// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _44clear_fwd_refs()
{
    object _0, _1, _2;
    

    /** fwdref.e:70		fwdref_count = 0*/
    _44fwdref_count_62789 = 0;

    /** fwdref.e:71	end procedure*/
    return;
    ;
}


object _44get_fwdref_count()
{
    object _0, _1, _2;
    

    /** fwdref.e:74		return fwdref_count*/
    return _44fwdref_count_62789;
    ;
}


void _44set_glabel_block(object _ref_62796, object _block_62798)
{
    object _30832 = NOVALUE;
    object _30831 = NOVALUE;
    object _30829 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_62796)) {
        _1 = (object)(DBL_PTR(_ref_62796)->dbl);
        DeRefDS(_ref_62796);
        _ref_62796 = _1;
    }
    if (!IS_ATOM_INT(_block_62798)) {
        _1 = (object)(DBL_PTR(_block_62798)->dbl);
        DeRefDS(_block_62798);
        _block_62798 = _1;
    }

    /** fwdref.e:78		forward_references[ref][FR_DATA] &= block*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_62796 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _30831 = (object)*(((s1_ptr)_2)->base + 12);
    _30829 = NOVALUE;
    if (IS_SEQUENCE(_30831) && IS_ATOM(_block_62798)) {
        Append(&_30832, _30831, _block_62798);
    }
    else if (IS_ATOM(_30831) && IS_SEQUENCE(_block_62798)) {
    }
    else {
        Concat((object_ptr)&_30832, _30831, _block_62798);
        _30831 = NOVALUE;
    }
    _30831 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30832;
    if( _1 != _30832 ){
        DeRef(_1);
    }
    _30832 = NOVALUE;
    _30829 = NOVALUE;

    /** fwdref.e:79	end procedure*/
    return;
    ;
}


void _44replace_code(object _code_62810, object _start_62811, object _finish_62812, object _subprog_62813)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_finish_62812)) {
        _1 = (object)(DBL_PTR(_finish_62812)->dbl);
        DeRefDS(_finish_62812);
        _finish_62812 = _1;
    }
    if (!IS_ATOM_INT(_subprog_62813)) {
        _1 = (object)(DBL_PTR(_subprog_62813)->dbl);
        DeRefDS(_subprog_62813);
        _subprog_62813 = _1;
    }

    /** fwdref.e:88		shifting_sub = subprog*/
    _44shifting_sub_62788 = _subprog_62813;

    /** fwdref.e:89		shift:replace_code( code, start, finish )*/
    RefDS(_code_62810);
    _66replace_code(_code_62810, _start_62811, _finish_62812);

    /** fwdref.e:90		shifting_sub = 0*/
    _44shifting_sub_62788 = 0;

    /** fwdref.e:91	end procedure*/
    DeRefDS(_code_62810);
    return;
    ;
}


void _44resolved_reference(object _ref_62816)
{
    object _file_62817 = NOVALUE;
    object _subprog_62820 = NOVALUE;
    object _tx_62823 = NOVALUE;
    object _ax_62824 = NOVALUE;
    object _sp_62825 = NOVALUE;
    object _r_62840 = NOVALUE;
    object _r_62858 = NOVALUE;
    object _30856 = NOVALUE;
    object _30855 = NOVALUE;
    object _30854 = NOVALUE;
    object _30852 = NOVALUE;
    object _30849 = NOVALUE;
    object _30847 = NOVALUE;
    object _30845 = NOVALUE;
    object _30844 = NOVALUE;
    object _30842 = NOVALUE;
    object _30840 = NOVALUE;
    object _30838 = NOVALUE;
    object _30837 = NOVALUE;
    object _30835 = NOVALUE;
    object _30833 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:95			file    = forward_references[ref][FR_FILE],*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    _30833 = (object)*(((s1_ptr)_2)->base + _ref_62816);
    _2 = (object)SEQ_PTR(_30833);
    _file_62817 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_file_62817)){
        _file_62817 = (object)DBL_PTR(_file_62817)->dbl;
    }
    _30833 = NOVALUE;

    /** fwdref.e:96			subprog = forward_references[ref][FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    _30835 = (object)*(((s1_ptr)_2)->base + _ref_62816);
    _2 = (object)SEQ_PTR(_30835);
    _subprog_62820 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_subprog_62820)){
        _subprog_62820 = (object)DBL_PTR(_subprog_62820)->dbl;
    }
    _30835 = NOVALUE;

    /** fwdref.e:99			tx = 0,*/
    _tx_62823 = 0;

    /** fwdref.e:100			ax = 0,*/
    _ax_62824 = 0;

    /** fwdref.e:101			sp = 0*/
    _sp_62825 = 0;

    /** fwdref.e:103		if forward_references[ref][FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    _30837 = (object)*(((s1_ptr)_2)->base + _ref_62816);
    _2 = (object)SEQ_PTR(_30837);
    _30838 = (object)*(((s1_ptr)_2)->base + 4);
    _30837 = NOVALUE;
    if (binary_op_a(NOTEQ, _30838, _36TopLevelSub_21454)){
        _30838 = NOVALUE;
        goto L1; // [60] 80
    }
    _30838 = NOVALUE;

    /** fwdref.e:104			tx = find( ref, toplevel_references[file] )*/
    _2 = (object)SEQ_PTR(_44toplevel_references_62772);
    _30840 = (object)*(((s1_ptr)_2)->base + _file_62817);
    _tx_62823 = find_from(_ref_62816, _30840, 1);
    _30840 = NOVALUE;
    goto L2; // [77] 111
L1: 

    /** fwdref.e:106			sp = find( subprog, active_subprogs[file] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_62770);
    _30842 = (object)*(((s1_ptr)_2)->base + _file_62817);
    _sp_62825 = find_from(_subprog_62820, _30842, 1);
    _30842 = NOVALUE;

    /** fwdref.e:107			ax = find( ref, active_references[file][sp] )*/
    _2 = (object)SEQ_PTR(_44active_references_62771);
    _30844 = (object)*(((s1_ptr)_2)->base + _file_62817);
    _2 = (object)SEQ_PTR(_30844);
    _30845 = (object)*(((s1_ptr)_2)->base + _sp_62825);
    _30844 = NOVALUE;
    _ax_62824 = find_from(_ref_62816, _30845, 1);
    _30845 = NOVALUE;
L2: 

    /** fwdref.e:110		if ax then*/
    if (_ax_62824 == 0)
    {
        goto L3; // [113] 253
    }
    else{
    }

    /** fwdref.e:111			sequence r = active_references[file][sp] */
    _2 = (object)SEQ_PTR(_44active_references_62771);
    _30847 = (object)*(((s1_ptr)_2)->base + _file_62817);
    DeRef(_r_62840);
    _2 = (object)SEQ_PTR(_30847);
    _r_62840 = (object)*(((s1_ptr)_2)->base + _sp_62825);
    Ref(_r_62840);
    _30847 = NOVALUE;

    /** fwdref.e:112			active_references[file][sp] = 0*/
    _2 = (object)SEQ_PTR(_44active_references_62771);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_62771 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_62817 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_62825);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30849 = NOVALUE;

    /** fwdref.e:113			r = remove( r, ax )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_62840);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ax_62824)) ? _ax_62824 : (object)(DBL_PTR(_ax_62824)->dbl);
        int stop = (IS_ATOM_INT(_ax_62824)) ? _ax_62824 : (object)(DBL_PTR(_ax_62824)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_62840), start, &_r_62840 );
            }
            else Tail(SEQ_PTR(_r_62840), stop+1, &_r_62840);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_62840), start, &_r_62840);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_62840 = Remove_elements(start, stop, (SEQ_PTR(_r_62840)->ref == 1));
        }
    }

    /** fwdref.e:114			active_references[file][sp] = r*/
    _2 = (object)SEQ_PTR(_44active_references_62771);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_62771 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_62817 + ((s1_ptr)_2)->base);
    RefDS(_r_62840);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_62825);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_62840;
    DeRef(_1);
    _30852 = NOVALUE;

    /** fwdref.e:116			if not length( active_references[file][sp] ) then*/
    _2 = (object)SEQ_PTR(_44active_references_62771);
    _30854 = (object)*(((s1_ptr)_2)->base + _file_62817);
    _2 = (object)SEQ_PTR(_30854);
    _30855 = (object)*(((s1_ptr)_2)->base + _sp_62825);
    _30854 = NOVALUE;
    if (IS_SEQUENCE(_30855)){
            _30856 = SEQ_PTR(_30855)->length;
    }
    else {
        _30856 = 1;
    }
    _30855 = NOVALUE;
    if (_30856 != 0)
    goto L4; // [178] 248
    _30856 = NOVALUE;

    /** fwdref.e:117				r = active_references[file]*/
    DeRefDS(_r_62840);
    _2 = (object)SEQ_PTR(_44active_references_62771);
    _r_62840 = (object)*(((s1_ptr)_2)->base + _file_62817);
    Ref(_r_62840);

    /** fwdref.e:118				active_references[file] = 0*/
    _2 = (object)SEQ_PTR(_44active_references_62771);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_62771 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_62817);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** fwdref.e:119				r = remove( r, sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_62840);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_62825)) ? _sp_62825 : (object)(DBL_PTR(_sp_62825)->dbl);
        int stop = (IS_ATOM_INT(_sp_62825)) ? _sp_62825 : (object)(DBL_PTR(_sp_62825)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_62840), start, &_r_62840 );
            }
            else Tail(SEQ_PTR(_r_62840), stop+1, &_r_62840);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_62840), start, &_r_62840);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_62840 = Remove_elements(start, stop, (SEQ_PTR(_r_62840)->ref == 1));
        }
    }

    /** fwdref.e:120				active_references[file] = r*/
    RefDS(_r_62840);
    _2 = (object)SEQ_PTR(_44active_references_62771);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_62771 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_62817);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_62840;
    DeRef(_1);

    /** fwdref.e:122				r = active_subprogs[file]*/
    DeRefDS(_r_62840);
    _2 = (object)SEQ_PTR(_44active_subprogs_62770);
    _r_62840 = (object)*(((s1_ptr)_2)->base + _file_62817);
    Ref(_r_62840);

    /** fwdref.e:123				active_subprogs[file] = 0*/
    _2 = (object)SEQ_PTR(_44active_subprogs_62770);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_subprogs_62770 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_62817);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** fwdref.e:124				r = remove( r,   sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_62840);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_62825)) ? _sp_62825 : (object)(DBL_PTR(_sp_62825)->dbl);
        int stop = (IS_ATOM_INT(_sp_62825)) ? _sp_62825 : (object)(DBL_PTR(_sp_62825)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_62840), start, &_r_62840 );
            }
            else Tail(SEQ_PTR(_r_62840), stop+1, &_r_62840);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_62840), start, &_r_62840);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_62840 = Remove_elements(start, stop, (SEQ_PTR(_r_62840)->ref == 1));
        }
    }

    /** fwdref.e:125				active_subprogs[file] = r*/
    RefDS(_r_62840);
    _2 = (object)SEQ_PTR(_44active_subprogs_62770);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_subprogs_62770 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_62817);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_62840;
    DeRef(_1);
L4: 
    DeRef(_r_62840);
    _r_62840 = NOVALUE;
    goto L5; // [250] 303
L3: 

    /** fwdref.e:127		elsif tx then*/
    if (_tx_62823 == 0)
    {
        goto L6; // [255] 296
    }
    else{
    }

    /** fwdref.e:128			sequence r = toplevel_references[file]*/
    DeRef(_r_62858);
    _2 = (object)SEQ_PTR(_44toplevel_references_62772);
    _r_62858 = (object)*(((s1_ptr)_2)->base + _file_62817);
    Ref(_r_62858);

    /** fwdref.e:129			toplevel_references[file] = 0*/
    _2 = (object)SEQ_PTR(_44toplevel_references_62772);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44toplevel_references_62772 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_62817);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** fwdref.e:130			r = remove( r, tx )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_62858);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_tx_62823)) ? _tx_62823 : (object)(DBL_PTR(_tx_62823)->dbl);
        int stop = (IS_ATOM_INT(_tx_62823)) ? _tx_62823 : (object)(DBL_PTR(_tx_62823)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_62858), start, &_r_62858 );
            }
            else Tail(SEQ_PTR(_r_62858), stop+1, &_r_62858);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_62858), start, &_r_62858);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_62858 = Remove_elements(start, stop, (SEQ_PTR(_r_62858)->ref == 1));
        }
    }

    /** fwdref.e:131			toplevel_references[file] = r*/
    RefDS(_r_62858);
    _2 = (object)SEQ_PTR(_44toplevel_references_62772);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44toplevel_references_62772 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_62817);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_62858;
    DeRef(_1);
    DeRefDS(_r_62858);
    _r_62858 = NOVALUE;
    goto L5; // [293] 303
L6: 

    /** fwdref.e:134			InternalErr( 260 )*/
    RefDS(_21997);
    _50InternalErr(260, _21997);
L5: 

    /** fwdref.e:136		inactive_references &= ref*/
    Append(&_44inactive_references_62773, _44inactive_references_62773, _ref_62816);

    /** fwdref.e:137		forward_references[ref] = 0*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ref_62816);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** fwdref.e:138	end procedure*/
    _30855 = NOVALUE;
    return;
    ;
}


void _44set_code(object _ref_62872)
{
    object _30881 = NOVALUE;
    object _30879 = NOVALUE;
    object _30878 = NOVALUE;
    object _30877 = NOVALUE;
    object _30876 = NOVALUE;
    object _30874 = NOVALUE;
    object _30872 = NOVALUE;
    object _30870 = NOVALUE;
    object _30868 = NOVALUE;
    object _30865 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:146		patch_code_sub = forward_references[ref][FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    _30865 = (object)*(((s1_ptr)_2)->base + _ref_62872);
    _2 = (object)SEQ_PTR(_30865);
    _44patch_code_sub_62867 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_44patch_code_sub_62867)){
        _44patch_code_sub_62867 = (object)DBL_PTR(_44patch_code_sub_62867)->dbl;
    }
    _30865 = NOVALUE;

    /** fwdref.e:147		if patch_code_sub != CurrentSub then*/
    if (_44patch_code_sub_62867 == _36CurrentSub_21455)
    goto L1; // [23] 136

    /** fwdref.e:149			patch_code_temp = Code*/
    RefDS(_36Code_21539);
    DeRef(_44patch_code_temp_62864);
    _44patch_code_temp_62864 = _36Code_21539;

    /** fwdref.e:150			patch_linetab_temp = LineTable*/
    RefDS(_36LineTable_21540);
    DeRef(_44patch_linetab_temp_62865);
    _44patch_linetab_temp_62865 = _36LineTable_21540;

    /** fwdref.e:152			Code = SymTab[patch_code_sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30868 = (object)*(((s1_ptr)_2)->base + _44patch_code_sub_62867);
    DeRefDS(_36Code_21539);
    _2 = (object)SEQ_PTR(_30868);
    if (!IS_ATOM_INT(_36S_CODE_21096)){
        _36Code_21539 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21096)->dbl));
    }
    else{
        _36Code_21539 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21096);
    }
    Ref(_36Code_21539);
    _30868 = NOVALUE;

    /** fwdref.e:153			SymTab[patch_code_sub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_62867 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21096))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21096)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21096);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30870 = NOVALUE;

    /** fwdref.e:154			LineTable = SymTab[patch_code_sub][S_LINETAB]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30872 = (object)*(((s1_ptr)_2)->base + _44patch_code_sub_62867);
    DeRefDS(_36LineTable_21540);
    _2 = (object)SEQ_PTR(_30872);
    if (!IS_ATOM_INT(_36S_LINETAB_21119)){
        _36LineTable_21540 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21119)->dbl));
    }
    else{
        _36LineTable_21540 = (object)*(((s1_ptr)_2)->base + _36S_LINETAB_21119);
    }
    Ref(_36LineTable_21540);
    _30872 = NOVALUE;

    /** fwdref.e:155			SymTab[patch_code_sub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_62867 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21119))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21119)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21119);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30874 = NOVALUE;

    /** fwdref.e:157			patch_current_sub = CurrentSub*/
    _44patch_current_sub_62869 = _36CurrentSub_21455;

    /** fwdref.e:158			CurrentSub = patch_code_sub*/
    _36CurrentSub_21455 = _44patch_code_sub_62867;
    goto L2; // [133] 203
L1: 

    /** fwdref.e:160			patch_current_sub = patch_code_sub*/
    _44patch_current_sub_62869 = _44patch_code_sub_62867;

    /** fwdref.e:161			if sequence( SymTab[patch_current_sub][S_CODE] ) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30876 = (object)*(((s1_ptr)_2)->base + _44patch_current_sub_62869);
    _2 = (object)SEQ_PTR(_30876);
    if (!IS_ATOM_INT(_36S_CODE_21096)){
        _30877 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21096)->dbl));
    }
    else{
        _30877 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21096);
    }
    _30876 = NOVALUE;
    _30878 = IS_SEQUENCE(_30877);
    _30877 = NOVALUE;
    if (_30878 == 0)
    {
        _30878 = NOVALUE;
        goto L3; // [164] 202
    }
    else{
        _30878 = NOVALUE;
    }

    /** fwdref.e:162				SymTab[patch_code_sub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_62867 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21096))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21096)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21096);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30879 = NOVALUE;

    /** fwdref.e:163				SymTab[patch_code_sub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_62867 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21119))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21119)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21119);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30881 = NOVALUE;
L3: 
L2: 

    /** fwdref.e:166	end procedure*/
    return;
    ;
}


void _44reset_code()
{
    object _30886 = NOVALUE;
    object _30884 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:169		if patch_code_sub != patch_current_sub then*/
    if (_44patch_code_sub_62867 == _44patch_current_sub_62869)
    goto L1; // [7] 77

    /** fwdref.e:171			SymTab[patch_code_sub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_62867 + ((s1_ptr)_2)->base);
    RefDS(_36Code_21539);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21096))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21096)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21096);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36Code_21539;
    DeRef(_1);
    _30884 = NOVALUE;

    /** fwdref.e:172			SymTab[patch_code_sub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_62867 + ((s1_ptr)_2)->base);
    RefDS(_36LineTable_21540);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21119))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21119)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21119);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36LineTable_21540;
    DeRef(_1);
    _30886 = NOVALUE;

    /** fwdref.e:175			CurrentSub = patch_current_sub*/
    _36CurrentSub_21455 = _44patch_current_sub_62869;

    /** fwdref.e:176			Code = patch_code_temp*/
    RefDS(_44patch_code_temp_62864);
    DeRefDS(_36Code_21539);
    _36Code_21539 = _44patch_code_temp_62864;

    /** fwdref.e:177			LineTable = patch_linetab_temp*/
    RefDS(_44patch_linetab_temp_62865);
    DeRefDS(_36LineTable_21540);
    _36LineTable_21540 = _44patch_linetab_temp_62865;
L1: 

    /** fwdref.e:181		patch_code_temp = {}*/
    RefDS(_21997);
    DeRef(_44patch_code_temp_62864);
    _44patch_code_temp_62864 = _21997;

    /** fwdref.e:182		patch_linetab_temp = {}*/
    RefDS(_21997);
    DeRef(_44patch_linetab_temp_62865);
    _44patch_linetab_temp_62865 = _21997;

    /** fwdref.e:183	end procedure*/
    return;
    ;
}


void _44set_data(object _ref_62934, object _data_62935)
{
    object _30888 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:186		forward_references[ref][FR_DATA] = data*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_62934 + ((s1_ptr)_2)->base);
    Ref(_data_62935);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _data_62935;
    DeRef(_1);
    _30888 = NOVALUE;

    /** fwdref.e:187	end procedure*/
    DeRef(_data_62935);
    return;
    ;
}


void _44add_data(object _ref_62940, object _data_62941)
{
    object _30894 = NOVALUE;
    object _30893 = NOVALUE;
    object _30892 = NOVALUE;
    object _30890 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_62940)) {
        _1 = (object)(DBL_PTR(_ref_62940)->dbl);
        DeRefDS(_ref_62940);
        _ref_62940 = _1;
    }

    /** fwdref.e:190		forward_references[ref][FR_DATA] = append( forward_references[ref][FR_DATA], data )*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_62940 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    _30892 = (object)*(((s1_ptr)_2)->base + _ref_62940);
    _2 = (object)SEQ_PTR(_30892);
    _30893 = (object)*(((s1_ptr)_2)->base + 12);
    _30892 = NOVALUE;
    Ref(_data_62941);
    Append(&_30894, _30893, _data_62941);
    _30893 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30894;
    if( _1 != _30894 ){
        DeRef(_1);
    }
    _30894 = NOVALUE;
    _30890 = NOVALUE;

    /** fwdref.e:191	end procedure*/
    DeRef(_data_62941);
    return;
    ;
}


void _44set_line(object _ref_62949, object _line_no_62950, object _this_line_62951, object _bp_62952)
{
    object _30899 = NOVALUE;
    object _30897 = NOVALUE;
    object _30895 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_62949)) {
        _1 = (object)(DBL_PTR(_ref_62949)->dbl);
        DeRefDS(_ref_62949);
        _ref_62949 = _1;
    }

    /** fwdref.e:194		forward_references[ref][FR_LINE] = line_no*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_62949 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _line_no_62950;
    DeRef(_1);
    _30895 = NOVALUE;

    /** fwdref.e:195		forward_references[ref][FR_THISLINE] = this_line*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_62949 + ((s1_ptr)_2)->base);
    RefDS(_this_line_62951);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _this_line_62951;
    DeRef(_1);
    _30897 = NOVALUE;

    /** fwdref.e:196		forward_references[ref][FR_BP] = bp*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_62949 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _bp_62952;
    DeRef(_1);
    _30899 = NOVALUE;

    /** fwdref.e:198	end procedure*/
    DeRefDS(_this_line_62951);
    return;
    ;
}


void _44add_private_symbol(object _sym_62964, object _name_62965)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_62964)) {
        _1 = (object)(DBL_PTR(_sym_62964)->dbl);
        DeRefDS(_sym_62964);
        _sym_62964 = _1;
    }

    /** fwdref.e:206		fwd_private_sym &= sym*/
    Append(&_44fwd_private_sym_62959, _44fwd_private_sym_62959, _sym_62964);

    /** fwdref.e:207		fwd_private_name = append( fwd_private_name, name )*/
    RefDS(_name_62965);
    Append(&_44fwd_private_name_62960, _44fwd_private_name_62960, _name_62965);

    /** fwdref.e:209	end procedure*/
    DeRefDS(_name_62965);
    return;
    ;
}


void _44patch_forward_goto(object _tok_62973, object _ref_62974)
{
    object _fr_62975 = NOVALUE;
    object _30915 = NOVALUE;
    object _30914 = NOVALUE;
    object _30913 = NOVALUE;
    object _30912 = NOVALUE;
    object _30911 = NOVALUE;
    object _30910 = NOVALUE;
    object _30909 = NOVALUE;
    object _30908 = NOVALUE;
    object _30906 = NOVALUE;
    object _30905 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:217		sequence fr = forward_references[ref]*/
    DeRef(_fr_62975);
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    _fr_62975 = (object)*(((s1_ptr)_2)->base + _ref_62974);
    Ref(_fr_62975);

    /** fwdref.e:218		set_code( ref )*/
    _44set_code(_ref_62974);

    /** fwdref.e:220		shifting_sub = fr[FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_fr_62975);
    _44shifting_sub_62788 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_44shifting_sub_62788))
    _44shifting_sub_62788 = (object)DBL_PTR(_44shifting_sub_62788)->dbl;

    /** fwdref.e:222		if length( fr[FR_DATA] ) = 2 then*/
    _2 = (object)SEQ_PTR(_fr_62975);
    _30905 = (object)*(((s1_ptr)_2)->base + 12);
    if (IS_SEQUENCE(_30905)){
            _30906 = SEQ_PTR(_30905)->length;
    }
    else {
        _30906 = 1;
    }
    _30905 = NOVALUE;
    if (_30906 != 2)
    goto L1; // [33] 64

    /** fwdref.e:223			prep_forward_error( ref )*/
    _44prep_forward_error(_ref_62974);

    /** fwdref.e:224			CompileErr( UNKNOWN_LABEL_1, { fr[FR_DATA][2] })*/
    _2 = (object)SEQ_PTR(_fr_62975);
    _30908 = (object)*(((s1_ptr)_2)->base + 12);
    _2 = (object)SEQ_PTR(_30908);
    _30909 = (object)*(((s1_ptr)_2)->base + 2);
    _30908 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_30909);
    ((intptr_t*)_2)[1] = _30909;
    _30910 = MAKE_SEQ(_1);
    _30909 = NOVALUE;
    _50CompileErr(156, _30910, 0);
    _30910 = NOVALUE;
L1: 

    /** fwdref.e:227		Goto_block(  fr[FR_DATA][1], fr[FR_DATA][3], fr[FR_PC] )*/
    _2 = (object)SEQ_PTR(_fr_62975);
    _30911 = (object)*(((s1_ptr)_2)->base + 12);
    _2 = (object)SEQ_PTR(_30911);
    _30912 = (object)*(((s1_ptr)_2)->base + 1);
    _30911 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_62975);
    _30913 = (object)*(((s1_ptr)_2)->base + 12);
    _2 = (object)SEQ_PTR(_30913);
    _30914 = (object)*(((s1_ptr)_2)->base + 3);
    _30913 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_62975);
    _30915 = (object)*(((s1_ptr)_2)->base + 5);
    Ref(_30912);
    Ref(_30914);
    Ref(_30915);
    _65Goto_block(_30912, _30914, _30915);
    _30912 = NOVALUE;
    _30914 = NOVALUE;
    _30915 = NOVALUE;

    /** fwdref.e:229		shifting_sub = 0*/
    _44shifting_sub_62788 = 0;

    /** fwdref.e:231		reset_code()*/
    _44reset_code();

    /** fwdref.e:232		resolved_reference( ref )*/
    _44resolved_reference(_ref_62974);

    /** fwdref.e:233	end procedure*/
    DeRefDS(_fr_62975);
    _30905 = NOVALUE;
    return;
    ;
}


void _44patch_forward_call(object _tok_62997, object _ref_62998)
{
    object _fr_62999 = NOVALUE;
    object _sub_63002 = NOVALUE;
    object _defarg_63008 = NOVALUE;
    object _paramsym_63012 = NOVALUE;
    object _old_63015 = NOVALUE;
    object _tx_63019 = NOVALUE;
    object _code_sub_63029 = NOVALUE;
    object _args_63031 = NOVALUE;
    object _is_func_63036 = NOVALUE;
    object _real_file_63050 = NOVALUE;
    object _code_63054 = NOVALUE;
    object _temp_sub_63056 = NOVALUE;
    object _pc_63058 = NOVALUE;
    object _next_pc_63060 = NOVALUE;
    object _supplied_args_63061 = NOVALUE;
    object _name_63064 = NOVALUE;
    object _old_temps_allocated_63100 = NOVALUE;
    object _temp_target_63109 = NOVALUE;
    object _converted_code_63112 = NOVALUE;
    object _target_63128 = NOVALUE;
    object _has_defaults_63134 = NOVALUE;
    object _goto_target_63135 = NOVALUE;
    object _defarg_63138 = NOVALUE;
    object _code_len_63139 = NOVALUE;
    object _extra_default_args_63141 = NOVALUE;
    object _param_sym_63144 = NOVALUE;
    object _params_63145 = NOVALUE;
    object _orig_code_63147 = NOVALUE;
    object _orig_linetable_63148 = NOVALUE;
    object _ar_sp_63152 = NOVALUE;
    object _pre_refs_63156 = NOVALUE;
    object _old_fwd_params_63171 = NOVALUE;
    object _temp_shifting_sub_63212 = NOVALUE;
    object _new_code_63216 = NOVALUE;
    object _routine_type_63225 = NOVALUE;
    object _31674 = NOVALUE;
    object _31056 = NOVALUE;
    object _31055 = NOVALUE;
    object _31054 = NOVALUE;
    object _31052 = NOVALUE;
    object _31051 = NOVALUE;
    object _31050 = NOVALUE;
    object _31049 = NOVALUE;
    object _31048 = NOVALUE;
    object _31047 = NOVALUE;
    object _31046 = NOVALUE;
    object _31045 = NOVALUE;
    object _31044 = NOVALUE;
    object _31043 = NOVALUE;
    object _31042 = NOVALUE;
    object _31041 = NOVALUE;
    object _31040 = NOVALUE;
    object _31038 = NOVALUE;
    object _31037 = NOVALUE;
    object _31036 = NOVALUE;
    object _31035 = NOVALUE;
    object _31034 = NOVALUE;
    object _31033 = NOVALUE;
    object _31032 = NOVALUE;
    object _31031 = NOVALUE;
    object _31029 = NOVALUE;
    object _31026 = NOVALUE;
    object _31025 = NOVALUE;
    object _31024 = NOVALUE;
    object _31023 = NOVALUE;
    object _31019 = NOVALUE;
    object _31018 = NOVALUE;
    object _31017 = NOVALUE;
    object _31016 = NOVALUE;
    object _31015 = NOVALUE;
    object _31013 = NOVALUE;
    object _31012 = NOVALUE;
    object _31011 = NOVALUE;
    object _31010 = NOVALUE;
    object _31009 = NOVALUE;
    object _31008 = NOVALUE;
    object _31006 = NOVALUE;
    object _31005 = NOVALUE;
    object _31003 = NOVALUE;
    object _31002 = NOVALUE;
    object _31001 = NOVALUE;
    object _31000 = NOVALUE;
    object _30998 = NOVALUE;
    object _30996 = NOVALUE;
    object _30995 = NOVALUE;
    object _30994 = NOVALUE;
    object _30992 = NOVALUE;
    object _30991 = NOVALUE;
    object _30989 = NOVALUE;
    object _30987 = NOVALUE;
    object _30984 = NOVALUE;
    object _30980 = NOVALUE;
    object _30978 = NOVALUE;
    object _30977 = NOVALUE;
    object _30975 = NOVALUE;
    object _30974 = NOVALUE;
    object _30973 = NOVALUE;
    object _30972 = NOVALUE;
    object _30970 = NOVALUE;
    object _30969 = NOVALUE;
    object _30968 = NOVALUE;
    object _30967 = NOVALUE;
    object _30966 = NOVALUE;
    object _30964 = NOVALUE;
    object _30963 = NOVALUE;
    object _30962 = NOVALUE;
    object _30961 = NOVALUE;
    object _30960 = NOVALUE;
    object _30959 = NOVALUE;
    object _30958 = NOVALUE;
    object _30957 = NOVALUE;
    object _30956 = NOVALUE;
    object _30955 = NOVALUE;
    object _30954 = NOVALUE;
    object _30953 = NOVALUE;
    object _30952 = NOVALUE;
    object _30951 = NOVALUE;
    object _30949 = NOVALUE;
    object _30948 = NOVALUE;
    object _30947 = NOVALUE;
    object _30946 = NOVALUE;
    object _30945 = NOVALUE;
    object _30942 = NOVALUE;
    object _30938 = NOVALUE;
    object _30937 = NOVALUE;
    object _30936 = NOVALUE;
    object _30935 = NOVALUE;
    object _30934 = NOVALUE;
    object _30933 = NOVALUE;
    object _30931 = NOVALUE;
    object _30928 = NOVALUE;
    object _30926 = NOVALUE;
    object _30925 = NOVALUE;
    object _30923 = NOVALUE;
    object _30920 = NOVALUE;
    object _30919 = NOVALUE;
    object _30918 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:242		sequence fr = forward_references[ref]*/
    DeRef(_fr_62999);
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    _fr_62999 = (object)*(((s1_ptr)_2)->base + _ref_62998);
    Ref(_fr_62999);

    /** fwdref.e:243		symtab_index sub = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_62997);
    _sub_63002 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sub_63002)){
        _sub_63002 = (object)DBL_PTR(_sub_63002)->dbl;
    }

    /** fwdref.e:245		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_62999);
    _30918 = (object)*(((s1_ptr)_2)->base + 12);
    _30919 = IS_SEQUENCE(_30918);
    _30918 = NOVALUE;
    if (_30919 == 0)
    {
        _30919 = NOVALUE;
        goto L1; // [32] 117
    }
    else{
        _30919 = NOVALUE;
    }

    /** fwdref.e:246			sequence defarg = fr[FR_DATA][1]*/
    _2 = (object)SEQ_PTR(_fr_62999);
    _30920 = (object)*(((s1_ptr)_2)->base + 12);
    DeRef(_defarg_63008);
    _2 = (object)SEQ_PTR(_30920);
    _defarg_63008 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_defarg_63008);
    _30920 = NOVALUE;

    /** fwdref.e:247			symtab_index paramsym = defarg[2]*/
    _2 = (object)SEQ_PTR(_defarg_63008);
    _paramsym_63012 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_paramsym_63012)){
        _paramsym_63012 = (object)DBL_PTR(_paramsym_63012)->dbl;
    }

    /** fwdref.e:248			token old = { RECORDED, defarg[3] }*/
    _2 = (object)SEQ_PTR(_defarg_63008);
    _30923 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_30923);
    DeRef(_old_63015);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508;
    ((intptr_t *)_2)[2] = _30923;
    _old_63015 = MAKE_SEQ(_1);
    _30923 = NOVALUE;

    /** fwdref.e:249			integer tx = find( old, SymTab[paramsym][S_CODE] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30925 = (object)*(((s1_ptr)_2)->base + _paramsym_63012);
    _2 = (object)SEQ_PTR(_30925);
    if (!IS_ATOM_INT(_36S_CODE_21096)){
        _30926 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21096)->dbl));
    }
    else{
        _30926 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21096);
    }
    _30925 = NOVALUE;
    _tx_63019 = find_from(_old_63015, _30926, 1);
    _30926 = NOVALUE;

    /** fwdref.e:250			SymTab[paramsym][S_CODE][tx] = tok*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_paramsym_63012 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21096))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21096)->dbl));
    else
    _3 = (object)(_36S_CODE_21096 + ((s1_ptr)_2)->base);
    _30928 = NOVALUE;
    Ref(_tok_62997);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _tx_63019);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _tok_62997;
    DeRef(_1);
    _30928 = NOVALUE;

    /** fwdref.e:251			resolved_reference( ref )*/
    _44resolved_reference(_ref_62998);

    /** fwdref.e:252			return*/
    DeRefDS(_defarg_63008);
    DeRefDS(_old_63015);
    DeRef(_tok_62997);
    DeRefDS(_fr_62999);
    DeRef(_code_63054);
    DeRef(_name_63064);
    DeRef(_params_63145);
    DeRef(_orig_code_63147);
    DeRef(_orig_linetable_63148);
    DeRef(_old_fwd_params_63171);
    DeRef(_new_code_63216);
    return;
L1: 
    DeRef(_defarg_63008);
    _defarg_63008 = NOVALUE;
    DeRef(_old_63015);
    _old_63015 = NOVALUE;

    /** fwdref.e:255		integer code_sub = fr[FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_fr_62999);
    _code_sub_63029 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_code_sub_63029))
    _code_sub_63029 = (object)DBL_PTR(_code_sub_63029)->dbl;

    /** fwdref.e:257		integer args = SymTab[sub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30931 = (object)*(((s1_ptr)_2)->base + _sub_63002);
    _2 = (object)SEQ_PTR(_30931);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
        _args_63031 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
    }
    else{
        _args_63031 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
    }
    if (!IS_ATOM_INT(_args_63031)){
        _args_63031 = (object)DBL_PTR(_args_63031)->dbl;
    }
    _30931 = NOVALUE;

    /** fwdref.e:258		integer is_func = (SymTab[sub][S_TOKEN] = FUNC) or (SymTab[sub][S_TOKEN] = TYPE)*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30933 = (object)*(((s1_ptr)_2)->base + _sub_63002);
    _2 = (object)SEQ_PTR(_30933);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _30934 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _30934 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    _30933 = NOVALUE;
    if (IS_ATOM_INT(_30934)) {
        _30935 = (_30934 == 501);
    }
    else {
        _30935 = binary_op(EQUALS, _30934, 501);
    }
    _30934 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30936 = (object)*(((s1_ptr)_2)->base + _sub_63002);
    _2 = (object)SEQ_PTR(_30936);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _30937 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _30937 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    _30936 = NOVALUE;
    if (IS_ATOM_INT(_30937)) {
        _30938 = (_30937 == 504);
    }
    else {
        _30938 = binary_op(EQUALS, _30937, 504);
    }
    _30937 = NOVALUE;
    if (IS_ATOM_INT(_30935) && IS_ATOM_INT(_30938)) {
        _is_func_63036 = (_30935 != 0 || _30938 != 0);
    }
    else {
        _is_func_63036 = binary_op(OR, _30935, _30938);
    }
    DeRef(_30935);
    _30935 = NOVALUE;
    DeRef(_30938);
    _30938 = NOVALUE;
    if (!IS_ATOM_INT(_is_func_63036)) {
        _1 = (object)(DBL_PTR(_is_func_63036)->dbl);
        DeRefDS(_is_func_63036);
        _is_func_63036 = _1;
    }

    /** fwdref.e:260		integer real_file = current_file_no*/
    _real_file_63050 = _36current_file_no_21447;

    /** fwdref.e:261		current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_62999);
    _36current_file_no_21447 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_36current_file_no_21447)){
        _36current_file_no_21447 = (object)DBL_PTR(_36current_file_no_21447)->dbl;
    }

    /** fwdref.e:263		set_code( ref )*/
    _44set_code(_ref_62998);

    /** fwdref.e:264		sequence code = Code*/
    RefDS(_36Code_21539);
    DeRef(_code_63054);
    _code_63054 = _36Code_21539;

    /** fwdref.e:265		integer temp_sub = CurrentSub*/
    _temp_sub_63056 = _36CurrentSub_21455;

    /** fwdref.e:267		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_62999);
    _pc_63058 = (object)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_63058))
    _pc_63058 = (object)DBL_PTR(_pc_63058)->dbl;

    /** fwdref.e:268		integer next_pc = pc*/
    _next_pc_63060 = _pc_63058;

    /** fwdref.e:269		integer supplied_args = code[pc+2]*/
    _30942 = _pc_63058 + 2;
    _2 = (object)SEQ_PTR(_code_63054);
    _supplied_args_63061 = (object)*(((s1_ptr)_2)->base + _30942);
    if (!IS_ATOM_INT(_supplied_args_63061))
    _supplied_args_63061 = (object)DBL_PTR(_supplied_args_63061)->dbl;

    /** fwdref.e:270		sequence name = fr[FR_NAME]*/
    DeRef(_name_63064);
    _2 = (object)SEQ_PTR(_fr_62999);
    _name_63064 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_name_63064);

    /** fwdref.e:272		if Code[pc] != FUNC_FORWARD and Code[pc] != PROC_FORWARD then*/
    _2 = (object)SEQ_PTR(_36Code_21539);
    _30945 = (object)*(((s1_ptr)_2)->base + _pc_63058);
    if (IS_ATOM_INT(_30945)) {
        _30946 = (_30945 != 196);
    }
    else {
        _30946 = binary_op(NOTEQ, _30945, 196);
    }
    _30945 = NOVALUE;
    if (IS_ATOM_INT(_30946)) {
        if (_30946 == 0) {
            goto L2; // [268] 332
        }
    }
    else {
        if (DBL_PTR(_30946)->dbl == 0.0) {
            goto L2; // [268] 332
        }
    }
    _2 = (object)SEQ_PTR(_36Code_21539);
    _30948 = (object)*(((s1_ptr)_2)->base + _pc_63058);
    if (IS_ATOM_INT(_30948)) {
        _30949 = (_30948 != 195);
    }
    else {
        _30949 = binary_op(NOTEQ, _30948, 195);
    }
    _30948 = NOVALUE;
    if (_30949 == 0) {
        DeRef(_30949);
        _30949 = NOVALUE;
        goto L2; // [285] 332
    }
    else {
        if (!IS_ATOM_INT(_30949) && DBL_PTR(_30949)->dbl == 0.0){
            DeRef(_30949);
            _30949 = NOVALUE;
            goto L2; // [285] 332
        }
        DeRef(_30949);
        _30949 = NOVALUE;
    }
    DeRef(_30949);
    _30949 = NOVALUE;

    /** fwdref.e:273			prep_forward_error( ref )*/
    _44prep_forward_error(_ref_62998);

    /** fwdref.e:274			CompileErr( "The forward call to [4] wasn't where we thought it would be: [1]:[2]:[3]",*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _30951 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    _2 = (object)SEQ_PTR(_fr_62999);
    _30952 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_30952);
    _30953 = _54sym_name(_30952);
    _30952 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_62999);
    _30954 = (object)*(((s1_ptr)_2)->base + 6);
    _2 = (object)SEQ_PTR(_fr_62999);
    _30955 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_30951);
    ((intptr_t*)_2)[1] = _30951;
    ((intptr_t*)_2)[2] = _30953;
    Ref(_30954);
    ((intptr_t*)_2)[3] = _30954;
    Ref(_30955);
    ((intptr_t*)_2)[4] = _30955;
    _30956 = MAKE_SEQ(_1);
    _30955 = NOVALUE;
    _30954 = NOVALUE;
    _30953 = NOVALUE;
    _30951 = NOVALUE;
    RefDS(_30950);
    _50CompileErr(_30950, _30956, 0);
    _30956 = NOVALUE;
L2: 

    /** fwdref.e:278		if SymTab[sub][S_DEPRECATED] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30957 = (object)*(((s1_ptr)_2)->base + _sub_63002);
    _2 = (object)SEQ_PTR(_30957);
    _30958 = (object)*(((s1_ptr)_2)->base + 30);
    _30957 = NOVALUE;
    if (_30958 == 0) {
        _30958 = NOVALUE;
        goto L3; // [346] 375
    }
    else {
        if (!IS_ATOM_INT(_30958) && DBL_PTR(_30958)->dbl == 0.0){
            _30958 = NOVALUE;
            goto L3; // [346] 375
        }
        _30958 = NOVALUE;
    }
    _30958 = NOVALUE;

    /** fwdref.e:279			Warning(327, deprecated_warning_flag, { SymTab[sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30959 = (object)*(((s1_ptr)_2)->base + _sub_63002);
    _2 = (object)SEQ_PTR(_30959);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _30960 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _30960 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _30959 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_30960);
    ((intptr_t*)_2)[1] = _30960;
    _30961 = MAKE_SEQ(_1);
    _30960 = NOVALUE;
    _50Warning(327, 16384, _30961);
    _30961 = NOVALUE;
L3: 

    /** fwdref.e:282		integer old_temps_allocated = temps_allocated*/
    _old_temps_allocated_63100 = _54temps_allocated_47311;

    /** fwdref.e:283		temps_allocated = 0*/
    _54temps_allocated_47311 = 0;

    /** fwdref.e:285		if is_func and fr[FR_OP] = PROC then*/
    if (_is_func_63036 == 0) {
        goto L4; // [393] 481
    }
    _2 = (object)SEQ_PTR(_fr_62999);
    _30963 = (object)*(((s1_ptr)_2)->base + 10);
    if (IS_ATOM_INT(_30963)) {
        _30964 = (_30963 == 27);
    }
    else {
        _30964 = binary_op(EQUALS, _30963, 27);
    }
    _30963 = NOVALUE;
    if (_30964 == 0) {
        DeRef(_30964);
        _30964 = NOVALUE;
        goto L4; // [408] 481
    }
    else {
        if (!IS_ATOM_INT(_30964) && DBL_PTR(_30964)->dbl == 0.0){
            DeRef(_30964);
            _30964 = NOVALUE;
            goto L4; // [408] 481
        }
        DeRef(_30964);
        _30964 = NOVALUE;
    }
    DeRef(_30964);
    _30964 = NOVALUE;

    /** fwdref.e:288			symtab_index temp_target = NewTempSym()*/
    _temp_target_63109 = _54NewTempSym(0);
    if (!IS_ATOM_INT(_temp_target_63109)) {
        _1 = (object)(DBL_PTR(_temp_target_63109)->dbl);
        DeRefDS(_temp_target_63109);
        _temp_target_63109 = _1;
    }

    /** fwdref.e:289			sequence converted_code = */
    _30966 = _pc_63058 + 1;
    if (_30966 > MAXINT){
        _30966 = NewDouble((eudouble)_30966);
    }
    _30967 = _pc_63058 + 2;
    if ((object)((uintptr_t)_30967 + (uintptr_t)HIGH_BITS) >= 0){
        _30967 = NewDouble((eudouble)_30967);
    }
    if (IS_ATOM_INT(_30967)) {
        _30968 = _30967 + _supplied_args_63061;
    }
    else {
        _30968 = NewDouble(DBL_PTR(_30967)->dbl + (eudouble)_supplied_args_63061);
    }
    DeRef(_30967);
    _30967 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30969;
    RHS_Slice(_36Code_21539, _30966, _30968);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 208;
    ((intptr_t *)_2)[2] = _temp_target_63109;
    _30970 = MAKE_SEQ(_1);
    {
        object concat_list[4];

        concat_list[0] = _30970;
        concat_list[1] = _temp_target_63109;
        concat_list[2] = _30969;
        concat_list[3] = 196;
        Concat_N((object_ptr)&_converted_code_63112, concat_list, 4);
    }
    DeRefDS(_30970);
    _30970 = NOVALUE;
    DeRefDS(_30969);
    _30969 = NOVALUE;

    /** fwdref.e:295			replace_code( converted_code, pc, pc + 2 + supplied_args, code_sub )*/
    _30972 = _pc_63058 + 2;
    if ((object)((uintptr_t)_30972 + (uintptr_t)HIGH_BITS) >= 0){
        _30972 = NewDouble((eudouble)_30972);
    }
    if (IS_ATOM_INT(_30972)) {
        _30973 = _30972 + _supplied_args_63061;
        if ((object)((uintptr_t)_30973 + (uintptr_t)HIGH_BITS) >= 0){
            _30973 = NewDouble((eudouble)_30973);
        }
    }
    else {
        _30973 = NewDouble(DBL_PTR(_30972)->dbl + (eudouble)_supplied_args_63061);
    }
    DeRef(_30972);
    _30972 = NOVALUE;
    RefDS(_converted_code_63112);
    _44replace_code(_converted_code_63112, _pc_63058, _30973, _code_sub_63029);
    _30973 = NOVALUE;

    /** fwdref.e:297			code = Code*/
    RefDS(_36Code_21539);
    DeRef(_code_63054);
    _code_63054 = _36Code_21539;
L4: 
    DeRef(_converted_code_63112);
    _converted_code_63112 = NOVALUE;

    /** fwdref.e:299		next_pc +=*/
    _30974 = 3 + _supplied_args_63061;
    if ((object)((uintptr_t)_30974 + (uintptr_t)HIGH_BITS) >= 0){
        _30974 = NewDouble((eudouble)_30974);
    }
    if (IS_ATOM_INT(_30974)) {
        _30975 = _30974 + _is_func_63036;
        if ((object)((uintptr_t)_30975 + (uintptr_t)HIGH_BITS) >= 0){
            _30975 = NewDouble((eudouble)_30975);
        }
    }
    else {
        _30975 = NewDouble(DBL_PTR(_30974)->dbl + (eudouble)_is_func_63036);
    }
    DeRef(_30974);
    _30974 = NOVALUE;
    if (IS_ATOM_INT(_30975)) {
        _next_pc_63060 = _next_pc_63060 + _30975;
    }
    else {
        _next_pc_63060 = NewDouble((eudouble)_next_pc_63060 + DBL_PTR(_30975)->dbl);
    }
    DeRef(_30975);
    _30975 = NOVALUE;
    if (!IS_ATOM_INT(_next_pc_63060)) {
        _1 = (object)(DBL_PTR(_next_pc_63060)->dbl);
        DeRefDS(_next_pc_63060);
        _next_pc_63060 = _1;
    }

    /** fwdref.e:303		integer target*/

    /** fwdref.e:304		if is_func then*/
    if (_is_func_63036 == 0)
    {
        goto L5; // [503] 525
    }
    else{
    }

    /** fwdref.e:305			target = Code[pc + 3 + supplied_args]*/
    _30977 = _pc_63058 + 3;
    if ((object)((uintptr_t)_30977 + (uintptr_t)HIGH_BITS) >= 0){
        _30977 = NewDouble((eudouble)_30977);
    }
    if (IS_ATOM_INT(_30977)) {
        _30978 = _30977 + _supplied_args_63061;
    }
    else {
        _30978 = NewDouble(DBL_PTR(_30977)->dbl + (eudouble)_supplied_args_63061);
    }
    DeRef(_30977);
    _30977 = NOVALUE;
    _2 = (object)SEQ_PTR(_36Code_21539);
    if (!IS_ATOM_INT(_30978)){
        _target_63128 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30978)->dbl));
    }
    else{
        _target_63128 = (object)*(((s1_ptr)_2)->base + _30978);
    }
    if (!IS_ATOM_INT(_target_63128)){
        _target_63128 = (object)DBL_PTR(_target_63128)->dbl;
    }
L5: 

    /** fwdref.e:307		integer has_defaults = 0*/
    _has_defaults_63134 = 0;

    /** fwdref.e:308		integer goto_target = length( code ) + 1*/
    if (IS_SEQUENCE(_code_63054)){
            _30980 = SEQ_PTR(_code_63054)->length;
    }
    else {
        _30980 = 1;
    }
    _goto_target_63135 = _30980 + 1;
    _30980 = NOVALUE;

    /** fwdref.e:309		integer defarg = 0*/
    _defarg_63138 = 0;

    /** fwdref.e:310		integer code_len = length(code)*/
    if (IS_SEQUENCE(_code_63054)){
            _code_len_63139 = SEQ_PTR(_code_63054)->length;
    }
    else {
        _code_len_63139 = 1;
    }

    /** fwdref.e:312		integer extra_default_args = 0*/
    _extra_default_args_63141 = 0;

    /** fwdref.e:313		set_dont_read( 1 )*/
    _62set_dont_read(1);

    /** fwdref.e:314		reset_private_lists()*/

    /** fwdref.e:212		fwd_private_sym  = {}*/
    RefDS(_21997);
    DeRefi(_44fwd_private_sym_62959);
    _44fwd_private_sym_62959 = _21997;

    /** fwdref.e:213		fwd_private_name = {}*/
    RefDS(_21997);
    DeRef(_44fwd_private_name_62960);
    _44fwd_private_name_62960 = _21997;

    /** fwdref.e:214	end procedure*/
    goto L6; // [577] 580
L6: 

    /** fwdref.e:315		integer param_sym = sub*/
    _param_sym_63144 = _sub_63002;

    /** fwdref.e:316		sequence params = repeat( 0, args )*/
    DeRef(_params_63145);
    _params_63145 = Repeat(0, _args_63031);

    /** fwdref.e:317		sequence orig_code = code*/
    RefDS(_code_63054);
    DeRef(_orig_code_63147);
    _orig_code_63147 = _code_63054;

    /** fwdref.e:318		sequence orig_linetable = LineTable*/
    RefDS(_36LineTable_21540);
    DeRef(_orig_linetable_63148);
    _orig_linetable_63148 = _36LineTable_21540;

    /** fwdref.e:319		LineTable = {}*/
    RefDS(_21997);
    DeRefDS(_36LineTable_21540);
    _36LineTable_21540 = _21997;

    /** fwdref.e:320		Code = {}*/
    RefDS(_21997);
    DeRef(_36Code_21539);
    _36Code_21539 = _21997;

    /** fwdref.e:323		integer ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_62770);
    _30984 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    _ar_sp_63152 = find_from(_code_sub_63029, _30984, 1);
    _30984 = NOVALUE;

    /** fwdref.e:324		integer pre_refs*/

    /** fwdref.e:326		if code_sub = TopLevelSub then*/
    if (_code_sub_63029 != _36TopLevelSub_21454)
    goto L7; // [644] 664

    /** fwdref.e:327			pre_refs = length( toplevel_references[current_file_no] )*/
    _2 = (object)SEQ_PTR(_44toplevel_references_62772);
    _30987 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    if (IS_SEQUENCE(_30987)){
            _pre_refs_63156 = SEQ_PTR(_30987)->length;
    }
    else {
        _pre_refs_63156 = 1;
    }
    _30987 = NOVALUE;
    goto L8; // [661] 697
L7: 

    /** fwdref.e:329			ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_62770);
    _30989 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    _ar_sp_63152 = find_from(_code_sub_63029, _30989, 1);
    _30989 = NOVALUE;

    /** fwdref.e:330			pre_refs = length( active_references[current_file_no][ar_sp] )*/
    _2 = (object)SEQ_PTR(_44active_references_62771);
    _30991 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    _2 = (object)SEQ_PTR(_30991);
    _30992 = (object)*(((s1_ptr)_2)->base + _ar_sp_63152);
    _30991 = NOVALUE;
    if (IS_SEQUENCE(_30992)){
            _pre_refs_63156 = SEQ_PTR(_30992)->length;
    }
    else {
        _pre_refs_63156 = 1;
    }
    _30992 = NOVALUE;
L8: 

    /** fwdref.e:333		sequence old_fwd_params = {}*/
    RefDS(_21997);
    DeRef(_old_fwd_params_63171);
    _old_fwd_params_63171 = _21997;

    /** fwdref.e:334		for i = pc + 3 to pc + args + 2 do*/
    _30994 = _pc_63058 + 3;
    if ((object)((uintptr_t)_30994 + (uintptr_t)HIGH_BITS) >= 0){
        _30994 = NewDouble((eudouble)_30994);
    }
    _30995 = _pc_63058 + _args_63031;
    if ((object)((uintptr_t)_30995 + (uintptr_t)HIGH_BITS) >= 0){
        _30995 = NewDouble((eudouble)_30995);
    }
    if (IS_ATOM_INT(_30995)) {
        _30996 = _30995 + 2;
        if ((object)((uintptr_t)_30996 + (uintptr_t)HIGH_BITS) >= 0){
            _30996 = NewDouble((eudouble)_30996);
        }
    }
    else {
        _30996 = NewDouble(DBL_PTR(_30995)->dbl + (eudouble)2);
    }
    DeRef(_30995);
    _30995 = NOVALUE;
    {
        object _i_63173;
        Ref(_30994);
        _i_63173 = _30994;
L9: 
        if (binary_op_a(GREATER, _i_63173, _30996)){
            goto LA; // [718] 879
        }

        /** fwdref.e:335			defarg += 1*/
        _defarg_63138 = _defarg_63138 + 1;

        /** fwdref.e:336			param_sym = SymTab[param_sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _30998 = (object)*(((s1_ptr)_2)->base + _param_sym_63144);
        _2 = (object)SEQ_PTR(_30998);
        _param_sym_63144 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_sym_63144)){
            _param_sym_63144 = (object)DBL_PTR(_param_sym_63144)->dbl;
        }
        _30998 = NOVALUE;

        /** fwdref.e:337			if defarg > supplied_args or i > length( code ) or not code[i] then*/
        _31000 = (_defarg_63138 > _supplied_args_63061);
        if (_31000 != 0) {
            _31001 = 1;
            goto LB; // [753] 768
        }
        if (IS_SEQUENCE(_code_63054)){
                _31002 = SEQ_PTR(_code_63054)->length;
        }
        else {
            _31002 = 1;
        }
        if (IS_ATOM_INT(_i_63173)) {
            _31003 = (_i_63173 > _31002);
        }
        else {
            _31003 = (DBL_PTR(_i_63173)->dbl > (eudouble)_31002);
        }
        _31002 = NOVALUE;
        _31001 = (_31003 != 0);
LB: 
        if (_31001 != 0) {
            goto LC; // [768] 784
        }
        _2 = (object)SEQ_PTR(_code_63054);
        if (!IS_ATOM_INT(_i_63173)){
            _31005 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63173)->dbl));
        }
        else{
            _31005 = (object)*(((s1_ptr)_2)->base + _i_63173);
        }
        if (IS_ATOM_INT(_31005)) {
            _31006 = (_31005 == 0);
        }
        else {
            _31006 = unary_op(NOT, _31005);
        }
        _31005 = NOVALUE;
        if (_31006 == 0) {
            DeRef(_31006);
            _31006 = NOVALUE;
            goto LD; // [780] 834
        }
        else {
            if (!IS_ATOM_INT(_31006) && DBL_PTR(_31006)->dbl == 0.0){
                DeRef(_31006);
                _31006 = NOVALUE;
                goto LD; // [780] 834
            }
            DeRef(_31006);
            _31006 = NOVALUE;
        }
        DeRef(_31006);
        _31006 = NOVALUE;
LC: 

        /** fwdref.e:339				has_defaults = 1*/
        _has_defaults_63134 = 1;

        /** fwdref.e:340				extra_default_args += 1*/
        _extra_default_args_63141 = _extra_default_args_63141 + 1;

        /** fwdref.e:345				show_params( sub )*/
        _54show_params(_sub_63002);

        /** fwdref.e:346				set_error_info( ref )*/
        _44set_error_info(_ref_62998);

        /** fwdref.e:347				Parse_default_arg(sub, defarg, fwd_private_name, fwd_private_sym) --call_proc( parse_arg_rid, { sub, defarg, fwd_private_name, fwd_private_sym } )*/
        RefDS(_44fwd_private_name_62960);
        RefDS(_44fwd_private_sym_62959);
        _45Parse_default_arg(_sub_63002, _defarg_63138, _44fwd_private_name_62960, _44fwd_private_sym_62959);

        /** fwdref.e:348				hide_params( sub )*/
        _54hide_params(_sub_63002);

        /** fwdref.e:349				params[defarg] = Pop()*/
        _31008 = _47Pop();
        _2 = (object)SEQ_PTR(_params_63145);
        _2 = (object)(((s1_ptr)_2)->base + _defarg_63138);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31008;
        if( _1 != _31008 ){
            DeRef(_1);
        }
        _31008 = NOVALUE;
        goto LE; // [831] 872
LD: 

        /** fwdref.e:351				extra_default_args = 0*/
        _extra_default_args_63141 = 0;

        /** fwdref.e:352				add_private_symbol( code[i], SymTab[param_sym][S_NAME] )*/
        _2 = (object)SEQ_PTR(_code_63054);
        if (!IS_ATOM_INT(_i_63173)){
            _31009 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63173)->dbl));
        }
        else{
            _31009 = (object)*(((s1_ptr)_2)->base + _i_63173);
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _31010 = (object)*(((s1_ptr)_2)->base + _param_sym_63144);
        _2 = (object)SEQ_PTR(_31010);
        if (!IS_ATOM_INT(_36S_NAME_21084)){
            _31011 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
        }
        else{
            _31011 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
        }
        _31010 = NOVALUE;
        Ref(_31009);
        Ref(_31011);
        _44add_private_symbol(_31009, _31011);
        _31009 = NOVALUE;
        _31011 = NOVALUE;

        /** fwdref.e:353				params[defarg] = code[i]*/
        _2 = (object)SEQ_PTR(_code_63054);
        if (!IS_ATOM_INT(_i_63173)){
            _31012 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63173)->dbl));
        }
        else{
            _31012 = (object)*(((s1_ptr)_2)->base + _i_63173);
        }
        Ref(_31012);
        _2 = (object)SEQ_PTR(_params_63145);
        _2 = (object)(((s1_ptr)_2)->base + _defarg_63138);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31012;
        if( _1 != _31012 ){
            DeRef(_1);
        }
        _31012 = NOVALUE;
LE: 

        /** fwdref.e:355		end for*/
        _0 = _i_63173;
        if (IS_ATOM_INT(_i_63173)) {
            _i_63173 = _i_63173 + 1;
            if ((object)((uintptr_t)_i_63173 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63173 = NewDouble((eudouble)_i_63173);
            }
        }
        else {
            _i_63173 = binary_op_a(PLUS, _i_63173, 1);
        }
        DeRef(_0);
        goto L9; // [874] 725
LA: 
        ;
        DeRef(_i_63173);
    }

    /** fwdref.e:357		SymTab[code_sub][S_STACK_SPACE] += temps_allocated*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_code_sub_63029 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21144)){
        _31015 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21144)->dbl));
    }
    else{
        _31015 = (object)*(((s1_ptr)_2)->base + _36S_STACK_SPACE_21144);
    }
    _31013 = NOVALUE;
    if (IS_ATOM_INT(_31015)) {
        _31016 = _31015 + _54temps_allocated_47311;
        if ((object)((uintptr_t)_31016 + (uintptr_t)HIGH_BITS) >= 0){
            _31016 = NewDouble((eudouble)_31016);
        }
    }
    else {
        _31016 = binary_op(PLUS, _31015, _54temps_allocated_47311);
    }
    _31015 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21144))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21144)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_STACK_SPACE_21144);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31016;
    if( _1 != _31016 ){
        DeRef(_1);
    }
    _31016 = NOVALUE;
    _31013 = NOVALUE;

    /** fwdref.e:358		temps_allocated = old_temps_allocated*/
    _54temps_allocated_47311 = _old_temps_allocated_63100;

    /** fwdref.e:363		integer temp_shifting_sub = shifting_sub*/
    _temp_shifting_sub_63212 = _44shifting_sub_62788;

    /** fwdref.e:364		shift( -pc, pc-1 )*/
    if ((uintptr_t)_pc_63058 == (uintptr_t)HIGH_BITS){
        _31017 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31017 = - _pc_63058;
    }
    _31018 = _pc_63058 - 1;
    if ((object)((uintptr_t)_31018 +(uintptr_t) HIGH_BITS) >= 0){
        _31018 = NewDouble((eudouble)_31018);
    }
    Ref(_31017);
    DeRef(_31674);
    _31674 = _31017;
    _66shift(_31017, _31018, _31674);
    _31017 = NOVALUE;
    _31018 = NOVALUE;
    _31674 = NOVALUE;

    /** fwdref.e:366		sequence new_code = Code*/
    RefDS(_36Code_21539);
    DeRef(_new_code_63216);
    _new_code_63216 = _36Code_21539;

    /** fwdref.e:367		Code = orig_code*/
    RefDS(_orig_code_63147);
    DeRefDS(_36Code_21539);
    _36Code_21539 = _orig_code_63147;

    /** fwdref.e:368		orig_code = {}*/
    RefDS(_21997);
    DeRefDS(_orig_code_63147);
    _orig_code_63147 = _21997;

    /** fwdref.e:369		LineTable = orig_linetable*/
    RefDS(_orig_linetable_63148);
    DeRef(_36LineTable_21540);
    _36LineTable_21540 = _orig_linetable_63148;

    /** fwdref.e:370		orig_linetable = {}*/
    RefDS(_21997);
    DeRefDS(_orig_linetable_63148);
    _orig_linetable_63148 = _21997;

    /** fwdref.e:371		set_dont_read( 0 )*/
    _62set_dont_read(0);

    /** fwdref.e:372		current_file_no = real_file*/
    _36current_file_no_21447 = _real_file_63050;

    /** fwdref.e:374		if args != ( supplied_args + extra_default_args ) then*/
    _31019 = _supplied_args_63061 + _extra_default_args_63141;
    if ((object)((uintptr_t)_31019 + (uintptr_t)HIGH_BITS) >= 0){
        _31019 = NewDouble((eudouble)_31019);
    }
    if (binary_op_a(EQUALS, _args_63031, _31019)){
        DeRef(_31019);
        _31019 = NOVALUE;
        goto LF; // [990] 1070
    }
    DeRef(_31019);
    _31019 = NOVALUE;

    /** fwdref.e:375			sequence routine_type*/

    /** fwdref.e:377			if is_func then */
    if (_is_func_63036 == 0)
    {
        goto L10; // [998] 1011
    }
    else{
    }

    /** fwdref.e:378				routine_type = "function"*/
    RefDS(_26196);
    DeRefi(_routine_type_63225);
    _routine_type_63225 = _26196;
    goto L11; // [1008] 1019
L10: 

    /** fwdref.e:380				routine_type = "procedure"*/
    RefDS(_26250);
    DeRefi(_routine_type_63225);
    _routine_type_63225 = _26250;
L11: 

    /** fwdref.e:382			current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_62999);
    _36current_file_no_21447 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_36current_file_no_21447)){
        _36current_file_no_21447 = (object)DBL_PTR(_36current_file_no_21447)->dbl;
    }

    /** fwdref.e:383			line_number = fr[FR_LINE]*/
    _2 = (object)SEQ_PTR(_fr_62999);
    _36line_number_21448 = (object)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_36line_number_21448)){
        _36line_number_21448 = (object)DBL_PTR(_36line_number_21448)->dbl;
    }

    /** fwdref.e:384			CompileErr( WRONG_NUMBER_OF_ARGUMENTS_SUPPLIED_FOR_FORWARD_REFERENCET1_2_3_4__EXPECTED_5_BUT_FOUND_6,*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _31023 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    _31024 = _supplied_args_63061 + _extra_default_args_63141;
    if ((object)((uintptr_t)_31024 + (uintptr_t)HIGH_BITS) >= 0){
        _31024 = NewDouble((eudouble)_31024);
    }
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31023);
    ((intptr_t*)_2)[1] = _31023;
    ((intptr_t*)_2)[2] = _36line_number_21448;
    RefDS(_routine_type_63225);
    ((intptr_t*)_2)[3] = _routine_type_63225;
    RefDS(_name_63064);
    ((intptr_t*)_2)[4] = _name_63064;
    ((intptr_t*)_2)[5] = _args_63031;
    ((intptr_t*)_2)[6] = _31024;
    _31025 = MAKE_SEQ(_1);
    _31024 = NOVALUE;
    _31023 = NOVALUE;
    _50CompileErr(158, _31025, 0);
    _31025 = NOVALUE;
LF: 
    DeRefi(_routine_type_63225);
    _routine_type_63225 = NOVALUE;

    /** fwdref.e:388		new_code &= PROC & sub & params*/
    {
        object concat_list[3];

        concat_list[0] = _params_63145;
        concat_list[1] = _sub_63002;
        concat_list[2] = 27;
        Concat_N((object_ptr)&_31026, concat_list, 3);
    }
    Concat((object_ptr)&_new_code_63216, _new_code_63216, _31026);
    DeRefDS(_31026);
    _31026 = NOVALUE;

    /** fwdref.e:389		if is_func then*/
    if (_is_func_63036 == 0)
    {
        goto L12; // [1088] 1100
    }
    else{
    }

    /** fwdref.e:390			new_code &= target*/
    Append(&_new_code_63216, _new_code_63216, _target_63128);
L12: 

    /** fwdref.e:393		replace_code( new_code, pc, next_pc - 1, code_sub )*/
    _31029 = _next_pc_63060 - 1;
    if ((object)((uintptr_t)_31029 +(uintptr_t) HIGH_BITS) >= 0){
        _31029 = NewDouble((eudouble)_31029);
    }
    RefDS(_new_code_63216);
    _44replace_code(_new_code_63216, _pc_63058, _31029, _code_sub_63029);
    _31029 = NOVALUE;

    /** fwdref.e:395		if code_sub = TopLevelSub then*/
    if (_code_sub_63029 != _36TopLevelSub_21454)
    goto L13; // [1116] 1197

    /** fwdref.e:396			for i = pre_refs + 1 to length( toplevel_references[fr[FR_FILE]] ) do*/
    _31031 = _pre_refs_63156 + 1;
    if (_31031 > MAXINT){
        _31031 = NewDouble((eudouble)_31031);
    }
    _2 = (object)SEQ_PTR(_fr_62999);
    _31032 = (object)*(((s1_ptr)_2)->base + 3);
    _2 = (object)SEQ_PTR(_44toplevel_references_62772);
    if (!IS_ATOM_INT(_31032)){
        _31033 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31032)->dbl));
    }
    else{
        _31033 = (object)*(((s1_ptr)_2)->base + _31032);
    }
    if (IS_SEQUENCE(_31033)){
            _31034 = SEQ_PTR(_31033)->length;
    }
    else {
        _31034 = 1;
    }
    _31033 = NOVALUE;
    {
        object _i_63250;
        Ref(_31031);
        _i_63250 = _31031;
L14: 
        if (binary_op_a(GREATER, _i_63250, _31034)){
            goto L15; // [1141] 1194
        }

        /** fwdref.e:397				forward_references[toplevel_references[fr[FR_FILE]][i]][FR_PC] += pc - 1*/
        _2 = (object)SEQ_PTR(_fr_62999);
        _31035 = (object)*(((s1_ptr)_2)->base + 3);
        _2 = (object)SEQ_PTR(_44toplevel_references_62772);
        if (!IS_ATOM_INT(_31035)){
            _31036 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31035)->dbl));
        }
        else{
            _31036 = (object)*(((s1_ptr)_2)->base + _31035);
        }
        _2 = (object)SEQ_PTR(_31036);
        if (!IS_ATOM_INT(_i_63250)){
            _31037 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63250)->dbl));
        }
        else{
            _31037 = (object)*(((s1_ptr)_2)->base + _i_63250);
        }
        _31036 = NOVALUE;
        _2 = (object)SEQ_PTR(_44forward_references_62769);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_62769 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31037))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31037)->dbl));
        else
        _3 = (object)(_31037 + ((s1_ptr)_2)->base);
        _31040 = _pc_63058 - 1;
        if ((object)((uintptr_t)_31040 +(uintptr_t) HIGH_BITS) >= 0){
            _31040 = NewDouble((eudouble)_31040);
        }
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _31041 = (object)*(((s1_ptr)_2)->base + 5);
        _31038 = NOVALUE;
        if (IS_ATOM_INT(_31041) && IS_ATOM_INT(_31040)) {
            _31042 = _31041 + _31040;
            if ((object)((uintptr_t)_31042 + (uintptr_t)HIGH_BITS) >= 0){
                _31042 = NewDouble((eudouble)_31042);
            }
        }
        else {
            _31042 = binary_op(PLUS, _31041, _31040);
        }
        _31041 = NOVALUE;
        DeRef(_31040);
        _31040 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31042;
        if( _1 != _31042 ){
            DeRef(_1);
        }
        _31042 = NOVALUE;
        _31038 = NOVALUE;

        /** fwdref.e:398			end for*/
        _0 = _i_63250;
        if (IS_ATOM_INT(_i_63250)) {
            _i_63250 = _i_63250 + 1;
            if ((object)((uintptr_t)_i_63250 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63250 = NewDouble((eudouble)_i_63250);
            }
        }
        else {
            _i_63250 = binary_op_a(PLUS, _i_63250, 1);
        }
        DeRef(_0);
        goto L14; // [1189] 1148
L15: 
        ;
        DeRef(_i_63250);
    }
    goto L16; // [1194] 1280
L13: 

    /** fwdref.e:400			for i = pre_refs + 1 to length( active_references[fr[FR_FILE]][ar_sp] ) do*/
    _31043 = _pre_refs_63156 + 1;
    if (_31043 > MAXINT){
        _31043 = NewDouble((eudouble)_31043);
    }
    _2 = (object)SEQ_PTR(_fr_62999);
    _31044 = (object)*(((s1_ptr)_2)->base + 3);
    _2 = (object)SEQ_PTR(_44active_references_62771);
    if (!IS_ATOM_INT(_31044)){
        _31045 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31044)->dbl));
    }
    else{
        _31045 = (object)*(((s1_ptr)_2)->base + _31044);
    }
    _2 = (object)SEQ_PTR(_31045);
    _31046 = (object)*(((s1_ptr)_2)->base + _ar_sp_63152);
    _31045 = NOVALUE;
    if (IS_SEQUENCE(_31046)){
            _31047 = SEQ_PTR(_31046)->length;
    }
    else {
        _31047 = 1;
    }
    _31046 = NOVALUE;
    {
        object _i_63265;
        Ref(_31043);
        _i_63265 = _31043;
L17: 
        if (binary_op_a(GREATER, _i_63265, _31047)){
            goto L18; // [1222] 1279
        }

        /** fwdref.e:401				forward_references[active_references[fr[FR_FILE]][ar_sp][i]][FR_PC] += pc - 1*/
        _2 = (object)SEQ_PTR(_fr_62999);
        _31048 = (object)*(((s1_ptr)_2)->base + 3);
        _2 = (object)SEQ_PTR(_44active_references_62771);
        if (!IS_ATOM_INT(_31048)){
            _31049 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31048)->dbl));
        }
        else{
            _31049 = (object)*(((s1_ptr)_2)->base + _31048);
        }
        _2 = (object)SEQ_PTR(_31049);
        _31050 = (object)*(((s1_ptr)_2)->base + _ar_sp_63152);
        _31049 = NOVALUE;
        _2 = (object)SEQ_PTR(_31050);
        if (!IS_ATOM_INT(_i_63265)){
            _31051 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63265)->dbl));
        }
        else{
            _31051 = (object)*(((s1_ptr)_2)->base + _i_63265);
        }
        _31050 = NOVALUE;
        _2 = (object)SEQ_PTR(_44forward_references_62769);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_62769 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31051))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31051)->dbl));
        else
        _3 = (object)(_31051 + ((s1_ptr)_2)->base);
        _31054 = _pc_63058 - 1;
        if ((object)((uintptr_t)_31054 +(uintptr_t) HIGH_BITS) >= 0){
            _31054 = NewDouble((eudouble)_31054);
        }
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _31055 = (object)*(((s1_ptr)_2)->base + 5);
        _31052 = NOVALUE;
        if (IS_ATOM_INT(_31055) && IS_ATOM_INT(_31054)) {
            _31056 = _31055 + _31054;
            if ((object)((uintptr_t)_31056 + (uintptr_t)HIGH_BITS) >= 0){
                _31056 = NewDouble((eudouble)_31056);
            }
        }
        else {
            _31056 = binary_op(PLUS, _31055, _31054);
        }
        _31055 = NOVALUE;
        DeRef(_31054);
        _31054 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31056;
        if( _1 != _31056 ){
            DeRef(_1);
        }
        _31056 = NOVALUE;
        _31052 = NOVALUE;

        /** fwdref.e:402			end for*/
        _0 = _i_63265;
        if (IS_ATOM_INT(_i_63265)) {
            _i_63265 = _i_63265 + 1;
            if ((object)((uintptr_t)_i_63265 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63265 = NewDouble((eudouble)_i_63265);
            }
        }
        else {
            _i_63265 = binary_op_a(PLUS, _i_63265, 1);
        }
        DeRef(_0);
        goto L17; // [1274] 1229
L18: 
        ;
        DeRef(_i_63265);
    }
L16: 

    /** fwdref.e:405		reset_code()*/
    _44reset_code();

    /** fwdref.e:408		resolved_reference( ref )*/
    _44resolved_reference(_ref_62998);

    /** fwdref.e:409	end procedure*/
    DeRef(_tok_62997);
    DeRef(_fr_62999);
    DeRef(_code_63054);
    DeRef(_name_63064);
    DeRef(_params_63145);
    DeRef(_orig_code_63147);
    DeRef(_orig_linetable_63148);
    DeRef(_old_fwd_params_63171);
    DeRef(_new_code_63216);
    _31037 = NOVALUE;
    _30992 = NOVALUE;
    DeRef(_31003);
    _31003 = NOVALUE;
    _31051 = NOVALUE;
    DeRef(_30994);
    _30994 = NOVALUE;
    _31048 = NOVALUE;
    _31033 = NOVALUE;
    _31035 = NOVALUE;
    DeRef(_30942);
    _30942 = NOVALUE;
    DeRef(_30946);
    _30946 = NOVALUE;
    _30987 = NOVALUE;
    DeRef(_31031);
    _31031 = NOVALUE;
    _31046 = NOVALUE;
    DeRef(_30978);
    _30978 = NOVALUE;
    _31032 = NOVALUE;
    DeRef(_31000);
    _31000 = NOVALUE;
    DeRef(_30996);
    _30996 = NOVALUE;
    DeRef(_30968);
    _30968 = NOVALUE;
    DeRef(_31043);
    _31043 = NOVALUE;
    DeRef(_30966);
    _30966 = NOVALUE;
    _31044 = NOVALUE;
    return;
    ;
}


void _44set_error_info(object _ref_63282)
{
    object _fr_63283 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:412		sequence fr = forward_references[ref]*/
    DeRef(_fr_63283);
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    _fr_63283 = (object)*(((s1_ptr)_2)->base + _ref_63282);
    Ref(_fr_63283);

    /** fwdref.e:413		ThisLine        = fr[FR_THISLINE]*/
    DeRef(_50ThisLine_49238);
    _2 = (object)SEQ_PTR(_fr_63283);
    _50ThisLine_49238 = (object)*(((s1_ptr)_2)->base + 7);
    Ref(_50ThisLine_49238);

    /** fwdref.e:414		bp              = fr[FR_BP]*/
    _2 = (object)SEQ_PTR(_fr_63283);
    _50bp_49242 = (object)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_50bp_49242)){
        _50bp_49242 = (object)DBL_PTR(_50bp_49242)->dbl;
    }

    /** fwdref.e:415		line_number     = fr[FR_LINE]*/
    _2 = (object)SEQ_PTR(_fr_63283);
    _36line_number_21448 = (object)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_36line_number_21448)){
        _36line_number_21448 = (object)DBL_PTR(_36line_number_21448)->dbl;
    }

    /** fwdref.e:416		current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63283);
    _36current_file_no_21447 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_36current_file_no_21447)){
        _36current_file_no_21447 = (object)DBL_PTR(_36current_file_no_21447)->dbl;
    }

    /** fwdref.e:417	end procedure*/
    DeRefDS(_fr_63283);
    return;
    ;
}


void _44patch_forward_variable(object _tok_63296, object _ref_63297)
{
    object _fr_63298 = NOVALUE;
    object _sym_63301 = NOVALUE;
    object _pc_63354 = NOVALUE;
    object _vx_63358 = NOVALUE;
    object _d_63375 = NOVALUE;
    object _param_63385 = NOVALUE;
    object _old_63388 = NOVALUE;
    object _new_63393 = NOVALUE;
    object _31113 = NOVALUE;
    object _31112 = NOVALUE;
    object _31111 = NOVALUE;
    object _31109 = NOVALUE;
    object _31106 = NOVALUE;
    object _31104 = NOVALUE;
    object _31103 = NOVALUE;
    object _31102 = NOVALUE;
    object _31101 = NOVALUE;
    object _31099 = NOVALUE;
    object _31098 = NOVALUE;
    object _31097 = NOVALUE;
    object _31096 = NOVALUE;
    object _31095 = NOVALUE;
    object _31093 = NOVALUE;
    object _31091 = NOVALUE;
    object _31088 = NOVALUE;
    object _31087 = NOVALUE;
    object _31086 = NOVALUE;
    object _31084 = NOVALUE;
    object _31083 = NOVALUE;
    object _31082 = NOVALUE;
    object _31081 = NOVALUE;
    object _31079 = NOVALUE;
    object _31077 = NOVALUE;
    object _31076 = NOVALUE;
    object _31075 = NOVALUE;
    object _31074 = NOVALUE;
    object _31073 = NOVALUE;
    object _31072 = NOVALUE;
    object _31071 = NOVALUE;
    object _31070 = NOVALUE;
    object _31069 = NOVALUE;
    object _31068 = NOVALUE;
    object _31067 = NOVALUE;
    object _31066 = NOVALUE;
    object _31065 = NOVALUE;
    object _31064 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:421		sequence fr = forward_references[ref]*/
    DeRef(_fr_63298);
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    _fr_63298 = (object)*(((s1_ptr)_2)->base + _ref_63297);
    Ref(_fr_63298);

    /** fwdref.e:422		symtab_index sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63296);
    _sym_63301 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_63301)){
        _sym_63301 = (object)DBL_PTR(_sym_63301)->dbl;
    }

    /** fwdref.e:424		if SymTab[sym][S_FILE_NO] = fr[FR_FILE] */
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31064 = (object)*(((s1_ptr)_2)->base + _sym_63301);
    _2 = (object)SEQ_PTR(_31064);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _31065 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _31065 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _31064 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63298);
    _31066 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_31065) && IS_ATOM_INT(_31066)) {
        _31067 = (_31065 == _31066);
    }
    else {
        _31067 = binary_op(EQUALS, _31065, _31066);
    }
    _31065 = NOVALUE;
    _31066 = NOVALUE;
    if (IS_ATOM_INT(_31067)) {
        if (_31067 == 0) {
            goto L1; // [45] 69
        }
    }
    else {
        if (DBL_PTR(_31067)->dbl == 0.0) {
            goto L1; // [45] 69
        }
    }
    _2 = (object)SEQ_PTR(_fr_63298);
    _31069 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_31069)) {
        _31070 = (_31069 == _36TopLevelSub_21454);
    }
    else {
        _31070 = binary_op(EQUALS, _31069, _36TopLevelSub_21454);
    }
    _31069 = NOVALUE;
    if (_31070 == 0) {
        DeRef(_31070);
        _31070 = NOVALUE;
        goto L1; // [60] 69
    }
    else {
        if (!IS_ATOM_INT(_31070) && DBL_PTR(_31070)->dbl == 0.0){
            DeRef(_31070);
            _31070 = NOVALUE;
            goto L1; // [60] 69
        }
        DeRef(_31070);
        _31070 = NOVALUE;
    }
    DeRef(_31070);
    _31070 = NOVALUE;

    /** fwdref.e:426			return*/
    DeRef(_tok_63296);
    DeRef(_fr_63298);
    DeRef(_31067);
    _31067 = NOVALUE;
    return;
L1: 

    /** fwdref.e:429		if fr[FR_OP] = ASSIGN and SymTab[sym][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_fr_63298);
    _31071 = (object)*(((s1_ptr)_2)->base + 10);
    if (IS_ATOM_INT(_31071)) {
        _31072 = (_31071 == 18);
    }
    else {
        _31072 = binary_op(EQUALS, _31071, 18);
    }
    _31071 = NOVALUE;
    if (IS_ATOM_INT(_31072)) {
        if (_31072 == 0) {
            goto L2; // [81] 122
        }
    }
    else {
        if (DBL_PTR(_31072)->dbl == 0.0) {
            goto L2; // [81] 122
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31074 = (object)*(((s1_ptr)_2)->base + _sym_63301);
    _2 = (object)SEQ_PTR(_31074);
    _31075 = (object)*(((s1_ptr)_2)->base + 3);
    _31074 = NOVALUE;
    if (IS_ATOM_INT(_31075)) {
        _31076 = (_31075 == 2);
    }
    else {
        _31076 = binary_op(EQUALS, _31075, 2);
    }
    _31075 = NOVALUE;
    if (_31076 == 0) {
        DeRef(_31076);
        _31076 = NOVALUE;
        goto L2; // [104] 122
    }
    else {
        if (!IS_ATOM_INT(_31076) && DBL_PTR(_31076)->dbl == 0.0){
            DeRef(_31076);
            _31076 = NOVALUE;
            goto L2; // [104] 122
        }
        DeRef(_31076);
        _31076 = NOVALUE;
    }
    DeRef(_31076);
    _31076 = NOVALUE;

    /** fwdref.e:430			prep_forward_error( ref )*/
    _44prep_forward_error(_ref_63297);

    /** fwdref.e:431			CompileErr( MAY_NOT_CHANGE_THE_VALUE_OF_A_CONSTANT)*/
    RefDS(_21997);
    _50CompileErr(110, _21997, 0);
L2: 

    /** fwdref.e:434		if fr[FR_OP] = ASSIGN then*/
    _2 = (object)SEQ_PTR(_fr_63298);
    _31077 = (object)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _31077, 18)){
        _31077 = NOVALUE;
        goto L3; // [130] 170
    }
    _31077 = NOVALUE;

    /** fwdref.e:435			SymTab[sym][S_USAGE] = or_bits( U_WRITTEN, SymTab[sym][S_USAGE] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_63301 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31081 = (object)*(((s1_ptr)_2)->base + _sym_63301);
    _2 = (object)SEQ_PTR(_31081);
    _31082 = (object)*(((s1_ptr)_2)->base + 5);
    _31081 = NOVALUE;
    if (IS_ATOM_INT(_31082)) {
        {uintptr_t tu;
             tu = (uintptr_t)2 | (uintptr_t)_31082;
             _31083 = MAKE_UINT(tu);
        }
    }
    else {
        _31083 = binary_op(OR_BITS, 2, _31082);
    }
    _31082 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31083;
    if( _1 != _31083 ){
        DeRef(_1);
    }
    _31083 = NOVALUE;
    _31079 = NOVALUE;
    goto L4; // [167] 204
L3: 

    /** fwdref.e:437			SymTab[sym][S_USAGE] = or_bits( U_READ, SymTab[sym][S_USAGE] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_63301 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31086 = (object)*(((s1_ptr)_2)->base + _sym_63301);
    _2 = (object)SEQ_PTR(_31086);
    _31087 = (object)*(((s1_ptr)_2)->base + 5);
    _31086 = NOVALUE;
    if (IS_ATOM_INT(_31087)) {
        {uintptr_t tu;
             tu = (uintptr_t)1 | (uintptr_t)_31087;
             _31088 = MAKE_UINT(tu);
        }
    }
    else {
        _31088 = binary_op(OR_BITS, 1, _31087);
    }
    _31087 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31088;
    if( _1 != _31088 ){
        DeRef(_1);
    }
    _31088 = NOVALUE;
    _31084 = NOVALUE;
L4: 

    /** fwdref.e:440		set_code( ref )*/
    _44set_code(_ref_63297);

    /** fwdref.e:441		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_63298);
    _pc_63354 = (object)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_63354))
    _pc_63354 = (object)DBL_PTR(_pc_63354)->dbl;

    /** fwdref.e:442		if pc < 1 then*/
    if (_pc_63354 >= 1)
    goto L5; // [217] 227

    /** fwdref.e:443			pc = 1*/
    _pc_63354 = 1;
L5: 

    /** fwdref.e:445		integer vx = find( -ref, Code, pc )*/
    if ((uintptr_t)_ref_63297 == (uintptr_t)HIGH_BITS){
        _31091 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31091 = - _ref_63297;
    }
    _vx_63358 = find_from(_31091, _36Code_21539, _pc_63354);
    DeRef(_31091);
    _31091 = NOVALUE;

    /** fwdref.e:446		if vx then*/
    if (_vx_63358 == 0)
    {
        goto L6; // [241] 283
    }
    else{
    }

    /** fwdref.e:447			while vx do*/
L7: 
    if (_vx_63358 == 0)
    {
        goto L8; // [249] 277
    }
    else{
    }

    /** fwdref.e:450				Code[vx] = sym*/
    _2 = (object)SEQ_PTR(_36Code_21539);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21539 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _vx_63358);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_63301;
    DeRef(_1);

    /** fwdref.e:451				vx = find( -ref, Code, vx )*/
    if ((uintptr_t)_ref_63297 == (uintptr_t)HIGH_BITS){
        _31093 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31093 = - _ref_63297;
    }
    _vx_63358 = find_from(_31093, _36Code_21539, _vx_63358);
    DeRef(_31093);
    _31093 = NOVALUE;

    /** fwdref.e:452			end while*/
    goto L7; // [274] 249
L8: 

    /** fwdref.e:453			resolved_reference( ref )*/
    _44resolved_reference(_ref_63297);
L6: 

    /** fwdref.e:456		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_63298);
    _31095 = (object)*(((s1_ptr)_2)->base + 12);
    _31096 = IS_SEQUENCE(_31095);
    _31095 = NOVALUE;
    if (_31096 == 0)
    {
        _31096 = NOVALUE;
        goto L9; // [292] 424
    }
    else{
        _31096 = NOVALUE;
    }

    /** fwdref.e:457			for i = 1 to length( fr[FR_DATA] ) do*/
    _2 = (object)SEQ_PTR(_fr_63298);
    _31097 = (object)*(((s1_ptr)_2)->base + 12);
    if (IS_SEQUENCE(_31097)){
            _31098 = SEQ_PTR(_31097)->length;
    }
    else {
        _31098 = 1;
    }
    _31097 = NOVALUE;
    {
        object _i_63372;
        _i_63372 = 1;
LA: 
        if (_i_63372 > _31098){
            goto LB; // [304] 418
        }

        /** fwdref.e:458				object d = fr[FR_DATA][i]*/
        _2 = (object)SEQ_PTR(_fr_63298);
        _31099 = (object)*(((s1_ptr)_2)->base + 12);
        DeRef(_d_63375);
        _2 = (object)SEQ_PTR(_31099);
        _d_63375 = (object)*(((s1_ptr)_2)->base + _i_63372);
        Ref(_d_63375);
        _31099 = NOVALUE;

        /** fwdref.e:459				if sequence( d ) and d[1] = PAM_RECORD then*/
        _31101 = IS_SEQUENCE(_d_63375);
        if (_31101 == 0) {
            goto LC; // [326] 407
        }
        _2 = (object)SEQ_PTR(_d_63375);
        _31103 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31103)) {
            _31104 = (_31103 == 1);
        }
        else {
            _31104 = binary_op(EQUALS, _31103, 1);
        }
        _31103 = NOVALUE;
        if (_31104 == 0) {
            DeRef(_31104);
            _31104 = NOVALUE;
            goto LC; // [341] 407
        }
        else {
            if (!IS_ATOM_INT(_31104) && DBL_PTR(_31104)->dbl == 0.0){
                DeRef(_31104);
                _31104 = NOVALUE;
                goto LC; // [341] 407
            }
            DeRef(_31104);
            _31104 = NOVALUE;
        }
        DeRef(_31104);
        _31104 = NOVALUE;

        /** fwdref.e:461					symtab_index param = d[2]*/
        _2 = (object)SEQ_PTR(_d_63375);
        _param_63385 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_63385)){
            _param_63385 = (object)DBL_PTR(_param_63385)->dbl;
        }

        /** fwdref.e:462					token old = {RECORDED, d[3]}*/
        _2 = (object)SEQ_PTR(_d_63375);
        _31106 = (object)*(((s1_ptr)_2)->base + 3);
        Ref(_31106);
        DeRef(_old_63388);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 508;
        ((intptr_t *)_2)[2] = _31106;
        _old_63388 = MAKE_SEQ(_1);
        _31106 = NOVALUE;

        /** fwdref.e:463					token new = {VARIABLE, sym}*/
        DeRefi(_new_63393);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -100;
        ((intptr_t *)_2)[2] = _sym_63301;
        _new_63393 = MAKE_SEQ(_1);

        /** fwdref.e:464					SymTab[param][S_CODE] = find_replace( old, SymTab[param][S_CODE], new )*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_param_63385 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _31111 = (object)*(((s1_ptr)_2)->base + _param_63385);
        _2 = (object)SEQ_PTR(_31111);
        if (!IS_ATOM_INT(_36S_CODE_21096)){
            _31112 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21096)->dbl));
        }
        else{
            _31112 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21096);
        }
        _31111 = NOVALUE;
        RefDS(_old_63388);
        Ref(_31112);
        RefDS(_new_63393);
        _31113 = _16find_replace(_old_63388, _31112, _new_63393, 0);
        _31112 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_36S_CODE_21096))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21096)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21096);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31113;
        if( _1 != _31113 ){
            DeRef(_1);
        }
        _31113 = NOVALUE;
        _31109 = NOVALUE;
LC: 
        DeRef(_old_63388);
        _old_63388 = NOVALUE;
        DeRefi(_new_63393);
        _new_63393 = NOVALUE;
        DeRef(_d_63375);
        _d_63375 = NOVALUE;

        /** fwdref.e:466			end for*/
        _i_63372 = _i_63372 + 1;
        goto LA; // [413] 311
LB: 
        ;
    }

    /** fwdref.e:467			resolved_reference( ref )*/
    _44resolved_reference(_ref_63297);
L9: 

    /** fwdref.e:469		reset_code()*/
    _44reset_code();

    /** fwdref.e:470	end procedure*/
    DeRef(_tok_63296);
    DeRef(_fr_63298);
    _31097 = NOVALUE;
    DeRef(_31072);
    _31072 = NOVALUE;
    DeRef(_31067);
    _31067 = NOVALUE;
    return;
    ;
}


void _44patch_forward_init_check(object _tok_63409, object _ref_63410)
{
    object _fr_63411 = NOVALUE;
    object _31121 = NOVALUE;
    object _31120 = NOVALUE;
    object _31119 = NOVALUE;
    object _31117 = NOVALUE;
    object _31116 = NOVALUE;
    object _31115 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:474		sequence fr = forward_references[ref]*/
    DeRef(_fr_63411);
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    _fr_63411 = (object)*(((s1_ptr)_2)->base + _ref_63410);
    Ref(_fr_63411);

    /** fwdref.e:475		set_code( ref )*/
    _44set_code(_ref_63410);

    /** fwdref.e:476		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_63411);
    _31115 = (object)*(((s1_ptr)_2)->base + 12);
    _31116 = IS_SEQUENCE(_31115);
    _31115 = NOVALUE;
    if (_31116 == 0)
    {
        _31116 = NOVALUE;
        goto L1; // [27] 38
    }
    else{
        _31116 = NOVALUE;
    }

    /** fwdref.e:478			resolved_reference( ref )*/
    _44resolved_reference(_ref_63410);
    goto L2; // [35] 85
L1: 

    /** fwdref.e:479		elsif fr[FR_PC] > 0 then*/
    _2 = (object)SEQ_PTR(_fr_63411);
    _31117 = (object)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(LESSEQ, _31117, 0)){
        _31117 = NOVALUE;
        goto L3; // [44] 78
    }
    _31117 = NOVALUE;

    /** fwdref.e:480			Code[fr[FR_PC]+1] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_fr_63411);
    _31119 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_31119)) {
        _31120 = _31119 + 1;
        if (_31120 > MAXINT){
            _31120 = NewDouble((eudouble)_31120);
        }
    }
    else
    _31120 = binary_op(PLUS, 1, _31119);
    _31119 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_63409);
    _31121 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_31121);
    _2 = (object)SEQ_PTR(_36Code_21539);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21539 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_31120))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31120)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _31120);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31121;
    if( _1 != _31121 ){
        DeRef(_1);
    }
    _31121 = NOVALUE;

    /** fwdref.e:481			resolved_reference( ref )*/
    _44resolved_reference(_ref_63410);
    goto L2; // [75] 85
L3: 

    /** fwdref.e:483			forward_error( tok, ref )*/
    Ref(_tok_63409);
    _44forward_error(_tok_63409, _ref_63410);
L2: 

    /** fwdref.e:485		reset_code()*/
    _44reset_code();

    /** fwdref.e:486	end procedure*/
    DeRef(_tok_63409);
    DeRef(_fr_63411);
    DeRef(_31120);
    _31120 = NOVALUE;
    return;
    ;
}


object _44expected_name(object _id_63428)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_63428)) {
        _1 = (object)(DBL_PTR(_id_63428)->dbl);
        DeRefDS(_id_63428);
        _id_63428 = _1;
    }

    /** fwdref.e:491		switch id with fallthru do*/
    _0 = _id_63428;
    switch ( _0 ){ 

        /** fwdref.e:492			case PROC then*/
        case 27:
        case 195:

        /** fwdref.e:494				return "a procedure"*/
        RefDS(_26248);
        return _26248;

        /** fwdref.e:496			case FUNC then*/
        case 501:
        case 196:

        /** fwdref.e:498				return "a function"*/
        RefDS(_26194);
        return _26194;

        /** fwdref.e:500			case VARIABLE then*/
        case -100:

        /** fwdref.e:501				return "a variable, constant or enum"*/
        RefDS(_31124);
        return _31124;

        /** fwdref.e:502			case else*/
        default:

        /** fwdref.e:503				return "something"*/
        RefDS(_31125);
        return _31125;
    ;}    ;
}


void _44patch_forward_type(object _tok_63445, object _ref_63446)
{
    object _fr_63447 = NOVALUE;
    object _syms_63449 = NOVALUE;
    object _31137 = NOVALUE;
    object _31136 = NOVALUE;
    object _31134 = NOVALUE;
    object _31133 = NOVALUE;
    object _31132 = NOVALUE;
    object _31130 = NOVALUE;
    object _31129 = NOVALUE;
    object _31128 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:510		sequence fr = forward_references[ref]*/
    DeRef(_fr_63447);
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    _fr_63447 = (object)*(((s1_ptr)_2)->base + _ref_63446);
    Ref(_fr_63447);

    /** fwdref.e:511		sequence syms = fr[FR_DATA]*/
    DeRef(_syms_63449);
    _2 = (object)SEQ_PTR(_fr_63447);
    _syms_63449 = (object)*(((s1_ptr)_2)->base + 12);
    Ref(_syms_63449);

    /** fwdref.e:512		for i = 2 to length( syms ) do*/
    if (IS_SEQUENCE(_syms_63449)){
            _31128 = SEQ_PTR(_syms_63449)->length;
    }
    else {
        _31128 = 1;
    }
    {
        object _i_63452;
        _i_63452 = 2;
L1: 
        if (_i_63452 > _31128){
            goto L2; // [26] 102
        }

        /** fwdref.e:513			SymTab[syms[i]][S_VTYPE] = tok[T_SYM]*/
        _2 = (object)SEQ_PTR(_syms_63449);
        _31129 = (object)*(((s1_ptr)_2)->base + _i_63452);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31129))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31129)->dbl));
        else
        _3 = (object)(_31129 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_tok_63445);
        _31132 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_31132);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 15);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31132;
        if( _1 != _31132 ){
            DeRef(_1);
        }
        _31132 = NOVALUE;
        _31130 = NOVALUE;

        /** fwdref.e:514			if TRANSLATE then*/
        if (_36TRANSLATE_21049 == 0)
        {
            goto L3; // [62] 95
        }
        else{
        }

        /** fwdref.e:515				SymTab[syms[i]][S_GTYPE] = CompileType(tok[T_SYM])*/
        _2 = (object)SEQ_PTR(_syms_63449);
        _31133 = (object)*(((s1_ptr)_2)->base + _i_63452);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31133))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31133)->dbl));
        else
        _3 = (object)(_31133 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_tok_63445);
        _31136 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_31136);
        _31137 = _45CompileType(_31136);
        _31136 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 36);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31137;
        if( _1 != _31137 ){
            DeRef(_1);
        }
        _31137 = NOVALUE;
        _31134 = NOVALUE;
L3: 

        /** fwdref.e:517		end for*/
        _i_63452 = _i_63452 + 1;
        goto L1; // [97] 33
L2: 
        ;
    }

    /** fwdref.e:518		resolved_reference( ref )*/
    _44resolved_reference(_ref_63446);

    /** fwdref.e:519	end procedure*/
    DeRef(_tok_63445);
    DeRef(_fr_63447);
    DeRef(_syms_63449);
    _31133 = NOVALUE;
    _31129 = NOVALUE;
    return;
    ;
}


void _44patch_forward_case(object _tok_63475, object _ref_63476)
{
    object _fr_63477 = NOVALUE;
    object _switch_pc_63479 = NOVALUE;
    object _case_sym_63482 = NOVALUE;
    object _case_values_63511 = NOVALUE;
    object _cx_63516 = NOVALUE;
    object _negative_63524 = NOVALUE;
    object _31175 = NOVALUE;
    object _31174 = NOVALUE;
    object _31173 = NOVALUE;
    object _31172 = NOVALUE;
    object _31171 = NOVALUE;
    object _31170 = NOVALUE;
    object _31168 = NOVALUE;
    object _31166 = NOVALUE;
    object _31165 = NOVALUE;
    object _31163 = NOVALUE;
    object _31162 = NOVALUE;
    object _31159 = NOVALUE;
    object _31157 = NOVALUE;
    object _31156 = NOVALUE;
    object _31155 = NOVALUE;
    object _31154 = NOVALUE;
    object _31153 = NOVALUE;
    object _31152 = NOVALUE;
    object _31151 = NOVALUE;
    object _31150 = NOVALUE;
    object _31149 = NOVALUE;
    object _31147 = NOVALUE;
    object _31146 = NOVALUE;
    object _31145 = NOVALUE;
    object _31144 = NOVALUE;
    object _31142 = NOVALUE;
    object _31140 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:522		sequence fr = forward_references[ref]*/
    DeRef(_fr_63477);
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    _fr_63477 = (object)*(((s1_ptr)_2)->base + _ref_63476);
    Ref(_fr_63477);

    /** fwdref.e:524		integer switch_pc = fr[FR_DATA]*/
    _2 = (object)SEQ_PTR(_fr_63477);
    _switch_pc_63479 = (object)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_switch_pc_63479))
    _switch_pc_63479 = (object)DBL_PTR(_switch_pc_63479)->dbl;

    /** fwdref.e:527		if fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_fr_63477);
    _31140 = (object)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _31140, _36TopLevelSub_21454)){
        _31140 = NOVALUE;
        goto L1; // [27] 48
    }
    _31140 = NOVALUE;

    /** fwdref.e:528			case_sym = Code[switch_pc + 2]*/
    _31142 = _switch_pc_63479 + 2;
    _2 = (object)SEQ_PTR(_36Code_21539);
    _case_sym_63482 = (object)*(((s1_ptr)_2)->base + _31142);
    if (!IS_ATOM_INT(_case_sym_63482)){
        _case_sym_63482 = (object)DBL_PTR(_case_sym_63482)->dbl;
    }
    goto L2; // [45] 77
L1: 

    /** fwdref.e:530			case_sym = SymTab[fr[FR_SUBPROG]][S_CODE][switch_pc + 2]*/
    _2 = (object)SEQ_PTR(_fr_63477);
    _31144 = (object)*(((s1_ptr)_2)->base + 4);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_31144)){
        _31145 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31144)->dbl));
    }
    else{
        _31145 = (object)*(((s1_ptr)_2)->base + _31144);
    }
    _2 = (object)SEQ_PTR(_31145);
    if (!IS_ATOM_INT(_36S_CODE_21096)){
        _31146 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21096)->dbl));
    }
    else{
        _31146 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21096);
    }
    _31145 = NOVALUE;
    _31147 = _switch_pc_63479 + 2;
    _2 = (object)SEQ_PTR(_31146);
    _case_sym_63482 = (object)*(((s1_ptr)_2)->base + _31147);
    if (!IS_ATOM_INT(_case_sym_63482)){
        _case_sym_63482 = (object)DBL_PTR(_case_sym_63482)->dbl;
    }
    _31146 = NOVALUE;
L2: 

    /** fwdref.e:533		if SymTab[tok[T_SYM]][S_FILE_NO] = fr[FR_FILE] and fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_tok_63475);
    _31149 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_31149)){
        _31150 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31149)->dbl));
    }
    else{
        _31150 = (object)*(((s1_ptr)_2)->base + _31149);
    }
    _2 = (object)SEQ_PTR(_31150);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _31151 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _31151 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _31150 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63477);
    _31152 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_31151) && IS_ATOM_INT(_31152)) {
        _31153 = (_31151 == _31152);
    }
    else {
        _31153 = binary_op(EQUALS, _31151, _31152);
    }
    _31151 = NOVALUE;
    _31152 = NOVALUE;
    if (IS_ATOM_INT(_31153)) {
        if (_31153 == 0) {
            goto L3; // [105] 129
        }
    }
    else {
        if (DBL_PTR(_31153)->dbl == 0.0) {
            goto L3; // [105] 129
        }
    }
    _2 = (object)SEQ_PTR(_fr_63477);
    _31155 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_31155)) {
        _31156 = (_31155 == _36TopLevelSub_21454);
    }
    else {
        _31156 = binary_op(EQUALS, _31155, _36TopLevelSub_21454);
    }
    _31155 = NOVALUE;
    if (_31156 == 0) {
        DeRef(_31156);
        _31156 = NOVALUE;
        goto L3; // [120] 129
    }
    else {
        if (!IS_ATOM_INT(_31156) && DBL_PTR(_31156)->dbl == 0.0){
            DeRef(_31156);
            _31156 = NOVALUE;
            goto L3; // [120] 129
        }
        DeRef(_31156);
        _31156 = NOVALUE;
    }
    DeRef(_31156);
    _31156 = NOVALUE;

    /** fwdref.e:534			return*/
    DeRef(_tok_63475);
    DeRef(_fr_63477);
    DeRef(_case_values_63511);
    _31144 = NOVALUE;
    DeRef(_31147);
    _31147 = NOVALUE;
    DeRef(_31142);
    _31142 = NOVALUE;
    DeRef(_31153);
    _31153 = NOVALUE;
    _31149 = NOVALUE;
    return;
L3: 

    /** fwdref.e:537		sequence case_values = SymTab[case_sym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31157 = (object)*(((s1_ptr)_2)->base + _case_sym_63482);
    DeRef(_case_values_63511);
    _2 = (object)SEQ_PTR(_31157);
    _case_values_63511 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_case_values_63511);
    _31157 = NOVALUE;

    /** fwdref.e:539		integer cx = find( { ref }, case_values )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ref_63476;
    _31159 = MAKE_SEQ(_1);
    _cx_63516 = find_from(_31159, _case_values_63511, 1);
    DeRefDS(_31159);
    _31159 = NOVALUE;

    /** fwdref.e:540		if not cx then*/
    if (_cx_63516 != 0)
    goto L4; // [160] 178

    /** fwdref.e:541			cx = find( { -ref }, case_values )*/
    if ((uintptr_t)_ref_63476 == (uintptr_t)HIGH_BITS){
        _31162 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31162 = - _ref_63476;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31162;
    _31163 = MAKE_SEQ(_1);
    _31162 = NOVALUE;
    _cx_63516 = find_from(_31163, _case_values_63511, 1);
    DeRefDS(_31163);
    _31163 = NOVALUE;
L4: 

    /** fwdref.e:544	 	ifdef DEBUG then	*/

    /** fwdref.e:551		integer negative = 0*/
    _negative_63524 = 0;

    /** fwdref.e:552		if case_values[cx][1] < 0 then*/
    _2 = (object)SEQ_PTR(_case_values_63511);
    _31165 = (object)*(((s1_ptr)_2)->base + _cx_63516);
    _2 = (object)SEQ_PTR(_31165);
    _31166 = (object)*(((s1_ptr)_2)->base + 1);
    _31165 = NOVALUE;
    if (binary_op_a(GREATEREQ, _31166, 0)){
        _31166 = NOVALUE;
        goto L5; // [195] 224
    }
    _31166 = NOVALUE;

    /** fwdref.e:553			negative = 1*/
    _negative_63524 = 1;

    /** fwdref.e:554			case_values[cx][1] *= -1*/
    _2 = (object)SEQ_PTR(_case_values_63511);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_63511 = MAKE_SEQ(_2);
    }
    _3 = (object)(_cx_63516 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31170 = (object)*(((s1_ptr)_2)->base + 1);
    _31168 = NOVALUE;
    if (IS_ATOM_INT(_31170)) {
        if (_31170 == (short)_31170){
            _31171 = _31170 * -1;
        }
        else{
            _31171 = NewDouble(_31170 * (eudouble)-1);
        }
    }
    else {
        _31171 = binary_op(MULTIPLY, _31170, -1);
    }
    _31170 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31171;
    if( _1 != _31171 ){
        DeRef(_1);
    }
    _31171 = NOVALUE;
    _31168 = NOVALUE;
L5: 

    /** fwdref.e:557		if negative then*/
    if (_negative_63524 == 0)
    {
        goto L6; // [226] 247
    }
    else{
    }

    /** fwdref.e:558			case_values[cx] = - tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63475);
    _31172 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_31172)) {
        if ((uintptr_t)_31172 == (uintptr_t)HIGH_BITS){
            _31173 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _31173 = - _31172;
        }
    }
    else {
        _31173 = unary_op(UMINUS, _31172);
    }
    _31172 = NOVALUE;
    _2 = (object)SEQ_PTR(_case_values_63511);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_63511 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _cx_63516);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31173;
    if( _1 != _31173 ){
        DeRef(_1);
    }
    _31173 = NOVALUE;
    goto L7; // [244] 260
L6: 

    /** fwdref.e:560			case_values[cx] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63475);
    _31174 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_31174);
    _2 = (object)SEQ_PTR(_case_values_63511);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_63511 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _cx_63516);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31174;
    if( _1 != _31174 ){
        DeRef(_1);
    }
    _31174 = NOVALUE;
L7: 

    /** fwdref.e:562		SymTab[case_sym][S_OBJ] = case_values*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_case_sym_63482 + ((s1_ptr)_2)->base);
    RefDS(_case_values_63511);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _case_values_63511;
    DeRef(_1);
    _31175 = NOVALUE;

    /** fwdref.e:563		resolved_reference( ref )*/
    _44resolved_reference(_ref_63476);

    /** fwdref.e:564	end procedure*/
    DeRef(_tok_63475);
    DeRef(_fr_63477);
    DeRefDS(_case_values_63511);
    _31144 = NOVALUE;
    DeRef(_31147);
    _31147 = NOVALUE;
    DeRef(_31142);
    _31142 = NOVALUE;
    DeRef(_31153);
    _31153 = NOVALUE;
    _31149 = NOVALUE;
    return;
    ;
}


void _44patch_forward_type_check(object _tok_63547, object _ref_63548)
{
    object _fr_63549 = NOVALUE;
    object _which_type_63552 = NOVALUE;
    object _var_63554 = NOVALUE;
    object _pc_63587 = NOVALUE;
    object _with_type_check_63589 = NOVALUE;
    object _c_63619 = NOVALUE;
    object _subprog_inlined_insert_code_at_332_63628 = NOVALUE;
    object _code_inlined_insert_code_at_329_63627 = NOVALUE;
    object _subprog_inlined_insert_code_at_415_63644 = NOVALUE;
    object _code_inlined_insert_code_at_412_63643 = NOVALUE;
    object _subprog_inlined_insert_code_at_477_63654 = NOVALUE;
    object _code_inlined_insert_code_at_474_63653 = NOVALUE;
    object _subprog_inlined_insert_code_at_539_63664 = NOVALUE;
    object _code_inlined_insert_code_at_536_63663 = NOVALUE;
    object _start_pc_63671 = NOVALUE;
    object _subprog_inlined_insert_code_at_647_63688 = NOVALUE;
    object _code_inlined_insert_code_at_644_63687 = NOVALUE;
    object _c_63691 = NOVALUE;
    object _subprog_inlined_insert_code_at_741_63707 = NOVALUE;
    object _code_inlined_insert_code_at_738_63706 = NOVALUE;
    object _start_pc_63718 = NOVALUE;
    object _subprog_inlined_insert_code_at_886_63738 = NOVALUE;
    object _code_inlined_insert_code_at_883_63737 = NOVALUE;
    object _subprog_inlined_insert_code_at_987_63759 = NOVALUE;
    object _code_inlined_insert_code_at_984_63758 = NOVALUE;
    object _31265 = NOVALUE;
    object _31264 = NOVALUE;
    object _31263 = NOVALUE;
    object _31262 = NOVALUE;
    object _31261 = NOVALUE;
    object _31260 = NOVALUE;
    object _31259 = NOVALUE;
    object _31257 = NOVALUE;
    object _31255 = NOVALUE;
    object _31254 = NOVALUE;
    object _31253 = NOVALUE;
    object _31252 = NOVALUE;
    object _31251 = NOVALUE;
    object _31250 = NOVALUE;
    object _31249 = NOVALUE;
    object _31247 = NOVALUE;
    object _31246 = NOVALUE;
    object _31245 = NOVALUE;
    object _31244 = NOVALUE;
    object _31243 = NOVALUE;
    object _31242 = NOVALUE;
    object _31240 = NOVALUE;
    object _31239 = NOVALUE;
    object _31238 = NOVALUE;
    object _31237 = NOVALUE;
    object _31235 = NOVALUE;
    object _31234 = NOVALUE;
    object _31231 = NOVALUE;
    object _31230 = NOVALUE;
    object _31228 = NOVALUE;
    object _31227 = NOVALUE;
    object _31226 = NOVALUE;
    object _31225 = NOVALUE;
    object _31224 = NOVALUE;
    object _31223 = NOVALUE;
    object _31221 = NOVALUE;
    object _31220 = NOVALUE;
    object _31217 = NOVALUE;
    object _31216 = NOVALUE;
    object _31213 = NOVALUE;
    object _31212 = NOVALUE;
    object _31208 = NOVALUE;
    object _31207 = NOVALUE;
    object _31205 = NOVALUE;
    object _31204 = NOVALUE;
    object _31202 = NOVALUE;
    object _31201 = NOVALUE;
    object _31198 = NOVALUE;
    object _31195 = NOVALUE;
    object _31193 = NOVALUE;
    object _31190 = NOVALUE;
    object _31189 = NOVALUE;
    object _31186 = NOVALUE;
    object _31181 = NOVALUE;
    object _31180 = NOVALUE;
    object _31178 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:568		sequence fr = forward_references[ref]*/
    DeRef(_fr_63549);
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    _fr_63549 = (object)*(((s1_ptr)_2)->base + _ref_63548);
    Ref(_fr_63549);

    /** fwdref.e:572		if fr[FR_OP] = TYPE_CHECK_FORWARD then*/
    _2 = (object)SEQ_PTR(_fr_63549);
    _31178 = (object)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _31178, 197)){
        _31178 = NOVALUE;
        goto L1; // [21] 86
    }
    _31178 = NOVALUE;

    /** fwdref.e:573			which_type = SymTab[tok[T_SYM]][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_tok_63547);
    _31180 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_31180)){
        _31181 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31180)->dbl));
    }
    else{
        _31181 = (object)*(((s1_ptr)_2)->base + _31180);
    }
    _2 = (object)SEQ_PTR(_31181);
    _which_type_63552 = (object)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_which_type_63552)){
        _which_type_63552 = (object)DBL_PTR(_which_type_63552)->dbl;
    }
    _31181 = NOVALUE;

    /** fwdref.e:574			if not which_type then*/
    if (_which_type_63552 != 0)
    goto L2; // [49] 72

    /** fwdref.e:575				which_type = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63547);
    _which_type_63552 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_which_type_63552)){
        _which_type_63552 = (object)DBL_PTR(_which_type_63552)->dbl;
    }

    /** fwdref.e:576				var = 0*/
    _var_63554 = 0;
    goto L3; // [69] 144
L2: 

    /** fwdref.e:578				var = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63547);
    _var_63554 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_var_63554)){
        _var_63554 = (object)DBL_PTR(_var_63554)->dbl;
    }
    goto L3; // [83] 144
L1: 

    /** fwdref.e:582		elsif fr[FR_OP] = TYPE then*/
    _2 = (object)SEQ_PTR(_fr_63549);
    _31186 = (object)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _31186, 504)){
        _31186 = NOVALUE;
        goto L4; // [94] 118
    }
    _31186 = NOVALUE;

    /** fwdref.e:583			which_type = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63547);
    _which_type_63552 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_which_type_63552)){
        _which_type_63552 = (object)DBL_PTR(_which_type_63552)->dbl;
    }

    /** fwdref.e:584			var = 0*/
    _var_63554 = 0;
    goto L3; // [115] 144
L4: 

    /** fwdref.e:587			prep_forward_error( ref )*/
    _44prep_forward_error(_ref_63548);

    /** fwdref.e:588			InternalErr( 262, { TYPE_CHECK, TYPE_CHECK_FORWARD, fr[FR_OP] })*/
    _2 = (object)SEQ_PTR(_fr_63549);
    _31189 = (object)*(((s1_ptr)_2)->base + 10);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 65;
    ((intptr_t*)_2)[2] = 197;
    Ref(_31189);
    ((intptr_t*)_2)[3] = _31189;
    _31190 = MAKE_SEQ(_1);
    _31189 = NOVALUE;
    _50InternalErr(262, _31190);
    _31190 = NOVALUE;
L3: 

    /** fwdref.e:591		if which_type < 0 then*/
    if (_which_type_63552 >= 0)
    goto L5; // [148] 158

    /** fwdref.e:593			return*/
    DeRef(_tok_63547);
    DeRef(_fr_63549);
    _31180 = NOVALUE;
    return;
L5: 

    /** fwdref.e:596		set_code( ref )*/
    _44set_code(_ref_63548);

    /** fwdref.e:598		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_63549);
    _pc_63587 = (object)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_63587))
    _pc_63587 = (object)DBL_PTR(_pc_63587)->dbl;

    /** fwdref.e:599		integer with_type_check = Code[pc + 2]*/
    _31193 = _pc_63587 + 2;
    _2 = (object)SEQ_PTR(_36Code_21539);
    _with_type_check_63589 = (object)*(((s1_ptr)_2)->base + _31193);
    if (!IS_ATOM_INT(_with_type_check_63589)){
        _with_type_check_63589 = (object)DBL_PTR(_with_type_check_63589)->dbl;
    }

    /** fwdref.e:601		if Code[pc] != TYPE_CHECK_FORWARD then*/
    _2 = (object)SEQ_PTR(_36Code_21539);
    _31195 = (object)*(((s1_ptr)_2)->base + _pc_63587);
    if (binary_op_a(EQUALS, _31195, 197)){
        _31195 = NOVALUE;
        goto L6; // [193] 204
    }
    _31195 = NOVALUE;

    /** fwdref.e:602			forward_error( tok, ref )*/
    Ref(_tok_63547);
    _44forward_error(_tok_63547, _ref_63548);
L6: 

    /** fwdref.e:604		if not var then*/
    if (_var_63554 != 0)
    goto L7; // [208] 226

    /** fwdref.e:606			var = Code[pc+1]*/
    _31198 = _pc_63587 + 1;
    _2 = (object)SEQ_PTR(_36Code_21539);
    _var_63554 = (object)*(((s1_ptr)_2)->base + _31198);
    if (!IS_ATOM_INT(_var_63554)){
        _var_63554 = (object)DBL_PTR(_var_63554)->dbl;
    }
L7: 

    /** fwdref.e:609		if var < 0 then*/
    if (_var_63554 >= 0)
    goto L8; // [228] 238

    /** fwdref.e:611			return*/
    DeRef(_tok_63547);
    DeRef(_fr_63549);
    DeRef(_31198);
    _31198 = NOVALUE;
    _31180 = NOVALUE;
    DeRef(_31193);
    _31193 = NOVALUE;
    return;
L8: 

    /** fwdref.e:615		replace_code( {}, pc, pc + 2, fr[FR_SUBPROG])*/
    _31201 = _pc_63587 + 2;
    if ((object)((uintptr_t)_31201 + (uintptr_t)HIGH_BITS) >= 0){
        _31201 = NewDouble((eudouble)_31201);
    }
    _2 = (object)SEQ_PTR(_fr_63549);
    _31202 = (object)*(((s1_ptr)_2)->base + 4);
    RefDS(_21997);
    Ref(_31202);
    _44replace_code(_21997, _pc_63587, _31201, _31202);
    _31201 = NOVALUE;
    _31202 = NOVALUE;

    /** fwdref.e:617		if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L9; // [258] 364
    }
    else{
    }

    /** fwdref.e:618			if with_type_check then*/
    if (_with_type_check_63589 == 0)
    {
        goto LA; // [263] 771
    }
    else{
    }

    /** fwdref.e:619				if which_type != object_type then*/
    if (_which_type_63552 == _54object_type_46780)
    goto LA; // [270] 771

    /** fwdref.e:620					if SymTab[which_type][S_EFFECT] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31204 = (object)*(((s1_ptr)_2)->base + _which_type_63552);
    _2 = (object)SEQ_PTR(_31204);
    _31205 = (object)*(((s1_ptr)_2)->base + 23);
    _31204 = NOVALUE;
    if (_31205 == 0) {
        _31205 = NOVALUE;
        goto LB; // [288] 357
    }
    else {
        if (!IS_ATOM_INT(_31205) && DBL_PTR(_31205)->dbl == 0.0){
            _31205 = NOVALUE;
            goto LB; // [288] 357
        }
        _31205 = NOVALUE;
    }
    _31205 = NOVALUE;

    /** fwdref.e:622						integer c = NewTempSym()*/
    _c_63619 = _54NewTempSym(0);
    if (!IS_ATOM_INT(_c_63619)) {
        _1 = (object)(DBL_PTR(_c_63619)->dbl);
        DeRefDS(_c_63619);
        _c_63619 = _1;
    }

    /** fwdref.e:623						insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 27;
    ((intptr_t*)_2)[2] = _which_type_63552;
    ((intptr_t*)_2)[3] = _var_63554;
    ((intptr_t*)_2)[4] = _c_63619;
    ((intptr_t*)_2)[5] = 65;
    _31207 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63549);
    _31208 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_329_63627);
    _code_inlined_insert_code_at_329_63627 = _31207;
    _31207 = NOVALUE;
    Ref(_31208);
    DeRef(_subprog_inlined_insert_code_at_332_63628);
    _subprog_inlined_insert_code_at_332_63628 = _31208;
    _31208 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_332_63628)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_332_63628)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_332_63628);
        _subprog_inlined_insert_code_at_332_63628 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_62788 = _subprog_inlined_insert_code_at_332_63628;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_329_63627);
    _66insert_code(_code_inlined_insert_code_at_329_63627, _pc_63587);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_62788 = 0;

    /** fwdref.e:85	end procedure*/
    goto LC; // [345] 348
LC: 
    DeRefi(_code_inlined_insert_code_at_329_63627);
    _code_inlined_insert_code_at_329_63627 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_332_63628);
    _subprog_inlined_insert_code_at_332_63628 = NOVALUE;

    /** fwdref.e:624						pc += 5*/
    _pc_63587 = _pc_63587 + 5;
LB: 
    goto LA; // [361] 771
L9: 

    /** fwdref.e:630			if with_type_check then*/
    if (_with_type_check_63589 == 0)
    {
        goto LD; // [366] 770
    }
    else{
    }

    /** fwdref.e:632				if which_type = object_type then*/
    if (_which_type_63552 != _54object_type_46780)
    goto LE; // [373] 380
    goto LF; // [377] 769
LE: 

    /** fwdref.e:636					if which_type = integer_type then*/
    if (_which_type_63552 != _54integer_type_46786)
    goto L10; // [384] 442

    /** fwdref.e:637						insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96;
    ((intptr_t *)_2)[2] = _var_63554;
    _31212 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63549);
    _31213 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_412_63643);
    _code_inlined_insert_code_at_412_63643 = _31212;
    _31212 = NOVALUE;
    Ref(_31213);
    DeRef(_subprog_inlined_insert_code_at_415_63644);
    _subprog_inlined_insert_code_at_415_63644 = _31213;
    _31213 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_415_63644)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_415_63644)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_415_63644);
        _subprog_inlined_insert_code_at_415_63644 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_62788 = _subprog_inlined_insert_code_at_415_63644;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_412_63643);
    _66insert_code(_code_inlined_insert_code_at_412_63643, _pc_63587);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_62788 = 0;

    /** fwdref.e:85	end procedure*/
    goto L11; // [428] 431
L11: 
    DeRefi(_code_inlined_insert_code_at_412_63643);
    _code_inlined_insert_code_at_412_63643 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_415_63644);
    _subprog_inlined_insert_code_at_415_63644 = NOVALUE;

    /** fwdref.e:638						pc += 2*/
    _pc_63587 = _pc_63587 + 2;
    goto L12; // [439] 768
L10: 

    /** fwdref.e:640					elsif which_type = sequence_type then*/
    if (_which_type_63552 != _54sequence_type_46784)
    goto L13; // [446] 504

    /** fwdref.e:641						insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG])*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 97;
    ((intptr_t *)_2)[2] = _var_63554;
    _31216 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63549);
    _31217 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_474_63653);
    _code_inlined_insert_code_at_474_63653 = _31216;
    _31216 = NOVALUE;
    Ref(_31217);
    DeRef(_subprog_inlined_insert_code_at_477_63654);
    _subprog_inlined_insert_code_at_477_63654 = _31217;
    _31217 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_477_63654)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_477_63654)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_477_63654);
        _subprog_inlined_insert_code_at_477_63654 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_62788 = _subprog_inlined_insert_code_at_477_63654;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_474_63653);
    _66insert_code(_code_inlined_insert_code_at_474_63653, _pc_63587);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_62788 = 0;

    /** fwdref.e:85	end procedure*/
    goto L14; // [490] 493
L14: 
    DeRefi(_code_inlined_insert_code_at_474_63653);
    _code_inlined_insert_code_at_474_63653 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_477_63654);
    _subprog_inlined_insert_code_at_477_63654 = NOVALUE;

    /** fwdref.e:642						pc += 2*/
    _pc_63587 = _pc_63587 + 2;
    goto L12; // [501] 768
L13: 

    /** fwdref.e:644					elsif which_type = atom_type then*/
    if (_which_type_63552 != _54atom_type_46782)
    goto L15; // [508] 566

    /** fwdref.e:645						insert_code( { ATOM_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 101;
    ((intptr_t *)_2)[2] = _var_63554;
    _31220 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63549);
    _31221 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_536_63663);
    _code_inlined_insert_code_at_536_63663 = _31220;
    _31220 = NOVALUE;
    Ref(_31221);
    DeRef(_subprog_inlined_insert_code_at_539_63664);
    _subprog_inlined_insert_code_at_539_63664 = _31221;
    _31221 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_539_63664)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_539_63664)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_539_63664);
        _subprog_inlined_insert_code_at_539_63664 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_62788 = _subprog_inlined_insert_code_at_539_63664;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_536_63663);
    _66insert_code(_code_inlined_insert_code_at_536_63663, _pc_63587);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_62788 = 0;

    /** fwdref.e:85	end procedure*/
    goto L16; // [552] 555
L16: 
    DeRefi(_code_inlined_insert_code_at_536_63663);
    _code_inlined_insert_code_at_536_63663 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_539_63664);
    _subprog_inlined_insert_code_at_539_63664 = NOVALUE;

    /** fwdref.e:646						pc += 2*/
    _pc_63587 = _pc_63587 + 2;
    goto L12; // [563] 768
L15: 

    /** fwdref.e:648					elsif SymTab[which_type][S_NEXT] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31223 = (object)*(((s1_ptr)_2)->base + _which_type_63552);
    _2 = (object)SEQ_PTR(_31223);
    _31224 = (object)*(((s1_ptr)_2)->base + 2);
    _31223 = NOVALUE;
    if (_31224 == 0) {
        _31224 = NOVALUE;
        goto L17; // [580] 765
    }
    else {
        if (!IS_ATOM_INT(_31224) && DBL_PTR(_31224)->dbl == 0.0){
            _31224 = NOVALUE;
            goto L17; // [580] 765
        }
        _31224 = NOVALUE;
    }
    _31224 = NOVALUE;

    /** fwdref.e:649						integer start_pc = pc*/
    _start_pc_63671 = _pc_63587;

    /** fwdref.e:652						if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] = integer_type then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31225 = (object)*(((s1_ptr)_2)->base + _which_type_63552);
    _2 = (object)SEQ_PTR(_31225);
    _31226 = (object)*(((s1_ptr)_2)->base + 2);
    _31225 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_31226)){
        _31227 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31226)->dbl));
    }
    else{
        _31227 = (object)*(((s1_ptr)_2)->base + _31226);
    }
    _2 = (object)SEQ_PTR(_31227);
    _31228 = (object)*(((s1_ptr)_2)->base + 15);
    _31227 = NOVALUE;
    if (binary_op_a(NOTEQ, _31228, _54integer_type_46786)){
        _31228 = NOVALUE;
        goto L18; // [616] 672
    }
    _31228 = NOVALUE;

    /** fwdref.e:654							insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96;
    ((intptr_t *)_2)[2] = _var_63554;
    _31230 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63549);
    _31231 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_644_63687);
    _code_inlined_insert_code_at_644_63687 = _31230;
    _31230 = NOVALUE;
    Ref(_31231);
    DeRef(_subprog_inlined_insert_code_at_647_63688);
    _subprog_inlined_insert_code_at_647_63688 = _31231;
    _31231 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_647_63688)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_647_63688)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_647_63688);
        _subprog_inlined_insert_code_at_647_63688 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_62788 = _subprog_inlined_insert_code_at_647_63688;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_644_63687);
    _66insert_code(_code_inlined_insert_code_at_644_63687, _pc_63587);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_62788 = 0;

    /** fwdref.e:85	end procedure*/
    goto L19; // [660] 663
L19: 
    DeRefi(_code_inlined_insert_code_at_644_63687);
    _code_inlined_insert_code_at_644_63687 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_647_63688);
    _subprog_inlined_insert_code_at_647_63688 = NOVALUE;

    /** fwdref.e:656							pc += 2*/
    _pc_63587 = _pc_63587 + 2;
L18: 

    /** fwdref.e:658						symtab_index c = NewTempSym()*/
    _c_63691 = _54NewTempSym(0);
    if (!IS_ATOM_INT(_c_63691)) {
        _1 = (object)(DBL_PTR(_c_63691)->dbl);
        DeRefDS(_c_63691);
        _c_63691 = _1;
    }

    /** fwdref.e:659						SymTab[fr[FR_SUBPROG]][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_fr_63549);
    _31234 = (object)*(((s1_ptr)_2)->base + 4);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_31234))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31234)->dbl));
    else
    _3 = (object)(_31234 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21144)){
        _31237 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21144)->dbl));
    }
    else{
        _31237 = (object)*(((s1_ptr)_2)->base + _36S_STACK_SPACE_21144);
    }
    _31235 = NOVALUE;
    if (IS_ATOM_INT(_31237)) {
        _31238 = _31237 + 1;
        if (_31238 > MAXINT){
            _31238 = NewDouble((eudouble)_31238);
        }
    }
    else
    _31238 = binary_op(PLUS, 1, _31237);
    _31237 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21144))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21144)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_STACK_SPACE_21144);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31238;
    if( _1 != _31238 ){
        DeRef(_1);
    }
    _31238 = NOVALUE;
    _31235 = NOVALUE;

    /** fwdref.e:660						insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 27;
    ((intptr_t*)_2)[2] = _which_type_63552;
    ((intptr_t*)_2)[3] = _var_63554;
    ((intptr_t*)_2)[4] = _c_63691;
    ((intptr_t*)_2)[5] = 65;
    _31239 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63549);
    _31240 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_738_63706);
    _code_inlined_insert_code_at_738_63706 = _31239;
    _31239 = NOVALUE;
    Ref(_31240);
    DeRef(_subprog_inlined_insert_code_at_741_63707);
    _subprog_inlined_insert_code_at_741_63707 = _31240;
    _31240 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_741_63707)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_741_63707)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_741_63707);
        _subprog_inlined_insert_code_at_741_63707 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_62788 = _subprog_inlined_insert_code_at_741_63707;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_738_63706);
    _66insert_code(_code_inlined_insert_code_at_738_63706, _pc_63587);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_62788 = 0;

    /** fwdref.e:85	end procedure*/
    goto L1A; // [753] 756
L1A: 
    DeRefi(_code_inlined_insert_code_at_738_63706);
    _code_inlined_insert_code_at_738_63706 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_741_63707);
    _subprog_inlined_insert_code_at_741_63707 = NOVALUE;

    /** fwdref.e:661						pc += 4*/
    _pc_63587 = _pc_63587 + 4;
L17: 
L12: 
LF: 
LD: 
LA: 

    /** fwdref.e:668		if (TRANSLATE or not with_type_check) and SymTab[which_type][S_NEXT] then*/
    if (_36TRANSLATE_21049 != 0) {
        _31242 = 1;
        goto L1B; // [775] 786
    }
    _31243 = (_with_type_check_63589 == 0);
    _31242 = (_31243 != 0);
L1B: 
    if (_31242 == 0) {
        goto L1C; // [786] 1013
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31245 = (object)*(((s1_ptr)_2)->base + _which_type_63552);
    _2 = (object)SEQ_PTR(_31245);
    _31246 = (object)*(((s1_ptr)_2)->base + 2);
    _31245 = NOVALUE;
    if (_31246 == 0) {
        _31246 = NOVALUE;
        goto L1C; // [803] 1013
    }
    else {
        if (!IS_ATOM_INT(_31246) && DBL_PTR(_31246)->dbl == 0.0){
            _31246 = NOVALUE;
            goto L1C; // [803] 1013
        }
        _31246 = NOVALUE;
    }
    _31246 = NOVALUE;

    /** fwdref.e:669			integer start_pc = pc*/
    _start_pc_63718 = _pc_63587;

    /** fwdref.e:671			if which_type = sequence_type or*/
    _31247 = (_which_type_63552 == _54sequence_type_46784);
    if (_31247 != 0) {
        goto L1D; // [819] 858
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31249 = (object)*(((s1_ptr)_2)->base + _which_type_63552);
    _2 = (object)SEQ_PTR(_31249);
    _31250 = (object)*(((s1_ptr)_2)->base + 2);
    _31249 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_31250)){
        _31251 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31250)->dbl));
    }
    else{
        _31251 = (object)*(((s1_ptr)_2)->base + _31250);
    }
    _2 = (object)SEQ_PTR(_31251);
    _31252 = (object)*(((s1_ptr)_2)->base + 15);
    _31251 = NOVALUE;
    if (IS_ATOM_INT(_31252)) {
        _31253 = (_31252 == _54sequence_type_46784);
    }
    else {
        _31253 = binary_op(EQUALS, _31252, _54sequence_type_46784);
    }
    _31252 = NOVALUE;
    if (_31253 == 0) {
        DeRef(_31253);
        _31253 = NOVALUE;
        goto L1E; // [854] 912
    }
    else {
        if (!IS_ATOM_INT(_31253) && DBL_PTR(_31253)->dbl == 0.0){
            DeRef(_31253);
            _31253 = NOVALUE;
            goto L1E; // [854] 912
        }
        DeRef(_31253);
        _31253 = NOVALUE;
    }
    DeRef(_31253);
    _31253 = NOVALUE;
L1D: 

    /** fwdref.e:674				insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 97;
    ((intptr_t *)_2)[2] = _var_63554;
    _31254 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63549);
    _31255 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_883_63737);
    _code_inlined_insert_code_at_883_63737 = _31254;
    _31254 = NOVALUE;
    Ref(_31255);
    DeRef(_subprog_inlined_insert_code_at_886_63738);
    _subprog_inlined_insert_code_at_886_63738 = _31255;
    _31255 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_886_63738)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_886_63738)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_886_63738);
        _subprog_inlined_insert_code_at_886_63738 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_62788 = _subprog_inlined_insert_code_at_886_63738;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_883_63737);
    _66insert_code(_code_inlined_insert_code_at_883_63737, _pc_63587);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_62788 = 0;

    /** fwdref.e:85	end procedure*/
    goto L1F; // [898] 901
L1F: 
    DeRefi(_code_inlined_insert_code_at_883_63737);
    _code_inlined_insert_code_at_883_63737 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_886_63738);
    _subprog_inlined_insert_code_at_886_63738 = NOVALUE;

    /** fwdref.e:675				pc += 2*/
    _pc_63587 = _pc_63587 + 2;
    goto L20; // [909] 1012
L1E: 

    /** fwdref.e:677			elsif which_type = integer_type or*/
    _31257 = (_which_type_63552 == _54integer_type_46786);
    if (_31257 != 0) {
        goto L21; // [920] 959
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31259 = (object)*(((s1_ptr)_2)->base + _which_type_63552);
    _2 = (object)SEQ_PTR(_31259);
    _31260 = (object)*(((s1_ptr)_2)->base + 2);
    _31259 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_31260)){
        _31261 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31260)->dbl));
    }
    else{
        _31261 = (object)*(((s1_ptr)_2)->base + _31260);
    }
    _2 = (object)SEQ_PTR(_31261);
    _31262 = (object)*(((s1_ptr)_2)->base + 15);
    _31261 = NOVALUE;
    if (IS_ATOM_INT(_31262)) {
        _31263 = (_31262 == _54integer_type_46786);
    }
    else {
        _31263 = binary_op(EQUALS, _31262, _54integer_type_46786);
    }
    _31262 = NOVALUE;
    if (_31263 == 0) {
        DeRef(_31263);
        _31263 = NOVALUE;
        goto L22; // [955] 1011
    }
    else {
        if (!IS_ATOM_INT(_31263) && DBL_PTR(_31263)->dbl == 0.0){
            DeRef(_31263);
            _31263 = NOVALUE;
            goto L22; // [955] 1011
        }
        DeRef(_31263);
        _31263 = NOVALUE;
    }
    DeRef(_31263);
    _31263 = NOVALUE;
L21: 

    /** fwdref.e:680				insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96;
    ((intptr_t *)_2)[2] = _var_63554;
    _31264 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63549);
    _31265 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_984_63758);
    _code_inlined_insert_code_at_984_63758 = _31264;
    _31264 = NOVALUE;
    Ref(_31265);
    DeRef(_subprog_inlined_insert_code_at_987_63759);
    _subprog_inlined_insert_code_at_987_63759 = _31265;
    _31265 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_987_63759)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_987_63759)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_987_63759);
        _subprog_inlined_insert_code_at_987_63759 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_62788 = _subprog_inlined_insert_code_at_987_63759;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_984_63758);
    _66insert_code(_code_inlined_insert_code_at_984_63758, _pc_63587);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_62788 = 0;

    /** fwdref.e:85	end procedure*/
    goto L23; // [999] 1002
L23: 
    DeRefi(_code_inlined_insert_code_at_984_63758);
    _code_inlined_insert_code_at_984_63758 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_987_63759);
    _subprog_inlined_insert_code_at_987_63759 = NOVALUE;

    /** fwdref.e:681				pc += 4*/
    _pc_63587 = _pc_63587 + 4;
L22: 
L20: 
L1C: 

    /** fwdref.e:686		resolved_reference( ref )*/
    _44resolved_reference(_ref_63548);

    /** fwdref.e:687		reset_code()*/
    _44reset_code();

    /** fwdref.e:688	end procedure*/
    DeRef(_tok_63547);
    DeRef(_fr_63549);
    DeRef(_31198);
    _31198 = NOVALUE;
    DeRef(_31257);
    _31257 = NOVALUE;
    DeRef(_31243);
    _31243 = NOVALUE;
    DeRef(_31247);
    _31247 = NOVALUE;
    _31250 = NOVALUE;
    _31260 = NOVALUE;
    _31180 = NOVALUE;
    DeRef(_31193);
    _31193 = NOVALUE;
    _31234 = NOVALUE;
    _31226 = NOVALUE;
    return;
    ;
}


void _44prep_forward_error(object _ref_63763)
{
    object _31273 = NOVALUE;
    object _31271 = NOVALUE;
    object _31269 = NOVALUE;
    object _31267 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_ref_63763)) {
        _1 = (object)(DBL_PTR(_ref_63763)->dbl);
        DeRefDS(_ref_63763);
        _ref_63763 = _1;
    }

    /** fwdref.e:691		ThisLine = forward_references[ref][FR_THISLINE]*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    _31267 = (object)*(((s1_ptr)_2)->base + _ref_63763);
    DeRef(_50ThisLine_49238);
    _2 = (object)SEQ_PTR(_31267);
    _50ThisLine_49238 = (object)*(((s1_ptr)_2)->base + 7);
    Ref(_50ThisLine_49238);
    _31267 = NOVALUE;

    /** fwdref.e:692		bp = forward_references[ref][FR_BP]*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    _31269 = (object)*(((s1_ptr)_2)->base + _ref_63763);
    _2 = (object)SEQ_PTR(_31269);
    _50bp_49242 = (object)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_50bp_49242)){
        _50bp_49242 = (object)DBL_PTR(_50bp_49242)->dbl;
    }
    _31269 = NOVALUE;

    /** fwdref.e:693		line_number = forward_references[ref][FR_LINE]*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    _31271 = (object)*(((s1_ptr)_2)->base + _ref_63763);
    _2 = (object)SEQ_PTR(_31271);
    _36line_number_21448 = (object)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_36line_number_21448)){
        _36line_number_21448 = (object)DBL_PTR(_36line_number_21448)->dbl;
    }
    _31271 = NOVALUE;

    /** fwdref.e:694		current_file_no = forward_references[ref][FR_FILE]*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    _31273 = (object)*(((s1_ptr)_2)->base + _ref_63763);
    _2 = (object)SEQ_PTR(_31273);
    _36current_file_no_21447 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_36current_file_no_21447)){
        _36current_file_no_21447 = (object)DBL_PTR(_36current_file_no_21447)->dbl;
    }
    _31273 = NOVALUE;

    /** fwdref.e:695	end procedure*/
    return;
    ;
}


void _44forward_error(object _tok_63779, object _ref_63780)
{
    object _31280 = NOVALUE;
    object _31279 = NOVALUE;
    object _31278 = NOVALUE;
    object _31277 = NOVALUE;
    object _31276 = NOVALUE;
    object _31275 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:698		prep_forward_error( ref )*/
    _44prep_forward_error(_ref_63780);

    /** fwdref.e:699		CompileErr(EXPECTED_1_NOT_2, { expected_name( forward_references[ref][FR_TYPE] ),*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    _31275 = (object)*(((s1_ptr)_2)->base + _ref_63780);
    _2 = (object)SEQ_PTR(_31275);
    _31276 = (object)*(((s1_ptr)_2)->base + 1);
    _31275 = NOVALUE;
    Ref(_31276);
    _31277 = _44expected_name(_31276);
    _31276 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_63779);
    _31278 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_31278);
    _31279 = _44expected_name(_31278);
    _31278 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _31277;
    ((intptr_t *)_2)[2] = _31279;
    _31280 = MAKE_SEQ(_1);
    _31279 = NOVALUE;
    _31277 = NOVALUE;
    _50CompileErr(68, _31280, 0);
    _31280 = NOVALUE;

    /** fwdref.e:701	end procedure*/
    DeRef(_tok_63779);
    return;
    ;
}


object _44find_reference(object _fr_63792)
{
    object _name_63793 = NOVALUE;
    object _file_63795 = NOVALUE;
    object _ns_file_63797 = NOVALUE;
    object _ix_63798 = NOVALUE;
    object _ns_63801 = NOVALUE;
    object _ns_tok_63805 = NOVALUE;
    object _tok_63817 = NOVALUE;
    object _31291 = NOVALUE;
    object _31288 = NOVALUE;
    object _31286 = NOVALUE;
    object _31284 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:706		sequence name = fr[FR_NAME]*/
    DeRef(_name_63793);
    _2 = (object)SEQ_PTR(_fr_63792);
    _name_63793 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_name_63793);

    /** fwdref.e:707		integer file  = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63792);
    _file_63795 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_file_63795))
    _file_63795 = (object)DBL_PTR(_file_63795)->dbl;

    /** fwdref.e:709		integer ns_file = -1*/
    _ns_file_63797 = -1;

    /** fwdref.e:710		integer ix = find( ':', name )*/
    _ix_63798 = find_from(58, _name_63793, 1);

    /** fwdref.e:711		if ix then*/
    if (_ix_63798 == 0)
    {
        goto L1; // [31] 85
    }
    else{
    }

    /** fwdref.e:712			sequence ns = name[1..ix-1]*/
    _31284 = _ix_63798 - 1;
    rhs_slice_target = (object_ptr)&_ns_63801;
    RHS_Slice(_name_63793, 1, _31284);

    /** fwdref.e:713			token ns_tok = keyfind( ns, ns_file, file, 1, fr[FR_HASHVAL] )*/
    _2 = (object)SEQ_PTR(_fr_63792);
    _31286 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_ns_63801);
    Ref(_31286);
    _0 = _ns_tok_63805;
    _ns_tok_63805 = _54keyfind(_ns_63801, -1, _file_63795, 1, _31286);
    DeRef(_0);
    _31286 = NOVALUE;

    /** fwdref.e:714			if ns_tok[T_ID] != NAMESPACE then*/
    _2 = (object)SEQ_PTR(_ns_tok_63805);
    _31288 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _31288, 523)){
        _31288 = NOVALUE;
        goto L2; // [69] 80
    }
    _31288 = NOVALUE;

    /** fwdref.e:715				return ns_tok*/
    DeRefDS(_ns_63801);
    DeRefDS(_fr_63792);
    DeRefDS(_name_63793);
    DeRef(_tok_63817);
    _31284 = NOVALUE;
    return _ns_tok_63805;
L2: 
    DeRef(_ns_63801);
    _ns_63801 = NOVALUE;
    DeRef(_ns_tok_63805);
    _ns_tok_63805 = NOVALUE;
    goto L3; // [82] 92
L1: 

    /** fwdref.e:718			ns_file = fr[FR_QUALIFIED]*/
    _2 = (object)SEQ_PTR(_fr_63792);
    _ns_file_63797 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_ns_file_63797))
    _ns_file_63797 = (object)DBL_PTR(_ns_file_63797)->dbl;
L3: 

    /** fwdref.e:721		No_new_entry = 1*/
    _54No_new_entry_47978 = 1;

    /** fwdref.e:722		object tok = keyfind( name, ns_file, file, , fr[FR_HASHVAL] )*/
    _2 = (object)SEQ_PTR(_fr_63792);
    _31291 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_name_63793);
    Ref(_31291);
    _0 = _tok_63817;
    _tok_63817 = _54keyfind(_name_63793, _ns_file_63797, _file_63795, 0, _31291);
    DeRef(_0);
    _31291 = NOVALUE;

    /** fwdref.e:723		No_new_entry = 0*/
    _54No_new_entry_47978 = 0;

    /** fwdref.e:724		return tok*/
    DeRefDS(_fr_63792);
    DeRefDS(_name_63793);
    DeRef(_31284);
    _31284 = NOVALUE;
    return _tok_63817;
    ;
}


void _44register_forward_type(object _sym_63825, object _ref_63826)
{
    object _31298 = NOVALUE;
    object _31297 = NOVALUE;
    object _31295 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:729		if ref < 0 then*/
    if (_ref_63826 >= 0)
    goto L1; // [7] 19

    /** fwdref.e:730			ref = -ref*/
    _ref_63826 = - _ref_63826;
L1: 

    /** fwdref.e:732		forward_references[ref][FR_DATA] &= sym*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63826 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31297 = (object)*(((s1_ptr)_2)->base + 12);
    _31295 = NOVALUE;
    if (IS_SEQUENCE(_31297) && IS_ATOM(_sym_63825)) {
        Append(&_31298, _31297, _sym_63825);
    }
    else if (IS_ATOM(_31297) && IS_SEQUENCE(_sym_63825)) {
    }
    else {
        Concat((object_ptr)&_31298, _31297, _sym_63825);
        _31297 = NOVALUE;
    }
    _31297 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31298;
    if( _1 != _31298 ){
        DeRef(_1);
    }
    _31298 = NOVALUE;
    _31295 = NOVALUE;

    /** fwdref.e:733	end procedure*/
    return;
    ;
}


object _44new_forward_reference(object _fwd_op_63856, object _sym_63858, object _op_63859)
{
    object _ref_63860 = NOVALUE;
    object _len_63861 = NOVALUE;
    object _hashval_63891 = NOVALUE;
    object _default_sym_63966 = NOVALUE;
    object _param_63969 = NOVALUE;
    object _set_data_2__tmp_at578_63986 = NOVALUE;
    object _set_data_1__tmp_at578_63985 = NOVALUE;
    object _data_inlined_set_data_at_575_63984 = NOVALUE;
    object _31384 = NOVALUE;
    object _31383 = NOVALUE;
    object _31382 = NOVALUE;
    object _31379 = NOVALUE;
    object _31377 = NOVALUE;
    object _31376 = NOVALUE;
    object _31374 = NOVALUE;
    object _31373 = NOVALUE;
    object _31372 = NOVALUE;
    object _31370 = NOVALUE;
    object _31368 = NOVALUE;
    object _31366 = NOVALUE;
    object _31363 = NOVALUE;
    object _31362 = NOVALUE;
    object _31360 = NOVALUE;
    object _31358 = NOVALUE;
    object _31356 = NOVALUE;
    object _31354 = NOVALUE;
    object _31353 = NOVALUE;
    object _31352 = NOVALUE;
    object _31350 = NOVALUE;
    object _31347 = NOVALUE;
    object _31345 = NOVALUE;
    object _31343 = NOVALUE;
    object _31342 = NOVALUE;
    object _31341 = NOVALUE;
    object _31340 = NOVALUE;
    object _31338 = NOVALUE;
    object _31335 = NOVALUE;
    object _31334 = NOVALUE;
    object _31333 = NOVALUE;
    object _31331 = NOVALUE;
    object _31330 = NOVALUE;
    object _31329 = NOVALUE;
    object _31328 = NOVALUE;
    object _31326 = NOVALUE;
    object _31325 = NOVALUE;
    object _31324 = NOVALUE;
    object _31323 = NOVALUE;
    object _31321 = NOVALUE;
    object _31318 = NOVALUE;
    object _31317 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_63858)) {
        _1 = (object)(DBL_PTR(_sym_63858)->dbl);
        DeRefDS(_sym_63858);
        _sym_63858 = _1;
    }

    /** fwdref.e:754			len = length( inactive_references )*/
    if (IS_SEQUENCE(_44inactive_references_62773)){
            _len_63861 = SEQ_PTR(_44inactive_references_62773)->length;
    }
    else {
        _len_63861 = 1;
    }

    /** fwdref.e:757		if len then*/
    if (_len_63861 == 0)
    {
        goto L1; // [16] 39
    }
    else{
    }

    /** fwdref.e:758			ref = inactive_references[len]*/
    _2 = (object)SEQ_PTR(_44inactive_references_62773);
    _ref_63860 = (object)*(((s1_ptr)_2)->base + _len_63861);
    if (!IS_ATOM_INT(_ref_63860))
    _ref_63860 = (object)DBL_PTR(_ref_63860)->dbl;

    /** fwdref.e:759			inactive_references = remove( inactive_references, len, len )*/
    {
        s1_ptr assign_space = SEQ_PTR(_44inactive_references_62773);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_len_63861)) ? _len_63861 : (object)(DBL_PTR(_len_63861)->dbl);
        int stop = (IS_ATOM_INT(_len_63861)) ? _len_63861 : (object)(DBL_PTR(_len_63861)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_44inactive_references_62773), start, &_44inactive_references_62773 );
            }
            else Tail(SEQ_PTR(_44inactive_references_62773), stop+1, &_44inactive_references_62773);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_44inactive_references_62773), start, &_44inactive_references_62773);
        }
        else {
            assign_slice_seq = &assign_space;
            _44inactive_references_62773 = Remove_elements(start, stop, (SEQ_PTR(_44inactive_references_62773)->ref == 1));
        }
    }
    goto L2; // [36] 55
L1: 

    /** fwdref.e:761			forward_references &= 0*/
    Append(&_44forward_references_62769, _44forward_references_62769, 0);

    /** fwdref.e:762			ref = length( forward_references )*/
    if (IS_SEQUENCE(_44forward_references_62769)){
            _ref_63860 = SEQ_PTR(_44forward_references_62769)->length;
    }
    else {
        _ref_63860 = 1;
    }
L2: 

    /** fwdref.e:764		forward_references[ref] = repeat( 0, FR_SIZE )*/
    _31317 = Repeat(0, 12);
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ref_63860);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31317;
    if( _1 != _31317 ){
        DeRef(_1);
    }
    _31317 = NOVALUE;

    /** fwdref.e:766		forward_references[ref][FR_TYPE]      = fwd_op*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63860 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _fwd_op_63856;
    DeRef(_1);
    _31318 = NOVALUE;

    /** fwdref.e:767		if sym < 0 then*/
    if (_sym_63858 >= 0)
    goto L3; // [84] 143

    /** fwdref.e:768			forward_references[ref][FR_NAME] = forward_references[-sym][FR_NAME]*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63860 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_sym_63858 == (uintptr_t)HIGH_BITS){
        _31323 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31323 = - _sym_63858;
    }
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!IS_ATOM_INT(_31323)){
        _31324 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31323)->dbl));
    }
    else{
        _31324 = (object)*(((s1_ptr)_2)->base + _31323);
    }
    _2 = (object)SEQ_PTR(_31324);
    _31325 = (object)*(((s1_ptr)_2)->base + 2);
    _31324 = NOVALUE;
    Ref(_31325);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31325;
    if( _1 != _31325 ){
        DeRef(_1);
    }
    _31325 = NOVALUE;
    _31321 = NOVALUE;

    /** fwdref.e:769			forward_references[ref][FR_HASHVAL] = forward_references[-sym][FR_HASHVAL]*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63860 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_sym_63858 == (uintptr_t)HIGH_BITS){
        _31328 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31328 = - _sym_63858;
    }
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!IS_ATOM_INT(_31328)){
        _31329 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31328)->dbl));
    }
    else{
        _31329 = (object)*(((s1_ptr)_2)->base + _31328);
    }
    _2 = (object)SEQ_PTR(_31329);
    _31330 = (object)*(((s1_ptr)_2)->base + 11);
    _31329 = NOVALUE;
    Ref(_31330);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31330;
    if( _1 != _31330 ){
        DeRef(_1);
    }
    _31330 = NOVALUE;
    _31326 = NOVALUE;
    goto L4; // [140] 242
L3: 

    /** fwdref.e:771			forward_references[ref][FR_NAME] = SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63860 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31333 = (object)*(((s1_ptr)_2)->base + _sym_63858);
    _2 = (object)SEQ_PTR(_31333);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _31334 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _31334 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _31333 = NOVALUE;
    Ref(_31334);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31334;
    if( _1 != _31334 ){
        DeRef(_1);
    }
    _31334 = NOVALUE;
    _31331 = NOVALUE;

    /** fwdref.e:772			integer hashval = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31335 = (object)*(((s1_ptr)_2)->base + _sym_63858);
    _2 = (object)SEQ_PTR(_31335);
    _hashval_63891 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_hashval_63891)){
        _hashval_63891 = (object)DBL_PTR(_hashval_63891)->dbl;
    }
    _31335 = NOVALUE;

    /** fwdref.e:773			if 0 = hashval then*/
    if (0 != _hashval_63891)
    goto L5; // [186] 220

    /** fwdref.e:774				forward_references[ref][FR_HASHVAL] = hashfn( forward_references[ref][FR_NAME] )*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63860 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    _31340 = (object)*(((s1_ptr)_2)->base + _ref_63860);
    _2 = (object)SEQ_PTR(_31340);
    _31341 = (object)*(((s1_ptr)_2)->base + 2);
    _31340 = NOVALUE;
    Ref(_31341);
    _31342 = _54hashfn(_31341);
    _31341 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31342;
    if( _1 != _31342 ){
        DeRef(_1);
    }
    _31342 = NOVALUE;
    _31338 = NOVALUE;
    goto L6; // [217] 239
L5: 

    /** fwdref.e:776				forward_references[ref][FR_HASHVAL] = hashval*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63860 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _hashval_63891;
    DeRef(_1);
    _31343 = NOVALUE;

    /** fwdref.e:777				remove_symbol( sym )*/
    _54remove_symbol(_sym_63858);
L6: 
L4: 

    /** fwdref.e:782		forward_references[ref][FR_FILE]      = current_file_no*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63860 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21447;
    DeRef(_1);
    _31345 = NOVALUE;

    /** fwdref.e:783		forward_references[ref][FR_SUBPROG]   = CurrentSub*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63860 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36CurrentSub_21455;
    DeRef(_1);
    _31347 = NOVALUE;

    /** fwdref.e:785		if fwd_op != TYPE then*/
    if (_fwd_op_63856 == 504)
    goto L7; // [276] 303

    /** fwdref.e:786			forward_references[ref][FR_PC]        = length( Code ) + 1*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63860 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_36Code_21539)){
            _31352 = SEQ_PTR(_36Code_21539)->length;
    }
    else {
        _31352 = 1;
    }
    _31353 = _31352 + 1;
    _31352 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31353;
    if( _1 != _31353 ){
        DeRef(_1);
    }
    _31353 = NOVALUE;
    _31350 = NOVALUE;
L7: 

    /** fwdref.e:789		forward_references[ref][FR_LINE]      = fwd_line_number*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63860 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36fwd_line_number_21449;
    DeRef(_1);
    _31354 = NOVALUE;

    /** fwdref.e:790		forward_references[ref][FR_THISLINE]  = ForwardLine*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63860 + ((s1_ptr)_2)->base);
    Ref(_50ForwardLine_49239);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _50ForwardLine_49239;
    DeRef(_1);
    _31356 = NOVALUE;

    /** fwdref.e:791		forward_references[ref][FR_BP]        = forward_bp*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63860 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _50forward_bp_49243;
    DeRef(_1);
    _31358 = NOVALUE;

    /** fwdref.e:792		forward_references[ref][FR_QUALIFIED] = get_qualified_fwd()*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63860 + ((s1_ptr)_2)->base);
    _31362 = _62get_qualified_fwd();
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31362;
    if( _1 != _31362 ){
        DeRef(_1);
    }
    _31362 = NOVALUE;
    _31360 = NOVALUE;

    /** fwdref.e:793		forward_references[ref][FR_OP]        = op*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63860 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _op_63859;
    DeRef(_1);
    _31363 = NOVALUE;

    /** fwdref.e:795		if op = GOTO then*/
    if (_op_63859 != 188)
    goto L8; // [381] 403

    /** fwdref.e:796			forward_references[ref][FR_DATA] = { sym }*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63860 + ((s1_ptr)_2)->base);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _sym_63858;
    _31368 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31368;
    if( _1 != _31368 ){
        DeRef(_1);
    }
    _31368 = NOVALUE;
    _31366 = NOVALUE;
L8: 

    /** fwdref.e:803		if CurrentSub = TopLevelSub then*/
    if (_36CurrentSub_21455 != _36TopLevelSub_21454)
    goto L9; // [409] 471

    /** fwdref.e:804			if length( toplevel_references ) < current_file_no then*/
    if (IS_SEQUENCE(_44toplevel_references_62772)){
            _31370 = SEQ_PTR(_44toplevel_references_62772)->length;
    }
    else {
        _31370 = 1;
    }
    if (_31370 >= _36current_file_no_21447)
    goto LA; // [422] 450

    /** fwdref.e:805				toplevel_references &= repeat( {}, current_file_no - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_44toplevel_references_62772)){
            _31372 = SEQ_PTR(_44toplevel_references_62772)->length;
    }
    else {
        _31372 = 1;
    }
    _31373 = _36current_file_no_21447 - _31372;
    _31372 = NOVALUE;
    _31374 = Repeat(_21997, _31373);
    _31373 = NOVALUE;
    Concat((object_ptr)&_44toplevel_references_62772, _44toplevel_references_62772, _31374);
    DeRefDS(_31374);
    _31374 = NOVALUE;
LA: 

    /** fwdref.e:807			toplevel_references[current_file_no] &= ref*/
    _2 = (object)SEQ_PTR(_44toplevel_references_62772);
    _31376 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    if (IS_SEQUENCE(_31376) && IS_ATOM(_ref_63860)) {
        Append(&_31377, _31376, _ref_63860);
    }
    else if (IS_ATOM(_31376) && IS_SEQUENCE(_ref_63860)) {
    }
    else {
        Concat((object_ptr)&_31377, _31376, _ref_63860);
        _31376 = NOVALUE;
    }
    _31376 = NOVALUE;
    _2 = (object)SEQ_PTR(_44toplevel_references_62772);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44toplevel_references_62772 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21447);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31377;
    if( _1 != _31377 ){
        DeRef(_1);
    }
    _31377 = NOVALUE;
    goto LB; // [468] 595
L9: 

    /** fwdref.e:809			add_active_reference( ref )*/
    _44add_active_reference(_ref_63860, _36current_file_no_21447);

    /** fwdref.e:811			if Parser_mode = PAM_RECORD then*/
    if (_36Parser_mode_21556 != 1)
    goto LC; // [485] 592

    /** fwdref.e:812				symtab_pointer default_sym = CurrentSub*/
    _default_sym_63966 = _36CurrentSub_21455;

    /** fwdref.e:813				symtab_pointer param = 0*/
    _param_63969 = 0;

    /** fwdref.e:814				while default_sym with entry do*/
    goto LD; // [507] 536
LE: 
    if (_default_sym_63966 == 0)
    {
        goto LF; // [510] 549
    }
    else{
    }

    /** fwdref.e:815					if sym_scope( default_sym ) = SC_PRIVATE then*/
    _31379 = _54sym_scope(_default_sym_63966);
    if (binary_op_a(NOTEQ, _31379, 3)){
        DeRef(_31379);
        _31379 = NOVALUE;
        goto L10; // [521] 533
    }
    DeRef(_31379);
    _31379 = NOVALUE;

    /** fwdref.e:816						param = default_sym*/
    _param_63969 = _default_sym_63966;
L10: 

    /** fwdref.e:818				entry*/
LD: 

    /** fwdref.e:819					default_sym = sym_next( default_sym )*/
    _default_sym_63966 = _54sym_next(_default_sym_63966);
    if (!IS_ATOM_INT(_default_sym_63966)) {
        _1 = (object)(DBL_PTR(_default_sym_63966)->dbl);
        DeRefDS(_default_sym_63966);
        _default_sym_63966 = _1;
    }

    /** fwdref.e:820				end while*/
    goto LE; // [546] 510
LF: 

    /** fwdref.e:821				set_data( ref, {{ PAM_RECORD, param, length( Recorded_sym ) }} )*/
    if (IS_SEQUENCE(_36Recorded_sym_21559)){
            _31382 = SEQ_PTR(_36Recorded_sym_21559)->length;
    }
    else {
        _31382 = 1;
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = _param_63969;
    ((intptr_t*)_2)[3] = _31382;
    _31383 = MAKE_SEQ(_1);
    _31382 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31383;
    _31384 = MAKE_SEQ(_1);
    _31383 = NOVALUE;
    DeRef(_data_inlined_set_data_at_575_63984);
    _data_inlined_set_data_at_575_63984 = _31384;
    _31384 = NOVALUE;

    /** fwdref.e:186		forward_references[ref][FR_DATA] = data*/
    _2 = (object)SEQ_PTR(_44forward_references_62769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62769 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63860 + ((s1_ptr)_2)->base);
    RefDS(_data_inlined_set_data_at_575_63984);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _data_inlined_set_data_at_575_63984;
    DeRef(_1);

    /** fwdref.e:187	end procedure*/
    goto L11; // [586] 589
L11: 
    DeRef(_data_inlined_set_data_at_575_63984);
    _data_inlined_set_data_at_575_63984 = NOVALUE;
LC: 
LB: 

    /** fwdref.e:824		fwdref_count += 1*/
    _44fwdref_count_62789 = _44fwdref_count_62789 + 1;

    /** fwdref.e:826		ifdef EUDIS then*/

    /** fwdref.e:839		return ref*/
    DeRef(_31323);
    _31323 = NOVALUE;
    DeRef(_31328);
    _31328 = NOVALUE;
    return _ref_63860;
    ;
}


void _44add_active_reference(object _ref_63990, object _file_no_63991)
{
    object _sp_64005 = NOVALUE;
    object _31408 = NOVALUE;
    object _31407 = NOVALUE;
    object _31405 = NOVALUE;
    object _31404 = NOVALUE;
    object _31403 = NOVALUE;
    object _31401 = NOVALUE;
    object _31400 = NOVALUE;
    object _31399 = NOVALUE;
    object _31396 = NOVALUE;
    object _31394 = NOVALUE;
    object _31393 = NOVALUE;
    object _31392 = NOVALUE;
    object _31390 = NOVALUE;
    object _31389 = NOVALUE;
    object _31388 = NOVALUE;
    object _31386 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:843		if length( active_references ) < file_no then*/
    if (IS_SEQUENCE(_44active_references_62771)){
            _31386 = SEQ_PTR(_44active_references_62771)->length;
    }
    else {
        _31386 = 1;
    }
    if (_31386 >= _file_no_63991)
    goto L1; // [12] 59

    /** fwdref.e:844			active_references &= repeat( {}, file_no - length( active_references ) )*/
    if (IS_SEQUENCE(_44active_references_62771)){
            _31388 = SEQ_PTR(_44active_references_62771)->length;
    }
    else {
        _31388 = 1;
    }
    _31389 = _file_no_63991 - _31388;
    _31388 = NOVALUE;
    _31390 = Repeat(_21997, _31389);
    _31389 = NOVALUE;
    Concat((object_ptr)&_44active_references_62771, _44active_references_62771, _31390);
    DeRefDS(_31390);
    _31390 = NOVALUE;

    /** fwdref.e:845			active_subprogs   &= repeat( {}, file_no - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_44active_subprogs_62770)){
            _31392 = SEQ_PTR(_44active_subprogs_62770)->length;
    }
    else {
        _31392 = 1;
    }
    _31393 = _file_no_63991 - _31392;
    _31392 = NOVALUE;
    _31394 = Repeat(_21997, _31393);
    _31393 = NOVALUE;
    Concat((object_ptr)&_44active_subprogs_62770, _44active_subprogs_62770, _31394);
    DeRefDS(_31394);
    _31394 = NOVALUE;
L1: 

    /** fwdref.e:847		integer sp = find( CurrentSub, active_subprogs[file_no] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_62770);
    _31396 = (object)*(((s1_ptr)_2)->base + _file_no_63991);
    _sp_64005 = find_from(_36CurrentSub_21455, _31396, 1);
    _31396 = NOVALUE;

    /** fwdref.e:848		if not sp then*/
    if (_sp_64005 != 0)
    goto L2; // [76] 127

    /** fwdref.e:849			active_subprogs[file_no] &= CurrentSub*/
    _2 = (object)SEQ_PTR(_44active_subprogs_62770);
    _31399 = (object)*(((s1_ptr)_2)->base + _file_no_63991);
    if (IS_SEQUENCE(_31399) && IS_ATOM(_36CurrentSub_21455)) {
        Append(&_31400, _31399, _36CurrentSub_21455);
    }
    else if (IS_ATOM(_31399) && IS_SEQUENCE(_36CurrentSub_21455)) {
    }
    else {
        Concat((object_ptr)&_31400, _31399, _36CurrentSub_21455);
        _31399 = NOVALUE;
    }
    _31399 = NOVALUE;
    _2 = (object)SEQ_PTR(_44active_subprogs_62770);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_subprogs_62770 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_no_63991);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31400;
    if( _1 != _31400 ){
        DeRef(_1);
    }
    _31400 = NOVALUE;

    /** fwdref.e:850			sp = length( active_subprogs[file_no] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_62770);
    _31401 = (object)*(((s1_ptr)_2)->base + _file_no_63991);
    if (IS_SEQUENCE(_31401)){
            _sp_64005 = SEQ_PTR(_31401)->length;
    }
    else {
        _sp_64005 = 1;
    }
    _31401 = NOVALUE;

    /** fwdref.e:852			active_references[file_no] = append( active_references[file_no], {} )*/
    _2 = (object)SEQ_PTR(_44active_references_62771);
    _31403 = (object)*(((s1_ptr)_2)->base + _file_no_63991);
    RefDS(_21997);
    Append(&_31404, _31403, _21997);
    _31403 = NOVALUE;
    _2 = (object)SEQ_PTR(_44active_references_62771);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_62771 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_no_63991);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31404;
    if( _1 != _31404 ){
        DeRef(_1);
    }
    _31404 = NOVALUE;
L2: 

    /** fwdref.e:854		active_references[file_no][sp] &= ref*/
    _2 = (object)SEQ_PTR(_44active_references_62771);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_62771 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_no_63991 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31407 = (object)*(((s1_ptr)_2)->base + _sp_64005);
    _31405 = NOVALUE;
    if (IS_SEQUENCE(_31407) && IS_ATOM(_ref_63990)) {
        Append(&_31408, _31407, _ref_63990);
    }
    else if (IS_ATOM(_31407) && IS_SEQUENCE(_ref_63990)) {
    }
    else {
        Concat((object_ptr)&_31408, _31407, _ref_63990);
        _31407 = NOVALUE;
    }
    _31407 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_64005);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31408;
    if( _1 != _31408 ){
        DeRef(_1);
    }
    _31408 = NOVALUE;
    _31405 = NOVALUE;

    /** fwdref.e:855	end procedure*/
    _31401 = NOVALUE;
    return;
    ;
}


object _44resolve_file(object _refs_64042, object _report_errors_64043, object _unincluded_ok_64044)
{
    object _errors_64045 = NOVALUE;
    object _ref_64049 = NOVALUE;
    object _fr_64051 = NOVALUE;
    object _tok_64064 = NOVALUE;
    object _code_sub_64072 = NOVALUE;
    object _fr_type_64074 = NOVALUE;
    object _sym_tok_64076 = NOVALUE;
    object _31462 = NOVALUE;
    object _31461 = NOVALUE;
    object _31460 = NOVALUE;
    object _31459 = NOVALUE;
    object _31458 = NOVALUE;
    object _31457 = NOVALUE;
    object _31452 = NOVALUE;
    object _31451 = NOVALUE;
    object _31450 = NOVALUE;
    object _31448 = NOVALUE;
    object _31447 = NOVALUE;
    object _31444 = NOVALUE;
    object _31443 = NOVALUE;
    object _31442 = NOVALUE;
    object _31438 = NOVALUE;
    object _31437 = NOVALUE;
    object _31429 = NOVALUE;
    object _31427 = NOVALUE;
    object _31426 = NOVALUE;
    object _31425 = NOVALUE;
    object _31424 = NOVALUE;
    object _31423 = NOVALUE;
    object _31422 = NOVALUE;
    object _31419 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:864		sequence errors = {}*/
    RefDS(_21997);
    DeRefi(_errors_64045);
    _errors_64045 = _21997;

    /** fwdref.e:865		for ar = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64042)){
            _31419 = SEQ_PTR(_refs_64042)->length;
    }
    else {
        _31419 = 1;
    }
    {
        object _ar_64047;
        _ar_64047 = _31419;
L1: 
        if (_ar_64047 < 1){
            goto L2; // [19] 481
        }

        /** fwdref.e:866			integer ref = refs[ar]*/
        _2 = (object)SEQ_PTR(_refs_64042);
        _ref_64049 = (object)*(((s1_ptr)_2)->base + _ar_64047);
        if (!IS_ATOM_INT(_ref_64049))
        _ref_64049 = (object)DBL_PTR(_ref_64049)->dbl;

        /** fwdref.e:868			sequence fr = forward_references[ref]*/
        DeRef(_fr_64051);
        _2 = (object)SEQ_PTR(_44forward_references_62769);
        _fr_64051 = (object)*(((s1_ptr)_2)->base + _ref_64049);
        Ref(_fr_64051);

        /** fwdref.e:869			if include_matrix[fr[FR_FILE]][current_file_no] = NOT_INCLUDED and not unincluded_ok then*/
        _2 = (object)SEQ_PTR(_fr_64051);
        _31422 = (object)*(((s1_ptr)_2)->base + 3);
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        if (!IS_ATOM_INT(_31422)){
            _31423 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31422)->dbl));
        }
        else{
            _31423 = (object)*(((s1_ptr)_2)->base + _31422);
        }
        _2 = (object)SEQ_PTR(_31423);
        _31424 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
        _31423 = NOVALUE;
        if (IS_ATOM_INT(_31424)) {
            _31425 = (_31424 == 0);
        }
        else {
            _31425 = binary_op(EQUALS, _31424, 0);
        }
        _31424 = NOVALUE;
        if (IS_ATOM_INT(_31425)) {
            if (_31425 == 0) {
                goto L3; // [66] 84
            }
        }
        else {
            if (DBL_PTR(_31425)->dbl == 0.0) {
                goto L3; // [66] 84
            }
        }
        _31427 = (_unincluded_ok_64044 == 0);
        if (_31427 == 0)
        {
            DeRef(_31427);
            _31427 = NOVALUE;
            goto L3; // [74] 84
        }
        else{
            DeRef(_31427);
            _31427 = NOVALUE;
        }

        /** fwdref.e:870				continue*/
        DeRef(_fr_64051);
        _fr_64051 = NOVALUE;
        DeRef(_tok_64064);
        _tok_64064 = NOVALUE;
        goto L4; // [81] 476
L3: 

        /** fwdref.e:873			token tok = find_reference( fr )*/
        RefDS(_fr_64051);
        _0 = _tok_64064;
        _tok_64064 = _44find_reference(_fr_64051);
        DeRef(_0);

        /** fwdref.e:874			if tok[T_ID] = IGNORED then*/
        _2 = (object)SEQ_PTR(_tok_64064);
        _31429 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _31429, 509)){
            _31429 = NOVALUE;
            goto L5; // [100] 117
        }
        _31429 = NOVALUE;

        /** fwdref.e:875				errors &= ref*/
        Append(&_errors_64045, _errors_64045, _ref_64049);

        /** fwdref.e:876				continue*/
        DeRefDS(_fr_64051);
        _fr_64051 = NOVALUE;
        DeRef(_tok_64064);
        _tok_64064 = NOVALUE;
        goto L4; // [114] 476
L5: 

        /** fwdref.e:880			integer code_sub = fr[FR_SUBPROG]*/
        _2 = (object)SEQ_PTR(_fr_64051);
        _code_sub_64072 = (object)*(((s1_ptr)_2)->base + 4);
        if (!IS_ATOM_INT(_code_sub_64072))
        _code_sub_64072 = (object)DBL_PTR(_code_sub_64072)->dbl;

        /** fwdref.e:881			integer fr_type  = fr[FR_TYPE]*/
        _2 = (object)SEQ_PTR(_fr_64051);
        _fr_type_64074 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_fr_type_64074))
        _fr_type_64074 = (object)DBL_PTR(_fr_type_64074)->dbl;

        /** fwdref.e:882			integer sym_tok*/

        /** fwdref.e:884			switch fr_type label "fr_type" do*/
        _0 = _fr_type_64074;
        switch ( _0 ){ 

            /** fwdref.e:885				case PROC, FUNC then*/
            case 27:
            case 501:

            /** fwdref.e:887					sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (object)SEQ_PTR(_tok_64064);
            _31437 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!IS_ATOM_INT(_31437)){
                _31438 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31437)->dbl));
            }
            else{
                _31438 = (object)*(((s1_ptr)_2)->base + _31437);
            }
            _2 = (object)SEQ_PTR(_31438);
            if (!IS_ATOM_INT(_36S_TOKEN_21089)){
                _sym_tok_64076 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
            }
            else{
                _sym_tok_64076 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
            }
            if (!IS_ATOM_INT(_sym_tok_64076)){
                _sym_tok_64076 = (object)DBL_PTR(_sym_tok_64076)->dbl;
            }
            _31438 = NOVALUE;

            /** fwdref.e:888					if sym_tok = TYPE then*/
            if (_sym_tok_64076 != 504)
            goto L6; // [170] 184

            /** fwdref.e:889						sym_tok = FUNC*/
            _sym_tok_64076 = 501;
L6: 

            /** fwdref.e:891					if sym_tok != fr_type then*/
            if (_sym_tok_64076 == _fr_type_64074)
            goto L7; // [186] 220

            /** fwdref.e:892						if sym_tok != FUNC and fr_type != PROC then*/
            _31442 = (_sym_tok_64076 != 501);
            if (_31442 == 0) {
                goto L8; // [198] 219
            }
            _31444 = (_fr_type_64074 != 27);
            if (_31444 == 0)
            {
                DeRef(_31444);
                _31444 = NOVALUE;
                goto L8; // [209] 219
            }
            else{
                DeRef(_31444);
                _31444 = NOVALUE;
            }

            /** fwdref.e:893							forward_error( tok, ref )*/
            Ref(_tok_64064);
            _44forward_error(_tok_64064, _ref_64049);
L8: 
L7: 

            /** fwdref.e:896					switch sym_tok do*/
            _0 = _sym_tok_64076;
            switch ( _0 ){ 

                /** fwdref.e:897						case PROC, FUNC then*/
                case 27:
                case 501:

                /** fwdref.e:898							patch_forward_call( tok, ref )*/
                Ref(_tok_64064);
                _44patch_forward_call(_tok_64064, _ref_64049);

                /** fwdref.e:899							break "fr_type"*/
                goto L9; // [241] 446
                goto L9; // [243] 446

                /** fwdref.e:901						case else*/
                default:

                /** fwdref.e:902							forward_error( tok, ref )*/
                Ref(_tok_64064);
                _44forward_error(_tok_64064, _ref_64049);
            ;}            goto L9; // [256] 446

            /** fwdref.e:906				case VARIABLE then*/
            case -100:

            /** fwdref.e:907					sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (object)SEQ_PTR(_tok_64064);
            _31447 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!IS_ATOM_INT(_31447)){
                _31448 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31447)->dbl));
            }
            else{
                _31448 = (object)*(((s1_ptr)_2)->base + _31447);
            }
            _2 = (object)SEQ_PTR(_31448);
            if (!IS_ATOM_INT(_36S_TOKEN_21089)){
                _sym_tok_64076 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
            }
            else{
                _sym_tok_64076 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
            }
            if (!IS_ATOM_INT(_sym_tok_64076)){
                _sym_tok_64076 = (object)DBL_PTR(_sym_tok_64076)->dbl;
            }
            _31448 = NOVALUE;

            /** fwdref.e:908					if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
            _2 = (object)SEQ_PTR(_tok_64064);
            _31450 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!IS_ATOM_INT(_31450)){
                _31451 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31450)->dbl));
            }
            else{
                _31451 = (object)*(((s1_ptr)_2)->base + _31450);
            }
            _2 = (object)SEQ_PTR(_31451);
            _31452 = (object)*(((s1_ptr)_2)->base + 4);
            _31451 = NOVALUE;
            if (binary_op_a(NOTEQ, _31452, 9)){
                _31452 = NOVALUE;
                goto LA; // [306] 323
            }
            _31452 = NOVALUE;

            /** fwdref.e:909						errors &= ref*/
            Append(&_errors_64045, _errors_64045, _ref_64049);

            /** fwdref.e:910						continue*/
            DeRef(_fr_64051);
            _fr_64051 = NOVALUE;
            DeRef(_tok_64064);
            _tok_64064 = NOVALUE;
            goto L4; // [320] 476
LA: 

            /** fwdref.e:913					switch sym_tok do*/
            _0 = _sym_tok_64076;
            switch ( _0 ){ 

                /** fwdref.e:914						case CONSTANT, ENUM, VARIABLE then*/
                case 417:
                case 427:
                case -100:

                /** fwdref.e:915							patch_forward_variable( tok, ref )*/
                Ref(_tok_64064);
                _44patch_forward_variable(_tok_64064, _ref_64049);

                /** fwdref.e:916							break "fr_type"*/
                goto L9; // [346] 446
                goto L9; // [348] 446

                /** fwdref.e:917						case else*/
                default:

                /** fwdref.e:918							forward_error( tok, ref )*/
                Ref(_tok_64064);
                _44forward_error(_tok_64064, _ref_64049);
            ;}            goto L9; // [361] 446

            /** fwdref.e:921				case TYPE_CHECK then*/
            case 65:

            /** fwdref.e:922					patch_forward_type_check( tok, ref )*/
            Ref(_tok_64064);
            _44patch_forward_type_check(_tok_64064, _ref_64049);
            goto L9; // [373] 446

            /** fwdref.e:924				case GLOBAL_INIT_CHECK then*/
            case 109:

            /** fwdref.e:925					patch_forward_init_check( tok, ref )*/
            Ref(_tok_64064);
            _44patch_forward_init_check(_tok_64064, _ref_64049);
            goto L9; // [385] 446

            /** fwdref.e:927				case CASE then*/
            case 186:

            /** fwdref.e:928					patch_forward_case( tok, ref )*/
            Ref(_tok_64064);
            _44patch_forward_case(_tok_64064, _ref_64049);
            goto L9; // [397] 446

            /** fwdref.e:930				case TYPE then*/
            case 504:

            /** fwdref.e:931					patch_forward_type( tok, ref )*/
            Ref(_tok_64064);
            _44patch_forward_type(_tok_64064, _ref_64049);
            goto L9; // [409] 446

            /** fwdref.e:933				case GOTO then*/
            case 188:

            /** fwdref.e:934					patch_forward_goto( tok, ref )*/
            Ref(_tok_64064);
            _44patch_forward_goto(_tok_64064, _ref_64049);
            goto L9; // [421] 446

            /** fwdref.e:936				case else*/
            default:

            /** fwdref.e:938					InternalErr( 263, {fr[FR_TYPE], fr[FR_NAME]})*/
            _2 = (object)SEQ_PTR(_fr_64051);
            _31457 = (object)*(((s1_ptr)_2)->base + 1);
            _2 = (object)SEQ_PTR(_fr_64051);
            _31458 = (object)*(((s1_ptr)_2)->base + 2);
            Ref(_31458);
            Ref(_31457);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _31457;
            ((intptr_t *)_2)[2] = _31458;
            _31459 = MAKE_SEQ(_1);
            _31458 = NOVALUE;
            _31457 = NOVALUE;
            _50InternalErr(263, _31459);
            _31459 = NOVALUE;
        ;}L9: 

        /** fwdref.e:940			if report_errors and sequence( forward_references[ref] ) then*/
        if (_report_errors_64043 == 0) {
            goto LB; // [448] 472
        }
        _2 = (object)SEQ_PTR(_44forward_references_62769);
        _31461 = (object)*(((s1_ptr)_2)->base + _ref_64049);
        _31462 = IS_SEQUENCE(_31461);
        _31461 = NOVALUE;
        if (_31462 == 0)
        {
            _31462 = NOVALUE;
            goto LB; // [462] 472
        }
        else{
            _31462 = NOVALUE;
        }

        /** fwdref.e:941				errors &= ref*/
        Append(&_errors_64045, _errors_64045, _ref_64049);
LB: 
        DeRef(_fr_64051);
        _fr_64051 = NOVALUE;
        DeRef(_tok_64064);
        _tok_64064 = NOVALUE;

        /** fwdref.e:944		end for*/
L4: 
        _ar_64047 = _ar_64047 + -1;
        goto L1; // [476] 26
L2: 
        ;
    }

    /** fwdref.e:945		return errors*/
    DeRefDS(_refs_64042);
    _31450 = NOVALUE;
    _31437 = NOVALUE;
    DeRef(_31442);
    _31442 = NOVALUE;
    DeRef(_31425);
    _31425 = NOVALUE;
    _31422 = NOVALUE;
    _31447 = NOVALUE;
    return _errors_64045;
    ;
}


object _44file_name_based_symindex_compare(object _si1_64154, object _si2_64155)
{
    object _fn1_64176 = NOVALUE;
    object _fn2_64181 = NOVALUE;
    object _31491 = NOVALUE;
    object _31490 = NOVALUE;
    object _31489 = NOVALUE;
    object _31488 = NOVALUE;
    object _31487 = NOVALUE;
    object _31486 = NOVALUE;
    object _31485 = NOVALUE;
    object _31484 = NOVALUE;
    object _31483 = NOVALUE;
    object _31482 = NOVALUE;
    object _31481 = NOVALUE;
    object _31480 = NOVALUE;
    object _31478 = NOVALUE;
    object _31476 = NOVALUE;
    object _31475 = NOVALUE;
    object _31474 = NOVALUE;
    object _31473 = NOVALUE;
    object _31472 = NOVALUE;
    object _31471 = NOVALUE;
    object _31470 = NOVALUE;
    object _31469 = NOVALUE;
    object _31468 = NOVALUE;
    object _31467 = NOVALUE;
    object _31465 = NOVALUE;
    object _31464 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_si1_64154)) {
        _1 = (object)(DBL_PTR(_si1_64154)->dbl);
        DeRefDS(_si1_64154);
        _si1_64154 = _1;
    }
    if (!IS_ATOM_INT(_si2_64155)) {
        _1 = (object)(DBL_PTR(_si2_64155)->dbl);
        DeRefDS(_si2_64155);
        _si2_64155 = _1;
    }

    /** fwdref.e:949		if not symtab_index(si1) or not symtab_index(si2) then*/
    _31464 = _36symtab_index(_si1_64154);
    if (IS_ATOM_INT(_31464)) {
        _31465 = (_31464 == 0);
    }
    else {
        _31465 = unary_op(NOT, _31464);
    }
    DeRef(_31464);
    _31464 = NOVALUE;
    if (IS_ATOM_INT(_31465)) {
        if (_31465 != 0) {
            goto L1; // [14] 30
        }
    }
    else {
        if (DBL_PTR(_31465)->dbl != 0.0) {
            goto L1; // [14] 30
        }
    }
    _31467 = _36symtab_index(_si2_64155);
    if (IS_ATOM_INT(_31467)) {
        _31468 = (_31467 == 0);
    }
    else {
        _31468 = unary_op(NOT, _31467);
    }
    DeRef(_31467);
    _31467 = NOVALUE;
    if (_31468 == 0) {
        DeRef(_31468);
        _31468 = NOVALUE;
        goto L2; // [26] 37
    }
    else {
        if (!IS_ATOM_INT(_31468) && DBL_PTR(_31468)->dbl == 0.0){
            DeRef(_31468);
            _31468 = NOVALUE;
            goto L2; // [26] 37
        }
        DeRef(_31468);
        _31468 = NOVALUE;
    }
    DeRef(_31468);
    _31468 = NOVALUE;
L1: 

    /** fwdref.e:950			return 1 -- put non symbols last*/
    DeRef(_31465);
    _31465 = NOVALUE;
    return 1;
L2: 

    /** fwdref.e:952		if S_FILE_NO <= length(SymTab[si1]) and S_FILE_NO <= length(SymTab[si2]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31469 = (object)*(((s1_ptr)_2)->base + _si1_64154);
    if (IS_SEQUENCE(_31469)){
            _31470 = SEQ_PTR(_31469)->length;
    }
    else {
        _31470 = 1;
    }
    _31469 = NOVALUE;
    if (IS_ATOM_INT(_36S_FILE_NO_21080)) {
        _31471 = (_36S_FILE_NO_21080 <= _31470);
    }
    else {
        _31471 = binary_op(LESSEQ, _36S_FILE_NO_21080, _31470);
    }
    _31470 = NOVALUE;
    if (IS_ATOM_INT(_31471)) {
        if (_31471 == 0) {
            goto L3; // [54] 186
        }
    }
    else {
        if (DBL_PTR(_31471)->dbl == 0.0) {
            goto L3; // [54] 186
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31473 = (object)*(((s1_ptr)_2)->base + _si2_64155);
    if (IS_SEQUENCE(_31473)){
            _31474 = SEQ_PTR(_31473)->length;
    }
    else {
        _31474 = 1;
    }
    _31473 = NOVALUE;
    if (IS_ATOM_INT(_36S_FILE_NO_21080)) {
        _31475 = (_36S_FILE_NO_21080 <= _31474);
    }
    else {
        _31475 = binary_op(LESSEQ, _36S_FILE_NO_21080, _31474);
    }
    _31474 = NOVALUE;
    if (_31475 == 0) {
        DeRef(_31475);
        _31475 = NOVALUE;
        goto L3; // [74] 186
    }
    else {
        if (!IS_ATOM_INT(_31475) && DBL_PTR(_31475)->dbl == 0.0){
            DeRef(_31475);
            _31475 = NOVALUE;
            goto L3; // [74] 186
        }
        DeRef(_31475);
        _31475 = NOVALUE;
    }
    DeRef(_31475);
    _31475 = NOVALUE;

    /** fwdref.e:953			integer fn1 = SymTab[si1][S_FILE_NO], fn2 = SymTab[si2][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31476 = (object)*(((s1_ptr)_2)->base + _si1_64154);
    _2 = (object)SEQ_PTR(_31476);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _fn1_64176 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _fn1_64176 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    if (!IS_ATOM_INT(_fn1_64176)){
        _fn1_64176 = (object)DBL_PTR(_fn1_64176)->dbl;
    }
    _31476 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31478 = (object)*(((s1_ptr)_2)->base + _si2_64155);
    _2 = (object)SEQ_PTR(_31478);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _fn2_64181 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _fn2_64181 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    if (!IS_ATOM_INT(_fn2_64181)){
        _fn2_64181 = (object)DBL_PTR(_fn2_64181)->dbl;
    }
    _31478 = NOVALUE;

    /** fwdref.e:954			if find(1,{fn1,fn2} > length(known_files) or {fn1,fn2} <= 0) then*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _fn1_64176;
    ((intptr_t *)_2)[2] = _fn2_64181;
    _31480 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_37known_files_15407)){
            _31481 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _31481 = 1;
    }
    _31482 = binary_op(GREATER, _31480, _31481);
    DeRefDS(_31480);
    _31480 = NOVALUE;
    _31481 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _fn1_64176;
    ((intptr_t *)_2)[2] = _fn2_64181;
    _31483 = MAKE_SEQ(_1);
    _31484 = binary_op(LESSEQ, _31483, 0);
    DeRefDS(_31483);
    _31483 = NOVALUE;
    _31485 = binary_op(OR, _31482, _31484);
    DeRefDS(_31482);
    _31482 = NOVALUE;
    DeRefDS(_31484);
    _31484 = NOVALUE;
    _31486 = find_from(1, _31485, 1);
    DeRefDS(_31485);
    _31485 = NOVALUE;
    if (_31486 == 0)
    {
        _31486 = NOVALUE;
        goto L4; // [139] 149
    }
    else{
        _31486 = NOVALUE;
    }

    /** fwdref.e:956				return 1*/
    DeRef(_31471);
    _31471 = NOVALUE;
    DeRef(_31465);
    _31465 = NOVALUE;
    _31473 = NOVALUE;
    _31469 = NOVALUE;
    return 1;
L4: 

    /** fwdref.e:958			return compare(abbreviate_path(known_files[fn1]),*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _31487 = (object)*(((s1_ptr)_2)->base + _fn1_64176);
    Ref(_31487);
    RefDS(_21997);
    _31488 = _17abbreviate_path(_31487, _21997);
    _31487 = NOVALUE;
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _31489 = (object)*(((s1_ptr)_2)->base + _fn2_64181);
    Ref(_31489);
    RefDS(_21997);
    _31490 = _17abbreviate_path(_31489, _21997);
    _31489 = NOVALUE;
    if (IS_ATOM_INT(_31488) && IS_ATOM_INT(_31490)){
        _31491 = (_31488 < _31490) ? -1 : (_31488 > _31490);
    }
    else{
        _31491 = compare(_31488, _31490);
    }
    DeRef(_31488);
    _31488 = NOVALUE;
    DeRef(_31490);
    _31490 = NOVALUE;
    DeRef(_31471);
    _31471 = NOVALUE;
    DeRef(_31465);
    _31465 = NOVALUE;
    _31473 = NOVALUE;
    _31469 = NOVALUE;
    return _31491;
    goto L5; // [183] 193
L3: 

    /** fwdref.e:961			return 1 -- put non-names last*/
    DeRef(_31471);
    _31471 = NOVALUE;
    DeRef(_31465);
    _31465 = NOVALUE;
    _31473 = NOVALUE;
    _31469 = NOVALUE;
    return 1;
L5: 
    ;
}


void _44Resolve_forward_references(object _report_errors_64207)
{
    object _errors_64208 = NOVALUE;
    object _unincluded_ok_64209 = NOVALUE;
    object _msg_64270 = NOVALUE;
    object _errloc_64271 = NOVALUE;
    object _ref_64276 = NOVALUE;
    object _tok_64292 = NOVALUE;
    object _THIS_SCOPE_64294 = NOVALUE;
    object _THESE_GLOBALS_64295 = NOVALUE;
    object _syms_64353 = NOVALUE;
    object _s_64374 = NOVALUE;
    object _31624 = NOVALUE;
    object _31623 = NOVALUE;
    object _31622 = NOVALUE;
    object _31620 = NOVALUE;
    object _31615 = NOVALUE;
    object _31612 = NOVALUE;
    object _31610 = NOVALUE;
    object _31609 = NOVALUE;
    object _31608 = NOVALUE;
    object _31607 = NOVALUE;
    object _31606 = NOVALUE;
    object _31605 = NOVALUE;
    object _31604 = NOVALUE;
    object _31602 = NOVALUE;
    object _31601 = NOVALUE;
    object _31600 = NOVALUE;
    object _31598 = NOVALUE;
    object _31596 = NOVALUE;
    object _31595 = NOVALUE;
    object _31594 = NOVALUE;
    object _31593 = NOVALUE;
    object _31592 = NOVALUE;
    object _31591 = NOVALUE;
    object _31588 = NOVALUE;
    object _31584 = NOVALUE;
    object _31583 = NOVALUE;
    object _31582 = NOVALUE;
    object _31581 = NOVALUE;
    object _31580 = NOVALUE;
    object _31579 = NOVALUE;
    object _31576 = NOVALUE;
    object _31575 = NOVALUE;
    object _31574 = NOVALUE;
    object _31573 = NOVALUE;
    object _31572 = NOVALUE;
    object _31571 = NOVALUE;
    object _31568 = NOVALUE;
    object _31567 = NOVALUE;
    object _31566 = NOVALUE;
    object _31565 = NOVALUE;
    object _31564 = NOVALUE;
    object _31563 = NOVALUE;
    object _31562 = NOVALUE;
    object _31561 = NOVALUE;
    object _31560 = NOVALUE;
    object _31559 = NOVALUE;
    object _31556 = NOVALUE;
    object _31554 = NOVALUE;
    object _31551 = NOVALUE;
    object _31549 = NOVALUE;
    object _31547 = NOVALUE;
    object _31546 = NOVALUE;
    object _31544 = NOVALUE;
    object _31543 = NOVALUE;
    object _31542 = NOVALUE;
    object _31541 = NOVALUE;
    object _31540 = NOVALUE;
    object _31538 = NOVALUE;
    object _31537 = NOVALUE;
    object _31535 = NOVALUE;
    object _31534 = NOVALUE;
    object _31532 = NOVALUE;
    object _31531 = NOVALUE;
    object _31529 = NOVALUE;
    object _31528 = NOVALUE;
    object _31527 = NOVALUE;
    object _31526 = NOVALUE;
    object _31525 = NOVALUE;
    object _31524 = NOVALUE;
    object _31523 = NOVALUE;
    object _31522 = NOVALUE;
    object _31521 = NOVALUE;
    object _31520 = NOVALUE;
    object _31519 = NOVALUE;
    object _31518 = NOVALUE;
    object _31517 = NOVALUE;
    object _31516 = NOVALUE;
    object _31515 = NOVALUE;
    object _31514 = NOVALUE;
    object _31512 = NOVALUE;
    object _31511 = NOVALUE;
    object _31510 = NOVALUE;
    object _31509 = NOVALUE;
    object _31507 = NOVALUE;
    object _31506 = NOVALUE;
    object _31504 = NOVALUE;
    object _31503 = NOVALUE;
    object _31502 = NOVALUE;
    object _31501 = NOVALUE;
    object _31499 = NOVALUE;
    object _31498 = NOVALUE;
    object _31497 = NOVALUE;
    object _31496 = NOVALUE;
    object _31494 = NOVALUE;
    object _31493 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:966		sequence errors = {}*/
    RefDS(_21997);
    DeRef(_errors_64208);
    _errors_64208 = _21997;

    /** fwdref.e:967		integer unincluded_ok = get_resolve_unincluded_globals()*/
    _unincluded_ok_64209 = _54get_resolve_unincluded_globals();
    if (!IS_ATOM_INT(_unincluded_ok_64209)) {
        _1 = (object)(DBL_PTR(_unincluded_ok_64209)->dbl);
        DeRefDS(_unincluded_ok_64209);
        _unincluded_ok_64209 = _1;
    }

    /** fwdref.e:969		if length( active_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_44active_references_62771)){
            _31493 = SEQ_PTR(_44active_references_62771)->length;
    }
    else {
        _31493 = 1;
    }
    if (IS_SEQUENCE(_37known_files_15407)){
            _31494 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _31494 = 1;
    }
    if (_31493 >= _31494)
    goto L1; // [29] 86

    /** fwdref.e:970			active_references &= repeat( {}, length( known_files ) - length( active_references ) )*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _31496 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _31496 = 1;
    }
    if (IS_SEQUENCE(_44active_references_62771)){
            _31497 = SEQ_PTR(_44active_references_62771)->length;
    }
    else {
        _31497 = 1;
    }
    _31498 = _31496 - _31497;
    _31496 = NOVALUE;
    _31497 = NOVALUE;
    _31499 = Repeat(_21997, _31498);
    _31498 = NOVALUE;
    Concat((object_ptr)&_44active_references_62771, _44active_references_62771, _31499);
    DeRefDS(_31499);
    _31499 = NOVALUE;

    /** fwdref.e:971			active_subprogs   &= repeat( {}, length( known_files ) - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _31501 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _31501 = 1;
    }
    if (IS_SEQUENCE(_44active_subprogs_62770)){
            _31502 = SEQ_PTR(_44active_subprogs_62770)->length;
    }
    else {
        _31502 = 1;
    }
    _31503 = _31501 - _31502;
    _31501 = NOVALUE;
    _31502 = NOVALUE;
    _31504 = Repeat(_21997, _31503);
    _31503 = NOVALUE;
    Concat((object_ptr)&_44active_subprogs_62770, _44active_subprogs_62770, _31504);
    DeRefDS(_31504);
    _31504 = NOVALUE;
L1: 

    /** fwdref.e:974		if length( toplevel_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_44toplevel_references_62772)){
            _31506 = SEQ_PTR(_44toplevel_references_62772)->length;
    }
    else {
        _31506 = 1;
    }
    if (IS_SEQUENCE(_37known_files_15407)){
            _31507 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _31507 = 1;
    }
    if (_31506 >= _31507)
    goto L2; // [98] 129

    /** fwdref.e:975			toplevel_references &= repeat( {}, length( known_files ) - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _31509 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _31509 = 1;
    }
    if (IS_SEQUENCE(_44toplevel_references_62772)){
            _31510 = SEQ_PTR(_44toplevel_references_62772)->length;
    }
    else {
        _31510 = 1;
    }
    _31511 = _31509 - _31510;
    _31509 = NOVALUE;
    _31510 = NOVALUE;
    _31512 = Repeat(_21997, _31511);
    _31511 = NOVALUE;
    Concat((object_ptr)&_44toplevel_references_62772, _44toplevel_references_62772, _31512);
    DeRefDS(_31512);
    _31512 = NOVALUE;
L2: 

    /** fwdref.e:978		for i = 1 to length( active_subprogs ) do*/
    if (IS_SEQUENCE(_44active_subprogs_62770)){
            _31514 = SEQ_PTR(_44active_subprogs_62770)->length;
    }
    else {
        _31514 = 1;
    }
    {
        object _i_64241;
        _i_64241 = 1;
L3: 
        if (_i_64241 > _31514){
            goto L4; // [136] 280
        }

        /** fwdref.e:979			if (length( active_subprogs[i] ) or length(toplevel_references[i])) */
        _2 = (object)SEQ_PTR(_44active_subprogs_62770);
        _31515 = (object)*(((s1_ptr)_2)->base + _i_64241);
        if (IS_SEQUENCE(_31515)){
                _31516 = SEQ_PTR(_31515)->length;
        }
        else {
            _31516 = 1;
        }
        _31515 = NOVALUE;
        if (_31516 != 0) {
            _31517 = 1;
            goto L5; // [154] 171
        }
        _2 = (object)SEQ_PTR(_44toplevel_references_62772);
        _31518 = (object)*(((s1_ptr)_2)->base + _i_64241);
        if (IS_SEQUENCE(_31518)){
                _31519 = SEQ_PTR(_31518)->length;
        }
        else {
            _31519 = 1;
        }
        _31518 = NOVALUE;
        _31517 = (_31519 != 0);
L5: 
        if (_31517 == 0) {
            goto L6; // [171] 273
        }
        _31521 = (_i_64241 == _36current_file_no_21447);
        if (_31521 != 0) {
            _31522 = 1;
            goto L7; // [181] 195
        }
        _2 = (object)SEQ_PTR(_37finished_files_15409);
        _31523 = (object)*(((s1_ptr)_2)->base + _i_64241);
        _31522 = (_31523 != 0);
L7: 
        if (_31522 != 0) {
            DeRef(_31524);
            _31524 = 1;
            goto L8; // [195] 203
        }
        _31524 = (_unincluded_ok_64209 != 0);
L8: 
        if (_31524 == 0)
        {
            _31524 = NOVALUE;
            goto L6; // [204] 273
        }
        else{
            _31524 = NOVALUE;
        }

        /** fwdref.e:982				for j = length( active_references[i] ) to 1 by -1 do*/
        _2 = (object)SEQ_PTR(_44active_references_62771);
        _31525 = (object)*(((s1_ptr)_2)->base + _i_64241);
        if (IS_SEQUENCE(_31525)){
                _31526 = SEQ_PTR(_31525)->length;
        }
        else {
            _31526 = 1;
        }
        _31525 = NOVALUE;
        {
            object _j_64257;
            _j_64257 = _31526;
L9: 
            if (_j_64257 < 1){
                goto LA; // [218] 254
            }

            /** fwdref.e:983					errors &= resolve_file( active_references[i][j], report_errors, unincluded_ok )*/
            _2 = (object)SEQ_PTR(_44active_references_62771);
            _31527 = (object)*(((s1_ptr)_2)->base + _i_64241);
            _2 = (object)SEQ_PTR(_31527);
            _31528 = (object)*(((s1_ptr)_2)->base + _j_64257);
            _31527 = NOVALUE;
            Ref(_31528);
            _31529 = _44resolve_file(_31528, _report_errors_64207, _unincluded_ok_64209);
            _31528 = NOVALUE;
            if (IS_SEQUENCE(_errors_64208) && IS_ATOM(_31529)) {
                Ref(_31529);
                Append(&_errors_64208, _errors_64208, _31529);
            }
            else if (IS_ATOM(_errors_64208) && IS_SEQUENCE(_31529)) {
            }
            else {
                Concat((object_ptr)&_errors_64208, _errors_64208, _31529);
            }
            DeRef(_31529);
            _31529 = NOVALUE;

            /** fwdref.e:984				end for*/
            _j_64257 = _j_64257 + -1;
            goto L9; // [249] 225
LA: 
            ;
        }

        /** fwdref.e:985				errors &= resolve_file( toplevel_references[i], report_errors, unincluded_ok )*/
        _2 = (object)SEQ_PTR(_44toplevel_references_62772);
        _31531 = (object)*(((s1_ptr)_2)->base + _i_64241);
        Ref(_31531);
        _31532 = _44resolve_file(_31531, _report_errors_64207, _unincluded_ok_64209);
        _31531 = NOVALUE;
        if (IS_SEQUENCE(_errors_64208) && IS_ATOM(_31532)) {
            Ref(_31532);
            Append(&_errors_64208, _errors_64208, _31532);
        }
        else if (IS_ATOM(_errors_64208) && IS_SEQUENCE(_31532)) {
        }
        else {
            Concat((object_ptr)&_errors_64208, _errors_64208, _31532);
        }
        DeRef(_31532);
        _31532 = NOVALUE;
L6: 

        /** fwdref.e:987		end for*/
        _i_64241 = _i_64241 + 1;
        goto L3; // [275] 143
L4: 
        ;
    }

    /** fwdref.e:989		if report_errors and length( errors ) then*/
    if (_report_errors_64207 == 0) {
        goto LB; // [282] 856
    }
    if (IS_SEQUENCE(_errors_64208)){
            _31535 = SEQ_PTR(_errors_64208)->length;
    }
    else {
        _31535 = 1;
    }
    if (_31535 == 0)
    {
        _31535 = NOVALUE;
        goto LB; // [290] 856
    }
    else{
        _31535 = NOVALUE;
    }

    /** fwdref.e:990			sequence msg = ""*/
    RefDS(_21997);
    DeRefi(_msg_64270);
    _msg_64270 = _21997;

    /** fwdref.e:991			sequence errloc = "Internal Error - Unknown Error Message"*/
    RefDS(_31536);
    DeRefi(_errloc_64271);
    _errloc_64271 = _31536;

    /** fwdref.e:993			for e = length(errors) to 1 by -1 do*/
    if (IS_SEQUENCE(_errors_64208)){
            _31537 = SEQ_PTR(_errors_64208)->length;
    }
    else {
        _31537 = 1;
    }
    {
        object _e_64274;
        _e_64274 = _31537;
LC: 
        if (_e_64274 < 1){
            goto LD; // [312] 828
        }

        /** fwdref.e:994				sequence ref = forward_references[errors[e]]*/
        _2 = (object)SEQ_PTR(_errors_64208);
        _31538 = (object)*(((s1_ptr)_2)->base + _e_64274);
        DeRef(_ref_64276);
        _2 = (object)SEQ_PTR(_44forward_references_62769);
        if (!IS_ATOM_INT(_31538)){
            _ref_64276 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31538)->dbl));
        }
        else{
            _ref_64276 = (object)*(((s1_ptr)_2)->base + _31538);
        }
        Ref(_ref_64276);

        /** fwdref.e:995				if (ref[FR_TYPE] = TYPE_CHECK and ref[FR_OP] = TYPE_CHECK) or ref[FR_TYPE] = GLOBAL_INIT_CHECK then*/
        _2 = (object)SEQ_PTR(_ref_64276);
        _31540 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31540)) {
            _31541 = (_31540 == 65);
        }
        else {
            _31541 = binary_op(EQUALS, _31540, 65);
        }
        _31540 = NOVALUE;
        if (IS_ATOM_INT(_31541)) {
            if (_31541 == 0) {
                DeRef(_31542);
                _31542 = 0;
                goto LE; // [345] 363
            }
        }
        else {
            if (DBL_PTR(_31541)->dbl == 0.0) {
                DeRef(_31542);
                _31542 = 0;
                goto LE; // [345] 363
            }
        }
        _2 = (object)SEQ_PTR(_ref_64276);
        _31543 = (object)*(((s1_ptr)_2)->base + 10);
        if (IS_ATOM_INT(_31543)) {
            _31544 = (_31543 == 65);
        }
        else {
            _31544 = binary_op(EQUALS, _31543, 65);
        }
        _31543 = NOVALUE;
        DeRef(_31542);
        if (IS_ATOM_INT(_31544))
        _31542 = (_31544 != 0);
        else
        _31542 = DBL_PTR(_31544)->dbl != 0.0;
LE: 
        if (_31542 != 0) {
            goto LF; // [363] 382
        }
        _2 = (object)SEQ_PTR(_ref_64276);
        _31546 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31546)) {
            _31547 = (_31546 == 109);
        }
        else {
            _31547 = binary_op(EQUALS, _31546, 109);
        }
        _31546 = NOVALUE;
        if (_31547 == 0) {
            DeRef(_31547);
            _31547 = NOVALUE;
            goto L10; // [378] 391
        }
        else {
            if (!IS_ATOM_INT(_31547) && DBL_PTR(_31547)->dbl == 0.0){
                DeRef(_31547);
                _31547 = NOVALUE;
                goto L10; // [378] 391
            }
            DeRef(_31547);
            _31547 = NOVALUE;
        }
        DeRef(_31547);
        _31547 = NOVALUE;
LF: 

        /** fwdref.e:997					continue*/
        DeRef(_ref_64276);
        _ref_64276 = NOVALUE;
        goto L11; // [386] 823
        goto L12; // [388] 789
L10: 

        /** fwdref.e:1001					object tok = find_reference(ref)*/
        RefDS(_ref_64276);
        _0 = _tok_64292;
        _tok_64292 = _44find_reference(_ref_64276);
        DeRef(_0);

        /** fwdref.e:1002					integer THIS_SCOPE = 3*/
        _THIS_SCOPE_64294 = 3;

        /** fwdref.e:1003					integer THESE_GLOBALS = 4*/
        _THESE_GLOBALS_64295 = 4;

        /** fwdref.e:1004					if tok[T_ID] = IGNORED then*/
        _2 = (object)SEQ_PTR(_tok_64292);
        _31549 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _31549, 509)){
            _31549 = NOVALUE;
            goto L13; // [417] 760
        }
        _31549 = NOVALUE;

        /** fwdref.e:1006						switch tok[THIS_SCOPE] do*/
        _2 = (object)SEQ_PTR(_tok_64292);
        _31551 = (object)*(((s1_ptr)_2)->base + 3);
        if (IS_SEQUENCE(_31551) ){
            goto L14; // [427] 756
        }
        if(!IS_ATOM_INT(_31551)){
            if( (DBL_PTR(_31551)->dbl != (eudouble) ((object) DBL_PTR(_31551)->dbl) ) ){
                goto L14; // [427] 756
            }
            _0 = (object) DBL_PTR(_31551)->dbl;
        }
        else {
            _0 = _31551;
        };
        _31551 = NOVALUE;
        switch ( _0 ){ 

            /** fwdref.e:1007							case SC_UNDEFINED then*/
            case 9:

            /** fwdref.e:1008								if ref[FR_QUALIFIED] != -1 then*/
            _2 = (object)SEQ_PTR(_ref_64276);
            _31554 = (object)*(((s1_ptr)_2)->base + 9);
            if (binary_op_a(EQUALS, _31554, -1)){
                _31554 = NOVALUE;
                goto L15; // [442] 556
            }
            _31554 = NOVALUE;

            /** fwdref.e:1009									if ref[FR_QUALIFIED] > 0 then*/
            _2 = (object)SEQ_PTR(_ref_64276);
            _31556 = (object)*(((s1_ptr)_2)->base + 9);
            if (binary_op_a(LESSEQ, _31556, 0)){
                _31556 = NOVALUE;
                goto L16; // [452] 517
            }
            _31556 = NOVALUE;

            /** fwdref.e:1011										errloc = sprintf("\t\'%s\' (%s:%d) was not declared in \'%s\'.\n", */
            _2 = (object)SEQ_PTR(_ref_64276);
            _31559 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_ref_64276);
            _31560 = (object)*(((s1_ptr)_2)->base + 3);
            _2 = (object)SEQ_PTR(_37known_files_15407);
            if (!IS_ATOM_INT(_31560)){
                _31561 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31560)->dbl));
            }
            else{
                _31561 = (object)*(((s1_ptr)_2)->base + _31560);
            }
            Ref(_31561);
            RefDS(_21997);
            _31562 = _17abbreviate_path(_31561, _21997);
            _31561 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64276);
            _31563 = (object)*(((s1_ptr)_2)->base + 6);
            _2 = (object)SEQ_PTR(_ref_64276);
            _31564 = (object)*(((s1_ptr)_2)->base + 9);
            _2 = (object)SEQ_PTR(_37known_files_15407);
            if (!IS_ATOM_INT(_31564)){
                _31565 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31564)->dbl));
            }
            else{
                _31565 = (object)*(((s1_ptr)_2)->base + _31564);
            }
            Ref(_31565);
            RefDS(_21997);
            _31566 = _17abbreviate_path(_31565, _21997);
            _31565 = NOVALUE;
            _31567 = _16find_replace(92, _31566, 47, 0);
            _31566 = NOVALUE;
            _1 = NewS1(4);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31559);
            ((intptr_t*)_2)[1] = _31559;
            ((intptr_t*)_2)[2] = _31562;
            Ref(_31563);
            ((intptr_t*)_2)[3] = _31563;
            ((intptr_t*)_2)[4] = _31567;
            _31568 = MAKE_SEQ(_1);
            _31567 = NOVALUE;
            _31563 = NOVALUE;
            _31562 = NOVALUE;
            _31559 = NOVALUE;
            DeRefi(_errloc_64271);
            _errloc_64271 = EPrintf(-9999999, _31558, _31568);
            DeRefDS(_31568);
            _31568 = NOVALUE;
            goto L17; // [514] 759
L16: 

            /** fwdref.e:1016										errloc = sprintf("\t\'%s\' (%s:%d) is not a builtin.\n", */
            _2 = (object)SEQ_PTR(_ref_64276);
            _31571 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_ref_64276);
            _31572 = (object)*(((s1_ptr)_2)->base + 3);
            _2 = (object)SEQ_PTR(_37known_files_15407);
            if (!IS_ATOM_INT(_31572)){
                _31573 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31572)->dbl));
            }
            else{
                _31573 = (object)*(((s1_ptr)_2)->base + _31572);
            }
            Ref(_31573);
            RefDS(_21997);
            _31574 = _17abbreviate_path(_31573, _21997);
            _31573 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64276);
            _31575 = (object)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31571);
            ((intptr_t*)_2)[1] = _31571;
            ((intptr_t*)_2)[2] = _31574;
            Ref(_31575);
            ((intptr_t*)_2)[3] = _31575;
            _31576 = MAKE_SEQ(_1);
            _31575 = NOVALUE;
            _31574 = NOVALUE;
            _31571 = NOVALUE;
            DeRefi(_errloc_64271);
            _errloc_64271 = EPrintf(-9999999, _31570, _31576);
            DeRefDS(_31576);
            _31576 = NOVALUE;
            goto L17; // [553] 759
L15: 

            /** fwdref.e:1021									errloc = sprintf("\t\'%s\' (%s:%d) has not been declared.\n", */
            _2 = (object)SEQ_PTR(_ref_64276);
            _31579 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_ref_64276);
            _31580 = (object)*(((s1_ptr)_2)->base + 3);
            _2 = (object)SEQ_PTR(_37known_files_15407);
            if (!IS_ATOM_INT(_31580)){
                _31581 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31580)->dbl));
            }
            else{
                _31581 = (object)*(((s1_ptr)_2)->base + _31580);
            }
            Ref(_31581);
            RefDS(_21997);
            _31582 = _17abbreviate_path(_31581, _21997);
            _31581 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64276);
            _31583 = (object)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31579);
            ((intptr_t*)_2)[1] = _31579;
            ((intptr_t*)_2)[2] = _31582;
            Ref(_31583);
            ((intptr_t*)_2)[3] = _31583;
            _31584 = MAKE_SEQ(_1);
            _31583 = NOVALUE;
            _31582 = NOVALUE;
            _31579 = NOVALUE;
            DeRefi(_errloc_64271);
            _errloc_64271 = EPrintf(-9999999, _31578, _31584);
            DeRefDS(_31584);
            _31584 = NOVALUE;
            goto L17; // [592] 759

            /** fwdref.e:1024							case SC_MULTIPLY_DEFINED then*/
            case 10:

            /** fwdref.e:1025								sequence syms = tok[THESE_GLOBALS] -- there should be no forward references in here.*/
            DeRef(_syms_64353);
            _2 = (object)SEQ_PTR(_tok_64292);
            _syms_64353 = (object)*(((s1_ptr)_2)->base + _THESE_GLOBALS_64295);
            Ref(_syms_64353);

            /** fwdref.e:1026								syms = custom_sort(routine_id("file_name_based_symindex_compare"), syms,, ASCENDING)*/
            _31588 = CRoutineId(1382, 44, _31587);
            RefDS(_syms_64353);
            RefDS(_21997);
            _0 = _syms_64353;
            _syms_64353 = _24custom_sort(_31588, _syms_64353, _21997, 1);
            DeRefDS(_0);
            _31588 = NOVALUE;

            /** fwdref.e:1027								errloc = sprintf("\t\'%s\' (%s:%d) has been declared more than once.\n", */
            _2 = (object)SEQ_PTR(_ref_64276);
            _31591 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_ref_64276);
            _31592 = (object)*(((s1_ptr)_2)->base + 3);
            _2 = (object)SEQ_PTR(_37known_files_15407);
            if (!IS_ATOM_INT(_31592)){
                _31593 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31592)->dbl));
            }
            else{
                _31593 = (object)*(((s1_ptr)_2)->base + _31592);
            }
            Ref(_31593);
            RefDS(_21997);
            _31594 = _17abbreviate_path(_31593, _21997);
            _31593 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64276);
            _31595 = (object)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31591);
            ((intptr_t*)_2)[1] = _31591;
            ((intptr_t*)_2)[2] = _31594;
            Ref(_31595);
            ((intptr_t*)_2)[3] = _31595;
            _31596 = MAKE_SEQ(_1);
            _31595 = NOVALUE;
            _31594 = NOVALUE;
            _31591 = NOVALUE;
            DeRefi(_errloc_64271);
            _errloc_64271 = EPrintf(-9999999, _31590, _31596);
            DeRefDS(_31596);
            _31596 = NOVALUE;

            /** fwdref.e:1029								for si = 1 to length(syms) do*/
            if (IS_SEQUENCE(_syms_64353)){
                    _31598 = SEQ_PTR(_syms_64353)->length;
            }
            else {
                _31598 = 1;
            }
            {
                object _si_64371;
                _si_64371 = 1;
L18: 
                if (_si_64371 > _31598){
                    goto L19; // [664] 750
                }

                /** fwdref.e:1030									symtab_index s = syms[si] */
                _2 = (object)SEQ_PTR(_syms_64353);
                _s_64374 = (object)*(((s1_ptr)_2)->base + _si_64371);
                if (!IS_ATOM_INT(_s_64374)){
                    _s_64374 = (object)DBL_PTR(_s_64374)->dbl;
                }

                /** fwdref.e:1031									if equal(ref[FR_NAME], sym_name(s)) then*/
                _2 = (object)SEQ_PTR(_ref_64276);
                _31600 = (object)*(((s1_ptr)_2)->base + 2);
                _31601 = _54sym_name(_s_64374);
                if (_31600 == _31601)
                _31602 = 1;
                else if (IS_ATOM_INT(_31600) && IS_ATOM_INT(_31601))
                _31602 = 0;
                else
                _31602 = (compare(_31600, _31601) == 0);
                _31600 = NOVALUE;
                DeRef(_31601);
                _31601 = NOVALUE;
                if (_31602 == 0)
                {
                    _31602 = NOVALUE;
                    goto L1A; // [693] 741
                }
                else{
                    _31602 = NOVALUE;
                }

                /** fwdref.e:1032										errloc &= sprintf("\t\tin %s\n", */
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _31604 = (object)*(((s1_ptr)_2)->base + _s_64374);
                _2 = (object)SEQ_PTR(_31604);
                if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
                    _31605 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
                }
                else{
                    _31605 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
                }
                _31604 = NOVALUE;
                _2 = (object)SEQ_PTR(_37known_files_15407);
                if (!IS_ATOM_INT(_31605)){
                    _31606 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31605)->dbl));
                }
                else{
                    _31606 = (object)*(((s1_ptr)_2)->base + _31605);
                }
                Ref(_31606);
                RefDS(_21997);
                _31607 = _17abbreviate_path(_31606, _21997);
                _31606 = NOVALUE;
                _31608 = _16find_replace(92, _31607, 47, 0);
                _31607 = NOVALUE;
                _1 = NewS1(1);
                _2 = (object)((s1_ptr)_1)->base;
                ((intptr_t*)_2)[1] = _31608;
                _31609 = MAKE_SEQ(_1);
                _31608 = NOVALUE;
                _31610 = EPrintf(-9999999, _31603, _31609);
                DeRefDS(_31609);
                _31609 = NOVALUE;
                Concat((object_ptr)&_errloc_64271, _errloc_64271, _31610);
                DeRefDS(_31610);
                _31610 = NOVALUE;
L1A: 

                /** fwdref.e:1035								end for*/
                _si_64371 = _si_64371 + 1;
                goto L18; // [745] 671
L19: 
                ;
            }
            DeRef(_syms_64353);
            _syms_64353 = NOVALUE;
            goto L17; // [752] 759

            /** fwdref.e:1036							case else */
            default:
L14: 
        ;}L17: 
L13: 

        /** fwdref.e:1040					if not match(errloc, msg) then*/
        _31612 = e_match_from(_errloc_64271, _msg_64270, 1);
        if (_31612 != 0)
        goto L1B; // [767] 786
        _31612 = NOVALUE;

        /** fwdref.e:1041						msg &= errloc*/
        Concat((object_ptr)&_msg_64270, _msg_64270, _errloc_64271);

        /** fwdref.e:1042						prep_forward_error( errors[e] )*/
        _2 = (object)SEQ_PTR(_errors_64208);
        _31615 = (object)*(((s1_ptr)_2)->base + _e_64274);
        Ref(_31615);
        _44prep_forward_error(_31615);
        _31615 = NOVALUE;
L1B: 
        DeRef(_tok_64292);
        _tok_64292 = NOVALUE;
L12: 

        /** fwdref.e:1045				ThisLine    = ref[FR_THISLINE]*/
        DeRef(_50ThisLine_49238);
        _2 = (object)SEQ_PTR(_ref_64276);
        _50ThisLine_49238 = (object)*(((s1_ptr)_2)->base + 7);
        Ref(_50ThisLine_49238);

        /** fwdref.e:1046				bp          = ref[FR_BP]*/
        _2 = (object)SEQ_PTR(_ref_64276);
        _50bp_49242 = (object)*(((s1_ptr)_2)->base + 8);
        if (!IS_ATOM_INT(_50bp_49242)){
            _50bp_49242 = (object)DBL_PTR(_50bp_49242)->dbl;
        }

        /** fwdref.e:1047				CurrentSub  = ref[FR_SUBPROG]*/
        _2 = (object)SEQ_PTR(_ref_64276);
        _36CurrentSub_21455 = (object)*(((s1_ptr)_2)->base + 4);
        if (!IS_ATOM_INT(_36CurrentSub_21455)){
            _36CurrentSub_21455 = (object)DBL_PTR(_36CurrentSub_21455)->dbl;
        }

        /** fwdref.e:1048				line_number = ref[FR_LINE]*/
        _2 = (object)SEQ_PTR(_ref_64276);
        _36line_number_21448 = (object)*(((s1_ptr)_2)->base + 6);
        if (!IS_ATOM_INT(_36line_number_21448)){
            _36line_number_21448 = (object)DBL_PTR(_36line_number_21448)->dbl;
        }
        DeRefDS(_ref_64276);
        _ref_64276 = NOVALUE;

        /** fwdref.e:1049			end for*/
L11: 
        _e_64274 = _e_64274 + -1;
        goto LC; // [823] 319
LD: 
        ;
    }

    /** fwdref.e:1050			if length(msg) > 0 then*/
    if (IS_SEQUENCE(_msg_64270)){
            _31620 = SEQ_PTR(_msg_64270)->length;
    }
    else {
        _31620 = 1;
    }
    if (_31620 <= 0)
    goto L1C; // [833] 851

    /** fwdref.e:1051				CompileErr( ERRORS_RESOLVING_THE_FOLLOWING_REFERENCES1, {msg} )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_msg_64270);
    ((intptr_t*)_2)[1] = _msg_64270;
    _31622 = MAKE_SEQ(_1);
    _50CompileErr(74, _31622, 0);
    _31622 = NOVALUE;
L1C: 
    DeRefi(_msg_64270);
    _msg_64270 = NOVALUE;
    DeRefi(_errloc_64271);
    _errloc_64271 = NOVALUE;
    goto L1D; // [853] 901
LB: 

    /** fwdref.e:1053		elsif report_errors and not repl then*/
    if (_report_errors_64207 == 0) {
        goto L1E; // [858] 900
    }
    _31624 = (0 == 0);
    if (_31624 == 0)
    {
        DeRef(_31624);
        _31624 = NOVALUE;
        goto L1E; // [868] 900
    }
    else{
        DeRef(_31624);
        _31624 = NOVALUE;
    }

    /** fwdref.e:1055			forward_references  = {}*/
    RefDS(_21997);
    DeRef(_44forward_references_62769);
    _44forward_references_62769 = _21997;

    /** fwdref.e:1056			active_references   = {}*/
    RefDS(_21997);
    DeRef(_44active_references_62771);
    _44active_references_62771 = _21997;

    /** fwdref.e:1057			toplevel_references = {}*/
    RefDS(_21997);
    DeRef(_44toplevel_references_62772);
    _44toplevel_references_62772 = _21997;

    /** fwdref.e:1058			inactive_references = {}*/
    RefDS(_21997);
    DeRef(_44inactive_references_62773);
    _44inactive_references_62773 = _21997;
L1E: 
L1D: 

    /** fwdref.e:1060		clear_last()*/
    _47clear_last();

    /** fwdref.e:1061	end procedure*/
    DeRef(_errors_64208);
    _31605 = NOVALUE;
    _31580 = NOVALUE;
    _31592 = NOVALUE;
    DeRef(_31541);
    _31541 = NOVALUE;
    DeRef(_31544);
    _31544 = NOVALUE;
    _31572 = NOVALUE;
    _31525 = NOVALUE;
    _31518 = NOVALUE;
    DeRef(_31521);
    _31521 = NOVALUE;
    _31538 = NOVALUE;
    _31560 = NOVALUE;
    _31564 = NOVALUE;
    _31523 = NOVALUE;
    _31515 = NOVALUE;
    return;
    ;
}


void _44shift_these(object _refs_64422, object _pc_64423, object _amount_64424)
{
    object _fr_64428 = NOVALUE;
    object _31642 = NOVALUE;
    object _31641 = NOVALUE;
    object _31640 = NOVALUE;
    object _31639 = NOVALUE;
    object _31638 = NOVALUE;
    object _31637 = NOVALUE;
    object _31636 = NOVALUE;
    object _31635 = NOVALUE;
    object _31634 = NOVALUE;
    object _31633 = NOVALUE;
    object _31631 = NOVALUE;
    object _31629 = NOVALUE;
    object _31628 = NOVALUE;
    object _31626 = NOVALUE;
    object _31625 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1064		for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64422)){
            _31625 = SEQ_PTR(_refs_64422)->length;
    }
    else {
        _31625 = 1;
    }
    {
        object _i_64426;
        _i_64426 = _31625;
L1: 
        if (_i_64426 < 1){
            goto L2; // [12] 147
        }

        /** fwdref.e:1065			sequence fr = forward_references[refs[i]]*/
        _2 = (object)SEQ_PTR(_refs_64422);
        _31626 = (object)*(((s1_ptr)_2)->base + _i_64426);
        DeRef(_fr_64428);
        _2 = (object)SEQ_PTR(_44forward_references_62769);
        if (!IS_ATOM_INT(_31626)){
            _fr_64428 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31626)->dbl));
        }
        else{
            _fr_64428 = (object)*(((s1_ptr)_2)->base + _31626);
        }
        Ref(_fr_64428);

        /** fwdref.e:1066			forward_references[refs[i]] = 0*/
        _2 = (object)SEQ_PTR(_refs_64422);
        _31628 = (object)*(((s1_ptr)_2)->base + _i_64426);
        _2 = (object)SEQ_PTR(_44forward_references_62769);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_62769 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31628))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31628)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31628);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);

        /** fwdref.e:1067			if fr[FR_SUBPROG] = shifting_sub then*/
        _2 = (object)SEQ_PTR(_fr_64428);
        _31629 = (object)*(((s1_ptr)_2)->base + 4);
        if (binary_op_a(NOTEQ, _31629, _44shifting_sub_62788)){
            _31629 = NOVALUE;
            goto L3; // [53] 126
        }
        _31629 = NOVALUE;

        /** fwdref.e:1068				if fr[FR_PC] >= pc then*/
        _2 = (object)SEQ_PTR(_fr_64428);
        _31631 = (object)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(LESS, _31631, _pc_64423)){
            _31631 = NOVALUE;
            goto L4; // [63] 125
        }
        _31631 = NOVALUE;

        /** fwdref.e:1069					fr[FR_PC] += amount*/
        _2 = (object)SEQ_PTR(_fr_64428);
        _31633 = (object)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_31633)) {
            _31634 = _31633 + _amount_64424;
            if ((object)((uintptr_t)_31634 + (uintptr_t)HIGH_BITS) >= 0){
                _31634 = NewDouble((eudouble)_31634);
            }
        }
        else {
            _31634 = binary_op(PLUS, _31633, _amount_64424);
        }
        _31633 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64428);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64428 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31634;
        if( _1 != _31634 ){
            DeRef(_1);
        }
        _31634 = NOVALUE;

        /** fwdref.e:1070					if fr[FR_TYPE] = CASE*/
        _2 = (object)SEQ_PTR(_fr_64428);
        _31635 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31635)) {
            _31636 = (_31635 == 186);
        }
        else {
            _31636 = binary_op(EQUALS, _31635, 186);
        }
        _31635 = NOVALUE;
        if (IS_ATOM_INT(_31636)) {
            if (_31636 == 0) {
                goto L5; // [93] 124
            }
        }
        else {
            if (DBL_PTR(_31636)->dbl == 0.0) {
                goto L5; // [93] 124
            }
        }
        _2 = (object)SEQ_PTR(_fr_64428);
        _31638 = (object)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31638)) {
            _31639 = (_31638 >= _pc_64423);
        }
        else {
            _31639 = binary_op(GREATEREQ, _31638, _pc_64423);
        }
        _31638 = NOVALUE;
        if (_31639 == 0) {
            DeRef(_31639);
            _31639 = NOVALUE;
            goto L5; // [106] 124
        }
        else {
            if (!IS_ATOM_INT(_31639) && DBL_PTR(_31639)->dbl == 0.0){
                DeRef(_31639);
                _31639 = NOVALUE;
                goto L5; // [106] 124
            }
            DeRef(_31639);
            _31639 = NOVALUE;
        }
        DeRef(_31639);
        _31639 = NOVALUE;

        /** fwdref.e:1073						fr[FR_DATA] += amount*/
        _2 = (object)SEQ_PTR(_fr_64428);
        _31640 = (object)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31640)) {
            _31641 = _31640 + _amount_64424;
            if ((object)((uintptr_t)_31641 + (uintptr_t)HIGH_BITS) >= 0){
                _31641 = NewDouble((eudouble)_31641);
            }
        }
        else {
            _31641 = binary_op(PLUS, _31640, _amount_64424);
        }
        _31640 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64428);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64428 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 12);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31641;
        if( _1 != _31641 ){
            DeRef(_1);
        }
        _31641 = NOVALUE;
L5: 
L4: 
L3: 

        /** fwdref.e:1077			forward_references[refs[i]] = fr*/
        _2 = (object)SEQ_PTR(_refs_64422);
        _31642 = (object)*(((s1_ptr)_2)->base + _i_64426);
        RefDS(_fr_64428);
        _2 = (object)SEQ_PTR(_44forward_references_62769);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_62769 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31642))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31642)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31642);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _fr_64428;
        DeRef(_1);
        DeRefDS(_fr_64428);
        _fr_64428 = NOVALUE;

        /** fwdref.e:1078		end for*/
        _i_64426 = _i_64426 + -1;
        goto L1; // [142] 19
L2: 
        ;
    }

    /** fwdref.e:1079	end procedure*/
    DeRefDS(_refs_64422);
    _31626 = NOVALUE;
    _31628 = NOVALUE;
    DeRef(_31636);
    _31636 = NOVALUE;
    _31642 = NOVALUE;
    return;
    ;
}


void _44shift_top(object _refs_64452, object _pc_64453, object _amount_64454)
{
    object _fr_64458 = NOVALUE;
    object _31658 = NOVALUE;
    object _31657 = NOVALUE;
    object _31656 = NOVALUE;
    object _31655 = NOVALUE;
    object _31654 = NOVALUE;
    object _31653 = NOVALUE;
    object _31652 = NOVALUE;
    object _31651 = NOVALUE;
    object _31650 = NOVALUE;
    object _31649 = NOVALUE;
    object _31647 = NOVALUE;
    object _31646 = NOVALUE;
    object _31644 = NOVALUE;
    object _31643 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1083		for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64452)){
            _31643 = SEQ_PTR(_refs_64452)->length;
    }
    else {
        _31643 = 1;
    }
    {
        object _i_64456;
        _i_64456 = _31643;
L1: 
        if (_i_64456 < 1){
            goto L2; // [12] 134
        }

        /** fwdref.e:1084			sequence fr = forward_references[refs[i]]*/
        _2 = (object)SEQ_PTR(_refs_64452);
        _31644 = (object)*(((s1_ptr)_2)->base + _i_64456);
        DeRef(_fr_64458);
        _2 = (object)SEQ_PTR(_44forward_references_62769);
        if (!IS_ATOM_INT(_31644)){
            _fr_64458 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31644)->dbl));
        }
        else{
            _fr_64458 = (object)*(((s1_ptr)_2)->base + _31644);
        }
        Ref(_fr_64458);

        /** fwdref.e:1085			forward_references[refs[i]] = 0*/
        _2 = (object)SEQ_PTR(_refs_64452);
        _31646 = (object)*(((s1_ptr)_2)->base + _i_64456);
        _2 = (object)SEQ_PTR(_44forward_references_62769);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_62769 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31646))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31646)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31646);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);

        /** fwdref.e:1086			if fr[FR_PC] >= pc then*/
        _2 = (object)SEQ_PTR(_fr_64458);
        _31647 = (object)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(LESS, _31647, _pc_64453)){
            _31647 = NOVALUE;
            goto L3; // [51] 113
        }
        _31647 = NOVALUE;

        /** fwdref.e:1087				fr[FR_PC] += amount*/
        _2 = (object)SEQ_PTR(_fr_64458);
        _31649 = (object)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_31649)) {
            _31650 = _31649 + _amount_64454;
            if ((object)((uintptr_t)_31650 + (uintptr_t)HIGH_BITS) >= 0){
                _31650 = NewDouble((eudouble)_31650);
            }
        }
        else {
            _31650 = binary_op(PLUS, _31649, _amount_64454);
        }
        _31649 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64458);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64458 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31650;
        if( _1 != _31650 ){
            DeRef(_1);
        }
        _31650 = NOVALUE;

        /** fwdref.e:1088				if fr[FR_TYPE] = CASE*/
        _2 = (object)SEQ_PTR(_fr_64458);
        _31651 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31651)) {
            _31652 = (_31651 == 186);
        }
        else {
            _31652 = binary_op(EQUALS, _31651, 186);
        }
        _31651 = NOVALUE;
        if (IS_ATOM_INT(_31652)) {
            if (_31652 == 0) {
                goto L4; // [81] 112
            }
        }
        else {
            if (DBL_PTR(_31652)->dbl == 0.0) {
                goto L4; // [81] 112
            }
        }
        _2 = (object)SEQ_PTR(_fr_64458);
        _31654 = (object)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31654)) {
            _31655 = (_31654 >= _pc_64453);
        }
        else {
            _31655 = binary_op(GREATEREQ, _31654, _pc_64453);
        }
        _31654 = NOVALUE;
        if (_31655 == 0) {
            DeRef(_31655);
            _31655 = NOVALUE;
            goto L4; // [94] 112
        }
        else {
            if (!IS_ATOM_INT(_31655) && DBL_PTR(_31655)->dbl == 0.0){
                DeRef(_31655);
                _31655 = NOVALUE;
                goto L4; // [94] 112
            }
            DeRef(_31655);
            _31655 = NOVALUE;
        }
        DeRef(_31655);
        _31655 = NOVALUE;

        /** fwdref.e:1091					fr[FR_DATA] += amount*/
        _2 = (object)SEQ_PTR(_fr_64458);
        _31656 = (object)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31656)) {
            _31657 = _31656 + _amount_64454;
            if ((object)((uintptr_t)_31657 + (uintptr_t)HIGH_BITS) >= 0){
                _31657 = NewDouble((eudouble)_31657);
            }
        }
        else {
            _31657 = binary_op(PLUS, _31656, _amount_64454);
        }
        _31656 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64458);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64458 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 12);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31657;
        if( _1 != _31657 ){
            DeRef(_1);
        }
        _31657 = NOVALUE;
L4: 
L3: 

        /** fwdref.e:1094			forward_references[refs[i]] = fr*/
        _2 = (object)SEQ_PTR(_refs_64452);
        _31658 = (object)*(((s1_ptr)_2)->base + _i_64456);
        RefDS(_fr_64458);
        _2 = (object)SEQ_PTR(_44forward_references_62769);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_62769 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31658))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31658)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31658);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _fr_64458;
        DeRef(_1);
        DeRefDS(_fr_64458);
        _fr_64458 = NOVALUE;

        /** fwdref.e:1095		end for*/
        _i_64456 = _i_64456 + -1;
        goto L1; // [129] 19
L2: 
        ;
    }

    /** fwdref.e:1096	end procedure*/
    DeRefDS(_refs_64452);
    _31658 = NOVALUE;
    DeRef(_31652);
    _31652 = NOVALUE;
    _31646 = NOVALUE;
    _31644 = NOVALUE;
    return;
    ;
}


void _44shift_fwd_refs(object _pc_64479, object _amount_64480)
{
    object _file_64491 = NOVALUE;
    object _sp_64496 = NOVALUE;
    object _31668 = NOVALUE;
    object _31667 = NOVALUE;
    object _31665 = NOVALUE;
    object _31663 = NOVALUE;
    object _31662 = NOVALUE;
    object _31661 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1099		if not shifting_sub then*/
    if (_44shifting_sub_62788 != 0)
    goto L1; // [9] 18

    /** fwdref.e:1100			return*/
    return;
L1: 

    /** fwdref.e:1103		if shifting_sub = TopLevelSub then*/
    if (_44shifting_sub_62788 != _36TopLevelSub_21454)
    goto L2; // [24] 65

    /** fwdref.e:1104			for file = 1 to length( toplevel_references ) do*/
    if (IS_SEQUENCE(_44toplevel_references_62772)){
            _31661 = SEQ_PTR(_44toplevel_references_62772)->length;
    }
    else {
        _31661 = 1;
    }
    {
        object _file_64487;
        _file_64487 = 1;
L3: 
        if (_file_64487 > _31661){
            goto L4; // [35] 62
        }

        /** fwdref.e:1105				shift_top( toplevel_references[file], pc, amount )*/
        _2 = (object)SEQ_PTR(_44toplevel_references_62772);
        _31662 = (object)*(((s1_ptr)_2)->base + _file_64487);
        Ref(_31662);
        _44shift_top(_31662, _pc_64479, _amount_64480);
        _31662 = NOVALUE;

        /** fwdref.e:1106			end for*/
        _file_64487 = _file_64487 + 1;
        goto L3; // [57] 42
L4: 
        ;
    }
    goto L5; // [62] 118
L2: 

    /** fwdref.e:1108			integer file = SymTab[shifting_sub][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31663 = (object)*(((s1_ptr)_2)->base + _44shifting_sub_62788);
    _2 = (object)SEQ_PTR(_31663);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _file_64491 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _file_64491 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    if (!IS_ATOM_INT(_file_64491)){
        _file_64491 = (object)DBL_PTR(_file_64491)->dbl;
    }
    _31663 = NOVALUE;

    /** fwdref.e:1109			integer sp   = find( shifting_sub, active_subprogs[file] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_62770);
    _31665 = (object)*(((s1_ptr)_2)->base + _file_64491);
    _sp_64496 = find_from(_44shifting_sub_62788, _31665, 1);
    _31665 = NOVALUE;

    /** fwdref.e:1110			shift_these( active_references[file][sp], pc, amount )*/
    _2 = (object)SEQ_PTR(_44active_references_62771);
    _31667 = (object)*(((s1_ptr)_2)->base + _file_64491);
    _2 = (object)SEQ_PTR(_31667);
    _31668 = (object)*(((s1_ptr)_2)->base + _sp_64496);
    _31667 = NOVALUE;
    Ref(_31668);
    _44shift_these(_31668, _pc_64479, _amount_64480);
    _31668 = NOVALUE;
L5: 

    /** fwdref.e:1112	end procedure*/
    return;
    ;
}



// 0xA94FD8FD
