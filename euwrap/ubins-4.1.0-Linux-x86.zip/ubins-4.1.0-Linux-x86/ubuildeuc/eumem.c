// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _30malloc(object _mem_struct_p_11246, object _cleanup_p_11247)
{
    object _temp__11248 = NOVALUE;
    object _6335 = NOVALUE;
    object _6333 = NOVALUE;
    object _6332 = NOVALUE;
    object _6331 = NOVALUE;
    object _6327 = NOVALUE;
    object _0, _1, _2;
    

    /** eumem.e:51		if atom(mem_struct_p) then*/
    _6327 = IS_ATOM(_mem_struct_p_11246);
    if (_6327 == 0)
    {
        _6327 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _6327 = NOVALUE;
    }

    /** eumem.e:52			mem_struct_p = repeat(0, mem_struct_p)*/
    _0 = _mem_struct_p_11246;
    _mem_struct_p_11246 = Repeat(0, _mem_struct_p_11246);
    DeRef(_0);
L1: 

    /** eumem.e:54		if ram_free_list = 0 then*/
    if (_30ram_free_list_11242 != 0)
    goto L2; // [22] 72

    /** eumem.e:55			ram_space = append(ram_space, mem_struct_p)*/
    Ref(_mem_struct_p_11246);
    Append(&_30ram_space_11238, _30ram_space_11238, _mem_struct_p_11246);

    /** eumem.e:56			if cleanup_p then*/
    if (_cleanup_p_11247 == 0)
    {
        goto L3; // [36] 59
    }
    else{
    }

    /** eumem.e:57				return delete_routine( length(ram_space), free_rid )*/
    if (IS_SEQUENCE(_30ram_space_11238)){
            _6331 = SEQ_PTR(_30ram_space_11238)->length;
    }
    else {
        _6331 = 1;
    }
    _6332 = NewDouble( (eudouble) _6331 );
    _1 = (object) _00[_30free_rid_11243].cleanup;
    if( _1 == 0 ){
        _1 = (object) TransAlloc( sizeof(struct cleanup) );
        _00[_30free_rid_11243].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _30free_rid_11243;
    ((cleanup_ptr)_1)->next = 0;
    if(DBL_PTR(_6332)->cleanup != 0 ){
        _1 = (object) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_6332)->cleanup );
    }
    else if( !UNIQUE(DBL_PTR(_6332)) ){
        DeRefDS(_6332);
        _6332 = NewDouble( DBL_PTR(_6332)->dbl );
    }
    DBL_PTR(_6332)->cleanup = (cleanup_ptr)_1;
    _6331 = NOVALUE;
    DeRef(_mem_struct_p_11246);
    return _6332;
    goto L4; // [56] 71
L3: 

    /** eumem.e:59				return length(ram_space)*/
    if (IS_SEQUENCE(_30ram_space_11238)){
            _6333 = SEQ_PTR(_30ram_space_11238)->length;
    }
    else {
        _6333 = 1;
    }
    DeRef(_mem_struct_p_11246);
    DeRef(_6332);
    _6332 = NOVALUE;
    return _6333;
L4: 
L2: 

    /** eumem.e:63		temp_ = ram_free_list*/
    _temp__11248 = _30ram_free_list_11242;

    /** eumem.e:64		ram_free_list = ram_space[temp_]*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    _30ram_free_list_11242 = (object)*(((s1_ptr)_2)->base + _temp__11248);
    if (!IS_ATOM_INT(_30ram_free_list_11242))
    _30ram_free_list_11242 = (object)DBL_PTR(_30ram_free_list_11242)->dbl;

    /** eumem.e:65		ram_space[temp_] = mem_struct_p*/
    Ref(_mem_struct_p_11246);
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11238 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _temp__11248);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _mem_struct_p_11246;
    DeRef(_1);

    /** eumem.e:67		if cleanup_p then*/
    if (_cleanup_p_11247 == 0)
    {
        goto L5; // [97] 115
    }
    else{
    }

    /** eumem.e:68			return delete_routine( temp_, free_rid )*/
    _6335 = NewDouble( (eudouble) _temp__11248 );
    _1 = (object) _00[_30free_rid_11243].cleanup;
    if( _1 == 0 ){
        _1 = (object) TransAlloc( sizeof(struct cleanup) );
        _00[_30free_rid_11243].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _30free_rid_11243;
    ((cleanup_ptr)_1)->next = 0;
    if(DBL_PTR(_6335)->cleanup != 0 ){
        _1 = (object) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_6335)->cleanup );
    }
    else if( !UNIQUE(DBL_PTR(_6335)) ){
        DeRefDS(_6335);
        _6335 = NewDouble( DBL_PTR(_6335)->dbl );
    }
    DBL_PTR(_6335)->cleanup = (cleanup_ptr)_1;
    DeRef(_mem_struct_p_11246);
    DeRef(_6332);
    _6332 = NOVALUE;
    return _6335;
    goto L6; // [112] 122
L5: 

    /** eumem.e:70			return temp_*/
    DeRef(_mem_struct_p_11246);
    DeRef(_6332);
    _6332 = NOVALUE;
    DeRef(_6335);
    _6335 = NOVALUE;
    return _temp__11248;
L6: 
    ;
}


void _30free(object _mem_p_11266)
{
    object _6338 = NOVALUE;
    object _6336 = NOVALUE;
    object _0, _1, _2;
    

    /** eumem.e:95		if object( ram_space ) then*/
    if( NOVALUE == _30ram_space_11238 ){
        _6336 = 0;
    }
    else{
        _6336 = 3;
    }
    if (_6336 == 0)
    {
        _6336 = NOVALUE;
        goto L1; // [6] 52
    }
    else{
        _6336 = NOVALUE;
    }

    /** eumem.e:96			if mem_p < 1 then return end if*/
    if (binary_op_a(GREATEREQ, _mem_p_11266, 1)){
        goto L2; // [11] 19
    }
    DeRef(_mem_p_11266);
    return;
L2: 

    /** eumem.e:97			if mem_p > length(ram_space) then return end if*/
    if (IS_SEQUENCE(_30ram_space_11238)){
            _6338 = SEQ_PTR(_30ram_space_11238)->length;
    }
    else {
        _6338 = 1;
    }
    if (binary_op_a(LESSEQ, _mem_p_11266, _6338)){
        _6338 = NOVALUE;
        goto L3; // [26] 34
    }
    _6338 = NOVALUE;
    DeRef(_mem_p_11266);
    return;
L3: 

    /** eumem.e:99			ram_space[mem_p] = ram_free_list*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11238 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_mem_p_11266))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_mem_p_11266)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _mem_p_11266);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30ram_free_list_11242;
    DeRef(_1);

    /** eumem.e:100			ram_free_list = floor(mem_p)*/
    if (IS_ATOM_INT(_mem_p_11266))
    _30ram_free_list_11242 = e_floor(_mem_p_11266);
    else
    _30ram_free_list_11242 = unary_op(FLOOR, _mem_p_11266);
    if (!IS_ATOM_INT(_30ram_free_list_11242)) {
        _1 = (object)(DBL_PTR(_30ram_free_list_11242)->dbl);
        DeRefDS(_30ram_free_list_11242);
        _30ram_free_list_11242 = _1;
    }
L1: 

    /** eumem.e:102	end procedure*/
    DeRef(_mem_p_11266);
    return;
    ;
}



// 0xC3547150
