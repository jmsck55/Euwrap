// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _68GetSourceName()
{
    object _real_name_66826 = NOVALUE;
    object _fh_66827 = NOVALUE;
    object _has_extension_66829 = NOVALUE;
    object _32945 = NOVALUE;
    object _32943 = NOVALUE;
    object _32942 = NOVALUE;
    object _32939 = NOVALUE;
    object _32938 = NOVALUE;
    object _32937 = NOVALUE;
    object _32936 = NOVALUE;
    object _32935 = NOVALUE;
    object _32934 = NOVALUE;
    object _32931 = NOVALUE;
    object _32930 = NOVALUE;
    object _32928 = NOVALUE;
    object _32927 = NOVALUE;
    object _32926 = NOVALUE;
    object _32925 = NOVALUE;
    object _32924 = NOVALUE;
    object _32923 = NOVALUE;
    object _32920 = NOVALUE;
    object _32919 = NOVALUE;
    object _32917 = NOVALUE;
    object _32916 = NOVALUE;
    object _32914 = NOVALUE;
    object _32913 = NOVALUE;
    object _32910 = NOVALUE;
    object _32909 = NOVALUE;
    object _32908 = NOVALUE;
    object _32906 = NOVALUE;
    object _32905 = NOVALUE;
    object _32904 = NOVALUE;
    object _32903 = NOVALUE;
    object _32902 = NOVALUE;
    object _32901 = NOVALUE;
    object _32900 = NOVALUE;
    object _0, _1, _2;
    

    /** main.e:48		boolean has_extension = FALSE*/
    _has_extension_66829 = _13FALSE_450;

    /** main.e:50		if length(src_name) = 0 and not repl then*/
    if (IS_SEQUENCE(_49src_name_49595)){
            _32900 = SEQ_PTR(_49src_name_49595)->length;
    }
    else {
        _32900 = 1;
    }
    _32901 = (_32900 == 0);
    _32900 = NOVALUE;
    if (_32901 == 0) {
        goto L1; // [19] 45
    }
    _32903 = (0 == 0);
    if (_32903 == 0)
    {
        DeRef(_32903);
        _32903 = NOVALUE;
        goto L1; // [29] 45
    }
    else{
        DeRef(_32903);
        _32903 = NOVALUE;
    }

    /** main.e:51			show_banner()*/
    _49show_banner();

    /** main.e:52			return -2 -- No source file*/
    DeRef(_real_name_66826);
    DeRef(_32901);
    _32901 = NOVALUE;
    return -2;
    goto L2; // [42] 143
L1: 

    /** main.e:53		elsif length(src_name) = 0 and repl then*/
    if (IS_SEQUENCE(_49src_name_49595)){
            _32904 = SEQ_PTR(_49src_name_49595)->length;
    }
    else {
        _32904 = 1;
    }
    _32905 = (_32904 == 0);
    _32904 = NOVALUE;
    if (_32905 == 0) {
        goto L3; // [56] 142
    }
    goto L3; // [63] 142

    /** main.e:54			known_files = append(known_files, "")*/
    RefDS(_21997);
    Append(&_37known_files_15407, _37known_files_15407, _21997);

    /** main.e:55			known_files_hash &= hash(known_files[$], stdhash:HSIEH32)*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _32908 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _32908 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _32909 = (object)*(((s1_ptr)_2)->base + _32908);
    _32910 = calc_hash(_32909, -5);
    _32909 = NOVALUE;
    Ref(_32910);
    Append(&_37known_files_hash_15408, _37known_files_hash_15408, _32910);
    DeRef(_32910);
    _32910 = NOVALUE;

    /** main.e:56			real_name = ""*/
    RefDS(_21997);
    DeRef(_real_name_66826);
    _real_name_66826 = _21997;

    /** main.e:57			finished_files &= 0*/
    Append(&_37finished_files_15409, _37finished_files_15409, 0);

    /** main.e:58			file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _32913 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _32913 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _32913;
    _32914 = MAKE_SEQ(_1);
    _32913 = NOVALUE;
    RefDS(_32914);
    Append(&_37file_include_depend_15410, _37file_include_depend_15410, _32914);
    DeRefDS(_32914);
    _32914 = NOVALUE;

    /** main.e:59			return repl_file*/
    DeRefDS(_real_name_66826);
    DeRef(_32905);
    _32905 = NOVALUE;
    DeRef(_32901);
    _32901 = NOVALUE;
    return 5555;
L3: 
L2: 

    /** main.e:62		ifdef WINDOWS then*/

    /** main.e:66		for p = length(src_name) to 1 by -1 do*/
    if (IS_SEQUENCE(_49src_name_49595)){
            _32916 = SEQ_PTR(_49src_name_49595)->length;
    }
    else {
        _32916 = 1;
    }
    {
        object _p_66864;
        _p_66864 = _32916;
L4: 
        if (_p_66864 < 1){
            goto L5; // [152] 216
        }

        /** main.e:67			if src_name[p] = '.' then*/
        _2 = (object)SEQ_PTR(_49src_name_49595);
        _32917 = (object)*(((s1_ptr)_2)->base + _p_66864);
        if (binary_op_a(NOTEQ, _32917, 46)){
            _32917 = NOVALUE;
            goto L6; // [167] 185
        }
        _32917 = NOVALUE;

        /** main.e:68			   has_extension = TRUE*/
        _has_extension_66829 = _13TRUE_452;

        /** main.e:69			   exit*/
        goto L5; // [180] 216
        goto L7; // [182] 209
L6: 

        /** main.e:70			elsif find(src_name[p], SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_49src_name_49595);
        _32919 = (object)*(((s1_ptr)_2)->base + _p_66864);
        _32920 = find_from(_32919, _46SLASH_CHARS_21614, 1);
        _32919 = NOVALUE;
        if (_32920 == 0)
        {
            _32920 = NOVALUE;
            goto L8; // [200] 208
        }
        else{
            _32920 = NOVALUE;
        }

        /** main.e:71			   exit*/
        goto L5; // [205] 216
L8: 
L7: 

        /** main.e:73		end for*/
        _p_66864 = _p_66864 + -1;
        goto L4; // [211] 159
L5: 
        ;
    }

    /** main.e:75		if not has_extension then*/
    if (_has_extension_66829 != 0)
    goto L9; // [218] 323

    /** main.e:79			known_files = append(known_files, "")*/
    RefDS(_21997);
    Append(&_37known_files_15407, _37known_files_15407, _21997);

    /** main.e:82			for i = 1 to length( DEFAULT_EXTS ) do*/
    _32923 = 4;
    {
        object _i_66883;
        _i_66883 = 1;
LA: 
        if (_i_66883 > 4){
            goto LB; // [238] 303
        }

        /** main.e:83				known_files[$] = src_name & DEFAULT_EXTS[i]*/
        if (IS_SEQUENCE(_37known_files_15407)){
                _32924 = SEQ_PTR(_37known_files_15407)->length;
        }
        else {
            _32924 = 1;
        }
        _2 = (object)SEQ_PTR(_46DEFAULT_EXTS_21589);
        _32925 = (object)*(((s1_ptr)_2)->base + _i_66883);
        Concat((object_ptr)&_32926, _49src_name_49595, _32925);
        _32925 = NOVALUE;
        _2 = (object)SEQ_PTR(_37known_files_15407);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37known_files_15407 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _32924);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32926;
        if( _1 != _32926 ){
            DeRef(_1);
        }
        _32926 = NOVALUE;

        /** main.e:84				real_name = e_path_find(known_files[$])*/
        if (IS_SEQUENCE(_37known_files_15407)){
                _32927 = SEQ_PTR(_37known_files_15407)->length;
        }
        else {
            _32927 = 1;
        }
        _2 = (object)SEQ_PTR(_37known_files_15407);
        _32928 = (object)*(((s1_ptr)_2)->base + _32927);
        Ref(_32928);
        _0 = _real_name_66826;
        _real_name_66826 = _48e_path_find(_32928);
        DeRef(_0);
        _32928 = NOVALUE;

        /** main.e:85				if sequence(real_name) then*/
        _32930 = IS_SEQUENCE(_real_name_66826);
        if (_32930 == 0)
        {
            _32930 = NOVALUE;
            goto LC; // [288] 296
        }
        else{
            _32930 = NOVALUE;
        }

        /** main.e:86					exit*/
        goto LB; // [293] 303
LC: 

        /** main.e:88			end for*/
        _i_66883 = _i_66883 + 1;
        goto LA; // [298] 245
LB: 
        ;
    }

    /** main.e:90			if atom(real_name) then*/
    _32931 = IS_ATOM(_real_name_66826);
    if (_32931 == 0)
    {
        _32931 = NOVALUE;
        goto LD; // [310] 359
    }
    else{
        _32931 = NOVALUE;
    }

    /** main.e:91				return -1*/
    DeRef(_real_name_66826);
    DeRef(_32905);
    _32905 = NOVALUE;
    DeRef(_32901);
    _32901 = NOVALUE;
    return -1;
    goto LD; // [320] 359
L9: 

    /** main.e:94			known_files = append(known_files, src_name)*/
    RefDS(_49src_name_49595);
    Append(&_37known_files_15407, _37known_files_15407, _49src_name_49595);

    /** main.e:95			real_name = e_path_find(src_name)*/
    RefDS(_49src_name_49595);
    _0 = _real_name_66826;
    _real_name_66826 = _48e_path_find(_49src_name_49595);
    DeRef(_0);

    /** main.e:96			if atom(real_name) then*/
    _32934 = IS_ATOM(_real_name_66826);
    if (_32934 == 0)
    {
        _32934 = NOVALUE;
        goto LE; // [348] 358
    }
    else{
        _32934 = NOVALUE;
    }

    /** main.e:97				return -1*/
    DeRef(_real_name_66826);
    DeRef(_32905);
    _32905 = NOVALUE;
    DeRef(_32901);
    _32901 = NOVALUE;
    return -1;
LE: 
LD: 

    /** main.e:100		known_files[$] = canonical_path(real_name,,CORRECT)*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _32935 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _32935 = 1;
    }
    Ref(_real_name_66826);
    _32936 = _17canonical_path(_real_name_66826, 0, 2);
    _2 = (object)SEQ_PTR(_37known_files_15407);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37known_files_15407 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _32935);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32936;
    if( _1 != _32936 ){
        DeRef(_1);
    }
    _32936 = NOVALUE;

    /** main.e:101		known_files_hash &= hash(known_files[$], stdhash:HSIEH32)*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _32937 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _32937 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _32938 = (object)*(((s1_ptr)_2)->base + _32937);
    _32939 = calc_hash(_32938, -5);
    _32938 = NOVALUE;
    Ref(_32939);
    Append(&_37known_files_hash_15408, _37known_files_hash_15408, _32939);
    DeRef(_32939);
    _32939 = NOVALUE;

    /** main.e:102		finished_files &= 0*/
    Append(&_37finished_files_15409, _37finished_files_15409, 0);

    /** main.e:103		file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _32942 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _32942 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _32942;
    _32943 = MAKE_SEQ(_1);
    _32942 = NOVALUE;
    RefDS(_32943);
    Append(&_37file_include_depend_15410, _37file_include_depend_15410, _32943);
    DeRefDS(_32943);
    _32943 = NOVALUE;

    /** main.e:105		if file_exists(real_name) then*/
    Ref(_real_name_66826);
    _32945 = _17file_exists(_real_name_66826);
    if (_32945 == 0) {
        DeRef(_32945);
        _32945 = NOVALUE;
        goto LF; // [438] 462
    }
    else {
        if (!IS_ATOM_INT(_32945) && DBL_PTR(_32945)->dbl == 0.0){
            DeRef(_32945);
            _32945 = NOVALUE;
            goto LF; // [438] 462
        }
        DeRef(_32945);
        _32945 = NOVALUE;
    }
    DeRef(_32945);
    _32945 = NOVALUE;

    /** main.e:106			real_name = maybe_preprocess(real_name)*/
    Ref(_real_name_66826);
    _0 = _real_name_66826;
    _real_name_66826 = _64maybe_preprocess(_real_name_66826);
    DeRef(_0);

    /** main.e:107			fh = open_locked(real_name)*/
    Ref(_real_name_66826);
    _fh_66827 = _37open_locked(_real_name_66826);
    if (!IS_ATOM_INT(_fh_66827)) {
        _1 = (object)(DBL_PTR(_fh_66827)->dbl);
        DeRefDS(_fh_66827);
        _fh_66827 = _1;
    }

    /** main.e:108			return fh*/
    DeRef(_real_name_66826);
    DeRef(_32905);
    _32905 = NOVALUE;
    DeRef(_32901);
    _32901 = NOVALUE;
    return _fh_66827;
LF: 

    /** main.e:111		return -1*/
    DeRef(_real_name_66826);
    DeRef(_32905);
    _32905 = NOVALUE;
    DeRef(_32901);
    _32901 = NOVALUE;
    return -1;
    ;
}


void _68main()
{
    object _argc_66952 = NOVALUE;
    object _argv_66953 = NOVALUE;
    object _32985 = NOVALUE;
    object _32984 = NOVALUE;
    object _32983 = NOVALUE;
    object _32982 = NOVALUE;
    object _32981 = NOVALUE;
    object _32980 = NOVALUE;
    object _32979 = NOVALUE;
    object _32978 = NOVALUE;
    object _32977 = NOVALUE;
    object _32976 = NOVALUE;
    object _32975 = NOVALUE;
    object _32972 = NOVALUE;
    object _32970 = NOVALUE;
    object _32968 = NOVALUE;
    object _32967 = NOVALUE;
    object _32966 = NOVALUE;
    object _32965 = NOVALUE;
    object _32964 = NOVALUE;
    object _32963 = NOVALUE;
    object _32962 = NOVALUE;
    object _32961 = NOVALUE;
    object _32957 = NOVALUE;
    object _0, _1, _2;
    

    /** main.e:131		argv = command_line()*/
    DeRef(_argv_66953);
    _argv_66953 = Command_Line();

    /** main.e:133		if BIND then*/
    if (_36BIND_21052 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** main.e:134			argv = extract_options(argv)*/
    RefDS(_argv_66953);
    _0 = _argv_66953;
    _argv_66953 = _2extract_options(_argv_66953);
    DeRefDS(_0);
L1: 

    /** main.e:137		argc = length(argv)*/
    if (IS_SEQUENCE(_argv_66953)){
            _argc_66952 = SEQ_PTR(_argv_66953)->length;
    }
    else {
        _argc_66952 = 1;
    }

    /** main.e:139		Argv = argv*/
    RefDS(_argv_66953);
    DeRef(_36Argv_21458);
    _36Argv_21458 = _argv_66953;

    /** main.e:140		Argc = argc*/
    _36Argc_21457 = _argc_66952;

    /** main.e:142		TempErrName = "ex.err"*/
    RefDS(_32956);
    DeRefi(_50TempErrName_49236);
    _50TempErrName_49236 = _32956;

    /** main.e:143		TempWarningName = STDERR*/
    DeRef(_36TempWarningName_21461);
    _36TempWarningName_21461 = 2;

    /** main.e:144		display_warnings = 1*/
    _50display_warnings_49237 = 1;

    /** main.e:146		InitGlobals()*/
    _45InitGlobals();

    /** main.e:148		if TRANSLATE or BIND or INTERPRET then*/
    if (_36TRANSLATE_21049 != 0) {
        _32957 = 1;
        goto L2; // [69] 79
    }
    _32957 = (_36BIND_21052 != 0);
L2: 
    if (_32957 != 0) {
        goto L3; // [79] 90
    }
    if (_36INTERPRET_21046 == 0)
    {
        goto L4; // [86] 96
    }
    else{
    }
L3: 

    /** main.e:149			InitBackEnd(0)*/
    _2InitBackEnd(0);
L4: 

    /** main.e:152		src_file = GetSourceName()*/
    _0 = _68GetSourceName();
    _36src_file_21572 = _0;
    if (!IS_ATOM_INT(_36src_file_21572)) {
        _1 = (object)(DBL_PTR(_36src_file_21572)->dbl);
        DeRefDS(_36src_file_21572);
        _36src_file_21572 = _1;
    }

    /** main.e:154		if src_file = -1 then*/
    if (_36src_file_21572 != -1)
    goto L5; // [107] 185

    /** main.e:156			screen_output(STDERR, GetMsgText(CANT_OPEN_1, 0, {known_files[$]}))*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _32961 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _32961 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _32962 = (object)*(((s1_ptr)_2)->base + _32961);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_32962);
    ((intptr_t*)_2)[1] = _32962;
    _32963 = MAKE_SEQ(_1);
    _32962 = NOVALUE;
    _32964 = _39GetMsgText(51, 0, _32963);
    _32963 = NOVALUE;
    _50screen_output(2, _32964);
    _32964 = NOVALUE;

    /** main.e:157			if not batch_job and not test_only then*/
    _32965 = (_36batch_job_21460 == 0);
    if (_32965 == 0) {
        goto L6; // [147] 177
    }
    _32967 = (_36test_only_21459 == 0);
    if (_32967 == 0)
    {
        DeRef(_32967);
        _32967 = NOVALUE;
        goto L6; // [157] 177
    }
    else{
        DeRef(_32967);
        _32967 = NOVALUE;
    }

    /** main.e:158				maybe_any_key(GetMsgText(PAUSED_PRESS_ANY_KEY,0), STDERR)*/
    RefDS(_21997);
    _32968 = _39GetMsgText(277, 0, _21997);
    _5maybe_any_key(_32968, 2);
    _32968 = NOVALUE;
L6: 

    /** main.e:160			Cleanup(1)*/
    _50Cleanup(1);
    goto L7; // [182] 230
L5: 

    /** main.e:162		elsif src_file >= 0 then*/
    if (_36src_file_21572 < 0)
    goto L8; // [189] 229

    /** main.e:163			main_path = known_files[$]*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _32970 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _32970 = 1;
    }
    DeRef(_36main_path_21571);
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _36main_path_21571 = (object)*(((s1_ptr)_2)->base + _32970);
    Ref(_36main_path_21571);

    /** main.e:164			if length(main_path) = 0 then*/
    if (IS_SEQUENCE(_36main_path_21571)){
            _32972 = SEQ_PTR(_36main_path_21571)->length;
    }
    else {
        _32972 = 1;
    }
    if (_32972 != 0)
    goto L9; // [213] 228

    /** main.e:165				main_path = '.' & SLASH*/
    Concat((object_ptr)&_36main_path_21571, 46, 47);
L9: 
L8: 
L7: 

    /** main.e:171		if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto LA; // [234] 243
    }
    else{
    }

    /** main.e:172			InitBackEnd(1)*/
    _2InitBackEnd(1);
LA: 

    /** main.e:175		CheckPlatform()*/
    _2CheckPlatform();

    /** main.e:177		InitSymTab()*/
    _54InitSymTab();

    /** main.e:178		InitEmit()*/
    _47InitEmit();

    /** main.e:179		InitLex()*/
    _62InitLex();

    /** main.e:180		InitParser()*/
    _45InitParser();

    /** main.e:184		eu_namespace()*/
    _62eu_namespace();

    /** main.e:186		ifdef TRANSLATOR then*/

    /** main.e:187			if keep and build_system_type = BUILD_DIRECT then*/
    if (_58keep_42574 == 0) {
        goto LB; // [273] 342
    }
    _32976 = (_56build_system_type_45389 == 3);
    if (_32976 == 0)
    {
        DeRef(_32976);
        _32976 = NOVALUE;
        goto LB; // [286] 342
    }
    else{
        DeRef(_32976);
        _32976 = NOVALUE;
    }

    /** main.e:188				if 0 and not quick_has_changed(known_files[$]) then*/
    if (0 == 0) {
        goto LC; // [291] 341
    }
    if (IS_SEQUENCE(_37known_files_15407)){
            _32978 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _32978 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _32979 = (object)*(((s1_ptr)_2)->base + _32978);
    Ref(_32979);
    _32980 = _56quick_has_changed(_32979);
    _32979 = NOVALUE;
    if (IS_ATOM_INT(_32980)) {
        _32981 = (_32980 == 0);
    }
    else {
        _32981 = unary_op(NOT, _32980);
    }
    DeRef(_32980);
    _32980 = NOVALUE;
    if (_32981 == 0) {
        DeRef(_32981);
        _32981 = NOVALUE;
        goto LC; // [312] 341
    }
    else {
        if (!IS_ATOM_INT(_32981) && DBL_PTR(_32981)->dbl == 0.0){
            DeRef(_32981);
            _32981 = NOVALUE;
            goto LC; // [312] 341
        }
        DeRef(_32981);
        _32981 = NOVALUE;
    }
    DeRef(_32981);
    _32981 = NOVALUE;

    /** main.e:189					build_direct(1, known_files[$])*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _32982 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _32982 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _32983 = (object)*(((s1_ptr)_2)->base + _32982);
    Ref(_32983);
    _56build_direct(1, _32983);
    _32983 = NOVALUE;

    /** main.e:190					Cleanup(0)*/
    _50Cleanup(0);

    /** main.e:191					return*/
    DeRef(_argv_66953);
    DeRef(_32965);
    _32965 = NOVALUE;
    return;
LC: 
LB: 

    /** main.e:197		main_file()*/
    _62main_file();

    /** main.e:199		check_coverage()*/
    _51check_coverage();

    /** main.e:201		parser()*/
    _45parser();

    /** main.e:203		init_coverage()*/
    _51init_coverage();

    /** main.e:206		if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto LD; // [362] 373
    }
    else{
    }

    /** main.e:207			BackEnd(0) -- translate IL to C*/
    _2BackEnd(0);
    goto LE; // [370] 460
LD: 

    /** main.e:209		elsif BIND then*/
    if (_36BIND_21052 == 0)
    {
        goto LF; // [377] 387
    }
    else{
    }

    /** main.e:210			OutputIL()*/
    _2OutputIL();
    goto LE; // [384] 460
LF: 

    /** main.e:212		elsif INTERPRET and not test_only then*/
    if (_36INTERPRET_21046 == 0) {
        goto L10; // [391] 459
    }
    _32985 = (_36test_only_21459 == 0);
    if (_32985 == 0)
    {
        DeRef(_32985);
        _32985 = NOVALUE;
        goto L10; // [401] 459
    }
    else{
        DeRef(_32985);
        _32985 = NOVALUE;
    }

    /** main.e:213			ifdef not STDDEBUG then*/

    /** main.e:214				BackEnd(0) -- execute IL using Euphoria-coded back-end*/
    _2BackEnd(0);

    /** main.e:216			while repl do*/
L10: 
LE: 

    /** main.e:225		Cleanup(0) -- does warnings*/
    _50Cleanup(0);

    /** main.e:226	end procedure*/
    DeRef(_argv_66953);
    DeRef(_32965);
    _32965 = NOVALUE;
    return;
    ;
}



// 0x4A16D3DC
