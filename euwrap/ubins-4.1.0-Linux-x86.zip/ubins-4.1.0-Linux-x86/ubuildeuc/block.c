// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _65block_type_name(object _opcode_25124)
{
    object _14043 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_25124)) {
        _1 = (object)(DBL_PTR(_opcode_25124)->dbl);
        DeRefDS(_opcode_25124);
        _opcode_25124 = _1;
    }

    /** block.e:51		switch opcode do*/
    _0 = _opcode_25124;
    switch ( _0 ){ 

        /** block.e:52			case LOOP then*/
        case 422:

        /** block.e:53				return "LOOP"*/
        RefDS(_14041);
        return _14041;
        goto L1; // [20] 63

        /** block.e:54			case PROC then*/
        case 27:

        /** block.e:55				return "PROC"*/
        RefDS(_12948);
        return _12948;
        goto L1; // [32] 63

        /** block.e:56			case FUNC then*/
        case 501:

        /** block.e:57				return "FUNC"*/
        RefDS(_14042);
        return _14042;
        goto L1; // [44] 63

        /** block.e:58			case else*/
        default:

        /** block.e:59				return opnames[opcode]*/
        _2 = (object)SEQ_PTR(_61opnames_22891);
        _14043 = (object)*(((s1_ptr)_2)->base + _opcode_25124);
        RefDS(_14043);
        return _14043;
    ;}L1: 
    ;
}


void _65check_block(object _got_25140)
{
    object _expected_25141 = NOVALUE;
    object _14051 = NOVALUE;
    object _14050 = NOVALUE;
    object _14049 = NOVALUE;
    object _14045 = NOVALUE;
    object _14044 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:64		integer expected = block_stack[$][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14044 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14044 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    _14045 = (object)*(((s1_ptr)_2)->base + _14044);
    _2 = (object)SEQ_PTR(_14045);
    _expected_25141 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_expected_25141)){
        _expected_25141 = (object)DBL_PTR(_expected_25141)->dbl;
    }
    _14045 = NOVALUE;

    /** block.e:65		if got = FUNC then*/
    if (_got_25140 != 501)
    goto L1; // [24] 38

    /** block.e:66			got = PROC*/
    _got_25140 = 27;
L1: 

    /** block.e:68		if got != expected then*/
    if (_got_25140 == _expected_25141)
    goto L2; // [40] 66

    /** block.e:69			CompileErr( EXPECTED_END_OF_1_BLOCK_NOT_2, {block_type_name( expected ), block_type_name( got)} )*/
    _14049 = _65block_type_name(_expected_25141);
    _14050 = _65block_type_name(_got_25140);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14049;
    ((intptr_t *)_2)[2] = _14050;
    _14051 = MAKE_SEQ(_1);
    _14050 = NOVALUE;
    _14049 = NOVALUE;
    _50CompileErr(79, _14051, 0);
    _14051 = NOVALUE;
L2: 

    /** block.e:71	end procedure*/
    return;
    ;
}


void _65Block_var(object _sym_25159)
{
    object _block_25160 = NOVALUE;
    object _14072 = NOVALUE;
    object _14071 = NOVALUE;
    object _14070 = NOVALUE;
    object _14068 = NOVALUE;
    object _14067 = NOVALUE;
    object _14065 = NOVALUE;
    object _14064 = NOVALUE;
    object _14063 = NOVALUE;
    object _14062 = NOVALUE;
    object _14061 = NOVALUE;
    object _14060 = NOVALUE;
    object _14059 = NOVALUE;
    object _14057 = NOVALUE;
    object _14055 = NOVALUE;
    object _14054 = NOVALUE;
    object _14052 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_25159)) {
        _1 = (object)(DBL_PTR(_sym_25159)->dbl);
        DeRefDS(_sym_25159);
        _sym_25159 = _1;
    }

    /** block.e:75		sequence block = block_stack[$]*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14052 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14052 = 1;
    }
    DeRef(_block_25160);
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    _block_25160 = (object)*(((s1_ptr)_2)->base + _14052);
    Ref(_block_25160);

    /** block.e:76		block_stack[$] = 0*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14054 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14054 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    _2 = (object)(((s1_ptr)_2)->base + _14054);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** block.e:77		if length(block_stack) > 1 then*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14055 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14055 = 1;
    }
    if (_14055 <= 1)
    goto L1; // [34] 58

    /** block.e:79			SymTab[sym][S_BLOCK] = block[BLOCK_SYM]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_25159 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_block_25160);
    _14059 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_14059);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_BLOCK_21104))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_BLOCK_21104)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_BLOCK_21104);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14059;
    if( _1 != _14059 ){
        DeRef(_1);
    }
    _14059 = NOVALUE;
    _14057 = NOVALUE;
L1: 

    /** block.e:82		if length(block[BLOCK_VARS]) then*/
    _2 = (object)SEQ_PTR(_block_25160);
    _14060 = (object)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_14060)){
            _14061 = SEQ_PTR(_14060)->length;
    }
    else {
        _14061 = 1;
    }
    _14060 = NOVALUE;
    if (_14061 == 0)
    {
        _14061 = NOVALUE;
        goto L2; // [67] 99
    }
    else{
        _14061 = NOVALUE;
    }

    /** block.e:83			SymTab[block[BLOCK_VARS][$]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (object)SEQ_PTR(_block_25160);
    _14062 = (object)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_14062)){
            _14063 = SEQ_PTR(_14062)->length;
    }
    else {
        _14063 = 1;
    }
    _2 = (object)SEQ_PTR(_14062);
    _14064 = (object)*(((s1_ptr)_2)->base + _14063);
    _14062 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14064))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14064)->dbl));
    else
    _3 = (object)(_14064 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21076))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21076)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21076);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_25159;
    DeRef(_1);
    _14065 = NOVALUE;
    goto L3; // [96] 119
L2: 

    /** block.e:85			SymTab[block[BLOCK_SYM]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (object)SEQ_PTR(_block_25160);
    _14067 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14067))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14067)->dbl));
    else
    _3 = (object)(_14067 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21076))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21076)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21076);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_25159;
    DeRef(_1);
    _14068 = NOVALUE;
L3: 

    /** block.e:88		block[BLOCK_VARS] &= sym*/
    _2 = (object)SEQ_PTR(_block_25160);
    _14070 = (object)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_14070) && IS_ATOM(_sym_25159)) {
        Append(&_14071, _14070, _sym_25159);
    }
    else if (IS_ATOM(_14070) && IS_SEQUENCE(_sym_25159)) {
    }
    else {
        Concat((object_ptr)&_14071, _14070, _sym_25159);
        _14070 = NOVALUE;
    }
    _14070 = NOVALUE;
    _2 = (object)SEQ_PTR(_block_25160);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25160 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14071;
    if( _1 != _14071 ){
        DeRef(_1);
    }
    _14071 = NOVALUE;

    /** block.e:90		block_stack[$] = block*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14072 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14072 = 1;
    }
    RefDS(_block_25160);
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    _2 = (object)(((s1_ptr)_2)->base + _14072);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _block_25160;
    DeRef(_1);

    /** block.e:91		ifdef BDEBUG then*/

    /** block.e:96	end procedure*/
    DeRefDS(_block_25160);
    _14064 = NOVALUE;
    _14067 = NOVALUE;
    _14060 = NOVALUE;
    return;
    ;
}


void _65NewBlock(object _opcode_25194, object _block_label_25195)
{
    object _block_25213 = NOVALUE;
    object _14086 = NOVALUE;
    object _14085 = NOVALUE;
    object _14084 = NOVALUE;
    object _14082 = NOVALUE;
    object _14080 = NOVALUE;
    object _14079 = NOVALUE;
    object _14077 = NOVALUE;
    object _14076 = NOVALUE;
    object _14074 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:101		SymTab = append( SymTab, repeat( 0, SIZEOF_BLOCK_ENTRY ) )*/
    _14074 = Repeat(0, _36SIZEOF_BLOCK_ENTRY_21216);
    RefDS(_14074);
    Append(&_37SymTab_15406, _37SymTab_15406, _14074);
    DeRefDS(_14074);
    _14074 = NOVALUE;

    /** block.e:102		SymTab[$][S_MODE] = M_BLOCK*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _14076 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _14076 = 1;
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14076 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4;
    DeRef(_1);
    _14077 = NOVALUE;

    /** block.e:103		SymTab[$][S_FIRST_LINE] = gline_number*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _14079 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _14079 = 1;
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14079 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FIRST_LINE_21109))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FIRST_LINE_21109)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FIRST_LINE_21109);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36gline_number_21452;
    DeRef(_1);
    _14080 = NOVALUE;

    /** block.e:105		sequence block = repeat( 0, BLOCK_SIZE-1 )*/
    _14082 = 6;
    DeRef(_block_25213);
    _block_25213 = Repeat(0, 6);
    _14082 = NOVALUE;

    /** block.e:106		block[BLOCK_SYM]    = length(SymTab)*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _14084 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _14084 = 1;
    }
    _2 = (object)SEQ_PTR(_block_25213);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25213 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    *(intptr_t *)_2 = _14084;
    if( _1 != _14084 ){
    }
    _14084 = NOVALUE;

    /** block.e:107		block[BLOCK_OPCODE] = opcode*/
    _2 = (object)SEQ_PTR(_block_25213);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25213 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    *(intptr_t *)_2 = _opcode_25194;

    /** block.e:108		block[BLOCK_LABEL]  = block_label*/
    Ref(_block_label_25195);
    _2 = (object)SEQ_PTR(_block_25213);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25213 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    *(intptr_t *)_2 = _block_label_25195;

    /** block.e:109		block[BLOCK_START]  = length(Code) + 1*/
    if (IS_SEQUENCE(_36Code_21539)){
            _14085 = SEQ_PTR(_36Code_21539)->length;
    }
    else {
        _14085 = 1;
    }
    _14086 = _14085 + 1;
    _14085 = NOVALUE;
    _2 = (object)SEQ_PTR(_block_25213);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25213 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14086;
    if( _1 != _14086 ){
        DeRef(_1);
    }
    _14086 = NOVALUE;

    /** block.e:110		block[BLOCK_VARS]   = {}*/
    RefDS(_5);
    _2 = (object)SEQ_PTR(_block_25213);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25213 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _5;
    DeRef(_1);

    /** block.e:112		block_stack = append( block_stack, block )*/
    RefDS(_block_25213);
    Append(&_65block_stack_25113, _65block_stack_25113, _block_25213);

    /** block.e:113		current_block = length(SymTab)*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _65current_block_25120 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _65current_block_25120 = 1;
    }

    /** block.e:114	end procedure*/
    DeRefi(_block_label_25195);
    DeRefDS(_block_25213);
    return;
    ;
}


void _65Start_block(object _opcode_25226, object _block_label_25227)
{
    object _last_block_25229 = NOVALUE;
    object _label_name_25257 = NOVALUE;
    object _14108 = NOVALUE;
    object _14107 = NOVALUE;
    object _14106 = NOVALUE;
    object _14103 = NOVALUE;
    object _14102 = NOVALUE;
    object _14100 = NOVALUE;
    object _14099 = NOVALUE;
    object _14098 = NOVALUE;
    object _14097 = NOVALUE;
    object _14096 = NOVALUE;
    object _14093 = NOVALUE;
    object _14091 = NOVALUE;
    object _14090 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:120		symtab_index last_block = current_block*/
    _last_block_25229 = _65current_block_25120;

    /** block.e:121		if opcode = FUNC then*/
    if (_opcode_25226 != 501)
    goto L1; // [16] 30

    /** block.e:122			opcode = PROC*/
    _opcode_25226 = 27;
L1: 

    /** block.e:124		NewBlock( opcode, block_label )*/
    Ref(_block_label_25227);
    _65NewBlock(_opcode_25226, _block_label_25227);

    /** block.e:126		if find(opcode, RTN_TOKS) then*/
    _14090 = find_from(_opcode_25226, _38RTN_TOKS_16045, 1);
    if (_14090 == 0)
    {
        _14090 = NOVALUE;
        goto L2; // [45] 105
    }
    else{
        _14090 = NOVALUE;
    }

    /** block.e:127			SymTab[block_label][S_BLOCK] = current_block*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_block_label_25227))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_block_label_25227)->dbl));
    else
    _3 = (object)(_block_label_25227 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_BLOCK_21104))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_BLOCK_21104)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_BLOCK_21104);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _65current_block_25120;
    DeRef(_1);
    _14091 = NOVALUE;

    /** block.e:128			SymTab[current_block][S_NAME] = sprintf("BLOCK: %s", {SymTab[block_label][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_65current_block_25120 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_block_label_25227)){
        _14096 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_block_label_25227)->dbl));
    }
    else{
        _14096 = (object)*(((s1_ptr)_2)->base + _block_label_25227);
    }
    _2 = (object)SEQ_PTR(_14096);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _14097 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _14097 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _14096 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_14097);
    ((intptr_t*)_2)[1] = _14097;
    _14098 = MAKE_SEQ(_1);
    _14097 = NOVALUE;
    _14099 = EPrintf(-9999999, _14095, _14098);
    DeRefDS(_14098);
    _14098 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NAME_21084))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NAME_21084);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14099;
    if( _1 != _14099 ){
        DeRef(_1);
    }
    _14099 = NOVALUE;
    _14093 = NOVALUE;
    goto L3; // [102] 185
L2: 

    /** block.e:129		elsif current_block then*/
    if (_65current_block_25120 == 0)
    {
        goto L4; // [109] 182
    }
    else{
    }

    /** block.e:135			SymTab[current_block][S_BLOCK] = last_block*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_65current_block_25120 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_BLOCK_21104))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_BLOCK_21104)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_BLOCK_21104);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _last_block_25229;
    DeRef(_1);
    _14100 = NOVALUE;

    /** block.e:136			sequence label_name = ""*/
    RefDS(_5);
    DeRefi(_label_name_25257);
    _label_name_25257 = _5;

    /** block.e:137			if sequence(block_label) then*/
    _14102 = IS_SEQUENCE(_block_label_25227);
    if (_14102 == 0)
    {
        _14102 = NOVALUE;
        goto L5; // [141] 152
    }
    else{
        _14102 = NOVALUE;
    }

    /** block.e:138				label_name = block_label*/
    Ref(_block_label_25227);
    DeRefDSi(_label_name_25257);
    _label_name_25257 = _block_label_25227;
L5: 

    /** block.e:141			SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", {block_type_name(opcode), label_name})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_65current_block_25120 + ((s1_ptr)_2)->base);
    _14106 = _65block_type_name(_opcode_25226);
    RefDS(_label_name_25257);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14106;
    ((intptr_t *)_2)[2] = _label_name_25257;
    _14107 = MAKE_SEQ(_1);
    _14106 = NOVALUE;
    _14108 = EPrintf(-9999999, _14105, _14107);
    DeRefDS(_14107);
    _14107 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NAME_21084))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NAME_21084);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14108;
    if( _1 != _14108 ){
        DeRef(_1);
    }
    _14108 = NOVALUE;
    _14103 = NOVALUE;
L4: 
    DeRefi(_label_name_25257);
    _label_name_25257 = NOVALUE;
L3: 

    /** block.e:144		ifdef BDEBUG then*/

    /** block.e:153	end procedure*/
    DeRefi(_block_label_25227);
    return;
    ;
}


void _65block_label(object _label_name_25273)
{
    object _14122 = NOVALUE;
    object _14121 = NOVALUE;
    object _14120 = NOVALUE;
    object _14119 = NOVALUE;
    object _14118 = NOVALUE;
    object _14117 = NOVALUE;
    object _14115 = NOVALUE;
    object _14113 = NOVALUE;
    object _14112 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:157		block_stack[$][BLOCK_LABEL] = label_name*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14112 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14112 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65block_stack_25113 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14112 + ((s1_ptr)_2)->base);
    RefDS(_label_name_25273);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _label_name_25273;
    DeRef(_1);
    _14113 = NOVALUE;

    /** block.e:158		SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", */
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_65current_block_25120 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14117 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14117 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    _14118 = (object)*(((s1_ptr)_2)->base + _14117);
    _2 = (object)SEQ_PTR(_14118);
    _14119 = (object)*(((s1_ptr)_2)->base + 2);
    _14118 = NOVALUE;
    Ref(_14119);
    _14120 = _65block_type_name(_14119);
    _14119 = NOVALUE;
    RefDS(_label_name_25273);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14120;
    ((intptr_t *)_2)[2] = _label_name_25273;
    _14121 = MAKE_SEQ(_1);
    _14120 = NOVALUE;
    _14122 = EPrintf(-9999999, _14105, _14121);
    DeRefDS(_14121);
    _14121 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NAME_21084))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NAME_21084);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14122;
    if( _1 != _14122 ){
        DeRef(_1);
    }
    _14122 = NOVALUE;
    _14115 = NOVALUE;

    /** block.e:160	end procedure*/
    DeRefDS(_label_name_25273);
    return;
    ;
}


object _65pop_block()
{
    object _block_25292 = NOVALUE;
    object _block_vars_25305 = NOVALUE;
    object _14151 = NOVALUE;
    object _14149 = NOVALUE;
    object _14148 = NOVALUE;
    object _14147 = NOVALUE;
    object _14146 = NOVALUE;
    object _14144 = NOVALUE;
    object _14143 = NOVALUE;
    object _14142 = NOVALUE;
    object _14141 = NOVALUE;
    object _14140 = NOVALUE;
    object _14139 = NOVALUE;
    object _14138 = NOVALUE;
    object _14137 = NOVALUE;
    object _14136 = NOVALUE;
    object _14135 = NOVALUE;
    object _14131 = NOVALUE;
    object _14130 = NOVALUE;
    object _14128 = NOVALUE;
    object _14127 = NOVALUE;
    object _14125 = NOVALUE;
    object _14123 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:164		if not length(block_stack) then*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14123 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14123 = 1;
    }
    if (_14123 != 0)
    goto L1; // [8] 18
    _14123 = NOVALUE;

    /** block.e:165			return 0*/
    DeRef(_block_25292);
    DeRef(_block_vars_25305);
    return 0;
L1: 

    /** block.e:168		sequence  block = block_stack[$]*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14125 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14125 = 1;
    }
    DeRef(_block_25292);
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    _block_25292 = (object)*(((s1_ptr)_2)->base + _14125);
    Ref(_block_25292);

    /** block.e:169		block_stack = block_stack[1..$-1]*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14127 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14127 = 1;
    }
    _14128 = _14127 - 1;
    _14127 = NOVALUE;
    rhs_slice_target = (object_ptr)&_65block_stack_25113;
    RHS_Slice(_65block_stack_25113, 1, _14128);

    /** block.e:170		SymTab[block[BLOCK_SYM]][S_LAST_LINE] = gline_number*/
    _2 = (object)SEQ_PTR(_block_25292);
    _14130 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14130))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14130)->dbl));
    else
    _3 = (object)(_14130 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LAST_LINE_21114))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LAST_LINE_21114)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LAST_LINE_21114);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36gline_number_21452;
    DeRef(_1);
    _14131 = NOVALUE;

    /** block.e:172		ifdef BDEBUG then*/

    /** block.e:177		sequence block_vars = block[BLOCK_VARS]*/
    DeRef(_block_vars_25305);
    _2 = (object)SEQ_PTR(_block_25292);
    _block_vars_25305 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_block_vars_25305);

    /** block.e:178		for sx = 1 to length( block_vars ) do*/
    if (IS_SEQUENCE(_block_vars_25305)){
            _14135 = SEQ_PTR(_block_vars_25305)->length;
    }
    else {
        _14135 = 1;
    }
    {
        object _sx_25308;
        _sx_25308 = 1;
L2: 
        if (_sx_25308 > _14135){
            goto L3; // [83] 172
        }

        /** block.e:180			if SymTab[block_vars[sx]][S_MODE] = M_NORMAL */
        _2 = (object)SEQ_PTR(_block_vars_25305);
        _14136 = (object)*(((s1_ptr)_2)->base + _sx_25308);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_14136)){
            _14137 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14136)->dbl));
        }
        else{
            _14137 = (object)*(((s1_ptr)_2)->base + _14136);
        }
        _2 = (object)SEQ_PTR(_14137);
        _14138 = (object)*(((s1_ptr)_2)->base + 3);
        _14137 = NOVALUE;
        if (IS_ATOM_INT(_14138)) {
            _14139 = (_14138 == 1);
        }
        else {
            _14139 = binary_op(EQUALS, _14138, 1);
        }
        _14138 = NOVALUE;
        if (IS_ATOM_INT(_14139)) {
            if (_14139 == 0) {
                goto L4; // [114] 165
            }
        }
        else {
            if (DBL_PTR(_14139)->dbl == 0.0) {
                goto L4; // [114] 165
            }
        }
        _2 = (object)SEQ_PTR(_block_vars_25305);
        _14141 = (object)*(((s1_ptr)_2)->base + _sx_25308);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_14141)){
            _14142 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14141)->dbl));
        }
        else{
            _14142 = (object)*(((s1_ptr)_2)->base + _14141);
        }
        _2 = (object)SEQ_PTR(_14142);
        _14143 = (object)*(((s1_ptr)_2)->base + 4);
        _14142 = NOVALUE;
        if (IS_ATOM_INT(_14143)) {
            _14144 = (_14143 <= 5);
        }
        else {
            _14144 = binary_op(LESSEQ, _14143, 5);
        }
        _14143 = NOVALUE;
        if (_14144 == 0) {
            DeRef(_14144);
            _14144 = NOVALUE;
            goto L4; // [141] 165
        }
        else {
            if (!IS_ATOM_INT(_14144) && DBL_PTR(_14144)->dbl == 0.0){
                DeRef(_14144);
                _14144 = NOVALUE;
                goto L4; // [141] 165
            }
            DeRef(_14144);
            _14144 = NOVALUE;
        }
        DeRef(_14144);
        _14144 = NOVALUE;

        /** block.e:182				ifdef BDEBUG then*/

        /** block.e:187				Hide( block_vars[sx] )*/
        _2 = (object)SEQ_PTR(_block_vars_25305);
        _14146 = (object)*(((s1_ptr)_2)->base + _sx_25308);
        Ref(_14146);
        _54Hide(_14146);
        _14146 = NOVALUE;

        /** block.e:188				LintCheck( block_vars[sx] )*/
        _2 = (object)SEQ_PTR(_block_vars_25305);
        _14147 = (object)*(((s1_ptr)_2)->base + _sx_25308);
        Ref(_14147);
        _54LintCheck(_14147);
        _14147 = NOVALUE;
L4: 

        /** block.e:191		end for*/
        _sx_25308 = _sx_25308 + 1;
        goto L2; // [167] 90
L3: 
        ;
    }

    /** block.e:213		current_block = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14148 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14148 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    _14149 = (object)*(((s1_ptr)_2)->base + _14148);
    _2 = (object)SEQ_PTR(_14149);
    _65current_block_25120 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_65current_block_25120)){
        _65current_block_25120 = (object)DBL_PTR(_65current_block_25120)->dbl;
    }
    _14149 = NOVALUE;

    /** block.e:214		return block[BLOCK_SYM]*/
    _2 = (object)SEQ_PTR(_block_25292);
    _14151 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_14151);
    DeRefDS(_block_25292);
    DeRef(_block_vars_25305);
    _14130 = NOVALUE;
    DeRef(_14139);
    _14139 = NOVALUE;
    DeRef(_14128);
    _14128 = NOVALUE;
    _14141 = NOVALUE;
    _14136 = NOVALUE;
    return _14151;
    ;
}


object _65top_block(object _offset_25337)
{
    object _14159 = NOVALUE;
    object _14158 = NOVALUE;
    object _14157 = NOVALUE;
    object _14156 = NOVALUE;
    object _14155 = NOVALUE;
    object _14154 = NOVALUE;
    object _14152 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:219		if offset >= length(block_stack) then*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14152 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14152 = 1;
    }
    if (_offset_25337 < _14152)
    goto L1; // [10] 35

    /** block.e:220			CompileErr(LEAVING_TOO_MANY_BLOCKS_1__2, {offset,length(block_stack)})*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14154 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14154 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _offset_25337;
    ((intptr_t *)_2)[2] = _14154;
    _14155 = MAKE_SEQ(_1);
    _14154 = NOVALUE;
    _50CompileErr(107, _14155, 0);
    _14155 = NOVALUE;
    goto L2; // [32] 59
L1: 

    /** block.e:222			return block_stack[$-offset][BLOCK_SYM]*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14156 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14156 = 1;
    }
    _14157 = _14156 - _offset_25337;
    _14156 = NOVALUE;
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    _14158 = (object)*(((s1_ptr)_2)->base + _14157);
    _2 = (object)SEQ_PTR(_14158);
    _14159 = (object)*(((s1_ptr)_2)->base + 1);
    _14158 = NOVALUE;
    Ref(_14159);
    _14157 = NOVALUE;
    return _14159;
L2: 
    ;
}


void _65End_block(object _opcode_25352)
{
    object _ix_25363 = NOVALUE;
    object _14167 = NOVALUE;
    object _14164 = NOVALUE;
    object _14163 = NOVALUE;
    object _14162 = NOVALUE;
    object _14161 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:229		if opcode = FUNC then*/

    /** block.e:232		check_block( opcode )*/
    _65check_block(_opcode_25352);

    /** block.e:233		if not length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14161 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14161 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    _14162 = (object)*(((s1_ptr)_2)->base + _14161);
    _2 = (object)SEQ_PTR(_14162);
    _14163 = (object)*(((s1_ptr)_2)->base + 6);
    _14162 = NOVALUE;
    if (IS_SEQUENCE(_14163)){
            _14164 = SEQ_PTR(_14163)->length;
    }
    else {
        _14164 = 1;
    }
    _14163 = NOVALUE;
    if (_14164 != 0)
    goto L1; // [44] 64
    _14164 = NOVALUE;

    /** block.e:234			integer ix = 1*/
    _ix_25363 = 1;

    /** block.e:235			ix = pop_block()*/
    _ix_25363 = _65pop_block();
    if (!IS_ATOM_INT(_ix_25363)) {
        _1 = (object)(DBL_PTR(_ix_25363)->dbl);
        DeRefDS(_ix_25363);
        _ix_25363 = _1;
    }
    goto L2; // [61] 80
L1: 

    /** block.e:237			Push( pop_block() )*/
    _14167 = _65pop_block();
    _47Push(_14167);
    _14167 = NOVALUE;

    /** block.e:238			emit_op( EXIT_BLOCK )*/
    _47emit_op(206);
L2: 

    /** block.e:241	end procedure*/
    _14163 = NOVALUE;
    return;
    ;
}


object _65End_inline_block(object _opcode_25372)
{
    object _14174 = NOVALUE;
    object _14173 = NOVALUE;
    object _14172 = NOVALUE;
    object _14171 = NOVALUE;
    object _14170 = NOVALUE;
    object _14169 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:246		if opcode = FUNC then*/

    /** block.e:249		if length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14169 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14169 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    _14170 = (object)*(((s1_ptr)_2)->base + _14169);
    _2 = (object)SEQ_PTR(_14170);
    _14171 = (object)*(((s1_ptr)_2)->base + 6);
    _14170 = NOVALUE;
    if (IS_SEQUENCE(_14171)){
            _14172 = SEQ_PTR(_14171)->length;
    }
    else {
        _14172 = 1;
    }
    _14171 = NOVALUE;
    if (_14172 == 0)
    {
        _14172 = NOVALUE;
        goto L1; // [39] 60
    }
    else{
        _14172 = NOVALUE;
    }

    /** block.e:250			return { EXIT_BLOCK, pop_block() }*/
    _14173 = _65pop_block();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 206;
    ((intptr_t *)_2)[2] = _14173;
    _14174 = MAKE_SEQ(_1);
    _14173 = NOVALUE;
    _14171 = NOVALUE;
    return _14174;
    goto L2; // [57] 72
L1: 

    /** block.e:252			Drop_block( opcode )*/
    _65Drop_block(_opcode_25372);

    /** block.e:253			return {}*/
    RefDS(_5);
    _14171 = NOVALUE;
    DeRef(_14174);
    _14174 = NOVALUE;
    return _5;
L2: 
    ;
}


void _65Sibling_block(object _opcode_25389)
{
    object _0, _1, _2;
    

    /** block.e:261		End_block( opcode )*/
    _65End_block(_opcode_25389);

    /** block.e:262		Start_block( opcode )*/
    _65Start_block(_opcode_25389, 0);

    /** block.e:263	end procedure*/
    return;
    ;
}


void _65Leave_block(object _offset_25392)
{
    object _14180 = NOVALUE;
    object _14179 = NOVALUE;
    object _14178 = NOVALUE;
    object _14177 = NOVALUE;
    object _14176 = NOVALUE;
    object _14175 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_offset_25392)) {
        _1 = (object)(DBL_PTR(_offset_25392)->dbl);
        DeRefDS(_offset_25392);
        _offset_25392 = _1;
    }

    /** block.e:268		if length( block_stack[$-offset][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14175 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14175 = 1;
    }
    _14176 = _14175 - _offset_25392;
    _14175 = NOVALUE;
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    _14177 = (object)*(((s1_ptr)_2)->base + _14176);
    _2 = (object)SEQ_PTR(_14177);
    _14178 = (object)*(((s1_ptr)_2)->base + 6);
    _14177 = NOVALUE;
    if (IS_SEQUENCE(_14178)){
            _14179 = SEQ_PTR(_14178)->length;
    }
    else {
        _14179 = 1;
    }
    _14178 = NOVALUE;
    if (_14179 == 0)
    {
        _14179 = NOVALUE;
        goto L1; // [25] 45
    }
    else{
        _14179 = NOVALUE;
    }

    /** block.e:269			Push( top_block( offset ) )*/
    _14180 = _65top_block(_offset_25392);
    _47Push(_14180);
    _14180 = NOVALUE;

    /** block.e:270			emit_op( EXIT_BLOCK )*/
    _47emit_op(206);
L1: 

    /** block.e:272	end procedure*/
    DeRef(_14176);
    _14176 = NOVALUE;
    _14178 = NOVALUE;
    return;
    ;
}


void _65Leave_blocks(object _blocks_25412, object _block_type_25413)
{
    object _bx_25414 = NOVALUE;
    object _Block_opcode_3__tmp_at29_25421 = NOVALUE;
    object _Block_opcode_2__tmp_at29_25420 = NOVALUE;
    object _Block_opcode_1__tmp_at29_25419 = NOVALUE;
    object _Block_opcode_inlined_Block_opcode_at_29_25418 = NOVALUE;
    object _14193 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_blocks_25412)) {
        _1 = (object)(DBL_PTR(_blocks_25412)->dbl);
        DeRefDS(_blocks_25412);
        _blocks_25412 = _1;
    }

    /** block.e:284		integer bx = 0*/
    _bx_25414 = 0;

    /** block.e:285		while blocks do*/
L1: 
    if (_blocks_25412 == 0)
    {
        goto L2; // [15] 119
    }
    else{
    }

    /** block.e:286			Leave_block( bx )*/
    _65Leave_block(_bx_25414);

    /** block.e:288			if block_type then*/
    if (_block_type_25413 == 0)
    {
        goto L3; // [25] 101
    }
    else{
    }

    /** block.e:289				switch Block_opcode( bx ) do*/

    /** block.e:276		return block_stack[$-bx][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _Block_opcode_1__tmp_at29_25419 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _Block_opcode_1__tmp_at29_25419 = 1;
    }
    _Block_opcode_2__tmp_at29_25420 = _Block_opcode_1__tmp_at29_25419 - _bx_25414;
    DeRef(_Block_opcode_3__tmp_at29_25421);
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    _Block_opcode_3__tmp_at29_25421 = (object)*(((s1_ptr)_2)->base + _Block_opcode_2__tmp_at29_25420);
    Ref(_Block_opcode_3__tmp_at29_25421);
    DeRef(_Block_opcode_inlined_Block_opcode_at_29_25418);
    _2 = (object)SEQ_PTR(_Block_opcode_3__tmp_at29_25421);
    _Block_opcode_inlined_Block_opcode_at_29_25418 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_Block_opcode_inlined_Block_opcode_at_29_25418);
    DeRef(_Block_opcode_3__tmp_at29_25421);
    _Block_opcode_3__tmp_at29_25421 = NOVALUE;
    if (IS_SEQUENCE(_Block_opcode_inlined_Block_opcode_at_29_25418) ){
        goto L4; // [52] 82
    }
    if(!IS_ATOM_INT(_Block_opcode_inlined_Block_opcode_at_29_25418)){
        if( (DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_25418)->dbl != (eudouble) ((object) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_25418)->dbl) ) ){
            goto L4; // [52] 82
        }
        _0 = (object) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_25418)->dbl;
    }
    else {
        _0 = _Block_opcode_inlined_Block_opcode_at_29_25418;
    };
    switch ( _0 ){ 

        /** block.e:290					case FOR, WHILE, LOOP then*/
        case 21:
        case 47:
        case 422:

        /** block.e:291						if block_type = LOOP_BLOCK then*/
        if (_block_type_25413 != 1)
        goto L5; // [67] 108

        /** block.e:292							blocks -= 1*/
        _blocks_25412 = _blocks_25412 - 1;
        goto L5; // [78] 108

        /** block.e:294					case else*/
        default:
L4: 

        /** block.e:295						if block_type = CONDITIONAL_BLOCK then*/
        if (_block_type_25413 != 2)
        goto L6; // [86] 97

        /** block.e:296							blocks -= 1*/
        _blocks_25412 = _blocks_25412 - 1;
L6: 
    ;}    goto L5; // [98] 108
L3: 

    /** block.e:300				blocks -= 1*/
    _blocks_25412 = _blocks_25412 - 1;
L5: 

    /** block.e:302			bx += 1*/
    _bx_25414 = _bx_25414 + 1;

    /** block.e:303		end while*/
    goto L1; // [116] 15
L2: 

    /** block.e:304		for i = 0 to blocks - 1 do*/
    _14193 = _blocks_25412 - 1;
    if ((object)((uintptr_t)_14193 +(uintptr_t) HIGH_BITS) >= 0){
        _14193 = NewDouble((eudouble)_14193);
    }
    {
        object _i_25439;
        _i_25439 = 0;
L7: 
        if (binary_op_a(GREATER, _i_25439, _14193)){
            goto L8; // [125] 144
        }

        /** block.e:305			Leave_block( i )*/
        Ref(_i_25439);
        _65Leave_block(_i_25439);

        /** block.e:306		end for*/
        _0 = _i_25439;
        if (IS_ATOM_INT(_i_25439)) {
            _i_25439 = _i_25439 + 1;
            if ((object)((uintptr_t)_i_25439 +(uintptr_t) HIGH_BITS) >= 0){
                _i_25439 = NewDouble((eudouble)_i_25439);
            }
        }
        else {
            _i_25439 = binary_op_a(PLUS, _i_25439, 1);
        }
        DeRef(_0);
        goto L7; // [139] 132
L8: 
        ;
        DeRef(_i_25439);
    }

    /** block.e:307	end procedure*/
    DeRef(_14193);
    _14193 = NOVALUE;
    return;
    ;
}


void _65Drop_block(object _opcode_25443)
{
    object _x_25445 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:311		check_block( opcode )*/
    _65check_block(_opcode_25443);

    /** block.e:312		symtab_index x = pop_block()*/
    _x_25445 = _65pop_block();
    if (!IS_ATOM_INT(_x_25445)) {
        _1 = (object)(DBL_PTR(_x_25445)->dbl);
        DeRefDS(_x_25445);
        _x_25445 = _1;
    }

    /** block.e:313	end procedure*/
    return;
    ;
}


void _65Pop_block_var()
{
    object _sym_25450 = NOVALUE;
    object _block_sym_25457 = NOVALUE;
    object _14221 = NOVALUE;
    object _14220 = NOVALUE;
    object _14219 = NOVALUE;
    object _14218 = NOVALUE;
    object _14217 = NOVALUE;
    object _14216 = NOVALUE;
    object _14215 = NOVALUE;
    object _14214 = NOVALUE;
    object _14212 = NOVALUE;
    object _14211 = NOVALUE;
    object _14209 = NOVALUE;
    object _14208 = NOVALUE;
    object _14206 = NOVALUE;
    object _14203 = NOVALUE;
    object _14201 = NOVALUE;
    object _14200 = NOVALUE;
    object _14198 = NOVALUE;
    object _14197 = NOVALUE;
    object _14196 = NOVALUE;
    object _14195 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:316		symtab_index sym = block_stack[$][BLOCK_VARS][$]*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14195 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14195 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    _14196 = (object)*(((s1_ptr)_2)->base + _14195);
    _2 = (object)SEQ_PTR(_14196);
    _14197 = (object)*(((s1_ptr)_2)->base + 6);
    _14196 = NOVALUE;
    if (IS_SEQUENCE(_14197)){
            _14198 = SEQ_PTR(_14197)->length;
    }
    else {
        _14198 = 1;
    }
    _2 = (object)SEQ_PTR(_14197);
    _sym_25450 = (object)*(((s1_ptr)_2)->base + _14198);
    if (!IS_ATOM_INT(_sym_25450)){
        _sym_25450 = (object)DBL_PTR(_sym_25450)->dbl;
    }
    _14197 = NOVALUE;

    /** block.e:317		symtab_index block_sym = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14200 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14200 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    _14201 = (object)*(((s1_ptr)_2)->base + _14200);
    _2 = (object)SEQ_PTR(_14201);
    _block_sym_25457 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_block_sym_25457)){
        _block_sym_25457 = (object)DBL_PTR(_block_sym_25457)->dbl;
    }
    _14201 = NOVALUE;

    /** block.e:318		while sym_next_in_block( block_sym ) != sym do*/
L1: 
    _14203 = _54sym_next_in_block(_block_sym_25457);
    if (binary_op_a(EQUALS, _14203, _sym_25450)){
        DeRef(_14203);
        _14203 = NOVALUE;
        goto L2; // [51] 68
    }
    DeRef(_14203);
    _14203 = NOVALUE;

    /** block.e:319			block_sym = sym_next_in_block( block_sym )*/
    _block_sym_25457 = _54sym_next_in_block(_block_sym_25457);
    if (!IS_ATOM_INT(_block_sym_25457)) {
        _1 = (object)(DBL_PTR(_block_sym_25457)->dbl);
        DeRefDS(_block_sym_25457);
        _block_sym_25457 = _1;
    }

    /** block.e:320		end while*/
    goto L1; // [65] 47
L2: 

    /** block.e:322		SymTab[block_sym][S_NEXT_IN_BLOCK] = sym_next_in_block( sym )*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_block_sym_25457 + ((s1_ptr)_2)->base);
    _14208 = _54sym_next_in_block(_sym_25450);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21076))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21076)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21076);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14208;
    if( _1 != _14208 ){
        DeRef(_1);
    }
    _14208 = NOVALUE;
    _14206 = NOVALUE;

    /** block.e:323		SymTab[sym][S_NEXT_IN_BLOCK] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_25450 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21076))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21076)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21076);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _14209 = NOVALUE;

    /** block.e:325		block_stack[$][BLOCK_VARS] = eu:remove( block_stack[$][BLOCK_VARS], */
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14211 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14211 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65block_stack_25113 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14211 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14214 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14214 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    _14215 = (object)*(((s1_ptr)_2)->base + _14214);
    _2 = (object)SEQ_PTR(_14215);
    _14216 = (object)*(((s1_ptr)_2)->base + 6);
    _14215 = NOVALUE;
    if (IS_SEQUENCE(_65block_stack_25113)){
            _14217 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _14217 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    _14218 = (object)*(((s1_ptr)_2)->base + _14217);
    _2 = (object)SEQ_PTR(_14218);
    _14219 = (object)*(((s1_ptr)_2)->base + 6);
    _14218 = NOVALUE;
    if (IS_SEQUENCE(_14219)){
            _14220 = SEQ_PTR(_14219)->length;
    }
    else {
        _14220 = 1;
    }
    _14219 = NOVALUE;
    {
        s1_ptr assign_space = SEQ_PTR(_14216);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_14220)) ? _14220 : (object)(DBL_PTR(_14220)->dbl);
        int stop = (IS_ATOM_INT(_14220)) ? _14220 : (object)(DBL_PTR(_14220)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
            RefDS(_14216);
            DeRef(_14221);
            _14221 = _14216;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_14216), start, &_14221 );
            }
            else Tail(SEQ_PTR(_14216), stop+1, &_14221);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_14216), start, &_14221);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_14221);
            _14221 = _1;
        }
    }
    _14216 = NOVALUE;
    _14220 = NOVALUE;
    _14220 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14221;
    if( _1 != _14221 ){
        DeRef(_1);
    }
    _14221 = NOVALUE;
    _14212 = NOVALUE;

    /** block.e:327	end procedure*/
    _14219 = NOVALUE;
    return;
    ;
}


void _65Goto_block(object _from_block_25491, object _to_block_25493, object _pc_25494)
{
    object _code_25495 = NOVALUE;
    object _next_block_25497 = NOVALUE;
    object _14232 = NOVALUE;
    object _14229 = NOVALUE;
    object _14228 = NOVALUE;
    object _14227 = NOVALUE;
    object _14226 = NOVALUE;
    object _14225 = NOVALUE;
    object _14224 = NOVALUE;
    object _14223 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_block_25491)) {
        _1 = (object)(DBL_PTR(_from_block_25491)->dbl);
        DeRefDS(_from_block_25491);
        _from_block_25491 = _1;
    }
    if (!IS_ATOM_INT(_to_block_25493)) {
        _1 = (object)(DBL_PTR(_to_block_25493)->dbl);
        DeRefDS(_to_block_25493);
        _to_block_25493 = _1;
    }
    if (!IS_ATOM_INT(_pc_25494)) {
        _1 = (object)(DBL_PTR(_pc_25494)->dbl);
        DeRefDS(_pc_25494);
        _pc_25494 = _1;
    }

    /** block.e:330		sequence code = {}*/
    RefDS(_5);
    DeRefi(_code_25495);
    _code_25495 = _5;

    /** block.e:331		symtab_index next_block = sym_block( from_block )*/
    _next_block_25497 = _54sym_block(_from_block_25491);
    if (!IS_ATOM_INT(_next_block_25497)) {
        _1 = (object)(DBL_PTR(_next_block_25497)->dbl);
        DeRefDS(_next_block_25497);
        _next_block_25497 = _1;
    }

    /** block.e:332		while next_block */
L1: 
    if (_next_block_25497 == 0) {
        _14223 = 0;
        goto L2; // [27] 39
    }
    _14224 = (_from_block_25491 != _to_block_25493);
    _14223 = (_14224 != 0);
L2: 
    if (_14223 == 0) {
        goto L3; // [39] 93
    }
    _14226 = _54sym_token(_next_block_25497);
    _14227 = find_from(_14226, _38RTN_TOKS_16045, 1);
    DeRef(_14226);
    _14226 = NOVALUE;
    _14228 = (_14227 == 0);
    _14227 = NOVALUE;
    if (_14228 == 0)
    {
        DeRef(_14228);
        _14228 = NOVALUE;
        goto L3; // [58] 93
    }
    else{
        DeRef(_14228);
        _14228 = NOVALUE;
    }

    /** block.e:335			code &= { EXIT_BLOCK, from_block }*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 206;
    ((intptr_t *)_2)[2] = _from_block_25491;
    _14229 = MAKE_SEQ(_1);
    Concat((object_ptr)&_code_25495, _code_25495, _14229);
    DeRefDS(_14229);
    _14229 = NOVALUE;

    /** block.e:336			from_block = next_block*/
    _from_block_25491 = _next_block_25497;

    /** block.e:337			next_block = sym_block( next_block )*/
    _next_block_25497 = _54sym_block(_next_block_25497);
    if (!IS_ATOM_INT(_next_block_25497)) {
        _1 = (object)(DBL_PTR(_next_block_25497)->dbl);
        DeRefDS(_next_block_25497);
        _next_block_25497 = _1;
    }

    /** block.e:338		end while*/
    goto L1; // [90] 27
L3: 

    /** block.e:340		if length(code) then*/
    if (IS_SEQUENCE(_code_25495)){
            _14232 = SEQ_PTR(_code_25495)->length;
    }
    else {
        _14232 = 1;
    }
    if (_14232 == 0)
    {
        _14232 = NOVALUE;
        goto L4; // [98] 127
    }
    else{
        _14232 = NOVALUE;
    }

    /** block.e:341			if pc then*/
    if (_pc_25494 == 0)
    {
        goto L5; // [103] 115
    }
    else{
    }

    /** block.e:342				insert_code( code, pc )*/
    RefDS(_code_25495);
    _66insert_code(_code_25495, _pc_25494);
    goto L6; // [112] 126
L5: 

    /** block.e:344				Code &= code*/
    Concat((object_ptr)&_36Code_21539, _36Code_21539, _code_25495);
L6: 
L4: 

    /** block.e:348	end procedure*/
    DeRefi(_code_25495);
    DeRef(_14224);
    _14224 = NOVALUE;
    return;
    ;
}


object _65Least_block()
{
    object _ix_25525 = NOVALUE;
    object _sub_block_25528 = NOVALUE;
    object _14246 = NOVALUE;
    object _14245 = NOVALUE;
    object _14243 = NOVALUE;
    object _14242 = NOVALUE;
    object _14241 = NOVALUE;
    object _14240 = NOVALUE;
    object _14239 = NOVALUE;
    object _14238 = NOVALUE;
    object _14237 = NOVALUE;
    object _14236 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:358		integer ix = length( block_stack )*/
    if (IS_SEQUENCE(_65block_stack_25113)){
            _ix_25525 = SEQ_PTR(_65block_stack_25113)->length;
    }
    else {
        _ix_25525 = 1;
    }

    /** block.e:359		symtab_index sub_block = sym_block( CurrentSub )*/
    _sub_block_25528 = _54sym_block(_36CurrentSub_21455);
    if (!IS_ATOM_INT(_sub_block_25528)) {
        _1 = (object)(DBL_PTR(_sub_block_25528)->dbl);
        DeRefDS(_sub_block_25528);
        _sub_block_25528 = _1;
    }

    /** block.e:360		while not length( block_stack[ix][BLOCK_VARS] ) */
L1: 
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    _14236 = (object)*(((s1_ptr)_2)->base + _ix_25525);
    _2 = (object)SEQ_PTR(_14236);
    _14237 = (object)*(((s1_ptr)_2)->base + 6);
    _14236 = NOVALUE;
    if (IS_SEQUENCE(_14237)){
            _14238 = SEQ_PTR(_14237)->length;
    }
    else {
        _14238 = 1;
    }
    _14237 = NOVALUE;
    _14239 = (_14238 == 0);
    _14238 = NOVALUE;
    if (_14239 == 0) {
        goto L2; // [39] 72
    }
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    _14241 = (object)*(((s1_ptr)_2)->base + _ix_25525);
    _2 = (object)SEQ_PTR(_14241);
    _14242 = (object)*(((s1_ptr)_2)->base + 1);
    _14241 = NOVALUE;
    if (IS_ATOM_INT(_14242)) {
        _14243 = (_14242 != _sub_block_25528);
    }
    else {
        _14243 = binary_op(NOTEQ, _14242, _sub_block_25528);
    }
    _14242 = NOVALUE;
    if (_14243 <= 0) {
        if (_14243 == 0) {
            DeRef(_14243);
            _14243 = NOVALUE;
            goto L2; // [58] 72
        }
        else {
            if (!IS_ATOM_INT(_14243) && DBL_PTR(_14243)->dbl == 0.0){
                DeRef(_14243);
                _14243 = NOVALUE;
                goto L2; // [58] 72
            }
            DeRef(_14243);
            _14243 = NOVALUE;
        }
    }
    DeRef(_14243);
    _14243 = NOVALUE;

    /** block.e:362			ix -= 1	*/
    _ix_25525 = _ix_25525 - 1;

    /** block.e:363		end while*/
    goto L1; // [69] 23
L2: 

    /** block.e:364		return block_stack[ix][BLOCK_SYM]*/
    _2 = (object)SEQ_PTR(_65block_stack_25113);
    _14245 = (object)*(((s1_ptr)_2)->base + _ix_25525);
    _2 = (object)SEQ_PTR(_14245);
    _14246 = (object)*(((s1_ptr)_2)->base + 1);
    _14245 = NOVALUE;
    Ref(_14246);
    _14237 = NOVALUE;
    DeRef(_14239);
    _14239 = NOVALUE;
    return _14246;
    ;
}



// 0xAB0D2C15
