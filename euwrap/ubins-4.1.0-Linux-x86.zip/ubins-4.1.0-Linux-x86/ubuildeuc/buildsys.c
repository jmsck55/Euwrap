// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _56find_file(object _fname_45315)
{
    object _23582 = NOVALUE;
    object _23581 = NOVALUE;
    object _23580 = NOVALUE;
    object _23579 = NOVALUE;
    object _23577 = NOVALUE;
    object _23576 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:30		for i = 1 to length(inc_dirs) do*/
    _23576 = 3;
    {
        object _i_45317;
        _i_45317 = 1;
L1: 
        if (_i_45317 > 3){
            goto L2; // [10] 64
        }

        /** buildsys.e:31			if file_exists(inc_dirs[i] & "/" & fname) then*/
        _2 = (object)SEQ_PTR(_56inc_dirs_45307);
        _23577 = (object)*(((s1_ptr)_2)->base + _i_45317);
        {
            object concat_list[3];

            concat_list[0] = _fname_45315;
            concat_list[1] = _23578;
            concat_list[2] = _23577;
            Concat_N((object_ptr)&_23579, concat_list, 3);
        }
        _23577 = NOVALUE;
        _23580 = _17file_exists(_23579);
        _23579 = NOVALUE;
        if (_23580 == 0) {
            DeRef(_23580);
            _23580 = NOVALUE;
            goto L3; // [35] 57
        }
        else {
            if (!IS_ATOM_INT(_23580) && DBL_PTR(_23580)->dbl == 0.0){
                DeRef(_23580);
                _23580 = NOVALUE;
                goto L3; // [35] 57
            }
            DeRef(_23580);
            _23580 = NOVALUE;
        }
        DeRef(_23580);
        _23580 = NOVALUE;

        /** buildsys.e:32				return inc_dirs[i] & "/" & fname*/
        _2 = (object)SEQ_PTR(_56inc_dirs_45307);
        _23581 = (object)*(((s1_ptr)_2)->base + _i_45317);
        {
            object concat_list[3];

            concat_list[0] = _fname_45315;
            concat_list[1] = _23578;
            concat_list[2] = _23581;
            Concat_N((object_ptr)&_23582, concat_list, 3);
        }
        _23581 = NOVALUE;
        DeRefDS(_fname_45315);
        return _23582;
L3: 

        /** buildsys.e:34		end for*/
        _i_45317 = _i_45317 + 1;
        goto L1; // [59] 17
L2: 
        ;
    }

    /** buildsys.e:36		return 0*/
    DeRefDS(_fname_45315);
    DeRef(_23582);
    _23582 = NOVALUE;
    return 0;
    ;
}


object _56find_all_includes(object _fname_45329, object _includes_45330)
{
    object _lines_45331 = NOVALUE;
    object _m_45337 = NOVALUE;
    object _full_fname_45342 = NOVALUE;
    object _23595 = NOVALUE;
    object _23593 = NOVALUE;
    object _23591 = NOVALUE;
    object _23590 = NOVALUE;
    object _23588 = NOVALUE;
    object _23587 = NOVALUE;
    object _23585 = NOVALUE;
    object _23584 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:40		sequence lines = read_lines(fname)*/
    RefDS(_fname_45329);
    _0 = _lines_45331;
    _lines_45331 = _8read_lines(_fname_45329);
    DeRef(_0);

    /** buildsys.e:42		for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_45331)){
            _23584 = SEQ_PTR(_lines_45331)->length;
    }
    else {
        _23584 = 1;
    }
    {
        object _i_45335;
        _i_45335 = 1;
L1: 
        if (_i_45335 > _23584){
            goto L2; // [18] 113
        }

        /** buildsys.e:43			object m = regex:matches(re_include, lines[i])*/
        _2 = (object)SEQ_PTR(_lines_45331);
        _23585 = (object)*(((s1_ptr)_2)->base + _i_45335);
        Ref(_56re_include_45304);
        Ref(_23585);
        _0 = _m_45337;
        _m_45337 = _52matches(_56re_include_45304, _23585, 1, 0);
        DeRef(_0);
        _23585 = NOVALUE;

        /** buildsys.e:44			if sequence(m) then*/
        _23587 = IS_SEQUENCE(_m_45337);
        if (_23587 == 0)
        {
            _23587 = NOVALUE;
            goto L3; // [45] 102
        }
        else{
            _23587 = NOVALUE;
        }

        /** buildsys.e:45				object full_fname = find_file(m[3])*/
        _2 = (object)SEQ_PTR(_m_45337);
        _23588 = (object)*(((s1_ptr)_2)->base + 3);
        Ref(_23588);
        _0 = _full_fname_45342;
        _full_fname_45342 = _56find_file(_23588);
        DeRef(_0);
        _23588 = NOVALUE;

        /** buildsys.e:46				if sequence(full_fname) then*/
        _23590 = IS_SEQUENCE(_full_fname_45342);
        if (_23590 == 0)
        {
            _23590 = NOVALUE;
            goto L4; // [63] 101
        }
        else{
            _23590 = NOVALUE;
        }

        /** buildsys.e:47					if eu:find(full_fname, includes) = 0 then*/
        _23591 = find_from(_full_fname_45342, _includes_45330, 1);
        if (_23591 != 0)
        goto L5; // [73] 100

        /** buildsys.e:48						includes &= { full_fname }*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_full_fname_45342);
        ((intptr_t*)_2)[1] = _full_fname_45342;
        _23593 = MAKE_SEQ(_1);
        Concat((object_ptr)&_includes_45330, _includes_45330, _23593);
        DeRefDS(_23593);
        _23593 = NOVALUE;

        /** buildsys.e:49						includes = find_all_includes(full_fname, includes)*/
        RefDS(_includes_45330);
        DeRef(_23595);
        _23595 = _includes_45330;
        Ref(_full_fname_45342);
        _0 = _includes_45330;
        _includes_45330 = _56find_all_includes(_full_fname_45342, _23595);
        DeRefDS(_0);
        _23595 = NOVALUE;
L5: 
L4: 
L3: 
        DeRef(_full_fname_45342);
        _full_fname_45342 = NOVALUE;
        DeRef(_m_45337);
        _m_45337 = NOVALUE;

        /** buildsys.e:53		end for*/
        _i_45335 = _i_45335 + 1;
        goto L1; // [108] 25
L2: 
        ;
    }

    /** buildsys.e:55		return includes*/
    DeRefDS(_fname_45329);
    DeRef(_lines_45331);
    return _includes_45330;
    ;
}


object _56quick_has_changed(object _fname_45356)
{
    object _d1_45357 = NOVALUE;
    object _all_files_45367 = NOVALUE;
    object _d2_45373 = NOVALUE;
    object _diff_2__tmp_at88_45383 = NOVALUE;
    object _diff_1__tmp_at88_45382 = NOVALUE;
    object _diff_inlined_diff_at_88_45381 = NOVALUE;
    object _23607 = NOVALUE;
    object _23605 = NOVALUE;
    object _23604 = NOVALUE;
    object _23602 = NOVALUE;
    object _23601 = NOVALUE;
    object _23599 = NOVALUE;
    object _23597 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:59		object d1 = file_timestamp(output_dir & filebase(fname) & ".bld")*/
    RefDS(_fname_45356);
    _23597 = _17filebase(_fname_45356);
    {
        object concat_list[3];

        concat_list[0] = _23598;
        concat_list[1] = _23597;
        concat_list[2] = _58output_dir_42581;
        Concat_N((object_ptr)&_23599, concat_list, 3);
    }
    DeRef(_23597);
    _23597 = NOVALUE;
    _0 = _d1_45357;
    _d1_45357 = _17file_timestamp(_23599);
    DeRef(_0);
    _23599 = NOVALUE;

    /** buildsys.e:61		if atom(d1) then*/
    _23601 = IS_ATOM(_d1_45357);
    if (_23601 == 0)
    {
        _23601 = NOVALUE;
        goto L1; // [26] 36
    }
    else{
        _23601 = NOVALUE;
    }

    /** buildsys.e:62			return 1*/
    DeRefDS(_fname_45356);
    DeRef(_d1_45357);
    DeRef(_all_files_45367);
    return 1;
L1: 

    /** buildsys.e:65		sequence all_files = append(find_all_includes(fname), fname)*/
    RefDS(_fname_45356);
    RefDS(_21997);
    _23602 = _56find_all_includes(_fname_45356, _21997);
    RefDS(_fname_45356);
    Append(&_all_files_45367, _23602, _fname_45356);
    DeRef(_23602);
    _23602 = NOVALUE;

    /** buildsys.e:66		for i = 1 to length(all_files) do*/
    if (IS_SEQUENCE(_all_files_45367)){
            _23604 = SEQ_PTR(_all_files_45367)->length;
    }
    else {
        _23604 = 1;
    }
    {
        object _i_45371;
        _i_45371 = 1;
L2: 
        if (_i_45371 > _23604){
            goto L3; // [52] 123
        }

        /** buildsys.e:67			object d2 = file_timestamp(all_files[i])*/
        _2 = (object)SEQ_PTR(_all_files_45367);
        _23605 = (object)*(((s1_ptr)_2)->base + _i_45371);
        Ref(_23605);
        _0 = _d2_45373;
        _d2_45373 = _17file_timestamp(_23605);
        DeRef(_0);
        _23605 = NOVALUE;

        /** buildsys.e:68			if atom(d2) then*/
        _23607 = IS_ATOM(_d2_45373);
        if (_23607 == 0)
        {
            _23607 = NOVALUE;
            goto L4; // [74] 84
        }
        else{
            _23607 = NOVALUE;
        }

        /** buildsys.e:69				return 1*/
        DeRef(_d2_45373);
        DeRefDS(_fname_45356);
        DeRef(_d1_45357);
        DeRefDS(_all_files_45367);
        return 1;
L4: 

        /** buildsys.e:71			if datetime:diff(d1, d2) > 0 then*/

        /** datetime.e:1253		return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
        Ref(_d2_45373);
        _0 = _diff_1__tmp_at88_45382;
        _diff_1__tmp_at88_45382 = _18datetimeToSeconds(_d2_45373);
        DeRef(_0);
        Ref(_d1_45357);
        _0 = _diff_2__tmp_at88_45383;
        _diff_2__tmp_at88_45383 = _18datetimeToSeconds(_d1_45357);
        DeRef(_0);
        DeRef(_diff_inlined_diff_at_88_45381);
        if (IS_ATOM_INT(_diff_1__tmp_at88_45382) && IS_ATOM_INT(_diff_2__tmp_at88_45383)) {
            _diff_inlined_diff_at_88_45381 = _diff_1__tmp_at88_45382 - _diff_2__tmp_at88_45383;
            if ((object)((uintptr_t)_diff_inlined_diff_at_88_45381 +(uintptr_t) HIGH_BITS) >= 0){
                _diff_inlined_diff_at_88_45381 = NewDouble((eudouble)_diff_inlined_diff_at_88_45381);
            }
        }
        else {
            _diff_inlined_diff_at_88_45381 = binary_op(MINUS, _diff_1__tmp_at88_45382, _diff_2__tmp_at88_45383);
        }
        DeRef(_diff_1__tmp_at88_45382);
        _diff_1__tmp_at88_45382 = NOVALUE;
        DeRef(_diff_2__tmp_at88_45383);
        _diff_2__tmp_at88_45383 = NOVALUE;
        if (binary_op_a(LESSEQ, _diff_inlined_diff_at_88_45381, 0)){
            goto L5; // [103] 114
        }

        /** buildsys.e:72				return 1*/
        DeRef(_d2_45373);
        DeRefDS(_fname_45356);
        DeRef(_d1_45357);
        DeRef(_all_files_45367);
        return 1;
L5: 
        DeRef(_d2_45373);
        _d2_45373 = NOVALUE;

        /** buildsys.e:74		end for*/
        _i_45371 = _i_45371 + 1;
        goto L2; // [118] 59
L3: 
        ;
    }

    /** buildsys.e:76		return 0*/
    DeRefDS(_fname_45356);
    DeRef(_d1_45357);
    DeRef(_all_files_45367);
    return 0;
    ;
}


void _56update_checksum(object _raw_data_45429)
{
    object _23615 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:213		cfile_check = xor_bits(cfile_check, hash( raw_data, stdhash:HSIEH32))*/
    _23615 = calc_hash(_raw_data_45429, -5);
    _0 = _56cfile_check_45410;
    if (IS_ATOM_INT(_56cfile_check_45410) && IS_ATOM_INT(_23615)) {
        {uintptr_t tu;
             tu = (uintptr_t)_56cfile_check_45410 ^ (uintptr_t)_23615;
             _56cfile_check_45410 = MAKE_UINT(tu);
        }
    }
    else {
        if (IS_ATOM_INT(_56cfile_check_45410)) {
            temp_d.dbl = (eudouble)_56cfile_check_45410;
            _56cfile_check_45410 = Dxor_bits(&temp_d, DBL_PTR(_23615));
        }
        else {
            if (IS_ATOM_INT(_23615)) {
                temp_d.dbl = (eudouble)_23615;
                _56cfile_check_45410 = Dxor_bits(DBL_PTR(_56cfile_check_45410), &temp_d);
            }
            else
            _56cfile_check_45410 = Dxor_bits(DBL_PTR(_56cfile_check_45410), DBL_PTR(_23615));
        }
    }
    DeRef(_0);
    DeRef(_23615);
    _23615 = NOVALUE;

    /** buildsys.e:214	end procedure*/
    DeRef(_raw_data_45429);
    return;
    ;
}


void _56write_checksum(object _file_45434)
{
    object _0, _1, _2;
    

    /** buildsys.e:219		printf( file, "\n// 0x%08x\n", cfile_check )*/
    EPrintf(_file_45434, _23617, _56cfile_check_45410);

    /** buildsys.e:220		cfile_check = 0*/
    DeRef(_56cfile_check_45410);
    _56cfile_check_45410 = 0;

    /** buildsys.e:221	end procedure*/
    return;
    ;
}


object _56adjust_for_command_line_passing(object _long_path_45482)
{
    object _slash_45483 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:310		if compiler_type = COMPILER_GCC then*/
    if (_56compiler_type_45393 != 1)
    goto L1; // [7] 19

    /** buildsys.e:311			slash = '/'*/
    _slash_45483 = 47;
    goto L2; // [16] 45
L1: 

    /** buildsys.e:312		elsif compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45393 != 2)
    goto L3; // [23] 35

    /** buildsys.e:313			slash = '\\'*/
    _slash_45483 = 92;
    goto L2; // [32] 45
L3: 

    /** buildsys.e:315			slash = SLASH*/
    _slash_45483 = 47;
L2: 

    /** buildsys.e:317		ifdef UNIX then*/

    /** buildsys.e:318			return long_path*/
    return _long_path_45482;
    ;
}


object _56adjust_for_build_file(object _long_path_45492)
{
    object _short_path_45493 = NOVALUE;
    object _23647 = NOVALUE;
    object _23646 = NOVALUE;
    object _23645 = NOVALUE;
    object _23644 = NOVALUE;
    object _23643 = NOVALUE;
    object _23642 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:355	    object short_path = adjust_for_command_line_passing(long_path)*/
    RefDS(_long_path_45492);
    _0 = _short_path_45493;
    _short_path_45493 = _56adjust_for_command_line_passing(_long_path_45492);
    DeRef(_0);

    /** buildsys.e:356	    if atom(short_path) then*/
    _23642 = IS_ATOM(_short_path_45493);
    if (_23642 == 0)
    {
        _23642 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _23642 = NOVALUE;
    }

    /** buildsys.e:357	    	return short_path*/
    DeRefDS(_long_path_45492);
    return _short_path_45493;
L1: 

    /** buildsys.e:359		if compiler_type = COMPILER_GCC and build_system_type != BUILD_DIRECT and TWINDOWS then*/
    _23643 = (_56compiler_type_45393 == 1);
    if (_23643 == 0) {
        _23644 = 0;
        goto L2; // [32] 46
    }
    _23645 = (_56build_system_type_45389 != 3);
    _23644 = (_23645 != 0);
L2: 
    if (_23644 == 0) {
        goto L3; // [46] 69
    }
    if (_46TWINDOWS_21594 == 0)
    {
        goto L3; // [53] 69
    }
    else{
    }

    /** buildsys.e:360			return windows_to_mingw_path(short_path)*/
    Ref(_short_path_45493);
    _23647 = _56windows_to_mingw_path(_short_path_45493);
    DeRefDS(_long_path_45492);
    DeRef(_short_path_45493);
    DeRef(_23643);
    _23643 = NOVALUE;
    DeRef(_23645);
    _23645 = NOVALUE;
    return _23647;
    goto L4; // [66] 76
L3: 

    /** buildsys.e:362			return short_path*/
    DeRefDS(_long_path_45492);
    DeRef(_23647);
    _23647 = NOVALUE;
    DeRef(_23643);
    _23643 = NOVALUE;
    DeRef(_23645);
    _23645 = NOVALUE;
    return _short_path_45493;
L4: 
    ;
}


object _56setup_build()
{
    object _c_exe_45508 = NOVALUE;
    object _c_flags_45509 = NOVALUE;
    object _l_exe_45510 = NOVALUE;
    object _l_flags_45511 = NOVALUE;
    object _obj_ext_45512 = NOVALUE;
    object _exe_ext_45513 = NOVALUE;
    object _l_flags_begin_45514 = NOVALUE;
    object _rc_comp_45515 = NOVALUE;
    object _l_names_45516 = NOVALUE;
    object _l_ext_45517 = NOVALUE;
    object _t_slash_45518 = NOVALUE;
    object _eudir_45560 = NOVALUE;
    object _locations_45585 = NOVALUE;
    object _compile_dir_45637 = NOVALUE;
    object _bits_45648 = NOVALUE;
    object _m_flag_45658 = NOVALUE;
    object _23816 = NOVALUE;
    object _23814 = NOVALUE;
    object _23813 = NOVALUE;
    object _23812 = NOVALUE;
    object _23810 = NOVALUE;
    object _23809 = NOVALUE;
    object _23808 = NOVALUE;
    object _23805 = NOVALUE;
    object _23804 = NOVALUE;
    object _23801 = NOVALUE;
    object _23800 = NOVALUE;
    object _23793 = NOVALUE;
    object _23792 = NOVALUE;
    object _23787 = NOVALUE;
    object _23786 = NOVALUE;
    object _23781 = NOVALUE;
    object _23780 = NOVALUE;
    object _23777 = NOVALUE;
    object _23776 = NOVALUE;
    object _23764 = NOVALUE;
    object _23763 = NOVALUE;
    object _23748 = NOVALUE;
    object _23747 = NOVALUE;
    object _23744 = NOVALUE;
    object _23739 = NOVALUE;
    object _23737 = NOVALUE;
    object _23736 = NOVALUE;
    object _23735 = NOVALUE;
    object _23734 = NOVALUE;
    object _23730 = NOVALUE;
    object _23729 = NOVALUE;
    object _23715 = NOVALUE;
    object _23714 = NOVALUE;
    object _23711 = NOVALUE;
    object _23699 = NOVALUE;
    object _23697 = NOVALUE;
    object _23696 = NOVALUE;
    object _23695 = NOVALUE;
    object _23694 = NOVALUE;
    object _23693 = NOVALUE;
    object _23692 = NOVALUE;
    object _23691 = NOVALUE;
    object _23690 = NOVALUE;
    object _23689 = NOVALUE;
    object _23688 = NOVALUE;
    object _23683 = NOVALUE;
    object _23680 = NOVALUE;
    object _23679 = NOVALUE;
    object _23678 = NOVALUE;
    object _23675 = NOVALUE;
    object _23674 = NOVALUE;
    object _23673 = NOVALUE;
    object _23670 = NOVALUE;
    object _23666 = NOVALUE;
    object _23665 = NOVALUE;
    object _23663 = NOVALUE;
    object _23662 = NOVALUE;
    object _23661 = NOVALUE;
    object _23660 = NOVALUE;
    object _23653 = NOVALUE;
    object _23652 = NOVALUE;
    object _23651 = NOVALUE;
    object _23650 = NOVALUE;
    object _23649 = NOVALUE;
    object _23648 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:373			c_exe   = "",*/
    RefDS(_21997);
    DeRef(_c_exe_45508);
    _c_exe_45508 = _21997;

    /** buildsys.e:374			c_flags = "",*/
    RefDS(_21997);
    DeRef(_c_flags_45509);
    _c_flags_45509 = _21997;

    /** buildsys.e:375			l_exe   = "",*/
    RefDS(_21997);
    DeRef(_l_exe_45510);
    _l_exe_45510 = _21997;

    /** buildsys.e:376			l_flags = "",*/
    RefDS(_21997);
    DeRef(_l_flags_45511);
    _l_flags_45511 = _21997;

    /** buildsys.e:377			obj_ext = "",*/
    RefDS(_21997);
    DeRefi(_obj_ext_45512);
    _obj_ext_45512 = _21997;

    /** buildsys.e:378			exe_ext = "",*/
    RefDS(_21997);
    DeRefi(_exe_ext_45513);
    _exe_ext_45513 = _21997;

    /** buildsys.e:379			l_flags_begin = "",*/
    RefDS(_21997);
    DeRefi(_l_flags_begin_45514);
    _l_flags_begin_45514 = _21997;

    /** buildsys.e:380			rc_comp = "",*/
    RefDS(_21997);
    DeRef(_rc_comp_45515);
    _rc_comp_45515 = _21997;

    /** buildsys.e:385		if dll_option*/
    if (_58dll_option_42567 == 0) {
        _23648 = 0;
        goto L1; // [61] 78
    }
    if (IS_SEQUENCE(_58user_pic_library_42580)){
            _23649 = SEQ_PTR(_58user_pic_library_42580)->length;
    }
    else {
        _23649 = 1;
    }
    _23650 = (_23649 > 0);
    _23649 = NOVALUE;
    _23648 = (_23650 != 0);
L1: 
    if (_23648 == 0) {
        goto L2; // [78] 101
    }
    _23652 = (_46TWINDOWS_21594 == 0);
    if (_23652 == 0)
    {
        DeRef(_23652);
        _23652 = NOVALUE;
        goto L2; // [88] 101
    }
    else{
        DeRef(_23652);
        _23652 = NOVALUE;
    }

    /** buildsys.e:388			user_library = user_pic_library*/
    RefDS(_58user_pic_library_42580);
    DeRef(_58user_library_42579);
    _58user_library_42579 = _58user_pic_library_42580;
L2: 

    /** buildsys.e:391		if length(user_library) = 0 then*/
    if (IS_SEQUENCE(_58user_library_42579)){
            _23653 = SEQ_PTR(_58user_library_42579)->length;
    }
    else {
        _23653 = 1;
    }
    if (_23653 != 0)
    goto L3; // [108] 456

    /** buildsys.e:392			if debug_option then*/
    if (_58debug_option_42577 == 0)
    {
        goto L4; // [116] 128
    }
    else{
    }

    /** buildsys.e:393				l_names = { "eudbg", "eu" }*/
    RefDS(_23656);
    RefDS(_23655);
    DeRef(_l_names_45516);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _23655;
    ((intptr_t *)_2)[2] = _23656;
    _l_names_45516 = MAKE_SEQ(_1);
    goto L5; // [125] 135
L4: 

    /** buildsys.e:395				l_names = { "eu", "eudbg" }*/
    RefDS(_23655);
    RefDS(_23656);
    DeRef(_l_names_45516);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _23656;
    ((intptr_t *)_2)[2] = _23655;
    _l_names_45516 = MAKE_SEQ(_1);
L5: 

    /** buildsys.e:400			if TUNIX or compiler_type = COMPILER_GCC then*/
    if (_46TUNIX_21598 != 0) {
        goto L6; // [139] 154
    }
    _23660 = (_56compiler_type_45393 == 1);
    if (_23660 == 0)
    {
        DeRef(_23660);
        _23660 = NOVALUE;
        goto L7; // [150] 224
    }
    else{
        DeRef(_23660);
        _23660 = NOVALUE;
    }
L6: 

    /** buildsys.e:401				l_ext = "a"*/
    RefDS(_22278);
    DeRefi(_l_ext_45517);
    _l_ext_45517 = _22278;

    /** buildsys.e:402				t_slash = "/"*/
    RefDS(_23578);
    DeRefi(_t_slash_45518);
    _t_slash_45518 = _23578;

    /** buildsys.e:403				if dll_option and not TWINDOWS then*/
    if (_58dll_option_42567 == 0) {
        goto L8; // [172] 247
    }
    _23662 = (_46TWINDOWS_21594 == 0);
    if (_23662 == 0)
    {
        DeRef(_23662);
        _23662 = NOVALUE;
        goto L8; // [182] 247
    }
    else{
        DeRef(_23662);
        _23662 = NOVALUE;
    }

    /** buildsys.e:404					for i = 1 to length( l_names ) do*/
    if (IS_SEQUENCE(_l_names_45516)){
            _23663 = SEQ_PTR(_l_names_45516)->length;
    }
    else {
        _23663 = 1;
    }
    {
        object _i_45551;
        _i_45551 = 1;
L9: 
        if (_i_45551 > _23663){
            goto LA; // [192] 220
        }

        /** buildsys.e:406						l_names[i] &= "so"*/
        _2 = (object)SEQ_PTR(_l_names_45516);
        _23665 = (object)*(((s1_ptr)_2)->base + _i_45551);
        if (IS_SEQUENCE(_23665) && IS_ATOM(_23664)) {
        }
        else if (IS_ATOM(_23665) && IS_SEQUENCE(_23664)) {
            Ref(_23665);
            Prepend(&_23666, _23664, _23665);
        }
        else {
            Concat((object_ptr)&_23666, _23665, _23664);
            _23665 = NOVALUE;
        }
        _23665 = NOVALUE;
        _2 = (object)SEQ_PTR(_l_names_45516);
        _2 = (object)(((s1_ptr)_2)->base + _i_45551);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _23666;
        if( _1 != _23666 ){
            DeRef(_1);
        }
        _23666 = NOVALUE;

        /** buildsys.e:407					end for*/
        _i_45551 = _i_45551 + 1;
        goto L9; // [215] 199
LA: 
        ;
    }
    goto L8; // [221] 247
L7: 

    /** buildsys.e:409			elsif TWINDOWS then*/
    if (_46TWINDOWS_21594 == 0)
    {
        goto LB; // [228] 246
    }
    else{
    }

    /** buildsys.e:410				l_ext = "lib"*/
    RefDS(_23667);
    DeRefi(_l_ext_45517);
    _l_ext_45517 = _23667;

    /** buildsys.e:411				t_slash = "\\"*/
    RefDS(_23668);
    DeRefi(_t_slash_45518);
    _t_slash_45518 = _23668;
LB: 
L8: 

    /** buildsys.e:414			object eudir = get_eucompiledir()*/
    _0 = _eudir_45560;
    _eudir_45560 = _58get_eucompiledir();
    DeRef(_0);

    /** buildsys.e:415			if not file_exists(eudir) then*/
    Ref(_eudir_45560);
    _23670 = _17file_exists(_eudir_45560);
    if (IS_ATOM_INT(_23670)) {
        if (_23670 != 0){
            DeRef(_23670);
            _23670 = NOVALUE;
            goto LC; // [258] 279
        }
    }
    else {
        if (DBL_PTR(_23670)->dbl != 0.0){
            DeRef(_23670);
            _23670 = NOVALUE;
            goto LC; // [258] 279
        }
    }
    DeRef(_23670);
    _23670 = NOVALUE;

    /** buildsys.e:416				printf(2,"Supplied directory \'%s\' is not a valid EUDIR\n",{get_eucompiledir()})*/
    _23673 = _58get_eucompiledir();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23673;
    _23674 = MAKE_SEQ(_1);
    _23673 = NOVALUE;
    EPrintf(2, _23672, _23674);
    DeRefDS(_23674);
    _23674 = NOVALUE;

    /** buildsys.e:417				abort(1)*/
    UserCleanup(1);
LC: 

    /** buildsys.e:419			for tk = 1 to length(l_names) label "translation kind" do*/
    if (IS_SEQUENCE(_l_names_45516)){
            _23675 = SEQ_PTR(_l_names_45516)->length;
    }
    else {
        _23675 = 1;
    }
    {
        object _tk_45572;
        _tk_45572 = 1;
LD: 
        if (_tk_45572 > _23675){
            goto LE; // [286] 455
        }

        /** buildsys.e:420				user_library = eudir & sprintf("%sbin%s%s.%s",{t_slash, t_slash, l_names[tk],l_ext})*/
        _2 = (object)SEQ_PTR(_l_names_45516);
        _23678 = (object)*(((s1_ptr)_2)->base + _tk_45572);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        RefDSn(_t_slash_45518, 2);
        ((intptr_t*)_2)[1] = _t_slash_45518;
        ((intptr_t*)_2)[2] = _t_slash_45518;
        Ref(_23678);
        ((intptr_t*)_2)[3] = _23678;
        RefDS(_l_ext_45517);
        ((intptr_t*)_2)[4] = _l_ext_45517;
        _23679 = MAKE_SEQ(_1);
        _23678 = NOVALUE;
        _23680 = EPrintf(-9999999, _23677, _23679);
        DeRefDS(_23679);
        _23679 = NOVALUE;
        if (IS_SEQUENCE(_eudir_45560) && IS_ATOM(_23680)) {
        }
        else if (IS_ATOM(_eudir_45560) && IS_SEQUENCE(_23680)) {
            Ref(_eudir_45560);
            Prepend(&_58user_library_42579, _23680, _eudir_45560);
        }
        else {
            Concat((object_ptr)&_58user_library_42579, _eudir_45560, _23680);
        }
        DeRefDS(_23680);
        _23680 = NOVALUE;

        /** buildsys.e:421				if TUNIX or compiler_type = COMPILER_GCC then*/
        if (_46TUNIX_21598 != 0) {
            goto LF; // [324] 339
        }
        _23683 = (_56compiler_type_45393 == 1);
        if (_23683 == 0)
        {
            DeRef(_23683);
            _23683 = NOVALUE;
            goto L10; // [335] 430
        }
        else{
            DeRef(_23683);
            _23683 = NOVALUE;
        }
LF: 

        /** buildsys.e:422					ifdef UNIX then*/

        /** buildsys.e:423						sequence locations = { "/usr/local/lib/%s.a", "/usr/lib/%s.a"}*/
        RefDS(_23685);
        RefDS(_23684);
        DeRef(_locations_45585);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23684;
        ((intptr_t *)_2)[2] = _23685;
        _locations_45585 = MAKE_SEQ(_1);

        /** buildsys.e:424						if match( "/share/euphoria", eudir ) then*/
        _23688 = e_match_from(_23687, _eudir_45560, 1);
        if (_23688 == 0)
        {
            _23688 = NOVALUE;
            goto L11; // [354] 429
        }
        else{
            _23688 = NOVALUE;
        }

        /** buildsys.e:426							for i = 1 to length(locations) do*/
        _23689 = 2;
        {
            object _i_45593;
            _i_45593 = 1;
L12: 
            if (_i_45593 > 2){
                goto L13; // [362] 428
            }

            /** buildsys.e:427								if file_exists( sprintf(locations[i],{l_names[tk]}) ) then*/
            _2 = (object)SEQ_PTR(_locations_45585);
            _23690 = (object)*(((s1_ptr)_2)->base + _i_45593);
            _2 = (object)SEQ_PTR(_l_names_45516);
            _23691 = (object)*(((s1_ptr)_2)->base + _tk_45572);
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_23691);
            ((intptr_t*)_2)[1] = _23691;
            _23692 = MAKE_SEQ(_1);
            _23691 = NOVALUE;
            _23693 = EPrintf(-9999999, _23690, _23692);
            _23690 = NOVALUE;
            DeRefDS(_23692);
            _23692 = NOVALUE;
            _23694 = _17file_exists(_23693);
            _23693 = NOVALUE;
            if (_23694 == 0) {
                DeRef(_23694);
                _23694 = NOVALUE;
                goto L14; // [391] 421
            }
            else {
                if (!IS_ATOM_INT(_23694) && DBL_PTR(_23694)->dbl == 0.0){
                    DeRef(_23694);
                    _23694 = NOVALUE;
                    goto L14; // [391] 421
                }
                DeRef(_23694);
                _23694 = NOVALUE;
            }
            DeRef(_23694);
            _23694 = NOVALUE;

            /** buildsys.e:428									user_library = sprintf(locations[i],{l_names[tk]})*/
            _2 = (object)SEQ_PTR(_locations_45585);
            _23695 = (object)*(((s1_ptr)_2)->base + _i_45593);
            _2 = (object)SEQ_PTR(_l_names_45516);
            _23696 = (object)*(((s1_ptr)_2)->base + _tk_45572);
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_23696);
            ((intptr_t*)_2)[1] = _23696;
            _23697 = MAKE_SEQ(_1);
            _23696 = NOVALUE;
            DeRef(_58user_library_42579);
            _58user_library_42579 = EPrintf(-9999999, _23695, _23697);
            _23695 = NOVALUE;
            DeRefDS(_23697);
            _23697 = NOVALUE;

            /** buildsys.e:429									exit "translation kind"*/
            DeRefDS(_locations_45585);
            _locations_45585 = NOVALUE;
            goto LE; // [418] 455
L14: 

            /** buildsys.e:431							end for*/
            _i_45593 = _i_45593 + 1;
            goto L12; // [423] 369
L13: 
            ;
        }
L11: 
L10: 
        DeRef(_locations_45585);
        _locations_45585 = NOVALUE;

        /** buildsys.e:436				if file_exists(user_library) then*/
        RefDS(_58user_library_42579);
        _23699 = _17file_exists(_58user_library_42579);
        if (_23699 == 0) {
            DeRef(_23699);
            _23699 = NOVALUE;
            goto L15; // [440] 448
        }
        else {
            if (!IS_ATOM_INT(_23699) && DBL_PTR(_23699)->dbl == 0.0){
                DeRef(_23699);
                _23699 = NOVALUE;
                goto L15; // [440] 448
            }
            DeRef(_23699);
            _23699 = NOVALUE;
        }
        DeRef(_23699);
        _23699 = NOVALUE;

        /** buildsys.e:437					exit "translation kind"*/
        goto LE; // [445] 455
L15: 

        /** buildsys.e:439			end for -- tk*/
        _tk_45572 = _tk_45572 + 1;
        goto LD; // [450] 293
LE: 
        ;
    }
L3: 
    DeRef(_eudir_45560);
    _eudir_45560 = NOVALUE;

    /** buildsys.e:441		user_library = adjust_for_build_file(user_library)*/
    RefDS(_58user_library_42579);
    _0 = _56adjust_for_build_file(_58user_library_42579);
    DeRefDS(_58user_library_42579);
    _58user_library_42579 = _0;

    /** buildsys.e:443		if TWINDOWS then*/
    if (_46TWINDOWS_21594 == 0)
    {
        goto L16; // [472] 527
    }
    else{
    }

    /** buildsys.e:444			if compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45393 != 2)
    goto L17; // [479] 492

    /** buildsys.e:445				c_flags &= " /dEWINDOWS"*/
    Concat((object_ptr)&_c_flags_45509, _c_flags_45509, _23702);
    goto L18; // [489] 499
L17: 

    /** buildsys.e:447				c_flags &= " -DEWINDOWS"*/
    Concat((object_ptr)&_c_flags_45509, _c_flags_45509, _23704);
L18: 

    /** buildsys.e:450			if dll_option then*/
    if (_58dll_option_42567 == 0)
    {
        goto L19; // [503] 516
    }
    else{
    }

    /** buildsys.e:451				exe_ext = ".dll"*/
    RefDS(_23706);
    DeRefi(_exe_ext_45513);
    _exe_ext_45513 = _23706;
    goto L1A; // [513] 568
L19: 

    /** buildsys.e:453				exe_ext = ".exe"*/
    RefDS(_23707);
    DeRefi(_exe_ext_45513);
    _exe_ext_45513 = _23707;
    goto L1A; // [524] 568
L16: 

    /** buildsys.e:455		elsif TOSX then*/
    if (_46TOSX_21602 == 0)
    {
        goto L1B; // [531] 552
    }
    else{
    }

    /** buildsys.e:456			if dll_option then*/
    if (_58dll_option_42567 == 0)
    {
        goto L1A; // [538] 568
    }
    else{
    }

    /** buildsys.e:457				exe_ext = ".dylib"*/
    RefDS(_23708);
    DeRefi(_exe_ext_45513);
    _exe_ext_45513 = _23708;
    goto L1A; // [549] 568
L1B: 

    /** buildsys.e:460			if dll_option then*/
    if (_58dll_option_42567 == 0)
    {
        goto L1C; // [556] 567
    }
    else{
    }

    /** buildsys.e:461				exe_ext = ".so"*/
    RefDS(_23709);
    DeRefi(_exe_ext_45513);
    _exe_ext_45513 = _23709;
L1C: 
L1A: 

    /** buildsys.e:465		object compile_dir = get_eucompiledir()*/
    _0 = _compile_dir_45637;
    _compile_dir_45637 = _58get_eucompiledir();
    DeRef(_0);

    /** buildsys.e:466		if not file_exists(compile_dir) then*/
    Ref(_compile_dir_45637);
    _23711 = _17file_exists(_compile_dir_45637);
    if (IS_ATOM_INT(_23711)) {
        if (_23711 != 0){
            DeRef(_23711);
            _23711 = NOVALUE;
            goto L1D; // [579] 600
        }
    }
    else {
        if (DBL_PTR(_23711)->dbl != 0.0){
            DeRef(_23711);
            _23711 = NOVALUE;
            goto L1D; // [579] 600
        }
    }
    DeRef(_23711);
    _23711 = NOVALUE;

    /** buildsys.e:467			printf(2,"Couldn't get include directory '%s'",{get_eucompiledir()})*/
    _23714 = _58get_eucompiledir();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23714;
    _23715 = MAKE_SEQ(_1);
    _23714 = NOVALUE;
    EPrintf(2, _23713, _23715);
    DeRefDS(_23715);
    _23715 = NOVALUE;

    /** buildsys.e:468			abort(1)*/
    UserCleanup(1);
L1D: 

    /** buildsys.e:471		integer bits = 32*/
    _bits_45648 = 32;

    /** buildsys.e:472		if TX86_64 then*/
    if (_46TX86_64_21610 == 0)
    {
        goto L1E; // [609] 618
    }
    else{
    }

    /** buildsys.e:473			bits = 64*/
    _bits_45648 = 64;
L1E: 

    /** buildsys.e:476		switch compiler_type do*/
    _0 = _56compiler_type_45393;
    switch ( _0 ){ 

        /** buildsys.e:477			case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:478				c_exe = compiler_prefix & "gcc"*/
        Concat((object_ptr)&_c_exe_45508, _56compiler_prefix_45394, _23718);

        /** buildsys.e:479				l_exe = compiler_prefix & "gcc"*/
        Concat((object_ptr)&_l_exe_45510, _56compiler_prefix_45394, _23718);

        /** buildsys.e:480				obj_ext = "o"*/
        RefDS(_23721);
        DeRefi(_obj_ext_45512);
        _obj_ext_45512 = _23721;

        /** buildsys.e:482				sequence m_flag = ""*/
        RefDS(_21997);
        DeRefi(_m_flag_45658);
        _m_flag_45658 = _21997;

        /** buildsys.e:483				if not TARM then*/
        if (_46TARM_21612 != 0)
        goto L1F; // [665] 675

        /** buildsys.e:485					m_flag = sprintf( "-m%d", bits )*/
        DeRefDSi(_m_flag_45658);
        _m_flag_45658 = EPrintf(-9999999, _23723, _bits_45648);
L1F: 

        /** buildsys.e:488				if debug_option then*/
        if (_58debug_option_42577 == 0)
        {
            goto L20; // [679] 691
        }
        else{
        }

        /** buildsys.e:489					c_flags &= " -g3"*/
        Concat((object_ptr)&_c_flags_45509, _c_flags_45509, _23725);
        goto L21; // [688] 698
L20: 

        /** buildsys.e:491					c_flags &= " -fomit-frame-pointer"*/
        Concat((object_ptr)&_c_flags_45509, _c_flags_45509, _23727);
L21: 

        /** buildsys.e:494				if dll_option and not TWINDOWS then*/
        if (_58dll_option_42567 == 0) {
            goto L22; // [702] 722
        }
        _23730 = (_46TWINDOWS_21594 == 0);
        if (_23730 == 0)
        {
            DeRef(_23730);
            _23730 = NOVALUE;
            goto L22; // [712] 722
        }
        else{
            DeRef(_23730);
            _23730 = NOVALUE;
        }

        /** buildsys.e:495					c_flags &= " -fPIC"*/
        Concat((object_ptr)&_c_flags_45509, _c_flags_45509, _23731);
L22: 

        /** buildsys.e:498				c_flags &= sprintf(" -c -w -fsigned-char -O2 %s -I%s -ffast-math",*/
        _23734 = _58get_eucompiledir();
        _23735 = _56adjust_for_build_file(_23734);
        _23734 = NOVALUE;
        RefDS(_m_flag_45658);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _m_flag_45658;
        ((intptr_t *)_2)[2] = _23735;
        _23736 = MAKE_SEQ(_1);
        _23735 = NOVALUE;
        _23737 = EPrintf(-9999999, _23733, _23736);
        DeRefDS(_23736);
        _23736 = NOVALUE;
        Concat((object_ptr)&_c_flags_45509, _c_flags_45509, _23737);
        DeRefDS(_23737);
        _23737 = NOVALUE;

        /** buildsys.e:501				if TWINDOWS and mno_cygwin then*/
        if (_46TWINDOWS_21594 == 0) {
            goto L23; // [747] 764
        }
        if (_56mno_cygwin_45417 == 0)
        {
            goto L23; // [754] 764
        }
        else{
        }

        /** buildsys.e:504					c_flags &= " -mno-cygwin"*/
        Concat((object_ptr)&_c_flags_45509, _c_flags_45509, _23740);
L23: 

        /** buildsys.e:507				if build_system_type != BUILD_DIRECT then*/
        if (_56build_system_type_45389 == 3)
        goto L24; // [768] 785

        /** buildsys.e:508					l_flags = sprintf( " $(RUNTIME_LIBRARY) %s", { m_flag })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_m_flag_45658);
        ((intptr_t*)_2)[1] = _m_flag_45658;
        _23744 = MAKE_SEQ(_1);
        DeRef(_l_flags_45511);
        _l_flags_45511 = EPrintf(-9999999, _23743, _23744);
        DeRefDS(_23744);
        _23744 = NOVALUE;
        goto L25; // [782] 802
L24: 

        /** buildsys.e:510					l_flags = sprintf( " %s %s",*/
        RefDS(_58user_library_42579);
        _23747 = _56adjust_for_command_line_passing(_58user_library_42579);
        RefDS(_m_flag_45658);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23747;
        ((intptr_t *)_2)[2] = _m_flag_45658;
        _23748 = MAKE_SEQ(_1);
        _23747 = NOVALUE;
        DeRef(_l_flags_45511);
        _l_flags_45511 = EPrintf(-9999999, _23746, _23748);
        DeRefDS(_23748);
        _23748 = NOVALUE;
L25: 

        /** buildsys.e:514				if dll_option then*/
        if (_58dll_option_42567 == 0)
        {
            goto L26; // [806] 816
        }
        else{
        }

        /** buildsys.e:515					l_flags &= " -shared "*/
        Concat((object_ptr)&_l_flags_45511, _l_flags_45511, _23750);
L26: 

        /** buildsys.e:518				if TLINUX then*/
        if (_46TLINUX_21596 == 0)
        {
            goto L27; // [820] 832
        }
        else{
        }

        /** buildsys.e:519					l_flags &= " -ldl -lm -lpthread"*/
        Concat((object_ptr)&_l_flags_45511, _l_flags_45511, _23752);
        goto L28; // [829] 901
L27: 

        /** buildsys.e:520				elsif TBSD then*/
        if (_46TBSD_21600 == 0)
        {
            goto L29; // [836] 848
        }
        else{
        }

        /** buildsys.e:521					l_flags &= " -lm -lpthread"*/
        Concat((object_ptr)&_l_flags_45511, _l_flags_45511, _23754);
        goto L28; // [845] 901
L29: 

        /** buildsys.e:522				elsif TOSX then*/
        if (_46TOSX_21602 == 0)
        {
            goto L2A; // [852] 864
        }
        else{
        }

        /** buildsys.e:523					l_flags &= " -lresolv"*/
        Concat((object_ptr)&_l_flags_45511, _l_flags_45511, _23756);
        goto L28; // [861] 901
L2A: 

        /** buildsys.e:524				elsif TWINDOWS then*/
        if (_46TWINDOWS_21594 == 0)
        {
            goto L2B; // [868] 900
        }
        else{
        }

        /** buildsys.e:525					if mno_cygwin then*/
        if (_56mno_cygwin_45417 == 0)
        {
            goto L2C; // [875] 885
        }
        else{
        }

        /** buildsys.e:527						l_flags &= " -mno-cygwin"*/
        Concat((object_ptr)&_l_flags_45511, _l_flags_45511, _23740);
L2C: 

        /** buildsys.e:529					if not con_option then*/
        if (_58con_option_42569 != 0)
        goto L2D; // [889] 899

        /** buildsys.e:532						l_flags &= " -mwindows"*/
        Concat((object_ptr)&_l_flags_45511, _l_flags_45511, _23760);
L2D: 
L2B: 
L28: 

        /** buildsys.e:537				rc_comp = compiler_prefix & "windres -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" [1] -O coff -o [2]"*/
        _23763 = _17current_dir();
        _23764 = _56adjust_for_build_file(_23763);
        _23763 = NOVALUE;
        {
            object concat_list[4];

            concat_list[0] = _23765;
            concat_list[1] = _23764;
            concat_list[2] = _23762;
            concat_list[3] = _56compiler_prefix_45394;
            Concat_N((object_ptr)&_rc_comp_45515, concat_list, 4);
        }
        DeRef(_23764);
        _23764 = NOVALUE;
        DeRefi(_m_flag_45658);
        _m_flag_45658 = NOVALUE;
        goto L2E; // [921] 1127

        /** buildsys.e:539			case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:540				c_exe = compiler_prefix & "wcc386"*/
        Concat((object_ptr)&_c_exe_45508, _56compiler_prefix_45394, _23767);

        /** buildsys.e:541				l_exe = compiler_prefix & "wlink"*/
        Concat((object_ptr)&_l_exe_45510, _56compiler_prefix_45394, _23769);

        /** buildsys.e:542				obj_ext = "obj"*/
        RefDS(_23771);
        DeRefi(_obj_ext_45512);
        _obj_ext_45512 = _23771;

        /** buildsys.e:544				if debug_option then*/
        if (_58debug_option_42577 == 0)
        {
            goto L2F; // [954] 971
        }
        else{
        }

        /** buildsys.e:545					c_flags = " /d3"*/
        RefDS(_23772);
        DeRef(_c_flags_45509);
        _c_flags_45509 = _23772;

        /** buildsys.e:546					l_flags_begin &= " DEBUG ALL "*/
        Concat((object_ptr)&_l_flags_begin_45514, _l_flags_begin_45514, _23773);
L2F: 

        /** buildsys.e:549				l_flags &= sprintf(" OPTION STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _58total_stack_size_42582;
        _23776 = MAKE_SEQ(_1);
        _23777 = EPrintf(-9999999, _23775, _23776);
        DeRefDS(_23776);
        _23776 = NOVALUE;
        Concat((object_ptr)&_l_flags_45511, _l_flags_45511, _23777);
        DeRefDS(_23777);
        _23777 = NOVALUE;

        /** buildsys.e:550				l_flags &= sprintf(" COMMIT STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _58total_stack_size_42582;
        _23780 = MAKE_SEQ(_1);
        _23781 = EPrintf(-9999999, _23779, _23780);
        DeRefDS(_23780);
        _23780 = NOVALUE;
        Concat((object_ptr)&_l_flags_45511, _l_flags_45511, _23781);
        DeRefDS(_23781);
        _23781 = NOVALUE;

        /** buildsys.e:551				l_flags &= " OPTION QUIET OPTION ELIMINATE OPTION CASEEXACT"*/
        Concat((object_ptr)&_l_flags_45511, _l_flags_45511, _23783);

        /** buildsys.e:553				if dll_option then*/
        if (_58dll_option_42567 == 0)
        {
            goto L30; // [1013] 1039
        }
        else{
        }

        /** buildsys.e:554					c_flags &= " /bd /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir) */
        Ref(_compile_dir_45637);
        _23786 = _56adjust_for_build_file(_compile_dir_45637);
        if (IS_SEQUENCE(_23785) && IS_ATOM(_23786)) {
            Ref(_23786);
            Append(&_23787, _23785, _23786);
        }
        else if (IS_ATOM(_23785) && IS_SEQUENCE(_23786)) {
        }
        else {
            Concat((object_ptr)&_23787, _23785, _23786);
        }
        DeRef(_23786);
        _23786 = NOVALUE;
        Concat((object_ptr)&_c_flags_45509, _c_flags_45509, _23787);
        DeRefDS(_23787);
        _23787 = NOVALUE;

        /** buildsys.e:555					l_flags &= " SYSTEM NT_DLL initinstance terminstance"*/
        Concat((object_ptr)&_l_flags_45511, _l_flags_45511, _23789);
        goto L31; // [1036] 1077
L30: 

        /** buildsys.e:557					c_flags &= " /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir)*/
        Ref(_compile_dir_45637);
        _23792 = _56adjust_for_build_file(_compile_dir_45637);
        if (IS_SEQUENCE(_23791) && IS_ATOM(_23792)) {
            Ref(_23792);
            Append(&_23793, _23791, _23792);
        }
        else if (IS_ATOM(_23791) && IS_SEQUENCE(_23792)) {
        }
        else {
            Concat((object_ptr)&_23793, _23791, _23792);
        }
        DeRef(_23792);
        _23792 = NOVALUE;
        Concat((object_ptr)&_c_flags_45509, _c_flags_45509, _23793);
        DeRefDS(_23793);
        _23793 = NOVALUE;

        /** buildsys.e:558					if con_option then*/
        if (_58con_option_42569 == 0)
        {
            goto L32; // [1057] 1069
        }
        else{
        }

        /** buildsys.e:560						l_flags = " SYSTEM NT" & l_flags*/
        Concat((object_ptr)&_l_flags_45511, _23795, _l_flags_45511);
        goto L33; // [1066] 1076
L32: 

        /** buildsys.e:562						l_flags = " SYSTEM NT_WIN RUNTIME WINDOWS=4.0" & l_flags*/
        Concat((object_ptr)&_l_flags_45511, _23797, _l_flags_45511);
L33: 
L31: 

        /** buildsys.e:566				l_flags &= sprintf(" FILE %s", { (user_library) })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_58user_library_42579);
        ((intptr_t*)_2)[1] = _58user_library_42579;
        _23800 = MAKE_SEQ(_1);
        _23801 = EPrintf(-9999999, _23799, _23800);
        DeRefDS(_23800);
        _23800 = NOVALUE;
        Concat((object_ptr)&_l_flags_45511, _l_flags_45511, _23801);
        DeRefDS(_23801);
        _23801 = NOVALUE;

        /** buildsys.e:570				rc_comp = compiler_prefix &"wrc -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" -q -fo=[2] -ad [1] [3]"*/
        _23804 = _17current_dir();
        _23805 = _56adjust_for_build_file(_23804);
        _23804 = NOVALUE;
        {
            object concat_list[4];

            concat_list[0] = _23806;
            concat_list[1] = _23805;
            concat_list[2] = _23803;
            concat_list[3] = _56compiler_prefix_45394;
            Concat_N((object_ptr)&_rc_comp_45515, concat_list, 4);
        }
        DeRef(_23805);
        _23805 = NOVALUE;
        goto L2E; // [1111] 1127

        /** buildsys.e:571			case else*/
        default:

        /** buildsys.e:572				CompileErr(COMPILER_IS_UNKNOWN)*/
        RefDS(_21997);
        _50CompileErr(43, _21997, 0);
    ;}L2E: 

    /** buildsys.e:575		if length(cflags) then*/
    if (IS_SEQUENCE(_56cflags_45411)){
            _23808 = SEQ_PTR(_56cflags_45411)->length;
    }
    else {
        _23808 = 1;
    }
    if (_23808 == 0)
    {
        _23808 = NOVALUE;
        goto L34; // [1134] 1147
    }
    else{
        _23808 = NOVALUE;
    }

    /** buildsys.e:577			c_flags = cflags*/
    RefDS(_56cflags_45411);
    DeRef(_c_flags_45509);
    _c_flags_45509 = _56cflags_45411;
L34: 

    /** buildsys.e:580		if length(extra_cflags) then*/
    if (IS_SEQUENCE(_56extra_cflags_45412)){
            _23809 = SEQ_PTR(_56extra_cflags_45412)->length;
    }
    else {
        _23809 = 1;
    }
    if (_23809 == 0)
    {
        _23809 = NOVALUE;
        goto L35; // [1154] 1170
    }
    else{
        _23809 = NOVALUE;
    }

    /** buildsys.e:581			c_flags &= " " & extra_cflags*/
    Concat((object_ptr)&_23810, _23388, _56extra_cflags_45412);
    Concat((object_ptr)&_c_flags_45509, _c_flags_45509, _23810);
    DeRefDS(_23810);
    _23810 = NOVALUE;
L35: 

    /** buildsys.e:584		if length(lflags) then*/
    if (IS_SEQUENCE(_56lflags_45413)){
            _23812 = SEQ_PTR(_56lflags_45413)->length;
    }
    else {
        _23812 = 1;
    }
    if (_23812 == 0)
    {
        _23812 = NOVALUE;
        goto L36; // [1177] 1197
    }
    else{
        _23812 = NOVALUE;
    }

    /** buildsys.e:585			l_flags = lflags*/
    RefDS(_56lflags_45413);
    DeRef(_l_flags_45511);
    _l_flags_45511 = _56lflags_45413;

    /** buildsys.e:586			l_flags_begin = ""*/
    RefDS(_21997);
    DeRefi(_l_flags_begin_45514);
    _l_flags_begin_45514 = _21997;
L36: 

    /** buildsys.e:589		if length(extra_lflags) then*/
    if (IS_SEQUENCE(_56extra_lflags_45414)){
            _23813 = SEQ_PTR(_56extra_lflags_45414)->length;
    }
    else {
        _23813 = 1;
    }
    if (_23813 == 0)
    {
        _23813 = NOVALUE;
        goto L37; // [1204] 1220
    }
    else{
        _23813 = NOVALUE;
    }

    /** buildsys.e:590			l_flags &= " " & extra_lflags*/
    Concat((object_ptr)&_23814, _23388, _56extra_lflags_45414);
    Concat((object_ptr)&_l_flags_45511, _l_flags_45511, _23814);
    DeRefDS(_23814);
    _23814 = NOVALUE;
L37: 

    /** buildsys.e:593		return { */
    _1 = NewS1(9);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_c_exe_45508);
    ((intptr_t*)_2)[1] = _c_exe_45508;
    RefDS(_c_flags_45509);
    ((intptr_t*)_2)[2] = _c_flags_45509;
    RefDS(_l_exe_45510);
    ((intptr_t*)_2)[3] = _l_exe_45510;
    RefDS(_l_flags_45511);
    ((intptr_t*)_2)[4] = _l_flags_45511;
    RefDS(_obj_ext_45512);
    ((intptr_t*)_2)[5] = _obj_ext_45512;
    RefDS(_exe_ext_45513);
    ((intptr_t*)_2)[6] = _exe_ext_45513;
    RefDS(_l_flags_begin_45514);
    ((intptr_t*)_2)[7] = _l_flags_begin_45514;
    RefDS(_rc_comp_45515);
    ((intptr_t*)_2)[8] = _rc_comp_45515;
    RefDS(_58user_library_42579);
    ((intptr_t*)_2)[9] = _58user_library_42579;
    _23816 = MAKE_SEQ(_1);
    DeRefDS(_c_exe_45508);
    DeRefDS(_c_flags_45509);
    DeRefDS(_l_exe_45510);
    DeRefDS(_l_flags_45511);
    DeRefDSi(_obj_ext_45512);
    DeRefDSi(_exe_ext_45513);
    DeRefDSi(_l_flags_begin_45514);
    DeRefDS(_rc_comp_45515);
    DeRef(_l_names_45516);
    DeRefi(_l_ext_45517);
    DeRefi(_t_slash_45518);
    DeRef(_compile_dir_45637);
    DeRef(_23650);
    _23650 = NOVALUE;
    return _23816;
    ;
}


void _56ensure_exename(object _ext_45805)
{
    object _23823 = NOVALUE;
    object _23822 = NOVALUE;
    object _23821 = NOVALUE;
    object _23820 = NOVALUE;
    object _23818 = NOVALUE;
    object _23817 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:602		if length(exe_name[D_ALTNAME]) = 0 then*/
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _23817 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23817)){
            _23818 = SEQ_PTR(_23817)->length;
    }
    else {
        _23818 = 1;
    }
    _23817 = NOVALUE;
    if (_23818 != 0)
    goto L1; // [16] 67

    /** buildsys.e:603			exe_name[D_NAME] = current_dir() & SLASH & file0 & ext*/
    _23820 = _17current_dir();
    {
        object concat_list[4];

        concat_list[0] = _ext_45805;
        concat_list[1] = _58file0_44535;
        concat_list[2] = 47;
        concat_list[3] = _23820;
        Concat_N((object_ptr)&_23821, concat_list, 4);
    }
    DeRef(_23820);
    _23820 = NOVALUE;
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23821;
    if( _1 != _23821 ){
        DeRef(_1);
    }
    _23821 = NOVALUE;

    /** buildsys.e:604			exe_name[D_ALTNAME] = adjust_for_command_line_passing(exe_name[D_NAME])*/
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _23822 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_23822);
    _23823 = _56adjust_for_command_line_passing(_23822);
    _23822 = NOVALUE;
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23823;
    if( _1 != _23823 ){
        DeRef(_1);
    }
    _23823 = NOVALUE;
L1: 

    /** buildsys.e:606	end procedure*/
    DeRefDS(_ext_45805);
    _23817 = NOVALUE;
    return;
    ;
}


void _56write_objlink_file()
{
    object _settings_45823 = NOVALUE;
    object _fh_45825 = NOVALUE;
    object _s_45873 = NOVALUE;
    object _23872 = NOVALUE;
    object _23870 = NOVALUE;
    object _23869 = NOVALUE;
    object _23868 = NOVALUE;
    object _23867 = NOVALUE;
    object _23866 = NOVALUE;
    object _23865 = NOVALUE;
    object _23864 = NOVALUE;
    object _23863 = NOVALUE;
    object _23862 = NOVALUE;
    object _23861 = NOVALUE;
    object _23860 = NOVALUE;
    object _23859 = NOVALUE;
    object _23857 = NOVALUE;
    object _23856 = NOVALUE;
    object _23855 = NOVALUE;
    object _23854 = NOVALUE;
    object _23852 = NOVALUE;
    object _23851 = NOVALUE;
    object _23850 = NOVALUE;
    object _23849 = NOVALUE;
    object _23848 = NOVALUE;
    object _23847 = NOVALUE;
    object _23846 = NOVALUE;
    object _23845 = NOVALUE;
    object _23844 = NOVALUE;
    object _23841 = NOVALUE;
    object _23840 = NOVALUE;
    object _23837 = NOVALUE;
    object _23836 = NOVALUE;
    object _23835 = NOVALUE;
    object _23834 = NOVALUE;
    object _23833 = NOVALUE;
    object _23831 = NOVALUE;
    object _23830 = NOVALUE;
    object _23829 = NOVALUE;
    object _23826 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:612		sequence settings = setup_build()*/
    _0 = _settings_45823;
    _settings_45823 = _56setup_build();
    DeRef(_0);

    /** buildsys.e:613		integer fh = open(output_dir & file0 & ".lnk", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _23825;
        concat_list[1] = _58file0_44535;
        concat_list[2] = _58output_dir_42581;
        Concat_N((object_ptr)&_23826, concat_list, 3);
    }
    _fh_45825 = EOpen(_23826, _23827, 0);
    DeRefDS(_23826);
    _23826 = NOVALUE;

    /** buildsys.e:615		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_45823);
    _23829 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_23829);
    _56ensure_exename(_23829);
    _23829 = NOVALUE;

    /** buildsys.e:617		if length(settings[SETUP_LFLAGS_BEGIN]) > 0 then*/
    _2 = (object)SEQ_PTR(_settings_45823);
    _23830 = (object)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_23830)){
            _23831 = SEQ_PTR(_23830)->length;
    }
    else {
        _23831 = 1;
    }
    _23830 = NOVALUE;
    if (_23831 <= 0)
    goto L1; // [43] 63

    /** buildsys.e:618			puts(fh, settings[SETUP_LFLAGS_BEGIN] & HOSTNL)*/
    _2 = (object)SEQ_PTR(_settings_45823);
    _23833 = (object)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_23833) && IS_ATOM(_46HOSTNL_21616)) {
    }
    else if (IS_ATOM(_23833) && IS_SEQUENCE(_46HOSTNL_21616)) {
        Ref(_23833);
        Prepend(&_23834, _46HOSTNL_21616, _23833);
    }
    else {
        Concat((object_ptr)&_23834, _23833, _46HOSTNL_21616);
        _23833 = NOVALUE;
    }
    _23833 = NOVALUE;
    EPuts(_fh_45825, _23834); // DJP 
    DeRefDS(_23834);
    _23834 = NOVALUE;
L1: 

    /** buildsys.e:621		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42571)){
            _23835 = SEQ_PTR(_58generated_files_42571)->length;
    }
    else {
        _23835 = 1;
    }
    {
        object _i_45841;
        _i_45841 = 1;
L2: 
        if (_i_45841 > _23835){
            goto L3; // [70] 132
        }

        /** buildsys.e:622			if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _23836 = (object)*(((s1_ptr)_2)->base + _i_45841);
        _23837 = e_match_from(_23148, _23836, 1);
        _23836 = NOVALUE;
        if (_23837 == 0)
        {
            _23837 = NOVALUE;
            goto L4; // [90] 125
        }
        else{
            _23837 = NOVALUE;
        }

        /** buildsys.e:623				if compiler_type = COMPILER_WATCOM then*/
        if (_56compiler_type_45393 != 2)
        goto L5; // [97] 107

        /** buildsys.e:624					puts(fh, "FILE ")*/
        EPuts(_fh_45825, _23839); // DJP 
L5: 

        /** buildsys.e:627				puts(fh, generated_files[i] & HOSTNL)*/
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _23840 = (object)*(((s1_ptr)_2)->base + _i_45841);
        Concat((object_ptr)&_23841, _23840, _46HOSTNL_21616);
        _23840 = NOVALUE;
        _23840 = NOVALUE;
        EPuts(_fh_45825, _23841); // DJP 
        DeRefDS(_23841);
        _23841 = NOVALUE;
L4: 

        /** buildsys.e:629		end for*/
        _i_45841 = _i_45841 + 1;
        goto L2; // [127] 77
L3: 
        ;
    }

    /** buildsys.e:631		if compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45393 != 2)
    goto L6; // [136] 165

    /** buildsys.e:632			printf(fh, "NAME '%s'" & HOSTNL, { exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_23844, _23843, _46HOSTNL_21616);
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _23845 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23845);
    ((intptr_t*)_2)[1] = _23845;
    _23846 = MAKE_SEQ(_1);
    _23845 = NOVALUE;
    EPrintf(_fh_45825, _23844, _23846);
    DeRefDS(_23844);
    _23844 = NOVALUE;
    DeRefDS(_23846);
    _23846 = NOVALUE;
L6: 

    /** buildsys.e:635		puts(fh, trim(settings[SETUP_LFLAGS] & HOSTNL))*/
    _2 = (object)SEQ_PTR(_settings_45823);
    _23847 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_23847) && IS_ATOM(_46HOSTNL_21616)) {
    }
    else if (IS_ATOM(_23847) && IS_SEQUENCE(_46HOSTNL_21616)) {
        Ref(_23847);
        Prepend(&_23848, _46HOSTNL_21616, _23847);
    }
    else {
        Concat((object_ptr)&_23848, _23847, _46HOSTNL_21616);
        _23847 = NOVALUE;
    }
    _23847 = NOVALUE;
    RefDS(_3871);
    _23849 = _14trim(_23848, _3871, 0);
    _23848 = NOVALUE;
    EPuts(_fh_45825, _23849); // DJP 
    DeRef(_23849);
    _23849 = NOVALUE;

    /** buildsys.e:637		if compiler_type = COMPILER_WATCOM and dll_option then*/
    _23850 = (_56compiler_type_45393 == 2);
    if (_23850 == 0) {
        goto L7; // [194] 361
    }
    if (_58dll_option_42567 == 0)
    {
        goto L7; // [201] 361
    }
    else{
    }

    /** buildsys.e:638			puts(fh, HOSTNL)*/
    EPuts(_fh_45825, _46HOSTNL_21616); // DJP 

    /** buildsys.e:640			object s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23852 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21454);
    DeRef(_s_45873);
    _2 = (object)SEQ_PTR(_23852);
    _s_45873 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_s_45873);
    _23852 = NOVALUE;

    /** buildsys.e:641			while s do*/
L8: 
    if (_s_45873 <= 0) {
        if (_s_45873 == 0) {
            goto L9; // [232] 360
        }
        else {
            if (!IS_ATOM_INT(_s_45873) && DBL_PTR(_s_45873)->dbl == 0.0){
                goto L9; // [232] 360
            }
        }
    }

    /** buildsys.e:642				if eu:find(SymTab[s][S_TOKEN], RTN_TOKS) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_s_45873)){
        _23854 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45873)->dbl));
    }
    else{
        _23854 = (object)*(((s1_ptr)_2)->base + _s_45873);
    }
    _2 = (object)SEQ_PTR(_23854);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _23855 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _23855 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    _23854 = NOVALUE;
    _23856 = find_from(_23855, _38RTN_TOKS_16045, 1);
    _23855 = NOVALUE;
    if (_23856 == 0)
    {
        _23856 = NOVALUE;
        goto LA; // [256] 341
    }
    else{
        _23856 = NOVALUE;
    }

    /** buildsys.e:643					if is_exported( s ) then*/
    Ref(_s_45873);
    _23857 = _58is_exported(_s_45873);
    if (_23857 == 0) {
        DeRef(_23857);
        _23857 = NOVALUE;
        goto LB; // [265] 340
    }
    else {
        if (!IS_ATOM_INT(_23857) && DBL_PTR(_23857)->dbl == 0.0){
            DeRef(_23857);
            _23857 = NOVALUE;
            goto LB; // [265] 340
        }
        DeRef(_23857);
        _23857 = NOVALUE;
    }
    DeRef(_23857);
    _23857 = NOVALUE;

    /** buildsys.e:644						printf(fh, "EXPORT %s='__%d%s@%d'" & HOSTNL,*/
    Concat((object_ptr)&_23859, _23858, _46HOSTNL_21616);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_s_45873)){
        _23860 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45873)->dbl));
    }
    else{
        _23860 = (object)*(((s1_ptr)_2)->base + _s_45873);
    }
    _2 = (object)SEQ_PTR(_23860);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _23861 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _23861 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _23860 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_s_45873)){
        _23862 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45873)->dbl));
    }
    else{
        _23862 = (object)*(((s1_ptr)_2)->base + _s_45873);
    }
    _2 = (object)SEQ_PTR(_23862);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _23863 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _23863 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _23862 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_s_45873)){
        _23864 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45873)->dbl));
    }
    else{
        _23864 = (object)*(((s1_ptr)_2)->base + _s_45873);
    }
    _2 = (object)SEQ_PTR(_23864);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _23865 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _23865 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _23864 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_s_45873)){
        _23866 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45873)->dbl));
    }
    else{
        _23866 = (object)*(((s1_ptr)_2)->base + _s_45873);
    }
    _2 = (object)SEQ_PTR(_23866);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
        _23867 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
    }
    else{
        _23867 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
    }
    _23866 = NOVALUE;
    if (IS_ATOM_INT(_23867)) {
        if (_23867 == (short)_23867){
            _23868 = _23867 * 4;
        }
        else{
            _23868 = NewDouble(_23867 * (eudouble)4);
        }
    }
    else {
        _23868 = binary_op(MULTIPLY, _23867, 4);
    }
    _23867 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23861);
    ((intptr_t*)_2)[1] = _23861;
    Ref(_23863);
    ((intptr_t*)_2)[2] = _23863;
    Ref(_23865);
    ((intptr_t*)_2)[3] = _23865;
    ((intptr_t*)_2)[4] = _23868;
    _23869 = MAKE_SEQ(_1);
    _23868 = NOVALUE;
    _23865 = NOVALUE;
    _23863 = NOVALUE;
    _23861 = NOVALUE;
    EPrintf(_fh_45825, _23859, _23869);
    DeRefDS(_23859);
    _23859 = NOVALUE;
    DeRefDS(_23869);
    _23869 = NOVALUE;
LB: 
LA: 

    /** buildsys.e:649				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_s_45873)){
        _23870 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45873)->dbl));
    }
    else{
        _23870 = (object)*(((s1_ptr)_2)->base + _s_45873);
    }
    DeRef(_s_45873);
    _2 = (object)SEQ_PTR(_23870);
    _s_45873 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_s_45873);
    _23870 = NOVALUE;

    /** buildsys.e:650			end while*/
    goto L8; // [357] 232
L9: 
L7: 
    DeRef(_s_45873);
    _s_45873 = NOVALUE;

    /** buildsys.e:653		close(fh)*/
    EClose(_fh_45825);

    /** buildsys.e:655		generated_files = append(generated_files, file0 & ".lnk")*/
    Concat((object_ptr)&_23872, _58file0_44535, _23825);
    RefDS(_23872);
    Append(&_58generated_files_42571, _58generated_files_42571, _23872);
    DeRefDS(_23872);
    _23872 = NOVALUE;

    /** buildsys.e:656	end procedure*/
    DeRef(_settings_45823);
    _23830 = NOVALUE;
    DeRef(_23850);
    _23850 = NOVALUE;
    return;
    ;
}


void _56write_makefile_srcobj_list(object _fh_45922)
{
    object _file_count_45952 = NOVALUE;
    object _23904 = NOVALUE;
    object _23903 = NOVALUE;
    object _23902 = NOVALUE;
    object _23900 = NOVALUE;
    object _23899 = NOVALUE;
    object _23898 = NOVALUE;
    object _23896 = NOVALUE;
    object _23895 = NOVALUE;
    object _23893 = NOVALUE;
    object _23892 = NOVALUE;
    object _23891 = NOVALUE;
    object _23890 = NOVALUE;
    object _23889 = NOVALUE;
    object _23888 = NOVALUE;
    object _23886 = NOVALUE;
    object _23885 = NOVALUE;
    object _23884 = NOVALUE;
    object _23880 = NOVALUE;
    object _23879 = NOVALUE;
    object _23878 = NOVALUE;
    object _23877 = NOVALUE;
    object _23876 = NOVALUE;
    object _23875 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:660		printf(fh, "%s_SOURCES =", { upper(file0) })*/
    RefDS(_58file0_44535);
    _23875 = _14upper(_58file0_44535);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23875;
    _23876 = MAKE_SEQ(_1);
    _23875 = NOVALUE;
    EPrintf(_fh_45922, _23874, _23876);
    DeRefDS(_23876);
    _23876 = NOVALUE;

    /** buildsys.e:661		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42571)){
            _23877 = SEQ_PTR(_58generated_files_42571)->length;
    }
    else {
        _23877 = 1;
    }
    {
        object _i_45929;
        _i_45929 = 1;
L1: 
        if (_i_45929 > _23877){
            goto L2; // [26] 94
        }

        /** buildsys.e:662			if generated_files[i][$] = 'c' then*/
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _23878 = (object)*(((s1_ptr)_2)->base + _i_45929);
        if (IS_SEQUENCE(_23878)){
                _23879 = SEQ_PTR(_23878)->length;
        }
        else {
            _23879 = 1;
        }
        _2 = (object)SEQ_PTR(_23878);
        _23880 = (object)*(((s1_ptr)_2)->base + _23879);
        _23878 = NOVALUE;
        if (binary_op_a(NOTEQ, _23880, 99)){
            _23880 = NOVALUE;
            goto L3; // [48] 87
        }
        _23880 = NOVALUE;

        /** buildsys.e:663				if i > 1 then*/
        if (_i_45929 <= 1)
        goto L4; // [54] 71

        /** buildsys.e:664					printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_46HOSTNL_21616);
        ((intptr_t*)_2)[1] = _46HOSTNL_21616;
        _23884 = MAKE_SEQ(_1);
        EPrintf(_fh_45922, _23883, _23884);
        DeRefDS(_23884);
        _23884 = NOVALUE;
L4: 

        /** buildsys.e:666				puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _23885 = (object)*(((s1_ptr)_2)->base + _i_45929);
        Concat((object_ptr)&_23886, _23388, _23885);
        _23885 = NOVALUE;
        EPuts(_fh_45922, _23886); // DJP 
        DeRefDS(_23886);
        _23886 = NOVALUE;
L3: 

        /** buildsys.e:668		end for*/
        _i_45929 = _i_45929 + 1;
        goto L1; // [89] 33
L2: 
        ;
    }

    /** buildsys.e:669		puts(fh, HOSTNL)*/
    EPuts(_fh_45922, _46HOSTNL_21616); // DJP 

    /** buildsys.e:671		printf(fh, "%s_OBJECTS =", { upper(file0) })*/
    RefDS(_58file0_44535);
    _23888 = _14upper(_58file0_44535);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23888;
    _23889 = MAKE_SEQ(_1);
    _23888 = NOVALUE;
    EPrintf(_fh_45922, _23887, _23889);
    DeRefDS(_23889);
    _23889 = NOVALUE;

    /** buildsys.e:672		integer file_count = 0*/
    _file_count_45952 = 0;

    /** buildsys.e:673		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42571)){
            _23890 = SEQ_PTR(_58generated_files_42571)->length;
    }
    else {
        _23890 = 1;
    }
    {
        object _i_45954;
        _i_45954 = 1;
L5: 
        if (_i_45954 > _23890){
            goto L6; // [129] 199
        }

        /** buildsys.e:674			if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _23891 = (object)*(((s1_ptr)_2)->base + _i_45954);
        _23892 = e_match_from(_23148, _23891, 1);
        _23891 = NOVALUE;
        if (_23892 == 0)
        {
            _23892 = NOVALUE;
            goto L7; // [149] 192
        }
        else{
            _23892 = NOVALUE;
        }

        /** buildsys.e:675				if file_count then*/
        if (_file_count_45952 == 0)
        {
            goto L8; // [154] 170
        }
        else{
        }

        /** buildsys.e:676					printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_46HOSTNL_21616);
        ((intptr_t*)_2)[1] = _46HOSTNL_21616;
        _23893 = MAKE_SEQ(_1);
        EPrintf(_fh_45922, _23883, _23893);
        DeRefDS(_23893);
        _23893 = NOVALUE;
L8: 

        /** buildsys.e:678				file_count += 1*/
        _file_count_45952 = _file_count_45952 + 1;

        /** buildsys.e:679				puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _23895 = (object)*(((s1_ptr)_2)->base + _i_45954);
        Concat((object_ptr)&_23896, _23388, _23895);
        _23895 = NOVALUE;
        EPuts(_fh_45922, _23896); // DJP 
        DeRefDS(_23896);
        _23896 = NOVALUE;
L7: 

        /** buildsys.e:681		end for*/
        _i_45954 = _i_45954 + 1;
        goto L5; // [194] 136
L6: 
        ;
    }

    /** buildsys.e:682		puts(fh, HOSTNL)*/
    EPuts(_fh_45922, _46HOSTNL_21616); // DJP 

    /** buildsys.e:684		printf(fh, "%s_GENERATED_FILES = ", { upper(file0) })*/
    RefDS(_58file0_44535);
    _23898 = _14upper(_58file0_44535);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23898;
    _23899 = MAKE_SEQ(_1);
    _23898 = NOVALUE;
    EPrintf(_fh_45922, _23897, _23899);
    DeRefDS(_23899);
    _23899 = NOVALUE;

    /** buildsys.e:685		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42571)){
            _23900 = SEQ_PTR(_58generated_files_42571)->length;
    }
    else {
        _23900 = 1;
    }
    {
        object _i_45975;
        _i_45975 = 1;
L9: 
        if (_i_45975 > _23900){
            goto LA; // [229] 277
        }

        /** buildsys.e:686			if i > 1 then*/
        if (_i_45975 <= 1)
        goto LB; // [238] 255

        /** buildsys.e:687				printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_46HOSTNL_21616);
        ((intptr_t*)_2)[1] = _46HOSTNL_21616;
        _23902 = MAKE_SEQ(_1);
        EPrintf(_fh_45922, _23883, _23902);
        DeRefDS(_23902);
        _23902 = NOVALUE;
LB: 

        /** buildsys.e:689			puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _23903 = (object)*(((s1_ptr)_2)->base + _i_45975);
        Concat((object_ptr)&_23904, _23388, _23903);
        _23903 = NOVALUE;
        EPuts(_fh_45922, _23904); // DJP 
        DeRefDS(_23904);
        _23904 = NOVALUE;

        /** buildsys.e:690		end for*/
        _i_45975 = _i_45975 + 1;
        goto L9; // [272] 236
LA: 
        ;
    }

    /** buildsys.e:691		puts(fh, HOSTNL)*/
    EPuts(_fh_45922, _46HOSTNL_21616); // DJP 

    /** buildsys.e:692	end procedure*/
    return;
    ;
}


object _56windows_to_mingw_path(object _s_45988)
{
    object _23906 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:701		ifdef TEST_FOR_WIN9X_ON_MING then*/

    /** buildsys.e:711		return search:find_replace('\\',s,'/')*/
    RefDS(_s_45988);
    _23906 = _16find_replace(92, _s_45988, 47, 0);
    DeRefDS(_s_45988);
    return _23906;
    ;
}


void _56write_makefile_full()
{
    object _settings_45993 = NOVALUE;
    object _fh_45996 = NOVALUE;
    object _24033 = NOVALUE;
    object _24031 = NOVALUE;
    object _24029 = NOVALUE;
    object _24028 = NOVALUE;
    object _24027 = NOVALUE;
    object _24026 = NOVALUE;
    object _24025 = NOVALUE;
    object _24023 = NOVALUE;
    object _24022 = NOVALUE;
    object _24020 = NOVALUE;
    object _24019 = NOVALUE;
    object _24018 = NOVALUE;
    object _24017 = NOVALUE;
    object _24015 = NOVALUE;
    object _24014 = NOVALUE;
    object _24012 = NOVALUE;
    object _24011 = NOVALUE;
    object _24009 = NOVALUE;
    object _24008 = NOVALUE;
    object _24007 = NOVALUE;
    object _24006 = NOVALUE;
    object _24005 = NOVALUE;
    object _24004 = NOVALUE;
    object _24003 = NOVALUE;
    object _24002 = NOVALUE;
    object _24000 = NOVALUE;
    object _23999 = NOVALUE;
    object _23998 = NOVALUE;
    object _23997 = NOVALUE;
    object _23996 = NOVALUE;
    object _23995 = NOVALUE;
    object _23994 = NOVALUE;
    object _23993 = NOVALUE;
    object _23992 = NOVALUE;
    object _23991 = NOVALUE;
    object _23990 = NOVALUE;
    object _23989 = NOVALUE;
    object _23988 = NOVALUE;
    object _23986 = NOVALUE;
    object _23985 = NOVALUE;
    object _23983 = NOVALUE;
    object _23981 = NOVALUE;
    object _23979 = NOVALUE;
    object _23978 = NOVALUE;
    object _23977 = NOVALUE;
    object _23976 = NOVALUE;
    object _23975 = NOVALUE;
    object _23974 = NOVALUE;
    object _23973 = NOVALUE;
    object _23972 = NOVALUE;
    object _23971 = NOVALUE;
    object _23970 = NOVALUE;
    object _23969 = NOVALUE;
    object _23968 = NOVALUE;
    object _23967 = NOVALUE;
    object _23966 = NOVALUE;
    object _23964 = NOVALUE;
    object _23963 = NOVALUE;
    object _23962 = NOVALUE;
    object _23961 = NOVALUE;
    object _23960 = NOVALUE;
    object _23959 = NOVALUE;
    object _23958 = NOVALUE;
    object _23957 = NOVALUE;
    object _23956 = NOVALUE;
    object _23954 = NOVALUE;
    object _23953 = NOVALUE;
    object _23952 = NOVALUE;
    object _23951 = NOVALUE;
    object _23949 = NOVALUE;
    object _23948 = NOVALUE;
    object _23947 = NOVALUE;
    object _23946 = NOVALUE;
    object _23945 = NOVALUE;
    object _23944 = NOVALUE;
    object _23942 = NOVALUE;
    object _23941 = NOVALUE;
    object _23940 = NOVALUE;
    object _23939 = NOVALUE;
    object _23938 = NOVALUE;
    object _23937 = NOVALUE;
    object _23936 = NOVALUE;
    object _23934 = NOVALUE;
    object _23933 = NOVALUE;
    object _23932 = NOVALUE;
    object _23931 = NOVALUE;
    object _23928 = NOVALUE;
    object _23927 = NOVALUE;
    object _23926 = NOVALUE;
    object _23923 = NOVALUE;
    object _23922 = NOVALUE;
    object _23921 = NOVALUE;
    object _23919 = NOVALUE;
    object _23918 = NOVALUE;
    object _23917 = NOVALUE;
    object _23915 = NOVALUE;
    object _23914 = NOVALUE;
    object _23913 = NOVALUE;
    object _23910 = NOVALUE;
    object _23908 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:718		sequence settings = setup_build()*/
    _0 = _settings_45993;
    _settings_45993 = _56setup_build();
    DeRef(_0);

    /** buildsys.e:720		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_45993);
    _23908 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_23908);
    _56ensure_exename(_23908);
    _23908 = NOVALUE;

    /** buildsys.e:722		integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _23909;
        concat_list[1] = _58file0_44535;
        concat_list[2] = _58output_dir_42581;
        Concat_N((object_ptr)&_23910, concat_list, 3);
    }
    _fh_45996 = EOpen(_23910, _23827, 0);
    DeRefDS(_23910);
    _23910 = NOVALUE;

    /** buildsys.e:724		printf(fh, "CC     = %s" & HOSTNL, { settings[SETUP_CEXE] })*/
    Concat((object_ptr)&_23913, _23912, _46HOSTNL_21616);
    _2 = (object)SEQ_PTR(_settings_45993);
    _23914 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23914);
    ((intptr_t*)_2)[1] = _23914;
    _23915 = MAKE_SEQ(_1);
    _23914 = NOVALUE;
    EPrintf(_fh_45996, _23913, _23915);
    DeRefDS(_23913);
    _23913 = NOVALUE;
    DeRefDS(_23915);
    _23915 = NOVALUE;

    /** buildsys.e:725		printf(fh, "CFLAGS = %s" & HOSTNL, { settings[SETUP_CFLAGS] })*/
    Concat((object_ptr)&_23917, _23916, _46HOSTNL_21616);
    _2 = (object)SEQ_PTR(_settings_45993);
    _23918 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23918);
    ((intptr_t*)_2)[1] = _23918;
    _23919 = MAKE_SEQ(_1);
    _23918 = NOVALUE;
    EPrintf(_fh_45996, _23917, _23919);
    DeRefDS(_23917);
    _23917 = NOVALUE;
    DeRefDS(_23919);
    _23919 = NOVALUE;

    /** buildsys.e:726		printf(fh, "LINKER = %s" & HOSTNL, { settings[SETUP_LEXE] })*/
    Concat((object_ptr)&_23921, _23920, _46HOSTNL_21616);
    _2 = (object)SEQ_PTR(_settings_45993);
    _23922 = (object)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23922);
    ((intptr_t*)_2)[1] = _23922;
    _23923 = MAKE_SEQ(_1);
    _23922 = NOVALUE;
    EPrintf(_fh_45996, _23921, _23923);
    DeRefDS(_23921);
    _23921 = NOVALUE;
    DeRefDS(_23923);
    _23923 = NOVALUE;

    /** buildsys.e:728		if compiler_type = COMPILER_GCC then*/
    if (_56compiler_type_45393 != 1)
    goto L1; // [98] 125

    /** buildsys.e:729			printf(fh, "LFLAGS = %s" & HOSTNL, { settings[SETUP_LFLAGS] })*/
    Concat((object_ptr)&_23926, _23925, _46HOSTNL_21616);
    _2 = (object)SEQ_PTR(_settings_45993);
    _23927 = (object)*(((s1_ptr)_2)->base + 4);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23927);
    ((intptr_t*)_2)[1] = _23927;
    _23928 = MAKE_SEQ(_1);
    _23927 = NOVALUE;
    EPrintf(_fh_45996, _23926, _23928);
    DeRefDS(_23926);
    _23926 = NOVALUE;
    DeRefDS(_23928);
    _23928 = NOVALUE;
    goto L2; // [122] 130
L1: 

    /** buildsys.e:731			write_objlink_file()*/
    _56write_objlink_file();
L2: 

    /** buildsys.e:734		write_makefile_srcobj_list(fh)*/
    _56write_makefile_srcobj_list(_fh_45996);

    /** buildsys.e:735		puts(fh, HOSTNL)*/
    EPuts(_fh_45996, _46HOSTNL_21616); // DJP 

    /** buildsys.e:737		if compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45393 != 2)
    goto L3; // [146] 575

    /** buildsys.e:738			printf(fh, "\"%s\" : $(%s_OBJECTS) %s" & HOSTNL, { */
    Concat((object_ptr)&_23931, _23930, _46HOSTNL_21616);
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _23932 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_58file0_44535);
    _23933 = _14upper(_58file0_44535);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23932);
    ((intptr_t*)_2)[1] = _23932;
    ((intptr_t*)_2)[2] = _23933;
    RefDS(_58user_library_42579);
    ((intptr_t*)_2)[3] = _58user_library_42579;
    _23934 = MAKE_SEQ(_1);
    _23933 = NOVALUE;
    _23932 = NOVALUE;
    EPrintf(_fh_45996, _23931, _23934);
    DeRefDS(_23931);
    _23931 = NOVALUE;
    DeRefDS(_23934);
    _23934 = NOVALUE;

    /** buildsys.e:741			printf(fh, "\t$(LINKER) @%s.lnk" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_23936, _23935, _46HOSTNL_21616);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_58file0_44535);
    ((intptr_t*)_2)[1] = _58file0_44535;
    _23937 = MAKE_SEQ(_1);
    EPrintf(_fh_45996, _23936, _23937);
    DeRefDS(_23936);
    _23936 = NOVALUE;
    DeRefDS(_23937);
    _23937 = NOVALUE;

    /** buildsys.e:742			if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) then*/
    _2 = (object)SEQ_PTR(_56rc_file_45402);
    _23938 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23938)){
            _23939 = SEQ_PTR(_23938)->length;
    }
    else {
        _23939 = 1;
    }
    _23938 = NOVALUE;
    if (_23939 == 0) {
        goto L4; // [215] 277
    }
    _2 = (object)SEQ_PTR(_settings_45993);
    _23941 = (object)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_23941)){
            _23942 = SEQ_PTR(_23941)->length;
    }
    else {
        _23942 = 1;
    }
    _23941 = NOVALUE;
    if (_23942 == 0)
    {
        _23942 = NOVALUE;
        goto L4; // [227] 277
    }
    else{
        _23942 = NOVALUE;
    }

    /** buildsys.e:743				writef(fh, "\t" & settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_45993);
    _23944 = (object)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_23943) && IS_ATOM(_23944)) {
        Ref(_23944);
        Append(&_23945, _23943, _23944);
    }
    else if (IS_ATOM(_23943) && IS_SEQUENCE(_23944)) {
    }
    else {
        Concat((object_ptr)&_23945, _23943, _23944);
    }
    _23944 = NOVALUE;
    _2 = (object)SEQ_PTR(_56rc_file_45402);
    _23946 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_56res_file_45408);
    _23947 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _23948 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23946);
    ((intptr_t*)_2)[1] = _23946;
    Ref(_23947);
    ((intptr_t*)_2)[2] = _23947;
    Ref(_23948);
    ((intptr_t*)_2)[3] = _23948;
    _23949 = MAKE_SEQ(_1);
    _23948 = NOVALUE;
    _23947 = NOVALUE;
    _23946 = NOVALUE;
    _8writef(_fh_45996, _23945, _23949, 0);
    _23945 = NOVALUE;
    _23949 = NOVALUE;
L4: 

    /** buildsys.e:745			puts(fh, HOSTNL)*/
    EPuts(_fh_45996, _46HOSTNL_21616); // DJP 

    /** buildsys.e:746			printf(fh, "%s-clean : .SYMBOLIC" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_23951, _23950, _46HOSTNL_21616);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_58file0_44535);
    ((intptr_t*)_2)[1] = _58file0_44535;
    _23952 = MAKE_SEQ(_1);
    EPrintf(_fh_45996, _23951, _23952);
    DeRefDS(_23951);
    _23951 = NOVALUE;
    DeRefDS(_23952);
    _23952 = NOVALUE;

    /** buildsys.e:747			if length(res_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_56res_file_45408);
    _23953 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23953)){
            _23954 = SEQ_PTR(_23953)->length;
    }
    else {
        _23954 = 1;
    }
    _23953 = NOVALUE;
    if (_23954 == 0)
    {
        _23954 = NOVALUE;
        goto L5; // [315] 343
    }
    else{
        _23954 = NOVALUE;
    }

    /** buildsys.e:748				printf(fh, "\tdel \"%s\"" & HOSTNL, { res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_23956, _23955, _46HOSTNL_21616);
    _2 = (object)SEQ_PTR(_56res_file_45408);
    _23957 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23957);
    ((intptr_t*)_2)[1] = _23957;
    _23958 = MAKE_SEQ(_1);
    _23957 = NOVALUE;
    EPrintf(_fh_45996, _23956, _23958);
    DeRefDS(_23956);
    _23956 = NOVALUE;
    DeRefDS(_23958);
    _23958 = NOVALUE;
L5: 

    /** buildsys.e:750			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42571)){
            _23959 = SEQ_PTR(_58generated_files_42571)->length;
    }
    else {
        _23959 = 1;
    }
    {
        object _i_46078;
        _i_46078 = 1;
L6: 
        if (_i_46078 > _23959){
            goto L7; // [350] 403
        }

        /** buildsys.e:751				if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _23960 = (object)*(((s1_ptr)_2)->base + _i_46078);
        _23961 = e_match_from(_23148, _23960, 1);
        _23960 = NOVALUE;
        if (_23961 == 0)
        {
            _23961 = NOVALUE;
            goto L8; // [370] 396
        }
        else{
            _23961 = NOVALUE;
        }

        /** buildsys.e:752					printf(fh, "\tdel \"%s\"" & HOSTNL, { generated_files[i] })*/
        Concat((object_ptr)&_23962, _23955, _46HOSTNL_21616);
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _23963 = (object)*(((s1_ptr)_2)->base + _i_46078);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_23963);
        ((intptr_t*)_2)[1] = _23963;
        _23964 = MAKE_SEQ(_1);
        _23963 = NOVALUE;
        EPrintf(_fh_45996, _23962, _23964);
        DeRefDS(_23962);
        _23962 = NOVALUE;
        DeRefDS(_23964);
        _23964 = NOVALUE;
L8: 

        /** buildsys.e:754			end for*/
        _i_46078 = _i_46078 + 1;
        goto L6; // [398] 357
L7: 
        ;
    }

    /** buildsys.e:755			puts(fh, HOSTNL)*/
    EPuts(_fh_45996, _46HOSTNL_21616); // DJP 

    /** buildsys.e:756			printf(fh, "%s-clean-all : .SYMBOLIC" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_23966, _23965, _46HOSTNL_21616);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_58file0_44535);
    ((intptr_t*)_2)[1] = _58file0_44535;
    _23967 = MAKE_SEQ(_1);
    EPrintf(_fh_45996, _23966, _23967);
    DeRefDS(_23966);
    _23966 = NOVALUE;
    DeRefDS(_23967);
    _23967 = NOVALUE;

    /** buildsys.e:757			printf(fh, "\tdel \"%s\"" & HOSTNL, { exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_23968, _23955, _46HOSTNL_21616);
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _23969 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23969);
    ((intptr_t*)_2)[1] = _23969;
    _23970 = MAKE_SEQ(_1);
    _23969 = NOVALUE;
    EPrintf(_fh_45996, _23968, _23970);
    DeRefDS(_23968);
    _23968 = NOVALUE;
    DeRefDS(_23970);
    _23970 = NOVALUE;

    /** buildsys.e:758			if length(res_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_56res_file_45408);
    _23971 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23971)){
            _23972 = SEQ_PTR(_23971)->length;
    }
    else {
        _23972 = 1;
    }
    _23971 = NOVALUE;
    if (_23972 == 0)
    {
        _23972 = NOVALUE;
        goto L9; // [465] 493
    }
    else{
        _23972 = NOVALUE;
    }

    /** buildsys.e:759				printf(fh, "\tdel \"%s\"" & HOSTNL, { res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_23973, _23955, _46HOSTNL_21616);
    _2 = (object)SEQ_PTR(_56res_file_45408);
    _23974 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23974);
    ((intptr_t*)_2)[1] = _23974;
    _23975 = MAKE_SEQ(_1);
    _23974 = NOVALUE;
    EPrintf(_fh_45996, _23973, _23975);
    DeRefDS(_23973);
    _23973 = NOVALUE;
    DeRefDS(_23975);
    _23975 = NOVALUE;
L9: 

    /** buildsys.e:761			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42571)){
            _23976 = SEQ_PTR(_58generated_files_42571)->length;
    }
    else {
        _23976 = 1;
    }
    {
        object _i_46111;
        _i_46111 = 1;
LA: 
        if (_i_46111 > _23976){
            goto LB; // [500] 536
        }

        /** buildsys.e:762				printf(fh, "\tdel \"%s\"" & HOSTNL, { generated_files[i] })*/
        Concat((object_ptr)&_23977, _23955, _46HOSTNL_21616);
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _23978 = (object)*(((s1_ptr)_2)->base + _i_46111);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_23978);
        ((intptr_t*)_2)[1] = _23978;
        _23979 = MAKE_SEQ(_1);
        _23978 = NOVALUE;
        EPrintf(_fh_45996, _23977, _23979);
        DeRefDS(_23977);
        _23977 = NOVALUE;
        DeRefDS(_23979);
        _23979 = NOVALUE;

        /** buildsys.e:763			end for*/
        _i_46111 = _i_46111 + 1;
        goto LA; // [531] 507
LB: 
        ;
    }

    /** buildsys.e:764			puts(fh, HOSTNL)*/
    EPuts(_fh_45996, _46HOSTNL_21616); // DJP 

    /** buildsys.e:765			puts(fh, ".c.obj : .autodepend" & HOSTNL)*/
    Concat((object_ptr)&_23981, _23980, _46HOSTNL_21616);
    EPuts(_fh_45996, _23981); // DJP 
    DeRefDS(_23981);
    _23981 = NOVALUE;

    /** buildsys.e:766			puts(fh, "\t$(CC) $(CFLAGS) $<" & HOSTNL)*/
    Concat((object_ptr)&_23983, _23982, _46HOSTNL_21616);
    EPuts(_fh_45996, _23983); // DJP 
    DeRefDS(_23983);
    _23983 = NOVALUE;

    /** buildsys.e:767			puts(fh, HOSTNL)*/
    EPuts(_fh_45996, _46HOSTNL_21616); // DJP 
    goto LC; // [572] 933
L3: 

    /** buildsys.e:770			printf(fh, "RUNTIME_LIBRARY=%s\n", { settings[SETUP_RUNTIME_LIBRARY] } )*/
    _2 = (object)SEQ_PTR(_settings_45993);
    _23985 = (object)*(((s1_ptr)_2)->base + 9);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23985);
    ((intptr_t*)_2)[1] = _23985;
    _23986 = MAKE_SEQ(_1);
    _23985 = NOVALUE;
    EPrintf(_fh_45996, _23984, _23986);
    DeRefDS(_23986);
    _23986 = NOVALUE;

    /** buildsys.e:771			printf(fh, "%s: $(%s_OBJECTS) $(RUNTIME_LIBRARY) %s " & HOSTNL, { adjust_for_build_file(exe_name[D_ALTNAME]), upper(file0), rc_file[D_ALTNAME] })*/
    Concat((object_ptr)&_23988, _23987, _46HOSTNL_21616);
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _23989 = (object)*(((s1_ptr)_2)->base + 11);
    Ref(_23989);
    _23990 = _56adjust_for_build_file(_23989);
    _23989 = NOVALUE;
    RefDS(_58file0_44535);
    _23991 = _14upper(_58file0_44535);
    _2 = (object)SEQ_PTR(_56rc_file_45402);
    _23992 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23990;
    ((intptr_t*)_2)[2] = _23991;
    Ref(_23992);
    ((intptr_t*)_2)[3] = _23992;
    _23993 = MAKE_SEQ(_1);
    _23992 = NOVALUE;
    _23991 = NOVALUE;
    _23990 = NOVALUE;
    EPrintf(_fh_45996, _23988, _23993);
    DeRefDS(_23988);
    _23988 = NOVALUE;
    DeRefDS(_23993);
    _23993 = NOVALUE;

    /** buildsys.e:772			if length(rc_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_56rc_file_45402);
    _23994 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23994)){
            _23995 = SEQ_PTR(_23994)->length;
    }
    else {
        _23995 = 1;
    }
    _23994 = NOVALUE;
    if (_23995 == 0)
    {
        _23995 = NOVALUE;
        goto LD; // [646] 690
    }
    else{
        _23995 = NOVALUE;
    }

    /** buildsys.e:773				writef(fh, "\t" & settings[SETUP_RC_COMPILER] & HOSTNL, { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_45993);
    _23996 = (object)*(((s1_ptr)_2)->base + 8);
    {
        object concat_list[3];

        concat_list[0] = _46HOSTNL_21616;
        concat_list[1] = _23996;
        concat_list[2] = _23943;
        Concat_N((object_ptr)&_23997, concat_list, 3);
    }
    _23996 = NOVALUE;
    _2 = (object)SEQ_PTR(_56rc_file_45402);
    _23998 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_56res_file_45408);
    _23999 = (object)*(((s1_ptr)_2)->base + 11);
    Ref(_23999);
    Ref(_23998);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _23998;
    ((intptr_t *)_2)[2] = _23999;
    _24000 = MAKE_SEQ(_1);
    _23999 = NOVALUE;
    _23998 = NOVALUE;
    _8writef(_fh_45996, _23997, _24000, 0);
    _23997 = NOVALUE;
    _24000 = NOVALUE;
LD: 

    /** buildsys.e:775			printf(fh, "\t$(LINKER) -o %s $(%s_OBJECTS) %s $(LFLAGS)" & HOSTNL, {*/
    Concat((object_ptr)&_24002, _24001, _46HOSTNL_21616);
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _24003 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_58file0_44535);
    _24004 = _14upper(_58file0_44535);
    _2 = (object)SEQ_PTR(_56res_file_45408);
    _24005 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24005)){
            _24006 = SEQ_PTR(_24005)->length;
    }
    else {
        _24006 = 1;
    }
    _24005 = NOVALUE;
    _2 = (object)SEQ_PTR(_56res_file_45408);
    _24007 = (object)*(((s1_ptr)_2)->base + 11);
    Ref(_24007);
    RefDS(_21997);
    _24008 = _57iif(_24006, _24007, _21997);
    _24006 = NOVALUE;
    _24007 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24003);
    ((intptr_t*)_2)[1] = _24003;
    ((intptr_t*)_2)[2] = _24004;
    ((intptr_t*)_2)[3] = _24008;
    _24009 = MAKE_SEQ(_1);
    _24008 = NOVALUE;
    _24004 = NOVALUE;
    _24003 = NOVALUE;
    EPrintf(_fh_45996, _24002, _24009);
    DeRefDS(_24002);
    _24002 = NOVALUE;
    DeRefDS(_24009);
    _24009 = NOVALUE;

    /** buildsys.e:777			puts(fh, HOSTNL)*/
    EPuts(_fh_45996, _46HOSTNL_21616); // DJP 

    /** buildsys.e:778			printf(fh, ".PHONY: %s-clean %s-clean-all" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_24011, _24010, _46HOSTNL_21616);
    RefDS(_58file0_44535);
    RefDS(_58file0_44535);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _58file0_44535;
    ((intptr_t *)_2)[2] = _58file0_44535;
    _24012 = MAKE_SEQ(_1);
    EPrintf(_fh_45996, _24011, _24012);
    DeRefDS(_24011);
    _24011 = NOVALUE;
    DeRefDS(_24012);
    _24012 = NOVALUE;

    /** buildsys.e:779			puts(fh, HOSTNL)*/
    EPuts(_fh_45996, _46HOSTNL_21616); // DJP 

    /** buildsys.e:780			printf(fh, "%s-clean:" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_24014, _24013, _46HOSTNL_21616);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_58file0_44535);
    ((intptr_t*)_2)[1] = _58file0_44535;
    _24015 = MAKE_SEQ(_1);
    EPrintf(_fh_45996, _24014, _24015);
    DeRefDS(_24014);
    _24014 = NOVALUE;
    DeRefDS(_24015);
    _24015 = NOVALUE;

    /** buildsys.e:781			printf(fh, "\trm -rf $(%s_OBJECTS) %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_24017, _24016, _46HOSTNL_21616);
    RefDS(_58file0_44535);
    _24018 = _14upper(_58file0_44535);
    _2 = (object)SEQ_PTR(_56res_file_45408);
    _24019 = (object)*(((s1_ptr)_2)->base + 11);
    Ref(_24019);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24018;
    ((intptr_t *)_2)[2] = _24019;
    _24020 = MAKE_SEQ(_1);
    _24019 = NOVALUE;
    _24018 = NOVALUE;
    EPrintf(_fh_45996, _24017, _24020);
    DeRefDS(_24017);
    _24017 = NOVALUE;
    DeRefDS(_24020);
    _24020 = NOVALUE;

    /** buildsys.e:782			puts(fh, HOSTNL)*/
    EPuts(_fh_45996, _46HOSTNL_21616); // DJP 

    /** buildsys.e:783			printf(fh, "%s-clean-all: %s-clean" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_24022, _24021, _46HOSTNL_21616);
    RefDS(_58file0_44535);
    RefDS(_58file0_44535);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _58file0_44535;
    ((intptr_t *)_2)[2] = _58file0_44535;
    _24023 = MAKE_SEQ(_1);
    EPrintf(_fh_45996, _24022, _24023);
    DeRefDS(_24022);
    _24022 = NOVALUE;
    DeRefDS(_24023);
    _24023 = NOVALUE;

    /** buildsys.e:784			printf(fh, "\trm -rf $(%s_SOURCES) %s %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_24025, _24024, _46HOSTNL_21616);
    RefDS(_58file0_44535);
    _24026 = _14upper(_58file0_44535);
    _2 = (object)SEQ_PTR(_56res_file_45408);
    _24027 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _24028 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24026;
    Ref(_24027);
    ((intptr_t*)_2)[2] = _24027;
    Ref(_24028);
    ((intptr_t*)_2)[3] = _24028;
    _24029 = MAKE_SEQ(_1);
    _24028 = NOVALUE;
    _24027 = NOVALUE;
    _24026 = NOVALUE;
    EPrintf(_fh_45996, _24025, _24029);
    DeRefDS(_24025);
    _24025 = NOVALUE;
    DeRefDS(_24029);
    _24029 = NOVALUE;

    /** buildsys.e:785			puts(fh, HOSTNL)*/
    EPuts(_fh_45996, _46HOSTNL_21616); // DJP 

    /** buildsys.e:786			puts(fh, "%.o: %.c" & HOSTNL)*/
    Concat((object_ptr)&_24031, _24030, _46HOSTNL_21616);
    EPuts(_fh_45996, _24031); // DJP 
    DeRefDS(_24031);
    _24031 = NOVALUE;

    /** buildsys.e:787			puts(fh, "\t$(CC) $(CFLAGS) $*.c -o $*.o" & HOSTNL)*/
    Concat((object_ptr)&_24033, _24032, _46HOSTNL_21616);
    EPuts(_fh_45996, _24033); // DJP 
    DeRefDS(_24033);
    _24033 = NOVALUE;

    /** buildsys.e:788			puts(fh, HOSTNL)*/
    EPuts(_fh_45996, _46HOSTNL_21616); // DJP 
LC: 

    /** buildsys.e:791		close(fh)*/
    EClose(_fh_45996);

    /** buildsys.e:792	end procedure*/
    DeRef(_settings_45993);
    _23953 = NOVALUE;
    _24005 = NOVALUE;
    _23971 = NOVALUE;
    _23941 = NOVALUE;
    _23994 = NOVALUE;
    _23938 = NOVALUE;
    return;
    ;
}


void _56write_makefile_partial()
{
    object _settings_46222 = NOVALUE;
    object _fh_46224 = NOVALUE;
    object _24035 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:798		sequence settings = setup_build()*/
    _0 = _settings_46222;
    _settings_46222 = _56setup_build();
    DeRef(_0);

    /** buildsys.e:799		integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _23909;
        concat_list[1] = _58file0_44535;
        concat_list[2] = _58output_dir_42581;
        Concat_N((object_ptr)&_24035, concat_list, 3);
    }
    _fh_46224 = EOpen(_24035, _23827, 0);
    DeRefDS(_24035);
    _24035 = NOVALUE;

    /** buildsys.e:801		write_makefile_srcobj_list(fh)*/
    _56write_makefile_srcobj_list(_fh_46224);

    /** buildsys.e:803		close(fh)*/
    EClose(_fh_46224);

    /** buildsys.e:804	end procedure*/
    DeRefDS(_settings_46222);
    return;
    ;
}


void _56build_direct(object _link_only_46231, object _the_file0_46232)
{
    object _cmd_46238 = NOVALUE;
    object _objs_46239 = NOVALUE;
    object _settings_46240 = NOVALUE;
    object _cwd_46242 = NOVALUE;
    object _status_46245 = NOVALUE;
    object _link_files_46276 = NOVALUE;
    object _pdone_46302 = NOVALUE;
    object _files_46353 = NOVALUE;
    object _31711 = NOVALUE;
    object _31710 = NOVALUE;
    object _31709 = NOVALUE;
    object _31708 = NOVALUE;
    object _31707 = NOVALUE;
    object _31706 = NOVALUE;
    object _31705 = NOVALUE;
    object _24183 = NOVALUE;
    object _24182 = NOVALUE;
    object _24180 = NOVALUE;
    object _24179 = NOVALUE;
    object _24178 = NOVALUE;
    object _24177 = NOVALUE;
    object _24176 = NOVALUE;
    object _24175 = NOVALUE;
    object _24174 = NOVALUE;
    object _24173 = NOVALUE;
    object _24171 = NOVALUE;
    object _24170 = NOVALUE;
    object _24169 = NOVALUE;
    object _24168 = NOVALUE;
    object _24164 = NOVALUE;
    object _24163 = NOVALUE;
    object _24162 = NOVALUE;
    object _24161 = NOVALUE;
    object _24160 = NOVALUE;
    object _24159 = NOVALUE;
    object _24158 = NOVALUE;
    object _24157 = NOVALUE;
    object _24156 = NOVALUE;
    object _24155 = NOVALUE;
    object _24154 = NOVALUE;
    object _24153 = NOVALUE;
    object _24152 = NOVALUE;
    object _24151 = NOVALUE;
    object _24150 = NOVALUE;
    object _24147 = NOVALUE;
    object _24146 = NOVALUE;
    object _24145 = NOVALUE;
    object _24144 = NOVALUE;
    object _24141 = NOVALUE;
    object _24139 = NOVALUE;
    object _24138 = NOVALUE;
    object _24137 = NOVALUE;
    object _24136 = NOVALUE;
    object _24135 = NOVALUE;
    object _24134 = NOVALUE;
    object _24131 = NOVALUE;
    object _24130 = NOVALUE;
    object _24126 = NOVALUE;
    object _24125 = NOVALUE;
    object _24124 = NOVALUE;
    object _24120 = NOVALUE;
    object _24119 = NOVALUE;
    object _24118 = NOVALUE;
    object _24117 = NOVALUE;
    object _24116 = NOVALUE;
    object _24115 = NOVALUE;
    object _24114 = NOVALUE;
    object _24113 = NOVALUE;
    object _24112 = NOVALUE;
    object _24111 = NOVALUE;
    object _24110 = NOVALUE;
    object _24109 = NOVALUE;
    object _24107 = NOVALUE;
    object _24106 = NOVALUE;
    object _24105 = NOVALUE;
    object _24104 = NOVALUE;
    object _24103 = NOVALUE;
    object _24101 = NOVALUE;
    object _24100 = NOVALUE;
    object _24099 = NOVALUE;
    object _24098 = NOVALUE;
    object _24097 = NOVALUE;
    object _24095 = NOVALUE;
    object _24093 = NOVALUE;
    object _24092 = NOVALUE;
    object _24091 = NOVALUE;
    object _24090 = NOVALUE;
    object _24088 = NOVALUE;
    object _24087 = NOVALUE;
    object _24086 = NOVALUE;
    object _24083 = NOVALUE;
    object _24082 = NOVALUE;
    object _24081 = NOVALUE;
    object _24080 = NOVALUE;
    object _24079 = NOVALUE;
    object _24078 = NOVALUE;
    object _24077 = NOVALUE;
    object _24076 = NOVALUE;
    object _24075 = NOVALUE;
    object _24074 = NOVALUE;
    object _24071 = NOVALUE;
    object _24070 = NOVALUE;
    object _24067 = NOVALUE;
    object _24065 = NOVALUE;
    object _24064 = NOVALUE;
    object _24063 = NOVALUE;
    object _24062 = NOVALUE;
    object _24059 = NOVALUE;
    object _24058 = NOVALUE;
    object _24057 = NOVALUE;
    object _24056 = NOVALUE;
    object _24054 = NOVALUE;
    object _24053 = NOVALUE;
    object _24052 = NOVALUE;
    object _24051 = NOVALUE;
    object _24050 = NOVALUE;
    object _24047 = NOVALUE;
    object _24041 = NOVALUE;
    object _24037 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:810		if length(the_file0) then*/
    if (IS_SEQUENCE(_the_file0_46232)){
            _24037 = SEQ_PTR(_the_file0_46232)->length;
    }
    else {
        _24037 = 1;
    }
    if (_24037 == 0)
    {
        _24037 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _24037 = NOVALUE;
    }

    /** buildsys.e:811			file0 = filebase(the_file0)*/
    RefDS(_the_file0_46232);
    _0 = _17filebase(_the_file0_46232);
    DeRef(_58file0_44535);
    _58file0_44535 = _0;
L1: 

    /** buildsys.e:813		sequence cmd, objs = "", settings = setup_build(), cwd = current_dir()*/
    RefDS(_21997);
    DeRef(_objs_46239);
    _objs_46239 = _21997;
    _0 = _settings_46240;
    _settings_46240 = _56setup_build();
    DeRef(_0);
    _0 = _cwd_46242;
    _cwd_46242 = _17current_dir();
    DeRef(_0);

    /** buildsys.e:814		integer status*/

    /** buildsys.e:816		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_46240);
    _24041 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_24041);
    _56ensure_exename(_24041);
    _24041 = NOVALUE;

    /** buildsys.e:818		if not link_only then*/
    if (_link_only_46231 != 0)
    goto L2; // [52] 124

    /** buildsys.e:819			switch compiler_type do*/
    _0 = _56compiler_type_45393;
    switch ( _0 ){ 

        /** buildsys.e:820				case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:821					if not silent then*/
        if (_36silent_21566 != 0)
        goto L3; // [72] 123

        /** buildsys.e:822						ShowMsg(1, COMPILING_WITH_1, {"GCC"})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24046);
        ((intptr_t*)_2)[1] = _24046;
        _24047 = MAKE_SEQ(_1);
        _39ShowMsg(1, 176, _24047, 1);
        _24047 = NOVALUE;
        goto L3; // [90] 123

        /** buildsys.e:825				case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:826					write_objlink_file()*/
        _56write_objlink_file();

        /** buildsys.e:828					if not silent then*/
        if (_36silent_21566 != 0)
        goto L4; // [104] 122

        /** buildsys.e:829						ShowMsg(1, COMPILING_WITH_1, {"Watcom"})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24049);
        ((intptr_t*)_2)[1] = _24049;
        _24050 = MAKE_SEQ(_1);
        _39ShowMsg(1, 176, _24050, 1);
        _24050 = NOVALUE;
L4: 
    ;}L3: 
L2: 

    /** buildsys.e:834		if sequence(output_dir) and length(output_dir) > 0 then*/
    _24051 = 1;
    if (_24051 == 0) {
        goto L5; // [131] 159
    }
    if (IS_SEQUENCE(_58output_dir_42581)){
            _24053 = SEQ_PTR(_58output_dir_42581)->length;
    }
    else {
        _24053 = 1;
    }
    _24054 = (_24053 > 0);
    _24053 = NOVALUE;
    if (_24054 == 0)
    {
        DeRef(_24054);
        _24054 = NOVALUE;
        goto L5; // [145] 159
    }
    else{
        DeRef(_24054);
        _24054 = NOVALUE;
    }

    /** buildsys.e:835			chdir(output_dir)*/
    RefDS(_58output_dir_42581);
    _31711 = _17chdir(_58output_dir_42581);
    DeRef(_31711);
    _31711 = NOVALUE;
L5: 

    /** buildsys.e:838		sequence link_files = {}*/
    RefDS(_21997);
    DeRef(_link_files_46276);
    _link_files_46276 = _21997;

    /** buildsys.e:840		if not link_only then*/
    if (_link_only_46231 != 0)
    goto L6; // [168] 482

    /** buildsys.e:841			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42571)){
            _24056 = SEQ_PTR(_58generated_files_42571)->length;
    }
    else {
        _24056 = 1;
    }
    {
        object _i_46280;
        _i_46280 = 1;
L7: 
        if (_i_46280 > _24056){
            goto L8; // [178] 479
        }

        /** buildsys.e:842				if generated_files[i][$] = 'c' then*/
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _24057 = (object)*(((s1_ptr)_2)->base + _i_46280);
        if (IS_SEQUENCE(_24057)){
                _24058 = SEQ_PTR(_24057)->length;
        }
        else {
            _24058 = 1;
        }
        _2 = (object)SEQ_PTR(_24057);
        _24059 = (object)*(((s1_ptr)_2)->base + _24058);
        _24057 = NOVALUE;
        if (binary_op_a(NOTEQ, _24059, 99)){
            _24059 = NOVALUE;
            goto L9; // [200] 438
        }
        _24059 = NOVALUE;

        /** buildsys.e:843					cmd = sprintf("%s %s %s", { settings[SETUP_CEXE], settings[SETUP_CFLAGS],*/
        _2 = (object)SEQ_PTR(_settings_46240);
        _24062 = (object)*(((s1_ptr)_2)->base + 1);
        _2 = (object)SEQ_PTR(_settings_46240);
        _24063 = (object)*(((s1_ptr)_2)->base + 2);
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _24064 = (object)*(((s1_ptr)_2)->base + _i_46280);
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_24062);
        ((intptr_t*)_2)[1] = _24062;
        Ref(_24063);
        ((intptr_t*)_2)[2] = _24063;
        RefDS(_24064);
        ((intptr_t*)_2)[3] = _24064;
        _24065 = MAKE_SEQ(_1);
        _24064 = NOVALUE;
        _24063 = NOVALUE;
        _24062 = NOVALUE;
        DeRef(_cmd_46238);
        _cmd_46238 = EPrintf(-9999999, _24061, _24065);
        DeRefDS(_24065);
        _24065 = NOVALUE;

        /** buildsys.e:846					link_files = append(link_files, generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _24067 = (object)*(((s1_ptr)_2)->base + _i_46280);
        RefDS(_24067);
        Append(&_link_files_46276, _link_files_46276, _24067);
        _24067 = NOVALUE;

        /** buildsys.e:848					if not silent then*/
        if (_36silent_21566 != 0)
        goto LA; // [246] 374

        /** buildsys.e:849						atom pdone = 100 * (i / length(generated_files))*/
        if (IS_SEQUENCE(_58generated_files_42571)){
                _24070 = SEQ_PTR(_58generated_files_42571)->length;
        }
        else {
            _24070 = 1;
        }
        _24071 = (_i_46280 % _24070) ? NewDouble((eudouble)_i_46280 / _24070) : (_i_46280 / _24070);
        _24070 = NOVALUE;
        DeRef(_pdone_46302);
        if (IS_ATOM_INT(_24071)) {
            if (_24071 <= INT15 && _24071 >= -INT15){
                _pdone_46302 = 100 * _24071;
            }
            else{
                _pdone_46302 = NewDouble(100 * (eudouble)_24071);
            }
        }
        else {
            _pdone_46302 = NewDouble((eudouble)100 * DBL_PTR(_24071)->dbl);
        }
        DeRef(_24071);
        _24071 = NOVALUE;

        /** buildsys.e:850						if not verbose then*/
        if (_36verbose_21569 != 0)
        goto LB; // [268] 358

        /** buildsys.e:853							if 0 and outdated_files[i] = 0 and force_build = 0 then*/
        if (0 == 0) {
            _24074 = 0;
            goto LC; // [273] 291
        }
        _2 = (object)SEQ_PTR(_58outdated_files_42572);
        _24075 = (object)*(((s1_ptr)_2)->base + _i_46280);
        if (IS_ATOM_INT(_24075)) {
            _24076 = (_24075 == 0);
        }
        else {
            _24076 = binary_op(EQUALS, _24075, 0);
        }
        _24075 = NOVALUE;
        if (IS_ATOM_INT(_24076))
        _24074 = (_24076 != 0);
        else
        _24074 = DBL_PTR(_24076)->dbl != 0.0;
LC: 
        if (_24074 == 0) {
            goto LD; // [291] 334
        }
        _24078 = (_56force_build_45415 == 0);
        if (_24078 == 0)
        {
            DeRef(_24078);
            _24078 = NOVALUE;
            goto LD; // [302] 334
        }
        else{
            DeRef(_24078);
            _24078 = NOVALUE;
        }

        /** buildsys.e:854								ShowMsg(1, SKIPPING__130_2_UPTODATE, { pdone, generated_files[i] })*/
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _24079 = (object)*(((s1_ptr)_2)->base + _i_46280);
        RefDS(_24079);
        Ref(_pdone_46302);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46302;
        ((intptr_t *)_2)[2] = _24079;
        _24080 = MAKE_SEQ(_1);
        _24079 = NOVALUE;
        _39ShowMsg(1, 325, _24080, 1);
        _24080 = NOVALUE;

        /** buildsys.e:855								continue*/
        DeRef(_pdone_46302);
        _pdone_46302 = NOVALUE;
        goto LE; // [329] 474
        goto LF; // [331] 373
LD: 

        /** buildsys.e:857								ShowMsg(1, COMPILING_130_2, { pdone, generated_files[i] })*/
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _24081 = (object)*(((s1_ptr)_2)->base + _i_46280);
        RefDS(_24081);
        Ref(_pdone_46302);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46302;
        ((intptr_t *)_2)[2] = _24081;
        _24082 = MAKE_SEQ(_1);
        _24081 = NOVALUE;
        _39ShowMsg(1, 163, _24082, 1);
        _24082 = NOVALUE;
        goto LF; // [355] 373
LB: 

        /** buildsys.e:860							ShowMsg(1, COMPILING_130_2, { pdone, cmd })*/
        RefDS(_cmd_46238);
        Ref(_pdone_46302);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46302;
        ((intptr_t *)_2)[2] = _cmd_46238;
        _24083 = MAKE_SEQ(_1);
        _39ShowMsg(1, 163, _24083, 1);
        _24083 = NOVALUE;
LF: 
LA: 
        DeRef(_pdone_46302);
        _pdone_46302 = NOVALUE;

        /** buildsys.e:865					status = system_exec(cmd, 0)*/
        _status_46245 = system_exec_call(_cmd_46238, 0);

        /** buildsys.e:866					if status != 0 then*/
        if (_status_46245 == 0)
        goto L10; // [384] 472

        /** buildsys.e:867						ShowMsg(2, COULDNT_COMPILE_FILE_1, { generated_files[i] })*/
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _24086 = (object)*(((s1_ptr)_2)->base + _i_46280);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24086);
        ((intptr_t*)_2)[1] = _24086;
        _24087 = MAKE_SEQ(_1);
        _24086 = NOVALUE;
        _39ShowMsg(2, 164, _24087, 1);
        _24087 = NOVALUE;

        /** buildsys.e:868						ShowMsg(2, STATUS_1_COMMAND_2, { status, cmd })*/
        RefDS(_cmd_46238);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _status_46245;
        ((intptr_t *)_2)[2] = _cmd_46238;
        _24088 = MAKE_SEQ(_1);
        _39ShowMsg(2, 165, _24088, 1);
        _24088 = NOVALUE;

        /** buildsys.e:869						goto "build_direct_cleanup"*/
        goto G11;
        goto L10; // [435] 472
L9: 

        /** buildsys.e:871				elsif match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _24090 = (object)*(((s1_ptr)_2)->base + _i_46280);
        _24091 = e_match_from(_23148, _24090, 1);
        _24090 = NOVALUE;
        if (_24091 == 0)
        {
            _24091 = NOVALUE;
            goto L12; // [451] 471
        }
        else{
            _24091 = NOVALUE;
        }

        /** buildsys.e:872					objs &= " " & generated_files[i]*/
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _24092 = (object)*(((s1_ptr)_2)->base + _i_46280);
        Concat((object_ptr)&_24093, _23388, _24092);
        _24092 = NOVALUE;
        Concat((object_ptr)&_objs_46239, _objs_46239, _24093);
        DeRefDS(_24093);
        _24093 = NOVALUE;
L12: 
L10: 

        /** buildsys.e:874			end for*/
LE: 
        _i_46280 = _i_46280 + 1;
        goto L7; // [474] 185
L8: 
        ;
    }
    goto L13; // [479] 541
L6: 

    /** buildsys.e:876			object files = read_lines(file0 & ".bld")*/
    Concat((object_ptr)&_24095, _58file0_44535, _23598);
    _0 = _files_46353;
    _files_46353 = _8read_lines(_24095);
    DeRef(_0);
    _24095 = NOVALUE;

    /** buildsys.e:877			for i = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_46353)){
            _24097 = SEQ_PTR(_files_46353)->length;
    }
    else {
        _24097 = 1;
    }
    {
        object _i_46359;
        _i_46359 = 1;
L14: 
        if (_i_46359 > _24097){
            goto L15; // [499] 538
        }

        /** buildsys.e:878				objs &= " " & filebase(files[i]) & "." & settings[SETUP_OBJ_EXT]*/
        _2 = (object)SEQ_PTR(_files_46353);
        _24098 = (object)*(((s1_ptr)_2)->base + _i_46359);
        Ref(_24098);
        _24099 = _17filebase(_24098);
        _24098 = NOVALUE;
        _2 = (object)SEQ_PTR(_settings_46240);
        _24100 = (object)*(((s1_ptr)_2)->base + 5);
        {
            object concat_list[4];

            concat_list[0] = _24100;
            concat_list[1] = _23187;
            concat_list[2] = _24099;
            concat_list[3] = _23388;
            Concat_N((object_ptr)&_24101, concat_list, 4);
        }
        _24100 = NOVALUE;
        DeRef(_24099);
        _24099 = NOVALUE;
        Concat((object_ptr)&_objs_46239, _objs_46239, _24101);
        DeRefDS(_24101);
        _24101 = NOVALUE;

        /** buildsys.e:879			end for*/
        _i_46359 = _i_46359 + 1;
        goto L14; // [533] 506
L15: 
        ;
    }
    DeRef(_files_46353);
    _files_46353 = NOVALUE;
L13: 

    /** buildsys.e:882		if keep and not link_only and length(link_files) then*/
    if (_58keep_42574 == 0) {
        _24103 = 0;
        goto L16; // [545] 556
    }
    _24104 = (_link_only_46231 == 0);
    _24103 = (_24104 != 0);
L16: 
    if (_24103 == 0) {
        goto L17; // [556] 585
    }
    if (IS_SEQUENCE(_link_files_46276)){
            _24106 = SEQ_PTR(_link_files_46276)->length;
    }
    else {
        _24106 = 1;
    }
    if (_24106 == 0)
    {
        _24106 = NOVALUE;
        goto L17; // [564] 585
    }
    else{
        _24106 = NOVALUE;
    }

    /** buildsys.e:883			write_lines(file0 & ".bld", link_files)*/
    Concat((object_ptr)&_24107, _58file0_44535, _23598);
    RefDS(_link_files_46276);
    _31710 = _8write_lines(_24107, _link_files_46276);
    _24107 = NOVALUE;
    DeRef(_31710);
    _31710 = NOVALUE;
    goto L18; // [582] 609
L17: 

    /** buildsys.e:884		elsif keep = 0 then*/
    if (_58keep_42574 != 0)
    goto L19; // [589] 608

    /** buildsys.e:886			delete_file(file0 & ".bld")*/
    Concat((object_ptr)&_24109, _58file0_44535, _23598);
    _31709 = _17delete_file(_24109);
    _24109 = NOVALUE;
    DeRef(_31709);
    _31709 = NOVALUE;
L19: 
L18: 

    /** buildsys.e:890		if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_GCC then*/
    _2 = (object)SEQ_PTR(_56rc_file_45402);
    _24110 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24110)){
            _24111 = SEQ_PTR(_24110)->length;
    }
    else {
        _24111 = 1;
    }
    _24110 = NOVALUE;
    if (_24111 == 0) {
        _24112 = 0;
        goto L1A; // [622] 637
    }
    _2 = (object)SEQ_PTR(_settings_46240);
    _24113 = (object)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_24113)){
            _24114 = SEQ_PTR(_24113)->length;
    }
    else {
        _24114 = 1;
    }
    _24113 = NOVALUE;
    _24112 = (_24114 != 0);
L1A: 
    if (_24112 == 0) {
        goto L1B; // [637] 742
    }
    _24116 = (_56compiler_type_45393 == 1);
    if (_24116 == 0)
    {
        DeRef(_24116);
        _24116 = NOVALUE;
        goto L1B; // [648] 742
    }
    else{
        DeRef(_24116);
        _24116 = NOVALUE;
    }

    /** buildsys.e:891			cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46240);
    _24117 = (object)*(((s1_ptr)_2)->base + 8);
    _2 = (object)SEQ_PTR(_56rc_file_45402);
    _24118 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_56res_file_45408);
    _24119 = (object)*(((s1_ptr)_2)->base + 11);
    Ref(_24119);
    Ref(_24118);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24118;
    ((intptr_t *)_2)[2] = _24119;
    _24120 = MAKE_SEQ(_1);
    _24119 = NOVALUE;
    _24118 = NOVALUE;
    Ref(_24117);
    _0 = _cmd_46238;
    _cmd_46238 = _14format(_24117, _24120);
    DeRef(_0);
    _24117 = NOVALUE;
    _24120 = NOVALUE;

    /** buildsys.e:892			status = system_exec(cmd, 0)*/
    _status_46245 = system_exec_call(_cmd_46238, 0);

    /** buildsys.e:893			if status != 0 then*/
    if (_status_46245 == 0)
    goto L1C; // [692] 741

    /** buildsys.e:894				ShowMsg(2, UNABLE_TO_COMPILE_RESOURCE_FILE_1, { rc_file[D_NAME] })*/
    _2 = (object)SEQ_PTR(_56rc_file_45402);
    _24124 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24124);
    ((intptr_t*)_2)[1] = _24124;
    _24125 = MAKE_SEQ(_1);
    _24124 = NOVALUE;
    _39ShowMsg(2, 350, _24125, 1);
    _24125 = NOVALUE;

    /** buildsys.e:895				ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46238);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46245;
    ((intptr_t *)_2)[2] = _cmd_46238;
    _24126 = MAKE_SEQ(_1);
    _39ShowMsg(2, 169, _24126, 1);
    _24126 = NOVALUE;

    /** buildsys.e:897				goto "build_direct_cleanup"*/
    goto G11;
L1C: 
L1B: 

    /** buildsys.e:901		switch compiler_type do*/
    _0 = _56compiler_type_45393;
    switch ( _0 ){ 

        /** buildsys.e:902			case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:903				cmd = sprintf("%s @%s.lnk", { settings[SETUP_LEXE], file0 })*/
        _2 = (object)SEQ_PTR(_settings_46240);
        _24130 = (object)*(((s1_ptr)_2)->base + 3);
        RefDS(_58file0_44535);
        Ref(_24130);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _24130;
        ((intptr_t *)_2)[2] = _58file0_44535;
        _24131 = MAKE_SEQ(_1);
        _24130 = NOVALUE;
        DeRef(_cmd_46238);
        _cmd_46238 = EPrintf(-9999999, _24129, _24131);
        DeRefDS(_24131);
        _24131 = NOVALUE;
        goto L1D; // [771] 848

        /** buildsys.e:905			case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:906				cmd = sprintf("%s -o %s %s %s %s", { */
        _2 = (object)SEQ_PTR(_settings_46240);
        _24134 = (object)*(((s1_ptr)_2)->base + 3);
        _2 = (object)SEQ_PTR(_56exe_name_45396);
        _24135 = (object)*(((s1_ptr)_2)->base + 11);
        Ref(_24135);
        _24136 = _56adjust_for_build_file(_24135);
        _24135 = NOVALUE;
        _2 = (object)SEQ_PTR(_56res_file_45408);
        _24137 = (object)*(((s1_ptr)_2)->base + 11);
        _2 = (object)SEQ_PTR(_settings_46240);
        _24138 = (object)*(((s1_ptr)_2)->base + 4);
        _1 = NewS1(5);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_24134);
        ((intptr_t*)_2)[1] = _24134;
        ((intptr_t*)_2)[2] = _24136;
        RefDS(_objs_46239);
        ((intptr_t*)_2)[3] = _objs_46239;
        Ref(_24137);
        ((intptr_t*)_2)[4] = _24137;
        Ref(_24138);
        ((intptr_t*)_2)[5] = _24138;
        _24139 = MAKE_SEQ(_1);
        _24138 = NOVALUE;
        _24137 = NOVALUE;
        _24136 = NOVALUE;
        _24134 = NOVALUE;
        DeRef(_cmd_46238);
        _cmd_46238 = EPrintf(-9999999, _24133, _24139);
        DeRefDS(_24139);
        _24139 = NOVALUE;
        goto L1D; // [819] 848

        /** buildsys.e:915			case else*/
        default:

        /** buildsys.e:916				ShowMsg(2, UNKNOWN_COMPILER_TYPE_1, { compiler_type })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _56compiler_type_45393;
        _24141 = MAKE_SEQ(_1);
        _39ShowMsg(2, 167, _24141, 1);
        _24141 = NOVALUE;

        /** buildsys.e:918				goto "build_direct_cleanup"*/
        goto G11;
    ;}L1D: 

    /** buildsys.e:921		if not silent then*/
    if (_36silent_21566 != 0)
    goto L1E; // [852] 910

    /** buildsys.e:922			if not verbose then*/
    if (_36verbose_21569 != 0)
    goto L1F; // [859] 892

    /** buildsys.e:923				ShowMsg(1, LINKING_100_1, { abbreviate_path(exe_name[D_NAME]) })*/
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _24144 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_24144);
    RefDS(_21997);
    _24145 = _17abbreviate_path(_24144, _21997);
    _24144 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24145;
    _24146 = MAKE_SEQ(_1);
    _24145 = NOVALUE;
    _39ShowMsg(1, 166, _24146, 1);
    _24146 = NOVALUE;
    goto L20; // [889] 909
L1F: 

    /** buildsys.e:925				ShowMsg(1, LINKING_100_1, { cmd })*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_cmd_46238);
    ((intptr_t*)_2)[1] = _cmd_46238;
    _24147 = MAKE_SEQ(_1);
    _39ShowMsg(1, 166, _24147, 1);
    _24147 = NOVALUE;
L20: 
L1E: 

    /** buildsys.e:929		status = system_exec(cmd, 0)*/
    _status_46245 = system_exec_call(_cmd_46238, 0);

    /** buildsys.e:930		if status != 0 then*/
    if (_status_46245 == 0)
    goto L21; // [920] 967

    /** buildsys.e:931			ShowMsg(2, UNABLE_TO_LINK_1, { exe_name[D_NAME] })*/
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _24150 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24150);
    ((intptr_t*)_2)[1] = _24150;
    _24151 = MAKE_SEQ(_1);
    _24150 = NOVALUE;
    _39ShowMsg(2, 168, _24151, 1);
    _24151 = NOVALUE;

    /** buildsys.e:932			ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46238);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46245;
    ((intptr_t *)_2)[2] = _cmd_46238;
    _24152 = MAKE_SEQ(_1);
    _39ShowMsg(2, 169, _24152, 1);
    _24152 = NOVALUE;

    /** buildsys.e:934			goto "build_direct_cleanup"*/
    goto G11;
L21: 

    /** buildsys.e:938		if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_WATCOM then*/
    _2 = (object)SEQ_PTR(_56rc_file_45402);
    _24153 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24153)){
            _24154 = SEQ_PTR(_24153)->length;
    }
    else {
        _24154 = 1;
    }
    _24153 = NOVALUE;
    if (_24154 == 0) {
        _24155 = 0;
        goto L22; // [980] 995
    }
    _2 = (object)SEQ_PTR(_settings_46240);
    _24156 = (object)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_24156)){
            _24157 = SEQ_PTR(_24156)->length;
    }
    else {
        _24157 = 1;
    }
    _24156 = NOVALUE;
    _24155 = (_24157 != 0);
L22: 
    if (_24155 == 0) {
        goto L23; // [995] 1118
    }
    _24159 = (_56compiler_type_45393 == 2);
    if (_24159 == 0)
    {
        DeRef(_24159);
        _24159 = NOVALUE;
        goto L23; // [1006] 1118
    }
    else{
        DeRef(_24159);
        _24159 = NOVALUE;
    }

    /** buildsys.e:939			cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46240);
    _24160 = (object)*(((s1_ptr)_2)->base + 8);
    _2 = (object)SEQ_PTR(_56rc_file_45402);
    _24161 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_56res_file_45408);
    _24162 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _24163 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24161);
    ((intptr_t*)_2)[1] = _24161;
    Ref(_24162);
    ((intptr_t*)_2)[2] = _24162;
    Ref(_24163);
    ((intptr_t*)_2)[3] = _24163;
    _24164 = MAKE_SEQ(_1);
    _24163 = NOVALUE;
    _24162 = NOVALUE;
    _24161 = NOVALUE;
    Ref(_24160);
    _0 = _cmd_46238;
    _cmd_46238 = _14format(_24160, _24164);
    DeRef(_0);
    _24160 = NOVALUE;
    _24164 = NOVALUE;

    /** buildsys.e:940			status = system_exec(cmd, 0)*/
    _status_46245 = system_exec_call(_cmd_46238, 0);

    /** buildsys.e:941			if status != 0 then*/
    if (_status_46245 == 0)
    goto L24; // [1060] 1117

    /** buildsys.e:942				ShowMsg(2, UNABLE_TO_LINK_RESOURCE_FILE_1_INTO_EXECUTABLE_2, { rc_file[D_NAME], exe_name[D_NAME] })*/
    _2 = (object)SEQ_PTR(_56rc_file_45402);
    _24168 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _24169 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_24169);
    Ref(_24168);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24168;
    ((intptr_t *)_2)[2] = _24169;
    _24170 = MAKE_SEQ(_1);
    _24169 = NOVALUE;
    _24168 = NOVALUE;
    _39ShowMsg(2, 187, _24170, 1);
    _24170 = NOVALUE;

    /** buildsys.e:943				ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46238);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46245;
    ((intptr_t *)_2)[2] = _cmd_46238;
    _24171 = MAKE_SEQ(_1);
    _39ShowMsg(2, 169, _24171, 1);
    _24171 = NOVALUE;

    /** buildsys.e:945				goto "build_direct_cleanup"*/
    goto G11;
L24: 
L23: 

    /** buildsys.e:949	label "build_direct_cleanup"*/
G11:

    /** buildsys.e:950		if keep = 0 then*/
    if (_58keep_42574 != 0)
    goto L25; // [1126] 1277

    /** buildsys.e:951			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42571)){
            _24173 = SEQ_PTR(_58generated_files_42571)->length;
    }
    else {
        _24173 = 1;
    }
    {
        object _i_46495;
        _i_46495 = 1;
L26: 
        if (_i_46495 > _24173){
            goto L27; // [1137] 1193
        }

        /** buildsys.e:952				if verbose then*/
        if (_36verbose_21569 == 0)
        {
            goto L28; // [1148] 1172
        }
        else{
        }

        /** buildsys.e:953					ShowMsg(1, DELETING_1, { generated_files[i] })*/
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _24174 = (object)*(((s1_ptr)_2)->base + _i_46495);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24174);
        ((intptr_t*)_2)[1] = _24174;
        _24175 = MAKE_SEQ(_1);
        _24174 = NOVALUE;
        _39ShowMsg(1, 347, _24175, 1);
        _24175 = NOVALUE;
L28: 

        /** buildsys.e:955				delete_file(generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42571);
        _24176 = (object)*(((s1_ptr)_2)->base + _i_46495);
        RefDS(_24176);
        _31708 = _17delete_file(_24176);
        _24176 = NOVALUE;
        DeRef(_31708);
        _31708 = NOVALUE;

        /** buildsys.e:956			end for*/
        _i_46495 = _i_46495 + 1;
        goto L26; // [1188] 1144
L27: 
        ;
    }

    /** buildsys.e:958			if length(res_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_56res_file_45408);
    _24177 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24177)){
            _24178 = SEQ_PTR(_24177)->length;
    }
    else {
        _24178 = 1;
    }
    _24177 = NOVALUE;
    if (_24178 == 0)
    {
        _24178 = NOVALUE;
        goto L29; // [1206] 1226
    }
    else{
        _24178 = NOVALUE;
    }

    /** buildsys.e:959				delete_file(res_file[D_ALTNAME])*/
    _2 = (object)SEQ_PTR(_56res_file_45408);
    _24179 = (object)*(((s1_ptr)_2)->base + 11);
    Ref(_24179);
    _31707 = _17delete_file(_24179);
    _24179 = NOVALUE;
    DeRef(_31707);
    _31707 = NOVALUE;
L29: 

    /** buildsys.e:962			if remove_output_dir then*/
    if (_56remove_output_dir_45416 == 0)
    {
        goto L2A; // [1230] 1276
    }
    else{
    }

    /** buildsys.e:963				chdir(cwd)*/
    RefDS(_cwd_46242);
    _31706 = _17chdir(_cwd_46242);
    DeRef(_31706);
    _31706 = NOVALUE;

    /** buildsys.e:966				if not remove_directory(output_dir) then*/
    RefDS(_58output_dir_42581);
    _24180 = _17remove_directory(_58output_dir_42581, 0);
    if (IS_ATOM_INT(_24180)) {
        if (_24180 != 0){
            DeRef(_24180);
            _24180 = NOVALUE;
            goto L2B; // [1250] 1275
        }
    }
    else {
        if (DBL_PTR(_24180)->dbl != 0.0){
            DeRef(_24180);
            _24180 = NOVALUE;
            goto L2B; // [1250] 1275
        }
    }
    DeRef(_24180);
    _24180 = NOVALUE;

    /** buildsys.e:967					ShowMsg(2, COULD_NOT_REMOVE_DIRECTORY_1, { abbreviate_path(output_dir) })*/
    RefDS(_58output_dir_42581);
    RefDS(_21997);
    _24182 = _17abbreviate_path(_58output_dir_42581, _21997);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24182;
    _24183 = MAKE_SEQ(_1);
    _24182 = NOVALUE;
    _39ShowMsg(2, 194, _24183, 1);
    _24183 = NOVALUE;
L2B: 
L2A: 
L25: 

    /** buildsys.e:972		chdir(cwd)*/
    RefDS(_cwd_46242);
    _31705 = _17chdir(_cwd_46242);
    DeRef(_31705);
    _31705 = NOVALUE;

    /** buildsys.e:973	end procedure*/
    DeRefDS(_the_file0_46232);
    DeRef(_cmd_46238);
    DeRef(_objs_46239);
    DeRef(_settings_46240);
    DeRefDS(_cwd_46242);
    DeRef(_link_files_46276);
    _24156 = NOVALUE;
    _24153 = NOVALUE;
    _24177 = NOVALUE;
    DeRef(_24104);
    _24104 = NOVALUE;
    _24113 = NOVALUE;
    DeRef(_24076);
    _24076 = NOVALUE;
    _24110 = NOVALUE;
    return;
    ;
}


void _56write_buildfile()
{
    object _make_command_46537 = NOVALUE;
    object _settings_46582 = NOVALUE;
    object _24206 = NOVALUE;
    object _24205 = NOVALUE;
    object _24201 = NOVALUE;
    object _24200 = NOVALUE;
    object _24199 = NOVALUE;
    object _24197 = NOVALUE;
    object _24196 = NOVALUE;
    object _24195 = NOVALUE;
    object _24194 = NOVALUE;
    object _24193 = NOVALUE;
    object _24192 = NOVALUE;
    object _24191 = NOVALUE;
    object _24190 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:982		switch build_system_type do*/
    _0 = _56build_system_type_45389;
    switch ( _0 ){ 

        /** buildsys.e:983			case BUILD_MAKEFILE_FULL then*/
        case 2:

        /** buildsys.e:984				write_makefile_full()*/
        _56write_makefile_full();

        /** buildsys.e:986				if not silent then*/
        if (_36silent_21566 != 0)
        goto L1; // [22] 142

        /** buildsys.e:987					sequence make_command*/

        /** buildsys.e:988					if compiler_type = COMPILER_WATCOM then*/
        if (_56compiler_type_45393 != 2)
        goto L2; // [31] 45

        /** buildsys.e:989						make_command = "wmake /f "*/
        RefDS(_24188);
        DeRefi(_make_command_46537);
        _make_command_46537 = _24188;
        goto L3; // [42] 53
L2: 

        /** buildsys.e:991						make_command = "make -f "*/
        RefDS(_24189);
        DeRefi(_make_command_46537);
        _make_command_46537 = _24189;
L3: 

        /** buildsys.e:994					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24190 = _36cfile_count_21529 + 2;
        if ((object)((uintptr_t)_24190 + (uintptr_t)HIGH_BITS) >= 0){
            _24190 = NewDouble((eudouble)_24190);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24190;
        _24191 = MAKE_SEQ(_1);
        _24190 = NOVALUE;
        _39ShowMsg(1, 170, _24191, 1);
        _24191 = NOVALUE;

        /** buildsys.e:996					if sequence(output_dir) and length(output_dir) > 0 then*/
        _24192 = 1;
        if (_24192 == 0) {
            goto L4; // [80] 122
        }
        if (IS_SEQUENCE(_58output_dir_42581)){
                _24194 = SEQ_PTR(_58output_dir_42581)->length;
        }
        else {
            _24194 = 1;
        }
        _24195 = (_24194 > 0);
        _24194 = NOVALUE;
        if (_24195 == 0)
        {
            DeRef(_24195);
            _24195 = NOVALUE;
            goto L4; // [94] 122
        }
        else{
            DeRef(_24195);
            _24195 = NOVALUE;
        }

        /** buildsys.e:997						ShowMsg(1, TO_BUILD_YOUR_PROJECT_CHANGE_DIRECTORY_TO_1_AND_TYPE_23MAK, { output_dir, make_command, file0 })*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_58output_dir_42581);
        ((intptr_t*)_2)[1] = _58output_dir_42581;
        RefDS(_make_command_46537);
        ((intptr_t*)_2)[2] = _make_command_46537;
        RefDS(_58file0_44535);
        ((intptr_t*)_2)[3] = _58file0_44535;
        _24196 = MAKE_SEQ(_1);
        _39ShowMsg(1, 174, _24196, 1);
        _24196 = NOVALUE;
        goto L5; // [119] 141
L4: 

        /** buildsys.e:999						ShowMsg(1, TO_BUILD_YOUR_PROJECT_TYPE_12MAK, { make_command, file0 })*/
        RefDS(_58file0_44535);
        RefDS(_make_command_46537);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _make_command_46537;
        ((intptr_t *)_2)[2] = _58file0_44535;
        _24197 = MAKE_SEQ(_1);
        _39ShowMsg(1, 172, _24197, 1);
        _24197 = NOVALUE;
L5: 
L1: 
        DeRefi(_make_command_46537);
        _make_command_46537 = NOVALUE;
        goto L6; // [144] 277

        /** buildsys.e:1003			case BUILD_MAKEFILE_PARTIAL then*/
        case 1:

        /** buildsys.e:1004				write_makefile_partial()*/
        _56write_makefile_partial();

        /** buildsys.e:1006				if not silent then*/
        if (_36silent_21566 != 0)
        goto L6; // [158] 277

        /** buildsys.e:1007					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24199 = _36cfile_count_21529 + 2;
        if ((object)((uintptr_t)_24199 + (uintptr_t)HIGH_BITS) >= 0){
            _24199 = NewDouble((eudouble)_24199);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24199;
        _24200 = MAKE_SEQ(_1);
        _24199 = NOVALUE;
        _39ShowMsg(1, 170, _24200, 1);
        _24200 = NOVALUE;

        /** buildsys.e:1008					ShowMsg(1, TO_BUILD_YOUR_PROJECT_INCLUDE_1MAK_INTO_A_LARGER_MAKEFILE_PROJECT, { file0 })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_58file0_44535);
        ((intptr_t*)_2)[1] = _58file0_44535;
        _24201 = MAKE_SEQ(_1);
        _39ShowMsg(1, 173, _24201, 1);
        _24201 = NOVALUE;
        goto L6; // [198] 277

        /** buildsys.e:1011			case BUILD_DIRECT then*/
        case 3:

        /** buildsys.e:1012				build_direct()*/
        RefDS(_21997);
        _56build_direct(0, _21997);

        /** buildsys.e:1014				if not silent then*/
        if (_36silent_21566 != 0)
        goto L7; // [214] 225

        /** buildsys.e:1015					sequence settings = setup_build()*/
        _0 = _settings_46582;
        _settings_46582 = _56setup_build();
        DeRef(_0);
L7: 
        DeRef(_settings_46582);
        _settings_46582 = NOVALUE;
        goto L6; // [227] 277

        /** buildsys.e:1019			case BUILD_NONE then*/
        case 0:

        /** buildsys.e:1020				if not silent then*/
        if (_36silent_21566 != 0)
        goto L6; // [237] 277

        /** buildsys.e:1021					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24205 = _36cfile_count_21529 + 2;
        if ((object)((uintptr_t)_24205 + (uintptr_t)HIGH_BITS) >= 0){
            _24205 = NewDouble((eudouble)_24205);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24205;
        _24206 = MAKE_SEQ(_1);
        _24205 = NOVALUE;
        _39ShowMsg(1, 170, _24206, 1);
        _24206 = NOVALUE;
        goto L6; // [261] 277

        /** buildsys.e:1026			case else*/
        default:

        /** buildsys.e:1027				CompileErr(UNKNOWN_BUILD_FILE_TYPE)*/
        RefDS(_21997);
        _50CompileErr(151, _21997, 0);
    ;}L6: 

    /** buildsys.e:1029	end procedure*/
    return;
    ;
}



// 0xB9E00832
