// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _52new(object _pattern_22169, object _options_22170)
{
    object _12522 = NOVALUE;
    object _12521 = NOVALUE;
    object _12519 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:723		if sequence(options) then */
    _12519 = 0;
    if (_12519 == 0)
    {
        _12519 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _12519 = NOVALUE;
    }

    /** regex.e:724			options = math:or_all(options) */
    _options_22170 = _20or_all(_options_22170);
L1: 

    /** regex.e:730		return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_options_22170);
    Ref(_pattern_22169);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _pattern_22169;
    ((intptr_t *)_2)[2] = _options_22170;
    _12521 = MAKE_SEQ(_1);
    _12522 = machine(68, _12521);
    DeRefDS(_12521);
    _12521 = NOVALUE;
    DeRefi(_pattern_22169);
    DeRef(_options_22170);
    return _12522;
    ;
}


object _52get_ovector_size(object _ex_22189, object _maxsize_22190)
{
    object _m_22191 = NOVALUE;
    object _12530 = NOVALUE;
    object _12527 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:804		integer m = machine_func(M_PCRE_GET_OVECTOR_SIZE, {ex})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_ex_22189);
    ((intptr_t*)_2)[1] = _ex_22189;
    _12527 = MAKE_SEQ(_1);
    _m_22191 = machine(97, _12527);
    DeRefDS(_12527);
    _12527 = NOVALUE;
    if (!IS_ATOM_INT(_m_22191)) {
        _1 = (object)(DBL_PTR(_m_22191)->dbl);
        DeRefDS(_m_22191);
        _m_22191 = _1;
    }

    /** regex.e:805		if (m > maxsize) then*/
    if (_m_22191 <= 30)
    goto L1; // [17] 28

    /** regex.e:806			return maxsize*/
    DeRef(_ex_22189);
    return 30;
L1: 

    /** regex.e:809		return m+1*/
    _12530 = _m_22191 + 1;
    if (_12530 > MAXINT){
        _12530 = NewDouble((eudouble)_12530);
    }
    DeRef(_ex_22189);
    return _12530;
    ;
}


object _52find(object _re_22199, object _haystack_22201, object _from_22202, object _options_22203, object _size_22204)
{
    object _12537 = NOVALUE;
    object _12536 = NOVALUE;
    object _12535 = NOVALUE;
    object _12532 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_22204)) {
        _1 = (object)(DBL_PTR(_size_22204)->dbl);
        DeRefDS(_size_22204);
        _size_22204 = _1;
    }

    /** regex.e:872		if sequence(options) then */
    _12532 = IS_SEQUENCE(_options_22203);
    if (_12532 == 0)
    {
        _12532 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12532 = NOVALUE;
    }

    /** regex.e:873			options = math:or_all(options) */
    Ref(_options_22203);
    _0 = _options_22203;
    _options_22203 = _20or_all(_options_22203);
    DeRef(_0);
L1: 

    /** regex.e:876		if size < 0 then*/
    if (_size_22204 >= 0)
    goto L2; // [22] 32

    /** regex.e:877			size = 0*/
    _size_22204 = 0;
L2: 

    /** regex.e:880		return machine_func(M_PCRE_EXEC, { re, haystack, length(haystack), options, from, size })*/
    if (IS_SEQUENCE(_haystack_22201)){
            _12535 = SEQ_PTR(_haystack_22201)->length;
    }
    else {
        _12535 = 1;
    }
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_re_22199);
    ((intptr_t*)_2)[1] = _re_22199;
    Ref(_haystack_22201);
    ((intptr_t*)_2)[2] = _haystack_22201;
    ((intptr_t*)_2)[3] = _12535;
    Ref(_options_22203);
    ((intptr_t*)_2)[4] = _options_22203;
    ((intptr_t*)_2)[5] = _from_22202;
    ((intptr_t*)_2)[6] = _size_22204;
    _12536 = MAKE_SEQ(_1);
    _12535 = NOVALUE;
    _12537 = machine(70, _12536);
    DeRefDS(_12536);
    _12536 = NOVALUE;
    DeRef(_re_22199);
    DeRef(_haystack_22201);
    DeRef(_options_22203);
    return _12537;
    ;
}


object _52matches(object _re_22279, object _haystack_22281, object _from_22282, object _options_22283)
{
    object _str_offsets_22287 = NOVALUE;
    object _match_data_22289 = NOVALUE;
    object _tmp_22299 = NOVALUE;
    object _12591 = NOVALUE;
    object _12590 = NOVALUE;
    object _12589 = NOVALUE;
    object _12588 = NOVALUE;
    object _12587 = NOVALUE;
    object _12585 = NOVALUE;
    object _12584 = NOVALUE;
    object _12583 = NOVALUE;
    object _12582 = NOVALUE;
    object _12580 = NOVALUE;
    object _12579 = NOVALUE;
    object _12578 = NOVALUE;
    object _12577 = NOVALUE;
    object _12575 = NOVALUE;
    object _12574 = NOVALUE;
    object _12573 = NOVALUE;
    object _12570 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:1038		if sequence(options) then */
    _12570 = 0;
    if (_12570 == 0)
    {
        _12570 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _12570 = NOVALUE;
    }

    /** regex.e:1039			options = math:or_all(options) */
    _options_22283 = _20or_all(0);
L1: 

    /** regex.e:1041		integer str_offsets = and_bits(STRING_OFFSETS, options)*/
    if (IS_ATOM_INT(_options_22283)) {
        {uintptr_t tu;
             tu = (uintptr_t)201326592 & (uintptr_t)_options_22283;
             _str_offsets_22287 = MAKE_UINT(tu);
        }
    }
    else {
        _str_offsets_22287 = binary_op(AND_BITS, 201326592, _options_22283);
    }
    if (!IS_ATOM_INT(_str_offsets_22287)) {
        _1 = (object)(DBL_PTR(_str_offsets_22287)->dbl);
        DeRefDS(_str_offsets_22287);
        _str_offsets_22287 = _1;
    }

    /** regex.e:1042		object match_data = find(re, haystack, from, and_bits(options, not_bits(STRING_OFFSETS)))*/
    _12573 = not_bits(201326592);
    if (IS_ATOM_INT(_options_22283) && IS_ATOM_INT(_12573)) {
        {uintptr_t tu;
             tu = (uintptr_t)_options_22283 & (uintptr_t)_12573;
             _12574 = MAKE_UINT(tu);
        }
    }
    else {
        _12574 = binary_op(AND_BITS, _options_22283, _12573);
    }
    DeRef(_12573);
    _12573 = NOVALUE;
    Ref(_re_22279);
    _12575 = _52get_ovector_size(_re_22279, 30);
    Ref(_re_22279);
    Ref(_haystack_22281);
    _0 = _match_data_22289;
    _match_data_22289 = _52find(_re_22279, _haystack_22281, _from_22282, _12574, _12575);
    DeRef(_0);
    _12574 = NOVALUE;
    _12575 = NOVALUE;

    /** regex.e:1044		if atom(match_data) then */
    _12577 = IS_ATOM(_match_data_22289);
    if (_12577 == 0)
    {
        _12577 = NOVALUE;
        goto L2; // [53] 63
    }
    else{
        _12577 = NOVALUE;
    }

    /** regex.e:1045			return ERROR_NOMATCH */
    DeRef(_re_22279);
    DeRef(_haystack_22281);
    DeRef(_options_22283);
    DeRef(_match_data_22289);
    return -1;
L2: 

    /** regex.e:1048		for i = 1 to length(match_data) do*/
    if (IS_SEQUENCE(_match_data_22289)){
            _12578 = SEQ_PTR(_match_data_22289)->length;
    }
    else {
        _12578 = 1;
    }
    {
        object _i_22297;
        _i_22297 = 1;
L3: 
        if (_i_22297 > _12578){
            goto L4; // [68] 181
        }

        /** regex.e:1049			sequence tmp*/

        /** regex.e:1050			if match_data[i][1] = 0 then*/
        _2 = (object)SEQ_PTR(_match_data_22289);
        _12579 = (object)*(((s1_ptr)_2)->base + _i_22297);
        _2 = (object)SEQ_PTR(_12579);
        _12580 = (object)*(((s1_ptr)_2)->base + 1);
        _12579 = NOVALUE;
        if (binary_op_a(NOTEQ, _12580, 0)){
            _12580 = NOVALUE;
            goto L5; // [87] 101
        }
        _12580 = NOVALUE;

        /** regex.e:1051				tmp = ""*/
        RefDS(_5);
        DeRef(_tmp_22299);
        _tmp_22299 = _5;
        goto L6; // [98] 125
L5: 

        /** regex.e:1053				tmp = haystack[match_data[i][1]..match_data[i][2]]*/
        _2 = (object)SEQ_PTR(_match_data_22289);
        _12582 = (object)*(((s1_ptr)_2)->base + _i_22297);
        _2 = (object)SEQ_PTR(_12582);
        _12583 = (object)*(((s1_ptr)_2)->base + 1);
        _12582 = NOVALUE;
        _2 = (object)SEQ_PTR(_match_data_22289);
        _12584 = (object)*(((s1_ptr)_2)->base + _i_22297);
        _2 = (object)SEQ_PTR(_12584);
        _12585 = (object)*(((s1_ptr)_2)->base + 2);
        _12584 = NOVALUE;
        rhs_slice_target = (object_ptr)&_tmp_22299;
        RHS_Slice(_haystack_22281, _12583, _12585);
L6: 

        /** regex.e:1055			if str_offsets then*/
        if (_str_offsets_22287 == 0)
        {
            goto L7; // [127] 163
        }
        else{
        }

        /** regex.e:1056				match_data[i] = { tmp, match_data[i][1], match_data[i][2] }*/
        _2 = (object)SEQ_PTR(_match_data_22289);
        _12587 = (object)*(((s1_ptr)_2)->base + _i_22297);
        _2 = (object)SEQ_PTR(_12587);
        _12588 = (object)*(((s1_ptr)_2)->base + 1);
        _12587 = NOVALUE;
        _2 = (object)SEQ_PTR(_match_data_22289);
        _12589 = (object)*(((s1_ptr)_2)->base + _i_22297);
        _2 = (object)SEQ_PTR(_12589);
        _12590 = (object)*(((s1_ptr)_2)->base + 2);
        _12589 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_tmp_22299);
        ((intptr_t*)_2)[1] = _tmp_22299;
        Ref(_12588);
        ((intptr_t*)_2)[2] = _12588;
        Ref(_12590);
        ((intptr_t*)_2)[3] = _12590;
        _12591 = MAKE_SEQ(_1);
        _12590 = NOVALUE;
        _12588 = NOVALUE;
        _2 = (object)SEQ_PTR(_match_data_22289);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _match_data_22289 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_22297);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _12591;
        if( _1 != _12591 ){
            DeRef(_1);
        }
        _12591 = NOVALUE;
        goto L8; // [160] 172
L7: 

        /** regex.e:1058				match_data[i] = tmp*/
        RefDS(_tmp_22299);
        _2 = (object)SEQ_PTR(_match_data_22289);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _match_data_22289 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_22297);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tmp_22299;
        DeRef(_1);
L8: 
        DeRef(_tmp_22299);
        _tmp_22299 = NOVALUE;

        /** regex.e:1060		end for*/
        _i_22297 = _i_22297 + 1;
        goto L3; // [176] 75
L4: 
        ;
    }

    /** regex.e:1062		return match_data*/
    DeRef(_re_22279);
    DeRef(_haystack_22281);
    DeRef(_options_22283);
    _12585 = NOVALUE;
    _12583 = NOVALUE;
    return _match_data_22289;
    ;
}



// 0xC12BD49A
