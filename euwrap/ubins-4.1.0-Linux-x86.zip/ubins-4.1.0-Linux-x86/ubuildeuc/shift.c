// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _66init_op_info()
{
    object _SHORT_CIRCUIT_24668 = NOVALUE;
    object _info_24713 = NOVALUE;
    object _13855 = NOVALUE;
    object _13854 = NOVALUE;
    object _13853 = NOVALUE;
    object _13852 = NOVALUE;
    object _13851 = NOVALUE;
    object _13850 = NOVALUE;
    object _13848 = NOVALUE;
    object _13847 = NOVALUE;
    object _13846 = NOVALUE;
    object _13845 = NOVALUE;
    object _13844 = NOVALUE;
    object _13843 = NOVALUE;
    object _13842 = NOVALUE;
    object _13841 = NOVALUE;
    object _13840 = NOVALUE;
    object _13839 = NOVALUE;
    object _13838 = NOVALUE;
    object _13837 = NOVALUE;
    object _13836 = NOVALUE;
    object _13835 = NOVALUE;
    object _13834 = NOVALUE;
    object _13833 = NOVALUE;
    object _13832 = NOVALUE;
    object _13831 = NOVALUE;
    object _13829 = NOVALUE;
    object _13828 = NOVALUE;
    object _13827 = NOVALUE;
    object _13826 = NOVALUE;
    object _13825 = NOVALUE;
    object _13824 = NOVALUE;
    object _13823 = NOVALUE;
    object _13822 = NOVALUE;
    object _13821 = NOVALUE;
    object _13820 = NOVALUE;
    object _13819 = NOVALUE;
    object _13818 = NOVALUE;
    object _13817 = NOVALUE;
    object _13816 = NOVALUE;
    object _13815 = NOVALUE;
    object _13814 = NOVALUE;
    object _13813 = NOVALUE;
    object _13812 = NOVALUE;
    object _13811 = NOVALUE;
    object _13810 = NOVALUE;
    object _13809 = NOVALUE;
    object _13808 = NOVALUE;
    object _13807 = NOVALUE;
    object _13806 = NOVALUE;
    object _13805 = NOVALUE;
    object _13804 = NOVALUE;
    object _13803 = NOVALUE;
    object _13802 = NOVALUE;
    object _13801 = NOVALUE;
    object _13800 = NOVALUE;
    object _13799 = NOVALUE;
    object _13798 = NOVALUE;
    object _13797 = NOVALUE;
    object _13796 = NOVALUE;
    object _13795 = NOVALUE;
    object _13794 = NOVALUE;
    object _13793 = NOVALUE;
    object _13792 = NOVALUE;
    object _13791 = NOVALUE;
    object _13790 = NOVALUE;
    object _13789 = NOVALUE;
    object _13788 = NOVALUE;
    object _13787 = NOVALUE;
    object _13786 = NOVALUE;
    object _13785 = NOVALUE;
    object _13784 = NOVALUE;
    object _13783 = NOVALUE;
    object _13782 = NOVALUE;
    object _13780 = NOVALUE;
    object _13779 = NOVALUE;
    object _13778 = NOVALUE;
    object _13777 = NOVALUE;
    object _13776 = NOVALUE;
    object _13775 = NOVALUE;
    object _13774 = NOVALUE;
    object _13773 = NOVALUE;
    object _13772 = NOVALUE;
    object _13771 = NOVALUE;
    object _13770 = NOVALUE;
    object _13769 = NOVALUE;
    object _13768 = NOVALUE;
    object _13767 = NOVALUE;
    object _13766 = NOVALUE;
    object _13765 = NOVALUE;
    object _13764 = NOVALUE;
    object _13763 = NOVALUE;
    object _13762 = NOVALUE;
    object _13761 = NOVALUE;
    object _13760 = NOVALUE;
    object _13759 = NOVALUE;
    object _13758 = NOVALUE;
    object _13757 = NOVALUE;
    object _13756 = NOVALUE;
    object _13755 = NOVALUE;
    object _13754 = NOVALUE;
    object _13753 = NOVALUE;
    object _13752 = NOVALUE;
    object _13751 = NOVALUE;
    object _13750 = NOVALUE;
    object _13749 = NOVALUE;
    object _13748 = NOVALUE;
    object _13747 = NOVALUE;
    object _13746 = NOVALUE;
    object _13745 = NOVALUE;
    object _13744 = NOVALUE;
    object _13743 = NOVALUE;
    object _13742 = NOVALUE;
    object _13741 = NOVALUE;
    object _13740 = NOVALUE;
    object _13739 = NOVALUE;
    object _13738 = NOVALUE;
    object _13737 = NOVALUE;
    object _13736 = NOVALUE;
    object _13735 = NOVALUE;
    object _13734 = NOVALUE;
    object _13733 = NOVALUE;
    object _13732 = NOVALUE;
    object _13731 = NOVALUE;
    object _13730 = NOVALUE;
    object _13729 = NOVALUE;
    object _13728 = NOVALUE;
    object _13727 = NOVALUE;
    object _13726 = NOVALUE;
    object _13725 = NOVALUE;
    object _13724 = NOVALUE;
    object _13723 = NOVALUE;
    object _13722 = NOVALUE;
    object _13721 = NOVALUE;
    object _13720 = NOVALUE;
    object _13719 = NOVALUE;
    object _13718 = NOVALUE;
    object _13717 = NOVALUE;
    object _13716 = NOVALUE;
    object _13715 = NOVALUE;
    object _13714 = NOVALUE;
    object _13713 = NOVALUE;
    object _13712 = NOVALUE;
    object _13711 = NOVALUE;
    object _13709 = NOVALUE;
    object _13708 = NOVALUE;
    object _13707 = NOVALUE;
    object _13706 = NOVALUE;
    object _13705 = NOVALUE;
    object _13704 = NOVALUE;
    object _13703 = NOVALUE;
    object _13702 = NOVALUE;
    object _13701 = NOVALUE;
    object _13700 = NOVALUE;
    object _13699 = NOVALUE;
    object _13698 = NOVALUE;
    object _13697 = NOVALUE;
    object _13696 = NOVALUE;
    object _13695 = NOVALUE;
    object _13694 = NOVALUE;
    object _13693 = NOVALUE;
    object _13692 = NOVALUE;
    object _13691 = NOVALUE;
    object _13690 = NOVALUE;
    object _13689 = NOVALUE;
    object _13688 = NOVALUE;
    object _13687 = NOVALUE;
    object _13686 = NOVALUE;
    object _13685 = NOVALUE;
    object _13684 = NOVALUE;
    object _13683 = NOVALUE;
    object _13681 = NOVALUE;
    object _13680 = NOVALUE;
    object _13679 = NOVALUE;
    object _13678 = NOVALUE;
    object _13677 = NOVALUE;
    object _13676 = NOVALUE;
    object _13675 = NOVALUE;
    object _13674 = NOVALUE;
    object _13673 = NOVALUE;
    object _13672 = NOVALUE;
    object _13671 = NOVALUE;
    object _13670 = NOVALUE;
    object _13669 = NOVALUE;
    object _13668 = NOVALUE;
    object _13667 = NOVALUE;
    object _13666 = NOVALUE;
    object _13665 = NOVALUE;
    object _13664 = NOVALUE;
    object _13663 = NOVALUE;
    object _13662 = NOVALUE;
    object _13661 = NOVALUE;
    object _13660 = NOVALUE;
    object _13659 = NOVALUE;
    object _13658 = NOVALUE;
    object _13657 = NOVALUE;
    object _13656 = NOVALUE;
    object _13655 = NOVALUE;
    object _13654 = NOVALUE;
    object _13653 = NOVALUE;
    object _13652 = NOVALUE;
    object _13651 = NOVALUE;
    object _13650 = NOVALUE;
    object _13649 = NOVALUE;
    object _13648 = NOVALUE;
    object _13647 = NOVALUE;
    object _13646 = NOVALUE;
    object _13645 = NOVALUE;
    object _13644 = NOVALUE;
    object _13643 = NOVALUE;
    object _13642 = NOVALUE;
    object _13641 = NOVALUE;
    object _13640 = NOVALUE;
    object _13639 = NOVALUE;
    object _13638 = NOVALUE;
    object _13637 = NOVALUE;
    object _13636 = NOVALUE;
    object _13634 = NOVALUE;
    object _13633 = NOVALUE;
    object _13632 = NOVALUE;
    object _13631 = NOVALUE;
    object _13630 = NOVALUE;
    object _13629 = NOVALUE;
    object _13628 = NOVALUE;
    object _13627 = NOVALUE;
    object _13626 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:44		op_info = repeat( 0, MAX_OPCODE )*/
    DeRef(_66op_info_24241);
    _66op_info_24241 = Repeat(0, 218);

    /** shift.e:45		op_info_size_type = repeat( 0, MAX_OPCODE )*/
    DeRef(_66op_info_size_type_24247);
    _66op_info_size_type_24247 = Repeat(0, 218);

    /** shift.e:46		op_info_size = repeat( 0, MAX_OPCODE )*/
    DeRef(_66op_info_size_24248);
    _66op_info_size_24248 = Repeat(0, 218);

    /** shift.e:47		op_info_addr = repeat( 0, MAX_OPCODE )*/
    DeRef(_66op_info_addr_24249);
    _66op_info_addr_24249 = Repeat(0, 218);

    /** shift.e:48		op_info_target = repeat( 0, MAX_OPCODE )*/
    DeRef(_66op_info_target_24250);
    _66op_info_target_24250 = Repeat(0, 218);

    /** shift.e:49		op_info_sub = repeat( 0, MAX_OPCODE )*/
    DeRef(_66op_info_sub_24251);
    _66op_info_sub_24251 = Repeat(0, 218);

    /** shift.e:51		op_info[ABORT               ] = { FIXED_SIZE, 2, {}, {}, {} }   -- ary: pun*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13626 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 126);
    *(intptr_t *)_2 = _13626;
    if( _1 != _13626 ){
    }
    _13626 = NOVALUE;

    /** shift.e:52		op_info[AND                 ] = { FIXED_SIZE, 4, {}, {}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13627 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13627;
    if( _1 != _13627 ){
        DeRef(_1);
    }
    _13627 = NOVALUE;

    /** shift.e:53		op_info[AND_BITS            ] = { FIXED_SIZE, 4, {}, {3}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13628 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 56);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13628;
    if( _1 != _13628 ){
        DeRef(_1);
    }
    _13628 = NOVALUE;

    /** shift.e:54		op_info[APPEND              ] = { FIXED_SIZE, 4, {}, {3}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13629 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 35);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13629;
    if( _1 != _13629 ){
        DeRef(_1);
    }
    _13629 = NOVALUE;

    /** shift.e:55		op_info[ARCTAN              ] = { FIXED_SIZE, 3, {}, {2}, {} }   -- ary: un*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13630 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 73);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13630;
    if( _1 != _13630 ){
        DeRef(_1);
    }
    _13630 = NOVALUE;

    /** shift.e:56		op_info[ASSIGN              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13631 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 18);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13631;
    if( _1 != _13631 ){
        DeRef(_1);
    }
    _13631 = NOVALUE;

    /** shift.e:57		op_info[ASSIGN_I            ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13632 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 113);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13632;
    if( _1 != _13632 ){
        DeRef(_1);
    }
    _13632 = NOVALUE;

    /** shift.e:58		op_info[ASSIGN_OP_SLICE     ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13469);
    ((intptr_t*)_2)[4] = _13469;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13633 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 150);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13633;
    if( _1 != _13633 ){
        DeRef(_1);
    }
    _13633 = NOVALUE;

    /** shift.e:59		op_info[ASSIGN_OP_SUBS      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13634 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 149);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13634;
    if( _1 != _13634 ){
        DeRef(_1);
    }
    _13634 = NOVALUE;

    /** shift.e:60		op_info[ASSIGN_SLICE        ] = { FIXED_SIZE, 5, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13635);
    ((intptr_t*)_2)[4] = _13635;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13636 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13636;
    if( _1 != _13636 ){
        DeRef(_1);
    }
    _13636 = NOVALUE;

    /** shift.e:61		op_info[ASSIGN_SUBS         ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13635);
    ((intptr_t*)_2)[4] = _13635;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13637 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 16);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13637;
    if( _1 != _13637 ){
        DeRef(_1);
    }
    _13637 = NOVALUE;

    /** shift.e:62		op_info[ASSIGN_SUBS_CHECK   ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13635);
    ((intptr_t*)_2)[4] = _13635;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13638 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 84);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13638;
    if( _1 != _13638 ){
        DeRef(_1);
    }
    _13638 = NOVALUE;

    /** shift.e:63		op_info[ASSIGN_SUBS_I       ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13635);
    ((intptr_t*)_2)[4] = _13635;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13639 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 118);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13639;
    if( _1 != _13639 ){
        DeRef(_1);
    }
    _13639 = NOVALUE;

    /** shift.e:64		op_info[BADRETURNF          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13640 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13640;
    if( _1 != _13640 ){
        DeRef(_1);
    }
    _13640 = NOVALUE;

    /** shift.e:65		op_info[CALL                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13641 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 129);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13641;
    if( _1 != _13641 ){
        DeRef(_1);
    }
    _13641 = NOVALUE;

    /** shift.e:66		op_info[CALL_PROC           ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13642 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 136);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13642;
    if( _1 != _13642 ){
        DeRef(_1);
    }
    _13642 = NOVALUE;

    /** shift.e:67		op_info[CALL_FUNC           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13643 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 137);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13643;
    if( _1 != _13643 ){
        DeRef(_1);
    }
    _13643 = NOVALUE;

    /** shift.e:68		op_info[CASE                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13644 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 186);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13644;
    if( _1 != _13644 ){
        DeRef(_1);
    }
    _13644 = NOVALUE;

    /** shift.e:69		op_info[CLEAR_SCREEN        ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13645 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 59);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13645;
    if( _1 != _13645 ){
        DeRef(_1);
    }
    _13645 = NOVALUE;

    /** shift.e:70		op_info[CLOSE               ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13646 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 86);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13646;
    if( _1 != _13646 ){
        DeRef(_1);
    }
    _13646 = NOVALUE;

    /** shift.e:71		op_info[COMMAND_LINE        ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13635);
    ((intptr_t*)_2)[4] = _13635;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13647 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 100);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13647;
    if( _1 != _13647 ){
        DeRef(_1);
    }
    _13647 = NOVALUE;

    /** shift.e:72		op_info[COMPARE             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13648 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 76);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13648;
    if( _1 != _13648 ){
        DeRef(_1);
    }
    _13648 = NOVALUE;

    /** shift.e:73		op_info[CONCAT              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13649 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13649;
    if( _1 != _13649 ){
        DeRef(_1);
    }
    _13649 = NOVALUE;

    /** shift.e:74		op_info[COS                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13650 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 81);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13650;
    if( _1 != _13650 ){
        DeRef(_1);
    }
    _13650 = NOVALUE;

    /** shift.e:75		op_info[COVERAGE_LINE       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13651 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 210);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13651;
    if( _1 != _13651 ){
        DeRef(_1);
    }
    _13651 = NOVALUE;

    /** shift.e:76		op_info[COVERAGE_ROUTINE    ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13652 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 211);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13652;
    if( _1 != _13652 ){
        DeRef(_1);
    }
    _13652 = NOVALUE;

    /** shift.e:77		op_info[C_FUNC              ] = { FIXED_SIZE, 5, {}, {4}, {3} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13469);
    ((intptr_t*)_2)[4] = _13469;
    RefDS(_13246);
    ((intptr_t*)_2)[5] = _13246;
    _13653 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 133);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13653;
    if( _1 != _13653 ){
        DeRef(_1);
    }
    _13653 = NOVALUE;

    /** shift.e:78		op_info[C_PROC              ] = { FIXED_SIZE, 4, {}, {}, {3} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[5] = _13246;
    _13654 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 132);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13654;
    if( _1 != _13654 ){
        DeRef(_1);
    }
    _13654 = NOVALUE;

    /** shift.e:79		op_info[DATE                ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13635);
    ((intptr_t*)_2)[4] = _13635;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13655 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 69);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13655;
    if( _1 != _13655 ){
        DeRef(_1);
    }
    _13655 = NOVALUE;

    /** shift.e:80		op_info[DELETE_ROUTINE      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13656 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 204);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13656;
    if( _1 != _13656 ){
        DeRef(_1);
    }
    _13656 = NOVALUE;

    /** shift.e:81		op_info[DELETE_OBJECT       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13657 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 205);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13657;
    if( _1 != _13657 ){
        DeRef(_1);
    }
    _13657 = NOVALUE;

    /** shift.e:82		op_info[DIV2                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13658 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 98);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13658;
    if( _1 != _13658 ){
        DeRef(_1);
    }
    _13658 = NOVALUE;

    /** shift.e:83		op_info[DIVIDE              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13659 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13659;
    if( _1 != _13659 ){
        DeRef(_1);
    }
    _13659 = NOVALUE;

    /** shift.e:84		op_info[ELSE                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_13635);
    ((intptr_t*)_2)[3] = _13635;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13660 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13660;
    if( _1 != _13660 ){
        DeRef(_1);
    }
    _13660 = NOVALUE;

    /** shift.e:85		op_info[EXIT                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_13635);
    ((intptr_t*)_2)[3] = _13635;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13661 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 61);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13661;
    if( _1 != _13661 ){
        DeRef(_1);
    }
    _13661 = NOVALUE;

    /** shift.e:86		op_info[EXIT_BLOCK          ] = { FIXED_SIZE, 2, {},  {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13662 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 206);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13662;
    if( _1 != _13662 ){
        DeRef(_1);
    }
    _13662 = NOVALUE;

    /** shift.e:87		op_info[ENDWHILE            ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_13635);
    ((intptr_t*)_2)[3] = _13635;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13663 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 22);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13663;
    if( _1 != _13663 ){
        DeRef(_1);
    }
    _13663 = NOVALUE;

    /** shift.e:88		op_info[RETRY               ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_13635);
    ((intptr_t*)_2)[3] = _13635;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13664 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 184);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13664;
    if( _1 != _13664 ){
        DeRef(_1);
    }
    _13664 = NOVALUE;

    /** shift.e:89		op_info[GOTO                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_13635);
    ((intptr_t*)_2)[3] = _13635;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13665 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 188);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13665;
    if( _1 != _13665 ){
        DeRef(_1);
    }
    _13665 = NOVALUE;

    /** shift.e:90		op_info[ENDFOR_GENERAL      ] = { FIXED_SIZE, 5, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_13635);
    ((intptr_t*)_2)[3] = _13635;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13666 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13666;
    if( _1 != _13666 ){
        DeRef(_1);
    }
    _13666 = NOVALUE;

    /** shift.e:91		op_info[ENDFOR_UP           ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13635);
    ((intptr_t*)_2)[3] = _13635;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13667 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13667;
    if( _1 != _13667 ){
        DeRef(_1);
    }
    _13667 = NOVALUE;

    /** shift.e:92		op_info[ENDFOR_DOWN         ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13635);
    ((intptr_t*)_2)[3] = _13635;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13668 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 50);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13668;
    if( _1 != _13668 ){
        DeRef(_1);
    }
    _13668 = NOVALUE;

    /** shift.e:93		op_info[ENDFOR_INT_UP       ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13635);
    ((intptr_t*)_2)[3] = _13635;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13669 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 48);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13669;
    if( _1 != _13669 ){
        DeRef(_1);
    }
    _13669 = NOVALUE;

    /** shift.e:94		op_info[ENDFOR_INT_DOWN     ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13635);
    ((intptr_t*)_2)[3] = _13635;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13670 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13670;
    if( _1 != _13670 ){
        DeRef(_1);
    }
    _13670 = NOVALUE;

    /** shift.e:95		op_info[ENDFOR_INT_DOWN1    ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13635);
    ((intptr_t*)_2)[3] = _13635;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13671 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 55);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13671;
    if( _1 != _13671 ){
        DeRef(_1);
    }
    _13671 = NOVALUE;

    /** shift.e:96		op_info[ENDFOR_INT_UP1      ] = { FIXED_SIZE, 5, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_13635);
    ((intptr_t*)_2)[3] = _13635;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13672 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 54);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13672;
    if( _1 != _13672 ){
        DeRef(_1);
    }
    _13672 = NOVALUE;

    /** shift.e:97		op_info[EQUAL               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13673 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 153);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13673;
    if( _1 != _13673 ){
        DeRef(_1);
    }
    _13673 = NOVALUE;

    /** shift.e:98		op_info[EQUALS              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13674 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13674;
    if( _1 != _13674 ){
        DeRef(_1);
    }
    _13674 = NOVALUE;

    /** shift.e:99		op_info[EQUALS_IFW          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13246);
    ((intptr_t*)_2)[3] = _13246;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13675 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 104);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13675;
    if( _1 != _13675 ){
        DeRef(_1);
    }
    _13675 = NOVALUE;

    /** shift.e:100		op_info[EQUALS_IFW_I        ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13246);
    ((intptr_t*)_2)[3] = _13246;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13676 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 121);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13676;
    if( _1 != _13676 ){
        DeRef(_1);
    }
    _13676 = NOVALUE;

    /** shift.e:101		op_info[FIND                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13677 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 77);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13677;
    if( _1 != _13677 ){
        DeRef(_1);
    }
    _13677 = NOVALUE;

    /** shift.e:102		op_info[FIND_FROM           ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13469);
    ((intptr_t*)_2)[4] = _13469;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13678 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 176);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13678;
    if( _1 != _13678 ){
        DeRef(_1);
    }
    _13678 = NOVALUE;

    /** shift.e:103		op_info[FLOOR               ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13679 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 83);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13679;
    if( _1 != _13679 ){
        DeRef(_1);
    }
    _13679 = NOVALUE;

    /** shift.e:104		op_info[FLOOR_DIV           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13680 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 63);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13680;
    if( _1 != _13680 ){
        DeRef(_1);
    }
    _13680 = NOVALUE;

    /** shift.e:105		op_info[FLOOR_DIV2          ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13681 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 66);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13681;
    if( _1 != _13681 ){
        DeRef(_1);
    }
    _13681 = NOVALUE;

    /** shift.e:106		op_info[FOR                 ] = { FIXED_SIZE, 7, {6}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 7;
    RefDS(_13682);
    ((intptr_t*)_2)[3] = _13682;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13683 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 21);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13683;
    if( _1 != _13683 ){
        DeRef(_1);
    }
    _13683 = NOVALUE;

    /** shift.e:107		op_info[FOR_I               ] = { FIXED_SIZE, 7, {6}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 7;
    RefDS(_13682);
    ((intptr_t*)_2)[3] = _13682;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13684 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 125);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13684;
    if( _1 != _13684 ){
        DeRef(_1);
    }
    _13684 = NOVALUE;

    /** shift.e:108		op_info[GETC                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13685 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13685;
    if( _1 != _13685 ){
        DeRef(_1);
    }
    _13685 = NOVALUE;

    /** shift.e:109		op_info[GETENV              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13686 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 91);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13686;
    if( _1 != _13686 ){
        DeRef(_1);
    }
    _13686 = NOVALUE;

    /** shift.e:110		op_info[GETS                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13687 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 17);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13687;
    if( _1 != _13687 ){
        DeRef(_1);
    }
    _13687 = NOVALUE;

    /** shift.e:111		op_info[GET_KEY             ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13635);
    ((intptr_t*)_2)[4] = _13635;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13688 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 79);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13688;
    if( _1 != _13688 ){
        DeRef(_1);
    }
    _13688 = NOVALUE;

    /** shift.e:112		op_info[GLABEL              ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_13635);
    ((intptr_t*)_2)[3] = _13635;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13689 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 189);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13689;
    if( _1 != _13689 ){
        DeRef(_1);
    }
    _13689 = NOVALUE;

    /** shift.e:113		op_info[GLOBAL_INIT_CHECK   ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13690 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 109);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13690;
    if( _1 != _13690 ){
        DeRef(_1);
    }
    _13690 = NOVALUE;

    /** shift.e:114		op_info[PRIVATE_INIT_CHECK  ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13691 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13691;
    if( _1 != _13691 ){
        DeRef(_1);
    }
    _13691 = NOVALUE;

    /** shift.e:115		op_info[GREATER             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13692 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13692;
    if( _1 != _13692 ){
        DeRef(_1);
    }
    _13692 = NOVALUE;

    /** shift.e:116		op_info[GREATEREQ           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13693 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13693;
    if( _1 != _13693 ){
        DeRef(_1);
    }
    _13693 = NOVALUE;

    /** shift.e:117		op_info[GREATEREQ_IFW       ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13246);
    ((intptr_t*)_2)[3] = _13246;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13694 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 103);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13694;
    if( _1 != _13694 ){
        DeRef(_1);
    }
    _13694 = NOVALUE;

    /** shift.e:118		op_info[GREATEREQ_IFW_I     ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13246);
    ((intptr_t*)_2)[3] = _13246;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13695 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 120);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13695;
    if( _1 != _13695 ){
        DeRef(_1);
    }
    _13695 = NOVALUE;

    /** shift.e:119		op_info[GREATER_IFW         ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13246);
    ((intptr_t*)_2)[3] = _13246;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13696 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 107);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13696;
    if( _1 != _13696 ){
        DeRef(_1);
    }
    _13696 = NOVALUE;

    /** shift.e:120		op_info[GREATER_IFW_I       ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13246);
    ((intptr_t*)_2)[3] = _13246;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13697 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 124);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13697;
    if( _1 != _13697 ){
        DeRef(_1);
    }
    _13697 = NOVALUE;

    /** shift.e:121		op_info[HASH                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13698 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 194);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13698;
    if( _1 != _13698 ){
        DeRef(_1);
    }
    _13698 = NOVALUE;

    /** shift.e:122		op_info[HEAD                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13699 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 198);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13699;
    if( _1 != _13699 ){
        DeRef(_1);
    }
    _13699 = NOVALUE;

    /** shift.e:123		op_info[IF                  ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_13309);
    ((intptr_t*)_2)[3] = _13309;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13700 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 20);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13700;
    if( _1 != _13700 ){
        DeRef(_1);
    }
    _13700 = NOVALUE;

    /** shift.e:124		op_info[INSERT              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13469);
    ((intptr_t*)_2)[4] = _13469;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13701 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 191);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13701;
    if( _1 != _13701 ){
        DeRef(_1);
    }
    _13701 = NOVALUE;

    /** shift.e:125		op_info[LENGTH              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13702 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13702;
    if( _1 != _13702 ){
        DeRef(_1);
    }
    _13702 = NOVALUE;

    /** shift.e:126		op_info[LESS                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13703 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13703;
    if( _1 != _13703 ){
        DeRef(_1);
    }
    _13703 = NOVALUE;

    /** shift.e:127		op_info[LESSEQ              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13704 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13704;
    if( _1 != _13704 ){
        DeRef(_1);
    }
    _13704 = NOVALUE;

    /** shift.e:128		op_info[LESSEQ_IFW          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13246);
    ((intptr_t*)_2)[3] = _13246;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13705 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 106);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13705;
    if( _1 != _13705 ){
        DeRef(_1);
    }
    _13705 = NOVALUE;

    /** shift.e:129		op_info[LESSEQ_IFW_I        ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13246);
    ((intptr_t*)_2)[3] = _13246;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13706 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 123);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13706;
    if( _1 != _13706 ){
        DeRef(_1);
    }
    _13706 = NOVALUE;

    /** shift.e:130		op_info[LESS_IFW            ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13246);
    ((intptr_t*)_2)[3] = _13246;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13707 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 102);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13707;
    if( _1 != _13707 ){
        DeRef(_1);
    }
    _13707 = NOVALUE;

    /** shift.e:131		op_info[LESS_IFW_I          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13246);
    ((intptr_t*)_2)[3] = _13246;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13708 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 119);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13708;
    if( _1 != _13708 ){
        DeRef(_1);
    }
    _13708 = NOVALUE;

    /** shift.e:132		op_info[LHS_SUBS            ] = { FIXED_SIZE, 5, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13709 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 95);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13709;
    if( _1 != _13709 ){
        DeRef(_1);
    }
    _13709 = NOVALUE;

    /** shift.e:133		op_info[LHS_SUBS1           ] = { FIXED_SIZE, 5, {}, {3,4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13710);
    ((intptr_t*)_2)[4] = _13710;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13711 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 161);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13711;
    if( _1 != _13711 ){
        DeRef(_1);
    }
    _13711 = NOVALUE;

    /** shift.e:134		op_info[LHS_SUBS1_COPY      ] = { FIXED_SIZE, 5, {}, {3,4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13710);
    ((intptr_t*)_2)[4] = _13710;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13712 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 166);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13712;
    if( _1 != _13712 ){
        DeRef(_1);
    }
    _13712 = NOVALUE;

    /** shift.e:135		op_info[LOG                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13713 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 74);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13713;
    if( _1 != _13713 ){
        DeRef(_1);
    }
    _13713 = NOVALUE;

    /** shift.e:136		op_info[MACHINE_FUNC        ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13714 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 111);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13714;
    if( _1 != _13714 ){
        DeRef(_1);
    }
    _13714 = NOVALUE;

    /** shift.e:137		op_info[MACHINE_PROC        ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13715 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 112);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13715;
    if( _1 != _13715 ){
        DeRef(_1);
    }
    _13715 = NOVALUE;

    /** shift.e:138		op_info[MATCH               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13716 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 78);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13716;
    if( _1 != _13716 ){
        DeRef(_1);
    }
    _13716 = NOVALUE;

    /** shift.e:139		op_info[MATCH_FROM          ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13469);
    ((intptr_t*)_2)[4] = _13469;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13717 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 177);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13717;
    if( _1 != _13717 ){
        DeRef(_1);
    }
    _13717 = NOVALUE;

    /** shift.e:140		op_info[MEM_COPY            ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13718 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 130);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13718;
    if( _1 != _13718 ){
        DeRef(_1);
    }
    _13718 = NOVALUE;

    /** shift.e:141		op_info[MEM_SET             ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13719 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 131);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13719;
    if( _1 != _13719 ){
        DeRef(_1);
    }
    _13719 = NOVALUE;

    /** shift.e:142		op_info[MINUS               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13720 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13720;
    if( _1 != _13720 ){
        DeRef(_1);
    }
    _13720 = NOVALUE;

    /** shift.e:143		op_info[MINUS_I             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13721 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 116);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13721;
    if( _1 != _13721 ){
        DeRef(_1);
    }
    _13721 = NOVALUE;

    /** shift.e:144		op_info[MULTIPLY            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13722 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 13);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13722;
    if( _1 != _13722 ){
        DeRef(_1);
    }
    _13722 = NOVALUE;

    /** shift.e:145		op_info[NOP1                ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13723 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 159);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13723;
    if( _1 != _13723 ){
        DeRef(_1);
    }
    _13723 = NOVALUE;

    /** shift.e:146		op_info[NOPWHILE            ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13724 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 158);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13724;
    if( _1 != _13724 ){
        DeRef(_1);
    }
    _13724 = NOVALUE;

    /** shift.e:147		op_info[NOP2                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13725 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 110);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13725;
    if( _1 != _13725 ){
        DeRef(_1);
    }
    _13725 = NOVALUE;

    /** shift.e:148		op_info[SC2_NULL            ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13726 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 145);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13726;
    if( _1 != _13726 ){
        DeRef(_1);
    }
    _13726 = NOVALUE;

    /** shift.e:149		op_info[ASSIGN_SUBS2        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13727 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 148);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13727;
    if( _1 != _13727 ){
        DeRef(_1);
    }
    _13727 = NOVALUE;

    /** shift.e:150		op_info[PLATFORM            ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13635);
    ((intptr_t*)_2)[4] = _13635;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13728 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 155);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13728;
    if( _1 != _13728 ){
        DeRef(_1);
    }
    _13728 = NOVALUE;

    /** shift.e:151		op_info[END_PARAM_CHECK     ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13729 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 156);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13729;
    if( _1 != _13729 ){
        DeRef(_1);
    }
    _13729 = NOVALUE;

    /** shift.e:153		op_info[NOPSWITCH           ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13730 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 187);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13730;
    if( _1 != _13730 ){
        DeRef(_1);
    }
    _13730 = NOVALUE;

    /** shift.e:154		op_info[NOT                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13731 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13731;
    if( _1 != _13731 ){
        DeRef(_1);
    }
    _13731 = NOVALUE;

    /** shift.e:155		op_info[NOTEQ               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13732 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13732;
    if( _1 != _13732 ){
        DeRef(_1);
    }
    _13732 = NOVALUE;

    /** shift.e:156		op_info[NOTEQ_IFW           ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13246);
    ((intptr_t*)_2)[3] = _13246;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13733 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 105);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13733;
    if( _1 != _13733 ){
        DeRef(_1);
    }
    _13733 = NOVALUE;

    /** shift.e:157		op_info[NOTEQ_IFW_I         ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13246);
    ((intptr_t*)_2)[3] = _13246;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13734 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 122);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13734;
    if( _1 != _13734 ){
        DeRef(_1);
    }
    _13734 = NOVALUE;

    /** shift.e:158		op_info[NOT_BITS            ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13735 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13735;
    if( _1 != _13735 ){
        DeRef(_1);
    }
    _13735 = NOVALUE;

    /** shift.e:159		op_info[NOT_IFW             ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_13309);
    ((intptr_t*)_2)[3] = _13309;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13736 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 108);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13736;
    if( _1 != _13736 ){
        DeRef(_1);
    }
    _13736 = NOVALUE;

    /** shift.e:160		op_info[OPEN                ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13469);
    ((intptr_t*)_2)[4] = _13469;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13737 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 37);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13737;
    if( _1 != _13737 ){
        DeRef(_1);
    }
    _13737 = NOVALUE;

    /** shift.e:161		op_info[OPTION_SWITCHES     ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13635);
    ((intptr_t*)_2)[4] = _13635;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13738 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 183);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13738;
    if( _1 != _13738 ){
        DeRef(_1);
    }
    _13738 = NOVALUE;

    /** shift.e:162		op_info[OR                  ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13739 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13739;
    if( _1 != _13739 ){
        DeRef(_1);
    }
    _13739 = NOVALUE;

    /** shift.e:163		op_info[OR_BITS             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13740 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13740;
    if( _1 != _13740 ){
        DeRef(_1);
    }
    _13740 = NOVALUE;

    /** shift.e:164		op_info[PASSIGN_OP_SLICE    ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13469);
    ((intptr_t*)_2)[4] = _13469;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13741 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 165);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13741;
    if( _1 != _13741 ){
        DeRef(_1);
    }
    _13741 = NOVALUE;

    /** shift.e:165		op_info[PASSIGN_OP_SUBS     ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13742 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 164);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13742;
    if( _1 != _13742 ){
        DeRef(_1);
    }
    _13742 = NOVALUE;

    /** shift.e:166		op_info[PASSIGN_SLICE       ] = { FIXED_SIZE, 5, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13635);
    ((intptr_t*)_2)[4] = _13635;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13743 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 163);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13743;
    if( _1 != _13743 ){
        DeRef(_1);
    }
    _13743 = NOVALUE;

    /** shift.e:167		op_info[PASSIGN_SUBS        ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13635);
    ((intptr_t*)_2)[4] = _13635;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13744 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 162);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13744;
    if( _1 != _13744 ){
        DeRef(_1);
    }
    _13744 = NOVALUE;

    /** shift.e:168		op_info[PEEK_STRING         ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13745 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 182);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13745;
    if( _1 != _13745 ){
        DeRef(_1);
    }
    _13745 = NOVALUE;

    /** shift.e:169		op_info[PEEK8U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13746 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 214);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13746;
    if( _1 != _13746 ){
        DeRef(_1);
    }
    _13746 = NOVALUE;

    /** shift.e:170		op_info[PEEK8S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13747 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 213);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13747;
    if( _1 != _13747 ){
        DeRef(_1);
    }
    _13747 = NOVALUE;

    /** shift.e:171		op_info[PEEK2U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13748 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 180);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13748;
    if( _1 != _13748 ){
        DeRef(_1);
    }
    _13748 = NOVALUE;

    /** shift.e:172		op_info[PEEK2S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13749 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 179);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13749;
    if( _1 != _13749 ){
        DeRef(_1);
    }
    _13749 = NOVALUE;

    /** shift.e:173		op_info[PEEK4U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13750 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 140);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13750;
    if( _1 != _13750 ){
        DeRef(_1);
    }
    _13750 = NOVALUE;

    /** shift.e:174		op_info[PEEK4S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13751 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 139);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13751;
    if( _1 != _13751 ){
        DeRef(_1);
    }
    _13751 = NOVALUE;

    /** shift.e:175		op_info[PEEKS               ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13752 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 181);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13752;
    if( _1 != _13752 ){
        DeRef(_1);
    }
    _13752 = NOVALUE;

    /** shift.e:176		op_info[PEEK                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13753 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 127);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13753;
    if( _1 != _13753 ){
        DeRef(_1);
    }
    _13753 = NOVALUE;

    /** shift.e:177		op_info[SIZEOF              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13754 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 217);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13754;
    if( _1 != _13754 ){
        DeRef(_1);
    }
    _13754 = NOVALUE;

    /** shift.e:178		op_info[PEEK_POINTER        ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13755 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 216);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13755;
    if( _1 != _13755 ){
        DeRef(_1);
    }
    _13755 = NOVALUE;

    /** shift.e:179		op_info[PLENGTH             ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13756 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 160);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13756;
    if( _1 != _13756 ){
        DeRef(_1);
    }
    _13756 = NOVALUE;

    /** shift.e:180		op_info[PLUS                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13757 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13757;
    if( _1 != _13757 ){
        DeRef(_1);
    }
    _13757 = NOVALUE;

    /** shift.e:181		op_info[PLUS_I              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13758 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 115);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13758;
    if( _1 != _13758 ){
        DeRef(_1);
    }
    _13758 = NOVALUE;

    /** shift.e:182		op_info[PLUS1               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13759 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 93);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13759;
    if( _1 != _13759 ){
        DeRef(_1);
    }
    _13759 = NOVALUE;

    /** shift.e:183		op_info[PLUS1_I             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13760 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 117);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13760;
    if( _1 != _13760 ){
        DeRef(_1);
    }
    _13760 = NOVALUE;

    /** shift.e:184		op_info[POKE                ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13761 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 128);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13761;
    if( _1 != _13761 ){
        DeRef(_1);
    }
    _13761 = NOVALUE;

    /** shift.e:185		op_info[POKE2               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13762 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 178);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13762;
    if( _1 != _13762 ){
        DeRef(_1);
    }
    _13762 = NOVALUE;

    /** shift.e:186		op_info[POKE4               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13763 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 138);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13763;
    if( _1 != _13763 ){
        DeRef(_1);
    }
    _13763 = NOVALUE;

    /** shift.e:187		op_info[POKE8               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13764 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 212);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13764;
    if( _1 != _13764 ){
        DeRef(_1);
    }
    _13764 = NOVALUE;

    /** shift.e:188		op_info[POKE_POINTER        ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13765 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 215);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13765;
    if( _1 != _13765 ){
        DeRef(_1);
    }
    _13765 = NOVALUE;

    /** shift.e:189		op_info[POSITION            ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13766 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 60);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13766;
    if( _1 != _13766 ){
        DeRef(_1);
    }
    _13766 = NOVALUE;

    /** shift.e:190		op_info[POWER               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13767 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 72);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13767;
    if( _1 != _13767 ){
        DeRef(_1);
    }
    _13767 = NOVALUE;

    /** shift.e:191		op_info[PREPEND             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13768 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 57);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13768;
    if( _1 != _13768 ){
        DeRef(_1);
    }
    _13768 = NOVALUE;

    /** shift.e:192		op_info[PRINT               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13769 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 19);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13769;
    if( _1 != _13769 ){
        DeRef(_1);
    }
    _13769 = NOVALUE;

    /** shift.e:193		op_info[PRINTF              ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13770 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13770;
    if( _1 != _13770 ){
        DeRef(_1);
    }
    _13770 = NOVALUE;

    /** shift.e:194		op_info[PROFILE             ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13771 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 151);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13771;
    if( _1 != _13771 ){
        DeRef(_1);
    }
    _13771 = NOVALUE;

    /** shift.e:195		op_info[DISPLAY_VAR         ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13772 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 87);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13772;
    if( _1 != _13772 ){
        DeRef(_1);
    }
    _13772 = NOVALUE;

    /** shift.e:196		op_info[ERASE_PRIVATE_NAMES ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13773 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 88);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13773;
    if( _1 != _13773 ){
        DeRef(_1);
    }
    _13773 = NOVALUE;

    /** shift.e:197		op_info[ERASE_SYMBOL        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13774 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 90);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13774;
    if( _1 != _13774 ){
        DeRef(_1);
    }
    _13774 = NOVALUE;

    /** shift.e:198		op_info[PUTS                ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13775 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13775;
    if( _1 != _13775 ){
        DeRef(_1);
    }
    _13775 = NOVALUE;

    /** shift.e:199		op_info[QPRINT              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13776 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13776;
    if( _1 != _13776 ){
        DeRef(_1);
    }
    _13776 = NOVALUE;

    /** shift.e:200		op_info[RAND                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13777 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 62);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13777;
    if( _1 != _13777 ){
        DeRef(_1);
    }
    _13777 = NOVALUE;

    /** shift.e:201		op_info[REMAINDER           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13778 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 71);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13778;
    if( _1 != _13778 ){
        DeRef(_1);
    }
    _13778 = NOVALUE;

    /** shift.e:202		op_info[REMOVE              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13469);
    ((intptr_t*)_2)[4] = _13469;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13779 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 200);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13779;
    if( _1 != _13779 ){
        DeRef(_1);
    }
    _13779 = NOVALUE;

    /** shift.e:203		op_info[REPEAT              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13780 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13780;
    if( _1 != _13780 ){
        DeRef(_1);
    }
    _13780 = NOVALUE;

    /** shift.e:204		op_info[REPLACE             ] = { FIXED_SIZE, 6, {}, {5}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 6;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13781);
    ((intptr_t*)_2)[4] = _13781;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13782 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 201);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13782;
    if( _1 != _13782 ){
        DeRef(_1);
    }
    _13782 = NOVALUE;

    /** shift.e:205		op_info[RETURNF             ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13783 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 28);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13783;
    if( _1 != _13783 ){
        DeRef(_1);
    }
    _13783 = NOVALUE;

    /** shift.e:206		op_info[RETURNP             ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13784 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 29);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13784;
    if( _1 != _13784 ){
        DeRef(_1);
    }
    _13784 = NOVALUE;

    /** shift.e:207		op_info[RETURNT             ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13785 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13785;
    if( _1 != _13785 ){
        DeRef(_1);
    }
    _13785 = NOVALUE;

    /** shift.e:208		op_info[RHS_SLICE           ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13469);
    ((intptr_t*)_2)[4] = _13469;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13786 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13786;
    if( _1 != _13786 ){
        DeRef(_1);
    }
    _13786 = NOVALUE;

    /** shift.e:209		op_info[RHS_SUBS            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13787 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13787;
    if( _1 != _13787 ){
        DeRef(_1);
    }
    _13787 = NOVALUE;

    /** shift.e:210		op_info[RHS_SUBS_I          ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13788 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 114);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13788;
    if( _1 != _13788 ){
        DeRef(_1);
    }
    _13788 = NOVALUE;

    /** shift.e:211		op_info[RHS_SUBS_CHECK      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13789 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 92);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13789;
    if( _1 != _13789 ){
        DeRef(_1);
    }
    _13789 = NOVALUE;

    /** shift.e:212		op_info[RIGHT_BRACE_2       ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13790 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 85);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13790;
    if( _1 != _13790 ){
        DeRef(_1);
    }
    _13790 = NOVALUE;

    /** shift.e:214		op_info[ROUTINE_ID          ] = { FIXED_SIZE, 6 - TRANSLATE, {}, { 4 + not TRANSLATE }, {} }*/
    _13791 = 6 - _36TRANSLATE_21049;
    _13792 = (_36TRANSLATE_21049 == 0);
    _13793 = 4 + _13792;
    if ((object)((uintptr_t)_13793 + (uintptr_t)HIGH_BITS) >= 0){
        _13793 = NewDouble((eudouble)_13793);
    }
    _13792 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _13793;
    _13794 = MAKE_SEQ(_1);
    _13793 = NOVALUE;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = _13791;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _13794;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13795 = MAKE_SEQ(_1);
    _13794 = NOVALUE;
    _13791 = NOVALUE;
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 134);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13795;
    if( _1 != _13795 ){
        DeRef(_1);
    }
    _13795 = NOVALUE;

    /** shift.e:215		op_info[SC2_OR              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13796 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 144);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13796;
    if( _1 != _13796 ){
        DeRef(_1);
    }
    _13796 = NOVALUE;

    /** shift.e:216		op_info[SC2_AND             ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13797 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 142);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13797;
    if( _1 != _13797 ){
        DeRef(_1);
    }
    _13797 = NOVALUE;

    /** shift.e:217		op_info[SIN                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13798 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 80);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13798;
    if( _1 != _13798 ){
        DeRef(_1);
    }
    _13798 = NOVALUE;

    /** shift.e:218		op_info[SPACE_USED          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13799 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 75);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13799;
    if( _1 != _13799 ){
        DeRef(_1);
    }
    _13799 = NOVALUE;

    /** shift.e:219		op_info[SPLICE              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13469);
    ((intptr_t*)_2)[4] = _13469;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13800 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 190);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13800;
    if( _1 != _13800 ){
        DeRef(_1);
    }
    _13800 = NOVALUE;

    /** shift.e:220		op_info[SPRINTF             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13801 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 53);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13801;
    if( _1 != _13801 ){
        DeRef(_1);
    }
    _13801 = NOVALUE;

    /** shift.e:221		op_info[SQRT                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13802 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13802;
    if( _1 != _13802 ){
        DeRef(_1);
    }
    _13802 = NOVALUE;

    /** shift.e:222		op_info[STARTLINE           ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13803 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 58);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13803;
    if( _1 != _13803 ){
        DeRef(_1);
    }
    _13803 = NOVALUE;

    /** shift.e:223		op_info[SWITCH              ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_13469);
    ((intptr_t*)_2)[3] = _13469;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13804 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 185);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13804;
    if( _1 != _13804 ){
        DeRef(_1);
    }
    _13804 = NOVALUE;

    /** shift.e:224		op_info[SWITCH_I            ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_13469);
    ((intptr_t*)_2)[3] = _13469;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13805 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 193);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13805;
    if( _1 != _13805 ){
        DeRef(_1);
    }
    _13805 = NOVALUE;

    /** shift.e:225		op_info[SWITCH_SPI          ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_13469);
    ((intptr_t*)_2)[3] = _13469;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13806 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 192);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13806;
    if( _1 != _13806 ){
        DeRef(_1);
    }
    _13806 = NOVALUE;

    /** shift.e:226		op_info[SWITCH_RT           ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 5;
    RefDS(_13469);
    ((intptr_t*)_2)[3] = _13469;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13807 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 202);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13807;
    if( _1 != _13807 ){
        DeRef(_1);
    }
    _13807 = NOVALUE;

    /** shift.e:227		op_info[SYSTEM              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13808 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 99);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13808;
    if( _1 != _13808 ){
        DeRef(_1);
    }
    _13808 = NOVALUE;

    /** shift.e:228		op_info[SYSTEM_EXEC         ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13809 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 154);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13809;
    if( _1 != _13809 ){
        DeRef(_1);
    }
    _13809 = NOVALUE;

    /** shift.e:229		op_info[TAIL                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13810 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 199);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13810;
    if( _1 != _13810 ){
        DeRef(_1);
    }
    _13810 = NOVALUE;

    /** shift.e:230		op_info[TAN                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13811 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 82);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13811;
    if( _1 != _13811 ){
        DeRef(_1);
    }
    _13811 = NOVALUE;

    /** shift.e:231		op_info[TASK_CLOCK_START    ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13812 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 175);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13812;
    if( _1 != _13812 ){
        DeRef(_1);
    }
    _13812 = NOVALUE;

    /** shift.e:232		op_info[TASK_CLOCK_STOP     ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13813 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 174);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13813;
    if( _1 != _13813 ){
        DeRef(_1);
    }
    _13813 = NOVALUE;

    /** shift.e:233		op_info[TASK_CREATE         ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13814 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 167);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13814;
    if( _1 != _13814 ){
        DeRef(_1);
    }
    _13814 = NOVALUE;

    /** shift.e:234		op_info[TASK_LIST           ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13635);
    ((intptr_t*)_2)[4] = _13635;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13815 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 172);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13815;
    if( _1 != _13815 ){
        DeRef(_1);
    }
    _13815 = NOVALUE;

    /** shift.e:235		op_info[TASK_SCHEDULE       ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13816 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 168);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13816;
    if( _1 != _13816 ){
        DeRef(_1);
    }
    _13816 = NOVALUE;

    /** shift.e:236		op_info[TASK_SELF           ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13635);
    ((intptr_t*)_2)[4] = _13635;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13817 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 170);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13817;
    if( _1 != _13817 ){
        DeRef(_1);
    }
    _13817 = NOVALUE;

    /** shift.e:237		op_info[TASK_STATUS         ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13818 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 173);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13818;
    if( _1 != _13818 ){
        DeRef(_1);
    }
    _13818 = NOVALUE;

    /** shift.e:238		op_info[TASK_SUSPEND        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13819 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 171);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13819;
    if( _1 != _13819 ){
        DeRef(_1);
    }
    _13819 = NOVALUE;

    /** shift.e:239		op_info[TASK_YIELD          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13820 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 169);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13820;
    if( _1 != _13820 ){
        DeRef(_1);
    }
    _13820 = NOVALUE;

    /** shift.e:240		op_info[TIME                ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13635);
    ((intptr_t*)_2)[4] = _13635;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13821 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 70);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13821;
    if( _1 != _13821 ){
        DeRef(_1);
    }
    _13821 = NOVALUE;

    /** shift.e:241		op_info[TRACE               ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13822 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 64);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13822;
    if( _1 != _13822 ){
        DeRef(_1);
    }
    _13822 = NOVALUE;

    /** shift.e:242		op_info[TYPE_CHECK          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13823 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 65);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13823;
    if( _1 != _13823 ){
        DeRef(_1);
    }
    _13823 = NOVALUE;

    /** shift.e:243		op_info[UMINUS              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13824 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13824;
    if( _1 != _13824 ){
        DeRef(_1);
    }
    _13824 = NOVALUE;

    /** shift.e:244		op_info[UPDATE_GLOBALS      ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13825 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 89);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13825;
    if( _1 != _13825 ){
        DeRef(_1);
    }
    _13825 = NOVALUE;

    /** shift.e:245		op_info[WHILE               ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_13309);
    ((intptr_t*)_2)[3] = _13309;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13826 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13826;
    if( _1 != _13826 ){
        DeRef(_1);
    }
    _13826 = NOVALUE;

    /** shift.e:246		op_info[XOR                 ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13827 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 152);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13827;
    if( _1 != _13827 ){
        DeRef(_1);
    }
    _13827 = NOVALUE;

    /** shift.e:247		op_info[XOR_BITS            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13246);
    ((intptr_t*)_2)[4] = _13246;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13828 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13828;
    if( _1 != _13828 ){
        DeRef(_1);
    }
    _13828 = NOVALUE;

    /** shift.e:249		op_info[TYPE_CHECK_FORWARD  ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13829 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 197);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13829;
    if( _1 != _13829 ){
        DeRef(_1);
    }
    _13829 = NOVALUE;

    /** shift.e:251		sequence SHORT_CIRCUIT = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _0 = _SHORT_CIRCUIT_24668;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 4;
    RefDS(_13246);
    ((intptr_t*)_2)[3] = _13246;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _SHORT_CIRCUIT_24668 = MAKE_SEQ(_1);
    DeRef(_0);

    /** shift.e:252		op_info[SC1_AND_IF          ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_24668);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 146);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_24668;
    DeRef(_1);

    /** shift.e:253		op_info[SC1_OR_IF           ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_24668);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 147);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_24668;
    DeRef(_1);

    /** shift.e:254		op_info[SC1_AND             ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_24668);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 141);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_24668;
    DeRef(_1);

    /** shift.e:255		op_info[SC1_OR              ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_24668);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 143);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_24668;
    DeRef(_1);

    /** shift.e:257		op_info[ATOM_CHECK          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13831 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 101);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13831;
    if( _1 != _13831 ){
        DeRef(_1);
    }
    _13831 = NOVALUE;

    /** shift.e:258		op_info[INTEGER_CHECK       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13832 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 96);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13832;
    if( _1 != _13832 ){
        DeRef(_1);
    }
    _13832 = NOVALUE;

    /** shift.e:259		op_info[SEQUENCE_CHECK      ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13833 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 97);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13833;
    if( _1 != _13833 ){
        DeRef(_1);
    }
    _13833 = NOVALUE;

    /** shift.e:261		op_info[IS_AN_INTEGER       ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13834 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 94);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13834;
    if( _1 != _13834 ){
        DeRef(_1);
    }
    _13834 = NOVALUE;

    /** shift.e:262		op_info[IS_AN_ATOM          ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13835 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 67);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13835;
    if( _1 != _13835 ){
        DeRef(_1);
    }
    _13835 = NOVALUE;

    /** shift.e:263		op_info[IS_A_SEQUENCE       ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13836 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 68);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13836;
    if( _1 != _13836 ){
        DeRef(_1);
    }
    _13836 = NOVALUE;

    /** shift.e:264		op_info[IS_AN_OBJECT        ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 3;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13309);
    ((intptr_t*)_2)[4] = _13309;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13837 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13837;
    if( _1 != _13837 ){
        DeRef(_1);
    }
    _13837 = NOVALUE;

    /** shift.e:266		op_info[CALL_BACK_RETURN    ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13838 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 135);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13838;
    if( _1 != _13838 ){
        DeRef(_1);
    }
    _13838 = NOVALUE;

    /** shift.e:268		op_info[REF_TEMP            ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13839 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 207);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13839;
    if( _1 != _13839 ){
        DeRef(_1);
    }
    _13839 = NOVALUE;

    /** shift.e:269		op_info[DEREF_TEMP          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13840 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 208);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13840;
    if( _1 != _13840 ){
        DeRef(_1);
    }
    _13840 = NOVALUE;

    /** shift.e:270		op_info[NOVALUE_TEMP        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13841 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 209);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13841;
    if( _1 != _13841 ){
        DeRef(_1);
    }
    _13841 = NOVALUE;

    /** shift.e:272		op_info[PROC_FORWARD        ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2;
    ((intptr_t*)_2)[2] = 0;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13842 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 195);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13842;
    if( _1 != _13842 ){
        DeRef(_1);
    }
    _13842 = NOVALUE;

    /** shift.e:273		op_info[FUNC_FORWARD        ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2;
    ((intptr_t*)_2)[2] = 0;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13843 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 196);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13843;
    if( _1 != _13843 ){
        DeRef(_1);
    }
    _13843 = NOVALUE;

    /** shift.e:275		op_info[RIGHT_BRACE_N       ] = { VARIABLE_SIZE, 3, {}, {}, {} } -- target: [pc+1] + 2*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2;
    ((intptr_t*)_2)[2] = 3;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13844 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13844;
    if( _1 != _13844 ){
        DeRef(_1);
    }
    _13844 = NOVALUE;

    /** shift.e:276		op_info[CONCAT_N            ] = { VARIABLE_SIZE, 0, {}, {}, {} } -- target: [pc+1] + 2*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2;
    ((intptr_t*)_2)[2] = 0;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13845 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 157);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13845;
    if( _1 != _13845 ){
        DeRef(_1);
    }
    _13845 = NOVALUE;

    /** shift.e:277		op_info[PROC                ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2;
    ((intptr_t*)_2)[2] = 0;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13846 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 27);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13846;
    if( _1 != _13846 ){
        DeRef(_1);
    }
    _13846 = NOVALUE;

    /** shift.e:278		op_info[PROC_TAIL           ] = op_info[PROC]*/
    _2 = (object)SEQ_PTR(_66op_info_24241);
    _13847 = (object)*(((s1_ptr)_2)->base + 27);
    Ref(_13847);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24241 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 203);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13847;
    if( _1 != _13847 ){
        DeRef(_1);
    }
    _13847 = NOVALUE;

    /** shift.e:281		for i = 1 to MAX_OPCODE do*/
    _13848 = 218;
    {
        object _i_24710;
        _i_24710 = 1;
L1: 
        if (_i_24710 > 218){
            goto L2; // [3959] 4052
        }

        /** shift.e:282			object info = op_info[i]*/
        DeRef(_info_24713);
        _2 = (object)SEQ_PTR(_66op_info_24241);
        _info_24713 = (object)*(((s1_ptr)_2)->base + _i_24710);
        Ref(_info_24713);

        /** shift.e:283			if sequence( info ) then*/
        _13850 = IS_SEQUENCE(_info_24713);
        if (_13850 == 0)
        {
            _13850 = NOVALUE;
            goto L3; // [3979] 4043
        }
        else{
            _13850 = NOVALUE;
        }

        /** shift.e:284				op_info_size_type[i] = info[OP_SIZE_TYPE]*/
        _2 = (object)SEQ_PTR(_info_24713);
        _13851 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_13851);
        _2 = (object)SEQ_PTR(_66op_info_size_type_24247);
        _2 = (object)(((s1_ptr)_2)->base + _i_24710);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _13851;
        if( _1 != _13851 ){
            DeRef(_1);
        }
        _13851 = NOVALUE;

        /** shift.e:285				op_info_size[i] = info[OP_SIZE]*/
        _2 = (object)SEQ_PTR(_info_24713);
        _13852 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_13852);
        _2 = (object)SEQ_PTR(_66op_info_size_24248);
        _2 = (object)(((s1_ptr)_2)->base + _i_24710);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _13852;
        if( _1 != _13852 ){
            DeRef(_1);
        }
        _13852 = NOVALUE;

        /** shift.e:286				op_info_addr[i] = info[OP_ADDR]*/
        _2 = (object)SEQ_PTR(_info_24713);
        _13853 = (object)*(((s1_ptr)_2)->base + 3);
        Ref(_13853);
        _2 = (object)SEQ_PTR(_66op_info_addr_24249);
        _2 = (object)(((s1_ptr)_2)->base + _i_24710);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _13853;
        if( _1 != _13853 ){
            DeRef(_1);
        }
        _13853 = NOVALUE;

        /** shift.e:287				op_info_target[i] = info[OP_TARGET]*/
        _2 = (object)SEQ_PTR(_info_24713);
        _13854 = (object)*(((s1_ptr)_2)->base + 4);
        Ref(_13854);
        _2 = (object)SEQ_PTR(_66op_info_target_24250);
        _2 = (object)(((s1_ptr)_2)->base + _i_24710);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _13854;
        if( _1 != _13854 ){
            DeRef(_1);
        }
        _13854 = NOVALUE;

        /** shift.e:288				op_info_sub[i] = info[OP_SUB]*/
        _2 = (object)SEQ_PTR(_info_24713);
        _13855 = (object)*(((s1_ptr)_2)->base + 5);
        Ref(_13855);
        _2 = (object)SEQ_PTR(_66op_info_sub_24251);
        _2 = (object)(((s1_ptr)_2)->base + _i_24710);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _13855;
        if( _1 != _13855 ){
            DeRef(_1);
        }
        _13855 = NOVALUE;
L3: 
        DeRef(_info_24713);
        _info_24713 = NOVALUE;

        /** shift.e:290		end for*/
        _i_24710 = _i_24710 + 1;
        goto L1; // [4047] 3966
L2: 
        ;
    }

    /** shift.e:291	end procedure*/
    DeRef(_SHORT_CIRCUIT_24668);
    return;
    ;
}


object _66variable_op_size(object _pc_24724, object _op_24725, object _code_24726)
{
    object _int_24729 = NOVALUE;
    object _info_24735 = NOVALUE;
    object _13875 = NOVALUE;
    object _13872 = NOVALUE;
    object _13869 = NOVALUE;
    object _13866 = NOVALUE;
    object _13865 = NOVALUE;
    object _13864 = NOVALUE;
    object _13863 = NOVALUE;
    object _13862 = NOVALUE;
    object _13861 = NOVALUE;
    object _13859 = NOVALUE;
    object _13858 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:297		switch op do*/
    _0 = _op_24725;
    switch ( _0 ){ 

        /** shift.e:298			case PROC, PROC_TAIL then*/
        case 27:
        case 203:

        /** shift.e:299				sequence info = SymTab[code[pc+1]]*/
        _13858 = _pc_24724 + 1;
        _2 = (object)SEQ_PTR(_code_24726);
        _13859 = (object)*(((s1_ptr)_2)->base + _13858);
        DeRef(_info_24735);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_13859)){
            _info_24735 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_13859)->dbl));
        }
        else{
            _info_24735 = (object)*(((s1_ptr)_2)->base + _13859);
        }
        Ref(_info_24735);

        /** shift.e:300				return info[S_NUM_ARGS] + 2 + (info[S_TOKEN] != PROC)*/
        _2 = (object)SEQ_PTR(_info_24735);
        if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
            _13861 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
        }
        else{
            _13861 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
        }
        if (IS_ATOM_INT(_13861)) {
            _13862 = _13861 + 2;
            if ((object)((uintptr_t)_13862 + (uintptr_t)HIGH_BITS) >= 0){
                _13862 = NewDouble((eudouble)_13862);
            }
        }
        else {
            _13862 = binary_op(PLUS, _13861, 2);
        }
        _13861 = NOVALUE;
        _2 = (object)SEQ_PTR(_info_24735);
        if (!IS_ATOM_INT(_36S_TOKEN_21089)){
            _13863 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
        }
        else{
            _13863 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
        }
        if (IS_ATOM_INT(_13863)) {
            _13864 = (_13863 != 27);
        }
        else {
            _13864 = binary_op(NOTEQ, _13863, 27);
        }
        _13863 = NOVALUE;
        if (IS_ATOM_INT(_13862) && IS_ATOM_INT(_13864)) {
            _13865 = _13862 + _13864;
            if ((object)((uintptr_t)_13865 + (uintptr_t)HIGH_BITS) >= 0){
                _13865 = NewDouble((eudouble)_13865);
            }
        }
        else {
            _13865 = binary_op(PLUS, _13862, _13864);
        }
        DeRef(_13862);
        _13862 = NOVALUE;
        DeRef(_13864);
        _13864 = NOVALUE;
        DeRefDS(_info_24735);
        DeRefDS(_code_24726);
        _13859 = NOVALUE;
        _13858 = NOVALUE;
        return _13865;
        goto L1; // [72] 157

        /** shift.e:302			case PROC_FORWARD then*/
        case 195:

        /** shift.e:303				int = code[pc+2]*/
        _13866 = _pc_24724 + 2;
        _2 = (object)SEQ_PTR(_code_24726);
        _int_24729 = (object)*(((s1_ptr)_2)->base + _13866);
        if (!IS_ATOM_INT(_int_24729))
        _int_24729 = (object)DBL_PTR(_int_24729)->dbl;

        /** shift.e:304				int += 3*/
        _int_24729 = _int_24729 + 3;
        goto L1; // [94] 157

        /** shift.e:305			case FUNC_FORWARD then*/
        case 196:

        /** shift.e:306				int = code[pc+2]*/
        _13869 = _pc_24724 + 2;
        _2 = (object)SEQ_PTR(_code_24726);
        _int_24729 = (object)*(((s1_ptr)_2)->base + _13869);
        if (!IS_ATOM_INT(_int_24729))
        _int_24729 = (object)DBL_PTR(_int_24729)->dbl;

        /** shift.e:307				int += 4*/
        _int_24729 = _int_24729 + 4;
        goto L1; // [116] 157

        /** shift.e:308			case RIGHT_BRACE_N, CONCAT_N then*/
        case 31:
        case 157:

        /** shift.e:309				int = code[pc+1]*/
        _13872 = _pc_24724 + 1;
        _2 = (object)SEQ_PTR(_code_24726);
        _int_24729 = (object)*(((s1_ptr)_2)->base + _13872);
        if (!IS_ATOM_INT(_int_24729))
        _int_24729 = (object)DBL_PTR(_int_24729)->dbl;

        /** shift.e:310				int += 3*/
        _int_24729 = _int_24729 + 3;
        goto L1; // [140] 157

        /** shift.e:311			case else*/
        default:

        /** shift.e:312				InternalErr( 269, {op} )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _op_24725;
        _13875 = MAKE_SEQ(_1);
        _50InternalErr(269, _13875);
        _13875 = NOVALUE;
    ;}L1: 

    /** shift.e:314		return int*/
    DeRefDS(_code_24726);
    _13859 = NOVALUE;
    DeRef(_13866);
    _13866 = NOVALUE;
    DeRef(_13872);
    _13872 = NOVALUE;
    DeRef(_13865);
    _13865 = NOVALUE;
    DeRef(_13869);
    _13869 = NOVALUE;
    DeRef(_13858);
    _13858 = NOVALUE;
    return _int_24729;
    ;
}


object _66op_size(object _pc_24769, object _code_24770)
{
    object _op_24773 = NOVALUE;
    object _int_24775 = NOVALUE;
    object _13880 = NOVALUE;
    object _13879 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:318		integer op = code[pc]*/
    _2 = (object)SEQ_PTR(_code_24770);
    _op_24773 = (object)*(((s1_ptr)_2)->base + _pc_24769);
    if (!IS_ATOM_INT(_op_24773))
    _op_24773 = (object)DBL_PTR(_op_24773)->dbl;

    /** shift.e:319		integer int = op_info_size_type[op]*/
    _2 = (object)SEQ_PTR(_66op_info_size_type_24247);
    _int_24775 = (object)*(((s1_ptr)_2)->base + _op_24773);
    if (!IS_ATOM_INT(_int_24775))
    _int_24775 = (object)DBL_PTR(_int_24775)->dbl;

    /** shift.e:321		if int = FIXED_SIZE then*/
    if (_int_24775 != 1)
    goto L1; // [21] 40

    /** shift.e:322			return op_info_size[op]*/
    _2 = (object)SEQ_PTR(_66op_info_size_24248);
    _13879 = (object)*(((s1_ptr)_2)->base + _op_24773);
    Ref(_13879);
    DeRefDS(_code_24770);
    return _13879;
    goto L2; // [37] 53
L1: 

    /** shift.e:324			return variable_op_size( pc, op, code )*/
    RefDS(_code_24770);
    _13880 = _66variable_op_size(_pc_24769, _op_24773, _code_24770);
    DeRefDS(_code_24770);
    _13879 = NOVALUE;
    return _13880;
L2: 
    ;
}


object _66advance(object _pc_24784, object _code_24785)
{
    object _size_24788 = NOVALUE;
    object _13882 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:329		integer size = op_size( pc, code )*/
    RefDS(_code_24785);
    _size_24788 = _66op_size(_pc_24784, _code_24785);
    if (!IS_ATOM_INT(_size_24788)) {
        _1 = (object)(DBL_PTR(_size_24788)->dbl);
        DeRefDS(_size_24788);
        _size_24788 = _1;
    }

    /** shift.e:330		return pc + size*/
    _13882 = _pc_24784 + _size_24788;
    if ((object)((uintptr_t)_13882 + (uintptr_t)HIGH_BITS) >= 0){
        _13882 = NewDouble((eudouble)_13882);
    }
    DeRefDS(_code_24785);
    return _13882;
    ;
}


void _66shift_switch(object _pc_24793, object _start_24794, object _amount_24795)
{
    object _addr_24796 = NOVALUE;
    object _jump_24828 = NOVALUE;
    object _13917 = NOVALUE;
    object _13916 = NOVALUE;
    object _13915 = NOVALUE;
    object _13914 = NOVALUE;
    object _13913 = NOVALUE;
    object _13912 = NOVALUE;
    object _13911 = NOVALUE;
    object _13910 = NOVALUE;
    object _13909 = NOVALUE;
    object _13908 = NOVALUE;
    object _13907 = NOVALUE;
    object _13905 = NOVALUE;
    object _13904 = NOVALUE;
    object _13903 = NOVALUE;
    object _13902 = NOVALUE;
    object _13901 = NOVALUE;
    object _13900 = NOVALUE;
    object _13899 = NOVALUE;
    object _13898 = NOVALUE;
    object _13896 = NOVALUE;
    object _13895 = NOVALUE;
    object _13894 = NOVALUE;
    object _13893 = NOVALUE;
    object _13892 = NOVALUE;
    object _13889 = NOVALUE;
    object _13887 = NOVALUE;
    object _13886 = NOVALUE;
    object _13885 = NOVALUE;
    object _13884 = NOVALUE;
    object _13883 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** shift.e:336		if sequence( Code[pc+4] ) then*/
    _13883 = _pc_24793 + 4;
    _2 = (object)SEQ_PTR(_36Code_21539);
    _13884 = (object)*(((s1_ptr)_2)->base + _13883);
    _13885 = IS_SEQUENCE(_13884);
    _13884 = NOVALUE;
    if (_13885 == 0)
    {
        _13885 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        _13885 = NOVALUE;
    }

    /** shift.e:337			addr = Code[pc+4][2]*/
    _13886 = _pc_24793 + 4;
    _2 = (object)SEQ_PTR(_36Code_21539);
    _13887 = (object)*(((s1_ptr)_2)->base + _13886);
    _2 = (object)SEQ_PTR(_13887);
    _addr_24796 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_addr_24796)){
        _addr_24796 = (object)DBL_PTR(_addr_24796)->dbl;
    }
    _13887 = NOVALUE;
    goto L2; // [43] 61
L1: 

    /** shift.e:339			addr = Code[pc+4]*/
    _13889 = _pc_24793 + 4;
    _2 = (object)SEQ_PTR(_36Code_21539);
    _addr_24796 = (object)*(((s1_ptr)_2)->base + _13889);
    if (!IS_ATOM_INT(_addr_24796)){
        _addr_24796 = (object)DBL_PTR(_addr_24796)->dbl;
    }
L2: 

    /** shift.e:343		if start < addr then*/
    if (_start_24794 >= _addr_24796)
    goto L3; // [65] 137

    /** shift.e:344			if sequence( Code[pc+4] ) then*/
    _13892 = _pc_24793 + 4;
    _2 = (object)SEQ_PTR(_36Code_21539);
    _13893 = (object)*(((s1_ptr)_2)->base + _13892);
    _13894 = IS_SEQUENCE(_13893);
    _13893 = NOVALUE;
    if (_13894 == 0)
    {
        _13894 = NOVALUE;
        goto L4; // [84] 115
    }
    else{
        _13894 = NOVALUE;
    }

    /** shift.e:345				Code[pc+4][2] += amount*/
    _13895 = _pc_24793 + 4;
    _2 = (object)SEQ_PTR(_36Code_21539);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21539 = MAKE_SEQ(_2);
    }
    _3 = (object)(_13895 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _13898 = (object)*(((s1_ptr)_2)->base + 2);
    _13896 = NOVALUE;
    if (IS_ATOM_INT(_13898)) {
        _13899 = _13898 + _amount_24795;
        if ((object)((uintptr_t)_13899 + (uintptr_t)HIGH_BITS) >= 0){
            _13899 = NewDouble((eudouble)_13899);
        }
    }
    else {
        _13899 = binary_op(PLUS, _13898, _amount_24795);
    }
    _13898 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13899;
    if( _1 != _13899 ){
        DeRef(_1);
    }
    _13899 = NOVALUE;
    _13896 = NOVALUE;
    goto L5; // [112] 136
L4: 

    /** shift.e:347				Code[pc+4] += amount*/
    _13900 = _pc_24793 + 4;
    _2 = (object)SEQ_PTR(_36Code_21539);
    _13901 = (object)*(((s1_ptr)_2)->base + _13900);
    if (IS_ATOM_INT(_13901)) {
        _13902 = _13901 + _amount_24795;
        if ((object)((uintptr_t)_13902 + (uintptr_t)HIGH_BITS) >= 0){
            _13902 = NewDouble((eudouble)_13902);
        }
    }
    else {
        _13902 = binary_op(PLUS, _13901, _amount_24795);
    }
    _13901 = NOVALUE;
    _2 = (object)SEQ_PTR(_36Code_21539);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21539 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _13900);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13902;
    if( _1 != _13902 ){
        DeRef(_1);
    }
    _13902 = NOVALUE;
L5: 
L3: 

    /** shift.e:351		sequence jump = SymTab[Code[pc+3]][S_OBJ]*/
    _13903 = _pc_24793 + 3;
    _2 = (object)SEQ_PTR(_36Code_21539);
    _13904 = (object)*(((s1_ptr)_2)->base + _13903);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_13904)){
        _13905 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_13904)->dbl));
    }
    else{
        _13905 = (object)*(((s1_ptr)_2)->base + _13904);
    }
    DeRef(_jump_24828);
    _2 = (object)SEQ_PTR(_13905);
    _jump_24828 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_jump_24828);
    _13905 = NOVALUE;

    /** shift.e:352		for i = 1 to length(jump) do*/
    if (IS_SEQUENCE(_jump_24828)){
            _13907 = SEQ_PTR(_jump_24828)->length;
    }
    else {
        _13907 = 1;
    }
    {
        object _i_24837;
        _i_24837 = 1;
L6: 
        if (_i_24837 > _13907){
            goto L7; // [168] 223
        }

        /** shift.e:353			if start > pc and start < pc + jump[i] then*/
        _13908 = (_start_24794 > _pc_24793);
        if (_13908 == 0) {
            goto L8; // [181] 216
        }
        _2 = (object)SEQ_PTR(_jump_24828);
        _13910 = (object)*(((s1_ptr)_2)->base + _i_24837);
        if (IS_ATOM_INT(_13910)) {
            _13911 = _pc_24793 + _13910;
            if ((object)((uintptr_t)_13911 + (uintptr_t)HIGH_BITS) >= 0){
                _13911 = NewDouble((eudouble)_13911);
            }
        }
        else {
            _13911 = binary_op(PLUS, _pc_24793, _13910);
        }
        _13910 = NOVALUE;
        if (IS_ATOM_INT(_13911)) {
            _13912 = (_start_24794 < _13911);
        }
        else {
            _13912 = binary_op(LESS, _start_24794, _13911);
        }
        DeRef(_13911);
        _13911 = NOVALUE;
        if (_13912 == 0) {
            DeRef(_13912);
            _13912 = NOVALUE;
            goto L8; // [198] 216
        }
        else {
            if (!IS_ATOM_INT(_13912) && DBL_PTR(_13912)->dbl == 0.0){
                DeRef(_13912);
                _13912 = NOVALUE;
                goto L8; // [198] 216
            }
            DeRef(_13912);
            _13912 = NOVALUE;
        }
        DeRef(_13912);
        _13912 = NOVALUE;

        /** shift.e:354				jump[i] += amount*/
        _2 = (object)SEQ_PTR(_jump_24828);
        _13913 = (object)*(((s1_ptr)_2)->base + _i_24837);
        if (IS_ATOM_INT(_13913)) {
            _13914 = _13913 + _amount_24795;
            if ((object)((uintptr_t)_13914 + (uintptr_t)HIGH_BITS) >= 0){
                _13914 = NewDouble((eudouble)_13914);
            }
        }
        else {
            _13914 = binary_op(PLUS, _13913, _amount_24795);
        }
        _13913 = NOVALUE;
        _2 = (object)SEQ_PTR(_jump_24828);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _jump_24828 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_24837);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _13914;
        if( _1 != _13914 ){
            DeRef(_1);
        }
        _13914 = NOVALUE;
L8: 

        /** shift.e:356		end for*/
        _i_24837 = _i_24837 + 1;
        goto L6; // [218] 175
L7: 
        ;
    }

    /** shift.e:357		SymTab[Code[pc+3]][S_OBJ] = jump*/
    _13915 = _pc_24793 + 3;
    _2 = (object)SEQ_PTR(_36Code_21539);
    _13916 = (object)*(((s1_ptr)_2)->base + _13915);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_13916))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_13916)->dbl));
    else
    _3 = (object)(_13916 + ((s1_ptr)_2)->base);
    RefDS(_jump_24828);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _jump_24828;
    DeRef(_1);
    _13917 = NOVALUE;

    /** shift.e:358	end procedure*/
    DeRefDS(_jump_24828);
    DeRef(_13908);
    _13908 = NOVALUE;
    DeRef(_13883);
    _13883 = NOVALUE;
    DeRef(_13900);
    _13900 = NOVALUE;
    DeRef(_13895);
    _13895 = NOVALUE;
    DeRef(_13903);
    _13903 = NOVALUE;
    DeRef(_13892);
    _13892 = NOVALUE;
    DeRef(_13886);
    _13886 = NOVALUE;
    _13916 = NOVALUE;
    DeRef(_13889);
    _13889 = NOVALUE;
    _13915 = NOVALUE;
    _13904 = NOVALUE;
    return;
    ;
}


void _66shift_addr(object _pc_24856, object _amount_24857, object _start_24858, object _bound_24859)
{
    object _int_24860 = NOVALUE;
    object _13932 = NOVALUE;
    object _13929 = NOVALUE;
    object _13925 = NOVALUE;
    object _13920 = NOVALUE;
    object _13919 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_pc_24856)) {
        _1 = (object)(DBL_PTR(_pc_24856)->dbl);
        DeRefDS(_pc_24856);
        _pc_24856 = _1;
    }

    /** shift.e:362		if atom( Code[pc] ) then*/
    _2 = (object)SEQ_PTR(_36Code_21539);
    _13919 = (object)*(((s1_ptr)_2)->base + _pc_24856);
    _13920 = IS_ATOM(_13919);
    _13919 = NOVALUE;
    if (_13920 == 0)
    {
        _13920 = NOVALUE;
        goto L1; // [20] 75
    }
    else{
        _13920 = NOVALUE;
    }

    /** shift.e:363			int = Code[pc]*/
    _2 = (object)SEQ_PTR(_36Code_21539);
    _int_24860 = (object)*(((s1_ptr)_2)->base + _pc_24856);
    if (!IS_ATOM_INT(_int_24860)){
        _int_24860 = (object)DBL_PTR(_int_24860)->dbl;
    }

    /** shift.e:364			if int >= start then*/
    if (_int_24860 < _start_24858)
    goto L2; // [35] 139

    /** shift.e:365				if int < bound then*/
    if (_int_24860 >= _bound_24859)
    goto L3; // [41] 56

    /** shift.e:366					Code[pc] = start*/
    _2 = (object)SEQ_PTR(_36Code_21539);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21539 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_24856);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _start_24858;
    DeRef(_1);
    goto L2; // [53] 139
L3: 

    /** shift.e:368					int += amount*/
    _int_24860 = _int_24860 + _amount_24857;

    /** shift.e:369					Code[pc] = int*/
    _2 = (object)SEQ_PTR(_36Code_21539);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21539 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_24856);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_24860;
    DeRef(_1);
    goto L2; // [72] 139
L1: 

    /** shift.e:373			int = Code[pc][2]*/
    _2 = (object)SEQ_PTR(_36Code_21539);
    _13925 = (object)*(((s1_ptr)_2)->base + _pc_24856);
    _2 = (object)SEQ_PTR(_13925);
    _int_24860 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_24860)){
        _int_24860 = (object)DBL_PTR(_int_24860)->dbl;
    }
    _13925 = NOVALUE;

    /** shift.e:374			if int >= start then*/
    if (_int_24860 < _start_24858)
    goto L4; // [91] 138

    /** shift.e:375				if int < bound then*/
    if (_int_24860 >= _bound_24859)
    goto L5; // [97] 117

    /** shift.e:376					Code[pc][2] = start*/
    _2 = (object)SEQ_PTR(_36Code_21539);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21539 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pc_24856 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _start_24858;
    DeRef(_1);
    _13929 = NOVALUE;
    goto L6; // [114] 137
L5: 

    /** shift.e:378					int += amount*/
    _int_24860 = _int_24860 + _amount_24857;

    /** shift.e:379					Code[pc][2] = int*/
    _2 = (object)SEQ_PTR(_36Code_21539);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21539 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pc_24856 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_24860;
    DeRef(_1);
    _13932 = NOVALUE;
L6: 
L4: 
L2: 

    /** shift.e:383	end procedure*/
    return;
    ;
}


void _66shift(object _start_24893, object _amount_24894, object _bound_24895)
{
    object _int_24898 = NOVALUE;
    object _pc_24911 = NOVALUE;
    object _op_24912 = NOVALUE;
    object _finish_24913 = NOVALUE;
    object _len_24916 = NOVALUE;
    object _size_type_24941 = NOVALUE;
    object _13959 = NOVALUE;
    object _13957 = NOVALUE;
    object _13954 = NOVALUE;
    object _13952 = NOVALUE;
    object _13949 = NOVALUE;
    object _13948 = NOVALUE;
    object _13947 = NOVALUE;
    object _13945 = NOVALUE;
    object _13940 = NOVALUE;
    object _13935 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_24893)) {
        _1 = (object)(DBL_PTR(_start_24893)->dbl);
        DeRefDS(_start_24893);
        _start_24893 = _1;
    }
    if (!IS_ATOM_INT(_amount_24894)) {
        _1 = (object)(DBL_PTR(_amount_24894)->dbl);
        DeRefDS(_amount_24894);
        _amount_24894 = _1;
    }
    if (!IS_ATOM_INT(_bound_24895)) {
        _1 = (object)(DBL_PTR(_bound_24895)->dbl);
        DeRefDS(_bound_24895);
        _bound_24895 = _1;
    }

    /** shift.e:388		if amount = 0 then*/
    if (_amount_24894 != 0)
    goto L1; // [9] 19

    /** shift.e:389			return*/
    return;
L1: 

    /** shift.e:392		integer int*/

    /** shift.e:393		for i = length( LineTable ) to 1 by -1 do*/
    if (IS_SEQUENCE(_36LineTable_21540)){
            _13935 = SEQ_PTR(_36LineTable_21540)->length;
    }
    else {
        _13935 = 1;
    }
    {
        object _i_24900;
        _i_24900 = _13935;
L2: 
        if (_i_24900 < 1){
            goto L3; // [28] 84
        }

        /** shift.e:394			int = LineTable[i]*/
        _2 = (object)SEQ_PTR(_36LineTable_21540);
        _int_24898 = (object)*(((s1_ptr)_2)->base + _i_24900);
        if (!IS_ATOM_INT(_int_24898)){
            _int_24898 = (object)DBL_PTR(_int_24898)->dbl;
        }

        /** shift.e:395			if int > 0 then*/
        if (_int_24898 <= 0)
        goto L4; // [47] 77

        /** shift.e:396				if int < start then*/
        if (_int_24898 >= _start_24893)
        goto L5; // [53] 62

        /** shift.e:397					exit*/
        goto L3; // [59] 84
L5: 

        /** shift.e:399				int += amount*/
        _int_24898 = _int_24898 + _amount_24894;

        /** shift.e:400				LineTable[i] = int*/
        _2 = (object)SEQ_PTR(_36LineTable_21540);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _36LineTable_21540 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_24900);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _int_24898;
        DeRef(_1);
L4: 

        /** shift.e:402		end for*/
        _i_24900 = _i_24900 + -1;
        goto L2; // [79] 35
L3: 
        ;
    }

    /** shift.e:404		integer pc = 1*/
    _pc_24911 = 1;

    /** shift.e:405		integer op*/

    /** shift.e:406		integer finish = start + amount - 1*/
    _13940 = _start_24893 + _amount_24894;
    if ((object)((uintptr_t)_13940 + (uintptr_t)HIGH_BITS) >= 0){
        _13940 = NewDouble((eudouble)_13940);
    }
    if (IS_ATOM_INT(_13940)) {
        _finish_24913 = _13940 - 1;
    }
    else {
        _finish_24913 = NewDouble(DBL_PTR(_13940)->dbl - (eudouble)1);
    }
    DeRef(_13940);
    _13940 = NOVALUE;
    if (!IS_ATOM_INT(_finish_24913)) {
        _1 = (object)(DBL_PTR(_finish_24913)->dbl);
        DeRefDS(_finish_24913);
        _finish_24913 = _1;
    }

    /** shift.e:407		integer len = length( Code )*/
    if (IS_SEQUENCE(_36Code_21539)){
            _len_24916 = SEQ_PTR(_36Code_21539)->length;
    }
    else {
        _len_24916 = 1;
    }

    /** shift.e:408		while pc <= len do*/
L6: 
    if (_pc_24911 > _len_24916)
    goto L7; // [115] 278

    /** shift.e:409			op = Code[pc]*/
    _2 = (object)SEQ_PTR(_36Code_21539);
    _op_24912 = (object)*(((s1_ptr)_2)->base + _pc_24911);
    if (!IS_ATOM_INT(_op_24912)){
        _op_24912 = (object)DBL_PTR(_op_24912)->dbl;
    }

    /** shift.e:410			if pc < start or pc > finish then*/
    _13945 = (_pc_24911 < _start_24893);
    if (_13945 != 0) {
        goto L8; // [135] 148
    }
    _13947 = (_pc_24911 > _finish_24913);
    if (_13947 == 0)
    {
        DeRef(_13947);
        _13947 = NOVALUE;
        goto L9; // [144] 223
    }
    else{
        DeRef(_13947);
        _13947 = NOVALUE;
    }
L8: 

    /** shift.e:412				if length( op_info_addr[op] ) then*/
    _2 = (object)SEQ_PTR(_66op_info_addr_24249);
    _13948 = (object)*(((s1_ptr)_2)->base + _op_24912);
    if (IS_SEQUENCE(_13948)){
            _13949 = SEQ_PTR(_13948)->length;
    }
    else {
        _13949 = 1;
    }
    _13948 = NOVALUE;
    if (_13949 == 0)
    {
        _13949 = NOVALUE;
        goto LA; // [159] 222
    }
    else{
        _13949 = NOVALUE;
    }

    /** shift.e:414					switch op with fallthru do*/
    _0 = _op_24912;
    switch ( _0 ){ 

        /** shift.e:415						case SWITCH then*/
        case 185:
        case 193:
        case 192:
        case 202:

        /** shift.e:420							shift_switch( pc, start, amount )*/
        _66shift_switch(_pc_24911, _start_24893, _amount_24894);

        /** shift.e:421							break*/
        goto LB; // [188] 221

        /** shift.e:423						case else*/
        default:

        /** shift.e:424							int = op_info_addr[op][1]*/
        _2 = (object)SEQ_PTR(_66op_info_addr_24249);
        _13952 = (object)*(((s1_ptr)_2)->base + _op_24912);
        _2 = (object)SEQ_PTR(_13952);
        _int_24898 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_int_24898)){
            _int_24898 = (object)DBL_PTR(_int_24898)->dbl;
        }
        _13952 = NOVALUE;

        /** shift.e:425							shift_addr( pc + int, amount, start, bound )*/
        _13954 = _pc_24911 + _int_24898;
        if ((object)((uintptr_t)_13954 + (uintptr_t)HIGH_BITS) >= 0){
            _13954 = NewDouble((eudouble)_13954);
        }
        _66shift_addr(_13954, _amount_24894, _start_24893, _bound_24895);
        _13954 = NOVALUE;
    ;}LB: 
LA: 
L9: 

    /** shift.e:430			integer size_type = op_info_size_type[op]*/
    _2 = (object)SEQ_PTR(_66op_info_size_type_24247);
    _size_type_24941 = (object)*(((s1_ptr)_2)->base + _op_24912);
    if (!IS_ATOM_INT(_size_type_24941))
    _size_type_24941 = (object)DBL_PTR(_size_type_24941)->dbl;

    /** shift.e:431			if size_type = FIXED_SIZE then*/
    if (_size_type_24941 != 1)
    goto LC; // [233] 254

    /** shift.e:433				pc += op_info_size[op]*/
    _2 = (object)SEQ_PTR(_66op_info_size_24248);
    _13957 = (object)*(((s1_ptr)_2)->base + _op_24912);
    if (IS_ATOM_INT(_13957)) {
        _pc_24911 = _pc_24911 + _13957;
    }
    else {
        _pc_24911 = binary_op(PLUS, _pc_24911, _13957);
    }
    _13957 = NOVALUE;
    if (!IS_ATOM_INT(_pc_24911)) {
        _1 = (object)(DBL_PTR(_pc_24911)->dbl);
        DeRefDS(_pc_24911);
        _pc_24911 = _1;
    }
    goto LD; // [251] 271
LC: 

    /** shift.e:435				pc += variable_op_size( pc, op )*/
    RefDS(_36Code_21539);
    _13959 = _66variable_op_size(_pc_24911, _op_24912, _36Code_21539);
    if (IS_ATOM_INT(_13959)) {
        _pc_24911 = _pc_24911 + _13959;
    }
    else {
        _pc_24911 = binary_op(PLUS, _pc_24911, _13959);
    }
    DeRef(_13959);
    _13959 = NOVALUE;
    if (!IS_ATOM_INT(_pc_24911)) {
        _1 = (object)(DBL_PTR(_pc_24911)->dbl);
        DeRefDS(_pc_24911);
        _pc_24911 = _1;
    }
LD: 

    /** shift.e:437		end while*/
    goto L6; // [275] 115
L7: 

    /** shift.e:438		shift_fwd_refs( start, amount )*/
    _44shift_fwd_refs(_start_24893, _amount_24894);

    /** shift.e:439		move_last_pc( amount )*/
    _47move_last_pc(_amount_24894);

    /** shift.e:440	end procedure*/
    DeRef(_13945);
    _13945 = NOVALUE;
    _13948 = NOVALUE;
    return;
    ;
}


void _66insert_code(object _code_24955, object _index_24956)
{
    object _13962 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:443		Code = splice( Code, code, index )*/
    {
        s1_ptr assign_space;
        insert_pos = _index_24956;
        if (insert_pos <= 0) {
            Concat(&_36Code_21539,_code_24955,_36Code_21539);
        }
        else if (insert_pos > SEQ_PTR(_36Code_21539)->length){
            Concat(&_36Code_21539,_36Code_21539,_code_24955);
        }
        else if (IS_SEQUENCE(_code_24955)) {
            if( _36Code_21539 != _36Code_21539 || SEQ_PTR( _36Code_21539 )->ref != 1 ){
                DeRef( _36Code_21539 );
                RefDS( _36Code_21539 );
            }
            assign_space = Add_internal_space( _36Code_21539, insert_pos,((s1_ptr)SEQ_PTR(_code_24955))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_code_24955), _36Code_21539 == _36Code_21539 );
            _36Code_21539 = MAKE_SEQ( assign_space );
        }
        else {
            if( _36Code_21539 == _36Code_21539 && SEQ_PTR( _36Code_21539 )->ref == 1 ){
                _36Code_21539 = Insert( _36Code_21539, _code_24955, insert_pos);
            }
            else {
                DeRef( _36Code_21539 );
                RefDS( _36Code_21539 );
                _36Code_21539 = Insert( _36Code_21539, _code_24955, insert_pos);
            }
        }
    }

    /** shift.e:444		shift( index, length( code ) )*/
    if (IS_SEQUENCE(_code_24955)){
            _13962 = SEQ_PTR(_code_24955)->length;
    }
    else {
        _13962 = 1;
    }
    _66shift(_index_24956, _13962, _index_24956);
    _13962 = NOVALUE;

    /** shift.e:445	end procedure*/
    DeRefDSi(_code_24955);
    return;
    ;
}


void _66replace_code(object _code_24963, object _start_24964, object _finish_24965)
{
    object _13967 = NOVALUE;
    object _13966 = NOVALUE;
    object _13965 = NOVALUE;
    object _13964 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_24964)) {
        _1 = (object)(DBL_PTR(_start_24964)->dbl);
        DeRefDS(_start_24964);
        _start_24964 = _1;
    }
    if (!IS_ATOM_INT(_finish_24965)) {
        _1 = (object)(DBL_PTR(_finish_24965)->dbl);
        DeRefDS(_finish_24965);
        _finish_24965 = _1;
    }

    /** shift.e:448		Code = replace( Code, code, start, finish )*/
    {
        intptr_t p1 = _36Code_21539;
        intptr_t p2 = _code_24963;
        intptr_t p3 = _start_24964;
        intptr_t p4 = _finish_24965;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_36Code_21539;
        Replace( &replace_params );
    }

    /** shift.e:449		shift( start, length( code ) - (finish - start + 1), finish )*/
    if (IS_SEQUENCE(_code_24963)){
            _13964 = SEQ_PTR(_code_24963)->length;
    }
    else {
        _13964 = 1;
    }
    _13965 = _finish_24965 - _start_24964;
    if ((object)((uintptr_t)_13965 +(uintptr_t) HIGH_BITS) >= 0){
        _13965 = NewDouble((eudouble)_13965);
    }
    if (IS_ATOM_INT(_13965)) {
        _13966 = _13965 + 1;
        if (_13966 > MAXINT){
            _13966 = NewDouble((eudouble)_13966);
        }
    }
    else
    _13966 = binary_op(PLUS, 1, _13965);
    DeRef(_13965);
    _13965 = NOVALUE;
    if (IS_ATOM_INT(_13966)) {
        _13967 = _13964 - _13966;
        if ((object)((uintptr_t)_13967 +(uintptr_t) HIGH_BITS) >= 0){
            _13967 = NewDouble((eudouble)_13967);
        }
    }
    else {
        _13967 = NewDouble((eudouble)_13964 - DBL_PTR(_13966)->dbl);
    }
    _13964 = NOVALUE;
    DeRef(_13966);
    _13966 = NOVALUE;
    _66shift(_start_24964, _13967, _finish_24965);
    _13967 = NOVALUE;

    /** shift.e:450	end procedure*/
    DeRefDS(_code_24963);
    return;
    ;
}


object _66current_op(object _pc_24975, object _code_24976)
{
    object _13975 = NOVALUE;
    object _13974 = NOVALUE;
    object _13973 = NOVALUE;
    object _13972 = NOVALUE;
    object _13971 = NOVALUE;
    object _13969 = NOVALUE;
    object _13968 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:456		if pc > length(code) or pc < 1 then*/
    if (IS_SEQUENCE(_code_24976)){
            _13968 = SEQ_PTR(_code_24976)->length;
    }
    else {
        _13968 = 1;
    }
    _13969 = (_pc_24975 > _13968);
    _13968 = NOVALUE;
    if (_13969 != 0) {
        goto L1; // [14] 27
    }
    _13971 = (_pc_24975 < 1);
    if (_13971 == 0)
    {
        DeRef(_13971);
        _13971 = NOVALUE;
        goto L2; // [23] 34
    }
    else{
        DeRef(_13971);
        _13971 = NOVALUE;
    }
L1: 

    /** shift.e:457			return {}*/
    RefDS(_5);
    DeRefDS(_code_24976);
    DeRef(_13969);
    _13969 = NOVALUE;
    return _5;
L2: 

    /** shift.e:459		return code[pc..pc-1+op_size( pc, code )]*/
    _13972 = _pc_24975 - 1;
    if ((object)((uintptr_t)_13972 +(uintptr_t) HIGH_BITS) >= 0){
        _13972 = NewDouble((eudouble)_13972);
    }
    RefDS(_code_24976);
    _13973 = _66op_size(_pc_24975, _code_24976);
    if (IS_ATOM_INT(_13972) && IS_ATOM_INT(_13973)) {
        _13974 = _13972 + _13973;
    }
    else {
        _13974 = binary_op(PLUS, _13972, _13973);
    }
    DeRef(_13972);
    _13972 = NOVALUE;
    DeRef(_13973);
    _13973 = NOVALUE;
    rhs_slice_target = (object_ptr)&_13975;
    RHS_Slice(_code_24976, _pc_24975, _13974);
    DeRefDS(_code_24976);
    DeRef(_13969);
    _13969 = NOVALUE;
    DeRef(_13974);
    _13974 = NOVALUE;
    return _13975;
    ;
}


object _66get_ops(object _pc_24990, object _offset_24991, object _num_ops_24992, object _code_24993)
{
    object _sign_24996 = NOVALUE;
    object _ops_25005 = NOVALUE;
    object _opx_25007 = NOVALUE;
    object _13992 = NOVALUE;
    object _13991 = NOVALUE;
    object _13987 = NOVALUE;
    object _13986 = NOVALUE;
    object _13985 = NOVALUE;
    object _13984 = NOVALUE;
    object _13983 = NOVALUE;
    object _13982 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:466		integer sign = offset >= 0*/
    _sign_24996 = (_offset_24991 >= 0);

    /** shift.e:467		if not sign then*/
    if (_sign_24996 != 0)
    goto L1; // [17] 33

    /** shift.e:468			offset = -offset*/
    _offset_24991 = - _offset_24991;

    /** shift.e:469			sign = -1*/
    _sign_24996 = -1;
L1: 

    /** shift.e:472		while offset do*/
L2: 
    if (_offset_24991 == 0)
    {
        goto L3; // [38] 63
    }
    else{
    }

    /** shift.e:473			pc = advance( pc )*/
    RefDS(_36Code_21539);
    _pc_24990 = _66advance(_pc_24990, _36Code_21539);
    if (!IS_ATOM_INT(_pc_24990)) {
        _1 = (object)(DBL_PTR(_pc_24990)->dbl);
        DeRefDS(_pc_24990);
        _pc_24990 = _1;
    }

    /** shift.e:474			offset -= sign*/
    _offset_24991 = _offset_24991 - _sign_24996;

    /** shift.e:475		end while*/
    goto L2; // [60] 38
L3: 

    /** shift.e:477		sequence ops = repeat( 0, num_ops )*/
    DeRef(_ops_25005);
    _ops_25005 = Repeat(0, _num_ops_24992);

    /** shift.e:478		integer opx = 1*/
    _opx_25007 = 1;

    /** shift.e:479		while num_ops and pc <= length(code) do*/
L4: 
    if (_num_ops_24992 == 0) {
        goto L5; // [79] 137
    }
    if (IS_SEQUENCE(_code_24993)){
            _13983 = SEQ_PTR(_code_24993)->length;
    }
    else {
        _13983 = 1;
    }
    _13984 = (_pc_24990 <= _13983);
    _13983 = NOVALUE;
    if (_13984 == 0)
    {
        DeRef(_13984);
        _13984 = NOVALUE;
        goto L5; // [91] 137
    }
    else{
        DeRef(_13984);
        _13984 = NOVALUE;
    }

    /** shift.e:480			ops[opx] = current_op( pc )*/
    RefDS(_36Code_21539);
    _13985 = _66current_op(_pc_24990, _36Code_21539);
    _2 = (object)SEQ_PTR(_ops_25005);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _ops_25005 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _opx_25007);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13985;
    if( _1 != _13985 ){
        DeRef(_1);
    }
    _13985 = NOVALUE;

    /** shift.e:481			pc += length( ops[opx] )*/
    _2 = (object)SEQ_PTR(_ops_25005);
    _13986 = (object)*(((s1_ptr)_2)->base + _opx_25007);
    if (IS_SEQUENCE(_13986)){
            _13987 = SEQ_PTR(_13986)->length;
    }
    else {
        _13987 = 1;
    }
    _13986 = NOVALUE;
    _pc_24990 = _pc_24990 + _13987;
    _13987 = NOVALUE;

    /** shift.e:482			opx += 1*/
    _opx_25007 = _opx_25007 + 1;

    /** shift.e:483			num_ops -= 1*/
    _num_ops_24992 = _num_ops_24992 - 1;

    /** shift.e:484		end while*/
    goto L4; // [134] 79
L5: 

    /** shift.e:485		if num_ops then*/
    if (_num_ops_24992 == 0)
    {
        goto L6; // [139] 156
    }
    else{
    }

    /** shift.e:486			ops = head( ops, length( ops ) - num_ops )*/
    if (IS_SEQUENCE(_ops_25005)){
            _13991 = SEQ_PTR(_ops_25005)->length;
    }
    else {
        _13991 = 1;
    }
    _13992 = _13991 - _num_ops_24992;
    if ((object)((uintptr_t)_13992 +(uintptr_t) HIGH_BITS) >= 0){
        _13992 = NewDouble((eudouble)_13992);
    }
    _13991 = NOVALUE;
    {
        int len = SEQ_PTR(_ops_25005)->length;
        int size = (IS_ATOM_INT(_13992)) ? _13992 : (object)(DBL_PTR(_13992)->dbl);
        if (size <= 0){
            DeRef( _ops_25005 );
            _ops_25005 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_ops_25005);
            DeRef(_ops_25005);
            _ops_25005 = _ops_25005;
        }
        else{
            Head(SEQ_PTR(_ops_25005),size+1,&_ops_25005);
        }
    }
    DeRef(_13992);
    _13992 = NOVALUE;
L6: 

    /** shift.e:488		return ops*/
    DeRefDS(_code_24993);
    _13986 = NOVALUE;
    return _ops_25005;
    ;
}


object _66find_ops(object _pc_25025, object _op_25026, object _code_25027)
{
    object _ops_25030 = NOVALUE;
    object _found_op_25034 = NOVALUE;
    object _14001 = NOVALUE;
    object _13999 = NOVALUE;
    object _13997 = NOVALUE;
    object _13994 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:492		sequence ops = {}*/
    RefDS(_5);
    DeRef(_ops_25030);
    _ops_25030 = _5;

    /** shift.e:493		while pc <= length(code) do*/
L1: 
    if (IS_SEQUENCE(_code_25027)){
            _13994 = SEQ_PTR(_code_25027)->length;
    }
    else {
        _13994 = 1;
    }
    if (_pc_25025 > _13994)
    goto L2; // [22] 74

    /** shift.e:494			sequence found_op = current_op( pc )*/
    RefDS(_36Code_21539);
    _0 = _found_op_25034;
    _found_op_25034 = _66current_op(_pc_25025, _36Code_21539);
    DeRef(_0);

    /** shift.e:495			if found_op[1] = op then*/
    _2 = (object)SEQ_PTR(_found_op_25034);
    _13997 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _13997, _op_25026)){
        _13997 = NOVALUE;
        goto L3; // [43] 58
    }
    _13997 = NOVALUE;

    /** shift.e:496				ops = append( ops, { pc, found_op } )*/
    RefDS(_found_op_25034);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _pc_25025;
    ((intptr_t *)_2)[2] = _found_op_25034;
    _13999 = MAKE_SEQ(_1);
    RefDS(_13999);
    Append(&_ops_25030, _ops_25030, _13999);
    DeRefDS(_13999);
    _13999 = NOVALUE;
L3: 

    /** shift.e:498			pc += length( found_op )*/
    if (IS_SEQUENCE(_found_op_25034)){
            _14001 = SEQ_PTR(_found_op_25034)->length;
    }
    else {
        _14001 = 1;
    }
    _pc_25025 = _pc_25025 + _14001;
    _14001 = NOVALUE;
    DeRefDS(_found_op_25034);
    _found_op_25034 = NOVALUE;

    /** shift.e:499		end while*/
    goto L1; // [71] 19
L2: 

    /** shift.e:500		return ops*/
    DeRefDS(_code_25027);
    return _ops_25030;
    ;
}


object _66get_target_sym(object _opseq_25046)
{
    object _op_25050 = NOVALUE;
    object _info_25052 = NOVALUE;
    object _targets_25068 = NOVALUE;
    object _sub_25083 = NOVALUE;
    object _14033 = NOVALUE;
    object _14032 = NOVALUE;
    object _14031 = NOVALUE;
    object _14030 = NOVALUE;
    object _14029 = NOVALUE;
    object _14028 = NOVALUE;
    object _14027 = NOVALUE;
    object _14025 = NOVALUE;
    object _14021 = NOVALUE;
    object _14020 = NOVALUE;
    object _14019 = NOVALUE;
    object _14018 = NOVALUE;
    object _14016 = NOVALUE;
    object _14015 = NOVALUE;
    object _14014 = NOVALUE;
    object _14013 = NOVALUE;
    object _14010 = NOVALUE;
    object _14009 = NOVALUE;
    object _14007 = NOVALUE;
    object _14003 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:509		if not length( opseq ) then*/
    if (IS_SEQUENCE(_opseq_25046)){
            _14003 = SEQ_PTR(_opseq_25046)->length;
    }
    else {
        _14003 = 1;
    }
    if (_14003 != 0)
    goto L1; // [8] 18
    _14003 = NOVALUE;

    /** shift.e:510			return 0*/
    DeRefDS(_opseq_25046);
    DeRef(_info_25052);
    return 0;
L1: 

    /** shift.e:512		integer op = opseq[1]*/
    _2 = (object)SEQ_PTR(_opseq_25046);
    _op_25050 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_op_25050))
    _op_25050 = (object)DBL_PTR(_op_25050)->dbl;

    /** shift.e:513		sequence info = op_info[op]*/
    DeRef(_info_25052);
    _2 = (object)SEQ_PTR(_66op_info_24241);
    _info_25052 = (object)*(((s1_ptr)_2)->base + _op_25050);
    Ref(_info_25052);

    /** shift.e:515		if info[OP_SIZE_TYPE] = FIXED_SIZE then*/
    _2 = (object)SEQ_PTR(_info_25052);
    _14007 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14007, 1)){
        _14007 = NOVALUE;
        goto L2; // [40] 157
    }
    _14007 = NOVALUE;

    /** shift.e:516			switch length( info[OP_TARGET] ) do*/
    _2 = (object)SEQ_PTR(_info_25052);
    _14009 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_14009)){
            _14010 = SEQ_PTR(_14009)->length;
    }
    else {
        _14010 = 1;
    }
    _14009 = NOVALUE;
    _0 = _14010;
    _14010 = NOVALUE;
    switch ( _0 ){ 

        /** shift.e:517				case 0 then*/
        case 0:

        /** shift.e:518					break*/
        goto L3; // [64] 152
        goto L3; // [66] 152

        /** shift.e:520				case 1 then*/
        case 1:

        /** shift.e:521					return opseq[info[OP_TARGET][1]+1]*/
        _2 = (object)SEQ_PTR(_info_25052);
        _14013 = (object)*(((s1_ptr)_2)->base + 4);
        _2 = (object)SEQ_PTR(_14013);
        _14014 = (object)*(((s1_ptr)_2)->base + 1);
        _14013 = NOVALUE;
        if (IS_ATOM_INT(_14014)) {
            _14015 = _14014 + 1;
        }
        else
        _14015 = binary_op(PLUS, 1, _14014);
        _14014 = NOVALUE;
        _2 = (object)SEQ_PTR(_opseq_25046);
        if (!IS_ATOM_INT(_14015)){
            _14016 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14015)->dbl));
        }
        else{
            _14016 = (object)*(((s1_ptr)_2)->base + _14015);
        }
        Ref(_14016);
        DeRefDS(_opseq_25046);
        DeRefDS(_info_25052);
        _14009 = NOVALUE;
        DeRef(_14015);
        _14015 = NOVALUE;
        return _14016;
        goto L3; // [94] 152

        /** shift.e:523				case else*/
        default:

        /** shift.e:524					sequence targets = info[OP_TARGET]*/
        DeRef(_targets_25068);
        _2 = (object)SEQ_PTR(_info_25052);
        _targets_25068 = (object)*(((s1_ptr)_2)->base + 4);
        Ref(_targets_25068);

        /** shift.e:525					for i = 1 to length( targets ) do*/
        if (IS_SEQUENCE(_targets_25068)){
                _14018 = SEQ_PTR(_targets_25068)->length;
        }
        else {
            _14018 = 1;
        }
        {
            object _i_25071;
            _i_25071 = 1;
L4: 
            if (_i_25071 > _14018){
                goto L5; // [113] 145
            }

            /** shift.e:526						targets[i] = opseq[targets[i] + 1]*/
            _2 = (object)SEQ_PTR(_targets_25068);
            _14019 = (object)*(((s1_ptr)_2)->base + _i_25071);
            if (IS_ATOM_INT(_14019)) {
                _14020 = _14019 + 1;
            }
            else
            _14020 = binary_op(PLUS, 1, _14019);
            _14019 = NOVALUE;
            _2 = (object)SEQ_PTR(_opseq_25046);
            if (!IS_ATOM_INT(_14020)){
                _14021 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14020)->dbl));
            }
            else{
                _14021 = (object)*(((s1_ptr)_2)->base + _14020);
            }
            Ref(_14021);
            _2 = (object)SEQ_PTR(_targets_25068);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _targets_25068 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _i_25071);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _14021;
            if( _1 != _14021 ){
                DeRef(_1);
            }
            _14021 = NOVALUE;

            /** shift.e:527					end for*/
            _i_25071 = _i_25071 + 1;
            goto L4; // [140] 120
L5: 
            ;
        }

        /** shift.e:529					return targets*/
        DeRefDS(_opseq_25046);
        DeRef(_info_25052);
        _14016 = NOVALUE;
        _14009 = NOVALUE;
        DeRef(_14015);
        _14015 = NOVALUE;
        DeRef(_14020);
        _14020 = NOVALUE;
        return _targets_25068;
    ;}L3: 
    DeRef(_targets_25068);
    _targets_25068 = NOVALUE;
    goto L6; // [154] 253
L2: 

    /** shift.e:535			switch op do*/
    _0 = _op_25050;
    switch ( _0 ){ 

        /** shift.e:536				case PROC, PROC_TAIL then*/
        case 27:
        case 203:

        /** shift.e:537					symtab_index sub = opseq[2]*/
        _2 = (object)SEQ_PTR(_opseq_25046);
        _sub_25083 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sub_25083)){
            _sub_25083 = (object)DBL_PTR(_sub_25083)->dbl;
        }

        /** shift.e:538					if sym_token( sub ) = FUNC then*/
        _14025 = _54sym_token(_sub_25083);
        if (binary_op_a(NOTEQ, _14025, 501)){
            DeRef(_14025);
            _14025 = NOVALUE;
            goto L7; // [186] 204
        }
        DeRef(_14025);
        _14025 = NOVALUE;

        /** shift.e:539						return opseq[$]*/
        if (IS_SEQUENCE(_opseq_25046)){
                _14027 = SEQ_PTR(_opseq_25046)->length;
        }
        else {
            _14027 = 1;
        }
        _2 = (object)SEQ_PTR(_opseq_25046);
        _14028 = (object)*(((s1_ptr)_2)->base + _14027);
        Ref(_14028);
        DeRefDS(_opseq_25046);
        DeRef(_info_25052);
        _14016 = NOVALUE;
        _14009 = NOVALUE;
        DeRef(_14015);
        _14015 = NOVALUE;
        DeRef(_14020);
        _14020 = NOVALUE;
        return _14028;
L7: 
        goto L8; // [206] 252

        /** shift.e:542				case FUNC_FORWARD then*/
        case 196:

        /** shift.e:543					return opseq[$]*/
        if (IS_SEQUENCE(_opseq_25046)){
                _14029 = SEQ_PTR(_opseq_25046)->length;
        }
        else {
            _14029 = 1;
        }
        _2 = (object)SEQ_PTR(_opseq_25046);
        _14030 = (object)*(((s1_ptr)_2)->base + _14029);
        Ref(_14030);
        DeRefDS(_opseq_25046);
        DeRef(_info_25052);
        _14028 = NOVALUE;
        _14016 = NOVALUE;
        _14009 = NOVALUE;
        DeRef(_14015);
        _14015 = NOVALUE;
        DeRef(_14020);
        _14020 = NOVALUE;
        return _14030;
        goto L8; // [225] 252

        /** shift.e:545				case RIGHT_BRACE_N, CONCAT_N then*/
        case 31:
        case 157:

        /** shift.e:546					return opseq[opseq[2]+2]*/
        _2 = (object)SEQ_PTR(_opseq_25046);
        _14031 = (object)*(((s1_ptr)_2)->base + 2);
        if (IS_ATOM_INT(_14031)) {
            _14032 = _14031 + 2;
        }
        else {
            _14032 = binary_op(PLUS, _14031, 2);
        }
        _14031 = NOVALUE;
        _2 = (object)SEQ_PTR(_opseq_25046);
        if (!IS_ATOM_INT(_14032)){
            _14033 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14032)->dbl));
        }
        else{
            _14033 = (object)*(((s1_ptr)_2)->base + _14032);
        }
        Ref(_14033);
        DeRefDS(_opseq_25046);
        DeRef(_info_25052);
        DeRef(_14032);
        _14032 = NOVALUE;
        _14028 = NOVALUE;
        _14016 = NOVALUE;
        _14030 = NOVALUE;
        _14009 = NOVALUE;
        DeRef(_14015);
        _14015 = NOVALUE;
        DeRef(_14020);
        _14020 = NOVALUE;
        return _14033;
    ;}L8: 
L6: 

    /** shift.e:551		return 0*/
    DeRefDS(_opseq_25046);
    DeRef(_info_25052);
    DeRef(_14032);
    _14032 = NOVALUE;
    _14028 = NOVALUE;
    _14033 = NOVALUE;
    _14016 = NOVALUE;
    _14030 = NOVALUE;
    _14009 = NOVALUE;
    DeRef(_14015);
    _14015 = NOVALUE;
    DeRef(_14020);
    _14020 = NOVALUE;
    return 0;
    ;
}



// 0x23E5C5E8
