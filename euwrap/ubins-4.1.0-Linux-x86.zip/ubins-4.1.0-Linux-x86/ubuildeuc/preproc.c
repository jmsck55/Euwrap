// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _64is_file_newer(object _f1_24042, object _f2_24043)
{
    object _d1_24044 = NOVALUE;
    object _d2_24047 = NOVALUE;
    object _diff_2__tmp_at33_24056 = NOVALUE;
    object _diff_1__tmp_at33_24055 = NOVALUE;
    object _diff_inlined_diff_at_33_24054 = NOVALUE;
    object _13523 = NOVALUE;
    object _0, _1, _2;
    

    /** preproc.e:22		object d1 = file_timestamp(f1)*/
    RefDS(_f1_24042);
    _0 = _d1_24044;
    _d1_24044 = _17file_timestamp(_f1_24042);
    DeRef(_0);

    /** preproc.e:23		object d2 = file_timestamp(f2)*/
    RefDS(_f2_24043);
    _0 = _d2_24047;
    _d2_24047 = _17file_timestamp(_f2_24043);
    DeRef(_0);

    /** preproc.e:25		if atom(d2) then return 1 end if*/
    _13523 = IS_ATOM(_d2_24047);
    if (_13523 == 0)
    {
        _13523 = NOVALUE;
        goto L1; // [22] 30
    }
    else{
        _13523 = NOVALUE;
    }
    DeRefDS(_f1_24042);
    DeRefDS(_f2_24043);
    DeRef(_d1_24044);
    DeRef(_d2_24047);
    return 1;
L1: 

    /** preproc.e:27		if dt:diff(d1, d2) < 0 then*/

    /** datetime.e:1253		return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_24047);
    _0 = _diff_1__tmp_at33_24055;
    _diff_1__tmp_at33_24055 = _18datetimeToSeconds(_d2_24047);
    DeRef(_0);
    Ref(_d1_24044);
    _0 = _diff_2__tmp_at33_24056;
    _diff_2__tmp_at33_24056 = _18datetimeToSeconds(_d1_24044);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_33_24054);
    if (IS_ATOM_INT(_diff_1__tmp_at33_24055) && IS_ATOM_INT(_diff_2__tmp_at33_24056)) {
        _diff_inlined_diff_at_33_24054 = _diff_1__tmp_at33_24055 - _diff_2__tmp_at33_24056;
        if ((object)((uintptr_t)_diff_inlined_diff_at_33_24054 +(uintptr_t) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_33_24054 = NewDouble((eudouble)_diff_inlined_diff_at_33_24054);
        }
    }
    else {
        _diff_inlined_diff_at_33_24054 = binary_op(MINUS, _diff_1__tmp_at33_24055, _diff_2__tmp_at33_24056);
    }
    DeRef(_diff_1__tmp_at33_24055);
    _diff_1__tmp_at33_24055 = NOVALUE;
    DeRef(_diff_2__tmp_at33_24056);
    _diff_2__tmp_at33_24056 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_33_24054, 0)){
        goto L2; // [49] 60
    }

    /** preproc.e:28			return 1*/
    DeRefDS(_f1_24042);
    DeRefDS(_f2_24043);
    DeRef(_d1_24044);
    DeRef(_d2_24047);
    return 1;
L2: 

    /** preproc.e:31		return 0*/
    DeRefDS(_f1_24042);
    DeRefDS(_f2_24043);
    DeRef(_d1_24044);
    DeRef(_d2_24047);
    return 0;
    ;
}


void _64add_preprocessor(object _file_ext_24060, object _command_24061, object _params_24062)
{
    object _tmp_24065 = NOVALUE;
    object _file_exts_24075 = NOVALUE;
    object _exts_24081 = NOVALUE;
    object _13540 = NOVALUE;
    object _13539 = NOVALUE;
    object _13538 = NOVALUE;
    object _13537 = NOVALUE;
    object _13535 = NOVALUE;
    object _13530 = NOVALUE;
    object _13525 = NOVALUE;
    object _0, _1, _2;
    

    /** preproc.e:46		if atom(command) then*/
    _13525 = 1;
    if (_13525 == 0)
    {
        _13525 = NOVALUE;
        goto L1; // [8] 53
    }
    else{
        _13525 = NOVALUE;
    }

    /** preproc.e:47			sequence tmp = split( file_ext, ":")*/
    RefDS(_file_ext_24060);
    RefDS(_13526);
    _0 = _tmp_24065;
    _tmp_24065 = _23split(_file_ext_24060, _13526, 0, 0);
    DeRef(_0);

    /** preproc.e:48			file_ext = tmp[1]*/
    DeRefDS(_file_ext_24060);
    _2 = (object)SEQ_PTR(_tmp_24065);
    _file_ext_24060 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_file_ext_24060);

    /** preproc.e:49			command = tmp[2]*/
    _2 = (object)SEQ_PTR(_tmp_24065);
    _command_24061 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_command_24061);

    /** preproc.e:50			if length(tmp) >= 3 then*/
    if (IS_SEQUENCE(_tmp_24065)){
            _13530 = SEQ_PTR(_tmp_24065)->length;
    }
    else {
        _13530 = 1;
    }
    if (_13530 < 3)
    goto L2; // [41] 52

    /** preproc.e:51				params = tmp[3]*/
    _2 = (object)SEQ_PTR(_tmp_24065);
    _params_24062 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_params_24062);
L2: 
L1: 
    DeRef(_tmp_24065);
    _tmp_24065 = NOVALUE;

    /** preproc.e:55		sequence file_exts = split( file_ext, "," )*/
    RefDS(_file_ext_24060);
    RefDS(_13533);
    _0 = _file_exts_24075;
    _file_exts_24075 = _23split(_file_ext_24060, _13533, 0, 0);
    DeRef(_0);

    /** preproc.e:57		if atom(params) then*/
    _13535 = IS_ATOM(_params_24062);
    if (_13535 == 0)
    {
        _13535 = NOVALUE;
        goto L3; // [71] 80
    }
    else{
        _13535 = NOVALUE;
    }

    /** preproc.e:58			params = ""*/
    RefDS(_5);
    DeRef(_params_24062);
    _params_24062 = _5;
L3: 

    /** preproc.e:61		sequence exts = split(file_ext, ",")*/
    RefDS(_file_ext_24060);
    RefDS(_13533);
    _0 = _exts_24081;
    _exts_24081 = _23split(_file_ext_24060, _13533, 0, 0);
    DeRef(_0);

    /** preproc.e:62		for i = 1 to length(exts) do*/
    if (IS_SEQUENCE(_exts_24081)){
            _13537 = SEQ_PTR(_exts_24081)->length;
    }
    else {
        _13537 = 1;
    }
    {
        object _i_24085;
        _i_24085 = 1;
L4: 
        if (_i_24085 > _13537){
            goto L5; // [96] 135
        }

        /** preproc.e:63			preprocessors &= { { exts[i], command, params, -1 } }*/
        _2 = (object)SEQ_PTR(_exts_24081);
        _13538 = (object)*(((s1_ptr)_2)->base + _i_24085);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_13538);
        ((intptr_t*)_2)[1] = _13538;
        Ref(_command_24061);
        ((intptr_t*)_2)[2] = _command_24061;
        Ref(_params_24062);
        ((intptr_t*)_2)[3] = _params_24062;
        ((intptr_t*)_2)[4] = -1;
        _13539 = MAKE_SEQ(_1);
        _13538 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _13539;
        _13540 = MAKE_SEQ(_1);
        _13539 = NOVALUE;
        Concat((object_ptr)&_37preprocessors_15423, _37preprocessors_15423, _13540);
        DeRefDS(_13540);
        _13540 = NOVALUE;

        /** preproc.e:64		end for*/
        _i_24085 = _i_24085 + 1;
        goto L4; // [130] 103
L5: 
        ;
    }

    /** preproc.e:65	end procedure */
    DeRefDS(_file_ext_24060);
    DeRef(_command_24061);
    DeRef(_params_24062);
    DeRef(_file_exts_24075);
    DeRef(_exts_24081);
    return;
    ;
}


object _64maybe_preprocess(object _fname_24094)
{
    object _pp_24095 = NOVALUE;
    object _pp_id_24096 = NOVALUE;
    object _fext_24100 = NOVALUE;
    object _post_fname_24117 = NOVALUE;
    object _rid_24145 = NOVALUE;
    object _dll_id_24149 = NOVALUE;
    object _public_cmd_args_24185 = NOVALUE;
    object _cmd_args_24188 = NOVALUE;
    object _cmd_24217 = NOVALUE;
    object _pcmd_24222 = NOVALUE;
    object _result_24227 = NOVALUE;
    object _13619 = NOVALUE;
    object _13618 = NOVALUE;
    object _13613 = NOVALUE;
    object _13612 = NOVALUE;
    object _13610 = NOVALUE;
    object _13609 = NOVALUE;
    object _13607 = NOVALUE;
    object _13605 = NOVALUE;
    object _13604 = NOVALUE;
    object _13602 = NOVALUE;
    object _13599 = NOVALUE;
    object _13597 = NOVALUE;
    object _13595 = NOVALUE;
    object _13593 = NOVALUE;
    object _13592 = NOVALUE;
    object _13590 = NOVALUE;
    object _13589 = NOVALUE;
    object _13587 = NOVALUE;
    object _13584 = NOVALUE;
    object _13583 = NOVALUE;
    object _13582 = NOVALUE;
    object _13580 = NOVALUE;
    object _13576 = NOVALUE;
    object _13574 = NOVALUE;
    object _13573 = NOVALUE;
    object _13572 = NOVALUE;
    object _13568 = NOVALUE;
    object _13565 = NOVALUE;
    object _13564 = NOVALUE;
    object _13563 = NOVALUE;
    object _13561 = NOVALUE;
    object _13558 = NOVALUE;
    object _13556 = NOVALUE;
    object _13555 = NOVALUE;
    object _13553 = NOVALUE;
    object _13551 = NOVALUE;
    object _13549 = NOVALUE;
    object _13547 = NOVALUE;
    object _13546 = NOVALUE;
    object _13545 = NOVALUE;
    object _13544 = NOVALUE;
    object _13542 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** preproc.e:81		sequence pp = {}*/
    RefDS(_5);
    DeRef(_pp_24095);
    _pp_24095 = _5;

    /** preproc.e:84		if length(preprocessors) then*/
    if (IS_SEQUENCE(_37preprocessors_15423)){
            _13542 = SEQ_PTR(_37preprocessors_15423)->length;
    }
    else {
        _13542 = 1;
    }
    if (_13542 == 0)
    {
        _13542 = NOVALUE;
        goto L1; // [17] 89
    }
    else{
        _13542 = NOVALUE;
    }

    /** preproc.e:85			sequence fext = fileext(fname)*/
    RefDS(_fname_24094);
    _0 = _fext_24100;
    _fext_24100 = _17fileext(_fname_24094);
    DeRef(_0);

    /** preproc.e:87			for i = 1 to length(preprocessors) do*/
    if (IS_SEQUENCE(_37preprocessors_15423)){
            _13544 = SEQ_PTR(_37preprocessors_15423)->length;
    }
    else {
        _13544 = 1;
    }
    {
        object _i_24104;
        _i_24104 = 1;
L2: 
        if (_i_24104 > _13544){
            goto L3; // [35] 88
        }

        /** preproc.e:88				if equal(fext, preprocessors[i][1]) then*/
        _2 = (object)SEQ_PTR(_37preprocessors_15423);
        _13545 = (object)*(((s1_ptr)_2)->base + _i_24104);
        _2 = (object)SEQ_PTR(_13545);
        _13546 = (object)*(((s1_ptr)_2)->base + 1);
        _13545 = NOVALUE;
        if (_fext_24100 == _13546)
        _13547 = 1;
        else if (IS_ATOM_INT(_fext_24100) && IS_ATOM_INT(_13546))
        _13547 = 0;
        else
        _13547 = (compare(_fext_24100, _13546) == 0);
        _13546 = NOVALUE;
        if (_13547 == 0)
        {
            _13547 = NOVALUE;
            goto L4; // [58] 81
        }
        else{
            _13547 = NOVALUE;
        }

        /** preproc.e:89					pp_id = i*/
        _pp_id_24096 = _i_24104;

        /** preproc.e:90					pp = preprocessors[pp_id]*/
        DeRef(_pp_24095);
        _2 = (object)SEQ_PTR(_37preprocessors_15423);
        _pp_24095 = (object)*(((s1_ptr)_2)->base + _pp_id_24096);
        RefDS(_pp_24095);

        /** preproc.e:91					exit*/
        goto L3; // [78] 88
L4: 

        /** preproc.e:93			end for*/
        _i_24104 = _i_24104 + 1;
        goto L2; // [83] 42
L3: 
        ;
    }
L1: 
    DeRef(_fext_24100);
    _fext_24100 = NOVALUE;

    /** preproc.e:96		if length(pp) = 0 then */
    if (IS_SEQUENCE(_pp_24095)){
            _13549 = SEQ_PTR(_pp_24095)->length;
    }
    else {
        _13549 = 1;
    }
    if (_13549 != 0)
    goto L5; // [96] 107

    /** preproc.e:97			return fname*/
    DeRefDS(_pp_24095);
    DeRef(_post_fname_24117);
    return _fname_24094;
L5: 

    /** preproc.e:100		sequence post_fname = filebase(fname) & ".pp." & fileext(fname)*/
    RefDS(_fname_24094);
    _13551 = _17filebase(_fname_24094);
    RefDS(_fname_24094);
    _13553 = _17fileext(_fname_24094);
    {
        object concat_list[3];

        concat_list[0] = _13553;
        concat_list[1] = _13552;
        concat_list[2] = _13551;
        Concat_N((object_ptr)&_post_fname_24117, concat_list, 3);
    }
    DeRef(_13553);
    _13553 = NOVALUE;
    DeRef(_13551);
    _13551 = NOVALUE;

    /** preproc.e:101		if length(dirname(fname)) > 0 then*/
    RefDS(_fname_24094);
    _13555 = _17dirname(_fname_24094, 0);
    if (IS_SEQUENCE(_13555)){
            _13556 = SEQ_PTR(_13555)->length;
    }
    else {
        _13556 = 1;
    }
    DeRef(_13555);
    _13555 = NOVALUE;
    if (_13556 <= 0)
    goto L6; // [133] 153

    /** preproc.e:102			post_fname = dirname(fname) & SLASH & post_fname*/
    RefDS(_fname_24094);
    _13558 = _17dirname(_fname_24094, 0);
    {
        object concat_list[3];

        concat_list[0] = _post_fname_24117;
        concat_list[1] = 47;
        concat_list[2] = _13558;
        Concat_N((object_ptr)&_post_fname_24117, concat_list, 3);
    }
    DeRef(_13558);
    _13558 = NOVALUE;
L6: 

    /** preproc.e:105		if not force_preprocessor then*/
    if (_37force_preprocessor_15424 != 0)
    goto L7; // [157] 178

    /** preproc.e:106			if not is_file_newer(fname, post_fname) then*/
    RefDS(_fname_24094);
    RefDS(_post_fname_24117);
    _13561 = _64is_file_newer(_fname_24094, _post_fname_24117);
    if (IS_ATOM_INT(_13561)) {
        if (_13561 != 0){
            DeRef(_13561);
            _13561 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    else {
        if (DBL_PTR(_13561)->dbl != 0.0){
            DeRef(_13561);
            _13561 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    DeRef(_13561);
    _13561 = NOVALUE;

    /** preproc.e:107				return post_fname*/
    DeRefDS(_fname_24094);
    DeRef(_pp_24095);
    _13555 = NOVALUE;
    return _post_fname_24117;
L8: 
L7: 

    /** preproc.e:112		if equal(fileext(pp[PP_COMMAND]), SHARED_LIB_EXT) then*/
    _2 = (object)SEQ_PTR(_pp_24095);
    _13563 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_13563);
    _13564 = _17fileext(_13563);
    _13563 = NOVALUE;
    if (_13564 == _17SHARED_LIB_EXT_5976)
    _13565 = 1;
    else if (IS_ATOM_INT(_13564) && IS_ATOM_INT(_17SHARED_LIB_EXT_5976))
    _13565 = 0;
    else
    _13565 = (compare(_13564, _17SHARED_LIB_EXT_5976) == 0);
    DeRef(_13564);
    _13564 = NOVALUE;
    if (_13565 == 0)
    {
        _13565 = NOVALUE;
        goto L9; // [194] 348
    }
    else{
        _13565 = NOVALUE;
    }

    /** preproc.e:113			integer rid = pp[PP_RID]*/
    _2 = (object)SEQ_PTR(_pp_24095);
    _rid_24145 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_rid_24145))
    _rid_24145 = (object)DBL_PTR(_rid_24145)->dbl;

    /** preproc.e:114			if rid = -1 then*/
    if (_rid_24145 != -1)
    goto LA; // [205] 307

    /** preproc.e:115				integer dll_id = open_dll(pp[PP_COMMAND])*/
    _2 = (object)SEQ_PTR(_pp_24095);
    _13568 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_13568);
    _dll_id_24149 = _12open_dll(_13568);
    _13568 = NOVALUE;
    if (!IS_ATOM_INT(_dll_id_24149)) {
        _1 = (object)(DBL_PTR(_dll_id_24149)->dbl);
        DeRefDS(_dll_id_24149);
        _dll_id_24149 = _1;
    }

    /** preproc.e:116				if dll_id = -1 then*/
    if (_dll_id_24149 != -1)
    goto LB; // [223] 247

    /** preproc.e:117					CompileErr(sprintf("Preprocessor shared library '%s' could not be loaded\n",*/
    _2 = (object)SEQ_PTR(_pp_24095);
    _13572 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_13572);
    ((intptr_t*)_2)[1] = _13572;
    _13573 = MAKE_SEQ(_1);
    _13572 = NOVALUE;
    _13574 = EPrintf(-9999999, _13571, _13573);
    DeRefDS(_13573);
    _13573 = NOVALUE;
    RefDS(_21997);
    _50CompileErr(_13574, _21997, 1);
    _13574 = NOVALUE;
LB: 

    /** preproc.e:121				rid = define_c_func(dll_id, "preprocess", { E_SEQUENCE, E_SEQUENCE, E_SEQUENCE }, */
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 134217732;
    ((intptr_t*)_2)[2] = 134217732;
    ((intptr_t*)_2)[3] = 134217732;
    _13576 = MAKE_SEQ(_1);
    RefDS(_13575);
    _rid_24145 = _12define_c_func(_dll_id_24149, _13575, _13576, 100663300);
    _13576 = NOVALUE;
    if (!IS_ATOM_INT(_rid_24145)) {
        _1 = (object)(DBL_PTR(_rid_24145)->dbl);
        DeRefDS(_rid_24145);
        _rid_24145 = _1;
    }

    /** preproc.e:123				if rid = -1 then*/
    if (_rid_24145 != -1)
    goto LC; // [274] 291

    /** preproc.e:124					CompileErr("Preprocessor entry point cound not be found\n",,1)*/
    RefDS(_13579);
    RefDS(_21997);
    _50CompileErr(_13579, _21997, 1);

    /** preproc.e:126					Cleanup(1)*/
    _50Cleanup(1);
LC: 

    /** preproc.e:129				preprocessors[pp_id][PP_RID] = rid*/
    _2 = (object)SEQ_PTR(_37preprocessors_15423);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37preprocessors_15423 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pp_id_24096 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _rid_24145;
    DeRef(_1);
    _13580 = NOVALUE;
LA: 

    /** preproc.e:132			if c_func(rid, { fname, post_fname, pp[PP_PARAMS] }) != 0 then*/
    _2 = (object)SEQ_PTR(_pp_24095);
    _13582 = (object)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_fname_24094);
    ((intptr_t*)_2)[1] = _fname_24094;
    RefDS(_post_fname_24117);
    ((intptr_t*)_2)[2] = _post_fname_24117;
    Ref(_13582);
    ((intptr_t*)_2)[3] = _13582;
    _13583 = MAKE_SEQ(_1);
    _13582 = NOVALUE;
    _13584 = call_c(1, _rid_24145, _13583);
    DeRefDS(_13583);
    _13583 = NOVALUE;
    if (binary_op_a(EQUALS, _13584, 0)){
        DeRef(_13584);
        _13584 = NOVALUE;
        goto LD; // [326] 343
    }
    DeRef(_13584);
    _13584 = NOVALUE;

    /** preproc.e:133				CompileErr("Preprocessor call failed\n",,1)*/
    RefDS(_13586);
    RefDS(_21997);
    _50CompileErr(_13586, _21997, 1);

    /** preproc.e:135				Cleanup(1)*/
    _50Cleanup(1);
LD: 
    goto LE; // [345] 520
L9: 

    /** preproc.e:138			sequence public_cmd_args = {pp[PP_COMMAND]}*/
    _2 = (object)SEQ_PTR(_pp_24095);
    _13587 = (object)*(((s1_ptr)_2)->base + 2);
    _0 = _public_cmd_args_24185;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_13587);
    ((intptr_t*)_2)[1] = _13587;
    _public_cmd_args_24185 = MAKE_SEQ(_1);
    DeRef(_0);
    _13587 = NOVALUE;

    /** preproc.e:139			sequence cmd_args = {canonical_path(pp[PP_COMMAND],,TO_SHORT)}*/
    _2 = (object)SEQ_PTR(_pp_24095);
    _13589 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_13589);
    _13590 = _17canonical_path(_13589, 0, 4);
    _13589 = NOVALUE;
    _0 = _cmd_args_24188;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _13590;
    _cmd_args_24188 = MAKE_SEQ(_1);
    DeRef(_0);
    _13590 = NOVALUE;

    /** preproc.e:141			if equal(fileext(pp[PP_COMMAND]), "ex") then*/
    _2 = (object)SEQ_PTR(_pp_24095);
    _13592 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_13592);
    _13593 = _17fileext(_13592);
    _13592 = NOVALUE;
    if (_13593 == _13594)
    _13595 = 1;
    else if (IS_ATOM_INT(_13593) && IS_ATOM_INT(_13594))
    _13595 = 0;
    else
    _13595 = (compare(_13593, _13594) == 0);
    DeRef(_13593);
    _13593 = NOVALUE;
    if (_13595 == 0)
    {
        _13595 = NOVALUE;
        goto LF; // [390] 414
    }
    else{
        _13595 = NOVALUE;
    }

    /** preproc.e:142				public_cmd_args = { "eui" } & public_cmd_args*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13596);
    ((intptr_t*)_2)[1] = _13596;
    _13597 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_24185, _13597, _public_cmd_args_24185);
    DeRefDS(_13597);
    _13597 = NOVALUE;
    DeRef(_13597);
    _13597 = NOVALUE;

    /** preproc.e:143				cmd_args = { "eui" } & cmd_args*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13596);
    ((intptr_t*)_2)[1] = _13596;
    _13599 = MAKE_SEQ(_1);
    Concat((object_ptr)&_cmd_args_24188, _13599, _cmd_args_24188);
    DeRefDS(_13599);
    _13599 = NOVALUE;
    DeRef(_13599);
    _13599 = NOVALUE;
LF: 

    /** preproc.e:146			cmd_args &= { "-i", canonical_path(fname,,TO_SHORT), "-o", canonical_path(post_fname,,TO_SHORT) }*/
    RefDS(_fname_24094);
    _13602 = _17canonical_path(_fname_24094, 0, 4);
    RefDS(_post_fname_24117);
    _13604 = _17canonical_path(_post_fname_24117, 0, 4);
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13601);
    ((intptr_t*)_2)[1] = _13601;
    ((intptr_t*)_2)[2] = _13602;
    RefDS(_13603);
    ((intptr_t*)_2)[3] = _13603;
    ((intptr_t*)_2)[4] = _13604;
    _13605 = MAKE_SEQ(_1);
    _13604 = NOVALUE;
    _13602 = NOVALUE;
    Concat((object_ptr)&_cmd_args_24188, _cmd_args_24188, _13605);
    DeRefDS(_13605);
    _13605 = NOVALUE;

    /** preproc.e:147			public_cmd_args &= { "-i", fname, "-o", post_fname }*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13601);
    ((intptr_t*)_2)[1] = _13601;
    RefDS(_fname_24094);
    ((intptr_t*)_2)[2] = _fname_24094;
    RefDS(_13603);
    ((intptr_t*)_2)[3] = _13603;
    RefDS(_post_fname_24117);
    ((intptr_t*)_2)[4] = _post_fname_24117;
    _13607 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_24185, _public_cmd_args_24185, _13607);
    DeRefDS(_13607);
    _13607 = NOVALUE;

    /** preproc.e:148			sequence cmd = build_commandline( cmd_args ) & pp[PP_PARAMS]*/
    RefDS(_cmd_args_24188);
    _13609 = _4build_commandline(_cmd_args_24188);
    _2 = (object)SEQ_PTR(_pp_24095);
    _13610 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_13609) && IS_ATOM(_13610)) {
        Ref(_13610);
        Append(&_cmd_24217, _13609, _13610);
    }
    else if (IS_ATOM(_13609) && IS_SEQUENCE(_13610)) {
        Ref(_13609);
        Prepend(&_cmd_24217, _13610, _13609);
    }
    else {
        Concat((object_ptr)&_cmd_24217, _13609, _13610);
        DeRef(_13609);
        _13609 = NOVALUE;
    }
    DeRef(_13609);
    _13609 = NOVALUE;
    _13610 = NOVALUE;

    /** preproc.e:149			sequence pcmd = build_commandline(public_cmd_args) & pp[PP_PARAMS]*/
    RefDS(_public_cmd_args_24185);
    _13612 = _4build_commandline(_public_cmd_args_24185);
    _2 = (object)SEQ_PTR(_pp_24095);
    _13613 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_13612) && IS_ATOM(_13613)) {
        Ref(_13613);
        Append(&_pcmd_24222, _13612, _13613);
    }
    else if (IS_ATOM(_13612) && IS_SEQUENCE(_13613)) {
        Ref(_13612);
        Prepend(&_pcmd_24222, _13613, _13612);
    }
    else {
        Concat((object_ptr)&_pcmd_24222, _13612, _13613);
        DeRef(_13612);
        _13612 = NOVALUE;
    }
    DeRef(_13612);
    _13612 = NOVALUE;
    _13613 = NOVALUE;

    /** preproc.e:150			integer result = system_exec(cmd, 2)*/
    _result_24227 = system_exec_call(_cmd_24217, 2);

    /** preproc.e:151			if result != 0 then*/
    if (_result_24227 == 0)
    goto L10; // [492] 517

    /** preproc.e:152				CompileErr(sprintf("Preprocessor command failed (%d): %s\n", { result, pcmd } ),,1)*/
    RefDS(_pcmd_24222);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _result_24227;
    ((intptr_t *)_2)[2] = _pcmd_24222;
    _13618 = MAKE_SEQ(_1);
    _13619 = EPrintf(-9999999, _13617, _13618);
    DeRefDS(_13618);
    _13618 = NOVALUE;
    RefDS(_21997);
    _50CompileErr(_13619, _21997, 1);
    _13619 = NOVALUE;

    /** preproc.e:154				Cleanup(1)*/
    _50Cleanup(1);
L10: 
    DeRef(_public_cmd_args_24185);
    _public_cmd_args_24185 = NOVALUE;
    DeRef(_cmd_args_24188);
    _cmd_args_24188 = NOVALUE;
    DeRef(_cmd_24217);
    _cmd_24217 = NOVALUE;
    DeRef(_pcmd_24222);
    _pcmd_24222 = NOVALUE;
LE: 

    /** preproc.e:158		return post_fname*/
    DeRefDS(_fname_24094);
    DeRef(_pp_24095);
    _13555 = NOVALUE;
    return _post_fname_24117;
    ;
}



// 0xB3CA2275
