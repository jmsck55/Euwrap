// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _4local_abort(object _lvl_14190)
{
    object _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_14195 = NOVALUE;
    object _7856 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:171		if length(pause_msg) != 0 then*/
    _7856 = 0;

    /** cmdline.e:175		abort(lvl)*/
    UserCleanup(_lvl_14190);

    /** cmdline.e:176	end procedure*/
    return;
    ;
}


void _4check_for_bad_combos(object _opts_14198, object _opt1_14199, object _opt2_14200, object _error_message_14201)
{
    object _msg_inlined_crash_at_38_14209 = NOVALUE;
    object _7861 = NOVALUE;
    object _7860 = NOVALUE;
    object _7859 = NOVALUE;
    object _7858 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:180		if find( opt1, opts[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_opts_14198);
    _7858 = (object)*(((s1_ptr)_2)->base + 4);
    _7859 = find_from(_opt1_14199, _7858, 1);
    _7858 = NOVALUE;
    if (_7859 == 0)
    {
        _7859 = NOVALUE;
        goto L1; // [20] 59
    }
    else{
        _7859 = NOVALUE;
    }

    /** cmdline.e:181			if find( opt2, opts[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_opts_14198);
    _7860 = (object)*(((s1_ptr)_2)->base + 4);
    _7861 = find_from(_opt2_14200, _7860, 1);
    _7860 = NOVALUE;
    if (_7861 == 0)
    {
        _7861 = NOVALUE;
        goto L2; // [34] 58
    }
    else{
        _7861 = NOVALUE;
    }

    /** cmdline.e:182				error:crash( error_message )*/

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_38_14209);
    _msg_inlined_crash_at_38_14209 = EPrintf(-9999999, _error_message_14201, _5);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_38_14209);

    /** error.e:53	end procedure*/
    goto L3; // [52] 55
L3: 
    DeRefi(_msg_inlined_crash_at_38_14209);
    _msg_inlined_crash_at_38_14209 = NOVALUE;
L2: 
L1: 

    /** cmdline.e:185	end procedure*/
    DeRefDS(_opts_14198);
    DeRefDSi(_error_message_14201);
    return;
    ;
}


object _4has_duplicate(object _opts_14212, object _opt_14213, object _name_type_14214, object _start_from_14215)
{
    object _opt_name_14219 = NOVALUE;
    object _7869 = NOVALUE;
    object _7868 = NOVALUE;
    object _7867 = NOVALUE;
    object _7866 = NOVALUE;
    object _7865 = NOVALUE;
    object _7863 = NOVALUE;
    object _7862 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:188		if sequence( opt[name_type] ) then*/
    _2 = (object)SEQ_PTR(_opt_14213);
    _7862 = (object)*(((s1_ptr)_2)->base + _name_type_14214);
    _7863 = IS_SEQUENCE(_7862);
    _7862 = NOVALUE;
    if (_7863 == 0)
    {
        _7863 = NOVALUE;
        goto L1; // [18] 77
    }
    else{
        _7863 = NOVALUE;
    }

    /** cmdline.e:189			sequence opt_name = opt[name_type]*/
    DeRef(_opt_name_14219);
    _2 = (object)SEQ_PTR(_opt_14213);
    _opt_name_14219 = (object)*(((s1_ptr)_2)->base + _name_type_14214);
    Ref(_opt_name_14219);

    /** cmdline.e:190			for i = start_from + 1 to length( opts ) do*/
    _7865 = _start_from_14215 + 1;
    if (IS_SEQUENCE(_opts_14212)){
            _7866 = SEQ_PTR(_opts_14212)->length;
    }
    else {
        _7866 = 1;
    }
    {
        object _i_14222;
        _i_14222 = _7865;
L2: 
        if (_i_14222 > _7866){
            goto L3; // [38] 76
        }

        /** cmdline.e:191				if equal( opt_name, opts[i][name_type] ) then*/
        _2 = (object)SEQ_PTR(_opts_14212);
        _7867 = (object)*(((s1_ptr)_2)->base + _i_14222);
        _2 = (object)SEQ_PTR(_7867);
        _7868 = (object)*(((s1_ptr)_2)->base + _name_type_14214);
        _7867 = NOVALUE;
        if (_opt_name_14219 == _7868)
        _7869 = 1;
        else if (IS_ATOM_INT(_opt_name_14219) && IS_ATOM_INT(_7868))
        _7869 = 0;
        else
        _7869 = (compare(_opt_name_14219, _7868) == 0);
        _7868 = NOVALUE;
        if (_7869 == 0)
        {
            _7869 = NOVALUE;
            goto L4; // [59] 69
        }
        else{
            _7869 = NOVALUE;
        }

        /** cmdline.e:192					return 1*/
        DeRefDS(_opt_name_14219);
        DeRefDS(_opts_14212);
        DeRefDS(_opt_14213);
        DeRef(_7865);
        _7865 = NOVALUE;
        return 1;
L4: 

        /** cmdline.e:194			end for*/
        _i_14222 = _i_14222 + 1;
        goto L2; // [71] 45
L3: 
        ;
    }
L1: 
    DeRef(_opt_name_14219);
    _opt_name_14219 = NOVALUE;

    /** cmdline.e:196		return 0*/
    DeRefDS(_opts_14212);
    DeRefDS(_opt_14213);
    DeRef(_7865);
    _7865 = NOVALUE;
    return 0;
    ;
}


void _4check_for_duplicates(object _opts_14231)
{
    object _opt_14235 = NOVALUE;
    object _msg_inlined_crash_at_49_14244 = NOVALUE;
    object _data_inlined_crash_at_46_14243 = NOVALUE;
    object _msg_inlined_crash_at_95_14252 = NOVALUE;
    object _data_inlined_crash_at_92_14251 = NOVALUE;
    object _7879 = NOVALUE;
    object _7878 = NOVALUE;
    object _7876 = NOVALUE;
    object _7875 = NOVALUE;
    object _7874 = NOVALUE;
    object _7872 = NOVALUE;
    object _7870 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:201		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14231)){
            _7870 = SEQ_PTR(_opts_14231)->length;
    }
    else {
        _7870 = 1;
    }
    {
        object _i_14233;
        _i_14233 = 1;
L1: 
        if (_i_14233 > _7870){
            goto L2; // [8] 125
        }

        /** cmdline.e:202			sequence opt*/

        /** cmdline.e:203			opt = opts[i]*/
        DeRef(_opt_14235);
        _2 = (object)SEQ_PTR(_opts_14231);
        _opt_14235 = (object)*(((s1_ptr)_2)->base + _i_14233);
        Ref(_opt_14235);

        /** cmdline.e:204			if has_duplicate( opts, opt, SHORTNAME, i ) then*/
        RefDS(_opts_14231);
        RefDS(_opt_14235);
        _7872 = _4has_duplicate(_opts_14231, _opt_14235, 1, _i_14233);
        if (_7872 == 0) {
            DeRef(_7872);
            _7872 = NOVALUE;
            goto L3; // [34] 71
        }
        else {
            if (!IS_ATOM_INT(_7872) && DBL_PTR(_7872)->dbl == 0.0){
                DeRef(_7872);
                _7872 = NOVALUE;
                goto L3; // [34] 71
            }
            DeRef(_7872);
            _7872 = NOVALUE;
        }
        DeRef(_7872);
        _7872 = NOVALUE;

        /** cmdline.e:206				error:crash("cmd_opts: Duplicate Short Names (%s) are not allowed in an option record.\n",*/
        _2 = (object)SEQ_PTR(_opt_14235);
        _7874 = (object)*(((s1_ptr)_2)->base + 1);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_7874);
        ((intptr_t*)_2)[1] = _7874;
        _7875 = MAKE_SEQ(_1);
        _7874 = NOVALUE;
        DeRef(_data_inlined_crash_at_46_14243);
        _data_inlined_crash_at_46_14243 = _7875;
        _7875 = NOVALUE;

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_49_14244);
        _msg_inlined_crash_at_49_14244 = EPrintf(-9999999, _7873, _data_inlined_crash_at_46_14243);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_49_14244);

        /** error.e:53	end procedure*/
        goto L4; // [63] 66
L4: 
        DeRef(_data_inlined_crash_at_46_14243);
        _data_inlined_crash_at_46_14243 = NOVALUE;
        DeRefi(_msg_inlined_crash_at_49_14244);
        _msg_inlined_crash_at_49_14244 = NOVALUE;
        goto L5; // [68] 116
L3: 

        /** cmdline.e:209			elsif has_duplicate( opts, opt, LONGNAME, i ) then*/
        RefDS(_opts_14231);
        RefDS(_opt_14235);
        _7876 = _4has_duplicate(_opts_14231, _opt_14235, 2, _i_14233);
        if (_7876 == 0) {
            DeRef(_7876);
            _7876 = NOVALUE;
            goto L6; // [80] 115
        }
        else {
            if (!IS_ATOM_INT(_7876) && DBL_PTR(_7876)->dbl == 0.0){
                DeRef(_7876);
                _7876 = NOVALUE;
                goto L6; // [80] 115
            }
            DeRef(_7876);
            _7876 = NOVALUE;
        }
        DeRef(_7876);
        _7876 = NOVALUE;

        /** cmdline.e:211				error:crash("cmd_opts: Duplicate Long Names (%s) are not allowed in an option record.\n",*/
        _2 = (object)SEQ_PTR(_opt_14235);
        _7878 = (object)*(((s1_ptr)_2)->base + 2);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_7878);
        ((intptr_t*)_2)[1] = _7878;
        _7879 = MAKE_SEQ(_1);
        _7878 = NOVALUE;
        DeRef(_data_inlined_crash_at_92_14251);
        _data_inlined_crash_at_92_14251 = _7879;
        _7879 = NOVALUE;

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_95_14252);
        _msg_inlined_crash_at_95_14252 = EPrintf(-9999999, _7877, _data_inlined_crash_at_92_14251);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_95_14252);

        /** error.e:53	end procedure*/
        goto L7; // [109] 112
L7: 
        DeRef(_data_inlined_crash_at_92_14251);
        _data_inlined_crash_at_92_14251 = NOVALUE;
        DeRefi(_msg_inlined_crash_at_95_14252);
        _msg_inlined_crash_at_95_14252 = NOVALUE;
L6: 
L5: 
        DeRef(_opt_14235);
        _opt_14235 = NOVALUE;

        /** cmdline.e:214		end for*/
        _i_14233 = _i_14233 + 1;
        goto L1; // [120] 15
L2: 
        ;
    }

    /** cmdline.e:216	end procedure*/
    DeRefDS(_opts_14231);
    return;
    ;
}


object _4update_opts(object _opts_14255)
{
    object _lExtras_14256 = NOVALUE;
    object _opt_14260 = NOVALUE;
    object _msg_inlined_crash_at_162_14293 = NOVALUE;
    object _msg_inlined_crash_at_323_14324 = NOVALUE;
    object _7950 = NOVALUE;
    object _7949 = NOVALUE;
    object _7948 = NOVALUE;
    object _7947 = NOVALUE;
    object _7946 = NOVALUE;
    object _7945 = NOVALUE;
    object _7944 = NOVALUE;
    object _7943 = NOVALUE;
    object _7942 = NOVALUE;
    object _7941 = NOVALUE;
    object _7940 = NOVALUE;
    object _7939 = NOVALUE;
    object _7938 = NOVALUE;
    object _7937 = NOVALUE;
    object _7935 = NOVALUE;
    object _7933 = NOVALUE;
    object _7932 = NOVALUE;
    object _7931 = NOVALUE;
    object _7930 = NOVALUE;
    object _7923 = NOVALUE;
    object _7922 = NOVALUE;
    object _7921 = NOVALUE;
    object _7920 = NOVALUE;
    object _7919 = NOVALUE;
    object _7918 = NOVALUE;
    object _7917 = NOVALUE;
    object _7916 = NOVALUE;
    object _7914 = NOVALUE;
    object _7913 = NOVALUE;
    object _7912 = NOVALUE;
    object _7911 = NOVALUE;
    object _7910 = NOVALUE;
    object _7909 = NOVALUE;
    object _7908 = NOVALUE;
    object _7907 = NOVALUE;
    object _7904 = NOVALUE;
    object _7903 = NOVALUE;
    object _7902 = NOVALUE;
    object _7901 = NOVALUE;
    object _7900 = NOVALUE;
    object _7899 = NOVALUE;
    object _7898 = NOVALUE;
    object _7897 = NOVALUE;
    object _7896 = NOVALUE;
    object _7895 = NOVALUE;
    object _7894 = NOVALUE;
    object _7893 = NOVALUE;
    object _7892 = NOVALUE;
    object _7891 = NOVALUE;
    object _7890 = NOVALUE;
    object _7889 = NOVALUE;
    object _7888 = NOVALUE;
    object _7886 = NOVALUE;
    object _7885 = NOVALUE;
    object _7884 = NOVALUE;
    object _7882 = NOVALUE;
    object _7880 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:223		integer lExtras = 0 -- Ensure that there is zero or one 'extras' record only.*/
    _lExtras_14256 = 0;

    /** cmdline.e:224		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14255)){
            _7880 = SEQ_PTR(_opts_14255)->length;
    }
    else {
        _7880 = 1;
    }
    {
        object _i_14258;
        _i_14258 = 1;
L1: 
        if (_i_14258 > _7880){
            goto L2; // [13] 565
        }

        /** cmdline.e:225			sequence opt = opts[i]*/
        DeRef(_opt_14260);
        _2 = (object)SEQ_PTR(_opts_14255);
        _opt_14260 = (object)*(((s1_ptr)_2)->base + _i_14258);
        Ref(_opt_14260);

        /** cmdline.e:226			opts[i] = 0*/
        _2 = (object)SEQ_PTR(_opts_14255);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opts_14255 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_14258);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);

        /** cmdline.e:228			if length(opt) < MAPNAME then*/
        if (IS_SEQUENCE(_opt_14260)){
                _7882 = SEQ_PTR(_opt_14260)->length;
        }
        else {
            _7882 = 1;
        }
        if (_7882 >= 6)
        goto L3; // [39] 61

        /** cmdline.e:229				opt &= repeat(-1, MAPNAME - length(opt))*/
        if (IS_SEQUENCE(_opt_14260)){
                _7884 = SEQ_PTR(_opt_14260)->length;
        }
        else {
            _7884 = 1;
        }
        _7885 = 6 - _7884;
        _7884 = NOVALUE;
        _7886 = Repeat(-1, _7885);
        _7885 = NOVALUE;
        Concat((object_ptr)&_opt_14260, _opt_14260, _7886);
        DeRefDS(_7886);
        _7886 = NOVALUE;
L3: 

        /** cmdline.e:232			if sequence(opt[SHORTNAME]) and length(opt[SHORTNAME]) = 0 then*/
        _2 = (object)SEQ_PTR(_opt_14260);
        _7888 = (object)*(((s1_ptr)_2)->base + 1);
        _7889 = IS_SEQUENCE(_7888);
        _7888 = NOVALUE;
        if (_7889 == 0) {
            goto L4; // [70] 96
        }
        _2 = (object)SEQ_PTR(_opt_14260);
        _7891 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_SEQUENCE(_7891)){
                _7892 = SEQ_PTR(_7891)->length;
        }
        else {
            _7892 = 1;
        }
        _7891 = NOVALUE;
        _7893 = (_7892 == 0);
        _7892 = NOVALUE;
        if (_7893 == 0)
        {
            DeRef(_7893);
            _7893 = NOVALUE;
            goto L4; // [86] 96
        }
        else{
            DeRef(_7893);
            _7893 = NOVALUE;
        }

        /** cmdline.e:233				opt[SHORTNAME] = 0*/
        _2 = (object)SEQ_PTR(_opt_14260);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_14260 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);
L4: 

        /** cmdline.e:236			if sequence(opt[LONGNAME]) and length(opt[LONGNAME]) = 0 then*/
        _2 = (object)SEQ_PTR(_opt_14260);
        _7894 = (object)*(((s1_ptr)_2)->base + 2);
        _7895 = IS_SEQUENCE(_7894);
        _7894 = NOVALUE;
        if (_7895 == 0) {
            goto L5; // [105] 131
        }
        _2 = (object)SEQ_PTR(_opt_14260);
        _7897 = (object)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_7897)){
                _7898 = SEQ_PTR(_7897)->length;
        }
        else {
            _7898 = 1;
        }
        _7897 = NOVALUE;
        _7899 = (_7898 == 0);
        _7898 = NOVALUE;
        if (_7899 == 0)
        {
            DeRef(_7899);
            _7899 = NOVALUE;
            goto L5; // [121] 131
        }
        else{
            DeRef(_7899);
            _7899 = NOVALUE;
        }

        /** cmdline.e:237				opt[LONGNAME] = 0*/
        _2 = (object)SEQ_PTR(_opt_14260);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_14260 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 2);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);
L5: 

        /** cmdline.e:240			if atom(opt[LONGNAME]) and atom(opt[SHORTNAME]) then*/
        _2 = (object)SEQ_PTR(_opt_14260);
        _7900 = (object)*(((s1_ptr)_2)->base + 2);
        _7901 = IS_ATOM(_7900);
        _7900 = NOVALUE;
        if (_7901 == 0) {
            goto L6; // [140] 212
        }
        _2 = (object)SEQ_PTR(_opt_14260);
        _7903 = (object)*(((s1_ptr)_2)->base + 1);
        _7904 = IS_ATOM(_7903);
        _7903 = NOVALUE;
        if (_7904 == 0)
        {
            _7904 = NOVALUE;
            goto L6; // [152] 212
        }
        else{
            _7904 = NOVALUE;
        }

        /** cmdline.e:241				if lExtras != 0 then*/
        if (_lExtras_14256 == 0)
        goto L7; // [157] 184

        /** cmdline.e:242					error:crash("cmd_opts: There must be less than two 'extras' option records.\n")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_162_14293);
        _msg_inlined_crash_at_162_14293 = EPrintf(-9999999, _7906, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_162_14293);

        /** error.e:53	end procedure*/
        goto L8; // [176] 179
L8: 
        DeRefi(_msg_inlined_crash_at_162_14293);
        _msg_inlined_crash_at_162_14293 = NOVALUE;
        goto L9; // [181] 211
L7: 

        /** cmdline.e:244					lExtras = i*/
        _lExtras_14256 = _i_14258;

        /** cmdline.e:245					if atom(opt[MAPNAME]) then*/
        _2 = (object)SEQ_PTR(_opt_14260);
        _7907 = (object)*(((s1_ptr)_2)->base + 6);
        _7908 = IS_ATOM(_7907);
        _7907 = NOVALUE;
        if (_7908 == 0)
        {
            _7908 = NOVALUE;
            goto LA; // [198] 210
        }
        else{
            _7908 = NOVALUE;
        }

        /** cmdline.e:246						opt[MAPNAME] = EXTRAS*/
        RefDS(_4EXTRAS_14176);
        _2 = (object)SEQ_PTR(_opt_14260);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_14260 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 6);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _4EXTRAS_14176;
        DeRef(_1);
LA: 
L9: 
L6: 

        /** cmdline.e:251			if atom(opt[DESCRIPTION]) then*/
        _2 = (object)SEQ_PTR(_opt_14260);
        _7909 = (object)*(((s1_ptr)_2)->base + 3);
        _7910 = IS_ATOM(_7909);
        _7909 = NOVALUE;
        if (_7910 == 0)
        {
            _7910 = NOVALUE;
            goto LB; // [221] 231
        }
        else{
            _7910 = NOVALUE;
        }

        /** cmdline.e:252				opt[DESCRIPTION] = ""*/
        RefDS(_5);
        _2 = (object)SEQ_PTR(_opt_14260);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_14260 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 3);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5;
        DeRef(_1);
LB: 

        /** cmdline.e:256			if atom(opt[OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opt_14260);
        _7911 = (object)*(((s1_ptr)_2)->base + 4);
        _7912 = IS_ATOM(_7911);
        _7911 = NOVALUE;
        if (_7912 == 0)
        {
            _7912 = NOVALUE;
            goto LC; // [240] 279
        }
        else{
            _7912 = NOVALUE;
        }

        /** cmdline.e:257				if equal(opt[OPTIONS], HAS_PARAMETER) then*/
        _2 = (object)SEQ_PTR(_opt_14260);
        _7913 = (object)*(((s1_ptr)_2)->base + 4);
        if (_7913 == 112)
        _7914 = 1;
        else if (IS_ATOM_INT(_7913) && IS_ATOM_INT(112))
        _7914 = 0;
        else
        _7914 = (compare(_7913, 112) == 0);
        _7913 = NOVALUE;
        if (_7914 == 0)
        {
            _7914 = NOVALUE;
            goto LD; // [253] 269
        }
        else{
            _7914 = NOVALUE;
        }

        /** cmdline.e:258					opt[OPTIONS] = {HAS_PARAMETER,"x"}*/
        RefDS(_7915);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 112;
        ((intptr_t *)_2)[2] = _7915;
        _7916 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_opt_14260);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_14260 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _7916;
        if( _1 != _7916 ){
            DeRef(_1);
        }
        _7916 = NOVALUE;
        goto LE; // [266] 383
LD: 

        /** cmdline.e:260					opt[OPTIONS] = {}*/
        RefDS(_5);
        _2 = (object)SEQ_PTR(_opt_14260);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_14260 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5;
        DeRef(_1);
        goto LE; // [276] 383
LC: 

        /** cmdline.e:263				for j = 1 to length(opt[OPTIONS]) do*/
        _2 = (object)SEQ_PTR(_opt_14260);
        _7917 = (object)*(((s1_ptr)_2)->base + 4);
        if (IS_SEQUENCE(_7917)){
                _7918 = SEQ_PTR(_7917)->length;
        }
        else {
            _7918 = 1;
        }
        _7917 = NOVALUE;
        {
            object _j_14312;
            _j_14312 = 1;
LF: 
            if (_j_14312 > _7918){
                goto L10; // [288] 350
            }

            /** cmdline.e:264					if find(opt[OPTIONS][j], opt[OPTIONS], j + 1) != 0 then*/
            _2 = (object)SEQ_PTR(_opt_14260);
            _7919 = (object)*(((s1_ptr)_2)->base + 4);
            _2 = (object)SEQ_PTR(_7919);
            _7920 = (object)*(((s1_ptr)_2)->base + _j_14312);
            _7919 = NOVALUE;
            _2 = (object)SEQ_PTR(_opt_14260);
            _7921 = (object)*(((s1_ptr)_2)->base + 4);
            _7922 = _j_14312 + 1;
            _7923 = find_from(_7920, _7921, _7922);
            _7920 = NOVALUE;
            _7921 = NOVALUE;
            _7922 = NOVALUE;
            if (_7923 == 0)
            goto L11; // [318] 343

            /** cmdline.e:265						error:crash("cmd_opts: Duplicate processing options are not allowed in an option record.\n")*/

            /** error.e:51		msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_323_14324);
            _msg_inlined_crash_at_323_14324 = EPrintf(-9999999, _7925, _5);

            /** error.e:52		machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_323_14324);

            /** error.e:53	end procedure*/
            goto L12; // [337] 340
L12: 
            DeRefi(_msg_inlined_crash_at_323_14324);
            _msg_inlined_crash_at_323_14324 = NOVALUE;
L11: 

            /** cmdline.e:267				end for*/
            _j_14312 = _j_14312 + 1;
            goto LF; // [345] 295
L10: 
            ;
        }

        /** cmdline.e:269				check_for_bad_combos( opt, HAS_PARAMETER, NO_PARAMETER, */
        RefDS(_opt_14260);
        RefDS(_7926);
        _4check_for_bad_combos(_opt_14260, 112, 110, _7926);

        /** cmdline.e:272				check_for_bad_combos( opt, HAS_CASE, NO_CASE, */
        RefDS(_opt_14260);
        RefDS(_7927);
        _4check_for_bad_combos(_opt_14260, 99, 105, _7927);

        /** cmdline.e:275				check_for_bad_combos( opt, MANDATORY, OPTIONAL, */
        RefDS(_opt_14260);
        RefDS(_7928);
        _4check_for_bad_combos(_opt_14260, 109, 111, _7928);

        /** cmdline.e:278				check_for_bad_combos( opt, ONCE, MULTIPLE, */
        RefDS(_opt_14260);
        RefDS(_7929);
        _4check_for_bad_combos(_opt_14260, 49, 42, _7929);
LE: 

        /** cmdline.e:283			if sequence(opt[CALLBACK]) then*/
        _2 = (object)SEQ_PTR(_opt_14260);
        _7930 = (object)*(((s1_ptr)_2)->base + 5);
        _7931 = IS_SEQUENCE(_7930);
        _7930 = NOVALUE;
        if (_7931 == 0)
        {
            _7931 = NOVALUE;
            goto L13; // [392] 404
        }
        else{
            _7931 = NOVALUE;
        }

        /** cmdline.e:284				opt[CALLBACK] = -1*/
        _2 = (object)SEQ_PTR(_opt_14260);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_14260 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = -1;
        DeRef(_1);
        goto L14; // [401] 443
L13: 

        /** cmdline.e:285			elsif not integer(opt[CALLBACK]) then*/
        _2 = (object)SEQ_PTR(_opt_14260);
        _7932 = (object)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_7932))
        _7933 = 1;
        else if (IS_ATOM_DBL(_7932))
        _7933 = IS_ATOM_INT(DoubleToInt(_7932));
        else
        _7933 = 0;
        _7932 = NOVALUE;
        if (_7933 != 0)
        goto L15; // [413] 425
        _7933 = NOVALUE;

        /** cmdline.e:286				opt[CALLBACK] = -1*/
        _2 = (object)SEQ_PTR(_opt_14260);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_14260 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = -1;
        DeRef(_1);
        goto L14; // [422] 443
L15: 

        /** cmdline.e:287			elsif opt[CALLBACK] < 0 then*/
        _2 = (object)SEQ_PTR(_opt_14260);
        _7935 = (object)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(GREATEREQ, _7935, 0)){
            _7935 = NOVALUE;
            goto L16; // [431] 442
        }
        _7935 = NOVALUE;

        /** cmdline.e:288				opt[CALLBACK] = -1*/
        _2 = (object)SEQ_PTR(_opt_14260);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_14260 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = -1;
        DeRef(_1);
L16: 
L14: 

        /** cmdline.e:291			if sequence(opt[MAPNAME]) and length(opt[MAPNAME]) = 0 then*/
        _2 = (object)SEQ_PTR(_opt_14260);
        _7937 = (object)*(((s1_ptr)_2)->base + 6);
        _7938 = IS_SEQUENCE(_7937);
        _7937 = NOVALUE;
        if (_7938 == 0) {
            goto L17; // [452] 478
        }
        _2 = (object)SEQ_PTR(_opt_14260);
        _7940 = (object)*(((s1_ptr)_2)->base + 6);
        if (IS_SEQUENCE(_7940)){
                _7941 = SEQ_PTR(_7940)->length;
        }
        else {
            _7941 = 1;
        }
        _7940 = NOVALUE;
        _7942 = (_7941 == 0);
        _7941 = NOVALUE;
        if (_7942 == 0)
        {
            DeRef(_7942);
            _7942 = NOVALUE;
            goto L17; // [468] 478
        }
        else{
            DeRef(_7942);
            _7942 = NOVALUE;
        }

        /** cmdline.e:292				opt[MAPNAME] = 0*/
        _2 = (object)SEQ_PTR(_opt_14260);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_14260 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 6);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);
L17: 

        /** cmdline.e:295			if atom(opt[MAPNAME]) then*/
        _2 = (object)SEQ_PTR(_opt_14260);
        _7943 = (object)*(((s1_ptr)_2)->base + 6);
        _7944 = IS_ATOM(_7943);
        _7943 = NOVALUE;
        if (_7944 == 0)
        {
            _7944 = NOVALUE;
            goto L18; // [487] 550
        }
        else{
            _7944 = NOVALUE;
        }

        /** cmdline.e:296				if sequence(opt[LONGNAME]) then*/
        _2 = (object)SEQ_PTR(_opt_14260);
        _7945 = (object)*(((s1_ptr)_2)->base + 2);
        _7946 = IS_SEQUENCE(_7945);
        _7945 = NOVALUE;
        if (_7946 == 0)
        {
            _7946 = NOVALUE;
            goto L19; // [499] 515
        }
        else{
            _7946 = NOVALUE;
        }

        /** cmdline.e:297					opt[MAPNAME] = opt[LONGNAME]*/
        _2 = (object)SEQ_PTR(_opt_14260);
        _7947 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_7947);
        _2 = (object)SEQ_PTR(_opt_14260);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_14260 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 6);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _7947;
        if( _1 != _7947 ){
            DeRef(_1);
        }
        _7947 = NOVALUE;
        goto L1A; // [512] 549
L19: 

        /** cmdline.e:298				elsif sequence(opt[SHORTNAME]) then*/
        _2 = (object)SEQ_PTR(_opt_14260);
        _7948 = (object)*(((s1_ptr)_2)->base + 1);
        _7949 = IS_SEQUENCE(_7948);
        _7948 = NOVALUE;
        if (_7949 == 0)
        {
            _7949 = NOVALUE;
            goto L1B; // [524] 540
        }
        else{
            _7949 = NOVALUE;
        }

        /** cmdline.e:299					opt[MAPNAME] = opt[SHORTNAME]*/
        _2 = (object)SEQ_PTR(_opt_14260);
        _7950 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_7950);
        _2 = (object)SEQ_PTR(_opt_14260);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_14260 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 6);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _7950;
        if( _1 != _7950 ){
            DeRef(_1);
        }
        _7950 = NOVALUE;
        goto L1A; // [537] 549
L1B: 

        /** cmdline.e:301					opt[MAPNAME] = EXTRAS*/
        RefDS(_4EXTRAS_14176);
        _2 = (object)SEQ_PTR(_opt_14260);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_14260 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 6);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _4EXTRAS_14176;
        DeRef(_1);
L1A: 
L18: 

        /** cmdline.e:305			opts[i] = opt*/
        RefDS(_opt_14260);
        _2 = (object)SEQ_PTR(_opts_14255);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opts_14255 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_14258);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _opt_14260;
        DeRef(_1);
        DeRefDS(_opt_14260);
        _opt_14260 = NOVALUE;

        /** cmdline.e:306		end for*/
        _i_14258 = _i_14258 + 1;
        goto L1; // [560] 20
L2: 
        ;
    }

    /** cmdline.e:307		return opts*/
    _7917 = NOVALUE;
    _7891 = NOVALUE;
    _7897 = NOVALUE;
    _7940 = NOVALUE;
    return _opts_14255;
    ;
}


object _4standardize_help_options(object _opts_14360, object _auto_help_switches_14361)
{
    object _has_h_14362 = NOVALUE;
    object _has_help_14363 = NOVALUE;
    object _has_question_14364 = NOVALUE;
    object _appended_opts_14384 = NOVALUE;
    object _7977 = NOVALUE;
    object _7974 = NOVALUE;
    object _7971 = NOVALUE;
    object _7968 = NOVALUE;
    object _7966 = NOVALUE;
    object _7965 = NOVALUE;
    object _7964 = NOVALUE;
    object _7963 = NOVALUE;
    object _7961 = NOVALUE;
    object _7960 = NOVALUE;
    object _7959 = NOVALUE;
    object _7957 = NOVALUE;
    object _7956 = NOVALUE;
    object _7955 = NOVALUE;
    object _7953 = NOVALUE;
    object _7952 = NOVALUE;
    object _7951 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:313		integer has_h = 0, has_help = 0, has_question = 0*/
    _has_h_14362 = 0;
    _has_help_14363 = 0;
    _has_question_14364 = 0;

    /** cmdline.e:314		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14360)){
            _7951 = SEQ_PTR(_opts_14360)->length;
    }
    else {
        _7951 = 1;
    }
    {
        object _i_14366;
        _i_14366 = 1;
L1: 
        if (_i_14366 > _7951){
            goto L2; // [21] 107
        }

        /** cmdline.e:315			if equal(opts[i][SHORTNAME], "h") then*/
        _2 = (object)SEQ_PTR(_opts_14360);
        _7952 = (object)*(((s1_ptr)_2)->base + _i_14366);
        _2 = (object)SEQ_PTR(_7952);
        _7953 = (object)*(((s1_ptr)_2)->base + 1);
        _7952 = NOVALUE;
        if (_7953 == _7954)
        _7955 = 1;
        else if (IS_ATOM_INT(_7953) && IS_ATOM_INT(_7954))
        _7955 = 0;
        else
        _7955 = (compare(_7953, _7954) == 0);
        _7953 = NOVALUE;
        if (_7955 == 0)
        {
            _7955 = NOVALUE;
            goto L3; // [42] 53
        }
        else{
            _7955 = NOVALUE;
        }

        /** cmdline.e:316				has_h = 1*/
        _has_h_14362 = 1;
        goto L4; // [50] 77
L3: 

        /** cmdline.e:317			elsif equal(opts[i][SHORTNAME], "?") then*/
        _2 = (object)SEQ_PTR(_opts_14360);
        _7956 = (object)*(((s1_ptr)_2)->base + _i_14366);
        _2 = (object)SEQ_PTR(_7956);
        _7957 = (object)*(((s1_ptr)_2)->base + 1);
        _7956 = NOVALUE;
        if (_7957 == _7958)
        _7959 = 1;
        else if (IS_ATOM_INT(_7957) && IS_ATOM_INT(_7958))
        _7959 = 0;
        else
        _7959 = (compare(_7957, _7958) == 0);
        _7957 = NOVALUE;
        if (_7959 == 0)
        {
            _7959 = NOVALUE;
            goto L5; // [67] 76
        }
        else{
            _7959 = NOVALUE;
        }

        /** cmdline.e:318				has_question = 1*/
        _has_question_14364 = 1;
L5: 
L4: 

        /** cmdline.e:321			if equal(opts[i][LONGNAME], "help") then*/
        _2 = (object)SEQ_PTR(_opts_14360);
        _7960 = (object)*(((s1_ptr)_2)->base + _i_14366);
        _2 = (object)SEQ_PTR(_7960);
        _7961 = (object)*(((s1_ptr)_2)->base + 2);
        _7960 = NOVALUE;
        if (_7961 == _7962)
        _7963 = 1;
        else if (IS_ATOM_INT(_7961) && IS_ATOM_INT(_7962))
        _7963 = 0;
        else
        _7963 = (compare(_7961, _7962) == 0);
        _7961 = NOVALUE;
        if (_7963 == 0)
        {
            _7963 = NOVALUE;
            goto L6; // [91] 100
        }
        else{
            _7963 = NOVALUE;
        }

        /** cmdline.e:322				has_help = 1*/
        _has_help_14363 = 1;
L6: 

        /** cmdline.e:324		end for*/
        _i_14366 = _i_14366 + 1;
        goto L1; // [102] 28
L2: 
        ;
    }

    /** cmdline.e:326		if auto_help_switches then*/
    if (_auto_help_switches_14361 == 0)
    {
        goto L7; // [109] 249
    }
    else{
    }

    /** cmdline.e:327			integer appended_opts = 0*/
    _appended_opts_14384 = 0;

    /** cmdline.e:328			if not has_h and not has_help then*/
    _7964 = (_has_h_14362 == 0);
    if (_7964 == 0) {
        goto L8; // [122] 155
    }
    _7966 = (_has_help_14363 == 0);
    if (_7966 == 0)
    {
        DeRef(_7966);
        _7966 = NOVALUE;
        goto L8; // [130] 155
    }
    else{
        DeRef(_7966);
        _7966 = NOVALUE;
    }

    /** cmdline.e:329				opts = append(opts, {"h", "help", "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_7954);
    ((intptr_t*)_2)[1] = _7954;
    RefDS(_7962);
    ((intptr_t*)_2)[2] = _7962;
    RefDS(_7967);
    ((intptr_t*)_2)[3] = _7967;
    RefDS(_7954);
    ((intptr_t*)_2)[4] = _7954;
    ((intptr_t*)_2)[5] = -1;
    _7968 = MAKE_SEQ(_1);
    RefDS(_7968);
    Append(&_opts_14360, _opts_14360, _7968);
    DeRefDS(_7968);
    _7968 = NOVALUE;

    /** cmdline.e:330				appended_opts = 1*/
    _appended_opts_14384 = 1;
    goto L9; // [152] 208
L8: 

    /** cmdline.e:332			elsif not has_h then*/
    if (_has_h_14362 != 0)
    goto LA; // [157] 182

    /** cmdline.e:333				opts = append(opts, {"h", 0, "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_7954);
    ((intptr_t*)_2)[1] = _7954;
    ((intptr_t*)_2)[2] = 0;
    RefDS(_7967);
    ((intptr_t*)_2)[3] = _7967;
    RefDS(_7954);
    ((intptr_t*)_2)[4] = _7954;
    ((intptr_t*)_2)[5] = -1;
    _7971 = MAKE_SEQ(_1);
    RefDS(_7971);
    Append(&_opts_14360, _opts_14360, _7971);
    DeRefDS(_7971);
    _7971 = NOVALUE;

    /** cmdline.e:334				appended_opts = 1*/
    _appended_opts_14384 = 1;
    goto L9; // [179] 208
LA: 

    /** cmdline.e:336			elsif not has_help then*/
    if (_has_help_14363 != 0)
    goto LB; // [184] 207

    /** cmdline.e:337				opts = append(opts, {0, "help", "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    RefDS(_7962);
    ((intptr_t*)_2)[2] = _7962;
    RefDS(_7967);
    ((intptr_t*)_2)[3] = _7967;
    RefDS(_7954);
    ((intptr_t*)_2)[4] = _7954;
    ((intptr_t*)_2)[5] = -1;
    _7974 = MAKE_SEQ(_1);
    RefDS(_7974);
    Append(&_opts_14360, _opts_14360, _7974);
    DeRefDS(_7974);
    _7974 = NOVALUE;

    /** cmdline.e:338				appended_opts = 1*/
    _appended_opts_14384 = 1;
LB: 
L9: 

    /** cmdline.e:342			if not has_question then			*/
    if (_has_question_14364 != 0)
    goto LC; // [210] 233

    /** cmdline.e:343				opts = append(opts, {"?", 0, "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_7958);
    ((intptr_t*)_2)[1] = _7958;
    ((intptr_t*)_2)[2] = 0;
    RefDS(_7967);
    ((intptr_t*)_2)[3] = _7967;
    RefDS(_7954);
    ((intptr_t*)_2)[4] = _7954;
    ((intptr_t*)_2)[5] = -1;
    _7977 = MAKE_SEQ(_1);
    RefDS(_7977);
    Append(&_opts_14360, _opts_14360, _7977);
    DeRefDS(_7977);
    _7977 = NOVALUE;

    /** cmdline.e:344				appended_opts = 1*/
    _appended_opts_14384 = 1;
LC: 

    /** cmdline.e:347			if appended_opts then*/
    if (_appended_opts_14384 == 0)
    {
        goto LD; // [235] 248
    }
    else{
    }

    /** cmdline.e:349				opts = standardize_opts(opts, 0)*/
    RefDS(_opts_14360);
    _0 = _opts_14360;
    _opts_14360 = _4standardize_opts(_opts_14360, 0);
    DeRefDS(_0);
LD: 
L7: 

    /** cmdline.e:352		return opts*/
    DeRef(_7964);
    _7964 = NOVALUE;
    return _opts_14360;
    ;
}


object _4standardize_opts(object _opts_14409, object _auto_help_switches_14410)
{
    object _8016 = NOVALUE;
    object _8015 = NOVALUE;
    object _8013 = NOVALUE;
    object _8012 = NOVALUE;
    object _8011 = NOVALUE;
    object _8010 = NOVALUE;
    object _8009 = NOVALUE;
    object _8008 = NOVALUE;
    object _8007 = NOVALUE;
    object _8006 = NOVALUE;
    object _8005 = NOVALUE;
    object _8004 = NOVALUE;
    object _8003 = NOVALUE;
    object _8002 = NOVALUE;
    object _8000 = NOVALUE;
    object _7999 = NOVALUE;
    object _7998 = NOVALUE;
    object _7997 = NOVALUE;
    object _7996 = NOVALUE;
    object _7995 = NOVALUE;
    object _7994 = NOVALUE;
    object _7993 = NOVALUE;
    object _7992 = NOVALUE;
    object _7991 = NOVALUE;
    object _7990 = NOVALUE;
    object _7989 = NOVALUE;
    object _7987 = NOVALUE;
    object _7985 = NOVALUE;
    object _7984 = NOVALUE;
    object _7983 = NOVALUE;
    object _7982 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** cmdline.e:357		opts = update_opts( opts )*/
    RefDS(_opts_14409);
    _0 = _opts_14409;
    _opts_14409 = _4update_opts(_opts_14409);
    DeRefDS(_0);

    /** cmdline.e:359		check_for_duplicates( opts )*/
    RefDS(_opts_14409);
    _4check_for_duplicates(_opts_14409);

    /** cmdline.e:361		opts = standardize_help_options( opts, auto_help_switches )*/
    RefDS(_opts_14409);
    _0 = _opts_14409;
    _opts_14409 = _4standardize_help_options(_opts_14409, _auto_help_switches_14410);
    DeRefDS(_0);

    /** cmdline.e:364		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14409)){
            _7982 = SEQ_PTR(_opts_14409)->length;
    }
    else {
        _7982 = 1;
    }
    {
        object _i_14414;
        _i_14414 = 1;
L1: 
        if (_i_14414 > _7982){
            goto L2; // [32] 208
        }

        /** cmdline.e:365			if not find(HAS_PARAMETER, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_14409);
        _7983 = (object)*(((s1_ptr)_2)->base + _i_14414);
        _2 = (object)SEQ_PTR(_7983);
        _7984 = (object)*(((s1_ptr)_2)->base + 4);
        _7983 = NOVALUE;
        _7985 = find_from(112, _7984, 1);
        _7984 = NOVALUE;
        if (_7985 != 0)
        goto L3; // [54] 77
        _7985 = NOVALUE;

        /** cmdline.e:366				opts[i][OPTIONS] &= NO_PARAMETER*/
        _2 = (object)SEQ_PTR(_opts_14409);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opts_14409 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_14414 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _7989 = (object)*(((s1_ptr)_2)->base + 4);
        _7987 = NOVALUE;
        if (IS_SEQUENCE(_7989) && IS_ATOM(110)) {
            Append(&_7990, _7989, 110);
        }
        else if (IS_ATOM(_7989) && IS_SEQUENCE(110)) {
        }
        else {
            Concat((object_ptr)&_7990, _7989, 110);
            _7989 = NOVALUE;
        }
        _7989 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _7990;
        if( _1 != _7990 ){
            DeRef(_1);
        }
        _7990 = NOVALUE;
        _7987 = NOVALUE;
L3: 

        /** cmdline.e:369			if not find(MULTIPLE, opts[i][OPTIONS]) and not find(ONCE, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_14409);
        _7991 = (object)*(((s1_ptr)_2)->base + _i_14414);
        _2 = (object)SEQ_PTR(_7991);
        _7992 = (object)*(((s1_ptr)_2)->base + 4);
        _7991 = NOVALUE;
        _7993 = find_from(42, _7992, 1);
        _7992 = NOVALUE;
        _7994 = (_7993 == 0);
        _7993 = NOVALUE;
        if (_7994 == 0) {
            goto L4; // [95] 139
        }
        _2 = (object)SEQ_PTR(_opts_14409);
        _7996 = (object)*(((s1_ptr)_2)->base + _i_14414);
        _2 = (object)SEQ_PTR(_7996);
        _7997 = (object)*(((s1_ptr)_2)->base + 4);
        _7996 = NOVALUE;
        _7998 = find_from(49, _7997, 1);
        _7997 = NOVALUE;
        _7999 = (_7998 == 0);
        _7998 = NOVALUE;
        if (_7999 == 0)
        {
            DeRef(_7999);
            _7999 = NOVALUE;
            goto L4; // [116] 139
        }
        else{
            DeRef(_7999);
            _7999 = NOVALUE;
        }

        /** cmdline.e:370				opts[i][OPTIONS] &= ONCE*/
        _2 = (object)SEQ_PTR(_opts_14409);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opts_14409 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_14414 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _8002 = (object)*(((s1_ptr)_2)->base + 4);
        _8000 = NOVALUE;
        if (IS_SEQUENCE(_8002) && IS_ATOM(49)) {
            Append(&_8003, _8002, 49);
        }
        else if (IS_ATOM(_8002) && IS_SEQUENCE(49)) {
        }
        else {
            Concat((object_ptr)&_8003, _8002, 49);
            _8002 = NOVALUE;
        }
        _8002 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8003;
        if( _1 != _8003 ){
            DeRef(_1);
        }
        _8003 = NOVALUE;
        _8000 = NOVALUE;
L4: 

        /** cmdline.e:373			if not find(HAS_CASE, opts[i][OPTIONS]) and not find(NO_CASE, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_14409);
        _8004 = (object)*(((s1_ptr)_2)->base + _i_14414);
        _2 = (object)SEQ_PTR(_8004);
        _8005 = (object)*(((s1_ptr)_2)->base + 4);
        _8004 = NOVALUE;
        _8006 = find_from(99, _8005, 1);
        _8005 = NOVALUE;
        _8007 = (_8006 == 0);
        _8006 = NOVALUE;
        if (_8007 == 0) {
            goto L5; // [157] 201
        }
        _2 = (object)SEQ_PTR(_opts_14409);
        _8009 = (object)*(((s1_ptr)_2)->base + _i_14414);
        _2 = (object)SEQ_PTR(_8009);
        _8010 = (object)*(((s1_ptr)_2)->base + 4);
        _8009 = NOVALUE;
        _8011 = find_from(105, _8010, 1);
        _8010 = NOVALUE;
        _8012 = (_8011 == 0);
        _8011 = NOVALUE;
        if (_8012 == 0)
        {
            DeRef(_8012);
            _8012 = NOVALUE;
            goto L5; // [178] 201
        }
        else{
            DeRef(_8012);
            _8012 = NOVALUE;
        }

        /** cmdline.e:374				opts[i][OPTIONS] &= NO_CASE*/
        _2 = (object)SEQ_PTR(_opts_14409);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opts_14409 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_14414 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _8015 = (object)*(((s1_ptr)_2)->base + 4);
        _8013 = NOVALUE;
        if (IS_SEQUENCE(_8015) && IS_ATOM(105)) {
            Append(&_8016, _8015, 105);
        }
        else if (IS_ATOM(_8015) && IS_SEQUENCE(105)) {
        }
        else {
            Concat((object_ptr)&_8016, _8015, 105);
            _8015 = NOVALUE;
        }
        _8015 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8016;
        if( _1 != _8016 ){
            DeRef(_1);
        }
        _8016 = NOVALUE;
        _8013 = NOVALUE;
L5: 

        /** cmdline.e:376		end for*/
        _i_14414 = _i_14414 + 1;
        goto L1; // [203] 39
L2: 
        ;
    }

    /** cmdline.e:378		return opts*/
    DeRef(_8007);
    _8007 = NOVALUE;
    DeRef(_7994);
    _7994 = NOVALUE;
    return _opts_14409;
    ;
}


object _4print_help(object _opts_14455, object _cmds_14456)
{
    object _pad_size_14457 = NOVALUE;
    object _this_size_14458 = NOVALUE;
    object _extras_mandatory_14459 = NOVALUE;
    object _extras_opt_14460 = NOVALUE;
    object _param_name_14461 = NOVALUE;
    object _has_param_14462 = NOVALUE;
    object _8107 = NOVALUE;
    object _8106 = NOVALUE;
    object _8105 = NOVALUE;
    object _8104 = NOVALUE;
    object _8101 = NOVALUE;
    object _8100 = NOVALUE;
    object _8099 = NOVALUE;
    object _8098 = NOVALUE;
    object _8097 = NOVALUE;
    object _8096 = NOVALUE;
    object _8095 = NOVALUE;
    object _8094 = NOVALUE;
    object _8093 = NOVALUE;
    object _8092 = NOVALUE;
    object _8086 = NOVALUE;
    object _8085 = NOVALUE;
    object _8083 = NOVALUE;
    object _8082 = NOVALUE;
    object _8081 = NOVALUE;
    object _8080 = NOVALUE;
    object _8079 = NOVALUE;
    object _8078 = NOVALUE;
    object _8076 = NOVALUE;
    object _8075 = NOVALUE;
    object _8074 = NOVALUE;
    object _8070 = NOVALUE;
    object _8069 = NOVALUE;
    object _8067 = NOVALUE;
    object _8066 = NOVALUE;
    object _8065 = NOVALUE;
    object _8064 = NOVALUE;
    object _8063 = NOVALUE;
    object _8062 = NOVALUE;
    object _8061 = NOVALUE;
    object _8058 = NOVALUE;
    object _8057 = NOVALUE;
    object _8056 = NOVALUE;
    object _8054 = NOVALUE;
    object _8053 = NOVALUE;
    object _8052 = NOVALUE;
    object _8051 = NOVALUE;
    object _8050 = NOVALUE;
    object _8049 = NOVALUE;
    object _8048 = NOVALUE;
    object _8045 = NOVALUE;
    object _8044 = NOVALUE;
    object _8043 = NOVALUE;
    object _8041 = NOVALUE;
    object _8040 = NOVALUE;
    object _8039 = NOVALUE;
    object _8038 = NOVALUE;
    object _8037 = NOVALUE;
    object _8036 = NOVALUE;
    object _8035 = NOVALUE;
    object _8034 = NOVALUE;
    object _8033 = NOVALUE;
    object _8032 = NOVALUE;
    object _8031 = NOVALUE;
    object _8030 = NOVALUE;
    object _8029 = NOVALUE;
    object _8028 = NOVALUE;
    object _8027 = NOVALUE;
    object _8026 = NOVALUE;
    object _8025 = NOVALUE;
    object _8024 = NOVALUE;
    object _8023 = NOVALUE;
    object _8022 = NOVALUE;
    object _8021 = NOVALUE;
    object _8020 = NOVALUE;
    object _8019 = NOVALUE;
    object _8018 = NOVALUE;
    object _8017 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:384		integer pad_size = 0*/
    _pad_size_14457 = 0;

    /** cmdline.e:386		integer extras_mandatory = 0*/
    _extras_mandatory_14459 = 0;

    /** cmdline.e:387		integer extras_opt = 0*/
    _extras_opt_14460 = 0;

    /** cmdline.e:391		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14455)){
            _8017 = SEQ_PTR(_opts_14455)->length;
    }
    else {
        _8017 = 1;
    }
    {
        object _i_14464;
        _i_14464 = 1;
L1: 
        if (_i_14464 > _8017){
            goto L2; // [25] 456
        }

        /** cmdline.e:392			this_size = 0*/
        _this_size_14458 = 0;

        /** cmdline.e:393			param_name = ""*/
        RefDS(_5);
        DeRef(_param_name_14461);
        _param_name_14461 = _5;

        /** cmdline.e:395			if atom(opts[i][SHORTNAME]) and opts[i][SHORTNAME] = HEADER then*/
        _2 = (object)SEQ_PTR(_opts_14455);
        _8018 = (object)*(((s1_ptr)_2)->base + _i_14464);
        _2 = (object)SEQ_PTR(_8018);
        _8019 = (object)*(((s1_ptr)_2)->base + 1);
        _8018 = NOVALUE;
        _8020 = IS_ATOM(_8019);
        _8019 = NOVALUE;
        if (_8020 == 0) {
            goto L3; // [57] 82
        }
        _2 = (object)SEQ_PTR(_opts_14455);
        _8022 = (object)*(((s1_ptr)_2)->base + _i_14464);
        _2 = (object)SEQ_PTR(_8022);
        _8023 = (object)*(((s1_ptr)_2)->base + 1);
        _8022 = NOVALUE;
        if (IS_ATOM_INT(_8023)) {
            _8024 = (_8023 == 72);
        }
        else {
            _8024 = binary_op(EQUALS, _8023, 72);
        }
        _8023 = NOVALUE;
        if (_8024 == 0) {
            DeRef(_8024);
            _8024 = NOVALUE;
            goto L3; // [74] 82
        }
        else {
            if (!IS_ATOM_INT(_8024) && DBL_PTR(_8024)->dbl == 0.0){
                DeRef(_8024);
                _8024 = NOVALUE;
                goto L3; // [74] 82
            }
            DeRef(_8024);
            _8024 = NOVALUE;
        }
        DeRef(_8024);
        _8024 = NOVALUE;

        /** cmdline.e:396				continue*/
        goto L4; // [79] 451
L3: 

        /** cmdline.e:399			if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_14455);
        _8025 = (object)*(((s1_ptr)_2)->base + _i_14464);
        _2 = (object)SEQ_PTR(_8025);
        _8026 = (object)*(((s1_ptr)_2)->base + 1);
        _8025 = NOVALUE;
        _8027 = IS_ATOM(_8026);
        _8026 = NOVALUE;
        if (_8027 == 0) {
            goto L5; // [95] 148
        }
        _2 = (object)SEQ_PTR(_opts_14455);
        _8029 = (object)*(((s1_ptr)_2)->base + _i_14464);
        _2 = (object)SEQ_PTR(_8029);
        _8030 = (object)*(((s1_ptr)_2)->base + 2);
        _8029 = NOVALUE;
        _8031 = IS_ATOM(_8030);
        _8030 = NOVALUE;
        if (_8031 == 0)
        {
            _8031 = NOVALUE;
            goto L5; // [111] 148
        }
        else{
            _8031 = NOVALUE;
        }

        /** cmdline.e:400				extras_opt = i*/
        _extras_opt_14460 = _i_14464;

        /** cmdline.e:401				if find(MANDATORY, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_14455);
        _8032 = (object)*(((s1_ptr)_2)->base + _i_14464);
        _2 = (object)SEQ_PTR(_8032);
        _8033 = (object)*(((s1_ptr)_2)->base + 4);
        _8032 = NOVALUE;
        _8034 = find_from(109, _8033, 1);
        _8033 = NOVALUE;
        if (_8034 == 0)
        {
            _8034 = NOVALUE;
            goto L4; // [134] 451
        }
        else{
            _8034 = NOVALUE;
        }

        /** cmdline.e:402					extras_mandatory = 1*/
        _extras_mandatory_14459 = 1;

        /** cmdline.e:405				continue*/
        goto L4; // [145] 451
L5: 

        /** cmdline.e:408			if sequence(opts[i][SHORTNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_14455);
        _8035 = (object)*(((s1_ptr)_2)->base + _i_14464);
        _2 = (object)SEQ_PTR(_8035);
        _8036 = (object)*(((s1_ptr)_2)->base + 1);
        _8035 = NOVALUE;
        _8037 = IS_SEQUENCE(_8036);
        _8036 = NOVALUE;
        if (_8037 == 0)
        {
            _8037 = NOVALUE;
            goto L6; // [161] 214
        }
        else{
            _8037 = NOVALUE;
        }

        /** cmdline.e:409				this_size += length(opts[i][SHORTNAME]) + 1 -- Allow for "-"*/
        _2 = (object)SEQ_PTR(_opts_14455);
        _8038 = (object)*(((s1_ptr)_2)->base + _i_14464);
        _2 = (object)SEQ_PTR(_8038);
        _8039 = (object)*(((s1_ptr)_2)->base + 1);
        _8038 = NOVALUE;
        if (IS_SEQUENCE(_8039)){
                _8040 = SEQ_PTR(_8039)->length;
        }
        else {
            _8040 = 1;
        }
        _8039 = NOVALUE;
        _8041 = _8040 + 1;
        _8040 = NOVALUE;
        _this_size_14458 = _this_size_14458 + _8041;
        _8041 = NOVALUE;

        /** cmdline.e:410				if find(MANDATORY, opts[i][OPTIONS]) = 0 then*/
        _2 = (object)SEQ_PTR(_opts_14455);
        _8043 = (object)*(((s1_ptr)_2)->base + _i_14464);
        _2 = (object)SEQ_PTR(_8043);
        _8044 = (object)*(((s1_ptr)_2)->base + 4);
        _8043 = NOVALUE;
        _8045 = find_from(109, _8044, 1);
        _8044 = NOVALUE;
        if (_8045 != 0)
        goto L7; // [202] 213

        /** cmdline.e:411					this_size += 2 -- Allow for '[' ']'*/
        _this_size_14458 = _this_size_14458 + 2;
L7: 
L6: 

        /** cmdline.e:415			if sequence(opts[i][LONGNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_14455);
        _8048 = (object)*(((s1_ptr)_2)->base + _i_14464);
        _2 = (object)SEQ_PTR(_8048);
        _8049 = (object)*(((s1_ptr)_2)->base + 2);
        _8048 = NOVALUE;
        _8050 = IS_SEQUENCE(_8049);
        _8049 = NOVALUE;
        if (_8050 == 0)
        {
            _8050 = NOVALUE;
            goto L8; // [227] 280
        }
        else{
            _8050 = NOVALUE;
        }

        /** cmdline.e:416				this_size += length(opts[i][LONGNAME]) + 2 -- Allow for "--"*/
        _2 = (object)SEQ_PTR(_opts_14455);
        _8051 = (object)*(((s1_ptr)_2)->base + _i_14464);
        _2 = (object)SEQ_PTR(_8051);
        _8052 = (object)*(((s1_ptr)_2)->base + 2);
        _8051 = NOVALUE;
        if (IS_SEQUENCE(_8052)){
                _8053 = SEQ_PTR(_8052)->length;
        }
        else {
            _8053 = 1;
        }
        _8052 = NOVALUE;
        _8054 = _8053 + 2;
        _8053 = NOVALUE;
        _this_size_14458 = _this_size_14458 + _8054;
        _8054 = NOVALUE;

        /** cmdline.e:417				if find(MANDATORY, opts[i][OPTIONS]) = 0 then*/
        _2 = (object)SEQ_PTR(_opts_14455);
        _8056 = (object)*(((s1_ptr)_2)->base + _i_14464);
        _2 = (object)SEQ_PTR(_8056);
        _8057 = (object)*(((s1_ptr)_2)->base + 4);
        _8056 = NOVALUE;
        _8058 = find_from(109, _8057, 1);
        _8057 = NOVALUE;
        if (_8058 != 0)
        goto L9; // [268] 279

        /** cmdline.e:418					this_size += 2 -- Allow for '[' ']'*/
        _this_size_14458 = _this_size_14458 + 2;
L9: 
L8: 

        /** cmdline.e:422			if sequence(opts[i][SHORTNAME]) and sequence(opts[i][LONGNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_14455);
        _8061 = (object)*(((s1_ptr)_2)->base + _i_14464);
        _2 = (object)SEQ_PTR(_8061);
        _8062 = (object)*(((s1_ptr)_2)->base + 1);
        _8061 = NOVALUE;
        _8063 = IS_SEQUENCE(_8062);
        _8062 = NOVALUE;
        if (_8063 == 0) {
            goto LA; // [293] 319
        }
        _2 = (object)SEQ_PTR(_opts_14455);
        _8065 = (object)*(((s1_ptr)_2)->base + _i_14464);
        _2 = (object)SEQ_PTR(_8065);
        _8066 = (object)*(((s1_ptr)_2)->base + 2);
        _8065 = NOVALUE;
        _8067 = IS_SEQUENCE(_8066);
        _8066 = NOVALUE;
        if (_8067 == 0)
        {
            _8067 = NOVALUE;
            goto LA; // [309] 319
        }
        else{
            _8067 = NOVALUE;
        }

        /** cmdline.e:423				this_size += 2 -- Allow for ", " between short and long names*/
        _this_size_14458 = _this_size_14458 + 2;
LA: 

        /** cmdline.e:426			has_param = find(HAS_PARAMETER, opts[i][OPTIONS])*/
        _2 = (object)SEQ_PTR(_opts_14455);
        _8069 = (object)*(((s1_ptr)_2)->base + _i_14464);
        _2 = (object)SEQ_PTR(_8069);
        _8070 = (object)*(((s1_ptr)_2)->base + 4);
        _8069 = NOVALUE;
        _has_param_14462 = find_from(112, _8070, 1);
        _8070 = NOVALUE;

        /** cmdline.e:427			if has_param != 0 then*/
        if (_has_param_14462 == 0)
        goto LB; // [336] 437

        /** cmdline.e:428				this_size += 1 -- Allow for " "*/
        _this_size_14458 = _this_size_14458 + 1;

        /** cmdline.e:429				if has_param < length(opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_14455);
        _8074 = (object)*(((s1_ptr)_2)->base + _i_14464);
        _2 = (object)SEQ_PTR(_8074);
        _8075 = (object)*(((s1_ptr)_2)->base + 4);
        _8074 = NOVALUE;
        if (IS_SEQUENCE(_8075)){
                _8076 = SEQ_PTR(_8075)->length;
        }
        else {
            _8076 = 1;
        }
        _8075 = NOVALUE;
        if (_has_param_14462 >= _8076)
        goto LC; // [359] 413

        /** cmdline.e:431					if sequence(opts[i][OPTIONS][has_param]) then*/
        _2 = (object)SEQ_PTR(_opts_14455);
        _8078 = (object)*(((s1_ptr)_2)->base + _i_14464);
        _2 = (object)SEQ_PTR(_8078);
        _8079 = (object)*(((s1_ptr)_2)->base + 4);
        _8078 = NOVALUE;
        _2 = (object)SEQ_PTR(_8079);
        _8080 = (object)*(((s1_ptr)_2)->base + _has_param_14462);
        _8079 = NOVALUE;
        _8081 = IS_SEQUENCE(_8080);
        _8080 = NOVALUE;
        if (_8081 == 0)
        {
            _8081 = NOVALUE;
            goto LD; // [380] 402
        }
        else{
            _8081 = NOVALUE;
        }

        /** cmdline.e:432						param_name = opts[i][OPTIONS][has_param]*/
        _2 = (object)SEQ_PTR(_opts_14455);
        _8082 = (object)*(((s1_ptr)_2)->base + _i_14464);
        _2 = (object)SEQ_PTR(_8082);
        _8083 = (object)*(((s1_ptr)_2)->base + 4);
        _8082 = NOVALUE;
        DeRef(_param_name_14461);
        _2 = (object)SEQ_PTR(_8083);
        _param_name_14461 = (object)*(((s1_ptr)_2)->base + _has_param_14462);
        Ref(_param_name_14461);
        _8083 = NOVALUE;
        goto LE; // [399] 421
LD: 

        /** cmdline.e:434						param_name = "x"*/
        RefDS(_7915);
        DeRef(_param_name_14461);
        _param_name_14461 = _7915;
        goto LE; // [410] 421
LC: 

        /** cmdline.e:437					param_name = "x"*/
        RefDS(_7915);
        DeRef(_param_name_14461);
        _param_name_14461 = _7915;
LE: 

        /** cmdline.e:439				this_size += 2 + length(param_name)*/
        if (IS_SEQUENCE(_param_name_14461)){
                _8085 = SEQ_PTR(_param_name_14461)->length;
        }
        else {
            _8085 = 1;
        }
        _8086 = 2 + _8085;
        _8085 = NOVALUE;
        _this_size_14458 = _this_size_14458 + _8086;
        _8086 = NOVALUE;
LB: 

        /** cmdline.e:442			if pad_size < this_size then*/
        if (_pad_size_14457 >= _this_size_14458)
        goto LF; // [439] 449

        /** cmdline.e:443				pad_size = this_size*/
        _pad_size_14457 = _this_size_14458;
LF: 

        /** cmdline.e:445		end for*/
L4: 
        _i_14464 = _i_14464 + 1;
        goto L1; // [451] 32
L2: 
        ;
    }

    /** cmdline.e:446		pad_size += 3 -- Allow for minimum gap between cmd and its description*/
    _pad_size_14457 = _pad_size_14457 + 3;

    /** cmdline.e:448		printf(1, "%s options:\n", {cmds[2]})*/
    _2 = (object)SEQ_PTR(_cmds_14456);
    _8092 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_8092);
    ((intptr_t*)_2)[1] = _8092;
    _8093 = MAKE_SEQ(_1);
    _8092 = NOVALUE;
    EPrintf(1, _8091, _8093);
    DeRefDS(_8093);
    _8093 = NOVALUE;

    /** cmdline.e:450		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14455)){
            _8094 = SEQ_PTR(_opts_14455)->length;
    }
    else {
        _8094 = 1;
    }
    {
        object _i_14556;
        _i_14556 = 1;
L10: 
        if (_i_14556 > _8094){
            goto L11; // [481] 574
        }

        /** cmdline.e:451			if atom(opts[i][1]) and opts[i][1] = HEADER then*/
        _2 = (object)SEQ_PTR(_opts_14455);
        _8095 = (object)*(((s1_ptr)_2)->base + _i_14556);
        _2 = (object)SEQ_PTR(_8095);
        _8096 = (object)*(((s1_ptr)_2)->base + 1);
        _8095 = NOVALUE;
        _8097 = IS_ATOM(_8096);
        _8096 = NOVALUE;
        if (_8097 == 0) {
            goto L12; // [501] 557
        }
        _2 = (object)SEQ_PTR(_opts_14455);
        _8099 = (object)*(((s1_ptr)_2)->base + _i_14556);
        _2 = (object)SEQ_PTR(_8099);
        _8100 = (object)*(((s1_ptr)_2)->base + 1);
        _8099 = NOVALUE;
        if (IS_ATOM_INT(_8100)) {
            _8101 = (_8100 == 72);
        }
        else {
            _8101 = binary_op(EQUALS, _8100, 72);
        }
        _8100 = NOVALUE;
        if (_8101 == 0) {
            DeRef(_8101);
            _8101 = NOVALUE;
            goto L12; // [518] 557
        }
        else {
            if (!IS_ATOM_INT(_8101) && DBL_PTR(_8101)->dbl == 0.0){
                DeRef(_8101);
                _8101 = NOVALUE;
                goto L12; // [518] 557
            }
            DeRef(_8101);
            _8101 = NOVALUE;
        }
        DeRef(_8101);
        _8101 = NOVALUE;

        /** cmdline.e:452				if i > 1 then*/
        if (_i_14556 <= 1)
        goto L13; // [523] 534

        /** cmdline.e:453					printf(1, "\n")*/
        EPrintf(1, _3122, _5);
L13: 

        /** cmdline.e:456				printf(1, "%s\n", { opts[i][2] })*/
        _2 = (object)SEQ_PTR(_opts_14455);
        _8104 = (object)*(((s1_ptr)_2)->base + _i_14556);
        _2 = (object)SEQ_PTR(_8104);
        _8105 = (object)*(((s1_ptr)_2)->base + 2);
        _8104 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_8105);
        ((intptr_t*)_2)[1] = _8105;
        _8106 = MAKE_SEQ(_1);
        _8105 = NOVALUE;
        EPrintf(1, _8103, _8106);
        DeRefDS(_8106);
        _8106 = NOVALUE;

        /** cmdline.e:457				continue*/
        goto L14; // [554] 569
L12: 

        /** cmdline.e:460			print_option_help( opts[i], pad_size )*/
        _2 = (object)SEQ_PTR(_opts_14455);
        _8107 = (object)*(((s1_ptr)_2)->base + _i_14556);
        Ref(_8107);
        _4print_option_help(_8107, _pad_size_14457);
        _8107 = NOVALUE;

        /** cmdline.e:461		end for*/
L14: 
        _i_14556 = _i_14556 + 1;
        goto L10; // [569] 488
L11: 
        ;
    }

    /** cmdline.e:463		print_extras_help( opts, extras_mandatory, extras_opt )*/
    RefDS(_opts_14455);
    _4print_extras_help(_opts_14455, _extras_mandatory_14459, _extras_opt_14460);

    /** cmdline.e:465		return pad_size*/
    DeRefDS(_opts_14455);
    DeRefDS(_cmds_14456);
    DeRef(_param_name_14461);
    _8052 = NOVALUE;
    _8039 = NOVALUE;
    _8075 = NOVALUE;
    return _pad_size_14457;
    ;
}


void _4print_extras_help(object _opts_14577, object _extras_mandatory_14578, object _extras_opt_14579)
{
    object _8124 = NOVALUE;
    object _8123 = NOVALUE;
    object _8122 = NOVALUE;
    object _8120 = NOVALUE;
    object _8119 = NOVALUE;
    object _8118 = NOVALUE;
    object _8115 = NOVALUE;
    object _8114 = NOVALUE;
    object _8113 = NOVALUE;
    object _8111 = NOVALUE;
    object _8110 = NOVALUE;
    object _8109 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:470		if extras_mandatory != 0 then*/
    if (_extras_mandatory_14578 == 0)
    goto L1; // [9] 64

    /** cmdline.e:471			if length(opts[extras_opt][DESCRIPTION]) > 0 then*/
    _2 = (object)SEQ_PTR(_opts_14577);
    _8109 = (object)*(((s1_ptr)_2)->base + _extras_opt_14579);
    _2 = (object)SEQ_PTR(_8109);
    _8110 = (object)*(((s1_ptr)_2)->base + 3);
    _8109 = NOVALUE;
    if (IS_SEQUENCE(_8110)){
            _8111 = SEQ_PTR(_8110)->length;
    }
    else {
        _8111 = 1;
    }
    _8110 = NOVALUE;
    if (_8111 <= 0)
    goto L2; // [26] 55

    /** cmdline.e:472				puts(1, "\n" & opts[extras_opt][DESCRIPTION])*/
    _2 = (object)SEQ_PTR(_opts_14577);
    _8113 = (object)*(((s1_ptr)_2)->base + _extras_opt_14579);
    _2 = (object)SEQ_PTR(_8113);
    _8114 = (object)*(((s1_ptr)_2)->base + 3);
    _8113 = NOVALUE;
    if (IS_SEQUENCE(_3122) && IS_ATOM(_8114)) {
        Ref(_8114);
        Append(&_8115, _3122, _8114);
    }
    else if (IS_ATOM(_3122) && IS_SEQUENCE(_8114)) {
    }
    else {
        Concat((object_ptr)&_8115, _3122, _8114);
    }
    _8114 = NOVALUE;
    EPuts(1, _8115); // DJP 
    DeRefDS(_8115);
    _8115 = NOVALUE;

    /** cmdline.e:473				puts(1, '\n')*/
    EPuts(1, 10); // DJP 
    goto L3; // [52] 120
L2: 

    /** cmdline.e:475				puts(1, "One or more additional arguments are also required\n")*/
    EPuts(1, _8116); // DJP 
    goto L3; // [61] 120
L1: 

    /** cmdline.e:477		elsif extras_opt > 0 then*/
    if (_extras_opt_14579 <= 0)
    goto L4; // [66] 119

    /** cmdline.e:478			if length(opts[extras_opt][DESCRIPTION]) > 0 then*/
    _2 = (object)SEQ_PTR(_opts_14577);
    _8118 = (object)*(((s1_ptr)_2)->base + _extras_opt_14579);
    _2 = (object)SEQ_PTR(_8118);
    _8119 = (object)*(((s1_ptr)_2)->base + 3);
    _8118 = NOVALUE;
    if (IS_SEQUENCE(_8119)){
            _8120 = SEQ_PTR(_8119)->length;
    }
    else {
        _8120 = 1;
    }
    _8119 = NOVALUE;
    if (_8120 <= 0)
    goto L5; // [83] 112

    /** cmdline.e:479				puts(1, "\n" & opts[extras_opt][DESCRIPTION])*/
    _2 = (object)SEQ_PTR(_opts_14577);
    _8122 = (object)*(((s1_ptr)_2)->base + _extras_opt_14579);
    _2 = (object)SEQ_PTR(_8122);
    _8123 = (object)*(((s1_ptr)_2)->base + 3);
    _8122 = NOVALUE;
    if (IS_SEQUENCE(_3122) && IS_ATOM(_8123)) {
        Ref(_8123);
        Append(&_8124, _3122, _8123);
    }
    else if (IS_ATOM(_3122) && IS_SEQUENCE(_8123)) {
    }
    else {
        Concat((object_ptr)&_8124, _3122, _8123);
    }
    _8123 = NOVALUE;
    EPuts(1, _8124); // DJP 
    DeRefDS(_8124);
    _8124 = NOVALUE;

    /** cmdline.e:480				puts(1, '\n')*/
    EPuts(1, 10); // DJP 
    goto L6; // [109] 118
L5: 

    /** cmdline.e:482				puts(1, "One or more additional arguments can be supplied.\n")*/
    EPuts(1, _8125); // DJP 
L6: 
L4: 
L3: 

    /** cmdline.e:485	end procedure*/
    DeRefDS(_opts_14577);
    _8110 = NOVALUE;
    _8119 = NOVALUE;
    return;
    ;
}


void _4local_help(object _opts_14606, object _add_help_rid_14607, object _cmds_14608, object _std_14610, object _parse_options_14611)
{
    object _cmd_14612 = NOVALUE;
    object _is_mandatory_14613 = NOVALUE;
    object _extras_mandatory_14614 = NOVALUE;
    object _extras_opt_14615 = NOVALUE;
    object _auto_help_14616 = NOVALUE;
    object _po_14617 = NOVALUE;
    object _msg_inlined_crash_at_94_14636 = NOVALUE;
    object _pad_size_14643 = NOVALUE;
    object _8134 = NOVALUE;
    object _8131 = NOVALUE;
    object _8129 = NOVALUE;
    object _8127 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:492		integer extras_mandatory = 0*/
    _extras_mandatory_14614 = 0;

    /** cmdline.e:493		integer extras_opt = 0*/
    _extras_opt_14615 = 0;

    /** cmdline.e:494		integer auto_help = 1*/
    _auto_help_14616 = 1;

    /** cmdline.e:496		integer po = 1*/
    _po_14617 = 1;

    /** cmdline.e:497		if atom(parse_options) then*/
    _8127 = IS_ATOM(_parse_options_14611);
    if (_8127 == 0)
    {
        _8127 = NOVALUE;
        goto L1; // [32] 42
    }
    else{
        _8127 = NOVALUE;
    }

    /** cmdline.e:498			parse_options = {parse_options}*/
    _0 = _parse_options_14611;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_parse_options_14611);
    ((intptr_t*)_2)[1] = _parse_options_14611;
    _parse_options_14611 = MAKE_SEQ(_1);
    DeRefi(_0);
L1: 

    /** cmdline.e:501		while po <= length(parse_options) do*/
L2: 
    if (IS_SEQUENCE(_parse_options_14611)){
            _8129 = SEQ_PTR(_parse_options_14611)->length;
    }
    else {
        _8129 = 1;
    }
    if (_po_14617 > _8129)
    goto L3; // [50] 143

    /** cmdline.e:502			switch parse_options[po] do*/
    _2 = (object)SEQ_PTR(_parse_options_14611);
    _8131 = (object)*(((s1_ptr)_2)->base + _po_14617);
    if (IS_SEQUENCE(_8131) ){
        goto L4; // [60] 129
    }
    if(!IS_ATOM_INT(_8131)){
        if( (DBL_PTR(_8131)->dbl != (eudouble) ((object) DBL_PTR(_8131)->dbl) ) ){
            goto L4; // [60] 129
        }
        _0 = (object) DBL_PTR(_8131)->dbl;
    }
    else {
        _0 = _8131;
    };
    _8131 = NOVALUE;
    switch ( _0 ){ 

        /** cmdline.e:503				case HELP_RID then*/
        case 1:

        /** cmdline.e:504					if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_14611)){
                _8134 = SEQ_PTR(_parse_options_14611)->length;
        }
        else {
            _8134 = 1;
        }
        if (_po_14617 >= _8134)
        goto L5; // [74] 93

        /** cmdline.e:505						po += 1*/
        _po_14617 = _po_14617 + 1;

        /** cmdline.e:506						add_help_rid = parse_options[po]*/
        DeRef(_add_help_rid_14607);
        _2 = (object)SEQ_PTR(_parse_options_14611);
        _add_help_rid_14607 = (object)*(((s1_ptr)_2)->base + _po_14617);
        Ref(_add_help_rid_14607);
        goto L6; // [90] 132
L5: 

        /** cmdline.e:508						error:crash("HELP_RID was given to cmd_parse with no routine_id")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_94_14636);
        _msg_inlined_crash_at_94_14636 = EPrintf(-9999999, _8138, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_94_14636);

        /** error.e:53	end procedure*/
        goto L7; // [108] 111
L7: 
        DeRefi(_msg_inlined_crash_at_94_14636);
        _msg_inlined_crash_at_94_14636 = NOVALUE;
        goto L6; // [114] 132

        /** cmdline.e:511				case NO_HELP then*/
        case 9:

        /** cmdline.e:512					auto_help = 0*/
        _auto_help_14616 = 0;
        goto L6; // [125] 132

        /** cmdline.e:514				case else*/
        default:
L4: 
    ;}L6: 

    /** cmdline.e:518			po += 1*/
    _po_14617 = _po_14617 + 1;

    /** cmdline.e:519		end while*/
    goto L2; // [140] 47
L3: 

    /** cmdline.e:521		if std = 0 then*/
    if (_std_14610 != 0)
    goto L8; // [145] 159

    /** cmdline.e:522			opts = standardize_opts(opts, auto_help)*/
    RefDS(_opts_14606);
    _0 = _opts_14606;
    _opts_14606 = _4standardize_opts(_opts_14606, _auto_help_14616);
    DeRefDS(_0);
L8: 

    /** cmdline.e:525		integer pad_size = print_help( opts, cmds )*/
    RefDS(_opts_14606);
    RefDS(_cmds_14608);
    _pad_size_14643 = _4print_help(_opts_14606, _cmds_14608);
    if (!IS_ATOM_INT(_pad_size_14643)) {
        _1 = (object)(DBL_PTR(_pad_size_14643)->dbl);
        DeRefDS(_pad_size_14643);
        _pad_size_14643 = _1;
    }

    /** cmdline.e:527		call_user_help( add_help_rid )*/
    Ref(_add_help_rid_14607);
    _4call_user_help(_add_help_rid_14607);

    /** cmdline.e:529	end procedure*/
    DeRefDS(_opts_14606);
    DeRef(_add_help_rid_14607);
    DeRefDS(_cmds_14608);
    DeRef(_parse_options_14611);
    return;
    ;
}


void _4call_user_help(object _add_help_rid_14648)
{
    object _8158 = NOVALUE;
    object _8157 = NOVALUE;
    object _8156 = NOVALUE;
    object _8155 = NOVALUE;
    object _8153 = NOVALUE;
    object _8152 = NOVALUE;
    object _8151 = NOVALUE;
    object _8150 = NOVALUE;
    object _8149 = NOVALUE;
    object _8147 = NOVALUE;
    object _8145 = NOVALUE;
    object _8143 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:532		if atom(add_help_rid) then*/
    _8143 = IS_ATOM(_add_help_rid_14648);
    if (_8143 == 0)
    {
        _8143 = NOVALUE;
        goto L1; // [6] 34
    }
    else{
        _8143 = NOVALUE;
    }

    /** cmdline.e:533			if add_help_rid >= 0 then*/
    if (binary_op_a(LESS, _add_help_rid_14648, 0)){
        goto L2; // [11] 142
    }

    /** cmdline.e:534				puts(1, "\n")*/
    EPuts(1, _3122); // DJP 

    /** cmdline.e:535				call_proc(add_help_rid, {})*/
    _0 = (object)_00[_add_help_rid_14648].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** cmdline.e:536				puts(1, "\n")*/
    EPuts(1, _3122); // DJP 
    goto L2; // [31] 142
L1: 

    /** cmdline.e:539			if length(add_help_rid) > 0 then*/
    if (IS_SEQUENCE(_add_help_rid_14648)){
            _8145 = SEQ_PTR(_add_help_rid_14648)->length;
    }
    else {
        _8145 = 1;
    }
    if (_8145 <= 0)
    goto L3; // [39] 141

    /** cmdline.e:540				puts(1, "\n")*/
    EPuts(1, _3122); // DJP 

    /** cmdline.e:541				if types:t_display(add_help_rid) then*/
    Ref(_add_help_rid_14648);
    _8147 = _13t_display(_add_help_rid_14648);
    if (_8147 == 0) {
        DeRef(_8147);
        _8147 = NOVALUE;
        goto L4; // [54] 64
    }
    else {
        if (!IS_ATOM_INT(_8147) && DBL_PTR(_8147)->dbl == 0.0){
            DeRef(_8147);
            _8147 = NOVALUE;
            goto L4; // [54] 64
        }
        DeRef(_8147);
        _8147 = NOVALUE;
    }
    DeRef(_8147);
    _8147 = NOVALUE;

    /** cmdline.e:542					add_help_rid = {add_help_rid}*/
    _0 = _add_help_rid_14648;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_add_help_rid_14648);
    ((intptr_t*)_2)[1] = _add_help_rid_14648;
    _add_help_rid_14648 = MAKE_SEQ(_1);
    DeRef(_0);
L4: 

    /** cmdline.e:545				for i = 1 to length(add_help_rid) do*/
    if (IS_SEQUENCE(_add_help_rid_14648)){
            _8149 = SEQ_PTR(_add_help_rid_14648)->length;
    }
    else {
        _8149 = 1;
    }
    {
        object _i_14661;
        _i_14661 = 1;
L5: 
        if (_i_14661 > _8149){
            goto L6; // [69] 135
        }

        /** cmdline.e:546					puts(1, add_help_rid[i])*/
        _2 = (object)SEQ_PTR(_add_help_rid_14648);
        _8150 = (object)*(((s1_ptr)_2)->base + _i_14661);
        EPuts(1, _8150); // DJP 
        _8150 = NOVALUE;

        /** cmdline.e:547					if length(add_help_rid[i]) = 0 or add_help_rid[i][$] != '\n' then*/
        _2 = (object)SEQ_PTR(_add_help_rid_14648);
        _8151 = (object)*(((s1_ptr)_2)->base + _i_14661);
        if (IS_SEQUENCE(_8151)){
                _8152 = SEQ_PTR(_8151)->length;
        }
        else {
            _8152 = 1;
        }
        _8151 = NOVALUE;
        _8153 = (_8152 == 0);
        _8152 = NOVALUE;
        if (_8153 != 0) {
            goto L7; // [98] 122
        }
        _2 = (object)SEQ_PTR(_add_help_rid_14648);
        _8155 = (object)*(((s1_ptr)_2)->base + _i_14661);
        if (IS_SEQUENCE(_8155)){
                _8156 = SEQ_PTR(_8155)->length;
        }
        else {
            _8156 = 1;
        }
        _2 = (object)SEQ_PTR(_8155);
        _8157 = (object)*(((s1_ptr)_2)->base + _8156);
        _8155 = NOVALUE;
        if (IS_ATOM_INT(_8157)) {
            _8158 = (_8157 != 10);
        }
        else {
            _8158 = binary_op(NOTEQ, _8157, 10);
        }
        _8157 = NOVALUE;
        if (_8158 == 0) {
            DeRef(_8158);
            _8158 = NOVALUE;
            goto L8; // [118] 128
        }
        else {
            if (!IS_ATOM_INT(_8158) && DBL_PTR(_8158)->dbl == 0.0){
                DeRef(_8158);
                _8158 = NOVALUE;
                goto L8; // [118] 128
            }
            DeRef(_8158);
            _8158 = NOVALUE;
        }
        DeRef(_8158);
        _8158 = NOVALUE;
L7: 

        /** cmdline.e:548						puts(1, '\n')*/
        EPuts(1, 10); // DJP 
L8: 

        /** cmdline.e:550				end for*/
        _i_14661 = _i_14661 + 1;
        goto L5; // [130] 76
L6: 
        ;
    }

    /** cmdline.e:552				puts(1, "\n")*/
    EPuts(1, _3122); // DJP 
L3: 
L2: 

    /** cmdline.e:555	end procedure*/
    DeRef(_add_help_rid_14648);
    DeRef(_8153);
    _8153 = NOVALUE;
    _8151 = NOVALUE;
    return;
    ;
}


void _4print_option_help(object _opt_14675, object _pad_size_14676)
{
    object _has_param_14683 = NOVALUE;
    object _param_name_14686 = NOVALUE;
    object _is_mandatory_14702 = NOVALUE;
    object _cmd_14706 = NOVALUE;
    object _8215 = NOVALUE;
    object _8214 = NOVALUE;
    object _8213 = NOVALUE;
    object _8212 = NOVALUE;
    object _8211 = NOVALUE;
    object _8210 = NOVALUE;
    object _8209 = NOVALUE;
    object _8206 = NOVALUE;
    object _8202 = NOVALUE;
    object _8199 = NOVALUE;
    object _8198 = NOVALUE;
    object _8193 = NOVALUE;
    object _8192 = NOVALUE;
    object _8191 = NOVALUE;
    object _8187 = NOVALUE;
    object _8184 = NOVALUE;
    object _8183 = NOVALUE;
    object _8180 = NOVALUE;
    object _8179 = NOVALUE;
    object _8177 = NOVALUE;
    object _8176 = NOVALUE;
    object _8174 = NOVALUE;
    object _8173 = NOVALUE;
    object _8172 = NOVALUE;
    object _8171 = NOVALUE;
    object _8168 = NOVALUE;
    object _8167 = NOVALUE;
    object _8164 = NOVALUE;
    object _8163 = NOVALUE;
    object _8162 = NOVALUE;
    object _8161 = NOVALUE;
    object _8160 = NOVALUE;
    object _8159 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:558		if atom(opt[SHORTNAME]) and atom(opt[LONGNAME]) then*/
    _2 = (object)SEQ_PTR(_opt_14675);
    _8159 = (object)*(((s1_ptr)_2)->base + 1);
    _8160 = IS_ATOM(_8159);
    _8159 = NOVALUE;
    if (_8160 == 0) {
        goto L1; // [14] 35
    }
    _2 = (object)SEQ_PTR(_opt_14675);
    _8162 = (object)*(((s1_ptr)_2)->base + 2);
    _8163 = IS_ATOM(_8162);
    _8162 = NOVALUE;
    if (_8163 == 0)
    {
        _8163 = NOVALUE;
        goto L1; // [26] 35
    }
    else{
        _8163 = NOVALUE;
    }

    /** cmdline.e:560			return*/
    DeRefDS(_opt_14675);
    DeRef(_param_name_14686);
    DeRef(_cmd_14706);
    return;
L1: 

    /** cmdline.e:563		integer has_param = find(HAS_PARAMETER, opt[OPTIONS])*/
    _2 = (object)SEQ_PTR(_opt_14675);
    _8164 = (object)*(((s1_ptr)_2)->base + 4);
    _has_param_14683 = find_from(112, _8164, 1);
    _8164 = NOVALUE;

    /** cmdline.e:564		sequence param_name*/

    /** cmdline.e:565		if has_param != 0 then*/
    if (_has_param_14683 == 0)
    goto L2; // [50] 124

    /** cmdline.e:566			if has_param < length(opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_opt_14675);
    _8167 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_8167)){
            _8168 = SEQ_PTR(_8167)->length;
    }
    else {
        _8168 = 1;
    }
    _8167 = NOVALUE;
    if (_has_param_14683 >= _8168)
    goto L3; // [63] 115

    /** cmdline.e:567				has_param += 1*/
    _has_param_14683 = _has_param_14683 + 1;

    /** cmdline.e:568				if sequence(opt[OPTIONS][has_param]) then*/
    _2 = (object)SEQ_PTR(_opt_14675);
    _8171 = (object)*(((s1_ptr)_2)->base + 4);
    _2 = (object)SEQ_PTR(_8171);
    _8172 = (object)*(((s1_ptr)_2)->base + _has_param_14683);
    _8171 = NOVALUE;
    _8173 = IS_SEQUENCE(_8172);
    _8172 = NOVALUE;
    if (_8173 == 0)
    {
        _8173 = NOVALUE;
        goto L4; // [86] 104
    }
    else{
        _8173 = NOVALUE;
    }

    /** cmdline.e:569					param_name = opt[OPTIONS][has_param]*/
    _2 = (object)SEQ_PTR(_opt_14675);
    _8174 = (object)*(((s1_ptr)_2)->base + 4);
    DeRef(_param_name_14686);
    _2 = (object)SEQ_PTR(_8174);
    _param_name_14686 = (object)*(((s1_ptr)_2)->base + _has_param_14683);
    Ref(_param_name_14686);
    _8174 = NOVALUE;
    goto L5; // [101] 123
L4: 

    /** cmdline.e:571					param_name = "x"*/
    RefDS(_7915);
    DeRef(_param_name_14686);
    _param_name_14686 = _7915;
    goto L5; // [112] 123
L3: 

    /** cmdline.e:574				param_name = "x"*/
    RefDS(_7915);
    DeRef(_param_name_14686);
    _param_name_14686 = _7915;
L5: 
L2: 

    /** cmdline.e:577		integer is_mandatory = (find(MANDATORY, opt[OPTIONS]) != 0)*/
    _2 = (object)SEQ_PTR(_opt_14675);
    _8176 = (object)*(((s1_ptr)_2)->base + 4);
    _8177 = find_from(109, _8176, 1);
    _8176 = NOVALUE;
    _is_mandatory_14702 = (_8177 != 0);
    _8177 = NOVALUE;

    /** cmdline.e:578		sequence cmd = ""*/
    RefDS(_5);
    DeRef(_cmd_14706);
    _cmd_14706 = _5;

    /** cmdline.e:580		if sequence(opt[SHORTNAME]) then*/
    _2 = (object)SEQ_PTR(_opt_14675);
    _8179 = (object)*(((s1_ptr)_2)->base + 1);
    _8180 = IS_SEQUENCE(_8179);
    _8179 = NOVALUE;
    if (_8180 == 0)
    {
        _8180 = NOVALUE;
        goto L6; // [155] 216
    }
    else{
        _8180 = NOVALUE;
    }

    /** cmdline.e:581			if not is_mandatory then*/
    if (_is_mandatory_14702 != 0)
    goto L7; // [160] 170

    /** cmdline.e:582				cmd &= '['*/
    Append(&_cmd_14706, _cmd_14706, 91);
L7: 

    /** cmdline.e:584			cmd &= '-' & opt[SHORTNAME]*/
    _2 = (object)SEQ_PTR(_opt_14675);
    _8183 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(45) && IS_ATOM(_8183)) {
    }
    else if (IS_ATOM(45) && IS_SEQUENCE(_8183)) {
        Prepend(&_8184, _8183, 45);
    }
    else {
        Concat((object_ptr)&_8184, 45, _8183);
    }
    _8183 = NOVALUE;
    Concat((object_ptr)&_cmd_14706, _cmd_14706, _8184);
    DeRefDS(_8184);
    _8184 = NOVALUE;

    /** cmdline.e:585			if has_param != 0 then*/
    if (_has_param_14683 == 0)
    goto L8; // [186] 203

    /** cmdline.e:586				cmd &= ' ' & param_name*/
    Prepend(&_8187, _param_name_14686, 32);
    Concat((object_ptr)&_cmd_14706, _cmd_14706, _8187);
    DeRefDS(_8187);
    _8187 = NOVALUE;
L8: 

    /** cmdline.e:588			if not is_mandatory then*/
    if (_is_mandatory_14702 != 0)
    goto L9; // [205] 215

    /** cmdline.e:589				cmd &= ']'*/
    Append(&_cmd_14706, _cmd_14706, 93);
L9: 
L6: 

    /** cmdline.e:593		if sequence(opt[LONGNAME]) then*/
    _2 = (object)SEQ_PTR(_opt_14675);
    _8191 = (object)*(((s1_ptr)_2)->base + 2);
    _8192 = IS_SEQUENCE(_8191);
    _8191 = NOVALUE;
    if (_8192 == 0)
    {
        _8192 = NOVALUE;
        goto LA; // [225] 300
    }
    else{
        _8192 = NOVALUE;
    }

    /** cmdline.e:594			if length(cmd) > 0 then cmd &= ", " end if*/
    if (IS_SEQUENCE(_cmd_14706)){
            _8193 = SEQ_PTR(_cmd_14706)->length;
    }
    else {
        _8193 = 1;
    }
    if (_8193 <= 0)
    goto LB; // [233] 242
    Concat((object_ptr)&_cmd_14706, _cmd_14706, _974);
LB: 

    /** cmdline.e:595			if not is_mandatory then*/
    if (_is_mandatory_14702 != 0)
    goto LC; // [244] 254

    /** cmdline.e:596				cmd &= '['*/
    Append(&_cmd_14706, _cmd_14706, 91);
LC: 

    /** cmdline.e:598			cmd &= "--" & opt[LONGNAME]*/
    _2 = (object)SEQ_PTR(_opt_14675);
    _8198 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_7162) && IS_ATOM(_8198)) {
        Ref(_8198);
        Append(&_8199, _7162, _8198);
    }
    else if (IS_ATOM(_7162) && IS_SEQUENCE(_8198)) {
    }
    else {
        Concat((object_ptr)&_8199, _7162, _8198);
    }
    _8198 = NOVALUE;
    Concat((object_ptr)&_cmd_14706, _cmd_14706, _8199);
    DeRefDS(_8199);
    _8199 = NOVALUE;

    /** cmdline.e:599			if has_param != 0 then*/
    if (_has_param_14683 == 0)
    goto LD; // [270] 287

    /** cmdline.e:600				cmd &= '=' & param_name*/
    Prepend(&_8202, _param_name_14686, 61);
    Concat((object_ptr)&_cmd_14706, _cmd_14706, _8202);
    DeRefDS(_8202);
    _8202 = NOVALUE;
LD: 

    /** cmdline.e:602			if not is_mandatory then*/
    if (_is_mandatory_14702 != 0)
    goto LE; // [289] 299

    /** cmdline.e:603				cmd &= ']'*/
    Append(&_cmd_14706, _cmd_14706, 93);
LE: 
LA: 

    /** cmdline.e:610		if length(cmd) > pad_size then*/
    if (IS_SEQUENCE(_cmd_14706)){
            _8206 = SEQ_PTR(_cmd_14706)->length;
    }
    else {
        _8206 = 1;
    }
    if (_8206 <= _pad_size_14676)
    goto LF; // [305] 336

    /** cmdline.e:611			puts(1, "   " & cmd & '\n')*/
    {
        object concat_list[3];

        concat_list[0] = 10;
        concat_list[1] = _cmd_14706;
        concat_list[2] = _8208;
        Concat_N((object_ptr)&_8209, concat_list, 3);
    }
    EPuts(1, _8209); // DJP 
    DeRefDS(_8209);
    _8209 = NOVALUE;

    /** cmdline.e:612			puts(1, repeat(' ', pad_size + 3))*/
    _8210 = _pad_size_14676 + 3;
    _8211 = Repeat(32, _8210);
    _8210 = NOVALUE;
    EPuts(1, _8211); // DJP 
    DeRefDS(_8211);
    _8211 = NOVALUE;
    goto L10; // [333] 352
LF: 

    /** cmdline.e:614			puts(1, "   " & stdseq:pad_tail(cmd, pad_size))*/
    RefDS(_cmd_14706);
    _8212 = _23pad_tail(_cmd_14706, _pad_size_14676, 32);
    if (IS_SEQUENCE(_8208) && IS_ATOM(_8212)) {
        Ref(_8212);
        Append(&_8213, _8208, _8212);
    }
    else if (IS_ATOM(_8208) && IS_SEQUENCE(_8212)) {
    }
    else {
        Concat((object_ptr)&_8213, _8208, _8212);
    }
    DeRef(_8212);
    _8212 = NOVALUE;
    EPuts(1, _8213); // DJP 
    DeRefDS(_8213);
    _8213 = NOVALUE;
L10: 

    /** cmdline.e:617		puts(1, opt[DESCRIPTION] & '\n')*/
    _2 = (object)SEQ_PTR(_opt_14675);
    _8214 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_8214) && IS_ATOM(10)) {
        Append(&_8215, _8214, 10);
    }
    else if (IS_ATOM(_8214) && IS_SEQUENCE(10)) {
    }
    else {
        Concat((object_ptr)&_8215, _8214, 10);
        _8214 = NOVALUE;
    }
    _8214 = NOVALUE;
    EPuts(1, _8215); // DJP 
    DeRefDS(_8215);
    _8215 = NOVALUE;

    /** cmdline.e:618	end procedure*/
    DeRefDS(_opt_14675);
    DeRef(_param_name_14686);
    DeRef(_cmd_14706);
    _8167 = NOVALUE;
    return;
    ;
}


object _4find_opt(object _opts_14764, object _opt_style_14765, object _cmd_text_14766)
{
    object _opt_name_14767 = NOVALUE;
    object _opt_param_14768 = NOVALUE;
    object _param_found_14769 = NOVALUE;
    object _reversed_14770 = NOVALUE;
    object _8317 = NOVALUE;
    object _8315 = NOVALUE;
    object _8314 = NOVALUE;
    object _8312 = NOVALUE;
    object _8311 = NOVALUE;
    object _8310 = NOVALUE;
    object _8309 = NOVALUE;
    object _8308 = NOVALUE;
    object _8305 = NOVALUE;
    object _8304 = NOVALUE;
    object _8303 = NOVALUE;
    object _8301 = NOVALUE;
    object _8300 = NOVALUE;
    object _8299 = NOVALUE;
    object _8298 = NOVALUE;
    object _8296 = NOVALUE;
    object _8295 = NOVALUE;
    object _8294 = NOVALUE;
    object _8293 = NOVALUE;
    object _8292 = NOVALUE;
    object _8291 = NOVALUE;
    object _8290 = NOVALUE;
    object _8289 = NOVALUE;
    object _8288 = NOVALUE;
    object _8287 = NOVALUE;
    object _8286 = NOVALUE;
    object _8285 = NOVALUE;
    object _8279 = NOVALUE;
    object _8278 = NOVALUE;
    object _8277 = NOVALUE;
    object _8269 = NOVALUE;
    object _8268 = NOVALUE;
    object _8266 = NOVALUE;
    object _8264 = NOVALUE;
    object _8263 = NOVALUE;
    object _8261 = NOVALUE;
    object _8260 = NOVALUE;
    object _8259 = NOVALUE;
    object _8258 = NOVALUE;
    object _8257 = NOVALUE;
    object _8255 = NOVALUE;
    object _8254 = NOVALUE;
    object _8252 = NOVALUE;
    object _8250 = NOVALUE;
    object _8249 = NOVALUE;
    object _8247 = NOVALUE;
    object _8246 = NOVALUE;
    object _8245 = NOVALUE;
    object _8244 = NOVALUE;
    object _8242 = NOVALUE;
    object _8241 = NOVALUE;
    object _8238 = NOVALUE;
    object _8236 = NOVALUE;
    object _8235 = NOVALUE;
    object _8233 = NOVALUE;
    object _8231 = NOVALUE;
    object _8229 = NOVALUE;
    object _8228 = NOVALUE;
    object _8226 = NOVALUE;
    object _8225 = NOVALUE;
    object _8224 = NOVALUE;
    object _8223 = NOVALUE;
    object _8222 = NOVALUE;
    object _8220 = NOVALUE;
    object _8219 = NOVALUE;
    object _8217 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:793		integer param_found = 0*/
    _param_found_14769 = 0;

    /** cmdline.e:794		integer reversed = 0*/
    _reversed_14770 = 0;

    /** cmdline.e:796		if length(cmd_text) >= 2 then*/
    if (IS_SEQUENCE(_cmd_text_14766)){
            _8217 = SEQ_PTR(_cmd_text_14766)->length;
    }
    else {
        _8217 = 1;
    }
    if (_8217 < 2)
    goto L1; // [20] 85

    /** cmdline.e:798			if cmd_text[1] = '\'' or cmd_text[1] = '"' then*/
    _2 = (object)SEQ_PTR(_cmd_text_14766);
    _8219 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8219)) {
        _8220 = (_8219 == 39);
    }
    else {
        _8220 = binary_op(EQUALS, _8219, 39);
    }
    _8219 = NOVALUE;
    if (IS_ATOM_INT(_8220)) {
        if (_8220 != 0) {
            goto L2; // [34] 51
        }
    }
    else {
        if (DBL_PTR(_8220)->dbl != 0.0) {
            goto L2; // [34] 51
        }
    }
    _2 = (object)SEQ_PTR(_cmd_text_14766);
    _8222 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8222)) {
        _8223 = (_8222 == 34);
    }
    else {
        _8223 = binary_op(EQUALS, _8222, 34);
    }
    _8222 = NOVALUE;
    if (_8223 == 0) {
        DeRef(_8223);
        _8223 = NOVALUE;
        goto L3; // [47] 84
    }
    else {
        if (!IS_ATOM_INT(_8223) && DBL_PTR(_8223)->dbl == 0.0){
            DeRef(_8223);
            _8223 = NOVALUE;
            goto L3; // [47] 84
        }
        DeRef(_8223);
        _8223 = NOVALUE;
    }
    DeRef(_8223);
    _8223 = NOVALUE;
L2: 

    /** cmdline.e:799				if cmd_text[$] = cmd_text[1] then*/
    if (IS_SEQUENCE(_cmd_text_14766)){
            _8224 = SEQ_PTR(_cmd_text_14766)->length;
    }
    else {
        _8224 = 1;
    }
    _2 = (object)SEQ_PTR(_cmd_text_14766);
    _8225 = (object)*(((s1_ptr)_2)->base + _8224);
    _2 = (object)SEQ_PTR(_cmd_text_14766);
    _8226 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _8225, _8226)){
        _8225 = NOVALUE;
        _8226 = NOVALUE;
        goto L4; // [64] 83
    }
    _8225 = NOVALUE;
    _8226 = NOVALUE;

    /** cmdline.e:800					cmd_text = cmd_text[2 .. $-1]*/
    if (IS_SEQUENCE(_cmd_text_14766)){
            _8228 = SEQ_PTR(_cmd_text_14766)->length;
    }
    else {
        _8228 = 1;
    }
    _8229 = _8228 - 1;
    _8228 = NOVALUE;
    rhs_slice_target = (object_ptr)&_cmd_text_14766;
    RHS_Slice(_cmd_text_14766, 2, _8229);
L4: 
L3: 
L1: 

    /** cmdline.e:805		if length(cmd_text) > 0 then*/
    if (IS_SEQUENCE(_cmd_text_14766)){
            _8231 = SEQ_PTR(_cmd_text_14766)->length;
    }
    else {
        _8231 = 1;
    }
    if (_8231 <= 0)
    goto L5; // [90] 125

    /** cmdline.e:806			if find(cmd_text[1], "!-") then*/
    _2 = (object)SEQ_PTR(_cmd_text_14766);
    _8233 = (object)*(((s1_ptr)_2)->base + 1);
    _8235 = find_from(_8233, _8234, 1);
    _8233 = NOVALUE;
    if (_8235 == 0)
    {
        _8235 = NOVALUE;
        goto L6; // [105] 124
    }
    else{
        _8235 = NOVALUE;
    }

    /** cmdline.e:807				reversed = 1*/
    _reversed_14770 = 1;

    /** cmdline.e:808				cmd_text = cmd_text[2 .. $]*/
    if (IS_SEQUENCE(_cmd_text_14766)){
            _8236 = SEQ_PTR(_cmd_text_14766)->length;
    }
    else {
        _8236 = 1;
    }
    rhs_slice_target = (object_ptr)&_cmd_text_14766;
    RHS_Slice(_cmd_text_14766, 2, _8236);
L6: 
L5: 

    /** cmdline.e:812		if length(cmd_text) < 1 then*/
    if (IS_SEQUENCE(_cmd_text_14766)){
            _8238 = SEQ_PTR(_cmd_text_14766)->length;
    }
    else {
        _8238 = 1;
    }
    if (_8238 >= 1)
    goto L7; // [130] 145

    /** cmdline.e:813			return {-1, "Empty command text"}*/
    RefDS(_8240);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = _8240;
    _8241 = MAKE_SEQ(_1);
    DeRefDS(_opts_14764);
    DeRefDS(_opt_style_14765);
    DeRef(_cmd_text_14766);
    DeRef(_opt_name_14767);
    DeRef(_opt_param_14768);
    DeRef(_8229);
    _8229 = NOVALUE;
    DeRef(_8220);
    _8220 = NOVALUE;
    return _8241;
L7: 

    /** cmdline.e:816		opt_name = repeat(' ', length(cmd_text))*/
    if (IS_SEQUENCE(_cmd_text_14766)){
            _8242 = SEQ_PTR(_cmd_text_14766)->length;
    }
    else {
        _8242 = 1;
    }
    DeRef(_opt_name_14767);
    _opt_name_14767 = Repeat(32, _8242);
    _8242 = NOVALUE;

    /** cmdline.e:817		opt_param = 0*/
    DeRef(_opt_param_14768);
    _opt_param_14768 = 0;

    /** cmdline.e:818		for i = 1 to length(cmd_text) do*/
    if (IS_SEQUENCE(_cmd_text_14766)){
            _8244 = SEQ_PTR(_cmd_text_14766)->length;
    }
    else {
        _8244 = 1;
    }
    {
        object _i_14805;
        _i_14805 = 1;
L8: 
        if (_i_14805 > _8244){
            goto L9; // [164] 320
        }

        /** cmdline.e:819			if find(cmd_text[i], ":=") then*/
        _2 = (object)SEQ_PTR(_cmd_text_14766);
        _8245 = (object)*(((s1_ptr)_2)->base + _i_14805);
        _8246 = find_from(_8245, _4676, 1);
        _8245 = NOVALUE;
        if (_8246 == 0)
        {
            _8246 = NOVALUE;
            goto LA; // [182] 302
        }
        else{
            _8246 = NOVALUE;
        }

        /** cmdline.e:820				opt_name = opt_name[1 .. i - 1]*/
        _8247 = _i_14805 - 1;
        rhs_slice_target = (object_ptr)&_opt_name_14767;
        RHS_Slice(_opt_name_14767, 1, _8247);

        /** cmdline.e:821				opt_param = cmd_text[i + 1 .. $]*/
        _8249 = _i_14805 + 1;
        if (IS_SEQUENCE(_cmd_text_14766)){
                _8250 = SEQ_PTR(_cmd_text_14766)->length;
        }
        else {
            _8250 = 1;
        }
        rhs_slice_target = (object_ptr)&_opt_param_14768;
        RHS_Slice(_cmd_text_14766, _8249, _8250);

        /** cmdline.e:822				if length(opt_param) >= 2 then*/
        if (IS_SEQUENCE(_opt_param_14768)){
                _8252 = SEQ_PTR(_opt_param_14768)->length;
        }
        else {
            _8252 = 1;
        }
        if (_8252 < 2)
        goto LB; // [215] 280

        /** cmdline.e:824					if opt_param[1] = '\'' or opt_param[1] = '"' then*/
        _2 = (object)SEQ_PTR(_opt_param_14768);
        _8254 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_8254)) {
            _8255 = (_8254 == 39);
        }
        else {
            _8255 = binary_op(EQUALS, _8254, 39);
        }
        _8254 = NOVALUE;
        if (IS_ATOM_INT(_8255)) {
            if (_8255 != 0) {
                goto LC; // [229] 246
            }
        }
        else {
            if (DBL_PTR(_8255)->dbl != 0.0) {
                goto LC; // [229] 246
            }
        }
        _2 = (object)SEQ_PTR(_opt_param_14768);
        _8257 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_8257)) {
            _8258 = (_8257 == 34);
        }
        else {
            _8258 = binary_op(EQUALS, _8257, 34);
        }
        _8257 = NOVALUE;
        if (_8258 == 0) {
            DeRef(_8258);
            _8258 = NOVALUE;
            goto LD; // [242] 279
        }
        else {
            if (!IS_ATOM_INT(_8258) && DBL_PTR(_8258)->dbl == 0.0){
                DeRef(_8258);
                _8258 = NOVALUE;
                goto LD; // [242] 279
            }
            DeRef(_8258);
            _8258 = NOVALUE;
        }
        DeRef(_8258);
        _8258 = NOVALUE;
LC: 

        /** cmdline.e:825						if opt_param[$] = opt_param[1] then*/
        if (IS_SEQUENCE(_opt_param_14768)){
                _8259 = SEQ_PTR(_opt_param_14768)->length;
        }
        else {
            _8259 = 1;
        }
        _2 = (object)SEQ_PTR(_opt_param_14768);
        _8260 = (object)*(((s1_ptr)_2)->base + _8259);
        _2 = (object)SEQ_PTR(_opt_param_14768);
        _8261 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _8260, _8261)){
            _8260 = NOVALUE;
            _8261 = NOVALUE;
            goto LE; // [259] 278
        }
        _8260 = NOVALUE;
        _8261 = NOVALUE;

        /** cmdline.e:826							opt_param = opt_param[2 .. $-1]*/
        if (IS_SEQUENCE(_opt_param_14768)){
                _8263 = SEQ_PTR(_opt_param_14768)->length;
        }
        else {
            _8263 = 1;
        }
        _8264 = _8263 - 1;
        _8263 = NOVALUE;
        rhs_slice_target = (object_ptr)&_opt_param_14768;
        RHS_Slice(_opt_param_14768, 2, _8264);
LE: 
LD: 
LB: 

        /** cmdline.e:831				if length(opt_param) > 0 then*/
        if (IS_SEQUENCE(_opt_param_14768)){
                _8266 = SEQ_PTR(_opt_param_14768)->length;
        }
        else {
            _8266 = 1;
        }
        if (_8266 <= 0)
        goto L9; // [285] 320

        /** cmdline.e:832					param_found = 1*/
        _param_found_14769 = 1;

        /** cmdline.e:835				exit*/
        goto L9; // [297] 320
        goto LF; // [299] 313
LA: 

        /** cmdline.e:837				opt_name[i] = cmd_text[i]*/
        _2 = (object)SEQ_PTR(_cmd_text_14766);
        _8268 = (object)*(((s1_ptr)_2)->base + _i_14805);
        Ref(_8268);
        _2 = (object)SEQ_PTR(_opt_name_14767);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_name_14767 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_14805);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8268;
        if( _1 != _8268 ){
            DeRef(_1);
        }
        _8268 = NOVALUE;
LF: 

        /** cmdline.e:839		end for*/
        _i_14805 = _i_14805 + 1;
        goto L8; // [315] 171
L9: 
        ;
    }

    /** cmdline.e:841		if param_found then*/
    if (_param_found_14769 == 0)
    {
        goto L10; // [322] 388
    }
    else{
    }

    /** cmdline.e:842			if find( text:lower(opt_param), {"1", "on", "yes", "y", "true", "ok", "+"}) then*/
    Ref(_opt_param_14768);
    _8269 = _14lower(_opt_param_14768);
    _1 = NewS1(7);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_8270);
    ((intptr_t*)_2)[1] = _8270;
    RefDS(_8271);
    ((intptr_t*)_2)[2] = _8271;
    RefDS(_8272);
    ((intptr_t*)_2)[3] = _8272;
    RefDS(_8273);
    ((intptr_t*)_2)[4] = _8273;
    RefDS(_8274);
    ((intptr_t*)_2)[5] = _8274;
    RefDS(_8275);
    ((intptr_t*)_2)[6] = _8275;
    RefDS(_8276);
    ((intptr_t*)_2)[7] = _8276;
    _8277 = MAKE_SEQ(_1);
    _8278 = find_from(_8269, _8277, 1);
    DeRef(_8269);
    _8269 = NOVALUE;
    DeRefDS(_8277);
    _8277 = NOVALUE;
    if (_8278 == 0)
    {
        _8278 = NOVALUE;
        goto L11; // [346] 357
    }
    else{
        _8278 = NOVALUE;
    }

    /** cmdline.e:843				opt_param = 1*/
    DeRef(_opt_param_14768);
    _opt_param_14768 = 1;
    goto L12; // [354] 387
L11: 

    /** cmdline.e:844			elsif find( text:lower(opt_param), {"0", "off", "no", "n", "false", "-"}) then*/
    Ref(_opt_param_14768);
    _8279 = _14lower(_opt_param_14768);
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_8280);
    ((intptr_t*)_2)[1] = _8280;
    RefDS(_8281);
    ((intptr_t*)_2)[2] = _8281;
    RefDS(_8282);
    ((intptr_t*)_2)[3] = _8282;
    RefDS(_8283);
    ((intptr_t*)_2)[4] = _8283;
    RefDS(_8284);
    ((intptr_t*)_2)[5] = _8284;
    RefDS(_7133);
    ((intptr_t*)_2)[6] = _7133;
    _8285 = MAKE_SEQ(_1);
    _8286 = find_from(_8279, _8285, 1);
    DeRef(_8279);
    _8279 = NOVALUE;
    DeRefDS(_8285);
    _8285 = NOVALUE;
    if (_8286 == 0)
    {
        _8286 = NOVALUE;
        goto L13; // [377] 386
    }
    else{
        _8286 = NOVALUE;
    }

    /** cmdline.e:845				opt_param = 0*/
    DeRef(_opt_param_14768);
    _opt_param_14768 = 0;
L13: 
L12: 
L10: 

    /** cmdline.e:849		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14764)){
            _8287 = SEQ_PTR(_opts_14764)->length;
    }
    else {
        _8287 = 1;
    }
    {
        object _i_14859;
        _i_14859 = 1;
L14: 
        if (_i_14859 > _8287){
            goto L15; // [393] 592
        }

        /** cmdline.e:850			if find(NO_CASE,  opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_14764);
        _8288 = (object)*(((s1_ptr)_2)->base + _i_14859);
        _2 = (object)SEQ_PTR(_8288);
        _8289 = (object)*(((s1_ptr)_2)->base + 4);
        _8288 = NOVALUE;
        _8290 = find_from(105, _8289, 1);
        _8289 = NOVALUE;
        if (_8290 == 0)
        {
            _8290 = NOVALUE;
            goto L16; // [415] 455
        }
        else{
            _8290 = NOVALUE;
        }

        /** cmdline.e:851				if not equal( text:lower(opt_name), text:lower(opts[i][opt_style[1]])) then*/
        RefDS(_opt_name_14767);
        _8291 = _14lower(_opt_name_14767);
        _2 = (object)SEQ_PTR(_opts_14764);
        _8292 = (object)*(((s1_ptr)_2)->base + _i_14859);
        _2 = (object)SEQ_PTR(_opt_style_14765);
        _8293 = (object)*(((s1_ptr)_2)->base + 1);
        _2 = (object)SEQ_PTR(_8292);
        if (!IS_ATOM_INT(_8293)){
            _8294 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_8293)->dbl));
        }
        else{
            _8294 = (object)*(((s1_ptr)_2)->base + _8293);
        }
        _8292 = NOVALUE;
        Ref(_8294);
        _8295 = _14lower(_8294);
        _8294 = NOVALUE;
        if (_8291 == _8295)
        _8296 = 1;
        else if (IS_ATOM_INT(_8291) && IS_ATOM_INT(_8295))
        _8296 = 0;
        else
        _8296 = (compare(_8291, _8295) == 0);
        DeRef(_8291);
        _8291 = NOVALUE;
        DeRef(_8295);
        _8295 = NOVALUE;
        if (_8296 != 0)
        goto L17; // [444] 482
        _8296 = NOVALUE;

        /** cmdline.e:852					continue*/
        goto L18; // [449] 587
        goto L17; // [452] 482
L16: 

        /** cmdline.e:855				if not equal(opt_name, opts[i][opt_style[1]]) then*/
        _2 = (object)SEQ_PTR(_opts_14764);
        _8298 = (object)*(((s1_ptr)_2)->base + _i_14859);
        _2 = (object)SEQ_PTR(_opt_style_14765);
        _8299 = (object)*(((s1_ptr)_2)->base + 1);
        _2 = (object)SEQ_PTR(_8298);
        if (!IS_ATOM_INT(_8299)){
            _8300 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_8299)->dbl));
        }
        else{
            _8300 = (object)*(((s1_ptr)_2)->base + _8299);
        }
        _8298 = NOVALUE;
        if (_opt_name_14767 == _8300)
        _8301 = 1;
        else if (IS_ATOM_INT(_opt_name_14767) && IS_ATOM_INT(_8300))
        _8301 = 0;
        else
        _8301 = (compare(_opt_name_14767, _8300) == 0);
        _8300 = NOVALUE;
        if (_8301 != 0)
        goto L19; // [473] 481
        _8301 = NOVALUE;

        /** cmdline.e:856					continue*/
        goto L18; // [478] 587
L19: 
L17: 

        /** cmdline.e:860			if find(HAS_PARAMETER,  opts[i][OPTIONS]) = 0 then*/
        _2 = (object)SEQ_PTR(_opts_14764);
        _8303 = (object)*(((s1_ptr)_2)->base + _i_14859);
        _2 = (object)SEQ_PTR(_8303);
        _8304 = (object)*(((s1_ptr)_2)->base + 4);
        _8303 = NOVALUE;
        _8305 = find_from(112, _8304, 1);
        _8304 = NOVALUE;
        if (_8305 != 0)
        goto L1A; // [497] 518

        /** cmdline.e:861				if param_found then*/
        if (_param_found_14769 == 0)
        {
            goto L1B; // [503] 517
        }
        else{
        }

        /** cmdline.e:862					return {0, "Option should not have a parameter"}*/
        RefDS(_8307);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 0;
        ((intptr_t *)_2)[2] = _8307;
        _8308 = MAKE_SEQ(_1);
        DeRefDS(_opts_14764);
        DeRefDS(_opt_style_14765);
        DeRef(_cmd_text_14766);
        DeRef(_opt_name_14767);
        DeRef(_opt_param_14768);
        DeRef(_8229);
        _8229 = NOVALUE;
        _8293 = NOVALUE;
        DeRef(_8241);
        _8241 = NOVALUE;
        _8299 = NOVALUE;
        DeRef(_8220);
        _8220 = NOVALUE;
        DeRef(_8264);
        _8264 = NOVALUE;
        DeRef(_8249);
        _8249 = NOVALUE;
        DeRef(_8247);
        _8247 = NOVALUE;
        DeRef(_8255);
        _8255 = NOVALUE;
        return _8308;
L1B: 
L1A: 

        /** cmdline.e:866			if param_found then*/
        if (_param_found_14769 == 0)
        {
            goto L1C; // [520] 539
        }
        else{
        }

        /** cmdline.e:867				return {i, opt_name, reversed, opt_param}*/
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _i_14859;
        RefDS(_opt_name_14767);
        ((intptr_t*)_2)[2] = _opt_name_14767;
        ((intptr_t*)_2)[3] = _reversed_14770;
        Ref(_opt_param_14768);
        ((intptr_t*)_2)[4] = _opt_param_14768;
        _8309 = MAKE_SEQ(_1);
        DeRefDS(_opts_14764);
        DeRefDS(_opt_style_14765);
        DeRef(_cmd_text_14766);
        DeRefDS(_opt_name_14767);
        DeRef(_opt_param_14768);
        DeRef(_8229);
        _8229 = NOVALUE;
        _8293 = NOVALUE;
        DeRef(_8308);
        _8308 = NOVALUE;
        DeRef(_8241);
        _8241 = NOVALUE;
        _8299 = NOVALUE;
        DeRef(_8220);
        _8220 = NOVALUE;
        DeRef(_8264);
        _8264 = NOVALUE;
        DeRef(_8249);
        _8249 = NOVALUE;
        DeRef(_8247);
        _8247 = NOVALUE;
        DeRef(_8255);
        _8255 = NOVALUE;
        return _8309;
        goto L1D; // [536] 585
L1C: 

        /** cmdline.e:869				if find(HAS_PARAMETER, opts[i][OPTIONS]) = 0 then*/
        _2 = (object)SEQ_PTR(_opts_14764);
        _8310 = (object)*(((s1_ptr)_2)->base + _i_14859);
        _2 = (object)SEQ_PTR(_8310);
        _8311 = (object)*(((s1_ptr)_2)->base + 4);
        _8310 = NOVALUE;
        _8312 = find_from(112, _8311, 1);
        _8311 = NOVALUE;
        if (_8312 != 0)
        goto L1E; // [554] 572

        /** cmdline.e:870					return {i, opt_name, reversed, 1 }*/
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _i_14859;
        RefDS(_opt_name_14767);
        ((intptr_t*)_2)[2] = _opt_name_14767;
        ((intptr_t*)_2)[3] = _reversed_14770;
        ((intptr_t*)_2)[4] = 1;
        _8314 = MAKE_SEQ(_1);
        DeRefDS(_opts_14764);
        DeRefDS(_opt_style_14765);
        DeRef(_cmd_text_14766);
        DeRefDS(_opt_name_14767);
        DeRef(_opt_param_14768);
        DeRef(_8229);
        _8229 = NOVALUE;
        _8293 = NOVALUE;
        DeRef(_8308);
        _8308 = NOVALUE;
        DeRef(_8241);
        _8241 = NOVALUE;
        _8299 = NOVALUE;
        DeRef(_8220);
        _8220 = NOVALUE;
        DeRef(_8264);
        _8264 = NOVALUE;
        DeRef(_8249);
        _8249 = NOVALUE;
        DeRef(_8247);
        _8247 = NOVALUE;
        DeRef(_8309);
        _8309 = NOVALUE;
        DeRef(_8255);
        _8255 = NOVALUE;
        return _8314;
L1E: 

        /** cmdline.e:873				return {i, opt_name, reversed}*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _i_14859;
        RefDS(_opt_name_14767);
        ((intptr_t*)_2)[2] = _opt_name_14767;
        ((intptr_t*)_2)[3] = _reversed_14770;
        _8315 = MAKE_SEQ(_1);
        DeRefDS(_opts_14764);
        DeRefDS(_opt_style_14765);
        DeRef(_cmd_text_14766);
        DeRefDS(_opt_name_14767);
        DeRef(_opt_param_14768);
        DeRef(_8229);
        _8229 = NOVALUE;
        _8293 = NOVALUE;
        DeRef(_8308);
        _8308 = NOVALUE;
        DeRef(_8241);
        _8241 = NOVALUE;
        _8299 = NOVALUE;
        DeRef(_8220);
        _8220 = NOVALUE;
        DeRef(_8264);
        _8264 = NOVALUE;
        DeRef(_8249);
        _8249 = NOVALUE;
        DeRef(_8247);
        _8247 = NOVALUE;
        DeRef(_8309);
        _8309 = NOVALUE;
        DeRef(_8314);
        _8314 = NOVALUE;
        DeRef(_8255);
        _8255 = NOVALUE;
        return _8315;
L1D: 

        /** cmdline.e:875		end for*/
L18: 
        _i_14859 = _i_14859 + 1;
        goto L14; // [587] 400
L15: 
        ;
    }

    /** cmdline.e:877		return {0, "Unrecognised"}*/
    RefDS(_8316);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _8316;
    _8317 = MAKE_SEQ(_1);
    DeRefDS(_opts_14764);
    DeRefDS(_opt_style_14765);
    DeRef(_cmd_text_14766);
    DeRef(_opt_name_14767);
    DeRef(_opt_param_14768);
    DeRef(_8229);
    _8229 = NOVALUE;
    _8293 = NOVALUE;
    DeRef(_8308);
    _8308 = NOVALUE;
    DeRef(_8241);
    _8241 = NOVALUE;
    _8299 = NOVALUE;
    DeRef(_8220);
    _8220 = NOVALUE;
    DeRef(_8264);
    _8264 = NOVALUE;
    DeRef(_8249);
    _8249 = NOVALUE;
    DeRef(_8247);
    _8247 = NOVALUE;
    DeRef(_8309);
    _8309 = NOVALUE;
    DeRef(_8315);
    _8315 = NOVALUE;
    DeRef(_8314);
    _8314 = NOVALUE;
    DeRef(_8255);
    _8255 = NOVALUE;
    return _8317;
    ;
}


object _4get_help_options(object _opts_14902)
{
    object _help_opts_14903 = NOVALUE;
    object _8340 = NOVALUE;
    object _8339 = NOVALUE;
    object _8338 = NOVALUE;
    object _8336 = NOVALUE;
    object _8335 = NOVALUE;
    object _8334 = NOVALUE;
    object _8332 = NOVALUE;
    object _8331 = NOVALUE;
    object _8330 = NOVALUE;
    object _8329 = NOVALUE;
    object _8328 = NOVALUE;
    object _8326 = NOVALUE;
    object _8325 = NOVALUE;
    object _8324 = NOVALUE;
    object _8323 = NOVALUE;
    object _8322 = NOVALUE;
    object _8321 = NOVALUE;
    object _8320 = NOVALUE;
    object _8319 = NOVALUE;
    object _8318 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:881		sequence help_opts = {}*/
    RefDS(_5);
    DeRef(_help_opts_14903);
    _help_opts_14903 = _5;

    /** cmdline.e:883		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14902)){
            _8318 = SEQ_PTR(_opts_14902)->length;
    }
    else {
        _8318 = 1;
    }
    {
        object _i_14905;
        _i_14905 = 1;
L1: 
        if (_i_14905 > _8318){
            goto L2; // [15] 170
        }

        /** cmdline.e:884			if find(HELP, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_14902);
        _8319 = (object)*(((s1_ptr)_2)->base + _i_14905);
        _2 = (object)SEQ_PTR(_8319);
        _8320 = (object)*(((s1_ptr)_2)->base + 4);
        _8319 = NOVALUE;
        _8321 = find_from(104, _8320, 1);
        _8320 = NOVALUE;
        if (_8321 == 0)
        {
            _8321 = NOVALUE;
            goto L3; // [37] 163
        }
        else{
            _8321 = NOVALUE;
        }

        /** cmdline.e:885				if sequence(opts[i][SHORTNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_14902);
        _8322 = (object)*(((s1_ptr)_2)->base + _i_14905);
        _2 = (object)SEQ_PTR(_8322);
        _8323 = (object)*(((s1_ptr)_2)->base + 1);
        _8322 = NOVALUE;
        _8324 = IS_SEQUENCE(_8323);
        _8323 = NOVALUE;
        if (_8324 == 0)
        {
            _8324 = NOVALUE;
            goto L4; // [53] 71
        }
        else{
            _8324 = NOVALUE;
        }

        /** cmdline.e:886					help_opts = append(help_opts, opts[i][SHORTNAME])*/
        _2 = (object)SEQ_PTR(_opts_14902);
        _8325 = (object)*(((s1_ptr)_2)->base + _i_14905);
        _2 = (object)SEQ_PTR(_8325);
        _8326 = (object)*(((s1_ptr)_2)->base + 1);
        _8325 = NOVALUE;
        Ref(_8326);
        Append(&_help_opts_14903, _help_opts_14903, _8326);
        _8326 = NOVALUE;
L4: 

        /** cmdline.e:889				if sequence(opts[i][LONGNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_14902);
        _8328 = (object)*(((s1_ptr)_2)->base + _i_14905);
        _2 = (object)SEQ_PTR(_8328);
        _8329 = (object)*(((s1_ptr)_2)->base + 2);
        _8328 = NOVALUE;
        _8330 = IS_SEQUENCE(_8329);
        _8329 = NOVALUE;
        if (_8330 == 0)
        {
            _8330 = NOVALUE;
            goto L5; // [84] 102
        }
        else{
            _8330 = NOVALUE;
        }

        /** cmdline.e:890					help_opts = append(help_opts, opts[i][LONGNAME])*/
        _2 = (object)SEQ_PTR(_opts_14902);
        _8331 = (object)*(((s1_ptr)_2)->base + _i_14905);
        _2 = (object)SEQ_PTR(_8331);
        _8332 = (object)*(((s1_ptr)_2)->base + 2);
        _8331 = NOVALUE;
        Ref(_8332);
        Append(&_help_opts_14903, _help_opts_14903, _8332);
        _8332 = NOVALUE;
L5: 

        /** cmdline.e:893				if find(NO_CASE, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_14902);
        _8334 = (object)*(((s1_ptr)_2)->base + _i_14905);
        _2 = (object)SEQ_PTR(_8334);
        _8335 = (object)*(((s1_ptr)_2)->base + 4);
        _8334 = NOVALUE;
        _8336 = find_from(105, _8335, 1);
        _8335 = NOVALUE;
        if (_8336 == 0)
        {
            _8336 = NOVALUE;
            goto L6; // [117] 162
        }
        else{
            _8336 = NOVALUE;
        }

        /** cmdline.e:894					help_opts = text:lower(help_opts)*/
        RefDS(_help_opts_14903);
        _0 = _help_opts_14903;
        _help_opts_14903 = _14lower(_help_opts_14903);
        DeRefDS(_0);

        /** cmdline.e:895					for j = 1 to length(help_opts) do*/
        if (IS_SEQUENCE(_help_opts_14903)){
                _8338 = SEQ_PTR(_help_opts_14903)->length;
        }
        else {
            _8338 = 1;
        }
        {
            object _j_14931;
            _j_14931 = 1;
L7: 
            if (_j_14931 > _8338){
                goto L8; // [133] 161
            }

            /** cmdline.e:896						help_opts = append( help_opts, text:upper(help_opts[j]) )*/
            _2 = (object)SEQ_PTR(_help_opts_14903);
            _8339 = (object)*(((s1_ptr)_2)->base + _j_14931);
            Ref(_8339);
            _8340 = _14upper(_8339);
            _8339 = NOVALUE;
            Ref(_8340);
            Append(&_help_opts_14903, _help_opts_14903, _8340);
            DeRef(_8340);
            _8340 = NOVALUE;

            /** cmdline.e:897					end for*/
            _j_14931 = _j_14931 + 1;
            goto L7; // [156] 140
L8: 
            ;
        }
L6: 
L3: 

        /** cmdline.e:900		end for*/
        _i_14905 = _i_14905 + 1;
        goto L1; // [165] 22
L2: 
        ;
    }

    /** cmdline.e:901		return help_opts*/
    DeRefDS(_opts_14902);
    return _help_opts_14903;
    ;
}


object _4parse_at_cmds(object _cmd_14938, object _cmds_14939, object _opts_14940, object _arg_idx_14941, object _add_help_rid_14942, object _parse_options_14943, object _help_on_error_14944, object _auto_help_14945)
{
    object _at_cmds_14946 = NOVALUE;
    object _j_14947 = NOVALUE;
    object _cmdex_15031 = NOVALUE;
    object _8421 = NOVALUE;
    object _8420 = NOVALUE;
    object _8417 = NOVALUE;
    object _8416 = NOVALUE;
    object _8415 = NOVALUE;
    object _8414 = NOVALUE;
    object _8413 = NOVALUE;
    object _8412 = NOVALUE;
    object _8411 = NOVALUE;
    object _8410 = NOVALUE;
    object _8409 = NOVALUE;
    object _8408 = NOVALUE;
    object _8407 = NOVALUE;
    object _8406 = NOVALUE;
    object _8405 = NOVALUE;
    object _8404 = NOVALUE;
    object _8403 = NOVALUE;
    object _8402 = NOVALUE;
    object _8401 = NOVALUE;
    object _8400 = NOVALUE;
    object _8399 = NOVALUE;
    object _8398 = NOVALUE;
    object _8397 = NOVALUE;
    object _8396 = NOVALUE;
    object _8395 = NOVALUE;
    object _8394 = NOVALUE;
    object _8393 = NOVALUE;
    object _8392 = NOVALUE;
    object _8391 = NOVALUE;
    object _8390 = NOVALUE;
    object _8389 = NOVALUE;
    object _8388 = NOVALUE;
    object _8387 = NOVALUE;
    object _8386 = NOVALUE;
    object _8383 = NOVALUE;
    object _8382 = NOVALUE;
    object _8381 = NOVALUE;
    object _8380 = NOVALUE;
    object _8379 = NOVALUE;
    object _8377 = NOVALUE;
    object _8376 = NOVALUE;
    object _8373 = NOVALUE;
    object _8372 = NOVALUE;
    object _8371 = NOVALUE;
    object _8370 = NOVALUE;
    object _8369 = NOVALUE;
    object _8367 = NOVALUE;
    object _8366 = NOVALUE;
    object _8365 = NOVALUE;
    object _8364 = NOVALUE;
    object _8361 = NOVALUE;
    object _8359 = NOVALUE;
    object _8358 = NOVALUE;
    object _8357 = NOVALUE;
    object _8355 = NOVALUE;
    object _8353 = NOVALUE;
    object _8352 = NOVALUE;
    object _8350 = NOVALUE;
    object _8348 = NOVALUE;
    object _8347 = NOVALUE;
    object _8346 = NOVALUE;
    object _8345 = NOVALUE;
    object _8344 = NOVALUE;
    object _8343 = NOVALUE;
    object _8342 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:912		if length(cmd) > 2 and cmd[2] = '@' then*/
    if (IS_SEQUENCE(_cmd_14938)){
            _8342 = SEQ_PTR(_cmd_14938)->length;
    }
    else {
        _8342 = 1;
    }
    _8343 = (_8342 > 2);
    _8342 = NOVALUE;
    if (_8343 == 0) {
        goto L1; // [22] 78
    }
    _2 = (object)SEQ_PTR(_cmd_14938);
    _8345 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_8345)) {
        _8346 = (_8345 == 64);
    }
    else {
        _8346 = binary_op(EQUALS, _8345, 64);
    }
    _8345 = NOVALUE;
    if (_8346 == 0) {
        DeRef(_8346);
        _8346 = NOVALUE;
        goto L1; // [35] 78
    }
    else {
        if (!IS_ATOM_INT(_8346) && DBL_PTR(_8346)->dbl == 0.0){
            DeRef(_8346);
            _8346 = NOVALUE;
            goto L1; // [35] 78
        }
        DeRef(_8346);
        _8346 = NOVALUE;
    }
    DeRef(_8346);
    _8346 = NOVALUE;

    /** cmdline.e:914			at_cmds = io:read_lines(cmd[3..$])*/
    if (IS_SEQUENCE(_cmd_14938)){
            _8347 = SEQ_PTR(_cmd_14938)->length;
    }
    else {
        _8347 = 1;
    }
    rhs_slice_target = (object_ptr)&_8348;
    RHS_Slice(_cmd_14938, 3, _8347);
    _0 = _at_cmds_14946;
    _at_cmds_14946 = _8read_lines(_8348);
    DeRef(_0);
    _8348 = NOVALUE;

    /** cmdline.e:915			if equal(at_cmds, -1) then*/
    if (_at_cmds_14946 == -1)
    _8350 = 1;
    else if (IS_ATOM_INT(_at_cmds_14946) && IS_ATOM_INT(-1))
    _8350 = 0;
    else
    _8350 = (compare(_at_cmds_14946, -1) == 0);
    if (_8350 == 0)
    {
        _8350 = NOVALUE;
        goto L2; // [58] 156
    }
    else{
        _8350 = NOVALUE;
    }

    /** cmdline.e:918				cmds = eu:remove(cmds, arg_idx)*/
    {
        s1_ptr assign_space = SEQ_PTR(_cmds_14939);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_arg_idx_14941)) ? _arg_idx_14941 : (object)(DBL_PTR(_arg_idx_14941)->dbl);
        int stop = (IS_ATOM_INT(_arg_idx_14941)) ? _arg_idx_14941 : (object)(DBL_PTR(_arg_idx_14941)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_cmds_14939), start, &_cmds_14939 );
            }
            else Tail(SEQ_PTR(_cmds_14939), stop+1, &_cmds_14939);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_cmds_14939), start, &_cmds_14939);
        }
        else {
            assign_slice_seq = &assign_space;
            _cmds_14939 = Remove_elements(start, stop, (SEQ_PTR(_cmds_14939)->ref == 1));
        }
    }

    /** cmdline.e:919				return cmds*/
    DeRefDS(_cmd_14938);
    DeRefDS(_opts_14940);
    DeRefi(_parse_options_14943);
    DeRef(_at_cmds_14946);
    DeRef(_8343);
    _8343 = NOVALUE;
    return _cmds_14939;
    goto L2; // [75] 156
L1: 

    /** cmdline.e:923			at_cmds = io:read_lines(cmd[2..$])*/
    if (IS_SEQUENCE(_cmd_14938)){
            _8352 = SEQ_PTR(_cmd_14938)->length;
    }
    else {
        _8352 = 1;
    }
    rhs_slice_target = (object_ptr)&_8353;
    RHS_Slice(_cmd_14938, 2, _8352);
    _0 = _at_cmds_14946;
    _at_cmds_14946 = _8read_lines(_8353);
    DeRef(_0);
    _8353 = NOVALUE;

    /** cmdline.e:924			if equal(at_cmds, -1) then*/
    if (_at_cmds_14946 == -1)
    _8355 = 1;
    else if (IS_ATOM_INT(_at_cmds_14946) && IS_ATOM_INT(-1))
    _8355 = 0;
    else
    _8355 = (compare(_at_cmds_14946, -1) == 0);
    if (_8355 == 0)
    {
        _8355 = NOVALUE;
        goto L3; // [98] 155
    }
    else{
        _8355 = NOVALUE;
    }

    /** cmdline.e:925				printf(2, "Cannot access '@' argument file '%s'\n", {cmd[2..$]})*/
    if (IS_SEQUENCE(_cmd_14938)){
            _8357 = SEQ_PTR(_cmd_14938)->length;
    }
    else {
        _8357 = 1;
    }
    rhs_slice_target = (object_ptr)&_8358;
    RHS_Slice(_cmd_14938, 2, _8357);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _8358;
    _8359 = MAKE_SEQ(_1);
    _8358 = NOVALUE;
    EPrintf(2, _8356, _8359);
    DeRefDS(_8359);
    _8359 = NOVALUE;

    /** cmdline.e:926				if help_on_error then*/
    if (_help_on_error_14944 == 0)
    {
        goto L4; // [121] 136
    }
    else{
    }

    /** cmdline.e:927					local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_14940);
    RefDS(_cmds_14939);
    Ref(_parse_options_14943);
    _4local_help(_opts_14940, _add_help_rid_14942, _cmds_14939, 1, _parse_options_14943);
    goto L5; // [133] 149
L4: 

    /** cmdline.e:928				elsif auto_help then*/
    if (_auto_help_14945 == 0)
    {
        goto L6; // [138] 148
    }
    else{
    }

    /** cmdline.e:929					printf(2,"Try '--help' for more information.\n",{})          */
    EPrintf(2, _8360, _5);
L6: 
L5: 

    /** cmdline.e:931				local_abort(1)*/
    _4local_abort(1);
L3: 
L2: 

    /** cmdline.e:936		j = 0*/
    _j_14947 = 0;

    /** cmdline.e:937		while j < length(at_cmds) do*/
L7: 
    if (IS_SEQUENCE(_at_cmds_14946)){
            _8361 = SEQ_PTR(_at_cmds_14946)->length;
    }
    else {
        _8361 = 1;
    }
    if (_j_14947 >= _8361)
    goto L8; // [171] 492

    /** cmdline.e:938			j += 1*/
    _j_14947 = _j_14947 + 1;

    /** cmdline.e:939			at_cmds[j] = text:trim(at_cmds[j])*/
    _2 = (object)SEQ_PTR(_at_cmds_14946);
    _8364 = (object)*(((s1_ptr)_2)->base + _j_14947);
    Ref(_8364);
    RefDS(_3871);
    _8365 = _14trim(_8364, _3871, 0);
    _8364 = NOVALUE;
    _2 = (object)SEQ_PTR(_at_cmds_14946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _at_cmds_14946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _j_14947);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _8365;
    if( _1 != _8365 ){
        DeRef(_1);
    }
    _8365 = NOVALUE;

    /** cmdline.e:940			if length(at_cmds[j]) = 0 then*/
    _2 = (object)SEQ_PTR(_at_cmds_14946);
    _8366 = (object)*(((s1_ptr)_2)->base + _j_14947);
    if (IS_SEQUENCE(_8366)){
            _8367 = SEQ_PTR(_8366)->length;
    }
    else {
        _8367 = 1;
    }
    _8366 = NOVALUE;
    if (_8367 != 0)
    goto L9; // [206] 246

    /** cmdline.e:941				at_cmds = at_cmds[1 .. j-1] & at_cmds[j+1 ..$]*/
    _8369 = _j_14947 - 1;
    rhs_slice_target = (object_ptr)&_8370;
    RHS_Slice(_at_cmds_14946, 1, _8369);
    _8371 = _j_14947 + 1;
    if (_8371 > MAXINT){
        _8371 = NewDouble((eudouble)_8371);
    }
    if (IS_SEQUENCE(_at_cmds_14946)){
            _8372 = SEQ_PTR(_at_cmds_14946)->length;
    }
    else {
        _8372 = 1;
    }
    rhs_slice_target = (object_ptr)&_8373;
    RHS_Slice(_at_cmds_14946, _8371, _8372);
    Concat((object_ptr)&_at_cmds_14946, _8370, _8373);
    DeRefDS(_8370);
    _8370 = NOVALUE;
    DeRef(_8370);
    _8370 = NOVALUE;
    DeRefDS(_8373);
    _8373 = NOVALUE;

    /** cmdline.e:942				j -= 1*/
    _j_14947 = _j_14947 - 1;
    goto L7; // [243] 166
L9: 

    /** cmdline.e:944			elsif at_cmds[j][1] = '#' then*/
    _2 = (object)SEQ_PTR(_at_cmds_14946);
    _8376 = (object)*(((s1_ptr)_2)->base + _j_14947);
    _2 = (object)SEQ_PTR(_8376);
    _8377 = (object)*(((s1_ptr)_2)->base + 1);
    _8376 = NOVALUE;
    if (binary_op_a(NOTEQ, _8377, 35)){
        _8377 = NOVALUE;
        goto LA; // [256] 296
    }
    _8377 = NOVALUE;

    /** cmdline.e:945				at_cmds = at_cmds[1 .. j-1] & at_cmds[j+1 ..$]*/
    _8379 = _j_14947 - 1;
    rhs_slice_target = (object_ptr)&_8380;
    RHS_Slice(_at_cmds_14946, 1, _8379);
    _8381 = _j_14947 + 1;
    if (_8381 > MAXINT){
        _8381 = NewDouble((eudouble)_8381);
    }
    if (IS_SEQUENCE(_at_cmds_14946)){
            _8382 = SEQ_PTR(_at_cmds_14946)->length;
    }
    else {
        _8382 = 1;
    }
    rhs_slice_target = (object_ptr)&_8383;
    RHS_Slice(_at_cmds_14946, _8381, _8382);
    Concat((object_ptr)&_at_cmds_14946, _8380, _8383);
    DeRefDS(_8380);
    _8380 = NOVALUE;
    DeRef(_8380);
    _8380 = NOVALUE;
    DeRefDS(_8383);
    _8383 = NOVALUE;

    /** cmdline.e:946				j -= 1*/
    _j_14947 = _j_14947 - 1;
    goto L7; // [293] 166
LA: 

    /** cmdline.e:948			elsif at_cmds[j][1] = '"' and at_cmds[j][$] = '"' and length(at_cmds[j]) >= 2 then*/
    _2 = (object)SEQ_PTR(_at_cmds_14946);
    _8386 = (object)*(((s1_ptr)_2)->base + _j_14947);
    _2 = (object)SEQ_PTR(_8386);
    _8387 = (object)*(((s1_ptr)_2)->base + 1);
    _8386 = NOVALUE;
    if (IS_ATOM_INT(_8387)) {
        _8388 = (_8387 == 34);
    }
    else {
        _8388 = binary_op(EQUALS, _8387, 34);
    }
    _8387 = NOVALUE;
    if (IS_ATOM_INT(_8388)) {
        if (_8388 == 0) {
            DeRef(_8389);
            _8389 = 0;
            goto LB; // [310] 333
        }
    }
    else {
        if (DBL_PTR(_8388)->dbl == 0.0) {
            DeRef(_8389);
            _8389 = 0;
            goto LB; // [310] 333
        }
    }
    _2 = (object)SEQ_PTR(_at_cmds_14946);
    _8390 = (object)*(((s1_ptr)_2)->base + _j_14947);
    if (IS_SEQUENCE(_8390)){
            _8391 = SEQ_PTR(_8390)->length;
    }
    else {
        _8391 = 1;
    }
    _2 = (object)SEQ_PTR(_8390);
    _8392 = (object)*(((s1_ptr)_2)->base + _8391);
    _8390 = NOVALUE;
    if (IS_ATOM_INT(_8392)) {
        _8393 = (_8392 == 34);
    }
    else {
        _8393 = binary_op(EQUALS, _8392, 34);
    }
    _8392 = NOVALUE;
    DeRef(_8389);
    if (IS_ATOM_INT(_8393))
    _8389 = (_8393 != 0);
    else
    _8389 = DBL_PTR(_8393)->dbl != 0.0;
LB: 
    if (_8389 == 0) {
        goto LC; // [333] 377
    }
    _2 = (object)SEQ_PTR(_at_cmds_14946);
    _8395 = (object)*(((s1_ptr)_2)->base + _j_14947);
    if (IS_SEQUENCE(_8395)){
            _8396 = SEQ_PTR(_8395)->length;
    }
    else {
        _8396 = 1;
    }
    _8395 = NOVALUE;
    _8397 = (_8396 >= 2);
    _8396 = NOVALUE;
    if (_8397 == 0)
    {
        DeRef(_8397);
        _8397 = NOVALUE;
        goto LC; // [349] 377
    }
    else{
        DeRef(_8397);
        _8397 = NOVALUE;
    }

    /** cmdline.e:949				at_cmds[j] = at_cmds[j][2 .. $-1]*/
    _2 = (object)SEQ_PTR(_at_cmds_14946);
    _8398 = (object)*(((s1_ptr)_2)->base + _j_14947);
    if (IS_SEQUENCE(_8398)){
            _8399 = SEQ_PTR(_8398)->length;
    }
    else {
        _8399 = 1;
    }
    _8400 = _8399 - 1;
    _8399 = NOVALUE;
    rhs_slice_target = (object_ptr)&_8401;
    RHS_Slice(_8398, 2, _8400);
    _8398 = NOVALUE;
    _2 = (object)SEQ_PTR(_at_cmds_14946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _at_cmds_14946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _j_14947);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _8401;
    if( _1 != _8401 ){
        DeRef(_1);
    }
    _8401 = NOVALUE;
    goto L7; // [374] 166
LC: 

    /** cmdline.e:951			elsif at_cmds[j][1] = '\'' and at_cmds[j][$] = '\'' and length(at_cmds[j]) >= 2 then*/
    _2 = (object)SEQ_PTR(_at_cmds_14946);
    _8402 = (object)*(((s1_ptr)_2)->base + _j_14947);
    _2 = (object)SEQ_PTR(_8402);
    _8403 = (object)*(((s1_ptr)_2)->base + 1);
    _8402 = NOVALUE;
    if (IS_ATOM_INT(_8403)) {
        _8404 = (_8403 == 39);
    }
    else {
        _8404 = binary_op(EQUALS, _8403, 39);
    }
    _8403 = NOVALUE;
    if (IS_ATOM_INT(_8404)) {
        if (_8404 == 0) {
            DeRef(_8405);
            _8405 = 0;
            goto LD; // [391] 414
        }
    }
    else {
        if (DBL_PTR(_8404)->dbl == 0.0) {
            DeRef(_8405);
            _8405 = 0;
            goto LD; // [391] 414
        }
    }
    _2 = (object)SEQ_PTR(_at_cmds_14946);
    _8406 = (object)*(((s1_ptr)_2)->base + _j_14947);
    if (IS_SEQUENCE(_8406)){
            _8407 = SEQ_PTR(_8406)->length;
    }
    else {
        _8407 = 1;
    }
    _2 = (object)SEQ_PTR(_8406);
    _8408 = (object)*(((s1_ptr)_2)->base + _8407);
    _8406 = NOVALUE;
    if (IS_ATOM_INT(_8408)) {
        _8409 = (_8408 == 39);
    }
    else {
        _8409 = binary_op(EQUALS, _8408, 39);
    }
    _8408 = NOVALUE;
    DeRef(_8405);
    if (IS_ATOM_INT(_8409))
    _8405 = (_8409 != 0);
    else
    _8405 = DBL_PTR(_8409)->dbl != 0.0;
LD: 
    if (_8405 == 0) {
        goto LE; // [414] 484
    }
    _2 = (object)SEQ_PTR(_at_cmds_14946);
    _8411 = (object)*(((s1_ptr)_2)->base + _j_14947);
    if (IS_SEQUENCE(_8411)){
            _8412 = SEQ_PTR(_8411)->length;
    }
    else {
        _8412 = 1;
    }
    _8411 = NOVALUE;
    _8413 = (_8412 >= 2);
    _8412 = NOVALUE;
    if (_8413 == 0)
    {
        DeRef(_8413);
        _8413 = NOVALUE;
        goto LE; // [430] 484
    }
    else{
        DeRef(_8413);
        _8413 = NOVALUE;
    }

    /** cmdline.e:952				sequence cmdex = stdseq:split(at_cmds[j][2 .. $-1],' ', 1) -- Empty words removed.*/
    _2 = (object)SEQ_PTR(_at_cmds_14946);
    _8414 = (object)*(((s1_ptr)_2)->base + _j_14947);
    if (IS_SEQUENCE(_8414)){
            _8415 = SEQ_PTR(_8414)->length;
    }
    else {
        _8415 = 1;
    }
    _8416 = _8415 - 1;
    _8415 = NOVALUE;
    rhs_slice_target = (object_ptr)&_8417;
    RHS_Slice(_8414, 2, _8416);
    _8414 = NOVALUE;
    _0 = _cmdex_15031;
    _cmdex_15031 = _23split(_8417, 32, 1, 0);
    DeRef(_0);
    _8417 = NOVALUE;

    /** cmdline.e:954				at_cmds = replace(at_cmds, cmdex, j)*/
    {
        intptr_t p1 = _at_cmds_14946;
        intptr_t p2 = _cmdex_15031;
        intptr_t p3 = _j_14947;
        intptr_t p4 = _j_14947;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_at_cmds_14946;
        Replace( &replace_params );
    }

    /** cmdline.e:955				j = j + length(cmdex) - 1*/
    if (IS_SEQUENCE(_cmdex_15031)){
            _8420 = SEQ_PTR(_cmdex_15031)->length;
    }
    else {
        _8420 = 1;
    }
    _8421 = _j_14947 + _8420;
    if ((object)((uintptr_t)_8421 + (uintptr_t)HIGH_BITS) >= 0){
        _8421 = NewDouble((eudouble)_8421);
    }
    _8420 = NOVALUE;
    if (IS_ATOM_INT(_8421)) {
        _j_14947 = _8421 - 1;
    }
    else {
        _j_14947 = NewDouble(DBL_PTR(_8421)->dbl - (eudouble)1);
    }
    DeRef(_8421);
    _8421 = NOVALUE;
    if (!IS_ATOM_INT(_j_14947)) {
        _1 = (object)(DBL_PTR(_j_14947)->dbl);
        DeRefDS(_j_14947);
        _j_14947 = _1;
    }
LE: 
    DeRef(_cmdex_15031);
    _cmdex_15031 = NOVALUE;

    /** cmdline.e:958		end while*/
    goto L7; // [489] 166
L8: 

    /** cmdline.e:961		cmds = replace(cmds, at_cmds, arg_idx)*/
    {
        intptr_t p1 = _cmds_14939;
        intptr_t p2 = _at_cmds_14946;
        intptr_t p3 = _arg_idx_14941;
        intptr_t p4 = _arg_idx_14941;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_cmds_14939;
        Replace( &replace_params );
    }

    /** cmdline.e:962		return cmds*/
    DeRefDS(_cmd_14938);
    DeRefDS(_opts_14940);
    DeRefi(_parse_options_14943);
    DeRef(_at_cmds_14946);
    _8395 = NOVALUE;
    DeRef(_8416);
    _8416 = NOVALUE;
    DeRef(_8393);
    _8393 = NOVALUE;
    DeRef(_8379);
    _8379 = NOVALUE;
    DeRef(_8400);
    _8400 = NOVALUE;
    _8366 = NOVALUE;
    DeRef(_8409);
    _8409 = NOVALUE;
    DeRef(_8343);
    _8343 = NOVALUE;
    DeRef(_8404);
    _8404 = NOVALUE;
    DeRef(_8388);
    _8388 = NOVALUE;
    DeRef(_8381);
    _8381 = NOVALUE;
    DeRef(_8369);
    _8369 = NOVALUE;
    _8411 = NOVALUE;
    DeRef(_8371);
    _8371 = NOVALUE;
    return _cmds_14939;
    ;
}


void _4check_mandatory(object _opts_15044, object _parsed_opts_15046, object _add_help_rid_15047, object _cmds_15048, object _parse_options_15049, object _help_on_error_15050, object _auto_help_15051)
{
    object _8448 = NOVALUE;
    object _8447 = NOVALUE;
    object _8446 = NOVALUE;
    object _8443 = NOVALUE;
    object _8442 = NOVALUE;
    object _8441 = NOVALUE;
    object _8438 = NOVALUE;
    object _8437 = NOVALUE;
    object _8436 = NOVALUE;
    object _8435 = NOVALUE;
    object _8434 = NOVALUE;
    object _8433 = NOVALUE;
    object _8432 = NOVALUE;
    object _8431 = NOVALUE;
    object _8430 = NOVALUE;
    object _8429 = NOVALUE;
    object _8428 = NOVALUE;
    object _8427 = NOVALUE;
    object _8426 = NOVALUE;
    object _8425 = NOVALUE;
    object _8424 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:969		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15044)){
            _8424 = SEQ_PTR(_opts_15044)->length;
    }
    else {
        _8424 = 1;
    }
    {
        object _i_15053;
        _i_15053 = 1;
L1: 
        if (_i_15053 > _8424){
            goto L2; // [14] 219
        }

        /** cmdline.e:970			if find(MANDATORY, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_15044);
        _8425 = (object)*(((s1_ptr)_2)->base + _i_15053);
        _2 = (object)SEQ_PTR(_8425);
        _8426 = (object)*(((s1_ptr)_2)->base + 4);
        _8425 = NOVALUE;
        _8427 = find_from(109, _8426, 1);
        _8426 = NOVALUE;
        if (_8427 == 0)
        {
            _8427 = NOVALUE;
            goto L3; // [36] 212
        }
        else{
            _8427 = NOVALUE;
        }

        /** cmdline.e:971				if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_15044);
        _8428 = (object)*(((s1_ptr)_2)->base + _i_15053);
        _2 = (object)SEQ_PTR(_8428);
        _8429 = (object)*(((s1_ptr)_2)->base + 1);
        _8428 = NOVALUE;
        _8430 = IS_ATOM(_8429);
        _8429 = NOVALUE;
        if (_8430 == 0) {
            goto L4; // [52] 138
        }
        _2 = (object)SEQ_PTR(_opts_15044);
        _8432 = (object)*(((s1_ptr)_2)->base + _i_15053);
        _2 = (object)SEQ_PTR(_8432);
        _8433 = (object)*(((s1_ptr)_2)->base + 2);
        _8432 = NOVALUE;
        _8434 = IS_ATOM(_8433);
        _8433 = NOVALUE;
        if (_8434 == 0)
        {
            _8434 = NOVALUE;
            goto L4; // [68] 138
        }
        else{
            _8434 = NOVALUE;
        }

        /** cmdline.e:972					if length(map:get(parsed_opts, opts[i][MAPNAME])) = 0 then*/
        _2 = (object)SEQ_PTR(_opts_15044);
        _8435 = (object)*(((s1_ptr)_2)->base + _i_15053);
        _2 = (object)SEQ_PTR(_8435);
        _8436 = (object)*(((s1_ptr)_2)->base + 6);
        _8435 = NOVALUE;
        Ref(_parsed_opts_15046);
        Ref(_8436);
        _8437 = _29get(_parsed_opts_15046, _8436, 0);
        _8436 = NOVALUE;
        if (IS_SEQUENCE(_8437)){
                _8438 = SEQ_PTR(_8437)->length;
        }
        else {
            _8438 = 1;
        }
        DeRef(_8437);
        _8437 = NOVALUE;
        if (_8438 != 0)
        goto L5; // [90] 211

        /** cmdline.e:973						puts(1, "Additional arguments were expected.\n\n")*/
        EPuts(1, _8440); // DJP 

        /** cmdline.e:974						if help_on_error then*/
        if (_help_on_error_15050 == 0)
        {
            goto L6; // [101] 116
        }
        else{
        }

        /** cmdline.e:975							local_help(opts, add_help_rid, cmds, 1, parse_options)*/
        RefDS(_opts_15044);
        RefDS(_cmds_15048);
        Ref(_parse_options_15049);
        _4local_help(_opts_15044, _add_help_rid_15047, _cmds_15048, 1, _parse_options_15049);
        goto L7; // [113] 129
L6: 

        /** cmdline.e:976						elsif auto_help then*/
        if (_auto_help_15051 == 0)
        {
            goto L8; // [118] 128
        }
        else{
        }

        /** cmdline.e:977							printf(2,"Try '--help' for more information.\n",{})          */
        EPrintf(2, _8360, _5);
L8: 
L7: 

        /** cmdline.e:979						local_abort(1)*/
        _4local_abort(1);
        goto L5; // [135] 211
L4: 

        /** cmdline.e:982					if not map:has(parsed_opts, opts[i][MAPNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_15044);
        _8441 = (object)*(((s1_ptr)_2)->base + _i_15053);
        _2 = (object)SEQ_PTR(_8441);
        _8442 = (object)*(((s1_ptr)_2)->base + 6);
        _8441 = NOVALUE;
        Ref(_parsed_opts_15046);
        Ref(_8442);
        _8443 = _29has(_parsed_opts_15046, _8442);
        _8442 = NOVALUE;
        if (IS_ATOM_INT(_8443)) {
            if (_8443 != 0){
                DeRef(_8443);
                _8443 = NOVALUE;
                goto L9; // [153] 210
            }
        }
        else {
            if (DBL_PTR(_8443)->dbl != 0.0){
                DeRef(_8443);
                _8443 = NOVALUE;
                goto L9; // [153] 210
            }
        }
        DeRef(_8443);
        _8443 = NOVALUE;

        /** cmdline.e:983						printf(1, "option '%s' is mandatory but was not supplied.\n\n", {opts[i][MAPNAME]})*/
        _2 = (object)SEQ_PTR(_opts_15044);
        _8446 = (object)*(((s1_ptr)_2)->base + _i_15053);
        _2 = (object)SEQ_PTR(_8446);
        _8447 = (object)*(((s1_ptr)_2)->base + 6);
        _8446 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_8447);
        ((intptr_t*)_2)[1] = _8447;
        _8448 = MAKE_SEQ(_1);
        _8447 = NOVALUE;
        EPrintf(1, _8445, _8448);
        DeRefDS(_8448);
        _8448 = NOVALUE;

        /** cmdline.e:984						if help_on_error then*/
        if (_help_on_error_15050 == 0)
        {
            goto LA; // [176] 191
        }
        else{
        }

        /** cmdline.e:985							local_help(opts, add_help_rid, cmds, 1, parse_options)*/
        RefDS(_opts_15044);
        RefDS(_cmds_15048);
        Ref(_parse_options_15049);
        _4local_help(_opts_15044, _add_help_rid_15047, _cmds_15048, 1, _parse_options_15049);
        goto LB; // [188] 204
LA: 

        /** cmdline.e:986						elsif auto_help then*/
        if (_auto_help_15051 == 0)
        {
            goto LC; // [193] 203
        }
        else{
        }

        /** cmdline.e:987							printf(2,"Try '--help' for more information.\n",{})          */
        EPrintf(2, _8360, _5);
LC: 
LB: 

        /** cmdline.e:989						local_abort(1)*/
        _4local_abort(1);
L9: 
L5: 
L3: 

        /** cmdline.e:993		end for*/
        _i_15053 = _i_15053 + 1;
        goto L1; // [214] 21
L2: 
        ;
    }

    /** cmdline.e:994	end procedure*/
    DeRefDS(_opts_15044);
    DeRef(_parsed_opts_15046);
    DeRefDS(_cmds_15048);
    DeRefi(_parse_options_15049);
    _8437 = NOVALUE;
    return;
    ;
}


void _4parse_abort(object _format_msg_15090, object _msg_data_15091, object _opts_15092, object _add_help_rid_15093, object _cmds_15094, object _parse_options_15095, object _help_on_error_15096, object _auto_help_15097)
{
    object _0, _1, _2;
    

    /** cmdline.e:999		printf(1, format_msg, msg_data)*/
    EPrintf(1, _format_msg_15090, _msg_data_15091);

    /** cmdline.e:1000		if help_on_error then*/
    if (_help_on_error_15096 == 0)
    {
        goto L1; // [21] 36
    }
    else{
    }

    /** cmdline.e:1001			local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_15092);
    RefDS(_cmds_15094);
    Ref(_parse_options_15095);
    _4local_help(_opts_15092, _add_help_rid_15093, _cmds_15094, 1, _parse_options_15095);
    goto L2; // [33] 49
L1: 

    /** cmdline.e:1002		elsif auto_help then*/
    if (_auto_help_15097 == 0)
    {
        goto L3; // [38] 48
    }
    else{
    }

    /** cmdline.e:1003			printf(2,"Try '--help' for more information.\n",{})          */
    EPrintf(2, _8360, _5);
L3: 
L2: 

    /** cmdline.e:1005		local_abort(1)*/
    _4local_abort(1);

    /** cmdline.e:1006	end procedure*/
    DeRefDSi(_format_msg_15090);
    DeRefDS(_msg_data_15091);
    DeRefDS(_opts_15092);
    DeRefDS(_cmds_15094);
    DeRefi(_parse_options_15095);
    return;
    ;
}


object _4parse_commands(object _cmds_15102, object _opts_15103, object _parsed_opts_15105, object _help_opts_15106, object _add_help_rid_15107, object _parse_options_15108, object _use_at_15109, object _validation_15110, object _has_extra_15111, object _call_count_15112, object _help_on_error_15113, object _auto_help_15114)
{
    object _arg_idx_15115 = NOVALUE;
    object _opts_done_15116 = NOVALUE;
    object _find_result_15117 = NOVALUE;
    object _type__15118 = NOVALUE;
    object _from__15119 = NOVALUE;
    object _cmd_15120 = NOVALUE;
    object _handle_result_15185 = NOVALUE;
    object _8500 = NOVALUE;
    object _8496 = NOVALUE;
    object _8495 = NOVALUE;
    object _8493 = NOVALUE;
    object _8492 = NOVALUE;
    object _8491 = NOVALUE;
    object _8489 = NOVALUE;
    object _8487 = NOVALUE;
    object _8485 = NOVALUE;
    object _8483 = NOVALUE;
    object _8482 = NOVALUE;
    object _8481 = NOVALUE;
    object _8480 = NOVALUE;
    object _8479 = NOVALUE;
    object _8475 = NOVALUE;
    object _8473 = NOVALUE;
    object _8472 = NOVALUE;
    object _8471 = NOVALUE;
    object _8470 = NOVALUE;
    object _8469 = NOVALUE;
    object _8468 = NOVALUE;
    object _8466 = NOVALUE;
    object _8465 = NOVALUE;
    object _8464 = NOVALUE;
    object _8463 = NOVALUE;
    object _8462 = NOVALUE;
    object _8461 = NOVALUE;
    object _8460 = NOVALUE;
    object _8457 = NOVALUE;
    object _8456 = NOVALUE;
    object _8455 = NOVALUE;
    object _8453 = NOVALUE;
    object _8449 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:1016		integer arg_idx = 2*/
    _arg_idx_15115 = 2;

    /** cmdline.e:1017		integer opts_done = 0*/
    _opts_done_15116 = 0;

    /** cmdline.e:1023		while arg_idx < length(cmds) do*/
L1: 
    if (IS_SEQUENCE(_cmds_15102)){
            _8449 = SEQ_PTR(_cmds_15102)->length;
    }
    else {
        _8449 = 1;
    }
    if (_arg_idx_15115 >= _8449)
    goto L2; // [37] 488

    /** cmdline.e:1024			arg_idx += 1*/
    _arg_idx_15115 = _arg_idx_15115 + 1;

    /** cmdline.e:1026			cmd = cmds[arg_idx]*/
    DeRef(_cmd_15120);
    _2 = (object)SEQ_PTR(_cmds_15102);
    _cmd_15120 = (object)*(((s1_ptr)_2)->base + _arg_idx_15115);
    Ref(_cmd_15120);

    /** cmdline.e:1027			if length(cmd) = 0 then*/
    if (IS_SEQUENCE(_cmd_15120)){
            _8453 = SEQ_PTR(_cmd_15120)->length;
    }
    else {
        _8453 = 1;
    }
    if (_8453 != 0)
    goto L3; // [60] 69

    /** cmdline.e:1028				continue*/
    goto L1; // [66] 34
L3: 

    /** cmdline.e:1031			if cmd[1] = '@' and use_at then*/
    _2 = (object)SEQ_PTR(_cmd_15120);
    _8455 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8455)) {
        _8456 = (_8455 == 64);
    }
    else {
        _8456 = binary_op(EQUALS, _8455, 64);
    }
    _8455 = NOVALUE;
    if (IS_ATOM_INT(_8456)) {
        if (_8456 == 0) {
            goto L4; // [79] 113
        }
    }
    else {
        if (DBL_PTR(_8456)->dbl == 0.0) {
            goto L4; // [79] 113
        }
    }
    if (_use_at_15109 == 0)
    {
        goto L4; // [84] 113
    }
    else{
    }

    /** cmdline.e:1032				cmds = parse_at_cmds( cmd, cmds, opts, arg_idx, add_help_rid, parse_options, help_on_error, auto_help )*/
    RefDS(_cmd_15120);
    RefDS(_cmds_15102);
    RefDS(_opts_15103);
    Ref(_parse_options_15108);
    _0 = _cmds_15102;
    _cmds_15102 = _4parse_at_cmds(_cmd_15120, _cmds_15102, _opts_15103, _arg_idx_15115, _add_help_rid_15107, _parse_options_15108, _help_on_error_15113, _auto_help_15114);
    DeRefDS(_0);

    /** cmdline.e:1033				arg_idx -= 1*/
    _arg_idx_15115 = _arg_idx_15115 - 1;

    /** cmdline.e:1034				continue*/
    goto L1; // [110] 34
L4: 

    /** cmdline.e:1037			if (opts_done or find(cmd[1], os:CMD_SWITCHES) = 0 or length(cmd) = 1)*/
    if (_opts_done_15116 != 0) {
        _8460 = 1;
        goto L5; // [115] 136
    }
    _2 = (object)SEQ_PTR(_cmd_15120);
    _8461 = (object)*(((s1_ptr)_2)->base + 1);
    _8462 = find_from(_8461, _35CMD_SWITCHES_14078, 1);
    _8461 = NOVALUE;
    _8463 = (_8462 == 0);
    _8462 = NOVALUE;
    _8460 = (_8463 != 0);
L5: 
    if (_8460 != 0) {
        DeRef(_8464);
        _8464 = 1;
        goto L6; // [136] 151
    }
    if (IS_SEQUENCE(_cmd_15120)){
            _8465 = SEQ_PTR(_cmd_15120)->length;
    }
    else {
        _8465 = 1;
    }
    _8466 = (_8465 == 1);
    _8465 = NOVALUE;
    _8464 = (_8466 != 0);
L6: 
    if (_8464 == 0)
    {
        _8464 = NOVALUE;
        goto L7; // [151] 227
    }
    else{
        _8464 = NOVALUE;
    }

    /** cmdline.e:1039				map:put(parsed_opts, EXTRAS, cmd, map:APPEND)*/
    Ref(_parsed_opts_15105);
    RefDS(_4EXTRAS_14176);
    RefDS(_cmd_15120);
    _29put(_parsed_opts_15105, _4EXTRAS_14176, _cmd_15120, 6, 0);

    /** cmdline.e:1040				has_extra = 1*/
    _has_extra_15111 = 1;

    /** cmdline.e:1041				if validation = NO_VALIDATION_AFTER_FIRST_EXTRA then*/
    if (_validation_15110 != 4)
    goto L1; // [172] 34

    /** cmdline.e:1042					for i = arg_idx + 1 to length(cmds) do*/
    _8468 = _arg_idx_15115 + 1;
    if (_8468 > MAXINT){
        _8468 = NewDouble((eudouble)_8468);
    }
    if (IS_SEQUENCE(_cmds_15102)){
            _8469 = SEQ_PTR(_cmds_15102)->length;
    }
    else {
        _8469 = 1;
    }
    {
        object _i_15146;
        Ref(_8468);
        _i_15146 = _8468;
L8: 
        if (binary_op_a(GREATER, _i_15146, _8469)){
            goto L9; // [185] 214
        }

        /** cmdline.e:1043						map:put(parsed_opts, EXTRAS, cmds[i], map:APPEND)*/
        _2 = (object)SEQ_PTR(_cmds_15102);
        if (!IS_ATOM_INT(_i_15146)){
            _8470 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_15146)->dbl));
        }
        else{
            _8470 = (object)*(((s1_ptr)_2)->base + _i_15146);
        }
        Ref(_parsed_opts_15105);
        RefDS(_4EXTRAS_14176);
        Ref(_8470);
        _29put(_parsed_opts_15105, _4EXTRAS_14176, _8470, 6, 0);
        _8470 = NOVALUE;

        /** cmdline.e:1044					end for*/
        _0 = _i_15146;
        if (IS_ATOM_INT(_i_15146)) {
            _i_15146 = _i_15146 + 1;
            if ((object)((uintptr_t)_i_15146 +(uintptr_t) HIGH_BITS) >= 0){
                _i_15146 = NewDouble((eudouble)_i_15146);
            }
        }
        else {
            _i_15146 = binary_op_a(PLUS, _i_15146, 1);
        }
        DeRef(_0);
        goto L8; // [209] 192
L9: 
        ;
        DeRef(_i_15146);
    }

    /** cmdline.e:1046					exit*/
    goto L2; // [216] 488
    goto LA; // [218] 226

    /** cmdline.e:1048					continue*/
    goto L1; // [223] 34
LA: 
L7: 

    /** cmdline.e:1052			if equal(cmd, "--") then*/
    if (_cmd_15120 == _7162)
    _8471 = 1;
    else if (IS_ATOM_INT(_cmd_15120) && IS_ATOM_INT(_7162))
    _8471 = 0;
    else
    _8471 = (compare(_cmd_15120, _7162) == 0);
    if (_8471 == 0)
    {
        _8471 = NOVALUE;
        goto LB; // [233] 246
    }
    else{
        _8471 = NOVALUE;
    }

    /** cmdline.e:1053				opts_done = 1*/
    _opts_done_15116 = 1;

    /** cmdline.e:1054				continue*/
    goto L1; // [243] 34
LB: 

    /** cmdline.e:1057			if equal(cmd[1..2], "--") then	  -- found --opt-name*/
    rhs_slice_target = (object_ptr)&_8472;
    RHS_Slice(_cmd_15120, 1, 2);
    if (_8472 == _7162)
    _8473 = 1;
    else if (IS_ATOM_INT(_8472) && IS_ATOM_INT(_7162))
    _8473 = 0;
    else
    _8473 = (compare(_8472, _7162) == 0);
    DeRefDS(_8472);
    _8472 = NOVALUE;
    if (_8473 == 0)
    {
        _8473 = NOVALUE;
        goto LC; // [257] 274
    }
    else{
        _8473 = NOVALUE;
    }

    /** cmdline.e:1058				type_ = {LONGNAME, "--"}*/
    RefDS(_7162);
    DeRef(_type__15118);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 2;
    ((intptr_t *)_2)[2] = _7162;
    _type__15118 = MAKE_SEQ(_1);

    /** cmdline.e:1059				from_ = 3*/
    _from__15119 = 3;
    goto LD; // [271] 310
LC: 

    /** cmdline.e:1060			elsif cmd[1] = '-' then -- found -opt*/
    _2 = (object)SEQ_PTR(_cmd_15120);
    _8475 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _8475, 45)){
        _8475 = NOVALUE;
        goto LE; // [280] 298
    }
    _8475 = NOVALUE;

    /** cmdline.e:1061				type_ = {SHORTNAME, "-"}*/
    RefDS(_7133);
    DeRef(_type__15118);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = _7133;
    _type__15118 = MAKE_SEQ(_1);

    /** cmdline.e:1062				from_ = 2*/
    _from__15119 = 2;
    goto LD; // [295] 310
LE: 

    /** cmdline.e:1064				type_ = {SHORTNAME, "/"}*/
    RefDS(_3121);
    DeRef(_type__15118);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = _3121;
    _type__15118 = MAKE_SEQ(_1);

    /** cmdline.e:1065				from_ = 2*/
    _from__15119 = 2;
LD: 

    /** cmdline.e:1068			if find(cmd[from_..$], help_opts) then*/
    if (IS_SEQUENCE(_cmd_15120)){
            _8479 = SEQ_PTR(_cmd_15120)->length;
    }
    else {
        _8479 = 1;
    }
    rhs_slice_target = (object_ptr)&_8480;
    RHS_Slice(_cmd_15120, _from__15119, _8479);
    _8481 = find_from(_8480, _help_opts_15106, 1);
    DeRefDS(_8480);
    _8480 = NOVALUE;
    if (_8481 == 0)
    {
        _8481 = NOVALUE;
        goto LF; // [327] 347
    }
    else{
        _8481 = NOVALUE;
    }

    /** cmdline.e:1069				local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_15103);
    RefDS(_cmds_15102);
    Ref(_parse_options_15108);
    _4local_help(_opts_15103, _add_help_rid_15107, _cmds_15102, 1, _parse_options_15108);

    /** cmdline.e:1070				ifdef UNITTEST then*/

    /** cmdline.e:1073				local_abort(0)*/
    _4local_abort(0);
LF: 

    /** cmdline.e:1076			find_result = find_opt(opts, type_, cmd[from_..$])*/
    if (IS_SEQUENCE(_cmd_15120)){
            _8482 = SEQ_PTR(_cmd_15120)->length;
    }
    else {
        _8482 = 1;
    }
    rhs_slice_target = (object_ptr)&_8483;
    RHS_Slice(_cmd_15120, _from__15119, _8482);
    RefDS(_opts_15103);
    RefDS(_type__15118);
    _0 = _find_result_15117;
    _find_result_15117 = _4find_opt(_opts_15103, _type__15118, _8483);
    DeRef(_0);
    _8483 = NOVALUE;

    /** cmdline.e:1078			if find_result[1] < 0 then*/
    _2 = (object)SEQ_PTR(_find_result_15117);
    _8485 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _8485, 0)){
        _8485 = NOVALUE;
        goto L10; // [373] 382
    }
    _8485 = NOVALUE;

    /** cmdline.e:1079				continue -- Couldn't use this command argument for anything.*/
    goto L1; // [379] 34
L10: 

    /** cmdline.e:1082			if find_result[1] = 0 then*/
    _2 = (object)SEQ_PTR(_find_result_15117);
    _8487 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _8487, 0)){
        _8487 = NOVALUE;
        goto L11; // [388] 449
    }
    _8487 = NOVALUE;

    /** cmdline.e:1083				if validation = VALIDATE_ALL or*/
    _8489 = (_validation_15110 == 2);
    if (_8489 != 0) {
        goto L12; // [398] 423
    }
    _8491 = (_validation_15110 == 4);
    if (_8491 == 0) {
        DeRef(_8492);
        _8492 = 0;
        goto L13; // [406] 418
    }
    _8493 = (_has_extra_15111 == 0);
    _8492 = (_8493 != 0);
L13: 
    if (_8492 == 0)
    {
        _8492 = NOVALUE;
        goto L1; // [419] 34
    }
    else{
        _8492 = NOVALUE;
    }
L12: 

    /** cmdline.e:1087					parse_abort( "option '%s': %s\n\n", {cmd, find_result[2]}, */
    _2 = (object)SEQ_PTR(_find_result_15117);
    _8495 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_8495);
    RefDS(_cmd_15120);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _cmd_15120;
    ((intptr_t *)_2)[2] = _8495;
    _8496 = MAKE_SEQ(_1);
    _8495 = NOVALUE;
    RefDS(_8494);
    RefDS(_opts_15103);
    RefDS(_cmds_15102);
    Ref(_parse_options_15108);
    _4parse_abort(_8494, _8496, _opts_15103, _add_help_rid_15107, _cmds_15102, _parse_options_15108, _help_on_error_15113, _auto_help_15114);
    _8496 = NOVALUE;

    /** cmdline.e:1091				continue*/
    goto L1; // [446] 34
L11: 

    /** cmdline.e:1094			sequence handle_result = handle_opt( find_result, arg_idx, opts, parsed_opts, cmds, add_help_rid,*/
    RefDS(_find_result_15117);
    RefDS(_opts_15103);
    Ref(_parsed_opts_15105);
    RefDS(_cmds_15102);
    Ref(_parse_options_15108);
    RefDS(_call_count_15112);
    _0 = _handle_result_15185;
    _handle_result_15185 = _4handle_opt(_find_result_15117, _arg_idx_15115, _opts_15103, _parsed_opts_15105, _cmds_15102, _add_help_rid_15107, _parse_options_15108, _call_count_15112, _validation_15110, _help_on_error_15113, _auto_help_15114);
    DeRef(_0);

    /** cmdline.e:1096			arg_idx     = handle_result[1]*/
    _2 = (object)SEQ_PTR(_handle_result_15185);
    _arg_idx_15115 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_arg_idx_15115))
    _arg_idx_15115 = (object)DBL_PTR(_arg_idx_15115)->dbl;

    /** cmdline.e:1097			call_count = handle_result[2]*/
    DeRefDS(_call_count_15112);
    _2 = (object)SEQ_PTR(_handle_result_15185);
    _call_count_15112 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_call_count_15112);
    DeRefDS(_handle_result_15185);
    _handle_result_15185 = NOVALUE;

    /** cmdline.e:1098		end while*/
    goto L1; // [485] 34
L2: 

    /** cmdline.e:1099		return { cmds, call_count }*/
    RefDS(_call_count_15112);
    RefDS(_cmds_15102);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _cmds_15102;
    ((intptr_t *)_2)[2] = _call_count_15112;
    _8500 = MAKE_SEQ(_1);
    DeRefDS(_cmds_15102);
    DeRefDS(_opts_15103);
    DeRef(_parsed_opts_15105);
    DeRefDS(_help_opts_15106);
    DeRefi(_parse_options_15108);
    DeRefDS(_call_count_15112);
    DeRef(_find_result_15117);
    DeRef(_type__15118);
    DeRef(_cmd_15120);
    DeRef(_8493);
    _8493 = NOVALUE;
    DeRef(_8456);
    _8456 = NOVALUE;
    DeRef(_8463);
    _8463 = NOVALUE;
    DeRef(_8466);
    _8466 = NOVALUE;
    DeRef(_8489);
    _8489 = NOVALUE;
    DeRef(_8468);
    _8468 = NOVALUE;
    DeRef(_8491);
    _8491 = NOVALUE;
    return _8500;
    ;
}


object _4handle_opt(object _find_result_15193, object _arg_idx_15194, object _opts_15195, object _parsed_opts_15197, object _cmds_15198, object _add_help_rid_15199, object _parse_options_15200, object _call_count_15201, object _validation_15202, object _help_on_error_15203, object _auto_help_15204)
{
    object _map_add_operation_15205 = NOVALUE;
    object _opt_15206 = NOVALUE;
    object _param_15209 = NOVALUE;
    object _pos_15246 = NOVALUE;
    object _ver_pos_15292 = NOVALUE;
    object _msg_inlined_crash_at_524_15309 = NOVALUE;
    object _fmt_inlined_crash_at_521_15308 = NOVALUE;
    object _8578 = NOVALUE;
    object _8577 = NOVALUE;
    object _8574 = NOVALUE;
    object _8573 = NOVALUE;
    object _8572 = NOVALUE;
    object _8570 = NOVALUE;
    object _8569 = NOVALUE;
    object _8567 = NOVALUE;
    object _8566 = NOVALUE;
    object _8565 = NOVALUE;
    object _8564 = NOVALUE;
    object _8563 = NOVALUE;
    object _8562 = NOVALUE;
    object _8561 = NOVALUE;
    object _8560 = NOVALUE;
    object _8558 = NOVALUE;
    object _8557 = NOVALUE;
    object _8555 = NOVALUE;
    object _8554 = NOVALUE;
    object _8553 = NOVALUE;
    object _8552 = NOVALUE;
    object _8551 = NOVALUE;
    object _8550 = NOVALUE;
    object _8549 = NOVALUE;
    object _8548 = NOVALUE;
    object _8546 = NOVALUE;
    object _8545 = NOVALUE;
    object _8544 = NOVALUE;
    object _8542 = NOVALUE;
    object _8541 = NOVALUE;
    object _8539 = NOVALUE;
    object _8538 = NOVALUE;
    object _8537 = NOVALUE;
    object _8536 = NOVALUE;
    object _8535 = NOVALUE;
    object _8534 = NOVALUE;
    object _8533 = NOVALUE;
    object _8532 = NOVALUE;
    object _8531 = NOVALUE;
    object _8528 = NOVALUE;
    object _8525 = NOVALUE;
    object _8524 = NOVALUE;
    object _8522 = NOVALUE;
    object _8521 = NOVALUE;
    object _8520 = NOVALUE;
    object _8519 = NOVALUE;
    object _8518 = NOVALUE;
    object _8517 = NOVALUE;
    object _8516 = NOVALUE;
    object _8515 = NOVALUE;
    object _8514 = NOVALUE;
    object _8513 = NOVALUE;
    object _8512 = NOVALUE;
    object _8509 = NOVALUE;
    object _8506 = NOVALUE;
    object _8504 = NOVALUE;
    object _8503 = NOVALUE;
    object _8501 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:1110		integer map_add_operation = map:ADD*/
    _map_add_operation_15205 = 2;

    /** cmdline.e:1111		sequence opt = opts[find_result[1]]*/
    _2 = (object)SEQ_PTR(_find_result_15193);
    _8501 = (object)*(((s1_ptr)_2)->base + 1);
    DeRef(_opt_15206);
    _2 = (object)SEQ_PTR(_opts_15195);
    if (!IS_ATOM_INT(_8501)){
        _opt_15206 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_8501)->dbl));
    }
    else{
        _opt_15206 = (object)*(((s1_ptr)_2)->base + _8501);
    }
    Ref(_opt_15206);

    /** cmdline.e:1114		if find(HAS_PARAMETER, opt[OPTIONS]) != 0 then*/
    _2 = (object)SEQ_PTR(_opt_15206);
    _8503 = (object)*(((s1_ptr)_2)->base + 4);
    _8504 = find_from(112, _8503, 1);
    _8503 = NOVALUE;
    if (_8504 == 0)
    goto L1; // [45] 194

    /** cmdline.e:1115			map_add_operation = map:APPEND*/
    _map_add_operation_15205 = 6;

    /** cmdline.e:1116			if length(find_result) < 4 then*/
    if (IS_SEQUENCE(_find_result_15193)){
            _8506 = SEQ_PTR(_find_result_15193)->length;
    }
    else {
        _8506 = 1;
    }
    if (_8506 >= 4)
    goto L2; // [59] 184

    /** cmdline.e:1117				arg_idx += 1*/
    _arg_idx_15194 = _arg_idx_15194 + 1;

    /** cmdline.e:1118				if arg_idx <= length(cmds) then*/
    if (IS_SEQUENCE(_cmds_15198)){
            _8509 = SEQ_PTR(_cmds_15198)->length;
    }
    else {
        _8509 = 1;
    }
    if (_arg_idx_15194 > _8509)
    goto L3; // [74] 119

    /** cmdline.e:1119					param = cmds[arg_idx]*/
    DeRef(_param_15209);
    _2 = (object)SEQ_PTR(_cmds_15198);
    _param_15209 = (object)*(((s1_ptr)_2)->base + _arg_idx_15194);
    Ref(_param_15209);

    /** cmdline.e:1120					if length(param) = 2 and find(param[1], "-/") then*/
    if (IS_SEQUENCE(_param_15209)){
            _8512 = SEQ_PTR(_param_15209)->length;
    }
    else {
        _8512 = 1;
    }
    _8513 = (_8512 == 2);
    _8512 = NOVALUE;
    if (_8513 == 0) {
        goto L4; // [93] 125
    }
    _2 = (object)SEQ_PTR(_param_15209);
    _8515 = (object)*(((s1_ptr)_2)->base + 1);
    _8516 = find_from(_8515, _7816, 1);
    _8515 = NOVALUE;
    if (_8516 == 0)
    {
        _8516 = NOVALUE;
        goto L4; // [107] 125
    }
    else{
        _8516 = NOVALUE;
    }

    /** cmdline.e:1121						param = ""*/
    RefDS(_5);
    DeRef(_param_15209);
    _param_15209 = _5;
    goto L4; // [116] 125
L3: 

    /** cmdline.e:1124					param = ""*/
    RefDS(_5);
    DeRef(_param_15209);
    _param_15209 = _5;
L4: 

    /** cmdline.e:1127				if length(param) = 0 and (validation = VALIDATE_ALL or (*/
    if (IS_SEQUENCE(_param_15209)){
            _8517 = SEQ_PTR(_param_15209)->length;
    }
    else {
        _8517 = 1;
    }
    _8518 = (_8517 == 0);
    _8517 = NOVALUE;
    if (_8518 == 0) {
        goto L5; // [136] 201
    }
    _8520 = (_validation_15202 == 2);
    if (_8520 != 0) {
        DeRef(_8521);
        _8521 = 1;
        goto L6; // [144] 156
    }
    _8522 = (_validation_15202 == 4);
    _8521 = (_8522 != 0);
L6: 
    if (_8521 == 0)
    {
        _8521 = NOVALUE;
        goto L5; // [157] 201
    }
    else{
        _8521 = NOVALUE;
    }

    /** cmdline.e:1130					parse_abort( "option '%s' must have a parameter\n\n", {find_result[2]}, */
    _2 = (object)SEQ_PTR(_find_result_15193);
    _8524 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_8524);
    ((intptr_t*)_2)[1] = _8524;
    _8525 = MAKE_SEQ(_1);
    _8524 = NOVALUE;
    RefDS(_8523);
    RefDS(_opts_15195);
    RefDS(_cmds_15198);
    Ref(_parse_options_15200);
    _4parse_abort(_8523, _8525, _opts_15195, _add_help_rid_15199, _cmds_15198, _parse_options_15200, _help_on_error_15203, _auto_help_15204);
    _8525 = NOVALUE;
    goto L5; // [181] 201
L2: 

    /** cmdline.e:1134				param = find_result[4]*/
    DeRef(_param_15209);
    _2 = (object)SEQ_PTR(_find_result_15193);
    _param_15209 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_param_15209);
    goto L5; // [191] 201
L1: 

    /** cmdline.e:1137			param = find_result[4]*/
    DeRef(_param_15209);
    _2 = (object)SEQ_PTR(_find_result_15193);
    _param_15209 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_param_15209);
L5: 

    /** cmdline.e:1140		if opt[CALLBACK] >= 0 then*/
    _2 = (object)SEQ_PTR(_opt_15206);
    _8528 = (object)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(LESS, _8528, 0)){
        _8528 = NOVALUE;
        goto L7; // [207] 282
    }
    _8528 = NOVALUE;

    /** cmdline.e:1141			integer pos = find_result[1]*/
    _2 = (object)SEQ_PTR(_find_result_15193);
    _pos_15246 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_pos_15246))
    _pos_15246 = (object)DBL_PTR(_pos_15246)->dbl;

    /** cmdline.e:1142			call_count[pos] += 1*/
    _2 = (object)SEQ_PTR(_call_count_15201);
    _8531 = (object)*(((s1_ptr)_2)->base + _pos_15246);
    if (IS_ATOM_INT(_8531)) {
        _8532 = _8531 + 1;
        if (_8532 > MAXINT){
            _8532 = NewDouble((eudouble)_8532);
        }
    }
    else
    _8532 = binary_op(PLUS, 1, _8531);
    _8531 = NOVALUE;
    _2 = (object)SEQ_PTR(_call_count_15201);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _call_count_15201 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pos_15246);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _8532;
    if( _1 != _8532 ){
        DeRef(_1);
    }
    _8532 = NOVALUE;

    /** cmdline.e:1144			if call_func(opt[CALLBACK], {{find_result[1], call_count[pos], param,  find_result[3]}}) = 0 then*/
    _2 = (object)SEQ_PTR(_opt_15206);
    _8533 = (object)*(((s1_ptr)_2)->base + 5);
    _2 = (object)SEQ_PTR(_find_result_15193);
    _8534 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_call_count_15201);
    _8535 = (object)*(((s1_ptr)_2)->base + _pos_15246);
    _2 = (object)SEQ_PTR(_find_result_15193);
    _8536 = (object)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_8534);
    ((intptr_t*)_2)[1] = _8534;
    Ref(_8535);
    ((intptr_t*)_2)[2] = _8535;
    Ref(_param_15209);
    ((intptr_t*)_2)[3] = _param_15209;
    Ref(_8536);
    ((intptr_t*)_2)[4] = _8536;
    _8537 = MAKE_SEQ(_1);
    _8536 = NOVALUE;
    _8535 = NOVALUE;
    _8534 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _8537;
    _8538 = MAKE_SEQ(_1);
    _8537 = NOVALUE;
    _1 = (object)SEQ_PTR(_8538);
    _2 = (object)((s1_ptr)_1)->base;
    _0 = (object)_00[_8533].addr;
    Ref( *(( (intptr_t*)_2) + 1) );
    _1 = (*(intptr_t (*)())_0)(
                        *( ((intptr_t *)_2) + 1)
                         );
    DeRef(_8539);
    _8539 = _1;
    DeRefDS(_8538);
    _8538 = NOVALUE;
    if (binary_op_a(NOTEQ, _8539, 0)){
        DeRef(_8539);
        _8539 = NOVALUE;
        goto L8; // [266] 281
    }
    DeRef(_8539);
    _8539 = NOVALUE;

    /** cmdline.e:1145				return { arg_idx, call_count }*/
    RefDS(_call_count_15201);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _arg_idx_15194;
    ((intptr_t *)_2)[2] = _call_count_15201;
    _8541 = MAKE_SEQ(_1);
    DeRefDS(_find_result_15193);
    DeRefDS(_opts_15195);
    DeRef(_parsed_opts_15197);
    DeRefDS(_cmds_15198);
    DeRefi(_parse_options_15200);
    DeRefDS(_call_count_15201);
    DeRefDS(_opt_15206);
    DeRef(_param_15209);
    DeRef(_8513);
    _8513 = NOVALUE;
    DeRef(_8518);
    _8518 = NOVALUE;
    DeRef(_8520);
    _8520 = NOVALUE;
    DeRef(_8522);
    _8522 = NOVALUE;
    _8533 = NOVALUE;
    _8501 = NOVALUE;
    return _8541;
L8: 
L7: 

    /** cmdline.e:1149		if find_result[3] = 1 then*/
    _2 = (object)SEQ_PTR(_find_result_15193);
    _8542 = (object)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _8542, 1)){
        _8542 = NOVALUE;
        goto L9; // [290] 307
    }
    _8542 = NOVALUE;

    /** cmdline.e:1150			map:remove(parsed_opts, opt[MAPNAME])*/
    _2 = (object)SEQ_PTR(_opt_15206);
    _8544 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_15197);
    Ref(_8544);
    _29remove(_parsed_opts_15197, _8544);
    _8544 = NOVALUE;
    goto LA; // [304] 446
L9: 

    /** cmdline.e:1152			if find(MULTIPLE, opt[OPTIONS]) = 0 then*/
    _2 = (object)SEQ_PTR(_opt_15206);
    _8545 = (object)*(((s1_ptr)_2)->base + 4);
    _8546 = find_from(42, _8545, 1);
    _8545 = NOVALUE;
    if (_8546 != 0)
    goto LB; // [318] 429

    /** cmdline.e:1153				if map:has(parsed_opts, opt[MAPNAME]) and (validation = VALIDATE_ALL or*/
    _2 = (object)SEQ_PTR(_opt_15206);
    _8548 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_15197);
    Ref(_8548);
    _8549 = _29has(_parsed_opts_15197, _8548);
    _8548 = NOVALUE;
    if (IS_ATOM_INT(_8549)) {
        if (_8549 == 0) {
            goto LC; // [333] 410
        }
    }
    else {
        if (DBL_PTR(_8549)->dbl == 0.0) {
            goto LC; // [333] 410
        }
    }
    _8551 = (_validation_15202 == 2);
    if (_8551 != 0) {
        DeRef(_8552);
        _8552 = 1;
        goto LD; // [341] 353
    }
    _8553 = (_validation_15202 == 4);
    _8552 = (_8553 != 0);
LD: 
    if (_8552 == 0)
    {
        _8552 = NOVALUE;
        goto LC; // [354] 410
    }
    else{
        _8552 = NOVALUE;
    }

    /** cmdline.e:1156					if find(HAS_PARAMETER, opt[OPTIONS]) or find(ONCE, opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_opt_15206);
    _8554 = (object)*(((s1_ptr)_2)->base + 4);
    _8555 = find_from(112, _8554, 1);
    _8554 = NOVALUE;
    if (_8555 != 0) {
        goto LE; // [368] 386
    }
    _2 = (object)SEQ_PTR(_opt_15206);
    _8557 = (object)*(((s1_ptr)_2)->base + 4);
    _8558 = find_from(49, _8557, 1);
    _8557 = NOVALUE;
    if (_8558 == 0)
    {
        _8558 = NOVALUE;
        goto LF; // [382] 445
    }
    else{
        _8558 = NOVALUE;
    }
LE: 

    /** cmdline.e:1157						parse_abort( "option '%s' must not occur more than once in the command line.\n\n", */
    _2 = (object)SEQ_PTR(_find_result_15193);
    _8560 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_8560);
    ((intptr_t*)_2)[1] = _8560;
    _8561 = MAKE_SEQ(_1);
    _8560 = NOVALUE;
    RefDS(_8559);
    RefDS(_opts_15195);
    RefDS(_cmds_15198);
    Ref(_parse_options_15200);
    _4parse_abort(_8559, _8561, _opts_15195, _add_help_rid_15199, _cmds_15198, _parse_options_15200, _help_on_error_15203, _auto_help_15204);
    _8561 = NOVALUE;
    goto LF; // [407] 445
LC: 

    /** cmdline.e:1161					map:put(parsed_opts, opt[MAPNAME], param)*/
    _2 = (object)SEQ_PTR(_opt_15206);
    _8562 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_15197);
    Ref(_8562);
    Ref(_param_15209);
    _29put(_parsed_opts_15197, _8562, _param_15209, 1, 0);
    _8562 = NOVALUE;
    goto LF; // [426] 445
LB: 

    /** cmdline.e:1164				map:put(parsed_opts, opt[MAPNAME], param, map_add_operation)*/
    _2 = (object)SEQ_PTR(_opt_15206);
    _8563 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_15197);
    Ref(_8563);
    Ref(_param_15209);
    _29put(_parsed_opts_15197, _8563, _param_15209, _map_add_operation_15205, 0);
    _8563 = NOVALUE;
LF: 
LA: 

    /** cmdline.e:1168		if find(VERSIONING, opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_opt_15206);
    _8564 = (object)*(((s1_ptr)_2)->base + 4);
    _8565 = find_from(118, _8564, 1);
    _8564 = NOVALUE;
    if (_8565 == 0)
    {
        _8565 = NOVALUE;
        goto L10; // [457] 544
    }
    else{
        _8565 = NOVALUE;
    }

    /** cmdline.e:1169			integer ver_pos = find(VERSIONING, opt[OPTIONS]) + 1*/
    _2 = (object)SEQ_PTR(_opt_15206);
    _8566 = (object)*(((s1_ptr)_2)->base + 4);
    _8567 = find_from(118, _8566, 1);
    _8566 = NOVALUE;
    _ver_pos_15292 = _8567 + 1;
    _8567 = NOVALUE;

    /** cmdline.e:1170			if length(opt[OPTIONS]) >= ver_pos then*/
    _2 = (object)SEQ_PTR(_opt_15206);
    _8569 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_8569)){
            _8570 = SEQ_PTR(_8569)->length;
    }
    else {
        _8570 = 1;
    }
    _8569 = NOVALUE;
    if (_8570 < _ver_pos_15292)
    goto L11; // [484] 513

    /** cmdline.e:1171				printf(1, "%s\n", { opt[OPTIONS][ver_pos] })*/
    _2 = (object)SEQ_PTR(_opt_15206);
    _8572 = (object)*(((s1_ptr)_2)->base + 4);
    _2 = (object)SEQ_PTR(_8572);
    _8573 = (object)*(((s1_ptr)_2)->base + _ver_pos_15292);
    _8572 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_8573);
    ((intptr_t*)_2)[1] = _8573;
    _8574 = MAKE_SEQ(_1);
    _8573 = NOVALUE;
    EPrintf(1, _8103, _8574);
    DeRefDS(_8574);
    _8574 = NOVALUE;

    /** cmdline.e:1172				abort(0)*/
    UserCleanup(0);
    goto L12; // [510] 543
L11: 

    /** cmdline.e:1174				error:crash("help options are incorrect,\n" &*/
    Concat((object_ptr)&_8577, _8575, _8576);
    DeRefi(_fmt_inlined_crash_at_521_15308);
    _fmt_inlined_crash_at_521_15308 = _8577;
    _8577 = NOVALUE;

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_524_15309);
    _msg_inlined_crash_at_524_15309 = EPrintf(-9999999, _fmt_inlined_crash_at_521_15308, _5);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_524_15309);

    /** error.e:53	end procedure*/
    goto L13; // [537] 540
L13: 
    DeRefi(_fmt_inlined_crash_at_521_15308);
    _fmt_inlined_crash_at_521_15308 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_524_15309);
    _msg_inlined_crash_at_524_15309 = NOVALUE;
L12: 
L10: 

    /** cmdline.e:1178		return {arg_idx, call_count}*/
    RefDS(_call_count_15201);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _arg_idx_15194;
    ((intptr_t *)_2)[2] = _call_count_15201;
    _8578 = MAKE_SEQ(_1);
    DeRefDS(_find_result_15193);
    DeRefDS(_opts_15195);
    DeRef(_parsed_opts_15197);
    DeRefDS(_cmds_15198);
    DeRefi(_parse_options_15200);
    DeRefDS(_call_count_15201);
    DeRef(_opt_15206);
    DeRef(_param_15209);
    DeRef(_8513);
    _8513 = NOVALUE;
    DeRef(_8518);
    _8518 = NOVALUE;
    DeRef(_8520);
    _8520 = NOVALUE;
    _8569 = NOVALUE;
    DeRef(_8541);
    _8541 = NOVALUE;
    DeRef(_8549);
    _8549 = NOVALUE;
    DeRef(_8522);
    _8522 = NOVALUE;
    DeRef(_8551);
    _8551 = NOVALUE;
    DeRef(_8553);
    _8553 = NOVALUE;
    _8533 = NOVALUE;
    _8501 = NOVALUE;
    return _8578;
    ;
}


object _4cmd_parse(object _opts_15313, object _parse_options_15314, object _cmds_15315)
{
    object _cmd_15317 = NOVALUE;
    object _help_opts_15318 = NOVALUE;
    object _call_count_15319 = NOVALUE;
    object _add_help_rid_15320 = NOVALUE;
    object _validation_15321 = NOVALUE;
    object _has_extra_15322 = NOVALUE;
    object _use_at_15323 = NOVALUE;
    object _auto_help_15324 = NOVALUE;
    object _help_on_error_15325 = NOVALUE;
    object _po_15326 = NOVALUE;
    object _msg_inlined_crash_at_161_15350 = NOVALUE;
    object _msg_inlined_crash_at_225_15361 = NOVALUE;
    object _msg_inlined_crash_at_263_15368 = NOVALUE;
    object _fmt_inlined_crash_at_260_15367 = NOVALUE;
    object _parsed_opts_15373 = NOVALUE;
    object _new_1__tmp_at315_15376 = NOVALUE;
    object _new_inlined_new_at_315_15375 = NOVALUE;
    object _cmds_ok_15378 = NOVALUE;
    object _8605 = NOVALUE;
    object _8601 = NOVALUE;
    object _8598 = NOVALUE;
    object _8597 = NOVALUE;
    object _8591 = NOVALUE;
    object _8587 = NOVALUE;
    object _8584 = NOVALUE;
    object _8582 = NOVALUE;
    object _8580 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:1428		object add_help_rid = -1*/
    _add_help_rid_15320 = -1;

    /** cmdline.e:1429		integer validation = VALIDATE_ALL*/
    _validation_15321 = 2;

    /** cmdline.e:1430		integer has_extra = 0*/
    _has_extra_15322 = 0;

    /** cmdline.e:1431		integer use_at = 1*/
    _use_at_15323 = 1;

    /** cmdline.e:1432		integer auto_help = 1*/
    _auto_help_15324 = 1;

    /** cmdline.e:1433		integer help_on_error = 1*/
    _help_on_error_15325 = 1;

    /** cmdline.e:1435		integer po = 1*/
    _po_15326 = 1;

    /** cmdline.e:1436		if atom(parse_options) then*/
    _8580 = 1;
    if (_8580 == 0)
    {
        _8580 = NOVALUE;
        goto L1; // [45] 55
    }
    else{
        _8580 = NOVALUE;
    }

    /** cmdline.e:1437			parse_options = {parse_options}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 10;
    _parse_options_15314 = MAKE_SEQ(_1);
L1: 

    /** cmdline.e:1441		while po <= length(parse_options) do*/
L2: 
    _8582 = 1;
    if (_po_15326 > 1)
    goto L3; // [63] 296

    /** cmdline.e:1442			switch parse_options[po] do*/
    _2 = (object)SEQ_PTR(_parse_options_15314);
    _8584 = (object)*(((s1_ptr)_2)->base + _po_15326);
    _0 = _8584;
    _8584 = NOVALUE;
    switch ( _0 ){ 

        /** cmdline.e:1444				case NO_HELP then                         auto_help = 0*/
        case 9:
        _auto_help_15324 = 0;
        goto L4; // [85] 285

        /** cmdline.e:1445				case VALIDATE_ALL then                    validation = VALIDATE_ALL*/
        case 2:
        _validation_15321 = 2;
        goto L4; // [94] 285

        /** cmdline.e:1446				case NO_VALIDATION then                   validation = NO_VALIDATION*/
        case 3:
        _validation_15321 = 3;
        goto L4; // [103] 285

        /** cmdline.e:1447				case NO_VALIDATION_AFTER_FIRST_EXTRA then validation = NO_VALIDATION_AFTER_FIRST_EXTRA*/
        case 4:
        _validation_15321 = 4;
        goto L4; // [112] 285

        /** cmdline.e:1448				case NO_AT_EXPANSION then                 use_at = 0*/
        case 7:
        _use_at_15323 = 0;
        goto L4; // [121] 285

        /** cmdline.e:1449				case AT_EXPANSION then                    use_at = 1*/
        case 6:
        _use_at_15323 = 1;
        goto L4; // [130] 285

        /** cmdline.e:1451				case HELP_RID then*/
        case 1:

        /** cmdline.e:1452					if po < length(parse_options) then*/
        _8587 = 1;
        if (_po_15326 >= 1)
        goto L5; // [141] 160

        /** cmdline.e:1453						po += 1*/
        _po_15326 = _po_15326 + 1;

        /** cmdline.e:1454						add_help_rid = parse_options[po]*/
        _2 = (object)SEQ_PTR(_parse_options_15314);
        _add_help_rid_15320 = (object)*(((s1_ptr)_2)->base + _po_15326);
        goto L4; // [157] 285
L5: 

        /** cmdline.e:1456						error:crash("HELP_RID was given to cmd_parse with no routine_id")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_161_15350);
        _msg_inlined_crash_at_161_15350 = EPrintf(-9999999, _8138, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_161_15350);

        /** error.e:53	end procedure*/
        goto L6; // [175] 178
L6: 
        DeRefi(_msg_inlined_crash_at_161_15350);
        _msg_inlined_crash_at_161_15350 = NOVALUE;
        goto L4; // [181] 285

        /** cmdline.e:1459				case NO_HELP_ON_ERROR then*/
        case 10:

        /** cmdline.e:1461					help_on_error = 0*/
        _help_on_error_15325 = 0;
        goto L4; // [192] 285

        /** cmdline.e:1463				case PAUSE_MSG then*/
        case 8:

        /** cmdline.e:1464					if po < length(parse_options) then*/
        _8591 = 1;
        if (_po_15326 >= 1)
        goto L7; // [203] 224

        /** cmdline.e:1465						po += 1*/
        _po_15326 = _po_15326 + 1;

        /** cmdline.e:1466						pause_msg = parse_options[po]*/
        DeRef(_4pause_msg_14187);
        _2 = (object)SEQ_PTR(_parse_options_15314);
        _4pause_msg_14187 = (object)*(((s1_ptr)_2)->base + _po_15326);
        goto L4; // [221] 285
L7: 

        /** cmdline.e:1468						error:crash("PAUSE_MSG was given to cmd_parse with no actual message text")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_225_15361);
        _msg_inlined_crash_at_225_15361 = EPrintf(-9999999, _8595, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_225_15361);

        /** error.e:53	end procedure*/
        goto L8; // [239] 242
L8: 
        DeRefi(_msg_inlined_crash_at_225_15361);
        _msg_inlined_crash_at_225_15361 = NOVALUE;
        goto L4; // [245] 285

        /** cmdline.e:1471				case else*/
        default:

        /** cmdline.e:1472					error:crash(sprintf("Unrecognised cmdline PARSE OPTION - %d", parse_options[po]) )*/
        _2 = (object)SEQ_PTR(_parse_options_15314);
        _8597 = (object)*(((s1_ptr)_2)->base + _po_15326);
        _8598 = EPrintf(-9999999, _8596, _8597);
        _8597 = NOVALUE;
        DeRefi(_fmt_inlined_crash_at_260_15367);
        _fmt_inlined_crash_at_260_15367 = _8598;
        _8598 = NOVALUE;

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_263_15368);
        _msg_inlined_crash_at_263_15368 = EPrintf(-9999999, _fmt_inlined_crash_at_260_15367, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_263_15368);

        /** error.e:53	end procedure*/
        goto L9; // [279] 282
L9: 
        DeRefi(_fmt_inlined_crash_at_260_15367);
        _fmt_inlined_crash_at_260_15367 = NOVALUE;
        DeRefi(_msg_inlined_crash_at_263_15368);
        _msg_inlined_crash_at_263_15368 = NOVALUE;
    ;}L4: 

    /** cmdline.e:1475			po += 1*/
    _po_15326 = _po_15326 + 1;

    /** cmdline.e:1476		end while*/
    goto L2; // [293] 60
L3: 

    /** cmdline.e:1478		opts = standardize_opts(opts, auto_help)*/
    RefDS(_opts_15313);
    _0 = _opts_15313;
    _opts_15313 = _4standardize_opts(_opts_15313, _auto_help_15324);
    DeRefDS(_0);

    /** cmdline.e:1479		call_count = repeat(0, length(opts))*/
    if (IS_SEQUENCE(_opts_15313)){
            _8601 = SEQ_PTR(_opts_15313)->length;
    }
    else {
        _8601 = 1;
    }
    DeRef(_call_count_15319);
    _call_count_15319 = Repeat(0, _8601);
    _8601 = NOVALUE;

    /** cmdline.e:1481		map:map parsed_opts = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at315_15376;
    _new_1__tmp_at315_15376 = _29new_map_seq(8);
    DeRef(_0);
    Ref(_new_1__tmp_at315_15376);
    _0 = _parsed_opts_15373;
    _parsed_opts_15373 = _30malloc(_new_1__tmp_at315_15376, 1);
    DeRef(_0);
    DeRef(_new_1__tmp_at315_15376);
    _new_1__tmp_at315_15376 = NOVALUE;

    /** cmdline.e:1482		map:put(parsed_opts, EXTRAS, {})*/
    Ref(_parsed_opts_15373);
    RefDS(_4EXTRAS_14176);
    RefDS(_5);
    _29put(_parsed_opts_15373, _4EXTRAS_14176, _5, 1, 0);

    /** cmdline.e:1485		help_opts = get_help_options( opts )*/
    RefDS(_opts_15313);
    _0 = _help_opts_15318;
    _help_opts_15318 = _4get_help_options(_opts_15313);
    DeRef(_0);

    /** cmdline.e:1487		object cmds_ok = parse_commands( cmds, opts, parsed_opts, help_opts, add_help_rid, parse_options, */
    RefDS(_cmds_15315);
    RefDS(_opts_15313);
    Ref(_parsed_opts_15373);
    RefDS(_help_opts_15318);
    Ref(_parse_options_15314);
    RefDS(_call_count_15319);
    _0 = _cmds_ok_15378;
    _cmds_ok_15378 = _4parse_commands(_cmds_15315, _opts_15313, _parsed_opts_15373, _help_opts_15318, _add_help_rid_15320, _parse_options_15314, _use_at_15323, _validation_15321, _has_extra_15322, _call_count_15319, _help_on_error_15325, _auto_help_15324);
    DeRef(_0);

    /** cmdline.e:1489		if atom( cmds_ok ) then*/
    _8605 = IS_ATOM(_cmds_ok_15378);
    if (_8605 == 0)
    {
        _8605 = NOVALUE;
        goto LA; // [371] 381
    }
    else{
        _8605 = NOVALUE;
    }

    /** cmdline.e:1490			return 0*/
    DeRefDS(_opts_15313);
    DeRefi(_parse_options_15314);
    DeRefDS(_cmds_15315);
    DeRefDS(_help_opts_15318);
    DeRefDS(_call_count_15319);
    DeRef(_parsed_opts_15373);
    DeRef(_cmds_ok_15378);
    return 0;
LA: 

    /** cmdline.e:1492		cmds       = cmds_ok[1]*/
    DeRefDS(_cmds_15315);
    _2 = (object)SEQ_PTR(_cmds_ok_15378);
    _cmds_15315 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_cmds_15315);

    /** cmdline.e:1493		call_count = cmds_ok[2]*/
    DeRef(_call_count_15319);
    _2 = (object)SEQ_PTR(_cmds_ok_15378);
    _call_count_15319 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_call_count_15319);

    /** cmdline.e:1496		check_mandatory( opts, parsed_opts, add_help_rid, cmds, parse_options, help_on_error, auto_help )*/
    RefDS(_opts_15313);
    Ref(_parsed_opts_15373);
    RefDS(_cmds_15315);
    Ref(_parse_options_15314);
    _4check_mandatory(_opts_15313, _parsed_opts_15373, _add_help_rid_15320, _cmds_15315, _parse_options_15314, _help_on_error_15325, _auto_help_15324);

    /** cmdline.e:1498		return parsed_opts*/
    DeRefDS(_opts_15313);
    DeRefi(_parse_options_15314);
    DeRefDS(_cmds_15315);
    DeRef(_help_opts_15318);
    DeRefDS(_call_count_15319);
    DeRef(_cmds_ok_15378);
    return _parsed_opts_15373;
    ;
}


object _4build_commandline(object _cmds_15386)
{
    object _8610 = NOVALUE;
    object _8609 = NOVALUE;
    object _8608 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:1551		return stdseq:flatten( text:quote( cmds,,'\\'," " ), " ")*/
    RefDS(_4852);
    RefDS(_4852);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _4852;
    ((intptr_t *)_2)[2] = _4852;
    _8608 = MAKE_SEQ(_1);
    RefDS(_cmds_15386);
    RefDS(_2676);
    _8609 = _14quote(_cmds_15386, _8608, 92, _2676);
    _8608 = NOVALUE;
    RefDS(_2676);
    _8610 = _23flatten(_8609, _2676);
    _8609 = NOVALUE;
    DeRefDS(_cmds_15386);
    return _8610;
    ;
}



// 0xDE6D6CCE
