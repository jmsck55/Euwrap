// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _36set_target_integer_size(object _sizeof_pointer_21282)
{
    object _12051 = NOVALUE;
    object _0, _1, _2;
    

    /** global.e:297		if sizeof_pointer = 4 then*/
    if (_sizeof_pointer_21282 != 4)
    goto L1; // [5] 17

    /** global.e:298			TMAXINT = max_int32*/
    DeRef(_36TMAXINT_21276);
    _36TMAXINT_21276 = 1073741823;
    goto L2; // [14] 25
L1: 

    /** global.e:300			TMAXINT = max_int64*/
    Ref(_36max_int64_21265);
    DeRef(_36TMAXINT_21276);
    _36TMAXINT_21276 = _36max_int64_21265;
L2: 

    /** global.e:303		TMININT = -TMAXINT - 1*/
    if (IS_ATOM_INT(_36TMAXINT_21276)) {
        if ((uintptr_t)_36TMAXINT_21276 == (uintptr_t)HIGH_BITS){
            _12051 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _12051 = - _36TMAXINT_21276;
        }
    }
    else {
        _12051 = unary_op(UMINUS, _36TMAXINT_21276);
    }
    DeRef(_36TMININT_21277);
    if (IS_ATOM_INT(_12051)) {
        _36TMININT_21277 = _12051 - 1;
        if ((object)((uintptr_t)_36TMININT_21277 +(uintptr_t) HIGH_BITS) >= 0){
            _36TMININT_21277 = NewDouble((eudouble)_36TMININT_21277);
        }
    }
    else {
        _36TMININT_21277 = NewDouble(DBL_PTR(_12051)->dbl - (eudouble)1);
    }
    DeRef(_12051);
    _12051 = NOVALUE;

    /** global.e:304		TMAXINT_DBL = TMAXINT*/
    Ref(_36TMAXINT_21276);
    DeRef(_36TMAXINT_DBL_21279);
    _36TMAXINT_DBL_21279 = _36TMAXINT_21276;

    /** global.e:305		TMININT_DBL = TMININT*/
    Ref(_36TMININT_21277);
    DeRef(_36TMININT_DBL_21278);
    _36TMININT_DBL_21278 = _36TMININT_21277;

    /** global.e:306	end procedure*/
    return;
    ;
}


object _36is_integer(object _o_21290)
{
    object _12059 = NOVALUE;
    object _12058 = NOVALUE;
    object _12057 = NOVALUE;
    object _12055 = NOVALUE;
    object _12053 = NOVALUE;
    object _0, _1, _2;
    

    /** global.e:310		if not atom( o ) then*/
    _12053 = IS_ATOM(_o_21290);
    if (_12053 != 0)
    goto L1; // [6] 16
    _12053 = NOVALUE;

    /** global.e:311			return 0*/
    DeRef(_o_21290);
    return 0;
L1: 

    /** global.e:314		if o = floor( o ) then*/
    if (IS_ATOM_INT(_o_21290))
    _12055 = e_floor(_o_21290);
    else
    _12055 = unary_op(FLOOR, _o_21290);
    if (binary_op_a(NOTEQ, _o_21290, _12055)){
        DeRef(_12055);
        _12055 = NOVALUE;
        goto L2; // [21] 55
    }
    DeRef(_12055);
    _12055 = NOVALUE;

    /** global.e:315			if o <= TMAXINT and o >= TMININT then*/
    if (IS_ATOM_INT(_o_21290) && IS_ATOM_INT(_36TMAXINT_21276)) {
        _12057 = (_o_21290 <= _36TMAXINT_21276);
    }
    else {
        _12057 = binary_op(LESSEQ, _o_21290, _36TMAXINT_21276);
    }
    if (IS_ATOM_INT(_12057)) {
        if (_12057 == 0) {
            goto L3; // [33] 54
        }
    }
    else {
        if (DBL_PTR(_12057)->dbl == 0.0) {
            goto L3; // [33] 54
        }
    }
    if (IS_ATOM_INT(_o_21290) && IS_ATOM_INT(_36TMININT_21277)) {
        _12059 = (_o_21290 >= _36TMININT_21277);
    }
    else {
        _12059 = binary_op(GREATEREQ, _o_21290, _36TMININT_21277);
    }
    if (_12059 == 0) {
        DeRef(_12059);
        _12059 = NOVALUE;
        goto L3; // [44] 54
    }
    else {
        if (!IS_ATOM_INT(_12059) && DBL_PTR(_12059)->dbl == 0.0){
            DeRef(_12059);
            _12059 = NOVALUE;
            goto L3; // [44] 54
        }
        DeRef(_12059);
        _12059 = NOVALUE;
    }
    DeRef(_12059);
    _12059 = NOVALUE;

    /** global.e:316				return 1*/
    DeRef(_o_21290);
    DeRef(_12057);
    _12057 = NOVALUE;
    return 1;
L3: 
L2: 

    /** global.e:319		return 0*/
    DeRef(_o_21290);
    DeRef(_12057);
    _12057 = NOVALUE;
    return 0;
    ;
}


object _36symtab_index(object _x_21314)
{
    object _12075 = NOVALUE;
    object _12074 = NOVALUE;
    object _12073 = NOVALUE;
    object _12072 = NOVALUE;
    object _12071 = NOVALUE;
    object _12070 = NOVALUE;
    object _12068 = NOVALUE;
    object _0, _1, _2;
    

    /** global.e:337		if x = 0 then*/
    if (_x_21314 != 0)
    goto L1; // [5] 18

    /** global.e:338			return TRUE -- NULL value*/
    return _13TRUE_452;
L1: 

    /** global.e:340		if x < 0 or x > length(SymTab) then*/
    _12068 = (_x_21314 < 0);
    if (_12068 != 0) {
        goto L2; // [24] 42
    }
    if (IS_SEQUENCE(_37SymTab_15406)){
            _12070 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _12070 = 1;
    }
    _12071 = (_x_21314 > _12070);
    _12070 = NOVALUE;
    if (_12071 == 0)
    {
        DeRef(_12071);
        _12071 = NOVALUE;
        goto L3; // [38] 51
    }
    else{
        DeRef(_12071);
        _12071 = NOVALUE;
    }
L2: 

    /** global.e:341			return FALSE*/
    DeRef(_12068);
    _12068 = NOVALUE;
    return _13FALSE_450;
L3: 

    /** global.e:343		return find(length(SymTab[x]), {SIZEOF_VAR_ENTRY, SIZEOF_ROUTINE_ENTRY,*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _12072 = (object)*(((s1_ptr)_2)->base + _x_21314);
    if (IS_SEQUENCE(_12072)){
            _12073 = SEQ_PTR(_12072)->length;
    }
    else {
        _12073 = 1;
    }
    _12072 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _36SIZEOF_VAR_ENTRY_21213;
    ((intptr_t*)_2)[2] = _36SIZEOF_ROUTINE_ENTRY_21210;
    ((intptr_t*)_2)[3] = _36SIZEOF_TEMP_ENTRY_21219;
    ((intptr_t*)_2)[4] = _36SIZEOF_BLOCK_ENTRY_21216;
    _12074 = MAKE_SEQ(_1);
    _12075 = find_from(_12073, _12074, 1);
    _12073 = NOVALUE;
    DeRefDS(_12074);
    _12074 = NOVALUE;
    _12072 = NOVALUE;
    DeRef(_12068);
    _12068 = NOVALUE;
    return _12075;
    ;
}



// 0xE2B27F79
