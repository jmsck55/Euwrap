// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _58get_eucompiledir()
{
    object _x_42585 = NOVALUE;
    object _22369 = NOVALUE;
    object _22367 = NOVALUE;
    object _22364 = NOVALUE;
    object _22362 = NOVALUE;
    object _22360 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:133		object x = getenv("EUCOMPILEDIR")*/
    DeRef(_x_42585);
    _x_42585 = EGetEnv(_22358);

    /** c_decl.e:134		if is_eudir_from_cmdline() then*/
    _22360 = _37is_eudir_from_cmdline();
    if (_22360 == 0) {
        DeRef(_22360);
        _22360 = NOVALUE;
        goto L1; // [11] 20
    }
    else {
        if (!IS_ATOM_INT(_22360) && DBL_PTR(_22360)->dbl == 0.0){
            DeRef(_22360);
            _22360 = NOVALUE;
            goto L1; // [11] 20
        }
        DeRef(_22360);
        _22360 = NOVALUE;
    }
    DeRef(_22360);
    _22360 = NOVALUE;

    /** c_decl.e:135			x = get_eudir()*/
    _0 = _x_42585;
    _x_42585 = _37get_eudir();
    DeRefi(_0);
L1: 

    /** c_decl.e:138		ifdef UNIX then*/

    /** c_decl.e:139			if equal(x, -1) then*/
    if (_x_42585 == -1)
    _22362 = 1;
    else if (IS_ATOM_INT(_x_42585) && IS_ATOM_INT(-1))
    _22362 = 0;
    else
    _22362 = (compare(_x_42585, -1) == 0);
    if (_22362 == 0)
    {
        _22362 = NOVALUE;
        goto L2; // [28] 67
    }
    else{
        _22362 = NOVALUE;
    }

    /** c_decl.e:140				x = "/usr/local/share/euphoria"*/
    RefDS(_22363);
    DeRef(_x_42585);
    _x_42585 = _22363;

    /** c_decl.e:141				if not file_exists( x ) then*/
    RefDS(_x_42585);
    _22364 = _17file_exists(_x_42585);
    if (IS_ATOM_INT(_22364)) {
        if (_22364 != 0){
            DeRef(_22364);
            _22364 = NOVALUE;
            goto L3; // [42] 66
        }
    }
    else {
        if (DBL_PTR(_22364)->dbl != 0.0){
            DeRef(_22364);
            _22364 = NOVALUE;
            goto L3; // [42] 66
        }
    }
    DeRef(_22364);
    _22364 = NOVALUE;

    /** c_decl.e:144					x = "/usr/share/euphoria"*/
    RefDS(_22366);
    DeRefDSi(_x_42585);
    _x_42585 = _22366;

    /** c_decl.e:145					if not file_exists( x ) then*/
    RefDS(_x_42585);
    _22367 = _17file_exists(_x_42585);
    if (IS_ATOM_INT(_22367)) {
        if (_22367 != 0){
            DeRef(_22367);
            _22367 = NOVALUE;
            goto L4; // [56] 65
        }
    }
    else {
        if (DBL_PTR(_22367)->dbl != 0.0){
            DeRef(_22367);
            _22367 = NOVALUE;
            goto L4; // [56] 65
        }
    }
    DeRef(_22367);
    _22367 = NOVALUE;

    /** c_decl.e:146						x = -1*/
    DeRefDSi(_x_42585);
    _x_42585 = -1;
L4: 
L3: 
L2: 

    /** c_decl.e:152		if equal(x, -1) then*/
    if (_x_42585 == -1)
    _22369 = 1;
    else if (IS_ATOM_INT(_x_42585) && IS_ATOM_INT(-1))
    _22369 = 0;
    else
    _22369 = (compare(_x_42585, -1) == 0);
    if (_22369 == 0)
    {
        _22369 = NOVALUE;
        goto L5; // [73] 82
    }
    else{
        _22369 = NOVALUE;
    }

    /** c_decl.e:153			x = get_eudir()*/
    _0 = _x_42585;
    _x_42585 = _37get_eudir();
    DeRef(_0);
L5: 

    /** c_decl.e:156		return x*/
    return _x_42585;
    ;
}


void _58NewBB(object _a_call_42611, object _mask_42612, object _sub_42614)
{
    object _s_42616 = NOVALUE;
    object _22402 = NOVALUE;
    object _22401 = NOVALUE;
    object _22399 = NOVALUE;
    object _22398 = NOVALUE;
    object _22396 = NOVALUE;
    object _22395 = NOVALUE;
    object _22394 = NOVALUE;
    object _22393 = NOVALUE;
    object _22392 = NOVALUE;
    object _22391 = NOVALUE;
    object _22390 = NOVALUE;
    object _22389 = NOVALUE;
    object _22388 = NOVALUE;
    object _22387 = NOVALUE;
    object _22386 = NOVALUE;
    object _22385 = NOVALUE;
    object _22384 = NOVALUE;
    object _22383 = NOVALUE;
    object _22382 = NOVALUE;
    object _22381 = NOVALUE;
    object _22380 = NOVALUE;
    object _22379 = NOVALUE;
    object _22378 = NOVALUE;
    object _22377 = NOVALUE;
    object _22376 = NOVALUE;
    object _22375 = NOVALUE;
    object _22374 = NOVALUE;
    object _22372 = NOVALUE;
    object _22371 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_mask_42612)) {
        _1 = (object)(DBL_PTR(_mask_42612)->dbl);
        DeRefDS(_mask_42612);
        _mask_42612 = _1;
    }

    /** c_decl.e:166		if a_call then*/
    if (_a_call_42611 == 0)
    {
        goto L1; // [9] 252
    }
    else{
    }

    /** c_decl.e:169			for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_58BB_info_42563)){
            _22371 = SEQ_PTR(_58BB_info_42563)->length;
    }
    else {
        _22371 = 1;
    }
    {
        object _i_42619;
        _i_42619 = 1;
L2: 
        if (_i_42619 > _22371){
            goto L3; // [19] 249
        }

        /** c_decl.e:170				s = BB_info[i][BB_VAR]*/
        _2 = (object)SEQ_PTR(_58BB_info_42563);
        _22372 = (object)*(((s1_ptr)_2)->base + _i_42619);
        _2 = (object)SEQ_PTR(_22372);
        _s_42616 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_s_42616)){
            _s_42616 = (object)DBL_PTR(_s_42616)->dbl;
        }
        _22372 = NOVALUE;

        /** c_decl.e:171				if SymTab[s][S_MODE] = M_NORMAL and*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _22374 = (object)*(((s1_ptr)_2)->base + _s_42616);
        _2 = (object)SEQ_PTR(_22374);
        _22375 = (object)*(((s1_ptr)_2)->base + 3);
        _22374 = NOVALUE;
        if (IS_ATOM_INT(_22375)) {
            _22376 = (_22375 == 1);
        }
        else {
            _22376 = binary_op(EQUALS, _22375, 1);
        }
        _22375 = NOVALUE;
        if (IS_ATOM_INT(_22376)) {
            if (_22376 == 0) {
                goto L4; // [60] 242
            }
        }
        else {
            if (DBL_PTR(_22376)->dbl == 0.0) {
                goto L4; // [60] 242
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _22378 = (object)*(((s1_ptr)_2)->base + _s_42616);
        _2 = (object)SEQ_PTR(_22378);
        _22379 = (object)*(((s1_ptr)_2)->base + 4);
        _22378 = NOVALUE;
        if (IS_ATOM_INT(_22379)) {
            _22380 = (_22379 == 6);
        }
        else {
            _22380 = binary_op(EQUALS, _22379, 6);
        }
        _22379 = NOVALUE;
        if (IS_ATOM_INT(_22380)) {
            if (_22380 != 0) {
                DeRef(_22381);
                _22381 = 1;
                goto L5; // [82] 108
            }
        }
        else {
            if (DBL_PTR(_22380)->dbl != 0.0) {
                DeRef(_22381);
                _22381 = 1;
                goto L5; // [82] 108
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _22382 = (object)*(((s1_ptr)_2)->base + _s_42616);
        _2 = (object)SEQ_PTR(_22382);
        _22383 = (object)*(((s1_ptr)_2)->base + 4);
        _22382 = NOVALUE;
        if (IS_ATOM_INT(_22383)) {
            _22384 = (_22383 == 5);
        }
        else {
            _22384 = binary_op(EQUALS, _22383, 5);
        }
        _22383 = NOVALUE;
        DeRef(_22381);
        if (IS_ATOM_INT(_22384))
        _22381 = (_22384 != 0);
        else
        _22381 = DBL_PTR(_22384)->dbl != 0.0;
L5: 
        if (_22381 != 0) {
            _22385 = 1;
            goto L6; // [108] 134
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _22386 = (object)*(((s1_ptr)_2)->base + _s_42616);
        _2 = (object)SEQ_PTR(_22386);
        _22387 = (object)*(((s1_ptr)_2)->base + 4);
        _22386 = NOVALUE;
        if (IS_ATOM_INT(_22387)) {
            _22388 = (_22387 == 11);
        }
        else {
            _22388 = binary_op(EQUALS, _22387, 11);
        }
        _22387 = NOVALUE;
        if (IS_ATOM_INT(_22388))
        _22385 = (_22388 != 0);
        else
        _22385 = DBL_PTR(_22388)->dbl != 0.0;
L6: 
        if (_22385 != 0) {
            DeRef(_22389);
            _22389 = 1;
            goto L7; // [134] 160
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _22390 = (object)*(((s1_ptr)_2)->base + _s_42616);
        _2 = (object)SEQ_PTR(_22390);
        _22391 = (object)*(((s1_ptr)_2)->base + 4);
        _22390 = NOVALUE;
        if (IS_ATOM_INT(_22391)) {
            _22392 = (_22391 == 13);
        }
        else {
            _22392 = binary_op(EQUALS, _22391, 13);
        }
        _22391 = NOVALUE;
        if (IS_ATOM_INT(_22392))
        _22389 = (_22392 != 0);
        else
        _22389 = DBL_PTR(_22392)->dbl != 0.0;
L7: 
        if (_22389 == 0)
        {
            _22389 = NOVALUE;
            goto L4; // [161] 242
        }
        else{
            _22389 = NOVALUE;
        }

        /** c_decl.e:176					  if and_bits(mask, power(2, remainder(s, E_SIZE))) then*/
        _22393 = (_s_42616 % 29);
        _22394 = power(2, _22393);
        _22393 = NOVALUE;
        if (IS_ATOM_INT(_22394)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_mask_42612 & (uintptr_t)_22394;
                 _22395 = MAKE_UINT(tu);
            }
        }
        else {
            temp_d.dbl = (eudouble)_mask_42612;
            _22395 = Dand_bits(&temp_d, DBL_PTR(_22394));
        }
        DeRef(_22394);
        _22394 = NOVALUE;
        if (_22395 == 0) {
            DeRef(_22395);
            _22395 = NOVALUE;
            goto L8; // [180] 241
        }
        else {
            if (!IS_ATOM_INT(_22395) && DBL_PTR(_22395)->dbl == 0.0){
                DeRef(_22395);
                _22395 = NOVALUE;
                goto L8; // [180] 241
            }
            DeRef(_22395);
            _22395 = NOVALUE;
        }
        DeRef(_22395);
        _22395 = NOVALUE;

        /** c_decl.e:177						  if mask = E_ALL_EFFECT or s < sub then*/
        _22396 = (_mask_42612 == 1073741823);
        if (_22396 != 0) {
            goto L9; // [191] 204
        }
        _22398 = (_s_42616 < _sub_42614);
        if (_22398 == 0)
        {
            DeRef(_22398);
            _22398 = NOVALUE;
            goto LA; // [200] 240
        }
        else{
            DeRef(_22398);
            _22398 = NOVALUE;
        }
L9: 

        /** c_decl.e:178							  BB_info[i][BB_TYPE..BB_OBJ] =*/
        _2 = (object)SEQ_PTR(_58BB_info_42563);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _58BB_info_42563 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_42619 + ((s1_ptr)_2)->base);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -1073741824;
        ((intptr_t *)_2)[2] = 1073741823;
        _22401 = MAKE_SEQ(_1);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 0;
        ((intptr_t*)_2)[2] = 0;
        Ref(_36NOVALUE_21301);
        ((intptr_t*)_2)[3] = _36NOVALUE_21301;
        ((intptr_t*)_2)[4] = _22401;
        _22402 = MAKE_SEQ(_1);
        _22401 = NOVALUE;
        assign_slice_seq = (s1_ptr *)_3;
        AssignSlice(2, 5, _22402);
        DeRefDS(_22402);
        _22402 = NOVALUE;
LA: 
L8: 
L4: 

        /** c_decl.e:183			end for*/
        _i_42619 = _i_42619 + 1;
        goto L2; // [244] 26
L3: 
        ;
    }
    goto LB; // [249] 260
L1: 

    /** c_decl.e:186			BB_info = {}*/
    RefDS(_21997);
    DeRef(_58BB_info_42563);
    _58BB_info_42563 = _21997;
LB: 

    /** c_decl.e:188	end procedure*/
    DeRef(_22388);
    _22388 = NOVALUE;
    DeRef(_22399);
    _22399 = NOVALUE;
    DeRef(_22376);
    _22376 = NOVALUE;
    DeRef(_22396);
    _22396 = NOVALUE;
    DeRef(_22384);
    _22384 = NOVALUE;
    DeRef(_22392);
    _22392 = NOVALUE;
    DeRef(_22380);
    _22380 = NOVALUE;
    return;
    ;
}


object _58BB_var_obj(object _var_42684)
{
    object _bbi_42685 = NOVALUE;
    object _22413 = NOVALUE;
    object _22411 = NOVALUE;
    object _22409 = NOVALUE;
    object _22408 = NOVALUE;
    object _22406 = NOVALUE;
    object _22404 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:196		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_58BB_info_42563)){
            _22404 = SEQ_PTR(_58BB_info_42563)->length;
    }
    else {
        _22404 = 1;
    }
    {
        object _i_42687;
        _i_42687 = _22404;
L1: 
        if (_i_42687 < 1){
            goto L2; // [10] 99
        }

        /** c_decl.e:197			bbi = BB_info[i]*/
        DeRef(_bbi_42685);
        _2 = (object)SEQ_PTR(_58BB_info_42563);
        _bbi_42685 = (object)*(((s1_ptr)_2)->base + _i_42687);
        Ref(_bbi_42685);

        /** c_decl.e:198			if bbi[BB_VAR] != var then*/
        _2 = (object)SEQ_PTR(_bbi_42685);
        _22406 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(EQUALS, _22406, _var_42684)){
            _22406 = NOVALUE;
            goto L3; // [31] 40
        }
        _22406 = NOVALUE;

        /** c_decl.e:199				continue*/
        goto L4; // [37] 94
L3: 

        /** c_decl.e:202			if SymTab[var][S_MODE] != M_NORMAL then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _22408 = (object)*(((s1_ptr)_2)->base + _var_42684);
        _2 = (object)SEQ_PTR(_22408);
        _22409 = (object)*(((s1_ptr)_2)->base + 3);
        _22408 = NOVALUE;
        if (binary_op_a(EQUALS, _22409, 1)){
            _22409 = NOVALUE;
            goto L5; // [56] 65
        }
        _22409 = NOVALUE;

        /** c_decl.e:203				continue*/
        goto L4; // [62] 94
L5: 

        /** c_decl.e:206			if bbi[BB_TYPE] != TYPE_INTEGER then*/
        _2 = (object)SEQ_PTR(_bbi_42685);
        _22411 = (object)*(((s1_ptr)_2)->base + 2);
        if (binary_op_a(EQUALS, _22411, 1)){
            _22411 = NOVALUE;
            goto L6; // [73] 82
        }
        _22411 = NOVALUE;

        /** c_decl.e:207				exit*/
        goto L2; // [79] 99
L6: 

        /** c_decl.e:210			return bbi[BB_OBJ]*/
        _2 = (object)SEQ_PTR(_bbi_42685);
        _22413 = (object)*(((s1_ptr)_2)->base + 5);
        Ref(_22413);
        DeRef(_bbi_42685);
        return _22413;

        /** c_decl.e:211		end for*/
L4: 
        _i_42687 = _i_42687 + -1;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** c_decl.e:212		return BB_def_values*/
    RefDS(_58BB_def_values_42678);
    DeRef(_bbi_42685);
    _22413 = NOVALUE;
    return _58BB_def_values_42678;
    ;
}


object _58BB_var_type(object _var_42707)
{
    object _22428 = NOVALUE;
    object _22427 = NOVALUE;
    object _22425 = NOVALUE;
    object _22424 = NOVALUE;
    object _22423 = NOVALUE;
    object _22422 = NOVALUE;
    object _22421 = NOVALUE;
    object _22420 = NOVALUE;
    object _22419 = NOVALUE;
    object _22418 = NOVALUE;
    object _22417 = NOVALUE;
    object _22416 = NOVALUE;
    object _22415 = NOVALUE;
    object _22414 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:218		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_58BB_info_42563)){
            _22414 = SEQ_PTR(_58BB_info_42563)->length;
    }
    else {
        _22414 = 1;
    }
    {
        object _i_42709;
        _i_42709 = _22414;
L1: 
        if (_i_42709 < 1){
            goto L2; // [10] 125
        }

        /** c_decl.e:219			if BB_info[i][BB_VAR] = var and*/
        _2 = (object)SEQ_PTR(_58BB_info_42563);
        _22415 = (object)*(((s1_ptr)_2)->base + _i_42709);
        _2 = (object)SEQ_PTR(_22415);
        _22416 = (object)*(((s1_ptr)_2)->base + 1);
        _22415 = NOVALUE;
        if (IS_ATOM_INT(_22416)) {
            _22417 = (_22416 == _var_42707);
        }
        else {
            _22417 = binary_op(EQUALS, _22416, _var_42707);
        }
        _22416 = NOVALUE;
        if (IS_ATOM_INT(_22417)) {
            if (_22417 == 0) {
                goto L3; // [33] 118
            }
        }
        else {
            if (DBL_PTR(_22417)->dbl == 0.0) {
                goto L3; // [33] 118
            }
        }
        _2 = (object)SEQ_PTR(_58BB_info_42563);
        _22419 = (object)*(((s1_ptr)_2)->base + _i_42709);
        _2 = (object)SEQ_PTR(_22419);
        _22420 = (object)*(((s1_ptr)_2)->base + 1);
        _22419 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_22420)){
            _22421 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22420)->dbl));
        }
        else{
            _22421 = (object)*(((s1_ptr)_2)->base + _22420);
        }
        _2 = (object)SEQ_PTR(_22421);
        _22422 = (object)*(((s1_ptr)_2)->base + 3);
        _22421 = NOVALUE;
        if (IS_ATOM_INT(_22422)) {
            _22423 = (_22422 == 1);
        }
        else {
            _22423 = binary_op(EQUALS, _22422, 1);
        }
        _22422 = NOVALUE;
        if (_22423 == 0) {
            DeRef(_22423);
            _22423 = NOVALUE;
            goto L3; // [66] 118
        }
        else {
            if (!IS_ATOM_INT(_22423) && DBL_PTR(_22423)->dbl == 0.0){
                DeRef(_22423);
                _22423 = NOVALUE;
                goto L3; // [66] 118
            }
            DeRef(_22423);
            _22423 = NOVALUE;
        }
        DeRef(_22423);
        _22423 = NOVALUE;

        /** c_decl.e:221				ifdef DEBUG then*/

        /** c_decl.e:228				if BB_info[i][BB_TYPE] = TYPE_NULL then  -- var has only been read*/
        _2 = (object)SEQ_PTR(_58BB_info_42563);
        _22424 = (object)*(((s1_ptr)_2)->base + _i_42709);
        _2 = (object)SEQ_PTR(_22424);
        _22425 = (object)*(((s1_ptr)_2)->base + 2);
        _22424 = NOVALUE;
        if (binary_op_a(NOTEQ, _22425, 0)){
            _22425 = NOVALUE;
            goto L4; // [85] 100
        }
        _22425 = NOVALUE;

        /** c_decl.e:229					return TYPE_OBJECT*/
        _22420 = NOVALUE;
        DeRef(_22417);
        _22417 = NOVALUE;
        return 16;
        goto L5; // [97] 117
L4: 

        /** c_decl.e:231					return BB_info[i][BB_TYPE]*/
        _2 = (object)SEQ_PTR(_58BB_info_42563);
        _22427 = (object)*(((s1_ptr)_2)->base + _i_42709);
        _2 = (object)SEQ_PTR(_22427);
        _22428 = (object)*(((s1_ptr)_2)->base + 2);
        _22427 = NOVALUE;
        Ref(_22428);
        _22420 = NOVALUE;
        DeRef(_22417);
        _22417 = NOVALUE;
        return _22428;
L5: 
L3: 

        /** c_decl.e:234		end for*/
        _i_42709 = _i_42709 + -1;
        goto L1; // [120] 17
L2: 
        ;
    }

    /** c_decl.e:235		return TYPE_OBJECT*/
    _22428 = NOVALUE;
    _22420 = NOVALUE;
    DeRef(_22417);
    _22417 = NOVALUE;
    return 16;
    ;
}


object _58GType(object _s_42737)
{
    object _t_42738 = NOVALUE;
    object _local_t_42739 = NOVALUE;
    object _22432 = NOVALUE;
    object _22431 = NOVALUE;
    object _22429 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_42737)) {
        _1 = (object)(DBL_PTR(_s_42737)->dbl);
        DeRefDS(_s_42737);
        _s_42737 = _1;
    }

    /** c_decl.e:243		t = SymTab[s][S_GTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22429 = (object)*(((s1_ptr)_2)->base + _s_42737);
    _2 = (object)SEQ_PTR(_22429);
    _t_42738 = (object)*(((s1_ptr)_2)->base + 36);
    if (!IS_ATOM_INT(_t_42738)){
        _t_42738 = (object)DBL_PTR(_t_42738)->dbl;
    }
    _22429 = NOVALUE;

    /** c_decl.e:244		ifdef DEBUG then*/

    /** c_decl.e:250		if SymTab[s][S_MODE] != M_NORMAL then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22431 = (object)*(((s1_ptr)_2)->base + _s_42737);
    _2 = (object)SEQ_PTR(_22431);
    _22432 = (object)*(((s1_ptr)_2)->base + 3);
    _22431 = NOVALUE;
    if (binary_op_a(EQUALS, _22432, 1)){
        _22432 = NOVALUE;
        goto L1; // [37] 48
    }
    _22432 = NOVALUE;

    /** c_decl.e:251			return t*/
    return _t_42738;
L1: 

    /** c_decl.e:254		local_t = BB_var_type(s)*/
    _local_t_42739 = _58BB_var_type(_s_42737);
    if (!IS_ATOM_INT(_local_t_42739)) {
        _1 = (object)(DBL_PTR(_local_t_42739)->dbl);
        DeRefDS(_local_t_42739);
        _local_t_42739 = _1;
    }

    /** c_decl.e:255		if local_t = TYPE_OBJECT then*/
    if (_local_t_42739 != 16)
    goto L2; // [60] 71

    /** c_decl.e:256			return t*/
    return _t_42738;
L2: 

    /** c_decl.e:258		if t = TYPE_INTEGER then*/
    if (_t_42738 != 1)
    goto L3; // [75] 88

    /** c_decl.e:259			return TYPE_INTEGER*/
    return 1;
L3: 

    /** c_decl.e:261		return local_t*/
    return _local_t_42739;
    ;
}


object _58GDelete()
{
    object _0, _1, _2;
    

    /** c_decl.e:269		return g_has_delete*/
    return _58g_has_delete_42759;
    ;
}


object _58HasDelete(object _s_42766)
{
    object _22447 = NOVALUE;
    object _22446 = NOVALUE;
    object _22444 = NOVALUE;
    object _22443 = NOVALUE;
    object _22442 = NOVALUE;
    object _22441 = NOVALUE;
    object _22439 = NOVALUE;
    object _22438 = NOVALUE;
    object _22437 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_42766)) {
        _1 = (object)(DBL_PTR(_s_42766)->dbl);
        DeRefDS(_s_42766);
        _s_42766 = _1;
    }

    /** c_decl.e:274		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_58BB_info_42563)){
            _22437 = SEQ_PTR(_58BB_info_42563)->length;
    }
    else {
        _22437 = 1;
    }
    {
        object _i_42768;
        _i_42768 = _22437;
L1: 
        if (_i_42768 < 1){
            goto L2; // [10] 57
        }

        /** c_decl.e:275			if BB_info[i][BB_VAR] = s then*/
        _2 = (object)SEQ_PTR(_58BB_info_42563);
        _22438 = (object)*(((s1_ptr)_2)->base + _i_42768);
        _2 = (object)SEQ_PTR(_22438);
        _22439 = (object)*(((s1_ptr)_2)->base + 1);
        _22438 = NOVALUE;
        if (binary_op_a(NOTEQ, _22439, _s_42766)){
            _22439 = NOVALUE;
            goto L3; // [29] 50
        }
        _22439 = NOVALUE;

        /** c_decl.e:276				return BB_info[i][BB_DELETE]*/
        _2 = (object)SEQ_PTR(_58BB_info_42563);
        _22441 = (object)*(((s1_ptr)_2)->base + _i_42768);
        _2 = (object)SEQ_PTR(_22441);
        _22442 = (object)*(((s1_ptr)_2)->base + 6);
        _22441 = NOVALUE;
        Ref(_22442);
        return _22442;
L3: 

        /** c_decl.e:278		end for*/
        _i_42768 = _i_42768 + -1;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** c_decl.e:279		if length(SymTab[s]) < S_HAS_DELETE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22443 = (object)*(((s1_ptr)_2)->base + _s_42766);
    if (IS_SEQUENCE(_22443)){
            _22444 = SEQ_PTR(_22443)->length;
    }
    else {
        _22444 = 1;
    }
    _22443 = NOVALUE;
    if (_22444 >= 54)
    goto L4; // [70] 81

    /** c_decl.e:280			return 0*/
    _22442 = NOVALUE;
    _22443 = NOVALUE;
    return 0;
L4: 

    /** c_decl.e:282		return SymTab[s][S_HAS_DELETE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22446 = (object)*(((s1_ptr)_2)->base + _s_42766);
    _2 = (object)SEQ_PTR(_22446);
    _22447 = (object)*(((s1_ptr)_2)->base + 54);
    _22446 = NOVALUE;
    Ref(_22447);
    _22442 = NOVALUE;
    _22443 = NOVALUE;
    return _22447;
    ;
}


object _58ObjValue(object _s_42789)
{
    object _local_t_42790 = NOVALUE;
    object _st_42791 = NOVALUE;
    object _tmin_42792 = NOVALUE;
    object _tmax_42793 = NOVALUE;
    object _22460 = NOVALUE;
    object _22458 = NOVALUE;
    object _22457 = NOVALUE;
    object _22455 = NOVALUE;
    object _22452 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_42789)) {
        _1 = (object)(DBL_PTR(_s_42789)->dbl);
        DeRefDS(_s_42789);
        _s_42789 = _1;
    }

    /** c_decl.e:293		st = SymTab[s]*/
    DeRef(_st_42791);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _st_42791 = (object)*(((s1_ptr)_2)->base + _s_42789);
    Ref(_st_42791);

    /** c_decl.e:294		tmin = st[S_OBJ_MIN]*/
    DeRef(_tmin_42792);
    _2 = (object)SEQ_PTR(_st_42791);
    _tmin_42792 = (object)*(((s1_ptr)_2)->base + 30);
    Ref(_tmin_42792);

    /** c_decl.e:295		tmax = st[S_OBJ_MAX]*/
    DeRef(_tmax_42793);
    _2 = (object)SEQ_PTR(_st_42791);
    _tmax_42793 = (object)*(((s1_ptr)_2)->base + 31);
    Ref(_tmax_42793);

    /** c_decl.e:297		if tmin != tmax then*/
    if (binary_op_a(EQUALS, _tmin_42792, _tmax_42793)){
        goto L1; // [29] 41
    }

    /** c_decl.e:298			tmin = NOVALUE*/
    Ref(_36NOVALUE_21301);
    DeRef(_tmin_42792);
    _tmin_42792 = _36NOVALUE_21301;
L1: 

    /** c_decl.e:300		if st[S_MODE] != M_NORMAL then*/
    _2 = (object)SEQ_PTR(_st_42791);
    _22452 = (object)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(EQUALS, _22452, 1)){
        _22452 = NOVALUE;
        goto L2; // [51] 62
    }
    _22452 = NOVALUE;

    /** c_decl.e:301			return tmin*/
    DeRef(_local_t_42790);
    DeRef(_st_42791);
    DeRef(_tmax_42793);
    return _tmin_42792;
L2: 

    /** c_decl.e:305		local_t = BB_var_obj(s)*/
    _0 = _local_t_42790;
    _local_t_42790 = _58BB_var_obj(_s_42789);
    DeRef(_0);

    /** c_decl.e:306		if local_t[MIN] = NOVALUE then*/
    _2 = (object)SEQ_PTR(_local_t_42790);
    _22455 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _22455, _36NOVALUE_21301)){
        _22455 = NOVALUE;
        goto L3; // [80] 91
    }
    _22455 = NOVALUE;

    /** c_decl.e:307			return tmin*/
    DeRefDS(_local_t_42790);
    DeRef(_st_42791);
    DeRef(_tmax_42793);
    return _tmin_42792;
L3: 

    /** c_decl.e:310		if local_t[MIN] != local_t[MAX] then*/
    _2 = (object)SEQ_PTR(_local_t_42790);
    _22457 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_local_t_42790);
    _22458 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(EQUALS, _22457, _22458)){
        _22457 = NOVALUE;
        _22458 = NOVALUE;
        goto L4; // [105] 116
    }
    _22457 = NOVALUE;
    _22458 = NOVALUE;

    /** c_decl.e:311			return tmin*/
    DeRefDS(_local_t_42790);
    DeRef(_st_42791);
    DeRef(_tmax_42793);
    return _tmin_42792;
L4: 

    /** c_decl.e:314		return local_t[MIN]*/
    _2 = (object)SEQ_PTR(_local_t_42790);
    _22460 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22460);
    DeRefDS(_local_t_42790);
    DeRef(_st_42791);
    DeRef(_tmin_42792);
    DeRef(_tmax_42793);
    return _22460;
    ;
}


object _58TypeIs(object _x_42824, object _typei_42825)
{
    object _22462 = NOVALUE;
    object _22461 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_42824)) {
        _1 = (object)(DBL_PTR(_x_42824)->dbl);
        DeRefDS(_x_42824);
        _x_42824 = _1;
    }

    /** c_decl.e:319		return GType(x) = typei*/
    _22461 = _58GType(_x_42824);
    if (IS_ATOM_INT(_22461)) {
        _22462 = (_22461 == _typei_42825);
    }
    else {
        _22462 = binary_op(EQUALS, _22461, _typei_42825);
    }
    DeRef(_22461);
    _22461 = NOVALUE;
    return _22462;
    ;
}


object _58TypeIsIn(object _x_42830, object _types_42831)
{
    object _22464 = NOVALUE;
    object _22463 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_42830)) {
        _1 = (object)(DBL_PTR(_x_42830)->dbl);
        DeRefDS(_x_42830);
        _x_42830 = _1;
    }

    /** c_decl.e:323		return find(GType(x), types)*/
    _22463 = _58GType(_x_42830);
    _22464 = find_from(_22463, _types_42831, 1);
    DeRef(_22463);
    _22463 = NOVALUE;
    DeRefDS(_types_42831);
    return _22464;
    ;
}


object _58TypeIsNot(object _x_42836, object _typei_42837)
{
    object _22466 = NOVALUE;
    object _22465 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_42836)) {
        _1 = (object)(DBL_PTR(_x_42836)->dbl);
        DeRefDS(_x_42836);
        _x_42836 = _1;
    }

    /** c_decl.e:327		return GType(x) != typei*/
    _22465 = _58GType(_x_42836);
    if (IS_ATOM_INT(_22465)) {
        _22466 = (_22465 != _typei_42837);
    }
    else {
        _22466 = binary_op(NOTEQ, _22465, _typei_42837);
    }
    DeRef(_22465);
    _22465 = NOVALUE;
    return _22466;
    ;
}


object _58TypeIsNotIn(object _x_42842, object _types_42843)
{
    object _22469 = NOVALUE;
    object _22468 = NOVALUE;
    object _22467 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_42842)) {
        _1 = (object)(DBL_PTR(_x_42842)->dbl);
        DeRefDS(_x_42842);
        _x_42842 = _1;
    }

    /** c_decl.e:331		return not find(GType(x), types)*/
    _22467 = _58GType(_x_42842);
    _22468 = find_from(_22467, _types_42843, 1);
    DeRef(_22467);
    _22467 = NOVALUE;
    _22469 = (_22468 == 0);
    _22468 = NOVALUE;
    DeRefDS(_types_42843);
    return _22469;
    ;
}


object _58or_type(object _t1_42849, object _t2_42850)
{
    object _22489 = NOVALUE;
    object _22488 = NOVALUE;
    object _22487 = NOVALUE;
    object _22486 = NOVALUE;
    object _22481 = NOVALUE;
    object _22479 = NOVALUE;
    object _22474 = NOVALUE;
    object _22472 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_t1_42849)) {
        _1 = (object)(DBL_PTR(_t1_42849)->dbl);
        DeRefDS(_t1_42849);
        _t1_42849 = _1;
    }
    if (!IS_ATOM_INT(_t2_42850)) {
        _1 = (object)(DBL_PTR(_t2_42850)->dbl);
        DeRefDS(_t2_42850);
        _t2_42850 = _1;
    }

    /** c_decl.e:337		if t1 = TYPE_NULL then*/
    if (_t1_42849 != 0)
    goto L1; // [9] 22

    /** c_decl.e:338			return t2*/
    return _t2_42850;
    goto L2; // [19] 307
L1: 

    /** c_decl.e:340		elsif t2 = TYPE_NULL then*/
    if (_t2_42850 != 0)
    goto L3; // [26] 39

    /** c_decl.e:341			return t1*/
    return _t1_42849;
    goto L2; // [36] 307
L3: 

    /** c_decl.e:343		elsif t1 = TYPE_OBJECT or t2 = TYPE_OBJECT then*/
    _22472 = (_t1_42849 == 16);
    if (_22472 != 0) {
        goto L4; // [47] 62
    }
    _22474 = (_t2_42850 == 16);
    if (_22474 == 0)
    {
        DeRef(_22474);
        _22474 = NOVALUE;
        goto L5; // [58] 73
    }
    else{
        DeRef(_22474);
        _22474 = NOVALUE;
    }
L4: 

    /** c_decl.e:344			return TYPE_OBJECT*/
    DeRef(_22472);
    _22472 = NOVALUE;
    return 16;
    goto L2; // [70] 307
L5: 

    /** c_decl.e:346		elsif t1 = TYPE_SEQUENCE then*/
    if (_t1_42849 != 8)
    goto L6; // [77] 112

    /** c_decl.e:347			if t2 = TYPE_SEQUENCE then*/
    if (_t2_42850 != 8)
    goto L7; // [85] 100

    /** c_decl.e:348				return TYPE_SEQUENCE*/
    DeRef(_22472);
    _22472 = NOVALUE;
    return 8;
    goto L2; // [97] 307
L7: 

    /** c_decl.e:350				return TYPE_OBJECT*/
    DeRef(_22472);
    _22472 = NOVALUE;
    return 16;
    goto L2; // [109] 307
L6: 

    /** c_decl.e:353		elsif t2 = TYPE_SEQUENCE then*/
    if (_t2_42850 != 8)
    goto L8; // [116] 151

    /** c_decl.e:354			if t1 = TYPE_SEQUENCE then*/
    if (_t1_42849 != 8)
    goto L9; // [124] 139

    /** c_decl.e:355				return TYPE_SEQUENCE*/
    DeRef(_22472);
    _22472 = NOVALUE;
    return 8;
    goto L2; // [136] 307
L9: 

    /** c_decl.e:357				return TYPE_OBJECT*/
    DeRef(_22472);
    _22472 = NOVALUE;
    return 16;
    goto L2; // [148] 307
L8: 

    /** c_decl.e:360		elsif t1 = TYPE_ATOM or t2 = TYPE_ATOM then*/
    _22479 = (_t1_42849 == 4);
    if (_22479 != 0) {
        goto LA; // [159] 174
    }
    _22481 = (_t2_42850 == 4);
    if (_22481 == 0)
    {
        DeRef(_22481);
        _22481 = NOVALUE;
        goto LB; // [170] 185
    }
    else{
        DeRef(_22481);
        _22481 = NOVALUE;
    }
LA: 

    /** c_decl.e:361			return TYPE_ATOM*/
    DeRef(_22472);
    _22472 = NOVALUE;
    DeRef(_22479);
    _22479 = NOVALUE;
    return 4;
    goto L2; // [182] 307
LB: 

    /** c_decl.e:363		elsif t1 = TYPE_DOUBLE then*/
    if (_t1_42849 != 2)
    goto LC; // [189] 224

    /** c_decl.e:364			if t2 = TYPE_INTEGER then*/
    if (_t2_42850 != 1)
    goto LD; // [197] 212

    /** c_decl.e:365				return TYPE_ATOM*/
    DeRef(_22472);
    _22472 = NOVALUE;
    DeRef(_22479);
    _22479 = NOVALUE;
    return 4;
    goto L2; // [209] 307
LD: 

    /** c_decl.e:367				return TYPE_DOUBLE*/
    DeRef(_22472);
    _22472 = NOVALUE;
    DeRef(_22479);
    _22479 = NOVALUE;
    return 2;
    goto L2; // [221] 307
LC: 

    /** c_decl.e:370		elsif t2 = TYPE_DOUBLE then*/
    if (_t2_42850 != 2)
    goto LE; // [228] 263

    /** c_decl.e:371			if t1 = TYPE_INTEGER then*/
    if (_t1_42849 != 1)
    goto LF; // [236] 251

    /** c_decl.e:372				return TYPE_ATOM*/
    DeRef(_22472);
    _22472 = NOVALUE;
    DeRef(_22479);
    _22479 = NOVALUE;
    return 4;
    goto L2; // [248] 307
LF: 

    /** c_decl.e:374				return TYPE_DOUBLE*/
    DeRef(_22472);
    _22472 = NOVALUE;
    DeRef(_22479);
    _22479 = NOVALUE;
    return 2;
    goto L2; // [260] 307
LE: 

    /** c_decl.e:377		elsif t1 = TYPE_INTEGER and t2 = TYPE_INTEGER then*/
    _22486 = (_t1_42849 == 1);
    if (_22486 == 0) {
        goto L10; // [271] 296
    }
    _22488 = (_t2_42850 == 1);
    if (_22488 == 0)
    {
        DeRef(_22488);
        _22488 = NOVALUE;
        goto L10; // [282] 296
    }
    else{
        DeRef(_22488);
        _22488 = NOVALUE;
    }

    /** c_decl.e:378			return TYPE_INTEGER*/
    DeRef(_22472);
    _22472 = NOVALUE;
    DeRef(_22479);
    _22479 = NOVALUE;
    DeRef(_22486);
    _22486 = NOVALUE;
    return 1;
    goto L2; // [293] 307
L10: 

    /** c_decl.e:381			InternalErr(258, {t1, t2})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _t1_42849;
    ((intptr_t *)_2)[2] = _t2_42850;
    _22489 = MAKE_SEQ(_1);
    _50InternalErr(258, _22489);
    _22489 = NOVALUE;
L2: 
    ;
}


void _58RemoveFromBB(object _s_42920)
{
    object _int_42921 = NOVALUE;
    object _22491 = NOVALUE;
    object _22490 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:388		for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_58BB_info_42563)){
            _22490 = SEQ_PTR(_58BB_info_42563)->length;
    }
    else {
        _22490 = 1;
    }
    {
        object _i_42923;
        _i_42923 = 1;
L1: 
        if (_i_42923 > _22490){
            goto L2; // [10] 59
        }

        /** c_decl.e:389			int = BB_info[i][BB_VAR]*/
        _2 = (object)SEQ_PTR(_58BB_info_42563);
        _22491 = (object)*(((s1_ptr)_2)->base + _i_42923);
        _2 = (object)SEQ_PTR(_22491);
        _int_42921 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_int_42921)){
            _int_42921 = (object)DBL_PTR(_int_42921)->dbl;
        }
        _22491 = NOVALUE;

        /** c_decl.e:390			if int = s then*/
        if (_int_42921 != _s_42920)
        goto L3; // [33] 52

        /** c_decl.e:391				BB_info = remove( BB_info, int )*/
        {
            s1_ptr assign_space = SEQ_PTR(_58BB_info_42563);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_int_42921)) ? _int_42921 : (object)(DBL_PTR(_int_42921)->dbl);
            int stop = (IS_ATOM_INT(_int_42921)) ? _int_42921 : (object)(DBL_PTR(_int_42921)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_58BB_info_42563), start, &_58BB_info_42563 );
                }
                else Tail(SEQ_PTR(_58BB_info_42563), stop+1, &_58BB_info_42563);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_58BB_info_42563), start, &_58BB_info_42563);
            }
            else {
                assign_slice_seq = &assign_space;
                _58BB_info_42563 = Remove_elements(start, stop, (SEQ_PTR(_58BB_info_42563)->ref == 1));
            }
        }

        /** c_decl.e:392				return*/
        return;
L3: 

        /** c_decl.e:394		end for*/
        _i_42923 = _i_42923 + 1;
        goto L1; // [54] 17
L2: 
        ;
    }

    /** c_decl.e:395	end procedure*/
    return;
    ;
}


void _58SetBBType(object _s_42941, object _t_42942, object _val_42943, object _etype_42944, object _has_delete_42945)
{
    object _found_42946 = NOVALUE;
    object _i_42947 = NOVALUE;
    object _tn_42948 = NOVALUE;
    object _int_42949 = NOVALUE;
    object _sym_42950 = NOVALUE;
    object _mode_42955 = NOVALUE;
    object _gtype_42970 = NOVALUE;
    object _new_type_43007 = NOVALUE;
    object _bbsym_43030 = NOVALUE;
    object _bbi_43166 = NOVALUE;
    object _22610 = NOVALUE;
    object _22609 = NOVALUE;
    object _22608 = NOVALUE;
    object _22606 = NOVALUE;
    object _22605 = NOVALUE;
    object _22604 = NOVALUE;
    object _22602 = NOVALUE;
    object _22601 = NOVALUE;
    object _22599 = NOVALUE;
    object _22597 = NOVALUE;
    object _22596 = NOVALUE;
    object _22594 = NOVALUE;
    object _22592 = NOVALUE;
    object _22591 = NOVALUE;
    object _22590 = NOVALUE;
    object _22589 = NOVALUE;
    object _22588 = NOVALUE;
    object _22587 = NOVALUE;
    object _22586 = NOVALUE;
    object _22585 = NOVALUE;
    object _22584 = NOVALUE;
    object _22581 = NOVALUE;
    object _22577 = NOVALUE;
    object _22572 = NOVALUE;
    object _22570 = NOVALUE;
    object _22569 = NOVALUE;
    object _22568 = NOVALUE;
    object _22566 = NOVALUE;
    object _22564 = NOVALUE;
    object _22563 = NOVALUE;
    object _22562 = NOVALUE;
    object _22560 = NOVALUE;
    object _22559 = NOVALUE;
    object _22557 = NOVALUE;
    object _22556 = NOVALUE;
    object _22555 = NOVALUE;
    object _22553 = NOVALUE;
    object _22552 = NOVALUE;
    object _22549 = NOVALUE;
    object _22548 = NOVALUE;
    object _22547 = NOVALUE;
    object _22545 = NOVALUE;
    object _22543 = NOVALUE;
    object _22542 = NOVALUE;
    object _22540 = NOVALUE;
    object _22539 = NOVALUE;
    object _22538 = NOVALUE;
    object _22536 = NOVALUE;
    object _22535 = NOVALUE;
    object _22524 = NOVALUE;
    object _22522 = NOVALUE;
    object _22519 = NOVALUE;
    object _22518 = NOVALUE;
    object _22515 = NOVALUE;
    object _22514 = NOVALUE;
    object _22513 = NOVALUE;
    object _22511 = NOVALUE;
    object _22510 = NOVALUE;
    object _22509 = NOVALUE;
    object _22507 = NOVALUE;
    object _22506 = NOVALUE;
    object _22504 = NOVALUE;
    object _22501 = NOVALUE;
    object _22499 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_42941)) {
        _1 = (object)(DBL_PTR(_s_42941)->dbl);
        DeRefDS(_s_42941);
        _s_42941 = _1;
    }
    if (!IS_ATOM_INT(_t_42942)) {
        _1 = (object)(DBL_PTR(_t_42942)->dbl);
        DeRefDS(_t_42942);
        _t_42942 = _1;
    }
    if (!IS_ATOM_INT(_etype_42944)) {
        _1 = (object)(DBL_PTR(_etype_42944)->dbl);
        DeRefDS(_etype_42944);
        _etype_42944 = _1;
    }
    if (!IS_ATOM_INT(_has_delete_42945)) {
        _1 = (object)(DBL_PTR(_has_delete_42945)->dbl);
        DeRefDS(_has_delete_42945);
        _has_delete_42945 = _1;
    }

    /** c_decl.e:416		if has_delete then*/
    if (_has_delete_42945 == 0)
    {
        goto L1; // [13] 27
    }
    else{
    }

    /** c_decl.e:417			p_has_delete = 1*/
    _58p_has_delete_42760 = 1;

    /** c_decl.e:418			g_has_delete = 1*/
    _58g_has_delete_42759 = 1;
L1: 

    /** c_decl.e:421		sym = SymTab[s]*/
    DeRef(_sym_42950);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _sym_42950 = (object)*(((s1_ptr)_2)->base + _s_42941);
    Ref(_sym_42950);

    /** c_decl.e:422		SymTab[s] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_42941);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:424		integer mode = sym[S_MODE]*/
    _2 = (object)SEQ_PTR(_sym_42950);
    _mode_42955 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_42955))
    _mode_42955 = (object)DBL_PTR(_mode_42955)->dbl;

    /** c_decl.e:425		if mode = M_NORMAL or mode = M_TEMP  then*/
    _22499 = (_mode_42955 == 1);
    if (_22499 != 0) {
        goto L2; // [61] 76
    }
    _22501 = (_mode_42955 == 3);
    if (_22501 == 0)
    {
        DeRef(_22501);
        _22501 = NOVALUE;
        goto L3; // [72] 1167
    }
    else{
        DeRef(_22501);
        _22501 = NOVALUE;
    }
L2: 

    /** c_decl.e:427			found = FALSE*/
    _found_42946 = _13FALSE_450;

    /** c_decl.e:428			if mode = M_TEMP then*/
    if (_mode_42955 != 3)
    goto L4; // [89] 465

    /** c_decl.e:429				sym[S_GTYPE] = t*/
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_42942;
    DeRef(_1);

    /** c_decl.e:430				sym[S_SEQ_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_42944;
    DeRef(_1);

    /** c_decl.e:431				integer gtype = sym[S_GTYPE]*/
    _2 = (object)SEQ_PTR(_sym_42950);
    _gtype_42970 = (object)*(((s1_ptr)_2)->base + 36);
    if (!IS_ATOM_INT(_gtype_42970))
    _gtype_42970 = (object)DBL_PTR(_gtype_42970)->dbl;

    /** c_decl.e:432				if gtype = TYPE_OBJECT*/
    _22504 = (_gtype_42970 == 16);
    if (_22504 != 0) {
        goto L5; // [125] 140
    }
    _22506 = (_gtype_42970 == 8);
    if (_22506 == 0)
    {
        DeRef(_22506);
        _22506 = NOVALUE;
        goto L6; // [136] 213
    }
    else{
        DeRef(_22506);
        _22506 = NOVALUE;
    }
L5: 

    /** c_decl.e:435					if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22507 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22507, 0)){
        _22507 = NOVALUE;
        goto L7; // [148] 165
    }
    _22507 = NOVALUE;

    /** c_decl.e:436						sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21301;
    DeRef(_1);
    goto L8; // [162] 180
L7: 

    /** c_decl.e:438						sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22509 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22509);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22509;
    if( _1 != _22509 ){
        DeRef(_1);
    }
    _22509 = NOVALUE;
L8: 

    /** c_decl.e:440					sym[S_OBJ] = NOVALUE*/
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21301;
    DeRef(_1);

    /** c_decl.e:442					sym[S_OBJ_MIN] = NOVALUE*/
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21301;
    DeRef(_1);

    /** c_decl.e:443					sym[S_OBJ_MAX] = NOVALUE*/
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21301;
    DeRef(_1);
    goto L9; // [210] 252
L6: 

    /** c_decl.e:445					sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22510 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22510);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22510;
    if( _1 != _22510 ){
        DeRef(_1);
    }
    _22510 = NOVALUE;

    /** c_decl.e:446					sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22511 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_22511);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22511;
    if( _1 != _22511 ){
        DeRef(_1);
    }
    _22511 = NOVALUE;

    /** c_decl.e:447					sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21301;
    DeRef(_1);
L9: 

    /** c_decl.e:449				if not Initializing then*/
    if (_36Initializing_21531 != 0)
    goto LA; // [256] 326

    /** c_decl.e:450					integer new_type = or_type(temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW], t)*/
    _2 = (object)SEQ_PTR(_sym_42950);
    _22513 = (object)*(((s1_ptr)_2)->base + 34);
    _2 = (object)SEQ_PTR(_36temp_name_type_21533);
    if (!IS_ATOM_INT(_22513)){
        _22514 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22513)->dbl));
    }
    else{
        _22514 = (object)*(((s1_ptr)_2)->base + _22513);
    }
    _2 = (object)SEQ_PTR(_22514);
    _22515 = (object)*(((s1_ptr)_2)->base + 2);
    _22514 = NOVALUE;
    Ref(_22515);
    _new_type_43007 = _58or_type(_22515, _t_42942);
    _22515 = NOVALUE;
    if (!IS_ATOM_INT(_new_type_43007)) {
        _1 = (object)(DBL_PTR(_new_type_43007)->dbl);
        DeRefDS(_new_type_43007);
        _new_type_43007 = _1;
    }

    /** c_decl.e:451					if new_type = TYPE_NULL then*/
    if (_new_type_43007 != 0)
    goto LB; // [290] 304

    /** c_decl.e:452						new_type = TYPE_OBJECT*/
    _new_type_43007 = 16;
LB: 

    /** c_decl.e:454					temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW] = new_type*/
    _2 = (object)SEQ_PTR(_sym_42950);
    _22518 = (object)*(((s1_ptr)_2)->base + 34);
    _2 = (object)SEQ_PTR(_36temp_name_type_21533);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36temp_name_type_21533 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_22518))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_22518)->dbl));
    else
    _3 = (object)(_22518 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_type_43007;
    DeRef(_1);
    _22519 = NOVALUE;
LA: 

    /** c_decl.e:458				tn = sym[S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_sym_42950);
    _tn_42948 = (object)*(((s1_ptr)_2)->base + 34);
    if (!IS_ATOM_INT(_tn_42948))
    _tn_42948 = (object)DBL_PTR(_tn_42948)->dbl;

    /** c_decl.e:459				i = 1*/
    _i_42947 = 1;

    /** c_decl.e:460				while i <= length(BB_info) do*/
LC: 
    if (IS_SEQUENCE(_58BB_info_42563)){
            _22522 = SEQ_PTR(_58BB_info_42563)->length;
    }
    else {
        _22522 = 1;
    }
    if (_i_42947 > _22522)
    goto LD; // [351] 460

    /** c_decl.e:461					sequence bbsym*/

    /** c_decl.e:462					int = BB_info[i][BB_VAR]*/
    _2 = (object)SEQ_PTR(_58BB_info_42563);
    _22524 = (object)*(((s1_ptr)_2)->base + _i_42947);
    _2 = (object)SEQ_PTR(_22524);
    _int_42949 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_42949)){
        _int_42949 = (object)DBL_PTR(_int_42949)->dbl;
    }
    _22524 = NOVALUE;

    /** c_decl.e:463					if int = s then*/
    if (_int_42949 != _s_42941)
    goto LE; // [373] 387

    /** c_decl.e:464						bbsym = sym*/
    RefDS(_sym_42950);
    DeRef(_bbsym_43030);
    _bbsym_43030 = _sym_42950;
    goto LF; // [384] 398
LE: 

    /** c_decl.e:466						bbsym = SymTab[int]*/
    DeRef(_bbsym_43030);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _bbsym_43030 = (object)*(((s1_ptr)_2)->base + _int_42949);
    Ref(_bbsym_43030);
LF: 

    /** c_decl.e:468					int = bbsym[S_MODE]*/
    _2 = (object)SEQ_PTR(_bbsym_43030);
    _int_42949 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_int_42949))
    _int_42949 = (object)DBL_PTR(_int_42949)->dbl;

    /** c_decl.e:469					if int = M_TEMP then*/
    if (_int_42949 != 3)
    goto L10; // [412] 447

    /** c_decl.e:470						int = bbsym[S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_bbsym_43030);
    _int_42949 = (object)*(((s1_ptr)_2)->base + 34);
    if (!IS_ATOM_INT(_int_42949))
    _int_42949 = (object)DBL_PTR(_int_42949)->dbl;

    /** c_decl.e:471						if int = tn then*/
    if (_int_42949 != _tn_42948)
    goto L11; // [426] 446

    /** c_decl.e:472							found = TRUE*/
    _found_42946 = _13TRUE_452;

    /** c_decl.e:473							exit*/
    DeRefDS(_bbsym_43030);
    _bbsym_43030 = NOVALUE;
    goto LD; // [443] 460
L11: 
L10: 

    /** c_decl.e:476					i += 1*/
    _i_42947 = _i_42947 + 1;
    DeRef(_bbsym_43030);
    _bbsym_43030 = NOVALUE;

    /** c_decl.e:477				end while*/
    goto LC; // [457] 346
LD: 
    goto L12; // [462] 889
L4: 

    /** c_decl.e:479				if t != TYPE_NULL then*/
    if (_t_42942 == 0)
    goto L13; // [469] 824

    /** c_decl.e:480					if not Initializing then*/
    if (_36Initializing_21531 != 0)
    goto L14; // [477] 500

    /** c_decl.e:481						sym[S_GTYPE_NEW] = or_type(sym[S_GTYPE_NEW], t)*/
    _2 = (object)SEQ_PTR(_sym_42950);
    _22535 = (object)*(((s1_ptr)_2)->base + 38);
    Ref(_22535);
    _22536 = _58or_type(_22535, _t_42942);
    _22535 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22536;
    if( _1 != _22536 ){
        DeRef(_1);
    }
    _22536 = NOVALUE;
L14: 

    /** c_decl.e:484					if t = TYPE_SEQUENCE then*/
    if (_t_42942 != 8)
    goto L15; // [504] 633

    /** c_decl.e:485						sym[S_SEQ_ELEM_NEW] =*/
    _2 = (object)SEQ_PTR(_sym_42950);
    _22538 = (object)*(((s1_ptr)_2)->base + 40);
    Ref(_22538);
    _22539 = _58or_type(_22538, _etype_42944);
    _22538 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22539;
    if( _1 != _22539 ){
        DeRef(_1);
    }
    _22539 = NOVALUE;

    /** c_decl.e:488						if val[MIN] != -1 then*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22540 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _22540, -1)){
        _22540 = NOVALUE;
        goto L16; // [535] 823
    }
    _22540 = NOVALUE;

    /** c_decl.e:489							if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_42950);
    _22542 = (object)*(((s1_ptr)_2)->base + 39);
    if (IS_ATOM_INT(_36NOVALUE_21301)) {
        if ((uintptr_t)_36NOVALUE_21301 == (uintptr_t)HIGH_BITS){
            _22543 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22543 = - _36NOVALUE_21301;
        }
    }
    else {
        _22543 = unary_op(UMINUS, _36NOVALUE_21301);
    }
    if (binary_op_a(NOTEQ, _22542, _22543)){
        _22542 = NOVALUE;
        DeRef(_22543);
        _22543 = NOVALUE;
        goto L17; // [552] 599
    }
    _22542 = NOVALUE;
    DeRef(_22543);
    _22543 = NOVALUE;

    /** c_decl.e:490								if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22545 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22545, 0)){
        _22545 = NOVALUE;
        goto L18; // [564] 581
    }
    _22545 = NOVALUE;

    /** c_decl.e:491									sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21301;
    DeRef(_1);
    goto L16; // [578] 823
L18: 

    /** c_decl.e:493									sym[S_SEQ_LEN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22547 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22547);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22547;
    if( _1 != _22547 ){
        DeRef(_1);
    }
    _22547 = NOVALUE;
    goto L16; // [596] 823
L17: 

    /** c_decl.e:495							elsif val[MIN] != sym[S_SEQ_LEN_NEW] then*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22548 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_sym_42950);
    _22549 = (object)*(((s1_ptr)_2)->base + 39);
    if (binary_op_a(EQUALS, _22548, _22549)){
        _22548 = NOVALUE;
        _22549 = NOVALUE;
        goto L16; // [613] 823
    }
    _22548 = NOVALUE;
    _22549 = NOVALUE;

    /** c_decl.e:496								sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21301;
    DeRef(_1);
    goto L16; // [630] 823
L15: 

    /** c_decl.e:500					elsif t = TYPE_INTEGER then*/
    if (_t_42942 != 1)
    goto L19; // [637] 774

    /** c_decl.e:502						if sym[S_OBJ_MIN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_42950);
    _22552 = (object)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_36NOVALUE_21301)) {
        if ((uintptr_t)_36NOVALUE_21301 == (uintptr_t)HIGH_BITS){
            _22553 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22553 = - _36NOVALUE_21301;
        }
    }
    else {
        _22553 = unary_op(UMINUS, _36NOVALUE_21301);
    }
    if (binary_op_a(NOTEQ, _22552, _22553)){
        _22552 = NOVALUE;
        DeRef(_22553);
        _22553 = NOVALUE;
        goto L1A; // [654] 689
    }
    _22552 = NOVALUE;
    DeRef(_22553);
    _22553 = NOVALUE;

    /** c_decl.e:504							sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22555 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22555);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22555;
    if( _1 != _22555 ){
        DeRef(_1);
    }
    _22555 = NOVALUE;

    /** c_decl.e:505							sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22556 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_22556);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22556;
    if( _1 != _22556 ){
        DeRef(_1);
    }
    _22556 = NOVALUE;
    goto L16; // [686] 823
L1A: 

    /** c_decl.e:507						elsif sym[S_OBJ_MIN_NEW] != NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_42950);
    _22557 = (object)*(((s1_ptr)_2)->base + 41);
    if (binary_op_a(EQUALS, _22557, _36NOVALUE_21301)){
        _22557 = NOVALUE;
        goto L16; // [699] 823
    }
    _22557 = NOVALUE;

    /** c_decl.e:509							if val[MIN] < sym[S_OBJ_MIN_NEW] then*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22559 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_sym_42950);
    _22560 = (object)*(((s1_ptr)_2)->base + 41);
    if (binary_op_a(GREATEREQ, _22559, _22560)){
        _22559 = NOVALUE;
        _22560 = NOVALUE;
        goto L1B; // [717] 736
    }
    _22559 = NOVALUE;
    _22560 = NOVALUE;

    /** c_decl.e:510								sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22562 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22562);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22562;
    if( _1 != _22562 ){
        DeRef(_1);
    }
    _22562 = NOVALUE;
L1B: 

    /** c_decl.e:512							if val[MAX] > sym[S_OBJ_MAX_NEW] then*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22563 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_sym_42950);
    _22564 = (object)*(((s1_ptr)_2)->base + 42);
    if (binary_op_a(LESSEQ, _22563, _22564)){
        _22563 = NOVALUE;
        _22564 = NOVALUE;
        goto L16; // [750] 823
    }
    _22563 = NOVALUE;
    _22564 = NOVALUE;

    /** c_decl.e:513								sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22566 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_22566);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22566;
    if( _1 != _22566 ){
        DeRef(_1);
    }
    _22566 = NOVALUE;
    goto L16; // [771] 823
L19: 

    /** c_decl.e:518						sym[S_OBJ_MIN_NEW] = NOVALUE*/
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21301;
    DeRef(_1);

    /** c_decl.e:519						if t = TYPE_OBJECT then*/
    if (_t_42942 != 16)
    goto L1C; // [788] 822

    /** c_decl.e:522							sym[S_SEQ_ELEM_NEW] =*/
    _2 = (object)SEQ_PTR(_sym_42950);
    _22568 = (object)*(((s1_ptr)_2)->base + 40);
    Ref(_22568);
    _22569 = _58or_type(_22568, _etype_42944);
    _22568 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22569;
    if( _1 != _22569 ){
        DeRef(_1);
    }
    _22569 = NOVALUE;

    /** c_decl.e:524							sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21301;
    DeRef(_1);
L1C: 
L16: 
L13: 

    /** c_decl.e:529				i = 1*/
    _i_42947 = 1;

    /** c_decl.e:530				while i <= length(BB_info) do*/
L1D: 
    if (IS_SEQUENCE(_58BB_info_42563)){
            _22570 = SEQ_PTR(_58BB_info_42563)->length;
    }
    else {
        _22570 = 1;
    }
    if (_i_42947 > _22570)
    goto L1E; // [839] 888

    /** c_decl.e:531					int = BB_info[i][BB_VAR]*/
    _2 = (object)SEQ_PTR(_58BB_info_42563);
    _22572 = (object)*(((s1_ptr)_2)->base + _i_42947);
    _2 = (object)SEQ_PTR(_22572);
    _int_42949 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_42949)){
        _int_42949 = (object)DBL_PTR(_int_42949)->dbl;
    }
    _22572 = NOVALUE;

    /** c_decl.e:532					if int = s then*/
    if (_int_42949 != _s_42941)
    goto L1F; // [859] 877

    /** c_decl.e:533						found = TRUE*/
    _found_42946 = _13TRUE_452;

    /** c_decl.e:534						exit*/
    goto L1E; // [874] 888
L1F: 

    /** c_decl.e:536					i += 1*/
    _i_42947 = _i_42947 + 1;

    /** c_decl.e:537				end while*/
    goto L1D; // [885] 834
L1E: 
L12: 

    /** c_decl.e:541			if not found then*/
    if (_found_42946 != 0)
    goto L20; // [891] 907

    /** c_decl.e:543				BB_info = append(BB_info, repeat(0, 6))*/
    _22577 = Repeat(0, 6);
    RefDS(_22577);
    Append(&_58BB_info_42563, _58BB_info_42563, _22577);
    DeRefDS(_22577);
    _22577 = NOVALUE;
L20: 

    /** c_decl.e:546			if t = TYPE_NULL then*/
    if (_t_42942 != 0)
    goto L21; // [911] 949

    /** c_decl.e:547				if not found then*/
    if (_found_42946 != 0)
    goto L22; // [917] 1308

    /** c_decl.e:549					BB_info[i] = dummy_bb*/
    RefDS(_58dummy_bb_42930);
    _2 = (object)SEQ_PTR(_58BB_info_42563);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58BB_info_42563 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_42947);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _58dummy_bb_42930;
    DeRef(_1);

    /** c_decl.e:550					BB_info[i][BB_VAR] = s*/
    _2 = (object)SEQ_PTR(_58BB_info_42563);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58BB_info_42563 = MAKE_SEQ(_2);
    }
    _3 = (object)(_i_42947 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_42941;
    DeRef(_1);
    _22581 = NOVALUE;
    goto L22; // [946] 1308
L21: 

    /** c_decl.e:554				sequence bbi = BB_info[i]*/
    DeRef(_bbi_43166);
    _2 = (object)SEQ_PTR(_58BB_info_42563);
    _bbi_43166 = (object)*(((s1_ptr)_2)->base + _i_42947);
    Ref(_bbi_43166);

    /** c_decl.e:555				BB_info[i] = 0*/
    _2 = (object)SEQ_PTR(_58BB_info_42563);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58BB_info_42563 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_42947);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:556				bbi[BB_VAR] = s*/
    _2 = (object)SEQ_PTR(_bbi_43166);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43166 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_42941;
    DeRef(_1);

    /** c_decl.e:557				bbi[BB_TYPE] = t*/
    _2 = (object)SEQ_PTR(_bbi_43166);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43166 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_42942;
    DeRef(_1);

    /** c_decl.e:558				bbi[BB_DELETE] = has_delete*/
    _2 = (object)SEQ_PTR(_bbi_43166);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43166 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _has_delete_42945;
    DeRef(_1);

    /** c_decl.e:560				if t = TYPE_SEQUENCE and val[MIN] = -1 then*/
    _22584 = (_t_42942 == 8);
    if (_22584 == 0) {
        goto L23; // [995] 1077
    }
    _2 = (object)SEQ_PTR(_val_42943);
    _22586 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_22586)) {
        _22587 = (_22586 == -1);
    }
    else {
        _22587 = binary_op(EQUALS, _22586, -1);
    }
    _22586 = NOVALUE;
    if (_22587 == 0) {
        DeRef(_22587);
        _22587 = NOVALUE;
        goto L23; // [1010] 1077
    }
    else {
        if (!IS_ATOM_INT(_22587) && DBL_PTR(_22587)->dbl == 0.0){
            DeRef(_22587);
            _22587 = NOVALUE;
            goto L23; // [1010] 1077
        }
        DeRef(_22587);
        _22587 = NOVALUE;
    }
    DeRef(_22587);
    _22587 = NOVALUE;

    /** c_decl.e:562					if found and bbi[BB_ELEM] != TYPE_NULL then*/
    if (_found_42946 == 0) {
        goto L24; // [1015] 1051
    }
    _2 = (object)SEQ_PTR(_bbi_43166);
    _22589 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_22589)) {
        _22590 = (_22589 != 0);
    }
    else {
        _22590 = binary_op(NOTEQ, _22589, 0);
    }
    _22589 = NOVALUE;
    if (_22590 == 0) {
        DeRef(_22590);
        _22590 = NOVALUE;
        goto L24; // [1030] 1051
    }
    else {
        if (!IS_ATOM_INT(_22590) && DBL_PTR(_22590)->dbl == 0.0){
            DeRef(_22590);
            _22590 = NOVALUE;
            goto L24; // [1030] 1051
        }
        DeRef(_22590);
        _22590 = NOVALUE;
    }
    DeRef(_22590);
    _22590 = NOVALUE;

    /** c_decl.e:564						bbi[BB_ELEM] = or_type(bbi[BB_ELEM], etype)*/
    _2 = (object)SEQ_PTR(_bbi_43166);
    _22591 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_22591);
    _22592 = _58or_type(_22591, _etype_42944);
    _22591 = NOVALUE;
    _2 = (object)SEQ_PTR(_bbi_43166);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43166 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22592;
    if( _1 != _22592 ){
        DeRef(_1);
    }
    _22592 = NOVALUE;
    goto L25; // [1048] 1060
L24: 

    /** c_decl.e:566						bbi[BB_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_bbi_43166);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43166 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
L25: 

    /** c_decl.e:568					if not found then*/
    if (_found_42946 != 0)
    goto L26; // [1062] 1153

    /** c_decl.e:569						bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(_bbi_43166);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43166 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21301;
    DeRef(_1);
    goto L26; // [1074] 1153
L23: 

    /** c_decl.e:572					bbi[BB_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_bbi_43166);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43166 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_42944;
    DeRef(_1);

    /** c_decl.e:573					if t = TYPE_SEQUENCE or t = TYPE_OBJECT then*/
    _22594 = (_t_42942 == 8);
    if (_22594 != 0) {
        goto L27; // [1091] 1106
    }
    _22596 = (_t_42942 == 16);
    if (_22596 == 0)
    {
        DeRef(_22596);
        _22596 = NOVALUE;
        goto L28; // [1102] 1145
    }
    else{
        DeRef(_22596);
        _22596 = NOVALUE;
    }
L27: 

    /** c_decl.e:574						if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22597 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22597, 0)){
        _22597 = NOVALUE;
        goto L29; // [1114] 1129
    }
    _22597 = NOVALUE;

    /** c_decl.e:575							bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(_bbi_43166);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43166 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21301;
    DeRef(_1);
    goto L2A; // [1126] 1152
L29: 

    /** c_decl.e:577							bbi[BB_SEQLEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22599 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22599);
    _2 = (object)SEQ_PTR(_bbi_43166);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43166 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22599;
    if( _1 != _22599 ){
        DeRef(_1);
    }
    _22599 = NOVALUE;
    goto L2A; // [1142] 1152
L28: 

    /** c_decl.e:580						bbi[BB_OBJ] = val*/
    RefDS(_val_42943);
    _2 = (object)SEQ_PTR(_bbi_43166);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43166 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _val_42943;
    DeRef(_1);
L2A: 
L26: 

    /** c_decl.e:583				BB_info[i] = bbi*/
    RefDS(_bbi_43166);
    _2 = (object)SEQ_PTR(_58BB_info_42563);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58BB_info_42563 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_42947);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _bbi_43166;
    DeRef(_1);
    DeRefDS(_bbi_43166);
    _bbi_43166 = NOVALUE;
    goto L22; // [1164] 1308
L3: 

    /** c_decl.e:586		elsif mode = M_CONSTANT then*/
    if (_mode_42955 != 2)
    goto L2B; // [1171] 1307

    /** c_decl.e:587			sym[S_GTYPE] = t*/
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_42942;
    DeRef(_1);

    /** c_decl.e:588			sym[S_SEQ_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_42944;
    DeRef(_1);

    /** c_decl.e:589			if sym[S_GTYPE] = TYPE_SEQUENCE or*/
    _2 = (object)SEQ_PTR(_sym_42950);
    _22601 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22601)) {
        _22602 = (_22601 == 8);
    }
    else {
        _22602 = binary_op(EQUALS, _22601, 8);
    }
    _22601 = NOVALUE;
    if (IS_ATOM_INT(_22602)) {
        if (_22602 != 0) {
            goto L2C; // [1205] 1226
        }
    }
    else {
        if (DBL_PTR(_22602)->dbl != 0.0) {
            goto L2C; // [1205] 1226
        }
    }
    _2 = (object)SEQ_PTR(_sym_42950);
    _22604 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22604)) {
        _22605 = (_22604 == 16);
    }
    else {
        _22605 = binary_op(EQUALS, _22604, 16);
    }
    _22604 = NOVALUE;
    if (_22605 == 0) {
        DeRef(_22605);
        _22605 = NOVALUE;
        goto L2D; // [1222] 1269
    }
    else {
        if (!IS_ATOM_INT(_22605) && DBL_PTR(_22605)->dbl == 0.0){
            DeRef(_22605);
            _22605 = NOVALUE;
            goto L2D; // [1222] 1269
        }
        DeRef(_22605);
        _22605 = NOVALUE;
    }
    DeRef(_22605);
    _22605 = NOVALUE;
L2C: 

    /** c_decl.e:591				if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22606 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22606, 0)){
        _22606 = NOVALUE;
        goto L2E; // [1234] 1251
    }
    _22606 = NOVALUE;

    /** c_decl.e:592					sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21301;
    DeRef(_1);
    goto L2F; // [1248] 1298
L2E: 

    /** c_decl.e:594					sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22608 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22608);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22608;
    if( _1 != _22608 ){
        DeRef(_1);
    }
    _22608 = NOVALUE;
    goto L2F; // [1266] 1298
L2D: 

    /** c_decl.e:597				sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22609 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22609);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22609;
    if( _1 != _22609 ){
        DeRef(_1);
    }
    _22609 = NOVALUE;

    /** c_decl.e:598				sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_42943);
    _22610 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_22610);
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22610;
    if( _1 != _22610 ){
        DeRef(_1);
    }
    _22610 = NOVALUE;
L2F: 

    /** c_decl.e:600			sym[S_HAS_DELETE] = has_delete*/
    _2 = (object)SEQ_PTR(_sym_42950);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42950 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 54);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _has_delete_42945;
    DeRef(_1);
L2B: 
L22: 

    /** c_decl.e:603		SymTab[s] = sym*/
    RefDS(_sym_42950);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_42941);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_42950;
    DeRef(_1);

    /** c_decl.e:605	end procedure*/
    DeRefDS(_val_42943);
    DeRefDS(_sym_42950);
    DeRef(_22594);
    _22594 = NOVALUE;
    DeRef(_22504);
    _22504 = NOVALUE;
    DeRef(_22602);
    _22602 = NOVALUE;
    DeRef(_22584);
    _22584 = NOVALUE;
    _22518 = NOVALUE;
    DeRef(_22499);
    _22499 = NOVALUE;
    _22513 = NOVALUE;
    return;
    ;
}


void _58CName(object _s_43240)
{
    object _v_43241 = NOVALUE;
    object _mode_43243 = NOVALUE;
    object _22675 = NOVALUE;
    object _22674 = NOVALUE;
    object _22672 = NOVALUE;
    object _22671 = NOVALUE;
    object _22670 = NOVALUE;
    object _22669 = NOVALUE;
    object _22668 = NOVALUE;
    object _22667 = NOVALUE;
    object _22666 = NOVALUE;
    object _22665 = NOVALUE;
    object _22663 = NOVALUE;
    object _22661 = NOVALUE;
    object _22660 = NOVALUE;
    object _22659 = NOVALUE;
    object _22658 = NOVALUE;
    object _22657 = NOVALUE;
    object _22656 = NOVALUE;
    object _22654 = NOVALUE;
    object _22653 = NOVALUE;
    object _22652 = NOVALUE;
    object _22651 = NOVALUE;
    object _22650 = NOVALUE;
    object _22648 = NOVALUE;
    object _22647 = NOVALUE;
    object _22646 = NOVALUE;
    object _22645 = NOVALUE;
    object _22644 = NOVALUE;
    object _22643 = NOVALUE;
    object _22641 = NOVALUE;
    object _22640 = NOVALUE;
    object _22638 = NOVALUE;
    object _22637 = NOVALUE;
    object _22636 = NOVALUE;
    object _22635 = NOVALUE;
    object _22634 = NOVALUE;
    object _22633 = NOVALUE;
    object _22632 = NOVALUE;
    object _22631 = NOVALUE;
    object _22630 = NOVALUE;
    object _22629 = NOVALUE;
    object _22628 = NOVALUE;
    object _22627 = NOVALUE;
    object _22625 = NOVALUE;
    object _22624 = NOVALUE;
    object _22620 = NOVALUE;
    object _22619 = NOVALUE;
    object _22618 = NOVALUE;
    object _22617 = NOVALUE;
    object _22616 = NOVALUE;
    object _22615 = NOVALUE;
    object _22612 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_43240)) {
        _1 = (object)(DBL_PTR(_s_43240)->dbl);
        DeRefDS(_s_43240);
        _s_43240 = _1;
    }

    /** c_decl.e:612		v = ObjValue(s)*/
    _0 = _v_43241;
    _v_43241 = _58ObjValue(_s_43240);
    DeRef(_0);

    /** c_decl.e:613		integer mode = SymTab[s][S_MODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22612 = (object)*(((s1_ptr)_2)->base + _s_43240);
    _2 = (object)SEQ_PTR(_22612);
    _mode_43243 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_43243)){
        _mode_43243 = (object)DBL_PTR(_mode_43243)->dbl;
    }
    _22612 = NOVALUE;

    /** c_decl.e:614	 	if mode = M_NORMAL then*/
    if (_mode_43243 != 1)
    goto L1; // [29] 254

    /** c_decl.e:617			if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22615 = (_58LeftSym_42564 == _13FALSE_450);
    if (_22615 == 0) {
        _22616 = 0;
        goto L2; // [43] 61
    }
    _22617 = _58GType(_s_43240);
    if (IS_ATOM_INT(_22617)) {
        _22618 = (_22617 == 1);
    }
    else {
        _22618 = binary_op(EQUALS, _22617, 1);
    }
    DeRef(_22617);
    _22617 = NOVALUE;
    if (IS_ATOM_INT(_22618))
    _22616 = (_22618 != 0);
    else
    _22616 = DBL_PTR(_22618)->dbl != 0.0;
L2: 
    if (_22616 == 0) {
        goto L3; // [61] 98
    }
    if (IS_ATOM_INT(_v_43241) && IS_ATOM_INT(_36NOVALUE_21301)) {
        _22620 = (_v_43241 != _36NOVALUE_21301);
    }
    else {
        _22620 = binary_op(NOTEQ, _v_43241, _36NOVALUE_21301);
    }
    if (_22620 == 0) {
        DeRef(_22620);
        _22620 = NOVALUE;
        goto L3; // [72] 98
    }
    else {
        if (!IS_ATOM_INT(_22620) && DBL_PTR(_22620)->dbl == 0.0){
            DeRef(_22620);
            _22620 = NOVALUE;
            goto L3; // [72] 98
        }
        DeRef(_22620);
        _22620 = NOVALUE;
    }
    DeRef(_22620);
    _22620 = NOVALUE;

    /** c_decl.e:618				c_printf("%d", v)*/
    RefDS(_22621);
    Ref(_v_43241);
    _55c_printf(_22621, _v_43241);

    /** c_decl.e:619				if TARGET_SIZEOF_POINTER = 8 then*/
    if (_36TARGET_SIZEOF_POINTER_21269 != 8)
    goto L4; // [85] 180

    /** c_decl.e:620					c_puts( "LL" )*/
    RefDS(_22623);
    _55c_puts(_22623);
    goto L4; // [95] 180
L3: 

    /** c_decl.e:623				if SymTab[s][S_SCOPE] > SC_PRIVATE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22624 = (object)*(((s1_ptr)_2)->base + _s_43240);
    _2 = (object)SEQ_PTR(_22624);
    _22625 = (object)*(((s1_ptr)_2)->base + 4);
    _22624 = NOVALUE;
    if (binary_op_a(LESSEQ, _22625, 3)){
        _22625 = NOVALUE;
        goto L5; // [114] 156
    }
    _22625 = NOVALUE;

    /** c_decl.e:624					c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22627 = (object)*(((s1_ptr)_2)->base + _s_43240);
    _2 = (object)SEQ_PTR(_22627);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _22628 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _22628 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _22627 = NOVALUE;
    RefDS(_22120);
    Ref(_22628);
    _55c_printf(_22120, _22628);
    _22628 = NOVALUE;

    /** c_decl.e:625					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22629 = (object)*(((s1_ptr)_2)->base + _s_43240);
    _2 = (object)SEQ_PTR(_22629);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _22630 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _22630 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _22629 = NOVALUE;
    Ref(_22630);
    _55c_puts(_22630);
    _22630 = NOVALUE;
    goto L6; // [153] 179
L5: 

    /** c_decl.e:627					c_puts("_")*/
    RefDS(_22069);
    _55c_puts(_22069);

    /** c_decl.e:628					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22631 = (object)*(((s1_ptr)_2)->base + _s_43240);
    _2 = (object)SEQ_PTR(_22631);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _22632 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _22632 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _22631 = NOVALUE;
    Ref(_22632);
    _55c_puts(_22632);
    _22632 = NOVALUE;
L6: 
L4: 

    /** c_decl.e:631			if s != CurrentSub and SymTab[s][S_NREFS] < 2 then*/
    _22633 = (_s_43240 != _36CurrentSub_21455);
    if (_22633 == 0) {
        goto L7; // [188] 236
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22635 = (object)*(((s1_ptr)_2)->base + _s_43240);
    _2 = (object)SEQ_PTR(_22635);
    _22636 = (object)*(((s1_ptr)_2)->base + 12);
    _22635 = NOVALUE;
    if (IS_ATOM_INT(_22636)) {
        _22637 = (_22636 < 2);
    }
    else {
        _22637 = binary_op(LESS, _22636, 2);
    }
    _22636 = NOVALUE;
    if (_22637 == 0) {
        DeRef(_22637);
        _22637 = NOVALUE;
        goto L7; // [209] 236
    }
    else {
        if (!IS_ATOM_INT(_22637) && DBL_PTR(_22637)->dbl == 0.0){
            DeRef(_22637);
            _22637 = NOVALUE;
            goto L7; // [209] 236
        }
        DeRef(_22637);
        _22637 = NOVALUE;
    }
    DeRef(_22637);
    _22637 = NOVALUE;

    /** c_decl.e:632				SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_43240 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _22640 = (object)*(((s1_ptr)_2)->base + 12);
    _22638 = NOVALUE;
    if (IS_ATOM_INT(_22640)) {
        _22641 = _22640 + 1;
        if (_22641 > MAXINT){
            _22641 = NewDouble((eudouble)_22641);
        }
    }
    else
    _22641 = binary_op(PLUS, 1, _22640);
    _22640 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22641;
    if( _1 != _22641 ){
        DeRef(_1);
    }
    _22641 = NOVALUE;
    _22638 = NOVALUE;
L7: 

    /** c_decl.e:634			SetBBType(s, TYPE_NULL, novalue, TYPE_OBJECT, 0) -- record that this var was referenced in this BB*/
    RefDS(_55novalue_46631);
    _58SetBBType(_s_43240, 0, _55novalue_46631, 16, 0);
    goto L8; // [251] 533
L1: 

    /** c_decl.e:636	 	elsif mode = M_CONSTANT then*/
    if (_mode_43243 != 2)
    goto L9; // [258] 448

    /** c_decl.e:638			if (is_integer( sym_obj( s ) ) and SymTab[s][S_GTYPE] != TYPE_DOUBLE ) or (LeftSym = FALSE and TypeIs(s, TYPE_INTEGER) and v != NOVALUE) then*/
    _22643 = _54sym_obj(_s_43240);
    _22644 = _36is_integer(_22643);
    _22643 = NOVALUE;
    if (IS_ATOM_INT(_22644)) {
        if (_22644 == 0) {
            DeRef(_22645);
            _22645 = 0;
            goto LA; // [272] 298
        }
    }
    else {
        if (DBL_PTR(_22644)->dbl == 0.0) {
            DeRef(_22645);
            _22645 = 0;
            goto LA; // [272] 298
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22646 = (object)*(((s1_ptr)_2)->base + _s_43240);
    _2 = (object)SEQ_PTR(_22646);
    _22647 = (object)*(((s1_ptr)_2)->base + 36);
    _22646 = NOVALUE;
    if (IS_ATOM_INT(_22647)) {
        _22648 = (_22647 != 2);
    }
    else {
        _22648 = binary_op(NOTEQ, _22647, 2);
    }
    _22647 = NOVALUE;
    DeRef(_22645);
    if (IS_ATOM_INT(_22648))
    _22645 = (_22648 != 0);
    else
    _22645 = DBL_PTR(_22648)->dbl != 0.0;
LA: 
    if (_22645 != 0) {
        goto LB; // [298] 344
    }
    _22650 = (_58LeftSym_42564 == _13FALSE_450);
    if (_22650 == 0) {
        _22651 = 0;
        goto LC; // [310] 325
    }
    _22652 = _58TypeIs(_s_43240, 1);
    if (IS_ATOM_INT(_22652))
    _22651 = (_22652 != 0);
    else
    _22651 = DBL_PTR(_22652)->dbl != 0.0;
LC: 
    if (_22651 == 0) {
        DeRef(_22653);
        _22653 = 0;
        goto LD; // [325] 339
    }
    if (IS_ATOM_INT(_v_43241) && IS_ATOM_INT(_36NOVALUE_21301)) {
        _22654 = (_v_43241 != _36NOVALUE_21301);
    }
    else {
        _22654 = binary_op(NOTEQ, _v_43241, _36NOVALUE_21301);
    }
    if (IS_ATOM_INT(_22654))
    _22653 = (_22654 != 0);
    else
    _22653 = DBL_PTR(_22654)->dbl != 0.0;
LD: 
    if (_22653 == 0)
    {
        _22653 = NOVALUE;
        goto LE; // [340] 367
    }
    else{
        _22653 = NOVALUE;
    }
LB: 

    /** c_decl.e:641				c_printf("%d", v)*/
    RefDS(_22621);
    Ref(_v_43241);
    _55c_printf(_22621, _v_43241);

    /** c_decl.e:642				if TARGET_SIZEOF_POINTER = 8 then*/
    if (_36TARGET_SIZEOF_POINTER_21269 != 8)
    goto L8; // [354] 533

    /** c_decl.e:643					c_puts( "LL" )*/
    RefDS(_22623);
    _55c_puts(_22623);
    goto L8; // [364] 533
LE: 

    /** c_decl.e:647				c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22656 = (object)*(((s1_ptr)_2)->base + _s_43240);
    _2 = (object)SEQ_PTR(_22656);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _22657 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _22657 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _22656 = NOVALUE;
    RefDS(_22120);
    Ref(_22657);
    _55c_printf(_22120, _22657);
    _22657 = NOVALUE;

    /** c_decl.e:648				c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22658 = (object)*(((s1_ptr)_2)->base + _s_43240);
    _2 = (object)SEQ_PTR(_22658);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _22659 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _22659 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _22658 = NOVALUE;
    Ref(_22659);
    _55c_puts(_22659);
    _22659 = NOVALUE;

    /** c_decl.e:649				if SymTab[s][S_NREFS] < 2 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22660 = (object)*(((s1_ptr)_2)->base + _s_43240);
    _2 = (object)SEQ_PTR(_22660);
    _22661 = (object)*(((s1_ptr)_2)->base + 12);
    _22660 = NOVALUE;
    if (binary_op_a(GREATEREQ, _22661, 2)){
        _22661 = NOVALUE;
        goto L8; // [416] 533
    }
    _22661 = NOVALUE;

    /** c_decl.e:650					SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_43240 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _22665 = (object)*(((s1_ptr)_2)->base + 12);
    _22663 = NOVALUE;
    if (IS_ATOM_INT(_22665)) {
        _22666 = _22665 + 1;
        if (_22666 > MAXINT){
            _22666 = NewDouble((eudouble)_22666);
        }
    }
    else
    _22666 = binary_op(PLUS, 1, _22665);
    _22665 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22666;
    if( _1 != _22666 ){
        DeRef(_1);
    }
    _22666 = NOVALUE;
    _22663 = NOVALUE;
    goto L8; // [445] 533
L9: 

    /** c_decl.e:656			if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22667 = (_58LeftSym_42564 == _13FALSE_450);
    if (_22667 == 0) {
        _22668 = 0;
        goto LF; // [458] 476
    }
    _22669 = _58GType(_s_43240);
    if (IS_ATOM_INT(_22669)) {
        _22670 = (_22669 == 1);
    }
    else {
        _22670 = binary_op(EQUALS, _22669, 1);
    }
    DeRef(_22669);
    _22669 = NOVALUE;
    if (IS_ATOM_INT(_22670))
    _22668 = (_22670 != 0);
    else
    _22668 = DBL_PTR(_22670)->dbl != 0.0;
LF: 
    if (_22668 == 0) {
        goto L10; // [476] 513
    }
    if (IS_ATOM_INT(_v_43241) && IS_ATOM_INT(_36NOVALUE_21301)) {
        _22672 = (_v_43241 != _36NOVALUE_21301);
    }
    else {
        _22672 = binary_op(NOTEQ, _v_43241, _36NOVALUE_21301);
    }
    if (_22672 == 0) {
        DeRef(_22672);
        _22672 = NOVALUE;
        goto L10; // [487] 513
    }
    else {
        if (!IS_ATOM_INT(_22672) && DBL_PTR(_22672)->dbl == 0.0){
            DeRef(_22672);
            _22672 = NOVALUE;
            goto L10; // [487] 513
        }
        DeRef(_22672);
        _22672 = NOVALUE;
    }
    DeRef(_22672);
    _22672 = NOVALUE;

    /** c_decl.e:657				c_printf("%d", v)*/
    RefDS(_22621);
    Ref(_v_43241);
    _55c_printf(_22621, _v_43241);

    /** c_decl.e:658				if TARGET_SIZEOF_POINTER = 8 then*/
    if (_36TARGET_SIZEOF_POINTER_21269 != 8)
    goto L11; // [500] 532

    /** c_decl.e:659					c_puts( "LL" )*/
    RefDS(_22623);
    _55c_puts(_22623);
    goto L11; // [510] 532
L10: 

    /** c_decl.e:662				c_printf("_%d", SymTab[s][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22674 = (object)*(((s1_ptr)_2)->base + _s_43240);
    _2 = (object)SEQ_PTR(_22674);
    _22675 = (object)*(((s1_ptr)_2)->base + 34);
    _22674 = NOVALUE;
    RefDS(_22120);
    Ref(_22675);
    _55c_printf(_22120, _22675);
    _22675 = NOVALUE;
L11: 
L8: 

    /** c_decl.e:666		LeftSym = FALSE*/
    _58LeftSym_42564 = _13FALSE_450;

    /** c_decl.e:667	end procedure*/
    DeRef(_v_43241);
    DeRef(_22633);
    _22633 = NOVALUE;
    DeRef(_22654);
    _22654 = NOVALUE;
    DeRef(_22667);
    _22667 = NOVALUE;
    DeRef(_22650);
    _22650 = NOVALUE;
    DeRef(_22648);
    _22648 = NOVALUE;
    DeRef(_22670);
    _22670 = NOVALUE;
    DeRef(_22615);
    _22615 = NOVALUE;
    DeRef(_22644);
    _22644 = NOVALUE;
    DeRef(_22652);
    _22652 = NOVALUE;
    DeRef(_22618);
    _22618 = NOVALUE;
    return;
    ;
}


void _58c_stmt(object _stmt_43388, object _arg_43389, object _lhs_arg_43391)
{
    object _argcount_43392 = NOVALUE;
    object _i_43393 = NOVALUE;
    object _22730 = NOVALUE;
    object _22729 = NOVALUE;
    object _22728 = NOVALUE;
    object _22727 = NOVALUE;
    object _22726 = NOVALUE;
    object _22725 = NOVALUE;
    object _22724 = NOVALUE;
    object _22723 = NOVALUE;
    object _22722 = NOVALUE;
    object _22721 = NOVALUE;
    object _22720 = NOVALUE;
    object _22719 = NOVALUE;
    object _22718 = NOVALUE;
    object _22717 = NOVALUE;
    object _22716 = NOVALUE;
    object _22715 = NOVALUE;
    object _22714 = NOVALUE;
    object _22712 = NOVALUE;
    object _22710 = NOVALUE;
    object _22708 = NOVALUE;
    object _22707 = NOVALUE;
    object _22706 = NOVALUE;
    object _22705 = NOVALUE;
    object _22703 = NOVALUE;
    object _22702 = NOVALUE;
    object _22701 = NOVALUE;
    object _22700 = NOVALUE;
    object _22699 = NOVALUE;
    object _22698 = NOVALUE;
    object _22697 = NOVALUE;
    object _22696 = NOVALUE;
    object _22695 = NOVALUE;
    object _22694 = NOVALUE;
    object _22693 = NOVALUE;
    object _22692 = NOVALUE;
    object _22691 = NOVALUE;
    object _22690 = NOVALUE;
    object _22687 = NOVALUE;
    object _22686 = NOVALUE;
    object _22685 = NOVALUE;
    object _22684 = NOVALUE;
    object _22683 = NOVALUE;
    object _22682 = NOVALUE;
    object _22680 = NOVALUE;
    object _22678 = NOVALUE;
    object _22677 = NOVALUE;
    object _22676 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_lhs_arg_43391)) {
        _1 = (object)(DBL_PTR(_lhs_arg_43391)->dbl);
        DeRefDS(_lhs_arg_43391);
        _lhs_arg_43391 = _1;
    }

    /** c_decl.e:675		if LAST_PASS = TRUE and Initializing = FALSE then*/
    _22676 = (_58LAST_PASS_42554 == _13TRUE_452);
    if (_22676 == 0) {
        goto L1; // [15] 47
    }
    _22678 = (_36Initializing_21531 == _13FALSE_450);
    if (_22678 == 0)
    {
        DeRef(_22678);
        _22678 = NOVALUE;
        goto L1; // [28] 47
    }
    else{
        DeRef(_22678);
        _22678 = NOVALUE;
    }

    /** c_decl.e:676			cfile_size += 1*/
    _36cfile_size_21530 = _36cfile_size_21530 + 1;

    /** c_decl.e:677			update_checksum( stmt )*/
    RefDS(_stmt_43388);
    _56update_checksum(_stmt_43388);
L1: 

    /** c_decl.e:681		if emit_c_output then*/
    if (_55emit_c_output_46624 == 0)
    {
        goto L2; // [51] 60
    }
    else{
    }

    /** c_decl.e:682			adjust_indent_before(stmt)*/
    RefDS(_stmt_43388);
    _55adjust_indent_before(_stmt_43388);
L2: 

    /** c_decl.e:685		if atom(arg) then*/
    _22680 = IS_ATOM(_arg_43389);
    if (_22680 == 0)
    {
        _22680 = NOVALUE;
        goto L3; // [65] 75
    }
    else{
        _22680 = NOVALUE;
    }

    /** c_decl.e:686			arg = {arg}*/
    _0 = _arg_43389;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_arg_43389);
    ((intptr_t*)_2)[1] = _arg_43389;
    _arg_43389 = MAKE_SEQ(_1);
    DeRef(_0);
L3: 

    /** c_decl.e:689		argcount = 1*/
    _argcount_43392 = 1;

    /** c_decl.e:690		i = 1*/
    _i_43393 = 1;

    /** c_decl.e:691		while i <= length(stmt) and length(stmt) > 0 do*/
L4: 
    if (IS_SEQUENCE(_stmt_43388)){
            _22682 = SEQ_PTR(_stmt_43388)->length;
    }
    else {
        _22682 = 1;
    }
    _22683 = (_i_43393 <= _22682);
    _22682 = NOVALUE;
    if (_22683 == 0) {
        goto L5; // [97] 435
    }
    if (IS_SEQUENCE(_stmt_43388)){
            _22685 = SEQ_PTR(_stmt_43388)->length;
    }
    else {
        _22685 = 1;
    }
    _22686 = (_22685 > 0);
    _22685 = NOVALUE;
    if (_22686 == 0)
    {
        DeRef(_22686);
        _22686 = NOVALUE;
        goto L5; // [109] 435
    }
    else{
        DeRef(_22686);
        _22686 = NOVALUE;
    }

    /** c_decl.e:692			if stmt[i] = '@' then*/
    _2 = (object)SEQ_PTR(_stmt_43388);
    _22687 = (object)*(((s1_ptr)_2)->base + _i_43393);
    if (binary_op_a(NOTEQ, _22687, 64)){
        _22687 = NOVALUE;
        goto L6; // [118] 288
    }
    _22687 = NOVALUE;

    /** c_decl.e:694				if i = 1 then*/
    if (_i_43393 != 1)
    goto L7; // [124] 138

    /** c_decl.e:695					LeftSym = TRUE*/
    _58LeftSym_42564 = _13TRUE_452;
L7: 

    /** c_decl.e:698				if i < length(stmt) and stmt[i+1] > '0' and stmt[i+1] <= '9' then*/
    if (IS_SEQUENCE(_stmt_43388)){
            _22690 = SEQ_PTR(_stmt_43388)->length;
    }
    else {
        _22690 = 1;
    }
    _22691 = (_i_43393 < _22690);
    _22690 = NOVALUE;
    if (_22691 == 0) {
        _22692 = 0;
        goto L8; // [147] 167
    }
    _22693 = _i_43393 + 1;
    _2 = (object)SEQ_PTR(_stmt_43388);
    _22694 = (object)*(((s1_ptr)_2)->base + _22693);
    if (IS_ATOM_INT(_22694)) {
        _22695 = (_22694 > 48);
    }
    else {
        _22695 = binary_op(GREATER, _22694, 48);
    }
    _22694 = NOVALUE;
    if (IS_ATOM_INT(_22695))
    _22692 = (_22695 != 0);
    else
    _22692 = DBL_PTR(_22695)->dbl != 0.0;
L8: 
    if (_22692 == 0) {
        goto L9; // [167] 249
    }
    _22697 = _i_43393 + 1;
    _2 = (object)SEQ_PTR(_stmt_43388);
    _22698 = (object)*(((s1_ptr)_2)->base + _22697);
    if (IS_ATOM_INT(_22698)) {
        _22699 = (_22698 <= 57);
    }
    else {
        _22699 = binary_op(LESSEQ, _22698, 57);
    }
    _22698 = NOVALUE;
    if (_22699 == 0) {
        DeRef(_22699);
        _22699 = NOVALUE;
        goto L9; // [184] 249
    }
    else {
        if (!IS_ATOM_INT(_22699) && DBL_PTR(_22699)->dbl == 0.0){
            DeRef(_22699);
            _22699 = NOVALUE;
            goto L9; // [184] 249
        }
        DeRef(_22699);
        _22699 = NOVALUE;
    }
    DeRef(_22699);
    _22699 = NOVALUE;

    /** c_decl.e:700					if arg[stmt[i+1]-'0'] = lhs_arg then*/
    _22700 = _i_43393 + 1;
    _2 = (object)SEQ_PTR(_stmt_43388);
    _22701 = (object)*(((s1_ptr)_2)->base + _22700);
    if (IS_ATOM_INT(_22701)) {
        _22702 = _22701 - 48;
    }
    else {
        _22702 = binary_op(MINUS, _22701, 48);
    }
    _22701 = NOVALUE;
    _2 = (object)SEQ_PTR(_arg_43389);
    if (!IS_ATOM_INT(_22702)){
        _22703 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22702)->dbl));
    }
    else{
        _22703 = (object)*(((s1_ptr)_2)->base + _22702);
    }
    if (binary_op_a(NOTEQ, _22703, _lhs_arg_43391)){
        _22703 = NOVALUE;
        goto LA; // [205] 219
    }
    _22703 = NOVALUE;

    /** c_decl.e:701						LeftSym = TRUE*/
    _58LeftSym_42564 = _13TRUE_452;
LA: 

    /** c_decl.e:703					CName(arg[stmt[i+1]-'0'])*/
    _22705 = _i_43393 + 1;
    _2 = (object)SEQ_PTR(_stmt_43388);
    _22706 = (object)*(((s1_ptr)_2)->base + _22705);
    if (IS_ATOM_INT(_22706)) {
        _22707 = _22706 - 48;
    }
    else {
        _22707 = binary_op(MINUS, _22706, 48);
    }
    _22706 = NOVALUE;
    _2 = (object)SEQ_PTR(_arg_43389);
    if (!IS_ATOM_INT(_22707)){
        _22708 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22707)->dbl));
    }
    else{
        _22708 = (object)*(((s1_ptr)_2)->base + _22707);
    }
    Ref(_22708);
    _58CName(_22708);
    _22708 = NOVALUE;

    /** c_decl.e:704					i += 1*/
    _i_43393 = _i_43393 + 1;
    goto LB; // [246] 279
L9: 

    /** c_decl.e:708					if arg[argcount] = lhs_arg then*/
    _2 = (object)SEQ_PTR(_arg_43389);
    _22710 = (object)*(((s1_ptr)_2)->base + _argcount_43392);
    if (binary_op_a(NOTEQ, _22710, _lhs_arg_43391)){
        _22710 = NOVALUE;
        goto LC; // [255] 269
    }
    _22710 = NOVALUE;

    /** c_decl.e:709						LeftSym = TRUE*/
    _58LeftSym_42564 = _13TRUE_452;
LC: 

    /** c_decl.e:711					CName(arg[argcount])*/
    _2 = (object)SEQ_PTR(_arg_43389);
    _22712 = (object)*(((s1_ptr)_2)->base + _argcount_43392);
    Ref(_22712);
    _58CName(_22712);
    _22712 = NOVALUE;
LB: 

    /** c_decl.e:714				argcount += 1*/
    _argcount_43392 = _argcount_43392 + 1;
    goto LD; // [285] 353
L6: 

    /** c_decl.e:717				c_putc(stmt[i])*/
    _2 = (object)SEQ_PTR(_stmt_43388);
    _22714 = (object)*(((s1_ptr)_2)->base + _i_43393);
    Ref(_22714);
    _55c_putc(_22714);
    _22714 = NOVALUE;

    /** c_decl.e:718				if stmt[i] = '&' and i < length(stmt) and stmt[i+1] = '@' then*/
    _2 = (object)SEQ_PTR(_stmt_43388);
    _22715 = (object)*(((s1_ptr)_2)->base + _i_43393);
    if (IS_ATOM_INT(_22715)) {
        _22716 = (_22715 == 38);
    }
    else {
        _22716 = binary_op(EQUALS, _22715, 38);
    }
    _22715 = NOVALUE;
    if (IS_ATOM_INT(_22716)) {
        if (_22716 == 0) {
            DeRef(_22717);
            _22717 = 0;
            goto LE; // [307] 322
        }
    }
    else {
        if (DBL_PTR(_22716)->dbl == 0.0) {
            DeRef(_22717);
            _22717 = 0;
            goto LE; // [307] 322
        }
    }
    if (IS_SEQUENCE(_stmt_43388)){
            _22718 = SEQ_PTR(_stmt_43388)->length;
    }
    else {
        _22718 = 1;
    }
    _22719 = (_i_43393 < _22718);
    _22718 = NOVALUE;
    DeRef(_22717);
    _22717 = (_22719 != 0);
LE: 
    if (_22717 == 0) {
        goto LF; // [322] 352
    }
    _22721 = _i_43393 + 1;
    _2 = (object)SEQ_PTR(_stmt_43388);
    _22722 = (object)*(((s1_ptr)_2)->base + _22721);
    if (IS_ATOM_INT(_22722)) {
        _22723 = (_22722 == 64);
    }
    else {
        _22723 = binary_op(EQUALS, _22722, 64);
    }
    _22722 = NOVALUE;
    if (_22723 == 0) {
        DeRef(_22723);
        _22723 = NOVALUE;
        goto LF; // [339] 352
    }
    else {
        if (!IS_ATOM_INT(_22723) && DBL_PTR(_22723)->dbl == 0.0){
            DeRef(_22723);
            _22723 = NOVALUE;
            goto LF; // [339] 352
        }
        DeRef(_22723);
        _22723 = NOVALUE;
    }
    DeRef(_22723);
    _22723 = NOVALUE;

    /** c_decl.e:719					LeftSym = TRUE -- never say: x = x &y or andy - always leave space*/
    _58LeftSym_42564 = _13TRUE_452;
LF: 
LD: 

    /** c_decl.e:723			if stmt[i] = '\n' and i < length(stmt) then*/
    _2 = (object)SEQ_PTR(_stmt_43388);
    _22724 = (object)*(((s1_ptr)_2)->base + _i_43393);
    if (IS_ATOM_INT(_22724)) {
        _22725 = (_22724 == 10);
    }
    else {
        _22725 = binary_op(EQUALS, _22724, 10);
    }
    _22724 = NOVALUE;
    if (IS_ATOM_INT(_22725)) {
        if (_22725 == 0) {
            goto L10; // [363] 424
        }
    }
    else {
        if (DBL_PTR(_22725)->dbl == 0.0) {
            goto L10; // [363] 424
        }
    }
    if (IS_SEQUENCE(_stmt_43388)){
            _22727 = SEQ_PTR(_stmt_43388)->length;
    }
    else {
        _22727 = 1;
    }
    _22728 = (_i_43393 < _22727);
    _22727 = NOVALUE;
    if (_22728 == 0)
    {
        DeRef(_22728);
        _22728 = NOVALUE;
        goto L10; // [375] 424
    }
    else{
        DeRef(_22728);
        _22728 = NOVALUE;
    }

    /** c_decl.e:724				if emit_c_output then*/
    if (_55emit_c_output_46624 == 0)
    {
        goto L11; // [382] 391
    }
    else{
    }

    /** c_decl.e:725					adjust_indent_after(stmt)*/
    RefDS(_stmt_43388);
    _55adjust_indent_after(_stmt_43388);
L11: 

    /** c_decl.e:727				stmt = stmt[i+1..$]*/
    _22729 = _i_43393 + 1;
    if (_22729 > MAXINT){
        _22729 = NewDouble((eudouble)_22729);
    }
    if (IS_SEQUENCE(_stmt_43388)){
            _22730 = SEQ_PTR(_stmt_43388)->length;
    }
    else {
        _22730 = 1;
    }
    rhs_slice_target = (object_ptr)&_stmt_43388;
    RHS_Slice(_stmt_43388, _22729, _22730);

    /** c_decl.e:728				i = 0*/
    _i_43393 = 0;

    /** c_decl.e:729				if emit_c_output then*/
    if (_55emit_c_output_46624 == 0)
    {
        goto L12; // [414] 423
    }
    else{
    }

    /** c_decl.e:730					adjust_indent_before(stmt)*/
    RefDS(_stmt_43388);
    _55adjust_indent_before(_stmt_43388);
L12: 
L10: 

    /** c_decl.e:734			i += 1*/
    _i_43393 = _i_43393 + 1;

    /** c_decl.e:735		end while*/
    goto L4; // [432] 90
L5: 

    /** c_decl.e:737		if emit_c_output then*/
    if (_55emit_c_output_46624 == 0)
    {
        goto L13; // [439] 448
    }
    else{
    }

    /** c_decl.e:738			adjust_indent_after(stmt)*/
    RefDS(_stmt_43388);
    _55adjust_indent_after(_stmt_43388);
L13: 

    /** c_decl.e:740	end procedure*/
    DeRefDS(_stmt_43388);
    DeRef(_arg_43389);
    DeRef(_22705);
    _22705 = NOVALUE;
    DeRef(_22697);
    _22697 = NOVALUE;
    DeRef(_22700);
    _22700 = NOVALUE;
    DeRef(_22719);
    _22719 = NOVALUE;
    DeRef(_22683);
    _22683 = NOVALUE;
    DeRef(_22693);
    _22693 = NOVALUE;
    DeRef(_22725);
    _22725 = NOVALUE;
    DeRef(_22707);
    _22707 = NOVALUE;
    DeRef(_22695);
    _22695 = NOVALUE;
    DeRef(_22691);
    _22691 = NOVALUE;
    DeRef(_22729);
    _22729 = NOVALUE;
    DeRef(_22676);
    _22676 = NOVALUE;
    DeRef(_22716);
    _22716 = NOVALUE;
    DeRef(_22721);
    _22721 = NOVALUE;
    DeRef(_22702);
    _22702 = NOVALUE;
    return;
    ;
}


void _58c_stmt0(object _stmt_43487)
{
    object _0, _1, _2;
    

    /** c_decl.e:745		if emit_c_output then*/
    if (_55emit_c_output_46624 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** c_decl.e:746			c_stmt(stmt, {})*/
    RefDS(_stmt_43487);
    RefDS(_21997);
    _58c_stmt(_stmt_43487, _21997, 0);
L1: 

    /** c_decl.e:748	end procedure*/
    DeRefDS(_stmt_43487);
    return;
    ;
}


object _58needs_uninit(object _eentry_43492)
{
    object _22753 = NOVALUE;
    object _22752 = NOVALUE;
    object _22751 = NOVALUE;
    object _22750 = NOVALUE;
    object _22749 = NOVALUE;
    object _22748 = NOVALUE;
    object _22747 = NOVALUE;
    object _22746 = NOVALUE;
    object _22745 = NOVALUE;
    object _22744 = NOVALUE;
    object _22743 = NOVALUE;
    object _22742 = NOVALUE;
    object _22741 = NOVALUE;
    object _22740 = NOVALUE;
    object _22739 = NOVALUE;
    object _22738 = NOVALUE;
    object _22737 = NOVALUE;
    object _22736 = NOVALUE;
    object _22735 = NOVALUE;
    object _22734 = NOVALUE;
    object _22733 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:751		if eentry[S_SCOPE] >= SC_LOCAL*/
    _2 = (object)SEQ_PTR(_eentry_43492);
    _22733 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22733)) {
        _22734 = (_22733 >= 5);
    }
    else {
        _22734 = binary_op(GREATEREQ, _22733, 5);
    }
    _22733 = NOVALUE;
    if (IS_ATOM_INT(_22734)) {
        if (_22734 == 0) {
            _22735 = 0;
            goto L1; // [17] 77
        }
    }
    else {
        if (DBL_PTR(_22734)->dbl == 0.0) {
            _22735 = 0;
            goto L1; // [17] 77
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43492);
    _22736 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22736)) {
        _22737 = (_22736 <= 6);
    }
    else {
        _22737 = binary_op(LESSEQ, _22736, 6);
    }
    _22736 = NOVALUE;
    if (IS_ATOM_INT(_22737)) {
        if (_22737 != 0) {
            _22738 = 1;
            goto L2; // [33] 53
        }
    }
    else {
        if (DBL_PTR(_22737)->dbl != 0.0) {
            _22738 = 1;
            goto L2; // [33] 53
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43492);
    _22739 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22739)) {
        _22740 = (_22739 == 11);
    }
    else {
        _22740 = binary_op(EQUALS, _22739, 11);
    }
    _22739 = NOVALUE;
    DeRef(_22738);
    if (IS_ATOM_INT(_22740))
    _22738 = (_22740 != 0);
    else
    _22738 = DBL_PTR(_22740)->dbl != 0.0;
L2: 
    if (_22738 != 0) {
        _22741 = 1;
        goto L3; // [53] 73
    }
    _2 = (object)SEQ_PTR(_eentry_43492);
    _22742 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22742)) {
        _22743 = (_22742 == 13);
    }
    else {
        _22743 = binary_op(EQUALS, _22742, 13);
    }
    _22742 = NOVALUE;
    if (IS_ATOM_INT(_22743))
    _22741 = (_22743 != 0);
    else
    _22741 = DBL_PTR(_22743)->dbl != 0.0;
L3: 
    DeRef(_22735);
    _22735 = (_22741 != 0);
L1: 
    if (_22735 == 0) {
        _22744 = 0;
        goto L4; // [77] 97
    }
    _2 = (object)SEQ_PTR(_eentry_43492);
    _22745 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22745)) {
        _22746 = (_22745 != 0);
    }
    else {
        _22746 = binary_op(NOTEQ, _22745, 0);
    }
    _22745 = NOVALUE;
    if (IS_ATOM_INT(_22746))
    _22744 = (_22746 != 0);
    else
    _22744 = DBL_PTR(_22746)->dbl != 0.0;
L4: 
    if (_22744 == 0) {
        _22747 = 0;
        goto L5; // [97] 117
    }
    _2 = (object)SEQ_PTR(_eentry_43492);
    _22748 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22748)) {
        _22749 = (_22748 != 99);
    }
    else {
        _22749 = binary_op(NOTEQ, _22748, 99);
    }
    _22748 = NOVALUE;
    if (IS_ATOM_INT(_22749))
    _22747 = (_22749 != 0);
    else
    _22747 = DBL_PTR(_22749)->dbl != 0.0;
L5: 
    if (_22747 == 0) {
        goto L6; // [117] 150
    }
    _2 = (object)SEQ_PTR(_eentry_43492);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _22751 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _22751 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    _22752 = find_from(_22751, _38RTN_TOKS_16045, 1);
    _22751 = NOVALUE;
    _22753 = (_22752 == 0);
    _22752 = NOVALUE;
    if (_22753 == 0)
    {
        DeRef(_22753);
        _22753 = NOVALUE;
        goto L6; // [138] 150
    }
    else{
        DeRef(_22753);
        _22753 = NOVALUE;
    }

    /** c_decl.e:757			return 1*/
    DeRefDS(_eentry_43492);
    DeRef(_22743);
    _22743 = NOVALUE;
    DeRef(_22734);
    _22734 = NOVALUE;
    DeRef(_22749);
    _22749 = NOVALUE;
    DeRef(_22737);
    _22737 = NOVALUE;
    DeRef(_22740);
    _22740 = NOVALUE;
    DeRef(_22746);
    _22746 = NOVALUE;
    return 1;
    goto L7; // [147] 157
L6: 

    /** c_decl.e:759			return 0*/
    DeRefDS(_eentry_43492);
    DeRef(_22743);
    _22743 = NOVALUE;
    DeRef(_22734);
    _22734 = NOVALUE;
    DeRef(_22749);
    _22749 = NOVALUE;
    DeRef(_22737);
    _22737 = NOVALUE;
    DeRef(_22740);
    _22740 = NOVALUE;
    DeRef(_22746);
    _22746 = NOVALUE;
    return 0;
L7: 
    ;
}


void _58DeclareFileVars()
{
    object _s_43533 = NOVALUE;
    object _eentry_43535 = NOVALUE;
    object _cleanup_vars_43629 = NOVALUE;
    object _22836 = NOVALUE;
    object _22829 = NOVALUE;
    object _22824 = NOVALUE;
    object _22821 = NOVALUE;
    object _22820 = NOVALUE;
    object _22819 = NOVALUE;
    object _22817 = NOVALUE;
    object _22813 = NOVALUE;
    object _22809 = NOVALUE;
    object _22806 = NOVALUE;
    object _22805 = NOVALUE;
    object _22804 = NOVALUE;
    object _22802 = NOVALUE;
    object _22798 = NOVALUE;
    object _22794 = NOVALUE;
    object _22793 = NOVALUE;
    object _22792 = NOVALUE;
    object _22789 = NOVALUE;
    object _22788 = NOVALUE;
    object _22786 = NOVALUE;
    object _22785 = NOVALUE;
    object _22784 = NOVALUE;
    object _22783 = NOVALUE;
    object _22779 = NOVALUE;
    object _22778 = NOVALUE;
    object _22777 = NOVALUE;
    object _22776 = NOVALUE;
    object _22775 = NOVALUE;
    object _22774 = NOVALUE;
    object _22773 = NOVALUE;
    object _22772 = NOVALUE;
    object _22771 = NOVALUE;
    object _22770 = NOVALUE;
    object _22769 = NOVALUE;
    object _22768 = NOVALUE;
    object _22767 = NOVALUE;
    object _22766 = NOVALUE;
    object _22765 = NOVALUE;
    object _22764 = NOVALUE;
    object _22763 = NOVALUE;
    object _22762 = NOVALUE;
    object _22761 = NOVALUE;
    object _22760 = NOVALUE;
    object _22759 = NOVALUE;
    object _22758 = NOVALUE;
    object _22755 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:769		c_puts("// Declaring file vars\n")*/
    RefDS(_22754);
    _55c_puts(_22754);

    /** c_decl.e:770		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22755 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21454);
    _2 = (object)SEQ_PTR(_22755);
    _s_43533 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43533)){
        _s_43533 = (object)DBL_PTR(_s_43533)->dbl;
    }
    _22755 = NOVALUE;

    /** c_decl.e:772		while s do*/
L1: 
    if (_s_43533 == 0)
    {
        goto L2; // [29] 328
    }
    else{
    }

    /** c_decl.e:773			eentry = SymTab[s]*/
    DeRef(_eentry_43535);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _eentry_43535 = (object)*(((s1_ptr)_2)->base + _s_43533);
    Ref(_eentry_43535);

    /** c_decl.e:774			if eentry[S_SCOPE] >= SC_LOCAL*/
    _2 = (object)SEQ_PTR(_eentry_43535);
    _22758 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22758)) {
        _22759 = (_22758 >= 5);
    }
    else {
        _22759 = binary_op(GREATEREQ, _22758, 5);
    }
    _22758 = NOVALUE;
    if (IS_ATOM_INT(_22759)) {
        if (_22759 == 0) {
            DeRef(_22760);
            _22760 = 0;
            goto L3; // [56] 116
        }
    }
    else {
        if (DBL_PTR(_22759)->dbl == 0.0) {
            DeRef(_22760);
            _22760 = 0;
            goto L3; // [56] 116
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43535);
    _22761 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22761)) {
        _22762 = (_22761 <= 6);
    }
    else {
        _22762 = binary_op(LESSEQ, _22761, 6);
    }
    _22761 = NOVALUE;
    if (IS_ATOM_INT(_22762)) {
        if (_22762 != 0) {
            DeRef(_22763);
            _22763 = 1;
            goto L4; // [72] 92
        }
    }
    else {
        if (DBL_PTR(_22762)->dbl != 0.0) {
            DeRef(_22763);
            _22763 = 1;
            goto L4; // [72] 92
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43535);
    _22764 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22764)) {
        _22765 = (_22764 == 11);
    }
    else {
        _22765 = binary_op(EQUALS, _22764, 11);
    }
    _22764 = NOVALUE;
    DeRef(_22763);
    if (IS_ATOM_INT(_22765))
    _22763 = (_22765 != 0);
    else
    _22763 = DBL_PTR(_22765)->dbl != 0.0;
L4: 
    if (_22763 != 0) {
        _22766 = 1;
        goto L5; // [92] 112
    }
    _2 = (object)SEQ_PTR(_eentry_43535);
    _22767 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22767)) {
        _22768 = (_22767 == 13);
    }
    else {
        _22768 = binary_op(EQUALS, _22767, 13);
    }
    _22767 = NOVALUE;
    if (IS_ATOM_INT(_22768))
    _22766 = (_22768 != 0);
    else
    _22766 = DBL_PTR(_22768)->dbl != 0.0;
L5: 
    DeRef(_22760);
    _22760 = (_22766 != 0);
L3: 
    if (_22760 == 0) {
        _22769 = 0;
        goto L6; // [116] 136
    }
    _2 = (object)SEQ_PTR(_eentry_43535);
    _22770 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22770)) {
        _22771 = (_22770 != 0);
    }
    else {
        _22771 = binary_op(NOTEQ, _22770, 0);
    }
    _22770 = NOVALUE;
    if (IS_ATOM_INT(_22771))
    _22769 = (_22771 != 0);
    else
    _22769 = DBL_PTR(_22771)->dbl != 0.0;
L6: 
    if (_22769 == 0) {
        _22772 = 0;
        goto L7; // [136] 156
    }
    _2 = (object)SEQ_PTR(_eentry_43535);
    _22773 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22773)) {
        _22774 = (_22773 != 99);
    }
    else {
        _22774 = binary_op(NOTEQ, _22773, 99);
    }
    _22773 = NOVALUE;
    if (IS_ATOM_INT(_22774))
    _22772 = (_22774 != 0);
    else
    _22772 = DBL_PTR(_22774)->dbl != 0.0;
L7: 
    if (_22772 == 0) {
        goto L8; // [156] 307
    }
    _2 = (object)SEQ_PTR(_eentry_43535);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _22776 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _22776 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    _22777 = find_from(_22776, _38RTN_TOKS_16045, 1);
    _22776 = NOVALUE;
    _22778 = (_22777 == 0);
    _22777 = NOVALUE;
    if (_22778 == 0)
    {
        DeRef(_22778);
        _22778 = NOVALUE;
        goto L8; // [177] 307
    }
    else{
        DeRef(_22778);
        _22778 = NOVALUE;
    }

    /** c_decl.e:780				if eentry[S_TOKEN] = PROC then*/
    _2 = (object)SEQ_PTR(_eentry_43535);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _22779 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _22779 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    if (binary_op_a(NOTEQ, _22779, 27)){
        _22779 = NOVALUE;
        goto L9; // [190] 202
    }
    _22779 = NOVALUE;

    /** c_decl.e:781					c_puts( "void ")*/
    RefDS(_22781);
    _55c_puts(_22781);
    goto LA; // [199] 208
L9: 

    /** c_decl.e:783					c_puts("object ")*/
    RefDS(_22782);
    _55c_puts(_22782);
LA: 

    /** c_decl.e:785				c_printf("_%d", eentry[S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_eentry_43535);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _22783 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _22783 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    RefDS(_22120);
    Ref(_22783);
    _55c_printf(_22120, _22783);
    _22783 = NOVALUE;

    /** c_decl.e:786				c_puts(eentry[S_NAME])*/
    _2 = (object)SEQ_PTR(_eentry_43535);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _22784 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _22784 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    Ref(_22784);
    _55c_puts(_22784);
    _22784 = NOVALUE;

    /** c_decl.e:787				if is_integer( eentry[S_OBJ] ) then*/
    _2 = (object)SEQ_PTR(_eentry_43535);
    _22785 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22785);
    _22786 = _36is_integer(_22785);
    _22785 = NOVALUE;
    if (_22786 == 0) {
        DeRef(_22786);
        _22786 = NOVALUE;
        goto LB; // [243] 267
    }
    else {
        if (!IS_ATOM_INT(_22786) && DBL_PTR(_22786)->dbl == 0.0){
            DeRef(_22786);
            _22786 = NOVALUE;
            goto LB; // [243] 267
        }
        DeRef(_22786);
        _22786 = NOVALUE;
    }
    DeRef(_22786);
    _22786 = NOVALUE;

    /** c_decl.e:788						c_printf(" = %d%s;\n", { eentry[S_OBJ], LL_suffix} )*/
    _2 = (object)SEQ_PTR(_eentry_43535);
    _22788 = (object)*(((s1_ptr)_2)->base + 1);
    RefDS(_59LL_suffix_30009);
    Ref(_22788);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _22788;
    ((intptr_t *)_2)[2] = _59LL_suffix_30009;
    _22789 = MAKE_SEQ(_1);
    _22788 = NOVALUE;
    RefDS(_22787);
    _55c_printf(_22787, _22789);
    _22789 = NOVALUE;
    goto LC; // [264] 273
LB: 

    /** c_decl.e:790					c_puts(" = NOVALUE;\n")*/
    RefDS(_22790);
    _55c_puts(_22790);
LC: 

    /** c_decl.e:793				c_hputs("extern object ")*/
    RefDS(_22791);
    _55c_hputs(_22791);

    /** c_decl.e:794				c_hprintf("_%d", eentry[S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_eentry_43535);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _22792 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _22792 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    RefDS(_22120);
    Ref(_22792);
    _55c_hprintf(_22120, _22792);
    _22792 = NOVALUE;

    /** c_decl.e:795				c_hputs(eentry[S_NAME])*/
    _2 = (object)SEQ_PTR(_eentry_43535);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _22793 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _22793 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    Ref(_22793);
    _55c_hputs(_22793);
    _22793 = NOVALUE;

    /** c_decl.e:797				c_hputs(";\n")*/
    RefDS(_22273);
    _55c_hputs(_22273);
L8: 

    /** c_decl.e:799			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22794 = (object)*(((s1_ptr)_2)->base + _s_43533);
    _2 = (object)SEQ_PTR(_22794);
    _s_43533 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43533)){
        _s_43533 = (object)DBL_PTR(_s_43533)->dbl;
    }
    _22794 = NOVALUE;

    /** c_decl.e:800		end while*/
    goto L1; // [325] 29
L2: 

    /** c_decl.e:801		c_puts("\n")*/
    RefDS(_22192);
    _55c_puts(_22192);

    /** c_decl.e:802		c_hputs("\n")*/
    RefDS(_22192);
    _55c_hputs(_22192);

    /** c_decl.e:803		if dll_option or debug_option then*/
    if (_58dll_option_42567 != 0) {
        goto LD; // [342] 353
    }
    if (_58debug_option_42577 == 0)
    {
        goto LE; // [349] 707
    }
    else{
    }
LD: 

    /** c_decl.e:804			integer cleanup_vars = 0*/
    _cleanup_vars_43629 = 0;

    /** c_decl.e:805			c_puts("// Declaring var array for cleanup\n")*/
    RefDS(_22797);
    _55c_puts(_22797);

    /** c_decl.e:806			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22798 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21454);
    _2 = (object)SEQ_PTR(_22798);
    _s_43533 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43533)){
        _s_43533 = (object)DBL_PTR(_s_43533)->dbl;
    }
    _22798 = NOVALUE;

    /** c_decl.e:807			c_stmt0( "object_ptr _0var_cleanup[] = {\n" )*/
    RefDS(_22800);
    _58c_stmt0(_22800);

    /** c_decl.e:808			while s do*/
LF: 
    if (_s_43533 == 0)
    {
        goto L10; // [391] 473
    }
    else{
    }

    /** c_decl.e:809				eentry = SymTab[s]*/
    DeRef(_eentry_43535);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _eentry_43535 = (object)*(((s1_ptr)_2)->base + _s_43533);
    Ref(_eentry_43535);

    /** c_decl.e:810				if needs_uninit( eentry ) then*/
    RefDS(_eentry_43535);
    _22802 = _58needs_uninit(_eentry_43535);
    if (_22802 == 0) {
        DeRef(_22802);
        _22802 = NOVALUE;
        goto L11; // [410] 452
    }
    else {
        if (!IS_ATOM_INT(_22802) && DBL_PTR(_22802)->dbl == 0.0){
            DeRef(_22802);
            _22802 = NOVALUE;
            goto L11; // [410] 452
        }
        DeRef(_22802);
        _22802 = NOVALUE;
    }
    DeRef(_22802);
    _22802 = NOVALUE;

    /** c_decl.e:812					c_stmt0( sprintf("&_%d", eentry[S_FILE_NO]))*/
    _2 = (object)SEQ_PTR(_eentry_43535);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _22804 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _22804 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _22805 = EPrintf(-9999999, _22803, _22804);
    _22804 = NOVALUE;
    _58c_stmt0(_22805);
    _22805 = NOVALUE;

    /** c_decl.e:813					c_puts(eentry[S_NAME] )*/
    _2 = (object)SEQ_PTR(_eentry_43535);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _22806 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _22806 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    Ref(_22806);
    _55c_puts(_22806);
    _22806 = NOVALUE;

    /** c_decl.e:814					c_printf(", // %d\n", cleanup_vars )*/
    RefDS(_22807);
    _55c_printf(_22807, _cleanup_vars_43629);

    /** c_decl.e:815					cleanup_vars += 1*/
    _cleanup_vars_43629 = _cleanup_vars_43629 + 1;
L11: 

    /** c_decl.e:818				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22809 = (object)*(((s1_ptr)_2)->base + _s_43533);
    _2 = (object)SEQ_PTR(_22809);
    _s_43533 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43533)){
        _s_43533 = (object)DBL_PTR(_s_43533)->dbl;
    }
    _22809 = NOVALUE;

    /** c_decl.e:819			end while*/
    goto LF; // [470] 391
L10: 

    /** c_decl.e:820			c_stmt0( "0\n" )*/
    RefDS(_22811);
    _58c_stmt0(_22811);

    /** c_decl.e:821			c_stmt0( "};\n" )*/
    RefDS(_22812);
    _58c_stmt0(_22812);

    /** c_decl.e:822			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22813 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21454);
    _2 = (object)SEQ_PTR(_22813);
    _s_43533 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43533)){
        _s_43533 = (object)DBL_PTR(_s_43533)->dbl;
    }
    _22813 = NOVALUE;

    /** c_decl.e:823			c_stmt0( "char *_0var_cleanup_name[] = {\n" )*/
    RefDS(_22815);
    _58c_stmt0(_22815);

    /** c_decl.e:824			cleanup_vars = 0*/
    _cleanup_vars_43629 = 0;

    /** c_decl.e:825			while s do*/
L12: 
    if (_s_43533 == 0)
    {
        goto L13; // [516] 598
    }
    else{
    }

    /** c_decl.e:826				eentry = SymTab[s]*/
    DeRef(_eentry_43535);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _eentry_43535 = (object)*(((s1_ptr)_2)->base + _s_43533);
    Ref(_eentry_43535);

    /** c_decl.e:827				if needs_uninit( eentry ) then*/
    RefDS(_eentry_43535);
    _22817 = _58needs_uninit(_eentry_43535);
    if (_22817 == 0) {
        DeRef(_22817);
        _22817 = NOVALUE;
        goto L14; // [535] 577
    }
    else {
        if (!IS_ATOM_INT(_22817) && DBL_PTR(_22817)->dbl == 0.0){
            DeRef(_22817);
            _22817 = NOVALUE;
            goto L14; // [535] 577
        }
        DeRef(_22817);
        _22817 = NOVALUE;
    }
    DeRef(_22817);
    _22817 = NOVALUE;

    /** c_decl.e:828					c_stmt0( sprintf("\"_%d", eentry[S_FILE_NO]))*/
    _2 = (object)SEQ_PTR(_eentry_43535);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _22819 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _22819 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _22820 = EPrintf(-9999999, _22818, _22819);
    _22819 = NOVALUE;
    _58c_stmt0(_22820);
    _22820 = NOVALUE;

    /** c_decl.e:829					c_puts(eentry[S_NAME] )*/
    _2 = (object)SEQ_PTR(_eentry_43535);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _22821 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _22821 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    Ref(_22821);
    _55c_puts(_22821);
    _22821 = NOVALUE;

    /** c_decl.e:830					c_printf("\", // %d\n", cleanup_vars )*/
    RefDS(_22822);
    _55c_printf(_22822, _cleanup_vars_43629);

    /** c_decl.e:831					cleanup_vars += 1*/
    _cleanup_vars_43629 = _cleanup_vars_43629 + 1;
L14: 

    /** c_decl.e:834				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22824 = (object)*(((s1_ptr)_2)->base + _s_43533);
    _2 = (object)SEQ_PTR(_22824);
    _s_43533 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43533)){
        _s_43533 = (object)DBL_PTR(_s_43533)->dbl;
    }
    _22824 = NOVALUE;

    /** c_decl.e:835			end while*/
    goto L12; // [595] 516
L13: 

    /** c_decl.e:836			c_stmt0( "0\n" )*/
    RefDS(_22811);
    _58c_stmt0(_22811);

    /** c_decl.e:837			c_stmt0( "};\n" )*/
    RefDS(_22812);
    _58c_stmt0(_22812);

    /** c_decl.e:838			c_stmt0( "void _0cleanup_vars(){\n" )*/
    RefDS(_22826);
    _58c_stmt0(_22826);

    /** c_decl.e:839				c_stmt0( "int i;\n" )*/
    RefDS(_22081);
    _58c_stmt0(_22081);

    /** c_decl.e:840				c_stmt0( "object x;\n" )*/
    RefDS(_22827);
    _58c_stmt0(_22827);

    /** c_decl.e:841				c_stmt0( sprintf( "for( i = 0; i < %d; ++i ){\n", cleanup_vars ) )*/
    _22829 = EPrintf(-9999999, _22828, _cleanup_vars_43629);
    _58c_stmt0(_22829);
    _22829 = NOVALUE;

    /** c_decl.e:842					c_stmt0( "x = *_0var_cleanup[i];\n" )*/
    RefDS(_22830);
    _58c_stmt0(_22830);

    //c_decl.e:843					c_stmt0( "if( x >= NOVALUE ) /* do nothing */;\n" )
    RefDS(_22831);
    _58c_stmt0(_22831);

    /** c_decl.e:844					c_stmt0( "else if ( IS_ATOM_DBL( x ) && DBL_PTR( x )->cleanup != 0) {\n")*/
    RefDS(_22832);
    _58c_stmt0(_22832);

    /** c_decl.e:845						c_stmt0( "cleanup_double( DBL_PTR( x ) );\n")*/
    RefDS(_22833);
    _58c_stmt0(_22833);

    /** c_decl.e:846					c_stmt0( "}\n" )*/
    RefDS(_15976);
    _58c_stmt0(_15976);

    /** c_decl.e:847						c_stmt0( "else if (IS_SEQUENCE( x ) && SEQ_PTR( x )->cleanup != 0 ) {\n")*/
    RefDS(_22834);
    _58c_stmt0(_22834);

    /** c_decl.e:848						c_stmt0( "cleanup_sequence( SEQ_PTR( x ) );\n")*/
    RefDS(_22835);
    _58c_stmt0(_22835);

    /** c_decl.e:849					c_stmt0( "}\n" )*/
    RefDS(_15976);
    _58c_stmt0(_15976);

    /** c_decl.e:850				c_stmt0( "}\n" )*/
    RefDS(_15976);
    _58c_stmt0(_15976);

    /** c_decl.e:851				c_stmt0( sprintf( "for( i = 0; i < %d; ++i ){\n", cleanup_vars ) )*/
    _22836 = EPrintf(-9999999, _22828, _cleanup_vars_43629);
    _58c_stmt0(_22836);
    _22836 = NOVALUE;

    /** c_decl.e:852					c_stmt0( "DeRef( *_0var_cleanup[i] );\n" )*/
    RefDS(_22837);
    _58c_stmt0(_22837);

    /** c_decl.e:853					c_stmt0( "*_0var_cleanup[i] = NOVALUE;\n" )*/
    RefDS(_22838);
    _58c_stmt0(_22838);

    /** c_decl.e:854				c_stmt0( "}\n" )*/
    RefDS(_15976);
    _58c_stmt0(_15976);

    /** c_decl.e:855			c_stmt0( "}\n" )*/
    RefDS(_15976);
    _58c_stmt0(_15976);
LE: 

    /** c_decl.e:857	end procedure*/
    DeRef(_eentry_43535);
    DeRef(_22771);
    _22771 = NOVALUE;
    DeRef(_22762);
    _22762 = NOVALUE;
    DeRef(_22765);
    _22765 = NOVALUE;
    DeRef(_22774);
    _22774 = NOVALUE;
    DeRef(_22759);
    _22759 = NOVALUE;
    DeRef(_22768);
    _22768 = NOVALUE;
    return;
    ;
}


object _58PromoteTypeInfo()
{
    object _updsym_43700 = NOVALUE;
    object _s_43702 = NOVALUE;
    object _sym_43703 = NOVALUE;
    object _symo_43704 = NOVALUE;
    object _upd_43933 = NOVALUE;
    object _22937 = NOVALUE;
    object _22935 = NOVALUE;
    object _22934 = NOVALUE;
    object _22933 = NOVALUE;
    object _22932 = NOVALUE;
    object _22930 = NOVALUE;
    object _22928 = NOVALUE;
    object _22927 = NOVALUE;
    object _22926 = NOVALUE;
    object _22925 = NOVALUE;
    object _22924 = NOVALUE;
    object _22920 = NOVALUE;
    object _22917 = NOVALUE;
    object _22916 = NOVALUE;
    object _22915 = NOVALUE;
    object _22914 = NOVALUE;
    object _22913 = NOVALUE;
    object _22912 = NOVALUE;
    object _22911 = NOVALUE;
    object _22910 = NOVALUE;
    object _22909 = NOVALUE;
    object _22908 = NOVALUE;
    object _22907 = NOVALUE;
    object _22905 = NOVALUE;
    object _22904 = NOVALUE;
    object _22903 = NOVALUE;
    object _22902 = NOVALUE;
    object _22901 = NOVALUE;
    object _22900 = NOVALUE;
    object _22899 = NOVALUE;
    object _22898 = NOVALUE;
    object _22897 = NOVALUE;
    object _22896 = NOVALUE;
    object _22894 = NOVALUE;
    object _22893 = NOVALUE;
    object _22892 = NOVALUE;
    object _22890 = NOVALUE;
    object _22889 = NOVALUE;
    object _22888 = NOVALUE;
    object _22886 = NOVALUE;
    object _22885 = NOVALUE;
    object _22884 = NOVALUE;
    object _22883 = NOVALUE;
    object _22882 = NOVALUE;
    object _22881 = NOVALUE;
    object _22880 = NOVALUE;
    object _22878 = NOVALUE;
    object _22877 = NOVALUE;
    object _22876 = NOVALUE;
    object _22875 = NOVALUE;
    object _22873 = NOVALUE;
    object _22872 = NOVALUE;
    object _22870 = NOVALUE;
    object _22869 = NOVALUE;
    object _22868 = NOVALUE;
    object _22867 = NOVALUE;
    object _22866 = NOVALUE;
    object _22865 = NOVALUE;
    object _22864 = NOVALUE;
    object _22862 = NOVALUE;
    object _22861 = NOVALUE;
    object _22860 = NOVALUE;
    object _22859 = NOVALUE;
    object _22858 = NOVALUE;
    object _22857 = NOVALUE;
    object _22856 = NOVALUE;
    object _22855 = NOVALUE;
    object _22854 = NOVALUE;
    object _22853 = NOVALUE;
    object _22852 = NOVALUE;
    object _22851 = NOVALUE;
    object _22850 = NOVALUE;
    object _22849 = NOVALUE;
    object _22847 = NOVALUE;
    object _22846 = NOVALUE;
    object _22845 = NOVALUE;
    object _22843 = NOVALUE;
    object _22842 = NOVALUE;
    object _22839 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:866		sequence sym, symo*/

    /** c_decl.e:868		updsym = 0*/
    _updsym_43700 = 0;

    /** c_decl.e:869		g_has_delete = p_has_delete*/
    _58g_has_delete_42759 = _58p_has_delete_42760;

    /** c_decl.e:870		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22839 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21454);
    _2 = (object)SEQ_PTR(_22839);
    _s_43702 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43702)){
        _s_43702 = (object)DBL_PTR(_s_43702)->dbl;
    }
    _22839 = NOVALUE;

    /** c_decl.e:871		while s do*/
L1: 
    if (_s_43702 == 0)
    {
        goto L2; // [38] 921
    }
    else{
    }

    /** c_decl.e:872			sym = SymTab[s]*/
    DeRef(_sym_43703);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _sym_43703 = (object)*(((s1_ptr)_2)->base + _s_43702);
    Ref(_sym_43703);

    /** c_decl.e:873			symo = sym*/
    RefDS(_sym_43703);
    DeRef(_symo_43704);
    _symo_43704 = _sym_43703;

    /** c_decl.e:874			if sym[S_TOKEN] = FUNC or sym[S_TOKEN] = TYPE then*/
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _22842 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _22842 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    if (IS_ATOM_INT(_22842)) {
        _22843 = (_22842 == 501);
    }
    else {
        _22843 = binary_op(EQUALS, _22842, 501);
    }
    _22842 = NOVALUE;
    if (IS_ATOM_INT(_22843)) {
        if (_22843 != 0) {
            goto L3; // [72] 93
        }
    }
    else {
        if (DBL_PTR(_22843)->dbl != 0.0) {
            goto L3; // [72] 93
        }
    }
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _22845 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _22845 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    if (IS_ATOM_INT(_22845)) {
        _22846 = (_22845 == 504);
    }
    else {
        _22846 = binary_op(EQUALS, _22845, 504);
    }
    _22845 = NOVALUE;
    if (_22846 == 0) {
        DeRef(_22846);
        _22846 = NOVALUE;
        goto L4; // [89] 138
    }
    else {
        if (!IS_ATOM_INT(_22846) && DBL_PTR(_22846)->dbl == 0.0){
            DeRef(_22846);
            _22846 = NOVALUE;
            goto L4; // [89] 138
        }
        DeRef(_22846);
        _22846 = NOVALUE;
    }
    DeRef(_22846);
    _22846 = NOVALUE;
L3: 

    /** c_decl.e:875				if sym[S_GTYPE_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22847 = (object)*(((s1_ptr)_2)->base + 38);
    if (binary_op_a(NOTEQ, _22847, 0)){
        _22847 = NOVALUE;
        goto L5; // [103] 120
    }
    _22847 = NOVALUE;

    /** c_decl.e:876					sym[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    goto L6; // [117] 549
L5: 

    /** c_decl.e:878					sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22849 = (object)*(((s1_ptr)_2)->base + 38);
    Ref(_22849);
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22849;
    if( _1 != _22849 ){
        DeRef(_1);
    }
    _22849 = NOVALUE;
    goto L6; // [135] 549
L4: 

    /** c_decl.e:883				if sym[S_GTYPE] != TYPE_INTEGER and*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22850 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22850)) {
        _22851 = (_22850 != 1);
    }
    else {
        _22851 = binary_op(NOTEQ, _22850, 1);
    }
    _22850 = NOVALUE;
    if (IS_ATOM_INT(_22851)) {
        if (_22851 == 0) {
            DeRef(_22852);
            _22852 = 0;
            goto L7; // [152] 172
        }
    }
    else {
        if (DBL_PTR(_22851)->dbl == 0.0) {
            DeRef(_22852);
            _22852 = 0;
            goto L7; // [152] 172
        }
    }
    _2 = (object)SEQ_PTR(_sym_43703);
    _22853 = (object)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22853)) {
        _22854 = (_22853 != 16);
    }
    else {
        _22854 = binary_op(NOTEQ, _22853, 16);
    }
    _22853 = NOVALUE;
    DeRef(_22852);
    if (IS_ATOM_INT(_22854))
    _22852 = (_22854 != 0);
    else
    _22852 = DBL_PTR(_22854)->dbl != 0.0;
L7: 
    if (_22852 == 0) {
        goto L8; // [172] 283
    }
    _2 = (object)SEQ_PTR(_sym_43703);
    _22856 = (object)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22856)) {
        _22857 = (_22856 != 0);
    }
    else {
        _22857 = binary_op(NOTEQ, _22856, 0);
    }
    _22856 = NOVALUE;
    if (_22857 == 0) {
        DeRef(_22857);
        _22857 = NOVALUE;
        goto L8; // [189] 283
    }
    else {
        if (!IS_ATOM_INT(_22857) && DBL_PTR(_22857)->dbl == 0.0){
            DeRef(_22857);
            _22857 = NOVALUE;
            goto L8; // [189] 283
        }
        DeRef(_22857);
        _22857 = NOVALUE;
    }
    DeRef(_22857);
    _22857 = NOVALUE;

    /** c_decl.e:886					if sym[S_GTYPE_NEW] = TYPE_INTEGER or*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22858 = (object)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22858)) {
        _22859 = (_22858 == 1);
    }
    else {
        _22859 = binary_op(EQUALS, _22858, 1);
    }
    _22858 = NOVALUE;
    if (IS_ATOM_INT(_22859)) {
        if (_22859 != 0) {
            DeRef(_22860);
            _22860 = 1;
            goto L9; // [206] 226
        }
    }
    else {
        if (DBL_PTR(_22859)->dbl != 0.0) {
            DeRef(_22860);
            _22860 = 1;
            goto L9; // [206] 226
        }
    }
    _2 = (object)SEQ_PTR(_sym_43703);
    _22861 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22861)) {
        _22862 = (_22861 == 16);
    }
    else {
        _22862 = binary_op(EQUALS, _22861, 16);
    }
    _22861 = NOVALUE;
    DeRef(_22860);
    if (IS_ATOM_INT(_22862))
    _22860 = (_22862 != 0);
    else
    _22860 = DBL_PTR(_22862)->dbl != 0.0;
L9: 
    if (_22860 != 0) {
        goto LA; // [226] 267
    }
    _2 = (object)SEQ_PTR(_sym_43703);
    _22864 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22864)) {
        _22865 = (_22864 == 4);
    }
    else {
        _22865 = binary_op(EQUALS, _22864, 4);
    }
    _22864 = NOVALUE;
    if (IS_ATOM_INT(_22865)) {
        if (_22865 == 0) {
            DeRef(_22866);
            _22866 = 0;
            goto LB; // [242] 262
        }
    }
    else {
        if (DBL_PTR(_22865)->dbl == 0.0) {
            DeRef(_22866);
            _22866 = 0;
            goto LB; // [242] 262
        }
    }
    _2 = (object)SEQ_PTR(_sym_43703);
    _22867 = (object)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22867)) {
        _22868 = (_22867 == 2);
    }
    else {
        _22868 = binary_op(EQUALS, _22867, 2);
    }
    _22867 = NOVALUE;
    DeRef(_22866);
    if (IS_ATOM_INT(_22868))
    _22866 = (_22868 != 0);
    else
    _22866 = DBL_PTR(_22868)->dbl != 0.0;
LB: 
    if (_22866 == 0)
    {
        _22866 = NOVALUE;
        goto LC; // [263] 282
    }
    else{
        _22866 = NOVALUE;
    }
LA: 

    /** c_decl.e:890							sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22869 = (object)*(((s1_ptr)_2)->base + 38);
    Ref(_22869);
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22869;
    if( _1 != _22869 ){
        DeRef(_1);
    }
    _22869 = NOVALUE;
LC: 
L8: 

    /** c_decl.e:893				if sym[S_ARG_TYPE_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22870 = (object)*(((s1_ptr)_2)->base + 44);
    if (binary_op_a(NOTEQ, _22870, 0)){
        _22870 = NOVALUE;
        goto LD; // [293] 310
    }
    _22870 = NOVALUE;

    /** c_decl.e:894					sym[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    goto LE; // [307] 325
LD: 

    /** c_decl.e:896					sym[S_ARG_TYPE] = sym[S_ARG_TYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22872 = (object)*(((s1_ptr)_2)->base + 44);
    Ref(_22872);
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22872;
    if( _1 != _22872 ){
        DeRef(_1);
    }
    _22872 = NOVALUE;
LE: 

    /** c_decl.e:898				sym[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:900				if sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22873 = (object)*(((s1_ptr)_2)->base + 46);
    if (binary_op_a(NOTEQ, _22873, 0)){
        _22873 = NOVALUE;
        goto LF; // [345] 362
    }
    _22873 = NOVALUE;

    /** c_decl.e:901					sym[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    goto L10; // [359] 377
LF: 

    /** c_decl.e:903					sym[S_ARG_SEQ_ELEM] = sym[S_ARG_SEQ_ELEM_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22875 = (object)*(((s1_ptr)_2)->base + 46);
    Ref(_22875);
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22875;
    if( _1 != _22875 ){
        DeRef(_1);
    }
    _22875 = NOVALUE;
L10: 

    /** c_decl.e:905				sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:907				if sym[S_ARG_MIN_NEW] = -NOVALUE or*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22876 = (object)*(((s1_ptr)_2)->base + 49);
    if (IS_ATOM_INT(_36NOVALUE_21301)) {
        if ((uintptr_t)_36NOVALUE_21301 == (uintptr_t)HIGH_BITS){
            _22877 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22877 = - _36NOVALUE_21301;
        }
    }
    else {
        _22877 = unary_op(UMINUS, _36NOVALUE_21301);
    }
    if (IS_ATOM_INT(_22876) && IS_ATOM_INT(_22877)) {
        _22878 = (_22876 == _22877);
    }
    else {
        _22878 = binary_op(EQUALS, _22876, _22877);
    }
    _22876 = NOVALUE;
    DeRef(_22877);
    _22877 = NOVALUE;
    if (IS_ATOM_INT(_22878)) {
        if (_22878 != 0) {
            goto L11; // [404] 425
        }
    }
    else {
        if (DBL_PTR(_22878)->dbl != 0.0) {
            goto L11; // [404] 425
        }
    }
    _2 = (object)SEQ_PTR(_sym_43703);
    _22880 = (object)*(((s1_ptr)_2)->base + 49);
    if (IS_ATOM_INT(_22880) && IS_ATOM_INT(_36NOVALUE_21301)) {
        _22881 = (_22880 == _36NOVALUE_21301);
    }
    else {
        _22881 = binary_op(EQUALS, _22880, _36NOVALUE_21301);
    }
    _22880 = NOVALUE;
    if (_22881 == 0) {
        DeRef(_22881);
        _22881 = NOVALUE;
        goto L12; // [421] 448
    }
    else {
        if (!IS_ATOM_INT(_22881) && DBL_PTR(_22881)->dbl == 0.0){
            DeRef(_22881);
            _22881 = NOVALUE;
            goto L12; // [421] 448
        }
        DeRef(_22881);
        _22881 = NOVALUE;
    }
    DeRef(_22881);
    _22881 = NOVALUE;
L11: 

    /** c_decl.e:909					sym[S_ARG_MIN] = MININT*/
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1073741824;
    DeRef(_1);

    /** c_decl.e:910					sym[S_ARG_MAX] = MAXINT*/
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 48);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1073741823;
    DeRef(_1);
    goto L13; // [445] 477
L12: 

    /** c_decl.e:912					sym[S_ARG_MIN] = sym[S_ARG_MIN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22882 = (object)*(((s1_ptr)_2)->base + 49);
    Ref(_22882);
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22882;
    if( _1 != _22882 ){
        DeRef(_1);
    }
    _22882 = NOVALUE;

    /** c_decl.e:913					sym[S_ARG_MAX] = sym[S_ARG_MAX_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22883 = (object)*(((s1_ptr)_2)->base + 50);
    Ref(_22883);
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 48);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22883;
    if( _1 != _22883 ){
        DeRef(_1);
    }
    _22883 = NOVALUE;
L13: 

    /** c_decl.e:915				sym[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21301)) {
        if ((uintptr_t)_36NOVALUE_21301 == (uintptr_t)HIGH_BITS){
            _22884 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22884 = - _36NOVALUE_21301;
        }
    }
    else {
        _22884 = unary_op(UMINUS, _36NOVALUE_21301);
    }
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22884;
    if( _1 != _22884 ){
        DeRef(_1);
    }
    _22884 = NOVALUE;

    /** c_decl.e:917				if sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22885 = (object)*(((s1_ptr)_2)->base + 52);
    if (IS_ATOM_INT(_36NOVALUE_21301)) {
        if ((uintptr_t)_36NOVALUE_21301 == (uintptr_t)HIGH_BITS){
            _22886 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22886 = - _36NOVALUE_21301;
        }
    }
    else {
        _22886 = unary_op(UMINUS, _36NOVALUE_21301);
    }
    if (binary_op_a(NOTEQ, _22885, _22886)){
        _22885 = NOVALUE;
        DeRef(_22886);
        _22886 = NOVALUE;
        goto L14; // [503] 520
    }
    _22885 = NOVALUE;
    DeRef(_22886);
    _22886 = NOVALUE;

    /** c_decl.e:918					sym[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21301;
    DeRef(_1);
    goto L15; // [517] 535
L14: 

    /** c_decl.e:920					sym[S_ARG_SEQ_LEN] = sym[S_ARG_SEQ_LEN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22888 = (object)*(((s1_ptr)_2)->base + 52);
    Ref(_22888);
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22888;
    if( _1 != _22888 ){
        DeRef(_1);
    }
    _22888 = NOVALUE;
L15: 

    /** c_decl.e:922				sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21301)) {
        if ((uintptr_t)_36NOVALUE_21301 == (uintptr_t)HIGH_BITS){
            _22889 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22889 = - _36NOVALUE_21301;
        }
    }
    else {
        _22889 = unary_op(UMINUS, _36NOVALUE_21301);
    }
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22889;
    if( _1 != _22889 ){
        DeRef(_1);
    }
    _22889 = NOVALUE;
L6: 

    /** c_decl.e:925			sym[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:927			if sym[S_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22890 = (object)*(((s1_ptr)_2)->base + 40);
    if (binary_op_a(NOTEQ, _22890, 0)){
        _22890 = NOVALUE;
        goto L16; // [569] 586
    }
    _22890 = NOVALUE;

    /** c_decl.e:928			   sym[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    goto L17; // [583] 601
L16: 

    /** c_decl.e:930				sym[S_SEQ_ELEM] = sym[S_SEQ_ELEM_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22892 = (object)*(((s1_ptr)_2)->base + 40);
    Ref(_22892);
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22892;
    if( _1 != _22892 ){
        DeRef(_1);
    }
    _22892 = NOVALUE;
L17: 

    /** c_decl.e:932			sym[S_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:934			if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22893 = (object)*(((s1_ptr)_2)->base + 39);
    if (IS_ATOM_INT(_36NOVALUE_21301)) {
        if ((uintptr_t)_36NOVALUE_21301 == (uintptr_t)HIGH_BITS){
            _22894 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22894 = - _36NOVALUE_21301;
        }
    }
    else {
        _22894 = unary_op(UMINUS, _36NOVALUE_21301);
    }
    if (binary_op_a(NOTEQ, _22893, _22894)){
        _22893 = NOVALUE;
        DeRef(_22894);
        _22894 = NOVALUE;
        goto L18; // [624] 641
    }
    _22893 = NOVALUE;
    DeRef(_22894);
    _22894 = NOVALUE;

    /** c_decl.e:935				sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21301;
    DeRef(_1);
    goto L19; // [638] 656
L18: 

    /** c_decl.e:937				sym[S_SEQ_LEN] = sym[S_SEQ_LEN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22896 = (object)*(((s1_ptr)_2)->base + 39);
    Ref(_22896);
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22896;
    if( _1 != _22896 ){
        DeRef(_1);
    }
    _22896 = NOVALUE;
L19: 

    /** c_decl.e:939			sym[S_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21301)) {
        if ((uintptr_t)_36NOVALUE_21301 == (uintptr_t)HIGH_BITS){
            _22897 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22897 = - _36NOVALUE_21301;
        }
    }
    else {
        _22897 = unary_op(UMINUS, _36NOVALUE_21301);
    }
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22897;
    if( _1 != _22897 ){
        DeRef(_1);
    }
    _22897 = NOVALUE;

    /** c_decl.e:941			if sym[S_TOKEN] != NAMESPACE*/
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _22898 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _22898 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    if (IS_ATOM_INT(_22898)) {
        _22899 = (_22898 != 523);
    }
    else {
        _22899 = binary_op(NOTEQ, _22898, 523);
    }
    _22898 = NOVALUE;
    if (IS_ATOM_INT(_22899)) {
        if (_22899 == 0) {
            goto L1A; // [683] 794
        }
    }
    else {
        if (DBL_PTR(_22899)->dbl == 0.0) {
            goto L1A; // [683] 794
        }
    }
    _2 = (object)SEQ_PTR(_sym_43703);
    _22901 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_22901)) {
        _22902 = (_22901 != 2);
    }
    else {
        _22902 = binary_op(NOTEQ, _22901, 2);
    }
    _22901 = NOVALUE;
    if (_22902 == 0) {
        DeRef(_22902);
        _22902 = NOVALUE;
        goto L1A; // [700] 794
    }
    else {
        if (!IS_ATOM_INT(_22902) && DBL_PTR(_22902)->dbl == 0.0){
            DeRef(_22902);
            _22902 = NOVALUE;
            goto L1A; // [700] 794
        }
        DeRef(_22902);
        _22902 = NOVALUE;
    }
    DeRef(_22902);
    _22902 = NOVALUE;

    /** c_decl.e:944				if sym[S_OBJ_MIN_NEW] = -NOVALUE or*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22903 = (object)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_36NOVALUE_21301)) {
        if ((uintptr_t)_36NOVALUE_21301 == (uintptr_t)HIGH_BITS){
            _22904 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22904 = - _36NOVALUE_21301;
        }
    }
    else {
        _22904 = unary_op(UMINUS, _36NOVALUE_21301);
    }
    if (IS_ATOM_INT(_22903) && IS_ATOM_INT(_22904)) {
        _22905 = (_22903 == _22904);
    }
    else {
        _22905 = binary_op(EQUALS, _22903, _22904);
    }
    _22903 = NOVALUE;
    DeRef(_22904);
    _22904 = NOVALUE;
    if (IS_ATOM_INT(_22905)) {
        if (_22905 != 0) {
            goto L1B; // [720] 741
        }
    }
    else {
        if (DBL_PTR(_22905)->dbl != 0.0) {
            goto L1B; // [720] 741
        }
    }
    _2 = (object)SEQ_PTR(_sym_43703);
    _22907 = (object)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_22907) && IS_ATOM_INT(_36NOVALUE_21301)) {
        _22908 = (_22907 == _36NOVALUE_21301);
    }
    else {
        _22908 = binary_op(EQUALS, _22907, _36NOVALUE_21301);
    }
    _22907 = NOVALUE;
    if (_22908 == 0) {
        DeRef(_22908);
        _22908 = NOVALUE;
        goto L1C; // [737] 764
    }
    else {
        if (!IS_ATOM_INT(_22908) && DBL_PTR(_22908)->dbl == 0.0){
            DeRef(_22908);
            _22908 = NOVALUE;
            goto L1C; // [737] 764
        }
        DeRef(_22908);
        _22908 = NOVALUE;
    }
    DeRef(_22908);
    _22908 = NOVALUE;
L1B: 

    /** c_decl.e:946					sym[S_OBJ_MIN] = MININT*/
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1073741824;
    DeRef(_1);

    /** c_decl.e:947					sym[S_OBJ_MAX] = MAXINT*/
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1073741823;
    DeRef(_1);
    goto L1D; // [761] 793
L1C: 

    /** c_decl.e:949					sym[S_OBJ_MIN] = sym[S_OBJ_MIN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22909 = (object)*(((s1_ptr)_2)->base + 41);
    Ref(_22909);
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22909;
    if( _1 != _22909 ){
        DeRef(_1);
    }
    _22909 = NOVALUE;

    /** c_decl.e:950					sym[S_OBJ_MAX] = sym[S_OBJ_MAX_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22910 = (object)*(((s1_ptr)_2)->base + 42);
    Ref(_22910);
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22910;
    if( _1 != _22910 ){
        DeRef(_1);
    }
    _22910 = NOVALUE;
L1D: 
L1A: 

    /** c_decl.e:953			sym[S_OBJ_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21301)) {
        if ((uintptr_t)_36NOVALUE_21301 == (uintptr_t)HIGH_BITS){
            _22911 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22911 = - _36NOVALUE_21301;
        }
    }
    else {
        _22911 = unary_op(UMINUS, _36NOVALUE_21301);
    }
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22911;
    if( _1 != _22911 ){
        DeRef(_1);
    }
    _22911 = NOVALUE;

    /** c_decl.e:955			if sym[S_NREFS] = 1 and*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22912 = (object)*(((s1_ptr)_2)->base + 12);
    if (IS_ATOM_INT(_22912)) {
        _22913 = (_22912 == 1);
    }
    else {
        _22913 = binary_op(EQUALS, _22912, 1);
    }
    _22912 = NOVALUE;
    if (IS_ATOM_INT(_22913)) {
        if (_22913 == 0) {
            goto L1E; // [819] 874
        }
    }
    else {
        if (DBL_PTR(_22913)->dbl == 0.0) {
            goto L1E; // [819] 874
        }
    }
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _22915 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _22915 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    _22916 = find_from(_22915, _38RTN_TOKS_16045, 1);
    _22915 = NOVALUE;
    if (_22916 == 0)
    {
        _22916 = NOVALUE;
        goto L1E; // [837] 874
    }
    else{
        _22916 = NOVALUE;
    }

    /** c_decl.e:957				if sym[S_USAGE] != U_DELETED then*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _22917 = (object)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(EQUALS, _22917, 99)){
        _22917 = NOVALUE;
        goto L1F; // [850] 873
    }
    _22917 = NOVALUE;

    /** c_decl.e:958					sym[S_USAGE] = U_DELETED*/
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 99;
    DeRef(_1);

    /** c_decl.e:959					deleted_routines += 1*/
    _58deleted_routines_43697 = _58deleted_routines_43697 + 1;
L1F: 
L1E: 

    /** c_decl.e:962			sym[S_NREFS] = 0*/
    _2 = (object)SEQ_PTR(_sym_43703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43703 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:963			if not equal(symo, sym) then*/
    if (_symo_43704 == _sym_43703)
    _22920 = 1;
    else if (IS_ATOM_INT(_symo_43704) && IS_ATOM_INT(_sym_43703))
    _22920 = 0;
    else
    _22920 = (compare(_symo_43704, _sym_43703) == 0);
    if (_22920 != 0)
    goto L20; // [888] 906
    _22920 = NOVALUE;

    /** c_decl.e:964				SymTab[s] = sym*/
    RefDS(_sym_43703);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_43702);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_43703;
    DeRef(_1);

    /** c_decl.e:965				updsym += 1*/
    _updsym_43700 = _updsym_43700 + 1;
L20: 

    /** c_decl.e:967			s = sym[S_NEXT]*/
    _2 = (object)SEQ_PTR(_sym_43703);
    _s_43702 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43702)){
        _s_43702 = (object)DBL_PTR(_s_43702)->dbl;
    }

    /** c_decl.e:968		end while*/
    goto L1; // [918] 38
L2: 

    /** c_decl.e:971		for i = 1 to length(temp_name_type) do*/
    if (IS_SEQUENCE(_36temp_name_type_21533)){
            _22924 = SEQ_PTR(_36temp_name_type_21533)->length;
    }
    else {
        _22924 = 1;
    }
    {
        object _i_43930;
        _i_43930 = 1;
L21: 
        if (_i_43930 > _22924){
            goto L22; // [928] 1061
        }

        /** c_decl.e:972			integer upd = 0*/
        _upd_43933 = 0;

        /** c_decl.e:974			if temp_name_type[i][T_GTYPE] != temp_name_type[i][T_GTYPE_NEW] then*/
        _2 = (object)SEQ_PTR(_36temp_name_type_21533);
        _22925 = (object)*(((s1_ptr)_2)->base + _i_43930);
        _2 = (object)SEQ_PTR(_22925);
        _22926 = (object)*(((s1_ptr)_2)->base + 1);
        _22925 = NOVALUE;
        _2 = (object)SEQ_PTR(_36temp_name_type_21533);
        _22927 = (object)*(((s1_ptr)_2)->base + _i_43930);
        _2 = (object)SEQ_PTR(_22927);
        _22928 = (object)*(((s1_ptr)_2)->base + 2);
        _22927 = NOVALUE;
        if (binary_op_a(EQUALS, _22926, _22928)){
            _22926 = NOVALUE;
            _22928 = NOVALUE;
            goto L23; // [966] 1003
        }
        _22926 = NOVALUE;
        _22928 = NOVALUE;

        /** c_decl.e:975				temp_name_type[i][T_GTYPE] = temp_name_type[i][T_GTYPE_NEW]*/
        _2 = (object)SEQ_PTR(_36temp_name_type_21533);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _36temp_name_type_21533 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_43930 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_36temp_name_type_21533);
        _22932 = (object)*(((s1_ptr)_2)->base + _i_43930);
        _2 = (object)SEQ_PTR(_22932);
        _22933 = (object)*(((s1_ptr)_2)->base + 2);
        _22932 = NOVALUE;
        Ref(_22933);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _22933;
        if( _1 != _22933 ){
            DeRef(_1);
        }
        _22933 = NOVALUE;
        _22930 = NOVALUE;

        /** c_decl.e:976				upd = 1*/
        _upd_43933 = 1;
L23: 

        /** c_decl.e:978			if temp_name_type[i][T_GTYPE_NEW] != TYPE_NULL then*/
        _2 = (object)SEQ_PTR(_36temp_name_type_21533);
        _22934 = (object)*(((s1_ptr)_2)->base + _i_43930);
        _2 = (object)SEQ_PTR(_22934);
        _22935 = (object)*(((s1_ptr)_2)->base + 2);
        _22934 = NOVALUE;
        if (binary_op_a(EQUALS, _22935, 0)){
            _22935 = NOVALUE;
            goto L24; // [1019] 1046
        }
        _22935 = NOVALUE;

        /** c_decl.e:979				temp_name_type[i][T_GTYPE_NEW] = TYPE_NULL*/
        _2 = (object)SEQ_PTR(_36temp_name_type_21533);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _36temp_name_type_21533 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_43930 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 2);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);
        _22937 = NOVALUE;

        /** c_decl.e:980				upd = 1*/
        _upd_43933 = 1;
L24: 

        /** c_decl.e:982			updsym += upd*/
        _updsym_43700 = _updsym_43700 + _upd_43933;

        /** c_decl.e:983		end for*/
        _i_43930 = _i_43930 + 1;
        goto L21; // [1056] 935
L22: 
        ;
    }

    /** c_decl.e:985		return updsym*/
    DeRef(_sym_43703);
    DeRef(_symo_43704);
    DeRef(_22913);
    _22913 = NOVALUE;
    DeRef(_22843);
    _22843 = NOVALUE;
    DeRef(_22854);
    _22854 = NOVALUE;
    DeRef(_22899);
    _22899 = NOVALUE;
    DeRef(_22905);
    _22905 = NOVALUE;
    DeRef(_22865);
    _22865 = NOVALUE;
    DeRef(_22878);
    _22878 = NOVALUE;
    DeRef(_22868);
    _22868 = NOVALUE;
    DeRef(_22862);
    _22862 = NOVALUE;
    DeRef(_22859);
    _22859 = NOVALUE;
    DeRef(_22851);
    _22851 = NOVALUE;
    return _updsym_43700;
    ;
}


void _58declare_prototype(object _s_43968)
{
    object _ret_type_43969 = NOVALUE;
    object _scope_43980 = NOVALUE;
    object _22957 = NOVALUE;
    object _22956 = NOVALUE;
    object _22954 = NOVALUE;
    object _22953 = NOVALUE;
    object _22952 = NOVALUE;
    object _22951 = NOVALUE;
    object _22949 = NOVALUE;
    object _22948 = NOVALUE;
    object _22947 = NOVALUE;
    object _22946 = NOVALUE;
    object _22945 = NOVALUE;
    object _22943 = NOVALUE;
    object _22942 = NOVALUE;
    object _22940 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:990		if sym_token( s ) = PROC then*/
    _22940 = _54sym_token(_s_43968);
    if (binary_op_a(NOTEQ, _22940, 27)){
        DeRef(_22940);
        _22940 = NOVALUE;
        goto L1; // [11] 25
    }
    DeRef(_22940);
    _22940 = NOVALUE;

    /** c_decl.e:991			ret_type = "void "*/
    RefDS(_22781);
    DeRefi(_ret_type_43969);
    _ret_type_43969 = _22781;
    goto L2; // [22] 33
L1: 

    /** c_decl.e:993			ret_type ="object "*/
    RefDS(_22782);
    DeRefi(_ret_type_43969);
    _ret_type_43969 = _22782;
L2: 

    /** c_decl.e:996		c_hputs(ret_type)*/
    RefDS(_ret_type_43969);
    _55c_hputs(_ret_type_43969);

    /** c_decl.e:999		if dll_option and TWINDOWS  then*/
    if (_58dll_option_42567 == 0) {
        goto L3; // [44] 116
    }
    if (_46TWINDOWS_21594 == 0)
    {
        goto L3; // [51] 116
    }
    else{
    }

    /** c_decl.e:1000			integer scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22943 = (object)*(((s1_ptr)_2)->base + _s_43968);
    _2 = (object)SEQ_PTR(_22943);
    _scope_43980 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_43980)){
        _scope_43980 = (object)DBL_PTR(_scope_43980)->dbl;
    }
    _22943 = NOVALUE;

    /** c_decl.e:1001			if (scope = SC_PUBLIC*/
    _22945 = (_scope_43980 == 13);
    if (_22945 != 0) {
        _22946 = 1;
        goto L4; // [78] 92
    }
    _22947 = (_scope_43980 == 11);
    _22946 = (_22947 != 0);
L4: 
    if (_22946 != 0) {
        DeRef(_22948);
        _22948 = 1;
        goto L5; // [92] 106
    }
    _22949 = (_scope_43980 == 6);
    _22948 = (_22949 != 0);
L5: 
    if (_22948 == 0)
    {
        _22948 = NOVALUE;
        goto L6; // [106] 115
    }
    else{
        _22948 = NOVALUE;
    }

    /** c_decl.e:1006				c_hputs("__stdcall ")*/
    RefDS(_22950);
    _55c_hputs(_22950);
L6: 
L3: 

    /** c_decl.e:1010		c_hprintf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22951 = (object)*(((s1_ptr)_2)->base + _s_43968);
    _2 = (object)SEQ_PTR(_22951);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _22952 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _22952 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _22951 = NOVALUE;
    RefDS(_22120);
    Ref(_22952);
    _55c_hprintf(_22120, _22952);
    _22952 = NOVALUE;

    /** c_decl.e:1011		c_hputs(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22953 = (object)*(((s1_ptr)_2)->base + _s_43968);
    _2 = (object)SEQ_PTR(_22953);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _22954 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _22954 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _22953 = NOVALUE;
    Ref(_22954);
    _55c_hputs(_22954);
    _22954 = NOVALUE;

    /** c_decl.e:1012		c_hputs("(")*/
    RefDS(_22955);
    _55c_hputs(_22955);

    /** c_decl.e:1014		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22956 = (object)*(((s1_ptr)_2)->base + _s_43968);
    _2 = (object)SEQ_PTR(_22956);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
        _22957 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
    }
    else{
        _22957 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
    }
    _22956 = NOVALUE;
    {
        object _i_44009;
        _i_44009 = 1;
L7: 
        if (binary_op_a(GREATER, _i_44009, _22957)){
            goto L8; // [172] 206
        }

        /** c_decl.e:1015			if i = 1 then*/
        if (binary_op_a(NOTEQ, _i_44009, 1)){
            goto L9; // [181] 193
        }

        /** c_decl.e:1016				c_hputs("object")*/
        RefDS(_22959);
        _55c_hputs(_22959);
        goto LA; // [190] 199
L9: 

        /** c_decl.e:1018				c_hputs(", object")*/
        RefDS(_22960);
        _55c_hputs(_22960);
LA: 

        /** c_decl.e:1020		end for*/
        _0 = _i_44009;
        if (IS_ATOM_INT(_i_44009)) {
            _i_44009 = _i_44009 + 1;
            if ((object)((uintptr_t)_i_44009 +(uintptr_t) HIGH_BITS) >= 0){
                _i_44009 = NewDouble((eudouble)_i_44009);
            }
        }
        else {
            _i_44009 = binary_op_a(PLUS, _i_44009, 1);
        }
        DeRef(_0);
        goto L7; // [201] 179
L8: 
        ;
        DeRef(_i_44009);
    }

    /** c_decl.e:1021		c_hputs(");\n")*/
    RefDS(_22301);
    _55c_hputs(_22301);

    /** c_decl.e:1022	end procedure*/
    DeRefi(_ret_type_43969);
    DeRef(_22947);
    _22947 = NOVALUE;
    DeRef(_22949);
    _22949 = NOVALUE;
    _22957 = NOVALUE;
    DeRef(_22945);
    _22945 = NOVALUE;
    return;
    ;
}


void _58add_to_routine_list(object _s_44025, object _seq_num_44026, object _first_44027)
{
    object _p_44102 = NOVALUE;
    object _23006 = NOVALUE;
    object _23004 = NOVALUE;
    object _23002 = NOVALUE;
    object _23000 = NOVALUE;
    object _22998 = NOVALUE;
    object _22997 = NOVALUE;
    object _22996 = NOVALUE;
    object _22994 = NOVALUE;
    object _22992 = NOVALUE;
    object _22990 = NOVALUE;
    object _22989 = NOVALUE;
    object _22987 = NOVALUE;
    object _22986 = NOVALUE;
    object _22982 = NOVALUE;
    object _22981 = NOVALUE;
    object _22980 = NOVALUE;
    object _22979 = NOVALUE;
    object _22978 = NOVALUE;
    object _22977 = NOVALUE;
    object _22976 = NOVALUE;
    object _22975 = NOVALUE;
    object _22974 = NOVALUE;
    object _22973 = NOVALUE;
    object _22971 = NOVALUE;
    object _22970 = NOVALUE;
    object _22969 = NOVALUE;
    object _22968 = NOVALUE;
    object _22965 = NOVALUE;
    object _22964 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:1025		if not first then*/
    if (_first_44027 != 0)
    goto L1; // [9] 18

    /** c_decl.e:1026			c_puts(",\n")*/
    RefDS(_22962);
    _55c_puts(_22962);
L1: 

    /** c_decl.e:1029		c_puts("  {\"")*/
    RefDS(_22963);
    _55c_puts(_22963);

    /** c_decl.e:1031		c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22964 = (object)*(((s1_ptr)_2)->base + _s_44025);
    _2 = (object)SEQ_PTR(_22964);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _22965 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _22965 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _22964 = NOVALUE;
    Ref(_22965);
    _55c_puts(_22965);
    _22965 = NOVALUE;

    /** c_decl.e:1032		c_puts("\", ")*/
    RefDS(_22966);
    _55c_puts(_22966);

    /** c_decl.e:1033		c_puts("(object (*)())")*/
    RefDS(_22967);
    _55c_puts(_22967);

    /** c_decl.e:1034		c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22968 = (object)*(((s1_ptr)_2)->base + _s_44025);
    _2 = (object)SEQ_PTR(_22968);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _22969 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _22969 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _22968 = NOVALUE;
    RefDS(_22120);
    Ref(_22969);
    _55c_printf(_22120, _22969);
    _22969 = NOVALUE;

    /** c_decl.e:1035		c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22970 = (object)*(((s1_ptr)_2)->base + _s_44025);
    _2 = (object)SEQ_PTR(_22970);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _22971 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _22971 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _22970 = NOVALUE;
    Ref(_22971);
    _55c_puts(_22971);
    _22971 = NOVALUE;

    /** c_decl.e:1036		c_printf(", %d", seq_num)*/
    RefDS(_22972);
    _55c_printf(_22972, _seq_num_44026);

    /** c_decl.e:1037		c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22973 = (object)*(((s1_ptr)_2)->base + _s_44025);
    _2 = (object)SEQ_PTR(_22973);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _22974 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _22974 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _22973 = NOVALUE;
    RefDS(_22972);
    Ref(_22974);
    _55c_printf(_22972, _22974);
    _22974 = NOVALUE;

    /** c_decl.e:1038		c_printf(", %d", SymTab[s][S_NUM_ARGS])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22975 = (object)*(((s1_ptr)_2)->base + _s_44025);
    _2 = (object)SEQ_PTR(_22975);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
        _22976 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
    }
    else{
        _22976 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
    }
    _22975 = NOVALUE;
    RefDS(_22972);
    Ref(_22976);
    _55c_printf(_22972, _22976);
    _22976 = NOVALUE;

    /** c_decl.e:1040		if TWINDOWS and dll_option and find( SymTab[s][S_SCOPE], { SC_GLOBAL, SC_EXPORT, SC_PUBLIC} ) then*/
    if (_46TWINDOWS_21594 == 0) {
        _22977 = 0;
        goto L2; // [131] 141
    }
    _22977 = (_58dll_option_42567 != 0);
L2: 
    if (_22977 == 0) {
        goto L3; // [141] 186
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22979 = (object)*(((s1_ptr)_2)->base + _s_44025);
    _2 = (object)SEQ_PTR(_22979);
    _22980 = (object)*(((s1_ptr)_2)->base + 4);
    _22979 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 6;
    ((intptr_t*)_2)[2] = 11;
    ((intptr_t*)_2)[3] = 13;
    _22981 = MAKE_SEQ(_1);
    _22982 = find_from(_22980, _22981, 1);
    _22980 = NOVALUE;
    DeRefDS(_22981);
    _22981 = NOVALUE;
    if (_22982 == 0)
    {
        _22982 = NOVALUE;
        goto L3; // [175] 186
    }
    else{
        _22982 = NOVALUE;
    }

    /** c_decl.e:1041			c_puts(", 1")  -- must call with __stdcall convention*/
    RefDS(_22983);
    _55c_puts(_22983);
    goto L4; // [183] 192
L3: 

    /** c_decl.e:1043			c_puts(", 0")  -- default: call with normal or __cdecl convention*/
    RefDS(_22984);
    _55c_puts(_22984);
L4: 

    /** c_decl.e:1046		c_printf(", %d, 0", SymTab[s][S_SCOPE] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22986 = (object)*(((s1_ptr)_2)->base + _s_44025);
    _2 = (object)SEQ_PTR(_22986);
    _22987 = (object)*(((s1_ptr)_2)->base + 4);
    _22986 = NOVALUE;
    RefDS(_22985);
    Ref(_22987);
    _55c_printf(_22985, _22987);
    _22987 = NOVALUE;

    /** c_decl.e:1047		c_puts("}")*/
    RefDS(_22988);
    _55c_puts(_22988);

    /** c_decl.e:1049		if SymTab[s][S_NREFS] < 2 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22989 = (object)*(((s1_ptr)_2)->base + _s_44025);
    _2 = (object)SEQ_PTR(_22989);
    _22990 = (object)*(((s1_ptr)_2)->base + 12);
    _22989 = NOVALUE;
    if (binary_op_a(GREATEREQ, _22990, 2)){
        _22990 = NOVALUE;
        goto L5; // [229] 249
    }
    _22990 = NOVALUE;

    /** c_decl.e:1050			SymTab[s][S_NREFS] = 2 --s->nrefs++*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_44025 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _22992 = NOVALUE;
L5: 

    /** c_decl.e:1055		symtab_index p = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22994 = (object)*(((s1_ptr)_2)->base + _s_44025);
    _2 = (object)SEQ_PTR(_22994);
    _p_44102 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_44102)){
        _p_44102 = (object)DBL_PTR(_p_44102)->dbl;
    }
    _22994 = NOVALUE;

    /** c_decl.e:1056		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22996 = (object)*(((s1_ptr)_2)->base + _s_44025);
    _2 = (object)SEQ_PTR(_22996);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
        _22997 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
    }
    else{
        _22997 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
    }
    _22996 = NOVALUE;
    {
        object _i_44108;
        _i_44108 = 1;
L6: 
        if (binary_op_a(GREATER, _i_44108, _22997)){
            goto L7; // [279] 377
        }

        /** c_decl.e:1057			SymTab[p][S_ARG_SEQ_ELEM_NEW] = TYPE_OBJECT*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44102 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 46);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 16;
        DeRef(_1);
        _22998 = NOVALUE;

        /** c_decl.e:1058			SymTab[p][S_ARG_TYPE_NEW] = TYPE_OBJECT*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44102 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 44);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 16;
        DeRef(_1);
        _23000 = NOVALUE;

        /** c_decl.e:1059			SymTab[p][S_ARG_MIN_NEW] = NOVALUE*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44102 + ((s1_ptr)_2)->base);
        Ref(_36NOVALUE_21301);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 49);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _36NOVALUE_21301;
        DeRef(_1);
        _23002 = NOVALUE;

        /** c_decl.e:1060			SymTab[p][S_ARG_SEQ_LEN_NEW] = NOVALUE*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44102 + ((s1_ptr)_2)->base);
        Ref(_36NOVALUE_21301);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 52);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _36NOVALUE_21301;
        DeRef(_1);
        _23004 = NOVALUE;

        /** c_decl.e:1061			p = SymTab[p][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _23006 = (object)*(((s1_ptr)_2)->base + _p_44102);
        _2 = (object)SEQ_PTR(_23006);
        _p_44102 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_p_44102)){
            _p_44102 = (object)DBL_PTR(_p_44102)->dbl;
        }
        _23006 = NOVALUE;

        /** c_decl.e:1062		end for*/
        _0 = _i_44108;
        if (IS_ATOM_INT(_i_44108)) {
            _i_44108 = _i_44108 + 1;
            if ((object)((uintptr_t)_i_44108 +(uintptr_t) HIGH_BITS) >= 0){
                _i_44108 = NewDouble((eudouble)_i_44108);
            }
        }
        else {
            _i_44108 = binary_op_a(PLUS, _i_44108, 1);
        }
        DeRef(_0);
        goto L6; // [372] 286
L7: 
        ;
        DeRef(_i_44108);
    }

    /** c_decl.e:1063	end procedure*/
    _22997 = NOVALUE;
    return;
    ;
}


void _58DeclareRoutineList()
{
    object _s_44140 = NOVALUE;
    object _first_44141 = NOVALUE;
    object _seq_num_44142 = NOVALUE;
    object _these_routines_44150 = NOVALUE;
    object _these_routines_44172 = NOVALUE;
    object _23022 = NOVALUE;
    object _23021 = NOVALUE;
    object _23019 = NOVALUE;
    object _23017 = NOVALUE;
    object _23014 = NOVALUE;
    object _23013 = NOVALUE;
    object _23011 = NOVALUE;
    object _23009 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1069		integer first, seq_num*/

    /** c_decl.e:1071		c_hputs("extern struct routine_list _00[];\n")*/
    RefDS(_23008);
    _55c_hputs(_23008);

    /** c_decl.e:1073		check_file_routines()*/
    _58check_file_routines();

    /** c_decl.e:1074		for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_58file_routines_44729)){
            _23009 = SEQ_PTR(_58file_routines_44729)->length;
    }
    else {
        _23009 = 1;
    }
    {
        object _f_44147;
        _f_44147 = 1;
L1: 
        if (_f_44147 > _23009){
            goto L2; // [19] 98
        }

        /** c_decl.e:1075			sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_44150);
        _2 = (object)SEQ_PTR(_58file_routines_44729);
        _these_routines_44150 = (object)*(((s1_ptr)_2)->base + _f_44147);
        Ref(_these_routines_44150);

        /** c_decl.e:1076			for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_44150)){
                _23011 = SEQ_PTR(_these_routines_44150)->length;
        }
        else {
            _23011 = 1;
        }
        {
            object _r_44154;
            _r_44154 = 1;
L3: 
            if (_r_44154 > _23011){
                goto L4; // [41] 89
            }

            /** c_decl.e:1077				s = these_routines[r]*/
            _2 = (object)SEQ_PTR(_these_routines_44150);
            _s_44140 = (object)*(((s1_ptr)_2)->base + _r_44154);
            if (!IS_ATOM_INT(_s_44140)){
                _s_44140 = (object)DBL_PTR(_s_44140)->dbl;
            }

            /** c_decl.e:1078				if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23013 = (object)*(((s1_ptr)_2)->base + _s_44140);
            _2 = (object)SEQ_PTR(_23013);
            _23014 = (object)*(((s1_ptr)_2)->base + 5);
            _23013 = NOVALUE;
            if (binary_op_a(EQUALS, _23014, 99)){
                _23014 = NOVALUE;
                goto L5; // [72] 82
            }
            _23014 = NOVALUE;

            /** c_decl.e:1080					declare_prototype( s )*/
            _58declare_prototype(_s_44140);
L5: 

            /** c_decl.e:1083			end for*/
            _r_44154 = _r_44154 + 1;
            goto L3; // [84] 48
L4: 
            ;
        }
        DeRef(_these_routines_44150);
        _these_routines_44150 = NOVALUE;

        /** c_decl.e:1084		end for*/
        _f_44147 = _f_44147 + 1;
        goto L1; // [93] 26
L2: 
        ;
    }

    /** c_decl.e:1085		c_puts("\n")*/
    RefDS(_22192);
    _55c_puts(_22192);

    /** c_decl.e:1088		seq_num = 0*/
    _seq_num_44142 = 0;

    /** c_decl.e:1089		first = TRUE*/
    _first_44141 = _13TRUE_452;

    /** c_decl.e:1090		c_puts("struct routine_list _00[] = {\n")*/
    RefDS(_23016);
    _55c_puts(_23016);

    /** c_decl.e:1092		for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_58file_routines_44729)){
            _23017 = SEQ_PTR(_58file_routines_44729)->length;
    }
    else {
        _23017 = 1;
    }
    {
        object _f_44169;
        _f_44169 = 1;
L6: 
        if (_f_44169 > _23017){
            goto L7; // [129] 222
        }

        /** c_decl.e:1093			sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_44172);
        _2 = (object)SEQ_PTR(_58file_routines_44729);
        _these_routines_44172 = (object)*(((s1_ptr)_2)->base + _f_44169);
        Ref(_these_routines_44172);

        /** c_decl.e:1094			for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_44172)){
                _23019 = SEQ_PTR(_these_routines_44172)->length;
        }
        else {
            _23019 = 1;
        }
        {
            object _r_44176;
            _r_44176 = 1;
L8: 
            if (_r_44176 > _23019){
                goto L9; // [151] 213
            }

            /** c_decl.e:1095				s = these_routines[r]*/
            _2 = (object)SEQ_PTR(_these_routines_44172);
            _s_44140 = (object)*(((s1_ptr)_2)->base + _r_44176);
            if (!IS_ATOM_INT(_s_44140)){
                _s_44140 = (object)DBL_PTR(_s_44140)->dbl;
            }

            /** c_decl.e:1096				if SymTab[s][S_RI_TARGET] then*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23021 = (object)*(((s1_ptr)_2)->base + _s_44140);
            _2 = (object)SEQ_PTR(_23021);
            _23022 = (object)*(((s1_ptr)_2)->base + 53);
            _23021 = NOVALUE;
            if (_23022 == 0) {
                _23022 = NOVALUE;
                goto LA; // [180] 200
            }
            else {
                if (!IS_ATOM_INT(_23022) && DBL_PTR(_23022)->dbl == 0.0){
                    _23022 = NOVALUE;
                    goto LA; // [180] 200
                }
                _23022 = NOVALUE;
            }
            _23022 = NOVALUE;

            /** c_decl.e:1098					add_to_routine_list( s, seq_num, first )*/
            _58add_to_routine_list(_s_44140, _seq_num_44142, _first_44141);

            /** c_decl.e:1099					first = FALSE*/
            _first_44141 = _13FALSE_450;
LA: 

            /** c_decl.e:1102				seq_num += 1*/
            _seq_num_44142 = _seq_num_44142 + 1;

            /** c_decl.e:1103			end for*/
            _r_44176 = _r_44176 + 1;
            goto L8; // [208] 158
L9: 
            ;
        }
        DeRef(_these_routines_44172);
        _these_routines_44172 = NOVALUE;

        /** c_decl.e:1104		end for*/
        _f_44169 = _f_44169 + 1;
        goto L6; // [217] 136
L7: 
        ;
    }

    /** c_decl.e:1105		if not first then*/
    if (_first_44141 != 0)
    goto LB; // [224] 233

    /** c_decl.e:1106			c_puts(",\n")*/
    RefDS(_22962);
    _55c_puts(_22962);
LB: 

    /** c_decl.e:1108		c_puts("  {\"\", 0, 999999999, 0, 0, 0, 0}\n};\n\n")  -- end marker*/
    RefDS(_23025);
    _55c_puts(_23025);

    /** c_decl.e:1110		c_hputs("extern char ** _02;\n")*/
    RefDS(_23026);
    _55c_hputs(_23026);

    /** c_decl.e:1111		c_puts("char ** _02;\n")*/
    RefDS(_23027);
    _55c_puts(_23027);

    /** c_decl.e:1113		c_hputs("extern object _0switches;\n")*/
    RefDS(_23028);
    _55c_hputs(_23028);

    /** c_decl.e:1114		c_puts("object _0switches;\n")*/
    RefDS(_23029);
    _55c_puts(_23029);

    /** c_decl.e:1115	end procedure*/
    return;
    ;
}


void _58DeclareNameSpaceList()
{
    object _s_44202 = NOVALUE;
    object _first_44203 = NOVALUE;
    object _seq_num_44204 = NOVALUE;
    object _23049 = NOVALUE;
    object _23047 = NOVALUE;
    object _23046 = NOVALUE;
    object _23045 = NOVALUE;
    object _23044 = NOVALUE;
    object _23042 = NOVALUE;
    object _23041 = NOVALUE;
    object _23038 = NOVALUE;
    object _23037 = NOVALUE;
    object _23036 = NOVALUE;
    object _23035 = NOVALUE;
    object _23034 = NOVALUE;
    object _23032 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1121		integer first, seq_num*/

    /** c_decl.e:1123		c_hputs("extern struct ns_list _01[];\n")*/
    RefDS(_23030);
    _55c_hputs(_23030);

    /** c_decl.e:1124		c_puts("struct ns_list _01[] = {\n")*/
    RefDS(_23031);
    _55c_puts(_23031);

    /** c_decl.e:1126		seq_num = 0*/
    _seq_num_44204 = 0;

    /** c_decl.e:1127		first = TRUE*/
    _first_44203 = _13TRUE_452;

    /** c_decl.e:1129		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23032 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21454);
    _2 = (object)SEQ_PTR(_23032);
    _s_44202 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_44202)){
        _s_44202 = (object)DBL_PTR(_s_44202)->dbl;
    }
    _23032 = NOVALUE;

    /** c_decl.e:1130		while s do*/
L1: 
    if (_s_44202 == 0)
    {
        goto L2; // [50] 215
    }
    else{
    }

    /** c_decl.e:1131			if find(SymTab[s][S_TOKEN], NAMED_TOKS) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23034 = (object)*(((s1_ptr)_2)->base + _s_44202);
    _2 = (object)SEQ_PTR(_23034);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _23035 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _23035 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    _23034 = NOVALUE;
    _23036 = find_from(_23035, _38NAMED_TOKS_16047, 1);
    _23035 = NOVALUE;
    if (_23036 == 0)
    {
        _23036 = NOVALUE;
        goto L3; // [74] 194
    }
    else{
        _23036 = NOVALUE;
    }

    /** c_decl.e:1132				if SymTab[s][S_TOKEN] = NAMESPACE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23037 = (object)*(((s1_ptr)_2)->base + _s_44202);
    _2 = (object)SEQ_PTR(_23037);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _23038 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _23038 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    _23037 = NOVALUE;
    if (binary_op_a(NOTEQ, _23038, 523)){
        _23038 = NOVALUE;
        goto L4; // [93] 187
    }
    _23038 = NOVALUE;

    /** c_decl.e:1133					if not first then*/
    if (_first_44203 != 0)
    goto L5; // [99] 108

    /** c_decl.e:1134						c_puts(",\n")*/
    RefDS(_22962);
    _55c_puts(_22962);
L5: 

    /** c_decl.e:1136					first = FALSE*/
    _first_44203 = _13FALSE_450;

    /** c_decl.e:1138					c_puts("  {\"")*/
    RefDS(_22963);
    _55c_puts(_22963);

    /** c_decl.e:1139					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23041 = (object)*(((s1_ptr)_2)->base + _s_44202);
    _2 = (object)SEQ_PTR(_23041);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _23042 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _23042 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _23041 = NOVALUE;
    Ref(_23042);
    _55c_puts(_23042);
    _23042 = NOVALUE;

    /** c_decl.e:1140					c_printf("\", %d", SymTab[s][S_OBJ])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23044 = (object)*(((s1_ptr)_2)->base + _s_44202);
    _2 = (object)SEQ_PTR(_23044);
    _23045 = (object)*(((s1_ptr)_2)->base + 1);
    _23044 = NOVALUE;
    RefDS(_23043);
    Ref(_23045);
    _55c_printf(_23043, _23045);
    _23045 = NOVALUE;

    /** c_decl.e:1141					c_printf(", %d", seq_num)*/
    RefDS(_22972);
    _55c_printf(_22972, _seq_num_44204);

    /** c_decl.e:1142					c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23046 = (object)*(((s1_ptr)_2)->base + _s_44202);
    _2 = (object)SEQ_PTR(_23046);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _23047 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _23047 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _23046 = NOVALUE;
    RefDS(_22972);
    Ref(_23047);
    _55c_printf(_22972, _23047);
    _23047 = NOVALUE;

    /** c_decl.e:1144					c_puts("}")*/
    RefDS(_22988);
    _55c_puts(_22988);
L4: 

    /** c_decl.e:1146				seq_num += 1*/
    _seq_num_44204 = _seq_num_44204 + 1;
L3: 

    /** c_decl.e:1148			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23049 = (object)*(((s1_ptr)_2)->base + _s_44202);
    _2 = (object)SEQ_PTR(_23049);
    _s_44202 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_44202)){
        _s_44202 = (object)DBL_PTR(_s_44202)->dbl;
    }
    _23049 = NOVALUE;

    /** c_decl.e:1149		end while*/
    goto L1; // [212] 50
L2: 

    /** c_decl.e:1150		if not first then*/
    if (_first_44203 != 0)
    goto L6; // [217] 226

    /** c_decl.e:1151			c_puts(",\n")*/
    RefDS(_22962);
    _55c_puts(_22962);
L6: 

    /** c_decl.e:1153		c_puts("  {\"\", 0, 999999999, 0}\n};\n\n")  -- end marker*/
    RefDS(_23052);
    _55c_puts(_23052);

    /** c_decl.e:1154	end procedure*/
    return;
    ;
}


object _58is_exported(object _s_44266)
{
    object _eentry_44267 = NOVALUE;
    object _scope_44270 = NOVALUE;
    object _23067 = NOVALUE;
    object _23066 = NOVALUE;
    object _23065 = NOVALUE;
    object _23064 = NOVALUE;
    object _23063 = NOVALUE;
    object _23062 = NOVALUE;
    object _23061 = NOVALUE;
    object _23060 = NOVALUE;
    object _23059 = NOVALUE;
    object _23058 = NOVALUE;
    object _23057 = NOVALUE;
    object _23055 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_44266)) {
        _1 = (object)(DBL_PTR(_s_44266)->dbl);
        DeRefDS(_s_44266);
        _s_44266 = _1;
    }

    /** c_decl.e:1159		sequence eentry = SymTab[s]*/
    DeRef(_eentry_44267);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _eentry_44267 = (object)*(((s1_ptr)_2)->base + _s_44266);
    Ref(_eentry_44267);

    /** c_decl.e:1160		integer scope = eentry[S_SCOPE]*/
    _2 = (object)SEQ_PTR(_eentry_44267);
    _scope_44270 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_44270))
    _scope_44270 = (object)DBL_PTR(_scope_44270)->dbl;

    /** c_decl.e:1162		if eentry[S_MODE] = M_NORMAL then*/
    _2 = (object)SEQ_PTR(_eentry_44267);
    _23055 = (object)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _23055, 1)){
        _23055 = NOVALUE;
        goto L1; // [31] 125
    }
    _23055 = NOVALUE;

    /** c_decl.e:1163			if eentry[S_FILE_NO] = 1 and find(scope, { SC_EXPORT, SC_PUBLIC, SC_GLOBAL }) then*/
    _2 = (object)SEQ_PTR(_eentry_44267);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _23057 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _23057 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    if (IS_ATOM_INT(_23057)) {
        _23058 = (_23057 == 1);
    }
    else {
        _23058 = binary_op(EQUALS, _23057, 1);
    }
    _23057 = NOVALUE;
    if (IS_ATOM_INT(_23058)) {
        if (_23058 == 0) {
            goto L2; // [47] 79
        }
    }
    else {
        if (DBL_PTR(_23058)->dbl == 0.0) {
            goto L2; // [47] 79
        }
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 11;
    ((intptr_t*)_2)[2] = 13;
    ((intptr_t*)_2)[3] = 6;
    _23060 = MAKE_SEQ(_1);
    _23061 = find_from(_scope_44270, _23060, 1);
    DeRefDS(_23060);
    _23060 = NOVALUE;
    if (_23061 == 0)
    {
        _23061 = NOVALUE;
        goto L2; // [69] 79
    }
    else{
        _23061 = NOVALUE;
    }

    /** c_decl.e:1164				return 1*/
    DeRef(_eentry_44267);
    DeRef(_23058);
    _23058 = NOVALUE;
    return 1;
L2: 

    /** c_decl.e:1167			if scope = SC_PUBLIC and*/
    _23062 = (_scope_44270 == 13);
    if (_23062 == 0) {
        goto L3; // [87] 124
    }
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _23064 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_eentry_44267);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _23065 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _23065 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _2 = (object)SEQ_PTR(_23064);
    if (!IS_ATOM_INT(_23065)){
        _23066 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23065)->dbl));
    }
    else{
        _23066 = (object)*(((s1_ptr)_2)->base + _23065);
    }
    _23064 = NOVALUE;
    if (IS_ATOM_INT(_23066)) {
        {uintptr_t tu;
             tu = (uintptr_t)_23066 & (uintptr_t)4;
             _23067 = MAKE_UINT(tu);
        }
    }
    else {
        _23067 = binary_op(AND_BITS, _23066, 4);
    }
    _23066 = NOVALUE;
    if (_23067 == 0) {
        DeRef(_23067);
        _23067 = NOVALUE;
        goto L3; // [114] 124
    }
    else {
        if (!IS_ATOM_INT(_23067) && DBL_PTR(_23067)->dbl == 0.0){
            DeRef(_23067);
            _23067 = NOVALUE;
            goto L3; // [114] 124
        }
        DeRef(_23067);
        _23067 = NOVALUE;
    }
    DeRef(_23067);
    _23067 = NOVALUE;

    /** c_decl.e:1170				return 1*/
    DeRef(_eentry_44267);
    DeRef(_23058);
    _23058 = NOVALUE;
    DeRef(_23062);
    _23062 = NOVALUE;
    _23065 = NOVALUE;
    return 1;
L3: 
L1: 

    /** c_decl.e:1174		return 0*/
    DeRef(_eentry_44267);
    DeRef(_23058);
    _23058 = NOVALUE;
    DeRef(_23062);
    _23062 = NOVALUE;
    _23065 = NOVALUE;
    return 0;
    ;
}


void _58version()
{
    object _23101 = NOVALUE;
    object _23100 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1207		c_puts("// Euphoria To C version " & version_string() & "\n")*/
    _23100 = _33version_string(0);
    {
        object concat_list[3];

        concat_list[0] = _22192;
        concat_list[1] = _23100;
        concat_list[2] = _23099;
        Concat_N((object_ptr)&_23101, concat_list, 3);
    }
    DeRef(_23100);
    _23100 = NOVALUE;
    _55c_puts(_23101);
    _23101 = NOVALUE;

    /** c_decl.e:1208	end procedure*/
    return;
    ;
}


void _58new_c_file(object _name_44374)
{
    object _23104 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1213		cfile_size = 0*/
    _36cfile_size_21530 = 0;

    /** c_decl.e:1216		if LAST_PASS = FALSE then*/
    if (_58LAST_PASS_42554 != _13FALSE_450)
    goto L1; // [16] 26

    /** c_decl.e:1217			return*/
    DeRefDS(_name_44374);
    return;
L1: 

    /** c_decl.e:1220		write_checksum( c_code )*/
    _56write_checksum(_55c_code_46627);

    /** c_decl.e:1221		close(c_code)*/
    EClose(_55c_code_46627);

    /** c_decl.e:1223		c_code = open(output_dir & name & ".c", "w")*/
    {
        object concat_list[3];

        concat_list[0] = _23103;
        concat_list[1] = _name_44374;
        concat_list[2] = _58output_dir_42581;
        Concat_N((object_ptr)&_23104, concat_list, 3);
    }
    _55c_code_46627 = EOpen(_23104, _22133, 0);
    DeRefDS(_23104);
    _23104 = NOVALUE;

    /** c_decl.e:1224		if c_code = -1 then*/
    if (_55c_code_46627 != -1)
    goto L2; // [60] 74

    /** c_decl.e:1225			CompileErr(COULDNT_OPEN_C_FILE_FOR_OUTPUT)*/
    RefDS(_21997);
    _50CompileErr(57, _21997, 0);
L2: 

    /** c_decl.e:1228		cfile_count += 1*/
    _36cfile_count_21529 = _36cfile_count_21529 + 1;

    /** c_decl.e:1229		version()*/
    _58version();

    /** c_decl.e:1231		c_puts("#include \"include/euphoria.h\"\n")*/
    RefDS(_22138);
    _55c_puts(_22138);

    /** c_decl.e:1233		c_puts("#include \"main-.h\"\n\n")*/
    RefDS(_22139);
    _55c_puts(_22139);

    /** c_decl.e:1235		if not TUNIX then*/
    if (_46TUNIX_21598 != 0)
    goto L3; // [102] 114

    /** c_decl.e:1236			name = lower(name)  -- for faster compare later*/
    RefDS(_name_44374);
    _0 = _name_44374;
    _name_44374 = _14lower(_name_44374);
    DeRefDS(_0);
L3: 

    /** c_decl.e:1238	end procedure*/
    DeRefDS(_name_44374);
    return;
    ;
}


object _58unique_c_name(object _name_44404)
{
    object _i_44405 = NOVALUE;
    object _compare_name_44406 = NOVALUE;
    object _next_fc_44407 = NOVALUE;
    object _23120 = NOVALUE;
    object _23118 = NOVALUE;
    object _23117 = NOVALUE;
    object _23116 = NOVALUE;
    object _23114 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1253		compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_44406, _name_44404, _23103);

    /** c_decl.e:1254		if not TUNIX then*/
    if (_46TUNIX_21598 != 0)
    goto L1; // [13] 25

    /** c_decl.e:1255			compare_name = lower(compare_name)*/
    RefDS(_compare_name_44406);
    _0 = _compare_name_44406;
    _compare_name_44406 = _14lower(_compare_name_44406);
    DeRefDS(_0);
L1: 

    /** c_decl.e:1258		next_fc = 1*/
    _next_fc_44407 = 1;

    /** c_decl.e:1259		i = 1*/
    _i_44405 = 1;

    /** c_decl.e:1261		while i <= length(generated_files) do*/
L2: 
    if (IS_SEQUENCE(_58generated_files_42571)){
            _23114 = SEQ_PTR(_58generated_files_42571)->length;
    }
    else {
        _23114 = 1;
    }
    if (_i_44405 > _23114)
    goto L3; // [45] 141

    /** c_decl.e:1263			if equal(generated_files[i], compare_name) then*/
    _2 = (object)SEQ_PTR(_58generated_files_42571);
    _23116 = (object)*(((s1_ptr)_2)->base + _i_44405);
    if (_23116 == _compare_name_44406)
    _23117 = 1;
    else if (IS_ATOM_INT(_23116) && IS_ATOM_INT(_compare_name_44406))
    _23117 = 0;
    else
    _23117 = (compare(_23116, _compare_name_44406) == 0);
    _23116 = NOVALUE;
    if (_23117 == 0)
    {
        _23117 = NOVALUE;
        goto L4; // [61] 129
    }
    else{
        _23117 = NOVALUE;
    }

    /** c_decl.e:1265				if next_fc > length(file_chars) then*/
    if (IS_SEQUENCE(_58file_chars_44400)){
            _23118 = SEQ_PTR(_58file_chars_44400)->length;
    }
    else {
        _23118 = 1;
    }
    if (_next_fc_44407 <= _23118)
    goto L5; // [69] 83

    /** c_decl.e:1266					CompileErr(SORRY_TOO_MANY_C_FILES_WITH_THE_SAME_BASE_NAME)*/
    RefDS(_21997);
    _50CompileErr(140, _21997, 0);
L5: 

    /** c_decl.e:1269				name[1] = file_chars[next_fc]*/
    _2 = (object)SEQ_PTR(_58file_chars_44400);
    _23120 = (object)*(((s1_ptr)_2)->base + _next_fc_44407);
    Ref(_23120);
    _2 = (object)SEQ_PTR(_name_44404);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _name_44404 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23120;
    if( _1 != _23120 ){
        DeRef(_1);
    }
    _23120 = NOVALUE;

    /** c_decl.e:1270				compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_44406, _name_44404, _23103);

    /** c_decl.e:1271				if not TUNIX then*/
    if (_46TUNIX_21598 != 0)
    goto L6; // [103] 115

    /** c_decl.e:1272					compare_name = lower(compare_name)*/
    RefDS(_compare_name_44406);
    _0 = _compare_name_44406;
    _compare_name_44406 = _14lower(_compare_name_44406);
    DeRefDS(_0);
L6: 

    /** c_decl.e:1275				next_fc += 1*/
    _next_fc_44407 = _next_fc_44407 + 1;

    /** c_decl.e:1276				i = 1 -- start over and compare again*/
    _i_44405 = 1;
    goto L2; // [126] 40
L4: 

    /** c_decl.e:1279				i += 1*/
    _i_44405 = _i_44405 + 1;

    /** c_decl.e:1281		end while*/
    goto L2; // [138] 40
L3: 

    /** c_decl.e:1283		return name*/
    DeRef(_compare_name_44406);
    return _name_44404;
    ;
}


object _58is_file_newer(object _f1_44437, object _f2_44438)
{
    object _d1_44439 = NOVALUE;
    object _d2_44442 = NOVALUE;
    object _diff_2__tmp_at42_44453 = NOVALUE;
    object _diff_1__tmp_at42_44452 = NOVALUE;
    object _diff_inlined_diff_at_42_44451 = NOVALUE;
    object _23130 = NOVALUE;
    object _23128 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1287		object d1 = file_timestamp(f1)*/
    RefDS(_f1_44437);
    _0 = _d1_44439;
    _d1_44439 = _17file_timestamp(_f1_44437);
    DeRef(_0);

    /** c_decl.e:1288		object d2 = file_timestamp(f2)*/
    RefDS(_f2_44438);
    _0 = _d2_44442;
    _d2_44442 = _17file_timestamp(_f2_44438);
    DeRef(_0);

    /** c_decl.e:1290		if atom(d1) or atom(d2) then return 1 end if*/
    _23128 = IS_ATOM(_d1_44439);
    if (_23128 != 0) {
        goto L1; // [22] 34
    }
    _23130 = IS_ATOM(_d2_44442);
    if (_23130 == 0)
    {
        _23130 = NOVALUE;
        goto L2; // [30] 39
    }
    else{
        _23130 = NOVALUE;
    }
L1: 
    DeRefDS(_f1_44437);
    DeRefDS(_f2_44438);
    DeRef(_d1_44439);
    DeRef(_d2_44442);
    return 1;
L2: 

    /** c_decl.e:1291		if datetime:diff(d1, d2) < 0 then*/

    /** datetime.e:1253		return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_44442);
    _0 = _diff_1__tmp_at42_44452;
    _diff_1__tmp_at42_44452 = _18datetimeToSeconds(_d2_44442);
    DeRef(_0);
    Ref(_d1_44439);
    _0 = _diff_2__tmp_at42_44453;
    _diff_2__tmp_at42_44453 = _18datetimeToSeconds(_d1_44439);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_42_44451);
    if (IS_ATOM_INT(_diff_1__tmp_at42_44452) && IS_ATOM_INT(_diff_2__tmp_at42_44453)) {
        _diff_inlined_diff_at_42_44451 = _diff_1__tmp_at42_44452 - _diff_2__tmp_at42_44453;
        if ((object)((uintptr_t)_diff_inlined_diff_at_42_44451 +(uintptr_t) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_42_44451 = NewDouble((eudouble)_diff_inlined_diff_at_42_44451);
        }
    }
    else {
        _diff_inlined_diff_at_42_44451 = binary_op(MINUS, _diff_1__tmp_at42_44452, _diff_2__tmp_at42_44453);
    }
    DeRef(_diff_1__tmp_at42_44452);
    _diff_1__tmp_at42_44452 = NOVALUE;
    DeRef(_diff_2__tmp_at42_44453);
    _diff_2__tmp_at42_44453 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_42_44451, 0)){
        goto L3; // [58] 69
    }

    /** c_decl.e:1292			return 1*/
    DeRefDS(_f1_44437);
    DeRefDS(_f2_44438);
    DeRef(_d1_44439);
    DeRef(_d2_44442);
    return 1;
L3: 

    /** c_decl.e:1295		return 0*/
    DeRefDS(_f1_44437);
    DeRefDS(_f2_44438);
    DeRef(_d1_44439);
    DeRef(_d2_44442);
    return 0;
    ;
}


void _58add_file(object _filename_44457, object _eu_filename_44458)
{
    object _obj_fname_44478 = NOVALUE;
    object _src_fname_44479 = NOVALUE;
    object _23154 = NOVALUE;
    object _23153 = NOVALUE;
    object _23140 = NOVALUE;
    object _23139 = NOVALUE;
    object _23136 = NOVALUE;
    object _23135 = NOVALUE;
    object _23134 = NOVALUE;
    object _23133 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1303		if equal("c", fileext(filename)) then*/
    RefDS(_filename_44457);
    _23133 = _17fileext(_filename_44457);
    if (_23132 == _23133)
    _23134 = 1;
    else if (IS_ATOM_INT(_23132) && IS_ATOM_INT(_23133))
    _23134 = 0;
    else
    _23134 = (compare(_23132, _23133) == 0);
    DeRef(_23133);
    _23133 = NOVALUE;
    if (_23134 == 0)
    {
        _23134 = NOVALUE;
        goto L1; // [15] 35
    }
    else{
        _23134 = NOVALUE;
    }

    /** c_decl.e:1304			filename = filename[1..$-2]*/
    if (IS_SEQUENCE(_filename_44457)){
            _23135 = SEQ_PTR(_filename_44457)->length;
    }
    else {
        _23135 = 1;
    }
    _23136 = _23135 - 2;
    _23135 = NOVALUE;
    rhs_slice_target = (object_ptr)&_filename_44457;
    RHS_Slice(_filename_44457, 1, _23136);
    goto L2; // [32] 82
L1: 

    /** c_decl.e:1305		elsif equal("h", fileext(filename)) then*/
    RefDS(_filename_44457);
    _23139 = _17fileext(_filename_44457);
    if (_23138 == _23139)
    _23140 = 1;
    else if (IS_ATOM_INT(_23138) && IS_ATOM_INT(_23139))
    _23140 = 0;
    else
    _23140 = (compare(_23138, _23139) == 0);
    DeRef(_23139);
    _23139 = NOVALUE;
    if (_23140 == 0)
    {
        _23140 = NOVALUE;
        goto L3; // [45] 81
    }
    else{
        _23140 = NOVALUE;
    }

    /** c_decl.e:1306			generated_files = append(generated_files, filename)*/
    RefDS(_filename_44457);
    Append(&_58generated_files_42571, _58generated_files_42571, _filename_44457);

    /** c_decl.e:1307			if build_system_type = BUILD_DIRECT then*/
    if (_56build_system_type_45389 != 3)
    goto L4; // [62] 75

    /** c_decl.e:1308				outdated_files  = append(outdated_files, 0)*/
    Append(&_58outdated_files_42572, _58outdated_files_42572, 0);
L4: 

    /** c_decl.e:1311			return*/
    DeRefDS(_filename_44457);
    DeRefDS(_eu_filename_44458);
    DeRef(_obj_fname_44478);
    DeRef(_src_fname_44479);
    DeRef(_23136);
    _23136 = NOVALUE;
    return;
L3: 
L2: 

    /** c_decl.e:1314		sequence obj_fname = filename, src_fname = filename & ".c"*/
    RefDS(_filename_44457);
    DeRef(_obj_fname_44478);
    _obj_fname_44478 = _filename_44457;
    Concat((object_ptr)&_src_fname_44479, _filename_44457, _23103);

    /** c_decl.e:1316		if compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45393 != 2)
    goto L5; // [99] 112

    /** c_decl.e:1317			obj_fname &= ".obj"*/
    Concat((object_ptr)&_obj_fname_44478, _obj_fname_44478, _23146);
    goto L6; // [109] 119
L5: 

    /** c_decl.e:1319			obj_fname &= ".o"*/
    Concat((object_ptr)&_obj_fname_44478, _obj_fname_44478, _23148);
L6: 

    /** c_decl.e:1322		generated_files = append(generated_files, src_fname)*/
    RefDS(_src_fname_44479);
    Append(&_58generated_files_42571, _58generated_files_42571, _src_fname_44479);

    /** c_decl.e:1323		generated_files = append(generated_files, obj_fname)*/
    RefDS(_obj_fname_44478);
    Append(&_58generated_files_42571, _58generated_files_42571, _obj_fname_44478);

    /** c_decl.e:1324		if build_system_type = BUILD_DIRECT then*/
    if (_56build_system_type_45389 != 3)
    goto L7; // [141] 173

    /** c_decl.e:1325			outdated_files  = append(outdated_files, is_file_newer(eu_filename, output_dir & src_fname))*/
    Concat((object_ptr)&_23153, _58output_dir_42581, _src_fname_44479);
    RefDS(_eu_filename_44458);
    _23154 = _58is_file_newer(_eu_filename_44458, _23153);
    _23153 = NOVALUE;
    Ref(_23154);
    Append(&_58outdated_files_42572, _58outdated_files_42572, _23154);
    DeRef(_23154);
    _23154 = NOVALUE;

    /** c_decl.e:1326			outdated_files  = append(outdated_files, 0)*/
    Append(&_58outdated_files_42572, _58outdated_files_42572, 0);
L7: 

    /** c_decl.e:1328	end procedure*/
    DeRefDS(_filename_44457);
    DeRefDS(_eu_filename_44458);
    DeRef(_obj_fname_44478);
    DeRef(_src_fname_44479);
    DeRef(_23136);
    _23136 = NOVALUE;
    return;
    ;
}


object _58any_code(object _file_no_44502)
{
    object _these_routines_44504 = NOVALUE;
    object _s_44511 = NOVALUE;
    object _23170 = NOVALUE;
    object _23169 = NOVALUE;
    object _23168 = NOVALUE;
    object _23167 = NOVALUE;
    object _23166 = NOVALUE;
    object _23165 = NOVALUE;
    object _23164 = NOVALUE;
    object _23163 = NOVALUE;
    object _23162 = NOVALUE;
    object _23161 = NOVALUE;
    object _23160 = NOVALUE;
    object _23158 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1334		check_file_routines()*/
    _58check_file_routines();

    /** c_decl.e:1336		sequence these_routines = file_routines[file_no]*/
    DeRef(_these_routines_44504);
    _2 = (object)SEQ_PTR(_58file_routines_44729);
    _these_routines_44504 = (object)*(((s1_ptr)_2)->base + _file_no_44502);
    Ref(_these_routines_44504);

    /** c_decl.e:1337		for i = 1 to length( these_routines ) do*/
    if (IS_SEQUENCE(_these_routines_44504)){
            _23158 = SEQ_PTR(_these_routines_44504)->length;
    }
    else {
        _23158 = 1;
    }
    {
        object _i_44508;
        _i_44508 = 1;
L1: 
        if (_i_44508 > _23158){
            goto L2; // [22] 126
        }

        /** c_decl.e:1338			symtab_index s = these_routines[i]*/
        _2 = (object)SEQ_PTR(_these_routines_44504);
        _s_44511 = (object)*(((s1_ptr)_2)->base + _i_44508);
        if (!IS_ATOM_INT(_s_44511)){
            _s_44511 = (object)DBL_PTR(_s_44511)->dbl;
        }

        /** c_decl.e:1339			if SymTab[s][S_FILE_NO] = file_no and*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _23160 = (object)*(((s1_ptr)_2)->base + _s_44511);
        _2 = (object)SEQ_PTR(_23160);
        if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
            _23161 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
        }
        else{
            _23161 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
        }
        _23160 = NOVALUE;
        if (IS_ATOM_INT(_23161)) {
            _23162 = (_23161 == _file_no_44502);
        }
        else {
            _23162 = binary_op(EQUALS, _23161, _file_no_44502);
        }
        _23161 = NOVALUE;
        if (IS_ATOM_INT(_23162)) {
            if (_23162 == 0) {
                DeRef(_23163);
                _23163 = 0;
                goto L3; // [55] 81
            }
        }
        else {
            if (DBL_PTR(_23162)->dbl == 0.0) {
                DeRef(_23163);
                _23163 = 0;
                goto L3; // [55] 81
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _23164 = (object)*(((s1_ptr)_2)->base + _s_44511);
        _2 = (object)SEQ_PTR(_23164);
        _23165 = (object)*(((s1_ptr)_2)->base + 5);
        _23164 = NOVALUE;
        if (IS_ATOM_INT(_23165)) {
            _23166 = (_23165 != 99);
        }
        else {
            _23166 = binary_op(NOTEQ, _23165, 99);
        }
        _23165 = NOVALUE;
        DeRef(_23163);
        if (IS_ATOM_INT(_23166))
        _23163 = (_23166 != 0);
        else
        _23163 = DBL_PTR(_23166)->dbl != 0.0;
L3: 
        if (_23163 == 0) {
            goto L4; // [81] 117
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _23168 = (object)*(((s1_ptr)_2)->base + _s_44511);
        _2 = (object)SEQ_PTR(_23168);
        if (!IS_ATOM_INT(_36S_TOKEN_21089)){
            _23169 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
        }
        else{
            _23169 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
        }
        _23168 = NOVALUE;
        _23170 = find_from(_23169, _38RTN_TOKS_16045, 1);
        _23169 = NOVALUE;
        if (_23170 == 0)
        {
            _23170 = NOVALUE;
            goto L4; // [105] 117
        }
        else{
            _23170 = NOVALUE;
        }

        /** c_decl.e:1342				return TRUE -- found a non-deleted routine in this file*/
        DeRef(_these_routines_44504);
        DeRef(_23162);
        _23162 = NOVALUE;
        DeRef(_23166);
        _23166 = NOVALUE;
        return _13TRUE_452;
L4: 

        /** c_decl.e:1344		end for*/
        _i_44508 = _i_44508 + 1;
        goto L1; // [121] 29
L2: 
        ;
    }

    /** c_decl.e:1345		return FALSE*/
    DeRef(_these_routines_44504);
    DeRef(_23162);
    _23162 = NOVALUE;
    DeRef(_23166);
    _23166 = NOVALUE;
    return _13FALSE_450;
    ;
}


void _58check_file_routines()
{
    object _s_44738 = NOVALUE;
    object _23332 = NOVALUE;
    object _23331 = NOVALUE;
    object _23330 = NOVALUE;
    object _23329 = NOVALUE;
    object _23328 = NOVALUE;
    object _23327 = NOVALUE;
    object _23326 = NOVALUE;
    object _23325 = NOVALUE;
    object _23324 = NOVALUE;
    object _23323 = NOVALUE;
    object _23322 = NOVALUE;
    object _23321 = NOVALUE;
    object _23319 = NOVALUE;
    object _23317 = NOVALUE;
    object _23315 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1451		if not length( file_routines ) then*/
    if (IS_SEQUENCE(_58file_routines_44729)){
            _23315 = SEQ_PTR(_58file_routines_44729)->length;
    }
    else {
        _23315 = 1;
    }
    if (_23315 != 0)
    goto L1; // [8] 146
    _23315 = NOVALUE;

    /** c_decl.e:1452			file_routines = repeat( {}, length( known_files ) )*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _23317 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _23317 = 1;
    }
    DeRefDS(_58file_routines_44729);
    _58file_routines_44729 = Repeat(_21997, _23317);
    _23317 = NOVALUE;

    /** c_decl.e:1453			integer s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23319 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21454);
    _2 = (object)SEQ_PTR(_23319);
    _s_44738 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_44738)){
        _s_44738 = (object)DBL_PTR(_s_44738)->dbl;
    }
    _23319 = NOVALUE;

    /** c_decl.e:1454			while s do*/
L2: 
    if (_s_44738 == 0)
    {
        goto L3; // [45] 145
    }
    else{
    }

    /** c_decl.e:1455				if SymTab[s][S_USAGE] != U_DELETED and*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23321 = (object)*(((s1_ptr)_2)->base + _s_44738);
    _2 = (object)SEQ_PTR(_23321);
    _23322 = (object)*(((s1_ptr)_2)->base + 5);
    _23321 = NOVALUE;
    if (IS_ATOM_INT(_23322)) {
        _23323 = (_23322 != 99);
    }
    else {
        _23323 = binary_op(NOTEQ, _23322, 99);
    }
    _23322 = NOVALUE;
    if (IS_ATOM_INT(_23323)) {
        if (_23323 == 0) {
            goto L4; // [68] 124
        }
    }
    else {
        if (DBL_PTR(_23323)->dbl == 0.0) {
            goto L4; // [68] 124
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23325 = (object)*(((s1_ptr)_2)->base + _s_44738);
    _2 = (object)SEQ_PTR(_23325);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _23326 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _23326 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    _23325 = NOVALUE;
    _23327 = find_from(_23326, _38RTN_TOKS_16045, 1);
    _23326 = NOVALUE;
    if (_23327 == 0)
    {
        _23327 = NOVALUE;
        goto L4; // [92] 124
    }
    else{
        _23327 = NOVALUE;
    }

    /** c_decl.e:1458					file_routines[SymTab[s][S_FILE_NO]] &= s*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23328 = (object)*(((s1_ptr)_2)->base + _s_44738);
    _2 = (object)SEQ_PTR(_23328);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _23329 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _23329 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _23328 = NOVALUE;
    _2 = (object)SEQ_PTR(_58file_routines_44729);
    if (!IS_ATOM_INT(_23329)){
        _23330 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23329)->dbl));
    }
    else{
        _23330 = (object)*(((s1_ptr)_2)->base + _23329);
    }
    if (IS_SEQUENCE(_23330) && IS_ATOM(_s_44738)) {
        Append(&_23331, _23330, _s_44738);
    }
    else if (IS_ATOM(_23330) && IS_SEQUENCE(_s_44738)) {
    }
    else {
        Concat((object_ptr)&_23331, _23330, _s_44738);
        _23330 = NOVALUE;
    }
    _23330 = NOVALUE;
    _2 = (object)SEQ_PTR(_58file_routines_44729);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58file_routines_44729 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_23329))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_23329)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _23329);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23331;
    if( _1 != _23331 ){
        DeRef(_1);
    }
    _23331 = NOVALUE;
L4: 

    /** c_decl.e:1460				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23332 = (object)*(((s1_ptr)_2)->base + _s_44738);
    _2 = (object)SEQ_PTR(_23332);
    _s_44738 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_44738)){
        _s_44738 = (object)DBL_PTR(_s_44738)->dbl;
    }
    _23332 = NOVALUE;

    /** c_decl.e:1461			end while*/
    goto L2; // [142] 45
L3: 
L1: 

    /** c_decl.e:1464	end procedure*/
    DeRef(_23323);
    _23323 = NOVALUE;
    _23329 = NOVALUE;
    return;
    ;
}


void _58GenerateUserRoutines()
{
    object _s_44772 = NOVALUE;
    object _sp_44773 = NOVALUE;
    object _next_c_char_44774 = NOVALUE;
    object _q_44775 = NOVALUE;
    object _temps_44776 = NOVALUE;
    object _buff_44777 = NOVALUE;
    object _base_name_44778 = NOVALUE;
    object _long_c_file_44779 = NOVALUE;
    object _c_file_44780 = NOVALUE;
    object _these_routines_44851 = NOVALUE;
    object _ret_type_44909 = NOVALUE;
    object _s_scope_44918 = NOVALUE;
    object _s_file_44921 = NOVALUE;
    object _scope_44998 = NOVALUE;
    object _names_45032 = NOVALUE;
    object _name_45042 = NOVALUE;
    object _23568 = NOVALUE;
    object _23566 = NOVALUE;
    object _23565 = NOVALUE;
    object _23564 = NOVALUE;
    object _23563 = NOVALUE;
    object _23562 = NOVALUE;
    object _23561 = NOVALUE;
    object _23559 = NOVALUE;
    object _23557 = NOVALUE;
    object _23556 = NOVALUE;
    object _23553 = NOVALUE;
    object _23551 = NOVALUE;
    object _23550 = NOVALUE;
    object _23549 = NOVALUE;
    object _23548 = NOVALUE;
    object _23547 = NOVALUE;
    object _23546 = NOVALUE;
    object _23544 = NOVALUE;
    object _23540 = NOVALUE;
    object _23538 = NOVALUE;
    object _23537 = NOVALUE;
    object _23536 = NOVALUE;
    object _23535 = NOVALUE;
    object _23533 = NOVALUE;
    object _23532 = NOVALUE;
    object _23530 = NOVALUE;
    object _23529 = NOVALUE;
    object _23527 = NOVALUE;
    object _23526 = NOVALUE;
    object _23525 = NOVALUE;
    object _23524 = NOVALUE;
    object _23522 = NOVALUE;
    object _23520 = NOVALUE;
    object _23519 = NOVALUE;
    object _23518 = NOVALUE;
    object _23517 = NOVALUE;
    object _23516 = NOVALUE;
    object _23515 = NOVALUE;
    object _23514 = NOVALUE;
    object _23512 = NOVALUE;
    object _23511 = NOVALUE;
    object _23510 = NOVALUE;
    object _23509 = NOVALUE;
    object _23508 = NOVALUE;
    object _23507 = NOVALUE;
    object _23506 = NOVALUE;
    object _23505 = NOVALUE;
    object _23503 = NOVALUE;
    object _23502 = NOVALUE;
    object _23500 = NOVALUE;
    object _23499 = NOVALUE;
    object _23498 = NOVALUE;
    object _23497 = NOVALUE;
    object _23496 = NOVALUE;
    object _23495 = NOVALUE;
    object _23494 = NOVALUE;
    object _23493 = NOVALUE;
    object _23491 = NOVALUE;
    object _23490 = NOVALUE;
    object _23488 = NOVALUE;
    object _23487 = NOVALUE;
    object _23486 = NOVALUE;
    object _23484 = NOVALUE;
    object _23479 = NOVALUE;
    object _23478 = NOVALUE;
    object _23476 = NOVALUE;
    object _23474 = NOVALUE;
    object _23468 = NOVALUE;
    object _23467 = NOVALUE;
    object _23466 = NOVALUE;
    object _23465 = NOVALUE;
    object _23464 = NOVALUE;
    object _23463 = NOVALUE;
    object _23462 = NOVALUE;
    object _23461 = NOVALUE;
    object _23459 = NOVALUE;
    object _23458 = NOVALUE;
    object _23456 = NOVALUE;
    object _23455 = NOVALUE;
    object _23452 = NOVALUE;
    object _23450 = NOVALUE;
    object _23449 = NOVALUE;
    object _23448 = NOVALUE;
    object _23444 = NOVALUE;
    object _23441 = NOVALUE;
    object _23438 = NOVALUE;
    object _23437 = NOVALUE;
    object _23436 = NOVALUE;
    object _23435 = NOVALUE;
    object _23433 = NOVALUE;
    object _23432 = NOVALUE;
    object _23430 = NOVALUE;
    object _23429 = NOVALUE;
    object _23428 = NOVALUE;
    object _23426 = NOVALUE;
    object _23423 = NOVALUE;
    object _23422 = NOVALUE;
    object _23421 = NOVALUE;
    object _23420 = NOVALUE;
    object _23419 = NOVALUE;
    object _23418 = NOVALUE;
    object _23417 = NOVALUE;
    object _23416 = NOVALUE;
    object _23415 = NOVALUE;
    object _23414 = NOVALUE;
    object _23413 = NOVALUE;
    object _23412 = NOVALUE;
    object _23411 = NOVALUE;
    object _23410 = NOVALUE;
    object _23409 = NOVALUE;
    object _23407 = NOVALUE;
    object _23404 = NOVALUE;
    object _23403 = NOVALUE;
    object _23401 = NOVALUE;
    object _23398 = NOVALUE;
    object _23397 = NOVALUE;
    object _23393 = NOVALUE;
    object _23392 = NOVALUE;
    object _23390 = NOVALUE;
    object _23386 = NOVALUE;
    object _23385 = NOVALUE;
    object _23384 = NOVALUE;
    object _23383 = NOVALUE;
    object _23382 = NOVALUE;
    object _23381 = NOVALUE;
    object _23380 = NOVALUE;
    object _23379 = NOVALUE;
    object _23378 = NOVALUE;
    object _23377 = NOVALUE;
    object _23376 = NOVALUE;
    object _23375 = NOVALUE;
    object _23374 = NOVALUE;
    object _23373 = NOVALUE;
    object _23371 = NOVALUE;
    object _23370 = NOVALUE;
    object _23368 = NOVALUE;
    object _23365 = NOVALUE;
    object _23362 = NOVALUE;
    object _23359 = NOVALUE;
    object _23356 = NOVALUE;
    object _23355 = NOVALUE;
    object _23354 = NOVALUE;
    object _23351 = NOVALUE;
    object _23348 = NOVALUE;
    object _23346 = NOVALUE;
    object _23342 = NOVALUE;
    object _23341 = NOVALUE;
    object _23339 = NOVALUE;
    object _23338 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:1468		integer next_c_char, q, temps*/

    /** c_decl.e:1469		sequence buff, base_name, long_c_file, c_file*/

    /** c_decl.e:1471		if not silent then*/
    if (_36silent_21566 != 0)
    goto L1; // [9] 68

    /** c_decl.e:1472			if Pass = 1 then*/
    if (_58Pass_42556 != 1)
    goto L2; // [16] 31

    /** c_decl.e:1473				ShowMsg(1, TRANSLATING_CODE_PASS,,0)*/
    RefDS(_21997);
    _39ShowMsg(1, 239, _21997, 0);
L2: 

    /** c_decl.e:1476			if LAST_PASS = TRUE then*/
    if (_58LAST_PASS_42554 != _13TRUE_452)
    goto L3; // [37] 54

    /** c_decl.e:1477				ShowMsg(1, MSG__GENERATING)*/
    RefDS(_21997);
    _39ShowMsg(1, 240, _21997, 1);
    goto L4; // [51] 67
L3: 

    /** c_decl.e:1479				ShowMsg(1, MSG_1, Pass, 0)*/
    _39ShowMsg(1, 241, _58Pass_42556, 0);
L4: 
L1: 

    /** c_decl.e:1483		check_file_routines()*/
    _58check_file_routines();

    /** c_decl.e:1485		c_puts("// GenerateUserRoutines\n")*/
    RefDS(_23337);
    _55c_puts(_23337);

    /** c_decl.e:1486		for file_no = 1 to length(known_files) do*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _23338 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _23338 = 1;
    }
    {
        object _file_no_44799;
        _file_no_44799 = 1;
L5: 
        if (_file_no_44799 > _23338){
            goto L6; // [84] 2208
        }

        /** c_decl.e:1487			if file_no = 1 or any_code(file_no) then*/
        _23339 = (_file_no_44799 == 1);
        if (_23339 != 0) {
            goto L7; // [97] 110
        }
        _23341 = _58any_code(_file_no_44799);
        if (_23341 == 0) {
            DeRef(_23341);
            _23341 = NOVALUE;
            goto L8; // [106] 2199
        }
        else {
            if (!IS_ATOM_INT(_23341) && DBL_PTR(_23341)->dbl == 0.0){
                DeRef(_23341);
                _23341 = NOVALUE;
                goto L8; // [106] 2199
            }
            DeRef(_23341);
            _23341 = NOVALUE;
        }
        DeRef(_23341);
        _23341 = NOVALUE;
L7: 

        /** c_decl.e:1490				next_c_char = 1*/
        _next_c_char_44774 = 1;

        /** c_decl.e:1491				base_name = name_ext(known_files[file_no])*/
        _2 = (object)SEQ_PTR(_37known_files_15407);
        _23342 = (object)*(((s1_ptr)_2)->base + _file_no_44799);
        Ref(_23342);
        _0 = _base_name_44778;
        _base_name_44778 = _54name_ext(_23342);
        DeRef(_0);
        _23342 = NOVALUE;

        /** c_decl.e:1492				c_file = base_name*/
        RefDS(_base_name_44778);
        DeRef(_c_file_44780);
        _c_file_44780 = _base_name_44778;

        /** c_decl.e:1494				q = length(c_file)*/
        if (IS_SEQUENCE(_c_file_44780)){
                _q_44775 = SEQ_PTR(_c_file_44780)->length;
        }
        else {
            _q_44775 = 1;
        }

        /** c_decl.e:1495				while q >= 1 do*/
L9: 
        if (_q_44775 < 1)
        goto LA; // [146] 187

        /** c_decl.e:1496					if c_file[q] = '.' then*/
        _2 = (object)SEQ_PTR(_c_file_44780);
        _23346 = (object)*(((s1_ptr)_2)->base + _q_44775);
        if (binary_op_a(NOTEQ, _23346, 46)){
            _23346 = NOVALUE;
            goto LB; // [156] 176
        }
        _23346 = NOVALUE;

        /** c_decl.e:1497						c_file = c_file[1..q-1]*/
        _23348 = _q_44775 - 1;
        rhs_slice_target = (object_ptr)&_c_file_44780;
        RHS_Slice(_c_file_44780, 1, _23348);

        /** c_decl.e:1498						exit*/
        goto LA; // [173] 187
LB: 

        /** c_decl.e:1500					q -= 1*/
        _q_44775 = _q_44775 - 1;

        /** c_decl.e:1501				end while*/
        goto L9; // [184] 146
LA: 

        /** c_decl.e:1503				if find(lower(c_file), {"main-", "init-"})  then*/
        RefDS(_c_file_44780);
        _23351 = _14lower(_c_file_44780);
        RefDS(_23353);
        RefDS(_23352);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23352;
        ((intptr_t *)_2)[2] = _23353;
        _23354 = MAKE_SEQ(_1);
        _23355 = find_from(_23351, _23354, 1);
        DeRef(_23351);
        _23351 = NOVALUE;
        DeRefDS(_23354);
        _23354 = NOVALUE;
        if (_23355 == 0)
        {
            _23355 = NOVALUE;
            goto LC; // [202] 219
        }
        else{
            _23355 = NOVALUE;
        }

        /** c_decl.e:1504					CompileErr(MSG_1_CONFLICTS_WITH_A_FILE_NAME_USED_INTERNALLY_BY_THE_TRANSLATOR, {base_name})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_base_name_44778);
        ((intptr_t*)_2)[1] = _base_name_44778;
        _23356 = MAKE_SEQ(_1);
        _50CompileErr(12, _23356, 0);
        _23356 = NOVALUE;
LC: 

        /** c_decl.e:1507				long_c_file = c_file*/
        RefDS(_c_file_44780);
        DeRef(_long_c_file_44779);
        _long_c_file_44779 = _c_file_44780;

        /** c_decl.e:1508				if LAST_PASS = TRUE then*/
        if (_58LAST_PASS_42554 != _13TRUE_452)
        goto LD; // [232] 257

        /** c_decl.e:1509					c_file = unique_c_name(c_file)*/
        RefDS(_c_file_44780);
        _0 = _c_file_44780;
        _c_file_44780 = _58unique_c_name(_c_file_44780);
        DeRefDS(_0);

        /** c_decl.e:1510					add_file(c_file, known_files[file_no])*/
        _2 = (object)SEQ_PTR(_37known_files_15407);
        _23359 = (object)*(((s1_ptr)_2)->base + _file_no_44799);
        RefDS(_c_file_44780);
        Ref(_23359);
        _58add_file(_c_file_44780, _23359);
        _23359 = NOVALUE;
LD: 

        /** c_decl.e:1513				if file_no = 1 then*/
        if (_file_no_44799 != 1)
        goto LE; // [259] 322

        /** c_decl.e:1515					if LAST_PASS = TRUE then*/
        if (_58LAST_PASS_42554 != _13TRUE_452)
        goto LF; // [269] 314

        /** c_decl.e:1516						add_file("main-")*/
        RefDS(_23352);
        RefDS(_21997);
        _58add_file(_23352, _21997);

        /** c_decl.e:1517						for i = 0 to main_name_num-1 do*/
        _23362 = _55main_name_num_46629 - 1;
        if ((object)((uintptr_t)_23362 +(uintptr_t) HIGH_BITS) >= 0){
            _23362 = NewDouble((eudouble)_23362);
        }
        {
            object _i_44841;
            _i_44841 = 0;
L10: 
            if (binary_op_a(GREATER, _i_44841, _23362)){
                goto L11; // [287] 313
            }

            /** c_decl.e:1518							buff = sprintf("main-%d", i)*/
            DeRefi(_buff_44777);
            _buff_44777 = EPrintf(-9999999, _23363, _i_44841);

            /** c_decl.e:1519							add_file(buff)*/
            RefDS(_buff_44777);
            RefDS(_21997);
            _58add_file(_buff_44777, _21997);

            /** c_decl.e:1520						end for*/
            _0 = _i_44841;
            if (IS_ATOM_INT(_i_44841)) {
                _i_44841 = _i_44841 + 1;
                if ((object)((uintptr_t)_i_44841 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_44841 = NewDouble((eudouble)_i_44841);
                }
            }
            else {
                _i_44841 = binary_op_a(PLUS, _i_44841, 1);
            }
            DeRef(_0);
            goto L10; // [308] 294
L11: 
            ;
            DeRef(_i_44841);
        }
LF: 

        /** c_decl.e:1523					file0 = long_c_file*/
        RefDS(_long_c_file_44779);
        DeRef(_58file0_44535);
        _58file0_44535 = _long_c_file_44779;
LE: 

        /** c_decl.e:1526				new_c_file(c_file)*/
        RefDS(_c_file_44780);
        _58new_c_file(_c_file_44780);

        /** c_decl.e:1528				s = SymTab[TopLevelSub][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _23365 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21454);
        _2 = (object)SEQ_PTR(_23365);
        _s_44772 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_44772)){
            _s_44772 = (object)DBL_PTR(_s_44772)->dbl;
        }
        _23365 = NOVALUE;

        /** c_decl.e:1530				sequence these_routines = file_routines[file_no]*/
        DeRef(_these_routines_44851);
        _2 = (object)SEQ_PTR(_58file_routines_44729);
        _these_routines_44851 = (object)*(((s1_ptr)_2)->base + _file_no_44799);
        Ref(_these_routines_44851);

        /** c_decl.e:1531				for routine_no = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_44851)){
                _23368 = SEQ_PTR(_these_routines_44851)->length;
        }
        else {
            _23368 = 1;
        }
        {
            object _routine_no_44854;
            _routine_no_44854 = 1;
L12: 
            if (_routine_no_44854 > _23368){
                goto L13; // [360] 2198
            }

            /** c_decl.e:1532					s = these_routines[routine_no]*/
            _2 = (object)SEQ_PTR(_these_routines_44851);
            _s_44772 = (object)*(((s1_ptr)_2)->base + _routine_no_44854);
            if (!IS_ATOM_INT(_s_44772)){
                _s_44772 = (object)DBL_PTR(_s_44772)->dbl;
            }

            /** c_decl.e:1533					if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23370 = (object)*(((s1_ptr)_2)->base + _s_44772);
            _2 = (object)SEQ_PTR(_23370);
            _23371 = (object)*(((s1_ptr)_2)->base + 5);
            _23370 = NOVALUE;
            if (binary_op_a(EQUALS, _23371, 99)){
                _23371 = NOVALUE;
                goto L14; // [391] 2189
            }
            _23371 = NOVALUE;

            /** c_decl.e:1537						if LAST_PASS = TRUE and*/
            _23373 = (_58LAST_PASS_42554 == _13TRUE_452);
            if (_23373 == 0) {
                goto L15; // [405] 601
            }
            _23375 = (_36cfile_size_21530 > _56max_cfile_size_45409);
            if (_23375 != 0) {
                DeRef(_23376);
                _23376 = 1;
                goto L16; // [417] 480
            }
            _23377 = (_s_44772 != _36TopLevelSub_21454);
            if (_23377 == 0) {
                _23378 = 0;
                goto L17; // [427] 447
            }
            _23379 = (_56max_cfile_size_45409 % 4) ? NewDouble((eudouble)_56max_cfile_size_45409 / 4) : (_56max_cfile_size_45409 / 4);
            if (IS_ATOM_INT(_23379)) {
                _23380 = (_36cfile_size_21530 > _23379);
            }
            else {
                _23380 = ((eudouble)_36cfile_size_21530 > DBL_PTR(_23379)->dbl);
            }
            DeRef(_23379);
            _23379 = NOVALUE;
            _23378 = (_23380 != 0);
L17: 
            if (_23378 == 0) {
                _23381 = 0;
                goto L18; // [447] 476
            }
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23382 = (object)*(((s1_ptr)_2)->base + _s_44772);
            _2 = (object)SEQ_PTR(_23382);
            if (!IS_ATOM_INT(_36S_CODE_21096)){
                _23383 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21096)->dbl));
            }
            else{
                _23383 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21096);
            }
            _23382 = NOVALUE;
            if (IS_SEQUENCE(_23383)){
                    _23384 = SEQ_PTR(_23383)->length;
            }
            else {
                _23384 = 1;
            }
            _23383 = NOVALUE;
            _23385 = (_23384 > _56max_cfile_size_45409);
            _23384 = NOVALUE;
            _23381 = (_23385 != 0);
L18: 
            DeRef(_23376);
            _23376 = (_23381 != 0);
L16: 
            if (_23376 == 0)
            {
                _23376 = NOVALUE;
                goto L15; // [481] 601
            }
            else{
                _23376 = NOVALUE;
            }

            /** c_decl.e:1546							if length(c_file) = 7 then*/
            if (IS_SEQUENCE(_c_file_44780)){
                    _23386 = SEQ_PTR(_c_file_44780)->length;
            }
            else {
                _23386 = 1;
            }
            if (_23386 != 7)
            goto L19; // [489] 500

            /** c_decl.e:1548								c_file &= " "*/
            Concat((object_ptr)&_c_file_44780, _c_file_44780, _23388);
L19: 

            /** c_decl.e:1551							if length(c_file) >= 8 then*/
            if (IS_SEQUENCE(_c_file_44780)){
                    _23390 = SEQ_PTR(_c_file_44780)->length;
            }
            else {
                _23390 = 1;
            }
            if (_23390 < 8)
            goto L1A; // [505] 528

            /** c_decl.e:1552								c_file[7] = '_'*/
            _2 = (object)SEQ_PTR(_c_file_44780);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_44780 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 7);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 95;
            DeRef(_1);

            /** c_decl.e:1553								c_file[8] = file_chars[next_c_char]*/
            _2 = (object)SEQ_PTR(_58file_chars_44400);
            _23392 = (object)*(((s1_ptr)_2)->base + _next_c_char_44774);
            Ref(_23392);
            _2 = (object)SEQ_PTR(_c_file_44780);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_44780 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 8);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _23392;
            if( _1 != _23392 ){
                DeRef(_1);
            }
            _23392 = NOVALUE;
            goto L1B; // [525] 560
L1A: 

            /** c_decl.e:1556								if find('_', c_file) = 0 then*/
            _23393 = find_from(95, _c_file_44780, 1);
            if (_23393 != 0)
            goto L1C; // [535] 546

            /** c_decl.e:1557									c_file &= "_ "*/
            Concat((object_ptr)&_c_file_44780, _c_file_44780, _23395);
L1C: 

            /** c_decl.e:1560								c_file[$] = file_chars[next_c_char]*/
            if (IS_SEQUENCE(_c_file_44780)){
                    _23397 = SEQ_PTR(_c_file_44780)->length;
            }
            else {
                _23397 = 1;
            }
            _2 = (object)SEQ_PTR(_58file_chars_44400);
            _23398 = (object)*(((s1_ptr)_2)->base + _next_c_char_44774);
            Ref(_23398);
            _2 = (object)SEQ_PTR(_c_file_44780);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_44780 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _23397);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _23398;
            if( _1 != _23398 ){
                DeRef(_1);
            }
            _23398 = NOVALUE;
L1B: 

            /** c_decl.e:1564							c_file = unique_c_name(c_file)*/
            RefDS(_c_file_44780);
            _0 = _c_file_44780;
            _c_file_44780 = _58unique_c_name(_c_file_44780);
            DeRefDS(_0);

            /** c_decl.e:1565							new_c_file(c_file)*/
            RefDS(_c_file_44780);
            _58new_c_file(_c_file_44780);

            /** c_decl.e:1567							next_c_char += 1*/
            _next_c_char_44774 = _next_c_char_44774 + 1;

            /** c_decl.e:1568							if next_c_char > length(file_chars) then*/
            if (IS_SEQUENCE(_58file_chars_44400)){
                    _23401 = SEQ_PTR(_58file_chars_44400)->length;
            }
            else {
                _23401 = 1;
            }
            if (_next_c_char_44774 <= _23401)
            goto L1D; // [584] 594

            /** c_decl.e:1569								next_c_char = 1  -- (unique_c_name will resolve)*/
            _next_c_char_44774 = 1;
L1D: 

            /** c_decl.e:1572							add_file(c_file)*/
            RefDS(_c_file_44780);
            RefDS(_21997);
            _58add_file(_c_file_44780, _21997);
L15: 

            /** c_decl.e:1575						sequence ret_type*/

            /** c_decl.e:1576						if SymTab[s][S_TOKEN] = PROC then*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23403 = (object)*(((s1_ptr)_2)->base + _s_44772);
            _2 = (object)SEQ_PTR(_23403);
            if (!IS_ATOM_INT(_36S_TOKEN_21089)){
                _23404 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
            }
            else{
                _23404 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
            }
            _23403 = NOVALUE;
            if (binary_op_a(NOTEQ, _23404, 27)){
                _23404 = NOVALUE;
                goto L1E; // [619] 633
            }
            _23404 = NOVALUE;

            /** c_decl.e:1577							ret_type = "void "*/
            RefDS(_22781);
            DeRefi(_ret_type_44909);
            _ret_type_44909 = _22781;
            goto L1F; // [630] 641
L1E: 

            /** c_decl.e:1579							ret_type = "object "*/
            RefDS(_22782);
            DeRefi(_ret_type_44909);
            _ret_type_44909 = _22782;
L1F: 

            /** c_decl.e:1581						integer s_scope = sym_scope( s )*/
            _s_scope_44918 = _54sym_scope(_s_44772);
            if (!IS_ATOM_INT(_s_scope_44918)) {
                _1 = (object)(DBL_PTR(_s_scope_44918)->dbl);
                DeRefDS(_s_scope_44918);
                _s_scope_44918 = _1;
            }

            /** c_decl.e:1582						integer s_file  = SymTab[s][S_FILE_NO]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23407 = (object)*(((s1_ptr)_2)->base + _s_44772);
            _2 = (object)SEQ_PTR(_23407);
            if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
                _s_file_44921 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
            }
            else{
                _s_file_44921 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
            }
            if (!IS_ATOM_INT(_s_file_44921)){
                _s_file_44921 = (object)DBL_PTR(_s_file_44921)->dbl;
            }
            _23407 = NOVALUE;

            /** c_decl.e:1583						if dll_option and*/
            if (_58dll_option_42567 == 0) {
                goto L20; // [669] 827
            }
            _23410 = (_s_scope_44918 == 6);
            if (_23410 != 0) {
                DeRef(_23411);
                _23411 = 1;
                goto L21; // [679] 757
            }
            _23412 = (_s_file_44921 == 1);
            if (_23412 == 0) {
                _23413 = 0;
                goto L22; // [687] 715
            }
            _23414 = (_s_scope_44918 == 13);
            if (_23414 != 0) {
                _23415 = 1;
                goto L23; // [697] 711
            }
            _23416 = (_s_scope_44918 == 11);
            _23415 = (_23416 != 0);
L23: 
            _23413 = (_23415 != 0);
L22: 
            if (_23413 != 0) {
                _23417 = 1;
                goto L24; // [715] 753
            }
            _23418 = (_s_scope_44918 == 13);
            if (_23418 == 0) {
                _23419 = 0;
                goto L25; // [725] 749
            }
            _2 = (object)SEQ_PTR(_37include_matrix_15413);
            _23420 = (object)*(((s1_ptr)_2)->base + 1);
            _2 = (object)SEQ_PTR(_23420);
            _23421 = (object)*(((s1_ptr)_2)->base + _s_file_44921);
            _23420 = NOVALUE;
            if (IS_ATOM_INT(_23421)) {
                {uintptr_t tu;
                     tu = (uintptr_t)_23421 & (uintptr_t)4;
                     _23422 = MAKE_UINT(tu);
                }
            }
            else {
                _23422 = binary_op(AND_BITS, _23421, 4);
            }
            _23421 = NOVALUE;
            if (IS_ATOM_INT(_23422))
            _23419 = (_23422 != 0);
            else
            _23419 = DBL_PTR(_23422)->dbl != 0.0;
L25: 
            _23417 = (_23419 != 0);
L24: 
            DeRef(_23411);
            _23411 = (_23417 != 0);
L21: 
            if (_23411 == 0)
            {
                _23411 = NOVALUE;
                goto L20; // [758] 827
            }
            else{
                _23411 = NOVALUE;
            }

            /** c_decl.e:1589							SymTab[s][S_RI_TARGET] = TRUE*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15406 = MAKE_SEQ(_2);
            }
            _3 = (object)(_s_44772 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 53);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _13TRUE_452;
            DeRef(_1);
            _23423 = NOVALUE;

            /** c_decl.e:1590							LeftSym = TRUE*/
            _58LeftSym_42564 = _13TRUE_452;

            /** c_decl.e:1593							if TWINDOWS then*/
            if (_46TWINDOWS_21594 == 0)
            {
                goto L26; // [791] 810
            }
            else{
            }

            /** c_decl.e:1594								c_stmt(ret_type & " __stdcall @(", s)*/
            Concat((object_ptr)&_23426, _ret_type_44909, _23425);
            _58c_stmt(_23426, _s_44772, 0);
            _23426 = NOVALUE;
            goto L27; // [807] 850
L26: 

            /** c_decl.e:1596								c_stmt(ret_type & "@(", s)*/
            Concat((object_ptr)&_23428, _ret_type_44909, _23427);
            _58c_stmt(_23428, _s_44772, 0);
            _23428 = NOVALUE;
            goto L27; // [824] 850
L20: 

            /** c_decl.e:1600							LeftSym = TRUE*/
            _58LeftSym_42564 = _13TRUE_452;

            /** c_decl.e:1601							c_stmt( ret_type & "@(", s)*/
            Concat((object_ptr)&_23429, _ret_type_44909, _23427);
            _58c_stmt(_23429, _s_44772, 0);
            _23429 = NOVALUE;
L27: 

            /** c_decl.e:1605						sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23430 = (object)*(((s1_ptr)_2)->base + _s_44772);
            _2 = (object)SEQ_PTR(_23430);
            _sp_44773 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_44773)){
                _sp_44773 = (object)DBL_PTR(_sp_44773)->dbl;
            }
            _23430 = NOVALUE;

            /** c_decl.e:1606						for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23432 = (object)*(((s1_ptr)_2)->base + _s_44772);
            _2 = (object)SEQ_PTR(_23432);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
                _23433 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
            }
            else{
                _23433 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
            }
            _23432 = NOVALUE;
            {
                object _p_44968;
                _p_44968 = 1;
L28: 
                if (binary_op_a(GREATER, _p_44968, _23433)){
                    goto L29; // [880] 956
                }

                /** c_decl.e:1607							c_puts("object _")*/
                RefDS(_23434);
                _55c_puts(_23434);

                /** c_decl.e:1608							c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23435 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23435);
                if (!IS_ATOM_INT(_36S_NAME_21084)){
                    _23436 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
                }
                else{
                    _23436 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
                }
                _23435 = NOVALUE;
                Ref(_23436);
                _55c_puts(_23436);
                _23436 = NOVALUE;

                /** c_decl.e:1609							if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23437 = (object)*(((s1_ptr)_2)->base + _s_44772);
                _2 = (object)SEQ_PTR(_23437);
                if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
                    _23438 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
                }
                else{
                    _23438 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
                }
                _23437 = NOVALUE;
                if (binary_op_a(EQUALS, _p_44968, _23438)){
                    _23438 = NOVALUE;
                    goto L2A; // [923] 933
                }
                _23438 = NOVALUE;

                /** c_decl.e:1610								c_puts(", ")*/
                RefDS(_23440);
                _55c_puts(_23440);
L2A: 

                /** c_decl.e:1612							sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23441 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23441);
                _sp_44773 = (object)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_44773)){
                    _sp_44773 = (object)DBL_PTR(_sp_44773)->dbl;
                }
                _23441 = NOVALUE;

                /** c_decl.e:1613						end for*/
                _0 = _p_44968;
                if (IS_ATOM_INT(_p_44968)) {
                    _p_44968 = _p_44968 + 1;
                    if ((object)((uintptr_t)_p_44968 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_44968 = NewDouble((eudouble)_p_44968);
                    }
                }
                else {
                    _p_44968 = binary_op_a(PLUS, _p_44968, 1);
                }
                DeRef(_0);
                goto L28; // [951] 887
L29: 
                ;
                DeRef(_p_44968);
            }

            /** c_decl.e:1615						c_puts(")\n")*/
            RefDS(_23443);
            _55c_puts(_23443);

            /** c_decl.e:1616						c_stmt0("{\n")*/
            RefDS(_22101);
            _58c_stmt0(_22101);

            /** c_decl.e:1618						NewBB(0, E_ALL_EFFECT, 0)*/
            _58NewBB(0, 1073741823, 0);

            /** c_decl.e:1619						Initializing = TRUE*/
            _36Initializing_21531 = _13TRUE_452;

            /** c_decl.e:1622						while sp do*/
L2B: 
            if (_sp_44773 == 0)
            {
                goto L2C; // [989] 1128
            }
            else{
            }

            /** c_decl.e:1623							integer scope = SymTab[sp][S_SCOPE]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23444 = (object)*(((s1_ptr)_2)->base + _sp_44773);
            _2 = (object)SEQ_PTR(_23444);
            _scope_44998 = (object)*(((s1_ptr)_2)->base + 4);
            if (!IS_ATOM_INT(_scope_44998)){
                _scope_44998 = (object)DBL_PTR(_scope_44998)->dbl;
            }
            _23444 = NOVALUE;

            /** c_decl.e:1624							switch scope with fallthru do*/
            _0 = _scope_44998;
            switch ( _0 ){ 

                /** c_decl.e:1625								case SC_LOOP_VAR, SC_UNDEFINED then*/
                case 2:
                case 9:

                /** c_decl.e:1628									break*/
                goto L2D; // [1023] 1105

                /** c_decl.e:1630								case SC_PRIVATE then*/
                case 3:

                /** c_decl.e:1631									c_stmt0("object ")*/
                RefDS(_22782);
                _58c_stmt0(_22782);

                /** c_decl.e:1632									c_puts("_")*/
                RefDS(_22069);
                _55c_puts(_22069);

                /** c_decl.e:1633									c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23448 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23448);
                if (!IS_ATOM_INT(_36S_NAME_21084)){
                    _23449 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
                }
                else{
                    _23449 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
                }
                _23448 = NOVALUE;
                Ref(_23449);
                _55c_puts(_23449);
                _23449 = NOVALUE;

                /** c_decl.e:1635									c_puts(" = NOVALUE;\n")*/
                RefDS(_22790);
                _55c_puts(_22790);

                /** c_decl.e:1636									target[MIN] = NOVALUE*/
                Ref(_36NOVALUE_21301);
                _2 = (object)SEQ_PTR(_59target_28396);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28396 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _36NOVALUE_21301;
                DeRef(_1);

                /** c_decl.e:1637									target[MAX] = NOVALUE*/
                Ref(_36NOVALUE_21301);
                _2 = (object)SEQ_PTR(_59target_28396);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28396 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _36NOVALUE_21301;
                DeRef(_1);

                /** c_decl.e:1638									RemoveFromBB( sp )*/
                _58RemoveFromBB(_sp_44773);

                /** c_decl.e:1640									break*/
                goto L2D; // [1092] 1105

                /** c_decl.e:1642								case else*/
                default:

                /** c_decl.e:1643									exit*/
                goto L2C; // [1102] 1128
            ;}L2D: 

            /** c_decl.e:1645							sp = SymTab[sp][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23450 = (object)*(((s1_ptr)_2)->base + _sp_44773);
            _2 = (object)SEQ_PTR(_23450);
            _sp_44773 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_44773)){
                _sp_44773 = (object)DBL_PTR(_sp_44773)->dbl;
            }
            _23450 = NOVALUE;

            /** c_decl.e:1646						end while*/
            goto L2B; // [1125] 989
L2C: 

            /** c_decl.e:1649						temps = SymTab[s][S_TEMPS]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23452 = (object)*(((s1_ptr)_2)->base + _s_44772);
            _2 = (object)SEQ_PTR(_23452);
            if (!IS_ATOM_INT(_36S_TEMPS_21129)){
                _temps_44776 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21129)->dbl));
            }
            else{
                _temps_44776 = (object)*(((s1_ptr)_2)->base + _36S_TEMPS_21129);
            }
            if (!IS_ATOM_INT(_temps_44776)){
                _temps_44776 = (object)DBL_PTR(_temps_44776)->dbl;
            }
            _23452 = NOVALUE;

            /** c_decl.e:1650						sequence names = {}*/
            RefDS(_21997);
            DeRef(_names_45032);
            _names_45032 = _21997;

            /** c_decl.e:1651						while temps != 0 do*/
L2E: 
            if (_temps_44776 == 0)
            goto L2F; // [1156] 1348

            /** c_decl.e:1652							if SymTab[temps][S_SCOPE] != DELETED then*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23455 = (object)*(((s1_ptr)_2)->base + _temps_44776);
            _2 = (object)SEQ_PTR(_23455);
            _23456 = (object)*(((s1_ptr)_2)->base + 4);
            _23455 = NOVALUE;
            if (binary_op_a(EQUALS, _23456, 2)){
                _23456 = NOVALUE;
                goto L30; // [1176] 1308
            }
            _23456 = NOVALUE;

            /** c_decl.e:1653								sequence name = sprintf("_%d", SymTab[temps][S_TEMP_NAME] )*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23458 = (object)*(((s1_ptr)_2)->base + _temps_44776);
            _2 = (object)SEQ_PTR(_23458);
            _23459 = (object)*(((s1_ptr)_2)->base + 34);
            _23458 = NOVALUE;
            DeRefi(_name_45042);
            _name_45042 = EPrintf(-9999999, _22120, _23459);
            _23459 = NOVALUE;

            /** c_decl.e:1654								if temp_name_type[SymTab[temps][S_TEMP_NAME]][T_GTYPE]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23461 = (object)*(((s1_ptr)_2)->base + _temps_44776);
            _2 = (object)SEQ_PTR(_23461);
            _23462 = (object)*(((s1_ptr)_2)->base + 34);
            _23461 = NOVALUE;
            _2 = (object)SEQ_PTR(_36temp_name_type_21533);
            if (!IS_ATOM_INT(_23462)){
                _23463 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23462)->dbl));
            }
            else{
                _23463 = (object)*(((s1_ptr)_2)->base + _23462);
            }
            _2 = (object)SEQ_PTR(_23463);
            _23464 = (object)*(((s1_ptr)_2)->base + 1);
            _23463 = NOVALUE;
            if (IS_ATOM_INT(_23464)) {
                _23465 = (_23464 != 0);
            }
            else {
                _23465 = binary_op(NOTEQ, _23464, 0);
            }
            _23464 = NOVALUE;
            if (IS_ATOM_INT(_23465)) {
                if (_23465 == 0) {
                    goto L31; // [1230] 1304
                }
            }
            else {
                if (DBL_PTR(_23465)->dbl == 0.0) {
                    goto L31; // [1230] 1304
                }
            }
            _23467 = find_from(_name_45042, _names_45032, 1);
            _23468 = (_23467 == 0);
            _23467 = NOVALUE;
            if (_23468 == 0)
            {
                DeRef(_23468);
                _23468 = NOVALUE;
                goto L31; // [1243] 1304
            }
            else{
                DeRef(_23468);
                _23468 = NOVALUE;
            }

            /** c_decl.e:1657									c_stmt0("object ")*/
            RefDS(_22782);
            _58c_stmt0(_22782);

            /** c_decl.e:1658									c_puts( name )*/
            RefDS(_name_45042);
            _55c_puts(_name_45042);

            /** c_decl.e:1659									c_puts(" = NOVALUE")*/
            RefDS(_23469);
            _55c_puts(_23469);

            /** c_decl.e:1661									target = {NOVALUE, NOVALUE}*/
            Ref(_36NOVALUE_21301);
            Ref(_36NOVALUE_21301);
            DeRef(_59target_28396);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _36NOVALUE_21301;
            ((intptr_t *)_2)[2] = _36NOVALUE_21301;
            _59target_28396 = MAKE_SEQ(_1);

            /** c_decl.e:1663									SetBBType(temps, TYPE_INTEGER, target, TYPE_OBJECT, 0)*/
            RefDS(_59target_28396);
            _58SetBBType(_temps_44776, 1, _59target_28396, 16, 0);

            /** c_decl.e:1664									ifdef DEBUG then*/

            /** c_decl.e:1667										c_puts(";\n")*/
            RefDS(_22273);
            _55c_puts(_22273);

            /** c_decl.e:1669									names = prepend( names, name )*/
            RefDS(_name_45042);
            Prepend(&_names_45032, _names_45032, _name_45042);
            goto L32; // [1301] 1307
L31: 

            /** c_decl.e:1671									ifdef DEBUG then*/
L32: 
L30: 
            DeRefi(_name_45042);
            _name_45042 = NOVALUE;

            /** c_decl.e:1677							SymTab[temps][S_GTYPE] = TYPE_OBJECT*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15406 = MAKE_SEQ(_2);
            }
            _3 = (object)(_temps_44776 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 36);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 16;
            DeRef(_1);
            _23474 = NOVALUE;

            /** c_decl.e:1678							temps = SymTab[temps][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23476 = (object)*(((s1_ptr)_2)->base + _temps_44776);
            _2 = (object)SEQ_PTR(_23476);
            _temps_44776 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_temps_44776)){
                _temps_44776 = (object)DBL_PTR(_temps_44776)->dbl;
            }
            _23476 = NOVALUE;

            /** c_decl.e:1679						end while*/
            goto L2E; // [1345] 1156
L2F: 

            /** c_decl.e:1680						Initializing = FALSE*/
            _36Initializing_21531 = _13FALSE_450;

            /** c_decl.e:1682						if SymTab[s][S_LHS_SUBS2] then*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23478 = (object)*(((s1_ptr)_2)->base + _s_44772);
            _2 = (object)SEQ_PTR(_23478);
            _23479 = (object)*(((s1_ptr)_2)->base + 37);
            _23478 = NOVALUE;
            if (_23479 == 0) {
                _23479 = NOVALUE;
                goto L33; // [1371] 1384
            }
            else {
                if (!IS_ATOM_INT(_23479) && DBL_PTR(_23479)->dbl == 0.0){
                    _23479 = NOVALUE;
                    goto L33; // [1371] 1384
                }
                _23479 = NOVALUE;
            }
            _23479 = NOVALUE;

            /** c_decl.e:1683							c_stmt0("object _0, _1, _2, _3;\n\n")*/
            RefDS(_23480);
            _58c_stmt0(_23480);

            /** c_decl.e:1684							ifdef DEBUG then*/
            goto L34; // [1381] 1392
L33: 

            /** c_decl.e:1688							c_stmt0("object _0, _1, _2;\n\n")*/
            RefDS(_23482);
            _58c_stmt0(_23482);

            /** c_decl.e:1689							ifdef DEBUG then*/
L34: 

            /** c_decl.e:1696						sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23484 = (object)*(((s1_ptr)_2)->base + _s_44772);
            _2 = (object)SEQ_PTR(_23484);
            _sp_44773 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_44773)){
                _sp_44773 = (object)DBL_PTR(_sp_44773)->dbl;
            }
            _23484 = NOVALUE;

            /** c_decl.e:1697						for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23486 = (object)*(((s1_ptr)_2)->base + _s_44772);
            _2 = (object)SEQ_PTR(_23486);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
                _23487 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
            }
            else{
                _23487 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
            }
            _23486 = NOVALUE;
            {
                object _p_45103;
                _p_45103 = 1;
L35: 
                if (binary_op_a(GREATER, _p_45103, _23487)){
                    goto L36; // [1422] 1773
                }

                /** c_decl.e:1698							SymTab[sp][S_ONE_REF] = FALSE*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _37SymTab_15406 = MAKE_SEQ(_2);
                }
                _3 = (object)(_sp_44773 + ((s1_ptr)_2)->base);
                _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    *(intptr_t *)_3 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 35);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _13FALSE_450;
                DeRef(_1);
                _23488 = NOVALUE;

                /** c_decl.e:1699							if SymTab[sp][S_ARG_TYPE] = TYPE_SEQUENCE then*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23490 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23490);
                _23491 = (object)*(((s1_ptr)_2)->base + 43);
                _23490 = NOVALUE;
                if (binary_op_a(NOTEQ, _23491, 8)){
                    _23491 = NOVALUE;
                    goto L37; // [1462] 1526
                }
                _23491 = NOVALUE;

                /** c_decl.e:1700								target[MIN] = SymTab[sp][S_ARG_SEQ_LEN]*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23493 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23493);
                _23494 = (object)*(((s1_ptr)_2)->base + 51);
                _23493 = NOVALUE;
                Ref(_23494);
                _2 = (object)SEQ_PTR(_59target_28396);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28396 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23494;
                if( _1 != _23494 ){
                    DeRef(_1);
                }
                _23494 = NOVALUE;

                /** c_decl.e:1701								SetBBType(sp, SymTab[sp][S_ARG_TYPE], target,*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23495 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23495);
                _23496 = (object)*(((s1_ptr)_2)->base + 43);
                _23495 = NOVALUE;
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23497 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23497);
                _23498 = (object)*(((s1_ptr)_2)->base + 45);
                _23497 = NOVALUE;
                Ref(_23496);
                RefDS(_59target_28396);
                Ref(_23498);
                _58SetBBType(_sp_44773, _23496, _59target_28396, _23498, 0);
                _23496 = NOVALUE;
                _23498 = NOVALUE;
                goto L38; // [1523] 1750
L37: 

                /** c_decl.e:1704							elsif SymTab[sp][S_ARG_TYPE] = TYPE_INTEGER then*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23499 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23499);
                _23500 = (object)*(((s1_ptr)_2)->base + 43);
                _23499 = NOVALUE;
                if (binary_op_a(NOTEQ, _23500, 1)){
                    _23500 = NOVALUE;
                    goto L39; // [1542] 1666
                }
                _23500 = NOVALUE;

                /** c_decl.e:1705								if SymTab[sp][S_ARG_MIN] = NOVALUE then*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23502 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23502);
                _23503 = (object)*(((s1_ptr)_2)->base + 47);
                _23502 = NOVALUE;
                if (binary_op_a(NOTEQ, _23503, _36NOVALUE_21301)){
                    _23503 = NOVALUE;
                    goto L3A; // [1562] 1593
                }
                _23503 = NOVALUE;

                /** c_decl.e:1706									target[MIN] = MININT*/
                _2 = (object)SEQ_PTR(_59target_28396);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28396 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = -1073741824;
                DeRef(_1);

                /** c_decl.e:1707									target[MAX] = MAXINT*/
                _2 = (object)SEQ_PTR(_59target_28396);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28396 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = 1073741823;
                DeRef(_1);
                goto L3B; // [1590] 1638
L3A: 

                /** c_decl.e:1709									target[MIN] = SymTab[sp][S_ARG_MIN]*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23505 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23505);
                _23506 = (object)*(((s1_ptr)_2)->base + 47);
                _23505 = NOVALUE;
                Ref(_23506);
                _2 = (object)SEQ_PTR(_59target_28396);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28396 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23506;
                if( _1 != _23506 ){
                    DeRef(_1);
                }
                _23506 = NOVALUE;

                /** c_decl.e:1710									target[MAX] = SymTab[sp][S_ARG_MAX]*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23507 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23507);
                _23508 = (object)*(((s1_ptr)_2)->base + 48);
                _23507 = NOVALUE;
                Ref(_23508);
                _2 = (object)SEQ_PTR(_59target_28396);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28396 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23508;
                if( _1 != _23508 ){
                    DeRef(_1);
                }
                _23508 = NOVALUE;
L3B: 

                /** c_decl.e:1712								SetBBType(sp, SymTab[sp][S_ARG_TYPE], target, TYPE_OBJECT, 0)*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23509 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23509);
                _23510 = (object)*(((s1_ptr)_2)->base + 43);
                _23509 = NOVALUE;
                Ref(_23510);
                RefDS(_59target_28396);
                _58SetBBType(_sp_44773, _23510, _59target_28396, 16, 0);
                _23510 = NOVALUE;
                goto L38; // [1663] 1750
L39: 

                /** c_decl.e:1714							elsif SymTab[sp][S_ARG_TYPE] = TYPE_OBJECT then*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23511 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23511);
                _23512 = (object)*(((s1_ptr)_2)->base + 43);
                _23511 = NOVALUE;
                if (binary_op_a(NOTEQ, _23512, 16)){
                    _23512 = NOVALUE;
                    goto L3C; // [1682] 1724
                }
                _23512 = NOVALUE;

                /** c_decl.e:1716								SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue,*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23514 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23514);
                _23515 = (object)*(((s1_ptr)_2)->base + 43);
                _23514 = NOVALUE;
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23516 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23516);
                _23517 = (object)*(((s1_ptr)_2)->base + 45);
                _23516 = NOVALUE;
                Ref(_23515);
                RefDS(_55novalue_46631);
                Ref(_23517);
                _58SetBBType(_sp_44773, _23515, _55novalue_46631, _23517, 0);
                _23515 = NOVALUE;
                _23517 = NOVALUE;
                goto L38; // [1721] 1750
L3C: 

                /** c_decl.e:1720								SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue, TYPE_OBJECT, 0)*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23518 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23518);
                _23519 = (object)*(((s1_ptr)_2)->base + 43);
                _23518 = NOVALUE;
                Ref(_23519);
                RefDS(_55novalue_46631);
                _58SetBBType(_sp_44773, _23519, _55novalue_46631, 16, 0);
                _23519 = NOVALUE;
L38: 

                /** c_decl.e:1723							sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23520 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23520);
                _sp_44773 = (object)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_44773)){
                    _sp_44773 = (object)DBL_PTR(_sp_44773)->dbl;
                }
                _23520 = NOVALUE;

                /** c_decl.e:1724						end for*/
                _0 = _p_45103;
                if (IS_ATOM_INT(_p_45103)) {
                    _p_45103 = _p_45103 + 1;
                    if ((object)((uintptr_t)_p_45103 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_45103 = NewDouble((eudouble)_p_45103);
                    }
                }
                else {
                    _p_45103 = binary_op_a(PLUS, _p_45103, 1);
                }
                DeRef(_0);
                goto L35; // [1768] 1429
L36: 
                ;
                DeRef(_p_45103);
            }

            /** c_decl.e:1727						call_proc(Execute_id, {s})*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t*)_2)[1] = _s_44772;
            _23522 = MAKE_SEQ(_1);
            _1 = (object)SEQ_PTR(_23522);
            _2 = (object)((s1_ptr)_1)->base;
            _0 = (object)_00[_36Execute_id_21538].addr;
            Ref( *(( (intptr_t*)_2) + 1) );
            (*(intptr_t (*)())_0)(
                                *( ((intptr_t *)_2) + 1)
                                 );
            DeRefDS(_23522);
            _23522 = NOVALUE;

            /** c_decl.e:1729						c_puts("    ;\n}\n")*/
            RefDS(_23523);
            _55c_puts(_23523);

            /** c_decl.e:1730						if dll_option and is_exported( s ) then*/
            if (_58dll_option_42567 == 0) {
                goto L3D; // [1793] 2183
            }
            _23525 = _58is_exported(_s_44772);
            if (_23525 == 0) {
                DeRef(_23525);
                _23525 = NOVALUE;
                goto L3D; // [1802] 2183
            }
            else {
                if (!IS_ATOM_INT(_23525) && DBL_PTR(_23525)->dbl == 0.0){
                    DeRef(_23525);
                    _23525 = NOVALUE;
                    goto L3D; // [1802] 2183
                }
                DeRef(_23525);
                _23525 = NOVALUE;
            }
            DeRef(_23525);
            _23525 = NOVALUE;

            /** c_decl.e:1732							LeftSym = TRUE*/
            _58LeftSym_42564 = _13TRUE_452;

            /** c_decl.e:1733							if TOSX then*/
            if (_46TOSX_21602 == 0)
            {
                goto L3E; // [1818] 2078
            }
            else{
            }

            /** c_decl.e:1737								c_stmt0( ret_type & SymTab[s][S_NAME] & " (" )*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23526 = (object)*(((s1_ptr)_2)->base + _s_44772);
            _2 = (object)SEQ_PTR(_23526);
            if (!IS_ATOM_INT(_36S_NAME_21084)){
                _23527 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
            }
            else{
                _23527 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
            }
            _23526 = NOVALUE;
            {
                object concat_list[3];

                concat_list[0] = _23528;
                concat_list[1] = _23527;
                concat_list[2] = _ret_type_44909;
                Concat_N((object_ptr)&_23529, concat_list, 3);
            }
            _23527 = NOVALUE;
            _58c_stmt0(_23529);
            _23529 = NOVALUE;

            /** c_decl.e:1739								sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23530 = (object)*(((s1_ptr)_2)->base + _s_44772);
            _2 = (object)SEQ_PTR(_23530);
            _sp_44773 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_44773)){
                _sp_44773 = (object)DBL_PTR(_sp_44773)->dbl;
            }
            _23530 = NOVALUE;

            /** c_decl.e:1740								for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23532 = (object)*(((s1_ptr)_2)->base + _s_44772);
            _2 = (object)SEQ_PTR(_23532);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
                _23533 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
            }
            else{
                _23533 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
            }
            _23532 = NOVALUE;
            {
                object _p_45222;
                _p_45222 = 1;
L3F: 
                if (binary_op_a(GREATER, _p_45222, _23533)){
                    goto L40; // [1876] 1952
                }

                /** c_decl.e:1741									c_puts("int _")*/
                RefDS(_23534);
                _55c_puts(_23534);

                /** c_decl.e:1742									c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23535 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23535);
                if (!IS_ATOM_INT(_36S_NAME_21084)){
                    _23536 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
                }
                else{
                    _23536 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
                }
                _23535 = NOVALUE;
                Ref(_23536);
                _55c_puts(_23536);
                _23536 = NOVALUE;

                /** c_decl.e:1743									if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23537 = (object)*(((s1_ptr)_2)->base + _s_44772);
                _2 = (object)SEQ_PTR(_23537);
                if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
                    _23538 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
                }
                else{
                    _23538 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
                }
                _23537 = NOVALUE;
                if (binary_op_a(EQUALS, _p_45222, _23538)){
                    _23538 = NOVALUE;
                    goto L41; // [1919] 1929
                }
                _23538 = NOVALUE;

                /** c_decl.e:1744										c_puts(", ")*/
                RefDS(_23440);
                _55c_puts(_23440);
L41: 

                /** c_decl.e:1746									sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23540 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23540);
                _sp_44773 = (object)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_44773)){
                    _sp_44773 = (object)DBL_PTR(_sp_44773)->dbl;
                }
                _23540 = NOVALUE;

                /** c_decl.e:1747								end for*/
                _0 = _p_45222;
                if (IS_ATOM_INT(_p_45222)) {
                    _p_45222 = _p_45222 + 1;
                    if ((object)((uintptr_t)_p_45222 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_45222 = NewDouble((eudouble)_p_45222);
                    }
                }
                else {
                    _p_45222 = binary_op_a(PLUS, _p_45222, 1);
                }
                DeRef(_0);
                goto L3F; // [1947] 1883
L40: 
                ;
                DeRef(_p_45222);
            }

            /** c_decl.e:1749								c_puts( ") {\n")*/
            RefDS(_23542);
            _55c_puts(_23542);

            /** c_decl.e:1750								c_stmt("    return @(", s)*/
            RefDS(_23543);
            _58c_stmt(_23543, _s_44772, 0);

            /** c_decl.e:1751								sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23544 = (object)*(((s1_ptr)_2)->base + _s_44772);
            _2 = (object)SEQ_PTR(_23544);
            _sp_44773 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_44773)){
                _sp_44773 = (object)DBL_PTR(_sp_44773)->dbl;
            }
            _23544 = NOVALUE;

            /** c_decl.e:1752								for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23546 = (object)*(((s1_ptr)_2)->base + _s_44772);
            _2 = (object)SEQ_PTR(_23546);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
                _23547 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
            }
            else{
                _23547 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
            }
            _23546 = NOVALUE;
            {
                object _p_45253;
                _p_45253 = 1;
L42: 
                if (binary_op_a(GREATER, _p_45253, _23547)){
                    goto L43; // [1994] 2070
                }

                /** c_decl.e:1753									c_puts("_")*/
                RefDS(_22069);
                _55c_puts(_22069);

                /** c_decl.e:1754									c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23548 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23548);
                if (!IS_ATOM_INT(_36S_NAME_21084)){
                    _23549 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
                }
                else{
                    _23549 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
                }
                _23548 = NOVALUE;
                Ref(_23549);
                _55c_puts(_23549);
                _23549 = NOVALUE;

                /** c_decl.e:1755									if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23550 = (object)*(((s1_ptr)_2)->base + _s_44772);
                _2 = (object)SEQ_PTR(_23550);
                if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
                    _23551 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
                }
                else{
                    _23551 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
                }
                _23550 = NOVALUE;
                if (binary_op_a(EQUALS, _p_45253, _23551)){
                    _23551 = NOVALUE;
                    goto L44; // [2037] 2047
                }
                _23551 = NOVALUE;

                /** c_decl.e:1756										c_puts(", ")*/
                RefDS(_23440);
                _55c_puts(_23440);
L44: 

                /** c_decl.e:1758									sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23553 = (object)*(((s1_ptr)_2)->base + _sp_44773);
                _2 = (object)SEQ_PTR(_23553);
                _sp_44773 = (object)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_44773)){
                    _sp_44773 = (object)DBL_PTR(_sp_44773)->dbl;
                }
                _23553 = NOVALUE;

                /** c_decl.e:1759								end for*/
                _0 = _p_45253;
                if (IS_ATOM_INT(_p_45253)) {
                    _p_45253 = _p_45253 + 1;
                    if ((object)((uintptr_t)_p_45253 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_45253 = NewDouble((eudouble)_p_45253);
                    }
                }
                else {
                    _p_45253 = binary_op_a(PLUS, _p_45253, 1);
                }
                DeRef(_0);
                goto L42; // [2065] 2001
L43: 
                ;
                DeRef(_p_45253);
            }

            /** c_decl.e:1761								c_puts( ");\n}\n" )*/
            RefDS(_23555);
            _55c_puts(_23555);
            goto L45; // [2075] 2173
L3E: 

            /** c_decl.e:1762							elsif TWINDOWS then*/
            if (_46TWINDOWS_21594 == 0)
            {
                goto L46; // [2082] 2145
            }
            else{
            }

            /** c_decl.e:1766								c_stmt0( ret_type & SymTab[s][S_NAME] & "() __attribute__ ((alias (\"" )*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23556 = (object)*(((s1_ptr)_2)->base + _s_44772);
            _2 = (object)SEQ_PTR(_23556);
            if (!IS_ATOM_INT(_36S_NAME_21084)){
                _23557 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
            }
            else{
                _23557 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
            }
            _23556 = NOVALUE;
            {
                object concat_list[3];

                concat_list[0] = _23558;
                concat_list[1] = _23557;
                concat_list[2] = _ret_type_44909;
                Concat_N((object_ptr)&_23559, concat_list, 3);
            }
            _23557 = NOVALUE;
            _58c_stmt0(_23559);
            _23559 = NOVALUE;

            /** c_decl.e:1767								CName( s )*/
            _58CName(_s_44772);

            /** c_decl.e:1768								c_puts( sprintf( "@%d\")));\n", SymTab[s][S_NUM_ARGS] * TARGET_SIZEOF_POINTER ) )*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23561 = (object)*(((s1_ptr)_2)->base + _s_44772);
            _2 = (object)SEQ_PTR(_23561);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
                _23562 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
            }
            else{
                _23562 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
            }
            _23561 = NOVALUE;
            if (IS_ATOM_INT(_23562)) {
                if (_23562 == (short)_23562){
                    _23563 = _23562 * _36TARGET_SIZEOF_POINTER_21269;
                }
                else{
                    _23563 = NewDouble(_23562 * (eudouble)_36TARGET_SIZEOF_POINTER_21269);
                }
            }
            else {
                _23563 = binary_op(MULTIPLY, _23562, _36TARGET_SIZEOF_POINTER_21269);
            }
            _23562 = NOVALUE;
            _23564 = EPrintf(-9999999, _23560, _23563);
            DeRef(_23563);
            _23563 = NOVALUE;
            _55c_puts(_23564);
            _23564 = NOVALUE;
            goto L45; // [2142] 2173
L46: 

            /** c_decl.e:1770								c_stmt( ret_type & SymTab[s][S_NAME] & "() __attribute__ ((alias (\"@\")));\n", s )*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23565 = (object)*(((s1_ptr)_2)->base + _s_44772);
            _2 = (object)SEQ_PTR(_23565);
            if (!IS_ATOM_INT(_36S_NAME_21084)){
                _23566 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
            }
            else{
                _23566 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
            }
            _23565 = NOVALUE;
            {
                object concat_list[3];

                concat_list[0] = _23567;
                concat_list[1] = _23566;
                concat_list[2] = _ret_type_44909;
                Concat_N((object_ptr)&_23568, concat_list, 3);
            }
            _23566 = NOVALUE;
            _58c_stmt(_23568, _s_44772, 0);
            _23568 = NOVALUE;
L45: 

            /** c_decl.e:1772							LeftSym = FALSE*/
            _58LeftSym_42564 = _13FALSE_450;
L3D: 

            /** c_decl.e:1774						c_puts("\n\n" )*/
            RefDS(_22141);
            _55c_puts(_22141);
L14: 
            DeRefi(_ret_type_44909);
            _ret_type_44909 = NOVALUE;
            DeRef(_names_45032);
            _names_45032 = NOVALUE;

            /** c_decl.e:1776				end for*/
            _routine_no_44854 = _routine_no_44854 + 1;
            goto L12; // [2193] 367
L13: 
            ;
        }
L8: 
        DeRef(_these_routines_44851);
        _these_routines_44851 = NOVALUE;

        /** c_decl.e:1778		end for*/
        _file_no_44799 = _file_no_44799 + 1;
        goto L5; // [2203] 91
L6: 
        ;
    }

    /** c_decl.e:1779	end procedure*/
    DeRefi(_buff_44777);
    DeRef(_base_name_44778);
    DeRef(_long_c_file_44779);
    DeRef(_c_file_44780);
    DeRef(_23362);
    _23362 = NOVALUE;
    DeRef(_23418);
    _23418 = NOVALUE;
    _23433 = NOVALUE;
    _23487 = NOVALUE;
    DeRef(_23410);
    _23410 = NOVALUE;
    DeRef(_23385);
    _23385 = NOVALUE;
    DeRef(_23380);
    _23380 = NOVALUE;
    _23533 = NOVALUE;
    _23462 = NOVALUE;
    DeRef(_23375);
    _23375 = NOVALUE;
    DeRef(_23373);
    _23373 = NOVALUE;
    DeRef(_23416);
    _23416 = NOVALUE;
    DeRef(_23339);
    _23339 = NOVALUE;
    _23383 = NOVALUE;
    DeRef(_23422);
    _23422 = NOVALUE;
    DeRef(_23412);
    _23412 = NOVALUE;
    DeRef(_23465);
    _23465 = NOVALUE;
    _23547 = NOVALUE;
    DeRef(_23348);
    _23348 = NOVALUE;
    DeRef(_23414);
    _23414 = NOVALUE;
    DeRef(_23377);
    _23377 = NOVALUE;
    return;
    ;
}



// 0xA66CD98F
