// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _49add_options(object _new_options_49727)
{
    object _0, _1, _2;
    

    /** cominit.e:65		options = splice(options, new_options, COMMON_OPTIONS_SPLICE_IDX)*/
    {
        s1_ptr assign_space;
        insert_pos = 16;
        if (insert_pos <= 0) {
            Concat(&_49options_49723,_new_options_49727,_49options_49723);
        }
        else if (insert_pos > SEQ_PTR(_49options_49723)->length){
            Concat(&_49options_49723,_49options_49723,_new_options_49727);
        }
        else if (IS_SEQUENCE(_new_options_49727)) {
            if( _49options_49723 != _49options_49723 || SEQ_PTR( _49options_49723 )->ref != 1 ){
                DeRef( _49options_49723 );
                RefDS( _49options_49723 );
            }
            assign_space = Add_internal_space( _49options_49723, insert_pos,((s1_ptr)SEQ_PTR(_new_options_49727))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_new_options_49727), _49options_49723 == _49options_49723 );
            _49options_49723 = MAKE_SEQ( assign_space );
        }
        else {
            if( _49options_49723 == _49options_49723 && SEQ_PTR( _49options_49723 )->ref == 1 ){
                _49options_49723 = Insert( _49options_49723, _new_options_49727, insert_pos);
            }
            else {
                DeRef( _49options_49723 );
                RefDS( _49options_49723 );
                _49options_49723 = Insert( _49options_49723, _new_options_49727, insert_pos);
            }
        }
    }

    /** cominit.e:67	end procedure*/
    DeRefDS(_new_options_49727);
    return;
    ;
}


object _49get_options()
{
    object _0, _1, _2;
    

    /** cominit.e:73		return options*/
    RefDS(_49options_49723);
    return _49options_49723;
    ;
}


object _49get_switches()
{
    object _0, _1, _2;
    

    /** cominit.e:87		return switches*/
    RefDS(_49switches_49596);
    return _49switches_49596;
    ;
}


void _49show_copyrights()
{
    object _notices_49737 = NOVALUE;
    object _25503 = NOVALUE;
    object _25502 = NOVALUE;
    object _25500 = NOVALUE;
    object _25499 = NOVALUE;
    object _25498 = NOVALUE;
    object _25497 = NOVALUE;
    object _25495 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:94		sequence notices = all_copyrights()*/
    _0 = _notices_49737;
    _notices_49737 = _33all_copyrights();
    DeRef(_0);

    /** cominit.e:95		for i = 1 to length(notices) do*/
    if (IS_SEQUENCE(_notices_49737)){
            _25495 = SEQ_PTR(_notices_49737)->length;
    }
    else {
        _25495 = 1;
    }
    {
        object _i_49741;
        _i_49741 = 1;
L1: 
        if (_i_49741 > _25495){
            goto L2; // [13] 60
        }

        /** cominit.e:96			printf(2, "%s\n  %s\n\n", { notices[i][1], match_replace("\n", notices[i][2], "\n  ") })*/
        _2 = (object)SEQ_PTR(_notices_49737);
        _25497 = (object)*(((s1_ptr)_2)->base + _i_49741);
        _2 = (object)SEQ_PTR(_25497);
        _25498 = (object)*(((s1_ptr)_2)->base + 1);
        _25497 = NOVALUE;
        _2 = (object)SEQ_PTR(_notices_49737);
        _25499 = (object)*(((s1_ptr)_2)->base + _i_49741);
        _2 = (object)SEQ_PTR(_25499);
        _25500 = (object)*(((s1_ptr)_2)->base + 2);
        _25499 = NOVALUE;
        RefDS(_22192);
        Ref(_25500);
        RefDS(_25501);
        _25502 = _16match_replace(_22192, _25500, _25501, 0);
        _25500 = NOVALUE;
        Ref(_25498);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _25498;
        ((intptr_t *)_2)[2] = _25502;
        _25503 = MAKE_SEQ(_1);
        _25502 = NOVALUE;
        _25498 = NOVALUE;
        EPrintf(2, _25496, _25503);
        DeRefDS(_25503);
        _25503 = NOVALUE;

        /** cominit.e:97		end for*/
        _i_49741 = _i_49741 + 1;
        goto L1; // [55] 20
L2: 
        ;
    }

    /** cominit.e:98	end procedure*/
    DeRef(_notices_49737);
    return;
    ;
}


void _49show_banner()
{
    object _version_type_inlined_version_type_at_220_49810 = NOVALUE;
    object _version_string_short_1__tmp_at204_49808 = NOVALUE;
    object _version_string_short_inlined_version_string_short_at_204_49807 = NOVALUE;
    object _version_revision_inlined_version_revision_at_133_49788 = NOVALUE;
    object _platform_name_inlined_platform_name_at_94_49780 = NOVALUE;
    object _prod_name_49754 = NOVALUE;
    object _memory_type_49755 = NOVALUE;
    object _misc_info_49777 = NOVALUE;
    object _EuConsole_49792 = NOVALUE;
    object _25528 = NOVALUE;
    object _25527 = NOVALUE;
    object _25526 = NOVALUE;
    object _25523 = NOVALUE;
    object _25522 = NOVALUE;
    object _25518 = NOVALUE;
    object _25517 = NOVALUE;
    object _25516 = NOVALUE;
    object _25514 = NOVALUE;
    object _25512 = NOVALUE;
    object _25511 = NOVALUE;
    object _25510 = NOVALUE;
    object _25505 = NOVALUE;
    object _25504 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:109		if INTERPRET and not BIND then*/
    if (_36INTERPRET_21046 == 0) {
        goto L1; // [5] 33
    }
    _25505 = (_36BIND_21052 == 0);
    if (_25505 == 0)
    {
        DeRef(_25505);
        _25505 = NOVALUE;
        goto L1; // [15] 33
    }
    else{
        DeRef(_25505);
        _25505 = NOVALUE;
    }

    /** cominit.e:110			prod_name = GetMsgText(EUPHORIA_INTERPRETER,0)*/
    RefDS(_21997);
    _0 = _prod_name_49754;
    _prod_name_49754 = _39GetMsgText(270, 0, _21997);
    DeRef(_0);
    goto L2; // [30] 76
L1: 

    /** cominit.e:112		elsif TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L3; // [37] 55
    }
    else{
    }

    /** cominit.e:113			prod_name = GetMsgText(EUPHORIA_TO_C_TRANSLATOR,0)*/
    RefDS(_21997);
    _0 = _prod_name_49754;
    _prod_name_49754 = _39GetMsgText(271, 0, _21997);
    DeRef(_0);
    goto L2; // [52] 76
L3: 

    /** cominit.e:115		elsif BIND then*/
    if (_36BIND_21052 == 0)
    {
        goto L4; // [59] 75
    }
    else{
    }

    /** cominit.e:116			prod_name = GetMsgText(EUPHORIA_BINDER,0)*/
    RefDS(_21997);
    _0 = _prod_name_49754;
    _prod_name_49754 = _39GetMsgText(272, 0, _21997);
    DeRef(_0);
L4: 
L2: 

    /** cominit.e:119		ifdef EU_MANAGED_MEM then*/

    /** cominit.e:122			memory_type = GetMsgText(USING_SYSTEM_MEMORY,0)*/
    RefDS(_21997);
    _0 = _memory_type_49755;
    _memory_type_49755 = _39GetMsgText(274, 0, _21997);
    DeRef(_0);

    /** cominit.e:125		sequence misc_info = {*/
    _25510 = _33arch_bits();

    /** info.e:48		ifdef WINDOWS then*/

    /** info.e:51			return "Linux"*/
    RefDS(_6723);
    DeRefi(_platform_name_inlined_platform_name_at_94_49780);
    _platform_name_inlined_platform_name_at_94_49780 = _6723;
    _25511 = _33version_date(0);
    _25512 = _33version_node(0);
    _0 = _misc_info_49777;
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25510;
    RefDS(_platform_name_inlined_platform_name_at_94_49780);
    ((intptr_t*)_2)[2] = _platform_name_inlined_platform_name_at_94_49780;
    RefDS(_memory_type_49755);
    ((intptr_t*)_2)[3] = _memory_type_49755;
    RefDS(_21997);
    ((intptr_t*)_2)[4] = _21997;
    ((intptr_t*)_2)[5] = _25511;
    ((intptr_t*)_2)[6] = _25512;
    _misc_info_49777 = MAKE_SEQ(_1);
    DeRef(_0);
    _25512 = NOVALUE;
    _25511 = NOVALUE;
    _25510 = NOVALUE;

    /** cominit.e:134		if info:is_developmental then*/
    if (_33is_developmental_11979 == 0)
    {
        goto L5; // [126] 160
    }
    else{
    }

    /** cominit.e:135			misc_info[$] = sprintf("%d:%s", { info:version_revision(), info:version_node() })*/
    _25514 = 6;

    /** info.e:157		return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_133_49788);
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _version_revision_inlined_version_revision_at_133_49788 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_version_revision_inlined_version_revision_at_133_49788);
    _25516 = _33version_node(0);
    Ref(_version_revision_inlined_version_revision_at_133_49788);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _version_revision_inlined_version_revision_at_133_49788;
    ((intptr_t *)_2)[2] = _25516;
    _25517 = MAKE_SEQ(_1);
    _25516 = NOVALUE;
    _25518 = EPrintf(-9999999, _25515, _25517);
    DeRefDS(_25517);
    _25517 = NOVALUE;
    _2 = (object)SEQ_PTR(_misc_info_49777);
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25518;
    if( _1 != _25518 ){
        DeRef(_1);
    }
    _25518 = NOVALUE;
L5: 

    /** cominit.e:138		object EuConsole = getenv("EUCONS")*/
    DeRefi(_EuConsole_49792);
    _EuConsole_49792 = EGetEnv(_25519);

    /** cominit.e:139		if equal(EuConsole, "1") then*/
    if (_EuConsole_49792 == _25521)
    _25522 = 1;
    else if (IS_ATOM_INT(_EuConsole_49792) && IS_ATOM_INT(_25521))
    _25522 = 0;
    else
    _25522 = (compare(_EuConsole_49792, _25521) == 0);
    if (_25522 == 0)
    {
        _25522 = NOVALUE;
        goto L6; // [171] 191
    }
    else{
        _25522 = NOVALUE;
    }

    /** cominit.e:140			misc_info[4] = GetMsgText(EUCONSOLE,0)*/
    RefDS(_21997);
    _25523 = _39GetMsgText(275, 0, _21997);
    _2 = (object)SEQ_PTR(_misc_info_49777);
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25523;
    if( _1 != _25523 ){
        DeRef(_1);
    }
    _25523 = NOVALUE;
    goto L7; // [188] 199
L6: 

    /** cominit.e:142			misc_info = remove(misc_info, 4)*/
    {
        s1_ptr assign_space = SEQ_PTR(_misc_info_49777);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(4)) ? 4 : (object)(DBL_PTR(4)->dbl);
        int stop = (IS_ATOM_INT(4)) ? 4 : (object)(DBL_PTR(4)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_misc_info_49777), start, &_misc_info_49777 );
            }
            else Tail(SEQ_PTR(_misc_info_49777), stop+1, &_misc_info_49777);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_misc_info_49777), start, &_misc_info_49777);
        }
        else {
            assign_slice_seq = &assign_space;
            _misc_info_49777 = Remove_elements(start, stop, (SEQ_PTR(_misc_info_49777)->ref == 1));
        }
    }
L7: 

    /** cominit.e:145		screen_output(STDERR, sprintf("%s v%s %s\n   %s %s, %s\n   Revision Date: %s, Id: %s\n", {*/

    /** info.e:261		return sprintf("%d.%d.%d", version_info[MAJ_VER..PAT_VER])*/
    rhs_slice_target = (object_ptr)&_version_string_short_1__tmp_at204_49808;
    RHS_Slice(_33version_info_11977, 1, 3);
    DeRefi(_version_string_short_inlined_version_string_short_at_204_49807);
    _version_string_short_inlined_version_string_short_at_204_49807 = EPrintf(-9999999, _6780, _version_string_short_1__tmp_at204_49808);
    DeRef(_version_string_short_1__tmp_at204_49808);
    _version_string_short_1__tmp_at204_49808 = NOVALUE;

    /** info.e:202		return version_info[VER_TYPE]*/
    DeRef(_version_type_inlined_version_type_at_220_49810);
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _version_type_inlined_version_type_at_220_49810 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_version_type_inlined_version_type_at_220_49810);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_prod_name_49754);
    ((intptr_t*)_2)[1] = _prod_name_49754;
    RefDS(_version_string_short_inlined_version_string_short_at_204_49807);
    ((intptr_t*)_2)[2] = _version_string_short_inlined_version_string_short_at_204_49807;
    Ref(_version_type_inlined_version_type_at_220_49810);
    ((intptr_t*)_2)[3] = _version_type_inlined_version_type_at_220_49810;
    _25526 = MAKE_SEQ(_1);
    Concat((object_ptr)&_25527, _25526, _misc_info_49777);
    DeRefDS(_25526);
    _25526 = NOVALUE;
    DeRef(_25526);
    _25526 = NOVALUE;
    _25528 = EPrintf(-9999999, _25525, _25527);
    DeRefDS(_25527);
    _25527 = NOVALUE;
    _50screen_output(2, _25528);
    _25528 = NOVALUE;

    /** cominit.e:147	end procedure*/
    DeRefDS(_prod_name_49754);
    DeRef(_memory_type_49755);
    DeRefDS(_misc_info_49777);
    DeRefi(_EuConsole_49792);
    return;
    ;
}


object _49find_opt(object _name_type_49822, object _opt_49823, object _opts_49824)
{
    object _o_49828 = NOVALUE;
    object _has_case_49830 = NOVALUE;
    object _25541 = NOVALUE;
    object _25540 = NOVALUE;
    object _25539 = NOVALUE;
    object _25538 = NOVALUE;
    object _25537 = NOVALUE;
    object _25536 = NOVALUE;
    object _25535 = NOVALUE;
    object _25534 = NOVALUE;
    object _25533 = NOVALUE;
    object _25531 = NOVALUE;
    object _25529 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:172		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_49824)){
            _25529 = SEQ_PTR(_opts_49824)->length;
    }
    else {
        _25529 = 1;
    }
    {
        object _i_49826;
        _i_49826 = 1;
L1: 
        if (_i_49826 > _25529){
            goto L2; // [12] 113
        }

        /** cominit.e:173			sequence o = opts[i]		*/
        DeRef(_o_49828);
        _2 = (object)SEQ_PTR(_opts_49824);
        _o_49828 = (object)*(((s1_ptr)_2)->base + _i_49826);
        Ref(_o_49828);

        /** cominit.e:174			integer has_case = find(HAS_CASE, o[OPTIONS])*/
        _2 = (object)SEQ_PTR(_o_49828);
        _25531 = (object)*(((s1_ptr)_2)->base + 4);
        _has_case_49830 = find_from(99, _25531, 1);
        _25531 = NOVALUE;

        /** cominit.e:176			if has_case and equal(o[name_type], opt) then*/
        if (_has_case_49830 == 0) {
            goto L3; // [42] 67
        }
        _2 = (object)SEQ_PTR(_o_49828);
        _25534 = (object)*(((s1_ptr)_2)->base + _name_type_49822);
        if (_25534 == _opt_49823)
        _25535 = 1;
        else if (IS_ATOM_INT(_25534) && IS_ATOM_INT(_opt_49823))
        _25535 = 0;
        else
        _25535 = (compare(_25534, _opt_49823) == 0);
        _25534 = NOVALUE;
        if (_25535 == 0)
        {
            _25535 = NOVALUE;
            goto L3; // [55] 67
        }
        else{
            _25535 = NOVALUE;
        }

        /** cominit.e:177				return o*/
        DeRefDS(_opt_49823);
        DeRefDS(_opts_49824);
        return _o_49828;
        goto L4; // [64] 104
L3: 

        /** cominit.e:178			elsif not has_case and equal(text:lower(o[name_type]), text:lower(opt)) then*/
        _25536 = (_has_case_49830 == 0);
        if (_25536 == 0) {
            goto L5; // [72] 103
        }
        _2 = (object)SEQ_PTR(_o_49828);
        _25538 = (object)*(((s1_ptr)_2)->base + _name_type_49822);
        Ref(_25538);
        _25539 = _14lower(_25538);
        _25538 = NOVALUE;
        RefDS(_opt_49823);
        _25540 = _14lower(_opt_49823);
        if (_25539 == _25540)
        _25541 = 1;
        else if (IS_ATOM_INT(_25539) && IS_ATOM_INT(_25540))
        _25541 = 0;
        else
        _25541 = (compare(_25539, _25540) == 0);
        DeRef(_25539);
        _25539 = NOVALUE;
        DeRef(_25540);
        _25540 = NOVALUE;
        if (_25541 == 0)
        {
            _25541 = NOVALUE;
            goto L5; // [93] 103
        }
        else{
            _25541 = NOVALUE;
        }

        /** cominit.e:179				return o*/
        DeRefDS(_opt_49823);
        DeRefDS(_opts_49824);
        DeRef(_25536);
        _25536 = NOVALUE;
        return _o_49828;
L5: 
L4: 
        DeRef(_o_49828);
        _o_49828 = NOVALUE;

        /** cominit.e:181		end for*/
        _i_49826 = _i_49826 + 1;
        goto L1; // [108] 19
L2: 
        ;
    }

    /** cominit.e:183		return {}*/
    RefDS(_21997);
    DeRefDS(_opt_49823);
    DeRefDS(_opts_49824);
    DeRef(_25536);
    _25536 = NOVALUE;
    return _21997;
    ;
}


object _49merge_parameters(object _a_49847, object _b_49848, object _opts_49849, object _dedupe_49850)
{
    object _i_49851 = NOVALUE;
    object _opt_49855 = NOVALUE;
    object _this_opt_49861 = NOVALUE;
    object _bi_49862 = NOVALUE;
    object _beginLen_49922 = NOVALUE;
    object _first_extra_49944 = NOVALUE;
    object _opt_49948 = NOVALUE;
    object _this_opt_49953 = NOVALUE;
    object _25635 = NOVALUE;
    object _25634 = NOVALUE;
    object _25631 = NOVALUE;
    object _25630 = NOVALUE;
    object _25629 = NOVALUE;
    object _25627 = NOVALUE;
    object _25626 = NOVALUE;
    object _25625 = NOVALUE;
    object _25624 = NOVALUE;
    object _25622 = NOVALUE;
    object _25621 = NOVALUE;
    object _25619 = NOVALUE;
    object _25618 = NOVALUE;
    object _25617 = NOVALUE;
    object _25616 = NOVALUE;
    object _25615 = NOVALUE;
    object _25614 = NOVALUE;
    object _25613 = NOVALUE;
    object _25611 = NOVALUE;
    object _25608 = NOVALUE;
    object _25607 = NOVALUE;
    object _25602 = NOVALUE;
    object _25600 = NOVALUE;
    object _25599 = NOVALUE;
    object _25598 = NOVALUE;
    object _25597 = NOVALUE;
    object _25596 = NOVALUE;
    object _25595 = NOVALUE;
    object _25594 = NOVALUE;
    object _25593 = NOVALUE;
    object _25589 = NOVALUE;
    object _25588 = NOVALUE;
    object _25587 = NOVALUE;
    object _25586 = NOVALUE;
    object _25585 = NOVALUE;
    object _25584 = NOVALUE;
    object _25583 = NOVALUE;
    object _25582 = NOVALUE;
    object _25581 = NOVALUE;
    object _25580 = NOVALUE;
    object _25579 = NOVALUE;
    object _25578 = NOVALUE;
    object _25577 = NOVALUE;
    object _25576 = NOVALUE;
    object _25575 = NOVALUE;
    object _25573 = NOVALUE;
    object _25572 = NOVALUE;
    object _25571 = NOVALUE;
    object _25570 = NOVALUE;
    object _25569 = NOVALUE;
    object _25568 = NOVALUE;
    object _25567 = NOVALUE;
    object _25566 = NOVALUE;
    object _25564 = NOVALUE;
    object _25563 = NOVALUE;
    object _25562 = NOVALUE;
    object _25561 = NOVALUE;
    object _25559 = NOVALUE;
    object _25558 = NOVALUE;
    object _25557 = NOVALUE;
    object _25556 = NOVALUE;
    object _25555 = NOVALUE;
    object _25554 = NOVALUE;
    object _25553 = NOVALUE;
    object _25551 = NOVALUE;
    object _25550 = NOVALUE;
    object _25548 = NOVALUE;
    object _25545 = NOVALUE;
    object _25542 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:199		integer i = 1*/
    _i_49851 = 1;

    /** cominit.e:201		while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_49847)){
            _25542 = SEQ_PTR(_a_49847)->length;
    }
    else {
        _25542 = 1;
    }
    if (_i_49851 > _25542)
    goto L2; // [22] 465

    /** cominit.e:202			sequence opt = a[i]*/
    DeRef(_opt_49855);
    _2 = (object)SEQ_PTR(_a_49847);
    _opt_49855 = (object)*(((s1_ptr)_2)->base + _i_49851);
    Ref(_opt_49855);

    /** cominit.e:203			if length(opt) < 2 then*/
    if (IS_SEQUENCE(_opt_49855)){
            _25545 = SEQ_PTR(_opt_49855)->length;
    }
    else {
        _25545 = 1;
    }
    if (_25545 >= 2)
    goto L3; // [39] 56

    /** cominit.e:204				i += 1*/
    _i_49851 = _i_49851 + 1;

    /** cominit.e:205				continue*/
    DeRefDS(_opt_49855);
    _opt_49855 = NOVALUE;
    DeRef(_this_opt_49861);
    _this_opt_49861 = NOVALUE;
    goto L1; // [53] 19
L3: 

    /** cominit.e:208			sequence this_opt = {}*/
    RefDS(_21997);
    DeRef(_this_opt_49861);
    _this_opt_49861 = _21997;

    /** cominit.e:209			integer bi = 0*/
    _bi_49862 = 0;

    /** cominit.e:211			if opt[2] = '-' then*/
    _2 = (object)SEQ_PTR(_opt_49855);
    _25548 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _25548, 45)){
        _25548 = NOVALUE;
        goto L4; // [74] 149
    }
    _25548 = NOVALUE;

    /** cominit.e:214				this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_49855)){
            _25550 = SEQ_PTR(_opt_49855)->length;
    }
    else {
        _25550 = 1;
    }
    rhs_slice_target = (object_ptr)&_25551;
    RHS_Slice(_opt_49855, 3, _25550);
    RefDS(_opts_49849);
    _0 = _this_opt_49861;
    _this_opt_49861 = _49find_opt(2, _25551, _opts_49849);
    DeRefDS(_0);
    _25551 = NOVALUE;

    /** cominit.e:216				for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_49848)){
            _25553 = SEQ_PTR(_b_49848)->length;
    }
    else {
        _25553 = 1;
    }
    {
        object _j_49870;
        _j_49870 = 1;
L5: 
        if (_j_49870 > _25553){
            goto L6; // [101] 146
        }

        /** cominit.e:217					if equal(text:lower(b[j]), text:lower(opt)) then*/
        _2 = (object)SEQ_PTR(_b_49848);
        _25554 = (object)*(((s1_ptr)_2)->base + _j_49870);
        Ref(_25554);
        _25555 = _14lower(_25554);
        _25554 = NOVALUE;
        RefDS(_opt_49855);
        _25556 = _14lower(_opt_49855);
        if (_25555 == _25556)
        _25557 = 1;
        else if (IS_ATOM_INT(_25555) && IS_ATOM_INT(_25556))
        _25557 = 0;
        else
        _25557 = (compare(_25555, _25556) == 0);
        DeRef(_25555);
        _25555 = NOVALUE;
        DeRef(_25556);
        _25556 = NOVALUE;
        if (_25557 == 0)
        {
            _25557 = NOVALUE;
            goto L7; // [126] 139
        }
        else{
            _25557 = NOVALUE;
        }

        /** cominit.e:218						bi = j*/
        _bi_49862 = _j_49870;

        /** cominit.e:219						exit*/
        goto L6; // [136] 146
L7: 

        /** cominit.e:221				end for*/
        _j_49870 = _j_49870 + 1;
        goto L5; // [141] 108
L6: 
        ;
    }
    goto L8; // [146] 292
L4: 

    /** cominit.e:223			elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (object)SEQ_PTR(_opt_49855);
    _25558 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25558)) {
        _25559 = (_25558 == 45);
    }
    else {
        _25559 = binary_op(EQUALS, _25558, 45);
    }
    _25558 = NOVALUE;
    if (IS_ATOM_INT(_25559)) {
        if (_25559 != 0) {
            goto L9; // [159] 176
        }
    }
    else {
        if (DBL_PTR(_25559)->dbl != 0.0) {
            goto L9; // [159] 176
        }
    }
    _2 = (object)SEQ_PTR(_opt_49855);
    _25561 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25561)) {
        _25562 = (_25561 == 47);
    }
    else {
        _25562 = binary_op(EQUALS, _25561, 47);
    }
    _25561 = NOVALUE;
    if (_25562 == 0) {
        DeRef(_25562);
        _25562 = NOVALUE;
        goto LA; // [172] 291
    }
    else {
        if (!IS_ATOM_INT(_25562) && DBL_PTR(_25562)->dbl == 0.0){
            DeRef(_25562);
            _25562 = NOVALUE;
            goto LA; // [172] 291
        }
        DeRef(_25562);
        _25562 = NOVALUE;
    }
    DeRef(_25562);
    _25562 = NOVALUE;
L9: 

    /** cominit.e:226				this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_49855)){
            _25563 = SEQ_PTR(_opt_49855)->length;
    }
    else {
        _25563 = 1;
    }
    rhs_slice_target = (object_ptr)&_25564;
    RHS_Slice(_opt_49855, 2, _25563);
    RefDS(_opts_49849);
    _0 = _this_opt_49861;
    _this_opt_49861 = _49find_opt(1, _25564, _opts_49849);
    DeRef(_0);
    _25564 = NOVALUE;

    /** cominit.e:228				for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_49848)){
            _25566 = SEQ_PTR(_b_49848)->length;
    }
    else {
        _25566 = 1;
    }
    {
        object _j_49887;
        _j_49887 = 1;
LB: 
        if (_j_49887 > _25566){
            goto LC; // [199] 290
        }

        /** cominit.e:229					if equal(text:lower(b[j]), '-' & text:lower(opt[2..$])) or */
        _2 = (object)SEQ_PTR(_b_49848);
        _25567 = (object)*(((s1_ptr)_2)->base + _j_49887);
        Ref(_25567);
        _25568 = _14lower(_25567);
        _25567 = NOVALUE;
        if (IS_SEQUENCE(_opt_49855)){
                _25569 = SEQ_PTR(_opt_49855)->length;
        }
        else {
            _25569 = 1;
        }
        rhs_slice_target = (object_ptr)&_25570;
        RHS_Slice(_opt_49855, 2, _25569);
        _25571 = _14lower(_25570);
        _25570 = NOVALUE;
        if (IS_SEQUENCE(45) && IS_ATOM(_25571)) {
        }
        else if (IS_ATOM(45) && IS_SEQUENCE(_25571)) {
            Prepend(&_25572, _25571, 45);
        }
        else {
            Concat((object_ptr)&_25572, 45, _25571);
        }
        DeRef(_25571);
        _25571 = NOVALUE;
        if (_25568 == _25572)
        _25573 = 1;
        else if (IS_ATOM_INT(_25568) && IS_ATOM_INT(_25572))
        _25573 = 0;
        else
        _25573 = (compare(_25568, _25572) == 0);
        DeRef(_25568);
        _25568 = NOVALUE;
        DeRefDS(_25572);
        _25572 = NOVALUE;
        if (_25573 != 0) {
            goto LD; // [236] 273
        }
        _2 = (object)SEQ_PTR(_b_49848);
        _25575 = (object)*(((s1_ptr)_2)->base + _j_49887);
        Ref(_25575);
        _25576 = _14lower(_25575);
        _25575 = NOVALUE;
        if (IS_SEQUENCE(_opt_49855)){
                _25577 = SEQ_PTR(_opt_49855)->length;
        }
        else {
            _25577 = 1;
        }
        rhs_slice_target = (object_ptr)&_25578;
        RHS_Slice(_opt_49855, 2, _25577);
        _25579 = _14lower(_25578);
        _25578 = NOVALUE;
        if (IS_SEQUENCE(47) && IS_ATOM(_25579)) {
        }
        else if (IS_ATOM(47) && IS_SEQUENCE(_25579)) {
            Prepend(&_25580, _25579, 47);
        }
        else {
            Concat((object_ptr)&_25580, 47, _25579);
        }
        DeRef(_25579);
        _25579 = NOVALUE;
        if (_25576 == _25580)
        _25581 = 1;
        else if (IS_ATOM_INT(_25576) && IS_ATOM_INT(_25580))
        _25581 = 0;
        else
        _25581 = (compare(_25576, _25580) == 0);
        DeRef(_25576);
        _25576 = NOVALUE;
        DeRefDS(_25580);
        _25580 = NOVALUE;
        if (_25581 == 0)
        {
            _25581 = NOVALUE;
            goto LE; // [269] 283
        }
        else{
            _25581 = NOVALUE;
        }
LD: 

        /** cominit.e:232						bi = j*/
        _bi_49862 = _j_49887;

        /** cominit.e:233						exit*/
        goto LC; // [280] 290
LE: 

        /** cominit.e:235				end for*/
        _j_49887 = _j_49887 + 1;
        goto LB; // [285] 206
LC: 
        ;
    }
LA: 
L8: 

    /** cominit.e:243			if length(this_opt) and not find(MULTIPLE, this_opt[OPTIONS]) then*/
    if (IS_SEQUENCE(_this_opt_49861)){
            _25582 = SEQ_PTR(_this_opt_49861)->length;
    }
    else {
        _25582 = 1;
    }
    if (_25582 == 0) {
        goto LF; // [297] 451
    }
    _2 = (object)SEQ_PTR(_this_opt_49861);
    _25584 = (object)*(((s1_ptr)_2)->base + 4);
    _25585 = find_from(42, _25584, 1);
    _25584 = NOVALUE;
    _25586 = (_25585 == 0);
    _25585 = NOVALUE;
    if (_25586 == 0)
    {
        DeRef(_25586);
        _25586 = NOVALUE;
        goto LF; // [316] 451
    }
    else{
        DeRef(_25586);
        _25586 = NOVALUE;
    }

    /** cominit.e:244				if bi then*/
    if (_bi_49862 == 0)
    {
        goto L10; // [321] 365
    }
    else{
    }

    /** cominit.e:245					if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_this_opt_49861);
    _25587 = (object)*(((s1_ptr)_2)->base + 4);
    _25588 = find_from(112, _25587, 1);
    _25587 = NOVALUE;
    if (_25588 == 0)
    {
        _25588 = NOVALUE;
        goto L11; // [337] 354
    }
    else{
        _25588 = NOVALUE;
    }

    /** cominit.e:247						a = remove(a, i, i + 1)*/
    _25589 = _i_49851 + 1;
    if (_25589 > MAXINT){
        _25589 = NewDouble((eudouble)_25589);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_a_49847);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_49851)) ? _i_49851 : (object)(DBL_PTR(_i_49851)->dbl);
        int stop = (IS_ATOM_INT(_25589)) ? _25589 : (object)(DBL_PTR(_25589)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_49847), start, &_a_49847 );
            }
            else Tail(SEQ_PTR(_a_49847), stop+1, &_a_49847);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_49847), start, &_a_49847);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_49847 = Remove_elements(start, stop, (SEQ_PTR(_a_49847)->ref == 1));
        }
    }
    DeRef(_25589);
    _25589 = NOVALUE;
    goto L12; // [351] 458
L11: 

    /** cominit.e:250						a = remove(a, i)*/
    {
        s1_ptr assign_space = SEQ_PTR(_a_49847);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_49851)) ? _i_49851 : (object)(DBL_PTR(_i_49851)->dbl);
        int stop = (IS_ATOM_INT(_i_49851)) ? _i_49851 : (object)(DBL_PTR(_i_49851)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_49847), start, &_a_49847 );
            }
            else Tail(SEQ_PTR(_a_49847), stop+1, &_a_49847);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_49847), start, &_a_49847);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_49847 = Remove_elements(start, stop, (SEQ_PTR(_a_49847)->ref == 1));
        }
    }
    goto L12; // [362] 458
L10: 

    /** cominit.e:265					integer beginLen = length(a)*/
    if (IS_SEQUENCE(_a_49847)){
            _beginLen_49922 = SEQ_PTR(_a_49847)->length;
    }
    else {
        _beginLen_49922 = 1;
    }

    /** cominit.e:267					if dedupe = 0 and i < beginLen then*/
    _25593 = (_dedupe_49850 == 0);
    if (_25593 == 0) {
        goto L13; // [376] 438
    }
    _25595 = (_i_49851 < _beginLen_49922);
    if (_25595 == 0)
    {
        DeRef(_25595);
        _25595 = NOVALUE;
        goto L13; // [385] 438
    }
    else{
        DeRef(_25595);
        _25595 = NOVALUE;
    }

    /** cominit.e:268						a = merge_parameters( a[i + 1..$], a[1..i], opts, 1)*/
    _25596 = _i_49851 + 1;
    if (_25596 > MAXINT){
        _25596 = NewDouble((eudouble)_25596);
    }
    if (IS_SEQUENCE(_a_49847)){
            _25597 = SEQ_PTR(_a_49847)->length;
    }
    else {
        _25597 = 1;
    }
    rhs_slice_target = (object_ptr)&_25598;
    RHS_Slice(_a_49847, _25596, _25597);
    rhs_slice_target = (object_ptr)&_25599;
    RHS_Slice(_a_49847, 1, _i_49851);
    RefDS(_opts_49849);
    DeRef(_25600);
    _25600 = _opts_49849;
    _0 = _a_49847;
    _a_49847 = _49merge_parameters(_25598, _25599, _25600, 1);
    DeRefDS(_0);
    _25598 = NOVALUE;
    _25599 = NOVALUE;
    _25600 = NOVALUE;

    /** cominit.e:270						if beginLen = length(a) then*/
    if (IS_SEQUENCE(_a_49847)){
            _25602 = SEQ_PTR(_a_49847)->length;
    }
    else {
        _25602 = 1;
    }
    if (_beginLen_49922 != _25602)
    goto L14; // [424] 445

    /** cominit.e:272							i += 1*/
    _i_49851 = _i_49851 + 1;
    goto L14; // [435] 445
L13: 

    /** cominit.e:276						i += 1*/
    _i_49851 = _i_49851 + 1;
L14: 
    goto L12; // [448] 458
LF: 

    /** cominit.e:282				i += 1*/
    _i_49851 = _i_49851 + 1;
L12: 
    DeRef(_opt_49855);
    _opt_49855 = NOVALUE;
    DeRef(_this_opt_49861);
    _this_opt_49861 = NOVALUE;

    /** cominit.e:284		end while*/
    goto L1; // [462] 19
L2: 

    /** cominit.e:286		if dedupe then*/
    if (_dedupe_49850 == 0)
    {
        goto L15; // [467] 481
    }
    else{
    }

    /** cominit.e:287			return b & a*/
    Concat((object_ptr)&_25607, _b_49848, _a_49847);
    DeRefDS(_a_49847);
    DeRefDS(_b_49848);
    DeRefDS(_opts_49849);
    DeRef(_25559);
    _25559 = NOVALUE;
    DeRef(_25593);
    _25593 = NOVALUE;
    DeRef(_25596);
    _25596 = NOVALUE;
    return _25607;
L15: 

    /** cominit.e:290		integer first_extra = 0*/
    _first_extra_49944 = 0;

    /** cominit.e:292		i = 1*/
    _i_49851 = 1;

    /** cominit.e:295		while i <= length(b) do*/
L16: 
    if (IS_SEQUENCE(_b_49848)){
            _25608 = SEQ_PTR(_b_49848)->length;
    }
    else {
        _25608 = 1;
    }
    if (_i_49851 > _25608)
    goto L17; // [499] 692

    /** cominit.e:296			sequence opt = b[i]*/
    DeRef(_opt_49948);
    _2 = (object)SEQ_PTR(_b_49848);
    _opt_49948 = (object)*(((s1_ptr)_2)->base + _i_49851);
    Ref(_opt_49948);

    /** cominit.e:299			if length(opt) <= 1 then*/
    if (IS_SEQUENCE(_opt_49948)){
            _25611 = SEQ_PTR(_opt_49948)->length;
    }
    else {
        _25611 = 1;
    }
    if (_25611 > 1)
    goto L18; // [516] 532

    /** cominit.e:300				first_extra = i*/
    _first_extra_49944 = _i_49851;

    /** cominit.e:301				exit*/
    DeRefDS(_opt_49948);
    _opt_49948 = NOVALUE;
    DeRef(_this_opt_49953);
    _this_opt_49953 = NOVALUE;
    goto L17; // [529] 692
L18: 

    /** cominit.e:304			sequence this_opt = {}*/
    RefDS(_21997);
    DeRef(_this_opt_49953);
    _this_opt_49953 = _21997;

    /** cominit.e:305			if opt[2] = '-' and opt[1] = '-' then*/
    _2 = (object)SEQ_PTR(_opt_49948);
    _25613 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_25613)) {
        _25614 = (_25613 == 45);
    }
    else {
        _25614 = binary_op(EQUALS, _25613, 45);
    }
    _25613 = NOVALUE;
    if (IS_ATOM_INT(_25614)) {
        if (_25614 == 0) {
            goto L19; // [549] 586
        }
    }
    else {
        if (DBL_PTR(_25614)->dbl == 0.0) {
            goto L19; // [549] 586
        }
    }
    _2 = (object)SEQ_PTR(_opt_49948);
    _25616 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25616)) {
        _25617 = (_25616 == 45);
    }
    else {
        _25617 = binary_op(EQUALS, _25616, 45);
    }
    _25616 = NOVALUE;
    if (_25617 == 0) {
        DeRef(_25617);
        _25617 = NOVALUE;
        goto L19; // [562] 586
    }
    else {
        if (!IS_ATOM_INT(_25617) && DBL_PTR(_25617)->dbl == 0.0){
            DeRef(_25617);
            _25617 = NOVALUE;
            goto L19; // [562] 586
        }
        DeRef(_25617);
        _25617 = NOVALUE;
    }
    DeRef(_25617);
    _25617 = NOVALUE;

    /** cominit.e:306				this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_49948)){
            _25618 = SEQ_PTR(_opt_49948)->length;
    }
    else {
        _25618 = 1;
    }
    rhs_slice_target = (object_ptr)&_25619;
    RHS_Slice(_opt_49948, 3, _25618);
    RefDS(_opts_49849);
    _0 = _this_opt_49953;
    _this_opt_49953 = _49find_opt(2, _25619, _opts_49849);
    DeRef(_0);
    _25619 = NOVALUE;
    goto L1A; // [583] 633
L19: 

    /** cominit.e:307			elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (object)SEQ_PTR(_opt_49948);
    _25621 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25621)) {
        _25622 = (_25621 == 45);
    }
    else {
        _25622 = binary_op(EQUALS, _25621, 45);
    }
    _25621 = NOVALUE;
    if (IS_ATOM_INT(_25622)) {
        if (_25622 != 0) {
            goto L1B; // [596] 613
        }
    }
    else {
        if (DBL_PTR(_25622)->dbl != 0.0) {
            goto L1B; // [596] 613
        }
    }
    _2 = (object)SEQ_PTR(_opt_49948);
    _25624 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25624)) {
        _25625 = (_25624 == 47);
    }
    else {
        _25625 = binary_op(EQUALS, _25624, 47);
    }
    _25624 = NOVALUE;
    if (_25625 == 0) {
        DeRef(_25625);
        _25625 = NOVALUE;
        goto L1C; // [609] 632
    }
    else {
        if (!IS_ATOM_INT(_25625) && DBL_PTR(_25625)->dbl == 0.0){
            DeRef(_25625);
            _25625 = NOVALUE;
            goto L1C; // [609] 632
        }
        DeRef(_25625);
        _25625 = NOVALUE;
    }
    DeRef(_25625);
    _25625 = NOVALUE;
L1B: 

    /** cominit.e:308				this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_49948)){
            _25626 = SEQ_PTR(_opt_49948)->length;
    }
    else {
        _25626 = 1;
    }
    rhs_slice_target = (object_ptr)&_25627;
    RHS_Slice(_opt_49948, 2, _25626);
    RefDS(_opts_49849);
    _0 = _this_opt_49953;
    _this_opt_49953 = _49find_opt(1, _25627, _opts_49849);
    DeRef(_0);
    _25627 = NOVALUE;
L1C: 
L1A: 

    /** cominit.e:311			if length(this_opt) then*/
    if (IS_SEQUENCE(_this_opt_49953)){
            _25629 = SEQ_PTR(_this_opt_49953)->length;
    }
    else {
        _25629 = 1;
    }
    if (_25629 == 0)
    {
        _25629 = NOVALUE;
        goto L1D; // [638] 667
    }
    else{
        _25629 = NOVALUE;
    }

    /** cominit.e:312				if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_this_opt_49953);
    _25630 = (object)*(((s1_ptr)_2)->base + 4);
    _25631 = find_from(112, _25630, 1);
    _25630 = NOVALUE;
    if (_25631 == 0)
    {
        _25631 = NOVALUE;
        goto L1E; // [654] 679
    }
    else{
        _25631 = NOVALUE;
    }

    /** cominit.e:313					i += 1*/
    _i_49851 = _i_49851 + 1;
    goto L1E; // [664] 679
L1D: 

    /** cominit.e:316				first_extra = i*/
    _first_extra_49944 = _i_49851;

    /** cominit.e:317				exit*/
    DeRef(_opt_49948);
    _opt_49948 = NOVALUE;
    DeRef(_this_opt_49953);
    _this_opt_49953 = NOVALUE;
    goto L17; // [676] 692
L1E: 

    /** cominit.e:320			i += 1*/
    _i_49851 = _i_49851 + 1;
    DeRef(_opt_49948);
    _opt_49948 = NOVALUE;
    DeRef(_this_opt_49953);
    _this_opt_49953 = NOVALUE;

    /** cominit.e:321		end while*/
    goto L16; // [689] 496
L17: 

    /** cominit.e:323		if first_extra then*/
    if (_first_extra_49944 == 0)
    {
        goto L1F; // [694] 709
    }
    else{
    }

    /** cominit.e:324			return splice(b, a, first_extra)*/
    {
        s1_ptr assign_space;
        insert_pos = _first_extra_49944;
        if (insert_pos <= 0) {
            Concat(&_25634,_a_49847,_b_49848);
        }
        else if (insert_pos > SEQ_PTR(_b_49848)->length){
            Concat(&_25634,_b_49848,_a_49847);
        }
        else if (IS_SEQUENCE(_a_49847)) {
            if( _25634 != _b_49848 || SEQ_PTR( _b_49848 )->ref != 1 ){
                DeRef( _25634 );
                RefDS( _b_49848 );
            }
            assign_space = Add_internal_space( _b_49848, insert_pos,((s1_ptr)SEQ_PTR(_a_49847))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_a_49847), _b_49848 == _25634 );
            _25634 = MAKE_SEQ( assign_space );
        }
        else {
            if( _25634 == _b_49848 && SEQ_PTR( _b_49848 )->ref == 1 ){
                _25634 = Insert( _b_49848, _a_49847, insert_pos);
            }
            else {
                DeRef( _25634 );
                RefDS( _b_49848 );
                _25634 = Insert( _b_49848, _a_49847, insert_pos);
            }
        }
    }
    DeRefDS(_a_49847);
    DeRefDS(_b_49848);
    DeRefDS(_opts_49849);
    DeRef(_25622);
    _25622 = NOVALUE;
    DeRef(_25559);
    _25559 = NOVALUE;
    DeRef(_25593);
    _25593 = NOVALUE;
    DeRef(_25614);
    _25614 = NOVALUE;
    DeRef(_25596);
    _25596 = NOVALUE;
    DeRef(_25607);
    _25607 = NOVALUE;
    return _25634;
L1F: 

    /** cominit.e:328		return b & a*/
    Concat((object_ptr)&_25635, _b_49848, _a_49847);
    DeRefDS(_a_49847);
    DeRefDS(_b_49848);
    DeRefDS(_opts_49849);
    DeRef(_25622);
    _25622 = NOVALUE;
    DeRef(_25559);
    _25559 = NOVALUE;
    DeRef(_25593);
    _25593 = NOVALUE;
    DeRef(_25634);
    _25634 = NOVALUE;
    DeRef(_25614);
    _25614 = NOVALUE;
    DeRef(_25596);
    _25596 = NOVALUE;
    DeRef(_25607);
    _25607 = NOVALUE;
    return _25635;
    ;
}


object _49validate_opt(object _opt_type_49986, object _arg_49987, object _args_49988, object _ix_49989)
{
    object _opt_49990 = NOVALUE;
    object _this_opt_49998 = NOVALUE;
    object _25654 = NOVALUE;
    object _25653 = NOVALUE;
    object _25652 = NOVALUE;
    object _25651 = NOVALUE;
    object _25650 = NOVALUE;
    object _25648 = NOVALUE;
    object _25647 = NOVALUE;
    object _25646 = NOVALUE;
    object _25645 = NOVALUE;
    object _25644 = NOVALUE;
    object _25642 = NOVALUE;
    object _25639 = NOVALUE;
    object _25637 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:336		if opt_type = SHORTNAME then*/
    if (_opt_type_49986 != 1)
    goto L1; // [11] 28

    /** cominit.e:337			opt = arg[2..$]*/
    if (IS_SEQUENCE(_arg_49987)){
            _25637 = SEQ_PTR(_arg_49987)->length;
    }
    else {
        _25637 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_49990;
    RHS_Slice(_arg_49987, 2, _25637);
    goto L2; // [25] 39
L1: 

    /** cominit.e:339			opt = arg[3..$]*/
    if (IS_SEQUENCE(_arg_49987)){
            _25639 = SEQ_PTR(_arg_49987)->length;
    }
    else {
        _25639 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_49990;
    RHS_Slice(_arg_49987, 3, _25639);
L2: 

    /** cominit.e:342		sequence this_opt = find_opt( opt_type, opt, options )*/
    RefDS(_opt_49990);
    RefDS(_49options_49723);
    _0 = _this_opt_49998;
    _this_opt_49998 = _49find_opt(_opt_type_49986, _opt_49990, _49options_49723);
    DeRef(_0);

    /** cominit.e:343		if not length( this_opt ) then*/
    if (IS_SEQUENCE(_this_opt_49998)){
            _25642 = SEQ_PTR(_this_opt_49998)->length;
    }
    else {
        _25642 = 1;
    }
    if (_25642 != 0)
    goto L3; // [58] 72
    _25642 = NOVALUE;

    /** cominit.e:345			return { 0, 0 }*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = 0;
    _25644 = MAKE_SEQ(_1);
    DeRefDS(_arg_49987);
    DeRefDS(_args_49988);
    DeRefDS(_opt_49990);
    DeRefDS(_this_opt_49998);
    return _25644;
L3: 

    /** cominit.e:348		if find( HAS_PARAMETER, this_opt[OPTIONS] ) then*/
    _2 = (object)SEQ_PTR(_this_opt_49998);
    _25645 = (object)*(((s1_ptr)_2)->base + 4);
    _25646 = find_from(112, _25645, 1);
    _25645 = NOVALUE;
    if (_25646 == 0)
    {
        _25646 = NOVALUE;
        goto L4; // [85] 135
    }
    else{
        _25646 = NOVALUE;
    }

    /** cominit.e:349			if ix = length( args ) - 1 then*/
    if (IS_SEQUENCE(_args_49988)){
            _25647 = SEQ_PTR(_args_49988)->length;
    }
    else {
        _25647 = 1;
    }
    _25648 = _25647 - 1;
    _25647 = NOVALUE;
    if (_ix_49989 != _25648)
    goto L5; // [97] 117

    /** cominit.e:351				CompileErr( MISSING_CMD_PARAMETER, { arg } )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_arg_49987);
    ((intptr_t*)_2)[1] = _arg_49987;
    _25650 = MAKE_SEQ(_1);
    _50CompileErr(353, _25650, 0);
    _25650 = NOVALUE;
    goto L6; // [114] 150
L5: 

    /** cominit.e:353				return { ix, ix + 2 }*/
    _25651 = _ix_49989 + 2;
    if ((object)((uintptr_t)_25651 + (uintptr_t)HIGH_BITS) >= 0){
        _25651 = NewDouble((eudouble)_25651);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _ix_49989;
    ((intptr_t *)_2)[2] = _25651;
    _25652 = MAKE_SEQ(_1);
    _25651 = NOVALUE;
    DeRefDS(_arg_49987);
    DeRefDS(_args_49988);
    DeRef(_opt_49990);
    DeRef(_this_opt_49998);
    DeRef(_25648);
    _25648 = NOVALUE;
    DeRef(_25644);
    _25644 = NOVALUE;
    return _25652;
    goto L6; // [132] 150
L4: 

    /** cominit.e:356			return { ix, ix + 1 }*/
    _25653 = _ix_49989 + 1;
    if (_25653 > MAXINT){
        _25653 = NewDouble((eudouble)_25653);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _ix_49989;
    ((intptr_t *)_2)[2] = _25653;
    _25654 = MAKE_SEQ(_1);
    _25653 = NOVALUE;
    DeRefDS(_arg_49987);
    DeRefDS(_args_49988);
    DeRef(_opt_49990);
    DeRef(_this_opt_49998);
    DeRef(_25648);
    _25648 = NOVALUE;
    DeRef(_25652);
    _25652 = NOVALUE;
    DeRef(_25644);
    _25644 = NOVALUE;
    return _25654;
L6: 
    ;
}


object _49find_next_opt(object _ix_50023, object _args_50024)
{
    object _arg_50028 = NOVALUE;
    object _25676 = NOVALUE;
    object _25675 = NOVALUE;
    object _25673 = NOVALUE;
    object _25672 = NOVALUE;
    object _25671 = NOVALUE;
    object _25670 = NOVALUE;
    object _25669 = NOVALUE;
    object _25668 = NOVALUE;
    object _25667 = NOVALUE;
    object _25666 = NOVALUE;
    object _25664 = NOVALUE;
    object _25662 = NOVALUE;
    object _25660 = NOVALUE;
    object _25658 = NOVALUE;
    object _25655 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:374		while ix < length( args ) do*/
L1: 
    if (IS_SEQUENCE(_args_50024)){
            _25655 = SEQ_PTR(_args_50024)->length;
    }
    else {
        _25655 = 1;
    }
    if (_ix_50023 >= _25655)
    goto L2; // [13] 157

    /** cominit.e:375			sequence arg = args[ix]*/
    DeRef(_arg_50028);
    _2 = (object)SEQ_PTR(_args_50024);
    _arg_50028 = (object)*(((s1_ptr)_2)->base + _ix_50023);
    Ref(_arg_50028);

    /** cominit.e:376			if length( arg ) > 1 then*/
    if (IS_SEQUENCE(_arg_50028)){
            _25658 = SEQ_PTR(_arg_50028)->length;
    }
    else {
        _25658 = 1;
    }
    if (_25658 <= 1)
    goto L3; // [30] 129

    /** cominit.e:377				if arg[1] = '-' then*/
    _2 = (object)SEQ_PTR(_arg_50028);
    _25660 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _25660, 45)){
        _25660 = NOVALUE;
        goto L4; // [40] 111
    }
    _25660 = NOVALUE;

    /** cominit.e:378					if arg[2] = '-' then*/
    _2 = (object)SEQ_PTR(_arg_50028);
    _25662 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _25662, 45)){
        _25662 = NOVALUE;
        goto L5; // [50] 94
    }
    _25662 = NOVALUE;

    /** cominit.e:380						if length( arg ) = 2 then*/
    if (IS_SEQUENCE(_arg_50028)){
            _25664 = SEQ_PTR(_arg_50028)->length;
    }
    else {
        _25664 = 1;
    }
    if (_25664 != 2)
    goto L6; // [59] 78

    /** cominit.e:382							return { 0, ix - 1 }*/
    _25666 = _ix_50023 - 1;
    if ((object)((uintptr_t)_25666 +(uintptr_t) HIGH_BITS) >= 0){
        _25666 = NewDouble((eudouble)_25666);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _25666;
    _25667 = MAKE_SEQ(_1);
    _25666 = NOVALUE;
    DeRefDS(_arg_50028);
    DeRefDS(_args_50024);
    return _25667;
L6: 

    /** cominit.e:385						return validate_opt( LONGNAME, arg, args, ix )*/
    RefDS(_arg_50028);
    RefDS(_args_50024);
    _25668 = _49validate_opt(2, _arg_50028, _args_50024, _ix_50023);
    DeRefDS(_arg_50028);
    DeRefDS(_args_50024);
    DeRef(_25667);
    _25667 = NOVALUE;
    return _25668;
    goto L7; // [91] 144
L5: 

    /** cominit.e:389						return validate_opt( SHORTNAME, arg, args, ix )*/
    RefDS(_arg_50028);
    RefDS(_args_50024);
    _25669 = _49validate_opt(1, _arg_50028, _args_50024, _ix_50023);
    DeRefDS(_arg_50028);
    DeRefDS(_args_50024);
    DeRef(_25667);
    _25667 = NOVALUE;
    DeRef(_25668);
    _25668 = NOVALUE;
    return _25669;
    goto L7; // [108] 144
L4: 

    /** cominit.e:393					return {0, ix-1}*/
    _25670 = _ix_50023 - 1;
    if ((object)((uintptr_t)_25670 +(uintptr_t) HIGH_BITS) >= 0){
        _25670 = NewDouble((eudouble)_25670);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _25670;
    _25671 = MAKE_SEQ(_1);
    _25670 = NOVALUE;
    DeRef(_arg_50028);
    DeRefDS(_args_50024);
    DeRef(_25667);
    _25667 = NOVALUE;
    DeRef(_25669);
    _25669 = NOVALUE;
    DeRef(_25668);
    _25668 = NOVALUE;
    return _25671;
    goto L7; // [126] 144
L3: 

    /** cominit.e:397				return { 0, ix-1 }*/
    _25672 = _ix_50023 - 1;
    if ((object)((uintptr_t)_25672 +(uintptr_t) HIGH_BITS) >= 0){
        _25672 = NewDouble((eudouble)_25672);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _25672;
    _25673 = MAKE_SEQ(_1);
    _25672 = NOVALUE;
    DeRef(_arg_50028);
    DeRefDS(_args_50024);
    DeRef(_25671);
    _25671 = NOVALUE;
    DeRef(_25667);
    _25667 = NOVALUE;
    DeRef(_25669);
    _25669 = NOVALUE;
    DeRef(_25668);
    _25668 = NOVALUE;
    return _25673;
L7: 

    /** cominit.e:400			ix += 1*/
    _ix_50023 = _ix_50023 + 1;
    DeRef(_arg_50028);
    _arg_50028 = NOVALUE;

    /** cominit.e:401		end while*/
    goto L1; // [154] 10
L2: 

    /** cominit.e:402		return {0, ix-1}*/
    _25675 = _ix_50023 - 1;
    if ((object)((uintptr_t)_25675 +(uintptr_t) HIGH_BITS) >= 0){
        _25675 = NewDouble((eudouble)_25675);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _25675;
    _25676 = MAKE_SEQ(_1);
    _25675 = NOVALUE;
    DeRefDS(_args_50024);
    DeRef(_25671);
    _25671 = NOVALUE;
    DeRef(_25667);
    _25667 = NOVALUE;
    DeRef(_25673);
    _25673 = NOVALUE;
    DeRef(_25669);
    _25669 = NOVALUE;
    DeRef(_25668);
    _25668 = NOVALUE;
    return _25676;
    ;
}


object _49expand_config_options(object _args_50058)
{
    object _idx_50059 = NOVALUE;
    object _next_idx_50060 = NOVALUE;
    object _files_50061 = NOVALUE;
    object _cmd_1_2_50062 = NOVALUE;
    object _25699 = NOVALUE;
    object _25698 = NOVALUE;
    object _25697 = NOVALUE;
    object _25696 = NOVALUE;
    object _25695 = NOVALUE;
    object _25694 = NOVALUE;
    object _25693 = NOVALUE;
    object _25692 = NOVALUE;
    object _25691 = NOVALUE;
    object _25686 = NOVALUE;
    object _25684 = NOVALUE;
    object _25683 = NOVALUE;
    object _25682 = NOVALUE;
    object _25680 = NOVALUE;
    object _25679 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:410		integer idx = 1*/
    _idx_50059 = 1;

    /** cominit.e:412		sequence files = {}*/
    RefDS(_21997);
    DeRef(_files_50061);
    _files_50061 = _21997;

    /** cominit.e:413		sequence cmd_1_2 = args[1..2]*/
    rhs_slice_target = (object_ptr)&_cmd_1_2_50062;
    RHS_Slice(_args_50058, 1, 2);

    /** cominit.e:414		args = remove( args, 1, 2 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_args_50058);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1)) ? 1 : (object)(DBL_PTR(1)->dbl);
        int stop = (IS_ATOM_INT(2)) ? 2 : (object)(DBL_PTR(2)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_50058), start, &_args_50058 );
            }
            else Tail(SEQ_PTR(_args_50058), stop+1, &_args_50058);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_50058), start, &_args_50058);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_50058 = Remove_elements(start, stop, (SEQ_PTR(_args_50058)->ref == 1));
        }
    }

    /** cominit.e:416		while idx with entry do*/
    goto L1; // [31] 94
L2: 
    if (_idx_50059 == 0)
    {
        goto L3; // [34] 114
    }
    else{
    }

    /** cominit.e:417			if equal(upper(args[idx]), "-C") then*/
    _2 = (object)SEQ_PTR(_args_50058);
    _25679 = (object)*(((s1_ptr)_2)->base + _idx_50059);
    Ref(_25679);
    _25680 = _14upper(_25679);
    _25679 = NOVALUE;
    if (_25680 == _25681)
    _25682 = 1;
    else if (IS_ATOM_INT(_25680) && IS_ATOM_INT(_25681))
    _25682 = 0;
    else
    _25682 = (compare(_25680, _25681) == 0);
    DeRef(_25680);
    _25680 = NOVALUE;
    if (_25682 == 0)
    {
        _25682 = NOVALUE;
        goto L4; // [51] 82
    }
    else{
        _25682 = NOVALUE;
    }

    /** cominit.e:418				files = append( files, args[idx+1] )*/
    _25683 = _idx_50059 + 1;
    _2 = (object)SEQ_PTR(_args_50058);
    _25684 = (object)*(((s1_ptr)_2)->base + _25683);
    Ref(_25684);
    Append(&_files_50061, _files_50061, _25684);
    _25684 = NOVALUE;

    /** cominit.e:419				args = remove( args, idx, idx + 1 )*/
    _25686 = _idx_50059 + 1;
    if (_25686 > MAXINT){
        _25686 = NewDouble((eudouble)_25686);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_args_50058);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_idx_50059)) ? _idx_50059 : (object)(DBL_PTR(_idx_50059)->dbl);
        int stop = (IS_ATOM_INT(_25686)) ? _25686 : (object)(DBL_PTR(_25686)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_50058), start, &_args_50058 );
            }
            else Tail(SEQ_PTR(_args_50058), stop+1, &_args_50058);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_50058), start, &_args_50058);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_50058 = Remove_elements(start, stop, (SEQ_PTR(_args_50058)->ref == 1));
        }
    }
    DeRef(_25686);
    _25686 = NOVALUE;
    goto L5; // [79] 91
L4: 

    /** cominit.e:422				idx = next_idx[2]*/
    _2 = (object)SEQ_PTR(_next_idx_50060);
    _idx_50059 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_idx_50059))
    _idx_50059 = (object)DBL_PTR(_idx_50059)->dbl;
L5: 

    /** cominit.e:424		entry*/
L1: 

    /** cominit.e:425			next_idx = find_next_opt( idx, args )*/
    RefDS(_args_50058);
    _0 = _next_idx_50060;
    _next_idx_50060 = _49find_next_opt(_idx_50059, _args_50058);
    DeRef(_0);

    /** cominit.e:426			idx = next_idx[1]*/
    _2 = (object)SEQ_PTR(_next_idx_50060);
    _idx_50059 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_idx_50059))
    _idx_50059 = (object)DBL_PTR(_idx_50059)->dbl;

    /** cominit.e:427		end while*/
    goto L2; // [111] 34
L3: 

    /** cominit.e:428		return cmd_1_2 & merge_parameters( GetDefaultArgs( files ), args[1..next_idx[2]], options, 1 ) & args[next_idx[2]+1..$]*/
    RefDS(_files_50061);
    _25691 = _48GetDefaultArgs(_files_50061);
    _2 = (object)SEQ_PTR(_next_idx_50060);
    _25692 = (object)*(((s1_ptr)_2)->base + 2);
    rhs_slice_target = (object_ptr)&_25693;
    RHS_Slice(_args_50058, 1, _25692);
    RefDS(_49options_49723);
    _25694 = _49merge_parameters(_25691, _25693, _49options_49723, 1);
    _25691 = NOVALUE;
    _25693 = NOVALUE;
    _2 = (object)SEQ_PTR(_next_idx_50060);
    _25695 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_25695)) {
        _25696 = _25695 + 1;
        if (_25696 > MAXINT){
            _25696 = NewDouble((eudouble)_25696);
        }
    }
    else
    _25696 = binary_op(PLUS, 1, _25695);
    _25695 = NOVALUE;
    if (IS_SEQUENCE(_args_50058)){
            _25697 = SEQ_PTR(_args_50058)->length;
    }
    else {
        _25697 = 1;
    }
    rhs_slice_target = (object_ptr)&_25698;
    RHS_Slice(_args_50058, _25696, _25697);
    {
        object concat_list[3];

        concat_list[0] = _25698;
        concat_list[1] = _25694;
        concat_list[2] = _cmd_1_2_50062;
        Concat_N((object_ptr)&_25699, concat_list, 3);
    }
    DeRefDS(_25698);
    _25698 = NOVALUE;
    DeRef(_25694);
    _25694 = NOVALUE;
    DeRefDS(_args_50058);
    DeRefDS(_next_idx_50060);
    DeRefDS(_files_50061);
    DeRefDS(_cmd_1_2_50062);
    DeRef(_25696);
    _25696 = NOVALUE;
    _25692 = NOVALUE;
    DeRef(_25683);
    _25683 = NOVALUE;
    return _25699;
    ;
}


void _49handle_common_options(object _opts_50093)
{
    object _opt_keys_50094 = NOVALUE;
    object _option_w_50096 = NOVALUE;
    object _key_50100 = NOVALUE;
    object _val_50102 = NOVALUE;
    object _this_warn_50148 = NOVALUE;
    object _auto_add_warn_50150 = NOVALUE;
    object _n_50156 = NOVALUE;
    object _this_warn_50179 = NOVALUE;
    object _auto_add_warn_50181 = NOVALUE;
    object _n_50187 = NOVALUE;
    object _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50224 = NOVALUE;
    object _prompt_inlined_maybe_any_key_at_617_50223 = NOVALUE;
    object _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50237 = NOVALUE;
    object _prompt_inlined_maybe_any_key_at_693_50236 = NOVALUE;
    object _25758 = NOVALUE;
    object _25757 = NOVALUE;
    object _25755 = NOVALUE;
    object _25753 = NOVALUE;
    object _25751 = NOVALUE;
    object _25750 = NOVALUE;
    object _25749 = NOVALUE;
    object _25748 = NOVALUE;
    object _25747 = NOVALUE;
    object _25746 = NOVALUE;
    object _25745 = NOVALUE;
    object _25744 = NOVALUE;
    object _25742 = NOVALUE;
    object _25740 = NOVALUE;
    object _25739 = NOVALUE;
    object _25738 = NOVALUE;
    object _25733 = NOVALUE;
    object _25731 = NOVALUE;
    object _25729 = NOVALUE;
    object _25726 = NOVALUE;
    object _25725 = NOVALUE;
    object _25720 = NOVALUE;
    object _25718 = NOVALUE;
    object _25716 = NOVALUE;
    object _25714 = NOVALUE;
    object _25713 = NOVALUE;
    object _25712 = NOVALUE;
    object _25711 = NOVALUE;
    object _25710 = NOVALUE;
    object _25709 = NOVALUE;
    object _25707 = NOVALUE;
    object _25706 = NOVALUE;
    object _25701 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:435		sequence opt_keys = m:keys(opts)*/
    Ref(_opts_50093);
    _0 = _opt_keys_50094;
    _opt_keys_50094 = _29keys(_opts_50093, 0);
    DeRef(_0);

    /** cominit.e:436		integer option_w = 0*/
    _option_w_50096 = 0;

    /** cominit.e:438		for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_50094)){
            _25701 = SEQ_PTR(_opt_keys_50094)->length;
    }
    else {
        _25701 = 1;
    }
    {
        object _idx_50098;
        _idx_50098 = 1;
L1: 
        if (_idx_50098 > _25701){
            goto L2; // [20] 795
        }

        /** cominit.e:439			sequence key = opt_keys[idx]*/
        DeRef(_key_50100);
        _2 = (object)SEQ_PTR(_opt_keys_50094);
        _key_50100 = (object)*(((s1_ptr)_2)->base + _idx_50098);
        Ref(_key_50100);

        /** cominit.e:440			object val = m:get(opts, key)*/
        Ref(_opts_50093);
        RefDS(_key_50100);
        _0 = _val_50102;
        _val_50102 = _29get(_opts_50093, _key_50100, 0);
        DeRef(_0);

        /** cominit.e:442			switch key do*/
        _1 = find(_key_50100, _25704);
        switch ( _1 ){ 

            /** cominit.e:443				case "i" then*/
            case 1:

            /** cominit.e:444					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50102)){
                    _25706 = SEQ_PTR(_val_50102)->length;
            }
            else {
                _25706 = 1;
            }
            {
                object _i_50108;
                _i_50108 = 1;
L3: 
                if (_i_50108 > _25706){
                    goto L4; // [59] 82
                }

                /** cominit.e:445						add_include_directory(val[i])*/
                _2 = (object)SEQ_PTR(_val_50102);
                _25707 = (object)*(((s1_ptr)_2)->base + _i_50108);
                Ref(_25707);
                _48add_include_directory(_25707);
                _25707 = NOVALUE;

                /** cominit.e:446					end for*/
                _i_50108 = _i_50108 + 1;
                goto L3; // [77] 66
L4: 
                ;
            }
            goto L5; // [82] 786

            /** cominit.e:448				case "d" then*/
            case 2:

            /** cominit.e:449					OpDefines &= val*/
            if (IS_SEQUENCE(_36OpDefines_21524) && IS_ATOM(_val_50102)) {
                Ref(_val_50102);
                Append(&_36OpDefines_21524, _36OpDefines_21524, _val_50102);
            }
            else if (IS_ATOM(_36OpDefines_21524) && IS_SEQUENCE(_val_50102)) {
            }
            else {
                Concat((object_ptr)&_36OpDefines_21524, _36OpDefines_21524, _val_50102);
            }
            goto L5; // [98] 786

            /** cominit.e:451				case "batch" then*/
            case 3:

            /** cominit.e:452					batch_job = 1*/
            _36batch_job_21460 = 1;
            goto L5; // [111] 786

            /** cominit.e:454				case "test" then*/
            case 4:

            /** cominit.e:455					test_only = 1*/
            _36test_only_21459 = 1;
            goto L5; // [124] 786

            /** cominit.e:457				case "strict" then*/
            case 5:

            /** cominit.e:458					Strict_is_on = 1*/
            _36Strict_is_on_21516 = 1;
            goto L5; // [137] 786

            /** cominit.e:460				case "p" then*/
            case 6:

            /** cominit.e:461					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50102)){
                    _25709 = SEQ_PTR(_val_50102)->length;
            }
            else {
                _25709 = 1;
            }
            {
                object _i_50123;
                _i_50123 = 1;
L6: 
                if (_i_50123 > _25709){
                    goto L7; // [148] 173
                }

                /** cominit.e:462						add_preprocessor(val[i])*/
                _2 = (object)SEQ_PTR(_val_50102);
                _25710 = (object)*(((s1_ptr)_2)->base + _i_50123);
                Ref(_25710);
                _64add_preprocessor(_25710, 0, 0);
                _25710 = NOVALUE;

                /** cominit.e:463					end for*/
                _i_50123 = _i_50123 + 1;
                goto L6; // [168] 155
L7: 
                ;
            }
            goto L5; // [173] 786

            /** cominit.e:465				case "pf" then*/
            case 7:

            /** cominit.e:466					force_preprocessor = 1*/
            _37force_preprocessor_15424 = 1;
            goto L5; // [186] 786

            /** cominit.e:468				case "l" then*/
            case 8:

            /** cominit.e:469					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50102)){
                    _25711 = SEQ_PTR(_val_50102)->length;
            }
            else {
                _25711 = 1;
            }
            {
                object _i_50131;
                _i_50131 = 1;
L8: 
                if (_i_50131 > _25711){
                    goto L9; // [197] 238
                }

                /** cominit.e:470						LocalizeQual = append(LocalizeQual, (filter(lower(val[i]), STDFLTR_ALPHA)))*/
                _2 = (object)SEQ_PTR(_val_50102);
                _25712 = (object)*(((s1_ptr)_2)->base + _i_50131);
                Ref(_25712);
                _25713 = _14lower(_25712);
                _25712 = NOVALUE;
                RefDS(_21997);
                RefDS(_5);
                _25714 = _23filter(_25713, _23STDFLTR_ALPHA_5092, _21997, _5);
                _25713 = NOVALUE;
                Ref(_25714);
                Append(&_37LocalizeQual_15425, _37LocalizeQual_15425, _25714);
                DeRef(_25714);
                _25714 = NOVALUE;

                /** cominit.e:471					end for*/
                _i_50131 = _i_50131 + 1;
                goto L8; // [233] 204
L9: 
                ;
            }
            goto L5; // [238] 786

            /** cominit.e:473				case "ldb" then*/
            case 9:

            /** cominit.e:474					LocalDB = val*/
            Ref(_val_50102);
            DeRef(_37LocalDB_15426);
            _37LocalDB_15426 = _val_50102;
            goto L5; // [251] 786

            /** cominit.e:476				case "w" then*/
            case 10:

            /** cominit.e:477					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50102)){
                    _25716 = SEQ_PTR(_val_50102)->length;
            }
            else {
                _25716 = 1;
            }
            {
                object _i_50146;
                _i_50146 = 1;
LA: 
                if (_i_50146 > _25716){
                    goto LB; // [262] 392
                }

                /** cominit.e:478						sequence this_warn = val[i]*/
                DeRef(_this_warn_50148);
                _2 = (object)SEQ_PTR(_val_50102);
                _this_warn_50148 = (object)*(((s1_ptr)_2)->base + _i_50146);
                Ref(_this_warn_50148);

                /** cominit.e:479						integer auto_add_warn = 0*/
                _auto_add_warn_50150 = 0;

                /** cominit.e:480						if this_warn[1] = '+' then*/
                _2 = (object)SEQ_PTR(_this_warn_50148);
                _25718 = (object)*(((s1_ptr)_2)->base + 1);
                if (binary_op_a(NOTEQ, _25718, 43)){
                    _25718 = NOVALUE;
                    goto LC; // [288] 308
                }
                _25718 = NOVALUE;

                /** cominit.e:481							auto_add_warn = 1*/
                _auto_add_warn_50150 = 1;

                /** cominit.e:482							this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_50148)){
                        _25720 = SEQ_PTR(_this_warn_50148)->length;
                }
                else {
                    _25720 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_50148;
                RHS_Slice(_this_warn_50148, 2, _25720);
LC: 

                /** cominit.e:484						integer n = find(this_warn, warning_names)*/
                _n_50156 = find_from(_this_warn_50148, _36warning_names_21495, 1);

                /** cominit.e:485						if n != 0 then*/
                if (_n_50156 == 0)
                goto LD; // [319] 383

                /** cominit.e:486							if auto_add_warn or option_w = 1 then*/
                if (_auto_add_warn_50150 != 0) {
                    goto LE; // [325] 338
                }
                _25725 = (_option_w_50096 == 1);
                if (_25725 == 0)
                {
                    DeRef(_25725);
                    _25725 = NOVALUE;
                    goto LF; // [334] 357
                }
                else{
                    DeRef(_25725);
                    _25725 = NOVALUE;
                }
LE: 

                /** cominit.e:487								OpWarning = or_bits(OpWarning, warning_flags[n])*/
                _2 = (object)SEQ_PTR(_36warning_flags_21493);
                _25726 = (object)*(((s1_ptr)_2)->base + _n_50156);
                {uintptr_t tu;
                     tu = (uintptr_t)_36OpWarning_21518 | (uintptr_t)_25726;
                     _36OpWarning_21518 = MAKE_UINT(tu);
                }
                _25726 = NOVALUE;
                if (!IS_ATOM_INT(_36OpWarning_21518)) {
                    _1 = (object)(DBL_PTR(_36OpWarning_21518)->dbl);
                    DeRefDS(_36OpWarning_21518);
                    _36OpWarning_21518 = _1;
                }
                goto L10; // [354] 373
LF: 

                /** cominit.e:489								option_w = 1*/
                _option_w_50096 = 1;

                /** cominit.e:490								OpWarning = warning_flags[n]*/
                _2 = (object)SEQ_PTR(_36warning_flags_21493);
                _36OpWarning_21518 = (object)*(((s1_ptr)_2)->base + _n_50156);
L10: 

                /** cominit.e:493							prev_OpWarning = OpWarning*/
                _36prev_OpWarning_21519 = _36OpWarning_21518;
LD: 
                DeRef(_this_warn_50148);
                _this_warn_50148 = NOVALUE;

                /** cominit.e:495					end for*/
                _i_50146 = _i_50146 + 1;
                goto LA; // [387] 269
LB: 
                ;
            }
            goto L5; // [392] 786

            /** cominit.e:497				case "x" then*/
            case 11:

            /** cominit.e:498					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50102)){
                    _25729 = SEQ_PTR(_val_50102)->length;
            }
            else {
                _25729 = 1;
            }
            {
                object _i_50177;
                _i_50177 = 1;
L11: 
                if (_i_50177 > _25729){
                    goto L12; // [403] 542
                }

                /** cominit.e:499						sequence this_warn = val[i]*/
                DeRef(_this_warn_50179);
                _2 = (object)SEQ_PTR(_val_50102);
                _this_warn_50179 = (object)*(((s1_ptr)_2)->base + _i_50177);
                Ref(_this_warn_50179);

                /** cominit.e:500						integer auto_add_warn = 0*/
                _auto_add_warn_50181 = 0;

                /** cominit.e:501						if this_warn[1] = '+' then*/
                _2 = (object)SEQ_PTR(_this_warn_50179);
                _25731 = (object)*(((s1_ptr)_2)->base + 1);
                if (binary_op_a(NOTEQ, _25731, 43)){
                    _25731 = NOVALUE;
                    goto L13; // [429] 449
                }
                _25731 = NOVALUE;

                /** cominit.e:502							auto_add_warn = 1*/
                _auto_add_warn_50181 = 1;

                /** cominit.e:503							this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_50179)){
                        _25733 = SEQ_PTR(_this_warn_50179)->length;
                }
                else {
                    _25733 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_50179;
                RHS_Slice(_this_warn_50179, 2, _25733);
L13: 

                /** cominit.e:505						integer n = find(this_warn, warning_names)*/
                _n_50187 = find_from(_this_warn_50179, _36warning_names_21495, 1);

                /** cominit.e:506						if n != 0 then*/
                if (_n_50187 == 0)
                goto L14; // [460] 533

                /** cominit.e:507							if auto_add_warn or option_w = -1 then*/
                if (_auto_add_warn_50181 != 0) {
                    goto L15; // [466] 479
                }
                _25738 = (_option_w_50096 == -1);
                if (_25738 == 0)
                {
                    DeRef(_25738);
                    _25738 = NOVALUE;
                    goto L16; // [475] 501
                }
                else{
                    DeRef(_25738);
                    _25738 = NOVALUE;
                }
L15: 

                /** cominit.e:508								OpWarning = and_bits(OpWarning, not_bits(warning_flags[n]))*/
                _2 = (object)SEQ_PTR(_36warning_flags_21493);
                _25739 = (object)*(((s1_ptr)_2)->base + _n_50187);
                _25740 = not_bits(_25739);
                _25739 = NOVALUE;
                if (IS_ATOM_INT(_25740)) {
                    {uintptr_t tu;
                         tu = (uintptr_t)_36OpWarning_21518 & (uintptr_t)_25740;
                         _36OpWarning_21518 = MAKE_UINT(tu);
                    }
                }
                else {
                    temp_d.dbl = (eudouble)_36OpWarning_21518;
                    _36OpWarning_21518 = Dand_bits(&temp_d, DBL_PTR(_25740));
                }
                DeRef(_25740);
                _25740 = NOVALUE;
                if (!IS_ATOM_INT(_36OpWarning_21518)) {
                    _1 = (object)(DBL_PTR(_36OpWarning_21518)->dbl);
                    DeRefDS(_36OpWarning_21518);
                    _36OpWarning_21518 = _1;
                }
                goto L17; // [498] 523
L16: 

                /** cominit.e:510								option_w = -1*/
                _option_w_50096 = -1;

                /** cominit.e:511								OpWarning = all_warning_flag - warning_flags[n]*/
                _2 = (object)SEQ_PTR(_36warning_flags_21493);
                _25742 = (object)*(((s1_ptr)_2)->base + _n_50187);
                _36OpWarning_21518 = 32767 - _25742;
                _25742 = NOVALUE;
L17: 

                /** cominit.e:514							prev_OpWarning = OpWarning*/
                _36prev_OpWarning_21519 = _36OpWarning_21518;
L14: 
                DeRef(_this_warn_50179);
                _this_warn_50179 = NOVALUE;

                /** cominit.e:516					end for*/
                _i_50177 = _i_50177 + 1;
                goto L11; // [537] 410
L12: 
                ;
            }
            goto L5; // [542] 786

            /** cominit.e:518				case "wf" then*/
            case 12:

            /** cominit.e:519					TempWarningName = val*/
            Ref(_val_50102);
            DeRef(_36TempWarningName_21461);
            _36TempWarningName_21461 = _val_50102;

            /** cominit.e:520				  	error:warning_file(TempWarningName)*/
            Ref(_36TempWarningName_21461);
            _7warning_file(_36TempWarningName_21461);
            goto L5; // [560] 786

            /** cominit.e:522				case "v", "version" then*/
            case 13:
            case 14:

            /** cominit.e:523					show_banner()*/
            _49show_banner();

            /** cominit.e:524					if not batch_job and not test_only then*/
            _25744 = (_36batch_job_21460 == 0);
            if (_25744 == 0) {
                goto L18; // [579] 634
            }
            _25746 = (_36test_only_21459 == 0);
            if (_25746 == 0)
            {
                DeRef(_25746);
                _25746 = NOVALUE;
                goto L18; // [589] 634
            }
            else{
                DeRef(_25746);
                _25746 = NOVALUE;
            }

            /** cominit.e:525						console:maybe_any_key(GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE,0), 2)*/
            RefDS(_21997);
            _25747 = _39GetMsgText(278, 0, _21997);
            DeRef(_prompt_inlined_maybe_any_key_at_617_50223);
            _prompt_inlined_maybe_any_key_at_617_50223 = _25747;
            _25747 = NOVALUE;

            /** console.e:923		if not has_console() then*/

            /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50224);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50224 = machine(99, 0);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50224)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50224 != 0){
                    goto L19; // [616] 631
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50224)->dbl != 0.0){
                    goto L19; // [616] 631
                }
            }

            /** console.e:924			any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_617_50223);
            _5any_key(_prompt_inlined_maybe_any_key_at_617_50223, 2);

            /** console.e:926	end procedure*/
            goto L19; // [628] 631
L19: 
            DeRef(_prompt_inlined_maybe_any_key_at_617_50223);
            _prompt_inlined_maybe_any_key_at_617_50223 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50224);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50224 = NOVALUE;
L18: 

            /** cominit.e:528					abort(0)*/
            UserCleanup(0);
            goto L5; // [638] 786

            /** cominit.e:530				case "copyright" then*/
            case 15:

            /** cominit.e:531					show_copyrights()*/
            _49show_copyrights();

            /** cominit.e:532					if not batch_job and not test_only then*/
            _25748 = (_36batch_job_21460 == 0);
            if (_25748 == 0) {
                goto L1A; // [655] 710
            }
            _25750 = (_36test_only_21459 == 0);
            if (_25750 == 0)
            {
                DeRef(_25750);
                _25750 = NOVALUE;
                goto L1A; // [665] 710
            }
            else{
                DeRef(_25750);
                _25750 = NOVALUE;
            }

            /** cominit.e:533						console:maybe_any_key(GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE,0), 2)*/
            RefDS(_21997);
            _25751 = _39GetMsgText(278, 0, _21997);
            DeRef(_prompt_inlined_maybe_any_key_at_693_50236);
            _prompt_inlined_maybe_any_key_at_693_50236 = _25751;
            _25751 = NOVALUE;

            /** console.e:923		if not has_console() then*/

            /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50237);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50237 = machine(99, 0);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50237)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50237 != 0){
                    goto L1B; // [692] 707
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50237)->dbl != 0.0){
                    goto L1B; // [692] 707
                }
            }

            /** console.e:924			any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_693_50236);
            _5any_key(_prompt_inlined_maybe_any_key_at_693_50236, 2);

            /** console.e:926	end procedure*/
            goto L1B; // [704] 707
L1B: 
            DeRef(_prompt_inlined_maybe_any_key_at_693_50236);
            _prompt_inlined_maybe_any_key_at_693_50236 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50237);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50237 = NOVALUE;
L1A: 

            /** cominit.e:535					abort(0)*/
            UserCleanup(0);
            goto L5; // [714] 786

            /** cominit.e:537				case "eudir" then*/
            case 16:

            /** cominit.e:538					set_eudir( val )*/
            Ref(_val_50102);
            _37set_eudir(_val_50102);
            goto L5; // [725] 786

            /** cominit.e:540				case "trace-lines" then*/
            case 17:

            /** cominit.e:541					val = value( val )*/
            Ref(_val_50102);
            _0 = _val_50102;
            _val_50102 = _6value(_val_50102, 1, _6GET_SHORT_ANSWER_11168);
            DeRef(_0);

            /** cominit.e:542					if val[1] = GET_SUCCESS then*/
            _2 = (object)SEQ_PTR(_val_50102);
            _25753 = (object)*(((s1_ptr)_2)->base + 1);
            if (binary_op_a(NOTEQ, _25753, 0)){
                _25753 = NOVALUE;
                goto L1C; // [749] 767
            }
            _25753 = NOVALUE;

            /** cominit.e:543						trace_lines = floor( val[2] )*/
            _2 = (object)SEQ_PTR(_val_50102);
            _25755 = (object)*(((s1_ptr)_2)->base + 2);
            if (IS_ATOM_INT(_25755))
            _36trace_lines_64511 = e_floor(_25755);
            else
            _36trace_lines_64511 = unary_op(FLOOR, _25755);
            _25755 = NOVALUE;
            if (!IS_ATOM_INT(_36trace_lines_64511)) {
                _1 = (object)(DBL_PTR(_36trace_lines_64511)->dbl);
                DeRefDS(_36trace_lines_64511);
                _36trace_lines_64511 = _1;
            }
            goto L1D; // [764] 785
L1C: 

            /** cominit.e:545						puts(2, GetMsgText( BAD_TRACE_LINES ) )*/
            RefDS(_21997);
            _25757 = _39GetMsgText(604, 1, _21997);
            EPuts(2, _25757); // DJP 
            DeRef(_25757);
            _25757 = NOVALUE;

            /** cominit.e:546						abort( 1 )*/
            UserCleanup(1);
L1D: 
        ;}L5: 
        DeRef(_key_50100);
        _key_50100 = NOVALUE;
        DeRef(_val_50102);
        _val_50102 = NOVALUE;

        /** cominit.e:549		end for*/
        _idx_50098 = _idx_50098 + 1;
        goto L1; // [790] 27
L2: 
        ;
    }

    /** cominit.e:551		if length(LocalizeQual) = 0 then*/
    if (IS_SEQUENCE(_37LocalizeQual_15425)){
            _25758 = SEQ_PTR(_37LocalizeQual_15425)->length;
    }
    else {
        _25758 = 1;
    }
    if (_25758 != 0)
    goto L1E; // [802] 815

    /** cominit.e:552			LocalizeQual = {"en"}*/
    _0 = _37LocalizeQual_15425;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_25760);
    ((intptr_t*)_2)[1] = _25760;
    _37LocalizeQual_15425 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1E: 

    /** cominit.e:554	end procedure*/
    DeRef(_opts_50093);
    DeRef(_opt_keys_50094);
    DeRef(_25748);
    _25748 = NOVALUE;
    DeRef(_25744);
    _25744 = NOVALUE;
    return;
    ;
}


void _49finalize_command_line(object _opts_50263)
{
    object _extras_50270 = NOVALUE;
    object _pairs_50275 = NOVALUE;
    object _pair_50280 = NOVALUE;
    object _25790 = NOVALUE;
    object _25788 = NOVALUE;
    object _25785 = NOVALUE;
    object _25784 = NOVALUE;
    object _25783 = NOVALUE;
    object _25782 = NOVALUE;
    object _25781 = NOVALUE;
    object _25780 = NOVALUE;
    object _25779 = NOVALUE;
    object _25778 = NOVALUE;
    object _25777 = NOVALUE;
    object _25776 = NOVALUE;
    object _25775 = NOVALUE;
    object _25774 = NOVALUE;
    object _25773 = NOVALUE;
    object _25772 = NOVALUE;
    object _25771 = NOVALUE;
    object _25770 = NOVALUE;
    object _25769 = NOVALUE;
    object _25768 = NOVALUE;
    object _25766 = NOVALUE;
    object _25763 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:562		if Strict_is_on then -- overrides any -W/-X switches*/
    if (_36Strict_is_on_21516 == 0)
    {
        goto L1; // [5] 27
    }
    else{
    }

    /** cominit.e:563			OpWarning = all_warning_flag*/
    _36OpWarning_21518 = 32767;

    /** cominit.e:564			prev_OpWarning = OpWarning*/
    _36prev_OpWarning_21519 = 32767;
L1: 

    /** cominit.e:569		sequence extras = m:get(opts, cmdline:EXTRAS)*/
    Ref(_opts_50263);
    RefDS(_4EXTRAS_14176);
    _0 = _extras_50270;
    _extras_50270 = _29get(_opts_50263, _4EXTRAS_14176, 0);
    DeRef(_0);

    /** cominit.e:570		if length(extras) > 0 then*/
    if (IS_SEQUENCE(_extras_50270)){
            _25763 = SEQ_PTR(_extras_50270)->length;
    }
    else {
        _25763 = 1;
    }
    if (_25763 <= 0)
    goto L2; // [44] 270

    /** cominit.e:571			sequence pairs = m:pairs( opts )*/
    Ref(_opts_50263);
    _0 = _pairs_50275;
    _pairs_50275 = _29pairs(_opts_50263, 0);
    DeRef(_0);

    /** cominit.e:573			for i = 1 to length( pairs ) do*/
    if (IS_SEQUENCE(_pairs_50275)){
            _25766 = SEQ_PTR(_pairs_50275)->length;
    }
    else {
        _25766 = 1;
    }
    {
        object _i_50278;
        _i_50278 = 1;
L3: 
        if (_i_50278 > _25766){
            goto L4; // [62] 237
        }

        /** cominit.e:574				sequence pair = pairs[i]*/
        DeRef(_pair_50280);
        _2 = (object)SEQ_PTR(_pairs_50275);
        _pair_50280 = (object)*(((s1_ptr)_2)->base + _i_50278);
        Ref(_pair_50280);

        /** cominit.e:575				if equal( pair[1], cmdline:EXTRAS ) then*/
        _2 = (object)SEQ_PTR(_pair_50280);
        _25768 = (object)*(((s1_ptr)_2)->base + 1);
        if (_25768 == _4EXTRAS_14176)
        _25769 = 1;
        else if (IS_ATOM_INT(_25768) && IS_ATOM_INT(_4EXTRAS_14176))
        _25769 = 0;
        else
        _25769 = (compare(_25768, _4EXTRAS_14176) == 0);
        _25768 = NOVALUE;
        if (_25769 == 0)
        {
            _25769 = NOVALUE;
            goto L5; // [89] 99
        }
        else{
            _25769 = NOVALUE;
        }

        /** cominit.e:576					continue*/
        DeRefDS(_pair_50280);
        _pair_50280 = NOVALUE;
        goto L6; // [96] 232
L5: 

        /** cominit.e:578				pair[1] = prepend( pair[1], '-' )*/
        _2 = (object)SEQ_PTR(_pair_50280);
        _25770 = (object)*(((s1_ptr)_2)->base + 1);
        Prepend(&_25771, _25770, 45);
        _25770 = NOVALUE;
        _2 = (object)SEQ_PTR(_pair_50280);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _pair_50280 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _25771;
        if( _1 != _25771 ){
            DeRef(_1);
        }
        _25771 = NOVALUE;

        /** cominit.e:579				if sequence( pair[2] ) then*/
        _2 = (object)SEQ_PTR(_pair_50280);
        _25772 = (object)*(((s1_ptr)_2)->base + 2);
        _25773 = IS_SEQUENCE(_25772);
        _25772 = NOVALUE;
        if (_25773 == 0)
        {
            _25773 = NOVALUE;
            goto L7; // [122] 215
        }
        else{
            _25773 = NOVALUE;
        }

        /** cominit.e:580					if length( pair[2] ) and sequence( pair[2][1] ) then*/
        _2 = (object)SEQ_PTR(_pair_50280);
        _25774 = (object)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_25774)){
                _25775 = SEQ_PTR(_25774)->length;
        }
        else {
            _25775 = 1;
        }
        _25774 = NOVALUE;
        if (_25775 == 0) {
            goto L8; // [134] 203
        }
        _2 = (object)SEQ_PTR(_pair_50280);
        _25777 = (object)*(((s1_ptr)_2)->base + 2);
        _2 = (object)SEQ_PTR(_25777);
        _25778 = (object)*(((s1_ptr)_2)->base + 1);
        _25777 = NOVALUE;
        _25779 = IS_SEQUENCE(_25778);
        _25778 = NOVALUE;
        if (_25779 == 0)
        {
            _25779 = NOVALUE;
            goto L8; // [150] 203
        }
        else{
            _25779 = NOVALUE;
        }

        /** cominit.e:581						for j = 1 to length( pair[2] ) do*/
        _2 = (object)SEQ_PTR(_pair_50280);
        _25780 = (object)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_25780)){
                _25781 = SEQ_PTR(_25780)->length;
        }
        else {
            _25781 = 1;
        }
        _25780 = NOVALUE;
        {
            object _j_50298;
            _j_50298 = 1;
L9: 
            if (_j_50298 > _25781){
                goto LA; // [162] 200
            }

            /** cominit.e:582							switches &= { pair[1], pair[2][j] }*/
            _2 = (object)SEQ_PTR(_pair_50280);
            _25782 = (object)*(((s1_ptr)_2)->base + 1);
            _2 = (object)SEQ_PTR(_pair_50280);
            _25783 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_25783);
            _25784 = (object)*(((s1_ptr)_2)->base + _j_50298);
            _25783 = NOVALUE;
            Ref(_25784);
            Ref(_25782);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _25782;
            ((intptr_t *)_2)[2] = _25784;
            _25785 = MAKE_SEQ(_1);
            _25784 = NOVALUE;
            _25782 = NOVALUE;
            Concat((object_ptr)&_49switches_49596, _49switches_49596, _25785);
            DeRefDS(_25785);
            _25785 = NOVALUE;

            /** cominit.e:583						end for*/
            _j_50298 = _j_50298 + 1;
            goto L9; // [195] 169
LA: 
            ;
        }
        goto LB; // [200] 228
L8: 

        /** cominit.e:585						switches &= pair*/
        Concat((object_ptr)&_49switches_49596, _49switches_49596, _pair_50280);
        goto LB; // [212] 228
L7: 

        /** cominit.e:588					switches = append( switches, pair[1] )*/
        _2 = (object)SEQ_PTR(_pair_50280);
        _25788 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_25788);
        Append(&_49switches_49596, _49switches_49596, _25788);
        _25788 = NOVALUE;
LB: 
        DeRef(_pair_50280);
        _pair_50280 = NOVALUE;

        /** cominit.e:590			end for*/
L6: 
        _i_50278 = _i_50278 + 1;
        goto L3; // [232] 69
L4: 
        ;
    }

    /** cominit.e:592			Argv = Argv[2..3] & extras*/
    rhs_slice_target = (object_ptr)&_25790;
    RHS_Slice(_36Argv_21458, 2, 3);
    Concat((object_ptr)&_36Argv_21458, _25790, _extras_50270);
    DeRefDS(_25790);
    _25790 = NOVALUE;
    DeRef(_25790);
    _25790 = NOVALUE;

    /** cominit.e:593			Argc = length(Argv)*/
    if (IS_SEQUENCE(_36Argv_21458)){
            _36Argc_21457 = SEQ_PTR(_36Argv_21458)->length;
    }
    else {
        _36Argc_21457 = 1;
    }

    /** cominit.e:595			src_name = extras[1]*/
    DeRef(_49src_name_49595);
    _2 = (object)SEQ_PTR(_extras_50270);
    _49src_name_49595 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_49src_name_49595);
L2: 
    DeRef(_pairs_50275);
    _pairs_50275 = NOVALUE;

    /** cominit.e:597	end procedure*/
    DeRef(_opts_50263);
    DeRef(_extras_50270);
    _25780 = NOVALUE;
    _25774 = NOVALUE;
    return;
    ;
}



// 0x1C56D7D8
