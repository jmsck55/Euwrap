// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _57iif(object _test_22509, object _ifTrue_22510, object _ifFalse_22511)
{
    object _0, _1, _2;
    

    /** utils.e:54		if test then*/
    if (_test_22509 == 0)
    {
        goto L1; // [3] 13
    }
    else{
    }

    /** utils.e:55			return ifTrue*/
    DeRefDS(_ifFalse_22511);
    return _ifTrue_22510;
L1: 

    /** utils.e:57		return ifFalse*/
    DeRef(_ifTrue_22510);
    return _ifFalse_22511;
    ;
}



// 0x627DC9F8
