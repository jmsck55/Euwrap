// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _14sprint(object _x_8214)
{
    object _s_8215 = NOVALUE;
    object _4483 = NOVALUE;
    object _4481 = NOVALUE;
    object _4480 = NOVALUE;
    object _4477 = NOVALUE;
    object _4476 = NOVALUE;
    object _4474 = NOVALUE;
    object _4473 = NOVALUE;
    object _4472 = NOVALUE;
    object _4471 = NOVALUE;
    object _4470 = NOVALUE;
    object _4469 = NOVALUE;
    object _4468 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:93		if atom(x) then*/
    _4468 = IS_ATOM(_x_8214);
    if (_4468 == 0)
    {
        _4468 = NOVALUE;
        goto L1; // [6] 22
    }
    else{
        _4468 = NOVALUE;
    }

    /** text.e:94			return sprintf("%.10g", x)*/
    _4469 = EPrintf(-9999999, _4148, _x_8214);
    DeRef(_x_8214);
    DeRef(_s_8215);
    return _4469;
    goto L2; // [19] 137
L1: 

    /** text.e:96			s = "{"*/
    RefDS(_966);
    DeRef(_s_8215);
    _s_8215 = _966;

    /** text.e:97			for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_8214)){
            _4470 = SEQ_PTR(_x_8214)->length;
    }
    else {
        _4470 = 1;
    }
    {
        object _i_8221;
        _i_8221 = 1;
L3: 
        if (_i_8221 > _4470){
            goto L4; // [34] 98
        }

        /** text.e:98				if atom(x[i]) then*/
        _2 = (object)SEQ_PTR(_x_8214);
        _4471 = (object)*(((s1_ptr)_2)->base + _i_8221);
        _4472 = IS_ATOM(_4471);
        _4471 = NOVALUE;
        if (_4472 == 0)
        {
            _4472 = NOVALUE;
            goto L5; // [50] 70
        }
        else{
            _4472 = NOVALUE;
        }

        /** text.e:99					s &= sprintf("%.10g", x[i])*/
        _2 = (object)SEQ_PTR(_x_8214);
        _4473 = (object)*(((s1_ptr)_2)->base + _i_8221);
        _4474 = EPrintf(-9999999, _4148, _4473);
        _4473 = NOVALUE;
        Concat((object_ptr)&_s_8215, _s_8215, _4474);
        DeRefDS(_4474);
        _4474 = NOVALUE;
        goto L6; // [67] 85
L5: 

        /** text.e:101					s &= sprint(x[i])*/
        _2 = (object)SEQ_PTR(_x_8214);
        _4476 = (object)*(((s1_ptr)_2)->base + _i_8221);
        Ref(_4476);
        _4477 = _14sprint(_4476);
        _4476 = NOVALUE;
        if (IS_SEQUENCE(_s_8215) && IS_ATOM(_4477)) {
            Ref(_4477);
            Append(&_s_8215, _s_8215, _4477);
        }
        else if (IS_ATOM(_s_8215) && IS_SEQUENCE(_4477)) {
        }
        else {
            Concat((object_ptr)&_s_8215, _s_8215, _4477);
        }
        DeRef(_4477);
        _4477 = NOVALUE;
L6: 

        /** text.e:103				s &= ','*/
        Append(&_s_8215, _s_8215, 44);

        /** text.e:104			end for*/
        _i_8221 = _i_8221 + 1;
        goto L3; // [93] 41
L4: 
        ;
    }

    /** text.e:105			if s[$] = ',' then*/
    if (IS_SEQUENCE(_s_8215)){
            _4480 = SEQ_PTR(_s_8215)->length;
    }
    else {
        _4480 = 1;
    }
    _2 = (object)SEQ_PTR(_s_8215);
    _4481 = (object)*(((s1_ptr)_2)->base + _4480);
    if (binary_op_a(NOTEQ, _4481, 44)){
        _4481 = NOVALUE;
        goto L7; // [107] 123
    }
    _4481 = NOVALUE;

    /** text.e:106				s[$] = '}'*/
    if (IS_SEQUENCE(_s_8215)){
            _4483 = SEQ_PTR(_s_8215)->length;
    }
    else {
        _4483 = 1;
    }
    _2 = (object)SEQ_PTR(_s_8215);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _s_8215 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _4483);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 125;
    DeRef(_1);
    goto L8; // [120] 130
L7: 

    /** text.e:108				s &= '}'*/
    Append(&_s_8215, _s_8215, 125);
L8: 

    /** text.e:110			return s*/
    DeRef(_x_8214);
    DeRef(_4469);
    _4469 = NOVALUE;
    return _s_8215;
L2: 
    ;
}


object _14trim(object _source_8284, object _what_8285, object _ret_index_8286)
{
    object _rpos_8287 = NOVALUE;
    object _lpos_8288 = NOVALUE;
    object _4524 = NOVALUE;
    object _4522 = NOVALUE;
    object _4520 = NOVALUE;
    object _4518 = NOVALUE;
    object _4515 = NOVALUE;
    object _4514 = NOVALUE;
    object _4509 = NOVALUE;
    object _4508 = NOVALUE;
    object _4506 = NOVALUE;
    object _4504 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:243		if atom(what) then*/
    _4504 = 0;
    if (_4504 == 0)
    {
        _4504 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _4504 = NOVALUE;
    }

    /** text.e:244			what = {what}*/
    _0 = _what_8285;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_what_8285);
    ((intptr_t*)_2)[1] = _what_8285;
    _what_8285 = MAKE_SEQ(_1);
    DeRefDSi(_0);
L1: 

    /** text.e:247		lpos = 1*/
    _lpos_8288 = 1;

    /** text.e:248		while lpos <= length(source) do*/
L2: 
    if (IS_SEQUENCE(_source_8284)){
            _4506 = SEQ_PTR(_source_8284)->length;
    }
    else {
        _4506 = 1;
    }
    if (_lpos_8288 > _4506)
    goto L3; // [33] 67

    /** text.e:249			if not find(source[lpos], what) then*/
    _2 = (object)SEQ_PTR(_source_8284);
    _4508 = (object)*(((s1_ptr)_2)->base + _lpos_8288);
    _4509 = find_from(_4508, _what_8285, 1);
    _4508 = NOVALUE;
    if (_4509 != 0)
    goto L4; // [48] 56
    _4509 = NOVALUE;

    /** text.e:250				exit*/
    goto L3; // [53] 67
L4: 

    /** text.e:252			lpos += 1*/
    _lpos_8288 = _lpos_8288 + 1;

    /** text.e:253		end while*/
    goto L2; // [64] 30
L3: 

    /** text.e:255		rpos = length(source)*/
    if (IS_SEQUENCE(_source_8284)){
            _rpos_8287 = SEQ_PTR(_source_8284)->length;
    }
    else {
        _rpos_8287 = 1;
    }

    /** text.e:256		while rpos > lpos do*/
L5: 
    if (_rpos_8287 <= _lpos_8288)
    goto L6; // [77] 111

    /** text.e:257			if not find(source[rpos], what) then*/
    _2 = (object)SEQ_PTR(_source_8284);
    _4514 = (object)*(((s1_ptr)_2)->base + _rpos_8287);
    _4515 = find_from(_4514, _what_8285, 1);
    _4514 = NOVALUE;
    if (_4515 != 0)
    goto L7; // [92] 100
    _4515 = NOVALUE;

    /** text.e:258				exit*/
    goto L6; // [97] 111
L7: 

    /** text.e:260			rpos -= 1*/
    _rpos_8287 = _rpos_8287 - 1;

    /** text.e:261		end while*/
    goto L5; // [108] 77
L6: 

    /** text.e:263		if ret_index then*/
    if (_ret_index_8286 == 0)
    {
        goto L8; // [113] 129
    }
    else{
    }

    /** text.e:264			return {lpos, rpos}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _lpos_8288;
    ((intptr_t *)_2)[2] = _rpos_8287;
    _4518 = MAKE_SEQ(_1);
    DeRefDS(_source_8284);
    DeRef(_what_8285);
    return _4518;
    goto L9; // [126] 180
L8: 

    /** text.e:266			if lpos = 1 then*/
    if (_lpos_8288 != 1)
    goto LA; // [131] 152

    /** text.e:267				if rpos = length(source) then*/
    if (IS_SEQUENCE(_source_8284)){
            _4520 = SEQ_PTR(_source_8284)->length;
    }
    else {
        _4520 = 1;
    }
    if (_rpos_8287 != _4520)
    goto LB; // [140] 151

    /** text.e:268					return source*/
    DeRef(_what_8285);
    DeRef(_4518);
    _4518 = NOVALUE;
    return _source_8284;
LB: 
LA: 

    /** text.e:271			if lpos > length(source) then*/
    if (IS_SEQUENCE(_source_8284)){
            _4522 = SEQ_PTR(_source_8284)->length;
    }
    else {
        _4522 = 1;
    }
    if (_lpos_8288 <= _4522)
    goto LC; // [157] 168

    /** text.e:272				return {}*/
    RefDS(_5);
    DeRefDS(_source_8284);
    DeRef(_what_8285);
    DeRef(_4518);
    _4518 = NOVALUE;
    return _5;
LC: 

    /** text.e:274			return source[lpos..rpos]*/
    rhs_slice_target = (object_ptr)&_4524;
    RHS_Slice(_source_8284, _lpos_8288, _rpos_8287);
    DeRefDS(_source_8284);
    DeRef(_what_8285);
    DeRef(_4518);
    _4518 = NOVALUE;
    return _4524;
L9: 
    ;
}


object _14lower(object _x_8476)
{
    object _4636 = NOVALUE;
    object _4635 = NOVALUE;
    object _4634 = NOVALUE;
    object _4633 = NOVALUE;
    object _4632 = NOVALUE;
    object _4629 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:535		if length(lower_case_SET) != 0 then*/
    _4629 = 0;

    /** text.e:539		ifdef WINDOWS then*/

    /** text.e:542			return x + (x >= 'A' and x <= 'Z') * TO_LOWER*/
    if (IS_ATOM_INT(_x_8476)) {
        _4632 = (_x_8476 >= 65);
    }
    else {
        _4632 = binary_op(GREATEREQ, _x_8476, 65);
    }
    if (IS_ATOM_INT(_x_8476)) {
        _4633 = (_x_8476 <= 90);
    }
    else {
        _4633 = binary_op(LESSEQ, _x_8476, 90);
    }
    if (IS_ATOM_INT(_4632) && IS_ATOM_INT(_4633)) {
        _4634 = (_4632 != 0 && _4633 != 0);
    }
    else {
        _4634 = binary_op(AND, _4632, _4633);
    }
    DeRef(_4632);
    _4632 = NOVALUE;
    DeRef(_4633);
    _4633 = NOVALUE;
    if (IS_ATOM_INT(_4634)) {
        if (_4634 == (short)_4634){
            _4635 = _4634 * 32;
        }
        else{
            _4635 = NewDouble(_4634 * (eudouble)32);
        }
    }
    else {
        _4635 = binary_op(MULTIPLY, _4634, 32);
    }
    DeRef(_4634);
    _4634 = NOVALUE;
    if (IS_ATOM_INT(_x_8476) && IS_ATOM_INT(_4635)) {
        _4636 = _x_8476 + _4635;
        if ((object)((uintptr_t)_4636 + (uintptr_t)HIGH_BITS) >= 0){
            _4636 = NewDouble((eudouble)_4636);
        }
    }
    else {
        _4636 = binary_op(PLUS, _x_8476, _4635);
    }
    DeRef(_4635);
    _4635 = NOVALUE;
    DeRef(_x_8476);
    return _4636;
    ;
}


object _14upper(object _x_8488)
{
    object _4644 = NOVALUE;
    object _4643 = NOVALUE;
    object _4642 = NOVALUE;
    object _4641 = NOVALUE;
    object _4640 = NOVALUE;
    object _4637 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:581		if length(upper_case_SET) != 0 then*/
    _4637 = 0;

    /** text.e:584		ifdef WINDOWS then*/

    /** text.e:587			return x - (x >= 'a' and x <= 'z') * TO_LOWER*/
    if (IS_ATOM_INT(_x_8488)) {
        _4640 = (_x_8488 >= 97);
    }
    else {
        _4640 = binary_op(GREATEREQ, _x_8488, 97);
    }
    if (IS_ATOM_INT(_x_8488)) {
        _4641 = (_x_8488 <= 122);
    }
    else {
        _4641 = binary_op(LESSEQ, _x_8488, 122);
    }
    if (IS_ATOM_INT(_4640) && IS_ATOM_INT(_4641)) {
        _4642 = (_4640 != 0 && _4641 != 0);
    }
    else {
        _4642 = binary_op(AND, _4640, _4641);
    }
    DeRef(_4640);
    _4640 = NOVALUE;
    DeRef(_4641);
    _4641 = NOVALUE;
    if (IS_ATOM_INT(_4642)) {
        if (_4642 == (short)_4642){
            _4643 = _4642 * 32;
        }
        else{
            _4643 = NewDouble(_4642 * (eudouble)32);
        }
    }
    else {
        _4643 = binary_op(MULTIPLY, _4642, 32);
    }
    DeRef(_4642);
    _4642 = NOVALUE;
    if (IS_ATOM_INT(_x_8488) && IS_ATOM_INT(_4643)) {
        _4644 = _x_8488 - _4643;
        if ((object)((uintptr_t)_4644 +(uintptr_t) HIGH_BITS) >= 0){
            _4644 = NewDouble((eudouble)_4644);
        }
    }
    else {
        _4644 = binary_op(MINUS, _x_8488, _4643);
    }
    DeRef(_4643);
    _4643 = NOVALUE;
    DeRef(_x_8488);
    return _4644;
    ;
}


object _14proper(object _x_8500)
{
    object _pos_8501 = NOVALUE;
    object _inword_8502 = NOVALUE;
    object _convert_8503 = NOVALUE;
    object _res_8504 = NOVALUE;
    object _4674 = NOVALUE;
    object _4673 = NOVALUE;
    object _4672 = NOVALUE;
    object _4671 = NOVALUE;
    object _4670 = NOVALUE;
    object _4669 = NOVALUE;
    object _4668 = NOVALUE;
    object _4667 = NOVALUE;
    object _4666 = NOVALUE;
    object _4665 = NOVALUE;
    object _4663 = NOVALUE;
    object _4662 = NOVALUE;
    object _4657 = NOVALUE;
    object _4654 = NOVALUE;
    object _4651 = NOVALUE;
    object _4648 = NOVALUE;
    object _4647 = NOVALUE;
    object _4646 = NOVALUE;
    object _4645 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:633		inword = 0	-- Initially not in a word*/
    _inword_8502 = 0;

    /** text.e:634		convert = 1	-- Initially convert text*/
    _convert_8503 = 1;

    /** text.e:635		res = x		-- Work on a copy of the original, in case we need to restore.*/
    RefDS(_x_8500);
    DeRef(_res_8504);
    _res_8504 = _x_8500;

    /** text.e:636		for i = 1 to length(res) do*/
    if (IS_SEQUENCE(_res_8504)){
            _4645 = SEQ_PTR(_res_8504)->length;
    }
    else {
        _4645 = 1;
    }
    {
        object _i_8506;
        _i_8506 = 1;
L1: 
        if (_i_8506 > _4645){
            goto L2; // [25] 298
        }

        /** text.e:637			if integer(res[i]) then*/
        _2 = (object)SEQ_PTR(_res_8504);
        _4646 = (object)*(((s1_ptr)_2)->base + _i_8506);
        if (IS_ATOM_INT(_4646))
        _4647 = 1;
        else if (IS_ATOM_DBL(_4646))
        _4647 = IS_ATOM_INT(DoubleToInt(_4646));
        else
        _4647 = 0;
        _4646 = NOVALUE;
        if (_4647 == 0)
        {
            _4647 = NOVALUE;
            goto L3; // [41] 209
        }
        else{
            _4647 = NOVALUE;
        }

        /** text.e:638				if convert then*/
        if (_convert_8503 == 0)
        {
            goto L4; // [46] 291
        }
        else{
        }

        /** text.e:640					pos = types:t_upper(res[i])*/
        _2 = (object)SEQ_PTR(_res_8504);
        _4648 = (object)*(((s1_ptr)_2)->base + _i_8506);
        Ref(_4648);
        _pos_8501 = _13t_upper(_4648);
        _4648 = NOVALUE;
        if (!IS_ATOM_INT(_pos_8501)) {
            _1 = (object)(DBL_PTR(_pos_8501)->dbl);
            DeRefDS(_pos_8501);
            _pos_8501 = _1;
        }

        /** text.e:641					if pos = 0 then*/
        if (_pos_8501 != 0)
        goto L5; // [63] 175

        /** text.e:643						pos = types:t_lower(res[i])*/
        _2 = (object)SEQ_PTR(_res_8504);
        _4651 = (object)*(((s1_ptr)_2)->base + _i_8506);
        Ref(_4651);
        _pos_8501 = _13t_lower(_4651);
        _4651 = NOVALUE;
        if (!IS_ATOM_INT(_pos_8501)) {
            _1 = (object)(DBL_PTR(_pos_8501)->dbl);
            DeRefDS(_pos_8501);
            _pos_8501 = _1;
        }

        /** text.e:644						if pos = 0 then*/
        if (_pos_8501 != 0)
        goto L6; // [81] 138

        /** text.e:647							pos = t_digit(res[i])*/
        _2 = (object)SEQ_PTR(_res_8504);
        _4654 = (object)*(((s1_ptr)_2)->base + _i_8506);
        Ref(_4654);
        _pos_8501 = _13t_digit(_4654);
        _4654 = NOVALUE;
        if (!IS_ATOM_INT(_pos_8501)) {
            _1 = (object)(DBL_PTR(_pos_8501)->dbl);
            DeRefDS(_pos_8501);
            _pos_8501 = _1;
        }

        /** text.e:648							if pos = 0 then*/
        if (_pos_8501 != 0)
        goto L4; // [99] 291

        /** text.e:650								pos = t_specword(res[i])*/
        _2 = (object)SEQ_PTR(_res_8504);
        _4657 = (object)*(((s1_ptr)_2)->base + _i_8506);
        Ref(_4657);
        _pos_8501 = _13t_specword(_4657);
        _4657 = NOVALUE;
        if (!IS_ATOM_INT(_pos_8501)) {
            _1 = (object)(DBL_PTR(_pos_8501)->dbl);
            DeRefDS(_pos_8501);
            _pos_8501 = _1;
        }

        /** text.e:651								if pos then*/
        if (_pos_8501 == 0)
        {
            goto L7; // [117] 128
        }
        else{
        }

        /** text.e:652									inword = 1*/
        _inword_8502 = 1;
        goto L4; // [125] 291
L7: 

        /** text.e:654									inword = 0*/
        _inword_8502 = 0;
        goto L4; // [135] 291
L6: 

        /** text.e:658							if inword = 0 then*/
        if (_inword_8502 != 0)
        goto L4; // [140] 291

        /** text.e:660								if pos <= 26 then*/
        if (_pos_8501 > 26)
        goto L8; // [146] 165

        /** text.e:661									res[i] = upper(res[i]) -- Convert to uppercase*/
        _2 = (object)SEQ_PTR(_res_8504);
        _4662 = (object)*(((s1_ptr)_2)->base + _i_8506);
        Ref(_4662);
        _4663 = _14upper(_4662);
        _4662 = NOVALUE;
        _2 = (object)SEQ_PTR(_res_8504);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _res_8504 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_8506);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _4663;
        if( _1 != _4663 ){
            DeRef(_1);
        }
        _4663 = NOVALUE;
L8: 

        /** text.e:663								inword = 1	-- now we are in a word*/
        _inword_8502 = 1;
        goto L4; // [172] 291
L5: 

        /** text.e:667						if inword = 1 then*/
        if (_inword_8502 != 1)
        goto L9; // [177] 198

        /** text.e:669							res[i] = lower(res[i]) -- Convert to lowercase*/
        _2 = (object)SEQ_PTR(_res_8504);
        _4665 = (object)*(((s1_ptr)_2)->base + _i_8506);
        Ref(_4665);
        _4666 = _14lower(_4665);
        _4665 = NOVALUE;
        _2 = (object)SEQ_PTR(_res_8504);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _res_8504 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_8506);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _4666;
        if( _1 != _4666 ){
            DeRef(_1);
        }
        _4666 = NOVALUE;
        goto L4; // [195] 291
L9: 

        /** text.e:671							inword = 1	-- now we are in a word*/
        _inword_8502 = 1;
        goto L4; // [206] 291
L3: 

        /** text.e:678				if convert then*/
        if (_convert_8503 == 0)
        {
            goto LA; // [211] 263
        }
        else{
        }

        /** text.e:680					for j = 1 to i-1 do*/
        _4667 = _i_8506 - 1;
        {
            object _j_8547;
            _j_8547 = 1;
LB: 
            if (_j_8547 > _4667){
                goto LC; // [220] 257
            }

            /** text.e:681						if atom(x[j]) then*/
            _2 = (object)SEQ_PTR(_x_8500);
            _4668 = (object)*(((s1_ptr)_2)->base + _j_8547);
            _4669 = IS_ATOM(_4668);
            _4668 = NOVALUE;
            if (_4669 == 0)
            {
                _4669 = NOVALUE;
                goto LD; // [236] 250
            }
            else{
                _4669 = NOVALUE;
            }

            /** text.e:682							res[j] = x[j]*/
            _2 = (object)SEQ_PTR(_x_8500);
            _4670 = (object)*(((s1_ptr)_2)->base + _j_8547);
            Ref(_4670);
            _2 = (object)SEQ_PTR(_res_8504);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _res_8504 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _j_8547);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _4670;
            if( _1 != _4670 ){
                DeRef(_1);
            }
            _4670 = NOVALUE;
LD: 

            /** text.e:684					end for*/
            _j_8547 = _j_8547 + 1;
            goto LB; // [252] 227
LC: 
            ;
        }

        /** text.e:686					convert = 0*/
        _convert_8503 = 0;
LA: 

        /** text.e:689				if sequence(res[i]) then*/
        _2 = (object)SEQ_PTR(_res_8504);
        _4671 = (object)*(((s1_ptr)_2)->base + _i_8506);
        _4672 = IS_SEQUENCE(_4671);
        _4671 = NOVALUE;
        if (_4672 == 0)
        {
            _4672 = NOVALUE;
            goto LE; // [272] 290
        }
        else{
            _4672 = NOVALUE;
        }

        /** text.e:690					res[i] = proper(res[i])	-- recursive conversion*/
        _2 = (object)SEQ_PTR(_res_8504);
        _4673 = (object)*(((s1_ptr)_2)->base + _i_8506);
        Ref(_4673);
        _4674 = _14proper(_4673);
        _4673 = NOVALUE;
        _2 = (object)SEQ_PTR(_res_8504);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _res_8504 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_8506);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _4674;
        if( _1 != _4674 ){
            DeRef(_1);
        }
        _4674 = NOVALUE;
LE: 
L4: 

        /** text.e:693		end for*/
        _i_8506 = _i_8506 + 1;
        goto L1; // [293] 32
L2: 
        ;
    }

    /** text.e:694		return res*/
    DeRefDS(_x_8500);
    DeRef(_4667);
    _4667 = NOVALUE;
    return _res_8504;
    ;
}


object _14quote(object _text_in_8823, object _quote_pair_8824, object _esc_8826, object _sp_8828)
{
    object _4945 = NOVALUE;
    object _4944 = NOVALUE;
    object _4943 = NOVALUE;
    object _4941 = NOVALUE;
    object _4940 = NOVALUE;
    object _4939 = NOVALUE;
    object _4937 = NOVALUE;
    object _4936 = NOVALUE;
    object _4935 = NOVALUE;
    object _4934 = NOVALUE;
    object _4933 = NOVALUE;
    object _4932 = NOVALUE;
    object _4931 = NOVALUE;
    object _4930 = NOVALUE;
    object _4929 = NOVALUE;
    object _4927 = NOVALUE;
    object _4926 = NOVALUE;
    object _4925 = NOVALUE;
    object _4923 = NOVALUE;
    object _4922 = NOVALUE;
    object _4921 = NOVALUE;
    object _4920 = NOVALUE;
    object _4919 = NOVALUE;
    object _4918 = NOVALUE;
    object _4917 = NOVALUE;
    object _4916 = NOVALUE;
    object _4915 = NOVALUE;
    object _4913 = NOVALUE;
    object _4912 = NOVALUE;
    object _4910 = NOVALUE;
    object _4909 = NOVALUE;
    object _4908 = NOVALUE;
    object _4906 = NOVALUE;
    object _4905 = NOVALUE;
    object _4904 = NOVALUE;
    object _4903 = NOVALUE;
    object _4902 = NOVALUE;
    object _4901 = NOVALUE;
    object _4900 = NOVALUE;
    object _4899 = NOVALUE;
    object _4898 = NOVALUE;
    object _4897 = NOVALUE;
    object _4896 = NOVALUE;
    object _4895 = NOVALUE;
    object _4894 = NOVALUE;
    object _4893 = NOVALUE;
    object _4892 = NOVALUE;
    object _4891 = NOVALUE;
    object _4890 = NOVALUE;
    object _4887 = NOVALUE;
    object _4886 = NOVALUE;
    object _4885 = NOVALUE;
    object _4884 = NOVALUE;
    object _4883 = NOVALUE;
    object _4882 = NOVALUE;
    object _4881 = NOVALUE;
    object _4880 = NOVALUE;
    object _4879 = NOVALUE;
    object _4878 = NOVALUE;
    object _4877 = NOVALUE;
    object _4876 = NOVALUE;
    object _4875 = NOVALUE;
    object _4874 = NOVALUE;
    object _4871 = NOVALUE;
    object _4869 = NOVALUE;
    object _4868 = NOVALUE;
    object _4866 = NOVALUE;
    object _4864 = NOVALUE;
    object _4863 = NOVALUE;
    object _4862 = NOVALUE;
    object _4860 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:1118		if length(text_in) = 0 then*/
    if (IS_SEQUENCE(_text_in_8823)){
            _4860 = SEQ_PTR(_text_in_8823)->length;
    }
    else {
        _4860 = 1;
    }
    if (_4860 != 0)
    goto L1; // [10] 21

    /** text.e:1119			return text_in*/
    DeRef(_quote_pair_8824);
    DeRef(_sp_8828);
    return _text_in_8823;
L1: 

    /** text.e:1122		if atom(quote_pair) then*/
    _4862 = IS_ATOM(_quote_pair_8824);
    if (_4862 == 0)
    {
        _4862 = NOVALUE;
        goto L2; // [26] 46
    }
    else{
        _4862 = NOVALUE;
    }

    /** text.e:1123			quote_pair = {{quote_pair}, {quote_pair}}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_quote_pair_8824);
    ((intptr_t*)_2)[1] = _quote_pair_8824;
    _4863 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_quote_pair_8824);
    ((intptr_t*)_2)[1] = _quote_pair_8824;
    _4864 = MAKE_SEQ(_1);
    DeRef(_quote_pair_8824);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _4863;
    ((intptr_t *)_2)[2] = _4864;
    _quote_pair_8824 = MAKE_SEQ(_1);
    _4864 = NOVALUE;
    _4863 = NOVALUE;
    goto L3; // [43] 89
L2: 

    /** text.e:1124		elsif length(quote_pair) = 1 then*/
    if (IS_SEQUENCE(_quote_pair_8824)){
            _4866 = SEQ_PTR(_quote_pair_8824)->length;
    }
    else {
        _4866 = 1;
    }
    if (_4866 != 1)
    goto L4; // [51] 72

    /** text.e:1125			quote_pair = {quote_pair[1], quote_pair[1]}*/
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4868 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4869 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_4869);
    Ref(_4868);
    DeRef(_quote_pair_8824);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _4868;
    ((intptr_t *)_2)[2] = _4869;
    _quote_pair_8824 = MAKE_SEQ(_1);
    _4869 = NOVALUE;
    _4868 = NOVALUE;
    goto L3; // [69] 89
L4: 

    /** text.e:1126		elsif length(quote_pair) = 0 then*/
    if (IS_SEQUENCE(_quote_pair_8824)){
            _4871 = SEQ_PTR(_quote_pair_8824)->length;
    }
    else {
        _4871 = 1;
    }
    if (_4871 != 0)
    goto L5; // [77] 88

    /** text.e:1127			quote_pair = {"\"", "\""}*/
    RefDS(_4852);
    RefDS(_4852);
    DeRef(_quote_pair_8824);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _4852;
    ((intptr_t *)_2)[2] = _4852;
    _quote_pair_8824 = MAKE_SEQ(_1);
L5: 
L3: 

    /** text.e:1130		if sequence(text_in[1]) then*/
    _2 = (object)SEQ_PTR(_text_in_8823);
    _4874 = (object)*(((s1_ptr)_2)->base + 1);
    _4875 = IS_SEQUENCE(_4874);
    _4874 = NOVALUE;
    if (_4875 == 0)
    {
        _4875 = NOVALUE;
        goto L6; // [98] 166
    }
    else{
        _4875 = NOVALUE;
    }

    /** text.e:1131			for i = 1 to length(text_in) do*/
    if (IS_SEQUENCE(_text_in_8823)){
            _4876 = SEQ_PTR(_text_in_8823)->length;
    }
    else {
        _4876 = 1;
    }
    {
        object _i_8851;
        _i_8851 = 1;
L7: 
        if (_i_8851 > _4876){
            goto L8; // [106] 159
        }

        /** text.e:1132				if sequence(text_in[i]) then*/
        _2 = (object)SEQ_PTR(_text_in_8823);
        _4877 = (object)*(((s1_ptr)_2)->base + _i_8851);
        _4878 = IS_SEQUENCE(_4877);
        _4877 = NOVALUE;
        if (_4878 == 0)
        {
            _4878 = NOVALUE;
            goto L9; // [122] 152
        }
        else{
            _4878 = NOVALUE;
        }

        /** text.e:1133					text_in[i] = quote(text_in[i], quote_pair, esc, sp)*/
        _2 = (object)SEQ_PTR(_text_in_8823);
        _4879 = (object)*(((s1_ptr)_2)->base + _i_8851);
        Ref(_quote_pair_8824);
        DeRef(_4880);
        _4880 = _quote_pair_8824;
        DeRef(_4881);
        _4881 = _esc_8826;
        Ref(_sp_8828);
        DeRef(_4882);
        _4882 = _sp_8828;
        Ref(_4879);
        _4883 = _14quote(_4879, _4880, _4881, _4882);
        _4879 = NOVALUE;
        _4880 = NOVALUE;
        _4881 = NOVALUE;
        _4882 = NOVALUE;
        _2 = (object)SEQ_PTR(_text_in_8823);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _text_in_8823 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_8851);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _4883;
        if( _1 != _4883 ){
            DeRef(_1);
        }
        _4883 = NOVALUE;
L9: 

        /** text.e:1135			end for*/
        _i_8851 = _i_8851 + 1;
        goto L7; // [154] 113
L8: 
        ;
    }

    /** text.e:1137			return text_in*/
    DeRef(_quote_pair_8824);
    DeRef(_sp_8828);
    return _text_in_8823;
L6: 

    /** text.e:1141		for i = 1 to length(sp) do*/
    if (IS_SEQUENCE(_sp_8828)){
            _4884 = SEQ_PTR(_sp_8828)->length;
    }
    else {
        _4884 = 1;
    }
    {
        object _i_8862;
        _i_8862 = 1;
LA: 
        if (_i_8862 > _4884){
            goto LB; // [171] 220
        }

        /** text.e:1142			if find(sp[i], text_in) then*/
        _2 = (object)SEQ_PTR(_sp_8828);
        _4885 = (object)*(((s1_ptr)_2)->base + _i_8862);
        _4886 = find_from(_4885, _text_in_8823, 1);
        _4885 = NOVALUE;
        if (_4886 == 0)
        {
            _4886 = NOVALUE;
            goto LC; // [189] 197
        }
        else{
            _4886 = NOVALUE;
        }

        /** text.e:1143				exit*/
        goto LB; // [194] 220
LC: 

        /** text.e:1146			if i = length(sp) then*/
        if (IS_SEQUENCE(_sp_8828)){
                _4887 = SEQ_PTR(_sp_8828)->length;
        }
        else {
            _4887 = 1;
        }
        if (_i_8862 != _4887)
        goto LD; // [202] 213

        /** text.e:1148				return text_in*/
        DeRef(_quote_pair_8824);
        DeRef(_sp_8828);
        return _text_in_8823;
LD: 

        /** text.e:1150		end for*/
        _i_8862 = _i_8862 + 1;
        goto LA; // [215] 178
LB: 
        ;
    }

    /** text.e:1152		if esc >= 0  then*/
    if (_esc_8826 < 0)
    goto LE; // [222] 561

    /** text.e:1156			if atom(quote_pair[1]) then*/
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4890 = (object)*(((s1_ptr)_2)->base + 1);
    _4891 = IS_ATOM(_4890);
    _4890 = NOVALUE;
    if (_4891 == 0)
    {
        _4891 = NOVALUE;
        goto LF; // [235] 253
    }
    else{
        _4891 = NOVALUE;
    }

    /** text.e:1157				quote_pair[1] = {quote_pair[1]}*/
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4892 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_4892);
    ((intptr_t*)_2)[1] = _4892;
    _4893 = MAKE_SEQ(_1);
    _4892 = NOVALUE;
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _quote_pair_8824 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _4893;
    if( _1 != _4893 ){
        DeRef(_1);
    }
    _4893 = NOVALUE;
LF: 

    /** text.e:1159			if atom(quote_pair[2]) then*/
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4894 = (object)*(((s1_ptr)_2)->base + 2);
    _4895 = IS_ATOM(_4894);
    _4894 = NOVALUE;
    if (_4895 == 0)
    {
        _4895 = NOVALUE;
        goto L10; // [262] 280
    }
    else{
        _4895 = NOVALUE;
    }

    /** text.e:1160				quote_pair[2] = {quote_pair[2]}*/
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4896 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_4896);
    ((intptr_t*)_2)[1] = _4896;
    _4897 = MAKE_SEQ(_1);
    _4896 = NOVALUE;
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _quote_pair_8824 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _4897;
    if( _1 != _4897 ){
        DeRef(_1);
    }
    _4897 = NOVALUE;
L10: 

    /** text.e:1163			if equal(quote_pair[1], quote_pair[2]) then*/
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4898 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4899 = (object)*(((s1_ptr)_2)->base + 2);
    if (_4898 == _4899)
    _4900 = 1;
    else if (IS_ATOM_INT(_4898) && IS_ATOM_INT(_4899))
    _4900 = 0;
    else
    _4900 = (compare(_4898, _4899) == 0);
    _4898 = NOVALUE;
    _4899 = NOVALUE;
    if (_4900 == 0)
    {
        _4900 = NOVALUE;
        goto L11; // [294] 372
    }
    else{
        _4900 = NOVALUE;
    }

    /** text.e:1165				if match(quote_pair[1], text_in) then*/
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4901 = (object)*(((s1_ptr)_2)->base + 1);
    _4902 = e_match_from(_4901, _text_in_8823, 1);
    _4901 = NOVALUE;
    if (_4902 == 0)
    {
        _4902 = NOVALUE;
        goto L12; // [308] 560
    }
    else{
        _4902 = NOVALUE;
    }

    /** text.e:1166					if match(esc & quote_pair[1], text_in) then*/
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4903 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_8826) && IS_ATOM(_4903)) {
    }
    else if (IS_ATOM(_esc_8826) && IS_SEQUENCE(_4903)) {
        Prepend(&_4904, _4903, _esc_8826);
    }
    else {
        Concat((object_ptr)&_4904, _esc_8826, _4903);
    }
    _4903 = NOVALUE;
    _4905 = e_match_from(_4904, _text_in_8823, 1);
    DeRefDS(_4904);
    _4904 = NOVALUE;
    if (_4905 == 0)
    {
        _4905 = NOVALUE;
        goto L13; // [326] 345
    }
    else{
        _4905 = NOVALUE;
    }

    /** text.e:1167						text_in = search:match_replace(esc, text_in, esc & esc)*/
    Concat((object_ptr)&_4906, _esc_8826, _esc_8826);
    RefDS(_text_in_8823);
    _0 = _text_in_8823;
    _text_in_8823 = _16match_replace(_esc_8826, _text_in_8823, _4906, 0);
    DeRefDS(_0);
    _4906 = NOVALUE;
L13: 

    /** text.e:1169					text_in = search:match_replace(quote_pair[1], text_in, esc & quote_pair[1])*/
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4908 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4909 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_8826) && IS_ATOM(_4909)) {
    }
    else if (IS_ATOM(_esc_8826) && IS_SEQUENCE(_4909)) {
        Prepend(&_4910, _4909, _esc_8826);
    }
    else {
        Concat((object_ptr)&_4910, _esc_8826, _4909);
    }
    _4909 = NOVALUE;
    Ref(_4908);
    RefDS(_text_in_8823);
    _0 = _text_in_8823;
    _text_in_8823 = _16match_replace(_4908, _text_in_8823, _4910, 0);
    DeRefDS(_0);
    _4908 = NOVALUE;
    _4910 = NOVALUE;
    goto L12; // [369] 560
L11: 

    /** text.e:1172				if match(quote_pair[1], text_in) or*/
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4912 = (object)*(((s1_ptr)_2)->base + 1);
    _4913 = e_match_from(_4912, _text_in_8823, 1);
    _4912 = NOVALUE;
    if (_4913 != 0) {
        goto L14; // [383] 401
    }
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4915 = (object)*(((s1_ptr)_2)->base + 2);
    _4916 = e_match_from(_4915, _text_in_8823, 1);
    _4915 = NOVALUE;
    if (_4916 == 0)
    {
        _4916 = NOVALUE;
        goto L15; // [397] 473
    }
    else{
        _4916 = NOVALUE;
    }
L14: 

    /** text.e:1174					if match(esc & quote_pair[1], text_in) then*/
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4917 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_8826) && IS_ATOM(_4917)) {
    }
    else if (IS_ATOM(_esc_8826) && IS_SEQUENCE(_4917)) {
        Prepend(&_4918, _4917, _esc_8826);
    }
    else {
        Concat((object_ptr)&_4918, _esc_8826, _4917);
    }
    _4917 = NOVALUE;
    _4919 = e_match_from(_4918, _text_in_8823, 1);
    DeRefDS(_4918);
    _4918 = NOVALUE;
    if (_4919 == 0)
    {
        _4919 = NOVALUE;
        goto L16; // [416] 449
    }
    else{
        _4919 = NOVALUE;
    }

    /** text.e:1175						text_in = search:match_replace(esc & quote_pair[1], text_in, esc & esc & quote_pair[1])*/
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4920 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_8826) && IS_ATOM(_4920)) {
    }
    else if (IS_ATOM(_esc_8826) && IS_SEQUENCE(_4920)) {
        Prepend(&_4921, _4920, _esc_8826);
    }
    else {
        Concat((object_ptr)&_4921, _esc_8826, _4920);
    }
    _4920 = NOVALUE;
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4922 = (object)*(((s1_ptr)_2)->base + 1);
    {
        object concat_list[3];

        concat_list[0] = _4922;
        concat_list[1] = _esc_8826;
        concat_list[2] = _esc_8826;
        Concat_N((object_ptr)&_4923, concat_list, 3);
    }
    _4922 = NOVALUE;
    RefDS(_text_in_8823);
    _0 = _text_in_8823;
    _text_in_8823 = _16match_replace(_4921, _text_in_8823, _4923, 0);
    DeRefDS(_0);
    _4921 = NOVALUE;
    _4923 = NOVALUE;
L16: 

    /** text.e:1177					text_in = match_replace(quote_pair[1], text_in, esc & quote_pair[1])*/
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4925 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4926 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_8826) && IS_ATOM(_4926)) {
    }
    else if (IS_ATOM(_esc_8826) && IS_SEQUENCE(_4926)) {
        Prepend(&_4927, _4926, _esc_8826);
    }
    else {
        Concat((object_ptr)&_4927, _esc_8826, _4926);
    }
    _4926 = NOVALUE;
    Ref(_4925);
    RefDS(_text_in_8823);
    _0 = _text_in_8823;
    _text_in_8823 = _16match_replace(_4925, _text_in_8823, _4927, 0);
    DeRefDS(_0);
    _4925 = NOVALUE;
    _4927 = NOVALUE;
L15: 

    /** text.e:1180				if match(quote_pair[2], text_in) then*/
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4929 = (object)*(((s1_ptr)_2)->base + 2);
    _4930 = e_match_from(_4929, _text_in_8823, 1);
    _4929 = NOVALUE;
    if (_4930 == 0)
    {
        _4930 = NOVALUE;
        goto L17; // [484] 559
    }
    else{
        _4930 = NOVALUE;
    }

    /** text.e:1181					if match(esc & quote_pair[2], text_in) then*/
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4931 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_8826) && IS_ATOM(_4931)) {
    }
    else if (IS_ATOM(_esc_8826) && IS_SEQUENCE(_4931)) {
        Prepend(&_4932, _4931, _esc_8826);
    }
    else {
        Concat((object_ptr)&_4932, _esc_8826, _4931);
    }
    _4931 = NOVALUE;
    _4933 = e_match_from(_4932, _text_in_8823, 1);
    DeRefDS(_4932);
    _4932 = NOVALUE;
    if (_4933 == 0)
    {
        _4933 = NOVALUE;
        goto L18; // [502] 535
    }
    else{
        _4933 = NOVALUE;
    }

    /** text.e:1182						text_in = search:match_replace(esc & quote_pair[2], text_in, esc & esc & quote_pair[2])*/
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4934 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_8826) && IS_ATOM(_4934)) {
    }
    else if (IS_ATOM(_esc_8826) && IS_SEQUENCE(_4934)) {
        Prepend(&_4935, _4934, _esc_8826);
    }
    else {
        Concat((object_ptr)&_4935, _esc_8826, _4934);
    }
    _4934 = NOVALUE;
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4936 = (object)*(((s1_ptr)_2)->base + 2);
    {
        object concat_list[3];

        concat_list[0] = _4936;
        concat_list[1] = _esc_8826;
        concat_list[2] = _esc_8826;
        Concat_N((object_ptr)&_4937, concat_list, 3);
    }
    _4936 = NOVALUE;
    RefDS(_text_in_8823);
    _0 = _text_in_8823;
    _text_in_8823 = _16match_replace(_4935, _text_in_8823, _4937, 0);
    DeRefDS(_0);
    _4935 = NOVALUE;
    _4937 = NOVALUE;
L18: 

    /** text.e:1184					text_in = search:match_replace(quote_pair[2], text_in, esc & quote_pair[2])*/
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4939 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4940 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_8826) && IS_ATOM(_4940)) {
    }
    else if (IS_ATOM(_esc_8826) && IS_SEQUENCE(_4940)) {
        Prepend(&_4941, _4940, _esc_8826);
    }
    else {
        Concat((object_ptr)&_4941, _esc_8826, _4940);
    }
    _4940 = NOVALUE;
    Ref(_4939);
    RefDS(_text_in_8823);
    _0 = _text_in_8823;
    _text_in_8823 = _16match_replace(_4939, _text_in_8823, _4941, 0);
    DeRefDS(_0);
    _4939 = NOVALUE;
    _4941 = NOVALUE;
L17: 
L12: 
LE: 

    /** text.e:1189		return quote_pair[1] & text_in & quote_pair[2]*/
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4943 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_quote_pair_8824);
    _4944 = (object)*(((s1_ptr)_2)->base + 2);
    {
        object concat_list[3];

        concat_list[0] = _4944;
        concat_list[1] = _text_in_8823;
        concat_list[2] = _4943;
        Concat_N((object_ptr)&_4945, concat_list, 3);
    }
    _4944 = NOVALUE;
    _4943 = NOVALUE;
    DeRefDS(_text_in_8823);
    DeRef(_quote_pair_8824);
    DeRef(_sp_8828);
    return _4945;
    ;
}


object _14format(object _format_pattern_9044, object _arg_list_9045)
{
    object _result_9046 = NOVALUE;
    object _in_token_9047 = NOVALUE;
    object _tch_9048 = NOVALUE;
    object _i_9049 = NOVALUE;
    object _tend_9050 = NOVALUE;
    object _cap_9051 = NOVALUE;
    object _align_9052 = NOVALUE;
    object _psign_9053 = NOVALUE;
    object _msign_9054 = NOVALUE;
    object _zfill_9055 = NOVALUE;
    object _bwz_9056 = NOVALUE;
    object _spacer_9057 = NOVALUE;
    object _alt_9058 = NOVALUE;
    object _width_9059 = NOVALUE;
    object _decs_9060 = NOVALUE;
    object _pos_9061 = NOVALUE;
    object _argn_9062 = NOVALUE;
    object _argl_9063 = NOVALUE;
    object _trimming_9064 = NOVALUE;
    object _hexout_9065 = NOVALUE;
    object _binout_9066 = NOVALUE;
    object _tsep_9067 = NOVALUE;
    object _istext_9068 = NOVALUE;
    object _prevargv_9069 = NOVALUE;
    object _currargv_9070 = NOVALUE;
    object _idname_9071 = NOVALUE;
    object _envsym_9072 = NOVALUE;
    object _envvar_9073 = NOVALUE;
    object _ep_9074 = NOVALUE;
    object _pflag_9075 = NOVALUE;
    object _count_9076 = NOVALUE;
    object _sp_9150 = NOVALUE;
    object _sp_9186 = NOVALUE;
    object _argtext_9233 = NOVALUE;
    object _tempv_9478 = NOVALUE;
    object _pretty_sprint_inlined_pretty_sprint_at_2521_9533 = NOVALUE;
    object _options_inlined_pretty_sprint_at_2518_9532 = NOVALUE;
    object _pretty_sprint_inlined_pretty_sprint_at_2577_9540 = NOVALUE;
    object _options_inlined_pretty_sprint_at_2574_9539 = NOVALUE;
    object _x_inlined_pretty_sprint_at_2571_9538 = NOVALUE;
    object _msg_inlined_crash_at_2725_9562 = NOVALUE;
    object _dpos_9624 = NOVALUE;
    object _dist_9625 = NOVALUE;
    object _bracketed_9626 = NOVALUE;
    object _5480 = NOVALUE;
    object _5479 = NOVALUE;
    object _5478 = NOVALUE;
    object _5476 = NOVALUE;
    object _5475 = NOVALUE;
    object _5474 = NOVALUE;
    object _5471 = NOVALUE;
    object _5470 = NOVALUE;
    object _5467 = NOVALUE;
    object _5465 = NOVALUE;
    object _5462 = NOVALUE;
    object _5461 = NOVALUE;
    object _5460 = NOVALUE;
    object _5457 = NOVALUE;
    object _5454 = NOVALUE;
    object _5453 = NOVALUE;
    object _5452 = NOVALUE;
    object _5451 = NOVALUE;
    object _5448 = NOVALUE;
    object _5447 = NOVALUE;
    object _5446 = NOVALUE;
    object _5443 = NOVALUE;
    object _5441 = NOVALUE;
    object _5438 = NOVALUE;
    object _5437 = NOVALUE;
    object _5436 = NOVALUE;
    object _5435 = NOVALUE;
    object _5432 = NOVALUE;
    object _5427 = NOVALUE;
    object _5426 = NOVALUE;
    object _5425 = NOVALUE;
    object _5424 = NOVALUE;
    object _5422 = NOVALUE;
    object _5421 = NOVALUE;
    object _5420 = NOVALUE;
    object _5419 = NOVALUE;
    object _5418 = NOVALUE;
    object _5417 = NOVALUE;
    object _5416 = NOVALUE;
    object _5411 = NOVALUE;
    object _5407 = NOVALUE;
    object _5406 = NOVALUE;
    object _5404 = NOVALUE;
    object _5402 = NOVALUE;
    object _5401 = NOVALUE;
    object _5400 = NOVALUE;
    object _5399 = NOVALUE;
    object _5398 = NOVALUE;
    object _5395 = NOVALUE;
    object _5393 = NOVALUE;
    object _5392 = NOVALUE;
    object _5391 = NOVALUE;
    object _5390 = NOVALUE;
    object _5387 = NOVALUE;
    object _5386 = NOVALUE;
    object _5384 = NOVALUE;
    object _5383 = NOVALUE;
    object _5382 = NOVALUE;
    object _5381 = NOVALUE;
    object _5380 = NOVALUE;
    object _5377 = NOVALUE;
    object _5376 = NOVALUE;
    object _5375 = NOVALUE;
    object _5372 = NOVALUE;
    object _5371 = NOVALUE;
    object _5369 = NOVALUE;
    object _5365 = NOVALUE;
    object _5364 = NOVALUE;
    object _5362 = NOVALUE;
    object _5361 = NOVALUE;
    object _5353 = NOVALUE;
    object _5349 = NOVALUE;
    object _5347 = NOVALUE;
    object _5346 = NOVALUE;
    object _5345 = NOVALUE;
    object _5342 = NOVALUE;
    object _5340 = NOVALUE;
    object _5339 = NOVALUE;
    object _5338 = NOVALUE;
    object _5336 = NOVALUE;
    object _5335 = NOVALUE;
    object _5334 = NOVALUE;
    object _5333 = NOVALUE;
    object _5330 = NOVALUE;
    object _5329 = NOVALUE;
    object _5328 = NOVALUE;
    object _5326 = NOVALUE;
    object _5325 = NOVALUE;
    object _5324 = NOVALUE;
    object _5323 = NOVALUE;
    object _5321 = NOVALUE;
    object _5319 = NOVALUE;
    object _5317 = NOVALUE;
    object _5315 = NOVALUE;
    object _5313 = NOVALUE;
    object _5311 = NOVALUE;
    object _5310 = NOVALUE;
    object _5309 = NOVALUE;
    object _5308 = NOVALUE;
    object _5307 = NOVALUE;
    object _5306 = NOVALUE;
    object _5304 = NOVALUE;
    object _5303 = NOVALUE;
    object _5301 = NOVALUE;
    object _5300 = NOVALUE;
    object _5298 = NOVALUE;
    object _5296 = NOVALUE;
    object _5295 = NOVALUE;
    object _5292 = NOVALUE;
    object _5290 = NOVALUE;
    object _5286 = NOVALUE;
    object _5284 = NOVALUE;
    object _5283 = NOVALUE;
    object _5282 = NOVALUE;
    object _5280 = NOVALUE;
    object _5279 = NOVALUE;
    object _5278 = NOVALUE;
    object _5277 = NOVALUE;
    object _5276 = NOVALUE;
    object _5274 = NOVALUE;
    object _5272 = NOVALUE;
    object _5271 = NOVALUE;
    object _5270 = NOVALUE;
    object _5269 = NOVALUE;
    object _5265 = NOVALUE;
    object _5262 = NOVALUE;
    object _5261 = NOVALUE;
    object _5258 = NOVALUE;
    object _5257 = NOVALUE;
    object _5256 = NOVALUE;
    object _5254 = NOVALUE;
    object _5253 = NOVALUE;
    object _5252 = NOVALUE;
    object _5251 = NOVALUE;
    object _5249 = NOVALUE;
    object _5247 = NOVALUE;
    object _5246 = NOVALUE;
    object _5245 = NOVALUE;
    object _5244 = NOVALUE;
    object _5243 = NOVALUE;
    object _5242 = NOVALUE;
    object _5240 = NOVALUE;
    object _5239 = NOVALUE;
    object _5238 = NOVALUE;
    object _5236 = NOVALUE;
    object _5235 = NOVALUE;
    object _5234 = NOVALUE;
    object _5233 = NOVALUE;
    object _5231 = NOVALUE;
    object _5228 = NOVALUE;
    object _5227 = NOVALUE;
    object _5225 = NOVALUE;
    object _5224 = NOVALUE;
    object _5222 = NOVALUE;
    object _5219 = NOVALUE;
    object _5218 = NOVALUE;
    object _5215 = NOVALUE;
    object _5213 = NOVALUE;
    object _5209 = NOVALUE;
    object _5207 = NOVALUE;
    object _5206 = NOVALUE;
    object _5205 = NOVALUE;
    object _5203 = NOVALUE;
    object _5201 = NOVALUE;
    object _5200 = NOVALUE;
    object _5199 = NOVALUE;
    object _5198 = NOVALUE;
    object _5197 = NOVALUE;
    object _5195 = NOVALUE;
    object _5193 = NOVALUE;
    object _5192 = NOVALUE;
    object _5191 = NOVALUE;
    object _5190 = NOVALUE;
    object _5188 = NOVALUE;
    object _5185 = NOVALUE;
    object _5183 = NOVALUE;
    object _5182 = NOVALUE;
    object _5181 = NOVALUE;
    object _5180 = NOVALUE;
    object _5179 = NOVALUE;
    object _5177 = NOVALUE;
    object _5176 = NOVALUE;
    object _5175 = NOVALUE;
    object _5173 = NOVALUE;
    object _5172 = NOVALUE;
    object _5171 = NOVALUE;
    object _5170 = NOVALUE;
    object _5168 = NOVALUE;
    object _5167 = NOVALUE;
    object _5166 = NOVALUE;
    object _5163 = NOVALUE;
    object _5162 = NOVALUE;
    object _5161 = NOVALUE;
    object _5160 = NOVALUE;
    object _5158 = NOVALUE;
    object _5157 = NOVALUE;
    object _5156 = NOVALUE;
    object _5155 = NOVALUE;
    object _5152 = NOVALUE;
    object _5151 = NOVALUE;
    object _5150 = NOVALUE;
    object _5148 = NOVALUE;
    object _5147 = NOVALUE;
    object _5146 = NOVALUE;
    object _5145 = NOVALUE;
    object _5142 = NOVALUE;
    object _5141 = NOVALUE;
    object _5140 = NOVALUE;
    object _5139 = NOVALUE;
    object _5137 = NOVALUE;
    object _5136 = NOVALUE;
    object _5135 = NOVALUE;
    object _5133 = NOVALUE;
    object _5132 = NOVALUE;
    object _5131 = NOVALUE;
    object _5129 = NOVALUE;
    object _5122 = NOVALUE;
    object _5120 = NOVALUE;
    object _5119 = NOVALUE;
    object _5112 = NOVALUE;
    object _5109 = NOVALUE;
    object _5105 = NOVALUE;
    object _5103 = NOVALUE;
    object _5102 = NOVALUE;
    object _5099 = NOVALUE;
    object _5097 = NOVALUE;
    object _5095 = NOVALUE;
    object _5092 = NOVALUE;
    object _5090 = NOVALUE;
    object _5089 = NOVALUE;
    object _5088 = NOVALUE;
    object _5087 = NOVALUE;
    object _5086 = NOVALUE;
    object _5083 = NOVALUE;
    object _5080 = NOVALUE;
    object _5079 = NOVALUE;
    object _5078 = NOVALUE;
    object _5075 = NOVALUE;
    object _5073 = NOVALUE;
    object _5071 = NOVALUE;
    object _5068 = NOVALUE;
    object _5067 = NOVALUE;
    object _5060 = NOVALUE;
    object _5057 = NOVALUE;
    object _5056 = NOVALUE;
    object _5048 = NOVALUE;
    object _5043 = NOVALUE;
    object _5040 = NOVALUE;
    object _5029 = NOVALUE;
    object _5027 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:1445		if atom(arg_list) then*/
    _5027 = IS_ATOM(_arg_list_9045);
    if (_5027 == 0)
    {
        _5027 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _5027 = NOVALUE;
    }

    /** text.e:1446			arg_list = {arg_list}*/
    _0 = _arg_list_9045;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_arg_list_9045);
    ((intptr_t*)_2)[1] = _arg_list_9045;
    _arg_list_9045 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** text.e:1449		result = ""*/
    RefDS(_5);
    DeRef(_result_9046);
    _result_9046 = _5;

    /** text.e:1450		in_token = 0*/
    _in_token_9047 = 0;

    /** text.e:1453		i = 0*/
    _i_9049 = 0;

    /** text.e:1454		tend = 0*/
    _tend_9050 = 0;

    /** text.e:1455		argl = 0*/
    _argl_9063 = 0;

    /** text.e:1456		spacer = 0*/
    _spacer_9057 = 0;

    /** text.e:1457		prevargv = 0*/
    DeRef(_prevargv_9069);
    _prevargv_9069 = 0;

    /** text.e:1458	    while i < length(format_pattern) do*/
L2: 
    if (IS_SEQUENCE(_format_pattern_9044)){
            _5029 = SEQ_PTR(_format_pattern_9044)->length;
    }
    else {
        _5029 = 1;
    }
    if (_i_9049 >= _5029)
    goto L3; // [63] 3614

    /** text.e:1459	    	i += 1*/
    _i_9049 = _i_9049 + 1;

    /** text.e:1460	    	tch = format_pattern[i]*/
    _2 = (object)SEQ_PTR(_format_pattern_9044);
    _tch_9048 = (object)*(((s1_ptr)_2)->base + _i_9049);
    if (!IS_ATOM_INT(_tch_9048))
    _tch_9048 = (object)DBL_PTR(_tch_9048)->dbl;

    /** text.e:1461	    	if not in_token then*/
    if (_in_token_9047 != 0)
    goto L4; // [81] 210

    /** text.e:1462	    		if tch = '[' then*/
    if (_tch_9048 != 91)
    goto L5; // [86] 200

    /** text.e:1463	    			in_token = 1*/
    _in_token_9047 = 1;

    /** text.e:1464	    			tend = 0*/
    _tend_9050 = 0;

    /** text.e:1465					cap = 0*/
    _cap_9051 = 0;

    /** text.e:1466					align = 0*/
    _align_9052 = 0;

    /** text.e:1467					psign = 0*/
    _psign_9053 = 0;

    /** text.e:1468					msign = 0*/
    _msign_9054 = 0;

    /** text.e:1469					zfill = 0*/
    _zfill_9055 = 0;

    /** text.e:1470					bwz = 0*/
    _bwz_9056 = 0;

    /** text.e:1471					spacer = 0*/
    _spacer_9057 = 0;

    /** text.e:1472					alt = 0*/
    _alt_9058 = 0;

    /** text.e:1473	    			width = 0*/
    _width_9059 = 0;

    /** text.e:1474	    			decs = -1*/
    _decs_9060 = -1;

    /** text.e:1475	    			argn = 0*/
    _argn_9062 = 0;

    /** text.e:1476	    			hexout = 0*/
    _hexout_9065 = 0;

    /** text.e:1477	    			binout = 0*/
    _binout_9066 = 0;

    /** text.e:1478	    			trimming = 0*/
    _trimming_9064 = 0;

    /** text.e:1479	    			tsep = 0*/
    _tsep_9067 = 0;

    /** text.e:1480	    			istext = 0*/
    _istext_9068 = 0;

    /** text.e:1481	    			idname = ""*/
    RefDS(_5);
    DeRef(_idname_9071);
    _idname_9071 = _5;

    /** text.e:1482	    			envvar = ""*/
    RefDS(_5);
    DeRefi(_envvar_9073);
    _envvar_9073 = _5;

    /** text.e:1483	    			envsym = ""*/
    RefDS(_5);
    DeRef(_envsym_9072);
    _envsym_9072 = _5;
    goto L2; // [197] 60
L5: 

    /** text.e:1485	    			result &= tch*/
    Append(&_result_9046, _result_9046, _tch_9048);
    goto L2; // [207] 60
L4: 

    /** text.e:1488				switch tch do*/
    _0 = _tch_9048;
    switch ( _0 ){ 

        /** text.e:1489	    			case ']' then*/
        case 93:

        /** text.e:1490	    				in_token = 0*/
        _in_token_9047 = 0;

        /** text.e:1491	    				tend = i*/
        _tend_9050 = _i_9049;
        goto L6; // [231] 1072

        /** text.e:1493	    			case '[' then*/
        case 91:

        /** text.e:1494		    			result &= tch*/
        Append(&_result_9046, _result_9046, _tch_9048);

        /** text.e:1495		    			while i < length(format_pattern) do*/
L7: 
        if (IS_SEQUENCE(_format_pattern_9044)){
                _5040 = SEQ_PTR(_format_pattern_9044)->length;
        }
        else {
            _5040 = 1;
        }
        if (_i_9049 >= _5040)
        goto L6; // [251] 1072

        /** text.e:1496		    				i += 1*/
        _i_9049 = _i_9049 + 1;

        /** text.e:1497		    				if format_pattern[i] = ']' then*/
        _2 = (object)SEQ_PTR(_format_pattern_9044);
        _5043 = (object)*(((s1_ptr)_2)->base + _i_9049);
        if (binary_op_a(NOTEQ, _5043, 93)){
            _5043 = NOVALUE;
            goto L7; // [267] 248
        }
        _5043 = NOVALUE;

        /** text.e:1498		    					in_token = 0*/
        _in_token_9047 = 0;

        /** text.e:1499		    					tend = 0*/
        _tend_9050 = 0;

        /** text.e:1500		    					exit*/
        goto L6; // [283] 1072

        /** text.e:1502		    			end while*/
        goto L7; // [288] 248
        goto L6; // [291] 1072

        /** text.e:1504		    		case 'w', 'u', 'l' then*/
        case 119:
        case 117:
        case 108:

        /** text.e:1505		    			cap = tch*/
        _cap_9051 = _tch_9048;
        goto L6; // [306] 1072

        /** text.e:1507		    		case 'b' then*/
        case 98:

        /** text.e:1508		    			bwz = 1*/
        _bwz_9056 = 1;
        goto L6; // [317] 1072

        /** text.e:1510		    		case 's' then*/
        case 115:

        /** text.e:1511		    			spacer = 1*/
        _spacer_9057 = 1;
        goto L6; // [328] 1072

        /** text.e:1513		    		case 't' then*/
        case 116:

        /** text.e:1514		    			trimming = 1*/
        _trimming_9064 = 1;
        goto L6; // [339] 1072

        /** text.e:1516		    		case 'z' then*/
        case 122:

        /** text.e:1517		    			zfill = 1*/
        _zfill_9055 = 1;
        goto L6; // [350] 1072

        /** text.e:1519		    		case 'X' then*/
        case 88:

        /** text.e:1520		    			hexout = 1*/
        _hexout_9065 = 1;
        goto L6; // [361] 1072

        /** text.e:1522		    		case 'B' then*/
        case 66:

        /** text.e:1523		    			binout = 1*/
        _binout_9066 = 1;
        goto L6; // [372] 1072

        /** text.e:1525		    		case 'c', '<', '>' then*/
        case 99:
        case 60:
        case 62:

        /** text.e:1526		    			align = tch*/
        _align_9052 = _tch_9048;
        goto L6; // [387] 1072

        /** text.e:1528		    		case '+' then*/
        case 43:

        /** text.e:1529		    			psign = 1*/
        _psign_9053 = 1;
        goto L6; // [398] 1072

        /** text.e:1531		    		case '(' then*/
        case 40:

        /** text.e:1532		    			msign = 1*/
        _msign_9054 = 1;
        goto L6; // [409] 1072

        /** text.e:1534		    		case '?' then*/
        case 63:

        /** text.e:1535		    			alt = 1*/
        _alt_9058 = 1;
        goto L6; // [420] 1072

        /** text.e:1537		    		case 'T' then*/
        case 84:

        /** text.e:1538		    			istext = 1*/
        _istext_9068 = 1;
        goto L6; // [431] 1072

        /** text.e:1540		    		case ':' then*/
        case 58:

        /** text.e:1541		    			while i < length(format_pattern) do*/
L8: 
        if (IS_SEQUENCE(_format_pattern_9044)){
                _5048 = SEQ_PTR(_format_pattern_9044)->length;
        }
        else {
            _5048 = 1;
        }
        if (_i_9049 >= _5048)
        goto L6; // [445] 1072

        /** text.e:1542		    				i += 1*/
        _i_9049 = _i_9049 + 1;

        /** text.e:1543		    				tch = format_pattern[i]*/
        _2 = (object)SEQ_PTR(_format_pattern_9044);
        _tch_9048 = (object)*(((s1_ptr)_2)->base + _i_9049);
        if (!IS_ATOM_INT(_tch_9048))
        _tch_9048 = (object)DBL_PTR(_tch_9048)->dbl;

        /** text.e:1544		    				pos = find(tch, "0123456789")*/
        _pos_9061 = find_from(_tch_9048, _5052, 1);

        /** text.e:1545		    				if pos = 0 then*/
        if (_pos_9061 != 0)
        goto L9; // [470] 485

        /** text.e:1546		    					i -= 1*/
        _i_9049 = _i_9049 - 1;

        /** text.e:1547		    					exit*/
        goto L6; // [482] 1072
L9: 

        /** text.e:1549		    				width = width * 10 + pos - 1*/
        if (_width_9059 == (short)_width_9059){
            _5056 = _width_9059 * 10;
        }
        else{
            _5056 = NewDouble(_width_9059 * (eudouble)10);
        }
        if (IS_ATOM_INT(_5056)) {
            _5057 = _5056 + _pos_9061;
            if ((object)((uintptr_t)_5057 + (uintptr_t)HIGH_BITS) >= 0){
                _5057 = NewDouble((eudouble)_5057);
            }
        }
        else {
            _5057 = NewDouble(DBL_PTR(_5056)->dbl + (eudouble)_pos_9061);
        }
        DeRef(_5056);
        _5056 = NOVALUE;
        if (IS_ATOM_INT(_5057)) {
            _width_9059 = _5057 - 1;
        }
        else {
            _width_9059 = NewDouble(DBL_PTR(_5057)->dbl - (eudouble)1);
        }
        DeRef(_5057);
        _5057 = NOVALUE;
        if (!IS_ATOM_INT(_width_9059)) {
            _1 = (object)(DBL_PTR(_width_9059)->dbl);
            DeRefDS(_width_9059);
            _width_9059 = _1;
        }

        /** text.e:1550		    				if width = 0 then*/
        if (_width_9059 != 0)
        goto L8; // [505] 442

        /** text.e:1551		    					zfill = '0'*/
        _zfill_9055 = 48;

        /** text.e:1553		    			end while*/
        goto L8; // [517] 442
        goto L6; // [520] 1072

        /** text.e:1555		    		case '.' then*/
        case 46:

        /** text.e:1556		    			decs = 0*/
        _decs_9060 = 0;

        /** text.e:1557		    			while i < length(format_pattern) do*/
LA: 
        if (IS_SEQUENCE(_format_pattern_9044)){
                _5060 = SEQ_PTR(_format_pattern_9044)->length;
        }
        else {
            _5060 = 1;
        }
        if (_i_9049 >= _5060)
        goto L6; // [539] 1072

        /** text.e:1558		    				i += 1*/
        _i_9049 = _i_9049 + 1;

        /** text.e:1559		    				tch = format_pattern[i]*/
        _2 = (object)SEQ_PTR(_format_pattern_9044);
        _tch_9048 = (object)*(((s1_ptr)_2)->base + _i_9049);
        if (!IS_ATOM_INT(_tch_9048))
        _tch_9048 = (object)DBL_PTR(_tch_9048)->dbl;

        /** text.e:1560		    				pos = find(tch, "0123456789")*/
        _pos_9061 = find_from(_tch_9048, _5052, 1);

        /** text.e:1561		    				if pos = 0 then*/
        if (_pos_9061 != 0)
        goto LB; // [564] 579

        /** text.e:1562		    					i -= 1*/
        _i_9049 = _i_9049 - 1;

        /** text.e:1563		    					exit*/
        goto L6; // [576] 1072
LB: 

        /** text.e:1565		    				decs = decs * 10 + pos - 1*/
        if (_decs_9060 == (short)_decs_9060){
            _5067 = _decs_9060 * 10;
        }
        else{
            _5067 = NewDouble(_decs_9060 * (eudouble)10);
        }
        if (IS_ATOM_INT(_5067)) {
            _5068 = _5067 + _pos_9061;
            if ((object)((uintptr_t)_5068 + (uintptr_t)HIGH_BITS) >= 0){
                _5068 = NewDouble((eudouble)_5068);
            }
        }
        else {
            _5068 = NewDouble(DBL_PTR(_5067)->dbl + (eudouble)_pos_9061);
        }
        DeRef(_5067);
        _5067 = NOVALUE;
        if (IS_ATOM_INT(_5068)) {
            _decs_9060 = _5068 - 1;
        }
        else {
            _decs_9060 = NewDouble(DBL_PTR(_5068)->dbl - (eudouble)1);
        }
        DeRef(_5068);
        _5068 = NOVALUE;
        if (!IS_ATOM_INT(_decs_9060)) {
            _1 = (object)(DBL_PTR(_decs_9060)->dbl);
            DeRefDS(_decs_9060);
            _decs_9060 = _1;
        }

        /** text.e:1566		    			end while*/
        goto LA; // [597] 536
        goto L6; // [600] 1072

        /** text.e:1568		    		case '{' then*/
        case 123:

        /** text.e:1570		    			integer sp*/

        /** text.e:1572		    			sp = i + 1*/
        _sp_9150 = _i_9049 + 1;

        /** text.e:1573		    			i = sp*/
        _i_9049 = _sp_9150;

        /** text.e:1574		    			while i < length(format_pattern) do*/
LC: 
        if (IS_SEQUENCE(_format_pattern_9044)){
                _5071 = SEQ_PTR(_format_pattern_9044)->length;
        }
        else {
            _5071 = 1;
        }
        if (_i_9049 >= _5071)
        goto LD; // [627] 672

        /** text.e:1575		    				if format_pattern[i] = '}' then*/
        _2 = (object)SEQ_PTR(_format_pattern_9044);
        _5073 = (object)*(((s1_ptr)_2)->base + _i_9049);
        if (binary_op_a(NOTEQ, _5073, 125)){
            _5073 = NOVALUE;
            goto LE; // [637] 646
        }
        _5073 = NOVALUE;

        /** text.e:1576		    					exit*/
        goto LD; // [643] 672
LE: 

        /** text.e:1578		    				if format_pattern[i] = ']' then*/
        _2 = (object)SEQ_PTR(_format_pattern_9044);
        _5075 = (object)*(((s1_ptr)_2)->base + _i_9049);
        if (binary_op_a(NOTEQ, _5075, 93)){
            _5075 = NOVALUE;
            goto LF; // [652] 661
        }
        _5075 = NOVALUE;

        /** text.e:1579		    					exit*/
        goto LD; // [658] 672
LF: 

        /** text.e:1581		    				i += 1*/
        _i_9049 = _i_9049 + 1;

        /** text.e:1582		    			end while*/
        goto LC; // [669] 624
LD: 

        /** text.e:1583		    			idname = trim(format_pattern[sp .. i-1]) & '='*/
        _5078 = _i_9049 - 1;
        rhs_slice_target = (object_ptr)&_5079;
        RHS_Slice(_format_pattern_9044, _sp_9150, _5078);
        RefDS(_3871);
        _5080 = _14trim(_5079, _3871, 0);
        _5079 = NOVALUE;
        if (IS_SEQUENCE(_5080) && IS_ATOM(61)) {
            Append(&_idname_9071, _5080, 61);
        }
        else if (IS_ATOM(_5080) && IS_SEQUENCE(61)) {
        }
        else {
            Concat((object_ptr)&_idname_9071, _5080, 61);
            DeRef(_5080);
            _5080 = NOVALUE;
        }
        DeRef(_5080);
        _5080 = NOVALUE;

        /** text.e:1584	    				if format_pattern[i] = ']' then*/
        _2 = (object)SEQ_PTR(_format_pattern_9044);
        _5083 = (object)*(((s1_ptr)_2)->base + _i_9049);
        if (binary_op_a(NOTEQ, _5083, 93)){
            _5083 = NOVALUE;
            goto L10; // [699] 710
        }
        _5083 = NOVALUE;

        /** text.e:1585	    					i -= 1*/
        _i_9049 = _i_9049 - 1;
L10: 

        /** text.e:1588	    				for j = 1 to length(arg_list) do*/
        if (IS_SEQUENCE(_arg_list_9045)){
                _5086 = SEQ_PTR(_arg_list_9045)->length;
        }
        else {
            _5086 = 1;
        }
        {
            object _j_9172;
            _j_9172 = 1;
L11: 
            if (_j_9172 > _5086){
                goto L12; // [715] 797
            }

            /** text.e:1589	    					if sequence(arg_list[j]) then*/
            _2 = (object)SEQ_PTR(_arg_list_9045);
            _5087 = (object)*(((s1_ptr)_2)->base + _j_9172);
            _5088 = IS_SEQUENCE(_5087);
            _5087 = NOVALUE;
            if (_5088 == 0)
            {
                _5088 = NOVALUE;
                goto L13; // [731] 768
            }
            else{
                _5088 = NOVALUE;
            }

            /** text.e:1590	    						if search:begins(idname, arg_list[j]) then*/
            _2 = (object)SEQ_PTR(_arg_list_9045);
            _5089 = (object)*(((s1_ptr)_2)->base + _j_9172);
            RefDS(_idname_9071);
            Ref(_5089);
            _5090 = _16begins(_idname_9071, _5089);
            _5089 = NOVALUE;
            if (_5090 == 0) {
                DeRef(_5090);
                _5090 = NOVALUE;
                goto L14; // [745] 767
            }
            else {
                if (!IS_ATOM_INT(_5090) && DBL_PTR(_5090)->dbl == 0.0){
                    DeRef(_5090);
                    _5090 = NOVALUE;
                    goto L14; // [745] 767
                }
                DeRef(_5090);
                _5090 = NOVALUE;
            }
            DeRef(_5090);
            _5090 = NOVALUE;

            /** text.e:1591	    							if argn = 0 then*/
            if (_argn_9062 != 0)
            goto L15; // [752] 766

            /** text.e:1592	    								argn = j*/
            _argn_9062 = _j_9172;

            /** text.e:1593	    								exit*/
            goto L12; // [763] 797
L15: 
L14: 
L13: 

            /** text.e:1597	    					if j = length(arg_list) then*/
            if (IS_SEQUENCE(_arg_list_9045)){
                    _5092 = SEQ_PTR(_arg_list_9045)->length;
            }
            else {
                _5092 = 1;
            }
            if (_j_9172 != _5092)
            goto L16; // [773] 790

            /** text.e:1598	    						idname = ""*/
            RefDS(_5);
            DeRef(_idname_9071);
            _idname_9071 = _5;

            /** text.e:1599	    						argn = -1*/
            _argn_9062 = -1;
L16: 

            /** text.e:1601	    				end for*/
            _j_9172 = _j_9172 + 1;
            goto L11; // [792] 722
L12: 
            ;
        }
        goto L6; // [799] 1072

        /** text.e:1602		    		case '%' then*/
        case 37:

        /** text.e:1604		    			integer sp*/

        /** text.e:1606		    			sp = i + 1*/
        _sp_9186 = _i_9049 + 1;

        /** text.e:1607		    			i = sp*/
        _i_9049 = _sp_9186;

        /** text.e:1608		    			while i < length(format_pattern) do*/
L17: 
        if (IS_SEQUENCE(_format_pattern_9044)){
                _5095 = SEQ_PTR(_format_pattern_9044)->length;
        }
        else {
            _5095 = 1;
        }
        if (_i_9049 >= _5095)
        goto L18; // [826] 871

        /** text.e:1609		    				if format_pattern[i] = '%' then*/
        _2 = (object)SEQ_PTR(_format_pattern_9044);
        _5097 = (object)*(((s1_ptr)_2)->base + _i_9049);
        if (binary_op_a(NOTEQ, _5097, 37)){
            _5097 = NOVALUE;
            goto L19; // [836] 845
        }
        _5097 = NOVALUE;

        /** text.e:1610		    					exit*/
        goto L18; // [842] 871
L19: 

        /** text.e:1612		    				if format_pattern[i] = ']' then*/
        _2 = (object)SEQ_PTR(_format_pattern_9044);
        _5099 = (object)*(((s1_ptr)_2)->base + _i_9049);
        if (binary_op_a(NOTEQ, _5099, 93)){
            _5099 = NOVALUE;
            goto L1A; // [851] 860
        }
        _5099 = NOVALUE;

        /** text.e:1613		    					exit*/
        goto L18; // [857] 871
L1A: 

        /** text.e:1615		    				i += 1*/
        _i_9049 = _i_9049 + 1;

        /** text.e:1616		    			end while*/
        goto L17; // [868] 823
L18: 

        /** text.e:1617		    			envsym = trim(format_pattern[sp .. i-1])*/
        _5102 = _i_9049 - 1;
        rhs_slice_target = (object_ptr)&_5103;
        RHS_Slice(_format_pattern_9044, _sp_9186, _5102);
        RefDS(_3871);
        _0 = _envsym_9072;
        _envsym_9072 = _14trim(_5103, _3871, 0);
        DeRef(_0);
        _5103 = NOVALUE;

        /** text.e:1618	    				if format_pattern[i] = ']' then*/
        _2 = (object)SEQ_PTR(_format_pattern_9044);
        _5105 = (object)*(((s1_ptr)_2)->base + _i_9049);
        if (binary_op_a(NOTEQ, _5105, 93)){
            _5105 = NOVALUE;
            goto L1B; // [894] 905
        }
        _5105 = NOVALUE;

        /** text.e:1619	    					i -= 1*/
        _i_9049 = _i_9049 - 1;
L1B: 

        /** text.e:1622	    				envvar = getenv(envsym)*/
        DeRefi(_envvar_9073);
        _envvar_9073 = EGetEnv(_envsym_9072);

        /** text.e:1624	    				argn = -1*/
        _argn_9062 = -1;

        /** text.e:1625	    				if atom(envvar) then*/
        _5109 = IS_ATOM(_envvar_9073);
        if (_5109 == 0)
        {
            _5109 = NOVALUE;
            goto L1C; // [920] 929
        }
        else{
            _5109 = NOVALUE;
        }

        /** text.e:1626	    					envvar = ""*/
        RefDS(_5);
        DeRefi(_envvar_9073);
        _envvar_9073 = _5;
L1C: 
        goto L6; // [931] 1072

        /** text.e:1630		    		case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' then*/
        case 48:
        case 49:
        case 50:
        case 51:
        case 52:
        case 53:
        case 54:
        case 55:
        case 56:
        case 57:

        /** text.e:1631		    			if argn = 0 then*/
        if (_argn_9062 != 0)
        goto L6; // [957] 1072

        /** text.e:1632			    			i -= 1*/
        _i_9049 = _i_9049 - 1;

        /** text.e:1633			    			while i < length(format_pattern) do*/
L1D: 
        if (IS_SEQUENCE(_format_pattern_9044)){
                _5112 = SEQ_PTR(_format_pattern_9044)->length;
        }
        else {
            _5112 = 1;
        }
        if (_i_9049 >= _5112)
        goto L6; // [975] 1072

        /** text.e:1634			    				i += 1*/
        _i_9049 = _i_9049 + 1;

        /** text.e:1635			    				tch = format_pattern[i]*/
        _2 = (object)SEQ_PTR(_format_pattern_9044);
        _tch_9048 = (object)*(((s1_ptr)_2)->base + _i_9049);
        if (!IS_ATOM_INT(_tch_9048))
        _tch_9048 = (object)DBL_PTR(_tch_9048)->dbl;

        /** text.e:1636			    				pos = find(tch, "0123456789")*/
        _pos_9061 = find_from(_tch_9048, _5052, 1);

        /** text.e:1637			    				if pos = 0 then*/
        if (_pos_9061 != 0)
        goto L1E; // [1000] 1015

        /** text.e:1638			    					i -= 1*/
        _i_9049 = _i_9049 - 1;

        /** text.e:1639			    					exit*/
        goto L6; // [1012] 1072
L1E: 

        /** text.e:1641			    				argn = argn * 10 + pos - 1*/
        if (_argn_9062 == (short)_argn_9062){
            _5119 = _argn_9062 * 10;
        }
        else{
            _5119 = NewDouble(_argn_9062 * (eudouble)10);
        }
        if (IS_ATOM_INT(_5119)) {
            _5120 = _5119 + _pos_9061;
            if ((object)((uintptr_t)_5120 + (uintptr_t)HIGH_BITS) >= 0){
                _5120 = NewDouble((eudouble)_5120);
            }
        }
        else {
            _5120 = NewDouble(DBL_PTR(_5119)->dbl + (eudouble)_pos_9061);
        }
        DeRef(_5119);
        _5119 = NOVALUE;
        if (IS_ATOM_INT(_5120)) {
            _argn_9062 = _5120 - 1;
        }
        else {
            _argn_9062 = NewDouble(DBL_PTR(_5120)->dbl - (eudouble)1);
        }
        DeRef(_5120);
        _5120 = NOVALUE;
        if (!IS_ATOM_INT(_argn_9062)) {
            _1 = (object)(DBL_PTR(_argn_9062)->dbl);
            DeRefDS(_argn_9062);
            _argn_9062 = _1;
        }

        /** text.e:1642			    			end while*/
        goto L1D; // [1033] 972
        goto L6; // [1037] 1072

        /** text.e:1645		    		case ',' then*/
        case 44:

        /** text.e:1646		    			if i < length(format_pattern) then*/
        if (IS_SEQUENCE(_format_pattern_9044)){
                _5122 = SEQ_PTR(_format_pattern_9044)->length;
        }
        else {
            _5122 = 1;
        }
        if (_i_9049 >= _5122)
        goto L6; // [1048] 1072

        /** text.e:1647		    				i +=1*/
        _i_9049 = _i_9049 + 1;

        /** text.e:1648		    				tsep = format_pattern[i]*/
        _2 = (object)SEQ_PTR(_format_pattern_9044);
        _tsep_9067 = (object)*(((s1_ptr)_2)->base + _i_9049);
        if (!IS_ATOM_INT(_tsep_9067))
        _tsep_9067 = (object)DBL_PTR(_tsep_9067)->dbl;
        goto L6; // [1065] 1072

        /** text.e:1651		    		case else*/
        default:
    ;}L6: 

    /** text.e:1655	    		if tend > 0 then*/
    if (_tend_9050 <= 0)
    goto L1F; // [1074] 3606

    /** text.e:1657	    			sequence argtext = ""*/
    RefDS(_5);
    DeRef(_argtext_9233);
    _argtext_9233 = _5;

    /** text.e:1659	    			if argn = 0 then*/
    if (_argn_9062 != 0)
    goto L20; // [1089] 1100

    /** text.e:1660	    				argn = argl + 1*/
    _argn_9062 = _argl_9063 + 1;
L20: 

    /** text.e:1662	    			argl = argn*/
    _argl_9063 = _argn_9062;

    /** text.e:1664	    			if argn < 1 or argn > length(arg_list) then*/
    _5129 = (_argn_9062 < 1);
    if (_5129 != 0) {
        goto L21; // [1111] 1127
    }
    if (IS_SEQUENCE(_arg_list_9045)){
            _5131 = SEQ_PTR(_arg_list_9045)->length;
    }
    else {
        _5131 = 1;
    }
    _5132 = (_argn_9062 > _5131);
    _5131 = NOVALUE;
    if (_5132 == 0)
    {
        DeRef(_5132);
        _5132 = NOVALUE;
        goto L22; // [1123] 1169
    }
    else{
        DeRef(_5132);
        _5132 = NOVALUE;
    }
L21: 

    /** text.e:1665	    				if length(envvar) > 0 then*/
    if (IS_SEQUENCE(_envvar_9073)){
            _5133 = SEQ_PTR(_envvar_9073)->length;
    }
    else {
        _5133 = 1;
    }
    if (_5133 <= 0)
    goto L23; // [1134] 1153

    /** text.e:1666	    					argtext = envvar*/
    Ref(_envvar_9073);
    DeRef(_argtext_9233);
    _argtext_9233 = _envvar_9073;

    /** text.e:1667		    				currargv = envvar*/
    Ref(_envvar_9073);
    DeRef(_currargv_9070);
    _currargv_9070 = _envvar_9073;
    goto L24; // [1150] 2647
L23: 

    /** text.e:1669	    					argtext = ""*/
    RefDS(_5);
    DeRef(_argtext_9233);
    _argtext_9233 = _5;

    /** text.e:1670		    				currargv =""*/
    RefDS(_5);
    DeRef(_currargv_9070);
    _currargv_9070 = _5;
    goto L24; // [1166] 2647
L22: 

    /** text.e:1673						if string(arg_list[argn]) then*/
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5135 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    Ref(_5135);
    _5136 = _13string(_5135);
    _5135 = NOVALUE;
    if (_5136 == 0) {
        DeRef(_5136);
        _5136 = NOVALUE;
        goto L25; // [1179] 1229
    }
    else {
        if (!IS_ATOM_INT(_5136) && DBL_PTR(_5136)->dbl == 0.0){
            DeRef(_5136);
            _5136 = NOVALUE;
            goto L25; // [1179] 1229
        }
        DeRef(_5136);
        _5136 = NOVALUE;
    }
    DeRef(_5136);
    _5136 = NOVALUE;

    /** text.e:1674							if length(idname) > 0 then*/
    if (IS_SEQUENCE(_idname_9071)){
            _5137 = SEQ_PTR(_idname_9071)->length;
    }
    else {
        _5137 = 1;
    }
    if (_5137 <= 0)
    goto L26; // [1189] 1217

    /** text.e:1675								argtext = arg_list[argn][length(idname) + 1 .. $]*/
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5139 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    if (IS_SEQUENCE(_idname_9071)){
            _5140 = SEQ_PTR(_idname_9071)->length;
    }
    else {
        _5140 = 1;
    }
    _5141 = _5140 + 1;
    _5140 = NOVALUE;
    if (IS_SEQUENCE(_5139)){
            _5142 = SEQ_PTR(_5139)->length;
    }
    else {
        _5142 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_9233;
    RHS_Slice(_5139, _5141, _5142);
    _5139 = NOVALUE;
    goto L27; // [1214] 2640
L26: 

    /** text.e:1677								argtext = arg_list[argn]*/
    DeRef(_argtext_9233);
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _argtext_9233 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    Ref(_argtext_9233);
    goto L27; // [1226] 2640
L25: 

    /** text.e:1680						elsif integer(arg_list[argn]) */
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5145 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    if (IS_ATOM_INT(_5145))
    _5146 = 1;
    else if (IS_ATOM_DBL(_5145))
    _5146 = IS_ATOM_INT(DoubleToInt(_5145));
    else
    _5146 = 0;
    _5145 = NOVALUE;
    if (_5146 == 0) {
        _5147 = 0;
        goto L28; // [1238] 1254
    }
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5148 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    if (IS_ATOM_INT(_5148)) {
        _5150 = (_5148 <= 1073741823);
    }
    else {
        _5150 = binary_op(LESSEQ, _5148, 1073741823);
    }
    _5148 = NOVALUE;
    if (IS_ATOM_INT(_5150))
    _5147 = (_5150 != 0);
    else
    _5147 = DBL_PTR(_5150)->dbl != 0.0;
L28: 
    if (_5147 == 0) {
        goto L29; // [1254] 1812
    }
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5152 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    _5155 = binary_op(GREATEREQ, _5152, _5154);
    _5152 = NOVALUE;
    if (_5155 == 0) {
        DeRef(_5155);
        _5155 = NOVALUE;
        goto L29; // [1267] 1812
    }
    else {
        if (!IS_ATOM_INT(_5155) && DBL_PTR(_5155)->dbl == 0.0){
            DeRef(_5155);
            _5155 = NOVALUE;
            goto L29; // [1267] 1812
        }
        DeRef(_5155);
        _5155 = NOVALUE;
    }
    DeRef(_5155);
    _5155 = NOVALUE;

    /** text.e:1684							if istext then*/
    if (_istext_9068 == 0)
    {
        goto L2A; // [1274] 1298
    }
    else{
    }

    /** text.e:1685								argtext = {and_bits(0xFFFF_FFFF, math:abs(arg_list[argn]))}*/
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5156 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    Ref(_5156);
    _5157 = _20abs(_5156);
    _5156 = NOVALUE;
    _5158 = binary_op(AND_BITS, _390, _5157);
    DeRef(_5157);
    _5157 = NOVALUE;
    _0 = _argtext_9233;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _5158;
    _argtext_9233 = MAKE_SEQ(_1);
    DeRef(_0);
    _5158 = NOVALUE;
    goto L27; // [1295] 2640
L2A: 

    /** text.e:1687							elsif bwz != 0 and arg_list[argn] = 0 then*/
    _5160 = (_bwz_9056 != 0);
    if (_5160 == 0) {
        goto L2B; // [1306] 1333
    }
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5162 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    if (IS_ATOM_INT(_5162)) {
        _5163 = (_5162 == 0);
    }
    else {
        _5163 = binary_op(EQUALS, _5162, 0);
    }
    _5162 = NOVALUE;
    if (_5163 == 0) {
        DeRef(_5163);
        _5163 = NOVALUE;
        goto L2B; // [1319] 1333
    }
    else {
        if (!IS_ATOM_INT(_5163) && DBL_PTR(_5163)->dbl == 0.0){
            DeRef(_5163);
            _5163 = NOVALUE;
            goto L2B; // [1319] 1333
        }
        DeRef(_5163);
        _5163 = NOVALUE;
    }
    DeRef(_5163);
    _5163 = NOVALUE;

    /** text.e:1688								argtext = repeat(' ', width)*/
    DeRef(_argtext_9233);
    _argtext_9233 = Repeat(32, _width_9059);
    goto L27; // [1330] 2640
L2B: 

    /** text.e:1690							elsif binout = 1 then*/
    if (_binout_9066 != 1)
    goto L2C; // [1337] 1476

    /** text.e:1691								argtext = stdseq:reverse( convert:int_to_bits(arg_list[argn], 32)) + '0'*/
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5166 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    Ref(_5166);
    _5167 = _15int_to_bits(_5166, 32);
    _5166 = NOVALUE;
    _5168 = _23reverse(_5167, 1, 0);
    _5167 = NOVALUE;
    DeRef(_argtext_9233);
    if (IS_ATOM_INT(_5168)) {
        _argtext_9233 = _5168 + 48;
        if ((object)((uintptr_t)_argtext_9233 + (uintptr_t)HIGH_BITS) >= 0){
            _argtext_9233 = NewDouble((eudouble)_argtext_9233);
        }
    }
    else {
        _argtext_9233 = binary_op(PLUS, _5168, 48);
    }
    DeRef(_5168);
    _5168 = NOVALUE;

    /** text.e:1692								if zfill != 0 and width > 0 then*/
    _5170 = (_zfill_9055 != 0);
    if (_5170 == 0) {
        goto L2D; // [1372] 1418
    }
    _5172 = (_width_9059 > 0);
    if (_5172 == 0)
    {
        DeRef(_5172);
        _5172 = NOVALUE;
        goto L2D; // [1383] 1418
    }
    else{
        DeRef(_5172);
        _5172 = NOVALUE;
    }

    /** text.e:1693									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5173 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5173 = 1;
    }
    if (_width_9059 <= _5173)
    goto L27; // [1393] 2640

    /** text.e:1694										argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5175 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5175 = 1;
    }
    _5176 = _width_9059 - _5175;
    _5175 = NOVALUE;
    _5177 = Repeat(48, _5176);
    _5176 = NOVALUE;
    Concat((object_ptr)&_argtext_9233, _5177, _argtext_9233);
    DeRefDS(_5177);
    _5177 = NOVALUE;
    DeRef(_5177);
    _5177 = NOVALUE;
    goto L27; // [1415] 2640
L2D: 

    /** text.e:1697									count = 1*/
    _count_9076 = 1;

    /** text.e:1698									while count < length(argtext) and argtext[count] = '0' do*/
L2E: 
    if (IS_SEQUENCE(_argtext_9233)){
            _5179 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5179 = 1;
    }
    _5180 = (_count_9076 < _5179);
    _5179 = NOVALUE;
    if (_5180 == 0) {
        goto L2F; // [1435] 1462
    }
    _2 = (object)SEQ_PTR(_argtext_9233);
    _5182 = (object)*(((s1_ptr)_2)->base + _count_9076);
    if (IS_ATOM_INT(_5182)) {
        _5183 = (_5182 == 48);
    }
    else {
        _5183 = binary_op(EQUALS, _5182, 48);
    }
    _5182 = NOVALUE;
    if (_5183 <= 0) {
        if (_5183 == 0) {
            DeRef(_5183);
            _5183 = NOVALUE;
            goto L2F; // [1448] 1462
        }
        else {
            if (!IS_ATOM_INT(_5183) && DBL_PTR(_5183)->dbl == 0.0){
                DeRef(_5183);
                _5183 = NOVALUE;
                goto L2F; // [1448] 1462
            }
            DeRef(_5183);
            _5183 = NOVALUE;
        }
    }
    DeRef(_5183);
    _5183 = NOVALUE;

    /** text.e:1699										count += 1*/
    _count_9076 = _count_9076 + 1;

    /** text.e:1700									end while*/
    goto L2E; // [1459] 1428
L2F: 

    /** text.e:1701									argtext = argtext[count .. $]*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5185 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5185 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_9233;
    RHS_Slice(_argtext_9233, _count_9076, _5185);
    goto L27; // [1473] 2640
L2C: 

    /** text.e:1704							elsif hexout = 0 then*/
    if (_hexout_9065 != 0)
    goto L30; // [1480] 1746

    /** text.e:1705								argtext = sprintf("%d", arg_list[argn])*/
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5188 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    DeRef(_argtext_9233);
    _argtext_9233 = EPrintf(-9999999, _956, _5188);
    _5188 = NOVALUE;

    /** text.e:1706								if zfill != 0 and width > 0 then*/
    _5190 = (_zfill_9055 != 0);
    if (_5190 == 0) {
        goto L31; // [1502] 1599
    }
    _5192 = (_width_9059 > 0);
    if (_5192 == 0)
    {
        DeRef(_5192);
        _5192 = NOVALUE;
        goto L31; // [1513] 1599
    }
    else{
        DeRef(_5192);
        _5192 = NOVALUE;
    }

    /** text.e:1707									if argtext[1] = '-' then*/
    _2 = (object)SEQ_PTR(_argtext_9233);
    _5193 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5193, 45)){
        _5193 = NOVALUE;
        goto L32; // [1522] 1568
    }
    _5193 = NOVALUE;

    /** text.e:1708										if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5195 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5195 = 1;
    }
    if (_width_9059 <= _5195)
    goto L33; // [1533] 1598

    /** text.e:1709											argtext = '-' & repeat('0', width - length(argtext)) & argtext[2..$]*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5197 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5197 = 1;
    }
    _5198 = _width_9059 - _5197;
    _5197 = NOVALUE;
    _5199 = Repeat(48, _5198);
    _5198 = NOVALUE;
    if (IS_SEQUENCE(_argtext_9233)){
            _5200 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5200 = 1;
    }
    rhs_slice_target = (object_ptr)&_5201;
    RHS_Slice(_argtext_9233, 2, _5200);
    {
        object concat_list[3];

        concat_list[0] = _5201;
        concat_list[1] = _5199;
        concat_list[2] = 45;
        Concat_N((object_ptr)&_argtext_9233, concat_list, 3);
    }
    DeRefDS(_5201);
    _5201 = NOVALUE;
    DeRefDS(_5199);
    _5199 = NOVALUE;
    goto L33; // [1565] 1598
L32: 

    /** text.e:1712										if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5203 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5203 = 1;
    }
    if (_width_9059 <= _5203)
    goto L34; // [1575] 1597

    /** text.e:1713											argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5205 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5205 = 1;
    }
    _5206 = _width_9059 - _5205;
    _5205 = NOVALUE;
    _5207 = Repeat(48, _5206);
    _5206 = NOVALUE;
    Concat((object_ptr)&_argtext_9233, _5207, _argtext_9233);
    DeRefDS(_5207);
    _5207 = NOVALUE;
    DeRef(_5207);
    _5207 = NOVALUE;
L34: 
L33: 
L31: 

    /** text.e:1718								if arg_list[argn] > 0 then*/
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5209 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    if (binary_op_a(LESSEQ, _5209, 0)){
        _5209 = NOVALUE;
        goto L35; // [1605] 1653
    }
    _5209 = NOVALUE;

    /** text.e:1719									if psign then*/
    if (_psign_9053 == 0)
    {
        goto L27; // [1613] 2640
    }
    else{
    }

    /** text.e:1720										if zfill = 0 then*/
    if (_zfill_9055 != 0)
    goto L36; // [1618] 1631

    /** text.e:1721											argtext = '+' & argtext*/
    Prepend(&_argtext_9233, _argtext_9233, 43);
    goto L27; // [1628] 2640
L36: 

    /** text.e:1722										elsif argtext[1] = '0' then*/
    _2 = (object)SEQ_PTR(_argtext_9233);
    _5213 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5213, 48)){
        _5213 = NOVALUE;
        goto L27; // [1637] 2640
    }
    _5213 = NOVALUE;

    /** text.e:1723											argtext[1] = '+'*/
    _2 = (object)SEQ_PTR(_argtext_9233);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _argtext_9233 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 43;
    DeRef(_1);
    goto L27; // [1650] 2640
L35: 

    /** text.e:1726								elsif arg_list[argn] < 0 then*/
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5215 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    if (binary_op_a(GREATEREQ, _5215, 0)){
        _5215 = NOVALUE;
        goto L27; // [1659] 2640
    }
    _5215 = NOVALUE;

    /** text.e:1727									if msign then*/
    if (_msign_9054 == 0)
    {
        goto L27; // [1667] 2640
    }
    else{
    }

    /** text.e:1728										if zfill = 0 then*/
    if (_zfill_9055 != 0)
    goto L37; // [1672] 1695

    /** text.e:1729											argtext = '(' & argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5218 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5218 = 1;
    }
    rhs_slice_target = (object_ptr)&_5219;
    RHS_Slice(_argtext_9233, 2, _5218);
    {
        object concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5219;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_9233, concat_list, 3);
    }
    DeRefDS(_5219);
    _5219 = NOVALUE;
    goto L27; // [1692] 2640
L37: 

    /** text.e:1731											if argtext[2] = '0' then*/
    _2 = (object)SEQ_PTR(_argtext_9233);
    _5222 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _5222, 48)){
        _5222 = NOVALUE;
        goto L38; // [1701] 1724
    }
    _5222 = NOVALUE;

    /** text.e:1732												argtext = '(' & argtext[3..$] & ')'*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5224 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5224 = 1;
    }
    rhs_slice_target = (object_ptr)&_5225;
    RHS_Slice(_argtext_9233, 3, _5224);
    {
        object concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5225;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_9233, concat_list, 3);
    }
    DeRefDS(_5225);
    _5225 = NOVALUE;
    goto L27; // [1721] 2640
L38: 

    /** text.e:1736												argtext = argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5227 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5227 = 1;
    }
    rhs_slice_target = (object_ptr)&_5228;
    RHS_Slice(_argtext_9233, 2, _5227);
    Append(&_argtext_9233, _5228, 41);
    DeRefDS(_5228);
    _5228 = NOVALUE;
    goto L27; // [1743] 2640
L30: 

    /** text.e:1742								argtext = sprintf("%x", arg_list[argn])*/
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5231 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    DeRef(_argtext_9233);
    _argtext_9233 = EPrintf(-9999999, _5230, _5231);
    _5231 = NOVALUE;

    /** text.e:1743								if zfill != 0 and width > 0 then*/
    _5233 = (_zfill_9055 != 0);
    if (_5233 == 0) {
        goto L27; // [1764] 2640
    }
    _5235 = (_width_9059 > 0);
    if (_5235 == 0)
    {
        DeRef(_5235);
        _5235 = NOVALUE;
        goto L27; // [1775] 2640
    }
    else{
        DeRef(_5235);
        _5235 = NOVALUE;
    }

    /** text.e:1744									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5236 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5236 = 1;
    }
    if (_width_9059 <= _5236)
    goto L27; // [1785] 2640

    /** text.e:1745										argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5238 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5238 = 1;
    }
    _5239 = _width_9059 - _5238;
    _5238 = NOVALUE;
    _5240 = Repeat(48, _5239);
    _5239 = NOVALUE;
    Concat((object_ptr)&_argtext_9233, _5240, _argtext_9233);
    DeRefDS(_5240);
    _5240 = NOVALUE;
    DeRef(_5240);
    _5240 = NOVALUE;
    goto L27; // [1809] 2640
L29: 

    /** text.e:1750						elsif atom(arg_list[argn]) then*/
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5242 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    _5243 = IS_ATOM(_5242);
    _5242 = NOVALUE;
    if (_5243 == 0)
    {
        _5243 = NOVALUE;
        goto L39; // [1821] 2224
    }
    else{
        _5243 = NOVALUE;
    }

    /** text.e:1751							if istext then*/
    if (_istext_9068 == 0)
    {
        goto L3A; // [1828] 1855
    }
    else{
    }

    /** text.e:1752								argtext = {and_bits(0xFFFF_FFFF, math:abs(floor(arg_list[argn])))}*/
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5244 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    if (IS_ATOM_INT(_5244))
    _5245 = e_floor(_5244);
    else
    _5245 = unary_op(FLOOR, _5244);
    _5244 = NOVALUE;
    _5246 = _20abs(_5245);
    _5245 = NOVALUE;
    _5247 = binary_op(AND_BITS, _390, _5246);
    DeRef(_5246);
    _5246 = NOVALUE;
    _0 = _argtext_9233;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _5247;
    _argtext_9233 = MAKE_SEQ(_1);
    DeRef(_0);
    _5247 = NOVALUE;
    goto L27; // [1852] 2640
L3A: 

    /** text.e:1755								if hexout then*/
    if (_hexout_9065 == 0)
    {
        goto L3B; // [1859] 1927
    }
    else{
    }

    /** text.e:1756									argtext = sprintf("%x", arg_list[argn])*/
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5249 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    DeRef(_argtext_9233);
    _argtext_9233 = EPrintf(-9999999, _5230, _5249);
    _5249 = NOVALUE;

    /** text.e:1757									if zfill != 0 and width > 0 then*/
    _5251 = (_zfill_9055 != 0);
    if (_5251 == 0) {
        goto L27; // [1880] 2640
    }
    _5253 = (_width_9059 > 0);
    if (_5253 == 0)
    {
        DeRef(_5253);
        _5253 = NOVALUE;
        goto L27; // [1891] 2640
    }
    else{
        DeRef(_5253);
        _5253 = NOVALUE;
    }

    /** text.e:1758										if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5254 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5254 = 1;
    }
    if (_width_9059 <= _5254)
    goto L27; // [1901] 2640

    /** text.e:1759											argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5256 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5256 = 1;
    }
    _5257 = _width_9059 - _5256;
    _5256 = NOVALUE;
    _5258 = Repeat(48, _5257);
    _5257 = NOVALUE;
    Concat((object_ptr)&_argtext_9233, _5258, _argtext_9233);
    DeRefDS(_5258);
    _5258 = NOVALUE;
    DeRef(_5258);
    _5258 = NOVALUE;
    goto L27; // [1924] 2640
L3B: 

    /** text.e:1763									argtext = trim(sprintf("%15.15g", arg_list[argn]))*/
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5261 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    _5262 = EPrintf(-9999999, _5260, _5261);
    _5261 = NOVALUE;
    RefDS(_3871);
    _0 = _argtext_9233;
    _argtext_9233 = _14trim(_5262, _3871, 0);
    DeRef(_0);
    _5262 = NOVALUE;

    /** text.e:1765									while ep != 0 with entry do*/
    goto L3C; // [1947] 1970
L3D: 
    if (_ep_9074 == 0)
    goto L3E; // [1952] 1982

    /** text.e:1766										argtext = remove(argtext, ep+2)*/
    _5265 = _ep_9074 + 2;
    if ((object)((uintptr_t)_5265 + (uintptr_t)HIGH_BITS) >= 0){
        _5265 = NewDouble((eudouble)_5265);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_argtext_9233);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_5265)) ? _5265 : (object)(DBL_PTR(_5265)->dbl);
        int stop = (IS_ATOM_INT(_5265)) ? _5265 : (object)(DBL_PTR(_5265)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_argtext_9233), start, &_argtext_9233 );
            }
            else Tail(SEQ_PTR(_argtext_9233), stop+1, &_argtext_9233);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_argtext_9233), start, &_argtext_9233);
        }
        else {
            assign_slice_seq = &assign_space;
            _argtext_9233 = Remove_elements(start, stop, (SEQ_PTR(_argtext_9233)->ref == 1));
        }
    }
    DeRef(_5265);
    _5265 = NOVALUE;
    _5265 = NOVALUE;

    /** text.e:1767									entry*/
L3C: 

    /** text.e:1768										ep = match("e+0", argtext)*/
    _ep_9074 = e_match_from(_5267, _argtext_9233, 1);

    /** text.e:1769									end while*/
    goto L3D; // [1979] 1950
L3E: 

    /** text.e:1770									if zfill != 0 and width > 0 then*/
    _5269 = (_zfill_9055 != 0);
    if (_5269 == 0) {
        goto L3F; // [1990] 2075
    }
    _5271 = (_width_9059 > 0);
    if (_5271 == 0)
    {
        DeRef(_5271);
        _5271 = NOVALUE;
        goto L3F; // [2001] 2075
    }
    else{
        DeRef(_5271);
        _5271 = NOVALUE;
    }

    /** text.e:1771										if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5272 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5272 = 1;
    }
    if (_width_9059 <= _5272)
    goto L40; // [2011] 2074

    /** text.e:1772											if argtext[1] = '-' then*/
    _2 = (object)SEQ_PTR(_argtext_9233);
    _5274 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5274, 45)){
        _5274 = NOVALUE;
        goto L41; // [2021] 2055
    }
    _5274 = NOVALUE;

    /** text.e:1773												argtext = '-' & repeat('0', width - length(argtext)) & argtext[2..$]*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5276 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5276 = 1;
    }
    _5277 = _width_9059 - _5276;
    _5276 = NOVALUE;
    _5278 = Repeat(48, _5277);
    _5277 = NOVALUE;
    if (IS_SEQUENCE(_argtext_9233)){
            _5279 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5279 = 1;
    }
    rhs_slice_target = (object_ptr)&_5280;
    RHS_Slice(_argtext_9233, 2, _5279);
    {
        object concat_list[3];

        concat_list[0] = _5280;
        concat_list[1] = _5278;
        concat_list[2] = 45;
        Concat_N((object_ptr)&_argtext_9233, concat_list, 3);
    }
    DeRefDS(_5280);
    _5280 = NOVALUE;
    DeRefDS(_5278);
    _5278 = NOVALUE;
    goto L42; // [2052] 2073
L41: 

    /** text.e:1775												argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5282 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5282 = 1;
    }
    _5283 = _width_9059 - _5282;
    _5282 = NOVALUE;
    _5284 = Repeat(48, _5283);
    _5283 = NOVALUE;
    Concat((object_ptr)&_argtext_9233, _5284, _argtext_9233);
    DeRefDS(_5284);
    _5284 = NOVALUE;
    DeRef(_5284);
    _5284 = NOVALUE;
L42: 
L40: 
L3F: 

    /** text.e:1779									if arg_list[argn] > 0 then*/
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5286 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    if (binary_op_a(LESSEQ, _5286, 0)){
        _5286 = NOVALUE;
        goto L43; // [2081] 2129
    }
    _5286 = NOVALUE;

    /** text.e:1780										if psign  then*/
    if (_psign_9053 == 0)
    {
        goto L27; // [2089] 2640
    }
    else{
    }

    /** text.e:1781											if zfill = 0 then*/
    if (_zfill_9055 != 0)
    goto L44; // [2094] 2107

    /** text.e:1782												argtext = '+' & argtext*/
    Prepend(&_argtext_9233, _argtext_9233, 43);
    goto L27; // [2104] 2640
L44: 

    /** text.e:1783											elsif argtext[1] = '0' then*/
    _2 = (object)SEQ_PTR(_argtext_9233);
    _5290 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5290, 48)){
        _5290 = NOVALUE;
        goto L27; // [2113] 2640
    }
    _5290 = NOVALUE;

    /** text.e:1784												argtext[1] = '+'*/
    _2 = (object)SEQ_PTR(_argtext_9233);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _argtext_9233 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 43;
    DeRef(_1);
    goto L27; // [2126] 2640
L43: 

    /** text.e:1787									elsif arg_list[argn] < 0 then*/
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5292 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    if (binary_op_a(GREATEREQ, _5292, 0)){
        _5292 = NOVALUE;
        goto L27; // [2135] 2640
    }
    _5292 = NOVALUE;

    /** text.e:1788										if msign then*/
    if (_msign_9054 == 0)
    {
        goto L27; // [2143] 2640
    }
    else{
    }

    /** text.e:1789											if zfill = 0 then*/
    if (_zfill_9055 != 0)
    goto L45; // [2148] 2171

    /** text.e:1790												argtext = '(' & argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5295 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5295 = 1;
    }
    rhs_slice_target = (object_ptr)&_5296;
    RHS_Slice(_argtext_9233, 2, _5295);
    {
        object concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5296;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_9233, concat_list, 3);
    }
    DeRefDS(_5296);
    _5296 = NOVALUE;
    goto L27; // [2168] 2640
L45: 

    /** text.e:1792												if argtext[2] = '0' then*/
    _2 = (object)SEQ_PTR(_argtext_9233);
    _5298 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _5298, 48)){
        _5298 = NOVALUE;
        goto L46; // [2177] 2200
    }
    _5298 = NOVALUE;

    /** text.e:1793													argtext = '(' & argtext[3..$] & ')'*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5300 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5300 = 1;
    }
    rhs_slice_target = (object_ptr)&_5301;
    RHS_Slice(_argtext_9233, 3, _5300);
    {
        object concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5301;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_9233, concat_list, 3);
    }
    DeRefDS(_5301);
    _5301 = NOVALUE;
    goto L27; // [2197] 2640
L46: 

    /** text.e:1795													argtext = argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5303 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5303 = 1;
    }
    rhs_slice_target = (object_ptr)&_5304;
    RHS_Slice(_argtext_9233, 2, _5303);
    Append(&_argtext_9233, _5304, 41);
    DeRefDS(_5304);
    _5304 = NOVALUE;
    goto L27; // [2221] 2640
L39: 

    /** text.e:1804							if alt != 0 and length(arg_list[argn]) = 2 then*/
    _5306 = (_alt_9058 != 0);
    if (_5306 == 0) {
        goto L47; // [2232] 2551
    }
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5308 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    if (IS_SEQUENCE(_5308)){
            _5309 = SEQ_PTR(_5308)->length;
    }
    else {
        _5309 = 1;
    }
    _5308 = NOVALUE;
    _5310 = (_5309 == 2);
    _5309 = NOVALUE;
    if (_5310 == 0)
    {
        DeRef(_5310);
        _5310 = NOVALUE;
        goto L47; // [2248] 2551
    }
    else{
        DeRef(_5310);
        _5310 = NOVALUE;
    }

    /** text.e:1805								object tempv*/

    /** text.e:1806								if atom(prevargv) then*/
    _5311 = IS_ATOM(_prevargv_9069);
    if (_5311 == 0)
    {
        _5311 = NOVALUE;
        goto L48; // [2258] 2294
    }
    else{
        _5311 = NOVALUE;
    }

    /** text.e:1807									if prevargv != 1 then*/
    if (binary_op_a(EQUALS, _prevargv_9069, 1)){
        goto L49; // [2263] 2280
    }

    /** text.e:1808										tempv = arg_list[argn][1]*/
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5313 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    DeRef(_tempv_9478);
    _2 = (object)SEQ_PTR(_5313);
    _tempv_9478 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_tempv_9478);
    _5313 = NOVALUE;
    goto L4A; // [2277] 2328
L49: 

    /** text.e:1810										tempv = arg_list[argn][2]*/
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5315 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    DeRef(_tempv_9478);
    _2 = (object)SEQ_PTR(_5315);
    _tempv_9478 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tempv_9478);
    _5315 = NOVALUE;
    goto L4A; // [2291] 2328
L48: 

    /** text.e:1813									if length(prevargv) = 0 then*/
    if (IS_SEQUENCE(_prevargv_9069)){
            _5317 = SEQ_PTR(_prevargv_9069)->length;
    }
    else {
        _5317 = 1;
    }
    if (_5317 != 0)
    goto L4B; // [2299] 2316

    /** text.e:1814										tempv = arg_list[argn][1]*/
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5319 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    DeRef(_tempv_9478);
    _2 = (object)SEQ_PTR(_5319);
    _tempv_9478 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_tempv_9478);
    _5319 = NOVALUE;
    goto L4C; // [2313] 2327
L4B: 

    /** text.e:1816										tempv = arg_list[argn][2]*/
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5321 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    DeRef(_tempv_9478);
    _2 = (object)SEQ_PTR(_5321);
    _tempv_9478 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tempv_9478);
    _5321 = NOVALUE;
L4C: 
L4A: 

    /** text.e:1820								if string(tempv) then*/
    Ref(_tempv_9478);
    _5323 = _13string(_tempv_9478);
    if (_5323 == 0) {
        DeRef(_5323);
        _5323 = NOVALUE;
        goto L4D; // [2336] 2349
    }
    else {
        if (!IS_ATOM_INT(_5323) && DBL_PTR(_5323)->dbl == 0.0){
            DeRef(_5323);
            _5323 = NOVALUE;
            goto L4D; // [2336] 2349
        }
        DeRef(_5323);
        _5323 = NOVALUE;
    }
    DeRef(_5323);
    _5323 = NOVALUE;

    /** text.e:1821									argtext = tempv*/
    Ref(_tempv_9478);
    DeRef(_argtext_9233);
    _argtext_9233 = _tempv_9478;
    goto L4E; // [2346] 2546
L4D: 

    /** text.e:1822								elsif integer(tempv) then*/
    if (IS_ATOM_INT(_tempv_9478))
    _5324 = 1;
    else if (IS_ATOM_DBL(_tempv_9478))
    _5324 = IS_ATOM_INT(DoubleToInt(_tempv_9478));
    else
    _5324 = 0;
    if (_5324 == 0)
    {
        _5324 = NOVALUE;
        goto L4F; // [2354] 2420
    }
    else{
        _5324 = NOVALUE;
    }

    /** text.e:1823									if istext then*/
    if (_istext_9068 == 0)
    {
        goto L50; // [2359] 2379
    }
    else{
    }

    /** text.e:1824										argtext = {and_bits(0xFFFF_FFFF, math:abs(tempv))}*/
    Ref(_tempv_9478);
    _5325 = _20abs(_tempv_9478);
    _5326 = binary_op(AND_BITS, _390, _5325);
    DeRef(_5325);
    _5325 = NOVALUE;
    _0 = _argtext_9233;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _5326;
    _argtext_9233 = MAKE_SEQ(_1);
    DeRef(_0);
    _5326 = NOVALUE;
    goto L4E; // [2376] 2546
L50: 

    /** text.e:1826									elsif bwz != 0 and tempv = 0 then*/
    _5328 = (_bwz_9056 != 0);
    if (_5328 == 0) {
        goto L51; // [2387] 2410
    }
    if (IS_ATOM_INT(_tempv_9478)) {
        _5330 = (_tempv_9478 == 0);
    }
    else {
        _5330 = binary_op(EQUALS, _tempv_9478, 0);
    }
    if (_5330 == 0) {
        DeRef(_5330);
        _5330 = NOVALUE;
        goto L51; // [2396] 2410
    }
    else {
        if (!IS_ATOM_INT(_5330) && DBL_PTR(_5330)->dbl == 0.0){
            DeRef(_5330);
            _5330 = NOVALUE;
            goto L51; // [2396] 2410
        }
        DeRef(_5330);
        _5330 = NOVALUE;
    }
    DeRef(_5330);
    _5330 = NOVALUE;

    /** text.e:1827										argtext = repeat(' ', width)*/
    DeRef(_argtext_9233);
    _argtext_9233 = Repeat(32, _width_9059);
    goto L4E; // [2407] 2546
L51: 

    /** text.e:1829										argtext = sprintf("%d", tempv)*/
    DeRef(_argtext_9233);
    _argtext_9233 = EPrintf(-9999999, _956, _tempv_9478);
    goto L4E; // [2417] 2546
L4F: 

    /** text.e:1832								elsif atom(tempv) then*/
    _5333 = IS_ATOM(_tempv_9478);
    if (_5333 == 0)
    {
        _5333 = NOVALUE;
        goto L52; // [2425] 2502
    }
    else{
        _5333 = NOVALUE;
    }

    /** text.e:1833									if istext then*/
    if (_istext_9068 == 0)
    {
        goto L53; // [2430] 2453
    }
    else{
    }

    /** text.e:1834										argtext = {and_bits(0xFFFF_FFFF, math:abs(floor(tempv)))}*/
    if (IS_ATOM_INT(_tempv_9478))
    _5334 = e_floor(_tempv_9478);
    else
    _5334 = unary_op(FLOOR, _tempv_9478);
    _5335 = _20abs(_5334);
    _5334 = NOVALUE;
    _5336 = binary_op(AND_BITS, _390, _5335);
    DeRef(_5335);
    _5335 = NOVALUE;
    _0 = _argtext_9233;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _5336;
    _argtext_9233 = MAKE_SEQ(_1);
    DeRef(_0);
    _5336 = NOVALUE;
    goto L4E; // [2450] 2546
L53: 

    /** text.e:1835									elsif bwz != 0 and tempv = 0 then*/
    _5338 = (_bwz_9056 != 0);
    if (_5338 == 0) {
        goto L54; // [2461] 2484
    }
    if (IS_ATOM_INT(_tempv_9478)) {
        _5340 = (_tempv_9478 == 0);
    }
    else {
        _5340 = binary_op(EQUALS, _tempv_9478, 0);
    }
    if (_5340 == 0) {
        DeRef(_5340);
        _5340 = NOVALUE;
        goto L54; // [2470] 2484
    }
    else {
        if (!IS_ATOM_INT(_5340) && DBL_PTR(_5340)->dbl == 0.0){
            DeRef(_5340);
            _5340 = NOVALUE;
            goto L54; // [2470] 2484
        }
        DeRef(_5340);
        _5340 = NOVALUE;
    }
    DeRef(_5340);
    _5340 = NOVALUE;

    /** text.e:1836										argtext = repeat(' ', width)*/
    DeRef(_argtext_9233);
    _argtext_9233 = Repeat(32, _width_9059);
    goto L4E; // [2481] 2546
L54: 

    /** text.e:1838										argtext = trim(sprintf("%15.15g", tempv))*/
    _5342 = EPrintf(-9999999, _5260, _tempv_9478);
    RefDS(_3871);
    _0 = _argtext_9233;
    _argtext_9233 = _14trim(_5342, _3871, 0);
    DeRef(_0);
    _5342 = NOVALUE;
    goto L4E; // [2499] 2546
L52: 

    /** text.e:1841									argtext = pretty:pretty_sprint( tempv,*/
    _1 = NewS1(10);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 1;
    ((intptr_t*)_2)[4] = 1000;
    RefDS(_956);
    ((intptr_t*)_2)[5] = _956;
    RefDS(_5344);
    ((intptr_t*)_2)[6] = _5344;
    ((intptr_t*)_2)[7] = 32;
    ((intptr_t*)_2)[8] = 127;
    ((intptr_t*)_2)[9] = 1;
    ((intptr_t*)_2)[10] = 0;
    _5345 = MAKE_SEQ(_1);
    DeRef(_options_inlined_pretty_sprint_at_2518_9532);
    _options_inlined_pretty_sprint_at_2518_9532 = _5345;
    _5345 = NOVALUE;

    /** pretty.e:364		pretty_printing = 0*/
    _26pretty_printing_7550 = 0;

    /** pretty.e:365		pretty( x, options )*/
    Ref(_tempv_9478);
    RefDS(_options_inlined_pretty_sprint_at_2518_9532);
    _26pretty(_tempv_9478, _options_inlined_pretty_sprint_at_2518_9532);

    /** pretty.e:366		return pretty_line*/
    RefDS(_26pretty_line_7553);
    DeRef(_argtext_9233);
    _argtext_9233 = _26pretty_line_7553;
    DeRef(_options_inlined_pretty_sprint_at_2518_9532);
    _options_inlined_pretty_sprint_at_2518_9532 = NOVALUE;
L4E: 
    DeRef(_tempv_9478);
    _tempv_9478 = NOVALUE;
    goto L55; // [2548] 2627
L47: 

    /** text.e:1846								argtext = pretty:pretty_sprint( arg_list[argn],*/
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _5346 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    _1 = NewS1(10);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 1;
    ((intptr_t*)_2)[4] = 1000;
    RefDS(_956);
    ((intptr_t*)_2)[5] = _956;
    RefDS(_5344);
    ((intptr_t*)_2)[6] = _5344;
    ((intptr_t*)_2)[7] = 32;
    ((intptr_t*)_2)[8] = 127;
    ((intptr_t*)_2)[9] = 1;
    ((intptr_t*)_2)[10] = 0;
    _5347 = MAKE_SEQ(_1);
    Ref(_5346);
    DeRef(_x_inlined_pretty_sprint_at_2571_9538);
    _x_inlined_pretty_sprint_at_2571_9538 = _5346;
    _5346 = NOVALUE;
    DeRef(_options_inlined_pretty_sprint_at_2574_9539);
    _options_inlined_pretty_sprint_at_2574_9539 = _5347;
    _5347 = NOVALUE;

    /** pretty.e:364		pretty_printing = 0*/
    _26pretty_printing_7550 = 0;

    /** pretty.e:365		pretty( x, options )*/
    Ref(_x_inlined_pretty_sprint_at_2571_9538);
    RefDS(_options_inlined_pretty_sprint_at_2574_9539);
    _26pretty(_x_inlined_pretty_sprint_at_2571_9538, _options_inlined_pretty_sprint_at_2574_9539);

    /** pretty.e:366		return pretty_line*/
    RefDS(_26pretty_line_7553);
    DeRef(_argtext_9233);
    _argtext_9233 = _26pretty_line_7553;
    DeRef(_x_inlined_pretty_sprint_at_2571_9538);
    _x_inlined_pretty_sprint_at_2571_9538 = NOVALUE;
    DeRef(_options_inlined_pretty_sprint_at_2574_9539);
    _options_inlined_pretty_sprint_at_2574_9539 = NOVALUE;

    /** text.e:1851							while ep != 0 with entry do*/
    goto L55; // [2604] 2627
L56: 
    if (_ep_9074 == 0)
    goto L57; // [2609] 2639

    /** text.e:1852								argtext = remove(argtext, ep+2)*/
    _5349 = _ep_9074 + 2;
    if ((object)((uintptr_t)_5349 + (uintptr_t)HIGH_BITS) >= 0){
        _5349 = NewDouble((eudouble)_5349);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_argtext_9233);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_5349)) ? _5349 : (object)(DBL_PTR(_5349)->dbl);
        int stop = (IS_ATOM_INT(_5349)) ? _5349 : (object)(DBL_PTR(_5349)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_argtext_9233), start, &_argtext_9233 );
            }
            else Tail(SEQ_PTR(_argtext_9233), stop+1, &_argtext_9233);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_argtext_9233), start, &_argtext_9233);
        }
        else {
            assign_slice_seq = &assign_space;
            _argtext_9233 = Remove_elements(start, stop, (SEQ_PTR(_argtext_9233)->ref == 1));
        }
    }
    DeRef(_5349);
    _5349 = NOVALUE;
    _5349 = NOVALUE;

    /** text.e:1853							entry*/
L55: 

    /** text.e:1854								ep = match("e+0", argtext)*/
    _ep_9074 = e_match_from(_5267, _argtext_9233, 1);

    /** text.e:1855							end while*/
    goto L56; // [2636] 2607
L57: 
L27: 

    /** text.e:1857		    			currargv = arg_list[argn]*/
    DeRef(_currargv_9070);
    _2 = (object)SEQ_PTR(_arg_list_9045);
    _currargv_9070 = (object)*(((s1_ptr)_2)->base + _argn_9062);
    Ref(_currargv_9070);
L24: 

    /** text.e:1861	    			if length(argtext) > 0 then*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5353 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5353 = 1;
    }
    if (_5353 <= 0)
    goto L58; // [2652] 3562

    /** text.e:1862	    				switch cap do*/
    _0 = _cap_9051;
    switch ( _0 ){ 

        /** text.e:1863	    					case 'u' then*/
        case 117:

        /** text.e:1864	    						argtext = upper(argtext)*/
        RefDS(_argtext_9233);
        _0 = _argtext_9233;
        _argtext_9233 = _14upper(_argtext_9233);
        DeRefDS(_0);
        goto L59; // [2677] 2743

        /** text.e:1865	    					case 'l' then*/
        case 108:

        /** text.e:1866	    						argtext = lower(argtext)*/
        RefDS(_argtext_9233);
        _0 = _argtext_9233;
        _argtext_9233 = _14lower(_argtext_9233);
        DeRefDS(_0);
        goto L59; // [2691] 2743

        /** text.e:1867	    					case 'w' then*/
        case 119:

        /** text.e:1868	    						argtext = proper(argtext)*/
        RefDS(_argtext_9233);
        _0 = _argtext_9233;
        _argtext_9233 = _14proper(_argtext_9233);
        DeRefDS(_0);
        goto L59; // [2705] 2743

        /** text.e:1869	    					case 0 then*/
        case 0:

        /** text.e:1871								cap = cap*/
        _cap_9051 = _cap_9051;
        goto L59; // [2716] 2743

        /** text.e:1873	    					case else*/
        default:

        /** text.e:1874	    						error:crash("logic error: 'cap' mode in format.")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_2725_9562);
        _msg_inlined_crash_at_2725_9562 = EPrintf(-9999999, _5360, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_2725_9562);

        /** error.e:53	end procedure*/
        goto L5A; // [2737] 2740
L5A: 
        DeRefi(_msg_inlined_crash_at_2725_9562);
        _msg_inlined_crash_at_2725_9562 = NOVALUE;
    ;}L59: 

    /** text.e:1878						if atom(currargv) then*/
    _5361 = IS_ATOM(_currargv_9070);
    if (_5361 == 0)
    {
        _5361 = NOVALUE;
        goto L5B; // [2750] 2993
    }
    else{
        _5361 = NOVALUE;
    }

    /** text.e:1879							if find('e', argtext) = 0 then*/
    _5362 = find_from(101, _argtext_9233, 1);
    if (_5362 != 0)
    goto L5C; // [2760] 2992

    /** text.e:1881								pflag = 0*/
    _pflag_9075 = 0;

    /** text.e:1882								if msign and currargv < 0 then*/
    if (_msign_9054 == 0) {
        goto L5D; // [2773] 2791
    }
    if (IS_ATOM_INT(_currargv_9070)) {
        _5365 = (_currargv_9070 < 0);
    }
    else {
        _5365 = binary_op(LESS, _currargv_9070, 0);
    }
    if (_5365 == 0) {
        DeRef(_5365);
        _5365 = NOVALUE;
        goto L5D; // [2782] 2791
    }
    else {
        if (!IS_ATOM_INT(_5365) && DBL_PTR(_5365)->dbl == 0.0){
            DeRef(_5365);
            _5365 = NOVALUE;
            goto L5D; // [2782] 2791
        }
        DeRef(_5365);
        _5365 = NOVALUE;
    }
    DeRef(_5365);
    _5365 = NOVALUE;

    /** text.e:1883									pflag = 1*/
    _pflag_9075 = 1;
L5D: 

    /** text.e:1885								if decs != -1 then*/
    if (_decs_9060 == -1)
    goto L5E; // [2795] 2991

    /** text.e:1886									pos = find('.', argtext)*/
    _pos_9061 = find_from(46, _argtext_9233, 1);

    /** text.e:1887									if pos then*/
    if (_pos_9061 == 0)
    {
        goto L5F; // [2808] 2936
    }
    else{
    }

    /** text.e:1888										if decs = 0 then*/
    if (_decs_9060 != 0)
    goto L60; // [2813] 2831

    /** text.e:1889											argtext = argtext [1 .. pos-1 ]*/
    _5369 = _pos_9061 - 1;
    rhs_slice_target = (object_ptr)&_argtext_9233;
    RHS_Slice(_argtext_9233, 1, _5369);
    goto L61; // [2828] 2990
L60: 

    /** text.e:1891											pos = length(argtext) - pos - pflag*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5371 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5371 = 1;
    }
    _5372 = _5371 - _pos_9061;
    if ((object)((uintptr_t)_5372 +(uintptr_t) HIGH_BITS) >= 0){
        _5372 = NewDouble((eudouble)_5372);
    }
    _5371 = NOVALUE;
    if (IS_ATOM_INT(_5372)) {
        _pos_9061 = _5372 - _pflag_9075;
    }
    else {
        _pos_9061 = NewDouble(DBL_PTR(_5372)->dbl - (eudouble)_pflag_9075);
    }
    DeRef(_5372);
    _5372 = NOVALUE;
    if (!IS_ATOM_INT(_pos_9061)) {
        _1 = (object)(DBL_PTR(_pos_9061)->dbl);
        DeRefDS(_pos_9061);
        _pos_9061 = _1;
    }

    /** text.e:1892											if pos > decs then*/
    if (_pos_9061 <= _decs_9060)
    goto L62; // [2848] 2873

    /** text.e:1893												argtext = argtext[ 1 .. $ - pos + decs ]*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5375 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5375 = 1;
    }
    _5376 = _5375 - _pos_9061;
    if ((object)((uintptr_t)_5376 +(uintptr_t) HIGH_BITS) >= 0){
        _5376 = NewDouble((eudouble)_5376);
    }
    _5375 = NOVALUE;
    if (IS_ATOM_INT(_5376)) {
        _5377 = _5376 + _decs_9060;
    }
    else {
        _5377 = NewDouble(DBL_PTR(_5376)->dbl + (eudouble)_decs_9060);
    }
    DeRef(_5376);
    _5376 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_9233;
    RHS_Slice(_argtext_9233, 1, _5377);
    goto L61; // [2870] 2990
L62: 

    /** text.e:1894											elsif pos < decs then*/
    if (_pos_9061 >= _decs_9060)
    goto L61; // [2875] 2990

    /** text.e:1895												if pflag then*/
    if (_pflag_9075 == 0)
    {
        goto L63; // [2881] 2915
    }
    else{
    }

    /** text.e:1896													argtext = argtext[ 1 .. $ - 1 ] & repeat('0', decs - pos) & ')'*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5380 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5380 = 1;
    }
    _5381 = _5380 - 1;
    _5380 = NOVALUE;
    rhs_slice_target = (object_ptr)&_5382;
    RHS_Slice(_argtext_9233, 1, _5381);
    _5383 = _decs_9060 - _pos_9061;
    _5384 = Repeat(48, _5383);
    _5383 = NOVALUE;
    {
        object concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5384;
        concat_list[2] = _5382;
        Concat_N((object_ptr)&_argtext_9233, concat_list, 3);
    }
    DeRefDS(_5384);
    _5384 = NOVALUE;
    DeRefDS(_5382);
    _5382 = NOVALUE;
    goto L61; // [2912] 2990
L63: 

    /** text.e:1898													argtext = argtext & repeat('0', decs - pos)*/
    _5386 = _decs_9060 - _pos_9061;
    _5387 = Repeat(48, _5386);
    _5386 = NOVALUE;
    Concat((object_ptr)&_argtext_9233, _argtext_9233, _5387);
    DeRefDS(_5387);
    _5387 = NOVALUE;
    goto L61; // [2933] 2990
L5F: 

    /** text.e:1902									elsif decs > 0 then*/
    if (_decs_9060 <= 0)
    goto L64; // [2938] 2989

    /** text.e:1903										if pflag then*/
    if (_pflag_9075 == 0)
    {
        goto L65; // [2944] 2975
    }
    else{
    }

    /** text.e:1904											argtext = argtext[1 .. $ - 1] & '.' & repeat('0', decs) & ')'*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5390 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5390 = 1;
    }
    _5391 = _5390 - 1;
    _5390 = NOVALUE;
    rhs_slice_target = (object_ptr)&_5392;
    RHS_Slice(_argtext_9233, 1, _5391);
    _5393 = Repeat(48, _decs_9060);
    {
        object concat_list[4];

        concat_list[0] = 41;
        concat_list[1] = _5393;
        concat_list[2] = 46;
        concat_list[3] = _5392;
        Concat_N((object_ptr)&_argtext_9233, concat_list, 4);
    }
    DeRefDS(_5393);
    _5393 = NOVALUE;
    DeRefDS(_5392);
    _5392 = NOVALUE;
    goto L66; // [2972] 2988
L65: 

    /** text.e:1906											argtext = argtext & '.' & repeat('0', decs)*/
    _5395 = Repeat(48, _decs_9060);
    {
        object concat_list[3];

        concat_list[0] = _5395;
        concat_list[1] = 46;
        concat_list[2] = _argtext_9233;
        Concat_N((object_ptr)&_argtext_9233, concat_list, 3);
    }
    DeRefDS(_5395);
    _5395 = NOVALUE;
L66: 
L64: 
L61: 
L5E: 
L5C: 
L5B: 

    /** text.e:1914	    				if align = 0 then*/
    if (_align_9052 != 0)
    goto L67; // [2997] 3024

    /** text.e:1915	    					if atom(currargv) then*/
    _5398 = IS_ATOM(_currargv_9070);
    if (_5398 == 0)
    {
        _5398 = NOVALUE;
        goto L68; // [3006] 3017
    }
    else{
        _5398 = NOVALUE;
    }

    /** text.e:1916	    						align = '>'*/
    _align_9052 = 62;
    goto L69; // [3014] 3023
L68: 

    /** text.e:1918	    						align = '<'*/
    _align_9052 = 60;
L69: 
L67: 

    /** text.e:1922	    				if atom(currargv) then*/
    _5399 = IS_ATOM(_currargv_9070);
    if (_5399 == 0)
    {
        _5399 = NOVALUE;
        goto L6A; // [3029] 3266
    }
    else{
        _5399 = NOVALUE;
    }

    /** text.e:1923		    				if tsep != 0 and zfill = 0 then*/
    _5400 = (_tsep_9067 != 0);
    if (_5400 == 0) {
        goto L6B; // [3040] 3263
    }
    _5402 = (_zfill_9055 == 0);
    if (_5402 == 0)
    {
        DeRef(_5402);
        _5402 = NOVALUE;
        goto L6B; // [3051] 3263
    }
    else{
        DeRef(_5402);
        _5402 = NOVALUE;
    }

    /** text.e:1924		    					integer dpos*/

    /** text.e:1925		    					integer dist*/

    /** text.e:1926		    					integer bracketed*/

    /** text.e:1928		    					if binout or hexout then*/
    if (_binout_9066 != 0) {
        goto L6C; // [3064] 3073
    }
    if (_hexout_9065 == 0)
    {
        goto L6D; // [3069] 3086
    }
    else{
    }
L6C: 

    /** text.e:1929		    						dist = 4*/
    _dist_9625 = 4;

    /** text.e:1930								psign = 0*/
    _psign_9053 = 0;
    goto L6E; // [3083] 3092
L6D: 

    /** text.e:1932		    						dist = 3*/
    _dist_9625 = 3;
L6E: 

    /** text.e:1934		    					bracketed = (argtext[1] = '(')*/
    _2 = (object)SEQ_PTR(_argtext_9233);
    _5404 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_5404)) {
        _bracketed_9626 = (_5404 == 40);
    }
    else {
        _bracketed_9626 = binary_op(EQUALS, _5404, 40);
    }
    _5404 = NOVALUE;
    if (!IS_ATOM_INT(_bracketed_9626)) {
        _1 = (object)(DBL_PTR(_bracketed_9626)->dbl);
        DeRefDS(_bracketed_9626);
        _bracketed_9626 = _1;
    }

    /** text.e:1935		    					if bracketed then*/
    if (_bracketed_9626 == 0)
    {
        goto L6F; // [3106] 3124
    }
    else{
    }

    /** text.e:1936		    						argtext = argtext[2 .. $-1]*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5406 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5406 = 1;
    }
    _5407 = _5406 - 1;
    _5406 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_9233;
    RHS_Slice(_argtext_9233, 2, _5407);
L6F: 

    /** text.e:1938		    					dpos = find('.', argtext)*/
    _dpos_9624 = find_from(46, _argtext_9233, 1);

    /** text.e:1939		    					if dpos = 0 then*/
    if (_dpos_9624 != 0)
    goto L70; // [3133] 3149

    /** text.e:1940		    						dpos = length(argtext) + 1*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5411 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5411 = 1;
    }
    _dpos_9624 = _5411 + 1;
    _5411 = NOVALUE;
    goto L71; // [3146] 3163
L70: 

    /** text.e:1942		    						if tsep = '.' then*/
    if (_tsep_9067 != 46)
    goto L72; // [3151] 3162

    /** text.e:1943		    							argtext[dpos] = ','*/
    _2 = (object)SEQ_PTR(_argtext_9233);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _argtext_9233 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _dpos_9624);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 44;
    DeRef(_1);
L72: 
L71: 

    /** text.e:1946		    					while dpos > dist do*/
L73: 
    if (_dpos_9624 <= _dist_9625)
    goto L74; // [3170] 3248

    /** text.e:1947		    						dpos -= dist*/
    _dpos_9624 = _dpos_9624 - _dist_9625;

    /** text.e:1948		    						if dpos > 1 + (currargv < 0) * not msign + (currargv > 0) * psign then*/
    if (IS_ATOM_INT(_currargv_9070)) {
        _5416 = (_currargv_9070 < 0);
    }
    else {
        _5416 = binary_op(LESS, _currargv_9070, 0);
    }
    _5417 = (_msign_9054 == 0);
    if (IS_ATOM_INT(_5416)) {
        if (_5416 == (short)_5416 && _5417 <= INT15 && _5417 >= -INT15){
            _5418 = _5416 * _5417;
        }
        else{
            _5418 = NewDouble(_5416 * (eudouble)_5417);
        }
    }
    else {
        _5418 = binary_op(MULTIPLY, _5416, _5417);
    }
    DeRef(_5416);
    _5416 = NOVALUE;
    _5417 = NOVALUE;
    if (IS_ATOM_INT(_5418)) {
        _5419 = _5418 + 1;
        if (_5419 > MAXINT){
            _5419 = NewDouble((eudouble)_5419);
        }
    }
    else
    _5419 = binary_op(PLUS, 1, _5418);
    DeRef(_5418);
    _5418 = NOVALUE;
    if (IS_ATOM_INT(_currargv_9070)) {
        _5420 = (_currargv_9070 > 0);
    }
    else {
        _5420 = binary_op(GREATER, _currargv_9070, 0);
    }
    if (IS_ATOM_INT(_5420)) {
        if (_5420 == (short)_5420 && _psign_9053 <= INT15 && _psign_9053 >= -INT15){
            _5421 = _5420 * _psign_9053;
        }
        else{
            _5421 = NewDouble(_5420 * (eudouble)_psign_9053);
        }
    }
    else {
        _5421 = binary_op(MULTIPLY, _5420, _psign_9053);
    }
    DeRef(_5420);
    _5420 = NOVALUE;
    if (IS_ATOM_INT(_5419) && IS_ATOM_INT(_5421)) {
        _5422 = _5419 + _5421;
        if ((object)((uintptr_t)_5422 + (uintptr_t)HIGH_BITS) >= 0){
            _5422 = NewDouble((eudouble)_5422);
        }
    }
    else {
        _5422 = binary_op(PLUS, _5419, _5421);
    }
    DeRef(_5419);
    _5419 = NOVALUE;
    DeRef(_5421);
    _5421 = NOVALUE;
    if (binary_op_a(LESSEQ, _dpos_9624, _5422)){
        DeRef(_5422);
        _5422 = NOVALUE;
        goto L73; // [3213] 3168
    }
    DeRef(_5422);
    _5422 = NOVALUE;

    /** text.e:1949		    							argtext = argtext[1.. dpos - 1] & tsep & argtext[dpos .. $]*/
    _5424 = _dpos_9624 - 1;
    rhs_slice_target = (object_ptr)&_5425;
    RHS_Slice(_argtext_9233, 1, _5424);
    if (IS_SEQUENCE(_argtext_9233)){
            _5426 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5426 = 1;
    }
    rhs_slice_target = (object_ptr)&_5427;
    RHS_Slice(_argtext_9233, _dpos_9624, _5426);
    {
        object concat_list[3];

        concat_list[0] = _5427;
        concat_list[1] = _tsep_9067;
        concat_list[2] = _5425;
        Concat_N((object_ptr)&_argtext_9233, concat_list, 3);
    }
    DeRefDS(_5427);
    _5427 = NOVALUE;
    DeRefDS(_5425);
    _5425 = NOVALUE;

    /** text.e:1951		    					end while*/
    goto L73; // [3245] 3168
L74: 

    /** text.e:1952		    					if bracketed then*/
    if (_bracketed_9626 == 0)
    {
        goto L75; // [3250] 3262
    }
    else{
    }

    /** text.e:1953		    						argtext = '(' & argtext & ')'*/
    {
        object concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _argtext_9233;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_9233, concat_list, 3);
    }
L75: 
L6B: 
L6A: 

    /** text.e:1958	    				if width <= 0 then*/
    if (_width_9059 > 0)
    goto L76; // [3270] 3280

    /** text.e:1959	    					width = length(argtext)*/
    if (IS_SEQUENCE(_argtext_9233)){
            _width_9059 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _width_9059 = 1;
    }
L76: 

    /** text.e:1963	    				if width < length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5432 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5432 = 1;
    }
    if (_width_9059 >= _5432)
    goto L77; // [3285] 3416

    /** text.e:1964	    					if align = '>' then*/
    if (_align_9052 != 62)
    goto L78; // [3291] 3319

    /** text.e:1965	    						argtext = argtext[ $ - width + 1 .. $]*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5435 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5435 = 1;
    }
    _5436 = _5435 - _width_9059;
    if ((object)((uintptr_t)_5436 +(uintptr_t) HIGH_BITS) >= 0){
        _5436 = NewDouble((eudouble)_5436);
    }
    _5435 = NOVALUE;
    if (IS_ATOM_INT(_5436)) {
        _5437 = _5436 + 1;
        if (_5437 > MAXINT){
            _5437 = NewDouble((eudouble)_5437);
        }
    }
    else
    _5437 = binary_op(PLUS, 1, _5436);
    DeRef(_5436);
    _5436 = NOVALUE;
    if (IS_SEQUENCE(_argtext_9233)){
            _5438 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5438 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_9233;
    RHS_Slice(_argtext_9233, _5437, _5438);
    goto L79; // [3316] 3553
L78: 

    /** text.e:1966	    					elsif align = 'c' then*/
    if (_align_9052 != 99)
    goto L7A; // [3321] 3405

    /** text.e:1967	    						pos = length(argtext) - width*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5441 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5441 = 1;
    }
    _pos_9061 = _5441 - _width_9059;
    _5441 = NOVALUE;

    /** text.e:1968	    						if remainder(pos, 2) = 0 then*/
    _5443 = (_pos_9061 % 2);
    if (_5443 != 0)
    goto L7B; // [3340] 3373

    /** text.e:1969	    							pos = pos / 2*/
    if (_pos_9061 & 1) {
        _pos_9061 = NewDouble((_pos_9061 >> 1) + 0.5);
    }
    else
    _pos_9061 = _pos_9061 >> 1;
    if (!IS_ATOM_INT(_pos_9061)) {
        _1 = (object)(DBL_PTR(_pos_9061)->dbl);
        DeRefDS(_pos_9061);
        _pos_9061 = _1;
    }

    /** text.e:1970	    							argtext = argtext[ pos + 1 .. $ - pos ]*/
    _5446 = _pos_9061 + 1;
    if (_5446 > MAXINT){
        _5446 = NewDouble((eudouble)_5446);
    }
    if (IS_SEQUENCE(_argtext_9233)){
            _5447 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5447 = 1;
    }
    _5448 = _5447 - _pos_9061;
    _5447 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_9233;
    RHS_Slice(_argtext_9233, _5446, _5448);
    goto L79; // [3370] 3553
L7B: 

    /** text.e:1972	    							pos = floor(pos / 2)*/
    _pos_9061 = _pos_9061 >> 1;

    /** text.e:1973	    							argtext = argtext[ pos + 1 .. $ - pos - 1]*/
    _5451 = _pos_9061 + 1;
    if (_5451 > MAXINT){
        _5451 = NewDouble((eudouble)_5451);
    }
    if (IS_SEQUENCE(_argtext_9233)){
            _5452 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5452 = 1;
    }
    _5453 = _5452 - _pos_9061;
    if ((object)((uintptr_t)_5453 +(uintptr_t) HIGH_BITS) >= 0){
        _5453 = NewDouble((eudouble)_5453);
    }
    _5452 = NOVALUE;
    if (IS_ATOM_INT(_5453)) {
        _5454 = _5453 - 1;
    }
    else {
        _5454 = NewDouble(DBL_PTR(_5453)->dbl - (eudouble)1);
    }
    DeRef(_5453);
    _5453 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_9233;
    RHS_Slice(_argtext_9233, _5451, _5454);
    goto L79; // [3402] 3553
L7A: 

    /** text.e:1976	    						argtext = argtext[ 1 .. width]*/
    rhs_slice_target = (object_ptr)&_argtext_9233;
    RHS_Slice(_argtext_9233, 1, _width_9059);
    goto L79; // [3413] 3553
L77: 

    /** text.e:1978	    				elsif width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5457 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5457 = 1;
    }
    if (_width_9059 <= _5457)
    goto L7C; // [3421] 3552

    /** text.e:1979							if align = '>' then*/
    if (_align_9052 != 62)
    goto L7D; // [3427] 3451

    /** text.e:1980								argtext = repeat(' ', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5460 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5460 = 1;
    }
    _5461 = _width_9059 - _5460;
    _5460 = NOVALUE;
    _5462 = Repeat(32, _5461);
    _5461 = NOVALUE;
    Concat((object_ptr)&_argtext_9233, _5462, _argtext_9233);
    DeRefDS(_5462);
    _5462 = NOVALUE;
    DeRef(_5462);
    _5462 = NOVALUE;
    goto L7E; // [3448] 3551
L7D: 

    /** text.e:1981	    					elsif align = 'c' then*/
    if (_align_9052 != 99)
    goto L7F; // [3453] 3533

    /** text.e:1982	    						pos = width - length(argtext)*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5465 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5465 = 1;
    }
    _pos_9061 = _width_9059 - _5465;
    _5465 = NOVALUE;

    /** text.e:1983	    						if remainder(pos, 2) = 0 then*/
    _5467 = (_pos_9061 % 2);
    if (_5467 != 0)
    goto L80; // [3472] 3503

    /** text.e:1984	    							pos = pos / 2*/
    if (_pos_9061 & 1) {
        _pos_9061 = NewDouble((_pos_9061 >> 1) + 0.5);
    }
    else
    _pos_9061 = _pos_9061 >> 1;
    if (!IS_ATOM_INT(_pos_9061)) {
        _1 = (object)(DBL_PTR(_pos_9061)->dbl);
        DeRefDS(_pos_9061);
        _pos_9061 = _1;
    }

    /** text.e:1985	    							argtext = repeat(' ', pos) & argtext & repeat(' ', pos)*/
    _5470 = Repeat(32, _pos_9061);
    _5471 = Repeat(32, _pos_9061);
    {
        object concat_list[3];

        concat_list[0] = _5471;
        concat_list[1] = _argtext_9233;
        concat_list[2] = _5470;
        Concat_N((object_ptr)&_argtext_9233, concat_list, 3);
    }
    DeRefDS(_5471);
    _5471 = NOVALUE;
    DeRefDS(_5470);
    _5470 = NOVALUE;
    goto L7E; // [3500] 3551
L80: 

    /** text.e:1987	    							pos = floor(pos / 2)*/
    _pos_9061 = _pos_9061 >> 1;

    /** text.e:1988	    							argtext = repeat(' ', pos) & argtext & repeat(' ', pos + 1)*/
    _5474 = Repeat(32, _pos_9061);
    _5475 = _pos_9061 + 1;
    _5476 = Repeat(32, _5475);
    _5475 = NOVALUE;
    {
        object concat_list[3];

        concat_list[0] = _5476;
        concat_list[1] = _argtext_9233;
        concat_list[2] = _5474;
        Concat_N((object_ptr)&_argtext_9233, concat_list, 3);
    }
    DeRefDS(_5476);
    _5476 = NOVALUE;
    DeRefDS(_5474);
    _5474 = NOVALUE;
    goto L7E; // [3530] 3551
L7F: 

    /** text.e:1992								argtext = argtext & repeat(' ', width - length(argtext))*/
    if (IS_SEQUENCE(_argtext_9233)){
            _5478 = SEQ_PTR(_argtext_9233)->length;
    }
    else {
        _5478 = 1;
    }
    _5479 = _width_9059 - _5478;
    _5478 = NOVALUE;
    _5480 = Repeat(32, _5479);
    _5479 = NOVALUE;
    Concat((object_ptr)&_argtext_9233, _argtext_9233, _5480);
    DeRefDS(_5480);
    _5480 = NOVALUE;
L7E: 
L7C: 
L79: 

    /** text.e:1995	    				result &= argtext*/
    Concat((object_ptr)&_result_9046, _result_9046, _argtext_9233);
    goto L81; // [3559] 3575
L58: 

    /** text.e:1998	    				if spacer then*/
    if (_spacer_9057 == 0)
    {
        goto L82; // [3564] 3574
    }
    else{
    }

    /** text.e:1999	    					result &= ' '*/
    Append(&_result_9046, _result_9046, 32);
L82: 
L81: 

    /** text.e:2003	   				if trimming then*/
    if (_trimming_9064 == 0)
    {
        goto L83; // [3579] 3593
    }
    else{
    }

    /** text.e:2004	   					result = trim(result)*/
    RefDS(_result_9046);
    RefDS(_3871);
    _0 = _result_9046;
    _result_9046 = _14trim(_result_9046, _3871, 0);
    DeRefDS(_0);
L83: 

    /** text.e:2007	    			tend = 0*/
    _tend_9050 = 0;

    /** text.e:2008			    	prevargv = currargv*/
    Ref(_currargv_9070);
    DeRef(_prevargv_9069);
    _prevargv_9069 = _currargv_9070;
L1F: 
    DeRef(_argtext_9233);
    _argtext_9233 = NOVALUE;

    /** text.e:2011	    end while*/
    goto L2; // [3611] 60
L3: 

    /** text.e:2013		return result*/
    DeRefDS(_format_pattern_9044);
    DeRef(_arg_list_9045);
    DeRef(_prevargv_9069);
    DeRef(_currargv_9070);
    DeRef(_idname_9071);
    DeRef(_envsym_9072);
    DeRefi(_envvar_9073);
    DeRef(_5141);
    _5141 = NOVALUE;
    DeRef(_5454);
    _5454 = NOVALUE;
    DeRef(_5400);
    _5400 = NOVALUE;
    DeRef(_5443);
    _5443 = NOVALUE;
    DeRef(_5446);
    _5446 = NOVALUE;
    DeRef(_5160);
    _5160 = NOVALUE;
    DeRef(_5129);
    _5129 = NOVALUE;
    DeRef(_5407);
    _5407 = NOVALUE;
    DeRef(_5328);
    _5328 = NOVALUE;
    DeRef(_5338);
    _5338 = NOVALUE;
    DeRef(_5381);
    _5381 = NOVALUE;
    DeRef(_5190);
    _5190 = NOVALUE;
    DeRef(_5233);
    _5233 = NOVALUE;
    DeRef(_5448);
    _5448 = NOVALUE;
    DeRef(_5150);
    _5150 = NOVALUE;
    DeRef(_5437);
    _5437 = NOVALUE;
    DeRef(_5251);
    _5251 = NOVALUE;
    DeRef(_5391);
    _5391 = NOVALUE;
    DeRef(_5467);
    _5467 = NOVALUE;
    DeRef(_5451);
    _5451 = NOVALUE;
    DeRef(_5377);
    _5377 = NOVALUE;
    DeRef(_5102);
    _5102 = NOVALUE;
    DeRef(_5306);
    _5306 = NOVALUE;
    DeRef(_5078);
    _5078 = NOVALUE;
    DeRef(_5269);
    _5269 = NOVALUE;
    DeRef(_5170);
    _5170 = NOVALUE;
    DeRef(_5369);
    _5369 = NOVALUE;
    _5308 = NOVALUE;
    DeRef(_5180);
    _5180 = NOVALUE;
    DeRef(_5424);
    _5424 = NOVALUE;
    return _result_9046;
    ;
}



// 0xC5FC88D1
