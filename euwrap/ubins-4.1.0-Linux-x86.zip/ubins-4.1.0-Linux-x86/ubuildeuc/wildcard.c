// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _25qmatch(object _p_5834, object _s_5835)
{
    object _k_5836 = NOVALUE;
    object _3046 = NOVALUE;
    object _3045 = NOVALUE;
    object _3044 = NOVALUE;
    object _3043 = NOVALUE;
    object _3042 = NOVALUE;
    object _3041 = NOVALUE;
    object _3040 = NOVALUE;
    object _3039 = NOVALUE;
    object _3038 = NOVALUE;
    object _3037 = NOVALUE;
    object _3036 = NOVALUE;
    object _3035 = NOVALUE;
    object _3033 = NOVALUE;
    object _0, _1, _2;
    

    /** wildcard.e:21		if not find('?', p) then*/
    _3033 = find_from(63, _p_5834, 1);
    if (_3033 != 0)
    goto L1; // [12] 27
    _3033 = NOVALUE;

    /** wildcard.e:22			return match(p, s) -- fast*/
    _3035 = e_match_from(_p_5834, _s_5835, 1);
    DeRefDS(_p_5834);
    DeRefDS(_s_5835);
    return _3035;
L1: 

    /** wildcard.e:25		for i = 1 to length(s) - length(p) + 1 do*/
    if (IS_SEQUENCE(_s_5835)){
            _3036 = SEQ_PTR(_s_5835)->length;
    }
    else {
        _3036 = 1;
    }
    if (IS_SEQUENCE(_p_5834)){
            _3037 = SEQ_PTR(_p_5834)->length;
    }
    else {
        _3037 = 1;
    }
    _3038 = _3036 - _3037;
    _3036 = NOVALUE;
    _3037 = NOVALUE;
    _3039 = _3038 + 1;
    _3038 = NOVALUE;
    {
        object _i_5842;
        _i_5842 = 1;
L2: 
        if (_i_5842 > _3039){
            goto L3; // [43] 142
        }

        /** wildcard.e:26			k = i*/
        _k_5836 = _i_5842;

        /** wildcard.e:27			for j = 1 to length(p) do*/
        if (IS_SEQUENCE(_p_5834)){
                _3040 = SEQ_PTR(_p_5834)->length;
        }
        else {
            _3040 = 1;
        }
        {
            object _j_5848;
            _j_5848 = 1;
L4: 
            if (_j_5848 > _3040){
                goto L5; // [62] 122
            }

            /** wildcard.e:28				if p[j] != s[k] and p[j] != '?' then*/
            _2 = (object)SEQ_PTR(_p_5834);
            _3041 = (object)*(((s1_ptr)_2)->base + _j_5848);
            _2 = (object)SEQ_PTR(_s_5835);
            _3042 = (object)*(((s1_ptr)_2)->base + _k_5836);
            if (IS_ATOM_INT(_3041) && IS_ATOM_INT(_3042)) {
                _3043 = (_3041 != _3042);
            }
            else {
                _3043 = binary_op(NOTEQ, _3041, _3042);
            }
            _3041 = NOVALUE;
            _3042 = NOVALUE;
            if (IS_ATOM_INT(_3043)) {
                if (_3043 == 0) {
                    goto L6; // [83] 109
                }
            }
            else {
                if (DBL_PTR(_3043)->dbl == 0.0) {
                    goto L6; // [83] 109
                }
            }
            _2 = (object)SEQ_PTR(_p_5834);
            _3045 = (object)*(((s1_ptr)_2)->base + _j_5848);
            if (IS_ATOM_INT(_3045)) {
                _3046 = (_3045 != 63);
            }
            else {
                _3046 = binary_op(NOTEQ, _3045, 63);
            }
            _3045 = NOVALUE;
            if (_3046 == 0) {
                DeRef(_3046);
                _3046 = NOVALUE;
                goto L6; // [96] 109
            }
            else {
                if (!IS_ATOM_INT(_3046) && DBL_PTR(_3046)->dbl == 0.0){
                    DeRef(_3046);
                    _3046 = NOVALUE;
                    goto L6; // [96] 109
                }
                DeRef(_3046);
                _3046 = NOVALUE;
            }
            DeRef(_3046);
            _3046 = NOVALUE;

            /** wildcard.e:29					k = 0*/
            _k_5836 = 0;

            /** wildcard.e:30					exit*/
            goto L5; // [106] 122
L6: 

            /** wildcard.e:32				k += 1*/
            _k_5836 = _k_5836 + 1;

            /** wildcard.e:33			end for*/
            _j_5848 = _j_5848 + 1;
            goto L4; // [117] 69
L5: 
            ;
        }

        /** wildcard.e:34			if k != 0 then*/
        if (_k_5836 == 0)
        goto L7; // [124] 135

        /** wildcard.e:35				return i*/
        DeRefDS(_p_5834);
        DeRefDS(_s_5835);
        DeRef(_3039);
        _3039 = NOVALUE;
        DeRef(_3043);
        _3043 = NOVALUE;
        return _i_5842;
L7: 

        /** wildcard.e:37		end for*/
        _i_5842 = _i_5842 + 1;
        goto L2; // [137] 50
L3: 
        ;
    }

    /** wildcard.e:38		return 0*/
    DeRefDS(_p_5834);
    DeRefDS(_s_5835);
    DeRef(_3039);
    _3039 = NOVALUE;
    DeRef(_3043);
    _3043 = NOVALUE;
    return 0;
    ;
}


object _25is_match(object _pattern_5863, object _string_5864)
{
    object _p_5865 = NOVALUE;
    object _f_5866 = NOVALUE;
    object _t_5867 = NOVALUE;
    object _match_string_5868 = NOVALUE;
    object _3088 = NOVALUE;
    object _3087 = NOVALUE;
    object _3085 = NOVALUE;
    object _3081 = NOVALUE;
    object _3080 = NOVALUE;
    object _3079 = NOVALUE;
    object _3076 = NOVALUE;
    object _3075 = NOVALUE;
    object _3072 = NOVALUE;
    object _3069 = NOVALUE;
    object _3067 = NOVALUE;
    object _3065 = NOVALUE;
    object _3063 = NOVALUE;
    object _3060 = NOVALUE;
    object _3058 = NOVALUE;
    object _3056 = NOVALUE;
    object _3055 = NOVALUE;
    object _3054 = NOVALUE;
    object _3053 = NOVALUE;
    object _3051 = NOVALUE;
    object _0, _1, _2;
    

    /** wildcard.e:95		pattern = pattern & END_MARKER*/
    Append(&_pattern_5863, _pattern_5863, -1);

    /** wildcard.e:96		string = string & END_MARKER*/
    Append(&_string_5864, _string_5864, -1);

    /** wildcard.e:97		p = 1*/
    _p_5865 = 1;

    /** wildcard.e:98		f = 1*/
    _f_5866 = 1;

    /** wildcard.e:99		while f <= length(string) do*/
L1: 
    if (IS_SEQUENCE(_string_5864)){
            _3051 = SEQ_PTR(_string_5864)->length;
    }
    else {
        _3051 = 1;
    }
    if (_f_5866 > _3051)
    goto L2; // [35] 288

    /** wildcard.e:100			if not find(pattern[p], {string[f], '?'}) then*/
    _2 = (object)SEQ_PTR(_pattern_5863);
    _3053 = (object)*(((s1_ptr)_2)->base + _p_5865);
    _2 = (object)SEQ_PTR(_string_5864);
    _3054 = (object)*(((s1_ptr)_2)->base + _f_5866);
    Ref(_3054);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _3054;
    ((intptr_t *)_2)[2] = 63;
    _3055 = MAKE_SEQ(_1);
    _3054 = NOVALUE;
    _3056 = find_from(_3053, _3055, 1);
    _3053 = NOVALUE;
    DeRefDS(_3055);
    _3055 = NOVALUE;
    if (_3056 != 0)
    goto L3; // [58] 248
    _3056 = NOVALUE;

    /** wildcard.e:101				if pattern[p] = '*' then*/
    _2 = (object)SEQ_PTR(_pattern_5863);
    _3058 = (object)*(((s1_ptr)_2)->base + _p_5865);
    if (binary_op_a(NOTEQ, _3058, 42)){
        _3058 = NOVALUE;
        goto L4; // [67] 240
    }
    _3058 = NOVALUE;

    /** wildcard.e:102					while pattern[p] = '*' do*/
L5: 
    _2 = (object)SEQ_PTR(_pattern_5863);
    _3060 = (object)*(((s1_ptr)_2)->base + _p_5865);
    if (binary_op_a(NOTEQ, _3060, 42)){
        _3060 = NOVALUE;
        goto L6; // [80] 95
    }
    _3060 = NOVALUE;

    /** wildcard.e:103						p += 1*/
    _p_5865 = _p_5865 + 1;

    /** wildcard.e:104					end while*/
    goto L5; // [92] 76
L6: 

    /** wildcard.e:105					if pattern[p] = END_MARKER then*/
    _2 = (object)SEQ_PTR(_pattern_5863);
    _3063 = (object)*(((s1_ptr)_2)->base + _p_5865);
    if (binary_op_a(NOTEQ, _3063, -1)){
        _3063 = NOVALUE;
        goto L7; // [101] 112
    }
    _3063 = NOVALUE;

    /** wildcard.e:106						return 1*/
    DeRefDS(_pattern_5863);
    DeRefDS(_string_5864);
    DeRef(_match_string_5868);
    return 1;
L7: 

    /** wildcard.e:108					match_string = ""*/
    RefDS(_5);
    DeRef(_match_string_5868);
    _match_string_5868 = _5;

    /** wildcard.e:109					while pattern[p] != '*' do*/
L8: 
    _2 = (object)SEQ_PTR(_pattern_5863);
    _3065 = (object)*(((s1_ptr)_2)->base + _p_5865);
    if (binary_op_a(EQUALS, _3065, 42)){
        _3065 = NOVALUE;
        goto L9; // [128] 168
    }
    _3065 = NOVALUE;

    /** wildcard.e:110						match_string = match_string & pattern[p]*/
    _2 = (object)SEQ_PTR(_pattern_5863);
    _3067 = (object)*(((s1_ptr)_2)->base + _p_5865);
    if (IS_SEQUENCE(_match_string_5868) && IS_ATOM(_3067)) {
        Ref(_3067);
        Append(&_match_string_5868, _match_string_5868, _3067);
    }
    else if (IS_ATOM(_match_string_5868) && IS_SEQUENCE(_3067)) {
    }
    else {
        Concat((object_ptr)&_match_string_5868, _match_string_5868, _3067);
    }
    _3067 = NOVALUE;

    /** wildcard.e:111						if pattern[p] = END_MARKER then*/
    _2 = (object)SEQ_PTR(_pattern_5863);
    _3069 = (object)*(((s1_ptr)_2)->base + _p_5865);
    if (binary_op_a(NOTEQ, _3069, -1)){
        _3069 = NOVALUE;
        goto LA; // [148] 157
    }
    _3069 = NOVALUE;

    /** wildcard.e:112							exit*/
    goto L9; // [154] 168
LA: 

    /** wildcard.e:114						p += 1*/
    _p_5865 = _p_5865 + 1;

    /** wildcard.e:115					end while*/
    goto L8; // [165] 124
L9: 

    /** wildcard.e:116					if pattern[p] = '*' then*/
    _2 = (object)SEQ_PTR(_pattern_5863);
    _3072 = (object)*(((s1_ptr)_2)->base + _p_5865);
    if (binary_op_a(NOTEQ, _3072, 42)){
        _3072 = NOVALUE;
        goto LB; // [174] 185
    }
    _3072 = NOVALUE;

    /** wildcard.e:117						p -= 1*/
    _p_5865 = _p_5865 - 1;
LB: 

    /** wildcard.e:119					t = qmatch(match_string, string[f..$])*/
    if (IS_SEQUENCE(_string_5864)){
            _3075 = SEQ_PTR(_string_5864)->length;
    }
    else {
        _3075 = 1;
    }
    rhs_slice_target = (object_ptr)&_3076;
    RHS_Slice(_string_5864, _f_5866, _3075);
    RefDS(_match_string_5868);
    _t_5867 = _25qmatch(_match_string_5868, _3076);
    _3076 = NOVALUE;
    if (!IS_ATOM_INT(_t_5867)) {
        _1 = (object)(DBL_PTR(_t_5867)->dbl);
        DeRefDS(_t_5867);
        _t_5867 = _1;
    }

    /** wildcard.e:120					if t = 0 then*/
    if (_t_5867 != 0)
    goto LC; // [204] 217

    /** wildcard.e:121						return 0*/
    DeRefDS(_pattern_5863);
    DeRefDS(_string_5864);
    DeRefDS(_match_string_5868);
    return 0;
    goto LD; // [214] 247
LC: 

    /** wildcard.e:123						f += t + length(match_string) - 2*/
    if (IS_SEQUENCE(_match_string_5868)){
            _3079 = SEQ_PTR(_match_string_5868)->length;
    }
    else {
        _3079 = 1;
    }
    _3080 = _t_5867 + _3079;
    if ((object)((uintptr_t)_3080 + (uintptr_t)HIGH_BITS) >= 0){
        _3080 = NewDouble((eudouble)_3080);
    }
    _3079 = NOVALUE;
    if (IS_ATOM_INT(_3080)) {
        _3081 = _3080 - 2;
        if ((object)((uintptr_t)_3081 +(uintptr_t) HIGH_BITS) >= 0){
            _3081 = NewDouble((eudouble)_3081);
        }
    }
    else {
        _3081 = NewDouble(DBL_PTR(_3080)->dbl - (eudouble)2);
    }
    DeRef(_3080);
    _3080 = NOVALUE;
    if (IS_ATOM_INT(_3081)) {
        _f_5866 = _f_5866 + _3081;
    }
    else {
        _f_5866 = NewDouble((eudouble)_f_5866 + DBL_PTR(_3081)->dbl);
    }
    DeRef(_3081);
    _3081 = NOVALUE;
    if (!IS_ATOM_INT(_f_5866)) {
        _1 = (object)(DBL_PTR(_f_5866)->dbl);
        DeRefDS(_f_5866);
        _f_5866 = _1;
    }
    goto LD; // [237] 247
L4: 

    /** wildcard.e:126					return 0*/
    DeRefDS(_pattern_5863);
    DeRefDS(_string_5864);
    DeRef(_match_string_5868);
    return 0;
LD: 
L3: 

    /** wildcard.e:129			p += 1*/
    _p_5865 = _p_5865 + 1;

    /** wildcard.e:130			f += 1*/
    _f_5866 = _f_5866 + 1;

    /** wildcard.e:131			if p > length(pattern) then*/
    if (IS_SEQUENCE(_pattern_5863)){
            _3085 = SEQ_PTR(_pattern_5863)->length;
    }
    else {
        _3085 = 1;
    }
    if (_p_5865 <= _3085)
    goto L1; // [265] 32

    /** wildcard.e:132				return f > length(string) */
    if (IS_SEQUENCE(_string_5864)){
            _3087 = SEQ_PTR(_string_5864)->length;
    }
    else {
        _3087 = 1;
    }
    _3088 = (_f_5866 > _3087);
    _3087 = NOVALUE;
    DeRefDS(_pattern_5863);
    DeRefDS(_string_5864);
    DeRef(_match_string_5868);
    return _3088;

    /** wildcard.e:134		end while*/
    goto L1; // [285] 32
L2: 

    /** wildcard.e:135		return 0*/
    DeRefDS(_pattern_5863);
    DeRefDS(_string_5864);
    DeRef(_match_string_5868);
    DeRef(_3088);
    _3088 = NOVALUE;
    return 0;
    ;
}



// 0x0BD032B0
