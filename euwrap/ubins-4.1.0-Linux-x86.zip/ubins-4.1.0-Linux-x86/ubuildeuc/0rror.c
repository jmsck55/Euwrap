// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _50screen_output(object _f_49249, object _msg_49250)
{
    object _0, _1, _2;
    

    /** error.e:44		puts(f, msg)*/
    EPuts(2, _msg_49250); // DJP 

    /** error.e:45	end procedure*/
    DeRefDS(_msg_49250);
    return;
    ;
}


void _50Warning(object _msg_49253, object _mask_49254, object _args_49255)
{
    object _orig_mask_49256 = NOVALUE;
    object _text_49257 = NOVALUE;
    object _w_name_49258 = NOVALUE;
    object _25296 = NOVALUE;
    object _25294 = NOVALUE;
    object _25292 = NOVALUE;
    object _25289 = NOVALUE;
    object _25284 = NOVALUE;
    object _25282 = NOVALUE;
    object _25281 = NOVALUE;
    object _25280 = NOVALUE;
    object _25279 = NOVALUE;
    object _25277 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:54		if display_warnings = 0 then*/

    /** error.e:58		if not Strict_is_on or Strict_Override then*/
    _25277 = (_36Strict_is_on_21516 == 0);
    if (_25277 != 0) {
        goto L1; // [26] 37
    }
    if (_36Strict_Override_21517 == 0)
    {
        goto L2; // [33] 56
    }
    else{
    }
L1: 

    /** error.e:59			if find(mask, strict_only_warnings) then*/
    _25279 = find_from(_mask_49254, _36strict_only_warnings_21514, 1);
    if (_25279 == 0)
    {
        _25279 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        _25279 = NOVALUE;
    }

    /** error.e:60				return*/
    DeRef(_msg_49253);
    DeRefDS(_args_49255);
    DeRef(_text_49257);
    DeRef(_w_name_49258);
    DeRef(_25277);
    _25277 = NOVALUE;
    return;
L3: 
L2: 

    /** error.e:64		orig_mask = mask -- =0 for non maskable warnings - none implemented so far*/
    _orig_mask_49256 = _mask_49254;

    /** error.e:65		if Strict_is_on and Strict_Override = 0 then*/
    if (_36Strict_is_on_21516 == 0) {
        goto L4; // [65] 85
    }
    _25281 = (_36Strict_Override_21517 == 0);
    if (_25281 == 0)
    {
        DeRef(_25281);
        _25281 = NOVALUE;
        goto L4; // [76] 85
    }
    else{
        DeRef(_25281);
        _25281 = NOVALUE;
    }

    /** error.e:66			mask = 0*/
    _mask_49254 = 0;
L4: 

    /** error.e:69		if mask = 0 or and_bits(OpWarning, mask) then*/
    _25282 = (_mask_49254 == 0);
    if (_25282 != 0) {
        goto L5; // [91] 106
    }
    {uintptr_t tu;
         tu = (uintptr_t)_36OpWarning_21518 & (uintptr_t)_mask_49254;
         _25284 = MAKE_UINT(tu);
    }
    if (_25284 == 0) {
        DeRef(_25284);
        _25284 = NOVALUE;
        goto L6; // [102] 215
    }
    else {
        if (!IS_ATOM_INT(_25284) && DBL_PTR(_25284)->dbl == 0.0){
            DeRef(_25284);
            _25284 = NOVALUE;
            goto L6; // [102] 215
        }
        DeRef(_25284);
        _25284 = NOVALUE;
    }
    DeRef(_25284);
    _25284 = NOVALUE;
L5: 

    /** error.e:70			if orig_mask != 0 then*/
    if (_orig_mask_49256 == 0)
    goto L7; // [108] 122

    /** error.e:71				orig_mask = find(orig_mask,warning_flags)*/
    _orig_mask_49256 = find_from(_orig_mask_49256, _36warning_flags_21493, 1);
L7: 

    /** error.e:74			if orig_mask != 0 then*/
    if (_orig_mask_49256 == 0)
    goto L8; // [124] 145

    /** error.e:75				w_name = "{ " & warning_names[orig_mask] & " }"*/
    _2 = (object)SEQ_PTR(_36warning_names_21495);
    _25289 = (object)*(((s1_ptr)_2)->base + _orig_mask_49256);
    {
        object concat_list[3];

        concat_list[0] = _25290;
        concat_list[1] = _25289;
        concat_list[2] = _25288;
        Concat_N((object_ptr)&_w_name_49258, concat_list, 3);
    }
    _25289 = NOVALUE;
    goto L9; // [142] 153
L8: 

    /** error.e:77				w_name = "" -- not maskable*/
    RefDS(_21997);
    DeRef(_w_name_49258);
    _w_name_49258 = _21997;
L9: 

    /** error.e:80			if atom(msg) then*/
    _25292 = IS_ATOM(_msg_49253);
    if (_25292 == 0)
    {
        _25292 = NOVALUE;
        goto LA; // [158] 170
    }
    else{
        _25292 = NOVALUE;
    }

    /** error.e:81				msg = GetMsgText(msg, 1, args)*/
    Ref(_msg_49253);
    RefDS(_args_49255);
    _0 = _msg_49253;
    _msg_49253 = _39GetMsgText(_msg_49253, 1, _args_49255);
    DeRef(_0);
LA: 

    /** error.e:84			text = GetMsgText(WARNING_1T2, 0, {w_name, msg})*/
    Ref(_msg_49253);
    RefDS(_w_name_49258);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _w_name_49258;
    ((intptr_t *)_2)[2] = _msg_49253;
    _25294 = MAKE_SEQ(_1);
    _0 = _text_49257;
    _text_49257 = _39GetMsgText(204, 0, _25294);
    DeRef(_0);
    _25294 = NOVALUE;

    /** error.e:85			if find(text, warning_list) then*/
    _25296 = find_from(_text_49257, _50warning_list_49246, 1);
    if (_25296 == 0)
    {
        _25296 = NOVALUE;
        goto LB; // [197] 206
    }
    else{
        _25296 = NOVALUE;
    }

    /** error.e:86				return -- duplicate*/
    DeRef(_msg_49253);
    DeRefDS(_args_49255);
    DeRefDS(_text_49257);
    DeRefDS(_w_name_49258);
    DeRef(_25277);
    _25277 = NOVALUE;
    DeRef(_25282);
    _25282 = NOVALUE;
    return;
LB: 

    /** error.e:89			warning_list = append(warning_list, text)*/
    RefDS(_text_49257);
    Append(&_50warning_list_49246, _50warning_list_49246, _text_49257);
L6: 

    /** error.e:91	end procedure*/
    DeRef(_msg_49253);
    DeRefDS(_args_49255);
    DeRef(_text_49257);
    DeRef(_w_name_49258);
    DeRef(_25277);
    _25277 = NOVALUE;
    DeRef(_25282);
    _25282 = NOVALUE;
    return;
    ;
}


object _50ShowWarnings()
{
    object _c_49323 = NOVALUE;
    object _errfile_49324 = NOVALUE;
    object _twf_49325 = NOVALUE;
    object _25335 = NOVALUE;
    object _25332 = NOVALUE;
    object _25331 = NOVALUE;
    object _25330 = NOVALUE;
    object _25329 = NOVALUE;
    object _25328 = NOVALUE;
    object _25327 = NOVALUE;
    object _25325 = NOVALUE;
    object _25324 = NOVALUE;
    object _25323 = NOVALUE;
    object _25321 = NOVALUE;
    object _25320 = NOVALUE;
    object _25319 = NOVALUE;
    object _25318 = NOVALUE;
    object _25316 = NOVALUE;
    object _25312 = NOVALUE;
    object _25310 = NOVALUE;
    object _25309 = NOVALUE;
    object _25308 = NOVALUE;
    object _25306 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:117		if display_warnings = 0 or length(warning_list) = 0 then*/
    _25306 = (1 == 0);
    if (_25306 != 0) {
        goto L1; // [9] 27
    }
    if (IS_SEQUENCE(_50warning_list_49246)){
            _25308 = SEQ_PTR(_50warning_list_49246)->length;
    }
    else {
        _25308 = 1;
    }
    _25309 = (_25308 == 0);
    _25308 = NOVALUE;
    if (_25309 == 0)
    {
        DeRef(_25309);
        _25309 = NOVALUE;
        goto L2; // [23] 39
    }
    else{
        DeRef(_25309);
        _25309 = NOVALUE;
    }
L1: 

    /** error.e:118			return length(warning_list)*/
    if (IS_SEQUENCE(_50warning_list_49246)){
            _25310 = SEQ_PTR(_50warning_list_49246)->length;
    }
    else {
        _25310 = 1;
    }
    DeRef(_25306);
    _25306 = NOVALUE;
    return _25310;
L2: 

    /** error.e:121		if TempErrFile > 0 then*/
    if (_50TempErrFile_49235 <= 0)
    goto L3; // [43] 57

    /** error.e:122			errfile = TempErrFile*/
    _errfile_49324 = _50TempErrFile_49235;
    goto L4; // [54] 67
L3: 

    /** error.e:124			errfile = STDERR*/
    _errfile_49324 = 2;
L4: 

    /** error.e:127		if not integer(TempWarningName) then*/
    if (IS_ATOM_INT(_36TempWarningName_21461))
    _25312 = 1;
    else if (IS_ATOM_DBL(_36TempWarningName_21461))
    _25312 = IS_ATOM_INT(DoubleToInt(_36TempWarningName_21461));
    else
    _25312 = 0;
    if (_25312 != 0)
    goto L5; // [74] 183
    _25312 = NOVALUE;

    /** error.e:128			twf = open(TempWarningName,"w")*/
    _twf_49325 = EOpen(_36TempWarningName_21461, _22133, 0);

    /** error.e:129			if twf = -1 then*/
    if (_twf_49325 != -1)
    goto L6; // [88] 140

    /** error.e:130				ShowMsg(errfile, UNABLE_TO_CREATE_WARNING_FILE_1, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_36TempWarningName_21461);
    ((intptr_t*)_2)[1] = _36TempWarningName_21461;
    _25316 = MAKE_SEQ(_1);
    _39ShowMsg(_errfile_49324, 205, _25316, 1);
    _25316 = NOVALUE;

    /** error.e:131				if errfile != STDERR then*/
    if (_errfile_49324 == 2)
    goto L7; // [114] 177

    /** error.e:132					ShowMsg(STDERR, UNABLE_TO_CREATE_WARNING_FILE_1, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_36TempWarningName_21461);
    ((intptr_t*)_2)[1] = _36TempWarningName_21461;
    _25318 = MAKE_SEQ(_1);
    _39ShowMsg(2, 205, _25318, 1);
    _25318 = NOVALUE;
    goto L7; // [137] 177
L6: 

    /** error.e:135				for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_50warning_list_49246)){
            _25319 = SEQ_PTR(_50warning_list_49246)->length;
    }
    else {
        _25319 = 1;
    }
    {
        object _i_49358;
        _i_49358 = 1;
L8: 
        if (_i_49358 > _25319){
            goto L9; // [147] 172
        }

        /** error.e:136					puts(twf, warning_list[i])*/
        _2 = (object)SEQ_PTR(_50warning_list_49246);
        _25320 = (object)*(((s1_ptr)_2)->base + _i_49358);
        EPuts(_twf_49325, _25320); // DJP 
        _25320 = NOVALUE;

        /** error.e:137				end for*/
        _i_49358 = _i_49358 + 1;
        goto L8; // [167] 154
L9: 
        ;
    }

    /** error.e:138			    close(twf)*/
    EClose(_twf_49325);
L7: 

    /** error.e:140			TempWarningName = 99 -- Flag that we have done this already.*/
    DeRef(_36TempWarningName_21461);
    _36TempWarningName_21461 = 99;
L5: 

    /** error.e:143		if batch_job = 0 or errfile != STDERR then*/
    _25321 = (_36batch_job_21460 == 0);
    if (_25321 != 0) {
        goto LA; // [191] 208
    }
    _25323 = (_errfile_49324 != 2);
    if (_25323 == 0)
    {
        DeRef(_25323);
        _25323 = NOVALUE;
        goto LB; // [204] 317
    }
    else{
        DeRef(_25323);
        _25323 = NOVALUE;
    }
LA: 

    /** error.e:144			for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_50warning_list_49246)){
            _25324 = SEQ_PTR(_50warning_list_49246)->length;
    }
    else {
        _25324 = 1;
    }
    {
        object _i_49369;
        _i_49369 = 1;
LC: 
        if (_i_49369 > _25324){
            goto LD; // [215] 316
        }

        /** error.e:145				puts(errfile, warning_list[i])*/
        _2 = (object)SEQ_PTR(_50warning_list_49246);
        _25325 = (object)*(((s1_ptr)_2)->base + _i_49369);
        EPuts(_errfile_49324, _25325); // DJP 
        _25325 = NOVALUE;

        /** error.e:146				if errfile = STDERR then*/
        if (_errfile_49324 != 2)
        goto LE; // [239] 309

        /** error.e:147					if remainder(i, 20) = 0 and batch_job = 0 and test_only = 0 then*/
        _25327 = (_i_49369 % 20);
        _25328 = (_25327 == 0);
        _25327 = NOVALUE;
        if (_25328 == 0) {
            _25329 = 0;
            goto LF; // [253] 267
        }
        _25330 = (_36batch_job_21460 == 0);
        _25329 = (_25330 != 0);
LF: 
        if (_25329 == 0) {
            goto L10; // [267] 308
        }
        _25332 = (_36test_only_21459 == 0);
        if (_25332 == 0)
        {
            DeRef(_25332);
            _25332 = NOVALUE;
            goto L10; // [278] 308
        }
        else{
            DeRef(_25332);
            _25332 = NOVALUE;
        }

        /** error.e:148						ShowMsg(errfile, PRESS_ENTER_TO_CONTINUE_Q_TO_QUIT)*/
        RefDS(_21997);
        _39ShowMsg(_errfile_49324, 206, _21997, 1);

        /** error.e:149						c = getc(0)*/
        if (0 != last_r_file_no) {
            last_r_file_ptr = which_file(0, EF_READ);
            last_r_file_no = 0;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _c_49323 = getc((FILE*)xstdin);
            }
            else{
                _c_49323 = getc(last_r_file_ptr);
            }
        }
        else{
            _c_49323 = getc(last_r_file_ptr);
        }

        /** error.e:150						if c = 'q' then*/
        if (_c_49323 != 113)
        goto L11; // [298] 307

        /** error.e:151							exit*/
        goto LD; // [304] 316
L11: 
L10: 
LE: 

        /** error.e:155			end for*/
        _i_49369 = _i_49369 + 1;
        goto LC; // [311] 222
LD: 
        ;
    }
LB: 

    /** error.e:158		return length(warning_list)*/
    if (IS_SEQUENCE(_50warning_list_49246)){
            _25335 = SEQ_PTR(_50warning_list_49246)->length;
    }
    else {
        _25335 = 1;
    }
    DeRef(_25306);
    _25306 = NOVALUE;
    DeRef(_25330);
    _25330 = NOVALUE;
    DeRef(_25328);
    _25328 = NOVALUE;
    DeRef(_25321);
    _25321 = NOVALUE;
    return _25335;
    ;
}


void _50ShowDefines(object _errfile_49392)
{
    object _c_49393 = NOVALUE;
    object _25349 = NOVALUE;
    object _25348 = NOVALUE;
    object _25346 = NOVALUE;
    object _25345 = NOVALUE;
    object _25342 = NOVALUE;
    object _25341 = NOVALUE;
    object _25340 = NOVALUE;
    object _25339 = NOVALUE;
    object _25338 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:164		if errfile=0 then*/
    if (_errfile_49392 != 0)
    goto L1; // [5] 19

    /** error.e:165			errfile = STDERR*/
    _errfile_49392 = 2;
L1: 

    /** error.e:168		puts(errfile, format("\n--- [1] ---\n", {GetMsgText(DEFINED_WORDS,0)}))*/
    RefDS(_21997);
    _25338 = _39GetMsgText(207, 0, _21997);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25338;
    _25339 = MAKE_SEQ(_1);
    _25338 = NOVALUE;
    RefDS(_25337);
    _25340 = _14format(_25337, _25339);
    _25339 = NOVALUE;
    EPuts(_errfile_49392, _25340); // DJP 
    DeRef(_25340);
    _25340 = NOVALUE;

    /** error.e:170		for i = 1 to length(OpDefines) do*/
    if (IS_SEQUENCE(_36OpDefines_21524)){
            _25341 = SEQ_PTR(_36OpDefines_21524)->length;
    }
    else {
        _25341 = 1;
    }
    {
        object _i_49405;
        _i_49405 = 1;
L2: 
        if (_i_49405 > _25341){
            goto L3; // [48] 100
        }

        /** error.e:171			if find(OpDefines[i], {"_PLAT_START", "_PLAT_STOP"}) = 0 then*/
        _2 = (object)SEQ_PTR(_36OpDefines_21524);
        _25342 = (object)*(((s1_ptr)_2)->base + _i_49405);
        RefDS(_25344);
        RefDS(_25343);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _25343;
        ((intptr_t *)_2)[2] = _25344;
        _25345 = MAKE_SEQ(_1);
        _25346 = find_from(_25342, _25345, 1);
        _25342 = NOVALUE;
        DeRefDS(_25345);
        _25345 = NOVALUE;
        if (_25346 != 0)
        goto L4; // [72] 93

        /** error.e:172				printf(errfile, "%s\n", {OpDefines[i]})*/
        _2 = (object)SEQ_PTR(_36OpDefines_21524);
        _25348 = (object)*(((s1_ptr)_2)->base + _i_49405);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_25348);
        ((intptr_t*)_2)[1] = _25348;
        _25349 = MAKE_SEQ(_1);
        _25348 = NOVALUE;
        EPrintf(_errfile_49392, _25230, _25349);
        DeRefDS(_25349);
        _25349 = NOVALUE;
L4: 

        /** error.e:174		end for*/
        _i_49405 = _i_49405 + 1;
        goto L2; // [95] 55
L3: 
        ;
    }

    /** error.e:175		puts(errfile, "-------------------\n")*/
    EPuts(_errfile_49392, _25350); // DJP 

    /** error.e:177	end procedure*/
    return;
    ;
}


void _50Cleanup(object _status_49422)
{
    object _w_49423 = NOVALUE;
    object _show_error_49424 = NOVALUE;
    object _25368 = NOVALUE;
    object _25367 = NOVALUE;
    object _25366 = NOVALUE;
    object _25365 = NOVALUE;
    object _25364 = NOVALUE;
    object _25363 = NOVALUE;
    object _25362 = NOVALUE;
    object _25361 = NOVALUE;
    object _25360 = NOVALUE;
    object _25359 = NOVALUE;
    object _25357 = NOVALUE;
    object _25356 = NOVALUE;
    object _25355 = NOVALUE;
    object _25354 = NOVALUE;
    object _25353 = NOVALUE;
    object _25351 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:182		integer w, show_error = 0*/
    _show_error_49424 = 0;

    /** error.e:184		ifdef EU_EX then*/

    /** error.e:190		show_error = 1*/
    _show_error_49424 = 1;

    /** error.e:196		if object(src_file) = 0 then*/
    if( NOVALUE == _36src_file_21572 ){
        _25351 = 0;
    }
    else{
        _25351 = 1;
    }
    if (_25351 != 0)
    goto L1; // [20] 34

    /** error.e:197			src_file = -1*/
    _36src_file_21572 = -1;
    goto L2; // [31] 86
L1: 

    /** error.e:198		elsif src_file >= 0 and (src_file != repl_file or not repl) then*/
    _25353 = (_36src_file_21572 >= 0);
    if (_25353 == 0) {
        goto L3; // [42] 85
    }
    _25355 = (_36src_file_21572 != 5555);
    if (_25355 != 0) {
        DeRef(_25356);
        _25356 = 1;
        goto L4; // [54] 67
    }
    _25357 = (0 == 0);
    _25356 = (_25357 != 0);
L4: 
    if (_25356 == 0)
    {
        _25356 = NOVALUE;
        goto L3; // [68] 85
    }
    else{
        _25356 = NOVALUE;
    }

    /** error.e:199			close(src_file)*/
    EClose(_36src_file_21572);

    /** error.e:200			src_file = -1*/
    _36src_file_21572 = -1;
L3: 
L2: 

    /** error.e:203		w = ShowWarnings()*/
    _w_49423 = _50ShowWarnings();
    if (!IS_ATOM_INT(_w_49423)) {
        _1 = (object)(DBL_PTR(_w_49423)->dbl);
        DeRefDS(_w_49423);
        _w_49423 = _1;
    }

    /** error.e:204		if not TRANSLATE and (BIND or show_error) and (w or Errors) then*/
    _25359 = (_36TRANSLATE_21049 == 0);
    if (_25359 == 0) {
        _25360 = 0;
        goto L5; // [100] 118
    }
    if (_36BIND_21052 != 0) {
        _25361 = 1;
        goto L6; // [106] 114
    }
    _25361 = (_show_error_49424 != 0);
L6: 
    _25360 = (_25361 != 0);
L5: 
    if (_25360 == 0) {
        goto L7; // [118] 179
    }
    if (_w_49423 != 0) {
        DeRef(_25363);
        _25363 = 1;
        goto L8; // [122] 132
    }
    _25363 = (_50Errors_49234 != 0);
L8: 
    if (_25363 == 0)
    {
        _25363 = NOVALUE;
        goto L7; // [133] 179
    }
    else{
        _25363 = NOVALUE;
    }

    /** error.e:205			if not batch_job and not test_only then*/
    _25364 = (_36batch_job_21460 == 0);
    if (_25364 == 0) {
        goto L9; // [143] 178
    }
    _25366 = (_36test_only_21459 == 0);
    if (_25366 == 0)
    {
        DeRef(_25366);
        _25366 = NOVALUE;
        goto L9; // [153] 178
    }
    else{
        DeRef(_25366);
        _25366 = NOVALUE;
    }

    /** error.e:206				screen_output(STDERR, GetMsgText(PRESS_ENTER,0))*/
    RefDS(_21997);
    _25367 = _39GetMsgText(208, 0, _21997);
    _50screen_output(2, _25367);
    _25367 = NOVALUE;

    /** error.e:207				getc(0) -- wait*/
    if (0 != last_r_file_no) {
        last_r_file_ptr = which_file(0, EF_READ);
        last_r_file_no = 0;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _25368 = getc((FILE*)xstdin);
        }
        else{
            _25368 = getc(last_r_file_ptr);
        }
    }
    else{
        _25368 = getc(last_r_file_ptr);
    }
L9: 
L7: 

    /** error.e:212		cleanup_open_includes()*/
    _62cleanup_open_includes();

    /** error.e:213		abort(status)*/
    UserCleanup(_status_49422);

    /** error.e:214	end procedure*/
    DeRef(_25357);
    _25357 = NOVALUE;
    DeRef(_25364);
    _25364 = NOVALUE;
    DeRef(_25353);
    _25353 = NOVALUE;
    DeRef(_25355);
    _25355 = NOVALUE;
    DeRef(_25359);
    _25359 = NOVALUE;
    return;
    ;
}


void _50OpenErrFile()
{
    object _25375 = NOVALUE;
    object _25374 = NOVALUE;
    object _25372 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:219	    if TempErrFile != -1 then*/
    if (_50TempErrFile_49235 == -1)
    goto L1; // [5] 19

    /** error.e:220			TempErrFile = open(TempErrName, "w")*/
    _50TempErrFile_49235 = EOpen(_50TempErrName_49236, _22133, 0);
L1: 

    /** error.e:223		if TempErrFile = -1 then*/
    if (_50TempErrFile_49235 != -1)
    goto L2; // [23] 66

    /** error.e:224			if length(TempErrName) > 0 then*/
    _25372 = 6;

    /** error.e:225				screen_output(STDERR, GetMsgText(CANT_CREATE_ERROR_MESSAGE_FILE_1, 0, {TempErrName}))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_50TempErrName_49236);
    ((intptr_t*)_2)[1] = _50TempErrName_49236;
    _25374 = MAKE_SEQ(_1);
    _25375 = _39GetMsgText(209, 0, _25374);
    _25374 = NOVALUE;
    _50screen_output(2, _25375);
    _25375 = NOVALUE;

    /** error.e:227			abort(1) -- with no clean up*/
    UserCleanup(1);
L2: 

    /** error.e:229	end procedure*/
    return;
    ;
}


void _50ShowErr(object _f_49480)
{
    object _msg_inlined_screen_output_at_43_49493 = NOVALUE;
    object _25382 = NOVALUE;
    object _25381 = NOVALUE;
    object _25380 = NOVALUE;
    object _25378 = NOVALUE;
    object _25376 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:234		if length(known_files) = 0 then*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _25376 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _25376 = 1;
    }
    if (_25376 != 0)
    goto L1; // [10] 20

    /** error.e:235			return*/
    return;
L1: 

    /** error.e:238		if ThisLine[1] = END_OF_FILE_CHAR then*/
    _2 = (object)SEQ_PTR(_50ThisLine_49238);
    _25378 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _25378, 26)){
        _25378 = NOVALUE;
        goto L2; // [30] 64
    }
    _25378 = NOVALUE;

    /** error.e:239			screen_output(f, GetMsgText(MSG_ENDOFFILE,0))*/
    RefDS(_21997);
    _25380 = _39GetMsgText(210, 0, _21997);
    DeRef(_msg_inlined_screen_output_at_43_49493);
    _msg_inlined_screen_output_at_43_49493 = _25380;
    _25380 = NOVALUE;

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49480, _msg_inlined_screen_output_at_43_49493); // DJP 

    /** error.e:45	end procedure*/
    goto L3; // [56] 59
L3: 
    DeRef(_msg_inlined_screen_output_at_43_49493);
    _msg_inlined_screen_output_at_43_49493 = NOVALUE;
    goto L4; // [61] 81
L2: 

    /** error.e:241			screen_output(f, ThisLine)*/

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49480, _50ThisLine_49238); // DJP 

    /** error.e:45	end procedure*/
    goto L5; // [77] 80
L5: 
L4: 

    /** error.e:244		for i = 1 to bp-2 do -- bp-1 points to last character read*/
    _25381 = _50bp_49242 - 2;
    if ((object)((uintptr_t)_25381 +(uintptr_t) HIGH_BITS) >= 0){
        _25381 = NewDouble((eudouble)_25381);
    }
    {
        object _i_49497;
        _i_49497 = 1;
L6: 
        if (binary_op_a(GREATER, _i_49497, _25381)){
            goto L7; // [89] 143
        }

        /** error.e:245			if ThisLine[i] = '\t' then*/
        _2 = (object)SEQ_PTR(_50ThisLine_49238);
        if (!IS_ATOM_INT(_i_49497)){
            _25382 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_49497)->dbl));
        }
        else{
            _25382 = (object)*(((s1_ptr)_2)->base + _i_49497);
        }
        if (binary_op_a(NOTEQ, _25382, 9)){
            _25382 = NOVALUE;
            goto L8; // [104] 123
        }
        _25382 = NOVALUE;

        /** error.e:246				screen_output(f, "\t")*/

        /** error.e:44		puts(f, msg)*/
        EPuts(_f_49480, _23943); // DJP 

        /** error.e:45	end procedure*/
        goto L9; // [117] 136
        goto L9; // [120] 136
L8: 

        /** error.e:248				screen_output(f, " ")*/

        /** error.e:44		puts(f, msg)*/
        EPuts(_f_49480, _23388); // DJP 

        /** error.e:45	end procedure*/
        goto LA; // [132] 135
LA: 
L9: 

        /** error.e:250		end for*/
        _0 = _i_49497;
        if (IS_ATOM_INT(_i_49497)) {
            _i_49497 = _i_49497 + 1;
            if ((object)((uintptr_t)_i_49497 +(uintptr_t) HIGH_BITS) >= 0){
                _i_49497 = NewDouble((eudouble)_i_49497);
            }
        }
        else {
            _i_49497 = binary_op_a(PLUS, _i_49497, 1);
        }
        DeRef(_0);
        goto L6; // [138] 96
L7: 
        ;
        DeRef(_i_49497);
    }

    /** error.e:252		screen_output(f, "^\n\n")*/

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49480, _25384); // DJP 

    /** error.e:45	end procedure*/
    goto LB; // [152] 155
LB: 

    /** error.e:253	end procedure*/
    DeRef(_25381);
    _25381 = NOVALUE;
    return;
    ;
}


void _50CompileErr(object _msg_49509, object _args_49510, object _preproc_49511)
{
    object _errmsg_49512 = NOVALUE;
    object _25405 = NOVALUE;
    object _25401 = NOVALUE;
    object _25400 = NOVALUE;
    object _25399 = NOVALUE;
    object _25398 = NOVALUE;
    object _25397 = NOVALUE;
    object _25396 = NOVALUE;
    object _25394 = NOVALUE;
    object _25393 = NOVALUE;
    object _25391 = NOVALUE;
    object _25390 = NOVALUE;
    object _25389 = NOVALUE;
    object _25385 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:260		if integer(msg) then*/
    if (IS_ATOM_INT(_msg_49509))
    _25385 = 1;
    else if (IS_ATOM_DBL(_msg_49509))
    _25385 = IS_ATOM_INT(DoubleToInt(_msg_49509));
    else
    _25385 = 0;
    if (_25385 == 0)
    {
        _25385 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25385 = NOVALUE;
    }

    /** error.e:261			msg = GetMsgText(msg)*/
    Ref(_msg_49509);
    RefDS(_21997);
    _0 = _msg_49509;
    _msg_49509 = _39GetMsgText(_msg_49509, 1, _21997);
    DeRefi(_0);
L1: 

    /** error.e:264		msg = format(msg, args)*/
    Ref(_msg_49509);
    Ref(_args_49510);
    _0 = _msg_49509;
    _msg_49509 = _14format(_msg_49509, _args_49510);
    DeRef(_0);

    /** error.e:266		Errors += 1*/
    _50Errors_49234 = _50Errors_49234 + 1;

    /** error.e:267		if not preproc and length(known_files) then*/
    _25389 = (_preproc_49511 == 0);
    if (_25389 == 0) {
        goto L2; // [40] 78
    }
    if (IS_SEQUENCE(_37known_files_15407)){
            _25391 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _25391 = 1;
    }
    if (_25391 == 0)
    {
        _25391 = NOVALUE;
        goto L2; // [50] 78
    }
    else{
        _25391 = NOVALUE;
    }

    /** error.e:268			errmsg = sprintf("%s:%d\n%s\n", {known_files[current_file_no],*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _25393 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_25393);
    ((intptr_t*)_2)[1] = _25393;
    ((intptr_t*)_2)[2] = _36line_number_21448;
    Ref(_msg_49509);
    ((intptr_t*)_2)[3] = _msg_49509;
    _25394 = MAKE_SEQ(_1);
    _25393 = NOVALUE;
    DeRef(_errmsg_49512);
    _errmsg_49512 = EPrintf(-9999999, _25392, _25394);
    DeRefDS(_25394);
    _25394 = NOVALUE;
    goto L3; // [75] 121
L2: 

    /** error.e:271			errmsg = msg*/
    Ref(_msg_49509);
    DeRef(_errmsg_49512);
    _errmsg_49512 = _msg_49509;

    /** error.e:272			if length(msg) > 0 and msg[$] != '\n' then*/
    if (IS_SEQUENCE(_msg_49509)){
            _25396 = SEQ_PTR(_msg_49509)->length;
    }
    else {
        _25396 = 1;
    }
    _25397 = (_25396 > 0);
    _25396 = NOVALUE;
    if (_25397 == 0) {
        goto L4; // [94] 120
    }
    if (IS_SEQUENCE(_msg_49509)){
            _25399 = SEQ_PTR(_msg_49509)->length;
    }
    else {
        _25399 = 1;
    }
    _2 = (object)SEQ_PTR(_msg_49509);
    _25400 = (object)*(((s1_ptr)_2)->base + _25399);
    if (IS_ATOM_INT(_25400)) {
        _25401 = (_25400 != 10);
    }
    else {
        _25401 = binary_op(NOTEQ, _25400, 10);
    }
    _25400 = NOVALUE;
    if (_25401 == 0) {
        DeRef(_25401);
        _25401 = NOVALUE;
        goto L4; // [110] 120
    }
    else {
        if (!IS_ATOM_INT(_25401) && DBL_PTR(_25401)->dbl == 0.0){
            DeRef(_25401);
            _25401 = NOVALUE;
            goto L4; // [110] 120
        }
        DeRef(_25401);
        _25401 = NOVALUE;
    }
    DeRef(_25401);
    _25401 = NOVALUE;

    /** error.e:273				errmsg &= '\n'*/
    Append(&_errmsg_49512, _errmsg_49512, 10);
L4: 
L3: 

    /** error.e:277		if not preproc then*/
    if (_preproc_49511 != 0)
    goto L5; // [123] 131

    /** error.e:279			OpenErrFile() -- exits if error filename is ""*/
    _50OpenErrFile();
L5: 

    /** error.e:281		screen_output(STDERR, errmsg)*/
    RefDS(_errmsg_49512);
    _50screen_output(2, _errmsg_49512);

    /** error.e:283		if not preproc then*/
    if (_preproc_49511 != 0)
    goto L6; // [143] 198

    /** error.e:284			ShowErr(STDERR)*/
    _50ShowErr(2);

    /** error.e:286			puts(TempErrFile, errmsg)*/
    EPuts(_50TempErrFile_49235, _errmsg_49512); // DJP 

    /** error.e:288			ShowErr(TempErrFile)*/
    _50ShowErr(_50TempErrFile_49235);

    /** error.e:290			ShowWarnings()*/
    _25405 = _50ShowWarnings();

    /** error.e:292			ShowDefines(TempErrFile)*/
    _50ShowDefines(_50TempErrFile_49235);

    /** error.e:294			close(TempErrFile)*/
    EClose(_50TempErrFile_49235);

    /** error.e:295			TempErrFile = -2*/
    _50TempErrFile_49235 = -2;

    /** error.e:296			ifdef CRASH_ON_ERROR then*/

    /** error.e:299			Cleanup(1)*/
    _50Cleanup(1);
L6: 

    /** error.e:302	end procedure*/
    DeRef(_msg_49509);
    DeRef(_args_49510);
    DeRef(_errmsg_49512);
    DeRef(_25397);
    _25397 = NOVALUE;
    DeRef(_25405);
    _25405 = NOVALUE;
    DeRef(_25389);
    _25389 = NOVALUE;
    return;
    ;
}


void _50InternalErr(object _msgno_49556, object _args_49557)
{
    object _msg_49558 = NOVALUE;
    object _25420 = NOVALUE;
    object _25419 = NOVALUE;
    object _25418 = NOVALUE;
    object _25417 = NOVALUE;
    object _25416 = NOVALUE;
    object _25415 = NOVALUE;
    object _25414 = NOVALUE;
    object _25413 = NOVALUE;
    object _25412 = NOVALUE;
    object _25411 = NOVALUE;
    object _25410 = NOVALUE;
    object _25407 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:316		if atom(args) then*/
    _25407 = 0;
    if (_25407 == 0)
    {
        _25407 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _25407 = NOVALUE;
    }

    /** error.e:317			args = {args}*/
    _0 = _args_49557;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_args_49557);
    ((intptr_t*)_2)[1] = _args_49557;
    _args_49557 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** error.e:320		msg = GetMsgText(msgno, 1, args)*/
    Ref(_args_49557);
    _0 = _msg_49558;
    _msg_49558 = _39GetMsgText(_msgno_49556, 1, _args_49557);
    DeRef(_0);

    /** error.e:321		if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L2; // [32] 58
    }
    else{
    }

    /** error.e:322			screen_output(STDERR, GetMsgText(INTERNAL_ERRORT1, 1, {msg}))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_msg_49558);
    ((intptr_t*)_2)[1] = _msg_49558;
    _25410 = MAKE_SEQ(_1);
    _25411 = _39GetMsgText(211, 1, _25410);
    _25410 = NOVALUE;
    _50screen_output(2, _25411);
    _25411 = NOVALUE;
    goto L3; // [55] 91
L2: 

    /** error.e:324			screen_output(STDERR, GetMsgText(INTERNAL_ERROR_AT_12T3, 1, {known_files[current_file_no], line_number, msg}))*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _25412 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_25412);
    ((intptr_t*)_2)[1] = _25412;
    ((intptr_t*)_2)[2] = _36line_number_21448;
    RefDS(_msg_49558);
    ((intptr_t*)_2)[3] = _msg_49558;
    _25413 = MAKE_SEQ(_1);
    _25412 = NOVALUE;
    _25414 = _39GetMsgText(212, 1, _25413);
    _25413 = NOVALUE;
    _50screen_output(2, _25414);
    _25414 = NOVALUE;
L3: 

    /** error.e:327		if not batch_job and not test_only then*/
    _25415 = (_36batch_job_21460 == 0);
    if (_25415 == 0) {
        goto L4; // [98] 133
    }
    _25417 = (_36test_only_21459 == 0);
    if (_25417 == 0)
    {
        DeRef(_25417);
        _25417 = NOVALUE;
        goto L4; // [108] 133
    }
    else{
        DeRef(_25417);
        _25417 = NOVALUE;
    }

    /** error.e:328			screen_output(STDERR, GetMsgText(PRESS_ENTER, 0))*/
    RefDS(_21997);
    _25418 = _39GetMsgText(208, 0, _21997);
    _50screen_output(2, _25418);
    _25418 = NOVALUE;

    /** error.e:329			getc(0)*/
    if (0 != last_r_file_no) {
        last_r_file_ptr = which_file(0, EF_READ);
        last_r_file_no = 0;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _25419 = getc((FILE*)xstdin);
        }
        else{
            _25419 = getc(last_r_file_ptr);
        }
    }
    else{
        _25419 = getc(last_r_file_ptr);
    }
L4: 

    /** error.e:333		machine_proc(67, GetMsgText(FAILED_DUE_TO_INTERNAL_ERROR))*/
    RefDS(_21997);
    _25420 = _39GetMsgText(213, 1, _21997);
    machine(67, _25420);
    DeRef(_25420);
    _25420 = NOVALUE;

    /** error.e:334	end procedure*/
    DeRef(_args_49557);
    DeRef(_msg_49558);
    DeRef(_25415);
    _25415 = NOVALUE;
    return;
    ;
}



// 0x565BCD25
