// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _54hashfn(object _name_46795)
{
    object _len_46796 = NOVALUE;
    object _val_46797 = NOVALUE;
    object _int_46798 = NOVALUE;
    object _24301 = NOVALUE;
    object _24300 = NOVALUE;
    object _24297 = NOVALUE;
    object _24296 = NOVALUE;
    object _24285 = NOVALUE;
    object _24281 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:49		len = length(name)*/
    if (IS_SEQUENCE(_name_46795)){
            _len_46796 = SEQ_PTR(_name_46795)->length;
    }
    else {
        _len_46796 = 1;
    }

    /** symtab.e:51		val = name[1]*/
    _2 = (object)SEQ_PTR(_name_46795);
    _val_46797 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_val_46797))
    _val_46797 = (object)DBL_PTR(_val_46797)->dbl;

    /** symtab.e:52		int = name[$]*/
    if (IS_SEQUENCE(_name_46795)){
            _24281 = SEQ_PTR(_name_46795)->length;
    }
    else {
        _24281 = 1;
    }
    _2 = (object)SEQ_PTR(_name_46795);
    _int_46798 = (object)*(((s1_ptr)_2)->base + _24281);
    if (!IS_ATOM_INT(_int_46798))
    _int_46798 = (object)DBL_PTR(_int_46798)->dbl;

    /** symtab.e:53		int *= 256*/
    _int_46798 = _int_46798 * 256;

    /** symtab.e:54		val *= 2*/
    _val_46797 = _val_46797 + _val_46797;

    /** symtab.e:55		val += int + len*/
    _24285 = _int_46798 + _len_46796;
    if ((object)((uintptr_t)_24285 + (uintptr_t)HIGH_BITS) >= 0){
        _24285 = NewDouble((eudouble)_24285);
    }
    if (IS_ATOM_INT(_24285)) {
        _val_46797 = _val_46797 + _24285;
    }
    else {
        _val_46797 = NewDouble((eudouble)_val_46797 + DBL_PTR(_24285)->dbl);
    }
    DeRef(_24285);
    _24285 = NOVALUE;
    if (!IS_ATOM_INT(_val_46797)) {
        _1 = (object)(DBL_PTR(_val_46797)->dbl);
        DeRefDS(_val_46797);
        _val_46797 = _1;
    }

    /** symtab.e:57		if len = 3 then*/
    if (_len_46796 != 3)
    goto L1; // [51] 78

    /** symtab.e:58			val *= 32*/
    _val_46797 = _val_46797 * 32;

    /** symtab.e:59			int = name[2]*/
    _2 = (object)SEQ_PTR(_name_46795);
    _int_46798 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_46798))
    _int_46798 = (object)DBL_PTR(_int_46798)->dbl;

    /** symtab.e:60			val += int*/
    _val_46797 = _val_46797 + _int_46798;
    goto L2; // [75] 133
L1: 

    /** symtab.e:61		elsif len > 3 then*/
    if (_len_46796 <= 3)
    goto L3; // [80] 132

    /** symtab.e:62			val *= 32*/
    _val_46797 = _val_46797 * 32;

    /** symtab.e:63			int = name[2]*/
    _2 = (object)SEQ_PTR(_name_46795);
    _int_46798 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_46798))
    _int_46798 = (object)DBL_PTR(_int_46798)->dbl;

    /** symtab.e:64			val += int*/
    _val_46797 = _val_46797 + _int_46798;

    /** symtab.e:66			val *= 32*/
    _val_46797 = _val_46797 * 32;

    /** symtab.e:67			int = name[$-1]*/
    if (IS_SEQUENCE(_name_46795)){
            _24296 = SEQ_PTR(_name_46795)->length;
    }
    else {
        _24296 = 1;
    }
    _24297 = _24296 - 1;
    _24296 = NOVALUE;
    _2 = (object)SEQ_PTR(_name_46795);
    _int_46798 = (object)*(((s1_ptr)_2)->base + _24297);
    if (!IS_ATOM_INT(_int_46798))
    _int_46798 = (object)DBL_PTR(_int_46798)->dbl;

    /** symtab.e:68			val += int*/
    _val_46797 = _val_46797 + _int_46798;
L3: 
L2: 

    /** symtab.e:70		return remainder(val, NBUCKETS) + 1*/
    _24300 = (_val_46797 % 2003);
    _24301 = _24300 + 1;
    _24300 = NOVALUE;
    DeRefDS(_name_46795);
    DeRef(_24297);
    _24297 = NOVALUE;
    return _24301;
    ;
}


void _54remove_symbol(object _sym_46827)
{
    object _hash_46828 = NOVALUE;
    object _st_ptr_46829 = NOVALUE;
    object _24316 = NOVALUE;
    object _24315 = NOVALUE;
    object _24313 = NOVALUE;
    object _24312 = NOVALUE;
    object _24311 = NOVALUE;
    object _24309 = NOVALUE;
    object _24307 = NOVALUE;
    object _24306 = NOVALUE;
    object _24305 = NOVALUE;
    object _24302 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:79		hash = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24302 = (object)*(((s1_ptr)_2)->base + _sym_46827);
    _2 = (object)SEQ_PTR(_24302);
    _hash_46828 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_hash_46828)){
        _hash_46828 = (object)DBL_PTR(_hash_46828)->dbl;
    }
    _24302 = NOVALUE;

    /** symtab.e:80		st_ptr = buckets[hash]*/
    _2 = (object)SEQ_PTR(_54buckets_46776);
    _st_ptr_46829 = (object)*(((s1_ptr)_2)->base + _hash_46828);
    if (!IS_ATOM_INT(_st_ptr_46829))
    _st_ptr_46829 = (object)DBL_PTR(_st_ptr_46829)->dbl;

    /** symtab.e:82		while st_ptr and st_ptr != sym do*/
L1: 
    if (_st_ptr_46829 == 0) {
        goto L2; // [32] 65
    }
    _24306 = (_st_ptr_46829 != _sym_46827);
    if (_24306 == 0)
    {
        DeRef(_24306);
        _24306 = NOVALUE;
        goto L2; // [41] 65
    }
    else{
        DeRef(_24306);
        _24306 = NOVALUE;
    }

    /** symtab.e:83			st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24307 = (object)*(((s1_ptr)_2)->base + _st_ptr_46829);
    _2 = (object)SEQ_PTR(_24307);
    _st_ptr_46829 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_st_ptr_46829)){
        _st_ptr_46829 = (object)DBL_PTR(_st_ptr_46829)->dbl;
    }
    _24307 = NOVALUE;

    /** symtab.e:84		end while*/
    goto L1; // [62] 32
L2: 

    /** symtab.e:86		if st_ptr then*/
    if (_st_ptr_46829 == 0)
    {
        goto L3; // [67] 134
    }
    else{
    }

    /** symtab.e:87			if st_ptr = buckets[hash] then*/
    _2 = (object)SEQ_PTR(_54buckets_46776);
    _24309 = (object)*(((s1_ptr)_2)->base + _hash_46828);
    if (binary_op_a(NOTEQ, _st_ptr_46829, _24309)){
        _24309 = NOVALUE;
        goto L4; // [78] 105
    }
    _24309 = NOVALUE;

    /** symtab.e:89				buckets[hash] = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24311 = (object)*(((s1_ptr)_2)->base + _st_ptr_46829);
    _2 = (object)SEQ_PTR(_24311);
    _24312 = (object)*(((s1_ptr)_2)->base + 9);
    _24311 = NOVALUE;
    Ref(_24312);
    _2 = (object)SEQ_PTR(_54buckets_46776);
    _2 = (object)(((s1_ptr)_2)->base + _hash_46828);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24312;
    if( _1 != _24312 ){
        DeRef(_1);
    }
    _24312 = NOVALUE;
    goto L5; // [102] 133
L4: 

    /** symtab.e:92				SymTab[st_ptr][S_SAMEHASH] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_st_ptr_46829 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24315 = (object)*(((s1_ptr)_2)->base + _sym_46827);
    _2 = (object)SEQ_PTR(_24315);
    _24316 = (object)*(((s1_ptr)_2)->base + 9);
    _24315 = NOVALUE;
    Ref(_24316);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24316;
    if( _1 != _24316 ){
        DeRef(_1);
    }
    _24316 = NOVALUE;
    _24313 = NOVALUE;
L5: 
L3: 

    /** symtab.e:95	end procedure*/
    return;
    ;
}


object _54NewBasicEntry(object _name_46861, object _varnum_46862, object _scope_46863, object _token_46864, object _hashval_46865, object _samehash_46867, object _type_sym_46869)
{
    object _new_46870 = NOVALUE;
    object _24325 = NOVALUE;
    object _24323 = NOVALUE;
    object _24322 = NOVALUE;
    object _24321 = NOVALUE;
    object _24320 = NOVALUE;
    object _24319 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:105		if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L1; // [19] 33
    }
    else{
    }

    /** symtab.e:106			new = repeat(0, SIZEOF_ROUTINE_ENTRY)*/
    DeRef(_new_46870);
    _new_46870 = Repeat(0, _36SIZEOF_ROUTINE_ENTRY_21210);
    goto L2; // [30] 42
L1: 

    /** symtab.e:108			new = repeat(0, SIZEOF_VAR_ENTRY)*/
    DeRef(_new_46870);
    _new_46870 = Repeat(0, _36SIZEOF_VAR_ENTRY_21213);
L2: 

    /** symtab.e:111		new[S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:112		new[S_NAME] = name*/
    RefDS(_name_46861);
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NAME_21084))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NAME_21084);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _name_46861;
    DeRef(_1);

    /** symtab.e:113		new[S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_46863;
    DeRef(_1);

    /** symtab.e:114		new[S_MODE] = M_NORMAL*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);

    /** symtab.e:115		new[S_USAGE] = U_UNUSED*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:116		new[S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FILE_NO_21080))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21447;
    DeRef(_1);

    /** symtab.e:118		if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L3; // [102] 327
    }
    else{
    }

    /** symtab.e:120			new[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:121			new[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:123			new[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:124			new[S_SEQ_ELEM_NEW] = TYPE_NULL -- starting point for ORing*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:126			new[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:127			new[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:128			new[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:129			new[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:131			new[S_ARG_MIN] = NOVALUE*/
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21301;
    DeRef(_1);

    /** symtab.e:132			new[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21301)) {
        if ((uintptr_t)_36NOVALUE_21301 == (uintptr_t)HIGH_BITS){
            _24319 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24319 = - _36NOVALUE_21301;
        }
    }
    else {
        _24319 = unary_op(UMINUS, _36NOVALUE_21301);
    }
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24319;
    if( _1 != _24319 ){
        DeRef(_1);
    }
    _24319 = NOVALUE;

    /** symtab.e:134			new[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21301;
    DeRef(_1);

    /** symtab.e:135			new[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21301)) {
        if ((uintptr_t)_36NOVALUE_21301 == (uintptr_t)HIGH_BITS){
            _24320 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24320 = - _36NOVALUE_21301;
        }
    }
    else {
        _24320 = unary_op(UMINUS, _36NOVALUE_21301);
    }
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24320;
    if( _1 != _24320 ){
        DeRef(_1);
    }
    _24320 = NOVALUE;

    /** symtab.e:137			new[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21301;
    DeRef(_1);

    /** symtab.e:138			new[S_SEQ_LEN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_36NOVALUE_21301)) {
        if ((uintptr_t)_36NOVALUE_21301 == (uintptr_t)HIGH_BITS){
            _24321 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24321 = - _36NOVALUE_21301;
        }
    }
    else {
        _24321 = unary_op(UMINUS, _36NOVALUE_21301);
    }
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24321;
    if( _1 != _24321 ){
        DeRef(_1);
    }
    _24321 = NOVALUE;

    /** symtab.e:140			new[S_NREFS] = 0*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:141			new[S_ONE_REF] = TRUE          -- assume TRUE until we find otherwise*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 35);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13TRUE_452;
    DeRef(_1);

    /** symtab.e:142			new[S_RI_TARGET] = 0*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 53);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:144			new[S_OBJ_MIN] = MININT*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1073741824;
    DeRef(_1);

    /** symtab.e:145			new[S_OBJ_MIN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_36NOVALUE_21301)) {
        if ((uintptr_t)_36NOVALUE_21301 == (uintptr_t)HIGH_BITS){
            _24322 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24322 = - _36NOVALUE_21301;
        }
    }
    else {
        _24322 = unary_op(UMINUS, _36NOVALUE_21301);
    }
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24322;
    if( _1 != _24322 ){
        DeRef(_1);
    }
    _24322 = NOVALUE;

    /** symtab.e:147			new[S_OBJ_MAX] = MAXINT*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1073741823;
    DeRef(_1);

    /** symtab.e:148			new[S_OBJ_MAX_NEW] = -NOVALUE -- missing from C code? (not needed)*/
    if (IS_ATOM_INT(_36NOVALUE_21301)) {
        if ((uintptr_t)_36NOVALUE_21301 == (uintptr_t)HIGH_BITS){
            _24323 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24323 = - _36NOVALUE_21301;
        }
    }
    else {
        _24323 = unary_op(UMINUS, _36NOVALUE_21301);
    }
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24323;
    if( _1 != _24323 ){
        DeRef(_1);
    }
    _24323 = NOVALUE;
L3: 

    /** symtab.e:151		new[S_TOKEN] = token*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TOKEN_21089))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _token_46864;
    DeRef(_1);

    /** symtab.e:152		new[S_VARNUM] = varnum*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 16);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _varnum_46862;
    DeRef(_1);

    /** symtab.e:153		new[S_INITLEVEL] = -1*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1;
    DeRef(_1);

    /** symtab.e:154		new[S_VTYPE] = type_sym*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_sym_46869;
    DeRef(_1);

    /** symtab.e:156		new[S_HASHVAL] = hashval*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _hashval_46865;
    DeRef(_1);

    /** symtab.e:157		new[S_SAMEHASH] = samehash*/
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _samehash_46867;
    DeRef(_1);

    /** symtab.e:159		new[S_OBJ] = NOVALUE -- important*/
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(_new_46870);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46870 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21301;
    DeRef(_1);

    /** symtab.e:162		SymTab = append(SymTab, new)*/
    RefDS(_new_46870);
    Append(&_37SymTab_15406, _37SymTab_15406, _new_46870);

    /** symtab.e:164		return length(SymTab)*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _24325 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _24325 = 1;
    }
    DeRefDS(_name_46861);
    DeRefDS(_new_46870);
    return _24325;
    ;
}


object _54NewEntry(object _name_46949, object _varnum_46950, object _scope_46951, object _token_46952, object _hashval_46953, object _samehash_46955, object _type_sym_46957)
{
    object _new_46959 = NOVALUE;
    object _24327 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_scope_46951)) {
        _1 = (object)(DBL_PTR(_scope_46951)->dbl);
        DeRefDS(_scope_46951);
        _scope_46951 = _1;
    }
    if (!IS_ATOM_INT(_token_46952)) {
        _1 = (object)(DBL_PTR(_token_46952)->dbl);
        DeRefDS(_token_46952);
        _token_46952 = _1;
    }
    if (!IS_ATOM_INT(_samehash_46955)) {
        _1 = (object)(DBL_PTR(_samehash_46955)->dbl);
        DeRefDS(_samehash_46955);
        _samehash_46955 = _1;
    }

    /** symtab.e:171		symtab_index new = NewBasicEntry( name, varnum, scope, token, hashval, samehash, type_sym )*/
    RefDS(_name_46949);
    _new_46959 = _54NewBasicEntry(_name_46949, _varnum_46950, _scope_46951, _token_46952, _hashval_46953, _samehash_46955, _type_sym_46957);
    if (!IS_ATOM_INT(_new_46959)) {
        _1 = (object)(DBL_PTR(_new_46959)->dbl);
        DeRefDS(_new_46959);
        _new_46959 = _1;
    }

    /** symtab.e:174		if last_sym then*/
    if (_54last_sym_46789 == 0)
    {
        goto L1; // [33] 54
    }
    else{
    }

    /** symtab.e:175			SymTab[last_sym][S_NEXT] = new*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_54last_sym_46789 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_46959;
    DeRef(_1);
    _24327 = NOVALUE;
L1: 

    /** symtab.e:177		last_sym = new*/
    _54last_sym_46789 = _new_46959;

    /** symtab.e:178		if type_sym < 0 then*/
    if (_type_sym_46957 >= 0)
    goto L2; // [63] 76

    /** symtab.e:179			register_forward_type( last_sym, type_sym )*/
    _44register_forward_type(_54last_sym_46789, _type_sym_46957);
L2: 

    /** symtab.e:181		return last_sym*/
    DeRefDS(_name_46949);
    return _54last_sym_46789;
    ;
}


object _54tmp_alloc()
{
    object _new_entry_46974 = NOVALUE;
    object _24341 = NOVALUE;
    object _24339 = NOVALUE;
    object _24336 = NOVALUE;
    object _24333 = NOVALUE;
    object _24332 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:188		sequence new_entry = repeat( 0, SIZEOF_TEMP_ENTRY )*/
    DeRef(_new_entry_46974);
    _new_entry_46974 = Repeat(0, _36SIZEOF_TEMP_ENTRY_21219);

    /** symtab.e:192		new_entry[S_USAGE] = T_UNKNOWN*/
    _2 = (object)SEQ_PTR(_new_entry_46974);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46974 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    *(intptr_t *)_2 = 4;

    /** symtab.e:194		if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L1; // [23] 132
    }
    else{
    }

    /** symtab.e:195			new_entry[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_entry_46974);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46974 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    *(intptr_t *)_2 = 16;

    /** symtab.e:196			new_entry[S_OBJ_MIN] = MININT*/
    _2 = (object)SEQ_PTR(_new_entry_46974);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46974 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    *(intptr_t *)_2 = -1073741824;

    /** symtab.e:197			new_entry[S_OBJ_MAX] = MAXINT*/
    _2 = (object)SEQ_PTR(_new_entry_46974);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46974 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    *(intptr_t *)_2 = 1073741823;

    /** symtab.e:198			new_entry[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(_new_entry_46974);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46974 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    *(intptr_t *)_2 = _36NOVALUE_21301;

    /** symtab.e:199			new_entry[S_SEQ_ELEM] = TYPE_OBJECT  -- other fields set later*/
    _2 = (object)SEQ_PTR(_new_entry_46974);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46974 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:200			if length(temp_name_type)+1 = 8087 then*/
    if (IS_SEQUENCE(_36temp_name_type_21533)){
            _24332 = SEQ_PTR(_36temp_name_type_21533)->length;
    }
    else {
        _24332 = 1;
    }
    _24333 = _24332 + 1;
    _24332 = NOVALUE;
    if (_24333 != 8087)
    goto L2; // [87] 106

    /** symtab.e:202				temp_name_type = append(temp_name_type, {0, 0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = 0;
    _24336 = MAKE_SEQ(_1);
    RefDS(_24336);
    Append(&_36temp_name_type_21533, _36temp_name_type_21533, _24336);
    DeRefDS(_24336);
    _24336 = NOVALUE;
L2: 

    /** symtab.e:204			temp_name_type = append(temp_name_type, TYPES_OBNL)*/
    RefDS(_55TYPES_OBNL_46621);
    Append(&_36temp_name_type_21533, _36temp_name_type_21533, _55TYPES_OBNL_46621);

    /** symtab.e:205			new_entry[S_TEMP_NAME] = length(temp_name_type)*/
    if (IS_SEQUENCE(_36temp_name_type_21533)){
            _24339 = SEQ_PTR(_36temp_name_type_21533)->length;
    }
    else {
        _24339 = 1;
    }
    _2 = (object)SEQ_PTR(_new_entry_46974);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46974 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24339;
    if( _1 != _24339 ){
        DeRef(_1);
    }
    _24339 = NOVALUE;
L1: 

    /** symtab.e:208		SymTab = append(SymTab, new_entry )*/
    RefDS(_new_entry_46974);
    Append(&_37SymTab_15406, _37SymTab_15406, _new_entry_46974);

    /** symtab.e:210		return length( SymTab )*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _24341 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _24341 = 1;
    }
    DeRefDS(_new_entry_46974);
    DeRef(_24333);
    _24333 = NOVALUE;
    return _24341;
    ;
}


void _54DefinedYet(object _sym_47043)
{
    object _24361 = NOVALUE;
    object _24360 = NOVALUE;
    object _24359 = NOVALUE;
    object _24357 = NOVALUE;
    object _24356 = NOVALUE;
    object _24354 = NOVALUE;
    object _24353 = NOVALUE;
    object _24352 = NOVALUE;
    object _24351 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:230		if not find(SymTab[sym][S_SCOPE],*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24351 = (object)*(((s1_ptr)_2)->base + _sym_47043);
    _2 = (object)SEQ_PTR(_24351);
    _24352 = (object)*(((s1_ptr)_2)->base + 4);
    _24351 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 9;
    ((intptr_t*)_2)[2] = 10;
    ((intptr_t*)_2)[3] = 7;
    _24353 = MAKE_SEQ(_1);
    _24354 = find_from(_24352, _24353, 1);
    _24352 = NOVALUE;
    DeRefDS(_24353);
    _24353 = NOVALUE;
    if (_24354 != 0)
    goto L1; // [34] 84
    _24354 = NOVALUE;

    /** symtab.e:232			if SymTab[sym][S_FILE_NO] = current_file_no then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24356 = (object)*(((s1_ptr)_2)->base + _sym_47043);
    _2 = (object)SEQ_PTR(_24356);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _24357 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _24357 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _24356 = NOVALUE;
    if (binary_op_a(NOTEQ, _24357, _36current_file_no_21447)){
        _24357 = NOVALUE;
        goto L2; // [53] 83
    }
    _24357 = NOVALUE;

    /** symtab.e:233				CompileErr(ATTEMPT_TO_REDEFINE_1, {SymTab[sym][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24359 = (object)*(((s1_ptr)_2)->base + _sym_47043);
    _2 = (object)SEQ_PTR(_24359);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _24360 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _24360 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _24359 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24360);
    ((intptr_t*)_2)[1] = _24360;
    _24361 = MAKE_SEQ(_1);
    _24360 = NOVALUE;
    _50CompileErr(31, _24361, 0);
    _24361 = NOVALUE;
L2: 
L1: 

    /** symtab.e:236	end procedure*/
    return;
    ;
}


object _54name_ext(object _s_47071)
{
    object _24368 = NOVALUE;
    object _24367 = NOVALUE;
    object _24366 = NOVALUE;
    object _24365 = NOVALUE;
    object _24363 = NOVALUE;
    object _24362 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:241		for i = length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_47071)){
            _24362 = SEQ_PTR(_s_47071)->length;
    }
    else {
        _24362 = 1;
    }
    {
        object _i_47073;
        _i_47073 = _24362;
L1: 
        if (_i_47073 < 1){
            goto L2; // [8] 55
        }

        /** symtab.e:242			if find(s[i], "/\\:") then*/
        _2 = (object)SEQ_PTR(_s_47071);
        _24363 = (object)*(((s1_ptr)_2)->base + _i_47073);
        _24365 = find_from(_24363, _24364, 1);
        _24363 = NOVALUE;
        if (_24365 == 0)
        {
            _24365 = NOVALUE;
            goto L3; // [26] 48
        }
        else{
            _24365 = NOVALUE;
        }

        /** symtab.e:243				return s[i+1 .. $]*/
        _24366 = _i_47073 + 1;
        if (IS_SEQUENCE(_s_47071)){
                _24367 = SEQ_PTR(_s_47071)->length;
        }
        else {
            _24367 = 1;
        }
        rhs_slice_target = (object_ptr)&_24368;
        RHS_Slice(_s_47071, _24366, _24367);
        DeRefDS(_s_47071);
        _24366 = NOVALUE;
        return _24368;
L3: 

        /** symtab.e:245		end for*/
        _i_47073 = _i_47073 + -1;
        goto L1; // [50] 15
L2: 
        ;
    }

    /** symtab.e:247		return s*/
    DeRef(_24366);
    _24366 = NOVALUE;
    DeRef(_24368);
    _24368 = NOVALUE;
    return _s_47071;
    ;
}


object _54NewStringSym(object _s_47090)
{
    object _p_47092 = NOVALUE;
    object _tp_47093 = NOVALUE;
    object _prev_47094 = NOVALUE;
    object _search_count_47095 = NOVALUE;
    object _24412 = NOVALUE;
    object _24410 = NOVALUE;
    object _24409 = NOVALUE;
    object _24408 = NOVALUE;
    object _24406 = NOVALUE;
    object _24405 = NOVALUE;
    object _24402 = NOVALUE;
    object _24400 = NOVALUE;
    object _24398 = NOVALUE;
    object _24397 = NOVALUE;
    object _24396 = NOVALUE;
    object _24394 = NOVALUE;
    object _24392 = NOVALUE;
    object _24390 = NOVALUE;
    object _24388 = NOVALUE;
    object _24385 = NOVALUE;
    object _24383 = NOVALUE;
    object _24382 = NOVALUE;
    object _24381 = NOVALUE;
    object _24379 = NOVALUE;
    object _24377 = NOVALUE;
    object _24376 = NOVALUE;
    object _24375 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:255		integer search_count*/

    /** symtab.e:258		tp = literal_init*/
    _tp_47093 = _54literal_init_46788;

    /** symtab.e:259		prev = 0*/
    _prev_47094 = 0;

    /** symtab.e:260		search_count = 0*/
    _search_count_47095 = 0;

    /** symtab.e:261		while tp != 0 do*/
L1: 
    if (_tp_47093 == 0)
    goto L2; // [31] 170

    /** symtab.e:262			search_count += 1*/
    _search_count_47095 = _search_count_47095 + 1;

    /** symtab.e:263			if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_47095, _54SEARCH_LIMIT_47082)){
        goto L3; // [45] 54
    }

    /** symtab.e:264				exit*/
    goto L2; // [51] 170
L3: 

    /** symtab.e:266			if equal(s, SymTab[tp][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24375 = (object)*(((s1_ptr)_2)->base + _tp_47093);
    _2 = (object)SEQ_PTR(_24375);
    _24376 = (object)*(((s1_ptr)_2)->base + 1);
    _24375 = NOVALUE;
    if (_s_47090 == _24376)
    _24377 = 1;
    else if (IS_ATOM_INT(_s_47090) && IS_ATOM_INT(_24376))
    _24377 = 0;
    else
    _24377 = (compare(_s_47090, _24376) == 0);
    _24376 = NOVALUE;
    if (_24377 == 0)
    {
        _24377 = NOVALUE;
        goto L4; // [72] 142
    }
    else{
        _24377 = NOVALUE;
    }

    /** symtab.e:268				if tp != literal_init then*/
    if (_tp_47093 == _54literal_init_46788)
    goto L5; // [79] 135

    /** symtab.e:269					SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_47094 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24381 = (object)*(((s1_ptr)_2)->base + _tp_47093);
    _2 = (object)SEQ_PTR(_24381);
    _24382 = (object)*(((s1_ptr)_2)->base + 2);
    _24381 = NOVALUE;
    Ref(_24382);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24382;
    if( _1 != _24382 ){
        DeRef(_1);
    }
    _24382 = NOVALUE;
    _24379 = NOVALUE;

    /** symtab.e:270					SymTab[tp][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_tp_47093 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54literal_init_46788;
    DeRef(_1);
    _24383 = NOVALUE;

    /** symtab.e:271					literal_init = tp*/
    _54literal_init_46788 = _tp_47093;
L5: 

    /** symtab.e:273				return tp*/
    DeRefDS(_s_47090);
    return _tp_47093;
L4: 

    /** symtab.e:275			prev = tp*/
    _prev_47094 = _tp_47093;

    /** symtab.e:276			tp = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24385 = (object)*(((s1_ptr)_2)->base + _tp_47093);
    _2 = (object)SEQ_PTR(_24385);
    _tp_47093 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_tp_47093)){
        _tp_47093 = (object)DBL_PTR(_tp_47093)->dbl;
    }
    _24385 = NOVALUE;

    /** symtab.e:277		end while*/
    goto L1; // [167] 31
L2: 

    /** symtab.e:279		p = tmp_alloc()*/
    _p_47092 = _54tmp_alloc();
    if (!IS_ATOM_INT(_p_47092)) {
        _1 = (object)(DBL_PTR(_p_47092)->dbl);
        DeRefDS(_p_47092);
        _p_47092 = _1;
    }

    /** symtab.e:280		SymTab[p][S_OBJ] = s*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47092 + ((s1_ptr)_2)->base);
    RefDS(_s_47090);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_47090;
    DeRef(_1);
    _24388 = NOVALUE;

    /** symtab.e:282		if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L6; // [196] 346
    }
    else{
    }

    /** symtab.e:283			SymTab[p][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47092 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _24390 = NOVALUE;

    /** symtab.e:284			SymTab[p][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47092 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8;
    DeRef(_1);
    _24392 = NOVALUE;

    /** symtab.e:285			SymTab[p][S_SEQ_LEN] = length(s)*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47092 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_s_47090)){
            _24396 = SEQ_PTR(_s_47090)->length;
    }
    else {
        _24396 = 1;
    }
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24396;
    if( _1 != _24396 ){
        DeRef(_1);
    }
    _24396 = NOVALUE;
    _24394 = NOVALUE;

    /** symtab.e:286			if SymTab[p][S_SEQ_LEN] > 0 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24397 = (object)*(((s1_ptr)_2)->base + _p_47092);
    _2 = (object)SEQ_PTR(_24397);
    _24398 = (object)*(((s1_ptr)_2)->base + 32);
    _24397 = NOVALUE;
    if (binary_op_a(LESSEQ, _24398, 0)){
        _24398 = NOVALUE;
        goto L7; // [265] 289
    }
    _24398 = NOVALUE;

    /** symtab.e:287				SymTab[p][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47092 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _24400 = NOVALUE;
    goto L8; // [286] 307
L7: 

    /** symtab.e:289				SymTab[p][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47092 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _24402 = NOVALUE;
L8: 

    /** symtab.e:291			c_printf("object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24405 = (object)*(((s1_ptr)_2)->base + _p_47092);
    _2 = (object)SEQ_PTR(_24405);
    _24406 = (object)*(((s1_ptr)_2)->base + 34);
    _24405 = NOVALUE;
    RefDS(_24404);
    Ref(_24406);
    _55c_printf(_24404, _24406);
    _24406 = NOVALUE;

    /** symtab.e:292			c_hprintf("extern object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24408 = (object)*(((s1_ptr)_2)->base + _p_47092);
    _2 = (object)SEQ_PTR(_24408);
    _24409 = (object)*(((s1_ptr)_2)->base + 34);
    _24408 = NOVALUE;
    RefDS(_24407);
    Ref(_24409);
    _55c_hprintf(_24407, _24409);
    _24409 = NOVALUE;
    goto L9; // [343] 364
L6: 

    /** symtab.e:295			SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47092 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24410 = NOVALUE;
L9: 

    /** symtab.e:299		SymTab[p][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47092 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54literal_init_46788;
    DeRef(_1);
    _24412 = NOVALUE;

    /** symtab.e:300		literal_init = p*/
    _54literal_init_46788 = _p_47092;

    /** symtab.e:301		return p*/
    DeRefDS(_s_47090);
    return _p_47092;
    ;
}


object _54NewIntSym(object _int_val_47188)
{
    object _p_47190 = NOVALUE;
    object _x_47191 = NOVALUE;
    object _24436 = NOVALUE;
    object _24434 = NOVALUE;
    object _24430 = NOVALUE;
    object _24428 = NOVALUE;
    object _24426 = NOVALUE;
    object _24424 = NOVALUE;
    object _24422 = NOVALUE;
    object _24420 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:308		integer x*/

    /** symtab.e:310		x = find(int_val, lastintval)*/
    _x_47191 = find_from(_int_val_47188, _54lastintval_46790, 1);

    /** symtab.e:311		if x then*/
    if (_x_47191 == 0)
    {
        goto L1; // [14] 75
    }
    else{
    }

    /** symtab.e:312			if repl then*/

    /** symtab.e:317			return lastintsym[x]  -- saves space, helps Translator reduce code size*/
    _2 = (object)SEQ_PTR(_54lastintsym_46791);
    _24420 = (object)*(((s1_ptr)_2)->base + _x_47191);
    DeRef(_int_val_47188);
    return _24420;
    goto L2; // [72] 225
L1: 

    /** symtab.e:320			label "lolol"*/
G3:

    /** symtab.e:321			p = tmp_alloc()*/
    _p_47190 = _54tmp_alloc();
    if (!IS_ATOM_INT(_p_47190)) {
        _1 = (object)(DBL_PTR(_p_47190)->dbl);
        DeRefDS(_p_47190);
        _p_47190 = _1;
    }

    /** symtab.e:322			SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47190 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24422 = NOVALUE;

    /** symtab.e:323			SymTab[p][S_OBJ] = int_val*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47190 + ((s1_ptr)_2)->base);
    Ref(_int_val_47188);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47188;
    DeRef(_1);
    _24424 = NOVALUE;

    /** symtab.e:325			if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L4; // [122] 173
    }
    else{
    }

    /** symtab.e:326				SymTab[p][S_OBJ_MIN] = int_val*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47190 + ((s1_ptr)_2)->base);
    Ref(_int_val_47188);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47188;
    DeRef(_1);
    _24426 = NOVALUE;

    /** symtab.e:327				SymTab[p][S_OBJ_MAX] = int_val*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47190 + ((s1_ptr)_2)->base);
    Ref(_int_val_47188);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47188;
    DeRef(_1);
    _24428 = NOVALUE;

    /** symtab.e:328				SymTab[p][S_GTYPE] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47190 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _24430 = NOVALUE;
L4: 

    /** symtab.e:331			lastintval = prepend(lastintval, int_val)*/
    Ref(_int_val_47188);
    Prepend(&_54lastintval_46790, _54lastintval_46790, _int_val_47188);

    /** symtab.e:332			lastintsym = prepend(lastintsym, p)*/
    Prepend(&_54lastintsym_46791, _54lastintsym_46791, _p_47190);

    /** symtab.e:333			if length(lastintval) > SEARCH_LIMIT then*/
    if (IS_SEQUENCE(_54lastintval_46790)){
            _24434 = SEQ_PTR(_54lastintval_46790)->length;
    }
    else {
        _24434 = 1;
    }
    if (binary_op_a(LESSEQ, _24434, _54SEARCH_LIMIT_47082)){
        _24434 = NOVALUE;
        goto L5; // [198] 218
    }
    _24434 = NOVALUE;

    /** symtab.e:334				lastintval = lastintval[1..floor(SEARCH_LIMIT/2)]*/
    if (IS_ATOM_INT(_54SEARCH_LIMIT_47082)) {
        _24436 = _54SEARCH_LIMIT_47082 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _54SEARCH_LIMIT_47082, 2);
        _24436 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    rhs_slice_target = (object_ptr)&_54lastintval_46790;
    RHS_Slice(_54lastintval_46790, 1, _24436);
L5: 

    /** symtab.e:336			return p*/
    DeRef(_int_val_47188);
    _24420 = NOVALUE;
    DeRef(_24436);
    _24436 = NOVALUE;
    return _p_47190;
L2: 
    ;
}


object _54NewDoubleSym(object _d_47240)
{
    object _p_47242 = NOVALUE;
    object _tp_47243 = NOVALUE;
    object _prev_47244 = NOVALUE;
    object _search_count_47245 = NOVALUE;
    object _24466 = NOVALUE;
    object _24465 = NOVALUE;
    object _24464 = NOVALUE;
    object _24463 = NOVALUE;
    object _24462 = NOVALUE;
    object _24460 = NOVALUE;
    object _24458 = NOVALUE;
    object _24456 = NOVALUE;
    object _24454 = NOVALUE;
    object _24451 = NOVALUE;
    object _24449 = NOVALUE;
    object _24448 = NOVALUE;
    object _24447 = NOVALUE;
    object _24445 = NOVALUE;
    object _24443 = NOVALUE;
    object _24442 = NOVALUE;
    object _24441 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:343		integer search_count*/

    /** symtab.e:346		tp = literal_init*/
    _tp_47243 = _54literal_init_46788;

    /** symtab.e:347		prev = 0*/
    _prev_47244 = 0;

    /** symtab.e:348		search_count = 0*/
    _search_count_47245 = 0;

    /** symtab.e:349		while tp != 0 do*/
L1: 
    if (_tp_47243 == 0)
    goto L2; // [29] 168

    /** symtab.e:350			search_count += 1*/
    _search_count_47245 = _search_count_47245 + 1;

    /** symtab.e:351			if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_47245, _54SEARCH_LIMIT_47082)){
        goto L3; // [43] 52
    }

    /** symtab.e:352				exit*/
    goto L2; // [49] 168
L3: 

    /** symtab.e:354			if equal(d, SymTab[tp][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24441 = (object)*(((s1_ptr)_2)->base + _tp_47243);
    _2 = (object)SEQ_PTR(_24441);
    _24442 = (object)*(((s1_ptr)_2)->base + 1);
    _24441 = NOVALUE;
    if (_d_47240 == _24442)
    _24443 = 1;
    else if (IS_ATOM_INT(_d_47240) && IS_ATOM_INT(_24442))
    _24443 = 0;
    else
    _24443 = (compare(_d_47240, _24442) == 0);
    _24442 = NOVALUE;
    if (_24443 == 0)
    {
        _24443 = NOVALUE;
        goto L4; // [70] 140
    }
    else{
        _24443 = NOVALUE;
    }

    /** symtab.e:356				if tp != literal_init then*/
    if (_tp_47243 == _54literal_init_46788)
    goto L5; // [77] 133

    /** symtab.e:358					SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_47244 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24447 = (object)*(((s1_ptr)_2)->base + _tp_47243);
    _2 = (object)SEQ_PTR(_24447);
    _24448 = (object)*(((s1_ptr)_2)->base + 2);
    _24447 = NOVALUE;
    Ref(_24448);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24448;
    if( _1 != _24448 ){
        DeRef(_1);
    }
    _24448 = NOVALUE;
    _24445 = NOVALUE;

    /** symtab.e:359					SymTab[tp][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_tp_47243 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54literal_init_46788;
    DeRef(_1);
    _24449 = NOVALUE;

    /** symtab.e:360					literal_init = tp*/
    _54literal_init_46788 = _tp_47243;
L5: 

    /** symtab.e:362				return tp*/
    DeRef(_d_47240);
    return _tp_47243;
L4: 

    /** symtab.e:364			prev = tp*/
    _prev_47244 = _tp_47243;

    /** symtab.e:365			tp = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24451 = (object)*(((s1_ptr)_2)->base + _tp_47243);
    _2 = (object)SEQ_PTR(_24451);
    _tp_47243 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_tp_47243)){
        _tp_47243 = (object)DBL_PTR(_tp_47243)->dbl;
    }
    _24451 = NOVALUE;

    /** symtab.e:366		end while*/
    goto L1; // [165] 29
L2: 

    /** symtab.e:368		p = tmp_alloc()*/
    _p_47242 = _54tmp_alloc();
    if (!IS_ATOM_INT(_p_47242)) {
        _1 = (object)(DBL_PTR(_p_47242)->dbl);
        DeRefDS(_p_47242);
        _p_47242 = _1;
    }

    /** symtab.e:369		SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47242 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24454 = NOVALUE;

    /** symtab.e:370		SymTab[p][S_OBJ] = d*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47242 + ((s1_ptr)_2)->base);
    Ref(_d_47240);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _d_47240;
    DeRef(_1);
    _24456 = NOVALUE;

    /** symtab.e:372		if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L6; // [211] 285
    }
    else{
    }

    /** symtab.e:373			SymTab[p][S_MODE] = M_TEMP  -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47242 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _24458 = NOVALUE;

    /** symtab.e:374			SymTab[p][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47242 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24460 = NOVALUE;

    /** symtab.e:375			c_printf("object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24462 = (object)*(((s1_ptr)_2)->base + _p_47242);
    _2 = (object)SEQ_PTR(_24462);
    _24463 = (object)*(((s1_ptr)_2)->base + 34);
    _24462 = NOVALUE;
    RefDS(_24404);
    Ref(_24463);
    _55c_printf(_24404, _24463);
    _24463 = NOVALUE;

    /** symtab.e:376			c_hprintf("extern object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24464 = (object)*(((s1_ptr)_2)->base + _p_47242);
    _2 = (object)SEQ_PTR(_24464);
    _24465 = (object)*(((s1_ptr)_2)->base + 34);
    _24464 = NOVALUE;
    RefDS(_24407);
    Ref(_24465);
    _55c_hprintf(_24407, _24465);
    _24465 = NOVALUE;
L6: 

    /** symtab.e:379		SymTab[p][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47242 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54literal_init_46788;
    DeRef(_1);
    _24466 = NOVALUE;

    /** symtab.e:380		literal_init = p*/
    _54literal_init_46788 = _p_47242;

    /** symtab.e:381		return p*/
    DeRef(_d_47240);
    return _p_47242;
    ;
}


object _54NewTempSym(object _inlining_47314)
{
    object _p_47316 = NOVALUE;
    object _q_47317 = NOVALUE;
    object _24515 = NOVALUE;
    object _24513 = NOVALUE;
    object _24511 = NOVALUE;
    object _24509 = NOVALUE;
    object _24507 = NOVALUE;
    object _24505 = NOVALUE;
    object _24504 = NOVALUE;
    object _24503 = NOVALUE;
    object _24501 = NOVALUE;
    object _24500 = NOVALUE;
    object _24499 = NOVALUE;
    object _24497 = NOVALUE;
    object _24495 = NOVALUE;
    object _24492 = NOVALUE;
    object _24491 = NOVALUE;
    object _24490 = NOVALUE;
    object _24488 = NOVALUE;
    object _24486 = NOVALUE;
    object _24485 = NOVALUE;
    object _24484 = NOVALUE;
    object _24482 = NOVALUE;
    object _24480 = NOVALUE;
    object _24475 = NOVALUE;
    object _24474 = NOVALUE;
    object _24473 = NOVALUE;
    object _24472 = NOVALUE;
    object _24471 = NOVALUE;
    object _24470 = NOVALUE;
    object _24468 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:392		if inlining then*/
    if (_inlining_47314 == 0)
    {
        goto L1; // [5] 85
    }
    else{
    }

    /** symtab.e:393			p = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24468 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21455);
    _2 = (object)SEQ_PTR(_24468);
    if (!IS_ATOM_INT(_36S_TEMPS_21129)){
        _p_47316 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21129)->dbl));
    }
    else{
        _p_47316 = (object)*(((s1_ptr)_2)->base + _36S_TEMPS_21129);
    }
    if (!IS_ATOM_INT(_p_47316)){
        _p_47316 = (object)DBL_PTR(_p_47316)->dbl;
    }
    _24468 = NOVALUE;

    /** symtab.e:394			while p != 0 and SymTab[p][S_SCOPE] != FREE do*/
L2: 
    _24470 = (_p_47316 != 0);
    if (_24470 == 0) {
        goto L3; // [35] 93
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24472 = (object)*(((s1_ptr)_2)->base + _p_47316);
    _2 = (object)SEQ_PTR(_24472);
    _24473 = (object)*(((s1_ptr)_2)->base + 4);
    _24472 = NOVALUE;
    if (IS_ATOM_INT(_24473)) {
        _24474 = (_24473 != 0);
    }
    else {
        _24474 = binary_op(NOTEQ, _24473, 0);
    }
    _24473 = NOVALUE;
    if (_24474 <= 0) {
        if (_24474 == 0) {
            DeRef(_24474);
            _24474 = NOVALUE;
            goto L3; // [58] 93
        }
        else {
            if (!IS_ATOM_INT(_24474) && DBL_PTR(_24474)->dbl == 0.0){
                DeRef(_24474);
                _24474 = NOVALUE;
                goto L3; // [58] 93
            }
            DeRef(_24474);
            _24474 = NOVALUE;
        }
    }
    DeRef(_24474);
    _24474 = NOVALUE;

    /** symtab.e:395				p = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24475 = (object)*(((s1_ptr)_2)->base + _p_47316);
    _2 = (object)SEQ_PTR(_24475);
    _p_47316 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_47316)){
        _p_47316 = (object)DBL_PTR(_p_47316)->dbl;
    }
    _24475 = NOVALUE;

    /** symtab.e:396			end while*/
    goto L2; // [79] 31
    goto L3; // [82] 93
L1: 

    /** symtab.e:398			p = 0*/
    _p_47316 = 0;
L3: 

    /** symtab.e:401		if p = 0 then*/
    if (_p_47316 != 0)
    goto L4; // [97] 213

    /** symtab.e:403			temps_allocated += 1*/
    _54temps_allocated_47311 = _54temps_allocated_47311 + 1;

    /** symtab.e:404			p = tmp_alloc()*/
    _p_47316 = _54tmp_alloc();
    if (!IS_ATOM_INT(_p_47316)) {
        _1 = (object)(DBL_PTR(_p_47316)->dbl);
        DeRefDS(_p_47316);
        _p_47316 = _1;
    }

    /** symtab.e:405			SymTab[p][S_MODE] = M_TEMP*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47316 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _24480 = NOVALUE;

    /** symtab.e:406			SymTab[p][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47316 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24484 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21455);
    _2 = (object)SEQ_PTR(_24484);
    if (!IS_ATOM_INT(_36S_TEMPS_21129)){
        _24485 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21129)->dbl));
    }
    else{
        _24485 = (object)*(((s1_ptr)_2)->base + _36S_TEMPS_21129);
    }
    _24484 = NOVALUE;
    Ref(_24485);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24485;
    if( _1 != _24485 ){
        DeRef(_1);
    }
    _24485 = NOVALUE;
    _24482 = NOVALUE;

    /** symtab.e:407			SymTab[CurrentSub][S_TEMPS] = p*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21455 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TEMPS_21129))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21129)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TEMPS_21129);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_47316;
    DeRef(_1);
    _24486 = NOVALUE;

    /** symtab.e:409			if inlining then*/
    if (_inlining_47314 == 0)
    {
        goto L5; // [181] 343
    }
    else{
    }

    /** symtab.e:410				SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21455 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21144)){
        _24490 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21144)->dbl));
    }
    else{
        _24490 = (object)*(((s1_ptr)_2)->base + _36S_STACK_SPACE_21144);
    }
    _24488 = NOVALUE;
    if (IS_ATOM_INT(_24490)) {
        _24491 = _24490 + 1;
        if (_24491 > MAXINT){
            _24491 = NewDouble((eudouble)_24491);
        }
    }
    else
    _24491 = binary_op(PLUS, 1, _24490);
    _24490 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21144))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21144)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_STACK_SPACE_21144);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24491;
    if( _1 != _24491 ){
        DeRef(_1);
    }
    _24491 = NOVALUE;
    _24488 = NOVALUE;
    goto L5; // [210] 343
L4: 

    /** symtab.e:413		elsif TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L6; // [217] 342
    }
    else{
    }

    /** symtab.e:418			SymTab[p][S_SCOPE] = DELETED*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47316 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24492 = NOVALUE;

    /** symtab.e:420			q = tmp_alloc()*/
    _q_47317 = _54tmp_alloc();
    if (!IS_ATOM_INT(_q_47317)) {
        _1 = (object)(DBL_PTR(_q_47317)->dbl);
        DeRefDS(_q_47317);
        _q_47317 = _1;
    }

    /** symtab.e:421			SymTab[q][S_MODE] = M_TEMP*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47317 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _24495 = NOVALUE;

    /** symtab.e:422			SymTab[q][S_TEMP_NAME] = SymTab[p][S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47317 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24499 = (object)*(((s1_ptr)_2)->base + _p_47316);
    _2 = (object)SEQ_PTR(_24499);
    _24500 = (object)*(((s1_ptr)_2)->base + 34);
    _24499 = NOVALUE;
    Ref(_24500);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24500;
    if( _1 != _24500 ){
        DeRef(_1);
    }
    _24500 = NOVALUE;
    _24497 = NOVALUE;

    /** symtab.e:423			SymTab[q][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47317 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24503 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21455);
    _2 = (object)SEQ_PTR(_24503);
    if (!IS_ATOM_INT(_36S_TEMPS_21129)){
        _24504 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21129)->dbl));
    }
    else{
        _24504 = (object)*(((s1_ptr)_2)->base + _36S_TEMPS_21129);
    }
    _24503 = NOVALUE;
    Ref(_24504);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24504;
    if( _1 != _24504 ){
        DeRef(_1);
    }
    _24504 = NOVALUE;
    _24501 = NOVALUE;

    /** symtab.e:424			SymTab[CurrentSub][S_TEMPS] = q*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21455 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TEMPS_21129))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21129)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TEMPS_21129);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _q_47317;
    DeRef(_1);
    _24505 = NOVALUE;

    /** symtab.e:425			p = q*/
    _p_47316 = _q_47317;
L6: 
L5: 

    /** symtab.e:428		if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L7; // [347] 385
    }
    else{
    }

    /** symtab.e:429			SymTab[p][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47316 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    _24507 = NOVALUE;

    /** symtab.e:430			SymTab[p][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47316 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    _24509 = NOVALUE;
L7: 

    /** symtab.e:433		SymTab[p][S_OBJ] = NOVALUE*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47316 + ((s1_ptr)_2)->base);
    Ref(_36NOVALUE_21301);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21301;
    DeRef(_1);
    _24511 = NOVALUE;

    /** symtab.e:434		SymTab[p][S_USAGE] = T_UNKNOWN*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47316 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4;
    DeRef(_1);
    _24513 = NOVALUE;

    /** symtab.e:435		SymTab[p][S_SCOPE] = IN_USE*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47316 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _24515 = NOVALUE;

    /** symtab.e:437		return p*/
    DeRef(_24470);
    _24470 = NOVALUE;
    return _p_47316;
    ;
}


void _54InitSymTab()
{
    object _hashval_47433 = NOVALUE;
    object _len_47434 = NOVALUE;
    object _s_47436 = NOVALUE;
    object _st_index_47437 = NOVALUE;
    object _kname_47438 = NOVALUE;
    object _fixups_47439 = NOVALUE;
    object _si_47578 = NOVALUE;
    object _sj_47579 = NOVALUE;
    object _25101 = NOVALUE;
    object _25100 = NOVALUE;
    object _24630 = NOVALUE;
    object _24629 = NOVALUE;
    object _24628 = NOVALUE;
    object _24627 = NOVALUE;
    object _24626 = NOVALUE;
    object _24624 = NOVALUE;
    object _24623 = NOVALUE;
    object _24622 = NOVALUE;
    object _24621 = NOVALUE;
    object _24619 = NOVALUE;
    object _24617 = NOVALUE;
    object _24615 = NOVALUE;
    object _24614 = NOVALUE;
    object _24612 = NOVALUE;
    object _24610 = NOVALUE;
    object _24608 = NOVALUE;
    object _24607 = NOVALUE;
    object _24605 = NOVALUE;
    object _24604 = NOVALUE;
    object _24603 = NOVALUE;
    object _24602 = NOVALUE;
    object _24601 = NOVALUE;
    object _24598 = NOVALUE;
    object _24597 = NOVALUE;
    object _24596 = NOVALUE;
    object _24594 = NOVALUE;
    object _24593 = NOVALUE;
    object _24592 = NOVALUE;
    object _24590 = NOVALUE;
    object _24589 = NOVALUE;
    object _24588 = NOVALUE;
    object _24585 = NOVALUE;
    object _24583 = NOVALUE;
    object _24581 = NOVALUE;
    object _24580 = NOVALUE;
    object _24577 = NOVALUE;
    object _24576 = NOVALUE;
    object _24574 = NOVALUE;
    object _24572 = NOVALUE;
    object _24570 = NOVALUE;
    object _24568 = NOVALUE;
    object _24567 = NOVALUE;
    object _24566 = NOVALUE;
    object _24563 = NOVALUE;
    object _24562 = NOVALUE;
    object _24560 = NOVALUE;
    object _24559 = NOVALUE;
    object _24557 = NOVALUE;
    object _24556 = NOVALUE;
    object _24555 = NOVALUE;
    object _24553 = NOVALUE;
    object _24551 = NOVALUE;
    object _24550 = NOVALUE;
    object _24548 = NOVALUE;
    object _24547 = NOVALUE;
    object _24546 = NOVALUE;
    object _24544 = NOVALUE;
    object _24543 = NOVALUE;
    object _24542 = NOVALUE;
    object _24540 = NOVALUE;
    object _24539 = NOVALUE;
    object _24538 = NOVALUE;
    object _24536 = NOVALUE;
    object _24535 = NOVALUE;
    object _24534 = NOVALUE;
    object _24533 = NOVALUE;
    object _24532 = NOVALUE;
    object _24531 = NOVALUE;
    object _24530 = NOVALUE;
    object _24529 = NOVALUE;
    object _24528 = NOVALUE;
    object _24527 = NOVALUE;
    object _24525 = NOVALUE;
    object _24524 = NOVALUE;
    object _24523 = NOVALUE;
    object _24522 = NOVALUE;
    object _24518 = NOVALUE;
    object _24517 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:445		sequence kname, fixups = {}*/
    RefDS(_21997);
    DeRefi(_fixups_47439);
    _fixups_47439 = _21997;

    /** symtab.e:447		for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_63keylist_23121)){
            _24517 = SEQ_PTR(_63keylist_23121)->length;
    }
    else {
        _24517 = 1;
    }
    {
        object _k_47441;
        _k_47441 = 1;
L1: 
        if (_k_47441 > _24517){
            goto L2; // [15] 560
        }

        /** symtab.e:448			kname = keylist[k][K_NAME]*/
        _2 = (object)SEQ_PTR(_63keylist_23121);
        _24518 = (object)*(((s1_ptr)_2)->base + _k_47441);
        DeRef(_kname_47438);
        _2 = (object)SEQ_PTR(_24518);
        _kname_47438 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_kname_47438);
        _24518 = NOVALUE;

        /** symtab.e:449			len = length(kname)*/
        if (IS_SEQUENCE(_kname_47438)){
                _len_47434 = SEQ_PTR(_kname_47438)->length;
        }
        else {
            _len_47434 = 1;
        }

        /** symtab.e:450			hashval = hashfn(kname)*/
        RefDS(_kname_47438);
        _hashval_47433 = _54hashfn(_kname_47438);
        if (!IS_ATOM_INT(_hashval_47433)) {
            _1 = (object)(DBL_PTR(_hashval_47433)->dbl);
            DeRefDS(_hashval_47433);
            _hashval_47433 = _1;
        }

        /** symtab.e:451			st_index = NewEntry(kname,*/
        _2 = (object)SEQ_PTR(_63keylist_23121);
        _24522 = (object)*(((s1_ptr)_2)->base + _k_47441);
        _2 = (object)SEQ_PTR(_24522);
        _24523 = (object)*(((s1_ptr)_2)->base + 2);
        _24522 = NOVALUE;
        _2 = (object)SEQ_PTR(_63keylist_23121);
        _24524 = (object)*(((s1_ptr)_2)->base + _k_47441);
        _2 = (object)SEQ_PTR(_24524);
        _24525 = (object)*(((s1_ptr)_2)->base + 3);
        _24524 = NOVALUE;
        RefDS(_kname_47438);
        Ref(_24523);
        Ref(_24525);
        _st_index_47437 = _54NewEntry(_kname_47438, 0, _24523, _24525, _hashval_47433, 0, 0);
        _24523 = NOVALUE;
        _24525 = NOVALUE;
        if (!IS_ATOM_INT(_st_index_47437)) {
            _1 = (object)(DBL_PTR(_st_index_47437)->dbl);
            DeRefDS(_st_index_47437);
            _st_index_47437 = _1;
        }

        /** symtab.e:456			if find(keylist[k][K_TOKEN], RTN_TOKS) then*/
        _2 = (object)SEQ_PTR(_63keylist_23121);
        _24527 = (object)*(((s1_ptr)_2)->base + _k_47441);
        _2 = (object)SEQ_PTR(_24527);
        _24528 = (object)*(((s1_ptr)_2)->base + 3);
        _24527 = NOVALUE;
        _24529 = find_from(_24528, _38RTN_TOKS_16045, 1);
        _24528 = NOVALUE;
        if (_24529 == 0)
        {
            _24529 = NOVALUE;
            goto L3; // [110] 325
        }
        else{
            _24529 = NOVALUE;
        }

        /** symtab.e:457				SymTab[st_index] = SymTab[st_index] &*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24530 = (object)*(((s1_ptr)_2)->base + _st_index_47437);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24531 = (object)*(((s1_ptr)_2)->base + _st_index_47437);
        if (IS_SEQUENCE(_24531)){
                _24532 = SEQ_PTR(_24531)->length;
        }
        else {
            _24532 = 1;
        }
        _24531 = NOVALUE;
        _24533 = _36SIZEOF_ROUTINE_ENTRY_21210 - _24532;
        _24532 = NOVALUE;
        _24534 = Repeat(0, _24533);
        _24533 = NOVALUE;
        if (IS_SEQUENCE(_24530) && IS_ATOM(_24534)) {
        }
        else if (IS_ATOM(_24530) && IS_SEQUENCE(_24534)) {
            Ref(_24530);
            Prepend(&_24535, _24534, _24530);
        }
        else {
            Concat((object_ptr)&_24535, _24530, _24534);
            _24530 = NOVALUE;
        }
        _24530 = NOVALUE;
        DeRefDS(_24534);
        _24534 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _st_index_47437);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24535;
        if( _1 != _24535 ){
            DeRef(_1);
        }
        _24535 = NOVALUE;

        /** symtab.e:460				SymTab[st_index][S_NUM_ARGS] = keylist[k][K_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47437 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23121);
        _24538 = (object)*(((s1_ptr)_2)->base + _k_47441);
        _2 = (object)SEQ_PTR(_24538);
        _24539 = (object)*(((s1_ptr)_2)->base + 5);
        _24538 = NOVALUE;
        Ref(_24539);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_36S_NUM_ARGS_21135))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24539;
        if( _1 != _24539 ){
            DeRef(_1);
        }
        _24539 = NOVALUE;
        _24536 = NOVALUE;

        /** symtab.e:461				SymTab[st_index][S_OPCODE] = keylist[k][K_OPCODE]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47437 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23121);
        _24542 = (object)*(((s1_ptr)_2)->base + _k_47441);
        _2 = (object)SEQ_PTR(_24542);
        _24543 = (object)*(((s1_ptr)_2)->base + 4);
        _24542 = NOVALUE;
        Ref(_24543);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 21);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24543;
        if( _1 != _24543 ){
            DeRef(_1);
        }
        _24543 = NOVALUE;
        _24540 = NOVALUE;

        /** symtab.e:462				SymTab[st_index][S_EFFECT] = keylist[k][K_EFFECT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47437 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23121);
        _24546 = (object)*(((s1_ptr)_2)->base + _k_47441);
        _2 = (object)SEQ_PTR(_24546);
        _24547 = (object)*(((s1_ptr)_2)->base + 6);
        _24546 = NOVALUE;
        Ref(_24547);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 23);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24547;
        if( _1 != _24547 ){
            DeRef(_1);
        }
        _24547 = NOVALUE;
        _24544 = NOVALUE;

        /** symtab.e:463				SymTab[st_index][S_REFLIST] = {}*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47437 + ((s1_ptr)_2)->base);
        RefDS(_21997);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 24);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _21997;
        DeRef(_1);
        _24548 = NOVALUE;

        /** symtab.e:464				if length(keylist[k]) > K_EFFECT then*/
        _2 = (object)SEQ_PTR(_63keylist_23121);
        _24550 = (object)*(((s1_ptr)_2)->base + _k_47441);
        if (IS_SEQUENCE(_24550)){
                _24551 = SEQ_PTR(_24550)->length;
        }
        else {
            _24551 = 1;
        }
        _24550 = NOVALUE;
        if (_24551 <= 6)
        goto L4; // [259] 324

        /** symtab.e:465				    SymTab[st_index][S_CODE] = keylist[k][K_CODE]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47437 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23121);
        _24555 = (object)*(((s1_ptr)_2)->base + _k_47441);
        _2 = (object)SEQ_PTR(_24555);
        _24556 = (object)*(((s1_ptr)_2)->base + 7);
        _24555 = NOVALUE;
        Ref(_24556);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_36S_CODE_21096))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21096)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21096);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24556;
        if( _1 != _24556 ){
            DeRef(_1);
        }
        _24556 = NOVALUE;
        _24553 = NOVALUE;

        /** symtab.e:466				    SymTab[st_index][S_DEF_ARGS] = keylist[k][K_DEF_ARGS]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47437 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23121);
        _24559 = (object)*(((s1_ptr)_2)->base + _k_47441);
        _2 = (object)SEQ_PTR(_24559);
        _24560 = (object)*(((s1_ptr)_2)->base + 8);
        _24559 = NOVALUE;
        Ref(_24560);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 28);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24560;
        if( _1 != _24560 ){
            DeRef(_1);
        }
        _24560 = NOVALUE;
        _24557 = NOVALUE;

        /** symtab.e:467				    fixups &= st_index*/
        Append(&_fixups_47439, _fixups_47439, _st_index_47437);
L4: 
L3: 

        /** symtab.e:470			if keylist[k][K_TOKEN] = PROC then*/
        _2 = (object)SEQ_PTR(_63keylist_23121);
        _24562 = (object)*(((s1_ptr)_2)->base + _k_47441);
        _2 = (object)SEQ_PTR(_24562);
        _24563 = (object)*(((s1_ptr)_2)->base + 3);
        _24562 = NOVALUE;
        if (binary_op_a(NOTEQ, _24563, 27)){
            _24563 = NOVALUE;
            goto L5; // [341] 365
        }
        _24563 = NOVALUE;

        /** symtab.e:471				if equal(kname, "<TopLevel>") then*/
        if (_kname_47438 == _24565)
        _24566 = 1;
        else if (IS_ATOM_INT(_kname_47438) && IS_ATOM_INT(_24565))
        _24566 = 0;
        else
        _24566 = (compare(_kname_47438, _24565) == 0);
        if (_24566 == 0)
        {
            _24566 = NOVALUE;
            goto L6; // [351] 462
        }
        else{
            _24566 = NOVALUE;
        }

        /** symtab.e:472					TopLevelSub = st_index*/
        _36TopLevelSub_21454 = _st_index_47437;
        goto L6; // [362] 462
L5: 

        /** symtab.e:474			elsif keylist[k][K_TOKEN] = TYPE then*/
        _2 = (object)SEQ_PTR(_63keylist_23121);
        _24567 = (object)*(((s1_ptr)_2)->base + _k_47441);
        _2 = (object)SEQ_PTR(_24567);
        _24568 = (object)*(((s1_ptr)_2)->base + 3);
        _24567 = NOVALUE;
        if (binary_op_a(NOTEQ, _24568, 504)){
            _24568 = NOVALUE;
            goto L7; // [381] 461
        }
        _24568 = NOVALUE;

        /** symtab.e:475				if equal(kname, "object") then*/
        if (_kname_47438 == _22959)
        _24570 = 1;
        else if (IS_ATOM_INT(_kname_47438) && IS_ATOM_INT(_22959))
        _24570 = 0;
        else
        _24570 = (compare(_kname_47438, _22959) == 0);
        if (_24570 == 0)
        {
            _24570 = NOVALUE;
            goto L8; // [391] 404
        }
        else{
            _24570 = NOVALUE;
        }

        /** symtab.e:476					object_type = st_index*/
        _54object_type_46780 = _st_index_47437;
        goto L9; // [401] 460
L8: 

        /** symtab.e:477				elsif equal(kname, "atom") then*/
        if (_kname_47438 == _24571)
        _24572 = 1;
        else if (IS_ATOM_INT(_kname_47438) && IS_ATOM_INT(_24571))
        _24572 = 0;
        else
        _24572 = (compare(_kname_47438, _24571) == 0);
        if (_24572 == 0)
        {
            _24572 = NOVALUE;
            goto LA; // [410] 423
        }
        else{
            _24572 = NOVALUE;
        }

        /** symtab.e:478					atom_type = st_index*/
        _54atom_type_46782 = _st_index_47437;
        goto L9; // [420] 460
LA: 

        /** symtab.e:479				elsif equal(kname, "integer") then*/
        if (_kname_47438 == _24573)
        _24574 = 1;
        else if (IS_ATOM_INT(_kname_47438) && IS_ATOM_INT(_24573))
        _24574 = 0;
        else
        _24574 = (compare(_kname_47438, _24573) == 0);
        if (_24574 == 0)
        {
            _24574 = NOVALUE;
            goto LB; // [429] 442
        }
        else{
            _24574 = NOVALUE;
        }

        /** symtab.e:480					integer_type = st_index*/
        _54integer_type_46786 = _st_index_47437;
        goto L9; // [439] 460
LB: 

        /** symtab.e:481				elsif equal(kname, "sequence") then*/
        if (_kname_47438 == _24575)
        _24576 = 1;
        else if (IS_ATOM_INT(_kname_47438) && IS_ATOM_INT(_24575))
        _24576 = 0;
        else
        _24576 = (compare(_kname_47438, _24575) == 0);
        if (_24576 == 0)
        {
            _24576 = NOVALUE;
            goto LC; // [448] 459
        }
        else{
            _24576 = NOVALUE;
        }

        /** symtab.e:482					sequence_type = st_index*/
        _54sequence_type_46784 = _st_index_47437;
LC: 
L9: 
L7: 
L6: 

        /** symtab.e:485			if buckets[hashval] = 0 then*/
        _2 = (object)SEQ_PTR(_54buckets_46776);
        _24577 = (object)*(((s1_ptr)_2)->base + _hashval_47433);
        if (binary_op_a(NOTEQ, _24577, 0)){
            _24577 = NOVALUE;
            goto LD; // [470] 485
        }
        _24577 = NOVALUE;

        /** symtab.e:486				buckets[hashval] = st_index*/
        _2 = (object)SEQ_PTR(_54buckets_46776);
        _2 = (object)(((s1_ptr)_2)->base + _hashval_47433);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _st_index_47437;
        DeRef(_1);
        goto LE; // [482] 553
LD: 

        /** symtab.e:488				s = buckets[hashval]*/
        _2 = (object)SEQ_PTR(_54buckets_46776);
        _s_47436 = (object)*(((s1_ptr)_2)->base + _hashval_47433);
        if (!IS_ATOM_INT(_s_47436)){
            _s_47436 = (object)DBL_PTR(_s_47436)->dbl;
        }

        /** symtab.e:489				while SymTab[s][S_SAMEHASH] != 0 do*/
LF: 
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24580 = (object)*(((s1_ptr)_2)->base + _s_47436);
        _2 = (object)SEQ_PTR(_24580);
        _24581 = (object)*(((s1_ptr)_2)->base + 9);
        _24580 = NOVALUE;
        if (binary_op_a(EQUALS, _24581, 0)){
            _24581 = NOVALUE;
            goto L10; // [512] 537
        }
        _24581 = NOVALUE;

        /** symtab.e:490					s = SymTab[s][S_SAMEHASH]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24583 = (object)*(((s1_ptr)_2)->base + _s_47436);
        _2 = (object)SEQ_PTR(_24583);
        _s_47436 = (object)*(((s1_ptr)_2)->base + 9);
        if (!IS_ATOM_INT(_s_47436)){
            _s_47436 = (object)DBL_PTR(_s_47436)->dbl;
        }
        _24583 = NOVALUE;

        /** symtab.e:491				end while*/
        goto LF; // [534] 500
L10: 

        /** symtab.e:492				SymTab[s][S_SAMEHASH] = st_index*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_47436 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 9);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _st_index_47437;
        DeRef(_1);
        _24585 = NOVALUE;
LE: 

        /** symtab.e:494		end for*/
        _k_47441 = _k_47441 + 1;
        goto L1; // [555] 22
L2: 
        ;
    }

    /** symtab.e:495		file_start_sym = length(SymTab)*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _36file_start_sym_21453 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _36file_start_sym_21453 = 1;
    }

    /** symtab.e:497		sequence si, sj*/

    /** symtab.e:498		CurrentSub = TopLevelSub*/
    _36CurrentSub_21455 = _36TopLevelSub_21454;

    /** symtab.e:499		for i=1 to length(fixups) do*/
    if (IS_SEQUENCE(_fixups_47439)){
            _24588 = SEQ_PTR(_fixups_47439)->length;
    }
    else {
        _24588 = 1;
    }
    {
        object _i_47583;
        _i_47583 = 1;
L11: 
        if (_i_47583 > _24588){
            goto L12; // [585] 946
        }

        /** symtab.e:500		    si = SymTab[fixups[i]][S_CODE] -- seq of either 0's or sequences of tokens*/
        _2 = (object)SEQ_PTR(_fixups_47439);
        _24589 = (object)*(((s1_ptr)_2)->base + _i_47583);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24590 = (object)*(((s1_ptr)_2)->base + _24589);
        DeRef(_si_47578);
        _2 = (object)SEQ_PTR(_24590);
        if (!IS_ATOM_INT(_36S_CODE_21096)){
            _si_47578 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21096)->dbl));
        }
        else{
            _si_47578 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21096);
        }
        Ref(_si_47578);
        _24590 = NOVALUE;

        /** symtab.e:501		    for j=1 to length(si) do*/
        if (IS_SEQUENCE(_si_47578)){
                _24592 = SEQ_PTR(_si_47578)->length;
        }
        else {
            _24592 = 1;
        }
        {
            object _j_47591;
            _j_47591 = 1;
L13: 
            if (_j_47591 > _24592){
                goto L14; // [617] 920
            }

            /** symtab.e:502		        if sequence(si[j]) then*/
            _2 = (object)SEQ_PTR(_si_47578);
            _24593 = (object)*(((s1_ptr)_2)->base + _j_47591);
            _24594 = IS_SEQUENCE(_24593);
            _24593 = NOVALUE;
            if (_24594 == 0)
            {
                _24594 = NOVALUE;
                goto L15; // [633] 913
            }
            else{
                _24594 = NOVALUE;
            }

            /** symtab.e:503		            sj = si[j] -- a sequence of tokens*/
            DeRef(_sj_47579);
            _2 = (object)SEQ_PTR(_si_47578);
            _sj_47579 = (object)*(((s1_ptr)_2)->base + _j_47591);
            Ref(_sj_47579);

            /** symtab.e:504					for ij=1 to length(sj) do*/
            if (IS_SEQUENCE(_sj_47579)){
                    _24596 = SEQ_PTR(_sj_47579)->length;
            }
            else {
                _24596 = 1;
            }
            {
                object _ij_47598;
                _ij_47598 = 1;
L16: 
                if (_ij_47598 > _24596){
                    goto L17; // [649] 906
                }

                /** symtab.e:505		                switch sj[ij][T_ID] with fallthru do*/
                _2 = (object)SEQ_PTR(_sj_47579);
                _24597 = (object)*(((s1_ptr)_2)->base + _ij_47598);
                _2 = (object)SEQ_PTR(_24597);
                _24598 = (object)*(((s1_ptr)_2)->base + 1);
                _24597 = NOVALUE;
                if (IS_SEQUENCE(_24598) ){
                    goto L18; // [668] 899
                }
                if(!IS_ATOM_INT(_24598)){
                    if( (DBL_PTR(_24598)->dbl != (eudouble) ((object) DBL_PTR(_24598)->dbl) ) ){
                        goto L18; // [668] 899
                    }
                    _0 = (object) DBL_PTR(_24598)->dbl;
                }
                else {
                    _0 = _24598;
                };
                _24598 = NOVALUE;
                switch ( _0 ){ 

                    /** symtab.e:506		                    case ATOM then -- must create a lasting temp*/
                    case 502:

                    /** symtab.e:507		                    	if is_integer(sj[ij][T_SYM]) then*/
                    _2 = (object)SEQ_PTR(_sj_47579);
                    _24601 = (object)*(((s1_ptr)_2)->base + _ij_47598);
                    _2 = (object)SEQ_PTR(_24601);
                    _24602 = (object)*(((s1_ptr)_2)->base + 2);
                    _24601 = NOVALUE;
                    Ref(_24602);
                    _24603 = _36is_integer(_24602);
                    _24602 = NOVALUE;
                    if (_24603 == 0) {
                        DeRef(_24603);
                        _24603 = NOVALUE;
                        goto L19; // [693] 717
                    }
                    else {
                        if (!IS_ATOM_INT(_24603) && DBL_PTR(_24603)->dbl == 0.0){
                            DeRef(_24603);
                            _24603 = NOVALUE;
                            goto L19; // [693] 717
                        }
                        DeRef(_24603);
                        _24603 = NOVALUE;
                    }
                    DeRef(_24603);
                    _24603 = NOVALUE;

                    /** symtab.e:508									st_index = NewIntSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47579);
                    _24604 = (object)*(((s1_ptr)_2)->base + _ij_47598);
                    _2 = (object)SEQ_PTR(_24604);
                    _24605 = (object)*(((s1_ptr)_2)->base + 2);
                    _24604 = NOVALUE;
                    Ref(_24605);
                    _st_index_47437 = _54NewIntSym(_24605);
                    _24605 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47437)) {
                        _1 = (object)(DBL_PTR(_st_index_47437)->dbl);
                        DeRefDS(_st_index_47437);
                        _st_index_47437 = _1;
                    }
                    goto L1A; // [714] 736
L19: 

                    /** symtab.e:510									st_index = NewDoubleSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47579);
                    _24607 = (object)*(((s1_ptr)_2)->base + _ij_47598);
                    _2 = (object)SEQ_PTR(_24607);
                    _24608 = (object)*(((s1_ptr)_2)->base + 2);
                    _24607 = NOVALUE;
                    Ref(_24608);
                    _st_index_47437 = _54NewDoubleSym(_24608);
                    _24608 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47437)) {
                        _1 = (object)(DBL_PTR(_st_index_47437)->dbl);
                        DeRefDS(_st_index_47437);
                        _st_index_47437 = _1;
                    }
L1A: 

                    /** symtab.e:512								SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (object)SEQ_PTR(_37SymTab_15406);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _37SymTab_15406 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_st_index_47437 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 4);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = 1;
                    DeRef(_1);
                    _24610 = NOVALUE;

                    /** symtab.e:513								sj[ij][T_SYM] = st_index*/
                    _2 = (object)SEQ_PTR(_sj_47579);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47579 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_47598 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _st_index_47437;
                    DeRef(_1);
                    _24612 = NOVALUE;

                    /** symtab.e:514								break*/
                    goto L18; // [770] 899

                    /** symtab.e:515							case STRING then -- same*/
                    case 503:

                    /** symtab.e:516		                    	st_index = NewStringSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47579);
                    _24614 = (object)*(((s1_ptr)_2)->base + _ij_47598);
                    _2 = (object)SEQ_PTR(_24614);
                    _24615 = (object)*(((s1_ptr)_2)->base + 2);
                    _24614 = NOVALUE;
                    Ref(_24615);
                    _st_index_47437 = _54NewStringSym(_24615);
                    _24615 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47437)) {
                        _1 = (object)(DBL_PTR(_st_index_47437)->dbl);
                        DeRefDS(_st_index_47437);
                        _st_index_47437 = _1;
                    }

                    /** symtab.e:517								SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (object)SEQ_PTR(_37SymTab_15406);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _37SymTab_15406 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_st_index_47437 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 4);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = 1;
                    DeRef(_1);
                    _24617 = NOVALUE;

                    /** symtab.e:518								sj[ij][T_SYM] = st_index*/
                    _2 = (object)SEQ_PTR(_sj_47579);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47579 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_47598 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _st_index_47437;
                    DeRef(_1);
                    _24619 = NOVALUE;

                    /** symtab.e:519								break*/
                    goto L18; // [826] 899

                    /** symtab.e:520							case BUILT_IN then -- name of a builtin in econd field*/
                    case 511:

                    /** symtab.e:521	                            sj[ij] = keyfind(sj[ij][T_SYM],-1)*/
                    _2 = (object)SEQ_PTR(_sj_47579);
                    _24621 = (object)*(((s1_ptr)_2)->base + _ij_47598);
                    _2 = (object)SEQ_PTR(_24621);
                    _24622 = (object)*(((s1_ptr)_2)->base + 2);
                    _24621 = NOVALUE;
                    Ref(_24622);
                    DeRef(_25100);
                    _25100 = _24622;
                    _25101 = _54hashfn(_25100);
                    _25100 = NOVALUE;
                    Ref(_24622);
                    _24623 = _54keyfind(_24622, -1, _36current_file_no_21447, 0, _25101);
                    _24622 = NOVALUE;
                    _25101 = NOVALUE;
                    _2 = (object)SEQ_PTR(_sj_47579);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47579 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + _ij_47598);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _24623;
                    if( _1 != _24623 ){
                        DeRef(_1);
                    }
                    _24623 = NOVALUE;

                    /** symtab.e:522								break*/
                    goto L18; // [867] 899

                    /** symtab.e:523							case DEF_PARAM then*/
                    case 510:

                    /** symtab.e:524								sj[ij][T_SYM] &= fixups[i]*/
                    _2 = (object)SEQ_PTR(_sj_47579);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47579 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_47598 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(_fixups_47439);
                    _24626 = (object)*(((s1_ptr)_2)->base + _i_47583);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    _24627 = (object)*(((s1_ptr)_2)->base + 2);
                    _24624 = NOVALUE;
                    if (IS_SEQUENCE(_24627) && IS_ATOM(_24626)) {
                        Append(&_24628, _24627, _24626);
                    }
                    else if (IS_ATOM(_24627) && IS_SEQUENCE(_24626)) {
                    }
                    else {
                        Concat((object_ptr)&_24628, _24627, _24626);
                        _24627 = NOVALUE;
                    }
                    _24627 = NOVALUE;
                    _24626 = NOVALUE;
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _24628;
                    if( _1 != _24628 ){
                        DeRef(_1);
                    }
                    _24628 = NOVALUE;
                    _24624 = NOVALUE;
                ;}L18: 

                /** symtab.e:526					end for*/
                _ij_47598 = _ij_47598 + 1;
                goto L16; // [901] 656
L17: 
                ;
            }

            /** symtab.e:527					si[j] = sj*/
            RefDS(_sj_47579);
            _2 = (object)SEQ_PTR(_si_47578);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _si_47578 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _j_47591);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _sj_47579;
            DeRef(_1);
L15: 

            /** symtab.e:529			end for*/
            _j_47591 = _j_47591 + 1;
            goto L13; // [915] 624
L14: 
            ;
        }

        /** symtab.e:530			SymTab[fixups[i]][S_CODE] = si*/
        _2 = (object)SEQ_PTR(_fixups_47439);
        _24629 = (object)*(((s1_ptr)_2)->base + _i_47583);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_24629 + ((s1_ptr)_2)->base);
        RefDS(_si_47578);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_36S_CODE_21096))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21096)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21096);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _si_47578;
        DeRef(_1);
        _24630 = NOVALUE;

        /** symtab.e:531		end for*/
        _i_47583 = _i_47583 + 1;
        goto L11; // [941] 592
L12: 
        ;
    }

    /** symtab.e:532	end procedure*/
    DeRef(_kname_47438);
    DeRefi(_fixups_47439);
    DeRef(_si_47578);
    DeRef(_sj_47579);
    _24550 = NOVALUE;
    _24589 = NOVALUE;
    _24531 = NOVALUE;
    _24629 = NOVALUE;
    return;
    ;
}


void _54add_ref(object _tok_47667)
{
    object _s_47669 = NOVALUE;
    object _24646 = NOVALUE;
    object _24645 = NOVALUE;
    object _24643 = NOVALUE;
    object _24642 = NOVALUE;
    object _24641 = NOVALUE;
    object _24639 = NOVALUE;
    object _24638 = NOVALUE;
    object _24637 = NOVALUE;
    object _24636 = NOVALUE;
    object _24635 = NOVALUE;
    object _24634 = NOVALUE;
    object _24633 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:538		s = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_47667);
    _s_47669 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_47669)){
        _s_47669 = (object)DBL_PTR(_s_47669)->dbl;
    }

    /** symtab.e:539		if s != CurrentSub and -- ignore self-ref's*/
    _24633 = (_s_47669 != _36CurrentSub_21455);
    if (_24633 == 0) {
        goto L1; // [19] 98
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24635 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21455);
    _2 = (object)SEQ_PTR(_24635);
    _24636 = (object)*(((s1_ptr)_2)->base + 24);
    _24635 = NOVALUE;
    _24637 = find_from(_s_47669, _24636, 1);
    _24636 = NOVALUE;
    _24638 = (_24637 == 0);
    _24637 = NOVALUE;
    if (_24638 == 0)
    {
        DeRef(_24638);
        _24638 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        DeRef(_24638);
        _24638 = NOVALUE;
    }

    /** symtab.e:542			SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_47669 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24641 = (object)*(((s1_ptr)_2)->base + 12);
    _24639 = NOVALUE;
    if (IS_ATOM_INT(_24641)) {
        _24642 = _24641 + 1;
        if (_24642 > MAXINT){
            _24642 = NewDouble((eudouble)_24642);
        }
    }
    else
    _24642 = binary_op(PLUS, 1, _24641);
    _24641 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24642;
    if( _1 != _24642 ){
        DeRef(_1);
    }
    _24642 = NOVALUE;
    _24639 = NOVALUE;

    /** symtab.e:543			SymTab[CurrentSub][S_REFLIST] &= s*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21455 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24645 = (object)*(((s1_ptr)_2)->base + 24);
    _24643 = NOVALUE;
    if (IS_SEQUENCE(_24645) && IS_ATOM(_s_47669)) {
        Append(&_24646, _24645, _s_47669);
    }
    else if (IS_ATOM(_24645) && IS_SEQUENCE(_s_47669)) {
    }
    else {
        Concat((object_ptr)&_24646, _24645, _s_47669);
        _24645 = NOVALUE;
    }
    _24645 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24646;
    if( _1 != _24646 ){
        DeRef(_1);
    }
    _24646 = NOVALUE;
    _24643 = NOVALUE;
L1: 

    /** symtab.e:545	end procedure*/
    DeRef(_tok_47667);
    DeRef(_24633);
    _24633 = NOVALUE;
    return;
    ;
}


void _54mark_all(object _attribute_47699)
{
    object _p_47702 = NOVALUE;
    object _sym_file_47709 = NOVALUE;
    object _scope_47726 = NOVALUE;
    object _24678 = NOVALUE;
    object _24677 = NOVALUE;
    object _24676 = NOVALUE;
    object _24674 = NOVALUE;
    object _24672 = NOVALUE;
    object _24671 = NOVALUE;
    object _24670 = NOVALUE;
    object _24669 = NOVALUE;
    object _24668 = NOVALUE;
    object _24666 = NOVALUE;
    object _24665 = NOVALUE;
    object _24664 = NOVALUE;
    object _24663 = NOVALUE;
    object _24659 = NOVALUE;
    object _24658 = NOVALUE;
    object _24657 = NOVALUE;
    object _24655 = NOVALUE;
    object _24654 = NOVALUE;
    object _24652 = NOVALUE;
    object _24650 = NOVALUE;
    object _24647 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:550		if just_mark_everything_from then*/
    if (_54just_mark_everything_from_47696 == 0)
    {
        goto L1; // [7] 270
    }
    else{
    }

    /** symtab.e:551			symtab_pointer p = SymTab[just_mark_everything_from][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24647 = (object)*(((s1_ptr)_2)->base + _54just_mark_everything_from_47696);
    _2 = (object)SEQ_PTR(_24647);
    _p_47702 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_47702)){
        _p_47702 = (object)DBL_PTR(_p_47702)->dbl;
    }
    _24647 = NOVALUE;

    /** symtab.e:552			while p != 0 do*/
L2: 
    if (_p_47702 == 0)
    goto L3; // [33] 269

    /** symtab.e:553				integer sym_file = SymTab[p][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24650 = (object)*(((s1_ptr)_2)->base + _p_47702);
    _2 = (object)SEQ_PTR(_24650);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _sym_file_47709 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _sym_file_47709 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    if (!IS_ATOM_INT(_sym_file_47709)){
        _sym_file_47709 = (object)DBL_PTR(_sym_file_47709)->dbl;
    }
    _24650 = NOVALUE;

    /** symtab.e:554				just_mark_everything_from = p*/
    _54just_mark_everything_from_47696 = _p_47702;

    /** symtab.e:555				if sym_file = current_file_no or map:has( recheck_routines, sym_file ) then*/
    _24652 = (_sym_file_47709 == _36current_file_no_21447);
    if (_24652 != 0) {
        goto L4; // [68] 84
    }
    Ref(_54recheck_routines_47769);
    _24654 = _29has(_54recheck_routines_47769, _sym_file_47709);
    if (_24654 == 0) {
        DeRef(_24654);
        _24654 = NOVALUE;
        goto L5; // [80] 108
    }
    else {
        if (!IS_ATOM_INT(_24654) && DBL_PTR(_24654)->dbl == 0.0){
            DeRef(_24654);
            _24654 = NOVALUE;
            goto L5; // [80] 108
        }
        DeRef(_24654);
        _24654 = NOVALUE;
    }
    DeRef(_24654);
    _24654 = NOVALUE;
L4: 

    /** symtab.e:556					SymTab[p][attribute] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47702 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24657 = (object)*(((s1_ptr)_2)->base + _attribute_47699);
    _24655 = NOVALUE;
    if (IS_ATOM_INT(_24657)) {
        _24658 = _24657 + 1;
        if (_24658 > MAXINT){
            _24658 = NewDouble((eudouble)_24658);
        }
    }
    else
    _24658 = binary_op(PLUS, 1, _24657);
    _24657 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _attribute_47699);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24658;
    if( _1 != _24658 ){
        DeRef(_1);
    }
    _24658 = NOVALUE;
    _24655 = NOVALUE;
    goto L6; // [105] 246
L5: 

    /** symtab.e:558					integer scope = SymTab[p][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24659 = (object)*(((s1_ptr)_2)->base + _p_47702);
    _2 = (object)SEQ_PTR(_24659);
    _scope_47726 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_47726)){
        _scope_47726 = (object)DBL_PTR(_scope_47726)->dbl;
    }
    _24659 = NOVALUE;

    /** symtab.e:559					switch scope with fallthru do*/
    _0 = _scope_47726;
    switch ( _0 ){ 

        /** symtab.e:560						case SC_PUBLIC then*/
        case 13:

        /** symtab.e:561							if and_bits( DIRECT_OR_PUBLIC_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _24663 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
        _2 = (object)SEQ_PTR(_24663);
        _24664 = (object)*(((s1_ptr)_2)->base + _sym_file_47709);
        _24663 = NOVALUE;
        if (IS_ATOM_INT(_24664)) {
            {uintptr_t tu;
                 tu = (uintptr_t)6 & (uintptr_t)_24664;
                 _24665 = MAKE_UINT(tu);
            }
        }
        else {
            _24665 = binary_op(AND_BITS, 6, _24664);
        }
        _24664 = NOVALUE;
        if (_24665 == 0) {
            DeRef(_24665);
            _24665 = NOVALUE;
            goto L7; // [155] 243
        }
        else {
            if (!IS_ATOM_INT(_24665) && DBL_PTR(_24665)->dbl == 0.0){
                DeRef(_24665);
                _24665 = NOVALUE;
                goto L7; // [155] 243
            }
            DeRef(_24665);
            _24665 = NOVALUE;
        }
        DeRef(_24665);
        _24665 = NOVALUE;

        /** symtab.e:562								SymTab[p][attribute] += 1*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_47702 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _24668 = (object)*(((s1_ptr)_2)->base + _attribute_47699);
        _24666 = NOVALUE;
        if (IS_ATOM_INT(_24668)) {
            _24669 = _24668 + 1;
            if (_24669 > MAXINT){
                _24669 = NewDouble((eudouble)_24669);
            }
        }
        else
        _24669 = binary_op(PLUS, 1, _24668);
        _24668 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _attribute_47699);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24669;
        if( _1 != _24669 ){
            DeRef(_1);
        }
        _24669 = NOVALUE;
        _24666 = NOVALUE;

        /** symtab.e:564							break*/
        goto L7; // [182] 243

        /** symtab.e:565						case SC_EXPORT then*/
        case 11:

        /** symtab.e:566							if not and_bits( DIRECT_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _24670 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
        _2 = (object)SEQ_PTR(_24670);
        _24671 = (object)*(((s1_ptr)_2)->base + _sym_file_47709);
        _24670 = NOVALUE;
        if (IS_ATOM_INT(_24671)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2 & (uintptr_t)_24671;
                 _24672 = MAKE_UINT(tu);
            }
        }
        else {
            _24672 = binary_op(AND_BITS, 2, _24671);
        }
        _24671 = NOVALUE;
        if (IS_ATOM_INT(_24672)) {
            if (_24672 != 0){
                DeRef(_24672);
                _24672 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        else {
            if (DBL_PTR(_24672)->dbl != 0.0){
                DeRef(_24672);
                _24672 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        DeRef(_24672);
        _24672 = NOVALUE;

        /** symtab.e:567								break*/
        goto L9; // [213] 217
L8: 
L9: 

        /** symtab.e:570						case SC_GLOBAL then*/
        case 6:

        /** symtab.e:571							SymTab[p][attribute] += 1*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_47702 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _24676 = (object)*(((s1_ptr)_2)->base + _attribute_47699);
        _24674 = NOVALUE;
        if (IS_ATOM_INT(_24676)) {
            _24677 = _24676 + 1;
            if (_24677 > MAXINT){
                _24677 = NewDouble((eudouble)_24677);
            }
        }
        else
        _24677 = binary_op(PLUS, 1, _24676);
        _24676 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _attribute_47699);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24677;
        if( _1 != _24677 ){
            DeRef(_1);
        }
        _24677 = NOVALUE;
        _24674 = NOVALUE;
    ;}L7: 
L6: 

    /** symtab.e:575				p = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24678 = (object)*(((s1_ptr)_2)->base + _p_47702);
    _2 = (object)SEQ_PTR(_24678);
    _p_47702 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_47702)){
        _p_47702 = (object)DBL_PTR(_p_47702)->dbl;
    }
    _24678 = NOVALUE;

    /** symtab.e:576			end while*/
    goto L2; // [266] 33
L3: 
L1: 

    /** symtab.e:578	end procedure*/
    DeRef(_24652);
    _24652 = NOVALUE;
    return;
    ;
}


void _54mark_rechecks(object _file_no_47775)
{
    object _recheck_targets_47778 = NOVALUE;
    object _remaining_47782 = NOVALUE;
    object _marked_47786 = NOVALUE;
    object _24685 = NOVALUE;
    object _24683 = NOVALUE;
    object _24682 = NOVALUE;
    object _24681 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_file_no_47775)) {
        _1 = (object)(DBL_PTR(_file_no_47775)->dbl);
        DeRefDS(_file_no_47775);
        _file_no_47775 = _1;
    }

    /** symtab.e:584		sequence recheck_targets = map:get( recheck_routines, file_no, {} )*/
    Ref(_54recheck_routines_47769);
    RefDS(_21997);
    _0 = _recheck_targets_47778;
    _recheck_targets_47778 = _29get(_54recheck_routines_47769, _file_no_47775, _21997);
    DeRef(_0);

    /** symtab.e:585		if length( recheck_targets ) then*/
    if (IS_SEQUENCE(_recheck_targets_47778)){
            _24681 = SEQ_PTR(_recheck_targets_47778)->length;
    }
    else {
        _24681 = 1;
    }
    if (_24681 == 0)
    {
        _24681 = NOVALUE;
        goto L1; // [20] 129
    }
    else{
        _24681 = NOVALUE;
    }

    /** symtab.e:586			sequence remaining = {}*/
    RefDS(_21997);
    DeRefi(_remaining_47782);
    _remaining_47782 = _21997;

    /** symtab.e:587			for i = length( recheck_targets ) to 1 by -1 do*/
    if (IS_SEQUENCE(_recheck_targets_47778)){
            _24682 = SEQ_PTR(_recheck_targets_47778)->length;
    }
    else {
        _24682 = 1;
    }
    {
        object _i_47784;
        _i_47784 = _24682;
L2: 
        if (_i_47784 < 1){
            goto L3; // [35] 117
        }

        /** symtab.e:588				integer marked = 0*/
        _marked_47786 = 0;

        /** symtab.e:589				if TRANSLATE then*/
        if (_36TRANSLATE_21049 == 0)
        {
            goto L4; // [51] 72
        }
        else{
        }

        /** symtab.e:590					marked = MarkTargets( recheck_targets[i], S_RI_TARGET )*/
        _2 = (object)SEQ_PTR(_recheck_targets_47778);
        _24683 = (object)*(((s1_ptr)_2)->base + _i_47784);
        Ref(_24683);
        _marked_47786 = _54MarkTargets(_24683, 53);
        _24683 = NOVALUE;
        if (!IS_ATOM_INT(_marked_47786)) {
            _1 = (object)(DBL_PTR(_marked_47786)->dbl);
            DeRefDS(_marked_47786);
            _marked_47786 = _1;
        }
        goto L5; // [69] 96
L4: 

        /** symtab.e:591				elsif BIND then*/
        if (_36BIND_21052 == 0)
        {
            goto L6; // [76] 95
        }
        else{
        }

        /** symtab.e:592					marked = MarkTargets( recheck_targets[i], S_NREFS )*/
        _2 = (object)SEQ_PTR(_recheck_targets_47778);
        _24685 = (object)*(((s1_ptr)_2)->base + _i_47784);
        Ref(_24685);
        _marked_47786 = _54MarkTargets(_24685, 12);
        _24685 = NOVALUE;
        if (!IS_ATOM_INT(_marked_47786)) {
            _1 = (object)(DBL_PTR(_marked_47786)->dbl);
            DeRefDS(_marked_47786);
            _marked_47786 = _1;
        }
L6: 
L5: 

        /** symtab.e:594				if not marked then*/
        if (_marked_47786 != 0)
        goto L7; // [98] 108

        /** symtab.e:595					remaining &= file_no*/
        Append(&_remaining_47782, _remaining_47782, _file_no_47775);
L7: 

        /** symtab.e:597			end for*/
        _i_47784 = _i_47784 + -1;
        goto L2; // [112] 42
L3: 
        ;
    }

    /** symtab.e:598			map:put( recheck_routines, file_no, recheck_targets )*/
    Ref(_54recheck_routines_47769);
    RefDS(_recheck_targets_47778);
    _29put(_54recheck_routines_47769, _file_no_47775, _recheck_targets_47778, 1, 0);
L1: 
    DeRefi(_remaining_47782);
    _remaining_47782 = NOVALUE;

    /** symtab.e:600	end procedure*/
    DeRef(_recheck_targets_47778);
    return;
    ;
}


void _54mark_final_targets()
{
    object _size_1__tmp_at47_47814 = NOVALUE;
    object _size_inlined_size_at_47_47813 = NOVALUE;
    object _recheck_files_47815 = NOVALUE;
    object _24691 = NOVALUE;
    object _24690 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:603		if just_mark_everything_from then*/
    if (_54just_mark_everything_from_47696 == 0)
    {
        goto L1; // [5] 44
    }
    else{
    }

    /** symtab.e:604			if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L2; // [12] 25
    }
    else{
    }

    /** symtab.e:605				mark_all( S_RI_TARGET )*/
    _54mark_all(53);
    goto L3; // [22] 109
L2: 

    /** symtab.e:606			elsif BIND then*/
    if (_36BIND_21052 == 0)
    {
        goto L3; // [29] 109
    }
    else{
    }

    /** symtab.e:607				mark_all( S_NREFS )*/
    _54mark_all(12);
    goto L3; // [41] 109
L1: 

    /** symtab.e:609		elsif map:size( recheck_routines ) then*/

    /** map.e:800		return eumem:ram_space[the_map_p][MAP_SIZE]*/
    DeRef(_size_1__tmp_at47_47814);
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!IS_ATOM_INT(_54recheck_routines_47769)){
        _size_1__tmp_at47_47814 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_54recheck_routines_47769)->dbl));
    }
    else{
        _size_1__tmp_at47_47814 = (object)*(((s1_ptr)_2)->base + _54recheck_routines_47769);
    }
    Ref(_size_1__tmp_at47_47814);
    DeRef(_size_inlined_size_at_47_47813);
    _2 = (object)SEQ_PTR(_size_1__tmp_at47_47814);
    _size_inlined_size_at_47_47813 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_size_inlined_size_at_47_47813);
    DeRef(_size_1__tmp_at47_47814);
    _size_1__tmp_at47_47814 = NOVALUE;
    if (_size_inlined_size_at_47_47813 == 0) {
        goto L4; // [63] 106
    }
    else {
        if (!IS_ATOM_INT(_size_inlined_size_at_47_47813) && DBL_PTR(_size_inlined_size_at_47_47813)->dbl == 0.0){
            goto L4; // [63] 106
        }
    }

    /** symtab.e:610			sequence recheck_files = map:keys( recheck_routines )*/
    Ref(_54recheck_routines_47769);
    _0 = _recheck_files_47815;
    _recheck_files_47815 = _29keys(_54recheck_routines_47769, 0);
    DeRef(_0);

    /** symtab.e:611			for i = 1 to length( recheck_files ) do*/
    if (IS_SEQUENCE(_recheck_files_47815)){
            _24690 = SEQ_PTR(_recheck_files_47815)->length;
    }
    else {
        _24690 = 1;
    }
    {
        object _i_47818;
        _i_47818 = 1;
L5: 
        if (_i_47818 > _24690){
            goto L6; // [82] 105
        }

        /** symtab.e:612				mark_rechecks( recheck_files[i] )*/
        _2 = (object)SEQ_PTR(_recheck_files_47815);
        _24691 = (object)*(((s1_ptr)_2)->base + _i_47818);
        Ref(_24691);
        _54mark_rechecks(_24691);
        _24691 = NOVALUE;

        /** symtab.e:613			end for*/
        _i_47818 = _i_47818 + 1;
        goto L5; // [100] 89
L6: 
        ;
    }
L4: 
    DeRef(_recheck_files_47815);
    _recheck_files_47815 = NOVALUE;
L3: 

    /** symtab.e:615	end procedure*/
    return;
    ;
}


object _54is_routine(object _sym_47824)
{
    object _tok_47825 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:618		integer tok = sym_token( sym )*/
    _tok_47825 = _54sym_token(_sym_47824);
    if (!IS_ATOM_INT(_tok_47825)) {
        _1 = (object)(DBL_PTR(_tok_47825)->dbl);
        DeRefDS(_tok_47825);
        _tok_47825 = _1;
    }

    /** symtab.e:619		switch tok do*/
    _0 = _tok_47825;
    switch ( _0 ){ 

        /** symtab.e:620			case FUNC, PROC, TYPE then*/
        case 501:
        case 27:
        case 504:

        /** symtab.e:621				return 1*/
        return 1;
        goto L1; // [32] 45

        /** symtab.e:622			case else*/
        default:

        /** symtab.e:623				return 0*/
        return 0;
    ;}L1: 
    ;
}


object _54is_visible(object _sym_47838, object _from_file_47839)
{
    object _scope_47840 = NOVALUE;
    object _sym_file_47843 = NOVALUE;
    object _visible_mask_47848 = NOVALUE;
    object _24703 = NOVALUE;
    object _24702 = NOVALUE;
    object _24701 = NOVALUE;
    object _24700 = NOVALUE;
    object _24696 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:628		integer scope = sym_scope( sym )*/
    _scope_47840 = _54sym_scope(_sym_47838);
    if (!IS_ATOM_INT(_scope_47840)) {
        _1 = (object)(DBL_PTR(_scope_47840)->dbl);
        DeRefDS(_scope_47840);
        _scope_47840 = _1;
    }

    /** symtab.e:629		integer sym_file = SymTab[sym][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24696 = (object)*(((s1_ptr)_2)->base + _sym_47838);
    _2 = (object)SEQ_PTR(_24696);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _sym_file_47843 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _sym_file_47843 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    if (!IS_ATOM_INT(_sym_file_47843)){
        _sym_file_47843 = (object)DBL_PTR(_sym_file_47843)->dbl;
    }
    _24696 = NOVALUE;

    /** symtab.e:631		switch scope do*/
    _0 = _scope_47840;
    switch ( _0 ){ 

        /** symtab.e:632			case SC_PUBLIC then*/
        case 13:

        /** symtab.e:633				visible_mask = DIRECT_OR_PUBLIC_INCLUDE*/
        _visible_mask_47848 = 6;
        goto L1; // [49] 93

        /** symtab.e:634			case SC_EXPORT then*/
        case 11:

        /** symtab.e:635				visible_mask = DIRECT_INCLUDE*/
        _visible_mask_47848 = 2;
        goto L1; // [64] 93

        /** symtab.e:636			case SC_GLOBAL then*/
        case 6:

        /** symtab.e:637				return 1*/
        return 1;
        goto L1; // [76] 93

        /** symtab.e:638			case else*/
        default:

        /** symtab.e:639				return from_file = sym_file*/
        _24700 = (_from_file_47839 == _sym_file_47843);
        return _24700;
    ;}L1: 

    /** symtab.e:641		return and_bits( visible_mask, include_matrix[from_file][sym_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _24701 = (object)*(((s1_ptr)_2)->base + _from_file_47839);
    _2 = (object)SEQ_PTR(_24701);
    _24702 = (object)*(((s1_ptr)_2)->base + _sym_file_47843);
    _24701 = NOVALUE;
    if (IS_ATOM_INT(_24702)) {
        {uintptr_t tu;
             tu = (uintptr_t)_visible_mask_47848 & (uintptr_t)_24702;
             _24703 = MAKE_UINT(tu);
        }
    }
    else {
        _24703 = binary_op(AND_BITS, _visible_mask_47848, _24702);
    }
    _24702 = NOVALUE;
    DeRef(_24700);
    _24700 = NOVALUE;
    return _24703;
    ;
}


object _54MarkTargets(object _s_47868, object _attribute_47869)
{
    object _p_47871 = NOVALUE;
    object _sname_47872 = NOVALUE;
    object _string_47873 = NOVALUE;
    object _colon_47874 = NOVALUE;
    object _h_47875 = NOVALUE;
    object _scope_47876 = NOVALUE;
    object _found_47897 = NOVALUE;
    object _24751 = NOVALUE;
    object _24749 = NOVALUE;
    object _24748 = NOVALUE;
    object _24747 = NOVALUE;
    object _24746 = NOVALUE;
    object _24744 = NOVALUE;
    object _24743 = NOVALUE;
    object _24742 = NOVALUE;
    object _24741 = NOVALUE;
    object _24740 = NOVALUE;
    object _24738 = NOVALUE;
    object _24737 = NOVALUE;
    object _24736 = NOVALUE;
    object _24734 = NOVALUE;
    object _24732 = NOVALUE;
    object _24730 = NOVALUE;
    object _24729 = NOVALUE;
    object _24728 = NOVALUE;
    object _24727 = NOVALUE;
    object _24725 = NOVALUE;
    object _24724 = NOVALUE;
    object _24723 = NOVALUE;
    object _24722 = NOVALUE;
    object _24720 = NOVALUE;
    object _24719 = NOVALUE;
    object _24715 = NOVALUE;
    object _24714 = NOVALUE;
    object _24713 = NOVALUE;
    object _24712 = NOVALUE;
    object _24711 = NOVALUE;
    object _24710 = NOVALUE;
    object _24709 = NOVALUE;
    object _24708 = NOVALUE;
    object _24707 = NOVALUE;
    object _24706 = NOVALUE;
    object _24705 = NOVALUE;
    object _24704 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_47868)) {
        _1 = (object)(DBL_PTR(_s_47868)->dbl);
        DeRefDS(_s_47868);
        _s_47868 = _1;
    }

    /** symtab.e:648		sequence sname*/

    /** symtab.e:649		sequence string*/

    /** symtab.e:650		integer colon, h*/

    /** symtab.e:651		integer scope*/

    /** symtab.e:653		if (SymTab[s][S_MODE] = M_TEMP or*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24704 = (object)*(((s1_ptr)_2)->base + _s_47868);
    _2 = (object)SEQ_PTR(_24704);
    _24705 = (object)*(((s1_ptr)_2)->base + 3);
    _24704 = NOVALUE;
    if (IS_ATOM_INT(_24705)) {
        _24706 = (_24705 == 3);
    }
    else {
        _24706 = binary_op(EQUALS, _24705, 3);
    }
    _24705 = NOVALUE;
    if (IS_ATOM_INT(_24706)) {
        if (_24706 != 0) {
            _24707 = 1;
            goto L1; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_24706)->dbl != 0.0) {
            _24707 = 1;
            goto L1; // [33] 59
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24708 = (object)*(((s1_ptr)_2)->base + _s_47868);
    _2 = (object)SEQ_PTR(_24708);
    _24709 = (object)*(((s1_ptr)_2)->base + 3);
    _24708 = NOVALUE;
    if (IS_ATOM_INT(_24709)) {
        _24710 = (_24709 == 2);
    }
    else {
        _24710 = binary_op(EQUALS, _24709, 2);
    }
    _24709 = NOVALUE;
    DeRef(_24707);
    if (IS_ATOM_INT(_24710))
    _24707 = (_24710 != 0);
    else
    _24707 = DBL_PTR(_24710)->dbl != 0.0;
L1: 
    if (_24707 == 0) {
        goto L2; // [59] 411
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24712 = (object)*(((s1_ptr)_2)->base + _s_47868);
    _2 = (object)SEQ_PTR(_24712);
    _24713 = (object)*(((s1_ptr)_2)->base + 1);
    _24712 = NOVALUE;
    _24714 = IS_SEQUENCE(_24713);
    _24713 = NOVALUE;
    if (_24714 == 0)
    {
        _24714 = NOVALUE;
        goto L2; // [79] 411
    }
    else{
        _24714 = NOVALUE;
    }

    /** symtab.e:658			integer found = 0*/
    _found_47897 = 0;

    /** symtab.e:660			string = SymTab[s][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24715 = (object)*(((s1_ptr)_2)->base + _s_47868);
    DeRef(_string_47873);
    _2 = (object)SEQ_PTR(_24715);
    _string_47873 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_string_47873);
    _24715 = NOVALUE;

    /** symtab.e:661			colon = find(':', string)*/
    _colon_47874 = find_from(58, _string_47873, 1);

    /** symtab.e:662			if colon = 0 then*/
    if (_colon_47874 != 0)
    goto L3; // [112] 126

    /** symtab.e:663				sname = string*/
    RefDS(_string_47873);
    DeRef(_sname_47872);
    _sname_47872 = _string_47873;
    goto L4; // [123] 200
L3: 

    /** symtab.e:665				sname = string[colon+1..$]  -- ignore namespace part*/
    _24719 = _colon_47874 + 1;
    if (_24719 > MAXINT){
        _24719 = NewDouble((eudouble)_24719);
    }
    if (IS_SEQUENCE(_string_47873)){
            _24720 = SEQ_PTR(_string_47873)->length;
    }
    else {
        _24720 = 1;
    }
    rhs_slice_target = (object_ptr)&_sname_47872;
    RHS_Slice(_string_47873, _24719, _24720);

    /** symtab.e:666				while length(sname) and sname[1] = ' ' or sname[1] = '\t' do*/
L5: 
    if (IS_SEQUENCE(_sname_47872)){
            _24722 = SEQ_PTR(_sname_47872)->length;
    }
    else {
        _24722 = 1;
    }
    if (_24722 == 0) {
        _24723 = 0;
        goto L6; // [148] 164
    }
    _2 = (object)SEQ_PTR(_sname_47872);
    _24724 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24724)) {
        _24725 = (_24724 == 32);
    }
    else {
        _24725 = binary_op(EQUALS, _24724, 32);
    }
    _24724 = NOVALUE;
    if (IS_ATOM_INT(_24725))
    _24723 = (_24725 != 0);
    else
    _24723 = DBL_PTR(_24725)->dbl != 0.0;
L6: 
    if (_24723 != 0) {
        goto L7; // [164] 181
    }
    _2 = (object)SEQ_PTR(_sname_47872);
    _24727 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24727)) {
        _24728 = (_24727 == 9);
    }
    else {
        _24728 = binary_op(EQUALS, _24727, 9);
    }
    _24727 = NOVALUE;
    if (_24728 <= 0) {
        if (_24728 == 0) {
            DeRef(_24728);
            _24728 = NOVALUE;
            goto L8; // [177] 199
        }
        else {
            if (!IS_ATOM_INT(_24728) && DBL_PTR(_24728)->dbl == 0.0){
                DeRef(_24728);
                _24728 = NOVALUE;
                goto L8; // [177] 199
            }
            DeRef(_24728);
            _24728 = NOVALUE;
        }
    }
    DeRef(_24728);
    _24728 = NOVALUE;
L7: 

    /** symtab.e:667					sname = tail( sname, length( sname ) -1 )*/
    if (IS_SEQUENCE(_sname_47872)){
            _24729 = SEQ_PTR(_sname_47872)->length;
    }
    else {
        _24729 = 1;
    }
    _24730 = _24729 - 1;
    _24729 = NOVALUE;
    {
        int len = SEQ_PTR(_sname_47872)->length;
        int size = (IS_ATOM_INT(_24730)) ? _24730 : (object)(DBL_PTR(_24730)->dbl);
        if (size <= 0) {
            DeRef(_sname_47872);
            _sname_47872 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_sname_47872);
            DeRef(_sname_47872);
            _sname_47872 = _sname_47872;
        }
        else Tail(SEQ_PTR(_sname_47872), len-size+1, &_sname_47872);
    }
    _24730 = NOVALUE;

    /** symtab.e:668				end while*/
    goto L5; // [196] 145
L8: 
L4: 

    /** symtab.e:671			if length(sname) = 0 then*/
    if (IS_SEQUENCE(_sname_47872)){
            _24732 = SEQ_PTR(_sname_47872)->length;
    }
    else {
        _24732 = 1;
    }
    if (_24732 != 0)
    goto L9; // [207] 218

    /** symtab.e:672				return 1*/
    DeRefDS(_sname_47872);
    DeRef(_string_47873);
    DeRef(_24710);
    _24710 = NOVALUE;
    DeRef(_24719);
    _24719 = NOVALUE;
    DeRef(_24706);
    _24706 = NOVALUE;
    DeRef(_24725);
    _24725 = NOVALUE;
    return 1;
L9: 

    /** symtab.e:674			h = buckets[hashfn(sname)]*/
    RefDS(_sname_47872);
    _24734 = _54hashfn(_sname_47872);
    _2 = (object)SEQ_PTR(_54buckets_46776);
    if (!IS_ATOM_INT(_24734)){
        _h_47875 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24734)->dbl));
    }
    else{
        _h_47875 = (object)*(((s1_ptr)_2)->base + _24734);
    }
    if (!IS_ATOM_INT(_h_47875))
    _h_47875 = (object)DBL_PTR(_h_47875)->dbl;

    /** symtab.e:675			while h do*/
LA: 
    if (_h_47875 == 0)
    {
        goto LB; // [235] 381
    }
    else{
    }

    /** symtab.e:676				if equal(sname, SymTab[h][S_NAME]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24736 = (object)*(((s1_ptr)_2)->base + _h_47875);
    _2 = (object)SEQ_PTR(_24736);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _24737 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _24737 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _24736 = NOVALUE;
    if (_sname_47872 == _24737)
    _24738 = 1;
    else if (IS_ATOM_INT(_sname_47872) && IS_ATOM_INT(_24737))
    _24738 = 0;
    else
    _24738 = (compare(_sname_47872, _24737) == 0);
    _24737 = NOVALUE;
    if (_24738 == 0)
    {
        _24738 = NOVALUE;
        goto LC; // [256] 360
    }
    else{
        _24738 = NOVALUE;
    }

    /** symtab.e:677					if attribute = S_NREFS then*/
    if (_attribute_47869 != 12)
    goto LD; // [263] 289

    /** symtab.e:678						if BIND then*/
    if (_36BIND_21052 == 0)
    {
        goto LE; // [271] 359
    }
    else{
    }

    /** symtab.e:679							add_ref({PROC, h})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 27;
    ((intptr_t *)_2)[2] = _h_47875;
    _24740 = MAKE_SEQ(_1);
    _54add_ref(_24740);
    _24740 = NOVALUE;
    goto LE; // [286] 359
LD: 

    /** symtab.e:681					elsif is_routine( h ) and is_visible( h, current_file_no ) then*/
    _24741 = _54is_routine(_h_47875);
    if (IS_ATOM_INT(_24741)) {
        if (_24741 == 0) {
            goto LF; // [295] 358
        }
    }
    else {
        if (DBL_PTR(_24741)->dbl == 0.0) {
            goto LF; // [295] 358
        }
    }
    _24743 = _54is_visible(_h_47875, _36current_file_no_21447);
    if (_24743 == 0) {
        DeRef(_24743);
        _24743 = NOVALUE;
        goto LF; // [307] 358
    }
    else {
        if (!IS_ATOM_INT(_24743) && DBL_PTR(_24743)->dbl == 0.0){
            DeRef(_24743);
            _24743 = NOVALUE;
            goto LF; // [307] 358
        }
        DeRef(_24743);
        _24743 = NOVALUE;
    }
    DeRef(_24743);
    _24743 = NOVALUE;

    /** symtab.e:682						SymTab[h][attribute] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_h_47875 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24746 = (object)*(((s1_ptr)_2)->base + _attribute_47869);
    _24744 = NOVALUE;
    if (IS_ATOM_INT(_24746)) {
        _24747 = _24746 + 1;
        if (_24747 > MAXINT){
            _24747 = NewDouble((eudouble)_24747);
        }
    }
    else
    _24747 = binary_op(PLUS, 1, _24746);
    _24746 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _attribute_47869);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24747;
    if( _1 != _24747 ){
        DeRef(_1);
    }
    _24747 = NOVALUE;
    _24744 = NOVALUE;

    /** symtab.e:683						if current_file_no = SymTab[h][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24748 = (object)*(((s1_ptr)_2)->base + _h_47875);
    _2 = (object)SEQ_PTR(_24748);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _24749 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _24749 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _24748 = NOVALUE;
    if (binary_op_a(NOTEQ, _36current_file_no_21447, _24749)){
        _24749 = NOVALUE;
        goto L10; // [347] 357
    }
    _24749 = NOVALUE;

    /** symtab.e:684							found = 1*/
    _found_47897 = 1;
L10: 
LF: 
LE: 
LC: 

    /** symtab.e:688				h = SymTab[h][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24751 = (object)*(((s1_ptr)_2)->base + _h_47875);
    _2 = (object)SEQ_PTR(_24751);
    _h_47875 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_h_47875)){
        _h_47875 = (object)DBL_PTR(_h_47875)->dbl;
    }
    _24751 = NOVALUE;

    /** symtab.e:689			end while*/
    goto LA; // [378] 235
LB: 

    /** symtab.e:691			if not found then*/
    if (_found_47897 != 0)
    goto L11; // [383] 400

    /** symtab.e:692				map:put( recheck_routines, current_file_no, s, map:APPEND )*/
    Ref(_54recheck_routines_47769);
    _29put(_54recheck_routines_47769, _36current_file_no_21447, _s_47868, 6, 0);
L11: 

    /** symtab.e:694			return found*/
    DeRef(_sname_47872);
    DeRef(_string_47873);
    DeRef(_24734);
    _24734 = NOVALUE;
    DeRef(_24710);
    _24710 = NOVALUE;
    DeRef(_24719);
    _24719 = NOVALUE;
    DeRef(_24741);
    _24741 = NOVALUE;
    DeRef(_24706);
    _24706 = NOVALUE;
    DeRef(_24725);
    _24725 = NOVALUE;
    return _found_47897;
    goto L12; // [408] 440
L2: 

    /** symtab.e:696			if not just_mark_everything_from then*/
    if (_54just_mark_everything_from_47696 != 0)
    goto L13; // [415] 428

    /** symtab.e:697				just_mark_everything_from = TopLevelSub*/
    _54just_mark_everything_from_47696 = _36TopLevelSub_21454;
L13: 

    /** symtab.e:699			mark_all( attribute )*/
    _54mark_all(_attribute_47869);

    /** symtab.e:700			return 1*/
    DeRef(_sname_47872);
    DeRef(_string_47873);
    DeRef(_24734);
    _24734 = NOVALUE;
    DeRef(_24710);
    _24710 = NOVALUE;
    DeRef(_24719);
    _24719 = NOVALUE;
    DeRef(_24741);
    _24741 = NOVALUE;
    DeRef(_24706);
    _24706 = NOVALUE;
    DeRef(_24725);
    _24725 = NOVALUE;
    return 1;
L12: 
    ;
}


void _54resolve_unincluded_globals(object _ok_47975)
{
    object _0, _1, _2;
    

    /** symtab.e:724		Resolve_unincluded_globals = ok*/
    _54Resolve_unincluded_globals_47972 = 1;

    /** symtab.e:725	end procedure*/
    return;
    ;
}


object _54get_resolve_unincluded_globals()
{
    object _0, _1, _2;
    

    /** symtab.e:728		return Resolve_unincluded_globals*/
    return _54Resolve_unincluded_globals_47972;
    ;
}


object _54keyfind(object _word_47981, object _file_no_47982, object _scanning_file_47983, object _namespace_ok_47986, object _hashval_47987)
{
    object _msg_47989 = NOVALUE;
    object _b_name_47990 = NOVALUE;
    object _scope_47991 = NOVALUE;
    object _defined_47992 = NOVALUE;
    object _ix_47993 = NOVALUE;
    object _st_ptr_47995 = NOVALUE;
    object _st_builtin_47996 = NOVALUE;
    object _tok_47998 = NOVALUE;
    object _gtok_47999 = NOVALUE;
    object _any_symbol_48002 = NOVALUE;
    object _tok_file_48170 = NOVALUE;
    object _good_48177 = NOVALUE;
    object _include_type_48187 = NOVALUE;
    object _msg_file_48243 = NOVALUE;
    object _24946 = NOVALUE;
    object _24945 = NOVALUE;
    object _24943 = NOVALUE;
    object _24941 = NOVALUE;
    object _24940 = NOVALUE;
    object _24939 = NOVALUE;
    object _24938 = NOVALUE;
    object _24937 = NOVALUE;
    object _24935 = NOVALUE;
    object _24933 = NOVALUE;
    object _24932 = NOVALUE;
    object _24931 = NOVALUE;
    object _24930 = NOVALUE;
    object _24929 = NOVALUE;
    object _24928 = NOVALUE;
    object _24927 = NOVALUE;
    object _24926 = NOVALUE;
    object _24924 = NOVALUE;
    object _24923 = NOVALUE;
    object _24922 = NOVALUE;
    object _24921 = NOVALUE;
    object _24920 = NOVALUE;
    object _24919 = NOVALUE;
    object _24918 = NOVALUE;
    object _24917 = NOVALUE;
    object _24916 = NOVALUE;
    object _24915 = NOVALUE;
    object _24914 = NOVALUE;
    object _24913 = NOVALUE;
    object _24912 = NOVALUE;
    object _24911 = NOVALUE;
    object _24910 = NOVALUE;
    object _24909 = NOVALUE;
    object _24908 = NOVALUE;
    object _24906 = NOVALUE;
    object _24905 = NOVALUE;
    object _24902 = NOVALUE;
    object _24898 = NOVALUE;
    object _24896 = NOVALUE;
    object _24895 = NOVALUE;
    object _24894 = NOVALUE;
    object _24893 = NOVALUE;
    object _24892 = NOVALUE;
    object _24890 = NOVALUE;
    object _24889 = NOVALUE;
    object _24888 = NOVALUE;
    object _24887 = NOVALUE;
    object _24885 = NOVALUE;
    object _24882 = NOVALUE;
    object _24881 = NOVALUE;
    object _24880 = NOVALUE;
    object _24879 = NOVALUE;
    object _24877 = NOVALUE;
    object _24874 = NOVALUE;
    object _24873 = NOVALUE;
    object _24872 = NOVALUE;
    object _24871 = NOVALUE;
    object _24870 = NOVALUE;
    object _24869 = NOVALUE;
    object _24868 = NOVALUE;
    object _24865 = NOVALUE;
    object _24864 = NOVALUE;
    object _24862 = NOVALUE;
    object _24860 = NOVALUE;
    object _24858 = NOVALUE;
    object _24857 = NOVALUE;
    object _24856 = NOVALUE;
    object _24852 = NOVALUE;
    object _24851 = NOVALUE;
    object _24846 = NOVALUE;
    object _24844 = NOVALUE;
    object _24842 = NOVALUE;
    object _24841 = NOVALUE;
    object _24837 = NOVALUE;
    object _24836 = NOVALUE;
    object _24834 = NOVALUE;
    object _24833 = NOVALUE;
    object _24831 = NOVALUE;
    object _24830 = NOVALUE;
    object _24829 = NOVALUE;
    object _24828 = NOVALUE;
    object _24827 = NOVALUE;
    object _24825 = NOVALUE;
    object _24824 = NOVALUE;
    object _24823 = NOVALUE;
    object _24822 = NOVALUE;
    object _24821 = NOVALUE;
    object _24820 = NOVALUE;
    object _24819 = NOVALUE;
    object _24818 = NOVALUE;
    object _24817 = NOVALUE;
    object _24816 = NOVALUE;
    object _24815 = NOVALUE;
    object _24814 = NOVALUE;
    object _24813 = NOVALUE;
    object _24812 = NOVALUE;
    object _24811 = NOVALUE;
    object _24810 = NOVALUE;
    object _24809 = NOVALUE;
    object _24808 = NOVALUE;
    object _24807 = NOVALUE;
    object _24806 = NOVALUE;
    object _24805 = NOVALUE;
    object _24804 = NOVALUE;
    object _24802 = NOVALUE;
    object _24801 = NOVALUE;
    object _24799 = NOVALUE;
    object _24798 = NOVALUE;
    object _24797 = NOVALUE;
    object _24796 = NOVALUE;
    object _24795 = NOVALUE;
    object _24793 = NOVALUE;
    object _24792 = NOVALUE;
    object _24791 = NOVALUE;
    object _24789 = NOVALUE;
    object _24788 = NOVALUE;
    object _24787 = NOVALUE;
    object _24786 = NOVALUE;
    object _24785 = NOVALUE;
    object _24784 = NOVALUE;
    object _24783 = NOVALUE;
    object _24781 = NOVALUE;
    object _24780 = NOVALUE;
    object _24775 = NOVALUE;
    object _24772 = NOVALUE;
    object _24771 = NOVALUE;
    object _24770 = NOVALUE;
    object _24769 = NOVALUE;
    object _24768 = NOVALUE;
    object _24767 = NOVALUE;
    object _24766 = NOVALUE;
    object _24765 = NOVALUE;
    object _24764 = NOVALUE;
    object _24763 = NOVALUE;
    object _24762 = NOVALUE;
    object _24761 = NOVALUE;
    object _24760 = NOVALUE;
    object _24759 = NOVALUE;
    object _24758 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_file_no_47982)) {
        _1 = (object)(DBL_PTR(_file_no_47982)->dbl);
        DeRefDS(_file_no_47982);
        _file_no_47982 = _1;
    }
    if (!IS_ATOM_INT(_hashval_47987)) {
        _1 = (object)(DBL_PTR(_hashval_47987)->dbl);
        DeRefDS(_hashval_47987);
        _hashval_47987 = _1;
    }

    /** symtab.e:750		dup_globals = {}*/
    RefDS(_21997);
    DeRef(_54dup_globals_47967);
    _54dup_globals_47967 = _21997;

    /** symtab.e:751		dup_overrides = {}*/
    RefDS(_21997);
    DeRefi(_54dup_overrides_47968);
    _54dup_overrides_47968 = _21997;

    /** symtab.e:752		in_include_path = {}*/
    RefDS(_21997);
    DeRef(_54in_include_path_47969);
    _54in_include_path_47969 = _21997;

    /** symtab.e:753		symbol_resolution_warning = ""*/
    RefDS(_21997);
    DeRef(_36symbol_resolution_warning_21552);
    _36symbol_resolution_warning_21552 = _21997;

    /** symtab.e:754		st_builtin = 0*/
    _st_builtin_47996 = 0;

    /** symtab.e:756		ifdef EUDIS then*/

    /** symtab.e:759		st_ptr = buckets[hashval]*/
    _2 = (object)SEQ_PTR(_54buckets_46776);
    _st_ptr_47995 = (object)*(((s1_ptr)_2)->base + _hashval_47987);
    if (!IS_ATOM_INT(_st_ptr_47995)){
        _st_ptr_47995 = (object)DBL_PTR(_st_ptr_47995)->dbl;
    }

    /** symtab.e:760		integer any_symbol = namespace_ok = -1*/
    _any_symbol_48002 = (_namespace_ok_47986 == -1);

    /** symtab.e:761		while st_ptr do*/
L1: 
    if (_st_ptr_47995 == 0)
    {
        goto L2; // [69] 1033
    }
    else{
    }

    /** symtab.e:762			if SymTab[st_ptr][S_SCOPE] != SC_UNDEFINED */
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24758 = (object)*(((s1_ptr)_2)->base + _st_ptr_47995);
    _2 = (object)SEQ_PTR(_24758);
    _24759 = (object)*(((s1_ptr)_2)->base + 4);
    _24758 = NOVALUE;
    if (IS_ATOM_INT(_24759)) {
        _24760 = (_24759 != 9);
    }
    else {
        _24760 = binary_op(NOTEQ, _24759, 9);
    }
    _24759 = NOVALUE;
    if (IS_ATOM_INT(_24760)) {
        if (_24760 == 0) {
            DeRef(_24761);
            _24761 = 0;
            goto L3; // [92] 116
        }
    }
    else {
        if (DBL_PTR(_24760)->dbl == 0.0) {
            DeRef(_24761);
            _24761 = 0;
            goto L3; // [92] 116
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24762 = (object)*(((s1_ptr)_2)->base + _st_ptr_47995);
    _2 = (object)SEQ_PTR(_24762);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _24763 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _24763 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _24762 = NOVALUE;
    if (_word_47981 == _24763)
    _24764 = 1;
    else if (IS_ATOM_INT(_word_47981) && IS_ATOM_INT(_24763))
    _24764 = 0;
    else
    _24764 = (compare(_word_47981, _24763) == 0);
    _24763 = NOVALUE;
    DeRef(_24761);
    _24761 = (_24764 != 0);
L3: 
    if (_24761 == 0) {
        goto L4; // [116] 1012
    }
    if (_any_symbol_48002 != 0) {
        DeRef(_24766);
        _24766 = 1;
        goto L5; // [120] 150
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24767 = (object)*(((s1_ptr)_2)->base + _st_ptr_47995);
    _2 = (object)SEQ_PTR(_24767);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _24768 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _24768 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    _24767 = NOVALUE;
    if (IS_ATOM_INT(_24768)) {
        _24769 = (_24768 == 523);
    }
    else {
        _24769 = binary_op(EQUALS, _24768, 523);
    }
    _24768 = NOVALUE;
    if (IS_ATOM_INT(_24769)) {
        _24770 = (_namespace_ok_47986 == _24769);
    }
    else {
        _24770 = binary_op(EQUALS, _namespace_ok_47986, _24769);
    }
    DeRef(_24769);
    _24769 = NOVALUE;
    if (IS_ATOM_INT(_24770))
    _24766 = (_24770 != 0);
    else
    _24766 = DBL_PTR(_24770)->dbl != 0.0;
L5: 
    if (_24766 == 0)
    {
        _24766 = NOVALUE;
        goto L4; // [151] 1012
    }
    else{
        _24766 = NOVALUE;
    }

    /** symtab.e:767				tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24771 = (object)*(((s1_ptr)_2)->base + _st_ptr_47995);
    _2 = (object)SEQ_PTR(_24771);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _24772 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _24772 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    _24771 = NOVALUE;
    Ref(_24772);
    DeRef(_tok_47998);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24772;
    ((intptr_t *)_2)[2] = _st_ptr_47995;
    _tok_47998 = MAKE_SEQ(_1);
    _24772 = NOVALUE;

    /** symtab.e:769				if file_no = -1 then*/
    if (_file_no_47982 != -1)
    goto L6; // [174] 714

    /** symtab.e:774					scope = SymTab[st_ptr][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24775 = (object)*(((s1_ptr)_2)->base + _st_ptr_47995);
    _2 = (object)SEQ_PTR(_24775);
    _scope_47991 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_47991)){
        _scope_47991 = (object)DBL_PTR(_scope_47991)->dbl;
    }
    _24775 = NOVALUE;

    /** symtab.e:776					switch scope with fallthru do*/
    _0 = _scope_47991;
    switch ( _0 ){ 

        /** symtab.e:777					case SC_OVERRIDE then*/
        case 12:

        /** symtab.e:778						dup_overrides &= st_ptr*/
        Append(&_54dup_overrides_47968, _54dup_overrides_47968, _st_ptr_47995);

        /** symtab.e:779						break*/
        goto L7; // [215] 1011

        /** symtab.e:781					case SC_PREDEF then*/
        case 7:

        /** symtab.e:782						st_builtin = st_ptr*/
        _st_builtin_47996 = _st_ptr_47995;

        /** symtab.e:783						break*/
        goto L7; // [230] 1011

        /** symtab.e:784					case SC_GLOBAL then*/
        case 6:

        /** symtab.e:785						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24780 = (object)*(((s1_ptr)_2)->base + _st_ptr_47995);
        _2 = (object)SEQ_PTR(_24780);
        if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
            _24781 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
        }
        else{
            _24781 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
        }
        _24780 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_47983, _24781)){
            _24781 = NOVALUE;
            goto L8; // [250] 274
        }
        _24781 = NOVALUE;

        /** symtab.e:788							if BIND then*/
        if (_36BIND_21052 == 0)
        {
            goto L9; // [258] 267
        }
        else{
        }

        /** symtab.e:789								add_ref(tok)*/
        Ref(_tok_47998);
        _54add_ref(_tok_47998);
L9: 

        /** symtab.e:792							return tok*/
        DeRefDS(_word_47981);
        DeRef(_msg_47989);
        DeRef(_b_name_47990);
        DeRef(_gtok_47999);
        DeRef(_24770);
        _24770 = NOVALUE;
        DeRef(_24760);
        _24760 = NOVALUE;
        return _tok_47998;
L8: 

        /** symtab.e:796						if Resolve_unincluded_globals */
        if (_54Resolve_unincluded_globals_47972 != 0) {
            _24783 = 1;
            goto LA; // [278] 322
        }
        _2 = (object)SEQ_PTR(_37finished_files_15409);
        _24784 = (object)*(((s1_ptr)_2)->base + _scanning_file_47983);
        if (_24784 == 0) {
            _24785 = 0;
            goto LB; // [288] 318
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _24786 = (object)*(((s1_ptr)_2)->base + _scanning_file_47983);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24787 = (object)*(((s1_ptr)_2)->base + _st_ptr_47995);
        _2 = (object)SEQ_PTR(_24787);
        if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
            _24788 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
        }
        else{
            _24788 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
        }
        _24787 = NOVALUE;
        _2 = (object)SEQ_PTR(_24786);
        if (!IS_ATOM_INT(_24788)){
            _24789 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24788)->dbl));
        }
        else{
            _24789 = (object)*(((s1_ptr)_2)->base + _24788);
        }
        _24786 = NOVALUE;
        if (IS_ATOM_INT(_24789))
        _24785 = (_24789 != 0);
        else
        _24785 = DBL_PTR(_24789)->dbl != 0.0;
LB: 
        _24783 = (_24785 != 0);
LA: 
        if (_24783 != 0) {
            goto LC; // [322] 349
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24791 = (object)*(((s1_ptr)_2)->base + _st_ptr_47995);
        _2 = (object)SEQ_PTR(_24791);
        if (!IS_ATOM_INT(_36S_TOKEN_21089)){
            _24792 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
        }
        else{
            _24792 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
        }
        _24791 = NOVALUE;
        if (IS_ATOM_INT(_24792)) {
            _24793 = (_24792 == 523);
        }
        else {
            _24793 = binary_op(EQUALS, _24792, 523);
        }
        _24792 = NOVALUE;
        if (_24793 == 0) {
            DeRef(_24793);
            _24793 = NOVALUE;
            goto L7; // [345] 1011
        }
        else {
            if (!IS_ATOM_INT(_24793) && DBL_PTR(_24793)->dbl == 0.0){
                DeRef(_24793);
                _24793 = NOVALUE;
                goto L7; // [345] 1011
            }
            DeRef(_24793);
            _24793 = NOVALUE;
        }
        DeRef(_24793);
        _24793 = NOVALUE;
LC: 

        /** symtab.e:800							gtok = tok*/
        Ref(_tok_47998);
        DeRef(_gtok_47999);
        _gtok_47999 = _tok_47998;

        /** symtab.e:801							dup_globals &= st_ptr*/
        Append(&_54dup_globals_47967, _54dup_globals_47967, _st_ptr_47995);

        /** symtab.e:802							in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0*/
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _24795 = (object)*(((s1_ptr)_2)->base + _scanning_file_47983);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24796 = (object)*(((s1_ptr)_2)->base + _st_ptr_47995);
        _2 = (object)SEQ_PTR(_24796);
        if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
            _24797 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
        }
        else{
            _24797 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
        }
        _24796 = NOVALUE;
        _2 = (object)SEQ_PTR(_24795);
        if (!IS_ATOM_INT(_24797)){
            _24798 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24797)->dbl));
        }
        else{
            _24798 = (object)*(((s1_ptr)_2)->base + _24797);
        }
        _24795 = NOVALUE;
        if (IS_ATOM_INT(_24798)) {
            _24799 = (_24798 != 0);
        }
        else {
            _24799 = binary_op(NOTEQ, _24798, 0);
        }
        _24798 = NOVALUE;
        if (IS_SEQUENCE(_54in_include_path_47969) && IS_ATOM(_24799)) {
            Ref(_24799);
            Append(&_54in_include_path_47969, _54in_include_path_47969, _24799);
        }
        else if (IS_ATOM(_54in_include_path_47969) && IS_SEQUENCE(_24799)) {
        }
        else {
            Concat((object_ptr)&_54in_include_path_47969, _54in_include_path_47969, _24799);
        }
        DeRef(_24799);
        _24799 = NOVALUE;

        /** symtab.e:804						break*/
        goto L7; // [399] 1011

        /** symtab.e:807					case SC_PUBLIC, SC_EXPORT then*/
        case 13:
        case 11:

        /** symtab.e:809						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24801 = (object)*(((s1_ptr)_2)->base + _st_ptr_47995);
        _2 = (object)SEQ_PTR(_24801);
        if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
            _24802 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
        }
        else{
            _24802 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
        }
        _24801 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_47983, _24802)){
            _24802 = NOVALUE;
            goto LD; // [421] 445
        }
        _24802 = NOVALUE;

        /** symtab.e:811							if BIND then*/
        if (_36BIND_21052 == 0)
        {
            goto LE; // [429] 438
        }
        else{
        }

        /** symtab.e:812								add_ref(tok)*/
        Ref(_tok_47998);
        _54add_ref(_tok_47998);
LE: 

        /** symtab.e:815							return tok*/
        DeRefDS(_word_47981);
        DeRef(_msg_47989);
        DeRef(_b_name_47990);
        DeRef(_gtok_47999);
        DeRef(_24770);
        _24770 = NOVALUE;
        _24788 = NOVALUE;
        _24784 = NOVALUE;
        _24789 = NOVALUE;
        _24797 = NOVALUE;
        DeRef(_24760);
        _24760 = NOVALUE;
        return _tok_47998;
LD: 

        /** symtab.e:818						if (finished_files[scanning_file] -- everything this file needs has been read in*/
        _2 = (object)SEQ_PTR(_37finished_files_15409);
        _24804 = (object)*(((s1_ptr)_2)->base + _scanning_file_47983);
        if (_24804 != 0) {
            _24805 = 1;
            goto LF; // [453] 487
        }
        if (_namespace_ok_47986 == 0) {
            _24806 = 0;
            goto L10; // [457] 483
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24807 = (object)*(((s1_ptr)_2)->base + _st_ptr_47995);
        _2 = (object)SEQ_PTR(_24807);
        if (!IS_ATOM_INT(_36S_TOKEN_21089)){
            _24808 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
        }
        else{
            _24808 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
        }
        _24807 = NOVALUE;
        if (IS_ATOM_INT(_24808)) {
            _24809 = (_24808 == 523);
        }
        else {
            _24809 = binary_op(EQUALS, _24808, 523);
        }
        _24808 = NOVALUE;
        if (IS_ATOM_INT(_24809))
        _24806 = (_24809 != 0);
        else
        _24806 = DBL_PTR(_24809)->dbl != 0.0;
L10: 
        _24805 = (_24806 != 0);
LF: 
        if (_24805 == 0) {
            goto L7; // [487] 1011
        }
        _24811 = (_scope_47991 == 13);
        if (_24811 == 0) {
            _24812 = 0;
            goto L11; // [497] 533
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _24813 = (object)*(((s1_ptr)_2)->base + _scanning_file_47983);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24814 = (object)*(((s1_ptr)_2)->base + _st_ptr_47995);
        _2 = (object)SEQ_PTR(_24814);
        if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
            _24815 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
        }
        else{
            _24815 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
        }
        _24814 = NOVALUE;
        _2 = (object)SEQ_PTR(_24813);
        if (!IS_ATOM_INT(_24815)){
            _24816 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24815)->dbl));
        }
        else{
            _24816 = (object)*(((s1_ptr)_2)->base + _24815);
        }
        _24813 = NOVALUE;
        if (IS_ATOM_INT(_24816)) {
            {uintptr_t tu;
                 tu = (uintptr_t)6 & (uintptr_t)_24816;
                 _24817 = MAKE_UINT(tu);
            }
        }
        else {
            _24817 = binary_op(AND_BITS, 6, _24816);
        }
        _24816 = NOVALUE;
        if (IS_ATOM_INT(_24817))
        _24812 = (_24817 != 0);
        else
        _24812 = DBL_PTR(_24817)->dbl != 0.0;
L11: 
        if (_24812 != 0) {
            DeRef(_24818);
            _24818 = 1;
            goto L12; // [533] 583
        }
        _24819 = (_scope_47991 == 11);
        if (_24819 == 0) {
            _24820 = 0;
            goto L13; // [543] 579
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _24821 = (object)*(((s1_ptr)_2)->base + _scanning_file_47983);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24822 = (object)*(((s1_ptr)_2)->base + _st_ptr_47995);
        _2 = (object)SEQ_PTR(_24822);
        if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
            _24823 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
        }
        else{
            _24823 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
        }
        _24822 = NOVALUE;
        _2 = (object)SEQ_PTR(_24821);
        if (!IS_ATOM_INT(_24823)){
            _24824 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24823)->dbl));
        }
        else{
            _24824 = (object)*(((s1_ptr)_2)->base + _24823);
        }
        _24821 = NOVALUE;
        if (IS_ATOM_INT(_24824)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2 & (uintptr_t)_24824;
                 _24825 = MAKE_UINT(tu);
            }
        }
        else {
            _24825 = binary_op(AND_BITS, 2, _24824);
        }
        _24824 = NOVALUE;
        if (IS_ATOM_INT(_24825))
        _24820 = (_24825 != 0);
        else
        _24820 = DBL_PTR(_24825)->dbl != 0.0;
L13: 
        DeRef(_24818);
        _24818 = (_24820 != 0);
L12: 
        if (_24818 == 0)
        {
            _24818 = NOVALUE;
            goto L7; // [584] 1011
        }
        else{
            _24818 = NOVALUE;
        }

        /** symtab.e:826							gtok = tok*/
        Ref(_tok_47998);
        DeRef(_gtok_47999);
        _gtok_47999 = _tok_47998;

        /** symtab.e:827							dup_globals &= st_ptr*/
        Append(&_54dup_globals_47967, _54dup_globals_47967, _st_ptr_47995);

        /** symtab.e:828							in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0 --symbol_in_include_path( st_ptr, scanning_file, {} )*/
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _24827 = (object)*(((s1_ptr)_2)->base + _scanning_file_47983);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24828 = (object)*(((s1_ptr)_2)->base + _st_ptr_47995);
        _2 = (object)SEQ_PTR(_24828);
        if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
            _24829 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
        }
        else{
            _24829 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
        }
        _24828 = NOVALUE;
        _2 = (object)SEQ_PTR(_24827);
        if (!IS_ATOM_INT(_24829)){
            _24830 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24829)->dbl));
        }
        else{
            _24830 = (object)*(((s1_ptr)_2)->base + _24829);
        }
        _24827 = NOVALUE;
        if (IS_ATOM_INT(_24830)) {
            _24831 = (_24830 != 0);
        }
        else {
            _24831 = binary_op(NOTEQ, _24830, 0);
        }
        _24830 = NOVALUE;
        if (IS_SEQUENCE(_54in_include_path_47969) && IS_ATOM(_24831)) {
            Ref(_24831);
            Append(&_54in_include_path_47969, _54in_include_path_47969, _24831);
        }
        else if (IS_ATOM(_54in_include_path_47969) && IS_SEQUENCE(_24831)) {
        }
        else {
            Concat((object_ptr)&_54in_include_path_47969, _54in_include_path_47969, _24831);
        }
        DeRef(_24831);
        _24831 = NOVALUE;

        /** symtab.e:831	ifdef STDDEBUG then*/

        /** symtab.e:852						break*/
        goto L7; // [639] 1011

        /** symtab.e:853					case SC_LOCAL then*/
        case 5:

        /** symtab.e:854						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24833 = (object)*(((s1_ptr)_2)->base + _st_ptr_47995);
        _2 = (object)SEQ_PTR(_24833);
        if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
            _24834 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
        }
        else{
            _24834 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
        }
        _24833 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_47983, _24834)){
            _24834 = NOVALUE;
            goto L7; // [659] 1011
        }
        _24834 = NOVALUE;

        /** symtab.e:857							if BIND then*/
        if (_36BIND_21052 == 0)
        {
            goto L14; // [667] 676
        }
        else{
        }

        /** symtab.e:858								add_ref(tok)*/
        Ref(_tok_47998);
        _54add_ref(_tok_47998);
L14: 

        /** symtab.e:861							return tok*/
        DeRefDS(_word_47981);
        DeRef(_msg_47989);
        DeRef(_b_name_47990);
        DeRef(_gtok_47999);
        DeRef(_24811);
        _24811 = NOVALUE;
        DeRef(_24770);
        _24770 = NOVALUE;
        _24823 = NOVALUE;
        _24788 = NOVALUE;
        _24815 = NOVALUE;
        _24804 = NOVALUE;
        DeRef(_24819);
        _24819 = NOVALUE;
        DeRef(_24825);
        _24825 = NOVALUE;
        _24784 = NOVALUE;
        _24789 = NOVALUE;
        DeRef(_24809);
        _24809 = NOVALUE;
        _24797 = NOVALUE;
        DeRef(_24760);
        _24760 = NOVALUE;
        _24829 = NOVALUE;
        DeRef(_24817);
        _24817 = NOVALUE;
        return _tok_47998;

        /** symtab.e:863						break*/
        goto L7; // [685] 1011

        /** symtab.e:864					case else*/
        default:

        /** symtab.e:866						if BIND then*/
        if (_36BIND_21052 == 0)
        {
            goto L15; // [695] 704
        }
        else{
        }

        /** symtab.e:867							add_ref(tok)*/
        Ref(_tok_47998);
        _54add_ref(_tok_47998);
L15: 

        /** symtab.e:870						return tok -- keyword, private*/
        DeRefDS(_word_47981);
        DeRef(_msg_47989);
        DeRef(_b_name_47990);
        DeRef(_gtok_47999);
        DeRef(_24811);
        _24811 = NOVALUE;
        DeRef(_24770);
        _24770 = NOVALUE;
        _24823 = NOVALUE;
        _24788 = NOVALUE;
        _24815 = NOVALUE;
        _24804 = NOVALUE;
        DeRef(_24819);
        _24819 = NOVALUE;
        DeRef(_24825);
        _24825 = NOVALUE;
        _24784 = NOVALUE;
        _24789 = NOVALUE;
        DeRef(_24809);
        _24809 = NOVALUE;
        _24797 = NOVALUE;
        DeRef(_24760);
        _24760 = NOVALUE;
        _24829 = NOVALUE;
        DeRef(_24817);
        _24817 = NOVALUE;
        return _tok_47998;
    ;}    goto L7; // [711] 1011
L6: 

    /** symtab.e:877					scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_tok_47998);
    _24836 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_24836)){
        _24837 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24836)->dbl));
    }
    else{
        _24837 = (object)*(((s1_ptr)_2)->base + _24836);
    }
    _2 = (object)SEQ_PTR(_24837);
    _scope_47991 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_47991)){
        _scope_47991 = (object)DBL_PTR(_scope_47991)->dbl;
    }
    _24837 = NOVALUE;

    /** symtab.e:878					if not file_no then*/
    if (_file_no_47982 != 0)
    goto L16; // [738] 772

    /** symtab.e:880						if scope = SC_PREDEF then*/
    if (_scope_47991 != 7)
    goto L17; // [745] 1010

    /** symtab.e:881							if BIND then*/
    if (_36BIND_21052 == 0)
    {
        goto L18; // [753] 762
    }
    else{
    }

    /** symtab.e:882								add_ref( tok )*/
    Ref(_tok_47998);
    _54add_ref(_tok_47998);
L18: 

    /** symtab.e:884							return tok*/
    DeRefDS(_word_47981);
    DeRef(_msg_47989);
    DeRef(_b_name_47990);
    DeRef(_gtok_47999);
    DeRef(_24811);
    _24811 = NOVALUE;
    DeRef(_24770);
    _24770 = NOVALUE;
    _24823 = NOVALUE;
    _24788 = NOVALUE;
    _24815 = NOVALUE;
    _24836 = NOVALUE;
    _24804 = NOVALUE;
    DeRef(_24819);
    _24819 = NOVALUE;
    DeRef(_24825);
    _24825 = NOVALUE;
    _24784 = NOVALUE;
    _24789 = NOVALUE;
    DeRef(_24809);
    _24809 = NOVALUE;
    _24797 = NOVALUE;
    DeRef(_24760);
    _24760 = NOVALUE;
    _24829 = NOVALUE;
    DeRef(_24817);
    _24817 = NOVALUE;
    return _tok_47998;
    goto L17; // [769] 1010
L16: 

    /** symtab.e:887						integer tok_file = SymTab[tok[T_SYM]][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_tok_47998);
    _24841 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_24841)){
        _24842 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24841)->dbl));
    }
    else{
        _24842 = (object)*(((s1_ptr)_2)->base + _24841);
    }
    _2 = (object)SEQ_PTR(_24842);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _tok_file_48170 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _tok_file_48170 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    if (!IS_ATOM_INT(_tok_file_48170)){
        _tok_file_48170 = (object)DBL_PTR(_tok_file_48170)->dbl;
    }
    _24842 = NOVALUE;

    /** symtab.e:888						integer good = 0*/
    _good_48177 = 0;

    /** symtab.e:889						if scope = SC_PRIVATE or scope = SC_PREDEF then*/
    _24844 = (_scope_47991 == 3);
    if (_24844 != 0) {
        goto L19; // [807] 940
    }
    _24846 = (_scope_47991 == 7);
    if (_24846 == 0)
    {
        DeRef(_24846);
        _24846 = NOVALUE;
        goto L1A; // [818] 825
    }
    else{
        DeRef(_24846);
        _24846 = NOVALUE;
    }
    goto L19; // [822] 940
L1A: 

    /** symtab.e:892						elsif file_no = tok_file then*/
    if (_file_no_47982 != _tok_file_48170)
    goto L1B; // [827] 839

    /** symtab.e:893							good = 1*/
    _good_48177 = 1;
    goto L19; // [836] 940
L1B: 

    /** symtab.e:896							integer include_type = 0*/
    _include_type_48187 = 0;

    /** symtab.e:897							switch scope do*/
    _0 = _scope_47991;
    switch ( _0 ){ 

        /** symtab.e:898								case SC_GLOBAL then*/
        case 6:

        /** symtab.e:899									if Resolve_unincluded_globals then*/
        if (_54Resolve_unincluded_globals_47972 == 0)
        {
            goto L1C; // [859] 874
        }
        else{
        }

        /** symtab.e:900										include_type = ANY_INCLUDE*/
        _include_type_48187 = 7;
        goto L1D; // [871] 919
L1C: 

        /** symtab.e:902										include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_48187 = 6;
        goto L1D; // [884] 919

        /** symtab.e:905								case SC_PUBLIC then*/
        case 13:

        /** symtab.e:907									if tok_file != file_no then*/
        if (_tok_file_48170 == _file_no_47982)
        goto L1E; // [892] 908

        /** symtab.e:908										include_type = PUBLIC_INCLUDE*/
        _include_type_48187 = 4;
        goto L1F; // [905] 918
L1E: 

        /** symtab.e:910										include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_48187 = 6;
L1F: 
    ;}L1D: 

    /** symtab.e:914							good = and_bits( include_type, include_matrix[file_no][tok_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _24851 = (object)*(((s1_ptr)_2)->base + _file_no_47982);
    _2 = (object)SEQ_PTR(_24851);
    _24852 = (object)*(((s1_ptr)_2)->base + _tok_file_48170);
    _24851 = NOVALUE;
    if (IS_ATOM_INT(_24852)) {
        {uintptr_t tu;
             tu = (uintptr_t)_include_type_48187 & (uintptr_t)_24852;
             _good_48177 = MAKE_UINT(tu);
        }
    }
    else {
        _good_48177 = binary_op(AND_BITS, _include_type_48187, _24852);
    }
    _24852 = NOVALUE;
    if (!IS_ATOM_INT(_good_48177)) {
        _1 = (object)(DBL_PTR(_good_48177)->dbl);
        DeRefDS(_good_48177);
        _good_48177 = _1;
    }
L19: 

    /** symtab.e:917						if good then*/
    if (_good_48177 == 0)
    {
        goto L20; // [942] 1007
    }
    else{
    }

    /** symtab.e:919							if file_no = tok_file then*/
    if (_file_no_47982 != _tok_file_48170)
    goto L21; // [947] 971

    /** symtab.e:920								if BIND then*/
    if (_36BIND_21052 == 0)
    {
        goto L22; // [955] 964
    }
    else{
    }

    /** symtab.e:921									add_ref(tok)*/
    Ref(_tok_47998);
    _54add_ref(_tok_47998);
L22: 

    /** symtab.e:923								return tok*/
    DeRefDS(_word_47981);
    DeRef(_msg_47989);
    DeRef(_b_name_47990);
    DeRef(_gtok_47999);
    DeRef(_24811);
    _24811 = NOVALUE;
    DeRef(_24770);
    _24770 = NOVALUE;
    _24823 = NOVALUE;
    _24788 = NOVALUE;
    _24815 = NOVALUE;
    _24836 = NOVALUE;
    _24804 = NOVALUE;
    DeRef(_24819);
    _24819 = NOVALUE;
    DeRef(_24825);
    _24825 = NOVALUE;
    _24784 = NOVALUE;
    _24789 = NOVALUE;
    DeRef(_24844);
    _24844 = NOVALUE;
    DeRef(_24809);
    _24809 = NOVALUE;
    _24797 = NOVALUE;
    _24841 = NOVALUE;
    DeRef(_24760);
    _24760 = NOVALUE;
    _24829 = NOVALUE;
    DeRef(_24817);
    _24817 = NOVALUE;
    return _tok_47998;
L21: 

    /** symtab.e:926							gtok = tok*/
    Ref(_tok_47998);
    DeRef(_gtok_47999);
    _gtok_47999 = _tok_47998;

    /** symtab.e:927							dup_globals &= st_ptr*/
    Append(&_54dup_globals_47967, _54dup_globals_47967, _st_ptr_47995);

    /** symtab.e:928							in_include_path &= include_matrix[scanning_file][tok_file] != 0*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _24856 = (object)*(((s1_ptr)_2)->base + _scanning_file_47983);
    _2 = (object)SEQ_PTR(_24856);
    _24857 = (object)*(((s1_ptr)_2)->base + _tok_file_48170);
    _24856 = NOVALUE;
    if (IS_ATOM_INT(_24857)) {
        _24858 = (_24857 != 0);
    }
    else {
        _24858 = binary_op(NOTEQ, _24857, 0);
    }
    _24857 = NOVALUE;
    if (IS_SEQUENCE(_54in_include_path_47969) && IS_ATOM(_24858)) {
        Ref(_24858);
        Append(&_54in_include_path_47969, _54in_include_path_47969, _24858);
    }
    else if (IS_ATOM(_54in_include_path_47969) && IS_SEQUENCE(_24858)) {
    }
    else {
        Concat((object_ptr)&_54in_include_path_47969, _54in_include_path_47969, _24858);
    }
    DeRef(_24858);
    _24858 = NOVALUE;
L20: 
L17: 
L7: 
L4: 

    /** symtab.e:936			st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24860 = (object)*(((s1_ptr)_2)->base + _st_ptr_47995);
    _2 = (object)SEQ_PTR(_24860);
    _st_ptr_47995 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_st_ptr_47995)){
        _st_ptr_47995 = (object)DBL_PTR(_st_ptr_47995)->dbl;
    }
    _24860 = NOVALUE;

    /** symtab.e:937		end while*/
    goto L1; // [1030] 69
L2: 

    /** symtab.e:939		if length(dup_overrides) then*/
    if (IS_SEQUENCE(_54dup_overrides_47968)){
            _24862 = SEQ_PTR(_54dup_overrides_47968)->length;
    }
    else {
        _24862 = 1;
    }
    if (_24862 == 0)
    {
        _24862 = NOVALUE;
        goto L23; // [1040] 1093
    }
    else{
        _24862 = NOVALUE;
    }

    /** symtab.e:940			st_ptr = dup_overrides[1]*/
    _2 = (object)SEQ_PTR(_54dup_overrides_47968);
    _st_ptr_47995 = (object)*(((s1_ptr)_2)->base + 1);

    /** symtab.e:941			tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24864 = (object)*(((s1_ptr)_2)->base + _st_ptr_47995);
    _2 = (object)SEQ_PTR(_24864);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _24865 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _24865 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    _24864 = NOVALUE;
    Ref(_24865);
    DeRef(_tok_47998);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24865;
    ((intptr_t *)_2)[2] = _st_ptr_47995;
    _tok_47998 = MAKE_SEQ(_1);
    _24865 = NOVALUE;

    /** symtab.e:944				if BIND then*/
    if (_36BIND_21052 == 0)
    {
        goto L24; // [1075] 1084
    }
    else{
    }

    /** symtab.e:945					add_ref(tok)*/
    RefDS(_tok_47998);
    _54add_ref(_tok_47998);
L24: 

    /** symtab.e:948				return tok*/
    DeRefDS(_word_47981);
    DeRef(_msg_47989);
    DeRef(_b_name_47990);
    DeRef(_gtok_47999);
    DeRef(_24811);
    _24811 = NOVALUE;
    DeRef(_24770);
    _24770 = NOVALUE;
    _24823 = NOVALUE;
    _24788 = NOVALUE;
    _24815 = NOVALUE;
    _24836 = NOVALUE;
    _24804 = NOVALUE;
    DeRef(_24819);
    _24819 = NOVALUE;
    DeRef(_24825);
    _24825 = NOVALUE;
    _24784 = NOVALUE;
    _24789 = NOVALUE;
    DeRef(_24844);
    _24844 = NOVALUE;
    DeRef(_24809);
    _24809 = NOVALUE;
    _24797 = NOVALUE;
    _24841 = NOVALUE;
    DeRef(_24760);
    _24760 = NOVALUE;
    _24829 = NOVALUE;
    DeRef(_24817);
    _24817 = NOVALUE;
    return _tok_47998;
    goto L25; // [1090] 1320
L23: 

    /** symtab.e:951		elsif st_builtin != 0 then*/
    if (_st_builtin_47996 == 0)
    goto L26; // [1095] 1319

    /** symtab.e:952			if length(dup_globals) and find(SymTab[st_builtin][S_NAME], builtin_warnings) = 0 then*/
    if (IS_SEQUENCE(_54dup_globals_47967)){
            _24868 = SEQ_PTR(_54dup_globals_47967)->length;
    }
    else {
        _24868 = 1;
    }
    if (_24868 == 0) {
        goto L27; // [1106] 1279
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24870 = (object)*(((s1_ptr)_2)->base + _st_builtin_47996);
    _2 = (object)SEQ_PTR(_24870);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _24871 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _24871 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _24870 = NOVALUE;
    _24872 = find_from(_24871, _54builtin_warnings_47971, 1);
    _24871 = NOVALUE;
    _24873 = (_24872 == 0);
    _24872 = NOVALUE;
    if (_24873 == 0)
    {
        DeRef(_24873);
        _24873 = NOVALUE;
        goto L27; // [1134] 1279
    }
    else{
        DeRef(_24873);
        _24873 = NOVALUE;
    }

    /** symtab.e:953				sequence msg_file */

    /** symtab.e:955				b_name = SymTab[st_builtin][S_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24874 = (object)*(((s1_ptr)_2)->base + _st_builtin_47996);
    DeRef(_b_name_47990);
    _2 = (object)SEQ_PTR(_24874);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _b_name_47990 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _b_name_47990 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    Ref(_b_name_47990);
    _24874 = NOVALUE;

    /** symtab.e:956				builtin_warnings = append(builtin_warnings, b_name)*/
    RefDS(_b_name_47990);
    Append(&_54builtin_warnings_47971, _54builtin_warnings_47971, _b_name_47990);

    /** symtab.e:958				if length(dup_globals) > 1 then*/
    if (IS_SEQUENCE(_54dup_globals_47967)){
            _24877 = SEQ_PTR(_54dup_globals_47967)->length;
    }
    else {
        _24877 = 1;
    }
    if (_24877 <= 1)
    goto L28; // [1170] 1184

    /** symtab.e:959					msg = "\n"*/
    RefDS(_22192);
    DeRef(_msg_47989);
    _msg_47989 = _22192;
    goto L29; // [1181] 1192
L28: 

    /** symtab.e:961					msg = ""*/
    RefDS(_21997);
    DeRef(_msg_47989);
    _msg_47989 = _21997;
L29: 

    /** symtab.e:964				for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_54dup_globals_47967)){
            _24879 = SEQ_PTR(_54dup_globals_47967)->length;
    }
    else {
        _24879 = 1;
    }
    {
        object _i_48254;
        _i_48254 = 1;
L2A: 
        if (_i_48254 > _24879){
            goto L2B; // [1199] 1255
        }

        /** symtab.e:965					msg_file = known_files[SymTab[dup_globals[i]][S_FILE_NO]]*/
        _2 = (object)SEQ_PTR(_54dup_globals_47967);
        _24880 = (object)*(((s1_ptr)_2)->base + _i_48254);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_24880)){
            _24881 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24880)->dbl));
        }
        else{
            _24881 = (object)*(((s1_ptr)_2)->base + _24880);
        }
        _2 = (object)SEQ_PTR(_24881);
        if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
            _24882 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
        }
        else{
            _24882 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
        }
        _24881 = NOVALUE;
        DeRef(_msg_file_48243);
        _2 = (object)SEQ_PTR(_37known_files_15407);
        if (!IS_ATOM_INT(_24882)){
            _msg_file_48243 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24882)->dbl));
        }
        else{
            _msg_file_48243 = (object)*(((s1_ptr)_2)->base + _24882);
        }
        Ref(_msg_file_48243);

        /** symtab.e:966					msg &= "    " & msg_file & "\n"*/
        {
            object concat_list[3];

            concat_list[0] = _22192;
            concat_list[1] = _msg_file_48243;
            concat_list[2] = _24884;
            Concat_N((object_ptr)&_24885, concat_list, 3);
        }
        Concat((object_ptr)&_msg_47989, _msg_47989, _24885);
        DeRefDS(_24885);
        _24885 = NOVALUE;

        /** symtab.e:967				end for*/
        _i_48254 = _i_48254 + 1;
        goto L2A; // [1250] 1206
L2B: 
        ;
    }

    /** symtab.e:969				Warning(234, builtin_chosen_warning_flag, {b_name, known_files[scanning_file], msg})*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _24887 = (object)*(((s1_ptr)_2)->base + _scanning_file_47983);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_b_name_47990);
    ((intptr_t*)_2)[1] = _b_name_47990;
    Ref(_24887);
    ((intptr_t*)_2)[2] = _24887;
    RefDS(_msg_47989);
    ((intptr_t*)_2)[3] = _msg_47989;
    _24888 = MAKE_SEQ(_1);
    _24887 = NOVALUE;
    _50Warning(234, 8, _24888);
    _24888 = NOVALUE;
L27: 
    DeRef(_msg_file_48243);
    _msg_file_48243 = NOVALUE;

    /** symtab.e:972			tok = {SymTab[st_builtin][S_TOKEN], st_builtin}*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24889 = (object)*(((s1_ptr)_2)->base + _st_builtin_47996);
    _2 = (object)SEQ_PTR(_24889);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _24890 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _24890 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    _24889 = NOVALUE;
    Ref(_24890);
    DeRef(_tok_47998);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24890;
    ((intptr_t *)_2)[2] = _st_builtin_47996;
    _tok_47998 = MAKE_SEQ(_1);
    _24890 = NOVALUE;

    /** symtab.e:974			if BIND then*/
    if (_36BIND_21052 == 0)
    {
        goto L2C; // [1303] 1312
    }
    else{
    }

    /** symtab.e:975				add_ref(tok)*/
    RefDS(_tok_47998);
    _54add_ref(_tok_47998);
L2C: 

    /** symtab.e:978			return tok*/
    DeRefDS(_word_47981);
    DeRef(_msg_47989);
    DeRef(_b_name_47990);
    DeRef(_gtok_47999);
    DeRef(_24811);
    _24811 = NOVALUE;
    DeRef(_24770);
    _24770 = NOVALUE;
    _24823 = NOVALUE;
    _24788 = NOVALUE;
    _24815 = NOVALUE;
    _24836 = NOVALUE;
    _24804 = NOVALUE;
    DeRef(_24819);
    _24819 = NOVALUE;
    DeRef(_24825);
    _24825 = NOVALUE;
    _24784 = NOVALUE;
    _24789 = NOVALUE;
    DeRef(_24844);
    _24844 = NOVALUE;
    _24882 = NOVALUE;
    DeRef(_24809);
    _24809 = NOVALUE;
    _24797 = NOVALUE;
    _24880 = NOVALUE;
    _24841 = NOVALUE;
    DeRef(_24760);
    _24760 = NOVALUE;
    _24829 = NOVALUE;
    DeRef(_24817);
    _24817 = NOVALUE;
    return _tok_47998;
L26: 
L25: 

    /** symtab.e:981	ifdef STDDEBUG then*/

    /** symtab.e:996		if length(dup_globals) > 1 and find( 1, in_include_path ) then*/
    if (IS_SEQUENCE(_54dup_globals_47967)){
            _24892 = SEQ_PTR(_54dup_globals_47967)->length;
    }
    else {
        _24892 = 1;
    }
    _24893 = (_24892 > 1);
    _24892 = NOVALUE;
    if (_24893 == 0) {
        goto L2D; // [1333] 1452
    }
    _24895 = find_from(1, _54in_include_path_47969, 1);
    if (_24895 == 0)
    {
        _24895 = NOVALUE;
        goto L2D; // [1345] 1452
    }
    else{
        _24895 = NOVALUE;
    }

    /** symtab.e:998			ix = 1*/
    _ix_47993 = 1;

    /** symtab.e:999			while ix <= length(dup_globals) do*/
L2E: 
    if (IS_SEQUENCE(_54dup_globals_47967)){
            _24896 = SEQ_PTR(_54dup_globals_47967)->length;
    }
    else {
        _24896 = 1;
    }
    if (_ix_47993 > _24896)
    goto L2F; // [1363] 1411

    /** symtab.e:1000				if in_include_path[ix] then*/
    _2 = (object)SEQ_PTR(_54in_include_path_47969);
    _24898 = (object)*(((s1_ptr)_2)->base + _ix_47993);
    if (_24898 == 0) {
        _24898 = NOVALUE;
        goto L30; // [1375] 1387
    }
    else {
        if (!IS_ATOM_INT(_24898) && DBL_PTR(_24898)->dbl == 0.0){
            _24898 = NOVALUE;
            goto L30; // [1375] 1387
        }
        _24898 = NOVALUE;
    }
    _24898 = NOVALUE;

    /** symtab.e:1001					ix += 1*/
    _ix_47993 = _ix_47993 + 1;
    goto L2E; // [1384] 1358
L30: 

    /** symtab.e:1003					dup_globals     = remove( dup_globals, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_54dup_globals_47967);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_47993)) ? _ix_47993 : (object)(DBL_PTR(_ix_47993)->dbl);
        int stop = (IS_ATOM_INT(_ix_47993)) ? _ix_47993 : (object)(DBL_PTR(_ix_47993)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_54dup_globals_47967), start, &_54dup_globals_47967 );
            }
            else Tail(SEQ_PTR(_54dup_globals_47967), stop+1, &_54dup_globals_47967);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_54dup_globals_47967), start, &_54dup_globals_47967);
        }
        else {
            assign_slice_seq = &assign_space;
            _54dup_globals_47967 = Remove_elements(start, stop, (SEQ_PTR(_54dup_globals_47967)->ref == 1));
        }
    }

    /** symtab.e:1004					in_include_path = remove( in_include_path, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_54in_include_path_47969);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_47993)) ? _ix_47993 : (object)(DBL_PTR(_ix_47993)->dbl);
        int stop = (IS_ATOM_INT(_ix_47993)) ? _ix_47993 : (object)(DBL_PTR(_ix_47993)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_54in_include_path_47969), start, &_54in_include_path_47969 );
            }
            else Tail(SEQ_PTR(_54in_include_path_47969), stop+1, &_54in_include_path_47969);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_54in_include_path_47969), start, &_54in_include_path_47969);
        }
        else {
            assign_slice_seq = &assign_space;
            _54in_include_path_47969 = Remove_elements(start, stop, (SEQ_PTR(_54in_include_path_47969)->ref == 1));
        }
    }

    /** symtab.e:1006			end while*/
    goto L2E; // [1408] 1358
L2F: 

    /** symtab.e:1008			if length(dup_globals) = 1 then*/
    if (IS_SEQUENCE(_54dup_globals_47967)){
            _24902 = SEQ_PTR(_54dup_globals_47967)->length;
    }
    else {
        _24902 = 1;
    }
    if (_24902 != 1)
    goto L31; // [1418] 1451

    /** symtab.e:1009					st_ptr = dup_globals[1]*/
    _2 = (object)SEQ_PTR(_54dup_globals_47967);
    _st_ptr_47995 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_st_ptr_47995)){
        _st_ptr_47995 = (object)DBL_PTR(_st_ptr_47995)->dbl;
    }

    /** symtab.e:1010					gtok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24905 = (object)*(((s1_ptr)_2)->base + _st_ptr_47995);
    _2 = (object)SEQ_PTR(_24905);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _24906 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _24906 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    _24905 = NOVALUE;
    Ref(_24906);
    DeRef(_gtok_47999);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24906;
    ((intptr_t *)_2)[2] = _st_ptr_47995;
    _gtok_47999 = MAKE_SEQ(_1);
    _24906 = NOVALUE;
L31: 
L2D: 

    /** symtab.e:1014	ifdef STDDEBUG then*/

    /** symtab.e:1023		if length(dup_globals) = 1 and st_builtin = 0 then*/
    if (IS_SEQUENCE(_54dup_globals_47967)){
            _24908 = SEQ_PTR(_54dup_globals_47967)->length;
    }
    else {
        _24908 = 1;
    }
    _24909 = (_24908 == 1);
    _24908 = NOVALUE;
    if (_24909 == 0) {
        goto L32; // [1465] 1644
    }
    _24911 = (_st_builtin_47996 == 0);
    if (_24911 == 0)
    {
        DeRef(_24911);
        _24911 = NOVALUE;
        goto L32; // [1474] 1644
    }
    else{
        DeRef(_24911);
        _24911 = NOVALUE;
    }

    /** symtab.e:1026			if BIND then*/
    if (_36BIND_21052 == 0)
    {
        goto L33; // [1481] 1492
    }
    else{
    }

    /** symtab.e:1027				add_ref(gtok)*/
    Ref(_gtok_47999);
    _54add_ref(_gtok_47999);
L33: 

    /** symtab.e:1029			if not in_include_path[1] and*/
    _2 = (object)SEQ_PTR(_54in_include_path_47969);
    _24912 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24912)) {
        _24913 = (_24912 == 0);
    }
    else {
        _24913 = unary_op(NOT, _24912);
    }
    _24912 = NOVALUE;
    if (IS_ATOM_INT(_24913)) {
        if (_24913 == 0) {
            goto L34; // [1503] 1637
        }
    }
    else {
        if (DBL_PTR(_24913)->dbl == 0.0) {
            goto L34; // [1503] 1637
        }
    }
    _2 = (object)SEQ_PTR(_gtok_47999);
    _24915 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_24915)){
        _24916 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24915)->dbl));
    }
    else{
        _24916 = (object)*(((s1_ptr)_2)->base + _24915);
    }
    _2 = (object)SEQ_PTR(_24916);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _24917 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _24917 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _24916 = NOVALUE;
    Ref(_24917);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _scanning_file_47983;
    ((intptr_t *)_2)[2] = _24917;
    _24918 = MAKE_SEQ(_1);
    _24917 = NOVALUE;
    _24919 = find_from(_24918, _54include_warnings_47970, 1);
    DeRefDS(_24918);
    _24918 = NOVALUE;
    _24920 = (_24919 == 0);
    _24919 = NOVALUE;
    if (_24920 == 0)
    {
        DeRef(_24920);
        _24920 = NOVALUE;
        goto L34; // [1542] 1637
    }
    else{
        DeRef(_24920);
        _24920 = NOVALUE;
    }

    /** symtab.e:1032				include_warnings = prepend( include_warnings,*/
    _2 = (object)SEQ_PTR(_gtok_47999);
    _24921 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_24921)){
        _24922 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24921)->dbl));
    }
    else{
        _24922 = (object)*(((s1_ptr)_2)->base + _24921);
    }
    _2 = (object)SEQ_PTR(_24922);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _24923 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _24923 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _24922 = NOVALUE;
    Ref(_24923);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _scanning_file_47983;
    ((intptr_t *)_2)[2] = _24923;
    _24924 = MAKE_SEQ(_1);
    _24923 = NOVALUE;
    RefDS(_24924);
    Prepend(&_54include_warnings_47970, _54include_warnings_47970, _24924);
    DeRefDS(_24924);
    _24924 = NOVALUE;

    /** symtab.e:1034	ifdef STDDEBUG then*/

    /** symtab.e:1040					symbol_resolution_warning = GetMsgText(MSG_12__IDENTIFIER_3_IN_4_IS_NOT_INCLUDED,0,*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _24926 = (object)*(((s1_ptr)_2)->base + _scanning_file_47983);
    Ref(_24926);
    _24927 = _54name_ext(_24926);
    _24926 = NOVALUE;
    _2 = (object)SEQ_PTR(_gtok_47999);
    _24928 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_24928)){
        _24929 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24928)->dbl));
    }
    else{
        _24929 = (object)*(((s1_ptr)_2)->base + _24928);
    }
    _2 = (object)SEQ_PTR(_24929);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _24930 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _24930 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _24929 = NOVALUE;
    _2 = (object)SEQ_PTR(_37known_files_15407);
    if (!IS_ATOM_INT(_24930)){
        _24931 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24930)->dbl));
    }
    else{
        _24931 = (object)*(((s1_ptr)_2)->base + _24930);
    }
    Ref(_24931);
    _24932 = _54name_ext(_24931);
    _24931 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24927;
    ((intptr_t*)_2)[2] = _36line_number_21448;
    RefDS(_word_47981);
    ((intptr_t*)_2)[3] = _word_47981;
    ((intptr_t*)_2)[4] = _24932;
    _24933 = MAKE_SEQ(_1);
    _24932 = NOVALUE;
    _24927 = NOVALUE;
    _0 = _39GetMsgText(233, 0, _24933);
    DeRef(_36symbol_resolution_warning_21552);
    _36symbol_resolution_warning_21552 = _0;
    _24933 = NOVALUE;
L34: 

    /** symtab.e:1047			return gtok*/
    DeRefDS(_word_47981);
    DeRef(_msg_47989);
    DeRef(_b_name_47990);
    DeRef(_tok_47998);
    DeRef(_24811);
    _24811 = NOVALUE;
    _24915 = NOVALUE;
    DeRef(_24770);
    _24770 = NOVALUE;
    _24823 = NOVALUE;
    _24788 = NOVALUE;
    _24815 = NOVALUE;
    DeRef(_24909);
    _24909 = NOVALUE;
    _24836 = NOVALUE;
    _24930 = NOVALUE;
    _24804 = NOVALUE;
    DeRef(_24893);
    _24893 = NOVALUE;
    DeRef(_24819);
    _24819 = NOVALUE;
    DeRef(_24825);
    _24825 = NOVALUE;
    _24784 = NOVALUE;
    _24789 = NOVALUE;
    DeRef(_24844);
    _24844 = NOVALUE;
    DeRef(_24913);
    _24913 = NOVALUE;
    _24882 = NOVALUE;
    DeRef(_24809);
    _24809 = NOVALUE;
    _24797 = NOVALUE;
    _24880 = NOVALUE;
    _24841 = NOVALUE;
    _24921 = NOVALUE;
    DeRef(_24760);
    _24760 = NOVALUE;
    _24928 = NOVALUE;
    _24829 = NOVALUE;
    DeRef(_24817);
    _24817 = NOVALUE;
    return _gtok_47999;
L32: 

    /** symtab.e:1051		if length(dup_globals) = 0 then*/
    if (IS_SEQUENCE(_54dup_globals_47967)){
            _24935 = SEQ_PTR(_54dup_globals_47967)->length;
    }
    else {
        _24935 = 1;
    }
    if (_24935 != 0)
    goto L35; // [1651] 1725

    /** symtab.e:1052			defined = SC_UNDEFINED*/
    _defined_47992 = 9;

    /** symtab.e:1054			if fwd_line_number then*/
    if (_36fwd_line_number_21449 == 0)
    {
        goto L36; // [1668] 1697
    }
    else{
    }

    /** symtab.e:1055				last_ForwardLine     = ForwardLine*/
    Ref(_50ForwardLine_49239);
    DeRef(_50last_ForwardLine_49241);
    _50last_ForwardLine_49241 = _50ForwardLine_49239;

    /** symtab.e:1056				last_forward_bp      = forward_bp*/
    _50last_forward_bp_49245 = _50forward_bp_49243;

    /** symtab.e:1057				last_fwd_line_number = fwd_line_number*/
    _36last_fwd_line_number_21451 = _36fwd_line_number_21449;
L36: 

    /** symtab.e:1060			ForwardLine = ThisLine*/
    Ref(_50ThisLine_49238);
    DeRef(_50ForwardLine_49239);
    _50ForwardLine_49239 = _50ThisLine_49238;

    /** symtab.e:1061			forward_bp = bp*/
    _50forward_bp_49243 = _50bp_49242;

    /** symtab.e:1062			fwd_line_number = line_number*/
    _36fwd_line_number_21449 = _36line_number_21448;
    goto L37; // [1722] 1768
L35: 

    /** symtab.e:1064		elsif length(dup_globals) then*/
    if (IS_SEQUENCE(_54dup_globals_47967)){
            _24937 = SEQ_PTR(_54dup_globals_47967)->length;
    }
    else {
        _24937 = 1;
    }
    if (_24937 == 0)
    {
        _24937 = NOVALUE;
        goto L38; // [1732] 1747
    }
    else{
        _24937 = NOVALUE;
    }

    /** symtab.e:1065			defined = SC_MULTIPLY_DEFINED*/
    _defined_47992 = 10;
    goto L37; // [1744] 1768
L38: 

    /** symtab.e:1066		elsif length(dup_overrides) then*/
    if (IS_SEQUENCE(_54dup_overrides_47968)){
            _24938 = SEQ_PTR(_54dup_overrides_47968)->length;
    }
    else {
        _24938 = 1;
    }
    if (_24938 == 0)
    {
        _24938 = NOVALUE;
        goto L39; // [1754] 1767
    }
    else{
        _24938 = NOVALUE;
    }

    /** symtab.e:1067			defined = SC_OVERRIDE*/
    _defined_47992 = 12;
L39: 
L37: 

    /** symtab.e:1070		if No_new_entry then*/
    if (_54No_new_entry_47978 == 0)
    {
        goto L3A; // [1772] 1795
    }
    else{
    }

    /** symtab.e:1071			return {IGNORED,word,defined,dup_globals}*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 509;
    RefDS(_word_47981);
    ((intptr_t*)_2)[2] = _word_47981;
    ((intptr_t*)_2)[3] = _defined_47992;
    RefDS(_54dup_globals_47967);
    ((intptr_t*)_2)[4] = _54dup_globals_47967;
    _24939 = MAKE_SEQ(_1);
    DeRefDS(_word_47981);
    DeRef(_msg_47989);
    DeRef(_b_name_47990);
    DeRef(_tok_47998);
    DeRef(_gtok_47999);
    DeRef(_24811);
    _24811 = NOVALUE;
    _24915 = NOVALUE;
    DeRef(_24770);
    _24770 = NOVALUE;
    _24823 = NOVALUE;
    _24788 = NOVALUE;
    _24815 = NOVALUE;
    DeRef(_24909);
    _24909 = NOVALUE;
    _24836 = NOVALUE;
    _24930 = NOVALUE;
    _24804 = NOVALUE;
    DeRef(_24893);
    _24893 = NOVALUE;
    DeRef(_24819);
    _24819 = NOVALUE;
    DeRef(_24825);
    _24825 = NOVALUE;
    _24784 = NOVALUE;
    _24789 = NOVALUE;
    DeRef(_24844);
    _24844 = NOVALUE;
    DeRef(_24913);
    _24913 = NOVALUE;
    _24882 = NOVALUE;
    DeRef(_24809);
    _24809 = NOVALUE;
    _24797 = NOVALUE;
    _24880 = NOVALUE;
    _24841 = NOVALUE;
    _24921 = NOVALUE;
    DeRef(_24760);
    _24760 = NOVALUE;
    _24928 = NOVALUE;
    _24829 = NOVALUE;
    DeRef(_24817);
    _24817 = NOVALUE;
    return _24939;
L3A: 

    /** symtab.e:1074		tok = {VARIABLE, NewEntry(word, 0, defined,*/
    _2 = (object)SEQ_PTR(_54buckets_46776);
    _24940 = (object)*(((s1_ptr)_2)->base + _hashval_47987);
    RefDS(_word_47981);
    Ref(_24940);
    _24941 = _54NewEntry(_word_47981, 0, _defined_47992, -100, _hashval_47987, _24940, 0);
    _24940 = NOVALUE;
    DeRef(_tok_47998);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _24941;
    _tok_47998 = MAKE_SEQ(_1);
    _24941 = NOVALUE;

    /** symtab.e:1076		buckets[hashval] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_47998);
    _24943 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_24943);
    _2 = (object)SEQ_PTR(_54buckets_46776);
    _2 = (object)(((s1_ptr)_2)->base + _hashval_47987);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24943;
    if( _1 != _24943 ){
        DeRef(_1);
    }
    _24943 = NOVALUE;

    /** symtab.e:1078		if file_no != -1 then*/
    if (_file_no_47982 == -1)
    goto L3B; // [1839] 1865

    /** symtab.e:1079			SymTab[tok[T_SYM]][S_FILE_NO] = file_no*/
    _2 = (object)SEQ_PTR(_tok_47998);
    _24945 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_24945))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_24945)->dbl));
    else
    _3 = (object)(_24945 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FILE_NO_21080))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _file_no_47982;
    DeRef(_1);
    _24946 = NOVALUE;
L3B: 

    /** symtab.e:1081		return tok  -- no ref on newly declared symbol*/
    DeRefDS(_word_47981);
    DeRef(_msg_47989);
    DeRef(_b_name_47990);
    DeRef(_gtok_47999);
    DeRef(_24811);
    _24811 = NOVALUE;
    _24915 = NOVALUE;
    DeRef(_24770);
    _24770 = NOVALUE;
    _24823 = NOVALUE;
    _24788 = NOVALUE;
    _24815 = NOVALUE;
    DeRef(_24939);
    _24939 = NOVALUE;
    DeRef(_24909);
    _24909 = NOVALUE;
    _24836 = NOVALUE;
    _24930 = NOVALUE;
    _24804 = NOVALUE;
    DeRef(_24893);
    _24893 = NOVALUE;
    DeRef(_24819);
    _24819 = NOVALUE;
    DeRef(_24825);
    _24825 = NOVALUE;
    _24784 = NOVALUE;
    _24789 = NOVALUE;
    DeRef(_24844);
    _24844 = NOVALUE;
    DeRef(_24913);
    _24913 = NOVALUE;
    _24882 = NOVALUE;
    DeRef(_24809);
    _24809 = NOVALUE;
    _24797 = NOVALUE;
    _24880 = NOVALUE;
    _24841 = NOVALUE;
    _24921 = NOVALUE;
    DeRef(_24760);
    _24760 = NOVALUE;
    _24928 = NOVALUE;
    _24945 = NOVALUE;
    _24829 = NOVALUE;
    DeRef(_24817);
    _24817 = NOVALUE;
    return _tok_47998;
    ;
}


void _54Hide(object _s_48392)
{
    object _prev_48394 = NOVALUE;
    object _p_48395 = NOVALUE;
    object _24966 = NOVALUE;
    object _24965 = NOVALUE;
    object _24964 = NOVALUE;
    object _24962 = NOVALUE;
    object _24961 = NOVALUE;
    object _24960 = NOVALUE;
    object _24959 = NOVALUE;
    object _24958 = NOVALUE;
    object _24954 = NOVALUE;
    object _24953 = NOVALUE;
    object _24952 = NOVALUE;
    object _24951 = NOVALUE;
    object _24949 = NOVALUE;
    object _24948 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_48392)) {
        _1 = (object)(DBL_PTR(_s_48392)->dbl);
        DeRefDS(_s_48392);
        _s_48392 = _1;
    }

    /** symtab.e:1090		p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24948 = (object)*(((s1_ptr)_2)->base + _s_48392);
    _2 = (object)SEQ_PTR(_24948);
    _24949 = (object)*(((s1_ptr)_2)->base + 11);
    _24948 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_46776);
    if (!IS_ATOM_INT(_24949)){
        _p_48395 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24949)->dbl));
    }
    else{
        _p_48395 = (object)*(((s1_ptr)_2)->base + _24949);
    }
    if (!IS_ATOM_INT(_p_48395)){
        _p_48395 = (object)DBL_PTR(_p_48395)->dbl;
    }

    /** symtab.e:1091		prev = 0*/
    _prev_48394 = 0;

    /** symtab.e:1093		while p != s and p != 0 do*/
L1: 
    _24951 = (_p_48395 != _s_48392);
    if (_24951 == 0) {
        goto L2; // [41] 81
    }
    _24953 = (_p_48395 != 0);
    if (_24953 == 0)
    {
        DeRef(_24953);
        _24953 = NOVALUE;
        goto L2; // [50] 81
    }
    else{
        DeRef(_24953);
        _24953 = NOVALUE;
    }

    /** symtab.e:1094			prev = p*/
    _prev_48394 = _p_48395;

    /** symtab.e:1095			p = SymTab[p][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24954 = (object)*(((s1_ptr)_2)->base + _p_48395);
    _2 = (object)SEQ_PTR(_24954);
    _p_48395 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_p_48395)){
        _p_48395 = (object)DBL_PTR(_p_48395)->dbl;
    }
    _24954 = NOVALUE;

    /** symtab.e:1096		end while*/
    goto L1; // [78] 37
L2: 

    /** symtab.e:1098		if p = 0 then*/
    if (_p_48395 != 0)
    goto L3; // [83] 93

    /** symtab.e:1099			return -- already hidden*/
    _24949 = NOVALUE;
    DeRef(_24951);
    _24951 = NOVALUE;
    return;
L3: 

    /** symtab.e:1101		if prev = 0 then*/
    if (_prev_48394 != 0)
    goto L4; // [95] 134

    /** symtab.e:1102			buckets[SymTab[s][S_HASHVAL]] = SymTab[s][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24958 = (object)*(((s1_ptr)_2)->base + _s_48392);
    _2 = (object)SEQ_PTR(_24958);
    _24959 = (object)*(((s1_ptr)_2)->base + 11);
    _24958 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24960 = (object)*(((s1_ptr)_2)->base + _s_48392);
    _2 = (object)SEQ_PTR(_24960);
    _24961 = (object)*(((s1_ptr)_2)->base + 9);
    _24960 = NOVALUE;
    Ref(_24961);
    _2 = (object)SEQ_PTR(_54buckets_46776);
    if (!IS_ATOM_INT(_24959))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_24959)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _24959);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24961;
    if( _1 != _24961 ){
        DeRef(_1);
    }
    _24961 = NOVALUE;
    goto L5; // [131] 162
L4: 

    /** symtab.e:1104			SymTab[prev][S_SAMEHASH] = SymTab[s][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_48394 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24964 = (object)*(((s1_ptr)_2)->base + _s_48392);
    _2 = (object)SEQ_PTR(_24964);
    _24965 = (object)*(((s1_ptr)_2)->base + 9);
    _24964 = NOVALUE;
    Ref(_24965);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24965;
    if( _1 != _24965 ){
        DeRef(_1);
    }
    _24965 = NOVALUE;
    _24962 = NOVALUE;
L5: 

    /** symtab.e:1106		SymTab[s][S_SAMEHASH] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48392 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _24966 = NOVALUE;

    /** symtab.e:1107	end procedure*/
    _24949 = NOVALUE;
    _24959 = NOVALUE;
    DeRef(_24951);
    _24951 = NOVALUE;
    return;
    ;
}


void _54Show(object _s_48437)
{
    object _p_48439 = NOVALUE;
    object _24978 = NOVALUE;
    object _24977 = NOVALUE;
    object _24975 = NOVALUE;
    object _24974 = NOVALUE;
    object _24972 = NOVALUE;
    object _24971 = NOVALUE;
    object _24969 = NOVALUE;
    object _24968 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:1114		p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24968 = (object)*(((s1_ptr)_2)->base + _s_48437);
    _2 = (object)SEQ_PTR(_24968);
    _24969 = (object)*(((s1_ptr)_2)->base + 11);
    _24968 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_46776);
    if (!IS_ATOM_INT(_24969)){
        _p_48439 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24969)->dbl));
    }
    else{
        _p_48439 = (object)*(((s1_ptr)_2)->base + _24969);
    }
    if (!IS_ATOM_INT(_p_48439)){
        _p_48439 = (object)DBL_PTR(_p_48439)->dbl;
    }

    /** symtab.e:1116		if SymTab[s][S_SAMEHASH] or p = s then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24971 = (object)*(((s1_ptr)_2)->base + _s_48437);
    _2 = (object)SEQ_PTR(_24971);
    _24972 = (object)*(((s1_ptr)_2)->base + 9);
    _24971 = NOVALUE;
    if (IS_ATOM_INT(_24972)) {
        if (_24972 != 0) {
            goto L1; // [39] 52
        }
    }
    else {
        if (DBL_PTR(_24972)->dbl != 0.0) {
            goto L1; // [39] 52
        }
    }
    _24974 = (_p_48439 == _s_48437);
    if (_24974 == 0)
    {
        DeRef(_24974);
        _24974 = NOVALUE;
        goto L2; // [48] 58
    }
    else{
        DeRef(_24974);
        _24974 = NOVALUE;
    }
L1: 

    /** symtab.e:1118			return*/
    _24969 = NOVALUE;
    _24972 = NOVALUE;
    return;
L2: 

    /** symtab.e:1121		SymTab[s][S_SAMEHASH] = p*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48437 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_48439;
    DeRef(_1);
    _24975 = NOVALUE;

    /** symtab.e:1122		buckets[SymTab[s][S_HASHVAL]] = s*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24977 = (object)*(((s1_ptr)_2)->base + _s_48437);
    _2 = (object)SEQ_PTR(_24977);
    _24978 = (object)*(((s1_ptr)_2)->base + 11);
    _24977 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_46776);
    if (!IS_ATOM_INT(_24978))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_24978)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _24978);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_48437;
    DeRef(_1);

    /** symtab.e:1124	end procedure*/
    _24978 = NOVALUE;
    _24969 = NOVALUE;
    _24972 = NOVALUE;
    return;
    ;
}


void _54hide_params(object _s_48463)
{
    object _param_48465 = NOVALUE;
    object _24981 = NOVALUE;
    object _24980 = NOVALUE;
    object _24979 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1127		symtab_index param = s*/
    _param_48465 = _s_48463;

    /** symtab.e:1128		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24979 = (object)*(((s1_ptr)_2)->base + _s_48463);
    _2 = (object)SEQ_PTR(_24979);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
        _24980 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
    }
    else{
        _24980 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
    }
    _24979 = NOVALUE;
    {
        object _i_48467;
        _i_48467 = 1;
L1: 
        if (binary_op_a(GREATER, _i_48467, _24980)){
            goto L2; // [24] 59
        }

        /** symtab.e:1129			param = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24981 = (object)*(((s1_ptr)_2)->base + _s_48463);
        _2 = (object)SEQ_PTR(_24981);
        _param_48465 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_48465)){
            _param_48465 = (object)DBL_PTR(_param_48465)->dbl;
        }
        _24981 = NOVALUE;

        /** symtab.e:1130			Hide( param )*/
        _54Hide(_param_48465);

        /** symtab.e:1131		end for*/
        _0 = _i_48467;
        if (IS_ATOM_INT(_i_48467)) {
            _i_48467 = _i_48467 + 1;
            if ((object)((uintptr_t)_i_48467 +(uintptr_t) HIGH_BITS) >= 0){
                _i_48467 = NewDouble((eudouble)_i_48467);
            }
        }
        else {
            _i_48467 = binary_op_a(PLUS, _i_48467, 1);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_48467);
    }

    /** symtab.e:1132	end procedure*/
    _24980 = NOVALUE;
    return;
    ;
}


void _54show_params(object _s_48479)
{
    object _param_48481 = NOVALUE;
    object _24985 = NOVALUE;
    object _24984 = NOVALUE;
    object _24983 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1135		symtab_index param = s*/
    _param_48481 = _s_48479;

    /** symtab.e:1136		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24983 = (object)*(((s1_ptr)_2)->base + _s_48479);
    _2 = (object)SEQ_PTR(_24983);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
        _24984 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
    }
    else{
        _24984 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
    }
    _24983 = NOVALUE;
    {
        object _i_48483;
        _i_48483 = 1;
L1: 
        if (binary_op_a(GREATER, _i_48483, _24984)){
            goto L2; // [24] 59
        }

        /** symtab.e:1137			param = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24985 = (object)*(((s1_ptr)_2)->base + _s_48479);
        _2 = (object)SEQ_PTR(_24985);
        _param_48481 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_48481)){
            _param_48481 = (object)DBL_PTR(_param_48481)->dbl;
        }
        _24985 = NOVALUE;

        /** symtab.e:1138			Show( param )*/
        _54Show(_param_48481);

        /** symtab.e:1139		end for*/
        _0 = _i_48483;
        if (IS_ATOM_INT(_i_48483)) {
            _i_48483 = _i_48483 + 1;
            if ((object)((uintptr_t)_i_48483 +(uintptr_t) HIGH_BITS) >= 0){
                _i_48483 = NewDouble((eudouble)_i_48483);
            }
        }
        else {
            _i_48483 = binary_op_a(PLUS, _i_48483, 1);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_48483);
    }

    /** symtab.e:1140	end procedure*/
    _24984 = NOVALUE;
    return;
    ;
}


void _54LintCheck(object _s_48495)
{
    object _warn_level_48496 = NOVALUE;
    object _file_48497 = NOVALUE;
    object _vscope_48498 = NOVALUE;
    object _vname_48499 = NOVALUE;
    object _vusage_48500 = NOVALUE;
    object _25046 = NOVALUE;
    object _25045 = NOVALUE;
    object _25044 = NOVALUE;
    object _25043 = NOVALUE;
    object _25042 = NOVALUE;
    object _25041 = NOVALUE;
    object _25039 = NOVALUE;
    object _25038 = NOVALUE;
    object _25037 = NOVALUE;
    object _25036 = NOVALUE;
    object _25035 = NOVALUE;
    object _25034 = NOVALUE;
    object _25031 = NOVALUE;
    object _25030 = NOVALUE;
    object _25029 = NOVALUE;
    object _25028 = NOVALUE;
    object _25027 = NOVALUE;
    object _25026 = NOVALUE;
    object _25024 = NOVALUE;
    object _25022 = NOVALUE;
    object _25021 = NOVALUE;
    object _25019 = NOVALUE;
    object _25018 = NOVALUE;
    object _25016 = NOVALUE;
    object _25015 = NOVALUE;
    object _25014 = NOVALUE;
    object _25013 = NOVALUE;
    object _25011 = NOVALUE;
    object _25010 = NOVALUE;
    object _25006 = NOVALUE;
    object _25003 = NOVALUE;
    object _25002 = NOVALUE;
    object _25001 = NOVALUE;
    object _25000 = NOVALUE;
    object _24997 = NOVALUE;
    object _24996 = NOVALUE;
    object _24991 = NOVALUE;
    object _24989 = NOVALUE;
    object _24987 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_48495)) {
        _1 = (object)(DBL_PTR(_s_48495)->dbl);
        DeRefDS(_s_48495);
        _s_48495 = _1;
    }

    /** symtab.e:1150		vusage = SymTab[s][S_USAGE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24987 = (object)*(((s1_ptr)_2)->base + _s_48495);
    _2 = (object)SEQ_PTR(_24987);
    _vusage_48500 = (object)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_vusage_48500)){
        _vusage_48500 = (object)DBL_PTR(_vusage_48500)->dbl;
    }
    _24987 = NOVALUE;

    /** symtab.e:1151		vscope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24989 = (object)*(((s1_ptr)_2)->base + _s_48495);
    _2 = (object)SEQ_PTR(_24989);
    _vscope_48498 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_vscope_48498)){
        _vscope_48498 = (object)DBL_PTR(_vscope_48498)->dbl;
    }
    _24989 = NOVALUE;

    /** symtab.e:1152		vname = SymTab[s][S_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24991 = (object)*(((s1_ptr)_2)->base + _s_48495);
    DeRef(_vname_48499);
    _2 = (object)SEQ_PTR(_24991);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _vname_48499 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _vname_48499 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    Ref(_vname_48499);
    _24991 = NOVALUE;

    /** symtab.e:1154		switch vusage do*/
    _0 = _vusage_48500;
    switch ( _0 ){ 

        /** symtab.e:1156			case U_UNUSED then*/
        case 0:

        /** symtab.e:1157				warn_level = 1*/
        _warn_level_48496 = 1;
        goto L1; // [67] 193

        /** symtab.e:1159			case U_WRITTEN then -- Set but never read*/
        case 2:

        /** symtab.e:1160				warn_level = 2*/
        _warn_level_48496 = 2;

        /** symtab.e:1162				if vscope > SC_LOCAL then*/
        if (_vscope_48498 <= 5)
        goto L2; // [82] 94

        /** symtab.e:1164					warn_level = 0 */
        _warn_level_48496 = 0;
        goto L1; // [91] 193
L2: 

        /** symtab.e:1166				elsif SymTab[s][S_MODE] = M_CONSTANT then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24996 = (object)*(((s1_ptr)_2)->base + _s_48495);
        _2 = (object)SEQ_PTR(_24996);
        _24997 = (object)*(((s1_ptr)_2)->base + 3);
        _24996 = NOVALUE;
        if (binary_op_a(NOTEQ, _24997, 2)){
            _24997 = NOVALUE;
            goto L1; // [110] 193
        }
        _24997 = NOVALUE;

        /** symtab.e:1167					if not Strict_is_on then*/
        if (_36Strict_is_on_21516 != 0)
        goto L1; // [118] 193

        /** symtab.e:1170						warn_level = 0 */
        _warn_level_48496 = 0;
        goto L1; // [129] 193

        /** symtab.e:1174			case U_READ then -- Read but never set*/
        case 1:

        /** symtab.e:1175				if SymTab[s][S_VARNUM] >= SymTab[CurrentSub][S_NUM_ARGS] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _25000 = (object)*(((s1_ptr)_2)->base + _s_48495);
        _2 = (object)SEQ_PTR(_25000);
        _25001 = (object)*(((s1_ptr)_2)->base + 16);
        _25000 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _25002 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21455);
        _2 = (object)SEQ_PTR(_25002);
        if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
            _25003 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
        }
        else{
            _25003 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
        }
        _25002 = NOVALUE;
        if (binary_op_a(LESS, _25001, _25003)){
            _25001 = NOVALUE;
            _25003 = NOVALUE;
            goto L3; // [163] 175
        }
        _25001 = NOVALUE;
        _25003 = NOVALUE;

        /** symtab.e:1176			    	warn_level = 3*/
        _warn_level_48496 = 3;
        goto L1; // [172] 193
L3: 

        /** symtab.e:1179			    	warn_level = 0*/
        _warn_level_48496 = 0;
        goto L1; // [181] 193

        /** symtab.e:1182		    case else*/
        default:

        /** symtab.e:1183		    	warn_level = 0*/
        _warn_level_48496 = 0;
    ;}L1: 

    /** symtab.e:1186		if warn_level = 0 then*/
    if (_warn_level_48496 != 0)
    goto L4; // [197] 207

    /** symtab.e:1187			return*/
    DeRef(_file_48497);
    DeRef(_vname_48499);
    return;
L4: 

    /** symtab.e:1191		file = abbreviate_path(known_files[current_file_no])*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _25006 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    Ref(_25006);
    RefDS(_21997);
    _0 = _file_48497;
    _file_48497 = _17abbreviate_path(_25006, _21997);
    DeRef(_0);
    _25006 = NOVALUE;

    /** symtab.e:1192		if warn_level = 3 then*/
    if (_warn_level_48496 != 3)
    goto L5; // [226] 308

    /** symtab.e:1193			if vscope = SC_LOCAL then*/
    if (_vscope_48498 != 5)
    goto L6; // [234] 275

    /** symtab.e:1194				if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25010 = (object)*(((s1_ptr)_2)->base + _s_48495);
    _2 = (object)SEQ_PTR(_25010);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _25011 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _25011 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _25010 = NOVALUE;
    if (binary_op_a(NOTEQ, _36current_file_no_21447, _25011)){
        _25011 = NOVALUE;
        goto L7; // [254] 602
    }
    _25011 = NOVALUE;

    /** symtab.e:1195					Warning(226, no_value_warning_flag, {file,  vname})*/
    RefDS(_vname_48499);
    RefDS(_file_48497);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48497;
    ((intptr_t *)_2)[2] = _vname_48499;
    _25013 = MAKE_SEQ(_1);
    _50Warning(226, 32, _25013);
    _25013 = NOVALUE;
    goto L7; // [272] 602
L6: 

    /** symtab.e:1198				Warning(227, no_value_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25014 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21455);
    _2 = (object)SEQ_PTR(_25014);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _25015 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _25015 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _25014 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48497);
    ((intptr_t*)_2)[1] = _file_48497;
    RefDS(_vname_48499);
    ((intptr_t*)_2)[2] = _vname_48499;
    Ref(_25015);
    ((intptr_t*)_2)[3] = _25015;
    _25016 = MAKE_SEQ(_1);
    _25015 = NOVALUE;
    _50Warning(227, 32, _25016);
    _25016 = NOVALUE;
    goto L7; // [305] 602
L5: 

    /** symtab.e:1201			if vscope = SC_LOCAL then*/
    if (_vscope_48498 != 5)
    goto L8; // [312] 412

    /** symtab.e:1202				if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25018 = (object)*(((s1_ptr)_2)->base + _s_48495);
    _2 = (object)SEQ_PTR(_25018);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _25019 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _25019 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _25018 = NOVALUE;
    if (binary_op_a(NOTEQ, _36current_file_no_21447, _25019)){
        _25019 = NOVALUE;
        goto L9; // [332] 601
    }
    _25019 = NOVALUE;

    /** symtab.e:1203					if SymTab[s][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25021 = (object)*(((s1_ptr)_2)->base + _s_48495);
    _2 = (object)SEQ_PTR(_25021);
    _25022 = (object)*(((s1_ptr)_2)->base + 3);
    _25021 = NOVALUE;
    if (binary_op_a(NOTEQ, _25022, 2)){
        _25022 = NOVALUE;
        goto LA; // [352] 372
    }
    _25022 = NOVALUE;

    /** symtab.e:1204						Warning(228, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48499);
    RefDS(_file_48497);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48497;
    ((intptr_t *)_2)[2] = _vname_48499;
    _25024 = MAKE_SEQ(_1);
    _50Warning(228, 16, _25024);
    _25024 = NOVALUE;
    goto L9; // [369] 601
LA: 

    /** symtab.e:1206					elsif warn_level = 1 then*/
    if (_warn_level_48496 != 1)
    goto LB; // [374] 394

    /** symtab.e:1207						Warning(229, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48499);
    RefDS(_file_48497);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48497;
    ((intptr_t *)_2)[2] = _vname_48499;
    _25026 = MAKE_SEQ(_1);
    _50Warning(229, 16, _25026);
    _25026 = NOVALUE;
    goto L9; // [391] 601
LB: 

    /** symtab.e:1210						Warning(320, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48499);
    RefDS(_file_48497);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48497;
    ((intptr_t *)_2)[2] = _vname_48499;
    _25027 = MAKE_SEQ(_1);
    _50Warning(320, 16, _25027);
    _25027 = NOVALUE;
    goto L9; // [409] 601
L8: 

    /** symtab.e:1214				if SymTab[s][S_VARNUM] < SymTab[CurrentSub][S_NUM_ARGS] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25028 = (object)*(((s1_ptr)_2)->base + _s_48495);
    _2 = (object)SEQ_PTR(_25028);
    _25029 = (object)*(((s1_ptr)_2)->base + 16);
    _25028 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25030 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21455);
    _2 = (object)SEQ_PTR(_25030);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
        _25031 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
    }
    else{
        _25031 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
    }
    _25030 = NOVALUE;
    if (binary_op_a(GREATEREQ, _25029, _25031)){
        _25029 = NOVALUE;
        _25031 = NOVALUE;
        goto LC; // [440] 523
    }
    _25029 = NOVALUE;
    _25031 = NOVALUE;

    /** symtab.e:1216					if warn_level = 1 then*/
    if (_warn_level_48496 != 1)
    goto LD; // [446] 490

    /** symtab.e:1217						if Strict_is_on then*/
    if (_36Strict_is_on_21516 == 0)
    {
        goto LE; // [454] 600
    }
    else{
    }

    /** symtab.e:1219							Warning(230, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25034 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21455);
    _2 = (object)SEQ_PTR(_25034);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _25035 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _25035 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _25034 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48497);
    ((intptr_t*)_2)[1] = _file_48497;
    RefDS(_vname_48499);
    ((intptr_t*)_2)[2] = _vname_48499;
    Ref(_25035);
    ((intptr_t*)_2)[3] = _25035;
    _25036 = MAKE_SEQ(_1);
    _25035 = NOVALUE;
    _50Warning(230, 16, _25036);
    _25036 = NOVALUE;
    goto LE; // [487] 600
LD: 

    /** symtab.e:1222						Warning(321, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25037 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21455);
    _2 = (object)SEQ_PTR(_25037);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _25038 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _25038 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _25037 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48497);
    ((intptr_t*)_2)[1] = _file_48497;
    RefDS(_vname_48499);
    ((intptr_t*)_2)[2] = _vname_48499;
    Ref(_25038);
    ((intptr_t*)_2)[3] = _25038;
    _25039 = MAKE_SEQ(_1);
    _25038 = NOVALUE;
    _50Warning(321, 16, _25039);
    _25039 = NOVALUE;
    goto LE; // [520] 600
LC: 

    /** symtab.e:1226					if warn_level = 1 then*/
    if (_warn_level_48496 != 1)
    goto LF; // [525] 569

    /** symtab.e:1227						if Strict_is_on then*/
    if (_36Strict_is_on_21516 == 0)
    {
        goto L10; // [533] 599
    }
    else{
    }

    /** symtab.e:1229							Warning(231, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25041 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21455);
    _2 = (object)SEQ_PTR(_25041);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _25042 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _25042 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _25041 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48497);
    ((intptr_t*)_2)[1] = _file_48497;
    RefDS(_vname_48499);
    ((intptr_t*)_2)[2] = _vname_48499;
    Ref(_25042);
    ((intptr_t*)_2)[3] = _25042;
    _25043 = MAKE_SEQ(_1);
    _25042 = NOVALUE;
    _50Warning(231, 16, _25043);
    _25043 = NOVALUE;
    goto L10; // [566] 599
LF: 

    /** symtab.e:1232						Warning(322, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25044 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21455);
    _2 = (object)SEQ_PTR(_25044);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _25045 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _25045 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _25044 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48497);
    ((intptr_t*)_2)[1] = _file_48497;
    RefDS(_vname_48499);
    ((intptr_t*)_2)[2] = _vname_48499;
    Ref(_25045);
    ((intptr_t*)_2)[3] = _25045;
    _25046 = MAKE_SEQ(_1);
    _25045 = NOVALUE;
    _50Warning(322, 16, _25046);
    _25046 = NOVALUE;
L10: 
LE: 
L9: 
L7: 

    /** symtab.e:1238	end procedure*/
    DeRef(_file_48497);
    DeRef(_vname_48499);
    return;
    ;
}


void _54HideLocals()
{
    object _s_48666 = NOVALUE;
    object _25059 = NOVALUE;
    object _25057 = NOVALUE;
    object _25056 = NOVALUE;
    object _25055 = NOVALUE;
    object _25054 = NOVALUE;
    object _25053 = NOVALUE;
    object _25052 = NOVALUE;
    object _25051 = NOVALUE;
    object _25050 = NOVALUE;
    object _25049 = NOVALUE;
    object _25048 = NOVALUE;
    object _25047 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1244		mark_rechecks()*/
    _54mark_rechecks(_36current_file_no_21447);

    /** symtab.e:1245		s = file_start_sym*/
    _s_48666 = _36file_start_sym_21453;

    /** symtab.e:1246		while s do*/
L1: 
    if (_s_48666 == 0)
    {
        goto L2; // [22] 148
    }
    else{
    }

    /** symtab.e:1247			if SymTab[s][S_SCOPE] = SC_LOCAL and*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25047 = (object)*(((s1_ptr)_2)->base + _s_48666);
    _2 = (object)SEQ_PTR(_25047);
    _25048 = (object)*(((s1_ptr)_2)->base + 4);
    _25047 = NOVALUE;
    if (IS_ATOM_INT(_25048)) {
        _25049 = (_25048 == 5);
    }
    else {
        _25049 = binary_op(EQUALS, _25048, 5);
    }
    _25048 = NOVALUE;
    if (IS_ATOM_INT(_25049)) {
        if (_25049 == 0) {
            goto L3; // [45] 127
        }
    }
    else {
        if (DBL_PTR(_25049)->dbl == 0.0) {
            goto L3; // [45] 127
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25051 = (object)*(((s1_ptr)_2)->base + _s_48666);
    _2 = (object)SEQ_PTR(_25051);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _25052 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _25052 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    _25051 = NOVALUE;
    if (IS_ATOM_INT(_25052)) {
        _25053 = (_25052 == _36current_file_no_21447);
    }
    else {
        _25053 = binary_op(EQUALS, _25052, _36current_file_no_21447);
    }
    _25052 = NOVALUE;
    if (_25053 == 0) {
        DeRef(_25053);
        _25053 = NOVALUE;
        goto L3; // [68] 127
    }
    else {
        if (!IS_ATOM_INT(_25053) && DBL_PTR(_25053)->dbl == 0.0){
            DeRef(_25053);
            _25053 = NOVALUE;
            goto L3; // [68] 127
        }
        DeRef(_25053);
        _25053 = NOVALUE;
    }
    DeRef(_25053);
    _25053 = NOVALUE;

    /** symtab.e:1249			   	if current_block = top_level_block and repl then*/
    _25054 = (_65current_block_25120 == _65top_level_block_25121);
    if (_25054 == 0) {
        goto L4; // [81] 94
    }
    goto L4; // [88] 94
    goto L5; // [91] 100
L4: 

    /** symtab.e:1251				Hide(s)*/
    _54Hide(_s_48666);
L5: 

    /** symtab.e:1253				if SymTab[s][S_TOKEN] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25056 = (object)*(((s1_ptr)_2)->base + _s_48666);
    _2 = (object)SEQ_PTR(_25056);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _25057 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _25057 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    _25056 = NOVALUE;
    if (binary_op_a(NOTEQ, _25057, -100)){
        _25057 = NOVALUE;
        goto L6; // [116] 126
    }
    _25057 = NOVALUE;

    /** symtab.e:1254					LintCheck(s)*/
    _54LintCheck(_s_48666);
L6: 
L3: 

    /** symtab.e:1257			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25059 = (object)*(((s1_ptr)_2)->base + _s_48666);
    _2 = (object)SEQ_PTR(_25059);
    _s_48666 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_48666)){
        _s_48666 = (object)DBL_PTR(_s_48666)->dbl;
    }
    _25059 = NOVALUE;

    /** symtab.e:1258		end while*/
    goto L1; // [145] 22
L2: 

    /** symtab.e:1259	end procedure*/
    DeRef(_25054);
    _25054 = NOVALUE;
    DeRef(_25049);
    _25049 = NOVALUE;
    return;
    ;
}


object _54sym_name(object _sym_48705)
{
    object _25062 = NOVALUE;
    object _25061 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48705)) {
        _1 = (object)(DBL_PTR(_sym_48705)->dbl);
        DeRefDS(_sym_48705);
        _sym_48705 = _1;
    }

    /** symtab.e:1262		return SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25061 = (object)*(((s1_ptr)_2)->base + _sym_48705);
    _2 = (object)SEQ_PTR(_25061);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _25062 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _25062 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _25061 = NOVALUE;
    Ref(_25062);
    return _25062;
    ;
}


object _54sym_token(object _sym_48713)
{
    object _25064 = NOVALUE;
    object _25063 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48713)) {
        _1 = (object)(DBL_PTR(_sym_48713)->dbl);
        DeRefDS(_sym_48713);
        _sym_48713 = _1;
    }

    /** symtab.e:1266		return SymTab[sym][S_TOKEN]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25063 = (object)*(((s1_ptr)_2)->base + _sym_48713);
    _2 = (object)SEQ_PTR(_25063);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _25064 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _25064 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    _25063 = NOVALUE;
    Ref(_25064);
    return _25064;
    ;
}


object _54sym_scope(object _sym_48721)
{
    object _25066 = NOVALUE;
    object _25065 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48721)) {
        _1 = (object)(DBL_PTR(_sym_48721)->dbl);
        DeRefDS(_sym_48721);
        _sym_48721 = _1;
    }

    /** symtab.e:1270		return SymTab[sym][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25065 = (object)*(((s1_ptr)_2)->base + _sym_48721);
    _2 = (object)SEQ_PTR(_25065);
    _25066 = (object)*(((s1_ptr)_2)->base + 4);
    _25065 = NOVALUE;
    Ref(_25066);
    return _25066;
    ;
}


object _54sym_mode(object _sym_48729)
{
    object _25068 = NOVALUE;
    object _25067 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48729)) {
        _1 = (object)(DBL_PTR(_sym_48729)->dbl);
        DeRefDS(_sym_48729);
        _sym_48729 = _1;
    }

    /** symtab.e:1274		return SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25067 = (object)*(((s1_ptr)_2)->base + _sym_48729);
    _2 = (object)SEQ_PTR(_25067);
    _25068 = (object)*(((s1_ptr)_2)->base + 3);
    _25067 = NOVALUE;
    Ref(_25068);
    return _25068;
    ;
}


object _54sym_obj(object _sym_48737)
{
    object _25070 = NOVALUE;
    object _25069 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48737)) {
        _1 = (object)(DBL_PTR(_sym_48737)->dbl);
        DeRefDS(_sym_48737);
        _sym_48737 = _1;
    }

    /** symtab.e:1278		return SymTab[sym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25069 = (object)*(((s1_ptr)_2)->base + _sym_48737);
    _2 = (object)SEQ_PTR(_25069);
    _25070 = (object)*(((s1_ptr)_2)->base + 1);
    _25069 = NOVALUE;
    Ref(_25070);
    return _25070;
    ;
}


object _54sym_next(object _sym_48745)
{
    object _25072 = NOVALUE;
    object _25071 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1282		return SymTab[sym][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25071 = (object)*(((s1_ptr)_2)->base + _sym_48745);
    _2 = (object)SEQ_PTR(_25071);
    _25072 = (object)*(((s1_ptr)_2)->base + 2);
    _25071 = NOVALUE;
    Ref(_25072);
    return _25072;
    ;
}


object _54sym_block(object _sym_48753)
{
    object _25074 = NOVALUE;
    object _25073 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1286		return SymTab[sym][S_BLOCK]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25073 = (object)*(((s1_ptr)_2)->base + _sym_48753);
    _2 = (object)SEQ_PTR(_25073);
    if (!IS_ATOM_INT(_36S_BLOCK_21104)){
        _25074 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_BLOCK_21104)->dbl));
    }
    else{
        _25074 = (object)*(((s1_ptr)_2)->base + _36S_BLOCK_21104);
    }
    _25073 = NOVALUE;
    Ref(_25074);
    return _25074;
    ;
}


object _54sym_next_in_block(object _sym_48761)
{
    object _25076 = NOVALUE;
    object _25075 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1290		return SymTab[sym][S_NEXT_IN_BLOCK]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25075 = (object)*(((s1_ptr)_2)->base + _sym_48761);
    _2 = (object)SEQ_PTR(_25075);
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21076)){
        _25076 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21076)->dbl));
    }
    else{
        _25076 = (object)*(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21076);
    }
    _25075 = NOVALUE;
    Ref(_25076);
    return _25076;
    ;
}


object _54sym_usage(object _sym_48769)
{
    object _25078 = NOVALUE;
    object _25077 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1294		return SymTab[sym][S_USAGE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25077 = (object)*(((s1_ptr)_2)->base + _sym_48769);
    _2 = (object)SEQ_PTR(_25077);
    _25078 = (object)*(((s1_ptr)_2)->base + 5);
    _25077 = NOVALUE;
    Ref(_25078);
    return _25078;
    ;
}



// 0xDBA422D0
