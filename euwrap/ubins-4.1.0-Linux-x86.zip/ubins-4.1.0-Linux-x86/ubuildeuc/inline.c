// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _67advance(object _pc_53478, object _code_53479)
{
    object _27106 = NOVALUE;
    object _27104 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:63		prev_pc = pc*/
    _67prev_pc_53461 = _pc_53478;

    /** inline.e:64		if pc > length( code ) then*/
    if (IS_SEQUENCE(_code_53479)){
            _27104 = SEQ_PTR(_code_53479)->length;
    }
    else {
        _27104 = 1;
    }
    if (_pc_53478 <= _27104)
    goto L1; // [15] 26

    /** inline.e:65			return pc*/
    DeRefDS(_code_53479);
    return _pc_53478;
L1: 

    /** inline.e:67		return shift:advance( pc, code )*/
    RefDS(_code_53479);
    _27106 = _66advance(_pc_53478, _code_53479);
    DeRefDS(_code_53479);
    return _27106;
    ;
}


void _67shift(object _start_53486, object _amount_53487, object _bound_53488)
{
    object _temp_LineTable_53489 = NOVALUE;
    object _temp_Code_53491 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_amount_53487)) {
        _1 = (object)(DBL_PTR(_amount_53487)->dbl);
        DeRefDS(_amount_53487);
        _amount_53487 = _1;
    }

    /** inline.e:72			temp_LineTable = LineTable,*/
    RefDS(_36LineTable_21540);
    DeRef(_temp_LineTable_53489);
    _temp_LineTable_53489 = _36LineTable_21540;

    /** inline.e:73			temp_Code = Code*/
    RefDS(_36Code_21539);
    DeRef(_temp_Code_53491);
    _temp_Code_53491 = _36Code_21539;

    /** inline.e:74		LineTable = {}*/
    RefDS(_21997);
    DeRefDS(_36LineTable_21540);
    _36LineTable_21540 = _21997;

    /** inline.e:75		Code = inline_code*/
    RefDS(_67inline_code_53453);
    DeRefDS(_36Code_21539);
    _36Code_21539 = _67inline_code_53453;

    /** inline.e:76		inline_code = {}*/
    RefDS(_21997);
    DeRefDS(_67inline_code_53453);
    _67inline_code_53453 = _21997;

    /** inline.e:78		shift:shift( start, amount, bound )*/
    _66shift(_start_53486, _amount_53487, _bound_53488);

    /** inline.e:80		LineTable = temp_LineTable*/
    RefDS(_temp_LineTable_53489);
    DeRefDS(_36LineTable_21540);
    _36LineTable_21540 = _temp_LineTable_53489;

    /** inline.e:81		inline_code = Code*/
    RefDS(_36Code_21539);
    DeRefDS(_67inline_code_53453);
    _67inline_code_53453 = _36Code_21539;

    /** inline.e:82		Code = temp_Code*/
    RefDS(_temp_Code_53491);
    DeRefDS(_36Code_21539);
    _36Code_21539 = _temp_Code_53491;

    /** inline.e:83	end procedure*/
    DeRefDS(_temp_LineTable_53489);
    DeRefDS(_temp_Code_53491);
    return;
    ;
}


void _67replace_code(object _code_53506, object _start_53507, object _finish_53508)
{
    object _27113 = NOVALUE;
    object _27112 = NOVALUE;
    object _27111 = NOVALUE;
    object _27110 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_finish_53508)) {
        _1 = (object)(DBL_PTR(_finish_53508)->dbl);
        DeRefDS(_finish_53508);
        _finish_53508 = _1;
    }

    /** inline.e:92		inline_code = replace( inline_code, code, start, finish )*/
    {
        intptr_t p1 = _67inline_code_53453;
        intptr_t p2 = _code_53506;
        intptr_t p3 = _start_53507;
        intptr_t p4 = _finish_53508;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_67inline_code_53453;
        Replace( &replace_params );
    }

    /** inline.e:93		shift( start , length( code ) - (finish - start + 1), finish )*/
    if (IS_SEQUENCE(_code_53506)){
            _27110 = SEQ_PTR(_code_53506)->length;
    }
    else {
        _27110 = 1;
    }
    _27111 = _finish_53508 - _start_53507;
    if ((object)((uintptr_t)_27111 +(uintptr_t) HIGH_BITS) >= 0){
        _27111 = NewDouble((eudouble)_27111);
    }
    if (IS_ATOM_INT(_27111)) {
        _27112 = _27111 + 1;
        if (_27112 > MAXINT){
            _27112 = NewDouble((eudouble)_27112);
        }
    }
    else
    _27112 = binary_op(PLUS, 1, _27111);
    DeRef(_27111);
    _27111 = NOVALUE;
    if (IS_ATOM_INT(_27112)) {
        _27113 = _27110 - _27112;
        if ((object)((uintptr_t)_27113 +(uintptr_t) HIGH_BITS) >= 0){
            _27113 = NewDouble((eudouble)_27113);
        }
    }
    else {
        _27113 = NewDouble((eudouble)_27110 - DBL_PTR(_27112)->dbl);
    }
    _27110 = NOVALUE;
    DeRef(_27112);
    _27112 = NOVALUE;
    _67shift(_start_53507, _27113, _finish_53508);
    _27113 = NOVALUE;

    /** inline.e:94	end procedure*/
    DeRefDS(_code_53506);
    return;
    ;
}


void _67defer()
{
    object _dx_53516 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:101		integer dx = find( inline_sub, deferred_inline_decisions )*/
    _dx_53516 = find_from(_67inline_sub_53467, _67deferred_inline_decisions_53469, 1);

    /** inline.e:102		if not dx then*/
    if (_dx_53516 != 0)
    goto L1; // [14] 36

    /** inline.e:103			deferred_inline_decisions &= inline_sub*/
    Append(&_67deferred_inline_decisions_53469, _67deferred_inline_decisions_53469, _67inline_sub_53467);

    /** inline.e:104			deferred_inline_calls = append( deferred_inline_calls, {} )*/
    RefDS(_21997);
    Append(&_67deferred_inline_calls_53470, _67deferred_inline_calls_53470, _21997);
L1: 

    /** inline.e:106	end procedure*/
    return;
    ;
}


object _67new_inline_temp(object _sym_53525)
{
    object _27119 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:110		inline_temps &= sym*/
    Append(&_67inline_temps_53455, _67inline_temps_53455, _sym_53525);

    /** inline.e:111		return length( inline_temps )*/
    if (IS_SEQUENCE(_67inline_temps_53455)){
            _27119 = SEQ_PTR(_67inline_temps_53455)->length;
    }
    else {
        _27119 = 1;
    }
    return _27119;
    ;
}


object _67get_inline_temp(object _sym_53531)
{
    object _temp_num_53532 = NOVALUE;
    object _27123 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:117		integer temp_num = find( sym, inline_params )*/
    _temp_num_53532 = find_from(_sym_53531, _67inline_params_53458, 1);

    /** inline.e:118		if temp_num then*/
    if (_temp_num_53532 == 0)
    {
        goto L1; // [14] 24
    }
    else{
    }

    /** inline.e:119			return temp_num*/
    return _temp_num_53532;
L1: 

    /** inline.e:122		temp_num = find( sym, proc_vars )*/
    _temp_num_53532 = find_from(_sym_53531, _67proc_vars_53454, 1);

    /** inline.e:123		if temp_num then*/
    if (_temp_num_53532 == 0)
    {
        goto L2; // [35] 45
    }
    else{
    }

    /** inline.e:124			return temp_num*/
    return _temp_num_53532;
L2: 

    /** inline.e:127		temp_num = find( sym, inline_temps )*/
    _temp_num_53532 = find_from(_sym_53531, _67inline_temps_53455, 1);

    /** inline.e:128		if temp_num then*/
    if (_temp_num_53532 == 0)
    {
        goto L3; // [56] 66
    }
    else{
    }

    /** inline.e:129			return temp_num*/
    return _temp_num_53532;
L3: 

    /** inline.e:132		return new_inline_temp( sym )*/
    _27123 = _67new_inline_temp(_sym_53531);
    return _27123;
    ;
}


object _67generic_symbol(object _sym_53543)
{
    object _inline_type_53544 = NOVALUE;
    object _px_53545 = NOVALUE;
    object _eentry_53552 = NOVALUE;
    object _27132 = NOVALUE;
    object _27131 = NOVALUE;
    object _27130 = NOVALUE;
    object _27129 = NOVALUE;
    object _27127 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:137		integer px = find( sym, inline_params )*/
    _px_53545 = find_from(_sym_53543, _67inline_params_53458, 1);

    /** inline.e:138		if px then*/
    if (_px_53545 == 0)
    {
        goto L1; // [14] 25
    }
    else{
    }

    /** inline.e:139			inline_type = INLINE_PARAM*/
    _inline_type_53544 = 1;
    goto L2; // [22] 100
L1: 

    /** inline.e:141			px = find( sym, proc_vars )*/
    _px_53545 = find_from(_sym_53543, _67proc_vars_53454, 1);

    /** inline.e:142			if px then*/
    if (_px_53545 == 0)
    {
        goto L3; // [36] 47
    }
    else{
    }

    /** inline.e:143				inline_type = INLINE_VAR*/
    _inline_type_53544 = 6;
    goto L4; // [44] 99
L3: 

    /** inline.e:145				sequence eentry = SymTab[sym]*/
    DeRef(_eentry_53552);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _eentry_53552 = (object)*(((s1_ptr)_2)->base + _sym_53543);
    Ref(_eentry_53552);

    /** inline.e:146				if is_literal( sym ) or eentry[S_SCOPE] > SC_PRIVATE then*/
    _27127 = _67is_literal(_sym_53543);
    if (IS_ATOM_INT(_27127)) {
        if (_27127 != 0) {
            goto L5; // [63] 84
        }
    }
    else {
        if (DBL_PTR(_27127)->dbl != 0.0) {
            goto L5; // [63] 84
        }
    }
    _2 = (object)SEQ_PTR(_eentry_53552);
    _27129 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_27129)) {
        _27130 = (_27129 > 3);
    }
    else {
        _27130 = binary_op(GREATER, _27129, 3);
    }
    _27129 = NOVALUE;
    if (_27130 == 0) {
        DeRef(_27130);
        _27130 = NOVALUE;
        goto L6; // [80] 91
    }
    else {
        if (!IS_ATOM_INT(_27130) && DBL_PTR(_27130)->dbl == 0.0){
            DeRef(_27130);
            _27130 = NOVALUE;
            goto L6; // [80] 91
        }
        DeRef(_27130);
        _27130 = NOVALUE;
    }
    DeRef(_27130);
    _27130 = NOVALUE;
L5: 

    /** inline.e:147					return sym*/
    DeRef(_eentry_53552);
    DeRef(_27127);
    _27127 = NOVALUE;
    return _sym_53543;
L6: 

    /** inline.e:149				inline_type = INLINE_TEMP*/
    _inline_type_53544 = 2;
    DeRef(_eentry_53552);
    _eentry_53552 = NOVALUE;
L4: 
L2: 

    /** inline.e:153		return { inline_type, get_inline_temp( sym ) }*/
    _27131 = _67get_inline_temp(_sym_53543);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _inline_type_53544;
    ((intptr_t *)_2)[2] = _27131;
    _27132 = MAKE_SEQ(_1);
    _27131 = NOVALUE;
    DeRef(_27127);
    _27127 = NOVALUE;
    return _27132;
    ;
}


object _67adjust_symbol(object _pc_53567)
{
    object _sym_53569 = NOVALUE;
    object _eentry_53575 = NOVALUE;
    object _27140 = NOVALUE;
    object _27138 = NOVALUE;
    object _27137 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_53567)) {
        _1 = (object)(DBL_PTR(_pc_53567)->dbl);
        DeRefDS(_pc_53567);
        _pc_53567 = _1;
    }

    /** inline.e:160		symtab_index sym = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    _sym_53569 = (object)*(((s1_ptr)_2)->base + _pc_53567);
    if (!IS_ATOM_INT(_sym_53569)){
        _sym_53569 = (object)DBL_PTR(_sym_53569)->dbl;
    }

    /** inline.e:161		if sym < 0 then*/
    if (_sym_53569 >= 0)
    goto L1; // [15] 28

    /** inline.e:162			return 0*/
    DeRef(_eentry_53575);
    return 0;
    goto L2; // [25] 41
L1: 

    /** inline.e:163		elsif not sym then*/
    if (_sym_53569 != 0)
    goto L3; // [30] 40

    /** inline.e:165			return 1*/
    DeRef(_eentry_53575);
    return 1;
L3: 
L2: 

    /** inline.e:168		sequence eentry = SymTab[sym]*/
    DeRef(_eentry_53575);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _eentry_53575 = (object)*(((s1_ptr)_2)->base + _sym_53569);
    Ref(_eentry_53575);

    /** inline.e:169		if is_literal( sym ) then*/
    _27137 = _67is_literal(_sym_53569);
    if (_27137 == 0) {
        DeRef(_27137);
        _27137 = NOVALUE;
        goto L4; // [57] 69
    }
    else {
        if (!IS_ATOM_INT(_27137) && DBL_PTR(_27137)->dbl == 0.0){
            DeRef(_27137);
            _27137 = NOVALUE;
            goto L4; // [57] 69
        }
        DeRef(_27137);
        _27137 = NOVALUE;
    }
    DeRef(_27137);
    _27137 = NOVALUE;

    /** inline.e:170			return 1*/
    DeRefDS(_eentry_53575);
    return 1;
    goto L5; // [66] 95
L4: 

    /** inline.e:172		elsif eentry[S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_eentry_53575);
    _27138 = (object)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _27138, 9)){
        _27138 = NOVALUE;
        goto L6; // [79] 94
    }
    _27138 = NOVALUE;

    /** inline.e:173			defer()*/
    _67defer();

    /** inline.e:174			return 0*/
    DeRefDS(_eentry_53575);
    return 0;
L6: 
L5: 

    /** inline.e:177		inline_code[pc] = generic_symbol( sym )*/
    _27140 = _67generic_symbol(_sym_53569);
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53453 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_53567);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27140;
    if( _1 != _27140 ){
        DeRef(_1);
    }
    _27140 = NOVALUE;

    /** inline.e:178		return 1*/
    DeRef(_eentry_53575);
    return 1;
    ;
}


object _67check_for_param(object _pc_53589)
{
    object _px_53590 = NOVALUE;
    object _27143 = NOVALUE;
    object _27141 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_53589)) {
        _1 = (object)(DBL_PTR(_pc_53589)->dbl);
        DeRefDS(_pc_53589);
        _pc_53589 = _1;
    }

    /** inline.e:182		integer px = find( inline_code[pc], inline_params )*/
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    _27141 = (object)*(((s1_ptr)_2)->base + _pc_53589);
    _px_53590 = find_from(_27141, _67inline_params_53458, 1);
    _27141 = NOVALUE;

    /** inline.e:183		if px then*/
    if (_px_53590 == 0)
    {
        goto L1; // [20] 51
    }
    else{
    }

    /** inline.e:184			if not find( px, assigned_params ) then*/
    _27143 = find_from(_px_53590, _67assigned_params_53459, 1);
    if (_27143 != 0)
    goto L2; // [32] 44
    _27143 = NOVALUE;

    /** inline.e:185				assigned_params &= px*/
    Append(&_67assigned_params_53459, _67assigned_params_53459, _px_53590);
L2: 

    /** inline.e:187			return 1*/
    return 1;
L1: 

    /** inline.e:189		return 0*/
    return 0;
    ;
}


void _67check_target(object _pc_53600, object _op_53601)
{
    object _targets_53602 = NOVALUE;
    object _27152 = NOVALUE;
    object _27151 = NOVALUE;
    object _27150 = NOVALUE;
    object _27149 = NOVALUE;
    object _27148 = NOVALUE;
    object _27146 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:194		sequence targets = op_info[op][OP_TARGET]*/
    _2 = (object)SEQ_PTR(_66op_info_24241);
    _27146 = (object)*(((s1_ptr)_2)->base + _op_53601);
    DeRef(_targets_53602);
    _2 = (object)SEQ_PTR(_27146);
    _targets_53602 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_targets_53602);
    _27146 = NOVALUE;

    /** inline.e:196		if length( targets ) then*/
    if (IS_SEQUENCE(_targets_53602)){
            _27148 = SEQ_PTR(_targets_53602)->length;
    }
    else {
        _27148 = 1;
    }
    if (_27148 == 0)
    {
        _27148 = NOVALUE;
        goto L1; // [26] 72
    }
    else{
        _27148 = NOVALUE;
    }

    /** inline.e:197		for i = 1 to length( targets ) do*/
    if (IS_SEQUENCE(_targets_53602)){
            _27149 = SEQ_PTR(_targets_53602)->length;
    }
    else {
        _27149 = 1;
    }
    {
        object _i_53610;
        _i_53610 = 1;
L2: 
        if (_i_53610 > _27149){
            goto L3; // [34] 71
        }

        /** inline.e:198				if check_for_param( pc + targets[i] ) then*/
        _2 = (object)SEQ_PTR(_targets_53602);
        _27150 = (object)*(((s1_ptr)_2)->base + _i_53610);
        if (IS_ATOM_INT(_27150)) {
            _27151 = _pc_53600 + _27150;
            if ((object)((uintptr_t)_27151 + (uintptr_t)HIGH_BITS) >= 0){
                _27151 = NewDouble((eudouble)_27151);
            }
        }
        else {
            _27151 = binary_op(PLUS, _pc_53600, _27150);
        }
        _27150 = NOVALUE;
        _27152 = _67check_for_param(_27151);
        _27151 = NOVALUE;
        if (_27152 == 0) {
            DeRef(_27152);
            _27152 = NOVALUE;
            goto L4; // [55] 64
        }
        else {
            if (!IS_ATOM_INT(_27152) && DBL_PTR(_27152)->dbl == 0.0){
                DeRef(_27152);
                _27152 = NOVALUE;
                goto L4; // [55] 64
            }
            DeRef(_27152);
            _27152 = NOVALUE;
        }
        DeRef(_27152);
        _27152 = NOVALUE;

        /** inline.e:199					return*/
        DeRefDS(_targets_53602);
        return;
L4: 

        /** inline.e:201			end for*/
        _i_53610 = _i_53610 + 1;
        goto L2; // [66] 41
L3: 
        ;
    }
L1: 

    /** inline.e:203	end procedure*/
    DeRef(_targets_53602);
    return;
    ;
}


object _67adjust_il(object _pc_53618, object _op_53619)
{
    object _addr_53627 = NOVALUE;
    object _sub_53633 = NOVALUE;
    object _27177 = NOVALUE;
    object _27176 = NOVALUE;
    object _27175 = NOVALUE;
    object _27174 = NOVALUE;
    object _27173 = NOVALUE;
    object _27172 = NOVALUE;
    object _27171 = NOVALUE;
    object _27169 = NOVALUE;
    object _27168 = NOVALUE;
    object _27167 = NOVALUE;
    object _27166 = NOVALUE;
    object _27165 = NOVALUE;
    object _27164 = NOVALUE;
    object _27163 = NOVALUE;
    object _27162 = NOVALUE;
    object _27160 = NOVALUE;
    object _27159 = NOVALUE;
    object _27157 = NOVALUE;
    object _27156 = NOVALUE;
    object _27155 = NOVALUE;
    object _27154 = NOVALUE;
    object _27153 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:208		for i = 1 to op_info[op][OP_SIZE] - 1 do*/
    _2 = (object)SEQ_PTR(_66op_info_24241);
    _27153 = (object)*(((s1_ptr)_2)->base + _op_53619);
    _2 = (object)SEQ_PTR(_27153);
    _27154 = (object)*(((s1_ptr)_2)->base + 2);
    _27153 = NOVALUE;
    if (IS_ATOM_INT(_27154)) {
        _27155 = _27154 - 1;
        if ((object)((uintptr_t)_27155 +(uintptr_t) HIGH_BITS) >= 0){
            _27155 = NewDouble((eudouble)_27155);
        }
    }
    else {
        _27155 = binary_op(MINUS, _27154, 1);
    }
    _27154 = NOVALUE;
    {
        object _i_53621;
        _i_53621 = 1;
L1: 
        if (binary_op_a(GREATER, _i_53621, _27155)){
            goto L2; // [23] 214
        }

        /** inline.e:210			integer addr = find( i, op_info[op][OP_ADDR] )*/
        _2 = (object)SEQ_PTR(_66op_info_24241);
        _27156 = (object)*(((s1_ptr)_2)->base + _op_53619);
        _2 = (object)SEQ_PTR(_27156);
        _27157 = (object)*(((s1_ptr)_2)->base + 3);
        _27156 = NOVALUE;
        _addr_53627 = find_from(_i_53621, _27157, 1);
        _27157 = NOVALUE;

        /** inline.e:211			integer sub  = find( i, op_info[op][OP_SUB] )*/
        _2 = (object)SEQ_PTR(_66op_info_24241);
        _27159 = (object)*(((s1_ptr)_2)->base + _op_53619);
        _2 = (object)SEQ_PTR(_27159);
        _27160 = (object)*(((s1_ptr)_2)->base + 5);
        _27159 = NOVALUE;
        _sub_53633 = find_from(_i_53621, _27160, 1);
        _27160 = NOVALUE;

        /** inline.e:212			if addr then*/
        if (_addr_53627 == 0)
        {
            goto L3; // [70] 121
        }
        else{
        }

        /** inline.e:213				if integer( inline_code[pc+i] ) then*/
        if (IS_ATOM_INT(_i_53621)) {
            _27162 = _pc_53618 + _i_53621;
        }
        else {
            _27162 = NewDouble((eudouble)_pc_53618 + DBL_PTR(_i_53621)->dbl);
        }
        _2 = (object)SEQ_PTR(_67inline_code_53453);
        if (!IS_ATOM_INT(_27162)){
            _27163 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27162)->dbl));
        }
        else{
            _27163 = (object)*(((s1_ptr)_2)->base + _27162);
        }
        if (IS_ATOM_INT(_27163))
        _27164 = 1;
        else if (IS_ATOM_DBL(_27163))
        _27164 = IS_ATOM_INT(DoubleToInt(_27163));
        else
        _27164 = 0;
        _27163 = NOVALUE;
        if (_27164 == 0)
        {
            _27164 = NOVALUE;
            goto L4; // [88] 205
        }
        else{
            _27164 = NOVALUE;
        }

        /** inline.e:214					inline_code[pc + i] = { INLINE_ADDR, inline_code[pc + i] }*/
        if (IS_ATOM_INT(_i_53621)) {
            _27165 = _pc_53618 + _i_53621;
            if ((object)((uintptr_t)_27165 + (uintptr_t)HIGH_BITS) >= 0){
                _27165 = NewDouble((eudouble)_27165);
            }
        }
        else {
            _27165 = NewDouble((eudouble)_pc_53618 + DBL_PTR(_i_53621)->dbl);
        }
        if (IS_ATOM_INT(_i_53621)) {
            _27166 = _pc_53618 + _i_53621;
        }
        else {
            _27166 = NewDouble((eudouble)_pc_53618 + DBL_PTR(_i_53621)->dbl);
        }
        _2 = (object)SEQ_PTR(_67inline_code_53453);
        if (!IS_ATOM_INT(_27166)){
            _27167 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27166)->dbl));
        }
        else{
            _27167 = (object)*(((s1_ptr)_2)->base + _27166);
        }
        Ref(_27167);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 4;
        ((intptr_t *)_2)[2] = _27167;
        _27168 = MAKE_SEQ(_1);
        _27167 = NOVALUE;
        _2 = (object)SEQ_PTR(_67inline_code_53453);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67inline_code_53453 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27165))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27165)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27165);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27168;
        if( _1 != _27168 ){
            DeRef(_1);
        }
        _27168 = NOVALUE;
        goto L4; // [118] 205
L3: 

        /** inline.e:217			elsif sub then*/
        if (_sub_53633 == 0)
        {
            goto L5; // [123] 141
        }
        else{
        }

        /** inline.e:218				inline_code[pc+i] = {INLINE_SUB}*/
        if (IS_ATOM_INT(_i_53621)) {
            _27169 = _pc_53618 + _i_53621;
        }
        else {
            _27169 = NewDouble((eudouble)_pc_53618 + DBL_PTR(_i_53621)->dbl);
        }
        RefDS(_27170);
        _2 = (object)SEQ_PTR(_67inline_code_53453);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67inline_code_53453 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27169))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27169)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27169);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27170;
        DeRef(_1);
        goto L4; // [138] 205
L5: 

        /** inline.e:220				if op != STARTLINE and op != COVERAGE_LINE and op != COVERAGE_ROUTINE then*/
        _27171 = (_op_53619 != 58);
        if (_27171 == 0) {
            _27172 = 0;
            goto L6; // [149] 163
        }
        _27173 = (_op_53619 != 210);
        _27172 = (_27173 != 0);
L6: 
        if (_27172 == 0) {
            goto L7; // [163] 204
        }
        _27175 = (_op_53619 != 211);
        if (_27175 == 0)
        {
            DeRef(_27175);
            _27175 = NOVALUE;
            goto L7; // [174] 204
        }
        else{
            DeRef(_27175);
            _27175 = NOVALUE;
        }

        /** inline.e:221					check_target( pc, op )*/
        _67check_target(_pc_53618, _op_53619);

        /** inline.e:222					if not adjust_symbol( pc + i ) then*/
        if (IS_ATOM_INT(_i_53621)) {
            _27176 = _pc_53618 + _i_53621;
            if ((object)((uintptr_t)_27176 + (uintptr_t)HIGH_BITS) >= 0){
                _27176 = NewDouble((eudouble)_27176);
            }
        }
        else {
            _27176 = NewDouble((eudouble)_pc_53618 + DBL_PTR(_i_53621)->dbl);
        }
        _27177 = _67adjust_symbol(_27176);
        _27176 = NOVALUE;
        if (IS_ATOM_INT(_27177)) {
            if (_27177 != 0){
                DeRef(_27177);
                _27177 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        else {
            if (DBL_PTR(_27177)->dbl != 0.0){
                DeRef(_27177);
                _27177 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        DeRef(_27177);
        _27177 = NOVALUE;

        /** inline.e:223						return 0*/
        DeRef(_i_53621);
        DeRef(_27169);
        _27169 = NOVALUE;
        DeRef(_27171);
        _27171 = NOVALUE;
        DeRef(_27155);
        _27155 = NOVALUE;
        DeRef(_27173);
        _27173 = NOVALUE;
        DeRef(_27165);
        _27165 = NOVALUE;
        DeRef(_27162);
        _27162 = NOVALUE;
        DeRef(_27166);
        _27166 = NOVALUE;
        return 0;
L8: 
L7: 
L4: 

        /** inline.e:227		end for*/
        _0 = _i_53621;
        if (IS_ATOM_INT(_i_53621)) {
            _i_53621 = _i_53621 + 1;
            if ((object)((uintptr_t)_i_53621 +(uintptr_t) HIGH_BITS) >= 0){
                _i_53621 = NewDouble((eudouble)_i_53621);
            }
        }
        else {
            _i_53621 = binary_op_a(PLUS, _i_53621, 1);
        }
        DeRef(_0);
        goto L1; // [209] 30
L2: 
        ;
        DeRef(_i_53621);
    }

    /** inline.e:228		return 1*/
    DeRef(_27169);
    _27169 = NOVALUE;
    DeRef(_27171);
    _27171 = NOVALUE;
    DeRef(_27155);
    _27155 = NOVALUE;
    DeRef(_27173);
    _27173 = NOVALUE;
    DeRef(_27165);
    _27165 = NOVALUE;
    DeRef(_27162);
    _27162 = NOVALUE;
    DeRef(_27166);
    _27166 = NOVALUE;
    return 1;
    ;
}


object _67is_temp(object _sym_53668)
{
    object _27188 = NOVALUE;
    object _27187 = NOVALUE;
    object _27186 = NOVALUE;
    object _27185 = NOVALUE;
    object _27184 = NOVALUE;
    object _27183 = NOVALUE;
    object _27182 = NOVALUE;
    object _27181 = NOVALUE;
    object _27180 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:232		if sym <= 0 then*/
    if (_sym_53668 > 0)
    goto L1; // [5] 16

    /** inline.e:233			return 0*/
    return 0;
L1: 

    /** inline.e:236		return (SymTab[sym][S_MODE] = M_TEMP) and (not TRANSLATE or equal( NOVALUE, SymTab[sym][S_OBJ]) )*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27180 = (object)*(((s1_ptr)_2)->base + _sym_53668);
    _2 = (object)SEQ_PTR(_27180);
    _27181 = (object)*(((s1_ptr)_2)->base + 3);
    _27180 = NOVALUE;
    if (IS_ATOM_INT(_27181)) {
        _27182 = (_27181 == 3);
    }
    else {
        _27182 = binary_op(EQUALS, _27181, 3);
    }
    _27181 = NOVALUE;
    _27183 = (_36TRANSLATE_21049 == 0);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27184 = (object)*(((s1_ptr)_2)->base + _sym_53668);
    _2 = (object)SEQ_PTR(_27184);
    _27185 = (object)*(((s1_ptr)_2)->base + 1);
    _27184 = NOVALUE;
    if (_36NOVALUE_21301 == _27185)
    _27186 = 1;
    else if (IS_ATOM_INT(_36NOVALUE_21301) && IS_ATOM_INT(_27185))
    _27186 = 0;
    else
    _27186 = (compare(_36NOVALUE_21301, _27185) == 0);
    _27185 = NOVALUE;
    _27187 = (_27183 != 0 || _27186 != 0);
    _27183 = NOVALUE;
    _27186 = NOVALUE;
    if (IS_ATOM_INT(_27182)) {
        _27188 = (_27182 != 0 && _27187 != 0);
    }
    else {
        _27188 = binary_op(AND, _27182, _27187);
    }
    DeRef(_27182);
    _27182 = NOVALUE;
    _27187 = NOVALUE;
    return _27188;
    ;
}


object _67is_literal(object _sym_53690)
{
    object _mode_53693 = NOVALUE;
    object _27203 = NOVALUE;
    object _27202 = NOVALUE;
    object _27201 = NOVALUE;
    object _27200 = NOVALUE;
    object _27199 = NOVALUE;
    object _27198 = NOVALUE;
    object _27196 = NOVALUE;
    object _27195 = NOVALUE;
    object _27194 = NOVALUE;
    object _27193 = NOVALUE;
    object _27192 = NOVALUE;
    object _27190 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:240		if sym <= 0 then*/
    if (_sym_53690 > 0)
    goto L1; // [5] 16

    /** inline.e:241			return 0*/
    return 0;
L1: 

    /** inline.e:244		integer mode = SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27190 = (object)*(((s1_ptr)_2)->base + _sym_53690);
    _2 = (object)SEQ_PTR(_27190);
    _mode_53693 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_53693)){
        _mode_53693 = (object)DBL_PTR(_mode_53693)->dbl;
    }
    _27190 = NOVALUE;

    /** inline.e:245		if (mode = M_CONSTANT and eu:compare( NOVALUE, SymTab[sym][S_OBJ]) ) */
    _27192 = (_mode_53693 == 2);
    if (_27192 == 0) {
        _27193 = 0;
        goto L2; // [40] 66
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27194 = (object)*(((s1_ptr)_2)->base + _sym_53690);
    _2 = (object)SEQ_PTR(_27194);
    _27195 = (object)*(((s1_ptr)_2)->base + 1);
    _27194 = NOVALUE;
    if (IS_ATOM_INT(_36NOVALUE_21301) && IS_ATOM_INT(_27195)){
        _27196 = (_36NOVALUE_21301 < _27195) ? -1 : (_36NOVALUE_21301 > _27195);
    }
    else{
        _27196 = compare(_36NOVALUE_21301, _27195);
    }
    _27195 = NOVALUE;
    _27193 = (_27196 != 0);
L2: 
    if (_27193 != 0) {
        goto L3; // [66] 117
    }
    if (_36TRANSLATE_21049 == 0) {
        _27198 = 0;
        goto L4; // [72] 86
    }
    _27199 = (_mode_53693 == 3);
    _27198 = (_27199 != 0);
L4: 
    if (_27198 == 0) {
        DeRef(_27200);
        _27200 = 0;
        goto L5; // [86] 112
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27201 = (object)*(((s1_ptr)_2)->base + _sym_53690);
    _2 = (object)SEQ_PTR(_27201);
    _27202 = (object)*(((s1_ptr)_2)->base + 1);
    _27201 = NOVALUE;
    if (IS_ATOM_INT(_27202) && IS_ATOM_INT(_36NOVALUE_21301)){
        _27203 = (_27202 < _36NOVALUE_21301) ? -1 : (_27202 > _36NOVALUE_21301);
    }
    else{
        _27203 = compare(_27202, _36NOVALUE_21301);
    }
    _27202 = NOVALUE;
    _27200 = (_27203 != 0);
L5: 
    if (_27200 == 0)
    {
        _27200 = NOVALUE;
        goto L6; // [113] 126
    }
    else{
        _27200 = NOVALUE;
    }
L3: 

    /** inline.e:247			return 1*/
    DeRef(_27192);
    _27192 = NOVALUE;
    DeRef(_27199);
    _27199 = NOVALUE;
    return 1;
    goto L7; // [123] 133
L6: 

    /** inline.e:249			return 0*/
    DeRef(_27192);
    _27192 = NOVALUE;
    DeRef(_27199);
    _27199 = NOVALUE;
    return 0;
L7: 
    ;
}


object _67returnf(object _pc_53740)
{
    object _retsym_53742 = NOVALUE;
    object _code_53775 = NOVALUE;
    object _ret_pc_53776 = NOVALUE;
    object _code_53821 = NOVALUE;
    object _ret_pc_53835 = NOVALUE;
    object _27276 = NOVALUE;
    object _27275 = NOVALUE;
    object _27273 = NOVALUE;
    object _27271 = NOVALUE;
    object _27270 = NOVALUE;
    object _27268 = NOVALUE;
    object _27267 = NOVALUE;
    object _27265 = NOVALUE;
    object _27264 = NOVALUE;
    object _27263 = NOVALUE;
    object _27261 = NOVALUE;
    object _27260 = NOVALUE;
    object _27258 = NOVALUE;
    object _27256 = NOVALUE;
    object _27255 = NOVALUE;
    object _27253 = NOVALUE;
    object _27252 = NOVALUE;
    object _27250 = NOVALUE;
    object _27249 = NOVALUE;
    object _27248 = NOVALUE;
    object _27246 = NOVALUE;
    object _27245 = NOVALUE;
    object _27244 = NOVALUE;
    object _27243 = NOVALUE;
    object _27242 = NOVALUE;
    object _27240 = NOVALUE;
    object _27239 = NOVALUE;
    object _27238 = NOVALUE;
    object _27237 = NOVALUE;
    object _27235 = NOVALUE;
    object _27233 = NOVALUE;
    object _27232 = NOVALUE;
    object _27231 = NOVALUE;
    object _27230 = NOVALUE;
    object _27229 = NOVALUE;
    object _27228 = NOVALUE;
    object _27227 = NOVALUE;
    object _27226 = NOVALUE;
    object _27225 = NOVALUE;
    object _27223 = NOVALUE;
    object _27222 = NOVALUE;
    object _27221 = NOVALUE;
    object _27219 = NOVALUE;
    object _27218 = NOVALUE;
    object _27217 = NOVALUE;
    object _27216 = NOVALUE;
    object _27215 = NOVALUE;
    object _27214 = NOVALUE;
    object _27212 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:259		symtab_index retsym = inline_code[pc+3]*/
    _27212 = _pc_53740 + 3;
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    _retsym_53742 = (object)*(((s1_ptr)_2)->base + _27212);
    if (!IS_ATOM_INT(_retsym_53742)){
        _retsym_53742 = (object)DBL_PTR(_retsym_53742)->dbl;
    }

    /** inline.e:260		if equal( inline_code[$], BADRETURNF ) then*/
    if (IS_SEQUENCE(_67inline_code_53453)){
            _27214 = SEQ_PTR(_67inline_code_53453)->length;
    }
    else {
        _27214 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    _27215 = (object)*(((s1_ptr)_2)->base + _27214);
    if (_27215 == 43)
    _27216 = 1;
    else if (IS_ATOM_INT(_27215) && IS_ATOM_INT(43))
    _27216 = 0;
    else
    _27216 = (compare(_27215, 43) == 0);
    _27215 = NOVALUE;
    if (_27216 == 0)
    {
        _27216 = NOVALUE;
        goto L1; // [34] 102
    }
    else{
        _27216 = NOVALUE;
    }

    /** inline.e:261			if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L2; // [41] 60
    }
    else{
    }

    /** inline.e:262				inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_67inline_code_53453)){
            _27217 = SEQ_PTR(_67inline_code_53453)->length;
    }
    else {
        _27217 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53453 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27217);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 159;
    DeRef(_1);
    goto L3; // [57] 101
L2: 

    /** inline.e:263			elsif SymTab[inline_sub][S_TOKEN] = PROC then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27218 = (object)*(((s1_ptr)_2)->base + _67inline_sub_53467);
    _2 = (object)SEQ_PTR(_27218);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _27219 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _27219 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    _27218 = NOVALUE;
    if (binary_op_a(NOTEQ, _27219, 27)){
        _27219 = NOVALUE;
        goto L4; // [78] 100
    }
    _27219 = NOVALUE;

    /** inline.e:264				replace_code( {}, length(inline_code), length(inline_code) )*/
    if (IS_SEQUENCE(_67inline_code_53453)){
            _27221 = SEQ_PTR(_67inline_code_53453)->length;
    }
    else {
        _27221 = 1;
    }
    if (IS_SEQUENCE(_67inline_code_53453)){
            _27222 = SEQ_PTR(_67inline_code_53453)->length;
    }
    else {
        _27222 = 1;
    }
    RefDS(_21997);
    _67replace_code(_21997, _27221, _27222);
    _27221 = NOVALUE;
    _27222 = NOVALUE;
L4: 
L3: 
L1: 

    /** inline.e:270		if is_temp( retsym ) */
    _27223 = _67is_temp(_retsym_53742);
    if (IS_ATOM_INT(_27223)) {
        if (_27223 != 0) {
            goto L5; // [108] 150
        }
    }
    else {
        if (DBL_PTR(_27223)->dbl != 0.0) {
            goto L5; // [108] 150
        }
    }
    _27225 = _67is_literal(_retsym_53742);
    if (IS_ATOM_INT(_27225)) {
        _27226 = (_27225 == 0);
    }
    else {
        _27226 = unary_op(NOT, _27225);
    }
    DeRef(_27225);
    _27225 = NOVALUE;
    if (IS_ATOM_INT(_27226)) {
        if (_27226 == 0) {
            DeRef(_27227);
            _27227 = 0;
            goto L6; // [119] 145
        }
    }
    else {
        if (DBL_PTR(_27226)->dbl == 0.0) {
            DeRef(_27227);
            _27227 = 0;
            goto L6; // [119] 145
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27228 = (object)*(((s1_ptr)_2)->base + _retsym_53742);
    _2 = (object)SEQ_PTR(_27228);
    _27229 = (object)*(((s1_ptr)_2)->base + 4);
    _27228 = NOVALUE;
    if (IS_ATOM_INT(_27229)) {
        _27230 = (_27229 <= 3);
    }
    else {
        _27230 = binary_op(LESSEQ, _27229, 3);
    }
    _27229 = NOVALUE;
    DeRef(_27227);
    if (IS_ATOM_INT(_27230))
    _27227 = (_27230 != 0);
    else
    _27227 = DBL_PTR(_27230)->dbl != 0.0;
L6: 
    if (_27227 == 0)
    {
        _27227 = NOVALUE;
        goto L7; // [146] 393
    }
    else{
        _27227 = NOVALUE;
    }
L5: 

    /** inline.e:272			sequence code = {}*/
    RefDS(_21997);
    DeRef(_code_53775);
    _code_53775 = _21997;

    /** inline.e:274			integer ret_pc = 0*/
    _ret_pc_53776 = 0;

    /** inline.e:276			if not (find( retsym, inline_params ) or find( retsym, proc_vars )) then*/
    _27231 = find_from(_retsym_53742, _67inline_params_53458, 1);
    if (_27231 != 0) {
        DeRef(_27232);
        _27232 = 1;
        goto L8; // [171] 186
    }
    _27233 = find_from(_retsym_53742, _67proc_vars_53454, 1);
    _27232 = (_27233 != 0);
L8: 
    if (_27232 != 0)
    goto L9; // [186] 206
    _27232 = NOVALUE;

    /** inline.e:277				ret_pc = rfind( generic_symbol( retsym ), inline_code, pc )*/
    _27235 = _67generic_symbol(_retsym_53742);
    RefDS(_67inline_code_53453);
    _ret_pc_53776 = _16rfind(_27235, _67inline_code_53453, _pc_53740);
    _27235 = NOVALUE;
    if (!IS_ATOM_INT(_ret_pc_53776)) {
        _1 = (object)(DBL_PTR(_ret_pc_53776)->dbl);
        DeRefDS(_ret_pc_53776);
        _ret_pc_53776 = _1;
    }
L9: 

    /** inline.e:281			if ret_pc and eu:compare( inline_code[ret_pc-1], PRIVATE_INIT_CHECK ) then*/
    if (_ret_pc_53776 == 0) {
        goto LA; // [208] 277
    }
    _27238 = _ret_pc_53776 - 1;
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    _27239 = (object)*(((s1_ptr)_2)->base + _27238);
    if (IS_ATOM_INT(_27239) && IS_ATOM_INT(30)){
        _27240 = (_27239 < 30) ? -1 : (_27239 > 30);
    }
    else{
        _27240 = compare(_27239, 30);
    }
    _27239 = NOVALUE;
    if (_27240 == 0)
    {
        _27240 = NOVALUE;
        goto LA; // [229] 277
    }
    else{
        _27240 = NOVALUE;
    }

    /** inline.e:282				inline_code[ret_pc] = {INLINE_TARGET}*/
    RefDS(_27241);
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53453 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ret_pc_53776);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27241;
    DeRef(_1);

    /** inline.e:284				if equal( inline_code[ret_pc-1], REF_TEMP ) then*/
    _27242 = _ret_pc_53776 - 1;
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    _27243 = (object)*(((s1_ptr)_2)->base + _27242);
    if (_27243 == 207)
    _27244 = 1;
    else if (IS_ATOM_INT(_27243) && IS_ATOM_INT(207))
    _27244 = 0;
    else
    _27244 = (compare(_27243, 207) == 0);
    _27243 = NOVALUE;
    if (_27244 == 0)
    {
        _27244 = NOVALUE;
        goto LB; // [258] 292
    }
    else{
        _27244 = NOVALUE;
    }

    /** inline.e:287					inline_code[ret_pc-2] = {INLINE_TARGET}*/
    _27245 = _ret_pc_53776 - 2;
    RefDS(_27241);
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53453 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27245);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27241;
    DeRef(_1);
    goto LB; // [274] 292
LA: 

    /** inline.e:290				code = {ASSIGN, generic_symbol( retsym ), {INLINE_TARGET}}*/
    _27246 = _67generic_symbol(_retsym_53742);
    _0 = _code_53775;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18;
    ((intptr_t*)_2)[2] = _27246;
    RefDS(_27241);
    ((intptr_t*)_2)[3] = _27241;
    _code_53775 = MAKE_SEQ(_1);
    DeRef(_0);
    _27246 = NOVALUE;
LB: 

    /** inline.e:293			if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_67inline_code_53453)){
            _27248 = SEQ_PTR(_67inline_code_53453)->length;
    }
    else {
        _27248 = 1;
    }
    _27249 = 3 + _36TRANSLATE_21049;
    _27250 = _27248 - _27249;
    _27248 = NOVALUE;
    _27249 = NOVALUE;
    if (_pc_53740 == _27250)
    goto LC; // [309] 330

    /** inline.e:294				code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = -1;
    _27252 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 23;
    ((intptr_t *)_2)[2] = _27252;
    _27253 = MAKE_SEQ(_1);
    _27252 = NOVALUE;
    Concat((object_ptr)&_code_53775, _code_53775, _27253);
    DeRefDS(_27253);
    _27253 = NOVALUE;
LC: 

    /** inline.e:298			replace_code( code, pc, pc + 3 )*/
    _27255 = _pc_53740 + 3;
    if ((object)((uintptr_t)_27255 + (uintptr_t)HIGH_BITS) >= 0){
        _27255 = NewDouble((eudouble)_27255);
    }
    RefDS(_code_53775);
    _67replace_code(_code_53775, _pc_53740, _27255);
    _27255 = NOVALUE;

    /** inline.e:299			ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = -1;
    _27256 = MAKE_SEQ(_1);
    _ret_pc_53776 = find_from(_27256, _67inline_code_53453, _pc_53740);
    DeRefDS(_27256);
    _27256 = NOVALUE;

    /** inline.e:300			if ret_pc then*/
    if (_ret_pc_53776 == 0)
    {
        goto LD; // [356] 382
    }
    else{
    }

    /** inline.e:301				inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53453 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ret_pc_53776 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_67inline_code_53453)){
            _27260 = SEQ_PTR(_67inline_code_53453)->length;
    }
    else {
        _27260 = 1;
    }
    _27261 = _27260 + 1;
    _27260 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27261;
    if( _1 != _27261 ){
        DeRef(_1);
    }
    _27261 = NOVALUE;
    _27258 = NOVALUE;
LD: 

    /** inline.e:303			return 1*/
    DeRef(_code_53775);
    DeRef(_27230);
    _27230 = NOVALUE;
    DeRef(_27212);
    _27212 = NOVALUE;
    DeRef(_27242);
    _27242 = NOVALUE;
    DeRef(_27245);
    _27245 = NOVALUE;
    DeRef(_27226);
    _27226 = NOVALUE;
    DeRef(_27250);
    _27250 = NOVALUE;
    DeRef(_27238);
    _27238 = NOVALUE;
    DeRef(_27223);
    _27223 = NOVALUE;
    return 1;
    goto LE; // [390] 502
L7: 

    /** inline.e:306			sequence code = {ASSIGN, retsym, {INLINE_TARGET}}*/
    _0 = _code_53821;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18;
    ((intptr_t*)_2)[2] = _retsym_53742;
    RefDS(_27241);
    ((intptr_t*)_2)[3] = _27241;
    _code_53821 = MAKE_SEQ(_1);
    DeRef(_0);

    /** inline.e:307			if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_67inline_code_53453)){
            _27263 = SEQ_PTR(_67inline_code_53453)->length;
    }
    else {
        _27263 = 1;
    }
    _27264 = 3 + _36TRANSLATE_21049;
    _27265 = _27263 - _27264;
    _27263 = NOVALUE;
    _27264 = NOVALUE;
    if (_pc_53740 == _27265)
    goto LF; // [420] 441

    /** inline.e:308				code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = -1;
    _27267 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 23;
    ((intptr_t *)_2)[2] = _27267;
    _27268 = MAKE_SEQ(_1);
    _27267 = NOVALUE;
    Concat((object_ptr)&_code_53821, _code_53821, _27268);
    DeRefDS(_27268);
    _27268 = NOVALUE;
LF: 

    /** inline.e:312			replace_code( code, pc, pc + 3 )*/
    _27270 = _pc_53740 + 3;
    if ((object)((uintptr_t)_27270 + (uintptr_t)HIGH_BITS) >= 0){
        _27270 = NewDouble((eudouble)_27270);
    }
    RefDS(_code_53821);
    _67replace_code(_code_53821, _pc_53740, _27270);
    _27270 = NOVALUE;

    /** inline.e:313			integer ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = -1;
    _27271 = MAKE_SEQ(_1);
    _ret_pc_53835 = find_from(_27271, _67inline_code_53453, _pc_53740);
    DeRefDS(_27271);
    _27271 = NOVALUE;

    /** inline.e:314			if ret_pc then*/
    if (_ret_pc_53835 == 0)
    {
        goto L10; // [467] 493
    }
    else{
    }

    /** inline.e:315				inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53453 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ret_pc_53835 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_67inline_code_53453)){
            _27275 = SEQ_PTR(_67inline_code_53453)->length;
    }
    else {
        _27275 = 1;
    }
    _27276 = _27275 + 1;
    _27275 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27276;
    if( _1 != _27276 ){
        DeRef(_1);
    }
    _27276 = NOVALUE;
    _27273 = NOVALUE;
L10: 

    /** inline.e:317			return 1*/
    DeRef(_code_53821);
    DeRef(_27230);
    _27230 = NOVALUE;
    DeRef(_27265);
    _27265 = NOVALUE;
    DeRef(_27212);
    _27212 = NOVALUE;
    DeRef(_27242);
    _27242 = NOVALUE;
    DeRef(_27245);
    _27245 = NOVALUE;
    DeRef(_27226);
    _27226 = NOVALUE;
    DeRef(_27250);
    _27250 = NOVALUE;
    DeRef(_27238);
    _27238 = NOVALUE;
    DeRef(_27223);
    _27223 = NOVALUE;
    return 1;
LE: 

    /** inline.e:319		return 0*/
    DeRef(_27230);
    _27230 = NOVALUE;
    DeRef(_27265);
    _27265 = NOVALUE;
    DeRef(_27212);
    _27212 = NOVALUE;
    DeRef(_27242);
    _27242 = NOVALUE;
    DeRef(_27245);
    _27245 = NOVALUE;
    DeRef(_27226);
    _27226 = NOVALUE;
    DeRef(_27250);
    _27250 = NOVALUE;
    DeRef(_27238);
    _27238 = NOVALUE;
    DeRef(_27223);
    _27223 = NOVALUE;
    return 0;
    ;
}


object _67inline_op(object _pc_53845)
{
    object _op_53846 = NOVALUE;
    object _code_53851 = NOVALUE;
    object _stlen_53884 = NOVALUE;
    object _file_53889 = NOVALUE;
    object _ok_53894 = NOVALUE;
    object _original_table_53917 = NOVALUE;
    object _jump_table_53921 = NOVALUE;
    object _27337 = NOVALUE;
    object _27336 = NOVALUE;
    object _27335 = NOVALUE;
    object _27334 = NOVALUE;
    object _27333 = NOVALUE;
    object _27332 = NOVALUE;
    object _27331 = NOVALUE;
    object _27330 = NOVALUE;
    object _27329 = NOVALUE;
    object _27328 = NOVALUE;
    object _27327 = NOVALUE;
    object _27326 = NOVALUE;
    object _27323 = NOVALUE;
    object _27322 = NOVALUE;
    object _27321 = NOVALUE;
    object _27320 = NOVALUE;
    object _27318 = NOVALUE;
    object _27316 = NOVALUE;
    object _27315 = NOVALUE;
    object _27313 = NOVALUE;
    object _27309 = NOVALUE;
    object _27308 = NOVALUE;
    object _27307 = NOVALUE;
    object _27306 = NOVALUE;
    object _27305 = NOVALUE;
    object _27304 = NOVALUE;
    object _27301 = NOVALUE;
    object _27300 = NOVALUE;
    object _27298 = NOVALUE;
    object _27297 = NOVALUE;
    object _27295 = NOVALUE;
    object _27293 = NOVALUE;
    object _27292 = NOVALUE;
    object _27291 = NOVALUE;
    object _27290 = NOVALUE;
    object _27289 = NOVALUE;
    object _27288 = NOVALUE;
    object _27287 = NOVALUE;
    object _27285 = NOVALUE;
    object _27284 = NOVALUE;
    object _27283 = NOVALUE;
    object _27281 = NOVALUE;
    object _27280 = NOVALUE;
    object _27279 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:324		integer op = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    _op_53846 = (object)*(((s1_ptr)_2)->base + _pc_53845);
    if (!IS_ATOM_INT(_op_53846))
    _op_53846 = (object)DBL_PTR(_op_53846)->dbl;

    /** inline.e:326		if op = RETURNP then*/
    if (_op_53846 != 29)
    goto L1; // [15] 150

    /** inline.e:333			sequence code = ""*/
    RefDS(_21997);
    DeRef(_code_53851);
    _code_53851 = _21997;

    /** inline.e:335			if pc != length( inline_code ) - 1 - TRANSLATE then*/
    if (IS_SEQUENCE(_67inline_code_53453)){
            _27279 = SEQ_PTR(_67inline_code_53453)->length;
    }
    else {
        _27279 = 1;
    }
    _27280 = _27279 - 1;
    _27279 = NOVALUE;
    _27281 = _27280 - _36TRANSLATE_21049;
    _27280 = NOVALUE;
    if (_pc_53845 == _27281)
    goto L2; // [43] 92

    /** inline.e:336				code = { ELSE, {INLINE_ADDR, length( inline_code ) + 1 }}*/
    if (IS_SEQUENCE(_67inline_code_53453)){
            _27283 = SEQ_PTR(_67inline_code_53453)->length;
    }
    else {
        _27283 = 1;
    }
    _27284 = _27283 + 1;
    _27283 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = _27284;
    _27285 = MAKE_SEQ(_1);
    _27284 = NOVALUE;
    DeRefDS(_code_53851);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 23;
    ((intptr_t *)_2)[2] = _27285;
    _code_53851 = MAKE_SEQ(_1);
    _27285 = NOVALUE;

    /** inline.e:337				if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L3; // [72] 134
    }
    else{
    }

    /** inline.e:338					inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_67inline_code_53453)){
            _27287 = SEQ_PTR(_67inline_code_53453)->length;
    }
    else {
        _27287 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53453 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27287);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 159;
    DeRef(_1);
    goto L3; // [89] 134
L2: 

    /** inline.e:341			elsif TRANSLATE and inline_code[$] = BADRETURNF then*/
    if (_36TRANSLATE_21049 == 0) {
        goto L4; // [96] 133
    }
    if (IS_SEQUENCE(_67inline_code_53453)){
            _27289 = SEQ_PTR(_67inline_code_53453)->length;
    }
    else {
        _27289 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    _27290 = (object)*(((s1_ptr)_2)->base + _27289);
    if (IS_ATOM_INT(_27290)) {
        _27291 = (_27290 == 43);
    }
    else {
        _27291 = binary_op(EQUALS, _27290, 43);
    }
    _27290 = NOVALUE;
    if (_27291 == 0) {
        DeRef(_27291);
        _27291 = NOVALUE;
        goto L4; // [116] 133
    }
    else {
        if (!IS_ATOM_INT(_27291) && DBL_PTR(_27291)->dbl == 0.0){
            DeRef(_27291);
            _27291 = NOVALUE;
            goto L4; // [116] 133
        }
        DeRef(_27291);
        _27291 = NOVALUE;
    }
    DeRef(_27291);
    _27291 = NOVALUE;

    /** inline.e:342				inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_67inline_code_53453)){
            _27292 = SEQ_PTR(_67inline_code_53453)->length;
    }
    else {
        _27292 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53453 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27292);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 159;
    DeRef(_1);
L4: 
L3: 

    /** inline.e:344			replace_code( code, pc, pc + 2 )*/
    _27293 = _pc_53845 + 2;
    if ((object)((uintptr_t)_27293 + (uintptr_t)HIGH_BITS) >= 0){
        _27293 = NewDouble((eudouble)_27293);
    }
    RefDS(_code_53851);
    _67replace_code(_code_53851, _pc_53845, _27293);
    _27293 = NOVALUE;
    DeRefDS(_code_53851);
    _code_53851 = NOVALUE;
    goto L5; // [147] 526
L1: 

    /** inline.e:346		elsif op = RETURNF then*/
    if (_op_53846 != 28)
    goto L6; // [154] 171

    /** inline.e:347			return returnf( pc )*/
    _27295 = _67returnf(_pc_53845);
    DeRef(_27281);
    _27281 = NOVALUE;
    return _27295;
    goto L5; // [168] 526
L6: 

    /** inline.e:349		elsif op = ROUTINE_ID then*/
    if (_op_53846 != 134)
    goto L7; // [175] 273

    /** inline.e:351			integer*/

    /** inline.e:352				stlen = inline_code[pc+2+TRANSLATE],*/
    _27297 = _pc_53845 + 2;
    if ((object)((uintptr_t)_27297 + (uintptr_t)HIGH_BITS) >= 0){
        _27297 = NewDouble((eudouble)_27297);
    }
    if (IS_ATOM_INT(_27297)) {
        _27298 = _27297 + _36TRANSLATE_21049;
    }
    else {
        _27298 = NewDouble(DBL_PTR(_27297)->dbl + (eudouble)_36TRANSLATE_21049);
    }
    DeRef(_27297);
    _27297 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    if (!IS_ATOM_INT(_27298)){
        _stlen_53884 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27298)->dbl));
    }
    else{
        _stlen_53884 = (object)*(((s1_ptr)_2)->base + _27298);
    }
    if (!IS_ATOM_INT(_stlen_53884))
    _stlen_53884 = (object)DBL_PTR(_stlen_53884)->dbl;

    /** inline.e:353				file  = inline_code[pc+4+TRANSLATE],*/
    _27300 = _pc_53845 + 4;
    if ((object)((uintptr_t)_27300 + (uintptr_t)HIGH_BITS) >= 0){
        _27300 = NewDouble((eudouble)_27300);
    }
    if (IS_ATOM_INT(_27300)) {
        _27301 = _27300 + _36TRANSLATE_21049;
    }
    else {
        _27301 = NewDouble(DBL_PTR(_27300)->dbl + (eudouble)_36TRANSLATE_21049);
    }
    DeRef(_27300);
    _27300 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    if (!IS_ATOM_INT(_27301)){
        _file_53889 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27301)->dbl));
    }
    else{
        _file_53889 = (object)*(((s1_ptr)_2)->base + _27301);
    }
    if (!IS_ATOM_INT(_file_53889))
    _file_53889 = (object)DBL_PTR(_file_53889)->dbl;

    /** inline.e:354				ok    = adjust_il( pc, op )*/
    _ok_53894 = _67adjust_il(_pc_53845, _op_53846);
    if (!IS_ATOM_INT(_ok_53894)) {
        _1 = (object)(DBL_PTR(_ok_53894)->dbl);
        DeRefDS(_ok_53894);
        _ok_53894 = _1;
    }

    /** inline.e:355			inline_code[pc+2+TRANSLATE] = stlen*/
    _27304 = _pc_53845 + 2;
    if ((object)((uintptr_t)_27304 + (uintptr_t)HIGH_BITS) >= 0){
        _27304 = NewDouble((eudouble)_27304);
    }
    if (IS_ATOM_INT(_27304)) {
        _27305 = _27304 + _36TRANSLATE_21049;
    }
    else {
        _27305 = NewDouble(DBL_PTR(_27304)->dbl + (eudouble)_36TRANSLATE_21049);
    }
    DeRef(_27304);
    _27304 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53453 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27305))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27305)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27305);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _stlen_53884;
    DeRef(_1);

    /** inline.e:356			inline_code[pc+4+TRANSLATE] = file*/
    _27306 = _pc_53845 + 4;
    if ((object)((uintptr_t)_27306 + (uintptr_t)HIGH_BITS) >= 0){
        _27306 = NewDouble((eudouble)_27306);
    }
    if (IS_ATOM_INT(_27306)) {
        _27307 = _27306 + _36TRANSLATE_21049;
    }
    else {
        _27307 = NewDouble(DBL_PTR(_27306)->dbl + (eudouble)_36TRANSLATE_21049);
    }
    DeRef(_27306);
    _27306 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53453 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27307))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27307)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27307);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _file_53889;
    DeRef(_1);

    /** inline.e:358			return ok*/
    DeRef(_27305);
    _27305 = NOVALUE;
    DeRef(_27307);
    _27307 = NOVALUE;
    DeRef(_27295);
    _27295 = NOVALUE;
    DeRef(_27298);
    _27298 = NOVALUE;
    DeRef(_27281);
    _27281 = NOVALUE;
    DeRef(_27301);
    _27301 = NOVALUE;
    return _ok_53894;
    goto L5; // [270] 526
L7: 

    /** inline.e:360		elsif op_info[op][OP_SIZE_TYPE] = FIXED_SIZE then*/
    _2 = (object)SEQ_PTR(_66op_info_24241);
    _27308 = (object)*(((s1_ptr)_2)->base + _op_53846);
    _2 = (object)SEQ_PTR(_27308);
    _27309 = (object)*(((s1_ptr)_2)->base + 1);
    _27308 = NOVALUE;
    if (binary_op_a(NOTEQ, _27309, 1)){
        _27309 = NOVALUE;
        goto L8; // [289] 397
    }
    _27309 = NOVALUE;

    /** inline.e:361			switch op do*/
    _0 = _op_53846;
    switch ( _0 ){ 

        /** inline.e:362				case SWITCH, SWITCH_RT, SWITCH_I, SWITCH_SPI then*/
        case 185:
        case 202:
        case 193:
        case 192:

        /** inline.e:364					symtab_index original_table = inline_code[pc + 3]*/
        _27313 = _pc_53845 + 3;
        _2 = (object)SEQ_PTR(_67inline_code_53453);
        _original_table_53917 = (object)*(((s1_ptr)_2)->base + _27313);
        if (!IS_ATOM_INT(_original_table_53917)){
            _original_table_53917 = (object)DBL_PTR(_original_table_53917)->dbl;
        }

        /** inline.e:365					symtab_index jump_table = NewStringSym( {-2, length(SymTab) } )*/
        if (IS_SEQUENCE(_37SymTab_15406)){
                _27315 = SEQ_PTR(_37SymTab_15406)->length;
        }
        else {
            _27315 = 1;
        }
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -2;
        ((intptr_t *)_2)[2] = _27315;
        _27316 = MAKE_SEQ(_1);
        _27315 = NOVALUE;
        _jump_table_53921 = _54NewStringSym(_27316);
        _27316 = NOVALUE;
        if (!IS_ATOM_INT(_jump_table_53921)) {
            _1 = (object)(DBL_PTR(_jump_table_53921)->dbl);
            DeRefDS(_jump_table_53921);
            _jump_table_53921 = _1;
        }

        /** inline.e:366					SymTab[jump_table][S_OBJ] = SymTab[original_table][S_OBJ]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_jump_table_53921 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27320 = (object)*(((s1_ptr)_2)->base + _original_table_53917);
        _2 = (object)SEQ_PTR(_27320);
        _27321 = (object)*(((s1_ptr)_2)->base + 1);
        _27320 = NOVALUE;
        Ref(_27321);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27321;
        if( _1 != _27321 ){
            DeRef(_1);
        }
        _27321 = NOVALUE;
        _27318 = NOVALUE;

        /** inline.e:367					inline_code[pc+3] = jump_table*/
        _27322 = _pc_53845 + 3;
        _2 = (object)SEQ_PTR(_67inline_code_53453);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67inline_code_53453 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _27322);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _jump_table_53921;
        DeRef(_1);
    ;}
    /** inline.e:369			return adjust_il( pc, op )*/
    _27323 = _67adjust_il(_pc_53845, _op_53846);
    DeRef(_27305);
    _27305 = NOVALUE;
    DeRef(_27322);
    _27322 = NOVALUE;
    DeRef(_27313);
    _27313 = NOVALUE;
    DeRef(_27307);
    _27307 = NOVALUE;
    DeRef(_27295);
    _27295 = NOVALUE;
    DeRef(_27298);
    _27298 = NOVALUE;
    DeRef(_27281);
    _27281 = NOVALUE;
    DeRef(_27301);
    _27301 = NOVALUE;
    return _27323;
    goto L5; // [394] 526
L8: 

    /** inline.e:372			switch op with fallthru do*/
    _0 = _op_53846;
    switch ( _0 ){ 

        /** inline.e:373				case REF_TEMP then*/
        case 207:

        /** inline.e:374					inline_code[pc+1] = {INLINE_TARGET}*/
        _27326 = _pc_53845 + 1;
        RefDS(_27241);
        _2 = (object)SEQ_PTR(_67inline_code_53453);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67inline_code_53453 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _27326);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27241;
        DeRef(_1);

        /** inline.e:376				case CONCAT_N then*/
        case 157:
        case 31:

        /** inline.e:379					if check_for_param( pc + 2 + inline_code[pc+1] ) then*/
        _27327 = _pc_53845 + 2;
        if ((object)((uintptr_t)_27327 + (uintptr_t)HIGH_BITS) >= 0){
            _27327 = NewDouble((eudouble)_27327);
        }
        _27328 = _pc_53845 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53453);
        _27329 = (object)*(((s1_ptr)_2)->base + _27328);
        if (IS_ATOM_INT(_27327) && IS_ATOM_INT(_27329)) {
            _27330 = _27327 + _27329;
            if ((object)((uintptr_t)_27330 + (uintptr_t)HIGH_BITS) >= 0){
                _27330 = NewDouble((eudouble)_27330);
            }
        }
        else {
            _27330 = binary_op(PLUS, _27327, _27329);
        }
        DeRef(_27327);
        _27327 = NOVALUE;
        _27329 = NOVALUE;
        _27331 = _67check_for_param(_27330);
        _27330 = NOVALUE;
        if (_27331 == 0) {
            DeRef(_27331);
            _27331 = NOVALUE;
            goto L9; // [450] 454
        }
        else {
            if (!IS_ATOM_INT(_27331) && DBL_PTR(_27331)->dbl == 0.0){
                DeRef(_27331);
                _27331 = NOVALUE;
                goto L9; // [450] 454
            }
            DeRef(_27331);
            _27331 = NOVALUE;
        }
        DeRef(_27331);
        _27331 = NOVALUE;
L9: 

        /** inline.e:383					for i = pc + 2 to pc + 2 + inline_code[pc+1] do*/
        _27332 = _pc_53845 + 2;
        if ((object)((uintptr_t)_27332 + (uintptr_t)HIGH_BITS) >= 0){
            _27332 = NewDouble((eudouble)_27332);
        }
        _27333 = _pc_53845 + 2;
        if ((object)((uintptr_t)_27333 + (uintptr_t)HIGH_BITS) >= 0){
            _27333 = NewDouble((eudouble)_27333);
        }
        _27334 = _pc_53845 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53453);
        _27335 = (object)*(((s1_ptr)_2)->base + _27334);
        if (IS_ATOM_INT(_27333) && IS_ATOM_INT(_27335)) {
            _27336 = _27333 + _27335;
            if ((object)((uintptr_t)_27336 + (uintptr_t)HIGH_BITS) >= 0){
                _27336 = NewDouble((eudouble)_27336);
            }
        }
        else {
            _27336 = binary_op(PLUS, _27333, _27335);
        }
        DeRef(_27333);
        _27333 = NOVALUE;
        _27335 = NOVALUE;
        {
            object _i_53953;
            Ref(_27332);
            _i_53953 = _27332;
LA: 
            if (binary_op_a(GREATER, _i_53953, _27336)){
                goto LB; // [478] 508
            }

            /** inline.e:384						if not adjust_symbol( i ) then*/
            Ref(_i_53953);
            _27337 = _67adjust_symbol(_i_53953);
            if (IS_ATOM_INT(_27337)) {
                if (_27337 != 0){
                    DeRef(_27337);
                    _27337 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            else {
                if (DBL_PTR(_27337)->dbl != 0.0){
                    DeRef(_27337);
                    _27337 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            DeRef(_27337);
            _27337 = NOVALUE;

            /** inline.e:385							return 0*/
            DeRef(_i_53953);
            DeRef(_27305);
            _27305 = NOVALUE;
            DeRef(_27334);
            _27334 = NOVALUE;
            DeRef(_27326);
            _27326 = NOVALUE;
            DeRef(_27322);
            _27322 = NOVALUE;
            DeRef(_27332);
            _27332 = NOVALUE;
            DeRef(_27313);
            _27313 = NOVALUE;
            DeRef(_27307);
            _27307 = NOVALUE;
            DeRef(_27336);
            _27336 = NOVALUE;
            DeRef(_27328);
            _27328 = NOVALUE;
            DeRef(_27295);
            _27295 = NOVALUE;
            DeRef(_27298);
            _27298 = NOVALUE;
            DeRef(_27281);
            _27281 = NOVALUE;
            DeRef(_27323);
            _27323 = NOVALUE;
            DeRef(_27301);
            _27301 = NOVALUE;
            return 0;
LC: 

            /** inline.e:388					end for*/
            _0 = _i_53953;
            if (IS_ATOM_INT(_i_53953)) {
                _i_53953 = _i_53953 + 1;
                if ((object)((uintptr_t)_i_53953 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_53953 = NewDouble((eudouble)_i_53953);
                }
            }
            else {
                _i_53953 = binary_op_a(PLUS, _i_53953, 1);
            }
            DeRef(_0);
            goto LA; // [503] 485
LB: 
            ;
            DeRef(_i_53953);
        }

        /** inline.e:389					return 1*/
        DeRef(_27305);
        _27305 = NOVALUE;
        DeRef(_27334);
        _27334 = NOVALUE;
        DeRef(_27326);
        _27326 = NOVALUE;
        DeRef(_27322);
        _27322 = NOVALUE;
        DeRef(_27332);
        _27332 = NOVALUE;
        DeRef(_27313);
        _27313 = NOVALUE;
        DeRef(_27307);
        _27307 = NOVALUE;
        DeRef(_27336);
        _27336 = NOVALUE;
        DeRef(_27328);
        _27328 = NOVALUE;
        DeRef(_27295);
        _27295 = NOVALUE;
        DeRef(_27298);
        _27298 = NOVALUE;
        DeRef(_27281);
        _27281 = NOVALUE;
        DeRef(_27323);
        _27323 = NOVALUE;
        DeRef(_27301);
        _27301 = NOVALUE;
        return 1;

        /** inline.e:390				case else*/
        default:

        /** inline.e:391					return 0*/
        DeRef(_27305);
        _27305 = NOVALUE;
        DeRef(_27334);
        _27334 = NOVALUE;
        DeRef(_27326);
        _27326 = NOVALUE;
        DeRef(_27322);
        _27322 = NOVALUE;
        DeRef(_27332);
        _27332 = NOVALUE;
        DeRef(_27313);
        _27313 = NOVALUE;
        DeRef(_27307);
        _27307 = NOVALUE;
        DeRef(_27336);
        _27336 = NOVALUE;
        DeRef(_27328);
        _27328 = NOVALUE;
        DeRef(_27295);
        _27295 = NOVALUE;
        DeRef(_27298);
        _27298 = NOVALUE;
        DeRef(_27281);
        _27281 = NOVALUE;
        DeRef(_27323);
        _27323 = NOVALUE;
        DeRef(_27301);
        _27301 = NOVALUE;
        return 0;
    ;}L5: 

    /** inline.e:394		return 1*/
    DeRef(_27305);
    _27305 = NOVALUE;
    DeRef(_27334);
    _27334 = NOVALUE;
    DeRef(_27326);
    _27326 = NOVALUE;
    DeRef(_27322);
    _27322 = NOVALUE;
    DeRef(_27332);
    _27332 = NOVALUE;
    DeRef(_27313);
    _27313 = NOVALUE;
    DeRef(_27307);
    _27307 = NOVALUE;
    DeRef(_27336);
    _27336 = NOVALUE;
    DeRef(_27328);
    _27328 = NOVALUE;
    DeRef(_27295);
    _27295 = NOVALUE;
    DeRef(_27298);
    _27298 = NOVALUE;
    DeRef(_27281);
    _27281 = NOVALUE;
    DeRef(_27323);
    _27323 = NOVALUE;
    DeRef(_27301);
    _27301 = NOVALUE;
    return 1;
    ;
}


void _67restore_code()
{
    object _27339 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:399		if length( temp_code ) then*/
    if (IS_SEQUENCE(_67temp_code_53963)){
            _27339 = SEQ_PTR(_67temp_code_53963)->length;
    }
    else {
        _27339 = 1;
    }
    if (_27339 == 0)
    {
        _27339 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _27339 = NOVALUE;
    }

    /** inline.e:400			Code = temp_code*/
    RefDS(_67temp_code_53963);
    DeRef(_36Code_21539);
    _36Code_21539 = _67temp_code_53963;
L1: 

    /** inline.e:402	end procedure*/
    return;
    ;
}


void _67check_inline(object _sub_53972)
{
    object _pc_54001 = NOVALUE;
    object _s_54003 = NOVALUE;
    object _backpatch_op_54041 = NOVALUE;
    object _op_54045 = NOVALUE;
    object _rtn_idx_54056 = NOVALUE;
    object _args_54061 = NOVALUE;
    object _args_54093 = NOVALUE;
    object _values_54122 = NOVALUE;
    object _27426 = NOVALUE;
    object _27425 = NOVALUE;
    object _27423 = NOVALUE;
    object _27420 = NOVALUE;
    object _27418 = NOVALUE;
    object _27417 = NOVALUE;
    object _27416 = NOVALUE;
    object _27414 = NOVALUE;
    object _27413 = NOVALUE;
    object _27412 = NOVALUE;
    object _27411 = NOVALUE;
    object _27410 = NOVALUE;
    object _27409 = NOVALUE;
    object _27408 = NOVALUE;
    object _27407 = NOVALUE;
    object _27406 = NOVALUE;
    object _27404 = NOVALUE;
    object _27403 = NOVALUE;
    object _27402 = NOVALUE;
    object _27401 = NOVALUE;
    object _27400 = NOVALUE;
    object _27398 = NOVALUE;
    object _27397 = NOVALUE;
    object _27396 = NOVALUE;
    object _27395 = NOVALUE;
    object _27394 = NOVALUE;
    object _27392 = NOVALUE;
    object _27391 = NOVALUE;
    object _27390 = NOVALUE;
    object _27389 = NOVALUE;
    object _27388 = NOVALUE;
    object _27387 = NOVALUE;
    object _27386 = NOVALUE;
    object _27385 = NOVALUE;
    object _27384 = NOVALUE;
    object _27383 = NOVALUE;
    object _27382 = NOVALUE;
    object _27381 = NOVALUE;
    object _27380 = NOVALUE;
    object _27379 = NOVALUE;
    object _27377 = NOVALUE;
    object _27374 = NOVALUE;
    object _27369 = NOVALUE;
    object _27367 = NOVALUE;
    object _27364 = NOVALUE;
    object _27363 = NOVALUE;
    object _27362 = NOVALUE;
    object _27361 = NOVALUE;
    object _27360 = NOVALUE;
    object _27359 = NOVALUE;
    object _27358 = NOVALUE;
    object _27357 = NOVALUE;
    object _27355 = NOVALUE;
    object _27353 = NOVALUE;
    object _27352 = NOVALUE;
    object _27350 = NOVALUE;
    object _27348 = NOVALUE;
    object _27346 = NOVALUE;
    object _27344 = NOVALUE;
    object _27343 = NOVALUE;
    object _27342 = NOVALUE;
    object _27341 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:411		if OpTrace or SymTab[sub][S_TOKEN] = TYPE then*/
    if (_36OpTrace_21520 != 0) {
        goto L1; // [7] 34
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27341 = (object)*(((s1_ptr)_2)->base + _sub_53972);
    _2 = (object)SEQ_PTR(_27341);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _27342 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _27342 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    _27341 = NOVALUE;
    if (IS_ATOM_INT(_27342)) {
        _27343 = (_27342 == 504);
    }
    else {
        _27343 = binary_op(EQUALS, _27342, 504);
    }
    _27342 = NOVALUE;
    if (_27343 == 0) {
        DeRef(_27343);
        _27343 = NOVALUE;
        goto L2; // [30] 40
    }
    else {
        if (!IS_ATOM_INT(_27343) && DBL_PTR(_27343)->dbl == 0.0){
            DeRef(_27343);
            _27343 = NOVALUE;
            goto L2; // [30] 40
        }
        DeRef(_27343);
        _27343 = NOVALUE;
    }
    DeRef(_27343);
    _27343 = NOVALUE;
L1: 

    /** inline.e:412			return*/
    DeRefi(_backpatch_op_54041);
    return;
L2: 

    /** inline.e:414		inline_sub      = sub*/
    _67inline_sub_53467 = _sub_53972;

    /** inline.e:415		if get_fwdref_count() then*/
    _27344 = _44get_fwdref_count();
    if (_27344 == 0) {
        DeRef(_27344);
        _27344 = NOVALUE;
        goto L3; // [52] 65
    }
    else {
        if (!IS_ATOM_INT(_27344) && DBL_PTR(_27344)->dbl == 0.0){
            DeRef(_27344);
            _27344 = NOVALUE;
            goto L3; // [52] 65
        }
        DeRef(_27344);
        _27344 = NOVALUE;
    }
    DeRef(_27344);
    _27344 = NOVALUE;

    /** inline.e:416			defer()*/
    _67defer();

    /** inline.e:417			return*/
    DeRefi(_backpatch_op_54041);
    return;
L3: 

    /** inline.e:419		temp_code = ""*/
    RefDS(_21997);
    DeRef(_67temp_code_53963);
    _67temp_code_53963 = _21997;

    /** inline.e:420		if sub != CurrentSub then*/
    if (_sub_53972 == _36CurrentSub_21455)
    goto L4; // [76] 99

    /** inline.e:421			Code = SymTab[sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27346 = (object)*(((s1_ptr)_2)->base + _sub_53972);
    DeRef(_36Code_21539);
    _2 = (object)SEQ_PTR(_27346);
    if (!IS_ATOM_INT(_36S_CODE_21096)){
        _36Code_21539 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21096)->dbl));
    }
    else{
        _36Code_21539 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21096);
    }
    Ref(_36Code_21539);
    _27346 = NOVALUE;
    goto L5; // [96] 109
L4: 

    /** inline.e:423			temp_code = Code*/
    RefDS(_36Code_21539);
    DeRef(_67temp_code_53963);
    _67temp_code_53963 = _36Code_21539;
L5: 

    /** inline.e:426		if length(Code) > OpInline then*/
    if (IS_SEQUENCE(_36Code_21539)){
            _27348 = SEQ_PTR(_36Code_21539)->length;
    }
    else {
        _27348 = 1;
    }
    if (_27348 <= _36OpInline_21525)
    goto L6; // [118] 128

    /** inline.e:427			return*/
    DeRefi(_backpatch_op_54041);
    return;
L6: 

    /** inline.e:430		inline_code     = Code*/
    RefDS(_36Code_21539);
    DeRef(_67inline_code_53453);
    _67inline_code_53453 = _36Code_21539;

    /** inline.e:431		return_gotos    = 0*/
    _67return_gotos_53462 = 0;

    /** inline.e:432		prev_pc         = 1*/
    _67prev_pc_53461 = 1;

    /** inline.e:433		proc_vars       = {}*/
    RefDS(_21997);
    DeRefi(_67proc_vars_53454);
    _67proc_vars_53454 = _21997;

    /** inline.e:434		inline_temps    = {}*/
    RefDS(_21997);
    DeRef(_67inline_temps_53455);
    _67inline_temps_53455 = _21997;

    /** inline.e:435		inline_params   = {}*/
    RefDS(_21997);
    DeRefi(_67inline_params_53458);
    _67inline_params_53458 = _21997;

    /** inline.e:436		assigned_params = {}*/
    RefDS(_21997);
    DeRef(_67assigned_params_53459);
    _67assigned_params_53459 = _21997;

    /** inline.e:438		integer pc = 1*/
    _pc_54001 = 1;

    /** inline.e:439		symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27350 = (object)*(((s1_ptr)_2)->base + _sub_53972);
    _2 = (object)SEQ_PTR(_27350);
    _s_54003 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_54003)){
        _s_54003 = (object)DBL_PTR(_s_54003)->dbl;
    }
    _27350 = NOVALUE;

    /** inline.e:440		for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27352 = (object)*(((s1_ptr)_2)->base + _sub_53972);
    _2 = (object)SEQ_PTR(_27352);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
        _27353 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
    }
    else{
        _27353 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
    }
    _27352 = NOVALUE;
    {
        object _p_54009;
        _p_54009 = 1;
L7: 
        if (binary_op_a(GREATER, _p_54009, _27353)){
            goto L8; // [210] 248
        }

        /** inline.e:441			inline_params &= s*/
        Append(&_67inline_params_53458, _67inline_params_53458, _s_54003);

        /** inline.e:442			s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27355 = (object)*(((s1_ptr)_2)->base + _s_54003);
        _2 = (object)SEQ_PTR(_27355);
        _s_54003 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_54003)){
            _s_54003 = (object)DBL_PTR(_s_54003)->dbl;
        }
        _27355 = NOVALUE;

        /** inline.e:443		end for*/
        _0 = _p_54009;
        if (IS_ATOM_INT(_p_54009)) {
            _p_54009 = _p_54009 + 1;
            if ((object)((uintptr_t)_p_54009 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54009 = NewDouble((eudouble)_p_54009);
            }
        }
        else {
            _p_54009 = binary_op_a(PLUS, _p_54009, 1);
        }
        DeRef(_0);
        goto L7; // [243] 217
L8: 
        ;
        DeRef(_p_54009);
    }

    /** inline.e:445		while s != 0 and */
L9: 
    _27357 = (_s_54003 != 0);
    if (_27357 == 0) {
        goto LA; // [257] 335
    }
    _27359 = _54sym_scope(_s_54003);
    if (IS_ATOM_INT(_27359)) {
        _27360 = (_27359 <= 3);
    }
    else {
        _27360 = binary_op(LESSEQ, _27359, 3);
    }
    DeRef(_27359);
    _27359 = NOVALUE;
    if (IS_ATOM_INT(_27360)) {
        if (_27360 != 0) {
            DeRef(_27361);
            _27361 = 1;
            goto LB; // [271] 289
        }
    }
    else {
        if (DBL_PTR(_27360)->dbl != 0.0) {
            DeRef(_27361);
            _27361 = 1;
            goto LB; // [271] 289
        }
    }
    _27362 = _54sym_scope(_s_54003);
    if (IS_ATOM_INT(_27362)) {
        _27363 = (_27362 == 9);
    }
    else {
        _27363 = binary_op(EQUALS, _27362, 9);
    }
    DeRef(_27362);
    _27362 = NOVALUE;
    DeRef(_27361);
    if (IS_ATOM_INT(_27363))
    _27361 = (_27363 != 0);
    else
    _27361 = DBL_PTR(_27363)->dbl != 0.0;
LB: 
    if (_27361 == 0)
    {
        _27361 = NOVALUE;
        goto LA; // [290] 335
    }
    else{
        _27361 = NOVALUE;
    }

    /** inline.e:447			if sym_scope( s ) != SC_UNDEFINED then*/
    _27364 = _54sym_scope(_s_54003);
    if (binary_op_a(EQUALS, _27364, 9)){
        DeRef(_27364);
        _27364 = NOVALUE;
        goto LC; // [301] 314
    }
    DeRef(_27364);
    _27364 = NOVALUE;

    /** inline.e:448				proc_vars &= s*/
    Append(&_67proc_vars_53454, _67proc_vars_53454, _s_54003);
LC: 

    /** inline.e:451			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27367 = (object)*(((s1_ptr)_2)->base + _s_54003);
    _2 = (object)SEQ_PTR(_27367);
    _s_54003 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_54003)){
        _s_54003 = (object)DBL_PTR(_s_54003)->dbl;
    }
    _27367 = NOVALUE;

    /** inline.e:452		end while*/
    goto L9; // [332] 253
LA: 

    /** inline.e:453		sequence backpatch_op = {}*/
    RefDS(_21997);
    DeRefi(_backpatch_op_54041);
    _backpatch_op_54041 = _21997;

    /** inline.e:454		while pc < length( inline_code ) do*/
LD: 
    if (IS_SEQUENCE(_67inline_code_53453)){
            _27369 = SEQ_PTR(_67inline_code_53453)->length;
    }
    else {
        _27369 = 1;
    }
    if (_pc_54001 >= _27369)
    goto LE; // [352] 869

    /** inline.e:456			integer op = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    _op_54045 = (object)*(((s1_ptr)_2)->base + _pc_54001);
    if (!IS_ATOM_INT(_op_54045))
    _op_54045 = (object)DBL_PTR(_op_54045)->dbl;

    /** inline.e:457			switch op do*/
    _0 = _op_54045;
    switch ( _0 ){ 

        /** inline.e:458				case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** inline.e:459					defer()*/
        _67defer();

        /** inline.e:460					restore_code()*/
        _67restore_code();

        /** inline.e:461					return*/
        DeRefi(_backpatch_op_54041);
        DeRef(_27357);
        _27357 = NOVALUE;
        DeRef(_27360);
        _27360 = NOVALUE;
        DeRef(_27363);
        _27363 = NOVALUE;
        _27353 = NOVALUE;
        return;
        goto LF; // [390] 851

        /** inline.e:463				case PROC, FUNC then*/
        case 27:
        case 501:

        /** inline.e:464					symtab_index rtn_idx = inline_code[pc+1]*/
        _27374 = _pc_54001 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53453);
        _rtn_idx_54056 = (object)*(((s1_ptr)_2)->base + _27374);
        if (!IS_ATOM_INT(_rtn_idx_54056)){
            _rtn_idx_54056 = (object)DBL_PTR(_rtn_idx_54056)->dbl;
        }

        /** inline.e:465					if rtn_idx = sub then*/
        if (_rtn_idx_54056 != _sub_53972)
        goto L10; // [414] 428

        /** inline.e:467						restore_code()*/
        _67restore_code();

        /** inline.e:468						return*/
        DeRefi(_backpatch_op_54041);
        DeRef(_27357);
        _27357 = NOVALUE;
        DeRef(_27360);
        _27360 = NOVALUE;
        DeRef(_27363);
        _27363 = NOVALUE;
        _27353 = NOVALUE;
        _27374 = NOVALUE;
        return;
L10: 

        /** inline.e:471					integer args = SymTab[rtn_idx][S_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27377 = (object)*(((s1_ptr)_2)->base + _rtn_idx_54056);
        _2 = (object)SEQ_PTR(_27377);
        if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
            _args_54061 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
        }
        else{
            _args_54061 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
        }
        if (!IS_ATOM_INT(_args_54061)){
            _args_54061 = (object)DBL_PTR(_args_54061)->dbl;
        }
        _27377 = NOVALUE;

        /** inline.e:472					if SymTab[rtn_idx][S_TOKEN] != PROC and check_for_param( pc + args + 2 ) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27379 = (object)*(((s1_ptr)_2)->base + _rtn_idx_54056);
        _2 = (object)SEQ_PTR(_27379);
        if (!IS_ATOM_INT(_36S_TOKEN_21089)){
            _27380 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
        }
        else{
            _27380 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
        }
        _27379 = NOVALUE;
        if (IS_ATOM_INT(_27380)) {
            _27381 = (_27380 != 27);
        }
        else {
            _27381 = binary_op(NOTEQ, _27380, 27);
        }
        _27380 = NOVALUE;
        if (IS_ATOM_INT(_27381)) {
            if (_27381 == 0) {
                goto L11; // [464] 485
            }
        }
        else {
            if (DBL_PTR(_27381)->dbl == 0.0) {
                goto L11; // [464] 485
            }
        }
        _27383 = _pc_54001 + _args_54061;
        if ((object)((uintptr_t)_27383 + (uintptr_t)HIGH_BITS) >= 0){
            _27383 = NewDouble((eudouble)_27383);
        }
        if (IS_ATOM_INT(_27383)) {
            _27384 = _27383 + 2;
            if ((object)((uintptr_t)_27384 + (uintptr_t)HIGH_BITS) >= 0){
                _27384 = NewDouble((eudouble)_27384);
            }
        }
        else {
            _27384 = NewDouble(DBL_PTR(_27383)->dbl + (eudouble)2);
        }
        DeRef(_27383);
        _27383 = NOVALUE;
        _27385 = _67check_for_param(_27384);
        _27384 = NOVALUE;
        if (_27385 == 0) {
            DeRef(_27385);
            _27385 = NOVALUE;
            goto L11; // [481] 485
        }
        else {
            if (!IS_ATOM_INT(_27385) && DBL_PTR(_27385)->dbl == 0.0){
                DeRef(_27385);
                _27385 = NOVALUE;
                goto L11; // [481] 485
            }
            DeRef(_27385);
            _27385 = NOVALUE;
        }
        DeRef(_27385);
        _27385 = NOVALUE;
L11: 

        /** inline.e:475					for i = 2 to args + 1 + (SymTab[rtn_idx][S_TOKEN] != PROC) do*/
        _27386 = _args_54061 + 1;
        if (_27386 > MAXINT){
            _27386 = NewDouble((eudouble)_27386);
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27387 = (object)*(((s1_ptr)_2)->base + _rtn_idx_54056);
        _2 = (object)SEQ_PTR(_27387);
        if (!IS_ATOM_INT(_36S_TOKEN_21089)){
            _27388 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
        }
        else{
            _27388 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
        }
        _27387 = NOVALUE;
        if (IS_ATOM_INT(_27388)) {
            _27389 = (_27388 != 27);
        }
        else {
            _27389 = binary_op(NOTEQ, _27388, 27);
        }
        _27388 = NOVALUE;
        if (IS_ATOM_INT(_27386) && IS_ATOM_INT(_27389)) {
            _27390 = _27386 + _27389;
            if ((object)((uintptr_t)_27390 + (uintptr_t)HIGH_BITS) >= 0){
                _27390 = NewDouble((eudouble)_27390);
            }
        }
        else {
            _27390 = binary_op(PLUS, _27386, _27389);
        }
        DeRef(_27386);
        _27386 = NOVALUE;
        DeRef(_27389);
        _27389 = NOVALUE;
        {
            object _i_54078;
            _i_54078 = 2;
L12: 
            if (binary_op_a(GREATER, _i_54078, _27390)){
                goto L13; // [513] 550
            }

            /** inline.e:476						if not adjust_symbol( pc + i ) then */
            if (IS_ATOM_INT(_i_54078)) {
                _27391 = _pc_54001 + _i_54078;
                if ((object)((uintptr_t)_27391 + (uintptr_t)HIGH_BITS) >= 0){
                    _27391 = NewDouble((eudouble)_27391);
                }
            }
            else {
                _27391 = NewDouble((eudouble)_pc_54001 + DBL_PTR(_i_54078)->dbl);
            }
            _27392 = _67adjust_symbol(_27391);
            _27391 = NOVALUE;
            if (IS_ATOM_INT(_27392)) {
                if (_27392 != 0){
                    DeRef(_27392);
                    _27392 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            else {
                if (DBL_PTR(_27392)->dbl != 0.0){
                    DeRef(_27392);
                    _27392 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            DeRef(_27392);
            _27392 = NOVALUE;

            /** inline.e:477							defer()*/
            _67defer();

            /** inline.e:478							return*/
            DeRef(_i_54078);
            DeRefi(_backpatch_op_54041);
            DeRef(_27381);
            _27381 = NOVALUE;
            DeRef(_27357);
            _27357 = NOVALUE;
            DeRef(_27360);
            _27360 = NOVALUE;
            DeRef(_27363);
            _27363 = NOVALUE;
            DeRef(_27390);
            _27390 = NOVALUE;
            _27353 = NOVALUE;
            DeRef(_27374);
            _27374 = NOVALUE;
            return;
L14: 

            /** inline.e:480					end for*/
            _0 = _i_54078;
            if (IS_ATOM_INT(_i_54078)) {
                _i_54078 = _i_54078 + 1;
                if ((object)((uintptr_t)_i_54078 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_54078 = NewDouble((eudouble)_i_54078);
                }
            }
            else {
                _i_54078 = binary_op_a(PLUS, _i_54078, 1);
            }
            DeRef(_0);
            goto L12; // [545] 520
L13: 
            ;
            DeRef(_i_54078);
        }
        goto LF; // [552] 851

        /** inline.e:482				case RIGHT_BRACE_N then*/
        case 31:

        /** inline.e:484					sequence args = inline_code[pc+2..inline_code[pc+1] + pc + 1]*/
        _27394 = _pc_54001 + 2;
        if ((object)((uintptr_t)_27394 + (uintptr_t)HIGH_BITS) >= 0){
            _27394 = NewDouble((eudouble)_27394);
        }
        _27395 = _pc_54001 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53453);
        _27396 = (object)*(((s1_ptr)_2)->base + _27395);
        if (IS_ATOM_INT(_27396)) {
            _27397 = _27396 + _pc_54001;
            if ((object)((uintptr_t)_27397 + (uintptr_t)HIGH_BITS) >= 0){
                _27397 = NewDouble((eudouble)_27397);
            }
        }
        else {
            _27397 = binary_op(PLUS, _27396, _pc_54001);
        }
        _27396 = NOVALUE;
        if (IS_ATOM_INT(_27397)) {
            _27398 = _27397 + 1;
        }
        else
        _27398 = binary_op(PLUS, 1, _27397);
        DeRef(_27397);
        _27397 = NOVALUE;
        rhs_slice_target = (object_ptr)&_args_54093;
        RHS_Slice(_67inline_code_53453, _27394, _27398);

        /** inline.e:486					for i = 1 to length(args) - 1 do*/
        if (IS_SEQUENCE(_args_54093)){
                _27400 = SEQ_PTR(_args_54093)->length;
        }
        else {
            _27400 = 1;
        }
        _27401 = _27400 - 1;
        _27400 = NOVALUE;
        {
            object _i_54101;
            _i_54101 = 1;
L15: 
            if (_i_54101 > _27401){
                goto L16; // [598] 644
            }

            /** inline.e:487						if find( args[i], args, i + 1 ) then*/
            _2 = (object)SEQ_PTR(_args_54093);
            _27402 = (object)*(((s1_ptr)_2)->base + _i_54101);
            _27403 = _i_54101 + 1;
            _27404 = find_from(_27402, _args_54093, _27403);
            _27402 = NOVALUE;
            _27403 = NOVALUE;
            if (_27404 == 0)
            {
                _27404 = NOVALUE;
                goto L17; // [620] 637
            }
            else{
                _27404 = NOVALUE;
            }

            /** inline.e:488							defer()*/
            _67defer();

            /** inline.e:489							restore_code()*/
            _67restore_code();

            /** inline.e:490							return*/
            DeRefDS(_args_54093);
            DeRefi(_backpatch_op_54041);
            DeRef(_27381);
            _27381 = NOVALUE;
            DeRef(_27357);
            _27357 = NOVALUE;
            DeRef(_27360);
            _27360 = NOVALUE;
            DeRef(_27394);
            _27394 = NOVALUE;
            DeRef(_27363);
            _27363 = NOVALUE;
            DeRef(_27395);
            _27395 = NOVALUE;
            DeRef(_27390);
            _27390 = NOVALUE;
            DeRef(_27401);
            _27401 = NOVALUE;
            DeRef(_27398);
            _27398 = NOVALUE;
            _27353 = NOVALUE;
            DeRef(_27374);
            _27374 = NOVALUE;
            return;
L17: 

            /** inline.e:492					end for*/
            _i_54101 = _i_54101 + 1;
            goto L15; // [639] 605
L16: 
            ;
        }

        /** inline.e:493					goto "inline op"*/
        DeRef(_args_54093);
        _args_54093 = NOVALUE;
        goto G18;
        goto LF; // [654] 851

        /** inline.e:495				case RIGHT_BRACE_2 then*/
        case 85:

        /** inline.e:496					if equal( inline_code[pc+1], inline_code[pc+2] ) then*/
        _27406 = _pc_54001 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53453);
        _27407 = (object)*(((s1_ptr)_2)->base + _27406);
        _27408 = _pc_54001 + 2;
        _2 = (object)SEQ_PTR(_67inline_code_53453);
        _27409 = (object)*(((s1_ptr)_2)->base + _27408);
        if (_27407 == _27409)
        _27410 = 1;
        else if (IS_ATOM_INT(_27407) && IS_ATOM_INT(_27409))
        _27410 = 0;
        else
        _27410 = (compare(_27407, _27409) == 0);
        _27407 = NOVALUE;
        _27409 = NOVALUE;
        if (_27410 == 0)
        {
            _27410 = NOVALUE;
            goto L19; // [686] 703
        }
        else{
            _27410 = NOVALUE;
        }

        /** inline.e:497						defer()*/
        _67defer();

        /** inline.e:498						restore_code()*/
        _67restore_code();

        /** inline.e:499						return*/
        DeRefi(_backpatch_op_54041);
        DeRef(_27381);
        _27381 = NOVALUE;
        DeRef(_27357);
        _27357 = NOVALUE;
        _27406 = NOVALUE;
        DeRef(_27360);
        _27360 = NOVALUE;
        DeRef(_27394);
        _27394 = NOVALUE;
        _27408 = NOVALUE;
        DeRef(_27363);
        _27363 = NOVALUE;
        DeRef(_27395);
        _27395 = NOVALUE;
        DeRef(_27390);
        _27390 = NOVALUE;
        DeRef(_27401);
        _27401 = NOVALUE;
        DeRef(_27398);
        _27398 = NOVALUE;
        _27353 = NOVALUE;
        DeRef(_27374);
        _27374 = NOVALUE;
        return;
L19: 

        /** inline.e:501					goto "inline op"*/
        goto G18;
        goto LF; // [711] 851

        /** inline.e:503				case EXIT_BLOCK then*/
        case 206:

        /** inline.e:504					replace_code( "", pc, pc + 1 )*/
        _27411 = _pc_54001 + 1;
        if (_27411 > MAXINT){
            _27411 = NewDouble((eudouble)_27411);
        }
        RefDS(_21997);
        _67replace_code(_21997, _pc_54001, _27411);
        _27411 = NOVALUE;

        /** inline.e:505					continue*/
        goto LD; // [732] 347
        goto LF; // [734] 851

        /** inline.e:507				case SWITCH_RT then*/
        case 202:

        /** inline.e:508					sequence values = SymTab[inline_code[pc+2]][S_OBJ]*/
        _27412 = _pc_54001 + 2;
        _2 = (object)SEQ_PTR(_67inline_code_53453);
        _27413 = (object)*(((s1_ptr)_2)->base + _27412);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_27413)){
            _27414 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27413)->dbl));
        }
        else{
            _27414 = (object)*(((s1_ptr)_2)->base + _27413);
        }
        DeRef(_values_54122);
        _2 = (object)SEQ_PTR(_27414);
        _values_54122 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_values_54122);
        _27414 = NOVALUE;

        /** inline.e:509					for i = 1 to length( values ) do*/
        if (IS_SEQUENCE(_values_54122)){
                _27416 = SEQ_PTR(_values_54122)->length;
        }
        else {
            _27416 = 1;
        }
        {
            object _i_54130;
            _i_54130 = 1;
L1A: 
            if (_i_54130 > _27416){
                goto L1B; // [771] 811
            }

            /** inline.e:510						if sequence( values[i] ) then*/
            _2 = (object)SEQ_PTR(_values_54122);
            _27417 = (object)*(((s1_ptr)_2)->base + _i_54130);
            _27418 = IS_SEQUENCE(_27417);
            _27417 = NOVALUE;
            if (_27418 == 0)
            {
                _27418 = NOVALUE;
                goto L1C; // [787] 804
            }
            else{
                _27418 = NOVALUE;
            }

            /** inline.e:512							defer()*/
            _67defer();

            /** inline.e:513							restore_code()*/
            _67restore_code();

            /** inline.e:514							return*/
            DeRefDS(_values_54122);
            DeRefi(_backpatch_op_54041);
            DeRef(_27381);
            _27381 = NOVALUE;
            DeRef(_27412);
            _27412 = NOVALUE;
            DeRef(_27357);
            _27357 = NOVALUE;
            DeRef(_27406);
            _27406 = NOVALUE;
            DeRef(_27360);
            _27360 = NOVALUE;
            DeRef(_27394);
            _27394 = NOVALUE;
            DeRef(_27408);
            _27408 = NOVALUE;
            DeRef(_27363);
            _27363 = NOVALUE;
            DeRef(_27395);
            _27395 = NOVALUE;
            DeRef(_27390);
            _27390 = NOVALUE;
            DeRef(_27401);
            _27401 = NOVALUE;
            DeRef(_27398);
            _27398 = NOVALUE;
            _27413 = NOVALUE;
            _27353 = NOVALUE;
            DeRef(_27374);
            _27374 = NOVALUE;
            return;
L1C: 

            /** inline.e:516					end for*/
            _i_54130 = _i_54130 + 1;
            goto L1A; // [806] 778
L1B: 
            ;
        }

        /** inline.e:517					backpatch_op = append( backpatch_op, pc )*/
        Append(&_backpatch_op_54041, _backpatch_op_54041, _pc_54001);
        DeRef(_values_54122);
        _values_54122 = NOVALUE;

        /** inline.e:520				case else*/
        default:

        /** inline.e:521				label "inline op"*/
G18:

        /** inline.e:522					if not inline_op( pc ) then*/
        _27420 = _67inline_op(_pc_54001);
        if (IS_ATOM_INT(_27420)) {
            if (_27420 != 0){
                DeRef(_27420);
                _27420 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        else {
            if (DBL_PTR(_27420)->dbl != 0.0){
                DeRef(_27420);
                _27420 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        DeRef(_27420);
        _27420 = NOVALUE;

        /** inline.e:524						defer()*/
        _67defer();

        /** inline.e:525						restore_code()*/
        _67restore_code();

        /** inline.e:526						return*/
        DeRefi(_backpatch_op_54041);
        DeRef(_27381);
        _27381 = NOVALUE;
        DeRef(_27412);
        _27412 = NOVALUE;
        DeRef(_27357);
        _27357 = NOVALUE;
        DeRef(_27406);
        _27406 = NOVALUE;
        DeRef(_27360);
        _27360 = NOVALUE;
        DeRef(_27394);
        _27394 = NOVALUE;
        DeRef(_27408);
        _27408 = NOVALUE;
        DeRef(_27363);
        _27363 = NOVALUE;
        DeRef(_27395);
        _27395 = NOVALUE;
        DeRef(_27390);
        _27390 = NOVALUE;
        DeRef(_27401);
        _27401 = NOVALUE;
        DeRef(_27398);
        _27398 = NOVALUE;
        _27413 = NOVALUE;
        _27353 = NOVALUE;
        DeRef(_27374);
        _27374 = NOVALUE;
        return;
L1D: 
    ;}LF: 

    /** inline.e:530			pc = advance( pc, inline_code )*/
    RefDS(_67inline_code_53453);
    _pc_54001 = _67advance(_pc_54001, _67inline_code_53453);
    if (!IS_ATOM_INT(_pc_54001)) {
        _1 = (object)(DBL_PTR(_pc_54001)->dbl);
        DeRefDS(_pc_54001);
        _pc_54001 = _1;
    }

    /** inline.e:532		end while*/
    goto LD; // [866] 347
LE: 

    /** inline.e:534		SymTab[sub][S_INLINE] = { sort( assigned_params ), inline_code, backpatch_op }*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_53972 + ((s1_ptr)_2)->base);
    RefDS(_67assigned_params_53459);
    _27425 = _24sort(_67assigned_params_53459, 1);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _27425;
    RefDS(_67inline_code_53453);
    ((intptr_t*)_2)[2] = _67inline_code_53453;
    RefDS(_backpatch_op_54041);
    ((intptr_t*)_2)[3] = _backpatch_op_54041;
    _27426 = MAKE_SEQ(_1);
    _27425 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 29);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27426;
    if( _1 != _27426 ){
        DeRef(_1);
    }
    _27426 = NOVALUE;
    _27423 = NOVALUE;

    /** inline.e:535		restore_code()*/
    _67restore_code();

    /** inline.e:536	end procedure*/
    DeRefDSi(_backpatch_op_54041);
    DeRef(_27381);
    _27381 = NOVALUE;
    DeRef(_27412);
    _27412 = NOVALUE;
    DeRef(_27357);
    _27357 = NOVALUE;
    DeRef(_27406);
    _27406 = NOVALUE;
    DeRef(_27360);
    _27360 = NOVALUE;
    DeRef(_27394);
    _27394 = NOVALUE;
    DeRef(_27408);
    _27408 = NOVALUE;
    DeRef(_27363);
    _27363 = NOVALUE;
    DeRef(_27395);
    _27395 = NOVALUE;
    DeRef(_27390);
    _27390 = NOVALUE;
    DeRef(_27401);
    _27401 = NOVALUE;
    DeRef(_27398);
    _27398 = NOVALUE;
    _27413 = NOVALUE;
    _27353 = NOVALUE;
    DeRef(_27374);
    _27374 = NOVALUE;
    return;
    ;
}


void _67replace_temp(object _pc_54150)
{
    object _temp_num_54151 = NOVALUE;
    object _needed_54154 = NOVALUE;
    object _27439 = NOVALUE;
    object _27438 = NOVALUE;
    object _27437 = NOVALUE;
    object _27436 = NOVALUE;
    object _27434 = NOVALUE;
    object _27432 = NOVALUE;
    object _27429 = NOVALUE;
    object _27427 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:539		integer temp_num = inline_code[pc][2]*/
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    _27427 = (object)*(((s1_ptr)_2)->base + _pc_54150);
    _2 = (object)SEQ_PTR(_27427);
    _temp_num_54151 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_temp_num_54151)){
        _temp_num_54151 = (object)DBL_PTR(_temp_num_54151)->dbl;
    }
    _27427 = NOVALUE;

    /** inline.e:540		integer needed = temp_num - length( inline_temps )*/
    if (IS_SEQUENCE(_67inline_temps_53455)){
            _27429 = SEQ_PTR(_67inline_temps_53455)->length;
    }
    else {
        _27429 = 1;
    }
    _needed_54154 = _temp_num_54151 - _27429;
    _27429 = NOVALUE;

    /** inline.e:541		if needed > 0 then*/
    if (_needed_54154 <= 0)
    goto L1; // [30] 47

    /** inline.e:542			inline_temps &= repeat( 0, needed )*/
    _27432 = Repeat(0, _needed_54154);
    Concat((object_ptr)&_67inline_temps_53455, _67inline_temps_53455, _27432);
    DeRefDS(_27432);
    _27432 = NOVALUE;
L1: 

    /** inline.e:545		if not inline_temps[temp_num] then*/
    _2 = (object)SEQ_PTR(_67inline_temps_53455);
    _27434 = (object)*(((s1_ptr)_2)->base + _temp_num_54151);
    if (IS_ATOM_INT(_27434)) {
        if (_27434 != 0){
            _27434 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    else {
        if (DBL_PTR(_27434)->dbl != 0.0){
            _27434 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    _27434 = NOVALUE;

    /** inline.e:546			if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L3; // [62] 84
    }
    else{
    }

    /** inline.e:547				inline_temps[temp_num] = new_inline_var( -temp_num, 0 )*/
    if ((uintptr_t)_temp_num_54151 == (uintptr_t)HIGH_BITS){
        _27436 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _27436 = - _temp_num_54151;
    }
    _27437 = _67new_inline_var(_27436, 0);
    _27436 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_temps_53455);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_temps_53455 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _temp_num_54151);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27437;
    if( _1 != _27437 ){
        DeRef(_1);
    }
    _27437 = NOVALUE;
    goto L4; // [81] 99
L3: 

    /** inline.e:549				inline_temps[temp_num] = NewTempSym( TRUE )*/
    _27438 = _54NewTempSym(_13TRUE_452);
    _2 = (object)SEQ_PTR(_67inline_temps_53455);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_temps_53455 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _temp_num_54151);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27438;
    if( _1 != _27438 ){
        DeRef(_1);
    }
    _27438 = NOVALUE;
L4: 
L2: 

    /** inline.e:554		inline_code[pc] = inline_temps[temp_num]*/
    _2 = (object)SEQ_PTR(_67inline_temps_53455);
    _27439 = (object)*(((s1_ptr)_2)->base + _temp_num_54151);
    Ref(_27439);
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53453 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_54150);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27439;
    if( _1 != _27439 ){
        DeRef(_1);
    }
    _27439 = NOVALUE;

    /** inline.e:555	end procedure*/
    return;
    ;
}


object _67get_param_sym(object _pc_54176)
{
    object _il_54177 = NOVALUE;
    object _px_54185 = NOVALUE;
    object _27446 = NOVALUE;
    object _27443 = NOVALUE;
    object _27442 = NOVALUE;
    object _27441 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:558		object il = inline_code[pc]*/
    DeRef(_il_54177);
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    _il_54177 = (object)*(((s1_ptr)_2)->base + _pc_54176);
    Ref(_il_54177);

    /** inline.e:559		if integer( il ) then*/
    if (IS_ATOM_INT(_il_54177))
    _27441 = 1;
    else if (IS_ATOM_DBL(_il_54177))
    _27441 = IS_ATOM_INT(DoubleToInt(_il_54177));
    else
    _27441 = 0;
    if (_27441 == 0)
    {
        _27441 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27441 = NOVALUE;
    }

    /** inline.e:560			return inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    _27442 = (object)*(((s1_ptr)_2)->base + _pc_54176);
    Ref(_27442);
    DeRef(_il_54177);
    return _27442;
    goto L2; // [31] 53
L1: 

    /** inline.e:562		elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_54177)){
            _27443 = SEQ_PTR(_il_54177)->length;
    }
    else {
        _27443 = 1;
    }
    if (_27443 != 1)
    goto L3; // [39] 52

    /** inline.e:563			return inline_target*/
    DeRef(_il_54177);
    _27442 = NOVALUE;
    return _67inline_target_53460;
L3: 
L2: 

    /** inline.e:567		integer px = il[2]*/
    _2 = (object)SEQ_PTR(_il_54177);
    _px_54185 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_px_54185)){
        _px_54185 = (object)DBL_PTR(_px_54185)->dbl;
    }

    /** inline.e:568		return passed_params[px]*/
    _2 = (object)SEQ_PTR(_67passed_params_53456);
    _27446 = (object)*(((s1_ptr)_2)->base + _px_54185);
    Ref(_27446);
    DeRef(_il_54177);
    _27442 = NOVALUE;
    return _27446;
    ;
}


object _67get_original_sym(object _pc_54190)
{
    object _il_54191 = NOVALUE;
    object _px_54199 = NOVALUE;
    object _27453 = NOVALUE;
    object _27450 = NOVALUE;
    object _27449 = NOVALUE;
    object _27448 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_54190)) {
        _1 = (object)(DBL_PTR(_pc_54190)->dbl);
        DeRefDS(_pc_54190);
        _pc_54190 = _1;
    }

    /** inline.e:572		object il = inline_code[pc]*/
    DeRef(_il_54191);
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    _il_54191 = (object)*(((s1_ptr)_2)->base + _pc_54190);
    Ref(_il_54191);

    /** inline.e:573		if integer( il ) then*/
    if (IS_ATOM_INT(_il_54191))
    _27448 = 1;
    else if (IS_ATOM_DBL(_il_54191))
    _27448 = IS_ATOM_INT(DoubleToInt(_il_54191));
    else
    _27448 = 0;
    if (_27448 == 0)
    {
        _27448 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27448 = NOVALUE;
    }

    /** inline.e:574			return inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    _27449 = (object)*(((s1_ptr)_2)->base + _pc_54190);
    Ref(_27449);
    DeRef(_il_54191);
    return _27449;
    goto L2; // [31] 53
L1: 

    /** inline.e:576		elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_54191)){
            _27450 = SEQ_PTR(_il_54191)->length;
    }
    else {
        _27450 = 1;
    }
    if (_27450 != 1)
    goto L3; // [39] 52

    /** inline.e:577			return inline_target*/
    DeRef(_il_54191);
    _27449 = NOVALUE;
    return _67inline_target_53460;
L3: 
L2: 

    /** inline.e:581		integer px = il[2]*/
    _2 = (object)SEQ_PTR(_il_54191);
    _px_54199 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_px_54199)){
        _px_54199 = (object)DBL_PTR(_px_54199)->dbl;
    }

    /** inline.e:582		return original_params[px]*/
    _2 = (object)SEQ_PTR(_67original_params_53457);
    _27453 = (object)*(((s1_ptr)_2)->base + _px_54199);
    Ref(_27453);
    DeRef(_il_54191);
    _27449 = NOVALUE;
    return _27453;
    ;
}


void _67replace_var(object _pc_54208)
{
    object _27457 = NOVALUE;
    object _27456 = NOVALUE;
    object _27455 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:590		inline_code[pc] = proc_vars[inline_code[pc][2]]*/
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    _27455 = (object)*(((s1_ptr)_2)->base + _pc_54208);
    _2 = (object)SEQ_PTR(_27455);
    _27456 = (object)*(((s1_ptr)_2)->base + 2);
    _27455 = NOVALUE;
    _2 = (object)SEQ_PTR(_67proc_vars_53454);
    if (!IS_ATOM_INT(_27456)){
        _27457 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27456)->dbl));
    }
    else{
        _27457 = (object)*(((s1_ptr)_2)->base + _27456);
    }
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53453 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_54208);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27457;
    if( _1 != _27457 ){
        DeRef(_1);
    }
    _27457 = NOVALUE;

    /** inline.e:591	end procedure*/
    _27456 = NOVALUE;
    return;
    ;
}


void _67fix_switch_rt(object _pc_54214)
{
    object _value_table_54216 = NOVALUE;
    object _jump_table_54223 = NOVALUE;
    object _27477 = NOVALUE;
    object _27476 = NOVALUE;
    object _27475 = NOVALUE;
    object _27474 = NOVALUE;
    object _27473 = NOVALUE;
    object _27472 = NOVALUE;
    object _27470 = NOVALUE;
    object _27469 = NOVALUE;
    object _27468 = NOVALUE;
    object _27467 = NOVALUE;
    object _27466 = NOVALUE;
    object _27464 = NOVALUE;
    object _27462 = NOVALUE;
    object _27461 = NOVALUE;
    object _27459 = NOVALUE;
    object _27458 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:594		symtab_index value_table = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _27458 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _27458 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = _27458;
    _27459 = MAKE_SEQ(_1);
    _27458 = NOVALUE;
    _value_table_54216 = _54NewStringSym(_27459);
    _27459 = NOVALUE;
    if (!IS_ATOM_INT(_value_table_54216)) {
        _1 = (object)(DBL_PTR(_value_table_54216)->dbl);
        DeRefDS(_value_table_54216);
        _value_table_54216 = _1;
    }

    /** inline.e:595		symtab_index jump_table  = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _27461 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _27461 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = _27461;
    _27462 = MAKE_SEQ(_1);
    _27461 = NOVALUE;
    _jump_table_54223 = _54NewStringSym(_27462);
    _27462 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_54223)) {
        _1 = (object)(DBL_PTR(_jump_table_54223)->dbl);
        DeRefDS(_jump_table_54223);
        _jump_table_54223 = _1;
    }

    /** inline.e:597		SymTab[value_table][S_OBJ] = SymTab[inline_code[pc+2]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_value_table_54216 + ((s1_ptr)_2)->base);
    _27466 = _pc_54214 + 2;
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    _27467 = (object)*(((s1_ptr)_2)->base + _27466);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_27467)){
        _27468 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27467)->dbl));
    }
    else{
        _27468 = (object)*(((s1_ptr)_2)->base + _27467);
    }
    _2 = (object)SEQ_PTR(_27468);
    _27469 = (object)*(((s1_ptr)_2)->base + 1);
    _27468 = NOVALUE;
    Ref(_27469);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27469;
    if( _1 != _27469 ){
        DeRef(_1);
    }
    _27469 = NOVALUE;
    _27464 = NOVALUE;

    /** inline.e:598		SymTab[jump_table][S_OBJ]  = SymTab[inline_code[pc+3]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_jump_table_54223 + ((s1_ptr)_2)->base);
    _27472 = _pc_54214 + 3;
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    _27473 = (object)*(((s1_ptr)_2)->base + _27472);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_27473)){
        _27474 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27473)->dbl));
    }
    else{
        _27474 = (object)*(((s1_ptr)_2)->base + _27473);
    }
    _2 = (object)SEQ_PTR(_27474);
    _27475 = (object)*(((s1_ptr)_2)->base + 1);
    _27474 = NOVALUE;
    Ref(_27475);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27475;
    if( _1 != _27475 ){
        DeRef(_1);
    }
    _27475 = NOVALUE;
    _27470 = NOVALUE;

    /** inline.e:600		inline_code[pc+2] = value_table*/
    _27476 = _pc_54214 + 2;
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53453 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27476);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _value_table_54216;
    DeRef(_1);

    /** inline.e:601		inline_code[pc+3] = jump_table*/
    _27477 = _pc_54214 + 3;
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53453 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27477);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _jump_table_54223;
    DeRef(_1);

    /** inline.e:603	end procedure*/
    _27466 = NOVALUE;
    _27473 = NOVALUE;
    _27472 = NOVALUE;
    _27467 = NOVALUE;
    _27476 = NOVALUE;
    _27477 = NOVALUE;
    return;
    ;
}


void _67fixup_special_op(object _pc_54253)
{
    object _op_54254 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_54253)) {
        _1 = (object)(DBL_PTR(_pc_54253)->dbl);
        DeRefDS(_pc_54253);
        _pc_54253 = _1;
    }

    /** inline.e:606		integer op = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    _op_54254 = (object)*(((s1_ptr)_2)->base + _pc_54253);
    if (!IS_ATOM_INT(_op_54254))
    _op_54254 = (object)DBL_PTR(_op_54254)->dbl;

    /** inline.e:607		switch op with fallthru do*/
    _0 = _op_54254;
    switch ( _0 ){ 

        /** inline.e:608			case SWITCH_RT then*/
        case 202:

        /** inline.e:609				fix_switch_rt( pc )*/
        _67fix_switch_rt(_pc_54253);

        /** inline.e:610				break*/
        goto L1; // [29] 32
    ;}L1: 

    /** inline.e:612	end procedure*/
    return;
    ;
}


object _67new_inline_var(object _ps_54265, object _reuse_54266)
{
    object _var_54268 = NOVALUE;
    object _vtype_54269 = NOVALUE;
    object _name_54270 = NOVALUE;
    object _s_54272 = NOVALUE;
    object _27540 = NOVALUE;
    object _27539 = NOVALUE;
    object _27537 = NOVALUE;
    object _27534 = NOVALUE;
    object _27533 = NOVALUE;
    object _27531 = NOVALUE;
    object _27528 = NOVALUE;
    object _27527 = NOVALUE;
    object _27526 = NOVALUE;
    object _27524 = NOVALUE;
    object _27519 = NOVALUE;
    object _27514 = NOVALUE;
    object _27513 = NOVALUE;
    object _27512 = NOVALUE;
    object _27511 = NOVALUE;
    object _27508 = NOVALUE;
    object _27506 = NOVALUE;
    object _27503 = NOVALUE;
    object _27498 = NOVALUE;
    object _27497 = NOVALUE;
    object _27496 = NOVALUE;
    object _27495 = NOVALUE;
    object _27494 = NOVALUE;
    object _27491 = NOVALUE;
    object _27490 = NOVALUE;
    object _27489 = NOVALUE;
    object _27488 = NOVALUE;
    object _27487 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ps_54265)) {
        _1 = (object)(DBL_PTR(_ps_54265)->dbl);
        DeRefDS(_ps_54265);
        _ps_54265 = _1;
    }

    /** inline.e:622			var = 0, */
    _var_54268 = 0;

    /** inline.e:624		sequence name*/

    /** inline.e:627		if reuse then*/

    /** inline.e:631		if not var then*/

    /** inline.e:632			if ps > 0 then*/
    if (_ps_54265 <= 0)
    goto L1; // [45] 222

    /** inline.e:633				s = ps*/
    _s_54272 = _ps_54265;

    /** inline.e:634				if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L2; // [60] 102
    }
    else{
    }

    /** inline.e:635					name = sprintf( "%s_inlined_%s", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27487 = (object)*(((s1_ptr)_2)->base + _s_54272);
    _2 = (object)SEQ_PTR(_27487);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _27488 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _27488 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _27487 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27489 = (object)*(((s1_ptr)_2)->base + _67inline_sub_53467);
    _2 = (object)SEQ_PTR(_27489);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _27490 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _27490 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _27489 = NOVALUE;
    Ref(_27490);
    Ref(_27488);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27488;
    ((intptr_t *)_2)[2] = _27490;
    _27491 = MAKE_SEQ(_1);
    _27490 = NOVALUE;
    _27488 = NOVALUE;
    DeRefi(_name_54270);
    _name_54270 = EPrintf(-9999999, _27486, _27491);
    DeRefDS(_27491);
    _27491 = NOVALUE;
    goto L3; // [99] 139
L2: 

    /** inline.e:637					name = sprintf( "%s (from inlined routine '%s'", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27494 = (object)*(((s1_ptr)_2)->base + _s_54272);
    _2 = (object)SEQ_PTR(_27494);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _27495 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _27495 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _27494 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27496 = (object)*(((s1_ptr)_2)->base + _67inline_sub_53467);
    _2 = (object)SEQ_PTR(_27496);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _27497 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _27497 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _27496 = NOVALUE;
    Ref(_27497);
    Ref(_27495);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27495;
    ((intptr_t *)_2)[2] = _27497;
    _27498 = MAKE_SEQ(_1);
    _27497 = NOVALUE;
    _27495 = NOVALUE;
    DeRefi(_name_54270);
    _name_54270 = EPrintf(-9999999, _27493, _27498);
    DeRefDS(_27498);
    _27498 = NOVALUE;
L3: 

    /** inline.e:640				if reuse then*/
    if (_reuse_54266 == 0)
    {
        goto L4; // [141] 163
    }
    else{
    }

    /** inline.e:641					if not TRANSLATE then*/
    if (_36TRANSLATE_21049 != 0)
    goto L5; // [148] 203

    /** inline.e:642						name &= ")"*/
    Concat((object_ptr)&_name_54270, _name_54270, _26263);
    goto L5; // [160] 203
L4: 

    /** inline.e:645					if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L6; // [167] 187
    }
    else{
    }

    /** inline.e:646						name &= sprintf( "_at_%d", inline_start)*/
    _27503 = EPrintf(-9999999, _27502, _67inline_start_53465);
    Concat((object_ptr)&_name_54270, _name_54270, _27503);
    DeRefDS(_27503);
    _27503 = NOVALUE;
    goto L7; // [184] 202
L6: 

    /** inline.e:648						name &= sprintf( " at %d)", inline_start)*/
    _27506 = EPrintf(-9999999, _27505, _67inline_start_53465);
    Concat((object_ptr)&_name_54270, _name_54270, _27506);
    DeRefDS(_27506);
    _27506 = NOVALUE;
L7: 
L5: 

    /** inline.e:652				vtype = SymTab[s][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27508 = (object)*(((s1_ptr)_2)->base + _s_54272);
    _2 = (object)SEQ_PTR(_27508);
    _vtype_54269 = (object)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_vtype_54269)){
        _vtype_54269 = (object)DBL_PTR(_vtype_54269)->dbl;
    }
    _27508 = NOVALUE;
    goto L8; // [219] 286
L1: 

    /** inline.e:654				name = sprintf( "%s_%d", {SymTab[inline_sub][S_NAME], -ps})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27511 = (object)*(((s1_ptr)_2)->base + _67inline_sub_53467);
    _2 = (object)SEQ_PTR(_27511);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _27512 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _27512 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _27511 = NOVALUE;
    if ((uintptr_t)_ps_54265 == (uintptr_t)HIGH_BITS){
        _27513 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _27513 = - _ps_54265;
    }
    Ref(_27512);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27512;
    ((intptr_t *)_2)[2] = _27513;
    _27514 = MAKE_SEQ(_1);
    _27513 = NOVALUE;
    _27512 = NOVALUE;
    DeRefi(_name_54270);
    _name_54270 = EPrintf(-9999999, _27510, _27514);
    DeRefDS(_27514);
    _27514 = NOVALUE;

    /** inline.e:655				if reuse then*/
    if (_reuse_54266 == 0)
    {
        goto L9; // [251] 263
    }
    else{
    }

    /** inline.e:656					name &= "__tmp"*/
    Concat((object_ptr)&_name_54270, _name_54270, _27516);
    goto LA; // [260] 276
L9: 

    /** inline.e:658					name &= sprintf( "__tmp_at%d", inline_start)*/
    _27519 = EPrintf(-9999999, _27518, _67inline_start_53465);
    Concat((object_ptr)&_name_54270, _name_54270, _27519);
    DeRefDS(_27519);
    _27519 = NOVALUE;
LA: 

    /** inline.e:660				vtype = object_type*/
    _vtype_54269 = _54object_type_46780;
L8: 

    /** inline.e:662			if CurrentSub = TopLevelSub then*/
    if (_36CurrentSub_21455 != _36TopLevelSub_21454)
    goto LB; // [292] 325

    /** inline.e:663				var = NewEntry( name, varnum, SC_LOCAL, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_54270);
    _var_54268 = _54NewEntry(_name_54270, _67varnum_53464, 5, -100, 2004, 0, _vtype_54269);
    if (!IS_ATOM_INT(_var_54268)) {
        _1 = (object)(DBL_PTR(_var_54268)->dbl);
        DeRefDS(_var_54268);
        _var_54268 = _1;
    }
    goto LC; // [322] 416
LB: 

    /** inline.e:666				var = NewBasicEntry( name, varnum, SC_PRIVATE, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_54270);
    _var_54268 = _54NewBasicEntry(_name_54270, _67varnum_53464, 3, -100, 2004, 0, _vtype_54269);
    if (!IS_ATOM_INT(_var_54268)) {
        _1 = (object)(DBL_PTR(_var_54268)->dbl);
        DeRefDS(_var_54268);
        _var_54268 = _1;
    }

    /** inline.e:667				SymTab[var][S_NEXT] = SymTab[last_param][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_var_54268 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27526 = (object)*(((s1_ptr)_2)->base + _67last_param_53468);
    _2 = (object)SEQ_PTR(_27526);
    _27527 = (object)*(((s1_ptr)_2)->base + 2);
    _27526 = NOVALUE;
    Ref(_27527);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27527;
    if( _1 != _27527 ){
        DeRef(_1);
    }
    _27527 = NOVALUE;
    _27524 = NOVALUE;

    /** inline.e:668				SymTab[last_param][S_NEXT] = var*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67last_param_53468 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _var_54268;
    DeRef(_1);
    _27528 = NOVALUE;

    /** inline.e:669				if last_param = last_sym then*/
    if (_67last_param_53468 != _54last_sym_46789)
    goto LD; // [403] 415

    /** inline.e:670					last_sym = var*/
    _54last_sym_46789 = _var_54268;
LD: 
LC: 

    /** inline.e:673			if deferred_inlining then*/
    if (_67deferred_inlining_53463 == 0)
    {
        goto LE; // [420] 451
    }
    else{
    }

    /** inline.e:674				SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21455 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21144)){
        _27533 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21144)->dbl));
    }
    else{
        _27533 = (object)*(((s1_ptr)_2)->base + _36S_STACK_SPACE_21144);
    }
    _27531 = NOVALUE;
    if (IS_ATOM_INT(_27533)) {
        _27534 = _27533 + 1;
        if (_27534 > MAXINT){
            _27534 = NewDouble((eudouble)_27534);
        }
    }
    else
    _27534 = binary_op(PLUS, 1, _27533);
    _27533 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21144))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21144)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_STACK_SPACE_21144);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27534;
    if( _1 != _27534 ){
        DeRef(_1);
    }
    _27534 = NOVALUE;
    _27531 = NOVALUE;
    goto LF; // [448] 471
LE: 

    /** inline.e:676				if param_num != -1 then*/
    if (_45param_num_54937 == -1)
    goto L10; // [455] 470

    /** inline.e:677					param_num += 1*/
    _45param_num_54937 = _45param_num_54937 + 1;
L10: 
LF: 

    /** inline.e:680			SymTab[var][S_USAGE] = U_USED*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_var_54268 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _27537 = NOVALUE;

    /** inline.e:681			if reuse then*/
    if (_reuse_54266 == 0)
    {
        goto L11; // [490] 511
    }
    else{
    }

    /** inline.e:682				map:nested_put( inline_var_map, {CurrentSub, ps }, var )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _36CurrentSub_21455;
    ((intptr_t *)_2)[2] = _ps_54265;
    _27539 = MAKE_SEQ(_1);
    Ref(_67inline_var_map_53472);
    _29nested_put(_67inline_var_map_53472, _27539, _var_54268, 1, 0);
    _27539 = NOVALUE;
L11: 

    /** inline.e:686		Block_var( var )*/
    _65Block_var(_var_54268);

    /** inline.e:687		if BIND then*/
    if (_36BIND_21052 == 0)
    {
        goto L12; // [521] 536
    }
    else{
    }

    /** inline.e:688			add_ref( {VARIABLE, var} )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _var_54268;
    _27540 = MAKE_SEQ(_1);
    _54add_ref(_27540);
    _27540 = NOVALUE;
L12: 

    /** inline.e:690		return var*/
    DeRefi(_name_54270);
    return _var_54268;
    ;
}


object _67get_inlined_code(object _sub_54402, object _start_54403, object _deferred_54404)
{
    object _is_proc_54405 = NOVALUE;
    object _backpatches_54423 = NOVALUE;
    object _prolog_54429 = NOVALUE;
    object _epilog_54430 = NOVALUE;
    object _s_54446 = NOVALUE;
    object _last_sym_54469 = NOVALUE;
    object _int_sym_54496 = NOVALUE;
    object _param_54504 = NOVALUE;
    object _ax_54507 = NOVALUE;
    object _var_54514 = NOVALUE;
    object _final_target_54529 = NOVALUE;
    object _var_54548 = NOVALUE;
    object _create_target_var_54561 = NOVALUE;
    object _check_pc_54584 = NOVALUE;
    object _op_54588 = NOVALUE;
    object _sym_54597 = NOVALUE;
    object _check_result_54602 = NOVALUE;
    object _inline_type_54680 = NOVALUE;
    object _replace_param_1__tmp_at1343_54691 = NOVALUE;
    object _27694 = NOVALUE;
    object _27693 = NOVALUE;
    object _27692 = NOVALUE;
    object _27691 = NOVALUE;
    object _27690 = NOVALUE;
    object _27689 = NOVALUE;
    object _27688 = NOVALUE;
    object _27687 = NOVALUE;
    object _27685 = NOVALUE;
    object _27682 = NOVALUE;
    object _27679 = NOVALUE;
    object _27678 = NOVALUE;
    object _27677 = NOVALUE;
    object _27676 = NOVALUE;
    object _27675 = NOVALUE;
    object _27674 = NOVALUE;
    object _27673 = NOVALUE;
    object _27672 = NOVALUE;
    object _27668 = NOVALUE;
    object _27667 = NOVALUE;
    object _27666 = NOVALUE;
    object _27665 = NOVALUE;
    object _27661 = NOVALUE;
    object _27660 = NOVALUE;
    object _27659 = NOVALUE;
    object _27658 = NOVALUE;
    object _27657 = NOVALUE;
    object _27656 = NOVALUE;
    object _27655 = NOVALUE;
    object _27653 = NOVALUE;
    object _27652 = NOVALUE;
    object _27651 = NOVALUE;
    object _27650 = NOVALUE;
    object _27649 = NOVALUE;
    object _27648 = NOVALUE;
    object _27647 = NOVALUE;
    object _27646 = NOVALUE;
    object _27645 = NOVALUE;
    object _27644 = NOVALUE;
    object _27643 = NOVALUE;
    object _27641 = NOVALUE;
    object _27640 = NOVALUE;
    object _27638 = NOVALUE;
    object _27637 = NOVALUE;
    object _27635 = NOVALUE;
    object _27634 = NOVALUE;
    object _27631 = NOVALUE;
    object _27630 = NOVALUE;
    object _27628 = NOVALUE;
    object _27626 = NOVALUE;
    object _27621 = NOVALUE;
    object _27617 = NOVALUE;
    object _27614 = NOVALUE;
    object _27610 = NOVALUE;
    object _27603 = NOVALUE;
    object _27602 = NOVALUE;
    object _27601 = NOVALUE;
    object _27600 = NOVALUE;
    object _27599 = NOVALUE;
    object _27598 = NOVALUE;
    object _27597 = NOVALUE;
    object _27595 = NOVALUE;
    object _27590 = NOVALUE;
    object _27587 = NOVALUE;
    object _27582 = NOVALUE;
    object _27581 = NOVALUE;
    object _27579 = NOVALUE;
    object _27578 = NOVALUE;
    object _27577 = NOVALUE;
    object _27574 = NOVALUE;
    object _27573 = NOVALUE;
    object _27572 = NOVALUE;
    object _27571 = NOVALUE;
    object _27570 = NOVALUE;
    object _27569 = NOVALUE;
    object _27568 = NOVALUE;
    object _27566 = NOVALUE;
    object _27565 = NOVALUE;
    object _27564 = NOVALUE;
    object _27562 = NOVALUE;
    object _27560 = NOVALUE;
    object _27559 = NOVALUE;
    object _27558 = NOVALUE;
    object _27557 = NOVALUE;
    object _27556 = NOVALUE;
    object _27555 = NOVALUE;
    object _27554 = NOVALUE;
    object _27551 = NOVALUE;
    object _27550 = NOVALUE;
    object _27548 = NOVALUE;
    object _27547 = NOVALUE;
    object _27545 = NOVALUE;
    object _27544 = NOVALUE;
    object _27542 = NOVALUE;
    object _27541 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_start_54403)) {
        _1 = (object)(DBL_PTR(_start_54403)->dbl);
        DeRefDS(_start_54403);
        _start_54403 = _1;
    }

    /** inline.e:694		integer is_proc = SymTab[sub][S_TOKEN] = PROC*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27541 = (object)*(((s1_ptr)_2)->base + _sub_54402);
    _2 = (object)SEQ_PTR(_27541);
    if (!IS_ATOM_INT(_36S_TOKEN_21089)){
        _27542 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    }
    else{
        _27542 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    }
    _27541 = NOVALUE;
    if (IS_ATOM_INT(_27542)) {
        _is_proc_54405 = (_27542 == 27);
    }
    else {
        _is_proc_54405 = binary_op(EQUALS, _27542, 27);
    }
    _27542 = NOVALUE;
    if (!IS_ATOM_INT(_is_proc_54405)) {
        _1 = (object)(DBL_PTR(_is_proc_54405)->dbl);
        DeRefDS(_is_proc_54405);
        _is_proc_54405 = _1;
    }

    /** inline.e:695		clear_inline_targets()*/
    _47clear_inline_targets();

    /** inline.e:697		inline_temps = {}*/
    RefDS(_21997);
    DeRef(_67inline_temps_53455);
    _67inline_temps_53455 = _21997;

    /** inline.e:698		inline_params = {}*/
    RefDS(_21997);
    DeRefi(_67inline_params_53458);
    _67inline_params_53458 = _21997;

    /** inline.e:699		assigned_params      = SymTab[sub][S_INLINE][1]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27544 = (object)*(((s1_ptr)_2)->base + _sub_54402);
    _2 = (object)SEQ_PTR(_27544);
    _27545 = (object)*(((s1_ptr)_2)->base + 29);
    _27544 = NOVALUE;
    DeRef(_67assigned_params_53459);
    _2 = (object)SEQ_PTR(_27545);
    _67assigned_params_53459 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_67assigned_params_53459);
    _27545 = NOVALUE;

    /** inline.e:700		inline_code          = SymTab[sub][S_INLINE][2]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27547 = (object)*(((s1_ptr)_2)->base + _sub_54402);
    _2 = (object)SEQ_PTR(_27547);
    _27548 = (object)*(((s1_ptr)_2)->base + 29);
    _27547 = NOVALUE;
    DeRef(_67inline_code_53453);
    _2 = (object)SEQ_PTR(_27548);
    _67inline_code_53453 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_67inline_code_53453);
    _27548 = NOVALUE;

    /** inline.e:701		sequence backpatches = SymTab[sub][S_INLINE][3]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27550 = (object)*(((s1_ptr)_2)->base + _sub_54402);
    _2 = (object)SEQ_PTR(_27550);
    _27551 = (object)*(((s1_ptr)_2)->base + 29);
    _27550 = NOVALUE;
    DeRef(_backpatches_54423);
    _2 = (object)SEQ_PTR(_27551);
    _backpatches_54423 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_backpatches_54423);
    _27551 = NOVALUE;

    /** inline.e:703		passed_params = {}*/
    RefDS(_21997);
    DeRef(_67passed_params_53456);
    _67passed_params_53456 = _21997;

    /** inline.e:704		original_params = {}*/
    RefDS(_21997);
    DeRef(_67original_params_53457);
    _67original_params_53457 = _21997;

    /** inline.e:705		proc_vars = {}*/
    RefDS(_21997);
    DeRefi(_67proc_vars_53454);
    _67proc_vars_53454 = _21997;

    /** inline.e:706		sequence prolog = {}*/
    RefDS(_21997);
    DeRefi(_prolog_54429);
    _prolog_54429 = _21997;

    /** inline.e:707		sequence epilog = {}*/
    RefDS(_21997);
    DeRef(_epilog_54430);
    _epilog_54430 = _21997;

    /** inline.e:709		Start_block( EXIT_BLOCK, sprintf("Inline-%s from %s @ %d", */
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27554 = (object)*(((s1_ptr)_2)->base + _sub_54402);
    _2 = (object)SEQ_PTR(_27554);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _27555 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _27555 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _27554 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27556 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21455);
    _2 = (object)SEQ_PTR(_27556);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _27557 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _27557 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _27556 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_27555);
    ((intptr_t*)_2)[1] = _27555;
    Ref(_27557);
    ((intptr_t*)_2)[2] = _27557;
    ((intptr_t*)_2)[3] = _start_54403;
    _27558 = MAKE_SEQ(_1);
    _27557 = NOVALUE;
    _27555 = NOVALUE;
    _27559 = EPrintf(-9999999, _27553, _27558);
    DeRefDS(_27558);
    _27558 = NOVALUE;
    _65Start_block(206, _27559);
    _27559 = NOVALUE;

    /** inline.e:712		symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27560 = (object)*(((s1_ptr)_2)->base + _sub_54402);
    _2 = (object)SEQ_PTR(_27560);
    _s_54446 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_54446)){
        _s_54446 = (object)DBL_PTR(_s_54446)->dbl;
    }
    _27560 = NOVALUE;

    /** inline.e:714		varnum = SymTab[CurrentSub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27562 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21455);
    _2 = (object)SEQ_PTR(_27562);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
        _67varnum_53464 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
    }
    else{
        _67varnum_53464 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
    }
    if (!IS_ATOM_INT(_67varnum_53464)){
        _67varnum_53464 = (object)DBL_PTR(_67varnum_53464)->dbl;
    }
    _27562 = NOVALUE;

    /** inline.e:715		inline_start = start*/
    _67inline_start_53465 = _start_54403;

    /** inline.e:717		last_param = CurrentSub*/
    _67last_param_53468 = _36CurrentSub_21455;

    /** inline.e:718		for p = 1 to SymTab[CurrentSub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27564 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21455);
    _2 = (object)SEQ_PTR(_27564);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
        _27565 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
    }
    else{
        _27565 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
    }
    _27564 = NOVALUE;
    {
        object _p_54458;
        _p_54458 = 1;
L1: 
        if (binary_op_a(GREATER, _p_54458, _27565)){
            goto L2; // [250] 282
        }

        /** inline.e:719			last_param = SymTab[last_param][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27566 = (object)*(((s1_ptr)_2)->base + _67last_param_53468);
        _2 = (object)SEQ_PTR(_27566);
        _67last_param_53468 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_67last_param_53468)){
            _67last_param_53468 = (object)DBL_PTR(_67last_param_53468)->dbl;
        }
        _27566 = NOVALUE;

        /** inline.e:720		end for*/
        _0 = _p_54458;
        if (IS_ATOM_INT(_p_54458)) {
            _p_54458 = _p_54458 + 1;
            if ((object)((uintptr_t)_p_54458 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54458 = NewDouble((eudouble)_p_54458);
            }
        }
        else {
            _p_54458 = binary_op_a(PLUS, _p_54458, 1);
        }
        DeRef(_0);
        goto L1; // [277] 257
L2: 
        ;
        DeRef(_p_54458);
    }

    /** inline.e:722		symtab_index last_sym = last_param*/
    _last_sym_54469 = _67last_param_53468;

    /** inline.e:723		while last_sym and */
L3: 
    if (_last_sym_54469 == 0) {
        goto L4; // [296] 368
    }
    _27569 = _54sym_scope(_last_sym_54469);
    if (IS_ATOM_INT(_27569)) {
        _27570 = (_27569 <= 3);
    }
    else {
        _27570 = binary_op(LESSEQ, _27569, 3);
    }
    DeRef(_27569);
    _27569 = NOVALUE;
    if (IS_ATOM_INT(_27570)) {
        if (_27570 != 0) {
            DeRef(_27571);
            _27571 = 1;
            goto L5; // [310] 328
        }
    }
    else {
        if (DBL_PTR(_27570)->dbl != 0.0) {
            DeRef(_27571);
            _27571 = 1;
            goto L5; // [310] 328
        }
    }
    _27572 = _54sym_scope(_last_sym_54469);
    if (IS_ATOM_INT(_27572)) {
        _27573 = (_27572 == 9);
    }
    else {
        _27573 = binary_op(EQUALS, _27572, 9);
    }
    DeRef(_27572);
    _27572 = NOVALUE;
    DeRef(_27571);
    if (IS_ATOM_INT(_27573))
    _27571 = (_27573 != 0);
    else
    _27571 = DBL_PTR(_27573)->dbl != 0.0;
L5: 
    if (_27571 == 0)
    {
        _27571 = NOVALUE;
        goto L4; // [329] 368
    }
    else{
        _27571 = NOVALUE;
    }

    /** inline.e:725			last_param = last_sym*/
    _67last_param_53468 = _last_sym_54469;

    /** inline.e:726			last_sym = SymTab[last_sym][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27574 = (object)*(((s1_ptr)_2)->base + _last_sym_54469);
    _2 = (object)SEQ_PTR(_27574);
    _last_sym_54469 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_last_sym_54469)){
        _last_sym_54469 = (object)DBL_PTR(_last_sym_54469)->dbl;
    }
    _27574 = NOVALUE;

    /** inline.e:727			varnum += 1*/
    _67varnum_53464 = _67varnum_53464 + 1;

    /** inline.e:728		end while*/
    goto L3; // [365] 296
L4: 

    /** inline.e:729		for p = SymTab[sub][S_NUM_ARGS] to 1 by -1 do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27577 = (object)*(((s1_ptr)_2)->base + _sub_54402);
    _2 = (object)SEQ_PTR(_27577);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
        _27578 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
    }
    else{
        _27578 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
    }
    _27577 = NOVALUE;
    {
        object _p_54487;
        Ref(_27578);
        _p_54487 = _27578;
L6: 
        if (binary_op_a(LESS, _p_54487, 1)){
            goto L7; // [382] 407
        }

        /** inline.e:730			passed_params = prepend( passed_params, Pop() )*/
        _27579 = _47Pop();
        Ref(_27579);
        Prepend(&_67passed_params_53456, _67passed_params_53456, _27579);
        DeRef(_27579);
        _27579 = NOVALUE;

        /** inline.e:731		end for*/
        _0 = _p_54487;
        if (IS_ATOM_INT(_p_54487)) {
            _p_54487 = _p_54487 + -1;
            if ((object)((uintptr_t)_p_54487 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54487 = NewDouble((eudouble)_p_54487);
            }
        }
        else {
            _p_54487 = binary_op_a(PLUS, _p_54487, -1);
        }
        DeRef(_0);
        goto L6; // [402] 389
L7: 
        ;
        DeRef(_p_54487);
    }

    /** inline.e:733		original_params = passed_params*/
    RefDS(_67passed_params_53456);
    DeRef(_67original_params_53457);
    _67original_params_53457 = _67passed_params_53456;

    /** inline.e:735		symtab_index int_sym = 0*/
    _int_sym_54496 = 0;

    /** inline.e:736		for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27581 = (object)*(((s1_ptr)_2)->base + _sub_54402);
    _2 = (object)SEQ_PTR(_27581);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
        _27582 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
    }
    else{
        _27582 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
    }
    _27581 = NOVALUE;
    {
        object _p_54498;
        _p_54498 = 1;
L8: 
        if (binary_op_a(GREATER, _p_54498, _27582)){
            goto L9; // [437] 575
        }

        /** inline.e:737			symtab_index param = passed_params[p]*/
        _2 = (object)SEQ_PTR(_67passed_params_53456);
        if (!IS_ATOM_INT(_p_54498)){
            _param_54504 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_p_54498)->dbl));
        }
        else{
            _param_54504 = (object)*(((s1_ptr)_2)->base + _p_54498);
        }
        if (!IS_ATOM_INT(_param_54504)){
            _param_54504 = (object)DBL_PTR(_param_54504)->dbl;
        }

        /** inline.e:738			inline_params &= s*/
        Append(&_67inline_params_53458, _67inline_params_53458, _s_54446);

        /** inline.e:739			integer ax = find( p, assigned_params )*/
        _ax_54507 = find_from(_p_54498, _67assigned_params_53459, 1);

        /** inline.e:740			if ax or is_temp( param ) then*/
        if (_ax_54507 != 0) {
            goto LA; // [473] 486
        }
        _27587 = _67is_temp(_param_54504);
        if (_27587 == 0) {
            DeRef(_27587);
            _27587 = NOVALUE;
            goto LB; // [482] 548
        }
        else {
            if (!IS_ATOM_INT(_27587) && DBL_PTR(_27587)->dbl == 0.0){
                DeRef(_27587);
                _27587 = NOVALUE;
                goto LB; // [482] 548
            }
            DeRef(_27587);
            _27587 = NOVALUE;
        }
        DeRef(_27587);
        _27587 = NOVALUE;
LA: 

        /** inline.e:743				varnum += 1*/
        _67varnum_53464 = _67varnum_53464 + 1;

        /** inline.e:744				symtab_index var = new_inline_var( s, 0 )*/
        _var_54514 = _67new_inline_var(_s_54446, 0);
        if (!IS_ATOM_INT(_var_54514)) {
            _1 = (object)(DBL_PTR(_var_54514)->dbl);
            DeRefDS(_var_54514);
            _var_54514 = _1;
        }

        /** inline.e:745				prolog &= {ASSIGN, param, var}*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 18;
        ((intptr_t*)_2)[2] = _param_54504;
        ((intptr_t*)_2)[3] = _var_54514;
        _27590 = MAKE_SEQ(_1);
        Concat((object_ptr)&_prolog_54429, _prolog_54429, _27590);
        DeRefDS(_27590);
        _27590 = NOVALUE;

        /** inline.e:746				if not int_sym then*/
        if (_int_sym_54496 != 0)
        goto LC; // [519] 531

        /** inline.e:747					int_sym = NewIntSym( 0 )*/
        _int_sym_54496 = _54NewIntSym(0);
        if (!IS_ATOM_INT(_int_sym_54496)) {
            _1 = (object)(DBL_PTR(_int_sym_54496)->dbl);
            DeRefDS(_int_sym_54496);
            _int_sym_54496 = _1;
        }
LC: 

        /** inline.e:750				inline_start += 3*/
        _67inline_start_53465 = _67inline_start_53465 + 3;

        /** inline.e:751				passed_params[p] = var*/
        _2 = (object)SEQ_PTR(_67passed_params_53456);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67passed_params_53456 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_p_54498))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_p_54498)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _p_54498);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _var_54514;
        DeRef(_1);
LB: 

        /** inline.e:753			s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27595 = (object)*(((s1_ptr)_2)->base + _s_54446);
        _2 = (object)SEQ_PTR(_27595);
        _s_54446 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_54446)){
            _s_54446 = (object)DBL_PTR(_s_54446)->dbl;
        }
        _27595 = NOVALUE;

        /** inline.e:755		end for*/
        _0 = _p_54498;
        if (IS_ATOM_INT(_p_54498)) {
            _p_54498 = _p_54498 + 1;
            if ((object)((uintptr_t)_p_54498 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54498 = NewDouble((eudouble)_p_54498);
            }
        }
        else {
            _p_54498 = binary_op_a(PLUS, _p_54498, 1);
        }
        DeRef(_0);
        goto L8; // [570] 444
L9: 
        ;
        DeRef(_p_54498);
    }

    /** inline.e:757		symtab_index final_target = 0*/
    _final_target_54529 = 0;

    /** inline.e:758		while s and */
LD: 
    if (_s_54446 == 0) {
        goto LE; // [587] 699
    }
    _27598 = _54sym_scope(_s_54446);
    if (IS_ATOM_INT(_27598)) {
        _27599 = (_27598 <= 3);
    }
    else {
        _27599 = binary_op(LESSEQ, _27598, 3);
    }
    DeRef(_27598);
    _27598 = NOVALUE;
    if (IS_ATOM_INT(_27599)) {
        if (_27599 != 0) {
            DeRef(_27600);
            _27600 = 1;
            goto LF; // [601] 619
        }
    }
    else {
        if (DBL_PTR(_27599)->dbl != 0.0) {
            DeRef(_27600);
            _27600 = 1;
            goto LF; // [601] 619
        }
    }
    _27601 = _54sym_scope(_s_54446);
    if (IS_ATOM_INT(_27601)) {
        _27602 = (_27601 == 9);
    }
    else {
        _27602 = binary_op(EQUALS, _27601, 9);
    }
    DeRef(_27601);
    _27601 = NOVALUE;
    DeRef(_27600);
    if (IS_ATOM_INT(_27602))
    _27600 = (_27602 != 0);
    else
    _27600 = DBL_PTR(_27602)->dbl != 0.0;
LF: 
    if (_27600 == 0)
    {
        _27600 = NOVALUE;
        goto LE; // [620] 699
    }
    else{
        _27600 = NOVALUE;
    }

    /** inline.e:760			if sym_scope( s ) != SC_UNDEFINED then*/
    _27603 = _54sym_scope(_s_54446);
    if (binary_op_a(EQUALS, _27603, 9)){
        DeRef(_27603);
        _27603 = NOVALUE;
        goto L10; // [631] 676
    }
    DeRef(_27603);
    _27603 = NOVALUE;

    /** inline.e:763				varnum += 1*/
    _67varnum_53464 = _67varnum_53464 + 1;

    /** inline.e:764				symtab_index var = new_inline_var( s, 0 )*/
    _var_54548 = _67new_inline_var(_s_54446, 0);
    if (!IS_ATOM_INT(_var_54548)) {
        _1 = (object)(DBL_PTR(_var_54548)->dbl);
        DeRefDS(_var_54548);
        _var_54548 = _1;
    }

    /** inline.e:765				proc_vars &= var*/
    Append(&_67proc_vars_53454, _67proc_vars_53454, _var_54548);

    /** inline.e:766				if int_sym = 0 then*/
    if (_int_sym_54496 != 0)
    goto L11; // [662] 675

    /** inline.e:767					int_sym = NewIntSym( 0 )*/
    _int_sym_54496 = _54NewIntSym(0);
    if (!IS_ATOM_INT(_int_sym_54496)) {
        _1 = (object)(DBL_PTR(_int_sym_54496)->dbl);
        DeRefDS(_int_sym_54496);
        _int_sym_54496 = _1;
    }
L11: 
L10: 

    /** inline.e:770			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27610 = (object)*(((s1_ptr)_2)->base + _s_54446);
    _2 = (object)SEQ_PTR(_27610);
    _s_54446 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_54446)){
        _s_54446 = (object)DBL_PTR(_s_54446)->dbl;
    }
    _27610 = NOVALUE;

    /** inline.e:771		end while*/
    goto LD; // [696] 587
LE: 

    /** inline.e:773		if not is_proc then*/
    if (_is_proc_54405 != 0)
    goto L12; // [701] 831

    /** inline.e:774			integer create_target_var = 1*/
    _create_target_var_54561 = 1;

    /** inline.e:775			if deferred then*/
    if (_deferred_54404 == 0)
    {
        goto L13; // [711] 751
    }
    else{
    }

    /** inline.e:776				inline_target = Pop()*/
    _0 = _47Pop();
    _67inline_target_53460 = _0;
    if (!IS_ATOM_INT(_67inline_target_53460)) {
        _1 = (object)(DBL_PTR(_67inline_target_53460)->dbl);
        DeRefDS(_67inline_target_53460);
        _67inline_target_53460 = _1;
    }

    /** inline.e:777				if is_temp( inline_target ) then*/
    _27614 = _67is_temp(_67inline_target_53460);
    if (_27614 == 0) {
        DeRef(_27614);
        _27614 = NOVALUE;
        goto L14; // [729] 744
    }
    else {
        if (!IS_ATOM_INT(_27614) && DBL_PTR(_27614)->dbl == 0.0){
            DeRef(_27614);
            _27614 = NOVALUE;
            goto L14; // [729] 744
        }
        DeRef(_27614);
        _27614 = NOVALUE;
    }
    DeRef(_27614);
    _27614 = NOVALUE;

    /** inline.e:778					final_target = inline_target*/
    _final_target_54529 = _67inline_target_53460;
    goto L15; // [741] 750
L14: 

    /** inline.e:780					create_target_var = 0*/
    _create_target_var_54561 = 0;
L15: 
L13: 

    /** inline.e:784			if create_target_var then*/
    if (_create_target_var_54561 == 0)
    {
        goto L16; // [753] 816
    }
    else{
    }

    /** inline.e:785				varnum += 1*/
    _67varnum_53464 = _67varnum_53464 + 1;

    /** inline.e:786				if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L17; // [768] 806
    }
    else{
    }

    /** inline.e:787					inline_target = new_inline_var( sub, 0 )*/
    _0 = _67new_inline_var(_sub_54402, 0);
    _67inline_target_53460 = _0;
    if (!IS_ATOM_INT(_67inline_target_53460)) {
        _1 = (object)(DBL_PTR(_67inline_target_53460)->dbl);
        DeRefDS(_67inline_target_53460);
        _67inline_target_53460 = _1;
    }

    /** inline.e:788					SymTab[inline_target][S_VTYPE] = object_type*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67inline_target_53460 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54object_type_46780;
    DeRef(_1);
    _27617 = NOVALUE;

    /** inline.e:789					Pop_block_var()*/
    _65Pop_block_var();
    goto L18; // [803] 815
L17: 

    /** inline.e:791					inline_target = NewTempSym()*/
    _0 = _54NewTempSym(0);
    _67inline_target_53460 = _0;
    if (!IS_ATOM_INT(_67inline_target_53460)) {
        _1 = (object)(DBL_PTR(_67inline_target_53460)->dbl);
        DeRefDS(_67inline_target_53460);
        _67inline_target_53460 = _1;
    }
L18: 
L16: 

    /** inline.e:794			proc_vars &= inline_target*/
    Append(&_67proc_vars_53454, _67proc_vars_53454, _67inline_target_53460);
    goto L19; // [828] 837
L12: 

    /** inline.e:796			inline_target = 0*/
    _67inline_target_53460 = 0;
L19: 

    /** inline.e:800		integer check_pc = 1*/
    _check_pc_54584 = 1;

    /** inline.e:802		while length(inline_code) > check_pc do*/
L1A: 
    if (IS_SEQUENCE(_67inline_code_53453)){
            _27621 = SEQ_PTR(_67inline_code_53453)->length;
    }
    else {
        _27621 = 1;
    }
    if (_27621 <= _check_pc_54584)
    goto L1B; // [852] 1218

    /** inline.e:803			integer op = inline_code[check_pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53453);
    _op_54588 = (object)*(((s1_ptr)_2)->base + _check_pc_54584);
    if (!IS_ATOM_INT(_op_54588))
    _op_54588 = (object)DBL_PTR(_op_54588)->dbl;

    /** inline.e:805			switch op with fallthru do*/
    _0 = _op_54588;
    switch ( _0 ){ 

        /** inline.e:806				case ATOM_CHECK then*/
        case 101:
        case 97:
        case 96:

        /** inline.e:809					symtab_index sym = get_original_sym( check_pc + 1 )*/
        _27626 = _check_pc_54584 + 1;
        if (_27626 > MAXINT){
            _27626 = NewDouble((eudouble)_27626);
        }
        _sym_54597 = _67get_original_sym(_27626);
        _27626 = NOVALUE;
        if (!IS_ATOM_INT(_sym_54597)) {
            _1 = (object)(DBL_PTR(_sym_54597)->dbl);
            DeRefDS(_sym_54597);
            _sym_54597 = _1;
        }

        /** inline.e:810					if is_literal( sym ) then*/
        _27628 = _67is_literal(_sym_54597);
        if (_27628 == 0) {
            DeRef(_27628);
            _27628 = NOVALUE;
            goto L1C; // [897] 1012
        }
        else {
            if (!IS_ATOM_INT(_27628) && DBL_PTR(_27628)->dbl == 0.0){
                DeRef(_27628);
                _27628 = NOVALUE;
                goto L1C; // [897] 1012
            }
            DeRef(_27628);
            _27628 = NOVALUE;
        }
        DeRef(_27628);
        _27628 = NOVALUE;

        /** inline.e:811						integer check_result*/

        /** inline.e:813						if op = INTEGER_CHECK then*/
        if (_op_54588 != 96)
        goto L1D; // [906] 930

        /** inline.e:814							check_result = integer( SymTab[sym][S_OBJ] )*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27630 = (object)*(((s1_ptr)_2)->base + _sym_54597);
        _2 = (object)SEQ_PTR(_27630);
        _27631 = (object)*(((s1_ptr)_2)->base + 1);
        _27630 = NOVALUE;
        if (IS_ATOM_INT(_27631))
        _check_result_54602 = 1;
        else if (IS_ATOM_DBL(_27631))
        _check_result_54602 = IS_ATOM_INT(DoubleToInt(_27631));
        else
        _check_result_54602 = 0;
        _27631 = NOVALUE;
        goto L1E; // [927] 976
L1D: 

        /** inline.e:815						elsif op = SEQUENCE_CHECK then*/
        if (_op_54588 != 97)
        goto L1F; // [934] 958

        /** inline.e:816							check_result = sequence( SymTab[sym][S_OBJ] )*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27634 = (object)*(((s1_ptr)_2)->base + _sym_54597);
        _2 = (object)SEQ_PTR(_27634);
        _27635 = (object)*(((s1_ptr)_2)->base + 1);
        _27634 = NOVALUE;
        _check_result_54602 = IS_SEQUENCE(_27635);
        _27635 = NOVALUE;
        goto L1E; // [955] 976
L1F: 

        /** inline.e:818							check_result = atom( SymTab[sym][S_OBJ] )*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27637 = (object)*(((s1_ptr)_2)->base + _sym_54597);
        _2 = (object)SEQ_PTR(_27637);
        _27638 = (object)*(((s1_ptr)_2)->base + 1);
        _27637 = NOVALUE;
        _check_result_54602 = IS_ATOM(_27638);
        _27638 = NOVALUE;
L1E: 

        /** inline.e:821						if check_result then*/
        if (_check_result_54602 == 0)
        {
            goto L20; // [980] 997
        }
        else{
        }

        /** inline.e:822							replace_code( {}, check_pc, check_pc+1 )*/
        _27640 = _check_pc_54584 + 1;
        if (_27640 > MAXINT){
            _27640 = NewDouble((eudouble)_27640);
        }
        RefDS(_21997);
        _67replace_code(_21997, _check_pc_54584, _27640);
        _27640 = NOVALUE;
        goto L21; // [994] 1007
L20: 

        /** inline.e:826							CompileErr(TYPE_CHECK_ERROR_WHEN_INLINING_LITERAL)*/
        RefDS(_21997);
        _50CompileErr(146, _21997, 0);
L21: 
        goto L22; // [1009] 1174
L1C: 

        /** inline.e:829					elsif not is_temp( sym ) then*/
        _27641 = _67is_temp(_sym_54597);
        if (IS_ATOM_INT(_27641)) {
            if (_27641 != 0){
                DeRef(_27641);
                _27641 = NOVALUE;
                goto L23; // [1018] 1167
            }
        }
        else {
            if (DBL_PTR(_27641)->dbl != 0.0){
                DeRef(_27641);
                _27641 = NOVALUE;
                goto L23; // [1018] 1167
            }
        }
        DeRef(_27641);
        _27641 = NOVALUE;

        /** inline.e:831						if (op = INTEGER_CHECK and SymTab[sym][S_VTYPE] = integer_type )*/
        _27643 = (_op_54588 == 96);
        if (_27643 == 0) {
            _27644 = 0;
            goto L24; // [1029] 1055
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27645 = (object)*(((s1_ptr)_2)->base + _sym_54597);
        _2 = (object)SEQ_PTR(_27645);
        _27646 = (object)*(((s1_ptr)_2)->base + 15);
        _27645 = NOVALUE;
        if (IS_ATOM_INT(_27646)) {
            _27647 = (_27646 == _54integer_type_46786);
        }
        else {
            _27647 = binary_op(EQUALS, _27646, _54integer_type_46786);
        }
        _27646 = NOVALUE;
        if (IS_ATOM_INT(_27647))
        _27644 = (_27647 != 0);
        else
        _27644 = DBL_PTR(_27647)->dbl != 0.0;
L24: 
        if (_27644 != 0) {
            _27648 = 1;
            goto L25; // [1055] 1095
        }
        _27649 = (_op_54588 == 97);
        if (_27649 == 0) {
            _27650 = 0;
            goto L26; // [1065] 1091
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27651 = (object)*(((s1_ptr)_2)->base + _sym_54597);
        _2 = (object)SEQ_PTR(_27651);
        _27652 = (object)*(((s1_ptr)_2)->base + 15);
        _27651 = NOVALUE;
        if (IS_ATOM_INT(_27652)) {
            _27653 = (_27652 == _54sequence_type_46784);
        }
        else {
            _27653 = binary_op(EQUALS, _27652, _54sequence_type_46784);
        }
        _27652 = NOVALUE;
        if (IS_ATOM_INT(_27653))
        _27650 = (_27653 != 0);
        else
        _27650 = DBL_PTR(_27653)->dbl != 0.0;
L26: 
        _27648 = (_27650 != 0);
L25: 
        if (_27648 != 0) {
            goto L27; // [1095] 1143
        }
        _27655 = (_op_54588 == 101);
        if (_27655 == 0) {
            DeRef(_27656);
            _27656 = 0;
            goto L28; // [1105] 1138
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27657 = (object)*(((s1_ptr)_2)->base + _sym_54597);
        _2 = (object)SEQ_PTR(_27657);
        _27658 = (object)*(((s1_ptr)_2)->base + 15);
        _27657 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _54integer_type_46786;
        ((intptr_t *)_2)[2] = _54atom_type_46782;
        _27659 = MAKE_SEQ(_1);
        _27660 = find_from(_27658, _27659, 1);
        _27658 = NOVALUE;
        DeRefDS(_27659);
        _27659 = NOVALUE;
        _27656 = (_27660 != 0);
L28: 
        if (_27656 == 0)
        {
            _27656 = NOVALUE;
            goto L29; // [1139] 1157
        }
        else{
            _27656 = NOVALUE;
        }
L27: 

        /** inline.e:834							replace_code( {}, check_pc, check_pc+1 )*/
        _27661 = _check_pc_54584 + 1;
        if (_27661 > MAXINT){
            _27661 = NewDouble((eudouble)_27661);
        }
        RefDS(_21997);
        _67replace_code(_21997, _check_pc_54584, _27661);
        _27661 = NOVALUE;
        goto L22; // [1154] 1174
L29: 

        /** inline.e:837							check_pc += 2*/
        _check_pc_54584 = _check_pc_54584 + 2;
        goto L22; // [1164] 1174
L23: 

        /** inline.e:841						check_pc += 2*/
        _check_pc_54584 = _check_pc_54584 + 2;
L22: 

        /** inline.e:843					continue*/
        goto L1A; // [1180] 847

        /** inline.e:844				case STARTLINE then*/
        case 58:

        /** inline.e:845					check_pc += 2*/
        _check_pc_54584 = _check_pc_54584 + 2;

        /** inline.e:846					continue*/
        goto L1A; // [1198] 847

        /** inline.e:848				case else*/
        default:

        /** inline.e:849					exit*/
        goto L1B; // [1208] 1218
    ;}
    /** inline.e:851		end while*/
    goto L1A; // [1215] 847
L1B: 

    /** inline.e:853		for pc = 1 to length( inline_code ) do*/
    if (IS_SEQUENCE(_67inline_code_53453)){
            _27665 = SEQ_PTR(_67inline_code_53453)->length;
    }
    else {
        _27665 = 1;
    }
    {
        object _pc_54675;
        _pc_54675 = 1;
L2A: 
        if (_pc_54675 > _27665){
            goto L2B; // [1225] 1422
        }

        /** inline.e:854			if sequence( inline_code[pc] ) then*/
        _2 = (object)SEQ_PTR(_67inline_code_53453);
        _27666 = (object)*(((s1_ptr)_2)->base + _pc_54675);
        _27667 = IS_SEQUENCE(_27666);
        _27666 = NOVALUE;
        if (_27667 == 0)
        {
            _27667 = NOVALUE;
            goto L2C; // [1243] 1413
        }
        else{
            _27667 = NOVALUE;
        }

        /** inline.e:855				integer inline_type = inline_code[pc][1]*/
        _2 = (object)SEQ_PTR(_67inline_code_53453);
        _27668 = (object)*(((s1_ptr)_2)->base + _pc_54675);
        _2 = (object)SEQ_PTR(_27668);
        _inline_type_54680 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_inline_type_54680)){
            _inline_type_54680 = (object)DBL_PTR(_inline_type_54680)->dbl;
        }
        _27668 = NOVALUE;

        /** inline.e:856				switch inline_type do*/
        _0 = _inline_type_54680;
        switch ( _0 ){ 

            /** inline.e:857					case INLINE_SUB then*/
            case 5:

            /** inline.e:858						inline_code[pc] = CurrentSub*/
            _2 = (object)SEQ_PTR(_67inline_code_53453);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67inline_code_53453 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_54675);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _36CurrentSub_21455;
            DeRef(_1);
            goto L2D; // [1281] 1412

            /** inline.e:860					case INLINE_VAR then*/
            case 6:

            /** inline.e:861						replace_var( pc )*/
            _67replace_var(_pc_54675);

            /** inline.e:862						break*/
            goto L2D; // [1294] 1412
            goto L2D; // [1296] 1412

            /** inline.e:863					case INLINE_TEMP then*/
            case 2:

            /** inline.e:864						replace_temp( pc )*/
            _67replace_temp(_pc_54675);
            goto L2D; // [1307] 1412

            /** inline.e:866					case INLINE_PARAM then*/
            case 1:

            /** inline.e:867						replace_param( pc )*/

            /** inline.e:586		inline_code[pc] = get_param_sym( pc )*/
            _0 = _replace_param_1__tmp_at1343_54691;
            _replace_param_1__tmp_at1343_54691 = _67get_param_sym(_pc_54675);
            DeRef(_0);
            Ref(_replace_param_1__tmp_at1343_54691);
            _2 = (object)SEQ_PTR(_67inline_code_53453);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67inline_code_53453 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_54675);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _replace_param_1__tmp_at1343_54691;
            DeRef(_1);

            /** inline.e:587	end procedure*/
            goto L2E; // [1329] 1332
L2E: 
            DeRef(_replace_param_1__tmp_at1343_54691);
            _replace_param_1__tmp_at1343_54691 = NOVALUE;
            goto L2D; // [1334] 1412

            /** inline.e:869					case INLINE_ADDR then*/
            case 4:

            /** inline.e:870						inline_code[pc] = inline_start + inline_code[pc][2]*/
            _2 = (object)SEQ_PTR(_67inline_code_53453);
            _27672 = (object)*(((s1_ptr)_2)->base + _pc_54675);
            _2 = (object)SEQ_PTR(_27672);
            _27673 = (object)*(((s1_ptr)_2)->base + 2);
            _27672 = NOVALUE;
            if (IS_ATOM_INT(_27673)) {
                _27674 = _67inline_start_53465 + _27673;
                if ((object)((uintptr_t)_27674 + (uintptr_t)HIGH_BITS) >= 0){
                    _27674 = NewDouble((eudouble)_27674);
                }
            }
            else {
                _27674 = binary_op(PLUS, _67inline_start_53465, _27673);
            }
            _27673 = NOVALUE;
            _2 = (object)SEQ_PTR(_67inline_code_53453);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67inline_code_53453 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_54675);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _27674;
            if( _1 != _27674 ){
                DeRef(_1);
            }
            _27674 = NOVALUE;
            goto L2D; // [1364] 1412

            /** inline.e:872					case INLINE_TARGET then*/
            case 3:

            /** inline.e:873						inline_code[pc] = inline_target*/
            _2 = (object)SEQ_PTR(_67inline_code_53453);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67inline_code_53453 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_54675);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _67inline_target_53460;
            DeRef(_1);

            /** inline.e:874						add_inline_target( pc + inline_start )*/
            _27675 = _pc_54675 + _67inline_start_53465;
            if ((object)((uintptr_t)_27675 + (uintptr_t)HIGH_BITS) >= 0){
                _27675 = NewDouble((eudouble)_27675);
            }
            _47add_inline_target(_27675);
            _27675 = NOVALUE;

            /** inline.e:875						break*/
            goto L2D; // [1393] 1412
            goto L2D; // [1395] 1412

            /** inline.e:877					case else*/
            default:

            /** inline.e:878						InternalErr( 265, {inline_type} )*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t*)_2)[1] = _inline_type_54680;
            _27676 = MAKE_SEQ(_1);
            _50InternalErr(265, _27676);
            _27676 = NOVALUE;
        ;}L2D: 
L2C: 

        /** inline.e:881		end for*/
        _pc_54675 = _pc_54675 + 1;
        goto L2A; // [1417] 1232
L2B: 
        ;
    }

    /** inline.e:883		for i = 1 to length(backpatches) do*/
    if (IS_SEQUENCE(_backpatches_54423)){
            _27677 = SEQ_PTR(_backpatches_54423)->length;
    }
    else {
        _27677 = 1;
    }
    {
        object _i_54703;
        _i_54703 = 1;
L2F: 
        if (_i_54703 > _27677){
            goto L30; // [1427] 1450
        }

        /** inline.e:884			fixup_special_op( backpatches[i] )*/
        _2 = (object)SEQ_PTR(_backpatches_54423);
        _27678 = (object)*(((s1_ptr)_2)->base + _i_54703);
        Ref(_27678);
        _67fixup_special_op(_27678);
        _27678 = NOVALUE;

        /** inline.e:885		end for*/
        _i_54703 = _i_54703 + 1;
        goto L2F; // [1445] 1434
L30: 
        ;
    }

    /** inline.e:887		epilog &= End_inline_block( EXIT_BLOCK )*/
    _27679 = _65End_inline_block(206);
    if (IS_SEQUENCE(_epilog_54430) && IS_ATOM(_27679)) {
        Ref(_27679);
        Append(&_epilog_54430, _epilog_54430, _27679);
    }
    else if (IS_ATOM(_epilog_54430) && IS_SEQUENCE(_27679)) {
    }
    else {
        Concat((object_ptr)&_epilog_54430, _epilog_54430, _27679);
    }
    DeRef(_27679);
    _27679 = NOVALUE;

    /** inline.e:889		if is_proc then*/
    if (_is_proc_54405 == 0)
    {
        goto L31; // [1464] 1474
    }
    else{
    }

    /** inline.e:890			clear_op()*/
    _47clear_op();
    goto L32; // [1471] 1597
L31: 

    /** inline.e:892			if not deferred then*/
    if (_deferred_54404 != 0)
    goto L33; // [1476] 1491

    /** inline.e:893				Push( inline_target )*/
    _47Push(_67inline_target_53460);

    /** inline.e:894				inlined_function()*/
    _47inlined_function();
L33: 

    /** inline.e:897			if final_target then*/
    if (_final_target_54529 == 0)
    {
        goto L34; // [1493] 1523
    }
    else{
    }

    /** inline.e:898				epilog &= { ASSIGN, inline_target, final_target }*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18;
    ((intptr_t*)_2)[2] = _67inline_target_53460;
    ((intptr_t*)_2)[3] = _final_target_54529;
    _27682 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_54430, _epilog_54430, _27682);
    DeRefDS(_27682);
    _27682 = NOVALUE;

    /** inline.e:899				emit_temp( final_target, NEW_REFERENCE )*/
    _47emit_temp(_final_target_54529, 1);
    goto L35; // [1520] 1596
L34: 

    /** inline.e:905				emit_temp( inline_target, NEW_REFERENCE )*/
    _47emit_temp(_67inline_target_53460, 1);

    /** inline.e:906				if not TRANSLATE then*/
    if (_36TRANSLATE_21049 != 0)
    goto L36; // [1537] 1595

    /** inline.e:907					epilog &= { ELSE, 0, PRIVATE_INIT_CHECK, inline_target }*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 23;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 30;
    ((intptr_t*)_2)[4] = _67inline_target_53460;
    _27685 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_54430, _epilog_54430, _27685);
    DeRefDS(_27685);
    _27685 = NOVALUE;

    /** inline.e:908					epilog[$-2] = length(inline_code) + length(epilog) + inline_start + 1*/
    if (IS_SEQUENCE(_epilog_54430)){
            _27687 = SEQ_PTR(_epilog_54430)->length;
    }
    else {
        _27687 = 1;
    }
    _27688 = _27687 - 2;
    _27687 = NOVALUE;
    if (IS_SEQUENCE(_67inline_code_53453)){
            _27689 = SEQ_PTR(_67inline_code_53453)->length;
    }
    else {
        _27689 = 1;
    }
    if (IS_SEQUENCE(_epilog_54430)){
            _27690 = SEQ_PTR(_epilog_54430)->length;
    }
    else {
        _27690 = 1;
    }
    _27691 = _27689 + _27690;
    if ((object)((uintptr_t)_27691 + (uintptr_t)HIGH_BITS) >= 0){
        _27691 = NewDouble((eudouble)_27691);
    }
    _27689 = NOVALUE;
    _27690 = NOVALUE;
    if (IS_ATOM_INT(_27691)) {
        _27692 = _27691 + _67inline_start_53465;
        if ((object)((uintptr_t)_27692 + (uintptr_t)HIGH_BITS) >= 0){
            _27692 = NewDouble((eudouble)_27692);
        }
    }
    else {
        _27692 = NewDouble(DBL_PTR(_27691)->dbl + (eudouble)_67inline_start_53465);
    }
    DeRef(_27691);
    _27691 = NOVALUE;
    if (IS_ATOM_INT(_27692)) {
        _27693 = _27692 + 1;
        if (_27693 > MAXINT){
            _27693 = NewDouble((eudouble)_27693);
        }
    }
    else
    _27693 = binary_op(PLUS, 1, _27692);
    DeRef(_27692);
    _27692 = NOVALUE;
    _2 = (object)SEQ_PTR(_epilog_54430);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _epilog_54430 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27688);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27693;
    if( _1 != _27693 ){
        DeRef(_1);
    }
    _27693 = NOVALUE;
L36: 
L35: 
L32: 

    /** inline.e:914		return prolog & inline_code & epilog*/
    {
        object concat_list[3];

        concat_list[0] = _epilog_54430;
        concat_list[1] = _67inline_code_53453;
        concat_list[2] = _prolog_54429;
        Concat_N((object_ptr)&_27694, concat_list, 3);
    }
    DeRef(_backpatches_54423);
    DeRefDSi(_prolog_54429);
    DeRefDS(_epilog_54430);
    _27565 = NOVALUE;
    DeRef(_27688);
    _27688 = NOVALUE;
    _27582 = NOVALUE;
    _27578 = NOVALUE;
    DeRef(_27643);
    _27643 = NOVALUE;
    DeRef(_27602);
    _27602 = NOVALUE;
    DeRef(_27655);
    _27655 = NOVALUE;
    DeRef(_27649);
    _27649 = NOVALUE;
    DeRef(_27570);
    _27570 = NOVALUE;
    DeRef(_27653);
    _27653 = NOVALUE;
    DeRef(_27573);
    _27573 = NOVALUE;
    DeRef(_27647);
    _27647 = NOVALUE;
    DeRef(_27599);
    _27599 = NOVALUE;
    return _27694;
    ;
}


void _67defer_call()
{
    object _defer_54743 = NOVALUE;
    object _27697 = NOVALUE;
    object _27696 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:918		integer defer = find( inline_sub, deferred_inline_decisions )*/
    _defer_54743 = find_from(_67inline_sub_53467, _67deferred_inline_decisions_53469, 1);

    /** inline.e:919		if defer then*/
    if (_defer_54743 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** inline.e:921			deferred_inline_calls[defer] &= CurrentSub*/
    _2 = (object)SEQ_PTR(_67deferred_inline_calls_53470);
    _27696 = (object)*(((s1_ptr)_2)->base + _defer_54743);
    if (IS_SEQUENCE(_27696) && IS_ATOM(_36CurrentSub_21455)) {
        Append(&_27697, _27696, _36CurrentSub_21455);
    }
    else if (IS_ATOM(_27696) && IS_SEQUENCE(_36CurrentSub_21455)) {
    }
    else {
        Concat((object_ptr)&_27697, _27696, _36CurrentSub_21455);
        _27696 = NOVALUE;
    }
    _27696 = NOVALUE;
    _2 = (object)SEQ_PTR(_67deferred_inline_calls_53470);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67deferred_inline_calls_53470 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _defer_54743);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27697;
    if( _1 != _27697 ){
        DeRef(_1);
    }
    _27697 = NOVALUE;
L1: 

    /** inline.e:923	end procedure*/
    return;
    ;
}


void _67emit_or_inline()
{
    object _sub_54752 = NOVALUE;
    object _code_54783 = NOVALUE;
    object _27709 = NOVALUE;
    object _27708 = NOVALUE;
    object _27706 = NOVALUE;
    object _27705 = NOVALUE;
    object _27704 = NOVALUE;
    object _27702 = NOVALUE;
    object _27701 = NOVALUE;
    object _27700 = NOVALUE;
    object _27699 = NOVALUE;
    object _27698 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:928		symtab_index sub = op_info1*/
    _sub_54752 = _47op_info1_50936;

    /** inline.e:929		inline_sub = sub*/
    _67inline_sub_53467 = _sub_54752;

    /** inline.e:931		if SymTab[sub][S_DEPRECATED] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27698 = (object)*(((s1_ptr)_2)->base + _sub_54752);
    _2 = (object)SEQ_PTR(_27698);
    _27699 = (object)*(((s1_ptr)_2)->base + 30);
    _27698 = NOVALUE;
    if (_27699 == 0) {
        _27699 = NOVALUE;
        goto L1; // [31] 60
    }
    else {
        if (!IS_ATOM_INT(_27699) && DBL_PTR(_27699)->dbl == 0.0){
            _27699 = NOVALUE;
            goto L1; // [31] 60
        }
        _27699 = NOVALUE;
    }
    _27699 = NOVALUE;

    /** inline.e:932			Warning(327, deprecated_warning_flag, { SymTab[sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27700 = (object)*(((s1_ptr)_2)->base + _sub_54752);
    _2 = (object)SEQ_PTR(_27700);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _27701 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _27701 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _27700 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_27701);
    ((intptr_t*)_2)[1] = _27701;
    _27702 = MAKE_SEQ(_1);
    _27701 = NOVALUE;
    _50Warning(327, 16384, _27702);
    _27702 = NOVALUE;
L1: 

    /** inline.e:935		if Parser_mode != PAM_NORMAL then*/
    if (_36Parser_mode_21556 == 0)
    goto L2; // [66] 85

    /** inline.e:938			emit_op( PROC )*/
    _47emit_op(27);

    /** inline.e:939			return*/
    DeRef(_code_54783);
    return;
    goto L3; // [82] 133
L2: 

    /** inline.e:941		elsif atom( SymTab[sub][S_INLINE] ) or has_forward_params(sub) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27704 = (object)*(((s1_ptr)_2)->base + _sub_54752);
    _2 = (object)SEQ_PTR(_27704);
    _27705 = (object)*(((s1_ptr)_2)->base + 29);
    _27704 = NOVALUE;
    _27706 = IS_ATOM(_27705);
    _27705 = NOVALUE;
    if (_27706 != 0) {
        goto L4; // [102] 115
    }
    _27708 = _47has_forward_params(_sub_54752);
    if (_27708 == 0) {
        DeRef(_27708);
        _27708 = NOVALUE;
        goto L5; // [111] 132
    }
    else {
        if (!IS_ATOM_INT(_27708) && DBL_PTR(_27708)->dbl == 0.0){
            DeRef(_27708);
            _27708 = NOVALUE;
            goto L5; // [111] 132
        }
        DeRef(_27708);
        _27708 = NOVALUE;
    }
    DeRef(_27708);
    _27708 = NOVALUE;
L4: 

    /** inline.e:942			defer_call()*/
    _67defer_call();

    /** inline.e:943			emit_op( PROC )*/
    _47emit_op(27);

    /** inline.e:944			return*/
    DeRef(_code_54783);
    return;
L5: 
L3: 

    /** inline.e:947		sequence code = get_inlined_code( sub, length(Code) )*/
    if (IS_SEQUENCE(_36Code_21539)){
            _27709 = SEQ_PTR(_36Code_21539)->length;
    }
    else {
        _27709 = 1;
    }
    _0 = _code_54783;
    _code_54783 = _67get_inlined_code(_sub_54752, _27709, 0);
    DeRef(_0);
    _27709 = NOVALUE;

    /** inline.e:948		emit_inline( code )*/
    RefDS(_code_54783);
    _47emit_inline(_code_54783);

    /** inline.e:949		clear_last()*/
    _47clear_last();

    /** inline.e:951	end procedure*/
    DeRefDS(_code_54783);
    return;
    ;
}


void _67inline_deferred_calls()
{
    object _sub_54797 = NOVALUE;
    object _ix_54809 = NOVALUE;
    object _calling_sub_54811 = NOVALUE;
    object _code_54833 = NOVALUE;
    object _calls_54834 = NOVALUE;
    object _is_func_54838 = NOVALUE;
    object _offset_54845 = NOVALUE;
    object _op_54856 = NOVALUE;
    object _size_54859 = NOVALUE;
    object _27771 = NOVALUE;
    object _27769 = NOVALUE;
    object _27767 = NOVALUE;
    object _27766 = NOVALUE;
    object _27765 = NOVALUE;
    object _27763 = NOVALUE;
    object _27762 = NOVALUE;
    object _27761 = NOVALUE;
    object _27760 = NOVALUE;
    object _27759 = NOVALUE;
    object _27758 = NOVALUE;
    object _27757 = NOVALUE;
    object _27756 = NOVALUE;
    object _27755 = NOVALUE;
    object _27754 = NOVALUE;
    object _27752 = NOVALUE;
    object _27751 = NOVALUE;
    object _27750 = NOVALUE;
    object _27749 = NOVALUE;
    object _27747 = NOVALUE;
    object _27746 = NOVALUE;
    object _27745 = NOVALUE;
    object _27743 = NOVALUE;
    object _27741 = NOVALUE;
    object _27739 = NOVALUE;
    object _27737 = NOVALUE;
    object _27736 = NOVALUE;
    object _27735 = NOVALUE;
    object _27734 = NOVALUE;
    object _27732 = NOVALUE;
    object _27731 = NOVALUE;
    object _27728 = NOVALUE;
    object _27726 = NOVALUE;
    object _27724 = NOVALUE;
    object _27722 = NOVALUE;
    object _27720 = NOVALUE;
    object _27719 = NOVALUE;
    object _27718 = NOVALUE;
    object _27717 = NOVALUE;
    object _27716 = NOVALUE;
    object _27715 = NOVALUE;
    object _27713 = NOVALUE;
    object _27712 = NOVALUE;
    object _27711 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:957		deferred_inlining = 1*/
    _67deferred_inlining_53463 = 1;

    /** inline.e:958		for i = 1 to length( deferred_inline_decisions ) do*/
    if (IS_SEQUENCE(_67deferred_inline_decisions_53469)){
            _27711 = SEQ_PTR(_67deferred_inline_decisions_53469)->length;
    }
    else {
        _27711 = 1;
    }
    {
        object _i_54792;
        _i_54792 = 1;
L1: 
        if (_i_54792 > _27711){
            goto L2; // [13] 506
        }

        /** inline.e:960			if length( deferred_inline_calls[i] ) then*/
        _2 = (object)SEQ_PTR(_67deferred_inline_calls_53470);
        _27712 = (object)*(((s1_ptr)_2)->base + _i_54792);
        if (IS_SEQUENCE(_27712)){
                _27713 = SEQ_PTR(_27712)->length;
        }
        else {
            _27713 = 1;
        }
        _27712 = NOVALUE;
        if (_27713 == 0)
        {
            _27713 = NOVALUE;
            goto L3; // [31] 497
        }
        else{
            _27713 = NOVALUE;
        }

        /** inline.e:962				integer sub = deferred_inline_decisions[i]*/
        _2 = (object)SEQ_PTR(_67deferred_inline_decisions_53469);
        _sub_54797 = (object)*(((s1_ptr)_2)->base + _i_54792);

        /** inline.e:963				check_inline( sub )*/
        _67check_inline(_sub_54797);

        /** inline.e:964				if atom( SymTab[sub][S_INLINE] ) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27715 = (object)*(((s1_ptr)_2)->base + _sub_54797);
        _2 = (object)SEQ_PTR(_27715);
        _27716 = (object)*(((s1_ptr)_2)->base + 29);
        _27715 = NOVALUE;
        _27717 = IS_ATOM(_27716);
        _27716 = NOVALUE;
        if (_27717 == 0)
        {
            _27717 = NOVALUE;
            goto L4; // [64] 74
        }
        else{
            _27717 = NOVALUE;
        }

        /** inline.e:965					continue*/
        goto L5; // [71] 501
L4: 

        /** inline.e:967				for cx = 1 to length( deferred_inline_calls[i] ) do*/
        _2 = (object)SEQ_PTR(_67deferred_inline_calls_53470);
        _27718 = (object)*(((s1_ptr)_2)->base + _i_54792);
        if (IS_SEQUENCE(_27718)){
                _27719 = SEQ_PTR(_27718)->length;
        }
        else {
            _27719 = 1;
        }
        _27718 = NOVALUE;
        {
            object _cx_54806;
            _cx_54806 = 1;
L6: 
            if (_cx_54806 > _27719){
                goto L7; // [85] 496
            }

            /** inline.e:968					integer ix = 1*/
            _ix_54809 = 1;

            /** inline.e:969					symtab_index calling_sub = deferred_inline_calls[i][cx]*/
            _2 = (object)SEQ_PTR(_67deferred_inline_calls_53470);
            _27720 = (object)*(((s1_ptr)_2)->base + _i_54792);
            _2 = (object)SEQ_PTR(_27720);
            _calling_sub_54811 = (object)*(((s1_ptr)_2)->base + _cx_54806);
            if (!IS_ATOM_INT(_calling_sub_54811)){
                _calling_sub_54811 = (object)DBL_PTR(_calling_sub_54811)->dbl;
            }
            _27720 = NOVALUE;

            /** inline.e:970					CurrentSub = calling_sub*/
            _36CurrentSub_21455 = _calling_sub_54811;

            /** inline.e:971					Code = SymTab[calling_sub][S_CODE]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _27722 = (object)*(((s1_ptr)_2)->base + _calling_sub_54811);
            DeRef(_36Code_21539);
            _2 = (object)SEQ_PTR(_27722);
            if (!IS_ATOM_INT(_36S_CODE_21096)){
                _36Code_21539 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21096)->dbl));
            }
            else{
                _36Code_21539 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21096);
            }
            Ref(_36Code_21539);
            _27722 = NOVALUE;

            /** inline.e:972					LineTable = SymTab[calling_sub][S_LINETAB]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _27724 = (object)*(((s1_ptr)_2)->base + _calling_sub_54811);
            DeRef(_36LineTable_21540);
            _2 = (object)SEQ_PTR(_27724);
            if (!IS_ATOM_INT(_36S_LINETAB_21119)){
                _36LineTable_21540 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21119)->dbl));
            }
            else{
                _36LineTable_21540 = (object)*(((s1_ptr)_2)->base + _36S_LINETAB_21119);
            }
            Ref(_36LineTable_21540);
            _27724 = NOVALUE;

            /** inline.e:973					SymTab[calling_sub][S_CODE] = 0*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15406 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_54811 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_36S_CODE_21096))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21096)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21096);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 0;
            DeRef(_1);
            _27726 = NOVALUE;

            /** inline.e:974					SymTab[calling_sub][S_LINETAB] = 0*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15406 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_54811 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_36S_LINETAB_21119))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21119)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21119);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 0;
            DeRef(_1);
            _27728 = NOVALUE;

            /** inline.e:975					sequence code = {}*/
            RefDS(_21997);
            DeRef(_code_54833);
            _code_54833 = _21997;

            /** inline.e:977					sequence calls = find_ops( 1, PROC )*/
            RefDS(_36Code_21539);
            _0 = _calls_54834;
            _calls_54834 = _66find_ops(1, 27, _36Code_21539);
            DeRef(_0);

            /** inline.e:978					integer is_func = SymTab[sub][S_TOKEN] != PROC */
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _27731 = (object)*(((s1_ptr)_2)->base + _sub_54797);
            _2 = (object)SEQ_PTR(_27731);
            if (!IS_ATOM_INT(_36S_TOKEN_21089)){
                _27732 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
            }
            else{
                _27732 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
            }
            _27731 = NOVALUE;
            if (IS_ATOM_INT(_27732)) {
                _is_func_54838 = (_27732 != 27);
            }
            else {
                _is_func_54838 = binary_op(NOTEQ, _27732, 27);
            }
            _27732 = NOVALUE;
            if (!IS_ATOM_INT(_is_func_54838)) {
                _1 = (object)(DBL_PTR(_is_func_54838)->dbl);
                DeRefDS(_is_func_54838);
                _is_func_54838 = _1;
            }

            /** inline.e:979					integer offset = 0*/
            _offset_54845 = 0;

            /** inline.e:980					for o = 1 to length( calls ) do*/
            if (IS_SEQUENCE(_calls_54834)){
                    _27734 = SEQ_PTR(_calls_54834)->length;
            }
            else {
                _27734 = 1;
            }
            {
                object _o_54847;
                _o_54847 = 1;
L8: 
                if (_o_54847 > _27734){
                    goto L9; // [233] 453
                }

                /** inline.e:981						if calls[o][2][2] = sub then*/
                _2 = (object)SEQ_PTR(_calls_54834);
                _27735 = (object)*(((s1_ptr)_2)->base + _o_54847);
                _2 = (object)SEQ_PTR(_27735);
                _27736 = (object)*(((s1_ptr)_2)->base + 2);
                _27735 = NOVALUE;
                _2 = (object)SEQ_PTR(_27736);
                _27737 = (object)*(((s1_ptr)_2)->base + 2);
                _27736 = NOVALUE;
                if (binary_op_a(NOTEQ, _27737, _sub_54797)){
                    _27737 = NOVALUE;
                    goto LA; // [254] 444
                }
                _27737 = NOVALUE;

                /** inline.e:982							ix = calls[o][1]*/
                _2 = (object)SEQ_PTR(_calls_54834);
                _27739 = (object)*(((s1_ptr)_2)->base + _o_54847);
                _2 = (object)SEQ_PTR(_27739);
                _ix_54809 = (object)*(((s1_ptr)_2)->base + 1);
                if (!IS_ATOM_INT(_ix_54809)){
                    _ix_54809 = (object)DBL_PTR(_ix_54809)->dbl;
                }
                _27739 = NOVALUE;

                /** inline.e:983							sequence op = calls[o][2]*/
                _2 = (object)SEQ_PTR(_calls_54834);
                _27741 = (object)*(((s1_ptr)_2)->base + _o_54847);
                DeRef(_op_54856);
                _2 = (object)SEQ_PTR(_27741);
                _op_54856 = (object)*(((s1_ptr)_2)->base + 2);
                Ref(_op_54856);
                _27741 = NOVALUE;

                /** inline.e:984							integer size = length( op ) - 1*/
                if (IS_SEQUENCE(_op_54856)){
                        _27743 = SEQ_PTR(_op_54856)->length;
                }
                else {
                    _27743 = 1;
                }
                _size_54859 = _27743 - 1;
                _27743 = NOVALUE;

                /** inline.e:985							if is_func then*/
                if (_is_func_54838 == 0)
                {
                    goto LB; // [293] 319
                }
                else{
                }

                /** inline.e:987								Push( op[$] )*/
                if (IS_SEQUENCE(_op_54856)){
                        _27745 = SEQ_PTR(_op_54856)->length;
                }
                else {
                    _27745 = 1;
                }
                _2 = (object)SEQ_PTR(_op_54856);
                _27746 = (object)*(((s1_ptr)_2)->base + _27745);
                Ref(_27746);
                _47Push(_27746);
                _27746 = NOVALUE;

                /** inline.e:988								op = remove( op, length(op) )*/
                if (IS_SEQUENCE(_op_54856)){
                        _27747 = SEQ_PTR(_op_54856)->length;
                }
                else {
                    _27747 = 1;
                }
                {
                    s1_ptr assign_space = SEQ_PTR(_op_54856);
                    int len = assign_space->length;
                    int start = (IS_ATOM_INT(_27747)) ? _27747 : (object)(DBL_PTR(_27747)->dbl);
                    int stop = (IS_ATOM_INT(_27747)) ? _27747 : (object)(DBL_PTR(_27747)->dbl);
                    if (stop > len){
                        stop = len;
                    }
                    if (start > len || start > stop || stop<1) {
                    }
                    else if (start < 2) {
                        if (stop >= len) {
                            Head( SEQ_PTR(_op_54856), start, &_op_54856 );
                        }
                        else Tail(SEQ_PTR(_op_54856), stop+1, &_op_54856);
                    }
                    else if (stop >= len){
                        Head(SEQ_PTR(_op_54856), start, &_op_54856);
                    }
                    else {
                        assign_slice_seq = &assign_space;
                        _op_54856 = Remove_elements(start, stop, (SEQ_PTR(_op_54856)->ref == 1));
                    }
                }
                _27747 = NOVALUE;
                _27747 = NOVALUE;
LB: 

                /** inline.e:992							for p = 3 to length( op ) do*/
                if (IS_SEQUENCE(_op_54856)){
                        _27749 = SEQ_PTR(_op_54856)->length;
                }
                else {
                    _27749 = 1;
                }
                {
                    object _p_54869;
                    _p_54869 = 3;
LC: 
                    if (_p_54869 > _27749){
                        goto LD; // [324] 347
                    }

                    /** inline.e:993								Push( op[p] )*/
                    _2 = (object)SEQ_PTR(_op_54856);
                    _27750 = (object)*(((s1_ptr)_2)->base + _p_54869);
                    Ref(_27750);
                    _47Push(_27750);
                    _27750 = NOVALUE;

                    /** inline.e:994							end for*/
                    _p_54869 = _p_54869 + 1;
                    goto LC; // [342] 331
LD: 
                    ;
                }

                /** inline.e:995							code = get_inlined_code( sub, ix + offset - 1, 1 )*/
                _27751 = _ix_54809 + _offset_54845;
                if ((object)((uintptr_t)_27751 + (uintptr_t)HIGH_BITS) >= 0){
                    _27751 = NewDouble((eudouble)_27751);
                }
                if (IS_ATOM_INT(_27751)) {
                    _27752 = _27751 - 1;
                    if ((object)((uintptr_t)_27752 +(uintptr_t) HIGH_BITS) >= 0){
                        _27752 = NewDouble((eudouble)_27752);
                    }
                }
                else {
                    _27752 = NewDouble(DBL_PTR(_27751)->dbl - (eudouble)1);
                }
                DeRef(_27751);
                _27751 = NOVALUE;
                _0 = _code_54833;
                _code_54833 = _67get_inlined_code(_sub_54797, _27752, 1);
                DeRef(_0);
                _27752 = NOVALUE;

                /** inline.e:996							shift:replace_code( repeat( NOP1, length(code) ), ix + offset, ix + offset + size )*/
                if (IS_SEQUENCE(_code_54833)){
                        _27754 = SEQ_PTR(_code_54833)->length;
                }
                else {
                    _27754 = 1;
                }
                _27755 = Repeat(159, _27754);
                _27754 = NOVALUE;
                _27756 = _ix_54809 + _offset_54845;
                if ((object)((uintptr_t)_27756 + (uintptr_t)HIGH_BITS) >= 0){
                    _27756 = NewDouble((eudouble)_27756);
                }
                _27757 = _ix_54809 + _offset_54845;
                if ((object)((uintptr_t)_27757 + (uintptr_t)HIGH_BITS) >= 0){
                    _27757 = NewDouble((eudouble)_27757);
                }
                if (IS_ATOM_INT(_27757)) {
                    _27758 = _27757 + _size_54859;
                    if ((object)((uintptr_t)_27758 + (uintptr_t)HIGH_BITS) >= 0){
                        _27758 = NewDouble((eudouble)_27758);
                    }
                }
                else {
                    _27758 = NewDouble(DBL_PTR(_27757)->dbl + (eudouble)_size_54859);
                }
                DeRef(_27757);
                _27757 = NOVALUE;
                _66replace_code(_27755, _27756, _27758);
                _27755 = NOVALUE;
                _27756 = NOVALUE;
                _27758 = NOVALUE;

                /** inline.e:999							Code = eu:replace( Code, code, ix + offset, ix + offset + length( code ) -1 )*/
                _27759 = _ix_54809 + _offset_54845;
                if ((object)((uintptr_t)_27759 + (uintptr_t)HIGH_BITS) >= 0){
                    _27759 = NewDouble((eudouble)_27759);
                }
                _27760 = _ix_54809 + _offset_54845;
                if ((object)((uintptr_t)_27760 + (uintptr_t)HIGH_BITS) >= 0){
                    _27760 = NewDouble((eudouble)_27760);
                }
                if (IS_SEQUENCE(_code_54833)){
                        _27761 = SEQ_PTR(_code_54833)->length;
                }
                else {
                    _27761 = 1;
                }
                if (IS_ATOM_INT(_27760)) {
                    _27762 = _27760 + _27761;
                    if ((object)((uintptr_t)_27762 + (uintptr_t)HIGH_BITS) >= 0){
                        _27762 = NewDouble((eudouble)_27762);
                    }
                }
                else {
                    _27762 = NewDouble(DBL_PTR(_27760)->dbl + (eudouble)_27761);
                }
                DeRef(_27760);
                _27760 = NOVALUE;
                _27761 = NOVALUE;
                if (IS_ATOM_INT(_27762)) {
                    _27763 = _27762 - 1;
                    if ((object)((uintptr_t)_27763 +(uintptr_t) HIGH_BITS) >= 0){
                        _27763 = NewDouble((eudouble)_27763);
                    }
                }
                else {
                    _27763 = NewDouble(DBL_PTR(_27762)->dbl - (eudouble)1);
                }
                DeRef(_27762);
                _27762 = NOVALUE;
                {
                    intptr_t p1 = _36Code_21539;
                    intptr_t p2 = _code_54833;
                    intptr_t p3 = _27759;
                    intptr_t p4 = _27763;
                    struct replace_block replace_params;
                    replace_params.copy_to   = &p1;
                    replace_params.copy_from = &p2;
                    replace_params.start     = &p3;
                    replace_params.stop      = &p4;
                    replace_params.target    = &_36Code_21539;
                    Replace( &replace_params );
                }
                DeRef(_27759);
                _27759 = NOVALUE;
                DeRef(_27763);
                _27763 = NOVALUE;

                /** inline.e:1000							offset += length(code) - size - 1*/
                if (IS_SEQUENCE(_code_54833)){
                        _27765 = SEQ_PTR(_code_54833)->length;
                }
                else {
                    _27765 = 1;
                }
                _27766 = _27765 - _size_54859;
                if ((object)((uintptr_t)_27766 +(uintptr_t) HIGH_BITS) >= 0){
                    _27766 = NewDouble((eudouble)_27766);
                }
                _27765 = NOVALUE;
                if (IS_ATOM_INT(_27766)) {
                    _27767 = _27766 - 1;
                    if ((object)((uintptr_t)_27767 +(uintptr_t) HIGH_BITS) >= 0){
                        _27767 = NewDouble((eudouble)_27767);
                    }
                }
                else {
                    _27767 = NewDouble(DBL_PTR(_27766)->dbl - (eudouble)1);
                }
                DeRef(_27766);
                _27766 = NOVALUE;
                if (IS_ATOM_INT(_27767)) {
                    _offset_54845 = _offset_54845 + _27767;
                }
                else {
                    _offset_54845 = NewDouble((eudouble)_offset_54845 + DBL_PTR(_27767)->dbl);
                }
                DeRef(_27767);
                _27767 = NOVALUE;
                if (!IS_ATOM_INT(_offset_54845)) {
                    _1 = (object)(DBL_PTR(_offset_54845)->dbl);
                    DeRefDS(_offset_54845);
                    _offset_54845 = _1;
                }
LA: 
                DeRef(_op_54856);
                _op_54856 = NOVALUE;

                /** inline.e:1003					end for*/
                _o_54847 = _o_54847 + 1;
                goto L8; // [448] 240
L9: 
                ;
            }

            /** inline.e:1004					SymTab[calling_sub][S_CODE] = Code*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15406 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_54811 + ((s1_ptr)_2)->base);
            RefDS(_36Code_21539);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_36S_CODE_21096))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21096)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21096);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _36Code_21539;
            DeRef(_1);
            _27769 = NOVALUE;

            /** inline.e:1005					SymTab[calling_sub][S_LINETAB] = LineTable*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15406 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_54811 + ((s1_ptr)_2)->base);
            RefDS(_36LineTable_21540);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_36S_LINETAB_21119))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21119)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21119);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _36LineTable_21540;
            DeRef(_1);
            _27771 = NOVALUE;
            DeRef(_code_54833);
            _code_54833 = NOVALUE;
            DeRef(_calls_54834);
            _calls_54834 = NOVALUE;

            /** inline.e:1006				end for*/
            _cx_54806 = _cx_54806 + 1;
            goto L6; // [491] 92
L7: 
            ;
        }
L3: 

        /** inline.e:1008		end for*/
L5: 
        _i_54792 = _i_54792 + 1;
        goto L1; // [501] 20
L2: 
        ;
    }

    /** inline.e:1009	end procedure*/
    _27718 = NOVALUE;
    _27712 = NOVALUE;
    return;
    ;
}



// 0xAF8FF195
