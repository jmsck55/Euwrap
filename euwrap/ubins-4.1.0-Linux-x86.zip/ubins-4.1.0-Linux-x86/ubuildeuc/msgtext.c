// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _39GetMsgText(object _MsgNum_20993, object _WithNum_20994, object _Args_20995)
{
    object _idx_20996 = NOVALUE;
    object _msgtext_20997 = NOVALUE;
    object _11966 = NOVALUE;
    object _11965 = NOVALUE;
    object _11961 = NOVALUE;
    object _11960 = NOVALUE;
    object _11958 = NOVALUE;
    object _11955 = NOVALUE;
    object _11953 = NOVALUE;
    object _11952 = NOVALUE;
    object _11951 = NOVALUE;
    object _11950 = NOVALUE;
    object _0, _1, _2;
    

    /** msgtext.e:757		integer idx = 1*/
    _idx_20996 = 1;

    /** msgtext.e:761		msgtext = get_text( MsgNum, LocalizeQual, LocalDB )*/
    Ref(_MsgNum_20993);
    RefDS(_37LocalizeQual_15425);
    RefDS(_37LocalDB_15426);
    _0 = _msgtext_20997;
    _msgtext_20997 = _40get_text(_MsgNum_20993, _37LocalizeQual_15425, _37LocalDB_15426);
    DeRef(_0);

    /** msgtext.e:764		if atom(msgtext) then*/
    _11950 = IS_ATOM(_msgtext_20997);
    if (_11950 == 0)
    {
        _11950 = NOVALUE;
        goto L1; // [25] 100
    }
    else{
        _11950 = NOVALUE;
    }

    /** msgtext.e:765			for i = 1 to length(StdErrMsgs) do*/
    _11951 = 365;
    {
        object _i_21005;
        _i_21005 = 1;
L2: 
        if (_i_21005 > 365){
            goto L3; // [35] 75
        }

        /** msgtext.e:766				if StdErrMsgs[i][1] = MsgNum then*/
        _2 = (object)SEQ_PTR(_39StdErrMsgs_20264);
        _11952 = (object)*(((s1_ptr)_2)->base + _i_21005);
        _2 = (object)SEQ_PTR(_11952);
        _11953 = (object)*(((s1_ptr)_2)->base + 1);
        _11952 = NOVALUE;
        if (binary_op_a(NOTEQ, _11953, _MsgNum_20993)){
            _11953 = NOVALUE;
            goto L4; // [54] 68
        }
        _11953 = NOVALUE;

        /** msgtext.e:767					idx = i*/
        _idx_20996 = _i_21005;

        /** msgtext.e:768					exit*/
        goto L3; // [65] 75
L4: 

        /** msgtext.e:770			end for*/
        _i_21005 = _i_21005 + 1;
        goto L2; // [70] 42
L3: 
        ;
    }

    /** msgtext.e:771			msgtext = StdErrMsgs[idx][2]*/
    _2 = (object)SEQ_PTR(_39StdErrMsgs_20264);
    _11955 = (object)*(((s1_ptr)_2)->base + _idx_20996);
    DeRef(_msgtext_20997);
    _2 = (object)SEQ_PTR(_11955);
    _msgtext_20997 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_msgtext_20997);
    _11955 = NOVALUE;

    /** msgtext.e:772			if idx = 1 then*/
    if (_idx_20996 != 1)
    goto L5; // [89] 99

    /** msgtext.e:773				Args = MsgNum*/
    Ref(_MsgNum_20993);
    DeRef(_Args_20995);
    _Args_20995 = _MsgNum_20993;
L5: 
L1: 

    /** msgtext.e:777		if atom(Args) or length(Args) != 0 then*/
    _11958 = IS_ATOM(_Args_20995);
    if (_11958 != 0) {
        goto L6; // [105] 121
    }
    if (IS_SEQUENCE(_Args_20995)){
            _11960 = SEQ_PTR(_Args_20995)->length;
    }
    else {
        _11960 = 1;
    }
    _11961 = (_11960 != 0);
    _11960 = NOVALUE;
    if (_11961 == 0)
    {
        DeRef(_11961);
        _11961 = NOVALUE;
        goto L7; // [117] 129
    }
    else{
        DeRef(_11961);
        _11961 = NOVALUE;
    }
L6: 

    /** msgtext.e:778			msgtext = format(msgtext, Args)*/
    Ref(_msgtext_20997);
    Ref(_Args_20995);
    _0 = _msgtext_20997;
    _msgtext_20997 = _14format(_msgtext_20997, _Args_20995);
    DeRef(_0);
L7: 

    /** msgtext.e:781		if WithNum != 0 then*/
    if (_WithNum_20994 == 0)
    goto L8; // [131] 152

    /** msgtext.e:782			return sprintf("<%04d>:: %s", {MsgNum, msgtext})*/
    Ref(_msgtext_20997);
    Ref(_MsgNum_20993);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _MsgNum_20993;
    ((intptr_t *)_2)[2] = _msgtext_20997;
    _11965 = MAKE_SEQ(_1);
    _11966 = EPrintf(-9999999, _11964, _11965);
    DeRefDS(_11965);
    _11965 = NOVALUE;
    DeRef(_MsgNum_20993);
    DeRef(_Args_20995);
    DeRef(_msgtext_20997);
    return _11966;
    goto L9; // [149] 159
L8: 

    /** msgtext.e:784			return msgtext*/
    DeRef(_MsgNum_20993);
    DeRef(_Args_20995);
    DeRef(_11966);
    _11966 = NOVALUE;
    return _msgtext_20997;
L9: 
    ;
}


void _39ShowMsg(object _Cons_21030, object _Msg_21031, object _Args_21032, object _NL_21033)
{
    object _11973 = NOVALUE;
    object _11972 = NOVALUE;
    object _11970 = NOVALUE;
    object _11968 = NOVALUE;
    object _11967 = NOVALUE;
    object _0, _1, _2;
    

    /** msgtext.e:790		if atom(Msg) then*/
    _11967 = 1;
    if (_11967 == 0)
    {
        _11967 = NOVALUE;
        goto L1; // [10] 25
    }
    else{
        _11967 = NOVALUE;
    }

    /** msgtext.e:791			Msg = GetMsgText(floor(Msg), 0)*/
    _11968 = e_floor(_Msg_21031);
    RefDS(_5);
    _Msg_21031 = _39GetMsgText(_11968, 0, _5);
    _11968 = NOVALUE;
L1: 

    /** msgtext.e:794		if atom(Args) or length(Args) != 0 then*/
    _11970 = IS_ATOM(_Args_21032);
    if (_11970 != 0) {
        goto L2; // [30] 46
    }
    if (IS_SEQUENCE(_Args_21032)){
            _11972 = SEQ_PTR(_Args_21032)->length;
    }
    else {
        _11972 = 1;
    }
    _11973 = (_11972 != 0);
    _11972 = NOVALUE;
    if (_11973 == 0)
    {
        DeRef(_11973);
        _11973 = NOVALUE;
        goto L3; // [42] 54
    }
    else{
        DeRef(_11973);
        _11973 = NOVALUE;
    }
L2: 

    /** msgtext.e:795			Msg = format(Msg, Args)*/
    Ref(_Msg_21031);
    Ref(_Args_21032);
    _0 = _Msg_21031;
    _Msg_21031 = _14format(_Msg_21031, _Args_21032);
    DeRef(_0);
L3: 

    /** msgtext.e:798		puts(Cons, Msg)*/
    EPuts(_Cons_21030, _Msg_21031); // DJP 

    /** msgtext.e:800		if NL then*/
    if (_NL_21033 == 0)
    {
        goto L4; // [61] 70
    }
    else{
    }

    /** msgtext.e:801			puts(Cons, '\n')*/
    EPuts(_Cons_21030, 10); // DJP 
L4: 

    /** msgtext.e:804	end procedure*/
    DeRef(_Msg_21031);
    DeRef(_Args_21032);
    return;
    ;
}



// 0x1174A877
