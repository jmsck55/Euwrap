// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _43fatal(object _errcode_16854, object _msg_16855, object _routine_name_16856, object _parms_16857)
{
    object _9581 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:231		vLastErrors = append(vLastErrors, {errcode, msg, routine_name, parms})*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _errcode_16854;
    RefDS(_msg_16855);
    ((intptr_t*)_2)[2] = _msg_16855;
    RefDS(_routine_name_16856);
    ((intptr_t*)_2)[3] = _routine_name_16856;
    RefDS(_parms_16857);
    ((intptr_t*)_2)[4] = _parms_16857;
    _9581 = MAKE_SEQ(_1);
    RefDS(_9581);
    Append(&_43vLastErrors_16851, _43vLastErrors_16851, _9581);
    DeRefDS(_9581);
    _9581 = NOVALUE;

    /** eds.e:232		if db_fatal_id >= 0 then*/

    /** eds.e:235	end procedure*/
    DeRefDSi(_msg_16855);
    DeRefDSi(_routine_name_16856);
    DeRefDS(_parms_16857);
    return;
    ;
}


object _43get4()
{
    object _9597 = NOVALUE;
    object _9596 = NOVALUE;
    object _9595 = NOVALUE;
    object _9594 = NOVALUE;
    object _9593 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:250		poke(mem0, getc(current_db))*/
    if (_43current_db_16827 != last_r_file_no) {
        last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
        last_r_file_no = _43current_db_16827;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _9593 = getc((FILE*)xstdin);
        }
        else{
            _9593 = getc(last_r_file_ptr);
        }
    }
    else{
        _9593 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_43mem0_16869)){
        poke_addr = (uint8_t *)_43mem0_16869;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_43mem0_16869)->dbl);
    }
    *poke_addr = (uint8_t)_9593;
    _9593 = NOVALUE;

    /** eds.e:251		poke(mem1, getc(current_db))*/
    if (_43current_db_16827 != last_r_file_no) {
        last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
        last_r_file_no = _43current_db_16827;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _9594 = getc((FILE*)xstdin);
        }
        else{
            _9594 = getc(last_r_file_ptr);
        }
    }
    else{
        _9594 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_43mem1_16870)){
        poke_addr = (uint8_t *)_43mem1_16870;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_43mem1_16870)->dbl);
    }
    *poke_addr = (uint8_t)_9594;
    _9594 = NOVALUE;

    /** eds.e:252		poke(mem2, getc(current_db))*/
    if (_43current_db_16827 != last_r_file_no) {
        last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
        last_r_file_no = _43current_db_16827;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _9595 = getc((FILE*)xstdin);
        }
        else{
            _9595 = getc(last_r_file_ptr);
        }
    }
    else{
        _9595 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_43mem2_16871)){
        poke_addr = (uint8_t *)_43mem2_16871;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_43mem2_16871)->dbl);
    }
    *poke_addr = (uint8_t)_9595;
    _9595 = NOVALUE;

    /** eds.e:253		poke(mem3, getc(current_db))*/
    if (_43current_db_16827 != last_r_file_no) {
        last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
        last_r_file_no = _43current_db_16827;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _9596 = getc((FILE*)xstdin);
        }
        else{
            _9596 = getc(last_r_file_ptr);
        }
    }
    else{
        _9596 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_43mem3_16872)){
        poke_addr = (uint8_t *)_43mem3_16872;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_43mem3_16872)->dbl);
    }
    *poke_addr = (uint8_t)_9596;
    _9596 = NOVALUE;

    /** eds.e:254		return peek4u(mem0)*/
    if (IS_ATOM_INT(_43mem0_16869)) {
        _9597 = (object)*(uint32_t *)_43mem0_16869;
        if ((uintptr_t)_9597 > (uintptr_t)MAXINT){
            _9597 = NewDouble((eudouble)(uintptr_t)_9597);
        }
    }
    else {
        _9597 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_43mem0_16869)->dbl);
        if ((uintptr_t)_9597 > (uintptr_t)MAXINT){
            _9597 = NewDouble((eudouble)(uintptr_t)_9597);
        }
    }
    return _9597;
    ;
}


object _43get_string()
{
    object _where_inlined_where_at_31_16897 = NOVALUE;
    object _s_16886 = NOVALUE;
    object _c_16887 = NOVALUE;
    object _i_16888 = NOVALUE;
    object _9610 = NOVALUE;
    object _9607 = NOVALUE;
    object _9605 = NOVALUE;
    object _9603 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:263		s = repeat(0, 256)*/
    DeRefi(_s_16886);
    _s_16886 = Repeat(0, 256);

    /** eds.e:264		i = 0*/
    _i_16888 = 0;

    /** eds.e:265		while c with entry do*/
    goto L1; // [14] 89
L2: 
    if (_c_16887 == 0)
    {
        goto L3; // [19] 101
    }
    else{
    }

    /** eds.e:266			if c = -1 then*/
    if (_c_16887 != -1)
    goto L4; // [24] 54

    /** eds.e:267				fatal(MISSING_END, "string is missing 0 terminator", "get_string", {io:where(current_db)})*/

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_31_16897);
    _where_inlined_where_at_31_16897 = machine(20, _43current_db_16827);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_31_16897);
    ((intptr_t*)_2)[1] = _where_inlined_where_at_31_16897;
    _9603 = MAKE_SEQ(_1);
    RefDS(_9601);
    RefDS(_9602);
    _43fatal(900, _9601, _9602, _9603);
    _9603 = NOVALUE;

    /** eds.e:268				exit*/
    goto L3; // [51] 101
L4: 

    /** eds.e:270			i += 1*/
    _i_16888 = _i_16888 + 1;

    /** eds.e:271			if i > length(s) then*/
    if (IS_SEQUENCE(_s_16886)){
            _9605 = SEQ_PTR(_s_16886)->length;
    }
    else {
        _9605 = 1;
    }
    if (_i_16888 <= _9605)
    goto L5; // [65] 80

    /** eds.e:272				s &= repeat(0, 256)*/
    _9607 = Repeat(0, 256);
    Concat((object_ptr)&_s_16886, _s_16886, _9607);
    DeRefDS(_9607);
    _9607 = NOVALUE;
L5: 

    /** eds.e:274			s[i] = c*/
    _2 = (object)SEQ_PTR(_s_16886);
    _2 = (object)(((s1_ptr)_2)->base + _i_16888);
    *(intptr_t *)_2 = _c_16887;

    /** eds.e:275		  entry*/
L1: 

    /** eds.e:276			c = getc(current_db)*/
    if (_43current_db_16827 != last_r_file_no) {
        last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
        last_r_file_no = _43current_db_16827;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_16887 = getc((FILE*)xstdin);
        }
        else{
            _c_16887 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_16887 = getc(last_r_file_ptr);
    }

    /** eds.e:277		end while*/
    goto L2; // [98] 17
L3: 

    /** eds.e:278		return s[1..i]*/
    rhs_slice_target = (object_ptr)&_9610;
    RHS_Slice(_s_16886, 1, _i_16888);
    DeRefDSi(_s_16886);
    return _9610;
    ;
}


object _43equal_string(object _target_16909)
{
    object _c_16910 = NOVALUE;
    object _i_16911 = NOVALUE;
    object _where_inlined_where_at_27_16917 = NOVALUE;
    object _9621 = NOVALUE;
    object _9620 = NOVALUE;
    object _9617 = NOVALUE;
    object _9615 = NOVALUE;
    object _9613 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:286		i = 0*/
    _i_16911 = 0;

    /** eds.e:287		while c with entry do*/
    goto L1; // [10] 94
L2: 
    if (_c_16910 == 0)
    {
        goto L3; // [15] 106
    }
    else{
    }

    /** eds.e:288			if c = -1 then*/
    if (_c_16910 != -1)
    goto L4; // [20] 52

    /** eds.e:289				fatal(MISSING_END, "string is missing 0 terminator", "equal_string", {io:where(current_db)})*/

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_27_16917);
    _where_inlined_where_at_27_16917 = machine(20, _43current_db_16827);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_27_16917);
    ((intptr_t*)_2)[1] = _where_inlined_where_at_27_16917;
    _9613 = MAKE_SEQ(_1);
    RefDS(_9601);
    RefDS(_9612);
    _43fatal(900, _9601, _9612, _9613);
    _9613 = NOVALUE;

    /** eds.e:290				return DB_FATAL_FAIL*/
    DeRefDS(_target_16909);
    return -404;
L4: 

    /** eds.e:292			i += 1*/
    _i_16911 = _i_16911 + 1;

    /** eds.e:293			if i > length(target) then*/
    if (IS_SEQUENCE(_target_16909)){
            _9615 = SEQ_PTR(_target_16909)->length;
    }
    else {
        _9615 = 1;
    }
    if (_i_16911 <= _9615)
    goto L5; // [63] 74

    /** eds.e:294				return 0*/
    DeRefDS(_target_16909);
    return 0;
L5: 

    /** eds.e:296			if target[i] != c then*/
    _2 = (object)SEQ_PTR(_target_16909);
    _9617 = (object)*(((s1_ptr)_2)->base + _i_16911);
    if (binary_op_a(EQUALS, _9617, _c_16910)){
        _9617 = NOVALUE;
        goto L6; // [80] 91
    }
    _9617 = NOVALUE;

    /** eds.e:297				return 0*/
    DeRefDS(_target_16909);
    return 0;
L6: 

    /** eds.e:299		  entry*/
L1: 

    /** eds.e:300			c = getc(current_db)*/
    if (_43current_db_16827 != last_r_file_no) {
        last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
        last_r_file_no = _43current_db_16827;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_16910 = getc((FILE*)xstdin);
        }
        else{
            _c_16910 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_16910 = getc(last_r_file_ptr);
    }

    /** eds.e:301		end while*/
    goto L2; // [103] 13
L3: 

    /** eds.e:302		return (i = length(target))*/
    if (IS_SEQUENCE(_target_16909)){
            _9620 = SEQ_PTR(_target_16909)->length;
    }
    else {
        _9620 = 1;
    }
    _9621 = (_i_16911 == _9620);
    _9620 = NOVALUE;
    DeRefDS(_target_16909);
    return _9621;
    ;
}


object _43decompress(object _c_16968)
{
    object _s_16969 = NOVALUE;
    object _len_16970 = NOVALUE;
    object _float32_to_atom_inlined_float32_to_atom_at_176_17006 = NOVALUE;
    object _ieee32_inlined_float32_to_atom_at_173_17005 = NOVALUE;
    object _float64_to_atom_inlined_float64_to_atom_at_251_17019 = NOVALUE;
    object _ieee64_inlined_float64_to_atom_at_248_17018 = NOVALUE;
    object _9690 = NOVALUE;
    object _9689 = NOVALUE;
    object _9688 = NOVALUE;
    object _9685 = NOVALUE;
    object _9680 = NOVALUE;
    object _9679 = NOVALUE;
    object _9678 = NOVALUE;
    object _9677 = NOVALUE;
    object _9676 = NOVALUE;
    object _9675 = NOVALUE;
    object _9674 = NOVALUE;
    object _9673 = NOVALUE;
    object _9672 = NOVALUE;
    object _9671 = NOVALUE;
    object _9670 = NOVALUE;
    object _9669 = NOVALUE;
    object _9668 = NOVALUE;
    object _9667 = NOVALUE;
    object _9666 = NOVALUE;
    object _9665 = NOVALUE;
    object _9664 = NOVALUE;
    object _9663 = NOVALUE;
    object _9662 = NOVALUE;
    object _9661 = NOVALUE;
    object _9659 = NOVALUE;
    object _9658 = NOVALUE;
    object _9657 = NOVALUE;
    object _9656 = NOVALUE;
    object _9655 = NOVALUE;
    object _9654 = NOVALUE;
    object _9653 = NOVALUE;
    object _9652 = NOVALUE;
    object _9651 = NOVALUE;
    object _9648 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:332		if c = 0 then*/
    if (_c_16968 != 0)
    goto L1; // [5] 34

    /** eds.e:333			c = getc(current_db)*/
    if (_43current_db_16827 != last_r_file_no) {
        last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
        last_r_file_no = _43current_db_16827;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_16968 = getc((FILE*)xstdin);
        }
        else{
            _c_16968 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_16968 = getc(last_r_file_ptr);
    }

    /** eds.e:334			if c < I2B then*/
    if (_c_16968 >= 249)
    goto L2; // [18] 33

    /** eds.e:335				return c + MIN1B*/
    _9648 = _c_16968 + -9;
    DeRef(_s_16969);
    return _9648;
L2: 
L1: 

    /** eds.e:339		switch c with fallthru do*/
    _0 = _c_16968;
    switch ( _0 ){ 

        /** eds.e:340			case I2B then*/
        case 249:

        /** eds.e:341				return getc(current_db) +*/
        if (_43current_db_16827 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
            last_r_file_no = _43current_db_16827;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9651 = getc((FILE*)xstdin);
            }
            else{
                _9651 = getc(last_r_file_ptr);
            }
        }
        else{
            _9651 = getc(last_r_file_ptr);
        }
        if (_43current_db_16827 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
            last_r_file_no = _43current_db_16827;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9652 = getc((FILE*)xstdin);
            }
            else{
                _9652 = getc(last_r_file_ptr);
            }
        }
        else{
            _9652 = getc(last_r_file_ptr);
        }
        _9653 = 256 * _9652;
        _9652 = NOVALUE;
        _9654 = _9651 + _9653;
        _9651 = NOVALUE;
        _9653 = NOVALUE;
        _9655 = _9654 + _43MIN2B_16948;
        if ((object)((uintptr_t)_9655 + (uintptr_t)HIGH_BITS) >= 0){
            _9655 = NewDouble((eudouble)_9655);
        }
        _9654 = NOVALUE;
        DeRef(_s_16969);
        DeRef(_9648);
        _9648 = NOVALUE;
        return _9655;

        /** eds.e:345			case I3B then*/
        case 250:

        /** eds.e:346				return getc(current_db) +*/
        if (_43current_db_16827 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
            last_r_file_no = _43current_db_16827;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9656 = getc((FILE*)xstdin);
            }
            else{
                _9656 = getc(last_r_file_ptr);
            }
        }
        else{
            _9656 = getc(last_r_file_ptr);
        }
        if (_43current_db_16827 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
            last_r_file_no = _43current_db_16827;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9657 = getc((FILE*)xstdin);
            }
            else{
                _9657 = getc(last_r_file_ptr);
            }
        }
        else{
            _9657 = getc(last_r_file_ptr);
        }
        _9658 = 256 * _9657;
        _9657 = NOVALUE;
        _9659 = _9656 + _9658;
        _9656 = NOVALUE;
        _9658 = NOVALUE;
        if (_43current_db_16827 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
            last_r_file_no = _43current_db_16827;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9661 = getc((FILE*)xstdin);
            }
            else{
                _9661 = getc(last_r_file_ptr);
            }
        }
        else{
            _9661 = getc(last_r_file_ptr);
        }
        _9662 = 65536 * _9661;
        _9661 = NOVALUE;
        _9663 = _9659 + _9662;
        _9659 = NOVALUE;
        _9662 = NOVALUE;
        _9664 = _9663 + _43MIN3B_16955;
        if ((object)((uintptr_t)_9664 + (uintptr_t)HIGH_BITS) >= 0){
            _9664 = NewDouble((eudouble)_9664);
        }
        _9663 = NOVALUE;
        DeRef(_s_16969);
        DeRef(_9648);
        _9648 = NOVALUE;
        DeRef(_9655);
        _9655 = NOVALUE;
        return _9664;

        /** eds.e:351			case I4B then*/
        case 251:

        /** eds.e:352				return get4() + MIN4B*/
        _9665 = _43get4();
        if (IS_ATOM_INT(_9665) && IS_ATOM_INT(_43MIN4B_16962)) {
            _9666 = _9665 + _43MIN4B_16962;
            if ((object)((uintptr_t)_9666 + (uintptr_t)HIGH_BITS) >= 0){
                _9666 = NewDouble((eudouble)_9666);
            }
        }
        else {
            _9666 = binary_op(PLUS, _9665, _43MIN4B_16962);
        }
        DeRef(_9665);
        _9665 = NOVALUE;
        DeRef(_s_16969);
        DeRef(_9648);
        _9648 = NOVALUE;
        DeRef(_9655);
        _9655 = NOVALUE;
        DeRef(_9664);
        _9664 = NOVALUE;
        return _9666;

        /** eds.e:354			case F4B then*/
        case 252:

        /** eds.e:355				return convert:float32_to_atom({getc(current_db), getc(current_db),*/
        if (_43current_db_16827 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
            last_r_file_no = _43current_db_16827;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9667 = getc((FILE*)xstdin);
            }
            else{
                _9667 = getc(last_r_file_ptr);
            }
        }
        else{
            _9667 = getc(last_r_file_ptr);
        }
        if (_43current_db_16827 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
            last_r_file_no = _43current_db_16827;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9668 = getc((FILE*)xstdin);
            }
            else{
                _9668 = getc(last_r_file_ptr);
            }
        }
        else{
            _9668 = getc(last_r_file_ptr);
        }
        if (_43current_db_16827 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
            last_r_file_no = _43current_db_16827;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9669 = getc((FILE*)xstdin);
            }
            else{
                _9669 = getc(last_r_file_ptr);
            }
        }
        else{
            _9669 = getc(last_r_file_ptr);
        }
        if (_43current_db_16827 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
            last_r_file_no = _43current_db_16827;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9670 = getc((FILE*)xstdin);
            }
            else{
                _9670 = getc(last_r_file_ptr);
            }
        }
        else{
            _9670 = getc(last_r_file_ptr);
        }
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _9667;
        ((intptr_t*)_2)[2] = _9668;
        ((intptr_t*)_2)[3] = _9669;
        ((intptr_t*)_2)[4] = _9670;
        _9671 = MAKE_SEQ(_1);
        _9670 = NOVALUE;
        _9669 = NOVALUE;
        _9668 = NOVALUE;
        _9667 = NOVALUE;
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_17005);
        _ieee32_inlined_float32_to_atom_at_173_17005 = _9671;
        _9671 = NOVALUE;

        /** convert.e:374		return machine_func(M_F32_TO_A, ieee32)*/
        DeRef(_float32_to_atom_inlined_float32_to_atom_at_176_17006);
        _float32_to_atom_inlined_float32_to_atom_at_176_17006 = machine(49, _ieee32_inlined_float32_to_atom_at_173_17005);
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_17005);
        _ieee32_inlined_float32_to_atom_at_173_17005 = NOVALUE;
        DeRef(_s_16969);
        DeRef(_9666);
        _9666 = NOVALUE;
        DeRef(_9648);
        _9648 = NOVALUE;
        DeRef(_9655);
        _9655 = NOVALUE;
        DeRef(_9664);
        _9664 = NOVALUE;
        return _float32_to_atom_inlined_float32_to_atom_at_176_17006;

        /** eds.e:358			case F8B then*/
        case 253:

        /** eds.e:359				return convert:float64_to_atom({getc(current_db), getc(current_db),*/
        if (_43current_db_16827 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
            last_r_file_no = _43current_db_16827;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9672 = getc((FILE*)xstdin);
            }
            else{
                _9672 = getc(last_r_file_ptr);
            }
        }
        else{
            _9672 = getc(last_r_file_ptr);
        }
        if (_43current_db_16827 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
            last_r_file_no = _43current_db_16827;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9673 = getc((FILE*)xstdin);
            }
            else{
                _9673 = getc(last_r_file_ptr);
            }
        }
        else{
            _9673 = getc(last_r_file_ptr);
        }
        if (_43current_db_16827 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
            last_r_file_no = _43current_db_16827;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9674 = getc((FILE*)xstdin);
            }
            else{
                _9674 = getc(last_r_file_ptr);
            }
        }
        else{
            _9674 = getc(last_r_file_ptr);
        }
        if (_43current_db_16827 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
            last_r_file_no = _43current_db_16827;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9675 = getc((FILE*)xstdin);
            }
            else{
                _9675 = getc(last_r_file_ptr);
            }
        }
        else{
            _9675 = getc(last_r_file_ptr);
        }
        if (_43current_db_16827 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
            last_r_file_no = _43current_db_16827;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9676 = getc((FILE*)xstdin);
            }
            else{
                _9676 = getc(last_r_file_ptr);
            }
        }
        else{
            _9676 = getc(last_r_file_ptr);
        }
        if (_43current_db_16827 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
            last_r_file_no = _43current_db_16827;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9677 = getc((FILE*)xstdin);
            }
            else{
                _9677 = getc(last_r_file_ptr);
            }
        }
        else{
            _9677 = getc(last_r_file_ptr);
        }
        if (_43current_db_16827 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
            last_r_file_no = _43current_db_16827;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9678 = getc((FILE*)xstdin);
            }
            else{
                _9678 = getc(last_r_file_ptr);
            }
        }
        else{
            _9678 = getc(last_r_file_ptr);
        }
        if (_43current_db_16827 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
            last_r_file_no = _43current_db_16827;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9679 = getc((FILE*)xstdin);
            }
            else{
                _9679 = getc(last_r_file_ptr);
            }
        }
        else{
            _9679 = getc(last_r_file_ptr);
        }
        _1 = NewS1(8);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _9672;
        ((intptr_t*)_2)[2] = _9673;
        ((intptr_t*)_2)[3] = _9674;
        ((intptr_t*)_2)[4] = _9675;
        ((intptr_t*)_2)[5] = _9676;
        ((intptr_t*)_2)[6] = _9677;
        ((intptr_t*)_2)[7] = _9678;
        ((intptr_t*)_2)[8] = _9679;
        _9680 = MAKE_SEQ(_1);
        _9679 = NOVALUE;
        _9678 = NOVALUE;
        _9677 = NOVALUE;
        _9676 = NOVALUE;
        _9675 = NOVALUE;
        _9674 = NOVALUE;
        _9673 = NOVALUE;
        _9672 = NOVALUE;
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_17018);
        _ieee64_inlined_float64_to_atom_at_248_17018 = _9680;
        _9680 = NOVALUE;

        /** convert.e:343		return machine_func(M_F64_TO_A, ieee64)*/
        DeRef(_float64_to_atom_inlined_float64_to_atom_at_251_17019);
        _float64_to_atom_inlined_float64_to_atom_at_251_17019 = machine(47, _ieee64_inlined_float64_to_atom_at_248_17018);
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_17018);
        _ieee64_inlined_float64_to_atom_at_248_17018 = NOVALUE;
        DeRef(_s_16969);
        DeRef(_9666);
        _9666 = NOVALUE;
        DeRef(_9648);
        _9648 = NOVALUE;
        DeRef(_9655);
        _9655 = NOVALUE;
        DeRef(_9664);
        _9664 = NOVALUE;
        return _float64_to_atom_inlined_float64_to_atom_at_251_17019;

        /** eds.e:364			case else*/
        default:

        /** eds.e:366				if c = S1B then*/
        if (_c_16968 != 254)
        goto L3; // [273] 287

        /** eds.e:367					len = getc(current_db)*/
        if (_43current_db_16827 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
            last_r_file_no = _43current_db_16827;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _len_16970 = getc((FILE*)xstdin);
            }
            else{
                _len_16970 = getc(last_r_file_ptr);
            }
        }
        else{
            _len_16970 = getc(last_r_file_ptr);
        }
        goto L4; // [284] 295
L3: 

        /** eds.e:369					len = get4()*/
        _len_16970 = _43get4();
        if (!IS_ATOM_INT(_len_16970)) {
            _1 = (object)(DBL_PTR(_len_16970)->dbl);
            DeRefDS(_len_16970);
            _len_16970 = _1;
        }
L4: 

        /** eds.e:371				s = repeat(0, len)*/
        DeRef(_s_16969);
        _s_16969 = Repeat(0, _len_16970);

        /** eds.e:372				for i = 1 to len do*/
        _9685 = _len_16970;
        {
            object _i_17028;
            _i_17028 = 1;
L5: 
            if (_i_17028 > _9685){
                goto L6; // [308] 362
            }

            /** eds.e:374					c = getc(current_db)*/
            if (_43current_db_16827 != last_r_file_no) {
                last_r_file_ptr = which_file(_43current_db_16827, EF_READ);
                last_r_file_no = _43current_db_16827;
            }
            if (last_r_file_ptr == xstdin) {
                if (in_from_keyb) {
                    _c_16968 = getc((FILE*)xstdin);
                }
                else{
                    _c_16968 = getc(last_r_file_ptr);
                }
            }
            else{
                _c_16968 = getc(last_r_file_ptr);
            }

            /** eds.e:375					if c < I2B then*/
            if (_c_16968 >= 249)
            goto L7; // [324] 341

            /** eds.e:376						s[i] = c + MIN1B*/
            _9688 = _c_16968 + -9;
            _2 = (object)SEQ_PTR(_s_16969);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _s_16969 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _i_17028);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _9688;
            if( _1 != _9688 ){
                DeRef(_1);
            }
            _9688 = NOVALUE;
            goto L8; // [338] 355
L7: 

            /** eds.e:378						s[i] = decompress(c)*/
            DeRef(_9689);
            _9689 = _c_16968;
            _9690 = _43decompress(_9689);
            _9689 = NOVALUE;
            _2 = (object)SEQ_PTR(_s_16969);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _s_16969 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _i_17028);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _9690;
            if( _1 != _9690 ){
                DeRef(_1);
            }
            _9690 = NOVALUE;
L8: 

            /** eds.e:380				end for*/
            _i_17028 = _i_17028 + 1;
            goto L5; // [357] 315
L6: 
            ;
        }

        /** eds.e:381				return s*/
        DeRef(_9666);
        _9666 = NOVALUE;
        DeRef(_9648);
        _9648 = NOVALUE;
        DeRef(_9655);
        _9655 = NOVALUE;
        DeRef(_9664);
        _9664 = NOVALUE;
        return _s_16969;
    ;}    ;
}


void _43save_keys()
{
    object _k_17754 = NOVALUE;
    object _10018 = NOVALUE;
    object _10014 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:926		if caching_option = 1 then*/

    /** eds.e:927			if current_table_pos > 0 then*/
    if (binary_op_a(LESSEQ, _43current_table_pos_16828, 0)){
        goto L1; // [13] 81
    }

    /** eds.e:928				k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_43current_table_pos_16828);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_16827;
    ((intptr_t *)_2)[2] = _43current_table_pos_16828;
    _10014 = MAKE_SEQ(_1);
    _k_17754 = find_from(_10014, _43cache_index_16836, 1);
    DeRefDS(_10014);
    _10014 = NOVALUE;

    /** eds.e:929				if k != 0 then*/
    if (_k_17754 == 0)
    goto L2; // [36] 53

    /** eds.e:930					key_cache[k] = key_pointers*/
    RefDS(_43key_pointers_16834);
    _2 = (object)SEQ_PTR(_43key_cache_16835);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43key_cache_16835 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _k_17754);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _43key_pointers_16834;
    DeRef(_1);
    goto L3; // [50] 80
L2: 

    /** eds.e:932					key_cache = append(key_cache, key_pointers)*/
    RefDS(_43key_pointers_16834);
    Append(&_43key_cache_16835, _43key_cache_16835, _43key_pointers_16834);

    /** eds.e:933					cache_index = append(cache_index, {current_db, current_table_pos})*/
    Ref(_43current_table_pos_16828);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_16827;
    ((intptr_t *)_2)[2] = _43current_table_pos_16828;
    _10018 = MAKE_SEQ(_1);
    RefDS(_10018);
    Append(&_43cache_index_16836, _43cache_index_16836, _10018);
    DeRefDS(_10018);
    _10018 = NOVALUE;
L3: 
L1: 

    /** eds.e:937	end procedure*/
    return;
    ;
}


object _43db_open(object _path_17936, object _lock_method_17937)
{
    object _db_17938 = NOVALUE;
    object _magic_17939 = NOVALUE;
    object _lock_file_1__tmp_at129_17964 = NOVALUE;
    object _lock_file_inlined_lock_file_at_129_17963 = NOVALUE;
    object _lock_file_1__tmp_at169_17971 = NOVALUE;
    object _lock_file_inlined_lock_file_at_169_17970 = NOVALUE;
    object _10129 = NOVALUE;
    object _10127 = NOVALUE;
    object _10125 = NOVALUE;
    object _10123 = NOVALUE;
    object _10122 = NOVALUE;
    object _10120 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1273		db = find(path, Known_Aliases)*/
    _db_17938 = find_from(_path_17936, _43Known_Aliases_16848, 1);

    /** eds.e:1274		if db then*/
    if (_db_17938 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** eds.e:1276			path = Alias_Details[db][1]*/
    _2 = (object)SEQ_PTR(_43Alias_Details_16849);
    _10120 = (object)*(((s1_ptr)_2)->base + _db_17938);
    DeRefDS(_path_17936);
    _2 = (object)SEQ_PTR(_10120);
    _path_17936 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_path_17936);
    _10120 = NOVALUE;

    /** eds.e:1277			lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (object)SEQ_PTR(_43Alias_Details_16849);
    _10122 = (object)*(((s1_ptr)_2)->base + _db_17938);
    _2 = (object)SEQ_PTR(_10122);
    _10123 = (object)*(((s1_ptr)_2)->base + 2);
    _10122 = NOVALUE;
    _2 = (object)SEQ_PTR(_10123);
    _lock_method_17937 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_17937)){
        _lock_method_17937 = (object)DBL_PTR(_lock_method_17937)->dbl;
    }
    _10123 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** eds.e:1279			path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_17936);
    RefDS(_10072);
    _10125 = _17defaultext(_path_17936, _10072);
    _0 = _path_17936;
    _path_17936 = _17canonical_path(_10125, 0, 0);
    DeRefDS(_0);
    _10125 = NOVALUE;
L2: 

    /** eds.e:1282		if lock_method = DB_LOCK_NO or*/
    _10127 = (_lock_method_17937 == 0);
    if (_10127 != 0) {
        goto L3; // [76] 89
    }
    _10129 = (_lock_method_17937 == 2);
    if (_10129 == 0)
    {
        DeRef(_10129);
        _10129 = NOVALUE;
        goto L4; // [85] 99
    }
    else{
        DeRef(_10129);
        _10129 = NOVALUE;
    }
L3: 

    /** eds.e:1285			db = open(path, "ub")*/
    _db_17938 = EOpen(_path_17936, _10099, 0);
    goto L5; // [96] 107
L4: 

    /** eds.e:1288			db = open(path, "rb")*/
    _db_17938 = EOpen(_path_17936, _10093, 0);
L5: 

    /** eds.e:1291	ifdef WINDOWS then*/

    /** eds.e:1298		if db = -1 then*/
    if (_db_17938 != -1)
    goto L6; // [111] 122

    /** eds.e:1299			return DB_OPEN_FAIL*/
    DeRefDS(_path_17936);
    DeRef(_10127);
    _10127 = NOVALUE;
    return -1;
L6: 

    /** eds.e:1301		if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_17937 != 2)
    goto L7; // [124] 162

    /** eds.e:1302			if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** io.e:1055		return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at129_17964;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _db_17938;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    _lock_file_1__tmp_at129_17964 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_129_17963 = machine(61, _lock_file_1__tmp_at129_17964);
    DeRef(_lock_file_1__tmp_at129_17964);
    _lock_file_1__tmp_at129_17964 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_129_17963 != 0)
    goto L8; // [145] 201

    /** eds.e:1303				close(db)*/
    EClose(_db_17938);

    /** eds.e:1304				return DB_LOCK_FAIL*/
    DeRefDS(_path_17936);
    DeRef(_10127);
    _10127 = NOVALUE;
    return -3;
    goto L8; // [159] 201
L7: 

    /** eds.e:1306		elsif lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_17937 != 1)
    goto L9; // [164] 200

    /** eds.e:1307			if not io:lock_file(db, io:LOCK_SHARED, {}) then*/

    /** io.e:1055		return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at169_17971;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _db_17938;
    ((intptr_t*)_2)[2] = 1;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    _lock_file_1__tmp_at169_17971 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_169_17970 = machine(61, _lock_file_1__tmp_at169_17971);
    DeRef(_lock_file_1__tmp_at169_17971);
    _lock_file_1__tmp_at169_17971 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_169_17970 != 0)
    goto LA; // [185] 199

    /** eds.e:1308				close(db)*/
    EClose(_db_17938);

    /** eds.e:1309				return DB_LOCK_FAIL*/
    DeRefDS(_path_17936);
    DeRef(_10127);
    _10127 = NOVALUE;
    return -3;
LA: 
L9: 
L8: 

    /** eds.e:1312		magic = getc(db)*/
    if (_db_17938 != last_r_file_no) {
        last_r_file_ptr = which_file(_db_17938, EF_READ);
        last_r_file_no = _db_17938;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _magic_17939 = getc((FILE*)xstdin);
        }
        else{
            _magic_17939 = getc(last_r_file_ptr);
        }
    }
    else{
        _magic_17939 = getc(last_r_file_ptr);
    }

    /** eds.e:1313		if magic != DB_MAGIC then*/
    if (_magic_17939 == 77)
    goto LB; // [208] 223

    /** eds.e:1314			close(db)*/
    EClose(_db_17938);

    /** eds.e:1315			return DB_OPEN_FAIL*/
    DeRefDS(_path_17936);
    DeRef(_10127);
    _10127 = NOVALUE;
    return -1;
LB: 

    /** eds.e:1317		save_keys()*/
    _43save_keys();

    /** eds.e:1318		current_db = db */
    _43current_db_16827 = _db_17938;

    /** eds.e:1319		current_table_pos = -1*/
    DeRef(_43current_table_pos_16828);
    _43current_table_pos_16828 = -1;

    /** eds.e:1320		current_table_name = ""*/
    RefDS(_5);
    DeRef(_43current_table_name_16829);
    _43current_table_name_16829 = _5;

    /** eds.e:1321		current_lock = lock_method*/
    _43current_lock_16833 = _lock_method_17937;

    /** eds.e:1322		db_names = append(db_names, path)*/
    RefDS(_path_17936);
    Append(&_43db_names_16830, _43db_names_16830, _path_17936);

    /** eds.e:1323		db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_43db_lock_methods_16832, _43db_lock_methods_16832, _lock_method_17937);

    /** eds.e:1324		db_file_nums = append(db_file_nums, db)*/
    Append(&_43db_file_nums_16831, _43db_file_nums_16831, _db_17938);

    /** eds.e:1325		return DB_OK*/
    DeRefDS(_path_17936);
    DeRef(_10127);
    _10127 = NOVALUE;
    return 0;
    ;
}


object _43db_select(object _path_17981, object _lock_method_17982)
{
    object _index_17983 = NOVALUE;
    object _10148 = NOVALUE;
    object _10146 = NOVALUE;
    object _10145 = NOVALUE;
    object _10143 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1372		index = find(path, Known_Aliases)*/
    _index_17983 = find_from(_path_17981, _43Known_Aliases_16848, 1);

    /** eds.e:1373		if index then*/
    if (_index_17983 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** eds.e:1375			path = Alias_Details[index][1]*/
    _2 = (object)SEQ_PTR(_43Alias_Details_16849);
    _10143 = (object)*(((s1_ptr)_2)->base + _index_17983);
    DeRefDS(_path_17981);
    _2 = (object)SEQ_PTR(_10143);
    _path_17981 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_path_17981);
    _10143 = NOVALUE;

    /** eds.e:1376			lock_method = Alias_Details[index][2][CONNECT_LOCK]*/
    _2 = (object)SEQ_PTR(_43Alias_Details_16849);
    _10145 = (object)*(((s1_ptr)_2)->base + _index_17983);
    _2 = (object)SEQ_PTR(_10145);
    _10146 = (object)*(((s1_ptr)_2)->base + 2);
    _10145 = NOVALUE;
    _2 = (object)SEQ_PTR(_10146);
    _lock_method_17982 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_17982)){
        _lock_method_17982 = (object)DBL_PTR(_lock_method_17982)->dbl;
    }
    _10146 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** eds.e:1378			path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_17981);
    RefDS(_10072);
    _10148 = _17defaultext(_path_17981, _10072);
    _0 = _path_17981;
    _path_17981 = _17canonical_path(_10148, 0, 0);
    DeRefDS(_0);
    _10148 = NOVALUE;
L2: 

    /** eds.e:1381		index = eu:find(path, db_names)*/
    _index_17983 = find_from(_path_17981, _43db_names_16830, 1);

    /** eds.e:1382		if index = 0 then*/
    if (_index_17983 != 0)
    goto L3; // [81] 130

    /** eds.e:1383			if lock_method = -1 then*/
    if (_lock_method_17982 != -1)
    goto L4; // [87] 98

    /** eds.e:1384				return DB_OPEN_FAIL*/
    DeRefDS(_path_17981);
    return -1;
L4: 

    /** eds.e:1386			index = db_open(path, lock_method)*/
    RefDS(_path_17981);
    _index_17983 = _43db_open(_path_17981, _lock_method_17982);
    if (!IS_ATOM_INT(_index_17983)) {
        _1 = (object)(DBL_PTR(_index_17983)->dbl);
        DeRefDS(_index_17983);
        _index_17983 = _1;
    }

    /** eds.e:1387			if index != DB_OK then*/
    if (_index_17983 == 0)
    goto L5; // [109] 120

    /** eds.e:1388				return index*/
    DeRefDS(_path_17981);
    return _index_17983;
L5: 

    /** eds.e:1390			index = eu:find(path, db_names)*/
    _index_17983 = find_from(_path_17981, _43db_names_16830, 1);
L3: 

    /** eds.e:1392		save_keys()*/
    _43save_keys();

    /** eds.e:1393		current_db = db_file_nums[index]*/
    _2 = (object)SEQ_PTR(_43db_file_nums_16831);
    _43current_db_16827 = (object)*(((s1_ptr)_2)->base + _index_17983);
    if (!IS_ATOM_INT(_43current_db_16827))
    _43current_db_16827 = (object)DBL_PTR(_43current_db_16827)->dbl;

    /** eds.e:1394		current_lock = db_lock_methods[index]*/
    _2 = (object)SEQ_PTR(_43db_lock_methods_16832);
    _43current_lock_16833 = (object)*(((s1_ptr)_2)->base + _index_17983);
    if (!IS_ATOM_INT(_43current_lock_16833))
    _43current_lock_16833 = (object)DBL_PTR(_43current_lock_16833)->dbl;

    /** eds.e:1395		current_table_pos = -1*/
    DeRef(_43current_table_pos_16828);
    _43current_table_pos_16828 = -1;

    /** eds.e:1396		current_table_name = ""*/
    RefDS(_5);
    DeRef(_43current_table_name_16829);
    _43current_table_name_16829 = _5;

    /** eds.e:1397		key_pointers = {}*/
    RefDS(_5);
    DeRef(_43key_pointers_16834);
    _43key_pointers_16834 = _5;

    /** eds.e:1398		return DB_OK*/
    DeRefDS(_path_17981);
    return 0;
    ;
}


void _43db_close()
{
    object _unlock_file_1__tmp_at25_18012 = NOVALUE;
    object _index_18007 = NOVALUE;
    object _10165 = NOVALUE;
    object _10164 = NOVALUE;
    object _10163 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1413		if current_db = -1 then*/
    if (_43current_db_16827 != -1)
    goto L1; // [5] 15

    /** eds.e:1414			return*/
    return;
L1: 

    /** eds.e:1417		if current_lock then*/
    if (_43current_lock_16833 == 0)
    {
        goto L2; // [19] 43
    }
    else{
    }

    /** eds.e:1418			io:unlock_file(current_db, {})*/

    /** io.e:1086		machine_proc(M_UNLOCK_FILE, {fn, r})*/
    RefDS(_5);
    DeRef(_unlock_file_1__tmp_at25_18012);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_16827;
    ((intptr_t *)_2)[2] = _5;
    _unlock_file_1__tmp_at25_18012 = MAKE_SEQ(_1);
    machine(62, _unlock_file_1__tmp_at25_18012);

    /** io.e:1087	end procedure*/
    goto L3; // [37] 40
L3: 
    DeRef(_unlock_file_1__tmp_at25_18012);
    _unlock_file_1__tmp_at25_18012 = NOVALUE;
L2: 

    /** eds.e:1420		close(current_db)*/
    EClose(_43current_db_16827);

    /** eds.e:1422		index = eu:find(current_db, db_file_nums)*/
    _index_18007 = find_from(_43current_db_16827, _43db_file_nums_16831, 1);

    /** eds.e:1423		db_names = remove(db_names, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_43db_names_16830);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_18007)) ? _index_18007 : (object)(DBL_PTR(_index_18007)->dbl);
        int stop = (IS_ATOM_INT(_index_18007)) ? _index_18007 : (object)(DBL_PTR(_index_18007)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43db_names_16830), start, &_43db_names_16830 );
            }
            else Tail(SEQ_PTR(_43db_names_16830), stop+1, &_43db_names_16830);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43db_names_16830), start, &_43db_names_16830);
        }
        else {
            assign_slice_seq = &assign_space;
            _43db_names_16830 = Remove_elements(start, stop, (SEQ_PTR(_43db_names_16830)->ref == 1));
        }
    }

    /** eds.e:1424		db_file_nums = remove(db_file_nums, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_43db_file_nums_16831);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_18007)) ? _index_18007 : (object)(DBL_PTR(_index_18007)->dbl);
        int stop = (IS_ATOM_INT(_index_18007)) ? _index_18007 : (object)(DBL_PTR(_index_18007)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43db_file_nums_16831), start, &_43db_file_nums_16831 );
            }
            else Tail(SEQ_PTR(_43db_file_nums_16831), stop+1, &_43db_file_nums_16831);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43db_file_nums_16831), start, &_43db_file_nums_16831);
        }
        else {
            assign_slice_seq = &assign_space;
            _43db_file_nums_16831 = Remove_elements(start, stop, (SEQ_PTR(_43db_file_nums_16831)->ref == 1));
        }
    }

    /** eds.e:1425		db_lock_methods = remove(db_lock_methods, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_43db_lock_methods_16832);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_18007)) ? _index_18007 : (object)(DBL_PTR(_index_18007)->dbl);
        int stop = (IS_ATOM_INT(_index_18007)) ? _index_18007 : (object)(DBL_PTR(_index_18007)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43db_lock_methods_16832), start, &_43db_lock_methods_16832 );
            }
            else Tail(SEQ_PTR(_43db_lock_methods_16832), stop+1, &_43db_lock_methods_16832);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43db_lock_methods_16832), start, &_43db_lock_methods_16832);
        }
        else {
            assign_slice_seq = &assign_space;
            _43db_lock_methods_16832 = Remove_elements(start, stop, (SEQ_PTR(_43db_lock_methods_16832)->ref == 1));
        }
    }

    /** eds.e:1427		for i = length(cache_index) to 1 by -1 do*/
    if (IS_SEQUENCE(_43cache_index_16836)){
            _10163 = SEQ_PTR(_43cache_index_16836)->length;
    }
    else {
        _10163 = 1;
    }
    {
        object _i_18018;
        _i_18018 = _10163;
L4: 
        if (_i_18018 < 1){
            goto L5; // [94] 145
        }

        /** eds.e:1428			if cache_index[i][1] = current_db then*/
        _2 = (object)SEQ_PTR(_43cache_index_16836);
        _10164 = (object)*(((s1_ptr)_2)->base + _i_18018);
        _2 = (object)SEQ_PTR(_10164);
        _10165 = (object)*(((s1_ptr)_2)->base + 1);
        _10164 = NOVALUE;
        if (binary_op_a(NOTEQ, _10165, _43current_db_16827)){
            _10165 = NOVALUE;
            goto L6; // [115] 138
        }
        _10165 = NOVALUE;

        /** eds.e:1429				cache_index = remove(cache_index, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_43cache_index_16836);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_18018)) ? _i_18018 : (object)(DBL_PTR(_i_18018)->dbl);
            int stop = (IS_ATOM_INT(_i_18018)) ? _i_18018 : (object)(DBL_PTR(_i_18018)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_43cache_index_16836), start, &_43cache_index_16836 );
                }
                else Tail(SEQ_PTR(_43cache_index_16836), stop+1, &_43cache_index_16836);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_43cache_index_16836), start, &_43cache_index_16836);
            }
            else {
                assign_slice_seq = &assign_space;
                _43cache_index_16836 = Remove_elements(start, stop, (SEQ_PTR(_43cache_index_16836)->ref == 1));
            }
        }

        /** eds.e:1430				key_cache = remove(key_cache, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_43key_cache_16835);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_18018)) ? _i_18018 : (object)(DBL_PTR(_i_18018)->dbl);
            int stop = (IS_ATOM_INT(_i_18018)) ? _i_18018 : (object)(DBL_PTR(_i_18018)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_43key_cache_16835), start, &_43key_cache_16835 );
                }
                else Tail(SEQ_PTR(_43key_cache_16835), stop+1, &_43key_cache_16835);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_43key_cache_16835), start, &_43key_cache_16835);
            }
            else {
                assign_slice_seq = &assign_space;
                _43key_cache_16835 = Remove_elements(start, stop, (SEQ_PTR(_43key_cache_16835)->ref == 1));
            }
        }
L6: 

        /** eds.e:1432		end for*/
        _i_18018 = _i_18018 + -1;
        goto L4; // [140] 101
L5: 
        ;
    }

    /** eds.e:1433		current_table_pos = -1*/
    DeRef(_43current_table_pos_16828);
    _43current_table_pos_16828 = -1;

    /** eds.e:1434		current_table_name = ""	*/
    RefDS(_5);
    DeRef(_43current_table_name_16829);
    _43current_table_name_16829 = _5;

    /** eds.e:1435		current_db = -1*/
    _43current_db_16827 = -1;

    /** eds.e:1436		key_pointers = {}*/
    RefDS(_5);
    DeRef(_43key_pointers_16834);
    _43key_pointers_16834 = _5;

    /** eds.e:1437	end procedure*/
    return;
    ;
}


object _43table_find(object _name_18028)
{
    object _tables_18029 = NOVALUE;
    object _nt_18030 = NOVALUE;
    object _t_header_18031 = NOVALUE;
    object _name_ptr_18032 = NOVALUE;
    object _seek_1__tmp_at6_18035 = NOVALUE;
    object _seek_inlined_seek_at_6_18034 = NOVALUE;
    object _seek_1__tmp_at44_18042 = NOVALUE;
    object _seek_inlined_seek_at_44_18041 = NOVALUE;
    object _seek_1__tmp_at84_18050 = NOVALUE;
    object _seek_inlined_seek_at_84_18049 = NOVALUE;
    object _seek_1__tmp_at106_18054 = NOVALUE;
    object _seek_inlined_seek_at_106_18053 = NOVALUE;
    object _10176 = NOVALUE;
    object _10174 = NOVALUE;
    object _10169 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1446		io:seek(current_db, TABLE_HEADERS)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at6_18035);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_16827;
    ((intptr_t *)_2)[2] = 3;
    _seek_1__tmp_at6_18035 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_6_18034 = machine(19, _seek_1__tmp_at6_18035);
    DeRefi(_seek_1__tmp_at6_18035);
    _seek_1__tmp_at6_18035 = NOVALUE;

    /** eds.e:1447		if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_43vLastErrors_16851)){
            _10169 = SEQ_PTR(_43vLastErrors_16851)->length;
    }
    else {
        _10169 = 1;
    }
    if (_10169 <= 0)
    goto L1; // [27] 36
    DeRefDS(_name_18028);
    DeRef(_tables_18029);
    DeRef(_nt_18030);
    DeRef(_t_header_18031);
    DeRef(_name_ptr_18032);
    return -1;
L1: 

    /** eds.e:1448		tables = get4()*/
    _0 = _tables_18029;
    _tables_18029 = _43get4();
    DeRef(_0);

    /** eds.e:1449		io:seek(current_db, tables)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_18029);
    DeRef(_seek_1__tmp_at44_18042);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_16827;
    ((intptr_t *)_2)[2] = _tables_18029;
    _seek_1__tmp_at44_18042 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_44_18041 = machine(19, _seek_1__tmp_at44_18042);
    DeRef(_seek_1__tmp_at44_18042);
    _seek_1__tmp_at44_18042 = NOVALUE;

    /** eds.e:1450		nt = get4()*/
    _0 = _nt_18030;
    _nt_18030 = _43get4();
    DeRef(_0);

    /** eds.e:1451		t_header = tables+4*/
    DeRef(_t_header_18031);
    if (IS_ATOM_INT(_tables_18029)) {
        _t_header_18031 = _tables_18029 + 4;
        if ((object)((uintptr_t)_t_header_18031 + (uintptr_t)HIGH_BITS) >= 0){
            _t_header_18031 = NewDouble((eudouble)_t_header_18031);
        }
    }
    else {
        _t_header_18031 = NewDouble(DBL_PTR(_tables_18029)->dbl + (eudouble)4);
    }

    /** eds.e:1452		for i = 1 to nt do*/
    Ref(_nt_18030);
    DeRef(_10174);
    _10174 = _nt_18030;
    {
        object _i_18046;
        _i_18046 = 1;
L2: 
        if (binary_op_a(GREATER, _i_18046, _10174)){
            goto L3; // [74] 150
        }

        /** eds.e:1453			io:seek(current_db, t_header)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_t_header_18031);
        DeRef(_seek_1__tmp_at84_18050);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _43current_db_16827;
        ((intptr_t *)_2)[2] = _t_header_18031;
        _seek_1__tmp_at84_18050 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_84_18049 = machine(19, _seek_1__tmp_at84_18050);
        DeRef(_seek_1__tmp_at84_18050);
        _seek_1__tmp_at84_18050 = NOVALUE;

        /** eds.e:1454			name_ptr = get4()*/
        _0 = _name_ptr_18032;
        _name_ptr_18032 = _43get4();
        DeRef(_0);

        /** eds.e:1455			io:seek(current_db, name_ptr)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_ptr_18032);
        DeRef(_seek_1__tmp_at106_18054);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _43current_db_16827;
        ((intptr_t *)_2)[2] = _name_ptr_18032;
        _seek_1__tmp_at106_18054 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_106_18053 = machine(19, _seek_1__tmp_at106_18054);
        DeRef(_seek_1__tmp_at106_18054);
        _seek_1__tmp_at106_18054 = NOVALUE;

        /** eds.e:1456			if equal_string(name) > 0 then*/
        RefDS(_name_18028);
        _10176 = _43equal_string(_name_18028);
        if (binary_op_a(LESSEQ, _10176, 0)){
            DeRef(_10176);
            _10176 = NOVALUE;
            goto L4; // [126] 137
        }
        DeRef(_10176);
        _10176 = NOVALUE;

        /** eds.e:1458				return t_header*/
        DeRef(_i_18046);
        DeRefDS(_name_18028);
        DeRef(_tables_18029);
        DeRef(_nt_18030);
        DeRef(_name_ptr_18032);
        return _t_header_18031;
L4: 

        /** eds.e:1460			t_header += SIZEOF_TABLE_HEADER*/
        _0 = _t_header_18031;
        if (IS_ATOM_INT(_t_header_18031)) {
            _t_header_18031 = _t_header_18031 + 16;
            if ((object)((uintptr_t)_t_header_18031 + (uintptr_t)HIGH_BITS) >= 0){
                _t_header_18031 = NewDouble((eudouble)_t_header_18031);
            }
        }
        else {
            _t_header_18031 = NewDouble(DBL_PTR(_t_header_18031)->dbl + (eudouble)16);
        }
        DeRef(_0);

        /** eds.e:1461		end for*/
        _0 = _i_18046;
        if (IS_ATOM_INT(_i_18046)) {
            _i_18046 = _i_18046 + 1;
            if ((object)((uintptr_t)_i_18046 +(uintptr_t) HIGH_BITS) >= 0){
                _i_18046 = NewDouble((eudouble)_i_18046);
            }
        }
        else {
            _i_18046 = binary_op_a(PLUS, _i_18046, 1);
        }
        DeRef(_0);
        goto L2; // [145] 81
L3: 
        ;
        DeRef(_i_18046);
    }

    /** eds.e:1462		return -1*/
    DeRefDS(_name_18028);
    DeRef(_tables_18029);
    DeRef(_nt_18030);
    DeRef(_t_header_18031);
    DeRef(_name_ptr_18032);
    return -1;
    ;
}


object _43db_select_table(object _name_18061)
{
    object _table_18062 = NOVALUE;
    object _nkeys_18063 = NOVALUE;
    object _index_18064 = NOVALUE;
    object _block_ptr_18065 = NOVALUE;
    object _block_size_18066 = NOVALUE;
    object _blocks_18067 = NOVALUE;
    object _k_18068 = NOVALUE;
    object _seek_1__tmp_at120_18087 = NOVALUE;
    object _seek_inlined_seek_at_120_18086 = NOVALUE;
    object _pos_inlined_seek_at_117_18085 = NOVALUE;
    object _seek_1__tmp_at178_18097 = NOVALUE;
    object _seek_inlined_seek_at_178_18096 = NOVALUE;
    object _seek_1__tmp_at205_18102 = NOVALUE;
    object _seek_inlined_seek_at_205_18101 = NOVALUE;
    object _10197 = NOVALUE;
    object _10196 = NOVALUE;
    object _10193 = NOVALUE;
    object _10188 = NOVALUE;
    object _10183 = NOVALUE;
    object _10179 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1501		if equal(current_table_name, name) then*/
    if (_43current_table_name_16829 == _name_18061)
    _10179 = 1;
    else if (IS_ATOM_INT(_43current_table_name_16829) && IS_ATOM_INT(_name_18061))
    _10179 = 0;
    else
    _10179 = (compare(_43current_table_name_16829, _name_18061) == 0);
    if (_10179 == 0)
    {
        _10179 = NOVALUE;
        goto L1; // [11] 21
    }
    else{
        _10179 = NOVALUE;
    }

    /** eds.e:1502			return DB_OK*/
    DeRefDS(_name_18061);
    DeRef(_table_18062);
    DeRef(_nkeys_18063);
    DeRef(_index_18064);
    DeRef(_block_ptr_18065);
    DeRef(_block_size_18066);
    return 0;
L1: 

    /** eds.e:1504		table = table_find(name)*/
    RefDS(_name_18061);
    _0 = _table_18062;
    _table_18062 = _43table_find(_name_18061);
    DeRef(_0);

    /** eds.e:1505		if table = -1 then*/
    if (binary_op_a(NOTEQ, _table_18062, -1)){
        goto L2; // [29] 40
    }

    /** eds.e:1506			return DB_OPEN_FAIL*/
    DeRefDS(_name_18061);
    DeRef(_table_18062);
    DeRef(_nkeys_18063);
    DeRef(_index_18064);
    DeRef(_block_ptr_18065);
    DeRef(_block_size_18066);
    return -1;
L2: 

    /** eds.e:1509		save_keys()*/
    _43save_keys();

    /** eds.e:1511		current_table_pos = table*/
    Ref(_table_18062);
    DeRef(_43current_table_pos_16828);
    _43current_table_pos_16828 = _table_18062;

    /** eds.e:1512		current_table_name = name*/
    RefDS(_name_18061);
    DeRef(_43current_table_name_16829);
    _43current_table_name_16829 = _name_18061;

    /** eds.e:1514		k = 0*/
    _k_18068 = 0;

    /** eds.e:1515		if caching_option = 1 then*/

    /** eds.e:1516			k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_43current_table_pos_16828);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_16827;
    ((intptr_t *)_2)[2] = _43current_table_pos_16828;
    _10183 = MAKE_SEQ(_1);
    _k_18068 = find_from(_10183, _43cache_index_16836, 1);
    DeRefDS(_10183);
    _10183 = NOVALUE;

    /** eds.e:1517			if k != 0 then*/
    if (_k_18068 == 0)
    goto L3; // [88] 103

    /** eds.e:1518				key_pointers = key_cache[k]*/
    DeRef(_43key_pointers_16834);
    _2 = (object)SEQ_PTR(_43key_cache_16835);
    _43key_pointers_16834 = (object)*(((s1_ptr)_2)->base + _k_18068);
    Ref(_43key_pointers_16834);
L3: 

    /** eds.e:1521		if k = 0 then*/
    if (_k_18068 != 0)
    goto L4; // [106] 269

    /** eds.e:1523			io:seek(current_db, table+4)*/
    if (IS_ATOM_INT(_table_18062)) {
        _10188 = _table_18062 + 4;
        if ((object)((uintptr_t)_10188 + (uintptr_t)HIGH_BITS) >= 0){
            _10188 = NewDouble((eudouble)_10188);
        }
    }
    else {
        _10188 = NewDouble(DBL_PTR(_table_18062)->dbl + (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_117_18085);
    _pos_inlined_seek_at_117_18085 = _10188;
    _10188 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_117_18085);
    DeRef(_seek_1__tmp_at120_18087);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_16827;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_117_18085;
    _seek_1__tmp_at120_18087 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_120_18086 = machine(19, _seek_1__tmp_at120_18087);
    DeRef(_pos_inlined_seek_at_117_18085);
    _pos_inlined_seek_at_117_18085 = NOVALUE;
    DeRef(_seek_1__tmp_at120_18087);
    _seek_1__tmp_at120_18087 = NOVALUE;

    /** eds.e:1524			nkeys = get4()*/
    _0 = _nkeys_18063;
    _nkeys_18063 = _43get4();
    DeRef(_0);

    /** eds.e:1525			blocks = get4()*/
    _blocks_18067 = _43get4();
    if (!IS_ATOM_INT(_blocks_18067)) {
        _1 = (object)(DBL_PTR(_blocks_18067)->dbl);
        DeRefDS(_blocks_18067);
        _blocks_18067 = _1;
    }

    /** eds.e:1526			index = get4()*/
    _0 = _index_18064;
    _index_18064 = _43get4();
    DeRef(_0);

    /** eds.e:1527			key_pointers = repeat(0, nkeys)*/
    DeRef(_43key_pointers_16834);
    _43key_pointers_16834 = Repeat(0, _nkeys_18063);

    /** eds.e:1528			k = 1*/
    _k_18068 = 1;

    /** eds.e:1529			for b = 0 to blocks-1 do*/
    _10193 = _blocks_18067 - 1;
    if ((object)((uintptr_t)_10193 +(uintptr_t) HIGH_BITS) >= 0){
        _10193 = NewDouble((eudouble)_10193);
    }
    {
        object _b_18093;
        _b_18093 = 0;
L5: 
        if (binary_op_a(GREATER, _b_18093, _10193)){
            goto L6; // [168] 268
        }

        /** eds.e:1530				io:seek(current_db, index)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_index_18064);
        DeRef(_seek_1__tmp_at178_18097);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _43current_db_16827;
        ((intptr_t *)_2)[2] = _index_18064;
        _seek_1__tmp_at178_18097 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_178_18096 = machine(19, _seek_1__tmp_at178_18097);
        DeRef(_seek_1__tmp_at178_18097);
        _seek_1__tmp_at178_18097 = NOVALUE;

        /** eds.e:1531				block_size = get4()*/
        _0 = _block_size_18066;
        _block_size_18066 = _43get4();
        DeRef(_0);

        /** eds.e:1532				block_ptr = get4()*/
        _0 = _block_ptr_18065;
        _block_ptr_18065 = _43get4();
        DeRef(_0);

        /** eds.e:1533				io:seek(current_db, block_ptr)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_block_ptr_18065);
        DeRef(_seek_1__tmp_at205_18102);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _43current_db_16827;
        ((intptr_t *)_2)[2] = _block_ptr_18065;
        _seek_1__tmp_at205_18102 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_205_18101 = machine(19, _seek_1__tmp_at205_18102);
        DeRef(_seek_1__tmp_at205_18102);
        _seek_1__tmp_at205_18102 = NOVALUE;

        /** eds.e:1534				for j = 1 to block_size do*/
        Ref(_block_size_18066);
        DeRef(_10196);
        _10196 = _block_size_18066;
        {
            object _j_18104;
            _j_18104 = 1;
L7: 
            if (binary_op_a(GREATER, _j_18104, _10196)){
                goto L8; // [224] 255
            }

            /** eds.e:1535					key_pointers[k] = get4()*/
            _10197 = _43get4();
            _2 = (object)SEQ_PTR(_43key_pointers_16834);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _43key_pointers_16834 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _k_18068);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _10197;
            if( _1 != _10197 ){
                DeRef(_1);
            }
            _10197 = NOVALUE;

            /** eds.e:1536					k += 1*/
            _k_18068 = _k_18068 + 1;

            /** eds.e:1537				end for*/
            _0 = _j_18104;
            if (IS_ATOM_INT(_j_18104)) {
                _j_18104 = _j_18104 + 1;
                if ((object)((uintptr_t)_j_18104 +(uintptr_t) HIGH_BITS) >= 0){
                    _j_18104 = NewDouble((eudouble)_j_18104);
                }
            }
            else {
                _j_18104 = binary_op_a(PLUS, _j_18104, 1);
            }
            DeRef(_0);
            goto L7; // [250] 231
L8: 
            ;
            DeRef(_j_18104);
        }

        /** eds.e:1538				index += 8*/
        _0 = _index_18064;
        if (IS_ATOM_INT(_index_18064)) {
            _index_18064 = _index_18064 + 8;
            if ((object)((uintptr_t)_index_18064 + (uintptr_t)HIGH_BITS) >= 0){
                _index_18064 = NewDouble((eudouble)_index_18064);
            }
        }
        else {
            _index_18064 = NewDouble(DBL_PTR(_index_18064)->dbl + (eudouble)8);
        }
        DeRef(_0);

        /** eds.e:1539			end for*/
        _0 = _b_18093;
        if (IS_ATOM_INT(_b_18093)) {
            _b_18093 = _b_18093 + 1;
            if ((object)((uintptr_t)_b_18093 +(uintptr_t) HIGH_BITS) >= 0){
                _b_18093 = NewDouble((eudouble)_b_18093);
            }
        }
        else {
            _b_18093 = binary_op_a(PLUS, _b_18093, 1);
        }
        DeRef(_0);
        goto L5; // [263] 175
L6: 
        ;
        DeRef(_b_18093);
    }
L4: 

    /** eds.e:1541		return DB_OK*/
    DeRefDS(_name_18061);
    DeRef(_table_18062);
    DeRef(_nkeys_18063);
    DeRef(_index_18064);
    DeRef(_block_ptr_18065);
    DeRef(_block_size_18066);
    DeRef(_10193);
    _10193 = NOVALUE;
    return 0;
    ;
}


object _43db_table_list()
{
    object _seek_1__tmp_at120_18484 = NOVALUE;
    object _seek_inlined_seek_at_120_18483 = NOVALUE;
    object _seek_1__tmp_at98_18480 = NOVALUE;
    object _seek_inlined_seek_at_98_18479 = NOVALUE;
    object _pos_inlined_seek_at_95_18478 = NOVALUE;
    object _seek_1__tmp_at42_18468 = NOVALUE;
    object _seek_inlined_seek_at_42_18467 = NOVALUE;
    object _seek_1__tmp_at4_18461 = NOVALUE;
    object _seek_inlined_seek_at_4_18460 = NOVALUE;
    object _table_names_18455 = NOVALUE;
    object _tables_18456 = NOVALUE;
    object _nt_18457 = NOVALUE;
    object _name_18458 = NOVALUE;
    object _10341 = NOVALUE;
    object _10340 = NOVALUE;
    object _10338 = NOVALUE;
    object _10337 = NOVALUE;
    object _10336 = NOVALUE;
    object _10335 = NOVALUE;
    object _10330 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1923		io:seek(current_db, TABLE_HEADERS)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_18461);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_16827;
    ((intptr_t *)_2)[2] = 3;
    _seek_1__tmp_at4_18461 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_18460 = machine(19, _seek_1__tmp_at4_18461);
    DeRefi(_seek_1__tmp_at4_18461);
    _seek_1__tmp_at4_18461 = NOVALUE;

    /** eds.e:1924		if length(vLastErrors) > 0 then return {} end if*/
    if (IS_SEQUENCE(_43vLastErrors_16851)){
            _10330 = SEQ_PTR(_43vLastErrors_16851)->length;
    }
    else {
        _10330 = 1;
    }
    if (_10330 <= 0)
    goto L1; // [25] 34
    RefDS(_5);
    DeRef(_table_names_18455);
    DeRef(_tables_18456);
    DeRef(_nt_18457);
    DeRef(_name_18458);
    return _5;
L1: 

    /** eds.e:1925		tables = get4()*/
    _0 = _tables_18456;
    _tables_18456 = _43get4();
    DeRef(_0);

    /** eds.e:1926		io:seek(current_db, tables)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_18456);
    DeRef(_seek_1__tmp_at42_18468);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_16827;
    ((intptr_t *)_2)[2] = _tables_18456;
    _seek_1__tmp_at42_18468 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_42_18467 = machine(19, _seek_1__tmp_at42_18468);
    DeRef(_seek_1__tmp_at42_18468);
    _seek_1__tmp_at42_18468 = NOVALUE;

    /** eds.e:1927		nt = get4()*/
    _0 = _nt_18457;
    _nt_18457 = _43get4();
    DeRef(_0);

    /** eds.e:1928		table_names = repeat(0, nt)*/
    DeRef(_table_names_18455);
    _table_names_18455 = Repeat(0, _nt_18457);

    /** eds.e:1929		for i = 0 to nt-1 do*/
    if (IS_ATOM_INT(_nt_18457)) {
        _10335 = _nt_18457 - 1;
        if ((object)((uintptr_t)_10335 +(uintptr_t) HIGH_BITS) >= 0){
            _10335 = NewDouble((eudouble)_10335);
        }
    }
    else {
        _10335 = NewDouble(DBL_PTR(_nt_18457)->dbl - (eudouble)1);
    }
    {
        object _i_18472;
        _i_18472 = 0;
L2: 
        if (binary_op_a(GREATER, _i_18472, _10335)){
            goto L3; // [73] 154
        }

        /** eds.e:1930			io:seek(current_db, tables + 4 + i*SIZEOF_TABLE_HEADER)*/
        if (IS_ATOM_INT(_tables_18456)) {
            _10336 = _tables_18456 + 4;
            if ((object)((uintptr_t)_10336 + (uintptr_t)HIGH_BITS) >= 0){
                _10336 = NewDouble((eudouble)_10336);
            }
        }
        else {
            _10336 = NewDouble(DBL_PTR(_tables_18456)->dbl + (eudouble)4);
        }
        if (IS_ATOM_INT(_i_18472)) {
            if (_i_18472 == (short)_i_18472){
                _10337 = _i_18472 * 16;
            }
            else{
                _10337 = NewDouble(_i_18472 * (eudouble)16);
            }
        }
        else {
            _10337 = NewDouble(DBL_PTR(_i_18472)->dbl * (eudouble)16);
        }
        if (IS_ATOM_INT(_10336) && IS_ATOM_INT(_10337)) {
            _10338 = _10336 + _10337;
            if ((object)((uintptr_t)_10338 + (uintptr_t)HIGH_BITS) >= 0){
                _10338 = NewDouble((eudouble)_10338);
            }
        }
        else {
            if (IS_ATOM_INT(_10336)) {
                _10338 = NewDouble((eudouble)_10336 + DBL_PTR(_10337)->dbl);
            }
            else {
                if (IS_ATOM_INT(_10337)) {
                    _10338 = NewDouble(DBL_PTR(_10336)->dbl + (eudouble)_10337);
                }
                else
                _10338 = NewDouble(DBL_PTR(_10336)->dbl + DBL_PTR(_10337)->dbl);
            }
        }
        DeRef(_10336);
        _10336 = NOVALUE;
        DeRef(_10337);
        _10337 = NOVALUE;
        DeRef(_pos_inlined_seek_at_95_18478);
        _pos_inlined_seek_at_95_18478 = _10338;
        _10338 = NOVALUE;

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_95_18478);
        DeRef(_seek_1__tmp_at98_18480);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _43current_db_16827;
        ((intptr_t *)_2)[2] = _pos_inlined_seek_at_95_18478;
        _seek_1__tmp_at98_18480 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_98_18479 = machine(19, _seek_1__tmp_at98_18480);
        DeRef(_pos_inlined_seek_at_95_18478);
        _pos_inlined_seek_at_95_18478 = NOVALUE;
        DeRef(_seek_1__tmp_at98_18480);
        _seek_1__tmp_at98_18480 = NOVALUE;

        /** eds.e:1931			name = get4()*/
        _0 = _name_18458;
        _name_18458 = _43get4();
        DeRef(_0);

        /** eds.e:1932			io:seek(current_db, name)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_18458);
        DeRef(_seek_1__tmp_at120_18484);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _43current_db_16827;
        ((intptr_t *)_2)[2] = _name_18458;
        _seek_1__tmp_at120_18484 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_120_18483 = machine(19, _seek_1__tmp_at120_18484);
        DeRef(_seek_1__tmp_at120_18484);
        _seek_1__tmp_at120_18484 = NOVALUE;

        /** eds.e:1933			table_names[i+1] = get_string()*/
        if (IS_ATOM_INT(_i_18472)) {
            _10340 = _i_18472 + 1;
            if (_10340 > MAXINT){
                _10340 = NewDouble((eudouble)_10340);
            }
        }
        else
        _10340 = binary_op(PLUS, 1, _i_18472);
        _10341 = _43get_string();
        _2 = (object)SEQ_PTR(_table_names_18455);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _table_names_18455 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_10340))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_10340)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _10340);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _10341;
        if( _1 != _10341 ){
            DeRef(_1);
        }
        _10341 = NOVALUE;

        /** eds.e:1934		end for*/
        _0 = _i_18472;
        if (IS_ATOM_INT(_i_18472)) {
            _i_18472 = _i_18472 + 1;
            if ((object)((uintptr_t)_i_18472 +(uintptr_t) HIGH_BITS) >= 0){
                _i_18472 = NewDouble((eudouble)_i_18472);
            }
        }
        else {
            _i_18472 = binary_op_a(PLUS, _i_18472, 1);
        }
        DeRef(_0);
        goto L2; // [149] 80
L3: 
        ;
        DeRef(_i_18472);
    }

    /** eds.e:1935		return table_names*/
    DeRef(_tables_18456);
    DeRef(_nt_18457);
    DeRef(_name_18458);
    DeRef(_10340);
    _10340 = NOVALUE;
    DeRef(_10335);
    _10335 = NOVALUE;
    return _table_names_18455;
    ;
}


object _43key_value(object _ptr_18489)
{
    object _seek_1__tmp_at11_18494 = NOVALUE;
    object _seek_inlined_seek_at_11_18493 = NOVALUE;
    object _pos_inlined_seek_at_8_18492 = NOVALUE;
    object _10343 = NOVALUE;
    object _10342 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1941		io:seek(current_db, ptr+4) -- skip ptr to data*/
    if (IS_ATOM_INT(_ptr_18489)) {
        _10342 = _ptr_18489 + 4;
        if ((object)((uintptr_t)_10342 + (uintptr_t)HIGH_BITS) >= 0){
            _10342 = NewDouble((eudouble)_10342);
        }
    }
    else {
        _10342 = NewDouble(DBL_PTR(_ptr_18489)->dbl + (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_8_18492);
    _pos_inlined_seek_at_8_18492 = _10342;
    _10342 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_18492);
    DeRef(_seek_1__tmp_at11_18494);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_16827;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_8_18492;
    _seek_1__tmp_at11_18494 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_18493 = machine(19, _seek_1__tmp_at11_18494);
    DeRef(_pos_inlined_seek_at_8_18492);
    _pos_inlined_seek_at_8_18492 = NOVALUE;
    DeRef(_seek_1__tmp_at11_18494);
    _seek_1__tmp_at11_18494 = NOVALUE;

    /** eds.e:1942		return decompress(0)*/
    _10343 = _43decompress(0);
    DeRef(_ptr_18489);
    return _10343;
    ;
}


object _43db_find_key(object _key_18498, object _table_name_18499)
{
    object _lo_18500 = NOVALUE;
    object _hi_18501 = NOVALUE;
    object _mid_18502 = NOVALUE;
    object _c_18503 = NOVALUE;
    object _10367 = NOVALUE;
    object _10359 = NOVALUE;
    object _10358 = NOVALUE;
    object _10356 = NOVALUE;
    object _10353 = NOVALUE;
    object _10350 = NOVALUE;
    object _10346 = NOVALUE;
    object _10344 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2003		if not equal(table_name, current_table_name) then*/
    if (_table_name_18499 == _43current_table_name_16829)
    _10344 = 1;
    else if (IS_ATOM_INT(_table_name_18499) && IS_ATOM_INT(_43current_table_name_16829))
    _10344 = 0;
    else
    _10344 = (compare(_table_name_18499, _43current_table_name_16829) == 0);
    if (_10344 != 0)
    goto L1; // [9] 42
    _10344 = NOVALUE;

    /** eds.e:2004			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_18499);
    _10346 = _43db_select_table(_table_name_18499);
    if (binary_op_a(EQUALS, _10346, 0)){
        DeRef(_10346);
        _10346 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10346);
    _10346 = NOVALUE;

    /** eds.e:2005				fatal(NO_TABLE, "invalid table name given", "db_find_key", {key, table_name})*/
    RefDS(_table_name_18499);
    Ref(_key_18498);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_18498;
    ((intptr_t *)_2)[2] = _table_name_18499;
    _10350 = MAKE_SEQ(_1);
    RefDS(_10348);
    RefDS(_10349);
    _43fatal(903, _10348, _10349, _10350);
    _10350 = NOVALUE;

    /** eds.e:2006				return 0*/
    DeRef(_key_18498);
    DeRefDS(_table_name_18499);
    return 0;
L2: 
L1: 

    /** eds.e:2010		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _43current_table_pos_16828, -1)){
        goto L3; // [46] 69
    }

    /** eds.e:2011			fatal(NO_TABLE, "no table selected", "db_find_key", {key, table_name})*/
    Ref(_table_name_18499);
    Ref(_key_18498);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_18498;
    ((intptr_t *)_2)[2] = _table_name_18499;
    _10353 = MAKE_SEQ(_1);
    RefDS(_10352);
    RefDS(_10349);
    _43fatal(903, _10352, _10349, _10353);
    _10353 = NOVALUE;

    /** eds.e:2012			return 0*/
    DeRef(_key_18498);
    DeRef(_table_name_18499);
    return 0;
L3: 

    /** eds.e:2015		lo = 1*/
    _lo_18500 = 1;

    /** eds.e:2016		hi = length(key_pointers)*/
    if (IS_SEQUENCE(_43key_pointers_16834)){
            _hi_18501 = SEQ_PTR(_43key_pointers_16834)->length;
    }
    else {
        _hi_18501 = 1;
    }

    /** eds.e:2017		mid = 1*/
    _mid_18502 = 1;

    /** eds.e:2018		c = 0*/
    _c_18503 = 0;

    /** eds.e:2019		while lo <= hi do*/
L4: 
    if (_lo_18500 > _hi_18501)
    goto L5; // [96] 170

    /** eds.e:2020			mid = floor((lo + hi) / 2)*/
    _10356 = _lo_18500 + _hi_18501;
    if ((object)((uintptr_t)_10356 + (uintptr_t)HIGH_BITS) >= 0){
        _10356 = NewDouble((eudouble)_10356);
    }
    if (IS_ATOM_INT(_10356)) {
        _mid_18502 = _10356 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _10356, 2);
        _mid_18502 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_10356);
    _10356 = NOVALUE;
    if (!IS_ATOM_INT(_mid_18502)) {
        _1 = (object)(DBL_PTR(_mid_18502)->dbl);
        DeRefDS(_mid_18502);
        _mid_18502 = _1;
    }

    /** eds.e:2021			c = eu:compare(key, key_value(key_pointers[mid]))*/
    _2 = (object)SEQ_PTR(_43key_pointers_16834);
    _10358 = (object)*(((s1_ptr)_2)->base + _mid_18502);
    Ref(_10358);
    _10359 = _43key_value(_10358);
    _10358 = NOVALUE;
    if (IS_ATOM_INT(_key_18498) && IS_ATOM_INT(_10359)){
        _c_18503 = (_key_18498 < _10359) ? -1 : (_key_18498 > _10359);
    }
    else{
        _c_18503 = compare(_key_18498, _10359);
    }
    DeRef(_10359);
    _10359 = NOVALUE;

    /** eds.e:2022			if c < 0 then*/
    if (_c_18503 >= 0)
    goto L6; // [130] 143

    /** eds.e:2023				hi = mid - 1*/
    _hi_18501 = _mid_18502 - 1;
    goto L4; // [140] 96
L6: 

    /** eds.e:2024			elsif c > 0 then*/
    if (_c_18503 <= 0)
    goto L7; // [145] 158

    /** eds.e:2025				lo = mid + 1*/
    _lo_18500 = _mid_18502 + 1;
    goto L4; // [155] 96
L7: 

    /** eds.e:2027				return mid*/
    DeRef(_key_18498);
    DeRef(_table_name_18499);
    return _mid_18502;

    /** eds.e:2029		end while*/
    goto L4; // [167] 96
L5: 

    /** eds.e:2031		if c > 0 then*/
    if (_c_18503 <= 0)
    goto L8; // [172] 183

    /** eds.e:2032			mid += 1*/
    _mid_18502 = _mid_18502 + 1;
L8: 

    /** eds.e:2034		return -mid*/
    if ((uintptr_t)_mid_18502 == (uintptr_t)HIGH_BITS){
        _10367 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _10367 = - _mid_18502;
    }
    DeRef(_key_18498);
    DeRef(_table_name_18499);
    return _10367;
    ;
}


object _43db_table_size(object _table_name_18909)
{
    object _10546 = NOVALUE;
    object _10545 = NOVALUE;
    object _10543 = NOVALUE;
    object _10540 = NOVALUE;
    object _10538 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2369		if not equal(table_name, current_table_name) then*/
    if (_table_name_18909 == _43current_table_name_16829)
    _10538 = 1;
    else if (IS_ATOM_INT(_table_name_18909) && IS_ATOM_INT(_43current_table_name_16829))
    _10538 = 0;
    else
    _10538 = (compare(_table_name_18909, _43current_table_name_16829) == 0);
    if (_10538 != 0)
    goto L1; // [9] 42
    _10538 = NOVALUE;

    /** eds.e:2370			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_18909);
    _10540 = _43db_select_table(_table_name_18909);
    if (binary_op_a(EQUALS, _10540, 0)){
        DeRef(_10540);
        _10540 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10540);
    _10540 = NOVALUE;

    /** eds.e:2371				fatal(NO_TABLE, "invalid table name given", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_table_name_18909);
    ((intptr_t*)_2)[1] = _table_name_18909;
    _10543 = MAKE_SEQ(_1);
    RefDS(_10348);
    RefDS(_10542);
    _43fatal(903, _10348, _10542, _10543);
    _10543 = NOVALUE;

    /** eds.e:2372				return -1*/
    DeRefDS(_table_name_18909);
    return -1;
L2: 
L1: 

    /** eds.e:2376		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _43current_table_pos_16828, -1)){
        goto L3; // [46] 69
    }

    /** eds.e:2377			fatal(NO_TABLE, "no table selected", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_table_name_18909);
    ((intptr_t*)_2)[1] = _table_name_18909;
    _10545 = MAKE_SEQ(_1);
    RefDS(_10352);
    RefDS(_10542);
    _43fatal(903, _10352, _10542, _10545);
    _10545 = NOVALUE;

    /** eds.e:2378			return -1*/
    DeRef(_table_name_18909);
    return -1;
L3: 

    /** eds.e:2380		return length(key_pointers)*/
    if (IS_SEQUENCE(_43key_pointers_16834)){
            _10546 = SEQ_PTR(_43key_pointers_16834)->length;
    }
    else {
        _10546 = 1;
    }
    DeRef(_table_name_18909);
    return _10546;
    ;
}


object _43db_record_data(object _key_location_18924, object _table_name_18925)
{
    object _data_ptr_18926 = NOVALUE;
    object _data_value_18927 = NOVALUE;
    object _seek_1__tmp_at126_18949 = NOVALUE;
    object _seek_inlined_seek_at_126_18948 = NOVALUE;
    object _pos_inlined_seek_at_123_18947 = NOVALUE;
    object _seek_1__tmp_at164_18956 = NOVALUE;
    object _seek_inlined_seek_at_164_18955 = NOVALUE;
    object _10561 = NOVALUE;
    object _10560 = NOVALUE;
    object _10559 = NOVALUE;
    object _10558 = NOVALUE;
    object _10557 = NOVALUE;
    object _10555 = NOVALUE;
    object _10554 = NOVALUE;
    object _10552 = NOVALUE;
    object _10549 = NOVALUE;
    object _10547 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_18924)) {
        _1 = (object)(DBL_PTR(_key_location_18924)->dbl);
        DeRefDS(_key_location_18924);
        _key_location_18924 = _1;
    }

    /** eds.e:2417		if not equal(table_name, current_table_name) then*/
    if (_table_name_18925 == _43current_table_name_16829)
    _10547 = 1;
    else if (IS_ATOM_INT(_table_name_18925) && IS_ATOM_INT(_43current_table_name_16829))
    _10547 = 0;
    else
    _10547 = (compare(_table_name_18925, _43current_table_name_16829) == 0);
    if (_10547 != 0)
    goto L1; // [11] 44
    _10547 = NOVALUE;

    /** eds.e:2418			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_18925);
    _10549 = _43db_select_table(_table_name_18925);
    if (binary_op_a(EQUALS, _10549, 0)){
        DeRef(_10549);
        _10549 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10549);
    _10549 = NOVALUE;

    /** eds.e:2419				fatal(NO_TABLE, "invalid table name given", "db_record_data", {key_location, table_name})*/
    RefDS(_table_name_18925);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_18924;
    ((intptr_t *)_2)[2] = _table_name_18925;
    _10552 = MAKE_SEQ(_1);
    RefDS(_10348);
    RefDS(_10551);
    _43fatal(903, _10348, _10551, _10552);
    _10552 = NOVALUE;

    /** eds.e:2420				return -1*/
    DeRefDS(_table_name_18925);
    DeRef(_data_ptr_18926);
    DeRef(_data_value_18927);
    return -1;
L2: 
L1: 

    /** eds.e:2424		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _43current_table_pos_16828, -1)){
        goto L3; // [48] 71
    }

    /** eds.e:2425			fatal(NO_TABLE, "no table selected", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_18925);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_18924;
    ((intptr_t *)_2)[2] = _table_name_18925;
    _10554 = MAKE_SEQ(_1);
    RefDS(_10352);
    RefDS(_10551);
    _43fatal(903, _10352, _10551, _10554);
    _10554 = NOVALUE;

    /** eds.e:2426			return -1*/
    DeRef(_table_name_18925);
    DeRef(_data_ptr_18926);
    DeRef(_data_value_18927);
    return -1;
L3: 

    /** eds.e:2428		if key_location < 1 or key_location > length(key_pointers) then*/
    _10555 = (_key_location_18924 < 1);
    if (_10555 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_43key_pointers_16834)){
            _10557 = SEQ_PTR(_43key_pointers_16834)->length;
    }
    else {
        _10557 = 1;
    }
    _10558 = (_key_location_18924 > _10557);
    _10557 = NOVALUE;
    if (_10558 == 0)
    {
        DeRef(_10558);
        _10558 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10558);
        _10558 = NOVALUE;
    }
L4: 

    /** eds.e:2429			fatal(BAD_RECNO, "bad record number", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_18925);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_18924;
    ((intptr_t *)_2)[2] = _table_name_18925;
    _10559 = MAKE_SEQ(_1);
    RefDS(_10476);
    RefDS(_10551);
    _43fatal(905, _10476, _10551, _10559);
    _10559 = NOVALUE;

    /** eds.e:2430			return -1*/
    DeRef(_table_name_18925);
    DeRef(_data_ptr_18926);
    DeRef(_data_value_18927);
    DeRef(_10555);
    _10555 = NOVALUE;
    return -1;
L5: 

    /** eds.e:2433		io:seek(current_db, key_pointers[key_location])*/
    _2 = (object)SEQ_PTR(_43key_pointers_16834);
    _10560 = (object)*(((s1_ptr)_2)->base + _key_location_18924);
    Ref(_10560);
    DeRef(_pos_inlined_seek_at_123_18947);
    _pos_inlined_seek_at_123_18947 = _10560;
    _10560 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_123_18947);
    DeRef(_seek_1__tmp_at126_18949);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_16827;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_123_18947;
    _seek_1__tmp_at126_18949 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_126_18948 = machine(19, _seek_1__tmp_at126_18949);
    DeRef(_pos_inlined_seek_at_123_18947);
    _pos_inlined_seek_at_123_18947 = NOVALUE;
    DeRef(_seek_1__tmp_at126_18949);
    _seek_1__tmp_at126_18949 = NOVALUE;

    /** eds.e:2434		if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_43vLastErrors_16851)){
            _10561 = SEQ_PTR(_43vLastErrors_16851)->length;
    }
    else {
        _10561 = 1;
    }
    if (_10561 <= 0)
    goto L6; // [147] 156
    DeRef(_table_name_18925);
    DeRef(_data_ptr_18926);
    DeRef(_data_value_18927);
    DeRef(_10555);
    _10555 = NOVALUE;
    return -1;
L6: 

    /** eds.e:2435		data_ptr = get4()*/
    _0 = _data_ptr_18926;
    _data_ptr_18926 = _43get4();
    DeRef(_0);

    /** eds.e:2436		io:seek(current_db, data_ptr)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_data_ptr_18926);
    DeRef(_seek_1__tmp_at164_18956);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_16827;
    ((intptr_t *)_2)[2] = _data_ptr_18926;
    _seek_1__tmp_at164_18956 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_164_18955 = machine(19, _seek_1__tmp_at164_18956);
    DeRef(_seek_1__tmp_at164_18956);
    _seek_1__tmp_at164_18956 = NOVALUE;

    /** eds.e:2437		data_value = decompress(0)*/
    _0 = _data_value_18927;
    _data_value_18927 = _43decompress(0);
    DeRef(_0);

    /** eds.e:2439		return data_value*/
    DeRef(_table_name_18925);
    DeRef(_data_ptr_18926);
    DeRef(_10555);
    _10555 = NOVALUE;
    return _data_value_18927;
    ;
}


object _43db_fetch_record(object _key_18960, object _table_name_18961)
{
    object _pos_18962 = NOVALUE;
    object _10567 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2481		pos = db_find_key(key, table_name)*/
    Ref(_key_18960);
    RefDS(_table_name_18961);
    _pos_18962 = _43db_find_key(_key_18960, _table_name_18961);
    if (!IS_ATOM_INT(_pos_18962)) {
        _1 = (object)(DBL_PTR(_pos_18962)->dbl);
        DeRefDS(_pos_18962);
        _pos_18962 = _1;
    }

    /** eds.e:2482		if pos > 0 then*/
    if (_pos_18962 <= 0)
    goto L1; // [12] 30

    /** eds.e:2483			return db_record_data(pos, table_name)*/
    RefDS(_table_name_18961);
    _10567 = _43db_record_data(_pos_18962, _table_name_18961);
    DeRef(_key_18960);
    DeRefDS(_table_name_18961);
    return _10567;
    goto L2; // [27] 37
L1: 

    /** eds.e:2485			return pos*/
    DeRef(_key_18960);
    DeRef(_table_name_18961);
    DeRef(_10567);
    _10567 = NOVALUE;
    return _pos_18962;
L2: 
    ;
}


object _43db_record_key(object _key_location_18970, object _table_name_18971)
{
    object _10582 = NOVALUE;
    object _10581 = NOVALUE;
    object _10580 = NOVALUE;
    object _10579 = NOVALUE;
    object _10578 = NOVALUE;
    object _10576 = NOVALUE;
    object _10575 = NOVALUE;
    object _10573 = NOVALUE;
    object _10570 = NOVALUE;
    object _10568 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_18970)) {
        _1 = (object)(DBL_PTR(_key_location_18970)->dbl);
        DeRefDS(_key_location_18970);
        _key_location_18970 = _1;
    }

    /** eds.e:2519		if not equal(table_name, current_table_name) then*/
    if (_table_name_18971 == _43current_table_name_16829)
    _10568 = 1;
    else if (IS_ATOM_INT(_table_name_18971) && IS_ATOM_INT(_43current_table_name_16829))
    _10568 = 0;
    else
    _10568 = (compare(_table_name_18971, _43current_table_name_16829) == 0);
    if (_10568 != 0)
    goto L1; // [11] 44
    _10568 = NOVALUE;

    /** eds.e:2520			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_18971);
    _10570 = _43db_select_table(_table_name_18971);
    if (binary_op_a(EQUALS, _10570, 0)){
        DeRef(_10570);
        _10570 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10570);
    _10570 = NOVALUE;

    /** eds.e:2521				fatal(NO_TABLE, "invalid table name given", "db_record_key", {key_location, table_name})*/
    RefDS(_table_name_18971);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_18970;
    ((intptr_t *)_2)[2] = _table_name_18971;
    _10573 = MAKE_SEQ(_1);
    RefDS(_10348);
    RefDS(_10572);
    _43fatal(903, _10348, _10572, _10573);
    _10573 = NOVALUE;

    /** eds.e:2522				return -1*/
    DeRefDS(_table_name_18971);
    return -1;
L2: 
L1: 

    /** eds.e:2526		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _43current_table_pos_16828, -1)){
        goto L3; // [48] 71
    }

    /** eds.e:2527			fatal(NO_TABLE, "no table selected", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_18971);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_18970;
    ((intptr_t *)_2)[2] = _table_name_18971;
    _10575 = MAKE_SEQ(_1);
    RefDS(_10352);
    RefDS(_10572);
    _43fatal(903, _10352, _10572, _10575);
    _10575 = NOVALUE;

    /** eds.e:2528			return -1*/
    DeRef(_table_name_18971);
    return -1;
L3: 

    /** eds.e:2530		if key_location < 1 or key_location > length(key_pointers) then*/
    _10576 = (_key_location_18970 < 1);
    if (_10576 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_43key_pointers_16834)){
            _10578 = SEQ_PTR(_43key_pointers_16834)->length;
    }
    else {
        _10578 = 1;
    }
    _10579 = (_key_location_18970 > _10578);
    _10578 = NOVALUE;
    if (_10579 == 0)
    {
        DeRef(_10579);
        _10579 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10579);
        _10579 = NOVALUE;
    }
L4: 

    /** eds.e:2531			fatal(BAD_RECNO, "bad record number", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_18971);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_18970;
    ((intptr_t *)_2)[2] = _table_name_18971;
    _10580 = MAKE_SEQ(_1);
    RefDS(_10476);
    RefDS(_10572);
    _43fatal(905, _10476, _10572, _10580);
    _10580 = NOVALUE;

    /** eds.e:2532			return -1*/
    DeRef(_table_name_18971);
    DeRef(_10576);
    _10576 = NOVALUE;
    return -1;
L5: 

    /** eds.e:2534		return key_value(key_pointers[key_location])*/
    _2 = (object)SEQ_PTR(_43key_pointers_16834);
    _10581 = (object)*(((s1_ptr)_2)->base + _key_location_18970);
    Ref(_10581);
    _10582 = _43key_value(_10581);
    _10581 = NOVALUE;
    DeRef(_table_name_18971);
    DeRef(_10576);
    _10576 = NOVALUE;
    return _10582;
    ;
}



// 0x5B0D9F1F
