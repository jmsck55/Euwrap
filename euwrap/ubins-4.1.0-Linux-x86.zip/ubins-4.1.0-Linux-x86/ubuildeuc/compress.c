// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _60compress(object _x_22563)
{
    object _x4_22564 = NOVALUE;
    object _s_22565 = NOVALUE;
    object _12754 = NOVALUE;
    object _12753 = NOVALUE;
    object _12752 = NOVALUE;
    object _12750 = NOVALUE;
    object _12749 = NOVALUE;
    object _12747 = NOVALUE;
    object _12745 = NOVALUE;
    object _12744 = NOVALUE;
    object _12743 = NOVALUE;
    object _12742 = NOVALUE;
    object _12740 = NOVALUE;
    object _12738 = NOVALUE;
    object _12736 = NOVALUE;
    object _12734 = NOVALUE;
    object _12733 = NOVALUE;
    object _12732 = NOVALUE;
    object _12730 = NOVALUE;
    object _12729 = NOVALUE;
    object _12728 = NOVALUE;
    object _12727 = NOVALUE;
    object _12726 = NOVALUE;
    object _12725 = NOVALUE;
    object _12724 = NOVALUE;
    object _12723 = NOVALUE;
    object _12722 = NOVALUE;
    object _12721 = NOVALUE;
    object _12719 = NOVALUE;
    object _12718 = NOVALUE;
    object _12717 = NOVALUE;
    object _12716 = NOVALUE;
    object _12715 = NOVALUE;
    object _12714 = NOVALUE;
    object _12712 = NOVALUE;
    object _12711 = NOVALUE;
    object _12710 = NOVALUE;
    object _12709 = NOVALUE;
    object _12708 = NOVALUE;
    object _12707 = NOVALUE;
    object _12706 = NOVALUE;
    object _12705 = NOVALUE;
    object _12704 = NOVALUE;
    object _0, _1, _2;
    

    /** compress.e:59		if integer(x) then*/
    if (IS_ATOM_INT(_x_22563))
    _12704 = 1;
    else if (IS_ATOM_DBL(_x_22563))
    _12704 = IS_ATOM_INT(DoubleToInt(_x_22563));
    else
    _12704 = 0;
    if (_12704 == 0)
    {
        _12704 = NOVALUE;
        goto L1; // [6] 220
    }
    else{
        _12704 = NOVALUE;
    }

    /** compress.e:60			if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_22563)) {
        _12705 = (_x_22563 >= -2);
    }
    else {
        _12705 = binary_op(GREATEREQ, _x_22563, -2);
    }
    if (IS_ATOM_INT(_12705)) {
        if (_12705 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_12705)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_22563)) {
        _12707 = (_x_22563 <= 244);
    }
    else {
        _12707 = binary_op(LESSEQ, _x_22563, 244);
    }
    if (_12707 == 0) {
        DeRef(_12707);
        _12707 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_12707) && DBL_PTR(_12707)->dbl == 0.0){
            DeRef(_12707);
            _12707 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_12707);
        _12707 = NOVALUE;
    }
    DeRef(_12707);
    _12707 = NOVALUE;

    /** compress.e:61				return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_22563)) {
        _12708 = _x_22563 - -2;
        if ((object)((uintptr_t)_12708 +(uintptr_t) HIGH_BITS) >= 0){
            _12708 = NewDouble((eudouble)_12708);
        }
    }
    else {
        _12708 = binary_op(MINUS, _x_22563, -2);
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _12708;
    _12709 = MAKE_SEQ(_1);
    _12708 = NOVALUE;
    DeRef(_x_22563);
    DeRef(_x4_22564);
    DeRef(_s_22565);
    DeRef(_12705);
    _12705 = NOVALUE;
    return _12709;
    goto L3; // [41] 389
L2: 

    /** compress.e:63			elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_22563)) {
        _12710 = (_x_22563 >= _60MIN2B_22537);
    }
    else {
        _12710 = binary_op(GREATEREQ, _x_22563, _60MIN2B_22537);
    }
    if (IS_ATOM_INT(_12710)) {
        if (_12710 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_12710)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_22563)) {
        _12712 = (_x_22563 <= 32767);
    }
    else {
        _12712 = binary_op(LESSEQ, _x_22563, 32767);
    }
    if (_12712 == 0) {
        DeRef(_12712);
        _12712 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_12712) && DBL_PTR(_12712)->dbl == 0.0){
            DeRef(_12712);
            _12712 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_12712);
        _12712 = NOVALUE;
    }
    DeRef(_12712);
    _12712 = NOVALUE;

    /** compress.e:64				x -= MIN2B*/
    _0 = _x_22563;
    if (IS_ATOM_INT(_x_22563)) {
        _x_22563 = _x_22563 - _60MIN2B_22537;
        if ((object)((uintptr_t)_x_22563 +(uintptr_t) HIGH_BITS) >= 0){
            _x_22563 = NewDouble((eudouble)_x_22563);
        }
    }
    else {
        _x_22563 = binary_op(MINUS, _x_22563, _60MIN2B_22537);
    }
    DeRef(_0);

    /** compress.e:65				return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_22563)) {
        {uintptr_t tu;
             tu = (uintptr_t)_x_22563 & (uintptr_t)255;
             _12714 = MAKE_UINT(tu);
        }
    }
    else {
        _12714 = binary_op(AND_BITS, _x_22563, 255);
    }
    if (IS_ATOM_INT(_x_22563)) {
        if (256 > 0 && _x_22563 >= 0) {
            _12715 = _x_22563 / 256;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_22563 / (eudouble)256);
            if (_x_22563 != MININT)
            _12715 = (object)temp_dbl;
            else
            _12715 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22563, 256);
        _12715 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 247;
    ((intptr_t*)_2)[2] = _12714;
    ((intptr_t*)_2)[3] = _12715;
    _12716 = MAKE_SEQ(_1);
    _12715 = NOVALUE;
    _12714 = NOVALUE;
    DeRef(_x_22563);
    DeRef(_x4_22564);
    DeRef(_s_22565);
    DeRef(_12710);
    _12710 = NOVALUE;
    DeRef(_12709);
    _12709 = NOVALUE;
    DeRef(_12705);
    _12705 = NOVALUE;
    return _12716;
    goto L3; // [94] 389
L4: 

    /** compress.e:67			elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_22563)) {
        _12717 = (_x_22563 >= _60MIN3B_22543);
    }
    else {
        _12717 = binary_op(GREATEREQ, _x_22563, _60MIN3B_22543);
    }
    if (IS_ATOM_INT(_12717)) {
        if (_12717 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_12717)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_22563)) {
        _12719 = (_x_22563 <= 8388607);
    }
    else {
        _12719 = binary_op(LESSEQ, _x_22563, 8388607);
    }
    if (_12719 == 0) {
        DeRef(_12719);
        _12719 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_12719) && DBL_PTR(_12719)->dbl == 0.0){
            DeRef(_12719);
            _12719 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_12719);
        _12719 = NOVALUE;
    }
    DeRef(_12719);
    _12719 = NOVALUE;

    /** compress.e:68				x -= MIN3B*/
    _0 = _x_22563;
    if (IS_ATOM_INT(_x_22563)) {
        _x_22563 = _x_22563 - _60MIN3B_22543;
        if ((object)((uintptr_t)_x_22563 +(uintptr_t) HIGH_BITS) >= 0){
            _x_22563 = NewDouble((eudouble)_x_22563);
        }
    }
    else {
        _x_22563 = binary_op(MINUS, _x_22563, _60MIN3B_22543);
    }
    DeRef(_0);

    /** compress.e:69				return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_22563)) {
        {uintptr_t tu;
             tu = (uintptr_t)_x_22563 & (uintptr_t)255;
             _12721 = MAKE_UINT(tu);
        }
    }
    else {
        _12721 = binary_op(AND_BITS, _x_22563, 255);
    }
    if (IS_ATOM_INT(_x_22563)) {
        if (256 > 0 && _x_22563 >= 0) {
            _12722 = _x_22563 / 256;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_22563 / (eudouble)256);
            if (_x_22563 != MININT)
            _12722 = (object)temp_dbl;
            else
            _12722 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22563, 256);
        _12722 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_12722)) {
        {uintptr_t tu;
             tu = (uintptr_t)_12722 & (uintptr_t)255;
             _12723 = MAKE_UINT(tu);
        }
    }
    else {
        _12723 = binary_op(AND_BITS, _12722, 255);
    }
    DeRef(_12722);
    _12722 = NOVALUE;
    if (IS_ATOM_INT(_x_22563)) {
        if (65536 > 0 && _x_22563 >= 0) {
            _12724 = _x_22563 / 65536;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_22563 / (eudouble)65536);
            if (_x_22563 != MININT)
            _12724 = (object)temp_dbl;
            else
            _12724 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22563, 65536);
        _12724 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 248;
    ((intptr_t*)_2)[2] = _12721;
    ((intptr_t*)_2)[3] = _12723;
    ((intptr_t*)_2)[4] = _12724;
    _12725 = MAKE_SEQ(_1);
    _12724 = NOVALUE;
    _12723 = NOVALUE;
    _12721 = NOVALUE;
    DeRef(_x_22563);
    DeRef(_x4_22564);
    DeRef(_s_22565);
    DeRef(_12710);
    _12710 = NOVALUE;
    DeRef(_12709);
    _12709 = NOVALUE;
    DeRef(_12716);
    _12716 = NOVALUE;
    DeRef(_12705);
    _12705 = NOVALUE;
    DeRef(_12717);
    _12717 = NOVALUE;
    return _12725;
    goto L3; // [156] 389
L5: 

    /** compress.e:71			elsif x >= MIN4B and x <= MAX4B then*/
    if (IS_ATOM_INT(_x_22563) && IS_ATOM_INT(_60MIN4B_22549)) {
        _12726 = (_x_22563 >= _60MIN4B_22549);
    }
    else {
        _12726 = binary_op(GREATEREQ, _x_22563, _60MIN4B_22549);
    }
    if (IS_ATOM_INT(_12726)) {
        if (_12726 == 0) {
            goto L6; // [167] 199
        }
    }
    else {
        if (DBL_PTR(_12726)->dbl == 0.0) {
            goto L6; // [167] 199
        }
    }
    if (IS_ATOM_INT(_x_22563) && IS_ATOM_INT(_60MAX4B_22552)) {
        _12728 = (_x_22563 <= _60MAX4B_22552);
    }
    else {
        _12728 = binary_op(LESSEQ, _x_22563, _60MAX4B_22552);
    }
    if (_12728 == 0) {
        DeRef(_12728);
        _12728 = NOVALUE;
        goto L6; // [178] 199
    }
    else {
        if (!IS_ATOM_INT(_12728) && DBL_PTR(_12728)->dbl == 0.0){
            DeRef(_12728);
            _12728 = NOVALUE;
            goto L6; // [178] 199
        }
        DeRef(_12728);
        _12728 = NOVALUE;
    }
    DeRef(_12728);
    _12728 = NOVALUE;

    /** compress.e:72				return I4B & int_to_bytes(x)*/
    Ref(_x_22563);
    _12729 = _15int_to_bytes(_x_22563, 4);
    if (IS_SEQUENCE(249) && IS_ATOM(_12729)) {
    }
    else if (IS_ATOM(249) && IS_SEQUENCE(_12729)) {
        Prepend(&_12730, _12729, 249);
    }
    else {
        Concat((object_ptr)&_12730, 249, _12729);
    }
    DeRef(_12729);
    _12729 = NOVALUE;
    DeRef(_x_22563);
    DeRef(_x4_22564);
    DeRef(_s_22565);
    DeRef(_12710);
    _12710 = NOVALUE;
    DeRef(_12709);
    _12709 = NOVALUE;
    DeRef(_12726);
    _12726 = NOVALUE;
    DeRef(_12716);
    _12716 = NOVALUE;
    DeRef(_12705);
    _12705 = NOVALUE;
    DeRef(_12725);
    _12725 = NOVALUE;
    DeRef(_12717);
    _12717 = NOVALUE;
    return _12730;
    goto L3; // [196] 389
L6: 

    /** compress.e:75				ifdef EU4_0 then*/

    /** compress.e:79					return I8B & int_to_bytes(x, 8)*/
    Ref(_x_22563);
    _12732 = _15int_to_bytes(_x_22563, 8);
    if (IS_SEQUENCE(250) && IS_ATOM(_12732)) {
    }
    else if (IS_ATOM(250) && IS_SEQUENCE(_12732)) {
        Prepend(&_12733, _12732, 250);
    }
    else {
        Concat((object_ptr)&_12733, 250, _12732);
    }
    DeRef(_12732);
    _12732 = NOVALUE;
    DeRef(_x_22563);
    DeRef(_x4_22564);
    DeRef(_s_22565);
    DeRef(_12730);
    _12730 = NOVALUE;
    DeRef(_12710);
    _12710 = NOVALUE;
    DeRef(_12709);
    _12709 = NOVALUE;
    DeRef(_12726);
    _12726 = NOVALUE;
    DeRef(_12716);
    _12716 = NOVALUE;
    DeRef(_12705);
    _12705 = NOVALUE;
    DeRef(_12725);
    _12725 = NOVALUE;
    DeRef(_12717);
    _12717 = NOVALUE;
    return _12733;
    goto L3; // [217] 389
L1: 

    /** compress.e:83		elsif atom(x) then*/
    _12734 = IS_ATOM(_x_22563);
    if (_12734 == 0)
    {
        _12734 = NOVALUE;
        goto L7; // [225] 309
    }
    else{
        _12734 = NOVALUE;
    }

    /** compress.e:85			x4 = atom_to_float32(x)*/
    Ref(_x_22563);
    _0 = _x4_22564;
    _x4_22564 = _15atom_to_float32(_x_22563);
    DeRef(_0);

    /** compress.e:86			if x = float32_to_atom(x4) then*/
    RefDS(_x4_22564);
    _12736 = _15float32_to_atom(_x4_22564);
    if (binary_op_a(NOTEQ, _x_22563, _12736)){
        DeRef(_12736);
        _12736 = NOVALUE;
        goto L8; // [242] 259
    }
    DeRef(_12736);
    _12736 = NOVALUE;

    /** compress.e:88				return F4B & x4*/
    Prepend(&_12738, _x4_22564, 251);
    DeRef(_x_22563);
    DeRefDS(_x4_22564);
    DeRef(_s_22565);
    DeRef(_12730);
    _12730 = NOVALUE;
    DeRef(_12733);
    _12733 = NOVALUE;
    DeRef(_12710);
    _12710 = NOVALUE;
    DeRef(_12709);
    _12709 = NOVALUE;
    DeRef(_12726);
    _12726 = NOVALUE;
    DeRef(_12716);
    _12716 = NOVALUE;
    DeRef(_12705);
    _12705 = NOVALUE;
    DeRef(_12725);
    _12725 = NOVALUE;
    DeRef(_12717);
    _12717 = NOVALUE;
    return _12738;
    goto L3; // [256] 389
L8: 

    /** compress.e:90				x4 = atom_to_float64( x )*/
    Ref(_x_22563);
    _0 = _x4_22564;
    _x4_22564 = _15atom_to_float64(_x_22563);
    DeRef(_0);

    /** compress.e:91				if x = float64_to_atom( x4 ) then*/
    RefDS(_x4_22564);
    _12740 = _15float64_to_atom(_x4_22564);
    if (binary_op_a(NOTEQ, _x_22563, _12740)){
        DeRef(_12740);
        _12740 = NOVALUE;
        goto L9; // [273] 290
    }
    DeRef(_12740);
    _12740 = NOVALUE;

    /** compress.e:92					return F8B & x4*/
    Prepend(&_12742, _x4_22564, 252);
    DeRef(_x_22563);
    DeRefDS(_x4_22564);
    DeRef(_s_22565);
    DeRef(_12730);
    _12730 = NOVALUE;
    DeRef(_12733);
    _12733 = NOVALUE;
    DeRef(_12710);
    _12710 = NOVALUE;
    DeRef(_12709);
    _12709 = NOVALUE;
    DeRef(_12726);
    _12726 = NOVALUE;
    DeRef(_12716);
    _12716 = NOVALUE;
    DeRef(_12738);
    _12738 = NOVALUE;
    DeRef(_12705);
    _12705 = NOVALUE;
    DeRef(_12725);
    _12725 = NOVALUE;
    DeRef(_12717);
    _12717 = NOVALUE;
    return _12742;
    goto L3; // [287] 389
L9: 

    /** compress.e:94					return F10B & atom_to_float80( x )*/
    Ref(_x_22563);
    _12743 = _15atom_to_float80(_x_22563);
    if (IS_SEQUENCE(253) && IS_ATOM(_12743)) {
    }
    else if (IS_ATOM(253) && IS_SEQUENCE(_12743)) {
        Prepend(&_12744, _12743, 253);
    }
    else {
        Concat((object_ptr)&_12744, 253, _12743);
    }
    DeRef(_12743);
    _12743 = NOVALUE;
    DeRef(_x_22563);
    DeRef(_x4_22564);
    DeRef(_s_22565);
    DeRef(_12730);
    _12730 = NOVALUE;
    DeRef(_12733);
    _12733 = NOVALUE;
    DeRef(_12710);
    _12710 = NOVALUE;
    DeRef(_12742);
    _12742 = NOVALUE;
    DeRef(_12709);
    _12709 = NOVALUE;
    DeRef(_12726);
    _12726 = NOVALUE;
    DeRef(_12716);
    _12716 = NOVALUE;
    DeRef(_12738);
    _12738 = NOVALUE;
    DeRef(_12705);
    _12705 = NOVALUE;
    DeRef(_12725);
    _12725 = NOVALUE;
    DeRef(_12717);
    _12717 = NOVALUE;
    return _12744;
    goto L3; // [306] 389
L7: 

    /** compress.e:100			if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_22563)){
            _12745 = SEQ_PTR(_x_22563)->length;
    }
    else {
        _12745 = 1;
    }
    if (_12745 > 255)
    goto LA; // [314] 330

    /** compress.e:101				s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_22563)){
            _12747 = SEQ_PTR(_x_22563)->length;
    }
    else {
        _12747 = 1;
    }
    DeRef(_s_22565);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 254;
    ((intptr_t *)_2)[2] = _12747;
    _s_22565 = MAKE_SEQ(_1);
    _12747 = NOVALUE;
    goto LB; // [327] 345
LA: 

    /** compress.e:103				s = S4B & int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_22563)){
            _12749 = SEQ_PTR(_x_22563)->length;
    }
    else {
        _12749 = 1;
    }
    _12750 = _15int_to_bytes(_12749, 4);
    _12749 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_12750)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_12750)) {
        Prepend(&_s_22565, _12750, 255);
    }
    else {
        Concat((object_ptr)&_s_22565, 255, _12750);
    }
    DeRef(_12750);
    _12750 = NOVALUE;
LB: 

    /** compress.e:105			for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_22563)){
            _12752 = SEQ_PTR(_x_22563)->length;
    }
    else {
        _12752 = 1;
    }
    {
        object _i_22637;
        _i_22637 = 1;
LC: 
        if (_i_22637 > _12752){
            goto LD; // [350] 380
        }

        /** compress.e:106				s &= compress(x[i])*/
        _2 = (object)SEQ_PTR(_x_22563);
        _12753 = (object)*(((s1_ptr)_2)->base + _i_22637);
        Ref(_12753);
        _12754 = _60compress(_12753);
        _12753 = NOVALUE;
        if (IS_SEQUENCE(_s_22565) && IS_ATOM(_12754)) {
            Ref(_12754);
            Append(&_s_22565, _s_22565, _12754);
        }
        else if (IS_ATOM(_s_22565) && IS_SEQUENCE(_12754)) {
        }
        else {
            Concat((object_ptr)&_s_22565, _s_22565, _12754);
        }
        DeRef(_12754);
        _12754 = NOVALUE;

        /** compress.e:107			end for*/
        _i_22637 = _i_22637 + 1;
        goto LC; // [375] 357
LD: 
        ;
    }

    /** compress.e:108			return s*/
    DeRef(_x_22563);
    DeRef(_x4_22564);
    DeRef(_12730);
    _12730 = NOVALUE;
    DeRef(_12733);
    _12733 = NOVALUE;
    DeRef(_12710);
    _12710 = NOVALUE;
    DeRef(_12742);
    _12742 = NOVALUE;
    DeRef(_12709);
    _12709 = NOVALUE;
    DeRef(_12726);
    _12726 = NOVALUE;
    DeRef(_12716);
    _12716 = NOVALUE;
    DeRef(_12738);
    _12738 = NOVALUE;
    DeRef(_12705);
    _12705 = NOVALUE;
    DeRef(_12725);
    _12725 = NOVALUE;
    DeRef(_12744);
    _12744 = NOVALUE;
    DeRef(_12717);
    _12717 = NOVALUE;
    return _s_22565;
L3: 
    ;
}



// 0x756500A6
