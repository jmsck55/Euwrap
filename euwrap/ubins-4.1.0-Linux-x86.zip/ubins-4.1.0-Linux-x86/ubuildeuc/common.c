// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _37open_locked(object _file_path_15436)
{
    object _fh_15437 = NOVALUE;
    object _0, _1, _2;
    

    /** common.e:55		fh = open(file_path, "u")*/
    _fh_15437 = EOpen(_file_path_15436, _8622, 0);

    /** common.e:57		if fh = -1 then*/
    if (_fh_15437 != -1)
    goto L1; // [12] 24

    /** common.e:58			fh = open(file_path, "r")*/
    _fh_15437 = EOpen(_file_path_15436, _3866, 0);
L1: 

    /** common.e:61		return fh*/
    DeRefDS(_file_path_15436);
    return _fh_15437;
    ;
}


object _37get_eudir()
{
    object _possible_paths_15450 = NOVALUE;
    object _home_15455 = NOVALUE;
    object _possible_path_15469 = NOVALUE;
    object _possible_path_15483 = NOVALUE;
    object _file_check_15497 = NOVALUE;
    object _8663 = NOVALUE;
    object _8662 = NOVALUE;
    object _8661 = NOVALUE;
    object _8659 = NOVALUE;
    object _8657 = NOVALUE;
    object _8655 = NOVALUE;
    object _8654 = NOVALUE;
    object _8653 = NOVALUE;
    object _8652 = NOVALUE;
    object _8651 = NOVALUE;
    object _8649 = NOVALUE;
    object _8647 = NOVALUE;
    object _8646 = NOVALUE;
    object _8642 = NOVALUE;
    object _8636 = NOVALUE;
    object _8634 = NOVALUE;
    object _8628 = NOVALUE;
    object _8626 = NOVALUE;
    object _0, _1, _2;
    

    /** common.e:82		if sequence(eudir) then*/
    _8626 = IS_SEQUENCE(_37eudir_15432);
    if (_8626 == 0)
    {
        _8626 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _8626 = NOVALUE;
    }

    /** common.e:83			return eudir*/
    Ref(_37eudir_15432);
    DeRef(_possible_paths_15450);
    DeRefi(_home_15455);
    return _37eudir_15432;
L1: 

    /** common.e:86		eudir = getenv("EUDIR")*/
    DeRef(_37eudir_15432);
    _37eudir_15432 = EGetEnv(_3779);

    /** common.e:87		if sequence(eudir) then*/
    _8628 = IS_SEQUENCE(_37eudir_15432);
    if (_8628 == 0)
    {
        _8628 = NOVALUE;
        goto L2; // [32] 44
    }
    else{
        _8628 = NOVALUE;
    }

    /** common.e:88			return eudir*/
    Ref(_37eudir_15432);
    DeRef(_possible_paths_15450);
    DeRefi(_home_15455);
    return _37eudir_15432;
L2: 

    /** common.e:91		ifdef UNIX then*/

    /** common.e:92			sequence possible_paths = {*/
    _0 = _possible_paths_15450;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_8629);
    ((intptr_t*)_2)[1] = _8629;
    RefDS(_8630);
    ((intptr_t*)_2)[2] = _8630;
    RefDS(_8631);
    ((intptr_t*)_2)[3] = _8631;
    _possible_paths_15450 = MAKE_SEQ(_1);
    DeRef(_0);

    /** common.e:97			object home = getenv("HOME")*/
    DeRefi(_home_15455);
    _home_15455 = EGetEnv(_3424);

    /** common.e:98			if sequence(home) then*/
    _8634 = IS_SEQUENCE(_home_15455);
    if (_8634 == 0)
    {
        _8634 = NOVALUE;
        goto L3; // [64] 78
    }
    else{
        _8634 = NOVALUE;
    }

    /** common.e:99				possible_paths = append(possible_paths, home & "/euphoria")*/
    if (IS_SEQUENCE(_home_15455) && IS_ATOM(_8635)) {
    }
    else if (IS_ATOM(_home_15455) && IS_SEQUENCE(_8635)) {
        Ref(_home_15455);
        Prepend(&_8636, _8635, _home_15455);
    }
    else {
        Concat((object_ptr)&_8636, _home_15455, _8635);
    }
    RefDS(_8636);
    Append(&_possible_paths_15450, _possible_paths_15450, _8636);
    DeRefDS(_8636);
    _8636 = NOVALUE;
L3: 

    /** common.e:118		for i = 1 to length(possible_paths) do*/
    if (IS_SEQUENCE(_possible_paths_15450)){
            _8642 = SEQ_PTR(_possible_paths_15450)->length;
    }
    else {
        _8642 = 1;
    }
    {
        object _i_15467;
        _i_15467 = 1;
L4: 
        if (_i_15467 > _8642){
            goto L5; // [85] 144
        }

        /** common.e:119			sequence possible_path = possible_paths[i]*/
        DeRef(_possible_path_15469);
        _2 = (object)SEQ_PTR(_possible_paths_15450);
        _possible_path_15469 = (object)*(((s1_ptr)_2)->base + _i_15467);
        RefDS(_possible_path_15469);

        /** common.e:121			if file_exists(possible_path & SLASH & "include" & SLASH & "euphoria.h") then*/
        {
            object concat_list[5];

            concat_list[0] = _8645;
            concat_list[1] = 47;
            concat_list[2] = _8644;
            concat_list[3] = 47;
            concat_list[4] = _possible_path_15469;
            Concat_N((object_ptr)&_8646, concat_list, 5);
        }
        _8647 = _17file_exists(_8646);
        _8646 = NOVALUE;
        if (_8647 == 0) {
            DeRef(_8647);
            _8647 = NOVALUE;
            goto L6; // [118] 135
        }
        else {
            if (!IS_ATOM_INT(_8647) && DBL_PTR(_8647)->dbl == 0.0){
                DeRef(_8647);
                _8647 = NOVALUE;
                goto L6; // [118] 135
            }
            DeRef(_8647);
            _8647 = NOVALUE;
        }
        DeRef(_8647);
        _8647 = NOVALUE;

        /** common.e:122				eudir = possible_path*/
        RefDS(_possible_path_15469);
        DeRef(_37eudir_15432);
        _37eudir_15432 = _possible_path_15469;

        /** common.e:123				return eudir*/
        RefDS(_37eudir_15432);
        DeRefDS(_possible_path_15469);
        DeRefDS(_possible_paths_15450);
        DeRefi(_home_15455);
        return _37eudir_15432;
L6: 
        DeRef(_possible_path_15469);
        _possible_path_15469 = NOVALUE;

        /** common.e:125		end for*/
        _i_15467 = _i_15467 + 1;
        goto L4; // [139] 92
L5: 
        ;
    }

    /** common.e:127		possible_paths = include_paths(0)*/
    _0 = _possible_paths_15450;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_3804);
    ((intptr_t*)_2)[1] = _3804;
    RefDS(_3803);
    ((intptr_t*)_2)[2] = _3803;
    _possible_paths_15450 = MAKE_SEQ(_1);
    DeRef(_0);

    /** common.e:128		for i = 1 to length(possible_paths) do*/
    _8649 = 2;
    {
        object _i_15481;
        _i_15481 = 1;
L7: 
        if (_i_15481 > 2){
            goto L8; // [156] 281
        }

        /** common.e:129			sequence possible_path = possible_paths[i]*/
        DeRef(_possible_path_15483);
        _2 = (object)SEQ_PTR(_possible_paths_15450);
        _possible_path_15483 = (object)*(((s1_ptr)_2)->base + _i_15481);
        RefDS(_possible_path_15483);

        /** common.e:130			if equal(possible_path[$], SLASH) then*/
        if (IS_SEQUENCE(_possible_path_15483)){
                _8651 = SEQ_PTR(_possible_path_15483)->length;
        }
        else {
            _8651 = 1;
        }
        _2 = (object)SEQ_PTR(_possible_path_15483);
        _8652 = (object)*(((s1_ptr)_2)->base + _8651);
        if (_8652 == 47)
        _8653 = 1;
        else if (IS_ATOM_INT(_8652) && IS_ATOM_INT(47))
        _8653 = 0;
        else
        _8653 = (compare(_8652, 47) == 0);
        _8652 = NOVALUE;
        if (_8653 == 0)
        {
            _8653 = NOVALUE;
            goto L9; // [186] 204
        }
        else{
            _8653 = NOVALUE;
        }

        /** common.e:131				possible_path = possible_path[1..$-1]*/
        if (IS_SEQUENCE(_possible_path_15483)){
                _8654 = SEQ_PTR(_possible_path_15483)->length;
        }
        else {
            _8654 = 1;
        }
        _8655 = _8654 - 1;
        _8654 = NOVALUE;
        rhs_slice_target = (object_ptr)&_possible_path_15483;
        RHS_Slice(_possible_path_15483, 1, _8655);
L9: 

        /** common.e:134			if not ends("include", possible_path) then*/
        RefDS(_8644);
        RefDS(_possible_path_15483);
        _8657 = _16ends(_8644, _possible_path_15483);
        if (IS_ATOM_INT(_8657)) {
            if (_8657 != 0){
                DeRef(_8657);
                _8657 = NOVALUE;
                goto LA; // [211] 221
            }
        }
        else {
            if (DBL_PTR(_8657)->dbl != 0.0){
                DeRef(_8657);
                _8657 = NOVALUE;
                goto LA; // [211] 221
            }
        }
        DeRef(_8657);
        _8657 = NOVALUE;

        /** common.e:135				continue*/
        DeRefDS(_possible_path_15483);
        _possible_path_15483 = NOVALUE;
        DeRef(_file_check_15497);
        _file_check_15497 = NOVALUE;
        goto LB; // [218] 276
LA: 

        /** common.e:138			sequence file_check = possible_path*/
        RefDS(_possible_path_15483);
        DeRef(_file_check_15497);
        _file_check_15497 = _possible_path_15483;

        /** common.e:139			file_check &= SLASH & "euphoria.h"*/
        Prepend(&_8659, _8645, 47);
        Concat((object_ptr)&_file_check_15497, _file_check_15497, _8659);
        DeRefDS(_8659);
        _8659 = NOVALUE;

        /** common.e:141			if file_exists(file_check) then*/
        RefDS(_file_check_15497);
        _8661 = _17file_exists(_file_check_15497);
        if (_8661 == 0) {
            DeRef(_8661);
            _8661 = NOVALUE;
            goto LC; // [246] 272
        }
        else {
            if (!IS_ATOM_INT(_8661) && DBL_PTR(_8661)->dbl == 0.0){
                DeRef(_8661);
                _8661 = NOVALUE;
                goto LC; // [246] 272
            }
            DeRef(_8661);
            _8661 = NOVALUE;
        }
        DeRef(_8661);
        _8661 = NOVALUE;

        /** common.e:142				eudir = possible_path[1..$-8] -- strip SLASH & "include"*/
        if (IS_SEQUENCE(_possible_path_15483)){
                _8662 = SEQ_PTR(_possible_path_15483)->length;
        }
        else {
            _8662 = 1;
        }
        _8663 = _8662 - 8;
        _8662 = NOVALUE;
        rhs_slice_target = (object_ptr)&_37eudir_15432;
        RHS_Slice(_possible_path_15483, 1, _8663);

        /** common.e:143				return eudir*/
        RefDS(_37eudir_15432);
        DeRefDS(_possible_path_15483);
        DeRefDS(_file_check_15497);
        DeRef(_possible_paths_15450);
        DeRefi(_home_15455);
        DeRef(_8655);
        _8655 = NOVALUE;
        _8663 = NOVALUE;
        return _37eudir_15432;
LC: 
        DeRef(_possible_path_15483);
        _possible_path_15483 = NOVALUE;
        DeRef(_file_check_15497);
        _file_check_15497 = NOVALUE;

        /** common.e:145		end for*/
LB: 
        _i_15481 = _i_15481 + 1;
        goto L7; // [276] 163
L8: 
        ;
    }

    /** common.e:147		return ""*/
    RefDS(_5);
    DeRef(_possible_paths_15450);
    DeRefi(_home_15455);
    DeRef(_8655);
    _8655 = NOVALUE;
    DeRef(_8663);
    _8663 = NOVALUE;
    return _5;
    ;
}


void _37set_eudir(object _new_eudir_15509)
{
    object _0, _1, _2;
    

    /** common.e:151		eudir = new_eudir*/
    RefDS(_new_eudir_15509);
    DeRef(_37eudir_15432);
    _37eudir_15432 = _new_eudir_15509;

    /** common.e:152		cmdline_eudir = 1*/
    _37cmdline_eudir_15433 = 1;

    /** common.e:153	end procedure*/
    DeRefDS(_new_eudir_15509);
    return;
    ;
}


object _37is_eudir_from_cmdline()
{
    object _0, _1, _2;
    

    /** common.e:156		return cmdline_eudir*/
    return _37cmdline_eudir_15433;
    ;
}



// 0x8BFA80CB
