// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _6get_ch()
{
    object _6029 = NOVALUE;
    object _6028 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:47		if sequence(input_string) then*/
    _6028 = IS_SEQUENCE(_6input_string_10734);
    if (_6028 == 0)
    {
        _6028 = NOVALUE;
        goto L1; // [8] 56
    }
    else{
        _6028 = NOVALUE;
    }

    /** get.e:48			if string_next <= length(input_string) then*/
    if (IS_SEQUENCE(_6input_string_10734)){
            _6029 = SEQ_PTR(_6input_string_10734)->length;
    }
    else {
        _6029 = 1;
    }
    if (_6string_next_10735 > _6029)
    goto L2; // [20] 47

    /** get.e:49				ch = input_string[string_next]*/
    _2 = (object)SEQ_PTR(_6input_string_10734);
    _6ch_10736 = (object)*(((s1_ptr)_2)->base + _6string_next_10735);
    if (!IS_ATOM_INT(_6ch_10736)){
        _6ch_10736 = (object)DBL_PTR(_6ch_10736)->dbl;
    }

    /** get.e:50				string_next += 1*/
    _6string_next_10735 = _6string_next_10735 + 1;
    goto L3; // [44] 81
L2: 

    /** get.e:52				ch = GET_EOF*/
    _6ch_10736 = -1;
    goto L3; // [53] 81
L1: 

    /** get.e:55			ch = getc(input_file)*/
    if (_6input_file_10733 != last_r_file_no) {
        last_r_file_ptr = which_file(_6input_file_10733, EF_READ);
        last_r_file_no = _6input_file_10733;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _6ch_10736 = getc((FILE*)xstdin);
        }
        else{
            _6ch_10736 = getc(last_r_file_ptr);
        }
    }
    else{
        _6ch_10736 = getc(last_r_file_ptr);
    }

    /** get.e:56			if ch = GET_EOF then*/
    if (_6ch_10736 != -1)
    goto L4; // [67] 80

    /** get.e:57				string_next += 1*/
    _6string_next_10735 = _6string_next_10735 + 1;
L4: 
L3: 

    /** get.e:60	end procedure*/
    return;
    ;
}


object _6escape_char(object _c_10763)
{
    object _i_10764 = NOVALUE;
    object _6041 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:79		i = find(c, ESCAPE_CHARS)*/
    _i_10764 = find_from(_c_10763, _6ESCAPE_CHARS_10757, 1);

    /** get.e:80		if i = 0 then*/
    if (_i_10764 != 0)
    goto L1; // [12] 25

    /** get.e:81			return GET_FAIL*/
    return 1;
    goto L2; // [22] 36
L1: 

    /** get.e:83			return ESCAPED_CHARS[i]*/
    _2 = (object)SEQ_PTR(_6ESCAPED_CHARS_10759);
    _6041 = (object)*(((s1_ptr)_2)->base + _i_10764);
    Ref(_6041);
    return _6041;
L2: 
    ;
}


object _6get_qchar()
{
    object _c_10772 = NOVALUE;
    object _6050 = NOVALUE;
    object _6049 = NOVALUE;
    object _6047 = NOVALUE;
    object _6045 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:92		get_ch()*/
    _6get_ch();

    /** get.e:93		c = ch*/
    _c_10772 = _6ch_10736;

    /** get.e:94		if ch = '\\' then*/
    if (_6ch_10736 != 92)
    goto L1; // [16] 54

    /** get.e:95			get_ch()*/
    _6get_ch();

    /** get.e:96			c = escape_char(ch)*/
    _c_10772 = _6escape_char(_6ch_10736);
    if (!IS_ATOM_INT(_c_10772)) {
        _1 = (object)(DBL_PTR(_c_10772)->dbl);
        DeRefDS(_c_10772);
        _c_10772 = _1;
    }

    /** get.e:97			if c = GET_FAIL then*/
    if (_c_10772 != 1)
    goto L2; // [36] 74

    /** get.e:98				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _6045 = MAKE_SEQ(_1);
    return _6045;
    goto L2; // [51] 74
L1: 

    /** get.e:100		elsif ch = '\'' then*/
    if (_6ch_10736 != 39)
    goto L3; // [58] 73

    /** get.e:101			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _6047 = MAKE_SEQ(_1);
    DeRef(_6045);
    _6045 = NOVALUE;
    return _6047;
L3: 
L2: 

    /** get.e:103		get_ch()*/
    _6get_ch();

    /** get.e:104		if ch != '\'' then*/
    if (_6ch_10736 == 39)
    goto L4; // [82] 99

    /** get.e:105			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _6049 = MAKE_SEQ(_1);
    DeRef(_6047);
    _6047 = NOVALUE;
    DeRef(_6045);
    _6045 = NOVALUE;
    return _6049;
    goto L5; // [96] 114
L4: 

    /** get.e:107			get_ch()*/
    _6get_ch();

    /** get.e:108			return {GET_SUCCESS, c}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _c_10772;
    _6050 = MAKE_SEQ(_1);
    DeRef(_6047);
    _6047 = NOVALUE;
    DeRef(_6049);
    _6049 = NOVALUE;
    DeRef(_6045);
    _6045 = NOVALUE;
    return _6050;
L5: 
    ;
}


object _6get_heredoc(object _terminator_10789)
{
    object _text_10790 = NOVALUE;
    object _ends_at_10791 = NOVALUE;
    object _6065 = NOVALUE;
    object _6064 = NOVALUE;
    object _6063 = NOVALUE;
    object _6062 = NOVALUE;
    object _6061 = NOVALUE;
    object _6058 = NOVALUE;
    object _6056 = NOVALUE;
    object _6055 = NOVALUE;
    object _6054 = NOVALUE;
    object _6053 = NOVALUE;
    object _6051 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:113		sequence text = ""*/
    RefDS(_5);
    DeRefi(_text_10790);
    _text_10790 = _5;

    /** get.e:114		integer ends_at = 1 - length( terminator )*/
    if (IS_SEQUENCE(_terminator_10789)){
            _6051 = SEQ_PTR(_terminator_10789)->length;
    }
    else {
        _6051 = 1;
    }
    _ends_at_10791 = 1 - _6051;
    _6051 = NOVALUE;

    /** get.e:115		while ends_at < 1 or not match( terminator, text, ends_at ) with entry do*/
    goto L1; // [21] 69
L2: 
    _6053 = (_ends_at_10791 < 1);
    if (_6053 != 0) {
        DeRef(_6054);
        _6054 = 1;
        goto L3; // [28] 44
    }
    _6055 = e_match_from(_terminator_10789, _text_10790, _ends_at_10791);
    _6056 = (_6055 == 0);
    _6055 = NOVALUE;
    _6054 = (_6056 != 0);
L3: 
    if (_6054 == 0)
    {
        _6054 = NOVALUE;
        goto L4; // [44] 92
    }
    else{
        _6054 = NOVALUE;
    }

    /** get.e:116			if ch = GET_EOF then*/
    if (_6ch_10736 != -1)
    goto L5; // [51] 66

    /** get.e:117				return { GET_FAIL, 0 }*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _6058 = MAKE_SEQ(_1);
    DeRefDSi(_terminator_10789);
    DeRefi(_text_10790);
    DeRef(_6056);
    _6056 = NOVALUE;
    DeRef(_6053);
    _6053 = NOVALUE;
    return _6058;
L5: 

    /** get.e:119		entry*/
L1: 

    /** get.e:120			get_ch()*/
    _6get_ch();

    /** get.e:121			text &= ch*/
    Append(&_text_10790, _text_10790, _6ch_10736);

    /** get.e:122			ends_at += 1*/
    _ends_at_10791 = _ends_at_10791 + 1;

    /** get.e:123		end while*/
    goto L2; // [89] 24
L4: 

    /** get.e:124		return { GET_SUCCESS, head( text, length( text ) - length( terminator ) ) }*/
    if (IS_SEQUENCE(_text_10790)){
            _6061 = SEQ_PTR(_text_10790)->length;
    }
    else {
        _6061 = 1;
    }
    if (IS_SEQUENCE(_terminator_10789)){
            _6062 = SEQ_PTR(_terminator_10789)->length;
    }
    else {
        _6062 = 1;
    }
    _6063 = _6061 - _6062;
    _6061 = NOVALUE;
    _6062 = NOVALUE;
    {
        int len = SEQ_PTR(_text_10790)->length;
        int size = (IS_ATOM_INT(_6063)) ? _6063 : (object)(DBL_PTR(_6063)->dbl);
        if (size <= 0){
            DeRef( _6064 );
            _6064 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_text_10790);
            DeRef(_6064);
            _6064 = _text_10790;
        }
        else{
            Head(SEQ_PTR(_text_10790),size+1,&_6064);
        }
    }
    _6063 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _6064;
    _6065 = MAKE_SEQ(_1);
    _6064 = NOVALUE;
    DeRefDSi(_terminator_10789);
    DeRefDSi(_text_10790);
    DeRef(_6056);
    _6056 = NOVALUE;
    DeRef(_6058);
    _6058 = NOVALUE;
    DeRef(_6053);
    _6053 = NOVALUE;
    return _6065;
    ;
}


object _6get_string()
{
    object _text_10811 = NOVALUE;
    object _6082 = NOVALUE;
    object _6078 = NOVALUE;
    object _6077 = NOVALUE;
    object _6074 = NOVALUE;
    object _6073 = NOVALUE;
    object _6072 = NOVALUE;
    object _6071 = NOVALUE;
    object _6069 = NOVALUE;
    object _6068 = NOVALUE;
    object _6066 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:132		text = ""*/
    RefDS(_5);
    DeRefi(_text_10811);
    _text_10811 = _5;

    /** get.e:133		while TRUE do*/
L1: 

    /** get.e:134			get_ch()*/
    _6get_ch();

    /** get.e:135			if ch = GET_EOF or ch = '\n' then*/
    _6066 = (_6ch_10736 == -1);
    if (_6066 != 0) {
        goto L2; // [25] 40
    }
    _6068 = (_6ch_10736 == 10);
    if (_6068 == 0)
    {
        DeRef(_6068);
        _6068 = NOVALUE;
        goto L3; // [36] 53
    }
    else{
        DeRef(_6068);
        _6068 = NOVALUE;
    }
L2: 

    /** get.e:136				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _6069 = MAKE_SEQ(_1);
    DeRefi(_text_10811);
    DeRef(_6066);
    _6066 = NOVALUE;
    return _6069;
    goto L4; // [50] 164
L3: 

    /** get.e:137			elsif ch = '"' then*/
    if (_6ch_10736 != 34)
    goto L5; // [57] 121

    /** get.e:138				get_ch()*/
    _6get_ch();

    /** get.e:139				if length( text ) = 0 and ch = '"' then*/
    if (IS_SEQUENCE(_text_10811)){
            _6071 = SEQ_PTR(_text_10811)->length;
    }
    else {
        _6071 = 1;
    }
    _6072 = (_6071 == 0);
    _6071 = NOVALUE;
    if (_6072 == 0) {
        goto L6; // [74] 108
    }
    _6074 = (_6ch_10736 == 34);
    if (_6074 == 0)
    {
        DeRef(_6074);
        _6074 = NOVALUE;
        goto L6; // [85] 108
    }
    else{
        DeRef(_6074);
        _6074 = NOVALUE;
    }

    /** get.e:140					if ch = '"' then*/
    if (_6ch_10736 != 34)
    goto L7; // [92] 107

    /** get.e:141						return get_heredoc( `"""` )*/
    RefDS(_6076);
    _6077 = _6get_heredoc(_6076);
    DeRefi(_text_10811);
    DeRef(_6066);
    _6066 = NOVALUE;
    DeRef(_6072);
    _6072 = NOVALUE;
    DeRef(_6069);
    _6069 = NOVALUE;
    return _6077;
L7: 
L6: 

    /** get.e:144				return {GET_SUCCESS, text}*/
    RefDS(_text_10811);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _text_10811;
    _6078 = MAKE_SEQ(_1);
    DeRefDSi(_text_10811);
    DeRef(_6077);
    _6077 = NOVALUE;
    DeRef(_6066);
    _6066 = NOVALUE;
    DeRef(_6072);
    _6072 = NOVALUE;
    DeRef(_6069);
    _6069 = NOVALUE;
    return _6078;
    goto L4; // [118] 164
L5: 

    /** get.e:145			elsif ch = '\\' then*/
    if (_6ch_10736 != 92)
    goto L8; // [125] 163

    /** get.e:146				get_ch()*/
    _6get_ch();

    /** get.e:147				ch = escape_char(ch)*/
    _0 = _6escape_char(_6ch_10736);
    _6ch_10736 = _0;
    if (!IS_ATOM_INT(_6ch_10736)) {
        _1 = (object)(DBL_PTR(_6ch_10736)->dbl);
        DeRefDS(_6ch_10736);
        _6ch_10736 = _1;
    }

    /** get.e:148				if ch = GET_FAIL then*/
    if (_6ch_10736 != 1)
    goto L9; // [147] 162

    /** get.e:149					return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _6082 = MAKE_SEQ(_1);
    DeRefi(_text_10811);
    DeRef(_6077);
    _6077 = NOVALUE;
    DeRef(_6066);
    _6066 = NOVALUE;
    DeRef(_6072);
    _6072 = NOVALUE;
    DeRef(_6078);
    _6078 = NOVALUE;
    DeRef(_6069);
    _6069 = NOVALUE;
    return _6082;
L9: 
L8: 
L4: 

    /** get.e:152			text = text & ch*/
    Append(&_text_10811, _text_10811, _6ch_10736);

    /** get.e:153		end while*/
    goto L1; // [174] 13
    ;
}


object _6read_comment()
{
    object _6103 = NOVALUE;
    object _6102 = NOVALUE;
    object _6100 = NOVALUE;
    object _6098 = NOVALUE;
    object _6096 = NOVALUE;
    object _6095 = NOVALUE;
    object _6094 = NOVALUE;
    object _6092 = NOVALUE;
    object _6091 = NOVALUE;
    object _6090 = NOVALUE;
    object _6089 = NOVALUE;
    object _6088 = NOVALUE;
    object _6087 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:163		if atom(input_string) then*/
    _6087 = IS_ATOM(_6input_string_10734);
    if (_6087 == 0)
    {
        _6087 = NOVALUE;
        goto L1; // [8] 98
    }
    else{
        _6087 = NOVALUE;
    }

    /** get.e:164			while ch!='\n' and ch!='\r' and ch!=-1 do*/
L2: 
    _6088 = (_6ch_10736 != 10);
    if (_6088 == 0) {
        _6089 = 0;
        goto L3; // [22] 36
    }
    _6090 = (_6ch_10736 != 13);
    _6089 = (_6090 != 0);
L3: 
    if (_6089 == 0) {
        goto L4; // [36] 59
    }
    _6092 = (_6ch_10736 != -1);
    if (_6092 == 0)
    {
        DeRef(_6092);
        _6092 = NOVALUE;
        goto L4; // [47] 59
    }
    else{
        DeRef(_6092);
        _6092 = NOVALUE;
    }

    /** get.e:165				get_ch()*/
    _6get_ch();

    /** get.e:166			end while*/
    goto L2; // [56] 16
L4: 

    /** get.e:167			get_ch()*/
    _6get_ch();

    /** get.e:168			if ch=-1 then*/
    if (_6ch_10736 != -1)
    goto L5; // [67] 84

    /** get.e:169				return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = 0;
    _6094 = MAKE_SEQ(_1);
    DeRef(_6090);
    _6090 = NOVALUE;
    DeRef(_6088);
    _6088 = NOVALUE;
    return _6094;
    goto L6; // [81] 182
L5: 

    /** get.e:171				return {GET_IGNORE, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -2;
    ((intptr_t *)_2)[2] = 0;
    _6095 = MAKE_SEQ(_1);
    DeRef(_6090);
    _6090 = NOVALUE;
    DeRef(_6088);
    _6088 = NOVALUE;
    DeRef(_6094);
    _6094 = NOVALUE;
    return _6095;
    goto L6; // [95] 182
L1: 

    /** get.e:174			for i=string_next to length(input_string) do*/
    if (IS_SEQUENCE(_6input_string_10734)){
            _6096 = SEQ_PTR(_6input_string_10734)->length;
    }
    else {
        _6096 = 1;
    }
    {
        object _i_10861;
        _i_10861 = _6string_next_10735;
L7: 
        if (_i_10861 > _6096){
            goto L8; // [107] 171
        }

        /** get.e:175				ch=input_string[i]*/
        _2 = (object)SEQ_PTR(_6input_string_10734);
        _6ch_10736 = (object)*(((s1_ptr)_2)->base + _i_10861);
        if (!IS_ATOM_INT(_6ch_10736)){
            _6ch_10736 = (object)DBL_PTR(_6ch_10736)->dbl;
        }

        /** get.e:176				if ch='\n' or ch='\r' then*/
        _6098 = (_6ch_10736 == 10);
        if (_6098 != 0) {
            goto L9; // [132] 147
        }
        _6100 = (_6ch_10736 == 13);
        if (_6100 == 0)
        {
            DeRef(_6100);
            _6100 = NOVALUE;
            goto LA; // [143] 164
        }
        else{
            DeRef(_6100);
            _6100 = NOVALUE;
        }
L9: 

        /** get.e:177					string_next=i+1*/
        _6string_next_10735 = _i_10861 + 1;

        /** get.e:178					return {GET_IGNORE, 0}*/
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -2;
        ((intptr_t *)_2)[2] = 0;
        _6102 = MAKE_SEQ(_1);
        DeRef(_6090);
        _6090 = NOVALUE;
        DeRef(_6088);
        _6088 = NOVALUE;
        DeRef(_6094);
        _6094 = NOVALUE;
        DeRef(_6095);
        _6095 = NOVALUE;
        DeRef(_6098);
        _6098 = NOVALUE;
        return _6102;
LA: 

        /** get.e:180			end for*/
        _i_10861 = _i_10861 + 1;
        goto L7; // [166] 114
L8: 
        ;
    }

    /** get.e:181			return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = 0;
    _6103 = MAKE_SEQ(_1);
    DeRef(_6090);
    _6090 = NOVALUE;
    DeRef(_6088);
    _6088 = NOVALUE;
    DeRef(_6094);
    _6094 = NOVALUE;
    DeRef(_6102);
    _6102 = NOVALUE;
    DeRef(_6095);
    _6095 = NOVALUE;
    DeRef(_6098);
    _6098 = NOVALUE;
    return _6103;
L6: 
    ;
}


object _6get_number()
{
    object _sign_10873 = NOVALUE;
    object _e_sign_10874 = NOVALUE;
    object _ndigits_10875 = NOVALUE;
    object _hex_digit_10876 = NOVALUE;
    object _mantissa_10877 = NOVALUE;
    object _dec_10878 = NOVALUE;
    object _e_mag_10879 = NOVALUE;
    object _number_string_10880 = NOVALUE;
    object _6163 = NOVALUE;
    object _6161 = NOVALUE;
    object _6159 = NOVALUE;
    object _6158 = NOVALUE;
    object _6157 = NOVALUE;
    object _6156 = NOVALUE;
    object _6155 = NOVALUE;
    object _6154 = NOVALUE;
    object _6148 = NOVALUE;
    object _6146 = NOVALUE;
    object _6144 = NOVALUE;
    object _6139 = NOVALUE;
    object _6138 = NOVALUE;
    object _6136 = NOVALUE;
    object _6135 = NOVALUE;
    object _6134 = NOVALUE;
    object _6129 = NOVALUE;
    object _6128 = NOVALUE;
    object _6126 = NOVALUE;
    object _6125 = NOVALUE;
    object _6124 = NOVALUE;
    object _6123 = NOVALUE;
    object _6122 = NOVALUE;
    object _6121 = NOVALUE;
    object _6117 = NOVALUE;
    object _6113 = NOVALUE;
    object _6108 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:192		sequence number_string = { ch }*/
    _0 = _number_string_10880;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _6ch_10736;
    _number_string_10880 = MAKE_SEQ(_1);
    DeRefi(_0);

    /** get.e:194		sign = +1*/
    _sign_10873 = 1;

    /** get.e:195		mantissa = 0*/
    DeRef(_mantissa_10877);
    _mantissa_10877 = 0;

    /** get.e:196		ndigits = 0*/
    _ndigits_10875 = 0;

    /** get.e:199		if ch = '-' then*/
    if (_6ch_10736 != 45)
    goto L1; // [28] 70

    /** get.e:200			sign = -1*/
    _sign_10873 = -1;

    /** get.e:201			get_ch()*/
    _6get_ch();

    /** get.e:202			number_string &= ch*/
    Append(&_number_string_10880, _number_string_10880, _6ch_10736);

    /** get.e:203			if ch='-' then*/
    if (_6ch_10736 != 45)
    goto L2; // [53] 92

    /** get.e:204				return read_comment()*/
    _6108 = _6read_comment();
    DeRef(_dec_10878);
    DeRefDSi(_number_string_10880);
    return _6108;
    goto L2; // [67] 92
L1: 

    /** get.e:206		elsif ch = '+' then*/
    if (_6ch_10736 != 43)
    goto L3; // [74] 91

    /** get.e:207			get_ch()*/
    _6get_ch();

    /** get.e:208			number_string &= ch*/
    Append(&_number_string_10880, _number_string_10880, _6ch_10736);
L3: 
L2: 

    /** get.e:212		if ch = '#' then*/
    if (_6ch_10736 != 35)
    goto L4; // [96] 210

    /** get.e:214			get_ch()*/
    _6get_ch();

    /** get.e:215			number_string &= ch*/
    Append(&_number_string_10880, _number_string_10880, _6ch_10736);

    /** get.e:216			while TRUE do*/
L5: 

    /** get.e:217				hex_digit = find(ch, HEX_DIGITS)-1*/
    _6113 = find_from(_6ch_10736, _6HEX_DIGITS_10716, 1);
    _hex_digit_10876 = _6113 - 1;
    _6113 = NOVALUE;

    /** get.e:218				if hex_digit >= 0 then*/
    if (_hex_digit_10876 < 0)
    goto L6; // [134] 169

    /** get.e:219					ndigits += 1*/
    _ndigits_10875 = _ndigits_10875 + 1;

    /** get.e:220					mantissa = mantissa * 16 + hex_digit*/
    if (IS_ATOM_INT(_mantissa_10877)) {
        if (_mantissa_10877 == (short)_mantissa_10877){
            _6117 = _mantissa_10877 * 16;
        }
        else{
            _6117 = NewDouble(_mantissa_10877 * (eudouble)16);
        }
    }
    else {
        _6117 = NewDouble(DBL_PTR(_mantissa_10877)->dbl * (eudouble)16);
    }
    DeRef(_mantissa_10877);
    if (IS_ATOM_INT(_6117)) {
        _mantissa_10877 = _6117 + _hex_digit_10876;
        if ((object)((uintptr_t)_mantissa_10877 + (uintptr_t)HIGH_BITS) >= 0){
            _mantissa_10877 = NewDouble((eudouble)_mantissa_10877);
        }
    }
    else {
        _mantissa_10877 = NewDouble(DBL_PTR(_6117)->dbl + (eudouble)_hex_digit_10876);
    }
    DeRef(_6117);
    _6117 = NOVALUE;

    /** get.e:221					get_ch()*/
    _6get_ch();

    /** get.e:222					number_string &= ch*/
    Append(&_number_string_10880, _number_string_10880, _6ch_10736);
    goto L5; // [166] 117
L6: 

    /** get.e:224					if ndigits > 0 then*/
    if (_ndigits_10875 <= 0)
    goto L7; // [171] 192

    /** get.e:225						return {GET_SUCCESS, sign * mantissa}*/
    if (IS_ATOM_INT(_mantissa_10877)) {
        if (_sign_10873 == (short)_sign_10873 && _mantissa_10877 <= INT15 && _mantissa_10877 >= -INT15){
            _6121 = _sign_10873 * _mantissa_10877;
        }
        else{
            _6121 = NewDouble(_sign_10873 * (eudouble)_mantissa_10877);
        }
    }
    else {
        _6121 = NewDouble((eudouble)_sign_10873 * DBL_PTR(_mantissa_10877)->dbl);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _6121;
    _6122 = MAKE_SEQ(_1);
    _6121 = NOVALUE;
    DeRef(_mantissa_10877);
    DeRef(_dec_10878);
    DeRefi(_number_string_10880);
    DeRef(_6108);
    _6108 = NOVALUE;
    return _6122;
    goto L5; // [189] 117
L7: 

    /** get.e:227						return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _6123 = MAKE_SEQ(_1);
    DeRef(_mantissa_10877);
    DeRef(_dec_10878);
    DeRefi(_number_string_10880);
    DeRef(_6122);
    _6122 = NOVALUE;
    DeRef(_6108);
    _6108 = NOVALUE;
    return _6123;

    /** get.e:230			end while*/
    goto L5; // [206] 117
L4: 

    /** get.e:234		while ch >= '0' and ch <= '9' do*/
L8: 
    _6124 = (_6ch_10736 >= 48);
    if (_6124 == 0) {
        goto L9; // [221] 274
    }
    _6126 = (_6ch_10736 <= 57);
    if (_6126 == 0)
    {
        DeRef(_6126);
        _6126 = NOVALUE;
        goto L9; // [232] 274
    }
    else{
        DeRef(_6126);
        _6126 = NOVALUE;
    }

    /** get.e:235			ndigits += 1*/
    _ndigits_10875 = _ndigits_10875 + 1;

    /** get.e:236			mantissa = mantissa * 10 + (ch - '0')*/
    if (IS_ATOM_INT(_mantissa_10877)) {
        if (_mantissa_10877 == (short)_mantissa_10877){
            _6128 = _mantissa_10877 * 10;
        }
        else{
            _6128 = NewDouble(_mantissa_10877 * (eudouble)10);
        }
    }
    else {
        _6128 = NewDouble(DBL_PTR(_mantissa_10877)->dbl * (eudouble)10);
    }
    _6129 = _6ch_10736 - 48;
    if ((object)((uintptr_t)_6129 +(uintptr_t) HIGH_BITS) >= 0){
        _6129 = NewDouble((eudouble)_6129);
    }
    DeRef(_mantissa_10877);
    if (IS_ATOM_INT(_6128) && IS_ATOM_INT(_6129)) {
        _mantissa_10877 = _6128 + _6129;
        if ((object)((uintptr_t)_mantissa_10877 + (uintptr_t)HIGH_BITS) >= 0){
            _mantissa_10877 = NewDouble((eudouble)_mantissa_10877);
        }
    }
    else {
        if (IS_ATOM_INT(_6128)) {
            _mantissa_10877 = NewDouble((eudouble)_6128 + DBL_PTR(_6129)->dbl);
        }
        else {
            if (IS_ATOM_INT(_6129)) {
                _mantissa_10877 = NewDouble(DBL_PTR(_6128)->dbl + (eudouble)_6129);
            }
            else
            _mantissa_10877 = NewDouble(DBL_PTR(_6128)->dbl + DBL_PTR(_6129)->dbl);
        }
    }
    DeRef(_6128);
    _6128 = NOVALUE;
    DeRef(_6129);
    _6129 = NOVALUE;

    /** get.e:237			get_ch()*/
    _6get_ch();

    /** get.e:238			number_string &= ch*/
    Append(&_number_string_10880, _number_string_10880, _6ch_10736);

    /** get.e:239		end while*/
    goto L8; // [271] 215
L9: 

    /** get.e:241		if ch = '.' then*/
    if (_6ch_10736 != 46)
    goto LA; // [278] 370

    /** get.e:243			get_ch()*/
    _6get_ch();

    /** get.e:244			number_string &= ch*/
    Append(&_number_string_10880, _number_string_10880, _6ch_10736);

    /** get.e:245			dec = 10*/
    DeRef(_dec_10878);
    _dec_10878 = 10;

    /** get.e:246			while ch >= '0' and ch <= '9' do*/
LB: 
    _6134 = (_6ch_10736 >= 48);
    if (_6134 == 0) {
        goto LC; // [310] 369
    }
    _6136 = (_6ch_10736 <= 57);
    if (_6136 == 0)
    {
        DeRef(_6136);
        _6136 = NOVALUE;
        goto LC; // [321] 369
    }
    else{
        DeRef(_6136);
        _6136 = NOVALUE;
    }

    /** get.e:247				ndigits += 1*/
    _ndigits_10875 = _ndigits_10875 + 1;

    /** get.e:248				mantissa += (ch - '0') / dec*/
    _6138 = _6ch_10736 - 48;
    if ((object)((uintptr_t)_6138 +(uintptr_t) HIGH_BITS) >= 0){
        _6138 = NewDouble((eudouble)_6138);
    }
    if (IS_ATOM_INT(_6138) && IS_ATOM_INT(_dec_10878)) {
        _6139 = (_6138 % _dec_10878) ? NewDouble((eudouble)_6138 / _dec_10878) : (_6138 / _dec_10878);
    }
    else {
        if (IS_ATOM_INT(_6138)) {
            _6139 = NewDouble((eudouble)_6138 / DBL_PTR(_dec_10878)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec_10878)) {
                _6139 = NewDouble(DBL_PTR(_6138)->dbl / (eudouble)_dec_10878);
            }
            else
            _6139 = NewDouble(DBL_PTR(_6138)->dbl / DBL_PTR(_dec_10878)->dbl);
        }
    }
    DeRef(_6138);
    _6138 = NOVALUE;
    _0 = _mantissa_10877;
    if (IS_ATOM_INT(_mantissa_10877) && IS_ATOM_INT(_6139)) {
        _mantissa_10877 = _mantissa_10877 + _6139;
        if ((object)((uintptr_t)_mantissa_10877 + (uintptr_t)HIGH_BITS) >= 0){
            _mantissa_10877 = NewDouble((eudouble)_mantissa_10877);
        }
    }
    else {
        if (IS_ATOM_INT(_mantissa_10877)) {
            _mantissa_10877 = NewDouble((eudouble)_mantissa_10877 + DBL_PTR(_6139)->dbl);
        }
        else {
            if (IS_ATOM_INT(_6139)) {
                _mantissa_10877 = NewDouble(DBL_PTR(_mantissa_10877)->dbl + (eudouble)_6139);
            }
            else
            _mantissa_10877 = NewDouble(DBL_PTR(_mantissa_10877)->dbl + DBL_PTR(_6139)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_6139);
    _6139 = NOVALUE;

    /** get.e:249				dec *= 10*/
    _0 = _dec_10878;
    if (IS_ATOM_INT(_dec_10878)) {
        if (_dec_10878 == (short)_dec_10878){
            _dec_10878 = _dec_10878 * 10;
        }
        else{
            _dec_10878 = NewDouble(_dec_10878 * (eudouble)10);
        }
    }
    else {
        _dec_10878 = NewDouble(DBL_PTR(_dec_10878)->dbl * (eudouble)10);
    }
    DeRef(_0);

    /** get.e:250				get_ch()*/
    _6get_ch();

    /** get.e:251				number_string &= ch*/
    Append(&_number_string_10880, _number_string_10880, _6ch_10736);

    /** get.e:252			end while*/
    goto LB; // [366] 304
LC: 
LA: 

    /** get.e:255		if ndigits = 0 then*/
    if (_ndigits_10875 != 0)
    goto LD; // [372] 387

    /** get.e:256			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _6144 = MAKE_SEQ(_1);
    DeRef(_mantissa_10877);
    DeRef(_dec_10878);
    DeRefi(_number_string_10880);
    DeRef(_6122);
    _6122 = NOVALUE;
    DeRef(_6108);
    _6108 = NOVALUE;
    DeRef(_6123);
    _6123 = NOVALUE;
    DeRef(_6124);
    _6124 = NOVALUE;
    DeRef(_6134);
    _6134 = NOVALUE;
    return _6144;
LD: 

    /** get.e:259		mantissa = sign * mantissa*/
    _0 = _mantissa_10877;
    if (IS_ATOM_INT(_mantissa_10877)) {
        if (_sign_10873 == (short)_sign_10873 && _mantissa_10877 <= INT15 && _mantissa_10877 >= -INT15){
            _mantissa_10877 = _sign_10873 * _mantissa_10877;
        }
        else{
            _mantissa_10877 = NewDouble(_sign_10873 * (eudouble)_mantissa_10877);
        }
    }
    else {
        _mantissa_10877 = NewDouble((eudouble)_sign_10873 * DBL_PTR(_mantissa_10877)->dbl);
    }
    DeRef(_0);

    /** get.e:261		if ch = 'e' or ch = 'E' then*/
    _6146 = (_6ch_10736 == 101);
    if (_6146 != 0) {
        goto LE; // [401] 416
    }
    _6148 = (_6ch_10736 == 69);
    if (_6148 == 0)
    {
        DeRef(_6148);
        _6148 = NOVALUE;
        goto LF; // [412] 565
    }
    else{
        DeRef(_6148);
        _6148 = NOVALUE;
    }
LE: 

    /** get.e:264			get_ch()*/
    _6get_ch();

    /** get.e:265			number_string &= ch*/
    Append(&_number_string_10880, _number_string_10880, _6ch_10736);

    /** get.e:266			if ch = '-' then*/
    if (_6ch_10736 != 45)
    goto L10; // [432] 451

    /** get.e:267				get_ch()*/
    _6get_ch();

    /** get.e:268				number_string &= ch*/
    Append(&_number_string_10880, _number_string_10880, _6ch_10736);
    goto L11; // [448] 473
L10: 

    /** get.e:269			elsif ch = '+' then*/
    if (_6ch_10736 != 43)
    goto L12; // [455] 472

    /** get.e:270				get_ch()*/
    _6get_ch();

    /** get.e:271				number_string &= ch*/
    Append(&_number_string_10880, _number_string_10880, _6ch_10736);
L12: 
L11: 

    /** get.e:275			if ch >= '0' and ch <= '9' then*/
    _6154 = (_6ch_10736 >= 48);
    if (_6154 == 0) {
        goto L13; // [481] 546
    }
    _6156 = (_6ch_10736 <= 57);
    if (_6156 == 0)
    {
        DeRef(_6156);
        _6156 = NOVALUE;
        goto L13; // [492] 546
    }
    else{
        DeRef(_6156);
        _6156 = NOVALUE;
    }

    /** get.e:277				while ch >= '0' and ch <= '9' with entry do*/
    goto L14; // [497] 534
L15: 
    _6157 = (_6ch_10736 >= 48);
    if (_6157 == 0) {
        DeRef(_6158);
        _6158 = 0;
        goto L16; // [506] 520
    }
    _6159 = (_6ch_10736 <= 57);
    _6158 = (_6159 != 0);
L16: 
    if (_6158 == 0)
    {
        _6158 = NOVALUE;
        goto L17; // [520] 557
    }
    else{
        _6158 = NOVALUE;
    }

    /** get.e:278					number_string &= ch*/
    Append(&_number_string_10880, _number_string_10880, _6ch_10736);

    /** get.e:279				entry*/
L14: 

    /** get.e:280					get_ch()*/
    _6get_ch();

    /** get.e:281				end while*/
    goto L15; // [540] 500
    goto L17; // [543] 557
L13: 

    /** get.e:283				return {GET_FAIL, 0} -- no exponent*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _6161 = MAKE_SEQ(_1);
    DeRef(_mantissa_10877);
    DeRef(_dec_10878);
    DeRefi(_number_string_10880);
    DeRef(_6122);
    _6122 = NOVALUE;
    DeRef(_6108);
    _6108 = NOVALUE;
    DeRef(_6154);
    _6154 = NOVALUE;
    DeRef(_6157);
    _6157 = NOVALUE;
    DeRef(_6159);
    _6159 = NOVALUE;
    DeRef(_6123);
    _6123 = NOVALUE;
    DeRef(_6124);
    _6124 = NOVALUE;
    DeRef(_6146);
    _6146 = NOVALUE;
    DeRef(_6144);
    _6144 = NOVALUE;
    DeRef(_6134);
    _6134 = NOVALUE;
    return _6161;
L17: 

    /** get.e:286			mantissa = scientific_to_atom( number_string )*/
    RefDS(_number_string_10880);
    _0 = _mantissa_10877;
    _mantissa_10877 = _28scientific_to_atom(_number_string_10880, 1);
    DeRef(_0);
LF: 

    /** get.e:289		return {GET_SUCCESS, mantissa}*/
    Ref(_mantissa_10877);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _mantissa_10877;
    _6163 = MAKE_SEQ(_1);
    DeRef(_mantissa_10877);
    DeRef(_dec_10878);
    DeRefi(_number_string_10880);
    DeRef(_6122);
    _6122 = NOVALUE;
    DeRef(_6108);
    _6108 = NOVALUE;
    DeRef(_6161);
    _6161 = NOVALUE;
    DeRef(_6154);
    _6154 = NOVALUE;
    DeRef(_6157);
    _6157 = NOVALUE;
    DeRef(_6159);
    _6159 = NOVALUE;
    DeRef(_6123);
    _6123 = NOVALUE;
    DeRef(_6124);
    _6124 = NOVALUE;
    DeRef(_6146);
    _6146 = NOVALUE;
    DeRef(_6144);
    _6144 = NOVALUE;
    DeRef(_6134);
    _6134 = NOVALUE;
    return _6163;
    ;
}


object _6Get()
{
    object _skip_blanks_1__tmp_at328_11007 = NOVALUE;
    object _skip_blanks_1__tmp_at177_10988 = NOVALUE;
    object _skip_blanks_1__tmp_at88_10979 = NOVALUE;
    object _s_10963 = NOVALUE;
    object _e_10964 = NOVALUE;
    object _e1_10965 = NOVALUE;
    object _6202 = NOVALUE;
    object _6201 = NOVALUE;
    object _6199 = NOVALUE;
    object _6196 = NOVALUE;
    object _6194 = NOVALUE;
    object _6192 = NOVALUE;
    object _6190 = NOVALUE;
    object _6187 = NOVALUE;
    object _6185 = NOVALUE;
    object _6181 = NOVALUE;
    object _6177 = NOVALUE;
    object _6174 = NOVALUE;
    object _6173 = NOVALUE;
    object _6171 = NOVALUE;
    object _6169 = NOVALUE;
    object _6167 = NOVALUE;
    object _6166 = NOVALUE;
    object _6164 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:300		while find(ch, white_space) do*/
L1: 
    _6164 = find_from(_6ch_10736, _6white_space_10752, 1);
    if (_6164 == 0)
    {
        _6164 = NOVALUE;
        goto L2; // [13] 25
    }
    else{
        _6164 = NOVALUE;
    }

    /** get.e:301			get_ch()*/
    _6get_ch();

    /** get.e:302		end while*/
    goto L1; // [22] 6
L2: 

    /** get.e:304		if ch = -1 then -- string is made of whitespace only*/
    if (_6ch_10736 != -1)
    goto L3; // [29] 44

    /** get.e:305			return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = 0;
    _6166 = MAKE_SEQ(_1);
    DeRef(_s_10963);
    DeRef(_e_10964);
    return _6166;
L3: 

    /** get.e:308		while 1 do*/
L4: 

    /** get.e:309			if find(ch, START_NUMERIC) then*/
    _6167 = find_from(_6ch_10736, _6START_NUMERIC_10719, 1);
    if (_6167 == 0)
    {
        _6167 = NOVALUE;
        goto L5; // [60] 157
    }
    else{
        _6167 = NOVALUE;
    }

    /** get.e:310				e = get_number()*/
    _0 = _e_10964;
    _e_10964 = _6get_number();
    DeRef(_0);

    /** get.e:311				if e[1] != GET_IGNORE then -- either a number or something illegal was read, so exit: the other goto*/
    _2 = (object)SEQ_PTR(_e_10964);
    _6169 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _6169, -2)){
        _6169 = NOVALUE;
        goto L6; // [76] 87
    }
    _6169 = NOVALUE;

    /** get.e:312					return e*/
    DeRef(_s_10963);
    DeRef(_6166);
    _6166 = NOVALUE;
    return _e_10964;
L6: 

    /** get.e:314				skip_blanks()*/

    /** get.e:67		while find(ch, white_space) do*/
L7: 
    _skip_blanks_1__tmp_at88_10979 = find_from(_6ch_10736, _6white_space_10752, 1);
    if (_skip_blanks_1__tmp_at88_10979 == 0)
    {
        goto L8; // [101] 118
    }
    else{
    }

    /** get.e:68			get_ch()*/
    _6get_ch();

    /** get.e:69		end while*/
    goto L7; // [110] 94

    /** get.e:70	end procedure*/
    goto L8; // [115] 118
L8: 

    /** get.e:315				if ch=-1 or ch='}' then -- '}' is expected only in the "{--\n}" case*/
    _6171 = (_6ch_10736 == -1);
    if (_6171 != 0) {
        goto L9; // [128] 143
    }
    _6173 = (_6ch_10736 == 125);
    if (_6173 == 0)
    {
        DeRef(_6173);
        _6173 = NOVALUE;
        goto L4; // [139] 49
    }
    else{
        DeRef(_6173);
        _6173 = NOVALUE;
    }
L9: 

    /** get.e:316					return {GET_NOTHING, 0} -- just a comment*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -2;
    ((intptr_t *)_2)[2] = 0;
    _6174 = MAKE_SEQ(_1);
    DeRef(_s_10963);
    DeRef(_e_10964);
    DeRef(_6171);
    _6171 = NOVALUE;
    DeRef(_6166);
    _6166 = NOVALUE;
    return _6174;
    goto L4; // [154] 49
L5: 

    /** get.e:318			elsif ch = '{' then*/
    if (_6ch_10736 != 123)
    goto LA; // [161] 465

    /** get.e:320				s = {}*/
    RefDS(_5);
    DeRef(_s_10963);
    _s_10963 = _5;

    /** get.e:321				get_ch()*/
    _6get_ch();

    /** get.e:322				skip_blanks()*/

    /** get.e:67		while find(ch, white_space) do*/
LB: 
    _skip_blanks_1__tmp_at177_10988 = find_from(_6ch_10736, _6white_space_10752, 1);
    if (_skip_blanks_1__tmp_at177_10988 == 0)
    {
        goto LC; // [190] 207
    }
    else{
    }

    /** get.e:68			get_ch()*/
    _6get_ch();

    /** get.e:69		end while*/
    goto LB; // [199] 183

    /** get.e:70	end procedure*/
    goto LC; // [204] 207
LC: 

    /** get.e:323				if ch = '}' then -- empty sequence*/
    if (_6ch_10736 != 125)
    goto LD; // [213] 232

    /** get.e:324					get_ch()*/
    _6get_ch();

    /** get.e:325					return {GET_SUCCESS, s} -- empty sequence*/
    RefDS(_s_10963);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _s_10963;
    _6177 = MAKE_SEQ(_1);
    DeRefDS(_s_10963);
    DeRef(_e_10964);
    DeRef(_6171);
    _6171 = NOVALUE;
    DeRef(_6174);
    _6174 = NOVALUE;
    DeRef(_6166);
    _6166 = NOVALUE;
    return _6177;
LD: 

    /** get.e:328				while TRUE do -- read: comment(s), element, comment(s), comma and so on till it terminates or errors out*/
LE: 

    /** get.e:329					while 1 do -- read zero or more comments and an element*/
LF: 

    /** get.e:330						e = Get() -- read next element, using standard function*/
    _0 = _e_10964;
    _e_10964 = _6Get();
    DeRef(_0);

    /** get.e:331						e1 = e[1]*/
    _2 = (object)SEQ_PTR(_e_10964);
    _e1_10965 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_e1_10965))
    _e1_10965 = (object)DBL_PTR(_e1_10965)->dbl;

    /** get.e:332						if e1 = GET_SUCCESS then*/
    if (_e1_10965 != 0)
    goto L10; // [257] 278

    /** get.e:333							s = append(s, e[2])*/
    _2 = (object)SEQ_PTR(_e_10964);
    _6181 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_6181);
    Append(&_s_10963, _s_10963, _6181);
    _6181 = NOVALUE;

    /** get.e:334							exit  -- element read and added to result*/
    goto L11; // [273] 322
    goto LF; // [275] 242
L10: 

    /** get.e:335						elsif e1 != GET_IGNORE then*/
    if (_e1_10965 == -2)
    goto L12; // [280] 293

    /** get.e:336							return e*/
    DeRef(_s_10963);
    DeRef(_6177);
    _6177 = NOVALUE;
    DeRef(_6171);
    _6171 = NOVALUE;
    DeRef(_6174);
    _6174 = NOVALUE;
    DeRef(_6166);
    _6166 = NOVALUE;
    return _e_10964;
    goto LF; // [290] 242
L12: 

    /** get.e:338						elsif ch='}' then*/
    if (_6ch_10736 != 125)
    goto LF; // [297] 242

    /** get.e:339							get_ch()*/
    _6get_ch();

    /** get.e:340							return {GET_SUCCESS, s} -- empty sequence*/
    RefDS(_s_10963);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _s_10963;
    _6185 = MAKE_SEQ(_1);
    DeRefDS(_s_10963);
    DeRef(_e_10964);
    DeRef(_6177);
    _6177 = NOVALUE;
    DeRef(_6171);
    _6171 = NOVALUE;
    DeRef(_6174);
    _6174 = NOVALUE;
    DeRef(_6166);
    _6166 = NOVALUE;
    return _6185;

    /** get.e:342					end while*/
    goto LF; // [319] 242
L11: 

    /** get.e:344					while 1 do -- now read zero or more post element comments*/
L13: 

    /** get.e:345						skip_blanks()*/

    /** get.e:67		while find(ch, white_space) do*/
L14: 
    _skip_blanks_1__tmp_at328_11007 = find_from(_6ch_10736, _6white_space_10752, 1);
    if (_skip_blanks_1__tmp_at328_11007 == 0)
    {
        goto L15; // [341] 358
    }
    else{
    }

    /** get.e:68			get_ch()*/
    _6get_ch();

    /** get.e:69		end while*/
    goto L14; // [350] 334

    /** get.e:70	end procedure*/
    goto L15; // [355] 358
L15: 

    /** get.e:346						if ch = '}' then*/
    if (_6ch_10736 != 125)
    goto L16; // [364] 385

    /** get.e:347							get_ch()*/
    _6get_ch();

    /** get.e:348						return {GET_SUCCESS, s}*/
    RefDS(_s_10963);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _s_10963;
    _6187 = MAKE_SEQ(_1);
    DeRefDS(_s_10963);
    DeRef(_e_10964);
    DeRef(_6177);
    _6177 = NOVALUE;
    DeRef(_6171);
    _6171 = NOVALUE;
    DeRef(_6174);
    _6174 = NOVALUE;
    DeRef(_6166);
    _6166 = NOVALUE;
    DeRef(_6185);
    _6185 = NOVALUE;
    return _6187;
    goto L13; // [382] 327
L16: 

    /** get.e:349						elsif ch!='-' then*/
    if (_6ch_10736 == 45)
    goto L17; // [389] 400

    /** get.e:350							exit*/
    goto L18; // [395] 434
    goto L13; // [397] 327
L17: 

    /** get.e:352							e = get_number() -- reads anything starting with '-'*/
    _0 = _e_10964;
    _e_10964 = _6get_number();
    DeRef(_0);

    /** get.e:353							if e[1] != GET_IGNORE then  -- it wasn't a comment, this is illegal*/
    _2 = (object)SEQ_PTR(_e_10964);
    _6190 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _6190, -2)){
        _6190 = NOVALUE;
        goto L13; // [413] 327
    }
    _6190 = NOVALUE;

    /** get.e:354								return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _6192 = MAKE_SEQ(_1);
    DeRef(_s_10963);
    DeRefDS(_e_10964);
    DeRef(_6187);
    _6187 = NOVALUE;
    DeRef(_6177);
    _6177 = NOVALUE;
    DeRef(_6171);
    _6171 = NOVALUE;
    DeRef(_6174);
    _6174 = NOVALUE;
    DeRef(_6166);
    _6166 = NOVALUE;
    DeRef(_6185);
    _6185 = NOVALUE;
    return _6192;

    /** get.e:358				end while*/
    goto L13; // [431] 327
L18: 

    /** get.e:359					if ch != ',' then*/
    if (_6ch_10736 == 44)
    goto L19; // [438] 453

    /** get.e:360					return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _6194 = MAKE_SEQ(_1);
    DeRef(_s_10963);
    DeRef(_e_10964);
    DeRef(_6187);
    _6187 = NOVALUE;
    DeRef(_6177);
    _6177 = NOVALUE;
    DeRef(_6171);
    _6171 = NOVALUE;
    DeRef(_6174);
    _6174 = NOVALUE;
    DeRef(_6166);
    _6166 = NOVALUE;
    DeRef(_6192);
    _6192 = NOVALUE;
    DeRef(_6185);
    _6185 = NOVALUE;
    return _6194;
L19: 

    /** get.e:362				get_ch() -- skip comma*/
    _6get_ch();

    /** get.e:363				end while*/
    goto LE; // [459] 237
    goto L4; // [462] 49
LA: 

    /** get.e:365			elsif ch = '\"' then*/
    if (_6ch_10736 != 34)
    goto L1A; // [469] 485

    /** get.e:366				return get_string()*/
    _6196 = _6get_string();
    DeRef(_s_10963);
    DeRef(_e_10964);
    DeRef(_6187);
    _6187 = NOVALUE;
    DeRef(_6177);
    _6177 = NOVALUE;
    DeRef(_6171);
    _6171 = NOVALUE;
    DeRef(_6174);
    _6174 = NOVALUE;
    DeRef(_6166);
    _6166 = NOVALUE;
    DeRef(_6194);
    _6194 = NOVALUE;
    DeRef(_6192);
    _6192 = NOVALUE;
    DeRef(_6185);
    _6185 = NOVALUE;
    return _6196;
    goto L4; // [482] 49
L1A: 

    /** get.e:367			elsif ch = '`' then*/
    if (_6ch_10736 != 96)
    goto L1B; // [489] 506

    /** get.e:368				return get_heredoc("`")*/
    RefDS(_6198);
    _6199 = _6get_heredoc(_6198);
    DeRef(_s_10963);
    DeRef(_e_10964);
    DeRef(_6187);
    _6187 = NOVALUE;
    DeRef(_6177);
    _6177 = NOVALUE;
    DeRef(_6171);
    _6171 = NOVALUE;
    DeRef(_6196);
    _6196 = NOVALUE;
    DeRef(_6174);
    _6174 = NOVALUE;
    DeRef(_6166);
    _6166 = NOVALUE;
    DeRef(_6194);
    _6194 = NOVALUE;
    DeRef(_6192);
    _6192 = NOVALUE;
    DeRef(_6185);
    _6185 = NOVALUE;
    return _6199;
    goto L4; // [503] 49
L1B: 

    /** get.e:369			elsif ch = '\'' then*/
    if (_6ch_10736 != 39)
    goto L1C; // [510] 526

    /** get.e:370				return get_qchar()*/
    _6201 = _6get_qchar();
    DeRef(_s_10963);
    DeRef(_e_10964);
    DeRef(_6187);
    _6187 = NOVALUE;
    DeRef(_6177);
    _6177 = NOVALUE;
    DeRef(_6199);
    _6199 = NOVALUE;
    DeRef(_6171);
    _6171 = NOVALUE;
    DeRef(_6196);
    _6196 = NOVALUE;
    DeRef(_6174);
    _6174 = NOVALUE;
    DeRef(_6166);
    _6166 = NOVALUE;
    DeRef(_6194);
    _6194 = NOVALUE;
    DeRef(_6192);
    _6192 = NOVALUE;
    DeRef(_6185);
    _6185 = NOVALUE;
    return _6201;
    goto L4; // [523] 49
L1C: 

    /** get.e:372				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _6202 = MAKE_SEQ(_1);
    DeRef(_s_10963);
    DeRef(_e_10964);
    DeRef(_6187);
    _6187 = NOVALUE;
    DeRef(_6201);
    _6201 = NOVALUE;
    DeRef(_6177);
    _6177 = NOVALUE;
    DeRef(_6199);
    _6199 = NOVALUE;
    DeRef(_6171);
    _6171 = NOVALUE;
    DeRef(_6196);
    _6196 = NOVALUE;
    DeRef(_6174);
    _6174 = NOVALUE;
    DeRef(_6166);
    _6166 = NOVALUE;
    DeRef(_6194);
    _6194 = NOVALUE;
    DeRef(_6192);
    _6192 = NOVALUE;
    DeRef(_6185);
    _6185 = NOVALUE;
    return _6202;

    /** get.e:376		end while*/
    goto L4; // [539] 49
    ;
}


object _6Get2()
{
    object _skip_blanks_1__tmp_at464_11108 = NOVALUE;
    object _skip_blanks_1__tmp_at233_11075 = NOVALUE;
    object _s_11037 = NOVALUE;
    object _e_11038 = NOVALUE;
    object _e1_11039 = NOVALUE;
    object _offset_11040 = NOVALUE;
    object _6302 = NOVALUE;
    object _6301 = NOVALUE;
    object _6300 = NOVALUE;
    object _6299 = NOVALUE;
    object _6298 = NOVALUE;
    object _6297 = NOVALUE;
    object _6296 = NOVALUE;
    object _6295 = NOVALUE;
    object _6294 = NOVALUE;
    object _6293 = NOVALUE;
    object _6292 = NOVALUE;
    object _6289 = NOVALUE;
    object _6288 = NOVALUE;
    object _6287 = NOVALUE;
    object _6286 = NOVALUE;
    object _6285 = NOVALUE;
    object _6284 = NOVALUE;
    object _6281 = NOVALUE;
    object _6280 = NOVALUE;
    object _6279 = NOVALUE;
    object _6278 = NOVALUE;
    object _6277 = NOVALUE;
    object _6276 = NOVALUE;
    object _6273 = NOVALUE;
    object _6272 = NOVALUE;
    object _6271 = NOVALUE;
    object _6270 = NOVALUE;
    object _6269 = NOVALUE;
    object _6267 = NOVALUE;
    object _6266 = NOVALUE;
    object _6265 = NOVALUE;
    object _6264 = NOVALUE;
    object _6263 = NOVALUE;
    object _6261 = NOVALUE;
    object _6258 = NOVALUE;
    object _6257 = NOVALUE;
    object _6256 = NOVALUE;
    object _6255 = NOVALUE;
    object _6254 = NOVALUE;
    object _6252 = NOVALUE;
    object _6251 = NOVALUE;
    object _6250 = NOVALUE;
    object _6249 = NOVALUE;
    object _6248 = NOVALUE;
    object _6246 = NOVALUE;
    object _6245 = NOVALUE;
    object _6244 = NOVALUE;
    object _6243 = NOVALUE;
    object _6242 = NOVALUE;
    object _6241 = NOVALUE;
    object _6238 = NOVALUE;
    object _6234 = NOVALUE;
    object _6233 = NOVALUE;
    object _6232 = NOVALUE;
    object _6231 = NOVALUE;
    object _6230 = NOVALUE;
    object _6227 = NOVALUE;
    object _6226 = NOVALUE;
    object _6225 = NOVALUE;
    object _6224 = NOVALUE;
    object _6223 = NOVALUE;
    object _6221 = NOVALUE;
    object _6220 = NOVALUE;
    object _6219 = NOVALUE;
    object _6218 = NOVALUE;
    object _6217 = NOVALUE;
    object _6216 = NOVALUE;
    object _6214 = NOVALUE;
    object _6212 = NOVALUE;
    object _6210 = NOVALUE;
    object _6209 = NOVALUE;
    object _6208 = NOVALUE;
    object _6207 = NOVALUE;
    object _6206 = NOVALUE;
    object _6204 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:392		offset = string_next-1*/
    _offset_11040 = _6string_next_10735 - 1;

    /** get.e:393		get_ch()*/
    _6get_ch();

    /** get.e:394		while find(ch, white_space) do*/
L1: 
    _6204 = find_from(_6ch_10736, _6white_space_10752, 1);
    if (_6204 == 0)
    {
        _6204 = NOVALUE;
        goto L2; // [25] 37
    }
    else{
        _6204 = NOVALUE;
    }

    /** get.e:395			get_ch()*/
    _6get_ch();

    /** get.e:396		end while*/
    goto L1; // [34] 18
L2: 

    /** get.e:398		if ch = -1 then -- string is made of whitespace only*/
    if (_6ch_10736 != -1)
    goto L3; // [41] 75

    /** get.e:399			return {GET_EOF, 0, string_next-1-offset ,string_next-1}*/
    _6206 = _6string_next_10735 - 1;
    if ((object)((uintptr_t)_6206 +(uintptr_t) HIGH_BITS) >= 0){
        _6206 = NewDouble((eudouble)_6206);
    }
    if (IS_ATOM_INT(_6206)) {
        _6207 = _6206 - _offset_11040;
        if ((object)((uintptr_t)_6207 +(uintptr_t) HIGH_BITS) >= 0){
            _6207 = NewDouble((eudouble)_6207);
        }
    }
    else {
        _6207 = NewDouble(DBL_PTR(_6206)->dbl - (eudouble)_offset_11040);
    }
    DeRef(_6206);
    _6206 = NOVALUE;
    _6208 = _6string_next_10735 - 1;
    if ((object)((uintptr_t)_6208 +(uintptr_t) HIGH_BITS) >= 0){
        _6208 = NewDouble((eudouble)_6208);
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = -1;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = _6207;
    ((intptr_t*)_2)[4] = _6208;
    _6209 = MAKE_SEQ(_1);
    _6208 = NOVALUE;
    _6207 = NOVALUE;
    DeRef(_s_11037);
    DeRef(_e_11038);
    return _6209;
L3: 

    /** get.e:402		leading_whitespace = string_next-2-offset -- index of the last whitespace: string_next points past the first non whitespace*/
    _6210 = _6string_next_10735 - 2;
    if ((object)((uintptr_t)_6210 +(uintptr_t) HIGH_BITS) >= 0){
        _6210 = NewDouble((eudouble)_6210);
    }
    if (IS_ATOM_INT(_6210)) {
        _6leading_whitespace_11034 = _6210 - _offset_11040;
    }
    else {
        _6leading_whitespace_11034 = NewDouble(DBL_PTR(_6210)->dbl - (eudouble)_offset_11040);
    }
    DeRef(_6210);
    _6210 = NOVALUE;
    if (!IS_ATOM_INT(_6leading_whitespace_11034)) {
        _1 = (object)(DBL_PTR(_6leading_whitespace_11034)->dbl);
        DeRefDS(_6leading_whitespace_11034);
        _6leading_whitespace_11034 = _1;
    }

    /** get.e:404		while 1 do*/
L4: 

    /** get.e:405			if find(ch, START_NUMERIC) then*/
    _6212 = find_from(_6ch_10736, _6START_NUMERIC_10719, 1);
    if (_6212 == 0)
    {
        _6212 = NOVALUE;
        goto L5; // [105] 213
    }
    else{
        _6212 = NOVALUE;
    }

    /** get.e:406				e = get_number()*/
    _0 = _e_11038;
    _e_11038 = _6get_number();
    DeRef(_0);

    /** get.e:407				if e[1] != GET_IGNORE then -- either a number or something illegal was read, so exit: the other goto*/
    _2 = (object)SEQ_PTR(_e_11038);
    _6214 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _6214, -2)){
        _6214 = NOVALUE;
        goto L6; // [121] 162
    }
    _6214 = NOVALUE;

    /** get.e:408					return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _6216 = _6string_next_10735 - 1;
    if ((object)((uintptr_t)_6216 +(uintptr_t) HIGH_BITS) >= 0){
        _6216 = NewDouble((eudouble)_6216);
    }
    if (IS_ATOM_INT(_6216)) {
        _6217 = _6216 - _offset_11040;
        if ((object)((uintptr_t)_6217 +(uintptr_t) HIGH_BITS) >= 0){
            _6217 = NewDouble((eudouble)_6217);
        }
    }
    else {
        _6217 = NewDouble(DBL_PTR(_6216)->dbl - (eudouble)_offset_11040);
    }
    DeRef(_6216);
    _6216 = NOVALUE;
    _6218 = (_6ch_10736 != -1);
    if (IS_ATOM_INT(_6217)) {
        _6219 = _6217 - _6218;
        if ((object)((uintptr_t)_6219 +(uintptr_t) HIGH_BITS) >= 0){
            _6219 = NewDouble((eudouble)_6219);
        }
    }
    else {
        _6219 = NewDouble(DBL_PTR(_6217)->dbl - (eudouble)_6218);
    }
    DeRef(_6217);
    _6217 = NOVALUE;
    _6218 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _6219;
    ((intptr_t *)_2)[2] = _6leading_whitespace_11034;
    _6220 = MAKE_SEQ(_1);
    _6219 = NOVALUE;
    Concat((object_ptr)&_6221, _e_11038, _6220);
    DeRefDS(_6220);
    _6220 = NOVALUE;
    DeRef(_s_11037);
    DeRefDS(_e_11038);
    DeRef(_6209);
    _6209 = NOVALUE;
    return _6221;
L6: 

    /** get.e:410				get_ch()*/
    _6get_ch();

    /** get.e:411				if ch=-1 then*/
    if (_6ch_10736 != -1)
    goto L4; // [170] 94

    /** get.e:412					return {GET_NOTHING, 0, string_next-1-offset-(ch!=-1), leading_whitespace} -- empty sequence*/
    _6223 = _6string_next_10735 - 1;
    if ((object)((uintptr_t)_6223 +(uintptr_t) HIGH_BITS) >= 0){
        _6223 = NewDouble((eudouble)_6223);
    }
    if (IS_ATOM_INT(_6223)) {
        _6224 = _6223 - _offset_11040;
        if ((object)((uintptr_t)_6224 +(uintptr_t) HIGH_BITS) >= 0){
            _6224 = NewDouble((eudouble)_6224);
        }
    }
    else {
        _6224 = NewDouble(DBL_PTR(_6223)->dbl - (eudouble)_offset_11040);
    }
    DeRef(_6223);
    _6223 = NOVALUE;
    _6225 = (_6ch_10736 != -1);
    if (IS_ATOM_INT(_6224)) {
        _6226 = _6224 - _6225;
        if ((object)((uintptr_t)_6226 +(uintptr_t) HIGH_BITS) >= 0){
            _6226 = NewDouble((eudouble)_6226);
        }
    }
    else {
        _6226 = NewDouble(DBL_PTR(_6224)->dbl - (eudouble)_6225);
    }
    DeRef(_6224);
    _6224 = NOVALUE;
    _6225 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = -2;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = _6226;
    ((intptr_t*)_2)[4] = _6leading_whitespace_11034;
    _6227 = MAKE_SEQ(_1);
    _6226 = NOVALUE;
    DeRef(_s_11037);
    DeRef(_e_11038);
    DeRef(_6221);
    _6221 = NOVALUE;
    DeRef(_6209);
    _6209 = NOVALUE;
    return _6227;
    goto L4; // [210] 94
L5: 

    /** get.e:415			elsif ch = '{' then*/
    if (_6ch_10736 != 123)
    goto L7; // [217] 676

    /** get.e:417				s = {}*/
    RefDS(_5);
    DeRef(_s_11037);
    _s_11037 = _5;

    /** get.e:418				get_ch()*/
    _6get_ch();

    /** get.e:419				skip_blanks()*/

    /** get.e:67		while find(ch, white_space) do*/
L8: 
    _skip_blanks_1__tmp_at233_11075 = find_from(_6ch_10736, _6white_space_10752, 1);
    if (_skip_blanks_1__tmp_at233_11075 == 0)
    {
        goto L9; // [246] 263
    }
    else{
    }

    /** get.e:68			get_ch()*/
    _6get_ch();

    /** get.e:69		end while*/
    goto L8; // [255] 239

    /** get.e:70	end procedure*/
    goto L9; // [260] 263
L9: 

    /** get.e:420				if ch = '}' then -- empty sequence*/
    if (_6ch_10736 != 125)
    goto LA; // [269] 313

    /** get.e:421					get_ch()*/
    _6get_ch();

    /** get.e:422					return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1), leading_whitespace} -- empty sequence*/
    _6230 = _6string_next_10735 - 1;
    if ((object)((uintptr_t)_6230 +(uintptr_t) HIGH_BITS) >= 0){
        _6230 = NewDouble((eudouble)_6230);
    }
    if (IS_ATOM_INT(_6230)) {
        _6231 = _6230 - _offset_11040;
        if ((object)((uintptr_t)_6231 +(uintptr_t) HIGH_BITS) >= 0){
            _6231 = NewDouble((eudouble)_6231);
        }
    }
    else {
        _6231 = NewDouble(DBL_PTR(_6230)->dbl - (eudouble)_offset_11040);
    }
    DeRef(_6230);
    _6230 = NOVALUE;
    _6232 = (_6ch_10736 != -1);
    if (IS_ATOM_INT(_6231)) {
        _6233 = _6231 - _6232;
        if ((object)((uintptr_t)_6233 +(uintptr_t) HIGH_BITS) >= 0){
            _6233 = NewDouble((eudouble)_6233);
        }
    }
    else {
        _6233 = NewDouble(DBL_PTR(_6231)->dbl - (eudouble)_6232);
    }
    DeRef(_6231);
    _6231 = NOVALUE;
    _6232 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    RefDS(_s_11037);
    ((intptr_t*)_2)[2] = _s_11037;
    ((intptr_t*)_2)[3] = _6233;
    ((intptr_t*)_2)[4] = _6leading_whitespace_11034;
    _6234 = MAKE_SEQ(_1);
    _6233 = NOVALUE;
    DeRefDS(_s_11037);
    DeRef(_e_11038);
    DeRef(_6221);
    _6221 = NOVALUE;
    DeRef(_6227);
    _6227 = NOVALUE;
    DeRef(_6209);
    _6209 = NOVALUE;
    return _6234;
LA: 

    /** get.e:425				while TRUE do -- read: comment(s), element, comment(s), comma and so on till it terminates or errors out*/
LB: 

    /** get.e:426					while 1 do -- read zero or more comments and an element*/
LC: 

    /** get.e:427						e = Get() -- read next element, using standard function*/
    _0 = _e_11038;
    _e_11038 = _6Get();
    DeRef(_0);

    /** get.e:428						e1 = e[1]*/
    _2 = (object)SEQ_PTR(_e_11038);
    _e1_11039 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_e1_11039))
    _e1_11039 = (object)DBL_PTR(_e1_11039)->dbl;

    /** get.e:429						if e1 = GET_SUCCESS then*/
    if (_e1_11039 != 0)
    goto LD; // [338] 359

    /** get.e:430							s = append(s, e[2])*/
    _2 = (object)SEQ_PTR(_e_11038);
    _6238 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_6238);
    Append(&_s_11037, _s_11037, _6238);
    _6238 = NOVALUE;

    /** get.e:431							exit  -- element read and added to result*/
    goto LE; // [354] 458
    goto LC; // [356] 323
LD: 

    /** get.e:432						elsif e1 != GET_IGNORE then*/
    if (_e1_11039 == -2)
    goto LF; // [361] 404

    /** get.e:433							return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _6241 = _6string_next_10735 - 1;
    if ((object)((uintptr_t)_6241 +(uintptr_t) HIGH_BITS) >= 0){
        _6241 = NewDouble((eudouble)_6241);
    }
    if (IS_ATOM_INT(_6241)) {
        _6242 = _6241 - _offset_11040;
        if ((object)((uintptr_t)_6242 +(uintptr_t) HIGH_BITS) >= 0){
            _6242 = NewDouble((eudouble)_6242);
        }
    }
    else {
        _6242 = NewDouble(DBL_PTR(_6241)->dbl - (eudouble)_offset_11040);
    }
    DeRef(_6241);
    _6241 = NOVALUE;
    _6243 = (_6ch_10736 != -1);
    if (IS_ATOM_INT(_6242)) {
        _6244 = _6242 - _6243;
        if ((object)((uintptr_t)_6244 +(uintptr_t) HIGH_BITS) >= 0){
            _6244 = NewDouble((eudouble)_6244);
        }
    }
    else {
        _6244 = NewDouble(DBL_PTR(_6242)->dbl - (eudouble)_6243);
    }
    DeRef(_6242);
    _6242 = NOVALUE;
    _6243 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _6244;
    ((intptr_t *)_2)[2] = _6leading_whitespace_11034;
    _6245 = MAKE_SEQ(_1);
    _6244 = NOVALUE;
    Concat((object_ptr)&_6246, _e_11038, _6245);
    DeRefDS(_6245);
    _6245 = NOVALUE;
    DeRef(_s_11037);
    DeRefDS(_e_11038);
    DeRef(_6221);
    _6221 = NOVALUE;
    DeRef(_6227);
    _6227 = NOVALUE;
    DeRef(_6209);
    _6209 = NOVALUE;
    DeRef(_6234);
    _6234 = NOVALUE;
    return _6246;
    goto LC; // [401] 323
LF: 

    /** get.e:435						elsif ch='}' then*/
    if (_6ch_10736 != 125)
    goto LC; // [408] 323

    /** get.e:436							get_ch()*/
    _6get_ch();

    /** get.e:437							return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1),leading_whitespace} -- empty sequence*/
    _6248 = _6string_next_10735 - 1;
    if ((object)((uintptr_t)_6248 +(uintptr_t) HIGH_BITS) >= 0){
        _6248 = NewDouble((eudouble)_6248);
    }
    if (IS_ATOM_INT(_6248)) {
        _6249 = _6248 - _offset_11040;
        if ((object)((uintptr_t)_6249 +(uintptr_t) HIGH_BITS) >= 0){
            _6249 = NewDouble((eudouble)_6249);
        }
    }
    else {
        _6249 = NewDouble(DBL_PTR(_6248)->dbl - (eudouble)_offset_11040);
    }
    DeRef(_6248);
    _6248 = NOVALUE;
    _6250 = (_6ch_10736 != -1);
    if (IS_ATOM_INT(_6249)) {
        _6251 = _6249 - _6250;
        if ((object)((uintptr_t)_6251 +(uintptr_t) HIGH_BITS) >= 0){
            _6251 = NewDouble((eudouble)_6251);
        }
    }
    else {
        _6251 = NewDouble(DBL_PTR(_6249)->dbl - (eudouble)_6250);
    }
    DeRef(_6249);
    _6249 = NOVALUE;
    _6250 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    RefDS(_s_11037);
    ((intptr_t*)_2)[2] = _s_11037;
    ((intptr_t*)_2)[3] = _6251;
    ((intptr_t*)_2)[4] = _6leading_whitespace_11034;
    _6252 = MAKE_SEQ(_1);
    _6251 = NOVALUE;
    DeRefDS(_s_11037);
    DeRef(_e_11038);
    DeRef(_6221);
    _6221 = NOVALUE;
    DeRef(_6227);
    _6227 = NOVALUE;
    DeRef(_6246);
    _6246 = NOVALUE;
    DeRef(_6209);
    _6209 = NOVALUE;
    DeRef(_6234);
    _6234 = NOVALUE;
    return _6252;

    /** get.e:439					end while*/
    goto LC; // [455] 323
LE: 

    /** get.e:441					while 1 do -- now read zero or more post element comments*/
L10: 

    /** get.e:442						skip_blanks()*/

    /** get.e:67		while find(ch, white_space) do*/
L11: 
    _skip_blanks_1__tmp_at464_11108 = find_from(_6ch_10736, _6white_space_10752, 1);
    if (_skip_blanks_1__tmp_at464_11108 == 0)
    {
        goto L12; // [477] 494
    }
    else{
    }

    /** get.e:68			get_ch()*/
    _6get_ch();

    /** get.e:69		end while*/
    goto L11; // [486] 470

    /** get.e:70	end procedure*/
    goto L12; // [491] 494
L12: 

    /** get.e:443						if ch = '}' then*/
    if (_6ch_10736 != 125)
    goto L13; // [500] 546

    /** get.e:444							get_ch()*/
    _6get_ch();

    /** get.e:445						return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _6254 = _6string_next_10735 - 1;
    if ((object)((uintptr_t)_6254 +(uintptr_t) HIGH_BITS) >= 0){
        _6254 = NewDouble((eudouble)_6254);
    }
    if (IS_ATOM_INT(_6254)) {
        _6255 = _6254 - _offset_11040;
        if ((object)((uintptr_t)_6255 +(uintptr_t) HIGH_BITS) >= 0){
            _6255 = NewDouble((eudouble)_6255);
        }
    }
    else {
        _6255 = NewDouble(DBL_PTR(_6254)->dbl - (eudouble)_offset_11040);
    }
    DeRef(_6254);
    _6254 = NOVALUE;
    _6256 = (_6ch_10736 != -1);
    if (IS_ATOM_INT(_6255)) {
        _6257 = _6255 - _6256;
        if ((object)((uintptr_t)_6257 +(uintptr_t) HIGH_BITS) >= 0){
            _6257 = NewDouble((eudouble)_6257);
        }
    }
    else {
        _6257 = NewDouble(DBL_PTR(_6255)->dbl - (eudouble)_6256);
    }
    DeRef(_6255);
    _6255 = NOVALUE;
    _6256 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    RefDS(_s_11037);
    ((intptr_t*)_2)[2] = _s_11037;
    ((intptr_t*)_2)[3] = _6257;
    ((intptr_t*)_2)[4] = _6leading_whitespace_11034;
    _6258 = MAKE_SEQ(_1);
    _6257 = NOVALUE;
    DeRefDS(_s_11037);
    DeRef(_e_11038);
    DeRef(_6221);
    _6221 = NOVALUE;
    DeRef(_6227);
    _6227 = NOVALUE;
    DeRef(_6246);
    _6246 = NOVALUE;
    DeRef(_6252);
    _6252 = NOVALUE;
    DeRef(_6209);
    _6209 = NOVALUE;
    DeRef(_6234);
    _6234 = NOVALUE;
    return _6258;
    goto L10; // [543] 463
L13: 

    /** get.e:446						elsif ch!='-' then*/
    if (_6ch_10736 == 45)
    goto L14; // [550] 561

    /** get.e:447							exit*/
    goto L15; // [556] 620
    goto L10; // [558] 463
L14: 

    /** get.e:449							e = get_number() -- reads anything starting with '-'*/
    _0 = _e_11038;
    _e_11038 = _6get_number();
    DeRef(_0);

    /** get.e:450							if e[1] != GET_IGNORE then  -- it was not a comment, this is illegal*/
    _2 = (object)SEQ_PTR(_e_11038);
    _6261 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _6261, -2)){
        _6261 = NOVALUE;
        goto L10; // [574] 463
    }
    _6261 = NOVALUE;

    /** get.e:451								return {GET_FAIL, 0, string_next-1-offset-(ch!=-1),leading_whitespace}*/
    _6263 = _6string_next_10735 - 1;
    if ((object)((uintptr_t)_6263 +(uintptr_t) HIGH_BITS) >= 0){
        _6263 = NewDouble((eudouble)_6263);
    }
    if (IS_ATOM_INT(_6263)) {
        _6264 = _6263 - _offset_11040;
        if ((object)((uintptr_t)_6264 +(uintptr_t) HIGH_BITS) >= 0){
            _6264 = NewDouble((eudouble)_6264);
        }
    }
    else {
        _6264 = NewDouble(DBL_PTR(_6263)->dbl - (eudouble)_offset_11040);
    }
    DeRef(_6263);
    _6263 = NOVALUE;
    _6265 = (_6ch_10736 != -1);
    if (IS_ATOM_INT(_6264)) {
        _6266 = _6264 - _6265;
        if ((object)((uintptr_t)_6266 +(uintptr_t) HIGH_BITS) >= 0){
            _6266 = NewDouble((eudouble)_6266);
        }
    }
    else {
        _6266 = NewDouble(DBL_PTR(_6264)->dbl - (eudouble)_6265);
    }
    DeRef(_6264);
    _6264 = NOVALUE;
    _6265 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = _6266;
    ((intptr_t*)_2)[4] = _6leading_whitespace_11034;
    _6267 = MAKE_SEQ(_1);
    _6266 = NOVALUE;
    DeRef(_s_11037);
    DeRefDS(_e_11038);
    DeRef(_6221);
    _6221 = NOVALUE;
    DeRef(_6227);
    _6227 = NOVALUE;
    DeRef(_6258);
    _6258 = NOVALUE;
    DeRef(_6246);
    _6246 = NOVALUE;
    DeRef(_6252);
    _6252 = NOVALUE;
    DeRef(_6209);
    _6209 = NOVALUE;
    DeRef(_6234);
    _6234 = NOVALUE;
    return _6267;

    /** get.e:455				end while*/
    goto L10; // [617] 463
L15: 

    /** get.e:456					if ch != ',' then*/
    if (_6ch_10736 == 44)
    goto L16; // [624] 664

    /** get.e:457					return {GET_FAIL, 0, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _6269 = _6string_next_10735 - 1;
    if ((object)((uintptr_t)_6269 +(uintptr_t) HIGH_BITS) >= 0){
        _6269 = NewDouble((eudouble)_6269);
    }
    if (IS_ATOM_INT(_6269)) {
        _6270 = _6269 - _offset_11040;
        if ((object)((uintptr_t)_6270 +(uintptr_t) HIGH_BITS) >= 0){
            _6270 = NewDouble((eudouble)_6270);
        }
    }
    else {
        _6270 = NewDouble(DBL_PTR(_6269)->dbl - (eudouble)_offset_11040);
    }
    DeRef(_6269);
    _6269 = NOVALUE;
    _6271 = (_6ch_10736 != -1);
    if (IS_ATOM_INT(_6270)) {
        _6272 = _6270 - _6271;
        if ((object)((uintptr_t)_6272 +(uintptr_t) HIGH_BITS) >= 0){
            _6272 = NewDouble((eudouble)_6272);
        }
    }
    else {
        _6272 = NewDouble(DBL_PTR(_6270)->dbl - (eudouble)_6271);
    }
    DeRef(_6270);
    _6270 = NOVALUE;
    _6271 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = _6272;
    ((intptr_t*)_2)[4] = _6leading_whitespace_11034;
    _6273 = MAKE_SEQ(_1);
    _6272 = NOVALUE;
    DeRef(_s_11037);
    DeRef(_e_11038);
    DeRef(_6267);
    _6267 = NOVALUE;
    DeRef(_6221);
    _6221 = NOVALUE;
    DeRef(_6227);
    _6227 = NOVALUE;
    DeRef(_6258);
    _6258 = NOVALUE;
    DeRef(_6246);
    _6246 = NOVALUE;
    DeRef(_6252);
    _6252 = NOVALUE;
    DeRef(_6209);
    _6209 = NOVALUE;
    DeRef(_6234);
    _6234 = NOVALUE;
    return _6273;
L16: 

    /** get.e:459				get_ch() -- skip comma*/
    _6get_ch();

    /** get.e:460				end while*/
    goto LB; // [670] 318
    goto L4; // [673] 94
L7: 

    /** get.e:462			elsif ch = '\"' then*/
    if (_6ch_10736 != 34)
    goto L17; // [680] 730

    /** get.e:463				e = get_string()*/
    _0 = _e_11038;
    _e_11038 = _6get_string();
    DeRef(_0);

    /** get.e:464				return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _6276 = _6string_next_10735 - 1;
    if ((object)((uintptr_t)_6276 +(uintptr_t) HIGH_BITS) >= 0){
        _6276 = NewDouble((eudouble)_6276);
    }
    if (IS_ATOM_INT(_6276)) {
        _6277 = _6276 - _offset_11040;
        if ((object)((uintptr_t)_6277 +(uintptr_t) HIGH_BITS) >= 0){
            _6277 = NewDouble((eudouble)_6277);
        }
    }
    else {
        _6277 = NewDouble(DBL_PTR(_6276)->dbl - (eudouble)_offset_11040);
    }
    DeRef(_6276);
    _6276 = NOVALUE;
    _6278 = (_6ch_10736 != -1);
    if (IS_ATOM_INT(_6277)) {
        _6279 = _6277 - _6278;
        if ((object)((uintptr_t)_6279 +(uintptr_t) HIGH_BITS) >= 0){
            _6279 = NewDouble((eudouble)_6279);
        }
    }
    else {
        _6279 = NewDouble(DBL_PTR(_6277)->dbl - (eudouble)_6278);
    }
    DeRef(_6277);
    _6277 = NOVALUE;
    _6278 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _6279;
    ((intptr_t *)_2)[2] = _6leading_whitespace_11034;
    _6280 = MAKE_SEQ(_1);
    _6279 = NOVALUE;
    Concat((object_ptr)&_6281, _e_11038, _6280);
    DeRefDS(_6280);
    _6280 = NOVALUE;
    DeRef(_s_11037);
    DeRefDS(_e_11038);
    DeRef(_6267);
    _6267 = NOVALUE;
    DeRef(_6221);
    _6221 = NOVALUE;
    DeRef(_6227);
    _6227 = NOVALUE;
    DeRef(_6258);
    _6258 = NOVALUE;
    DeRef(_6246);
    _6246 = NOVALUE;
    DeRef(_6273);
    _6273 = NOVALUE;
    DeRef(_6252);
    _6252 = NOVALUE;
    DeRef(_6209);
    _6209 = NOVALUE;
    DeRef(_6234);
    _6234 = NOVALUE;
    return _6281;
    goto L4; // [727] 94
L17: 

    /** get.e:465			elsif ch = '`' then*/
    if (_6ch_10736 != 96)
    goto L18; // [734] 785

    /** get.e:466				e = get_heredoc("`")*/
    RefDS(_6198);
    _0 = _e_11038;
    _e_11038 = _6get_heredoc(_6198);
    DeRef(_0);

    /** get.e:467				return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _6284 = _6string_next_10735 - 1;
    if ((object)((uintptr_t)_6284 +(uintptr_t) HIGH_BITS) >= 0){
        _6284 = NewDouble((eudouble)_6284);
    }
    if (IS_ATOM_INT(_6284)) {
        _6285 = _6284 - _offset_11040;
        if ((object)((uintptr_t)_6285 +(uintptr_t) HIGH_BITS) >= 0){
            _6285 = NewDouble((eudouble)_6285);
        }
    }
    else {
        _6285 = NewDouble(DBL_PTR(_6284)->dbl - (eudouble)_offset_11040);
    }
    DeRef(_6284);
    _6284 = NOVALUE;
    _6286 = (_6ch_10736 != -1);
    if (IS_ATOM_INT(_6285)) {
        _6287 = _6285 - _6286;
        if ((object)((uintptr_t)_6287 +(uintptr_t) HIGH_BITS) >= 0){
            _6287 = NewDouble((eudouble)_6287);
        }
    }
    else {
        _6287 = NewDouble(DBL_PTR(_6285)->dbl - (eudouble)_6286);
    }
    DeRef(_6285);
    _6285 = NOVALUE;
    _6286 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _6287;
    ((intptr_t *)_2)[2] = _6leading_whitespace_11034;
    _6288 = MAKE_SEQ(_1);
    _6287 = NOVALUE;
    Concat((object_ptr)&_6289, _e_11038, _6288);
    DeRefDS(_6288);
    _6288 = NOVALUE;
    DeRef(_s_11037);
    DeRefDS(_e_11038);
    DeRef(_6267);
    _6267 = NOVALUE;
    DeRef(_6281);
    _6281 = NOVALUE;
    DeRef(_6221);
    _6221 = NOVALUE;
    DeRef(_6227);
    _6227 = NOVALUE;
    DeRef(_6258);
    _6258 = NOVALUE;
    DeRef(_6246);
    _6246 = NOVALUE;
    DeRef(_6273);
    _6273 = NOVALUE;
    DeRef(_6252);
    _6252 = NOVALUE;
    DeRef(_6209);
    _6209 = NOVALUE;
    DeRef(_6234);
    _6234 = NOVALUE;
    return _6289;
    goto L4; // [782] 94
L18: 

    /** get.e:468			elsif ch = '\'' then*/
    if (_6ch_10736 != 39)
    goto L19; // [789] 839

    /** get.e:469				e = get_qchar()*/
    _0 = _e_11038;
    _e_11038 = _6get_qchar();
    DeRef(_0);

    /** get.e:470				return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _6292 = _6string_next_10735 - 1;
    if ((object)((uintptr_t)_6292 +(uintptr_t) HIGH_BITS) >= 0){
        _6292 = NewDouble((eudouble)_6292);
    }
    if (IS_ATOM_INT(_6292)) {
        _6293 = _6292 - _offset_11040;
        if ((object)((uintptr_t)_6293 +(uintptr_t) HIGH_BITS) >= 0){
            _6293 = NewDouble((eudouble)_6293);
        }
    }
    else {
        _6293 = NewDouble(DBL_PTR(_6292)->dbl - (eudouble)_offset_11040);
    }
    DeRef(_6292);
    _6292 = NOVALUE;
    _6294 = (_6ch_10736 != -1);
    if (IS_ATOM_INT(_6293)) {
        _6295 = _6293 - _6294;
        if ((object)((uintptr_t)_6295 +(uintptr_t) HIGH_BITS) >= 0){
            _6295 = NewDouble((eudouble)_6295);
        }
    }
    else {
        _6295 = NewDouble(DBL_PTR(_6293)->dbl - (eudouble)_6294);
    }
    DeRef(_6293);
    _6293 = NOVALUE;
    _6294 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _6295;
    ((intptr_t *)_2)[2] = _6leading_whitespace_11034;
    _6296 = MAKE_SEQ(_1);
    _6295 = NOVALUE;
    Concat((object_ptr)&_6297, _e_11038, _6296);
    DeRefDS(_6296);
    _6296 = NOVALUE;
    DeRef(_s_11037);
    DeRefDS(_e_11038);
    DeRef(_6267);
    _6267 = NOVALUE;
    DeRef(_6281);
    _6281 = NOVALUE;
    DeRef(_6221);
    _6221 = NOVALUE;
    DeRef(_6227);
    _6227 = NOVALUE;
    DeRef(_6258);
    _6258 = NOVALUE;
    DeRef(_6246);
    _6246 = NOVALUE;
    DeRef(_6273);
    _6273 = NOVALUE;
    DeRef(_6252);
    _6252 = NOVALUE;
    DeRef(_6289);
    _6289 = NOVALUE;
    DeRef(_6209);
    _6209 = NOVALUE;
    DeRef(_6234);
    _6234 = NOVALUE;
    return _6297;
    goto L4; // [836] 94
L19: 

    /** get.e:472				return {GET_FAIL, 0, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _6298 = _6string_next_10735 - 1;
    if ((object)((uintptr_t)_6298 +(uintptr_t) HIGH_BITS) >= 0){
        _6298 = NewDouble((eudouble)_6298);
    }
    if (IS_ATOM_INT(_6298)) {
        _6299 = _6298 - _offset_11040;
        if ((object)((uintptr_t)_6299 +(uintptr_t) HIGH_BITS) >= 0){
            _6299 = NewDouble((eudouble)_6299);
        }
    }
    else {
        _6299 = NewDouble(DBL_PTR(_6298)->dbl - (eudouble)_offset_11040);
    }
    DeRef(_6298);
    _6298 = NOVALUE;
    _6300 = (_6ch_10736 != -1);
    if (IS_ATOM_INT(_6299)) {
        _6301 = _6299 - _6300;
        if ((object)((uintptr_t)_6301 +(uintptr_t) HIGH_BITS) >= 0){
            _6301 = NewDouble((eudouble)_6301);
        }
    }
    else {
        _6301 = NewDouble(DBL_PTR(_6299)->dbl - (eudouble)_6300);
    }
    DeRef(_6299);
    _6299 = NOVALUE;
    _6300 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = _6301;
    ((intptr_t*)_2)[4] = _6leading_whitespace_11034;
    _6302 = MAKE_SEQ(_1);
    _6301 = NOVALUE;
    DeRef(_s_11037);
    DeRef(_e_11038);
    DeRef(_6267);
    _6267 = NOVALUE;
    DeRef(_6281);
    _6281 = NOVALUE;
    DeRef(_6221);
    _6221 = NOVALUE;
    DeRef(_6227);
    _6227 = NOVALUE;
    DeRef(_6297);
    _6297 = NOVALUE;
    DeRef(_6258);
    _6258 = NOVALUE;
    DeRef(_6246);
    _6246 = NOVALUE;
    DeRef(_6273);
    _6273 = NOVALUE;
    DeRef(_6252);
    _6252 = NOVALUE;
    DeRef(_6289);
    _6289 = NOVALUE;
    DeRef(_6209);
    _6209 = NOVALUE;
    DeRef(_6234);
    _6234 = NOVALUE;
    return _6302;

    /** get.e:476		end while*/
    goto L4; // [877] 94
    ;
}


object _6get_value(object _target_11176, object _start_point_11177, object _answer_type_11178)
{
    object _msg_inlined_crash_at_35_11189 = NOVALUE;
    object _data_inlined_crash_at_32_11188 = NOVALUE;
    object _where_inlined_where_at_76_11195 = NOVALUE;
    object _seek_1__tmp_at90_11200 = NOVALUE;
    object _seek_inlined_seek_at_90_11199 = NOVALUE;
    object _pos_inlined_seek_at_87_11198 = NOVALUE;
    object _msg_inlined_crash_at_108_11203 = NOVALUE;
    object _6318 = NOVALUE;
    object _6315 = NOVALUE;
    object _6314 = NOVALUE;
    object _6313 = NOVALUE;
    object _6309 = NOVALUE;
    object _6308 = NOVALUE;
    object _6307 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:488		if answer_type != GET_SHORT_ANSWER and answer_type != GET_LONG_ANSWER then*/
    _6307 = (_answer_type_11178 != _6GET_SHORT_ANSWER_11168);
    if (_6307 == 0) {
        goto L1; // [13] 55
    }
    _6309 = (_answer_type_11178 != _6GET_LONG_ANSWER_11171);
    if (_6309 == 0)
    {
        DeRef(_6309);
        _6309 = NOVALUE;
        goto L1; // [24] 55
    }
    else{
        DeRef(_6309);
        _6309 = NOVALUE;
    }

    /** get.e:489			error:crash("Invalid type of answer, please only use %s (the default) or %s.", {"GET_SHORT_ANSWER", "GET_LONG_ANSWER"})*/
    RefDS(_6312);
    RefDS(_6311);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _6311;
    ((intptr_t *)_2)[2] = _6312;
    _6313 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_32_11188);
    _data_inlined_crash_at_32_11188 = _6313;
    _6313 = NOVALUE;

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_35_11189);
    _msg_inlined_crash_at_35_11189 = EPrintf(-9999999, _6310, _data_inlined_crash_at_32_11188);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_35_11189);

    /** error.e:53	end procedure*/
    goto L2; // [49] 52
L2: 
    DeRef(_data_inlined_crash_at_32_11188);
    _data_inlined_crash_at_32_11188 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_35_11189);
    _msg_inlined_crash_at_35_11189 = NOVALUE;
L1: 

    /** get.e:491		if atom(target) then -- get()*/
    _6314 = IS_ATOM(_target_11176);
    if (_6314 == 0)
    {
        _6314 = NOVALUE;
        goto L3; // [60] 142
    }
    else{
        _6314 = NOVALUE;
    }

    /** get.e:492			input_file = target*/
    Ref(_target_11176);
    _6input_file_10733 = _target_11176;
    if (!IS_ATOM_INT(_6input_file_10733)) {
        _1 = (object)(DBL_PTR(_6input_file_10733)->dbl);
        DeRefDS(_6input_file_10733);
        _6input_file_10733 = _1;
    }

    /** get.e:493			if start_point then*/
    if (_start_point_11177 == 0)
    {
        goto L4; // [72] 129
    }
    else{
    }

    /** get.e:494				if io:seek(target, io:where(target)+start_point) then*/

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_76_11195);
    _where_inlined_where_at_76_11195 = machine(20, _target_11176);
    if (IS_ATOM_INT(_where_inlined_where_at_76_11195)) {
        _6315 = _where_inlined_where_at_76_11195 + _start_point_11177;
        if ((object)((uintptr_t)_6315 + (uintptr_t)HIGH_BITS) >= 0){
            _6315 = NewDouble((eudouble)_6315);
        }
    }
    else {
        _6315 = NewDouble(DBL_PTR(_where_inlined_where_at_76_11195)->dbl + (eudouble)_start_point_11177);
    }
    DeRef(_pos_inlined_seek_at_87_11198);
    _pos_inlined_seek_at_87_11198 = _6315;
    _6315 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_87_11198);
    Ref(_target_11176);
    DeRef(_seek_1__tmp_at90_11200);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _target_11176;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_87_11198;
    _seek_1__tmp_at90_11200 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_90_11199 = machine(19, _seek_1__tmp_at90_11200);
    DeRef(_pos_inlined_seek_at_87_11198);
    _pos_inlined_seek_at_87_11198 = NOVALUE;
    DeRef(_seek_1__tmp_at90_11200);
    _seek_1__tmp_at90_11200 = NOVALUE;
    if (_seek_inlined_seek_at_90_11199 == 0)
    {
        goto L5; // [104] 128
    }
    else{
    }

    /** get.e:495					error:crash("Initial seek() for get() failed!")*/

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_108_11203);
    _msg_inlined_crash_at_108_11203 = EPrintf(-9999999, _6316, _5);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_108_11203);

    /** error.e:53	end procedure*/
    goto L6; // [122] 125
L6: 
    DeRefi(_msg_inlined_crash_at_108_11203);
    _msg_inlined_crash_at_108_11203 = NOVALUE;
L5: 
L4: 

    /** get.e:498			string_next = 1*/
    _6string_next_10735 = 1;

    /** get.e:499			input_string = 0*/
    DeRef(_6input_string_10734);
    _6input_string_10734 = 0;
    goto L7; // [139] 153
L3: 

    /** get.e:501			input_string = target*/
    Ref(_target_11176);
    DeRef(_6input_string_10734);
    _6input_string_10734 = _target_11176;

    /** get.e:502			string_next = start_point*/
    _6string_next_10735 = _start_point_11177;
L7: 

    /** get.e:504		if answer_type = GET_SHORT_ANSWER then*/
    if (_answer_type_11178 != _6GET_SHORT_ANSWER_11168)
    goto L8; // [157] 166

    /** get.e:505			get_ch()*/
    _6get_ch();
L8: 

    /** get.e:507		return call_func(answer_type, {})*/
    _0 = (object)_00[_answer_type_11178].addr;
    _1 = (*(intptr_t (*)())_0)(
                         );
    DeRef(_6318);
    _6318 = _1;
    DeRef(_target_11176);
    DeRef(_6307);
    _6307 = NOVALUE;
    return _6318;
    ;
}


object _6value(object _st_11216, object _start_point_11217, object _answer_11218)
{
    object _6320 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:684		return get_value(st, start_point, answer)*/
    RefDS(_st_11216);
    _6320 = _6get_value(_st_11216, 1, _answer_11218);
    DeRefDS(_st_11216);
    return _6320;
    ;
}



// 0x399D7419
