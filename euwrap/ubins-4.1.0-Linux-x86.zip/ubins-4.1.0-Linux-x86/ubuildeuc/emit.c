// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _47Push(object _x_51191)
{
    object _26297 = NOVALUE;
    object _26295 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_51191)) {
        _1 = (object)(DBL_PTR(_x_51191)->dbl);
        DeRefDS(_x_51191);
        _x_51191 = _1;
    }

    /** emit.e:135		cgi += 1*/
    _47cgi_50952 = _47cgi_50952 + 1;

    /** emit.e:136		if cgi > length(cg_stack) then*/
    if (IS_SEQUENCE(_47cg_stack_50951)){
            _26295 = SEQ_PTR(_47cg_stack_50951)->length;
    }
    else {
        _26295 = 1;
    }
    if (_47cgi_50952 <= _26295)
    goto L1; // [20] 37

    /** emit.e:137			cg_stack &= repeat(0, 400)*/
    _26297 = Repeat(0, 400);
    Concat((object_ptr)&_47cg_stack_50951, _47cg_stack_50951, _26297);
    DeRefDS(_26297);
    _26297 = NOVALUE;
L1: 

    /** emit.e:139		cg_stack[cgi] = x*/
    _2 = (object)SEQ_PTR(_47cg_stack_50951);
    _2 = (object)(((s1_ptr)_2)->base + _47cgi_50952);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _x_51191;
    DeRef(_1);

    /** emit.e:141	end procedure*/
    return;
    ;
}


object _47Top()
{
    object _26299 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:145		return cg_stack[cgi]*/
    _2 = (object)SEQ_PTR(_47cg_stack_50951);
    _26299 = (object)*(((s1_ptr)_2)->base + _47cgi_50952);
    Ref(_26299);
    return _26299;
    ;
}


object _47Pop()
{
    object _t_51204 = NOVALUE;
    object _s_51210 = NOVALUE;
    object _26311 = NOVALUE;
    object _26309 = NOVALUE;
    object _26307 = NOVALUE;
    object _26304 = NOVALUE;
    object _26303 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** emit.e:153		t = cg_stack[cgi]*/
    _2 = (object)SEQ_PTR(_47cg_stack_50951);
    _t_51204 = (object)*(((s1_ptr)_2)->base + _47cgi_50952);
    if (!IS_ATOM_INT(_t_51204)){
        _t_51204 = (object)DBL_PTR(_t_51204)->dbl;
    }

    /** emit.e:154		cgi -= 1*/
    _47cgi_50952 = _47cgi_50952 - 1;

    /** emit.e:155		if t > 0 then*/
    if (_t_51204 <= 0)
    goto L1; // [23] 116

    /** emit.e:156			symtab_index s = t -- for type checking*/
    _s_51210 = _t_51204;

    /** emit.e:157			if SymTab[t][S_MODE] = M_TEMP then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26303 = (object)*(((s1_ptr)_2)->base + _t_51204);
    _2 = (object)SEQ_PTR(_26303);
    _26304 = (object)*(((s1_ptr)_2)->base + 3);
    _26303 = NOVALUE;
    if (binary_op_a(NOTEQ, _26304, 3)){
        _26304 = NOVALUE;
        goto L2; // [50] 115
    }
    _26304 = NOVALUE;

    /** emit.e:158				if use_private_list = 0 then  -- no problem with reusing the temp*/
    if (_36use_private_list_21564 != 0)
    goto L3; // [58] 82

    /** emit.e:159					SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_t_51204 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _26307 = NOVALUE;
    goto L4; // [79] 114
L3: 

    /** emit.e:163				elsif find(t, private_sym) = 0 then*/
    _26309 = find_from(_t_51204, _36private_sym_21563, 1);
    if (_26309 != 0)
    goto L5; // [91] 113

    /** emit.e:165					SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_t_51204 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _26311 = NOVALUE;
L5: 
L4: 
L2: 
L1: 

    /** emit.e:169		return t*/
    return _t_51204;
    ;
}


void _47TempKeep(object _x_51238)
{
    object _26318 = NOVALUE;
    object _26317 = NOVALUE;
    object _26316 = NOVALUE;
    object _26315 = NOVALUE;
    object _26314 = NOVALUE;
    object _26313 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** emit.e:173		if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26313 = (_x_51238 > 0);
    if (_26313 == 0) {
        goto L1; // [9] 53
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26315 = (object)*(((s1_ptr)_2)->base + _x_51238);
    _2 = (object)SEQ_PTR(_26315);
    _26316 = (object)*(((s1_ptr)_2)->base + 3);
    _26315 = NOVALUE;
    if (IS_ATOM_INT(_26316)) {
        _26317 = (_26316 == 3);
    }
    else {
        _26317 = binary_op(EQUALS, _26316, 3);
    }
    _26316 = NOVALUE;
    if (_26317 == 0) {
        DeRef(_26317);
        _26317 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26317) && DBL_PTR(_26317)->dbl == 0.0){
            DeRef(_26317);
            _26317 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26317);
        _26317 = NOVALUE;
    }
    DeRef(_26317);
    _26317 = NOVALUE;

    /** emit.e:174			SymTab[x][S_SCOPE] = IN_USE*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_x_51238 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _26318 = NOVALUE;
L1: 

    /** emit.e:176	end procedure*/
    DeRef(_26313);
    _26313 = NOVALUE;
    return;
    ;
}


void _47TempFree(object _x_51256)
{
    object _26324 = NOVALUE;
    object _26322 = NOVALUE;
    object _26321 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** emit.e:179		if x > 0 then*/
    if (_x_51256 <= 0)
    goto L1; // [5] 53

    /** emit.e:180			if SymTab[x][S_MODE] = M_TEMP then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26321 = (object)*(((s1_ptr)_2)->base + _x_51256);
    _2 = (object)SEQ_PTR(_26321);
    _26322 = (object)*(((s1_ptr)_2)->base + 3);
    _26321 = NOVALUE;
    if (binary_op_a(NOTEQ, _26322, 3)){
        _26322 = NOVALUE;
        goto L2; // [25] 52
    }
    _26322 = NOVALUE;

    /** emit.e:181				SymTab[x][S_SCOPE] = FREE*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_x_51256 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _26324 = NOVALUE;

    /** emit.e:182				clear_temp( x )*/
    _47clear_temp(_x_51256);
L2: 
L1: 

    /** emit.e:185	end procedure*/
    return;
    ;
}


void _47TempInteger(object _x_51275)
{
    object _26331 = NOVALUE;
    object _26330 = NOVALUE;
    object _26329 = NOVALUE;
    object _26328 = NOVALUE;
    object _26327 = NOVALUE;
    object _26326 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_x_51275)) {
        _1 = (object)(DBL_PTR(_x_51275)->dbl);
        DeRefDS(_x_51275);
        _x_51275 = _1;
    }

    /** emit.e:188		if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26326 = (_x_51275 > 0);
    if (_26326 == 0) {
        goto L1; // [9] 53
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26328 = (object)*(((s1_ptr)_2)->base + _x_51275);
    _2 = (object)SEQ_PTR(_26328);
    _26329 = (object)*(((s1_ptr)_2)->base + 3);
    _26328 = NOVALUE;
    if (IS_ATOM_INT(_26329)) {
        _26330 = (_26329 == 3);
    }
    else {
        _26330 = binary_op(EQUALS, _26329, 3);
    }
    _26329 = NOVALUE;
    if (_26330 == 0) {
        DeRef(_26330);
        _26330 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26330) && DBL_PTR(_26330)->dbl == 0.0){
            DeRef(_26330);
            _26330 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26330);
        _26330 = NOVALUE;
    }
    DeRef(_26330);
    _26330 = NOVALUE;

    /** emit.e:189			SymTab[x][S_USAGE] = T_INTEGER*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_x_51275 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _26331 = NOVALUE;
L1: 

    /** emit.e:191	end procedure*/
    DeRef(_26326);
    _26326 = NOVALUE;
    return;
    ;
}


object _47LexName(object _t_51292, object _defname_51293)
{
    object _name_51295 = NOVALUE;
    object _26340 = NOVALUE;
    object _26338 = NOVALUE;
    object _26336 = NOVALUE;
    object _26335 = NOVALUE;
    object _26334 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_t_51292)) {
        _1 = (object)(DBL_PTR(_t_51292)->dbl);
        DeRefDS(_t_51292);
        _t_51292 = _1;
    }

    /** emit.e:197		for i = 1 to length(token_name) do*/
    _26334 = 80;
    {
        object _i_51297;
        _i_51297 = 1;
L1: 
        if (_i_51297 > 80){
            goto L2; // [12] 82
        }

        /** emit.e:198			if t = token_name[i][LEX_NUMBER] then*/
        _2 = (object)SEQ_PTR(_47token_name_50959);
        _26335 = (object)*(((s1_ptr)_2)->base + _i_51297);
        _2 = (object)SEQ_PTR(_26335);
        _26336 = (object)*(((s1_ptr)_2)->base + 1);
        _26335 = NOVALUE;
        if (binary_op_a(NOTEQ, _t_51292, _26336)){
            _26336 = NOVALUE;
            goto L3; // [31] 75
        }
        _26336 = NOVALUE;

        /** emit.e:199				name = token_name[i][LEX_NAME]*/
        _2 = (object)SEQ_PTR(_47token_name_50959);
        _26338 = (object)*(((s1_ptr)_2)->base + _i_51297);
        DeRef(_name_51295);
        _2 = (object)SEQ_PTR(_26338);
        _name_51295 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_name_51295);
        _26338 = NOVALUE;

        /** emit.e:200				if not find(' ', name) then*/
        _26340 = find_from(32, _name_51295, 1);
        if (_26340 != 0)
        goto L4; // [56] 68
        _26340 = NOVALUE;

        /** emit.e:201					name = "'" & name & "'"*/
        {
            object concat_list[3];

            concat_list[0] = _26342;
            concat_list[1] = _name_51295;
            concat_list[2] = _26342;
            Concat_N((object_ptr)&_name_51295, concat_list, 3);
        }
L4: 

        /** emit.e:203				return name*/
        DeRefDSi(_defname_51293);
        return _name_51295;
L3: 

        /** emit.e:205		end for*/
        _i_51297 = _i_51297 + 1;
        goto L1; // [77] 19
L2: 
        ;
    }

    /** emit.e:206		return defname -- try to avoid this case*/
    DeRef(_name_51295);
    return _defname_51293;
    ;
}


void _47InitEmit()
{
    object _0, _1, _2;
    

    /** emit.e:212		cg_stack = repeat(0, 400)*/
    DeRef(_47cg_stack_50951);
    _47cg_stack_50951 = Repeat(0, 400);

    /** emit.e:213		cgi = 0*/
    _47cgi_50952 = 0;

    /** emit.e:214	end procedure*/
    return;
    ;
}


object _47IsInteger(object _sym_51316)
{
    object _mode_51317 = NOVALUE;
    object _t_51319 = NOVALUE;
    object _pt_51320 = NOVALUE;
    object _26365 = NOVALUE;
    object _26364 = NOVALUE;
    object _26362 = NOVALUE;
    object _26361 = NOVALUE;
    object _26360 = NOVALUE;
    object _26358 = NOVALUE;
    object _26357 = NOVALUE;
    object _26356 = NOVALUE;
    object _26355 = NOVALUE;
    object _26353 = NOVALUE;
    object _26349 = NOVALUE;
    object _26346 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_51316)) {
        _1 = (object)(DBL_PTR(_sym_51316)->dbl);
        DeRefDS(_sym_51316);
        _sym_51316 = _1;
    }

    /** emit.e:221		if sym < 1 then*/
    if (_sym_51316 >= 1)
    goto L1; // [5] 16

    /** emit.e:223			return 0*/
    return 0;
L1: 

    /** emit.e:226		mode = SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26346 = (object)*(((s1_ptr)_2)->base + _sym_51316);
    _2 = (object)SEQ_PTR(_26346);
    _mode_51317 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_51317)){
        _mode_51317 = (object)DBL_PTR(_mode_51317)->dbl;
    }
    _26346 = NOVALUE;

    /** emit.e:227		if mode = M_NORMAL then*/
    if (_mode_51317 != 1)
    goto L2; // [36] 136

    /** emit.e:228			t = SymTab[sym][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26349 = (object)*(((s1_ptr)_2)->base + _sym_51316);
    _2 = (object)SEQ_PTR(_26349);
    _t_51319 = (object)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_t_51319)){
        _t_51319 = (object)DBL_PTR(_t_51319)->dbl;
    }
    _26349 = NOVALUE;

    /** emit.e:229			if t = integer_type then*/
    if (_t_51319 != _54integer_type_46786)
    goto L3; // [60] 73

    /** emit.e:230				return TRUE*/
    return _13TRUE_452;
L3: 

    /** emit.e:232			if t > 0 then*/
    if (_t_51319 <= 0)
    goto L4; // [75] 215

    /** emit.e:233				pt = SymTab[t][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26353 = (object)*(((s1_ptr)_2)->base + _t_51319);
    _2 = (object)SEQ_PTR(_26353);
    _pt_51320 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_pt_51320)){
        _pt_51320 = (object)DBL_PTR(_pt_51320)->dbl;
    }
    _26353 = NOVALUE;

    /** emit.e:234				if pt and SymTab[pt][S_VTYPE] = integer_type then*/
    if (_pt_51320 == 0) {
        goto L4; // [97] 215
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26356 = (object)*(((s1_ptr)_2)->base + _pt_51320);
    _2 = (object)SEQ_PTR(_26356);
    _26357 = (object)*(((s1_ptr)_2)->base + 15);
    _26356 = NOVALUE;
    if (IS_ATOM_INT(_26357)) {
        _26358 = (_26357 == _54integer_type_46786);
    }
    else {
        _26358 = binary_op(EQUALS, _26357, _54integer_type_46786);
    }
    _26357 = NOVALUE;
    if (_26358 == 0) {
        DeRef(_26358);
        _26358 = NOVALUE;
        goto L4; // [120] 215
    }
    else {
        if (!IS_ATOM_INT(_26358) && DBL_PTR(_26358)->dbl == 0.0){
            DeRef(_26358);
            _26358 = NOVALUE;
            goto L4; // [120] 215
        }
        DeRef(_26358);
        _26358 = NOVALUE;
    }
    DeRef(_26358);
    _26358 = NOVALUE;

    /** emit.e:235					return TRUE   -- usertype(integer x)*/
    return _13TRUE_452;
    goto L4; // [133] 215
L2: 

    /** emit.e:239		elsif mode = M_CONSTANT then*/
    if (_mode_51317 != 2)
    goto L5; // [140] 176

    /** emit.e:240			if integer(SymTab[sym][S_OBJ]) then  -- bug fixed: can't allow PLUS1_I op*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26360 = (object)*(((s1_ptr)_2)->base + _sym_51316);
    _2 = (object)SEQ_PTR(_26360);
    _26361 = (object)*(((s1_ptr)_2)->base + 1);
    _26360 = NOVALUE;
    if (IS_ATOM_INT(_26361))
    _26362 = 1;
    else if (IS_ATOM_DBL(_26361))
    _26362 = IS_ATOM_INT(DoubleToInt(_26361));
    else
    _26362 = 0;
    _26361 = NOVALUE;
    if (_26362 == 0)
    {
        _26362 = NOVALUE;
        goto L4; // [161] 215
    }
    else{
        _26362 = NOVALUE;
    }

    /** emit.e:241				return TRUE*/
    return _13TRUE_452;
    goto L4; // [173] 215
L5: 

    /** emit.e:244		elsif mode = M_TEMP then*/
    if (_mode_51317 != 3)
    goto L6; // [180] 214

    /** emit.e:245			if SymTab[sym][S_USAGE] = T_INTEGER then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26364 = (object)*(((s1_ptr)_2)->base + _sym_51316);
    _2 = (object)SEQ_PTR(_26364);
    _26365 = (object)*(((s1_ptr)_2)->base + 5);
    _26364 = NOVALUE;
    if (binary_op_a(NOTEQ, _26365, 1)){
        _26365 = NOVALUE;
        goto L7; // [200] 213
    }
    _26365 = NOVALUE;

    /** emit.e:246				return TRUE*/
    return _13TRUE_452;
L7: 
L6: 
L4: 

    /** emit.e:250		return FALSE*/
    return _13FALSE_450;
    ;
}


void _47emit(object _val_51377)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_val_51377)) {
        _1 = (object)(DBL_PTR(_val_51377)->dbl);
        DeRefDS(_val_51377);
        _val_51377 = _1;
    }

    /** emit.e:260		Code = append(Code, val)*/
    Append(&_36Code_21539, _36Code_21539, _val_51377);

    /** emit.e:261	end procedure*/
    return;
    ;
}


void _47emit_opnd(object _opnd_51384)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_opnd_51384)) {
        _1 = (object)(DBL_PTR(_opnd_51384)->dbl);
        DeRefDS(_opnd_51384);
        _opnd_51384 = _1;
    }

    /** emit.e:271			Push(opnd)*/
    _47Push(_opnd_51384);

    /** emit.e:272			previous_op = -1  -- N.B.*/
    _36previous_op_21549 = -1;

    /** emit.e:273	end procedure*/
    return;
    ;
}


void _47emit_addr(object _x_51388)
{
    object _0, _1, _2;
    

    /** emit.e:277			Code = append(Code, x)*/
    Ref(_x_51388);
    Append(&_36Code_21539, _36Code_21539, _x_51388);

    /** emit.e:278	end procedure*/
    DeRef(_x_51388);
    return;
    ;
}


void _47emit_opcode(object _op_51394)
{
    object _0, _1, _2;
    

    /** emit.e:282		Code = append(Code, op)*/
    Append(&_36Code_21539, _36Code_21539, _op_51394);

    /** emit.e:283	end procedure*/
    return;
    ;
}


void _47emit_temp(object _tempsym_51428, object _referenced_51429)
{
    object _26396 = NOVALUE;
    object _26395 = NOVALUE;
    object _26394 = NOVALUE;
    object _26393 = NOVALUE;
    object _26392 = NOVALUE;
    object _26391 = NOVALUE;
    object _26390 = NOVALUE;
    object _26389 = NOVALUE;
    object _26388 = NOVALUE;
    object _26387 = NOVALUE;
    object _26386 = NOVALUE;
    object _26385 = NOVALUE;
    object _26384 = NOVALUE;
    object _26383 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:307		if not TRANSLATE  then -- translator has its own way of handling temps*/
    if (_36TRANSLATE_21049 != 0)
    goto L1; // [7] 129

    /** emit.e:308			if sequence(tempsym) then*/
    _26383 = IS_SEQUENCE(_tempsym_51428);
    if (_26383 == 0)
    {
        _26383 = NOVALUE;
        goto L2; // [15] 53
    }
    else{
        _26383 = NOVALUE;
    }

    /** emit.e:309				for i = 1 to length(tempsym) do*/
    if (IS_SEQUENCE(_tempsym_51428)){
            _26384 = SEQ_PTR(_tempsym_51428)->length;
    }
    else {
        _26384 = 1;
    }
    {
        object _i_51436;
        _i_51436 = 1;
L3: 
        if (_i_51436 > _26384){
            goto L4; // [23] 50
        }

        /** emit.e:310					emit_temp( tempsym[i], referenced )*/
        _2 = (object)SEQ_PTR(_tempsym_51428);
        _26385 = (object)*(((s1_ptr)_2)->base + _i_51436);
        DeRef(_26386);
        _26386 = _referenced_51429;
        Ref(_26385);
        _47emit_temp(_26385, _26386);
        _26385 = NOVALUE;
        _26386 = NOVALUE;

        /** emit.e:311				end for*/
        _i_51436 = _i_51436 + 1;
        goto L3; // [45] 30
L4: 
        ;
    }
    goto L5; // [50] 128
L2: 

    /** emit.e:313			elsif tempsym > 0*/
    if (IS_ATOM_INT(_tempsym_51428)) {
        _26387 = (_tempsym_51428 > 0);
    }
    else {
        _26387 = binary_op(GREATER, _tempsym_51428, 0);
    }
    if (IS_ATOM_INT(_26387)) {
        if (_26387 == 0) {
            DeRef(_26388);
            _26388 = 0;
            goto L6; // [59] 77
        }
    }
    else {
        if (DBL_PTR(_26387)->dbl == 0.0) {
            DeRef(_26388);
            _26388 = 0;
            goto L6; // [59] 77
        }
    }
    Ref(_tempsym_51428);
    _26389 = _54sym_mode(_tempsym_51428);
    if (IS_ATOM_INT(_26389)) {
        _26390 = (_26389 == 3);
    }
    else {
        _26390 = binary_op(EQUALS, _26389, 3);
    }
    DeRef(_26389);
    _26389 = NOVALUE;
    DeRef(_26388);
    if (IS_ATOM_INT(_26390))
    _26388 = (_26390 != 0);
    else
    _26388 = DBL_PTR(_26390)->dbl != 0.0;
L6: 
    if (_26388 == 0) {
        _26391 = 0;
        goto L7; // [77] 92
    }
    Ref(_tempsym_51428);
    _26392 = _47IsInteger(_tempsym_51428);
    if (IS_ATOM_INT(_26392)) {
        _26393 = (_26392 == 0);
    }
    else {
        _26393 = unary_op(NOT, _26392);
    }
    DeRef(_26392);
    _26392 = NOVALUE;
    if (IS_ATOM_INT(_26393))
    _26391 = (_26393 != 0);
    else
    _26391 = DBL_PTR(_26393)->dbl != 0.0;
L7: 
    if (_26391 == 0) {
        goto L8; // [92] 127
    }
    _26395 = find_from(_tempsym_51428, _47emitted_temps_51424, 1);
    _26396 = (_26395 == 0);
    _26395 = NOVALUE;
    if (_26396 == 0)
    {
        DeRef(_26396);
        _26396 = NOVALUE;
        goto L8; // [107] 127
    }
    else{
        DeRef(_26396);
        _26396 = NOVALUE;
    }

    /** emit.e:319				emitted_temps &= tempsym*/
    if (IS_SEQUENCE(_47emitted_temps_51424) && IS_ATOM(_tempsym_51428)) {
        Ref(_tempsym_51428);
        Append(&_47emitted_temps_51424, _47emitted_temps_51424, _tempsym_51428);
    }
    else if (IS_ATOM(_47emitted_temps_51424) && IS_SEQUENCE(_tempsym_51428)) {
    }
    else {
        Concat((object_ptr)&_47emitted_temps_51424, _47emitted_temps_51424, _tempsym_51428);
    }

    /** emit.e:320				emitted_temp_referenced &= referenced*/
    Append(&_47emitted_temp_referenced_51425, _47emitted_temp_referenced_51425, _referenced_51429);
L8: 
L5: 
L1: 

    /** emit.e:323	end procedure*/
    DeRef(_tempsym_51428);
    DeRef(_26393);
    _26393 = NOVALUE;
    DeRef(_26387);
    _26387 = NOVALUE;
    DeRef(_26390);
    _26390 = NOVALUE;
    return;
    ;
}


void _47flush_temps(object _except_for_51458)
{
    object _refs_51461 = NOVALUE;
    object _novalues_51462 = NOVALUE;
    object _sym_51467 = NOVALUE;
    object _26411 = NOVALUE;
    object _26410 = NOVALUE;
    object _26409 = NOVALUE;
    object _26408 = NOVALUE;
    object _26406 = NOVALUE;
    object _26402 = NOVALUE;
    object _26401 = NOVALUE;
    object _26399 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:332		if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L1; // [7] 16
    }
    else{
    }

    /** emit.e:333			return*/
    DeRefDS(_except_for_51458);
    DeRef(_refs_51461);
    DeRefi(_novalues_51462);
    return;
L1: 

    /** emit.e:336		sequence*/

    /** emit.e:337			refs = {},*/
    RefDS(_21997);
    DeRef(_refs_51461);
    _refs_51461 = _21997;

    /** emit.e:338			novalues = {}*/
    RefDS(_21997);
    DeRefi(_novalues_51462);
    _novalues_51462 = _21997;

    /** emit.e:340		derefs = {}*/
    RefDS(_21997);
    DeRefi(_47derefs_51455);
    _47derefs_51455 = _21997;

    /** emit.e:341		for i = 1 to length( emitted_temps ) do*/
    if (IS_SEQUENCE(_47emitted_temps_51424)){
            _26399 = SEQ_PTR(_47emitted_temps_51424)->length;
    }
    else {
        _26399 = 1;
    }
    {
        object _i_51464;
        _i_51464 = 1;
L2: 
        if (_i_51464 > _26399){
            goto L3; // [46] 119
        }

        /** emit.e:342			symtab_index sym = emitted_temps[i]*/
        _2 = (object)SEQ_PTR(_47emitted_temps_51424);
        _sym_51467 = (object)*(((s1_ptr)_2)->base + _i_51464);
        if (!IS_ATOM_INT(_sym_51467)){
            _sym_51467 = (object)DBL_PTR(_sym_51467)->dbl;
        }

        /** emit.e:344			if find( sym, except_for ) then*/
        _26401 = find_from(_sym_51467, _except_for_51458, 1);
        if (_26401 == 0)
        {
            _26401 = NOVALUE;
            goto L4; // [70] 80
        }
        else{
            _26401 = NOVALUE;
        }

        /** emit.e:345				continue*/
        goto L5; // [77] 114
L4: 

        /** emit.e:348			if emitted_temp_referenced[i] = NEW_REFERENCE then*/
        _2 = (object)SEQ_PTR(_47emitted_temp_referenced_51425);
        _26402 = (object)*(((s1_ptr)_2)->base + _i_51464);
        if (binary_op_a(NOTEQ, _26402, 1)){
            _26402 = NOVALUE;
            goto L6; // [88] 103
        }
        _26402 = NOVALUE;

        /** emit.e:349				derefs &= sym*/
        Append(&_47derefs_51455, _47derefs_51455, _sym_51467);
        goto L7; // [100] 110
L6: 

        /** emit.e:351				novalues &= sym*/
        Append(&_novalues_51462, _novalues_51462, _sym_51467);
L7: 

        /** emit.e:353		end for*/
L5: 
        _i_51464 = _i_51464 + 1;
        goto L2; // [114] 53
L3: 
        ;
    }

    /** emit.e:355		if not length( except_for ) then*/
    if (IS_SEQUENCE(_except_for_51458)){
            _26406 = SEQ_PTR(_except_for_51458)->length;
    }
    else {
        _26406 = 1;
    }
    if (_26406 != 0)
    goto L8; // [124] 132
    _26406 = NOVALUE;

    /** emit.e:356			clear_last()*/
    _47clear_last();
L8: 

    /** emit.e:359		for i = 1 to length( derefs ) do*/
    if (IS_SEQUENCE(_47derefs_51455)){
            _26408 = SEQ_PTR(_47derefs_51455)->length;
    }
    else {
        _26408 = 1;
    }
    {
        object _i_51482;
        _i_51482 = 1;
L9: 
        if (_i_51482 > _26408){
            goto LA; // [139] 171
        }

        /** emit.e:360			emit( DEREF_TEMP )*/
        _47emit(208);

        /** emit.e:361			emit( derefs[i] )*/
        _2 = (object)SEQ_PTR(_47derefs_51455);
        _26409 = (object)*(((s1_ptr)_2)->base + _i_51482);
        _47emit(_26409);
        _26409 = NOVALUE;

        /** emit.e:362		end for*/
        _i_51482 = _i_51482 + 1;
        goto L9; // [166] 146
LA: 
        ;
    }

    /** emit.e:364		for i = 1 to length( novalues ) do*/
    if (IS_SEQUENCE(_novalues_51462)){
            _26410 = SEQ_PTR(_novalues_51462)->length;
    }
    else {
        _26410 = 1;
    }
    {
        object _i_51487;
        _i_51487 = 1;
LB: 
        if (_i_51487 > _26410){
            goto LC; // [176] 206
        }

        /** emit.e:365			emit( NOVALUE_TEMP )*/
        _47emit(209);

        /** emit.e:366			emit( novalues[i] )*/
        _2 = (object)SEQ_PTR(_novalues_51462);
        _26411 = (object)*(((s1_ptr)_2)->base + _i_51487);
        _47emit(_26411);
        _26411 = NOVALUE;

        /** emit.e:367		end for*/
        _i_51487 = _i_51487 + 1;
        goto LB; // [201] 183
LC: 
        ;
    }

    /** emit.e:369		emitted_temps = {}*/
    RefDS(_21997);
    DeRef(_47emitted_temps_51424);
    _47emitted_temps_51424 = _21997;

    /** emit.e:370		emitted_temp_referenced = {}*/
    RefDS(_21997);
    DeRef(_47emitted_temp_referenced_51425);
    _47emitted_temp_referenced_51425 = _21997;

    /** emit.e:371	end procedure*/
    DeRefDS(_except_for_51458);
    DeRef(_refs_51461);
    DeRefi(_novalues_51462);
    return;
    ;
}


void _47flush_temp(object _temp_51494)
{
    object _except_for_51495 = NOVALUE;
    object _ix_51496 = NOVALUE;
    object _26413 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_temp_51494)) {
        _1 = (object)(DBL_PTR(_temp_51494)->dbl);
        DeRefDS(_temp_51494);
        _temp_51494 = _1;
    }

    /** emit.e:374		sequence except_for = emitted_temps*/
    RefDS(_47emitted_temps_51424);
    DeRef(_except_for_51495);
    _except_for_51495 = _47emitted_temps_51424;

    /** emit.e:375		integer ix = find( temp, emitted_temps )*/
    _ix_51496 = find_from(_temp_51494, _47emitted_temps_51424, 1);

    /** emit.e:376		if ix then*/
    if (_ix_51496 == 0)
    {
        goto L1; // [23] 37
    }
    else{
    }

    /** emit.e:377			flush_temps( remove( except_for, ix ) )*/
    {
        s1_ptr assign_space = SEQ_PTR(_except_for_51495);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_51496)) ? _ix_51496 : (object)(DBL_PTR(_ix_51496)->dbl);
        int stop = (IS_ATOM_INT(_ix_51496)) ? _ix_51496 : (object)(DBL_PTR(_ix_51496)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
            RefDS(_except_for_51495);
            DeRef(_26413);
            _26413 = _except_for_51495;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_except_for_51495), start, &_26413 );
            }
            else Tail(SEQ_PTR(_except_for_51495), stop+1, &_26413);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_except_for_51495), start, &_26413);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_26413);
            _26413 = _1;
        }
    }
    _47flush_temps(_26413);
    _26413 = NOVALUE;
L1: 

    /** emit.e:379	end procedure*/
    DeRef(_except_for_51495);
    return;
    ;
}


void _47check_for_temps()
{
    object _26420 = NOVALUE;
    object _26419 = NOVALUE;
    object _26418 = NOVALUE;
    object _26417 = NOVALUE;
    object _26415 = NOVALUE;
    object _26414 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:382		if TRANSLATE or last_op < 1 or last_pc < 1 then*/
    if (_36TRANSLATE_21049 != 0) {
        _26414 = 1;
        goto L1; // [5] 19
    }
    _26415 = (_47last_op_51833 < 1);
    _26414 = (_26415 != 0);
L1: 
    if (_26414 != 0) {
        goto L2; // [19] 34
    }
    _26417 = (_47last_pc_51834 < 1);
    if (_26417 == 0)
    {
        DeRef(_26417);
        _26417 = NOVALUE;
        goto L3; // [30] 40
    }
    else{
        DeRef(_26417);
        _26417 = NOVALUE;
    }
L2: 

    /** emit.e:383			return*/
    DeRef(_26415);
    _26415 = NOVALUE;
    return;
L3: 

    /** emit.e:386		emit_temp( get_target_sym( current_op( last_pc ) ), op_temp_ref[last_op] )*/
    RefDS(_36Code_21539);
    _26418 = _66current_op(_47last_pc_51834, _36Code_21539);
    _26419 = _66get_target_sym(_26418);
    _26418 = NOVALUE;
    _2 = (object)SEQ_PTR(_47op_temp_ref_51646);
    _26420 = (object)*(((s1_ptr)_2)->base + _47last_op_51833);
    _47emit_temp(_26419, _26420);
    _26419 = NOVALUE;
    _26420 = NOVALUE;

    /** emit.e:388	end procedure*/
    DeRef(_26415);
    _26415 = NOVALUE;
    return;
    ;
}


void _47clear_temp(object _tempsym_51521)
{
    object _ix_51522 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tempsym_51521)) {
        _1 = (object)(DBL_PTR(_tempsym_51521)->dbl);
        DeRefDS(_tempsym_51521);
        _tempsym_51521 = _1;
    }

    /** emit.e:391		integer ix = find( tempsym, emitted_temps )*/
    _ix_51522 = find_from(_tempsym_51521, _47emitted_temps_51424, 1);

    /** emit.e:392		if ix then*/
    if (_ix_51522 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** emit.e:393			emitted_temps = remove( emitted_temps, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_47emitted_temps_51424);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_51522)) ? _ix_51522 : (object)(DBL_PTR(_ix_51522)->dbl);
        int stop = (IS_ATOM_INT(_ix_51522)) ? _ix_51522 : (object)(DBL_PTR(_ix_51522)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_47emitted_temps_51424), start, &_47emitted_temps_51424 );
            }
            else Tail(SEQ_PTR(_47emitted_temps_51424), stop+1, &_47emitted_temps_51424);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_47emitted_temps_51424), start, &_47emitted_temps_51424);
        }
        else {
            assign_slice_seq = &assign_space;
            _47emitted_temps_51424 = Remove_elements(start, stop, (SEQ_PTR(_47emitted_temps_51424)->ref == 1));
        }
    }

    /** emit.e:394			emitted_temp_referenced = remove( emitted_temp_referenced, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_47emitted_temp_referenced_51425);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_51522)) ? _ix_51522 : (object)(DBL_PTR(_ix_51522)->dbl);
        int stop = (IS_ATOM_INT(_ix_51522)) ? _ix_51522 : (object)(DBL_PTR(_ix_51522)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_47emitted_temp_referenced_51425), start, &_47emitted_temp_referenced_51425 );
            }
            else Tail(SEQ_PTR(_47emitted_temp_referenced_51425), stop+1, &_47emitted_temp_referenced_51425);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_47emitted_temp_referenced_51425), start, &_47emitted_temp_referenced_51425);
        }
        else {
            assign_slice_seq = &assign_space;
            _47emitted_temp_referenced_51425 = Remove_elements(start, stop, (SEQ_PTR(_47emitted_temp_referenced_51425)->ref == 1));
        }
    }
L1: 

    /** emit.e:396	end procedure*/
    return;
    ;
}


object _47pop_temps()
{
    object _new_emitted_51529 = NOVALUE;
    object _new_referenced_51530 = NOVALUE;
    object _26424 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:402		sequence new_emitted  = emitted_temps*/
    RefDS(_47emitted_temps_51424);
    DeRef(_new_emitted_51529);
    _new_emitted_51529 = _47emitted_temps_51424;

    /** emit.e:403		sequence new_referenced = emitted_temp_referenced*/
    RefDS(_47emitted_temp_referenced_51425);
    DeRef(_new_referenced_51530);
    _new_referenced_51530 = _47emitted_temp_referenced_51425;

    /** emit.e:405		emitted_temps  = {}*/
    RefDS(_21997);
    DeRefDS(_47emitted_temps_51424);
    _47emitted_temps_51424 = _21997;

    /** emit.e:406		emitted_temp_referenced = {}*/
    RefDS(_21997);
    DeRefDS(_47emitted_temp_referenced_51425);
    _47emitted_temp_referenced_51425 = _21997;

    /** emit.e:407		return { new_emitted, new_referenced }*/
    RefDS(_new_referenced_51530);
    RefDS(_new_emitted_51529);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _new_emitted_51529;
    ((intptr_t *)_2)[2] = _new_referenced_51530;
    _26424 = MAKE_SEQ(_1);
    DeRefDS(_new_emitted_51529);
    DeRefDS(_new_referenced_51530);
    return _26424;
    ;
}


object _47get_temps(object _add_to_51534)
{
    object _26429 = NOVALUE;
    object _26428 = NOVALUE;
    object _26427 = NOVALUE;
    object _26426 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:416		add_to[1] &= emitted_temps*/
    _2 = (object)SEQ_PTR(_add_to_51534);
    _26426 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_26426) && IS_ATOM(_47emitted_temps_51424)) {
    }
    else if (IS_ATOM(_26426) && IS_SEQUENCE(_47emitted_temps_51424)) {
        Ref(_26426);
        Prepend(&_26427, _47emitted_temps_51424, _26426);
    }
    else {
        Concat((object_ptr)&_26427, _26426, _47emitted_temps_51424);
        _26426 = NOVALUE;
    }
    _26426 = NOVALUE;
    _2 = (object)SEQ_PTR(_add_to_51534);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _add_to_51534 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _26427;
    if( _1 != _26427 ){
        DeRef(_1);
    }
    _26427 = NOVALUE;

    /** emit.e:417		add_to[2] &= emitted_temp_referenced*/
    _2 = (object)SEQ_PTR(_add_to_51534);
    _26428 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_26428) && IS_ATOM(_47emitted_temp_referenced_51425)) {
    }
    else if (IS_ATOM(_26428) && IS_SEQUENCE(_47emitted_temp_referenced_51425)) {
        Ref(_26428);
        Prepend(&_26429, _47emitted_temp_referenced_51425, _26428);
    }
    else {
        Concat((object_ptr)&_26429, _26428, _47emitted_temp_referenced_51425);
        _26428 = NOVALUE;
    }
    _26428 = NOVALUE;
    _2 = (object)SEQ_PTR(_add_to_51534);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _add_to_51534 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _26429;
    if( _1 != _26429 ){
        DeRef(_1);
    }
    _26429 = NOVALUE;

    /** emit.e:418		return add_to*/
    return _add_to_51534;
    ;
}


void _47push_temps(object _temps_51542)
{
    object _26432 = NOVALUE;
    object _26430 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:426		emitted_temps &= temps[1]*/
    _2 = (object)SEQ_PTR(_temps_51542);
    _26430 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_47emitted_temps_51424) && IS_ATOM(_26430)) {
        Ref(_26430);
        Append(&_47emitted_temps_51424, _47emitted_temps_51424, _26430);
    }
    else if (IS_ATOM(_47emitted_temps_51424) && IS_SEQUENCE(_26430)) {
    }
    else {
        Concat((object_ptr)&_47emitted_temps_51424, _47emitted_temps_51424, _26430);
    }
    _26430 = NOVALUE;

    /** emit.e:427		emitted_temp_referenced &= temps[2]*/
    _2 = (object)SEQ_PTR(_temps_51542);
    _26432 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_47emitted_temp_referenced_51425) && IS_ATOM(_26432)) {
        Ref(_26432);
        Append(&_47emitted_temp_referenced_51425, _47emitted_temp_referenced_51425, _26432);
    }
    else if (IS_ATOM(_47emitted_temp_referenced_51425) && IS_SEQUENCE(_26432)) {
    }
    else {
        Concat((object_ptr)&_47emitted_temp_referenced_51425, _47emitted_temp_referenced_51425, _26432);
    }
    _26432 = NOVALUE;

    /** emit.e:428		flush_temps()*/
    RefDS(_21997);
    _47flush_temps(_21997);

    /** emit.e:429	end procedure*/
    DeRefDS(_temps_51542);
    return;
    ;
}


void _47backpatch(object _index_51549, object _val_51550)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_index_51549)) {
        _1 = (object)(DBL_PTR(_index_51549)->dbl);
        DeRefDS(_index_51549);
        _index_51549 = _1;
    }
    if (!IS_ATOM_INT(_val_51550)) {
        _1 = (object)(DBL_PTR(_val_51550)->dbl);
        DeRefDS(_val_51550);
        _val_51550 = _1;
    }

    /** emit.e:433			Code[index] = val*/
    _2 = (object)SEQ_PTR(_36Code_21539);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21539 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _index_51549);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _val_51550;
    DeRef(_1);

    /** emit.e:434	end procedure*/
    return;
    ;
}


void _47cont11ii(object _op_51734, object _ii_51736)
{
    object _t_51737 = NOVALUE;
    object _source_51738 = NOVALUE;
    object _c_51739 = NOVALUE;
    object _26441 = NOVALUE;
    object _26440 = NOVALUE;
    object _26438 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:580		emit_opcode(op)*/
    _47emit_opcode(_op_51734);

    /** emit.e:581		source = Pop()*/
    _source_51738 = _47Pop();
    if (!IS_ATOM_INT(_source_51738)) {
        _1 = (object)(DBL_PTR(_source_51738)->dbl);
        DeRefDS(_source_51738);
        _source_51738 = _1;
    }

    /** emit.e:582		emit_addr(source)*/
    _47emit_addr(_source_51738);

    /** emit.e:583		assignable = TRUE*/
    _47assignable_50954 = _13TRUE_452;

    /** emit.e:584		t = op_result[op]*/
    _2 = (object)SEQ_PTR(_47op_result_51552);
    _t_51737 = (object)*(((s1_ptr)_2)->base + _op_51734);

    /** emit.e:587		if t = T_INTEGER or (ii and IsInteger(source)) then*/
    _26438 = (_t_51737 == 1);
    if (_26438 != 0) {
        goto L1; // [43] 64
    }
    if (_ii_51736 == 0) {
        _26440 = 0;
        goto L2; // [47] 59
    }
    _26441 = _47IsInteger(_source_51738);
    if (IS_ATOM_INT(_26441))
    _26440 = (_26441 != 0);
    else
    _26440 = DBL_PTR(_26441)->dbl != 0.0;
L2: 
    if (_26440 == 0)
    {
        _26440 = NOVALUE;
        goto L3; // [60] 80
    }
    else{
        _26440 = NOVALUE;
    }
L1: 

    /** emit.e:588			c = NewTempSym()*/
    _c_51739 = _54NewTempSym(0);
    if (!IS_ATOM_INT(_c_51739)) {
        _1 = (object)(DBL_PTR(_c_51739)->dbl);
        DeRefDS(_c_51739);
        _c_51739 = _1;
    }

    /** emit.e:589			TempInteger(c)*/
    _47TempInteger(_c_51739);
    goto L4; // [77] 95
L3: 

    /** emit.e:591			c = NewTempSym() -- allocate *after* checking opnd type*/
    _c_51739 = _54NewTempSym(0);
    if (!IS_ATOM_INT(_c_51739)) {
        _1 = (object)(DBL_PTR(_c_51739)->dbl);
        DeRefDS(_c_51739);
        _c_51739 = _1;
    }

    /** emit.e:592			emit_temp( c, NEW_REFERENCE )*/
    _47emit_temp(_c_51739, 1);
L4: 

    /** emit.e:595		Push(c)*/
    _47Push(_c_51739);

    /** emit.e:596		emit_addr(c)*/
    _47emit_addr(_c_51739);

    /** emit.e:597	end procedure*/
    DeRef(_26441);
    _26441 = NOVALUE;
    DeRef(_26438);
    _26438 = NOVALUE;
    return;
    ;
}


void _47cont21d(object _op_51756, object _a_51757, object _b_51758, object _ii_51760)
{
    object _c_51761 = NOVALUE;
    object _t_51762 = NOVALUE;
    object _26451 = NOVALUE;
    object _26450 = NOVALUE;
    object _26449 = NOVALUE;
    object _26448 = NOVALUE;
    object _26446 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:602		assignable = TRUE*/
    _47assignable_50954 = _13TRUE_452;

    /** emit.e:603		t = op_result[op]*/
    _2 = (object)SEQ_PTR(_47op_result_51552);
    _t_51762 = (object)*(((s1_ptr)_2)->base + _op_51756);

    /** emit.e:604		if op = C_FUNC then*/
    if (_op_51756 != 133)
    goto L1; // [26] 38

    /** emit.e:605			emit_addr(CurrentSub)*/
    _47emit_addr(_36CurrentSub_21455);
L1: 

    /** emit.e:607		if t = T_INTEGER or (ii and IsInteger(a) and IsInteger(b)) then*/
    _26446 = (_t_51762 == 1);
    if (_26446 != 0) {
        goto L2; // [46] 79
    }
    if (_ii_51760 == 0) {
        _26448 = 0;
        goto L3; // [50] 62
    }
    _26449 = _47IsInteger(_a_51757);
    if (IS_ATOM_INT(_26449))
    _26448 = (_26449 != 0);
    else
    _26448 = DBL_PTR(_26449)->dbl != 0.0;
L3: 
    if (_26448 == 0) {
        DeRef(_26450);
        _26450 = 0;
        goto L4; // [62] 74
    }
    _26451 = _47IsInteger(_b_51758);
    if (IS_ATOM_INT(_26451))
    _26450 = (_26451 != 0);
    else
    _26450 = DBL_PTR(_26451)->dbl != 0.0;
L4: 
    if (_26450 == 0)
    {
        _26450 = NOVALUE;
        goto L5; // [75] 95
    }
    else{
        _26450 = NOVALUE;
    }
L2: 

    /** emit.e:608			c = NewTempSym()*/
    _c_51761 = _54NewTempSym(0);
    if (!IS_ATOM_INT(_c_51761)) {
        _1 = (object)(DBL_PTR(_c_51761)->dbl);
        DeRefDS(_c_51761);
        _c_51761 = _1;
    }

    /** emit.e:609			TempInteger(c)*/
    _47TempInteger(_c_51761);
    goto L6; // [92] 110
L5: 

    /** emit.e:611			c = NewTempSym() -- allocate *after* checking opnd types*/
    _c_51761 = _54NewTempSym(0);
    if (!IS_ATOM_INT(_c_51761)) {
        _1 = (object)(DBL_PTR(_c_51761)->dbl);
        DeRefDS(_c_51761);
        _c_51761 = _1;
    }

    /** emit.e:612			emit_temp( c, NEW_REFERENCE )*/
    _47emit_temp(_c_51761, 1);
L6: 

    /** emit.e:614		Push(c)*/
    _47Push(_c_51761);

    /** emit.e:615		emit_addr(c)*/
    _47emit_addr(_c_51761);

    /** emit.e:616	end procedure*/
    DeRef(_26451);
    _26451 = NOVALUE;
    DeRef(_26449);
    _26449 = NOVALUE;
    DeRef(_26446);
    _26446 = NOVALUE;
    return;
    ;
}


void _47cont21ii(object _op_51784, object _ii_51786)
{
    object _a_51787 = NOVALUE;
    object _b_51788 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:621		b = Pop()*/
    _b_51788 = _47Pop();
    if (!IS_ATOM_INT(_b_51788)) {
        _1 = (object)(DBL_PTR(_b_51788)->dbl);
        DeRefDS(_b_51788);
        _b_51788 = _1;
    }

    /** emit.e:622		emit_opcode(op)*/
    _47emit_opcode(_op_51784);

    /** emit.e:623		a = Pop()*/
    _a_51787 = _47Pop();
    if (!IS_ATOM_INT(_a_51787)) {
        _1 = (object)(DBL_PTR(_a_51787)->dbl);
        DeRefDS(_a_51787);
        _a_51787 = _1;
    }

    /** emit.e:624		emit_addr(a)*/
    _47emit_addr(_a_51787);

    /** emit.e:625		emit_addr(b)*/
    _47emit_addr(_b_51788);

    /** emit.e:626		cont21d(op, a, b, ii)*/
    _47cont21d(_op_51784, _a_51787, _b_51788, _ii_51786);

    /** emit.e:627	end procedure*/
    return;
    ;
}


object _47good_string(object _elements_51793)
{
    object _obj_51794 = NOVALUE;
    object _ep_51796 = NOVALUE;
    object _e_51798 = NOVALUE;
    object _element_vals_51799 = NOVALUE;
    object _26474 = NOVALUE;
    object _26473 = NOVALUE;
    object _26472 = NOVALUE;
    object _26471 = NOVALUE;
    object _26470 = NOVALUE;
    object _26469 = NOVALUE;
    object _26468 = NOVALUE;
    object _26467 = NOVALUE;
    object _26466 = NOVALUE;
    object _26465 = NOVALUE;
    object _26464 = NOVALUE;
    object _26462 = NOVALUE;
    object _26459 = NOVALUE;
    object _26458 = NOVALUE;
    object _26457 = NOVALUE;
    object _26456 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:634		sequence element_vals*/

    /** emit.e:636		if TRANSLATE and length(elements) > 10000 then*/
    if (_36TRANSLATE_21049 == 0) {
        goto L1; // [9] 31
    }
    if (IS_SEQUENCE(_elements_51793)){
            _26457 = SEQ_PTR(_elements_51793)->length;
    }
    else {
        _26457 = 1;
    }
    _26458 = (_26457 > 10000);
    _26457 = NOVALUE;
    if (_26458 == 0)
    {
        DeRef(_26458);
        _26458 = NOVALUE;
        goto L1; // [21] 31
    }
    else{
        DeRef(_26458);
        _26458 = NOVALUE;
    }

    /** emit.e:637			return -1 -- A huge string might upset the C compiler.*/
    DeRefDS(_elements_51793);
    DeRef(_obj_51794);
    DeRef(_element_vals_51799);
    return -1;
L1: 

    /** emit.e:639		element_vals = {}*/
    RefDS(_21997);
    DeRef(_element_vals_51799);
    _element_vals_51799 = _21997;

    /** emit.e:640		for i = 1 to length(elements) do*/
    if (IS_SEQUENCE(_elements_51793)){
            _26459 = SEQ_PTR(_elements_51793)->length;
    }
    else {
        _26459 = 1;
    }
    {
        object _i_51806;
        _i_51806 = 1;
L2: 
        if (_i_51806 > _26459){
            goto L3; // [43] 183
        }

        /** emit.e:641			ep = elements[i]*/
        _2 = (object)SEQ_PTR(_elements_51793);
        _ep_51796 = (object)*(((s1_ptr)_2)->base + _i_51806);
        if (!IS_ATOM_INT(_ep_51796)){
            _ep_51796 = (object)DBL_PTR(_ep_51796)->dbl;
        }

        /** emit.e:642			if ep < 1 then*/
        if (_ep_51796 >= 1)
        goto L4; // [60] 71

        /** emit.e:644				return -1*/
        DeRefDS(_elements_51793);
        DeRef(_obj_51794);
        DeRef(_element_vals_51799);
        return -1;
L4: 

        /** emit.e:646			e = ep*/
        _e_51798 = _ep_51796;

        /** emit.e:647			obj = SymTab[e][S_OBJ]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26462 = (object)*(((s1_ptr)_2)->base + _e_51798);
        DeRef(_obj_51794);
        _2 = (object)SEQ_PTR(_26462);
        _obj_51794 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_obj_51794);
        _26462 = NOVALUE;

        /** emit.e:648			if SymTab[e][S_MODE] = M_CONSTANT and*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26464 = (object)*(((s1_ptr)_2)->base + _e_51798);
        _2 = (object)SEQ_PTR(_26464);
        _26465 = (object)*(((s1_ptr)_2)->base + 3);
        _26464 = NOVALUE;
        if (IS_ATOM_INT(_26465)) {
            _26466 = (_26465 == 2);
        }
        else {
            _26466 = binary_op(EQUALS, _26465, 2);
        }
        _26465 = NOVALUE;
        if (IS_ATOM_INT(_26466)) {
            if (_26466 == 0) {
                DeRef(_26467);
                _26467 = 0;
                goto L5; // [112] 123
            }
        }
        else {
            if (DBL_PTR(_26466)->dbl == 0.0) {
                DeRef(_26467);
                _26467 = 0;
                goto L5; // [112] 123
            }
        }
        if (IS_ATOM_INT(_obj_51794))
        _26468 = 1;
        else if (IS_ATOM_DBL(_obj_51794))
        _26468 = IS_ATOM_INT(DoubleToInt(_obj_51794));
        else
        _26468 = 0;
        DeRef(_26467);
        _26467 = (_26468 != 0);
L5: 
        if (_26467 == 0) {
            goto L6; // [123] 169
        }
        _26470 = (_36TRANSLATE_21049 == 0);
        if (_26470 != 0) {
            DeRef(_26471);
            _26471 = 1;
            goto L7; // [132] 156
        }
        if (IS_ATOM_INT(_obj_51794)) {
            _26472 = (_obj_51794 >= 1);
        }
        else {
            _26472 = binary_op(GREATEREQ, _obj_51794, 1);
        }
        if (IS_ATOM_INT(_26472)) {
            if (_26472 == 0) {
                DeRef(_26473);
                _26473 = 0;
                goto L8; // [140] 152
            }
        }
        else {
            if (DBL_PTR(_26472)->dbl == 0.0) {
                DeRef(_26473);
                _26473 = 0;
                goto L8; // [140] 152
            }
        }
        if (IS_ATOM_INT(_obj_51794)) {
            _26474 = (_obj_51794 <= 255);
        }
        else {
            _26474 = binary_op(LESSEQ, _obj_51794, 255);
        }
        DeRef(_26473);
        if (IS_ATOM_INT(_26474))
        _26473 = (_26474 != 0);
        else
        _26473 = DBL_PTR(_26474)->dbl != 0.0;
L8: 
        DeRef(_26471);
        _26471 = (_26473 != 0);
L7: 
        if (_26471 == 0)
        {
            _26471 = NOVALUE;
            goto L6; // [157] 169
        }
        else{
            _26471 = NOVALUE;
        }

        /** emit.e:653				element_vals = prepend(element_vals, obj)*/
        Ref(_obj_51794);
        Prepend(&_element_vals_51799, _element_vals_51799, _obj_51794);
        goto L9; // [166] 176
L6: 

        /** emit.e:655				return -1*/
        DeRefDS(_elements_51793);
        DeRef(_obj_51794);
        DeRef(_element_vals_51799);
        DeRef(_26466);
        _26466 = NOVALUE;
        DeRef(_26472);
        _26472 = NOVALUE;
        DeRef(_26470);
        _26470 = NOVALUE;
        DeRef(_26474);
        _26474 = NOVALUE;
        return -1;
L9: 

        /** emit.e:657		end for*/
        _i_51806 = _i_51806 + 1;
        goto L2; // [178] 50
L3: 
        ;
    }

    /** emit.e:658		return element_vals*/
    DeRefDS(_elements_51793);
    DeRef(_obj_51794);
    DeRef(_26466);
    _26466 = NOVALUE;
    DeRef(_26472);
    _26472 = NOVALUE;
    DeRef(_26470);
    _26470 = NOVALUE;
    DeRef(_26474);
    _26474 = NOVALUE;
    return _element_vals_51799;
    ;
}


object _47Last_op()
{
    object _0, _1, _2;
    

    /** emit.e:664		return last_op*/
    return _47last_op_51833;
    ;
}


object _47Last_pc()
{
    object _0, _1, _2;
    

    /** emit.e:668		return last_pc*/
    return _47last_pc_51834;
    ;
}


void _47move_last_pc(object _amount_51841)
{
    object _0, _1, _2;
    

    /** emit.e:672		if last_pc > 0 then*/
    if (_47last_pc_51834 <= 0)
    goto L1; // [7] 20

    /** emit.e:673			last_pc += amount*/
    _47last_pc_51834 = _47last_pc_51834 + _amount_51841;
L1: 

    /** emit.e:675	end procedure*/
    return;
    ;
}


void _47clear_last()
{
    object _0, _1, _2;
    

    /** emit.e:678		last_op = 0*/
    _47last_op_51833 = 0;

    /** emit.e:679		last_pc = 0*/
    _47last_pc_51834 = 0;

    /** emit.e:680	end procedure*/
    return;
    ;
}


void _47clear_op()
{
    object _0, _1, _2;
    

    /** emit.e:683		previous_op = -1*/
    _36previous_op_21549 = -1;

    /** emit.e:684		assignable = FALSE*/
    _47assignable_50954 = _13FALSE_450;

    /** emit.e:685	end procedure*/
    return;
    ;
}


void _47inlined_function()
{
    object _0, _1, _2;
    

    /** emit.e:689		previous_op = PROC*/
    _36previous_op_21549 = 27;

    /** emit.e:690		assignable = TRUE*/
    _47assignable_50954 = _13TRUE_452;

    /** emit.e:691		inlined = TRUE*/
    _47inlined_51852 = _13TRUE_452;

    /** emit.e:692	end procedure*/
    return;
    ;
}


void _47add_inline_target(object _pc_51863)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_51863)) {
        _1 = (object)(DBL_PTR(_pc_51863)->dbl);
        DeRefDS(_pc_51863);
        _pc_51863 = _1;
    }

    /** emit.e:696		inlined_targets &= pc*/
    Append(&_47inlined_targets_51860, _47inlined_targets_51860, _pc_51863);

    /** emit.e:697	end procedure*/
    return;
    ;
}


void _47clear_inline_targets()
{
    object _0, _1, _2;
    

    /** emit.e:700		inlined_targets = {}*/
    RefDS(_21997);
    DeRefi(_47inlined_targets_51860);
    _47inlined_targets_51860 = _21997;

    /** emit.e:701	end procedure*/
    return;
    ;
}


void _47emit_inline(object _code_51869)
{
    object _0, _1, _2;
    

    /** emit.e:704		last_pc = 0*/
    _47last_pc_51834 = 0;

    /** emit.e:705		last_op = 0*/
    _47last_op_51833 = 0;

    /** emit.e:706		Code &= code*/
    Concat((object_ptr)&_36Code_21539, _36Code_21539, _code_51869);

    /** emit.e:707	end procedure*/
    DeRefDS(_code_51869);
    return;
    ;
}


void _47emit_op(object _op_51874)
{
    object _a_51876 = NOVALUE;
    object _b_51877 = NOVALUE;
    object _c_51878 = NOVALUE;
    object _d_51879 = NOVALUE;
    object _source_51880 = NOVALUE;
    object _target_51881 = NOVALUE;
    object _subsym_51882 = NOVALUE;
    object _lhs_var_51884 = NOVALUE;
    object _ib_51885 = NOVALUE;
    object _ic_51886 = NOVALUE;
    object _n_51887 = NOVALUE;
    object _obj_51888 = NOVALUE;
    object _elements_51889 = NOVALUE;
    object _element_vals_51890 = NOVALUE;
    object _last_pc_backup_51891 = NOVALUE;
    object _last_op_backup_51892 = NOVALUE;
    object _temp_51901 = NOVALUE;
    object _real_op_52201 = NOVALUE;
    object _ref_52208 = NOVALUE;
    object _paths_52238 = NOVALUE;
    object _if_code_52318 = NOVALUE;
    object _if_code_52357 = NOVALUE;
    object _Top_inlined_Top_at_5482_52976 = NOVALUE;
    object _element_53047 = NOVALUE;
    object _Top_inlined_Top_at_7037_53194 = NOVALUE;
    object _31702 = NOVALUE;
    object _31701 = NOVALUE;
    object _27074 = NOVALUE;
    object _27073 = NOVALUE;
    object _27072 = NOVALUE;
    object _27068 = NOVALUE;
    object _27065 = NOVALUE;
    object _27063 = NOVALUE;
    object _27057 = NOVALUE;
    object _27056 = NOVALUE;
    object _27055 = NOVALUE;
    object _27053 = NOVALUE;
    object _27051 = NOVALUE;
    object _27050 = NOVALUE;
    object _27049 = NOVALUE;
    object _27048 = NOVALUE;
    object _27047 = NOVALUE;
    object _27046 = NOVALUE;
    object _27045 = NOVALUE;
    object _27044 = NOVALUE;
    object _27043 = NOVALUE;
    object _27042 = NOVALUE;
    object _27041 = NOVALUE;
    object _27039 = NOVALUE;
    object _27038 = NOVALUE;
    object _27037 = NOVALUE;
    object _27035 = NOVALUE;
    object _27034 = NOVALUE;
    object _27033 = NOVALUE;
    object _27032 = NOVALUE;
    object _27031 = NOVALUE;
    object _27030 = NOVALUE;
    object _27029 = NOVALUE;
    object _27028 = NOVALUE;
    object _27027 = NOVALUE;
    object _27024 = NOVALUE;
    object _27021 = NOVALUE;
    object _27020 = NOVALUE;
    object _27019 = NOVALUE;
    object _27018 = NOVALUE;
    object _27016 = NOVALUE;
    object _27014 = NOVALUE;
    object _27002 = NOVALUE;
    object _26994 = NOVALUE;
    object _26991 = NOVALUE;
    object _26990 = NOVALUE;
    object _26989 = NOVALUE;
    object _26988 = NOVALUE;
    object _26985 = NOVALUE;
    object _26984 = NOVALUE;
    object _26983 = NOVALUE;
    object _26982 = NOVALUE;
    object _26981 = NOVALUE;
    object _26980 = NOVALUE;
    object _26979 = NOVALUE;
    object _26978 = NOVALUE;
    object _26977 = NOVALUE;
    object _26976 = NOVALUE;
    object _26975 = NOVALUE;
    object _26973 = NOVALUE;
    object _26969 = NOVALUE;
    object _26968 = NOVALUE;
    object _26967 = NOVALUE;
    object _26966 = NOVALUE;
    object _26965 = NOVALUE;
    object _26964 = NOVALUE;
    object _26963 = NOVALUE;
    object _26962 = NOVALUE;
    object _26961 = NOVALUE;
    object _26960 = NOVALUE;
    object _26959 = NOVALUE;
    object _26957 = NOVALUE;
    object _26952 = NOVALUE;
    object _26951 = NOVALUE;
    object _26949 = NOVALUE;
    object _26948 = NOVALUE;
    object _26947 = NOVALUE;
    object _26945 = NOVALUE;
    object _26942 = NOVALUE;
    object _26938 = NOVALUE;
    object _26935 = NOVALUE;
    object _26934 = NOVALUE;
    object _26933 = NOVALUE;
    object _26932 = NOVALUE;
    object _26931 = NOVALUE;
    object _26930 = NOVALUE;
    object _26928 = NOVALUE;
    object _26927 = NOVALUE;
    object _26925 = NOVALUE;
    object _26924 = NOVALUE;
    object _26923 = NOVALUE;
    object _26922 = NOVALUE;
    object _26921 = NOVALUE;
    object _26920 = NOVALUE;
    object _26919 = NOVALUE;
    object _26918 = NOVALUE;
    object _26917 = NOVALUE;
    object _26916 = NOVALUE;
    object _26914 = NOVALUE;
    object _26913 = NOVALUE;
    object _26912 = NOVALUE;
    object _26911 = NOVALUE;
    object _26910 = NOVALUE;
    object _26909 = NOVALUE;
    object _26908 = NOVALUE;
    object _26907 = NOVALUE;
    object _26906 = NOVALUE;
    object _26905 = NOVALUE;
    object _26904 = NOVALUE;
    object _26903 = NOVALUE;
    object _26902 = NOVALUE;
    object _26901 = NOVALUE;
    object _26900 = NOVALUE;
    object _26898 = NOVALUE;
    object _26895 = NOVALUE;
    object _26894 = NOVALUE;
    object _26893 = NOVALUE;
    object _26892 = NOVALUE;
    object _26891 = NOVALUE;
    object _26890 = NOVALUE;
    object _26889 = NOVALUE;
    object _26888 = NOVALUE;
    object _26887 = NOVALUE;
    object _26886 = NOVALUE;
    object _26885 = NOVALUE;
    object _26884 = NOVALUE;
    object _26883 = NOVALUE;
    object _26882 = NOVALUE;
    object _26881 = NOVALUE;
    object _26879 = NOVALUE;
    object _26875 = NOVALUE;
    object _26873 = NOVALUE;
    object _26872 = NOVALUE;
    object _26870 = NOVALUE;
    object _26868 = NOVALUE;
    object _26866 = NOVALUE;
    object _26865 = NOVALUE;
    object _26863 = NOVALUE;
    object _26862 = NOVALUE;
    object _26861 = NOVALUE;
    object _26860 = NOVALUE;
    object _26859 = NOVALUE;
    object _26858 = NOVALUE;
    object _26857 = NOVALUE;
    object _26856 = NOVALUE;
    object _26855 = NOVALUE;
    object _26854 = NOVALUE;
    object _26853 = NOVALUE;
    object _26852 = NOVALUE;
    object _26851 = NOVALUE;
    object _26850 = NOVALUE;
    object _26849 = NOVALUE;
    object _26848 = NOVALUE;
    object _26847 = NOVALUE;
    object _26846 = NOVALUE;
    object _26845 = NOVALUE;
    object _26843 = NOVALUE;
    object _26841 = NOVALUE;
    object _26840 = NOVALUE;
    object _26838 = NOVALUE;
    object _26835 = NOVALUE;
    object _26834 = NOVALUE;
    object _26832 = NOVALUE;
    object _26831 = NOVALUE;
    object _26830 = NOVALUE;
    object _26828 = NOVALUE;
    object _26820 = NOVALUE;
    object _26819 = NOVALUE;
    object _26818 = NOVALUE;
    object _26817 = NOVALUE;
    object _26816 = NOVALUE;
    object _26815 = NOVALUE;
    object _26814 = NOVALUE;
    object _26813 = NOVALUE;
    object _26812 = NOVALUE;
    object _26811 = NOVALUE;
    object _26810 = NOVALUE;
    object _26809 = NOVALUE;
    object _26808 = NOVALUE;
    object _26807 = NOVALUE;
    object _26806 = NOVALUE;
    object _26805 = NOVALUE;
    object _26804 = NOVALUE;
    object _26803 = NOVALUE;
    object _26802 = NOVALUE;
    object _26801 = NOVALUE;
    object _26800 = NOVALUE;
    object _26799 = NOVALUE;
    object _26798 = NOVALUE;
    object _26797 = NOVALUE;
    object _26791 = NOVALUE;
    object _26790 = NOVALUE;
    object _26787 = NOVALUE;
    object _26784 = NOVALUE;
    object _26783 = NOVALUE;
    object _26782 = NOVALUE;
    object _26781 = NOVALUE;
    object _26780 = NOVALUE;
    object _26779 = NOVALUE;
    object _26778 = NOVALUE;
    object _26777 = NOVALUE;
    object _26776 = NOVALUE;
    object _26775 = NOVALUE;
    object _26773 = NOVALUE;
    object _26772 = NOVALUE;
    object _26771 = NOVALUE;
    object _26769 = NOVALUE;
    object _26767 = NOVALUE;
    object _26766 = NOVALUE;
    object _26765 = NOVALUE;
    object _26764 = NOVALUE;
    object _26763 = NOVALUE;
    object _26762 = NOVALUE;
    object _26761 = NOVALUE;
    object _26760 = NOVALUE;
    object _26759 = NOVALUE;
    object _26758 = NOVALUE;
    object _26756 = NOVALUE;
    object _26755 = NOVALUE;
    object _26753 = NOVALUE;
    object _26752 = NOVALUE;
    object _26751 = NOVALUE;
    object _26750 = NOVALUE;
    object _26749 = NOVALUE;
    object _26747 = NOVALUE;
    object _26746 = NOVALUE;
    object _26745 = NOVALUE;
    object _26744 = NOVALUE;
    object _26743 = NOVALUE;
    object _26742 = NOVALUE;
    object _26741 = NOVALUE;
    object _26740 = NOVALUE;
    object _26738 = NOVALUE;
    object _26737 = NOVALUE;
    object _26736 = NOVALUE;
    object _26735 = NOVALUE;
    object _26734 = NOVALUE;
    object _26732 = NOVALUE;
    object _26731 = NOVALUE;
    object _26729 = NOVALUE;
    object _26728 = NOVALUE;
    object _26727 = NOVALUE;
    object _26726 = NOVALUE;
    object _26725 = NOVALUE;
    object _26723 = NOVALUE;
    object _26721 = NOVALUE;
    object _26719 = NOVALUE;
    object _26718 = NOVALUE;
    object _26716 = NOVALUE;
    object _26715 = NOVALUE;
    object _26714 = NOVALUE;
    object _26713 = NOVALUE;
    object _26712 = NOVALUE;
    object _26711 = NOVALUE;
    object _26710 = NOVALUE;
    object _26709 = NOVALUE;
    object _26708 = NOVALUE;
    object _26707 = NOVALUE;
    object _26706 = NOVALUE;
    object _26705 = NOVALUE;
    object _26704 = NOVALUE;
    object _26703 = NOVALUE;
    object _26702 = NOVALUE;
    object _26701 = NOVALUE;
    object _26700 = NOVALUE;
    object _26697 = NOVALUE;
    object _26696 = NOVALUE;
    object _26694 = NOVALUE;
    object _26693 = NOVALUE;
    object _26692 = NOVALUE;
    object _26691 = NOVALUE;
    object _26690 = NOVALUE;
    object _26688 = NOVALUE;
    object _26686 = NOVALUE;
    object _26685 = NOVALUE;
    object _26684 = NOVALUE;
    object _26683 = NOVALUE;
    object _26682 = NOVALUE;
    object _26681 = NOVALUE;
    object _26680 = NOVALUE;
    object _26679 = NOVALUE;
    object _26678 = NOVALUE;
    object _26675 = NOVALUE;
    object _26674 = NOVALUE;
    object _26672 = NOVALUE;
    object _26671 = NOVALUE;
    object _26670 = NOVALUE;
    object _26669 = NOVALUE;
    object _26668 = NOVALUE;
    object _26665 = NOVALUE;
    object _26664 = NOVALUE;
    object _26663 = NOVALUE;
    object _26662 = NOVALUE;
    object _26661 = NOVALUE;
    object _26660 = NOVALUE;
    object _26659 = NOVALUE;
    object _26654 = NOVALUE;
    object _26653 = NOVALUE;
    object _26652 = NOVALUE;
    object _26650 = NOVALUE;
    object _26649 = NOVALUE;
    object _26647 = NOVALUE;
    object _26646 = NOVALUE;
    object _26641 = NOVALUE;
    object _26640 = NOVALUE;
    object _26639 = NOVALUE;
    object _26638 = NOVALUE;
    object _26637 = NOVALUE;
    object _26631 = NOVALUE;
    object _26630 = NOVALUE;
    object _26628 = NOVALUE;
    object _26627 = NOVALUE;
    object _26626 = NOVALUE;
    object _26625 = NOVALUE;
    object _26624 = NOVALUE;
    object _26623 = NOVALUE;
    object _26622 = NOVALUE;
    object _26621 = NOVALUE;
    object _26620 = NOVALUE;
    object _26619 = NOVALUE;
    object _26618 = NOVALUE;
    object _26616 = NOVALUE;
    object _26615 = NOVALUE;
    object _26614 = NOVALUE;
    object _26613 = NOVALUE;
    object _26612 = NOVALUE;
    object _26611 = NOVALUE;
    object _26610 = NOVALUE;
    object _26609 = NOVALUE;
    object _26608 = NOVALUE;
    object _26607 = NOVALUE;
    object _26606 = NOVALUE;
    object _26605 = NOVALUE;
    object _26604 = NOVALUE;
    object _26603 = NOVALUE;
    object _26601 = NOVALUE;
    object _26600 = NOVALUE;
    object _26599 = NOVALUE;
    object _26598 = NOVALUE;
    object _26595 = NOVALUE;
    object _26594 = NOVALUE;
    object _26593 = NOVALUE;
    object _26592 = NOVALUE;
    object _26590 = NOVALUE;
    object _26589 = NOVALUE;
    object _26588 = NOVALUE;
    object _26587 = NOVALUE;
    object _26585 = NOVALUE;
    object _26584 = NOVALUE;
    object _26583 = NOVALUE;
    object _26582 = NOVALUE;
    object _26581 = NOVALUE;
    object _26580 = NOVALUE;
    object _26579 = NOVALUE;
    object _26578 = NOVALUE;
    object _26577 = NOVALUE;
    object _26576 = NOVALUE;
    object _26575 = NOVALUE;
    object _26574 = NOVALUE;
    object _26573 = NOVALUE;
    object _26572 = NOVALUE;
    object _26570 = NOVALUE;
    object _26569 = NOVALUE;
    object _26568 = NOVALUE;
    object _26567 = NOVALUE;
    object _26566 = NOVALUE;
    object _26564 = NOVALUE;
    object _26563 = NOVALUE;
    object _26562 = NOVALUE;
    object _26561 = NOVALUE;
    object _26560 = NOVALUE;
    object _26556 = NOVALUE;
    object _26555 = NOVALUE;
    object _26554 = NOVALUE;
    object _26553 = NOVALUE;
    object _26552 = NOVALUE;
    object _26550 = NOVALUE;
    object _26549 = NOVALUE;
    object _26548 = NOVALUE;
    object _26547 = NOVALUE;
    object _26546 = NOVALUE;
    object _26545 = NOVALUE;
    object _26544 = NOVALUE;
    object _26543 = NOVALUE;
    object _26542 = NOVALUE;
    object _26541 = NOVALUE;
    object _26540 = NOVALUE;
    object _26539 = NOVALUE;
    object _26538 = NOVALUE;
    object _26537 = NOVALUE;
    object _26536 = NOVALUE;
    object _26535 = NOVALUE;
    object _26534 = NOVALUE;
    object _26533 = NOVALUE;
    object _26531 = NOVALUE;
    object _26530 = NOVALUE;
    object _26529 = NOVALUE;
    object _26528 = NOVALUE;
    object _26527 = NOVALUE;
    object _26526 = NOVALUE;
    object _26525 = NOVALUE;
    object _26524 = NOVALUE;
    object _26523 = NOVALUE;
    object _26521 = NOVALUE;
    object _26520 = NOVALUE;
    object _26519 = NOVALUE;
    object _26517 = NOVALUE;
    object _26516 = NOVALUE;
    object _26514 = NOVALUE;
    object _26512 = NOVALUE;
    object _26511 = NOVALUE;
    object _26510 = NOVALUE;
    object _26509 = NOVALUE;
    object _26508 = NOVALUE;
    object _26507 = NOVALUE;
    object _26503 = NOVALUE;
    object _26502 = NOVALUE;
    object _26501 = NOVALUE;
    object _26499 = NOVALUE;
    object _26498 = NOVALUE;
    object _26497 = NOVALUE;
    object _26496 = NOVALUE;
    object _26495 = NOVALUE;
    object _26494 = NOVALUE;
    object _26493 = NOVALUE;
    object _26492 = NOVALUE;
    object _26491 = NOVALUE;
    object _26490 = NOVALUE;
    object _26489 = NOVALUE;
    object _26488 = NOVALUE;
    object _26487 = NOVALUE;
    object _26486 = NOVALUE;
    object _26485 = NOVALUE;
    object _26480 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_op_51874)) {
        _1 = (object)(DBL_PTR(_op_51874)->dbl);
        DeRefDS(_op_51874);
        _op_51874 = _1;
    }

    /** emit.e:717		integer ib, ic, n*/

    /** emit.e:718		object obj*/

    /** emit.e:719		sequence elements*/

    /** emit.e:720		object element_vals*/

    /** emit.e:722		check_for_temps()*/
    _47check_for_temps();

    /** emit.e:723		integer last_pc_backup = last_pc*/
    _last_pc_backup_51891 = _47last_pc_51834;

    /** emit.e:724		integer last_op_backup = last_op*/
    _last_op_backup_51892 = _47last_op_51833;

    /** emit.e:726		last_op = op*/
    _47last_op_51833 = _op_51874;

    /** emit.e:727		last_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_36Code_21539)){
            _26480 = SEQ_PTR(_36Code_21539)->length;
    }
    else {
        _26480 = 1;
    }
    _47last_pc_51834 = _26480 + 1;
    _26480 = NOVALUE;

    /** emit.e:729		switch op label "EMIT" do*/
    _0 = _op_51874;
    switch ( _0 ){ 

        /** emit.e:730		case ASSIGN then*/
        case 18:

        /** emit.e:731			sequence temp = {}*/
        RefDS(_21997);
        DeRef(_temp_51901);
        _temp_51901 = _21997;

        /** emit.e:732			if not TRANSLATE and*/
        _26485 = (_36TRANSLATE_21049 == 0);
        if (_26485 == 0) {
            goto L1; // [70] 202
        }
        _26487 = (_36previous_op_21549 == 92);
        if (_26487 != 0) {
            DeRef(_26488);
            _26488 = 1;
            goto L2; // [82] 98
        }
        _26489 = (_36previous_op_21549 == 25);
        _26488 = (_26489 != 0);
L2: 
        if (_26488 == 0)
        {
            _26488 = NOVALUE;
            goto L1; // [99] 202
        }
        else{
            _26488 = NOVALUE;
        }

        /** emit.e:736				while Code[$-1] = DEREF_TEMP and find( Code[$], derefs ) do*/
L3: 
        if (IS_SEQUENCE(_36Code_21539)){
                _26490 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26490 = 1;
        }
        _26491 = _26490 - 1;
        _26490 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21539);
        _26492 = (object)*(((s1_ptr)_2)->base + _26491);
        if (IS_ATOM_INT(_26492)) {
            _26493 = (_26492 == 208);
        }
        else {
            _26493 = binary_op(EQUALS, _26492, 208);
        }
        _26492 = NOVALUE;
        if (IS_ATOM_INT(_26493)) {
            if (_26493 == 0) {
                goto L4; // [126] 201
            }
        }
        else {
            if (DBL_PTR(_26493)->dbl == 0.0) {
                goto L4; // [126] 201
            }
        }
        if (IS_SEQUENCE(_36Code_21539)){
                _26495 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26495 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21539);
        _26496 = (object)*(((s1_ptr)_2)->base + _26495);
        _26497 = find_from(_26496, _47derefs_51455, 1);
        _26496 = NOVALUE;
        if (_26497 == 0)
        {
            _26497 = NOVALUE;
            goto L4; // [147] 201
        }
        else{
            _26497 = NOVALUE;
        }

        /** emit.e:739					temp &= Code[$]*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26498 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26498 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21539);
        _26499 = (object)*(((s1_ptr)_2)->base + _26498);
        if (IS_SEQUENCE(_temp_51901) && IS_ATOM(_26499)) {
            Ref(_26499);
            Append(&_temp_51901, _temp_51901, _26499);
        }
        else if (IS_ATOM(_temp_51901) && IS_SEQUENCE(_26499)) {
        }
        else {
            Concat((object_ptr)&_temp_51901, _temp_51901, _26499);
        }
        _26499 = NOVALUE;

        /** emit.e:740					Code = remove( Code, length(Code)-1, length(Code) )*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26501 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26501 = 1;
        }
        _26502 = _26501 - 1;
        _26501 = NOVALUE;
        if (IS_SEQUENCE(_36Code_21539)){
                _26503 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26503 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_36Code_21539);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26502)) ? _26502 : (object)(DBL_PTR(_26502)->dbl);
            int stop = (IS_ATOM_INT(_26503)) ? _26503 : (object)(DBL_PTR(_26503)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_36Code_21539), start, &_36Code_21539 );
                }
                else Tail(SEQ_PTR(_36Code_21539), stop+1, &_36Code_21539);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_36Code_21539), start, &_36Code_21539);
            }
            else {
                assign_slice_seq = &assign_space;
                _36Code_21539 = Remove_elements(start, stop, (SEQ_PTR(_36Code_21539)->ref == 1));
            }
        }
        _26502 = NOVALUE;
        _26503 = NOVALUE;

        /** emit.e:741					emit_temp( temp, NEW_REFERENCE )*/
        RefDS(_temp_51901);
        _47emit_temp(_temp_51901, 1);

        /** emit.e:742				end while*/
        goto L3; // [198] 107
L4: 
L1: 

        /** emit.e:746			source = Pop()*/
        _source_51880 = _47Pop();
        if (!IS_ATOM_INT(_source_51880)) {
            _1 = (object)(DBL_PTR(_source_51880)->dbl);
            DeRefDS(_source_51880);
            _source_51880 = _1;
        }

        /** emit.e:747			target = Pop()*/
        _target_51881 = _47Pop();
        if (!IS_ATOM_INT(_target_51881)) {
            _1 = (object)(DBL_PTR(_target_51881)->dbl);
            DeRefDS(_target_51881);
            _target_51881 = _1;
        }

        /** emit.e:748			if assignable then*/
        if (_47assignable_50954 == 0)
        {
            goto L5; // [220] 601
        }
        else{
        }

        /** emit.e:750				if inlined then*/
        if (_47inlined_51852 == 0)
        {
            goto L6; // [227] 326
        }
        else{
        }

        /** emit.e:751					inlined = 0*/
        _47inlined_51852 = 0;

        /** emit.e:752					if length( inlined_targets ) then*/
        if (IS_SEQUENCE(_47inlined_targets_51860)){
                _26507 = SEQ_PTR(_47inlined_targets_51860)->length;
        }
        else {
            _26507 = 1;
        }
        if (_26507 == 0)
        {
            _26507 = NOVALUE;
            goto L7; // [242] 295
        }
        else{
            _26507 = NOVALUE;
        }

        /** emit.e:753						for i = 1 to length( inlined_targets ) do*/
        if (IS_SEQUENCE(_47inlined_targets_51860)){
                _26508 = SEQ_PTR(_47inlined_targets_51860)->length;
        }
        else {
            _26508 = 1;
        }
        {
            object _i_51944;
            _i_51944 = 1;
L8: 
            if (_i_51944 > _26508){
                goto L9; // [252] 280
            }

            /** emit.e:754							Code[inlined_targets[i]] = target*/
            _2 = (object)SEQ_PTR(_47inlined_targets_51860);
            _26509 = (object)*(((s1_ptr)_2)->base + _i_51944);
            _2 = (object)SEQ_PTR(_36Code_21539);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _36Code_21539 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _26509);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _target_51881;
            DeRef(_1);

            /** emit.e:755						end for*/
            _i_51944 = _i_51944 + 1;
            goto L8; // [275] 259
L9: 
            ;
        }

        /** emit.e:756						clear_inline_targets()*/

        /** emit.e:700		inlined_targets = {}*/
        RefDS(_21997);
        DeRefi(_47inlined_targets_51860);
        _47inlined_targets_51860 = _21997;

        /** emit.e:701	end procedure*/
        goto LA; // [291] 294
LA: 
L7: 

        /** emit.e:759					assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;

        /** emit.e:760					clear_last()*/

        /** emit.e:678		last_op = 0*/
        _47last_op_51833 = 0;

        /** emit.e:679		last_pc = 0*/
        _47last_pc_51834 = 0;

        /** emit.e:680	end procedure*/
        goto LB; // [316] 319
LB: 

        /** emit.e:761					break "EMIT"*/
        DeRef(_temp_51901);
        _temp_51901 = NOVALUE;
        goto LC; // [323] 7739
L6: 

        /** emit.e:764				clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26510 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26510 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21539);
        _26511 = (object)*(((s1_ptr)_2)->base + _26510);
        Ref(_26511);
        _47clear_temp(_26511);
        _26511 = NOVALUE;

        /** emit.e:765				Code = remove( Code, length( Code ) ) -- drop previous target*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26512 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26512 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_36Code_21539);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26512)) ? _26512 : (object)(DBL_PTR(_26512)->dbl);
            int stop = (IS_ATOM_INT(_26512)) ? _26512 : (object)(DBL_PTR(_26512)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_36Code_21539), start, &_36Code_21539 );
                }
                else Tail(SEQ_PTR(_36Code_21539), stop+1, &_36Code_21539);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_36Code_21539), start, &_36Code_21539);
            }
            else {
                assign_slice_seq = &assign_space;
                _36Code_21539 = Remove_elements(start, stop, (SEQ_PTR(_36Code_21539)->ref == 1));
            }
        }
        _26512 = NOVALUE;
        _26512 = NOVALUE;

        /** emit.e:766				op = previous_op -- keep same previous op*/
        _op_51874 = _36previous_op_21549;

        /** emit.e:767				if IsInteger(target) then*/
        _26514 = _47IsInteger(_target_51881);
        if (_26514 == 0) {
            DeRef(_26514);
            _26514 = NOVALUE;
            goto LD; // [372] 588
        }
        else {
            if (!IS_ATOM_INT(_26514) && DBL_PTR(_26514)->dbl == 0.0){
                DeRef(_26514);
                _26514 = NOVALUE;
                goto LD; // [372] 588
            }
            DeRef(_26514);
            _26514 = NOVALUE;
        }
        DeRef(_26514);
        _26514 = NOVALUE;

        /** emit.e:768					if previous_op = RHS_SUBS then*/
        if (_36previous_op_21549 != 25)
        goto LE; // [381] 412

        /** emit.e:769						op = RHS_SUBS_I*/
        _op_51874 = 114;

        /** emit.e:770						backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26516 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26516 = 1;
        }
        _26517 = _26516 - 2;
        _26516 = NOVALUE;
        _47backpatch(_26517, 114);
        _26517 = NOVALUE;
        goto LF; // [409] 587
LE: 

        /** emit.e:772					elsif previous_op = PLUS1 then*/
        if (_36previous_op_21549 != 93)
        goto L10; // [418] 449

        /** emit.e:773						op = PLUS1_I*/
        _op_51874 = 117;

        /** emit.e:774						backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26519 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26519 = 1;
        }
        _26520 = _26519 - 2;
        _26519 = NOVALUE;
        _47backpatch(_26520, 117);
        _26520 = NOVALUE;
        goto LF; // [446] 587
L10: 

        /** emit.e:776					elsif previous_op = PLUS or previous_op = MINUS then*/
        _26521 = (_36previous_op_21549 == 11);
        if (_26521 != 0) {
            goto L11; // [459] 476
        }
        _26523 = (_36previous_op_21549 == 10);
        if (_26523 == 0)
        {
            DeRef(_26523);
            _26523 = NOVALUE;
            goto L12; // [472] 567
        }
        else{
            DeRef(_26523);
            _26523 = NOVALUE;
        }
L11: 

        /** emit.e:777						if IsInteger(Code[$]) and*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26524 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26524 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21539);
        _26525 = (object)*(((s1_ptr)_2)->base + _26524);
        Ref(_26525);
        _26526 = _47IsInteger(_26525);
        _26525 = NOVALUE;
        if (IS_ATOM_INT(_26526)) {
            if (_26526 == 0) {
                goto LF; // [491] 587
            }
        }
        else {
            if (DBL_PTR(_26526)->dbl == 0.0) {
                goto LF; // [491] 587
            }
        }
        if (IS_SEQUENCE(_36Code_21539)){
                _26528 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26528 = 1;
        }
        _26529 = _26528 - 1;
        _26528 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21539);
        _26530 = (object)*(((s1_ptr)_2)->base + _26529);
        Ref(_26530);
        _26531 = _47IsInteger(_26530);
        _26530 = NOVALUE;
        if (_26531 == 0) {
            DeRef(_26531);
            _26531 = NOVALUE;
            goto LF; // [513] 587
        }
        else {
            if (!IS_ATOM_INT(_26531) && DBL_PTR(_26531)->dbl == 0.0){
                DeRef(_26531);
                _26531 = NOVALUE;
                goto LF; // [513] 587
            }
            DeRef(_26531);
            _26531 = NOVALUE;
        }
        DeRef(_26531);
        _26531 = NOVALUE;

        /** emit.e:779							if previous_op = PLUS then*/
        if (_36previous_op_21549 != 11)
        goto L13; // [522] 538

        /** emit.e:780								op = PLUS_I*/
        _op_51874 = 115;
        goto L14; // [535] 548
L13: 

        /** emit.e:782								op = MINUS_I*/
        _op_51874 = 116;
L14: 

        /** emit.e:784							backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26533 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26533 = 1;
        }
        _26534 = _26533 - 2;
        _26533 = NOVALUE;
        _47backpatch(_26534, _op_51874);
        _26534 = NOVALUE;
        goto LF; // [564] 587
L12: 

        /** emit.e:790						if IsInteger(source) then*/
        _26535 = _47IsInteger(_source_51880);
        if (_26535 == 0) {
            DeRef(_26535);
            _26535 = NOVALUE;
            goto L15; // [573] 586
        }
        else {
            if (!IS_ATOM_INT(_26535) && DBL_PTR(_26535)->dbl == 0.0){
                DeRef(_26535);
                _26535 = NOVALUE;
                goto L15; // [573] 586
            }
            DeRef(_26535);
            _26535 = NOVALUE;
        }
        DeRef(_26535);
        _26535 = NOVALUE;

        /** emit.e:791							op = ASSIGN_I -- fake to avoid subsequent check*/
        _op_51874 = 113;
L15: 
LF: 
LD: 

        /** emit.e:795				last_op = last_op_backup*/
        _47last_op_51833 = _last_op_backup_51892;

        /** emit.e:796				last_pc = last_pc_backup*/
        _47last_pc_51834 = _last_pc_backup_51891;
        goto L16; // [598] 743
L5: 

        /** emit.e:798				if IsInteger(source) and IsInteger(target) then*/
        _26536 = _47IsInteger(_source_51880);
        if (IS_ATOM_INT(_26536)) {
            if (_26536 == 0) {
                goto L17; // [607] 629
            }
        }
        else {
            if (DBL_PTR(_26536)->dbl == 0.0) {
                goto L17; // [607] 629
            }
        }
        _26538 = _47IsInteger(_target_51881);
        if (_26538 == 0) {
            DeRef(_26538);
            _26538 = NOVALUE;
            goto L17; // [616] 629
        }
        else {
            if (!IS_ATOM_INT(_26538) && DBL_PTR(_26538)->dbl == 0.0){
                DeRef(_26538);
                _26538 = NOVALUE;
                goto L17; // [616] 629
            }
            DeRef(_26538);
            _26538 = NOVALUE;
        }
        DeRef(_26538);
        _26538 = NOVALUE;

        /** emit.e:799					op = ASSIGN_I*/
        _op_51874 = 113;
L17: 

        /** emit.e:801				if source > 0 and target > 0 and*/
        _26539 = (_source_51880 > 0);
        if (_26539 == 0) {
            _26540 = 0;
            goto L18; // [635] 647
        }
        _26541 = (_target_51881 > 0);
        _26540 = (_26541 != 0);
L18: 
        if (_26540 == 0) {
            _26542 = 0;
            goto L19; // [647] 673
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26543 = (object)*(((s1_ptr)_2)->base + _source_51880);
        _2 = (object)SEQ_PTR(_26543);
        _26544 = (object)*(((s1_ptr)_2)->base + 3);
        _26543 = NOVALUE;
        if (IS_ATOM_INT(_26544)) {
            _26545 = (_26544 == 2);
        }
        else {
            _26545 = binary_op(EQUALS, _26544, 2);
        }
        _26544 = NOVALUE;
        if (IS_ATOM_INT(_26545))
        _26542 = (_26545 != 0);
        else
        _26542 = DBL_PTR(_26545)->dbl != 0.0;
L19: 
        if (_26542 == 0) {
            goto L1A; // [673] 727
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26547 = (object)*(((s1_ptr)_2)->base + _target_51881);
        _2 = (object)SEQ_PTR(_26547);
        _26548 = (object)*(((s1_ptr)_2)->base + 3);
        _26547 = NOVALUE;
        if (IS_ATOM_INT(_26548)) {
            _26549 = (_26548 == 2);
        }
        else {
            _26549 = binary_op(EQUALS, _26548, 2);
        }
        _26548 = NOVALUE;
        if (_26549 == 0) {
            DeRef(_26549);
            _26549 = NOVALUE;
            goto L1A; // [696] 727
        }
        else {
            if (!IS_ATOM_INT(_26549) && DBL_PTR(_26549)->dbl == 0.0){
                DeRef(_26549);
                _26549 = NOVALUE;
                goto L1A; // [696] 727
            }
            DeRef(_26549);
            _26549 = NOVALUE;
        }
        DeRef(_26549);
        _26549 = NOVALUE;

        /** emit.e:806					SymTab[target][S_OBJ] = SymTab[source][S_OBJ]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_target_51881 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26552 = (object)*(((s1_ptr)_2)->base + _source_51880);
        _2 = (object)SEQ_PTR(_26552);
        _26553 = (object)*(((s1_ptr)_2)->base + 1);
        _26552 = NOVALUE;
        Ref(_26553);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26553;
        if( _1 != _26553 ){
            DeRef(_1);
        }
        _26553 = NOVALUE;
        _26550 = NOVALUE;
L1A: 

        /** emit.e:809				emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:810				emit_addr(source)*/
        _47emit_addr(_source_51880);

        /** emit.e:811				last_op = op*/
        _47last_op_51833 = _op_51874;
L16: 

        /** emit.e:814			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;

        /** emit.e:815			emit_addr(target)*/
        _47emit_addr(_target_51881);

        /** emit.e:817			if length(temp) then*/
        if (IS_SEQUENCE(_temp_51901)){
                _26554 = SEQ_PTR(_temp_51901)->length;
        }
        else {
            _26554 = 1;
        }
        if (_26554 == 0)
        {
            _26554 = NOVALUE;
            goto L1B; // [760] 792
        }
        else{
            _26554 = NOVALUE;
        }

        /** emit.e:819				for i = 1 to length( temp ) do*/
        if (IS_SEQUENCE(_temp_51901)){
                _26555 = SEQ_PTR(_temp_51901)->length;
        }
        else {
            _26555 = 1;
        }
        {
            object _i_52047;
            _i_52047 = 1;
L1C: 
            if (_i_52047 > _26555){
                goto L1D; // [768] 791
            }

            /** emit.e:820					flush_temp( temp[i] )*/
            _2 = (object)SEQ_PTR(_temp_51901);
            _26556 = (object)*(((s1_ptr)_2)->base + _i_52047);
            Ref(_26556);
            _47flush_temp(_26556);
            _26556 = NOVALUE;

            /** emit.e:821				end for*/
            _i_52047 = _i_52047 + 1;
            goto L1C; // [786] 775
L1D: 
            ;
        }
L1B: 
        DeRef(_temp_51901);
        _temp_51901 = NOVALUE;
        goto LC; // [794] 7739

        /** emit.e:824		case RHS_SUBS then*/
        case 25:

        /** emit.e:825			b = Pop() -- subscript*/
        _b_51877 = _47Pop();
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:826			c = Pop() -- sequence*/
        _c_51878 = _47Pop();
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:827			target = NewTempSym() -- target*/
        _target_51881 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_target_51881)) {
            _1 = (object)(DBL_PTR(_target_51881)->dbl);
            DeRefDS(_target_51881);
            _target_51881 = _1;
        }

        /** emit.e:828			if c < 0 or length(SymTab[c]) < S_VTYPE or SymTab[c][S_VTYPE] < 0 then -- forward reference*/
        _26560 = (_c_51878 < 0);
        if (_26560 != 0) {
            _26561 = 1;
            goto L1E; // [828] 851
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26562 = (object)*(((s1_ptr)_2)->base + _c_51878);
        if (IS_SEQUENCE(_26562)){
                _26563 = SEQ_PTR(_26562)->length;
        }
        else {
            _26563 = 1;
        }
        _26562 = NOVALUE;
        _26564 = (_26563 < 15);
        _26563 = NOVALUE;
        _26561 = (_26564 != 0);
L1E: 
        if (_26561 != 0) {
            goto L1F; // [851] 876
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26566 = (object)*(((s1_ptr)_2)->base + _c_51878);
        _2 = (object)SEQ_PTR(_26566);
        _26567 = (object)*(((s1_ptr)_2)->base + 15);
        _26566 = NOVALUE;
        if (IS_ATOM_INT(_26567)) {
            _26568 = (_26567 < 0);
        }
        else {
            _26568 = binary_op(LESS, _26567, 0);
        }
        _26567 = NOVALUE;
        if (_26568 == 0) {
            DeRef(_26568);
            _26568 = NOVALUE;
            goto L20; // [872] 888
        }
        else {
            if (!IS_ATOM_INT(_26568) && DBL_PTR(_26568)->dbl == 0.0){
                DeRef(_26568);
                _26568 = NOVALUE;
                goto L20; // [872] 888
            }
            DeRef(_26568);
            _26568 = NOVALUE;
        }
        DeRef(_26568);
        _26568 = NOVALUE;
L1F: 

        /** emit.e:830				op = RHS_SUBS_CHECK*/
        _op_51874 = 92;
        goto L21; // [885] 1049
L20: 

        /** emit.e:831			elsif SymTab[c][S_MODE] = M_NORMAL then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26569 = (object)*(((s1_ptr)_2)->base + _c_51878);
        _2 = (object)SEQ_PTR(_26569);
        _26570 = (object)*(((s1_ptr)_2)->base + 3);
        _26569 = NOVALUE;
        if (binary_op_a(NOTEQ, _26570, 1)){
            _26570 = NOVALUE;
            goto L22; // [904] 991
        }
        _26570 = NOVALUE;

        /** emit.e:832				if SymTab[c][S_VTYPE] != sequence_type and*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26572 = (object)*(((s1_ptr)_2)->base + _c_51878);
        _2 = (object)SEQ_PTR(_26572);
        _26573 = (object)*(((s1_ptr)_2)->base + 15);
        _26572 = NOVALUE;
        if (IS_ATOM_INT(_26573)) {
            _26574 = (_26573 != _54sequence_type_46784);
        }
        else {
            _26574 = binary_op(NOTEQ, _26573, _54sequence_type_46784);
        }
        _26573 = NOVALUE;
        if (IS_ATOM_INT(_26574)) {
            if (_26574 == 0) {
                goto L21; // [928] 1049
            }
        }
        else {
            if (DBL_PTR(_26574)->dbl == 0.0) {
                goto L21; // [928] 1049
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26576 = (object)*(((s1_ptr)_2)->base + _c_51878);
        _2 = (object)SEQ_PTR(_26576);
        _26577 = (object)*(((s1_ptr)_2)->base + 15);
        _26576 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_26577)){
            _26578 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26577)->dbl));
        }
        else{
            _26578 = (object)*(((s1_ptr)_2)->base + _26577);
        }
        _2 = (object)SEQ_PTR(_26578);
        _26579 = (object)*(((s1_ptr)_2)->base + 2);
        _26578 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_26579)){
            _26580 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26579)->dbl));
        }
        else{
            _26580 = (object)*(((s1_ptr)_2)->base + _26579);
        }
        _2 = (object)SEQ_PTR(_26580);
        _26581 = (object)*(((s1_ptr)_2)->base + 15);
        _26580 = NOVALUE;
        if (IS_ATOM_INT(_26581)) {
            _26582 = (_26581 != _54sequence_type_46784);
        }
        else {
            _26582 = binary_op(NOTEQ, _26581, _54sequence_type_46784);
        }
        _26581 = NOVALUE;
        if (_26582 == 0) {
            DeRef(_26582);
            _26582 = NOVALUE;
            goto L21; // [975] 1049
        }
        else {
            if (!IS_ATOM_INT(_26582) && DBL_PTR(_26582)->dbl == 0.0){
                DeRef(_26582);
                _26582 = NOVALUE;
                goto L21; // [975] 1049
            }
            DeRef(_26582);
            _26582 = NOVALUE;
        }
        DeRef(_26582);
        _26582 = NOVALUE;

        /** emit.e:835					op = RHS_SUBS_CHECK*/
        _op_51874 = 92;
        goto L21; // [988] 1049
L22: 

        /** emit.e:837			elsif SymTab[c][S_MODE] != M_CONSTANT or*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26583 = (object)*(((s1_ptr)_2)->base + _c_51878);
        _2 = (object)SEQ_PTR(_26583);
        _26584 = (object)*(((s1_ptr)_2)->base + 3);
        _26583 = NOVALUE;
        if (IS_ATOM_INT(_26584)) {
            _26585 = (_26584 != 2);
        }
        else {
            _26585 = binary_op(NOTEQ, _26584, 2);
        }
        _26584 = NOVALUE;
        if (IS_ATOM_INT(_26585)) {
            if (_26585 != 0) {
                goto L23; // [1011] 1038
            }
        }
        else {
            if (DBL_PTR(_26585)->dbl != 0.0) {
                goto L23; // [1011] 1038
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26587 = (object)*(((s1_ptr)_2)->base + _c_51878);
        _2 = (object)SEQ_PTR(_26587);
        _26588 = (object)*(((s1_ptr)_2)->base + 1);
        _26587 = NOVALUE;
        _26589 = IS_SEQUENCE(_26588);
        _26588 = NOVALUE;
        _26590 = (_26589 == 0);
        _26589 = NOVALUE;
        if (_26590 == 0)
        {
            DeRef(_26590);
            _26590 = NOVALUE;
            goto L24; // [1034] 1048
        }
        else{
            DeRef(_26590);
            _26590 = NOVALUE;
        }
L23: 

        /** emit.e:839				op = RHS_SUBS_CHECK*/
        _op_51874 = 92;
L24: 
L21: 

        /** emit.e:841			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:842			emit_addr(c)*/
        _47emit_addr(_c_51878);

        /** emit.e:843			emit_addr(b)*/
        _47emit_addr(_b_51877);

        /** emit.e:844			assignable = TRUE*/
        _47assignable_50954 = _13TRUE_452;

        /** emit.e:845			Push(target)*/
        _47Push(_target_51881);

        /** emit.e:846			emit_addr(target)*/
        _47emit_addr(_target_51881);

        /** emit.e:847			emit_temp(target, NEW_REFERENCE)*/
        _47emit_temp(_target_51881, 1);

        /** emit.e:848			current_sequence = append(current_sequence, target)*/
        Append(&_47current_sequence_50944, _47current_sequence_50944, _target_51881);

        /** emit.e:849			flush_temp( Code[$-2] )*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26592 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26592 = 1;
        }
        _26593 = _26592 - 2;
        _26592 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21539);
        _26594 = (object)*(((s1_ptr)_2)->base + _26593);
        Ref(_26594);
        _47flush_temp(_26594);
        _26594 = NOVALUE;
        goto LC; // [1113] 7739

        /** emit.e:851		case PROC then -- procedure, function and type calls*/
        case 27:

        /** emit.e:853			assignable = FALSE -- assume for now*/
        _47assignable_50954 = _13FALSE_450;

        /** emit.e:854			subsym = op_info1*/
        _subsym_51882 = _47op_info1_50936;

        /** emit.e:855			n = SymTab[subsym][S_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26595 = (object)*(((s1_ptr)_2)->base + _subsym_51882);
        _2 = (object)SEQ_PTR(_26595);
        if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
            _n_51887 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
        }
        else{
            _n_51887 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
        }
        if (!IS_ATOM_INT(_n_51887)){
            _n_51887 = (object)DBL_PTR(_n_51887)->dbl;
        }
        _26595 = NOVALUE;

        /** emit.e:857			if subsym = CurrentSub then*/
        if (_subsym_51882 != _36CurrentSub_21455)
        goto L25; // [1155] 1340

        /** emit.e:860				for i = cgi-n+1 to cgi do*/
        _26598 = _47cgi_50952 - _n_51887;
        if ((object)((uintptr_t)_26598 +(uintptr_t) HIGH_BITS) >= 0){
            _26598 = NewDouble((eudouble)_26598);
        }
        if (IS_ATOM_INT(_26598)) {
            _26599 = _26598 + 1;
            if (_26599 > MAXINT){
                _26599 = NewDouble((eudouble)_26599);
            }
        }
        else
        _26599 = binary_op(PLUS, 1, _26598);
        DeRef(_26598);
        _26598 = NOVALUE;
        _26600 = _47cgi_50952;
        {
            object _i_52133;
            Ref(_26599);
            _i_52133 = _26599;
L26: 
            if (binary_op_a(GREATER, _i_52133, _26600)){
                goto L27; // [1176] 1339
            }

            /** emit.e:861					if cg_stack[i] > 0 then -- if it's a forward reference, it's not a private*/
            _2 = (object)SEQ_PTR(_47cg_stack_50951);
            if (!IS_ATOM_INT(_i_52133)){
                _26601 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52133)->dbl));
            }
            else{
                _26601 = (object)*(((s1_ptr)_2)->base + _i_52133);
            }
            if (binary_op_a(LESSEQ, _26601, 0)){
                _26601 = NOVALUE;
                goto L28; // [1191] 1332
            }
            _26601 = NOVALUE;

            /** emit.e:862						if SymTab[cg_stack[i]][S_SCOPE] = SC_PRIVATE and*/
            _2 = (object)SEQ_PTR(_47cg_stack_50951);
            if (!IS_ATOM_INT(_i_52133)){
                _26603 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52133)->dbl));
            }
            else{
                _26603 = (object)*(((s1_ptr)_2)->base + _i_52133);
            }
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!IS_ATOM_INT(_26603)){
                _26604 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26603)->dbl));
            }
            else{
                _26604 = (object)*(((s1_ptr)_2)->base + _26603);
            }
            _2 = (object)SEQ_PTR(_26604);
            _26605 = (object)*(((s1_ptr)_2)->base + 4);
            _26604 = NOVALUE;
            if (IS_ATOM_INT(_26605)) {
                _26606 = (_26605 == 3);
            }
            else {
                _26606 = binary_op(EQUALS, _26605, 3);
            }
            _26605 = NOVALUE;
            if (IS_ATOM_INT(_26606)) {
                if (_26606 == 0) {
                    goto L29; // [1221] 1299
                }
            }
            else {
                if (DBL_PTR(_26606)->dbl == 0.0) {
                    goto L29; // [1221] 1299
                }
            }
            _2 = (object)SEQ_PTR(_47cg_stack_50951);
            if (!IS_ATOM_INT(_i_52133)){
                _26608 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52133)->dbl));
            }
            else{
                _26608 = (object)*(((s1_ptr)_2)->base + _i_52133);
            }
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!IS_ATOM_INT(_26608)){
                _26609 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26608)->dbl));
            }
            else{
                _26609 = (object)*(((s1_ptr)_2)->base + _26608);
            }
            _2 = (object)SEQ_PTR(_26609);
            _26610 = (object)*(((s1_ptr)_2)->base + 16);
            _26609 = NOVALUE;
            if (IS_ATOM_INT(_26610) && IS_ATOM_INT(_i_52133)) {
                _26611 = (_26610 < _i_52133);
            }
            else {
                _26611 = binary_op(LESS, _26610, _i_52133);
            }
            _26610 = NOVALUE;
            if (_26611 == 0) {
                DeRef(_26611);
                _26611 = NOVALUE;
                goto L29; // [1248] 1299
            }
            else {
                if (!IS_ATOM_INT(_26611) && DBL_PTR(_26611)->dbl == 0.0){
                    DeRef(_26611);
                    _26611 = NOVALUE;
                    goto L29; // [1248] 1299
                }
                DeRef(_26611);
                _26611 = NOVALUE;
            }
            DeRef(_26611);
            _26611 = NOVALUE;

            /** emit.e:865							emit_opcode(ASSIGN)*/
            _47emit_opcode(18);

            /** emit.e:866							emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_47cg_stack_50951);
            if (!IS_ATOM_INT(_i_52133)){
                _26612 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52133)->dbl));
            }
            else{
                _26612 = (object)*(((s1_ptr)_2)->base + _i_52133);
            }
            Ref(_26612);
            _47emit_addr(_26612);
            _26612 = NOVALUE;

            /** emit.e:867							cg_stack[i] = NewTempSym()*/
            _26613 = _54NewTempSym(0);
            _2 = (object)SEQ_PTR(_47cg_stack_50951);
            if (!IS_ATOM_INT(_i_52133))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52133)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _i_52133);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _26613;
            if( _1 != _26613 ){
                DeRef(_1);
            }
            _26613 = NOVALUE;

            /** emit.e:868							emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_47cg_stack_50951);
            if (!IS_ATOM_INT(_i_52133)){
                _26614 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52133)->dbl));
            }
            else{
                _26614 = (object)*(((s1_ptr)_2)->base + _i_52133);
            }
            Ref(_26614);
            _47emit_addr(_26614);
            _26614 = NOVALUE;

            /** emit.e:869							check_for_temps()*/
            _47check_for_temps();
            goto L2A; // [1296] 1331
L29: 

            /** emit.e:870						elsif sym_mode( cg_stack[i] ) = M_TEMP then*/
            _2 = (object)SEQ_PTR(_47cg_stack_50951);
            if (!IS_ATOM_INT(_i_52133)){
                _26615 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52133)->dbl));
            }
            else{
                _26615 = (object)*(((s1_ptr)_2)->base + _i_52133);
            }
            Ref(_26615);
            _26616 = _54sym_mode(_26615);
            _26615 = NOVALUE;
            if (binary_op_a(NOTEQ, _26616, 3)){
                DeRef(_26616);
                _26616 = NOVALUE;
                goto L2B; // [1313] 1330
            }
            DeRef(_26616);
            _26616 = NOVALUE;

            /** emit.e:871							emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (object)SEQ_PTR(_47cg_stack_50951);
            if (!IS_ATOM_INT(_i_52133)){
                _26618 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52133)->dbl));
            }
            else{
                _26618 = (object)*(((s1_ptr)_2)->base + _i_52133);
            }
            Ref(_26618);
            _47emit_temp(_26618, 1);
            _26618 = NOVALUE;
L2B: 
L2A: 
L28: 

            /** emit.e:874				end for*/
            _0 = _i_52133;
            if (IS_ATOM_INT(_i_52133)) {
                _i_52133 = _i_52133 + 1;
                if ((object)((uintptr_t)_i_52133 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_52133 = NewDouble((eudouble)_i_52133);
                }
            }
            else {
                _i_52133 = binary_op_a(PLUS, _i_52133, 1);
            }
            DeRef(_0);
            goto L26; // [1334] 1183
L27: 
            ;
            DeRef(_i_52133);
        }
L25: 

        /** emit.e:877			if SymTab[subsym][S_DEPRECATED] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26619 = (object)*(((s1_ptr)_2)->base + _subsym_51882);
        _2 = (object)SEQ_PTR(_26619);
        _26620 = (object)*(((s1_ptr)_2)->base + 30);
        _26619 = NOVALUE;
        if (_26620 == 0) {
            _26620 = NOVALUE;
            goto L2C; // [1354] 1383
        }
        else {
            if (!IS_ATOM_INT(_26620) && DBL_PTR(_26620)->dbl == 0.0){
                _26620 = NOVALUE;
                goto L2C; // [1354] 1383
            }
            _26620 = NOVALUE;
        }
        _26620 = NOVALUE;

        /** emit.e:878				Warning(327, deprecated_warning_flag, { SymTab[subsym][S_NAME] })*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26621 = (object)*(((s1_ptr)_2)->base + _subsym_51882);
        _2 = (object)SEQ_PTR(_26621);
        if (!IS_ATOM_INT(_36S_NAME_21084)){
            _26622 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
        }
        else{
            _26622 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
        }
        _26621 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_26622);
        ((intptr_t*)_2)[1] = _26622;
        _26623 = MAKE_SEQ(_1);
        _26622 = NOVALUE;
        _50Warning(327, 16384, _26623);
        _26623 = NOVALUE;
L2C: 

        /** emit.e:881			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:882			emit_addr(subsym)*/
        _47emit_addr(_subsym_51882);

        /** emit.e:883			for i = cgi-n+1 to cgi do*/
        _26624 = _47cgi_50952 - _n_51887;
        if ((object)((uintptr_t)_26624 +(uintptr_t) HIGH_BITS) >= 0){
            _26624 = NewDouble((eudouble)_26624);
        }
        if (IS_ATOM_INT(_26624)) {
            _26625 = _26624 + 1;
            if (_26625 > MAXINT){
                _26625 = NewDouble((eudouble)_26625);
            }
        }
        else
        _26625 = binary_op(PLUS, 1, _26624);
        DeRef(_26624);
        _26624 = NOVALUE;
        _26626 = _47cgi_50952;
        {
            object _i_52180;
            Ref(_26625);
            _i_52180 = _26625;
L2D: 
            if (binary_op_a(GREATER, _i_52180, _26626)){
                goto L2E; // [1410] 1447
            }

            /** emit.e:884				emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_47cg_stack_50951);
            if (!IS_ATOM_INT(_i_52180)){
                _26627 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52180)->dbl));
            }
            else{
                _26627 = (object)*(((s1_ptr)_2)->base + _i_52180);
            }
            Ref(_26627);
            _47emit_addr(_26627);
            _26627 = NOVALUE;

            /** emit.e:885				emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (object)SEQ_PTR(_47cg_stack_50951);
            if (!IS_ATOM_INT(_i_52180)){
                _26628 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52180)->dbl));
            }
            else{
                _26628 = (object)*(((s1_ptr)_2)->base + _i_52180);
            }
            Ref(_26628);
            _47emit_temp(_26628, 1);
            _26628 = NOVALUE;

            /** emit.e:886			end for*/
            _0 = _i_52180;
            if (IS_ATOM_INT(_i_52180)) {
                _i_52180 = _i_52180 + 1;
                if ((object)((uintptr_t)_i_52180 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_52180 = NewDouble((eudouble)_i_52180);
                }
            }
            else {
                _i_52180 = binary_op_a(PLUS, _i_52180, 1);
            }
            DeRef(_0);
            goto L2D; // [1442] 1417
L2E: 
            ;
            DeRef(_i_52180);
        }

        /** emit.e:888			cgi -= n*/
        _47cgi_50952 = _47cgi_50952 - _n_51887;

        /** emit.e:890			if SymTab[subsym][S_TOKEN] != PROC then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26630 = (object)*(((s1_ptr)_2)->base + _subsym_51882);
        _2 = (object)SEQ_PTR(_26630);
        if (!IS_ATOM_INT(_36S_TOKEN_21089)){
            _26631 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
        }
        else{
            _26631 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21089);
        }
        _26630 = NOVALUE;
        if (binary_op_a(EQUALS, _26631, 27)){
            _26631 = NOVALUE;
            goto LC; // [1471] 7739
        }
        _26631 = NOVALUE;

        /** emit.e:891				assignable = TRUE*/
        _47assignable_50954 = _13TRUE_452;

        /** emit.e:892				c = NewTempSym() -- put final result in temp*/
        _c_51878 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:893				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_51878, 1);

        /** emit.e:894				Push(c)*/
        _47Push(_c_51878);

        /** emit.e:896				emit_addr(c)*/
        _47emit_addr(_c_51878);
        goto LC; // [1507] 7739

        /** emit.e:900		case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** emit.e:901			assignable = FALSE -- assume for now*/
        _47assignable_50954 = _13FALSE_450;

        /** emit.e:902			integer real_op*/

        /** emit.e:903			if op = PROC_FORWARD then*/
        if (_op_51874 != 195)
        goto L2F; // [1528] 1544

        /** emit.e:904				real_op = PROC*/
        _real_op_52201 = 27;
        goto L30; // [1541] 1554
L2F: 

        /** emit.e:906				real_op = FUNC*/
        _real_op_52201 = 501;
L30: 

        /** emit.e:908			integer ref*/

        /** emit.e:909			ref = new_forward_reference( real_op, op_info1, real_op )*/
        _ref_52208 = _44new_forward_reference(_real_op_52201, _47op_info1_50936, _real_op_52201);
        if (!IS_ATOM_INT(_ref_52208)) {
            _1 = (object)(DBL_PTR(_ref_52208)->dbl);
            DeRefDS(_ref_52208);
            _ref_52208 = _1;
        }

        /** emit.e:910			n = Pop() -- number of known args*/
        _n_51887 = _47Pop();
        if (!IS_ATOM_INT(_n_51887)) {
            _1 = (object)(DBL_PTR(_n_51887)->dbl);
            DeRefDS(_n_51887);
            _n_51887 = _1;
        }

        /** emit.e:912			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:913			emit_addr(ref)*/
        _47emit_addr(_ref_52208);

        /** emit.e:914			emit_addr( n ) -- this changes to be the "next" instruction*/
        _47emit_addr(_n_51887);

        /** emit.e:915			for i = cgi-n+1 to cgi do*/
        _26637 = _47cgi_50952 - _n_51887;
        if ((object)((uintptr_t)_26637 +(uintptr_t) HIGH_BITS) >= 0){
            _26637 = NewDouble((eudouble)_26637);
        }
        if (IS_ATOM_INT(_26637)) {
            _26638 = _26637 + 1;
            if (_26638 > MAXINT){
                _26638 = NewDouble((eudouble)_26638);
            }
        }
        else
        _26638 = binary_op(PLUS, 1, _26637);
        DeRef(_26637);
        _26637 = NOVALUE;
        _26639 = _47cgi_50952;
        {
            object _i_52213;
            Ref(_26638);
            _i_52213 = _26638;
L31: 
            if (binary_op_a(GREATER, _i_52213, _26639)){
                goto L32; // [1609] 1646
            }

            /** emit.e:916				emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_47cg_stack_50951);
            if (!IS_ATOM_INT(_i_52213)){
                _26640 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52213)->dbl));
            }
            else{
                _26640 = (object)*(((s1_ptr)_2)->base + _i_52213);
            }
            Ref(_26640);
            _47emit_addr(_26640);
            _26640 = NOVALUE;

            /** emit.e:917				emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (object)SEQ_PTR(_47cg_stack_50951);
            if (!IS_ATOM_INT(_i_52213)){
                _26641 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52213)->dbl));
            }
            else{
                _26641 = (object)*(((s1_ptr)_2)->base + _i_52213);
            }
            Ref(_26641);
            _47emit_temp(_26641, 1);
            _26641 = NOVALUE;

            /** emit.e:918			end for*/
            _0 = _i_52213;
            if (IS_ATOM_INT(_i_52213)) {
                _i_52213 = _i_52213 + 1;
                if ((object)((uintptr_t)_i_52213 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_52213 = NewDouble((eudouble)_i_52213);
                }
            }
            else {
                _i_52213 = binary_op_a(PLUS, _i_52213, 1);
            }
            DeRef(_0);
            goto L31; // [1641] 1616
L32: 
            ;
            DeRef(_i_52213);
        }

        /** emit.e:919			cgi -= n*/
        _47cgi_50952 = _47cgi_50952 - _n_51887;

        /** emit.e:921			if op != PROC_FORWARD then*/
        if (_op_51874 == 195)
        goto L33; // [1658] 1694

        /** emit.e:922				assignable = TRUE*/
        _47assignable_50954 = _13TRUE_452;

        /** emit.e:923				c = NewTempSym() -- put final result in temp*/
        _c_51878 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:924				Push(c)*/
        _47Push(_c_51878);

        /** emit.e:926				emit_addr(c)*/
        _47emit_addr(_c_51878);

        /** emit.e:927				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_51878, 1);
L33: 
        goto LC; // [1696] 7739

        /** emit.e:930		case WARNING then*/
        case 506:

        /** emit.e:931			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;

        /** emit.e:932		    a = Pop()*/
        _a_51876 = _47Pop();
        if (!IS_ATOM_INT(_a_51876)) {
            _1 = (object)(DBL_PTR(_a_51876)->dbl);
            DeRefDS(_a_51876);
            _a_51876 = _1;
        }

        /** emit.e:933			Warning(SymTab[a][S_OBJ], custom_warning_flag,"")*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26646 = (object)*(((s1_ptr)_2)->base + _a_51876);
        _2 = (object)SEQ_PTR(_26646);
        _26647 = (object)*(((s1_ptr)_2)->base + 1);
        _26646 = NOVALUE;
        Ref(_26647);
        RefDS(_21997);
        _50Warning(_26647, 64, _21997);
        _26647 = NOVALUE;
        goto LC; // [1737] 7739

        /** emit.e:935		case INCLUDE_PATHS then*/
        case 507:

        /** emit.e:936			sequence paths*/

        /** emit.e:938			assignable = TRUE*/
        _47assignable_50954 = _13TRUE_452;

        /** emit.e:939		    a = Pop()*/
        _a_51876 = _47Pop();
        if (!IS_ATOM_INT(_a_51876)) {
            _1 = (object)(DBL_PTR(_a_51876)->dbl);
            DeRefDS(_a_51876);
            _a_51876 = _1;
        }

        /** emit.e:940		    emit_opcode(RIGHT_BRACE_N)*/
        _47emit_opcode(31);

        /** emit.e:941		    paths = Include_paths(SymTab[a][S_OBJ])*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26649 = (object)*(((s1_ptr)_2)->base + _a_51876);
        _2 = (object)SEQ_PTR(_26649);
        _26650 = (object)*(((s1_ptr)_2)->base + 1);
        _26649 = NOVALUE;
        Ref(_26650);
        _0 = _paths_52238;
        _paths_52238 = _48Include_paths(_26650);
        DeRef(_0);
        _26650 = NOVALUE;

        /** emit.e:942		    emit(length(paths))*/
        if (IS_SEQUENCE(_paths_52238)){
                _26652 = SEQ_PTR(_paths_52238)->length;
        }
        else {
            _26652 = 1;
        }
        _47emit(_26652);
        _26652 = NOVALUE;

        /** emit.e:943		    for i=length(paths) to 1 by -1 do*/
        if (IS_SEQUENCE(_paths_52238)){
                _26653 = SEQ_PTR(_paths_52238)->length;
        }
        else {
            _26653 = 1;
        }
        {
            object _i_52250;
            _i_52250 = _26653;
L34: 
            if (_i_52250 < 1){
                goto L35; // [1799] 1830
            }

            /** emit.e:944		        c = NewStringSym(paths[i])*/
            _2 = (object)SEQ_PTR(_paths_52238);
            _26654 = (object)*(((s1_ptr)_2)->base + _i_52250);
            Ref(_26654);
            _c_51878 = _54NewStringSym(_26654);
            _26654 = NOVALUE;
            if (!IS_ATOM_INT(_c_51878)) {
                _1 = (object)(DBL_PTR(_c_51878)->dbl);
                DeRefDS(_c_51878);
                _c_51878 = _1;
            }

            /** emit.e:945		        emit_addr(c)*/
            _47emit_addr(_c_51878);

            /** emit.e:946		    end for*/
            _i_52250 = _i_52250 + -1;
            goto L34; // [1825] 1806
L35: 
            ;
        }

        /** emit.e:947		    b = NewTempSym()*/
        _b_51877 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:948			emit_temp(b, NEW_REFERENCE)*/
        _47emit_temp(_b_51877, 1);

        /** emit.e:949		    Push(b)*/
        _47Push(_b_51877);

        /** emit.e:950		    emit_addr(b)*/
        _47emit_addr(_b_51877);

        /** emit.e:951			last_op = RIGHT_BRACE_N*/
        _47last_op_51833 = 31;

        /** emit.e:952			op = last_op*/
        _op_51874 = 31;
        DeRef(_paths_52238);
        _paths_52238 = NOVALUE;
        goto LC; // [1872] 7739

        /** emit.e:955		case NOP1, NOP2, NOPWHILE, PRIVATE_INIT_CHECK, GLOBAL_INIT_CHECK,*/
        case 159:
        case 110:
        case 158:
        case 30:
        case 109:
        case 58:
        case 59:
        case 61:
        case 184:
        case 22:
        case 23:
        case 188:
        case 189:
        case 88:
        case 43:
        case 90:
        case 89:
        case 87:
        case 135:
        case 156:
        case 169:
        case 175:
        case 174:
        case 187:
        case 210:
        case 211:

        /** emit.e:961			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:962			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;

        /** emit.e:963			if op = UPDATE_GLOBALS then*/
        if (_op_51874 != 89)
        goto LC; // [1944] 7739

        /** emit.e:964				last_op = last_op_backup*/
        _47last_op_51833 = _last_op_backup_51892;

        /** emit.e:965				last_pc = last_pc_backup*/
        _47last_pc_51834 = _last_pc_backup_51891;
        goto LC; // [1959] 7739

        /** emit.e:969		case IF, WHILE then*/
        case 20:
        case 47:

        /** emit.e:970			a = Pop()*/
        _a_51876 = _47Pop();
        if (!IS_ATOM_INT(_a_51876)) {
            _1 = (object)(DBL_PTR(_a_51876)->dbl);
            DeRefDS(_a_51876);
            _a_51876 = _1;
        }

        /** emit.e:971			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;

        /** emit.e:973			if previous_op >= LESS and previous_op <= NOT then*/
        _26659 = (_36previous_op_21549 >= 1);
        if (_26659 == 0) {
            goto L36; // [1991] 2283
        }
        _26661 = (_36previous_op_21549 <= 7);
        if (_26661 == 0)
        {
            DeRef(_26661);
            _26661 = NOVALUE;
            goto L36; // [2004] 2283
        }
        else{
            DeRef(_26661);
            _26661 = NOVALUE;
        }

        /** emit.e:974				clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26662 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26662 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21539);
        _26663 = (object)*(((s1_ptr)_2)->base + _26662);
        Ref(_26663);
        _47clear_temp(_26663);
        _26663 = NOVALUE;

        /** emit.e:975				Code = Code[1..$-1]*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26664 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26664 = 1;
        }
        _26665 = _26664 - 1;
        _26664 = NOVALUE;
        rhs_slice_target = (object_ptr)&_36Code_21539;
        RHS_Slice(_36Code_21539, 1, _26665);

        /** emit.e:976				if previous_op = NOT then*/
        if (_36previous_op_21549 != 7)
        goto L37; // [2045] 2125

        /** emit.e:977					op = NOT_IFW*/
        _op_51874 = 108;

        /** emit.e:978					backpatch(length(Code) - 1, op)*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26668 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26668 = 1;
        }
        _26669 = _26668 - 1;
        _26668 = NOVALUE;
        _47backpatch(_26669, 108);
        _26669 = NOVALUE;

        /** emit.e:979					sequence if_code = Code[$-1..$]*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26670 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26670 = 1;
        }
        _26671 = _26670 - 1;
        _26670 = NOVALUE;
        if (IS_SEQUENCE(_36Code_21539)){
                _26672 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26672 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_52318;
        RHS_Slice(_36Code_21539, _26671, _26672);

        /** emit.e:980					Code = Code[1..$-2]*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26674 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26674 = 1;
        }
        _26675 = _26674 - 2;
        _26674 = NOVALUE;
        rhs_slice_target = (object_ptr)&_36Code_21539;
        RHS_Slice(_36Code_21539, 1, _26675);

        /** emit.e:981					Code &= if_code*/
        Concat((object_ptr)&_36Code_21539, _36Code_21539, _if_code_52318);
        DeRefDS(_if_code_52318);
        _if_code_52318 = NOVALUE;
        goto L38; // [2122] 2270
L37: 

        /** emit.e:983					if IsInteger(Code[$-1]) and IsInteger(Code[$]) then*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26678 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26678 = 1;
        }
        _26679 = _26678 - 1;
        _26678 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21539);
        _26680 = (object)*(((s1_ptr)_2)->base + _26679);
        Ref(_26680);
        _26681 = _47IsInteger(_26680);
        _26680 = NOVALUE;
        if (IS_ATOM_INT(_26681)) {
            if (_26681 == 0) {
                goto L39; // [2144] 2186
            }
        }
        else {
            if (DBL_PTR(_26681)->dbl == 0.0) {
                goto L39; // [2144] 2186
            }
        }
        if (IS_SEQUENCE(_36Code_21539)){
                _26683 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26683 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21539);
        _26684 = (object)*(((s1_ptr)_2)->base + _26683);
        Ref(_26684);
        _26685 = _47IsInteger(_26684);
        _26684 = NOVALUE;
        if (_26685 == 0) {
            DeRef(_26685);
            _26685 = NOVALUE;
            goto L39; // [2162] 2186
        }
        else {
            if (!IS_ATOM_INT(_26685) && DBL_PTR(_26685)->dbl == 0.0){
                DeRef(_26685);
                _26685 = NOVALUE;
                goto L39; // [2162] 2186
            }
            DeRef(_26685);
            _26685 = NOVALUE;
        }
        DeRef(_26685);
        _26685 = NOVALUE;

        /** emit.e:984						op = previous_op + LESS_IFW_I - LESS*/
        _26686 = _36previous_op_21549 + 119;
        if ((object)((uintptr_t)_26686 + (uintptr_t)HIGH_BITS) >= 0){
            _26686 = NewDouble((eudouble)_26686);
        }
        if (IS_ATOM_INT(_26686)) {
            _op_51874 = _26686 - 1;
        }
        else {
            _op_51874 = NewDouble(DBL_PTR(_26686)->dbl - (eudouble)1);
        }
        DeRef(_26686);
        _26686 = NOVALUE;
        if (!IS_ATOM_INT(_op_51874)) {
            _1 = (object)(DBL_PTR(_op_51874)->dbl);
            DeRefDS(_op_51874);
            _op_51874 = _1;
        }
        goto L3A; // [2183] 2205
L39: 

        /** emit.e:986						op = previous_op + LESS_IFW - LESS*/
        _26688 = _36previous_op_21549 + 102;
        if ((object)((uintptr_t)_26688 + (uintptr_t)HIGH_BITS) >= 0){
            _26688 = NewDouble((eudouble)_26688);
        }
        if (IS_ATOM_INT(_26688)) {
            _op_51874 = _26688 - 1;
        }
        else {
            _op_51874 = NewDouble(DBL_PTR(_26688)->dbl - (eudouble)1);
        }
        DeRef(_26688);
        _26688 = NOVALUE;
        if (!IS_ATOM_INT(_op_51874)) {
            _1 = (object)(DBL_PTR(_op_51874)->dbl);
            DeRefDS(_op_51874);
            _op_51874 = _1;
        }
L3A: 

        /** emit.e:989					backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26690 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26690 = 1;
        }
        _26691 = _26690 - 2;
        _26690 = NOVALUE;
        _47backpatch(_26691, _op_51874);
        _26691 = NOVALUE;

        /** emit.e:991					sequence if_code = Code[$-2..$]*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26692 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26692 = 1;
        }
        _26693 = _26692 - 2;
        _26692 = NOVALUE;
        if (IS_SEQUENCE(_36Code_21539)){
                _26694 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26694 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_52357;
        RHS_Slice(_36Code_21539, _26693, _26694);

        /** emit.e:992					Code = Code[1..$-3]*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26696 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26696 = 1;
        }
        _26697 = _26696 - 3;
        _26696 = NOVALUE;
        rhs_slice_target = (object_ptr)&_36Code_21539;
        RHS_Slice(_36Code_21539, 1, _26697);

        /** emit.e:993					Code &= if_code*/
        Concat((object_ptr)&_36Code_21539, _36Code_21539, _if_code_52357);
        DeRefDS(_if_code_52357);
        _if_code_52357 = NOVALUE;
L38: 

        /** emit.e:997				last_pc = last_pc_backup*/
        _47last_pc_51834 = _last_pc_backup_51891;

        /** emit.e:998				last_op = op*/
        _47last_op_51833 = _op_51874;
        goto LC; // [2280] 7739
L36: 

        /** emit.e:1000			elsif op = WHILE and*/
        _26700 = (_op_51874 == 47);
        if (_26700 == 0) {
            _26701 = 0;
            goto L3B; // [2291] 2303
        }
        _26702 = (_a_51876 > 0);
        _26701 = (_26702 != 0);
L3B: 
        if (_26701 == 0) {
            _26703 = 0;
            goto L3C; // [2303] 2329
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26704 = (object)*(((s1_ptr)_2)->base + _a_51876);
        _2 = (object)SEQ_PTR(_26704);
        _26705 = (object)*(((s1_ptr)_2)->base + 3);
        _26704 = NOVALUE;
        if (IS_ATOM_INT(_26705)) {
            _26706 = (_26705 == 2);
        }
        else {
            _26706 = binary_op(EQUALS, _26705, 2);
        }
        _26705 = NOVALUE;
        if (IS_ATOM_INT(_26706))
        _26703 = (_26706 != 0);
        else
        _26703 = DBL_PTR(_26706)->dbl != 0.0;
L3C: 
        if (_26703 == 0) {
            _26707 = 0;
            goto L3D; // [2329] 2352
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26708 = (object)*(((s1_ptr)_2)->base + _a_51876);
        _2 = (object)SEQ_PTR(_26708);
        _26709 = (object)*(((s1_ptr)_2)->base + 1);
        _26708 = NOVALUE;
        if (IS_ATOM_INT(_26709))
        _26710 = 1;
        else if (IS_ATOM_DBL(_26709))
        _26710 = IS_ATOM_INT(DoubleToInt(_26709));
        else
        _26710 = 0;
        _26709 = NOVALUE;
        _26707 = (_26710 != 0);
L3D: 
        if (_26707 == 0) {
            goto L3E; // [2352] 2401
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26712 = (object)*(((s1_ptr)_2)->base + _a_51876);
        _2 = (object)SEQ_PTR(_26712);
        _26713 = (object)*(((s1_ptr)_2)->base + 1);
        _26712 = NOVALUE;
        if (_26713 == 0)
        _26714 = 1;
        else if (IS_ATOM_INT(_26713) && IS_ATOM_INT(0))
        _26714 = 0;
        else
        _26714 = (compare(_26713, 0) == 0);
        _26713 = NOVALUE;
        _26715 = (_26714 == 0);
        _26714 = NOVALUE;
        if (_26715 == 0)
        {
            DeRef(_26715);
            _26715 = NOVALUE;
            goto L3E; // [2376] 2401
        }
        else{
            DeRef(_26715);
            _26715 = NOVALUE;
        }

        /** emit.e:1005				optimized_while = TRUE   -- while TRUE ... emit nothing*/
        _47optimized_while_50938 = _13TRUE_452;

        /** emit.e:1006				last_pc = last_pc_backup*/
        _47last_pc_51834 = _last_pc_backup_51891;

        /** emit.e:1007				last_op = last_op_backup*/
        _47last_op_51833 = _last_op_backup_51892;
        goto LC; // [2398] 7739
L3E: 

        /** emit.e:1009				flush_temps( {a} )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _a_51876;
        _26716 = MAKE_SEQ(_1);
        _47flush_temps(_26716);
        _26716 = NOVALUE;

        /** emit.e:1010				emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1011				emit_addr(a)*/
        _47emit_addr(_a_51876);
        goto LC; // [2421] 7739

        /** emit.e:1016		case INTEGER_CHECK then*/
        case 96:

        /** emit.e:1017			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;

        /** emit.e:1018			if previous_op = ASSIGN then*/
        if (_36previous_op_21549 != 18)
        goto L3F; // [2440] 2499

        /** emit.e:1019				c = Code[$-1]*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26718 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26718 = 1;
        }
        _26719 = _26718 - 1;
        _26718 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21539);
        _c_51878 = (object)*(((s1_ptr)_2)->base + _26719);
        if (!IS_ATOM_INT(_c_51878)){
            _c_51878 = (object)DBL_PTR(_c_51878)->dbl;
        }

        /** emit.e:1020				if not IsInteger(c) then*/
        _26721 = _47IsInteger(_c_51878);
        if (IS_ATOM_INT(_26721)) {
            if (_26721 != 0){
                DeRef(_26721);
                _26721 = NOVALUE;
                goto L40; // [2467] 2485
            }
        }
        else {
            if (DBL_PTR(_26721)->dbl != 0.0){
                DeRef(_26721);
                _26721 = NOVALUE;
                goto L40; // [2467] 2485
            }
        }
        DeRef(_26721);
        _26721 = NOVALUE;

        /** emit.e:1021					emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1022					emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_50936);
        goto L41; // [2482] 2556
L40: 

        /** emit.e:1024					last_op = last_op_backup*/
        _47last_op_51833 = _last_op_backup_51892;

        /** emit.e:1025					last_pc = last_pc_backup*/
        _47last_pc_51834 = _last_pc_backup_51891;
        goto L41; // [2496] 2556
L3F: 

        /** emit.e:1027			elsif previous_op = -1 or*/
        _26723 = (_36previous_op_21549 == -1);
        if (_26723 != 0) {
            goto L42; // [2507] 2530
        }
        _2 = (object)SEQ_PTR(_47op_result_51552);
        _26725 = (object)*(((s1_ptr)_2)->base + _36previous_op_21549);
        _26726 = (_26725 != 1);
        _26725 = NOVALUE;
        if (_26726 == 0)
        {
            DeRef(_26726);
            _26726 = NOVALUE;
            goto L43; // [2526] 2545
        }
        else{
            DeRef(_26726);
            _26726 = NOVALUE;
        }
L42: 

        /** emit.e:1029				emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1030				emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_50936);
        goto L41; // [2542] 2556
L43: 

        /** emit.e:1032				last_op = last_op_backup*/
        _47last_op_51833 = _last_op_backup_51892;

        /** emit.e:1033				last_pc = last_pc_backup*/
        _47last_pc_51834 = _last_pc_backup_51891;
L41: 

        /** emit.e:1035			clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26727 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26727 = 1;
        }
        _26728 = _26727 - 1;
        _26727 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21539);
        _26729 = (object)*(((s1_ptr)_2)->base + _26728);
        Ref(_26729);
        _47clear_temp(_26729);
        _26729 = NOVALUE;
        goto LC; // [2574] 7739

        /** emit.e:1037		case SEQUENCE_CHECK then*/
        case 97:

        /** emit.e:1038			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;

        /** emit.e:1039			if previous_op = ASSIGN then*/
        if (_36previous_op_21549 != 18)
        goto L44; // [2593] 2720

        /** emit.e:1040				c = Code[$-1]*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26731 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26731 = 1;
        }
        _26732 = _26731 - 1;
        _26731 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21539);
        _c_51878 = (object)*(((s1_ptr)_2)->base + _26732);
        if (!IS_ATOM_INT(_c_51878)){
            _c_51878 = (object)DBL_PTR(_c_51878)->dbl;
        }

        /** emit.e:1041				if c < 1 or*/
        _26734 = (_c_51878 < 1);
        if (_26734 != 0) {
            _26735 = 1;
            goto L45; // [2620] 2646
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26736 = (object)*(((s1_ptr)_2)->base + _c_51878);
        _2 = (object)SEQ_PTR(_26736);
        _26737 = (object)*(((s1_ptr)_2)->base + 3);
        _26736 = NOVALUE;
        if (IS_ATOM_INT(_26737)) {
            _26738 = (_26737 != 2);
        }
        else {
            _26738 = binary_op(NOTEQ, _26737, 2);
        }
        _26737 = NOVALUE;
        if (IS_ATOM_INT(_26738))
        _26735 = (_26738 != 0);
        else
        _26735 = DBL_PTR(_26738)->dbl != 0.0;
L45: 
        if (_26735 != 0) {
            goto L46; // [2646] 2673
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26740 = (object)*(((s1_ptr)_2)->base + _c_51878);
        _2 = (object)SEQ_PTR(_26740);
        _26741 = (object)*(((s1_ptr)_2)->base + 1);
        _26740 = NOVALUE;
        _26742 = IS_SEQUENCE(_26741);
        _26741 = NOVALUE;
        _26743 = (_26742 == 0);
        _26742 = NOVALUE;
        if (_26743 == 0)
        {
            DeRef(_26743);
            _26743 = NOVALUE;
            goto L47; // [2669] 2706
        }
        else{
            DeRef(_26743);
            _26743 = NOVALUE;
        }
L46: 

        /** emit.e:1044					emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1045					emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_50936);

        /** emit.e:1046					clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26744 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26744 = 1;
        }
        _26745 = _26744 - 1;
        _26744 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21539);
        _26746 = (object)*(((s1_ptr)_2)->base + _26745);
        Ref(_26746);
        _47clear_temp(_26746);
        _26746 = NOVALUE;
        goto LC; // [2703] 7739
L47: 

        /** emit.e:1048					last_op = last_op_backup*/
        _47last_op_51833 = _last_op_backup_51892;

        /** emit.e:1049					last_pc = last_pc_backup*/
        _47last_pc_51834 = _last_pc_backup_51891;
        goto LC; // [2717] 7739
L44: 

        /** emit.e:1051			elsif previous_op = -1 or op_result[previous_op] != T_SEQUENCE then*/
        _26747 = (_36previous_op_21549 == -1);
        if (_26747 != 0) {
            goto L48; // [2728] 2751
        }
        _2 = (object)SEQ_PTR(_47op_result_51552);
        _26749 = (object)*(((s1_ptr)_2)->base + _36previous_op_21549);
        _26750 = (_26749 != 2);
        _26749 = NOVALUE;
        if (_26750 == 0)
        {
            DeRef(_26750);
            _26750 = NOVALUE;
            goto L49; // [2747] 2784
        }
        else{
            DeRef(_26750);
            _26750 = NOVALUE;
        }
L48: 

        /** emit.e:1052				emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1053				emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_50936);

        /** emit.e:1054				clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26751 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26751 = 1;
        }
        _26752 = _26751 - 1;
        _26751 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21539);
        _26753 = (object)*(((s1_ptr)_2)->base + _26752);
        Ref(_26753);
        _47clear_temp(_26753);
        _26753 = NOVALUE;
        goto LC; // [2781] 7739
L49: 

        /** emit.e:1056				last_op = last_op_backup*/
        _47last_op_51833 = _last_op_backup_51892;

        /** emit.e:1057				last_pc = last_pc_backup*/
        _47last_pc_51834 = _last_pc_backup_51891;
        goto LC; // [2795] 7739

        /** emit.e:1061		case ATOM_CHECK then*/
        case 101:

        /** emit.e:1062			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;

        /** emit.e:1063			if previous_op = ASSIGN then*/
        if (_36previous_op_21549 != 18)
        goto L4A; // [2814] 3015

        /** emit.e:1064				c = Code[$-1]*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26755 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26755 = 1;
        }
        _26756 = _26755 - 1;
        _26755 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21539);
        _c_51878 = (object)*(((s1_ptr)_2)->base + _26756);
        if (!IS_ATOM_INT(_c_51878)){
            _c_51878 = (object)DBL_PTR(_c_51878)->dbl;
        }

        /** emit.e:1065				if c > 1*/
        _26758 = (_c_51878 > 1);
        if (_26758 == 0) {
            goto L4B; // [2841] 2964
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26760 = (object)*(((s1_ptr)_2)->base + _c_51878);
        _2 = (object)SEQ_PTR(_26760);
        _26761 = (object)*(((s1_ptr)_2)->base + 3);
        _26760 = NOVALUE;
        if (IS_ATOM_INT(_26761)) {
            _26762 = (_26761 == 2);
        }
        else {
            _26762 = binary_op(EQUALS, _26761, 2);
        }
        _26761 = NOVALUE;
        if (_26762 == 0) {
            DeRef(_26762);
            _26762 = NOVALUE;
            goto L4B; // [2864] 2964
        }
        else {
            if (!IS_ATOM_INT(_26762) && DBL_PTR(_26762)->dbl == 0.0){
                DeRef(_26762);
                _26762 = NOVALUE;
                goto L4B; // [2864] 2964
            }
            DeRef(_26762);
            _26762 = NOVALUE;
        }
        DeRef(_26762);
        _26762 = NOVALUE;

        /** emit.e:1068					if sequence( SymTab[c][S_OBJ] ) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26763 = (object)*(((s1_ptr)_2)->base + _c_51878);
        _2 = (object)SEQ_PTR(_26763);
        _26764 = (object)*(((s1_ptr)_2)->base + 1);
        _26763 = NOVALUE;
        _26765 = IS_SEQUENCE(_26764);
        _26764 = NOVALUE;
        if (_26765 == 0)
        {
            _26765 = NOVALUE;
            goto L4C; // [2884] 2915
        }
        else{
            _26765 = NOVALUE;
        }

        /** emit.e:1070						ThisLine = ExprLine*/
        RefDS(_45ExprLine_57046);
        DeRef(_50ThisLine_49238);
        _50ThisLine_49238 = _45ExprLine_57046;

        /** emit.e:1071						bp = expr_bp*/
        _50bp_49242 = _45expr_bp_57047;

        /** emit.e:1072						CompileErr( TYPE_CHECK_ERROR__ASSIGNING_A_SEQUENCE_TO_AN_ATOM)*/
        RefDS(_21997);
        _50CompileErr(346, _21997, 0);
        goto L4D; // [2912] 3094
L4C: 

        /** emit.e:1074					elsif SymTab[c][S_OBJ] = NOVALUE then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26766 = (object)*(((s1_ptr)_2)->base + _c_51878);
        _2 = (object)SEQ_PTR(_26766);
        _26767 = (object)*(((s1_ptr)_2)->base + 1);
        _26766 = NOVALUE;
        if (binary_op_a(NOTEQ, _26767, _36NOVALUE_21301)){
            _26767 = NOVALUE;
            goto L4E; // [2931] 2950
        }
        _26767 = NOVALUE;

        /** emit.e:1075						emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1076						emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_50936);
        goto L4D; // [2947] 3094
L4E: 

        /** emit.e:1078						last_op = last_op_backup*/
        _47last_op_51833 = _last_op_backup_51892;

        /** emit.e:1079						last_pc = last_pc_backup*/
        _47last_pc_51834 = _last_pc_backup_51891;
        goto L4D; // [2961] 3094
L4B: 

        /** emit.e:1082				elsif c < 1 */
        _26769 = (_c_51878 < 1);
        if (_26769 != 0) {
            goto L4F; // [2970] 2986
        }
        _26771 = _47IsInteger(_c_51878);
        if (IS_ATOM_INT(_26771)) {
            _26772 = (_26771 == 0);
        }
        else {
            _26772 = unary_op(NOT, _26771);
        }
        DeRef(_26771);
        _26771 = NOVALUE;
        if (_26772 == 0) {
            DeRef(_26772);
            _26772 = NOVALUE;
            goto L50; // [2982] 3001
        }
        else {
            if (!IS_ATOM_INT(_26772) && DBL_PTR(_26772)->dbl == 0.0){
                DeRef(_26772);
                _26772 = NOVALUE;
                goto L50; // [2982] 3001
            }
            DeRef(_26772);
            _26772 = NOVALUE;
        }
        DeRef(_26772);
        _26772 = NOVALUE;
L4F: 

        /** emit.e:1085					emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1086					emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_50936);
        goto L4D; // [2998] 3094
L50: 

        /** emit.e:1089					last_op = last_op_backup*/
        _47last_op_51833 = _last_op_backup_51892;

        /** emit.e:1090					last_pc = last_pc_backup*/
        _47last_pc_51834 = _last_pc_backup_51891;
        goto L4D; // [3012] 3094
L4A: 

        /** emit.e:1092			elsif previous_op = -1 or*/
        _26773 = (_36previous_op_21549 == -1);
        if (_26773 != 0) {
            goto L51; // [3023] 3068
        }
        _2 = (object)SEQ_PTR(_47op_result_51552);
        _26775 = (object)*(((s1_ptr)_2)->base + _36previous_op_21549);
        _26776 = (_26775 != 1);
        _26775 = NOVALUE;
        if (_26776 == 0) {
            DeRef(_26777);
            _26777 = 0;
            goto L52; // [3041] 3063
        }
        _2 = (object)SEQ_PTR(_47op_result_51552);
        _26778 = (object)*(((s1_ptr)_2)->base + _36previous_op_21549);
        _26779 = (_26778 != 3);
        _26778 = NOVALUE;
        _26777 = (_26779 != 0);
L52: 
        if (_26777 == 0)
        {
            _26777 = NOVALUE;
            goto L53; // [3064] 3083
        }
        else{
            _26777 = NOVALUE;
        }
L51: 

        /** emit.e:1095				emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1096				emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_50936);
        goto L4D; // [3080] 3094
L53: 

        /** emit.e:1098				last_op = last_op_backup*/
        _47last_op_51833 = _last_op_backup_51892;

        /** emit.e:1099				last_pc = last_pc_backup*/
        _47last_pc_51834 = _last_pc_backup_51891;
L4D: 

        /** emit.e:1101			clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26780 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26780 = 1;
        }
        _26781 = _26780 - 1;
        _26780 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21539);
        _26782 = (object)*(((s1_ptr)_2)->base + _26781);
        Ref(_26782);
        _47clear_temp(_26782);
        _26782 = NOVALUE;
        goto LC; // [3112] 7739

        /** emit.e:1103		case RIGHT_BRACE_N then*/
        case 31:

        /** emit.e:1105			n = op_info1*/
        _n_51887 = _47op_info1_50936;

        /** emit.e:1107			elements = {}*/
        RefDS(_21997);
        DeRef(_elements_51889);
        _elements_51889 = _21997;

        /** emit.e:1108			for i = 1 to n do*/
        _26783 = _n_51887;
        {
            object _i_52538;
            _i_52538 = 1;
L54: 
            if (_i_52538 > _26783){
                goto L55; // [3137] 3160
            }

            /** emit.e:1109				elements = append(elements, Pop())*/
            _26784 = _47Pop();
            Ref(_26784);
            Append(&_elements_51889, _elements_51889, _26784);
            DeRef(_26784);
            _26784 = NOVALUE;

            /** emit.e:1110			end for*/
            _i_52538 = _i_52538 + 1;
            goto L54; // [3155] 3144
L55: 
            ;
        }

        /** emit.e:1111			element_vals = good_string(elements)*/
        RefDS(_elements_51889);
        _0 = _element_vals_51890;
        _element_vals_51890 = _47good_string(_elements_51889);
        DeRef(_0);

        /** emit.e:1113			if sequence(element_vals) then*/
        _26787 = IS_SEQUENCE(_element_vals_51890);
        if (_26787 == 0)
        {
            _26787 = NOVALUE;
            goto L56; // [3171] 3202
        }
        else{
            _26787 = NOVALUE;
        }

        /** emit.e:1114				c = NewStringSym(element_vals)  -- make a string literal*/
        Ref(_element_vals_51890);
        _c_51878 = _54NewStringSym(_element_vals_51890);
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1115				assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;

        /** emit.e:1116				last_op = last_op_backup*/
        _47last_op_51833 = _last_op_backup_51892;

        /** emit.e:1117				last_pc = last_pc_backup*/
        _47last_pc_51834 = _last_pc_backup_51891;
        goto L57; // [3199] 3293
L56: 

        /** emit.e:1119				if n = 2 then*/
        if (_n_51887 != 2)
        goto L58; // [3204] 3227

        /** emit.e:1120					emit_opcode(RIGHT_BRACE_2) -- faster op for two items*/
        _47emit_opcode(85);

        /** emit.e:1121					last_op = RIGHT_BRACE_2*/
        _47last_op_51833 = 85;
        goto L59; // [3224] 3238
L58: 

        /** emit.e:1123					emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1124					emit(n)*/
        _47emit(_n_51887);
L59: 

        /** emit.e:1127				for i = 1 to n do*/
        _26790 = _n_51887;
        {
            object _i_52555;
            _i_52555 = 1;
L5A: 
            if (_i_52555 > _26790){
                goto L5B; // [3243] 3266
            }

            /** emit.e:1128					emit_addr(elements[i])*/
            _2 = (object)SEQ_PTR(_elements_51889);
            _26791 = (object)*(((s1_ptr)_2)->base + _i_52555);
            Ref(_26791);
            _47emit_addr(_26791);
            _26791 = NOVALUE;

            /** emit.e:1129				end for*/
            _i_52555 = _i_52555 + 1;
            goto L5A; // [3261] 3250
L5B: 
            ;
        }

        /** emit.e:1130				c = NewTempSym()*/
        _c_51878 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1131				emit_addr(c)*/
        _47emit_addr(_c_51878);

        /** emit.e:1132				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_51878, 1);

        /** emit.e:1133				assignable = TRUE*/
        _47assignable_50954 = _13TRUE_452;
L57: 

        /** emit.e:1135			Push(c)*/
        _47Push(_c_51878);
        goto LC; // [3298] 7739

        /** emit.e:1138		case ASSIGN_SUBS2,      -- can't change the op*/
        case 148:
        case 16:
        case 162:

        /** emit.e:1141			b = Pop() -- rhs value*/
        _b_51877 = _47Pop();
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:1142			a = Pop() -- subscript*/
        _a_51876 = _47Pop();
        if (!IS_ATOM_INT(_a_51876)) {
            _1 = (object)(DBL_PTR(_a_51876)->dbl);
            DeRefDS(_a_51876);
            _a_51876 = _1;
        }

        /** emit.e:1143			c = Pop() -- sequence*/
        _c_51878 = _47Pop();
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1144			if op = ASSIGN_SUBS then*/
        if (_op_51874 != 16)
        goto L5C; // [3333] 3525

        /** emit.e:1146				if (previous_op != LHS_SUBS) and*/
        _26797 = (_36previous_op_21549 != 95);
        if (_26797 == 0) {
            _26798 = 0;
            goto L5D; // [3347] 3359
        }
        _26799 = (_c_51878 > 0);
        _26798 = (_26799 != 0);
L5D: 
        if (_26798 == 0) {
            goto L5E; // [3359] 3497
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26801 = (object)*(((s1_ptr)_2)->base + _c_51878);
        _2 = (object)SEQ_PTR(_26801);
        _26802 = (object)*(((s1_ptr)_2)->base + 3);
        _26801 = NOVALUE;
        if (IS_ATOM_INT(_26802)) {
            _26803 = (_26802 != 1);
        }
        else {
            _26803 = binary_op(NOTEQ, _26802, 1);
        }
        _26802 = NOVALUE;
        if (IS_ATOM_INT(_26803)) {
            if (_26803 != 0) {
                DeRef(_26804);
                _26804 = 1;
                goto L5F; // [3381] 3481
            }
        }
        else {
            if (DBL_PTR(_26803)->dbl != 0.0) {
                DeRef(_26804);
                _26804 = 1;
                goto L5F; // [3381] 3481
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26805 = (object)*(((s1_ptr)_2)->base + _c_51878);
        _2 = (object)SEQ_PTR(_26805);
        _26806 = (object)*(((s1_ptr)_2)->base + 15);
        _26805 = NOVALUE;
        if (IS_ATOM_INT(_26806)) {
            _26807 = (_26806 != _54sequence_type_46784);
        }
        else {
            _26807 = binary_op(NOTEQ, _26806, _54sequence_type_46784);
        }
        _26806 = NOVALUE;
        if (IS_ATOM_INT(_26807)) {
            if (_26807 == 0) {
                DeRef(_26808);
                _26808 = 0;
                goto L60; // [3403] 3477
            }
        }
        else {
            if (DBL_PTR(_26807)->dbl == 0.0) {
                DeRef(_26808);
                _26808 = 0;
                goto L60; // [3403] 3477
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26809 = (object)*(((s1_ptr)_2)->base + _c_51878);
        _2 = (object)SEQ_PTR(_26809);
        _26810 = (object)*(((s1_ptr)_2)->base + 15);
        _26809 = NOVALUE;
        if (IS_ATOM_INT(_26810)) {
            _26811 = (_26810 > 0);
        }
        else {
            _26811 = binary_op(GREATER, _26810, 0);
        }
        _26810 = NOVALUE;
        if (IS_ATOM_INT(_26811)) {
            if (_26811 == 0) {
                DeRef(_26812);
                _26812 = 0;
                goto L61; // [3423] 3473
            }
        }
        else {
            if (DBL_PTR(_26811)->dbl == 0.0) {
                DeRef(_26812);
                _26812 = 0;
                goto L61; // [3423] 3473
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26813 = (object)*(((s1_ptr)_2)->base + _c_51878);
        _2 = (object)SEQ_PTR(_26813);
        _26814 = (object)*(((s1_ptr)_2)->base + 15);
        _26813 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_26814)){
            _26815 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26814)->dbl));
        }
        else{
            _26815 = (object)*(((s1_ptr)_2)->base + _26814);
        }
        _2 = (object)SEQ_PTR(_26815);
        _26816 = (object)*(((s1_ptr)_2)->base + 2);
        _26815 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_26816)){
            _26817 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26816)->dbl));
        }
        else{
            _26817 = (object)*(((s1_ptr)_2)->base + _26816);
        }
        _2 = (object)SEQ_PTR(_26817);
        _26818 = (object)*(((s1_ptr)_2)->base + 15);
        _26817 = NOVALUE;
        if (IS_ATOM_INT(_26818)) {
            _26819 = (_26818 != _54sequence_type_46784);
        }
        else {
            _26819 = binary_op(NOTEQ, _26818, _54sequence_type_46784);
        }
        _26818 = NOVALUE;
        DeRef(_26812);
        if (IS_ATOM_INT(_26819))
        _26812 = (_26819 != 0);
        else
        _26812 = DBL_PTR(_26819)->dbl != 0.0;
L61: 
        DeRef(_26808);
        _26808 = (_26812 != 0);
L60: 
        DeRef(_26804);
        _26804 = (_26808 != 0);
L5F: 
        if (_26804 == 0)
        {
            _26804 = NOVALUE;
            goto L5E; // [3482] 3497
        }
        else{
            _26804 = NOVALUE;
        }

        /** emit.e:1153					op = ASSIGN_SUBS_CHECK*/
        _op_51874 = 84;
        goto L62; // [3494] 3517
L5E: 

        /** emit.e:1155					if IsInteger(b) then*/
        _26820 = _47IsInteger(_b_51877);
        if (_26820 == 0) {
            DeRef(_26820);
            _26820 = NOVALUE;
            goto L63; // [3503] 3516
        }
        else {
            if (!IS_ATOM_INT(_26820) && DBL_PTR(_26820)->dbl == 0.0){
                DeRef(_26820);
                _26820 = NOVALUE;
                goto L63; // [3503] 3516
            }
            DeRef(_26820);
            _26820 = NOVALUE;
        }
        DeRef(_26820);
        _26820 = NOVALUE;

        /** emit.e:1156						op = ASSIGN_SUBS_I*/
        _op_51874 = 118;
L63: 
L62: 

        /** emit.e:1159				emit_opcode(op)*/
        _47emit_opcode(_op_51874);
        goto L64; // [3522] 3551
L5C: 

        /** emit.e:1161			elsif op = PASSIGN_SUBS then*/
        if (_op_51874 != 162)
        goto L65; // [3529] 3543

        /** emit.e:1162				emit_opcode(PASSIGN_SUBS) -- always*/
        _47emit_opcode(162);
        goto L64; // [3540] 3551
L65: 

        /** emit.e:1165				emit_opcode(ASSIGN_SUBS) -- always*/
        _47emit_opcode(16);
L64: 

        /** emit.e:1169			emit_addr(c) -- sequence*/
        _47emit_addr(_c_51878);

        /** emit.e:1170			emit_addr(a) -- subscript*/
        _47emit_addr(_a_51876);

        /** emit.e:1171			emit_addr(b) -- rhs value*/
        _47emit_addr(_b_51877);

        /** emit.e:1172			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [3573] 7739

        /** emit.e:1174		case LHS_SUBS, LHS_SUBS1, LHS_SUBS1_COPY then*/
        case 95:
        case 161:
        case 166:

        /** emit.e:1176			a = Pop() -- subs*/
        _a_51876 = _47Pop();
        if (!IS_ATOM_INT(_a_51876)) {
            _1 = (object)(DBL_PTR(_a_51876)->dbl);
            DeRefDS(_a_51876);
            _a_51876 = _1;
        }

        /** emit.e:1177			lhs_var = Pop() -- sequence*/
        _lhs_var_51884 = _47Pop();
        if (!IS_ATOM_INT(_lhs_var_51884)) {
            _1 = (object)(DBL_PTR(_lhs_var_51884)->dbl);
            DeRefDS(_lhs_var_51884);
            _lhs_var_51884 = _1;
        }

        /** emit.e:1178			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1179			emit_addr(lhs_var)*/
        _47emit_addr(_lhs_var_51884);

        /** emit.e:1180			emit_addr(a)*/
        _47emit_addr(_a_51876);

        /** emit.e:1181			if op = LHS_SUBS then*/
        if (_op_51874 != 95)
        goto L66; // [3616] 3647

        /** emit.e:1182				TempKeep(lhs_var) -- should be lhs_target_temp*/
        _47TempKeep(_lhs_var_51884);

        /** emit.e:1183				emit_addr(lhs_target_temp)*/
        _47emit_addr(_47lhs_target_temp_50950);

        /** emit.e:1184				Push(lhs_target_temp)*/
        _47Push(_47lhs_target_temp_50950);

        /** emit.e:1185				emit_addr(0) -- place holder*/
        _47emit_addr(0);
        goto L67; // [3644] 3701
L66: 

        /** emit.e:1189				lhs_target_temp = NewTempSym() -- use same temp for all subscripts*/
        _0 = _54NewTempSym(0);
        _47lhs_target_temp_50950 = _0;
        if (!IS_ATOM_INT(_47lhs_target_temp_50950)) {
            _1 = (object)(DBL_PTR(_47lhs_target_temp_50950)->dbl);
            DeRefDS(_47lhs_target_temp_50950);
            _47lhs_target_temp_50950 = _1;
        }

        /** emit.e:1190				emit_addr(lhs_target_temp) -- target temp holds pointer to sequence*/
        _47emit_addr(_47lhs_target_temp_50950);

        /** emit.e:1191				emit_temp(lhs_target_temp, NEW_REFERENCE )*/
        _47emit_temp(_47lhs_target_temp_50950, 1);

        /** emit.e:1192				Push(lhs_target_temp)*/
        _47Push(_47lhs_target_temp_50950);

        /** emit.e:1193				lhs_subs1_copy_temp = NewTempSym() -- place to copy (may be ignored)*/
        _0 = _54NewTempSym(0);
        _47lhs_subs1_copy_temp_50949 = _0;
        if (!IS_ATOM_INT(_47lhs_subs1_copy_temp_50949)) {
            _1 = (object)(DBL_PTR(_47lhs_subs1_copy_temp_50949)->dbl);
            DeRefDS(_47lhs_subs1_copy_temp_50949);
            _47lhs_subs1_copy_temp_50949 = _1;
        }

        /** emit.e:1194				emit_addr(lhs_subs1_copy_temp)*/
        _47emit_addr(_47lhs_subs1_copy_temp_50949);

        /** emit.e:1195				emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
        _47emit_temp(_47lhs_subs1_copy_temp_50949, 1);
L67: 

        /** emit.e:1198			current_sequence = append(current_sequence, lhs_target_temp)*/
        Append(&_47current_sequence_50944, _47current_sequence_50944, _47lhs_target_temp_50950);

        /** emit.e:1199			assignable = FALSE  -- need to update current_sequence like in RHS_SUBS*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [3718] 7739

        /** emit.e:1201		case PEEK_LONGS then*/
        case 436:

        /** emit.e:1202			if IWINDOWS or TWINDOWS or not (IX86_64 or TX86_64) then*/
        if (_46IWINDOWS_21593 != 0) {
            _26828 = 1;
            goto L68; // [3728] 3738
        }
        _26828 = (_46TWINDOWS_21594 != 0);
L68: 
        if (_26828 != 0) {
            goto L69; // [3738] 3762
        }
        if (_46IX86_64_21609 != 0) {
            DeRef(_26830);
            _26830 = 1;
            goto L6A; // [3744] 3754
        }
        _26830 = (_46TX86_64_21610 != 0);
L6A: 
        _26831 = (_26830 == 0);
        _26830 = NOVALUE;
        if (_26831 == 0)
        {
            DeRef(_26831);
            _26831 = NOVALUE;
            goto L6B; // [3758] 3774
        }
        else{
            DeRef(_26831);
            _26831 = NOVALUE;
        }
L69: 

        /** emit.e:1203				op = PEEK4S*/
        _op_51874 = 139;
        goto L6C; // [3771] 3784
L6B: 

        /** emit.e:1205				op = PEEK8S*/
        _op_51874 = 213;
L6C: 

        /** emit.e:1207			last_op = op*/
        _47last_op_51833 = _op_51874;

        /** emit.e:1208			cont11ii(op, TRUE )*/
        _47cont11ii(_op_51874, _13TRUE_452);
        goto LC; // [3797] 7739

        /** emit.e:1210		case PEEK_LONGU then*/
        case 435:

        /** emit.e:1211			if IWINDOWS or TWINDOWS or not (IX86_64 or TX86_64) then*/
        if (_46IWINDOWS_21593 != 0) {
            _26832 = 1;
            goto L6D; // [3807] 3817
        }
        _26832 = (_46TWINDOWS_21594 != 0);
L6D: 
        if (_26832 != 0) {
            goto L6E; // [3817] 3841
        }
        if (_46IX86_64_21609 != 0) {
            DeRef(_26834);
            _26834 = 1;
            goto L6F; // [3823] 3833
        }
        _26834 = (_46TX86_64_21610 != 0);
L6F: 
        _26835 = (_26834 == 0);
        _26834 = NOVALUE;
        if (_26835 == 0)
        {
            DeRef(_26835);
            _26835 = NOVALUE;
            goto L70; // [3837] 3853
        }
        else{
            DeRef(_26835);
            _26835 = NOVALUE;
        }
L6E: 

        /** emit.e:1212				op = PEEK4U*/
        _op_51874 = 140;
        goto L71; // [3850] 3863
L70: 

        /** emit.e:1214				op = PEEK8U*/
        _op_51874 = 214;
L71: 

        /** emit.e:1216			last_op = op*/
        _47last_op_51833 = _op_51874;

        /** emit.e:1217			cont11ii(op, TRUE )*/
        _47cont11ii(_op_51874, _13TRUE_452);
        goto LC; // [3876] 7739

        /** emit.e:1220		case RAND, PEEK, PEEK4S, PEEK4U, NOT_BITS, NOT, PEEK8U, PEEK8S, SIZEOF,*/
        case 62:
        case 127:
        case 139:
        case 140:
        case 51:
        case 7:
        case 214:
        case 213:
        case 217:
        case 173:
        case 180:
        case 179:
        case 181:
        case 182:
        case 216:

        /** emit.e:1222			cont11ii(op, TRUE)*/
        _47cont11ii(_op_51874, _13TRUE_452);
        goto LC; // [3918] 7739

        /** emit.e:1224		case UMINUS then*/
        case 12:

        /** emit.e:1226			a = Pop()*/
        _a_51876 = _47Pop();
        if (!IS_ATOM_INT(_a_51876)) {
            _1 = (object)(DBL_PTR(_a_51876)->dbl);
            DeRefDS(_a_51876);
            _a_51876 = _1;
        }

        /** emit.e:1228			if a > 0 then*/
        if (_a_51876 <= 0)
        goto L72; // [3933] 4180

        /** emit.e:1229				obj = SymTab[a][S_OBJ]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26838 = (object)*(((s1_ptr)_2)->base + _a_51876);
        DeRef(_obj_51888);
        _2 = (object)SEQ_PTR(_26838);
        _obj_51888 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_obj_51888);
        _26838 = NOVALUE;

        /** emit.e:1230				if SymTab[a][S_MODE] = M_CONSTANT then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26840 = (object)*(((s1_ptr)_2)->base + _a_51876);
        _2 = (object)SEQ_PTR(_26840);
        _26841 = (object)*(((s1_ptr)_2)->base + 3);
        _26840 = NOVALUE;
        if (binary_op_a(NOTEQ, _26841, 2)){
            _26841 = NOVALUE;
            goto L73; // [3967] 4092
        }
        _26841 = NOVALUE;

        /** emit.e:1231					if is_integer(obj) then*/
        Ref(_obj_51888);
        _26843 = _36is_integer(_obj_51888);
        if (_26843 == 0) {
            DeRef(_26843);
            _26843 = NOVALUE;
            goto L74; // [3977] 4031
        }
        else {
            if (!IS_ATOM_INT(_26843) && DBL_PTR(_26843)->dbl == 0.0){
                DeRef(_26843);
                _26843 = NOVALUE;
                goto L74; // [3977] 4031
            }
            DeRef(_26843);
            _26843 = NOVALUE;
        }
        DeRef(_26843);
        _26843 = NOVALUE;

        /** emit.e:1232						if obj = MININT then*/
        if (binary_op_a(NOTEQ, _obj_51888, -1073741824)){
            goto L75; // [3984] 4005
        }

        /** emit.e:1233							Push(NewDoubleSym(-MININT))*/
        if ((uintptr_t)-1073741824 == (uintptr_t)HIGH_BITS){
            _26845 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _26845 = - -1073741824;
        }
        _26846 = _54NewDoubleSym(_26845);
        _26845 = NOVALUE;
        _47Push(_26846);
        _26846 = NOVALUE;
        goto L76; // [4002] 4018
L75: 

        /** emit.e:1235							Push(NewIntSym(-obj))*/
        if (IS_ATOM_INT(_obj_51888)) {
            if ((uintptr_t)_obj_51888 == (uintptr_t)HIGH_BITS){
                _26847 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _26847 = - _obj_51888;
            }
        }
        else {
            _26847 = unary_op(UMINUS, _obj_51888);
        }
        _26848 = _54NewIntSym(_26847);
        _26847 = NOVALUE;
        _47Push(_26848);
        _26848 = NOVALUE;
L76: 

        /** emit.e:1237						last_pc = last_pc_backup*/
        _47last_pc_51834 = _last_pc_backup_51891;

        /** emit.e:1238						last_op = last_op_backup*/
        _47last_op_51833 = _last_op_backup_51892;
        goto LC; // [4028] 7739
L74: 

        /** emit.e:1240					elsif atom(obj) and obj != NOVALUE then*/
        _26849 = IS_ATOM(_obj_51888);
        if (_26849 == 0) {
            goto L77; // [4036] 4075
        }
        if (IS_ATOM_INT(_obj_51888) && IS_ATOM_INT(_36NOVALUE_21301)) {
            _26851 = (_obj_51888 != _36NOVALUE_21301);
        }
        else {
            _26851 = binary_op(NOTEQ, _obj_51888, _36NOVALUE_21301);
        }
        if (_26851 == 0) {
            DeRef(_26851);
            _26851 = NOVALUE;
            goto L77; // [4047] 4075
        }
        else {
            if (!IS_ATOM_INT(_26851) && DBL_PTR(_26851)->dbl == 0.0){
                DeRef(_26851);
                _26851 = NOVALUE;
                goto L77; // [4047] 4075
            }
            DeRef(_26851);
            _26851 = NOVALUE;
        }
        DeRef(_26851);
        _26851 = NOVALUE;

        /** emit.e:1245						Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_51888)) {
            if ((uintptr_t)_obj_51888 == (uintptr_t)HIGH_BITS){
                _26852 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _26852 = - _obj_51888;
            }
        }
        else {
            _26852 = unary_op(UMINUS, _obj_51888);
        }
        _26853 = _54NewDoubleSym(_26852);
        _26852 = NOVALUE;
        _47Push(_26853);
        _26853 = NOVALUE;

        /** emit.e:1246						last_pc = last_pc_backup*/
        _47last_pc_51834 = _last_pc_backup_51891;

        /** emit.e:1247						last_op = last_op_backup*/
        _47last_op_51833 = _last_op_backup_51892;
        goto LC; // [4072] 7739
L77: 

        /** emit.e:1250						Push(a)*/
        _47Push(_a_51876);

        /** emit.e:1251						cont11ii(op, FALSE)*/
        _47cont11ii(_op_51874, _13FALSE_450);
        goto LC; // [4089] 7739
L73: 

        /** emit.e:1254				elsif TRANSLATE and SymTab[a][S_MODE] = M_TEMP and*/
        if (_36TRANSLATE_21049 == 0) {
            _26854 = 0;
            goto L78; // [4096] 4122
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26855 = (object)*(((s1_ptr)_2)->base + _a_51876);
        _2 = (object)SEQ_PTR(_26855);
        _26856 = (object)*(((s1_ptr)_2)->base + 3);
        _26855 = NOVALUE;
        if (IS_ATOM_INT(_26856)) {
            _26857 = (_26856 == 3);
        }
        else {
            _26857 = binary_op(EQUALS, _26856, 3);
        }
        _26856 = NOVALUE;
        if (IS_ATOM_INT(_26857))
        _26854 = (_26857 != 0);
        else
        _26854 = DBL_PTR(_26857)->dbl != 0.0;
L78: 
        if (_26854 == 0) {
            goto L79; // [4122] 4163
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26859 = (object)*(((s1_ptr)_2)->base + _a_51876);
        _2 = (object)SEQ_PTR(_26859);
        _26860 = (object)*(((s1_ptr)_2)->base + 36);
        _26859 = NOVALUE;
        if (IS_ATOM_INT(_26860)) {
            _26861 = (_26860 == 2);
        }
        else {
            _26861 = binary_op(EQUALS, _26860, 2);
        }
        _26860 = NOVALUE;
        if (_26861 == 0) {
            DeRef(_26861);
            _26861 = NOVALUE;
            goto L79; // [4145] 4163
        }
        else {
            if (!IS_ATOM_INT(_26861) && DBL_PTR(_26861)->dbl == 0.0){
                DeRef(_26861);
                _26861 = NOVALUE;
                goto L79; // [4145] 4163
            }
            DeRef(_26861);
            _26861 = NOVALUE;
        }
        DeRef(_26861);
        _26861 = NOVALUE;

        /** emit.e:1256					Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_51888)) {
            if ((uintptr_t)_obj_51888 == (uintptr_t)HIGH_BITS){
                _26862 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _26862 = - _obj_51888;
            }
        }
        else {
            _26862 = unary_op(UMINUS, _obj_51888);
        }
        _26863 = _54NewDoubleSym(_26862);
        _26862 = NOVALUE;
        _47Push(_26863);
        _26863 = NOVALUE;
        goto LC; // [4160] 7739
L79: 

        /** emit.e:1259					Push(a)*/
        _47Push(_a_51876);

        /** emit.e:1260					cont11ii(op, FALSE)*/
        _47cont11ii(_op_51874, _13FALSE_450);
        goto LC; // [4177] 7739
L72: 

        /** emit.e:1263				Push(a)*/
        _47Push(_a_51876);

        /** emit.e:1264				cont11ii(op, FALSE)*/
        _47cont11ii(_op_51874, _13FALSE_450);
        goto LC; // [4194] 7739

        /** emit.e:1267		case LENGTH, GETC, SQRT, SIN, COS, TAN, ARCTAN, LOG, GETS, GETENV then*/
        case 42:
        case 33:
        case 41:
        case 80:
        case 81:
        case 82:
        case 73:
        case 74:
        case 17:
        case 91:

        /** emit.e:1268			cont11ii(op, FALSE)*/
        _47cont11ii(_op_51874, _13FALSE_450);
        goto LC; // [4226] 7739

        /** emit.e:1270		case IS_AN_INTEGER, IS_AN_ATOM, IS_A_SEQUENCE, IS_AN_OBJECT then*/
        case 94:
        case 67:
        case 68:
        case 40:

        /** emit.e:1271			cont11ii(op, FALSE)*/
        _47cont11ii(_op_51874, _13FALSE_450);
        goto LC; // [4246] 7739

        /** emit.e:1275		case ROUTINE_ID then*/
        case 134:

        /** emit.e:1276			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1277			source = Pop()*/
        _source_51880 = _47Pop();
        if (!IS_ATOM_INT(_source_51880)) {
            _1 = (object)(DBL_PTR(_source_51880)->dbl);
            DeRefDS(_source_51880);
            _source_51880 = _1;
        }

        /** emit.e:1278			if TRANSLATE then*/
        if (_36TRANSLATE_21049 == 0)
        {
            goto L7A; // [4268] 4312
        }
        else{
        }

        /** emit.e:1279				emit_addr(num_routines-1)*/
        _26865 = _36num_routines_21456 - 1;
        if ((object)((uintptr_t)_26865 +(uintptr_t) HIGH_BITS) >= 0){
            _26865 = NewDouble((eudouble)_26865);
        }
        _47emit_addr(_26865);
        _26865 = NOVALUE;

        /** emit.e:1280				last_routine_id = num_routines*/
        _47last_routine_id_50941 = _36num_routines_21456;

        /** emit.e:1281				last_max_params = max_params*/
        _47last_max_params_50943 = _47max_params_50942;

        /** emit.e:1282				MarkTargets(source, S_RI_TARGET)*/
        _31702 = _54MarkTargets(_source_51880, 53);
        DeRef(_31702);
        _31702 = NOVALUE;
        goto L7B; // [4309] 4349
L7A: 

        /** emit.e:1285				emit_addr(CurrentSub)*/
        _47emit_addr(_36CurrentSub_21455);

        /** emit.e:1286				emit_addr(length(SymTab))*/
        if (IS_SEQUENCE(_37SymTab_15406)){
                _26866 = SEQ_PTR(_37SymTab_15406)->length;
        }
        else {
            _26866 = 1;
        }
        _47emit_addr(_26866);
        _26866 = NOVALUE;

        /** emit.e:1288				if BIND then*/
        if (_36BIND_21052 == 0)
        {
            goto L7C; // [4333] 4348
        }
        else{
        }

        /** emit.e:1290					MarkTargets(source, S_NREFS)*/
        _31701 = _54MarkTargets(_source_51880, 12);
        DeRef(_31701);
        _31701 = NOVALUE;
L7C: 
L7B: 

        /** emit.e:1294			emit_addr(source)*/
        _47emit_addr(_source_51880);

        /** emit.e:1295			emit_addr(current_file_no)  -- necessary at top level*/
        _47emit_addr(_36current_file_no_21447);

        /** emit.e:1296			assignable = TRUE*/
        _47assignable_50954 = _13TRUE_452;

        /** emit.e:1297			c = NewTempSym()*/
        _c_51878 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1298			TempInteger(c) -- result will always be an integer*/
        _47TempInteger(_c_51878);

        /** emit.e:1299			Push(c)*/
        _47Push(_c_51878);

        /** emit.e:1300			emit_addr(c)*/
        _47emit_addr(_c_51878);
        goto LC; // [4391] 7739

        /** emit.e:1305		case SC1_OR, SC1_AND then*/
        case 143:
        case 141:

        /** emit.e:1306			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1307			emit_addr(Pop())*/
        _26868 = _47Pop();
        _47emit_addr(_26868);
        _26868 = NOVALUE;

        /** emit.e:1308			c = NewTempSym()*/
        _c_51878 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1309			Push(c)*/
        _47Push(_c_51878);

        /** emit.e:1310			emit_addr(c)*/
        _47emit_addr(_c_51878);

        /** emit.e:1311			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [4437] 7739

        /** emit.e:1315		case POKE_LONG then*/
        case 434:

        /** emit.e:1316			if IWINDOWS or TWINDOWS or not (IX86_64 or TX86_64) then*/
        if (_46IWINDOWS_21593 != 0) {
            _26870 = 1;
            goto L7D; // [4447] 4457
        }
        _26870 = (_46TWINDOWS_21594 != 0);
L7D: 
        if (_26870 != 0) {
            goto L7E; // [4457] 4481
        }
        if (_46IX86_64_21609 != 0) {
            DeRef(_26872);
            _26872 = 1;
            goto L7F; // [4463] 4473
        }
        _26872 = (_46TX86_64_21610 != 0);
L7F: 
        _26873 = (_26872 == 0);
        _26872 = NOVALUE;
        if (_26873 == 0)
        {
            DeRef(_26873);
            _26873 = NOVALUE;
            goto L80; // [4477] 4493
        }
        else{
            DeRef(_26873);
            _26873 = NOVALUE;
        }
L7E: 

        /** emit.e:1317				op = POKE4*/
        _op_51874 = 138;
        goto L81; // [4490] 4503
L80: 

        /** emit.e:1319				op = POKE8*/
        _op_51874 = 212;
L81: 

        /** emit.e:1321			last_op = op*/
        _47last_op_51833 = _op_51874;

        /** emit.e:1324		case SYSTEM, PUTS, PRINT, QPRINT, POSITION, MACHINE_PROC,*/
        case 99:
        case 44:
        case 19:
        case 36:
        case 60:
        case 112:
        case 132:
        case 128:
        case 138:
        case 168:
        case 178:
        case 212:
        case 215:

        /** emit.e:1326			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1328			b = Pop()*/
        _b_51877 = _47Pop();
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:1329			emit_addr(Pop())*/
        _26875 = _47Pop();
        _47emit_addr(_26875);
        _26875 = NOVALUE;

        /** emit.e:1330			emit_addr(b)*/
        _47emit_addr(_b_51877);

        /** emit.e:1331			if op = C_PROC then*/
        if (_op_51874 != 132)
        goto L82; // [4565] 4577

        /** emit.e:1332				emit_addr(CurrentSub)*/
        _47emit_addr(_36CurrentSub_21455);
L82: 

        /** emit.e:1334			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [4584] 7739

        /** emit.e:1337		case EQUALS, LESS, GREATER, NOTEQ, LESSEQ, GREATEREQ,*/
        case 3:
        case 1:
        case 6:
        case 4:
        case 5:
        case 2:
        case 8:
        case 9:
        case 152:
        case 71:
        case 56:
        case 24:
        case 26:

        /** emit.e:1339			cont21ii(op, TRUE)  -- both integer args => integer result*/
        _47cont21ii(_op_51874, _13TRUE_452);
        goto LC; // [4622] 7739

        /** emit.e:1341		case PLUS then -- elsif op = PLUS then*/
        case 11:

        /** emit.e:1343			b = Pop()*/
        _b_51877 = _47Pop();
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:1344			a = Pop()*/
        _a_51876 = _47Pop();
        if (!IS_ATOM_INT(_a_51876)) {
            _1 = (object)(DBL_PTR(_a_51876)->dbl);
            DeRefDS(_a_51876);
            _a_51876 = _1;
        }

        /** emit.e:1346			if b < 1 or a < 1 then*/
        _26879 = (_b_51877 < 1);
        if (_26879 != 0) {
            goto L83; // [4648] 4661
        }
        _26881 = (_a_51876 < 1);
        if (_26881 == 0)
        {
            DeRef(_26881);
            _26881 = NOVALUE;
            goto L84; // [4657] 4682
        }
        else{
            DeRef(_26881);
            _26881 = NOVALUE;
        }
L83: 

        /** emit.e:1347				Push(a)*/
        _47Push(_a_51876);

        /** emit.e:1348				Push(b)*/
        _47Push(_b_51877);

        /** emit.e:1349				cont21ii(op, FALSE)*/
        _47cont21ii(_op_51874, _13FALSE_450);
        goto LC; // [4679] 7739
L84: 

        /** emit.e:1350			elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 1) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26882 = (object)*(((s1_ptr)_2)->base + _b_51877);
        _2 = (object)SEQ_PTR(_26882);
        _26883 = (object)*(((s1_ptr)_2)->base + 3);
        _26882 = NOVALUE;
        if (IS_ATOM_INT(_26883)) {
            _26884 = (_26883 == 2);
        }
        else {
            _26884 = binary_op(EQUALS, _26883, 2);
        }
        _26883 = NOVALUE;
        if (IS_ATOM_INT(_26884)) {
            if (_26884 == 0) {
                goto L85; // [4702] 4763
            }
        }
        else {
            if (DBL_PTR(_26884)->dbl == 0.0) {
                goto L85; // [4702] 4763
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26886 = (object)*(((s1_ptr)_2)->base + _b_51877);
        _2 = (object)SEQ_PTR(_26886);
        _26887 = (object)*(((s1_ptr)_2)->base + 1);
        _26886 = NOVALUE;
        if (_26887 == 1)
        _26888 = 1;
        else if (IS_ATOM_INT(_26887) && IS_ATOM_INT(1))
        _26888 = 0;
        else
        _26888 = (compare(_26887, 1) == 0);
        _26887 = NOVALUE;
        if (_26888 == 0)
        {
            _26888 = NOVALUE;
            goto L85; // [4723] 4763
        }
        else{
            _26888 = NOVALUE;
        }

        /** emit.e:1351				op = PLUS1*/
        _op_51874 = 93;

        /** emit.e:1352				emit_opcode(op)*/
        _47emit_opcode(93);

        /** emit.e:1353				emit_addr(a)*/
        _47emit_addr(_a_51876);

        /** emit.e:1354				emit_addr(0)*/
        _47emit_addr(0);

        /** emit.e:1355				cont21d(op, a, b, FALSE)*/
        _47cont21d(93, _a_51876, _b_51877, _13FALSE_450);
        goto LC; // [4760] 7739
L85: 

        /** emit.e:1356			elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 1) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26889 = (object)*(((s1_ptr)_2)->base + _a_51876);
        _2 = (object)SEQ_PTR(_26889);
        _26890 = (object)*(((s1_ptr)_2)->base + 3);
        _26889 = NOVALUE;
        if (IS_ATOM_INT(_26890)) {
            _26891 = (_26890 == 2);
        }
        else {
            _26891 = binary_op(EQUALS, _26890, 2);
        }
        _26890 = NOVALUE;
        if (IS_ATOM_INT(_26891)) {
            if (_26891 == 0) {
                goto L86; // [4783] 4844
            }
        }
        else {
            if (DBL_PTR(_26891)->dbl == 0.0) {
                goto L86; // [4783] 4844
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26893 = (object)*(((s1_ptr)_2)->base + _a_51876);
        _2 = (object)SEQ_PTR(_26893);
        _26894 = (object)*(((s1_ptr)_2)->base + 1);
        _26893 = NOVALUE;
        if (_26894 == 1)
        _26895 = 1;
        else if (IS_ATOM_INT(_26894) && IS_ATOM_INT(1))
        _26895 = 0;
        else
        _26895 = (compare(_26894, 1) == 0);
        _26894 = NOVALUE;
        if (_26895 == 0)
        {
            _26895 = NOVALUE;
            goto L86; // [4804] 4844
        }
        else{
            _26895 = NOVALUE;
        }

        /** emit.e:1357				op = PLUS1*/
        _op_51874 = 93;

        /** emit.e:1358				emit_opcode(op)*/
        _47emit_opcode(93);

        /** emit.e:1359				emit_addr(b)*/
        _47emit_addr(_b_51877);

        /** emit.e:1360				emit_addr(0)*/
        _47emit_addr(0);

        /** emit.e:1361				cont21d(op, a, b, FALSE)*/
        _47cont21d(93, _a_51876, _b_51877, _13FALSE_450);
        goto LC; // [4841] 7739
L86: 

        /** emit.e:1363				Push(a)*/
        _47Push(_a_51876);

        /** emit.e:1364				Push(b)*/
        _47Push(_b_51877);

        /** emit.e:1365				cont21ii(op, FALSE)*/
        _47cont21ii(_op_51874, _13FALSE_450);
        goto LC; // [4863] 7739

        /** emit.e:1368		case rw:MULTIPLY then*/
        case 13:

        /** emit.e:1370			b = Pop()*/
        _b_51877 = _47Pop();
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:1371			a = Pop()*/
        _a_51876 = _47Pop();
        if (!IS_ATOM_INT(_a_51876)) {
            _1 = (object)(DBL_PTR(_a_51876)->dbl);
            DeRefDS(_a_51876);
            _a_51876 = _1;
        }

        /** emit.e:1372			if a < 1 or b < 1 then*/
        _26898 = (_a_51876 < 1);
        if (_26898 != 0) {
            goto L87; // [4889] 4902
        }
        _26900 = (_b_51877 < 1);
        if (_26900 == 0)
        {
            DeRef(_26900);
            _26900 = NOVALUE;
            goto L88; // [4898] 4923
        }
        else{
            DeRef(_26900);
            _26900 = NOVALUE;
        }
L87: 

        /** emit.e:1373				Push(a)*/
        _47Push(_a_51876);

        /** emit.e:1374				Push(b)*/
        _47Push(_b_51877);

        /** emit.e:1375				cont21ii(op, FALSE)*/
        _47cont21ii(_op_51874, _13FALSE_450);
        goto LC; // [4920] 7739
L88: 

        /** emit.e:1377			elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26901 = (object)*(((s1_ptr)_2)->base + _b_51877);
        _2 = (object)SEQ_PTR(_26901);
        _26902 = (object)*(((s1_ptr)_2)->base + 3);
        _26901 = NOVALUE;
        if (IS_ATOM_INT(_26902)) {
            _26903 = (_26902 == 2);
        }
        else {
            _26903 = binary_op(EQUALS, _26902, 2);
        }
        _26902 = NOVALUE;
        if (IS_ATOM_INT(_26903)) {
            if (_26903 == 0) {
                goto L89; // [4943] 5004
            }
        }
        else {
            if (DBL_PTR(_26903)->dbl == 0.0) {
                goto L89; // [4943] 5004
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26905 = (object)*(((s1_ptr)_2)->base + _b_51877);
        _2 = (object)SEQ_PTR(_26905);
        _26906 = (object)*(((s1_ptr)_2)->base + 1);
        _26905 = NOVALUE;
        if (_26906 == 2)
        _26907 = 1;
        else if (IS_ATOM_INT(_26906) && IS_ATOM_INT(2))
        _26907 = 0;
        else
        _26907 = (compare(_26906, 2) == 0);
        _26906 = NOVALUE;
        if (_26907 == 0)
        {
            _26907 = NOVALUE;
            goto L89; // [4964] 5004
        }
        else{
            _26907 = NOVALUE;
        }

        /** emit.e:1379				op = PLUS*/
        _op_51874 = 11;

        /** emit.e:1380				emit_opcode(op)*/
        _47emit_opcode(11);

        /** emit.e:1381				emit_addr(a)*/
        _47emit_addr(_a_51876);

        /** emit.e:1382				emit_addr(a)*/
        _47emit_addr(_a_51876);

        /** emit.e:1383				cont21d(op, a, b, FALSE)*/
        _47cont21d(11, _a_51876, _b_51877, _13FALSE_450);
        goto LC; // [5001] 7739
L89: 

        /** emit.e:1385			elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 2) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26908 = (object)*(((s1_ptr)_2)->base + _a_51876);
        _2 = (object)SEQ_PTR(_26908);
        _26909 = (object)*(((s1_ptr)_2)->base + 3);
        _26908 = NOVALUE;
        if (IS_ATOM_INT(_26909)) {
            _26910 = (_26909 == 2);
        }
        else {
            _26910 = binary_op(EQUALS, _26909, 2);
        }
        _26909 = NOVALUE;
        if (IS_ATOM_INT(_26910)) {
            if (_26910 == 0) {
                goto L8A; // [5024] 5085
            }
        }
        else {
            if (DBL_PTR(_26910)->dbl == 0.0) {
                goto L8A; // [5024] 5085
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26912 = (object)*(((s1_ptr)_2)->base + _a_51876);
        _2 = (object)SEQ_PTR(_26912);
        _26913 = (object)*(((s1_ptr)_2)->base + 1);
        _26912 = NOVALUE;
        if (_26913 == 2)
        _26914 = 1;
        else if (IS_ATOM_INT(_26913) && IS_ATOM_INT(2))
        _26914 = 0;
        else
        _26914 = (compare(_26913, 2) == 0);
        _26913 = NOVALUE;
        if (_26914 == 0)
        {
            _26914 = NOVALUE;
            goto L8A; // [5045] 5085
        }
        else{
            _26914 = NOVALUE;
        }

        /** emit.e:1386				op = PLUS*/
        _op_51874 = 11;

        /** emit.e:1387				emit_opcode(op)*/
        _47emit_opcode(11);

        /** emit.e:1388				emit_addr(b)*/
        _47emit_addr(_b_51877);

        /** emit.e:1389				emit_addr(b)*/
        _47emit_addr(_b_51877);

        /** emit.e:1390				cont21d(op, a, b, FALSE)*/
        _47cont21d(11, _a_51876, _b_51877, _13FALSE_450);
        goto LC; // [5082] 7739
L8A: 

        /** emit.e:1393				Push(a)*/
        _47Push(_a_51876);

        /** emit.e:1394				Push(b)*/
        _47Push(_b_51877);

        /** emit.e:1395				cont21ii(op, FALSE)*/
        _47cont21ii(_op_51874, _13FALSE_450);
        goto LC; // [5104] 7739

        /** emit.e:1399		case rw:DIVIDE then*/
        case 14:

        /** emit.e:1400			b = Pop()*/
        _b_51877 = _47Pop();
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:1401			if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _26916 = (_b_51877 > 0);
        if (_26916 == 0) {
            _26917 = 0;
            goto L8B; // [5123] 5149
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26918 = (object)*(((s1_ptr)_2)->base + _b_51877);
        _2 = (object)SEQ_PTR(_26918);
        _26919 = (object)*(((s1_ptr)_2)->base + 3);
        _26918 = NOVALUE;
        if (IS_ATOM_INT(_26919)) {
            _26920 = (_26919 == 2);
        }
        else {
            _26920 = binary_op(EQUALS, _26919, 2);
        }
        _26919 = NOVALUE;
        if (IS_ATOM_INT(_26920))
        _26917 = (_26920 != 0);
        else
        _26917 = DBL_PTR(_26920)->dbl != 0.0;
L8B: 
        if (_26917 == 0) {
            goto L8C; // [5149] 5220
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26922 = (object)*(((s1_ptr)_2)->base + _b_51877);
        _2 = (object)SEQ_PTR(_26922);
        _26923 = (object)*(((s1_ptr)_2)->base + 1);
        _26922 = NOVALUE;
        if (_26923 == 2)
        _26924 = 1;
        else if (IS_ATOM_INT(_26923) && IS_ATOM_INT(2))
        _26924 = 0;
        else
        _26924 = (compare(_26923, 2) == 0);
        _26923 = NOVALUE;
        if (_26924 == 0)
        {
            _26924 = NOVALUE;
            goto L8C; // [5170] 5220
        }
        else{
            _26924 = NOVALUE;
        }

        /** emit.e:1402				op = DIV2*/
        _op_51874 = 98;

        /** emit.e:1403				emit_opcode(op)*/
        _47emit_opcode(98);

        /** emit.e:1404				emit_addr(Pop()) -- n.b. "a" hasn't been set*/
        _26925 = _47Pop();
        _47emit_addr(_26925);
        _26925 = NOVALUE;

        /** emit.e:1405				a = 0*/
        _a_51876 = 0;

        /** emit.e:1406				emit_addr(0)*/
        _47emit_addr(0);

        /** emit.e:1407				cont21d(op, a, b, FALSE)  -- could have fractional result*/
        _47cont21d(98, 0, _b_51877, _13FALSE_450);
        goto LC; // [5217] 7739
L8C: 

        /** emit.e:1409				Push(b)*/
        _47Push(_b_51877);

        /** emit.e:1410				cont21ii(op, FALSE)*/
        _47cont21ii(_op_51874, _13FALSE_450);
        goto LC; // [5234] 7739

        /** emit.e:1413		case FLOOR then*/
        case 83:

        /** emit.e:1414			if previous_op = rw:DIVIDE then*/
        if (_36previous_op_21549 != 14)
        goto L8D; // [5244] 5292

        /** emit.e:1415				op = FLOOR_DIV*/
        _op_51874 = 63;

        /** emit.e:1416				backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26927 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26927 = 1;
        }
        _26928 = _26927 - 3;
        _26927 = NOVALUE;
        _47backpatch(_26928, 63);
        _26928 = NOVALUE;

        /** emit.e:1417				assignable = TRUE*/
        _47assignable_50954 = _13TRUE_452;

        /** emit.e:1418				last_op = op*/
        _47last_op_51833 = 63;

        /** emit.e:1419				last_pc = last_pc_backup*/
        _47last_pc_51834 = _last_pc_backup_51891;
        goto LC; // [5289] 7739
L8D: 

        /** emit.e:1421			elsif previous_op = DIV2 then*/
        if (_36previous_op_21549 != 98)
        goto L8E; // [5298] 5385

        /** emit.e:1422				op = FLOOR_DIV2*/
        _op_51874 = 66;

        /** emit.e:1423				backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26930 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26930 = 1;
        }
        _26931 = _26930 - 3;
        _26930 = NOVALUE;
        _47backpatch(_26931, 66);
        _26931 = NOVALUE;

        /** emit.e:1424				assignable = TRUE*/
        _47assignable_50954 = _13TRUE_452;

        /** emit.e:1425				if IsInteger(Code[$-2]) then*/
        if (IS_SEQUENCE(_36Code_21539)){
                _26932 = SEQ_PTR(_36Code_21539)->length;
        }
        else {
            _26932 = 1;
        }
        _26933 = _26932 - 2;
        _26932 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21539);
        _26934 = (object)*(((s1_ptr)_2)->base + _26933);
        Ref(_26934);
        _26935 = _47IsInteger(_26934);
        _26934 = NOVALUE;
        if (_26935 == 0) {
            DeRef(_26935);
            _26935 = NOVALUE;
            goto L8F; // [5352] 5372
        }
        else {
            if (!IS_ATOM_INT(_26935) && DBL_PTR(_26935)->dbl == 0.0){
                DeRef(_26935);
                _26935 = NOVALUE;
                goto L8F; // [5352] 5372
            }
            DeRef(_26935);
            _26935 = NOVALUE;
        }
        DeRef(_26935);
        _26935 = NOVALUE;

        /** emit.e:1426					TempInteger(Top()) --mark temp as integer type*/

        /** emit.e:145		return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_5482_52976);
        _2 = (object)SEQ_PTR(_47cg_stack_50951);
        _Top_inlined_Top_at_5482_52976 = (object)*(((s1_ptr)_2)->base + _47cgi_50952);
        Ref(_Top_inlined_Top_at_5482_52976);
        Ref(_Top_inlined_Top_at_5482_52976);
        _47TempInteger(_Top_inlined_Top_at_5482_52976);
L8F: 

        /** emit.e:1428				last_op = op*/
        _47last_op_51833 = _op_51874;

        /** emit.e:1429				last_pc = last_pc_backup*/
        _47last_pc_51834 = _last_pc_backup_51891;
        goto LC; // [5382] 7739
L8E: 

        /** emit.e:1431				cont11ii(op, TRUE)*/
        _47cont11ii(_op_51874, _13TRUE_452);
        goto LC; // [5394] 7739

        /** emit.e:1437		case MINUS, rw:APPEND, PREPEND, COMPARE, EQUAL,*/
        case 10:
        case 35:
        case 57:
        case 76:
        case 153:
        case 154:
        case 15:
        case 32:
        case 111:
        case 133:
        case 53:
        case 167:
        case 194:
        case 198:
        case 199:
        case 204:

        /** emit.e:1440			cont21ii(op, FALSE)*/
        _47cont21ii(_op_51874, _13FALSE_450);
        goto LC; // [5438] 7739

        /** emit.e:1442		case SC2_NULL then  -- correct the stack - we aren't emitting anything*/
        case 145:

        /** emit.e:1443			c = Pop()*/
        _c_51878 = _47Pop();
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1444			TempKeep(c)*/
        _47TempKeep(_c_51878);

        /** emit.e:1445			b = Pop()  -- remove SC1's temp*/
        _b_51877 = _47Pop();
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:1446			Push(c)*/
        _47Push(_c_51878);

        /** emit.e:1447			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;

        /** emit.e:1448			last_op = last_op_backup*/
        _47last_op_51833 = _last_op_backup_51892;

        /** emit.e:1449			last_pc = last_pc_backup*/
        _47last_pc_51834 = _last_pc_backup_51891;
        goto LC; // [5485] 7739

        /** emit.e:1452		case SC2_AND, SC2_OR then*/
        case 142:
        case 144:

        /** emit.e:1453			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1454			emit_addr(Pop())*/
        _26938 = _47Pop();
        _47emit_addr(_26938);
        _26938 = NOVALUE;

        /** emit.e:1455			c = Pop()*/
        _c_51878 = _47Pop();
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1456			TempKeep(c)*/
        _47TempKeep(_c_51878);

        /** emit.e:1457			emit_addr(c) -- target*/
        _47emit_addr(_c_51878);

        /** emit.e:1458			TempInteger(c)*/
        _47TempInteger(_c_51878);

        /** emit.e:1459			Push(c)*/
        _47Push(_c_51878);

        /** emit.e:1460			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [5540] 7739

        /** emit.e:1463		case MEM_COPY, MEM_SET, PRINTF then*/
        case 130:
        case 131:
        case 38:

        /** emit.e:1464			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1465			c = Pop()*/
        _c_51878 = _47Pop();
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1466			b = Pop()*/
        _b_51877 = _47Pop();
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:1467			emit_addr(Pop())*/
        _26942 = _47Pop();
        _47emit_addr(_26942);
        _26942 = NOVALUE;

        /** emit.e:1468			emit_addr(b)*/
        _47emit_addr(_b_51877);

        /** emit.e:1469			emit_addr(c)*/
        _47emit_addr(_c_51878);

        /** emit.e:1470			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [5594] 7739

        /** emit.e:1473		case RHS_SLICE, FIND, MATCH, FIND_FROM, MATCH_FROM, SPLICE, INSERT, REMOVE, OPEN then*/
        case 46:
        case 77:
        case 78:
        case 176:
        case 177:
        case 190:
        case 191:
        case 200:
        case 37:

        /** emit.e:1474			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1475			c = Pop()*/
        _c_51878 = _47Pop();
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1476			b = Pop()*/
        _b_51877 = _47Pop();
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:1477			emit_addr(Pop())*/
        _26945 = _47Pop();
        _47emit_addr(_26945);
        _26945 = NOVALUE;

        /** emit.e:1478			emit_addr(b)*/
        _47emit_addr(_b_51877);

        /** emit.e:1479			emit_addr(c)*/
        _47emit_addr(_c_51878);

        /** emit.e:1480			c = NewTempSym()*/
        _c_51878 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1481			if op = FIND or op = FIND_FROM or op = OPEN then*/
        _26947 = (_op_51874 == 77);
        if (_26947 != 0) {
            _26948 = 1;
            goto L90; // [5669] 5683
        }
        _26949 = (_op_51874 == 176);
        _26948 = (_26949 != 0);
L90: 
        if (_26948 != 0) {
            goto L91; // [5683] 5698
        }
        _26951 = (_op_51874 == 37);
        if (_26951 == 0)
        {
            DeRef(_26951);
            _26951 = NOVALUE;
            goto L92; // [5694] 5706
        }
        else{
            DeRef(_26951);
            _26951 = NOVALUE;
        }
L91: 

        /** emit.e:1482				TempInteger( c )*/
        _47TempInteger(_c_51878);
        goto L93; // [5703] 5713
L92: 

        /** emit.e:1484				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_51878, 1);
L93: 

        /** emit.e:1486			assignable = TRUE*/
        _47assignable_50954 = _13TRUE_452;

        /** emit.e:1487			Push(c)*/
        _47Push(_c_51878);

        /** emit.e:1488			emit_addr(c)*/
        _47emit_addr(_c_51878);
        goto LC; // [5730] 7739

        /** emit.e:1491		case CONCAT_N then     -- concatenate 3 or more items*/
        case 157:

        /** emit.e:1492			n = op_info1  -- number of items to concatenate*/
        _n_51887 = _47op_info1_50936;

        /** emit.e:1493			emit_opcode(CONCAT_N)*/
        _47emit_opcode(157);

        /** emit.e:1494			emit(n)*/
        _47emit(_n_51887);

        /** emit.e:1495			for i = 1 to n do*/
        _26952 = _n_51887;
        {
            object _i_53044;
            _i_53044 = 1;
L94: 
            if (_i_53044 > _26952){
                goto L95; // [5760] 5788
            }

            /** emit.e:1496				symtab_index element = Pop()*/
            _element_53047 = _47Pop();
            if (!IS_ATOM_INT(_element_53047)) {
                _1 = (object)(DBL_PTR(_element_53047)->dbl);
                DeRefDS(_element_53047);
                _element_53047 = _1;
            }

            /** emit.e:1497				emit_addr( element )  -- reverse order*/
            _47emit_addr(_element_53047);

            /** emit.e:1498			end for*/
            _i_53044 = _i_53044 + 1;
            goto L94; // [5783] 5767
L95: 
            ;
        }

        /** emit.e:1499			c = NewTempSym()*/
        _c_51878 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1500			emit_addr(c)*/
        _47emit_addr(_c_51878);

        /** emit.e:1501			emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_51878, 1);

        /** emit.e:1502			assignable = TRUE*/
        _47assignable_50954 = _13TRUE_452;

        /** emit.e:1503			Push(c)*/
        _47Push(_c_51878);
        goto LC; // [5819] 7739

        /** emit.e:1505		case FOR then*/
        case 21:

        /** emit.e:1506			c = Pop() -- increment*/
        _c_51878 = _47Pop();
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1507			TempKeep(c)*/
        _47TempKeep(_c_51878);

        /** emit.e:1508			ic = IsInteger(c)*/
        _ic_51886 = _47IsInteger(_c_51878);
        if (!IS_ATOM_INT(_ic_51886)) {
            _1 = (object)(DBL_PTR(_ic_51886)->dbl);
            DeRefDS(_ic_51886);
            _ic_51886 = _1;
        }

        /** emit.e:1509			if c < 1 or*/
        _26957 = (_c_51878 < 1);
        if (_26957 != 0) {
            goto L96; // [5851] 5930
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26959 = (object)*(((s1_ptr)_2)->base + _c_51878);
        _2 = (object)SEQ_PTR(_26959);
        _26960 = (object)*(((s1_ptr)_2)->base + 3);
        _26959 = NOVALUE;
        if (IS_ATOM_INT(_26960)) {
            _26961 = (_26960 == 1);
        }
        else {
            _26961 = binary_op(EQUALS, _26960, 1);
        }
        _26960 = NOVALUE;
        if (IS_ATOM_INT(_26961)) {
            if (_26961 == 0) {
                DeRef(_26962);
                _26962 = 0;
                goto L97; // [5873] 5899
            }
        }
        else {
            if (DBL_PTR(_26961)->dbl == 0.0) {
                DeRef(_26962);
                _26962 = 0;
                goto L97; // [5873] 5899
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26963 = (object)*(((s1_ptr)_2)->base + _c_51878);
        _2 = (object)SEQ_PTR(_26963);
        _26964 = (object)*(((s1_ptr)_2)->base + 4);
        _26963 = NOVALUE;
        if (IS_ATOM_INT(_26964)) {
            _26965 = (_26964 != 2);
        }
        else {
            _26965 = binary_op(NOTEQ, _26964, 2);
        }
        _26964 = NOVALUE;
        DeRef(_26962);
        if (IS_ATOM_INT(_26965))
        _26962 = (_26965 != 0);
        else
        _26962 = DBL_PTR(_26965)->dbl != 0.0;
L97: 
        if (_26962 == 0) {
            DeRef(_26966);
            _26966 = 0;
            goto L98; // [5899] 5925
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26967 = (object)*(((s1_ptr)_2)->base + _c_51878);
        _2 = (object)SEQ_PTR(_26967);
        _26968 = (object)*(((s1_ptr)_2)->base + 4);
        _26967 = NOVALUE;
        if (IS_ATOM_INT(_26968)) {
            _26969 = (_26968 != 4);
        }
        else {
            _26969 = binary_op(NOTEQ, _26968, 4);
        }
        _26968 = NOVALUE;
        if (IS_ATOM_INT(_26969))
        _26966 = (_26969 != 0);
        else
        _26966 = DBL_PTR(_26969)->dbl != 0.0;
L98: 
        if (_26966 == 0)
        {
            _26966 = NOVALUE;
            goto L99; // [5926] 5967
        }
        else{
            _26966 = NOVALUE;
        }
L96: 

        /** emit.e:1514				emit_opcode(ASSIGN)*/
        _47emit_opcode(18);

        /** emit.e:1515				emit_addr(c)*/
        _47emit_addr(_c_51878);

        /** emit.e:1516				c = NewTempSym()*/
        _c_51878 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1517				if ic then*/
        if (_ic_51886 == 0)
        {
            goto L9A; // [5952] 5961
        }
        else{
        }

        /** emit.e:1518					TempInteger( c )*/
        _47TempInteger(_c_51878);
L9A: 

        /** emit.e:1520				emit_addr(c)*/
        _47emit_addr(_c_51878);
L99: 

        /** emit.e:1522			b = Pop() -- limit*/
        _b_51877 = _47Pop();
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:1523			TempKeep(b)*/
        _47TempKeep(_b_51877);

        /** emit.e:1524			ib = IsInteger(b)*/
        _ib_51885 = _47IsInteger(_b_51877);
        if (!IS_ATOM_INT(_ib_51885)) {
            _1 = (object)(DBL_PTR(_ib_51885)->dbl);
            DeRefDS(_ib_51885);
            _ib_51885 = _1;
        }

        /** emit.e:1525			if b < 1 or*/
        _26973 = (_b_51877 < 1);
        if (_26973 != 0) {
            goto L9B; // [5993] 6072
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26975 = (object)*(((s1_ptr)_2)->base + _b_51877);
        _2 = (object)SEQ_PTR(_26975);
        _26976 = (object)*(((s1_ptr)_2)->base + 3);
        _26975 = NOVALUE;
        if (IS_ATOM_INT(_26976)) {
            _26977 = (_26976 == 1);
        }
        else {
            _26977 = binary_op(EQUALS, _26976, 1);
        }
        _26976 = NOVALUE;
        if (IS_ATOM_INT(_26977)) {
            if (_26977 == 0) {
                DeRef(_26978);
                _26978 = 0;
                goto L9C; // [6015] 6041
            }
        }
        else {
            if (DBL_PTR(_26977)->dbl == 0.0) {
                DeRef(_26978);
                _26978 = 0;
                goto L9C; // [6015] 6041
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26979 = (object)*(((s1_ptr)_2)->base + _b_51877);
        _2 = (object)SEQ_PTR(_26979);
        _26980 = (object)*(((s1_ptr)_2)->base + 4);
        _26979 = NOVALUE;
        if (IS_ATOM_INT(_26980)) {
            _26981 = (_26980 != 2);
        }
        else {
            _26981 = binary_op(NOTEQ, _26980, 2);
        }
        _26980 = NOVALUE;
        DeRef(_26978);
        if (IS_ATOM_INT(_26981))
        _26978 = (_26981 != 0);
        else
        _26978 = DBL_PTR(_26981)->dbl != 0.0;
L9C: 
        if (_26978 == 0) {
            DeRef(_26982);
            _26982 = 0;
            goto L9D; // [6041] 6067
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26983 = (object)*(((s1_ptr)_2)->base + _b_51877);
        _2 = (object)SEQ_PTR(_26983);
        _26984 = (object)*(((s1_ptr)_2)->base + 4);
        _26983 = NOVALUE;
        if (IS_ATOM_INT(_26984)) {
            _26985 = (_26984 != 4);
        }
        else {
            _26985 = binary_op(NOTEQ, _26984, 4);
        }
        _26984 = NOVALUE;
        if (IS_ATOM_INT(_26985))
        _26982 = (_26985 != 0);
        else
        _26982 = DBL_PTR(_26985)->dbl != 0.0;
L9D: 
        if (_26982 == 0)
        {
            _26982 = NOVALUE;
            goto L9E; // [6068] 6109
        }
        else{
            _26982 = NOVALUE;
        }
L9B: 

        /** emit.e:1530				emit_opcode(ASSIGN)*/
        _47emit_opcode(18);

        /** emit.e:1531				emit_addr(b)*/
        _47emit_addr(_b_51877);

        /** emit.e:1532				b = NewTempSym()*/
        _b_51877 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:1533				if ib then*/
        if (_ib_51885 == 0)
        {
            goto L9F; // [6094] 6103
        }
        else{
        }

        /** emit.e:1534					TempInteger( b )*/
        _47TempInteger(_b_51877);
L9F: 

        /** emit.e:1536				emit_addr(b)*/
        _47emit_addr(_b_51877);
L9E: 

        /** emit.e:1538			a = Pop() -- initial value*/
        _a_51876 = _47Pop();
        if (!IS_ATOM_INT(_a_51876)) {
            _1 = (object)(DBL_PTR(_a_51876)->dbl);
            DeRefDS(_a_51876);
            _a_51876 = _1;
        }

        /** emit.e:1539			if IsInteger(a) and ib and ic then*/
        _26988 = _47IsInteger(_a_51876);
        if (IS_ATOM_INT(_26988)) {
            if (_26988 == 0) {
                DeRef(_26989);
                _26989 = 0;
                goto LA0; // [6122] 6130
            }
        }
        else {
            if (DBL_PTR(_26988)->dbl == 0.0) {
                DeRef(_26989);
                _26989 = 0;
                goto LA0; // [6122] 6130
            }
        }
        DeRef(_26989);
        _26989 = (_ib_51885 != 0);
LA0: 
        if (_26989 == 0) {
            goto LA1; // [6130] 6169
        }
        if (_ic_51886 == 0)
        {
            goto LA1; // [6135] 6169
        }
        else{
        }

        /** emit.e:1540				SymTab[op_info1][S_VTYPE] = integer_type*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_47op_info1_50936 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 15);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _54integer_type_46786;
        DeRef(_1);
        _26991 = NOVALUE;

        /** emit.e:1541				op = FOR_I*/
        _op_51874 = 125;
        goto LA2; // [6166] 6179
LA1: 

        /** emit.e:1543				op = FOR*/
        _op_51874 = 21;
LA2: 

        /** emit.e:1545			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1546			emit_addr(c)*/
        _47emit_addr(_c_51878);

        /** emit.e:1547			emit_addr(b)*/
        _47emit_addr(_b_51877);

        /** emit.e:1548			emit_addr(a)*/
        _47emit_addr(_a_51876);

        /** emit.e:1549			emit_addr(CurrentSub) -- in case recursion check is needed*/
        _47emit_addr(_36CurrentSub_21455);

        /** emit.e:1550			Push(b)*/
        _47Push(_b_51877);

        /** emit.e:1551			Push(c)*/
        _47Push(_c_51878);

        /** emit.e:1552			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [6223] 7739

        /** emit.e:1555		case ENDFOR_GENERAL, ENDFOR_INT_UP1 then  -- all ENDFORs*/
        case 39:
        case 54:

        /** emit.e:1556			emit_opcode(op) -- will be patched at runtime*/
        _47emit_opcode(_op_51874);

        /** emit.e:1557			a = Pop()*/
        _a_51876 = _47Pop();
        if (!IS_ATOM_INT(_a_51876)) {
            _1 = (object)(DBL_PTR(_a_51876)->dbl);
            DeRefDS(_a_51876);
            _a_51876 = _1;
        }

        /** emit.e:1558			emit_addr(op_info2) -- address of top of loop*/
        _47emit_addr(_47op_info2_50937);

        /** emit.e:1559			emit_addr(Pop())    -- limit*/
        _26994 = _47Pop();
        _47emit_addr(_26994);
        _26994 = NOVALUE;

        /** emit.e:1560			emit_addr(op_info1) -- loop var*/
        _47emit_addr(_47op_info1_50936);

        /** emit.e:1561			emit_addr(a)        -- increment - not always used -*/
        _47emit_addr(_a_51876);

        /** emit.e:1563			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [6277] 7739

        /** emit.e:1566		case ASSIGN_OP_SUBS, PASSIGN_OP_SUBS then*/
        case 149:
        case 164:

        /** emit.e:1568			b = Pop()      -- rhs value, keep on stack*/
        _b_51877 = _47Pop();
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:1569			TempKeep(b)*/
        _47TempKeep(_b_51877);

        /** emit.e:1571			a = Pop()      -- subscript, keep on stack*/
        _a_51876 = _47Pop();
        if (!IS_ATOM_INT(_a_51876)) {
            _1 = (object)(DBL_PTR(_a_51876)->dbl);
            DeRefDS(_a_51876);
            _a_51876 = _1;
        }

        /** emit.e:1572			TempKeep(a)*/
        _47TempKeep(_a_51876);

        /** emit.e:1574			c = Pop()      -- lhs sequence, keep on stack*/
        _c_51878 = _47Pop();
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1575			TempKeep(c)*/
        _47TempKeep(_c_51878);

        /** emit.e:1577			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1578			emit_addr(c)*/
        _47emit_addr(_c_51878);

        /** emit.e:1579			emit_addr(a)*/
        _47emit_addr(_a_51876);

        /** emit.e:1581			d = NewTempSym()*/
        _d_51879 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_d_51879)) {
            _1 = (object)(DBL_PTR(_d_51879)->dbl);
            DeRefDS(_d_51879);
            _d_51879 = _1;
        }

        /** emit.e:1582			emit_addr(d)   -- place to store result*/
        _47emit_addr(_d_51879);

        /** emit.e:1583			emit_temp( d, NEW_REFERENCE )*/
        _47emit_temp(_d_51879, 1);

        /** emit.e:1585			Push(c)*/
        _47Push(_c_51878);

        /** emit.e:1586			Push(a)*/
        _47Push(_a_51876);

        /** emit.e:1587			Push(d)*/
        _47Push(_d_51879);

        /** emit.e:1588			Push(b)*/
        _47Push(_b_51877);

        /** emit.e:1589			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [6382] 7739

        /** emit.e:1592		case ASSIGN_SLICE, PASSIGN_SLICE then*/
        case 45:
        case 163:

        /** emit.e:1593			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1594			b = Pop() -- rhs value*/
        _b_51877 = _47Pop();
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:1595			a = Pop() -- 2nd subs*/
        _a_51876 = _47Pop();
        if (!IS_ATOM_INT(_a_51876)) {
            _1 = (object)(DBL_PTR(_a_51876)->dbl);
            DeRefDS(_a_51876);
            _a_51876 = _1;
        }

        /** emit.e:1596			c = Pop() -- 1st subs*/
        _c_51878 = _47Pop();
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1597			emit_addr(Pop()) -- sequence*/
        _27002 = _47Pop();
        _47emit_addr(_27002);
        _27002 = NOVALUE;

        /** emit.e:1598			emit_addr(c)*/
        _47emit_addr(_c_51878);

        /** emit.e:1599			emit_addr(a)*/
        _47emit_addr(_a_51876);

        /** emit.e:1600			emit_addr(b)*/
        _47emit_addr(_b_51877);

        /** emit.e:1601			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [6446] 7739

        /** emit.e:1604		case REPLACE then*/
        case 201:

        /** emit.e:1605			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1607			b = Pop()  -- source*/
        _b_51877 = _47Pop();
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:1608			a = Pop()  -- replacement*/
        _a_51876 = _47Pop();
        if (!IS_ATOM_INT(_a_51876)) {
            _1 = (object)(DBL_PTR(_a_51876)->dbl);
            DeRefDS(_a_51876);
            _a_51876 = _1;
        }

        /** emit.e:1609			c = Pop()  -- start of replaced slice*/
        _c_51878 = _47Pop();
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1610			d = Pop()  -- end of replaced slice*/
        _d_51879 = _47Pop();
        if (!IS_ATOM_INT(_d_51879)) {
            _1 = (object)(DBL_PTR(_d_51879)->dbl);
            DeRefDS(_d_51879);
            _d_51879 = _1;
        }

        /** emit.e:1611			emit_addr(d)*/
        _47emit_addr(_d_51879);

        /** emit.e:1612			emit_addr(c)*/
        _47emit_addr(_c_51878);

        /** emit.e:1613			emit_addr(a)*/
        _47emit_addr(_a_51876);

        /** emit.e:1614			emit_addr(b)*/
        _47emit_addr(_b_51877);

        /** emit.e:1616			c = NewTempSym()*/
        _c_51878 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1617			Push(c)*/
        _47Push(_c_51878);

        /** emit.e:1618			emit_addr(c)     -- place to store result*/
        _47emit_addr(_c_51878);

        /** emit.e:1619			emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_51878, 1);

        /** emit.e:1620			assignable = TRUE*/
        _47assignable_50954 = _13TRUE_452;
        goto LC; // [6536] 7739

        /** emit.e:1623		case ASSIGN_OP_SLICE, PASSIGN_OP_SLICE then*/
        case 150:
        case 165:

        /** emit.e:1625			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1627			b = Pop()        -- rhs value not used*/
        _b_51877 = _47Pop();
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:1628			TempKeep(b)*/
        _47TempKeep(_b_51877);

        /** emit.e:1630			a = Pop()        -- 2nd subs*/
        _a_51876 = _47Pop();
        if (!IS_ATOM_INT(_a_51876)) {
            _1 = (object)(DBL_PTR(_a_51876)->dbl);
            DeRefDS(_a_51876);
            _a_51876 = _1;
        }

        /** emit.e:1631			TempKeep(a)*/
        _47TempKeep(_a_51876);

        /** emit.e:1633			c = Pop()        -- 1st subs*/
        _c_51878 = _47Pop();
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1634			TempKeep(c)*/
        _47TempKeep(_c_51878);

        /** emit.e:1636			d = Pop()*/
        _d_51879 = _47Pop();
        if (!IS_ATOM_INT(_d_51879)) {
            _1 = (object)(DBL_PTR(_d_51879)->dbl);
            DeRefDS(_d_51879);
            _d_51879 = _1;
        }

        /** emit.e:1637			TempKeep(d)      -- sequence*/
        _47TempKeep(_d_51879);

        /** emit.e:1639			emit_addr(d)*/
        _47emit_addr(_d_51879);

        /** emit.e:1640			Push(d)*/
        _47Push(_d_51879);

        /** emit.e:1642			emit_addr(c)*/
        _47emit_addr(_c_51878);

        /** emit.e:1643			Push(c)*/
        _47Push(_c_51878);

        /** emit.e:1645			emit_addr(a)*/
        _47emit_addr(_a_51876);

        /** emit.e:1646			Push(a)*/
        _47Push(_a_51876);

        /** emit.e:1648			c = NewTempSym()*/
        _c_51878 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1649			Push(c)*/
        _47Push(_c_51878);

        /** emit.e:1650			emit_addr(c)     -- place to store result*/
        _47emit_addr(_c_51878);

        /** emit.e:1651			emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_51878, 1);

        /** emit.e:1653			Push(b)*/
        _47Push(_b_51877);

        /** emit.e:1654			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [6663] 7739

        /** emit.e:1657		case CALL_PROC then*/
        case 136:

        /** emit.e:1658			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1659			b = Pop()*/
        _b_51877 = _47Pop();
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:1660			emit_addr(Pop())*/
        _27014 = _47Pop();
        _47emit_addr(_27014);
        _27014 = NOVALUE;

        /** emit.e:1661			emit_addr(b)*/
        _47emit_addr(_b_51877);

        /** emit.e:1662			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [6701] 7739

        /** emit.e:1664		case CALL_FUNC then*/
        case 137:

        /** emit.e:1665			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1666			b = Pop()*/
        _b_51877 = _47Pop();
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:1667			emit_addr(Pop())*/
        _27016 = _47Pop();
        _47emit_addr(_27016);
        _27016 = NOVALUE;

        /** emit.e:1668			emit_addr(b)*/
        _47emit_addr(_b_51877);

        /** emit.e:1669			assignable = TRUE*/
        _47assignable_50954 = _13TRUE_452;

        /** emit.e:1670			c = NewTempSym()*/
        _c_51878 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1671			Push(c)*/
        _47Push(_c_51878);

        /** emit.e:1672			emit_addr(c)*/
        _47emit_addr(_c_51878);

        /** emit.e:1673			emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_51878, 1);
        goto LC; // [6763] 7739

        /** emit.e:1675		case EXIT_BLOCK then*/
        case 206:

        /** emit.e:1676			emit_opcode( op )*/
        _47emit_opcode(_op_51874);

        /** emit.e:1677			emit_addr( Pop() )*/
        _27018 = _47Pop();
        _47emit_addr(_27018);
        _27018 = NOVALUE;

        /** emit.e:1678			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [6789] 7739

        /** emit.e:1680		case RETURNP then*/
        case 29:

        /** emit.e:1681			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1682			emit_addr(CurrentSub)*/
        _47emit_addr(_36CurrentSub_21455);

        /** emit.e:1683			emit_addr(top_block())*/
        _27019 = _65top_block(0);
        _47emit_addr(_27019);
        _27019 = NOVALUE;

        /** emit.e:1684			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [6823] 7739

        /** emit.e:1686		case RETURNF then*/
        case 28:

        /** emit.e:1687			clear_temp( Top() )*/

        /** emit.e:145		return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_7037_53194);
        _2 = (object)SEQ_PTR(_47cg_stack_50951);
        _Top_inlined_Top_at_7037_53194 = (object)*(((s1_ptr)_2)->base + _47cgi_50952);
        Ref(_Top_inlined_Top_at_7037_53194);
        Ref(_Top_inlined_Top_at_7037_53194);
        _47clear_temp(_Top_inlined_Top_at_7037_53194);

        /** emit.e:1688			flush_temps()*/
        RefDS(_21997);
        _47flush_temps(_21997);

        /** emit.e:1689			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1690			emit_addr(CurrentSub)*/
        _47emit_addr(_36CurrentSub_21455);

        /** emit.e:1691			emit_addr(Least_block())*/
        _27020 = _65Least_block();
        _47emit_addr(_27020);
        _27020 = NOVALUE;

        /** emit.e:1692			emit_addr(Pop())*/
        _27021 = _47Pop();
        _47emit_addr(_27021);
        _27021 = NOVALUE;

        /** emit.e:1693			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [6885] 7739

        /** emit.e:1695		case RETURNT then*/
        case 34:

        /** emit.e:1696			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1697			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [6903] 7739

        /** emit.e:1699		case DATE, TIME, SPACE_USED, GET_KEY, TASK_LIST,*/
        case 69:
        case 70:
        case 75:
        case 79:
        case 172:
        case 100:
        case 183:

        /** emit.e:1701			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1702			c = NewTempSym()*/
        _c_51878 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1703			assignable = TRUE*/
        _47assignable_50954 = _13TRUE_452;

        /** emit.e:1704			if op = GET_KEY then  -- it's in op_result as integer*/
        if (_op_51874 != 79)
        goto LA3; // [6945] 6957

        /** emit.e:1705				TempInteger(c)*/
        _47TempInteger(_c_51878);
        goto LA4; // [6954] 6964
LA3: 

        /** emit.e:1707				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_51878, 1);
LA4: 

        /** emit.e:1709			Push(c)*/
        _47Push(_c_51878);

        /** emit.e:1710			emit_addr(c)*/
        _47emit_addr(_c_51878);
        goto LC; // [6974] 7739

        /** emit.e:1712		case CLOSE, ABORT, CALL, DELETE_OBJECT then*/
        case 86:
        case 126:
        case 129:
        case 205:

        /** emit.e:1713			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1714			emit_addr(Pop())*/
        _27024 = _47Pop();
        _47emit_addr(_27024);
        _27024 = NOVALUE;

        /** emit.e:1715			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [7006] 7739

        /** emit.e:1717		case POWER then*/
        case 72:

        /** emit.e:1719			b = Pop()*/
        _b_51877 = _47Pop();
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:1720			a = Pop()*/
        _a_51876 = _47Pop();
        if (!IS_ATOM_INT(_a_51876)) {
            _1 = (object)(DBL_PTR(_a_51876)->dbl);
            DeRefDS(_a_51876);
            _a_51876 = _1;
        }

        /** emit.e:1721			if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _27027 = (_b_51877 > 0);
        if (_27027 == 0) {
            _27028 = 0;
            goto LA5; // [7032] 7058
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27029 = (object)*(((s1_ptr)_2)->base + _b_51877);
        _2 = (object)SEQ_PTR(_27029);
        _27030 = (object)*(((s1_ptr)_2)->base + 3);
        _27029 = NOVALUE;
        if (IS_ATOM_INT(_27030)) {
            _27031 = (_27030 == 2);
        }
        else {
            _27031 = binary_op(EQUALS, _27030, 2);
        }
        _27030 = NOVALUE;
        if (IS_ATOM_INT(_27031))
        _27028 = (_27031 != 0);
        else
        _27028 = DBL_PTR(_27031)->dbl != 0.0;
LA5: 
        if (_27028 == 0) {
            goto LA6; // [7058] 7115
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27033 = (object)*(((s1_ptr)_2)->base + _b_51877);
        _2 = (object)SEQ_PTR(_27033);
        _27034 = (object)*(((s1_ptr)_2)->base + 1);
        _27033 = NOVALUE;
        if (_27034 == 2)
        _27035 = 1;
        else if (IS_ATOM_INT(_27034) && IS_ATOM_INT(2))
        _27035 = 0;
        else
        _27035 = (compare(_27034, 2) == 0);
        _27034 = NOVALUE;
        if (_27035 == 0)
        {
            _27035 = NOVALUE;
            goto LA6; // [7079] 7115
        }
        else{
            _27035 = NOVALUE;
        }

        /** emit.e:1723				op = rw:MULTIPLY*/
        _op_51874 = 13;

        /** emit.e:1724				emit_opcode(op)*/
        _47emit_opcode(13);

        /** emit.e:1725				emit_addr(a)*/
        _47emit_addr(_a_51876);

        /** emit.e:1726				emit_addr(a)*/
        _47emit_addr(_a_51876);

        /** emit.e:1727				cont21d(op, a, b, FALSE)*/
        _47cont21d(13, _a_51876, _b_51877, _13FALSE_450);
        goto LC; // [7112] 7739
LA6: 

        /** emit.e:1729				Push(a)*/
        _47Push(_a_51876);

        /** emit.e:1730				Push(b)*/
        _47Push(_b_51877);

        /** emit.e:1731				cont21ii(op, FALSE)*/
        _47cont21ii(_op_51874, _13FALSE_450);
        goto LC; // [7134] 7739

        /** emit.e:1735		case TYPE_CHECK then*/
        case 65:

        /** emit.e:1736			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1737			c = Pop()*/
        _c_51878 = _47Pop();
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1738			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [7159] 7739

        /** emit.e:1741		case DOLLAR then*/
        case -22:

        /** emit.e:1742			if current_sequence[$] < 0 or SymTab[current_sequence[$]][S_SCOPE] = SC_UNDEFINED then*/
        if (IS_SEQUENCE(_47current_sequence_50944)){
                _27037 = SEQ_PTR(_47current_sequence_50944)->length;
        }
        else {
            _27037 = 1;
        }
        _2 = (object)SEQ_PTR(_47current_sequence_50944);
        _27038 = (object)*(((s1_ptr)_2)->base + _27037);
        if (IS_ATOM_INT(_27038)) {
            _27039 = (_27038 < 0);
        }
        else {
            _27039 = binary_op(LESS, _27038, 0);
        }
        _27038 = NOVALUE;
        if (IS_ATOM_INT(_27039)) {
            if (_27039 != 0) {
                goto LA7; // [7180] 7216
            }
        }
        else {
            if (DBL_PTR(_27039)->dbl != 0.0) {
                goto LA7; // [7180] 7216
            }
        }
        if (IS_SEQUENCE(_47current_sequence_50944)){
                _27041 = SEQ_PTR(_47current_sequence_50944)->length;
        }
        else {
            _27041 = 1;
        }
        _2 = (object)SEQ_PTR(_47current_sequence_50944);
        _27042 = (object)*(((s1_ptr)_2)->base + _27041);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_27042)){
            _27043 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27042)->dbl));
        }
        else{
            _27043 = (object)*(((s1_ptr)_2)->base + _27042);
        }
        _2 = (object)SEQ_PTR(_27043);
        _27044 = (object)*(((s1_ptr)_2)->base + 4);
        _27043 = NOVALUE;
        if (IS_ATOM_INT(_27044)) {
            _27045 = (_27044 == 9);
        }
        else {
            _27045 = binary_op(EQUALS, _27044, 9);
        }
        _27044 = NOVALUE;
        if (_27045 == 0) {
            DeRef(_27045);
            _27045 = NOVALUE;
            goto LA8; // [7212] 7286
        }
        else {
            if (!IS_ATOM_INT(_27045) && DBL_PTR(_27045)->dbl == 0.0){
                DeRef(_27045);
                _27045 = NOVALUE;
                goto LA8; // [7212] 7286
            }
            DeRef(_27045);
            _27045 = NOVALUE;
        }
        DeRef(_27045);
        _27045 = NOVALUE;
LA7: 

        /** emit.e:1743				if lhs_ptr and length(current_sequence) = 1 then*/
        if (_47lhs_ptr_50946 == 0) {
            goto LA9; // [7220] 7249
        }
        if (IS_SEQUENCE(_47current_sequence_50944)){
                _27047 = SEQ_PTR(_47current_sequence_50944)->length;
        }
        else {
            _27047 = 1;
        }
        _27048 = (_27047 == 1);
        _27047 = NOVALUE;
        if (_27048 == 0)
        {
            DeRef(_27048);
            _27048 = NOVALUE;
            goto LA9; // [7234] 7249
        }
        else{
            DeRef(_27048);
            _27048 = NOVALUE;
        }

        /** emit.e:1744					c = PLENGTH*/
        _c_51878 = 160;
        goto LAA; // [7246] 7259
LA9: 

        /** emit.e:1746					c = LENGTH*/
        _c_51878 = 42;
LAA: 

        /** emit.e:1748				c = - new_forward_reference( VARIABLE, current_sequence[$], c )*/
        if (IS_SEQUENCE(_47current_sequence_50944)){
                _27049 = SEQ_PTR(_47current_sequence_50944)->length;
        }
        else {
            _27049 = 1;
        }
        _2 = (object)SEQ_PTR(_47current_sequence_50944);
        _27050 = (object)*(((s1_ptr)_2)->base + _27049);
        Ref(_27050);
        _27051 = _44new_forward_reference(-100, _27050, _c_51878);
        _27050 = NOVALUE;
        if (IS_ATOM_INT(_27051)) {
            if ((uintptr_t)_27051 == (uintptr_t)HIGH_BITS){
                _c_51878 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _c_51878 = - _27051;
            }
        }
        else {
            _c_51878 = unary_op(UMINUS, _27051);
        }
        DeRef(_27051);
        _27051 = NOVALUE;
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }
        goto LAB; // [7283] 7300
LA8: 

        /** emit.e:1750				c = current_sequence[$]*/
        if (IS_SEQUENCE(_47current_sequence_50944)){
                _27053 = SEQ_PTR(_47current_sequence_50944)->length;
        }
        else {
            _27053 = 1;
        }
        _2 = (object)SEQ_PTR(_47current_sequence_50944);
        _c_51878 = (object)*(((s1_ptr)_2)->base + _27053);
        if (!IS_ATOM_INT(_c_51878)){
            _c_51878 = (object)DBL_PTR(_c_51878)->dbl;
        }
LAB: 

        /** emit.e:1754			if lhs_ptr and length(current_sequence) = 1 then*/
        if (_47lhs_ptr_50946 == 0) {
            goto LAC; // [7304] 7331
        }
        if (IS_SEQUENCE(_47current_sequence_50944)){
                _27056 = SEQ_PTR(_47current_sequence_50944)->length;
        }
        else {
            _27056 = 1;
        }
        _27057 = (_27056 == 1);
        _27056 = NOVALUE;
        if (_27057 == 0)
        {
            DeRef(_27057);
            _27057 = NOVALUE;
            goto LAC; // [7318] 7331
        }
        else{
            DeRef(_27057);
            _27057 = NOVALUE;
        }

        /** emit.e:1755				emit_opcode(PLENGTH)*/
        _47emit_opcode(160);
        goto LAD; // [7328] 7339
LAC: 

        /** emit.e:1757				emit_opcode(LENGTH)*/
        _47emit_opcode(42);
LAD: 

        /** emit.e:1760			emit_addr( c )*/
        _47emit_addr(_c_51878);

        /** emit.e:1762			c = NewTempSym()*/
        _c_51878 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1763			TempInteger(c)*/
        _47TempInteger(_c_51878);

        /** emit.e:1764			Push(c)*/
        _47Push(_c_51878);

        /** emit.e:1765			emit_addr(c)*/
        _47emit_addr(_c_51878);

        /** emit.e:1766			assignable = FALSE -- it wouldn't be assigned anyway*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [7374] 7739

        /** emit.e:1769		case TASK_SELF then*/
        case 170:

        /** emit.e:1770			c = NewTempSym()*/
        _c_51878 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1771			Push(c)*/
        _47Push(_c_51878);

        /** emit.e:1772			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1773			emit_addr(c)*/
        _47emit_addr(_c_51878);

        /** emit.e:1774			assignable = TRUE*/
        _47assignable_50954 = _13TRUE_452;
        goto LC; // [7410] 7739

        /** emit.e:1776		case SWITCH then*/
        case 185:

        /** emit.e:1777			emit_opcode( op )*/
        _47emit_opcode(_op_51874);

        /** emit.e:1778			c = Pop()*/
        _c_51878 = _47Pop();
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1779			b = Pop()*/
        _b_51877 = _47Pop();
        if (!IS_ATOM_INT(_b_51877)) {
            _1 = (object)(DBL_PTR(_b_51877)->dbl);
            DeRefDS(_b_51877);
            _b_51877 = _1;
        }

        /** emit.e:1780			a = Pop()*/
        _a_51876 = _47Pop();
        if (!IS_ATOM_INT(_a_51876)) {
            _1 = (object)(DBL_PTR(_a_51876)->dbl);
            DeRefDS(_a_51876);
            _a_51876 = _1;
        }

        /** emit.e:1781			emit_addr( a ) -- Switch Expr*/
        _47emit_addr(_a_51876);

        /** emit.e:1782			emit_addr( b ) -- Case values*/
        _47emit_addr(_b_51877);

        /** emit.e:1783			emit_addr( c ) -- Jump table*/
        _47emit_addr(_c_51878);

        /** emit.e:1785			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [7464] 7739

        /** emit.e:1787		case CASE then*/
        case 186:

        /** emit.e:1789			emit_opcode( op )*/
        _47emit_opcode(_op_51874);

        /** emit.e:1790			emit( cg_stack[cgi] )  -- the case index*/
        _2 = (object)SEQ_PTR(_47cg_stack_50951);
        _27063 = (object)*(((s1_ptr)_2)->base + _47cgi_50952);
        Ref(_27063);
        _47emit(_27063);
        _27063 = NOVALUE;

        /** emit.e:1791			cgi -= 1*/
        _47cgi_50952 = _47cgi_50952 - 1;
        goto LC; // [7496] 7739

        /** emit.e:1794		case PLATFORM then*/
        case 155:

        /** emit.e:1795			if BIND and shroud_only then*/
        if (_36BIND_21052 == 0) {
            goto LAE; // [7506] 7554
        }
        if (_36shroud_only_21445 == 0)
        {
            goto LAE; // [7513] 7554
        }
        else{
        }

        /** emit.e:1797				c = NewTempSym()*/
        _c_51878 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_51878)) {
            _1 = (object)(DBL_PTR(_c_51878)->dbl);
            DeRefDS(_c_51878);
            _c_51878 = _1;
        }

        /** emit.e:1798				TempInteger(c)*/
        _47TempInteger(_c_51878);

        /** emit.e:1799				Push(c)*/
        _47Push(_c_51878);

        /** emit.e:1800				emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1801				emit_addr(c)*/
        _47emit_addr(_c_51878);

        /** emit.e:1802				assignable = TRUE*/
        _47assignable_50954 = _13TRUE_452;
        goto LC; // [7551] 7739
LAE: 

        /** emit.e:1806				n = host_platform()*/
        _n_51887 = _46host_platform();
        if (!IS_ATOM_INT(_n_51887)) {
            _1 = (object)(DBL_PTR(_n_51887)->dbl);
            DeRefDS(_n_51887);
            _n_51887 = _1;
        }

        /** emit.e:1807				Push(NewIntSym(n))*/
        _27068 = _54NewIntSym(_n_51887);
        _47Push(_27068);
        _27068 = NOVALUE;

        /** emit.e:1808				assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [7578] 7739

        /** emit.e:1812		case PROFILE, TASK_SUSPEND then*/
        case 151:
        case 171:

        /** emit.e:1813			a = Pop()*/
        _a_51876 = _47Pop();
        if (!IS_ATOM_INT(_a_51876)) {
            _1 = (object)(DBL_PTR(_a_51876)->dbl);
            DeRefDS(_a_51876);
            _a_51876 = _1;
        }

        /** emit.e:1814			emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1815			emit_addr(a)*/
        _47emit_addr(_a_51876);

        /** emit.e:1816			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [7610] 7739

        /** emit.e:1818		case TRACE then*/
        case 64:

        /** emit.e:1819			a = Pop()*/
        _a_51876 = _47Pop();
        if (!IS_ATOM_INT(_a_51876)) {
            _1 = (object)(DBL_PTR(_a_51876)->dbl);
            DeRefDS(_a_51876);
            _a_51876 = _1;
        }

        /** emit.e:1820			if OpTrace then*/
        if (_36OpTrace_21520 == 0)
        {
            goto LAF; // [7627] 7673
        }
        else{
        }

        /** emit.e:1822				emit_opcode(op)*/
        _47emit_opcode(_op_51874);

        /** emit.e:1823				emit_addr(a)*/
        _47emit_addr(_a_51876);

        /** emit.e:1824				if TRANSLATE then*/
        if (_36TRANSLATE_21049 == 0)
        {
            goto LB0; // [7644] 7672
        }
        else{
        }

        /** emit.e:1825					if not trace_called then*/
        if (_47trace_called_50939 != 0)
        goto LB1; // [7651] 7662

        /** emit.e:1826						Warning(217,0)*/
        RefDS(_21997);
        _50Warning(217, 0, _21997);
LB1: 

        /** emit.e:1828					trace_called = TRUE*/
        _47trace_called_50939 = _13TRUE_452;
LB0: 
LAF: 

        /** emit.e:1831			assignable = FALSE*/
        _47assignable_50954 = _13FALSE_450;
        goto LC; // [7680] 7739

        /** emit.e:1833		case REF_TEMP then*/
        case 207:

        /** emit.e:1835			emit_opcode( REF_TEMP )*/
        _47emit_opcode(207);

        /** emit.e:1836			emit_addr( Pop() )*/
        _27072 = _47Pop();
        _47emit_addr(_27072);
        _27072 = NOVALUE;
        goto LC; // [7701] 7739

        /** emit.e:1838		case DEREF_TEMP then*/
        case 208:

        /** emit.e:1839			emit_opcode( DEREF_TEMP )*/
        _47emit_opcode(208);

        /** emit.e:1840			emit_addr( Pop() )*/
        _27073 = _47Pop();
        _47emit_addr(_27073);
        _27073 = NOVALUE;
        goto LC; // [7722] 7739

        /** emit.e:1842		case else*/
        default:

        /** emit.e:1843			InternalErr(259, {op})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _op_51874;
        _27074 = MAKE_SEQ(_1);
        _50InternalErr(259, _27074);
        _27074 = NOVALUE;
    ;}LC: 

    /** emit.e:1847		previous_op = op*/
    _36previous_op_21549 = _op_51874;

    /** emit.e:1848		inlined = 0*/
    _47inlined_51852 = 0;

    /** emit.e:1850	end procedure*/
    DeRef(_obj_51888);
    DeRef(_elements_51889);
    DeRef(_element_vals_51890);
    DeRef(_26719);
    _26719 = NOVALUE;
    DeRef(_26898);
    _26898 = NOVALUE;
    DeRef(_26606);
    _26606 = NOVALUE;
    DeRef(_26947);
    _26947 = NOVALUE;
    DeRef(_26803);
    _26803 = NOVALUE;
    DeRef(_26756);
    _26756 = NOVALUE;
    DeRef(_26545);
    _26545 = NOVALUE;
    DeRef(_26564);
    _26564 = NOVALUE;
    DeRef(_26781);
    _26781 = NOVALUE;
    _26816 = NOVALUE;
    DeRef(_26728);
    _26728 = NOVALUE;
    DeRef(_26779);
    _26779 = NOVALUE;
    DeRef(_26493);
    _26493 = NOVALUE;
    DeRef(_26857);
    _26857 = NOVALUE;
    _26509 = NOVALUE;
    DeRef(_26973);
    _26973 = NOVALUE;
    DeRef(_26985);
    _26985 = NOVALUE;
    _26603 = NOVALUE;
    DeRef(_26949);
    _26949 = NOVALUE;
    _26814 = NOVALUE;
    DeRef(_26910);
    _26910 = NOVALUE;
    DeRef(_26745);
    _26745 = NOVALUE;
    DeRef(_26903);
    _26903 = NOVALUE;
    DeRef(_26675);
    _26675 = NOVALUE;
    DeRef(_26977);
    _26977 = NOVALUE;
    DeRef(_26700);
    _26700 = NOVALUE;
    DeRef(_26679);
    _26679 = NOVALUE;
    DeRef(_26773);
    _26773 = NOVALUE;
    DeRef(_26723);
    _26723 = NOVALUE;
    _26562 = NOVALUE;
    DeRef(_26891);
    _26891 = NOVALUE;
    DeRef(_26491);
    _26491 = NOVALUE;
    DeRef(_26521);
    _26521 = NOVALUE;
    DeRef(_26659);
    _26659 = NOVALUE;
    DeRef(_26706);
    _26706 = NOVALUE;
    DeRef(_26758);
    _26758 = NOVALUE;
    DeRef(_26665);
    _26665 = NOVALUE;
    DeRef(_26526);
    _26526 = NOVALUE;
    DeRef(_26920);
    _26920 = NOVALUE;
    _26579 = NOVALUE;
    DeRef(_26957);
    _26957 = NOVALUE;
    DeRef(_27031);
    _27031 = NOVALUE;
    DeRef(_26879);
    _26879 = NOVALUE;
    DeRef(_26752);
    _26752 = NOVALUE;
    DeRef(_26965);
    _26965 = NOVALUE;
    DeRef(_26693);
    _26693 = NOVALUE;
    DeRef(_26487);
    _26487 = NOVALUE;
    DeRef(_26560);
    _26560 = NOVALUE;
    DeRef(_26981);
    _26981 = NOVALUE;
    DeRef(_26489);
    _26489 = NOVALUE;
    DeRef(_26797);
    _26797 = NOVALUE;
    DeRef(_26884);
    _26884 = NOVALUE;
    DeRef(_26574);
    _26574 = NOVALUE;
    DeRef(_26769);
    _26769 = NOVALUE;
    DeRef(_26969);
    _26969 = NOVALUE;
    DeRef(_27039);
    _27039 = NOVALUE;
    DeRef(_26529);
    _26529 = NOVALUE;
    DeRef(_26702);
    _26702 = NOVALUE;
    DeRef(_26811);
    _26811 = NOVALUE;
    DeRef(_26638);
    _26638 = NOVALUE;
    DeRef(_26541);
    _26541 = NOVALUE;
    DeRef(_26747);
    _26747 = NOVALUE;
    DeRef(_26819);
    _26819 = NOVALUE;
    DeRef(_26961);
    _26961 = NOVALUE;
    DeRef(_26807);
    _26807 = NOVALUE;
    DeRef(_26916);
    _26916 = NOVALUE;
    DeRef(_26593);
    _26593 = NOVALUE;
    DeRef(_26485);
    _26485 = NOVALUE;
    DeRef(_26536);
    _26536 = NOVALUE;
    DeRef(_26988);
    _26988 = NOVALUE;
    DeRef(_26681);
    _26681 = NOVALUE;
    DeRef(_26539);
    _26539 = NOVALUE;
    DeRef(_26738);
    _26738 = NOVALUE;
    DeRef(_26671);
    _26671 = NOVALUE;
    DeRef(_26799);
    _26799 = NOVALUE;
    DeRef(_26697);
    _26697 = NOVALUE;
    DeRef(_26625);
    _26625 = NOVALUE;
    DeRef(_26599);
    _26599 = NOVALUE;
    DeRef(_26732);
    _26732 = NOVALUE;
    _27042 = NOVALUE;
    DeRef(_26585);
    _26585 = NOVALUE;
    DeRef(_26776);
    _26776 = NOVALUE;
    _26608 = NOVALUE;
    _26577 = NOVALUE;
    DeRef(_26933);
    _26933 = NOVALUE;
    DeRef(_26734);
    _26734 = NOVALUE;
    DeRef(_27027);
    _27027 = NOVALUE;
    return;
    ;
}


void _47emit_assign_op(object _op_53353)
{
    object _0, _1, _2;
    

    /** emit.e:1854		if op = PLUS_EQUALS then*/
    if (_op_53353 != 515)
    goto L1; // [7] 21

    /** emit.e:1855			emit_op(PLUS)*/
    _47emit_op(11);
    goto L2; // [18] 86
L1: 

    /** emit.e:1856		elsif op = MINUS_EQUALS then*/
    if (_op_53353 != 516)
    goto L3; // [25] 39

    /** emit.e:1857			emit_op(MINUS)*/
    _47emit_op(10);
    goto L2; // [36] 86
L3: 

    /** emit.e:1858		elsif op = MULTIPLY_EQUALS then*/
    if (_op_53353 != 517)
    goto L4; // [43] 55

    /** emit.e:1859			emit_op(rw:MULTIPLY)*/
    _47emit_op(13);
    goto L2; // [52] 86
L4: 

    /** emit.e:1860		elsif op = DIVIDE_EQUALS then*/
    if (_op_53353 != 518)
    goto L5; // [59] 71

    /** emit.e:1861			emit_op(rw:DIVIDE)*/
    _47emit_op(14);
    goto L2; // [68] 86
L5: 

    /** emit.e:1862		elsif op = CONCAT_EQUALS then*/
    if (_op_53353 != 519)
    goto L6; // [75] 85

    /** emit.e:1863			emit_op(rw:CONCAT)*/
    _47emit_op(15);
L6: 
L2: 

    /** emit.e:1865	end procedure*/
    return;
    ;
}


void _47StartSourceLine(object _sl_53373, object _dup_ok_53374, object _emit_coverage_53375)
{
    object _line_span_53378 = NOVALUE;
    object _27096 = NOVALUE;
    object _27094 = NOVALUE;
    object _27093 = NOVALUE;
    object _27092 = NOVALUE;
    object _27091 = NOVALUE;
    object _27090 = NOVALUE;
    object _27088 = NOVALUE;
    object _27085 = NOVALUE;
    object _27083 = NOVALUE;
    object _27082 = NOVALUE;
    object _27081 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:1873		if gline_number = LastLineNumber then*/
    if (_36gline_number_21452 != _62LastLineNumber_25557)
    goto L1; // [13] 66

    /** emit.e:1874			if length(LineTable) then*/
    if (IS_SEQUENCE(_36LineTable_21540)){
            _27081 = SEQ_PTR(_36LineTable_21540)->length;
    }
    else {
        _27081 = 1;
    }
    if (_27081 == 0)
    {
        _27081 = NOVALUE;
        goto L2; // [24] 55
    }
    else{
        _27081 = NOVALUE;
    }

    /** emit.e:1875				if dup_ok then*/
    if (_dup_ok_53374 == 0)
    {
        goto L3; // [29] 47
    }
    else{
    }

    /** emit.e:1876					emit_op( STARTLINE )*/
    _47emit_op(58);

    /** emit.e:1877					emit_addr( gline_number )*/
    _47emit_addr(_36gline_number_21452);
L3: 

    /** emit.e:1879				return -- ignore duplicates*/
    return;
    goto L4; // [52] 65
L2: 

    /** emit.e:1882				sl = FALSE -- top-level new statement to execute on same line*/
    _sl_53373 = _13FALSE_450;
L4: 
L1: 

    /** emit.e:1885		LastLineNumber = gline_number*/
    _62LastLineNumber_25557 = _36gline_number_21452;

    /** emit.e:1888		line_span = gline_number - SymTab[CurrentSub][S_FIRSTLINE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27082 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21455);
    _2 = (object)SEQ_PTR(_27082);
    if (!IS_ATOM_INT(_36S_FIRSTLINE_21124)){
        _27083 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FIRSTLINE_21124)->dbl));
    }
    else{
        _27083 = (object)*(((s1_ptr)_2)->base + _36S_FIRSTLINE_21124);
    }
    _27082 = NOVALUE;
    if (IS_ATOM_INT(_27083)) {
        _line_span_53378 = _36gline_number_21452 - _27083;
    }
    else {
        _line_span_53378 = binary_op(MINUS, _36gline_number_21452, _27083);
    }
    _27083 = NOVALUE;
    if (!IS_ATOM_INT(_line_span_53378)) {
        _1 = (object)(DBL_PTR(_line_span_53378)->dbl);
        DeRefDS(_line_span_53378);
        _line_span_53378 = _1;
    }

    /** emit.e:1889		while length(LineTable) < line_span do*/
L5: 
    if (IS_SEQUENCE(_36LineTable_21540)){
            _27085 = SEQ_PTR(_36LineTable_21540)->length;
    }
    else {
        _27085 = 1;
    }
    if (_27085 >= _line_span_53378)
    goto L6; // [109] 128

    /** emit.e:1890			LineTable = append(LineTable, -1) -- filler*/
    Append(&_36LineTable_21540, _36LineTable_21540, -1);

    /** emit.e:1891		end while*/
    goto L5; // [125] 104
L6: 

    /** emit.e:1892		LineTable = append(LineTable, length(Code))*/
    if (IS_SEQUENCE(_36Code_21539)){
            _27088 = SEQ_PTR(_36Code_21539)->length;
    }
    else {
        _27088 = 1;
    }
    Append(&_36LineTable_21540, _36LineTable_21540, _27088);
    _27088 = NOVALUE;

    /** emit.e:1894		if sl and (TRANSLATE or (OpTrace or OpProfileStatement)) then*/
    if (_sl_53373 == 0) {
        goto L7; // [145] 190
    }
    if (_36TRANSLATE_21049 != 0) {
        DeRef(_27091);
        _27091 = 1;
        goto L8; // [151] 171
    }
    if (_36OpTrace_21520 != 0) {
        _27092 = 1;
        goto L9; // [157] 167
    }
    _27092 = (_36OpProfileStatement_21522 != 0);
L9: 
    DeRef(_27091);
    _27091 = (_27092 != 0);
L8: 
    if (_27091 == 0)
    {
        _27091 = NOVALUE;
        goto L7; // [172] 190
    }
    else{
        _27091 = NOVALUE;
    }

    /** emit.e:1896			emit_op(STARTLINE)*/
    _47emit_op(58);

    /** emit.e:1897			emit_addr(gline_number)*/
    _47emit_addr(_36gline_number_21452);
L7: 

    /** emit.e:1901		if (sl and emit_coverage = COVERAGE_INCLUDE) or emit_coverage = COVERAGE_OVERRIDE then*/
    if (_sl_53373 == 0) {
        _27093 = 0;
        goto LA; // [192] 206
    }
    _27094 = (_emit_coverage_53375 == 2);
    _27093 = (_27094 != 0);
LA: 
    if (_27093 != 0) {
        goto LB; // [206] 221
    }
    _27096 = (_emit_coverage_53375 == 3);
    if (_27096 == 0)
    {
        DeRef(_27096);
        _27096 = NOVALUE;
        goto LC; // [217] 229
    }
    else{
        DeRef(_27096);
        _27096 = NOVALUE;
    }
LB: 

    /** emit.e:1902			include_line( gline_number )*/
    _51include_line(_36gline_number_21452);
LC: 

    /** emit.e:1905	end procedure*/
    DeRef(_27094);
    _27094 = NOVALUE;
    return;
    ;
}


object _47has_forward_params(object _sym_53432)
{
    object _27102 = NOVALUE;
    object _27101 = NOVALUE;
    object _27100 = NOVALUE;
    object _27099 = NOVALUE;
    object _27098 = NOVALUE;
    object _27097 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:1908		for i = cgi - (SymTab[sym][S_NUM_ARGS]-1) to cgi do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27097 = (object)*(((s1_ptr)_2)->base + _sym_53432);
    _2 = (object)SEQ_PTR(_27097);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21135)){
        _27098 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21135)->dbl));
    }
    else{
        _27098 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21135);
    }
    _27097 = NOVALUE;
    if (IS_ATOM_INT(_27098)) {
        _27099 = _27098 - 1;
        if ((object)((uintptr_t)_27099 +(uintptr_t) HIGH_BITS) >= 0){
            _27099 = NewDouble((eudouble)_27099);
        }
    }
    else {
        _27099 = binary_op(MINUS, _27098, 1);
    }
    _27098 = NOVALUE;
    if (IS_ATOM_INT(_27099)) {
        _27100 = _47cgi_50952 - _27099;
        if ((object)((uintptr_t)_27100 +(uintptr_t) HIGH_BITS) >= 0){
            _27100 = NewDouble((eudouble)_27100);
        }
    }
    else {
        _27100 = binary_op(MINUS, _47cgi_50952, _27099);
    }
    DeRef(_27099);
    _27099 = NOVALUE;
    _27101 = _47cgi_50952;
    {
        object _i_53434;
        Ref(_27100);
        _i_53434 = _27100;
L1: 
        if (binary_op_a(GREATER, _i_53434, _27101)){
            goto L2; // [32] 65
        }

        /** emit.e:1909			if cg_stack[i] < 0 then*/
        _2 = (object)SEQ_PTR(_47cg_stack_50951);
        if (!IS_ATOM_INT(_i_53434)){
            _27102 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_53434)->dbl));
        }
        else{
            _27102 = (object)*(((s1_ptr)_2)->base + _i_53434);
        }
        if (binary_op_a(GREATEREQ, _27102, 0)){
            _27102 = NOVALUE;
            goto L3; // [47] 58
        }
        _27102 = NOVALUE;

        /** emit.e:1910				return 1*/
        DeRef(_i_53434);
        DeRef(_27100);
        _27100 = NOVALUE;
        return 1;
L3: 

        /** emit.e:1912		end for*/
        _0 = _i_53434;
        if (IS_ATOM_INT(_i_53434)) {
            _i_53434 = _i_53434 + 1;
            if ((object)((uintptr_t)_i_53434 +(uintptr_t) HIGH_BITS) >= 0){
                _i_53434 = NewDouble((eudouble)_i_53434);
            }
        }
        else {
            _i_53434 = binary_op_a(PLUS, _i_53434, 1);
        }
        DeRef(_0);
        goto L1; // [60] 39
L2: 
        ;
        DeRef(_i_53434);
    }

    /** emit.e:1913		return 0*/
    DeRef(_27100);
    _27100 = NOVALUE;
    return 0;
    ;
}



// 0xCCF3CB44
