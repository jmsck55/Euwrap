// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _63find_category(object _tokid_24002)
{
    object _catname_24003 = NOVALUE;
    object _13511 = NOVALUE;
    object _13510 = NOVALUE;
    object _13508 = NOVALUE;
    object _13507 = NOVALUE;
    object _13506 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_24002)) {
        _1 = (object)(DBL_PTR(_tokid_24002)->dbl);
        DeRefDS(_tokid_24002);
        _tokid_24002 = _1;
    }

    /** keylist.e:194		sequence catname = "reserved word"*/
    RefDS(_13505);
    DeRef(_catname_24003);
    _catname_24003 = _13505;

    /** keylist.e:195		for i = 1 to length(token_category) do*/
    _13506 = 73;
    {
        object _i_24006;
        _i_24006 = 1;
L1: 
        if (_i_24006 > 73){
            goto L2; // [17] 72
        }

        /** keylist.e:196			if token_category[i][1] = tokid then*/
        _2 = (object)SEQ_PTR(_38token_category_15972);
        _13507 = (object)*(((s1_ptr)_2)->base + _i_24006);
        _2 = (object)SEQ_PTR(_13507);
        _13508 = (object)*(((s1_ptr)_2)->base + 1);
        _13507 = NOVALUE;
        if (binary_op_a(NOTEQ, _13508, _tokid_24002)){
            _13508 = NOVALUE;
            goto L3; // [36] 65
        }
        _13508 = NOVALUE;

        /** keylist.e:197				catname = token_catname[token_category[i][2]]*/
        _2 = (object)SEQ_PTR(_38token_category_15972);
        _13510 = (object)*(((s1_ptr)_2)->base + _i_24006);
        _2 = (object)SEQ_PTR(_13510);
        _13511 = (object)*(((s1_ptr)_2)->base + 2);
        _13510 = NOVALUE;
        DeRef(_catname_24003);
        _2 = (object)SEQ_PTR(_38token_catname_15959);
        if (!IS_ATOM_INT(_13511)){
            _catname_24003 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_13511)->dbl));
        }
        else{
            _catname_24003 = (object)*(((s1_ptr)_2)->base + _13511);
        }
        RefDS(_catname_24003);

        /** keylist.e:198				exit*/
        goto L2; // [62] 72
L3: 

        /** keylist.e:200		end for*/
        _i_24006 = _i_24006 + 1;
        goto L1; // [67] 24
L2: 
        ;
    }

    /** keylist.e:201		return catname*/
    _13511 = NOVALUE;
    return _catname_24003;
    ;
}


object _63find_token_text(object _tokid_24021)
{
    object _13520 = NOVALUE;
    object _13518 = NOVALUE;
    object _13517 = NOVALUE;
    object _13515 = NOVALUE;
    object _13514 = NOVALUE;
    object _13513 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_24021)) {
        _1 = (object)(DBL_PTR(_tokid_24021)->dbl);
        DeRefDS(_tokid_24021);
        _tokid_24021 = _1;
    }

    /** keylist.e:205		for i = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_63keylist_23121)){
            _13513 = SEQ_PTR(_63keylist_23121)->length;
    }
    else {
        _13513 = 1;
    }
    {
        object _i_24023;
        _i_24023 = 1;
L1: 
        if (_i_24023 > _13513){
            goto L2; // [10] 57
        }

        /** keylist.e:206			if keylist[i][3] = tokid then*/
        _2 = (object)SEQ_PTR(_63keylist_23121);
        _13514 = (object)*(((s1_ptr)_2)->base + _i_24023);
        _2 = (object)SEQ_PTR(_13514);
        _13515 = (object)*(((s1_ptr)_2)->base + 3);
        _13514 = NOVALUE;
        if (binary_op_a(NOTEQ, _13515, _tokid_24021)){
            _13515 = NOVALUE;
            goto L3; // [29] 50
        }
        _13515 = NOVALUE;

        /** keylist.e:207				return keylist[i][1]*/
        _2 = (object)SEQ_PTR(_63keylist_23121);
        _13517 = (object)*(((s1_ptr)_2)->base + _i_24023);
        _2 = (object)SEQ_PTR(_13517);
        _13518 = (object)*(((s1_ptr)_2)->base + 1);
        _13517 = NOVALUE;
        Ref(_13518);
        return _13518;
L3: 

        /** keylist.e:209		end for*/
        _i_24023 = _i_24023 + 1;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** keylist.e:210		return LexName(tokid, "unknown word")*/
    RefDS(_13519);
    _13520 = _47LexName(_tokid_24021, _13519);
    _13518 = NOVALUE;
    return _13520;
    ;
}



// 0x06E588CE
