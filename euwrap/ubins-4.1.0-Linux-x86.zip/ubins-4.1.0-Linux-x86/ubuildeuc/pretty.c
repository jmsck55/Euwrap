// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _26pretty_out(object _text_7556)
{
    object _4071 = NOVALUE;
    object _4069 = NOVALUE;
    object _4067 = NOVALUE;
    object _4066 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:19		pretty_line &= text*/
    if (IS_SEQUENCE(_26pretty_line_7553) && IS_ATOM(_text_7556)) {
        Ref(_text_7556);
        Append(&_26pretty_line_7553, _26pretty_line_7553, _text_7556);
    }
    else if (IS_ATOM(_26pretty_line_7553) && IS_SEQUENCE(_text_7556)) {
    }
    else {
        Concat((object_ptr)&_26pretty_line_7553, _26pretty_line_7553, _text_7556);
    }

    /** pretty.e:20		if equal(text, '\n') and pretty_printing then*/
    if (_text_7556 == 10)
    _4066 = 1;
    else if (IS_ATOM_INT(_text_7556) && IS_ATOM_INT(10))
    _4066 = 0;
    else
    _4066 = (compare(_text_7556, 10) == 0);
    if (_4066 == 0) {
        goto L1; // [15] 50
    }
    goto L1; // [22] 50

    /** pretty.e:21			puts(pretty_file, pretty_line)*/
    EPuts(_26pretty_file_7541, _26pretty_line_7553); // DJP 

    /** pretty.e:22			pretty_line = ""*/
    RefDS(_5);
    DeRefDS(_26pretty_line_7553);
    _26pretty_line_7553 = _5;

    /** pretty.e:23			pretty_line_count += 1*/
    _26pretty_line_count_7546 = _26pretty_line_count_7546 + 1;
L1: 

    /** pretty.e:25		if atom(text) then*/
    _4069 = IS_ATOM(_text_7556);
    if (_4069 == 0)
    {
        _4069 = NOVALUE;
        goto L2; // [55] 69
    }
    else{
        _4069 = NOVALUE;
    }

    /** pretty.e:26			pretty_chars += 1*/
    _26pretty_chars_7538 = _26pretty_chars_7538 + 1;
    goto L3; // [66] 81
L2: 

    /** pretty.e:28			pretty_chars += length(text)*/
    if (IS_SEQUENCE(_text_7556)){
            _4071 = SEQ_PTR(_text_7556)->length;
    }
    else {
        _4071 = 1;
    }
    _26pretty_chars_7538 = _26pretty_chars_7538 + _4071;
    _4071 = NOVALUE;
L3: 

    /** pretty.e:30	end procedure*/
    DeRef(_text_7556);
    return;
    ;
}


void _26cut_line(object _n_7570)
{
    object _4074 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:34		if not pretty_line_breaks then	*/
    if (_26pretty_line_breaks_7549 != 0)
    goto L1; // [7] 21

    /** pretty.e:35			pretty_chars = 0*/
    _26pretty_chars_7538 = 0;

    /** pretty.e:36			return*/
    return;
L1: 

    /** pretty.e:38		if pretty_chars + n > pretty_end_col then*/
    _4074 = _26pretty_chars_7538 + _n_7570;
    if ((object)((uintptr_t)_4074 + (uintptr_t)HIGH_BITS) >= 0){
        _4074 = NewDouble((eudouble)_4074);
    }
    if (binary_op_a(LESSEQ, _4074, _26pretty_end_col_7537)){
        DeRef(_4074);
        _4074 = NOVALUE;
        goto L2; // [31] 46
    }
    DeRef(_4074);
    _4074 = NOVALUE;

    /** pretty.e:39			pretty_out('\n')*/
    _26pretty_out(10);

    /** pretty.e:40			pretty_chars = 0*/
    _26pretty_chars_7538 = 0;
L2: 

    /** pretty.e:42	end procedure*/
    return;
    ;
}


void _26indent()
{
    object _4082 = NOVALUE;
    object _4081 = NOVALUE;
    object _4080 = NOVALUE;
    object _4079 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:46		if pretty_line_breaks = 0 then	*/
    if (_26pretty_line_breaks_7549 != 0)
    goto L1; // [5] 22

    /** pretty.e:47			pretty_chars = 0*/
    _26pretty_chars_7538 = 0;

    /** pretty.e:48			return*/
    return;
    goto L2; // [19] 85
L1: 

    /** pretty.e:49		elsif pretty_line_breaks = -1 then*/
    if (_26pretty_line_breaks_7549 != -1)
    goto L3; // [26] 38

    /** pretty.e:51			cut_line( 0 )*/
    _26cut_line(0);
    goto L2; // [35] 85
L3: 

    /** pretty.e:54			if pretty_chars > 0 then*/
    if (_26pretty_chars_7538 <= 0)
    goto L4; // [42] 57

    /** pretty.e:55				pretty_out('\n')*/
    _26pretty_out(10);

    /** pretty.e:56				pretty_chars = 0*/
    _26pretty_chars_7538 = 0;
L4: 

    /** pretty.e:58			pretty_out(repeat(' ', (pretty_start_col-1) + */
    _4079 = _26pretty_start_col_7539 - 1;
    if ((object)((uintptr_t)_4079 +(uintptr_t) HIGH_BITS) >= 0){
        _4079 = NewDouble((eudouble)_4079);
    }
    if (_26pretty_level_7540 == (short)_26pretty_level_7540 && _26pretty_indent_7543 <= INT15 && _26pretty_indent_7543 >= -INT15){
        _4080 = _26pretty_level_7540 * _26pretty_indent_7543;
    }
    else{
        _4080 = NewDouble(_26pretty_level_7540 * (eudouble)_26pretty_indent_7543);
    }
    if (IS_ATOM_INT(_4079) && IS_ATOM_INT(_4080)) {
        _4081 = _4079 + _4080;
    }
    else {
        if (IS_ATOM_INT(_4079)) {
            _4081 = NewDouble((eudouble)_4079 + DBL_PTR(_4080)->dbl);
        }
        else {
            if (IS_ATOM_INT(_4080)) {
                _4081 = NewDouble(DBL_PTR(_4079)->dbl + (eudouble)_4080);
            }
            else
            _4081 = NewDouble(DBL_PTR(_4079)->dbl + DBL_PTR(_4080)->dbl);
        }
    }
    DeRef(_4079);
    _4079 = NOVALUE;
    DeRef(_4080);
    _4080 = NOVALUE;
    _4082 = Repeat(32, _4081);
    DeRef(_4081);
    _4081 = NOVALUE;
    _26pretty_out(_4082);
    _4082 = NOVALUE;
L2: 

    /** pretty.e:62	end procedure*/
    return;
    ;
}


object _26esc_char(object _a_7591)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_7591)) {
        _1 = (object)(DBL_PTR(_a_7591)->dbl);
        DeRefDS(_a_7591);
        _a_7591 = _1;
    }

    /** pretty.e:66		switch a do*/
    _0 = _a_7591;
    switch ( _0 ){ 

        /** pretty.e:67			case'\t' then*/
        case 9:

        /** pretty.e:68				return `\t`*/
        RefDS(_4085);
        return _4085;
        goto L1; // [20] 81

        /** pretty.e:70			case'\n' then*/
        case 10:

        /** pretty.e:71				return `\n`*/
        RefDS(_4086);
        return _4086;
        goto L1; // [32] 81

        /** pretty.e:73			case'\r' then*/
        case 13:

        /** pretty.e:74				return `\r`*/
        RefDS(_4087);
        return _4087;
        goto L1; // [44] 81

        /** pretty.e:76			case'\\' then*/
        case 92:

        /** pretty.e:77				return `\\`*/
        RefDS(_948);
        return _948;
        goto L1; // [56] 81

        /** pretty.e:79			case'"' then*/
        case 34:

        /** pretty.e:80				return `\"`*/
        RefDS(_4088);
        return _4088;
        goto L1; // [68] 81

        /** pretty.e:82			case else*/
        default:

        /** pretty.e:83				return a*/
        return _a_7591;
    ;}L1: 
    ;
}


void _26rPrint(object _a_7606)
{
    object _sbuff_7607 = NOVALUE;
    object _multi_line_7608 = NOVALUE;
    object _all_ascii_7609 = NOVALUE;
    object _4145 = NOVALUE;
    object _4144 = NOVALUE;
    object _4143 = NOVALUE;
    object _4142 = NOVALUE;
    object _4138 = NOVALUE;
    object _4137 = NOVALUE;
    object _4136 = NOVALUE;
    object _4135 = NOVALUE;
    object _4133 = NOVALUE;
    object _4132 = NOVALUE;
    object _4130 = NOVALUE;
    object _4129 = NOVALUE;
    object _4127 = NOVALUE;
    object _4126 = NOVALUE;
    object _4125 = NOVALUE;
    object _4124 = NOVALUE;
    object _4123 = NOVALUE;
    object _4122 = NOVALUE;
    object _4121 = NOVALUE;
    object _4120 = NOVALUE;
    object _4119 = NOVALUE;
    object _4118 = NOVALUE;
    object _4117 = NOVALUE;
    object _4116 = NOVALUE;
    object _4115 = NOVALUE;
    object _4114 = NOVALUE;
    object _4113 = NOVALUE;
    object _4112 = NOVALUE;
    object _4111 = NOVALUE;
    object _4107 = NOVALUE;
    object _4106 = NOVALUE;
    object _4105 = NOVALUE;
    object _4104 = NOVALUE;
    object _4103 = NOVALUE;
    object _4102 = NOVALUE;
    object _4100 = NOVALUE;
    object _4099 = NOVALUE;
    object _4095 = NOVALUE;
    object _4094 = NOVALUE;
    object _4093 = NOVALUE;
    object _4090 = NOVALUE;
    object _4089 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:92		if atom(a) then*/
    _4089 = IS_ATOM(_a_7606);
    if (_4089 == 0)
    {
        _4089 = NOVALUE;
        goto L1; // [6] 176
    }
    else{
        _4089 = NOVALUE;
    }

    /** pretty.e:93			if integer(a) then*/
    if (IS_ATOM_INT(_a_7606))
    _4090 = 1;
    else if (IS_ATOM_DBL(_a_7606))
    _4090 = IS_ATOM_INT(DoubleToInt(_a_7606));
    else
    _4090 = 0;
    if (_4090 == 0)
    {
        _4090 = NOVALUE;
        goto L2; // [14] 157
    }
    else{
        _4090 = NOVALUE;
    }

    /** pretty.e:94				sbuff = sprintf(pretty_int_format, a)*/
    DeRef(_sbuff_7607);
    _sbuff_7607 = EPrintf(-9999999, _26pretty_int_format_7552, _a_7606);

    /** pretty.e:95				if pretty_ascii then */
    if (_26pretty_ascii_7542 == 0)
    {
        goto L3; // [29] 166
    }
    else{
    }

    /** pretty.e:96					if pretty_ascii >= 3 then */
    if (_26pretty_ascii_7542 < 3)
    goto L4; // [36] 103

    /** pretty.e:98						if (a >= pretty_ascii_min and a <= pretty_ascii_max) then*/
    if (IS_ATOM_INT(_a_7606)) {
        _4093 = (_a_7606 >= _26pretty_ascii_min_7544);
    }
    else {
        _4093 = binary_op(GREATEREQ, _a_7606, _26pretty_ascii_min_7544);
    }
    if (IS_ATOM_INT(_4093)) {
        if (_4093 == 0) {
            _4094 = 0;
            goto L5; // [48] 62
        }
    }
    else {
        if (DBL_PTR(_4093)->dbl == 0.0) {
            _4094 = 0;
            goto L5; // [48] 62
        }
    }
    if (IS_ATOM_INT(_a_7606)) {
        _4095 = (_a_7606 <= _26pretty_ascii_max_7545);
    }
    else {
        _4095 = binary_op(LESSEQ, _a_7606, _26pretty_ascii_max_7545);
    }
    DeRef(_4094);
    if (IS_ATOM_INT(_4095))
    _4094 = (_4095 != 0);
    else
    _4094 = DBL_PTR(_4095)->dbl != 0.0;
L5: 
    if (_4094 == 0)
    {
        _4094 = NOVALUE;
        goto L6; // [62] 76
    }
    else{
        _4094 = NOVALUE;
    }

    /** pretty.e:99							sbuff = '\'' & a & '\''  -- display char only*/
    {
        object concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _a_7606;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_sbuff_7607, concat_list, 3);
    }
    goto L3; // [73] 166
L6: 

    /** pretty.e:101						elsif find(a, "\t\n\r\\") then*/
    _4099 = find_from(_a_7606, _4098, 1);
    if (_4099 == 0)
    {
        _4099 = NOVALUE;
        goto L3; // [83] 166
    }
    else{
        _4099 = NOVALUE;
    }

    /** pretty.e:102							sbuff = '\'' & esc_char(a) & '\''  -- display char only*/
    Ref(_a_7606);
    _4100 = _26esc_char(_a_7606);
    {
        object concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _4100;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_sbuff_7607, concat_list, 3);
    }
    DeRef(_4100);
    _4100 = NOVALUE;
    goto L3; // [100] 166
L4: 

    /** pretty.e:107						if (a >= pretty_ascii_min and a <= pretty_ascii_max) and pretty_ascii < 2 then*/
    if (IS_ATOM_INT(_a_7606)) {
        _4102 = (_a_7606 >= _26pretty_ascii_min_7544);
    }
    else {
        _4102 = binary_op(GREATEREQ, _a_7606, _26pretty_ascii_min_7544);
    }
    if (IS_ATOM_INT(_4102)) {
        if (_4102 == 0) {
            DeRef(_4103);
            _4103 = 0;
            goto L7; // [111] 125
        }
    }
    else {
        if (DBL_PTR(_4102)->dbl == 0.0) {
            DeRef(_4103);
            _4103 = 0;
            goto L7; // [111] 125
        }
    }
    if (IS_ATOM_INT(_a_7606)) {
        _4104 = (_a_7606 <= _26pretty_ascii_max_7545);
    }
    else {
        _4104 = binary_op(LESSEQ, _a_7606, _26pretty_ascii_max_7545);
    }
    DeRef(_4103);
    if (IS_ATOM_INT(_4104))
    _4103 = (_4104 != 0);
    else
    _4103 = DBL_PTR(_4104)->dbl != 0.0;
L7: 
    if (_4103 == 0) {
        goto L3; // [125] 166
    }
    _4106 = (_26pretty_ascii_7542 < 2);
    if (_4106 == 0)
    {
        DeRef(_4106);
        _4106 = NOVALUE;
        goto L3; // [136] 166
    }
    else{
        DeRef(_4106);
        _4106 = NOVALUE;
    }

    /** pretty.e:108							sbuff &= '\'' & a & '\'' -- add to numeric display*/
    {
        object concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _a_7606;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_4107, concat_list, 3);
    }
    Concat((object_ptr)&_sbuff_7607, _sbuff_7607, _4107);
    DeRefDS(_4107);
    _4107 = NOVALUE;
    goto L3; // [154] 166
L2: 

    /** pretty.e:113				sbuff = sprintf(pretty_fp_format, a)*/
    DeRef(_sbuff_7607);
    _sbuff_7607 = EPrintf(-9999999, _26pretty_fp_format_7551, _a_7606);
L3: 

    /** pretty.e:115			pretty_out(sbuff)*/
    RefDS(_sbuff_7607);
    _26pretty_out(_sbuff_7607);
    goto L8; // [173] 535
L1: 

    /** pretty.e:119			cut_line(1)*/
    _26cut_line(1);

    /** pretty.e:120			multi_line = 0*/
    _multi_line_7608 = 0;

    /** pretty.e:121			all_ascii = pretty_ascii > 1*/
    _all_ascii_7609 = (_26pretty_ascii_7542 > 1);

    /** pretty.e:122			for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_7606)){
            _4111 = SEQ_PTR(_a_7606)->length;
    }
    else {
        _4111 = 1;
    }
    {
        object _i_7643;
        _i_7643 = 1;
L9: 
        if (_i_7643 > _4111){
            goto LA; // [199] 345
        }

        /** pretty.e:123				if sequence(a[i]) and length(a[i]) > 0 then*/
        _2 = (object)SEQ_PTR(_a_7606);
        _4112 = (object)*(((s1_ptr)_2)->base + _i_7643);
        _4113 = IS_SEQUENCE(_4112);
        _4112 = NOVALUE;
        if (_4113 == 0) {
            goto LB; // [215] 249
        }
        _2 = (object)SEQ_PTR(_a_7606);
        _4115 = (object)*(((s1_ptr)_2)->base + _i_7643);
        if (IS_SEQUENCE(_4115)){
                _4116 = SEQ_PTR(_4115)->length;
        }
        else {
            _4116 = 1;
        }
        _4115 = NOVALUE;
        _4117 = (_4116 > 0);
        _4116 = NOVALUE;
        if (_4117 == 0)
        {
            DeRef(_4117);
            _4117 = NOVALUE;
            goto LB; // [231] 249
        }
        else{
            DeRef(_4117);
            _4117 = NOVALUE;
        }

        /** pretty.e:124					multi_line = 1*/
        _multi_line_7608 = 1;

        /** pretty.e:125					all_ascii = 0*/
        _all_ascii_7609 = 0;

        /** pretty.e:126					exit*/
        goto LA; // [246] 345
LB: 

        /** pretty.e:128				if not integer(a[i]) or*/
        _2 = (object)SEQ_PTR(_a_7606);
        _4118 = (object)*(((s1_ptr)_2)->base + _i_7643);
        if (IS_ATOM_INT(_4118))
        _4119 = 1;
        else if (IS_ATOM_DBL(_4118))
        _4119 = IS_ATOM_INT(DoubleToInt(_4118));
        else
        _4119 = 0;
        _4118 = NOVALUE;
        _4120 = (_4119 == 0);
        _4119 = NOVALUE;
        if (_4120 != 0) {
            _4121 = 1;
            goto LC; // [261] 313
        }
        _2 = (object)SEQ_PTR(_a_7606);
        _4122 = (object)*(((s1_ptr)_2)->base + _i_7643);
        if (IS_ATOM_INT(_4122)) {
            _4123 = (_4122 < _26pretty_ascii_min_7544);
        }
        else {
            _4123 = binary_op(LESS, _4122, _26pretty_ascii_min_7544);
        }
        _4122 = NOVALUE;
        if (IS_ATOM_INT(_4123)) {
            if (_4123 == 0) {
                DeRef(_4124);
                _4124 = 0;
                goto LD; // [275] 309
            }
        }
        else {
            if (DBL_PTR(_4123)->dbl == 0.0) {
                DeRef(_4124);
                _4124 = 0;
                goto LD; // [275] 309
            }
        }
        _4125 = (_26pretty_ascii_7542 < 2);
        if (_4125 != 0) {
            _4126 = 1;
            goto LE; // [285] 305
        }
        _2 = (object)SEQ_PTR(_a_7606);
        _4127 = (object)*(((s1_ptr)_2)->base + _i_7643);
        _4129 = find_from(_4127, _4128, 1);
        _4127 = NOVALUE;
        _4130 = (_4129 == 0);
        _4129 = NOVALUE;
        _4126 = (_4130 != 0);
LE: 
        DeRef(_4124);
        _4124 = (_4126 != 0);
LD: 
        _4121 = (_4124 != 0);
LC: 
        if (_4121 != 0) {
            goto LF; // [313] 332
        }
        _2 = (object)SEQ_PTR(_a_7606);
        _4132 = (object)*(((s1_ptr)_2)->base + _i_7643);
        if (IS_ATOM_INT(_4132)) {
            _4133 = (_4132 > _26pretty_ascii_max_7545);
        }
        else {
            _4133 = binary_op(GREATER, _4132, _26pretty_ascii_max_7545);
        }
        _4132 = NOVALUE;
        if (_4133 == 0) {
            DeRef(_4133);
            _4133 = NOVALUE;
            goto L10; // [328] 338
        }
        else {
            if (!IS_ATOM_INT(_4133) && DBL_PTR(_4133)->dbl == 0.0){
                DeRef(_4133);
                _4133 = NOVALUE;
                goto L10; // [328] 338
            }
            DeRef(_4133);
            _4133 = NOVALUE;
        }
        DeRef(_4133);
        _4133 = NOVALUE;
LF: 

        /** pretty.e:132					all_ascii = 0*/
        _all_ascii_7609 = 0;
L10: 

        /** pretty.e:134			end for*/
        _i_7643 = _i_7643 + 1;
        goto L9; // [340] 206
LA: 
        ;
    }

    /** pretty.e:136			if all_ascii then*/
    if (_all_ascii_7609 == 0)
    {
        goto L11; // [347] 358
    }
    else{
    }

    /** pretty.e:137				pretty_out('\"')*/
    _26pretty_out(34);
    goto L12; // [355] 364
L11: 

    /** pretty.e:139				pretty_out('{')*/
    _26pretty_out(123);
L12: 

    /** pretty.e:141			pretty_level += 1*/
    _26pretty_level_7540 = _26pretty_level_7540 + 1;

    /** pretty.e:142			for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_7606)){
            _4135 = SEQ_PTR(_a_7606)->length;
    }
    else {
        _4135 = 1;
    }
    {
        object _i_7673;
        _i_7673 = 1;
L13: 
        if (_i_7673 > _4135){
            goto L14; // [377] 497
        }

        /** pretty.e:143				if multi_line then*/
        if (_multi_line_7608 == 0)
        {
            goto L15; // [386] 394
        }
        else{
        }

        /** pretty.e:144					indent()*/
        _26indent();
L15: 

        /** pretty.e:146				if all_ascii then*/
        if (_all_ascii_7609 == 0)
        {
            goto L16; // [396] 415
        }
        else{
        }

        /** pretty.e:147					pretty_out(esc_char(a[i]))*/
        _2 = (object)SEQ_PTR(_a_7606);
        _4136 = (object)*(((s1_ptr)_2)->base + _i_7673);
        Ref(_4136);
        _4137 = _26esc_char(_4136);
        _4136 = NOVALUE;
        _26pretty_out(_4137);
        _4137 = NOVALUE;
        goto L17; // [412] 425
L16: 

        /** pretty.e:149					rPrint(a[i])*/
        _2 = (object)SEQ_PTR(_a_7606);
        _4138 = (object)*(((s1_ptr)_2)->base + _i_7673);
        Ref(_4138);
        _26rPrint(_4138);
        _4138 = NOVALUE;
L17: 

        /** pretty.e:151				if pretty_line_count >= pretty_line_max then*/
        if (_26pretty_line_count_7546 < _26pretty_line_max_7547)
        goto L18; // [431] 459

        /** pretty.e:152					if not pretty_dots then*/
        if (_26pretty_dots_7548 != 0)
        goto L19; // [439] 448

        /** pretty.e:153						pretty_out(" ...")*/
        RefDS(_4141);
        _26pretty_out(_4141);
L19: 

        /** pretty.e:155					pretty_dots = 1*/
        _26pretty_dots_7548 = 1;

        /** pretty.e:156					return*/
        DeRef(_a_7606);
        DeRef(_sbuff_7607);
        DeRef(_4120);
        _4120 = NOVALUE;
        DeRef(_4102);
        _4102 = NOVALUE;
        DeRef(_4123);
        _4123 = NOVALUE;
        DeRef(_4104);
        _4104 = NOVALUE;
        DeRef(_4125);
        _4125 = NOVALUE;
        DeRef(_4093);
        _4093 = NOVALUE;
        DeRef(_4095);
        _4095 = NOVALUE;
        DeRef(_4130);
        _4130 = NOVALUE;
        _4115 = NOVALUE;
        return;
L18: 

        /** pretty.e:158				if i != length(a) and not all_ascii then*/
        if (IS_SEQUENCE(_a_7606)){
                _4142 = SEQ_PTR(_a_7606)->length;
        }
        else {
            _4142 = 1;
        }
        _4143 = (_i_7673 != _4142);
        _4142 = NOVALUE;
        if (_4143 == 0) {
            goto L1A; // [468] 490
        }
        _4145 = (_all_ascii_7609 == 0);
        if (_4145 == 0)
        {
            DeRef(_4145);
            _4145 = NOVALUE;
            goto L1A; // [476] 490
        }
        else{
            DeRef(_4145);
            _4145 = NOVALUE;
        }

        /** pretty.e:159					pretty_out(',')*/
        _26pretty_out(44);

        /** pretty.e:160					cut_line(6)*/
        _26cut_line(6);
L1A: 

        /** pretty.e:162			end for*/
        _i_7673 = _i_7673 + 1;
        goto L13; // [492] 384
L14: 
        ;
    }

    /** pretty.e:163			pretty_level -= 1*/
    _26pretty_level_7540 = _26pretty_level_7540 - 1;

    /** pretty.e:164			if multi_line then*/
    if (_multi_line_7608 == 0)
    {
        goto L1B; // [507] 515
    }
    else{
    }

    /** pretty.e:165				indent()*/
    _26indent();
L1B: 

    /** pretty.e:167			if all_ascii then*/
    if (_all_ascii_7609 == 0)
    {
        goto L1C; // [517] 528
    }
    else{
    }

    /** pretty.e:168				pretty_out('\"')*/
    _26pretty_out(34);
    goto L1D; // [525] 534
L1C: 

    /** pretty.e:170				pretty_out('}')*/
    _26pretty_out(125);
L1D: 
L8: 

    /** pretty.e:173	end procedure*/
    DeRef(_a_7606);
    DeRef(_sbuff_7607);
    DeRef(_4120);
    _4120 = NOVALUE;
    DeRef(_4102);
    _4102 = NOVALUE;
    DeRef(_4123);
    _4123 = NOVALUE;
    DeRef(_4143);
    _4143 = NOVALUE;
    DeRef(_4104);
    _4104 = NOVALUE;
    DeRef(_4125);
    _4125 = NOVALUE;
    DeRef(_4093);
    _4093 = NOVALUE;
    DeRef(_4095);
    _4095 = NOVALUE;
    DeRef(_4130);
    _4130 = NOVALUE;
    _4115 = NOVALUE;
    return;
    ;
}


void _26pretty(object _x_7712, object _options_7713)
{
    object _4152 = NOVALUE;
    object _4151 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:197		if length(options) < length( PRETTY_DEFAULT ) then*/
    _4151 = 10;
    _4152 = 10;

    /** pretty.e:202		pretty_ascii = options[DISPLAY_ASCII] */
    _2 = (object)SEQ_PTR(_options_7713);
    _26pretty_ascii_7542 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_26pretty_ascii_7542))
    _26pretty_ascii_7542 = (object)DBL_PTR(_26pretty_ascii_7542)->dbl;

    /** pretty.e:203		pretty_indent = options[INDENT]*/
    _2 = (object)SEQ_PTR(_options_7713);
    _26pretty_indent_7543 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_26pretty_indent_7543))
    _26pretty_indent_7543 = (object)DBL_PTR(_26pretty_indent_7543)->dbl;

    /** pretty.e:204		pretty_start_col = options[START_COLUMN]*/
    _2 = (object)SEQ_PTR(_options_7713);
    _26pretty_start_col_7539 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_26pretty_start_col_7539))
    _26pretty_start_col_7539 = (object)DBL_PTR(_26pretty_start_col_7539)->dbl;

    /** pretty.e:205		pretty_end_col = options[WRAP]*/
    _2 = (object)SEQ_PTR(_options_7713);
    _26pretty_end_col_7537 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_26pretty_end_col_7537))
    _26pretty_end_col_7537 = (object)DBL_PTR(_26pretty_end_col_7537)->dbl;

    /** pretty.e:206		pretty_int_format = options[INT_FORMAT]*/
    DeRef(_26pretty_int_format_7552);
    _2 = (object)SEQ_PTR(_options_7713);
    _26pretty_int_format_7552 = (object)*(((s1_ptr)_2)->base + 5);
    Ref(_26pretty_int_format_7552);

    /** pretty.e:207		pretty_fp_format = options[FP_FORMAT]*/
    DeRef(_26pretty_fp_format_7551);
    _2 = (object)SEQ_PTR(_options_7713);
    _26pretty_fp_format_7551 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_26pretty_fp_format_7551);

    /** pretty.e:208		pretty_ascii_min = options[MIN_ASCII]*/
    _2 = (object)SEQ_PTR(_options_7713);
    _26pretty_ascii_min_7544 = (object)*(((s1_ptr)_2)->base + 7);
    if (!IS_ATOM_INT(_26pretty_ascii_min_7544))
    _26pretty_ascii_min_7544 = (object)DBL_PTR(_26pretty_ascii_min_7544)->dbl;

    /** pretty.e:209		pretty_ascii_max = options[MAX_ASCII]*/
    _2 = (object)SEQ_PTR(_options_7713);
    _26pretty_ascii_max_7545 = (object)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_26pretty_ascii_max_7545))
    _26pretty_ascii_max_7545 = (object)DBL_PTR(_26pretty_ascii_max_7545)->dbl;

    /** pretty.e:210		pretty_line_max = options[MAX_LINES]*/
    _2 = (object)SEQ_PTR(_options_7713);
    _26pretty_line_max_7547 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_26pretty_line_max_7547))
    _26pretty_line_max_7547 = (object)DBL_PTR(_26pretty_line_max_7547)->dbl;

    /** pretty.e:211		pretty_line_breaks = options[LINE_BREAKS]*/
    _2 = (object)SEQ_PTR(_options_7713);
    _26pretty_line_breaks_7549 = (object)*(((s1_ptr)_2)->base + 10);
    if (!IS_ATOM_INT(_26pretty_line_breaks_7549))
    _26pretty_line_breaks_7549 = (object)DBL_PTR(_26pretty_line_breaks_7549)->dbl;

    /** pretty.e:213		pretty_chars = pretty_start_col*/
    _26pretty_chars_7538 = _26pretty_start_col_7539;

    /** pretty.e:215		pretty_level = 0 */
    _26pretty_level_7540 = 0;

    /** pretty.e:216		pretty_line = ""*/
    RefDS(_5);
    DeRef(_26pretty_line_7553);
    _26pretty_line_7553 = _5;

    /** pretty.e:217		pretty_line_count = 0*/
    _26pretty_line_count_7546 = 0;

    /** pretty.e:218		pretty_dots = 0*/
    _26pretty_dots_7548 = 0;

    /** pretty.e:219		rPrint(x)*/
    Ref(_x_7712);
    _26rPrint(_x_7712);

    /** pretty.e:220	end procedure*/
    DeRef(_x_7712);
    DeRefDS(_options_7713);
    return;
    ;
}



// 0x49348164
