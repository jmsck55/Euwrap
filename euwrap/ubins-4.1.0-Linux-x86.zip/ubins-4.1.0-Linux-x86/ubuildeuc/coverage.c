// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _51check_coverage()
{
    object _25107 = NOVALUE;
    object _25106 = NOVALUE;
    object _25105 = NOVALUE;
    object _25104 = NOVALUE;
    object _25103 = NOVALUE;
    object _25102 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:45		for i = length( file_coverage ) + 1 to length( known_files ) do*/
    if (IS_SEQUENCE(_51file_coverage_48825)){
            _25102 = SEQ_PTR(_51file_coverage_48825)->length;
    }
    else {
        _25102 = 1;
    }
    _25103 = _25102 + 1;
    _25102 = NOVALUE;
    if (IS_SEQUENCE(_37known_files_15407)){
            _25104 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _25104 = 1;
    }
    {
        object _i_48836;
        _i_48836 = _25103;
L1: 
        if (_i_48836 > _25104){
            goto L2; // [17] 58
        }

        /** coverage.e:46			file_coverage &= find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (object)SEQ_PTR(_37known_files_15407);
        _25105 = (object)*(((s1_ptr)_2)->base + _i_48836);
        Ref(_25105);
        _25106 = _17canonical_path(_25105, 0, 1);
        _25105 = NOVALUE;
        _25107 = find_from(_25106, _51covered_files_48824, 1);
        DeRef(_25106);
        _25106 = NOVALUE;
        Append(&_51file_coverage_48825, _51file_coverage_48825, _25107);
        _25107 = NOVALUE;

        /** coverage.e:47		end for*/
        _i_48836 = _i_48836 + 1;
        goto L1; // [53] 24
L2: 
        ;
    }

    /** coverage.e:48	end procedure*/
    DeRef(_25103);
    _25103 = NOVALUE;
    return;
    ;
}


void _51init_coverage()
{
    object _cmd_48860 = NOVALUE;
    object _25125 = NOVALUE;
    object _25124 = NOVALUE;
    object _25122 = NOVALUE;
    object _25121 = NOVALUE;
    object _25120 = NOVALUE;
    object _25118 = NOVALUE;
    object _25116 = NOVALUE;
    object _25115 = NOVALUE;
    object _25113 = NOVALUE;
    object _25112 = NOVALUE;
    object _25111 = NOVALUE;
    object _25110 = NOVALUE;
    object _25109 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:54		if initialized_coverage then*/
    if (_51initialized_coverage_48832 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** coverage.e:55			return*/
    return;
L1: 

    /** coverage.e:57		initialized_coverage = 1*/
    _51initialized_coverage_48832 = 1;

    /** coverage.e:58		for i = 1 to length( file_coverage ) do*/
    if (IS_SEQUENCE(_51file_coverage_48825)){
            _25109 = SEQ_PTR(_51file_coverage_48825)->length;
    }
    else {
        _25109 = 1;
    }
    {
        object _i_48851;
        _i_48851 = 1;
L2: 
        if (_i_48851 > _25109){
            goto L3; // [26] 67
        }

        /** coverage.e:59			file_coverage[i] = find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (object)SEQ_PTR(_37known_files_15407);
        _25110 = (object)*(((s1_ptr)_2)->base + _i_48851);
        Ref(_25110);
        _25111 = _17canonical_path(_25110, 0, 1);
        _25110 = NOVALUE;
        _25112 = find_from(_25111, _51covered_files_48824, 1);
        DeRef(_25111);
        _25111 = NOVALUE;
        _2 = (object)SEQ_PTR(_51file_coverage_48825);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _51file_coverage_48825 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_48851);
        *(intptr_t *)_2 = _25112;
        if( _1 != _25112 ){
        }
        _25112 = NOVALUE;

        /** coverage.e:60		end for*/
        _i_48851 = _i_48851 + 1;
        goto L2; // [62] 33
L3: 
        ;
    }

    /** coverage.e:62		if equal( coverage_db_name, "" ) then*/
    if (_51coverage_db_name_48826 == _21997)
    _25113 = 1;
    else if (IS_ATOM_INT(_51coverage_db_name_48826) && IS_ATOM_INT(_21997))
    _25113 = 0;
    else
    _25113 = (compare(_51coverage_db_name_48826, _21997) == 0);
    if (_25113 == 0)
    {
        _25113 = NOVALUE;
        goto L4; // [75] 105
    }
    else{
        _25113 = NOVALUE;
    }

    /** coverage.e:63			sequence cmd = command_line()*/
    DeRef(_cmd_48860);
    _cmd_48860 = Command_Line();

    /** coverage.e:64			coverage_db_name = canonical_path( filebase( cmd[2] ) & "-cvg.edb" )*/
    _2 = (object)SEQ_PTR(_cmd_48860);
    _25115 = (object)*(((s1_ptr)_2)->base + 2);
    RefDS(_25115);
    _25116 = _17filebase(_25115);
    _25115 = NOVALUE;
    if (IS_SEQUENCE(_25116) && IS_ATOM(_25117)) {
    }
    else if (IS_ATOM(_25116) && IS_SEQUENCE(_25117)) {
        Ref(_25116);
        Prepend(&_25118, _25117, _25116);
    }
    else {
        Concat((object_ptr)&_25118, _25116, _25117);
        DeRef(_25116);
        _25116 = NOVALUE;
    }
    DeRef(_25116);
    _25116 = NOVALUE;
    _0 = _17canonical_path(_25118, 0, 0);
    DeRefDS(_51coverage_db_name_48826);
    _51coverage_db_name_48826 = _0;
    _25118 = NOVALUE;
L4: 
    DeRef(_cmd_48860);
    _cmd_48860 = NOVALUE;

    /** coverage.e:67		if coverage_erase and file_exists( coverage_db_name ) then*/
    if (0 == 0) {
        goto L5; // [111] 153
    }
    RefDS(_51coverage_db_name_48826);
    _25121 = _17file_exists(_51coverage_db_name_48826);
    if (_25121 == 0) {
        DeRef(_25121);
        _25121 = NOVALUE;
        goto L5; // [122] 153
    }
    else {
        if (!IS_ATOM_INT(_25121) && DBL_PTR(_25121)->dbl == 0.0){
            DeRef(_25121);
            _25121 = NOVALUE;
            goto L5; // [122] 153
        }
        DeRef(_25121);
        _25121 = NOVALUE;
    }
    DeRef(_25121);
    _25121 = NOVALUE;

    /** coverage.e:68			if not delete_file( coverage_db_name ) then*/
    RefDS(_51coverage_db_name_48826);
    _25122 = _17delete_file(_51coverage_db_name_48826);
    if (IS_ATOM_INT(_25122)) {
        if (_25122 != 0){
            DeRef(_25122);
            _25122 = NOVALUE;
            goto L6; // [133] 152
        }
    }
    else {
        if (DBL_PTR(_25122)->dbl != 0.0){
            DeRef(_25122);
            _25122 = NOVALUE;
            goto L6; // [133] 152
        }
    }
    DeRef(_25122);
    _25122 = NOVALUE;

    /** coverage.e:69				CompileErr( COULD_NOT_ERASE_COVERAGE_DATABASE_1, { coverage_db_name } )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_51coverage_db_name_48826);
    ((intptr_t*)_2)[1] = _51coverage_db_name_48826;
    _25124 = MAKE_SEQ(_1);
    _50CompileErr(335, _25124, 0);
    _25124 = NOVALUE;
L6: 
L5: 

    /** coverage.e:73		if db_open( coverage_db_name ) = DB_OK then*/
    RefDS(_51coverage_db_name_48826);
    _25125 = _43db_open(_51coverage_db_name_48826, 0);
    if (binary_op_a(NOTEQ, _25125, 0)){
        DeRef(_25125);
        _25125 = NOVALUE;
        goto L7; // [164] 177
    }
    DeRef(_25125);
    _25125 = NOVALUE;

    /** coverage.e:74			read_coverage_db()*/
    _51read_coverage_db();

    /** coverage.e:75			db_close()*/
    _43db_close();
L7: 

    /** coverage.e:77	end procedure*/
    return;
    ;
}


void _51read_coverage_db()
{
    object _tables_48966 = NOVALUE;
    object _name_48972 = NOVALUE;
    object _fx_48976 = NOVALUE;
    object _the_map_48983 = NOVALUE;
    object _31703 = NOVALUE;
    object _25173 = NOVALUE;
    object _25172 = NOVALUE;
    object _25171 = NOVALUE;
    object _25167 = NOVALUE;
    object _25166 = NOVALUE;
    object _25165 = NOVALUE;
    object _25161 = NOVALUE;
    object _25160 = NOVALUE;
    object _25159 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:135		sequence tables = db_table_list()*/
    _0 = _tables_48966;
    _tables_48966 = _43db_table_list();
    DeRef(_0);

    /** coverage.e:137		for i = 1 to length( tables ) do*/
    if (IS_SEQUENCE(_tables_48966)){
            _25159 = SEQ_PTR(_tables_48966)->length;
    }
    else {
        _25159 = 1;
    }
    {
        object _i_48970;
        _i_48970 = 1;
L1: 
        if (_i_48970 > _25159){
            goto L2; // [13] 157
        }

        /** coverage.e:138			sequence name = tables[i][2..$]*/
        _2 = (object)SEQ_PTR(_tables_48966);
        _25160 = (object)*(((s1_ptr)_2)->base + _i_48970);
        if (IS_SEQUENCE(_25160)){
                _25161 = SEQ_PTR(_25160)->length;
        }
        else {
            _25161 = 1;
        }
        rhs_slice_target = (object_ptr)&_name_48972;
        RHS_Slice(_25160, 2, _25161);
        _25160 = NOVALUE;

        /** coverage.e:139			integer fx = find( name, covered_files )*/
        _fx_48976 = find_from(_name_48972, _51covered_files_48824, 1);

        /** coverage.e:140			if not fx then*/
        if (_fx_48976 != 0)
        goto L3; // [45] 55

        /** coverage.e:141				continue*/
        DeRefDS(_name_48972);
        _name_48972 = NOVALUE;
        DeRef(_the_map_48983);
        _the_map_48983 = NOVALUE;
        goto L4; // [52] 152
L3: 

        /** coverage.e:144			db_select_table( tables[i] )*/
        _2 = (object)SEQ_PTR(_tables_48966);
        _25165 = (object)*(((s1_ptr)_2)->base + _i_48970);
        Ref(_25165);
        _31703 = _43db_select_table(_25165);
        _25165 = NOVALUE;
        DeRef(_31703);
        _31703 = NOVALUE;

        /** coverage.e:146			if tables[i][1] = 'r' then*/
        _2 = (object)SEQ_PTR(_tables_48966);
        _25166 = (object)*(((s1_ptr)_2)->base + _i_48970);
        _2 = (object)SEQ_PTR(_25166);
        _25167 = (object)*(((s1_ptr)_2)->base + 1);
        _25166 = NOVALUE;
        if (binary_op_a(NOTEQ, _25167, 114)){
            _25167 = NOVALUE;
            goto L5; // [77] 92
        }
        _25167 = NOVALUE;

        /** coverage.e:148				the_map = routine_map[fx]*/
        DeRef(_the_map_48983);
        _2 = (object)SEQ_PTR(_51routine_map_48830);
        _the_map_48983 = (object)*(((s1_ptr)_2)->base + _fx_48976);
        Ref(_the_map_48983);
        goto L6; // [89] 101
L5: 

        /** coverage.e:152				the_map = line_map[fx]*/
        DeRef(_the_map_48983);
        _2 = (object)SEQ_PTR(_51line_map_48829);
        _the_map_48983 = (object)*(((s1_ptr)_2)->base + _fx_48976);
        Ref(_the_map_48983);
L6: 

        /** coverage.e:156			for j = 1 to db_table_size() do*/
        RefDS(_43current_table_name_16829);
        _25171 = _43db_table_size(_43current_table_name_16829);
        {
            object _j_48992;
            _j_48992 = 1;
L7: 
            if (binary_op_a(GREATER, _j_48992, _25171)){
                goto L8; // [109] 148
            }

            /** coverage.e:157				map:put( the_map, db_record_key( j ), db_record_data( j ), map:ADD )*/
            Ref(_j_48992);
            RefDS(_43current_table_name_16829);
            _25172 = _43db_record_key(_j_48992, _43current_table_name_16829);
            Ref(_j_48992);
            RefDS(_43current_table_name_16829);
            _25173 = _43db_record_data(_j_48992, _43current_table_name_16829);
            Ref(_the_map_48983);
            _29put(_the_map_48983, _25172, _25173, 2, 0);
            _25172 = NOVALUE;
            _25173 = NOVALUE;

            /** coverage.e:158			end for*/
            _0 = _j_48992;
            if (IS_ATOM_INT(_j_48992)) {
                _j_48992 = _j_48992 + 1;
                if ((object)((uintptr_t)_j_48992 +(uintptr_t) HIGH_BITS) >= 0){
                    _j_48992 = NewDouble((eudouble)_j_48992);
                }
            }
            else {
                _j_48992 = binary_op_a(PLUS, _j_48992, 1);
            }
            DeRef(_0);
            goto L7; // [143] 116
L8: 
            ;
            DeRef(_j_48992);
        }
        DeRef(_name_48972);
        _name_48972 = NOVALUE;
        DeRef(_the_map_48983);
        _the_map_48983 = NOVALUE;

        /** coverage.e:160		end for*/
L4: 
        _i_48970 = _i_48970 + 1;
        goto L1; // [152] 20
L2: 
        ;
    }

    /** coverage.e:161	end procedure*/
    DeRef(_tables_48966);
    DeRef(_25171);
    _25171 = NOVALUE;
    return;
    ;
}


object _51coverage_on()
{
    object _25174 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:170		return file_coverage[current_file_no]*/
    _2 = (object)SEQ_PTR(_51file_coverage_48825);
    _25174 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    return _25174;
    ;
}


void _51include_line(object _line_number_49132)
{
    object _25235 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:247		if coverage_on() then*/
    _25235 = _51coverage_on();
    if (_25235 == 0) {
        DeRef(_25235);
        _25235 = NOVALUE;
        goto L1; // [8] 34
    }
    else {
        if (!IS_ATOM_INT(_25235) && DBL_PTR(_25235)->dbl == 0.0){
            DeRef(_25235);
            _25235 = NOVALUE;
            goto L1; // [8] 34
        }
        DeRef(_25235);
        _25235 = NOVALUE;
    }
    DeRef(_25235);
    _25235 = NOVALUE;

    /** coverage.e:248			emit_op( COVERAGE_LINE )*/
    _47emit_op(210);

    /** coverage.e:249			emit_addr( gline_number )*/
    _47emit_addr(_36gline_number_21452);

    /** coverage.e:251			included_lines &= line_number*/
    Append(&_51included_lines_48831, _51included_lines_48831, _line_number_49132);
L1: 

    /** coverage.e:253	end procedure*/
    return;
    ;
}


void _51include_routine()
{
    object _file_no_49148 = NOVALUE;
    object _25242 = NOVALUE;
    object _25241 = NOVALUE;
    object _25240 = NOVALUE;
    object _25238 = NOVALUE;
    object _25237 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:256		if coverage_on() then*/
    _25237 = _51coverage_on();
    if (_25237 == 0) {
        DeRef(_25237);
        _25237 = NOVALUE;
        goto L1; // [6] 69
    }
    else {
        if (!IS_ATOM_INT(_25237) && DBL_PTR(_25237)->dbl == 0.0){
            DeRef(_25237);
            _25237 = NOVALUE;
            goto L1; // [6] 69
        }
        DeRef(_25237);
        _25237 = NOVALUE;
    }
    DeRef(_25237);
    _25237 = NOVALUE;

    /** coverage.e:257			emit_op( COVERAGE_ROUTINE )*/
    _47emit_op(211);

    /** coverage.e:258			emit_addr( CurrentSub )*/
    _47emit_addr(_36CurrentSub_21455);

    /** coverage.e:261			integer file_no = SymTab[CurrentSub][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25238 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21455);
    _2 = (object)SEQ_PTR(_25238);
    if (!IS_ATOM_INT(_36S_FILE_NO_21080)){
        _file_no_49148 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    }
    else{
        _file_no_49148 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    }
    if (!IS_ATOM_INT(_file_no_49148)){
        _file_no_49148 = (object)DBL_PTR(_file_no_49148)->dbl;
    }
    _25238 = NOVALUE;

    /** coverage.e:262			map:put( routine_map[file_coverage[file_no]], sym_name( CurrentSub ), 0, map:ADD )*/
    _2 = (object)SEQ_PTR(_51file_coverage_48825);
    _25240 = (object)*(((s1_ptr)_2)->base + _file_no_49148);
    _2 = (object)SEQ_PTR(_51routine_map_48830);
    _25241 = (object)*(((s1_ptr)_2)->base + _25240);
    _25242 = _54sym_name(_36CurrentSub_21455);
    Ref(_25241);
    _29put(_25241, _25242, 0, 2, 0);
    _25241 = NOVALUE;
    _25242 = NOVALUE;
L1: 

    /** coverage.e:264	end procedure*/
    _25240 = NOVALUE;
    return;
    ;
}



// 0x984091D4
