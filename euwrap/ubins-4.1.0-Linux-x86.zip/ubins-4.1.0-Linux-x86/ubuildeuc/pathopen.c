// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _48exe_path()
{
    object _25812 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:70		if sequence(exe_path_cache) then*/
    _25812 = IS_SEQUENCE(_48exe_path_cache_50364);
    if (_25812 == 0)
    {
        _25812 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25812 = NOVALUE;
    }

    /** pathopen.e:71			return exe_path_cache*/
    Ref(_48exe_path_cache_50364);
    return _48exe_path_cache_50364;
L1: 

    /** pathopen.e:74		exe_path_cache = command_line()*/
    DeRef(_48exe_path_cache_50364);
    _48exe_path_cache_50364 = Command_Line();

    /** pathopen.e:75		exe_path_cache = exe_path_cache[1]*/
    _0 = _48exe_path_cache_50364;
    _2 = (object)SEQ_PTR(_48exe_path_cache_50364);
    _48exe_path_cache_50364 = (object)*(((s1_ptr)_2)->base + 1);
    RefDS(_48exe_path_cache_50364);
    DeRefDS(_0);

    /** pathopen.e:77		return exe_path_cache*/
    RefDS(_48exe_path_cache_50364);
    return _48exe_path_cache_50364;
    ;
}


object _48check_cache(object _env_50376, object _inc_path_50377)
{
    object _delim_50378 = NOVALUE;
    object _pos_50379 = NOVALUE;
    object _25860 = NOVALUE;
    object _25859 = NOVALUE;
    object _25858 = NOVALUE;
    object _25857 = NOVALUE;
    object _25855 = NOVALUE;
    object _25854 = NOVALUE;
    object _25853 = NOVALUE;
    object _25852 = NOVALUE;
    object _25851 = NOVALUE;
    object _25850 = NOVALUE;
    object _25849 = NOVALUE;
    object _25848 = NOVALUE;
    object _25847 = NOVALUE;
    object _25843 = NOVALUE;
    object _25842 = NOVALUE;
    object _25841 = NOVALUE;
    object _25840 = NOVALUE;
    object _25839 = NOVALUE;
    object _25838 = NOVALUE;
    object _25837 = NOVALUE;
    object _25836 = NOVALUE;
    object _25834 = NOVALUE;
    object _25833 = NOVALUE;
    object _25832 = NOVALUE;
    object _25831 = NOVALUE;
    object _25830 = NOVALUE;
    object _25829 = NOVALUE;
    object _25827 = NOVALUE;
    object _25826 = NOVALUE;
    object _25825 = NOVALUE;
    object _25824 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:83		if not num_var then -- first time the var is accessed, add cache entry*/
    if (_48num_var_50353 != 0)
    goto L1; // [9] 86

    /** pathopen.e:84			cache_vars = append(cache_vars,env)*/
    RefDS(_env_50376);
    Append(&_48cache_vars_50354, _48cache_vars_50354, _env_50376);

    /** pathopen.e:85			cache_strings = append(cache_strings,inc_path)*/
    RefDS(_inc_path_50377);
    Append(&_48cache_strings_50355, _48cache_strings_50355, _inc_path_50377);

    /** pathopen.e:86			cache_substrings = append(cache_substrings,{})*/
    RefDS(_21997);
    Append(&_48cache_substrings_50356, _48cache_substrings_50356, _21997);

    /** pathopen.e:87			cache_starts = append(cache_starts,{})*/
    RefDS(_21997);
    Append(&_48cache_starts_50357, _48cache_starts_50357, _21997);

    /** pathopen.e:88			cache_ends = append(cache_ends,{})*/
    RefDS(_21997);
    Append(&_48cache_ends_50358, _48cache_ends_50358, _21997);

    /** pathopen.e:89			ifdef WINDOWS then*/

    /** pathopen.e:92			num_var = length(cache_vars)*/
    if (IS_SEQUENCE(_48cache_vars_50354)){
            _48num_var_50353 = SEQ_PTR(_48cache_vars_50354)->length;
    }
    else {
        _48num_var_50353 = 1;
    }

    /** pathopen.e:93			cache_complete &= 0*/
    Append(&_48cache_complete_50360, _48cache_complete_50360, 0);

    /** pathopen.e:94			cache_delims &= 0*/
    Append(&_48cache_delims_50361, _48cache_delims_50361, 0);

    /** pathopen.e:95			return 0*/
    DeRefDSi(_env_50376);
    DeRefDSi(_inc_path_50377);
    return 0;
    goto L2; // [83] 425
L1: 

    /** pathopen.e:97			if compare(inc_path,cache_strings[num_var]) then*/
    _2 = (object)SEQ_PTR(_48cache_strings_50355);
    _25824 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
    if (IS_ATOM_INT(_inc_path_50377) && IS_ATOM_INT(_25824)){
        _25825 = (_inc_path_50377 < _25824) ? -1 : (_inc_path_50377 > _25824);
    }
    else{
        _25825 = compare(_inc_path_50377, _25824);
    }
    _25824 = NOVALUE;
    if (_25825 == 0)
    {
        _25825 = NOVALUE;
        goto L3; // [100] 424
    }
    else{
        _25825 = NOVALUE;
    }

    /** pathopen.e:98				cache_strings[num_var] = inc_path*/
    RefDS(_inc_path_50377);
    _2 = (object)SEQ_PTR(_48cache_strings_50355);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _48cache_strings_50355 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _48num_var_50353);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _inc_path_50377;
    DeRefDS(_1);

    /** pathopen.e:99				cache_complete[num_var] = 0*/
    _2 = (object)SEQ_PTR(_48cache_complete_50360);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _48cache_complete_50360 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _48num_var_50353);
    *(intptr_t *)_2 = 0;

    /** pathopen.e:100				if match(cache_strings[num_var],inc_path)!=1 then -- try to salvage what we can*/
    _2 = (object)SEQ_PTR(_48cache_strings_50355);
    _25826 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
    _25827 = e_match_from(_25826, _inc_path_50377, 1);
    _25826 = NOVALUE;
    if (_25827 == 1)
    goto L4; // [138] 423

    /** pathopen.e:101					pos = -1*/
    _pos_50379 = -1;

    /** pathopen.e:102					for i=1 to length(cache_strings[num_var]) do*/
    _2 = (object)SEQ_PTR(_48cache_strings_50355);
    _25829 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
    if (IS_SEQUENCE(_25829)){
            _25830 = SEQ_PTR(_25829)->length;
    }
    else {
        _25830 = 1;
    }
    _25829 = NOVALUE;
    {
        object _i_50399;
        _i_50399 = 1;
L5: 
        if (_i_50399 > _25830){
            goto L6; // [160] 422
        }

        /** pathopen.e:103						if cache_ends[num_var][i] > length(inc_path) or */
        _2 = (object)SEQ_PTR(_48cache_ends_50358);
        _25831 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
        _2 = (object)SEQ_PTR(_25831);
        _25832 = (object)*(((s1_ptr)_2)->base + _i_50399);
        _25831 = NOVALUE;
        if (IS_SEQUENCE(_inc_path_50377)){
                _25833 = SEQ_PTR(_inc_path_50377)->length;
        }
        else {
            _25833 = 1;
        }
        if (IS_ATOM_INT(_25832)) {
            _25834 = (_25832 > _25833);
        }
        else {
            _25834 = binary_op(GREATER, _25832, _25833);
        }
        _25832 = NOVALUE;
        _25833 = NOVALUE;
        if (IS_ATOM_INT(_25834)) {
            if (_25834 != 0) {
                goto L7; // [188] 242
            }
        }
        else {
            if (DBL_PTR(_25834)->dbl != 0.0) {
                goto L7; // [188] 242
            }
        }
        _2 = (object)SEQ_PTR(_48cache_substrings_50356);
        _25836 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
        _2 = (object)SEQ_PTR(_25836);
        _25837 = (object)*(((s1_ptr)_2)->base + _i_50399);
        _25836 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_starts_50357);
        _25838 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
        _2 = (object)SEQ_PTR(_25838);
        _25839 = (object)*(((s1_ptr)_2)->base + _i_50399);
        _25838 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_ends_50358);
        _25840 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
        _2 = (object)SEQ_PTR(_25840);
        _25841 = (object)*(((s1_ptr)_2)->base + _i_50399);
        _25840 = NOVALUE;
        rhs_slice_target = (object_ptr)&_25842;
        RHS_Slice(_inc_path_50377, _25839, _25841);
        if (IS_ATOM_INT(_25837) && IS_ATOM_INT(_25842)){
            _25843 = (_25837 < _25842) ? -1 : (_25837 > _25842);
        }
        else{
            _25843 = compare(_25837, _25842);
        }
        _25837 = NOVALUE;
        DeRefDS(_25842);
        _25842 = NOVALUE;
        if (_25843 == 0)
        {
            _25843 = NOVALUE;
            goto L8; // [238] 253
        }
        else{
            _25843 = NOVALUE;
        }
L7: 

        /** pathopen.e:107							pos = i-1*/
        _pos_50379 = _i_50399 - 1;

        /** pathopen.e:108							exit*/
        goto L6; // [250] 422
L8: 

        /** pathopen.e:110						if pos = 0 then*/
        if (_pos_50379 != 0)
        goto L9; // [255] 268

        /** pathopen.e:111							return 0*/
        DeRefDSi(_env_50376);
        DeRefDSi(_inc_path_50377);
        _25841 = NOVALUE;
        DeRef(_25834);
        _25834 = NOVALUE;
        _25829 = NOVALUE;
        _25839 = NOVALUE;
        return 0;
        goto LA; // [265] 415
L9: 

        /** pathopen.e:112						elsif pos >0 then -- crop cache data*/
        if (_pos_50379 <= 0)
        goto LB; // [270] 414

        /** pathopen.e:113							cache_substrings[num_var] = cache_substrings[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_48cache_substrings_50356);
        _25847 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
        rhs_slice_target = (object_ptr)&_25848;
        RHS_Slice(_25847, 1, _pos_50379);
        _25847 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_substrings_50356);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_substrings_50356 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50353);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _25848;
        if( _1 != _25848 ){
            DeRefDS(_1);
        }
        _25848 = NOVALUE;

        /** pathopen.e:114							cache_starts[num_var] = cache_starts[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_48cache_starts_50357);
        _25849 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
        rhs_slice_target = (object_ptr)&_25850;
        RHS_Slice(_25849, 1, _pos_50379);
        _25849 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_starts_50357);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_starts_50357 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50353);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _25850;
        if( _1 != _25850 ){
            DeRef(_1);
        }
        _25850 = NOVALUE;

        /** pathopen.e:115							cache_ends[num_var] = cache_ends[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_48cache_ends_50358);
        _25851 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
        rhs_slice_target = (object_ptr)&_25852;
        RHS_Slice(_25851, 1, _pos_50379);
        _25851 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_ends_50358);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_ends_50358 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50353);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _25852;
        if( _1 != _25852 ){
            DeRef(_1);
        }
        _25852 = NOVALUE;

        /** pathopen.e:116							ifdef WINDOWS then*/

        /** pathopen.e:119							delim = cache_ends[num_var][$]+1*/
        _2 = (object)SEQ_PTR(_48cache_ends_50358);
        _25853 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
        if (IS_SEQUENCE(_25853)){
                _25854 = SEQ_PTR(_25853)->length;
        }
        else {
            _25854 = 1;
        }
        _2 = (object)SEQ_PTR(_25853);
        _25855 = (object)*(((s1_ptr)_2)->base + _25854);
        _25853 = NOVALUE;
        if (IS_ATOM_INT(_25855)) {
            _delim_50378 = _25855 + 1;
        }
        else
        { // coercing _delim_50378 to an integer 1
            _delim_50378 = 1+(object)(DBL_PTR(_25855)->dbl);
            if( !IS_ATOM_INT(_delim_50378) ){
                _delim_50378 = (object)DBL_PTR(_delim_50378)->dbl;
            }
        }
        _25855 = NOVALUE;

        /** pathopen.e:120							while delim <= length(inc_path) and delim != PATH_SEPARATOR do*/
LC: 
        if (IS_SEQUENCE(_inc_path_50377)){
                _25857 = SEQ_PTR(_inc_path_50377)->length;
        }
        else {
            _25857 = 1;
        }
        _25858 = (_delim_50378 <= _25857);
        _25857 = NOVALUE;
        if (_25858 == 0) {
            goto LD; // [378] 403
        }
        _25860 = (_delim_50378 != 58);
        if (_25860 == 0)
        {
            DeRef(_25860);
            _25860 = NOVALUE;
            goto LD; // [389] 403
        }
        else{
            DeRef(_25860);
            _25860 = NOVALUE;
        }

        /** pathopen.e:121								delim+=1*/
        _delim_50378 = _delim_50378 + 1;

        /** pathopen.e:122							end while*/
        goto LC; // [400] 371
LD: 

        /** pathopen.e:123							cache_delims[num_var] = delim*/
        _2 = (object)SEQ_PTR(_48cache_delims_50361);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_delims_50361 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50353);
        *(intptr_t *)_2 = _delim_50378;
LB: 
LA: 

        /** pathopen.e:125					end for*/
        _i_50399 = _i_50399 + 1;
        goto L5; // [417] 167
L6: 
        ;
    }
L4: 
L3: 
L2: 

    /** pathopen.e:129		return 1*/
    DeRefDSi(_env_50376);
    DeRefDSi(_inc_path_50377);
    _25841 = NOVALUE;
    DeRef(_25834);
    _25834 = NOVALUE;
    DeRef(_25858);
    _25858 = NOVALUE;
    _25829 = NOVALUE;
    _25839 = NOVALUE;
    return 1;
    ;
}


object _48get_conf_dirs()
{
    object _delimiter_50440 = NOVALUE;
    object _dirs_50441 = NOVALUE;
    object _25865 = NOVALUE;
    object _25863 = NOVALUE;
    object _25862 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:136		ifdef UNIX then*/

    /** pathopen.e:137			delimiter = ':'*/
    _delimiter_50440 = 58;

    /** pathopen.e:142		dirs = ""*/
    RefDS(_21997);
    DeRef(_dirs_50441);
    _dirs_50441 = _21997;

    /** pathopen.e:143		for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_48config_inc_paths_50362)){
            _25862 = SEQ_PTR(_48config_inc_paths_50362)->length;
    }
    else {
        _25862 = 1;
    }
    {
        object _i_50443;
        _i_50443 = 1;
L1: 
        if (_i_50443 > _25862){
            goto L2; // [22] 68
        }

        /** pathopen.e:144			dirs &= config_inc_paths[i]*/
        _2 = (object)SEQ_PTR(_48config_inc_paths_50362);
        _25863 = (object)*(((s1_ptr)_2)->base + _i_50443);
        Concat((object_ptr)&_dirs_50441, _dirs_50441, _25863);
        _25863 = NOVALUE;

        /** pathopen.e:145			if i != length(config_inc_paths) then*/
        if (IS_SEQUENCE(_48config_inc_paths_50362)){
                _25865 = SEQ_PTR(_48config_inc_paths_50362)->length;
        }
        else {
            _25865 = 1;
        }
        if (_i_50443 == _25865)
        goto L3; // [48] 61

        /** pathopen.e:146				dirs &= delimiter*/
        Append(&_dirs_50441, _dirs_50441, _delimiter_50440);
L3: 

        /** pathopen.e:148		end for*/
        _i_50443 = _i_50443 + 1;
        goto L1; // [63] 29
L2: 
        ;
    }

    /** pathopen.e:150		return dirs*/
    return _dirs_50441;
    ;
}


object _48strip_file_from_path(object _full_path_50453)
{
    object _25871 = NOVALUE;
    object _25869 = NOVALUE;
    object _25868 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:156		for i = length(full_path) to 1 by -1 do*/
    if (IS_SEQUENCE(_full_path_50453)){
            _25868 = SEQ_PTR(_full_path_50453)->length;
    }
    else {
        _25868 = 1;
    }
    {
        object _i_50455;
        _i_50455 = _25868;
L1: 
        if (_i_50455 < 1){
            goto L2; // [8] 46
        }

        /** pathopen.e:157			if full_path[i] = SLASH then*/
        _2 = (object)SEQ_PTR(_full_path_50453);
        _25869 = (object)*(((s1_ptr)_2)->base + _i_50455);
        if (binary_op_a(NOTEQ, _25869, 47)){
            _25869 = NOVALUE;
            goto L3; // [23] 39
        }
        _25869 = NOVALUE;

        /** pathopen.e:158				return full_path[1..i]*/
        rhs_slice_target = (object_ptr)&_25871;
        RHS_Slice(_full_path_50453, 1, _i_50455);
        DeRefDS(_full_path_50453);
        return _25871;
L3: 

        /** pathopen.e:160		end for*/
        _i_50455 = _i_50455 + -1;
        goto L1; // [41] 15
L2: 
        ;
    }

    /** pathopen.e:162		return ""*/
    RefDS(_21997);
    DeRefDS(_full_path_50453);
    DeRef(_25871);
    _25871 = NOVALUE;
    return _21997;
    ;
}


object _48expand_path(object _path_50464, object _prefix_50465)
{
    object _absolute_50466 = NOVALUE;
    object _home_50470 = NOVALUE;
    object _25895 = NOVALUE;
    object _25894 = NOVALUE;
    object _25893 = NOVALUE;
    object _25892 = NOVALUE;
    object _25891 = NOVALUE;
    object _25890 = NOVALUE;
    object _25886 = NOVALUE;
    object _25884 = NOVALUE;
    object _25883 = NOVALUE;
    object _25882 = NOVALUE;
    object _25881 = NOVALUE;
    object _25880 = NOVALUE;
    object _25877 = NOVALUE;
    object _25876 = NOVALUE;
    object _25875 = NOVALUE;
    object _25874 = NOVALUE;
    object _25872 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:169		if not length(path) then*/
    if (IS_SEQUENCE(_path_50464)){
            _25872 = SEQ_PTR(_path_50464)->length;
    }
    else {
        _25872 = 1;
    }
    if (_25872 != 0)
    goto L1; // [10] 22
    _25872 = NOVALUE;

    /** pathopen.e:170			return pwd*/
    RefDS(_48pwd_50365);
    DeRefDS(_path_50464);
    DeRefDS(_prefix_50465);
    DeRefi(_home_50470);
    return _48pwd_50365;
L1: 

    /** pathopen.e:174		ifdef UNIX then*/

    /** pathopen.e:175			object home*/

    /** pathopen.e:176			if length(path) and path[1] = '~' then*/
    if (IS_SEQUENCE(_path_50464)){
            _25874 = SEQ_PTR(_path_50464)->length;
    }
    else {
        _25874 = 1;
    }
    if (_25874 == 0) {
        goto L2; // [31] 84
    }
    _2 = (object)SEQ_PTR(_path_50464);
    _25876 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25876)) {
        _25877 = (_25876 == 126);
    }
    else {
        _25877 = binary_op(EQUALS, _25876, 126);
    }
    _25876 = NOVALUE;
    if (_25877 == 0) {
        DeRef(_25877);
        _25877 = NOVALUE;
        goto L2; // [44] 84
    }
    else {
        if (!IS_ATOM_INT(_25877) && DBL_PTR(_25877)->dbl == 0.0){
            DeRef(_25877);
            _25877 = NOVALUE;
            goto L2; // [44] 84
        }
        DeRef(_25877);
        _25877 = NOVALUE;
    }
    DeRef(_25877);
    _25877 = NOVALUE;

    /** pathopen.e:177				home = getenv("HOME")*/
    DeRefi(_home_50470);
    _home_50470 = EGetEnv(_25878);

    /** pathopen.e:178				if sequence(home) and length(home) then*/
    _25880 = IS_SEQUENCE(_home_50470);
    if (_25880 == 0) {
        goto L3; // [57] 83
    }
    if (IS_SEQUENCE(_home_50470)){
            _25882 = SEQ_PTR(_home_50470)->length;
    }
    else {
        _25882 = 1;
    }
    if (_25882 == 0)
    {
        _25882 = NOVALUE;
        goto L3; // [65] 83
    }
    else{
        _25882 = NOVALUE;
    }

    /** pathopen.e:179					path = home & path[2..$]*/
    if (IS_SEQUENCE(_path_50464)){
            _25883 = SEQ_PTR(_path_50464)->length;
    }
    else {
        _25883 = 1;
    }
    rhs_slice_target = (object_ptr)&_25884;
    RHS_Slice(_path_50464, 2, _25883);
    if (IS_SEQUENCE(_home_50470) && IS_ATOM(_25884)) {
    }
    else if (IS_ATOM(_home_50470) && IS_SEQUENCE(_25884)) {
        Ref(_home_50470);
        Prepend(&_path_50464, _25884, _home_50470);
    }
    else {
        Concat((object_ptr)&_path_50464, _home_50470, _25884);
    }
    DeRefDS(_25884);
    _25884 = NOVALUE;
L3: 
L2: 

    /** pathopen.e:183			absolute = find(path[1], SLASH_CHARS)*/
    _2 = (object)SEQ_PTR(_path_50464);
    _25886 = (object)*(((s1_ptr)_2)->base + 1);
    _absolute_50466 = find_from(_25886, _46SLASH_CHARS_21614, 1);
    _25886 = NOVALUE;

    /** pathopen.e:188		if not absolute then*/
    if (_absolute_50466 != 0)
    goto L4; // [101] 115

    /** pathopen.e:189			path = prefix & SLASH & path*/
    {
        object concat_list[3];

        concat_list[0] = _path_50464;
        concat_list[1] = 47;
        concat_list[2] = _prefix_50465;
        Concat_N((object_ptr)&_path_50464, concat_list, 3);
    }
L4: 

    /** pathopen.e:192		if length(path) and not find(path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_path_50464)){
            _25890 = SEQ_PTR(_path_50464)->length;
    }
    else {
        _25890 = 1;
    }
    if (_25890 == 0) {
        goto L5; // [120] 154
    }
    if (IS_SEQUENCE(_path_50464)){
            _25892 = SEQ_PTR(_path_50464)->length;
    }
    else {
        _25892 = 1;
    }
    _2 = (object)SEQ_PTR(_path_50464);
    _25893 = (object)*(((s1_ptr)_2)->base + _25892);
    _25894 = find_from(_25893, _46SLASH_CHARS_21614, 1);
    _25893 = NOVALUE;
    _25895 = (_25894 == 0);
    _25894 = NOVALUE;
    if (_25895 == 0)
    {
        DeRef(_25895);
        _25895 = NOVALUE;
        goto L5; // [142] 154
    }
    else{
        DeRef(_25895);
        _25895 = NOVALUE;
    }

    /** pathopen.e:193			path &= SLASH*/
    Append(&_path_50464, _path_50464, 47);
L5: 

    /** pathopen.e:196		return path*/
    DeRefDS(_prefix_50465);
    DeRefi(_home_50470);
    return _path_50464;
    ;
}


void _48add_include_directory(object _path_50504)
{
    object _25898 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:200		path = expand_path( path, pwd )*/
    RefDS(_path_50504);
    RefDS(_48pwd_50365);
    _0 = _path_50504;
    _path_50504 = _48expand_path(_path_50504, _48pwd_50365);
    DeRefDS(_0);

    /** pathopen.e:202		if not find( path, config_inc_paths ) then*/
    _25898 = find_from(_path_50504, _48config_inc_paths_50362, 1);
    if (_25898 != 0)
    goto L1; // [23] 35
    _25898 = NOVALUE;

    /** pathopen.e:203			config_inc_paths = append( config_inc_paths, path )*/
    RefDS(_path_50504);
    Append(&_48config_inc_paths_50362, _48config_inc_paths_50362, _path_50504);
L1: 

    /** pathopen.e:205	end procedure*/
    DeRefDS(_path_50504);
    return;
    ;
}


object _48load_euphoria_config(object _file_50513)
{
    object _fn_50514 = NOVALUE;
    object _in_50515 = NOVALUE;
    object _spos_50516 = NOVALUE;
    object _epos_50517 = NOVALUE;
    object _conf_path_50518 = NOVALUE;
    object _new_args_50519 = NOVALUE;
    object _arg_50520 = NOVALUE;
    object _parm_50521 = NOVALUE;
    object _section_50522 = NOVALUE;
    object _needed_50619 = NOVALUE;
    object _25995 = NOVALUE;
    object _25994 = NOVALUE;
    object _25991 = NOVALUE;
    object _25989 = NOVALUE;
    object _25988 = NOVALUE;
    object _25966 = NOVALUE;
    object _25963 = NOVALUE;
    object _25962 = NOVALUE;
    object _25960 = NOVALUE;
    object _25956 = NOVALUE;
    object _25954 = NOVALUE;
    object _25952 = NOVALUE;
    object _25950 = NOVALUE;
    object _25948 = NOVALUE;
    object _25946 = NOVALUE;
    object _25945 = NOVALUE;
    object _25944 = NOVALUE;
    object _25943 = NOVALUE;
    object _25942 = NOVALUE;
    object _25941 = NOVALUE;
    object _25940 = NOVALUE;
    object _25939 = NOVALUE;
    object _25937 = NOVALUE;
    object _25935 = NOVALUE;
    object _25933 = NOVALUE;
    object _25929 = NOVALUE;
    object _25928 = NOVALUE;
    object _25923 = NOVALUE;
    object _25921 = NOVALUE;
    object _25919 = NOVALUE;
    object _25918 = NOVALUE;
    object _25910 = NOVALUE;
    object _25904 = NOVALUE;
    object _25903 = NOVALUE;
    object _25901 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:213		sequence new_args = {}*/
    RefDS(_21997);
    DeRef(_new_args_50519);
    _new_args_50519 = _21997;

    /** pathopen.e:219		if file_type(file) = FILETYPE_DIRECTORY then*/
    RefDS(_file_50513);
    _25901 = _17file_type(_file_50513);
    if (binary_op_a(NOTEQ, _25901, 2)){
        DeRef(_25901);
        _25901 = NOVALUE;
        goto L1; // [18] 53
    }
    DeRef(_25901);
    _25901 = NOVALUE;

    /** pathopen.e:220			if file[$] != SLASH then*/
    if (IS_SEQUENCE(_file_50513)){
            _25903 = SEQ_PTR(_file_50513)->length;
    }
    else {
        _25903 = 1;
    }
    _2 = (object)SEQ_PTR(_file_50513);
    _25904 = (object)*(((s1_ptr)_2)->base + _25903);
    if (binary_op_a(EQUALS, _25904, 47)){
        _25904 = NOVALUE;
        goto L2; // [33] 46
    }
    _25904 = NOVALUE;

    /** pathopen.e:221				file &= SLASH*/
    Append(&_file_50513, _file_50513, 47);
L2: 

    /** pathopen.e:223			file &= "eu.cfg"*/
    Concat((object_ptr)&_file_50513, _file_50513, _25907);
L1: 

    /** pathopen.e:226		conf_path = canonical_path( file,,CORRECT )*/
    RefDS(_file_50513);
    _0 = _conf_path_50518;
    _conf_path_50518 = _17canonical_path(_file_50513, 0, 2);
    DeRef(_0);

    /** pathopen.e:229		if find(conf_path, seen_conf) != 0 then*/
    _25910 = find_from(_conf_path_50518, _48seen_conf_50510, 1);
    if (_25910 == 0)
    goto L3; // [74] 85

    /** pathopen.e:230			return {}*/
    RefDS(_21997);
    DeRefDS(_file_50513);
    DeRefi(_in_50515);
    DeRefDS(_conf_path_50518);
    DeRef(_new_args_50519);
    DeRefi(_arg_50520);
    DeRefi(_parm_50521);
    DeRef(_section_50522);
    return _21997;
L3: 

    /** pathopen.e:232		seen_conf = append(seen_conf, conf_path)*/
    RefDS(_conf_path_50518);
    Append(&_48seen_conf_50510, _48seen_conf_50510, _conf_path_50518);

    /** pathopen.e:234		section = "all"*/
    RefDS(_25913);
    DeRef(_section_50522);
    _section_50522 = _25913;

    /** pathopen.e:235		fn = open( conf_path, "r" )*/
    _fn_50514 = EOpen(_conf_path_50518, _25914, 0);

    /** pathopen.e:236		if fn = -1 then return {} end if*/
    if (_fn_50514 != -1)
    goto L4; // [109] 118
    RefDS(_21997);
    DeRefDS(_file_50513);
    DeRefi(_in_50515);
    DeRefDS(_conf_path_50518);
    DeRef(_new_args_50519);
    DeRefi(_arg_50520);
    DeRefi(_parm_50521);
    DeRefDSi(_section_50522);
    return _21997;
L4: 

    /** pathopen.e:238		in = gets( fn )*/
    DeRefi(_in_50515);
    _in_50515 = EGets(_fn_50514);

    /** pathopen.e:239		while sequence( in ) do*/
L5: 
    _25918 = IS_SEQUENCE(_in_50515);
    if (_25918 == 0)
    {
        _25918 = NOVALUE;
        goto L6; // [131] 768
    }
    else{
        _25918 = NOVALUE;
    }

    /** pathopen.e:241			spos = 1*/
    _spos_50516 = 1;

    /** pathopen.e:242			while spos <= length(in) do*/
L7: 
    if (IS_SEQUENCE(_in_50515)){
            _25919 = SEQ_PTR(_in_50515)->length;
    }
    else {
        _25919 = 1;
    }
    if (_spos_50516 > _25919)
    goto L8; // [147] 182

    /** pathopen.e:243				if find( in[spos], "\n\r \t" ) = 0 then*/
    _2 = (object)SEQ_PTR(_in_50515);
    _25921 = (object)*(((s1_ptr)_2)->base + _spos_50516);
    _25923 = find_from(_25921, _25922, 1);
    _25921 = NOVALUE;
    if (_25923 != 0)
    goto L9; // [162] 171

    /** pathopen.e:244					exit*/
    goto L8; // [168] 182
L9: 

    /** pathopen.e:246				spos += 1*/
    _spos_50516 = _spos_50516 + 1;

    /** pathopen.e:247			end while*/
    goto L7; // [179] 144
L8: 

    /** pathopen.e:249			epos = length(in)*/
    if (IS_SEQUENCE(_in_50515)){
            _epos_50517 = SEQ_PTR(_in_50515)->length;
    }
    else {
        _epos_50517 = 1;
    }

    /** pathopen.e:250			while epos >= spos do*/
LA: 
    if (_epos_50517 < _spos_50516)
    goto LB; // [192] 227

    /** pathopen.e:251				if find( in[epos], "\n\r \t" ) = 0 then*/
    _2 = (object)SEQ_PTR(_in_50515);
    _25928 = (object)*(((s1_ptr)_2)->base + _epos_50517);
    _25929 = find_from(_25928, _25922, 1);
    _25928 = NOVALUE;
    if (_25929 != 0)
    goto LC; // [207] 216

    /** pathopen.e:252					exit*/
    goto LB; // [213] 227
LC: 

    /** pathopen.e:254				epos -= 1*/
    _epos_50517 = _epos_50517 - 1;

    /** pathopen.e:255			end while*/
    goto LA; // [224] 192
LB: 

    /** pathopen.e:257			in = in[spos .. epos]		*/
    rhs_slice_target = (object_ptr)&_in_50515;
    RHS_Slice(_in_50515, _spos_50516, _epos_50517);

    /** pathopen.e:260			arg = ""*/
    RefDS(_21997);
    DeRefi(_arg_50520);
    _arg_50520 = _21997;

    /** pathopen.e:261			parm = ""*/
    RefDS(_21997);
    DeRefi(_parm_50521);
    _parm_50521 = _21997;

    /** pathopen.e:269			if length(in) > 0 then*/
    if (IS_SEQUENCE(_in_50515)){
            _25933 = SEQ_PTR(_in_50515)->length;
    }
    else {
        _25933 = 1;
    }
    if (_25933 <= 0)
    goto LD; // [253] 477

    /** pathopen.e:270				if in[1] = '[' then*/
    _2 = (object)SEQ_PTR(_in_50515);
    _25935 = (object)*(((s1_ptr)_2)->base + 1);
    if (_25935 != 91)
    goto LE; // [263] 354

    /** pathopen.e:272					section = in[2..$]*/
    if (IS_SEQUENCE(_in_50515)){
            _25937 = SEQ_PTR(_in_50515)->length;
    }
    else {
        _25937 = 1;
    }
    rhs_slice_target = (object_ptr)&_section_50522;
    RHS_Slice(_in_50515, 2, _25937);

    /** pathopen.e:273					if length(section) > 0 and section[$] = ']' then*/
    if (IS_SEQUENCE(_section_50522)){
            _25939 = SEQ_PTR(_section_50522)->length;
    }
    else {
        _25939 = 1;
    }
    _25940 = (_25939 > 0);
    _25939 = NOVALUE;
    if (_25940 == 0) {
        goto LF; // [286] 320
    }
    if (IS_SEQUENCE(_section_50522)){
            _25942 = SEQ_PTR(_section_50522)->length;
    }
    else {
        _25942 = 1;
    }
    _2 = (object)SEQ_PTR(_section_50522);
    _25943 = (object)*(((s1_ptr)_2)->base + _25942);
    _25944 = (_25943 == 93);
    _25943 = NOVALUE;
    if (_25944 == 0)
    {
        DeRef(_25944);
        _25944 = NOVALUE;
        goto LF; // [302] 320
    }
    else{
        DeRef(_25944);
        _25944 = NOVALUE;
    }

    /** pathopen.e:274						section = section[1..$-1]*/
    if (IS_SEQUENCE(_section_50522)){
            _25945 = SEQ_PTR(_section_50522)->length;
    }
    else {
        _25945 = 1;
    }
    _25946 = _25945 - 1;
    _25945 = NOVALUE;
    rhs_slice_target = (object_ptr)&_section_50522;
    RHS_Slice(_section_50522, 1, _25946);
LF: 

    /** pathopen.e:276					section = lower(trim(section))*/
    RefDS(_section_50522);
    RefDS(_3871);
    _25948 = _14trim(_section_50522, _3871, 0);
    _0 = _section_50522;
    _section_50522 = _14lower(_25948);
    DeRefDS(_0);
    _25948 = NOVALUE;

    /** pathopen.e:277					if length(section) = 0 then*/
    if (IS_SEQUENCE(_section_50522)){
            _25950 = SEQ_PTR(_section_50522)->length;
    }
    else {
        _25950 = 1;
    }
    if (_25950 != 0)
    goto L10; // [339] 476

    /** pathopen.e:278						section = "all"*/
    RefDS(_25913);
    DeRefDS(_section_50522);
    _section_50522 = _25913;
    goto L10; // [351] 476
LE: 

    /** pathopen.e:281				elsif length(in) > 2 then*/
    if (IS_SEQUENCE(_in_50515)){
            _25952 = SEQ_PTR(_in_50515)->length;
    }
    else {
        _25952 = 1;
    }
    if (_25952 <= 2)
    goto L11; // [359] 461

    /** pathopen.e:282					if in[1] = '-' then*/
    _2 = (object)SEQ_PTR(_in_50515);
    _25954 = (object)*(((s1_ptr)_2)->base + 1);
    if (_25954 != 45)
    goto L12; // [369] 443

    /** pathopen.e:283						if in[2] != '-' then*/
    _2 = (object)SEQ_PTR(_in_50515);
    _25956 = (object)*(((s1_ptr)_2)->base + 2);
    if (_25956 == 45)
    goto L10; // [379] 476

    /** pathopen.e:284							spos = find(' ', in)*/
    _spos_50516 = find_from(32, _in_50515, 1);

    /** pathopen.e:285							if spos = 0 then*/
    if (_spos_50516 != 0)
    goto L13; // [392] 413

    /** pathopen.e:286								arg = in*/
    Ref(_in_50515);
    DeRefi(_arg_50520);
    _arg_50520 = _in_50515;

    /** pathopen.e:287								parm = ""*/
    RefDS(_21997);
    DeRefi(_parm_50521);
    _parm_50521 = _21997;
    goto L10; // [410] 476
L13: 

    /** pathopen.e:289								arg = in[1..spos - 1]*/
    _25960 = _spos_50516 - 1;
    rhs_slice_target = (object_ptr)&_arg_50520;
    RHS_Slice(_in_50515, 1, _25960);

    /** pathopen.e:290								parm = in[spos + 1 .. $]*/
    _25962 = _spos_50516 + 1;
    if (_25962 > MAXINT){
        _25962 = NewDouble((eudouble)_25962);
    }
    if (IS_SEQUENCE(_in_50515)){
            _25963 = SEQ_PTR(_in_50515)->length;
    }
    else {
        _25963 = 1;
    }
    rhs_slice_target = (object_ptr)&_parm_50521;
    RHS_Slice(_in_50515, _25962, _25963);
    goto L10; // [440] 476
L12: 

    /** pathopen.e:294						arg = "-i"*/
    RefDS(_25965);
    DeRefi(_arg_50520);
    _arg_50520 = _25965;

    /** pathopen.e:295						parm = in*/
    Ref(_in_50515);
    DeRefi(_parm_50521);
    _parm_50521 = _in_50515;
    goto L10; // [458] 476
L11: 

    /** pathopen.e:298					arg = "-i"*/
    RefDS(_25965);
    DeRefi(_arg_50520);
    _arg_50520 = _25965;

    /** pathopen.e:299					parm = in*/
    Ref(_in_50515);
    DeRefi(_parm_50521);
    _parm_50521 = _in_50515;
L10: 
LD: 

    /** pathopen.e:303			if length(arg) > 0 then*/
    if (IS_SEQUENCE(_arg_50520)){
            _25966 = SEQ_PTR(_arg_50520)->length;
    }
    else {
        _25966 = 1;
    }
    if (_25966 <= 0)
    goto L14; // [482] 756

    /** pathopen.e:304				integer needed = 0*/
    _needed_50619 = 0;

    /** pathopen.e:305				switch section do*/
    _1 = find(_section_50522, _25968);
    switch ( _1 ){ 

        /** pathopen.e:306					case "all" then*/
        case 1:

        /** pathopen.e:307						needed = 1*/
        _needed_50619 = 1;
        goto L15; // [507] 691

        /** pathopen.e:309					case "windows" then*/
        case 2:

        /** pathopen.e:310						needed = TWINDOWS*/
        _needed_50619 = _46TWINDOWS_21594;
        goto L15; // [522] 691

        /** pathopen.e:312					case "unix" then*/
        case 3:

        /** pathopen.e:313						needed = TUNIX*/
        _needed_50619 = _46TUNIX_21598;
        goto L15; // [537] 691

        /** pathopen.e:315					case "translate" then*/
        case 4:

        /** pathopen.e:316						needed = TRANSLATE*/
        _needed_50619 = _36TRANSLATE_21049;
        goto L15; // [552] 691

        /** pathopen.e:318					case "translate:windows" then*/
        case 5:

        /** pathopen.e:319						needed = TRANSLATE and TWINDOWS*/
        _needed_50619 = (_36TRANSLATE_21049 != 0 && _46TWINDOWS_21594 != 0);
        goto L15; // [570] 691

        /** pathopen.e:321					case "translate:unix" then*/
        case 6:

        /** pathopen.e:322						needed = TRANSLATE and TUNIX*/
        _needed_50619 = (_36TRANSLATE_21049 != 0 && _46TUNIX_21598 != 0);
        goto L15; // [588] 691

        /** pathopen.e:324					case "interpret" then*/
        case 7:

        /** pathopen.e:325						needed = INTERPRET*/
        _needed_50619 = _36INTERPRET_21046;
        goto L15; // [603] 691

        /** pathopen.e:327					case "interpret:windows" then*/
        case 8:

        /** pathopen.e:328						needed = INTERPRET and TWINDOWS*/
        _needed_50619 = (_36INTERPRET_21046 != 0 && _46TWINDOWS_21594 != 0);
        goto L15; // [621] 691

        /** pathopen.e:330					case "interpret:unix" then*/
        case 9:

        /** pathopen.e:331						needed = INTERPRET and TUNIX*/
        _needed_50619 = (_36INTERPRET_21046 != 0 && _46TUNIX_21598 != 0);
        goto L15; // [639] 691

        /** pathopen.e:333					case "bind" then*/
        case 10:

        /** pathopen.e:334						needed = BIND*/
        _needed_50619 = _36BIND_21052;
        goto L15; // [654] 691

        /** pathopen.e:336					case "bind:windows" then*/
        case 11:

        /** pathopen.e:337						needed = BIND and TWINDOWS*/
        _needed_50619 = (_36BIND_21052 != 0 && _46TWINDOWS_21594 != 0);
        goto L15; // [672] 691

        /** pathopen.e:339					case "bind:unix" then*/
        case 12:

        /** pathopen.e:340						needed = BIND and TUNIX*/
        _needed_50619 = (_36BIND_21052 != 0 && _46TUNIX_21598 != 0);
    ;}L15: 

    /** pathopen.e:344				if needed then*/
    if (_needed_50619 == 0)
    {
        goto L16; // [693] 755
    }
    else{
    }

    /** pathopen.e:345					if equal(arg, "-c") then*/
    if (_arg_50520 == _25987)
    _25988 = 1;
    else if (IS_ATOM_INT(_arg_50520) && IS_ATOM_INT(_25987))
    _25988 = 0;
    else
    _25988 = (compare(_arg_50520, _25987) == 0);
    if (_25988 == 0)
    {
        _25988 = NOVALUE;
        goto L17; // [702] 728
    }
    else{
        _25988 = NOVALUE;
    }

    /** pathopen.e:346						if length(parm) > 0 then*/
    if (IS_SEQUENCE(_parm_50521)){
            _25989 = SEQ_PTR(_parm_50521)->length;
    }
    else {
        _25989 = 1;
    }
    if (_25989 <= 0)
    goto L18; // [710] 754

    /** pathopen.e:347							new_args &= load_euphoria_config(parm)*/
    RefDS(_parm_50521);
    _25991 = _48load_euphoria_config(_parm_50521);
    if (IS_SEQUENCE(_new_args_50519) && IS_ATOM(_25991)) {
        Ref(_25991);
        Append(&_new_args_50519, _new_args_50519, _25991);
    }
    else if (IS_ATOM(_new_args_50519) && IS_SEQUENCE(_25991)) {
    }
    else {
        Concat((object_ptr)&_new_args_50519, _new_args_50519, _25991);
    }
    DeRef(_25991);
    _25991 = NOVALUE;
    goto L18; // [725] 754
L17: 

    /** pathopen.e:350						new_args = append(new_args, arg)*/
    RefDS(_arg_50520);
    Append(&_new_args_50519, _new_args_50519, _arg_50520);

    /** pathopen.e:351						if length(parm > 0) then*/
    _25994 = binary_op(GREATER, _parm_50521, 0);
    if (IS_SEQUENCE(_25994)){
            _25995 = SEQ_PTR(_25994)->length;
    }
    else {
        _25995 = 1;
    }
    DeRefDS(_25994);
    _25994 = NOVALUE;
    if (_25995 == 0)
    {
        _25995 = NOVALUE;
        goto L19; // [743] 753
    }
    else{
        _25995 = NOVALUE;
    }

    /** pathopen.e:352							new_args = append(new_args, parm)*/
    RefDS(_parm_50521);
    Append(&_new_args_50519, _new_args_50519, _parm_50521);
L19: 
L18: 
L16: 
L14: 

    /** pathopen.e:358			in = gets( fn )*/
    DeRefi(_in_50515);
    _in_50515 = EGets(_fn_50514);

    /** pathopen.e:359		end while*/
    goto L5; // [765] 128
L6: 

    /** pathopen.e:360		close(fn)*/
    EClose(_fn_50514);

    /** pathopen.e:362		return new_args*/
    DeRefDS(_file_50513);
    DeRefi(_in_50515);
    DeRef(_conf_path_50518);
    DeRefi(_arg_50520);
    DeRefi(_parm_50521);
    DeRef(_section_50522);
    _25956 = NOVALUE;
    DeRef(_25960);
    _25960 = NOVALUE;
    _25954 = NOVALUE;
    DeRef(_25946);
    _25946 = NOVALUE;
    _25994 = NOVALUE;
    _25935 = NOVALUE;
    DeRef(_25962);
    _25962 = NOVALUE;
    DeRef(_25940);
    _25940 = NOVALUE;
    return _new_args_50519;
    ;
}


object _48GetDefaultArgs(object _user_files_50686)
{
    object _env_50687 = NOVALUE;
    object _default_args_50688 = NOVALUE;
    object _conf_file_50689 = NOVALUE;
    object _cmd_options_50691 = NOVALUE;
    object _user_config_50697 = NOVALUE;
    object _26030 = NOVALUE;
    object _26029 = NOVALUE;
    object _26028 = NOVALUE;
    object _26020 = NOVALUE;
    object _26019 = NOVALUE;
    object _26017 = NOVALUE;
    object _26014 = NOVALUE;
    object _26013 = NOVALUE;
    object _26010 = NOVALUE;
    object _26009 = NOVALUE;
    object _26007 = NOVALUE;
    object _26005 = NOVALUE;
    object _26004 = NOVALUE;
    object _26000 = NOVALUE;
    object _25999 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:367		sequence default_args = {}*/
    RefDS(_21997);
    DeRef(_default_args_50688);
    _default_args_50688 = _21997;

    /** pathopen.e:368		sequence conf_file = "eu.cfg"*/
    RefDS(_25907);
    DeRefi(_conf_file_50689);
    _conf_file_50689 = _25907;

    /** pathopen.e:370		if loaded_config_inc_paths then return "" end if*/
    if (_48loaded_config_inc_paths_50363 == 0)
    {
        goto L1; // [21] 29
    }
    else{
    }
    RefDS(_21997);
    DeRefDS(_user_files_50686);
    DeRef(_env_50687);
    DeRefDS(_default_args_50688);
    DeRefDSi(_conf_file_50689);
    DeRef(_cmd_options_50691);
    return _21997;
L1: 

    /** pathopen.e:371		loaded_config_inc_paths = 1*/
    _48loaded_config_inc_paths_50363 = 1;

    /** pathopen.e:380		sequence cmd_options = get_options()*/
    _0 = _cmd_options_50691;
    _cmd_options_50691 = _49get_options();
    DeRef(_0);

    /** pathopen.e:382		default_args = {}*/
    RefDS(_21997);
    DeRef(_default_args_50688);
    _default_args_50688 = _21997;

    /** pathopen.e:385		for i = 1 to length( user_files ) do*/
    if (IS_SEQUENCE(_user_files_50686)){
            _25999 = SEQ_PTR(_user_files_50686)->length;
    }
    else {
        _25999 = 1;
    }
    {
        object _i_50695;
        _i_50695 = 1;
L2: 
        if (_i_50695 > _25999){
            goto L3; // [53] 92
        }

        /** pathopen.e:386			sequence user_config = load_euphoria_config( user_files[i] )*/
        _2 = (object)SEQ_PTR(_user_files_50686);
        _26000 = (object)*(((s1_ptr)_2)->base + _i_50695);
        Ref(_26000);
        _0 = _user_config_50697;
        _user_config_50697 = _48load_euphoria_config(_26000);
        DeRef(_0);
        _26000 = NOVALUE;

        /** pathopen.e:387			default_args = merge_parameters( user_config, default_args, cmd_options, 1 )*/
        RefDS(_user_config_50697);
        RefDS(_default_args_50688);
        RefDS(_cmd_options_50691);
        _0 = _default_args_50688;
        _default_args_50688 = _49merge_parameters(_user_config_50697, _default_args_50688, _cmd_options_50691, 1);
        DeRefDS(_0);
        DeRefDS(_user_config_50697);
        _user_config_50697 = NOVALUE;

        /** pathopen.e:388		end for*/
        _i_50695 = _i_50695 + 1;
        goto L2; // [87] 60
L3: 
        ;
    }

    /** pathopen.e:391		default_args = merge_parameters( load_euphoria_config("./" & conf_file), default_args, cmd_options, 1 )*/
    Concat((object_ptr)&_26004, _26003, _conf_file_50689);
    _26005 = _48load_euphoria_config(_26004);
    _26004 = NOVALUE;
    RefDS(_default_args_50688);
    RefDS(_cmd_options_50691);
    _0 = _default_args_50688;
    _default_args_50688 = _49merge_parameters(_26005, _default_args_50688, _cmd_options_50691, 1);
    DeRefDS(_0);
    _26005 = NOVALUE;

    /** pathopen.e:394		env = strip_file_from_path( exe_path() )*/
    _26007 = _48exe_path();
    _0 = _env_50687;
    _env_50687 = _48strip_file_from_path(_26007);
    DeRef(_0);
    _26007 = NOVALUE;

    /** pathopen.e:395		default_args = merge_parameters( load_euphoria_config( env & conf_file ), default_args, cmd_options, 1 )*/
    if (IS_SEQUENCE(_env_50687) && IS_ATOM(_conf_file_50689)) {
    }
    else if (IS_ATOM(_env_50687) && IS_SEQUENCE(_conf_file_50689)) {
        Ref(_env_50687);
        Prepend(&_26009, _conf_file_50689, _env_50687);
    }
    else {
        Concat((object_ptr)&_26009, _env_50687, _conf_file_50689);
    }
    _26010 = _48load_euphoria_config(_26009);
    _26009 = NOVALUE;
    RefDS(_default_args_50688);
    RefDS(_cmd_options_50691);
    _0 = _default_args_50688;
    _default_args_50688 = _49merge_parameters(_26010, _default_args_50688, _cmd_options_50691, 1);
    DeRefDS(_0);
    _26010 = NOVALUE;

    /** pathopen.e:398		ifdef UNIX then*/

    /** pathopen.e:399			default_args = merge_parameters( load_euphoria_config( "/etc/euphoria/" & conf_file ), default_args, cmd_options, 1 )*/
    Concat((object_ptr)&_26013, _26012, _conf_file_50689);
    _26014 = _48load_euphoria_config(_26013);
    _26013 = NOVALUE;
    RefDS(_default_args_50688);
    RefDS(_cmd_options_50691);
    _0 = _default_args_50688;
    _default_args_50688 = _49merge_parameters(_26014, _default_args_50688, _cmd_options_50691, 1);
    DeRefDS(_0);
    _26014 = NOVALUE;

    /** pathopen.e:401			env = getenv( "HOME" )*/
    DeRef(_env_50687);
    _env_50687 = EGetEnv(_25878);

    /** pathopen.e:402			if sequence(env) then*/
    _26017 = IS_SEQUENCE(_env_50687);
    if (_26017 == 0)
    {
        _26017 = NOVALUE;
        goto L4; // [170] 195
    }
    else{
        _26017 = NOVALUE;
    }

    /** pathopen.e:403				default_args = merge_parameters( load_euphoria_config( env & "/." & conf_file ), default_args, cmd_options, 1 )*/
    {
        object concat_list[3];

        concat_list[0] = _conf_file_50689;
        concat_list[1] = _26018;
        concat_list[2] = _env_50687;
        Concat_N((object_ptr)&_26019, concat_list, 3);
    }
    _26020 = _48load_euphoria_config(_26019);
    _26019 = NOVALUE;
    RefDS(_default_args_50688);
    RefDS(_cmd_options_50691);
    _0 = _default_args_50688;
    _default_args_50688 = _49merge_parameters(_26020, _default_args_50688, _cmd_options_50691, 1);
    DeRefDS(_0);
    _26020 = NOVALUE;
L4: 

    /** pathopen.e:427		env = get_eudir()*/
    _0 = _env_50687;
    _env_50687 = _37get_eudir();
    DeRef(_0);

    /** pathopen.e:428		if sequence(env) then*/
    _26028 = IS_SEQUENCE(_env_50687);
    if (_26028 == 0)
    {
        _26028 = NOVALUE;
        goto L5; // [205] 230
    }
    else{
        _26028 = NOVALUE;
    }

    /** pathopen.e:429			default_args = merge_parameters( load_euphoria_config(env & "/" & conf_file), default_args, cmd_options, 1 )*/
    {
        object concat_list[3];

        concat_list[0] = _conf_file_50689;
        concat_list[1] = _23578;
        concat_list[2] = _env_50687;
        Concat_N((object_ptr)&_26029, concat_list, 3);
    }
    _26030 = _48load_euphoria_config(_26029);
    _26029 = NOVALUE;
    RefDS(_default_args_50688);
    RefDS(_cmd_options_50691);
    _0 = _default_args_50688;
    _default_args_50688 = _49merge_parameters(_26030, _default_args_50688, _cmd_options_50691, 1);
    DeRefDS(_0);
    _26030 = NOVALUE;
L5: 

    /** pathopen.e:432		return default_args*/
    DeRefDS(_user_files_50686);
    DeRef(_env_50687);
    DeRefi(_conf_file_50689);
    DeRef(_cmd_options_50691);
    return _default_args_50688;
    ;
}


object _48ConfPath(object _file_name_50741)
{
    object _file_path_50742 = NOVALUE;
    object _try_50743 = NOVALUE;
    object _26037 = NOVALUE;
    object _26033 = NOVALUE;
    object _26032 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:440		for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_48config_inc_paths_50362)){
            _26032 = SEQ_PTR(_48config_inc_paths_50362)->length;
    }
    else {
        _26032 = 1;
    }
    {
        object _i_50745;
        _i_50745 = 1;
L1: 
        if (_i_50745 > _26032){
            goto L2; // [10] 60
        }

        /** pathopen.e:441			file_path = config_inc_paths[i] & file_name*/
        _2 = (object)SEQ_PTR(_48config_inc_paths_50362);
        _26033 = (object)*(((s1_ptr)_2)->base + _i_50745);
        Concat((object_ptr)&_file_path_50742, _26033, _file_name_50741);
        _26033 = NOVALUE;
        _26033 = NOVALUE;

        /** pathopen.e:442			try = open( file_path, "r" )*/
        _try_50743 = EOpen(_file_path_50742, _25914, 0);

        /** pathopen.e:443			if try != -1 then*/
        if (_try_50743 == -1)
        goto L3; // [38] 53

        /** pathopen.e:444				return {file_path, try}*/
        RefDS(_file_path_50742);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_50742;
        ((intptr_t *)_2)[2] = _try_50743;
        _26037 = MAKE_SEQ(_1);
        DeRefDS(_file_name_50741);
        DeRefDS(_file_path_50742);
        return _26037;
L3: 

        /** pathopen.e:446		end for*/
        _i_50745 = _i_50745 + 1;
        goto L1; // [55] 17
L2: 
        ;
    }

    /** pathopen.e:447		return -1*/
    DeRefDS(_file_name_50741);
    DeRef(_file_path_50742);
    DeRef(_26037);
    _26037 = NOVALUE;
    return -1;
    ;
}


object _48ScanPath(object _file_name_50755, object _env_50756, object _flag_50757)
{
    object _inc_path_50758 = NOVALUE;
    object _full_path_50759 = NOVALUE;
    object _file_path_50760 = NOVALUE;
    object _strings_50761 = NOVALUE;
    object _end_path_50762 = NOVALUE;
    object _start_path_50763 = NOVALUE;
    object _try_50764 = NOVALUE;
    object _use_cache_50765 = NOVALUE;
    object _pos_50766 = NOVALUE;
    object _26085 = NOVALUE;
    object _26084 = NOVALUE;
    object _26083 = NOVALUE;
    object _26082 = NOVALUE;
    object _26081 = NOVALUE;
    object _26080 = NOVALUE;
    object _26079 = NOVALUE;
    object _26078 = NOVALUE;
    object _26074 = NOVALUE;
    object _26073 = NOVALUE;
    object _26072 = NOVALUE;
    object _26071 = NOVALUE;
    object _26070 = NOVALUE;
    object _26069 = NOVALUE;
    object _26067 = NOVALUE;
    object _26065 = NOVALUE;
    object _26064 = NOVALUE;
    object _26062 = NOVALUE;
    object _26061 = NOVALUE;
    object _26060 = NOVALUE;
    object _26057 = NOVALUE;
    object _26056 = NOVALUE;
    object _26054 = NOVALUE;
    object _26053 = NOVALUE;
    object _26052 = NOVALUE;
    object _26047 = NOVALUE;
    object _26039 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:459		inc_path = getenv(env)*/
    DeRefi(_inc_path_50758);
    _inc_path_50758 = EGetEnv(_env_50756);

    /** pathopen.e:460		if compare(inc_path,{})!=1 then -- nothing to do, just fail*/
    if (IS_ATOM_INT(_inc_path_50758) && IS_ATOM_INT(_21997)){
        _26039 = (_inc_path_50758 < _21997) ? -1 : (_inc_path_50758 > _21997);
    }
    else{
        _26039 = compare(_inc_path_50758, _21997);
    }
    if (_26039 == 1)
    goto L1; // [18] 29

    /** pathopen.e:461			return -1*/
    DeRefDS(_file_name_50755);
    DeRefDSi(_env_50756);
    DeRefi(_inc_path_50758);
    DeRef(_full_path_50759);
    DeRef(_file_path_50760);
    DeRef(_strings_50761);
    return -1;
L1: 

    /** pathopen.e:464		num_var = find(env,cache_vars)*/
    _48num_var_50353 = find_from(_env_50756, _48cache_vars_50354, 1);

    /** pathopen.e:465		use_cache = check_cache(env,inc_path)*/
    RefDS(_env_50756);
    Ref(_inc_path_50758);
    _use_cache_50765 = _48check_cache(_env_50756, _inc_path_50758);
    if (!IS_ATOM_INT(_use_cache_50765)) {
        _1 = (object)(DBL_PTR(_use_cache_50765)->dbl);
        DeRefDS(_use_cache_50765);
        _use_cache_50765 = _1;
    }

    /** pathopen.e:466		inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_50758, _inc_path_50758, 58);

    /** pathopen.e:468		file_name = SLASH & file_name*/
    Prepend(&_file_name_50755, _file_name_50755, 47);

    /** pathopen.e:469		if flag then*/
    if (_flag_50757 == 0)
    {
        goto L2; // [65] 77
    }
    else{
    }

    /** pathopen.e:470			file_name = include_subfolder & file_name*/
    Concat((object_ptr)&_file_name_50755, _48include_subfolder_50349, _file_name_50755);
L2: 

    /** pathopen.e:472		strings = cache_substrings[num_var]*/
    DeRef(_strings_50761);
    _2 = (object)SEQ_PTR(_48cache_substrings_50356);
    _strings_50761 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
    RefDS(_strings_50761);

    /** pathopen.e:474		if use_cache then*/
    if (_use_cache_50765 == 0)
    {
        goto L3; // [91] 194
    }
    else{
    }

    /** pathopen.e:475			for i=1 to length(strings) do*/
    if (IS_SEQUENCE(_strings_50761)){
            _26047 = SEQ_PTR(_strings_50761)->length;
    }
    else {
        _26047 = 1;
    }
    {
        object _i_50782;
        _i_50782 = 1;
L4: 
        if (_i_50782 > _26047){
            goto L5; // [99] 154
        }

        /** pathopen.e:476				full_path = strings[i]*/
        DeRef(_full_path_50759);
        _2 = (object)SEQ_PTR(_strings_50761);
        _full_path_50759 = (object)*(((s1_ptr)_2)->base + _i_50782);
        Ref(_full_path_50759);

        /** pathopen.e:477				file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_50760, _full_path_50759, _file_name_50755);

        /** pathopen.e:478				try = open_locked(file_path)    */
        RefDS(_file_path_50760);
        _try_50764 = _37open_locked(_file_path_50760);
        if (!IS_ATOM_INT(_try_50764)) {
            _1 = (object)(DBL_PTR(_try_50764)->dbl);
            DeRefDS(_try_50764);
            _try_50764 = _1;
        }

        /** pathopen.e:479				if try != -1 then*/
        if (_try_50764 == -1)
        goto L6; // [130] 145

        /** pathopen.e:480					return {file_path,try}*/
        RefDS(_file_path_50760);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_50760;
        ((intptr_t *)_2)[2] = _try_50764;
        _26052 = MAKE_SEQ(_1);
        DeRefDS(_file_name_50755);
        DeRefDSi(_env_50756);
        DeRefi(_inc_path_50758);
        DeRefDS(_full_path_50759);
        DeRefDS(_file_path_50760);
        DeRefDS(_strings_50761);
        return _26052;
L6: 

        /** pathopen.e:482				ifdef WINDOWS then */

        /** pathopen.e:496			end for*/
        _i_50782 = _i_50782 + 1;
        goto L4; // [149] 106
L5: 
        ;
    }

    /** pathopen.e:497			if cache_complete[num_var] then -- nothing to scan*/
    _2 = (object)SEQ_PTR(_48cache_complete_50360);
    _26053 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
    if (_26053 == 0)
    {
        _26053 = NOVALUE;
        goto L7; // [164] 176
    }
    else{
        _26053 = NOVALUE;
    }

    /** pathopen.e:498				return -1*/
    DeRefDS(_file_name_50755);
    DeRefDSi(_env_50756);
    DeRefi(_inc_path_50758);
    DeRef(_full_path_50759);
    DeRef(_file_path_50760);
    DeRef(_strings_50761);
    DeRef(_26052);
    _26052 = NOVALUE;
    return -1;
    goto L8; // [173] 200
L7: 

    /** pathopen.e:500				pos = cache_delims[num_var]+1 -- scan remainder, starting from as far sa possible*/
    _2 = (object)SEQ_PTR(_48cache_delims_50361);
    _26054 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
    _pos_50766 = _26054 + 1;
    _26054 = NOVALUE;
    goto L8; // [191] 200
L3: 

    /** pathopen.e:503			pos = 1*/
    _pos_50766 = 1;
L8: 

    /** pathopen.e:506		start_path = 0*/
    _start_path_50763 = 0;

    /** pathopen.e:507		for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_50758)){
            _26056 = SEQ_PTR(_inc_path_50758)->length;
    }
    else {
        _26056 = 1;
    }
    {
        object _p_50798;
        _p_50798 = _pos_50766;
L9: 
        if (_p_50798 > _26056){
            goto LA; // [212] 460
        }

        /** pathopen.e:508			if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (object)SEQ_PTR(_inc_path_50758);
        _26057 = (object)*(((s1_ptr)_2)->base + _p_50798);
        if (_26057 != 58)
        goto LB; // [227] 409

        /** pathopen.e:510				cache_delims[num_var] = p*/
        _2 = (object)SEQ_PTR(_48cache_delims_50361);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_delims_50361 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50353);
        *(intptr_t *)_2 = _p_50798;

        /** pathopen.e:512				end_path = p-1*/
        _end_path_50762 = _p_50798 - 1;

        /** pathopen.e:513				while end_path >= start_path and find(inc_path[end_path], " \t" & SLASH_CHARS) do*/
LC: 
        _26060 = (_end_path_50762 >= _start_path_50763);
        if (_26060 == 0) {
            goto LD; // [256] 290
        }
        _2 = (object)SEQ_PTR(_inc_path_50758);
        _26062 = (object)*(((s1_ptr)_2)->base + _end_path_50762);
        Concat((object_ptr)&_26064, _26063, _46SLASH_CHARS_21614);
        _26065 = find_from(_26062, _26064, 1);
        _26062 = NOVALUE;
        DeRefDS(_26064);
        _26064 = NOVALUE;
        if (_26065 == 0)
        {
            _26065 = NOVALUE;
            goto LD; // [276] 290
        }
        else{
            _26065 = NOVALUE;
        }

        /** pathopen.e:514					end_path-=1*/
        _end_path_50762 = _end_path_50762 - 1;

        /** pathopen.e:515				end while*/
        goto LC; // [287] 252
LD: 

        /** pathopen.e:517				if start_path and end_path then*/
        if (_start_path_50763 == 0) {
            goto LE; // [292] 453
        }
        if (_end_path_50762 == 0)
        {
            goto LE; // [297] 453
        }
        else{
        }

        /** pathopen.e:518					full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_50759;
        RHS_Slice(_inc_path_50758, _start_path_50763, _end_path_50762);

        /** pathopen.e:519					cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_48cache_substrings_50356);
        _26069 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
        RefDS(_full_path_50759);
        Append(&_26070, _26069, _full_path_50759);
        _26069 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_substrings_50356);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_substrings_50356 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50353);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26070;
        if( _1 != _26070 ){
            DeRefDS(_1);
        }
        _26070 = NOVALUE;

        /** pathopen.e:520					cache_starts[num_var] &= start_path*/
        _2 = (object)SEQ_PTR(_48cache_starts_50357);
        _26071 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
        if (IS_SEQUENCE(_26071) && IS_ATOM(_start_path_50763)) {
            Append(&_26072, _26071, _start_path_50763);
        }
        else if (IS_ATOM(_26071) && IS_SEQUENCE(_start_path_50763)) {
        }
        else {
            Concat((object_ptr)&_26072, _26071, _start_path_50763);
            _26071 = NOVALUE;
        }
        _26071 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_starts_50357);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_starts_50357 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50353);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26072;
        if( _1 != _26072 ){
            DeRef(_1);
        }
        _26072 = NOVALUE;

        /** pathopen.e:521					cache_ends[num_var] &= end_path*/
        _2 = (object)SEQ_PTR(_48cache_ends_50358);
        _26073 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
        if (IS_SEQUENCE(_26073) && IS_ATOM(_end_path_50762)) {
            Append(&_26074, _26073, _end_path_50762);
        }
        else if (IS_ATOM(_26073) && IS_SEQUENCE(_end_path_50762)) {
        }
        else {
            Concat((object_ptr)&_26074, _26073, _end_path_50762);
            _26073 = NOVALUE;
        }
        _26073 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_ends_50358);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_ends_50358 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50353);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26074;
        if( _1 != _26074 ){
            DeRef(_1);
        }
        _26074 = NOVALUE;

        /** pathopen.e:522					file_path = full_path & file_name  */
        Concat((object_ptr)&_file_path_50760, _full_path_50759, _file_name_50755);

        /** pathopen.e:523					try = open_locked(file_path)*/
        RefDS(_file_path_50760);
        _try_50764 = _37open_locked(_file_path_50760);
        if (!IS_ATOM_INT(_try_50764)) {
            _1 = (object)(DBL_PTR(_try_50764)->dbl);
            DeRefDS(_try_50764);
            _try_50764 = _1;
        }

        /** pathopen.e:524					if try != -1 then -- valid path, no point trying to convert*/
        if (_try_50764 == -1)
        goto LF; // [381] 398

        /** pathopen.e:525						ifdef WINDOWS then*/

        /** pathopen.e:528						return {file_path,try}*/
        RefDS(_file_path_50760);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_50760;
        ((intptr_t *)_2)[2] = _try_50764;
        _26078 = MAKE_SEQ(_1);
        DeRefDS(_file_name_50755);
        DeRefDSi(_env_50756);
        DeRefi(_inc_path_50758);
        DeRefDSi(_full_path_50759);
        DeRefDS(_file_path_50760);
        DeRef(_strings_50761);
        DeRef(_26060);
        _26060 = NOVALUE;
        DeRef(_26052);
        _26052 = NOVALUE;
        _26057 = NOVALUE;
        return _26078;
LF: 

        /** pathopen.e:530					ifdef WINDOWS then*/

        /** pathopen.e:547					start_path = 0*/
        _start_path_50763 = 0;
        goto LE; // [406] 453
LB: 

        /** pathopen.e:549			elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26079 = (_start_path_50763 == 0);
        if (_26079 == 0) {
            goto L10; // [414] 452
        }
        _2 = (object)SEQ_PTR(_inc_path_50758);
        _26081 = (object)*(((s1_ptr)_2)->base + _p_50798);
        _26082 = (_26081 != 32);
        _26081 = NOVALUE;
        if (_26082 == 0) {
            DeRef(_26083);
            _26083 = 0;
            goto L11; // [426] 442
        }
        _2 = (object)SEQ_PTR(_inc_path_50758);
        _26084 = (object)*(((s1_ptr)_2)->base + _p_50798);
        _26085 = (_26084 != 9);
        _26084 = NOVALUE;
        _26083 = (_26085 != 0);
L11: 
        if (_26083 == 0)
        {
            _26083 = NOVALUE;
            goto L10; // [443] 452
        }
        else{
            _26083 = NOVALUE;
        }

        /** pathopen.e:550				start_path = p*/
        _start_path_50763 = _p_50798;
L10: 
LE: 

        /** pathopen.e:552		end for*/
        _p_50798 = _p_50798 + 1;
        goto L9; // [455] 219
LA: 
        ;
    }

    /** pathopen.e:554		cache_complete[num_var] = 1*/
    _2 = (object)SEQ_PTR(_48cache_complete_50360);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _48cache_complete_50360 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _48num_var_50353);
    *(intptr_t *)_2 = 1;

    /** pathopen.e:555		return -1*/
    DeRefDS(_file_name_50755);
    DeRefDSi(_env_50756);
    DeRefi(_inc_path_50758);
    DeRef(_full_path_50759);
    DeRef(_file_path_50760);
    DeRef(_strings_50761);
    DeRef(_26060);
    _26060 = NOVALUE;
    DeRef(_26078);
    _26078 = NOVALUE;
    DeRef(_26079);
    _26079 = NOVALUE;
    DeRef(_26085);
    _26085 = NOVALUE;
    DeRef(_26082);
    _26082 = NOVALUE;
    DeRef(_26052);
    _26052 = NOVALUE;
    _26057 = NOVALUE;
    return -1;
    ;
}


object _48Include_paths(object _add_converted_50840)
{
    object _status_50841 = NOVALUE;
    object _pos_50842 = NOVALUE;
    object _inc_path_50843 = NOVALUE;
    object _full_path_50844 = NOVALUE;
    object _start_path_50845 = NOVALUE;
    object _end_path_50846 = NOVALUE;
    object _eudir_path_50862 = NOVALUE;
    object _26131 = NOVALUE;
    object _26130 = NOVALUE;
    object _26129 = NOVALUE;
    object _26128 = NOVALUE;
    object _26127 = NOVALUE;
    object _26126 = NOVALUE;
    object _26125 = NOVALUE;
    object _26124 = NOVALUE;
    object _26123 = NOVALUE;
    object _26122 = NOVALUE;
    object _26121 = NOVALUE;
    object _26120 = NOVALUE;
    object _26119 = NOVALUE;
    object _26118 = NOVALUE;
    object _26116 = NOVALUE;
    object _26114 = NOVALUE;
    object _26113 = NOVALUE;
    object _26112 = NOVALUE;
    object _26111 = NOVALUE;
    object _26110 = NOVALUE;
    object _26107 = NOVALUE;
    object _26106 = NOVALUE;
    object _26104 = NOVALUE;
    object _26102 = NOVALUE;
    object _26100 = NOVALUE;
    object _26099 = NOVALUE;
    object _26097 = NOVALUE;
    object _26094 = NOVALUE;
    object _26092 = NOVALUE;
    object _26087 = NOVALUE;
    object _26086 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_add_converted_50840)) {
        _1 = (object)(DBL_PTR(_add_converted_50840)->dbl);
        DeRefDS(_add_converted_50840);
        _add_converted_50840 = _1;
    }

    /** pathopen.e:566		if length(include_Paths) then*/
    if (IS_SEQUENCE(_48include_Paths_50837)){
            _26086 = SEQ_PTR(_48include_Paths_50837)->length;
    }
    else {
        _26086 = 1;
    }
    if (_26086 == 0)
    {
        _26086 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _26086 = NOVALUE;
    }

    /** pathopen.e:567			return include_Paths*/
    RefDS(_48include_Paths_50837);
    DeRefi(_inc_path_50843);
    DeRefi(_full_path_50844);
    DeRef(_eudir_path_50862);
    return _48include_Paths_50837;
L1: 

    /** pathopen.e:570		include_Paths = append(config_inc_paths, current_dir())*/
    _26087 = _17current_dir();
    Ref(_26087);
    Append(&_48include_Paths_50837, _48config_inc_paths_50362, _26087);
    DeRef(_26087);
    _26087 = NOVALUE;

    /** pathopen.e:571		num_var = find("EUINC", cache_vars)*/
    _48num_var_50353 = find_from(_26089, _48cache_vars_50354, 1);

    /** pathopen.e:572		inc_path = getenv("EUINC")*/
    DeRefi(_inc_path_50843);
    _inc_path_50843 = EGetEnv(_26089);

    /** pathopen.e:573		if atom(inc_path) then*/
    _26092 = IS_ATOM(_inc_path_50843);
    if (_26092 == 0)
    {
        _26092 = NOVALUE;
        goto L2; // [52] 61
    }
    else{
        _26092 = NOVALUE;
    }

    /** pathopen.e:574			inc_path = ""*/
    RefDS(_21997);
    DeRefi(_inc_path_50843);
    _inc_path_50843 = _21997;
L2: 

    /** pathopen.e:576		status = check_cache("EUINC", inc_path)*/
    RefDS(_26089);
    Ref(_inc_path_50843);
    _status_50841 = _48check_cache(_26089, _inc_path_50843);
    if (!IS_ATOM_INT(_status_50841)) {
        _1 = (object)(DBL_PTR(_status_50841)->dbl);
        DeRefDS(_status_50841);
        _status_50841 = _1;
    }

    /** pathopen.e:577		if length(inc_path) then*/
    if (IS_SEQUENCE(_inc_path_50843)){
            _26094 = SEQ_PTR(_inc_path_50843)->length;
    }
    else {
        _26094 = 1;
    }
    if (_26094 == 0)
    {
        _26094 = NOVALUE;
        goto L3; // [75] 87
    }
    else{
        _26094 = NOVALUE;
    }

    /** pathopen.e:578			inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_50843, _inc_path_50843, 58);
L3: 

    /** pathopen.e:580		object eudir_path = get_eudir()*/
    _0 = _eudir_path_50862;
    _eudir_path_50862 = _37get_eudir();
    DeRef(_0);

    /** pathopen.e:581		if sequence(eudir_path) then*/
    _26097 = IS_SEQUENCE(_eudir_path_50862);
    if (_26097 == 0)
    {
        _26097 = NOVALUE;
        goto L4; // [97] 117
    }
    else{
        _26097 = NOVALUE;
    }

    /** pathopen.e:582			include_Paths = append(include_Paths, sprintf("%s/include", { eudir_path }))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_eudir_path_50862);
    ((intptr_t*)_2)[1] = _eudir_path_50862;
    _26099 = MAKE_SEQ(_1);
    _26100 = EPrintf(-9999999, _26098, _26099);
    DeRefDS(_26099);
    _26099 = NOVALUE;
    RefDS(_26100);
    Append(&_48include_Paths_50837, _48include_Paths_50837, _26100);
    DeRefDS(_26100);
    _26100 = NOVALUE;
L4: 

    /** pathopen.e:585		if status then*/
    if (_status_50841 == 0)
    {
        goto L5; // [119] 161
    }
    else{
    }

    /** pathopen.e:587			if cache_complete[num_var] then*/
    _2 = (object)SEQ_PTR(_48cache_complete_50360);
    _26102 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
    if (_26102 == 0)
    {
        _26102 = NOVALUE;
        goto L6; // [132] 144
    }
    else{
        _26102 = NOVALUE;
    }

    /** pathopen.e:588				goto "cache done"*/
    goto G7;
L6: 

    /** pathopen.e:590			pos = cache_delims[num_var]+1*/
    _2 = (object)SEQ_PTR(_48cache_delims_50361);
    _26104 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
    _pos_50842 = _26104 + 1;
    _26104 = NOVALUE;
    goto L8; // [158] 167
L5: 

    /** pathopen.e:592	        pos = 1*/
    _pos_50842 = 1;
L8: 

    /** pathopen.e:594		start_path = 0*/
    _start_path_50845 = 0;

    /** pathopen.e:595		for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_50843)){
            _26106 = SEQ_PTR(_inc_path_50843)->length;
    }
    else {
        _26106 = 1;
    }
    {
        object _p_50879;
        _p_50879 = _pos_50842;
L9: 
        if (_p_50879 > _26106){
            goto LA; // [179] 394
        }

        /** pathopen.e:596			if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (object)SEQ_PTR(_inc_path_50843);
        _26107 = (object)*(((s1_ptr)_2)->base + _p_50879);
        if (_26107 != 58)
        goto LB; // [194] 343

        /** pathopen.e:598				cache_delims[num_var] = p*/
        _2 = (object)SEQ_PTR(_48cache_delims_50361);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_delims_50361 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50353);
        *(intptr_t *)_2 = _p_50879;

        /** pathopen.e:600				end_path = p-1*/
        _end_path_50846 = _p_50879 - 1;

        /** pathopen.e:601				while end_path >= start_path and find(inc_path[end_path]," \t" & SLASH_CHARS) do*/
LC: 
        _26110 = (_end_path_50846 >= _start_path_50845);
        if (_26110 == 0) {
            goto LD; // [223] 257
        }
        _2 = (object)SEQ_PTR(_inc_path_50843);
        _26112 = (object)*(((s1_ptr)_2)->base + _end_path_50846);
        Concat((object_ptr)&_26113, _26063, _46SLASH_CHARS_21614);
        _26114 = find_from(_26112, _26113, 1);
        _26112 = NOVALUE;
        DeRefDS(_26113);
        _26113 = NOVALUE;
        if (_26114 == 0)
        {
            _26114 = NOVALUE;
            goto LD; // [243] 257
        }
        else{
            _26114 = NOVALUE;
        }

        /** pathopen.e:602					end_path -= 1*/
        _end_path_50846 = _end_path_50846 - 1;

        /** pathopen.e:603				end while*/
        goto LC; // [254] 219
LD: 

        /** pathopen.e:605				if start_path and end_path then*/
        if (_start_path_50845 == 0) {
            goto LE; // [259] 387
        }
        if (_end_path_50846 == 0)
        {
            goto LE; // [264] 387
        }
        else{
        }

        /** pathopen.e:606					full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_50844;
        RHS_Slice(_inc_path_50843, _start_path_50845, _end_path_50846);

        /** pathopen.e:607					cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_48cache_substrings_50356);
        _26118 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
        RefDS(_full_path_50844);
        Append(&_26119, _26118, _full_path_50844);
        _26118 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_substrings_50356);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_substrings_50356 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50353);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26119;
        if( _1 != _26119 ){
            DeRefDS(_1);
        }
        _26119 = NOVALUE;

        /** pathopen.e:608					cache_starts[num_var] &= start_path*/
        _2 = (object)SEQ_PTR(_48cache_starts_50357);
        _26120 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
        if (IS_SEQUENCE(_26120) && IS_ATOM(_start_path_50845)) {
            Append(&_26121, _26120, _start_path_50845);
        }
        else if (IS_ATOM(_26120) && IS_SEQUENCE(_start_path_50845)) {
        }
        else {
            Concat((object_ptr)&_26121, _26120, _start_path_50845);
            _26120 = NOVALUE;
        }
        _26120 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_starts_50357);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_starts_50357 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50353);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26121;
        if( _1 != _26121 ){
            DeRef(_1);
        }
        _26121 = NOVALUE;

        /** pathopen.e:609					cache_ends[num_var] &= end_path*/
        _2 = (object)SEQ_PTR(_48cache_ends_50358);
        _26122 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
        if (IS_SEQUENCE(_26122) && IS_ATOM(_end_path_50846)) {
            Append(&_26123, _26122, _end_path_50846);
        }
        else if (IS_ATOM(_26122) && IS_SEQUENCE(_end_path_50846)) {
        }
        else {
            Concat((object_ptr)&_26123, _26122, _end_path_50846);
            _26122 = NOVALUE;
        }
        _26122 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_ends_50358);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_ends_50358 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50353);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26123;
        if( _1 != _26123 ){
            DeRef(_1);
        }
        _26123 = NOVALUE;

        /** pathopen.e:610					ifdef WINDOWS then*/

        /** pathopen.e:620					start_path = 0*/
        _start_path_50845 = 0;
        goto LE; // [340] 387
LB: 

        /** pathopen.e:622			elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26124 = (_start_path_50845 == 0);
        if (_26124 == 0) {
            goto LF; // [348] 386
        }
        _2 = (object)SEQ_PTR(_inc_path_50843);
        _26126 = (object)*(((s1_ptr)_2)->base + _p_50879);
        _26127 = (_26126 != 32);
        _26126 = NOVALUE;
        if (_26127 == 0) {
            DeRef(_26128);
            _26128 = 0;
            goto L10; // [360] 376
        }
        _2 = (object)SEQ_PTR(_inc_path_50843);
        _26129 = (object)*(((s1_ptr)_2)->base + _p_50879);
        _26130 = (_26129 != 9);
        _26129 = NOVALUE;
        _26128 = (_26130 != 0);
L10: 
        if (_26128 == 0)
        {
            _26128 = NOVALUE;
            goto LF; // [377] 386
        }
        else{
            _26128 = NOVALUE;
        }

        /** pathopen.e:623				start_path = p*/
        _start_path_50845 = _p_50879;
LF: 
LE: 

        /** pathopen.e:625		end for*/
        _p_50879 = _p_50879 + 1;
        goto L9; // [389] 186
LA: 
        ;
    }

    /** pathopen.e:627	label "cache done"*/
G7:

    /** pathopen.e:628		include_Paths &= cache_substrings[num_var]*/
    _2 = (object)SEQ_PTR(_48cache_substrings_50356);
    _26131 = (object)*(((s1_ptr)_2)->base + _48num_var_50353);
    Concat((object_ptr)&_48include_Paths_50837, _48include_Paths_50837, _26131);
    _26131 = NOVALUE;

    /** pathopen.e:629		cache_complete[num_var] = 1*/
    _2 = (object)SEQ_PTR(_48cache_complete_50360);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _48cache_complete_50360 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _48num_var_50353);
    *(intptr_t *)_2 = 1;

    /** pathopen.e:631		ifdef WINDOWS then*/

    /** pathopen.e:640		return include_Paths*/
    RefDS(_48include_Paths_50837);
    DeRefi(_inc_path_50843);
    DeRefi(_full_path_50844);
    DeRef(_eudir_path_50862);
    DeRef(_26127);
    _26127 = NOVALUE;
    DeRef(_26124);
    _26124 = NOVALUE;
    DeRef(_26110);
    _26110 = NOVALUE;
    _26107 = NOVALUE;
    DeRef(_26130);
    _26130 = NOVALUE;
    return _48include_Paths_50837;
    ;
}


object _48e_path_find(object _name_50915)
{
    object _scan_result_50916 = NOVALUE;
    object _26141 = NOVALUE;
    object _26140 = NOVALUE;
    object _26139 = NOVALUE;
    object _26136 = NOVALUE;
    object _26135 = NOVALUE;
    object _26134 = NOVALUE;
    object _26133 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:656		if file_exists(name) then*/
    RefDS(_name_50915);
    _26133 = _17file_exists(_name_50915);
    if (_26133 == 0) {
        DeRef(_26133);
        _26133 = NOVALUE;
        goto L1; // [9] 19
    }
    else {
        if (!IS_ATOM_INT(_26133) && DBL_PTR(_26133)->dbl == 0.0){
            DeRef(_26133);
            _26133 = NOVALUE;
            goto L1; // [9] 19
        }
        DeRef(_26133);
        _26133 = NOVALUE;
    }
    DeRef(_26133);
    _26133 = NOVALUE;

    /** pathopen.e:657			return name*/
    DeRef(_scan_result_50916);
    return _name_50915;
L1: 

    /** pathopen.e:661		for i = 1 to length(SLASH_CHARS) do*/
    if (IS_SEQUENCE(_46SLASH_CHARS_21614)){
            _26134 = SEQ_PTR(_46SLASH_CHARS_21614)->length;
    }
    else {
        _26134 = 1;
    }
    {
        object _i_50921;
        _i_50921 = 1;
L2: 
        if (_i_50921 > _26134){
            goto L3; // [26] 63
        }

        /** pathopen.e:662			if find(SLASH_CHARS[i], name) then*/
        _2 = (object)SEQ_PTR(_46SLASH_CHARS_21614);
        _26135 = (object)*(((s1_ptr)_2)->base + _i_50921);
        _26136 = find_from(_26135, _name_50915, 1);
        _26135 = NOVALUE;
        if (_26136 == 0)
        {
            _26136 = NOVALUE;
            goto L4; // [46] 56
        }
        else{
            _26136 = NOVALUE;
        }

        /** pathopen.e:663				return -1*/
        DeRefDS(_name_50915);
        DeRef(_scan_result_50916);
        return -1;
L4: 

        /** pathopen.e:665		end for*/
        _i_50921 = _i_50921 + 1;
        goto L2; // [58] 33
L3: 
        ;
    }

    /** pathopen.e:667		scan_result = ScanPath(name, "PATH", 0)*/
    RefDS(_name_50915);
    RefDS(_26137);
    _0 = _scan_result_50916;
    _scan_result_50916 = _48ScanPath(_name_50915, _26137, 0);
    DeRef(_0);

    /** pathopen.e:668		if sequence(scan_result) then*/
    _26139 = IS_SEQUENCE(_scan_result_50916);
    if (_26139 == 0)
    {
        _26139 = NOVALUE;
        goto L5; // [76] 98
    }
    else{
        _26139 = NOVALUE;
    }

    /** pathopen.e:669			close(scan_result[2])*/
    _2 = (object)SEQ_PTR(_scan_result_50916);
    _26140 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_26140))
    EClose(_26140);
    else
    EClose((object)DBL_PTR(_26140)->dbl);
    _26140 = NOVALUE;

    /** pathopen.e:670			return scan_result[1]*/
    _2 = (object)SEQ_PTR(_scan_result_50916);
    _26141 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_26141);
    DeRefDS(_name_50915);
    DeRef(_scan_result_50916);
    return _26141;
L5: 

    /** pathopen.e:673		return -1*/
    DeRefDS(_name_50915);
    DeRef(_scan_result_50916);
    _26141 = NOVALUE;
    return -1;
    ;
}



// 0x0C8BADDC
