// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _3extract_options(object _s_64565)
{
    object _0, _1, _2;
    

    /** traninit.e:69		return s*/
    return _s_64565;
    ;
}


void _3transoptions()
{
    object _tranopts_64752 = NOVALUE;
    object _opts_64764 = NOVALUE;
    object _opt_keys_64770 = NOVALUE;
    object _option_w_64772 = NOVALUE;
    object _key_64776 = NOVALUE;
    object _val_64778 = NOVALUE;
    object _tmp_64883 = NOVALUE;
    object _tmp_64903 = NOVALUE;
    object _filetype_64929 = NOVALUE;
    object _31943 = NOVALUE;
    object _31942 = NOVALUE;
    object _31941 = NOVALUE;
    object _31940 = NOVALUE;
    object _31938 = NOVALUE;
    object _31937 = NOVALUE;
    object _31936 = NOVALUE;
    object _31935 = NOVALUE;
    object _31934 = NOVALUE;
    object _31933 = NOVALUE;
    object _31928 = NOVALUE;
    object _31927 = NOVALUE;
    object _31926 = NOVALUE;
    object _31923 = NOVALUE;
    object _31922 = NOVALUE;
    object _31921 = NOVALUE;
    object _31920 = NOVALUE;
    object _31919 = NOVALUE;
    object _31916 = NOVALUE;
    object _31913 = NOVALUE;
    object _31912 = NOVALUE;
    object _31911 = NOVALUE;
    object _31910 = NOVALUE;
    object _31908 = NOVALUE;
    object _31905 = NOVALUE;
    object _31904 = NOVALUE;
    object _31903 = NOVALUE;
    object _31902 = NOVALUE;
    object _31901 = NOVALUE;
    object _31900 = NOVALUE;
    object _31899 = NOVALUE;
    object _31898 = NOVALUE;
    object _31897 = NOVALUE;
    object _31896 = NOVALUE;
    object _31895 = NOVALUE;
    object _31894 = NOVALUE;
    object _31893 = NOVALUE;
    object _31889 = NOVALUE;
    object _31886 = NOVALUE;
    object _31885 = NOVALUE;
    object _31884 = NOVALUE;
    object _31878 = NOVALUE;
    object _31875 = NOVALUE;
    object _31874 = NOVALUE;
    object _31872 = NOVALUE;
    object _31870 = NOVALUE;
    object _31866 = NOVALUE;
    object _31856 = NOVALUE;
    object _31854 = NOVALUE;
    object _31851 = NOVALUE;
    object _31849 = NOVALUE;
    object _31847 = NOVALUE;
    object _31846 = NOVALUE;
    object _31845 = NOVALUE;
    object _31844 = NOVALUE;
    object _31843 = NOVALUE;
    object _31838 = NOVALUE;
    object _31832 = NOVALUE;
    object _0, _1, _2;
    

    /** traninit.e:112		sequence tranopts = sort( get_options() )*/
    _31832 = _49get_options();
    _0 = _tranopts_64752;
    _tranopts_64752 = _24sort(_31832, 1);
    DeRef(_0);
    _31832 = NOVALUE;

    /** traninit.e:114		Argv = expand_config_options( Argv )*/
    RefDS(_36Argv_21458);
    _0 = _49expand_config_options(_36Argv_21458);
    DeRefDS(_36Argv_21458);
    _36Argv_21458 = _0;

    /** traninit.e:115		Argc = length(Argv)*/
    if (IS_SEQUENCE(_36Argv_21458)){
            _36Argc_21457 = SEQ_PTR(_36Argv_21458)->length;
    }
    else {
        _36Argc_21457 = 1;
    }

    /** traninit.e:117		map:map opts = cmd_parse( tranopts, NO_HELP_ON_ERROR, Argv)*/
    RefDS(_tranopts_64752);
    RefDS(_36Argv_21458);
    _0 = _opts_64764;
    _opts_64764 = _4cmd_parse(_tranopts_64752, 10, _36Argv_21458);
    DeRef(_0);

    /** traninit.e:119		handle_common_options(opts)*/
    Ref(_opts_64764);
    _49handle_common_options(_opts_64764);

    /** traninit.e:121		sequence opt_keys = map:keys(opts)*/
    Ref(_opts_64764);
    _0 = _opt_keys_64770;
    _opt_keys_64770 = _29keys(_opts_64764, 0);
    DeRef(_0);

    /** traninit.e:122		integer option_w = 0*/
    _option_w_64772 = 0;

    /** traninit.e:124		for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_64770)){
            _31838 = SEQ_PTR(_opt_keys_64770)->length;
    }
    else {
        _31838 = 1;
    }
    {
        object _idx_64774;
        _idx_64774 = 1;
L1: 
        if (_idx_64774 > _31838){
            goto L2; // [68] 884
        }

        /** traninit.e:126			sequence key = opt_keys[idx]*/
        DeRef(_key_64776);
        _2 = (object)SEQ_PTR(_opt_keys_64770);
        _key_64776 = (object)*(((s1_ptr)_2)->base + _idx_64774);
        Ref(_key_64776);

        /** traninit.e:127			object val = map:get(opts, key)*/
        Ref(_opts_64764);
        RefDS(_key_64776);
        _0 = _val_64778;
        _val_64778 = _29get(_opts_64764, _key_64776, 0);
        DeRef(_0);

        /** traninit.e:129			switch key do*/
        _1 = find(_key_64776, _31841);
        switch ( _1 ){ 

            /** traninit.e:130				case "silent" then*/
            case 1:

            /** traninit.e:131					silent = TRUE*/
            _36silent_21566 = _13TRUE_452;
            goto L3; // [109] 875

            /** traninit.e:133				case "verbose" then*/
            case 2:

            /** traninit.e:134					verbose = TRUE*/
            _36verbose_21569 = _13TRUE_452;
            goto L3; // [122] 875

            /** traninit.e:136				case "rc-file" then*/
            case 3:

            /** traninit.e:137					rc_file[D_NAME] = canonical_path(val)*/
            Ref(_val_64778);
            _31843 = _17canonical_path(_val_64778, 0, 0);
            _2 = (object)SEQ_PTR(_56rc_file_45402);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _56rc_file_45402 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 1);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _31843;
            if( _1 != _31843 ){
                DeRef(_1);
            }
            _31843 = NOVALUE;

            /** traninit.e:138					rc_file[D_ALTNAME] = adjust_for_command_line_passing((rc_file[D_NAME]))*/
            _2 = (object)SEQ_PTR(_56rc_file_45402);
            _31844 = (object)*(((s1_ptr)_2)->base + 1);
            Ref(_31844);
            _31845 = _56adjust_for_command_line_passing(_31844);
            _31844 = NOVALUE;
            _2 = (object)SEQ_PTR(_56rc_file_45402);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _56rc_file_45402 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 11);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _31845;
            if( _1 != _31845 ){
                DeRef(_1);
            }
            _31845 = NOVALUE;

            /** traninit.e:139					if not file_exists(rc_file[D_NAME]) then*/
            _2 = (object)SEQ_PTR(_56rc_file_45402);
            _31846 = (object)*(((s1_ptr)_2)->base + 1);
            Ref(_31846);
            _31847 = _17file_exists(_31846);
            _31846 = NOVALUE;
            if (IS_ATOM_INT(_31847)) {
                if (_31847 != 0){
                    DeRef(_31847);
                    _31847 = NOVALUE;
                    goto L3; // [180] 875
                }
            }
            else {
                if (DBL_PTR(_31847)->dbl != 0.0){
                    DeRef(_31847);
                    _31847 = NOVALUE;
                    goto L3; // [180] 875
                }
            }
            DeRef(_31847);
            _31847 = NOVALUE;

            /** traninit.e:140						ShowMsg(2, RESOURCE_FILE_DOES_NOT_EXIST__1, { val })*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_val_64778);
            ((intptr_t*)_2)[1] = _val_64778;
            _31849 = MAKE_SEQ(_1);
            _39ShowMsg(2, 349, _31849, 1);
            _31849 = NOVALUE;

            /** traninit.e:141						abort(1)*/
            UserCleanup(1);
            goto L3; // [202] 875

            /** traninit.e:144				case "cflags" then*/
            case 4:

            /** traninit.e:145					cflags = val*/
            Ref(_val_64778);
            DeRef(_56cflags_45411);
            _56cflags_45411 = _val_64778;
            goto L3; // [215] 875

            /** traninit.e:147				case "extra-cflags" then*/
            case 5:

            /** traninit.e:148					extra_cflags = val*/
            Ref(_val_64778);
            DeRef(_56extra_cflags_45412);
            _56extra_cflags_45412 = _val_64778;
            goto L3; // [228] 875

            /** traninit.e:150				case "lflags" then*/
            case 6:

            /** traninit.e:151					lflags = val*/
            Ref(_val_64778);
            DeRef(_56lflags_45413);
            _56lflags_45413 = _val_64778;
            goto L3; // [241] 875

            /** traninit.e:153				case "extra-lflags" then*/
            case 7:

            /** traninit.e:154					extra_lflags = val*/
            Ref(_val_64778);
            DeRef(_56extra_lflags_45414);
            _56extra_lflags_45414 = _val_64778;
            goto L3; // [254] 875

            /** traninit.e:156				case "wat" then*/
            case 8:

            /** traninit.e:157					compiler_type = COMPILER_WATCOM*/
            _56compiler_type_45393 = 2;
            goto L3; // [269] 875

            /** traninit.e:159				case "gcc" then*/
            case 9:

            /** traninit.e:160					compiler_type = COMPILER_GCC*/
            _56compiler_type_45393 = 1;
            goto L3; // [284] 875

            /** traninit.e:162				case "com" then*/
            case 10:

            /** traninit.e:163					compiler_dir = val*/
            Ref(_val_64778);
            DeRef(_56compiler_dir_45395);
            _56compiler_dir_45395 = _val_64778;
            goto L3; // [297] 875

            /** traninit.e:165				case "con" then*/
            case 11:

            /** traninit.e:166					con_option = TRUE*/
            _58con_option_42569 = _13TRUE_452;

            /** traninit.e:167					OpDefines &= { "CONSOLE" }*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            RefDS(_31850);
            ((intptr_t*)_2)[1] = _31850;
            _31851 = MAKE_SEQ(_1);
            Concat((object_ptr)&_36OpDefines_21524, _36OpDefines_21524, _31851);
            DeRefDS(_31851);
            _31851 = NOVALUE;
            goto L3; // [324] 875

            /** traninit.e:169				case "dll", "so" then*/
            case 12:
            case 13:

            /** traninit.e:170					dll_option = TRUE*/
            _58dll_option_42567 = _13TRUE_452;

            /** traninit.e:171					OpDefines &= { "EUC_DLL" }*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            RefDS(_31853);
            ((intptr_t*)_2)[1] = _31853;
            _31854 = MAKE_SEQ(_1);
            Concat((object_ptr)&_36OpDefines_21524, _36OpDefines_21524, _31854);
            DeRefDS(_31854);
            _31854 = NOVALUE;
            goto L3; // [353] 875

            /** traninit.e:173				case "plat" then*/
            case 14:

            /** traninit.e:174					switch upper(val) do*/
            Ref(_val_64778);
            _31856 = _14upper(_val_64778);
            _1 = find(_31856, _31857);
            DeRef(_31856);
            _31856 = NOVALUE;
            switch ( _1 ){ 

                /** traninit.e:178						case "WINDOWS" then*/
                case 1:

                /** traninit.e:179							set_host_platform( WIN32 )*/
                _46set_host_platform(2);
                goto L3; // [381] 875

                /** traninit.e:181						case "LINUX" then*/
                case 2:

                /** traninit.e:182							set_host_platform( ULINUX )*/
                _46set_host_platform(3);
                goto L3; // [394] 875

                /** traninit.e:184						case "FREEBSD" then*/
                case 3:

                /** traninit.e:185							set_host_platform( UFREEBSD )*/
                _46set_host_platform(8);
                goto L3; // [407] 875

                /** traninit.e:187						case "OSX" then*/
                case 4:

                /** traninit.e:188							set_host_platform( UOSX )*/
                _46set_host_platform(4);
                goto L3; // [420] 875

                /** traninit.e:190						case "OPENBSD" then*/
                case 5:

                /** traninit.e:191							set_host_platform( UOPENBSD )*/
                _46set_host_platform(6);
                goto L3; // [433] 875

                /** traninit.e:193						case "NETBSD" then*/
                case 6:

                /** traninit.e:194							set_host_platform( UNETBSD )*/
                _46set_host_platform(7);
                goto L3; // [446] 875

                /** traninit.e:196						case else*/
                case 0:

                /** traninit.e:197							ShowMsg(2, UNKNOWN_PLATFORM_1__SUPPORTED_PLATFORMS_ARE_2, { val, "WINDOWS, LINUX, FREEBSD, OSX, OPENBSD, NETBSD" })*/
                RefDS(_31865);
                Ref(_val_64778);
                _1 = NewS1(2);
                _2 = (object)((s1_ptr)_1)->base;
                ((intptr_t *)_2)[1] = _val_64778;
                ((intptr_t *)_2)[2] = _31865;
                _31866 = MAKE_SEQ(_1);
                _39ShowMsg(2, 201, _31866, 1);
                _31866 = NOVALUE;

                /** traninit.e:198							abort(1)*/
                UserCleanup(1);
            ;}            goto L3; // [471] 875

            /** traninit.e:201				case "lib" then*/
            case 15:

            /** traninit.e:202					user_library = canonical_path(val)*/
            Ref(_val_64778);
            _0 = _17canonical_path(_val_64778, 0, 0);
            DeRef(_58user_library_42579);
            _58user_library_42579 = _0;
            goto L3; // [487] 875

            /** traninit.e:204				case "lib-pic" then*/
            case 16:

            /** traninit.e:205					user_pic_library = canonical_path( val )*/
            Ref(_val_64778);
            _0 = _17canonical_path(_val_64778, 0, 0);
            DeRef(_58user_pic_library_42580);
            _58user_pic_library_42580 = _0;
            goto L3; // [503] 875

            /** traninit.e:207				case "stack" then*/
            case 17:

            /** traninit.e:208					sequence tmp = value(val)*/
            Ref(_val_64778);
            _0 = _tmp_64883;
            _tmp_64883 = _6value(_val_64778, 1, _6GET_SHORT_ANSWER_11168);
            DeRef(_0);

            /** traninit.e:209					if tmp[1] = GET_SUCCESS then*/
            _2 = (object)SEQ_PTR(_tmp_64883);
            _31870 = (object)*(((s1_ptr)_2)->base + 1);
            if (binary_op_a(NOTEQ, _31870, 0)){
                _31870 = NOVALUE;
                goto L4; // [529] 561
            }
            _31870 = NOVALUE;

            /** traninit.e:210						if tmp[2] >= 16384 then*/
            _2 = (object)SEQ_PTR(_tmp_64883);
            _31872 = (object)*(((s1_ptr)_2)->base + 2);
            if (binary_op_a(LESS, _31872, 16384)){
                _31872 = NOVALUE;
                goto L5; // [539] 560
            }
            _31872 = NOVALUE;

            /** traninit.e:211							total_stack_size = floor(tmp[2] / 4) * 4*/
            _2 = (object)SEQ_PTR(_tmp_64883);
            _31874 = (object)*(((s1_ptr)_2)->base + 2);
            if (IS_ATOM_INT(_31874)) {
                if (4 > 0 && _31874 >= 0) {
                    _31875 = _31874 / 4;
                }
                else {
                    temp_dbl = EUFLOOR((eudouble)_31874 / (eudouble)4);
                    if (_31874 != MININT)
                    _31875 = (object)temp_dbl;
                    else
                    _31875 = NewDouble(temp_dbl);
                }
            }
            else {
                _2 = binary_op(DIVIDE, _31874, 4);
                _31875 = unary_op(FLOOR, _2);
                DeRef(_2);
            }
            _31874 = NOVALUE;
            if (IS_ATOM_INT(_31875)) {
                _58total_stack_size_42582 = _31875 * 4;
            }
            else {
                _58total_stack_size_42582 = binary_op(MULTIPLY, _31875, 4);
            }
            DeRef(_31875);
            _31875 = NOVALUE;
            if (!IS_ATOM_INT(_58total_stack_size_42582)) {
                _1 = (object)(DBL_PTR(_58total_stack_size_42582)->dbl);
                DeRefDS(_58total_stack_size_42582);
                _58total_stack_size_42582 = _1;
            }
L5: 
L4: 
            DeRef(_tmp_64883);
            _tmp_64883 = NOVALUE;
            goto L3; // [563] 875

            /** traninit.e:215				case "debug" then*/
            case 18:

            /** traninit.e:216					debug_option = TRUE*/
            _58debug_option_42577 = _13TRUE_452;

            /** traninit.e:217					keep = TRUE -- you'll need the sources to debug*/
            _58keep_42574 = _13TRUE_452;
            goto L3; // [583] 875

            /** traninit.e:219				case "maxsize" then*/
            case 19:

            /** traninit.e:220					sequence tmp = value(val)*/
            Ref(_val_64778);
            _0 = _tmp_64903;
            _tmp_64903 = _6value(_val_64778, 1, _6GET_SHORT_ANSWER_11168);
            DeRef(_0);

            /** traninit.e:221					if tmp[1] = GET_SUCCESS then*/
            _2 = (object)SEQ_PTR(_tmp_64903);
            _31878 = (object)*(((s1_ptr)_2)->base + 1);
            if (binary_op_a(NOTEQ, _31878, 0)){
                _31878 = NOVALUE;
                goto L6; // [609] 624
            }
            _31878 = NOVALUE;

            /** traninit.e:222						max_cfile_size = tmp[2]*/
            _2 = (object)SEQ_PTR(_tmp_64903);
            _56max_cfile_size_45409 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_56max_cfile_size_45409)){
                _56max_cfile_size_45409 = (object)DBL_PTR(_56max_cfile_size_45409)->dbl;
            }
            goto L7; // [621] 639
L6: 

            /** traninit.e:224						ShowMsg(2, INVALID_MAXIMUM_FILE_SIZE)*/
            RefDS(_21997);
            _39ShowMsg(2, 202, _21997, 1);

            /** traninit.e:225						abort(1)*/
            UserCleanup(1);
L7: 
            DeRef(_tmp_64903);
            _tmp_64903 = NOVALUE;
            goto L3; // [641] 875

            /** traninit.e:228				case "keep" then*/
            case 20:

            /** traninit.e:229					keep = TRUE*/
            _58keep_42574 = _13TRUE_452;
            goto L3; // [654] 875

            /** traninit.e:231				case "makefile-partial" then*/
            case 21:

            /** traninit.e:232					build_system_type = BUILD_MAKEFILE_PARTIAL*/
            _56build_system_type_45389 = 1;
            goto L3; // [669] 875

            /** traninit.e:234				case "makefile" then*/
            case 22:

            /** traninit.e:235					build_system_type = BUILD_MAKEFILE_FULL*/
            _56build_system_type_45389 = 2;
            goto L3; // [684] 875

            /** traninit.e:237				case "nobuild" then*/
            case 23:

            /** traninit.e:238					build_system_type = BUILD_NONE*/
            _56build_system_type_45389 = 0;
            goto L3; // [699] 875

            /** traninit.e:240				case "build-dir" then*/
            case 24:

            /** traninit.e:241					output_dir = val*/
            Ref(_val_64778);
            DeRef(_58output_dir_42581);
            _58output_dir_42581 = _val_64778;

            /** traninit.e:242					integer filetype = file_type( output_dir )*/
            RefDS(_58output_dir_42581);
            _filetype_64929 = _17file_type(_58output_dir_42581);
            if (!IS_ATOM_INT(_filetype_64929)) {
                _1 = (object)(DBL_PTR(_filetype_64929)->dbl);
                DeRefDS(_filetype_64929);
                _filetype_64929 = _1;
            }

            /** traninit.e:244					if filetype = FILETYPE_FILE then*/
            if (_filetype_64929 != 1)
            goto L8; // [726] 747

            /** traninit.e:245						ShowMsg( 2, BUILDDIR_IS_FILE )*/
            RefDS(_21997);
            _39ShowMsg(2, 605, _21997, 1);

            /** traninit.e:246						abort(1)*/
            UserCleanup(1);
            goto L9; // [744] 771
L8: 

            /** traninit.e:247					elsif filetype = FILETYPE_UNDEFINED then*/
            if (_filetype_64929 != -1)
            goto LA; // [751] 770

            /** traninit.e:248						ShowMsg( 2, BUILDDIR_IS_UNDEFINED )*/
            RefDS(_21997);
            _39ShowMsg(2, 606, _21997, 1);

            /** traninit.e:249						abort(1)*/
            UserCleanup(1);
LA: 
L9: 

            /** traninit.e:251					if find(output_dir[$], "/\\") = 0 then*/
            if (IS_SEQUENCE(_58output_dir_42581)){
                    _31884 = SEQ_PTR(_58output_dir_42581)->length;
            }
            else {
                _31884 = 1;
            }
            _2 = (object)SEQ_PTR(_58output_dir_42581);
            _31885 = (object)*(((s1_ptr)_2)->base + _31884);
            _31886 = find_from(_31885, _23905, 1);
            _31885 = NOVALUE;
            if (_31886 != 0)
            goto LB; // [787] 802

            /** traninit.e:252						output_dir &= '/'*/
            Append(&_58output_dir_42581, _58output_dir_42581, 47);
LB: 
            goto L3; // [804] 875

            /** traninit.e:255				case "force-build" then*/
            case 25:

            /** traninit.e:256					force_build = 1*/
            _56force_build_45415 = 1;
            goto L3; // [817] 875

            /** traninit.e:258				case "o" then*/
            case 26:

            /** traninit.e:259					exe_name[D_NAME] = val*/
            Ref(_val_64778);
            _2 = (object)SEQ_PTR(_56exe_name_45396);
            _2 = (object)(((s1_ptr)_2)->base + 1);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _val_64778;
            DeRef(_1);
            goto L3; // [833] 875

            /** traninit.e:261				case "no-cygwin" then*/
            case 27:

            /** traninit.e:262					mno_cygwin = 1*/
            _56mno_cygwin_45417 = 1;
            goto L3; // [846] 875

            /** traninit.e:264				case "arch" then*/
            case 28:

            /** traninit.e:265					set_target_arch( upper( val ) )*/
            Ref(_val_64778);
            _31889 = _14upper(_val_64778);
            _46set_target_arch(_31889);
            _31889 = NOVALUE;
            goto L3; // [861] 875

            /** traninit.e:267				case "cc-prefix" then*/
            case 29:

            /** traninit.e:268					compiler_prefix = val*/
            Ref(_val_64778);
            DeRef(_56compiler_prefix_45394);
            _56compiler_prefix_45394 = _val_64778;
        ;}L3: 
        DeRef(_key_64776);
        _key_64776 = NOVALUE;
        DeRef(_val_64778);
        _val_64778 = NOVALUE;

        /** traninit.e:271		end for*/
        _idx_64774 = _idx_64774 + 1;
        goto L1; // [879] 75
L2: 
        ;
    }

    /** traninit.e:274		if dll_option then*/
    if (_58dll_option_42567 == 0)
    {
        goto LC; // [888] 925
    }
    else{
    }

    /** traninit.e:275			if TX86_64  then*/
    if (_46TX86_64_21610 == 0)
    {
        goto LD; // [895] 911
    }
    else{
    }

    /** traninit.e:277				user_pic_library = check_library( user_pic_library )*/
    RefDS(_58user_pic_library_42580);
    _0 = _3check_library(_58user_pic_library_42580);
    DeRefDS(_58user_pic_library_42580);
    _58user_pic_library_42580 = _0;
    goto LE; // [908] 936
LD: 

    /** traninit.e:279				user_library = check_library( user_library )*/
    RefDS(_58user_library_42579);
    _0 = _3check_library(_58user_library_42579);
    DeRefDS(_58user_library_42579);
    _58user_library_42579 = _0;
    goto LE; // [922] 936
LC: 

    /** traninit.e:282			user_library = check_library( user_library )*/
    RefDS(_58user_library_42579);
    _0 = _3check_library(_58user_library_42579);
    DeRefDS(_58user_library_42579);
    _58user_library_42579 = _0;
LE: 

    /** traninit.e:285		if length(exe_name[D_NAME]) and not absolute_path(exe_name[D_NAME]) then*/
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _31893 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_31893)){
            _31894 = SEQ_PTR(_31893)->length;
    }
    else {
        _31894 = 1;
    }
    _31893 = NOVALUE;
    if (_31894 == 0) {
        goto LF; // [949] 1002
    }
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _31896 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_31896);
    _31897 = _17absolute_path(_31896);
    _31896 = NOVALUE;
    if (IS_ATOM_INT(_31897)) {
        _31898 = (_31897 == 0);
    }
    else {
        _31898 = unary_op(NOT, _31897);
    }
    DeRef(_31897);
    _31897 = NOVALUE;
    if (_31898 == 0) {
        DeRef(_31898);
        _31898 = NOVALUE;
        goto LF; // [969] 1002
    }
    else {
        if (!IS_ATOM_INT(_31898) && DBL_PTR(_31898)->dbl == 0.0){
            DeRef(_31898);
            _31898 = NOVALUE;
            goto LF; // [969] 1002
        }
        DeRef(_31898);
        _31898 = NOVALUE;
    }
    DeRef(_31898);
    _31898 = NOVALUE;

    /** traninit.e:286			exe_name[D_NAME] = current_dir() & SLASH & exe_name[D_NAME]*/
    _31899 = _17current_dir();
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _31900 = (object)*(((s1_ptr)_2)->base + 1);
    {
        object concat_list[3];

        concat_list[0] = _31900;
        concat_list[1] = 47;
        concat_list[2] = _31899;
        Concat_N((object_ptr)&_31901, concat_list, 3);
    }
    _31900 = NOVALUE;
    DeRef(_31899);
    _31899 = NOVALUE;
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31901;
    if( _1 != _31901 ){
        DeRef(_1);
    }
    _31901 = NOVALUE;
LF: 

    /** traninit.e:288		exe_name[D_ALTNAME] = adjust_for_command_line_passing(exe_name[D_NAME])*/
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _31902 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_31902);
    _31903 = _56adjust_for_command_line_passing(_31902);
    _31902 = NOVALUE;
    _2 = (object)SEQ_PTR(_56exe_name_45396);
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31903;
    if( _1 != _31903 ){
        DeRef(_1);
    }
    _31903 = NOVALUE;

    /** traninit.e:290		if length(map:get(opts, OPT_EXTRAS)) = 0 then*/
    Ref(_opts_64764);
    RefDS(_4OPT_EXTRAS_14180);
    _31904 = _29get(_opts_64764, _4OPT_EXTRAS_14180, 0);
    if (IS_SEQUENCE(_31904)){
            _31905 = SEQ_PTR(_31904)->length;
    }
    else {
        _31905 = 1;
    }
    DeRef(_31904);
    _31904 = NOVALUE;
    if (_31905 != 0)
    goto L10; // [1037] 1060

    /** traninit.e:292			show_banner()*/
    _49show_banner();

    /** traninit.e:293			ShowMsg(2, ERROR_MUST_SPECIFY_THE_FILE_TO_BE_TRANSLATED_ON_THE_COMMAND_LINE)*/
    RefDS(_21997);
    _39ShowMsg(2, 203, _21997, 1);

    /** traninit.e:296			abort(1)*/
    UserCleanup(1);
L10: 

    /** traninit.e:299		OpDefines &= { "EUC" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_31907);
    ((intptr_t*)_2)[1] = _31907;
    _31908 = MAKE_SEQ(_1);
    Concat((object_ptr)&_36OpDefines_21524, _36OpDefines_21524, _31908);
    DeRefDS(_31908);
    _31908 = NOVALUE;

    /** traninit.e:301		if host_platform() = WIN32 and not con_option then*/
    _31910 = _46host_platform();
    if (IS_ATOM_INT(_31910)) {
        _31911 = (_31910 == 2);
    }
    else {
        _31911 = binary_op(EQUALS, _31910, 2);
    }
    DeRef(_31910);
    _31910 = NOVALUE;
    if (IS_ATOM_INT(_31911)) {
        if (_31911 == 0) {
            goto L11; // [1085] 1111
        }
    }
    else {
        if (DBL_PTR(_31911)->dbl == 0.0) {
            goto L11; // [1085] 1111
        }
    }
    _31913 = (_58con_option_42569 == 0);
    if (_31913 == 0)
    {
        DeRef(_31913);
        _31913 = NOVALUE;
        goto L11; // [1095] 1111
    }
    else{
        DeRef(_31913);
        _31913 = NOVALUE;
    }

    /** traninit.e:302			OpDefines = append( OpDefines, "GUI" )*/
    RefDS(_31914);
    Append(&_36OpDefines_21524, _36OpDefines_21524, _31914);
    goto L12; // [1108] 1135
L11: 

    /** traninit.e:303		elsif not find( "CONSOLE", OpDefines ) then*/
    _31916 = find_from(_31850, _36OpDefines_21524, 1);
    if (_31916 != 0)
    goto L13; // [1120] 1134
    _31916 = NOVALUE;

    /** traninit.e:304			OpDefines = append( OpDefines, "CONSOLE" )*/
    RefDS(_31850);
    Append(&_36OpDefines_21524, _36OpDefines_21524, _31850);
L13: 
L12: 

    /** traninit.e:307		ifdef not EUDIS then*/

    /** traninit.e:308			if build_system_type = BUILD_DIRECT and length(output_dir) = 0 then*/
    _31919 = (_56build_system_type_45389 == 3);
    if (_31919 == 0) {
        goto L14; // [1147] 1245
    }
    if (IS_SEQUENCE(_58output_dir_42581)){
            _31921 = SEQ_PTR(_58output_dir_42581)->length;
    }
    else {
        _31921 = 1;
    }
    _31922 = (_31921 == 0);
    _31921 = NOVALUE;
    if (_31922 == 0)
    {
        DeRef(_31922);
        _31922 = NOVALUE;
        goto L14; // [1161] 1245
    }
    else{
        DeRef(_31922);
        _31922 = NOVALUE;
    }

    /** traninit.e:309				output_dir = temp_file("." & SLASH, "build-", "")*/
    Append(&_31923, _23187, 47);
    RefDS(_31924);
    RefDS(_21997);
    _0 = _17temp_file(_31923, _31924, _21997, 0);
    DeRef(_58output_dir_42581);
    _58output_dir_42581 = _0;
    _31923 = NOVALUE;

    /** traninit.e:310				if find(output_dir[$], "/\\") = 0 then*/
    if (IS_SEQUENCE(_58output_dir_42581)){
            _31926 = SEQ_PTR(_58output_dir_42581)->length;
    }
    else {
        _31926 = 1;
    }
    _2 = (object)SEQ_PTR(_58output_dir_42581);
    _31927 = (object)*(((s1_ptr)_2)->base + _31926);
    _31928 = find_from(_31927, _23905, 1);
    _31927 = NOVALUE;
    if (_31928 != 0)
    goto L15; // [1197] 1212

    /** traninit.e:311					output_dir &= '/'*/
    Append(&_58output_dir_42581, _58output_dir_42581, 47);
L15: 

    /** traninit.e:314				if not silent then*/
    if (_36silent_21566 != 0)
    goto L16; // [1216] 1237

    /** traninit.e:315					printf(1, "Build directory: %s\n", { abbreviate_path(output_dir) })*/
    RefDS(_58output_dir_42581);
    RefDS(_21997);
    _31933 = _17abbreviate_path(_58output_dir_42581, _21997);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31933;
    _31934 = MAKE_SEQ(_1);
    _31933 = NOVALUE;
    EPrintf(1, _31932, _31934);
    DeRefDS(_31934);
    _31934 = NOVALUE;
L16: 

    /** traninit.e:318				remove_output_dir = 1*/
    _56remove_output_dir_45416 = 1;
L14: 

    /** traninit.e:322		if length(rc_file[D_NAME]) then*/
    _2 = (object)SEQ_PTR(_56rc_file_45402);
    _31935 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_31935)){
            _31936 = SEQ_PTR(_31935)->length;
    }
    else {
        _31936 = 1;
    }
    _31935 = NOVALUE;
    if (_31936 == 0)
    {
        _31936 = NOVALUE;
        goto L17; // [1258] 1320
    }
    else{
        _31936 = NOVALUE;
    }

    /** traninit.e:323			res_file[D_NAME] = canonical_path(output_dir & filebase(rc_file[D_NAME]) & ".res")*/
    _2 = (object)SEQ_PTR(_56rc_file_45402);
    _31937 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_31937);
    _31938 = _17filebase(_31937);
    _31937 = NOVALUE;
    {
        object concat_list[3];

        concat_list[0] = _31939;
        concat_list[1] = _31938;
        concat_list[2] = _58output_dir_42581;
        Concat_N((object_ptr)&_31940, concat_list, 3);
    }
    DeRef(_31938);
    _31938 = NOVALUE;
    _31941 = _17canonical_path(_31940, 0, 0);
    _31940 = NOVALUE;
    _2 = (object)SEQ_PTR(_56res_file_45408);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _56res_file_45408 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31941;
    if( _1 != _31941 ){
        DeRef(_1);
    }
    _31941 = NOVALUE;

    /** traninit.e:324			res_file[D_ALTNAME] = adjust_for_command_line_passing(res_file[D_NAME])*/
    _2 = (object)SEQ_PTR(_56res_file_45408);
    _31942 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_31942);
    _31943 = _56adjust_for_command_line_passing(_31942);
    _31942 = NOVALUE;
    _2 = (object)SEQ_PTR(_56res_file_45408);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _56res_file_45408 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31943;
    if( _1 != _31943 ){
        DeRef(_1);
    }
    _31943 = NOVALUE;
L17: 

    /** traninit.e:327		finalize_command_line(opts)*/
    Ref(_opts_64764);
    _49finalize_command_line(_opts_64764);

    /** traninit.e:328	end procedure*/
    DeRef(_tranopts_64752);
    DeRef(_opts_64764);
    DeRef(_opt_keys_64770);
    _31935 = NOVALUE;
    _31904 = NOVALUE;
    DeRef(_31919);
    _31919 = NOVALUE;
    _31893 = NOVALUE;
    DeRef(_31911);
    _31911 = NOVALUE;
    return;
    ;
}


void _3OpenCFiles()
{
    object _32005 = NOVALUE;
    object _31955 = NOVALUE;
    object _31949 = NOVALUE;
    object _31947 = NOVALUE;
    object _31946 = NOVALUE;
    object _31945 = NOVALUE;
    object _31944 = NOVALUE;
    object _0, _1, _2;
    

    /** traninit.e:333		if sequence(output_dir) and length(output_dir) > 0 then*/
    _31944 = 1;
    if (_31944 == 0) {
        goto L1; // [8] 38
    }
    if (IS_SEQUENCE(_58output_dir_42581)){
            _31946 = SEQ_PTR(_58output_dir_42581)->length;
    }
    else {
        _31946 = 1;
    }
    _31947 = (_31946 > 0);
    _31946 = NOVALUE;
    if (_31947 == 0)
    {
        DeRef(_31947);
        _31947 = NOVALUE;
        goto L1; // [22] 38
    }
    else{
        DeRef(_31947);
        _31947 = NOVALUE;
    }

    /** traninit.e:334			create_directory(output_dir)*/
    RefDS(_58output_dir_42581);
    _32005 = _17create_directory(_58output_dir_42581, 448, 1);
    DeRef(_32005);
    _32005 = NOVALUE;
L1: 

    /** traninit.e:337		c_code = open(output_dir & "init-.c", "w")*/
    Concat((object_ptr)&_31949, _58output_dir_42581, _31948);
    _55c_code_46627 = EOpen(_31949, _22133, 0);
    DeRefDS(_31949);
    _31949 = NOVALUE;

    /** traninit.e:338		if c_code = -1 then*/
    if (_55c_code_46627 != -1)
    goto L2; // [57] 71

    /** traninit.e:339			CompileErr(CANT_OPEN_INITC_FOR_OUTPUT)*/
    RefDS(_21997);
    _50CompileErr(55, _21997, 0);
L2: 

    /** traninit.e:342		add_file("init-.c")*/
    RefDS(_31948);
    RefDS(_21997);
    _58add_file(_31948, _21997);

    /** traninit.e:344		emit_c_output = TRUE*/
    _55emit_c_output_46624 = _13TRUE_452;

    /** traninit.e:346		c_puts("#include \"")*/
    RefDS(_31952);
    _55c_puts(_31952);

    /** traninit.e:347		c_puts("include/euphoria.h\"\n")*/
    RefDS(_31953);
    _55c_puts(_31953);

    /** traninit.e:349		c_puts("#include \"main-.h\"\n\n")*/
    RefDS(_22139);
    _55c_puts(_22139);

    /** traninit.e:350		c_h = open(output_dir & "main-.h", "w")*/
    Concat((object_ptr)&_31955, _58output_dir_42581, _31954);
    _55c_h_46628 = EOpen(_31955, _22133, 0);
    DeRefDS(_31955);
    _31955 = NOVALUE;

    /** traninit.e:351		if c_h = -1 then*/
    if (_55c_h_46628 != -1)
    goto L3; // [118] 132

    /** traninit.e:352			CompileErr(CANT_OPEN_MAINH_FILE_FOR_OUTPUT)*/
    RefDS(_21997);
    _50CompileErr(47, _21997, 0);
L3: 

    /** traninit.e:354		c_hputs("#include \"include/euphoria.h\"\n")*/
    RefDS(_22138);
    _55c_hputs(_22138);

    /** traninit.e:356		add_file("main-.h")*/
    RefDS(_31954);
    RefDS(_21997);
    _58add_file(_31954, _21997);

    /** traninit.e:357	end procedure*/
    return;
    ;
}


void _3InitBackEnd(object _c_65140)
{
    object _31988 = NOVALUE;
    object _31987 = NOVALUE;
    object _31985 = NOVALUE;
    object _31984 = NOVALUE;
    object _31983 = NOVALUE;
    object _31982 = NOVALUE;
    object _31981 = NOVALUE;
    object _31978 = NOVALUE;
    object _31977 = NOVALUE;
    object _31974 = NOVALUE;
    object _31973 = NOVALUE;
    object _31970 = NOVALUE;
    object _31969 = NOVALUE;
    object _31967 = NOVALUE;
    object _31964 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_65140)) {
        _1 = (object)(DBL_PTR(_c_65140)->dbl);
        DeRefDS(_c_65140);
        _c_65140 = _1;
    }

    /** traninit.e:363		if c = 1 then*/
    if (_c_65140 != 1)
    goto L1; // [5] 19

    /** traninit.e:364			OpenCFiles()*/
    _3OpenCFiles();

    /** traninit.e:366			return*/
    return;
L1: 

    /** traninit.e:369		init_opcodes()*/
    _59init_opcodes();

    /** traninit.e:370		transoptions()*/
    _3transoptions();

    /** traninit.e:372		if compiler_type = COMPILER_UNKNOWN then*/
    if (_56compiler_type_45393 != 0)
    goto L2; // [33] 75

    /** traninit.e:373			if TWINDOWS then*/
    if (_46TWINDOWS_21594 == 0)
    {
        goto L3; // [41] 56
    }
    else{
    }

    /** traninit.e:374				compiler_type = COMPILER_WATCOM*/
    _56compiler_type_45393 = 2;
    goto L4; // [53] 74
L3: 

    /** traninit.e:375			elsif TUNIX then*/
    if (_46TUNIX_21598 == 0)
    {
        goto L5; // [60] 73
    }
    else{
    }

    /** traninit.e:376				compiler_type = COMPILER_GCC*/
    _56compiler_type_45393 = 1;
L5: 
L4: 
L2: 

    /** traninit.e:380		switch compiler_type do*/
    _0 = _56compiler_type_45393;
    switch ( _0 ){ 

        /** traninit.e:381		  	case COMPILER_GCC then*/
        case 1:

        /** traninit.e:383				break -- to avoid empty block warning*/
        goto L6; // [90] 334
        goto L6; // [92] 334

        /** traninit.e:385			case COMPILER_WATCOM then*/
        case 2:

        /** traninit.e:386				wat_path = getenv("WATCOM")*/
        DeRefi(_36wat_path_21528);
        _36wat_path_21528 = EGetEnv(_31962);

        /** traninit.e:388				if atom(wat_path) then*/
        _31964 = IS_ATOM(_36wat_path_21528);
        if (_31964 == 0)
        {
            _31964 = NOVALUE;
            goto L7; // [110] 148
        }
        else{
            _31964 = NOVALUE;
        }

        /** traninit.e:389					if build_system_type = BUILD_DIRECT then*/
        if (_56build_system_type_45389 != 3)
        goto L8; // [119] 135

        /** traninit.e:392						CompileErr(WATCOM_ENVIRONMENT_VARIABLE_IS_NOT_SET)*/
        RefDS(_21997);
        _50CompileErr(159, _21997, 0);
        goto L6; // [132] 334
L8: 

        /** traninit.e:397						Warning(159, translator_warning_flag)*/
        RefDS(_21997);
        _50Warning(159, 128, _21997);
        goto L6; // [145] 334
L7: 

        /** traninit.e:399				elsif find(' ', wat_path) then*/
        _31967 = find_from(32, _36wat_path_21528, 1);
        if (_31967 == 0)
        {
            _31967 = NOVALUE;
            goto L9; // [157] 172
        }
        else{
            _31967 = NOVALUE;
        }

        /** traninit.e:400					Warning( 214, translator_warning_flag)*/
        RefDS(_21997);
        _50Warning(214, 128, _21997);
        goto L6; // [169] 334
L9: 

        /** traninit.e:401				elsif atom(getenv("INCLUDE")) then*/
        _31969 = EGetEnv(_31968);
        _31970 = IS_ATOM(_31969);
        DeRef(_31969);
        _31969 = NOVALUE;
        if (_31970 == 0)
        {
            _31970 = NOVALUE;
            goto LA; // [180] 195
        }
        else{
            _31970 = NOVALUE;
        }

        /** traninit.e:402					Warning( 215, translator_warning_flag )*/
        RefDS(_21997);
        _50Warning(215, 128, _21997);
        goto L6; // [192] 334
LA: 

        /** traninit.e:403				elsif not file_exists(wat_path & SLASH & "binnt" & SLASH & "wcc386.exe") then*/
        {
            object concat_list[5];

            concat_list[0] = _31972;
            concat_list[1] = 47;
            concat_list[2] = _31971;
            concat_list[3] = 47;
            concat_list[4] = _36wat_path_21528;
            Concat_N((object_ptr)&_31973, concat_list, 5);
        }
        _31974 = _17file_exists(_31973);
        _31973 = NOVALUE;
        if (IS_ATOM_INT(_31974)) {
            if (_31974 != 0){
                DeRef(_31974);
                _31974 = NOVALUE;
                goto LB; // [215] 265
            }
        }
        else {
            if (DBL_PTR(_31974)->dbl != 0.0){
                DeRef(_31974);
                _31974 = NOVALUE;
                goto LB; // [215] 265
            }
        }
        DeRef(_31974);
        _31974 = NOVALUE;

        /** traninit.e:404					if build_system_type = BUILD_DIRECT then*/
        if (_56build_system_type_45389 != 3)
        goto LC; // [224] 246

        /** traninit.e:405						CompileErr( THERE_IS_NO_WATCOM_INSTALATION_UNDER_SPECIFIED_WATOM_PATH_1, {wat_path})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_36wat_path_21528);
        ((intptr_t*)_2)[1] = _36wat_path_21528;
        _31977 = MAKE_SEQ(_1);
        _50CompileErr(352, _31977, 0);
        _31977 = NOVALUE;
        goto L6; // [243] 334
LC: 

        /** traninit.e:407						Warning( 352, translator_warning_flag, {wat_path})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_36wat_path_21528);
        ((intptr_t*)_2)[1] = _36wat_path_21528;
        _31978 = MAKE_SEQ(_1);
        _50Warning(352, 128, _31978);
        _31978 = NOVALUE;
        goto L6; // [262] 334
LB: 

        /** traninit.e:409				elsif match(upper(wat_path & "\\H;" & wat_path & "\\H\\NT"),*/
        {
            object concat_list[4];

            concat_list[0] = _31980;
            concat_list[1] = _36wat_path_21528;
            concat_list[2] = _31979;
            concat_list[3] = _36wat_path_21528;
            Concat_N((object_ptr)&_31981, concat_list, 4);
        }
        _31982 = _14upper(_31981);
        _31981 = NOVALUE;
        _31983 = EGetEnv(_31968);
        _31984 = _14upper(_31983);
        _31983 = NOVALUE;
        _31985 = e_match_from(_31982, _31984, 1);
        DeRef(_31982);
        _31982 = NOVALUE;
        DeRef(_31984);
        _31984 = NOVALUE;
        if (_31985 == 1)
        goto L6; // [294] 334

        /** traninit.e:412					Warning( 216, translator_warning_flag, {wat_path,getenv("INCLUDE")} )*/
        _31987 = EGetEnv(_31968);
        Ref(_36wat_path_21528);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _36wat_path_21528;
        ((intptr_t *)_2)[2] = _31987;
        _31988 = MAKE_SEQ(_1);
        _31987 = NOVALUE;
        _50Warning(216, 128, _31988);
        _31988 = NOVALUE;
        goto L6; // [318] 334

        /** traninit.e:415			case else*/
        default:

        /** traninit.e:416				CompileErr(UNKNOWN_COMPILER)*/
        RefDS(_21997);
        _50CompileErr(150, _21997, 0);
    ;}L6: 

    /** traninit.e:419	end procedure*/
    return;
    ;
}


void _3CheckPlatform()
{
    object _31994 = NOVALUE;
    object _31992 = NOVALUE;
    object _31991 = NOVALUE;
    object _0, _1, _2;
    

    /** traninit.e:425		OpDefines = eu:remove(OpDefines,*/
    _31991 = find_from(_25343, _36OpDefines_21524, 1);
    _31992 = find_from(_25344, _36OpDefines_21524, 1);
    {
        s1_ptr assign_space = SEQ_PTR(_36OpDefines_21524);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_31991)) ? _31991 : (object)(DBL_PTR(_31991)->dbl);
        int stop = (IS_ATOM_INT(_31992)) ? _31992 : (object)(DBL_PTR(_31992)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_36OpDefines_21524), start, &_36OpDefines_21524 );
            }
            else Tail(SEQ_PTR(_36OpDefines_21524), stop+1, &_36OpDefines_21524);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_36OpDefines_21524), start, &_36OpDefines_21524);
        }
        else {
            assign_slice_seq = &assign_space;
            _36OpDefines_21524 = Remove_elements(start, stop, (SEQ_PTR(_36OpDefines_21524)->ref == 1));
        }
    }
    _31991 = NOVALUE;
    _31992 = NOVALUE;

    /** traninit.e:428		OpDefines &= GetPlatformDefines(1)*/
    _31994 = _46GetPlatformDefines(1);
    if (IS_SEQUENCE(_36OpDefines_21524) && IS_ATOM(_31994)) {
        Ref(_31994);
        Append(&_36OpDefines_21524, _36OpDefines_21524, _31994);
    }
    else if (IS_ATOM(_36OpDefines_21524) && IS_SEQUENCE(_31994)) {
    }
    else {
        Concat((object_ptr)&_36OpDefines_21524, _36OpDefines_21524, _31994);
    }
    DeRef(_31994);
    _31994 = NOVALUE;

    /** traninit.e:429	end procedure*/
    return;
    ;
}


object _3check_library(object _lib_65257)
{
    object _32004 = NOVALUE;
    object _32003 = NOVALUE;
    object _32001 = NOVALUE;
    object _31999 = NOVALUE;
    object _31998 = NOVALUE;
    object _0, _1, _2;
    

    /** traninit.e:433		if equal( lib, "" ) then*/
    if (_lib_65257 == _21997)
    _31998 = 1;
    else if (IS_ATOM_INT(_lib_65257) && IS_ATOM_INT(_21997))
    _31998 = 0;
    else
    _31998 = (compare(_lib_65257, _21997) == 0);
    if (_31998 == 0)
    {
        _31998 = NOVALUE;
        goto L1; // [9] 19
    }
    else{
        _31998 = NOVALUE;
    }

    /** traninit.e:434			return ""*/
    RefDS(_21997);
    DeRefDS(_lib_65257);
    return _21997;
L1: 

    /** traninit.e:437		if not file_exists( lib ) then*/
    RefDS(_lib_65257);
    _31999 = _17file_exists(_lib_65257);
    if (IS_ATOM_INT(_31999)) {
        if (_31999 != 0){
            DeRef(_31999);
            _31999 = NOVALUE;
            goto L2; // [25] 69
        }
    }
    else {
        if (DBL_PTR(_31999)->dbl != 0.0){
            DeRef(_31999);
            _31999 = NOVALUE;
            goto L2; // [25] 69
        }
    }
    DeRef(_31999);
    _31999 = NOVALUE;

    /** traninit.e:438			ShowMsg(2, USER_SUPPLIED_LIBRARY_DOES_NOT_EXIST__1, { lib })*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_lib_65257);
    ((intptr_t*)_2)[1] = _lib_65257;
    _32001 = MAKE_SEQ(_1);
    _39ShowMsg(2, 348, _32001, 1);
    _32001 = NOVALUE;

    /** traninit.e:439			if force_build or build_system_type = BUILD_DIRECT then*/
    if (_56force_build_45415 != 0) {
        goto L3; // [46] 63
    }
    _32003 = (_56build_system_type_45389 == 3);
    if (_32003 == 0)
    {
        DeRef(_32003);
        _32003 = NOVALUE;
        goto L4; // [59] 68
    }
    else{
        DeRef(_32003);
        _32003 = NOVALUE;
    }
L3: 

    /** traninit.e:440				abort(1)*/
    UserCleanup(1);
L4: 
L2: 

    /** traninit.e:443		return canonical_path( lib )*/
    RefDS(_lib_65257);
    _32004 = _17canonical_path(_lib_65257, 0, 0);
    DeRefDS(_lib_65257);
    return _32004;
    ;
}



// 0x7244E485
