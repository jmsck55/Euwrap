// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _62set_qualified_fwd(object _fwd_25588)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_fwd_25588)) {
        _1 = (object)(DBL_PTR(_fwd_25588)->dbl);
        DeRefDS(_fwd_25588);
        _fwd_25588 = _1;
    }

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25585 = _fwd_25588;

    /** scanner.e:105	end procedure*/
    return;
    ;
}


object _62get_qualified_fwd()
{
    object _fwd_25591 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:108		integer fwd = qualified_fwd*/
    _fwd_25591 = _62qualified_fwd_25585;

    /** scanner.e:109		set_qualified_fwd( -1 )*/

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25585 = -1;

    /** scanner.e:105	end procedure*/
    goto L1; // [17] 20
L1: 

    /** scanner.e:110		return fwd*/
    return _fwd_25591;
    ;
}


void _62InitLex()
{
    object _14255 = NOVALUE;
    object _14254 = NOVALUE;
    object _14253 = NOVALUE;
    object _14251 = NOVALUE;
    object _14250 = NOVALUE;
    object _14249 = NOVALUE;
    object _14248 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:117		gline_number = 0*/
    _36gline_number_21452 = 0;

    /** scanner.e:118		line_number = 0*/
    _36line_number_21448 = 0;

    /** scanner.e:119		IncludeStk = {}*/
    RefDS(_5);
    DeRef(_62IncludeStk_25562);
    _62IncludeStk_25562 = _5;

    /** scanner.e:120		char_class = repeat(ILLEGAL_CHAR, 255)  -- we screen out the 0 character*/
    DeRefi(_62char_class_25560);
    _62char_class_25560 = Repeat(-20, 255);

    /** scanner.e:122		char_class['0'..'9'] = DIGIT*/
    assign_slice_seq = (s1_ptr *)&_62char_class_25560;
    AssignSlice(48, 57, -7);

    /** scanner.e:123		char_class['_']      = DIGIT*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 95);
    *(intptr_t *)_2 = -7;

    /** scanner.e:124		char_class['a'..'z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_62char_class_25560;
    AssignSlice(97, 122, -2);

    /** scanner.e:125		char_class['A'..'Z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_62char_class_25560;
    AssignSlice(65, 90, -2);

    /** scanner.e:126		char_class[KEYWORD_BASE+1..KEYWORD_BASE+NUM_KEYWORDS] = KEYWORD*/
    _14248 = 129;
    _14249 = 152;
    assign_slice_seq = (s1_ptr *)&_62char_class_25560;
    AssignSlice(129, 152, -10);
    _14248 = NOVALUE;
    _14249 = NOVALUE;

    /** scanner.e:127		char_class[BUILTIN_BASE+1..BUILTIN_BASE+NUM_BUILTINS] = BUILTIN*/
    _14250 = 171;
    _14251 = 234;
    assign_slice_seq = (s1_ptr *)&_62char_class_25560;
    AssignSlice(171, 234, -9);
    _14250 = NOVALUE;
    _14251 = NOVALUE;

    /** scanner.e:129		char_class[' '] = BLANK*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 32);
    *(intptr_t *)_2 = -8;

    /** scanner.e:130		char_class['\t'] = BLANK*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 9);
    *(intptr_t *)_2 = -8;

    /** scanner.e:131		char_class['+'] = PLUS*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 43);
    *(intptr_t *)_2 = 11;

    /** scanner.e:132		char_class['-'] = MINUS*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 45);
    *(intptr_t *)_2 = 10;

    /** scanner.e:133		char_class['*'] = res:MULTIPLY*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 42);
    *(intptr_t *)_2 = 13;

    /** scanner.e:134		char_class['/'] = res:DIVIDE*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 47);
    *(intptr_t *)_2 = 14;

    /** scanner.e:135		char_class['='] = EQUALS*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 61);
    *(intptr_t *)_2 = 3;

    /** scanner.e:136		char_class['<'] = LESS*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 60);
    *(intptr_t *)_2 = 1;

    /** scanner.e:137		char_class['>'] = GREATER*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 62);
    *(intptr_t *)_2 = 6;

    /** scanner.e:138		char_class['\''] = SINGLE_QUOTE*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 39);
    *(intptr_t *)_2 = -5;

    /** scanner.e:139		char_class['"'] = DOUBLE_QUOTE*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 34);
    *(intptr_t *)_2 = -4;

    /** scanner.e:140		char_class['`'] = BACK_QUOTE*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 96);
    *(intptr_t *)_2 = -12;

    /** scanner.e:141		char_class['.'] = DOT*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 46);
    *(intptr_t *)_2 = -3;

    /** scanner.e:142		char_class[':'] = COLON*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 58);
    *(intptr_t *)_2 = -23;

    /** scanner.e:143		char_class['\r'] = NEWLINE*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 13);
    *(intptr_t *)_2 = -6;

    /** scanner.e:144		char_class['\n'] = NEWLINE*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 10);
    *(intptr_t *)_2 = -6;

    /** scanner.e:145		char_class['!'] = BANG*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 33);
    *(intptr_t *)_2 = -1;

    /** scanner.e:146		char_class['{'] = LEFT_BRACE*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 123);
    *(intptr_t *)_2 = -24;

    /** scanner.e:147		char_class['}'] = RIGHT_BRACE*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 125);
    *(intptr_t *)_2 = -25;

    /** scanner.e:148		char_class['('] = LEFT_ROUND*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 40);
    *(intptr_t *)_2 = -26;

    /** scanner.e:149		char_class[')'] = RIGHT_ROUND*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 41);
    *(intptr_t *)_2 = -27;

    /** scanner.e:150		char_class['['] = LEFT_SQUARE*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 91);
    *(intptr_t *)_2 = -28;

    /** scanner.e:151		char_class[']'] = RIGHT_SQUARE*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 93);
    *(intptr_t *)_2 = -29;

    /** scanner.e:152		char_class['$'] = DOLLAR*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 36);
    *(intptr_t *)_2 = -22;

    /** scanner.e:153		char_class[','] = COMMA*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 44);
    *(intptr_t *)_2 = -30;

    /** scanner.e:154		char_class['&'] = res:CONCAT*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 38);
    *(intptr_t *)_2 = 15;

    /** scanner.e:155		char_class['?'] = QUESTION_MARK*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 63);
    *(intptr_t *)_2 = -31;

    /** scanner.e:156		char_class['#'] = NUMBER_SIGN*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 35);
    *(intptr_t *)_2 = -11;

    /** scanner.e:159		char_class[END_OF_FILE_CHAR] = END_OF_FILE*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _2 = (object)(((s1_ptr)_2)->base + 26);
    *(intptr_t *)_2 = -21;

    /** scanner.e:162		id_char = repeat(FALSE, 255)*/
    DeRefi(_62id_char_25561);
    _62id_char_25561 = Repeat(_13FALSE_450, 255);

    /** scanner.e:163		for i = 1 to 255 do*/
    {
        object _i_25639;
        _i_25639 = 1;
L1: 
        if (_i_25639 > 255){
            goto L2; // [407] 456
        }

        /** scanner.e:164			if find(char_class[i], {LETTER, DIGIT}) then*/
        _2 = (object)SEQ_PTR(_62char_class_25560);
        _14253 = (object)*(((s1_ptr)_2)->base + _i_25639);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -2;
        ((intptr_t *)_2)[2] = -7;
        _14254 = MAKE_SEQ(_1);
        _14255 = find_from(_14253, _14254, 1);
        _14253 = NOVALUE;
        DeRefDS(_14254);
        _14254 = NOVALUE;
        if (_14255 == 0)
        {
            _14255 = NOVALUE;
            goto L3; // [435] 449
        }
        else{
            _14255 = NOVALUE;
        }

        /** scanner.e:165				id_char[i] = TRUE*/
        _2 = (object)SEQ_PTR(_62id_char_25561);
        _2 = (object)(((s1_ptr)_2)->base + _i_25639);
        *(intptr_t *)_2 = _13TRUE_452;
L3: 

        /** scanner.e:167		end for*/
        _i_25639 = _i_25639 + 1;
        goto L1; // [451] 414
L2: 
        ;
    }

    /** scanner.e:169		default_namespaces = {0}*/
    _0 = _62default_namespaces_25559;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    _62default_namespaces_25559 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:170	end procedure*/
    return;
    ;
}


void _62ResetTP()
{
    object _0, _1, _2;
    

    /** scanner.e:174		OpTrace = FALSE*/
    _36OpTrace_21520 = _13FALSE_450;

    /** scanner.e:175		OpProfileStatement = FALSE*/
    _36OpProfileStatement_21522 = _13FALSE_450;

    /** scanner.e:176		OpProfileTime = FALSE*/
    _36OpProfileTime_21523 = _13FALSE_450;

    /** scanner.e:177		AnyStatementProfile = FALSE*/
    _37AnyStatementProfile_15429 = _13FALSE_450;

    /** scanner.e:178		AnyTimeProfile = FALSE*/
    _37AnyTimeProfile_15428 = _13FALSE_450;

    /** scanner.e:179	end procedure*/
    return;
    ;
}


object _62pack_source(object _src_25669)
{
    object _start_25670 = NOVALUE;
    object _14279 = NOVALUE;
    object _14278 = NOVALUE;
    object _14277 = NOVALUE;
    object _14276 = NOVALUE;
    object _14274 = NOVALUE;
    object _14272 = NOVALUE;
    object _14271 = NOVALUE;
    object _14270 = NOVALUE;
    object _14266 = NOVALUE;
    object _14264 = NOVALUE;
    object _14263 = NOVALUE;
    object _14260 = NOVALUE;
    object _14259 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:197		if equal(src, 0) then*/
    if (_src_25669 == 0)
    _14259 = 1;
    else if (IS_ATOM_INT(_src_25669) && IS_ATOM_INT(0))
    _14259 = 0;
    else
    _14259 = (compare(_src_25669, 0) == 0);
    if (_14259 == 0)
    {
        _14259 = NOVALUE;
        goto L1; // [7] 17
    }
    else{
        _14259 = NOVALUE;
    }

    /** scanner.e:198			return 0*/
    DeRef(_src_25669);
    return 0;
L1: 

    /** scanner.e:201		if length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_25669)){
            _14260 = SEQ_PTR(_src_25669)->length;
    }
    else {
        _14260 = 1;
    }
    if (_14260 < 10000)
    goto L2; // [22] 34

    /** scanner.e:202			src = src[1..100] -- enough for trace or profile display*/
    rhs_slice_target = (object_ptr)&_src_25669;
    RHS_Slice(_src_25669, 1, 100);
L2: 

    /** scanner.e:205		if current_source_next + length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_25669)){
            _14263 = SEQ_PTR(_src_25669)->length;
    }
    else {
        _14263 = 1;
    }
    _14264 = _62current_source_next_25665 + _14263;
    if ((object)((uintptr_t)_14264 + (uintptr_t)HIGH_BITS) >= 0){
        _14264 = NewDouble((eudouble)_14264);
    }
    _14263 = NOVALUE;
    if (binary_op_a(LESS, _14264, 10000)){
        DeRef(_14264);
        _14264 = NOVALUE;
        goto L3; // [45] 96
    }
    DeRef(_14264);
    _14264 = NOVALUE;

    /** scanner.e:207			current_source = allocate(SOURCE_CHUNK + LINE_BUFLEN)*/
    _14266 = 10400;
    _0 = _9allocate(10400, 0);
    DeRef(_62current_source_25664);
    _62current_source_25664 = _0;
    _14266 = NOVALUE;

    /** scanner.e:208			if current_source = 0 then*/
    if (binary_op_a(NOTEQ, _62current_source_25664, 0)){
        goto L4; // [64] 78
    }

    /** scanner.e:209				CompileErr(OUT_OF_MEMORY__TURN_OFF_TRACE_AND_PROFILE)*/
    RefDS(_21997);
    _50CompileErr(123, _21997, 0);
L4: 

    /** scanner.e:211			all_source = append(all_source, current_source)*/
    Ref(_62current_source_25664);
    Append(&_37all_source_15430, _37all_source_15430, _62current_source_25664);

    /** scanner.e:213			current_source_next = 1*/
    _62current_source_next_25665 = 1;
L3: 

    /** scanner.e:216		start = current_source_next*/
    _start_25670 = _62current_source_next_25665;

    /** scanner.e:217		poke(current_source+current_source_next, src)*/
    if (IS_ATOM_INT(_62current_source_25664)) {
        _14270 = _62current_source_25664 + _62current_source_next_25665;
        if ((object)((uintptr_t)_14270 + (uintptr_t)HIGH_BITS) >= 0){
            _14270 = NewDouble((eudouble)_14270);
        }
    }
    else {
        _14270 = NewDouble(DBL_PTR(_62current_source_25664)->dbl + (eudouble)_62current_source_next_25665);
    }
    if (IS_ATOM_INT(_14270)){
        poke_addr = (uint8_t *)_14270;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_14270)->dbl);
    }
    if (IS_ATOM_INT(_src_25669)) {
        *poke_addr = (uint8_t)_src_25669;
    }
    else if (IS_ATOM(_src_25669)) {
        *poke_addr = (uint8_t)DBL_PTR(_src_25669)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_src_25669);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke_addr++ = (uint8_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_14270);
    _14270 = NOVALUE;

    /** scanner.e:218		current_source_next += length(src)-1*/
    if (IS_SEQUENCE(_src_25669)){
            _14271 = SEQ_PTR(_src_25669)->length;
    }
    else {
        _14271 = 1;
    }
    _14272 = _14271 - 1;
    _14271 = NOVALUE;
    _62current_source_next_25665 = _62current_source_next_25665 + _14272;
    _14272 = NOVALUE;

    /** scanner.e:219		poke(current_source+current_source_next, 0) -- overwrite \n*/
    if (IS_ATOM_INT(_62current_source_25664)) {
        _14274 = _62current_source_25664 + _62current_source_next_25665;
        if ((object)((uintptr_t)_14274 + (uintptr_t)HIGH_BITS) >= 0){
            _14274 = NewDouble((eudouble)_14274);
        }
    }
    else {
        _14274 = NewDouble(DBL_PTR(_62current_source_25664)->dbl + (eudouble)_62current_source_next_25665);
    }
    if (IS_ATOM_INT(_14274)){
        poke_addr = (uint8_t *)_14274;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_14274)->dbl);
    }
    *poke_addr = (uint8_t)0;
    DeRef(_14274);
    _14274 = NOVALUE;

    /** scanner.e:220		current_source_next += 1*/
    _62current_source_next_25665 = _62current_source_next_25665 + 1;

    /** scanner.e:221		return start + SOURCE_CHUNK * (length(all_source)-1)*/
    if (IS_SEQUENCE(_37all_source_15430)){
            _14276 = SEQ_PTR(_37all_source_15430)->length;
    }
    else {
        _14276 = 1;
    }
    _14277 = _14276 - 1;
    _14276 = NOVALUE;
    if (_14277 <= INT15){
        _14278 = 10000 * _14277;
    }
    else{
        _14278 = NewDouble(10000 * (eudouble)_14277);
    }
    _14277 = NOVALUE;
    if (IS_ATOM_INT(_14278)) {
        _14279 = _start_25670 + _14278;
        if ((object)((uintptr_t)_14279 + (uintptr_t)HIGH_BITS) >= 0){
            _14279 = NewDouble((eudouble)_14279);
        }
    }
    else {
        _14279 = NewDouble((eudouble)_start_25670 + DBL_PTR(_14278)->dbl);
    }
    DeRef(_14278);
    _14278 = NOVALUE;
    DeRef(_src_25669);
    return _14279;
    ;
}


object _62fetch_line(object _start_25704)
{
    object _line_25705 = NOVALUE;
    object _memdata_25706 = NOVALUE;
    object _c_25707 = NOVALUE;
    object _chunk_25708 = NOVALUE;
    object _p_25709 = NOVALUE;
    object _n_25710 = NOVALUE;
    object _m_25711 = NOVALUE;
    object _14304 = NOVALUE;
    object _14303 = NOVALUE;
    object _14301 = NOVALUE;
    object _14299 = NOVALUE;
    object _14293 = NOVALUE;
    object _14291 = NOVALUE;
    object _14287 = NOVALUE;
    object _14285 = NOVALUE;
    object _14282 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:234		if start = 0 then*/
    if (_start_25704 != 0)
    goto L1; // [5] 16

    /** scanner.e:235			return ""*/
    RefDS(_5);
    DeRef(_line_25705);
    DeRefi(_memdata_25706);
    DeRef(_p_25709);
    return _5;
L1: 

    /** scanner.e:237		line = repeat(0, LINE_BUFLEN)*/
    DeRef(_line_25705);
    _line_25705 = Repeat(0, 400);

    /** scanner.e:238		n = 0*/
    _n_25710 = 0;

    /** scanner.e:239		chunk = 1+floor(start / SOURCE_CHUNK)*/
    if (10000 > 0 && _start_25704 >= 0) {
        _14282 = _start_25704 / 10000;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_start_25704 / (eudouble)10000);
        _14282 = (object)temp_dbl;
    }
    _chunk_25708 = _14282 + 1;
    _14282 = NOVALUE;

    /** scanner.e:240		start = remainder(start, SOURCE_CHUNK)*/
    _start_25704 = (_start_25704 % 10000);

    /** scanner.e:241		p = all_source[chunk] + start*/
    _2 = (object)SEQ_PTR(_37all_source_15430);
    _14285 = (object)*(((s1_ptr)_2)->base + _chunk_25708);
    DeRef(_p_25709);
    if (IS_ATOM_INT(_14285)) {
        _p_25709 = _14285 + _start_25704;
        if ((object)((uintptr_t)_p_25709 + (uintptr_t)HIGH_BITS) >= 0){
            _p_25709 = NewDouble((eudouble)_p_25709);
        }
    }
    else {
        _p_25709 = NewDouble(DBL_PTR(_14285)->dbl + (eudouble)_start_25704);
    }
    _14285 = NOVALUE;

    /** scanner.e:242		memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_25709);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _p_25709;
    ((intptr_t *)_2)[2] = 400;
    _14287 = MAKE_SEQ(_1);
    DeRefi(_memdata_25706);
    _1 = (object)SEQ_PTR(_14287);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _memdata_25706 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_14287);
    _14287 = NOVALUE;

    /** scanner.e:243		p += LINE_BUFLEN*/
    _0 = _p_25709;
    if (IS_ATOM_INT(_p_25709)) {
        _p_25709 = _p_25709 + 400;
        if ((object)((uintptr_t)_p_25709 + (uintptr_t)HIGH_BITS) >= 0){
            _p_25709 = NewDouble((eudouble)_p_25709);
        }
    }
    else {
        _p_25709 = NewDouble(DBL_PTR(_p_25709)->dbl + (eudouble)400);
    }
    DeRef(_0);

    /** scanner.e:244		m = 0*/
    _m_25711 = 0;

    /** scanner.e:245		while TRUE do*/
L2: 
    if (_13TRUE_452 == 0)
    {
        goto L3; // [84] 179
    }
    else{
    }

    /** scanner.e:246			m += 1*/
    _m_25711 = _m_25711 + 1;

    /** scanner.e:247			if m > length(memdata) then*/
    if (IS_SEQUENCE(_memdata_25706)){
            _14291 = SEQ_PTR(_memdata_25706)->length;
    }
    else {
        _14291 = 1;
    }
    if (_m_25711 <= _14291)
    goto L4; // [98] 125

    /** scanner.e:248				memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_25709);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _p_25709;
    ((intptr_t *)_2)[2] = 400;
    _14293 = MAKE_SEQ(_1);
    DeRefDSi(_memdata_25706);
    _1 = (object)SEQ_PTR(_14293);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _memdata_25706 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_14293);
    _14293 = NOVALUE;

    /** scanner.e:249				p += LINE_BUFLEN*/
    _0 = _p_25709;
    if (IS_ATOM_INT(_p_25709)) {
        _p_25709 = _p_25709 + 400;
        if ((object)((uintptr_t)_p_25709 + (uintptr_t)HIGH_BITS) >= 0){
            _p_25709 = NewDouble((eudouble)_p_25709);
        }
    }
    else {
        _p_25709 = NewDouble(DBL_PTR(_p_25709)->dbl + (eudouble)400);
    }
    DeRef(_0);

    /** scanner.e:250				m = 1*/
    _m_25711 = 1;
L4: 

    /** scanner.e:252			c = memdata[m]*/
    _2 = (object)SEQ_PTR(_memdata_25706);
    _c_25707 = (object)*(((s1_ptr)_2)->base + _m_25711);

    /** scanner.e:253			if c = 0 then*/
    if (_c_25707 != 0)
    goto L5; // [133] 142

    /** scanner.e:254				exit*/
    goto L3; // [139] 179
L5: 

    /** scanner.e:256			n += 1*/
    _n_25710 = _n_25710 + 1;

    /** scanner.e:257			if n > length(line) then*/
    if (IS_SEQUENCE(_line_25705)){
            _14299 = SEQ_PTR(_line_25705)->length;
    }
    else {
        _14299 = 1;
    }
    if (_n_25710 <= _14299)
    goto L6; // [153] 168

    /** scanner.e:258				line &= repeat(0, LINE_BUFLEN)*/
    _14301 = Repeat(0, 400);
    Concat((object_ptr)&_line_25705, _line_25705, _14301);
    DeRefDS(_14301);
    _14301 = NOVALUE;
L6: 

    /** scanner.e:260			line[n] = c*/
    _2 = (object)SEQ_PTR(_line_25705);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _line_25705 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _n_25710);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _c_25707;
    DeRef(_1);

    /** scanner.e:261		end while*/
    goto L2; // [176] 82
L3: 

    /** scanner.e:262		line = remove( line, n+1, length( line ) )*/
    _14303 = _n_25710 + 1;
    if (_14303 > MAXINT){
        _14303 = NewDouble((eudouble)_14303);
    }
    if (IS_SEQUENCE(_line_25705)){
            _14304 = SEQ_PTR(_line_25705)->length;
    }
    else {
        _14304 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_line_25705);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_14303)) ? _14303 : (object)(DBL_PTR(_14303)->dbl);
        int stop = (IS_ATOM_INT(_14304)) ? _14304 : (object)(DBL_PTR(_14304)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_line_25705), start, &_line_25705 );
            }
            else Tail(SEQ_PTR(_line_25705), stop+1, &_line_25705);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_line_25705), start, &_line_25705);
        }
        else {
            assign_slice_seq = &assign_space;
            _line_25705 = Remove_elements(start, stop, (SEQ_PTR(_line_25705)->ref == 1));
        }
    }
    DeRef(_14303);
    _14303 = NOVALUE;
    _14304 = NOVALUE;

    /** scanner.e:263		return line*/
    DeRefi(_memdata_25706);
    DeRef(_p_25709);
    return _line_25705;
    ;
}


void _62AppendSourceLine()
{
    object _new_25747 = NOVALUE;
    object _old_25748 = NOVALUE;
    object _options_25749 = NOVALUE;
    object _src_25750 = NOVALUE;
    object _14345 = NOVALUE;
    object _14341 = NOVALUE;
    object _14339 = NOVALUE;
    object _14338 = NOVALUE;
    object _14335 = NOVALUE;
    object _14334 = NOVALUE;
    object _14333 = NOVALUE;
    object _14332 = NOVALUE;
    object _14331 = NOVALUE;
    object _14330 = NOVALUE;
    object _14329 = NOVALUE;
    object _14328 = NOVALUE;
    object _14327 = NOVALUE;
    object _14326 = NOVALUE;
    object _14325 = NOVALUE;
    object _14324 = NOVALUE;
    object _14323 = NOVALUE;
    object _14322 = NOVALUE;
    object _14321 = NOVALUE;
    object _14320 = NOVALUE;
    object _14319 = NOVALUE;
    object _14318 = NOVALUE;
    object _14316 = NOVALUE;
    object _14315 = NOVALUE;
    object _14314 = NOVALUE;
    object _14312 = NOVALUE;
    object _14307 = NOVALUE;
    object _14306 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:272		src = 0*/
    DeRef(_src_25750);
    _src_25750 = 0;

    /** scanner.e:273		options = 0*/
    _options_25749 = 0;

    /** scanner.e:275		if TRANSLATE or OpTrace or OpProfileStatement or OpProfileTime then*/
    if (_36TRANSLATE_21049 != 0) {
        _14306 = 1;
        goto L1; // [15] 25
    }
    _14306 = (_36OpTrace_21520 != 0);
L1: 
    if (_14306 != 0) {
        _14307 = 1;
        goto L2; // [25] 35
    }
    _14307 = (_36OpProfileStatement_21522 != 0);
L2: 
    if (_14307 != 0) {
        goto L3; // [35] 46
    }
    if (_36OpProfileTime_21523 == 0)
    {
        goto L4; // [42] 136
    }
    else{
    }
L3: 

    /** scanner.e:277			src = ThisLine*/
    Ref(_50ThisLine_49238);
    DeRef(_src_25750);
    _src_25750 = _50ThisLine_49238;

    /** scanner.e:279			if OpTrace then*/
    if (_36OpTrace_21520 == 0)
    {
        goto L5; // [57] 70
    }
    else{
    }

    /** scanner.e:280				options = SOP_TRACE*/
    _options_25749 = 1;
L5: 

    /** scanner.e:282			if OpProfileTime then*/
    if (_36OpProfileTime_21523 == 0)
    {
        goto L6; // [74] 88
    }
    else{
    }

    /** scanner.e:283				options = or_bits(options, SOP_PROFILE_TIME)*/
    {uintptr_t tu;
         tu = (uintptr_t)_options_25749 | (uintptr_t)2;
         _options_25749 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_25749)) {
        _1 = (object)(DBL_PTR(_options_25749)->dbl);
        DeRefDS(_options_25749);
        _options_25749 = _1;
    }
L6: 

    /** scanner.e:285			if OpProfileStatement then*/
    if (_36OpProfileStatement_21522 == 0)
    {
        goto L7; // [92] 106
    }
    else{
    }

    /** scanner.e:286				options = or_bits(options, SOP_PROFILE_STATEMENT)*/
    {uintptr_t tu;
         tu = (uintptr_t)_options_25749 | (uintptr_t)4;
         _options_25749 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_25749)) {
        _1 = (object)(DBL_PTR(_options_25749)->dbl);
        DeRefDS(_options_25749);
        _options_25749 = _1;
    }
L7: 

    /** scanner.e:288			if OpProfileStatement or OpProfileTime then*/
    if (_36OpProfileStatement_21522 != 0) {
        goto L8; // [110] 121
    }
    if (_36OpProfileTime_21523 == 0)
    {
        goto L9; // [117] 135
    }
    else{
    }
L8: 

    /** scanner.e:289				src = {0,0,0,0} & src*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 0;
    ((intptr_t*)_2)[4] = 0;
    _14312 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_14312) && IS_ATOM(_src_25750)) {
        Ref(_src_25750);
        Append(&_src_25750, _14312, _src_25750);
    }
    else if (IS_ATOM(_14312) && IS_SEQUENCE(_src_25750)) {
    }
    else {
        Concat((object_ptr)&_src_25750, _14312, _src_25750);
        DeRefDS(_14312);
        _14312 = NOVALUE;
    }
    DeRef(_14312);
    _14312 = NOVALUE;
L9: 
L4: 

    /** scanner.e:293		if length(slist) then*/
    if (IS_SEQUENCE(_36slist_21541)){
            _14314 = SEQ_PTR(_36slist_21541)->length;
    }
    else {
        _14314 = 1;
    }
    if (_14314 == 0)
    {
        _14314 = NOVALUE;
        goto LA; // [143] 345
    }
    else{
        _14314 = NOVALUE;
    }

    /** scanner.e:294			old = slist[$-1]*/
    if (IS_SEQUENCE(_36slist_21541)){
            _14315 = SEQ_PTR(_36slist_21541)->length;
    }
    else {
        _14315 = 1;
    }
    _14316 = _14315 - 1;
    _14315 = NOVALUE;
    DeRef(_old_25748);
    _2 = (object)SEQ_PTR(_36slist_21541);
    _old_25748 = (object)*(((s1_ptr)_2)->base + _14316);
    Ref(_old_25748);

    /** scanner.e:296			if equal(src, old[SRC]) and*/
    _2 = (object)SEQ_PTR(_old_25748);
    _14318 = (object)*(((s1_ptr)_2)->base + 1);
    if (_src_25750 == _14318)
    _14319 = 1;
    else if (IS_ATOM_INT(_src_25750) && IS_ATOM_INT(_14318))
    _14319 = 0;
    else
    _14319 = (compare(_src_25750, _14318) == 0);
    _14318 = NOVALUE;
    if (_14319 == 0) {
        _14320 = 0;
        goto LB; // [175] 195
    }
    _2 = (object)SEQ_PTR(_old_25748);
    _14321 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_14321)) {
        _14322 = (_36current_file_no_21447 == _14321);
    }
    else {
        _14322 = binary_op(EQUALS, _36current_file_no_21447, _14321);
    }
    _14321 = NOVALUE;
    if (IS_ATOM_INT(_14322))
    _14320 = (_14322 != 0);
    else
    _14320 = DBL_PTR(_14322)->dbl != 0.0;
LB: 
    if (_14320 == 0) {
        _14323 = 0;
        goto LC; // [195] 232
    }
    _2 = (object)SEQ_PTR(_old_25748);
    _14324 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_14324)) {
        _14325 = _14324 + 1;
        if (_14325 > MAXINT){
            _14325 = NewDouble((eudouble)_14325);
        }
    }
    else
    _14325 = binary_op(PLUS, 1, _14324);
    _14324 = NOVALUE;
    if (IS_SEQUENCE(_36slist_21541)){
            _14326 = SEQ_PTR(_36slist_21541)->length;
    }
    else {
        _14326 = 1;
    }
    _2 = (object)SEQ_PTR(_36slist_21541);
    _14327 = (object)*(((s1_ptr)_2)->base + _14326);
    if (IS_ATOM_INT(_14325) && IS_ATOM_INT(_14327)) {
        _14328 = _14325 + _14327;
        if ((object)((uintptr_t)_14328 + (uintptr_t)HIGH_BITS) >= 0){
            _14328 = NewDouble((eudouble)_14328);
        }
    }
    else {
        _14328 = binary_op(PLUS, _14325, _14327);
    }
    DeRef(_14325);
    _14325 = NOVALUE;
    _14327 = NOVALUE;
    if (IS_ATOM_INT(_14328)) {
        _14329 = (_36line_number_21448 == _14328);
    }
    else {
        _14329 = binary_op(EQUALS, _36line_number_21448, _14328);
    }
    DeRef(_14328);
    _14328 = NOVALUE;
    if (IS_ATOM_INT(_14329))
    _14323 = (_14329 != 0);
    else
    _14323 = DBL_PTR(_14329)->dbl != 0.0;
LC: 
    if (_14323 == 0) {
        goto LD; // [232] 272
    }
    _2 = (object)SEQ_PTR(_old_25748);
    _14331 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_14331)) {
        _14332 = (_options_25749 == _14331);
    }
    else {
        _14332 = binary_op(EQUALS, _options_25749, _14331);
    }
    _14331 = NOVALUE;
    if (_14332 == 0) {
        DeRef(_14332);
        _14332 = NOVALUE;
        goto LD; // [247] 272
    }
    else {
        if (!IS_ATOM_INT(_14332) && DBL_PTR(_14332)->dbl == 0.0){
            DeRef(_14332);
            _14332 = NOVALUE;
            goto LD; // [247] 272
        }
        DeRef(_14332);
        _14332 = NOVALUE;
    }
    DeRef(_14332);
    _14332 = NOVALUE;

    /** scanner.e:302				slist[$] += 1*/
    if (IS_SEQUENCE(_36slist_21541)){
            _14333 = SEQ_PTR(_36slist_21541)->length;
    }
    else {
        _14333 = 1;
    }
    _2 = (object)SEQ_PTR(_36slist_21541);
    _14334 = (object)*(((s1_ptr)_2)->base + _14333);
    if (IS_ATOM_INT(_14334)) {
        _14335 = _14334 + 1;
        if (_14335 > MAXINT){
            _14335 = NewDouble((eudouble)_14335);
        }
    }
    else
    _14335 = binary_op(PLUS, 1, _14334);
    _14334 = NOVALUE;
    _2 = (object)SEQ_PTR(_36slist_21541);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36slist_21541 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14333);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14335;
    if( _1 != _14335 ){
        DeRef(_1);
    }
    _14335 = NOVALUE;
    goto LE; // [269] 371
LD: 

    /** scanner.e:304				src = pack_source(src)*/
    Ref(_src_25750);
    _0 = _src_25750;
    _src_25750 = _62pack_source(_src_25750);
    DeRef(_0);

    /** scanner.e:305				new = {src, line_number, current_file_no, options}*/
    _0 = _new_25747;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_src_25750);
    ((intptr_t*)_2)[1] = _src_25750;
    ((intptr_t*)_2)[2] = _36line_number_21448;
    ((intptr_t*)_2)[3] = _36current_file_no_21447;
    ((intptr_t*)_2)[4] = _options_25749;
    _new_25747 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:306				if slist[$] = 0 then*/
    if (IS_SEQUENCE(_36slist_21541)){
            _14338 = SEQ_PTR(_36slist_21541)->length;
    }
    else {
        _14338 = 1;
    }
    _2 = (object)SEQ_PTR(_36slist_21541);
    _14339 = (object)*(((s1_ptr)_2)->base + _14338);
    if (binary_op_a(NOTEQ, _14339, 0)){
        _14339 = NOVALUE;
        goto LF; // [302] 320
    }
    _14339 = NOVALUE;

    /** scanner.e:307					slist[$] = new*/
    if (IS_SEQUENCE(_36slist_21541)){
            _14341 = SEQ_PTR(_36slist_21541)->length;
    }
    else {
        _14341 = 1;
    }
    RefDS(_new_25747);
    _2 = (object)SEQ_PTR(_36slist_21541);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36slist_21541 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14341);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_25747;
    DeRef(_1);
    goto L10; // [317] 331
LF: 

    /** scanner.e:309					slist = append(slist, new)*/
    RefDS(_new_25747);
    Append(&_36slist_21541, _36slist_21541, _new_25747);
L10: 

    /** scanner.e:311				slist = append(slist, 0)*/
    Append(&_36slist_21541, _36slist_21541, 0);
    goto LE; // [342] 371
LA: 

    /** scanner.e:314			src = pack_source(src)*/
    Ref(_src_25750);
    _0 = _src_25750;
    _src_25750 = _62pack_source(_src_25750);
    DeRef(_0);

    /** scanner.e:315			slist = {{src, line_number, current_file_no, options}, 0}*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_src_25750);
    ((intptr_t*)_2)[1] = _src_25750;
    ((intptr_t*)_2)[2] = _36line_number_21448;
    ((intptr_t*)_2)[3] = _36current_file_no_21447;
    ((intptr_t*)_2)[4] = _options_25749;
    _14345 = MAKE_SEQ(_1);
    DeRef(_36slist_21541);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14345;
    ((intptr_t *)_2)[2] = 0;
    _36slist_21541 = MAKE_SEQ(_1);
    _14345 = NOVALUE;
LE: 

    /** scanner.e:317	end procedure*/
    DeRef(_new_25747);
    DeRef(_old_25748);
    DeRef(_src_25750);
    DeRef(_14316);
    _14316 = NOVALUE;
    DeRef(_14329);
    _14329 = NOVALUE;
    DeRef(_14322);
    _14322 = NOVALUE;
    return;
    ;
}


object _62s_expand(object _slist_25839)
{
    object _new_slist_25840 = NOVALUE;
    object _14359 = NOVALUE;
    object _14358 = NOVALUE;
    object _14357 = NOVALUE;
    object _14356 = NOVALUE;
    object _14354 = NOVALUE;
    object _14353 = NOVALUE;
    object _14352 = NOVALUE;
    object _14350 = NOVALUE;
    object _14349 = NOVALUE;
    object _14348 = NOVALUE;
    object _14347 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:323		new_slist = {}*/
    RefDS(_5);
    DeRef(_new_slist_25840);
    _new_slist_25840 = _5;

    /** scanner.e:325		for i = 1 to length(slist) do*/
    if (IS_SEQUENCE(_slist_25839)){
            _14347 = SEQ_PTR(_slist_25839)->length;
    }
    else {
        _14347 = 1;
    }
    {
        object _i_25842;
        _i_25842 = 1;
L1: 
        if (_i_25842 > _14347){
            goto L2; // [15] 114
        }

        /** scanner.e:326			if sequence(slist[i]) then*/
        _2 = (object)SEQ_PTR(_slist_25839);
        _14348 = (object)*(((s1_ptr)_2)->base + _i_25842);
        _14349 = IS_SEQUENCE(_14348);
        _14348 = NOVALUE;
        if (_14349 == 0)
        {
            _14349 = NOVALUE;
            goto L3; // [31] 47
        }
        else{
            _14349 = NOVALUE;
        }

        /** scanner.e:327				new_slist = append(new_slist, slist[i])*/
        _2 = (object)SEQ_PTR(_slist_25839);
        _14350 = (object)*(((s1_ptr)_2)->base + _i_25842);
        Ref(_14350);
        Append(&_new_slist_25840, _new_slist_25840, _14350);
        _14350 = NOVALUE;
        goto L4; // [44] 107
L3: 

        /** scanner.e:329				for j = 1 to slist[i] do*/
        _2 = (object)SEQ_PTR(_slist_25839);
        _14352 = (object)*(((s1_ptr)_2)->base + _i_25842);
        {
            object _j_25851;
            _j_25851 = 1;
L5: 
            if (binary_op_a(GREATER, _j_25851, _14352)){
                goto L6; // [53] 106
            }

            /** scanner.e:330					slist[i-1][LINE] += 1*/
            _14353 = _i_25842 - 1;
            _2 = (object)SEQ_PTR(_slist_25839);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _slist_25839 = MAKE_SEQ(_2);
            }
            _3 = (object)(_14353 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            _14356 = (object)*(((s1_ptr)_2)->base + 2);
            _14354 = NOVALUE;
            if (IS_ATOM_INT(_14356)) {
                _14357 = _14356 + 1;
                if (_14357 > MAXINT){
                    _14357 = NewDouble((eudouble)_14357);
                }
            }
            else
            _14357 = binary_op(PLUS, 1, _14356);
            _14356 = NOVALUE;
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 2);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _14357;
            if( _1 != _14357 ){
                DeRef(_1);
            }
            _14357 = NOVALUE;
            _14354 = NOVALUE;

            /** scanner.e:331					new_slist = append(new_slist, slist[i-1])*/
            _14358 = _i_25842 - 1;
            _2 = (object)SEQ_PTR(_slist_25839);
            _14359 = (object)*(((s1_ptr)_2)->base + _14358);
            Ref(_14359);
            Append(&_new_slist_25840, _new_slist_25840, _14359);
            _14359 = NOVALUE;

            /** scanner.e:332				end for*/
            _0 = _j_25851;
            if (IS_ATOM_INT(_j_25851)) {
                _j_25851 = _j_25851 + 1;
                if ((object)((uintptr_t)_j_25851 +(uintptr_t) HIGH_BITS) >= 0){
                    _j_25851 = NewDouble((eudouble)_j_25851);
                }
            }
            else {
                _j_25851 = binary_op_a(PLUS, _j_25851, 1);
            }
            DeRef(_0);
            goto L5; // [101] 60
L6: 
            ;
            DeRef(_j_25851);
        }
L4: 

        /** scanner.e:334		end for*/
        _i_25842 = _i_25842 + 1;
        goto L1; // [109] 22
L2: 
        ;
    }

    /** scanner.e:335		return new_slist*/
    DeRefDS(_slist_25839);
    DeRef(_14353);
    _14353 = NOVALUE;
    DeRef(_14358);
    _14358 = NOVALUE;
    _14352 = NOVALUE;
    return _new_slist_25840;
    ;
}


void _62set_dont_read(object _read_25866)
{
    object _0, _1, _2;
    

    /** scanner.e:357		dont_read = read*/
    _62dont_read_25863 = _read_25866;

    /** scanner.e:358	end procedure*/
    return;
    ;
}


void _62read_line()
{
    object _n_25872 = NOVALUE;
    object _14389 = NOVALUE;
    object _14388 = NOVALUE;
    object _14387 = NOVALUE;
    object _14386 = NOVALUE;
    object _14385 = NOVALUE;
    object _14383 = NOVALUE;
    object _14382 = NOVALUE;
    object _14380 = NOVALUE;
    object _14379 = NOVALUE;
    object _14378 = NOVALUE;
    object _14377 = NOVALUE;
    object _14369 = NOVALUE;
    object _14367 = NOVALUE;
    object _14366 = NOVALUE;
    object _14365 = NOVALUE;
    object _14364 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:367		line_number += 1*/
    _36line_number_21448 = _36line_number_21448 + 1;

    /** scanner.e:368		gline_number += 1*/
    _36gline_number_21452 = _36gline_number_21452 + 1;

    /** scanner.e:370		if dont_read then*/
    if (_62dont_read_25863 == 0)
    {
        goto L1; // [25] 36
    }
    else{
    }

    /** scanner.e:371			ThisLine = -1*/
    DeRef(_50ThisLine_49238);
    _50ThisLine_49238 = -1;
    goto L2; // [33] 216
L1: 

    /** scanner.e:372		elsif repl and src_file = repl_file then*/
    if (0 == 0) {
        goto L3; // [40] 144
    }
    _14365 = (_36src_file_21572 == 5555);
    if (_14365 == 0)
    {
        DeRef(_14365);
        _14365 = NOVALUE;
        goto L3; // [53] 144
    }
    else{
        DeRef(_14365);
        _14365 = NOVALUE;
    }

    /** scanner.e:373			if repl_line_was_read and current_block = top_level_block then*/
    if (_62repl_line_was_read_25867 == 0) {
        goto L4; // [60] 118
    }
    _14367 = (_65current_block_25120 == _65top_level_block_25121);
    if (_14367 == 0)
    {
        DeRef(_14367);
        _14367 = NOVALUE;
        goto L4; // [73] 118
    }
    else{
        DeRef(_14367);
        _14367 = NOVALUE;
    }

    /** scanner.e:374				if repl_line_was_read > 1 then*/
    if (_62repl_line_was_read_25867 <= 1)
    goto L5; // [80] 110

    /** scanner.e:375					if not match("end", ThisLine) then*/
    _14369 = e_match_from(_13143, _50ThisLine_49238, 1);
    if (_14369 != 0)
    goto L6; // [93] 109
    _14369 = NOVALUE;

    /** scanner.e:376						goto "lol"*/
    goto G7;
L6: 
L5: 

    /** scanner.e:379				ThisLine = -1*/
    DeRef(_50ThisLine_49238);
    _50ThisLine_49238 = -1;
    goto L2; // [115] 216
L4: 

    /** scanner.e:381				label "lol"*/
G7:

    /** scanner.e:382				puts(1, "Enter line:\n")*/
    EPuts(1, _14372); // DJP 

    /** scanner.e:383				repl_line_was_read += 1*/
    _62repl_line_was_read_25867 = _62repl_line_was_read_25867 + 1;

    /** scanner.e:384				ThisLine = gets(0)*/
    DeRef(_50ThisLine_49238);
    _50ThisLine_49238 = EGets(0);
    goto L2; // [141] 216
L3: 

    /** scanner.e:386		elsif src_file < 0 then*/
    if (_36src_file_21572 >= 0)
    goto L8; // [148] 160

    /** scanner.e:387			ThisLine = -1*/
    DeRef(_50ThisLine_49238);
    _50ThisLine_49238 = -1;
    goto L2; // [157] 216
L8: 

    /** scanner.e:389			ThisLine = gets(src_file)*/
    DeRef(_50ThisLine_49238);
    _50ThisLine_49238 = EGets(_36src_file_21572);

    /** scanner.e:390			if sequence(ThisLine) and ends( {13,10}, ThisLine ) then*/
    _14377 = IS_SEQUENCE(_50ThisLine_49238);
    if (_14377 == 0) {
        goto L9; // [174] 215
    }
    RefDS(_12173);
    Ref(_50ThisLine_49238);
    _14379 = _16ends(_12173, _50ThisLine_49238);
    if (_14379 == 0) {
        DeRef(_14379);
        _14379 = NOVALUE;
        goto L9; // [186] 215
    }
    else {
        if (!IS_ATOM_INT(_14379) && DBL_PTR(_14379)->dbl == 0.0){
            DeRef(_14379);
            _14379 = NOVALUE;
            goto L9; // [186] 215
        }
        DeRef(_14379);
        _14379 = NOVALUE;
    }
    DeRef(_14379);
    _14379 = NOVALUE;

    /** scanner.e:391				ThisLine = remove(ThisLine, length(ThisLine))*/
    if (IS_SEQUENCE(_50ThisLine_49238)){
            _14380 = SEQ_PTR(_50ThisLine_49238)->length;
    }
    else {
        _14380 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_50ThisLine_49238);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_14380)) ? _14380 : (object)(DBL_PTR(_14380)->dbl);
        int stop = (IS_ATOM_INT(_14380)) ? _14380 : (object)(DBL_PTR(_14380)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_50ThisLine_49238), start, &_50ThisLine_49238 );
            }
            else Tail(SEQ_PTR(_50ThisLine_49238), stop+1, &_50ThisLine_49238);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_50ThisLine_49238), start, &_50ThisLine_49238);
        }
        else {
            assign_slice_seq = &assign_space;
            _50ThisLine_49238 = Remove_elements(start, stop, (SEQ_PTR(_50ThisLine_49238)->ref == 1));
        }
    }
    _14380 = NOVALUE;
    _14380 = NOVALUE;

    /** scanner.e:392				ThisLine[$] = 10*/
    if (IS_SEQUENCE(_50ThisLine_49238)){
            _14382 = SEQ_PTR(_50ThisLine_49238)->length;
    }
    else {
        _14382 = 1;
    }
    _2 = (object)SEQ_PTR(_50ThisLine_49238);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _50ThisLine_49238 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14382);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 10;
    DeRef(_1);
L9: 
L2: 

    /** scanner.e:395		if atom(ThisLine) then*/
    _14383 = IS_ATOM(_50ThisLine_49238);
    if (_14383 == 0)
    {
        _14383 = NOVALUE;
        goto LA; // [223] 286
    }
    else{
        _14383 = NOVALUE;
    }

    /** scanner.e:396			ThisLine = {END_OF_FILE_CHAR}*/
    _0 = _50ThisLine_49238;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 26;
    _50ThisLine_49238 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:397			if src_file >= 0 and (src_file != repl_file or not repl) then*/
    _14385 = (_36src_file_21572 >= 0);
    if (_14385 == 0) {
        goto LB; // [242] 278
    }
    _14387 = (_36src_file_21572 != 5555);
    if (_14387 != 0) {
        DeRef(_14388);
        _14388 = 1;
        goto LC; // [254] 267
    }
    _14389 = (0 == 0);
    _14388 = (_14389 != 0);
LC: 
    if (_14388 == 0)
    {
        _14388 = NOVALUE;
        goto LB; // [268] 278
    }
    else{
        _14388 = NOVALUE;
    }

    /** scanner.e:398				close(src_file)*/
    EClose(_36src_file_21572);
LB: 

    /** scanner.e:400			src_file = -1*/
    _36src_file_21572 = -1;
LA: 

    /** scanner.e:403		bp = 1*/
    _50bp_49242 = 1;

    /** scanner.e:411		AppendSourceLine()*/
    _62AppendSourceLine();

    /** scanner.e:412	end procedure*/
    DeRef(_14389);
    _14389 = NOVALUE;
    DeRef(_14387);
    _14387 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    return;
    ;
}


object _62getch()
{
    object _c_25946 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:417		c = ThisLine[bp]*/
    _2 = (object)SEQ_PTR(_50ThisLine_49238);
    _c_25946 = (object)*(((s1_ptr)_2)->base + _50bp_49242);
    if (!IS_ATOM_INT(_c_25946)){
        _c_25946 = (object)DBL_PTR(_c_25946)->dbl;
    }

    /** scanner.e:418		bp += 1*/
    _50bp_49242 = _50bp_49242 + 1;

    /** scanner.e:419		return c*/
    return _c_25946;
    ;
}


void _62ungetch()
{
    object _0, _1, _2;
    

    /** scanner.e:424		bp -= 1*/
    _50bp_49242 = _50bp_49242 - 1;

    /** scanner.e:425	end procedure*/
    return;
    ;
}


object _62get_file_path(object _s_25958)
{
    object _14398 = NOVALUE;
    object _14396 = NOVALUE;
    object _14395 = NOVALUE;
    object _14394 = NOVALUE;
    object _14393 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:429			for t=length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_25958)){
            _14393 = SEQ_PTR(_s_25958)->length;
    }
    else {
        _14393 = 1;
    }
    {
        object _t_25960;
        _t_25960 = _14393;
L1: 
        if (_t_25960 < 1){
            goto L2; // [8] 50
        }

        /** scanner.e:430					if find(s[t],SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_s_25958);
        _14394 = (object)*(((s1_ptr)_2)->base + _t_25960);
        _14395 = find_from(_14394, _46SLASH_CHARS_21614, 1);
        _14394 = NOVALUE;
        if (_14395 == 0)
        {
            _14395 = NOVALUE;
            goto L3; // [28] 43
        }
        else{
            _14395 = NOVALUE;
        }

        /** scanner.e:431							return s[1..t]*/
        rhs_slice_target = (object_ptr)&_14396;
        RHS_Slice(_s_25958, 1, _t_25960);
        DeRefDS(_s_25958);
        return _14396;
L3: 

        /** scanner.e:433			end for*/
        _t_25960 = _t_25960 + -1;
        goto L1; // [45] 15
L2: 
        ;
    }

    /** scanner.e:435			return "." & SLASH*/
    Append(&_14398, _14397, 47);
    DeRefDS(_s_25958);
    DeRef(_14396);
    _14396 = NOVALUE;
    return _14398;
    ;
}


object _62find_file(object _fname_25972)
{
    object _try_25973 = NOVALUE;
    object _full_path_25974 = NOVALUE;
    object _errbuff_25975 = NOVALUE;
    object _currdir_25976 = NOVALUE;
    object _conf_path_25977 = NOVALUE;
    object _scan_result_25978 = NOVALUE;
    object _inc_path_25979 = NOVALUE;
    object _mainpath_25999 = NOVALUE;
    object _31723 = NOVALUE;
    object _31722 = NOVALUE;
    object _14495 = NOVALUE;
    object _14493 = NOVALUE;
    object _14492 = NOVALUE;
    object _14491 = NOVALUE;
    object _14489 = NOVALUE;
    object _14487 = NOVALUE;
    object _14485 = NOVALUE;
    object _14484 = NOVALUE;
    object _14482 = NOVALUE;
    object _14481 = NOVALUE;
    object _14478 = NOVALUE;
    object _14475 = NOVALUE;
    object _14474 = NOVALUE;
    object _14473 = NOVALUE;
    object _14472 = NOVALUE;
    object _14471 = NOVALUE;
    object _14470 = NOVALUE;
    object _14469 = NOVALUE;
    object _14468 = NOVALUE;
    object _14465 = NOVALUE;
    object _14464 = NOVALUE;
    object _14460 = NOVALUE;
    object _14457 = NOVALUE;
    object _14456 = NOVALUE;
    object _14455 = NOVALUE;
    object _14454 = NOVALUE;
    object _14453 = NOVALUE;
    object _14452 = NOVALUE;
    object _14451 = NOVALUE;
    object _14450 = NOVALUE;
    object _14447 = NOVALUE;
    object _14443 = NOVALUE;
    object _14441 = NOVALUE;
    object _14440 = NOVALUE;
    object _14439 = NOVALUE;
    object _14438 = NOVALUE;
    object _14437 = NOVALUE;
    object _14434 = NOVALUE;
    object _14433 = NOVALUE;
    object _14432 = NOVALUE;
    object _14431 = NOVALUE;
    object _14430 = NOVALUE;
    object _14429 = NOVALUE;
    object _14427 = NOVALUE;
    object _14426 = NOVALUE;
    object _14425 = NOVALUE;
    object _14424 = NOVALUE;
    object _14423 = NOVALUE;
    object _14421 = NOVALUE;
    object _14420 = NOVALUE;
    object _14417 = NOVALUE;
    object _14414 = NOVALUE;
    object _14412 = NOVALUE;
    object _14409 = NOVALUE;
    object _14407 = NOVALUE;
    object _14406 = NOVALUE;
    object _14403 = NOVALUE;
    object _14402 = NOVALUE;
    object _14400 = NOVALUE;
    object _14399 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:449		if absolute_path(fname) then*/
    RefDS(_fname_25972);
    _14399 = _17absolute_path(_fname_25972);
    if (_14399 == 0) {
        DeRef(_14399);
        _14399 = NOVALUE;
        goto L1; // [9] 44
    }
    else {
        if (!IS_ATOM_INT(_14399) && DBL_PTR(_14399)->dbl == 0.0){
            DeRef(_14399);
            _14399 = NOVALUE;
            goto L1; // [9] 44
        }
        DeRef(_14399);
        _14399 = NOVALUE;
    }
    DeRef(_14399);
    _14399 = NOVALUE;

    /** scanner.e:451			if not file_exists(fname) then*/
    RefDS(_fname_25972);
    _14400 = _17file_exists(_fname_25972);
    if (IS_ATOM_INT(_14400)) {
        if (_14400 != 0){
            DeRef(_14400);
            _14400 = NOVALUE;
            goto L2; // [18] 37
        }
    }
    else {
        if (DBL_PTR(_14400)->dbl != 0.0){
            DeRef(_14400);
            _14400 = NOVALUE;
            goto L2; // [18] 37
        }
    }
    DeRef(_14400);
    _14400 = NOVALUE;

    /** scanner.e:452				CompileErr(CANT_OPEN_1, {new_include_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_36new_include_name_21573);
    ((intptr_t*)_2)[1] = _36new_include_name_21573;
    _14402 = MAKE_SEQ(_1);
    _50CompileErr(51, _14402, 0);
    _14402 = NOVALUE;
L2: 

    /** scanner.e:455			return fname*/
    DeRef(_full_path_25974);
    DeRef(_errbuff_25975);
    DeRef(_currdir_25976);
    DeRef(_conf_path_25977);
    DeRef(_scan_result_25978);
    DeRef(_inc_path_25979);
    DeRef(_mainpath_25999);
    return _fname_25972;
L1: 

    /** scanner.e:460		currdir = get_file_path( known_files[current_file_no] )*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _14403 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    Ref(_14403);
    _0 = _currdir_25976;
    _currdir_25976 = _62get_file_path(_14403);
    DeRef(_0);
    _14403 = NOVALUE;

    /** scanner.e:461		full_path = currdir & fname*/
    Concat((object_ptr)&_full_path_25974, _currdir_25976, _fname_25972);

    /** scanner.e:462		if file_exists(full_path) then*/
    RefDS(_full_path_25974);
    _14406 = _17file_exists(_full_path_25974);
    if (_14406 == 0) {
        DeRef(_14406);
        _14406 = NOVALUE;
        goto L3; // [72] 82
    }
    else {
        if (!IS_ATOM_INT(_14406) && DBL_PTR(_14406)->dbl == 0.0){
            DeRef(_14406);
            _14406 = NOVALUE;
            goto L3; // [72] 82
        }
        DeRef(_14406);
        _14406 = NOVALUE;
    }
    DeRef(_14406);
    _14406 = NOVALUE;

    /** scanner.e:463			return full_path*/
    DeRefDS(_fname_25972);
    DeRef(_errbuff_25975);
    DeRefDS(_currdir_25976);
    DeRef(_conf_path_25977);
    DeRef(_scan_result_25978);
    DeRef(_inc_path_25979);
    DeRef(_mainpath_25999);
    return _full_path_25974;
L3: 

    /** scanner.e:467		sequence mainpath = main_path[1..rfind(SLASH, main_path)]*/
    RefDS(_36main_path_21571);
    DeRef(_31722);
    _31722 = _36main_path_21571;
    if (IS_SEQUENCE(_31722)){
            _31723 = SEQ_PTR(_31722)->length;
    }
    else {
        _31723 = 1;
    }
    _31722 = NOVALUE;
    RefDS(_36main_path_21571);
    _14407 = _16rfind(47, _36main_path_21571, _31723);
    _31723 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mainpath_25999;
    RHS_Slice(_36main_path_21571, 1, _14407);

    /** scanner.e:468		if not equal(mainpath, currdir) then*/
    if (_mainpath_25999 == _currdir_25976)
    _14409 = 1;
    else if (IS_ATOM_INT(_mainpath_25999) && IS_ATOM_INT(_currdir_25976))
    _14409 = 0;
    else
    _14409 = (compare(_mainpath_25999, _currdir_25976) == 0);
    if (_14409 != 0)
    goto L4; // [113] 141
    _14409 = NOVALUE;

    /** scanner.e:469			full_path = mainpath & new_include_name*/
    Concat((object_ptr)&_full_path_25974, _mainpath_25999, _36new_include_name_21573);

    /** scanner.e:470			if file_exists(full_path) then*/
    RefDS(_full_path_25974);
    _14412 = _17file_exists(_full_path_25974);
    if (_14412 == 0) {
        DeRef(_14412);
        _14412 = NOVALUE;
        goto L5; // [130] 140
    }
    else {
        if (!IS_ATOM_INT(_14412) && DBL_PTR(_14412)->dbl == 0.0){
            DeRef(_14412);
            _14412 = NOVALUE;
            goto L5; // [130] 140
        }
        DeRef(_14412);
        _14412 = NOVALUE;
    }
    DeRef(_14412);
    _14412 = NOVALUE;

    /** scanner.e:471				return full_path*/
    DeRefDS(_fname_25972);
    DeRef(_errbuff_25975);
    DeRefDS(_currdir_25976);
    DeRef(_conf_path_25977);
    DeRef(_scan_result_25978);
    DeRef(_inc_path_25979);
    DeRefDS(_mainpath_25999);
    DeRef(_14407);
    _14407 = NOVALUE;
    _31722 = NOVALUE;
    return _full_path_25974;
L5: 
L4: 

    /** scanner.e:475		scan_result = ConfPath(new_include_name)*/
    RefDS(_36new_include_name_21573);
    _0 = _scan_result_25978;
    _scan_result_25978 = _48ConfPath(_36new_include_name_21573);
    DeRef(_0);

    /** scanner.e:477		if atom(scan_result) then*/
    _14414 = IS_ATOM(_scan_result_25978);
    if (_14414 == 0)
    {
        _14414 = NOVALUE;
        goto L6; // [154] 166
    }
    else{
        _14414 = NOVALUE;
    }

    /** scanner.e:478			scan_result = ScanPath(fname,"EUINC",0)*/
    RefDS(_fname_25972);
    RefDS(_14415);
    _0 = _scan_result_25978;
    _scan_result_25978 = _48ScanPath(_fname_25972, _14415, 0);
    DeRef(_0);
L6: 

    /** scanner.e:481		if atom(scan_result) then*/
    _14417 = IS_ATOM(_scan_result_25978);
    if (_14417 == 0)
    {
        _14417 = NOVALUE;
        goto L7; // [171] 183
    }
    else{
        _14417 = NOVALUE;
    }

    /** scanner.e:482			scan_result = ScanPath(fname, "EUDIR",1)*/
    RefDS(_fname_25972);
    RefDS(_14418);
    _0 = _scan_result_25978;
    _scan_result_25978 = _48ScanPath(_fname_25972, _14418, 1);
    DeRef(_0);
L7: 

    /** scanner.e:485		if atom(scan_result) then*/
    _14420 = IS_ATOM(_scan_result_25978);
    if (_14420 == 0)
    {
        _14420 = NOVALUE;
        goto L8; // [188] 225
    }
    else{
        _14420 = NOVALUE;
    }

    /** scanner.e:487			full_path = get_eudir() & SLASH & "include" & SLASH & fname*/
    _14421 = _37get_eudir();
    {
        object concat_list[5];

        concat_list[0] = _fname_25972;
        concat_list[1] = 47;
        concat_list[2] = _13181;
        concat_list[3] = 47;
        concat_list[4] = _14421;
        Concat_N((object_ptr)&_full_path_25974, concat_list, 5);
    }
    DeRef(_14421);
    _14421 = NOVALUE;

    /** scanner.e:488			if file_exists(full_path) then*/
    RefDS(_full_path_25974);
    _14423 = _17file_exists(_full_path_25974);
    if (_14423 == 0) {
        DeRef(_14423);
        _14423 = NOVALUE;
        goto L9; // [214] 224
    }
    else {
        if (!IS_ATOM_INT(_14423) && DBL_PTR(_14423)->dbl == 0.0){
            DeRef(_14423);
            _14423 = NOVALUE;
            goto L9; // [214] 224
        }
        DeRef(_14423);
        _14423 = NOVALUE;
    }
    DeRef(_14423);
    _14423 = NOVALUE;

    /** scanner.e:489				return full_path*/
    DeRefDS(_fname_25972);
    DeRef(_errbuff_25975);
    DeRef(_currdir_25976);
    DeRef(_conf_path_25977);
    DeRef(_scan_result_25978);
    DeRef(_inc_path_25979);
    DeRef(_mainpath_25999);
    DeRef(_14407);
    _14407 = NOVALUE;
    _31722 = NOVALUE;
    return _full_path_25974;
L9: 
L8: 

    /** scanner.e:493		if sequence(scan_result) then*/
    _14424 = IS_SEQUENCE(_scan_result_25978);
    if (_14424 == 0)
    {
        _14424 = NOVALUE;
        goto LA; // [230] 252
    }
    else{
        _14424 = NOVALUE;
    }

    /** scanner.e:495			close(scan_result[2])*/
    _2 = (object)SEQ_PTR(_scan_result_25978);
    _14425 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_14425))
    EClose(_14425);
    else
    EClose((object)DBL_PTR(_14425)->dbl);
    _14425 = NOVALUE;

    /** scanner.e:496			return scan_result[1]*/
    _2 = (object)SEQ_PTR(_scan_result_25978);
    _14426 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_14426);
    DeRefDS(_fname_25972);
    DeRef(_full_path_25974);
    DeRef(_errbuff_25975);
    DeRef(_currdir_25976);
    DeRef(_conf_path_25977);
    DeRef(_scan_result_25978);
    DeRef(_inc_path_25979);
    DeRef(_mainpath_25999);
    DeRef(_14407);
    _14407 = NOVALUE;
    _31722 = NOVALUE;
    return _14426;
LA: 

    /** scanner.e:500		errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_25975);
    _errbuff_25975 = _5;

    /** scanner.e:501		full_path = {}*/
    RefDS(_5);
    DeRef(_full_path_25974);
    _full_path_25974 = _5;

    /** scanner.e:502		if length(currdir) > 0 then*/
    if (IS_SEQUENCE(_currdir_25976)){
            _14427 = SEQ_PTR(_currdir_25976)->length;
    }
    else {
        _14427 = 1;
    }
    if (_14427 <= 0)
    goto LB; // [271] 323

    /** scanner.e:503			if find(currdir[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_currdir_25976)){
            _14429 = SEQ_PTR(_currdir_25976)->length;
    }
    else {
        _14429 = 1;
    }
    _2 = (object)SEQ_PTR(_currdir_25976);
    _14430 = (object)*(((s1_ptr)_2)->base + _14429);
    _14431 = find_from(_14430, _46SLASH_CHARS_21614, 1);
    _14430 = NOVALUE;
    if (_14431 == 0)
    {
        _14431 = NOVALUE;
        goto LC; // [291] 315
    }
    else{
        _14431 = NOVALUE;
    }

    /** scanner.e:504				full_path = append(full_path, currdir[1..$-1])*/
    if (IS_SEQUENCE(_currdir_25976)){
            _14432 = SEQ_PTR(_currdir_25976)->length;
    }
    else {
        _14432 = 1;
    }
    _14433 = _14432 - 1;
    _14432 = NOVALUE;
    rhs_slice_target = (object_ptr)&_14434;
    RHS_Slice(_currdir_25976, 1, _14433);
    RefDS(_14434);
    Append(&_full_path_25974, _full_path_25974, _14434);
    DeRefDS(_14434);
    _14434 = NOVALUE;
    goto LD; // [312] 322
LC: 

    /** scanner.e:506				full_path = append(full_path, currdir)*/
    RefDS(_currdir_25976);
    Append(&_full_path_25974, _full_path_25974, _currdir_25976);
LD: 
LB: 

    /** scanner.e:511		if find(main_path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_36main_path_21571)){
            _14437 = SEQ_PTR(_36main_path_21571)->length;
    }
    else {
        _14437 = 1;
    }
    _2 = (object)SEQ_PTR(_36main_path_21571);
    _14438 = (object)*(((s1_ptr)_2)->base + _14437);
    _14439 = find_from(_14438, _46SLASH_CHARS_21614, 1);
    _14438 = NOVALUE;
    if (_14439 == 0)
    {
        _14439 = NOVALUE;
        goto LE; // [341] 363
    }
    else{
        _14439 = NOVALUE;
    }

    /** scanner.e:512			errbuff = main_path[1..$-1]  -- looks better*/
    if (IS_SEQUENCE(_36main_path_21571)){
            _14440 = SEQ_PTR(_36main_path_21571)->length;
    }
    else {
        _14440 = 1;
    }
    _14441 = _14440 - 1;
    _14440 = NOVALUE;
    rhs_slice_target = (object_ptr)&_errbuff_25975;
    RHS_Slice(_36main_path_21571, 1, _14441);
    goto LF; // [360] 373
LE: 

    /** scanner.e:514			errbuff = main_path*/
    RefDS(_36main_path_21571);
    DeRef(_errbuff_25975);
    _errbuff_25975 = _36main_path_21571;
LF: 

    /** scanner.e:516		if not find(errbuff, full_path) then*/
    _14443 = find_from(_errbuff_25975, _full_path_25974, 1);
    if (_14443 != 0)
    goto L10; // [380] 390
    _14443 = NOVALUE;

    /** scanner.e:517			full_path = append(full_path, errbuff)*/
    RefDS(_errbuff_25975);
    Append(&_full_path_25974, _full_path_25974, _errbuff_25975);
L10: 

    /** scanner.e:520		conf_path = get_conf_dirs()*/
    _0 = _conf_path_25977;
    _conf_path_25977 = _48get_conf_dirs();
    DeRef(_0);

    /** scanner.e:521		if length(conf_path) > 0 then*/
    if (IS_SEQUENCE(_conf_path_25977)){
            _14447 = SEQ_PTR(_conf_path_25977)->length;
    }
    else {
        _14447 = 1;
    }
    if (_14447 <= 0)
    goto L11; // [402] 509

    /** scanner.e:522			conf_path = split(conf_path, PATHSEP)*/
    RefDS(_conf_path_25977);
    _0 = _conf_path_25977;
    _conf_path_25977 = _23split(_conf_path_25977, 58, 0, 0);
    DeRefDS(_0);

    /** scanner.e:523			for i = 1 to length(conf_path) do*/
    if (IS_SEQUENCE(_conf_path_25977)){
            _14450 = SEQ_PTR(_conf_path_25977)->length;
    }
    else {
        _14450 = 1;
    }
    {
        object _i_26080;
        _i_26080 = 1;
L12: 
        if (_i_26080 > _14450){
            goto L13; // [424] 508
        }

        /** scanner.e:524				if find(conf_path[i][$], SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_conf_path_25977);
        _14451 = (object)*(((s1_ptr)_2)->base + _i_26080);
        if (IS_SEQUENCE(_14451)){
                _14452 = SEQ_PTR(_14451)->length;
        }
        else {
            _14452 = 1;
        }
        _2 = (object)SEQ_PTR(_14451);
        _14453 = (object)*(((s1_ptr)_2)->base + _14452);
        _14451 = NOVALUE;
        _14454 = find_from(_14453, _46SLASH_CHARS_21614, 1);
        _14453 = NOVALUE;
        if (_14454 == 0)
        {
            _14454 = NOVALUE;
            goto L14; // [451] 475
        }
        else{
            _14454 = NOVALUE;
        }

        /** scanner.e:525					errbuff = conf_path[i][1..$-1]  -- looks better*/
        _2 = (object)SEQ_PTR(_conf_path_25977);
        _14455 = (object)*(((s1_ptr)_2)->base + _i_26080);
        if (IS_SEQUENCE(_14455)){
                _14456 = SEQ_PTR(_14455)->length;
        }
        else {
            _14456 = 1;
        }
        _14457 = _14456 - 1;
        _14456 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_25975;
        RHS_Slice(_14455, 1, _14457);
        _14455 = NOVALUE;
        goto L15; // [472] 484
L14: 

        /** scanner.e:527					errbuff = conf_path[i]*/
        DeRef(_errbuff_25975);
        _2 = (object)SEQ_PTR(_conf_path_25977);
        _errbuff_25975 = (object)*(((s1_ptr)_2)->base + _i_26080);
        Ref(_errbuff_25975);
L15: 

        /** scanner.e:529				if not find(errbuff, full_path) then*/
        _14460 = find_from(_errbuff_25975, _full_path_25974, 1);
        if (_14460 != 0)
        goto L16; // [491] 501
        _14460 = NOVALUE;

        /** scanner.e:530					full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_25975);
        Append(&_full_path_25974, _full_path_25974, _errbuff_25975);
L16: 

        /** scanner.e:532			end for*/
        _i_26080 = _i_26080 + 1;
        goto L12; // [503] 431
L13: 
        ;
    }
L11: 

    /** scanner.e:535		inc_path = getenv("EUINC")*/
    DeRef(_inc_path_25979);
    _inc_path_25979 = EGetEnv(_14415);

    /** scanner.e:536		if sequence(inc_path) then*/
    _14464 = IS_SEQUENCE(_inc_path_25979);
    if (_14464 == 0)
    {
        _14464 = NOVALUE;
        goto L17; // [519] 633
    }
    else{
        _14464 = NOVALUE;
    }

    /** scanner.e:537			if length(inc_path) > 0 then*/
    if (IS_SEQUENCE(_inc_path_25979)){
            _14465 = SEQ_PTR(_inc_path_25979)->length;
    }
    else {
        _14465 = 1;
    }
    if (_14465 <= 0)
    goto L18; // [527] 632

    /** scanner.e:538				inc_path = split(inc_path, PATHSEP)*/
    Ref(_inc_path_25979);
    _0 = _inc_path_25979;
    _inc_path_25979 = _23split(_inc_path_25979, 58, 0, 0);
    DeRefi(_0);

    /** scanner.e:539				for i = 1 to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_25979)){
            _14468 = SEQ_PTR(_inc_path_25979)->length;
    }
    else {
        _14468 = 1;
    }
    {
        object _i_26108;
        _i_26108 = 1;
L19: 
        if (_i_26108 > _14468){
            goto L1A; // [547] 631
        }

        /** scanner.e:540					if find(inc_path[i][$], SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_inc_path_25979);
        _14469 = (object)*(((s1_ptr)_2)->base + _i_26108);
        if (IS_SEQUENCE(_14469)){
                _14470 = SEQ_PTR(_14469)->length;
        }
        else {
            _14470 = 1;
        }
        _2 = (object)SEQ_PTR(_14469);
        _14471 = (object)*(((s1_ptr)_2)->base + _14470);
        _14469 = NOVALUE;
        _14472 = find_from(_14471, _46SLASH_CHARS_21614, 1);
        _14471 = NOVALUE;
        if (_14472 == 0)
        {
            _14472 = NOVALUE;
            goto L1B; // [574] 598
        }
        else{
            _14472 = NOVALUE;
        }

        /** scanner.e:541						errbuff = inc_path[i][1..$-1]  -- looks better*/
        _2 = (object)SEQ_PTR(_inc_path_25979);
        _14473 = (object)*(((s1_ptr)_2)->base + _i_26108);
        if (IS_SEQUENCE(_14473)){
                _14474 = SEQ_PTR(_14473)->length;
        }
        else {
            _14474 = 1;
        }
        _14475 = _14474 - 1;
        _14474 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_25975;
        RHS_Slice(_14473, 1, _14475);
        _14473 = NOVALUE;
        goto L1C; // [595] 607
L1B: 

        /** scanner.e:543						errbuff = inc_path[i]*/
        DeRef(_errbuff_25975);
        _2 = (object)SEQ_PTR(_inc_path_25979);
        _errbuff_25975 = (object)*(((s1_ptr)_2)->base + _i_26108);
        Ref(_errbuff_25975);
L1C: 

        /** scanner.e:545					if not find(errbuff, full_path) then*/
        _14478 = find_from(_errbuff_25975, _full_path_25974, 1);
        if (_14478 != 0)
        goto L1D; // [614] 624
        _14478 = NOVALUE;

        /** scanner.e:546						full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_25975);
        Append(&_full_path_25974, _full_path_25974, _errbuff_25975);
L1D: 

        /** scanner.e:548				end for*/
        _i_26108 = _i_26108 + 1;
        goto L19; // [626] 554
L1A: 
        ;
    }
L18: 
L17: 

    /** scanner.e:552		if length(get_eudir()) > 0 then*/
    _14481 = _37get_eudir();
    if (IS_SEQUENCE(_14481)){
            _14482 = SEQ_PTR(_14481)->length;
    }
    else {
        _14482 = 1;
    }
    DeRef(_14481);
    _14481 = NOVALUE;
    if (_14482 <= 0)
    goto L1E; // [641] 669

    /** scanner.e:553			if not find(get_eudir(), full_path) then*/
    _14484 = _37get_eudir();
    _14485 = find_from(_14484, _full_path_25974, 1);
    DeRef(_14484);
    _14484 = NOVALUE;
    if (_14485 != 0)
    goto L1F; // [655] 668
    _14485 = NOVALUE;

    /** scanner.e:554				full_path = append(full_path, get_eudir())*/
    _14487 = _37get_eudir();
    Ref(_14487);
    Append(&_full_path_25974, _full_path_25974, _14487);
    DeRef(_14487);
    _14487 = NOVALUE;
L1F: 
L1E: 

    /** scanner.e:558		errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_25975);
    _errbuff_25975 = _5;

    /** scanner.e:559		for i = 1 to length(full_path) do*/
    if (IS_SEQUENCE(_full_path_25974)){
            _14489 = SEQ_PTR(_full_path_25974)->length;
    }
    else {
        _14489 = 1;
    }
    {
        object _i_26140;
        _i_26140 = 1;
L20: 
        if (_i_26140 > _14489){
            goto L21; // [681] 713
        }

        /** scanner.e:560			errbuff &= sprintf("\t%s\n", {full_path[i]})*/
        _2 = (object)SEQ_PTR(_full_path_25974);
        _14491 = (object)*(((s1_ptr)_2)->base + _i_26140);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_14491);
        ((intptr_t*)_2)[1] = _14491;
        _14492 = MAKE_SEQ(_1);
        _14491 = NOVALUE;
        _14493 = EPrintf(-9999999, _14490, _14492);
        DeRefDS(_14492);
        _14492 = NOVALUE;
        Concat((object_ptr)&_errbuff_25975, _errbuff_25975, _14493);
        DeRefDS(_14493);
        _14493 = NOVALUE;

        /** scanner.e:561		end for*/
        _i_26140 = _i_26140 + 1;
        goto L20; // [708] 688
L21: 
        ;
    }

    /** scanner.e:563		CompileErr(CANT_FIND_1_IN_ANY_OF_2, {new_include_name, errbuff})*/
    RefDS(_errbuff_25975);
    RefDS(_36new_include_name_21573);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _36new_include_name_21573;
    ((intptr_t *)_2)[2] = _errbuff_25975;
    _14495 = MAKE_SEQ(_1);
    _50CompileErr(52, _14495, 0);
    _14495 = NOVALUE;
    ;
}


object _62path_open()
{
    object _fh_26153 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:569		new_include_name = find_file(new_include_name)*/
    RefDS(_36new_include_name_21573);
    _0 = _62find_file(_36new_include_name_21573);
    DeRefDS(_36new_include_name_21573);
    _36new_include_name_21573 = _0;

    /** scanner.e:570		new_include_name = maybe_preprocess(new_include_name)*/
    RefDS(_36new_include_name_21573);
    _0 = _64maybe_preprocess(_36new_include_name_21573);
    DeRefDS(_36new_include_name_21573);
    _36new_include_name_21573 = _0;

    /** scanner.e:572		fh = open_locked(new_include_name)*/
    RefDS(_36new_include_name_21573);
    _fh_26153 = _37open_locked(_36new_include_name_21573);
    if (!IS_ATOM_INT(_fh_26153)) {
        _1 = (object)(DBL_PTR(_fh_26153)->dbl);
        DeRefDS(_fh_26153);
        _fh_26153 = _1;
    }

    /** scanner.e:573		return fh*/
    return _fh_26153;
    ;
}


object _62NameSpace_declaration(object _sym_26177)
{
    object _h_26178 = NOVALUE;
    object _14517 = NOVALUE;
    object _14515 = NOVALUE;
    object _14513 = NOVALUE;
    object _14511 = NOVALUE;
    object _14510 = NOVALUE;
    object _14509 = NOVALUE;
    object _14507 = NOVALUE;
    object _14506 = NOVALUE;
    object _14505 = NOVALUE;
    object _14504 = NOVALUE;
    object _14503 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_26177)) {
        _1 = (object)(DBL_PTR(_sym_26177)->dbl);
        DeRefDS(_sym_26177);
        _sym_26177 = _1;
    }

    /** scanner.e:594		DefinedYet(sym)*/
    _54DefinedYet(_sym_26177);

    /** scanner.e:595		if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_PREDEF}) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _14503 = (object)*(((s1_ptr)_2)->base + _sym_26177);
    _2 = (object)SEQ_PTR(_14503);
    _14504 = (object)*(((s1_ptr)_2)->base + 4);
    _14503 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 6;
    ((intptr_t*)_2)[2] = 13;
    ((intptr_t*)_2)[3] = 11;
    ((intptr_t*)_2)[4] = 7;
    _14505 = MAKE_SEQ(_1);
    _14506 = find_from(_14504, _14505, 1);
    _14504 = NOVALUE;
    DeRefDS(_14505);
    _14505 = NOVALUE;
    if (_14506 == 0)
    {
        _14506 = NOVALUE;
        goto L1; // [42] 104
    }
    else{
        _14506 = NOVALUE;
    }

    /** scanner.e:597			h = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _14507 = (object)*(((s1_ptr)_2)->base + _sym_26177);
    _2 = (object)SEQ_PTR(_14507);
    _h_26178 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_26178)){
        _h_26178 = (object)DBL_PTR(_h_26178)->dbl;
    }
    _14507 = NOVALUE;

    /** scanner.e:599			sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _14509 = (object)*(((s1_ptr)_2)->base + _sym_26177);
    _2 = (object)SEQ_PTR(_14509);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _14510 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _14510 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _14509 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_46776);
    _14511 = (object)*(((s1_ptr)_2)->base + _h_26178);
    Ref(_14510);
    Ref(_14511);
    _sym_26177 = _54NewEntry(_14510, 0, 0, -100, _h_26178, _14511, 0);
    _14510 = NOVALUE;
    _14511 = NOVALUE;
    if (!IS_ATOM_INT(_sym_26177)) {
        _1 = (object)(DBL_PTR(_sym_26177)->dbl);
        DeRefDS(_sym_26177);
        _sym_26177 = _1;
    }

    /** scanner.e:600			buckets[h] = sym*/
    _2 = (object)SEQ_PTR(_54buckets_46776);
    _2 = (object)(((s1_ptr)_2)->base + _h_26178);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_26177;
    DeRef(_1);
L1: 

    /** scanner.e:602		SymTab[sym][S_SCOPE] = SC_LOCAL*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26177 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 5;
    DeRef(_1);
    _14513 = NOVALUE;

    /** scanner.e:603		SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26177 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _14515 = NOVALUE;

    /** scanner.e:604		SymTab[sym][S_TOKEN] = NAMESPACE -- [S_OBJ] will get the file number referred-to*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26177 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TOKEN_21089))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21089)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TOKEN_21089);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 523;
    DeRef(_1);
    _14517 = NOVALUE;

    /** scanner.e:605		if TRANSLATE then*/
    if (_36TRANSLATE_21049 == 0)
    {
        goto L2; // [159] 173
    }
    else{
    }

    /** scanner.e:606			num_routines += 1 -- order of ns declaration relative to routines*/
    _36num_routines_21456 = _36num_routines_21456 + 1;
L2: 

    /** scanner.e:609		return sym*/
    return _sym_26177;
    ;
}


void _62default_namespace()
{
    object _tok_26228 = NOVALUE;
    object _sym_26230 = NOVALUE;
    object _14541 = NOVALUE;
    object _14540 = NOVALUE;
    object _14538 = NOVALUE;
    object _14536 = NOVALUE;
    object _14533 = NOVALUE;
    object _14530 = NOVALUE;
    object _14528 = NOVALUE;
    object _14526 = NOVALUE;
    object _14525 = NOVALUE;
    object _14524 = NOVALUE;
    object _14523 = NOVALUE;
    object _14522 = NOVALUE;
    object _14521 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:618		tok = call_func( scanner_rid, {} )*/
    _0 = (object)_00[_62scanner_rid_26224].addr;
    _1 = (*(intptr_t (*)())_0)(
                         );
    DeRef(_tok_26228);
    _tok_26228 = _1;

    /** scanner.e:619		if tok[T_ID] = VARIABLE and equal( SymTab[tok[T_SYM]][S_NAME], "namespace" ) then*/
    _2 = (object)SEQ_PTR(_tok_26228);
    _14521 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_14521)) {
        _14522 = (_14521 == -100);
    }
    else {
        _14522 = binary_op(EQUALS, _14521, -100);
    }
    _14521 = NOVALUE;
    if (IS_ATOM_INT(_14522)) {
        if (_14522 == 0) {
            goto L1; // [23] 179
        }
    }
    else {
        if (DBL_PTR(_14522)->dbl == 0.0) {
            goto L1; // [23] 179
        }
    }
    _2 = (object)SEQ_PTR(_tok_26228);
    _14524 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_14524)){
        _14525 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14524)->dbl));
    }
    else{
        _14525 = (object)*(((s1_ptr)_2)->base + _14524);
    }
    _2 = (object)SEQ_PTR(_14525);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _14526 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _14526 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _14525 = NOVALUE;
    if (_14526 == _14527)
    _14528 = 1;
    else if (IS_ATOM_INT(_14526) && IS_ATOM_INT(_14527))
    _14528 = 0;
    else
    _14528 = (compare(_14526, _14527) == 0);
    _14526 = NOVALUE;
    if (_14528 == 0)
    {
        _14528 = NOVALUE;
        goto L1; // [50] 179
    }
    else{
        _14528 = NOVALUE;
    }

    /** scanner.e:621			tok = call_func( scanner_rid, {} )*/
    _0 = (object)_00[_62scanner_rid_26224].addr;
    _1 = (*(intptr_t (*)())_0)(
                         );
    DeRef(_tok_26228);
    _tok_26228 = _1;

    /** scanner.e:622			if tok[T_ID] != VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_26228);
    _14530 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _14530, -100)){
        _14530 = NOVALUE;
        goto L2; // [71] 85
    }
    _14530 = NOVALUE;

    /** scanner.e:623				CompileErr(MISSING_DEFAULT_NAMESPACE_QUALIFIER)*/
    RefDS(_21997);
    _50CompileErr(114, _21997, 0);
L2: 

    /** scanner.e:626			sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_26228);
    _sym_26230 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_26230)){
        _sym_26230 = (object)DBL_PTR(_sym_26230)->dbl;
    }

    /** scanner.e:628			SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26230 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FILE_NO_21080))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21080)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FILE_NO_21080);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21447;
    DeRef(_1);
    _14533 = NOVALUE;

    /** scanner.e:629			sym  = NameSpace_declaration( sym )*/
    _sym_26230 = _62NameSpace_declaration(_sym_26230);
    if (!IS_ATOM_INT(_sym_26230)) {
        _1 = (object)(DBL_PTR(_sym_26230)->dbl);
        DeRefDS(_sym_26230);
        _sym_26230 = _1;
    }

    /** scanner.e:630			SymTab[sym][S_OBJ] = current_file_no*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26230 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21447;
    DeRef(_1);
    _14536 = NOVALUE;

    /** scanner.e:631			SymTab[sym][S_SCOPE] = SC_PUBLIC*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26230 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 13;
    DeRef(_1);
    _14538 = NOVALUE;

    /** scanner.e:633			default_namespaces[current_file_no] = SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _14540 = (object)*(((s1_ptr)_2)->base + _sym_26230);
    _2 = (object)SEQ_PTR(_14540);
    if (!IS_ATOM_INT(_36S_NAME_21084)){
        _14541 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21084)->dbl));
    }
    else{
        _14541 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21084);
    }
    _14540 = NOVALUE;
    Ref(_14541);
    _2 = (object)SEQ_PTR(_62default_namespaces_25559);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21447);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14541;
    if( _1 != _14541 ){
        DeRef(_1);
    }
    _14541 = NOVALUE;
    goto L3; // [176] 187
L1: 

    /** scanner.e:637			bp = 1*/
    _50bp_49242 = 1;
L3: 

    /** scanner.e:640	end procedure*/
    DeRef(_tok_26228);
    DeRef(_14522);
    _14522 = NOVALUE;
    _14524 = NOVALUE;
    return;
    ;
}


void _62add_exports(object _from_file_26281, object _to_file_26282)
{
    object _exports_26283 = NOVALUE;
    object _direct_26284 = NOVALUE;
    object _14561 = NOVALUE;
    object _14560 = NOVALUE;
    object _14559 = NOVALUE;
    object _14558 = NOVALUE;
    object _14557 = NOVALUE;
    object _14555 = NOVALUE;
    object _14553 = NOVALUE;
    object _14552 = NOVALUE;
    object _14550 = NOVALUE;
    object _14549 = NOVALUE;
    object _14548 = NOVALUE;
    object _14546 = NOVALUE;
    object _14545 = NOVALUE;
    object _14544 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:645		direct = file_include[to_file]*/
    DeRef(_direct_26284);
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _direct_26284 = (object)*(((s1_ptr)_2)->base + _to_file_26282);
    Ref(_direct_26284);

    /** scanner.e:646		exports = file_public[from_file]*/
    DeRef(_exports_26283);
    _2 = (object)SEQ_PTR(_37file_public_15417);
    _exports_26283 = (object)*(((s1_ptr)_2)->base + _from_file_26281);
    Ref(_exports_26283);

    /** scanner.e:647		for i = 1 to length(exports) do*/
    if (IS_SEQUENCE(_exports_26283)){
            _14544 = SEQ_PTR(_exports_26283)->length;
    }
    else {
        _14544 = 1;
    }
    {
        object _i_26290;
        _i_26290 = 1;
L1: 
        if (_i_26290 > _14544){
            goto L2; // [30] 127
        }

        /** scanner.e:648			if not find( exports[i], direct ) then*/
        _2 = (object)SEQ_PTR(_exports_26283);
        _14545 = (object)*(((s1_ptr)_2)->base + _i_26290);
        _14546 = find_from(_14545, _direct_26284, 1);
        _14545 = NOVALUE;
        if (_14546 != 0)
        goto L3; // [48] 120
        _14546 = NOVALUE;

        /** scanner.e:649				if not find( -exports[i], direct ) then*/
        _2 = (object)SEQ_PTR(_exports_26283);
        _14548 = (object)*(((s1_ptr)_2)->base + _i_26290);
        if (IS_ATOM_INT(_14548)) {
            if ((uintptr_t)_14548 == (uintptr_t)HIGH_BITS){
                _14549 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _14549 = - _14548;
            }
        }
        else {
            _14549 = unary_op(UMINUS, _14548);
        }
        _14548 = NOVALUE;
        _14550 = find_from(_14549, _direct_26284, 1);
        DeRef(_14549);
        _14549 = NOVALUE;
        if (_14550 != 0)
        goto L4; // [65] 82
        _14550 = NOVALUE;

        /** scanner.e:650					direct &= -exports[i]*/
        _2 = (object)SEQ_PTR(_exports_26283);
        _14552 = (object)*(((s1_ptr)_2)->base + _i_26290);
        if (IS_ATOM_INT(_14552)) {
            if ((uintptr_t)_14552 == (uintptr_t)HIGH_BITS){
                _14553 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _14553 = - _14552;
            }
        }
        else {
            _14553 = unary_op(UMINUS, _14552);
        }
        _14552 = NOVALUE;
        if (IS_SEQUENCE(_direct_26284) && IS_ATOM(_14553)) {
            Ref(_14553);
            Append(&_direct_26284, _direct_26284, _14553);
        }
        else if (IS_ATOM(_direct_26284) && IS_SEQUENCE(_14553)) {
        }
        else {
            Concat((object_ptr)&_direct_26284, _direct_26284, _14553);
        }
        DeRef(_14553);
        _14553 = NOVALUE;
L4: 

        /** scanner.e:654				include_matrix[to_file][exports[i]] = or_bits( PUBLIC_INCLUDE, include_matrix[to_file][exports[i]] )*/
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15413 = MAKE_SEQ(_2);
        }
        _3 = (object)(_to_file_26282 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_exports_26283);
        _14557 = (object)*(((s1_ptr)_2)->base + _i_26290);
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _14558 = (object)*(((s1_ptr)_2)->base + _to_file_26282);
        _2 = (object)SEQ_PTR(_exports_26283);
        _14559 = (object)*(((s1_ptr)_2)->base + _i_26290);
        _2 = (object)SEQ_PTR(_14558);
        if (!IS_ATOM_INT(_14559)){
            _14560 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14559)->dbl));
        }
        else{
            _14560 = (object)*(((s1_ptr)_2)->base + _14559);
        }
        _14558 = NOVALUE;
        if (IS_ATOM_INT(_14560)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 | (uintptr_t)_14560;
                 _14561 = MAKE_UINT(tu);
            }
        }
        else {
            _14561 = binary_op(OR_BITS, 4, _14560);
        }
        _14560 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14557))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14557)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _14557);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14561;
        if( _1 != _14561 ){
            DeRef(_1);
        }
        _14561 = NOVALUE;
        _14555 = NOVALUE;
L3: 

        /** scanner.e:656		end for*/
        _i_26290 = _i_26290 + 1;
        goto L1; // [122] 37
L2: 
        ;
    }

    /** scanner.e:657		file_include[to_file] = direct*/
    RefDS(_direct_26284);
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _2 = (object)(((s1_ptr)_2)->base + _to_file_26282);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _direct_26284;
    DeRef(_1);

    /** scanner.e:658	end procedure*/
    DeRef(_exports_26283);
    DeRefDS(_direct_26284);
    _14559 = NOVALUE;
    _14557 = NOVALUE;
    return;
    ;
}


void _62patch_exports(object _for_file_26317)
{
    object _export_len_26318 = NOVALUE;
    object _14572 = NOVALUE;
    object _14571 = NOVALUE;
    object _14569 = NOVALUE;
    object _14568 = NOVALUE;
    object _14567 = NOVALUE;
    object _14566 = NOVALUE;
    object _14564 = NOVALUE;
    object _14563 = NOVALUE;
    object _14562 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:663		for i = 1 to length(file_include) do*/
    if (IS_SEQUENCE(_37file_include_15411)){
            _14562 = SEQ_PTR(_37file_include_15411)->length;
    }
    else {
        _14562 = 1;
    }
    {
        object _i_26320;
        _i_26320 = 1;
L1: 
        if (_i_26320 > _14562){
            goto L2; // [10] 99
        }

        /** scanner.e:664			if find( for_file, file_include[i] ) or find( -for_file, file_include[i] ) then*/
        _2 = (object)SEQ_PTR(_37file_include_15411);
        _14563 = (object)*(((s1_ptr)_2)->base + _i_26320);
        _14564 = find_from(_for_file_26317, _14563, 1);
        _14563 = NOVALUE;
        if (_14564 != 0) {
            goto L3; // [30] 53
        }
        if ((uintptr_t)_for_file_26317 == (uintptr_t)HIGH_BITS){
            _14566 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _14566 = - _for_file_26317;
        }
        _2 = (object)SEQ_PTR(_37file_include_15411);
        _14567 = (object)*(((s1_ptr)_2)->base + _i_26320);
        _14568 = find_from(_14566, _14567, 1);
        DeRef(_14566);
        _14566 = NOVALUE;
        _14567 = NOVALUE;
        if (_14568 == 0)
        {
            _14568 = NOVALUE;
            goto L4; // [49] 92
        }
        else{
            _14568 = NOVALUE;
        }
L3: 

        /** scanner.e:665				export_len = length( file_include[i] )*/
        _2 = (object)SEQ_PTR(_37file_include_15411);
        _14569 = (object)*(((s1_ptr)_2)->base + _i_26320);
        if (IS_SEQUENCE(_14569)){
                _export_len_26318 = SEQ_PTR(_14569)->length;
        }
        else {
            _export_len_26318 = 1;
        }
        _14569 = NOVALUE;

        /** scanner.e:666				add_exports( for_file, i )*/
        _62add_exports(_for_file_26317, _i_26320);

        /** scanner.e:667				if length( file_include[i] ) != export_len then*/
        _2 = (object)SEQ_PTR(_37file_include_15411);
        _14571 = (object)*(((s1_ptr)_2)->base + _i_26320);
        if (IS_SEQUENCE(_14571)){
                _14572 = SEQ_PTR(_14571)->length;
        }
        else {
            _14572 = 1;
        }
        _14571 = NOVALUE;
        if (_14572 == _export_len_26318)
        goto L5; // [81] 91

        /** scanner.e:669					patch_exports( i )*/
        _62patch_exports(_i_26320);
L5: 
L4: 

        /** scanner.e:672		end for*/
        _i_26320 = _i_26320 + 1;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** scanner.e:673	end procedure*/
    _14571 = NOVALUE;
    _14569 = NOVALUE;
    return;
    ;
}


void _62update_include_matrix(object _included_file_26342, object _from_file_26343)
{
    object _add_public_26353 = NOVALUE;
    object _px_26371 = NOVALUE;
    object _indirect_26430 = NOVALUE;
    object _mask_26433 = NOVALUE;
    object _ix_26444 = NOVALUE;
    object _indirect_file_26448 = NOVALUE;
    object _14648 = NOVALUE;
    object _14647 = NOVALUE;
    object _14645 = NOVALUE;
    object _14644 = NOVALUE;
    object _14643 = NOVALUE;
    object _14642 = NOVALUE;
    object _14641 = NOVALUE;
    object _14640 = NOVALUE;
    object _14639 = NOVALUE;
    object _14638 = NOVALUE;
    object _14637 = NOVALUE;
    object _14634 = NOVALUE;
    object _14632 = NOVALUE;
    object _14631 = NOVALUE;
    object _14630 = NOVALUE;
    object _14628 = NOVALUE;
    object _14626 = NOVALUE;
    object _14625 = NOVALUE;
    object _14623 = NOVALUE;
    object _14622 = NOVALUE;
    object _14621 = NOVALUE;
    object _14620 = NOVALUE;
    object _14619 = NOVALUE;
    object _14617 = NOVALUE;
    object _14616 = NOVALUE;
    object _14615 = NOVALUE;
    object _14614 = NOVALUE;
    object _14613 = NOVALUE;
    object _14612 = NOVALUE;
    object _14610 = NOVALUE;
    object _14609 = NOVALUE;
    object _14608 = NOVALUE;
    object _14606 = NOVALUE;
    object _14605 = NOVALUE;
    object _14604 = NOVALUE;
    object _14603 = NOVALUE;
    object _14602 = NOVALUE;
    object _14601 = NOVALUE;
    object _14600 = NOVALUE;
    object _14599 = NOVALUE;
    object _14598 = NOVALUE;
    object _14597 = NOVALUE;
    object _14596 = NOVALUE;
    object _14594 = NOVALUE;
    object _14593 = NOVALUE;
    object _14591 = NOVALUE;
    object _14589 = NOVALUE;
    object _14587 = NOVALUE;
    object _14586 = NOVALUE;
    object _14585 = NOVALUE;
    object _14584 = NOVALUE;
    object _14582 = NOVALUE;
    object _14581 = NOVALUE;
    object _14580 = NOVALUE;
    object _14578 = NOVALUE;
    object _14577 = NOVALUE;
    object _14576 = NOVALUE;
    object _14574 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:684		include_matrix[from_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[from_file][included_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15413 = MAKE_SEQ(_2);
    }
    _3 = (object)(_from_file_26343 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _14576 = (object)*(((s1_ptr)_2)->base + _from_file_26343);
    _2 = (object)SEQ_PTR(_14576);
    _14577 = (object)*(((s1_ptr)_2)->base + _included_file_26342);
    _14576 = NOVALUE;
    if (IS_ATOM_INT(_14577)) {
        {uintptr_t tu;
             tu = (uintptr_t)2 | (uintptr_t)_14577;
             _14578 = MAKE_UINT(tu);
        }
    }
    else {
        _14578 = binary_op(OR_BITS, 2, _14577);
    }
    _14577 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26342);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14578;
    if( _1 != _14578 ){
        DeRef(_1);
    }
    _14578 = NOVALUE;
    _14574 = NOVALUE;

    /** scanner.e:686		if public_include then*/
    if (_62public_include_25556 == 0)
    {
        goto L1; // [38] 339
    }
    else{
    }

    /** scanner.e:689			sequence add_public = file_include_by[from_file]*/
    DeRef(_add_public_26353);
    _2 = (object)SEQ_PTR(_37file_include_by_15419);
    _add_public_26353 = (object)*(((s1_ptr)_2)->base + _from_file_26343);
    Ref(_add_public_26353);

    /** scanner.e:690			for i = 1 to length( add_public ) do*/
    if (IS_SEQUENCE(_add_public_26353)){
            _14580 = SEQ_PTR(_add_public_26353)->length;
    }
    else {
        _14580 = 1;
    }
    {
        object _i_26357;
        _i_26357 = 1;
L2: 
        if (_i_26357 > _14580){
            goto L3; // [56] 107
        }

        /** scanner.e:692				include_matrix[add_public[i]][included_file] =*/
        _2 = (object)SEQ_PTR(_add_public_26353);
        _14581 = (object)*(((s1_ptr)_2)->base + _i_26357);
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15413 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14581))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14581)->dbl));
        else
        _3 = (object)(_14581 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_add_public_26353);
        _14584 = (object)*(((s1_ptr)_2)->base + _i_26357);
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        if (!IS_ATOM_INT(_14584)){
            _14585 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14584)->dbl));
        }
        else{
            _14585 = (object)*(((s1_ptr)_2)->base + _14584);
        }
        _2 = (object)SEQ_PTR(_14585);
        _14586 = (object)*(((s1_ptr)_2)->base + _included_file_26342);
        _14585 = NOVALUE;
        if (IS_ATOM_INT(_14586)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 | (uintptr_t)_14586;
                 _14587 = MAKE_UINT(tu);
            }
        }
        else {
            _14587 = binary_op(OR_BITS, 4, _14586);
        }
        _14586 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _included_file_26342);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14587;
        if( _1 != _14587 ){
            DeRef(_1);
        }
        _14587 = NOVALUE;
        _14582 = NOVALUE;

        /** scanner.e:695			end for*/
        _i_26357 = _i_26357 + 1;
        goto L2; // [102] 63
L3: 
        ;
    }

    /** scanner.e:698			add_public = file_public_by[from_file]*/
    DeRef(_add_public_26353);
    _2 = (object)SEQ_PTR(_37file_public_by_15421);
    _add_public_26353 = (object)*(((s1_ptr)_2)->base + _from_file_26343);
    Ref(_add_public_26353);

    /** scanner.e:699			integer px = length( add_public ) + 1*/
    if (IS_SEQUENCE(_add_public_26353)){
            _14589 = SEQ_PTR(_add_public_26353)->length;
    }
    else {
        _14589 = 1;
    }
    _px_26371 = _14589 + 1;
    _14589 = NOVALUE;

    /** scanner.e:700			while px <= length( add_public ) do*/
L4: 
    if (IS_SEQUENCE(_add_public_26353)){
            _14591 = SEQ_PTR(_add_public_26353)->length;
    }
    else {
        _14591 = 1;
    }
    if (_px_26371 > _14591)
    goto L5; // [134] 338

    /** scanner.e:701				include_matrix[add_public[px]][included_file] =*/
    _2 = (object)SEQ_PTR(_add_public_26353);
    _14593 = (object)*(((s1_ptr)_2)->base + _px_26371);
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15413 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14593))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14593)->dbl));
    else
    _3 = (object)(_14593 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_add_public_26353);
    _14596 = (object)*(((s1_ptr)_2)->base + _px_26371);
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    if (!IS_ATOM_INT(_14596)){
        _14597 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14596)->dbl));
    }
    else{
        _14597 = (object)*(((s1_ptr)_2)->base + _14596);
    }
    _2 = (object)SEQ_PTR(_14597);
    _14598 = (object)*(((s1_ptr)_2)->base + _included_file_26342);
    _14597 = NOVALUE;
    if (IS_ATOM_INT(_14598)) {
        {uintptr_t tu;
             tu = (uintptr_t)4 | (uintptr_t)_14598;
             _14599 = MAKE_UINT(tu);
        }
    }
    else {
        _14599 = binary_op(OR_BITS, 4, _14598);
    }
    _14598 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26342);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14599;
    if( _1 != _14599 ){
        DeRef(_1);
    }
    _14599 = NOVALUE;
    _14594 = NOVALUE;

    /** scanner.e:704				for i = 1 to length( file_public_by[add_public[px]] ) do*/
    _2 = (object)SEQ_PTR(_add_public_26353);
    _14600 = (object)*(((s1_ptr)_2)->base + _px_26371);
    _2 = (object)SEQ_PTR(_37file_public_by_15421);
    if (!IS_ATOM_INT(_14600)){
        _14601 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14600)->dbl));
    }
    else{
        _14601 = (object)*(((s1_ptr)_2)->base + _14600);
    }
    if (IS_SEQUENCE(_14601)){
            _14602 = SEQ_PTR(_14601)->length;
    }
    else {
        _14602 = 1;
    }
    _14601 = NOVALUE;
    {
        object _i_26388;
        _i_26388 = 1;
L6: 
        if (_i_26388 > _14602){
            goto L7; // [190] 249
        }

        /** scanner.e:705					if not find( file_public[add_public[px]][i], add_public ) then*/
        _2 = (object)SEQ_PTR(_add_public_26353);
        _14603 = (object)*(((s1_ptr)_2)->base + _px_26371);
        _2 = (object)SEQ_PTR(_37file_public_15417);
        if (!IS_ATOM_INT(_14603)){
            _14604 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14603)->dbl));
        }
        else{
            _14604 = (object)*(((s1_ptr)_2)->base + _14603);
        }
        _2 = (object)SEQ_PTR(_14604);
        _14605 = (object)*(((s1_ptr)_2)->base + _i_26388);
        _14604 = NOVALUE;
        _14606 = find_from(_14605, _add_public_26353, 1);
        _14605 = NOVALUE;
        if (_14606 != 0)
        goto L8; // [218] 242
        _14606 = NOVALUE;

        /** scanner.e:706						add_public &= file_public[add_public[px]][i]*/
        _2 = (object)SEQ_PTR(_add_public_26353);
        _14608 = (object)*(((s1_ptr)_2)->base + _px_26371);
        _2 = (object)SEQ_PTR(_37file_public_15417);
        if (!IS_ATOM_INT(_14608)){
            _14609 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14608)->dbl));
        }
        else{
            _14609 = (object)*(((s1_ptr)_2)->base + _14608);
        }
        _2 = (object)SEQ_PTR(_14609);
        _14610 = (object)*(((s1_ptr)_2)->base + _i_26388);
        _14609 = NOVALUE;
        if (IS_SEQUENCE(_add_public_26353) && IS_ATOM(_14610)) {
            Ref(_14610);
            Append(&_add_public_26353, _add_public_26353, _14610);
        }
        else if (IS_ATOM(_add_public_26353) && IS_SEQUENCE(_14610)) {
        }
        else {
            Concat((object_ptr)&_add_public_26353, _add_public_26353, _14610);
        }
        _14610 = NOVALUE;
L8: 

        /** scanner.e:708				end for*/
        _i_26388 = _i_26388 + 1;
        goto L6; // [244] 197
L7: 
        ;
    }

    /** scanner.e:710				for i = 1 to length( file_include_by[add_public[px]] ) do*/
    _2 = (object)SEQ_PTR(_add_public_26353);
    _14612 = (object)*(((s1_ptr)_2)->base + _px_26371);
    _2 = (object)SEQ_PTR(_37file_include_by_15419);
    if (!IS_ATOM_INT(_14612)){
        _14613 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14612)->dbl));
    }
    else{
        _14613 = (object)*(((s1_ptr)_2)->base + _14612);
    }
    if (IS_SEQUENCE(_14613)){
            _14614 = SEQ_PTR(_14613)->length;
    }
    else {
        _14614 = 1;
    }
    _14613 = NOVALUE;
    {
        object _i_26406;
        _i_26406 = 1;
L9: 
        if (_i_26406 > _14614){
            goto LA; // [264] 327
        }

        /** scanner.e:711					include_matrix[file_include_by[add_public[px]]][included_file] =*/
        _2 = (object)SEQ_PTR(_add_public_26353);
        _14615 = (object)*(((s1_ptr)_2)->base + _px_26371);
        _2 = (object)SEQ_PTR(_37file_include_by_15419);
        if (!IS_ATOM_INT(_14615)){
            _14616 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14615)->dbl));
        }
        else{
            _14616 = (object)*(((s1_ptr)_2)->base + _14615);
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15413 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14616))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14616)->dbl));
        else
        _3 = (object)(_14616 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_add_public_26353);
        _14619 = (object)*(((s1_ptr)_2)->base + _px_26371);
        _2 = (object)SEQ_PTR(_37file_include_by_15419);
        if (!IS_ATOM_INT(_14619)){
            _14620 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14619)->dbl));
        }
        else{
            _14620 = (object)*(((s1_ptr)_2)->base + _14619);
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        if (!IS_ATOM_INT(_14620)){
            _14621 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14620)->dbl));
        }
        else{
            _14621 = (object)*(((s1_ptr)_2)->base + _14620);
        }
        _2 = (object)SEQ_PTR(_14621);
        _14622 = (object)*(((s1_ptr)_2)->base + _included_file_26342);
        _14621 = NOVALUE;
        if (IS_ATOM_INT(_14622)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 | (uintptr_t)_14622;
                 _14623 = MAKE_UINT(tu);
            }
        }
        else {
            _14623 = binary_op(OR_BITS, 4, _14622);
        }
        _14622 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _included_file_26342);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14623;
        if( _1 != _14623 ){
            DeRef(_1);
        }
        _14623 = NOVALUE;
        _14617 = NOVALUE;

        /** scanner.e:713				end for*/
        _i_26406 = _i_26406 + 1;
        goto L9; // [322] 271
LA: 
        ;
    }

    /** scanner.e:715				px += 1*/
    _px_26371 = _px_26371 + 1;

    /** scanner.e:716			end while*/
    goto L4; // [335] 131
L5: 
L1: 
    DeRef(_add_public_26353);
    _add_public_26353 = NOVALUE;

    /** scanner.e:721		if indirect_include[from_file][included_file] then*/
    _2 = (object)SEQ_PTR(_37indirect_include_15415);
    _14625 = (object)*(((s1_ptr)_2)->base + _from_file_26343);
    _2 = (object)SEQ_PTR(_14625);
    _14626 = (object)*(((s1_ptr)_2)->base + _included_file_26342);
    _14625 = NOVALUE;
    if (_14626 == 0) {
        _14626 = NOVALUE;
        goto LB; // [353] 545
    }
    else {
        if (!IS_ATOM_INT(_14626) && DBL_PTR(_14626)->dbl == 0.0){
            _14626 = NOVALUE;
            goto LB; // [353] 545
        }
        _14626 = NOVALUE;
    }
    _14626 = NOVALUE;

    /** scanner.e:723			sequence indirect = file_include_by[from_file]*/
    DeRef(_indirect_26430);
    _2 = (object)SEQ_PTR(_37file_include_by_15419);
    _indirect_26430 = (object)*(((s1_ptr)_2)->base + _from_file_26343);
    Ref(_indirect_26430);

    /** scanner.e:725			sequence mask = include_matrix[included_file] != 0*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _14628 = (object)*(((s1_ptr)_2)->base + _included_file_26342);
    DeRef(_mask_26433);
    if (IS_ATOM_INT(_14628)) {
        _mask_26433 = (_14628 != 0);
    }
    else {
        _mask_26433 = binary_op(NOTEQ, _14628, 0);
    }
    _14628 = NOVALUE;

    /** scanner.e:726			include_matrix[from_file] = or_bits( include_matrix[from_file], mask )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _14630 = (object)*(((s1_ptr)_2)->base + _from_file_26343);
    _14631 = binary_op(OR_BITS, _14630, _mask_26433);
    _14630 = NOVALUE;
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _2 = (object)(((s1_ptr)_2)->base + _from_file_26343);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14631;
    if( _1 != _14631 ){
        DeRef(_1);
    }
    _14631 = NOVALUE;

    /** scanner.e:727			mask = include_matrix[from_file] != 0*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _14632 = (object)*(((s1_ptr)_2)->base + _from_file_26343);
    DeRefDS(_mask_26433);
    if (IS_ATOM_INT(_14632)) {
        _mask_26433 = (_14632 != 0);
    }
    else {
        _mask_26433 = binary_op(NOTEQ, _14632, 0);
    }
    _14632 = NOVALUE;

    /** scanner.e:728			integer ix = 1*/
    _ix_26444 = 1;

    /** scanner.e:729			while ix <= length(indirect) do*/
LC: 
    if (IS_SEQUENCE(_indirect_26430)){
            _14634 = SEQ_PTR(_indirect_26430)->length;
    }
    else {
        _14634 = 1;
    }
    if (_ix_26444 > _14634)
    goto LD; // [425] 544

    /** scanner.e:730				integer indirect_file = indirect[ix]*/
    _2 = (object)SEQ_PTR(_indirect_26430);
    _indirect_file_26448 = (object)*(((s1_ptr)_2)->base + _ix_26444);
    if (!IS_ATOM_INT(_indirect_file_26448))
    _indirect_file_26448 = (object)DBL_PTR(_indirect_file_26448)->dbl;

    /** scanner.e:731				if indirect_include[indirect_file][included_file] then*/
    _2 = (object)SEQ_PTR(_37indirect_include_15415);
    _14637 = (object)*(((s1_ptr)_2)->base + _indirect_file_26448);
    _2 = (object)SEQ_PTR(_14637);
    _14638 = (object)*(((s1_ptr)_2)->base + _included_file_26342);
    _14637 = NOVALUE;
    if (_14638 == 0) {
        _14638 = NOVALUE;
        goto LE; // [447] 531
    }
    else {
        if (!IS_ATOM_INT(_14638) && DBL_PTR(_14638)->dbl == 0.0){
            _14638 = NOVALUE;
            goto LE; // [447] 531
        }
        _14638 = NOVALUE;
    }
    _14638 = NOVALUE;

    /** scanner.e:732					include_matrix[indirect_file] =*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _14639 = (object)*(((s1_ptr)_2)->base + _indirect_file_26448);
    _14640 = binary_op(OR_BITS, _mask_26433, _14639);
    _14639 = NOVALUE;
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _2 = (object)(((s1_ptr)_2)->base + _indirect_file_26448);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14640;
    if( _1 != _14640 ){
        DeRef(_1);
    }
    _14640 = NOVALUE;

    /** scanner.e:734					for i = 1 to length( file_include_by[indirect_file] ) do*/
    _2 = (object)SEQ_PTR(_37file_include_by_15419);
    _14641 = (object)*(((s1_ptr)_2)->base + _indirect_file_26448);
    if (IS_SEQUENCE(_14641)){
            _14642 = SEQ_PTR(_14641)->length;
    }
    else {
        _14642 = 1;
    }
    _14641 = NOVALUE;
    {
        object _i_26459;
        _i_26459 = 1;
LF: 
        if (_i_26459 > _14642){
            goto L10; // [479] 530
        }

        /** scanner.e:736						if not find( file_include_by[indirect_file][i], indirect ) then*/
        _2 = (object)SEQ_PTR(_37file_include_by_15419);
        _14643 = (object)*(((s1_ptr)_2)->base + _indirect_file_26448);
        _2 = (object)SEQ_PTR(_14643);
        _14644 = (object)*(((s1_ptr)_2)->base + _i_26459);
        _14643 = NOVALUE;
        _14645 = find_from(_14644, _indirect_26430, 1);
        _14644 = NOVALUE;
        if (_14645 != 0)
        goto L11; // [503] 523
        _14645 = NOVALUE;

        /** scanner.e:737							indirect &= file_include_by[indirect_file][i]*/
        _2 = (object)SEQ_PTR(_37file_include_by_15419);
        _14647 = (object)*(((s1_ptr)_2)->base + _indirect_file_26448);
        _2 = (object)SEQ_PTR(_14647);
        _14648 = (object)*(((s1_ptr)_2)->base + _i_26459);
        _14647 = NOVALUE;
        if (IS_SEQUENCE(_indirect_26430) && IS_ATOM(_14648)) {
            Ref(_14648);
            Append(&_indirect_26430, _indirect_26430, _14648);
        }
        else if (IS_ATOM(_indirect_26430) && IS_SEQUENCE(_14648)) {
        }
        else {
            Concat((object_ptr)&_indirect_26430, _indirect_26430, _14648);
        }
        _14648 = NOVALUE;
L11: 

        /** scanner.e:740					end for*/
        _i_26459 = _i_26459 + 1;
        goto LF; // [525] 486
L10: 
        ;
    }
LE: 

    /** scanner.e:742				ix += 1*/
    _ix_26444 = _ix_26444 + 1;

    /** scanner.e:743			end while*/
    goto LC; // [541] 422
LD: 
LB: 
    DeRef(_indirect_26430);
    _indirect_26430 = NOVALUE;
    DeRef(_mask_26433);
    _mask_26433 = NOVALUE;

    /** scanner.e:746		public_include = FALSE*/
    _62public_include_25556 = _13FALSE_450;

    /** scanner.e:747	end procedure*/
    _14601 = NOVALUE;
    _14584 = NOVALUE;
    _14603 = NOVALUE;
    _14613 = NOVALUE;
    _14596 = NOVALUE;
    _14615 = NOVALUE;
    _14612 = NOVALUE;
    _14616 = NOVALUE;
    _14600 = NOVALUE;
    _14620 = NOVALUE;
    _14593 = NOVALUE;
    _14608 = NOVALUE;
    _14619 = NOVALUE;
    _14581 = NOVALUE;
    _14641 = NOVALUE;
    return;
    ;
}


void _62add_include_by(object _by_file_26477, object _included_file_26478, object _is_public_26479)
{
    object _14695 = NOVALUE;
    object _14694 = NOVALUE;
    object _14693 = NOVALUE;
    object _14691 = NOVALUE;
    object _14690 = NOVALUE;
    object _14689 = NOVALUE;
    object _14688 = NOVALUE;
    object _14686 = NOVALUE;
    object _14685 = NOVALUE;
    object _14684 = NOVALUE;
    object _14683 = NOVALUE;
    object _14682 = NOVALUE;
    object _14681 = NOVALUE;
    object _14680 = NOVALUE;
    object _14679 = NOVALUE;
    object _14677 = NOVALUE;
    object _14676 = NOVALUE;
    object _14675 = NOVALUE;
    object _14674 = NOVALUE;
    object _14672 = NOVALUE;
    object _14671 = NOVALUE;
    object _14670 = NOVALUE;
    object _14669 = NOVALUE;
    object _14667 = NOVALUE;
    object _14666 = NOVALUE;
    object _14665 = NOVALUE;
    object _14664 = NOVALUE;
    object _14662 = NOVALUE;
    object _14661 = NOVALUE;
    object _14660 = NOVALUE;
    object _14659 = NOVALUE;
    object _14658 = NOVALUE;
    object _14656 = NOVALUE;
    object _14655 = NOVALUE;
    object _14654 = NOVALUE;
    object _14653 = NOVALUE;
    object _14651 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:750		include_matrix[by_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15413 = MAKE_SEQ(_2);
    }
    _3 = (object)(_by_file_26477 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _14653 = (object)*(((s1_ptr)_2)->base + _by_file_26477);
    _2 = (object)SEQ_PTR(_14653);
    _14654 = (object)*(((s1_ptr)_2)->base + _included_file_26478);
    _14653 = NOVALUE;
    if (IS_ATOM_INT(_14654)) {
        {uintptr_t tu;
             tu = (uintptr_t)2 | (uintptr_t)_14654;
             _14655 = MAKE_UINT(tu);
        }
    }
    else {
        _14655 = binary_op(OR_BITS, 2, _14654);
    }
    _14654 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26478);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14655;
    if( _1 != _14655 ){
        DeRef(_1);
    }
    _14655 = NOVALUE;
    _14651 = NOVALUE;

    /** scanner.e:751		if is_public then*/
    if (_is_public_26479 == 0)
    {
        goto L1; // [38] 71
    }
    else{
    }

    /** scanner.e:752			include_matrix[by_file][included_file] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15413 = MAKE_SEQ(_2);
    }
    _3 = (object)(_by_file_26477 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _14658 = (object)*(((s1_ptr)_2)->base + _by_file_26477);
    _2 = (object)SEQ_PTR(_14658);
    _14659 = (object)*(((s1_ptr)_2)->base + _included_file_26478);
    _14658 = NOVALUE;
    if (IS_ATOM_INT(_14659)) {
        {uintptr_t tu;
             tu = (uintptr_t)4 | (uintptr_t)_14659;
             _14660 = MAKE_UINT(tu);
        }
    }
    else {
        _14660 = binary_op(OR_BITS, 4, _14659);
    }
    _14659 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26478);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14660;
    if( _1 != _14660 ){
        DeRef(_1);
    }
    _14660 = NOVALUE;
    _14656 = NOVALUE;
L1: 

    /** scanner.e:754		if not find( by_file, file_include_by[included_file] ) then*/
    _2 = (object)SEQ_PTR(_37file_include_by_15419);
    _14661 = (object)*(((s1_ptr)_2)->base + _included_file_26478);
    _14662 = find_from(_by_file_26477, _14661, 1);
    _14661 = NOVALUE;
    if (_14662 != 0)
    goto L2; // [84] 104
    _14662 = NOVALUE;

    /** scanner.e:755			file_include_by[included_file] &= by_file*/
    _2 = (object)SEQ_PTR(_37file_include_by_15419);
    _14664 = (object)*(((s1_ptr)_2)->base + _included_file_26478);
    if (IS_SEQUENCE(_14664) && IS_ATOM(_by_file_26477)) {
        Append(&_14665, _14664, _by_file_26477);
    }
    else if (IS_ATOM(_14664) && IS_SEQUENCE(_by_file_26477)) {
    }
    else {
        Concat((object_ptr)&_14665, _14664, _by_file_26477);
        _14664 = NOVALUE;
    }
    _14664 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_by_15419);
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26478);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14665;
    if( _1 != _14665 ){
        DeRef(_1);
    }
    _14665 = NOVALUE;
L2: 

    /** scanner.e:758		if not find( included_file, file_include[by_file] ) then*/
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _14666 = (object)*(((s1_ptr)_2)->base + _by_file_26477);
    _14667 = find_from(_included_file_26478, _14666, 1);
    _14666 = NOVALUE;
    if (_14667 != 0)
    goto L3; // [117] 137
    _14667 = NOVALUE;

    /** scanner.e:759			file_include[by_file] &= included_file*/
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _14669 = (object)*(((s1_ptr)_2)->base + _by_file_26477);
    if (IS_SEQUENCE(_14669) && IS_ATOM(_included_file_26478)) {
        Append(&_14670, _14669, _included_file_26478);
    }
    else if (IS_ATOM(_14669) && IS_SEQUENCE(_included_file_26478)) {
    }
    else {
        Concat((object_ptr)&_14670, _14669, _included_file_26478);
        _14669 = NOVALUE;
    }
    _14669 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _2 = (object)(((s1_ptr)_2)->base + _by_file_26477);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14670;
    if( _1 != _14670 ){
        DeRef(_1);
    }
    _14670 = NOVALUE;
L3: 

    /** scanner.e:762		if is_public then*/
    if (_is_public_26479 == 0)
    {
        goto L4; // [139] 209
    }
    else{
    }

    /** scanner.e:763			if not find( by_file, file_public_by[included_file] ) then*/
    _2 = (object)SEQ_PTR(_37file_public_by_15421);
    _14671 = (object)*(((s1_ptr)_2)->base + _included_file_26478);
    _14672 = find_from(_by_file_26477, _14671, 1);
    _14671 = NOVALUE;
    if (_14672 != 0)
    goto L5; // [155] 175
    _14672 = NOVALUE;

    /** scanner.e:764				file_public_by[included_file] &= by_file*/
    _2 = (object)SEQ_PTR(_37file_public_by_15421);
    _14674 = (object)*(((s1_ptr)_2)->base + _included_file_26478);
    if (IS_SEQUENCE(_14674) && IS_ATOM(_by_file_26477)) {
        Append(&_14675, _14674, _by_file_26477);
    }
    else if (IS_ATOM(_14674) && IS_SEQUENCE(_by_file_26477)) {
    }
    else {
        Concat((object_ptr)&_14675, _14674, _by_file_26477);
        _14674 = NOVALUE;
    }
    _14674 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_public_by_15421);
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26478);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14675;
    if( _1 != _14675 ){
        DeRef(_1);
    }
    _14675 = NOVALUE;
L5: 

    /** scanner.e:767			if not find( included_file, file_public[by_file] ) then*/
    _2 = (object)SEQ_PTR(_37file_public_15417);
    _14676 = (object)*(((s1_ptr)_2)->base + _by_file_26477);
    _14677 = find_from(_included_file_26478, _14676, 1);
    _14676 = NOVALUE;
    if (_14677 != 0)
    goto L6; // [188] 208
    _14677 = NOVALUE;

    /** scanner.e:768				file_public[by_file] &= included_file*/
    _2 = (object)SEQ_PTR(_37file_public_15417);
    _14679 = (object)*(((s1_ptr)_2)->base + _by_file_26477);
    if (IS_SEQUENCE(_14679) && IS_ATOM(_included_file_26478)) {
        Append(&_14680, _14679, _included_file_26478);
    }
    else if (IS_ATOM(_14679) && IS_SEQUENCE(_included_file_26478)) {
    }
    else {
        Concat((object_ptr)&_14680, _14679, _included_file_26478);
        _14679 = NOVALUE;
    }
    _14679 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_public_15417);
    _2 = (object)(((s1_ptr)_2)->base + _by_file_26477);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14680;
    if( _1 != _14680 ){
        DeRef(_1);
    }
    _14680 = NOVALUE;
L6: 
L4: 

    /** scanner.e:772		for propagate = 1 to length( include_matrix[included_file] ) do*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _14681 = (object)*(((s1_ptr)_2)->base + _included_file_26478);
    if (IS_SEQUENCE(_14681)){
            _14682 = SEQ_PTR(_14681)->length;
    }
    else {
        _14682 = 1;
    }
    _14681 = NOVALUE;
    {
        object _propagate_26531;
        _propagate_26531 = 1;
L7: 
        if (_propagate_26531 > _14682){
            goto L8; // [220] 320
        }

        /** scanner.e:773			if and_bits( PUBLIC_INCLUDE, include_matrix[included_file][propagate] ) then*/
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _14683 = (object)*(((s1_ptr)_2)->base + _included_file_26478);
        _2 = (object)SEQ_PTR(_14683);
        _14684 = (object)*(((s1_ptr)_2)->base + _propagate_26531);
        _14683 = NOVALUE;
        if (IS_ATOM_INT(_14684)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 & (uintptr_t)_14684;
                 _14685 = MAKE_UINT(tu);
            }
        }
        else {
            _14685 = binary_op(AND_BITS, 4, _14684);
        }
        _14684 = NOVALUE;
        if (_14685 == 0) {
            DeRef(_14685);
            _14685 = NOVALUE;
            goto L9; // [245] 313
        }
        else {
            if (!IS_ATOM_INT(_14685) && DBL_PTR(_14685)->dbl == 0.0){
                DeRef(_14685);
                _14685 = NOVALUE;
                goto L9; // [245] 313
            }
            DeRef(_14685);
            _14685 = NOVALUE;
        }
        DeRef(_14685);
        _14685 = NOVALUE;

        /** scanner.e:774				include_matrix[by_file][propagate] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15413 = MAKE_SEQ(_2);
        }
        _3 = (object)(_by_file_26477 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _14688 = (object)*(((s1_ptr)_2)->base + _by_file_26477);
        _2 = (object)SEQ_PTR(_14688);
        _14689 = (object)*(((s1_ptr)_2)->base + _propagate_26531);
        _14688 = NOVALUE;
        if (IS_ATOM_INT(_14689)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2 | (uintptr_t)_14689;
                 _14690 = MAKE_UINT(tu);
            }
        }
        else {
            _14690 = binary_op(OR_BITS, 2, _14689);
        }
        _14689 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _propagate_26531);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14690;
        if( _1 != _14690 ){
            DeRef(_1);
        }
        _14690 = NOVALUE;
        _14686 = NOVALUE;

        /** scanner.e:775				if is_public then*/
        if (_is_public_26479 == 0)
        {
            goto LA; // [279] 312
        }
        else{
        }

        /** scanner.e:776					include_matrix[by_file][propagate] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15413 = MAKE_SEQ(_2);
        }
        _3 = (object)(_by_file_26477 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _14693 = (object)*(((s1_ptr)_2)->base + _by_file_26477);
        _2 = (object)SEQ_PTR(_14693);
        _14694 = (object)*(((s1_ptr)_2)->base + _propagate_26531);
        _14693 = NOVALUE;
        if (IS_ATOM_INT(_14694)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 | (uintptr_t)_14694;
                 _14695 = MAKE_UINT(tu);
            }
        }
        else {
            _14695 = binary_op(OR_BITS, 4, _14694);
        }
        _14694 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _propagate_26531);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14695;
        if( _1 != _14695 ){
            DeRef(_1);
        }
        _14695 = NOVALUE;
        _14691 = NOVALUE;
LA: 
L9: 

        /** scanner.e:779		end for*/
        _propagate_26531 = _propagate_26531 + 1;
        goto L7; // [315] 227
L8: 
        ;
    }

    /** scanner.e:780	end procedure*/
    _14681 = NOVALUE;
    return;
    ;
}


void _62IncludePush()
{
    object _new_file_handle_26560 = NOVALUE;
    object _old_file_no_26561 = NOVALUE;
    object _new_hash_26562 = NOVALUE;
    object _idx_26563 = NOVALUE;
    object _14782 = NOVALUE;
    object _14779 = NOVALUE;
    object _14777 = NOVALUE;
    object _14776 = NOVALUE;
    object _14775 = NOVALUE;
    object _14773 = NOVALUE;
    object _14772 = NOVALUE;
    object _14766 = NOVALUE;
    object _14765 = NOVALUE;
    object _14764 = NOVALUE;
    object _14763 = NOVALUE;
    object _14762 = NOVALUE;
    object _14761 = NOVALUE;
    object _14760 = NOVALUE;
    object _14757 = NOVALUE;
    object _14755 = NOVALUE;
    object _14753 = NOVALUE;
    object _14752 = NOVALUE;
    object _14751 = NOVALUE;
    object _14749 = NOVALUE;
    object _14748 = NOVALUE;
    object _14746 = NOVALUE;
    object _14745 = NOVALUE;
    object _14743 = NOVALUE;
    object _14742 = NOVALUE;
    object _14741 = NOVALUE;
    object _14740 = NOVALUE;
    object _14739 = NOVALUE;
    object _14738 = NOVALUE;
    object _14737 = NOVALUE;
    object _14733 = NOVALUE;
    object _14731 = NOVALUE;
    object _14730 = NOVALUE;
    object _14729 = NOVALUE;
    object _14728 = NOVALUE;
    object _14727 = NOVALUE;
    object _14726 = NOVALUE;
    object _14725 = NOVALUE;
    object _14724 = NOVALUE;
    object _14723 = NOVALUE;
    object _14721 = NOVALUE;
    object _14720 = NOVALUE;
    object _14719 = NOVALUE;
    object _14717 = NOVALUE;
    object _14716 = NOVALUE;
    object _14715 = NOVALUE;
    object _14714 = NOVALUE;
    object _14712 = NOVALUE;
    object _14711 = NOVALUE;
    object _14710 = NOVALUE;
    object _14709 = NOVALUE;
    object _14708 = NOVALUE;
    object _14706 = NOVALUE;
    object _14705 = NOVALUE;
    object _14704 = NOVALUE;
    object _14703 = NOVALUE;
    object _14701 = NOVALUE;
    object _14697 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:788		start_include = FALSE*/
    _62start_include_25553 = _13FALSE_450;

    /** scanner.e:790		new_file_handle = path_open() -- sets new_include_name to full path*/
    _new_file_handle_26560 = _62path_open();
    if (!IS_ATOM_INT(_new_file_handle_26560)) {
        _1 = (object)(DBL_PTR(_new_file_handle_26560)->dbl);
        DeRefDS(_new_file_handle_26560);
        _new_file_handle_26560 = _1;
    }

    /** scanner.e:792		new_hash = hash(canonical_path(new_include_name,,CORRECT), stdhash:HSIEH32)*/
    RefDS(_36new_include_name_21573);
    _14697 = _17canonical_path(_36new_include_name_21573, 0, 2);
    DeRef(_new_hash_26562);
    _new_hash_26562 = calc_hash(_14697, -5);
    DeRef(_14697);
    _14697 = NOVALUE;

    /** scanner.e:794		idx = find(new_hash, known_files_hash)*/
    _idx_26563 = find_from(_new_hash_26562, _37known_files_hash_15408, 1);

    /** scanner.e:795		if idx then*/
    if (_idx_26563 == 0)
    {
        goto L1; // [42] 335
    }
    else{
    }

    /** scanner.e:797			if new_include_space != 0 then*/
    if (_62new_include_space_25551 == 0)
    goto L2; // [49] 71

    /** scanner.e:798				SymTab[new_include_space][S_OBJ] = idx -- but note any namespace*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_62new_include_space_25551 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _idx_26563;
    DeRef(_1);
    _14701 = NOVALUE;
L2: 

    /** scanner.e:801			close(new_file_handle)*/
    EClose(_new_file_handle_26560);

    /** scanner.e:803			if find( -idx, file_include[current_file_no] ) then*/
    if ((uintptr_t)_idx_26563 == (uintptr_t)HIGH_BITS){
        _14703 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _14703 = - _idx_26563;
    }
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _14704 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    _14705 = find_from(_14703, _14704, 1);
    DeRef(_14703);
    _14703 = NOVALUE;
    _14704 = NOVALUE;
    if (_14705 == 0)
    {
        _14705 = NOVALUE;
        goto L3; // [93] 130
    }
    else{
        _14705 = NOVALUE;
    }

    /** scanner.e:805				file_include[current_file_no][ find( -idx, file_include[current_file_no] ) ] = idx*/
    _2 = (object)SEQ_PTR(_37file_include_15411);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37file_include_15411 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36current_file_no_21447 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_idx_26563 == (uintptr_t)HIGH_BITS){
        _14708 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _14708 = - _idx_26563;
    }
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _14709 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    _14710 = find_from(_14708, _14709, 1);
    DeRef(_14708);
    _14708 = NOVALUE;
    _14709 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14710);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _idx_26563;
    DeRef(_1);
    _14706 = NOVALUE;
    goto L4; // [127] 228
L3: 

    /** scanner.e:809			elsif not find( idx, file_include[current_file_no] ) then*/
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _14711 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    _14712 = find_from(_idx_26563, _14711, 1);
    _14711 = NOVALUE;
    if (_14712 != 0)
    goto L5; // [145] 227
    _14712 = NOVALUE;

    /** scanner.e:811				file_include[current_file_no] &= idx*/
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _14714 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    if (IS_SEQUENCE(_14714) && IS_ATOM(_idx_26563)) {
        Append(&_14715, _14714, _idx_26563);
    }
    else if (IS_ATOM(_14714) && IS_SEQUENCE(_idx_26563)) {
    }
    else {
        Concat((object_ptr)&_14715, _14714, _idx_26563);
        _14714 = NOVALUE;
    }
    _14714 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21447);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14715;
    if( _1 != _14715 ){
        DeRef(_1);
    }
    _14715 = NOVALUE;

    /** scanner.e:814				add_exports( idx, current_file_no )*/
    _62add_exports(_idx_26563, _36current_file_no_21447);

    /** scanner.e:816				if public_include then*/
    if (_62public_include_25556 == 0)
    {
        goto L6; // [178] 226
    }
    else{
    }

    /** scanner.e:818					if not find( idx, file_public[current_file_no] ) then*/
    _2 = (object)SEQ_PTR(_37file_public_15417);
    _14716 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    _14717 = find_from(_idx_26563, _14716, 1);
    _14716 = NOVALUE;
    if (_14717 != 0)
    goto L7; // [196] 225
    _14717 = NOVALUE;

    /** scanner.e:819						file_public[current_file_no] &= idx*/
    _2 = (object)SEQ_PTR(_37file_public_15417);
    _14719 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    if (IS_SEQUENCE(_14719) && IS_ATOM(_idx_26563)) {
        Append(&_14720, _14719, _idx_26563);
    }
    else if (IS_ATOM(_14719) && IS_SEQUENCE(_idx_26563)) {
    }
    else {
        Concat((object_ptr)&_14720, _14719, _idx_26563);
        _14719 = NOVALUE;
    }
    _14719 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_public_15417);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21447);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14720;
    if( _1 != _14720 ){
        DeRef(_1);
    }
    _14720 = NOVALUE;

    /** scanner.e:820						patch_exports( current_file_no )*/
    _62patch_exports(_36current_file_no_21447);
L7: 
L6: 
L5: 
L4: 

    /** scanner.e:825			indirect_include[current_file_no][idx] = OpIndirectInclude*/
    _2 = (object)SEQ_PTR(_37indirect_include_15415);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37indirect_include_15415 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36current_file_no_21447 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _idx_26563);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36OpIndirectInclude_21526;
    DeRef(_1);
    _14721 = NOVALUE;

    /** scanner.e:826			add_include_by( current_file_no, idx, public_include )*/
    _62add_include_by(_36current_file_no_21447, _idx_26563, _62public_include_25556);

    /** scanner.e:827			update_include_matrix( idx, current_file_no )*/
    _62update_include_matrix(_idx_26563, _36current_file_no_21447);

    /** scanner.e:828			public_include = FALSE*/
    _62public_include_25556 = _13FALSE_450;

    /** scanner.e:829			read_line() -- we can't return without reading a line first*/
    _62read_line();

    /** scanner.e:830			if not find( idx, file_include_depend[current_file_no] ) and not finished_files[idx] then*/
    _2 = (object)SEQ_PTR(_37file_include_depend_15410);
    _14723 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    _14724 = find_from(_idx_26563, _14723, 1);
    _14723 = NOVALUE;
    _14725 = (_14724 == 0);
    _14724 = NOVALUE;
    if (_14725 == 0) {
        goto L8; // [293] 329
    }
    _2 = (object)SEQ_PTR(_37finished_files_15409);
    _14727 = (object)*(((s1_ptr)_2)->base + _idx_26563);
    _14728 = (_14727 == 0);
    _14727 = NOVALUE;
    if (_14728 == 0)
    {
        DeRef(_14728);
        _14728 = NOVALUE;
        goto L8; // [307] 329
    }
    else{
        DeRef(_14728);
        _14728 = NOVALUE;
    }

    /** scanner.e:831				file_include_depend[current_file_no] &= idx*/
    _2 = (object)SEQ_PTR(_37file_include_depend_15410);
    _14729 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    if (IS_SEQUENCE(_14729) && IS_ATOM(_idx_26563)) {
        Append(&_14730, _14729, _idx_26563);
    }
    else if (IS_ATOM(_14729) && IS_SEQUENCE(_idx_26563)) {
    }
    else {
        Concat((object_ptr)&_14730, _14729, _idx_26563);
        _14729 = NOVALUE;
    }
    _14729 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_depend_15410);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37file_include_depend_15410 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21447);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14730;
    if( _1 != _14730 ){
        DeRef(_1);
    }
    _14730 = NOVALUE;
L8: 

    /** scanner.e:833			return -- ignore it*/
    DeRef(_new_hash_26562);
    DeRef(_14725);
    _14725 = NOVALUE;
    return;
L1: 

    /** scanner.e:836		if length(IncludeStk) >= INCLUDE_LIMIT then*/
    if (IS_SEQUENCE(_62IncludeStk_25562)){
            _14731 = SEQ_PTR(_62IncludeStk_25562)->length;
    }
    else {
        _14731 = 1;
    }
    if (_14731 < 30)
    goto L9; // [342] 356

    /** scanner.e:837			CompileErr(INCLUDES_ARE_NESTED_TOO_DEEPLY)*/
    RefDS(_21997);
    _50CompileErr(104, _21997, 0);
L9: 

    /** scanner.e:840		IncludeStk = append(IncludeStk,*/
    _1 = NewS1(22);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _36current_file_no_21447;
    ((intptr_t*)_2)[2] = _36line_number_21448;
    ((intptr_t*)_2)[3] = _36src_file_21572;
    ((intptr_t*)_2)[4] = _36file_start_sym_21453;
    ((intptr_t*)_2)[5] = _36OpWarning_21518;
    ((intptr_t*)_2)[6] = _36OpTrace_21520;
    ((intptr_t*)_2)[7] = _36OpTypeCheck_21521;
    ((intptr_t*)_2)[8] = _36OpProfileTime_21523;
    ((intptr_t*)_2)[9] = _36OpProfileStatement_21522;
    RefDS(_36OpDefines_21524);
    ((intptr_t*)_2)[10] = _36OpDefines_21524;
    ((intptr_t*)_2)[11] = _36prev_OpWarning_21519;
    ((intptr_t*)_2)[12] = _36OpInline_21525;
    ((intptr_t*)_2)[13] = _36OpIndirectInclude_21526;
    ((intptr_t*)_2)[14] = _36putback_fwd_line_number_21450;
    Ref(_50putback_ForwardLine_49240);
    ((intptr_t*)_2)[15] = _50putback_ForwardLine_49240;
    ((intptr_t*)_2)[16] = _50putback_forward_bp_49244;
    ((intptr_t*)_2)[17] = _36last_fwd_line_number_21451;
    Ref(_50last_ForwardLine_49241);
    ((intptr_t*)_2)[18] = _50last_ForwardLine_49241;
    ((intptr_t*)_2)[19] = _50last_forward_bp_49245;
    Ref(_50ThisLine_49238);
    ((intptr_t*)_2)[20] = _50ThisLine_49238;
    ((intptr_t*)_2)[21] = _36fwd_line_number_21449;
    ((intptr_t*)_2)[22] = _50forward_bp_49243;
    _14733 = MAKE_SEQ(_1);
    RefDS(_14733);
    Append(&_62IncludeStk_25562, _62IncludeStk_25562, _14733);
    DeRefDS(_14733);
    _14733 = NOVALUE;

    /** scanner.e:864		file_include = append( file_include, {} )*/
    RefDS(_5);
    Append(&_37file_include_15411, _37file_include_15411, _5);

    /** scanner.e:865		file_include_by = append( file_include_by, {} )*/
    RefDS(_5);
    Append(&_37file_include_by_15419, _37file_include_by_15419, _5);

    /** scanner.e:866		for i = 1 to length( include_matrix) do*/
    if (IS_SEQUENCE(_37include_matrix_15413)){
            _14737 = SEQ_PTR(_37include_matrix_15413)->length;
    }
    else {
        _14737 = 1;
    }
    {
        object _i_26676;
        _i_26676 = 1;
LA: 
        if (_i_26676 > _14737){
            goto LB; // [460] 506
        }

        /** scanner.e:867			include_matrix[i]   &= 0*/
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _14738 = (object)*(((s1_ptr)_2)->base + _i_26676);
        if (IS_SEQUENCE(_14738) && IS_ATOM(0)) {
            Append(&_14739, _14738, 0);
        }
        else if (IS_ATOM(_14738) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_14739, _14738, 0);
            _14738 = NOVALUE;
        }
        _14738 = NOVALUE;
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _2 = (object)(((s1_ptr)_2)->base + _i_26676);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14739;
        if( _1 != _14739 ){
            DeRef(_1);
        }
        _14739 = NOVALUE;

        /** scanner.e:868			indirect_include[i] &= 0*/
        _2 = (object)SEQ_PTR(_37indirect_include_15415);
        _14740 = (object)*(((s1_ptr)_2)->base + _i_26676);
        if (IS_SEQUENCE(_14740) && IS_ATOM(0)) {
            Append(&_14741, _14740, 0);
        }
        else if (IS_ATOM(_14740) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_14741, _14740, 0);
            _14740 = NOVALUE;
        }
        _14740 = NOVALUE;
        _2 = (object)SEQ_PTR(_37indirect_include_15415);
        _2 = (object)(((s1_ptr)_2)->base + _i_26676);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14741;
        if( _1 != _14741 ){
            DeRef(_1);
        }
        _14741 = NOVALUE;

        /** scanner.e:869		end for*/
        _i_26676 = _i_26676 + 1;
        goto LA; // [501] 467
LB: 
        ;
    }

    /** scanner.e:870		include_matrix = append( include_matrix, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_37file_include_15411)){
            _14742 = SEQ_PTR(_37file_include_15411)->length;
    }
    else {
        _14742 = 1;
    }
    _14743 = Repeat(0, _14742);
    _14742 = NOVALUE;
    RefDS(_14743);
    Append(&_37include_matrix_15413, _37include_matrix_15413, _14743);
    DeRefDS(_14743);
    _14743 = NOVALUE;

    /** scanner.e:871		include_matrix[$][$] = DIRECT_INCLUDE*/
    if (IS_SEQUENCE(_37include_matrix_15413)){
            _14745 = SEQ_PTR(_37include_matrix_15413)->length;
    }
    else {
        _14745 = 1;
    }
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15413 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14745 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14748 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14748 = 1;
    }
    _14746 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14748);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _14746 = NOVALUE;

    /** scanner.e:872		include_matrix[current_file_no][$] = DIRECT_INCLUDE*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15413 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36current_file_no_21447 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14751 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14751 = 1;
    }
    _14749 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14751);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _14749 = NOVALUE;

    /** scanner.e:874		indirect_include = append( indirect_include, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_37file_include_15411)){
            _14752 = SEQ_PTR(_37file_include_15411)->length;
    }
    else {
        _14752 = 1;
    }
    _14753 = Repeat(0, _14752);
    _14752 = NOVALUE;
    RefDS(_14753);
    Append(&_37indirect_include_15415, _37indirect_include_15415, _14753);
    DeRefDS(_14753);
    _14753 = NOVALUE;

    /** scanner.e:875		indirect_include[current_file_no][$] = OpIndirectInclude*/
    _2 = (object)SEQ_PTR(_37indirect_include_15415);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37indirect_include_15415 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36current_file_no_21447 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14757 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14757 = 1;
    }
    _14755 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14757);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36OpIndirectInclude_21526;
    DeRef(_1);
    _14755 = NOVALUE;

    /** scanner.e:876		OpIndirectInclude = 1*/
    _36OpIndirectInclude_21526 = 1;

    /** scanner.e:878		file_public  = append( file_public, {} )*/
    RefDS(_5);
    Append(&_37file_public_15417, _37file_public_15417, _5);

    /** scanner.e:879		file_public_by = append( file_public_by, {} )*/
    RefDS(_5);
    Append(&_37file_public_by_15421, _37file_public_by_15421, _5);

    /** scanner.e:880		file_include[current_file_no] &= length( file_include )*/
    if (IS_SEQUENCE(_37file_include_15411)){
            _14760 = SEQ_PTR(_37file_include_15411)->length;
    }
    else {
        _14760 = 1;
    }
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _14761 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    if (IS_SEQUENCE(_14761) && IS_ATOM(_14760)) {
        Append(&_14762, _14761, _14760);
    }
    else if (IS_ATOM(_14761) && IS_SEQUENCE(_14760)) {
    }
    else {
        Concat((object_ptr)&_14762, _14761, _14760);
        _14761 = NOVALUE;
    }
    _14761 = NOVALUE;
    _14760 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21447);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14762;
    if( _1 != _14762 ){
        DeRef(_1);
    }
    _14762 = NOVALUE;

    /** scanner.e:881		add_include_by( current_file_no, length(file_include), public_include )*/
    if (IS_SEQUENCE(_37file_include_15411)){
            _14763 = SEQ_PTR(_37file_include_15411)->length;
    }
    else {
        _14763 = 1;
    }
    _62add_include_by(_36current_file_no_21447, _14763, _62public_include_25556);
    _14763 = NOVALUE;

    /** scanner.e:882		if public_include then*/
    if (_62public_include_25556 == 0)
    {
        goto LC; // [675] 709
    }
    else{
    }

    /** scanner.e:883			file_public[current_file_no] &= length( file_public )*/
    if (IS_SEQUENCE(_37file_public_15417)){
            _14764 = SEQ_PTR(_37file_public_15417)->length;
    }
    else {
        _14764 = 1;
    }
    _2 = (object)SEQ_PTR(_37file_public_15417);
    _14765 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    if (IS_SEQUENCE(_14765) && IS_ATOM(_14764)) {
        Append(&_14766, _14765, _14764);
    }
    else if (IS_ATOM(_14765) && IS_SEQUENCE(_14764)) {
    }
    else {
        Concat((object_ptr)&_14766, _14765, _14764);
        _14765 = NOVALUE;
    }
    _14765 = NOVALUE;
    _14764 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_public_15417);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21447);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14766;
    if( _1 != _14766 ){
        DeRef(_1);
    }
    _14766 = NOVALUE;

    /** scanner.e:884			patch_exports( current_file_no )*/
    _62patch_exports(_36current_file_no_21447);
LC: 

    /** scanner.e:887	ifdef STDDEBUG then*/

    /** scanner.e:893		src_file = new_file_handle*/
    _36src_file_21572 = _new_file_handle_26560;

    /** scanner.e:894		file_start_sym = last_sym*/
    _36file_start_sym_21453 = _54last_sym_46789;

    /** scanner.e:895		if current_file_no >= MAX_FILE then*/
    if (_36current_file_no_21447 < 256)
    goto LD; // [731] 745

    /** scanner.e:896			CompileErr(PROGRAM_INCLUDES_TOO_MANY_FILES)*/
    RefDS(_21997);
    _50CompileErr(126, _21997, 0);
LD: 

    /** scanner.e:898		known_files = append(known_files, new_include_name)*/
    RefDS(_36new_include_name_21573);
    Append(&_37known_files_15407, _37known_files_15407, _36new_include_name_21573);

    /** scanner.e:899		known_files_hash &= new_hash*/
    Ref(_new_hash_26562);
    Append(&_37known_files_hash_15408, _37known_files_hash_15408, _new_hash_26562);

    /** scanner.e:900		finished_files &= 0*/
    Append(&_37finished_files_15409, _37finished_files_15409, 0);

    /** scanner.e:901		file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _14772 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _14772 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _14772;
    _14773 = MAKE_SEQ(_1);
    _14772 = NOVALUE;
    RefDS(_14773);
    Append(&_37file_include_depend_15410, _37file_include_depend_15410, _14773);
    DeRefDS(_14773);
    _14773 = NOVALUE;

    /** scanner.e:902		file_include_depend[current_file_no] &= length( known_files )*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _14775 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _14775 = 1;
    }
    _2 = (object)SEQ_PTR(_37file_include_depend_15410);
    _14776 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21447);
    if (IS_SEQUENCE(_14776) && IS_ATOM(_14775)) {
        Append(&_14777, _14776, _14775);
    }
    else if (IS_ATOM(_14776) && IS_SEQUENCE(_14775)) {
    }
    else {
        Concat((object_ptr)&_14777, _14776, _14775);
        _14776 = NOVALUE;
    }
    _14776 = NOVALUE;
    _14775 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_depend_15410);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37file_include_depend_15410 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21447);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14777;
    if( _1 != _14777 ){
        DeRef(_1);
    }
    _14777 = NOVALUE;

    /** scanner.e:903		check_coverage()*/
    _51check_coverage();

    /** scanner.e:904		default_namespaces &= 0*/
    Append(&_62default_namespaces_25559, _62default_namespaces_25559, 0);

    /** scanner.e:906		update_include_matrix( length( file_include ), current_file_no )*/
    if (IS_SEQUENCE(_37file_include_15411)){
            _14779 = SEQ_PTR(_37file_include_15411)->length;
    }
    else {
        _14779 = 1;
    }
    _62update_include_matrix(_14779, _36current_file_no_21447);
    _14779 = NOVALUE;

    /** scanner.e:907		old_file_no = current_file_no*/
    _old_file_no_26561 = _36current_file_no_21447;

    /** scanner.e:908		current_file_no = length(known_files)*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _36current_file_no_21447 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _36current_file_no_21447 = 1;
    }

    /** scanner.e:909		line_number = 0*/
    _36line_number_21448 = 0;

    /** scanner.e:910		read_line()*/
    _62read_line();

    /** scanner.e:912		if new_include_space != 0 then*/
    if (_62new_include_space_25551 == 0)
    goto LE; // [877] 901

    /** scanner.e:913			SymTab[new_include_space][S_OBJ] = current_file_no*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_62new_include_space_25551 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21447;
    DeRef(_1);
    _14782 = NOVALUE;
LE: 

    /** scanner.e:915		default_namespace( )*/
    _62default_namespace();

    /** scanner.e:916	end procedure*/
    DeRef(_new_hash_26562);
    DeRef(_14725);
    _14725 = NOVALUE;
    return;
    ;
}


void _62update_include_completion(object _file_no_26787)
{
    object _fx_26796 = NOVALUE;
    object _14792 = NOVALUE;
    object _14791 = NOVALUE;
    object _14790 = NOVALUE;
    object _14789 = NOVALUE;
    object _14787 = NOVALUE;
    object _14786 = NOVALUE;
    object _14785 = NOVALUE;
    object _14784 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:919		for i = 1 to length( file_include_depend ) do*/
    if (IS_SEQUENCE(_37file_include_depend_15410)){
            _14784 = SEQ_PTR(_37file_include_depend_15410)->length;
    }
    else {
        _14784 = 1;
    }
    {
        object _i_26789;
        _i_26789 = 1;
L1: 
        if (_i_26789 > _14784){
            goto L2; // [10] 114
        }

        /** scanner.e:920			if length( file_include_depend[i] ) then*/
        _2 = (object)SEQ_PTR(_37file_include_depend_15410);
        _14785 = (object)*(((s1_ptr)_2)->base + _i_26789);
        if (IS_SEQUENCE(_14785)){
                _14786 = SEQ_PTR(_14785)->length;
        }
        else {
            _14786 = 1;
        }
        _14785 = NOVALUE;
        if (_14786 == 0)
        {
            _14786 = NOVALUE;
            goto L3; // [28] 105
        }
        else{
            _14786 = NOVALUE;
        }

        /** scanner.e:921				integer fx = find( file_no, file_include_depend[i] )*/
        _2 = (object)SEQ_PTR(_37file_include_depend_15410);
        _14787 = (object)*(((s1_ptr)_2)->base + _i_26789);
        _fx_26796 = find_from(_file_no_26787, _14787, 1);
        _14787 = NOVALUE;

        /** scanner.e:922				if fx then*/
        if (_fx_26796 == 0)
        {
            goto L4; // [46] 104
        }
        else{
        }

        /** scanner.e:923					file_include_depend[i] = remove( file_include_depend[i], fx )*/
        _2 = (object)SEQ_PTR(_37file_include_depend_15410);
        _14789 = (object)*(((s1_ptr)_2)->base + _i_26789);
        {
            s1_ptr assign_space = SEQ_PTR(_14789);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_26796)) ? _fx_26796 : (object)(DBL_PTR(_fx_26796)->dbl);
            int stop = (IS_ATOM_INT(_fx_26796)) ? _fx_26796 : (object)(DBL_PTR(_fx_26796)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
                RefDS(_14789);
                DeRef(_14790);
                _14790 = _14789;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_14789), start, &_14790 );
                }
                else Tail(SEQ_PTR(_14789), stop+1, &_14790);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_14789), start, &_14790);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_14790);
                _14790 = _1;
            }
        }
        _14789 = NOVALUE;
        _2 = (object)SEQ_PTR(_37file_include_depend_15410);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37file_include_depend_15410 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_26789);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14790;
        if( _1 != _14790 ){
            DeRef(_1);
        }
        _14790 = NOVALUE;

        /** scanner.e:924					if not length( file_include_depend[i] ) then*/
        _2 = (object)SEQ_PTR(_37file_include_depend_15410);
        _14791 = (object)*(((s1_ptr)_2)->base + _i_26789);
        if (IS_SEQUENCE(_14791)){
                _14792 = SEQ_PTR(_14791)->length;
        }
        else {
            _14792 = 1;
        }
        _14791 = NOVALUE;
        if (_14792 != 0)
        goto L5; // [79] 103
        _14792 = NOVALUE;

        /** scanner.e:925						finished_files[i] = 1*/
        _2 = (object)SEQ_PTR(_37finished_files_15409);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37finished_files_15409 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_26789);
        *(intptr_t *)_2 = 1;

        /** scanner.e:926						if i != file_no then*/
        if (_i_26789 == _file_no_26787)
        goto L6; // [92] 102

        /** scanner.e:927							update_include_completion( i )*/
        _62update_include_completion(_i_26789);
L6: 
L5: 
L4: 
L3: 

        /** scanner.e:932		end for*/
        _i_26789 = _i_26789 + 1;
        goto L1; // [109] 17
L2: 
        ;
    }

    /** scanner.e:933	end procedure*/
    _14791 = NOVALUE;
    _14785 = NOVALUE;
    return;
    ;
}


object _62IncludePop()
{
    object _top_26827 = NOVALUE;
    object _14823 = NOVALUE;
    object _14821 = NOVALUE;
    object _14820 = NOVALUE;
    object _14798 = NOVALUE;
    object _14796 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:940		update_include_completion( current_file_no )*/
    _62update_include_completion(_36current_file_no_21447);

    /** scanner.e:941		Resolve_forward_references()*/
    _44Resolve_forward_references(0);

    /** scanner.e:942		HideLocals()*/
    _54HideLocals();

    /** scanner.e:944		if src_file >= 0 then*/
    if (_36src_file_21572 < 0)
    goto L1; // [21] 39

    /** scanner.e:945			close(src_file)*/
    EClose(_36src_file_21572);

    /** scanner.e:946			src_file = -1*/
    _36src_file_21572 = -1;
L1: 

    /** scanner.e:949		if length(IncludeStk) = 0 then*/
    if (IS_SEQUENCE(_62IncludeStk_25562)){
            _14796 = SEQ_PTR(_62IncludeStk_25562)->length;
    }
    else {
        _14796 = 1;
    }
    if (_14796 != 0)
    goto L2; // [46] 59

    /** scanner.e:950			return FALSE  -- the end*/
    DeRef(_top_26827);
    return _13FALSE_450;
L2: 

    /** scanner.e:953		sequence top = IncludeStk[$]*/
    if (IS_SEQUENCE(_62IncludeStk_25562)){
            _14798 = SEQ_PTR(_62IncludeStk_25562)->length;
    }
    else {
        _14798 = 1;
    }
    DeRef(_top_26827);
    _2 = (object)SEQ_PTR(_62IncludeStk_25562);
    _top_26827 = (object)*(((s1_ptr)_2)->base + _14798);
    RefDS(_top_26827);

    /** scanner.e:955		current_file_no    = top[FILE_NO]*/
    _2 = (object)SEQ_PTR(_top_26827);
    _36current_file_no_21447 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_36current_file_no_21447)){
        _36current_file_no_21447 = (object)DBL_PTR(_36current_file_no_21447)->dbl;
    }

    /** scanner.e:956		line_number        = top[LINE_NO]*/
    _2 = (object)SEQ_PTR(_top_26827);
    _36line_number_21448 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_36line_number_21448)){
        _36line_number_21448 = (object)DBL_PTR(_36line_number_21448)->dbl;
    }

    /** scanner.e:957		src_file           = top[FILE_PTR]*/
    _2 = (object)SEQ_PTR(_top_26827);
    _36src_file_21572 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_36src_file_21572)){
        _36src_file_21572 = (object)DBL_PTR(_36src_file_21572)->dbl;
    }

    /** scanner.e:958		file_start_sym     = top[FILE_START_SYM]*/
    _2 = (object)SEQ_PTR(_top_26827);
    _36file_start_sym_21453 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_36file_start_sym_21453)){
        _36file_start_sym_21453 = (object)DBL_PTR(_36file_start_sym_21453)->dbl;
    }

    /** scanner.e:959		OpWarning          = top[OP_WARNING]*/
    _2 = (object)SEQ_PTR(_top_26827);
    _36OpWarning_21518 = (object)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_36OpWarning_21518)){
        _36OpWarning_21518 = (object)DBL_PTR(_36OpWarning_21518)->dbl;
    }

    /** scanner.e:960		OpTrace            = top[OP_TRACE]*/
    _2 = (object)SEQ_PTR(_top_26827);
    _36OpTrace_21520 = (object)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_36OpTrace_21520)){
        _36OpTrace_21520 = (object)DBL_PTR(_36OpTrace_21520)->dbl;
    }

    /** scanner.e:961		OpTypeCheck        = top[OP_TYPE_CHECK]*/
    _2 = (object)SEQ_PTR(_top_26827);
    _36OpTypeCheck_21521 = (object)*(((s1_ptr)_2)->base + 7);
    if (!IS_ATOM_INT(_36OpTypeCheck_21521)){
        _36OpTypeCheck_21521 = (object)DBL_PTR(_36OpTypeCheck_21521)->dbl;
    }

    /** scanner.e:962		OpProfileTime      = top[OP_PROFILE_TIME]*/
    _2 = (object)SEQ_PTR(_top_26827);
    _36OpProfileTime_21523 = (object)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_36OpProfileTime_21523)){
        _36OpProfileTime_21523 = (object)DBL_PTR(_36OpProfileTime_21523)->dbl;
    }

    /** scanner.e:963		OpProfileStatement = top[OP_PROFILE_STATEMENT]*/
    _2 = (object)SEQ_PTR(_top_26827);
    _36OpProfileStatement_21522 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_36OpProfileStatement_21522)){
        _36OpProfileStatement_21522 = (object)DBL_PTR(_36OpProfileStatement_21522)->dbl;
    }

    /** scanner.e:964		OpDefines          = top[OP_DEFINES]*/
    DeRef(_36OpDefines_21524);
    _2 = (object)SEQ_PTR(_top_26827);
    _36OpDefines_21524 = (object)*(((s1_ptr)_2)->base + 10);
    Ref(_36OpDefines_21524);

    /** scanner.e:965		prev_OpWarning     = top[PREV_OP_WARNING]*/
    _2 = (object)SEQ_PTR(_top_26827);
    _36prev_OpWarning_21519 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_36prev_OpWarning_21519)){
        _36prev_OpWarning_21519 = (object)DBL_PTR(_36prev_OpWarning_21519)->dbl;
    }

    /** scanner.e:966		OpInline           = top[OP_INLINE]*/
    _2 = (object)SEQ_PTR(_top_26827);
    _36OpInline_21525 = (object)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_36OpInline_21525)){
        _36OpInline_21525 = (object)DBL_PTR(_36OpInline_21525)->dbl;
    }

    /** scanner.e:967		OpIndirectInclude  = top[OP_INDIRECT_INCLUDE]*/
    _2 = (object)SEQ_PTR(_top_26827);
    _36OpIndirectInclude_21526 = (object)*(((s1_ptr)_2)->base + 13);
    if (!IS_ATOM_INT(_36OpIndirectInclude_21526)){
        _36OpIndirectInclude_21526 = (object)DBL_PTR(_36OpIndirectInclude_21526)->dbl;
    }

    /** scanner.e:968		putback_fwd_line_number = line_number -- top[PUTBACK_FWD_LINE_NUMBER]*/
    _36putback_fwd_line_number_21450 = _36line_number_21448;

    /** scanner.e:969		putback_ForwardLine = top[PUTBACK_FORWARDLINE]*/
    DeRef(_50putback_ForwardLine_49240);
    _2 = (object)SEQ_PTR(_top_26827);
    _50putback_ForwardLine_49240 = (object)*(((s1_ptr)_2)->base + 15);
    Ref(_50putback_ForwardLine_49240);

    /** scanner.e:970		putback_forward_bp = top[PUTBACK_FORWARD_BP]*/
    _2 = (object)SEQ_PTR(_top_26827);
    _50putback_forward_bp_49244 = (object)*(((s1_ptr)_2)->base + 16);
    if (!IS_ATOM_INT(_50putback_forward_bp_49244)){
        _50putback_forward_bp_49244 = (object)DBL_PTR(_50putback_forward_bp_49244)->dbl;
    }

    /** scanner.e:971		last_fwd_line_number = top[LAST_FWD_LINE_NUMBER]*/
    _2 = (object)SEQ_PTR(_top_26827);
    _36last_fwd_line_number_21451 = (object)*(((s1_ptr)_2)->base + 17);
    if (!IS_ATOM_INT(_36last_fwd_line_number_21451)){
        _36last_fwd_line_number_21451 = (object)DBL_PTR(_36last_fwd_line_number_21451)->dbl;
    }

    /** scanner.e:972		last_ForwardLine = top[LAST_FORWARDLINE]*/
    DeRef(_50last_ForwardLine_49241);
    _2 = (object)SEQ_PTR(_top_26827);
    _50last_ForwardLine_49241 = (object)*(((s1_ptr)_2)->base + 18);
    Ref(_50last_ForwardLine_49241);

    /** scanner.e:973		last_forward_bp = top[LAST_FORWARD_BP]*/
    _2 = (object)SEQ_PTR(_top_26827);
    _50last_forward_bp_49245 = (object)*(((s1_ptr)_2)->base + 19);
    if (!IS_ATOM_INT(_50last_forward_bp_49245)){
        _50last_forward_bp_49245 = (object)DBL_PTR(_50last_forward_bp_49245)->dbl;
    }

    /** scanner.e:974		ThisLine = top[THISLINE]*/
    DeRef(_50ThisLine_49238);
    _2 = (object)SEQ_PTR(_top_26827);
    _50ThisLine_49238 = (object)*(((s1_ptr)_2)->base + 20);
    Ref(_50ThisLine_49238);

    /** scanner.e:976		fwd_line_number = line_number --top[FWD_LINE_NUMBER]*/
    _36fwd_line_number_21449 = _36line_number_21448;

    /** scanner.e:977		forward_bp = top[FORWARD_BP]*/
    _2 = (object)SEQ_PTR(_top_26827);
    _50forward_bp_49243 = (object)*(((s1_ptr)_2)->base + 22);
    if (!IS_ATOM_INT(_50forward_bp_49243)){
        _50forward_bp_49243 = (object)DBL_PTR(_50forward_bp_49243)->dbl;
    }

    /** scanner.e:978		ForwardLine = ThisLine*/
    Ref(_50ThisLine_49238);
    DeRef(_50ForwardLine_49239);
    _50ForwardLine_49239 = _50ThisLine_49238;

    /** scanner.e:980		putback_ForwardLine = ThisLine*/
    Ref(_50ThisLine_49238);
    DeRef(_50putback_ForwardLine_49240);
    _50putback_ForwardLine_49240 = _50ThisLine_49238;

    /** scanner.e:981		last_ForwardLine = ThisLine*/
    Ref(_50ThisLine_49238);
    DeRef(_50last_ForwardLine_49241);
    _50last_ForwardLine_49241 = _50ThisLine_49238;

    /** scanner.e:983		IncludeStk = IncludeStk[1..$-1]*/
    if (IS_SEQUENCE(_62IncludeStk_25562)){
            _14820 = SEQ_PTR(_62IncludeStk_25562)->length;
    }
    else {
        _14820 = 1;
    }
    _14821 = _14820 - 1;
    _14820 = NOVALUE;
    rhs_slice_target = (object_ptr)&_62IncludeStk_25562;
    RHS_Slice(_62IncludeStk_25562, 1, _14821);

    /** scanner.e:984		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21454 + ((s1_ptr)_2)->base);
    RefDS(_36Code_21539);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21096))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21096)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21096);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36Code_21539;
    DeRef(_1);
    _14823 = NOVALUE;

    /** scanner.e:987		return TRUE*/
    DeRefDS(_top_26827);
    _14821 = NOVALUE;
    return _13TRUE_452;
    ;
}


object _62MakeInt(object _text_26928, object _nBase_26929)
{
    object _num_26930 = NOVALUE;
    object _maxchk_26931 = NOVALUE;
    object _fnum_26932 = NOVALUE;
    object _digit_26933 = NOVALUE;
    object _14873 = NOVALUE;
    object _14871 = NOVALUE;
    object _14869 = NOVALUE;
    object _14866 = NOVALUE;
    object _14865 = NOVALUE;
    object _14864 = NOVALUE;
    object _14862 = NOVALUE;
    object _14860 = NOVALUE;
    object _14859 = NOVALUE;
    object _14858 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_nBase_26929)) {
        _1 = (object)(DBL_PTR(_nBase_26929)->dbl);
        DeRefDS(_nBase_26929);
        _nBase_26929 = _1;
    }

    /** scanner.e:1012		ifdef BITS32 then*/

    /** scanner.e:1013			atom num, maxchk*/

    /** scanner.e:1017		atom fnum*/

    /** scanner.e:1018		integer digit*/

    /** scanner.e:1021		switch nBase do*/
    _0 = _nBase_26929;
    switch ( _0 ){ 

        /** scanner.e:1022			case 2 then*/
        case 2:

        /** scanner.e:1023				maxchk = MAXCHK2*/
        _maxchk_26931 = 536870911;
        goto L1; // [29] 90

        /** scanner.e:1025			case 8 then*/
        case 8:

        /** scanner.e:1026				maxchk = MAXCHK8*/
        _maxchk_26931 = 134217727;
        goto L1; // [40] 90

        /** scanner.e:1028			case 10 then*/
        case 10:

        /** scanner.e:1030				num = find(text, common_int_text)*/
        DeRef(_num_26930);
        _num_26930 = find_from(_text_26928, _62common_int_text_26903, 1);

        /** scanner.e:1031				if num then*/
        if (_num_26930 == 0)
        {
            goto L2; // [57] 73
        }
        else{
        }

        /** scanner.e:1032					return common_ints[num]*/
        _2 = (object)SEQ_PTR(_62common_ints_26923);
        _14858 = (object)*(((s1_ptr)_2)->base + _num_26930);
        DeRefDS(_text_26928);
        DeRef(_fnum_26932);
        return _14858;
L2: 

        /** scanner.e:1035				maxchk = MAXCHK10*/
        _maxchk_26931 = 107374181;
        goto L1; // [78] 90

        /** scanner.e:1037			case 16 then*/
        case 16:

        /** scanner.e:1038				maxchk = MAXCHK16*/
        _maxchk_26931 = 67108863;
    ;}L1: 

    /** scanner.e:1042		num = 0*/
    DeRef(_num_26930);
    _num_26930 = 0;

    /** scanner.e:1043		fnum = 0*/
    DeRef(_fnum_26932);
    _fnum_26932 = 0;

    /** scanner.e:1044		for i = 1 to length(text) do*/
    if (IS_SEQUENCE(_text_26928)){
            _14859 = SEQ_PTR(_text_26928)->length;
    }
    else {
        _14859 = 1;
    }
    {
        object _i_26944;
        _i_26944 = 1;
L3: 
        if (_i_26944 > _14859){
            goto L4; // [105] 220
        }

        /** scanner.e:1045			digit = (text[i] - '0')*/
        _2 = (object)SEQ_PTR(_text_26928);
        _14860 = (object)*(((s1_ptr)_2)->base + _i_26944);
        if (IS_ATOM_INT(_14860)) {
            _digit_26933 = _14860 - 48;
        }
        else {
            _digit_26933 = binary_op(MINUS, _14860, 48);
        }
        _14860 = NOVALUE;
        if (!IS_ATOM_INT(_digit_26933)) {
            _1 = (object)(DBL_PTR(_digit_26933)->dbl);
            DeRefDS(_digit_26933);
            _digit_26933 = _1;
        }

        /** scanner.e:1046			if digit >= nBase or digit < 0 then*/
        _14862 = (_digit_26933 >= _nBase_26929);
        if (_14862 != 0) {
            goto L5; // [130] 143
        }
        _14864 = (_digit_26933 < 0);
        if (_14864 == 0)
        {
            DeRef(_14864);
            _14864 = NOVALUE;
            goto L6; // [139] 161
        }
        else{
            DeRef(_14864);
            _14864 = NOVALUE;
        }
L5: 

        /** scanner.e:1047				CompileErr(DIGIT_1_AT_POSITION_2_IS_OUTSIDE_OF_NUMBER_BASE, {text[i],i})*/
        _2 = (object)SEQ_PTR(_text_26928);
        _14865 = (object)*(((s1_ptr)_2)->base + _i_26944);
        Ref(_14865);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _14865;
        ((intptr_t *)_2)[2] = _i_26944;
        _14866 = MAKE_SEQ(_1);
        _14865 = NOVALUE;
        _50CompileErr(62, _14866, 0);
        _14866 = NOVALUE;
L6: 

        /** scanner.e:1049			if fnum = 0 then*/
        if (binary_op_a(NOTEQ, _fnum_26932, 0)){
            goto L7; // [163] 202
        }

        /** scanner.e:1050				if num <= maxchk then*/
        if (binary_op_a(GREATER, _num_26930, _maxchk_26931)){
            goto L8; // [171] 188
        }

        /** scanner.e:1051					num = num * nBase + digit*/
        if (IS_ATOM_INT(_num_26930)) {
            if (_num_26930 == (short)_num_26930 && _nBase_26929 <= INT15 && _nBase_26929 >= -INT15){
                _14869 = _num_26930 * _nBase_26929;
            }
            else{
                _14869 = NewDouble(_num_26930 * (eudouble)_nBase_26929);
            }
        }
        else {
            _14869 = NewDouble(DBL_PTR(_num_26930)->dbl * (eudouble)_nBase_26929);
        }
        DeRef(_num_26930);
        if (IS_ATOM_INT(_14869)) {
            _num_26930 = _14869 + _digit_26933;
            if ((object)((uintptr_t)_num_26930 + (uintptr_t)HIGH_BITS) >= 0){
                _num_26930 = NewDouble((eudouble)_num_26930);
            }
        }
        else {
            _num_26930 = NewDouble(DBL_PTR(_14869)->dbl + (eudouble)_digit_26933);
        }
        DeRef(_14869);
        _14869 = NOVALUE;
        goto L9; // [185] 213
L8: 

        /** scanner.e:1053					fnum = num * nBase + digit*/
        if (IS_ATOM_INT(_num_26930)) {
            if (_num_26930 == (short)_num_26930 && _nBase_26929 <= INT15 && _nBase_26929 >= -INT15){
                _14871 = _num_26930 * _nBase_26929;
            }
            else{
                _14871 = NewDouble(_num_26930 * (eudouble)_nBase_26929);
            }
        }
        else {
            _14871 = NewDouble(DBL_PTR(_num_26930)->dbl * (eudouble)_nBase_26929);
        }
        DeRef(_fnum_26932);
        if (IS_ATOM_INT(_14871)) {
            _fnum_26932 = _14871 + _digit_26933;
            if ((object)((uintptr_t)_fnum_26932 + (uintptr_t)HIGH_BITS) >= 0){
                _fnum_26932 = NewDouble((eudouble)_fnum_26932);
            }
        }
        else {
            _fnum_26932 = NewDouble(DBL_PTR(_14871)->dbl + (eudouble)_digit_26933);
        }
        DeRef(_14871);
        _14871 = NOVALUE;
        goto L9; // [199] 213
L7: 

        /** scanner.e:1056				fnum = fnum * nBase + digit*/
        if (IS_ATOM_INT(_fnum_26932)) {
            if (_fnum_26932 == (short)_fnum_26932 && _nBase_26929 <= INT15 && _nBase_26929 >= -INT15){
                _14873 = _fnum_26932 * _nBase_26929;
            }
            else{
                _14873 = NewDouble(_fnum_26932 * (eudouble)_nBase_26929);
            }
        }
        else {
            _14873 = NewDouble(DBL_PTR(_fnum_26932)->dbl * (eudouble)_nBase_26929);
        }
        DeRef(_fnum_26932);
        if (IS_ATOM_INT(_14873)) {
            _fnum_26932 = _14873 + _digit_26933;
            if ((object)((uintptr_t)_fnum_26932 + (uintptr_t)HIGH_BITS) >= 0){
                _fnum_26932 = NewDouble((eudouble)_fnum_26932);
            }
        }
        else {
            _fnum_26932 = NewDouble(DBL_PTR(_14873)->dbl + (eudouble)_digit_26933);
        }
        DeRef(_14873);
        _14873 = NOVALUE;
L9: 

        /** scanner.e:1058		end for*/
        _i_26944 = _i_26944 + 1;
        goto L3; // [215] 112
L4: 
        ;
    }

    /** scanner.e:1060		if fnum = 0 then*/
    if (binary_op_a(NOTEQ, _fnum_26932, 0)){
        goto LA; // [222] 235
    }

    /** scanner.e:1061			return num*/
    DeRefDS(_text_26928);
    DeRef(_fnum_26932);
    DeRef(_14862);
    _14862 = NOVALUE;
    _14858 = NOVALUE;
    return _num_26930;
    goto LB; // [232] 242
LA: 

    /** scanner.e:1063			return fnum*/
    DeRefDS(_text_26928);
    DeRef(_num_26930);
    DeRef(_14862);
    _14862 = NOVALUE;
    _14858 = NOVALUE;
    return _fnum_26932;
LB: 
    ;
}


object _62GetHexChar(object _cnt_26973, object _errno_26974)
{
    object _val_26975 = NOVALUE;
    object _d_26976 = NOVALUE;
    object _14883 = NOVALUE;
    object _14882 = NOVALUE;
    object _14877 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1070		val = 0*/
    DeRef(_val_26975);
    _val_26975 = 0;

    /** scanner.e:1072		while cnt > 0 do*/
L1: 
    if (_cnt_26973 <= 0)
    goto L2; // [15] 88

    /** scanner.e:1073			d = find(getch(), "0123456789ABCDEFabcdef_")*/
    _14877 = _62getch();
    _d_26976 = find_from(_14877, _14878, 1);
    DeRef(_14877);
    _14877 = NOVALUE;

    /** scanner.e:1074			if d = 0 then*/
    if (_d_26976 != 0)
    goto L3; // [31] 43

    /** scanner.e:1075				CompileErr( errno )*/
    RefDS(_21997);
    _50CompileErr(_errno_26974, _21997, 0);
L3: 

    /** scanner.e:1077			if d != 23 then*/
    if (_d_26976 == 23)
    goto L1; // [45] 15

    /** scanner.e:1078				val = val * 16 + d - 1*/
    if (IS_ATOM_INT(_val_26975)) {
        if (_val_26975 == (short)_val_26975){
            _14882 = _val_26975 * 16;
        }
        else{
            _14882 = NewDouble(_val_26975 * (eudouble)16);
        }
    }
    else {
        _14882 = NewDouble(DBL_PTR(_val_26975)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_14882)) {
        _14883 = _14882 + _d_26976;
        if ((object)((uintptr_t)_14883 + (uintptr_t)HIGH_BITS) >= 0){
            _14883 = NewDouble((eudouble)_14883);
        }
    }
    else {
        _14883 = NewDouble(DBL_PTR(_14882)->dbl + (eudouble)_d_26976);
    }
    DeRef(_14882);
    _14882 = NOVALUE;
    DeRef(_val_26975);
    if (IS_ATOM_INT(_14883)) {
        _val_26975 = _14883 - 1;
        if ((object)((uintptr_t)_val_26975 +(uintptr_t) HIGH_BITS) >= 0){
            _val_26975 = NewDouble((eudouble)_val_26975);
        }
    }
    else {
        _val_26975 = NewDouble(DBL_PTR(_14883)->dbl - (eudouble)1);
    }
    DeRef(_14883);
    _14883 = NOVALUE;

    /** scanner.e:1079				if d > 16 then*/
    if (_d_26976 <= 16)
    goto L4; // [65] 76

    /** scanner.e:1080					val -= 6*/
    _0 = _val_26975;
    if (IS_ATOM_INT(_val_26975)) {
        _val_26975 = _val_26975 - 6;
        if ((object)((uintptr_t)_val_26975 +(uintptr_t) HIGH_BITS) >= 0){
            _val_26975 = NewDouble((eudouble)_val_26975);
        }
    }
    else {
        _val_26975 = NewDouble(DBL_PTR(_val_26975)->dbl - (eudouble)6);
    }
    DeRef(_0);
L4: 

    /** scanner.e:1082				cnt -= 1*/
    _cnt_26973 = _cnt_26973 - 1;

    /** scanner.e:1084		end while*/
    goto L1; // [85] 15
L2: 

    /** scanner.e:1086		return val*/
    return _val_26975;
    ;
}


object _62GetBinaryChar(object _delim_26996)
{
    object _val_26997 = NOVALUE;
    object _d_26998 = NOVALUE;
    object _vchars_26999 = NOVALUE;
    object _cnt_27002 = NOVALUE;
    object _14897 = NOVALUE;
    object _14896 = NOVALUE;
    object _14890 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1092		sequence vchars = "01_ " & delim*/
    Append(&_vchars_26999, _14888, _delim_26996);

    /** scanner.e:1093		integer cnt = 0*/
    _cnt_27002 = 0;

    /** scanner.e:1094		val = 0*/
    DeRef(_val_26997);
    _val_26997 = 0;

    /** scanner.e:1095		while 1 do*/
L1: 

    /** scanner.e:1096			d = find(getch(), vchars)*/
    _14890 = _62getch();
    _d_26998 = find_from(_14890, _vchars_26999, 1);
    DeRef(_14890);
    _14890 = NOVALUE;

    /** scanner.e:1097			if d = 0 then*/
    if (_d_26998 != 0)
    goto L2; // [36] 50

    /** scanner.e:1098				CompileErr( EXPECTING_ONLY_0_1_OR_SPACE_TO_FOLLOW_THE_B)*/
    RefDS(_21997);
    _50CompileErr(343, _21997, 0);
L2: 

    /** scanner.e:1100			if d = 5 then*/
    if (_d_26998 != 5)
    goto L3; // [52] 65

    /** scanner.e:1101				ungetch()*/
    _62ungetch();

    /** scanner.e:1102				exit*/
    goto L4; // [62] 108
L3: 

    /** scanner.e:1104			if d = 4 then*/
    if (_d_26998 != 4)
    goto L5; // [67] 76

    /** scanner.e:1105				exit*/
    goto L4; // [73] 108
L5: 

    /** scanner.e:1107			if d != 3 then*/
    if (_d_26998 == 3)
    goto L1; // [78] 24

    /** scanner.e:1108				val = val * 2 + d - 1*/
    if (IS_ATOM_INT(_val_26997) && IS_ATOM_INT(_val_26997)) {
        _14896 = _val_26997 + _val_26997;
        if ((object)((uintptr_t)_14896 + (uintptr_t)HIGH_BITS) >= 0){
            _14896 = NewDouble((eudouble)_14896);
        }
    }
    else {
        if (IS_ATOM_INT(_val_26997)) {
            _14896 = NewDouble((eudouble)_val_26997 + DBL_PTR(_val_26997)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_26997)) {
                _14896 = NewDouble(DBL_PTR(_val_26997)->dbl + (eudouble)_val_26997);
            }
            else
            _14896 = NewDouble(DBL_PTR(_val_26997)->dbl + DBL_PTR(_val_26997)->dbl);
        }
    }
    if (IS_ATOM_INT(_14896)) {
        _14897 = _14896 + _d_26998;
        if ((object)((uintptr_t)_14897 + (uintptr_t)HIGH_BITS) >= 0){
            _14897 = NewDouble((eudouble)_14897);
        }
    }
    else {
        _14897 = NewDouble(DBL_PTR(_14896)->dbl + (eudouble)_d_26998);
    }
    DeRef(_14896);
    _14896 = NOVALUE;
    DeRef(_val_26997);
    if (IS_ATOM_INT(_14897)) {
        _val_26997 = _14897 - 1;
        if ((object)((uintptr_t)_val_26997 +(uintptr_t) HIGH_BITS) >= 0){
            _val_26997 = NewDouble((eudouble)_val_26997);
        }
    }
    else {
        _val_26997 = NewDouble(DBL_PTR(_14897)->dbl - (eudouble)1);
    }
    DeRef(_14897);
    _14897 = NOVALUE;

    /** scanner.e:1109				cnt += 1*/
    _cnt_27002 = _cnt_27002 + 1;

    /** scanner.e:1111		end while*/
    goto L1; // [105] 24
L4: 

    /** scanner.e:1113		if cnt = 0 then*/
    if (_cnt_27002 != 0)
    goto L6; // [110] 124

    /** scanner.e:1114			CompileErr(EXPECTING_ONLY_0_1_OR_SPACE_TO_FOLLOW_THE_B)*/
    RefDS(_21997);
    _50CompileErr(343, _21997, 0);
L6: 

    /** scanner.e:1116		return val*/
    DeRefi(_vchars_26999);
    return _val_26997;
    ;
}


object _62EscapeChar(object _delim_27026)
{
    object _c_27027 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1124		c = getch()*/
    _0 = _c_27027;
    _c_27027 = _62getch();
    DeRef(_0);

    /** scanner.e:1125		switch c do*/
    if (IS_SEQUENCE(_c_27027) ){
        goto L1; // [10] 135
    }
    if(!IS_ATOM_INT(_c_27027)){
        if( (DBL_PTR(_c_27027)->dbl != (eudouble) ((object) DBL_PTR(_c_27027)->dbl) ) ){
            goto L1; // [10] 135
        }
        _0 = (object) DBL_PTR(_c_27027)->dbl;
    }
    else {
        _0 = _c_27027;
    };
    switch ( _0 ){ 

        /** scanner.e:1126			case 'n' then*/
        case 110:

        /** scanner.e:1127				c = 10 -- Newline*/
        DeRef(_c_27027);
        _c_27027 = 10;
        goto L2; // [24] 147

        /** scanner.e:1129			case 't' then*/
        case 116:

        /** scanner.e:1130				c = 9 -- Tabulator*/
        DeRef(_c_27027);
        _c_27027 = 9;
        goto L2; // [35] 147

        /** scanner.e:1132			case '"', '\\', '\'' then*/
        case 34:
        case 92:
        case 39:

        /** scanner.e:1137			case 'r' then*/
        goto L2; // [47] 147
        case 114:

        /** scanner.e:1138				c = 13 -- Carriage Return*/
        DeRef(_c_27027);
        _c_27027 = 13;
        goto L2; // [56] 147

        /** scanner.e:1140			case '0' then*/
        case 48:

        /** scanner.e:1141				c = 0 -- Null*/
        DeRef(_c_27027);
        _c_27027 = 0;
        goto L2; // [67] 147

        /** scanner.e:1143			case 'e', 'E' then*/
        case 101:
        case 69:

        /** scanner.e:1144				c = 27 -- escape char.*/
        DeRef(_c_27027);
        _c_27027 = 27;
        goto L2; // [80] 147

        /** scanner.e:1146			case 'x' then*/
        case 120:

        /** scanner.e:1148				c = GetHexChar(2, 340)*/
        _0 = _c_27027;
        _c_27027 = _62GetHexChar(2, 340);
        DeRef(_0);
        goto L2; // [93] 147

        /** scanner.e:1150			case 'u' then*/
        case 117:

        /** scanner.e:1152				c = GetHexChar(4, 341)*/
        _0 = _c_27027;
        _c_27027 = _62GetHexChar(4, 341);
        DeRef(_0);
        goto L2; // [106] 147

        /** scanner.e:1154			case 'U' then*/
        case 85:

        /** scanner.e:1156				c = GetHexChar(8, 342)*/
        _0 = _c_27027;
        _c_27027 = _62GetHexChar(8, 342);
        DeRef(_0);
        goto L2; // [119] 147

        /** scanner.e:1158			case 'b' then*/
        case 98:

        /** scanner.e:1160				c = GetBinaryChar(delim)*/
        _0 = _c_27027;
        _c_27027 = _62GetBinaryChar(_delim_27026);
        DeRef(_0);
        goto L2; // [131] 147

        /** scanner.e:1162			case else*/
        default:
L1: 

        /** scanner.e:1163				CompileErr(UNKNOWN_ESCAPE_CHARACTER)*/
        RefDS(_21997);
        _50CompileErr(155, _21997, 0);
    ;}L2: 

    /** scanner.e:1166		return c*/
    return _c_27027;
    ;
}


object _62my_sscanf(object _yytext_27050)
{
    object _e_sign_27051 = NOVALUE;
    object _ndigits_27052 = NOVALUE;
    object _e_mag_27053 = NOVALUE;
    object _mantissa_27054 = NOVALUE;
    object _c_27055 = NOVALUE;
    object _i_27056 = NOVALUE;
    object _dec_27057 = NOVALUE;
    object _frac_27090 = NOVALUE;
    object _14942 = NOVALUE;
    object _14937 = NOVALUE;
    object _14936 = NOVALUE;
    object _14934 = NOVALUE;
    object _14933 = NOVALUE;
    object _14932 = NOVALUE;
    object _14924 = NOVALUE;
    object _14923 = NOVALUE;
    object _14920 = NOVALUE;
    object _14919 = NOVALUE;
    object _14918 = NOVALUE;
    object _14913 = NOVALUE;
    object _14912 = NOVALUE;
    object _14910 = NOVALUE;
    object _14908 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1179		if length(yytext) < 2 then*/
    if (IS_SEQUENCE(_yytext_27050)){
            _14908 = SEQ_PTR(_yytext_27050)->length;
    }
    else {
        _14908 = 1;
    }
    if (_14908 >= 2)
    goto L1; // [8] 22

    /** scanner.e:1180			CompileErr(NUMBER_NOT_FORMED_CORRECTLY)*/
    RefDS(_21997);
    _50CompileErr(121, _21997, 0);
L1: 

    /** scanner.e:1184		if find( 'e', yytext ) or find( 'E', yytext ) then*/
    _14910 = find_from(101, _yytext_27050, 1);
    if (_14910 != 0) {
        goto L2; // [29] 43
    }
    _14912 = find_from(69, _yytext_27050, 1);
    if (_14912 == 0)
    {
        _14912 = NOVALUE;
        goto L3; // [39] 59
    }
    else{
        _14912 = NOVALUE;
    }
L2: 

    /** scanner.e:1185			ifdef BITS32 then*/

    /** scanner.e:1186				return scientific_to_atom( yytext, DOUBLE )*/
    RefDS(_yytext_27050);
    _14913 = _28scientific_to_atom(_yytext_27050, 2);
    DeRefDS(_yytext_27050);
    DeRef(_mantissa_27054);
    DeRef(_dec_27057);
    return _14913;
L3: 

    /** scanner.e:1193		mantissa = 0.0*/
    RefDS(_14915);
    DeRef(_mantissa_27054);
    _mantissa_27054 = _14915;

    /** scanner.e:1194		ndigits = 0*/
    _ndigits_27052 = 0;

    /** scanner.e:1198		yytext &= 0 -- end marker*/
    Append(&_yytext_27050, _yytext_27050, 0);

    /** scanner.e:1199		c = yytext[1]*/
    _2 = (object)SEQ_PTR(_yytext_27050);
    _c_27055 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_c_27055))
    _c_27055 = (object)DBL_PTR(_c_27055)->dbl;

    /** scanner.e:1200		i = 2*/
    _i_27056 = 2;

    /** scanner.e:1201		while c >= '0' and c <= '9' do*/
L4: 
    _14918 = (_c_27055 >= 48);
    if (_14918 == 0) {
        goto L5; // [95] 144
    }
    _14920 = (_c_27055 <= 57);
    if (_14920 == 0)
    {
        DeRef(_14920);
        _14920 = NOVALUE;
        goto L5; // [104] 144
    }
    else{
        DeRef(_14920);
        _14920 = NOVALUE;
    }

    /** scanner.e:1202			ndigits += 1*/
    _ndigits_27052 = _ndigits_27052 + 1;

    /** scanner.e:1203			mantissa = mantissa * 10.0 + (c - '0')*/
    if (IS_ATOM_INT(_mantissa_27054)) {
        _14923 = NewDouble((eudouble)_mantissa_27054 * DBL_PTR(_14922)->dbl);
    }
    else {
        _14923 = NewDouble(DBL_PTR(_mantissa_27054)->dbl * DBL_PTR(_14922)->dbl);
    }
    _14924 = _c_27055 - 48;
    if ((object)((uintptr_t)_14924 +(uintptr_t) HIGH_BITS) >= 0){
        _14924 = NewDouble((eudouble)_14924);
    }
    DeRef(_mantissa_27054);
    if (IS_ATOM_INT(_14924)) {
        _mantissa_27054 = NewDouble(DBL_PTR(_14923)->dbl + (eudouble)_14924);
    }
    else
    _mantissa_27054 = NewDouble(DBL_PTR(_14923)->dbl + DBL_PTR(_14924)->dbl);
    DeRefDS(_14923);
    _14923 = NOVALUE;
    DeRef(_14924);
    _14924 = NOVALUE;

    /** scanner.e:1204			c = yytext[i]*/
    _2 = (object)SEQ_PTR(_yytext_27050);
    _c_27055 = (object)*(((s1_ptr)_2)->base + _i_27056);
    if (!IS_ATOM_INT(_c_27055))
    _c_27055 = (object)DBL_PTR(_c_27055)->dbl;

    /** scanner.e:1205			i += 1*/
    _i_27056 = _i_27056 + 1;

    /** scanner.e:1206		end while*/
    goto L4; // [141] 91
L5: 

    /** scanner.e:1208		if c = '.' then*/
    if (_c_27055 != 46)
    goto L6; // [146] 247

    /** scanner.e:1210			c = yytext[i]*/
    _2 = (object)SEQ_PTR(_yytext_27050);
    _c_27055 = (object)*(((s1_ptr)_2)->base + _i_27056);
    if (!IS_ATOM_INT(_c_27055))
    _c_27055 = (object)DBL_PTR(_c_27055)->dbl;

    /** scanner.e:1211			i += 1*/
    _i_27056 = _i_27056 + 1;

    /** scanner.e:1212			dec = 1.0*/
    RefDS(_14931);
    DeRef(_dec_27057);
    _dec_27057 = _14931;

    /** scanner.e:1213			atom frac = 0*/
    DeRef(_frac_27090);
    _frac_27090 = 0;

    /** scanner.e:1214			while c >= '0' and c <= '9' do*/
L7: 
    _14932 = (_c_27055 >= 48);
    if (_14932 == 0) {
        goto L8; // [181] 236
    }
    _14934 = (_c_27055 <= 57);
    if (_14934 == 0)
    {
        DeRef(_14934);
        _14934 = NOVALUE;
        goto L8; // [190] 236
    }
    else{
        DeRef(_14934);
        _14934 = NOVALUE;
    }

    /** scanner.e:1215				ndigits += 1*/
    _ndigits_27052 = _ndigits_27052 + 1;

    /** scanner.e:1216				frac = frac * 10 + (c - '0')*/
    if (IS_ATOM_INT(_frac_27090)) {
        if (_frac_27090 == (short)_frac_27090){
            _14936 = _frac_27090 * 10;
        }
        else{
            _14936 = NewDouble(_frac_27090 * (eudouble)10);
        }
    }
    else {
        _14936 = NewDouble(DBL_PTR(_frac_27090)->dbl * (eudouble)10);
    }
    _14937 = _c_27055 - 48;
    if ((object)((uintptr_t)_14937 +(uintptr_t) HIGH_BITS) >= 0){
        _14937 = NewDouble((eudouble)_14937);
    }
    DeRef(_frac_27090);
    if (IS_ATOM_INT(_14936) && IS_ATOM_INT(_14937)) {
        _frac_27090 = _14936 + _14937;
        if ((object)((uintptr_t)_frac_27090 + (uintptr_t)HIGH_BITS) >= 0){
            _frac_27090 = NewDouble((eudouble)_frac_27090);
        }
    }
    else {
        if (IS_ATOM_INT(_14936)) {
            _frac_27090 = NewDouble((eudouble)_14936 + DBL_PTR(_14937)->dbl);
        }
        else {
            if (IS_ATOM_INT(_14937)) {
                _frac_27090 = NewDouble(DBL_PTR(_14936)->dbl + (eudouble)_14937);
            }
            else
            _frac_27090 = NewDouble(DBL_PTR(_14936)->dbl + DBL_PTR(_14937)->dbl);
        }
    }
    DeRef(_14936);
    _14936 = NOVALUE;
    DeRef(_14937);
    _14937 = NOVALUE;

    /** scanner.e:1217				dec *= 10.0*/
    _0 = _dec_27057;
    if (IS_ATOM_INT(_dec_27057)) {
        _dec_27057 = NewDouble((eudouble)_dec_27057 * DBL_PTR(_14922)->dbl);
    }
    else {
        _dec_27057 = NewDouble(DBL_PTR(_dec_27057)->dbl * DBL_PTR(_14922)->dbl);
    }
    DeRef(_0);

    /** scanner.e:1218				c = yytext[i]*/
    _2 = (object)SEQ_PTR(_yytext_27050);
    _c_27055 = (object)*(((s1_ptr)_2)->base + _i_27056);
    if (!IS_ATOM_INT(_c_27055))
    _c_27055 = (object)DBL_PTR(_c_27055)->dbl;

    /** scanner.e:1219				i += 1*/
    _i_27056 = _i_27056 + 1;

    /** scanner.e:1220			end while*/
    goto L7; // [233] 177
L8: 

    /** scanner.e:1221			mantissa += frac / dec*/
    if (IS_ATOM_INT(_frac_27090) && IS_ATOM_INT(_dec_27057)) {
        _14942 = (_frac_27090 % _dec_27057) ? NewDouble((eudouble)_frac_27090 / _dec_27057) : (_frac_27090 / _dec_27057);
    }
    else {
        if (IS_ATOM_INT(_frac_27090)) {
            _14942 = NewDouble((eudouble)_frac_27090 / DBL_PTR(_dec_27057)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec_27057)) {
                _14942 = NewDouble(DBL_PTR(_frac_27090)->dbl / (eudouble)_dec_27057);
            }
            else
            _14942 = NewDouble(DBL_PTR(_frac_27090)->dbl / DBL_PTR(_dec_27057)->dbl);
        }
    }
    _0 = _mantissa_27054;
    if (IS_ATOM_INT(_mantissa_27054) && IS_ATOM_INT(_14942)) {
        _mantissa_27054 = _mantissa_27054 + _14942;
        if ((object)((uintptr_t)_mantissa_27054 + (uintptr_t)HIGH_BITS) >= 0){
            _mantissa_27054 = NewDouble((eudouble)_mantissa_27054);
        }
    }
    else {
        if (IS_ATOM_INT(_mantissa_27054)) {
            _mantissa_27054 = NewDouble((eudouble)_mantissa_27054 + DBL_PTR(_14942)->dbl);
        }
        else {
            if (IS_ATOM_INT(_14942)) {
                _mantissa_27054 = NewDouble(DBL_PTR(_mantissa_27054)->dbl + (eudouble)_14942);
            }
            else
            _mantissa_27054 = NewDouble(DBL_PTR(_mantissa_27054)->dbl + DBL_PTR(_14942)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_14942);
    _14942 = NOVALUE;
L6: 
    DeRef(_frac_27090);
    _frac_27090 = NOVALUE;

    /** scanner.e:1224		if ndigits = 0 then*/
    if (_ndigits_27052 != 0)
    goto L9; // [251] 265

    /** scanner.e:1225			CompileErr(NUMBER_NOT_FORMED_CORRECTLY)  -- no digits*/
    RefDS(_21997);
    _50CompileErr(121, _21997, 0);
L9: 

    /** scanner.e:1271		return mantissa*/
    DeRefDS(_yytext_27050);
    DeRef(_dec_27057);
    DeRef(_14913);
    _14913 = NOVALUE;
    DeRef(_14918);
    _14918 = NOVALUE;
    DeRef(_14932);
    _14932 = NOVALUE;
    return _mantissa_27054;
    ;
}


void _62maybe_namespace()
{
    object _0, _1, _2;
    

    /** scanner.e:1276		might_be_namespace = 1*/
    _62might_be_namespace_27108 = 1;

    /** scanner.e:1277	end procedure*/
    return;
    ;
}


object _62ExtendedString(object _ech_27118)
{
    object _ch_27119 = NOVALUE;
    object _fch_27120 = NOVALUE;
    object _cline_27121 = NOVALUE;
    object _string_text_27122 = NOVALUE;
    object _trimming_27123 = NOVALUE;
    object _14995 = NOVALUE;
    object _14994 = NOVALUE;
    object _14992 = NOVALUE;
    object _14991 = NOVALUE;
    object _14990 = NOVALUE;
    object _14989 = NOVALUE;
    object _14988 = NOVALUE;
    object _14987 = NOVALUE;
    object _14986 = NOVALUE;
    object _14985 = NOVALUE;
    object _14983 = NOVALUE;
    object _14982 = NOVALUE;
    object _14981 = NOVALUE;
    object _14980 = NOVALUE;
    object _14979 = NOVALUE;
    object _14978 = NOVALUE;
    object _14975 = NOVALUE;
    object _14974 = NOVALUE;
    object _14973 = NOVALUE;
    object _14971 = NOVALUE;
    object _14970 = NOVALUE;
    object _14969 = NOVALUE;
    object _14968 = NOVALUE;
    object _14965 = NOVALUE;
    object _14950 = NOVALUE;
    object _14948 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1290		cline = line_number*/
    _cline_27121 = _36line_number_21448;

    /** scanner.e:1291		string_text = ""*/
    RefDS(_5);
    DeRefi(_string_text_27122);
    _string_text_27122 = _5;

    /** scanner.e:1292		trimming = 0*/
    _trimming_27123 = 0;

    /** scanner.e:1293		ch = getch()*/
    _ch_27119 = _62getch();
    if (!IS_ATOM_INT(_ch_27119)) {
        _1 = (object)(DBL_PTR(_ch_27119)->dbl);
        DeRefDS(_ch_27119);
        _ch_27119 = _1;
    }

    /** scanner.e:1294		if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_50ThisLine_49238)){
            _14948 = SEQ_PTR(_50ThisLine_49238)->length;
    }
    else {
        _14948 = 1;
    }
    if (_50bp_49242 <= _14948)
    goto L1; // [40] 101

    /** scanner.e:1296			read_line()*/
    _62read_line();

    /** scanner.e:1297			while ThisLine[bp] = '_' do*/
L2: 
    _2 = (object)SEQ_PTR(_50ThisLine_49238);
    _14950 = (object)*(((s1_ptr)_2)->base + _50bp_49242);
    if (binary_op_a(NOTEQ, _14950, 95)){
        _14950 = NOVALUE;
        goto L3; // [61] 86
    }
    _14950 = NOVALUE;

    /** scanner.e:1298				trimming += 1*/
    _trimming_27123 = _trimming_27123 + 1;

    /** scanner.e:1299				bp += 1*/
    _50bp_49242 = _50bp_49242 + 1;

    /** scanner.e:1300			end while*/
    goto L2; // [83] 53
L3: 

    /** scanner.e:1301			if trimming > 0 then*/
    if (_trimming_27123 <= 0)
    goto L4; // [88] 100

    /** scanner.e:1302				ch = getch()*/
    _ch_27119 = _62getch();
    if (!IS_ATOM_INT(_ch_27119)) {
        _1 = (object)(DBL_PTR(_ch_27119)->dbl);
        DeRefDS(_ch_27119);
        _ch_27119 = _1;
    }
L4: 
L1: 

    /** scanner.e:1306		while 1 do*/
L5: 

    /** scanner.e:1307			if ch = END_OF_FILE_CHAR then*/
    if (_ch_27119 != 26)
    goto L6; // [110] 124

    /** scanner.e:1308				CompileErr(RAW_STRING_LITERAL_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _50CompileErr(129, _cline_27121, 0);
L6: 

    /** scanner.e:1311			if ch = ech then*/
    if (_ch_27119 != _ech_27118)
    goto L7; // [126] 182

    /** scanner.e:1312				if ech != '"' then*/
    if (_ech_27118 == 34)
    goto L8; // [132] 141

    /** scanner.e:1313					exit*/
    goto L9; // [138] 312
L8: 

    /** scanner.e:1315				fch = getch()*/
    _fch_27120 = _62getch();
    if (!IS_ATOM_INT(_fch_27120)) {
        _1 = (object)(DBL_PTR(_fch_27120)->dbl);
        DeRefDS(_fch_27120);
        _fch_27120 = _1;
    }

    /** scanner.e:1316				if fch = '"' then*/
    if (_fch_27120 != 34)
    goto LA; // [150] 177

    /** scanner.e:1317					fch = getch()*/
    _fch_27120 = _62getch();
    if (!IS_ATOM_INT(_fch_27120)) {
        _1 = (object)(DBL_PTR(_fch_27120)->dbl);
        DeRefDS(_fch_27120);
        _fch_27120 = _1;
    }

    /** scanner.e:1318					if fch = '"' then*/
    if (_fch_27120 != 34)
    goto LB; // [163] 172

    /** scanner.e:1319						exit*/
    goto L9; // [169] 312
LB: 

    /** scanner.e:1321					ungetch()*/
    _62ungetch();
LA: 

    /** scanner.e:1323				ungetch()*/
    _62ungetch();
L7: 

    /** scanner.e:1326			if ch != '\r' then*/
    if (_ch_27119 == 13)
    goto LC; // [184] 195

    /** scanner.e:1329				string_text &= ch*/
    Append(&_string_text_27122, _string_text_27122, _ch_27119);
LC: 

    /** scanner.e:1332			if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_50ThisLine_49238)){
            _14965 = SEQ_PTR(_50ThisLine_49238)->length;
    }
    else {
        _14965 = 1;
    }
    if (_50bp_49242 <= _14965)
    goto LD; // [204] 300

    /** scanner.e:1333				read_line() -- sets bp to 1, btw.*/
    _62read_line();

    /** scanner.e:1334				if trimming > 0 then*/
    if (_trimming_27123 <= 0)
    goto LE; // [214] 299

    /** scanner.e:1335					while bp <= trimming and bp <= length(ThisLine) do*/
LF: 
    _14968 = (_50bp_49242 <= _trimming_27123);
    if (_14968 == 0) {
        goto L10; // [229] 298
    }
    if (IS_SEQUENCE(_50ThisLine_49238)){
            _14970 = SEQ_PTR(_50ThisLine_49238)->length;
    }
    else {
        _14970 = 1;
    }
    _14971 = (_50bp_49242 <= _14970);
    _14970 = NOVALUE;
    if (_14971 == 0)
    {
        DeRef(_14971);
        _14971 = NOVALUE;
        goto L10; // [245] 298
    }
    else{
        DeRef(_14971);
        _14971 = NOVALUE;
    }

    /** scanner.e:1336						ch = ThisLine[bp]*/
    _2 = (object)SEQ_PTR(_50ThisLine_49238);
    _ch_27119 = (object)*(((s1_ptr)_2)->base + _50bp_49242);
    if (!IS_ATOM_INT(_ch_27119)){
        _ch_27119 = (object)DBL_PTR(_ch_27119)->dbl;
    }

    /** scanner.e:1337						if ch != ' ' and ch != '\t' then*/
    _14973 = (_ch_27119 != 32);
    if (_14973 == 0) {
        goto L11; // [266] 283
    }
    _14975 = (_ch_27119 != 9);
    if (_14975 == 0)
    {
        DeRef(_14975);
        _14975 = NOVALUE;
        goto L11; // [275] 283
    }
    else{
        DeRef(_14975);
        _14975 = NOVALUE;
    }

    /** scanner.e:1338							exit*/
    goto L10; // [280] 298
L11: 

    /** scanner.e:1340						bp += 1*/
    _50bp_49242 = _50bp_49242 + 1;

    /** scanner.e:1341					end while*/
    goto LF; // [295] 223
L10: 
LE: 
LD: 

    /** scanner.e:1344			ch = getch()*/
    _ch_27119 = _62getch();
    if (!IS_ATOM_INT(_ch_27119)) {
        _1 = (object)(DBL_PTR(_ch_27119)->dbl);
        DeRefDS(_ch_27119);
        _ch_27119 = _1;
    }

    /** scanner.e:1345		end while*/
    goto L5; // [309] 106
L9: 

    /** scanner.e:1346		if length(string_text) > 0 and string_text[1] = '\n' then*/
    if (IS_SEQUENCE(_string_text_27122)){
            _14978 = SEQ_PTR(_string_text_27122)->length;
    }
    else {
        _14978 = 1;
    }
    _14979 = (_14978 > 0);
    _14978 = NOVALUE;
    if (_14979 == 0) {
        goto L12; // [321] 391
    }
    _2 = (object)SEQ_PTR(_string_text_27122);
    _14981 = (object)*(((s1_ptr)_2)->base + 1);
    _14982 = (_14981 == 10);
    _14981 = NOVALUE;
    if (_14982 == 0)
    {
        DeRef(_14982);
        _14982 = NOVALUE;
        goto L12; // [334] 391
    }
    else{
        DeRef(_14982);
        _14982 = NOVALUE;
    }

    /** scanner.e:1347			string_text = string_text[2 .. $]*/
    if (IS_SEQUENCE(_string_text_27122)){
            _14983 = SEQ_PTR(_string_text_27122)->length;
    }
    else {
        _14983 = 1;
    }
    rhs_slice_target = (object_ptr)&_string_text_27122;
    RHS_Slice(_string_text_27122, 2, _14983);

    /** scanner.e:1348			if length(string_text) > 0 and string_text[$] = '\n' then*/
    if (IS_SEQUENCE(_string_text_27122)){
            _14985 = SEQ_PTR(_string_text_27122)->length;
    }
    else {
        _14985 = 1;
    }
    _14986 = (_14985 > 0);
    _14985 = NOVALUE;
    if (_14986 == 0) {
        goto L13; // [356] 390
    }
    if (IS_SEQUENCE(_string_text_27122)){
            _14988 = SEQ_PTR(_string_text_27122)->length;
    }
    else {
        _14988 = 1;
    }
    _2 = (object)SEQ_PTR(_string_text_27122);
    _14989 = (object)*(((s1_ptr)_2)->base + _14988);
    _14990 = (_14989 == 10);
    _14989 = NOVALUE;
    if (_14990 == 0)
    {
        DeRef(_14990);
        _14990 = NOVALUE;
        goto L13; // [372] 390
    }
    else{
        DeRef(_14990);
        _14990 = NOVALUE;
    }

    /** scanner.e:1349				string_text = string_text[1 .. $-1]*/
    if (IS_SEQUENCE(_string_text_27122)){
            _14991 = SEQ_PTR(_string_text_27122)->length;
    }
    else {
        _14991 = 1;
    }
    _14992 = _14991 - 1;
    _14991 = NOVALUE;
    rhs_slice_target = (object_ptr)&_string_text_27122;
    RHS_Slice(_string_text_27122, 1, _14992);
L13: 
L12: 

    /** scanner.e:1352		return {STRING, NewStringSym(string_text)}*/
    RefDS(_string_text_27122);
    _14994 = _54NewStringSym(_string_text_27122);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 503;
    ((intptr_t *)_2)[2] = _14994;
    _14995 = MAKE_SEQ(_1);
    _14994 = NOVALUE;
    DeRefDSi(_string_text_27122);
    DeRef(_14979);
    _14979 = NOVALUE;
    DeRef(_14992);
    _14992 = NOVALUE;
    DeRef(_14973);
    _14973 = NOVALUE;
    DeRef(_14968);
    _14968 = NOVALUE;
    DeRef(_14986);
    _14986 = NOVALUE;
    return _14995;
    ;
}


object _62GetHexString(object _maxnibbles_27210)
{
    object _ch_27211 = NOVALUE;
    object _digit_27212 = NOVALUE;
    object _val_27213 = NOVALUE;
    object _cline_27214 = NOVALUE;
    object _nibble_27215 = NOVALUE;
    object _string_text_27216 = NOVALUE;
    object _15009 = NOVALUE;
    object _15008 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1363		cline = line_number*/
    _cline_27214 = _36line_number_21448;

    /** scanner.e:1364		string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_27216);
    _string_text_27216 = _5;

    /** scanner.e:1365		nibble = 1*/
    _nibble_27215 = 1;

    /** scanner.e:1366		val = -1*/
    DeRef(_val_27213);
    _val_27213 = -1;

    /** scanner.e:1367		ch = getch()*/
    _ch_27211 = _62getch();
    if (!IS_ATOM_INT(_ch_27211)) {
        _1 = (object)(DBL_PTR(_ch_27211)->dbl);
        DeRefDS(_ch_27211);
        _ch_27211 = _1;
    }

    /** scanner.e:1368		while 1 do*/
L1: 

    /** scanner.e:1369			if ch = END_OF_FILE_CHAR then*/
    if (_ch_27211 != 26)
    goto L2; // [45] 59

    /** scanner.e:1370				CompileErr(RAW_STRING_LITERAL_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _50CompileErr(129, _cline_27214, 0);
L2: 

    /** scanner.e:1373			if ch = '"' then*/
    if (_ch_27211 != 34)
    goto L3; // [61] 70

    /** scanner.e:1374				exit*/
    goto L4; // [67] 228
L3: 

    /** scanner.e:1377			digit = find(ch, "0123456789ABCDEFabcdef_ \t\n\r")*/
    _digit_27212 = find_from(_ch_27211, _14999, 1);

    /** scanner.e:1378			if digit = 0 then*/
    if (_digit_27212 != 0)
    goto L5; // [79] 93

    /** scanner.e:1379				CompileErr(INVALID_CHARACTER_IN_HEX_STRING)*/
    RefDS(_21997);
    _50CompileErr(329, _21997, 0);
L5: 

    /** scanner.e:1381			if digit <= 23 then*/
    if (_digit_27212 > 23)
    goto L6; // [95] 181

    /** scanner.e:1382				if digit != 23 then*/
    if (_digit_27212 == 23)
    goto L7; // [101] 216

    /** scanner.e:1383					if digit > 16 then*/
    if (_digit_27212 <= 16)
    goto L8; // [107] 118

    /** scanner.e:1384						digit -= 6*/
    _digit_27212 = _digit_27212 - 6;
L8: 

    /** scanner.e:1386					if nibble = 1 then*/
    if (_nibble_27215 != 1)
    goto L9; // [120] 133

    /** scanner.e:1387						val = digit - 1*/
    DeRef(_val_27213);
    _val_27213 = _digit_27212 - 1;
    if ((object)((uintptr_t)_val_27213 +(uintptr_t) HIGH_BITS) >= 0){
        _val_27213 = NewDouble((eudouble)_val_27213);
    }
    goto LA; // [130] 171
L9: 

    /** scanner.e:1389						val = val * 16 + digit - 1*/
    if (IS_ATOM_INT(_val_27213)) {
        if (_val_27213 == (short)_val_27213){
            _15008 = _val_27213 * 16;
        }
        else{
            _15008 = NewDouble(_val_27213 * (eudouble)16);
        }
    }
    else {
        _15008 = NewDouble(DBL_PTR(_val_27213)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_15008)) {
        _15009 = _15008 + _digit_27212;
        if ((object)((uintptr_t)_15009 + (uintptr_t)HIGH_BITS) >= 0){
            _15009 = NewDouble((eudouble)_15009);
        }
    }
    else {
        _15009 = NewDouble(DBL_PTR(_15008)->dbl + (eudouble)_digit_27212);
    }
    DeRef(_15008);
    _15008 = NOVALUE;
    DeRef(_val_27213);
    if (IS_ATOM_INT(_15009)) {
        _val_27213 = _15009 - 1;
        if ((object)((uintptr_t)_val_27213 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27213 = NewDouble((eudouble)_val_27213);
        }
    }
    else {
        _val_27213 = NewDouble(DBL_PTR(_15009)->dbl - (eudouble)1);
    }
    DeRef(_15009);
    _15009 = NOVALUE;

    /** scanner.e:1390						if nibble = maxnibbles then*/
    if (_nibble_27215 != _maxnibbles_27210)
    goto LB; // [149] 170

    /** scanner.e:1391							string_text &= val*/
    Ref(_val_27213);
    Append(&_string_text_27216, _string_text_27216, _val_27213);

    /** scanner.e:1392							val = -1*/
    DeRef(_val_27213);
    _val_27213 = -1;

    /** scanner.e:1393							nibble = 0*/
    _nibble_27215 = 0;
LB: 
LA: 

    /** scanner.e:1396					nibble += 1*/
    _nibble_27215 = _nibble_27215 + 1;
    goto L7; // [178] 216
L6: 

    /** scanner.e:1399				if val >= 0 then*/
    if (binary_op_a(LESS, _val_27213, 0)){
        goto LC; // [183] 199
    }

    /** scanner.e:1401					string_text &= val*/
    Ref(_val_27213);
    Append(&_string_text_27216, _string_text_27216, _val_27213);

    /** scanner.e:1402					val = -1*/
    DeRef(_val_27213);
    _val_27213 = -1;
LC: 

    /** scanner.e:1404				nibble = 1*/
    _nibble_27215 = 1;

    /** scanner.e:1405				if ch = '\n' then*/
    if (_ch_27211 != 10)
    goto LD; // [206] 215

    /** scanner.e:1406					read_line()*/
    _62read_line();
LD: 
L7: 

    /** scanner.e:1409			ch = getch()*/
    _ch_27211 = _62getch();
    if (!IS_ATOM_INT(_ch_27211)) {
        _1 = (object)(DBL_PTR(_ch_27211)->dbl);
        DeRefDS(_ch_27211);
        _ch_27211 = _1;
    }

    /** scanner.e:1410		end while*/
    goto L1; // [225] 41
L4: 

    /** scanner.e:1412		if val >= 0 then	*/
    if (binary_op_a(LESS, _val_27213, 0)){
        goto LE; // [230] 241
    }

    /** scanner.e:1414			string_text &= val*/
    Ref(_val_27213);
    Append(&_string_text_27216, _string_text_27216, _val_27213);
LE: 

    /** scanner.e:1417		return string_text*/
    DeRef(_val_27213);
    return _string_text_27216;
    ;
}


object _62GetBitString()
{
    object _ch_27263 = NOVALUE;
    object _digit_27264 = NOVALUE;
    object _val_27265 = NOVALUE;
    object _cline_27266 = NOVALUE;
    object _bitcnt_27267 = NOVALUE;
    object _string_text_27268 = NOVALUE;
    object _15031 = NOVALUE;
    object _15030 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1428		cline = line_number*/
    _cline_27266 = _36line_number_21448;

    /** scanner.e:1429		string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_27268);
    _string_text_27268 = _5;

    /** scanner.e:1430		bitcnt = 1*/
    _bitcnt_27267 = 1;

    /** scanner.e:1431		val = -1*/
    DeRef(_val_27265);
    _val_27265 = -1;

    /** scanner.e:1432		ch = getch()*/
    _ch_27263 = _62getch();
    if (!IS_ATOM_INT(_ch_27263)) {
        _1 = (object)(DBL_PTR(_ch_27263)->dbl);
        DeRefDS(_ch_27263);
        _ch_27263 = _1;
    }

    /** scanner.e:1433		while 1 do*/
L1: 

    /** scanner.e:1434			if ch = END_OF_FILE_CHAR then*/
    if (_ch_27263 != 26)
    goto L2; // [43] 57

    /** scanner.e:1435				CompileErr(RAW_STRING_LITERAL_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _50CompileErr(129, _cline_27266, 0);
L2: 

    /** scanner.e:1438			if ch = '"' then*/
    if (_ch_27263 != 34)
    goto L3; // [59] 68

    /** scanner.e:1439				exit*/
    goto L4; // [65] 190
L3: 

    /** scanner.e:1442			digit = find(ch, "01_ \t\n\r")*/
    _digit_27264 = find_from(_ch_27263, _15023, 1);

    /** scanner.e:1443			if digit = 0 then*/
    if (_digit_27264 != 0)
    goto L5; // [77] 91

    /** scanner.e:1444				CompileErr(INVALID_CHARACTER_IN_HEX_STRING)*/
    RefDS(_21997);
    _50CompileErr(329, _21997, 0);
L5: 

    /** scanner.e:1446			if digit <= 3 then*/
    if (_digit_27264 > 3)
    goto L6; // [93] 143

    /** scanner.e:1447				if digit != 3 then*/
    if (_digit_27264 == 3)
    goto L7; // [99] 178

    /** scanner.e:1448					if bitcnt = 1 then*/
    if (_bitcnt_27267 != 1)
    goto L8; // [105] 118

    /** scanner.e:1449						val = digit - 1*/
    DeRef(_val_27265);
    _val_27265 = _digit_27264 - 1;
    if ((object)((uintptr_t)_val_27265 +(uintptr_t) HIGH_BITS) >= 0){
        _val_27265 = NewDouble((eudouble)_val_27265);
    }
    goto L9; // [115] 133
L8: 

    /** scanner.e:1451						val = val * 2 + digit - 1*/
    if (IS_ATOM_INT(_val_27265) && IS_ATOM_INT(_val_27265)) {
        _15030 = _val_27265 + _val_27265;
        if ((object)((uintptr_t)_15030 + (uintptr_t)HIGH_BITS) >= 0){
            _15030 = NewDouble((eudouble)_15030);
        }
    }
    else {
        if (IS_ATOM_INT(_val_27265)) {
            _15030 = NewDouble((eudouble)_val_27265 + DBL_PTR(_val_27265)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_27265)) {
                _15030 = NewDouble(DBL_PTR(_val_27265)->dbl + (eudouble)_val_27265);
            }
            else
            _15030 = NewDouble(DBL_PTR(_val_27265)->dbl + DBL_PTR(_val_27265)->dbl);
        }
    }
    if (IS_ATOM_INT(_15030)) {
        _15031 = _15030 + _digit_27264;
        if ((object)((uintptr_t)_15031 + (uintptr_t)HIGH_BITS) >= 0){
            _15031 = NewDouble((eudouble)_15031);
        }
    }
    else {
        _15031 = NewDouble(DBL_PTR(_15030)->dbl + (eudouble)_digit_27264);
    }
    DeRef(_15030);
    _15030 = NOVALUE;
    DeRef(_val_27265);
    if (IS_ATOM_INT(_15031)) {
        _val_27265 = _15031 - 1;
        if ((object)((uintptr_t)_val_27265 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27265 = NewDouble((eudouble)_val_27265);
        }
    }
    else {
        _val_27265 = NewDouble(DBL_PTR(_15031)->dbl - (eudouble)1);
    }
    DeRef(_15031);
    _15031 = NOVALUE;
L9: 

    /** scanner.e:1453					bitcnt += 1*/
    _bitcnt_27267 = _bitcnt_27267 + 1;
    goto L7; // [140] 178
L6: 

    /** scanner.e:1456				if val >= 0 then*/
    if (binary_op_a(LESS, _val_27265, 0)){
        goto LA; // [145] 161
    }

    /** scanner.e:1458					string_text &= val*/
    Ref(_val_27265);
    Append(&_string_text_27268, _string_text_27268, _val_27265);

    /** scanner.e:1459					val = -1*/
    DeRef(_val_27265);
    _val_27265 = -1;
LA: 

    /** scanner.e:1461				bitcnt = 1*/
    _bitcnt_27267 = 1;

    /** scanner.e:1462				if ch = '\n' then*/
    if (_ch_27263 != 10)
    goto LB; // [168] 177

    /** scanner.e:1463					read_line()*/
    _62read_line();
LB: 
L7: 

    /** scanner.e:1466			ch = getch()*/
    _ch_27263 = _62getch();
    if (!IS_ATOM_INT(_ch_27263)) {
        _1 = (object)(DBL_PTR(_ch_27263)->dbl);
        DeRefDS(_ch_27263);
        _ch_27263 = _1;
    }

    /** scanner.e:1467		end while*/
    goto L1; // [187] 39
L4: 

    /** scanner.e:1469		if val >= 0 then	*/
    if (binary_op_a(LESS, _val_27265, 0)){
        goto LC; // [192] 203
    }

    /** scanner.e:1471			string_text &= val*/
    Ref(_val_27265);
    Append(&_string_text_27268, _string_text_27268, _val_27265);
LC: 

    /** scanner.e:1474		return string_text*/
    DeRef(_val_27265);
    return _string_text_27268;
    ;
}


object _62Scanner()
{
    object _fwd_inlined_set_qualified_fwd_at_441_27408 = NOVALUE;
    object _ch_27309 = NOVALUE;
    object _sp_27310 = NOVALUE;
    object _prev_Nne_27311 = NOVALUE;
    object _i_27312 = NOVALUE;
    object _pch_27313 = NOVALUE;
    object _cline_27314 = NOVALUE;
    object _yytext_27315 = NOVALUE;
    object _namespaces_27316 = NOVALUE;
    object _d_27317 = NOVALUE;
    object _tok_27319 = NOVALUE;
    object _is_int_27320 = NOVALUE;
    object _class_27321 = NOVALUE;
    object _name_27322 = NOVALUE;
    object _is_namespace_27381 = NOVALUE;
    object _basetype_27617 = NOVALUE;
    object _hdigit_27658 = NOVALUE;
    object _fch_27798 = NOVALUE;
    object _cnest_27982 = NOVALUE;
    object _ach_28012 = NOVALUE;
    object _31721 = NOVALUE;
    object _31720 = NOVALUE;
    object _31719 = NOVALUE;
    object _31718 = NOVALUE;
    object _31717 = NOVALUE;
    object _31716 = NOVALUE;
    object _31715 = NOVALUE;
    object _15424 = NOVALUE;
    object _15423 = NOVALUE;
    object _15421 = NOVALUE;
    object _15419 = NOVALUE;
    object _15418 = NOVALUE;
    object _15417 = NOVALUE;
    object _15415 = NOVALUE;
    object _15414 = NOVALUE;
    object _15413 = NOVALUE;
    object _15412 = NOVALUE;
    object _15410 = NOVALUE;
    object _15409 = NOVALUE;
    object _15407 = NOVALUE;
    object _15405 = NOVALUE;
    object _15404 = NOVALUE;
    object _15402 = NOVALUE;
    object _15400 = NOVALUE;
    object _15399 = NOVALUE;
    object _15397 = NOVALUE;
    object _15395 = NOVALUE;
    object _15394 = NOVALUE;
    object _15393 = NOVALUE;
    object _15392 = NOVALUE;
    object _15391 = NOVALUE;
    object _15389 = NOVALUE;
    object _15388 = NOVALUE;
    object _15378 = NOVALUE;
    object _15365 = NOVALUE;
    object _15361 = NOVALUE;
    object _15360 = NOVALUE;
    object _15356 = NOVALUE;
    object _15355 = NOVALUE;
    object _15354 = NOVALUE;
    object _15353 = NOVALUE;
    object _15351 = NOVALUE;
    object _15350 = NOVALUE;
    object _15349 = NOVALUE;
    object _15348 = NOVALUE;
    object _15345 = NOVALUE;
    object _15344 = NOVALUE;
    object _15343 = NOVALUE;
    object _15342 = NOVALUE;
    object _15341 = NOVALUE;
    object _15340 = NOVALUE;
    object _15338 = NOVALUE;
    object _15337 = NOVALUE;
    object _15336 = NOVALUE;
    object _15335 = NOVALUE;
    object _15334 = NOVALUE;
    object _15333 = NOVALUE;
    object _15331 = NOVALUE;
    object _15330 = NOVALUE;
    object _15327 = NOVALUE;
    object _15324 = NOVALUE;
    object _15319 = NOVALUE;
    object _15318 = NOVALUE;
    object _15317 = NOVALUE;
    object _15316 = NOVALUE;
    object _15315 = NOVALUE;
    object _15314 = NOVALUE;
    object _15312 = NOVALUE;
    object _15311 = NOVALUE;
    object _15310 = NOVALUE;
    object _15309 = NOVALUE;
    object _15308 = NOVALUE;
    object _15307 = NOVALUE;
    object _15305 = NOVALUE;
    object _15304 = NOVALUE;
    object _15301 = NOVALUE;
    object _15298 = NOVALUE;
    object _15296 = NOVALUE;
    object _15295 = NOVALUE;
    object _15291 = NOVALUE;
    object _15290 = NOVALUE;
    object _15286 = NOVALUE;
    object _15285 = NOVALUE;
    object _15284 = NOVALUE;
    object _15282 = NOVALUE;
    object _15277 = NOVALUE;
    object _15274 = NOVALUE;
    object _15273 = NOVALUE;
    object _15272 = NOVALUE;
    object _15271 = NOVALUE;
    object _15265 = NOVALUE;
    object _15263 = NOVALUE;
    object _15258 = NOVALUE;
    object _15257 = NOVALUE;
    object _15256 = NOVALUE;
    object _15255 = NOVALUE;
    object _15254 = NOVALUE;
    object _15253 = NOVALUE;
    object _15252 = NOVALUE;
    object _15250 = NOVALUE;
    object _15248 = NOVALUE;
    object _15247 = NOVALUE;
    object _15246 = NOVALUE;
    object _15245 = NOVALUE;
    object _15244 = NOVALUE;
    object _15242 = NOVALUE;
    object _15237 = NOVALUE;
    object _15236 = NOVALUE;
    object _15234 = NOVALUE;
    object _15230 = NOVALUE;
    object _15227 = NOVALUE;
    object _15226 = NOVALUE;
    object _15224 = NOVALUE;
    object _15223 = NOVALUE;
    object _15222 = NOVALUE;
    object _15219 = NOVALUE;
    object _15217 = NOVALUE;
    object _15216 = NOVALUE;
    object _15212 = NOVALUE;
    object _15208 = NOVALUE;
    object _15205 = NOVALUE;
    object _15199 = NOVALUE;
    object _15191 = NOVALUE;
    object _15190 = NOVALUE;
    object _15189 = NOVALUE;
    object _15187 = NOVALUE;
    object _15184 = NOVALUE;
    object _15182 = NOVALUE;
    object _15180 = NOVALUE;
    object _15177 = NOVALUE;
    object _15174 = NOVALUE;
    object _15172 = NOVALUE;
    object _15170 = NOVALUE;
    object _15168 = NOVALUE;
    object _15167 = NOVALUE;
    object _15163 = NOVALUE;
    object _15160 = NOVALUE;
    object _15158 = NOVALUE;
    object _15155 = NOVALUE;
    object _15148 = NOVALUE;
    object _15146 = NOVALUE;
    object _15143 = NOVALUE;
    object _15137 = NOVALUE;
    object _15136 = NOVALUE;
    object _15135 = NOVALUE;
    object _15134 = NOVALUE;
    object _15133 = NOVALUE;
    object _15132 = NOVALUE;
    object _15131 = NOVALUE;
    object _15129 = NOVALUE;
    object _15127 = NOVALUE;
    object _15125 = NOVALUE;
    object _15123 = NOVALUE;
    object _15121 = NOVALUE;
    object _15120 = NOVALUE;
    object _15119 = NOVALUE;
    object _15118 = NOVALUE;
    object _15117 = NOVALUE;
    object _15115 = NOVALUE;
    object _15112 = NOVALUE;
    object _15110 = NOVALUE;
    object _15109 = NOVALUE;
    object _15108 = NOVALUE;
    object _15106 = NOVALUE;
    object _15101 = NOVALUE;
    object _15097 = NOVALUE;
    object _15094 = NOVALUE;
    object _15092 = NOVALUE;
    object _15091 = NOVALUE;
    object _15089 = NOVALUE;
    object _15087 = NOVALUE;
    object _15085 = NOVALUE;
    object _15084 = NOVALUE;
    object _15083 = NOVALUE;
    object _15081 = NOVALUE;
    object _15076 = NOVALUE;
    object _15073 = NOVALUE;
    object _15071 = NOVALUE;
    object _15068 = NOVALUE;
    object _15067 = NOVALUE;
    object _15065 = NOVALUE;
    object _15064 = NOVALUE;
    object _15063 = NOVALUE;
    object _15062 = NOVALUE;
    object _15061 = NOVALUE;
    object _15060 = NOVALUE;
    object _15059 = NOVALUE;
    object _15058 = NOVALUE;
    object _15057 = NOVALUE;
    object _15056 = NOVALUE;
    object _15055 = NOVALUE;
    object _15054 = NOVALUE;
    object _15053 = NOVALUE;
    object _15048 = NOVALUE;
    object _15046 = NOVALUE;
    object _15043 = NOVALUE;
    object _15041 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1486		integer is_int, class*/

    /** scanner.e:1487		sequence name*/

    /** scanner.e:1489		while TRUE do*/
L1: 
    if (_13TRUE_452 == 0)
    {
        goto L2; // [12] 3821
    }
    else{
    }

    /** scanner.e:1490			ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1491			while ch = ' ' or ch = '\t' do*/
L3: 
    _15041 = (_ch_27309 == 32);
    if (_15041 != 0) {
        goto L4; // [31] 44
    }
    _15043 = (_ch_27309 == 9);
    if (_15043 == 0)
    {
        DeRef(_15043);
        _15043 = NOVALUE;
        goto L5; // [40] 56
    }
    else{
        DeRef(_15043);
        _15043 = NOVALUE;
    }
L4: 

    /** scanner.e:1492				ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1493			end while*/
    goto L3; // [53] 27
L5: 

    /** scanner.e:1495			class = char_class[ch]*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _class_27321 = (object)*(((s1_ptr)_2)->base + _ch_27309);

    /** scanner.e:1498			if class = LETTER or ch = '_' then*/
    _15046 = (_class_27321 == -2);
    if (_15046 != 0) {
        goto L6; // [72] 85
    }
    _15048 = (_ch_27309 == 95);
    if (_15048 == 0)
    {
        DeRef(_15048);
        _15048 = NOVALUE;
        goto L7; // [81] 1284
    }
    else{
        DeRef(_15048);
        _15048 = NOVALUE;
    }
L6: 

    /** scanner.e:1499				sp = bp*/
    _sp_27310 = _50bp_49242;

    /** scanner.e:1500				pch = ch*/
    _pch_27313 = _ch_27309;

    /** scanner.e:1501				ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1502				if ch = '"' then*/
    if (_ch_27309 != 34)
    goto L8; // [108] 222

    /** scanner.e:1503					switch pch do*/
    _0 = _pch_27313;
    switch ( _0 ){ 

        /** scanner.e:1504						case 'x' then*/
        case 120:

        /** scanner.e:1505							return {STRING, NewStringSym(GetHexString(2))}*/
        _15053 = _62GetHexString(2);
        _15054 = _54NewStringSym(_15053);
        _15053 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503;
        ((intptr_t *)_2)[2] = _15054;
        _15055 = MAKE_SEQ(_1);
        _15054 = NOVALUE;
        DeRef(_i_27312);
        DeRef(_yytext_27315);
        DeRef(_namespaces_27316);
        DeRef(_d_27317);
        DeRef(_tok_27319);
        DeRef(_name_27322);
        DeRef(_15046);
        _15046 = NOVALUE;
        DeRef(_15041);
        _15041 = NOVALUE;
        return _15055;
        goto L9; // [143] 221

        /** scanner.e:1507						case 'u' then*/
        case 117:

        /** scanner.e:1508							return {STRING, NewStringSym(GetHexString(4))}*/
        _15056 = _62GetHexString(4);
        _15057 = _54NewStringSym(_15056);
        _15056 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503;
        ((intptr_t *)_2)[2] = _15057;
        _15058 = MAKE_SEQ(_1);
        _15057 = NOVALUE;
        DeRef(_i_27312);
        DeRef(_yytext_27315);
        DeRef(_namespaces_27316);
        DeRef(_d_27317);
        DeRef(_tok_27319);
        DeRef(_name_27322);
        DeRef(_15046);
        _15046 = NOVALUE;
        DeRef(_15041);
        _15041 = NOVALUE;
        DeRef(_15055);
        _15055 = NOVALUE;
        return _15058;
        goto L9; // [169] 221

        /** scanner.e:1510						case 'U' then*/
        case 85:

        /** scanner.e:1511							return {STRING, NewStringSym(GetHexString(8))}*/
        _15059 = _62GetHexString(8);
        _15060 = _54NewStringSym(_15059);
        _15059 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503;
        ((intptr_t *)_2)[2] = _15060;
        _15061 = MAKE_SEQ(_1);
        _15060 = NOVALUE;
        DeRef(_i_27312);
        DeRef(_yytext_27315);
        DeRef(_namespaces_27316);
        DeRef(_d_27317);
        DeRef(_tok_27319);
        DeRef(_name_27322);
        DeRef(_15058);
        _15058 = NOVALUE;
        DeRef(_15046);
        _15046 = NOVALUE;
        DeRef(_15041);
        _15041 = NOVALUE;
        DeRef(_15055);
        _15055 = NOVALUE;
        return _15061;
        goto L9; // [195] 221

        /** scanner.e:1513						case 'b' then*/
        case 98:

        /** scanner.e:1514							return {STRING, NewStringSym(GetBitString())}*/
        _15062 = _62GetBitString();
        _15063 = _54NewStringSym(_15062);
        _15062 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503;
        ((intptr_t *)_2)[2] = _15063;
        _15064 = MAKE_SEQ(_1);
        _15063 = NOVALUE;
        DeRef(_i_27312);
        DeRef(_yytext_27315);
        DeRef(_namespaces_27316);
        DeRef(_d_27317);
        DeRef(_tok_27319);
        DeRef(_name_27322);
        DeRef(_15058);
        _15058 = NOVALUE;
        DeRef(_15046);
        _15046 = NOVALUE;
        DeRef(_15041);
        _15041 = NOVALUE;
        DeRef(_15061);
        _15061 = NOVALUE;
        DeRef(_15055);
        _15055 = NOVALUE;
        return _15064;
    ;}L9: 
L8: 

    /** scanner.e:1519				while id_char[ch] do*/
LA: 
    _2 = (object)SEQ_PTR(_62id_char_25561);
    _15065 = (object)*(((s1_ptr)_2)->base + _ch_27309);
    if (_15065 == 0)
    {
        _15065 = NOVALUE;
        goto LB; // [233] 248
    }
    else{
        _15065 = NOVALUE;
    }

    /** scanner.e:1520					ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1521				end while*/
    goto LA; // [245] 227
LB: 

    /** scanner.e:1522				yytext = ThisLine[sp-1..bp-2]*/
    _15067 = _sp_27310 - 1;
    if ((object)((uintptr_t)_15067 +(uintptr_t) HIGH_BITS) >= 0){
        _15067 = NewDouble((eudouble)_15067);
    }
    _15068 = _50bp_49242 - 2;
    rhs_slice_target = (object_ptr)&_yytext_27315;
    RHS_Slice(_50ThisLine_49238, _15067, _15068);

    /** scanner.e:1523				ungetch()*/
    _62ungetch();

    /** scanner.e:1525				ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1526				while ch = ' ' or ch = '\t' do*/
LC: 
    _15071 = (_ch_27309 == 32);
    if (_15071 != 0) {
        goto LD; // [287] 300
    }
    _15073 = (_ch_27309 == 9);
    if (_15073 == 0)
    {
        DeRef(_15073);
        _15073 = NOVALUE;
        goto LE; // [296] 312
    }
    else{
        DeRef(_15073);
        _15073 = NOVALUE;
    }
LD: 

    /** scanner.e:1527					ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1528				end while*/
    goto LC; // [309] 283
LE: 

    /** scanner.e:1529				integer is_namespace*/

    /** scanner.e:1531				if might_be_namespace then*/
    if (_62might_be_namespace_27108 == 0)
    {
        goto LF; // [318] 361
    }
    else{
    }

    /** scanner.e:1532					tok = keyfind(yytext, -1, , -1 )*/
    RefDS(_yytext_27315);
    _31721 = _54hashfn(_yytext_27315);
    RefDS(_yytext_27315);
    _0 = _tok_27319;
    _tok_27319 = _54keyfind(_yytext_27315, -1, _36current_file_no_21447, -1, _31721);
    DeRef(_0);
    _31721 = NOVALUE;

    /** scanner.e:1533					is_namespace = tok[T_ID] = NAMESPACE*/
    _2 = (object)SEQ_PTR(_tok_27319);
    _15076 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_15076)) {
        _is_namespace_27381 = (_15076 == 523);
    }
    else {
        _is_namespace_27381 = binary_op(EQUALS, _15076, 523);
    }
    _15076 = NOVALUE;
    if (!IS_ATOM_INT(_is_namespace_27381)) {
        _1 = (object)(DBL_PTR(_is_namespace_27381)->dbl);
        DeRefDS(_is_namespace_27381);
        _is_namespace_27381 = _1;
    }

    /** scanner.e:1534					might_be_namespace = 0*/
    _62might_be_namespace_27108 = 0;
    goto L10; // [358] 384
LF: 

    /** scanner.e:1536					is_namespace = ch = ':'*/
    _is_namespace_27381 = (_ch_27309 == 58);

    /** scanner.e:1537					tok = keyfind(yytext, -1, , is_namespace )*/
    RefDS(_yytext_27315);
    _31720 = _54hashfn(_yytext_27315);
    RefDS(_yytext_27315);
    _0 = _tok_27319;
    _tok_27319 = _54keyfind(_yytext_27315, -1, _36current_file_no_21447, _is_namespace_27381, _31720);
    DeRef(_0);
    _31720 = NOVALUE;
L10: 

    /** scanner.e:1541				if not is_namespace then*/
    if (_is_namespace_27381 != 0)
    goto L11; // [388] 396

    /** scanner.e:1542					ungetch()*/
    _62ungetch();
L11: 

    /** scanner.e:1545				if is_namespace then*/
    if (_is_namespace_27381 == 0)
    {
        goto L12; // [398] 1121
    }
    else{
    }

    /** scanner.e:1547					namespaces = yytext*/
    RefDS(_yytext_27315);
    DeRef(_namespaces_27316);
    _namespaces_27316 = _yytext_27315;

    /** scanner.e:1550					if tok[T_ID] = NAMESPACE then -- known namespace*/
    _2 = (object)SEQ_PTR(_tok_27319);
    _15081 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15081, 523)){
        _15081 = NOVALUE;
        goto L13; // [420] 976
    }
    _15081 = NOVALUE;

    /** scanner.e:1551						set_qualified_fwd( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (object)SEQ_PTR(_tok_27319);
    _15083 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_15083)){
        _15084 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15083)->dbl));
    }
    else{
        _15084 = (object)*(((s1_ptr)_2)->base + _15083);
    }
    _2 = (object)SEQ_PTR(_15084);
    _15085 = (object)*(((s1_ptr)_2)->base + 1);
    _15084 = NOVALUE;
    Ref(_15085);
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_27408);
    _fwd_inlined_set_qualified_fwd_at_441_27408 = _15085;
    _15085 = NOVALUE;
    if (!IS_ATOM_INT(_fwd_inlined_set_qualified_fwd_at_441_27408)) {
        _1 = (object)(DBL_PTR(_fwd_inlined_set_qualified_fwd_at_441_27408)->dbl);
        DeRefDS(_fwd_inlined_set_qualified_fwd_at_441_27408);
        _fwd_inlined_set_qualified_fwd_at_441_27408 = _1;
    }

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25585 = _fwd_inlined_set_qualified_fwd_at_441_27408;

    /** scanner.e:105	end procedure*/
    goto L14; // [456] 459
L14: 
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_27408);
    _fwd_inlined_set_qualified_fwd_at_441_27408 = NOVALUE;

    /** scanner.e:1554						ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1555						while ch = ' ' or ch = '\t' do*/
L15: 
    _15087 = (_ch_27309 == 32);
    if (_15087 != 0) {
        goto L16; // [477] 490
    }
    _15089 = (_ch_27309 == 9);
    if (_15089 == 0)
    {
        DeRef(_15089);
        _15089 = NOVALUE;
        goto L17; // [486] 502
    }
    else{
        DeRef(_15089);
        _15089 = NOVALUE;
    }
L16: 

    /** scanner.e:1556							ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1557						end while*/
    goto L15; // [499] 473
L17: 

    /** scanner.e:1558						yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_27315);
    _yytext_27315 = _5;

    /** scanner.e:1559						if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _15091 = (object)*(((s1_ptr)_2)->base + _ch_27309);
    _15092 = (_15091 == -2);
    _15091 = NOVALUE;
    if (_15092 != 0) {
        goto L18; // [523] 536
    }
    _15094 = (_ch_27309 == 95);
    if (_15094 == 0)
    {
        DeRef(_15094);
        _15094 = NOVALUE;
        goto L19; // [532] 589
    }
    else{
        DeRef(_15094);
        _15094 = NOVALUE;
    }
L18: 

    /** scanner.e:1560							yytext &= ch*/
    Append(&_yytext_27315, _yytext_27315, _ch_27309);

    /** scanner.e:1561							ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1562							while id_char[ch] = TRUE do*/
L1A: 
    _2 = (object)SEQ_PTR(_62id_char_25561);
    _15097 = (object)*(((s1_ptr)_2)->base + _ch_27309);
    if (_15097 != _13TRUE_452)
    goto L1B; // [562] 584

    /** scanner.e:1563								yytext &= ch*/
    Append(&_yytext_27315, _yytext_27315, _ch_27309);

    /** scanner.e:1564								ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1565							end while*/
    goto L1A; // [581] 554
L1B: 

    /** scanner.e:1566							ungetch()*/
    _62ungetch();
L19: 

    /** scanner.e:1569						if length(yytext) = 0 then*/
    if (IS_SEQUENCE(_yytext_27315)){
            _15101 = SEQ_PTR(_yytext_27315)->length;
    }
    else {
        _15101 = 1;
    }
    if (_15101 != 0)
    goto L1C; // [594] 608

    /** scanner.e:1570							CompileErr(AN_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_21997);
    _50CompileErr(32, _21997, 0);
L1C: 

    /** scanner.e:1576					    if Parser_mode = PAM_RECORD then*/
    if (_36Parser_mode_21556 != 1)
    goto L1D; // [614] 775

    /** scanner.e:1577			                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_27315);
    Append(&_36Recorded_21557, _36Recorded_21557, _yytext_27315);

    /** scanner.e:1578			                Ns_recorded = append(Ns_recorded,namespaces)*/
    RefDS(_namespaces_27316);
    Append(&_36Ns_recorded_21558, _36Ns_recorded_21558, _namespaces_27316);

    /** scanner.e:1579			                Ns_recorded_sym &= tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_27319);
    _15106 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_36Ns_recorded_sym_21560) && IS_ATOM(_15106)) {
        Ref(_15106);
        Append(&_36Ns_recorded_sym_21560, _36Ns_recorded_sym_21560, _15106);
    }
    else if (IS_ATOM(_36Ns_recorded_sym_21560) && IS_SEQUENCE(_15106)) {
    }
    else {
        Concat((object_ptr)&_36Ns_recorded_sym_21560, _36Ns_recorded_sym_21560, _15106);
    }
    _15106 = NOVALUE;

    /** scanner.e:1580			                prev_Nne = No_new_entry*/
    _prev_Nne_27311 = _54No_new_entry_47978;

    /** scanner.e:1581							No_new_entry = 1*/
    _54No_new_entry_47978 = 1;

    /** scanner.e:1582							tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (object)SEQ_PTR(_tok_27319);
    _15108 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_15108)){
        _15109 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15108)->dbl));
    }
    else{
        _15109 = (object)*(((s1_ptr)_2)->base + _15108);
    }
    _2 = (object)SEQ_PTR(_15109);
    _15110 = (object)*(((s1_ptr)_2)->base + 1);
    _15109 = NOVALUE;
    RefDS(_yytext_27315);
    _31719 = _54hashfn(_yytext_27315);
    RefDS(_yytext_27315);
    Ref(_15110);
    _0 = _tok_27319;
    _tok_27319 = _54keyfind(_yytext_27315, _15110, _36current_file_no_21447, 0, _31719);
    DeRef(_0);
    _15110 = NOVALUE;
    _31719 = NOVALUE;

    /** scanner.e:1583							if tok[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_27319);
    _15112 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15112, 509)){
        _15112 = NOVALUE;
        goto L1E; // [714] 731
    }
    _15112 = NOVALUE;

    /** scanner.e:1584								Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_36Recorded_sym_21559, _36Recorded_sym_21559, 0);
    goto L1F; // [728] 748
L1E: 

    /** scanner.e:1586								Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (object)SEQ_PTR(_tok_27319);
    _15115 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_36Recorded_sym_21559) && IS_ATOM(_15115)) {
        Ref(_15115);
        Append(&_36Recorded_sym_21559, _36Recorded_sym_21559, _15115);
    }
    else if (IS_ATOM(_36Recorded_sym_21559) && IS_SEQUENCE(_15115)) {
    }
    else {
        Concat((object_ptr)&_36Recorded_sym_21559, _36Recorded_sym_21559, _15115);
    }
    _15115 = NOVALUE;
L1F: 

    /** scanner.e:1588			                No_new_entry = prev_Nne*/
    _54No_new_entry_47978 = _prev_Nne_27311;

    /** scanner.e:1589			                return {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_36Recorded_21557)){
            _15117 = SEQ_PTR(_36Recorded_21557)->length;
    }
    else {
        _15117 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508;
    ((intptr_t *)_2)[2] = _15117;
    _15118 = MAKE_SEQ(_1);
    _15117 = NOVALUE;
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    return _15118;
    goto L20; // [772] 917
L1D: 

    /** scanner.e:1591							tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (object)SEQ_PTR(_tok_27319);
    _15119 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_15119)){
        _15120 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15119)->dbl));
    }
    else{
        _15120 = (object)*(((s1_ptr)_2)->base + _15119);
    }
    _2 = (object)SEQ_PTR(_15120);
    _15121 = (object)*(((s1_ptr)_2)->base + 1);
    _15120 = NOVALUE;
    RefDS(_yytext_27315);
    _31718 = _54hashfn(_yytext_27315);
    RefDS(_yytext_27315);
    Ref(_15121);
    _0 = _tok_27319;
    _tok_27319 = _54keyfind(_yytext_27315, _15121, _36current_file_no_21447, 0, _31718);
    DeRef(_0);
    _15121 = NOVALUE;
    _31718 = NOVALUE;

    /** scanner.e:1593							if tok[T_ID] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_27319);
    _15123 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15123, -100)){
        _15123 = NOVALUE;
        goto L21; // [819] 836
    }
    _15123 = NOVALUE;

    /** scanner.e:1594								tok[T_ID] = QUALIFIED_VARIABLE*/
    _2 = (object)SEQ_PTR(_tok_27319);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27319 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 512;
    DeRef(_1);
    goto L22; // [833] 916
L21: 

    /** scanner.e:1595							elsif tok[T_ID] = FUNC then*/
    _2 = (object)SEQ_PTR(_tok_27319);
    _15125 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15125, 501)){
        _15125 = NOVALUE;
        goto L23; // [846] 863
    }
    _15125 = NOVALUE;

    /** scanner.e:1596								tok[T_ID] = QUALIFIED_FUNC*/
    _2 = (object)SEQ_PTR(_tok_27319);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27319 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 520;
    DeRef(_1);
    goto L22; // [860] 916
L23: 

    /** scanner.e:1597							elsif tok[T_ID] = PROC then*/
    _2 = (object)SEQ_PTR(_tok_27319);
    _15127 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15127, 27)){
        _15127 = NOVALUE;
        goto L24; // [873] 890
    }
    _15127 = NOVALUE;

    /** scanner.e:1598								tok[T_ID] = QUALIFIED_PROC*/
    _2 = (object)SEQ_PTR(_tok_27319);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27319 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 521;
    DeRef(_1);
    goto L22; // [887] 916
L24: 

    /** scanner.e:1599							elsif tok[T_ID] = TYPE then*/
    _2 = (object)SEQ_PTR(_tok_27319);
    _15129 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15129, 504)){
        _15129 = NOVALUE;
        goto L25; // [900] 915
    }
    _15129 = NOVALUE;

    /** scanner.e:1600								tok[T_ID] = QUALIFIED_TYPE*/
    _2 = (object)SEQ_PTR(_tok_27319);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27319 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 522;
    DeRef(_1);
L25: 
L22: 
L20: 

    /** scanner.e:1605						if atom( tok[T_SYM] ) and  SymTab[tok[T_SYM]][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok_27319);
    _15131 = (object)*(((s1_ptr)_2)->base + 2);
    _15132 = IS_ATOM(_15131);
    _15131 = NOVALUE;
    if (_15132 == 0) {
        goto L26; // [928] 1271
    }
    _2 = (object)SEQ_PTR(_tok_27319);
    _15134 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_15134)){
        _15135 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15134)->dbl));
    }
    else{
        _15135 = (object)*(((s1_ptr)_2)->base + _15134);
    }
    _2 = (object)SEQ_PTR(_15135);
    _15136 = (object)*(((s1_ptr)_2)->base + 4);
    _15135 = NOVALUE;
    if (IS_ATOM_INT(_15136)) {
        _15137 = (_15136 != 9);
    }
    else {
        _15137 = binary_op(NOTEQ, _15136, 9);
    }
    _15136 = NOVALUE;
    if (_15137 == 0) {
        DeRef(_15137);
        _15137 = NOVALUE;
        goto L26; // [957] 1271
    }
    else {
        if (!IS_ATOM_INT(_15137) && DBL_PTR(_15137)->dbl == 0.0){
            DeRef(_15137);
            _15137 = NOVALUE;
            goto L26; // [957] 1271
        }
        DeRef(_15137);
        _15137 = NOVALUE;
    }
    DeRef(_15137);
    _15137 = NOVALUE;

    /** scanner.e:1606							set_qualified_fwd( -1 )*/

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25585 = -1;

    /** scanner.e:105	end procedure*/
    goto L26; // [969] 1271
    goto L26; // [973] 1271
L13: 

    /** scanner.e:1610						ungetch()*/
    _62ungetch();

    /** scanner.e:1611					    if Parser_mode = PAM_RECORD then*/
    if (_36Parser_mode_21556 != 1)
    goto L26; // [986] 1271

    /** scanner.e:1612			                Ns_recorded &= 0*/
    Append(&_36Ns_recorded_21558, _36Ns_recorded_21558, 0);

    /** scanner.e:1613			                Ns_recorded_sym &= 0*/
    Append(&_36Ns_recorded_sym_21560, _36Ns_recorded_sym_21560, 0);

    /** scanner.e:1614			                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_27315);
    Append(&_36Recorded_21557, _36Recorded_21557, _yytext_27315);

    /** scanner.e:1615			                prev_Nne = No_new_entry*/
    _prev_Nne_27311 = _54No_new_entry_47978;

    /** scanner.e:1616							No_new_entry = 1*/
    _54No_new_entry_47978 = 1;

    /** scanner.e:1617							tok = keyfind(yytext, -1)*/
    RefDS(_yytext_27315);
    _31717 = _54hashfn(_yytext_27315);
    RefDS(_yytext_27315);
    _0 = _tok_27319;
    _tok_27319 = _54keyfind(_yytext_27315, -1, _36current_file_no_21447, 0, _31717);
    DeRef(_0);
    _31717 = NOVALUE;

    /** scanner.e:1618							if tok[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_27319);
    _15143 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15143, 509)){
        _15143 = NOVALUE;
        goto L27; // [1062] 1079
    }
    _15143 = NOVALUE;

    /** scanner.e:1619								Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_36Recorded_sym_21559, _36Recorded_sym_21559, 0);
    goto L28; // [1076] 1096
L27: 

    /** scanner.e:1621								Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (object)SEQ_PTR(_tok_27319);
    _15146 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_36Recorded_sym_21559) && IS_ATOM(_15146)) {
        Ref(_15146);
        Append(&_36Recorded_sym_21559, _36Recorded_sym_21559, _15146);
    }
    else if (IS_ATOM(_36Recorded_sym_21559) && IS_SEQUENCE(_15146)) {
    }
    else {
        Concat((object_ptr)&_36Recorded_sym_21559, _36Recorded_sym_21559, _15146);
    }
    _15146 = NOVALUE;
L28: 

    /** scanner.e:1623			                No_new_entry = prev_Nne*/
    _54No_new_entry_47978 = _prev_Nne_27311;

    /** scanner.e:1624			                tok = {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_36Recorded_21557)){
            _15148 = SEQ_PTR(_36Recorded_21557)->length;
    }
    else {
        _15148 = 1;
    }
    DeRef(_tok_27319);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508;
    ((intptr_t *)_2)[2] = _15148;
    _tok_27319 = MAKE_SEQ(_1);
    _15148 = NOVALUE;
    goto L26; // [1118] 1271
L12: 

    /** scanner.e:1628					set_qualified_fwd( -1 )*/

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25585 = -1;

    /** scanner.e:105	end procedure*/
    goto L29; // [1130] 1133
L29: 

    /** scanner.e:1629				    if Parser_mode = PAM_RECORD then*/
    if (_36Parser_mode_21556 != 1)
    goto L2A; // [1139] 1270

    /** scanner.e:1630		                Ns_recorded_sym &= 0*/
    Append(&_36Ns_recorded_sym_21560, _36Ns_recorded_sym_21560, 0);

    /** scanner.e:1631							Recorded = append(Recorded, yytext)*/
    RefDS(_yytext_27315);
    Append(&_36Recorded_21557, _36Recorded_21557, _yytext_27315);

    /** scanner.e:1632			                Ns_recorded &= 0*/
    Append(&_36Ns_recorded_21558, _36Ns_recorded_21558, 0);

    /** scanner.e:1633			                prev_Nne = No_new_entry*/
    _prev_Nne_27311 = _54No_new_entry_47978;

    /** scanner.e:1634							No_new_entry = 1*/
    _54No_new_entry_47978 = 1;

    /** scanner.e:1635							tok = keyfind(yytext, -1)*/
    RefDS(_yytext_27315);
    _31716 = _54hashfn(_yytext_27315);
    RefDS(_yytext_27315);
    _0 = _tok_27319;
    _tok_27319 = _54keyfind(_yytext_27315, -1, _36current_file_no_21447, 0, _31716);
    DeRef(_0);
    _31716 = NOVALUE;

    /** scanner.e:1636							if tok[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_27319);
    _15155 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15155, 509)){
        _15155 = NOVALUE;
        goto L2B; // [1215] 1232
    }
    _15155 = NOVALUE;

    /** scanner.e:1637								Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_36Recorded_sym_21559, _36Recorded_sym_21559, 0);
    goto L2C; // [1229] 1249
L2B: 

    /** scanner.e:1639								Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (object)SEQ_PTR(_tok_27319);
    _15158 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_36Recorded_sym_21559) && IS_ATOM(_15158)) {
        Ref(_15158);
        Append(&_36Recorded_sym_21559, _36Recorded_sym_21559, _15158);
    }
    else if (IS_ATOM(_36Recorded_sym_21559) && IS_SEQUENCE(_15158)) {
    }
    else {
        Concat((object_ptr)&_36Recorded_sym_21559, _36Recorded_sym_21559, _15158);
    }
    _15158 = NOVALUE;
L2C: 

    /** scanner.e:1641			                No_new_entry = prev_Nne*/
    _54No_new_entry_47978 = _prev_Nne_27311;

    /** scanner.e:1642		                tok = {RECORDED, length(Recorded)}*/
    if (IS_SEQUENCE(_36Recorded_21557)){
            _15160 = SEQ_PTR(_36Recorded_21557)->length;
    }
    else {
        _15160 = 1;
    }
    DeRef(_tok_27319);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508;
    ((intptr_t *)_2)[2] = _15160;
    _tok_27319 = MAKE_SEQ(_1);
    _15160 = NOVALUE;
L2A: 
L26: 

    /** scanner.e:1646				return tok*/
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    return _tok_27319;
    goto L1; // [1281] 10
L7: 

    /** scanner.e:1648			elsif class < ILLEGAL_CHAR then*/
    if (_class_27321 >= -20)
    goto L2D; // [1288] 1305

    /** scanner.e:1649				return {class, 0}  -- brackets, punctuation, eof, illegal char etc.*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _class_27321;
    ((intptr_t *)_2)[2] = 0;
    _15163 = MAKE_SEQ(_1);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    return _15163;
    goto L1; // [1302] 10
L2D: 

    /** scanner.e:1651			elsif class = ILLEGAL_CHAR then*/
    if (_class_27321 != -20)
    goto L2E; // [1309] 1325

    /** scanner.e:1652				CompileErr(ILLEGAL_CHARACTER_IN_SOURCE)*/
    RefDS(_21997);
    _50CompileErr(101, _21997, 0);
    goto L1; // [1322] 10
L2E: 

    /** scanner.e:1654			elsif class = NEWLINE then*/
    if (_class_27321 != -6)
    goto L2F; // [1329] 1355

    /** scanner.e:1655				if start_include then*/
    if (_62start_include_25553 == 0)
    {
        goto L30; // [1337] 1347
    }
    else{
    }

    /** scanner.e:1656					IncludePush()*/
    _62IncludePush();
    goto L1; // [1344] 10
L30: 

    /** scanner.e:1658					read_line()*/
    _62read_line();
    goto L1; // [1352] 10
L2F: 

    /** scanner.e:1662			elsif class = EQUALS then*/
    if (_class_27321 != 3)
    goto L31; // [1359] 1376

    /** scanner.e:1663				return {class, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _class_27321;
    ((intptr_t *)_2)[2] = 0;
    _15167 = MAKE_SEQ(_1);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    return _15167;
    goto L1; // [1373] 10
L31: 

    /** scanner.e:1665			elsif class = DOT or class = DIGIT then*/
    _15168 = (_class_27321 == -3);
    if (_15168 != 0) {
        goto L32; // [1384] 1399
    }
    _15170 = (_class_27321 == -7);
    if (_15170 == 0)
    {
        DeRef(_15170);
        _15170 = NOVALUE;
        goto L33; // [1395] 2195
    }
    else{
        DeRef(_15170);
        _15170 = NOVALUE;
    }
L32: 

    /** scanner.e:1666				integer basetype*/

    /** scanner.e:1667				if class = DOT then*/
    if (_class_27321 != -3)
    goto L34; // [1405] 1439

    /** scanner.e:1668					if getch() = '.' then*/
    _15172 = _62getch();
    if (binary_op_a(NOTEQ, _15172, 46)){
        DeRef(_15172);
        _15172 = NOVALUE;
        goto L35; // [1414] 1433
    }
    DeRef(_15172);
    _15172 = NOVALUE;

    /** scanner.e:1669						return {SLICE, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 513;
    ((intptr_t *)_2)[2] = 0;
    _15174 = MAKE_SEQ(_1);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15174;
    goto L36; // [1430] 1438
L35: 

    /** scanner.e:1671						ungetch()*/
    _62ungetch();
L36: 
L34: 

    /** scanner.e:1675				yytext = {ch}*/
    _0 = _yytext_27315;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ch_27309;
    _yytext_27315 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:1676				is_int = (ch != '.')*/
    _is_int_27320 = (_ch_27309 != 46);

    /** scanner.e:1677				basetype = -1 -- default is decimal*/
    _basetype_27617 = -1;

    /** scanner.e:1678				while 1 with entry do*/
    goto L37; // [1458] 1651
L38: 

    /** scanner.e:1679					if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _15177 = (object)*(((s1_ptr)_2)->base + _ch_27309);
    if (_15177 != -7)
    goto L39; // [1471] 1484

    /** scanner.e:1680						yytext &= ch*/
    Append(&_yytext_27315, _yytext_27315, _ch_27309);
    goto L3A; // [1481] 1648
L39: 

    /** scanner.e:1682					elsif equal(yytext, "0") then*/
    if (_yytext_27315 == _14834)
    _15180 = 1;
    else if (IS_ATOM_INT(_yytext_27315) && IS_ATOM_INT(_14834))
    _15180 = 0;
    else
    _15180 = (compare(_yytext_27315, _14834) == 0);
    if (_15180 == 0)
    {
        _15180 = NOVALUE;
        goto L3B; // [1490] 1587
    }
    else{
        _15180 = NOVALUE;
    }

    /** scanner.e:1683						basetype = find(ch, nbasecode)*/
    _basetype_27617 = find_from(_ch_27309, _62nbasecode_27112, 1);

    /** scanner.e:1684						if basetype > length(nbase) then*/
    if (IS_SEQUENCE(_62nbase_27111)){
            _15182 = SEQ_PTR(_62nbase_27111)->length;
    }
    else {
        _15182 = 1;
    }
    if (_basetype_27617 <= _15182)
    goto L3C; // [1505] 1519

    /** scanner.e:1685							basetype -= length(nbase)*/
    if (IS_SEQUENCE(_62nbase_27111)){
            _15184 = SEQ_PTR(_62nbase_27111)->length;
    }
    else {
        _15184 = 1;
    }
    _basetype_27617 = _basetype_27617 - _15184;
    _15184 = NOVALUE;
L3C: 

    /** scanner.e:1688						if basetype = 0 then*/
    if (_basetype_27617 != 0)
    goto L3D; // [1521] 1578

    /** scanner.e:1689							if char_class[ch] = LETTER then*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _15187 = (object)*(((s1_ptr)_2)->base + _ch_27309);
    if (_15187 != -2)
    goto L3E; // [1535] 1568

    /** scanner.e:1690								if ch != 'e' and ch != 'E' then*/
    _15189 = (_ch_27309 != 101);
    if (_15189 == 0) {
        goto L3F; // [1545] 1567
    }
    _15191 = (_ch_27309 != 69);
    if (_15191 == 0)
    {
        DeRef(_15191);
        _15191 = NOVALUE;
        goto L3F; // [1554] 1567
    }
    else{
        DeRef(_15191);
        _15191 = NOVALUE;
    }

    /** scanner.e:1691									CompileErr(INVALID_NUMBER_BASE_SPECIFIER_1, ch)*/
    _50CompileErr(105, _ch_27309, 0);
L3F: 
L3E: 

    /** scanner.e:1695							basetype = -1 -- decimal*/
    _basetype_27617 = -1;

    /** scanner.e:1696							exit*/
    goto L40; // [1575] 1663
L3D: 

    /** scanner.e:1698						yytext &= '0'*/
    Append(&_yytext_27315, _yytext_27315, 48);
    goto L3A; // [1584] 1648
L3B: 

    /** scanner.e:1700					elsif basetype = 4 then -- hexadecimal*/
    if (_basetype_27617 != 4)
    goto L40; // [1589] 1663

    /** scanner.e:1701						integer hdigit*/

    /** scanner.e:1702						hdigit = find(ch, "ABCDEFabcdef")*/
    _hdigit_27658 = find_from(_ch_27309, _15194, 1);

    /** scanner.e:1703						if hdigit = 0 then*/
    if (_hdigit_27658 != 0)
    goto L41; // [1604] 1615

    /** scanner.e:1704							exit*/
    goto L40; // [1612] 1663
L41: 

    /** scanner.e:1706						if hdigit > 6 then*/
    if (_hdigit_27658 <= 6)
    goto L42; // [1617] 1628

    /** scanner.e:1707							hdigit -= 6*/
    _hdigit_27658 = _hdigit_27658 - 6;
L42: 

    /** scanner.e:1709						yytext &= hexasc[hdigit]*/
    _2 = (object)SEQ_PTR(_62hexasc_27114);
    _15199 = (object)*(((s1_ptr)_2)->base + _hdigit_27658);
    if (IS_SEQUENCE(_yytext_27315) && IS_ATOM(_15199)) {
        Ref(_15199);
        Append(&_yytext_27315, _yytext_27315, _15199);
    }
    else if (IS_ATOM(_yytext_27315) && IS_SEQUENCE(_15199)) {
    }
    else {
        Concat((object_ptr)&_yytext_27315, _yytext_27315, _15199);
    }
    _15199 = NOVALUE;
    goto L3A; // [1640] 1648

    /** scanner.e:1712						exit*/
    goto L40; // [1645] 1663
L3A: 

    /** scanner.e:1714				entry*/
L37: 

    /** scanner.e:1715					ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1716				end while*/
    goto L38; // [1660] 1461
L40: 

    /** scanner.e:1718				if ch = '.' then*/
    if (_ch_27309 != 46)
    goto L43; // [1665] 1804

    /** scanner.e:1719					ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1720					if ch = '.' then*/
    if (_ch_27309 != 46)
    goto L44; // [1678] 1689

    /** scanner.e:1722						ungetch()*/
    _62ungetch();
    goto L45; // [1686] 1803
L44: 

    /** scanner.e:1724						is_int = FALSE*/
    _is_int_27320 = _13FALSE_450;

    /** scanner.e:1725						if yytext[1] = '.' then*/
    _2 = (object)SEQ_PTR(_yytext_27315);
    _15205 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15205, 46)){
        _15205 = NOVALUE;
        goto L46; // [1704] 1720
    }
    _15205 = NOVALUE;

    /** scanner.e:1726							CompileErr(ONLY_ONE_DECIMAL_POINT_ALLOWED)*/
    RefDS(_21997);
    _50CompileErr(124, _21997, 0);
    goto L47; // [1717] 1727
L46: 

    /** scanner.e:1728							yytext &= '.'*/
    Append(&_yytext_27315, _yytext_27315, 46);
L47: 

    /** scanner.e:1730						if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _15208 = (object)*(((s1_ptr)_2)->base + _ch_27309);
    if (_15208 != -7)
    goto L48; // [1737] 1792

    /** scanner.e:1731							yytext &= ch*/
    Append(&_yytext_27315, _yytext_27315, _ch_27309);

    /** scanner.e:1732							ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1733							while char_class[ch] = DIGIT do*/
L49: 
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _15212 = (object)*(((s1_ptr)_2)->base + _ch_27309);
    if (_15212 != -7)
    goto L4A; // [1767] 1802

    /** scanner.e:1734								yytext &= ch*/
    Append(&_yytext_27315, _yytext_27315, _ch_27309);

    /** scanner.e:1735								ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1736							end while*/
    goto L49; // [1786] 1759
    goto L4A; // [1789] 1802
L48: 

    /** scanner.e:1738							CompileErr(FRACTIONAL_PART_OF_NUMBER_IS_MISSING)*/
    RefDS(_21997);
    _50CompileErr(94, _21997, 0);
L4A: 
L45: 
L43: 

    /** scanner.e:1743				if basetype = -1 and find(ch, "eE") then*/
    _15216 = (_basetype_27617 == -1);
    if (_15216 == 0) {
        goto L4B; // [1810] 1948
    }
    _15219 = find_from(_ch_27309, _15218, 1);
    if (_15219 == 0)
    {
        _15219 = NOVALUE;
        goto L4B; // [1820] 1948
    }
    else{
        _15219 = NOVALUE;
    }

    /** scanner.e:1744					is_int = FALSE*/
    _is_int_27320 = _13FALSE_450;

    /** scanner.e:1745					yytext &= ch*/
    Append(&_yytext_27315, _yytext_27315, _ch_27309);

    /** scanner.e:1746					ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1747					if ch = '-' or ch = '+' or char_class[ch] = DIGIT then*/
    _15222 = (_ch_27309 == 45);
    if (_15222 != 0) {
        _15223 = 1;
        goto L4C; // [1851] 1863
    }
    _15224 = (_ch_27309 == 43);
    _15223 = (_15224 != 0);
L4C: 
    if (_15223 != 0) {
        goto L4D; // [1863] 1884
    }
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _15226 = (object)*(((s1_ptr)_2)->base + _ch_27309);
    _15227 = (_15226 == -7);
    _15226 = NOVALUE;
    if (_15227 == 0)
    {
        DeRef(_15227);
        _15227 = NOVALUE;
        goto L4E; // [1880] 1893
    }
    else{
        DeRef(_15227);
        _15227 = NOVALUE;
    }
L4D: 

    /** scanner.e:1748						yytext &= ch*/
    Append(&_yytext_27315, _yytext_27315, _ch_27309);
    goto L4F; // [1890] 1903
L4E: 

    /** scanner.e:1750						CompileErr(EXPONENT_NOT_FORMED_CORRECTLY)*/
    RefDS(_21997);
    _50CompileErr(86, _21997, 0);
L4F: 

    /** scanner.e:1752					ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1753					while char_class[ch] = DIGIT do*/
L50: 
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _15230 = (object)*(((s1_ptr)_2)->base + _ch_27309);
    if (_15230 != -7)
    goto L51; // [1923] 1981

    /** scanner.e:1754						yytext &= ch*/
    Append(&_yytext_27315, _yytext_27315, _ch_27309);

    /** scanner.e:1755						ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1756					end while*/
    goto L50; // [1942] 1915
    goto L51; // [1945] 1981
L4B: 

    /** scanner.e:1757				elsif char_class[ch] = LETTER then*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _15234 = (object)*(((s1_ptr)_2)->base + _ch_27309);
    if (_15234 != -2)
    goto L52; // [1958] 1980

    /** scanner.e:1758					CompileErr(PUNCTUATION_MISSING_IN_BETWEEN_NUMBER_AND_1, {{ch}})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ch_27309;
    _15236 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _15236;
    _15237 = MAKE_SEQ(_1);
    _15236 = NOVALUE;
    _50CompileErr(127, _15237, 0);
    _15237 = NOVALUE;
L52: 
L51: 

    /** scanner.e:1761				ungetch()*/
    _62ungetch();

    /** scanner.e:1763				while i != 0 with entry do*/
    goto L53; // [1987] 2006
L54: 
    if (binary_op_a(EQUALS, _i_27312, 0)){
        goto L55; // [1992] 2018
    }

    /** scanner.e:1764					yytext = remove( yytext, i )*/
    {
        s1_ptr assign_space = SEQ_PTR(_yytext_27315);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_27312)) ? _i_27312 : (object)(DBL_PTR(_i_27312)->dbl);
        int stop = (IS_ATOM_INT(_i_27312)) ? _i_27312 : (object)(DBL_PTR(_i_27312)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_yytext_27315), start, &_yytext_27315 );
            }
            else Tail(SEQ_PTR(_yytext_27315), stop+1, &_yytext_27315);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_yytext_27315), start, &_yytext_27315);
        }
        else {
            assign_slice_seq = &assign_space;
            _yytext_27315 = Remove_elements(start, stop, (SEQ_PTR(_yytext_27315)->ref == 1));
        }
    }

    /** scanner.e:1765				  entry*/
L53: 

    /** scanner.e:1766				    i = find('_', yytext)*/
    DeRef(_i_27312);
    _i_27312 = find_from(95, _yytext_27315, 1);

    /** scanner.e:1767				end while*/
    goto L54; // [2015] 1990
L55: 

    /** scanner.e:1769				if is_int then*/
    if (_is_int_27320 == 0)
    {
        goto L56; // [2020] 2092
    }
    else{
    }

    /** scanner.e:1770					if basetype = -1 then*/
    if (_basetype_27617 != -1)
    goto L57; // [2025] 2035

    /** scanner.e:1771						basetype = 3 -- decimal*/
    _basetype_27617 = 3;
L57: 

    /** scanner.e:1773					d = MakeInt(yytext, nbase[basetype])*/
    _2 = (object)SEQ_PTR(_62nbase_27111);
    _15242 = (object)*(((s1_ptr)_2)->base + _basetype_27617);
    RefDS(_yytext_27315);
    Ref(_15242);
    _0 = _d_27317;
    _d_27317 = _62MakeInt(_yytext_27315, _15242);
    DeRef(_0);
    _15242 = NOVALUE;

    /** scanner.e:1774					if is_integer(d) then*/
    Ref(_d_27317);
    _15244 = _36is_integer(_d_27317);
    if (_15244 == 0) {
        DeRef(_15244);
        _15244 = NOVALUE;
        goto L58; // [2052] 2074
    }
    else {
        if (!IS_ATOM_INT(_15244) && DBL_PTR(_15244)->dbl == 0.0){
            DeRef(_15244);
            _15244 = NOVALUE;
            goto L58; // [2052] 2074
        }
        DeRef(_15244);
        _15244 = NOVALUE;
    }
    DeRef(_15244);
    _15244 = NOVALUE;

    /** scanner.e:1775						return {ATOM, NewIntSym(d)}*/
    Ref(_d_27317);
    _15245 = _54NewIntSym(_d_27317);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15245;
    _15246 = MAKE_SEQ(_1);
    _15245 = NOVALUE;
    DeRef(_i_27312);
    DeRefDS(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15246;
    goto L59; // [2071] 2091
L58: 

    /** scanner.e:1777						return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_27317);
    _15247 = _54NewDoubleSym(_d_27317);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15247;
    _15248 = MAKE_SEQ(_1);
    _15247 = NOVALUE;
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15248;
L59: 
L56: 

    /** scanner.e:1782				if basetype != -1 then*/
    if (_basetype_27617 == -1)
    goto L5A; // [2094] 2112

    /** scanner.e:1783					CompileErr(ONLY_INTEGER_LITERALS_CAN_USE_THE_01_FORMAT, nbasecode[basetype])*/
    _2 = (object)SEQ_PTR(_62nbasecode_27112);
    _15250 = (object)*(((s1_ptr)_2)->base + _basetype_27617);
    Ref(_15250);
    _50CompileErr(125, _15250, 0);
    _15250 = NOVALUE;
L5A: 

    /** scanner.e:1787				d = my_sscanf(yytext)*/
    RefDS(_yytext_27315);
    _0 = _d_27317;
    _d_27317 = _62my_sscanf(_yytext_27315);
    DeRef(_0);

    /** scanner.e:1788				if sequence(d) then*/
    _15252 = IS_SEQUENCE(_d_27317);
    if (_15252 == 0)
    {
        _15252 = NOVALUE;
        goto L5B; // [2123] 2138
    }
    else{
        _15252 = NOVALUE;
    }

    /** scanner.e:1789					CompileErr(NUMBER_NOT_FORMED_CORRECTLY)*/
    RefDS(_21997);
    _50CompileErr(121, _21997, 0);
    goto L5C; // [2135] 2190
L5B: 

    /** scanner.e:1790				elsif is_int and d <= TMAXINT_DBL then*/
    if (_is_int_27320 == 0) {
        goto L5D; // [2140] 2173
    }
    if (IS_ATOM_INT(_d_27317) && IS_ATOM_INT(_36TMAXINT_DBL_21279)) {
        _15254 = (_d_27317 <= _36TMAXINT_DBL_21279);
    }
    else {
        _15254 = binary_op(LESSEQ, _d_27317, _36TMAXINT_DBL_21279);
    }
    if (_15254 == 0) {
        DeRef(_15254);
        _15254 = NOVALUE;
        goto L5D; // [2151] 2173
    }
    else {
        if (!IS_ATOM_INT(_15254) && DBL_PTR(_15254)->dbl == 0.0){
            DeRef(_15254);
            _15254 = NOVALUE;
            goto L5D; // [2151] 2173
        }
        DeRef(_15254);
        _15254 = NOVALUE;
    }
    DeRef(_15254);
    _15254 = NOVALUE;

    /** scanner.e:1791					return {ATOM, NewIntSym(d)}  -- 1 to 1.07 billion*/
    Ref(_d_27317);
    _15255 = _54NewIntSym(_d_27317);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15255;
    _15256 = MAKE_SEQ(_1);
    _15255 = NOVALUE;
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15256;
    goto L5C; // [2170] 2190
L5D: 

    /** scanner.e:1793					return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_27317);
    _15257 = _54NewDoubleSym(_d_27317);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15257;
    _15258 = MAKE_SEQ(_1);
    _15257 = NOVALUE;
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15258;
L5C: 
    goto L1; // [2192] 10
L33: 

    /** scanner.e:1797			elsif class = MINUS then*/
    if (_class_27321 != 10)
    goto L5E; // [2199] 2285

    /** scanner.e:1798				ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1799				if ch = '-' then*/
    if (_ch_27309 != 45)
    goto L5F; // [2212] 2238

    /** scanner.e:1801					if start_include then*/
    if (_62start_include_25553 == 0)
    {
        goto L60; // [2220] 2230
    }
    else{
    }

    /** scanner.e:1802						IncludePush()*/
    _62IncludePush();
    goto L1; // [2227] 10
L60: 

    /** scanner.e:1804						read_line()*/
    _62read_line();
    goto L1; // [2235] 10
L5F: 

    /** scanner.e:1806				elsif ch = '=' then*/
    if (_ch_27309 != 61)
    goto L61; // [2240] 2259

    /** scanner.e:1807					return {MINUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 516;
    ((intptr_t *)_2)[2] = 0;
    _15263 = MAKE_SEQ(_1);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15263;
    goto L1; // [2256] 10
L61: 

    /** scanner.e:1809					bp -= 1*/
    _50bp_49242 = _50bp_49242 - 1;

    /** scanner.e:1810					return {MINUS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 10;
    ((intptr_t *)_2)[2] = 0;
    _15265 = MAKE_SEQ(_1);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15265;
    goto L1; // [2282] 10
L5E: 

    /** scanner.e:1812			elsif class = DOUBLE_QUOTE then*/
    if (_class_27321 != -4)
    goto L62; // [2289] 2487

    /** scanner.e:1813				integer fch*/

    /** scanner.e:1814				ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1815				if ch = '"' then*/
    if (_ch_27309 != 34)
    goto L63; // [2304] 2340

    /** scanner.e:1816					fch = getch()*/
    _fch_27798 = _62getch();
    if (!IS_ATOM_INT(_fch_27798)) {
        _1 = (object)(DBL_PTR(_fch_27798)->dbl);
        DeRefDS(_fch_27798);
        _fch_27798 = _1;
    }

    /** scanner.e:1817					if fch = '"' then*/
    if (_fch_27798 != 34)
    goto L64; // [2317] 2334

    /** scanner.e:1819						return ExtendedString( fch )*/
    _15271 = _62ExtendedString(_fch_27798);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15271;
    goto L65; // [2331] 2339
L64: 

    /** scanner.e:1821						ungetch()*/
    _62ungetch();
L65: 
L63: 

    /** scanner.e:1824				yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_27315);
    _yytext_27315 = _5;

    /** scanner.e:1825				while ch != '\n' and ch != '\r' do -- can't be EOF*/
L66: 
    _15272 = (_ch_27309 != 10);
    if (_15272 == 0) {
        goto L67; // [2356] 2437
    }
    _15274 = (_ch_27309 != 13);
    if (_15274 == 0)
    {
        DeRef(_15274);
        _15274 = NOVALUE;
        goto L67; // [2365] 2437
    }
    else{
        DeRef(_15274);
        _15274 = NOVALUE;
    }

    /** scanner.e:1826					if ch = '"' then*/
    if (_ch_27309 != 34)
    goto L68; // [2370] 2381

    /** scanner.e:1827						exit*/
    goto L67; // [2376] 2437
    goto L69; // [2378] 2425
L68: 

    /** scanner.e:1828					elsif ch = '\\' then*/
    if (_ch_27309 != 92)
    goto L6A; // [2383] 2400

    /** scanner.e:1829						yytext &= EscapeChar('"')*/
    _15277 = _62EscapeChar(34);
    if (IS_SEQUENCE(_yytext_27315) && IS_ATOM(_15277)) {
        Ref(_15277);
        Append(&_yytext_27315, _yytext_27315, _15277);
    }
    else if (IS_ATOM(_yytext_27315) && IS_SEQUENCE(_15277)) {
    }
    else {
        Concat((object_ptr)&_yytext_27315, _yytext_27315, _15277);
    }
    DeRef(_15277);
    _15277 = NOVALUE;
    goto L69; // [2397] 2425
L6A: 

    /** scanner.e:1830					elsif ch = '\t' then*/
    if (_ch_27309 != 9)
    goto L6B; // [2402] 2418

    /** scanner.e:1831						CompileErr(MSG_TAB_CHARACTER_FOUND_IN_STRING__USE_T_INSTEAD)*/
    RefDS(_21997);
    _50CompileErr(145, _21997, 0);
    goto L69; // [2415] 2425
L6B: 

    /** scanner.e:1833						yytext &= ch*/
    Append(&_yytext_27315, _yytext_27315, _ch_27309);
L69: 

    /** scanner.e:1835					ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1836				end while*/
    goto L66; // [2434] 2352
L67: 

    /** scanner.e:1837				if ch = '\n' or ch = '\r' then*/
    _15282 = (_ch_27309 == 10);
    if (_15282 != 0) {
        goto L6C; // [2443] 2456
    }
    _15284 = (_ch_27309 == 13);
    if (_15284 == 0)
    {
        DeRef(_15284);
        _15284 = NOVALUE;
        goto L6D; // [2452] 2466
    }
    else{
        DeRef(_15284);
        _15284 = NOVALUE;
    }
L6C: 

    /** scanner.e:1838					CompileErr(END_OF_LINE_REACHED_WITH_NO_CLOSING)*/
    RefDS(_21997);
    _50CompileErr(67, _21997, 0);
L6D: 

    /** scanner.e:1840				return {STRING, NewStringSym(yytext)}*/
    RefDS(_yytext_27315);
    _15285 = _54NewStringSym(_yytext_27315);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 503;
    ((intptr_t *)_2)[2] = _15285;
    _15286 = MAKE_SEQ(_1);
    _15285 = NOVALUE;
    DeRef(_i_27312);
    DeRefDS(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15286;
    goto L1; // [2484] 10
L62: 

    /** scanner.e:1842			elsif class = PLUS then*/
    if (_class_27321 != 11)
    goto L6E; // [2491] 2543

    /** scanner.e:1843				ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1844				if ch = '=' then*/
    if (_ch_27309 != 61)
    goto L6F; // [2504] 2523

    /** scanner.e:1845					return {PLUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 515;
    ((intptr_t *)_2)[2] = 0;
    _15290 = MAKE_SEQ(_1);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15290;
    goto L1; // [2520] 10
L6F: 

    /** scanner.e:1847					ungetch()*/
    _62ungetch();

    /** scanner.e:1848					return {PLUS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 11;
    ((intptr_t *)_2)[2] = 0;
    _15291 = MAKE_SEQ(_1);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15291;
    goto L1; // [2540] 10
L6E: 

    /** scanner.e:1851			elsif class = res:CONCAT then*/
    if (_class_27321 != 15)
    goto L70; // [2545] 2595

    /** scanner.e:1852				ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1853				if ch = '=' then*/
    if (_ch_27309 != 61)
    goto L71; // [2558] 2577

    /** scanner.e:1854					return {CONCAT_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 519;
    ((intptr_t *)_2)[2] = 0;
    _15295 = MAKE_SEQ(_1);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15295;
    goto L1; // [2574] 10
L71: 

    /** scanner.e:1856					ungetch()*/
    _62ungetch();

    /** scanner.e:1857					return {res:CONCAT, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 15;
    ((intptr_t *)_2)[2] = 0;
    _15296 = MAKE_SEQ(_1);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15295);
    _15295 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15296;
    goto L1; // [2592] 10
L70: 

    /** scanner.e:1860			elsif class = NUMBER_SIGN then*/
    if (_class_27321 != -11)
    goto L72; // [2599] 3122

    /** scanner.e:1861				i = 0*/
    DeRef(_i_27312);
    _i_27312 = 0;

    /** scanner.e:1862				is_int = -1*/
    _is_int_27320 = -1;

    /** scanner.e:1863				while i < TMAXINT/32 do*/
L73: 
    if (IS_ATOM_INT(_36TMAXINT_21276)) {
        _15298 = (_36TMAXINT_21276 % 32) ? NewDouble((eudouble)_36TMAXINT_21276 / 32) : (_36TMAXINT_21276 / 32);
    }
    else {
        _15298 = NewDouble(DBL_PTR(_36TMAXINT_21276)->dbl / (eudouble)32);
    }
    if (binary_op_a(GREATEREQ, _i_27312, _15298)){
        DeRef(_15298);
        _15298 = NOVALUE;
        goto L74; // [2624] 2788
    }
    DeRef(_15298);
    _15298 = NOVALUE;

    /** scanner.e:1864					ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1865					if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _15301 = (object)*(((s1_ptr)_2)->base + _ch_27309);
    if (_15301 != -7)
    goto L75; // [2645] 2682

    /** scanner.e:1866						if ch != '_' then*/
    if (_ch_27309 == 95)
    goto L73; // [2651] 2618

    /** scanner.e:1867							i = i * 16 + ch - '0'*/
    if (IS_ATOM_INT(_i_27312)) {
        if (_i_27312 == (short)_i_27312){
            _15304 = _i_27312 * 16;
        }
        else{
            _15304 = NewDouble(_i_27312 * (eudouble)16);
        }
    }
    else {
        _15304 = NewDouble(DBL_PTR(_i_27312)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_15304)) {
        _15305 = _15304 + _ch_27309;
        if ((object)((uintptr_t)_15305 + (uintptr_t)HIGH_BITS) >= 0){
            _15305 = NewDouble((eudouble)_15305);
        }
    }
    else {
        _15305 = NewDouble(DBL_PTR(_15304)->dbl + (eudouble)_ch_27309);
    }
    DeRef(_15304);
    _15304 = NOVALUE;
    DeRef(_i_27312);
    if (IS_ATOM_INT(_15305)) {
        _i_27312 = _15305 - 48;
        if ((object)((uintptr_t)_i_27312 +(uintptr_t) HIGH_BITS) >= 0){
            _i_27312 = NewDouble((eudouble)_i_27312);
        }
    }
    else {
        _i_27312 = NewDouble(DBL_PTR(_15305)->dbl - (eudouble)48);
    }
    DeRef(_15305);
    _15305 = NOVALUE;

    /** scanner.e:1868							is_int = TRUE*/
    _is_int_27320 = _13TRUE_452;
    goto L73; // [2679] 2618
L75: 

    /** scanner.e:1870					elsif ch >= 'A' and ch <= 'F' then*/
    _15307 = (_ch_27309 >= 65);
    if (_15307 == 0) {
        goto L76; // [2688] 2730
    }
    _15309 = (_ch_27309 <= 70);
    if (_15309 == 0)
    {
        DeRef(_15309);
        _15309 = NOVALUE;
        goto L76; // [2697] 2730
    }
    else{
        DeRef(_15309);
        _15309 = NOVALUE;
    }

    /** scanner.e:1871						i = (i * 16) + ch - ('A'-10)*/
    if (IS_ATOM_INT(_i_27312)) {
        if (_i_27312 == (short)_i_27312){
            _15310 = _i_27312 * 16;
        }
        else{
            _15310 = NewDouble(_i_27312 * (eudouble)16);
        }
    }
    else {
        _15310 = NewDouble(DBL_PTR(_i_27312)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_15310)) {
        _15311 = _15310 + _ch_27309;
        if ((object)((uintptr_t)_15311 + (uintptr_t)HIGH_BITS) >= 0){
            _15311 = NewDouble((eudouble)_15311);
        }
    }
    else {
        _15311 = NewDouble(DBL_PTR(_15310)->dbl + (eudouble)_ch_27309);
    }
    DeRef(_15310);
    _15310 = NOVALUE;
    _15312 = 55;
    DeRef(_i_27312);
    if (IS_ATOM_INT(_15311)) {
        _i_27312 = _15311 - 55;
        if ((object)((uintptr_t)_i_27312 +(uintptr_t) HIGH_BITS) >= 0){
            _i_27312 = NewDouble((eudouble)_i_27312);
        }
    }
    else {
        _i_27312 = NewDouble(DBL_PTR(_15311)->dbl - (eudouble)55);
    }
    DeRef(_15311);
    _15311 = NOVALUE;
    _15312 = NOVALUE;

    /** scanner.e:1872						is_int = TRUE*/
    _is_int_27320 = _13TRUE_452;
    goto L73; // [2727] 2618
L76: 

    /** scanner.e:1873					elsif ch >= 'a' and ch <= 'f' then*/
    _15314 = (_ch_27309 >= 97);
    if (_15314 == 0) {
        goto L74; // [2736] 2788
    }
    _15316 = (_ch_27309 <= 102);
    if (_15316 == 0)
    {
        DeRef(_15316);
        _15316 = NOVALUE;
        goto L74; // [2745] 2788
    }
    else{
        DeRef(_15316);
        _15316 = NOVALUE;
    }

    /** scanner.e:1874						i = (i * 16) + ch - ('a'-10)*/
    if (IS_ATOM_INT(_i_27312)) {
        if (_i_27312 == (short)_i_27312){
            _15317 = _i_27312 * 16;
        }
        else{
            _15317 = NewDouble(_i_27312 * (eudouble)16);
        }
    }
    else {
        _15317 = NewDouble(DBL_PTR(_i_27312)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_15317)) {
        _15318 = _15317 + _ch_27309;
        if ((object)((uintptr_t)_15318 + (uintptr_t)HIGH_BITS) >= 0){
            _15318 = NewDouble((eudouble)_15318);
        }
    }
    else {
        _15318 = NewDouble(DBL_PTR(_15317)->dbl + (eudouble)_ch_27309);
    }
    DeRef(_15317);
    _15317 = NOVALUE;
    _15319 = 87;
    DeRef(_i_27312);
    if (IS_ATOM_INT(_15318)) {
        _i_27312 = _15318 - 87;
        if ((object)((uintptr_t)_i_27312 +(uintptr_t) HIGH_BITS) >= 0){
            _i_27312 = NewDouble((eudouble)_i_27312);
        }
    }
    else {
        _i_27312 = NewDouble(DBL_PTR(_15318)->dbl - (eudouble)87);
    }
    DeRef(_15318);
    _15318 = NOVALUE;
    _15319 = NOVALUE;

    /** scanner.e:1875						is_int = TRUE*/
    _is_int_27320 = _13TRUE_452;
    goto L73; // [2775] 2618

    /** scanner.e:1877						exit*/
    goto L74; // [2780] 2788

    /** scanner.e:1879				end while*/
    goto L73; // [2785] 2618
L74: 

    /** scanner.e:1881				if is_int = -1 then*/
    if (_is_int_27320 != -1)
    goto L77; // [2790] 2857

    /** scanner.e:1882					if ch = '!' then*/
    if (_ch_27309 != 33)
    goto L78; // [2796] 2844

    /** scanner.e:1883						if line_number > 1 then*/
    if (_36line_number_21448 <= 1)
    goto L79; // [2804] 2818

    /** scanner.e:1884							CompileErr(MSG__MAY_ONLY_BE_ON_THE_FIRST_LINE_OF_A_PROGRAM)*/
    RefDS(_21997);
    _50CompileErr(161, _21997, 0);
L79: 

    /** scanner.e:1887						shebang = ThisLine*/
    Ref(_50ThisLine_49238);
    DeRef(_62shebang_25558);
    _62shebang_25558 = _50ThisLine_49238;

    /** scanner.e:1888						if start_include then*/
    if (_62start_include_25553 == 0)
    {
        goto L7A; // [2829] 2837
    }
    else{
    }

    /** scanner.e:1889							IncludePush()*/
    _62IncludePush();
L7A: 

    /** scanner.e:1891						read_line()*/
    _62read_line();
    goto L1; // [2841] 10
L78: 

    /** scanner.e:1893						CompileErr(HEX_NUMBER_NOT_FORMED_CORRECTLY)*/
    RefDS(_21997);
    _50CompileErr(97, _21997, 0);
    goto L1; // [2854] 10
L77: 

    /** scanner.e:1896					d = i*/
    Ref(_i_27312);
    DeRef(_d_27317);
    _d_27317 = _i_27312;

    /** scanner.e:1897					if i >= TMAXINT/32 then*/
    if (IS_ATOM_INT(_36TMAXINT_21276)) {
        _15324 = (_36TMAXINT_21276 % 32) ? NewDouble((eudouble)_36TMAXINT_21276 / 32) : (_36TMAXINT_21276 / 32);
    }
    else {
        _15324 = NewDouble(DBL_PTR(_36TMAXINT_21276)->dbl / (eudouble)32);
    }
    if (binary_op_a(LESS, _i_27312, _15324)){
        DeRef(_15324);
        _15324 = NOVALUE;
        goto L7B; // [2870] 3036
    }
    DeRef(_15324);
    _15324 = NOVALUE;

    /** scanner.e:1898						is_int = FALSE*/
    _is_int_27320 = _13FALSE_450;

    /** scanner.e:1899						while TRUE do*/
L7C: 
    if (_13TRUE_452 == 0)
    {
        goto L7D; // [2890] 3035
    }
    else{
    }

    /** scanner.e:1900							ch = getch()  -- eventually END_OF_FILE_CHAR or new-line*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1901							if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _15327 = (object)*(((s1_ptr)_2)->base + _ch_27309);
    if (_15327 != -7)
    goto L7E; // [2910] 2938

    /** scanner.e:1902								if ch != '_' then*/
    if (_ch_27309 == 95)
    goto L7C; // [2916] 2888

    /** scanner.e:1903									d = (d * 16) + ch - '0'*/
    if (IS_ATOM_INT(_d_27317)) {
        if (_d_27317 == (short)_d_27317){
            _15330 = _d_27317 * 16;
        }
        else{
            _15330 = NewDouble(_d_27317 * (eudouble)16);
        }
    }
    else {
        _15330 = binary_op(MULTIPLY, _d_27317, 16);
    }
    if (IS_ATOM_INT(_15330)) {
        _15331 = _15330 + _ch_27309;
        if ((object)((uintptr_t)_15331 + (uintptr_t)HIGH_BITS) >= 0){
            _15331 = NewDouble((eudouble)_15331);
        }
    }
    else {
        _15331 = binary_op(PLUS, _15330, _ch_27309);
    }
    DeRef(_15330);
    _15330 = NOVALUE;
    DeRef(_d_27317);
    if (IS_ATOM_INT(_15331)) {
        _d_27317 = _15331 - 48;
        if ((object)((uintptr_t)_d_27317 +(uintptr_t) HIGH_BITS) >= 0){
            _d_27317 = NewDouble((eudouble)_d_27317);
        }
    }
    else {
        _d_27317 = binary_op(MINUS, _15331, 48);
    }
    DeRef(_15331);
    _15331 = NOVALUE;
    goto L7C; // [2935] 2888
L7E: 

    /** scanner.e:1905							elsif ch >= 'A' and ch <= 'F' then*/
    _15333 = (_ch_27309 >= 65);
    if (_15333 == 0) {
        goto L7F; // [2944] 2977
    }
    _15335 = (_ch_27309 <= 70);
    if (_15335 == 0)
    {
        DeRef(_15335);
        _15335 = NOVALUE;
        goto L7F; // [2953] 2977
    }
    else{
        DeRef(_15335);
        _15335 = NOVALUE;
    }

    /** scanner.e:1906								d = (d * 16) + ch - ('A'- 10)*/
    if (IS_ATOM_INT(_d_27317)) {
        if (_d_27317 == (short)_d_27317){
            _15336 = _d_27317 * 16;
        }
        else{
            _15336 = NewDouble(_d_27317 * (eudouble)16);
        }
    }
    else {
        _15336 = binary_op(MULTIPLY, _d_27317, 16);
    }
    if (IS_ATOM_INT(_15336)) {
        _15337 = _15336 + _ch_27309;
        if ((object)((uintptr_t)_15337 + (uintptr_t)HIGH_BITS) >= 0){
            _15337 = NewDouble((eudouble)_15337);
        }
    }
    else {
        _15337 = binary_op(PLUS, _15336, _ch_27309);
    }
    DeRef(_15336);
    _15336 = NOVALUE;
    _15338 = 55;
    DeRef(_d_27317);
    if (IS_ATOM_INT(_15337)) {
        _d_27317 = _15337 - 55;
        if ((object)((uintptr_t)_d_27317 +(uintptr_t) HIGH_BITS) >= 0){
            _d_27317 = NewDouble((eudouble)_d_27317);
        }
    }
    else {
        _d_27317 = binary_op(MINUS, _15337, 55);
    }
    DeRef(_15337);
    _15337 = NOVALUE;
    _15338 = NOVALUE;
    goto L7C; // [2974] 2888
L7F: 

    /** scanner.e:1907							elsif ch >= 'a' and ch <= 'f' then*/
    _15340 = (_ch_27309 >= 97);
    if (_15340 == 0) {
        goto L80; // [2983] 3016
    }
    _15342 = (_ch_27309 <= 102);
    if (_15342 == 0)
    {
        DeRef(_15342);
        _15342 = NOVALUE;
        goto L80; // [2992] 3016
    }
    else{
        DeRef(_15342);
        _15342 = NOVALUE;
    }

    /** scanner.e:1908								d = (d * 16) + ch - ('a'-10)*/
    if (IS_ATOM_INT(_d_27317)) {
        if (_d_27317 == (short)_d_27317){
            _15343 = _d_27317 * 16;
        }
        else{
            _15343 = NewDouble(_d_27317 * (eudouble)16);
        }
    }
    else {
        _15343 = binary_op(MULTIPLY, _d_27317, 16);
    }
    if (IS_ATOM_INT(_15343)) {
        _15344 = _15343 + _ch_27309;
        if ((object)((uintptr_t)_15344 + (uintptr_t)HIGH_BITS) >= 0){
            _15344 = NewDouble((eudouble)_15344);
        }
    }
    else {
        _15344 = binary_op(PLUS, _15343, _ch_27309);
    }
    DeRef(_15343);
    _15343 = NOVALUE;
    _15345 = 87;
    DeRef(_d_27317);
    if (IS_ATOM_INT(_15344)) {
        _d_27317 = _15344 - 87;
        if ((object)((uintptr_t)_d_27317 +(uintptr_t) HIGH_BITS) >= 0){
            _d_27317 = NewDouble((eudouble)_d_27317);
        }
    }
    else {
        _d_27317 = binary_op(MINUS, _15344, 87);
    }
    DeRef(_15344);
    _15344 = NOVALUE;
    _15345 = NOVALUE;
    goto L7C; // [3013] 2888
L80: 

    /** scanner.e:1909							elsif ch = '_' then*/
    if (_ch_27309 != 95)
    goto L7D; // [3018] 3035
    goto L7C; // [3022] 2888

    /** scanner.e:1912								exit*/
    goto L7D; // [3027] 3035

    /** scanner.e:1914						end while*/
    goto L7C; // [3032] 2888
L7D: 
L7B: 

    /** scanner.e:1917					ungetch()*/
    _62ungetch();

    /** scanner.e:1918					if is_int and is_integer(i) then*/
    if (_is_int_27320 == 0) {
        goto L81; // [3042] 3073
    }
    Ref(_i_27312);
    _15349 = _36is_integer(_i_27312);
    if (_15349 == 0) {
        DeRef(_15349);
        _15349 = NOVALUE;
        goto L81; // [3051] 3073
    }
    else {
        if (!IS_ATOM_INT(_15349) && DBL_PTR(_15349)->dbl == 0.0){
            DeRef(_15349);
            _15349 = NOVALUE;
            goto L81; // [3051] 3073
        }
        DeRef(_15349);
        _15349 = NOVALUE;
    }
    DeRef(_15349);
    _15349 = NOVALUE;

    /** scanner.e:1919						return {ATOM, NewIntSym(i)}*/
    Ref(_i_27312);
    _15350 = _54NewIntSym(_i_27312);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15350;
    _15351 = MAKE_SEQ(_1);
    _15350 = NOVALUE;
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15296);
    _15296 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15307);
    _15307 = NOVALUE;
    DeRef(_15295);
    _15295 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15340);
    _15340 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    _15301 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15327 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15351;
    goto L1; // [3070] 10
L81: 

    /** scanner.e:1921						if d <= TMAXINT_DBL then            -- d is always >= 0*/
    if (binary_op_a(GREATER, _d_27317, _36TMAXINT_DBL_21279)){
        goto L82; // [3077] 3100
    }

    /** scanner.e:1922							return {ATOM, NewIntSym(d)}*/
    Ref(_d_27317);
    _15353 = _54NewIntSym(_d_27317);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15353;
    _15354 = MAKE_SEQ(_1);
    _15353 = NOVALUE;
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15296);
    _15296 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15307);
    _15307 = NOVALUE;
    DeRef(_15295);
    _15295 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15340);
    _15340 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    _15301 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15327 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15354;
    goto L1; // [3097] 10
L82: 

    /** scanner.e:1924							return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_27317);
    _15355 = _54NewDoubleSym(_d_27317);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15355;
    _15356 = MAKE_SEQ(_1);
    _15355 = NOVALUE;
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15296);
    _15296 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15307);
    _15307 = NOVALUE;
    DeRef(_15295);
    _15295 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15340);
    _15340 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    _15301 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15327 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15356;
    goto L1; // [3119] 10
L72: 

    /** scanner.e:1929			elsif class = res:MULTIPLY then*/
    if (_class_27321 != 13)
    goto L83; // [3124] 3174

    /** scanner.e:1930				ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1931				if ch = '=' then*/
    if (_ch_27309 != 61)
    goto L84; // [3137] 3156

    /** scanner.e:1932					return {MULTIPLY_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 517;
    ((intptr_t *)_2)[2] = 0;
    _15360 = MAKE_SEQ(_1);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15296);
    _15296 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15307);
    _15307 = NOVALUE;
    DeRef(_15295);
    _15295 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15340);
    _15340 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    _15301 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15327 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15360;
    goto L1; // [3153] 10
L84: 

    /** scanner.e:1934					ungetch()*/
    _62ungetch();

    /** scanner.e:1935					return {res:MULTIPLY, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 13;
    ((intptr_t *)_2)[2] = 0;
    _15361 = MAKE_SEQ(_1);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15296);
    _15296 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15307);
    _15307 = NOVALUE;
    DeRef(_15295);
    _15295 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15340);
    _15340 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    _15301 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15327 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15361;
    goto L1; // [3171] 10
L83: 

    /** scanner.e:1938			elsif class = res:DIVIDE then*/
    if (_class_27321 != 14)
    goto L85; // [3176] 3380

    /** scanner.e:1939				ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1940				if ch = '=' then*/
    if (_ch_27309 != 61)
    goto L86; // [3189] 3208

    /** scanner.e:1941					return {DIVIDE_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 518;
    ((intptr_t *)_2)[2] = 0;
    _15365 = MAKE_SEQ(_1);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15296);
    _15296 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15307);
    _15307 = NOVALUE;
    DeRef(_15295);
    _15295 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15340);
    _15340 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    _15301 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15327 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15365;
    goto L1; // [3205] 10
L86: 

    /** scanner.e:1942				elsif ch = '*' then*/
    if (_ch_27309 != 42)
    goto L87; // [3210] 3362

    /** scanner.e:1944					cline = line_number*/
    _cline_27314 = _36line_number_21448;

    /** scanner.e:1945					integer cnest = 1*/
    _cnest_27982 = 1;

    /** scanner.e:1946					while cnest > 0 do*/
L88: 
    if (_cnest_27982 <= 0)
    goto L89; // [3233] 3341

    /** scanner.e:1947						ch = getch()*/
    _ch_27309 = _62getch();
    if (!IS_ATOM_INT(_ch_27309)) {
        _1 = (object)(DBL_PTR(_ch_27309)->dbl);
        DeRefDS(_ch_27309);
        _ch_27309 = _1;
    }

    /** scanner.e:1948						switch ch do*/
    _0 = _ch_27309;
    switch ( _0 ){ 

        /** scanner.e:1949							case  END_OF_FILE_CHAR then*/
        case 26:

        /** scanner.e:1950								exit*/
        goto L89; // [3257] 3341
        goto L88; // [3259] 3233

        /** scanner.e:1952							case '\n' then*/
        case 10:

        /** scanner.e:1953								read_line()*/
        _62read_line();
        goto L88; // [3269] 3233

        /** scanner.e:1955							case '*' then*/
        case 42:

        /** scanner.e:1956								ch = getch()*/
        _ch_27309 = _62getch();
        if (!IS_ATOM_INT(_ch_27309)) {
            _1 = (object)(DBL_PTR(_ch_27309)->dbl);
            DeRefDS(_ch_27309);
            _ch_27309 = _1;
        }

        /** scanner.e:1957								if ch = '/' then*/
        if (_ch_27309 != 47)
        goto L8A; // [3284] 3297

        /** scanner.e:1958									cnest -= 1*/
        _cnest_27982 = _cnest_27982 - 1;
        goto L88; // [3294] 3233
L8A: 

        /** scanner.e:1960									ungetch()*/
        _62ungetch();
        goto L88; // [3302] 3233

        /** scanner.e:1963							case '/' then*/
        case 47:

        /** scanner.e:1964								ch = getch()*/
        _ch_27309 = _62getch();
        if (!IS_ATOM_INT(_ch_27309)) {
            _1 = (object)(DBL_PTR(_ch_27309)->dbl);
            DeRefDS(_ch_27309);
            _ch_27309 = _1;
        }

        /** scanner.e:1965								if ch = '*' then*/
        if (_ch_27309 != 42)
        goto L8B; // [3317] 3330

        /** scanner.e:1966									cnest += 1*/
        _cnest_27982 = _cnest_27982 + 1;
        goto L8C; // [3327] 3335
L8B: 

        /** scanner.e:1968									ungetch()*/
        _62ungetch();
L8C: 
    ;}
    /** scanner.e:1972					end while*/
    goto L88; // [3338] 3233
L89: 

    /** scanner.e:1974					if cnest > 0 then*/
    if (_cnest_27982 <= 0)
    goto L8D; // [3343] 3357

    /** scanner.e:1975						CompileErr(BLOCK_COMMENT_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _50CompileErr(42, _cline_27314, 0);
L8D: 
    goto L1; // [3359] 10
L87: 

    /** scanner.e:1978					ungetch()*/
    _62ungetch();

    /** scanner.e:1979					return {res:DIVIDE, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 14;
    ((intptr_t *)_2)[2] = 0;
    _15378 = MAKE_SEQ(_1);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15296);
    _15296 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15307);
    _15307 = NOVALUE;
    DeRef(_15295);
    _15295 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15340);
    _15340 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    _15301 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15327 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15365);
    _15365 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15378;
    goto L1; // [3377] 10
L85: 

    /** scanner.e:1981			elsif class = SINGLE_QUOTE then*/
    if (_class_27321 != -5)
    goto L8E; // [3384] 3534

    /** scanner.e:1982				atom ach = getch()*/
    _0 = _ach_28012;
    _ach_28012 = _62getch();
    DeRef(_0);

    /** scanner.e:1983				if ach = '\\' then*/
    if (binary_op_a(NOTEQ, _ach_28012, 92)){
        goto L8F; // [3395] 3408
    }

    /** scanner.e:1984					ach = EscapeChar('\'')*/
    _0 = _ach_28012;
    _ach_28012 = _62EscapeChar(39);
    DeRef(_0);
    goto L90; // [3405] 3465
L8F: 

    /** scanner.e:1985				elsif ach = '\t' then*/
    if (binary_op_a(NOTEQ, _ach_28012, 9)){
        goto L91; // [3410] 3426
    }

    /** scanner.e:1986					CompileErr(MSG_TAB_CHARACTER_FOUND_IN_STRING__USE_T_INSTEAD)*/
    RefDS(_21997);
    _50CompileErr(145, _21997, 0);
    goto L90; // [3423] 3465
L91: 

    /** scanner.e:1987				elsif ach = '\'' then*/
    if (binary_op_a(NOTEQ, _ach_28012, 39)){
        goto L92; // [3428] 3444
    }

    /** scanner.e:1988					CompileErr(SINGLEQUOTE_CHARACTER_IS_EMPTY)*/
    RefDS(_21997);
    _50CompileErr(137, _21997, 0);
    goto L90; // [3441] 3465
L92: 

    /** scanner.e:1989				elsif ach = '\n' then*/
    if (binary_op_a(NOTEQ, _ach_28012, 10)){
        goto L93; // [3446] 3464
    }

    /** scanner.e:1990					CompileErr(EXPECTED_1_NOT_2, {"character", "end of line"})*/
    RefDS(_15387);
    RefDS(_15386);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _15386;
    ((intptr_t *)_2)[2] = _15387;
    _15388 = MAKE_SEQ(_1);
    _50CompileErr(68, _15388, 0);
    _15388 = NOVALUE;
L93: 
L90: 

    /** scanner.e:1992				if getch() != '\'' then*/
    _15389 = _62getch();
    if (binary_op_a(EQUALS, _15389, 39)){
        DeRef(_15389);
        _15389 = NOVALUE;
        goto L94; // [3470] 3484
    }
    DeRef(_15389);
    _15389 = NOVALUE;

    /** scanner.e:1993					CompileErr(CHARACTER_CONSTANT_IS_MISSING_A_CLOSING)*/
    RefDS(_21997);
    _50CompileErr(56, _21997, 0);
L94: 

    /** scanner.e:1995				if is_integer(ach) then*/
    Ref(_ach_28012);
    _15391 = _36is_integer(_ach_28012);
    if (_15391 == 0) {
        DeRef(_15391);
        _15391 = NOVALUE;
        goto L95; // [3490] 3512
    }
    else {
        if (!IS_ATOM_INT(_15391) && DBL_PTR(_15391)->dbl == 0.0){
            DeRef(_15391);
            _15391 = NOVALUE;
            goto L95; // [3490] 3512
        }
        DeRef(_15391);
        _15391 = NOVALUE;
    }
    DeRef(_15391);
    _15391 = NOVALUE;

    /** scanner.e:1996					return {ATOM, NewIntSym(ach)}*/
    Ref(_ach_28012);
    _15392 = _54NewIntSym(_ach_28012);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15392;
    _15393 = MAKE_SEQ(_1);
    _15392 = NOVALUE;
    DeRef(_ach_28012);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15296);
    _15296 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15307);
    _15307 = NOVALUE;
    DeRef(_15295);
    _15295 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15340);
    _15340 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15378);
    _15378 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    _15301 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15327 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15365);
    _15365 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15393;
    goto L96; // [3509] 3529
L95: 

    /** scanner.e:1998					return {ATOM, NewDoubleSym(ach)}*/
    Ref(_ach_28012);
    _15394 = _54NewDoubleSym(_ach_28012);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15394;
    _15395 = MAKE_SEQ(_1);
    _15394 = NOVALUE;
    DeRef(_ach_28012);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15296);
    _15296 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    DeRef(_15393);
    _15393 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15307);
    _15307 = NOVALUE;
    DeRef(_15295);
    _15295 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15340);
    _15340 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15378);
    _15378 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    _15301 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15327 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15365);
    _15365 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15395;
L96: 
    DeRef(_ach_28012);
    _ach_28012 = NOVALUE;
    goto L1; // [3531] 10
L8E: 

    /** scanner.e:2001			elsif class = LESS then*/
    if (_class_27321 != 1)
    goto L97; // [3538] 3586

    /** scanner.e:2002				if getch() = '=' then*/
    _15397 = _62getch();
    if (binary_op_a(NOTEQ, _15397, 61)){
        DeRef(_15397);
        _15397 = NOVALUE;
        goto L98; // [3547] 3566
    }
    DeRef(_15397);
    _15397 = NOVALUE;

    /** scanner.e:2003					return {LESSEQ, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 5;
    ((intptr_t *)_2)[2] = 0;
    _15399 = MAKE_SEQ(_1);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15296);
    _15296 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    DeRef(_15393);
    _15393 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15307);
    _15307 = NOVALUE;
    DeRef(_15295);
    _15295 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15340);
    _15340 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15378);
    _15378 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15395);
    _15395 = NOVALUE;
    _15301 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15327 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15365);
    _15365 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15399;
    goto L1; // [3563] 10
L98: 

    /** scanner.e:2005					ungetch()*/
    _62ungetch();

    /** scanner.e:2006					return {LESS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _15400 = MAKE_SEQ(_1);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15296);
    _15296 = NOVALUE;
    DeRef(_15399);
    _15399 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    DeRef(_15393);
    _15393 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15307);
    _15307 = NOVALUE;
    DeRef(_15295);
    _15295 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15340);
    _15340 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15378);
    _15378 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15395);
    _15395 = NOVALUE;
    _15301 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15327 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15365);
    _15365 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15400;
    goto L1; // [3583] 10
L97: 

    /** scanner.e:2009			elsif class = GREATER then*/
    if (_class_27321 != 6)
    goto L99; // [3590] 3638

    /** scanner.e:2010				if getch() = '=' then*/
    _15402 = _62getch();
    if (binary_op_a(NOTEQ, _15402, 61)){
        DeRef(_15402);
        _15402 = NOVALUE;
        goto L9A; // [3599] 3618
    }
    DeRef(_15402);
    _15402 = NOVALUE;

    /** scanner.e:2011					return {GREATEREQ, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 2;
    ((intptr_t *)_2)[2] = 0;
    _15404 = MAKE_SEQ(_1);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15296);
    _15296 = NOVALUE;
    DeRef(_15399);
    _15399 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    DeRef(_15393);
    _15393 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15307);
    _15307 = NOVALUE;
    DeRef(_15295);
    _15295 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15340);
    _15340 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15378);
    _15378 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15395);
    _15395 = NOVALUE;
    _15301 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15327 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15400);
    _15400 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15365);
    _15365 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15404;
    goto L1; // [3615] 10
L9A: 

    /** scanner.e:2013					ungetch()*/
    _62ungetch();

    /** scanner.e:2014					return {GREATER, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 6;
    ((intptr_t *)_2)[2] = 0;
    _15405 = MAKE_SEQ(_1);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15296);
    _15296 = NOVALUE;
    DeRef(_15399);
    _15399 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    DeRef(_15393);
    _15393 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15307);
    _15307 = NOVALUE;
    DeRef(_15295);
    _15295 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15404);
    _15404 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15340);
    _15340 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15378);
    _15378 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15395);
    _15395 = NOVALUE;
    _15301 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15327 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15400);
    _15400 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15365);
    _15365 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15405;
    goto L1; // [3635] 10
L99: 

    /** scanner.e:2017			elsif class = BANG then*/
    if (_class_27321 != -1)
    goto L9B; // [3642] 3690

    /** scanner.e:2018				if getch() = '=' then*/
    _15407 = _62getch();
    if (binary_op_a(NOTEQ, _15407, 61)){
        DeRef(_15407);
        _15407 = NOVALUE;
        goto L9C; // [3651] 3670
    }
    DeRef(_15407);
    _15407 = NOVALUE;

    /** scanner.e:2019					return {NOTEQ, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = 0;
    _15409 = MAKE_SEQ(_1);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15405);
    _15405 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15296);
    _15296 = NOVALUE;
    DeRef(_15399);
    _15399 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    DeRef(_15393);
    _15393 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15307);
    _15307 = NOVALUE;
    DeRef(_15295);
    _15295 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15404);
    _15404 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15340);
    _15340 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15378);
    _15378 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15395);
    _15395 = NOVALUE;
    _15301 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15327 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15400);
    _15400 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15365);
    _15365 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15409;
    goto L1; // [3667] 10
L9C: 

    /** scanner.e:2021					ungetch()*/
    _62ungetch();

    /** scanner.e:2022					return {BANG, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = 0;
    _15410 = MAKE_SEQ(_1);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15405);
    _15405 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15296);
    _15296 = NOVALUE;
    DeRef(_15399);
    _15399 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    DeRef(_15393);
    _15393 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15307);
    _15307 = NOVALUE;
    DeRef(_15295);
    _15295 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15404);
    _15404 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15340);
    _15340 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15378);
    _15378 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15395);
    _15395 = NOVALUE;
    _15301 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15327 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15400);
    _15400 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15365);
    _15365 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15410;
    goto L1; // [3687] 10
L9B: 

    /** scanner.e:2025			elsif class = KEYWORD then*/
    if (_class_27321 != -10)
    goto L9D; // [3694] 3727

    /** scanner.e:2026				return {keylist[ch - KEYWORD_BASE][K_TOKEN], 0}*/
    _15412 = _ch_27309 - 128;
    _2 = (object)SEQ_PTR(_63keylist_23121);
    _15413 = (object)*(((s1_ptr)_2)->base + _15412);
    _2 = (object)SEQ_PTR(_15413);
    _15414 = (object)*(((s1_ptr)_2)->base + 3);
    _15413 = NOVALUE;
    Ref(_15414);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _15414;
    ((intptr_t *)_2)[2] = 0;
    _15415 = MAKE_SEQ(_1);
    _15414 = NOVALUE;
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15405);
    _15405 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15296);
    _15296 = NOVALUE;
    DeRef(_15399);
    _15399 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    DeRef(_15393);
    _15393 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    _15412 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15307);
    _15307 = NOVALUE;
    DeRef(_15295);
    _15295 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15404);
    _15404 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15340);
    _15340 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15378);
    _15378 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15395);
    _15395 = NOVALUE;
    _15301 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15327 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15410);
    _15410 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15400);
    _15400 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15365);
    _15365 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15415;
    goto L1; // [3724] 10
L9D: 

    /** scanner.e:2028			elsif class = BUILTIN then*/
    if (_class_27321 != -9)
    goto L9E; // [3731] 3784

    /** scanner.e:2029				name = keylist[ch - BUILTIN_BASE + NUM_KEYWORDS][K_NAME]*/
    _15417 = _ch_27309 - 170;
    if ((object)((uintptr_t)_15417 +(uintptr_t) HIGH_BITS) >= 0){
        _15417 = NewDouble((eudouble)_15417);
    }
    if (IS_ATOM_INT(_15417)) {
        _15418 = _15417 + 24;
    }
    else {
        _15418 = NewDouble(DBL_PTR(_15417)->dbl + (eudouble)24);
    }
    DeRef(_15417);
    _15417 = NOVALUE;
    _2 = (object)SEQ_PTR(_63keylist_23121);
    if (!IS_ATOM_INT(_15418)){
        _15419 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15418)->dbl));
    }
    else{
        _15419 = (object)*(((s1_ptr)_2)->base + _15418);
    }
    DeRef(_name_27322);
    _2 = (object)SEQ_PTR(_15419);
    _name_27322 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_name_27322);
    _15419 = NOVALUE;

    /** scanner.e:2030				return keyfind(name, -1)*/
    RefDS(_name_27322);
    _31715 = _54hashfn(_name_27322);
    RefDS(_name_27322);
    _15421 = _54keyfind(_name_27322, -1, _36current_file_no_21447, 0, _31715);
    _31715 = NOVALUE;
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRefDS(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15405);
    _15405 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15296);
    _15296 = NOVALUE;
    DeRef(_15399);
    _15399 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    DeRef(_15393);
    _15393 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15418);
    _15418 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    DeRef(_15412);
    _15412 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15307);
    _15307 = NOVALUE;
    DeRef(_15295);
    _15295 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15404);
    _15404 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15415);
    _15415 = NOVALUE;
    DeRef(_15340);
    _15340 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15378);
    _15378 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15395);
    _15395 = NOVALUE;
    _15301 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15327 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15410);
    _15410 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15400);
    _15400 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15365);
    _15365 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15421;
    goto L1; // [3781] 10
L9E: 

    /** scanner.e:2032			elsif class = BACK_QUOTE then*/
    if (_class_27321 != -12)
    goto L9F; // [3788] 3805

    /** scanner.e:2033				return ExtendedString( '`' )*/
    _15423 = _62ExtendedString(96);
    DeRef(_i_27312);
    DeRef(_yytext_27315);
    DeRef(_namespaces_27316);
    DeRef(_d_27317);
    DeRef(_tok_27319);
    DeRef(_name_27322);
    DeRef(_15058);
    _15058 = NOVALUE;
    DeRef(_15271);
    _15271 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    _15230 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    _15097 = NOVALUE;
    DeRef(_15067);
    _15067 = NOVALUE;
    _15208 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15405);
    _15405 = NOVALUE;
    DeRef(_15174);
    _15174 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    _15234 = NOVALUE;
    DeRef(_15224);
    _15224 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15296);
    _15296 = NOVALUE;
    DeRef(_15399);
    _15399 = NOVALUE;
    DeRef(_15046);
    _15046 = NOVALUE;
    DeRef(_15246);
    _15246 = NOVALUE;
    DeRef(_15393);
    _15393 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15418);
    _15418 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    DeRef(_15092);
    _15092 = NOVALUE;
    _15083 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15421);
    _15421 = NOVALUE;
    DeRef(_15222);
    _15222 = NOVALUE;
    DeRef(_15412);
    _15412 = NOVALUE;
    _15119 = NOVALUE;
    DeRef(_15064);
    _15064 = NOVALUE;
    _15108 = NOVALUE;
    DeRef(_15263);
    _15263 = NOVALUE;
    DeRef(_15307);
    _15307 = NOVALUE;
    DeRef(_15295);
    _15295 = NOVALUE;
    DeRef(_15189);
    _15189 = NOVALUE;
    DeRef(_15272);
    _15272 = NOVALUE;
    DeRef(_15118);
    _15118 = NOVALUE;
    DeRef(_15404);
    _15404 = NOVALUE;
    DeRef(_15256);
    _15256 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15415);
    _15415 = NOVALUE;
    DeRef(_15340);
    _15340 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15061);
    _15061 = NOVALUE;
    _15134 = NOVALUE;
    DeRef(_15378);
    _15378 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15395);
    _15395 = NOVALUE;
    _15301 = NOVALUE;
    _15187 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    _15177 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15327 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15410);
    _15410 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15055);
    _15055 = NOVALUE;
    DeRef(_15400);
    _15400 = NOVALUE;
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15365);
    _15365 = NOVALUE;
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15167);
    _15167 = NOVALUE;
    return _15423;
    goto L1; // [3802] 10
L9F: 

    /** scanner.e:2036				InternalErr(268, {class})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _class_27321;
    _15424 = MAKE_SEQ(_1);
    _50InternalErr(268, _15424);
    _15424 = NOVALUE;

    /** scanner.e:2039	   end while*/
    goto L1; // [3818] 10
L2: 
    ;
}


void _62eu_namespace()
{
    object _eu_tok_28114 = NOVALUE;
    object _eu_ns_28116 = NOVALUE;
    object _31714 = NOVALUE;
    object _31713 = NOVALUE;
    object _15433 = NOVALUE;
    object _15431 = NOVALUE;
    object _15429 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:2047		eu_tok = keyfind("eu", -1, , 1)*/
    RefDS(_15427);
    _31713 = _15427;
    _31714 = _54hashfn(_31713);
    _31713 = NOVALUE;
    RefDS(_15427);
    _0 = _eu_tok_28114;
    _eu_tok_28114 = _54keyfind(_15427, -1, _36current_file_no_21447, 1, _31714);
    DeRef(_0);
    _31714 = NOVALUE;

    /** scanner.e:2050		eu_ns  = NameSpace_declaration(eu_tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_eu_tok_28114);
    _15429 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_15429);
    _eu_ns_28116 = _62NameSpace_declaration(_15429);
    _15429 = NOVALUE;
    if (!IS_ATOM_INT(_eu_ns_28116)) {
        _1 = (object)(DBL_PTR(_eu_ns_28116)->dbl);
        DeRefDS(_eu_ns_28116);
        _eu_ns_28116 = _1;
    }

    /** scanner.e:2051		SymTab[eu_ns][S_OBJ] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_eu_ns_28116 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _15431 = NOVALUE;

    /** scanner.e:2052		SymTab[eu_ns][S_SCOPE] = SC_GLOBAL*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_eu_ns_28116 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 6;
    DeRef(_1);
    _15433 = NOVALUE;

    /** scanner.e:2053	end procedure*/
    DeRef(_eu_tok_28114);
    return;
    ;
}


object _62StringToken(object _pDelims_28134)
{
    object _ch_28135 = NOVALUE;
    object _m_28136 = NOVALUE;
    object _gtext_28137 = NOVALUE;
    object _level_28168 = NOVALUE;
    object _15472 = NOVALUE;
    object _15470 = NOVALUE;
    object _15468 = NOVALUE;
    object _15449 = NOVALUE;
    object _15448 = NOVALUE;
    object _15442 = NOVALUE;
    object _15440 = NOVALUE;
    object _15438 = NOVALUE;
    object _15436 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2064		ch = getch()*/
    _ch_28135 = _62getch();
    if (!IS_ATOM_INT(_ch_28135)) {
        _1 = (object)(DBL_PTR(_ch_28135)->dbl);
        DeRefDS(_ch_28135);
        _ch_28135 = _1;
    }

    /** scanner.e:2065		while ch = ' ' or ch = '\t' do*/
L1: 
    _15436 = (_ch_28135 == 32);
    if (_15436 != 0) {
        goto L2; // [19] 32
    }
    _15438 = (_ch_28135 == 9);
    if (_15438 == 0)
    {
        DeRef(_15438);
        _15438 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_15438);
        _15438 = NOVALUE;
    }
L2: 

    /** scanner.e:2066			ch = getch()*/
    _ch_28135 = _62getch();
    if (!IS_ATOM_INT(_ch_28135)) {
        _1 = (object)(DBL_PTR(_ch_28135)->dbl);
        DeRefDS(_ch_28135);
        _ch_28135 = _1;
    }

    /** scanner.e:2067		end while*/
    goto L1; // [41] 15
L3: 

    /** scanner.e:2069		pDelims &= {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 32;
    ((intptr_t*)_2)[2] = 9;
    ((intptr_t*)_2)[3] = 10;
    ((intptr_t*)_2)[4] = 13;
    ((intptr_t*)_2)[5] = 26;
    _15440 = MAKE_SEQ(_1);
    Concat((object_ptr)&_pDelims_28134, _pDelims_28134, _15440);
    DeRefDS(_15440);
    _15440 = NOVALUE;

    /** scanner.e:2070		gtext = ""*/
    RefDS(_5);
    DeRefi(_gtext_28137);
    _gtext_28137 = _5;

    /** scanner.e:2071		while not find(ch,  pDelims) label "top" do*/
L4: 
    _15442 = find_from(_ch_28135, _pDelims_28134, 1);
    if (_15442 != 0)
    goto L5; // [77] 391
    _15442 = NOVALUE;

    /** scanner.e:2072			if ch = '-' then*/
    if (_ch_28135 != 45)
    goto L6; // [82] 145

    /** scanner.e:2073				ch = getch()*/
    _ch_28135 = _62getch();
    if (!IS_ATOM_INT(_ch_28135)) {
        _1 = (object)(DBL_PTR(_ch_28135)->dbl);
        DeRefDS(_ch_28135);
        _ch_28135 = _1;
    }

    /** scanner.e:2074				if ch = '-' then*/
    if (_ch_28135 != 45)
    goto L7; // [95] 137

    /** scanner.e:2075					while not find(ch, {'\n', END_OF_FILE_CHAR}) do*/
L8: 
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 10;
    ((intptr_t *)_2)[2] = 26;
    _15448 = MAKE_SEQ(_1);
    _15449 = find_from(_ch_28135, _15448, 1);
    DeRefDS(_15448);
    _15448 = NOVALUE;
    if (_15449 != 0)
    goto L5; // [115] 391
    _15449 = NOVALUE;

    /** scanner.e:2076						ch = getch()*/
    _ch_28135 = _62getch();
    if (!IS_ATOM_INT(_ch_28135)) {
        _1 = (object)(DBL_PTR(_ch_28135)->dbl);
        DeRefDS(_ch_28135);
        _ch_28135 = _1;
    }

    /** scanner.e:2077					end while*/
    goto L8; // [127] 104

    /** scanner.e:2078					exit*/
    goto L5; // [132] 391
    goto L9; // [134] 373
L7: 

    /** scanner.e:2080					ungetch()*/
    _62ungetch();
    goto L9; // [142] 373
L6: 

    /** scanner.e:2082			elsif ch = '/' then*/
    if (_ch_28135 != 47)
    goto LA; // [147] 372

    /** scanner.e:2083				ch = getch()*/
    _ch_28135 = _62getch();
    if (!IS_ATOM_INT(_ch_28135)) {
        _1 = (object)(DBL_PTR(_ch_28135)->dbl);
        DeRefDS(_ch_28135);
        _ch_28135 = _1;
    }

    /** scanner.e:2084				if ch = '*' then*/
    if (_ch_28135 != 42)
    goto LB; // [160] 361

    /** scanner.e:2085					integer level = 1*/
    _level_28168 = 1;

    /** scanner.e:2086					while level > 0 do*/
LC: 
    if (_level_28168 <= 0)
    goto LD; // [174] 293

    /** scanner.e:2087						ch = getch()*/
    _ch_28135 = _62getch();
    if (!IS_ATOM_INT(_ch_28135)) {
        _1 = (object)(DBL_PTR(_ch_28135)->dbl);
        DeRefDS(_ch_28135);
        _ch_28135 = _1;
    }

    /** scanner.e:2088						if ch = '/' then*/
    if (_ch_28135 != 47)
    goto LE; // [187] 221

    /** scanner.e:2089							ch = getch()*/
    _ch_28135 = _62getch();
    if (!IS_ATOM_INT(_ch_28135)) {
        _1 = (object)(DBL_PTR(_ch_28135)->dbl);
        DeRefDS(_ch_28135);
        _ch_28135 = _1;
    }

    /** scanner.e:2090							if ch = '*' then*/
    if (_ch_28135 != 42)
    goto LF; // [200] 213

    /** scanner.e:2091								level += 1*/
    _level_28168 = _level_28168 + 1;
    goto LC; // [210] 174
LF: 

    /** scanner.e:2093								ungetch()*/
    _62ungetch();
    goto LC; // [218] 174
LE: 

    /** scanner.e:2095						elsif ch = '*' then*/
    if (_ch_28135 != 42)
    goto L10; // [223] 257

    /** scanner.e:2096							ch = getch()*/
    _ch_28135 = _62getch();
    if (!IS_ATOM_INT(_ch_28135)) {
        _1 = (object)(DBL_PTR(_ch_28135)->dbl);
        DeRefDS(_ch_28135);
        _ch_28135 = _1;
    }

    /** scanner.e:2097							if ch = '/' then*/
    if (_ch_28135 != 47)
    goto L11; // [236] 249

    /** scanner.e:2098								level -= 1*/
    _level_28168 = _level_28168 - 1;
    goto LC; // [246] 174
L11: 

    /** scanner.e:2100								ungetch()*/
    _62ungetch();
    goto LC; // [254] 174
L10: 

    /** scanner.e:2102						elsif ch = '\n' then*/
    if (_ch_28135 != 10)
    goto L12; // [259] 270

    /** scanner.e:2103							read_line()*/
    _62read_line();
    goto LC; // [267] 174
L12: 

    /** scanner.e:2104						elsif ch = END_OF_FILE_CHAR then*/
    if (_ch_28135 != 26)
    goto LC; // [274] 174

    /** scanner.e:2105							ungetch()*/
    _62ungetch();

    /** scanner.e:2106							exit*/
    goto LD; // [284] 293

    /** scanner.e:2108					end while*/
    goto LC; // [290] 174
LD: 

    /** scanner.e:2109					ch = getch()*/
    _ch_28135 = _62getch();
    if (!IS_ATOM_INT(_ch_28135)) {
        _1 = (object)(DBL_PTR(_ch_28135)->dbl);
        DeRefDS(_ch_28135);
        _ch_28135 = _1;
    }

    /** scanner.e:2110					if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_28137)){
            _15468 = SEQ_PTR(_gtext_28137)->length;
    }
    else {
        _15468 = 1;
    }
    if (_15468 != 0)
    goto L13; // [305] 350

    /** scanner.e:2111						while ch = ' ' or ch = '\t' do*/
L14: 
    _15470 = (_ch_28135 == 32);
    if (_15470 != 0) {
        goto L15; // [318] 331
    }
    _15472 = (_ch_28135 == 9);
    if (_15472 == 0)
    {
        DeRef(_15472);
        _15472 = NOVALUE;
        goto L16; // [327] 343
    }
    else{
        DeRef(_15472);
        _15472 = NOVALUE;
    }
L15: 

    /** scanner.e:2112							ch = getch()*/
    _ch_28135 = _62getch();
    if (!IS_ATOM_INT(_ch_28135)) {
        _1 = (object)(DBL_PTR(_ch_28135)->dbl);
        DeRefDS(_ch_28135);
        _ch_28135 = _1;
    }

    /** scanner.e:2113						end while*/
    goto L14; // [340] 314
L16: 

    /** scanner.e:2114						continue "top"*/
    goto L4; // [347] 72
L13: 

    /** scanner.e:2116					exit*/
    goto L5; // [354] 391
    goto L17; // [358] 371
LB: 

    /** scanner.e:2119					ungetch()*/
    _62ungetch();

    /** scanner.e:2120					ch = '/'*/
    _ch_28135 = 47;
L17: 
LA: 
L9: 

    /** scanner.e:2123			gtext &= ch*/
    Append(&_gtext_28137, _gtext_28137, _ch_28135);

    /** scanner.e:2124			ch = getch()*/
    _ch_28135 = _62getch();
    if (!IS_ATOM_INT(_ch_28135)) {
        _1 = (object)(DBL_PTR(_ch_28135)->dbl);
        DeRefDS(_ch_28135);
        _ch_28135 = _1;
    }

    /** scanner.e:2125		end while*/
    goto L4; // [388] 72
L5: 

    /** scanner.e:2127		ungetch() -- put back end-word token.*/
    _62ungetch();

    /** scanner.e:2129		return gtext*/
    DeRefDSi(_pDelims_28134);
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    return _gtext_28137;
    ;
}


void _62IncludeScan(object _is_public_28205)
{
    object _ch_28206 = NOVALUE;
    object _gtext_28207 = NOVALUE;
    object _s_28209 = NOVALUE;
    object _31712 = NOVALUE;
    object _15535 = NOVALUE;
    object _15534 = NOVALUE;
    object _15532 = NOVALUE;
    object _15530 = NOVALUE;
    object _15529 = NOVALUE;
    object _15524 = NOVALUE;
    object _15521 = NOVALUE;
    object _15519 = NOVALUE;
    object _15518 = NOVALUE;
    object _15516 = NOVALUE;
    object _15514 = NOVALUE;
    object _15512 = NOVALUE;
    object _15510 = NOVALUE;
    object _15504 = NOVALUE;
    object _15502 = NOVALUE;
    object _15497 = NOVALUE;
    object _15493 = NOVALUE;
    object _15492 = NOVALUE;
    object _15487 = NOVALUE;
    object _15484 = NOVALUE;
    object _15483 = NOVALUE;
    object _15479 = NOVALUE;
    object _15477 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2149		ch = getch()*/
    _ch_28206 = _62getch();
    if (!IS_ATOM_INT(_ch_28206)) {
        _1 = (object)(DBL_PTR(_ch_28206)->dbl);
        DeRefDS(_ch_28206);
        _ch_28206 = _1;
    }

    /** scanner.e:2150		while ch = ' ' or ch = '\t' do*/
L1: 
    _15477 = (_ch_28206 == 32);
    if (_15477 != 0) {
        goto L2; // [19] 32
    }
    _15479 = (_ch_28206 == 9);
    if (_15479 == 0)
    {
        DeRef(_15479);
        _15479 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_15479);
        _15479 = NOVALUE;
    }
L2: 

    /** scanner.e:2151			ch = getch()*/
    _ch_28206 = _62getch();
    if (!IS_ATOM_INT(_ch_28206)) {
        _1 = (object)(DBL_PTR(_ch_28206)->dbl);
        DeRefDS(_ch_28206);
        _ch_28206 = _1;
    }

    /** scanner.e:2152		end while*/
    goto L1; // [41] 15
L3: 

    /** scanner.e:2155		gtext = ""*/
    RefDS(_5);
    DeRef(_gtext_28207);
    _gtext_28207 = _5;

    /** scanner.e:2157		if ch = '"' then*/
    if (_ch_28206 != 34)
    goto L4; // [53] 143

    /** scanner.e:2159			ch = getch()*/
    _ch_28206 = _62getch();
    if (!IS_ATOM_INT(_ch_28206)) {
        _1 = (object)(DBL_PTR(_ch_28206)->dbl);
        DeRefDS(_ch_28206);
        _ch_28206 = _1;
    }

    /** scanner.e:2160			while not find(ch, {'\n', '\r', '"', END_OF_FILE_CHAR}) do*/
L5: 
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 10;
    ((intptr_t*)_2)[2] = 13;
    ((intptr_t*)_2)[3] = 34;
    ((intptr_t*)_2)[4] = 26;
    _15483 = MAKE_SEQ(_1);
    _15484 = find_from(_ch_28206, _15483, 1);
    DeRefDS(_15483);
    _15483 = NOVALUE;
    if (_15484 != 0)
    goto L6; // [83] 124
    _15484 = NOVALUE;

    /** scanner.e:2161				if ch = '\\' then*/
    if (_ch_28206 != 92)
    goto L7; // [88] 105

    /** scanner.e:2162					gtext &= EscapeChar('"')*/
    _15487 = _62EscapeChar(34);
    if (IS_SEQUENCE(_gtext_28207) && IS_ATOM(_15487)) {
        Ref(_15487);
        Append(&_gtext_28207, _gtext_28207, _15487);
    }
    else if (IS_ATOM(_gtext_28207) && IS_SEQUENCE(_15487)) {
    }
    else {
        Concat((object_ptr)&_gtext_28207, _gtext_28207, _15487);
    }
    DeRef(_15487);
    _15487 = NOVALUE;
    goto L8; // [102] 112
L7: 

    /** scanner.e:2164					gtext &= ch*/
    Append(&_gtext_28207, _gtext_28207, _ch_28206);
L8: 

    /** scanner.e:2166				ch = getch()*/
    _ch_28206 = _62getch();
    if (!IS_ATOM_INT(_ch_28206)) {
        _1 = (object)(DBL_PTR(_ch_28206)->dbl);
        DeRefDS(_ch_28206);
        _ch_28206 = _1;
    }

    /** scanner.e:2167			end while*/
    goto L5; // [121] 69
L6: 

    /** scanner.e:2168			if ch != '"' then*/
    if (_ch_28206 == 34)
    goto L9; // [126] 189

    /** scanner.e:2169				CompileErr(MISSING_CLOSING_QUOTE_ON_FILE_NAME)*/
    RefDS(_21997);
    _50CompileErr(115, _21997, 0);
    goto L9; // [140] 189
L4: 

    /** scanner.e:2173			while not find(ch, {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}) do*/
LA: 
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 32;
    ((intptr_t*)_2)[2] = 9;
    ((intptr_t*)_2)[3] = 10;
    ((intptr_t*)_2)[4] = 13;
    ((intptr_t*)_2)[5] = 26;
    _15492 = MAKE_SEQ(_1);
    _15493 = find_from(_ch_28206, _15492, 1);
    DeRefDS(_15492);
    _15492 = NOVALUE;
    if (_15493 != 0)
    goto LB; // [163] 184
    _15493 = NOVALUE;

    /** scanner.e:2174				gtext &= ch*/
    Append(&_gtext_28207, _gtext_28207, _ch_28206);

    /** scanner.e:2175				ch = getch()*/
    _ch_28206 = _62getch();
    if (!IS_ATOM_INT(_ch_28206)) {
        _1 = (object)(DBL_PTR(_ch_28206)->dbl);
        DeRefDS(_ch_28206);
        _ch_28206 = _1;
    }

    /** scanner.e:2176			end while*/
    goto LA; // [181] 148
LB: 

    /** scanner.e:2177			ungetch()*/
    _62ungetch();
L9: 

    /** scanner.e:2180		if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_28207)){
            _15497 = SEQ_PTR(_gtext_28207)->length;
    }
    else {
        _15497 = 1;
    }
    if (_15497 != 0)
    goto LC; // [194] 208

    /** scanner.e:2181			CompileErr(FILE_NAME_IS_MISSING)*/
    RefDS(_21997);
    _50CompileErr(95, _21997, 0);
LC: 

    /** scanner.e:2185		ifdef WINDOWS then*/

    /** scanner.e:2188			new_include_name = gtext*/
    RefDS(_gtext_28207);
    DeRef(_36new_include_name_21573);
    _36new_include_name_21573 = _gtext_28207;

    /** scanner.e:2192		ch = getch()*/
    _ch_28206 = _62getch();
    if (!IS_ATOM_INT(_ch_28206)) {
        _1 = (object)(DBL_PTR(_ch_28206)->dbl);
        DeRefDS(_ch_28206);
        _ch_28206 = _1;
    }

    /** scanner.e:2193		while ch = ' ' or ch = '\t' do*/
LD: 
    _15502 = (_ch_28206 == 32);
    if (_15502 != 0) {
        goto LE; // [233] 246
    }
    _15504 = (_ch_28206 == 9);
    if (_15504 == 0)
    {
        DeRef(_15504);
        _15504 = NOVALUE;
        goto LF; // [242] 258
    }
    else{
        DeRef(_15504);
        _15504 = NOVALUE;
    }
LE: 

    /** scanner.e:2194			ch = getch()*/
    _ch_28206 = _62getch();
    if (!IS_ATOM_INT(_ch_28206)) {
        _1 = (object)(DBL_PTR(_ch_28206)->dbl);
        DeRefDS(_ch_28206);
        _ch_28206 = _1;
    }

    /** scanner.e:2195		end while*/
    goto LD; // [255] 229
LF: 

    /** scanner.e:2197		new_include_space = 0*/
    _62new_include_space_25551 = 0;

    /** scanner.e:2199		if ch = 'a' then*/
    if (_ch_28206 != 97)
    goto L10; // [267] 532

    /** scanner.e:2201			ch = getch()*/
    _ch_28206 = _62getch();
    if (!IS_ATOM_INT(_ch_28206)) {
        _1 = (object)(DBL_PTR(_ch_28206)->dbl);
        DeRefDS(_ch_28206);
        _ch_28206 = _1;
    }

    /** scanner.e:2202			if ch = 's' then*/
    if (_ch_28206 != 115)
    goto L11; // [280] 519

    /** scanner.e:2203				ch = getch()*/
    _ch_28206 = _62getch();
    if (!IS_ATOM_INT(_ch_28206)) {
        _1 = (object)(DBL_PTR(_ch_28206)->dbl);
        DeRefDS(_ch_28206);
        _ch_28206 = _1;
    }

    /** scanner.e:2204				if ch = ' ' or ch = '\t' then*/
    _15510 = (_ch_28206 == 32);
    if (_15510 != 0) {
        goto L12; // [297] 310
    }
    _15512 = (_ch_28206 == 9);
    if (_15512 == 0)
    {
        DeRef(_15512);
        _15512 = NOVALUE;
        goto L13; // [306] 506
    }
    else{
        DeRef(_15512);
        _15512 = NOVALUE;
    }
L12: 

    /** scanner.e:2207					ch = getch()*/
    _ch_28206 = _62getch();
    if (!IS_ATOM_INT(_ch_28206)) {
        _1 = (object)(DBL_PTR(_ch_28206)->dbl);
        DeRefDS(_ch_28206);
        _ch_28206 = _1;
    }

    /** scanner.e:2208					while ch = ' ' or ch = '\t' do*/
L14: 
    _15514 = (_ch_28206 == 32);
    if (_15514 != 0) {
        goto L15; // [326] 339
    }
    _15516 = (_ch_28206 == 9);
    if (_15516 == 0)
    {
        DeRef(_15516);
        _15516 = NOVALUE;
        goto L16; // [335] 351
    }
    else{
        DeRef(_15516);
        _15516 = NOVALUE;
    }
L15: 

    /** scanner.e:2209						ch = getch()*/
    _ch_28206 = _62getch();
    if (!IS_ATOM_INT(_ch_28206)) {
        _1 = (object)(DBL_PTR(_ch_28206)->dbl);
        DeRefDS(_ch_28206);
        _ch_28206 = _1;
    }

    /** scanner.e:2210					end while*/
    goto L14; // [348] 322
L16: 

    /** scanner.e:2213					if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (object)SEQ_PTR(_62char_class_25560);
    _15518 = (object)*(((s1_ptr)_2)->base + _ch_28206);
    _15519 = (_15518 == -2);
    _15518 = NOVALUE;
    if (_15519 != 0) {
        goto L17; // [365] 378
    }
    _15521 = (_ch_28206 == 95);
    if (_15521 == 0)
    {
        DeRef(_15521);
        _15521 = NOVALUE;
        goto L18; // [374] 493
    }
    else{
        DeRef(_15521);
        _15521 = NOVALUE;
    }
L17: 

    /** scanner.e:2214						gtext = {ch}*/
    _0 = _gtext_28207;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ch_28206;
    _gtext_28207 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:2215						ch = getch()*/
    _ch_28206 = _62getch();
    if (!IS_ATOM_INT(_ch_28206)) {
        _1 = (object)(DBL_PTR(_ch_28206)->dbl);
        DeRefDS(_ch_28206);
        _ch_28206 = _1;
    }

    /** scanner.e:2216						while id_char[ch] = TRUE do*/
L19: 
    _2 = (object)SEQ_PTR(_62id_char_25561);
    _15524 = (object)*(((s1_ptr)_2)->base + _ch_28206);
    if (_15524 != _13TRUE_452)
    goto L1A; // [404] 426

    /** scanner.e:2217							gtext &= ch*/
    Append(&_gtext_28207, _gtext_28207, _ch_28206);

    /** scanner.e:2218							ch = getch()*/
    _ch_28206 = _62getch();
    if (!IS_ATOM_INT(_ch_28206)) {
        _1 = (object)(DBL_PTR(_ch_28206)->dbl);
        DeRefDS(_ch_28206);
        _ch_28206 = _1;
    }

    /** scanner.e:2219						end while*/
    goto L19; // [423] 396
L1A: 

    /** scanner.e:2221						ungetch()*/
    _62ungetch();

    /** scanner.e:2222						s = keyfind(gtext, -1, , 1)*/
    RefDS(_gtext_28207);
    _31712 = _54hashfn(_gtext_28207);
    RefDS(_gtext_28207);
    _0 = _s_28209;
    _s_28209 = _54keyfind(_gtext_28207, -1, _36current_file_no_21447, 1, _31712);
    DeRef(_0);
    _31712 = NOVALUE;

    /** scanner.e:2223						if not find(s[T_ID], ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_s_28209);
    _15529 = (object)*(((s1_ptr)_2)->base + 1);
    _15530 = find_from(_15529, _38ID_TOKS_16051, 1);
    _15529 = NOVALUE;
    if (_15530 != 0)
    goto L1B; // [463] 476
    _15530 = NOVALUE;

    /** scanner.e:2224							CompileErr(A_NEW_NAMESPACE_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_21997);
    _50CompileErr(36, _21997, 0);
L1B: 

    /** scanner.e:2226						new_include_space = NameSpace_declaration(s[T_SYM])*/
    _2 = (object)SEQ_PTR(_s_28209);
    _15532 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_15532);
    _0 = _62NameSpace_declaration(_15532);
    _62new_include_space_25551 = _0;
    _15532 = NOVALUE;
    if (!IS_ATOM_INT(_62new_include_space_25551)) {
        _1 = (object)(DBL_PTR(_62new_include_space_25551)->dbl);
        DeRefDS(_62new_include_space_25551);
        _62new_include_space_25551 = _1;
    }
    goto L1C; // [490] 647
L18: 

    /** scanner.e:2228						CompileErr(MISSING_NAMESPACE_QUALIFIER)*/
    RefDS(_21997);
    _50CompileErr(113, _21997, 0);
    goto L1C; // [503] 647
L13: 

    /** scanner.e:2231					CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_21997);
    _50CompileErr(100, _21997, 0);
    goto L1C; // [516] 647
L11: 

    /** scanner.e:2234				CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_21997);
    _50CompileErr(100, _21997, 0);
    goto L1C; // [529] 647
L10: 

    /** scanner.e:2237		elsif find(ch, {'\n', '\r', END_OF_FILE_CHAR}) then*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 10;
    ((intptr_t*)_2)[2] = 13;
    ((intptr_t*)_2)[3] = 26;
    _15534 = MAKE_SEQ(_1);
    _15535 = find_from(_ch_28206, _15534, 1);
    DeRefDS(_15534);
    _15534 = NOVALUE;
    if (_15535 == 0)
    {
        _15535 = NOVALUE;
        goto L1D; // [547] 557
    }
    else{
        _15535 = NOVALUE;
    }

    /** scanner.e:2238			ungetch()*/
    _62ungetch();
    goto L1C; // [554] 647
L1D: 

    /** scanner.e:2240		elsif ch = '-' then*/
    if (_ch_28206 != 45)
    goto L1E; // [559] 597

    /** scanner.e:2241			ch = getch()*/
    _ch_28206 = _62getch();
    if (!IS_ATOM_INT(_ch_28206)) {
        _1 = (object)(DBL_PTR(_ch_28206)->dbl);
        DeRefDS(_ch_28206);
        _ch_28206 = _1;
    }

    /** scanner.e:2242			if ch != '-' then*/
    if (_ch_28206 == 45)
    goto L1F; // [572] 586

    /** scanner.e:2243				CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_21997);
    _50CompileErr(100, _21997, 0);
L1F: 

    /** scanner.e:2245			ungetch()*/
    _62ungetch();

    /** scanner.e:2246			ungetch()*/
    _62ungetch();
    goto L1C; // [594] 647
L1E: 

    /** scanner.e:2248		elsif ch = '/' then*/
    if (_ch_28206 != 47)
    goto L20; // [599] 637

    /** scanner.e:2249			ch = getch()*/
    _ch_28206 = _62getch();
    if (!IS_ATOM_INT(_ch_28206)) {
        _1 = (object)(DBL_PTR(_ch_28206)->dbl);
        DeRefDS(_ch_28206);
        _ch_28206 = _1;
    }

    /** scanner.e:2250			if ch != '*' then*/
    if (_ch_28206 == 42)
    goto L21; // [612] 626

    /** scanner.e:2251				CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_21997);
    _50CompileErr(100, _21997, 0);
L21: 

    /** scanner.e:2253			ungetch()*/
    _62ungetch();

    /** scanner.e:2254			ungetch()*/
    _62ungetch();
    goto L1C; // [634] 647
L20: 

    /** scanner.e:2257			CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_21997);
    _50CompileErr(100, _21997, 0);
L1C: 

    /** scanner.e:2260		start_include = TRUE -- let scanner know*/
    _62start_include_25553 = _13TRUE_452;

    /** scanner.e:2261		public_include = is_public*/
    _62public_include_25556 = _is_public_28205;

    /** scanner.e:2262	end procedure*/
    DeRef(_gtext_28207);
    DeRef(_s_28209);
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15519);
    _15519 = NOVALUE;
    DeRef(_15510);
    _15510 = NOVALUE;
    DeRef(_15514);
    _15514 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    _15524 = NOVALUE;
    return;
    ;
}


void _62main_file()
{
    object _15544 = NOVALUE;
    object _15543 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2275		if repl and top_level_block = -1 then*/
    if (0 == 0) {
        goto L1; // [5] 29
    }
    _15544 = (_65top_level_block_25121 == -1);
    if (_15544 == 0)
    {
        DeRef(_15544);
        _15544 = NOVALUE;
        goto L1; // [16] 29
    }
    else{
        DeRef(_15544);
        _15544 = NOVALUE;
    }

    /** scanner.e:2276			top_level_block = current_block*/
    _65top_level_block_25121 = _65current_block_25120;
L1: 

    /** scanner.e:2278		ifdef STDDEBUG then*/

    /** scanner.e:2283			read_line()*/
    _62read_line();

    /** scanner.e:2284			default_namespace( )*/
    _62default_namespace();

    /** scanner.e:2286	end procedure*/
    return;
    ;
}


void _62cleanup_open_includes()
{
    object _15547 = NOVALUE;
    object _15546 = NOVALUE;
    object _15545 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2289		for i = 1 to length( IncludeStk ) do*/
    if (IS_SEQUENCE(_62IncludeStk_25562)){
            _15545 = SEQ_PTR(_62IncludeStk_25562)->length;
    }
    else {
        _15545 = 1;
    }
    {
        object _i_28344;
        _i_28344 = 1;
L1: 
        if (_i_28344 > _15545){
            goto L2; // [8] 36
        }

        /** scanner.e:2290			close( IncludeStk[i][FILE_PTR] )*/
        _2 = (object)SEQ_PTR(_62IncludeStk_25562);
        _15546 = (object)*(((s1_ptr)_2)->base + _i_28344);
        _2 = (object)SEQ_PTR(_15546);
        _15547 = (object)*(((s1_ptr)_2)->base + 3);
        _15546 = NOVALUE;
        if (IS_ATOM_INT(_15547))
        EClose(_15547);
        else
        EClose((object)DBL_PTR(_15547)->dbl);
        _15547 = NOVALUE;

        /** scanner.e:2291		end for*/
        _i_28344 = _i_28344 + 1;
        goto L1; // [31] 15
L2: 
        ;
    }

    /** scanner.e:2292	end procedure*/
    return;
    ;
}



// 0x8D001B65
