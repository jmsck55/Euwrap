// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _46host_platform()
{
    object _0, _1, _2;
    

    /** platform.e:113		return ihost_platform*/
    return _46ihost_platform_21619;
    ;
}


void _46set_host_platform(object _plat_21626)
{
    object _12176 = NOVALUE;
    object _0, _1, _2;
    

    /** platform.e:119		ihost_platform = floor(plat)*/
    _46ihost_platform_21619 = e_floor(_plat_21626);

    /** platform.e:121		TUNIX    = (find(ihost_platform, unices) != 0) */
    _12176 = find_from(_46ihost_platform_21619, _46unices_21622, 1);
    _46TUNIX_21598 = (_12176 != 0);
    _12176 = NOVALUE;

    /** platform.e:122		TWINDOWS = (ihost_platform = WIN32)*/
    _46TWINDOWS_21594 = (_46ihost_platform_21619 == 2);

    /** platform.e:123		TBSD     = (ihost_platform = UFREEBSD)*/
    _46TBSD_21600 = (_46ihost_platform_21619 == 8);

    /** platform.e:124		TOSX     = (ihost_platform = UOSX)*/
    _46TOSX_21602 = (_46ihost_platform_21619 == 4);

    /** platform.e:125		TLINUX   = (ihost_platform = ULINUX)*/
    _46TLINUX_21596 = (_46ihost_platform_21619 == 3);

    /** platform.e:126		TOPENBSD = (ihost_platform = UOPENBSD)*/
    _46TOPENBSD_21604 = (_46ihost_platform_21619 == 6);

    /** platform.e:127		TNETBSD  = (ihost_platform = UNETBSD)*/
    _46TNETBSD_21606 = (_46ihost_platform_21619 == 7);

    /** platform.e:128		IUNIX    = TUNIX*/
    _46IUNIX_21597 = _46TUNIX_21598;

    /** platform.e:129		IWINDOWS = TWINDOWS*/
    _46IWINDOWS_21593 = _46TWINDOWS_21594;

    /** platform.e:130		IBSD     = TBSD*/
    _46IBSD_21599 = _46TBSD_21600;

    /** platform.e:131		IOSX     = TOSX*/
    _46IOSX_21601 = _46TOSX_21602;

    /** platform.e:132		ILINUX   = TLINUX*/
    _46ILINUX_21595 = _46TLINUX_21596;

    /** platform.e:133		IOPENBSD = TOPENBSD*/
    _46IOPENBSD_21603 = _46TOPENBSD_21604;

    /** platform.e:134		INETBSD  = TNETBSD*/
    _46INETBSD_21605 = _46TNETBSD_21606;

    /** platform.e:136		if TUNIX then*/
    if (_46TUNIX_21598 == 0)
    {
        goto L1; // [148] 161
    }
    else{
    }

    /** platform.e:137			HOSTNL = "\n"*/
    RefDS(_9772);
    DeRefi(_46HOSTNL_21616);
    _46HOSTNL_21616 = _9772;
    goto L2; // [158] 169
L1: 

    /** platform.e:139			HOSTNL = "\r\n"*/
    RefDS(_12173);
    DeRefi(_46HOSTNL_21616);
    _46HOSTNL_21616 = _12173;
L2: 

    /** platform.e:141	end procedure*/
    return;
    ;
}


void _46set_target_arch(object _arch_21641)
{
    object _12193 = NOVALUE;
    object _12184 = NOVALUE;
    object _0, _1, _2;
    

    /** platform.e:144		IX86    = 0*/
    _46IX86_21607 = 0;

    /** platform.e:145		TX86    = 0*/
    _46TX86_21608 = 0;

    /** platform.e:146		IX86_64 = 0*/
    _46IX86_64_21609 = 0;

    /** platform.e:147		TX86_64 = 0*/
    _46TX86_64_21610 = 0;

    /** platform.e:148		IARM    = 0*/
    _46IARM_21611 = 0;

    /** platform.e:149		TARM    = 0*/
    _46TARM_21612 = 0;

    /** platform.e:150		switch upper( arch ) do*/
    RefDS(_arch_21641);
    _12184 = _14upper(_arch_21641);
    _1 = find(_12184, _12185);
    DeRef(_12184);
    _12184 = NOVALUE;
    switch ( _1 ){ 

        /** platform.e:151			case "X86", "IX86" then*/
        case 1:
        case 2:

        /** platform.e:152				IX86    = 1*/
        _46IX86_21607 = 1;

        /** platform.e:153				TX86    = 1*/
        _46TX86_21608 = 1;

        /** platform.e:154				TARGET_SIZEOF_POINTER = 4*/
        _36TARGET_SIZEOF_POINTER_21269 = 4;
        goto L1; // [67] 140

        /** platform.e:156			case "X86_64", "IX86_64" then*/
        case 3:
        case 4:

        /** platform.e:157				IX86_64 = 1*/
        _46IX86_64_21609 = 1;

        /** platform.e:158				TX86_64 = 1*/
        _46TX86_64_21610 = 1;

        /** platform.e:159				TARGET_SIZEOF_POINTER = 8*/
        _36TARGET_SIZEOF_POINTER_21269 = 8;
        goto L1; // [92] 140

        /** platform.e:161			case "ARM" then*/
        case 5:

        /** platform.e:162				IARM = 1*/
        _46IARM_21611 = 1;

        /** platform.e:163				TARM = 1*/
        _46TARM_21612 = 1;

        /** platform.e:164				TARGET_SIZEOF_POINTER = 4*/
        _36TARGET_SIZEOF_POINTER_21269 = 4;
        goto L1; // [115] 140

        /** platform.e:166			case else*/
        case 0:

        /** platform.e:167				ShowMsg( 2, UNKNOWN_ARCHITECTURE_1__SUPPORTED_ARCHITECTURES_ARE_2, { arch, "X86, X86_64, ARM" } )*/
        RefDS(_12192);
        RefDS(_arch_21641);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _arch_21641;
        ((intptr_t *)_2)[2] = _12192;
        _12193 = MAKE_SEQ(_1);
        _39ShowMsg(2, 357, _12193, 1);
        _12193 = NOVALUE;

        /** platform.e:168				abort( 1 )*/
        UserCleanup(1);
    ;}L1: 

    /** platform.e:170		set_target_integer_size( TARGET_SIZEOF_POINTER )	*/
    _36set_target_integer_size(_36TARGET_SIZEOF_POINTER_21269);

    /** platform.e:171	end procedure*/
    DeRefDS(_arch_21641);
    return;
    ;
}


object _46GetPlatformDefines(object _for_translator_21666)
{
    object _local_defines_21667 = NOVALUE;
    object _lcmds_21677 = NOVALUE;
    object _fh_21679 = NOVALUE;
    object _sk_21699 = NOVALUE;
    object _12318 = NOVALUE;
    object _12317 = NOVALUE;
    object _12315 = NOVALUE;
    object _12312 = NOVALUE;
    object _12311 = NOVALUE;
    object _12309 = NOVALUE;
    object _12308 = NOVALUE;
    object _12306 = NOVALUE;
    object _12303 = NOVALUE;
    object _12302 = NOVALUE;
    object _12300 = NOVALUE;
    object _12299 = NOVALUE;
    object _12297 = NOVALUE;
    object _12295 = NOVALUE;
    object _12293 = NOVALUE;
    object _12292 = NOVALUE;
    object _12290 = NOVALUE;
    object _12287 = NOVALUE;
    object _12285 = NOVALUE;
    object _12284 = NOVALUE;
    object _12282 = NOVALUE;
    object _12280 = NOVALUE;
    object _12278 = NOVALUE;
    object _12277 = NOVALUE;
    object _12275 = NOVALUE;
    object _12273 = NOVALUE;
    object _12271 = NOVALUE;
    object _12270 = NOVALUE;
    object _12268 = NOVALUE;
    object _12266 = NOVALUE;
    object _12264 = NOVALUE;
    object _12263 = NOVALUE;
    object _12261 = NOVALUE;
    object _12258 = NOVALUE;
    object _12256 = NOVALUE;
    object _12255 = NOVALUE;
    object _12253 = NOVALUE;
    object _12251 = NOVALUE;
    object _12249 = NOVALUE;
    object _12248 = NOVALUE;
    object _12245 = NOVALUE;
    object _12242 = NOVALUE;
    object _12239 = NOVALUE;
    object _12235 = NOVALUE;
    object _12234 = NOVALUE;
    object _12229 = NOVALUE;
    object _12228 = NOVALUE;
    object _12215 = NOVALUE;
    object _12212 = NOVALUE;
    object _12209 = NOVALUE;
    object _12208 = NOVALUE;
    object _12207 = NOVALUE;
    object _12203 = NOVALUE;
    object _12200 = NOVALUE;
    object _12197 = NOVALUE;
    object _12195 = NOVALUE;
    object _12194 = NOVALUE;
    object _0, _1, _2;
    

    /** platform.e:174		sequence local_defines = {}*/
    RefDS(_5);
    DeRef(_local_defines_21667);
    _local_defines_21667 = _5;

    /** platform.e:176		if (IWINDOWS and not for_translator) or (TWINDOWS and for_translator) then*/
    if (_46IWINDOWS_21593 == 0) {
        _12194 = 0;
        goto L1; // [14] 25
    }
    _12195 = (_for_translator_21666 == 0);
    _12194 = (_12195 != 0);
L1: 
    if (_12194 != 0) {
        goto L2; // [25] 44
    }
    if (_46TWINDOWS_21594 == 0) {
        DeRef(_12197);
        _12197 = 0;
        goto L3; // [31] 39
    }
    _12197 = (_for_translator_21666 != 0);
L3: 
    if (_12197 == 0)
    {
        _12197 = NOVALUE;
        goto L4; // [40] 326
    }
    else{
        _12197 = NOVALUE;
    }
L2: 

    /** platform.e:177			local_defines &= {"WINDOWS", "WIN32"}*/
    RefDS(_12199);
    RefDS(_12198);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _12198;
    ((intptr_t *)_2)[2] = _12199;
    _12200 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21667, _local_defines_21667, _12200);
    DeRefDS(_12200);
    _12200 = NOVALUE;

    /** platform.e:178			sequence lcmds = command_line()*/
    DeRef(_lcmds_21677);
    _lcmds_21677 = Command_Line();

    /** platform.e:181			integer fh*/

    /** platform.e:182			fh = open(lcmds[1], "rb")*/
    _2 = (object)SEQ_PTR(_lcmds_21677);
    _12203 = (object)*(((s1_ptr)_2)->base + 1);
    _fh_21679 = EOpen(_12203, _10093, 0);
    _12203 = NOVALUE;

    /** platform.e:183			if fh = -1 then*/
    if (_fh_21679 != -1)
    goto L5; // [73] 123

    /** platform.e:185	 			if match("euiw", lower(lcmds[1])) != 0 then*/
    _2 = (object)SEQ_PTR(_lcmds_21677);
    _12207 = (object)*(((s1_ptr)_2)->base + 1);
    RefDS(_12207);
    _12208 = _14lower(_12207);
    _12207 = NOVALUE;
    _12209 = e_match_from(_12206, _12208, 1);
    DeRef(_12208);
    _12208 = NOVALUE;
    if (_12209 == 0)
    goto L6; // [92] 109

    /** platform.e:186	 				local_defines &= { "GUI" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12211);
    ((intptr_t*)_2)[1] = _12211;
    _12212 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21667, _local_defines_21667, _12212);
    DeRefDS(_12212);
    _12212 = NOVALUE;
    goto L7; // [106] 321
L6: 

    /** platform.e:188	 				local_defines &= { "CONSOLE" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12214);
    ((intptr_t*)_2)[1] = _12214;
    _12215 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21667, _local_defines_21667, _12215);
    DeRefDS(_12215);
    _12215 = NOVALUE;
    goto L7; // [120] 321
L5: 

    /** platform.e:191				atom sk*/

    /** platform.e:192				sk = seek(fh, #18) -- Fixed location of relocation table.*/
    _0 = _sk_21699;
    _sk_21699 = _8seek(_fh_21679, 24);
    DeRef(_0);

    /** platform.e:193				sk = get_integer16(fh)*/
    _0 = _sk_21699;
    _sk_21699 = _8get_integer16(_fh_21679);
    DeRef(_0);

    /** platform.e:194				if sk = #40 then*/
    if (binary_op_a(NOTEQ, _sk_21699, 64)){
        goto L8; // [140] 259
    }

    /** platform.e:196					sk = seek(fh, #3C) -- Fixed location of COFF signature offset.*/
    _0 = _sk_21699;
    _sk_21699 = _8seek(_fh_21679, 60);
    DeRef(_0);

    /** platform.e:197					sk = get_integer32(fh)*/
    _0 = _sk_21699;
    _sk_21699 = _8get_integer32(_fh_21679);
    DeRef(_0);

    /** platform.e:198					sk = seek(fh, sk)*/
    Ref(_sk_21699);
    _0 = _sk_21699;
    _sk_21699 = _8seek(_fh_21679, _sk_21699);
    DeRef(_0);

    /** platform.e:199					sk = get_integer16(fh)*/
    _0 = _sk_21699;
    _sk_21699 = _8get_integer16(_fh_21679);
    DeRef(_0);

    /** platform.e:200					if sk = #4550 then -- "PE" in intel endian*/
    if (binary_op_a(NOTEQ, _sk_21699, 17744)){
        goto L9; // [172] 221
    }

    /** platform.e:201						sk = get_integer16(fh)*/
    _0 = _sk_21699;
    _sk_21699 = _8get_integer16(_fh_21679);
    DeRef(_0);

    /** platform.e:202						if sk = 0 then*/
    if (binary_op_a(NOTEQ, _sk_21699, 0)){
        goto LA; // [184] 212
    }

    /** platform.e:204							sk = seek(fh, where(fh) + 88 )*/
    _12228 = _8where(_fh_21679);
    if (IS_ATOM_INT(_12228)) {
        _12229 = _12228 + 88;
        if ((object)((uintptr_t)_12229 + (uintptr_t)HIGH_BITS) >= 0){
            _12229 = NewDouble((eudouble)_12229);
        }
    }
    else {
        _12229 = binary_op(PLUS, _12228, 88);
    }
    DeRef(_12228);
    _12228 = NOVALUE;
    _0 = _sk_21699;
    _sk_21699 = _8seek(_fh_21679, _12229);
    DeRef(_0);
    _12229 = NOVALUE;

    /** platform.e:205							sk = get_integer16(fh)*/
    _0 = _sk_21699;
    _sk_21699 = _8get_integer16(_fh_21679);
    DeRef(_0);
    goto LB; // [209] 265
LA: 

    /** platform.e:207							sk = 0	-- Don't know this format.*/
    DeRef(_sk_21699);
    _sk_21699 = 0;
    goto LB; // [218] 265
L9: 

    /** platform.e:209					elsif sk = #454E then -- "NE" in intel endian*/
    if (binary_op_a(NOTEQ, _sk_21699, 17742)){
        goto LC; // [223] 250
    }

    /** platform.e:211						sk = seek(fh, where(fh) + 54 )*/
    _12234 = _8where(_fh_21679);
    if (IS_ATOM_INT(_12234)) {
        _12235 = _12234 + 54;
        if ((object)((uintptr_t)_12235 + (uintptr_t)HIGH_BITS) >= 0){
            _12235 = NewDouble((eudouble)_12235);
        }
    }
    else {
        _12235 = binary_op(PLUS, _12234, 54);
    }
    DeRef(_12234);
    _12234 = NOVALUE;
    _0 = _sk_21699;
    _sk_21699 = _8seek(_fh_21679, _12235);
    DeRef(_0);
    _12235 = NOVALUE;

    /** platform.e:212						sk = getc(fh)*/
    DeRef(_sk_21699);
    if (_fh_21679 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_21679, EF_READ);
        last_r_file_no = _fh_21679;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _sk_21699 = getc((FILE*)xstdin);
        }
        else{
            _sk_21699 = getc(last_r_file_ptr);
        }
    }
    else{
        _sk_21699 = getc(last_r_file_ptr);
    }
    goto LB; // [247] 265
LC: 

    /** platform.e:214						sk = 0*/
    DeRef(_sk_21699);
    _sk_21699 = 0;
    goto LB; // [256] 265
L8: 

    /** platform.e:217					sk = 0*/
    DeRef(_sk_21699);
    _sk_21699 = 0;
LB: 

    /** platform.e:219				if sk = 2 then*/
    if (binary_op_a(NOTEQ, _sk_21699, 2)){
        goto LD; // [267] 284
    }

    /** platform.e:220					local_defines &= { "GUI" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12211);
    ((intptr_t*)_2)[1] = _12211;
    _12239 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21667, _local_defines_21667, _12239);
    DeRefDS(_12239);
    _12239 = NOVALUE;
    goto LE; // [281] 314
LD: 

    /** platform.e:221				elsif sk = 3 then*/
    if (binary_op_a(NOTEQ, _sk_21699, 3)){
        goto LF; // [286] 303
    }

    /** platform.e:222					local_defines &= { "CONSOLE" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12214);
    ((intptr_t*)_2)[1] = _12214;
    _12242 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21667, _local_defines_21667, _12242);
    DeRefDS(_12242);
    _12242 = NOVALUE;
    goto LE; // [300] 314
LF: 

    /** platform.e:224					local_defines &= { "UNKNOWN" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12244);
    ((intptr_t*)_2)[1] = _12244;
    _12245 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21667, _local_defines_21667, _12245);
    DeRefDS(_12245);
    _12245 = NOVALUE;
LE: 

    /** platform.e:226				close(fh)*/
    EClose(_fh_21679);
    DeRef(_sk_21699);
    _sk_21699 = NOVALUE;
L7: 
    DeRef(_lcmds_21677);
    _lcmds_21677 = NOVALUE;
    goto L10; // [323] 575
L4: 

    /** platform.e:229			local_defines = append( local_defines, "CONSOLE" )*/
    RefDS(_12214);
    Append(&_local_defines_21667, _local_defines_21667, _12214);

    /** platform.e:230			if (ILINUX and not for_translator) or (TLINUX and for_translator) then*/
    if (_46ILINUX_21595 == 0) {
        _12248 = 0;
        goto L11; // [336] 347
    }
    _12249 = (_for_translator_21666 == 0);
    _12248 = (_12249 != 0);
L11: 
    if (_12248 != 0) {
        goto L12; // [347] 366
    }
    if (_46TLINUX_21596 == 0) {
        DeRef(_12251);
        _12251 = 0;
        goto L13; // [353] 361
    }
    _12251 = (_for_translator_21666 != 0);
L13: 
    if (_12251 == 0)
    {
        _12251 = NOVALUE;
        goto L14; // [362] 379
    }
    else{
        _12251 = NOVALUE;
    }
L12: 

    /** platform.e:231				local_defines &= {"UNIX", "LINUX"}*/
    RefDS(_12252);
    RefDS(_11981);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _11981;
    ((intptr_t *)_2)[2] = _12252;
    _12253 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21667, _local_defines_21667, _12253);
    DeRefDS(_12253);
    _12253 = NOVALUE;
    goto L15; // [376] 574
L14: 

    /** platform.e:232			elsif (IOSX and not for_translator) or (TOSX and for_translator) then*/
    if (_46IOSX_21601 == 0) {
        _12255 = 0;
        goto L16; // [383] 394
    }
    _12256 = (_for_translator_21666 == 0);
    _12255 = (_12256 != 0);
L16: 
    if (_12255 != 0) {
        goto L17; // [394] 413
    }
    if (_46TOSX_21602 == 0) {
        DeRef(_12258);
        _12258 = 0;
        goto L18; // [400] 408
    }
    _12258 = (_for_translator_21666 != 0);
L18: 
    if (_12258 == 0)
    {
        _12258 = NOVALUE;
        goto L19; // [409] 428
    }
    else{
        _12258 = NOVALUE;
    }
L17: 

    /** platform.e:233				local_defines &= {"UNIX", "BSD", "OSX"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11981);
    ((intptr_t*)_2)[1] = _11981;
    RefDS(_12259);
    ((intptr_t*)_2)[2] = _12259;
    RefDS(_12260);
    ((intptr_t*)_2)[3] = _12260;
    _12261 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21667, _local_defines_21667, _12261);
    DeRefDS(_12261);
    _12261 = NOVALUE;
    goto L15; // [425] 574
L19: 

    /** platform.e:234			elsif (IOPENBSD and not for_translator) or (TOPENBSD and for_translator) then*/
    if (_46IOPENBSD_21603 == 0) {
        _12263 = 0;
        goto L1A; // [432] 443
    }
    _12264 = (_for_translator_21666 == 0);
    _12263 = (_12264 != 0);
L1A: 
    if (_12263 != 0) {
        goto L1B; // [443] 462
    }
    if (_46TOPENBSD_21604 == 0) {
        DeRef(_12266);
        _12266 = 0;
        goto L1C; // [449] 457
    }
    _12266 = (_for_translator_21666 != 0);
L1C: 
    if (_12266 == 0)
    {
        _12266 = NOVALUE;
        goto L1D; // [458] 477
    }
    else{
        _12266 = NOVALUE;
    }
L1B: 

    /** platform.e:235				local_defines &= { "UNIX", "BSD", "OPENBSD"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11981);
    ((intptr_t*)_2)[1] = _11981;
    RefDS(_12259);
    ((intptr_t*)_2)[2] = _12259;
    RefDS(_12267);
    ((intptr_t*)_2)[3] = _12267;
    _12268 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21667, _local_defines_21667, _12268);
    DeRefDS(_12268);
    _12268 = NOVALUE;
    goto L15; // [474] 574
L1D: 

    /** platform.e:236			elsif (INETBSD and not for_translator) or (TNETBSD and for_translator) then*/
    if (_46INETBSD_21605 == 0) {
        _12270 = 0;
        goto L1E; // [481] 492
    }
    _12271 = (_for_translator_21666 == 0);
    _12270 = (_12271 != 0);
L1E: 
    if (_12270 != 0) {
        goto L1F; // [492] 511
    }
    if (_46TNETBSD_21606 == 0) {
        DeRef(_12273);
        _12273 = 0;
        goto L20; // [498] 506
    }
    _12273 = (_for_translator_21666 != 0);
L20: 
    if (_12273 == 0)
    {
        _12273 = NOVALUE;
        goto L21; // [507] 526
    }
    else{
        _12273 = NOVALUE;
    }
L1F: 

    /** platform.e:237				local_defines &= { "UNIX", "BSD", "NETBSD"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11981);
    ((intptr_t*)_2)[1] = _11981;
    RefDS(_12259);
    ((intptr_t*)_2)[2] = _12259;
    RefDS(_12274);
    ((intptr_t*)_2)[3] = _12274;
    _12275 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21667, _local_defines_21667, _12275);
    DeRefDS(_12275);
    _12275 = NOVALUE;
    goto L15; // [523] 574
L21: 

    /** platform.e:238			elsif (IBSD and not for_translator) or (TBSD and for_translator) then*/
    if (_46IBSD_21599 == 0) {
        _12277 = 0;
        goto L22; // [530] 541
    }
    _12278 = (_for_translator_21666 == 0);
    _12277 = (_12278 != 0);
L22: 
    if (_12277 != 0) {
        goto L23; // [541] 560
    }
    if (_46TBSD_21600 == 0) {
        DeRef(_12280);
        _12280 = 0;
        goto L24; // [547] 555
    }
    _12280 = (_for_translator_21666 != 0);
L24: 
    if (_12280 == 0)
    {
        _12280 = NOVALUE;
        goto L25; // [556] 573
    }
    else{
        _12280 = NOVALUE;
    }
L23: 

    /** platform.e:239				local_defines &= {"UNIX", "BSD", "FREEBSD"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11981);
    ((intptr_t*)_2)[1] = _11981;
    RefDS(_12259);
    ((intptr_t*)_2)[2] = _12259;
    RefDS(_12281);
    ((intptr_t*)_2)[3] = _12281;
    _12282 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21667, _local_defines_21667, _12282);
    DeRefDS(_12282);
    _12282 = NOVALUE;
L25: 
L15: 
L10: 

    /** platform.e:243		if (IX86 and not for_translator) or (TX86 and for_translator) then*/
    if (_46IX86_21607 == 0) {
        _12284 = 0;
        goto L26; // [579] 590
    }
    _12285 = (_for_translator_21666 == 0);
    _12284 = (_12285 != 0);
L26: 
    if (_12284 != 0) {
        goto L27; // [590] 609
    }
    if (_46TX86_21608 == 0) {
        DeRef(_12287);
        _12287 = 0;
        goto L28; // [596] 604
    }
    _12287 = (_for_translator_21666 != 0);
L28: 
    if (_12287 == 0)
    {
        _12287 = NOVALUE;
        goto L29; // [605] 624
    }
    else{
        _12287 = NOVALUE;
    }
L27: 

    /** platform.e:244			local_defines &= {"X86", "BITS32", "LONG32"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12187);
    ((intptr_t*)_2)[1] = _12187;
    RefDS(_12288);
    ((intptr_t*)_2)[2] = _12288;
    RefDS(_12289);
    ((intptr_t*)_2)[3] = _12289;
    _12290 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21667, _local_defines_21667, _12290);
    DeRefDS(_12290);
    _12290 = NOVALUE;
    goto L2A; // [621] 777
L29: 

    /** platform.e:246		elsif (IX86_64 and not for_translator) or (TX86_64 and for_translator) then*/
    if (_46IX86_64_21609 == 0) {
        _12292 = 0;
        goto L2B; // [628] 639
    }
    _12293 = (_for_translator_21666 == 0);
    _12292 = (_12293 != 0);
L2B: 
    if (_12292 != 0) {
        goto L2C; // [639] 658
    }
    if (_46TX86_64_21610 == 0) {
        DeRef(_12295);
        _12295 = 0;
        goto L2D; // [645] 653
    }
    _12295 = (_for_translator_21666 != 0);
L2D: 
    if (_12295 == 0)
    {
        _12295 = NOVALUE;
        goto L2E; // [654] 729
    }
    else{
        _12295 = NOVALUE;
    }
L2C: 

    /** platform.e:247			local_defines &= {"X86_64", "BITS64"}*/
    RefDS(_12296);
    RefDS(_12189);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _12189;
    ((intptr_t *)_2)[2] = _12296;
    _12297 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21667, _local_defines_21667, _12297);
    DeRefDS(_12297);
    _12297 = NOVALUE;

    /** platform.e:248			if (IWINDOWS and not for_translator) or (TWINDOWS and for_translator) then*/
    if (_46IWINDOWS_21593 == 0) {
        _12299 = 0;
        goto L2F; // [672] 683
    }
    _12300 = (_for_translator_21666 == 0);
    _12299 = (_12300 != 0);
L2F: 
    if (_12299 != 0) {
        goto L30; // [683] 702
    }
    if (_46TWINDOWS_21594 == 0) {
        DeRef(_12302);
        _12302 = 0;
        goto L31; // [689] 697
    }
    _12302 = (_for_translator_21666 != 0);
L31: 
    if (_12302 == 0)
    {
        _12302 = NOVALUE;
        goto L32; // [698] 715
    }
    else{
        _12302 = NOVALUE;
    }
L30: 

    /** platform.e:249				local_defines &= {"LONG32"}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12289);
    ((intptr_t*)_2)[1] = _12289;
    _12303 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21667, _local_defines_21667, _12303);
    DeRefDS(_12303);
    _12303 = NOVALUE;
    goto L2A; // [712] 777
L32: 

    /** platform.e:251				local_defines &= {"LONG64"}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12305);
    ((intptr_t*)_2)[1] = _12305;
    _12306 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21667, _local_defines_21667, _12306);
    DeRefDS(_12306);
    _12306 = NOVALUE;
    goto L2A; // [726] 777
L2E: 

    /** platform.e:253		elsif (IARM and not for_translator) or (TARM and for_translator) then*/
    if (_46IARM_21611 == 0) {
        _12308 = 0;
        goto L33; // [733] 744
    }
    _12309 = (_for_translator_21666 == 0);
    _12308 = (_12309 != 0);
L33: 
    if (_12308 != 0) {
        goto L34; // [744] 763
    }
    if (_46TARM_21612 == 0) {
        DeRef(_12311);
        _12311 = 0;
        goto L35; // [750] 758
    }
    _12311 = (_for_translator_21666 != 0);
L35: 
    if (_12311 == 0)
    {
        _12311 = NOVALUE;
        goto L36; // [759] 776
    }
    else{
        _12311 = NOVALUE;
    }
L34: 

    /** platform.e:254			local_defines &= {"ARM", "BITS32", "LONG32"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12191);
    ((intptr_t*)_2)[1] = _12191;
    RefDS(_12288);
    ((intptr_t*)_2)[2] = _12288;
    RefDS(_12289);
    ((intptr_t*)_2)[3] = _12289;
    _12312 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21667, _local_defines_21667, _12312);
    DeRefDS(_12312);
    _12312 = NOVALUE;
L36: 
L2A: 

    /** platform.e:259		return { "_PLAT_START" } & local_defines & { "_PLAT_STOP" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12314);
    ((intptr_t*)_2)[1] = _12314;
    _12315 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12316);
    ((intptr_t*)_2)[1] = _12316;
    _12317 = MAKE_SEQ(_1);
    {
        object concat_list[3];

        concat_list[0] = _12317;
        concat_list[1] = _local_defines_21667;
        concat_list[2] = _12315;
        Concat_N((object_ptr)&_12318, concat_list, 3);
    }
    DeRefDS(_12317);
    _12317 = NOVALUE;
    DeRefDS(_12315);
    _12315 = NOVALUE;
    DeRefDS(_local_defines_21667);
    DeRef(_12256);
    _12256 = NOVALUE;
    DeRef(_12309);
    _12309 = NOVALUE;
    DeRef(_12293);
    _12293 = NOVALUE;
    DeRef(_12271);
    _12271 = NOVALUE;
    DeRef(_12300);
    _12300 = NOVALUE;
    DeRef(_12278);
    _12278 = NOVALUE;
    DeRef(_12249);
    _12249 = NOVALUE;
    DeRef(_12264);
    _12264 = NOVALUE;
    DeRef(_12195);
    _12195 = NOVALUE;
    DeRef(_12285);
    _12285 = NOVALUE;
    return _12318;
    ;
}



// 0x666CE900
