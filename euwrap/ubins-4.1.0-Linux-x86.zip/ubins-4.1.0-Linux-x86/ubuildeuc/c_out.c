// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _55c_putc(object _c_46637)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_46637)) {
        _1 = (object)(DBL_PTR(_c_46637)->dbl);
        DeRefDS(_c_46637);
        _c_46637 = _1;
    }

    /** c_out.e:62		if emit_c_output then*/
    if (_55emit_c_output_46624 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** c_out.e:63			puts(c_code, c)*/
    EPuts(_55c_code_46627, _c_46637); // DJP 

    /** c_out.e:64			update_checksum( c )*/
    _56update_checksum(_c_46637);
L1: 

    /** c_out.e:66	end procedure*/
    return;
    ;
}


void _55c_hputs(object _c_source_46642)
{
    object _0, _1, _2;
    

    /** c_out.e:71		if emit_c_output then*/
    if (_55emit_c_output_46624 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** c_out.e:72			puts(c_h, c_source)    */
    EPuts(_55c_h_46628, _c_source_46642); // DJP 
L1: 

    /** c_out.e:74	end procedure*/
    DeRefDS(_c_source_46642);
    return;
    ;
}


void _55c_puts(object _c_source_46646)
{
    object _0, _1, _2;
    

    /** c_out.e:79		if emit_c_output then*/
    if (_55emit_c_output_46624 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** c_out.e:80			puts(c_code, c_source)*/
    EPuts(_55c_code_46627, _c_source_46646); // DJP 

    /** c_out.e:81			update_checksum( c_source )*/
    RefDS(_c_source_46646);
    _56update_checksum(_c_source_46646);
L1: 

    /** c_out.e:83	end procedure*/
    DeRefDS(_c_source_46646);
    return;
    ;
}


void _55c_hprintf(object _format_46651, object _value_46652)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_value_46652)) {
        _1 = (object)(DBL_PTR(_value_46652)->dbl);
        DeRefDS(_value_46652);
        _value_46652 = _1;
    }

    /** c_out.e:88		if emit_c_output then*/
    if (_55emit_c_output_46624 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** c_out.e:89			printf(c_h, format, value)*/
    EPrintf(_55c_h_46628, _format_46651, _value_46652);
L1: 

    /** c_out.e:91	end procedure*/
    DeRefDSi(_format_46651);
    return;
    ;
}


void _55c_printf(object _format_46656, object _value_46657)
{
    object _text_46659 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:96		if emit_c_output then*/
    if (_55emit_c_output_46624 == 0)
    {
        goto L1; // [7] 29
    }
    else{
    }

    /** c_out.e:97			sequence text = sprintf( format, value )*/
    DeRefi(_text_46659);
    _text_46659 = EPrintf(-9999999, _format_46656, _value_46657);

    /** c_out.e:98			puts(c_code, text)*/
    EPuts(_55c_code_46627, _text_46659); // DJP 

    /** c_out.e:99			update_checksum( text )*/
    RefDS(_text_46659);
    _56update_checksum(_text_46659);
L1: 
    DeRefi(_text_46659);
    _text_46659 = NOVALUE;

    /** c_out.e:101	end procedure*/
    DeRefDSi(_format_46656);
    DeRef(_value_46657);
    return;
    ;
}


void _55c_printf8(object _value_46670)
{
    object _buff_46671 = NOVALUE;
    object _neg_46672 = NOVALUE;
    object _p_46673 = NOVALUE;
    object _24238 = NOVALUE;
    object _24237 = NOVALUE;
    object _24235 = NOVALUE;
    object _24234 = NOVALUE;
    object _24232 = NOVALUE;
    object _24231 = NOVALUE;
    object _24229 = NOVALUE;
    object _24228 = NOVALUE;
    object _24226 = NOVALUE;
    object _24224 = NOVALUE;
    object _24222 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:115		if emit_c_output then*/
    if (_55emit_c_output_46624 == 0)
    {
        goto L1; // [5] 182
    }
    else{
    }

    /** c_out.e:116			neg = 0*/
    _neg_46672 = 0;

    /** c_out.e:117			buff = sprintf("%.20eL", value)*/
    DeRef(_buff_46671);
    _buff_46671 = EPrintf(-9999999, _24220, _value_46670);

    /** c_out.e:118			if length(buff) < 10 then*/
    if (IS_SEQUENCE(_buff_46671)){
            _24222 = SEQ_PTR(_buff_46671)->length;
    }
    else {
        _24222 = 1;
    }
    if (_24222 >= 10)
    goto L2; // [24] 174

    /** c_out.e:120				p = 1*/
    _p_46673 = 1;

    /** c_out.e:121				while p <= length(buff) do*/
L3: 
    if (IS_SEQUENCE(_buff_46671)){
            _24224 = SEQ_PTR(_buff_46671)->length;
    }
    else {
        _24224 = 1;
    }
    if (_p_46673 > _24224)
    goto L4; // [41] 173

    /** c_out.e:122					if buff[p] = '-' then*/
    _2 = (object)SEQ_PTR(_buff_46671);
    _24226 = (object)*(((s1_ptr)_2)->base + _p_46673);
    if (binary_op_a(NOTEQ, _24226, 45)){
        _24226 = NOVALUE;
        goto L5; // [51] 63
    }
    _24226 = NOVALUE;

    /** c_out.e:123						neg = 1*/
    _neg_46672 = 1;
    goto L6; // [60] 162
L5: 

    /** c_out.e:125					elsif buff[p] = 'i' or buff[p] = 'I' then*/
    _2 = (object)SEQ_PTR(_buff_46671);
    _24228 = (object)*(((s1_ptr)_2)->base + _p_46673);
    if (IS_ATOM_INT(_24228)) {
        _24229 = (_24228 == 105);
    }
    else {
        _24229 = binary_op(EQUALS, _24228, 105);
    }
    _24228 = NOVALUE;
    if (IS_ATOM_INT(_24229)) {
        if (_24229 != 0) {
            goto L7; // [73] 90
        }
    }
    else {
        if (DBL_PTR(_24229)->dbl != 0.0) {
            goto L7; // [73] 90
        }
    }
    _2 = (object)SEQ_PTR(_buff_46671);
    _24231 = (object)*(((s1_ptr)_2)->base + _p_46673);
    if (IS_ATOM_INT(_24231)) {
        _24232 = (_24231 == 73);
    }
    else {
        _24232 = binary_op(EQUALS, _24231, 73);
    }
    _24231 = NOVALUE;
    if (_24232 == 0) {
        DeRef(_24232);
        _24232 = NOVALUE;
        goto L8; // [86] 114
    }
    else {
        if (!IS_ATOM_INT(_24232) && DBL_PTR(_24232)->dbl == 0.0){
            DeRef(_24232);
            _24232 = NOVALUE;
            goto L8; // [86] 114
        }
        DeRef(_24232);
        _24232 = NOVALUE;
    }
    DeRef(_24232);
    _24232 = NOVALUE;
L7: 

    /** c_out.e:127						buff = CREATE_INF*/
    RefDS(_55CREATE_INF_46662);
    DeRef(_buff_46671);
    _buff_46671 = _55CREATE_INF_46662;

    /** c_out.e:128						if neg then*/
    if (_neg_46672 == 0)
    {
        goto L4; // [97] 173
    }
    else{
    }

    /** c_out.e:129							buff = prepend(buff, '-')*/
    Prepend(&_buff_46671, _buff_46671, 45);

    /** c_out.e:131						exit*/
    goto L4; // [109] 173
    goto L6; // [111] 162
L8: 

    /** c_out.e:133					elsif buff[p] = 'n' or buff[p] = 'N' then*/
    _2 = (object)SEQ_PTR(_buff_46671);
    _24234 = (object)*(((s1_ptr)_2)->base + _p_46673);
    if (IS_ATOM_INT(_24234)) {
        _24235 = (_24234 == 110);
    }
    else {
        _24235 = binary_op(EQUALS, _24234, 110);
    }
    _24234 = NOVALUE;
    if (IS_ATOM_INT(_24235)) {
        if (_24235 != 0) {
            goto L9; // [124] 141
        }
    }
    else {
        if (DBL_PTR(_24235)->dbl != 0.0) {
            goto L9; // [124] 141
        }
    }
    _2 = (object)SEQ_PTR(_buff_46671);
    _24237 = (object)*(((s1_ptr)_2)->base + _p_46673);
    if (IS_ATOM_INT(_24237)) {
        _24238 = (_24237 == 78);
    }
    else {
        _24238 = binary_op(EQUALS, _24237, 78);
    }
    _24237 = NOVALUE;
    if (_24238 == 0) {
        DeRef(_24238);
        _24238 = NOVALUE;
        goto LA; // [137] 161
    }
    else {
        if (!IS_ATOM_INT(_24238) && DBL_PTR(_24238)->dbl == 0.0){
            DeRef(_24238);
            _24238 = NOVALUE;
            goto LA; // [137] 161
        }
        DeRef(_24238);
        _24238 = NOVALUE;
    }
    DeRef(_24238);
    _24238 = NOVALUE;
L9: 

    /** c_out.e:135						ifdef UNIX then*/

    /** c_out.e:136							buff = CREATE_NAN1*/
    RefDS(_55CREATE_NAN1_46664);
    DeRef(_buff_46671);
    _buff_46671 = _55CREATE_NAN1_46664;

    /** c_out.e:137							if neg then*/
    if (_neg_46672 == 0)
    {
        goto LB; // [150] 160
    }
    else{
    }

    /** c_out.e:138								buff = prepend(buff, '-')*/
    Prepend(&_buff_46671, _buff_46671, 45);
LB: 
LA: 
L6: 

    /** c_out.e:156					p += 1*/
    _p_46673 = _p_46673 + 1;

    /** c_out.e:157				end while*/
    goto L3; // [170] 38
L4: 
L2: 

    /** c_out.e:159			puts(c_code, buff)*/
    EPuts(_55c_code_46627, _buff_46671); // DJP 
L1: 

    /** c_out.e:161	end procedure*/
    DeRef(_value_46670);
    DeRef(_buff_46671);
    DeRef(_24235);
    _24235 = NOVALUE;
    DeRef(_24229);
    _24229 = NOVALUE;
    return;
    ;
}


void _55adjust_indent_before(object _stmt_46709)
{
    object _i_46710 = NOVALUE;
    object _lb_46712 = NOVALUE;
    object _rb_46713 = NOVALUE;
    object _24253 = NOVALUE;
    object _24251 = NOVALUE;
    object _24249 = NOVALUE;
    object _24243 = NOVALUE;
    object _24242 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:177		lb = FALSE*/
    _lb_46712 = _13FALSE_450;

    /** c_out.e:178		rb = FALSE*/
    _rb_46713 = _13FALSE_450;

    /** c_out.e:180		for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_46709)){
            _24242 = SEQ_PTR(_stmt_46709)->length;
    }
    else {
        _24242 = 1;
    }
    {
        object _p_46717;
        _p_46717 = 1;
L1: 
        if (_p_46717 > _24242){
            goto L2; // [22] 102
        }

        /** c_out.e:181			switch stmt[p] do*/
        _2 = (object)SEQ_PTR(_stmt_46709);
        _24243 = (object)*(((s1_ptr)_2)->base + _p_46717);
        if (IS_SEQUENCE(_24243) ){
            goto L3; // [35] 95
        }
        if(!IS_ATOM_INT(_24243)){
            if( (DBL_PTR(_24243)->dbl != (eudouble) ((object) DBL_PTR(_24243)->dbl) ) ){
                goto L3; // [35] 95
            }
            _0 = (object) DBL_PTR(_24243)->dbl;
        }
        else {
            _0 = _24243;
        };
        _24243 = NOVALUE;
        switch ( _0 ){ 

            /** c_out.e:182				case '\n' then*/
            case 10:

            /** c_out.e:183					exit*/
            goto L2; // [46] 102
            goto L3; // [48] 95

            /** c_out.e:185				case  '}' then*/
            case 125:

            /** c_out.e:186					rb = TRUE*/
            _rb_46713 = _13TRUE_452;

            /** c_out.e:187					if lb then*/
            if (_lb_46712 == 0)
            {
                goto L3; // [63] 95
            }
            else{
            }

            /** c_out.e:188						exit*/
            goto L2; // [68] 102
            goto L3; // [71] 95

            /** c_out.e:191				case '{' then*/
            case 123:

            /** c_out.e:192					lb = TRUE*/
            _lb_46712 = _13TRUE_452;

            /** c_out.e:193					if rb then */
            if (_rb_46713 == 0)
            {
                goto L4; // [86] 94
            }
            else{
            }

            /** c_out.e:194						exit*/
            goto L2; // [91] 102
L4: 
        ;}L3: 

        /** c_out.e:198		end for*/
        _p_46717 = _p_46717 + 1;
        goto L1; // [97] 29
L2: 
        ;
    }

    /** c_out.e:200		if rb then*/
    if (_rb_46713 == 0)
    {
        goto L5; // [104] 122
    }
    else{
    }

    /** c_out.e:201			if not lb then*/
    if (_lb_46712 != 0)
    goto L6; // [109] 121

    /** c_out.e:202				indent -= 4*/
    _55indent_46703 = _55indent_46703 - 4;
L6: 
L5: 

    /** c_out.e:206		i = indent + temp_indent*/
    _i_46710 = _55indent_46703 + _55temp_indent_46704;

    /** c_out.e:207		while i >= length(big_blanks) do*/
L7: 
    if (IS_SEQUENCE(_55big_blanks_46705)){
            _24249 = SEQ_PTR(_55big_blanks_46705)->length;
    }
    else {
        _24249 = 1;
    }
    if (_i_46710 < _24249)
    goto L8; // [140] 163

    /** c_out.e:208			c_puts(big_blanks)*/
    RefDS(_55big_blanks_46705);
    _55c_puts(_55big_blanks_46705);

    /** c_out.e:209			i -= length(big_blanks)*/
    if (IS_SEQUENCE(_55big_blanks_46705)){
            _24251 = SEQ_PTR(_55big_blanks_46705)->length;
    }
    else {
        _24251 = 1;
    }
    _i_46710 = _i_46710 - _24251;
    _24251 = NOVALUE;

    /** c_out.e:210		end while*/
    goto L7; // [160] 137
L8: 

    /** c_out.e:212		c_puts(big_blanks[1..i])*/
    rhs_slice_target = (object_ptr)&_24253;
    RHS_Slice(_55big_blanks_46705, 1, _i_46710);
    _55c_puts(_24253);
    _24253 = NOVALUE;

    /** c_out.e:214		temp_indent = 0    */
    _55temp_indent_46704 = 0;

    /** c_out.e:215	end procedure*/
    DeRefDS(_stmt_46709);
    return;
    ;
}


void _55adjust_indent_after(object _stmt_46742)
{
    object _24274 = NOVALUE;
    object _24273 = NOVALUE;
    object _24271 = NOVALUE;
    object _24269 = NOVALUE;
    object _24268 = NOVALUE;
    object _24265 = NOVALUE;
    object _24263 = NOVALUE;
    object _24262 = NOVALUE;
    object _24259 = NOVALUE;
    object _24255 = NOVALUE;
    object _24254 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:221		for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_46742)){
            _24254 = SEQ_PTR(_stmt_46742)->length;
    }
    else {
        _24254 = 1;
    }
    {
        object _p_46744;
        _p_46744 = 1;
L1: 
        if (_p_46744 > _24254){
            goto L2; // [8] 61
        }

        /** c_out.e:222			switch stmt[p] do*/
        _2 = (object)SEQ_PTR(_stmt_46742);
        _24255 = (object)*(((s1_ptr)_2)->base + _p_46744);
        if (IS_SEQUENCE(_24255) ){
            goto L3; // [21] 54
        }
        if(!IS_ATOM_INT(_24255)){
            if( (DBL_PTR(_24255)->dbl != (eudouble) ((object) DBL_PTR(_24255)->dbl) ) ){
                goto L3; // [21] 54
            }
            _0 = (object) DBL_PTR(_24255)->dbl;
        }
        else {
            _0 = _24255;
        };
        _24255 = NOVALUE;
        switch ( _0 ){ 

            /** c_out.e:223				case '\n' then*/
            case 10:

            /** c_out.e:224					exit*/
            goto L2; // [32] 61
            goto L3; // [34] 54

            /** c_out.e:226				case '{' then*/
            case 123:

            /** c_out.e:227					indent += 4*/
            _55indent_46703 = _55indent_46703 + 4;

            /** c_out.e:228					return*/
            DeRefDS(_stmt_46742);
            return;
        ;}L3: 

        /** c_out.e:230		end for*/
        _p_46744 = _p_46744 + 1;
        goto L1; // [56] 15
L2: 
        ;
    }

    /** c_out.e:232		if length(stmt) < 3 then*/
    if (IS_SEQUENCE(_stmt_46742)){
            _24259 = SEQ_PTR(_stmt_46742)->length;
    }
    else {
        _24259 = 1;
    }
    if (_24259 >= 3)
    goto L4; // [66] 76

    /** c_out.e:233			return*/
    DeRefDS(_stmt_46742);
    return;
L4: 

    /** c_out.e:236		if not equal("if ", stmt[1..3]) then*/
    rhs_slice_target = (object_ptr)&_24262;
    RHS_Slice(_stmt_46742, 1, 3);
    if (_24261 == _24262)
    _24263 = 1;
    else if (IS_ATOM_INT(_24261) && IS_ATOM_INT(_24262))
    _24263 = 0;
    else
    _24263 = (compare(_24261, _24262) == 0);
    DeRefDS(_24262);
    _24262 = NOVALUE;
    if (_24263 != 0)
    goto L5; // [87] 96
    _24263 = NOVALUE;

    /** c_out.e:237			return*/
    DeRefDS(_stmt_46742);
    return;
L5: 

    /** c_out.e:240		if length(stmt) < 5 then*/
    if (IS_SEQUENCE(_stmt_46742)){
            _24265 = SEQ_PTR(_stmt_46742)->length;
    }
    else {
        _24265 = 1;
    }
    if (_24265 >= 5)
    goto L6; // [101] 111

    /** c_out.e:241			return*/
    DeRefDS(_stmt_46742);
    return;
L6: 

    /** c_out.e:244		if not equal("else", stmt[1..4]) then*/
    rhs_slice_target = (object_ptr)&_24268;
    RHS_Slice(_stmt_46742, 1, 4);
    if (_24267 == _24268)
    _24269 = 1;
    else if (IS_ATOM_INT(_24267) && IS_ATOM_INT(_24268))
    _24269 = 0;
    else
    _24269 = (compare(_24267, _24268) == 0);
    DeRefDS(_24268);
    _24268 = NOVALUE;
    if (_24269 != 0)
    goto L7; // [122] 131
    _24269 = NOVALUE;

    /** c_out.e:245			return*/
    DeRefDS(_stmt_46742);
    return;
L7: 

    /** c_out.e:248		if not find(stmt[5], {" \n"}) then*/
    _2 = (object)SEQ_PTR(_stmt_46742);
    _24271 = (object)*(((s1_ptr)_2)->base + 5);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_24272);
    ((intptr_t*)_2)[1] = _24272;
    _24273 = MAKE_SEQ(_1);
    _24274 = find_from(_24271, _24273, 1);
    _24271 = NOVALUE;
    DeRefDS(_24273);
    _24273 = NOVALUE;
    if (_24274 != 0)
    goto L8; // [146] 155
    _24274 = NOVALUE;

    /** c_out.e:249			return*/
    DeRefDS(_stmt_46742);
    return;
L8: 

    /** c_out.e:252		temp_indent = 4*/
    _55temp_indent_46704 = 4;

    /** c_out.e:254	end procedure*/
    DeRefDS(_stmt_46742);
    return;
    ;
}



// 0xA11A8947
