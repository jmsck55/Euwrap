// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _28reverse(object _s_10253)
{
    object _lower_10254 = NOVALUE;
    object _n_10255 = NOVALUE;
    object _n2_10256 = NOVALUE;
    object _t_10257 = NOVALUE;
    object _5734 = NOVALUE;
    object _5733 = NOVALUE;
    object _5732 = NOVALUE;
    object _5729 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:87		n = length(s)*/
    if (IS_SEQUENCE(_s_10253)){
            _n_10255 = SEQ_PTR(_s_10253)->length;
    }
    else {
        _n_10255 = 1;
    }

    /** scinot.e:88		n2 = floor(n/2)+1*/
    _5729 = _n_10255 >> 1;
    _n2_10256 = _5729 + 1;
    _5729 = NOVALUE;

    /** scinot.e:89		t = repeat(0, n)*/
    DeRef(_t_10257);
    _t_10257 = Repeat(0, _n_10255);

    /** scinot.e:90		lower = 1*/
    _lower_10254 = 1;

    /** scinot.e:91		for upper = n to n2 by -1 do*/
    _5732 = _n2_10256;
    {
        object _upper_10263;
        _upper_10263 = _n_10255;
L1: 
        if (_upper_10263 < _5732){
            goto L2; // [34] 74
        }

        /** scinot.e:92			t[upper] = s[lower]*/
        _2 = (object)SEQ_PTR(_s_10253);
        _5733 = (object)*(((s1_ptr)_2)->base + _lower_10254);
        Ref(_5733);
        _2 = (object)SEQ_PTR(_t_10257);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _t_10257 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _upper_10263);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5733;
        if( _1 != _5733 ){
            DeRef(_1);
        }
        _5733 = NOVALUE;

        /** scinot.e:93			t[lower] = s[upper]*/
        _2 = (object)SEQ_PTR(_s_10253);
        _5734 = (object)*(((s1_ptr)_2)->base + _upper_10263);
        Ref(_5734);
        _2 = (object)SEQ_PTR(_t_10257);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _t_10257 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _lower_10254);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5734;
        if( _1 != _5734 ){
            DeRef(_1);
        }
        _5734 = NOVALUE;

        /** scinot.e:94			lower += 1*/
        _lower_10254 = _lower_10254 + 1;

        /** scinot.e:95		end for*/
        _upper_10263 = _upper_10263 + -1;
        goto L1; // [69] 41
L2: 
        ;
    }

    /** scinot.e:96		return t*/
    DeRefDS(_s_10253);
    return _t_10257;
    ;
}


object _28carry(object _a_10270, object _radix_10271)
{
    object _q_10272 = NOVALUE;
    object _r_10273 = NOVALUE;
    object _b_10274 = NOVALUE;
    object _rmax_10275 = NOVALUE;
    object _i_10276 = NOVALUE;
    object _5748 = NOVALUE;
    object _5747 = NOVALUE;
    object _5746 = NOVALUE;
    object _5743 = NOVALUE;
    object _5737 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:102		rmax = radix - 1*/
    DeRef(_rmax_10275);
    _rmax_10275 = _radix_10271 - 1;
    if ((object)((uintptr_t)_rmax_10275 +(uintptr_t) HIGH_BITS) >= 0){
        _rmax_10275 = NewDouble((eudouble)_rmax_10275);
    }

    /** scinot.e:103		i = 1*/
    DeRef(_i_10276);
    _i_10276 = 1;

    /** scinot.e:104		while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_10270)){
            _5737 = SEQ_PTR(_a_10270)->length;
    }
    else {
        _5737 = 1;
    }
    if (binary_op_a(GREATER, _i_10276, _5737)){
        _5737 = NOVALUE;
        goto L2; // [24] 104
    }
    _5737 = NOVALUE;

    /** scinot.e:105			b = a[i]*/
    DeRef(_b_10274);
    _2 = (object)SEQ_PTR(_a_10270);
    if (!IS_ATOM_INT(_i_10276)){
        _b_10274 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_10276)->dbl));
    }
    else{
        _b_10274 = (object)*(((s1_ptr)_2)->base + _i_10276);
    }
    Ref(_b_10274);

    /** scinot.e:106			if b > rmax then*/
    if (binary_op_a(LESSEQ, _b_10274, _rmax_10275)){
        goto L3; // [36] 93
    }

    /** scinot.e:107				q = floor( b / radix )*/
    DeRef(_q_10272);
    if (IS_ATOM_INT(_b_10274)) {
        if (_radix_10271 > 0 && _b_10274 >= 0) {
            _q_10272 = _b_10274 / _radix_10271;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_b_10274 / (eudouble)_radix_10271);
            if (_b_10274 != MININT)
            _q_10272 = (object)temp_dbl;
            else
            _q_10272 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _b_10274, _radix_10271);
        _q_10272 = unary_op(FLOOR, _2);
        DeRef(_2);
    }

    /** scinot.e:108				r = remainder( b, radix )*/
    DeRef(_r_10273);
    if (IS_ATOM_INT(_b_10274)) {
        _r_10273 = (_b_10274 % _radix_10271);
    }
    else {
        temp_d.dbl = (eudouble)_radix_10271;
        _r_10273 = Dremainder(DBL_PTR(_b_10274), &temp_d);
    }

    /** scinot.e:109				a[i] = r*/
    Ref(_r_10273);
    _2 = (object)SEQ_PTR(_a_10270);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _a_10270 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_i_10276))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_10276)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _i_10276);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_10273;
    DeRef(_1);

    /** scinot.e:110				if i = length(a) then*/
    if (IS_SEQUENCE(_a_10270)){
            _5743 = SEQ_PTR(_a_10270)->length;
    }
    else {
        _5743 = 1;
    }
    if (binary_op_a(NOTEQ, _i_10276, _5743)){
        _5743 = NOVALUE;
        goto L4; // [63] 74
    }
    _5743 = NOVALUE;

    /** scinot.e:111					a &= 0*/
    Append(&_a_10270, _a_10270, 0);
L4: 

    /** scinot.e:113				a[i+1] += q*/
    if (IS_ATOM_INT(_i_10276)) {
        _5746 = _i_10276 + 1;
    }
    else
    _5746 = binary_op(PLUS, 1, _i_10276);
    _2 = (object)SEQ_PTR(_a_10270);
    if (!IS_ATOM_INT(_5746)){
        _5747 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_5746)->dbl));
    }
    else{
        _5747 = (object)*(((s1_ptr)_2)->base + _5746);
    }
    if (IS_ATOM_INT(_5747) && IS_ATOM_INT(_q_10272)) {
        _5748 = _5747 + _q_10272;
        if ((object)((uintptr_t)_5748 + (uintptr_t)HIGH_BITS) >= 0){
            _5748 = NewDouble((eudouble)_5748);
        }
    }
    else {
        _5748 = binary_op(PLUS, _5747, _q_10272);
    }
    _5747 = NOVALUE;
    _2 = (object)SEQ_PTR(_a_10270);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _a_10270 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_5746))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_5746)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _5746);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _5748;
    if( _1 != _5748 ){
        DeRef(_1);
    }
    _5748 = NOVALUE;
L3: 

    /** scinot.e:115			i += 1*/
    _0 = _i_10276;
    if (IS_ATOM_INT(_i_10276)) {
        _i_10276 = _i_10276 + 1;
        if (_i_10276 > MAXINT){
            _i_10276 = NewDouble((eudouble)_i_10276);
        }
    }
    else
    _i_10276 = binary_op(PLUS, 1, _i_10276);
    DeRef(_0);

    /** scinot.e:116		end while*/
    goto L1; // [101] 21
L2: 

    /** scinot.e:118		return a*/
    DeRef(_q_10272);
    DeRef(_r_10273);
    DeRef(_b_10274);
    DeRef(_rmax_10275);
    DeRef(_i_10276);
    DeRef(_5746);
    _5746 = NOVALUE;
    return _a_10270;
    ;
}


object _28add(object _a_10296, object _b_10297)
{
    object _5766 = NOVALUE;
    object _5764 = NOVALUE;
    object _5763 = NOVALUE;
    object _5762 = NOVALUE;
    object _5761 = NOVALUE;
    object _5759 = NOVALUE;
    object _5758 = NOVALUE;
    object _5756 = NOVALUE;
    object _5755 = NOVALUE;
    object _5754 = NOVALUE;
    object _5753 = NOVALUE;
    object _5751 = NOVALUE;
    object _5750 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:123		if length(a) < length(b) then*/
    if (IS_SEQUENCE(_a_10296)){
            _5750 = SEQ_PTR(_a_10296)->length;
    }
    else {
        _5750 = 1;
    }
    if (IS_SEQUENCE(_b_10297)){
            _5751 = SEQ_PTR(_b_10297)->length;
    }
    else {
        _5751 = 1;
    }
    if (_5750 >= _5751)
    goto L1; // [13] 40

    /** scinot.e:124			a &= repeat( 0, length(b) - length(a) )*/
    if (IS_SEQUENCE(_b_10297)){
            _5753 = SEQ_PTR(_b_10297)->length;
    }
    else {
        _5753 = 1;
    }
    if (IS_SEQUENCE(_a_10296)){
            _5754 = SEQ_PTR(_a_10296)->length;
    }
    else {
        _5754 = 1;
    }
    _5755 = _5753 - _5754;
    _5753 = NOVALUE;
    _5754 = NOVALUE;
    _5756 = Repeat(0, _5755);
    _5755 = NOVALUE;
    Concat((object_ptr)&_a_10296, _a_10296, _5756);
    DeRefDS(_5756);
    _5756 = NOVALUE;
    goto L2; // [37] 74
L1: 

    /** scinot.e:125		elsif length(b) < length(a) then*/
    if (IS_SEQUENCE(_b_10297)){
            _5758 = SEQ_PTR(_b_10297)->length;
    }
    else {
        _5758 = 1;
    }
    if (IS_SEQUENCE(_a_10296)){
            _5759 = SEQ_PTR(_a_10296)->length;
    }
    else {
        _5759 = 1;
    }
    if (_5758 >= _5759)
    goto L3; // [48] 73

    /** scinot.e:126			b &= repeat( 0, length(a) - length(b) )*/
    if (IS_SEQUENCE(_a_10296)){
            _5761 = SEQ_PTR(_a_10296)->length;
    }
    else {
        _5761 = 1;
    }
    if (IS_SEQUENCE(_b_10297)){
            _5762 = SEQ_PTR(_b_10297)->length;
    }
    else {
        _5762 = 1;
    }
    _5763 = _5761 - _5762;
    _5761 = NOVALUE;
    _5762 = NOVALUE;
    _5764 = Repeat(0, _5763);
    _5763 = NOVALUE;
    Concat((object_ptr)&_b_10297, _b_10297, _5764);
    DeRefDS(_5764);
    _5764 = NOVALUE;
L3: 
L2: 

    /** scinot.e:129		return a + b*/
    _5766 = binary_op(PLUS, _a_10296, _b_10297);
    DeRefDS(_a_10296);
    DeRefDS(_b_10297);
    return _5766;
    ;
}


object _28borrow(object _a_10319, object _radix_10320)
{
    object _5774 = NOVALUE;
    object _5773 = NOVALUE;
    object _5772 = NOVALUE;
    object _5771 = NOVALUE;
    object _5770 = NOVALUE;
    object _5768 = NOVALUE;
    object _5767 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:134		for i = length(a) to 2 by -1 do*/
    if (IS_SEQUENCE(_a_10319)){
            _5767 = SEQ_PTR(_a_10319)->length;
    }
    else {
        _5767 = 1;
    }
    {
        object _i_10322;
        _i_10322 = _5767;
L1: 
        if (_i_10322 < 2){
            goto L2; // [10] 67
        }

        /** scinot.e:135			if a[i] < 0 then*/
        _2 = (object)SEQ_PTR(_a_10319);
        _5768 = (object)*(((s1_ptr)_2)->base + _i_10322);
        if (binary_op_a(GREATEREQ, _5768, 0)){
            _5768 = NOVALUE;
            goto L3; // [23] 60
        }
        _5768 = NOVALUE;

        /** scinot.e:136				a[i] += radix*/
        _2 = (object)SEQ_PTR(_a_10319);
        _5770 = (object)*(((s1_ptr)_2)->base + _i_10322);
        if (IS_ATOM_INT(_5770)) {
            _5771 = _5770 + _radix_10320;
            if ((object)((uintptr_t)_5771 + (uintptr_t)HIGH_BITS) >= 0){
                _5771 = NewDouble((eudouble)_5771);
            }
        }
        else {
            _5771 = binary_op(PLUS, _5770, _radix_10320);
        }
        _5770 = NOVALUE;
        _2 = (object)SEQ_PTR(_a_10319);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _a_10319 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_10322);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5771;
        if( _1 != _5771 ){
            DeRef(_1);
        }
        _5771 = NOVALUE;

        /** scinot.e:137				a[i-1] -= 1*/
        _5772 = _i_10322 - 1;
        _2 = (object)SEQ_PTR(_a_10319);
        _5773 = (object)*(((s1_ptr)_2)->base + _5772);
        if (IS_ATOM_INT(_5773)) {
            _5774 = _5773 - 1;
            if ((object)((uintptr_t)_5774 +(uintptr_t) HIGH_BITS) >= 0){
                _5774 = NewDouble((eudouble)_5774);
            }
        }
        else {
            _5774 = binary_op(MINUS, _5773, 1);
        }
        _5773 = NOVALUE;
        _2 = (object)SEQ_PTR(_a_10319);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _a_10319 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _5772);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5774;
        if( _1 != _5774 ){
            DeRef(_1);
        }
        _5774 = NOVALUE;
L3: 

        /** scinot.e:139		end for*/
        _i_10322 = _i_10322 + -1;
        goto L1; // [62] 17
L2: 
        ;
    }

    /** scinot.e:140		return a*/
    DeRef(_5772);
    _5772 = NOVALUE;
    return _a_10319;
    ;
}


object _28bits_to_bytes(object _bits_10334)
{
    object _bytes_10335 = NOVALUE;
    object _r_10336 = NOVALUE;
    object _5783 = NOVALUE;
    object _5782 = NOVALUE;
    object _5781 = NOVALUE;
    object _5780 = NOVALUE;
    object _5778 = NOVALUE;
    object _5777 = NOVALUE;
    object _5775 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:155		r = remainder( length(bits), 8 )*/
    if (IS_SEQUENCE(_bits_10334)){
            _5775 = SEQ_PTR(_bits_10334)->length;
    }
    else {
        _5775 = 1;
    }
    _r_10336 = (_5775 % 8);
    _5775 = NOVALUE;

    /** scinot.e:156		if r  then*/
    if (_r_10336 == 0)
    {
        goto L1; // [14] 32
    }
    else{
    }

    /** scinot.e:157			bits &= repeat( 0, 8 - r )*/
    _5777 = 8 - _r_10336;
    _5778 = Repeat(0, _5777);
    _5777 = NOVALUE;
    Concat((object_ptr)&_bits_10334, _bits_10334, _5778);
    DeRefDS(_5778);
    _5778 = NOVALUE;
L1: 

    /** scinot.e:160		bytes = {}*/
    RefDS(_5);
    DeRef(_bytes_10335);
    _bytes_10335 = _5;

    /** scinot.e:161		for i = 1 to length(bits) by 8 do*/
    if (IS_SEQUENCE(_bits_10334)){
            _5780 = SEQ_PTR(_bits_10334)->length;
    }
    else {
        _5780 = 1;
    }
    {
        object _i_10344;
        _i_10344 = 1;
L2: 
        if (_i_10344 > _5780){
            goto L3; // [44] 77
        }

        /** scinot.e:162			bytes &= bits_to_int( bits[i..i+7] )*/
        _5781 = _i_10344 + 7;
        rhs_slice_target = (object_ptr)&_5782;
        RHS_Slice(_bits_10334, _i_10344, _5781);
        _5783 = _15bits_to_int(_5782);
        _5782 = NOVALUE;
        if (IS_SEQUENCE(_bytes_10335) && IS_ATOM(_5783)) {
            Ref(_5783);
            Append(&_bytes_10335, _bytes_10335, _5783);
        }
        else if (IS_ATOM(_bytes_10335) && IS_SEQUENCE(_5783)) {
        }
        else {
            Concat((object_ptr)&_bytes_10335, _bytes_10335, _5783);
        }
        DeRef(_5783);
        _5783 = NOVALUE;

        /** scinot.e:163		end for*/
        _i_10344 = _i_10344 + 8;
        goto L2; // [72] 51
L3: 
        ;
    }

    /** scinot.e:164		return bytes*/
    DeRefDS(_bits_10334);
    DeRef(_5781);
    _5781 = NOVALUE;
    return _bytes_10335;
    ;
}


object _28bytes_to_bits(object _bytes_10353)
{
    object _bits_10354 = NOVALUE;
    object _5787 = NOVALUE;
    object _5786 = NOVALUE;
    object _5785 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:179		bits = {}*/
    RefDS(_5);
    DeRef(_bits_10354);
    _bits_10354 = _5;

    /** scinot.e:180		for i = 1 to length(bytes) do*/
    if (IS_SEQUENCE(_bytes_10353)){
            _5785 = SEQ_PTR(_bytes_10353)->length;
    }
    else {
        _5785 = 1;
    }
    {
        object _i_10356;
        _i_10356 = 1;
L1: 
        if (_i_10356 > _5785){
            goto L2; // [15] 44
        }

        /** scinot.e:181			bits &= int_to_bits( bytes[i], 8 )*/
        _2 = (object)SEQ_PTR(_bytes_10353);
        _5786 = (object)*(((s1_ptr)_2)->base + _i_10356);
        Ref(_5786);
        _5787 = _15int_to_bits(_5786, 8);
        _5786 = NOVALUE;
        if (IS_SEQUENCE(_bits_10354) && IS_ATOM(_5787)) {
            Ref(_5787);
            Append(&_bits_10354, _bits_10354, _5787);
        }
        else if (IS_ATOM(_bits_10354) && IS_SEQUENCE(_5787)) {
        }
        else {
            Concat((object_ptr)&_bits_10354, _bits_10354, _5787);
        }
        DeRef(_5787);
        _5787 = NOVALUE;

        /** scinot.e:182		end for*/
        _i_10356 = _i_10356 + 1;
        goto L1; // [39] 22
L2: 
        ;
    }

    /** scinot.e:184		return bits*/
    DeRefDS(_bytes_10353);
    return _bits_10354;
    ;
}


object _28convert_radix(object _number_10364, object _from_radix_10365, object _to_radix_10366)
{
    object _target_10367 = NOVALUE;
    object _base_10368 = NOVALUE;
    object _5794 = NOVALUE;
    object _5793 = NOVALUE;
    object _5792 = NOVALUE;
    object _5791 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:190		base = {1}*/
    RefDS(_5789);
    DeRef(_base_10368);
    _base_10368 = _5789;

    /** scinot.e:191		target = {0}*/
    _0 = _target_10367;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    _target_10367 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scinot.e:192		for i = 1 to length(number) do*/
    if (IS_SEQUENCE(_number_10364)){
            _5791 = SEQ_PTR(_number_10364)->length;
    }
    else {
        _5791 = 1;
    }
    {
        object _i_10372;
        _i_10372 = 1;
L1: 
        if (_i_10372 > _5791){
            goto L2; // [25] 78
        }

        /** scinot.e:193			target = carry( add( base * number[i], target ), to_radix )*/
        _2 = (object)SEQ_PTR(_number_10364);
        _5792 = (object)*(((s1_ptr)_2)->base + _i_10372);
        _5793 = binary_op(MULTIPLY, _base_10368, _5792);
        _5792 = NOVALUE;
        RefDS(_target_10367);
        _5794 = _28add(_5793, _target_10367);
        _5793 = NOVALUE;
        _0 = _target_10367;
        _target_10367 = _28carry(_5794, _to_radix_10366);
        DeRefDS(_0);
        _5794 = NOVALUE;

        /** scinot.e:194			base *= from_radix*/
        _0 = _base_10368;
        _base_10368 = binary_op(MULTIPLY, _base_10368, _from_radix_10365);
        DeRefDS(_0);

        /** scinot.e:195			base = carry( base, to_radix )*/
        RefDS(_base_10368);
        _0 = _base_10368;
        _base_10368 = _28carry(_base_10368, _to_radix_10366);
        DeRefDS(_0);

        /** scinot.e:196		end for*/
        _i_10372 = _i_10372 + 1;
        goto L1; // [73] 32
L2: 
        ;
    }

    /** scinot.e:198		return target*/
    DeRefDS(_number_10364);
    DeRef(_base_10368);
    return _target_10367;
    ;
}


object _28half(object _decimal_10382)
{
    object _quotient_10383 = NOVALUE;
    object _q_10384 = NOVALUE;
    object _Q_10385 = NOVALUE;
    object _5815 = NOVALUE;
    object _5814 = NOVALUE;
    object _5813 = NOVALUE;
    object _5812 = NOVALUE;
    object _5811 = NOVALUE;
    object _5810 = NOVALUE;
    object _5807 = NOVALUE;
    object _5805 = NOVALUE;
    object _5804 = NOVALUE;
    object _5801 = NOVALUE;
    object _5800 = NOVALUE;
    object _5798 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:205		quotient = repeat( 0, length(decimal) )*/
    if (IS_SEQUENCE(_decimal_10382)){
            _5798 = SEQ_PTR(_decimal_10382)->length;
    }
    else {
        _5798 = 1;
    }
    DeRef(_quotient_10383);
    _quotient_10383 = Repeat(0, _5798);
    _5798 = NOVALUE;

    /** scinot.e:206		for i = 1 to length( decimal ) do*/
    if (IS_SEQUENCE(_decimal_10382)){
            _5800 = SEQ_PTR(_decimal_10382)->length;
    }
    else {
        _5800 = 1;
    }
    {
        object _i_10389;
        _i_10389 = 1;
L1: 
        if (_i_10389 > _5800){
            goto L2; // [17] 101
        }

        /** scinot.e:207			q = decimal[i] / 2*/
        _2 = (object)SEQ_PTR(_decimal_10382);
        _5801 = (object)*(((s1_ptr)_2)->base + _i_10389);
        DeRef(_q_10384);
        if (IS_ATOM_INT(_5801)) {
            if (_5801 & 1) {
                _q_10384 = NewDouble((_5801 >> 1) + 0.5);
            }
            else
            _q_10384 = _5801 >> 1;
        }
        else {
            _q_10384 = binary_op(DIVIDE, _5801, 2);
        }
        _5801 = NOVALUE;

        /** scinot.e:208			Q = floor( q )*/
        DeRef(_Q_10385);
        if (IS_ATOM_INT(_q_10384))
        _Q_10385 = e_floor(_q_10384);
        else
        _Q_10385 = unary_op(FLOOR, _q_10384);

        /** scinot.e:209			quotient[i] +=  Q*/
        _2 = (object)SEQ_PTR(_quotient_10383);
        _5804 = (object)*(((s1_ptr)_2)->base + _i_10389);
        if (IS_ATOM_INT(_5804) && IS_ATOM_INT(_Q_10385)) {
            _5805 = _5804 + _Q_10385;
            if ((object)((uintptr_t)_5805 + (uintptr_t)HIGH_BITS) >= 0){
                _5805 = NewDouble((eudouble)_5805);
            }
        }
        else {
            _5805 = binary_op(PLUS, _5804, _Q_10385);
        }
        _5804 = NOVALUE;
        _2 = (object)SEQ_PTR(_quotient_10383);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _quotient_10383 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_10389);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5805;
        if( _1 != _5805 ){
            DeRef(_1);
        }
        _5805 = NOVALUE;

        /** scinot.e:211			if q != Q then*/
        if (binary_op_a(EQUALS, _q_10384, _Q_10385)){
            goto L3; // [55] 94
        }

        /** scinot.e:212				if length(quotient) = i then*/
        if (IS_SEQUENCE(_quotient_10383)){
                _5807 = SEQ_PTR(_quotient_10383)->length;
        }
        else {
            _5807 = 1;
        }
        if (_5807 != _i_10389)
        goto L4; // [64] 75

        /** scinot.e:213					quotient &= 0*/
        Append(&_quotient_10383, _quotient_10383, 0);
L4: 

        /** scinot.e:215				quotient[i+1] += 5*/
        _5810 = _i_10389 + 1;
        _2 = (object)SEQ_PTR(_quotient_10383);
        _5811 = (object)*(((s1_ptr)_2)->base + _5810);
        if (IS_ATOM_INT(_5811)) {
            _5812 = _5811 + 5;
            if ((object)((uintptr_t)_5812 + (uintptr_t)HIGH_BITS) >= 0){
                _5812 = NewDouble((eudouble)_5812);
            }
        }
        else {
            _5812 = binary_op(PLUS, _5811, 5);
        }
        _5811 = NOVALUE;
        _2 = (object)SEQ_PTR(_quotient_10383);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _quotient_10383 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _5810);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5812;
        if( _1 != _5812 ){
            DeRef(_1);
        }
        _5812 = NOVALUE;
L3: 

        /** scinot.e:217		end for*/
        _i_10389 = _i_10389 + 1;
        goto L1; // [96] 24
L2: 
        ;
    }

    /** scinot.e:218		return reverse( carry( reverse( quotient ), 10 ) )*/
    RefDS(_quotient_10383);
    _5813 = _28reverse(_quotient_10383);
    _5814 = _28carry(_5813, 10);
    _5813 = NOVALUE;
    _5815 = _28reverse(_5814);
    _5814 = NOVALUE;
    DeRefDS(_decimal_10382);
    DeRefDS(_quotient_10383);
    DeRef(_q_10384);
    DeRef(_Q_10385);
    DeRef(_5810);
    _5810 = NOVALUE;
    return _5815;
    ;
}


object _28decimals_to_bits(object _decimals_10418, object _size_10419)
{
    object _sub_10420 = NOVALUE;
    object _bits_10421 = NOVALUE;
    object _bit_10422 = NOVALUE;
    object _assigned_10423 = NOVALUE;
    object _5843 = NOVALUE;
    object _5839 = NOVALUE;
    object _5838 = NOVALUE;
    object _5837 = NOVALUE;
    object _5836 = NOVALUE;
    object _5834 = NOVALUE;
    object _5833 = NOVALUE;
    object _5832 = NOVALUE;
    object _5830 = NOVALUE;
    object _5828 = NOVALUE;
    object _5827 = NOVALUE;
    object _5826 = NOVALUE;
    object _5825 = NOVALUE;
    object _5824 = NOVALUE;
    object _5822 = NOVALUE;
    object _5820 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:233		sub = {5}*/
    RefDS(_5818);
    DeRef(_sub_10420);
    _sub_10420 = _5818;

    /** scinot.e:234		bits = repeat( 0, size )*/
    DeRef(_bits_10421);
    _bits_10421 = Repeat(0, _size_10419);

    /** scinot.e:235		bit = 1*/
    _bit_10422 = 1;

    /** scinot.e:236		assigned = 0*/
    _assigned_10423 = 0;

    /** scinot.e:240		if compare(decimals, bits) > 0 then */
    if (IS_ATOM_INT(_decimals_10418) && IS_ATOM_INT(_bits_10421)){
        _5820 = (_decimals_10418 < _bits_10421) ? -1 : (_decimals_10418 > _bits_10421);
    }
    else{
        _5820 = compare(_decimals_10418, _bits_10421);
    }
    if (_5820 <= 0)
    goto L1; // [34] 166

    /** scinot.e:242			while (not assigned) or (bit < find( 1, bits ) + size + 1)  do*/
L2: 
    _5822 = (_assigned_10423 == 0);
    if (_5822 != 0) {
        goto L3; // [46] 72
    }
    _5824 = find_from(1, _bits_10421, 1);
    _5825 = _5824 + _size_10419;
    if ((object)((uintptr_t)_5825 + (uintptr_t)HIGH_BITS) >= 0){
        _5825 = NewDouble((eudouble)_5825);
    }
    _5824 = NOVALUE;
    if (IS_ATOM_INT(_5825)) {
        _5826 = _5825 + 1;
        if (_5826 > MAXINT){
            _5826 = NewDouble((eudouble)_5826);
        }
    }
    else
    _5826 = binary_op(PLUS, 1, _5825);
    DeRef(_5825);
    _5825 = NOVALUE;
    if (IS_ATOM_INT(_5826)) {
        _5827 = (_bit_10422 < _5826);
    }
    else {
        _5827 = ((eudouble)_bit_10422 < DBL_PTR(_5826)->dbl);
    }
    DeRef(_5826);
    _5826 = NOVALUE;
    if (_5827 == 0)
    {
        DeRef(_5827);
        _5827 = NOVALUE;
        goto L4; // [68] 165
    }
    else{
        DeRef(_5827);
        _5827 = NOVALUE;
    }
L3: 

    /** scinot.e:243				if compare( sub, decimals ) <= 0 then*/
    if (IS_ATOM_INT(_sub_10420) && IS_ATOM_INT(_decimals_10418)){
        _5828 = (_sub_10420 < _decimals_10418) ? -1 : (_sub_10420 > _decimals_10418);
    }
    else{
        _5828 = compare(_sub_10420, _decimals_10418);
    }
    if (_5828 > 0)
    goto L5; // [78] 146

    /** scinot.e:244					assigned = 1*/
    _assigned_10423 = 1;

    /** scinot.e:245					if length( bits ) < bit then*/
    if (IS_SEQUENCE(_bits_10421)){
            _5830 = SEQ_PTR(_bits_10421)->length;
    }
    else {
        _5830 = 1;
    }
    if (_5830 >= _bit_10422)
    goto L6; // [92] 114

    /** scinot.e:246						bits &= repeat( 0, bit - length(bits)) */
    if (IS_SEQUENCE(_bits_10421)){
            _5832 = SEQ_PTR(_bits_10421)->length;
    }
    else {
        _5832 = 1;
    }
    _5833 = _bit_10422 - _5832;
    _5832 = NOVALUE;
    _5834 = Repeat(0, _5833);
    _5833 = NOVALUE;
    Concat((object_ptr)&_bits_10421, _bits_10421, _5834);
    DeRefDS(_5834);
    _5834 = NOVALUE;
L6: 

    /** scinot.e:249					bits[bit] += 1*/
    _2 = (object)SEQ_PTR(_bits_10421);
    _5836 = (object)*(((s1_ptr)_2)->base + _bit_10422);
    if (IS_ATOM_INT(_5836)) {
        _5837 = _5836 + 1;
        if (_5837 > MAXINT){
            _5837 = NewDouble((eudouble)_5837);
        }
    }
    else
    _5837 = binary_op(PLUS, 1, _5836);
    _5836 = NOVALUE;
    _2 = (object)SEQ_PTR(_bits_10421);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bits_10421 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _bit_10422);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _5837;
    if( _1 != _5837 ){
        DeRef(_1);
    }
    _5837 = NOVALUE;

    /** scinot.e:250					decimals = borrow( add( decimals, -sub ), 10 )*/
    _5838 = unary_op(UMINUS, _sub_10420);
    RefDS(_decimals_10418);
    _5839 = _28add(_decimals_10418, _5838);
    _5838 = NOVALUE;
    _0 = _decimals_10418;
    _decimals_10418 = _28borrow(_5839, 10);
    DeRefDS(_0);
    _5839 = NOVALUE;
L5: 

    /** scinot.e:252				sub = half( sub )*/
    RefDS(_sub_10420);
    _0 = _sub_10420;
    _sub_10420 = _28half(_sub_10420);
    DeRefDS(_0);

    /** scinot.e:254				bit += 1*/
    _bit_10422 = _bit_10422 + 1;

    /** scinot.e:255			end while*/
    goto L2; // [162] 43
L4: 
L1: 

    /** scinot.e:258		return reverse(bits)*/
    RefDS(_bits_10421);
    _5843 = _28reverse(_bits_10421);
    DeRefDS(_decimals_10418);
    DeRef(_sub_10420);
    DeRefDS(_bits_10421);
    DeRef(_5822);
    _5822 = NOVALUE;
    return _5843;
    ;
}


object _28string_to_int(object _s_10456)
{
    object _int_10457 = NOVALUE;
    object _5847 = NOVALUE;
    object _5846 = NOVALUE;
    object _5844 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:263		int = 0*/
    _int_10457 = 0;

    /** scinot.e:264		for i = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_10456)){
            _5844 = SEQ_PTR(_s_10456)->length;
    }
    else {
        _5844 = 1;
    }
    {
        object _i_10459;
        _i_10459 = 1;
L1: 
        if (_i_10459 > _5844){
            goto L2; // [13] 51
        }

        /** scinot.e:265			int *= 10*/
        _int_10457 = _int_10457 * 10;

        /** scinot.e:266			int += s[i] - '0'*/
        _2 = (object)SEQ_PTR(_s_10456);
        _5846 = (object)*(((s1_ptr)_2)->base + _i_10459);
        if (IS_ATOM_INT(_5846)) {
            _5847 = _5846 - 48;
            if ((object)((uintptr_t)_5847 +(uintptr_t) HIGH_BITS) >= 0){
                _5847 = NewDouble((eudouble)_5847);
            }
        }
        else {
            _5847 = binary_op(MINUS, _5846, 48);
        }
        _5846 = NOVALUE;
        if (IS_ATOM_INT(_5847)) {
            _int_10457 = _int_10457 + _5847;
        }
        else {
            _int_10457 = binary_op(PLUS, _int_10457, _5847);
        }
        DeRef(_5847);
        _5847 = NOVALUE;
        if (!IS_ATOM_INT(_int_10457)) {
            _1 = (object)(DBL_PTR(_int_10457)->dbl);
            DeRefDS(_int_10457);
            _int_10457 = _1;
        }

        /** scinot.e:267		end for*/
        _i_10459 = _i_10459 + 1;
        goto L1; // [46] 20
L2: 
        ;
    }

    /** scinot.e:268		return int*/
    DeRefDS(_s_10456);
    return _int_10457;
    ;
}


object _28trim_bits(object _bits_10467)
{
    object _5854 = NOVALUE;
    object _5853 = NOVALUE;
    object _5852 = NOVALUE;
    object _5851 = NOVALUE;
    object _5850 = NOVALUE;
    object _5849 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:272			while length(bits) and not bits[$] do*/
L1: 
    if (IS_SEQUENCE(_bits_10467)){
            _5849 = SEQ_PTR(_bits_10467)->length;
    }
    else {
        _5849 = 1;
    }
    if (_5849 == 0) {
        goto L2; // [11] 44
    }
    if (IS_SEQUENCE(_bits_10467)){
            _5851 = SEQ_PTR(_bits_10467)->length;
    }
    else {
        _5851 = 1;
    }
    _2 = (object)SEQ_PTR(_bits_10467);
    _5852 = (object)*(((s1_ptr)_2)->base + _5851);
    if (IS_ATOM_INT(_5852)) {
        _5853 = (_5852 == 0);
    }
    else {
        _5853 = unary_op(NOT, _5852);
    }
    _5852 = NOVALUE;
    if (_5853 <= 0) {
        if (_5853 == 0) {
            DeRef(_5853);
            _5853 = NOVALUE;
            goto L2; // [26] 44
        }
        else {
            if (!IS_ATOM_INT(_5853) && DBL_PTR(_5853)->dbl == 0.0){
                DeRef(_5853);
                _5853 = NOVALUE;
                goto L2; // [26] 44
            }
            DeRef(_5853);
            _5853 = NOVALUE;
        }
    }
    DeRef(_5853);
    _5853 = NOVALUE;

    /** scinot.e:273				bits = remove( bits, length( bits ) )*/
    if (IS_SEQUENCE(_bits_10467)){
            _5854 = SEQ_PTR(_bits_10467)->length;
    }
    else {
        _5854 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_bits_10467);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_5854)) ? _5854 : (object)(DBL_PTR(_5854)->dbl);
        int stop = (IS_ATOM_INT(_5854)) ? _5854 : (object)(DBL_PTR(_5854)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_bits_10467), start, &_bits_10467 );
            }
            else Tail(SEQ_PTR(_bits_10467), stop+1, &_bits_10467);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_bits_10467), start, &_bits_10467);
        }
        else {
            assign_slice_seq = &assign_space;
            _bits_10467 = Remove_elements(start, stop, (SEQ_PTR(_bits_10467)->ref == 1));
        }
    }
    _5854 = NOVALUE;
    _5854 = NOVALUE;

    /** scinot.e:274			end while*/
    goto L1; // [41] 8
L2: 

    /** scinot.e:275			return bits*/
    return _bits_10467;
    ;
}


object _28scientific_to_float(object _s_10490, object _fp_10491)
{
    object _dp_10492 = NOVALUE;
    object _e_10493 = NOVALUE;
    object _exp_10494 = NOVALUE;
    object _int_bits_10495 = NOVALUE;
    object _frac_bits_10496 = NOVALUE;
    object _mbits_10497 = NOVALUE;
    object _ebits_10498 = NOVALUE;
    object _sbits_10499 = NOVALUE;
    object _significand_10500 = NOVALUE;
    object _exponent_10501 = NOVALUE;
    object _min_exp_10502 = NOVALUE;
    object _exp_bias_10503 = NOVALUE;
    object _6013 = NOVALUE;
    object _6012 = NOVALUE;
    object _6010 = NOVALUE;
    object _6008 = NOVALUE;
    object _6007 = NOVALUE;
    object _6005 = NOVALUE;
    object _6004 = NOVALUE;
    object _6003 = NOVALUE;
    object _6002 = NOVALUE;
    object _6001 = NOVALUE;
    object _6000 = NOVALUE;
    object _5999 = NOVALUE;
    object _5997 = NOVALUE;
    object _5996 = NOVALUE;
    object _5994 = NOVALUE;
    object _5993 = NOVALUE;
    object _5992 = NOVALUE;
    object _5991 = NOVALUE;
    object _5988 = NOVALUE;
    object _5987 = NOVALUE;
    object _5986 = NOVALUE;
    object _5985 = NOVALUE;
    object _5984 = NOVALUE;
    object _5983 = NOVALUE;
    object _5982 = NOVALUE;
    object _5981 = NOVALUE;
    object _5978 = NOVALUE;
    object _5977 = NOVALUE;
    object _5974 = NOVALUE;
    object _5973 = NOVALUE;
    object _5972 = NOVALUE;
    object _5971 = NOVALUE;
    object _5968 = NOVALUE;
    object _5967 = NOVALUE;
    object _5965 = NOVALUE;
    object _5964 = NOVALUE;
    object _5962 = NOVALUE;
    object _5960 = NOVALUE;
    object _5959 = NOVALUE;
    object _5958 = NOVALUE;
    object _5957 = NOVALUE;
    object _5956 = NOVALUE;
    object _5955 = NOVALUE;
    object _5954 = NOVALUE;
    object _5953 = NOVALUE;
    object _5952 = NOVALUE;
    object _5951 = NOVALUE;
    object _5949 = NOVALUE;
    object _5948 = NOVALUE;
    object _5947 = NOVALUE;
    object _5946 = NOVALUE;
    object _5944 = NOVALUE;
    object _5943 = NOVALUE;
    object _5942 = NOVALUE;
    object _5941 = NOVALUE;
    object _5938 = NOVALUE;
    object _5936 = NOVALUE;
    object _5935 = NOVALUE;
    object _5934 = NOVALUE;
    object _5933 = NOVALUE;
    object _5932 = NOVALUE;
    object _5930 = NOVALUE;
    object _5929 = NOVALUE;
    object _5928 = NOVALUE;
    object _5927 = NOVALUE;
    object _5926 = NOVALUE;
    object _5925 = NOVALUE;
    object _5923 = NOVALUE;
    object _5922 = NOVALUE;
    object _5921 = NOVALUE;
    object _5920 = NOVALUE;
    object _5919 = NOVALUE;
    object _5917 = NOVALUE;
    object _5916 = NOVALUE;
    object _5914 = NOVALUE;
    object _5913 = NOVALUE;
    object _5912 = NOVALUE;
    object _5911 = NOVALUE;
    object _5910 = NOVALUE;
    object _5908 = NOVALUE;
    object _5906 = NOVALUE;
    object _5903 = NOVALUE;
    object _5902 = NOVALUE;
    object _5900 = NOVALUE;
    object _5899 = NOVALUE;
    object _5897 = NOVALUE;
    object _5893 = NOVALUE;
    object _5892 = NOVALUE;
    object _5891 = NOVALUE;
    object _5890 = NOVALUE;
    object _5888 = NOVALUE;
    object _5887 = NOVALUE;
    object _5886 = NOVALUE;
    object _5885 = NOVALUE;
    object _5883 = NOVALUE;
    object _5882 = NOVALUE;
    object _5880 = NOVALUE;
    object _5879 = NOVALUE;
    object _5878 = NOVALUE;
    object _5877 = NOVALUE;
    object _5875 = NOVALUE;
    object _5874 = NOVALUE;
    object _5867 = NOVALUE;
    object _5863 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:316		if fp = NATIVE then*/
    if (_fp_10491 != 1)
    goto L1; // [5] 17

    /** scinot.e:317			fp = NATIVE_FORMAT*/
    _fp_10491 = _28NATIVE_FORMAT_10245;
L1: 

    /** scinot.e:319		if fp = DOUBLE then*/
    if (_fp_10491 != 2)
    goto L2; // [19] 46

    /** scinot.e:320			significand = DOUBLE_SIGNIFICAND*/
    _significand_10500 = 52;

    /** scinot.e:321			exponent    = DOUBLE_EXPONENT*/
    _exponent_10501 = 11;

    /** scinot.e:322			min_exp     = DOUBLE_MIN_EXP*/
    _min_exp_10502 = -1023;

    /** scinot.e:323			exp_bias    = DOUBLE_EXP_BIAS*/
    _exp_bias_10503 = 1023;
    goto L3; // [43] 74
L2: 

    /** scinot.e:325		elsif fp = EXTENDED then*/
    if (_fp_10491 != 3)
    goto L4; // [48] 73

    /** scinot.e:326			significand = EXTENDED_SIGNIFICAND*/
    _significand_10500 = 64;

    /** scinot.e:327			exponent    = EXTENDED_EXPONENT*/
    _exponent_10501 = 15;

    /** scinot.e:328			min_exp     = EXTENDED_MIN_EXP*/
    _min_exp_10502 = -16383;

    /** scinot.e:329			exp_bias    = EXTENDED_EXP_BIAS*/
    _exp_bias_10503 = 16383;
L4: 
L3: 

    /** scinot.e:333		if s[1] = '-' then*/
    _2 = (object)SEQ_PTR(_s_10490);
    _5863 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5863, 45)){
        _5863 = NOVALUE;
        goto L5; // [80] 101
    }
    _5863 = NOVALUE;

    /** scinot.e:334			sbits = {1}*/
    RefDS(_5789);
    DeRefi(_sbits_10499);
    _sbits_10499 = _5789;

    /** scinot.e:335			s = remove( s, 1 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_s_10490);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1)) ? 1 : (object)(DBL_PTR(1)->dbl);
        int stop = (IS_ATOM_INT(1)) ? 1 : (object)(DBL_PTR(1)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_s_10490), start, &_s_10490 );
            }
            else Tail(SEQ_PTR(_s_10490), stop+1, &_s_10490);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_s_10490), start, &_s_10490);
        }
        else {
            assign_slice_seq = &assign_space;
            _s_10490 = Remove_elements(start, stop, (SEQ_PTR(_s_10490)->ref == 1));
        }
    }
    goto L6; // [98] 126
L5: 

    /** scinot.e:337			sbits = {0}*/
    _0 = _sbits_10499;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    _sbits_10499 = MAKE_SEQ(_1);
    DeRefi(_0);

    /** scinot.e:338			if s[1] = '+' then*/
    _2 = (object)SEQ_PTR(_s_10490);
    _5867 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5867, 43)){
        _5867 = NOVALUE;
        goto L7; // [113] 125
    }
    _5867 = NOVALUE;

    /** scinot.e:339				s = remove( s, 1 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_s_10490);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1)) ? 1 : (object)(DBL_PTR(1)->dbl);
        int stop = (IS_ATOM_INT(1)) ? 1 : (object)(DBL_PTR(1)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_s_10490), start, &_s_10490 );
            }
            else Tail(SEQ_PTR(_s_10490), stop+1, &_s_10490);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_s_10490), start, &_s_10490);
        }
        else {
            assign_slice_seq = &assign_space;
            _s_10490 = Remove_elements(start, stop, (SEQ_PTR(_s_10490)->ref == 1));
        }
    }
L7: 
L6: 

    /** scinot.e:344		dp = find('.', s)*/
    _dp_10492 = find_from(46, _s_10490, 1);

    /** scinot.e:345		e = find( 'e', s )*/
    _e_10493 = find_from(101, _s_10490, 1);

    /** scinot.e:346		if not e then*/
    if (_e_10493 != 0)
    goto L8; // [142] 153

    /** scinot.e:347			e = find('E', s )*/
    _e_10493 = find_from(69, _s_10490, 1);
L8: 

    /** scinot.e:351		exp = 0*/
    _exp_10494 = 0;

    /** scinot.e:352		if s[e+1] = '-' then*/
    _5874 = _e_10493 + 1;
    _2 = (object)SEQ_PTR(_s_10490);
    _5875 = (object)*(((s1_ptr)_2)->base + _5874);
    if (binary_op_a(NOTEQ, _5875, 45)){
        _5875 = NOVALUE;
        goto L9; // [168] 199
    }
    _5875 = NOVALUE;

    /** scinot.e:353			exp -= string_to_int( s[e+2..$] )*/
    _5877 = _e_10493 + 2;
    if ((object)((uintptr_t)_5877 + (uintptr_t)HIGH_BITS) >= 0){
        _5877 = NewDouble((eudouble)_5877);
    }
    if (IS_SEQUENCE(_s_10490)){
            _5878 = SEQ_PTR(_s_10490)->length;
    }
    else {
        _5878 = 1;
    }
    rhs_slice_target = (object_ptr)&_5879;
    RHS_Slice(_s_10490, _5877, _5878);
    _5880 = _28string_to_int(_5879);
    _5879 = NOVALUE;
    if (IS_ATOM_INT(_5880)) {
        _exp_10494 = _exp_10494 - _5880;
    }
    else {
        _exp_10494 = binary_op(MINUS, _exp_10494, _5880);
    }
    DeRef(_5880);
    _5880 = NOVALUE;
    if (!IS_ATOM_INT(_exp_10494)) {
        _1 = (object)(DBL_PTR(_exp_10494)->dbl);
        DeRefDS(_exp_10494);
        _exp_10494 = _1;
    }
    goto LA; // [196] 266
L9: 

    /** scinot.e:356			if s[e+1] = '+' then*/
    _5882 = _e_10493 + 1;
    _2 = (object)SEQ_PTR(_s_10490);
    _5883 = (object)*(((s1_ptr)_2)->base + _5882);
    if (binary_op_a(NOTEQ, _5883, 43)){
        _5883 = NOVALUE;
        goto LB; // [209] 240
    }
    _5883 = NOVALUE;

    /** scinot.e:357				exp += string_to_int( s[e+2..$] )*/
    _5885 = _e_10493 + 2;
    if ((object)((uintptr_t)_5885 + (uintptr_t)HIGH_BITS) >= 0){
        _5885 = NewDouble((eudouble)_5885);
    }
    if (IS_SEQUENCE(_s_10490)){
            _5886 = SEQ_PTR(_s_10490)->length;
    }
    else {
        _5886 = 1;
    }
    rhs_slice_target = (object_ptr)&_5887;
    RHS_Slice(_s_10490, _5885, _5886);
    _5888 = _28string_to_int(_5887);
    _5887 = NOVALUE;
    if (IS_ATOM_INT(_5888)) {
        _exp_10494 = _exp_10494 + _5888;
    }
    else {
        _exp_10494 = binary_op(PLUS, _exp_10494, _5888);
    }
    DeRef(_5888);
    _5888 = NOVALUE;
    if (!IS_ATOM_INT(_exp_10494)) {
        _1 = (object)(DBL_PTR(_exp_10494)->dbl);
        DeRefDS(_exp_10494);
        _exp_10494 = _1;
    }
    goto LC; // [237] 265
LB: 

    /** scinot.e:359				exp += string_to_int( s[e+1..$] )*/
    _5890 = _e_10493 + 1;
    if (_5890 > MAXINT){
        _5890 = NewDouble((eudouble)_5890);
    }
    if (IS_SEQUENCE(_s_10490)){
            _5891 = SEQ_PTR(_s_10490)->length;
    }
    else {
        _5891 = 1;
    }
    rhs_slice_target = (object_ptr)&_5892;
    RHS_Slice(_s_10490, _5890, _5891);
    _5893 = _28string_to_int(_5892);
    _5892 = NOVALUE;
    if (IS_ATOM_INT(_5893)) {
        _exp_10494 = _exp_10494 + _5893;
    }
    else {
        _exp_10494 = binary_op(PLUS, _exp_10494, _5893);
    }
    DeRef(_5893);
    _5893 = NOVALUE;
    if (!IS_ATOM_INT(_exp_10494)) {
        _1 = (object)(DBL_PTR(_exp_10494)->dbl);
        DeRefDS(_exp_10494);
        _exp_10494 = _1;
    }
LC: 
LA: 

    /** scinot.e:363		if dp then*/
    if (_dp_10492 == 0)
    {
        goto LD; // [268] 297
    }
    else{
    }

    /** scinot.e:365			s = remove( s, dp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_s_10490);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_dp_10492)) ? _dp_10492 : (object)(DBL_PTR(_dp_10492)->dbl);
        int stop = (IS_ATOM_INT(_dp_10492)) ? _dp_10492 : (object)(DBL_PTR(_dp_10492)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_s_10490), start, &_s_10490 );
            }
            else Tail(SEQ_PTR(_s_10490), stop+1, &_s_10490);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_s_10490), start, &_s_10490);
        }
        else {
            assign_slice_seq = &assign_space;
            _s_10490 = Remove_elements(start, stop, (SEQ_PTR(_s_10490)->ref == 1));
        }
    }

    /** scinot.e:366			e -= 1*/
    _e_10493 = _e_10493 - 1;

    /** scinot.e:369			exp -= e - dp*/
    _5897 = _e_10493 - _dp_10492;
    if ((object)((uintptr_t)_5897 +(uintptr_t) HIGH_BITS) >= 0){
        _5897 = NewDouble((eudouble)_5897);
    }
    if (IS_ATOM_INT(_5897)) {
        _exp_10494 = _exp_10494 - _5897;
    }
    else {
        _exp_10494 = NewDouble((eudouble)_exp_10494 - DBL_PTR(_5897)->dbl);
    }
    DeRef(_5897);
    _5897 = NOVALUE;
    if (!IS_ATOM_INT(_exp_10494)) {
        _1 = (object)(DBL_PTR(_exp_10494)->dbl);
        DeRefDS(_exp_10494);
        _exp_10494 = _1;
    }
LD: 

    /** scinot.e:374		s = s[1..e-1] - '0'*/
    _5899 = _e_10493 - 1;
    rhs_slice_target = (object_ptr)&_5900;
    RHS_Slice(_s_10490, 1, _5899);
    DeRefDS(_s_10490);
    _s_10490 = binary_op(MINUS, _5900, 48);
    DeRefDS(_5900);
    _5900 = NOVALUE;

    /** scinot.e:377		if not find(0, s = 0) then*/
    _5902 = binary_op(EQUALS, _s_10490, 0);
    _5903 = find_from(0, _5902, 1);
    DeRefDS(_5902);
    _5902 = NOVALUE;
    if (_5903 != 0)
    goto LE; // [325] 366
    _5903 = NOVALUE;

    /** scinot.e:378			if fp = DOUBLE then*/
    if (_fp_10491 != 2)
    goto LF; // [330] 347

    /** scinot.e:379				return atom_to_float64(0)*/
    _5906 = _15atom_to_float64(0);
    DeRefDS(_s_10490);
    DeRef(_int_bits_10495);
    DeRef(_frac_bits_10496);
    DeRef(_mbits_10497);
    DeRef(_ebits_10498);
    DeRefi(_sbits_10499);
    DeRef(_5890);
    _5890 = NOVALUE;
    DeRef(_5877);
    _5877 = NOVALUE;
    DeRef(_5885);
    _5885 = NOVALUE;
    DeRef(_5874);
    _5874 = NOVALUE;
    _5899 = NOVALUE;
    DeRef(_5882);
    _5882 = NOVALUE;
    return _5906;
    goto L10; // [344] 365
LF: 

    /** scinot.e:380			elsif fp = EXTENDED then*/
    if (_fp_10491 != 3)
    goto L11; // [349] 364

    /** scinot.e:381				return atom_to_float80(0)*/
    _5908 = _15atom_to_float80(0);
    DeRefDS(_s_10490);
    DeRef(_int_bits_10495);
    DeRef(_frac_bits_10496);
    DeRef(_mbits_10497);
    DeRef(_ebits_10498);
    DeRefi(_sbits_10499);
    DeRef(_5890);
    _5890 = NOVALUE;
    DeRef(_5906);
    _5906 = NOVALUE;
    DeRef(_5877);
    _5877 = NOVALUE;
    DeRef(_5885);
    _5885 = NOVALUE;
    DeRef(_5874);
    _5874 = NOVALUE;
    DeRef(_5899);
    _5899 = NOVALUE;
    DeRef(_5882);
    _5882 = NOVALUE;
    return _5908;
L11: 
L10: 
LE: 

    /** scinot.e:385		if exp >= 0 then*/
    if (_exp_10494 < 0)
    goto L12; // [368] 412

    /** scinot.e:388			int_bits = trim_bits( bytes_to_bits( convert_radix( repeat( 0, exp ) & reverse( s ), 10, #100 ) ) )*/
    _5910 = Repeat(0, _exp_10494);
    RefDS(_s_10490);
    _5911 = _28reverse(_s_10490);
    if (IS_SEQUENCE(_5910) && IS_ATOM(_5911)) {
        Ref(_5911);
        Append(&_5912, _5910, _5911);
    }
    else if (IS_ATOM(_5910) && IS_SEQUENCE(_5911)) {
    }
    else {
        Concat((object_ptr)&_5912, _5910, _5911);
        DeRefDS(_5910);
        _5910 = NOVALUE;
    }
    DeRef(_5910);
    _5910 = NOVALUE;
    DeRef(_5911);
    _5911 = NOVALUE;
    _5913 = _28convert_radix(_5912, 10, 256);
    _5912 = NOVALUE;
    _5914 = _28bytes_to_bits(_5913);
    _5913 = NOVALUE;
    _0 = _int_bits_10495;
    _int_bits_10495 = _28trim_bits(_5914);
    DeRef(_0);
    _5914 = NOVALUE;

    /** scinot.e:389			frac_bits = {}*/
    RefDS(_5);
    DeRef(_frac_bits_10496);
    _frac_bits_10496 = _5;
    goto L13; // [409] 529
L12: 

    /** scinot.e:391			if -exp > length(s) then*/
    if ((uintptr_t)_exp_10494 == (uintptr_t)HIGH_BITS){
        _5916 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _5916 = - _exp_10494;
    }
    if (IS_SEQUENCE(_s_10490)){
            _5917 = SEQ_PTR(_s_10490)->length;
    }
    else {
        _5917 = 1;
    }
    if (binary_op_a(LESSEQ, _5916, _5917)){
        DeRef(_5916);
        _5916 = NOVALUE;
        _5917 = NOVALUE;
        goto L14; // [420] 463
    }
    DeRef(_5916);
    _5916 = NOVALUE;
    _5917 = NOVALUE;

    /** scinot.e:393				int_bits = {}*/
    RefDS(_5);
    DeRef(_int_bits_10495);
    _int_bits_10495 = _5;

    /** scinot.e:394				frac_bits = decimals_to_bits( repeat( 0, -exp-length(s) ) & s, significand ) */
    if ((uintptr_t)_exp_10494 == (uintptr_t)HIGH_BITS){
        _5919 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _5919 = - _exp_10494;
    }
    if (IS_SEQUENCE(_s_10490)){
            _5920 = SEQ_PTR(_s_10490)->length;
    }
    else {
        _5920 = 1;
    }
    if (IS_ATOM_INT(_5919)) {
        _5921 = _5919 - _5920;
    }
    else {
        _5921 = NewDouble(DBL_PTR(_5919)->dbl - (eudouble)_5920);
    }
    DeRef(_5919);
    _5919 = NOVALUE;
    _5920 = NOVALUE;
    _5922 = Repeat(0, _5921);
    DeRef(_5921);
    _5921 = NOVALUE;
    Concat((object_ptr)&_5923, _5922, _s_10490);
    DeRefDS(_5922);
    _5922 = NOVALUE;
    DeRef(_5922);
    _5922 = NOVALUE;
    _0 = _frac_bits_10496;
    _frac_bits_10496 = _28decimals_to_bits(_5923, _significand_10500);
    DeRef(_0);
    _5923 = NOVALUE;
    goto L15; // [460] 528
L14: 

    /** scinot.e:398				int_bits = trim_bits( bytes_to_bits( convert_radix( reverse( s[1..$+exp] ), 10, #100 ) ) )*/
    if (IS_SEQUENCE(_s_10490)){
            _5925 = SEQ_PTR(_s_10490)->length;
    }
    else {
        _5925 = 1;
    }
    _5926 = _5925 + _exp_10494;
    _5925 = NOVALUE;
    rhs_slice_target = (object_ptr)&_5927;
    RHS_Slice(_s_10490, 1, _5926);
    _5928 = _28reverse(_5927);
    _5927 = NOVALUE;
    _5929 = _28convert_radix(_5928, 10, 256);
    _5928 = NOVALUE;
    _5930 = _28bytes_to_bits(_5929);
    _5929 = NOVALUE;
    _0 = _int_bits_10495;
    _int_bits_10495 = _28trim_bits(_5930);
    DeRef(_0);
    _5930 = NOVALUE;

    /** scinot.e:399				frac_bits =  decimals_to_bits( s[$+exp+1..$], significand )*/
    if (IS_SEQUENCE(_s_10490)){
            _5932 = SEQ_PTR(_s_10490)->length;
    }
    else {
        _5932 = 1;
    }
    _5933 = _5932 + _exp_10494;
    if ((object)((uintptr_t)_5933 + (uintptr_t)HIGH_BITS) >= 0){
        _5933 = NewDouble((eudouble)_5933);
    }
    _5932 = NOVALUE;
    if (IS_ATOM_INT(_5933)) {
        _5934 = _5933 + 1;
        if (_5934 > MAXINT){
            _5934 = NewDouble((eudouble)_5934);
        }
    }
    else
    _5934 = binary_op(PLUS, 1, _5933);
    DeRef(_5933);
    _5933 = NOVALUE;
    if (IS_SEQUENCE(_s_10490)){
            _5935 = SEQ_PTR(_s_10490)->length;
    }
    else {
        _5935 = 1;
    }
    rhs_slice_target = (object_ptr)&_5936;
    RHS_Slice(_s_10490, _5934, _5935);
    _0 = _frac_bits_10496;
    _frac_bits_10496 = _28decimals_to_bits(_5936, _significand_10500);
    DeRef(_0);
    _5936 = NOVALUE;
L15: 
L13: 

    /** scinot.e:403		if length(int_bits) > significand then*/
    if (IS_SEQUENCE(_int_bits_10495)){
            _5938 = SEQ_PTR(_int_bits_10495)->length;
    }
    else {
        _5938 = 1;
    }
    if (_5938 <= _significand_10500)
    goto L16; // [538] 668

    /** scinot.e:406			if fp = DOUBLE then*/
    if (_fp_10491 != 2)
    goto L17; // [544] 572

    /** scinot.e:408				mbits = int_bits[$-significand..$-1]*/
    if (IS_SEQUENCE(_int_bits_10495)){
            _5941 = SEQ_PTR(_int_bits_10495)->length;
    }
    else {
        _5941 = 1;
    }
    _5942 = _5941 - _significand_10500;
    if ((object)((uintptr_t)_5942 +(uintptr_t) HIGH_BITS) >= 0){
        _5942 = NewDouble((eudouble)_5942);
    }
    _5941 = NOVALUE;
    if (IS_SEQUENCE(_int_bits_10495)){
            _5943 = SEQ_PTR(_int_bits_10495)->length;
    }
    else {
        _5943 = 1;
    }
    _5944 = _5943 - 1;
    _5943 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mbits_10497;
    RHS_Slice(_int_bits_10495, _5942, _5944);
    goto L18; // [569] 594
L17: 

    /** scinot.e:411				mbits = int_bits[$-significand+1..$]*/
    if (IS_SEQUENCE(_int_bits_10495)){
            _5946 = SEQ_PTR(_int_bits_10495)->length;
    }
    else {
        _5946 = 1;
    }
    _5947 = _5946 - _significand_10500;
    if ((object)((uintptr_t)_5947 +(uintptr_t) HIGH_BITS) >= 0){
        _5947 = NewDouble((eudouble)_5947);
    }
    _5946 = NOVALUE;
    if (IS_ATOM_INT(_5947)) {
        _5948 = _5947 + 1;
        if (_5948 > MAXINT){
            _5948 = NewDouble((eudouble)_5948);
        }
    }
    else
    _5948 = binary_op(PLUS, 1, _5947);
    DeRef(_5947);
    _5947 = NOVALUE;
    if (IS_SEQUENCE(_int_bits_10495)){
            _5949 = SEQ_PTR(_int_bits_10495)->length;
    }
    else {
        _5949 = 1;
    }
    rhs_slice_target = (object_ptr)&_mbits_10497;
    RHS_Slice(_int_bits_10495, _5948, _5949);
L18: 

    /** scinot.e:414			if length(int_bits) > significand + 1 and int_bits[$-(significand+1)] then*/
    if (IS_SEQUENCE(_int_bits_10495)){
            _5951 = SEQ_PTR(_int_bits_10495)->length;
    }
    else {
        _5951 = 1;
    }
    _5952 = _significand_10500 + 1;
    if (_5952 > MAXINT){
        _5952 = NewDouble((eudouble)_5952);
    }
    if (IS_ATOM_INT(_5952)) {
        _5953 = (_5951 > _5952);
    }
    else {
        _5953 = ((eudouble)_5951 > DBL_PTR(_5952)->dbl);
    }
    _5951 = NOVALUE;
    DeRef(_5952);
    _5952 = NOVALUE;
    if (_5953 == 0) {
        goto L19; // [607] 656
    }
    if (IS_SEQUENCE(_int_bits_10495)){
            _5955 = SEQ_PTR(_int_bits_10495)->length;
    }
    else {
        _5955 = 1;
    }
    _5956 = _significand_10500 + 1;
    if (_5956 > MAXINT){
        _5956 = NewDouble((eudouble)_5956);
    }
    if (IS_ATOM_INT(_5956)) {
        _5957 = _5955 - _5956;
    }
    else {
        _5957 = NewDouble((eudouble)_5955 - DBL_PTR(_5956)->dbl);
    }
    _5955 = NOVALUE;
    DeRef(_5956);
    _5956 = NOVALUE;
    _2 = (object)SEQ_PTR(_int_bits_10495);
    if (!IS_ATOM_INT(_5957)){
        _5958 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_5957)->dbl));
    }
    else{
        _5958 = (object)*(((s1_ptr)_2)->base + _5957);
    }
    if (_5958 == 0) {
        _5958 = NOVALUE;
        goto L19; // [627] 656
    }
    else {
        if (!IS_ATOM_INT(_5958) && DBL_PTR(_5958)->dbl == 0.0){
            _5958 = NOVALUE;
            goto L19; // [627] 656
        }
        _5958 = NOVALUE;
    }
    _5958 = NOVALUE;

    /** scinot.e:416				mbits[1] += 1*/
    _2 = (object)SEQ_PTR(_mbits_10497);
    _5959 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_5959)) {
        _5960 = _5959 + 1;
        if (_5960 > MAXINT){
            _5960 = NewDouble((eudouble)_5960);
        }
    }
    else
    _5960 = binary_op(PLUS, 1, _5959);
    _5959 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_10497);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _mbits_10497 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _5960;
    if( _1 != _5960 ){
        DeRef(_1);
    }
    _5960 = NOVALUE;

    /** scinot.e:417				mbits = carry( mbits, 2 )*/
    RefDS(_mbits_10497);
    _0 = _mbits_10497;
    _mbits_10497 = _28carry(_mbits_10497, 2);
    DeRefDS(_0);
L19: 

    /** scinot.e:419			exp = length(int_bits)-1*/
    if (IS_SEQUENCE(_int_bits_10495)){
            _5962 = SEQ_PTR(_int_bits_10495)->length;
    }
    else {
        _5962 = 1;
    }
    _exp_10494 = _5962 - 1;
    _5962 = NOVALUE;
    goto L1A; // [665] 940
L16: 

    /** scinot.e:422			if length(int_bits) then*/
    if (IS_SEQUENCE(_int_bits_10495)){
            _5964 = SEQ_PTR(_int_bits_10495)->length;
    }
    else {
        _5964 = 1;
    }
    if (_5964 == 0)
    {
        _5964 = NOVALUE;
        goto L1B; // [673] 688
    }
    else{
        _5964 = NOVALUE;
    }

    /** scinot.e:424				exp = length(int_bits)-1*/
    if (IS_SEQUENCE(_int_bits_10495)){
            _5965 = SEQ_PTR(_int_bits_10495)->length;
    }
    else {
        _5965 = 1;
    }
    _exp_10494 = _5965 - 1;
    _5965 = NOVALUE;
    goto L1C; // [685] 748
L1B: 

    /** scinot.e:428				exp = - find( 1, reverse( frac_bits ) )*/
    RefDS(_frac_bits_10496);
    _5967 = _28reverse(_frac_bits_10496);
    _5968 = find_from(1, _5967, 1);
    DeRef(_5967);
    _5967 = NOVALUE;
    _exp_10494 = - _5968;

    /** scinot.e:429				if exp < min_exp then*/
    if (_exp_10494 >= _min_exp_10502)
    goto L1D; // [710] 720

    /** scinot.e:432					exp = min_exp*/
    _exp_10494 = _min_exp_10502;
L1D: 

    /** scinot.e:435				if exp then*/
    if (_exp_10494 == 0)
    {
        goto L1E; // [722] 747
    }
    else{
    }

    /** scinot.e:437					frac_bits = remove( frac_bits, length(frac_bits) + exp + 2, length( frac_bits ) )*/
    if (IS_SEQUENCE(_frac_bits_10496)){
            _5971 = SEQ_PTR(_frac_bits_10496)->length;
    }
    else {
        _5971 = 1;
    }
    _5972 = _5971 + _exp_10494;
    if ((object)((uintptr_t)_5972 + (uintptr_t)HIGH_BITS) >= 0){
        _5972 = NewDouble((eudouble)_5972);
    }
    _5971 = NOVALUE;
    if (IS_ATOM_INT(_5972)) {
        _5973 = _5972 + 2;
        if ((object)((uintptr_t)_5973 + (uintptr_t)HIGH_BITS) >= 0){
            _5973 = NewDouble((eudouble)_5973);
        }
    }
    else {
        _5973 = NewDouble(DBL_PTR(_5972)->dbl + (eudouble)2);
    }
    DeRef(_5972);
    _5972 = NOVALUE;
    if (IS_SEQUENCE(_frac_bits_10496)){
            _5974 = SEQ_PTR(_frac_bits_10496)->length;
    }
    else {
        _5974 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_frac_bits_10496);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_5973)) ? _5973 : (object)(DBL_PTR(_5973)->dbl);
        int stop = (IS_ATOM_INT(_5974)) ? _5974 : (object)(DBL_PTR(_5974)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_frac_bits_10496), start, &_frac_bits_10496 );
            }
            else Tail(SEQ_PTR(_frac_bits_10496), stop+1, &_frac_bits_10496);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_frac_bits_10496), start, &_frac_bits_10496);
        }
        else {
            assign_slice_seq = &assign_space;
            _frac_bits_10496 = Remove_elements(start, stop, (SEQ_PTR(_frac_bits_10496)->ref == 1));
        }
    }
    DeRef(_5973);
    _5973 = NOVALUE;
    _5974 = NOVALUE;
L1E: 
L1C: 

    /** scinot.e:444			mbits = frac_bits & int_bits*/
    Concat((object_ptr)&_mbits_10497, _frac_bits_10496, _int_bits_10495);

    /** scinot.e:445			mbits = repeat( 0, significand + 1 ) & mbits*/
    _5977 = _significand_10500 + 1;
    _5978 = Repeat(0, _5977);
    _5977 = NOVALUE;
    Concat((object_ptr)&_mbits_10497, _5978, _mbits_10497);
    DeRefDS(_5978);
    _5978 = NOVALUE;
    DeRef(_5978);
    _5978 = NOVALUE;

    /** scinot.e:447			if exp > min_exp then*/
    if (_exp_10494 <= _min_exp_10502)
    goto L1F; // [774] 877

    /** scinot.e:449				if mbits[$-(significand+1)] then*/
    if (IS_SEQUENCE(_mbits_10497)){
            _5981 = SEQ_PTR(_mbits_10497)->length;
    }
    else {
        _5981 = 1;
    }
    _5982 = _significand_10500 + 1;
    if (_5982 > MAXINT){
        _5982 = NewDouble((eudouble)_5982);
    }
    if (IS_ATOM_INT(_5982)) {
        _5983 = _5981 - _5982;
    }
    else {
        _5983 = NewDouble((eudouble)_5981 - DBL_PTR(_5982)->dbl);
    }
    _5981 = NOVALUE;
    DeRef(_5982);
    _5982 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_10497);
    if (!IS_ATOM_INT(_5983)){
        _5984 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_5983)->dbl));
    }
    else{
        _5984 = (object)*(((s1_ptr)_2)->base + _5983);
    }
    if (_5984 == 0) {
        _5984 = NOVALUE;
        goto L20; // [795] 829
    }
    else {
        if (!IS_ATOM_INT(_5984) && DBL_PTR(_5984)->dbl == 0.0){
            _5984 = NOVALUE;
            goto L20; // [795] 829
        }
        _5984 = NOVALUE;
    }
    _5984 = NOVALUE;

    /** scinot.e:451					mbits[$-significand] += 1*/
    if (IS_SEQUENCE(_mbits_10497)){
            _5985 = SEQ_PTR(_mbits_10497)->length;
    }
    else {
        _5985 = 1;
    }
    _5986 = _5985 - _significand_10500;
    _5985 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_10497);
    _5987 = (object)*(((s1_ptr)_2)->base + _5986);
    if (IS_ATOM_INT(_5987)) {
        _5988 = _5987 + 1;
        if (_5988 > MAXINT){
            _5988 = NewDouble((eudouble)_5988);
        }
    }
    else
    _5988 = binary_op(PLUS, 1, _5987);
    _5987 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_10497);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _mbits_10497 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _5986);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _5988;
    if( _1 != _5988 ){
        DeRef(_1);
    }
    _5988 = NOVALUE;

    /** scinot.e:452					mbits = carry( mbits, 2 )*/
    RefDS(_mbits_10497);
    _0 = _mbits_10497;
    _mbits_10497 = _28carry(_mbits_10497, 2);
    DeRefDS(_0);
L20: 

    /** scinot.e:454				if fp = DOUBLE then*/
    if (_fp_10491 != 2)
    goto L21; // [831] 859

    /** scinot.e:456					mbits = mbits[$-significand..$-1]*/
    if (IS_SEQUENCE(_mbits_10497)){
            _5991 = SEQ_PTR(_mbits_10497)->length;
    }
    else {
        _5991 = 1;
    }
    _5992 = _5991 - _significand_10500;
    if ((object)((uintptr_t)_5992 +(uintptr_t) HIGH_BITS) >= 0){
        _5992 = NewDouble((eudouble)_5992);
    }
    _5991 = NOVALUE;
    if (IS_SEQUENCE(_mbits_10497)){
            _5993 = SEQ_PTR(_mbits_10497)->length;
    }
    else {
        _5993 = 1;
    }
    _5994 = _5993 - 1;
    _5993 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mbits_10497;
    RHS_Slice(_mbits_10497, _5992, _5994);
    goto L22; // [856] 939
L21: 

    /** scinot.e:459					mbits = remove( mbits, 1, length(mbits) - significand )*/
    if (IS_SEQUENCE(_mbits_10497)){
            _5996 = SEQ_PTR(_mbits_10497)->length;
    }
    else {
        _5996 = 1;
    }
    _5997 = _5996 - _significand_10500;
    if ((object)((uintptr_t)_5997 +(uintptr_t) HIGH_BITS) >= 0){
        _5997 = NewDouble((eudouble)_5997);
    }
    _5996 = NOVALUE;
    {
        s1_ptr assign_space = SEQ_PTR(_mbits_10497);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1)) ? 1 : (object)(DBL_PTR(1)->dbl);
        int stop = (IS_ATOM_INT(_5997)) ? _5997 : (object)(DBL_PTR(_5997)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_mbits_10497), start, &_mbits_10497 );
            }
            else Tail(SEQ_PTR(_mbits_10497), stop+1, &_mbits_10497);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_mbits_10497), start, &_mbits_10497);
        }
        else {
            assign_slice_seq = &assign_space;
            _mbits_10497 = Remove_elements(start, stop, (SEQ_PTR(_mbits_10497)->ref == 1));
        }
    }
    DeRef(_5997);
    _5997 = NOVALUE;
    goto L22; // [874] 939
L1F: 

    /** scinot.e:463				if mbits[$-significand] then*/
    if (IS_SEQUENCE(_mbits_10497)){
            _5999 = SEQ_PTR(_mbits_10497)->length;
    }
    else {
        _5999 = 1;
    }
    _6000 = _5999 - _significand_10500;
    _5999 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_10497);
    _6001 = (object)*(((s1_ptr)_2)->base + _6000);
    if (_6001 == 0) {
        _6001 = NOVALUE;
        goto L23; // [890] 924
    }
    else {
        if (!IS_ATOM_INT(_6001) && DBL_PTR(_6001)->dbl == 0.0){
            _6001 = NOVALUE;
            goto L23; // [890] 924
        }
        _6001 = NOVALUE;
    }
    _6001 = NOVALUE;

    /** scinot.e:465					mbits[$-significand] += 1*/
    if (IS_SEQUENCE(_mbits_10497)){
            _6002 = SEQ_PTR(_mbits_10497)->length;
    }
    else {
        _6002 = 1;
    }
    _6003 = _6002 - _significand_10500;
    _6002 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_10497);
    _6004 = (object)*(((s1_ptr)_2)->base + _6003);
    if (IS_ATOM_INT(_6004)) {
        _6005 = _6004 + 1;
        if (_6005 > MAXINT){
            _6005 = NewDouble((eudouble)_6005);
        }
    }
    else
    _6005 = binary_op(PLUS, 1, _6004);
    _6004 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_10497);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _mbits_10497 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _6003);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _6005;
    if( _1 != _6005 ){
        DeRef(_1);
    }
    _6005 = NOVALUE;

    /** scinot.e:466					mbits = carry( mbits, 2 )*/
    RefDS(_mbits_10497);
    _0 = _mbits_10497;
    _mbits_10497 = _28carry(_mbits_10497, 2);
    DeRefDS(_0);
L23: 

    /** scinot.e:468				mbits = remove( mbits, 1, length(mbits) - significand )*/
    if (IS_SEQUENCE(_mbits_10497)){
            _6007 = SEQ_PTR(_mbits_10497)->length;
    }
    else {
        _6007 = 1;
    }
    _6008 = _6007 - _significand_10500;
    if ((object)((uintptr_t)_6008 +(uintptr_t) HIGH_BITS) >= 0){
        _6008 = NewDouble((eudouble)_6008);
    }
    _6007 = NOVALUE;
    {
        s1_ptr assign_space = SEQ_PTR(_mbits_10497);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1)) ? 1 : (object)(DBL_PTR(1)->dbl);
        int stop = (IS_ATOM_INT(_6008)) ? _6008 : (object)(DBL_PTR(_6008)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_mbits_10497), start, &_mbits_10497 );
            }
            else Tail(SEQ_PTR(_mbits_10497), stop+1, &_mbits_10497);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_mbits_10497), start, &_mbits_10497);
        }
        else {
            assign_slice_seq = &assign_space;
            _mbits_10497 = Remove_elements(start, stop, (SEQ_PTR(_mbits_10497)->ref == 1));
        }
    }
    DeRef(_6008);
    _6008 = NOVALUE;
L22: 
L1A: 

    /** scinot.e:474		ebits = int_to_bits( exp + exp_bias, exponent )*/
    _6010 = _exp_10494 + _exp_bias_10503;
    if ((object)((uintptr_t)_6010 + (uintptr_t)HIGH_BITS) >= 0){
        _6010 = NewDouble((eudouble)_6010);
    }
    _0 = _ebits_10498;
    _ebits_10498 = _15int_to_bits(_6010, _exponent_10501);
    DeRef(_0);
    _6010 = NOVALUE;

    /** scinot.e:477		return bits_to_bytes( mbits & ebits & sbits )*/
    {
        object concat_list[3];

        concat_list[0] = _sbits_10499;
        concat_list[1] = _ebits_10498;
        concat_list[2] = _mbits_10497;
        Concat_N((object_ptr)&_6012, concat_list, 3);
    }
    _6013 = _28bits_to_bytes(_6012);
    _6012 = NOVALUE;
    DeRefDS(_s_10490);
    DeRef(_int_bits_10495);
    DeRef(_frac_bits_10496);
    DeRefDS(_mbits_10497);
    DeRefDS(_ebits_10498);
    DeRefDSi(_sbits_10499);
    DeRef(_5983);
    _5983 = NOVALUE;
    DeRef(_5890);
    _5890 = NOVALUE;
    DeRef(_6000);
    _6000 = NOVALUE;
    DeRef(_5994);
    _5994 = NOVALUE;
    DeRef(_5986);
    _5986 = NOVALUE;
    DeRef(_5906);
    _5906 = NOVALUE;
    DeRef(_5992);
    _5992 = NOVALUE;
    DeRef(_5957);
    _5957 = NOVALUE;
    DeRef(_5877);
    _5877 = NOVALUE;
    DeRef(_5944);
    _5944 = NOVALUE;
    DeRef(_5948);
    _5948 = NOVALUE;
    DeRef(_5953);
    _5953 = NOVALUE;
    DeRef(_5942);
    _5942 = NOVALUE;
    DeRef(_5885);
    _5885 = NOVALUE;
    DeRef(_5874);
    _5874 = NOVALUE;
    DeRef(_5926);
    _5926 = NOVALUE;
    DeRef(_5908);
    _5908 = NOVALUE;
    DeRef(_5899);
    _5899 = NOVALUE;
    DeRef(_5934);
    _5934 = NOVALUE;
    DeRef(_5882);
    _5882 = NOVALUE;
    DeRef(_6003);
    _6003 = NOVALUE;
    return _6013;
    ;
}


object _28scientific_to_atom(object _s_10697, object _fp_10698)
{
    object _float_10701 = NOVALUE;
    object _6019 = NOVALUE;
    object _6017 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:495		if fp = NATIVE then*/
    if (_fp_10698 != 1)
    goto L1; // [5] 17

    /** scinot.e:496			fp = NATIVE_FORMAT*/
    _fp_10698 = _28NATIVE_FORMAT_10245;
L1: 

    /** scinot.e:498		sequence float = scientific_to_float( s, fp )*/
    RefDS(_s_10697);
    _0 = _float_10701;
    _float_10701 = _28scientific_to_float(_s_10697, _fp_10698);
    DeRef(_0);

    /** scinot.e:499		if fp = DOUBLE then*/
    if (_fp_10698 != 2)
    goto L2; // [28] 45

    /** scinot.e:500			return float64_to_atom( float )*/
    RefDS(_float_10701);
    _6017 = _15float64_to_atom(_float_10701);
    DeRefDS(_s_10697);
    DeRefDS(_float_10701);
    return _6017;
    goto L3; // [42] 63
L2: 

    /** scinot.e:501		elsif fp = EXTENDED then*/
    if (_fp_10698 != 3)
    goto L4; // [47] 62

    /** scinot.e:502			return float80_to_atom( float )*/
    RefDS(_float_10701);
    _6019 = _15float80_to_atom(_float_10701);
    DeRefDS(_s_10697);
    DeRefDS(_float_10701);
    DeRef(_6017);
    _6017 = NOVALUE;
    return _6019;
L4: 
L3: 
    ;
}



// 0x9EBE7739
