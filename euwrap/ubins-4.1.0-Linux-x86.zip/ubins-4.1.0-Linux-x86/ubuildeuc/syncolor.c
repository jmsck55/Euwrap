// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _70set_colors(object _pColorList_66534)
{
    object _lColorName_66535 = NOVALUE;
    object _32781 = NOVALUE;
    object _32778 = NOVALUE;
    object _32775 = NOVALUE;
    object _32772 = NOVALUE;
    object _32769 = NOVALUE;
    object _32766 = NOVALUE;
    object _32763 = NOVALUE;
    object _32758 = NOVALUE;
    object _32757 = NOVALUE;
    object _32756 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:48		for i = 1 to length(pColorList) do*/
    _32756 = 6;
    {
        object _i_66537;
        _i_66537 = 1;
L1: 
        if (_i_66537 > 6){
            goto L2; // [8] 168
        }

        /** syncolor.e:49			lColorName = text:upper(pColorList[i][1])*/
        _2 = (object)SEQ_PTR(_pColorList_66534);
        _32757 = (object)*(((s1_ptr)_2)->base + _i_66537);
        _2 = (object)SEQ_PTR(_32757);
        _32758 = (object)*(((s1_ptr)_2)->base + 1);
        _32757 = NOVALUE;
        Ref(_32758);
        _0 = _lColorName_66535;
        _lColorName_66535 = _14upper(_32758);
        DeRef(_0);
        _32758 = NOVALUE;

        /** syncolor.e:50			switch lColorName do*/
        _1 = find(_lColorName_66535, _32760);
        switch ( _1 ){ 

            /** syncolor.e:51				case "NORMAL" then*/
            case 1:

            /** syncolor.e:52					NORMAL_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_66534);
            _32763 = (object)*(((s1_ptr)_2)->base + _i_66537);
            _2 = (object)SEQ_PTR(_32763);
            _70NORMAL_COLOR_66523 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_70NORMAL_COLOR_66523)){
                _70NORMAL_COLOR_66523 = (object)DBL_PTR(_70NORMAL_COLOR_66523)->dbl;
            }
            _32763 = NOVALUE;
            goto L3; // [54] 161

            /** syncolor.e:53				case "COMMENT" then*/
            case 2:

            /** syncolor.e:54					COMMENT_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_66534);
            _32766 = (object)*(((s1_ptr)_2)->base + _i_66537);
            _2 = (object)SEQ_PTR(_32766);
            _70COMMENT_COLOR_66524 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_70COMMENT_COLOR_66524)){
                _70COMMENT_COLOR_66524 = (object)DBL_PTR(_70COMMENT_COLOR_66524)->dbl;
            }
            _32766 = NOVALUE;
            goto L3; // [72] 161

            /** syncolor.e:55				case "KEYWORD" then*/
            case 3:

            /** syncolor.e:56					KEYWORD_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_66534);
            _32769 = (object)*(((s1_ptr)_2)->base + _i_66537);
            _2 = (object)SEQ_PTR(_32769);
            _70KEYWORD_COLOR_66525 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_70KEYWORD_COLOR_66525)){
                _70KEYWORD_COLOR_66525 = (object)DBL_PTR(_70KEYWORD_COLOR_66525)->dbl;
            }
            _32769 = NOVALUE;
            goto L3; // [90] 161

            /** syncolor.e:57				case "BUILTIN" then*/
            case 4:

            /** syncolor.e:58					BUILTIN_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_66534);
            _32772 = (object)*(((s1_ptr)_2)->base + _i_66537);
            _2 = (object)SEQ_PTR(_32772);
            _70BUILTIN_COLOR_66526 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_70BUILTIN_COLOR_66526)){
                _70BUILTIN_COLOR_66526 = (object)DBL_PTR(_70BUILTIN_COLOR_66526)->dbl;
            }
            _32772 = NOVALUE;
            goto L3; // [108] 161

            /** syncolor.e:59				case "STRING" then*/
            case 5:

            /** syncolor.e:60					STRING_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_66534);
            _32775 = (object)*(((s1_ptr)_2)->base + _i_66537);
            _2 = (object)SEQ_PTR(_32775);
            _70STRING_COLOR_66527 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_70STRING_COLOR_66527)){
                _70STRING_COLOR_66527 = (object)DBL_PTR(_70STRING_COLOR_66527)->dbl;
            }
            _32775 = NOVALUE;
            goto L3; // [126] 161

            /** syncolor.e:61				case "BRACKET" then*/
            case 6:

            /** syncolor.e:62					BRACKET_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_66534);
            _32778 = (object)*(((s1_ptr)_2)->base + _i_66537);
            DeRef(_70BRACKET_COLOR_66528);
            _2 = (object)SEQ_PTR(_32778);
            _70BRACKET_COLOR_66528 = (object)*(((s1_ptr)_2)->base + 2);
            Ref(_70BRACKET_COLOR_66528);
            _32778 = NOVALUE;
            goto L3; // [144] 161

            /** syncolor.e:63				case else*/
            case 0:

            /** syncolor.e:64					printf(2, "syncolor.e: Unknown color name '%s', ignored.\n", {lColorName})*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            RefDS(_lColorName_66535);
            ((intptr_t*)_2)[1] = _lColorName_66535;
            _32781 = MAKE_SEQ(_1);
            EPrintf(2, _32780, _32781);
            DeRefDS(_32781);
            _32781 = NOVALUE;
        ;}L3: 

        /** syncolor.e:66		end for*/
        _i_66537 = _i_66537 + 1;
        goto L1; // [163] 15
L2: 
        ;
    }

    /** syncolor.e:67	end procedure*/
    DeRefDS(_pColorList_66534);
    DeRef(_lColorName_66535);
    return;
    ;
}


void _70init_class()
{
    object _0, _1, _2;
    

    /** syncolor.e:71		NORMAL_COLOR  = #330033*/
    _70NORMAL_COLOR_66523 = 3342387;

    /** syncolor.e:72		COMMENT_COLOR = #FF0055*/
    _70COMMENT_COLOR_66524 = 16711765;

    /** syncolor.e:73		KEYWORD_COLOR = #0000FF*/
    _70KEYWORD_COLOR_66525 = 255;

    /** syncolor.e:74		BUILTIN_COLOR = #FF00FF*/
    _70BUILTIN_COLOR_66526 = 16711935;

    /** syncolor.e:75		STRING_COLOR  = #00A033*/
    _70STRING_COLOR_66527 = 41011;

    /** syncolor.e:76		BRACKET_COLOR = {NORMAL_COLOR, #993333, #0000FF, #5500FF, #00FF00}*/
    _0 = _70BRACKET_COLOR_66528;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 3342387;
    ((intptr_t*)_2)[2] = 10040115;
    ((intptr_t*)_2)[3] = 255;
    ((intptr_t*)_2)[4] = 5570815;
    ((intptr_t*)_2)[5] = 65280;
    _70BRACKET_COLOR_66528 = MAKE_SEQ(_1);
    DeRef(_0);

    /** syncolor.e:78	end procedure*/
    return;
    ;
}


object _70default_state(object _token_66601)
{
    object _32799 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:103		if not token then*/
    if (IS_ATOM_INT(_token_66601)) {
        if (_token_66601 != 0){
            goto L1; // [3] 12
        }
    }
    else {
        if (DBL_PTR(_token_66601)->dbl != 0.0){
            goto L1; // [3] 12
        }
    }

    /** syncolor.e:104			token = tokenize:new()*/
    _0 = _token_66601;
    _token_66601 = _71new();
    DeRef(_0);
L1: 

    /** syncolor.e:106		return {*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_token_66601);
    ((intptr_t*)_2)[1] = _token_66601;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 0;
    _32799 = MAKE_SEQ(_1);
    DeRef(_token_66601);
    return _32799;
    ;
}


object _70new()
{
    object _state_66611 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:124		atom state = eumem:malloc()*/
    _0 = _state_66611;
    _state_66611 = _30malloc(1, 1);
    DeRef(_0);

    /** syncolor.e:126		reset(state)*/
    Ref(_state_66611);
    _70reset(_state_66611);

    /** syncolor.e:128		return state*/
    return _state_66611;
    ;
}


void _70tokenize_reset(object _token_66616)
{
    object _reset_1__tmp_at7_66619 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:138		if token then*/
    if (_token_66616 == 0) {
        goto L1; // [3] 27
    }
    else {
        if (!IS_ATOM_INT(_token_66616) && DBL_PTR(_token_66616)->dbl == 0.0){
            goto L1; // [3] 27
        }
    }

    /** syncolor.e:139			tokenize:reset(token)*/

    /** tokenize.e:215		eumem:ram_space[state] = default_state()*/
    _0 = _reset_1__tmp_at7_66619;
    _reset_1__tmp_at7_66619 = _71default_state();
    DeRef(_0);
    Ref(_reset_1__tmp_at7_66619);
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11238 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_token_66616))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_token_66616)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _token_66616);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _reset_1__tmp_at7_66619;
    DeRef(_1);

    /** tokenize.e:216	end procedure*/
    goto L2; // [21] 24
L2: 
    DeRef(_reset_1__tmp_at7_66619);
    _reset_1__tmp_at7_66619 = NOVALUE;
L1: 

    /** syncolor.e:141	end procedure*/
    DeRef(_token_66616);
    return;
    ;
}


void _70reset(object _state_66622)
{
    object _token_66623 = NOVALUE;
    object _32806 = NOVALUE;
    object _32805 = NOVALUE;
    object _32803 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:144		atom token = eumem:ram_space[state][S_TOKENIZER]*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!IS_ATOM_INT(_state_66622)){
        _32803 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_66622)->dbl));
    }
    else{
        _32803 = (object)*(((s1_ptr)_2)->base + _state_66622);
    }
    DeRef(_token_66623);
    _2 = (object)SEQ_PTR(_32803);
    _token_66623 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_token_66623);
    _32803 = NOVALUE;

    /** syncolor.e:145		tokenize_reset(token)*/
    Ref(_token_66623);
    _70tokenize_reset(_token_66623);

    /** syncolor.e:146		eumem:ram_space[state] = default_state(token)*/
    Ref(_token_66623);
    _32805 = _70default_state(_token_66623);
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11238 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_66622))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_66622)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _state_66622);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32805;
    if( _1 != _32805 ){
        DeRef(_1);
    }
    _32805 = NOVALUE;

    /** syncolor.e:147		eumem:ram_space[state] = default_state()*/
    _32806 = _70default_state(0);
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11238 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_66622))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_66622)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _state_66622);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32806;
    if( _1 != _32806 ){
        DeRef(_1);
    }
    _32806 = NOVALUE;

    /** syncolor.e:148	end procedure*/
    DeRef(_state_66622);
    DeRef(_token_66623);
    return;
    ;
}



// 0x07B217AE
