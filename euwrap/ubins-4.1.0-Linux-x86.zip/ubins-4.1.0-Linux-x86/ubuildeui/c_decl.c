// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _57get_eucompiledir()
{
    object _x_42608 = NOVALUE;
    object _22387 = NOVALUE;
    object _22385 = NOVALUE;
    object _22382 = NOVALUE;
    object _22380 = NOVALUE;
    object _22378 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:133		object x = getenv("EUCOMPILEDIR")*/
    DeRef(_x_42608);
    _x_42608 = EGetEnv(_22376);

    /** c_decl.e:134		if is_eudir_from_cmdline() then*/
    _22378 = _13is_eudir_from_cmdline();
    if (_22378 == 0) {
        DeRef(_22378);
        _22378 = NOVALUE;
        goto L1; // [11] 20
    }
    else {
        if (!IS_ATOM_INT(_22378) && DBL_PTR(_22378)->dbl == 0.0){
            DeRef(_22378);
            _22378 = NOVALUE;
            goto L1; // [11] 20
        }
        DeRef(_22378);
        _22378 = NOVALUE;
    }
    DeRef(_22378);
    _22378 = NOVALUE;

    /** c_decl.e:135			x = get_eudir()*/
    _0 = _x_42608;
    _x_42608 = _13get_eudir();
    DeRefi(_0);
L1: 

    /** c_decl.e:138		ifdef UNIX then*/

    /** c_decl.e:139			if equal(x, -1) then*/
    if (_x_42608 == -1)
    _22380 = 1;
    else if (IS_ATOM_INT(_x_42608) && IS_ATOM_INT(-1))
    _22380 = 0;
    else
    _22380 = (compare(_x_42608, -1) == 0);
    if (_22380 == 0)
    {
        _22380 = NOVALUE;
        goto L2; // [28] 67
    }
    else{
        _22380 = NOVALUE;
    }

    /** c_decl.e:140				x = "/usr/local/share/euphoria"*/
    RefDS(_22381);
    DeRef(_x_42608);
    _x_42608 = _22381;

    /** c_decl.e:141				if not file_exists( x ) then*/
    RefDS(_x_42608);
    _22382 = _14file_exists(_x_42608);
    if (IS_ATOM_INT(_22382)) {
        if (_22382 != 0){
            DeRef(_22382);
            _22382 = NOVALUE;
            goto L3; // [42] 66
        }
    }
    else {
        if (DBL_PTR(_22382)->dbl != 0.0){
            DeRef(_22382);
            _22382 = NOVALUE;
            goto L3; // [42] 66
        }
    }
    DeRef(_22382);
    _22382 = NOVALUE;

    /** c_decl.e:144					x = "/usr/share/euphoria"*/
    RefDS(_22384);
    DeRefDSi(_x_42608);
    _x_42608 = _22384;

    /** c_decl.e:145					if not file_exists( x ) then*/
    RefDS(_x_42608);
    _22385 = _14file_exists(_x_42608);
    if (IS_ATOM_INT(_22385)) {
        if (_22385 != 0){
            DeRef(_22385);
            _22385 = NOVALUE;
            goto L4; // [56] 65
        }
    }
    else {
        if (DBL_PTR(_22385)->dbl != 0.0){
            DeRef(_22385);
            _22385 = NOVALUE;
            goto L4; // [56] 65
        }
    }
    DeRef(_22385);
    _22385 = NOVALUE;

    /** c_decl.e:146						x = -1*/
    DeRefDSi(_x_42608);
    _x_42608 = -1;
L4: 
L3: 
L2: 

    /** c_decl.e:152		if equal(x, -1) then*/
    if (_x_42608 == -1)
    _22387 = 1;
    else if (IS_ATOM_INT(_x_42608) && IS_ATOM_INT(-1))
    _22387 = 0;
    else
    _22387 = (compare(_x_42608, -1) == 0);
    if (_22387 == 0)
    {
        _22387 = NOVALUE;
        goto L5; // [73] 82
    }
    else{
        _22387 = NOVALUE;
    }

    /** c_decl.e:153			x = get_eudir()*/
    _0 = _x_42608;
    _x_42608 = _13get_eudir();
    DeRef(_0);
L5: 

    /** c_decl.e:156		return x*/
    return _x_42608;
    ;
}


void _57NewBB(object _a_call_42634, object _mask_42635, object _sub_42637)
{
    object _s_42639 = NOVALUE;
    object _22420 = NOVALUE;
    object _22419 = NOVALUE;
    object _22417 = NOVALUE;
    object _22416 = NOVALUE;
    object _22414 = NOVALUE;
    object _22413 = NOVALUE;
    object _22412 = NOVALUE;
    object _22411 = NOVALUE;
    object _22410 = NOVALUE;
    object _22409 = NOVALUE;
    object _22408 = NOVALUE;
    object _22407 = NOVALUE;
    object _22406 = NOVALUE;
    object _22405 = NOVALUE;
    object _22404 = NOVALUE;
    object _22403 = NOVALUE;
    object _22402 = NOVALUE;
    object _22401 = NOVALUE;
    object _22400 = NOVALUE;
    object _22399 = NOVALUE;
    object _22398 = NOVALUE;
    object _22397 = NOVALUE;
    object _22396 = NOVALUE;
    object _22395 = NOVALUE;
    object _22394 = NOVALUE;
    object _22393 = NOVALUE;
    object _22392 = NOVALUE;
    object _22390 = NOVALUE;
    object _22389 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_mask_42635)) {
        _1 = (object)(DBL_PTR(_mask_42635)->dbl);
        DeRefDS(_mask_42635);
        _mask_42635 = _1;
    }

    /** c_decl.e:166		if a_call then*/
    if (_a_call_42634 == 0)
    {
        goto L1; // [9] 252
    }
    else{
    }

    /** c_decl.e:169			for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_57BB_info_42586)){
            _22389 = SEQ_PTR(_57BB_info_42586)->length;
    }
    else {
        _22389 = 1;
    }
    {
        object _i_42642;
        _i_42642 = 1;
L2: 
        if (_i_42642 > _22389){
            goto L3; // [19] 249
        }

        /** c_decl.e:170				s = BB_info[i][BB_VAR]*/
        _2 = (object)SEQ_PTR(_57BB_info_42586);
        _22390 = (object)*(((s1_ptr)_2)->base + _i_42642);
        _2 = (object)SEQ_PTR(_22390);
        _s_42639 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_s_42639)){
            _s_42639 = (object)DBL_PTR(_s_42639)->dbl;
        }
        _22390 = NOVALUE;

        /** c_decl.e:171				if SymTab[s][S_MODE] = M_NORMAL and*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _22392 = (object)*(((s1_ptr)_2)->base + _s_42639);
        _2 = (object)SEQ_PTR(_22392);
        _22393 = (object)*(((s1_ptr)_2)->base + 3);
        _22392 = NOVALUE;
        if (IS_ATOM_INT(_22393)) {
            _22394 = (_22393 == 1);
        }
        else {
            _22394 = binary_op(EQUALS, _22393, 1);
        }
        _22393 = NOVALUE;
        if (IS_ATOM_INT(_22394)) {
            if (_22394 == 0) {
                goto L4; // [60] 242
            }
        }
        else {
            if (DBL_PTR(_22394)->dbl == 0.0) {
                goto L4; // [60] 242
            }
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _22396 = (object)*(((s1_ptr)_2)->base + _s_42639);
        _2 = (object)SEQ_PTR(_22396);
        _22397 = (object)*(((s1_ptr)_2)->base + 4);
        _22396 = NOVALUE;
        if (IS_ATOM_INT(_22397)) {
            _22398 = (_22397 == 6);
        }
        else {
            _22398 = binary_op(EQUALS, _22397, 6);
        }
        _22397 = NOVALUE;
        if (IS_ATOM_INT(_22398)) {
            if (_22398 != 0) {
                DeRef(_22399);
                _22399 = 1;
                goto L5; // [82] 108
            }
        }
        else {
            if (DBL_PTR(_22398)->dbl != 0.0) {
                DeRef(_22399);
                _22399 = 1;
                goto L5; // [82] 108
            }
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _22400 = (object)*(((s1_ptr)_2)->base + _s_42639);
        _2 = (object)SEQ_PTR(_22400);
        _22401 = (object)*(((s1_ptr)_2)->base + 4);
        _22400 = NOVALUE;
        if (IS_ATOM_INT(_22401)) {
            _22402 = (_22401 == 5);
        }
        else {
            _22402 = binary_op(EQUALS, _22401, 5);
        }
        _22401 = NOVALUE;
        DeRef(_22399);
        if (IS_ATOM_INT(_22402))
        _22399 = (_22402 != 0);
        else
        _22399 = DBL_PTR(_22402)->dbl != 0.0;
L5: 
        if (_22399 != 0) {
            _22403 = 1;
            goto L6; // [108] 134
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _22404 = (object)*(((s1_ptr)_2)->base + _s_42639);
        _2 = (object)SEQ_PTR(_22404);
        _22405 = (object)*(((s1_ptr)_2)->base + 4);
        _22404 = NOVALUE;
        if (IS_ATOM_INT(_22405)) {
            _22406 = (_22405 == 11);
        }
        else {
            _22406 = binary_op(EQUALS, _22405, 11);
        }
        _22405 = NOVALUE;
        if (IS_ATOM_INT(_22406))
        _22403 = (_22406 != 0);
        else
        _22403 = DBL_PTR(_22406)->dbl != 0.0;
L6: 
        if (_22403 != 0) {
            DeRef(_22407);
            _22407 = 1;
            goto L7; // [134] 160
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _22408 = (object)*(((s1_ptr)_2)->base + _s_42639);
        _2 = (object)SEQ_PTR(_22408);
        _22409 = (object)*(((s1_ptr)_2)->base + 4);
        _22408 = NOVALUE;
        if (IS_ATOM_INT(_22409)) {
            _22410 = (_22409 == 13);
        }
        else {
            _22410 = binary_op(EQUALS, _22409, 13);
        }
        _22409 = NOVALUE;
        if (IS_ATOM_INT(_22410))
        _22407 = (_22410 != 0);
        else
        _22407 = DBL_PTR(_22410)->dbl != 0.0;
L7: 
        if (_22407 == 0)
        {
            _22407 = NOVALUE;
            goto L4; // [161] 242
        }
        else{
            _22407 = NOVALUE;
        }

        /** c_decl.e:176					  if and_bits(mask, power(2, remainder(s, E_SIZE))) then*/
        _22411 = (_s_42639 % 29);
        _22412 = power(2, _22411);
        _22411 = NOVALUE;
        if (IS_ATOM_INT(_22412)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_mask_42635 & (uintptr_t)_22412;
                 _22413 = MAKE_UINT(tu);
            }
        }
        else {
            temp_d.dbl = (eudouble)_mask_42635;
            _22413 = Dand_bits(&temp_d, DBL_PTR(_22412));
        }
        DeRef(_22412);
        _22412 = NOVALUE;
        if (_22413 == 0) {
            DeRef(_22413);
            _22413 = NOVALUE;
            goto L8; // [180] 241
        }
        else {
            if (!IS_ATOM_INT(_22413) && DBL_PTR(_22413)->dbl == 0.0){
                DeRef(_22413);
                _22413 = NOVALUE;
                goto L8; // [180] 241
            }
            DeRef(_22413);
            _22413 = NOVALUE;
        }
        DeRef(_22413);
        _22413 = NOVALUE;

        /** c_decl.e:177						  if mask = E_ALL_EFFECT or s < sub then*/
        _22414 = (_mask_42635 == 1073741823);
        if (_22414 != 0) {
            goto L9; // [191] 204
        }
        _22416 = (_s_42639 < _sub_42637);
        if (_22416 == 0)
        {
            DeRef(_22416);
            _22416 = NOVALUE;
            goto LA; // [200] 240
        }
        else{
            DeRef(_22416);
            _22416 = NOVALUE;
        }
L9: 

        /** c_decl.e:178							  BB_info[i][BB_TYPE..BB_OBJ] =*/
        _2 = (object)SEQ_PTR(_57BB_info_42586);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _57BB_info_42586 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_42642 + ((s1_ptr)_2)->base);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -1073741824;
        ((intptr_t *)_2)[2] = 1073741823;
        _22419 = MAKE_SEQ(_1);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 0;
        ((intptr_t*)_2)[2] = 0;
        Ref(_12NOVALUE_20081);
        ((intptr_t*)_2)[3] = _12NOVALUE_20081;
        ((intptr_t*)_2)[4] = _22419;
        _22420 = MAKE_SEQ(_1);
        _22419 = NOVALUE;
        assign_slice_seq = (s1_ptr *)_3;
        AssignSlice(2, 5, _22420);
        DeRefDS(_22420);
        _22420 = NOVALUE;
LA: 
L8: 
L4: 

        /** c_decl.e:183			end for*/
        _i_42642 = _i_42642 + 1;
        goto L2; // [244] 26
L3: 
        ;
    }
    goto LB; // [249] 260
L1: 

    /** c_decl.e:186			BB_info = {}*/
    RefDS(_22015);
    DeRef(_57BB_info_42586);
    _57BB_info_42586 = _22015;
LB: 

    /** c_decl.e:188	end procedure*/
    DeRef(_22417);
    _22417 = NOVALUE;
    DeRef(_22402);
    _22402 = NOVALUE;
    DeRef(_22406);
    _22406 = NOVALUE;
    DeRef(_22394);
    _22394 = NOVALUE;
    DeRef(_22410);
    _22410 = NOVALUE;
    DeRef(_22414);
    _22414 = NOVALUE;
    DeRef(_22398);
    _22398 = NOVALUE;
    return;
    ;
}


object _57BB_var_obj(object _var_42707)
{
    object _bbi_42708 = NOVALUE;
    object _22431 = NOVALUE;
    object _22429 = NOVALUE;
    object _22427 = NOVALUE;
    object _22426 = NOVALUE;
    object _22424 = NOVALUE;
    object _22422 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:196		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_57BB_info_42586)){
            _22422 = SEQ_PTR(_57BB_info_42586)->length;
    }
    else {
        _22422 = 1;
    }
    {
        object _i_42710;
        _i_42710 = _22422;
L1: 
        if (_i_42710 < 1){
            goto L2; // [10] 99
        }

        /** c_decl.e:197			bbi = BB_info[i]*/
        DeRef(_bbi_42708);
        _2 = (object)SEQ_PTR(_57BB_info_42586);
        _bbi_42708 = (object)*(((s1_ptr)_2)->base + _i_42710);
        Ref(_bbi_42708);

        /** c_decl.e:198			if bbi[BB_VAR] != var then*/
        _2 = (object)SEQ_PTR(_bbi_42708);
        _22424 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(EQUALS, _22424, _var_42707)){
            _22424 = NOVALUE;
            goto L3; // [31] 40
        }
        _22424 = NOVALUE;

        /** c_decl.e:199				continue*/
        goto L4; // [37] 94
L3: 

        /** c_decl.e:202			if SymTab[var][S_MODE] != M_NORMAL then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _22426 = (object)*(((s1_ptr)_2)->base + _var_42707);
        _2 = (object)SEQ_PTR(_22426);
        _22427 = (object)*(((s1_ptr)_2)->base + 3);
        _22426 = NOVALUE;
        if (binary_op_a(EQUALS, _22427, 1)){
            _22427 = NOVALUE;
            goto L5; // [56] 65
        }
        _22427 = NOVALUE;

        /** c_decl.e:203				continue*/
        goto L4; // [62] 94
L5: 

        /** c_decl.e:206			if bbi[BB_TYPE] != TYPE_INTEGER then*/
        _2 = (object)SEQ_PTR(_bbi_42708);
        _22429 = (object)*(((s1_ptr)_2)->base + 2);
        if (binary_op_a(EQUALS, _22429, 1)){
            _22429 = NOVALUE;
            goto L6; // [73] 82
        }
        _22429 = NOVALUE;

        /** c_decl.e:207				exit*/
        goto L2; // [79] 99
L6: 

        /** c_decl.e:210			return bbi[BB_OBJ]*/
        _2 = (object)SEQ_PTR(_bbi_42708);
        _22431 = (object)*(((s1_ptr)_2)->base + 5);
        Ref(_22431);
        DeRef(_bbi_42708);
        return _22431;

        /** c_decl.e:211		end for*/
L4: 
        _i_42710 = _i_42710 + -1;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** c_decl.e:212		return BB_def_values*/
    RefDS(_57BB_def_values_42701);
    DeRef(_bbi_42708);
    _22431 = NOVALUE;
    return _57BB_def_values_42701;
    ;
}


object _57BB_var_type(object _var_42730)
{
    object _22446 = NOVALUE;
    object _22445 = NOVALUE;
    object _22443 = NOVALUE;
    object _22442 = NOVALUE;
    object _22441 = NOVALUE;
    object _22440 = NOVALUE;
    object _22439 = NOVALUE;
    object _22438 = NOVALUE;
    object _22437 = NOVALUE;
    object _22436 = NOVALUE;
    object _22435 = NOVALUE;
    object _22434 = NOVALUE;
    object _22433 = NOVALUE;
    object _22432 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:218		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_57BB_info_42586)){
            _22432 = SEQ_PTR(_57BB_info_42586)->length;
    }
    else {
        _22432 = 1;
    }
    {
        object _i_42732;
        _i_42732 = _22432;
L1: 
        if (_i_42732 < 1){
            goto L2; // [10] 125
        }

        /** c_decl.e:219			if BB_info[i][BB_VAR] = var and*/
        _2 = (object)SEQ_PTR(_57BB_info_42586);
        _22433 = (object)*(((s1_ptr)_2)->base + _i_42732);
        _2 = (object)SEQ_PTR(_22433);
        _22434 = (object)*(((s1_ptr)_2)->base + 1);
        _22433 = NOVALUE;
        if (IS_ATOM_INT(_22434)) {
            _22435 = (_22434 == _var_42730);
        }
        else {
            _22435 = binary_op(EQUALS, _22434, _var_42730);
        }
        _22434 = NOVALUE;
        if (IS_ATOM_INT(_22435)) {
            if (_22435 == 0) {
                goto L3; // [33] 118
            }
        }
        else {
            if (DBL_PTR(_22435)->dbl == 0.0) {
                goto L3; // [33] 118
            }
        }
        _2 = (object)SEQ_PTR(_57BB_info_42586);
        _22437 = (object)*(((s1_ptr)_2)->base + _i_42732);
        _2 = (object)SEQ_PTR(_22437);
        _22438 = (object)*(((s1_ptr)_2)->base + 1);
        _22437 = NOVALUE;
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!IS_ATOM_INT(_22438)){
            _22439 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22438)->dbl));
        }
        else{
            _22439 = (object)*(((s1_ptr)_2)->base + _22438);
        }
        _2 = (object)SEQ_PTR(_22439);
        _22440 = (object)*(((s1_ptr)_2)->base + 3);
        _22439 = NOVALUE;
        if (IS_ATOM_INT(_22440)) {
            _22441 = (_22440 == 1);
        }
        else {
            _22441 = binary_op(EQUALS, _22440, 1);
        }
        _22440 = NOVALUE;
        if (_22441 == 0) {
            DeRef(_22441);
            _22441 = NOVALUE;
            goto L3; // [66] 118
        }
        else {
            if (!IS_ATOM_INT(_22441) && DBL_PTR(_22441)->dbl == 0.0){
                DeRef(_22441);
                _22441 = NOVALUE;
                goto L3; // [66] 118
            }
            DeRef(_22441);
            _22441 = NOVALUE;
        }
        DeRef(_22441);
        _22441 = NOVALUE;

        /** c_decl.e:221				ifdef DEBUG then*/

        /** c_decl.e:228				if BB_info[i][BB_TYPE] = TYPE_NULL then  -- var has only been read*/
        _2 = (object)SEQ_PTR(_57BB_info_42586);
        _22442 = (object)*(((s1_ptr)_2)->base + _i_42732);
        _2 = (object)SEQ_PTR(_22442);
        _22443 = (object)*(((s1_ptr)_2)->base + 2);
        _22442 = NOVALUE;
        if (binary_op_a(NOTEQ, _22443, 0)){
            _22443 = NOVALUE;
            goto L4; // [85] 100
        }
        _22443 = NOVALUE;

        /** c_decl.e:229					return TYPE_OBJECT*/
        _22438 = NOVALUE;
        DeRef(_22435);
        _22435 = NOVALUE;
        return 16;
        goto L5; // [97] 117
L4: 

        /** c_decl.e:231					return BB_info[i][BB_TYPE]*/
        _2 = (object)SEQ_PTR(_57BB_info_42586);
        _22445 = (object)*(((s1_ptr)_2)->base + _i_42732);
        _2 = (object)SEQ_PTR(_22445);
        _22446 = (object)*(((s1_ptr)_2)->base + 2);
        _22445 = NOVALUE;
        Ref(_22446);
        _22438 = NOVALUE;
        DeRef(_22435);
        _22435 = NOVALUE;
        return _22446;
L5: 
L3: 

        /** c_decl.e:234		end for*/
        _i_42732 = _i_42732 + -1;
        goto L1; // [120] 17
L2: 
        ;
    }

    /** c_decl.e:235		return TYPE_OBJECT*/
    _22438 = NOVALUE;
    DeRef(_22435);
    _22435 = NOVALUE;
    _22446 = NOVALUE;
    return 16;
    ;
}


object _57GType(object _s_42760)
{
    object _t_42761 = NOVALUE;
    object _local_t_42762 = NOVALUE;
    object _22450 = NOVALUE;
    object _22449 = NOVALUE;
    object _22447 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_42760)) {
        _1 = (object)(DBL_PTR(_s_42760)->dbl);
        DeRefDS(_s_42760);
        _s_42760 = _1;
    }

    /** c_decl.e:243		t = SymTab[s][S_GTYPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22447 = (object)*(((s1_ptr)_2)->base + _s_42760);
    _2 = (object)SEQ_PTR(_22447);
    _t_42761 = (object)*(((s1_ptr)_2)->base + 36);
    if (!IS_ATOM_INT(_t_42761)){
        _t_42761 = (object)DBL_PTR(_t_42761)->dbl;
    }
    _22447 = NOVALUE;

    /** c_decl.e:244		ifdef DEBUG then*/

    /** c_decl.e:250		if SymTab[s][S_MODE] != M_NORMAL then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22449 = (object)*(((s1_ptr)_2)->base + _s_42760);
    _2 = (object)SEQ_PTR(_22449);
    _22450 = (object)*(((s1_ptr)_2)->base + 3);
    _22449 = NOVALUE;
    if (binary_op_a(EQUALS, _22450, 1)){
        _22450 = NOVALUE;
        goto L1; // [37] 48
    }
    _22450 = NOVALUE;

    /** c_decl.e:251			return t*/
    return _t_42761;
L1: 

    /** c_decl.e:254		local_t = BB_var_type(s)*/
    _local_t_42762 = _57BB_var_type(_s_42760);
    if (!IS_ATOM_INT(_local_t_42762)) {
        _1 = (object)(DBL_PTR(_local_t_42762)->dbl);
        DeRefDS(_local_t_42762);
        _local_t_42762 = _1;
    }

    /** c_decl.e:255		if local_t = TYPE_OBJECT then*/
    if (_local_t_42762 != 16)
    goto L2; // [60] 71

    /** c_decl.e:256			return t*/
    return _t_42761;
L2: 

    /** c_decl.e:258		if t = TYPE_INTEGER then*/
    if (_t_42761 != 1)
    goto L3; // [75] 88

    /** c_decl.e:259			return TYPE_INTEGER*/
    return 1;
L3: 

    /** c_decl.e:261		return local_t*/
    return _local_t_42762;
    ;
}


object _57GDelete()
{
    object _0, _1, _2;
    

    /** c_decl.e:269		return g_has_delete*/
    return _57g_has_delete_42782;
    ;
}


object _57HasDelete(object _s_42789)
{
    object _22465 = NOVALUE;
    object _22464 = NOVALUE;
    object _22462 = NOVALUE;
    object _22461 = NOVALUE;
    object _22460 = NOVALUE;
    object _22459 = NOVALUE;
    object _22457 = NOVALUE;
    object _22456 = NOVALUE;
    object _22455 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_42789)) {
        _1 = (object)(DBL_PTR(_s_42789)->dbl);
        DeRefDS(_s_42789);
        _s_42789 = _1;
    }

    /** c_decl.e:274		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_57BB_info_42586)){
            _22455 = SEQ_PTR(_57BB_info_42586)->length;
    }
    else {
        _22455 = 1;
    }
    {
        object _i_42791;
        _i_42791 = _22455;
L1: 
        if (_i_42791 < 1){
            goto L2; // [10] 57
        }

        /** c_decl.e:275			if BB_info[i][BB_VAR] = s then*/
        _2 = (object)SEQ_PTR(_57BB_info_42586);
        _22456 = (object)*(((s1_ptr)_2)->base + _i_42791);
        _2 = (object)SEQ_PTR(_22456);
        _22457 = (object)*(((s1_ptr)_2)->base + 1);
        _22456 = NOVALUE;
        if (binary_op_a(NOTEQ, _22457, _s_42789)){
            _22457 = NOVALUE;
            goto L3; // [29] 50
        }
        _22457 = NOVALUE;

        /** c_decl.e:276				return BB_info[i][BB_DELETE]*/
        _2 = (object)SEQ_PTR(_57BB_info_42586);
        _22459 = (object)*(((s1_ptr)_2)->base + _i_42791);
        _2 = (object)SEQ_PTR(_22459);
        _22460 = (object)*(((s1_ptr)_2)->base + 6);
        _22459 = NOVALUE;
        Ref(_22460);
        return _22460;
L3: 

        /** c_decl.e:278		end for*/
        _i_42791 = _i_42791 + -1;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** c_decl.e:279		if length(SymTab[s]) < S_HAS_DELETE then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22461 = (object)*(((s1_ptr)_2)->base + _s_42789);
    if (IS_SEQUENCE(_22461)){
            _22462 = SEQ_PTR(_22461)->length;
    }
    else {
        _22462 = 1;
    }
    _22461 = NOVALUE;
    if (_22462 >= 54)
    goto L4; // [70] 81

    /** c_decl.e:280			return 0*/
    _22460 = NOVALUE;
    _22461 = NOVALUE;
    return 0;
L4: 

    /** c_decl.e:282		return SymTab[s][S_HAS_DELETE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22464 = (object)*(((s1_ptr)_2)->base + _s_42789);
    _2 = (object)SEQ_PTR(_22464);
    _22465 = (object)*(((s1_ptr)_2)->base + 54);
    _22464 = NOVALUE;
    Ref(_22465);
    _22460 = NOVALUE;
    _22461 = NOVALUE;
    return _22465;
    ;
}


object _57ObjValue(object _s_42812)
{
    object _local_t_42813 = NOVALUE;
    object _st_42814 = NOVALUE;
    object _tmin_42815 = NOVALUE;
    object _tmax_42816 = NOVALUE;
    object _22478 = NOVALUE;
    object _22476 = NOVALUE;
    object _22475 = NOVALUE;
    object _22473 = NOVALUE;
    object _22470 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_42812)) {
        _1 = (object)(DBL_PTR(_s_42812)->dbl);
        DeRefDS(_s_42812);
        _s_42812 = _1;
    }

    /** c_decl.e:293		st = SymTab[s]*/
    DeRef(_st_42814);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _st_42814 = (object)*(((s1_ptr)_2)->base + _s_42812);
    Ref(_st_42814);

    /** c_decl.e:294		tmin = st[S_OBJ_MIN]*/
    DeRef(_tmin_42815);
    _2 = (object)SEQ_PTR(_st_42814);
    _tmin_42815 = (object)*(((s1_ptr)_2)->base + 30);
    Ref(_tmin_42815);

    /** c_decl.e:295		tmax = st[S_OBJ_MAX]*/
    DeRef(_tmax_42816);
    _2 = (object)SEQ_PTR(_st_42814);
    _tmax_42816 = (object)*(((s1_ptr)_2)->base + 31);
    Ref(_tmax_42816);

    /** c_decl.e:297		if tmin != tmax then*/
    if (binary_op_a(EQUALS, _tmin_42815, _tmax_42816)){
        goto L1; // [29] 41
    }

    /** c_decl.e:298			tmin = NOVALUE*/
    Ref(_12NOVALUE_20081);
    DeRef(_tmin_42815);
    _tmin_42815 = _12NOVALUE_20081;
L1: 

    /** c_decl.e:300		if st[S_MODE] != M_NORMAL then*/
    _2 = (object)SEQ_PTR(_st_42814);
    _22470 = (object)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(EQUALS, _22470, 1)){
        _22470 = NOVALUE;
        goto L2; // [51] 62
    }
    _22470 = NOVALUE;

    /** c_decl.e:301			return tmin*/
    DeRef(_local_t_42813);
    DeRef(_st_42814);
    DeRef(_tmax_42816);
    return _tmin_42815;
L2: 

    /** c_decl.e:305		local_t = BB_var_obj(s)*/
    _0 = _local_t_42813;
    _local_t_42813 = _57BB_var_obj(_s_42812);
    DeRef(_0);

    /** c_decl.e:306		if local_t[MIN] = NOVALUE then*/
    _2 = (object)SEQ_PTR(_local_t_42813);
    _22473 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _22473, _12NOVALUE_20081)){
        _22473 = NOVALUE;
        goto L3; // [80] 91
    }
    _22473 = NOVALUE;

    /** c_decl.e:307			return tmin*/
    DeRefDS(_local_t_42813);
    DeRef(_st_42814);
    DeRef(_tmax_42816);
    return _tmin_42815;
L3: 

    /** c_decl.e:310		if local_t[MIN] != local_t[MAX] then*/
    _2 = (object)SEQ_PTR(_local_t_42813);
    _22475 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_local_t_42813);
    _22476 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(EQUALS, _22475, _22476)){
        _22475 = NOVALUE;
        _22476 = NOVALUE;
        goto L4; // [105] 116
    }
    _22475 = NOVALUE;
    _22476 = NOVALUE;

    /** c_decl.e:311			return tmin*/
    DeRefDS(_local_t_42813);
    DeRef(_st_42814);
    DeRef(_tmax_42816);
    return _tmin_42815;
L4: 

    /** c_decl.e:314		return local_t[MIN]*/
    _2 = (object)SEQ_PTR(_local_t_42813);
    _22478 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22478);
    DeRefDS(_local_t_42813);
    DeRef(_st_42814);
    DeRef(_tmin_42815);
    DeRef(_tmax_42816);
    return _22478;
    ;
}


object _57TypeIs(object _x_42847, object _typei_42848)
{
    object _22480 = NOVALUE;
    object _22479 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_42847)) {
        _1 = (object)(DBL_PTR(_x_42847)->dbl);
        DeRefDS(_x_42847);
        _x_42847 = _1;
    }

    /** c_decl.e:319		return GType(x) = typei*/
    _22479 = _57GType(_x_42847);
    if (IS_ATOM_INT(_22479)) {
        _22480 = (_22479 == _typei_42848);
    }
    else {
        _22480 = binary_op(EQUALS, _22479, _typei_42848);
    }
    DeRef(_22479);
    _22479 = NOVALUE;
    return _22480;
    ;
}


object _57TypeIsIn(object _x_42853, object _types_42854)
{
    object _22482 = NOVALUE;
    object _22481 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_42853)) {
        _1 = (object)(DBL_PTR(_x_42853)->dbl);
        DeRefDS(_x_42853);
        _x_42853 = _1;
    }

    /** c_decl.e:323		return find(GType(x), types)*/
    _22481 = _57GType(_x_42853);
    _22482 = find_from(_22481, _types_42854, 1);
    DeRef(_22481);
    _22481 = NOVALUE;
    DeRefDS(_types_42854);
    return _22482;
    ;
}


object _57TypeIsNot(object _x_42859, object _typei_42860)
{
    object _22484 = NOVALUE;
    object _22483 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_42859)) {
        _1 = (object)(DBL_PTR(_x_42859)->dbl);
        DeRefDS(_x_42859);
        _x_42859 = _1;
    }

    /** c_decl.e:327		return GType(x) != typei*/
    _22483 = _57GType(_x_42859);
    if (IS_ATOM_INT(_22483)) {
        _22484 = (_22483 != _typei_42860);
    }
    else {
        _22484 = binary_op(NOTEQ, _22483, _typei_42860);
    }
    DeRef(_22483);
    _22483 = NOVALUE;
    return _22484;
    ;
}


object _57TypeIsNotIn(object _x_42865, object _types_42866)
{
    object _22487 = NOVALUE;
    object _22486 = NOVALUE;
    object _22485 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_42865)) {
        _1 = (object)(DBL_PTR(_x_42865)->dbl);
        DeRefDS(_x_42865);
        _x_42865 = _1;
    }

    /** c_decl.e:331		return not find(GType(x), types)*/
    _22485 = _57GType(_x_42865);
    _22486 = find_from(_22485, _types_42866, 1);
    DeRef(_22485);
    _22485 = NOVALUE;
    _22487 = (_22486 == 0);
    _22486 = NOVALUE;
    DeRefDS(_types_42866);
    return _22487;
    ;
}


object _57or_type(object _t1_42872, object _t2_42873)
{
    object _22507 = NOVALUE;
    object _22506 = NOVALUE;
    object _22505 = NOVALUE;
    object _22504 = NOVALUE;
    object _22499 = NOVALUE;
    object _22497 = NOVALUE;
    object _22492 = NOVALUE;
    object _22490 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_t1_42872)) {
        _1 = (object)(DBL_PTR(_t1_42872)->dbl);
        DeRefDS(_t1_42872);
        _t1_42872 = _1;
    }
    if (!IS_ATOM_INT(_t2_42873)) {
        _1 = (object)(DBL_PTR(_t2_42873)->dbl);
        DeRefDS(_t2_42873);
        _t2_42873 = _1;
    }

    /** c_decl.e:337		if t1 = TYPE_NULL then*/
    if (_t1_42872 != 0)
    goto L1; // [9] 22

    /** c_decl.e:338			return t2*/
    return _t2_42873;
    goto L2; // [19] 307
L1: 

    /** c_decl.e:340		elsif t2 = TYPE_NULL then*/
    if (_t2_42873 != 0)
    goto L3; // [26] 39

    /** c_decl.e:341			return t1*/
    return _t1_42872;
    goto L2; // [36] 307
L3: 

    /** c_decl.e:343		elsif t1 = TYPE_OBJECT or t2 = TYPE_OBJECT then*/
    _22490 = (_t1_42872 == 16);
    if (_22490 != 0) {
        goto L4; // [47] 62
    }
    _22492 = (_t2_42873 == 16);
    if (_22492 == 0)
    {
        DeRef(_22492);
        _22492 = NOVALUE;
        goto L5; // [58] 73
    }
    else{
        DeRef(_22492);
        _22492 = NOVALUE;
    }
L4: 

    /** c_decl.e:344			return TYPE_OBJECT*/
    DeRef(_22490);
    _22490 = NOVALUE;
    return 16;
    goto L2; // [70] 307
L5: 

    /** c_decl.e:346		elsif t1 = TYPE_SEQUENCE then*/
    if (_t1_42872 != 8)
    goto L6; // [77] 112

    /** c_decl.e:347			if t2 = TYPE_SEQUENCE then*/
    if (_t2_42873 != 8)
    goto L7; // [85] 100

    /** c_decl.e:348				return TYPE_SEQUENCE*/
    DeRef(_22490);
    _22490 = NOVALUE;
    return 8;
    goto L2; // [97] 307
L7: 

    /** c_decl.e:350				return TYPE_OBJECT*/
    DeRef(_22490);
    _22490 = NOVALUE;
    return 16;
    goto L2; // [109] 307
L6: 

    /** c_decl.e:353		elsif t2 = TYPE_SEQUENCE then*/
    if (_t2_42873 != 8)
    goto L8; // [116] 151

    /** c_decl.e:354			if t1 = TYPE_SEQUENCE then*/
    if (_t1_42872 != 8)
    goto L9; // [124] 139

    /** c_decl.e:355				return TYPE_SEQUENCE*/
    DeRef(_22490);
    _22490 = NOVALUE;
    return 8;
    goto L2; // [136] 307
L9: 

    /** c_decl.e:357				return TYPE_OBJECT*/
    DeRef(_22490);
    _22490 = NOVALUE;
    return 16;
    goto L2; // [148] 307
L8: 

    /** c_decl.e:360		elsif t1 = TYPE_ATOM or t2 = TYPE_ATOM then*/
    _22497 = (_t1_42872 == 4);
    if (_22497 != 0) {
        goto LA; // [159] 174
    }
    _22499 = (_t2_42873 == 4);
    if (_22499 == 0)
    {
        DeRef(_22499);
        _22499 = NOVALUE;
        goto LB; // [170] 185
    }
    else{
        DeRef(_22499);
        _22499 = NOVALUE;
    }
LA: 

    /** c_decl.e:361			return TYPE_ATOM*/
    DeRef(_22490);
    _22490 = NOVALUE;
    DeRef(_22497);
    _22497 = NOVALUE;
    return 4;
    goto L2; // [182] 307
LB: 

    /** c_decl.e:363		elsif t1 = TYPE_DOUBLE then*/
    if (_t1_42872 != 2)
    goto LC; // [189] 224

    /** c_decl.e:364			if t2 = TYPE_INTEGER then*/
    if (_t2_42873 != 1)
    goto LD; // [197] 212

    /** c_decl.e:365				return TYPE_ATOM*/
    DeRef(_22490);
    _22490 = NOVALUE;
    DeRef(_22497);
    _22497 = NOVALUE;
    return 4;
    goto L2; // [209] 307
LD: 

    /** c_decl.e:367				return TYPE_DOUBLE*/
    DeRef(_22490);
    _22490 = NOVALUE;
    DeRef(_22497);
    _22497 = NOVALUE;
    return 2;
    goto L2; // [221] 307
LC: 

    /** c_decl.e:370		elsif t2 = TYPE_DOUBLE then*/
    if (_t2_42873 != 2)
    goto LE; // [228] 263

    /** c_decl.e:371			if t1 = TYPE_INTEGER then*/
    if (_t1_42872 != 1)
    goto LF; // [236] 251

    /** c_decl.e:372				return TYPE_ATOM*/
    DeRef(_22490);
    _22490 = NOVALUE;
    DeRef(_22497);
    _22497 = NOVALUE;
    return 4;
    goto L2; // [248] 307
LF: 

    /** c_decl.e:374				return TYPE_DOUBLE*/
    DeRef(_22490);
    _22490 = NOVALUE;
    DeRef(_22497);
    _22497 = NOVALUE;
    return 2;
    goto L2; // [260] 307
LE: 

    /** c_decl.e:377		elsif t1 = TYPE_INTEGER and t2 = TYPE_INTEGER then*/
    _22504 = (_t1_42872 == 1);
    if (_22504 == 0) {
        goto L10; // [271] 296
    }
    _22506 = (_t2_42873 == 1);
    if (_22506 == 0)
    {
        DeRef(_22506);
        _22506 = NOVALUE;
        goto L10; // [282] 296
    }
    else{
        DeRef(_22506);
        _22506 = NOVALUE;
    }

    /** c_decl.e:378			return TYPE_INTEGER*/
    DeRef(_22490);
    _22490 = NOVALUE;
    DeRef(_22504);
    _22504 = NOVALUE;
    DeRef(_22497);
    _22497 = NOVALUE;
    return 1;
    goto L2; // [293] 307
L10: 

    /** c_decl.e:381			InternalErr(258, {t1, t2})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _t1_42872;
    ((intptr_t *)_2)[2] = _t2_42873;
    _22507 = MAKE_SEQ(_1);
    _49InternalErr(258, _22507);
    _22507 = NOVALUE;
L2: 
    ;
}


void _57RemoveFromBB(object _s_42943)
{
    object _int_42944 = NOVALUE;
    object _22509 = NOVALUE;
    object _22508 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:388		for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_57BB_info_42586)){
            _22508 = SEQ_PTR(_57BB_info_42586)->length;
    }
    else {
        _22508 = 1;
    }
    {
        object _i_42946;
        _i_42946 = 1;
L1: 
        if (_i_42946 > _22508){
            goto L2; // [10] 59
        }

        /** c_decl.e:389			int = BB_info[i][BB_VAR]*/
        _2 = (object)SEQ_PTR(_57BB_info_42586);
        _22509 = (object)*(((s1_ptr)_2)->base + _i_42946);
        _2 = (object)SEQ_PTR(_22509);
        _int_42944 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_int_42944)){
            _int_42944 = (object)DBL_PTR(_int_42944)->dbl;
        }
        _22509 = NOVALUE;

        /** c_decl.e:390			if int = s then*/
        if (_int_42944 != _s_42943)
        goto L3; // [33] 52

        /** c_decl.e:391				BB_info = remove( BB_info, int )*/
        {
            s1_ptr assign_space = SEQ_PTR(_57BB_info_42586);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_int_42944)) ? _int_42944 : (object)(DBL_PTR(_int_42944)->dbl);
            int stop = (IS_ATOM_INT(_int_42944)) ? _int_42944 : (object)(DBL_PTR(_int_42944)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_57BB_info_42586), start, &_57BB_info_42586 );
                }
                else Tail(SEQ_PTR(_57BB_info_42586), stop+1, &_57BB_info_42586);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_57BB_info_42586), start, &_57BB_info_42586);
            }
            else {
                assign_slice_seq = &assign_space;
                _57BB_info_42586 = Remove_elements(start, stop, (SEQ_PTR(_57BB_info_42586)->ref == 1));
            }
        }

        /** c_decl.e:392				return*/
        return;
L3: 

        /** c_decl.e:394		end for*/
        _i_42946 = _i_42946 + 1;
        goto L1; // [54] 17
L2: 
        ;
    }

    /** c_decl.e:395	end procedure*/
    return;
    ;
}


void _57SetBBType(object _s_42964, object _t_42965, object _val_42966, object _etype_42967, object _has_delete_42968)
{
    object _found_42969 = NOVALUE;
    object _i_42970 = NOVALUE;
    object _tn_42971 = NOVALUE;
    object _int_42972 = NOVALUE;
    object _sym_42973 = NOVALUE;
    object _mode_42978 = NOVALUE;
    object _gtype_42993 = NOVALUE;
    object _new_type_43030 = NOVALUE;
    object _bbsym_43053 = NOVALUE;
    object _bbi_43189 = NOVALUE;
    object _22628 = NOVALUE;
    object _22627 = NOVALUE;
    object _22626 = NOVALUE;
    object _22624 = NOVALUE;
    object _22623 = NOVALUE;
    object _22622 = NOVALUE;
    object _22620 = NOVALUE;
    object _22619 = NOVALUE;
    object _22617 = NOVALUE;
    object _22615 = NOVALUE;
    object _22614 = NOVALUE;
    object _22612 = NOVALUE;
    object _22610 = NOVALUE;
    object _22609 = NOVALUE;
    object _22608 = NOVALUE;
    object _22607 = NOVALUE;
    object _22606 = NOVALUE;
    object _22605 = NOVALUE;
    object _22604 = NOVALUE;
    object _22603 = NOVALUE;
    object _22602 = NOVALUE;
    object _22599 = NOVALUE;
    object _22595 = NOVALUE;
    object _22590 = NOVALUE;
    object _22588 = NOVALUE;
    object _22587 = NOVALUE;
    object _22586 = NOVALUE;
    object _22584 = NOVALUE;
    object _22582 = NOVALUE;
    object _22581 = NOVALUE;
    object _22580 = NOVALUE;
    object _22578 = NOVALUE;
    object _22577 = NOVALUE;
    object _22575 = NOVALUE;
    object _22574 = NOVALUE;
    object _22573 = NOVALUE;
    object _22571 = NOVALUE;
    object _22570 = NOVALUE;
    object _22567 = NOVALUE;
    object _22566 = NOVALUE;
    object _22565 = NOVALUE;
    object _22563 = NOVALUE;
    object _22561 = NOVALUE;
    object _22560 = NOVALUE;
    object _22558 = NOVALUE;
    object _22557 = NOVALUE;
    object _22556 = NOVALUE;
    object _22554 = NOVALUE;
    object _22553 = NOVALUE;
    object _22542 = NOVALUE;
    object _22540 = NOVALUE;
    object _22537 = NOVALUE;
    object _22536 = NOVALUE;
    object _22533 = NOVALUE;
    object _22532 = NOVALUE;
    object _22531 = NOVALUE;
    object _22529 = NOVALUE;
    object _22528 = NOVALUE;
    object _22527 = NOVALUE;
    object _22525 = NOVALUE;
    object _22524 = NOVALUE;
    object _22522 = NOVALUE;
    object _22519 = NOVALUE;
    object _22517 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_42964)) {
        _1 = (object)(DBL_PTR(_s_42964)->dbl);
        DeRefDS(_s_42964);
        _s_42964 = _1;
    }
    if (!IS_ATOM_INT(_t_42965)) {
        _1 = (object)(DBL_PTR(_t_42965)->dbl);
        DeRefDS(_t_42965);
        _t_42965 = _1;
    }
    if (!IS_ATOM_INT(_etype_42967)) {
        _1 = (object)(DBL_PTR(_etype_42967)->dbl);
        DeRefDS(_etype_42967);
        _etype_42967 = _1;
    }
    if (!IS_ATOM_INT(_has_delete_42968)) {
        _1 = (object)(DBL_PTR(_has_delete_42968)->dbl);
        DeRefDS(_has_delete_42968);
        _has_delete_42968 = _1;
    }

    /** c_decl.e:416		if has_delete then*/
    if (_has_delete_42968 == 0)
    {
        goto L1; // [13] 27
    }
    else{
    }

    /** c_decl.e:417			p_has_delete = 1*/
    _57p_has_delete_42783 = 1;

    /** c_decl.e:418			g_has_delete = 1*/
    _57g_has_delete_42782 = 1;
L1: 

    /** c_decl.e:421		sym = SymTab[s]*/
    DeRef(_sym_42973);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _sym_42973 = (object)*(((s1_ptr)_2)->base + _s_42964);
    Ref(_sym_42973);

    /** c_decl.e:422		SymTab[s] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_42964);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:424		integer mode = sym[S_MODE]*/
    _2 = (object)SEQ_PTR(_sym_42973);
    _mode_42978 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_42978))
    _mode_42978 = (object)DBL_PTR(_mode_42978)->dbl;

    /** c_decl.e:425		if mode = M_NORMAL or mode = M_TEMP  then*/
    _22517 = (_mode_42978 == 1);
    if (_22517 != 0) {
        goto L2; // [61] 76
    }
    _22519 = (_mode_42978 == 3);
    if (_22519 == 0)
    {
        DeRef(_22519);
        _22519 = NOVALUE;
        goto L3; // [72] 1167
    }
    else{
        DeRef(_22519);
        _22519 = NOVALUE;
    }
L2: 

    /** c_decl.e:427			found = FALSE*/
    _found_42969 = _9FALSE_444;

    /** c_decl.e:428			if mode = M_TEMP then*/
    if (_mode_42978 != 3)
    goto L4; // [89] 465

    /** c_decl.e:429				sym[S_GTYPE] = t*/
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_42965;
    DeRef(_1);

    /** c_decl.e:430				sym[S_SEQ_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_42967;
    DeRef(_1);

    /** c_decl.e:431				integer gtype = sym[S_GTYPE]*/
    _2 = (object)SEQ_PTR(_sym_42973);
    _gtype_42993 = (object)*(((s1_ptr)_2)->base + 36);
    if (!IS_ATOM_INT(_gtype_42993))
    _gtype_42993 = (object)DBL_PTR(_gtype_42993)->dbl;

    /** c_decl.e:432				if gtype = TYPE_OBJECT*/
    _22522 = (_gtype_42993 == 16);
    if (_22522 != 0) {
        goto L5; // [125] 140
    }
    _22524 = (_gtype_42993 == 8);
    if (_22524 == 0)
    {
        DeRef(_22524);
        _22524 = NOVALUE;
        goto L6; // [136] 213
    }
    else{
        DeRef(_22524);
        _22524 = NOVALUE;
    }
L5: 

    /** c_decl.e:435					if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22525 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22525, 0)){
        _22525 = NOVALUE;
        goto L7; // [148] 165
    }
    _22525 = NOVALUE;

    /** c_decl.e:436						sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
    goto L8; // [162] 180
L7: 

    /** c_decl.e:438						sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22527 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22527);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22527;
    if( _1 != _22527 ){
        DeRef(_1);
    }
    _22527 = NOVALUE;
L8: 

    /** c_decl.e:440					sym[S_OBJ] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** c_decl.e:442					sym[S_OBJ_MIN] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** c_decl.e:443					sym[S_OBJ_MAX] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
    goto L9; // [210] 252
L6: 

    /** c_decl.e:445					sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22528 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22528);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22528;
    if( _1 != _22528 ){
        DeRef(_1);
    }
    _22528 = NOVALUE;

    /** c_decl.e:446					sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22529 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_22529);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22529;
    if( _1 != _22529 ){
        DeRef(_1);
    }
    _22529 = NOVALUE;

    /** c_decl.e:447					sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
L9: 

    /** c_decl.e:449				if not Initializing then*/
    if (_12Initializing_20307 != 0)
    goto LA; // [256] 326

    /** c_decl.e:450					integer new_type = or_type(temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW], t)*/
    _2 = (object)SEQ_PTR(_sym_42973);
    _22531 = (object)*(((s1_ptr)_2)->base + 34);
    _2 = (object)SEQ_PTR(_12temp_name_type_20309);
    if (!IS_ATOM_INT(_22531)){
        _22532 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22531)->dbl));
    }
    else{
        _22532 = (object)*(((s1_ptr)_2)->base + _22531);
    }
    _2 = (object)SEQ_PTR(_22532);
    _22533 = (object)*(((s1_ptr)_2)->base + 2);
    _22532 = NOVALUE;
    Ref(_22533);
    _new_type_43030 = _57or_type(_22533, _t_42965);
    _22533 = NOVALUE;
    if (!IS_ATOM_INT(_new_type_43030)) {
        _1 = (object)(DBL_PTR(_new_type_43030)->dbl);
        DeRefDS(_new_type_43030);
        _new_type_43030 = _1;
    }

    /** c_decl.e:451					if new_type = TYPE_NULL then*/
    if (_new_type_43030 != 0)
    goto LB; // [290] 304

    /** c_decl.e:452						new_type = TYPE_OBJECT*/
    _new_type_43030 = 16;
LB: 

    /** c_decl.e:454					temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW] = new_type*/
    _2 = (object)SEQ_PTR(_sym_42973);
    _22536 = (object)*(((s1_ptr)_2)->base + 34);
    _2 = (object)SEQ_PTR(_12temp_name_type_20309);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12temp_name_type_20309 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_22536))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_22536)->dbl));
    else
    _3 = (object)(_22536 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_type_43030;
    DeRef(_1);
    _22537 = NOVALUE;
LA: 

    /** c_decl.e:458				tn = sym[S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_sym_42973);
    _tn_42971 = (object)*(((s1_ptr)_2)->base + 34);
    if (!IS_ATOM_INT(_tn_42971))
    _tn_42971 = (object)DBL_PTR(_tn_42971)->dbl;

    /** c_decl.e:459				i = 1*/
    _i_42970 = 1;

    /** c_decl.e:460				while i <= length(BB_info) do*/
LC: 
    if (IS_SEQUENCE(_57BB_info_42586)){
            _22540 = SEQ_PTR(_57BB_info_42586)->length;
    }
    else {
        _22540 = 1;
    }
    if (_i_42970 > _22540)
    goto LD; // [351] 460

    /** c_decl.e:461					sequence bbsym*/

    /** c_decl.e:462					int = BB_info[i][BB_VAR]*/
    _2 = (object)SEQ_PTR(_57BB_info_42586);
    _22542 = (object)*(((s1_ptr)_2)->base + _i_42970);
    _2 = (object)SEQ_PTR(_22542);
    _int_42972 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_42972)){
        _int_42972 = (object)DBL_PTR(_int_42972)->dbl;
    }
    _22542 = NOVALUE;

    /** c_decl.e:463					if int = s then*/
    if (_int_42972 != _s_42964)
    goto LE; // [373] 387

    /** c_decl.e:464						bbsym = sym*/
    RefDS(_sym_42973);
    DeRef(_bbsym_43053);
    _bbsym_43053 = _sym_42973;
    goto LF; // [384] 398
LE: 

    /** c_decl.e:466						bbsym = SymTab[int]*/
    DeRef(_bbsym_43053);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _bbsym_43053 = (object)*(((s1_ptr)_2)->base + _int_42972);
    Ref(_bbsym_43053);
LF: 

    /** c_decl.e:468					int = bbsym[S_MODE]*/
    _2 = (object)SEQ_PTR(_bbsym_43053);
    _int_42972 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_int_42972))
    _int_42972 = (object)DBL_PTR(_int_42972)->dbl;

    /** c_decl.e:469					if int = M_TEMP then*/
    if (_int_42972 != 3)
    goto L10; // [412] 447

    /** c_decl.e:470						int = bbsym[S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_bbsym_43053);
    _int_42972 = (object)*(((s1_ptr)_2)->base + 34);
    if (!IS_ATOM_INT(_int_42972))
    _int_42972 = (object)DBL_PTR(_int_42972)->dbl;

    /** c_decl.e:471						if int = tn then*/
    if (_int_42972 != _tn_42971)
    goto L11; // [426] 446

    /** c_decl.e:472							found = TRUE*/
    _found_42969 = _9TRUE_446;

    /** c_decl.e:473							exit*/
    DeRefDS(_bbsym_43053);
    _bbsym_43053 = NOVALUE;
    goto LD; // [443] 460
L11: 
L10: 

    /** c_decl.e:476					i += 1*/
    _i_42970 = _i_42970 + 1;
    DeRef(_bbsym_43053);
    _bbsym_43053 = NOVALUE;

    /** c_decl.e:477				end while*/
    goto LC; // [457] 346
LD: 
    goto L12; // [462] 889
L4: 

    /** c_decl.e:479				if t != TYPE_NULL then*/
    if (_t_42965 == 0)
    goto L13; // [469] 824

    /** c_decl.e:480					if not Initializing then*/
    if (_12Initializing_20307 != 0)
    goto L14; // [477] 500

    /** c_decl.e:481						sym[S_GTYPE_NEW] = or_type(sym[S_GTYPE_NEW], t)*/
    _2 = (object)SEQ_PTR(_sym_42973);
    _22553 = (object)*(((s1_ptr)_2)->base + 38);
    Ref(_22553);
    _22554 = _57or_type(_22553, _t_42965);
    _22553 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22554;
    if( _1 != _22554 ){
        DeRef(_1);
    }
    _22554 = NOVALUE;
L14: 

    /** c_decl.e:484					if t = TYPE_SEQUENCE then*/
    if (_t_42965 != 8)
    goto L15; // [504] 633

    /** c_decl.e:485						sym[S_SEQ_ELEM_NEW] =*/
    _2 = (object)SEQ_PTR(_sym_42973);
    _22556 = (object)*(((s1_ptr)_2)->base + 40);
    Ref(_22556);
    _22557 = _57or_type(_22556, _etype_42967);
    _22556 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22557;
    if( _1 != _22557 ){
        DeRef(_1);
    }
    _22557 = NOVALUE;

    /** c_decl.e:488						if val[MIN] != -1 then*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22558 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _22558, -1)){
        _22558 = NOVALUE;
        goto L16; // [535] 823
    }
    _22558 = NOVALUE;

    /** c_decl.e:489							if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_42973);
    _22560 = (object)*(((s1_ptr)_2)->base + 39);
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _22561 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22561 = - _12NOVALUE_20081;
        }
    }
    else {
        _22561 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    if (binary_op_a(NOTEQ, _22560, _22561)){
        _22560 = NOVALUE;
        DeRef(_22561);
        _22561 = NOVALUE;
        goto L17; // [552] 599
    }
    _22560 = NOVALUE;
    DeRef(_22561);
    _22561 = NOVALUE;

    /** c_decl.e:490								if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22563 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22563, 0)){
        _22563 = NOVALUE;
        goto L18; // [564] 581
    }
    _22563 = NOVALUE;

    /** c_decl.e:491									sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
    goto L16; // [578] 823
L18: 

    /** c_decl.e:493									sym[S_SEQ_LEN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22565 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22565);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22565;
    if( _1 != _22565 ){
        DeRef(_1);
    }
    _22565 = NOVALUE;
    goto L16; // [596] 823
L17: 

    /** c_decl.e:495							elsif val[MIN] != sym[S_SEQ_LEN_NEW] then*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22566 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_sym_42973);
    _22567 = (object)*(((s1_ptr)_2)->base + 39);
    if (binary_op_a(EQUALS, _22566, _22567)){
        _22566 = NOVALUE;
        _22567 = NOVALUE;
        goto L16; // [613] 823
    }
    _22566 = NOVALUE;
    _22567 = NOVALUE;

    /** c_decl.e:496								sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
    goto L16; // [630] 823
L15: 

    /** c_decl.e:500					elsif t = TYPE_INTEGER then*/
    if (_t_42965 != 1)
    goto L19; // [637] 774

    /** c_decl.e:502						if sym[S_OBJ_MIN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_42973);
    _22570 = (object)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _22571 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22571 = - _12NOVALUE_20081;
        }
    }
    else {
        _22571 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    if (binary_op_a(NOTEQ, _22570, _22571)){
        _22570 = NOVALUE;
        DeRef(_22571);
        _22571 = NOVALUE;
        goto L1A; // [654] 689
    }
    _22570 = NOVALUE;
    DeRef(_22571);
    _22571 = NOVALUE;

    /** c_decl.e:504							sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22573 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22573);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22573;
    if( _1 != _22573 ){
        DeRef(_1);
    }
    _22573 = NOVALUE;

    /** c_decl.e:505							sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22574 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_22574);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22574;
    if( _1 != _22574 ){
        DeRef(_1);
    }
    _22574 = NOVALUE;
    goto L16; // [686] 823
L1A: 

    /** c_decl.e:507						elsif sym[S_OBJ_MIN_NEW] != NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_42973);
    _22575 = (object)*(((s1_ptr)_2)->base + 41);
    if (binary_op_a(EQUALS, _22575, _12NOVALUE_20081)){
        _22575 = NOVALUE;
        goto L16; // [699] 823
    }
    _22575 = NOVALUE;

    /** c_decl.e:509							if val[MIN] < sym[S_OBJ_MIN_NEW] then*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22577 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_sym_42973);
    _22578 = (object)*(((s1_ptr)_2)->base + 41);
    if (binary_op_a(GREATEREQ, _22577, _22578)){
        _22577 = NOVALUE;
        _22578 = NOVALUE;
        goto L1B; // [717] 736
    }
    _22577 = NOVALUE;
    _22578 = NOVALUE;

    /** c_decl.e:510								sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22580 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22580);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22580;
    if( _1 != _22580 ){
        DeRef(_1);
    }
    _22580 = NOVALUE;
L1B: 

    /** c_decl.e:512							if val[MAX] > sym[S_OBJ_MAX_NEW] then*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22581 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_sym_42973);
    _22582 = (object)*(((s1_ptr)_2)->base + 42);
    if (binary_op_a(LESSEQ, _22581, _22582)){
        _22581 = NOVALUE;
        _22582 = NOVALUE;
        goto L16; // [750] 823
    }
    _22581 = NOVALUE;
    _22582 = NOVALUE;

    /** c_decl.e:513								sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22584 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_22584);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22584;
    if( _1 != _22584 ){
        DeRef(_1);
    }
    _22584 = NOVALUE;
    goto L16; // [771] 823
L19: 

    /** c_decl.e:518						sym[S_OBJ_MIN_NEW] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** c_decl.e:519						if t = TYPE_OBJECT then*/
    if (_t_42965 != 16)
    goto L1C; // [788] 822

    /** c_decl.e:522							sym[S_SEQ_ELEM_NEW] =*/
    _2 = (object)SEQ_PTR(_sym_42973);
    _22586 = (object)*(((s1_ptr)_2)->base + 40);
    Ref(_22586);
    _22587 = _57or_type(_22586, _etype_42967);
    _22586 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22587;
    if( _1 != _22587 ){
        DeRef(_1);
    }
    _22587 = NOVALUE;

    /** c_decl.e:524							sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
L1C: 
L16: 
L13: 

    /** c_decl.e:529				i = 1*/
    _i_42970 = 1;

    /** c_decl.e:530				while i <= length(BB_info) do*/
L1D: 
    if (IS_SEQUENCE(_57BB_info_42586)){
            _22588 = SEQ_PTR(_57BB_info_42586)->length;
    }
    else {
        _22588 = 1;
    }
    if (_i_42970 > _22588)
    goto L1E; // [839] 888

    /** c_decl.e:531					int = BB_info[i][BB_VAR]*/
    _2 = (object)SEQ_PTR(_57BB_info_42586);
    _22590 = (object)*(((s1_ptr)_2)->base + _i_42970);
    _2 = (object)SEQ_PTR(_22590);
    _int_42972 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_42972)){
        _int_42972 = (object)DBL_PTR(_int_42972)->dbl;
    }
    _22590 = NOVALUE;

    /** c_decl.e:532					if int = s then*/
    if (_int_42972 != _s_42964)
    goto L1F; // [859] 877

    /** c_decl.e:533						found = TRUE*/
    _found_42969 = _9TRUE_446;

    /** c_decl.e:534						exit*/
    goto L1E; // [874] 888
L1F: 

    /** c_decl.e:536					i += 1*/
    _i_42970 = _i_42970 + 1;

    /** c_decl.e:537				end while*/
    goto L1D; // [885] 834
L1E: 
L12: 

    /** c_decl.e:541			if not found then*/
    if (_found_42969 != 0)
    goto L20; // [891] 907

    /** c_decl.e:543				BB_info = append(BB_info, repeat(0, 6))*/
    _22595 = Repeat(0, 6);
    RefDS(_22595);
    Append(&_57BB_info_42586, _57BB_info_42586, _22595);
    DeRefDS(_22595);
    _22595 = NOVALUE;
L20: 

    /** c_decl.e:546			if t = TYPE_NULL then*/
    if (_t_42965 != 0)
    goto L21; // [911] 949

    /** c_decl.e:547				if not found then*/
    if (_found_42969 != 0)
    goto L22; // [917] 1308

    /** c_decl.e:549					BB_info[i] = dummy_bb*/
    RefDS(_57dummy_bb_42953);
    _2 = (object)SEQ_PTR(_57BB_info_42586);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _57BB_info_42586 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_42970);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _57dummy_bb_42953;
    DeRef(_1);

    /** c_decl.e:550					BB_info[i][BB_VAR] = s*/
    _2 = (object)SEQ_PTR(_57BB_info_42586);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _57BB_info_42586 = MAKE_SEQ(_2);
    }
    _3 = (object)(_i_42970 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_42964;
    DeRef(_1);
    _22599 = NOVALUE;
    goto L22; // [946] 1308
L21: 

    /** c_decl.e:554				sequence bbi = BB_info[i]*/
    DeRef(_bbi_43189);
    _2 = (object)SEQ_PTR(_57BB_info_42586);
    _bbi_43189 = (object)*(((s1_ptr)_2)->base + _i_42970);
    Ref(_bbi_43189);

    /** c_decl.e:555				BB_info[i] = 0*/
    _2 = (object)SEQ_PTR(_57BB_info_42586);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _57BB_info_42586 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_42970);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:556				bbi[BB_VAR] = s*/
    _2 = (object)SEQ_PTR(_bbi_43189);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43189 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_42964;
    DeRef(_1);

    /** c_decl.e:557				bbi[BB_TYPE] = t*/
    _2 = (object)SEQ_PTR(_bbi_43189);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43189 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_42965;
    DeRef(_1);

    /** c_decl.e:558				bbi[BB_DELETE] = has_delete*/
    _2 = (object)SEQ_PTR(_bbi_43189);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43189 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _has_delete_42968;
    DeRef(_1);

    /** c_decl.e:560				if t = TYPE_SEQUENCE and val[MIN] = -1 then*/
    _22602 = (_t_42965 == 8);
    if (_22602 == 0) {
        goto L23; // [995] 1077
    }
    _2 = (object)SEQ_PTR(_val_42966);
    _22604 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_22604)) {
        _22605 = (_22604 == -1);
    }
    else {
        _22605 = binary_op(EQUALS, _22604, -1);
    }
    _22604 = NOVALUE;
    if (_22605 == 0) {
        DeRef(_22605);
        _22605 = NOVALUE;
        goto L23; // [1010] 1077
    }
    else {
        if (!IS_ATOM_INT(_22605) && DBL_PTR(_22605)->dbl == 0.0){
            DeRef(_22605);
            _22605 = NOVALUE;
            goto L23; // [1010] 1077
        }
        DeRef(_22605);
        _22605 = NOVALUE;
    }
    DeRef(_22605);
    _22605 = NOVALUE;

    /** c_decl.e:562					if found and bbi[BB_ELEM] != TYPE_NULL then*/
    if (_found_42969 == 0) {
        goto L24; // [1015] 1051
    }
    _2 = (object)SEQ_PTR(_bbi_43189);
    _22607 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_22607)) {
        _22608 = (_22607 != 0);
    }
    else {
        _22608 = binary_op(NOTEQ, _22607, 0);
    }
    _22607 = NOVALUE;
    if (_22608 == 0) {
        DeRef(_22608);
        _22608 = NOVALUE;
        goto L24; // [1030] 1051
    }
    else {
        if (!IS_ATOM_INT(_22608) && DBL_PTR(_22608)->dbl == 0.0){
            DeRef(_22608);
            _22608 = NOVALUE;
            goto L24; // [1030] 1051
        }
        DeRef(_22608);
        _22608 = NOVALUE;
    }
    DeRef(_22608);
    _22608 = NOVALUE;

    /** c_decl.e:564						bbi[BB_ELEM] = or_type(bbi[BB_ELEM], etype)*/
    _2 = (object)SEQ_PTR(_bbi_43189);
    _22609 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_22609);
    _22610 = _57or_type(_22609, _etype_42967);
    _22609 = NOVALUE;
    _2 = (object)SEQ_PTR(_bbi_43189);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43189 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22610;
    if( _1 != _22610 ){
        DeRef(_1);
    }
    _22610 = NOVALUE;
    goto L25; // [1048] 1060
L24: 

    /** c_decl.e:566						bbi[BB_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_bbi_43189);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43189 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
L25: 

    /** c_decl.e:568					if not found then*/
    if (_found_42969 != 0)
    goto L26; // [1062] 1153

    /** c_decl.e:569						bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_bbi_43189);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43189 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
    goto L26; // [1074] 1153
L23: 

    /** c_decl.e:572					bbi[BB_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_bbi_43189);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43189 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_42967;
    DeRef(_1);

    /** c_decl.e:573					if t = TYPE_SEQUENCE or t = TYPE_OBJECT then*/
    _22612 = (_t_42965 == 8);
    if (_22612 != 0) {
        goto L27; // [1091] 1106
    }
    _22614 = (_t_42965 == 16);
    if (_22614 == 0)
    {
        DeRef(_22614);
        _22614 = NOVALUE;
        goto L28; // [1102] 1145
    }
    else{
        DeRef(_22614);
        _22614 = NOVALUE;
    }
L27: 

    /** c_decl.e:574						if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22615 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22615, 0)){
        _22615 = NOVALUE;
        goto L29; // [1114] 1129
    }
    _22615 = NOVALUE;

    /** c_decl.e:575							bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_bbi_43189);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43189 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
    goto L2A; // [1126] 1152
L29: 

    /** c_decl.e:577							bbi[BB_SEQLEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22617 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22617);
    _2 = (object)SEQ_PTR(_bbi_43189);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43189 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22617;
    if( _1 != _22617 ){
        DeRef(_1);
    }
    _22617 = NOVALUE;
    goto L2A; // [1142] 1152
L28: 

    /** c_decl.e:580						bbi[BB_OBJ] = val*/
    RefDS(_val_42966);
    _2 = (object)SEQ_PTR(_bbi_43189);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43189 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _val_42966;
    DeRef(_1);
L2A: 
L26: 

    /** c_decl.e:583				BB_info[i] = bbi*/
    RefDS(_bbi_43189);
    _2 = (object)SEQ_PTR(_57BB_info_42586);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _57BB_info_42586 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_42970);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _bbi_43189;
    DeRef(_1);
    DeRefDS(_bbi_43189);
    _bbi_43189 = NOVALUE;
    goto L22; // [1164] 1308
L3: 

    /** c_decl.e:586		elsif mode = M_CONSTANT then*/
    if (_mode_42978 != 2)
    goto L2B; // [1171] 1307

    /** c_decl.e:587			sym[S_GTYPE] = t*/
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_42965;
    DeRef(_1);

    /** c_decl.e:588			sym[S_SEQ_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_42967;
    DeRef(_1);

    /** c_decl.e:589			if sym[S_GTYPE] = TYPE_SEQUENCE or*/
    _2 = (object)SEQ_PTR(_sym_42973);
    _22619 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22619)) {
        _22620 = (_22619 == 8);
    }
    else {
        _22620 = binary_op(EQUALS, _22619, 8);
    }
    _22619 = NOVALUE;
    if (IS_ATOM_INT(_22620)) {
        if (_22620 != 0) {
            goto L2C; // [1205] 1226
        }
    }
    else {
        if (DBL_PTR(_22620)->dbl != 0.0) {
            goto L2C; // [1205] 1226
        }
    }
    _2 = (object)SEQ_PTR(_sym_42973);
    _22622 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22622)) {
        _22623 = (_22622 == 16);
    }
    else {
        _22623 = binary_op(EQUALS, _22622, 16);
    }
    _22622 = NOVALUE;
    if (_22623 == 0) {
        DeRef(_22623);
        _22623 = NOVALUE;
        goto L2D; // [1222] 1269
    }
    else {
        if (!IS_ATOM_INT(_22623) && DBL_PTR(_22623)->dbl == 0.0){
            DeRef(_22623);
            _22623 = NOVALUE;
            goto L2D; // [1222] 1269
        }
        DeRef(_22623);
        _22623 = NOVALUE;
    }
    DeRef(_22623);
    _22623 = NOVALUE;
L2C: 

    /** c_decl.e:591				if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22624 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22624, 0)){
        _22624 = NOVALUE;
        goto L2E; // [1234] 1251
    }
    _22624 = NOVALUE;

    /** c_decl.e:592					sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
    goto L2F; // [1248] 1298
L2E: 

    /** c_decl.e:594					sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22626 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22626);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22626;
    if( _1 != _22626 ){
        DeRef(_1);
    }
    _22626 = NOVALUE;
    goto L2F; // [1266] 1298
L2D: 

    /** c_decl.e:597				sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22627 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22627);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22627;
    if( _1 != _22627 ){
        DeRef(_1);
    }
    _22627 = NOVALUE;

    /** c_decl.e:598				sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_42966);
    _22628 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_22628);
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22628;
    if( _1 != _22628 ){
        DeRef(_1);
    }
    _22628 = NOVALUE;
L2F: 

    /** c_decl.e:600			sym[S_HAS_DELETE] = has_delete*/
    _2 = (object)SEQ_PTR(_sym_42973);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42973 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 54);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _has_delete_42968;
    DeRef(_1);
L2B: 
L22: 

    /** c_decl.e:603		SymTab[s] = sym*/
    RefDS(_sym_42973);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_42964);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_42973;
    DeRef(_1);

    /** c_decl.e:605	end procedure*/
    DeRefDS(_val_42966);
    DeRefDS(_sym_42973);
    DeRef(_22517);
    _22517 = NOVALUE;
    _22531 = NOVALUE;
    DeRef(_22612);
    _22612 = NOVALUE;
    DeRef(_22522);
    _22522 = NOVALUE;
    DeRef(_22602);
    _22602 = NOVALUE;
    _22536 = NOVALUE;
    DeRef(_22620);
    _22620 = NOVALUE;
    return;
    ;
}


void _57CName(object _s_43263)
{
    object _v_43264 = NOVALUE;
    object _mode_43266 = NOVALUE;
    object _22693 = NOVALUE;
    object _22692 = NOVALUE;
    object _22690 = NOVALUE;
    object _22689 = NOVALUE;
    object _22688 = NOVALUE;
    object _22687 = NOVALUE;
    object _22686 = NOVALUE;
    object _22685 = NOVALUE;
    object _22684 = NOVALUE;
    object _22683 = NOVALUE;
    object _22681 = NOVALUE;
    object _22679 = NOVALUE;
    object _22678 = NOVALUE;
    object _22677 = NOVALUE;
    object _22676 = NOVALUE;
    object _22675 = NOVALUE;
    object _22674 = NOVALUE;
    object _22672 = NOVALUE;
    object _22671 = NOVALUE;
    object _22670 = NOVALUE;
    object _22669 = NOVALUE;
    object _22668 = NOVALUE;
    object _22666 = NOVALUE;
    object _22665 = NOVALUE;
    object _22664 = NOVALUE;
    object _22663 = NOVALUE;
    object _22662 = NOVALUE;
    object _22661 = NOVALUE;
    object _22659 = NOVALUE;
    object _22658 = NOVALUE;
    object _22656 = NOVALUE;
    object _22655 = NOVALUE;
    object _22654 = NOVALUE;
    object _22653 = NOVALUE;
    object _22652 = NOVALUE;
    object _22651 = NOVALUE;
    object _22650 = NOVALUE;
    object _22649 = NOVALUE;
    object _22648 = NOVALUE;
    object _22647 = NOVALUE;
    object _22646 = NOVALUE;
    object _22645 = NOVALUE;
    object _22643 = NOVALUE;
    object _22642 = NOVALUE;
    object _22638 = NOVALUE;
    object _22637 = NOVALUE;
    object _22636 = NOVALUE;
    object _22635 = NOVALUE;
    object _22634 = NOVALUE;
    object _22633 = NOVALUE;
    object _22630 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_43263)) {
        _1 = (object)(DBL_PTR(_s_43263)->dbl);
        DeRefDS(_s_43263);
        _s_43263 = _1;
    }

    /** c_decl.e:612		v = ObjValue(s)*/
    _0 = _v_43264;
    _v_43264 = _57ObjValue(_s_43263);
    DeRef(_0);

    /** c_decl.e:613		integer mode = SymTab[s][S_MODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22630 = (object)*(((s1_ptr)_2)->base + _s_43263);
    _2 = (object)SEQ_PTR(_22630);
    _mode_43266 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_43266)){
        _mode_43266 = (object)DBL_PTR(_mode_43266)->dbl;
    }
    _22630 = NOVALUE;

    /** c_decl.e:614	 	if mode = M_NORMAL then*/
    if (_mode_43266 != 1)
    goto L1; // [29] 254

    /** c_decl.e:617			if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22633 = (_57LeftSym_42587 == _9FALSE_444);
    if (_22633 == 0) {
        _22634 = 0;
        goto L2; // [43] 61
    }
    _22635 = _57GType(_s_43263);
    if (IS_ATOM_INT(_22635)) {
        _22636 = (_22635 == 1);
    }
    else {
        _22636 = binary_op(EQUALS, _22635, 1);
    }
    DeRef(_22635);
    _22635 = NOVALUE;
    if (IS_ATOM_INT(_22636))
    _22634 = (_22636 != 0);
    else
    _22634 = DBL_PTR(_22636)->dbl != 0.0;
L2: 
    if (_22634 == 0) {
        goto L3; // [61] 98
    }
    if (IS_ATOM_INT(_v_43264) && IS_ATOM_INT(_12NOVALUE_20081)) {
        _22638 = (_v_43264 != _12NOVALUE_20081);
    }
    else {
        _22638 = binary_op(NOTEQ, _v_43264, _12NOVALUE_20081);
    }
    if (_22638 == 0) {
        DeRef(_22638);
        _22638 = NOVALUE;
        goto L3; // [72] 98
    }
    else {
        if (!IS_ATOM_INT(_22638) && DBL_PTR(_22638)->dbl == 0.0){
            DeRef(_22638);
            _22638 = NOVALUE;
            goto L3; // [72] 98
        }
        DeRef(_22638);
        _22638 = NOVALUE;
    }
    DeRef(_22638);
    _22638 = NOVALUE;

    /** c_decl.e:618				c_printf("%d", v)*/
    RefDS(_22639);
    Ref(_v_43264);
    _54c_printf(_22639, _v_43264);

    /** c_decl.e:619				if TARGET_SIZEOF_POINTER = 8 then*/
    goto L4; // [95] 180
L3: 

    /** c_decl.e:623				if SymTab[s][S_SCOPE] > SC_PRIVATE then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22642 = (object)*(((s1_ptr)_2)->base + _s_43263);
    _2 = (object)SEQ_PTR(_22642);
    _22643 = (object)*(((s1_ptr)_2)->base + 4);
    _22642 = NOVALUE;
    if (binary_op_a(LESSEQ, _22643, 3)){
        _22643 = NOVALUE;
        goto L5; // [114] 156
    }
    _22643 = NOVALUE;

    /** c_decl.e:624					c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22645 = (object)*(((s1_ptr)_2)->base + _s_43263);
    _2 = (object)SEQ_PTR(_22645);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _22646 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _22646 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _22645 = NOVALUE;
    RefDS(_22138);
    Ref(_22646);
    _54c_printf(_22138, _22646);
    _22646 = NOVALUE;

    /** c_decl.e:625					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22647 = (object)*(((s1_ptr)_2)->base + _s_43263);
    _2 = (object)SEQ_PTR(_22647);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _22648 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _22648 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _22647 = NOVALUE;
    Ref(_22648);
    _54c_puts(_22648);
    _22648 = NOVALUE;
    goto L6; // [153] 179
L5: 

    /** c_decl.e:627					c_puts("_")*/
    RefDS(_22087);
    _54c_puts(_22087);

    /** c_decl.e:628					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22649 = (object)*(((s1_ptr)_2)->base + _s_43263);
    _2 = (object)SEQ_PTR(_22649);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _22650 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _22650 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _22649 = NOVALUE;
    Ref(_22650);
    _54c_puts(_22650);
    _22650 = NOVALUE;
L6: 
L4: 

    /** c_decl.e:631			if s != CurrentSub and SymTab[s][S_NREFS] < 2 then*/
    _22651 = (_s_43263 != _12CurrentSub_20234);
    if (_22651 == 0) {
        goto L7; // [188] 236
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22653 = (object)*(((s1_ptr)_2)->base + _s_43263);
    _2 = (object)SEQ_PTR(_22653);
    _22654 = (object)*(((s1_ptr)_2)->base + 12);
    _22653 = NOVALUE;
    if (IS_ATOM_INT(_22654)) {
        _22655 = (_22654 < 2);
    }
    else {
        _22655 = binary_op(LESS, _22654, 2);
    }
    _22654 = NOVALUE;
    if (_22655 == 0) {
        DeRef(_22655);
        _22655 = NOVALUE;
        goto L7; // [209] 236
    }
    else {
        if (!IS_ATOM_INT(_22655) && DBL_PTR(_22655)->dbl == 0.0){
            DeRef(_22655);
            _22655 = NOVALUE;
            goto L7; // [209] 236
        }
        DeRef(_22655);
        _22655 = NOVALUE;
    }
    DeRef(_22655);
    _22655 = NOVALUE;

    /** c_decl.e:632				SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_43263 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _22658 = (object)*(((s1_ptr)_2)->base + 12);
    _22656 = NOVALUE;
    if (IS_ATOM_INT(_22658)) {
        _22659 = _22658 + 1;
        if (_22659 > MAXINT){
            _22659 = NewDouble((eudouble)_22659);
        }
    }
    else
    _22659 = binary_op(PLUS, 1, _22658);
    _22658 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22659;
    if( _1 != _22659 ){
        DeRef(_1);
    }
    _22659 = NOVALUE;
    _22656 = NOVALUE;
L7: 

    /** c_decl.e:634			SetBBType(s, TYPE_NULL, novalue, TYPE_OBJECT, 0) -- record that this var was referenced in this BB*/
    RefDS(_54novalue_46654);
    _57SetBBType(_s_43263, 0, _54novalue_46654, 16, 0);
    goto L8; // [251] 533
L1: 

    /** c_decl.e:636	 	elsif mode = M_CONSTANT then*/
    if (_mode_43266 != 2)
    goto L9; // [258] 448

    /** c_decl.e:638			if (is_integer( sym_obj( s ) ) and SymTab[s][S_GTYPE] != TYPE_DOUBLE ) or (LeftSym = FALSE and TypeIs(s, TYPE_INTEGER) and v != NOVALUE) then*/
    _22661 = _53sym_obj(_s_43263);
    _22662 = _12is_integer(_22661);
    _22661 = NOVALUE;
    if (IS_ATOM_INT(_22662)) {
        if (_22662 == 0) {
            DeRef(_22663);
            _22663 = 0;
            goto LA; // [272] 298
        }
    }
    else {
        if (DBL_PTR(_22662)->dbl == 0.0) {
            DeRef(_22663);
            _22663 = 0;
            goto LA; // [272] 298
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22664 = (object)*(((s1_ptr)_2)->base + _s_43263);
    _2 = (object)SEQ_PTR(_22664);
    _22665 = (object)*(((s1_ptr)_2)->base + 36);
    _22664 = NOVALUE;
    if (IS_ATOM_INT(_22665)) {
        _22666 = (_22665 != 2);
    }
    else {
        _22666 = binary_op(NOTEQ, _22665, 2);
    }
    _22665 = NOVALUE;
    DeRef(_22663);
    if (IS_ATOM_INT(_22666))
    _22663 = (_22666 != 0);
    else
    _22663 = DBL_PTR(_22666)->dbl != 0.0;
LA: 
    if (_22663 != 0) {
        goto LB; // [298] 344
    }
    _22668 = (_57LeftSym_42587 == _9FALSE_444);
    if (_22668 == 0) {
        _22669 = 0;
        goto LC; // [310] 325
    }
    _22670 = _57TypeIs(_s_43263, 1);
    if (IS_ATOM_INT(_22670))
    _22669 = (_22670 != 0);
    else
    _22669 = DBL_PTR(_22670)->dbl != 0.0;
LC: 
    if (_22669 == 0) {
        DeRef(_22671);
        _22671 = 0;
        goto LD; // [325] 339
    }
    if (IS_ATOM_INT(_v_43264) && IS_ATOM_INT(_12NOVALUE_20081)) {
        _22672 = (_v_43264 != _12NOVALUE_20081);
    }
    else {
        _22672 = binary_op(NOTEQ, _v_43264, _12NOVALUE_20081);
    }
    if (IS_ATOM_INT(_22672))
    _22671 = (_22672 != 0);
    else
    _22671 = DBL_PTR(_22672)->dbl != 0.0;
LD: 
    if (_22671 == 0)
    {
        _22671 = NOVALUE;
        goto LE; // [340] 367
    }
    else{
        _22671 = NOVALUE;
    }
LB: 

    /** c_decl.e:641				c_printf("%d", v)*/
    RefDS(_22639);
    Ref(_v_43264);
    _54c_printf(_22639, _v_43264);

    /** c_decl.e:642				if TARGET_SIZEOF_POINTER = 8 then*/
    goto L8; // [364] 533
LE: 

    /** c_decl.e:647				c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22674 = (object)*(((s1_ptr)_2)->base + _s_43263);
    _2 = (object)SEQ_PTR(_22674);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _22675 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _22675 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _22674 = NOVALUE;
    RefDS(_22138);
    Ref(_22675);
    _54c_printf(_22138, _22675);
    _22675 = NOVALUE;

    /** c_decl.e:648				c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22676 = (object)*(((s1_ptr)_2)->base + _s_43263);
    _2 = (object)SEQ_PTR(_22676);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _22677 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _22677 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _22676 = NOVALUE;
    Ref(_22677);
    _54c_puts(_22677);
    _22677 = NOVALUE;

    /** c_decl.e:649				if SymTab[s][S_NREFS] < 2 then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22678 = (object)*(((s1_ptr)_2)->base + _s_43263);
    _2 = (object)SEQ_PTR(_22678);
    _22679 = (object)*(((s1_ptr)_2)->base + 12);
    _22678 = NOVALUE;
    if (binary_op_a(GREATEREQ, _22679, 2)){
        _22679 = NOVALUE;
        goto L8; // [416] 533
    }
    _22679 = NOVALUE;

    /** c_decl.e:650					SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_43263 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _22683 = (object)*(((s1_ptr)_2)->base + 12);
    _22681 = NOVALUE;
    if (IS_ATOM_INT(_22683)) {
        _22684 = _22683 + 1;
        if (_22684 > MAXINT){
            _22684 = NewDouble((eudouble)_22684);
        }
    }
    else
    _22684 = binary_op(PLUS, 1, _22683);
    _22683 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22684;
    if( _1 != _22684 ){
        DeRef(_1);
    }
    _22684 = NOVALUE;
    _22681 = NOVALUE;
    goto L8; // [445] 533
L9: 

    /** c_decl.e:656			if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22685 = (_57LeftSym_42587 == _9FALSE_444);
    if (_22685 == 0) {
        _22686 = 0;
        goto LF; // [458] 476
    }
    _22687 = _57GType(_s_43263);
    if (IS_ATOM_INT(_22687)) {
        _22688 = (_22687 == 1);
    }
    else {
        _22688 = binary_op(EQUALS, _22687, 1);
    }
    DeRef(_22687);
    _22687 = NOVALUE;
    if (IS_ATOM_INT(_22688))
    _22686 = (_22688 != 0);
    else
    _22686 = DBL_PTR(_22688)->dbl != 0.0;
LF: 
    if (_22686 == 0) {
        goto L10; // [476] 513
    }
    if (IS_ATOM_INT(_v_43264) && IS_ATOM_INT(_12NOVALUE_20081)) {
        _22690 = (_v_43264 != _12NOVALUE_20081);
    }
    else {
        _22690 = binary_op(NOTEQ, _v_43264, _12NOVALUE_20081);
    }
    if (_22690 == 0) {
        DeRef(_22690);
        _22690 = NOVALUE;
        goto L10; // [487] 513
    }
    else {
        if (!IS_ATOM_INT(_22690) && DBL_PTR(_22690)->dbl == 0.0){
            DeRef(_22690);
            _22690 = NOVALUE;
            goto L10; // [487] 513
        }
        DeRef(_22690);
        _22690 = NOVALUE;
    }
    DeRef(_22690);
    _22690 = NOVALUE;

    /** c_decl.e:657				c_printf("%d", v)*/
    RefDS(_22639);
    Ref(_v_43264);
    _54c_printf(_22639, _v_43264);

    /** c_decl.e:658				if TARGET_SIZEOF_POINTER = 8 then*/
    goto L11; // [510] 532
L10: 

    /** c_decl.e:662				c_printf("_%d", SymTab[s][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22692 = (object)*(((s1_ptr)_2)->base + _s_43263);
    _2 = (object)SEQ_PTR(_22692);
    _22693 = (object)*(((s1_ptr)_2)->base + 34);
    _22692 = NOVALUE;
    RefDS(_22138);
    Ref(_22693);
    _54c_printf(_22138, _22693);
    _22693 = NOVALUE;
L11: 
L8: 

    /** c_decl.e:666		LeftSym = FALSE*/
    _57LeftSym_42587 = _9FALSE_444;

    /** c_decl.e:667	end procedure*/
    DeRef(_v_43264);
    DeRef(_22688);
    _22688 = NOVALUE;
    DeRef(_22672);
    _22672 = NOVALUE;
    DeRef(_22670);
    _22670 = NOVALUE;
    DeRef(_22633);
    _22633 = NOVALUE;
    DeRef(_22685);
    _22685 = NOVALUE;
    DeRef(_22666);
    _22666 = NOVALUE;
    DeRef(_22662);
    _22662 = NOVALUE;
    DeRef(_22651);
    _22651 = NOVALUE;
    DeRef(_22668);
    _22668 = NOVALUE;
    DeRef(_22636);
    _22636 = NOVALUE;
    return;
    ;
}


void _57c_stmt(object _stmt_43411, object _arg_43412, object _lhs_arg_43414)
{
    object _argcount_43415 = NOVALUE;
    object _i_43416 = NOVALUE;
    object _22748 = NOVALUE;
    object _22747 = NOVALUE;
    object _22746 = NOVALUE;
    object _22745 = NOVALUE;
    object _22744 = NOVALUE;
    object _22743 = NOVALUE;
    object _22742 = NOVALUE;
    object _22741 = NOVALUE;
    object _22740 = NOVALUE;
    object _22739 = NOVALUE;
    object _22738 = NOVALUE;
    object _22737 = NOVALUE;
    object _22736 = NOVALUE;
    object _22735 = NOVALUE;
    object _22734 = NOVALUE;
    object _22733 = NOVALUE;
    object _22732 = NOVALUE;
    object _22730 = NOVALUE;
    object _22728 = NOVALUE;
    object _22726 = NOVALUE;
    object _22725 = NOVALUE;
    object _22724 = NOVALUE;
    object _22723 = NOVALUE;
    object _22721 = NOVALUE;
    object _22720 = NOVALUE;
    object _22719 = NOVALUE;
    object _22718 = NOVALUE;
    object _22717 = NOVALUE;
    object _22716 = NOVALUE;
    object _22715 = NOVALUE;
    object _22714 = NOVALUE;
    object _22713 = NOVALUE;
    object _22712 = NOVALUE;
    object _22711 = NOVALUE;
    object _22710 = NOVALUE;
    object _22709 = NOVALUE;
    object _22708 = NOVALUE;
    object _22705 = NOVALUE;
    object _22704 = NOVALUE;
    object _22703 = NOVALUE;
    object _22702 = NOVALUE;
    object _22701 = NOVALUE;
    object _22700 = NOVALUE;
    object _22698 = NOVALUE;
    object _22696 = NOVALUE;
    object _22695 = NOVALUE;
    object _22694 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_lhs_arg_43414)) {
        _1 = (object)(DBL_PTR(_lhs_arg_43414)->dbl);
        DeRefDS(_lhs_arg_43414);
        _lhs_arg_43414 = _1;
    }

    /** c_decl.e:675		if LAST_PASS = TRUE and Initializing = FALSE then*/
    _22694 = (_57LAST_PASS_42577 == _9TRUE_446);
    if (_22694 == 0) {
        goto L1; // [15] 47
    }
    _22696 = (_12Initializing_20307 == _9FALSE_444);
    if (_22696 == 0)
    {
        DeRef(_22696);
        _22696 = NOVALUE;
        goto L1; // [28] 47
    }
    else{
        DeRef(_22696);
        _22696 = NOVALUE;
    }

    /** c_decl.e:676			cfile_size += 1*/
    _12cfile_size_20306 = _12cfile_size_20306 + 1;

    /** c_decl.e:677			update_checksum( stmt )*/
    RefDS(_stmt_43411);
    _55update_checksum(_stmt_43411);
L1: 

    /** c_decl.e:681		if emit_c_output then*/
    if (_54emit_c_output_46647 == 0)
    {
        goto L2; // [51] 60
    }
    else{
    }

    /** c_decl.e:682			adjust_indent_before(stmt)*/
    RefDS(_stmt_43411);
    _54adjust_indent_before(_stmt_43411);
L2: 

    /** c_decl.e:685		if atom(arg) then*/
    _22698 = IS_ATOM(_arg_43412);
    if (_22698 == 0)
    {
        _22698 = NOVALUE;
        goto L3; // [65] 75
    }
    else{
        _22698 = NOVALUE;
    }

    /** c_decl.e:686			arg = {arg}*/
    _0 = _arg_43412;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_arg_43412);
    ((intptr_t*)_2)[1] = _arg_43412;
    _arg_43412 = MAKE_SEQ(_1);
    DeRef(_0);
L3: 

    /** c_decl.e:689		argcount = 1*/
    _argcount_43415 = 1;

    /** c_decl.e:690		i = 1*/
    _i_43416 = 1;

    /** c_decl.e:691		while i <= length(stmt) and length(stmt) > 0 do*/
L4: 
    if (IS_SEQUENCE(_stmt_43411)){
            _22700 = SEQ_PTR(_stmt_43411)->length;
    }
    else {
        _22700 = 1;
    }
    _22701 = (_i_43416 <= _22700);
    _22700 = NOVALUE;
    if (_22701 == 0) {
        goto L5; // [97] 435
    }
    if (IS_SEQUENCE(_stmt_43411)){
            _22703 = SEQ_PTR(_stmt_43411)->length;
    }
    else {
        _22703 = 1;
    }
    _22704 = (_22703 > 0);
    _22703 = NOVALUE;
    if (_22704 == 0)
    {
        DeRef(_22704);
        _22704 = NOVALUE;
        goto L5; // [109] 435
    }
    else{
        DeRef(_22704);
        _22704 = NOVALUE;
    }

    /** c_decl.e:692			if stmt[i] = '@' then*/
    _2 = (object)SEQ_PTR(_stmt_43411);
    _22705 = (object)*(((s1_ptr)_2)->base + _i_43416);
    if (binary_op_a(NOTEQ, _22705, 64)){
        _22705 = NOVALUE;
        goto L6; // [118] 288
    }
    _22705 = NOVALUE;

    /** c_decl.e:694				if i = 1 then*/
    if (_i_43416 != 1)
    goto L7; // [124] 138

    /** c_decl.e:695					LeftSym = TRUE*/
    _57LeftSym_42587 = _9TRUE_446;
L7: 

    /** c_decl.e:698				if i < length(stmt) and stmt[i+1] > '0' and stmt[i+1] <= '9' then*/
    if (IS_SEQUENCE(_stmt_43411)){
            _22708 = SEQ_PTR(_stmt_43411)->length;
    }
    else {
        _22708 = 1;
    }
    _22709 = (_i_43416 < _22708);
    _22708 = NOVALUE;
    if (_22709 == 0) {
        _22710 = 0;
        goto L8; // [147] 167
    }
    _22711 = _i_43416 + 1;
    _2 = (object)SEQ_PTR(_stmt_43411);
    _22712 = (object)*(((s1_ptr)_2)->base + _22711);
    if (IS_ATOM_INT(_22712)) {
        _22713 = (_22712 > 48);
    }
    else {
        _22713 = binary_op(GREATER, _22712, 48);
    }
    _22712 = NOVALUE;
    if (IS_ATOM_INT(_22713))
    _22710 = (_22713 != 0);
    else
    _22710 = DBL_PTR(_22713)->dbl != 0.0;
L8: 
    if (_22710 == 0) {
        goto L9; // [167] 249
    }
    _22715 = _i_43416 + 1;
    _2 = (object)SEQ_PTR(_stmt_43411);
    _22716 = (object)*(((s1_ptr)_2)->base + _22715);
    if (IS_ATOM_INT(_22716)) {
        _22717 = (_22716 <= 57);
    }
    else {
        _22717 = binary_op(LESSEQ, _22716, 57);
    }
    _22716 = NOVALUE;
    if (_22717 == 0) {
        DeRef(_22717);
        _22717 = NOVALUE;
        goto L9; // [184] 249
    }
    else {
        if (!IS_ATOM_INT(_22717) && DBL_PTR(_22717)->dbl == 0.0){
            DeRef(_22717);
            _22717 = NOVALUE;
            goto L9; // [184] 249
        }
        DeRef(_22717);
        _22717 = NOVALUE;
    }
    DeRef(_22717);
    _22717 = NOVALUE;

    /** c_decl.e:700					if arg[stmt[i+1]-'0'] = lhs_arg then*/
    _22718 = _i_43416 + 1;
    _2 = (object)SEQ_PTR(_stmt_43411);
    _22719 = (object)*(((s1_ptr)_2)->base + _22718);
    if (IS_ATOM_INT(_22719)) {
        _22720 = _22719 - 48;
    }
    else {
        _22720 = binary_op(MINUS, _22719, 48);
    }
    _22719 = NOVALUE;
    _2 = (object)SEQ_PTR(_arg_43412);
    if (!IS_ATOM_INT(_22720)){
        _22721 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22720)->dbl));
    }
    else{
        _22721 = (object)*(((s1_ptr)_2)->base + _22720);
    }
    if (binary_op_a(NOTEQ, _22721, _lhs_arg_43414)){
        _22721 = NOVALUE;
        goto LA; // [205] 219
    }
    _22721 = NOVALUE;

    /** c_decl.e:701						LeftSym = TRUE*/
    _57LeftSym_42587 = _9TRUE_446;
LA: 

    /** c_decl.e:703					CName(arg[stmt[i+1]-'0'])*/
    _22723 = _i_43416 + 1;
    _2 = (object)SEQ_PTR(_stmt_43411);
    _22724 = (object)*(((s1_ptr)_2)->base + _22723);
    if (IS_ATOM_INT(_22724)) {
        _22725 = _22724 - 48;
    }
    else {
        _22725 = binary_op(MINUS, _22724, 48);
    }
    _22724 = NOVALUE;
    _2 = (object)SEQ_PTR(_arg_43412);
    if (!IS_ATOM_INT(_22725)){
        _22726 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22725)->dbl));
    }
    else{
        _22726 = (object)*(((s1_ptr)_2)->base + _22725);
    }
    Ref(_22726);
    _57CName(_22726);
    _22726 = NOVALUE;

    /** c_decl.e:704					i += 1*/
    _i_43416 = _i_43416 + 1;
    goto LB; // [246] 279
L9: 

    /** c_decl.e:708					if arg[argcount] = lhs_arg then*/
    _2 = (object)SEQ_PTR(_arg_43412);
    _22728 = (object)*(((s1_ptr)_2)->base + _argcount_43415);
    if (binary_op_a(NOTEQ, _22728, _lhs_arg_43414)){
        _22728 = NOVALUE;
        goto LC; // [255] 269
    }
    _22728 = NOVALUE;

    /** c_decl.e:709						LeftSym = TRUE*/
    _57LeftSym_42587 = _9TRUE_446;
LC: 

    /** c_decl.e:711					CName(arg[argcount])*/
    _2 = (object)SEQ_PTR(_arg_43412);
    _22730 = (object)*(((s1_ptr)_2)->base + _argcount_43415);
    Ref(_22730);
    _57CName(_22730);
    _22730 = NOVALUE;
LB: 

    /** c_decl.e:714				argcount += 1*/
    _argcount_43415 = _argcount_43415 + 1;
    goto LD; // [285] 353
L6: 

    /** c_decl.e:717				c_putc(stmt[i])*/
    _2 = (object)SEQ_PTR(_stmt_43411);
    _22732 = (object)*(((s1_ptr)_2)->base + _i_43416);
    Ref(_22732);
    _54c_putc(_22732);
    _22732 = NOVALUE;

    /** c_decl.e:718				if stmt[i] = '&' and i < length(stmt) and stmt[i+1] = '@' then*/
    _2 = (object)SEQ_PTR(_stmt_43411);
    _22733 = (object)*(((s1_ptr)_2)->base + _i_43416);
    if (IS_ATOM_INT(_22733)) {
        _22734 = (_22733 == 38);
    }
    else {
        _22734 = binary_op(EQUALS, _22733, 38);
    }
    _22733 = NOVALUE;
    if (IS_ATOM_INT(_22734)) {
        if (_22734 == 0) {
            DeRef(_22735);
            _22735 = 0;
            goto LE; // [307] 322
        }
    }
    else {
        if (DBL_PTR(_22734)->dbl == 0.0) {
            DeRef(_22735);
            _22735 = 0;
            goto LE; // [307] 322
        }
    }
    if (IS_SEQUENCE(_stmt_43411)){
            _22736 = SEQ_PTR(_stmt_43411)->length;
    }
    else {
        _22736 = 1;
    }
    _22737 = (_i_43416 < _22736);
    _22736 = NOVALUE;
    DeRef(_22735);
    _22735 = (_22737 != 0);
LE: 
    if (_22735 == 0) {
        goto LF; // [322] 352
    }
    _22739 = _i_43416 + 1;
    _2 = (object)SEQ_PTR(_stmt_43411);
    _22740 = (object)*(((s1_ptr)_2)->base + _22739);
    if (IS_ATOM_INT(_22740)) {
        _22741 = (_22740 == 64);
    }
    else {
        _22741 = binary_op(EQUALS, _22740, 64);
    }
    _22740 = NOVALUE;
    if (_22741 == 0) {
        DeRef(_22741);
        _22741 = NOVALUE;
        goto LF; // [339] 352
    }
    else {
        if (!IS_ATOM_INT(_22741) && DBL_PTR(_22741)->dbl == 0.0){
            DeRef(_22741);
            _22741 = NOVALUE;
            goto LF; // [339] 352
        }
        DeRef(_22741);
        _22741 = NOVALUE;
    }
    DeRef(_22741);
    _22741 = NOVALUE;

    /** c_decl.e:719					LeftSym = TRUE -- never say: x = x &y or andy - always leave space*/
    _57LeftSym_42587 = _9TRUE_446;
LF: 
LD: 

    /** c_decl.e:723			if stmt[i] = '\n' and i < length(stmt) then*/
    _2 = (object)SEQ_PTR(_stmt_43411);
    _22742 = (object)*(((s1_ptr)_2)->base + _i_43416);
    if (IS_ATOM_INT(_22742)) {
        _22743 = (_22742 == 10);
    }
    else {
        _22743 = binary_op(EQUALS, _22742, 10);
    }
    _22742 = NOVALUE;
    if (IS_ATOM_INT(_22743)) {
        if (_22743 == 0) {
            goto L10; // [363] 424
        }
    }
    else {
        if (DBL_PTR(_22743)->dbl == 0.0) {
            goto L10; // [363] 424
        }
    }
    if (IS_SEQUENCE(_stmt_43411)){
            _22745 = SEQ_PTR(_stmt_43411)->length;
    }
    else {
        _22745 = 1;
    }
    _22746 = (_i_43416 < _22745);
    _22745 = NOVALUE;
    if (_22746 == 0)
    {
        DeRef(_22746);
        _22746 = NOVALUE;
        goto L10; // [375] 424
    }
    else{
        DeRef(_22746);
        _22746 = NOVALUE;
    }

    /** c_decl.e:724				if emit_c_output then*/
    if (_54emit_c_output_46647 == 0)
    {
        goto L11; // [382] 391
    }
    else{
    }

    /** c_decl.e:725					adjust_indent_after(stmt)*/
    RefDS(_stmt_43411);
    _54adjust_indent_after(_stmt_43411);
L11: 

    /** c_decl.e:727				stmt = stmt[i+1..$]*/
    _22747 = _i_43416 + 1;
    if (_22747 > MAXINT){
        _22747 = NewDouble((eudouble)_22747);
    }
    if (IS_SEQUENCE(_stmt_43411)){
            _22748 = SEQ_PTR(_stmt_43411)->length;
    }
    else {
        _22748 = 1;
    }
    rhs_slice_target = (object_ptr)&_stmt_43411;
    RHS_Slice(_stmt_43411, _22747, _22748);

    /** c_decl.e:728				i = 0*/
    _i_43416 = 0;

    /** c_decl.e:729				if emit_c_output then*/
    if (_54emit_c_output_46647 == 0)
    {
        goto L12; // [414] 423
    }
    else{
    }

    /** c_decl.e:730					adjust_indent_before(stmt)*/
    RefDS(_stmt_43411);
    _54adjust_indent_before(_stmt_43411);
L12: 
L10: 

    /** c_decl.e:734			i += 1*/
    _i_43416 = _i_43416 + 1;

    /** c_decl.e:735		end while*/
    goto L4; // [432] 90
L5: 

    /** c_decl.e:737		if emit_c_output then*/
    if (_54emit_c_output_46647 == 0)
    {
        goto L13; // [439] 448
    }
    else{
    }

    /** c_decl.e:738			adjust_indent_after(stmt)*/
    RefDS(_stmt_43411);
    _54adjust_indent_after(_stmt_43411);
L13: 

    /** c_decl.e:740	end procedure*/
    DeRefDS(_stmt_43411);
    DeRef(_arg_43412);
    DeRef(_22743);
    _22743 = NOVALUE;
    DeRef(_22747);
    _22747 = NOVALUE;
    DeRef(_22715);
    _22715 = NOVALUE;
    DeRef(_22694);
    _22694 = NOVALUE;
    DeRef(_22711);
    _22711 = NOVALUE;
    DeRef(_22723);
    _22723 = NOVALUE;
    DeRef(_22725);
    _22725 = NOVALUE;
    DeRef(_22709);
    _22709 = NOVALUE;
    DeRef(_22737);
    _22737 = NOVALUE;
    DeRef(_22701);
    _22701 = NOVALUE;
    DeRef(_22718);
    _22718 = NOVALUE;
    DeRef(_22713);
    _22713 = NOVALUE;
    DeRef(_22734);
    _22734 = NOVALUE;
    DeRef(_22720);
    _22720 = NOVALUE;
    DeRef(_22739);
    _22739 = NOVALUE;
    return;
    ;
}


void _57c_stmt0(object _stmt_43510)
{
    object _0, _1, _2;
    

    /** c_decl.e:745		if emit_c_output then*/
    if (_54emit_c_output_46647 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** c_decl.e:746			c_stmt(stmt, {})*/
    RefDS(_stmt_43510);
    RefDS(_22015);
    _57c_stmt(_stmt_43510, _22015, 0);
L1: 

    /** c_decl.e:748	end procedure*/
    DeRefDSi(_stmt_43510);
    return;
    ;
}


object _57needs_uninit(object _eentry_43515)
{
    object _22771 = NOVALUE;
    object _22770 = NOVALUE;
    object _22769 = NOVALUE;
    object _22768 = NOVALUE;
    object _22767 = NOVALUE;
    object _22766 = NOVALUE;
    object _22765 = NOVALUE;
    object _22764 = NOVALUE;
    object _22763 = NOVALUE;
    object _22762 = NOVALUE;
    object _22761 = NOVALUE;
    object _22760 = NOVALUE;
    object _22759 = NOVALUE;
    object _22758 = NOVALUE;
    object _22757 = NOVALUE;
    object _22756 = NOVALUE;
    object _22755 = NOVALUE;
    object _22754 = NOVALUE;
    object _22753 = NOVALUE;
    object _22752 = NOVALUE;
    object _22751 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:751		if eentry[S_SCOPE] >= SC_LOCAL*/
    _2 = (object)SEQ_PTR(_eentry_43515);
    _22751 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22751)) {
        _22752 = (_22751 >= 5);
    }
    else {
        _22752 = binary_op(GREATEREQ, _22751, 5);
    }
    _22751 = NOVALUE;
    if (IS_ATOM_INT(_22752)) {
        if (_22752 == 0) {
            _22753 = 0;
            goto L1; // [17] 77
        }
    }
    else {
        if (DBL_PTR(_22752)->dbl == 0.0) {
            _22753 = 0;
            goto L1; // [17] 77
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43515);
    _22754 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22754)) {
        _22755 = (_22754 <= 6);
    }
    else {
        _22755 = binary_op(LESSEQ, _22754, 6);
    }
    _22754 = NOVALUE;
    if (IS_ATOM_INT(_22755)) {
        if (_22755 != 0) {
            _22756 = 1;
            goto L2; // [33] 53
        }
    }
    else {
        if (DBL_PTR(_22755)->dbl != 0.0) {
            _22756 = 1;
            goto L2; // [33] 53
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43515);
    _22757 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22757)) {
        _22758 = (_22757 == 11);
    }
    else {
        _22758 = binary_op(EQUALS, _22757, 11);
    }
    _22757 = NOVALUE;
    DeRef(_22756);
    if (IS_ATOM_INT(_22758))
    _22756 = (_22758 != 0);
    else
    _22756 = DBL_PTR(_22758)->dbl != 0.0;
L2: 
    if (_22756 != 0) {
        _22759 = 1;
        goto L3; // [53] 73
    }
    _2 = (object)SEQ_PTR(_eentry_43515);
    _22760 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22760)) {
        _22761 = (_22760 == 13);
    }
    else {
        _22761 = binary_op(EQUALS, _22760, 13);
    }
    _22760 = NOVALUE;
    if (IS_ATOM_INT(_22761))
    _22759 = (_22761 != 0);
    else
    _22759 = DBL_PTR(_22761)->dbl != 0.0;
L3: 
    DeRef(_22753);
    _22753 = (_22759 != 0);
L1: 
    if (_22753 == 0) {
        _22762 = 0;
        goto L4; // [77] 97
    }
    _2 = (object)SEQ_PTR(_eentry_43515);
    _22763 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22763)) {
        _22764 = (_22763 != 0);
    }
    else {
        _22764 = binary_op(NOTEQ, _22763, 0);
    }
    _22763 = NOVALUE;
    if (IS_ATOM_INT(_22764))
    _22762 = (_22764 != 0);
    else
    _22762 = DBL_PTR(_22764)->dbl != 0.0;
L4: 
    if (_22762 == 0) {
        _22765 = 0;
        goto L5; // [97] 117
    }
    _2 = (object)SEQ_PTR(_eentry_43515);
    _22766 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22766)) {
        _22767 = (_22766 != 99);
    }
    else {
        _22767 = binary_op(NOTEQ, _22766, 99);
    }
    _22766 = NOVALUE;
    if (IS_ATOM_INT(_22767))
    _22765 = (_22767 != 0);
    else
    _22765 = DBL_PTR(_22767)->dbl != 0.0;
L5: 
    if (_22765 == 0) {
        goto L6; // [117] 150
    }
    _2 = (object)SEQ_PTR(_eentry_43515);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _22769 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _22769 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _22770 = find_from(_22769, _29RTN_TOKS_12006, 1);
    _22769 = NOVALUE;
    _22771 = (_22770 == 0);
    _22770 = NOVALUE;
    if (_22771 == 0)
    {
        DeRef(_22771);
        _22771 = NOVALUE;
        goto L6; // [138] 150
    }
    else{
        DeRef(_22771);
        _22771 = NOVALUE;
    }

    /** c_decl.e:757			return 1*/
    DeRefDS(_eentry_43515);
    DeRef(_22752);
    _22752 = NOVALUE;
    DeRef(_22767);
    _22767 = NOVALUE;
    DeRef(_22758);
    _22758 = NOVALUE;
    DeRef(_22764);
    _22764 = NOVALUE;
    DeRef(_22755);
    _22755 = NOVALUE;
    DeRef(_22761);
    _22761 = NOVALUE;
    return 1;
    goto L7; // [147] 157
L6: 

    /** c_decl.e:759			return 0*/
    DeRefDS(_eentry_43515);
    DeRef(_22752);
    _22752 = NOVALUE;
    DeRef(_22767);
    _22767 = NOVALUE;
    DeRef(_22758);
    _22758 = NOVALUE;
    DeRef(_22764);
    _22764 = NOVALUE;
    DeRef(_22755);
    _22755 = NOVALUE;
    DeRef(_22761);
    _22761 = NOVALUE;
    return 0;
L7: 
    ;
}


void _57DeclareFileVars()
{
    object _s_43556 = NOVALUE;
    object _eentry_43558 = NOVALUE;
    object _cleanup_vars_43652 = NOVALUE;
    object _22854 = NOVALUE;
    object _22847 = NOVALUE;
    object _22842 = NOVALUE;
    object _22839 = NOVALUE;
    object _22838 = NOVALUE;
    object _22837 = NOVALUE;
    object _22835 = NOVALUE;
    object _22831 = NOVALUE;
    object _22827 = NOVALUE;
    object _22824 = NOVALUE;
    object _22823 = NOVALUE;
    object _22822 = NOVALUE;
    object _22820 = NOVALUE;
    object _22816 = NOVALUE;
    object _22812 = NOVALUE;
    object _22811 = NOVALUE;
    object _22810 = NOVALUE;
    object _22807 = NOVALUE;
    object _22806 = NOVALUE;
    object _22804 = NOVALUE;
    object _22803 = NOVALUE;
    object _22802 = NOVALUE;
    object _22801 = NOVALUE;
    object _22797 = NOVALUE;
    object _22796 = NOVALUE;
    object _22795 = NOVALUE;
    object _22794 = NOVALUE;
    object _22793 = NOVALUE;
    object _22792 = NOVALUE;
    object _22791 = NOVALUE;
    object _22790 = NOVALUE;
    object _22789 = NOVALUE;
    object _22788 = NOVALUE;
    object _22787 = NOVALUE;
    object _22786 = NOVALUE;
    object _22785 = NOVALUE;
    object _22784 = NOVALUE;
    object _22783 = NOVALUE;
    object _22782 = NOVALUE;
    object _22781 = NOVALUE;
    object _22780 = NOVALUE;
    object _22779 = NOVALUE;
    object _22778 = NOVALUE;
    object _22777 = NOVALUE;
    object _22776 = NOVALUE;
    object _22773 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:769		c_puts("// Declaring file vars\n")*/
    RefDS(_22772);
    _54c_puts(_22772);

    /** c_decl.e:770		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22773 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    _2 = (object)SEQ_PTR(_22773);
    _s_43556 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43556)){
        _s_43556 = (object)DBL_PTR(_s_43556)->dbl;
    }
    _22773 = NOVALUE;

    /** c_decl.e:772		while s do*/
L1: 
    if (_s_43556 == 0)
    {
        goto L2; // [29] 328
    }
    else{
    }

    /** c_decl.e:773			eentry = SymTab[s]*/
    DeRef(_eentry_43558);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _eentry_43558 = (object)*(((s1_ptr)_2)->base + _s_43556);
    Ref(_eentry_43558);

    /** c_decl.e:774			if eentry[S_SCOPE] >= SC_LOCAL*/
    _2 = (object)SEQ_PTR(_eentry_43558);
    _22776 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22776)) {
        _22777 = (_22776 >= 5);
    }
    else {
        _22777 = binary_op(GREATEREQ, _22776, 5);
    }
    _22776 = NOVALUE;
    if (IS_ATOM_INT(_22777)) {
        if (_22777 == 0) {
            DeRef(_22778);
            _22778 = 0;
            goto L3; // [56] 116
        }
    }
    else {
        if (DBL_PTR(_22777)->dbl == 0.0) {
            DeRef(_22778);
            _22778 = 0;
            goto L3; // [56] 116
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43558);
    _22779 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22779)) {
        _22780 = (_22779 <= 6);
    }
    else {
        _22780 = binary_op(LESSEQ, _22779, 6);
    }
    _22779 = NOVALUE;
    if (IS_ATOM_INT(_22780)) {
        if (_22780 != 0) {
            DeRef(_22781);
            _22781 = 1;
            goto L4; // [72] 92
        }
    }
    else {
        if (DBL_PTR(_22780)->dbl != 0.0) {
            DeRef(_22781);
            _22781 = 1;
            goto L4; // [72] 92
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43558);
    _22782 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22782)) {
        _22783 = (_22782 == 11);
    }
    else {
        _22783 = binary_op(EQUALS, _22782, 11);
    }
    _22782 = NOVALUE;
    DeRef(_22781);
    if (IS_ATOM_INT(_22783))
    _22781 = (_22783 != 0);
    else
    _22781 = DBL_PTR(_22783)->dbl != 0.0;
L4: 
    if (_22781 != 0) {
        _22784 = 1;
        goto L5; // [92] 112
    }
    _2 = (object)SEQ_PTR(_eentry_43558);
    _22785 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22785)) {
        _22786 = (_22785 == 13);
    }
    else {
        _22786 = binary_op(EQUALS, _22785, 13);
    }
    _22785 = NOVALUE;
    if (IS_ATOM_INT(_22786))
    _22784 = (_22786 != 0);
    else
    _22784 = DBL_PTR(_22786)->dbl != 0.0;
L5: 
    DeRef(_22778);
    _22778 = (_22784 != 0);
L3: 
    if (_22778 == 0) {
        _22787 = 0;
        goto L6; // [116] 136
    }
    _2 = (object)SEQ_PTR(_eentry_43558);
    _22788 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22788)) {
        _22789 = (_22788 != 0);
    }
    else {
        _22789 = binary_op(NOTEQ, _22788, 0);
    }
    _22788 = NOVALUE;
    if (IS_ATOM_INT(_22789))
    _22787 = (_22789 != 0);
    else
    _22787 = DBL_PTR(_22789)->dbl != 0.0;
L6: 
    if (_22787 == 0) {
        _22790 = 0;
        goto L7; // [136] 156
    }
    _2 = (object)SEQ_PTR(_eentry_43558);
    _22791 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22791)) {
        _22792 = (_22791 != 99);
    }
    else {
        _22792 = binary_op(NOTEQ, _22791, 99);
    }
    _22791 = NOVALUE;
    if (IS_ATOM_INT(_22792))
    _22790 = (_22792 != 0);
    else
    _22790 = DBL_PTR(_22792)->dbl != 0.0;
L7: 
    if (_22790 == 0) {
        goto L8; // [156] 307
    }
    _2 = (object)SEQ_PTR(_eentry_43558);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _22794 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _22794 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _22795 = find_from(_22794, _29RTN_TOKS_12006, 1);
    _22794 = NOVALUE;
    _22796 = (_22795 == 0);
    _22795 = NOVALUE;
    if (_22796 == 0)
    {
        DeRef(_22796);
        _22796 = NOVALUE;
        goto L8; // [177] 307
    }
    else{
        DeRef(_22796);
        _22796 = NOVALUE;
    }

    /** c_decl.e:780				if eentry[S_TOKEN] = PROC then*/
    _2 = (object)SEQ_PTR(_eentry_43558);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _22797 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _22797 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    if (binary_op_a(NOTEQ, _22797, 27)){
        _22797 = NOVALUE;
        goto L9; // [190] 202
    }
    _22797 = NOVALUE;

    /** c_decl.e:781					c_puts( "void ")*/
    RefDS(_22799);
    _54c_puts(_22799);
    goto LA; // [199] 208
L9: 

    /** c_decl.e:783					c_puts("object ")*/
    RefDS(_22800);
    _54c_puts(_22800);
LA: 

    /** c_decl.e:785				c_printf("_%d", eentry[S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_eentry_43558);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _22801 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _22801 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    RefDS(_22138);
    Ref(_22801);
    _54c_printf(_22138, _22801);
    _22801 = NOVALUE;

    /** c_decl.e:786				c_puts(eentry[S_NAME])*/
    _2 = (object)SEQ_PTR(_eentry_43558);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _22802 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _22802 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_22802);
    _54c_puts(_22802);
    _22802 = NOVALUE;

    /** c_decl.e:787				if is_integer( eentry[S_OBJ] ) then*/
    _2 = (object)SEQ_PTR(_eentry_43558);
    _22803 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22803);
    _22804 = _12is_integer(_22803);
    _22803 = NOVALUE;
    if (_22804 == 0) {
        DeRef(_22804);
        _22804 = NOVALUE;
        goto LB; // [243] 267
    }
    else {
        if (!IS_ATOM_INT(_22804) && DBL_PTR(_22804)->dbl == 0.0){
            DeRef(_22804);
            _22804 = NOVALUE;
            goto LB; // [243] 267
        }
        DeRef(_22804);
        _22804 = NOVALUE;
    }
    DeRef(_22804);
    _22804 = NOVALUE;

    /** c_decl.e:788						c_printf(" = %d%s;\n", { eentry[S_OBJ], LL_suffix} )*/
    _2 = (object)SEQ_PTR(_eentry_43558);
    _22806 = (object)*(((s1_ptr)_2)->base + 1);
    RefDS(_58LL_suffix_30032);
    Ref(_22806);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _22806;
    ((intptr_t *)_2)[2] = _58LL_suffix_30032;
    _22807 = MAKE_SEQ(_1);
    _22806 = NOVALUE;
    RefDS(_22805);
    _54c_printf(_22805, _22807);
    _22807 = NOVALUE;
    goto LC; // [264] 273
LB: 

    /** c_decl.e:790					c_puts(" = NOVALUE;\n")*/
    RefDS(_22808);
    _54c_puts(_22808);
LC: 

    /** c_decl.e:793				c_hputs("extern object ")*/
    RefDS(_22809);
    _54c_hputs(_22809);

    /** c_decl.e:794				c_hprintf("_%d", eentry[S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_eentry_43558);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _22810 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _22810 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    RefDS(_22138);
    Ref(_22810);
    _54c_hprintf(_22138, _22810);
    _22810 = NOVALUE;

    /** c_decl.e:795				c_hputs(eentry[S_NAME])*/
    _2 = (object)SEQ_PTR(_eentry_43558);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _22811 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _22811 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_22811);
    _54c_hputs(_22811);
    _22811 = NOVALUE;

    /** c_decl.e:797				c_hputs(";\n")*/
    RefDS(_22291);
    _54c_hputs(_22291);
L8: 

    /** c_decl.e:799			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22812 = (object)*(((s1_ptr)_2)->base + _s_43556);
    _2 = (object)SEQ_PTR(_22812);
    _s_43556 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43556)){
        _s_43556 = (object)DBL_PTR(_s_43556)->dbl;
    }
    _22812 = NOVALUE;

    /** c_decl.e:800		end while*/
    goto L1; // [325] 29
L2: 

    /** c_decl.e:801		c_puts("\n")*/
    RefDS(_22210);
    _54c_puts(_22210);

    /** c_decl.e:802		c_hputs("\n")*/
    RefDS(_22210);
    _54c_hputs(_22210);

    /** c_decl.e:803		if dll_option or debug_option then*/
    if (_57dll_option_42590 != 0) {
        goto LD; // [342] 353
    }
    if (_57debug_option_42600 == 0)
    {
        goto LE; // [349] 707
    }
    else{
    }
LD: 

    /** c_decl.e:804			integer cleanup_vars = 0*/
    _cleanup_vars_43652 = 0;

    /** c_decl.e:805			c_puts("// Declaring var array for cleanup\n")*/
    RefDS(_22815);
    _54c_puts(_22815);

    /** c_decl.e:806			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22816 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    _2 = (object)SEQ_PTR(_22816);
    _s_43556 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43556)){
        _s_43556 = (object)DBL_PTR(_s_43556)->dbl;
    }
    _22816 = NOVALUE;

    /** c_decl.e:807			c_stmt0( "object_ptr _0var_cleanup[] = {\n" )*/
    RefDS(_22818);
    _57c_stmt0(_22818);

    /** c_decl.e:808			while s do*/
LF: 
    if (_s_43556 == 0)
    {
        goto L10; // [391] 473
    }
    else{
    }

    /** c_decl.e:809				eentry = SymTab[s]*/
    DeRef(_eentry_43558);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _eentry_43558 = (object)*(((s1_ptr)_2)->base + _s_43556);
    Ref(_eentry_43558);

    /** c_decl.e:810				if needs_uninit( eentry ) then*/
    RefDS(_eentry_43558);
    _22820 = _57needs_uninit(_eentry_43558);
    if (_22820 == 0) {
        DeRef(_22820);
        _22820 = NOVALUE;
        goto L11; // [410] 452
    }
    else {
        if (!IS_ATOM_INT(_22820) && DBL_PTR(_22820)->dbl == 0.0){
            DeRef(_22820);
            _22820 = NOVALUE;
            goto L11; // [410] 452
        }
        DeRef(_22820);
        _22820 = NOVALUE;
    }
    DeRef(_22820);
    _22820 = NOVALUE;

    /** c_decl.e:812					c_stmt0( sprintf("&_%d", eentry[S_FILE_NO]))*/
    _2 = (object)SEQ_PTR(_eentry_43558);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _22822 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _22822 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _22823 = EPrintf(-9999999, _22821, _22822);
    _22822 = NOVALUE;
    _57c_stmt0(_22823);
    _22823 = NOVALUE;

    /** c_decl.e:813					c_puts(eentry[S_NAME] )*/
    _2 = (object)SEQ_PTR(_eentry_43558);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _22824 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _22824 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_22824);
    _54c_puts(_22824);
    _22824 = NOVALUE;

    /** c_decl.e:814					c_printf(", // %d\n", cleanup_vars )*/
    RefDS(_22825);
    _54c_printf(_22825, _cleanup_vars_43652);

    /** c_decl.e:815					cleanup_vars += 1*/
    _cleanup_vars_43652 = _cleanup_vars_43652 + 1;
L11: 

    /** c_decl.e:818				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22827 = (object)*(((s1_ptr)_2)->base + _s_43556);
    _2 = (object)SEQ_PTR(_22827);
    _s_43556 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43556)){
        _s_43556 = (object)DBL_PTR(_s_43556)->dbl;
    }
    _22827 = NOVALUE;

    /** c_decl.e:819			end while*/
    goto LF; // [470] 391
L10: 

    /** c_decl.e:820			c_stmt0( "0\n" )*/
    RefDS(_22829);
    _57c_stmt0(_22829);

    /** c_decl.e:821			c_stmt0( "};\n" )*/
    RefDS(_22830);
    _57c_stmt0(_22830);

    /** c_decl.e:822			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22831 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    _2 = (object)SEQ_PTR(_22831);
    _s_43556 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43556)){
        _s_43556 = (object)DBL_PTR(_s_43556)->dbl;
    }
    _22831 = NOVALUE;

    /** c_decl.e:823			c_stmt0( "char *_0var_cleanup_name[] = {\n" )*/
    RefDS(_22833);
    _57c_stmt0(_22833);

    /** c_decl.e:824			cleanup_vars = 0*/
    _cleanup_vars_43652 = 0;

    /** c_decl.e:825			while s do*/
L12: 
    if (_s_43556 == 0)
    {
        goto L13; // [516] 598
    }
    else{
    }

    /** c_decl.e:826				eentry = SymTab[s]*/
    DeRef(_eentry_43558);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _eentry_43558 = (object)*(((s1_ptr)_2)->base + _s_43556);
    Ref(_eentry_43558);

    /** c_decl.e:827				if needs_uninit( eentry ) then*/
    RefDS(_eentry_43558);
    _22835 = _57needs_uninit(_eentry_43558);
    if (_22835 == 0) {
        DeRef(_22835);
        _22835 = NOVALUE;
        goto L14; // [535] 577
    }
    else {
        if (!IS_ATOM_INT(_22835) && DBL_PTR(_22835)->dbl == 0.0){
            DeRef(_22835);
            _22835 = NOVALUE;
            goto L14; // [535] 577
        }
        DeRef(_22835);
        _22835 = NOVALUE;
    }
    DeRef(_22835);
    _22835 = NOVALUE;

    /** c_decl.e:828					c_stmt0( sprintf("\"_%d", eentry[S_FILE_NO]))*/
    _2 = (object)SEQ_PTR(_eentry_43558);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _22837 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _22837 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _22838 = EPrintf(-9999999, _22836, _22837);
    _22837 = NOVALUE;
    _57c_stmt0(_22838);
    _22838 = NOVALUE;

    /** c_decl.e:829					c_puts(eentry[S_NAME] )*/
    _2 = (object)SEQ_PTR(_eentry_43558);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _22839 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _22839 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_22839);
    _54c_puts(_22839);
    _22839 = NOVALUE;

    /** c_decl.e:830					c_printf("\", // %d\n", cleanup_vars )*/
    RefDS(_22840);
    _54c_printf(_22840, _cleanup_vars_43652);

    /** c_decl.e:831					cleanup_vars += 1*/
    _cleanup_vars_43652 = _cleanup_vars_43652 + 1;
L14: 

    /** c_decl.e:834				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22842 = (object)*(((s1_ptr)_2)->base + _s_43556);
    _2 = (object)SEQ_PTR(_22842);
    _s_43556 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43556)){
        _s_43556 = (object)DBL_PTR(_s_43556)->dbl;
    }
    _22842 = NOVALUE;

    /** c_decl.e:835			end while*/
    goto L12; // [595] 516
L13: 

    /** c_decl.e:836			c_stmt0( "0\n" )*/
    RefDS(_22829);
    _57c_stmt0(_22829);

    /** c_decl.e:837			c_stmt0( "};\n" )*/
    RefDS(_22830);
    _57c_stmt0(_22830);

    /** c_decl.e:838			c_stmt0( "void _0cleanup_vars(){\n" )*/
    RefDS(_22844);
    _57c_stmt0(_22844);

    /** c_decl.e:839				c_stmt0( "int i;\n" )*/
    RefDS(_22099);
    _57c_stmt0(_22099);

    /** c_decl.e:840				c_stmt0( "object x;\n" )*/
    RefDS(_22845);
    _57c_stmt0(_22845);

    /** c_decl.e:841				c_stmt0( sprintf( "for( i = 0; i < %d; ++i ){\n", cleanup_vars ) )*/
    _22847 = EPrintf(-9999999, _22846, _cleanup_vars_43652);
    _57c_stmt0(_22847);
    _22847 = NOVALUE;

    /** c_decl.e:842					c_stmt0( "x = *_0var_cleanup[i];\n" )*/
    RefDS(_22848);
    _57c_stmt0(_22848);

    //c_decl.e:843					c_stmt0( "if( x >= NOVALUE ) /* do nothing */;\n" )
    RefDS(_22849);
    _57c_stmt0(_22849);

    /** c_decl.e:844					c_stmt0( "else if ( IS_ATOM_DBL( x ) && DBL_PTR( x )->cleanup != 0) {\n")*/
    RefDS(_22850);
    _57c_stmt0(_22850);

    /** c_decl.e:845						c_stmt0( "cleanup_double( DBL_PTR( x ) );\n")*/
    RefDS(_22851);
    _57c_stmt0(_22851);

    /** c_decl.e:846					c_stmt0( "}\n" )*/
    RefDS(_15995);
    _57c_stmt0(_15995);

    /** c_decl.e:847						c_stmt0( "else if (IS_SEQUENCE( x ) && SEQ_PTR( x )->cleanup != 0 ) {\n")*/
    RefDS(_22852);
    _57c_stmt0(_22852);

    /** c_decl.e:848						c_stmt0( "cleanup_sequence( SEQ_PTR( x ) );\n")*/
    RefDS(_22853);
    _57c_stmt0(_22853);

    /** c_decl.e:849					c_stmt0( "}\n" )*/
    RefDS(_15995);
    _57c_stmt0(_15995);

    /** c_decl.e:850				c_stmt0( "}\n" )*/
    RefDS(_15995);
    _57c_stmt0(_15995);

    /** c_decl.e:851				c_stmt0( sprintf( "for( i = 0; i < %d; ++i ){\n", cleanup_vars ) )*/
    _22854 = EPrintf(-9999999, _22846, _cleanup_vars_43652);
    _57c_stmt0(_22854);
    _22854 = NOVALUE;

    /** c_decl.e:852					c_stmt0( "DeRef( *_0var_cleanup[i] );\n" )*/
    RefDS(_22855);
    _57c_stmt0(_22855);

    /** c_decl.e:853					c_stmt0( "*_0var_cleanup[i] = NOVALUE;\n" )*/
    RefDS(_22856);
    _57c_stmt0(_22856);

    /** c_decl.e:854				c_stmt0( "}\n" )*/
    RefDS(_15995);
    _57c_stmt0(_15995);

    /** c_decl.e:855			c_stmt0( "}\n" )*/
    RefDS(_15995);
    _57c_stmt0(_15995);
LE: 

    /** c_decl.e:857	end procedure*/
    DeRef(_eentry_43558);
    DeRef(_22780);
    _22780 = NOVALUE;
    DeRef(_22777);
    _22777 = NOVALUE;
    DeRef(_22786);
    _22786 = NOVALUE;
    DeRef(_22792);
    _22792 = NOVALUE;
    DeRef(_22783);
    _22783 = NOVALUE;
    DeRef(_22789);
    _22789 = NOVALUE;
    return;
    ;
}


object _57PromoteTypeInfo()
{
    object _updsym_43723 = NOVALUE;
    object _s_43725 = NOVALUE;
    object _sym_43726 = NOVALUE;
    object _symo_43727 = NOVALUE;
    object _upd_43956 = NOVALUE;
    object _22955 = NOVALUE;
    object _22953 = NOVALUE;
    object _22952 = NOVALUE;
    object _22951 = NOVALUE;
    object _22950 = NOVALUE;
    object _22948 = NOVALUE;
    object _22946 = NOVALUE;
    object _22945 = NOVALUE;
    object _22944 = NOVALUE;
    object _22943 = NOVALUE;
    object _22942 = NOVALUE;
    object _22938 = NOVALUE;
    object _22935 = NOVALUE;
    object _22934 = NOVALUE;
    object _22933 = NOVALUE;
    object _22932 = NOVALUE;
    object _22931 = NOVALUE;
    object _22930 = NOVALUE;
    object _22929 = NOVALUE;
    object _22928 = NOVALUE;
    object _22927 = NOVALUE;
    object _22926 = NOVALUE;
    object _22925 = NOVALUE;
    object _22923 = NOVALUE;
    object _22922 = NOVALUE;
    object _22921 = NOVALUE;
    object _22920 = NOVALUE;
    object _22919 = NOVALUE;
    object _22918 = NOVALUE;
    object _22917 = NOVALUE;
    object _22916 = NOVALUE;
    object _22915 = NOVALUE;
    object _22914 = NOVALUE;
    object _22912 = NOVALUE;
    object _22911 = NOVALUE;
    object _22910 = NOVALUE;
    object _22908 = NOVALUE;
    object _22907 = NOVALUE;
    object _22906 = NOVALUE;
    object _22904 = NOVALUE;
    object _22903 = NOVALUE;
    object _22902 = NOVALUE;
    object _22901 = NOVALUE;
    object _22900 = NOVALUE;
    object _22899 = NOVALUE;
    object _22898 = NOVALUE;
    object _22896 = NOVALUE;
    object _22895 = NOVALUE;
    object _22894 = NOVALUE;
    object _22893 = NOVALUE;
    object _22891 = NOVALUE;
    object _22890 = NOVALUE;
    object _22888 = NOVALUE;
    object _22887 = NOVALUE;
    object _22886 = NOVALUE;
    object _22885 = NOVALUE;
    object _22884 = NOVALUE;
    object _22883 = NOVALUE;
    object _22882 = NOVALUE;
    object _22880 = NOVALUE;
    object _22879 = NOVALUE;
    object _22878 = NOVALUE;
    object _22877 = NOVALUE;
    object _22876 = NOVALUE;
    object _22875 = NOVALUE;
    object _22874 = NOVALUE;
    object _22873 = NOVALUE;
    object _22872 = NOVALUE;
    object _22871 = NOVALUE;
    object _22870 = NOVALUE;
    object _22869 = NOVALUE;
    object _22868 = NOVALUE;
    object _22867 = NOVALUE;
    object _22865 = NOVALUE;
    object _22864 = NOVALUE;
    object _22863 = NOVALUE;
    object _22861 = NOVALUE;
    object _22860 = NOVALUE;
    object _22857 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:866		sequence sym, symo*/

    /** c_decl.e:868		updsym = 0*/
    _updsym_43723 = 0;

    /** c_decl.e:869		g_has_delete = p_has_delete*/
    _57g_has_delete_42782 = _57p_has_delete_42783;

    /** c_decl.e:870		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22857 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    _2 = (object)SEQ_PTR(_22857);
    _s_43725 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43725)){
        _s_43725 = (object)DBL_PTR(_s_43725)->dbl;
    }
    _22857 = NOVALUE;

    /** c_decl.e:871		while s do*/
L1: 
    if (_s_43725 == 0)
    {
        goto L2; // [38] 921
    }
    else{
    }

    /** c_decl.e:872			sym = SymTab[s]*/
    DeRef(_sym_43726);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _sym_43726 = (object)*(((s1_ptr)_2)->base + _s_43725);
    Ref(_sym_43726);

    /** c_decl.e:873			symo = sym*/
    RefDS(_sym_43726);
    DeRef(_symo_43727);
    _symo_43727 = _sym_43726;

    /** c_decl.e:874			if sym[S_TOKEN] = FUNC or sym[S_TOKEN] = TYPE then*/
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _22860 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _22860 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    if (IS_ATOM_INT(_22860)) {
        _22861 = (_22860 == 501);
    }
    else {
        _22861 = binary_op(EQUALS, _22860, 501);
    }
    _22860 = NOVALUE;
    if (IS_ATOM_INT(_22861)) {
        if (_22861 != 0) {
            goto L3; // [72] 93
        }
    }
    else {
        if (DBL_PTR(_22861)->dbl != 0.0) {
            goto L3; // [72] 93
        }
    }
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _22863 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _22863 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    if (IS_ATOM_INT(_22863)) {
        _22864 = (_22863 == 504);
    }
    else {
        _22864 = binary_op(EQUALS, _22863, 504);
    }
    _22863 = NOVALUE;
    if (_22864 == 0) {
        DeRef(_22864);
        _22864 = NOVALUE;
        goto L4; // [89] 138
    }
    else {
        if (!IS_ATOM_INT(_22864) && DBL_PTR(_22864)->dbl == 0.0){
            DeRef(_22864);
            _22864 = NOVALUE;
            goto L4; // [89] 138
        }
        DeRef(_22864);
        _22864 = NOVALUE;
    }
    DeRef(_22864);
    _22864 = NOVALUE;
L3: 

    /** c_decl.e:875				if sym[S_GTYPE_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22865 = (object)*(((s1_ptr)_2)->base + 38);
    if (binary_op_a(NOTEQ, _22865, 0)){
        _22865 = NOVALUE;
        goto L5; // [103] 120
    }
    _22865 = NOVALUE;

    /** c_decl.e:876					sym[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    goto L6; // [117] 549
L5: 

    /** c_decl.e:878					sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22867 = (object)*(((s1_ptr)_2)->base + 38);
    Ref(_22867);
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22867;
    if( _1 != _22867 ){
        DeRef(_1);
    }
    _22867 = NOVALUE;
    goto L6; // [135] 549
L4: 

    /** c_decl.e:883				if sym[S_GTYPE] != TYPE_INTEGER and*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22868 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22868)) {
        _22869 = (_22868 != 1);
    }
    else {
        _22869 = binary_op(NOTEQ, _22868, 1);
    }
    _22868 = NOVALUE;
    if (IS_ATOM_INT(_22869)) {
        if (_22869 == 0) {
            DeRef(_22870);
            _22870 = 0;
            goto L7; // [152] 172
        }
    }
    else {
        if (DBL_PTR(_22869)->dbl == 0.0) {
            DeRef(_22870);
            _22870 = 0;
            goto L7; // [152] 172
        }
    }
    _2 = (object)SEQ_PTR(_sym_43726);
    _22871 = (object)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22871)) {
        _22872 = (_22871 != 16);
    }
    else {
        _22872 = binary_op(NOTEQ, _22871, 16);
    }
    _22871 = NOVALUE;
    DeRef(_22870);
    if (IS_ATOM_INT(_22872))
    _22870 = (_22872 != 0);
    else
    _22870 = DBL_PTR(_22872)->dbl != 0.0;
L7: 
    if (_22870 == 0) {
        goto L8; // [172] 283
    }
    _2 = (object)SEQ_PTR(_sym_43726);
    _22874 = (object)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22874)) {
        _22875 = (_22874 != 0);
    }
    else {
        _22875 = binary_op(NOTEQ, _22874, 0);
    }
    _22874 = NOVALUE;
    if (_22875 == 0) {
        DeRef(_22875);
        _22875 = NOVALUE;
        goto L8; // [189] 283
    }
    else {
        if (!IS_ATOM_INT(_22875) && DBL_PTR(_22875)->dbl == 0.0){
            DeRef(_22875);
            _22875 = NOVALUE;
            goto L8; // [189] 283
        }
        DeRef(_22875);
        _22875 = NOVALUE;
    }
    DeRef(_22875);
    _22875 = NOVALUE;

    /** c_decl.e:886					if sym[S_GTYPE_NEW] = TYPE_INTEGER or*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22876 = (object)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22876)) {
        _22877 = (_22876 == 1);
    }
    else {
        _22877 = binary_op(EQUALS, _22876, 1);
    }
    _22876 = NOVALUE;
    if (IS_ATOM_INT(_22877)) {
        if (_22877 != 0) {
            DeRef(_22878);
            _22878 = 1;
            goto L9; // [206] 226
        }
    }
    else {
        if (DBL_PTR(_22877)->dbl != 0.0) {
            DeRef(_22878);
            _22878 = 1;
            goto L9; // [206] 226
        }
    }
    _2 = (object)SEQ_PTR(_sym_43726);
    _22879 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22879)) {
        _22880 = (_22879 == 16);
    }
    else {
        _22880 = binary_op(EQUALS, _22879, 16);
    }
    _22879 = NOVALUE;
    DeRef(_22878);
    if (IS_ATOM_INT(_22880))
    _22878 = (_22880 != 0);
    else
    _22878 = DBL_PTR(_22880)->dbl != 0.0;
L9: 
    if (_22878 != 0) {
        goto LA; // [226] 267
    }
    _2 = (object)SEQ_PTR(_sym_43726);
    _22882 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22882)) {
        _22883 = (_22882 == 4);
    }
    else {
        _22883 = binary_op(EQUALS, _22882, 4);
    }
    _22882 = NOVALUE;
    if (IS_ATOM_INT(_22883)) {
        if (_22883 == 0) {
            DeRef(_22884);
            _22884 = 0;
            goto LB; // [242] 262
        }
    }
    else {
        if (DBL_PTR(_22883)->dbl == 0.0) {
            DeRef(_22884);
            _22884 = 0;
            goto LB; // [242] 262
        }
    }
    _2 = (object)SEQ_PTR(_sym_43726);
    _22885 = (object)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22885)) {
        _22886 = (_22885 == 2);
    }
    else {
        _22886 = binary_op(EQUALS, _22885, 2);
    }
    _22885 = NOVALUE;
    DeRef(_22884);
    if (IS_ATOM_INT(_22886))
    _22884 = (_22886 != 0);
    else
    _22884 = DBL_PTR(_22886)->dbl != 0.0;
LB: 
    if (_22884 == 0)
    {
        _22884 = NOVALUE;
        goto LC; // [263] 282
    }
    else{
        _22884 = NOVALUE;
    }
LA: 

    /** c_decl.e:890							sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22887 = (object)*(((s1_ptr)_2)->base + 38);
    Ref(_22887);
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22887;
    if( _1 != _22887 ){
        DeRef(_1);
    }
    _22887 = NOVALUE;
LC: 
L8: 

    /** c_decl.e:893				if sym[S_ARG_TYPE_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22888 = (object)*(((s1_ptr)_2)->base + 44);
    if (binary_op_a(NOTEQ, _22888, 0)){
        _22888 = NOVALUE;
        goto LD; // [293] 310
    }
    _22888 = NOVALUE;

    /** c_decl.e:894					sym[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    goto LE; // [307] 325
LD: 

    /** c_decl.e:896					sym[S_ARG_TYPE] = sym[S_ARG_TYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22890 = (object)*(((s1_ptr)_2)->base + 44);
    Ref(_22890);
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22890;
    if( _1 != _22890 ){
        DeRef(_1);
    }
    _22890 = NOVALUE;
LE: 

    /** c_decl.e:898				sym[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:900				if sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22891 = (object)*(((s1_ptr)_2)->base + 46);
    if (binary_op_a(NOTEQ, _22891, 0)){
        _22891 = NOVALUE;
        goto LF; // [345] 362
    }
    _22891 = NOVALUE;

    /** c_decl.e:901					sym[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    goto L10; // [359] 377
LF: 

    /** c_decl.e:903					sym[S_ARG_SEQ_ELEM] = sym[S_ARG_SEQ_ELEM_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22893 = (object)*(((s1_ptr)_2)->base + 46);
    Ref(_22893);
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22893;
    if( _1 != _22893 ){
        DeRef(_1);
    }
    _22893 = NOVALUE;
L10: 

    /** c_decl.e:905				sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:907				if sym[S_ARG_MIN_NEW] = -NOVALUE or*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22894 = (object)*(((s1_ptr)_2)->base + 49);
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _22895 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22895 = - _12NOVALUE_20081;
        }
    }
    else {
        _22895 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    if (IS_ATOM_INT(_22894) && IS_ATOM_INT(_22895)) {
        _22896 = (_22894 == _22895);
    }
    else {
        _22896 = binary_op(EQUALS, _22894, _22895);
    }
    _22894 = NOVALUE;
    DeRef(_22895);
    _22895 = NOVALUE;
    if (IS_ATOM_INT(_22896)) {
        if (_22896 != 0) {
            goto L11; // [404] 425
        }
    }
    else {
        if (DBL_PTR(_22896)->dbl != 0.0) {
            goto L11; // [404] 425
        }
    }
    _2 = (object)SEQ_PTR(_sym_43726);
    _22898 = (object)*(((s1_ptr)_2)->base + 49);
    if (IS_ATOM_INT(_22898) && IS_ATOM_INT(_12NOVALUE_20081)) {
        _22899 = (_22898 == _12NOVALUE_20081);
    }
    else {
        _22899 = binary_op(EQUALS, _22898, _12NOVALUE_20081);
    }
    _22898 = NOVALUE;
    if (_22899 == 0) {
        DeRef(_22899);
        _22899 = NOVALUE;
        goto L12; // [421] 448
    }
    else {
        if (!IS_ATOM_INT(_22899) && DBL_PTR(_22899)->dbl == 0.0){
            DeRef(_22899);
            _22899 = NOVALUE;
            goto L12; // [421] 448
        }
        DeRef(_22899);
        _22899 = NOVALUE;
    }
    DeRef(_22899);
    _22899 = NOVALUE;
L11: 

    /** c_decl.e:909					sym[S_ARG_MIN] = MININT*/
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1073741824;
    DeRef(_1);

    /** c_decl.e:910					sym[S_ARG_MAX] = MAXINT*/
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 48);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1073741823;
    DeRef(_1);
    goto L13; // [445] 477
L12: 

    /** c_decl.e:912					sym[S_ARG_MIN] = sym[S_ARG_MIN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22900 = (object)*(((s1_ptr)_2)->base + 49);
    Ref(_22900);
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22900;
    if( _1 != _22900 ){
        DeRef(_1);
    }
    _22900 = NOVALUE;

    /** c_decl.e:913					sym[S_ARG_MAX] = sym[S_ARG_MAX_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22901 = (object)*(((s1_ptr)_2)->base + 50);
    Ref(_22901);
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 48);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22901;
    if( _1 != _22901 ){
        DeRef(_1);
    }
    _22901 = NOVALUE;
L13: 

    /** c_decl.e:915				sym[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _22902 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22902 = - _12NOVALUE_20081;
        }
    }
    else {
        _22902 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22902;
    if( _1 != _22902 ){
        DeRef(_1);
    }
    _22902 = NOVALUE;

    /** c_decl.e:917				if sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22903 = (object)*(((s1_ptr)_2)->base + 52);
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _22904 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22904 = - _12NOVALUE_20081;
        }
    }
    else {
        _22904 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    if (binary_op_a(NOTEQ, _22903, _22904)){
        _22903 = NOVALUE;
        DeRef(_22904);
        _22904 = NOVALUE;
        goto L14; // [503] 520
    }
    _22903 = NOVALUE;
    DeRef(_22904);
    _22904 = NOVALUE;

    /** c_decl.e:918					sym[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
    goto L15; // [517] 535
L14: 

    /** c_decl.e:920					sym[S_ARG_SEQ_LEN] = sym[S_ARG_SEQ_LEN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22906 = (object)*(((s1_ptr)_2)->base + 52);
    Ref(_22906);
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22906;
    if( _1 != _22906 ){
        DeRef(_1);
    }
    _22906 = NOVALUE;
L15: 

    /** c_decl.e:922				sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _22907 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22907 = - _12NOVALUE_20081;
        }
    }
    else {
        _22907 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22907;
    if( _1 != _22907 ){
        DeRef(_1);
    }
    _22907 = NOVALUE;
L6: 

    /** c_decl.e:925			sym[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:927			if sym[S_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22908 = (object)*(((s1_ptr)_2)->base + 40);
    if (binary_op_a(NOTEQ, _22908, 0)){
        _22908 = NOVALUE;
        goto L16; // [569] 586
    }
    _22908 = NOVALUE;

    /** c_decl.e:928			   sym[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    goto L17; // [583] 601
L16: 

    /** c_decl.e:930				sym[S_SEQ_ELEM] = sym[S_SEQ_ELEM_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22910 = (object)*(((s1_ptr)_2)->base + 40);
    Ref(_22910);
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22910;
    if( _1 != _22910 ){
        DeRef(_1);
    }
    _22910 = NOVALUE;
L17: 

    /** c_decl.e:932			sym[S_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:934			if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22911 = (object)*(((s1_ptr)_2)->base + 39);
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _22912 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22912 = - _12NOVALUE_20081;
        }
    }
    else {
        _22912 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    if (binary_op_a(NOTEQ, _22911, _22912)){
        _22911 = NOVALUE;
        DeRef(_22912);
        _22912 = NOVALUE;
        goto L18; // [624] 641
    }
    _22911 = NOVALUE;
    DeRef(_22912);
    _22912 = NOVALUE;

    /** c_decl.e:935				sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
    goto L19; // [638] 656
L18: 

    /** c_decl.e:937				sym[S_SEQ_LEN] = sym[S_SEQ_LEN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22914 = (object)*(((s1_ptr)_2)->base + 39);
    Ref(_22914);
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22914;
    if( _1 != _22914 ){
        DeRef(_1);
    }
    _22914 = NOVALUE;
L19: 

    /** c_decl.e:939			sym[S_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _22915 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22915 = - _12NOVALUE_20081;
        }
    }
    else {
        _22915 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22915;
    if( _1 != _22915 ){
        DeRef(_1);
    }
    _22915 = NOVALUE;

    /** c_decl.e:941			if sym[S_TOKEN] != NAMESPACE*/
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _22916 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _22916 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    if (IS_ATOM_INT(_22916)) {
        _22917 = (_22916 != 523);
    }
    else {
        _22917 = binary_op(NOTEQ, _22916, 523);
    }
    _22916 = NOVALUE;
    if (IS_ATOM_INT(_22917)) {
        if (_22917 == 0) {
            goto L1A; // [683] 794
        }
    }
    else {
        if (DBL_PTR(_22917)->dbl == 0.0) {
            goto L1A; // [683] 794
        }
    }
    _2 = (object)SEQ_PTR(_sym_43726);
    _22919 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_22919)) {
        _22920 = (_22919 != 2);
    }
    else {
        _22920 = binary_op(NOTEQ, _22919, 2);
    }
    _22919 = NOVALUE;
    if (_22920 == 0) {
        DeRef(_22920);
        _22920 = NOVALUE;
        goto L1A; // [700] 794
    }
    else {
        if (!IS_ATOM_INT(_22920) && DBL_PTR(_22920)->dbl == 0.0){
            DeRef(_22920);
            _22920 = NOVALUE;
            goto L1A; // [700] 794
        }
        DeRef(_22920);
        _22920 = NOVALUE;
    }
    DeRef(_22920);
    _22920 = NOVALUE;

    /** c_decl.e:944				if sym[S_OBJ_MIN_NEW] = -NOVALUE or*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22921 = (object)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _22922 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22922 = - _12NOVALUE_20081;
        }
    }
    else {
        _22922 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    if (IS_ATOM_INT(_22921) && IS_ATOM_INT(_22922)) {
        _22923 = (_22921 == _22922);
    }
    else {
        _22923 = binary_op(EQUALS, _22921, _22922);
    }
    _22921 = NOVALUE;
    DeRef(_22922);
    _22922 = NOVALUE;
    if (IS_ATOM_INT(_22923)) {
        if (_22923 != 0) {
            goto L1B; // [720] 741
        }
    }
    else {
        if (DBL_PTR(_22923)->dbl != 0.0) {
            goto L1B; // [720] 741
        }
    }
    _2 = (object)SEQ_PTR(_sym_43726);
    _22925 = (object)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_22925) && IS_ATOM_INT(_12NOVALUE_20081)) {
        _22926 = (_22925 == _12NOVALUE_20081);
    }
    else {
        _22926 = binary_op(EQUALS, _22925, _12NOVALUE_20081);
    }
    _22925 = NOVALUE;
    if (_22926 == 0) {
        DeRef(_22926);
        _22926 = NOVALUE;
        goto L1C; // [737] 764
    }
    else {
        if (!IS_ATOM_INT(_22926) && DBL_PTR(_22926)->dbl == 0.0){
            DeRef(_22926);
            _22926 = NOVALUE;
            goto L1C; // [737] 764
        }
        DeRef(_22926);
        _22926 = NOVALUE;
    }
    DeRef(_22926);
    _22926 = NOVALUE;
L1B: 

    /** c_decl.e:946					sym[S_OBJ_MIN] = MININT*/
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1073741824;
    DeRef(_1);

    /** c_decl.e:947					sym[S_OBJ_MAX] = MAXINT*/
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1073741823;
    DeRef(_1);
    goto L1D; // [761] 793
L1C: 

    /** c_decl.e:949					sym[S_OBJ_MIN] = sym[S_OBJ_MIN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22927 = (object)*(((s1_ptr)_2)->base + 41);
    Ref(_22927);
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22927;
    if( _1 != _22927 ){
        DeRef(_1);
    }
    _22927 = NOVALUE;

    /** c_decl.e:950					sym[S_OBJ_MAX] = sym[S_OBJ_MAX_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22928 = (object)*(((s1_ptr)_2)->base + 42);
    Ref(_22928);
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22928;
    if( _1 != _22928 ){
        DeRef(_1);
    }
    _22928 = NOVALUE;
L1D: 
L1A: 

    /** c_decl.e:953			sym[S_OBJ_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _22929 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22929 = - _12NOVALUE_20081;
        }
    }
    else {
        _22929 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22929;
    if( _1 != _22929 ){
        DeRef(_1);
    }
    _22929 = NOVALUE;

    /** c_decl.e:955			if sym[S_NREFS] = 1 and*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22930 = (object)*(((s1_ptr)_2)->base + 12);
    if (IS_ATOM_INT(_22930)) {
        _22931 = (_22930 == 1);
    }
    else {
        _22931 = binary_op(EQUALS, _22930, 1);
    }
    _22930 = NOVALUE;
    if (IS_ATOM_INT(_22931)) {
        if (_22931 == 0) {
            goto L1E; // [819] 874
        }
    }
    else {
        if (DBL_PTR(_22931)->dbl == 0.0) {
            goto L1E; // [819] 874
        }
    }
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _22933 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _22933 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _22934 = find_from(_22933, _29RTN_TOKS_12006, 1);
    _22933 = NOVALUE;
    if (_22934 == 0)
    {
        _22934 = NOVALUE;
        goto L1E; // [837] 874
    }
    else{
        _22934 = NOVALUE;
    }

    /** c_decl.e:957				if sym[S_USAGE] != U_DELETED then*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _22935 = (object)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(EQUALS, _22935, 99)){
        _22935 = NOVALUE;
        goto L1F; // [850] 873
    }
    _22935 = NOVALUE;

    /** c_decl.e:958					sym[S_USAGE] = U_DELETED*/
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 99;
    DeRef(_1);

    /** c_decl.e:959					deleted_routines += 1*/
    _57deleted_routines_43720 = _57deleted_routines_43720 + 1;
L1F: 
L1E: 

    /** c_decl.e:962			sym[S_NREFS] = 0*/
    _2 = (object)SEQ_PTR(_sym_43726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:963			if not equal(symo, sym) then*/
    if (_symo_43727 == _sym_43726)
    _22938 = 1;
    else if (IS_ATOM_INT(_symo_43727) && IS_ATOM_INT(_sym_43726))
    _22938 = 0;
    else
    _22938 = (compare(_symo_43727, _sym_43726) == 0);
    if (_22938 != 0)
    goto L20; // [888] 906
    _22938 = NOVALUE;

    /** c_decl.e:964				SymTab[s] = sym*/
    RefDS(_sym_43726);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_43725);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_43726;
    DeRef(_1);

    /** c_decl.e:965				updsym += 1*/
    _updsym_43723 = _updsym_43723 + 1;
L20: 

    /** c_decl.e:967			s = sym[S_NEXT]*/
    _2 = (object)SEQ_PTR(_sym_43726);
    _s_43725 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43725)){
        _s_43725 = (object)DBL_PTR(_s_43725)->dbl;
    }

    /** c_decl.e:968		end while*/
    goto L1; // [918] 38
L2: 

    /** c_decl.e:971		for i = 1 to length(temp_name_type) do*/
    if (IS_SEQUENCE(_12temp_name_type_20309)){
            _22942 = SEQ_PTR(_12temp_name_type_20309)->length;
    }
    else {
        _22942 = 1;
    }
    {
        object _i_43953;
        _i_43953 = 1;
L21: 
        if (_i_43953 > _22942){
            goto L22; // [928] 1061
        }

        /** c_decl.e:972			integer upd = 0*/
        _upd_43956 = 0;

        /** c_decl.e:974			if temp_name_type[i][T_GTYPE] != temp_name_type[i][T_GTYPE_NEW] then*/
        _2 = (object)SEQ_PTR(_12temp_name_type_20309);
        _22943 = (object)*(((s1_ptr)_2)->base + _i_43953);
        _2 = (object)SEQ_PTR(_22943);
        _22944 = (object)*(((s1_ptr)_2)->base + 1);
        _22943 = NOVALUE;
        _2 = (object)SEQ_PTR(_12temp_name_type_20309);
        _22945 = (object)*(((s1_ptr)_2)->base + _i_43953);
        _2 = (object)SEQ_PTR(_22945);
        _22946 = (object)*(((s1_ptr)_2)->base + 2);
        _22945 = NOVALUE;
        if (binary_op_a(EQUALS, _22944, _22946)){
            _22944 = NOVALUE;
            _22946 = NOVALUE;
            goto L23; // [966] 1003
        }
        _22944 = NOVALUE;
        _22946 = NOVALUE;

        /** c_decl.e:975				temp_name_type[i][T_GTYPE] = temp_name_type[i][T_GTYPE_NEW]*/
        _2 = (object)SEQ_PTR(_12temp_name_type_20309);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _12temp_name_type_20309 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_43953 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_12temp_name_type_20309);
        _22950 = (object)*(((s1_ptr)_2)->base + _i_43953);
        _2 = (object)SEQ_PTR(_22950);
        _22951 = (object)*(((s1_ptr)_2)->base + 2);
        _22950 = NOVALUE;
        Ref(_22951);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _22951;
        if( _1 != _22951 ){
            DeRef(_1);
        }
        _22951 = NOVALUE;
        _22948 = NOVALUE;

        /** c_decl.e:976				upd = 1*/
        _upd_43956 = 1;
L23: 

        /** c_decl.e:978			if temp_name_type[i][T_GTYPE_NEW] != TYPE_NULL then*/
        _2 = (object)SEQ_PTR(_12temp_name_type_20309);
        _22952 = (object)*(((s1_ptr)_2)->base + _i_43953);
        _2 = (object)SEQ_PTR(_22952);
        _22953 = (object)*(((s1_ptr)_2)->base + 2);
        _22952 = NOVALUE;
        if (binary_op_a(EQUALS, _22953, 0)){
            _22953 = NOVALUE;
            goto L24; // [1019] 1046
        }
        _22953 = NOVALUE;

        /** c_decl.e:979				temp_name_type[i][T_GTYPE_NEW] = TYPE_NULL*/
        _2 = (object)SEQ_PTR(_12temp_name_type_20309);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _12temp_name_type_20309 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_43953 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 2);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);
        _22955 = NOVALUE;

        /** c_decl.e:980				upd = 1*/
        _upd_43956 = 1;
L24: 

        /** c_decl.e:982			updsym += upd*/
        _updsym_43723 = _updsym_43723 + _upd_43956;

        /** c_decl.e:983		end for*/
        _i_43953 = _i_43953 + 1;
        goto L21; // [1056] 935
L22: 
        ;
    }

    /** c_decl.e:985		return updsym*/
    DeRef(_sym_43726);
    DeRef(_symo_43727);
    DeRef(_22923);
    _22923 = NOVALUE;
    DeRef(_22931);
    _22931 = NOVALUE;
    DeRef(_22877);
    _22877 = NOVALUE;
    DeRef(_22917);
    _22917 = NOVALUE;
    DeRef(_22886);
    _22886 = NOVALUE;
    DeRef(_22896);
    _22896 = NOVALUE;
    DeRef(_22880);
    _22880 = NOVALUE;
    DeRef(_22872);
    _22872 = NOVALUE;
    DeRef(_22861);
    _22861 = NOVALUE;
    DeRef(_22869);
    _22869 = NOVALUE;
    DeRef(_22883);
    _22883 = NOVALUE;
    return _updsym_43723;
    ;
}


void _57declare_prototype(object _s_43991)
{
    object _ret_type_43992 = NOVALUE;
    object _scope_44003 = NOVALUE;
    object _22975 = NOVALUE;
    object _22974 = NOVALUE;
    object _22972 = NOVALUE;
    object _22971 = NOVALUE;
    object _22970 = NOVALUE;
    object _22969 = NOVALUE;
    object _22967 = NOVALUE;
    object _22966 = NOVALUE;
    object _22965 = NOVALUE;
    object _22964 = NOVALUE;
    object _22963 = NOVALUE;
    object _22961 = NOVALUE;
    object _22960 = NOVALUE;
    object _22958 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:990		if sym_token( s ) = PROC then*/
    _22958 = _53sym_token(_s_43991);
    if (binary_op_a(NOTEQ, _22958, 27)){
        DeRef(_22958);
        _22958 = NOVALUE;
        goto L1; // [11] 25
    }
    DeRef(_22958);
    _22958 = NOVALUE;

    /** c_decl.e:991			ret_type = "void "*/
    RefDS(_22799);
    DeRefi(_ret_type_43992);
    _ret_type_43992 = _22799;
    goto L2; // [22] 33
L1: 

    /** c_decl.e:993			ret_type ="object "*/
    RefDS(_22800);
    DeRefi(_ret_type_43992);
    _ret_type_43992 = _22800;
L2: 

    /** c_decl.e:996		c_hputs(ret_type)*/
    RefDS(_ret_type_43992);
    _54c_hputs(_ret_type_43992);

    /** c_decl.e:999		if dll_option and TWINDOWS  then*/
    if (_57dll_option_42590 == 0) {
        goto L3; // [44] 116
    }
    goto L3; // [51] 116

    /** c_decl.e:1000			integer scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22961 = (object)*(((s1_ptr)_2)->base + _s_43991);
    _2 = (object)SEQ_PTR(_22961);
    _scope_44003 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_44003)){
        _scope_44003 = (object)DBL_PTR(_scope_44003)->dbl;
    }
    _22961 = NOVALUE;

    /** c_decl.e:1001			if (scope = SC_PUBLIC*/
    _22963 = (_scope_44003 == 13);
    if (_22963 != 0) {
        _22964 = 1;
        goto L4; // [78] 92
    }
    _22965 = (_scope_44003 == 11);
    _22964 = (_22965 != 0);
L4: 
    if (_22964 != 0) {
        DeRef(_22966);
        _22966 = 1;
        goto L5; // [92] 106
    }
    _22967 = (_scope_44003 == 6);
    _22966 = (_22967 != 0);
L5: 
    if (_22966 == 0)
    {
        _22966 = NOVALUE;
        goto L6; // [106] 115
    }
    else{
        _22966 = NOVALUE;
    }

    /** c_decl.e:1006				c_hputs("__stdcall ")*/
    RefDS(_22968);
    _54c_hputs(_22968);
L6: 
L3: 

    /** c_decl.e:1010		c_hprintf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22969 = (object)*(((s1_ptr)_2)->base + _s_43991);
    _2 = (object)SEQ_PTR(_22969);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _22970 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _22970 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _22969 = NOVALUE;
    RefDS(_22138);
    Ref(_22970);
    _54c_hprintf(_22138, _22970);
    _22970 = NOVALUE;

    /** c_decl.e:1011		c_hputs(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22971 = (object)*(((s1_ptr)_2)->base + _s_43991);
    _2 = (object)SEQ_PTR(_22971);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _22972 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _22972 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _22971 = NOVALUE;
    Ref(_22972);
    _54c_hputs(_22972);
    _22972 = NOVALUE;

    /** c_decl.e:1012		c_hputs("(")*/
    RefDS(_22973);
    _54c_hputs(_22973);

    /** c_decl.e:1014		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22974 = (object)*(((s1_ptr)_2)->base + _s_43991);
    _2 = (object)SEQ_PTR(_22974);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _22975 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _22975 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _22974 = NOVALUE;
    {
        object _i_44032;
        _i_44032 = 1;
L7: 
        if (binary_op_a(GREATER, _i_44032, _22975)){
            goto L8; // [172] 206
        }

        /** c_decl.e:1015			if i = 1 then*/
        if (binary_op_a(NOTEQ, _i_44032, 1)){
            goto L9; // [181] 193
        }

        /** c_decl.e:1016				c_hputs("object")*/
        RefDS(_22977);
        _54c_hputs(_22977);
        goto LA; // [190] 199
L9: 

        /** c_decl.e:1018				c_hputs(", object")*/
        RefDS(_22978);
        _54c_hputs(_22978);
LA: 

        /** c_decl.e:1020		end for*/
        _0 = _i_44032;
        if (IS_ATOM_INT(_i_44032)) {
            _i_44032 = _i_44032 + 1;
            if ((object)((uintptr_t)_i_44032 +(uintptr_t) HIGH_BITS) >= 0){
                _i_44032 = NewDouble((eudouble)_i_44032);
            }
        }
        else {
            _i_44032 = binary_op_a(PLUS, _i_44032, 1);
        }
        DeRef(_0);
        goto L7; // [201] 179
L8: 
        ;
        DeRef(_i_44032);
    }

    /** c_decl.e:1021		c_hputs(");\n")*/
    RefDS(_22319);
    _54c_hputs(_22319);

    /** c_decl.e:1022	end procedure*/
    DeRefi(_ret_type_43992);
    _22975 = NOVALUE;
    DeRef(_22967);
    _22967 = NOVALUE;
    DeRef(_22965);
    _22965 = NOVALUE;
    DeRef(_22963);
    _22963 = NOVALUE;
    return;
    ;
}


void _57add_to_routine_list(object _s_44048, object _seq_num_44049, object _first_44050)
{
    object _p_44125 = NOVALUE;
    object _23024 = NOVALUE;
    object _23022 = NOVALUE;
    object _23020 = NOVALUE;
    object _23018 = NOVALUE;
    object _23016 = NOVALUE;
    object _23015 = NOVALUE;
    object _23014 = NOVALUE;
    object _23012 = NOVALUE;
    object _23010 = NOVALUE;
    object _23008 = NOVALUE;
    object _23007 = NOVALUE;
    object _23005 = NOVALUE;
    object _23004 = NOVALUE;
    object _23000 = NOVALUE;
    object _22999 = NOVALUE;
    object _22998 = NOVALUE;
    object _22997 = NOVALUE;
    object _22996 = NOVALUE;
    object _22995 = NOVALUE;
    object _22994 = NOVALUE;
    object _22993 = NOVALUE;
    object _22992 = NOVALUE;
    object _22991 = NOVALUE;
    object _22989 = NOVALUE;
    object _22988 = NOVALUE;
    object _22987 = NOVALUE;
    object _22986 = NOVALUE;
    object _22983 = NOVALUE;
    object _22982 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:1025		if not first then*/
    if (_first_44050 != 0)
    goto L1; // [9] 18

    /** c_decl.e:1026			c_puts(",\n")*/
    RefDS(_22980);
    _54c_puts(_22980);
L1: 

    /** c_decl.e:1029		c_puts("  {\"")*/
    RefDS(_22981);
    _54c_puts(_22981);

    /** c_decl.e:1031		c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22982 = (object)*(((s1_ptr)_2)->base + _s_44048);
    _2 = (object)SEQ_PTR(_22982);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _22983 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _22983 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _22982 = NOVALUE;
    Ref(_22983);
    _54c_puts(_22983);
    _22983 = NOVALUE;

    /** c_decl.e:1032		c_puts("\", ")*/
    RefDS(_22984);
    _54c_puts(_22984);

    /** c_decl.e:1033		c_puts("(object (*)())")*/
    RefDS(_22985);
    _54c_puts(_22985);

    /** c_decl.e:1034		c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22986 = (object)*(((s1_ptr)_2)->base + _s_44048);
    _2 = (object)SEQ_PTR(_22986);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _22987 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _22987 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _22986 = NOVALUE;
    RefDS(_22138);
    Ref(_22987);
    _54c_printf(_22138, _22987);
    _22987 = NOVALUE;

    /** c_decl.e:1035		c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22988 = (object)*(((s1_ptr)_2)->base + _s_44048);
    _2 = (object)SEQ_PTR(_22988);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _22989 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _22989 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _22988 = NOVALUE;
    Ref(_22989);
    _54c_puts(_22989);
    _22989 = NOVALUE;

    /** c_decl.e:1036		c_printf(", %d", seq_num)*/
    RefDS(_22990);
    _54c_printf(_22990, _seq_num_44049);

    /** c_decl.e:1037		c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22991 = (object)*(((s1_ptr)_2)->base + _s_44048);
    _2 = (object)SEQ_PTR(_22991);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _22992 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _22992 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _22991 = NOVALUE;
    RefDS(_22990);
    Ref(_22992);
    _54c_printf(_22990, _22992);
    _22992 = NOVALUE;

    /** c_decl.e:1038		c_printf(", %d", SymTab[s][S_NUM_ARGS])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22993 = (object)*(((s1_ptr)_2)->base + _s_44048);
    _2 = (object)SEQ_PTR(_22993);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _22994 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _22994 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _22993 = NOVALUE;
    RefDS(_22990);
    Ref(_22994);
    _54c_printf(_22990, _22994);
    _22994 = NOVALUE;

    /** c_decl.e:1040		if TWINDOWS and dll_option and find( SymTab[s][S_SCOPE], { SC_GLOBAL, SC_EXPORT, SC_PUBLIC} ) then*/
    if (0 == 0) {
        _22995 = 0;
        goto L2; // [131] 141
    }
    _22995 = (_57dll_option_42590 != 0);
L2: 
    if (_22995 == 0) {
        goto L3; // [141] 186
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _22997 = (object)*(((s1_ptr)_2)->base + _s_44048);
    _2 = (object)SEQ_PTR(_22997);
    _22998 = (object)*(((s1_ptr)_2)->base + 4);
    _22997 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 6;
    ((intptr_t*)_2)[2] = 11;
    ((intptr_t*)_2)[3] = 13;
    _22999 = MAKE_SEQ(_1);
    _23000 = find_from(_22998, _22999, 1);
    _22998 = NOVALUE;
    DeRefDS(_22999);
    _22999 = NOVALUE;
    if (_23000 == 0)
    {
        _23000 = NOVALUE;
        goto L3; // [175] 186
    }
    else{
        _23000 = NOVALUE;
    }

    /** c_decl.e:1041			c_puts(", 1")  -- must call with __stdcall convention*/
    RefDS(_23001);
    _54c_puts(_23001);
    goto L4; // [183] 192
L3: 

    /** c_decl.e:1043			c_puts(", 0")  -- default: call with normal or __cdecl convention*/
    RefDS(_23002);
    _54c_puts(_23002);
L4: 

    /** c_decl.e:1046		c_printf(", %d, 0", SymTab[s][S_SCOPE] )*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _23004 = (object)*(((s1_ptr)_2)->base + _s_44048);
    _2 = (object)SEQ_PTR(_23004);
    _23005 = (object)*(((s1_ptr)_2)->base + 4);
    _23004 = NOVALUE;
    RefDS(_23003);
    Ref(_23005);
    _54c_printf(_23003, _23005);
    _23005 = NOVALUE;

    /** c_decl.e:1047		c_puts("}")*/
    RefDS(_23006);
    _54c_puts(_23006);

    /** c_decl.e:1049		if SymTab[s][S_NREFS] < 2 then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _23007 = (object)*(((s1_ptr)_2)->base + _s_44048);
    _2 = (object)SEQ_PTR(_23007);
    _23008 = (object)*(((s1_ptr)_2)->base + 12);
    _23007 = NOVALUE;
    if (binary_op_a(GREATEREQ, _23008, 2)){
        _23008 = NOVALUE;
        goto L5; // [229] 249
    }
    _23008 = NOVALUE;

    /** c_decl.e:1050			SymTab[s][S_NREFS] = 2 --s->nrefs++*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_44048 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _23010 = NOVALUE;
L5: 

    /** c_decl.e:1055		symtab_index p = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _23012 = (object)*(((s1_ptr)_2)->base + _s_44048);
    _2 = (object)SEQ_PTR(_23012);
    _p_44125 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_44125)){
        _p_44125 = (object)DBL_PTR(_p_44125)->dbl;
    }
    _23012 = NOVALUE;

    /** c_decl.e:1056		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _23014 = (object)*(((s1_ptr)_2)->base + _s_44048);
    _2 = (object)SEQ_PTR(_23014);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _23015 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _23015 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _23014 = NOVALUE;
    {
        object _i_44131;
        _i_44131 = 1;
L6: 
        if (binary_op_a(GREATER, _i_44131, _23015)){
            goto L7; // [279] 377
        }

        /** c_decl.e:1057			SymTab[p][S_ARG_SEQ_ELEM_NEW] = TYPE_OBJECT*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44125 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 46);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 16;
        DeRef(_1);
        _23016 = NOVALUE;

        /** c_decl.e:1058			SymTab[p][S_ARG_TYPE_NEW] = TYPE_OBJECT*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44125 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 44);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 16;
        DeRef(_1);
        _23018 = NOVALUE;

        /** c_decl.e:1059			SymTab[p][S_ARG_MIN_NEW] = NOVALUE*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44125 + ((s1_ptr)_2)->base);
        Ref(_12NOVALUE_20081);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 49);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _12NOVALUE_20081;
        DeRef(_1);
        _23020 = NOVALUE;

        /** c_decl.e:1060			SymTab[p][S_ARG_SEQ_LEN_NEW] = NOVALUE*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44125 + ((s1_ptr)_2)->base);
        Ref(_12NOVALUE_20081);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 52);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _12NOVALUE_20081;
        DeRef(_1);
        _23022 = NOVALUE;

        /** c_decl.e:1061			p = SymTab[p][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _23024 = (object)*(((s1_ptr)_2)->base + _p_44125);
        _2 = (object)SEQ_PTR(_23024);
        _p_44125 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_p_44125)){
            _p_44125 = (object)DBL_PTR(_p_44125)->dbl;
        }
        _23024 = NOVALUE;

        /** c_decl.e:1062		end for*/
        _0 = _i_44131;
        if (IS_ATOM_INT(_i_44131)) {
            _i_44131 = _i_44131 + 1;
            if ((object)((uintptr_t)_i_44131 +(uintptr_t) HIGH_BITS) >= 0){
                _i_44131 = NewDouble((eudouble)_i_44131);
            }
        }
        else {
            _i_44131 = binary_op_a(PLUS, _i_44131, 1);
        }
        DeRef(_0);
        goto L6; // [372] 286
L7: 
        ;
        DeRef(_i_44131);
    }

    /** c_decl.e:1063	end procedure*/
    _23015 = NOVALUE;
    return;
    ;
}


void _57DeclareRoutineList()
{
    object _s_44163 = NOVALUE;
    object _first_44164 = NOVALUE;
    object _seq_num_44165 = NOVALUE;
    object _these_routines_44173 = NOVALUE;
    object _these_routines_44195 = NOVALUE;
    object _23040 = NOVALUE;
    object _23039 = NOVALUE;
    object _23037 = NOVALUE;
    object _23035 = NOVALUE;
    object _23032 = NOVALUE;
    object _23031 = NOVALUE;
    object _23029 = NOVALUE;
    object _23027 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1069		integer first, seq_num*/

    /** c_decl.e:1071		c_hputs("extern struct routine_list _00[];\n")*/
    RefDS(_23026);
    _54c_hputs(_23026);

    /** c_decl.e:1073		check_file_routines()*/
    _57check_file_routines();

    /** c_decl.e:1074		for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_57file_routines_44752)){
            _23027 = SEQ_PTR(_57file_routines_44752)->length;
    }
    else {
        _23027 = 1;
    }
    {
        object _f_44170;
        _f_44170 = 1;
L1: 
        if (_f_44170 > _23027){
            goto L2; // [19] 98
        }

        /** c_decl.e:1075			sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_44173);
        _2 = (object)SEQ_PTR(_57file_routines_44752);
        _these_routines_44173 = (object)*(((s1_ptr)_2)->base + _f_44170);
        Ref(_these_routines_44173);

        /** c_decl.e:1076			for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_44173)){
                _23029 = SEQ_PTR(_these_routines_44173)->length;
        }
        else {
            _23029 = 1;
        }
        {
            object _r_44177;
            _r_44177 = 1;
L3: 
            if (_r_44177 > _23029){
                goto L4; // [41] 89
            }

            /** c_decl.e:1077				s = these_routines[r]*/
            _2 = (object)SEQ_PTR(_these_routines_44173);
            _s_44163 = (object)*(((s1_ptr)_2)->base + _r_44177);
            if (!IS_ATOM_INT(_s_44163)){
                _s_44163 = (object)DBL_PTR(_s_44163)->dbl;
            }

            /** c_decl.e:1078				if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _23031 = (object)*(((s1_ptr)_2)->base + _s_44163);
            _2 = (object)SEQ_PTR(_23031);
            _23032 = (object)*(((s1_ptr)_2)->base + 5);
            _23031 = NOVALUE;
            if (binary_op_a(EQUALS, _23032, 99)){
                _23032 = NOVALUE;
                goto L5; // [72] 82
            }
            _23032 = NOVALUE;

            /** c_decl.e:1080					declare_prototype( s )*/
            _57declare_prototype(_s_44163);
L5: 

            /** c_decl.e:1083			end for*/
            _r_44177 = _r_44177 + 1;
            goto L3; // [84] 48
L4: 
            ;
        }
        DeRef(_these_routines_44173);
        _these_routines_44173 = NOVALUE;

        /** c_decl.e:1084		end for*/
        _f_44170 = _f_44170 + 1;
        goto L1; // [93] 26
L2: 
        ;
    }

    /** c_decl.e:1085		c_puts("\n")*/
    RefDS(_22210);
    _54c_puts(_22210);

    /** c_decl.e:1088		seq_num = 0*/
    _seq_num_44165 = 0;

    /** c_decl.e:1089		first = TRUE*/
    _first_44164 = _9TRUE_446;

    /** c_decl.e:1090		c_puts("struct routine_list _00[] = {\n")*/
    RefDS(_23034);
    _54c_puts(_23034);

    /** c_decl.e:1092		for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_57file_routines_44752)){
            _23035 = SEQ_PTR(_57file_routines_44752)->length;
    }
    else {
        _23035 = 1;
    }
    {
        object _f_44192;
        _f_44192 = 1;
L6: 
        if (_f_44192 > _23035){
            goto L7; // [129] 222
        }

        /** c_decl.e:1093			sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_44195);
        _2 = (object)SEQ_PTR(_57file_routines_44752);
        _these_routines_44195 = (object)*(((s1_ptr)_2)->base + _f_44192);
        Ref(_these_routines_44195);

        /** c_decl.e:1094			for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_44195)){
                _23037 = SEQ_PTR(_these_routines_44195)->length;
        }
        else {
            _23037 = 1;
        }
        {
            object _r_44199;
            _r_44199 = 1;
L8: 
            if (_r_44199 > _23037){
                goto L9; // [151] 213
            }

            /** c_decl.e:1095				s = these_routines[r]*/
            _2 = (object)SEQ_PTR(_these_routines_44195);
            _s_44163 = (object)*(((s1_ptr)_2)->base + _r_44199);
            if (!IS_ATOM_INT(_s_44163)){
                _s_44163 = (object)DBL_PTR(_s_44163)->dbl;
            }

            /** c_decl.e:1096				if SymTab[s][S_RI_TARGET] then*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _23039 = (object)*(((s1_ptr)_2)->base + _s_44163);
            _2 = (object)SEQ_PTR(_23039);
            _23040 = (object)*(((s1_ptr)_2)->base + 53);
            _23039 = NOVALUE;
            if (_23040 == 0) {
                _23040 = NOVALUE;
                goto LA; // [180] 200
            }
            else {
                if (!IS_ATOM_INT(_23040) && DBL_PTR(_23040)->dbl == 0.0){
                    _23040 = NOVALUE;
                    goto LA; // [180] 200
                }
                _23040 = NOVALUE;
            }
            _23040 = NOVALUE;

            /** c_decl.e:1098					add_to_routine_list( s, seq_num, first )*/
            _57add_to_routine_list(_s_44163, _seq_num_44165, _first_44164);

            /** c_decl.e:1099					first = FALSE*/
            _first_44164 = _9FALSE_444;
LA: 

            /** c_decl.e:1102				seq_num += 1*/
            _seq_num_44165 = _seq_num_44165 + 1;

            /** c_decl.e:1103			end for*/
            _r_44199 = _r_44199 + 1;
            goto L8; // [208] 158
L9: 
            ;
        }
        DeRef(_these_routines_44195);
        _these_routines_44195 = NOVALUE;

        /** c_decl.e:1104		end for*/
        _f_44192 = _f_44192 + 1;
        goto L6; // [217] 136
L7: 
        ;
    }

    /** c_decl.e:1105		if not first then*/
    if (_first_44164 != 0)
    goto LB; // [224] 233

    /** c_decl.e:1106			c_puts(",\n")*/
    RefDS(_22980);
    _54c_puts(_22980);
LB: 

    /** c_decl.e:1108		c_puts("  {\"\", 0, 999999999, 0, 0, 0, 0}\n};\n\n")  -- end marker*/
    RefDS(_23043);
    _54c_puts(_23043);

    /** c_decl.e:1110		c_hputs("extern char ** _02;\n")*/
    RefDS(_23044);
    _54c_hputs(_23044);

    /** c_decl.e:1111		c_puts("char ** _02;\n")*/
    RefDS(_23045);
    _54c_puts(_23045);

    /** c_decl.e:1113		c_hputs("extern object _0switches;\n")*/
    RefDS(_23046);
    _54c_hputs(_23046);

    /** c_decl.e:1114		c_puts("object _0switches;\n")*/
    RefDS(_23047);
    _54c_puts(_23047);

    /** c_decl.e:1115	end procedure*/
    return;
    ;
}


void _57DeclareNameSpaceList()
{
    object _s_44225 = NOVALUE;
    object _first_44226 = NOVALUE;
    object _seq_num_44227 = NOVALUE;
    object _23067 = NOVALUE;
    object _23065 = NOVALUE;
    object _23064 = NOVALUE;
    object _23063 = NOVALUE;
    object _23062 = NOVALUE;
    object _23060 = NOVALUE;
    object _23059 = NOVALUE;
    object _23056 = NOVALUE;
    object _23055 = NOVALUE;
    object _23054 = NOVALUE;
    object _23053 = NOVALUE;
    object _23052 = NOVALUE;
    object _23050 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1121		integer first, seq_num*/

    /** c_decl.e:1123		c_hputs("extern struct ns_list _01[];\n")*/
    RefDS(_23048);
    _54c_hputs(_23048);

    /** c_decl.e:1124		c_puts("struct ns_list _01[] = {\n")*/
    RefDS(_23049);
    _54c_puts(_23049);

    /** c_decl.e:1126		seq_num = 0*/
    _seq_num_44227 = 0;

    /** c_decl.e:1127		first = TRUE*/
    _first_44226 = _9TRUE_446;

    /** c_decl.e:1129		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _23050 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    _2 = (object)SEQ_PTR(_23050);
    _s_44225 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_44225)){
        _s_44225 = (object)DBL_PTR(_s_44225)->dbl;
    }
    _23050 = NOVALUE;

    /** c_decl.e:1130		while s do*/
L1: 
    if (_s_44225 == 0)
    {
        goto L2; // [50] 215
    }
    else{
    }

    /** c_decl.e:1131			if find(SymTab[s][S_TOKEN], NAMED_TOKS) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _23052 = (object)*(((s1_ptr)_2)->base + _s_44225);
    _2 = (object)SEQ_PTR(_23052);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _23053 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _23053 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _23052 = NOVALUE;
    _23054 = find_from(_23053, _29NAMED_TOKS_12008, 1);
    _23053 = NOVALUE;
    if (_23054 == 0)
    {
        _23054 = NOVALUE;
        goto L3; // [74] 194
    }
    else{
        _23054 = NOVALUE;
    }

    /** c_decl.e:1132				if SymTab[s][S_TOKEN] = NAMESPACE then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _23055 = (object)*(((s1_ptr)_2)->base + _s_44225);
    _2 = (object)SEQ_PTR(_23055);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _23056 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _23056 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _23055 = NOVALUE;
    if (binary_op_a(NOTEQ, _23056, 523)){
        _23056 = NOVALUE;
        goto L4; // [93] 187
    }
    _23056 = NOVALUE;

    /** c_decl.e:1133					if not first then*/
    if (_first_44226 != 0)
    goto L5; // [99] 108

    /** c_decl.e:1134						c_puts(",\n")*/
    RefDS(_22980);
    _54c_puts(_22980);
L5: 

    /** c_decl.e:1136					first = FALSE*/
    _first_44226 = _9FALSE_444;

    /** c_decl.e:1138					c_puts("  {\"")*/
    RefDS(_22981);
    _54c_puts(_22981);

    /** c_decl.e:1139					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _23059 = (object)*(((s1_ptr)_2)->base + _s_44225);
    _2 = (object)SEQ_PTR(_23059);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _23060 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _23060 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _23059 = NOVALUE;
    Ref(_23060);
    _54c_puts(_23060);
    _23060 = NOVALUE;

    /** c_decl.e:1140					c_printf("\", %d", SymTab[s][S_OBJ])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _23062 = (object)*(((s1_ptr)_2)->base + _s_44225);
    _2 = (object)SEQ_PTR(_23062);
    _23063 = (object)*(((s1_ptr)_2)->base + 1);
    _23062 = NOVALUE;
    RefDS(_23061);
    Ref(_23063);
    _54c_printf(_23061, _23063);
    _23063 = NOVALUE;

    /** c_decl.e:1141					c_printf(", %d", seq_num)*/
    RefDS(_22990);
    _54c_printf(_22990, _seq_num_44227);

    /** c_decl.e:1142					c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _23064 = (object)*(((s1_ptr)_2)->base + _s_44225);
    _2 = (object)SEQ_PTR(_23064);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _23065 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _23065 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _23064 = NOVALUE;
    RefDS(_22990);
    Ref(_23065);
    _54c_printf(_22990, _23065);
    _23065 = NOVALUE;

    /** c_decl.e:1144					c_puts("}")*/
    RefDS(_23006);
    _54c_puts(_23006);
L4: 

    /** c_decl.e:1146				seq_num += 1*/
    _seq_num_44227 = _seq_num_44227 + 1;
L3: 

    /** c_decl.e:1148			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _23067 = (object)*(((s1_ptr)_2)->base + _s_44225);
    _2 = (object)SEQ_PTR(_23067);
    _s_44225 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_44225)){
        _s_44225 = (object)DBL_PTR(_s_44225)->dbl;
    }
    _23067 = NOVALUE;

    /** c_decl.e:1149		end while*/
    goto L1; // [212] 50
L2: 

    /** c_decl.e:1150		if not first then*/
    if (_first_44226 != 0)
    goto L6; // [217] 226

    /** c_decl.e:1151			c_puts(",\n")*/
    RefDS(_22980);
    _54c_puts(_22980);
L6: 

    /** c_decl.e:1153		c_puts("  {\"\", 0, 999999999, 0}\n};\n\n")  -- end marker*/
    RefDS(_23070);
    _54c_puts(_23070);

    /** c_decl.e:1154	end procedure*/
    return;
    ;
}


object _57is_exported(object _s_44289)
{
    object _eentry_44290 = NOVALUE;
    object _scope_44293 = NOVALUE;
    object _23085 = NOVALUE;
    object _23084 = NOVALUE;
    object _23083 = NOVALUE;
    object _23082 = NOVALUE;
    object _23081 = NOVALUE;
    object _23080 = NOVALUE;
    object _23079 = NOVALUE;
    object _23078 = NOVALUE;
    object _23077 = NOVALUE;
    object _23076 = NOVALUE;
    object _23075 = NOVALUE;
    object _23073 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_44289)) {
        _1 = (object)(DBL_PTR(_s_44289)->dbl);
        DeRefDS(_s_44289);
        _s_44289 = _1;
    }

    /** c_decl.e:1159		sequence eentry = SymTab[s]*/
    DeRef(_eentry_44290);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _eentry_44290 = (object)*(((s1_ptr)_2)->base + _s_44289);
    Ref(_eentry_44290);

    /** c_decl.e:1160		integer scope = eentry[S_SCOPE]*/
    _2 = (object)SEQ_PTR(_eentry_44290);
    _scope_44293 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_44293))
    _scope_44293 = (object)DBL_PTR(_scope_44293)->dbl;

    /** c_decl.e:1162		if eentry[S_MODE] = M_NORMAL then*/
    _2 = (object)SEQ_PTR(_eentry_44290);
    _23073 = (object)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _23073, 1)){
        _23073 = NOVALUE;
        goto L1; // [31] 125
    }
    _23073 = NOVALUE;

    /** c_decl.e:1163			if eentry[S_FILE_NO] = 1 and find(scope, { SC_EXPORT, SC_PUBLIC, SC_GLOBAL }) then*/
    _2 = (object)SEQ_PTR(_eentry_44290);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _23075 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _23075 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    if (IS_ATOM_INT(_23075)) {
        _23076 = (_23075 == 1);
    }
    else {
        _23076 = binary_op(EQUALS, _23075, 1);
    }
    _23075 = NOVALUE;
    if (IS_ATOM_INT(_23076)) {
        if (_23076 == 0) {
            goto L2; // [47] 79
        }
    }
    else {
        if (DBL_PTR(_23076)->dbl == 0.0) {
            goto L2; // [47] 79
        }
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 11;
    ((intptr_t*)_2)[2] = 13;
    ((intptr_t*)_2)[3] = 6;
    _23078 = MAKE_SEQ(_1);
    _23079 = find_from(_scope_44293, _23078, 1);
    DeRefDS(_23078);
    _23078 = NOVALUE;
    if (_23079 == 0)
    {
        _23079 = NOVALUE;
        goto L2; // [69] 79
    }
    else{
        _23079 = NOVALUE;
    }

    /** c_decl.e:1164				return 1*/
    DeRef(_eentry_44290);
    DeRef(_23076);
    _23076 = NOVALUE;
    return 1;
L2: 

    /** c_decl.e:1167			if scope = SC_PUBLIC and*/
    _23080 = (_scope_44293 == 13);
    if (_23080 == 0) {
        goto L3; // [87] 124
    }
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _23082 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_eentry_44290);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _23083 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _23083 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _2 = (object)SEQ_PTR(_23082);
    if (!IS_ATOM_INT(_23083)){
        _23084 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23083)->dbl));
    }
    else{
        _23084 = (object)*(((s1_ptr)_2)->base + _23083);
    }
    _23082 = NOVALUE;
    if (IS_ATOM_INT(_23084)) {
        {uintptr_t tu;
             tu = (uintptr_t)_23084 & (uintptr_t)4;
             _23085 = MAKE_UINT(tu);
        }
    }
    else {
        _23085 = binary_op(AND_BITS, _23084, 4);
    }
    _23084 = NOVALUE;
    if (_23085 == 0) {
        DeRef(_23085);
        _23085 = NOVALUE;
        goto L3; // [114] 124
    }
    else {
        if (!IS_ATOM_INT(_23085) && DBL_PTR(_23085)->dbl == 0.0){
            DeRef(_23085);
            _23085 = NOVALUE;
            goto L3; // [114] 124
        }
        DeRef(_23085);
        _23085 = NOVALUE;
    }
    DeRef(_23085);
    _23085 = NOVALUE;

    /** c_decl.e:1170				return 1*/
    DeRef(_eentry_44290);
    DeRef(_23080);
    _23080 = NOVALUE;
    _23083 = NOVALUE;
    DeRef(_23076);
    _23076 = NOVALUE;
    return 1;
L3: 
L1: 

    /** c_decl.e:1174		return 0*/
    DeRef(_eentry_44290);
    DeRef(_23080);
    _23080 = NOVALUE;
    _23083 = NOVALUE;
    DeRef(_23076);
    _23076 = NOVALUE;
    return 0;
    ;
}


void _57version()
{
    object _23119 = NOVALUE;
    object _23118 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1207		c_puts("// Euphoria To C version " & version_string() & "\n")*/
    _23118 = _40version_string(0);
    {
        object concat_list[3];

        concat_list[0] = _22210;
        concat_list[1] = _23118;
        concat_list[2] = _23117;
        Concat_N((object_ptr)&_23119, concat_list, 3);
    }
    DeRef(_23118);
    _23118 = NOVALUE;
    _54c_puts(_23119);
    _23119 = NOVALUE;

    /** c_decl.e:1208	end procedure*/
    return;
    ;
}


void _57new_c_file(object _name_44397)
{
    object _23122 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1213		cfile_size = 0*/
    _12cfile_size_20306 = 0;

    /** c_decl.e:1216		if LAST_PASS = FALSE then*/
    if (_57LAST_PASS_42577 != _9FALSE_444)
    goto L1; // [16] 26

    /** c_decl.e:1217			return*/
    DeRefDS(_name_44397);
    return;
L1: 

    /** c_decl.e:1220		write_checksum( c_code )*/
    _55write_checksum(_54c_code_46650);

    /** c_decl.e:1221		close(c_code)*/
    EClose(_54c_code_46650);

    /** c_decl.e:1223		c_code = open(output_dir & name & ".c", "w")*/
    {
        object concat_list[3];

        concat_list[0] = _23121;
        concat_list[1] = _name_44397;
        concat_list[2] = _57output_dir_42604;
        Concat_N((object_ptr)&_23122, concat_list, 3);
    }
    _54c_code_46650 = EOpen(_23122, _22151, 0);
    DeRefDS(_23122);
    _23122 = NOVALUE;

    /** c_decl.e:1224		if c_code = -1 then*/
    if (_54c_code_46650 != -1)
    goto L2; // [60] 74

    /** c_decl.e:1225			CompileErr(COULDNT_OPEN_C_FILE_FOR_OUTPUT)*/
    RefDS(_22015);
    _49CompileErr(57, _22015, 0);
L2: 

    /** c_decl.e:1228		cfile_count += 1*/
    _12cfile_count_20305 = _12cfile_count_20305 + 1;

    /** c_decl.e:1229		version()*/
    _57version();

    /** c_decl.e:1231		c_puts("#include \"include/euphoria.h\"\n")*/
    RefDS(_22156);
    _54c_puts(_22156);

    /** c_decl.e:1233		c_puts("#include \"main-.h\"\n\n")*/
    RefDS(_22157);
    _54c_puts(_22157);

    /** c_decl.e:1235		if not TUNIX then*/
    if (_44TUNIX_20374 != 0)
    goto L3; // [102] 114

    /** c_decl.e:1236			name = lower(name)  -- for faster compare later*/
    RefDS(_name_44397);
    _0 = _name_44397;
    _name_44397 = _18lower(_name_44397);
    DeRefDS(_0);
L3: 

    /** c_decl.e:1238	end procedure*/
    DeRefDS(_name_44397);
    return;
    ;
}


object _57unique_c_name(object _name_44427)
{
    object _i_44428 = NOVALUE;
    object _compare_name_44429 = NOVALUE;
    object _next_fc_44430 = NOVALUE;
    object _23138 = NOVALUE;
    object _23136 = NOVALUE;
    object _23135 = NOVALUE;
    object _23134 = NOVALUE;
    object _23132 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1253		compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_44429, _name_44427, _23121);

    /** c_decl.e:1254		if not TUNIX then*/
    if (_44TUNIX_20374 != 0)
    goto L1; // [13] 25

    /** c_decl.e:1255			compare_name = lower(compare_name)*/
    RefDS(_compare_name_44429);
    _0 = _compare_name_44429;
    _compare_name_44429 = _18lower(_compare_name_44429);
    DeRefDS(_0);
L1: 

    /** c_decl.e:1258		next_fc = 1*/
    _next_fc_44430 = 1;

    /** c_decl.e:1259		i = 1*/
    _i_44428 = 1;

    /** c_decl.e:1261		while i <= length(generated_files) do*/
L2: 
    if (IS_SEQUENCE(_57generated_files_42594)){
            _23132 = SEQ_PTR(_57generated_files_42594)->length;
    }
    else {
        _23132 = 1;
    }
    if (_i_44428 > _23132)
    goto L3; // [45] 141

    /** c_decl.e:1263			if equal(generated_files[i], compare_name) then*/
    _2 = (object)SEQ_PTR(_57generated_files_42594);
    _23134 = (object)*(((s1_ptr)_2)->base + _i_44428);
    if (_23134 == _compare_name_44429)
    _23135 = 1;
    else if (IS_ATOM_INT(_23134) && IS_ATOM_INT(_compare_name_44429))
    _23135 = 0;
    else
    _23135 = (compare(_23134, _compare_name_44429) == 0);
    _23134 = NOVALUE;
    if (_23135 == 0)
    {
        _23135 = NOVALUE;
        goto L4; // [61] 129
    }
    else{
        _23135 = NOVALUE;
    }

    /** c_decl.e:1265				if next_fc > length(file_chars) then*/
    if (IS_SEQUENCE(_57file_chars_44423)){
            _23136 = SEQ_PTR(_57file_chars_44423)->length;
    }
    else {
        _23136 = 1;
    }
    if (_next_fc_44430 <= _23136)
    goto L5; // [69] 83

    /** c_decl.e:1266					CompileErr(SORRY_TOO_MANY_C_FILES_WITH_THE_SAME_BASE_NAME)*/
    RefDS(_22015);
    _49CompileErr(140, _22015, 0);
L5: 

    /** c_decl.e:1269				name[1] = file_chars[next_fc]*/
    _2 = (object)SEQ_PTR(_57file_chars_44423);
    _23138 = (object)*(((s1_ptr)_2)->base + _next_fc_44430);
    Ref(_23138);
    _2 = (object)SEQ_PTR(_name_44427);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _name_44427 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23138;
    if( _1 != _23138 ){
        DeRef(_1);
    }
    _23138 = NOVALUE;

    /** c_decl.e:1270				compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_44429, _name_44427, _23121);

    /** c_decl.e:1271				if not TUNIX then*/
    if (_44TUNIX_20374 != 0)
    goto L6; // [103] 115

    /** c_decl.e:1272					compare_name = lower(compare_name)*/
    RefDS(_compare_name_44429);
    _0 = _compare_name_44429;
    _compare_name_44429 = _18lower(_compare_name_44429);
    DeRefDS(_0);
L6: 

    /** c_decl.e:1275				next_fc += 1*/
    _next_fc_44430 = _next_fc_44430 + 1;

    /** c_decl.e:1276				i = 1 -- start over and compare again*/
    _i_44428 = 1;
    goto L2; // [126] 40
L4: 

    /** c_decl.e:1279				i += 1*/
    _i_44428 = _i_44428 + 1;

    /** c_decl.e:1281		end while*/
    goto L2; // [138] 40
L3: 

    /** c_decl.e:1283		return name*/
    DeRef(_compare_name_44429);
    return _name_44427;
    ;
}


object _57is_file_newer(object _f1_44460, object _f2_44461)
{
    object _d1_44462 = NOVALUE;
    object _d2_44465 = NOVALUE;
    object _diff_2__tmp_at42_44476 = NOVALUE;
    object _diff_1__tmp_at42_44475 = NOVALUE;
    object _diff_inlined_diff_at_42_44474 = NOVALUE;
    object _23148 = NOVALUE;
    object _23146 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1287		object d1 = file_timestamp(f1)*/
    RefDS(_f1_44460);
    _0 = _d1_44462;
    _d1_44462 = _14file_timestamp(_f1_44460);
    DeRef(_0);

    /** c_decl.e:1288		object d2 = file_timestamp(f2)*/
    RefDS(_f2_44461);
    _0 = _d2_44465;
    _d2_44465 = _14file_timestamp(_f2_44461);
    DeRef(_0);

    /** c_decl.e:1290		if atom(d1) or atom(d2) then return 1 end if*/
    _23146 = IS_ATOM(_d1_44462);
    if (_23146 != 0) {
        goto L1; // [22] 34
    }
    _23148 = IS_ATOM(_d2_44465);
    if (_23148 == 0)
    {
        _23148 = NOVALUE;
        goto L2; // [30] 39
    }
    else{
        _23148 = NOVALUE;
    }
L1: 
    DeRefDS(_f1_44460);
    DeRefDS(_f2_44461);
    DeRef(_d1_44462);
    DeRef(_d2_44465);
    return 1;
L2: 

    /** c_decl.e:1291		if datetime:diff(d1, d2) < 0 then*/

    /** datetime.e:1253		return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_44465);
    _0 = _diff_1__tmp_at42_44475;
    _diff_1__tmp_at42_44475 = _15datetimeToSeconds(_d2_44465);
    DeRef(_0);
    Ref(_d1_44462);
    _0 = _diff_2__tmp_at42_44476;
    _diff_2__tmp_at42_44476 = _15datetimeToSeconds(_d1_44462);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_42_44474);
    if (IS_ATOM_INT(_diff_1__tmp_at42_44475) && IS_ATOM_INT(_diff_2__tmp_at42_44476)) {
        _diff_inlined_diff_at_42_44474 = _diff_1__tmp_at42_44475 - _diff_2__tmp_at42_44476;
        if ((object)((uintptr_t)_diff_inlined_diff_at_42_44474 +(uintptr_t) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_42_44474 = NewDouble((eudouble)_diff_inlined_diff_at_42_44474);
        }
    }
    else {
        _diff_inlined_diff_at_42_44474 = binary_op(MINUS, _diff_1__tmp_at42_44475, _diff_2__tmp_at42_44476);
    }
    DeRef(_diff_1__tmp_at42_44475);
    _diff_1__tmp_at42_44475 = NOVALUE;
    DeRef(_diff_2__tmp_at42_44476);
    _diff_2__tmp_at42_44476 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_42_44474, 0)){
        goto L3; // [58] 69
    }

    /** c_decl.e:1292			return 1*/
    DeRefDS(_f1_44460);
    DeRefDS(_f2_44461);
    DeRef(_d1_44462);
    DeRef(_d2_44465);
    return 1;
L3: 

    /** c_decl.e:1295		return 0*/
    DeRefDS(_f1_44460);
    DeRefDS(_f2_44461);
    DeRef(_d1_44462);
    DeRef(_d2_44465);
    return 0;
    ;
}


void _57add_file(object _filename_44480, object _eu_filename_44481)
{
    object _obj_fname_44501 = NOVALUE;
    object _src_fname_44502 = NOVALUE;
    object _23172 = NOVALUE;
    object _23171 = NOVALUE;
    object _23158 = NOVALUE;
    object _23157 = NOVALUE;
    object _23154 = NOVALUE;
    object _23153 = NOVALUE;
    object _23152 = NOVALUE;
    object _23151 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1303		if equal("c", fileext(filename)) then*/
    RefDS(_filename_44480);
    _23151 = _14fileext(_filename_44480);
    if (_23150 == _23151)
    _23152 = 1;
    else if (IS_ATOM_INT(_23150) && IS_ATOM_INT(_23151))
    _23152 = 0;
    else
    _23152 = (compare(_23150, _23151) == 0);
    DeRef(_23151);
    _23151 = NOVALUE;
    if (_23152 == 0)
    {
        _23152 = NOVALUE;
        goto L1; // [15] 35
    }
    else{
        _23152 = NOVALUE;
    }

    /** c_decl.e:1304			filename = filename[1..$-2]*/
    if (IS_SEQUENCE(_filename_44480)){
            _23153 = SEQ_PTR(_filename_44480)->length;
    }
    else {
        _23153 = 1;
    }
    _23154 = _23153 - 2;
    _23153 = NOVALUE;
    rhs_slice_target = (object_ptr)&_filename_44480;
    RHS_Slice(_filename_44480, 1, _23154);
    goto L2; // [32] 82
L1: 

    /** c_decl.e:1305		elsif equal("h", fileext(filename)) then*/
    RefDS(_filename_44480);
    _23157 = _14fileext(_filename_44480);
    if (_23156 == _23157)
    _23158 = 1;
    else if (IS_ATOM_INT(_23156) && IS_ATOM_INT(_23157))
    _23158 = 0;
    else
    _23158 = (compare(_23156, _23157) == 0);
    DeRef(_23157);
    _23157 = NOVALUE;
    if (_23158 == 0)
    {
        _23158 = NOVALUE;
        goto L3; // [45] 81
    }
    else{
        _23158 = NOVALUE;
    }

    /** c_decl.e:1306			generated_files = append(generated_files, filename)*/
    RefDS(_filename_44480);
    Append(&_57generated_files_42594, _57generated_files_42594, _filename_44480);

    /** c_decl.e:1307			if build_system_type = BUILD_DIRECT then*/

    /** c_decl.e:1308				outdated_files  = append(outdated_files, 0)*/
    Append(&_57outdated_files_42595, _57outdated_files_42595, 0);

    /** c_decl.e:1311			return*/
    DeRefDS(_filename_44480);
    DeRefDS(_eu_filename_44481);
    DeRef(_obj_fname_44501);
    DeRef(_src_fname_44502);
    DeRef(_23154);
    _23154 = NOVALUE;
    return;
L3: 
L2: 

    /** c_decl.e:1314		sequence obj_fname = filename, src_fname = filename & ".c"*/
    RefDS(_filename_44480);
    DeRef(_obj_fname_44501);
    _obj_fname_44501 = _filename_44480;
    Concat((object_ptr)&_src_fname_44502, _filename_44480, _23121);

    /** c_decl.e:1316		if compiler_type = COMPILER_WATCOM then*/

    /** c_decl.e:1319			obj_fname &= ".o"*/
    Concat((object_ptr)&_obj_fname_44501, _obj_fname_44501, _23166);

    /** c_decl.e:1322		generated_files = append(generated_files, src_fname)*/
    RefDS(_src_fname_44502);
    Append(&_57generated_files_42594, _57generated_files_42594, _src_fname_44502);

    /** c_decl.e:1323		generated_files = append(generated_files, obj_fname)*/
    RefDS(_obj_fname_44501);
    Append(&_57generated_files_42594, _57generated_files_42594, _obj_fname_44501);

    /** c_decl.e:1324		if build_system_type = BUILD_DIRECT then*/

    /** c_decl.e:1325			outdated_files  = append(outdated_files, is_file_newer(eu_filename, output_dir & src_fname))*/
    Concat((object_ptr)&_23171, _57output_dir_42604, _src_fname_44502);
    RefDS(_eu_filename_44481);
    _23172 = _57is_file_newer(_eu_filename_44481, _23171);
    _23171 = NOVALUE;
    Ref(_23172);
    Append(&_57outdated_files_42595, _57outdated_files_42595, _23172);
    DeRef(_23172);
    _23172 = NOVALUE;

    /** c_decl.e:1326			outdated_files  = append(outdated_files, 0)*/
    Append(&_57outdated_files_42595, _57outdated_files_42595, 0);

    /** c_decl.e:1328	end procedure*/
    DeRefDS(_filename_44480);
    DeRefDS(_eu_filename_44481);
    DeRef(_obj_fname_44501);
    DeRef(_src_fname_44502);
    DeRef(_23154);
    _23154 = NOVALUE;
    return;
    ;
}


object _57any_code(object _file_no_44525)
{
    object _these_routines_44527 = NOVALUE;
    object _s_44534 = NOVALUE;
    object _23188 = NOVALUE;
    object _23187 = NOVALUE;
    object _23186 = NOVALUE;
    object _23185 = NOVALUE;
    object _23184 = NOVALUE;
    object _23183 = NOVALUE;
    object _23182 = NOVALUE;
    object _23181 = NOVALUE;
    object _23180 = NOVALUE;
    object _23179 = NOVALUE;
    object _23178 = NOVALUE;
    object _23176 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1334		check_file_routines()*/
    _57check_file_routines();

    /** c_decl.e:1336		sequence these_routines = file_routines[file_no]*/
    DeRef(_these_routines_44527);
    _2 = (object)SEQ_PTR(_57file_routines_44752);
    _these_routines_44527 = (object)*(((s1_ptr)_2)->base + _file_no_44525);
    Ref(_these_routines_44527);

    /** c_decl.e:1337		for i = 1 to length( these_routines ) do*/
    if (IS_SEQUENCE(_these_routines_44527)){
            _23176 = SEQ_PTR(_these_routines_44527)->length;
    }
    else {
        _23176 = 1;
    }
    {
        object _i_44531;
        _i_44531 = 1;
L1: 
        if (_i_44531 > _23176){
            goto L2; // [22] 126
        }

        /** c_decl.e:1338			symtab_index s = these_routines[i]*/
        _2 = (object)SEQ_PTR(_these_routines_44527);
        _s_44534 = (object)*(((s1_ptr)_2)->base + _i_44531);
        if (!IS_ATOM_INT(_s_44534)){
            _s_44534 = (object)DBL_PTR(_s_44534)->dbl;
        }

        /** c_decl.e:1339			if SymTab[s][S_FILE_NO] = file_no and*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _23178 = (object)*(((s1_ptr)_2)->base + _s_44534);
        _2 = (object)SEQ_PTR(_23178);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _23179 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _23179 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _23178 = NOVALUE;
        if (IS_ATOM_INT(_23179)) {
            _23180 = (_23179 == _file_no_44525);
        }
        else {
            _23180 = binary_op(EQUALS, _23179, _file_no_44525);
        }
        _23179 = NOVALUE;
        if (IS_ATOM_INT(_23180)) {
            if (_23180 == 0) {
                DeRef(_23181);
                _23181 = 0;
                goto L3; // [55] 81
            }
        }
        else {
            if (DBL_PTR(_23180)->dbl == 0.0) {
                DeRef(_23181);
                _23181 = 0;
                goto L3; // [55] 81
            }
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _23182 = (object)*(((s1_ptr)_2)->base + _s_44534);
        _2 = (object)SEQ_PTR(_23182);
        _23183 = (object)*(((s1_ptr)_2)->base + 5);
        _23182 = NOVALUE;
        if (IS_ATOM_INT(_23183)) {
            _23184 = (_23183 != 99);
        }
        else {
            _23184 = binary_op(NOTEQ, _23183, 99);
        }
        _23183 = NOVALUE;
        DeRef(_23181);
        if (IS_ATOM_INT(_23184))
        _23181 = (_23184 != 0);
        else
        _23181 = DBL_PTR(_23184)->dbl != 0.0;
L3: 
        if (_23181 == 0) {
            goto L4; // [81] 117
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _23186 = (object)*(((s1_ptr)_2)->base + _s_44534);
        _2 = (object)SEQ_PTR(_23186);
        if (!IS_ATOM_INT(_12S_TOKEN_19869)){
            _23187 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
        }
        else{
            _23187 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
        }
        _23186 = NOVALUE;
        _23188 = find_from(_23187, _29RTN_TOKS_12006, 1);
        _23187 = NOVALUE;
        if (_23188 == 0)
        {
            _23188 = NOVALUE;
            goto L4; // [105] 117
        }
        else{
            _23188 = NOVALUE;
        }

        /** c_decl.e:1342				return TRUE -- found a non-deleted routine in this file*/
        DeRef(_these_routines_44527);
        DeRef(_23184);
        _23184 = NOVALUE;
        DeRef(_23180);
        _23180 = NOVALUE;
        return _9TRUE_446;
L4: 

        /** c_decl.e:1344		end for*/
        _i_44531 = _i_44531 + 1;
        goto L1; // [121] 29
L2: 
        ;
    }

    /** c_decl.e:1345		return FALSE*/
    DeRef(_these_routines_44527);
    DeRef(_23184);
    _23184 = NOVALUE;
    DeRef(_23180);
    _23180 = NOVALUE;
    return _9FALSE_444;
    ;
}


void _57check_file_routines()
{
    object _s_44761 = NOVALUE;
    object _23350 = NOVALUE;
    object _23349 = NOVALUE;
    object _23348 = NOVALUE;
    object _23347 = NOVALUE;
    object _23346 = NOVALUE;
    object _23345 = NOVALUE;
    object _23344 = NOVALUE;
    object _23343 = NOVALUE;
    object _23342 = NOVALUE;
    object _23341 = NOVALUE;
    object _23340 = NOVALUE;
    object _23339 = NOVALUE;
    object _23337 = NOVALUE;
    object _23335 = NOVALUE;
    object _23333 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1451		if not length( file_routines ) then*/
    if (IS_SEQUENCE(_57file_routines_44752)){
            _23333 = SEQ_PTR(_57file_routines_44752)->length;
    }
    else {
        _23333 = 1;
    }
    if (_23333 != 0)
    goto L1; // [8] 146
    _23333 = NOVALUE;

    /** c_decl.e:1452			file_routines = repeat( {}, length( known_files ) )*/
    if (IS_SEQUENCE(_13known_files_11317)){
            _23335 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _23335 = 1;
    }
    DeRefDS(_57file_routines_44752);
    _57file_routines_44752 = Repeat(_22015, _23335);
    _23335 = NOVALUE;

    /** c_decl.e:1453			integer s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _23337 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    _2 = (object)SEQ_PTR(_23337);
    _s_44761 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_44761)){
        _s_44761 = (object)DBL_PTR(_s_44761)->dbl;
    }
    _23337 = NOVALUE;

    /** c_decl.e:1454			while s do*/
L2: 
    if (_s_44761 == 0)
    {
        goto L3; // [45] 145
    }
    else{
    }

    /** c_decl.e:1455				if SymTab[s][S_USAGE] != U_DELETED and*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _23339 = (object)*(((s1_ptr)_2)->base + _s_44761);
    _2 = (object)SEQ_PTR(_23339);
    _23340 = (object)*(((s1_ptr)_2)->base + 5);
    _23339 = NOVALUE;
    if (IS_ATOM_INT(_23340)) {
        _23341 = (_23340 != 99);
    }
    else {
        _23341 = binary_op(NOTEQ, _23340, 99);
    }
    _23340 = NOVALUE;
    if (IS_ATOM_INT(_23341)) {
        if (_23341 == 0) {
            goto L4; // [68] 124
        }
    }
    else {
        if (DBL_PTR(_23341)->dbl == 0.0) {
            goto L4; // [68] 124
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _23343 = (object)*(((s1_ptr)_2)->base + _s_44761);
    _2 = (object)SEQ_PTR(_23343);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _23344 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _23344 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _23343 = NOVALUE;
    _23345 = find_from(_23344, _29RTN_TOKS_12006, 1);
    _23344 = NOVALUE;
    if (_23345 == 0)
    {
        _23345 = NOVALUE;
        goto L4; // [92] 124
    }
    else{
        _23345 = NOVALUE;
    }

    /** c_decl.e:1458					file_routines[SymTab[s][S_FILE_NO]] &= s*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _23346 = (object)*(((s1_ptr)_2)->base + _s_44761);
    _2 = (object)SEQ_PTR(_23346);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _23347 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _23347 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _23346 = NOVALUE;
    _2 = (object)SEQ_PTR(_57file_routines_44752);
    if (!IS_ATOM_INT(_23347)){
        _23348 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23347)->dbl));
    }
    else{
        _23348 = (object)*(((s1_ptr)_2)->base + _23347);
    }
    if (IS_SEQUENCE(_23348) && IS_ATOM(_s_44761)) {
        Append(&_23349, _23348, _s_44761);
    }
    else if (IS_ATOM(_23348) && IS_SEQUENCE(_s_44761)) {
    }
    else {
        Concat((object_ptr)&_23349, _23348, _s_44761);
        _23348 = NOVALUE;
    }
    _23348 = NOVALUE;
    _2 = (object)SEQ_PTR(_57file_routines_44752);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _57file_routines_44752 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_23347))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_23347)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _23347);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23349;
    if( _1 != _23349 ){
        DeRef(_1);
    }
    _23349 = NOVALUE;
L4: 

    /** c_decl.e:1460				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _23350 = (object)*(((s1_ptr)_2)->base + _s_44761);
    _2 = (object)SEQ_PTR(_23350);
    _s_44761 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_44761)){
        _s_44761 = (object)DBL_PTR(_s_44761)->dbl;
    }
    _23350 = NOVALUE;

    /** c_decl.e:1461			end while*/
    goto L2; // [142] 45
L3: 
L1: 

    /** c_decl.e:1464	end procedure*/
    _23347 = NOVALUE;
    DeRef(_23341);
    _23341 = NOVALUE;
    return;
    ;
}


void _57GenerateUserRoutines()
{
    object _s_44795 = NOVALUE;
    object _sp_44796 = NOVALUE;
    object _next_c_char_44797 = NOVALUE;
    object _q_44798 = NOVALUE;
    object _temps_44799 = NOVALUE;
    object _buff_44800 = NOVALUE;
    object _base_name_44801 = NOVALUE;
    object _long_c_file_44802 = NOVALUE;
    object _c_file_44803 = NOVALUE;
    object _these_routines_44874 = NOVALUE;
    object _ret_type_44932 = NOVALUE;
    object _s_scope_44941 = NOVALUE;
    object _s_file_44944 = NOVALUE;
    object _scope_45021 = NOVALUE;
    object _names_45055 = NOVALUE;
    object _name_45065 = NOVALUE;
    object _23586 = NOVALUE;
    object _23584 = NOVALUE;
    object _23583 = NOVALUE;
    object _23543 = NOVALUE;
    object _23542 = NOVALUE;
    object _23540 = NOVALUE;
    object _23538 = NOVALUE;
    object _23537 = NOVALUE;
    object _23536 = NOVALUE;
    object _23535 = NOVALUE;
    object _23534 = NOVALUE;
    object _23533 = NOVALUE;
    object _23532 = NOVALUE;
    object _23530 = NOVALUE;
    object _23529 = NOVALUE;
    object _23528 = NOVALUE;
    object _23527 = NOVALUE;
    object _23526 = NOVALUE;
    object _23525 = NOVALUE;
    object _23524 = NOVALUE;
    object _23523 = NOVALUE;
    object _23521 = NOVALUE;
    object _23520 = NOVALUE;
    object _23518 = NOVALUE;
    object _23517 = NOVALUE;
    object _23516 = NOVALUE;
    object _23515 = NOVALUE;
    object _23514 = NOVALUE;
    object _23513 = NOVALUE;
    object _23512 = NOVALUE;
    object _23511 = NOVALUE;
    object _23509 = NOVALUE;
    object _23508 = NOVALUE;
    object _23506 = NOVALUE;
    object _23505 = NOVALUE;
    object _23504 = NOVALUE;
    object _23502 = NOVALUE;
    object _23497 = NOVALUE;
    object _23496 = NOVALUE;
    object _23494 = NOVALUE;
    object _23492 = NOVALUE;
    object _23486 = NOVALUE;
    object _23485 = NOVALUE;
    object _23484 = NOVALUE;
    object _23483 = NOVALUE;
    object _23482 = NOVALUE;
    object _23481 = NOVALUE;
    object _23480 = NOVALUE;
    object _23479 = NOVALUE;
    object _23477 = NOVALUE;
    object _23476 = NOVALUE;
    object _23474 = NOVALUE;
    object _23473 = NOVALUE;
    object _23470 = NOVALUE;
    object _23468 = NOVALUE;
    object _23467 = NOVALUE;
    object _23466 = NOVALUE;
    object _23462 = NOVALUE;
    object _23459 = NOVALUE;
    object _23456 = NOVALUE;
    object _23455 = NOVALUE;
    object _23454 = NOVALUE;
    object _23453 = NOVALUE;
    object _23451 = NOVALUE;
    object _23450 = NOVALUE;
    object _23448 = NOVALUE;
    object _23447 = NOVALUE;
    object _23446 = NOVALUE;
    object _23441 = NOVALUE;
    object _23440 = NOVALUE;
    object _23439 = NOVALUE;
    object _23438 = NOVALUE;
    object _23437 = NOVALUE;
    object _23436 = NOVALUE;
    object _23435 = NOVALUE;
    object _23434 = NOVALUE;
    object _23433 = NOVALUE;
    object _23432 = NOVALUE;
    object _23431 = NOVALUE;
    object _23430 = NOVALUE;
    object _23429 = NOVALUE;
    object _23428 = NOVALUE;
    object _23427 = NOVALUE;
    object _23425 = NOVALUE;
    object _23422 = NOVALUE;
    object _23421 = NOVALUE;
    object _23419 = NOVALUE;
    object _23416 = NOVALUE;
    object _23415 = NOVALUE;
    object _23411 = NOVALUE;
    object _23410 = NOVALUE;
    object _23408 = NOVALUE;
    object _23404 = NOVALUE;
    object _23403 = NOVALUE;
    object _23402 = NOVALUE;
    object _23401 = NOVALUE;
    object _23400 = NOVALUE;
    object _23399 = NOVALUE;
    object _23398 = NOVALUE;
    object _23397 = NOVALUE;
    object _23396 = NOVALUE;
    object _23395 = NOVALUE;
    object _23394 = NOVALUE;
    object _23393 = NOVALUE;
    object _23392 = NOVALUE;
    object _23391 = NOVALUE;
    object _23389 = NOVALUE;
    object _23388 = NOVALUE;
    object _23386 = NOVALUE;
    object _23383 = NOVALUE;
    object _23380 = NOVALUE;
    object _23377 = NOVALUE;
    object _23374 = NOVALUE;
    object _23373 = NOVALUE;
    object _23372 = NOVALUE;
    object _23369 = NOVALUE;
    object _23366 = NOVALUE;
    object _23364 = NOVALUE;
    object _23360 = NOVALUE;
    object _23359 = NOVALUE;
    object _23357 = NOVALUE;
    object _23356 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:1468		integer next_c_char, q, temps*/

    /** c_decl.e:1469		sequence buff, base_name, long_c_file, c_file*/

    /** c_decl.e:1471		if not silent then*/
    if (_12silent_20342 != 0)
    goto L1; // [9] 68

    /** c_decl.e:1472			if Pass = 1 then*/
    if (_57Pass_42579 != 1)
    goto L2; // [16] 31

    /** c_decl.e:1473				ShowMsg(1, TRANSLATING_CODE_PASS,,0)*/
    RefDS(_22015);
    _30ShowMsg(1, 239, _22015, 0);
L2: 

    /** c_decl.e:1476			if LAST_PASS = TRUE then*/
    if (_57LAST_PASS_42577 != _9TRUE_446)
    goto L3; // [37] 54

    /** c_decl.e:1477				ShowMsg(1, MSG__GENERATING)*/
    RefDS(_22015);
    _30ShowMsg(1, 240, _22015, 1);
    goto L4; // [51] 67
L3: 

    /** c_decl.e:1479				ShowMsg(1, MSG_1, Pass, 0)*/
    _30ShowMsg(1, 241, _57Pass_42579, 0);
L4: 
L1: 

    /** c_decl.e:1483		check_file_routines()*/
    _57check_file_routines();

    /** c_decl.e:1485		c_puts("// GenerateUserRoutines\n")*/
    RefDS(_23355);
    _54c_puts(_23355);

    /** c_decl.e:1486		for file_no = 1 to length(known_files) do*/
    if (IS_SEQUENCE(_13known_files_11317)){
            _23356 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _23356 = 1;
    }
    {
        object _file_no_44822;
        _file_no_44822 = 1;
L5: 
        if (_file_no_44822 > _23356){
            goto L6; // [84] 2208
        }

        /** c_decl.e:1487			if file_no = 1 or any_code(file_no) then*/
        _23357 = (_file_no_44822 == 1);
        if (_23357 != 0) {
            goto L7; // [97] 110
        }
        _23359 = _57any_code(_file_no_44822);
        if (_23359 == 0) {
            DeRef(_23359);
            _23359 = NOVALUE;
            goto L8; // [106] 2199
        }
        else {
            if (!IS_ATOM_INT(_23359) && DBL_PTR(_23359)->dbl == 0.0){
                DeRef(_23359);
                _23359 = NOVALUE;
                goto L8; // [106] 2199
            }
            DeRef(_23359);
            _23359 = NOVALUE;
        }
        DeRef(_23359);
        _23359 = NOVALUE;
L7: 

        /** c_decl.e:1490				next_c_char = 1*/
        _next_c_char_44797 = 1;

        /** c_decl.e:1491				base_name = name_ext(known_files[file_no])*/
        _2 = (object)SEQ_PTR(_13known_files_11317);
        _23360 = (object)*(((s1_ptr)_2)->base + _file_no_44822);
        Ref(_23360);
        _0 = _base_name_44801;
        _base_name_44801 = _53name_ext(_23360);
        DeRef(_0);
        _23360 = NOVALUE;

        /** c_decl.e:1492				c_file = base_name*/
        RefDS(_base_name_44801);
        DeRef(_c_file_44803);
        _c_file_44803 = _base_name_44801;

        /** c_decl.e:1494				q = length(c_file)*/
        if (IS_SEQUENCE(_c_file_44803)){
                _q_44798 = SEQ_PTR(_c_file_44803)->length;
        }
        else {
            _q_44798 = 1;
        }

        /** c_decl.e:1495				while q >= 1 do*/
L9: 
        if (_q_44798 < 1)
        goto LA; // [146] 187

        /** c_decl.e:1496					if c_file[q] = '.' then*/
        _2 = (object)SEQ_PTR(_c_file_44803);
        _23364 = (object)*(((s1_ptr)_2)->base + _q_44798);
        if (binary_op_a(NOTEQ, _23364, 46)){
            _23364 = NOVALUE;
            goto LB; // [156] 176
        }
        _23364 = NOVALUE;

        /** c_decl.e:1497						c_file = c_file[1..q-1]*/
        _23366 = _q_44798 - 1;
        rhs_slice_target = (object_ptr)&_c_file_44803;
        RHS_Slice(_c_file_44803, 1, _23366);

        /** c_decl.e:1498						exit*/
        goto LA; // [173] 187
LB: 

        /** c_decl.e:1500					q -= 1*/
        _q_44798 = _q_44798 - 1;

        /** c_decl.e:1501				end while*/
        goto L9; // [184] 146
LA: 

        /** c_decl.e:1503				if find(lower(c_file), {"main-", "init-"})  then*/
        RefDS(_c_file_44803);
        _23369 = _18lower(_c_file_44803);
        RefDS(_23371);
        RefDS(_23370);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23370;
        ((intptr_t *)_2)[2] = _23371;
        _23372 = MAKE_SEQ(_1);
        _23373 = find_from(_23369, _23372, 1);
        DeRef(_23369);
        _23369 = NOVALUE;
        DeRefDS(_23372);
        _23372 = NOVALUE;
        if (_23373 == 0)
        {
            _23373 = NOVALUE;
            goto LC; // [202] 219
        }
        else{
            _23373 = NOVALUE;
        }

        /** c_decl.e:1504					CompileErr(MSG_1_CONFLICTS_WITH_A_FILE_NAME_USED_INTERNALLY_BY_THE_TRANSLATOR, {base_name})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_base_name_44801);
        ((intptr_t*)_2)[1] = _base_name_44801;
        _23374 = MAKE_SEQ(_1);
        _49CompileErr(12, _23374, 0);
        _23374 = NOVALUE;
LC: 

        /** c_decl.e:1507				long_c_file = c_file*/
        RefDS(_c_file_44803);
        DeRef(_long_c_file_44802);
        _long_c_file_44802 = _c_file_44803;

        /** c_decl.e:1508				if LAST_PASS = TRUE then*/
        if (_57LAST_PASS_42577 != _9TRUE_446)
        goto LD; // [232] 257

        /** c_decl.e:1509					c_file = unique_c_name(c_file)*/
        RefDS(_c_file_44803);
        _0 = _c_file_44803;
        _c_file_44803 = _57unique_c_name(_c_file_44803);
        DeRefDS(_0);

        /** c_decl.e:1510					add_file(c_file, known_files[file_no])*/
        _2 = (object)SEQ_PTR(_13known_files_11317);
        _23377 = (object)*(((s1_ptr)_2)->base + _file_no_44822);
        RefDS(_c_file_44803);
        Ref(_23377);
        _57add_file(_c_file_44803, _23377);
        _23377 = NOVALUE;
LD: 

        /** c_decl.e:1513				if file_no = 1 then*/
        if (_file_no_44822 != 1)
        goto LE; // [259] 322

        /** c_decl.e:1515					if LAST_PASS = TRUE then*/
        if (_57LAST_PASS_42577 != _9TRUE_446)
        goto LF; // [269] 314

        /** c_decl.e:1516						add_file("main-")*/
        RefDS(_23370);
        RefDS(_22015);
        _57add_file(_23370, _22015);

        /** c_decl.e:1517						for i = 0 to main_name_num-1 do*/
        _23380 = _54main_name_num_46652 - 1;
        if ((object)((uintptr_t)_23380 +(uintptr_t) HIGH_BITS) >= 0){
            _23380 = NewDouble((eudouble)_23380);
        }
        {
            object _i_44864;
            _i_44864 = 0;
L10: 
            if (binary_op_a(GREATER, _i_44864, _23380)){
                goto L11; // [287] 313
            }

            /** c_decl.e:1518							buff = sprintf("main-%d", i)*/
            DeRefi(_buff_44800);
            _buff_44800 = EPrintf(-9999999, _23381, _i_44864);

            /** c_decl.e:1519							add_file(buff)*/
            RefDS(_buff_44800);
            RefDS(_22015);
            _57add_file(_buff_44800, _22015);

            /** c_decl.e:1520						end for*/
            _0 = _i_44864;
            if (IS_ATOM_INT(_i_44864)) {
                _i_44864 = _i_44864 + 1;
                if ((object)((uintptr_t)_i_44864 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_44864 = NewDouble((eudouble)_i_44864);
                }
            }
            else {
                _i_44864 = binary_op_a(PLUS, _i_44864, 1);
            }
            DeRef(_0);
            goto L10; // [308] 294
L11: 
            ;
            DeRef(_i_44864);
        }
LF: 

        /** c_decl.e:1523					file0 = long_c_file*/
        RefDS(_long_c_file_44802);
        DeRef(_57file0_44558);
        _57file0_44558 = _long_c_file_44802;
LE: 

        /** c_decl.e:1526				new_c_file(c_file)*/
        RefDS(_c_file_44803);
        _57new_c_file(_c_file_44803);

        /** c_decl.e:1528				s = SymTab[TopLevelSub][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _23383 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
        _2 = (object)SEQ_PTR(_23383);
        _s_44795 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_44795)){
            _s_44795 = (object)DBL_PTR(_s_44795)->dbl;
        }
        _23383 = NOVALUE;

        /** c_decl.e:1530				sequence these_routines = file_routines[file_no]*/
        DeRef(_these_routines_44874);
        _2 = (object)SEQ_PTR(_57file_routines_44752);
        _these_routines_44874 = (object)*(((s1_ptr)_2)->base + _file_no_44822);
        Ref(_these_routines_44874);

        /** c_decl.e:1531				for routine_no = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_44874)){
                _23386 = SEQ_PTR(_these_routines_44874)->length;
        }
        else {
            _23386 = 1;
        }
        {
            object _routine_no_44877;
            _routine_no_44877 = 1;
L12: 
            if (_routine_no_44877 > _23386){
                goto L13; // [360] 2198
            }

            /** c_decl.e:1532					s = these_routines[routine_no]*/
            _2 = (object)SEQ_PTR(_these_routines_44874);
            _s_44795 = (object)*(((s1_ptr)_2)->base + _routine_no_44877);
            if (!IS_ATOM_INT(_s_44795)){
                _s_44795 = (object)DBL_PTR(_s_44795)->dbl;
            }

            /** c_decl.e:1533					if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _23388 = (object)*(((s1_ptr)_2)->base + _s_44795);
            _2 = (object)SEQ_PTR(_23388);
            _23389 = (object)*(((s1_ptr)_2)->base + 5);
            _23388 = NOVALUE;
            if (binary_op_a(EQUALS, _23389, 99)){
                _23389 = NOVALUE;
                goto L14; // [391] 2189
            }
            _23389 = NOVALUE;

            /** c_decl.e:1537						if LAST_PASS = TRUE and*/
            _23391 = (_57LAST_PASS_42577 == _9TRUE_446);
            if (_23391 == 0) {
                goto L15; // [405] 601
            }
            _23393 = (_12cfile_size_20306 > 100000);
            if (_23393 != 0) {
                DeRef(_23394);
                _23394 = 1;
                goto L16; // [417] 480
            }
            _23395 = (_s_44795 != _12TopLevelSub_20233);
            if (_23395 == 0) {
                _23396 = 0;
                goto L17; // [427] 447
            }
            _23397 = (100000 % 4) ? NewDouble((eudouble)100000 / 4) : (100000 / 4);
            if (IS_ATOM_INT(_23397)) {
                _23398 = (_12cfile_size_20306 > _23397);
            }
            else {
                _23398 = ((eudouble)_12cfile_size_20306 > DBL_PTR(_23397)->dbl);
            }
            DeRef(_23397);
            _23397 = NOVALUE;
            _23396 = (_23398 != 0);
L17: 
            if (_23396 == 0) {
                _23399 = 0;
                goto L18; // [447] 476
            }
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _23400 = (object)*(((s1_ptr)_2)->base + _s_44795);
            _2 = (object)SEQ_PTR(_23400);
            if (!IS_ATOM_INT(_12S_CODE_19876)){
                _23401 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
            }
            else{
                _23401 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
            }
            _23400 = NOVALUE;
            if (IS_SEQUENCE(_23401)){
                    _23402 = SEQ_PTR(_23401)->length;
            }
            else {
                _23402 = 1;
            }
            _23401 = NOVALUE;
            _23403 = (_23402 > 100000);
            _23402 = NOVALUE;
            _23399 = (_23403 != 0);
L18: 
            DeRef(_23394);
            _23394 = (_23399 != 0);
L16: 
            if (_23394 == 0)
            {
                _23394 = NOVALUE;
                goto L15; // [481] 601
            }
            else{
                _23394 = NOVALUE;
            }

            /** c_decl.e:1546							if length(c_file) = 7 then*/
            if (IS_SEQUENCE(_c_file_44803)){
                    _23404 = SEQ_PTR(_c_file_44803)->length;
            }
            else {
                _23404 = 1;
            }
            if (_23404 != 7)
            goto L19; // [489] 500

            /** c_decl.e:1548								c_file &= " "*/
            Concat((object_ptr)&_c_file_44803, _c_file_44803, _23406);
L19: 

            /** c_decl.e:1551							if length(c_file) >= 8 then*/
            if (IS_SEQUENCE(_c_file_44803)){
                    _23408 = SEQ_PTR(_c_file_44803)->length;
            }
            else {
                _23408 = 1;
            }
            if (_23408 < 8)
            goto L1A; // [505] 528

            /** c_decl.e:1552								c_file[7] = '_'*/
            _2 = (object)SEQ_PTR(_c_file_44803);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_44803 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 7);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 95;
            DeRef(_1);

            /** c_decl.e:1553								c_file[8] = file_chars[next_c_char]*/
            _2 = (object)SEQ_PTR(_57file_chars_44423);
            _23410 = (object)*(((s1_ptr)_2)->base + _next_c_char_44797);
            Ref(_23410);
            _2 = (object)SEQ_PTR(_c_file_44803);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_44803 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 8);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _23410;
            if( _1 != _23410 ){
                DeRef(_1);
            }
            _23410 = NOVALUE;
            goto L1B; // [525] 560
L1A: 

            /** c_decl.e:1556								if find('_', c_file) = 0 then*/
            _23411 = find_from(95, _c_file_44803, 1);
            if (_23411 != 0)
            goto L1C; // [535] 546

            /** c_decl.e:1557									c_file &= "_ "*/
            Concat((object_ptr)&_c_file_44803, _c_file_44803, _23413);
L1C: 

            /** c_decl.e:1560								c_file[$] = file_chars[next_c_char]*/
            if (IS_SEQUENCE(_c_file_44803)){
                    _23415 = SEQ_PTR(_c_file_44803)->length;
            }
            else {
                _23415 = 1;
            }
            _2 = (object)SEQ_PTR(_57file_chars_44423);
            _23416 = (object)*(((s1_ptr)_2)->base + _next_c_char_44797);
            Ref(_23416);
            _2 = (object)SEQ_PTR(_c_file_44803);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_44803 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _23415);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _23416;
            if( _1 != _23416 ){
                DeRef(_1);
            }
            _23416 = NOVALUE;
L1B: 

            /** c_decl.e:1564							c_file = unique_c_name(c_file)*/
            RefDS(_c_file_44803);
            _0 = _c_file_44803;
            _c_file_44803 = _57unique_c_name(_c_file_44803);
            DeRefDS(_0);

            /** c_decl.e:1565							new_c_file(c_file)*/
            RefDS(_c_file_44803);
            _57new_c_file(_c_file_44803);

            /** c_decl.e:1567							next_c_char += 1*/
            _next_c_char_44797 = _next_c_char_44797 + 1;

            /** c_decl.e:1568							if next_c_char > length(file_chars) then*/
            if (IS_SEQUENCE(_57file_chars_44423)){
                    _23419 = SEQ_PTR(_57file_chars_44423)->length;
            }
            else {
                _23419 = 1;
            }
            if (_next_c_char_44797 <= _23419)
            goto L1D; // [584] 594

            /** c_decl.e:1569								next_c_char = 1  -- (unique_c_name will resolve)*/
            _next_c_char_44797 = 1;
L1D: 

            /** c_decl.e:1572							add_file(c_file)*/
            RefDS(_c_file_44803);
            RefDS(_22015);
            _57add_file(_c_file_44803, _22015);
L15: 

            /** c_decl.e:1575						sequence ret_type*/

            /** c_decl.e:1576						if SymTab[s][S_TOKEN] = PROC then*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _23421 = (object)*(((s1_ptr)_2)->base + _s_44795);
            _2 = (object)SEQ_PTR(_23421);
            if (!IS_ATOM_INT(_12S_TOKEN_19869)){
                _23422 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
            }
            else{
                _23422 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
            }
            _23421 = NOVALUE;
            if (binary_op_a(NOTEQ, _23422, 27)){
                _23422 = NOVALUE;
                goto L1E; // [619] 633
            }
            _23422 = NOVALUE;

            /** c_decl.e:1577							ret_type = "void "*/
            RefDS(_22799);
            DeRefi(_ret_type_44932);
            _ret_type_44932 = _22799;
            goto L1F; // [630] 641
L1E: 

            /** c_decl.e:1579							ret_type = "object "*/
            RefDS(_22800);
            DeRefi(_ret_type_44932);
            _ret_type_44932 = _22800;
L1F: 

            /** c_decl.e:1581						integer s_scope = sym_scope( s )*/
            _s_scope_44941 = _53sym_scope(_s_44795);
            if (!IS_ATOM_INT(_s_scope_44941)) {
                _1 = (object)(DBL_PTR(_s_scope_44941)->dbl);
                DeRefDS(_s_scope_44941);
                _s_scope_44941 = _1;
            }

            /** c_decl.e:1582						integer s_file  = SymTab[s][S_FILE_NO]*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _23425 = (object)*(((s1_ptr)_2)->base + _s_44795);
            _2 = (object)SEQ_PTR(_23425);
            if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
                _s_file_44944 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
            }
            else{
                _s_file_44944 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
            }
            if (!IS_ATOM_INT(_s_file_44944)){
                _s_file_44944 = (object)DBL_PTR(_s_file_44944)->dbl;
            }
            _23425 = NOVALUE;

            /** c_decl.e:1583						if dll_option and*/
            if (_57dll_option_42590 == 0) {
                goto L20; // [669] 827
            }
            _23428 = (_s_scope_44941 == 6);
            if (_23428 != 0) {
                DeRef(_23429);
                _23429 = 1;
                goto L21; // [679] 757
            }
            _23430 = (_s_file_44944 == 1);
            if (_23430 == 0) {
                _23431 = 0;
                goto L22; // [687] 715
            }
            _23432 = (_s_scope_44941 == 13);
            if (_23432 != 0) {
                _23433 = 1;
                goto L23; // [697] 711
            }
            _23434 = (_s_scope_44941 == 11);
            _23433 = (_23434 != 0);
L23: 
            _23431 = (_23433 != 0);
L22: 
            if (_23431 != 0) {
                _23435 = 1;
                goto L24; // [715] 753
            }
            _23436 = (_s_scope_44941 == 13);
            if (_23436 == 0) {
                _23437 = 0;
                goto L25; // [725] 749
            }
            _2 = (object)SEQ_PTR(_13include_matrix_11323);
            _23438 = (object)*(((s1_ptr)_2)->base + 1);
            _2 = (object)SEQ_PTR(_23438);
            _23439 = (object)*(((s1_ptr)_2)->base + _s_file_44944);
            _23438 = NOVALUE;
            if (IS_ATOM_INT(_23439)) {
                {uintptr_t tu;
                     tu = (uintptr_t)_23439 & (uintptr_t)4;
                     _23440 = MAKE_UINT(tu);
                }
            }
            else {
                _23440 = binary_op(AND_BITS, _23439, 4);
            }
            _23439 = NOVALUE;
            if (IS_ATOM_INT(_23440))
            _23437 = (_23440 != 0);
            else
            _23437 = DBL_PTR(_23440)->dbl != 0.0;
L25: 
            _23435 = (_23437 != 0);
L24: 
            DeRef(_23429);
            _23429 = (_23435 != 0);
L21: 
            if (_23429 == 0)
            {
                _23429 = NOVALUE;
                goto L20; // [758] 827
            }
            else{
                _23429 = NOVALUE;
            }

            /** c_decl.e:1589							SymTab[s][S_RI_TARGET] = TRUE*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _13SymTab_11316 = MAKE_SEQ(_2);
            }
            _3 = (object)(_s_44795 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 53);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _9TRUE_446;
            DeRef(_1);
            _23441 = NOVALUE;

            /** c_decl.e:1590							LeftSym = TRUE*/
            _57LeftSym_42587 = _9TRUE_446;

            /** c_decl.e:1593							if TWINDOWS then*/

            /** c_decl.e:1596								c_stmt(ret_type & "@(", s)*/
            Concat((object_ptr)&_23446, _ret_type_44932, _23445);
            _57c_stmt(_23446, _s_44795, 0);
            _23446 = NOVALUE;
            goto L26; // [824] 850
L20: 

            /** c_decl.e:1600							LeftSym = TRUE*/
            _57LeftSym_42587 = _9TRUE_446;

            /** c_decl.e:1601							c_stmt( ret_type & "@(", s)*/
            Concat((object_ptr)&_23447, _ret_type_44932, _23445);
            _57c_stmt(_23447, _s_44795, 0);
            _23447 = NOVALUE;
L26: 

            /** c_decl.e:1605						sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _23448 = (object)*(((s1_ptr)_2)->base + _s_44795);
            _2 = (object)SEQ_PTR(_23448);
            _sp_44796 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_44796)){
                _sp_44796 = (object)DBL_PTR(_sp_44796)->dbl;
            }
            _23448 = NOVALUE;

            /** c_decl.e:1606						for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _23450 = (object)*(((s1_ptr)_2)->base + _s_44795);
            _2 = (object)SEQ_PTR(_23450);
            if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
                _23451 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
            }
            else{
                _23451 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
            }
            _23450 = NOVALUE;
            {
                object _p_44991;
                _p_44991 = 1;
L27: 
                if (binary_op_a(GREATER, _p_44991, _23451)){
                    goto L28; // [880] 956
                }

                /** c_decl.e:1607							c_puts("object _")*/
                RefDS(_23452);
                _54c_puts(_23452);

                /** c_decl.e:1608							c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                _23453 = (object)*(((s1_ptr)_2)->base + _sp_44796);
                _2 = (object)SEQ_PTR(_23453);
                if (!IS_ATOM_INT(_12S_NAME_19864)){
                    _23454 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
                }
                else{
                    _23454 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
                }
                _23453 = NOVALUE;
                Ref(_23454);
                _54c_puts(_23454);
                _23454 = NOVALUE;

                /** c_decl.e:1609							if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                _23455 = (object)*(((s1_ptr)_2)->base + _s_44795);
                _2 = (object)SEQ_PTR(_23455);
                if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
                    _23456 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
                }
                else{
                    _23456 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
                }
                _23455 = NOVALUE;
                if (binary_op_a(EQUALS, _p_44991, _23456)){
                    _23456 = NOVALUE;
                    goto L29; // [923] 933
                }
                _23456 = NOVALUE;

                /** c_decl.e:1610								c_puts(", ")*/
                RefDS(_23458);
                _54c_puts(_23458);
L29: 

                /** c_decl.e:1612							sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                _23459 = (object)*(((s1_ptr)_2)->base + _sp_44796);
                _2 = (object)SEQ_PTR(_23459);
                _sp_44796 = (object)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_44796)){
                    _sp_44796 = (object)DBL_PTR(_sp_44796)->dbl;
                }
                _23459 = NOVALUE;

                /** c_decl.e:1613						end for*/
                _0 = _p_44991;
                if (IS_ATOM_INT(_p_44991)) {
                    _p_44991 = _p_44991 + 1;
                    if ((object)((uintptr_t)_p_44991 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_44991 = NewDouble((eudouble)_p_44991);
                    }
                }
                else {
                    _p_44991 = binary_op_a(PLUS, _p_44991, 1);
                }
                DeRef(_0);
                goto L27; // [951] 887
L28: 
                ;
                DeRef(_p_44991);
            }

            /** c_decl.e:1615						c_puts(")\n")*/
            RefDS(_23461);
            _54c_puts(_23461);

            /** c_decl.e:1616						c_stmt0("{\n")*/
            RefDS(_22119);
            _57c_stmt0(_22119);

            /** c_decl.e:1618						NewBB(0, E_ALL_EFFECT, 0)*/
            _57NewBB(0, 1073741823, 0);

            /** c_decl.e:1619						Initializing = TRUE*/
            _12Initializing_20307 = _9TRUE_446;

            /** c_decl.e:1622						while sp do*/
L2A: 
            if (_sp_44796 == 0)
            {
                goto L2B; // [989] 1128
            }
            else{
            }

            /** c_decl.e:1623							integer scope = SymTab[sp][S_SCOPE]*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _23462 = (object)*(((s1_ptr)_2)->base + _sp_44796);
            _2 = (object)SEQ_PTR(_23462);
            _scope_45021 = (object)*(((s1_ptr)_2)->base + 4);
            if (!IS_ATOM_INT(_scope_45021)){
                _scope_45021 = (object)DBL_PTR(_scope_45021)->dbl;
            }
            _23462 = NOVALUE;

            /** c_decl.e:1624							switch scope with fallthru do*/
            _0 = _scope_45021;
            switch ( _0 ){ 

                /** c_decl.e:1625								case SC_LOOP_VAR, SC_UNDEFINED then*/
                case 2:
                case 9:

                /** c_decl.e:1628									break*/
                goto L2C; // [1023] 1105

                /** c_decl.e:1630								case SC_PRIVATE then*/
                case 3:

                /** c_decl.e:1631									c_stmt0("object ")*/
                RefDS(_22800);
                _57c_stmt0(_22800);

                /** c_decl.e:1632									c_puts("_")*/
                RefDS(_22087);
                _54c_puts(_22087);

                /** c_decl.e:1633									c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                _23466 = (object)*(((s1_ptr)_2)->base + _sp_44796);
                _2 = (object)SEQ_PTR(_23466);
                if (!IS_ATOM_INT(_12S_NAME_19864)){
                    _23467 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
                }
                else{
                    _23467 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
                }
                _23466 = NOVALUE;
                Ref(_23467);
                _54c_puts(_23467);
                _23467 = NOVALUE;

                /** c_decl.e:1635									c_puts(" = NOVALUE;\n")*/
                RefDS(_22808);
                _54c_puts(_22808);

                /** c_decl.e:1636									target[MIN] = NOVALUE*/
                Ref(_12NOVALUE_20081);
                _2 = (object)SEQ_PTR(_58target_28420);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28420 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _12NOVALUE_20081;
                DeRef(_1);

                /** c_decl.e:1637									target[MAX] = NOVALUE*/
                Ref(_12NOVALUE_20081);
                _2 = (object)SEQ_PTR(_58target_28420);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28420 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _12NOVALUE_20081;
                DeRef(_1);

                /** c_decl.e:1638									RemoveFromBB( sp )*/
                _57RemoveFromBB(_sp_44796);

                /** c_decl.e:1640									break*/
                goto L2C; // [1092] 1105

                /** c_decl.e:1642								case else*/
                default:

                /** c_decl.e:1643									exit*/
                goto L2B; // [1102] 1128
            ;}L2C: 

            /** c_decl.e:1645							sp = SymTab[sp][S_NEXT]*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _23468 = (object)*(((s1_ptr)_2)->base + _sp_44796);
            _2 = (object)SEQ_PTR(_23468);
            _sp_44796 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_44796)){
                _sp_44796 = (object)DBL_PTR(_sp_44796)->dbl;
            }
            _23468 = NOVALUE;

            /** c_decl.e:1646						end while*/
            goto L2A; // [1125] 989
L2B: 

            /** c_decl.e:1649						temps = SymTab[s][S_TEMPS]*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _23470 = (object)*(((s1_ptr)_2)->base + _s_44795);
            _2 = (object)SEQ_PTR(_23470);
            if (!IS_ATOM_INT(_12S_TEMPS_19909)){
                _temps_44799 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
            }
            else{
                _temps_44799 = (object)*(((s1_ptr)_2)->base + _12S_TEMPS_19909);
            }
            if (!IS_ATOM_INT(_temps_44799)){
                _temps_44799 = (object)DBL_PTR(_temps_44799)->dbl;
            }
            _23470 = NOVALUE;

            /** c_decl.e:1650						sequence names = {}*/
            RefDS(_22015);
            DeRef(_names_45055);
            _names_45055 = _22015;

            /** c_decl.e:1651						while temps != 0 do*/
L2D: 
            if (_temps_44799 == 0)
            goto L2E; // [1156] 1348

            /** c_decl.e:1652							if SymTab[temps][S_SCOPE] != DELETED then*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _23473 = (object)*(((s1_ptr)_2)->base + _temps_44799);
            _2 = (object)SEQ_PTR(_23473);
            _23474 = (object)*(((s1_ptr)_2)->base + 4);
            _23473 = NOVALUE;
            if (binary_op_a(EQUALS, _23474, 2)){
                _23474 = NOVALUE;
                goto L2F; // [1176] 1308
            }
            _23474 = NOVALUE;

            /** c_decl.e:1653								sequence name = sprintf("_%d", SymTab[temps][S_TEMP_NAME] )*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _23476 = (object)*(((s1_ptr)_2)->base + _temps_44799);
            _2 = (object)SEQ_PTR(_23476);
            _23477 = (object)*(((s1_ptr)_2)->base + 34);
            _23476 = NOVALUE;
            DeRefi(_name_45065);
            _name_45065 = EPrintf(-9999999, _22138, _23477);
            _23477 = NOVALUE;

            /** c_decl.e:1654								if temp_name_type[SymTab[temps][S_TEMP_NAME]][T_GTYPE]*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _23479 = (object)*(((s1_ptr)_2)->base + _temps_44799);
            _2 = (object)SEQ_PTR(_23479);
            _23480 = (object)*(((s1_ptr)_2)->base + 34);
            _23479 = NOVALUE;
            _2 = (object)SEQ_PTR(_12temp_name_type_20309);
            if (!IS_ATOM_INT(_23480)){
                _23481 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23480)->dbl));
            }
            else{
                _23481 = (object)*(((s1_ptr)_2)->base + _23480);
            }
            _2 = (object)SEQ_PTR(_23481);
            _23482 = (object)*(((s1_ptr)_2)->base + 1);
            _23481 = NOVALUE;
            if (IS_ATOM_INT(_23482)) {
                _23483 = (_23482 != 0);
            }
            else {
                _23483 = binary_op(NOTEQ, _23482, 0);
            }
            _23482 = NOVALUE;
            if (IS_ATOM_INT(_23483)) {
                if (_23483 == 0) {
                    goto L30; // [1230] 1304
                }
            }
            else {
                if (DBL_PTR(_23483)->dbl == 0.0) {
                    goto L30; // [1230] 1304
                }
            }
            _23485 = find_from(_name_45065, _names_45055, 1);
            _23486 = (_23485 == 0);
            _23485 = NOVALUE;
            if (_23486 == 0)
            {
                DeRef(_23486);
                _23486 = NOVALUE;
                goto L30; // [1243] 1304
            }
            else{
                DeRef(_23486);
                _23486 = NOVALUE;
            }

            /** c_decl.e:1657									c_stmt0("object ")*/
            RefDS(_22800);
            _57c_stmt0(_22800);

            /** c_decl.e:1658									c_puts( name )*/
            RefDS(_name_45065);
            _54c_puts(_name_45065);

            /** c_decl.e:1659									c_puts(" = NOVALUE")*/
            RefDS(_23487);
            _54c_puts(_23487);

            /** c_decl.e:1661									target = {NOVALUE, NOVALUE}*/
            Ref(_12NOVALUE_20081);
            Ref(_12NOVALUE_20081);
            DeRef(_58target_28420);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _12NOVALUE_20081;
            ((intptr_t *)_2)[2] = _12NOVALUE_20081;
            _58target_28420 = MAKE_SEQ(_1);

            /** c_decl.e:1663									SetBBType(temps, TYPE_INTEGER, target, TYPE_OBJECT, 0)*/
            RefDS(_58target_28420);
            _57SetBBType(_temps_44799, 1, _58target_28420, 16, 0);

            /** c_decl.e:1664									ifdef DEBUG then*/

            /** c_decl.e:1667										c_puts(";\n")*/
            RefDS(_22291);
            _54c_puts(_22291);

            /** c_decl.e:1669									names = prepend( names, name )*/
            RefDS(_name_45065);
            Prepend(&_names_45055, _names_45055, _name_45065);
            goto L31; // [1301] 1307
L30: 

            /** c_decl.e:1671									ifdef DEBUG then*/
L31: 
L2F: 
            DeRefi(_name_45065);
            _name_45065 = NOVALUE;

            /** c_decl.e:1677							SymTab[temps][S_GTYPE] = TYPE_OBJECT*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _13SymTab_11316 = MAKE_SEQ(_2);
            }
            _3 = (object)(_temps_44799 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 36);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 16;
            DeRef(_1);
            _23492 = NOVALUE;

            /** c_decl.e:1678							temps = SymTab[temps][S_NEXT]*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _23494 = (object)*(((s1_ptr)_2)->base + _temps_44799);
            _2 = (object)SEQ_PTR(_23494);
            _temps_44799 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_temps_44799)){
                _temps_44799 = (object)DBL_PTR(_temps_44799)->dbl;
            }
            _23494 = NOVALUE;

            /** c_decl.e:1679						end while*/
            goto L2D; // [1345] 1156
L2E: 

            /** c_decl.e:1680						Initializing = FALSE*/
            _12Initializing_20307 = _9FALSE_444;

            /** c_decl.e:1682						if SymTab[s][S_LHS_SUBS2] then*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _23496 = (object)*(((s1_ptr)_2)->base + _s_44795);
            _2 = (object)SEQ_PTR(_23496);
            _23497 = (object)*(((s1_ptr)_2)->base + 37);
            _23496 = NOVALUE;
            if (_23497 == 0) {
                _23497 = NOVALUE;
                goto L32; // [1371] 1384
            }
            else {
                if (!IS_ATOM_INT(_23497) && DBL_PTR(_23497)->dbl == 0.0){
                    _23497 = NOVALUE;
                    goto L32; // [1371] 1384
                }
                _23497 = NOVALUE;
            }
            _23497 = NOVALUE;

            /** c_decl.e:1683							c_stmt0("object _0, _1, _2, _3;\n\n")*/
            RefDS(_23498);
            _57c_stmt0(_23498);

            /** c_decl.e:1684							ifdef DEBUG then*/
            goto L33; // [1381] 1392
L32: 

            /** c_decl.e:1688							c_stmt0("object _0, _1, _2;\n\n")*/
            RefDS(_23500);
            _57c_stmt0(_23500);

            /** c_decl.e:1689							ifdef DEBUG then*/
L33: 

            /** c_decl.e:1696						sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _23502 = (object)*(((s1_ptr)_2)->base + _s_44795);
            _2 = (object)SEQ_PTR(_23502);
            _sp_44796 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_44796)){
                _sp_44796 = (object)DBL_PTR(_sp_44796)->dbl;
            }
            _23502 = NOVALUE;

            /** c_decl.e:1697						for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _23504 = (object)*(((s1_ptr)_2)->base + _s_44795);
            _2 = (object)SEQ_PTR(_23504);
            if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
                _23505 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
            }
            else{
                _23505 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
            }
            _23504 = NOVALUE;
            {
                object _p_45126;
                _p_45126 = 1;
L34: 
                if (binary_op_a(GREATER, _p_45126, _23505)){
                    goto L35; // [1422] 1773
                }

                /** c_decl.e:1698							SymTab[sp][S_ONE_REF] = FALSE*/
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _13SymTab_11316 = MAKE_SEQ(_2);
                }
                _3 = (object)(_sp_44796 + ((s1_ptr)_2)->base);
                _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    *(intptr_t *)_3 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 35);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _9FALSE_444;
                DeRef(_1);
                _23506 = NOVALUE;

                /** c_decl.e:1699							if SymTab[sp][S_ARG_TYPE] = TYPE_SEQUENCE then*/
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                _23508 = (object)*(((s1_ptr)_2)->base + _sp_44796);
                _2 = (object)SEQ_PTR(_23508);
                _23509 = (object)*(((s1_ptr)_2)->base + 43);
                _23508 = NOVALUE;
                if (binary_op_a(NOTEQ, _23509, 8)){
                    _23509 = NOVALUE;
                    goto L36; // [1462] 1526
                }
                _23509 = NOVALUE;

                /** c_decl.e:1700								target[MIN] = SymTab[sp][S_ARG_SEQ_LEN]*/
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                _23511 = (object)*(((s1_ptr)_2)->base + _sp_44796);
                _2 = (object)SEQ_PTR(_23511);
                _23512 = (object)*(((s1_ptr)_2)->base + 51);
                _23511 = NOVALUE;
                Ref(_23512);
                _2 = (object)SEQ_PTR(_58target_28420);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28420 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23512;
                if( _1 != _23512 ){
                    DeRef(_1);
                }
                _23512 = NOVALUE;

                /** c_decl.e:1701								SetBBType(sp, SymTab[sp][S_ARG_TYPE], target,*/
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                _23513 = (object)*(((s1_ptr)_2)->base + _sp_44796);
                _2 = (object)SEQ_PTR(_23513);
                _23514 = (object)*(((s1_ptr)_2)->base + 43);
                _23513 = NOVALUE;
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                _23515 = (object)*(((s1_ptr)_2)->base + _sp_44796);
                _2 = (object)SEQ_PTR(_23515);
                _23516 = (object)*(((s1_ptr)_2)->base + 45);
                _23515 = NOVALUE;
                Ref(_23514);
                RefDS(_58target_28420);
                Ref(_23516);
                _57SetBBType(_sp_44796, _23514, _58target_28420, _23516, 0);
                _23514 = NOVALUE;
                _23516 = NOVALUE;
                goto L37; // [1523] 1750
L36: 

                /** c_decl.e:1704							elsif SymTab[sp][S_ARG_TYPE] = TYPE_INTEGER then*/
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                _23517 = (object)*(((s1_ptr)_2)->base + _sp_44796);
                _2 = (object)SEQ_PTR(_23517);
                _23518 = (object)*(((s1_ptr)_2)->base + 43);
                _23517 = NOVALUE;
                if (binary_op_a(NOTEQ, _23518, 1)){
                    _23518 = NOVALUE;
                    goto L38; // [1542] 1666
                }
                _23518 = NOVALUE;

                /** c_decl.e:1705								if SymTab[sp][S_ARG_MIN] = NOVALUE then*/
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                _23520 = (object)*(((s1_ptr)_2)->base + _sp_44796);
                _2 = (object)SEQ_PTR(_23520);
                _23521 = (object)*(((s1_ptr)_2)->base + 47);
                _23520 = NOVALUE;
                if (binary_op_a(NOTEQ, _23521, _12NOVALUE_20081)){
                    _23521 = NOVALUE;
                    goto L39; // [1562] 1593
                }
                _23521 = NOVALUE;

                /** c_decl.e:1706									target[MIN] = MININT*/
                _2 = (object)SEQ_PTR(_58target_28420);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28420 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = -1073741824;
                DeRef(_1);

                /** c_decl.e:1707									target[MAX] = MAXINT*/
                _2 = (object)SEQ_PTR(_58target_28420);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28420 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = 1073741823;
                DeRef(_1);
                goto L3A; // [1590] 1638
L39: 

                /** c_decl.e:1709									target[MIN] = SymTab[sp][S_ARG_MIN]*/
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                _23523 = (object)*(((s1_ptr)_2)->base + _sp_44796);
                _2 = (object)SEQ_PTR(_23523);
                _23524 = (object)*(((s1_ptr)_2)->base + 47);
                _23523 = NOVALUE;
                Ref(_23524);
                _2 = (object)SEQ_PTR(_58target_28420);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28420 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23524;
                if( _1 != _23524 ){
                    DeRef(_1);
                }
                _23524 = NOVALUE;

                /** c_decl.e:1710									target[MAX] = SymTab[sp][S_ARG_MAX]*/
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                _23525 = (object)*(((s1_ptr)_2)->base + _sp_44796);
                _2 = (object)SEQ_PTR(_23525);
                _23526 = (object)*(((s1_ptr)_2)->base + 48);
                _23525 = NOVALUE;
                Ref(_23526);
                _2 = (object)SEQ_PTR(_58target_28420);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28420 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23526;
                if( _1 != _23526 ){
                    DeRef(_1);
                }
                _23526 = NOVALUE;
L3A: 

                /** c_decl.e:1712								SetBBType(sp, SymTab[sp][S_ARG_TYPE], target, TYPE_OBJECT, 0)*/
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                _23527 = (object)*(((s1_ptr)_2)->base + _sp_44796);
                _2 = (object)SEQ_PTR(_23527);
                _23528 = (object)*(((s1_ptr)_2)->base + 43);
                _23527 = NOVALUE;
                Ref(_23528);
                RefDS(_58target_28420);
                _57SetBBType(_sp_44796, _23528, _58target_28420, 16, 0);
                _23528 = NOVALUE;
                goto L37; // [1663] 1750
L38: 

                /** c_decl.e:1714							elsif SymTab[sp][S_ARG_TYPE] = TYPE_OBJECT then*/
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                _23529 = (object)*(((s1_ptr)_2)->base + _sp_44796);
                _2 = (object)SEQ_PTR(_23529);
                _23530 = (object)*(((s1_ptr)_2)->base + 43);
                _23529 = NOVALUE;
                if (binary_op_a(NOTEQ, _23530, 16)){
                    _23530 = NOVALUE;
                    goto L3B; // [1682] 1724
                }
                _23530 = NOVALUE;

                /** c_decl.e:1716								SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue,*/
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                _23532 = (object)*(((s1_ptr)_2)->base + _sp_44796);
                _2 = (object)SEQ_PTR(_23532);
                _23533 = (object)*(((s1_ptr)_2)->base + 43);
                _23532 = NOVALUE;
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                _23534 = (object)*(((s1_ptr)_2)->base + _sp_44796);
                _2 = (object)SEQ_PTR(_23534);
                _23535 = (object)*(((s1_ptr)_2)->base + 45);
                _23534 = NOVALUE;
                Ref(_23533);
                RefDS(_54novalue_46654);
                Ref(_23535);
                _57SetBBType(_sp_44796, _23533, _54novalue_46654, _23535, 0);
                _23533 = NOVALUE;
                _23535 = NOVALUE;
                goto L37; // [1721] 1750
L3B: 

                /** c_decl.e:1720								SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue, TYPE_OBJECT, 0)*/
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                _23536 = (object)*(((s1_ptr)_2)->base + _sp_44796);
                _2 = (object)SEQ_PTR(_23536);
                _23537 = (object)*(((s1_ptr)_2)->base + 43);
                _23536 = NOVALUE;
                Ref(_23537);
                RefDS(_54novalue_46654);
                _57SetBBType(_sp_44796, _23537, _54novalue_46654, 16, 0);
                _23537 = NOVALUE;
L37: 

                /** c_decl.e:1723							sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                _23538 = (object)*(((s1_ptr)_2)->base + _sp_44796);
                _2 = (object)SEQ_PTR(_23538);
                _sp_44796 = (object)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_44796)){
                    _sp_44796 = (object)DBL_PTR(_sp_44796)->dbl;
                }
                _23538 = NOVALUE;

                /** c_decl.e:1724						end for*/
                _0 = _p_45126;
                if (IS_ATOM_INT(_p_45126)) {
                    _p_45126 = _p_45126 + 1;
                    if ((object)((uintptr_t)_p_45126 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_45126 = NewDouble((eudouble)_p_45126);
                    }
                }
                else {
                    _p_45126 = binary_op_a(PLUS, _p_45126, 1);
                }
                DeRef(_0);
                goto L34; // [1768] 1429
L35: 
                ;
                DeRef(_p_45126);
            }

            /** c_decl.e:1727						call_proc(Execute_id, {s})*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t*)_2)[1] = _s_44795;
            _23540 = MAKE_SEQ(_1);
            _1 = (object)SEQ_PTR(_23540);
            _2 = (object)((s1_ptr)_1)->base;
            _0 = (object)_00[_12Execute_id_20314].addr;
            Ref( *(( (intptr_t*)_2) + 1) );
            (*(intptr_t (*)())_0)(
                                *( ((intptr_t *)_2) + 1)
                                 );
            DeRefDS(_23540);
            _23540 = NOVALUE;

            /** c_decl.e:1729						c_puts("    ;\n}\n")*/
            RefDS(_23541);
            _54c_puts(_23541);

            /** c_decl.e:1730						if dll_option and is_exported( s ) then*/
            if (_57dll_option_42590 == 0) {
                goto L3C; // [1793] 2183
            }
            _23543 = _57is_exported(_s_44795);
            if (_23543 == 0) {
                DeRef(_23543);
                _23543 = NOVALUE;
                goto L3C; // [1802] 2183
            }
            else {
                if (!IS_ATOM_INT(_23543) && DBL_PTR(_23543)->dbl == 0.0){
                    DeRef(_23543);
                    _23543 = NOVALUE;
                    goto L3C; // [1802] 2183
                }
                DeRef(_23543);
                _23543 = NOVALUE;
            }
            DeRef(_23543);
            _23543 = NOVALUE;

            /** c_decl.e:1732							LeftSym = TRUE*/
            _57LeftSym_42587 = _9TRUE_446;

            /** c_decl.e:1733							if TOSX then*/

            /** c_decl.e:1762							elsif TWINDOWS then*/

            /** c_decl.e:1770								c_stmt( ret_type & SymTab[s][S_NAME] & "() __attribute__ ((alias (\"@\")));\n", s )*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _23583 = (object)*(((s1_ptr)_2)->base + _s_44795);
            _2 = (object)SEQ_PTR(_23583);
            if (!IS_ATOM_INT(_12S_NAME_19864)){
                _23584 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
            }
            else{
                _23584 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
            }
            _23583 = NOVALUE;
            {
                object concat_list[3];

                concat_list[0] = _23585;
                concat_list[1] = _23584;
                concat_list[2] = _ret_type_44932;
                Concat_N((object_ptr)&_23586, concat_list, 3);
            }
            _23584 = NOVALUE;
            _57c_stmt(_23586, _s_44795, 0);
            _23586 = NOVALUE;

            /** c_decl.e:1772							LeftSym = FALSE*/
            _57LeftSym_42587 = _9FALSE_444;
L3C: 

            /** c_decl.e:1774						c_puts("\n\n" )*/
            RefDS(_22159);
            _54c_puts(_22159);
L14: 
            DeRefi(_ret_type_44932);
            _ret_type_44932 = NOVALUE;
            DeRef(_names_45055);
            _names_45055 = NOVALUE;

            /** c_decl.e:1776				end for*/
            _routine_no_44877 = _routine_no_44877 + 1;
            goto L12; // [2193] 367
L13: 
            ;
        }
L8: 
        DeRef(_these_routines_44874);
        _these_routines_44874 = NOVALUE;

        /** c_decl.e:1778		end for*/
        _file_no_44822 = _file_no_44822 + 1;
        goto L5; // [2203] 91
L6: 
        ;
    }

    /** c_decl.e:1779	end procedure*/
    DeRefi(_buff_44800);
    DeRef(_base_name_44801);
    DeRef(_long_c_file_44802);
    DeRef(_c_file_44803);
    DeRef(_23428);
    _23428 = NOVALUE;
    DeRef(_23395);
    _23395 = NOVALUE;
    DeRef(_23393);
    _23393 = NOVALUE;
    _23451 = NOVALUE;
    _23480 = NOVALUE;
    DeRef(_23366);
    _23366 = NOVALUE;
    DeRef(_23380);
    _23380 = NOVALUE;
    DeRef(_23403);
    _23403 = NOVALUE;
    DeRef(_23436);
    _23436 = NOVALUE;
    DeRef(_23357);
    _23357 = NOVALUE;
    _23401 = NOVALUE;
    DeRef(_23483);
    _23483 = NOVALUE;
    DeRef(_23391);
    _23391 = NOVALUE;
    DeRef(_23434);
    _23434 = NOVALUE;
    DeRef(_23440);
    _23440 = NOVALUE;
    DeRef(_23432);
    _23432 = NOVALUE;
    DeRef(_23430);
    _23430 = NOVALUE;
    _23505 = NOVALUE;
    DeRef(_23398);
    _23398 = NOVALUE;
    return;
    ;
}



// 0x278F8650
