// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _59compress(object _x_22590)
{
    object _x4_22591 = NOVALUE;
    object _s_22592 = NOVALUE;
    object _12776 = NOVALUE;
    object _12775 = NOVALUE;
    object _12774 = NOVALUE;
    object _12772 = NOVALUE;
    object _12771 = NOVALUE;
    object _12769 = NOVALUE;
    object _12767 = NOVALUE;
    object _12766 = NOVALUE;
    object _12765 = NOVALUE;
    object _12764 = NOVALUE;
    object _12762 = NOVALUE;
    object _12760 = NOVALUE;
    object _12758 = NOVALUE;
    object _12756 = NOVALUE;
    object _12755 = NOVALUE;
    object _12754 = NOVALUE;
    object _12752 = NOVALUE;
    object _12751 = NOVALUE;
    object _12750 = NOVALUE;
    object _12749 = NOVALUE;
    object _12748 = NOVALUE;
    object _12747 = NOVALUE;
    object _12746 = NOVALUE;
    object _12745 = NOVALUE;
    object _12744 = NOVALUE;
    object _12743 = NOVALUE;
    object _12741 = NOVALUE;
    object _12740 = NOVALUE;
    object _12739 = NOVALUE;
    object _12738 = NOVALUE;
    object _12737 = NOVALUE;
    object _12736 = NOVALUE;
    object _12734 = NOVALUE;
    object _12733 = NOVALUE;
    object _12732 = NOVALUE;
    object _12731 = NOVALUE;
    object _12730 = NOVALUE;
    object _12729 = NOVALUE;
    object _12728 = NOVALUE;
    object _12727 = NOVALUE;
    object _12726 = NOVALUE;
    object _0, _1, _2;
    

    /** compress.e:59		if integer(x) then*/
    if (IS_ATOM_INT(_x_22590))
    _12726 = 1;
    else if (IS_ATOM_DBL(_x_22590))
    _12726 = IS_ATOM_INT(DoubleToInt(_x_22590));
    else
    _12726 = 0;
    if (_12726 == 0)
    {
        _12726 = NOVALUE;
        goto L1; // [6] 220
    }
    else{
        _12726 = NOVALUE;
    }

    /** compress.e:60			if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_22590)) {
        _12727 = (_x_22590 >= -2);
    }
    else {
        _12727 = binary_op(GREATEREQ, _x_22590, -2);
    }
    if (IS_ATOM_INT(_12727)) {
        if (_12727 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_12727)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_22590)) {
        _12729 = (_x_22590 <= 244);
    }
    else {
        _12729 = binary_op(LESSEQ, _x_22590, 244);
    }
    if (_12729 == 0) {
        DeRef(_12729);
        _12729 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_12729) && DBL_PTR(_12729)->dbl == 0.0){
            DeRef(_12729);
            _12729 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_12729);
        _12729 = NOVALUE;
    }
    DeRef(_12729);
    _12729 = NOVALUE;

    /** compress.e:61				return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_22590)) {
        _12730 = _x_22590 - -2;
        if ((object)((uintptr_t)_12730 +(uintptr_t) HIGH_BITS) >= 0){
            _12730 = NewDouble((eudouble)_12730);
        }
    }
    else {
        _12730 = binary_op(MINUS, _x_22590, -2);
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _12730;
    _12731 = MAKE_SEQ(_1);
    _12730 = NOVALUE;
    DeRef(_x_22590);
    DeRef(_x4_22591);
    DeRef(_s_22592);
    DeRef(_12727);
    _12727 = NOVALUE;
    return _12731;
    goto L3; // [41] 389
L2: 

    /** compress.e:63			elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_22590)) {
        _12732 = (_x_22590 >= _59MIN2B_22564);
    }
    else {
        _12732 = binary_op(GREATEREQ, _x_22590, _59MIN2B_22564);
    }
    if (IS_ATOM_INT(_12732)) {
        if (_12732 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_12732)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_22590)) {
        _12734 = (_x_22590 <= 32767);
    }
    else {
        _12734 = binary_op(LESSEQ, _x_22590, 32767);
    }
    if (_12734 == 0) {
        DeRef(_12734);
        _12734 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_12734) && DBL_PTR(_12734)->dbl == 0.0){
            DeRef(_12734);
            _12734 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_12734);
        _12734 = NOVALUE;
    }
    DeRef(_12734);
    _12734 = NOVALUE;

    /** compress.e:64				x -= MIN2B*/
    _0 = _x_22590;
    if (IS_ATOM_INT(_x_22590)) {
        _x_22590 = _x_22590 - _59MIN2B_22564;
        if ((object)((uintptr_t)_x_22590 +(uintptr_t) HIGH_BITS) >= 0){
            _x_22590 = NewDouble((eudouble)_x_22590);
        }
    }
    else {
        _x_22590 = binary_op(MINUS, _x_22590, _59MIN2B_22564);
    }
    DeRef(_0);

    /** compress.e:65				return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_22590)) {
        {uintptr_t tu;
             tu = (uintptr_t)_x_22590 & (uintptr_t)255;
             _12736 = MAKE_UINT(tu);
        }
    }
    else {
        _12736 = binary_op(AND_BITS, _x_22590, 255);
    }
    if (IS_ATOM_INT(_x_22590)) {
        if (256 > 0 && _x_22590 >= 0) {
            _12737 = _x_22590 / 256;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_22590 / (eudouble)256);
            if (_x_22590 != MININT)
            _12737 = (object)temp_dbl;
            else
            _12737 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22590, 256);
        _12737 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 247;
    ((intptr_t*)_2)[2] = _12736;
    ((intptr_t*)_2)[3] = _12737;
    _12738 = MAKE_SEQ(_1);
    _12737 = NOVALUE;
    _12736 = NOVALUE;
    DeRef(_x_22590);
    DeRef(_x4_22591);
    DeRef(_s_22592);
    DeRef(_12727);
    _12727 = NOVALUE;
    DeRef(_12732);
    _12732 = NOVALUE;
    DeRef(_12731);
    _12731 = NOVALUE;
    return _12738;
    goto L3; // [94] 389
L4: 

    /** compress.e:67			elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_22590)) {
        _12739 = (_x_22590 >= _59MIN3B_22570);
    }
    else {
        _12739 = binary_op(GREATEREQ, _x_22590, _59MIN3B_22570);
    }
    if (IS_ATOM_INT(_12739)) {
        if (_12739 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_12739)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_22590)) {
        _12741 = (_x_22590 <= 8388607);
    }
    else {
        _12741 = binary_op(LESSEQ, _x_22590, 8388607);
    }
    if (_12741 == 0) {
        DeRef(_12741);
        _12741 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_12741) && DBL_PTR(_12741)->dbl == 0.0){
            DeRef(_12741);
            _12741 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_12741);
        _12741 = NOVALUE;
    }
    DeRef(_12741);
    _12741 = NOVALUE;

    /** compress.e:68				x -= MIN3B*/
    _0 = _x_22590;
    if (IS_ATOM_INT(_x_22590)) {
        _x_22590 = _x_22590 - _59MIN3B_22570;
        if ((object)((uintptr_t)_x_22590 +(uintptr_t) HIGH_BITS) >= 0){
            _x_22590 = NewDouble((eudouble)_x_22590);
        }
    }
    else {
        _x_22590 = binary_op(MINUS, _x_22590, _59MIN3B_22570);
    }
    DeRef(_0);

    /** compress.e:69				return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_22590)) {
        {uintptr_t tu;
             tu = (uintptr_t)_x_22590 & (uintptr_t)255;
             _12743 = MAKE_UINT(tu);
        }
    }
    else {
        _12743 = binary_op(AND_BITS, _x_22590, 255);
    }
    if (IS_ATOM_INT(_x_22590)) {
        if (256 > 0 && _x_22590 >= 0) {
            _12744 = _x_22590 / 256;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_22590 / (eudouble)256);
            if (_x_22590 != MININT)
            _12744 = (object)temp_dbl;
            else
            _12744 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22590, 256);
        _12744 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_12744)) {
        {uintptr_t tu;
             tu = (uintptr_t)_12744 & (uintptr_t)255;
             _12745 = MAKE_UINT(tu);
        }
    }
    else {
        _12745 = binary_op(AND_BITS, _12744, 255);
    }
    DeRef(_12744);
    _12744 = NOVALUE;
    if (IS_ATOM_INT(_x_22590)) {
        if (65536 > 0 && _x_22590 >= 0) {
            _12746 = _x_22590 / 65536;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_22590 / (eudouble)65536);
            if (_x_22590 != MININT)
            _12746 = (object)temp_dbl;
            else
            _12746 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22590, 65536);
        _12746 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 248;
    ((intptr_t*)_2)[2] = _12743;
    ((intptr_t*)_2)[3] = _12745;
    ((intptr_t*)_2)[4] = _12746;
    _12747 = MAKE_SEQ(_1);
    _12746 = NOVALUE;
    _12745 = NOVALUE;
    _12743 = NOVALUE;
    DeRef(_x_22590);
    DeRef(_x4_22591);
    DeRef(_s_22592);
    DeRef(_12727);
    _12727 = NOVALUE;
    DeRef(_12738);
    _12738 = NOVALUE;
    DeRef(_12732);
    _12732 = NOVALUE;
    DeRef(_12739);
    _12739 = NOVALUE;
    DeRef(_12731);
    _12731 = NOVALUE;
    return _12747;
    goto L3; // [156] 389
L5: 

    /** compress.e:71			elsif x >= MIN4B and x <= MAX4B then*/
    if (IS_ATOM_INT(_x_22590) && IS_ATOM_INT(_59MIN4B_22576)) {
        _12748 = (_x_22590 >= _59MIN4B_22576);
    }
    else {
        _12748 = binary_op(GREATEREQ, _x_22590, _59MIN4B_22576);
    }
    if (IS_ATOM_INT(_12748)) {
        if (_12748 == 0) {
            goto L6; // [167] 199
        }
    }
    else {
        if (DBL_PTR(_12748)->dbl == 0.0) {
            goto L6; // [167] 199
        }
    }
    if (IS_ATOM_INT(_x_22590) && IS_ATOM_INT(_59MAX4B_22579)) {
        _12750 = (_x_22590 <= _59MAX4B_22579);
    }
    else {
        _12750 = binary_op(LESSEQ, _x_22590, _59MAX4B_22579);
    }
    if (_12750 == 0) {
        DeRef(_12750);
        _12750 = NOVALUE;
        goto L6; // [178] 199
    }
    else {
        if (!IS_ATOM_INT(_12750) && DBL_PTR(_12750)->dbl == 0.0){
            DeRef(_12750);
            _12750 = NOVALUE;
            goto L6; // [178] 199
        }
        DeRef(_12750);
        _12750 = NOVALUE;
    }
    DeRef(_12750);
    _12750 = NOVALUE;

    /** compress.e:72				return I4B & int_to_bytes(x)*/
    Ref(_x_22590);
    _12751 = _19int_to_bytes(_x_22590, 4);
    if (IS_SEQUENCE(249) && IS_ATOM(_12751)) {
    }
    else if (IS_ATOM(249) && IS_SEQUENCE(_12751)) {
        Prepend(&_12752, _12751, 249);
    }
    else {
        Concat((object_ptr)&_12752, 249, _12751);
    }
    DeRef(_12751);
    _12751 = NOVALUE;
    DeRef(_x_22590);
    DeRef(_x4_22591);
    DeRef(_s_22592);
    DeRef(_12727);
    _12727 = NOVALUE;
    DeRef(_12738);
    _12738 = NOVALUE;
    DeRef(_12732);
    _12732 = NOVALUE;
    DeRef(_12748);
    _12748 = NOVALUE;
    DeRef(_12739);
    _12739 = NOVALUE;
    DeRef(_12731);
    _12731 = NOVALUE;
    DeRef(_12747);
    _12747 = NOVALUE;
    return _12752;
    goto L3; // [196] 389
L6: 

    /** compress.e:75				ifdef EU4_0 then*/

    /** compress.e:79					return I8B & int_to_bytes(x, 8)*/
    Ref(_x_22590);
    _12754 = _19int_to_bytes(_x_22590, 8);
    if (IS_SEQUENCE(250) && IS_ATOM(_12754)) {
    }
    else if (IS_ATOM(250) && IS_SEQUENCE(_12754)) {
        Prepend(&_12755, _12754, 250);
    }
    else {
        Concat((object_ptr)&_12755, 250, _12754);
    }
    DeRef(_12754);
    _12754 = NOVALUE;
    DeRef(_x_22590);
    DeRef(_x4_22591);
    DeRef(_s_22592);
    DeRef(_12727);
    _12727 = NOVALUE;
    DeRef(_12738);
    _12738 = NOVALUE;
    DeRef(_12732);
    _12732 = NOVALUE;
    DeRef(_12748);
    _12748 = NOVALUE;
    DeRef(_12739);
    _12739 = NOVALUE;
    DeRef(_12752);
    _12752 = NOVALUE;
    DeRef(_12731);
    _12731 = NOVALUE;
    DeRef(_12747);
    _12747 = NOVALUE;
    return _12755;
    goto L3; // [217] 389
L1: 

    /** compress.e:83		elsif atom(x) then*/
    _12756 = IS_ATOM(_x_22590);
    if (_12756 == 0)
    {
        _12756 = NOVALUE;
        goto L7; // [225] 309
    }
    else{
        _12756 = NOVALUE;
    }

    /** compress.e:85			x4 = atom_to_float32(x)*/
    Ref(_x_22590);
    _0 = _x4_22591;
    _x4_22591 = _19atom_to_float32(_x_22590);
    DeRef(_0);

    /** compress.e:86			if x = float32_to_atom(x4) then*/
    RefDS(_x4_22591);
    _12758 = _19float32_to_atom(_x4_22591);
    if (binary_op_a(NOTEQ, _x_22590, _12758)){
        DeRef(_12758);
        _12758 = NOVALUE;
        goto L8; // [242] 259
    }
    DeRef(_12758);
    _12758 = NOVALUE;

    /** compress.e:88				return F4B & x4*/
    Prepend(&_12760, _x4_22591, 251);
    DeRef(_x_22590);
    DeRefDS(_x4_22591);
    DeRef(_s_22592);
    DeRef(_12727);
    _12727 = NOVALUE;
    DeRef(_12738);
    _12738 = NOVALUE;
    DeRef(_12732);
    _12732 = NOVALUE;
    DeRef(_12748);
    _12748 = NOVALUE;
    DeRef(_12739);
    _12739 = NOVALUE;
    DeRef(_12752);
    _12752 = NOVALUE;
    DeRef(_12731);
    _12731 = NOVALUE;
    DeRef(_12747);
    _12747 = NOVALUE;
    DeRef(_12755);
    _12755 = NOVALUE;
    return _12760;
    goto L3; // [256] 389
L8: 

    /** compress.e:90				x4 = atom_to_float64( x )*/
    Ref(_x_22590);
    _0 = _x4_22591;
    _x4_22591 = _19atom_to_float64(_x_22590);
    DeRef(_0);

    /** compress.e:91				if x = float64_to_atom( x4 ) then*/
    RefDS(_x4_22591);
    _12762 = _19float64_to_atom(_x4_22591);
    if (binary_op_a(NOTEQ, _x_22590, _12762)){
        DeRef(_12762);
        _12762 = NOVALUE;
        goto L9; // [273] 290
    }
    DeRef(_12762);
    _12762 = NOVALUE;

    /** compress.e:92					return F8B & x4*/
    Prepend(&_12764, _x4_22591, 252);
    DeRef(_x_22590);
    DeRefDS(_x4_22591);
    DeRef(_s_22592);
    DeRef(_12760);
    _12760 = NOVALUE;
    DeRef(_12727);
    _12727 = NOVALUE;
    DeRef(_12738);
    _12738 = NOVALUE;
    DeRef(_12732);
    _12732 = NOVALUE;
    DeRef(_12748);
    _12748 = NOVALUE;
    DeRef(_12739);
    _12739 = NOVALUE;
    DeRef(_12752);
    _12752 = NOVALUE;
    DeRef(_12731);
    _12731 = NOVALUE;
    DeRef(_12747);
    _12747 = NOVALUE;
    DeRef(_12755);
    _12755 = NOVALUE;
    return _12764;
    goto L3; // [287] 389
L9: 

    /** compress.e:94					return F10B & atom_to_float80( x )*/
    Ref(_x_22590);
    _12765 = _19atom_to_float80(_x_22590);
    if (IS_SEQUENCE(253) && IS_ATOM(_12765)) {
    }
    else if (IS_ATOM(253) && IS_SEQUENCE(_12765)) {
        Prepend(&_12766, _12765, 253);
    }
    else {
        Concat((object_ptr)&_12766, 253, _12765);
    }
    DeRef(_12765);
    _12765 = NOVALUE;
    DeRef(_x_22590);
    DeRef(_x4_22591);
    DeRef(_s_22592);
    DeRef(_12760);
    _12760 = NOVALUE;
    DeRef(_12727);
    _12727 = NOVALUE;
    DeRef(_12738);
    _12738 = NOVALUE;
    DeRef(_12732);
    _12732 = NOVALUE;
    DeRef(_12748);
    _12748 = NOVALUE;
    DeRef(_12764);
    _12764 = NOVALUE;
    DeRef(_12739);
    _12739 = NOVALUE;
    DeRef(_12752);
    _12752 = NOVALUE;
    DeRef(_12731);
    _12731 = NOVALUE;
    DeRef(_12747);
    _12747 = NOVALUE;
    DeRef(_12755);
    _12755 = NOVALUE;
    return _12766;
    goto L3; // [306] 389
L7: 

    /** compress.e:100			if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_22590)){
            _12767 = SEQ_PTR(_x_22590)->length;
    }
    else {
        _12767 = 1;
    }
    if (_12767 > 255)
    goto LA; // [314] 330

    /** compress.e:101				s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_22590)){
            _12769 = SEQ_PTR(_x_22590)->length;
    }
    else {
        _12769 = 1;
    }
    DeRef(_s_22592);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 254;
    ((intptr_t *)_2)[2] = _12769;
    _s_22592 = MAKE_SEQ(_1);
    _12769 = NOVALUE;
    goto LB; // [327] 345
LA: 

    /** compress.e:103				s = S4B & int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_22590)){
            _12771 = SEQ_PTR(_x_22590)->length;
    }
    else {
        _12771 = 1;
    }
    _12772 = _19int_to_bytes(_12771, 4);
    _12771 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_12772)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_12772)) {
        Prepend(&_s_22592, _12772, 255);
    }
    else {
        Concat((object_ptr)&_s_22592, 255, _12772);
    }
    DeRef(_12772);
    _12772 = NOVALUE;
LB: 

    /** compress.e:105			for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_22590)){
            _12774 = SEQ_PTR(_x_22590)->length;
    }
    else {
        _12774 = 1;
    }
    {
        object _i_22664;
        _i_22664 = 1;
LC: 
        if (_i_22664 > _12774){
            goto LD; // [350] 380
        }

        /** compress.e:106				s &= compress(x[i])*/
        _2 = (object)SEQ_PTR(_x_22590);
        _12775 = (object)*(((s1_ptr)_2)->base + _i_22664);
        Ref(_12775);
        _12776 = _59compress(_12775);
        _12775 = NOVALUE;
        if (IS_SEQUENCE(_s_22592) && IS_ATOM(_12776)) {
            Ref(_12776);
            Append(&_s_22592, _s_22592, _12776);
        }
        else if (IS_ATOM(_s_22592) && IS_SEQUENCE(_12776)) {
        }
        else {
            Concat((object_ptr)&_s_22592, _s_22592, _12776);
        }
        DeRef(_12776);
        _12776 = NOVALUE;

        /** compress.e:107			end for*/
        _i_22664 = _i_22664 + 1;
        goto LC; // [375] 357
LD: 
        ;
    }

    /** compress.e:108			return s*/
    DeRef(_x_22590);
    DeRef(_x4_22591);
    DeRef(_12760);
    _12760 = NOVALUE;
    DeRef(_12727);
    _12727 = NOVALUE;
    DeRef(_12766);
    _12766 = NOVALUE;
    DeRef(_12738);
    _12738 = NOVALUE;
    DeRef(_12732);
    _12732 = NOVALUE;
    DeRef(_12748);
    _12748 = NOVALUE;
    DeRef(_12764);
    _12764 = NOVALUE;
    DeRef(_12739);
    _12739 = NOVALUE;
    DeRef(_12752);
    _12752 = NOVALUE;
    DeRef(_12731);
    _12731 = NOVALUE;
    DeRef(_12747);
    _12747 = NOVALUE;
    DeRef(_12755);
    _12755 = NOVALUE;
    return _s_22592;
L3: 
    ;
}



// 0x9477C7AE
