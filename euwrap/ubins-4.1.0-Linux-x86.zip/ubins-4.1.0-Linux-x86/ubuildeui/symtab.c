// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _53hashfn(object _name_46818)
{
    object _len_46819 = NOVALUE;
    object _val_46820 = NOVALUE;
    object _int_46821 = NOVALUE;
    object _24319 = NOVALUE;
    object _24318 = NOVALUE;
    object _24315 = NOVALUE;
    object _24314 = NOVALUE;
    object _24303 = NOVALUE;
    object _24299 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:49		len = length(name)*/
    if (IS_SEQUENCE(_name_46818)){
            _len_46819 = SEQ_PTR(_name_46818)->length;
    }
    else {
        _len_46819 = 1;
    }

    /** symtab.e:51		val = name[1]*/
    _2 = (object)SEQ_PTR(_name_46818);
    _val_46820 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_val_46820))
    _val_46820 = (object)DBL_PTR(_val_46820)->dbl;

    /** symtab.e:52		int = name[$]*/
    if (IS_SEQUENCE(_name_46818)){
            _24299 = SEQ_PTR(_name_46818)->length;
    }
    else {
        _24299 = 1;
    }
    _2 = (object)SEQ_PTR(_name_46818);
    _int_46821 = (object)*(((s1_ptr)_2)->base + _24299);
    if (!IS_ATOM_INT(_int_46821))
    _int_46821 = (object)DBL_PTR(_int_46821)->dbl;

    /** symtab.e:53		int *= 256*/
    _int_46821 = _int_46821 * 256;

    /** symtab.e:54		val *= 2*/
    _val_46820 = _val_46820 + _val_46820;

    /** symtab.e:55		val += int + len*/
    _24303 = _int_46821 + _len_46819;
    if ((object)((uintptr_t)_24303 + (uintptr_t)HIGH_BITS) >= 0){
        _24303 = NewDouble((eudouble)_24303);
    }
    if (IS_ATOM_INT(_24303)) {
        _val_46820 = _val_46820 + _24303;
    }
    else {
        _val_46820 = NewDouble((eudouble)_val_46820 + DBL_PTR(_24303)->dbl);
    }
    DeRef(_24303);
    _24303 = NOVALUE;
    if (!IS_ATOM_INT(_val_46820)) {
        _1 = (object)(DBL_PTR(_val_46820)->dbl);
        DeRefDS(_val_46820);
        _val_46820 = _1;
    }

    /** symtab.e:57		if len = 3 then*/
    if (_len_46819 != 3)
    goto L1; // [51] 78

    /** symtab.e:58			val *= 32*/
    _val_46820 = _val_46820 * 32;

    /** symtab.e:59			int = name[2]*/
    _2 = (object)SEQ_PTR(_name_46818);
    _int_46821 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_46821))
    _int_46821 = (object)DBL_PTR(_int_46821)->dbl;

    /** symtab.e:60			val += int*/
    _val_46820 = _val_46820 + _int_46821;
    goto L2; // [75] 133
L1: 

    /** symtab.e:61		elsif len > 3 then*/
    if (_len_46819 <= 3)
    goto L3; // [80] 132

    /** symtab.e:62			val *= 32*/
    _val_46820 = _val_46820 * 32;

    /** symtab.e:63			int = name[2]*/
    _2 = (object)SEQ_PTR(_name_46818);
    _int_46821 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_46821))
    _int_46821 = (object)DBL_PTR(_int_46821)->dbl;

    /** symtab.e:64			val += int*/
    _val_46820 = _val_46820 + _int_46821;

    /** symtab.e:66			val *= 32*/
    _val_46820 = _val_46820 * 32;

    /** symtab.e:67			int = name[$-1]*/
    if (IS_SEQUENCE(_name_46818)){
            _24314 = SEQ_PTR(_name_46818)->length;
    }
    else {
        _24314 = 1;
    }
    _24315 = _24314 - 1;
    _24314 = NOVALUE;
    _2 = (object)SEQ_PTR(_name_46818);
    _int_46821 = (object)*(((s1_ptr)_2)->base + _24315);
    if (!IS_ATOM_INT(_int_46821))
    _int_46821 = (object)DBL_PTR(_int_46821)->dbl;

    /** symtab.e:68			val += int*/
    _val_46820 = _val_46820 + _int_46821;
L3: 
L2: 

    /** symtab.e:70		return remainder(val, NBUCKETS) + 1*/
    _24318 = (_val_46820 % 2003);
    _24319 = _24318 + 1;
    _24318 = NOVALUE;
    DeRefDS(_name_46818);
    DeRef(_24315);
    _24315 = NOVALUE;
    return _24319;
    ;
}


void _53remove_symbol(object _sym_46850)
{
    object _hash_46851 = NOVALUE;
    object _st_ptr_46852 = NOVALUE;
    object _24334 = NOVALUE;
    object _24333 = NOVALUE;
    object _24331 = NOVALUE;
    object _24330 = NOVALUE;
    object _24329 = NOVALUE;
    object _24327 = NOVALUE;
    object _24325 = NOVALUE;
    object _24324 = NOVALUE;
    object _24323 = NOVALUE;
    object _24320 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:79		hash = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24320 = (object)*(((s1_ptr)_2)->base + _sym_46850);
    _2 = (object)SEQ_PTR(_24320);
    _hash_46851 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_hash_46851)){
        _hash_46851 = (object)DBL_PTR(_hash_46851)->dbl;
    }
    _24320 = NOVALUE;

    /** symtab.e:80		st_ptr = buckets[hash]*/
    _2 = (object)SEQ_PTR(_53buckets_46799);
    _st_ptr_46852 = (object)*(((s1_ptr)_2)->base + _hash_46851);
    if (!IS_ATOM_INT(_st_ptr_46852))
    _st_ptr_46852 = (object)DBL_PTR(_st_ptr_46852)->dbl;

    /** symtab.e:82		while st_ptr and st_ptr != sym do*/
L1: 
    if (_st_ptr_46852 == 0) {
        goto L2; // [32] 65
    }
    _24324 = (_st_ptr_46852 != _sym_46850);
    if (_24324 == 0)
    {
        DeRef(_24324);
        _24324 = NOVALUE;
        goto L2; // [41] 65
    }
    else{
        DeRef(_24324);
        _24324 = NOVALUE;
    }

    /** symtab.e:83			st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24325 = (object)*(((s1_ptr)_2)->base + _st_ptr_46852);
    _2 = (object)SEQ_PTR(_24325);
    _st_ptr_46852 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_st_ptr_46852)){
        _st_ptr_46852 = (object)DBL_PTR(_st_ptr_46852)->dbl;
    }
    _24325 = NOVALUE;

    /** symtab.e:84		end while*/
    goto L1; // [62] 32
L2: 

    /** symtab.e:86		if st_ptr then*/
    if (_st_ptr_46852 == 0)
    {
        goto L3; // [67] 134
    }
    else{
    }

    /** symtab.e:87			if st_ptr = buckets[hash] then*/
    _2 = (object)SEQ_PTR(_53buckets_46799);
    _24327 = (object)*(((s1_ptr)_2)->base + _hash_46851);
    if (binary_op_a(NOTEQ, _st_ptr_46852, _24327)){
        _24327 = NOVALUE;
        goto L4; // [78] 105
    }
    _24327 = NOVALUE;

    /** symtab.e:89				buckets[hash] = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24329 = (object)*(((s1_ptr)_2)->base + _st_ptr_46852);
    _2 = (object)SEQ_PTR(_24329);
    _24330 = (object)*(((s1_ptr)_2)->base + 9);
    _24329 = NOVALUE;
    Ref(_24330);
    _2 = (object)SEQ_PTR(_53buckets_46799);
    _2 = (object)(((s1_ptr)_2)->base + _hash_46851);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24330;
    if( _1 != _24330 ){
        DeRef(_1);
    }
    _24330 = NOVALUE;
    goto L5; // [102] 133
L4: 

    /** symtab.e:92				SymTab[st_ptr][S_SAMEHASH] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_st_ptr_46852 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24333 = (object)*(((s1_ptr)_2)->base + _sym_46850);
    _2 = (object)SEQ_PTR(_24333);
    _24334 = (object)*(((s1_ptr)_2)->base + 9);
    _24333 = NOVALUE;
    Ref(_24334);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24334;
    if( _1 != _24334 ){
        DeRef(_1);
    }
    _24334 = NOVALUE;
    _24331 = NOVALUE;
L5: 
L3: 

    /** symtab.e:95	end procedure*/
    return;
    ;
}


object _53NewBasicEntry(object _name_46884, object _varnum_46885, object _scope_46886, object _token_46887, object _hashval_46888, object _samehash_46890, object _type_sym_46892)
{
    object _new_46893 = NOVALUE;
    object _24343 = NOVALUE;
    object _24341 = NOVALUE;
    object _24340 = NOVALUE;
    object _24339 = NOVALUE;
    object _24338 = NOVALUE;
    object _24337 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:105		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L1; // [19] 33
    }
    else{
    }

    /** symtab.e:106			new = repeat(0, SIZEOF_ROUTINE_ENTRY)*/
    DeRef(_new_46893);
    _new_46893 = Repeat(0, _12SIZEOF_ROUTINE_ENTRY_19990);
    goto L2; // [30] 42
L1: 

    /** symtab.e:108			new = repeat(0, SIZEOF_VAR_ENTRY)*/
    DeRef(_new_46893);
    _new_46893 = Repeat(0, _12SIZEOF_VAR_ENTRY_19993);
L2: 

    /** symtab.e:111		new[S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:112		new[S_NAME] = name*/
    RefDS(_name_46884);
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NAME_19864))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_NAME_19864);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _name_46884;
    DeRef(_1);

    /** symtab.e:113		new[S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_46886;
    DeRef(_1);

    /** symtab.e:114		new[S_MODE] = M_NORMAL*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);

    /** symtab.e:115		new[S_USAGE] = U_UNUSED*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:116		new[S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FILE_NO_19860))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12current_file_no_20226;
    DeRef(_1);

    /** symtab.e:118		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L3; // [102] 327
    }
    else{
    }

    /** symtab.e:120			new[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:121			new[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:123			new[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:124			new[S_SEQ_ELEM_NEW] = TYPE_NULL -- starting point for ORing*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:126			new[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:127			new[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:128			new[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:129			new[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:131			new[S_ARG_MIN] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** symtab.e:132			new[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _24337 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24337 = - _12NOVALUE_20081;
        }
    }
    else {
        _24337 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24337;
    if( _1 != _24337 ){
        DeRef(_1);
    }
    _24337 = NOVALUE;

    /** symtab.e:134			new[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** symtab.e:135			new[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _24338 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24338 = - _12NOVALUE_20081;
        }
    }
    else {
        _24338 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24338;
    if( _1 != _24338 ){
        DeRef(_1);
    }
    _24338 = NOVALUE;

    /** symtab.e:137			new[S_SEQ_LEN] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** symtab.e:138			new[S_SEQ_LEN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _24339 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24339 = - _12NOVALUE_20081;
        }
    }
    else {
        _24339 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24339;
    if( _1 != _24339 ){
        DeRef(_1);
    }
    _24339 = NOVALUE;

    /** symtab.e:140			new[S_NREFS] = 0*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:141			new[S_ONE_REF] = TRUE          -- assume TRUE until we find otherwise*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 35);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _9TRUE_446;
    DeRef(_1);

    /** symtab.e:142			new[S_RI_TARGET] = 0*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 53);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:144			new[S_OBJ_MIN] = MININT*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1073741824;
    DeRef(_1);

    /** symtab.e:145			new[S_OBJ_MIN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _24340 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24340 = - _12NOVALUE_20081;
        }
    }
    else {
        _24340 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24340;
    if( _1 != _24340 ){
        DeRef(_1);
    }
    _24340 = NOVALUE;

    /** symtab.e:147			new[S_OBJ_MAX] = MAXINT*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1073741823;
    DeRef(_1);

    /** symtab.e:148			new[S_OBJ_MAX_NEW] = -NOVALUE -- missing from C code? (not needed)*/
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _24341 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24341 = - _12NOVALUE_20081;
        }
    }
    else {
        _24341 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24341;
    if( _1 != _24341 ){
        DeRef(_1);
    }
    _24341 = NOVALUE;
L3: 

    /** symtab.e:151		new[S_TOKEN] = token*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TOKEN_19869))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _token_46887;
    DeRef(_1);

    /** symtab.e:152		new[S_VARNUM] = varnum*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 16);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _varnum_46885;
    DeRef(_1);

    /** symtab.e:153		new[S_INITLEVEL] = -1*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1;
    DeRef(_1);

    /** symtab.e:154		new[S_VTYPE] = type_sym*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_sym_46892;
    DeRef(_1);

    /** symtab.e:156		new[S_HASHVAL] = hashval*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _hashval_46888;
    DeRef(_1);

    /** symtab.e:157		new[S_SAMEHASH] = samehash*/
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _samehash_46890;
    DeRef(_1);

    /** symtab.e:159		new[S_OBJ] = NOVALUE -- important*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_new_46893);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46893 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** symtab.e:162		SymTab = append(SymTab, new)*/
    RefDS(_new_46893);
    Append(&_13SymTab_11316, _13SymTab_11316, _new_46893);

    /** symtab.e:164		return length(SymTab)*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _24343 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _24343 = 1;
    }
    DeRefDS(_name_46884);
    DeRefDS(_new_46893);
    return _24343;
    ;
}


object _53NewEntry(object _name_46972, object _varnum_46973, object _scope_46974, object _token_46975, object _hashval_46976, object _samehash_46978, object _type_sym_46980)
{
    object _new_46982 = NOVALUE;
    object _24345 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_scope_46974)) {
        _1 = (object)(DBL_PTR(_scope_46974)->dbl);
        DeRefDS(_scope_46974);
        _scope_46974 = _1;
    }
    if (!IS_ATOM_INT(_token_46975)) {
        _1 = (object)(DBL_PTR(_token_46975)->dbl);
        DeRefDS(_token_46975);
        _token_46975 = _1;
    }
    if (!IS_ATOM_INT(_samehash_46978)) {
        _1 = (object)(DBL_PTR(_samehash_46978)->dbl);
        DeRefDS(_samehash_46978);
        _samehash_46978 = _1;
    }

    /** symtab.e:171		symtab_index new = NewBasicEntry( name, varnum, scope, token, hashval, samehash, type_sym )*/
    RefDS(_name_46972);
    _new_46982 = _53NewBasicEntry(_name_46972, _varnum_46973, _scope_46974, _token_46975, _hashval_46976, _samehash_46978, _type_sym_46980);
    if (!IS_ATOM_INT(_new_46982)) {
        _1 = (object)(DBL_PTR(_new_46982)->dbl);
        DeRefDS(_new_46982);
        _new_46982 = _1;
    }

    /** symtab.e:174		if last_sym then*/
    if (_53last_sym_46812 == 0)
    {
        goto L1; // [33] 54
    }
    else{
    }

    /** symtab.e:175			SymTab[last_sym][S_NEXT] = new*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_53last_sym_46812 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_46982;
    DeRef(_1);
    _24345 = NOVALUE;
L1: 

    /** symtab.e:177		last_sym = new*/
    _53last_sym_46812 = _new_46982;

    /** symtab.e:178		if type_sym < 0 then*/
    if (_type_sym_46980 >= 0)
    goto L2; // [63] 76

    /** symtab.e:179			register_forward_type( last_sym, type_sym )*/
    _42register_forward_type(_53last_sym_46812, _type_sym_46980);
L2: 

    /** symtab.e:181		return last_sym*/
    DeRefDS(_name_46972);
    return _53last_sym_46812;
    ;
}


object _53tmp_alloc()
{
    object _new_entry_46997 = NOVALUE;
    object _24359 = NOVALUE;
    object _24357 = NOVALUE;
    object _24354 = NOVALUE;
    object _24351 = NOVALUE;
    object _24350 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:188		sequence new_entry = repeat( 0, SIZEOF_TEMP_ENTRY )*/
    DeRef(_new_entry_46997);
    _new_entry_46997 = Repeat(0, _12SIZEOF_TEMP_ENTRY_19999);

    /** symtab.e:192		new_entry[S_USAGE] = T_UNKNOWN*/
    _2 = (object)SEQ_PTR(_new_entry_46997);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46997 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    *(intptr_t *)_2 = 4;

    /** symtab.e:194		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L1; // [23] 132
    }
    else{
    }

    /** symtab.e:195			new_entry[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_entry_46997);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46997 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    *(intptr_t *)_2 = 16;

    /** symtab.e:196			new_entry[S_OBJ_MIN] = MININT*/
    _2 = (object)SEQ_PTR(_new_entry_46997);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46997 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    *(intptr_t *)_2 = -1073741824;

    /** symtab.e:197			new_entry[S_OBJ_MAX] = MAXINT*/
    _2 = (object)SEQ_PTR(_new_entry_46997);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46997 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    *(intptr_t *)_2 = 1073741823;

    /** symtab.e:198			new_entry[S_SEQ_LEN] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_new_entry_46997);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46997 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    *(intptr_t *)_2 = _12NOVALUE_20081;

    /** symtab.e:199			new_entry[S_SEQ_ELEM] = TYPE_OBJECT  -- other fields set later*/
    _2 = (object)SEQ_PTR(_new_entry_46997);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46997 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:200			if length(temp_name_type)+1 = 8087 then*/
    if (IS_SEQUENCE(_12temp_name_type_20309)){
            _24350 = SEQ_PTR(_12temp_name_type_20309)->length;
    }
    else {
        _24350 = 1;
    }
    _24351 = _24350 + 1;
    _24350 = NOVALUE;
    if (_24351 != 8087)
    goto L2; // [87] 106

    /** symtab.e:202				temp_name_type = append(temp_name_type, {0, 0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = 0;
    _24354 = MAKE_SEQ(_1);
    RefDS(_24354);
    Append(&_12temp_name_type_20309, _12temp_name_type_20309, _24354);
    DeRefDS(_24354);
    _24354 = NOVALUE;
L2: 

    /** symtab.e:204			temp_name_type = append(temp_name_type, TYPES_OBNL)*/
    RefDS(_54TYPES_OBNL_46644);
    Append(&_12temp_name_type_20309, _12temp_name_type_20309, _54TYPES_OBNL_46644);

    /** symtab.e:205			new_entry[S_TEMP_NAME] = length(temp_name_type)*/
    if (IS_SEQUENCE(_12temp_name_type_20309)){
            _24357 = SEQ_PTR(_12temp_name_type_20309)->length;
    }
    else {
        _24357 = 1;
    }
    _2 = (object)SEQ_PTR(_new_entry_46997);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46997 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24357;
    if( _1 != _24357 ){
        DeRef(_1);
    }
    _24357 = NOVALUE;
L1: 

    /** symtab.e:208		SymTab = append(SymTab, new_entry )*/
    RefDS(_new_entry_46997);
    Append(&_13SymTab_11316, _13SymTab_11316, _new_entry_46997);

    /** symtab.e:210		return length( SymTab )*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _24359 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _24359 = 1;
    }
    DeRefDS(_new_entry_46997);
    DeRef(_24351);
    _24351 = NOVALUE;
    return _24359;
    ;
}


void _53DefinedYet(object _sym_47066)
{
    object _24379 = NOVALUE;
    object _24378 = NOVALUE;
    object _24377 = NOVALUE;
    object _24375 = NOVALUE;
    object _24374 = NOVALUE;
    object _24372 = NOVALUE;
    object _24371 = NOVALUE;
    object _24370 = NOVALUE;
    object _24369 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:230		if not find(SymTab[sym][S_SCOPE],*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24369 = (object)*(((s1_ptr)_2)->base + _sym_47066);
    _2 = (object)SEQ_PTR(_24369);
    _24370 = (object)*(((s1_ptr)_2)->base + 4);
    _24369 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 9;
    ((intptr_t*)_2)[2] = 10;
    ((intptr_t*)_2)[3] = 7;
    _24371 = MAKE_SEQ(_1);
    _24372 = find_from(_24370, _24371, 1);
    _24370 = NOVALUE;
    DeRefDS(_24371);
    _24371 = NOVALUE;
    if (_24372 != 0)
    goto L1; // [34] 84
    _24372 = NOVALUE;

    /** symtab.e:232			if SymTab[sym][S_FILE_NO] = current_file_no then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24374 = (object)*(((s1_ptr)_2)->base + _sym_47066);
    _2 = (object)SEQ_PTR(_24374);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _24375 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _24375 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _24374 = NOVALUE;
    if (binary_op_a(NOTEQ, _24375, _12current_file_no_20226)){
        _24375 = NOVALUE;
        goto L2; // [53] 83
    }
    _24375 = NOVALUE;

    /** symtab.e:233				CompileErr(ATTEMPT_TO_REDEFINE_1, {SymTab[sym][S_NAME]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24377 = (object)*(((s1_ptr)_2)->base + _sym_47066);
    _2 = (object)SEQ_PTR(_24377);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _24378 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _24378 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _24377 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24378);
    ((intptr_t*)_2)[1] = _24378;
    _24379 = MAKE_SEQ(_1);
    _24378 = NOVALUE;
    _49CompileErr(31, _24379, 0);
    _24379 = NOVALUE;
L2: 
L1: 

    /** symtab.e:236	end procedure*/
    return;
    ;
}


object _53name_ext(object _s_47094)
{
    object _24386 = NOVALUE;
    object _24385 = NOVALUE;
    object _24384 = NOVALUE;
    object _24383 = NOVALUE;
    object _24381 = NOVALUE;
    object _24380 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:241		for i = length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_47094)){
            _24380 = SEQ_PTR(_s_47094)->length;
    }
    else {
        _24380 = 1;
    }
    {
        object _i_47096;
        _i_47096 = _24380;
L1: 
        if (_i_47096 < 1){
            goto L2; // [8] 55
        }

        /** symtab.e:242			if find(s[i], "/\\:") then*/
        _2 = (object)SEQ_PTR(_s_47094);
        _24381 = (object)*(((s1_ptr)_2)->base + _i_47096);
        _24383 = find_from(_24381, _24382, 1);
        _24381 = NOVALUE;
        if (_24383 == 0)
        {
            _24383 = NOVALUE;
            goto L3; // [26] 48
        }
        else{
            _24383 = NOVALUE;
        }

        /** symtab.e:243				return s[i+1 .. $]*/
        _24384 = _i_47096 + 1;
        if (IS_SEQUENCE(_s_47094)){
                _24385 = SEQ_PTR(_s_47094)->length;
        }
        else {
            _24385 = 1;
        }
        rhs_slice_target = (object_ptr)&_24386;
        RHS_Slice(_s_47094, _24384, _24385);
        DeRefDS(_s_47094);
        _24384 = NOVALUE;
        return _24386;
L3: 

        /** symtab.e:245		end for*/
        _i_47096 = _i_47096 + -1;
        goto L1; // [50] 15
L2: 
        ;
    }

    /** symtab.e:247		return s*/
    DeRef(_24386);
    _24386 = NOVALUE;
    DeRef(_24384);
    _24384 = NOVALUE;
    return _s_47094;
    ;
}


object _53NewStringSym(object _s_47113)
{
    object _p_47115 = NOVALUE;
    object _tp_47116 = NOVALUE;
    object _prev_47117 = NOVALUE;
    object _search_count_47118 = NOVALUE;
    object _24430 = NOVALUE;
    object _24428 = NOVALUE;
    object _24427 = NOVALUE;
    object _24426 = NOVALUE;
    object _24424 = NOVALUE;
    object _24423 = NOVALUE;
    object _24420 = NOVALUE;
    object _24418 = NOVALUE;
    object _24416 = NOVALUE;
    object _24415 = NOVALUE;
    object _24414 = NOVALUE;
    object _24412 = NOVALUE;
    object _24410 = NOVALUE;
    object _24408 = NOVALUE;
    object _24406 = NOVALUE;
    object _24403 = NOVALUE;
    object _24401 = NOVALUE;
    object _24400 = NOVALUE;
    object _24399 = NOVALUE;
    object _24397 = NOVALUE;
    object _24395 = NOVALUE;
    object _24394 = NOVALUE;
    object _24393 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:255		integer search_count*/

    /** symtab.e:258		tp = literal_init*/
    _tp_47116 = _53literal_init_46811;

    /** symtab.e:259		prev = 0*/
    _prev_47117 = 0;

    /** symtab.e:260		search_count = 0*/
    _search_count_47118 = 0;

    /** symtab.e:261		while tp != 0 do*/
L1: 
    if (_tp_47116 == 0)
    goto L2; // [31] 170

    /** symtab.e:262			search_count += 1*/
    _search_count_47118 = _search_count_47118 + 1;

    /** symtab.e:263			if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_47118, _53SEARCH_LIMIT_47105)){
        goto L3; // [45] 54
    }

    /** symtab.e:264				exit*/
    goto L2; // [51] 170
L3: 

    /** symtab.e:266			if equal(s, SymTab[tp][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24393 = (object)*(((s1_ptr)_2)->base + _tp_47116);
    _2 = (object)SEQ_PTR(_24393);
    _24394 = (object)*(((s1_ptr)_2)->base + 1);
    _24393 = NOVALUE;
    if (_s_47113 == _24394)
    _24395 = 1;
    else if (IS_ATOM_INT(_s_47113) && IS_ATOM_INT(_24394))
    _24395 = 0;
    else
    _24395 = (compare(_s_47113, _24394) == 0);
    _24394 = NOVALUE;
    if (_24395 == 0)
    {
        _24395 = NOVALUE;
        goto L4; // [72] 142
    }
    else{
        _24395 = NOVALUE;
    }

    /** symtab.e:268				if tp != literal_init then*/
    if (_tp_47116 == _53literal_init_46811)
    goto L5; // [79] 135

    /** symtab.e:269					SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_47117 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24399 = (object)*(((s1_ptr)_2)->base + _tp_47116);
    _2 = (object)SEQ_PTR(_24399);
    _24400 = (object)*(((s1_ptr)_2)->base + 2);
    _24399 = NOVALUE;
    Ref(_24400);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24400;
    if( _1 != _24400 ){
        DeRef(_1);
    }
    _24400 = NOVALUE;
    _24397 = NOVALUE;

    /** symtab.e:270					SymTab[tp][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_tp_47116 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53literal_init_46811;
    DeRef(_1);
    _24401 = NOVALUE;

    /** symtab.e:271					literal_init = tp*/
    _53literal_init_46811 = _tp_47116;
L5: 

    /** symtab.e:273				return tp*/
    DeRefDS(_s_47113);
    return _tp_47116;
L4: 

    /** symtab.e:275			prev = tp*/
    _prev_47117 = _tp_47116;

    /** symtab.e:276			tp = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24403 = (object)*(((s1_ptr)_2)->base + _tp_47116);
    _2 = (object)SEQ_PTR(_24403);
    _tp_47116 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_tp_47116)){
        _tp_47116 = (object)DBL_PTR(_tp_47116)->dbl;
    }
    _24403 = NOVALUE;

    /** symtab.e:277		end while*/
    goto L1; // [167] 31
L2: 

    /** symtab.e:279		p = tmp_alloc()*/
    _p_47115 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_47115)) {
        _1 = (object)(DBL_PTR(_p_47115)->dbl);
        DeRefDS(_p_47115);
        _p_47115 = _1;
    }

    /** symtab.e:280		SymTab[p][S_OBJ] = s*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47115 + ((s1_ptr)_2)->base);
    RefDS(_s_47113);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_47113;
    DeRef(_1);
    _24406 = NOVALUE;

    /** symtab.e:282		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L6; // [196] 346
    }
    else{
    }

    /** symtab.e:283			SymTab[p][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47115 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _24408 = NOVALUE;

    /** symtab.e:284			SymTab[p][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47115 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8;
    DeRef(_1);
    _24410 = NOVALUE;

    /** symtab.e:285			SymTab[p][S_SEQ_LEN] = length(s)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47115 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_s_47113)){
            _24414 = SEQ_PTR(_s_47113)->length;
    }
    else {
        _24414 = 1;
    }
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24414;
    if( _1 != _24414 ){
        DeRef(_1);
    }
    _24414 = NOVALUE;
    _24412 = NOVALUE;

    /** symtab.e:286			if SymTab[p][S_SEQ_LEN] > 0 then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24415 = (object)*(((s1_ptr)_2)->base + _p_47115);
    _2 = (object)SEQ_PTR(_24415);
    _24416 = (object)*(((s1_ptr)_2)->base + 32);
    _24415 = NOVALUE;
    if (binary_op_a(LESSEQ, _24416, 0)){
        _24416 = NOVALUE;
        goto L7; // [265] 289
    }
    _24416 = NOVALUE;

    /** symtab.e:287				SymTab[p][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47115 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _24418 = NOVALUE;
    goto L8; // [286] 307
L7: 

    /** symtab.e:289				SymTab[p][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47115 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _24420 = NOVALUE;
L8: 

    /** symtab.e:291			c_printf("object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24423 = (object)*(((s1_ptr)_2)->base + _p_47115);
    _2 = (object)SEQ_PTR(_24423);
    _24424 = (object)*(((s1_ptr)_2)->base + 34);
    _24423 = NOVALUE;
    RefDS(_24422);
    Ref(_24424);
    _54c_printf(_24422, _24424);
    _24424 = NOVALUE;

    /** symtab.e:292			c_hprintf("extern object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24426 = (object)*(((s1_ptr)_2)->base + _p_47115);
    _2 = (object)SEQ_PTR(_24426);
    _24427 = (object)*(((s1_ptr)_2)->base + 34);
    _24426 = NOVALUE;
    RefDS(_24425);
    Ref(_24427);
    _54c_hprintf(_24425, _24427);
    _24427 = NOVALUE;
    goto L9; // [343] 364
L6: 

    /** symtab.e:295			SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47115 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24428 = NOVALUE;
L9: 

    /** symtab.e:299		SymTab[p][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47115 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53literal_init_46811;
    DeRef(_1);
    _24430 = NOVALUE;

    /** symtab.e:300		literal_init = p*/
    _53literal_init_46811 = _p_47115;

    /** symtab.e:301		return p*/
    DeRefDS(_s_47113);
    return _p_47115;
    ;
}


object _53NewIntSym(object _int_val_47211)
{
    object _p_47213 = NOVALUE;
    object _x_47214 = NOVALUE;
    object _24454 = NOVALUE;
    object _24452 = NOVALUE;
    object _24448 = NOVALUE;
    object _24446 = NOVALUE;
    object _24444 = NOVALUE;
    object _24442 = NOVALUE;
    object _24440 = NOVALUE;
    object _24438 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:308		integer x*/

    /** symtab.e:310		x = find(int_val, lastintval)*/
    _x_47214 = find_from(_int_val_47211, _53lastintval_46813, 1);

    /** symtab.e:311		if x then*/
    if (_x_47214 == 0)
    {
        goto L1; // [14] 75
    }
    else{
    }

    /** symtab.e:312			if repl then*/

    /** symtab.e:317			return lastintsym[x]  -- saves space, helps Translator reduce code size*/
    _2 = (object)SEQ_PTR(_53lastintsym_46814);
    _24438 = (object)*(((s1_ptr)_2)->base + _x_47214);
    DeRef(_int_val_47211);
    return _24438;
    goto L2; // [72] 225
L1: 

    /** symtab.e:320			label "lolol"*/
G3:

    /** symtab.e:321			p = tmp_alloc()*/
    _p_47213 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_47213)) {
        _1 = (object)(DBL_PTR(_p_47213)->dbl);
        DeRefDS(_p_47213);
        _p_47213 = _1;
    }

    /** symtab.e:322			SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47213 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24440 = NOVALUE;

    /** symtab.e:323			SymTab[p][S_OBJ] = int_val*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47213 + ((s1_ptr)_2)->base);
    Ref(_int_val_47211);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47211;
    DeRef(_1);
    _24442 = NOVALUE;

    /** symtab.e:325			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L4; // [122] 173
    }
    else{
    }

    /** symtab.e:326				SymTab[p][S_OBJ_MIN] = int_val*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47213 + ((s1_ptr)_2)->base);
    Ref(_int_val_47211);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47211;
    DeRef(_1);
    _24444 = NOVALUE;

    /** symtab.e:327				SymTab[p][S_OBJ_MAX] = int_val*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47213 + ((s1_ptr)_2)->base);
    Ref(_int_val_47211);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47211;
    DeRef(_1);
    _24446 = NOVALUE;

    /** symtab.e:328				SymTab[p][S_GTYPE] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47213 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _24448 = NOVALUE;
L4: 

    /** symtab.e:331			lastintval = prepend(lastintval, int_val)*/
    Ref(_int_val_47211);
    Prepend(&_53lastintval_46813, _53lastintval_46813, _int_val_47211);

    /** symtab.e:332			lastintsym = prepend(lastintsym, p)*/
    Prepend(&_53lastintsym_46814, _53lastintsym_46814, _p_47213);

    /** symtab.e:333			if length(lastintval) > SEARCH_LIMIT then*/
    if (IS_SEQUENCE(_53lastintval_46813)){
            _24452 = SEQ_PTR(_53lastintval_46813)->length;
    }
    else {
        _24452 = 1;
    }
    if (binary_op_a(LESSEQ, _24452, _53SEARCH_LIMIT_47105)){
        _24452 = NOVALUE;
        goto L5; // [198] 218
    }
    _24452 = NOVALUE;

    /** symtab.e:334				lastintval = lastintval[1..floor(SEARCH_LIMIT/2)]*/
    if (IS_ATOM_INT(_53SEARCH_LIMIT_47105)) {
        _24454 = _53SEARCH_LIMIT_47105 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _53SEARCH_LIMIT_47105, 2);
        _24454 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    rhs_slice_target = (object_ptr)&_53lastintval_46813;
    RHS_Slice(_53lastintval_46813, 1, _24454);
L5: 

    /** symtab.e:336			return p*/
    DeRef(_int_val_47211);
    _24438 = NOVALUE;
    DeRef(_24454);
    _24454 = NOVALUE;
    return _p_47213;
L2: 
    ;
}


object _53NewDoubleSym(object _d_47263)
{
    object _p_47265 = NOVALUE;
    object _tp_47266 = NOVALUE;
    object _prev_47267 = NOVALUE;
    object _search_count_47268 = NOVALUE;
    object _24484 = NOVALUE;
    object _24483 = NOVALUE;
    object _24482 = NOVALUE;
    object _24481 = NOVALUE;
    object _24480 = NOVALUE;
    object _24478 = NOVALUE;
    object _24476 = NOVALUE;
    object _24474 = NOVALUE;
    object _24472 = NOVALUE;
    object _24469 = NOVALUE;
    object _24467 = NOVALUE;
    object _24466 = NOVALUE;
    object _24465 = NOVALUE;
    object _24463 = NOVALUE;
    object _24461 = NOVALUE;
    object _24460 = NOVALUE;
    object _24459 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:343		integer search_count*/

    /** symtab.e:346		tp = literal_init*/
    _tp_47266 = _53literal_init_46811;

    /** symtab.e:347		prev = 0*/
    _prev_47267 = 0;

    /** symtab.e:348		search_count = 0*/
    _search_count_47268 = 0;

    /** symtab.e:349		while tp != 0 do*/
L1: 
    if (_tp_47266 == 0)
    goto L2; // [29] 168

    /** symtab.e:350			search_count += 1*/
    _search_count_47268 = _search_count_47268 + 1;

    /** symtab.e:351			if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_47268, _53SEARCH_LIMIT_47105)){
        goto L3; // [43] 52
    }

    /** symtab.e:352				exit*/
    goto L2; // [49] 168
L3: 

    /** symtab.e:354			if equal(d, SymTab[tp][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24459 = (object)*(((s1_ptr)_2)->base + _tp_47266);
    _2 = (object)SEQ_PTR(_24459);
    _24460 = (object)*(((s1_ptr)_2)->base + 1);
    _24459 = NOVALUE;
    if (_d_47263 == _24460)
    _24461 = 1;
    else if (IS_ATOM_INT(_d_47263) && IS_ATOM_INT(_24460))
    _24461 = 0;
    else
    _24461 = (compare(_d_47263, _24460) == 0);
    _24460 = NOVALUE;
    if (_24461 == 0)
    {
        _24461 = NOVALUE;
        goto L4; // [70] 140
    }
    else{
        _24461 = NOVALUE;
    }

    /** symtab.e:356				if tp != literal_init then*/
    if (_tp_47266 == _53literal_init_46811)
    goto L5; // [77] 133

    /** symtab.e:358					SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_47267 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24465 = (object)*(((s1_ptr)_2)->base + _tp_47266);
    _2 = (object)SEQ_PTR(_24465);
    _24466 = (object)*(((s1_ptr)_2)->base + 2);
    _24465 = NOVALUE;
    Ref(_24466);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24466;
    if( _1 != _24466 ){
        DeRef(_1);
    }
    _24466 = NOVALUE;
    _24463 = NOVALUE;

    /** symtab.e:359					SymTab[tp][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_tp_47266 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53literal_init_46811;
    DeRef(_1);
    _24467 = NOVALUE;

    /** symtab.e:360					literal_init = tp*/
    _53literal_init_46811 = _tp_47266;
L5: 

    /** symtab.e:362				return tp*/
    DeRef(_d_47263);
    return _tp_47266;
L4: 

    /** symtab.e:364			prev = tp*/
    _prev_47267 = _tp_47266;

    /** symtab.e:365			tp = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24469 = (object)*(((s1_ptr)_2)->base + _tp_47266);
    _2 = (object)SEQ_PTR(_24469);
    _tp_47266 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_tp_47266)){
        _tp_47266 = (object)DBL_PTR(_tp_47266)->dbl;
    }
    _24469 = NOVALUE;

    /** symtab.e:366		end while*/
    goto L1; // [165] 29
L2: 

    /** symtab.e:368		p = tmp_alloc()*/
    _p_47265 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_47265)) {
        _1 = (object)(DBL_PTR(_p_47265)->dbl);
        DeRefDS(_p_47265);
        _p_47265 = _1;
    }

    /** symtab.e:369		SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47265 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24472 = NOVALUE;

    /** symtab.e:370		SymTab[p][S_OBJ] = d*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47265 + ((s1_ptr)_2)->base);
    Ref(_d_47263);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _d_47263;
    DeRef(_1);
    _24474 = NOVALUE;

    /** symtab.e:372		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L6; // [211] 285
    }
    else{
    }

    /** symtab.e:373			SymTab[p][S_MODE] = M_TEMP  -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47265 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _24476 = NOVALUE;

    /** symtab.e:374			SymTab[p][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47265 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24478 = NOVALUE;

    /** symtab.e:375			c_printf("object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24480 = (object)*(((s1_ptr)_2)->base + _p_47265);
    _2 = (object)SEQ_PTR(_24480);
    _24481 = (object)*(((s1_ptr)_2)->base + 34);
    _24480 = NOVALUE;
    RefDS(_24422);
    Ref(_24481);
    _54c_printf(_24422, _24481);
    _24481 = NOVALUE;

    /** symtab.e:376			c_hprintf("extern object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24482 = (object)*(((s1_ptr)_2)->base + _p_47265);
    _2 = (object)SEQ_PTR(_24482);
    _24483 = (object)*(((s1_ptr)_2)->base + 34);
    _24482 = NOVALUE;
    RefDS(_24425);
    Ref(_24483);
    _54c_hprintf(_24425, _24483);
    _24483 = NOVALUE;
L6: 

    /** symtab.e:379		SymTab[p][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47265 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53literal_init_46811;
    DeRef(_1);
    _24484 = NOVALUE;

    /** symtab.e:380		literal_init = p*/
    _53literal_init_46811 = _p_47265;

    /** symtab.e:381		return p*/
    DeRef(_d_47263);
    return _p_47265;
    ;
}


object _53NewTempSym(object _inlining_47337)
{
    object _p_47339 = NOVALUE;
    object _q_47340 = NOVALUE;
    object _24533 = NOVALUE;
    object _24531 = NOVALUE;
    object _24529 = NOVALUE;
    object _24527 = NOVALUE;
    object _24525 = NOVALUE;
    object _24523 = NOVALUE;
    object _24522 = NOVALUE;
    object _24521 = NOVALUE;
    object _24519 = NOVALUE;
    object _24518 = NOVALUE;
    object _24517 = NOVALUE;
    object _24515 = NOVALUE;
    object _24513 = NOVALUE;
    object _24510 = NOVALUE;
    object _24509 = NOVALUE;
    object _24508 = NOVALUE;
    object _24506 = NOVALUE;
    object _24504 = NOVALUE;
    object _24503 = NOVALUE;
    object _24502 = NOVALUE;
    object _24500 = NOVALUE;
    object _24498 = NOVALUE;
    object _24493 = NOVALUE;
    object _24492 = NOVALUE;
    object _24491 = NOVALUE;
    object _24490 = NOVALUE;
    object _24489 = NOVALUE;
    object _24488 = NOVALUE;
    object _24486 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:392		if inlining then*/
    if (_inlining_47337 == 0)
    {
        goto L1; // [5] 85
    }
    else{
    }

    /** symtab.e:393			p = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24486 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_24486);
    if (!IS_ATOM_INT(_12S_TEMPS_19909)){
        _p_47339 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    }
    else{
        _p_47339 = (object)*(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    }
    if (!IS_ATOM_INT(_p_47339)){
        _p_47339 = (object)DBL_PTR(_p_47339)->dbl;
    }
    _24486 = NOVALUE;

    /** symtab.e:394			while p != 0 and SymTab[p][S_SCOPE] != FREE do*/
L2: 
    _24488 = (_p_47339 != 0);
    if (_24488 == 0) {
        goto L3; // [35] 93
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24490 = (object)*(((s1_ptr)_2)->base + _p_47339);
    _2 = (object)SEQ_PTR(_24490);
    _24491 = (object)*(((s1_ptr)_2)->base + 4);
    _24490 = NOVALUE;
    if (IS_ATOM_INT(_24491)) {
        _24492 = (_24491 != 0);
    }
    else {
        _24492 = binary_op(NOTEQ, _24491, 0);
    }
    _24491 = NOVALUE;
    if (_24492 <= 0) {
        if (_24492 == 0) {
            DeRef(_24492);
            _24492 = NOVALUE;
            goto L3; // [58] 93
        }
        else {
            if (!IS_ATOM_INT(_24492) && DBL_PTR(_24492)->dbl == 0.0){
                DeRef(_24492);
                _24492 = NOVALUE;
                goto L3; // [58] 93
            }
            DeRef(_24492);
            _24492 = NOVALUE;
        }
    }
    DeRef(_24492);
    _24492 = NOVALUE;

    /** symtab.e:395				p = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24493 = (object)*(((s1_ptr)_2)->base + _p_47339);
    _2 = (object)SEQ_PTR(_24493);
    _p_47339 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_47339)){
        _p_47339 = (object)DBL_PTR(_p_47339)->dbl;
    }
    _24493 = NOVALUE;

    /** symtab.e:396			end while*/
    goto L2; // [79] 31
    goto L3; // [82] 93
L1: 

    /** symtab.e:398			p = 0*/
    _p_47339 = 0;
L3: 

    /** symtab.e:401		if p = 0 then*/
    if (_p_47339 != 0)
    goto L4; // [97] 213

    /** symtab.e:403			temps_allocated += 1*/
    _53temps_allocated_47334 = _53temps_allocated_47334 + 1;

    /** symtab.e:404			p = tmp_alloc()*/
    _p_47339 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_47339)) {
        _1 = (object)(DBL_PTR(_p_47339)->dbl);
        DeRefDS(_p_47339);
        _p_47339 = _1;
    }

    /** symtab.e:405			SymTab[p][S_MODE] = M_TEMP*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47339 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _24498 = NOVALUE;

    /** symtab.e:406			SymTab[p][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47339 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24502 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_24502);
    if (!IS_ATOM_INT(_12S_TEMPS_19909)){
        _24503 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    }
    else{
        _24503 = (object)*(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    }
    _24502 = NOVALUE;
    Ref(_24503);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24503;
    if( _1 != _24503 ){
        DeRef(_1);
    }
    _24503 = NOVALUE;
    _24500 = NOVALUE;

    /** symtab.e:407			SymTab[CurrentSub][S_TEMPS] = p*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TEMPS_19909))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_47339;
    DeRef(_1);
    _24504 = NOVALUE;

    /** symtab.e:409			if inlining then*/
    if (_inlining_47337 == 0)
    {
        goto L5; // [181] 343
    }
    else{
    }

    /** symtab.e:410				SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_12S_STACK_SPACE_19924)){
        _24508 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_STACK_SPACE_19924)->dbl));
    }
    else{
        _24508 = (object)*(((s1_ptr)_2)->base + _12S_STACK_SPACE_19924);
    }
    _24506 = NOVALUE;
    if (IS_ATOM_INT(_24508)) {
        _24509 = _24508 + 1;
        if (_24509 > MAXINT){
            _24509 = NewDouble((eudouble)_24509);
        }
    }
    else
    _24509 = binary_op(PLUS, 1, _24508);
    _24508 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_STACK_SPACE_19924))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_STACK_SPACE_19924)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_STACK_SPACE_19924);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24509;
    if( _1 != _24509 ){
        DeRef(_1);
    }
    _24509 = NOVALUE;
    _24506 = NOVALUE;
    goto L5; // [210] 343
L4: 

    /** symtab.e:413		elsif TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L6; // [217] 342
    }
    else{
    }

    /** symtab.e:418			SymTab[p][S_SCOPE] = DELETED*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47339 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24510 = NOVALUE;

    /** symtab.e:420			q = tmp_alloc()*/
    _q_47340 = _53tmp_alloc();
    if (!IS_ATOM_INT(_q_47340)) {
        _1 = (object)(DBL_PTR(_q_47340)->dbl);
        DeRefDS(_q_47340);
        _q_47340 = _1;
    }

    /** symtab.e:421			SymTab[q][S_MODE] = M_TEMP*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47340 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _24513 = NOVALUE;

    /** symtab.e:422			SymTab[q][S_TEMP_NAME] = SymTab[p][S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47340 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24517 = (object)*(((s1_ptr)_2)->base + _p_47339);
    _2 = (object)SEQ_PTR(_24517);
    _24518 = (object)*(((s1_ptr)_2)->base + 34);
    _24517 = NOVALUE;
    Ref(_24518);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24518;
    if( _1 != _24518 ){
        DeRef(_1);
    }
    _24518 = NOVALUE;
    _24515 = NOVALUE;

    /** symtab.e:423			SymTab[q][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47340 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24521 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_24521);
    if (!IS_ATOM_INT(_12S_TEMPS_19909)){
        _24522 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    }
    else{
        _24522 = (object)*(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    }
    _24521 = NOVALUE;
    Ref(_24522);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24522;
    if( _1 != _24522 ){
        DeRef(_1);
    }
    _24522 = NOVALUE;
    _24519 = NOVALUE;

    /** symtab.e:424			SymTab[CurrentSub][S_TEMPS] = q*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TEMPS_19909))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _q_47340;
    DeRef(_1);
    _24523 = NOVALUE;

    /** symtab.e:425			p = q*/
    _p_47339 = _q_47340;
L6: 
L5: 

    /** symtab.e:428		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L7; // [347] 385
    }
    else{
    }

    /** symtab.e:429			SymTab[p][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47339 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    _24525 = NOVALUE;

    /** symtab.e:430			SymTab[p][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47339 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    _24527 = NOVALUE;
L7: 

    /** symtab.e:433		SymTab[p][S_OBJ] = NOVALUE*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47339 + ((s1_ptr)_2)->base);
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
    _24529 = NOVALUE;

    /** symtab.e:434		SymTab[p][S_USAGE] = T_UNKNOWN*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47339 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4;
    DeRef(_1);
    _24531 = NOVALUE;

    /** symtab.e:435		SymTab[p][S_SCOPE] = IN_USE*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47339 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _24533 = NOVALUE;

    /** symtab.e:437		return p*/
    DeRef(_24488);
    _24488 = NOVALUE;
    return _p_47339;
    ;
}


void _53InitSymTab()
{
    object _hashval_47456 = NOVALUE;
    object _len_47457 = NOVALUE;
    object _s_47459 = NOVALUE;
    object _st_index_47460 = NOVALUE;
    object _kname_47461 = NOVALUE;
    object _fixups_47462 = NOVALUE;
    object _si_47601 = NOVALUE;
    object _sj_47602 = NOVALUE;
    object _25119 = NOVALUE;
    object _25118 = NOVALUE;
    object _24648 = NOVALUE;
    object _24647 = NOVALUE;
    object _24646 = NOVALUE;
    object _24645 = NOVALUE;
    object _24644 = NOVALUE;
    object _24642 = NOVALUE;
    object _24641 = NOVALUE;
    object _24640 = NOVALUE;
    object _24639 = NOVALUE;
    object _24637 = NOVALUE;
    object _24635 = NOVALUE;
    object _24633 = NOVALUE;
    object _24632 = NOVALUE;
    object _24630 = NOVALUE;
    object _24628 = NOVALUE;
    object _24626 = NOVALUE;
    object _24625 = NOVALUE;
    object _24623 = NOVALUE;
    object _24622 = NOVALUE;
    object _24621 = NOVALUE;
    object _24620 = NOVALUE;
    object _24619 = NOVALUE;
    object _24616 = NOVALUE;
    object _24615 = NOVALUE;
    object _24614 = NOVALUE;
    object _24612 = NOVALUE;
    object _24611 = NOVALUE;
    object _24610 = NOVALUE;
    object _24608 = NOVALUE;
    object _24607 = NOVALUE;
    object _24606 = NOVALUE;
    object _24603 = NOVALUE;
    object _24601 = NOVALUE;
    object _24599 = NOVALUE;
    object _24598 = NOVALUE;
    object _24595 = NOVALUE;
    object _24594 = NOVALUE;
    object _24592 = NOVALUE;
    object _24590 = NOVALUE;
    object _24588 = NOVALUE;
    object _24586 = NOVALUE;
    object _24585 = NOVALUE;
    object _24584 = NOVALUE;
    object _24581 = NOVALUE;
    object _24580 = NOVALUE;
    object _24578 = NOVALUE;
    object _24577 = NOVALUE;
    object _24575 = NOVALUE;
    object _24574 = NOVALUE;
    object _24573 = NOVALUE;
    object _24571 = NOVALUE;
    object _24569 = NOVALUE;
    object _24568 = NOVALUE;
    object _24566 = NOVALUE;
    object _24565 = NOVALUE;
    object _24564 = NOVALUE;
    object _24562 = NOVALUE;
    object _24561 = NOVALUE;
    object _24560 = NOVALUE;
    object _24558 = NOVALUE;
    object _24557 = NOVALUE;
    object _24556 = NOVALUE;
    object _24554 = NOVALUE;
    object _24553 = NOVALUE;
    object _24552 = NOVALUE;
    object _24551 = NOVALUE;
    object _24550 = NOVALUE;
    object _24549 = NOVALUE;
    object _24548 = NOVALUE;
    object _24547 = NOVALUE;
    object _24546 = NOVALUE;
    object _24545 = NOVALUE;
    object _24543 = NOVALUE;
    object _24542 = NOVALUE;
    object _24541 = NOVALUE;
    object _24540 = NOVALUE;
    object _24536 = NOVALUE;
    object _24535 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:445		sequence kname, fixups = {}*/
    RefDS(_22015);
    DeRefi(_fixups_47462);
    _fixups_47462 = _22015;

    /** symtab.e:447		for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_62keylist_23148)){
            _24535 = SEQ_PTR(_62keylist_23148)->length;
    }
    else {
        _24535 = 1;
    }
    {
        object _k_47464;
        _k_47464 = 1;
L1: 
        if (_k_47464 > _24535){
            goto L2; // [15] 560
        }

        /** symtab.e:448			kname = keylist[k][K_NAME]*/
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24536 = (object)*(((s1_ptr)_2)->base + _k_47464);
        DeRef(_kname_47461);
        _2 = (object)SEQ_PTR(_24536);
        _kname_47461 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_kname_47461);
        _24536 = NOVALUE;

        /** symtab.e:449			len = length(kname)*/
        if (IS_SEQUENCE(_kname_47461)){
                _len_47457 = SEQ_PTR(_kname_47461)->length;
        }
        else {
            _len_47457 = 1;
        }

        /** symtab.e:450			hashval = hashfn(kname)*/
        RefDS(_kname_47461);
        _hashval_47456 = _53hashfn(_kname_47461);
        if (!IS_ATOM_INT(_hashval_47456)) {
            _1 = (object)(DBL_PTR(_hashval_47456)->dbl);
            DeRefDS(_hashval_47456);
            _hashval_47456 = _1;
        }

        /** symtab.e:451			st_index = NewEntry(kname,*/
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24540 = (object)*(((s1_ptr)_2)->base + _k_47464);
        _2 = (object)SEQ_PTR(_24540);
        _24541 = (object)*(((s1_ptr)_2)->base + 2);
        _24540 = NOVALUE;
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24542 = (object)*(((s1_ptr)_2)->base + _k_47464);
        _2 = (object)SEQ_PTR(_24542);
        _24543 = (object)*(((s1_ptr)_2)->base + 3);
        _24542 = NOVALUE;
        RefDS(_kname_47461);
        Ref(_24541);
        Ref(_24543);
        _st_index_47460 = _53NewEntry(_kname_47461, 0, _24541, _24543, _hashval_47456, 0, 0);
        _24541 = NOVALUE;
        _24543 = NOVALUE;
        if (!IS_ATOM_INT(_st_index_47460)) {
            _1 = (object)(DBL_PTR(_st_index_47460)->dbl);
            DeRefDS(_st_index_47460);
            _st_index_47460 = _1;
        }

        /** symtab.e:456			if find(keylist[k][K_TOKEN], RTN_TOKS) then*/
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24545 = (object)*(((s1_ptr)_2)->base + _k_47464);
        _2 = (object)SEQ_PTR(_24545);
        _24546 = (object)*(((s1_ptr)_2)->base + 3);
        _24545 = NOVALUE;
        _24547 = find_from(_24546, _29RTN_TOKS_12006, 1);
        _24546 = NOVALUE;
        if (_24547 == 0)
        {
            _24547 = NOVALUE;
            goto L3; // [110] 325
        }
        else{
            _24547 = NOVALUE;
        }

        /** symtab.e:457				SymTab[st_index] = SymTab[st_index] &*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24548 = (object)*(((s1_ptr)_2)->base + _st_index_47460);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24549 = (object)*(((s1_ptr)_2)->base + _st_index_47460);
        if (IS_SEQUENCE(_24549)){
                _24550 = SEQ_PTR(_24549)->length;
        }
        else {
            _24550 = 1;
        }
        _24549 = NOVALUE;
        _24551 = _12SIZEOF_ROUTINE_ENTRY_19990 - _24550;
        _24550 = NOVALUE;
        _24552 = Repeat(0, _24551);
        _24551 = NOVALUE;
        if (IS_SEQUENCE(_24548) && IS_ATOM(_24552)) {
        }
        else if (IS_ATOM(_24548) && IS_SEQUENCE(_24552)) {
            Ref(_24548);
            Prepend(&_24553, _24552, _24548);
        }
        else {
            Concat((object_ptr)&_24553, _24548, _24552);
            _24548 = NOVALUE;
        }
        _24548 = NOVALUE;
        DeRefDS(_24552);
        _24552 = NOVALUE;
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _st_index_47460);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24553;
        if( _1 != _24553 ){
            DeRef(_1);
        }
        _24553 = NOVALUE;

        /** symtab.e:460				SymTab[st_index][S_NUM_ARGS] = keylist[k][K_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47460 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24556 = (object)*(((s1_ptr)_2)->base + _k_47464);
        _2 = (object)SEQ_PTR(_24556);
        _24557 = (object)*(((s1_ptr)_2)->base + 5);
        _24556 = NOVALUE;
        Ref(_24557);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_12S_NUM_ARGS_19915))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24557;
        if( _1 != _24557 ){
            DeRef(_1);
        }
        _24557 = NOVALUE;
        _24554 = NOVALUE;

        /** symtab.e:461				SymTab[st_index][S_OPCODE] = keylist[k][K_OPCODE]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47460 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24560 = (object)*(((s1_ptr)_2)->base + _k_47464);
        _2 = (object)SEQ_PTR(_24560);
        _24561 = (object)*(((s1_ptr)_2)->base + 4);
        _24560 = NOVALUE;
        Ref(_24561);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 21);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24561;
        if( _1 != _24561 ){
            DeRef(_1);
        }
        _24561 = NOVALUE;
        _24558 = NOVALUE;

        /** symtab.e:462				SymTab[st_index][S_EFFECT] = keylist[k][K_EFFECT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47460 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24564 = (object)*(((s1_ptr)_2)->base + _k_47464);
        _2 = (object)SEQ_PTR(_24564);
        _24565 = (object)*(((s1_ptr)_2)->base + 6);
        _24564 = NOVALUE;
        Ref(_24565);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 23);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24565;
        if( _1 != _24565 ){
            DeRef(_1);
        }
        _24565 = NOVALUE;
        _24562 = NOVALUE;

        /** symtab.e:463				SymTab[st_index][S_REFLIST] = {}*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47460 + ((s1_ptr)_2)->base);
        RefDS(_22015);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 24);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _22015;
        DeRef(_1);
        _24566 = NOVALUE;

        /** symtab.e:464				if length(keylist[k]) > K_EFFECT then*/
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24568 = (object)*(((s1_ptr)_2)->base + _k_47464);
        if (IS_SEQUENCE(_24568)){
                _24569 = SEQ_PTR(_24568)->length;
        }
        else {
            _24569 = 1;
        }
        _24568 = NOVALUE;
        if (_24569 <= 6)
        goto L4; // [259] 324

        /** symtab.e:465				    SymTab[st_index][S_CODE] = keylist[k][K_CODE]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47460 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24573 = (object)*(((s1_ptr)_2)->base + _k_47464);
        _2 = (object)SEQ_PTR(_24573);
        _24574 = (object)*(((s1_ptr)_2)->base + 7);
        _24573 = NOVALUE;
        Ref(_24574);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_12S_CODE_19876))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24574;
        if( _1 != _24574 ){
            DeRef(_1);
        }
        _24574 = NOVALUE;
        _24571 = NOVALUE;

        /** symtab.e:466				    SymTab[st_index][S_DEF_ARGS] = keylist[k][K_DEF_ARGS]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47460 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24577 = (object)*(((s1_ptr)_2)->base + _k_47464);
        _2 = (object)SEQ_PTR(_24577);
        _24578 = (object)*(((s1_ptr)_2)->base + 8);
        _24577 = NOVALUE;
        Ref(_24578);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 28);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24578;
        if( _1 != _24578 ){
            DeRef(_1);
        }
        _24578 = NOVALUE;
        _24575 = NOVALUE;

        /** symtab.e:467				    fixups &= st_index*/
        Append(&_fixups_47462, _fixups_47462, _st_index_47460);
L4: 
L3: 

        /** symtab.e:470			if keylist[k][K_TOKEN] = PROC then*/
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24580 = (object)*(((s1_ptr)_2)->base + _k_47464);
        _2 = (object)SEQ_PTR(_24580);
        _24581 = (object)*(((s1_ptr)_2)->base + 3);
        _24580 = NOVALUE;
        if (binary_op_a(NOTEQ, _24581, 27)){
            _24581 = NOVALUE;
            goto L5; // [341] 365
        }
        _24581 = NOVALUE;

        /** symtab.e:471				if equal(kname, "<TopLevel>") then*/
        if (_kname_47461 == _24583)
        _24584 = 1;
        else if (IS_ATOM_INT(_kname_47461) && IS_ATOM_INT(_24583))
        _24584 = 0;
        else
        _24584 = (compare(_kname_47461, _24583) == 0);
        if (_24584 == 0)
        {
            _24584 = NOVALUE;
            goto L6; // [351] 462
        }
        else{
            _24584 = NOVALUE;
        }

        /** symtab.e:472					TopLevelSub = st_index*/
        _12TopLevelSub_20233 = _st_index_47460;
        goto L6; // [362] 462
L5: 

        /** symtab.e:474			elsif keylist[k][K_TOKEN] = TYPE then*/
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24585 = (object)*(((s1_ptr)_2)->base + _k_47464);
        _2 = (object)SEQ_PTR(_24585);
        _24586 = (object)*(((s1_ptr)_2)->base + 3);
        _24585 = NOVALUE;
        if (binary_op_a(NOTEQ, _24586, 504)){
            _24586 = NOVALUE;
            goto L7; // [381] 461
        }
        _24586 = NOVALUE;

        /** symtab.e:475				if equal(kname, "object") then*/
        if (_kname_47461 == _22977)
        _24588 = 1;
        else if (IS_ATOM_INT(_kname_47461) && IS_ATOM_INT(_22977))
        _24588 = 0;
        else
        _24588 = (compare(_kname_47461, _22977) == 0);
        if (_24588 == 0)
        {
            _24588 = NOVALUE;
            goto L8; // [391] 404
        }
        else{
            _24588 = NOVALUE;
        }

        /** symtab.e:476					object_type = st_index*/
        _53object_type_46803 = _st_index_47460;
        goto L9; // [401] 460
L8: 

        /** symtab.e:477				elsif equal(kname, "atom") then*/
        if (_kname_47461 == _24589)
        _24590 = 1;
        else if (IS_ATOM_INT(_kname_47461) && IS_ATOM_INT(_24589))
        _24590 = 0;
        else
        _24590 = (compare(_kname_47461, _24589) == 0);
        if (_24590 == 0)
        {
            _24590 = NOVALUE;
            goto LA; // [410] 423
        }
        else{
            _24590 = NOVALUE;
        }

        /** symtab.e:478					atom_type = st_index*/
        _53atom_type_46805 = _st_index_47460;
        goto L9; // [420] 460
LA: 

        /** symtab.e:479				elsif equal(kname, "integer") then*/
        if (_kname_47461 == _24591)
        _24592 = 1;
        else if (IS_ATOM_INT(_kname_47461) && IS_ATOM_INT(_24591))
        _24592 = 0;
        else
        _24592 = (compare(_kname_47461, _24591) == 0);
        if (_24592 == 0)
        {
            _24592 = NOVALUE;
            goto LB; // [429] 442
        }
        else{
            _24592 = NOVALUE;
        }

        /** symtab.e:480					integer_type = st_index*/
        _53integer_type_46809 = _st_index_47460;
        goto L9; // [439] 460
LB: 

        /** symtab.e:481				elsif equal(kname, "sequence") then*/
        if (_kname_47461 == _24593)
        _24594 = 1;
        else if (IS_ATOM_INT(_kname_47461) && IS_ATOM_INT(_24593))
        _24594 = 0;
        else
        _24594 = (compare(_kname_47461, _24593) == 0);
        if (_24594 == 0)
        {
            _24594 = NOVALUE;
            goto LC; // [448] 459
        }
        else{
            _24594 = NOVALUE;
        }

        /** symtab.e:482					sequence_type = st_index*/
        _53sequence_type_46807 = _st_index_47460;
LC: 
L9: 
L7: 
L6: 

        /** symtab.e:485			if buckets[hashval] = 0 then*/
        _2 = (object)SEQ_PTR(_53buckets_46799);
        _24595 = (object)*(((s1_ptr)_2)->base + _hashval_47456);
        if (binary_op_a(NOTEQ, _24595, 0)){
            _24595 = NOVALUE;
            goto LD; // [470] 485
        }
        _24595 = NOVALUE;

        /** symtab.e:486				buckets[hashval] = st_index*/
        _2 = (object)SEQ_PTR(_53buckets_46799);
        _2 = (object)(((s1_ptr)_2)->base + _hashval_47456);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _st_index_47460;
        DeRef(_1);
        goto LE; // [482] 553
LD: 

        /** symtab.e:488				s = buckets[hashval]*/
        _2 = (object)SEQ_PTR(_53buckets_46799);
        _s_47459 = (object)*(((s1_ptr)_2)->base + _hashval_47456);
        if (!IS_ATOM_INT(_s_47459)){
            _s_47459 = (object)DBL_PTR(_s_47459)->dbl;
        }

        /** symtab.e:489				while SymTab[s][S_SAMEHASH] != 0 do*/
LF: 
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24598 = (object)*(((s1_ptr)_2)->base + _s_47459);
        _2 = (object)SEQ_PTR(_24598);
        _24599 = (object)*(((s1_ptr)_2)->base + 9);
        _24598 = NOVALUE;
        if (binary_op_a(EQUALS, _24599, 0)){
            _24599 = NOVALUE;
            goto L10; // [512] 537
        }
        _24599 = NOVALUE;

        /** symtab.e:490					s = SymTab[s][S_SAMEHASH]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24601 = (object)*(((s1_ptr)_2)->base + _s_47459);
        _2 = (object)SEQ_PTR(_24601);
        _s_47459 = (object)*(((s1_ptr)_2)->base + 9);
        if (!IS_ATOM_INT(_s_47459)){
            _s_47459 = (object)DBL_PTR(_s_47459)->dbl;
        }
        _24601 = NOVALUE;

        /** symtab.e:491				end while*/
        goto LF; // [534] 500
L10: 

        /** symtab.e:492				SymTab[s][S_SAMEHASH] = st_index*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_47459 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 9);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _st_index_47460;
        DeRef(_1);
        _24603 = NOVALUE;
LE: 

        /** symtab.e:494		end for*/
        _k_47464 = _k_47464 + 1;
        goto L1; // [555] 22
L2: 
        ;
    }

    /** symtab.e:495		file_start_sym = length(SymTab)*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _12file_start_sym_20232 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _12file_start_sym_20232 = 1;
    }

    /** symtab.e:497		sequence si, sj*/

    /** symtab.e:498		CurrentSub = TopLevelSub*/
    _12CurrentSub_20234 = _12TopLevelSub_20233;

    /** symtab.e:499		for i=1 to length(fixups) do*/
    if (IS_SEQUENCE(_fixups_47462)){
            _24606 = SEQ_PTR(_fixups_47462)->length;
    }
    else {
        _24606 = 1;
    }
    {
        object _i_47606;
        _i_47606 = 1;
L11: 
        if (_i_47606 > _24606){
            goto L12; // [585] 946
        }

        /** symtab.e:500		    si = SymTab[fixups[i]][S_CODE] -- seq of either 0's or sequences of tokens*/
        _2 = (object)SEQ_PTR(_fixups_47462);
        _24607 = (object)*(((s1_ptr)_2)->base + _i_47606);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24608 = (object)*(((s1_ptr)_2)->base + _24607);
        DeRef(_si_47601);
        _2 = (object)SEQ_PTR(_24608);
        if (!IS_ATOM_INT(_12S_CODE_19876)){
            _si_47601 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        }
        else{
            _si_47601 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
        }
        Ref(_si_47601);
        _24608 = NOVALUE;

        /** symtab.e:501		    for j=1 to length(si) do*/
        if (IS_SEQUENCE(_si_47601)){
                _24610 = SEQ_PTR(_si_47601)->length;
        }
        else {
            _24610 = 1;
        }
        {
            object _j_47614;
            _j_47614 = 1;
L13: 
            if (_j_47614 > _24610){
                goto L14; // [617] 920
            }

            /** symtab.e:502		        if sequence(si[j]) then*/
            _2 = (object)SEQ_PTR(_si_47601);
            _24611 = (object)*(((s1_ptr)_2)->base + _j_47614);
            _24612 = IS_SEQUENCE(_24611);
            _24611 = NOVALUE;
            if (_24612 == 0)
            {
                _24612 = NOVALUE;
                goto L15; // [633] 913
            }
            else{
                _24612 = NOVALUE;
            }

            /** symtab.e:503		            sj = si[j] -- a sequence of tokens*/
            DeRef(_sj_47602);
            _2 = (object)SEQ_PTR(_si_47601);
            _sj_47602 = (object)*(((s1_ptr)_2)->base + _j_47614);
            Ref(_sj_47602);

            /** symtab.e:504					for ij=1 to length(sj) do*/
            if (IS_SEQUENCE(_sj_47602)){
                    _24614 = SEQ_PTR(_sj_47602)->length;
            }
            else {
                _24614 = 1;
            }
            {
                object _ij_47621;
                _ij_47621 = 1;
L16: 
                if (_ij_47621 > _24614){
                    goto L17; // [649] 906
                }

                /** symtab.e:505		                switch sj[ij][T_ID] with fallthru do*/
                _2 = (object)SEQ_PTR(_sj_47602);
                _24615 = (object)*(((s1_ptr)_2)->base + _ij_47621);
                _2 = (object)SEQ_PTR(_24615);
                _24616 = (object)*(((s1_ptr)_2)->base + 1);
                _24615 = NOVALUE;
                if (IS_SEQUENCE(_24616) ){
                    goto L18; // [668] 899
                }
                if(!IS_ATOM_INT(_24616)){
                    if( (DBL_PTR(_24616)->dbl != (eudouble) ((object) DBL_PTR(_24616)->dbl) ) ){
                        goto L18; // [668] 899
                    }
                    _0 = (object) DBL_PTR(_24616)->dbl;
                }
                else {
                    _0 = _24616;
                };
                _24616 = NOVALUE;
                switch ( _0 ){ 

                    /** symtab.e:506		                    case ATOM then -- must create a lasting temp*/
                    case 502:

                    /** symtab.e:507		                    	if is_integer(sj[ij][T_SYM]) then*/
                    _2 = (object)SEQ_PTR(_sj_47602);
                    _24619 = (object)*(((s1_ptr)_2)->base + _ij_47621);
                    _2 = (object)SEQ_PTR(_24619);
                    _24620 = (object)*(((s1_ptr)_2)->base + 2);
                    _24619 = NOVALUE;
                    Ref(_24620);
                    _24621 = _12is_integer(_24620);
                    _24620 = NOVALUE;
                    if (_24621 == 0) {
                        DeRef(_24621);
                        _24621 = NOVALUE;
                        goto L19; // [693] 717
                    }
                    else {
                        if (!IS_ATOM_INT(_24621) && DBL_PTR(_24621)->dbl == 0.0){
                            DeRef(_24621);
                            _24621 = NOVALUE;
                            goto L19; // [693] 717
                        }
                        DeRef(_24621);
                        _24621 = NOVALUE;
                    }
                    DeRef(_24621);
                    _24621 = NOVALUE;

                    /** symtab.e:508									st_index = NewIntSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47602);
                    _24622 = (object)*(((s1_ptr)_2)->base + _ij_47621);
                    _2 = (object)SEQ_PTR(_24622);
                    _24623 = (object)*(((s1_ptr)_2)->base + 2);
                    _24622 = NOVALUE;
                    Ref(_24623);
                    _st_index_47460 = _53NewIntSym(_24623);
                    _24623 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47460)) {
                        _1 = (object)(DBL_PTR(_st_index_47460)->dbl);
                        DeRefDS(_st_index_47460);
                        _st_index_47460 = _1;
                    }
                    goto L1A; // [714] 736
L19: 

                    /** symtab.e:510									st_index = NewDoubleSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47602);
                    _24625 = (object)*(((s1_ptr)_2)->base + _ij_47621);
                    _2 = (object)SEQ_PTR(_24625);
                    _24626 = (object)*(((s1_ptr)_2)->base + 2);
                    _24625 = NOVALUE;
                    Ref(_24626);
                    _st_index_47460 = _53NewDoubleSym(_24626);
                    _24626 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47460)) {
                        _1 = (object)(DBL_PTR(_st_index_47460)->dbl);
                        DeRefDS(_st_index_47460);
                        _st_index_47460 = _1;
                    }
L1A: 

                    /** symtab.e:512								SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (object)SEQ_PTR(_13SymTab_11316);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _13SymTab_11316 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_st_index_47460 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 4);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = 1;
                    DeRef(_1);
                    _24628 = NOVALUE;

                    /** symtab.e:513								sj[ij][T_SYM] = st_index*/
                    _2 = (object)SEQ_PTR(_sj_47602);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47602 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_47621 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _st_index_47460;
                    DeRef(_1);
                    _24630 = NOVALUE;

                    /** symtab.e:514								break*/
                    goto L18; // [770] 899

                    /** symtab.e:515							case STRING then -- same*/
                    case 503:

                    /** symtab.e:516		                    	st_index = NewStringSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47602);
                    _24632 = (object)*(((s1_ptr)_2)->base + _ij_47621);
                    _2 = (object)SEQ_PTR(_24632);
                    _24633 = (object)*(((s1_ptr)_2)->base + 2);
                    _24632 = NOVALUE;
                    Ref(_24633);
                    _st_index_47460 = _53NewStringSym(_24633);
                    _24633 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47460)) {
                        _1 = (object)(DBL_PTR(_st_index_47460)->dbl);
                        DeRefDS(_st_index_47460);
                        _st_index_47460 = _1;
                    }

                    /** symtab.e:517								SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (object)SEQ_PTR(_13SymTab_11316);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _13SymTab_11316 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_st_index_47460 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 4);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = 1;
                    DeRef(_1);
                    _24635 = NOVALUE;

                    /** symtab.e:518								sj[ij][T_SYM] = st_index*/
                    _2 = (object)SEQ_PTR(_sj_47602);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47602 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_47621 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _st_index_47460;
                    DeRef(_1);
                    _24637 = NOVALUE;

                    /** symtab.e:519								break*/
                    goto L18; // [826] 899

                    /** symtab.e:520							case BUILT_IN then -- name of a builtin in econd field*/
                    case 511:

                    /** symtab.e:521	                            sj[ij] = keyfind(sj[ij][T_SYM],-1)*/
                    _2 = (object)SEQ_PTR(_sj_47602);
                    _24639 = (object)*(((s1_ptr)_2)->base + _ij_47621);
                    _2 = (object)SEQ_PTR(_24639);
                    _24640 = (object)*(((s1_ptr)_2)->base + 2);
                    _24639 = NOVALUE;
                    Ref(_24640);
                    DeRef(_25118);
                    _25118 = _24640;
                    _25119 = _53hashfn(_25118);
                    _25118 = NOVALUE;
                    Ref(_24640);
                    _24641 = _53keyfind(_24640, -1, _12current_file_no_20226, 0, _25119);
                    _24640 = NOVALUE;
                    _25119 = NOVALUE;
                    _2 = (object)SEQ_PTR(_sj_47602);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47602 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + _ij_47621);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _24641;
                    if( _1 != _24641 ){
                        DeRef(_1);
                    }
                    _24641 = NOVALUE;

                    /** symtab.e:522								break*/
                    goto L18; // [867] 899

                    /** symtab.e:523							case DEF_PARAM then*/
                    case 510:

                    /** symtab.e:524								sj[ij][T_SYM] &= fixups[i]*/
                    _2 = (object)SEQ_PTR(_sj_47602);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47602 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_47621 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(_fixups_47462);
                    _24644 = (object)*(((s1_ptr)_2)->base + _i_47606);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    _24645 = (object)*(((s1_ptr)_2)->base + 2);
                    _24642 = NOVALUE;
                    if (IS_SEQUENCE(_24645) && IS_ATOM(_24644)) {
                        Append(&_24646, _24645, _24644);
                    }
                    else if (IS_ATOM(_24645) && IS_SEQUENCE(_24644)) {
                    }
                    else {
                        Concat((object_ptr)&_24646, _24645, _24644);
                        _24645 = NOVALUE;
                    }
                    _24645 = NOVALUE;
                    _24644 = NOVALUE;
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _24646;
                    if( _1 != _24646 ){
                        DeRef(_1);
                    }
                    _24646 = NOVALUE;
                    _24642 = NOVALUE;
                ;}L18: 

                /** symtab.e:526					end for*/
                _ij_47621 = _ij_47621 + 1;
                goto L16; // [901] 656
L17: 
                ;
            }

            /** symtab.e:527					si[j] = sj*/
            RefDS(_sj_47602);
            _2 = (object)SEQ_PTR(_si_47601);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _si_47601 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _j_47614);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _sj_47602;
            DeRef(_1);
L15: 

            /** symtab.e:529			end for*/
            _j_47614 = _j_47614 + 1;
            goto L13; // [915] 624
L14: 
            ;
        }

        /** symtab.e:530			SymTab[fixups[i]][S_CODE] = si*/
        _2 = (object)SEQ_PTR(_fixups_47462);
        _24647 = (object)*(((s1_ptr)_2)->base + _i_47606);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_24647 + ((s1_ptr)_2)->base);
        RefDS(_si_47601);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_12S_CODE_19876))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _si_47601;
        DeRef(_1);
        _24648 = NOVALUE;

        /** symtab.e:531		end for*/
        _i_47606 = _i_47606 + 1;
        goto L11; // [941] 592
L12: 
        ;
    }

    /** symtab.e:532	end procedure*/
    DeRef(_kname_47461);
    DeRefi(_fixups_47462);
    DeRef(_si_47601);
    DeRef(_sj_47602);
    _24647 = NOVALUE;
    _24549 = NOVALUE;
    _24568 = NOVALUE;
    _24607 = NOVALUE;
    return;
    ;
}


void _53add_ref(object _tok_47690)
{
    object _s_47692 = NOVALUE;
    object _24664 = NOVALUE;
    object _24663 = NOVALUE;
    object _24661 = NOVALUE;
    object _24660 = NOVALUE;
    object _24659 = NOVALUE;
    object _24657 = NOVALUE;
    object _24656 = NOVALUE;
    object _24655 = NOVALUE;
    object _24654 = NOVALUE;
    object _24653 = NOVALUE;
    object _24652 = NOVALUE;
    object _24651 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:538		s = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_47690);
    _s_47692 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_47692)){
        _s_47692 = (object)DBL_PTR(_s_47692)->dbl;
    }

    /** symtab.e:539		if s != CurrentSub and -- ignore self-ref's*/
    _24651 = (_s_47692 != _12CurrentSub_20234);
    if (_24651 == 0) {
        goto L1; // [19] 98
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24653 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_24653);
    _24654 = (object)*(((s1_ptr)_2)->base + 24);
    _24653 = NOVALUE;
    _24655 = find_from(_s_47692, _24654, 1);
    _24654 = NOVALUE;
    _24656 = (_24655 == 0);
    _24655 = NOVALUE;
    if (_24656 == 0)
    {
        DeRef(_24656);
        _24656 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        DeRef(_24656);
        _24656 = NOVALUE;
    }

    /** symtab.e:542			SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_47692 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24659 = (object)*(((s1_ptr)_2)->base + 12);
    _24657 = NOVALUE;
    if (IS_ATOM_INT(_24659)) {
        _24660 = _24659 + 1;
        if (_24660 > MAXINT){
            _24660 = NewDouble((eudouble)_24660);
        }
    }
    else
    _24660 = binary_op(PLUS, 1, _24659);
    _24659 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24660;
    if( _1 != _24660 ){
        DeRef(_1);
    }
    _24660 = NOVALUE;
    _24657 = NOVALUE;

    /** symtab.e:543			SymTab[CurrentSub][S_REFLIST] &= s*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24663 = (object)*(((s1_ptr)_2)->base + 24);
    _24661 = NOVALUE;
    if (IS_SEQUENCE(_24663) && IS_ATOM(_s_47692)) {
        Append(&_24664, _24663, _s_47692);
    }
    else if (IS_ATOM(_24663) && IS_SEQUENCE(_s_47692)) {
    }
    else {
        Concat((object_ptr)&_24664, _24663, _s_47692);
        _24663 = NOVALUE;
    }
    _24663 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24664;
    if( _1 != _24664 ){
        DeRef(_1);
    }
    _24664 = NOVALUE;
    _24661 = NOVALUE;
L1: 

    /** symtab.e:545	end procedure*/
    DeRef(_tok_47690);
    DeRef(_24651);
    _24651 = NOVALUE;
    return;
    ;
}


void _53mark_all(object _attribute_47722)
{
    object _p_47725 = NOVALUE;
    object _sym_file_47732 = NOVALUE;
    object _scope_47749 = NOVALUE;
    object _24696 = NOVALUE;
    object _24695 = NOVALUE;
    object _24694 = NOVALUE;
    object _24692 = NOVALUE;
    object _24690 = NOVALUE;
    object _24689 = NOVALUE;
    object _24688 = NOVALUE;
    object _24687 = NOVALUE;
    object _24686 = NOVALUE;
    object _24684 = NOVALUE;
    object _24683 = NOVALUE;
    object _24682 = NOVALUE;
    object _24681 = NOVALUE;
    object _24677 = NOVALUE;
    object _24676 = NOVALUE;
    object _24675 = NOVALUE;
    object _24673 = NOVALUE;
    object _24672 = NOVALUE;
    object _24670 = NOVALUE;
    object _24668 = NOVALUE;
    object _24665 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:550		if just_mark_everything_from then*/
    if (_53just_mark_everything_from_47719 == 0)
    {
        goto L1; // [7] 270
    }
    else{
    }

    /** symtab.e:551			symtab_pointer p = SymTab[just_mark_everything_from][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24665 = (object)*(((s1_ptr)_2)->base + _53just_mark_everything_from_47719);
    _2 = (object)SEQ_PTR(_24665);
    _p_47725 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_47725)){
        _p_47725 = (object)DBL_PTR(_p_47725)->dbl;
    }
    _24665 = NOVALUE;

    /** symtab.e:552			while p != 0 do*/
L2: 
    if (_p_47725 == 0)
    goto L3; // [33] 269

    /** symtab.e:553				integer sym_file = SymTab[p][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24668 = (object)*(((s1_ptr)_2)->base + _p_47725);
    _2 = (object)SEQ_PTR(_24668);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _sym_file_47732 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _sym_file_47732 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    if (!IS_ATOM_INT(_sym_file_47732)){
        _sym_file_47732 = (object)DBL_PTR(_sym_file_47732)->dbl;
    }
    _24668 = NOVALUE;

    /** symtab.e:554				just_mark_everything_from = p*/
    _53just_mark_everything_from_47719 = _p_47725;

    /** symtab.e:555				if sym_file = current_file_no or map:has( recheck_routines, sym_file ) then*/
    _24670 = (_sym_file_47732 == _12current_file_no_20226);
    if (_24670 != 0) {
        goto L4; // [68] 84
    }
    Ref(_53recheck_routines_47792);
    _24672 = _34has(_53recheck_routines_47792, _sym_file_47732);
    if (_24672 == 0) {
        DeRef(_24672);
        _24672 = NOVALUE;
        goto L5; // [80] 108
    }
    else {
        if (!IS_ATOM_INT(_24672) && DBL_PTR(_24672)->dbl == 0.0){
            DeRef(_24672);
            _24672 = NOVALUE;
            goto L5; // [80] 108
        }
        DeRef(_24672);
        _24672 = NOVALUE;
    }
    DeRef(_24672);
    _24672 = NOVALUE;
L4: 

    /** symtab.e:556					SymTab[p][attribute] += 1*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47725 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24675 = (object)*(((s1_ptr)_2)->base + _attribute_47722);
    _24673 = NOVALUE;
    if (IS_ATOM_INT(_24675)) {
        _24676 = _24675 + 1;
        if (_24676 > MAXINT){
            _24676 = NewDouble((eudouble)_24676);
        }
    }
    else
    _24676 = binary_op(PLUS, 1, _24675);
    _24675 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _attribute_47722);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24676;
    if( _1 != _24676 ){
        DeRef(_1);
    }
    _24676 = NOVALUE;
    _24673 = NOVALUE;
    goto L6; // [105] 246
L5: 

    /** symtab.e:558					integer scope = SymTab[p][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24677 = (object)*(((s1_ptr)_2)->base + _p_47725);
    _2 = (object)SEQ_PTR(_24677);
    _scope_47749 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_47749)){
        _scope_47749 = (object)DBL_PTR(_scope_47749)->dbl;
    }
    _24677 = NOVALUE;

    /** symtab.e:559					switch scope with fallthru do*/
    _0 = _scope_47749;
    switch ( _0 ){ 

        /** symtab.e:560						case SC_PUBLIC then*/
        case 13:

        /** symtab.e:561							if and_bits( DIRECT_OR_PUBLIC_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _24681 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
        _2 = (object)SEQ_PTR(_24681);
        _24682 = (object)*(((s1_ptr)_2)->base + _sym_file_47732);
        _24681 = NOVALUE;
        if (IS_ATOM_INT(_24682)) {
            {uintptr_t tu;
                 tu = (uintptr_t)6 & (uintptr_t)_24682;
                 _24683 = MAKE_UINT(tu);
            }
        }
        else {
            _24683 = binary_op(AND_BITS, 6, _24682);
        }
        _24682 = NOVALUE;
        if (_24683 == 0) {
            DeRef(_24683);
            _24683 = NOVALUE;
            goto L7; // [155] 243
        }
        else {
            if (!IS_ATOM_INT(_24683) && DBL_PTR(_24683)->dbl == 0.0){
                DeRef(_24683);
                _24683 = NOVALUE;
                goto L7; // [155] 243
            }
            DeRef(_24683);
            _24683 = NOVALUE;
        }
        DeRef(_24683);
        _24683 = NOVALUE;

        /** symtab.e:562								SymTab[p][attribute] += 1*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_47725 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _24686 = (object)*(((s1_ptr)_2)->base + _attribute_47722);
        _24684 = NOVALUE;
        if (IS_ATOM_INT(_24686)) {
            _24687 = _24686 + 1;
            if (_24687 > MAXINT){
                _24687 = NewDouble((eudouble)_24687);
            }
        }
        else
        _24687 = binary_op(PLUS, 1, _24686);
        _24686 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _attribute_47722);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24687;
        if( _1 != _24687 ){
            DeRef(_1);
        }
        _24687 = NOVALUE;
        _24684 = NOVALUE;

        /** symtab.e:564							break*/
        goto L7; // [182] 243

        /** symtab.e:565						case SC_EXPORT then*/
        case 11:

        /** symtab.e:566							if not and_bits( DIRECT_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _24688 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
        _2 = (object)SEQ_PTR(_24688);
        _24689 = (object)*(((s1_ptr)_2)->base + _sym_file_47732);
        _24688 = NOVALUE;
        if (IS_ATOM_INT(_24689)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2 & (uintptr_t)_24689;
                 _24690 = MAKE_UINT(tu);
            }
        }
        else {
            _24690 = binary_op(AND_BITS, 2, _24689);
        }
        _24689 = NOVALUE;
        if (IS_ATOM_INT(_24690)) {
            if (_24690 != 0){
                DeRef(_24690);
                _24690 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        else {
            if (DBL_PTR(_24690)->dbl != 0.0){
                DeRef(_24690);
                _24690 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        DeRef(_24690);
        _24690 = NOVALUE;

        /** symtab.e:567								break*/
        goto L9; // [213] 217
L8: 
L9: 

        /** symtab.e:570						case SC_GLOBAL then*/
        case 6:

        /** symtab.e:571							SymTab[p][attribute] += 1*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_47725 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _24694 = (object)*(((s1_ptr)_2)->base + _attribute_47722);
        _24692 = NOVALUE;
        if (IS_ATOM_INT(_24694)) {
            _24695 = _24694 + 1;
            if (_24695 > MAXINT){
                _24695 = NewDouble((eudouble)_24695);
            }
        }
        else
        _24695 = binary_op(PLUS, 1, _24694);
        _24694 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _attribute_47722);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24695;
        if( _1 != _24695 ){
            DeRef(_1);
        }
        _24695 = NOVALUE;
        _24692 = NOVALUE;
    ;}L7: 
L6: 

    /** symtab.e:575				p = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24696 = (object)*(((s1_ptr)_2)->base + _p_47725);
    _2 = (object)SEQ_PTR(_24696);
    _p_47725 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_47725)){
        _p_47725 = (object)DBL_PTR(_p_47725)->dbl;
    }
    _24696 = NOVALUE;

    /** symtab.e:576			end while*/
    goto L2; // [266] 33
L3: 
L1: 

    /** symtab.e:578	end procedure*/
    DeRef(_24670);
    _24670 = NOVALUE;
    return;
    ;
}


void _53mark_rechecks(object _file_no_47798)
{
    object _recheck_targets_47801 = NOVALUE;
    object _remaining_47805 = NOVALUE;
    object _marked_47809 = NOVALUE;
    object _24703 = NOVALUE;
    object _24701 = NOVALUE;
    object _24700 = NOVALUE;
    object _24699 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_file_no_47798)) {
        _1 = (object)(DBL_PTR(_file_no_47798)->dbl);
        DeRefDS(_file_no_47798);
        _file_no_47798 = _1;
    }

    /** symtab.e:584		sequence recheck_targets = map:get( recheck_routines, file_no, {} )*/
    Ref(_53recheck_routines_47792);
    RefDS(_22015);
    _0 = _recheck_targets_47801;
    _recheck_targets_47801 = _34get(_53recheck_routines_47792, _file_no_47798, _22015);
    DeRef(_0);

    /** symtab.e:585		if length( recheck_targets ) then*/
    if (IS_SEQUENCE(_recheck_targets_47801)){
            _24699 = SEQ_PTR(_recheck_targets_47801)->length;
    }
    else {
        _24699 = 1;
    }
    if (_24699 == 0)
    {
        _24699 = NOVALUE;
        goto L1; // [20] 129
    }
    else{
        _24699 = NOVALUE;
    }

    /** symtab.e:586			sequence remaining = {}*/
    RefDS(_22015);
    DeRefi(_remaining_47805);
    _remaining_47805 = _22015;

    /** symtab.e:587			for i = length( recheck_targets ) to 1 by -1 do*/
    if (IS_SEQUENCE(_recheck_targets_47801)){
            _24700 = SEQ_PTR(_recheck_targets_47801)->length;
    }
    else {
        _24700 = 1;
    }
    {
        object _i_47807;
        _i_47807 = _24700;
L2: 
        if (_i_47807 < 1){
            goto L3; // [35] 117
        }

        /** symtab.e:588				integer marked = 0*/
        _marked_47809 = 0;

        /** symtab.e:589				if TRANSLATE then*/
        if (_12TRANSLATE_19834 == 0)
        {
            goto L4; // [51] 72
        }
        else{
        }

        /** symtab.e:590					marked = MarkTargets( recheck_targets[i], S_RI_TARGET )*/
        _2 = (object)SEQ_PTR(_recheck_targets_47801);
        _24701 = (object)*(((s1_ptr)_2)->base + _i_47807);
        Ref(_24701);
        _marked_47809 = _53MarkTargets(_24701, 53);
        _24701 = NOVALUE;
        if (!IS_ATOM_INT(_marked_47809)) {
            _1 = (object)(DBL_PTR(_marked_47809)->dbl);
            DeRefDS(_marked_47809);
            _marked_47809 = _1;
        }
        goto L5; // [69] 96
L4: 

        /** symtab.e:591				elsif BIND then*/
        if (_12BIND_19837 == 0)
        {
            goto L6; // [76] 95
        }
        else{
        }

        /** symtab.e:592					marked = MarkTargets( recheck_targets[i], S_NREFS )*/
        _2 = (object)SEQ_PTR(_recheck_targets_47801);
        _24703 = (object)*(((s1_ptr)_2)->base + _i_47807);
        Ref(_24703);
        _marked_47809 = _53MarkTargets(_24703, 12);
        _24703 = NOVALUE;
        if (!IS_ATOM_INT(_marked_47809)) {
            _1 = (object)(DBL_PTR(_marked_47809)->dbl);
            DeRefDS(_marked_47809);
            _marked_47809 = _1;
        }
L6: 
L5: 

        /** symtab.e:594				if not marked then*/
        if (_marked_47809 != 0)
        goto L7; // [98] 108

        /** symtab.e:595					remaining &= file_no*/
        Append(&_remaining_47805, _remaining_47805, _file_no_47798);
L7: 

        /** symtab.e:597			end for*/
        _i_47807 = _i_47807 + -1;
        goto L2; // [112] 42
L3: 
        ;
    }

    /** symtab.e:598			map:put( recheck_routines, file_no, recheck_targets )*/
    Ref(_53recheck_routines_47792);
    RefDS(_recheck_targets_47801);
    _34put(_53recheck_routines_47792, _file_no_47798, _recheck_targets_47801, 1, 0);
L1: 
    DeRefi(_remaining_47805);
    _remaining_47805 = NOVALUE;

    /** symtab.e:600	end procedure*/
    DeRef(_recheck_targets_47801);
    return;
    ;
}


void _53mark_final_targets()
{
    object _size_1__tmp_at47_47837 = NOVALUE;
    object _size_inlined_size_at_47_47836 = NOVALUE;
    object _recheck_files_47838 = NOVALUE;
    object _24709 = NOVALUE;
    object _24708 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:603		if just_mark_everything_from then*/
    if (_53just_mark_everything_from_47719 == 0)
    {
        goto L1; // [5] 44
    }
    else{
    }

    /** symtab.e:604			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L2; // [12] 25
    }
    else{
    }

    /** symtab.e:605				mark_all( S_RI_TARGET )*/
    _53mark_all(53);
    goto L3; // [22] 109
L2: 

    /** symtab.e:606			elsif BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto L3; // [29] 109
    }
    else{
    }

    /** symtab.e:607				mark_all( S_NREFS )*/
    _53mark_all(12);
    goto L3; // [41] 109
L1: 

    /** symtab.e:609		elsif map:size( recheck_routines ) then*/

    /** map.e:800		return eumem:ram_space[the_map_p][MAP_SIZE]*/
    DeRef(_size_1__tmp_at47_47837);
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_53recheck_routines_47792)){
        _size_1__tmp_at47_47837 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_53recheck_routines_47792)->dbl));
    }
    else{
        _size_1__tmp_at47_47837 = (object)*(((s1_ptr)_2)->base + _53recheck_routines_47792);
    }
    Ref(_size_1__tmp_at47_47837);
    DeRef(_size_inlined_size_at_47_47836);
    _2 = (object)SEQ_PTR(_size_1__tmp_at47_47837);
    _size_inlined_size_at_47_47836 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_size_inlined_size_at_47_47836);
    DeRef(_size_1__tmp_at47_47837);
    _size_1__tmp_at47_47837 = NOVALUE;
    if (_size_inlined_size_at_47_47836 == 0) {
        goto L4; // [63] 106
    }
    else {
        if (!IS_ATOM_INT(_size_inlined_size_at_47_47836) && DBL_PTR(_size_inlined_size_at_47_47836)->dbl == 0.0){
            goto L4; // [63] 106
        }
    }

    /** symtab.e:610			sequence recheck_files = map:keys( recheck_routines )*/
    Ref(_53recheck_routines_47792);
    _0 = _recheck_files_47838;
    _recheck_files_47838 = _34keys(_53recheck_routines_47792, 0);
    DeRef(_0);

    /** symtab.e:611			for i = 1 to length( recheck_files ) do*/
    if (IS_SEQUENCE(_recheck_files_47838)){
            _24708 = SEQ_PTR(_recheck_files_47838)->length;
    }
    else {
        _24708 = 1;
    }
    {
        object _i_47841;
        _i_47841 = 1;
L5: 
        if (_i_47841 > _24708){
            goto L6; // [82] 105
        }

        /** symtab.e:612				mark_rechecks( recheck_files[i] )*/
        _2 = (object)SEQ_PTR(_recheck_files_47838);
        _24709 = (object)*(((s1_ptr)_2)->base + _i_47841);
        Ref(_24709);
        _53mark_rechecks(_24709);
        _24709 = NOVALUE;

        /** symtab.e:613			end for*/
        _i_47841 = _i_47841 + 1;
        goto L5; // [100] 89
L6: 
        ;
    }
L4: 
    DeRef(_recheck_files_47838);
    _recheck_files_47838 = NOVALUE;
L3: 

    /** symtab.e:615	end procedure*/
    return;
    ;
}


object _53is_routine(object _sym_47847)
{
    object _tok_47848 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:618		integer tok = sym_token( sym )*/
    _tok_47848 = _53sym_token(_sym_47847);
    if (!IS_ATOM_INT(_tok_47848)) {
        _1 = (object)(DBL_PTR(_tok_47848)->dbl);
        DeRefDS(_tok_47848);
        _tok_47848 = _1;
    }

    /** symtab.e:619		switch tok do*/
    _0 = _tok_47848;
    switch ( _0 ){ 

        /** symtab.e:620			case FUNC, PROC, TYPE then*/
        case 501:
        case 27:
        case 504:

        /** symtab.e:621				return 1*/
        return 1;
        goto L1; // [32] 45

        /** symtab.e:622			case else*/
        default:

        /** symtab.e:623				return 0*/
        return 0;
    ;}L1: 
    ;
}


object _53is_visible(object _sym_47861, object _from_file_47862)
{
    object _scope_47863 = NOVALUE;
    object _sym_file_47866 = NOVALUE;
    object _visible_mask_47871 = NOVALUE;
    object _24721 = NOVALUE;
    object _24720 = NOVALUE;
    object _24719 = NOVALUE;
    object _24718 = NOVALUE;
    object _24714 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:628		integer scope = sym_scope( sym )*/
    _scope_47863 = _53sym_scope(_sym_47861);
    if (!IS_ATOM_INT(_scope_47863)) {
        _1 = (object)(DBL_PTR(_scope_47863)->dbl);
        DeRefDS(_scope_47863);
        _scope_47863 = _1;
    }

    /** symtab.e:629		integer sym_file = SymTab[sym][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24714 = (object)*(((s1_ptr)_2)->base + _sym_47861);
    _2 = (object)SEQ_PTR(_24714);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _sym_file_47866 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _sym_file_47866 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    if (!IS_ATOM_INT(_sym_file_47866)){
        _sym_file_47866 = (object)DBL_PTR(_sym_file_47866)->dbl;
    }
    _24714 = NOVALUE;

    /** symtab.e:631		switch scope do*/
    _0 = _scope_47863;
    switch ( _0 ){ 

        /** symtab.e:632			case SC_PUBLIC then*/
        case 13:

        /** symtab.e:633				visible_mask = DIRECT_OR_PUBLIC_INCLUDE*/
        _visible_mask_47871 = 6;
        goto L1; // [49] 93

        /** symtab.e:634			case SC_EXPORT then*/
        case 11:

        /** symtab.e:635				visible_mask = DIRECT_INCLUDE*/
        _visible_mask_47871 = 2;
        goto L1; // [64] 93

        /** symtab.e:636			case SC_GLOBAL then*/
        case 6:

        /** symtab.e:637				return 1*/
        return 1;
        goto L1; // [76] 93

        /** symtab.e:638			case else*/
        default:

        /** symtab.e:639				return from_file = sym_file*/
        _24718 = (_from_file_47862 == _sym_file_47866);
        return _24718;
    ;}L1: 

    /** symtab.e:641		return and_bits( visible_mask, include_matrix[from_file][sym_file] )*/
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _24719 = (object)*(((s1_ptr)_2)->base + _from_file_47862);
    _2 = (object)SEQ_PTR(_24719);
    _24720 = (object)*(((s1_ptr)_2)->base + _sym_file_47866);
    _24719 = NOVALUE;
    if (IS_ATOM_INT(_24720)) {
        {uintptr_t tu;
             tu = (uintptr_t)_visible_mask_47871 & (uintptr_t)_24720;
             _24721 = MAKE_UINT(tu);
        }
    }
    else {
        _24721 = binary_op(AND_BITS, _visible_mask_47871, _24720);
    }
    _24720 = NOVALUE;
    DeRef(_24718);
    _24718 = NOVALUE;
    return _24721;
    ;
}


object _53MarkTargets(object _s_47891, object _attribute_47892)
{
    object _p_47894 = NOVALUE;
    object _sname_47895 = NOVALUE;
    object _string_47896 = NOVALUE;
    object _colon_47897 = NOVALUE;
    object _h_47898 = NOVALUE;
    object _scope_47899 = NOVALUE;
    object _found_47920 = NOVALUE;
    object _24769 = NOVALUE;
    object _24767 = NOVALUE;
    object _24766 = NOVALUE;
    object _24765 = NOVALUE;
    object _24764 = NOVALUE;
    object _24762 = NOVALUE;
    object _24761 = NOVALUE;
    object _24760 = NOVALUE;
    object _24759 = NOVALUE;
    object _24758 = NOVALUE;
    object _24756 = NOVALUE;
    object _24755 = NOVALUE;
    object _24754 = NOVALUE;
    object _24752 = NOVALUE;
    object _24750 = NOVALUE;
    object _24748 = NOVALUE;
    object _24747 = NOVALUE;
    object _24746 = NOVALUE;
    object _24745 = NOVALUE;
    object _24743 = NOVALUE;
    object _24742 = NOVALUE;
    object _24741 = NOVALUE;
    object _24740 = NOVALUE;
    object _24738 = NOVALUE;
    object _24737 = NOVALUE;
    object _24733 = NOVALUE;
    object _24732 = NOVALUE;
    object _24731 = NOVALUE;
    object _24730 = NOVALUE;
    object _24729 = NOVALUE;
    object _24728 = NOVALUE;
    object _24727 = NOVALUE;
    object _24726 = NOVALUE;
    object _24725 = NOVALUE;
    object _24724 = NOVALUE;
    object _24723 = NOVALUE;
    object _24722 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_47891)) {
        _1 = (object)(DBL_PTR(_s_47891)->dbl);
        DeRefDS(_s_47891);
        _s_47891 = _1;
    }

    /** symtab.e:648		sequence sname*/

    /** symtab.e:649		sequence string*/

    /** symtab.e:650		integer colon, h*/

    /** symtab.e:651		integer scope*/

    /** symtab.e:653		if (SymTab[s][S_MODE] = M_TEMP or*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24722 = (object)*(((s1_ptr)_2)->base + _s_47891);
    _2 = (object)SEQ_PTR(_24722);
    _24723 = (object)*(((s1_ptr)_2)->base + 3);
    _24722 = NOVALUE;
    if (IS_ATOM_INT(_24723)) {
        _24724 = (_24723 == 3);
    }
    else {
        _24724 = binary_op(EQUALS, _24723, 3);
    }
    _24723 = NOVALUE;
    if (IS_ATOM_INT(_24724)) {
        if (_24724 != 0) {
            _24725 = 1;
            goto L1; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_24724)->dbl != 0.0) {
            _24725 = 1;
            goto L1; // [33] 59
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24726 = (object)*(((s1_ptr)_2)->base + _s_47891);
    _2 = (object)SEQ_PTR(_24726);
    _24727 = (object)*(((s1_ptr)_2)->base + 3);
    _24726 = NOVALUE;
    if (IS_ATOM_INT(_24727)) {
        _24728 = (_24727 == 2);
    }
    else {
        _24728 = binary_op(EQUALS, _24727, 2);
    }
    _24727 = NOVALUE;
    DeRef(_24725);
    if (IS_ATOM_INT(_24728))
    _24725 = (_24728 != 0);
    else
    _24725 = DBL_PTR(_24728)->dbl != 0.0;
L1: 
    if (_24725 == 0) {
        goto L2; // [59] 411
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24730 = (object)*(((s1_ptr)_2)->base + _s_47891);
    _2 = (object)SEQ_PTR(_24730);
    _24731 = (object)*(((s1_ptr)_2)->base + 1);
    _24730 = NOVALUE;
    _24732 = IS_SEQUENCE(_24731);
    _24731 = NOVALUE;
    if (_24732 == 0)
    {
        _24732 = NOVALUE;
        goto L2; // [79] 411
    }
    else{
        _24732 = NOVALUE;
    }

    /** symtab.e:658			integer found = 0*/
    _found_47920 = 0;

    /** symtab.e:660			string = SymTab[s][S_OBJ]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24733 = (object)*(((s1_ptr)_2)->base + _s_47891);
    DeRef(_string_47896);
    _2 = (object)SEQ_PTR(_24733);
    _string_47896 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_string_47896);
    _24733 = NOVALUE;

    /** symtab.e:661			colon = find(':', string)*/
    _colon_47897 = find_from(58, _string_47896, 1);

    /** symtab.e:662			if colon = 0 then*/
    if (_colon_47897 != 0)
    goto L3; // [112] 126

    /** symtab.e:663				sname = string*/
    RefDS(_string_47896);
    DeRef(_sname_47895);
    _sname_47895 = _string_47896;
    goto L4; // [123] 200
L3: 

    /** symtab.e:665				sname = string[colon+1..$]  -- ignore namespace part*/
    _24737 = _colon_47897 + 1;
    if (_24737 > MAXINT){
        _24737 = NewDouble((eudouble)_24737);
    }
    if (IS_SEQUENCE(_string_47896)){
            _24738 = SEQ_PTR(_string_47896)->length;
    }
    else {
        _24738 = 1;
    }
    rhs_slice_target = (object_ptr)&_sname_47895;
    RHS_Slice(_string_47896, _24737, _24738);

    /** symtab.e:666				while length(sname) and sname[1] = ' ' or sname[1] = '\t' do*/
L5: 
    if (IS_SEQUENCE(_sname_47895)){
            _24740 = SEQ_PTR(_sname_47895)->length;
    }
    else {
        _24740 = 1;
    }
    if (_24740 == 0) {
        _24741 = 0;
        goto L6; // [148] 164
    }
    _2 = (object)SEQ_PTR(_sname_47895);
    _24742 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24742)) {
        _24743 = (_24742 == 32);
    }
    else {
        _24743 = binary_op(EQUALS, _24742, 32);
    }
    _24742 = NOVALUE;
    if (IS_ATOM_INT(_24743))
    _24741 = (_24743 != 0);
    else
    _24741 = DBL_PTR(_24743)->dbl != 0.0;
L6: 
    if (_24741 != 0) {
        goto L7; // [164] 181
    }
    _2 = (object)SEQ_PTR(_sname_47895);
    _24745 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24745)) {
        _24746 = (_24745 == 9);
    }
    else {
        _24746 = binary_op(EQUALS, _24745, 9);
    }
    _24745 = NOVALUE;
    if (_24746 <= 0) {
        if (_24746 == 0) {
            DeRef(_24746);
            _24746 = NOVALUE;
            goto L8; // [177] 199
        }
        else {
            if (!IS_ATOM_INT(_24746) && DBL_PTR(_24746)->dbl == 0.0){
                DeRef(_24746);
                _24746 = NOVALUE;
                goto L8; // [177] 199
            }
            DeRef(_24746);
            _24746 = NOVALUE;
        }
    }
    DeRef(_24746);
    _24746 = NOVALUE;
L7: 

    /** symtab.e:667					sname = tail( sname, length( sname ) -1 )*/
    if (IS_SEQUENCE(_sname_47895)){
            _24747 = SEQ_PTR(_sname_47895)->length;
    }
    else {
        _24747 = 1;
    }
    _24748 = _24747 - 1;
    _24747 = NOVALUE;
    {
        int len = SEQ_PTR(_sname_47895)->length;
        int size = (IS_ATOM_INT(_24748)) ? _24748 : (object)(DBL_PTR(_24748)->dbl);
        if (size <= 0) {
            DeRef(_sname_47895);
            _sname_47895 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_sname_47895);
            DeRef(_sname_47895);
            _sname_47895 = _sname_47895;
        }
        else Tail(SEQ_PTR(_sname_47895), len-size+1, &_sname_47895);
    }
    _24748 = NOVALUE;

    /** symtab.e:668				end while*/
    goto L5; // [196] 145
L8: 
L4: 

    /** symtab.e:671			if length(sname) = 0 then*/
    if (IS_SEQUENCE(_sname_47895)){
            _24750 = SEQ_PTR(_sname_47895)->length;
    }
    else {
        _24750 = 1;
    }
    if (_24750 != 0)
    goto L9; // [207] 218

    /** symtab.e:672				return 1*/
    DeRefDS(_sname_47895);
    DeRef(_string_47896);
    DeRef(_24737);
    _24737 = NOVALUE;
    DeRef(_24724);
    _24724 = NOVALUE;
    DeRef(_24728);
    _24728 = NOVALUE;
    DeRef(_24743);
    _24743 = NOVALUE;
    return 1;
L9: 

    /** symtab.e:674			h = buckets[hashfn(sname)]*/
    RefDS(_sname_47895);
    _24752 = _53hashfn(_sname_47895);
    _2 = (object)SEQ_PTR(_53buckets_46799);
    if (!IS_ATOM_INT(_24752)){
        _h_47898 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24752)->dbl));
    }
    else{
        _h_47898 = (object)*(((s1_ptr)_2)->base + _24752);
    }
    if (!IS_ATOM_INT(_h_47898))
    _h_47898 = (object)DBL_PTR(_h_47898)->dbl;

    /** symtab.e:675			while h do*/
LA: 
    if (_h_47898 == 0)
    {
        goto LB; // [235] 381
    }
    else{
    }

    /** symtab.e:676				if equal(sname, SymTab[h][S_NAME]) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24754 = (object)*(((s1_ptr)_2)->base + _h_47898);
    _2 = (object)SEQ_PTR(_24754);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _24755 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _24755 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _24754 = NOVALUE;
    if (_sname_47895 == _24755)
    _24756 = 1;
    else if (IS_ATOM_INT(_sname_47895) && IS_ATOM_INT(_24755))
    _24756 = 0;
    else
    _24756 = (compare(_sname_47895, _24755) == 0);
    _24755 = NOVALUE;
    if (_24756 == 0)
    {
        _24756 = NOVALUE;
        goto LC; // [256] 360
    }
    else{
        _24756 = NOVALUE;
    }

    /** symtab.e:677					if attribute = S_NREFS then*/
    if (_attribute_47892 != 12)
    goto LD; // [263] 289

    /** symtab.e:678						if BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto LE; // [271] 359
    }
    else{
    }

    /** symtab.e:679							add_ref({PROC, h})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 27;
    ((intptr_t *)_2)[2] = _h_47898;
    _24758 = MAKE_SEQ(_1);
    _53add_ref(_24758);
    _24758 = NOVALUE;
    goto LE; // [286] 359
LD: 

    /** symtab.e:681					elsif is_routine( h ) and is_visible( h, current_file_no ) then*/
    _24759 = _53is_routine(_h_47898);
    if (IS_ATOM_INT(_24759)) {
        if (_24759 == 0) {
            goto LF; // [295] 358
        }
    }
    else {
        if (DBL_PTR(_24759)->dbl == 0.0) {
            goto LF; // [295] 358
        }
    }
    _24761 = _53is_visible(_h_47898, _12current_file_no_20226);
    if (_24761 == 0) {
        DeRef(_24761);
        _24761 = NOVALUE;
        goto LF; // [307] 358
    }
    else {
        if (!IS_ATOM_INT(_24761) && DBL_PTR(_24761)->dbl == 0.0){
            DeRef(_24761);
            _24761 = NOVALUE;
            goto LF; // [307] 358
        }
        DeRef(_24761);
        _24761 = NOVALUE;
    }
    DeRef(_24761);
    _24761 = NOVALUE;

    /** symtab.e:682						SymTab[h][attribute] += 1*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_h_47898 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24764 = (object)*(((s1_ptr)_2)->base + _attribute_47892);
    _24762 = NOVALUE;
    if (IS_ATOM_INT(_24764)) {
        _24765 = _24764 + 1;
        if (_24765 > MAXINT){
            _24765 = NewDouble((eudouble)_24765);
        }
    }
    else
    _24765 = binary_op(PLUS, 1, _24764);
    _24764 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _attribute_47892);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24765;
    if( _1 != _24765 ){
        DeRef(_1);
    }
    _24765 = NOVALUE;
    _24762 = NOVALUE;

    /** symtab.e:683						if current_file_no = SymTab[h][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24766 = (object)*(((s1_ptr)_2)->base + _h_47898);
    _2 = (object)SEQ_PTR(_24766);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _24767 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _24767 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _24766 = NOVALUE;
    if (binary_op_a(NOTEQ, _12current_file_no_20226, _24767)){
        _24767 = NOVALUE;
        goto L10; // [347] 357
    }
    _24767 = NOVALUE;

    /** symtab.e:684							found = 1*/
    _found_47920 = 1;
L10: 
LF: 
LE: 
LC: 

    /** symtab.e:688				h = SymTab[h][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24769 = (object)*(((s1_ptr)_2)->base + _h_47898);
    _2 = (object)SEQ_PTR(_24769);
    _h_47898 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_h_47898)){
        _h_47898 = (object)DBL_PTR(_h_47898)->dbl;
    }
    _24769 = NOVALUE;

    /** symtab.e:689			end while*/
    goto LA; // [378] 235
LB: 

    /** symtab.e:691			if not found then*/
    if (_found_47920 != 0)
    goto L11; // [383] 400

    /** symtab.e:692				map:put( recheck_routines, current_file_no, s, map:APPEND )*/
    Ref(_53recheck_routines_47792);
    _34put(_53recheck_routines_47792, _12current_file_no_20226, _s_47891, 6, 0);
L11: 

    /** symtab.e:694			return found*/
    DeRef(_sname_47895);
    DeRef(_string_47896);
    DeRef(_24737);
    _24737 = NOVALUE;
    DeRef(_24724);
    _24724 = NOVALUE;
    DeRef(_24759);
    _24759 = NOVALUE;
    DeRef(_24752);
    _24752 = NOVALUE;
    DeRef(_24728);
    _24728 = NOVALUE;
    DeRef(_24743);
    _24743 = NOVALUE;
    return _found_47920;
    goto L12; // [408] 440
L2: 

    /** symtab.e:696			if not just_mark_everything_from then*/
    if (_53just_mark_everything_from_47719 != 0)
    goto L13; // [415] 428

    /** symtab.e:697				just_mark_everything_from = TopLevelSub*/
    _53just_mark_everything_from_47719 = _12TopLevelSub_20233;
L13: 

    /** symtab.e:699			mark_all( attribute )*/
    _53mark_all(_attribute_47892);

    /** symtab.e:700			return 1*/
    DeRef(_sname_47895);
    DeRef(_string_47896);
    DeRef(_24737);
    _24737 = NOVALUE;
    DeRef(_24724);
    _24724 = NOVALUE;
    DeRef(_24759);
    _24759 = NOVALUE;
    DeRef(_24752);
    _24752 = NOVALUE;
    DeRef(_24728);
    _24728 = NOVALUE;
    DeRef(_24743);
    _24743 = NOVALUE;
    return 1;
L12: 
    ;
}


void _53resolve_unincluded_globals(object _ok_47998)
{
    object _0, _1, _2;
    

    /** symtab.e:724		Resolve_unincluded_globals = ok*/
    _53Resolve_unincluded_globals_47995 = 1;

    /** symtab.e:725	end procedure*/
    return;
    ;
}


object _53get_resolve_unincluded_globals()
{
    object _0, _1, _2;
    

    /** symtab.e:728		return Resolve_unincluded_globals*/
    return _53Resolve_unincluded_globals_47995;
    ;
}


object _53keyfind(object _word_48004, object _file_no_48005, object _scanning_file_48006, object _namespace_ok_48009, object _hashval_48010)
{
    object _msg_48012 = NOVALUE;
    object _b_name_48013 = NOVALUE;
    object _scope_48014 = NOVALUE;
    object _defined_48015 = NOVALUE;
    object _ix_48016 = NOVALUE;
    object _st_ptr_48018 = NOVALUE;
    object _st_builtin_48019 = NOVALUE;
    object _tok_48021 = NOVALUE;
    object _gtok_48022 = NOVALUE;
    object _any_symbol_48025 = NOVALUE;
    object _tok_file_48193 = NOVALUE;
    object _good_48200 = NOVALUE;
    object _include_type_48210 = NOVALUE;
    object _msg_file_48266 = NOVALUE;
    object _24964 = NOVALUE;
    object _24963 = NOVALUE;
    object _24961 = NOVALUE;
    object _24959 = NOVALUE;
    object _24958 = NOVALUE;
    object _24957 = NOVALUE;
    object _24956 = NOVALUE;
    object _24955 = NOVALUE;
    object _24953 = NOVALUE;
    object _24951 = NOVALUE;
    object _24950 = NOVALUE;
    object _24949 = NOVALUE;
    object _24948 = NOVALUE;
    object _24947 = NOVALUE;
    object _24946 = NOVALUE;
    object _24945 = NOVALUE;
    object _24944 = NOVALUE;
    object _24942 = NOVALUE;
    object _24941 = NOVALUE;
    object _24940 = NOVALUE;
    object _24939 = NOVALUE;
    object _24938 = NOVALUE;
    object _24937 = NOVALUE;
    object _24936 = NOVALUE;
    object _24935 = NOVALUE;
    object _24934 = NOVALUE;
    object _24933 = NOVALUE;
    object _24932 = NOVALUE;
    object _24931 = NOVALUE;
    object _24930 = NOVALUE;
    object _24929 = NOVALUE;
    object _24928 = NOVALUE;
    object _24927 = NOVALUE;
    object _24926 = NOVALUE;
    object _24924 = NOVALUE;
    object _24923 = NOVALUE;
    object _24920 = NOVALUE;
    object _24916 = NOVALUE;
    object _24914 = NOVALUE;
    object _24913 = NOVALUE;
    object _24912 = NOVALUE;
    object _24911 = NOVALUE;
    object _24910 = NOVALUE;
    object _24908 = NOVALUE;
    object _24907 = NOVALUE;
    object _24906 = NOVALUE;
    object _24905 = NOVALUE;
    object _24903 = NOVALUE;
    object _24900 = NOVALUE;
    object _24899 = NOVALUE;
    object _24898 = NOVALUE;
    object _24897 = NOVALUE;
    object _24895 = NOVALUE;
    object _24892 = NOVALUE;
    object _24891 = NOVALUE;
    object _24890 = NOVALUE;
    object _24889 = NOVALUE;
    object _24888 = NOVALUE;
    object _24887 = NOVALUE;
    object _24886 = NOVALUE;
    object _24883 = NOVALUE;
    object _24882 = NOVALUE;
    object _24880 = NOVALUE;
    object _24878 = NOVALUE;
    object _24876 = NOVALUE;
    object _24875 = NOVALUE;
    object _24874 = NOVALUE;
    object _24870 = NOVALUE;
    object _24869 = NOVALUE;
    object _24864 = NOVALUE;
    object _24862 = NOVALUE;
    object _24860 = NOVALUE;
    object _24859 = NOVALUE;
    object _24855 = NOVALUE;
    object _24854 = NOVALUE;
    object _24852 = NOVALUE;
    object _24851 = NOVALUE;
    object _24849 = NOVALUE;
    object _24848 = NOVALUE;
    object _24847 = NOVALUE;
    object _24846 = NOVALUE;
    object _24845 = NOVALUE;
    object _24843 = NOVALUE;
    object _24842 = NOVALUE;
    object _24841 = NOVALUE;
    object _24840 = NOVALUE;
    object _24839 = NOVALUE;
    object _24838 = NOVALUE;
    object _24837 = NOVALUE;
    object _24836 = NOVALUE;
    object _24835 = NOVALUE;
    object _24834 = NOVALUE;
    object _24833 = NOVALUE;
    object _24832 = NOVALUE;
    object _24831 = NOVALUE;
    object _24830 = NOVALUE;
    object _24829 = NOVALUE;
    object _24828 = NOVALUE;
    object _24827 = NOVALUE;
    object _24826 = NOVALUE;
    object _24825 = NOVALUE;
    object _24824 = NOVALUE;
    object _24823 = NOVALUE;
    object _24822 = NOVALUE;
    object _24820 = NOVALUE;
    object _24819 = NOVALUE;
    object _24817 = NOVALUE;
    object _24816 = NOVALUE;
    object _24815 = NOVALUE;
    object _24814 = NOVALUE;
    object _24813 = NOVALUE;
    object _24811 = NOVALUE;
    object _24810 = NOVALUE;
    object _24809 = NOVALUE;
    object _24807 = NOVALUE;
    object _24806 = NOVALUE;
    object _24805 = NOVALUE;
    object _24804 = NOVALUE;
    object _24803 = NOVALUE;
    object _24802 = NOVALUE;
    object _24801 = NOVALUE;
    object _24799 = NOVALUE;
    object _24798 = NOVALUE;
    object _24793 = NOVALUE;
    object _24790 = NOVALUE;
    object _24789 = NOVALUE;
    object _24788 = NOVALUE;
    object _24787 = NOVALUE;
    object _24786 = NOVALUE;
    object _24785 = NOVALUE;
    object _24784 = NOVALUE;
    object _24783 = NOVALUE;
    object _24782 = NOVALUE;
    object _24781 = NOVALUE;
    object _24780 = NOVALUE;
    object _24779 = NOVALUE;
    object _24778 = NOVALUE;
    object _24777 = NOVALUE;
    object _24776 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_file_no_48005)) {
        _1 = (object)(DBL_PTR(_file_no_48005)->dbl);
        DeRefDS(_file_no_48005);
        _file_no_48005 = _1;
    }
    if (!IS_ATOM_INT(_hashval_48010)) {
        _1 = (object)(DBL_PTR(_hashval_48010)->dbl);
        DeRefDS(_hashval_48010);
        _hashval_48010 = _1;
    }

    /** symtab.e:750		dup_globals = {}*/
    RefDS(_22015);
    DeRef(_53dup_globals_47990);
    _53dup_globals_47990 = _22015;

    /** symtab.e:751		dup_overrides = {}*/
    RefDS(_22015);
    DeRefi(_53dup_overrides_47991);
    _53dup_overrides_47991 = _22015;

    /** symtab.e:752		in_include_path = {}*/
    RefDS(_22015);
    DeRef(_53in_include_path_47992);
    _53in_include_path_47992 = _22015;

    /** symtab.e:753		symbol_resolution_warning = ""*/
    RefDS(_22015);
    DeRef(_12symbol_resolution_warning_20328);
    _12symbol_resolution_warning_20328 = _22015;

    /** symtab.e:754		st_builtin = 0*/
    _st_builtin_48019 = 0;

    /** symtab.e:756		ifdef EUDIS then*/

    /** symtab.e:759		st_ptr = buckets[hashval]*/
    _2 = (object)SEQ_PTR(_53buckets_46799);
    _st_ptr_48018 = (object)*(((s1_ptr)_2)->base + _hashval_48010);
    if (!IS_ATOM_INT(_st_ptr_48018)){
        _st_ptr_48018 = (object)DBL_PTR(_st_ptr_48018)->dbl;
    }

    /** symtab.e:760		integer any_symbol = namespace_ok = -1*/
    _any_symbol_48025 = (_namespace_ok_48009 == -1);

    /** symtab.e:761		while st_ptr do*/
L1: 
    if (_st_ptr_48018 == 0)
    {
        goto L2; // [69] 1033
    }
    else{
    }

    /** symtab.e:762			if SymTab[st_ptr][S_SCOPE] != SC_UNDEFINED */
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24776 = (object)*(((s1_ptr)_2)->base + _st_ptr_48018);
    _2 = (object)SEQ_PTR(_24776);
    _24777 = (object)*(((s1_ptr)_2)->base + 4);
    _24776 = NOVALUE;
    if (IS_ATOM_INT(_24777)) {
        _24778 = (_24777 != 9);
    }
    else {
        _24778 = binary_op(NOTEQ, _24777, 9);
    }
    _24777 = NOVALUE;
    if (IS_ATOM_INT(_24778)) {
        if (_24778 == 0) {
            DeRef(_24779);
            _24779 = 0;
            goto L3; // [92] 116
        }
    }
    else {
        if (DBL_PTR(_24778)->dbl == 0.0) {
            DeRef(_24779);
            _24779 = 0;
            goto L3; // [92] 116
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24780 = (object)*(((s1_ptr)_2)->base + _st_ptr_48018);
    _2 = (object)SEQ_PTR(_24780);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _24781 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _24781 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _24780 = NOVALUE;
    if (_word_48004 == _24781)
    _24782 = 1;
    else if (IS_ATOM_INT(_word_48004) && IS_ATOM_INT(_24781))
    _24782 = 0;
    else
    _24782 = (compare(_word_48004, _24781) == 0);
    _24781 = NOVALUE;
    DeRef(_24779);
    _24779 = (_24782 != 0);
L3: 
    if (_24779 == 0) {
        goto L4; // [116] 1012
    }
    if (_any_symbol_48025 != 0) {
        DeRef(_24784);
        _24784 = 1;
        goto L5; // [120] 150
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24785 = (object)*(((s1_ptr)_2)->base + _st_ptr_48018);
    _2 = (object)SEQ_PTR(_24785);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _24786 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _24786 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _24785 = NOVALUE;
    if (IS_ATOM_INT(_24786)) {
        _24787 = (_24786 == 523);
    }
    else {
        _24787 = binary_op(EQUALS, _24786, 523);
    }
    _24786 = NOVALUE;
    if (IS_ATOM_INT(_24787)) {
        _24788 = (_namespace_ok_48009 == _24787);
    }
    else {
        _24788 = binary_op(EQUALS, _namespace_ok_48009, _24787);
    }
    DeRef(_24787);
    _24787 = NOVALUE;
    if (IS_ATOM_INT(_24788))
    _24784 = (_24788 != 0);
    else
    _24784 = DBL_PTR(_24788)->dbl != 0.0;
L5: 
    if (_24784 == 0)
    {
        _24784 = NOVALUE;
        goto L4; // [151] 1012
    }
    else{
        _24784 = NOVALUE;
    }

    /** symtab.e:767				tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24789 = (object)*(((s1_ptr)_2)->base + _st_ptr_48018);
    _2 = (object)SEQ_PTR(_24789);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _24790 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _24790 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _24789 = NOVALUE;
    Ref(_24790);
    DeRef(_tok_48021);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24790;
    ((intptr_t *)_2)[2] = _st_ptr_48018;
    _tok_48021 = MAKE_SEQ(_1);
    _24790 = NOVALUE;

    /** symtab.e:769				if file_no = -1 then*/
    if (_file_no_48005 != -1)
    goto L6; // [174] 714

    /** symtab.e:774					scope = SymTab[st_ptr][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24793 = (object)*(((s1_ptr)_2)->base + _st_ptr_48018);
    _2 = (object)SEQ_PTR(_24793);
    _scope_48014 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_48014)){
        _scope_48014 = (object)DBL_PTR(_scope_48014)->dbl;
    }
    _24793 = NOVALUE;

    /** symtab.e:776					switch scope with fallthru do*/
    _0 = _scope_48014;
    switch ( _0 ){ 

        /** symtab.e:777					case SC_OVERRIDE then*/
        case 12:

        /** symtab.e:778						dup_overrides &= st_ptr*/
        Append(&_53dup_overrides_47991, _53dup_overrides_47991, _st_ptr_48018);

        /** symtab.e:779						break*/
        goto L7; // [215] 1011

        /** symtab.e:781					case SC_PREDEF then*/
        case 7:

        /** symtab.e:782						st_builtin = st_ptr*/
        _st_builtin_48019 = _st_ptr_48018;

        /** symtab.e:783						break*/
        goto L7; // [230] 1011

        /** symtab.e:784					case SC_GLOBAL then*/
        case 6:

        /** symtab.e:785						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24798 = (object)*(((s1_ptr)_2)->base + _st_ptr_48018);
        _2 = (object)SEQ_PTR(_24798);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _24799 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _24799 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _24798 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_48006, _24799)){
            _24799 = NOVALUE;
            goto L8; // [250] 274
        }
        _24799 = NOVALUE;

        /** symtab.e:788							if BIND then*/
        if (_12BIND_19837 == 0)
        {
            goto L9; // [258] 267
        }
        else{
        }

        /** symtab.e:789								add_ref(tok)*/
        Ref(_tok_48021);
        _53add_ref(_tok_48021);
L9: 

        /** symtab.e:792							return tok*/
        DeRefDS(_word_48004);
        DeRef(_msg_48012);
        DeRef(_b_name_48013);
        DeRef(_gtok_48022);
        DeRef(_24778);
        _24778 = NOVALUE;
        DeRef(_24788);
        _24788 = NOVALUE;
        return _tok_48021;
L8: 

        /** symtab.e:796						if Resolve_unincluded_globals */
        if (_53Resolve_unincluded_globals_47995 != 0) {
            _24801 = 1;
            goto LA; // [278] 322
        }
        _2 = (object)SEQ_PTR(_13finished_files_11319);
        _24802 = (object)*(((s1_ptr)_2)->base + _scanning_file_48006);
        if (_24802 == 0) {
            _24803 = 0;
            goto LB; // [288] 318
        }
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _24804 = (object)*(((s1_ptr)_2)->base + _scanning_file_48006);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24805 = (object)*(((s1_ptr)_2)->base + _st_ptr_48018);
        _2 = (object)SEQ_PTR(_24805);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _24806 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _24806 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _24805 = NOVALUE;
        _2 = (object)SEQ_PTR(_24804);
        if (!IS_ATOM_INT(_24806)){
            _24807 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24806)->dbl));
        }
        else{
            _24807 = (object)*(((s1_ptr)_2)->base + _24806);
        }
        _24804 = NOVALUE;
        if (IS_ATOM_INT(_24807))
        _24803 = (_24807 != 0);
        else
        _24803 = DBL_PTR(_24807)->dbl != 0.0;
LB: 
        _24801 = (_24803 != 0);
LA: 
        if (_24801 != 0) {
            goto LC; // [322] 349
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24809 = (object)*(((s1_ptr)_2)->base + _st_ptr_48018);
        _2 = (object)SEQ_PTR(_24809);
        if (!IS_ATOM_INT(_12S_TOKEN_19869)){
            _24810 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
        }
        else{
            _24810 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
        }
        _24809 = NOVALUE;
        if (IS_ATOM_INT(_24810)) {
            _24811 = (_24810 == 523);
        }
        else {
            _24811 = binary_op(EQUALS, _24810, 523);
        }
        _24810 = NOVALUE;
        if (_24811 == 0) {
            DeRef(_24811);
            _24811 = NOVALUE;
            goto L7; // [345] 1011
        }
        else {
            if (!IS_ATOM_INT(_24811) && DBL_PTR(_24811)->dbl == 0.0){
                DeRef(_24811);
                _24811 = NOVALUE;
                goto L7; // [345] 1011
            }
            DeRef(_24811);
            _24811 = NOVALUE;
        }
        DeRef(_24811);
        _24811 = NOVALUE;
LC: 

        /** symtab.e:800							gtok = tok*/
        Ref(_tok_48021);
        DeRef(_gtok_48022);
        _gtok_48022 = _tok_48021;

        /** symtab.e:801							dup_globals &= st_ptr*/
        Append(&_53dup_globals_47990, _53dup_globals_47990, _st_ptr_48018);

        /** symtab.e:802							in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0*/
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _24813 = (object)*(((s1_ptr)_2)->base + _scanning_file_48006);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24814 = (object)*(((s1_ptr)_2)->base + _st_ptr_48018);
        _2 = (object)SEQ_PTR(_24814);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _24815 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _24815 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _24814 = NOVALUE;
        _2 = (object)SEQ_PTR(_24813);
        if (!IS_ATOM_INT(_24815)){
            _24816 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24815)->dbl));
        }
        else{
            _24816 = (object)*(((s1_ptr)_2)->base + _24815);
        }
        _24813 = NOVALUE;
        if (IS_ATOM_INT(_24816)) {
            _24817 = (_24816 != 0);
        }
        else {
            _24817 = binary_op(NOTEQ, _24816, 0);
        }
        _24816 = NOVALUE;
        if (IS_SEQUENCE(_53in_include_path_47992) && IS_ATOM(_24817)) {
            Ref(_24817);
            Append(&_53in_include_path_47992, _53in_include_path_47992, _24817);
        }
        else if (IS_ATOM(_53in_include_path_47992) && IS_SEQUENCE(_24817)) {
        }
        else {
            Concat((object_ptr)&_53in_include_path_47992, _53in_include_path_47992, _24817);
        }
        DeRef(_24817);
        _24817 = NOVALUE;

        /** symtab.e:804						break*/
        goto L7; // [399] 1011

        /** symtab.e:807					case SC_PUBLIC, SC_EXPORT then*/
        case 13:
        case 11:

        /** symtab.e:809						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24819 = (object)*(((s1_ptr)_2)->base + _st_ptr_48018);
        _2 = (object)SEQ_PTR(_24819);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _24820 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _24820 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _24819 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_48006, _24820)){
            _24820 = NOVALUE;
            goto LD; // [421] 445
        }
        _24820 = NOVALUE;

        /** symtab.e:811							if BIND then*/
        if (_12BIND_19837 == 0)
        {
            goto LE; // [429] 438
        }
        else{
        }

        /** symtab.e:812								add_ref(tok)*/
        Ref(_tok_48021);
        _53add_ref(_tok_48021);
LE: 

        /** symtab.e:815							return tok*/
        DeRefDS(_word_48004);
        DeRef(_msg_48012);
        DeRef(_b_name_48013);
        DeRef(_gtok_48022);
        _24815 = NOVALUE;
        _24806 = NOVALUE;
        DeRef(_24778);
        _24778 = NOVALUE;
        _24802 = NOVALUE;
        _24807 = NOVALUE;
        DeRef(_24788);
        _24788 = NOVALUE;
        return _tok_48021;
LD: 

        /** symtab.e:818						if (finished_files[scanning_file] -- everything this file needs has been read in*/
        _2 = (object)SEQ_PTR(_13finished_files_11319);
        _24822 = (object)*(((s1_ptr)_2)->base + _scanning_file_48006);
        if (_24822 != 0) {
            _24823 = 1;
            goto LF; // [453] 487
        }
        if (_namespace_ok_48009 == 0) {
            _24824 = 0;
            goto L10; // [457] 483
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24825 = (object)*(((s1_ptr)_2)->base + _st_ptr_48018);
        _2 = (object)SEQ_PTR(_24825);
        if (!IS_ATOM_INT(_12S_TOKEN_19869)){
            _24826 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
        }
        else{
            _24826 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
        }
        _24825 = NOVALUE;
        if (IS_ATOM_INT(_24826)) {
            _24827 = (_24826 == 523);
        }
        else {
            _24827 = binary_op(EQUALS, _24826, 523);
        }
        _24826 = NOVALUE;
        if (IS_ATOM_INT(_24827))
        _24824 = (_24827 != 0);
        else
        _24824 = DBL_PTR(_24827)->dbl != 0.0;
L10: 
        _24823 = (_24824 != 0);
LF: 
        if (_24823 == 0) {
            goto L7; // [487] 1011
        }
        _24829 = (_scope_48014 == 13);
        if (_24829 == 0) {
            _24830 = 0;
            goto L11; // [497] 533
        }
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _24831 = (object)*(((s1_ptr)_2)->base + _scanning_file_48006);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24832 = (object)*(((s1_ptr)_2)->base + _st_ptr_48018);
        _2 = (object)SEQ_PTR(_24832);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _24833 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _24833 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _24832 = NOVALUE;
        _2 = (object)SEQ_PTR(_24831);
        if (!IS_ATOM_INT(_24833)){
            _24834 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24833)->dbl));
        }
        else{
            _24834 = (object)*(((s1_ptr)_2)->base + _24833);
        }
        _24831 = NOVALUE;
        if (IS_ATOM_INT(_24834)) {
            {uintptr_t tu;
                 tu = (uintptr_t)6 & (uintptr_t)_24834;
                 _24835 = MAKE_UINT(tu);
            }
        }
        else {
            _24835 = binary_op(AND_BITS, 6, _24834);
        }
        _24834 = NOVALUE;
        if (IS_ATOM_INT(_24835))
        _24830 = (_24835 != 0);
        else
        _24830 = DBL_PTR(_24835)->dbl != 0.0;
L11: 
        if (_24830 != 0) {
            DeRef(_24836);
            _24836 = 1;
            goto L12; // [533] 583
        }
        _24837 = (_scope_48014 == 11);
        if (_24837 == 0) {
            _24838 = 0;
            goto L13; // [543] 579
        }
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _24839 = (object)*(((s1_ptr)_2)->base + _scanning_file_48006);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24840 = (object)*(((s1_ptr)_2)->base + _st_ptr_48018);
        _2 = (object)SEQ_PTR(_24840);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _24841 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _24841 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _24840 = NOVALUE;
        _2 = (object)SEQ_PTR(_24839);
        if (!IS_ATOM_INT(_24841)){
            _24842 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24841)->dbl));
        }
        else{
            _24842 = (object)*(((s1_ptr)_2)->base + _24841);
        }
        _24839 = NOVALUE;
        if (IS_ATOM_INT(_24842)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2 & (uintptr_t)_24842;
                 _24843 = MAKE_UINT(tu);
            }
        }
        else {
            _24843 = binary_op(AND_BITS, 2, _24842);
        }
        _24842 = NOVALUE;
        if (IS_ATOM_INT(_24843))
        _24838 = (_24843 != 0);
        else
        _24838 = DBL_PTR(_24843)->dbl != 0.0;
L13: 
        DeRef(_24836);
        _24836 = (_24838 != 0);
L12: 
        if (_24836 == 0)
        {
            _24836 = NOVALUE;
            goto L7; // [584] 1011
        }
        else{
            _24836 = NOVALUE;
        }

        /** symtab.e:826							gtok = tok*/
        Ref(_tok_48021);
        DeRef(_gtok_48022);
        _gtok_48022 = _tok_48021;

        /** symtab.e:827							dup_globals &= st_ptr*/
        Append(&_53dup_globals_47990, _53dup_globals_47990, _st_ptr_48018);

        /** symtab.e:828							in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0 --symbol_in_include_path( st_ptr, scanning_file, {} )*/
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _24845 = (object)*(((s1_ptr)_2)->base + _scanning_file_48006);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24846 = (object)*(((s1_ptr)_2)->base + _st_ptr_48018);
        _2 = (object)SEQ_PTR(_24846);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _24847 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _24847 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _24846 = NOVALUE;
        _2 = (object)SEQ_PTR(_24845);
        if (!IS_ATOM_INT(_24847)){
            _24848 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24847)->dbl));
        }
        else{
            _24848 = (object)*(((s1_ptr)_2)->base + _24847);
        }
        _24845 = NOVALUE;
        if (IS_ATOM_INT(_24848)) {
            _24849 = (_24848 != 0);
        }
        else {
            _24849 = binary_op(NOTEQ, _24848, 0);
        }
        _24848 = NOVALUE;
        if (IS_SEQUENCE(_53in_include_path_47992) && IS_ATOM(_24849)) {
            Ref(_24849);
            Append(&_53in_include_path_47992, _53in_include_path_47992, _24849);
        }
        else if (IS_ATOM(_53in_include_path_47992) && IS_SEQUENCE(_24849)) {
        }
        else {
            Concat((object_ptr)&_53in_include_path_47992, _53in_include_path_47992, _24849);
        }
        DeRef(_24849);
        _24849 = NOVALUE;

        /** symtab.e:831	ifdef STDDEBUG then*/

        /** symtab.e:852						break*/
        goto L7; // [639] 1011

        /** symtab.e:853					case SC_LOCAL then*/
        case 5:

        /** symtab.e:854						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24851 = (object)*(((s1_ptr)_2)->base + _st_ptr_48018);
        _2 = (object)SEQ_PTR(_24851);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _24852 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _24852 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _24851 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_48006, _24852)){
            _24852 = NOVALUE;
            goto L7; // [659] 1011
        }
        _24852 = NOVALUE;

        /** symtab.e:857							if BIND then*/
        if (_12BIND_19837 == 0)
        {
            goto L14; // [667] 676
        }
        else{
        }

        /** symtab.e:858								add_ref(tok)*/
        Ref(_tok_48021);
        _53add_ref(_tok_48021);
L14: 

        /** symtab.e:861							return tok*/
        DeRefDS(_word_48004);
        DeRef(_msg_48012);
        DeRef(_b_name_48013);
        DeRef(_gtok_48022);
        _24815 = NOVALUE;
        _24806 = NOVALUE;
        _24833 = NOVALUE;
        _24822 = NOVALUE;
        DeRef(_24778);
        _24778 = NOVALUE;
        DeRef(_24829);
        _24829 = NOVALUE;
        _24802 = NOVALUE;
        DeRef(_24843);
        _24843 = NOVALUE;
        DeRef(_24827);
        _24827 = NOVALUE;
        DeRef(_24835);
        _24835 = NOVALUE;
        DeRef(_24837);
        _24837 = NOVALUE;
        _24807 = NOVALUE;
        DeRef(_24788);
        _24788 = NOVALUE;
        _24841 = NOVALUE;
        _24847 = NOVALUE;
        return _tok_48021;

        /** symtab.e:863						break*/
        goto L7; // [685] 1011

        /** symtab.e:864					case else*/
        default:

        /** symtab.e:866						if BIND then*/
        if (_12BIND_19837 == 0)
        {
            goto L15; // [695] 704
        }
        else{
        }

        /** symtab.e:867							add_ref(tok)*/
        Ref(_tok_48021);
        _53add_ref(_tok_48021);
L15: 

        /** symtab.e:870						return tok -- keyword, private*/
        DeRefDS(_word_48004);
        DeRef(_msg_48012);
        DeRef(_b_name_48013);
        DeRef(_gtok_48022);
        _24815 = NOVALUE;
        _24806 = NOVALUE;
        _24833 = NOVALUE;
        _24822 = NOVALUE;
        DeRef(_24778);
        _24778 = NOVALUE;
        DeRef(_24829);
        _24829 = NOVALUE;
        _24802 = NOVALUE;
        DeRef(_24843);
        _24843 = NOVALUE;
        DeRef(_24827);
        _24827 = NOVALUE;
        DeRef(_24835);
        _24835 = NOVALUE;
        DeRef(_24837);
        _24837 = NOVALUE;
        _24807 = NOVALUE;
        DeRef(_24788);
        _24788 = NOVALUE;
        _24841 = NOVALUE;
        _24847 = NOVALUE;
        return _tok_48021;
    ;}    goto L7; // [711] 1011
L6: 

    /** symtab.e:877					scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_tok_48021);
    _24854 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_24854)){
        _24855 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24854)->dbl));
    }
    else{
        _24855 = (object)*(((s1_ptr)_2)->base + _24854);
    }
    _2 = (object)SEQ_PTR(_24855);
    _scope_48014 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_48014)){
        _scope_48014 = (object)DBL_PTR(_scope_48014)->dbl;
    }
    _24855 = NOVALUE;

    /** symtab.e:878					if not file_no then*/
    if (_file_no_48005 != 0)
    goto L16; // [738] 772

    /** symtab.e:880						if scope = SC_PREDEF then*/
    if (_scope_48014 != 7)
    goto L17; // [745] 1010

    /** symtab.e:881							if BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto L18; // [753] 762
    }
    else{
    }

    /** symtab.e:882								add_ref( tok )*/
    Ref(_tok_48021);
    _53add_ref(_tok_48021);
L18: 

    /** symtab.e:884							return tok*/
    DeRefDS(_word_48004);
    DeRef(_msg_48012);
    DeRef(_b_name_48013);
    DeRef(_gtok_48022);
    _24815 = NOVALUE;
    _24806 = NOVALUE;
    _24854 = NOVALUE;
    _24833 = NOVALUE;
    _24822 = NOVALUE;
    DeRef(_24778);
    _24778 = NOVALUE;
    DeRef(_24829);
    _24829 = NOVALUE;
    _24802 = NOVALUE;
    DeRef(_24843);
    _24843 = NOVALUE;
    DeRef(_24827);
    _24827 = NOVALUE;
    DeRef(_24835);
    _24835 = NOVALUE;
    DeRef(_24837);
    _24837 = NOVALUE;
    _24807 = NOVALUE;
    DeRef(_24788);
    _24788 = NOVALUE;
    _24841 = NOVALUE;
    _24847 = NOVALUE;
    return _tok_48021;
    goto L17; // [769] 1010
L16: 

    /** symtab.e:887						integer tok_file = SymTab[tok[T_SYM]][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_tok_48021);
    _24859 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_24859)){
        _24860 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24859)->dbl));
    }
    else{
        _24860 = (object)*(((s1_ptr)_2)->base + _24859);
    }
    _2 = (object)SEQ_PTR(_24860);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _tok_file_48193 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _tok_file_48193 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    if (!IS_ATOM_INT(_tok_file_48193)){
        _tok_file_48193 = (object)DBL_PTR(_tok_file_48193)->dbl;
    }
    _24860 = NOVALUE;

    /** symtab.e:888						integer good = 0*/
    _good_48200 = 0;

    /** symtab.e:889						if scope = SC_PRIVATE or scope = SC_PREDEF then*/
    _24862 = (_scope_48014 == 3);
    if (_24862 != 0) {
        goto L19; // [807] 940
    }
    _24864 = (_scope_48014 == 7);
    if (_24864 == 0)
    {
        DeRef(_24864);
        _24864 = NOVALUE;
        goto L1A; // [818] 825
    }
    else{
        DeRef(_24864);
        _24864 = NOVALUE;
    }
    goto L19; // [822] 940
L1A: 

    /** symtab.e:892						elsif file_no = tok_file then*/
    if (_file_no_48005 != _tok_file_48193)
    goto L1B; // [827] 839

    /** symtab.e:893							good = 1*/
    _good_48200 = 1;
    goto L19; // [836] 940
L1B: 

    /** symtab.e:896							integer include_type = 0*/
    _include_type_48210 = 0;

    /** symtab.e:897							switch scope do*/
    _0 = _scope_48014;
    switch ( _0 ){ 

        /** symtab.e:898								case SC_GLOBAL then*/
        case 6:

        /** symtab.e:899									if Resolve_unincluded_globals then*/
        if (_53Resolve_unincluded_globals_47995 == 0)
        {
            goto L1C; // [859] 874
        }
        else{
        }

        /** symtab.e:900										include_type = ANY_INCLUDE*/
        _include_type_48210 = 7;
        goto L1D; // [871] 919
L1C: 

        /** symtab.e:902										include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_48210 = 6;
        goto L1D; // [884] 919

        /** symtab.e:905								case SC_PUBLIC then*/
        case 13:

        /** symtab.e:907									if tok_file != file_no then*/
        if (_tok_file_48193 == _file_no_48005)
        goto L1E; // [892] 908

        /** symtab.e:908										include_type = PUBLIC_INCLUDE*/
        _include_type_48210 = 4;
        goto L1F; // [905] 918
L1E: 

        /** symtab.e:910										include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_48210 = 6;
L1F: 
    ;}L1D: 

    /** symtab.e:914							good = and_bits( include_type, include_matrix[file_no][tok_file] )*/
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _24869 = (object)*(((s1_ptr)_2)->base + _file_no_48005);
    _2 = (object)SEQ_PTR(_24869);
    _24870 = (object)*(((s1_ptr)_2)->base + _tok_file_48193);
    _24869 = NOVALUE;
    if (IS_ATOM_INT(_24870)) {
        {uintptr_t tu;
             tu = (uintptr_t)_include_type_48210 & (uintptr_t)_24870;
             _good_48200 = MAKE_UINT(tu);
        }
    }
    else {
        _good_48200 = binary_op(AND_BITS, _include_type_48210, _24870);
    }
    _24870 = NOVALUE;
    if (!IS_ATOM_INT(_good_48200)) {
        _1 = (object)(DBL_PTR(_good_48200)->dbl);
        DeRefDS(_good_48200);
        _good_48200 = _1;
    }
L19: 

    /** symtab.e:917						if good then*/
    if (_good_48200 == 0)
    {
        goto L20; // [942] 1007
    }
    else{
    }

    /** symtab.e:919							if file_no = tok_file then*/
    if (_file_no_48005 != _tok_file_48193)
    goto L21; // [947] 971

    /** symtab.e:920								if BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto L22; // [955] 964
    }
    else{
    }

    /** symtab.e:921									add_ref(tok)*/
    Ref(_tok_48021);
    _53add_ref(_tok_48021);
L22: 

    /** symtab.e:923								return tok*/
    DeRefDS(_word_48004);
    DeRef(_msg_48012);
    DeRef(_b_name_48013);
    DeRef(_gtok_48022);
    DeRef(_24862);
    _24862 = NOVALUE;
    _24815 = NOVALUE;
    _24806 = NOVALUE;
    _24859 = NOVALUE;
    _24854 = NOVALUE;
    _24833 = NOVALUE;
    _24822 = NOVALUE;
    DeRef(_24778);
    _24778 = NOVALUE;
    DeRef(_24829);
    _24829 = NOVALUE;
    _24802 = NOVALUE;
    DeRef(_24843);
    _24843 = NOVALUE;
    DeRef(_24827);
    _24827 = NOVALUE;
    DeRef(_24835);
    _24835 = NOVALUE;
    DeRef(_24837);
    _24837 = NOVALUE;
    _24807 = NOVALUE;
    DeRef(_24788);
    _24788 = NOVALUE;
    _24841 = NOVALUE;
    _24847 = NOVALUE;
    return _tok_48021;
L21: 

    /** symtab.e:926							gtok = tok*/
    Ref(_tok_48021);
    DeRef(_gtok_48022);
    _gtok_48022 = _tok_48021;

    /** symtab.e:927							dup_globals &= st_ptr*/
    Append(&_53dup_globals_47990, _53dup_globals_47990, _st_ptr_48018);

    /** symtab.e:928							in_include_path &= include_matrix[scanning_file][tok_file] != 0*/
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _24874 = (object)*(((s1_ptr)_2)->base + _scanning_file_48006);
    _2 = (object)SEQ_PTR(_24874);
    _24875 = (object)*(((s1_ptr)_2)->base + _tok_file_48193);
    _24874 = NOVALUE;
    if (IS_ATOM_INT(_24875)) {
        _24876 = (_24875 != 0);
    }
    else {
        _24876 = binary_op(NOTEQ, _24875, 0);
    }
    _24875 = NOVALUE;
    if (IS_SEQUENCE(_53in_include_path_47992) && IS_ATOM(_24876)) {
        Ref(_24876);
        Append(&_53in_include_path_47992, _53in_include_path_47992, _24876);
    }
    else if (IS_ATOM(_53in_include_path_47992) && IS_SEQUENCE(_24876)) {
    }
    else {
        Concat((object_ptr)&_53in_include_path_47992, _53in_include_path_47992, _24876);
    }
    DeRef(_24876);
    _24876 = NOVALUE;
L20: 
L17: 
L7: 
L4: 

    /** symtab.e:936			st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24878 = (object)*(((s1_ptr)_2)->base + _st_ptr_48018);
    _2 = (object)SEQ_PTR(_24878);
    _st_ptr_48018 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_st_ptr_48018)){
        _st_ptr_48018 = (object)DBL_PTR(_st_ptr_48018)->dbl;
    }
    _24878 = NOVALUE;

    /** symtab.e:937		end while*/
    goto L1; // [1030] 69
L2: 

    /** symtab.e:939		if length(dup_overrides) then*/
    if (IS_SEQUENCE(_53dup_overrides_47991)){
            _24880 = SEQ_PTR(_53dup_overrides_47991)->length;
    }
    else {
        _24880 = 1;
    }
    if (_24880 == 0)
    {
        _24880 = NOVALUE;
        goto L23; // [1040] 1093
    }
    else{
        _24880 = NOVALUE;
    }

    /** symtab.e:940			st_ptr = dup_overrides[1]*/
    _2 = (object)SEQ_PTR(_53dup_overrides_47991);
    _st_ptr_48018 = (object)*(((s1_ptr)_2)->base + 1);

    /** symtab.e:941			tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24882 = (object)*(((s1_ptr)_2)->base + _st_ptr_48018);
    _2 = (object)SEQ_PTR(_24882);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _24883 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _24883 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _24882 = NOVALUE;
    Ref(_24883);
    DeRef(_tok_48021);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24883;
    ((intptr_t *)_2)[2] = _st_ptr_48018;
    _tok_48021 = MAKE_SEQ(_1);
    _24883 = NOVALUE;

    /** symtab.e:944				if BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto L24; // [1075] 1084
    }
    else{
    }

    /** symtab.e:945					add_ref(tok)*/
    RefDS(_tok_48021);
    _53add_ref(_tok_48021);
L24: 

    /** symtab.e:948				return tok*/
    DeRefDS(_word_48004);
    DeRef(_msg_48012);
    DeRef(_b_name_48013);
    DeRef(_gtok_48022);
    DeRef(_24862);
    _24862 = NOVALUE;
    _24815 = NOVALUE;
    _24806 = NOVALUE;
    _24859 = NOVALUE;
    _24854 = NOVALUE;
    _24833 = NOVALUE;
    _24822 = NOVALUE;
    DeRef(_24778);
    _24778 = NOVALUE;
    DeRef(_24829);
    _24829 = NOVALUE;
    _24802 = NOVALUE;
    DeRef(_24843);
    _24843 = NOVALUE;
    DeRef(_24827);
    _24827 = NOVALUE;
    DeRef(_24835);
    _24835 = NOVALUE;
    DeRef(_24837);
    _24837 = NOVALUE;
    _24807 = NOVALUE;
    DeRef(_24788);
    _24788 = NOVALUE;
    _24841 = NOVALUE;
    _24847 = NOVALUE;
    return _tok_48021;
    goto L25; // [1090] 1320
L23: 

    /** symtab.e:951		elsif st_builtin != 0 then*/
    if (_st_builtin_48019 == 0)
    goto L26; // [1095] 1319

    /** symtab.e:952			if length(dup_globals) and find(SymTab[st_builtin][S_NAME], builtin_warnings) = 0 then*/
    if (IS_SEQUENCE(_53dup_globals_47990)){
            _24886 = SEQ_PTR(_53dup_globals_47990)->length;
    }
    else {
        _24886 = 1;
    }
    if (_24886 == 0) {
        goto L27; // [1106] 1279
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24888 = (object)*(((s1_ptr)_2)->base + _st_builtin_48019);
    _2 = (object)SEQ_PTR(_24888);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _24889 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _24889 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _24888 = NOVALUE;
    _24890 = find_from(_24889, _53builtin_warnings_47994, 1);
    _24889 = NOVALUE;
    _24891 = (_24890 == 0);
    _24890 = NOVALUE;
    if (_24891 == 0)
    {
        DeRef(_24891);
        _24891 = NOVALUE;
        goto L27; // [1134] 1279
    }
    else{
        DeRef(_24891);
        _24891 = NOVALUE;
    }

    /** symtab.e:953				sequence msg_file */

    /** symtab.e:955				b_name = SymTab[st_builtin][S_NAME]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24892 = (object)*(((s1_ptr)_2)->base + _st_builtin_48019);
    DeRef(_b_name_48013);
    _2 = (object)SEQ_PTR(_24892);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _b_name_48013 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _b_name_48013 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_b_name_48013);
    _24892 = NOVALUE;

    /** symtab.e:956				builtin_warnings = append(builtin_warnings, b_name)*/
    RefDS(_b_name_48013);
    Append(&_53builtin_warnings_47994, _53builtin_warnings_47994, _b_name_48013);

    /** symtab.e:958				if length(dup_globals) > 1 then*/
    if (IS_SEQUENCE(_53dup_globals_47990)){
            _24895 = SEQ_PTR(_53dup_globals_47990)->length;
    }
    else {
        _24895 = 1;
    }
    if (_24895 <= 1)
    goto L28; // [1170] 1184

    /** symtab.e:959					msg = "\n"*/
    RefDS(_22210);
    DeRef(_msg_48012);
    _msg_48012 = _22210;
    goto L29; // [1181] 1192
L28: 

    /** symtab.e:961					msg = ""*/
    RefDS(_22015);
    DeRef(_msg_48012);
    _msg_48012 = _22015;
L29: 

    /** symtab.e:964				for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_53dup_globals_47990)){
            _24897 = SEQ_PTR(_53dup_globals_47990)->length;
    }
    else {
        _24897 = 1;
    }
    {
        object _i_48277;
        _i_48277 = 1;
L2A: 
        if (_i_48277 > _24897){
            goto L2B; // [1199] 1255
        }

        /** symtab.e:965					msg_file = known_files[SymTab[dup_globals[i]][S_FILE_NO]]*/
        _2 = (object)SEQ_PTR(_53dup_globals_47990);
        _24898 = (object)*(((s1_ptr)_2)->base + _i_48277);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!IS_ATOM_INT(_24898)){
            _24899 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24898)->dbl));
        }
        else{
            _24899 = (object)*(((s1_ptr)_2)->base + _24898);
        }
        _2 = (object)SEQ_PTR(_24899);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _24900 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _24900 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _24899 = NOVALUE;
        DeRef(_msg_file_48266);
        _2 = (object)SEQ_PTR(_13known_files_11317);
        if (!IS_ATOM_INT(_24900)){
            _msg_file_48266 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24900)->dbl));
        }
        else{
            _msg_file_48266 = (object)*(((s1_ptr)_2)->base + _24900);
        }
        Ref(_msg_file_48266);

        /** symtab.e:966					msg &= "    " & msg_file & "\n"*/
        {
            object concat_list[3];

            concat_list[0] = _22210;
            concat_list[1] = _msg_file_48266;
            concat_list[2] = _24902;
            Concat_N((object_ptr)&_24903, concat_list, 3);
        }
        Concat((object_ptr)&_msg_48012, _msg_48012, _24903);
        DeRefDS(_24903);
        _24903 = NOVALUE;

        /** symtab.e:967				end for*/
        _i_48277 = _i_48277 + 1;
        goto L2A; // [1250] 1206
L2B: 
        ;
    }

    /** symtab.e:969				Warning(234, builtin_chosen_warning_flag, {b_name, known_files[scanning_file], msg})*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _24905 = (object)*(((s1_ptr)_2)->base + _scanning_file_48006);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_b_name_48013);
    ((intptr_t*)_2)[1] = _b_name_48013;
    Ref(_24905);
    ((intptr_t*)_2)[2] = _24905;
    RefDS(_msg_48012);
    ((intptr_t*)_2)[3] = _msg_48012;
    _24906 = MAKE_SEQ(_1);
    _24905 = NOVALUE;
    _49Warning(234, 8, _24906);
    _24906 = NOVALUE;
L27: 
    DeRef(_msg_file_48266);
    _msg_file_48266 = NOVALUE;

    /** symtab.e:972			tok = {SymTab[st_builtin][S_TOKEN], st_builtin}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24907 = (object)*(((s1_ptr)_2)->base + _st_builtin_48019);
    _2 = (object)SEQ_PTR(_24907);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _24908 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _24908 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _24907 = NOVALUE;
    Ref(_24908);
    DeRef(_tok_48021);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24908;
    ((intptr_t *)_2)[2] = _st_builtin_48019;
    _tok_48021 = MAKE_SEQ(_1);
    _24908 = NOVALUE;

    /** symtab.e:974			if BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto L2C; // [1303] 1312
    }
    else{
    }

    /** symtab.e:975				add_ref(tok)*/
    RefDS(_tok_48021);
    _53add_ref(_tok_48021);
L2C: 

    /** symtab.e:978			return tok*/
    DeRefDS(_word_48004);
    DeRef(_msg_48012);
    DeRef(_b_name_48013);
    DeRef(_gtok_48022);
    DeRef(_24862);
    _24862 = NOVALUE;
    _24815 = NOVALUE;
    _24806 = NOVALUE;
    _24859 = NOVALUE;
    _24854 = NOVALUE;
    _24833 = NOVALUE;
    _24822 = NOVALUE;
    DeRef(_24778);
    _24778 = NOVALUE;
    _24900 = NOVALUE;
    DeRef(_24829);
    _24829 = NOVALUE;
    _24802 = NOVALUE;
    DeRef(_24843);
    _24843 = NOVALUE;
    DeRef(_24827);
    _24827 = NOVALUE;
    DeRef(_24835);
    _24835 = NOVALUE;
    DeRef(_24837);
    _24837 = NOVALUE;
    _24807 = NOVALUE;
    _24898 = NOVALUE;
    DeRef(_24788);
    _24788 = NOVALUE;
    _24841 = NOVALUE;
    _24847 = NOVALUE;
    return _tok_48021;
L26: 
L25: 

    /** symtab.e:981	ifdef STDDEBUG then*/

    /** symtab.e:996		if length(dup_globals) > 1 and find( 1, in_include_path ) then*/
    if (IS_SEQUENCE(_53dup_globals_47990)){
            _24910 = SEQ_PTR(_53dup_globals_47990)->length;
    }
    else {
        _24910 = 1;
    }
    _24911 = (_24910 > 1);
    _24910 = NOVALUE;
    if (_24911 == 0) {
        goto L2D; // [1333] 1452
    }
    _24913 = find_from(1, _53in_include_path_47992, 1);
    if (_24913 == 0)
    {
        _24913 = NOVALUE;
        goto L2D; // [1345] 1452
    }
    else{
        _24913 = NOVALUE;
    }

    /** symtab.e:998			ix = 1*/
    _ix_48016 = 1;

    /** symtab.e:999			while ix <= length(dup_globals) do*/
L2E: 
    if (IS_SEQUENCE(_53dup_globals_47990)){
            _24914 = SEQ_PTR(_53dup_globals_47990)->length;
    }
    else {
        _24914 = 1;
    }
    if (_ix_48016 > _24914)
    goto L2F; // [1363] 1411

    /** symtab.e:1000				if in_include_path[ix] then*/
    _2 = (object)SEQ_PTR(_53in_include_path_47992);
    _24916 = (object)*(((s1_ptr)_2)->base + _ix_48016);
    if (_24916 == 0) {
        _24916 = NOVALUE;
        goto L30; // [1375] 1387
    }
    else {
        if (!IS_ATOM_INT(_24916) && DBL_PTR(_24916)->dbl == 0.0){
            _24916 = NOVALUE;
            goto L30; // [1375] 1387
        }
        _24916 = NOVALUE;
    }
    _24916 = NOVALUE;

    /** symtab.e:1001					ix += 1*/
    _ix_48016 = _ix_48016 + 1;
    goto L2E; // [1384] 1358
L30: 

    /** symtab.e:1003					dup_globals     = remove( dup_globals, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_53dup_globals_47990);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_48016)) ? _ix_48016 : (object)(DBL_PTR(_ix_48016)->dbl);
        int stop = (IS_ATOM_INT(_ix_48016)) ? _ix_48016 : (object)(DBL_PTR(_ix_48016)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_53dup_globals_47990), start, &_53dup_globals_47990 );
            }
            else Tail(SEQ_PTR(_53dup_globals_47990), stop+1, &_53dup_globals_47990);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_53dup_globals_47990), start, &_53dup_globals_47990);
        }
        else {
            assign_slice_seq = &assign_space;
            _53dup_globals_47990 = Remove_elements(start, stop, (SEQ_PTR(_53dup_globals_47990)->ref == 1));
        }
    }

    /** symtab.e:1004					in_include_path = remove( in_include_path, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_53in_include_path_47992);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_48016)) ? _ix_48016 : (object)(DBL_PTR(_ix_48016)->dbl);
        int stop = (IS_ATOM_INT(_ix_48016)) ? _ix_48016 : (object)(DBL_PTR(_ix_48016)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_53in_include_path_47992), start, &_53in_include_path_47992 );
            }
            else Tail(SEQ_PTR(_53in_include_path_47992), stop+1, &_53in_include_path_47992);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_53in_include_path_47992), start, &_53in_include_path_47992);
        }
        else {
            assign_slice_seq = &assign_space;
            _53in_include_path_47992 = Remove_elements(start, stop, (SEQ_PTR(_53in_include_path_47992)->ref == 1));
        }
    }

    /** symtab.e:1006			end while*/
    goto L2E; // [1408] 1358
L2F: 

    /** symtab.e:1008			if length(dup_globals) = 1 then*/
    if (IS_SEQUENCE(_53dup_globals_47990)){
            _24920 = SEQ_PTR(_53dup_globals_47990)->length;
    }
    else {
        _24920 = 1;
    }
    if (_24920 != 1)
    goto L31; // [1418] 1451

    /** symtab.e:1009					st_ptr = dup_globals[1]*/
    _2 = (object)SEQ_PTR(_53dup_globals_47990);
    _st_ptr_48018 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_st_ptr_48018)){
        _st_ptr_48018 = (object)DBL_PTR(_st_ptr_48018)->dbl;
    }

    /** symtab.e:1010					gtok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24923 = (object)*(((s1_ptr)_2)->base + _st_ptr_48018);
    _2 = (object)SEQ_PTR(_24923);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _24924 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _24924 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _24923 = NOVALUE;
    Ref(_24924);
    DeRef(_gtok_48022);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24924;
    ((intptr_t *)_2)[2] = _st_ptr_48018;
    _gtok_48022 = MAKE_SEQ(_1);
    _24924 = NOVALUE;
L31: 
L2D: 

    /** symtab.e:1014	ifdef STDDEBUG then*/

    /** symtab.e:1023		if length(dup_globals) = 1 and st_builtin = 0 then*/
    if (IS_SEQUENCE(_53dup_globals_47990)){
            _24926 = SEQ_PTR(_53dup_globals_47990)->length;
    }
    else {
        _24926 = 1;
    }
    _24927 = (_24926 == 1);
    _24926 = NOVALUE;
    if (_24927 == 0) {
        goto L32; // [1465] 1644
    }
    _24929 = (_st_builtin_48019 == 0);
    if (_24929 == 0)
    {
        DeRef(_24929);
        _24929 = NOVALUE;
        goto L32; // [1474] 1644
    }
    else{
        DeRef(_24929);
        _24929 = NOVALUE;
    }

    /** symtab.e:1026			if BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto L33; // [1481] 1492
    }
    else{
    }

    /** symtab.e:1027				add_ref(gtok)*/
    Ref(_gtok_48022);
    _53add_ref(_gtok_48022);
L33: 

    /** symtab.e:1029			if not in_include_path[1] and*/
    _2 = (object)SEQ_PTR(_53in_include_path_47992);
    _24930 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24930)) {
        _24931 = (_24930 == 0);
    }
    else {
        _24931 = unary_op(NOT, _24930);
    }
    _24930 = NOVALUE;
    if (IS_ATOM_INT(_24931)) {
        if (_24931 == 0) {
            goto L34; // [1503] 1637
        }
    }
    else {
        if (DBL_PTR(_24931)->dbl == 0.0) {
            goto L34; // [1503] 1637
        }
    }
    _2 = (object)SEQ_PTR(_gtok_48022);
    _24933 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_24933)){
        _24934 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24933)->dbl));
    }
    else{
        _24934 = (object)*(((s1_ptr)_2)->base + _24933);
    }
    _2 = (object)SEQ_PTR(_24934);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _24935 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _24935 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _24934 = NOVALUE;
    Ref(_24935);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _scanning_file_48006;
    ((intptr_t *)_2)[2] = _24935;
    _24936 = MAKE_SEQ(_1);
    _24935 = NOVALUE;
    _24937 = find_from(_24936, _53include_warnings_47993, 1);
    DeRefDS(_24936);
    _24936 = NOVALUE;
    _24938 = (_24937 == 0);
    _24937 = NOVALUE;
    if (_24938 == 0)
    {
        DeRef(_24938);
        _24938 = NOVALUE;
        goto L34; // [1542] 1637
    }
    else{
        DeRef(_24938);
        _24938 = NOVALUE;
    }

    /** symtab.e:1032				include_warnings = prepend( include_warnings,*/
    _2 = (object)SEQ_PTR(_gtok_48022);
    _24939 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_24939)){
        _24940 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24939)->dbl));
    }
    else{
        _24940 = (object)*(((s1_ptr)_2)->base + _24939);
    }
    _2 = (object)SEQ_PTR(_24940);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _24941 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _24941 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _24940 = NOVALUE;
    Ref(_24941);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _scanning_file_48006;
    ((intptr_t *)_2)[2] = _24941;
    _24942 = MAKE_SEQ(_1);
    _24941 = NOVALUE;
    RefDS(_24942);
    Prepend(&_53include_warnings_47993, _53include_warnings_47993, _24942);
    DeRefDS(_24942);
    _24942 = NOVALUE;

    /** symtab.e:1034	ifdef STDDEBUG then*/

    /** symtab.e:1040					symbol_resolution_warning = GetMsgText(MSG_12__IDENTIFIER_3_IN_4_IS_NOT_INCLUDED,0,*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _24944 = (object)*(((s1_ptr)_2)->base + _scanning_file_48006);
    Ref(_24944);
    _24945 = _53name_ext(_24944);
    _24944 = NOVALUE;
    _2 = (object)SEQ_PTR(_gtok_48022);
    _24946 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_24946)){
        _24947 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24946)->dbl));
    }
    else{
        _24947 = (object)*(((s1_ptr)_2)->base + _24946);
    }
    _2 = (object)SEQ_PTR(_24947);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _24948 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _24948 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _24947 = NOVALUE;
    _2 = (object)SEQ_PTR(_13known_files_11317);
    if (!IS_ATOM_INT(_24948)){
        _24949 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24948)->dbl));
    }
    else{
        _24949 = (object)*(((s1_ptr)_2)->base + _24948);
    }
    Ref(_24949);
    _24950 = _53name_ext(_24949);
    _24949 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24945;
    ((intptr_t*)_2)[2] = _12line_number_20227;
    RefDS(_word_48004);
    ((intptr_t*)_2)[3] = _word_48004;
    ((intptr_t*)_2)[4] = _24950;
    _24951 = MAKE_SEQ(_1);
    _24950 = NOVALUE;
    _24945 = NOVALUE;
    _0 = _30GetMsgText(233, 0, _24951);
    DeRef(_12symbol_resolution_warning_20328);
    _12symbol_resolution_warning_20328 = _0;
    _24951 = NOVALUE;
L34: 

    /** symtab.e:1047			return gtok*/
    DeRefDS(_word_48004);
    DeRef(_msg_48012);
    DeRef(_b_name_48013);
    DeRef(_tok_48021);
    DeRef(_24862);
    _24862 = NOVALUE;
    _24815 = NOVALUE;
    _24806 = NOVALUE;
    _24859 = NOVALUE;
    _24854 = NOVALUE;
    _24946 = NOVALUE;
    _24833 = NOVALUE;
    _24822 = NOVALUE;
    DeRef(_24911);
    _24911 = NOVALUE;
    DeRef(_24778);
    _24778 = NOVALUE;
    DeRef(_24931);
    _24931 = NOVALUE;
    _24900 = NOVALUE;
    _24933 = NOVALUE;
    _24939 = NOVALUE;
    DeRef(_24829);
    _24829 = NOVALUE;
    _24802 = NOVALUE;
    DeRef(_24843);
    _24843 = NOVALUE;
    _24948 = NOVALUE;
    DeRef(_24827);
    _24827 = NOVALUE;
    DeRef(_24835);
    _24835 = NOVALUE;
    DeRef(_24837);
    _24837 = NOVALUE;
    _24807 = NOVALUE;
    _24898 = NOVALUE;
    DeRef(_24788);
    _24788 = NOVALUE;
    DeRef(_24927);
    _24927 = NOVALUE;
    _24841 = NOVALUE;
    _24847 = NOVALUE;
    return _gtok_48022;
L32: 

    /** symtab.e:1051		if length(dup_globals) = 0 then*/
    if (IS_SEQUENCE(_53dup_globals_47990)){
            _24953 = SEQ_PTR(_53dup_globals_47990)->length;
    }
    else {
        _24953 = 1;
    }
    if (_24953 != 0)
    goto L35; // [1651] 1725

    /** symtab.e:1052			defined = SC_UNDEFINED*/
    _defined_48015 = 9;

    /** symtab.e:1054			if fwd_line_number then*/
    if (_12fwd_line_number_20228 == 0)
    {
        goto L36; // [1668] 1697
    }
    else{
    }

    /** symtab.e:1055				last_ForwardLine     = ForwardLine*/
    Ref(_49ForwardLine_49262);
    DeRef(_49last_ForwardLine_49264);
    _49last_ForwardLine_49264 = _49ForwardLine_49262;

    /** symtab.e:1056				last_forward_bp      = forward_bp*/
    _49last_forward_bp_49268 = _49forward_bp_49266;

    /** symtab.e:1057				last_fwd_line_number = fwd_line_number*/
    _12last_fwd_line_number_20230 = _12fwd_line_number_20228;
L36: 

    /** symtab.e:1060			ForwardLine = ThisLine*/
    Ref(_49ThisLine_49261);
    DeRef(_49ForwardLine_49262);
    _49ForwardLine_49262 = _49ThisLine_49261;

    /** symtab.e:1061			forward_bp = bp*/
    _49forward_bp_49266 = _49bp_49265;

    /** symtab.e:1062			fwd_line_number = line_number*/
    _12fwd_line_number_20228 = _12line_number_20227;
    goto L37; // [1722] 1768
L35: 

    /** symtab.e:1064		elsif length(dup_globals) then*/
    if (IS_SEQUENCE(_53dup_globals_47990)){
            _24955 = SEQ_PTR(_53dup_globals_47990)->length;
    }
    else {
        _24955 = 1;
    }
    if (_24955 == 0)
    {
        _24955 = NOVALUE;
        goto L38; // [1732] 1747
    }
    else{
        _24955 = NOVALUE;
    }

    /** symtab.e:1065			defined = SC_MULTIPLY_DEFINED*/
    _defined_48015 = 10;
    goto L37; // [1744] 1768
L38: 

    /** symtab.e:1066		elsif length(dup_overrides) then*/
    if (IS_SEQUENCE(_53dup_overrides_47991)){
            _24956 = SEQ_PTR(_53dup_overrides_47991)->length;
    }
    else {
        _24956 = 1;
    }
    if (_24956 == 0)
    {
        _24956 = NOVALUE;
        goto L39; // [1754] 1767
    }
    else{
        _24956 = NOVALUE;
    }

    /** symtab.e:1067			defined = SC_OVERRIDE*/
    _defined_48015 = 12;
L39: 
L37: 

    /** symtab.e:1070		if No_new_entry then*/
    if (_53No_new_entry_48001 == 0)
    {
        goto L3A; // [1772] 1795
    }
    else{
    }

    /** symtab.e:1071			return {IGNORED,word,defined,dup_globals}*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 509;
    RefDS(_word_48004);
    ((intptr_t*)_2)[2] = _word_48004;
    ((intptr_t*)_2)[3] = _defined_48015;
    RefDS(_53dup_globals_47990);
    ((intptr_t*)_2)[4] = _53dup_globals_47990;
    _24957 = MAKE_SEQ(_1);
    DeRefDS(_word_48004);
    DeRef(_msg_48012);
    DeRef(_b_name_48013);
    DeRef(_tok_48021);
    DeRef(_gtok_48022);
    DeRef(_24862);
    _24862 = NOVALUE;
    _24815 = NOVALUE;
    _24806 = NOVALUE;
    _24859 = NOVALUE;
    _24854 = NOVALUE;
    _24946 = NOVALUE;
    _24833 = NOVALUE;
    _24822 = NOVALUE;
    DeRef(_24911);
    _24911 = NOVALUE;
    DeRef(_24778);
    _24778 = NOVALUE;
    DeRef(_24931);
    _24931 = NOVALUE;
    _24900 = NOVALUE;
    _24933 = NOVALUE;
    _24939 = NOVALUE;
    DeRef(_24829);
    _24829 = NOVALUE;
    _24802 = NOVALUE;
    DeRef(_24843);
    _24843 = NOVALUE;
    _24948 = NOVALUE;
    DeRef(_24827);
    _24827 = NOVALUE;
    DeRef(_24835);
    _24835 = NOVALUE;
    DeRef(_24837);
    _24837 = NOVALUE;
    _24807 = NOVALUE;
    _24898 = NOVALUE;
    DeRef(_24788);
    _24788 = NOVALUE;
    DeRef(_24927);
    _24927 = NOVALUE;
    _24841 = NOVALUE;
    _24847 = NOVALUE;
    return _24957;
L3A: 

    /** symtab.e:1074		tok = {VARIABLE, NewEntry(word, 0, defined,*/
    _2 = (object)SEQ_PTR(_53buckets_46799);
    _24958 = (object)*(((s1_ptr)_2)->base + _hashval_48010);
    RefDS(_word_48004);
    Ref(_24958);
    _24959 = _53NewEntry(_word_48004, 0, _defined_48015, -100, _hashval_48010, _24958, 0);
    _24958 = NOVALUE;
    DeRef(_tok_48021);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _24959;
    _tok_48021 = MAKE_SEQ(_1);
    _24959 = NOVALUE;

    /** symtab.e:1076		buckets[hashval] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_48021);
    _24961 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_24961);
    _2 = (object)SEQ_PTR(_53buckets_46799);
    _2 = (object)(((s1_ptr)_2)->base + _hashval_48010);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24961;
    if( _1 != _24961 ){
        DeRef(_1);
    }
    _24961 = NOVALUE;

    /** symtab.e:1078		if file_no != -1 then*/
    if (_file_no_48005 == -1)
    goto L3B; // [1839] 1865

    /** symtab.e:1079			SymTab[tok[T_SYM]][S_FILE_NO] = file_no*/
    _2 = (object)SEQ_PTR(_tok_48021);
    _24963 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_24963))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_24963)->dbl));
    else
    _3 = (object)(_24963 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FILE_NO_19860))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _file_no_48005;
    DeRef(_1);
    _24964 = NOVALUE;
L3B: 

    /** symtab.e:1081		return tok  -- no ref on newly declared symbol*/
    DeRefDS(_word_48004);
    DeRef(_msg_48012);
    DeRef(_b_name_48013);
    DeRef(_gtok_48022);
    DeRef(_24862);
    _24862 = NOVALUE;
    _24815 = NOVALUE;
    _24806 = NOVALUE;
    _24859 = NOVALUE;
    _24854 = NOVALUE;
    _24946 = NOVALUE;
    _24833 = NOVALUE;
    _24822 = NOVALUE;
    DeRef(_24911);
    _24911 = NOVALUE;
    DeRef(_24778);
    _24778 = NOVALUE;
    DeRef(_24931);
    _24931 = NOVALUE;
    _24900 = NOVALUE;
    _24963 = NOVALUE;
    _24933 = NOVALUE;
    _24939 = NOVALUE;
    DeRef(_24829);
    _24829 = NOVALUE;
    _24802 = NOVALUE;
    DeRef(_24843);
    _24843 = NOVALUE;
    _24948 = NOVALUE;
    DeRef(_24827);
    _24827 = NOVALUE;
    DeRef(_24835);
    _24835 = NOVALUE;
    DeRef(_24957);
    _24957 = NOVALUE;
    DeRef(_24837);
    _24837 = NOVALUE;
    _24807 = NOVALUE;
    _24898 = NOVALUE;
    DeRef(_24788);
    _24788 = NOVALUE;
    DeRef(_24927);
    _24927 = NOVALUE;
    _24841 = NOVALUE;
    _24847 = NOVALUE;
    return _tok_48021;
    ;
}


void _53Hide(object _s_48415)
{
    object _prev_48417 = NOVALUE;
    object _p_48418 = NOVALUE;
    object _24984 = NOVALUE;
    object _24983 = NOVALUE;
    object _24982 = NOVALUE;
    object _24980 = NOVALUE;
    object _24979 = NOVALUE;
    object _24978 = NOVALUE;
    object _24977 = NOVALUE;
    object _24976 = NOVALUE;
    object _24972 = NOVALUE;
    object _24971 = NOVALUE;
    object _24970 = NOVALUE;
    object _24969 = NOVALUE;
    object _24967 = NOVALUE;
    object _24966 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_48415)) {
        _1 = (object)(DBL_PTR(_s_48415)->dbl);
        DeRefDS(_s_48415);
        _s_48415 = _1;
    }

    /** symtab.e:1090		p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24966 = (object)*(((s1_ptr)_2)->base + _s_48415);
    _2 = (object)SEQ_PTR(_24966);
    _24967 = (object)*(((s1_ptr)_2)->base + 11);
    _24966 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_46799);
    if (!IS_ATOM_INT(_24967)){
        _p_48418 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24967)->dbl));
    }
    else{
        _p_48418 = (object)*(((s1_ptr)_2)->base + _24967);
    }
    if (!IS_ATOM_INT(_p_48418)){
        _p_48418 = (object)DBL_PTR(_p_48418)->dbl;
    }

    /** symtab.e:1091		prev = 0*/
    _prev_48417 = 0;

    /** symtab.e:1093		while p != s and p != 0 do*/
L1: 
    _24969 = (_p_48418 != _s_48415);
    if (_24969 == 0) {
        goto L2; // [41] 81
    }
    _24971 = (_p_48418 != 0);
    if (_24971 == 0)
    {
        DeRef(_24971);
        _24971 = NOVALUE;
        goto L2; // [50] 81
    }
    else{
        DeRef(_24971);
        _24971 = NOVALUE;
    }

    /** symtab.e:1094			prev = p*/
    _prev_48417 = _p_48418;

    /** symtab.e:1095			p = SymTab[p][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24972 = (object)*(((s1_ptr)_2)->base + _p_48418);
    _2 = (object)SEQ_PTR(_24972);
    _p_48418 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_p_48418)){
        _p_48418 = (object)DBL_PTR(_p_48418)->dbl;
    }
    _24972 = NOVALUE;

    /** symtab.e:1096		end while*/
    goto L1; // [78] 37
L2: 

    /** symtab.e:1098		if p = 0 then*/
    if (_p_48418 != 0)
    goto L3; // [83] 93

    /** symtab.e:1099			return -- already hidden*/
    DeRef(_24969);
    _24969 = NOVALUE;
    _24967 = NOVALUE;
    return;
L3: 

    /** symtab.e:1101		if prev = 0 then*/
    if (_prev_48417 != 0)
    goto L4; // [95] 134

    /** symtab.e:1102			buckets[SymTab[s][S_HASHVAL]] = SymTab[s][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24976 = (object)*(((s1_ptr)_2)->base + _s_48415);
    _2 = (object)SEQ_PTR(_24976);
    _24977 = (object)*(((s1_ptr)_2)->base + 11);
    _24976 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24978 = (object)*(((s1_ptr)_2)->base + _s_48415);
    _2 = (object)SEQ_PTR(_24978);
    _24979 = (object)*(((s1_ptr)_2)->base + 9);
    _24978 = NOVALUE;
    Ref(_24979);
    _2 = (object)SEQ_PTR(_53buckets_46799);
    if (!IS_ATOM_INT(_24977))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_24977)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _24977);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24979;
    if( _1 != _24979 ){
        DeRef(_1);
    }
    _24979 = NOVALUE;
    goto L5; // [131] 162
L4: 

    /** symtab.e:1104			SymTab[prev][S_SAMEHASH] = SymTab[s][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_48417 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24982 = (object)*(((s1_ptr)_2)->base + _s_48415);
    _2 = (object)SEQ_PTR(_24982);
    _24983 = (object)*(((s1_ptr)_2)->base + 9);
    _24982 = NOVALUE;
    Ref(_24983);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24983;
    if( _1 != _24983 ){
        DeRef(_1);
    }
    _24983 = NOVALUE;
    _24980 = NOVALUE;
L5: 

    /** symtab.e:1106		SymTab[s][S_SAMEHASH] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48415 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _24984 = NOVALUE;

    /** symtab.e:1107	end procedure*/
    DeRef(_24969);
    _24969 = NOVALUE;
    _24977 = NOVALUE;
    _24967 = NOVALUE;
    return;
    ;
}


void _53Show(object _s_48460)
{
    object _p_48462 = NOVALUE;
    object _24996 = NOVALUE;
    object _24995 = NOVALUE;
    object _24993 = NOVALUE;
    object _24992 = NOVALUE;
    object _24990 = NOVALUE;
    object _24989 = NOVALUE;
    object _24987 = NOVALUE;
    object _24986 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:1114		p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24986 = (object)*(((s1_ptr)_2)->base + _s_48460);
    _2 = (object)SEQ_PTR(_24986);
    _24987 = (object)*(((s1_ptr)_2)->base + 11);
    _24986 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_46799);
    if (!IS_ATOM_INT(_24987)){
        _p_48462 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24987)->dbl));
    }
    else{
        _p_48462 = (object)*(((s1_ptr)_2)->base + _24987);
    }
    if (!IS_ATOM_INT(_p_48462)){
        _p_48462 = (object)DBL_PTR(_p_48462)->dbl;
    }

    /** symtab.e:1116		if SymTab[s][S_SAMEHASH] or p = s then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24989 = (object)*(((s1_ptr)_2)->base + _s_48460);
    _2 = (object)SEQ_PTR(_24989);
    _24990 = (object)*(((s1_ptr)_2)->base + 9);
    _24989 = NOVALUE;
    if (IS_ATOM_INT(_24990)) {
        if (_24990 != 0) {
            goto L1; // [39] 52
        }
    }
    else {
        if (DBL_PTR(_24990)->dbl != 0.0) {
            goto L1; // [39] 52
        }
    }
    _24992 = (_p_48462 == _s_48460);
    if (_24992 == 0)
    {
        DeRef(_24992);
        _24992 = NOVALUE;
        goto L2; // [48] 58
    }
    else{
        DeRef(_24992);
        _24992 = NOVALUE;
    }
L1: 

    /** symtab.e:1118			return*/
    _24990 = NOVALUE;
    _24987 = NOVALUE;
    return;
L2: 

    /** symtab.e:1121		SymTab[s][S_SAMEHASH] = p*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48460 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_48462;
    DeRef(_1);
    _24993 = NOVALUE;

    /** symtab.e:1122		buckets[SymTab[s][S_HASHVAL]] = s*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24995 = (object)*(((s1_ptr)_2)->base + _s_48460);
    _2 = (object)SEQ_PTR(_24995);
    _24996 = (object)*(((s1_ptr)_2)->base + 11);
    _24995 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_46799);
    if (!IS_ATOM_INT(_24996))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_24996)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _24996);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_48460;
    DeRef(_1);

    /** symtab.e:1124	end procedure*/
    _24990 = NOVALUE;
    _24996 = NOVALUE;
    _24987 = NOVALUE;
    return;
    ;
}


void _53hide_params(object _s_48486)
{
    object _param_48488 = NOVALUE;
    object _24999 = NOVALUE;
    object _24998 = NOVALUE;
    object _24997 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1127		symtab_index param = s*/
    _param_48488 = _s_48486;

    /** symtab.e:1128		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24997 = (object)*(((s1_ptr)_2)->base + _s_48486);
    _2 = (object)SEQ_PTR(_24997);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _24998 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _24998 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _24997 = NOVALUE;
    {
        object _i_48490;
        _i_48490 = 1;
L1: 
        if (binary_op_a(GREATER, _i_48490, _24998)){
            goto L2; // [24] 59
        }

        /** symtab.e:1129			param = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24999 = (object)*(((s1_ptr)_2)->base + _s_48486);
        _2 = (object)SEQ_PTR(_24999);
        _param_48488 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_48488)){
            _param_48488 = (object)DBL_PTR(_param_48488)->dbl;
        }
        _24999 = NOVALUE;

        /** symtab.e:1130			Hide( param )*/
        _53Hide(_param_48488);

        /** symtab.e:1131		end for*/
        _0 = _i_48490;
        if (IS_ATOM_INT(_i_48490)) {
            _i_48490 = _i_48490 + 1;
            if ((object)((uintptr_t)_i_48490 +(uintptr_t) HIGH_BITS) >= 0){
                _i_48490 = NewDouble((eudouble)_i_48490);
            }
        }
        else {
            _i_48490 = binary_op_a(PLUS, _i_48490, 1);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_48490);
    }

    /** symtab.e:1132	end procedure*/
    _24998 = NOVALUE;
    return;
    ;
}


void _53show_params(object _s_48502)
{
    object _param_48504 = NOVALUE;
    object _25003 = NOVALUE;
    object _25002 = NOVALUE;
    object _25001 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1135		symtab_index param = s*/
    _param_48504 = _s_48502;

    /** symtab.e:1136		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25001 = (object)*(((s1_ptr)_2)->base + _s_48502);
    _2 = (object)SEQ_PTR(_25001);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _25002 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _25002 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _25001 = NOVALUE;
    {
        object _i_48506;
        _i_48506 = 1;
L1: 
        if (binary_op_a(GREATER, _i_48506, _25002)){
            goto L2; // [24] 59
        }

        /** symtab.e:1137			param = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _25003 = (object)*(((s1_ptr)_2)->base + _s_48502);
        _2 = (object)SEQ_PTR(_25003);
        _param_48504 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_48504)){
            _param_48504 = (object)DBL_PTR(_param_48504)->dbl;
        }
        _25003 = NOVALUE;

        /** symtab.e:1138			Show( param )*/
        _53Show(_param_48504);

        /** symtab.e:1139		end for*/
        _0 = _i_48506;
        if (IS_ATOM_INT(_i_48506)) {
            _i_48506 = _i_48506 + 1;
            if ((object)((uintptr_t)_i_48506 +(uintptr_t) HIGH_BITS) >= 0){
                _i_48506 = NewDouble((eudouble)_i_48506);
            }
        }
        else {
            _i_48506 = binary_op_a(PLUS, _i_48506, 1);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_48506);
    }

    /** symtab.e:1140	end procedure*/
    _25002 = NOVALUE;
    return;
    ;
}


void _53LintCheck(object _s_48518)
{
    object _warn_level_48519 = NOVALUE;
    object _file_48520 = NOVALUE;
    object _vscope_48521 = NOVALUE;
    object _vname_48522 = NOVALUE;
    object _vusage_48523 = NOVALUE;
    object _25064 = NOVALUE;
    object _25063 = NOVALUE;
    object _25062 = NOVALUE;
    object _25061 = NOVALUE;
    object _25060 = NOVALUE;
    object _25059 = NOVALUE;
    object _25057 = NOVALUE;
    object _25056 = NOVALUE;
    object _25055 = NOVALUE;
    object _25054 = NOVALUE;
    object _25053 = NOVALUE;
    object _25052 = NOVALUE;
    object _25049 = NOVALUE;
    object _25048 = NOVALUE;
    object _25047 = NOVALUE;
    object _25046 = NOVALUE;
    object _25045 = NOVALUE;
    object _25044 = NOVALUE;
    object _25042 = NOVALUE;
    object _25040 = NOVALUE;
    object _25039 = NOVALUE;
    object _25037 = NOVALUE;
    object _25036 = NOVALUE;
    object _25034 = NOVALUE;
    object _25033 = NOVALUE;
    object _25032 = NOVALUE;
    object _25031 = NOVALUE;
    object _25029 = NOVALUE;
    object _25028 = NOVALUE;
    object _25024 = NOVALUE;
    object _25021 = NOVALUE;
    object _25020 = NOVALUE;
    object _25019 = NOVALUE;
    object _25018 = NOVALUE;
    object _25015 = NOVALUE;
    object _25014 = NOVALUE;
    object _25009 = NOVALUE;
    object _25007 = NOVALUE;
    object _25005 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_48518)) {
        _1 = (object)(DBL_PTR(_s_48518)->dbl);
        DeRefDS(_s_48518);
        _s_48518 = _1;
    }

    /** symtab.e:1150		vusage = SymTab[s][S_USAGE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25005 = (object)*(((s1_ptr)_2)->base + _s_48518);
    _2 = (object)SEQ_PTR(_25005);
    _vusage_48523 = (object)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_vusage_48523)){
        _vusage_48523 = (object)DBL_PTR(_vusage_48523)->dbl;
    }
    _25005 = NOVALUE;

    /** symtab.e:1151		vscope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25007 = (object)*(((s1_ptr)_2)->base + _s_48518);
    _2 = (object)SEQ_PTR(_25007);
    _vscope_48521 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_vscope_48521)){
        _vscope_48521 = (object)DBL_PTR(_vscope_48521)->dbl;
    }
    _25007 = NOVALUE;

    /** symtab.e:1152		vname = SymTab[s][S_NAME]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25009 = (object)*(((s1_ptr)_2)->base + _s_48518);
    DeRef(_vname_48522);
    _2 = (object)SEQ_PTR(_25009);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _vname_48522 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _vname_48522 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_vname_48522);
    _25009 = NOVALUE;

    /** symtab.e:1154		switch vusage do*/
    _0 = _vusage_48523;
    switch ( _0 ){ 

        /** symtab.e:1156			case U_UNUSED then*/
        case 0:

        /** symtab.e:1157				warn_level = 1*/
        _warn_level_48519 = 1;
        goto L1; // [67] 193

        /** symtab.e:1159			case U_WRITTEN then -- Set but never read*/
        case 2:

        /** symtab.e:1160				warn_level = 2*/
        _warn_level_48519 = 2;

        /** symtab.e:1162				if vscope > SC_LOCAL then*/
        if (_vscope_48521 <= 5)
        goto L2; // [82] 94

        /** symtab.e:1164					warn_level = 0 */
        _warn_level_48519 = 0;
        goto L1; // [91] 193
L2: 

        /** symtab.e:1166				elsif SymTab[s][S_MODE] = M_CONSTANT then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _25014 = (object)*(((s1_ptr)_2)->base + _s_48518);
        _2 = (object)SEQ_PTR(_25014);
        _25015 = (object)*(((s1_ptr)_2)->base + 3);
        _25014 = NOVALUE;
        if (binary_op_a(NOTEQ, _25015, 2)){
            _25015 = NOVALUE;
            goto L1; // [110] 193
        }
        _25015 = NOVALUE;

        /** symtab.e:1167					if not Strict_is_on then*/
        if (_12Strict_is_on_20292 != 0)
        goto L1; // [118] 193

        /** symtab.e:1170						warn_level = 0 */
        _warn_level_48519 = 0;
        goto L1; // [129] 193

        /** symtab.e:1174			case U_READ then -- Read but never set*/
        case 1:

        /** symtab.e:1175				if SymTab[s][S_VARNUM] >= SymTab[CurrentSub][S_NUM_ARGS] then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _25018 = (object)*(((s1_ptr)_2)->base + _s_48518);
        _2 = (object)SEQ_PTR(_25018);
        _25019 = (object)*(((s1_ptr)_2)->base + 16);
        _25018 = NOVALUE;
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _25020 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
        _2 = (object)SEQ_PTR(_25020);
        if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
            _25021 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
        }
        else{
            _25021 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
        }
        _25020 = NOVALUE;
        if (binary_op_a(LESS, _25019, _25021)){
            _25019 = NOVALUE;
            _25021 = NOVALUE;
            goto L3; // [163] 175
        }
        _25019 = NOVALUE;
        _25021 = NOVALUE;

        /** symtab.e:1176			    	warn_level = 3*/
        _warn_level_48519 = 3;
        goto L1; // [172] 193
L3: 

        /** symtab.e:1179			    	warn_level = 0*/
        _warn_level_48519 = 0;
        goto L1; // [181] 193

        /** symtab.e:1182		    case else*/
        default:

        /** symtab.e:1183		    	warn_level = 0*/
        _warn_level_48519 = 0;
    ;}L1: 

    /** symtab.e:1186		if warn_level = 0 then*/
    if (_warn_level_48519 != 0)
    goto L4; // [197] 207

    /** symtab.e:1187			return*/
    DeRef(_file_48520);
    DeRef(_vname_48522);
    return;
L4: 

    /** symtab.e:1191		file = abbreviate_path(known_files[current_file_no])*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _25024 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    Ref(_25024);
    RefDS(_22015);
    _0 = _file_48520;
    _file_48520 = _14abbreviate_path(_25024, _22015);
    DeRef(_0);
    _25024 = NOVALUE;

    /** symtab.e:1192		if warn_level = 3 then*/
    if (_warn_level_48519 != 3)
    goto L5; // [226] 308

    /** symtab.e:1193			if vscope = SC_LOCAL then*/
    if (_vscope_48521 != 5)
    goto L6; // [234] 275

    /** symtab.e:1194				if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25028 = (object)*(((s1_ptr)_2)->base + _s_48518);
    _2 = (object)SEQ_PTR(_25028);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _25029 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _25029 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _25028 = NOVALUE;
    if (binary_op_a(NOTEQ, _12current_file_no_20226, _25029)){
        _25029 = NOVALUE;
        goto L7; // [254] 602
    }
    _25029 = NOVALUE;

    /** symtab.e:1195					Warning(226, no_value_warning_flag, {file,  vname})*/
    RefDS(_vname_48522);
    RefDS(_file_48520);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48520;
    ((intptr_t *)_2)[2] = _vname_48522;
    _25031 = MAKE_SEQ(_1);
    _49Warning(226, 32, _25031);
    _25031 = NOVALUE;
    goto L7; // [272] 602
L6: 

    /** symtab.e:1198				Warning(227, no_value_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25032 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_25032);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _25033 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _25033 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _25032 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48520);
    ((intptr_t*)_2)[1] = _file_48520;
    RefDS(_vname_48522);
    ((intptr_t*)_2)[2] = _vname_48522;
    Ref(_25033);
    ((intptr_t*)_2)[3] = _25033;
    _25034 = MAKE_SEQ(_1);
    _25033 = NOVALUE;
    _49Warning(227, 32, _25034);
    _25034 = NOVALUE;
    goto L7; // [305] 602
L5: 

    /** symtab.e:1201			if vscope = SC_LOCAL then*/
    if (_vscope_48521 != 5)
    goto L8; // [312] 412

    /** symtab.e:1202				if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25036 = (object)*(((s1_ptr)_2)->base + _s_48518);
    _2 = (object)SEQ_PTR(_25036);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _25037 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _25037 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _25036 = NOVALUE;
    if (binary_op_a(NOTEQ, _12current_file_no_20226, _25037)){
        _25037 = NOVALUE;
        goto L9; // [332] 601
    }
    _25037 = NOVALUE;

    /** symtab.e:1203					if SymTab[s][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25039 = (object)*(((s1_ptr)_2)->base + _s_48518);
    _2 = (object)SEQ_PTR(_25039);
    _25040 = (object)*(((s1_ptr)_2)->base + 3);
    _25039 = NOVALUE;
    if (binary_op_a(NOTEQ, _25040, 2)){
        _25040 = NOVALUE;
        goto LA; // [352] 372
    }
    _25040 = NOVALUE;

    /** symtab.e:1204						Warning(228, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48522);
    RefDS(_file_48520);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48520;
    ((intptr_t *)_2)[2] = _vname_48522;
    _25042 = MAKE_SEQ(_1);
    _49Warning(228, 16, _25042);
    _25042 = NOVALUE;
    goto L9; // [369] 601
LA: 

    /** symtab.e:1206					elsif warn_level = 1 then*/
    if (_warn_level_48519 != 1)
    goto LB; // [374] 394

    /** symtab.e:1207						Warning(229, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48522);
    RefDS(_file_48520);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48520;
    ((intptr_t *)_2)[2] = _vname_48522;
    _25044 = MAKE_SEQ(_1);
    _49Warning(229, 16, _25044);
    _25044 = NOVALUE;
    goto L9; // [391] 601
LB: 

    /** symtab.e:1210						Warning(320, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48522);
    RefDS(_file_48520);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48520;
    ((intptr_t *)_2)[2] = _vname_48522;
    _25045 = MAKE_SEQ(_1);
    _49Warning(320, 16, _25045);
    _25045 = NOVALUE;
    goto L9; // [409] 601
L8: 

    /** symtab.e:1214				if SymTab[s][S_VARNUM] < SymTab[CurrentSub][S_NUM_ARGS] then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25046 = (object)*(((s1_ptr)_2)->base + _s_48518);
    _2 = (object)SEQ_PTR(_25046);
    _25047 = (object)*(((s1_ptr)_2)->base + 16);
    _25046 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25048 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_25048);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _25049 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _25049 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _25048 = NOVALUE;
    if (binary_op_a(GREATEREQ, _25047, _25049)){
        _25047 = NOVALUE;
        _25049 = NOVALUE;
        goto LC; // [440] 523
    }
    _25047 = NOVALUE;
    _25049 = NOVALUE;

    /** symtab.e:1216					if warn_level = 1 then*/
    if (_warn_level_48519 != 1)
    goto LD; // [446] 490

    /** symtab.e:1217						if Strict_is_on then*/
    if (_12Strict_is_on_20292 == 0)
    {
        goto LE; // [454] 600
    }
    else{
    }

    /** symtab.e:1219							Warning(230, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25052 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_25052);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _25053 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _25053 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _25052 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48520);
    ((intptr_t*)_2)[1] = _file_48520;
    RefDS(_vname_48522);
    ((intptr_t*)_2)[2] = _vname_48522;
    Ref(_25053);
    ((intptr_t*)_2)[3] = _25053;
    _25054 = MAKE_SEQ(_1);
    _25053 = NOVALUE;
    _49Warning(230, 16, _25054);
    _25054 = NOVALUE;
    goto LE; // [487] 600
LD: 

    /** symtab.e:1222						Warning(321, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25055 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_25055);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _25056 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _25056 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _25055 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48520);
    ((intptr_t*)_2)[1] = _file_48520;
    RefDS(_vname_48522);
    ((intptr_t*)_2)[2] = _vname_48522;
    Ref(_25056);
    ((intptr_t*)_2)[3] = _25056;
    _25057 = MAKE_SEQ(_1);
    _25056 = NOVALUE;
    _49Warning(321, 16, _25057);
    _25057 = NOVALUE;
    goto LE; // [520] 600
LC: 

    /** symtab.e:1226					if warn_level = 1 then*/
    if (_warn_level_48519 != 1)
    goto LF; // [525] 569

    /** symtab.e:1227						if Strict_is_on then*/
    if (_12Strict_is_on_20292 == 0)
    {
        goto L10; // [533] 599
    }
    else{
    }

    /** symtab.e:1229							Warning(231, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25059 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_25059);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _25060 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _25060 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _25059 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48520);
    ((intptr_t*)_2)[1] = _file_48520;
    RefDS(_vname_48522);
    ((intptr_t*)_2)[2] = _vname_48522;
    Ref(_25060);
    ((intptr_t*)_2)[3] = _25060;
    _25061 = MAKE_SEQ(_1);
    _25060 = NOVALUE;
    _49Warning(231, 16, _25061);
    _25061 = NOVALUE;
    goto L10; // [566] 599
LF: 

    /** symtab.e:1232						Warning(322, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25062 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_25062);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _25063 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _25063 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _25062 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48520);
    ((intptr_t*)_2)[1] = _file_48520;
    RefDS(_vname_48522);
    ((intptr_t*)_2)[2] = _vname_48522;
    Ref(_25063);
    ((intptr_t*)_2)[3] = _25063;
    _25064 = MAKE_SEQ(_1);
    _25063 = NOVALUE;
    _49Warning(322, 16, _25064);
    _25064 = NOVALUE;
L10: 
LE: 
L9: 
L7: 

    /** symtab.e:1238	end procedure*/
    DeRef(_file_48520);
    DeRef(_vname_48522);
    return;
    ;
}


void _53HideLocals()
{
    object _s_48689 = NOVALUE;
    object _25077 = NOVALUE;
    object _25075 = NOVALUE;
    object _25074 = NOVALUE;
    object _25073 = NOVALUE;
    object _25072 = NOVALUE;
    object _25071 = NOVALUE;
    object _25070 = NOVALUE;
    object _25069 = NOVALUE;
    object _25068 = NOVALUE;
    object _25067 = NOVALUE;
    object _25066 = NOVALUE;
    object _25065 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1244		mark_rechecks()*/
    _53mark_rechecks(_12current_file_no_20226);

    /** symtab.e:1245		s = file_start_sym*/
    _s_48689 = _12file_start_sym_20232;

    /** symtab.e:1246		while s do*/
L1: 
    if (_s_48689 == 0)
    {
        goto L2; // [22] 148
    }
    else{
    }

    /** symtab.e:1247			if SymTab[s][S_SCOPE] = SC_LOCAL and*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25065 = (object)*(((s1_ptr)_2)->base + _s_48689);
    _2 = (object)SEQ_PTR(_25065);
    _25066 = (object)*(((s1_ptr)_2)->base + 4);
    _25065 = NOVALUE;
    if (IS_ATOM_INT(_25066)) {
        _25067 = (_25066 == 5);
    }
    else {
        _25067 = binary_op(EQUALS, _25066, 5);
    }
    _25066 = NOVALUE;
    if (IS_ATOM_INT(_25067)) {
        if (_25067 == 0) {
            goto L3; // [45] 127
        }
    }
    else {
        if (DBL_PTR(_25067)->dbl == 0.0) {
            goto L3; // [45] 127
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25069 = (object)*(((s1_ptr)_2)->base + _s_48689);
    _2 = (object)SEQ_PTR(_25069);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _25070 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _25070 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _25069 = NOVALUE;
    if (IS_ATOM_INT(_25070)) {
        _25071 = (_25070 == _12current_file_no_20226);
    }
    else {
        _25071 = binary_op(EQUALS, _25070, _12current_file_no_20226);
    }
    _25070 = NOVALUE;
    if (_25071 == 0) {
        DeRef(_25071);
        _25071 = NOVALUE;
        goto L3; // [68] 127
    }
    else {
        if (!IS_ATOM_INT(_25071) && DBL_PTR(_25071)->dbl == 0.0){
            DeRef(_25071);
            _25071 = NOVALUE;
            goto L3; // [68] 127
        }
        DeRef(_25071);
        _25071 = NOVALUE;
    }
    DeRef(_25071);
    _25071 = NOVALUE;

    /** symtab.e:1249			   	if current_block = top_level_block and repl then*/
    _25072 = (_64current_block_25147 == _64top_level_block_25148);
    if (_25072 == 0) {
        goto L4; // [81] 94
    }
    goto L4; // [88] 94
    goto L5; // [91] 100
L4: 

    /** symtab.e:1251				Hide(s)*/
    _53Hide(_s_48689);
L5: 

    /** symtab.e:1253				if SymTab[s][S_TOKEN] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25074 = (object)*(((s1_ptr)_2)->base + _s_48689);
    _2 = (object)SEQ_PTR(_25074);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _25075 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _25075 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _25074 = NOVALUE;
    if (binary_op_a(NOTEQ, _25075, -100)){
        _25075 = NOVALUE;
        goto L6; // [116] 126
    }
    _25075 = NOVALUE;

    /** symtab.e:1254					LintCheck(s)*/
    _53LintCheck(_s_48689);
L6: 
L3: 

    /** symtab.e:1257			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25077 = (object)*(((s1_ptr)_2)->base + _s_48689);
    _2 = (object)SEQ_PTR(_25077);
    _s_48689 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_48689)){
        _s_48689 = (object)DBL_PTR(_s_48689)->dbl;
    }
    _25077 = NOVALUE;

    /** symtab.e:1258		end while*/
    goto L1; // [145] 22
L2: 

    /** symtab.e:1259	end procedure*/
    DeRef(_25072);
    _25072 = NOVALUE;
    DeRef(_25067);
    _25067 = NOVALUE;
    return;
    ;
}


object _53sym_name(object _sym_48728)
{
    object _25080 = NOVALUE;
    object _25079 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48728)) {
        _1 = (object)(DBL_PTR(_sym_48728)->dbl);
        DeRefDS(_sym_48728);
        _sym_48728 = _1;
    }

    /** symtab.e:1262		return SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25079 = (object)*(((s1_ptr)_2)->base + _sym_48728);
    _2 = (object)SEQ_PTR(_25079);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _25080 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _25080 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _25079 = NOVALUE;
    Ref(_25080);
    return _25080;
    ;
}


object _53sym_token(object _sym_48736)
{
    object _25082 = NOVALUE;
    object _25081 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48736)) {
        _1 = (object)(DBL_PTR(_sym_48736)->dbl);
        DeRefDS(_sym_48736);
        _sym_48736 = _1;
    }

    /** symtab.e:1266		return SymTab[sym][S_TOKEN]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25081 = (object)*(((s1_ptr)_2)->base + _sym_48736);
    _2 = (object)SEQ_PTR(_25081);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _25082 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _25082 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _25081 = NOVALUE;
    Ref(_25082);
    return _25082;
    ;
}


object _53sym_scope(object _sym_48744)
{
    object _25084 = NOVALUE;
    object _25083 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48744)) {
        _1 = (object)(DBL_PTR(_sym_48744)->dbl);
        DeRefDS(_sym_48744);
        _sym_48744 = _1;
    }

    /** symtab.e:1270		return SymTab[sym][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25083 = (object)*(((s1_ptr)_2)->base + _sym_48744);
    _2 = (object)SEQ_PTR(_25083);
    _25084 = (object)*(((s1_ptr)_2)->base + 4);
    _25083 = NOVALUE;
    Ref(_25084);
    return _25084;
    ;
}


object _53sym_mode(object _sym_48752)
{
    object _25086 = NOVALUE;
    object _25085 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48752)) {
        _1 = (object)(DBL_PTR(_sym_48752)->dbl);
        DeRefDS(_sym_48752);
        _sym_48752 = _1;
    }

    /** symtab.e:1274		return SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25085 = (object)*(((s1_ptr)_2)->base + _sym_48752);
    _2 = (object)SEQ_PTR(_25085);
    _25086 = (object)*(((s1_ptr)_2)->base + 3);
    _25085 = NOVALUE;
    Ref(_25086);
    return _25086;
    ;
}


object _53sym_obj(object _sym_48760)
{
    object _25088 = NOVALUE;
    object _25087 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48760)) {
        _1 = (object)(DBL_PTR(_sym_48760)->dbl);
        DeRefDS(_sym_48760);
        _sym_48760 = _1;
    }

    /** symtab.e:1278		return SymTab[sym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25087 = (object)*(((s1_ptr)_2)->base + _sym_48760);
    _2 = (object)SEQ_PTR(_25087);
    _25088 = (object)*(((s1_ptr)_2)->base + 1);
    _25087 = NOVALUE;
    Ref(_25088);
    return _25088;
    ;
}


object _53sym_next(object _sym_48768)
{
    object _25090 = NOVALUE;
    object _25089 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1282		return SymTab[sym][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25089 = (object)*(((s1_ptr)_2)->base + _sym_48768);
    _2 = (object)SEQ_PTR(_25089);
    _25090 = (object)*(((s1_ptr)_2)->base + 2);
    _25089 = NOVALUE;
    Ref(_25090);
    return _25090;
    ;
}


object _53sym_block(object _sym_48776)
{
    object _25092 = NOVALUE;
    object _25091 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1286		return SymTab[sym][S_BLOCK]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25091 = (object)*(((s1_ptr)_2)->base + _sym_48776);
    _2 = (object)SEQ_PTR(_25091);
    if (!IS_ATOM_INT(_12S_BLOCK_19884)){
        _25092 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_BLOCK_19884)->dbl));
    }
    else{
        _25092 = (object)*(((s1_ptr)_2)->base + _12S_BLOCK_19884);
    }
    _25091 = NOVALUE;
    Ref(_25092);
    return _25092;
    ;
}


object _53sym_next_in_block(object _sym_48784)
{
    object _25094 = NOVALUE;
    object _25093 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1290		return SymTab[sym][S_NEXT_IN_BLOCK]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25093 = (object)*(((s1_ptr)_2)->base + _sym_48784);
    _2 = (object)SEQ_PTR(_25093);
    if (!IS_ATOM_INT(_12S_NEXT_IN_BLOCK_19856)){
        _25094 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NEXT_IN_BLOCK_19856)->dbl));
    }
    else{
        _25094 = (object)*(((s1_ptr)_2)->base + _12S_NEXT_IN_BLOCK_19856);
    }
    _25093 = NOVALUE;
    Ref(_25094);
    return _25094;
    ;
}


object _53sym_usage(object _sym_48792)
{
    object _25096 = NOVALUE;
    object _25095 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1294		return SymTab[sym][S_USAGE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25095 = (object)*(((s1_ptr)_2)->base + _sym_48792);
    _2 = (object)SEQ_PTR(_25095);
    _25096 = (object)*(((s1_ptr)_2)->base + 5);
    _25095 = NOVALUE;
    Ref(_25096);
    return _25096;
    ;
}



// 0xD4BA85FF
