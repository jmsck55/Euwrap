// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _14find_first_wildcard(object _name_9783, object _from_9784)
{
    object _asterisk_at_9785 = NOVALUE;
    object _question_at_9787 = NOVALUE;
    object _first_wildcard_at_9789 = NOVALUE;
    object _5443 = NOVALUE;
    object _5442 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:247		integer asterisk_at = eu:find('*', name, from)*/
    _asterisk_at_9785 = find_from(42, _name_9783, _from_9784);

    /** filesys.e:248		integer question_at = eu:find('?', name, from)*/
    _question_at_9787 = find_from(63, _name_9783, _from_9784);

    /** filesys.e:249		integer first_wildcard_at = asterisk_at*/
    _first_wildcard_at_9789 = _asterisk_at_9785;

    /** filesys.e:250		if asterisk_at or question_at then*/
    if (_asterisk_at_9785 != 0) {
        goto L1; // [26] 35
    }
    if (_question_at_9787 == 0)
    {
        goto L2; // [31] 56
    }
    else{
    }
L1: 

    /** filesys.e:253			if question_at and question_at < asterisk_at then*/
    if (_question_at_9787 == 0) {
        goto L3; // [37] 55
    }
    _5443 = (_question_at_9787 < _asterisk_at_9785);
    if (_5443 == 0)
    {
        DeRef(_5443);
        _5443 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        DeRef(_5443);
        _5443 = NOVALUE;
    }

    /** filesys.e:254				first_wildcard_at = question_at*/
    _first_wildcard_at_9789 = _question_at_9787;
L3: 
L2: 

    /** filesys.e:257		return first_wildcard_at*/
    DeRefDS(_name_9783);
    return _first_wildcard_at_9789;
    ;
}


object _14dir(object _name_9797)
{
    object _dir_data_9798 = NOVALUE;
    object _data_9799 = NOVALUE;
    object _the_name_9800 = NOVALUE;
    object _the_dir_9801 = NOVALUE;
    object _the_suffix_9802 = NOVALUE;
    object _idx_9803 = NOVALUE;
    object _first_wildcard_at_9804 = NOVALUE;
    object _next_slash_9819 = NOVALUE;
    object _wild_data_9851 = NOVALUE;
    object _interim_dir_9855 = NOVALUE;
    object _dir_results_9859 = NOVALUE;
    object _5486 = NOVALUE;
    object _5485 = NOVALUE;
    object _5484 = NOVALUE;
    object _5482 = NOVALUE;
    object _5481 = NOVALUE;
    object _5480 = NOVALUE;
    object _5478 = NOVALUE;
    object _5476 = NOVALUE;
    object _5475 = NOVALUE;
    object _5474 = NOVALUE;
    object _5473 = NOVALUE;
    object _5471 = NOVALUE;
    object _5469 = NOVALUE;
    object _5468 = NOVALUE;
    object _5467 = NOVALUE;
    object _5466 = NOVALUE;
    object _5465 = NOVALUE;
    object _5464 = NOVALUE;
    object _5461 = NOVALUE;
    object _5460 = NOVALUE;
    object _5458 = NOVALUE;
    object _5456 = NOVALUE;
    object _5455 = NOVALUE;
    object _5448 = NOVALUE;
    object _5446 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** filesys.e:358		ifdef WINDOWS then*/

    /** filesys.e:361			object dir_data, data, the_name, the_dir, the_suffix = 0*/
    DeRef(_the_suffix_9802);
    _the_suffix_9802 = 0;

    /** filesys.e:362			integer idx*/

    /** filesys.e:365			integer first_wildcard_at = find_first_wildcard( name )*/
    RefDS(_name_9797);
    _first_wildcard_at_9804 = _14find_first_wildcard(_name_9797, 1);
    if (!IS_ATOM_INT(_first_wildcard_at_9804)) {
        _1 = (object)(DBL_PTR(_first_wildcard_at_9804)->dbl);
        DeRefDS(_first_wildcard_at_9804);
        _first_wildcard_at_9804 = _1;
    }

    /** filesys.e:366			if first_wildcard_at = 0 then*/
    if (_first_wildcard_at_9804 != 0)
    goto L1; // [23] 38

    /** filesys.e:367				return machine_func(M_DIR, name)*/
    _5446 = machine(22, _name_9797);
    DeRefDS(_name_9797);
    DeRef(_dir_data_9798);
    DeRef(_data_9799);
    DeRef(_the_name_9800);
    DeRef(_the_dir_9801);
    return _5446;
L1: 

    /** filesys.e:371			if first_wildcard_at then*/
    if (_first_wildcard_at_9804 == 0)
    {
        goto L2; // [40] 56
    }
    else{
    }

    /** filesys.e:372				idx = search:rfind(SLASH, name, first_wildcard_at )*/
    RefDS(_name_9797);
    _idx_9803 = _20rfind(47, _name_9797, _first_wildcard_at_9804);
    if (!IS_ATOM_INT(_idx_9803)) {
        _1 = (object)(DBL_PTR(_idx_9803)->dbl);
        DeRefDS(_idx_9803);
        _idx_9803 = _1;
    }
    goto L3; // [53] 70
L2: 

    /** filesys.e:374				idx = search:rfind(SLASH, name )*/
    if (IS_SEQUENCE(_name_9797)){
            _5448 = SEQ_PTR(_name_9797)->length;
    }
    else {
        _5448 = 1;
    }
    RefDS(_name_9797);
    _idx_9803 = _20rfind(47, _name_9797, _5448);
    _5448 = NOVALUE;
    if (!IS_ATOM_INT(_idx_9803)) {
        _1 = (object)(DBL_PTR(_idx_9803)->dbl);
        DeRefDS(_idx_9803);
        _idx_9803 = _1;
    }
L3: 

    /** filesys.e:377			if idx = 0 then*/
    if (_idx_9803 != 0)
    goto L4; // [74] 91

    /** filesys.e:378				the_dir = "."*/
    RefDS(_5451);
    DeRef(_the_dir_9801);
    _the_dir_9801 = _5451;

    /** filesys.e:379				the_name = name*/
    RefDS(_name_9797);
    DeRef(_the_name_9800);
    _the_name_9800 = _name_9797;
    goto L5; // [88] 187
L4: 

    /** filesys.e:383				the_dir = name[1 .. idx]*/
    rhs_slice_target = (object_ptr)&_the_dir_9801;
    RHS_Slice(_name_9797, 1, _idx_9803);

    /** filesys.e:384				integer next_slash = 0*/
    _next_slash_9819 = 0;

    /** filesys.e:385				if first_wildcard_at then*/
    if (_first_wildcard_at_9804 == 0)
    {
        goto L6; // [105] 116
    }
    else{
    }

    /** filesys.e:386					next_slash = eu:find( SLASH, name, first_wildcard_at )*/
    _next_slash_9819 = find_from(47, _name_9797, _first_wildcard_at_9804);
L6: 

    /** filesys.e:389				if next_slash then*/
    if (_next_slash_9819 == 0)
    {
        goto L7; // [118] 164
    }
    else{
    }

    /** filesys.e:390					first_wildcard_at = find_first_wildcard( name, next_slash )*/
    RefDS(_name_9797);
    _first_wildcard_at_9804 = _14find_first_wildcard(_name_9797, _next_slash_9819);
    if (!IS_ATOM_INT(_first_wildcard_at_9804)) {
        _1 = (object)(DBL_PTR(_first_wildcard_at_9804)->dbl);
        DeRefDS(_first_wildcard_at_9804);
        _first_wildcard_at_9804 = _1;
    }

    /** filesys.e:391					if first_wildcard_at then*/
    if (_first_wildcard_at_9804 == 0)
    {
        goto L8; // [132] 184
    }
    else{
    }

    /** filesys.e:392						the_name = name[idx+1..next_slash-1]*/
    _5455 = _idx_9803 + 1;
    if (_5455 > MAXINT){
        _5455 = NewDouble((eudouble)_5455);
    }
    _5456 = _next_slash_9819 - 1;
    rhs_slice_target = (object_ptr)&_the_name_9800;
    RHS_Slice(_name_9797, _5455, _5456);

    /** filesys.e:393						the_suffix = name[next_slash..$]*/
    if (IS_SEQUENCE(_name_9797)){
            _5458 = SEQ_PTR(_name_9797)->length;
    }
    else {
        _5458 = 1;
    }
    rhs_slice_target = (object_ptr)&_the_suffix_9802;
    RHS_Slice(_name_9797, _next_slash_9819, _5458);
    goto L8; // [161] 184
L7: 

    /** filesys.e:396					the_name = name[idx+1 .. $]*/
    _5460 = _idx_9803 + 1;
    if (_5460 > MAXINT){
        _5460 = NewDouble((eudouble)_5460);
    }
    if (IS_SEQUENCE(_name_9797)){
            _5461 = SEQ_PTR(_name_9797)->length;
    }
    else {
        _5461 = 1;
    }
    rhs_slice_target = (object_ptr)&_the_name_9800;
    RHS_Slice(_name_9797, _5460, _5461);

    /** filesys.e:397					the_suffix = 0*/
    DeRef(_the_suffix_9802);
    _the_suffix_9802 = 0;
L8: 
L5: 

    /** filesys.e:403			dir_data = dir( the_dir )*/
    Ref(_the_dir_9801);
    _0 = _dir_data_9798;
    _dir_data_9798 = _14dir(_the_dir_9801);
    DeRef(_0);

    /** filesys.e:406			if atom(dir_data) then*/
    _5464 = IS_ATOM(_dir_data_9798);
    if (_5464 == 0)
    {
        _5464 = NOVALUE;
        goto L9; // [200] 210
    }
    else{
        _5464 = NOVALUE;
    }

    /** filesys.e:407				return dir_data*/
    DeRefDS(_name_9797);
    DeRef(_data_9799);
    DeRef(_the_name_9800);
    DeRef(_the_dir_9801);
    DeRef(_the_suffix_9802);
    DeRef(_5455);
    _5455 = NOVALUE;
    DeRef(_5460);
    _5460 = NOVALUE;
    DeRef(_5446);
    _5446 = NOVALUE;
    DeRef(_5456);
    _5456 = NOVALUE;
    return _dir_data_9798;
L9: 

    /** filesys.e:412			data = {}*/
    RefDS(_5);
    DeRef(_data_9799);
    _data_9799 = _5;

    /** filesys.e:413			for i = 1 to length(dir_data) do*/
    if (IS_SEQUENCE(_dir_data_9798)){
            _5465 = SEQ_PTR(_dir_data_9798)->length;
    }
    else {
        _5465 = 1;
    }
    {
        object _i_9838;
        _i_9838 = 1;
LA: 
        if (_i_9838 > _5465){
            goto LB; // [220] 265
        }

        /** filesys.e:414				if wildcard:is_match(the_name, dir_data[i][1]) then*/
        _2 = (object)SEQ_PTR(_dir_data_9798);
        _5466 = (object)*(((s1_ptr)_2)->base + _i_9838);
        _2 = (object)SEQ_PTR(_5466);
        _5467 = (object)*(((s1_ptr)_2)->base + 1);
        _5466 = NOVALUE;
        Ref(_the_name_9800);
        Ref(_5467);
        _5468 = _11is_match(_the_name_9800, _5467);
        _5467 = NOVALUE;
        if (_5468 == 0) {
            DeRef(_5468);
            _5468 = NOVALUE;
            goto LC; // [244] 258
        }
        else {
            if (!IS_ATOM_INT(_5468) && DBL_PTR(_5468)->dbl == 0.0){
                DeRef(_5468);
                _5468 = NOVALUE;
                goto LC; // [244] 258
            }
            DeRef(_5468);
            _5468 = NOVALUE;
        }
        DeRef(_5468);
        _5468 = NOVALUE;

        /** filesys.e:415						data = append(data, dir_data[i])*/
        _2 = (object)SEQ_PTR(_dir_data_9798);
        _5469 = (object)*(((s1_ptr)_2)->base + _i_9838);
        Ref(_5469);
        Append(&_data_9799, _data_9799, _5469);
        _5469 = NOVALUE;
LC: 

        /** filesys.e:417			end for*/
        _i_9838 = _i_9838 + 1;
        goto LA; // [260] 227
LB: 
        ;
    }

    /** filesys.e:419			if not length(data) then*/
    if (IS_SEQUENCE(_data_9799)){
            _5471 = SEQ_PTR(_data_9799)->length;
    }
    else {
        _5471 = 1;
    }
    if (_5471 != 0)
    goto LD; // [270] 280
    _5471 = NOVALUE;

    /** filesys.e:421				return -1*/
    DeRefDS(_name_9797);
    DeRef(_dir_data_9798);
    DeRef(_data_9799);
    DeRef(_the_name_9800);
    DeRef(_the_dir_9801);
    DeRef(_the_suffix_9802);
    DeRef(_5455);
    _5455 = NOVALUE;
    DeRef(_5460);
    _5460 = NOVALUE;
    DeRef(_5446);
    _5446 = NOVALUE;
    DeRef(_5456);
    _5456 = NOVALUE;
    return -1;
LD: 

    /** filesys.e:424			if sequence( the_suffix ) then*/
    _5473 = IS_SEQUENCE(_the_suffix_9802);
    if (_5473 == 0)
    {
        _5473 = NOVALUE;
        goto LE; // [285] 406
    }
    else{
        _5473 = NOVALUE;
    }

    /** filesys.e:425				sequence wild_data = {}*/
    RefDS(_5);
    DeRef(_wild_data_9851);
    _wild_data_9851 = _5;

    /** filesys.e:426				for i = 1 to length( dir_data ) do*/
    if (IS_SEQUENCE(_dir_data_9798)){
            _5474 = SEQ_PTR(_dir_data_9798)->length;
    }
    else {
        _5474 = 1;
    }
    {
        object _i_9853;
        _i_9853 = 1;
LF: 
        if (_i_9853 > _5474){
            goto L10; // [300] 399
        }

        /** filesys.e:427					sequence interim_dir = the_dir & dir_data[i][D_NAME] & SLASH*/
        _2 = (object)SEQ_PTR(_dir_data_9798);
        _5475 = (object)*(((s1_ptr)_2)->base + _i_9853);
        _2 = (object)SEQ_PTR(_5475);
        _5476 = (object)*(((s1_ptr)_2)->base + 1);
        _5475 = NOVALUE;
        {
            object concat_list[3];

            concat_list[0] = 47;
            concat_list[1] = _5476;
            concat_list[2] = _the_dir_9801;
            Concat_N((object_ptr)&_interim_dir_9855, concat_list, 3);
        }
        _5476 = NOVALUE;

        /** filesys.e:428					object dir_results = dir( interim_dir & the_suffix )*/
        if (IS_SEQUENCE(_interim_dir_9855) && IS_ATOM(_the_suffix_9802)) {
            Ref(_the_suffix_9802);
            Append(&_5478, _interim_dir_9855, _the_suffix_9802);
        }
        else if (IS_ATOM(_interim_dir_9855) && IS_SEQUENCE(_the_suffix_9802)) {
        }
        else {
            Concat((object_ptr)&_5478, _interim_dir_9855, _the_suffix_9802);
        }
        _0 = _dir_results_9859;
        _dir_results_9859 = _14dir(_5478);
        DeRef(_0);
        _5478 = NOVALUE;

        /** filesys.e:429					if sequence( dir_results ) then*/
        _5480 = IS_SEQUENCE(_dir_results_9859);
        if (_5480 == 0)
        {
            _5480 = NOVALUE;
            goto L11; // [338] 390
        }
        else{
            _5480 = NOVALUE;
        }

        /** filesys.e:430						for j = 1 to length( dir_results ) do*/
        if (IS_SEQUENCE(_dir_results_9859)){
                _5481 = SEQ_PTR(_dir_results_9859)->length;
        }
        else {
            _5481 = 1;
        }
        {
            object _j_9865;
            _j_9865 = 1;
L12: 
            if (_j_9865 > _5481){
                goto L13; // [346] 383
            }

            /** filesys.e:431							dir_results[j][D_NAME] = interim_dir & dir_results[j][D_NAME]*/
            _2 = (object)SEQ_PTR(_dir_results_9859);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _dir_results_9859 = MAKE_SEQ(_2);
            }
            _3 = (object)(_j_9865 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(_dir_results_9859);
            _5484 = (object)*(((s1_ptr)_2)->base + _j_9865);
            _2 = (object)SEQ_PTR(_5484);
            _5485 = (object)*(((s1_ptr)_2)->base + 1);
            _5484 = NOVALUE;
            if (IS_SEQUENCE(_interim_dir_9855) && IS_ATOM(_5485)) {
                Ref(_5485);
                Append(&_5486, _interim_dir_9855, _5485);
            }
            else if (IS_ATOM(_interim_dir_9855) && IS_SEQUENCE(_5485)) {
            }
            else {
                Concat((object_ptr)&_5486, _interim_dir_9855, _5485);
            }
            _5485 = NOVALUE;
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 1);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _5486;
            if( _1 != _5486 ){
                DeRef(_1);
            }
            _5486 = NOVALUE;
            _5482 = NOVALUE;

            /** filesys.e:432						end for*/
            _j_9865 = _j_9865 + 1;
            goto L12; // [378] 353
L13: 
            ;
        }

        /** filesys.e:433						wild_data &= dir_results*/
        if (IS_SEQUENCE(_wild_data_9851) && IS_ATOM(_dir_results_9859)) {
            Ref(_dir_results_9859);
            Append(&_wild_data_9851, _wild_data_9851, _dir_results_9859);
        }
        else if (IS_ATOM(_wild_data_9851) && IS_SEQUENCE(_dir_results_9859)) {
        }
        else {
            Concat((object_ptr)&_wild_data_9851, _wild_data_9851, _dir_results_9859);
        }
L11: 
        DeRef(_interim_dir_9855);
        _interim_dir_9855 = NOVALUE;
        DeRef(_dir_results_9859);
        _dir_results_9859 = NOVALUE;

        /** filesys.e:435				end for*/
        _i_9853 = _i_9853 + 1;
        goto LF; // [394] 307
L10: 
        ;
    }

    /** filesys.e:436				return wild_data*/
    DeRefDS(_name_9797);
    DeRef(_dir_data_9798);
    DeRef(_data_9799);
    DeRef(_the_name_9800);
    DeRef(_the_dir_9801);
    DeRef(_the_suffix_9802);
    DeRef(_5455);
    _5455 = NOVALUE;
    DeRef(_5460);
    _5460 = NOVALUE;
    DeRef(_5446);
    _5446 = NOVALUE;
    DeRef(_5456);
    _5456 = NOVALUE;
    return _wild_data_9851;
LE: 
    DeRef(_wild_data_9851);
    _wild_data_9851 = NOVALUE;

    /** filesys.e:439			return data*/
    DeRefDS(_name_9797);
    DeRef(_dir_data_9798);
    DeRef(_the_name_9800);
    DeRef(_the_dir_9801);
    DeRef(_the_suffix_9802);
    DeRef(_5455);
    _5455 = NOVALUE;
    DeRef(_5460);
    _5460 = NOVALUE;
    DeRef(_5446);
    _5446 = NOVALUE;
    DeRef(_5456);
    _5456 = NOVALUE;
    return _data_9799;
    ;
}


object _14current_dir()
{
    object _5488 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:465		return machine_func(M_CURRENT_DIR, 0)*/
    _5488 = machine(23, 0);
    return _5488;
    ;
}


object _14chdir(object _newdir_9878)
{
    object _5489 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:501		return machine_func(M_CHDIR, newdir)*/
    _5489 = machine(63, _newdir_9878);
    DeRefDS(_newdir_9878);
    return _5489;
    ;
}


object _14delete_file(object _name_10010)
{
    object _pfilename_10011 = NOVALUE;
    object _success_10013 = NOVALUE;
    object _5566 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:802		atom pfilename = machine:allocate_string(name)*/
    RefDS(_name_10010);
    _0 = _pfilename_10011;
    _pfilename_10011 = _4allocate_string(_name_10010, 0);
    DeRef(_0);

    /** filesys.e:803		integer success = c_func(xDeleteFile, {pfilename})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_pfilename_10011);
    ((intptr_t*)_2)[1] = _pfilename_10011;
    _5566 = MAKE_SEQ(_1);
    _success_10013 = call_c(1, _14xDeleteFile_9729, _5566);
    DeRefDS(_5566);
    _5566 = NOVALUE;
    if (!IS_ATOM_INT(_success_10013)) {
        _1 = (object)(DBL_PTR(_success_10013)->dbl);
        DeRefDS(_success_10013);
        _success_10013 = _1;
    }

    /** filesys.e:805		ifdef UNIX then*/

    /** filesys.e:806			success = not success*/
    _success_10013 = (_success_10013 == 0);

    /** filesys.e:809		machine:free(pfilename)*/
    Ref(_pfilename_10011);
    _4free(_pfilename_10011);

    /** filesys.e:811		return success*/
    DeRefDS(_name_10010);
    DeRef(_pfilename_10011);
    return _success_10013;
    ;
}


object _14curdir(object _drive_id_10019)
{
    object _lCurDir_10020 = NOVALUE;
    object _current_dir_inlined_current_dir_at_6_10022 = NOVALUE;
    object _5570 = NOVALUE;
    object _5569 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:847		ifdef not LINUX then*/

    /** filesys.e:862	    lCurDir = current_dir()*/

    /** filesys.e:465		return machine_func(M_CURRENT_DIR, 0)*/
    DeRefi(_lCurDir_10020);
    _lCurDir_10020 = machine(23, 0);

    /** filesys.e:863		ifdef not LINUX then*/

    /** filesys.e:870		if (lCurDir[$] != SLASH) then*/
    if (IS_SEQUENCE(_lCurDir_10020)){
            _5569 = SEQ_PTR(_lCurDir_10020)->length;
    }
    else {
        _5569 = 1;
    }
    _2 = (object)SEQ_PTR(_lCurDir_10020);
    _5570 = (object)*(((s1_ptr)_2)->base + _5569);
    if (_5570 == 47)
    goto L1; // [27] 38

    /** filesys.e:871			lCurDir &= SLASH*/
    Append(&_lCurDir_10020, _lCurDir_10020, 47);
L1: 

    /** filesys.e:874		return lCurDir*/
    _5570 = NOVALUE;
    return _lCurDir_10020;
    ;
}


object _14pathinfo(object _path_10153, object _std_slash_10154)
{
    object _slash_10155 = NOVALUE;
    object _period_10156 = NOVALUE;
    object _ch_10157 = NOVALUE;
    object _dir_name_10158 = NOVALUE;
    object _file_name_10159 = NOVALUE;
    object _file_ext_10160 = NOVALUE;
    object _file_full_10161 = NOVALUE;
    object _drive_id_10162 = NOVALUE;
    object _from_slash_10194 = NOVALUE;
    object _5672 = NOVALUE;
    object _5665 = NOVALUE;
    object _5664 = NOVALUE;
    object _5661 = NOVALUE;
    object _5660 = NOVALUE;
    object _5658 = NOVALUE;
    object _5657 = NOVALUE;
    object _5654 = NOVALUE;
    object _5652 = NOVALUE;
    object _5651 = NOVALUE;
    object _5650 = NOVALUE;
    object _5649 = NOVALUE;
    object _5647 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1196		dir_name  = ""*/
    RefDS(_5);
    DeRef(_dir_name_10158);
    _dir_name_10158 = _5;

    /** filesys.e:1197		file_name = ""*/
    RefDS(_5);
    DeRef(_file_name_10159);
    _file_name_10159 = _5;

    /** filesys.e:1198		file_ext  = ""*/
    RefDS(_5);
    DeRef(_file_ext_10160);
    _file_ext_10160 = _5;

    /** filesys.e:1199		file_full = ""*/
    RefDS(_5);
    DeRef(_file_full_10161);
    _file_full_10161 = _5;

    /** filesys.e:1200		drive_id  = ""*/
    RefDS(_5);
    DeRef(_drive_id_10162);
    _drive_id_10162 = _5;

    /** filesys.e:1202		slash = 0*/
    _slash_10155 = 0;

    /** filesys.e:1203		period = 0*/
    _period_10156 = 0;

    /** filesys.e:1205		for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_10153)){
            _5647 = SEQ_PTR(_path_10153)->length;
    }
    else {
        _5647 = 1;
    }
    {
        object _i_10164;
        _i_10164 = _5647;
L1: 
        if (_i_10164 < 1){
            goto L2; // [55] 122
        }

        /** filesys.e:1206			ch = path[i]*/
        _2 = (object)SEQ_PTR(_path_10153);
        _ch_10157 = (object)*(((s1_ptr)_2)->base + _i_10164);
        if (!IS_ATOM_INT(_ch_10157))
        _ch_10157 = (object)DBL_PTR(_ch_10157)->dbl;

        /** filesys.e:1207			if period = 0 and ch = '.' then*/
        _5649 = (_period_10156 == 0);
        if (_5649 == 0) {
            goto L3; // [74] 94
        }
        _5651 = (_ch_10157 == 46);
        if (_5651 == 0)
        {
            DeRef(_5651);
            _5651 = NOVALUE;
            goto L3; // [83] 94
        }
        else{
            DeRef(_5651);
            _5651 = NOVALUE;
        }

        /** filesys.e:1208				period = i*/
        _period_10156 = _i_10164;
        goto L4; // [91] 115
L3: 

        /** filesys.e:1209			elsif eu:find(ch, SLASHES) then*/
        _5652 = find_from(_ch_10157, _14SLASHES_9753, 1);
        if (_5652 == 0)
        {
            _5652 = NOVALUE;
            goto L5; // [101] 114
        }
        else{
            _5652 = NOVALUE;
        }

        /** filesys.e:1210				slash = i*/
        _slash_10155 = _i_10164;

        /** filesys.e:1211				exit*/
        goto L2; // [111] 122
L5: 
L4: 

        /** filesys.e:1213		end for*/
        _i_10164 = _i_10164 + -1;
        goto L1; // [117] 62
L2: 
        ;
    }

    /** filesys.e:1215		if slash > 0 then*/
    if (_slash_10155 <= 0)
    goto L6; // [124] 142

    /** filesys.e:1216			dir_name = path[1..slash-1]*/
    _5654 = _slash_10155 - 1;
    rhs_slice_target = (object_ptr)&_dir_name_10158;
    RHS_Slice(_path_10153, 1, _5654);

    /** filesys.e:1218			ifdef not UNIX then*/
L6: 

    /** filesys.e:1226		if period > 0 then*/
    if (_period_10156 <= 0)
    goto L7; // [144] 188

    /** filesys.e:1227			file_name = path[slash+1..period-1]*/
    _5657 = _slash_10155 + 1;
    if (_5657 > MAXINT){
        _5657 = NewDouble((eudouble)_5657);
    }
    _5658 = _period_10156 - 1;
    rhs_slice_target = (object_ptr)&_file_name_10159;
    RHS_Slice(_path_10153, _5657, _5658);

    /** filesys.e:1228			file_ext = path[period+1..$]*/
    _5660 = _period_10156 + 1;
    if (_5660 > MAXINT){
        _5660 = NewDouble((eudouble)_5660);
    }
    if (IS_SEQUENCE(_path_10153)){
            _5661 = SEQ_PTR(_path_10153)->length;
    }
    else {
        _5661 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_ext_10160;
    RHS_Slice(_path_10153, _5660, _5661);

    /** filesys.e:1229			file_full = file_name & '.' & file_ext*/
    {
        object concat_list[3];

        concat_list[0] = _file_ext_10160;
        concat_list[1] = 46;
        concat_list[2] = _file_name_10159;
        Concat_N((object_ptr)&_file_full_10161, concat_list, 3);
    }
    goto L8; // [185] 210
L7: 

    /** filesys.e:1231			file_name = path[slash+1..$]*/
    _5664 = _slash_10155 + 1;
    if (_5664 > MAXINT){
        _5664 = NewDouble((eudouble)_5664);
    }
    if (IS_SEQUENCE(_path_10153)){
            _5665 = SEQ_PTR(_path_10153)->length;
    }
    else {
        _5665 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_name_10159;
    RHS_Slice(_path_10153, _5664, _5665);

    /** filesys.e:1232			file_full = file_name*/
    RefDS(_file_name_10159);
    DeRef(_file_full_10161);
    _file_full_10161 = _file_name_10159;
L8: 

    /** filesys.e:1235		if std_slash != 0 then*/
    if (_std_slash_10154 == 0)
    goto L9; // [212] 278

    /** filesys.e:1236			if std_slash < 0 then*/
    if (_std_slash_10154 >= 0)
    goto LA; // [218] 254

    /** filesys.e:1237				std_slash = SLASH*/
    _std_slash_10154 = 47;

    /** filesys.e:1238				ifdef UNIX then*/

    /** filesys.e:1239				sequence from_slash = "\\"*/
    RefDS(_1154);
    DeRefi(_from_slash_10194);
    _from_slash_10194 = _1154;

    /** filesys.e:1243				dir_name = search:match_replace(from_slash, dir_name, std_slash)*/
    RefDS(_from_slash_10194);
    RefDS(_dir_name_10158);
    _0 = _dir_name_10158;
    _dir_name_10158 = _20match_replace(_from_slash_10194, _dir_name_10158, 47, 0);
    DeRefDS(_0);
    DeRefDSi(_from_slash_10194);
    _from_slash_10194 = NOVALUE;
    goto LB; // [251] 277
LA: 

    /** filesys.e:1245				dir_name = search:match_replace("\\", dir_name, std_slash)*/
    RefDS(_1154);
    RefDS(_dir_name_10158);
    _0 = _dir_name_10158;
    _dir_name_10158 = _20match_replace(_1154, _dir_name_10158, _std_slash_10154, 0);
    DeRefDS(_0);

    /** filesys.e:1246				dir_name = search:match_replace("/", dir_name, std_slash)*/
    RefDS(_5430);
    RefDS(_dir_name_10158);
    _0 = _dir_name_10158;
    _dir_name_10158 = _20match_replace(_5430, _dir_name_10158, _std_slash_10154, 0);
    DeRefDS(_0);
LB: 
L9: 

    /** filesys.e:1250		return {dir_name, file_full, file_name, file_ext, drive_id }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_dir_name_10158);
    ((intptr_t*)_2)[1] = _dir_name_10158;
    RefDS(_file_full_10161);
    ((intptr_t*)_2)[2] = _file_full_10161;
    RefDS(_file_name_10159);
    ((intptr_t*)_2)[3] = _file_name_10159;
    RefDS(_file_ext_10160);
    ((intptr_t*)_2)[4] = _file_ext_10160;
    RefDS(_drive_id_10162);
    ((intptr_t*)_2)[5] = _drive_id_10162;
    _5672 = MAKE_SEQ(_1);
    DeRefDS(_path_10153);
    DeRefDS(_dir_name_10158);
    DeRefDS(_file_name_10159);
    DeRefDS(_file_ext_10160);
    DeRefDS(_file_full_10161);
    DeRefDS(_drive_id_10162);
    DeRef(_5658);
    _5658 = NOVALUE;
    DeRef(_5660);
    _5660 = NOVALUE;
    DeRef(_5664);
    _5664 = NOVALUE;
    DeRef(_5654);
    _5654 = NOVALUE;
    DeRef(_5649);
    _5649 = NOVALUE;
    DeRef(_5657);
    _5657 = NOVALUE;
    return _5672;
    ;
}


object _14dirname(object _path_10202, object _pcd_10203)
{
    object _data_10204 = NOVALUE;
    object _5677 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1279		data = pathinfo(path)*/
    RefDS(_path_10202);
    _0 = _data_10204;
    _data_10204 = _14pathinfo(_path_10202, 0);
    DeRef(_0);

    /** filesys.e:1280		if pcd then*/

    /** filesys.e:1285		return data[1]*/
    _2 = (object)SEQ_PTR(_data_10204);
    _5677 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_5677);
    DeRefDS(_path_10202);
    DeRefDS(_data_10204);
    return _5677;
    ;
}


object _14filebase(object _path_10231)
{
    object _data_10232 = NOVALUE;
    object _5686 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1375		data = pathinfo(path)*/
    RefDS(_path_10231);
    _0 = _data_10232;
    _data_10232 = _14pathinfo(_path_10231, 0);
    DeRef(_0);

    /** filesys.e:1377		return data[3]*/
    _2 = (object)SEQ_PTR(_data_10232);
    _5686 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_5686);
    DeRefDS(_path_10231);
    DeRefDS(_data_10232);
    return _5686;
    ;
}


object _14fileext(object _path_10237)
{
    object _data_10238 = NOVALUE;
    object _5688 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1403		data = pathinfo(path)*/
    RefDS(_path_10237);
    _0 = _data_10238;
    _data_10238 = _14pathinfo(_path_10237, 0);
    DeRef(_0);

    /** filesys.e:1404		return data[4]*/
    _2 = (object)SEQ_PTR(_data_10238);
    _5688 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_5688);
    DeRefDS(_path_10237);
    DeRefDS(_data_10238);
    return _5688;
    ;
}


object _14defaultext(object _path_10249, object _defext_10250)
{
    object _5703 = NOVALUE;
    object _5700 = NOVALUE;
    object _5698 = NOVALUE;
    object _5697 = NOVALUE;
    object _5696 = NOVALUE;
    object _5694 = NOVALUE;
    object _5693 = NOVALUE;
    object _5691 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1455		if length(defext) = 0 then*/
    _5691 = 3;

    /** filesys.e:1459		for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_10249)){
            _5693 = SEQ_PTR(_path_10249)->length;
    }
    else {
        _5693 = 1;
    }
    {
        object _i_10255;
        _i_10255 = _5693;
L1: 
        if (_i_10255 < 1){
            goto L2; // [26] 95
        }

        /** filesys.e:1460			if path[i] = '.' then*/
        _2 = (object)SEQ_PTR(_path_10249);
        _5694 = (object)*(((s1_ptr)_2)->base + _i_10255);
        if (binary_op_a(NOTEQ, _5694, 46)){
            _5694 = NOVALUE;
            goto L3; // [39] 50
        }
        _5694 = NOVALUE;

        /** filesys.e:1462				return path*/
        DeRefDSi(_defext_10250);
        return _path_10249;
L3: 

        /** filesys.e:1464			if find(path[i], SLASHES) then*/
        _2 = (object)SEQ_PTR(_path_10249);
        _5696 = (object)*(((s1_ptr)_2)->base + _i_10255);
        _5697 = find_from(_5696, _14SLASHES_9753, 1);
        _5696 = NOVALUE;
        if (_5697 == 0)
        {
            _5697 = NOVALUE;
            goto L4; // [61] 88
        }
        else{
            _5697 = NOVALUE;
        }

        /** filesys.e:1465				if i = length(path) then*/
        if (IS_SEQUENCE(_path_10249)){
                _5698 = SEQ_PTR(_path_10249)->length;
        }
        else {
            _5698 = 1;
        }
        if (_i_10255 != _5698)
        goto L2; // [69] 95

        /** filesys.e:1467					return path*/
        DeRefDSi(_defext_10250);
        return _path_10249;
        goto L5; // [79] 87

        /** filesys.e:1470					exit*/
        goto L2; // [84] 95
L5: 
L4: 

        /** filesys.e:1473		end for*/
        _i_10255 = _i_10255 + -1;
        goto L1; // [90] 33
L2: 
        ;
    }

    /** filesys.e:1475		if defext[1] != '.' then*/
    _2 = (object)SEQ_PTR(_defext_10250);
    _5700 = (object)*(((s1_ptr)_2)->base + 1);
    if (_5700 == 46)
    goto L6; // [101] 112

    /** filesys.e:1476			path &= '.'*/
    Append(&_path_10249, _path_10249, 46);
L6: 

    /** filesys.e:1479		return path & defext*/
    Concat((object_ptr)&_5703, _path_10249, _defext_10250);
    DeRefDS(_path_10249);
    DeRefDSi(_defext_10250);
    _5700 = NOVALUE;
    return _5703;
    ;
}


object _14absolute_path(object _filename_10274)
{
    object _5707 = NOVALUE;
    object _5706 = NOVALUE;
    object _5704 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1514		if length(filename) = 0 then*/
    if (IS_SEQUENCE(_filename_10274)){
            _5704 = SEQ_PTR(_filename_10274)->length;
    }
    else {
        _5704 = 1;
    }
    if (_5704 != 0)
    goto L1; // [8] 19

    /** filesys.e:1515			return 0*/
    DeRefDS(_filename_10274);
    return 0;
L1: 

    /** filesys.e:1518		if eu:find(filename[1], SLASHES) then*/
    _2 = (object)SEQ_PTR(_filename_10274);
    _5706 = (object)*(((s1_ptr)_2)->base + 1);
    _5707 = find_from(_5706, _14SLASHES_9753, 1);
    _5706 = NOVALUE;
    if (_5707 == 0)
    {
        _5707 = NOVALUE;
        goto L2; // [30] 40
    }
    else{
        _5707 = NOVALUE;
    }

    /** filesys.e:1519			return 1*/
    DeRefDS(_filename_10274);
    return 1;
L2: 

    /** filesys.e:1522		ifdef WINDOWS then*/

    /** filesys.e:1539		return 0*/
    DeRefDS(_filename_10274);
    return 0;
    ;
}


object _14canonical_path(object _path_in_10294, object _directory_given_10295, object _case_flags_10296)
{
    object _lPath_10297 = NOVALUE;
    object _lPosA_10298 = NOVALUE;
    object _lPosB_10299 = NOVALUE;
    object _lLevel_10300 = NOVALUE;
    object _lHome_10301 = NOVALUE;
    object _wildcard_suffix_10343 = NOVALUE;
    object _first_wildcard_at_10344 = NOVALUE;
    object _last_slash_10347 = NOVALUE;
    object _sl_10400 = NOVALUE;
    object _short_name_10403 = NOVALUE;
    object _correct_name_10406 = NOVALUE;
    object _lower_name_10409 = NOVALUE;
    object _part_10425 = NOVALUE;
    object _list_10429 = NOVALUE;
    object _supplied_name_10432 = NOVALUE;
    object _read_name_10451 = NOVALUE;
    object _read_name_10476 = NOVALUE;
    object _5887 = NOVALUE;
    object _5885 = NOVALUE;
    object _5884 = NOVALUE;
    object _5883 = NOVALUE;
    object _5882 = NOVALUE;
    object _5881 = NOVALUE;
    object _5879 = NOVALUE;
    object _5878 = NOVALUE;
    object _5877 = NOVALUE;
    object _5876 = NOVALUE;
    object _5875 = NOVALUE;
    object _5874 = NOVALUE;
    object _5873 = NOVALUE;
    object _5872 = NOVALUE;
    object _5870 = NOVALUE;
    object _5869 = NOVALUE;
    object _5868 = NOVALUE;
    object _5867 = NOVALUE;
    object _5866 = NOVALUE;
    object _5865 = NOVALUE;
    object _5864 = NOVALUE;
    object _5863 = NOVALUE;
    object _5862 = NOVALUE;
    object _5860 = NOVALUE;
    object _5859 = NOVALUE;
    object _5858 = NOVALUE;
    object _5857 = NOVALUE;
    object _5856 = NOVALUE;
    object _5855 = NOVALUE;
    object _5854 = NOVALUE;
    object _5853 = NOVALUE;
    object _5852 = NOVALUE;
    object _5851 = NOVALUE;
    object _5850 = NOVALUE;
    object _5849 = NOVALUE;
    object _5848 = NOVALUE;
    object _5847 = NOVALUE;
    object _5846 = NOVALUE;
    object _5844 = NOVALUE;
    object _5843 = NOVALUE;
    object _5842 = NOVALUE;
    object _5841 = NOVALUE;
    object _5840 = NOVALUE;
    object _5838 = NOVALUE;
    object _5837 = NOVALUE;
    object _5836 = NOVALUE;
    object _5835 = NOVALUE;
    object _5834 = NOVALUE;
    object _5833 = NOVALUE;
    object _5832 = NOVALUE;
    object _5831 = NOVALUE;
    object _5830 = NOVALUE;
    object _5829 = NOVALUE;
    object _5828 = NOVALUE;
    object _5827 = NOVALUE;
    object _5826 = NOVALUE;
    object _5824 = NOVALUE;
    object _5823 = NOVALUE;
    object _5821 = NOVALUE;
    object _5820 = NOVALUE;
    object _5819 = NOVALUE;
    object _5818 = NOVALUE;
    object _5817 = NOVALUE;
    object _5815 = NOVALUE;
    object _5814 = NOVALUE;
    object _5813 = NOVALUE;
    object _5812 = NOVALUE;
    object _5811 = NOVALUE;
    object _5809 = NOVALUE;
    object _5807 = NOVALUE;
    object _5806 = NOVALUE;
    object _5804 = NOVALUE;
    object _5803 = NOVALUE;
    object _5801 = NOVALUE;
    object _5800 = NOVALUE;
    object _5799 = NOVALUE;
    object _5797 = NOVALUE;
    object _5796 = NOVALUE;
    object _5794 = NOVALUE;
    object _5792 = NOVALUE;
    object _5790 = NOVALUE;
    object _5783 = NOVALUE;
    object _5780 = NOVALUE;
    object _5779 = NOVALUE;
    object _5778 = NOVALUE;
    object _5777 = NOVALUE;
    object _5771 = NOVALUE;
    object _5767 = NOVALUE;
    object _5766 = NOVALUE;
    object _5765 = NOVALUE;
    object _5764 = NOVALUE;
    object _5763 = NOVALUE;
    object _5761 = NOVALUE;
    object _5760 = NOVALUE;
    object _5759 = NOVALUE;
    object _5757 = NOVALUE;
    object _5756 = NOVALUE;
    object _5755 = NOVALUE;
    object _5754 = NOVALUE;
    object _5752 = NOVALUE;
    object _5750 = NOVALUE;
    object _5746 = NOVALUE;
    object _5745 = NOVALUE;
    object _5743 = NOVALUE;
    object _5742 = NOVALUE;
    object _5741 = NOVALUE;
    object _5740 = NOVALUE;
    object _5739 = NOVALUE;
    object _5738 = NOVALUE;
    object _5737 = NOVALUE;
    object _5734 = NOVALUE;
    object _5733 = NOVALUE;
    object _5728 = NOVALUE;
    object _5727 = NOVALUE;
    object _5726 = NOVALUE;
    object _5725 = NOVALUE;
    object _5724 = NOVALUE;
    object _5722 = NOVALUE;
    object _5721 = NOVALUE;
    object _5720 = NOVALUE;
    object _5719 = NOVALUE;
    object _5718 = NOVALUE;
    object _5717 = NOVALUE;
    object _5716 = NOVALUE;
    object _5715 = NOVALUE;
    object _5714 = NOVALUE;
    object _5713 = NOVALUE;
    object _5712 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1607	    sequence lPath = ""*/
    RefDS(_5);
    DeRef(_lPath_10297);
    _lPath_10297 = _5;

    /** filesys.e:1608	    integer lPosA = -1*/
    _lPosA_10298 = -1;

    /** filesys.e:1609	    integer lPosB = -1*/
    _lPosB_10299 = -1;

    /** filesys.e:1610	    sequence lLevel = ""*/
    RefDS(_5);
    DeRefi(_lLevel_10300);
    _lLevel_10300 = _5;

    /** filesys.e:1612	    path_in = path_in*/
    RefDS(_path_in_10294);
    DeRefDS(_path_in_10294);
    _path_in_10294 = _path_in_10294;

    /** filesys.e:1614		ifdef UNIX then*/

    /** filesys.e:1615			lPath = path_in*/
    RefDS(_path_in_10294);
    DeRefDS(_lPath_10297);
    _lPath_10297 = _path_in_10294;

    /** filesys.e:1623	    if (length(lPath) > 2 and lPath[1] = '"' and lPath[$] = '"') then*/
    if (IS_SEQUENCE(_lPath_10297)){
            _5712 = SEQ_PTR(_lPath_10297)->length;
    }
    else {
        _5712 = 1;
    }
    _5713 = (_5712 > 2);
    _5712 = NOVALUE;
    if (_5713 == 0) {
        _5714 = 0;
        goto L1; // [56] 72
    }
    _2 = (object)SEQ_PTR(_lPath_10297);
    _5715 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_5715)) {
        _5716 = (_5715 == 34);
    }
    else {
        _5716 = binary_op(EQUALS, _5715, 34);
    }
    _5715 = NOVALUE;
    if (IS_ATOM_INT(_5716))
    _5714 = (_5716 != 0);
    else
    _5714 = DBL_PTR(_5716)->dbl != 0.0;
L1: 
    if (_5714 == 0) {
        DeRef(_5717);
        _5717 = 0;
        goto L2; // [72] 91
    }
    if (IS_SEQUENCE(_lPath_10297)){
            _5718 = SEQ_PTR(_lPath_10297)->length;
    }
    else {
        _5718 = 1;
    }
    _2 = (object)SEQ_PTR(_lPath_10297);
    _5719 = (object)*(((s1_ptr)_2)->base + _5718);
    if (IS_ATOM_INT(_5719)) {
        _5720 = (_5719 == 34);
    }
    else {
        _5720 = binary_op(EQUALS, _5719, 34);
    }
    _5719 = NOVALUE;
    if (IS_ATOM_INT(_5720))
    _5717 = (_5720 != 0);
    else
    _5717 = DBL_PTR(_5720)->dbl != 0.0;
L2: 
    if (_5717 == 0)
    {
        _5717 = NOVALUE;
        goto L3; // [91] 109
    }
    else{
        _5717 = NOVALUE;
    }

    /** filesys.e:1624	        lPath = lPath[2..$-1]*/
    if (IS_SEQUENCE(_lPath_10297)){
            _5721 = SEQ_PTR(_lPath_10297)->length;
    }
    else {
        _5721 = 1;
    }
    _5722 = _5721 - 1;
    _5721 = NOVALUE;
    rhs_slice_target = (object_ptr)&_lPath_10297;
    RHS_Slice(_lPath_10297, 2, _5722);
L3: 

    /** filesys.e:1628	    if (length(lPath) > 0 and lPath[1] = '~') then*/
    if (IS_SEQUENCE(_lPath_10297)){
            _5724 = SEQ_PTR(_lPath_10297)->length;
    }
    else {
        _5724 = 1;
    }
    _5725 = (_5724 > 0);
    _5724 = NOVALUE;
    if (_5725 == 0) {
        DeRef(_5726);
        _5726 = 0;
        goto L4; // [118] 134
    }
    _2 = (object)SEQ_PTR(_lPath_10297);
    _5727 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_5727)) {
        _5728 = (_5727 == 126);
    }
    else {
        _5728 = binary_op(EQUALS, _5727, 126);
    }
    _5727 = NOVALUE;
    if (IS_ATOM_INT(_5728))
    _5726 = (_5728 != 0);
    else
    _5726 = DBL_PTR(_5728)->dbl != 0.0;
L4: 
    if (_5726 == 0)
    {
        _5726 = NOVALUE;
        goto L5; // [134] 222
    }
    else{
        _5726 = NOVALUE;
    }

    /** filesys.e:1630			lHome = getenv("HOME")*/
    DeRefi(_lHome_10301);
    _lHome_10301 = EGetEnv(_5729);

    /** filesys.e:1631			ifdef WINDOWS then*/

    /** filesys.e:1637			if lHome[$] != SLASH then*/
    if (IS_SEQUENCE(_lHome_10301)){
            _5733 = SEQ_PTR(_lHome_10301)->length;
    }
    else {
        _5733 = 1;
    }
    _2 = (object)SEQ_PTR(_lHome_10301);
    _5734 = (object)*(((s1_ptr)_2)->base + _5733);
    if (_5734 == 47)
    goto L6; // [153] 164

    /** filesys.e:1638				lHome &= SLASH*/
    if (IS_SEQUENCE(_lHome_10301) && IS_ATOM(47)) {
        Append(&_lHome_10301, _lHome_10301, 47);
    }
    else if (IS_ATOM(_lHome_10301) && IS_SEQUENCE(47)) {
    }
    else {
        Concat((object_ptr)&_lHome_10301, _lHome_10301, 47);
    }
L6: 

    /** filesys.e:1641			if length(lPath) > 1 and lPath[2] = SLASH then*/
    if (IS_SEQUENCE(_lPath_10297)){
            _5737 = SEQ_PTR(_lPath_10297)->length;
    }
    else {
        _5737 = 1;
    }
    _5738 = (_5737 > 1);
    _5737 = NOVALUE;
    if (_5738 == 0) {
        goto L7; // [173] 206
    }
    _2 = (object)SEQ_PTR(_lPath_10297);
    _5740 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_5740)) {
        _5741 = (_5740 == 47);
    }
    else {
        _5741 = binary_op(EQUALS, _5740, 47);
    }
    _5740 = NOVALUE;
    if (_5741 == 0) {
        DeRef(_5741);
        _5741 = NOVALUE;
        goto L7; // [186] 206
    }
    else {
        if (!IS_ATOM_INT(_5741) && DBL_PTR(_5741)->dbl == 0.0){
            DeRef(_5741);
            _5741 = NOVALUE;
            goto L7; // [186] 206
        }
        DeRef(_5741);
        _5741 = NOVALUE;
    }
    DeRef(_5741);
    _5741 = NOVALUE;

    /** filesys.e:1642				lPath = lHome & lPath[3 .. $]*/
    if (IS_SEQUENCE(_lPath_10297)){
            _5742 = SEQ_PTR(_lPath_10297)->length;
    }
    else {
        _5742 = 1;
    }
    rhs_slice_target = (object_ptr)&_5743;
    RHS_Slice(_lPath_10297, 3, _5742);
    if (IS_SEQUENCE(_lHome_10301) && IS_ATOM(_5743)) {
    }
    else if (IS_ATOM(_lHome_10301) && IS_SEQUENCE(_5743)) {
        Ref(_lHome_10301);
        Prepend(&_lPath_10297, _5743, _lHome_10301);
    }
    else {
        Concat((object_ptr)&_lPath_10297, _lHome_10301, _5743);
    }
    DeRefDS(_5743);
    _5743 = NOVALUE;
    goto L8; // [203] 221
L7: 

    /** filesys.e:1644				lPath = lHome & lPath[2 .. $]*/
    if (IS_SEQUENCE(_lPath_10297)){
            _5745 = SEQ_PTR(_lPath_10297)->length;
    }
    else {
        _5745 = 1;
    }
    rhs_slice_target = (object_ptr)&_5746;
    RHS_Slice(_lPath_10297, 2, _5745);
    if (IS_SEQUENCE(_lHome_10301) && IS_ATOM(_5746)) {
    }
    else if (IS_ATOM(_lHome_10301) && IS_SEQUENCE(_5746)) {
        Ref(_lHome_10301);
        Prepend(&_lPath_10297, _5746, _lHome_10301);
    }
    else {
        Concat((object_ptr)&_lPath_10297, _lHome_10301, _5746);
    }
    DeRefDS(_5746);
    _5746 = NOVALUE;
L8: 
L5: 

    /** filesys.e:1648		ifdef WINDOWS then*/

    /** filesys.e:1658		sequence wildcard_suffix*/

    /** filesys.e:1659		integer first_wildcard_at = find_first_wildcard( lPath )*/
    RefDS(_lPath_10297);
    _first_wildcard_at_10344 = _14find_first_wildcard(_lPath_10297, 1);
    if (!IS_ATOM_INT(_first_wildcard_at_10344)) {
        _1 = (object)(DBL_PTR(_first_wildcard_at_10344)->dbl);
        DeRefDS(_first_wildcard_at_10344);
        _first_wildcard_at_10344 = _1;
    }

    /** filesys.e:1660		if first_wildcard_at then*/
    if (_first_wildcard_at_10344 == 0)
    {
        goto L9; // [237] 298
    }
    else{
    }

    /** filesys.e:1661			integer last_slash = search:rfind( SLASH, lPath, first_wildcard_at )*/
    RefDS(_lPath_10297);
    _last_slash_10347 = _20rfind(47, _lPath_10297, _first_wildcard_at_10344);
    if (!IS_ATOM_INT(_last_slash_10347)) {
        _1 = (object)(DBL_PTR(_last_slash_10347)->dbl);
        DeRefDS(_last_slash_10347);
        _last_slash_10347 = _1;
    }

    /** filesys.e:1662			if last_slash then*/
    if (_last_slash_10347 == 0)
    {
        goto LA; // [252] 278
    }
    else{
    }

    /** filesys.e:1663				wildcard_suffix = lPath[last_slash..$]*/
    if (IS_SEQUENCE(_lPath_10297)){
            _5750 = SEQ_PTR(_lPath_10297)->length;
    }
    else {
        _5750 = 1;
    }
    rhs_slice_target = (object_ptr)&_wildcard_suffix_10343;
    RHS_Slice(_lPath_10297, _last_slash_10347, _5750);

    /** filesys.e:1664				lPath = remove( lPath, last_slash, length( lPath ) )*/
    if (IS_SEQUENCE(_lPath_10297)){
            _5752 = SEQ_PTR(_lPath_10297)->length;
    }
    else {
        _5752 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_10297);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_last_slash_10347)) ? _last_slash_10347 : (object)(DBL_PTR(_last_slash_10347)->dbl);
        int stop = (IS_ATOM_INT(_5752)) ? _5752 : (object)(DBL_PTR(_5752)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_10297), start, &_lPath_10297 );
            }
            else Tail(SEQ_PTR(_lPath_10297), stop+1, &_lPath_10297);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_10297), start, &_lPath_10297);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_10297 = Remove_elements(start, stop, (SEQ_PTR(_lPath_10297)->ref == 1));
        }
    }
    _5752 = NOVALUE;
    goto LB; // [275] 293
LA: 

    /** filesys.e:1666				wildcard_suffix = lPath*/
    RefDS(_lPath_10297);
    DeRef(_wildcard_suffix_10343);
    _wildcard_suffix_10343 = _lPath_10297;

    /** filesys.e:1667				lPath = ""*/
    RefDS(_5);
    DeRefDS(_lPath_10297);
    _lPath_10297 = _5;
LB: 
    goto LC; // [295] 306
L9: 

    /** filesys.e:1670			wildcard_suffix = ""*/
    RefDS(_5);
    DeRef(_wildcard_suffix_10343);
    _wildcard_suffix_10343 = _5;
LC: 

    /** filesys.e:1674		if ((length(lPath) = 0) or not find(lPath[1], "/\\")) then*/
    if (IS_SEQUENCE(_lPath_10297)){
            _5754 = SEQ_PTR(_lPath_10297)->length;
    }
    else {
        _5754 = 1;
    }
    _5755 = (_5754 == 0);
    _5754 = NOVALUE;
    if (_5755 != 0) {
        DeRef(_5756);
        _5756 = 1;
        goto LD; // [315] 335
    }
    _2 = (object)SEQ_PTR(_lPath_10297);
    _5757 = (object)*(((s1_ptr)_2)->base + 1);
    _5759 = find_from(_5757, _5758, 1);
    _5757 = NOVALUE;
    _5760 = (_5759 == 0);
    _5759 = NOVALUE;
    _5756 = (_5760 != 0);
LD: 
    if (_5756 == 0)
    {
        _5756 = NOVALUE;
        goto LE; // [335] 351
    }
    else{
        _5756 = NOVALUE;
    }

    /** filesys.e:1675			ifdef UNIX then*/

    /** filesys.e:1676				lPath = curdir() & lPath*/
    _5761 = _14curdir(0);
    if (IS_SEQUENCE(_5761) && IS_ATOM(_lPath_10297)) {
    }
    else if (IS_ATOM(_5761) && IS_SEQUENCE(_lPath_10297)) {
        Ref(_5761);
        Prepend(&_lPath_10297, _lPath_10297, _5761);
    }
    else {
        Concat((object_ptr)&_lPath_10297, _5761, _lPath_10297);
        DeRef(_5761);
        _5761 = NOVALUE;
    }
    DeRef(_5761);
    _5761 = NOVALUE;
LE: 

    /** filesys.e:1694		if ((directory_given != 0) and (lPath[$] != SLASH) ) then*/
    _5763 = (_directory_given_10295 != 0);
    if (_5763 == 0) {
        DeRef(_5764);
        _5764 = 0;
        goto LF; // [357] 376
    }
    if (IS_SEQUENCE(_lPath_10297)){
            _5765 = SEQ_PTR(_lPath_10297)->length;
    }
    else {
        _5765 = 1;
    }
    _2 = (object)SEQ_PTR(_lPath_10297);
    _5766 = (object)*(((s1_ptr)_2)->base + _5765);
    if (IS_ATOM_INT(_5766)) {
        _5767 = (_5766 != 47);
    }
    else {
        _5767 = binary_op(NOTEQ, _5766, 47);
    }
    _5766 = NOVALUE;
    if (IS_ATOM_INT(_5767))
    _5764 = (_5767 != 0);
    else
    _5764 = DBL_PTR(_5767)->dbl != 0.0;
LF: 
    if (_5764 == 0)
    {
        _5764 = NOVALUE;
        goto L10; // [376] 386
    }
    else{
        _5764 = NOVALUE;
    }

    /** filesys.e:1695			lPath &= SLASH*/
    Append(&_lPath_10297, _lPath_10297, 47);
L10: 

    /** filesys.e:1699		lLevel = SLASH & '.' & SLASH*/
    {
        object concat_list[3];

        concat_list[0] = 47;
        concat_list[1] = 46;
        concat_list[2] = 47;
        Concat_N((object_ptr)&_lLevel_10300, concat_list, 3);
    }

    /** filesys.e:1700		lPosA = 1*/
    _lPosA_10298 = 1;

    /** filesys.e:1701		while( lPosA != 0 ) with entry do*/
    goto L11; // [401] 422
L12: 
    if (_lPosA_10298 == 0)
    goto L13; // [404] 434

    /** filesys.e:1702			lPath = eu:remove(lPath, lPosA, lPosA + 1)*/
    _5771 = _lPosA_10298 + 1;
    if (_5771 > MAXINT){
        _5771 = NewDouble((eudouble)_5771);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_10297);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosA_10298)) ? _lPosA_10298 : (object)(DBL_PTR(_lPosA_10298)->dbl);
        int stop = (IS_ATOM_INT(_5771)) ? _5771 : (object)(DBL_PTR(_5771)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_10297), start, &_lPath_10297 );
            }
            else Tail(SEQ_PTR(_lPath_10297), stop+1, &_lPath_10297);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_10297), start, &_lPath_10297);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_10297 = Remove_elements(start, stop, (SEQ_PTR(_lPath_10297)->ref == 1));
        }
    }
    DeRef(_5771);
    _5771 = NOVALUE;

    /** filesys.e:1704		  entry*/
L11: 

    /** filesys.e:1705			lPosA = match(lLevel, lPath, lPosA )*/
    _lPosA_10298 = e_match_from(_lLevel_10300, _lPath_10297, _lPosA_10298);

    /** filesys.e:1706		end while*/
    goto L12; // [431] 404
L13: 

    /** filesys.e:1709		lLevel = SLASH & ".." & SLASH*/
    {
        object concat_list[3];

        concat_list[0] = 47;
        concat_list[1] = _5518;
        concat_list[2] = 47;
        Concat_N((object_ptr)&_lLevel_10300, concat_list, 3);
    }

    /** filesys.e:1711		lPosB = 1*/
    _lPosB_10299 = 1;

    /** filesys.e:1712		while( lPosA != 0 ) with entry do*/
    goto L14; // [449] 527
L15: 
    if (_lPosA_10298 == 0)
    goto L16; // [452] 539

    /** filesys.e:1714			lPosB = lPosA-1*/
    _lPosB_10299 = _lPosA_10298 - 1;

    /** filesys.e:1715			while((lPosB > 0) and (lPath[lPosB] != SLASH)) do*/
L17: 
    _5777 = (_lPosB_10299 > 0);
    if (_5777 == 0) {
        DeRef(_5778);
        _5778 = 0;
        goto L18; // [471] 487
    }
    _2 = (object)SEQ_PTR(_lPath_10297);
    _5779 = (object)*(((s1_ptr)_2)->base + _lPosB_10299);
    if (IS_ATOM_INT(_5779)) {
        _5780 = (_5779 != 47);
    }
    else {
        _5780 = binary_op(NOTEQ, _5779, 47);
    }
    _5779 = NOVALUE;
    if (IS_ATOM_INT(_5780))
    _5778 = (_5780 != 0);
    else
    _5778 = DBL_PTR(_5780)->dbl != 0.0;
L18: 
    if (_5778 == 0)
    {
        _5778 = NOVALUE;
        goto L19; // [487] 501
    }
    else{
        _5778 = NOVALUE;
    }

    /** filesys.e:1716				lPosB -= 1*/
    _lPosB_10299 = _lPosB_10299 - 1;

    /** filesys.e:1717			end while*/
    goto L17; // [498] 467
L19: 

    /** filesys.e:1718			if (lPosB <= 0) then*/
    if (_lPosB_10299 > 0)
    goto L1A; // [503] 513

    /** filesys.e:1719				lPosB = 1*/
    _lPosB_10299 = 1;
L1A: 

    /** filesys.e:1721			lPath = eu:remove(lPath, lPosB, lPosA + 2)*/
    _5783 = _lPosA_10298 + 2;
    if ((object)((uintptr_t)_5783 + (uintptr_t)HIGH_BITS) >= 0){
        _5783 = NewDouble((eudouble)_5783);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_10297);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosB_10299)) ? _lPosB_10299 : (object)(DBL_PTR(_lPosB_10299)->dbl);
        int stop = (IS_ATOM_INT(_5783)) ? _5783 : (object)(DBL_PTR(_5783)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_10297), start, &_lPath_10297 );
            }
            else Tail(SEQ_PTR(_lPath_10297), stop+1, &_lPath_10297);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_10297), start, &_lPath_10297);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_10297 = Remove_elements(start, stop, (SEQ_PTR(_lPath_10297)->ref == 1));
        }
    }
    DeRef(_5783);
    _5783 = NOVALUE;

    /** filesys.e:1723		  entry*/
L14: 

    /** filesys.e:1724			lPosA = match(lLevel, lPath, lPosB )*/
    _lPosA_10298 = e_match_from(_lLevel_10300, _lPath_10297, _lPosB_10299);

    /** filesys.e:1725		end while*/
    goto L15; // [536] 452
L16: 

    /** filesys.e:1727		if case_flags = TO_LOWER then*/
    if (_case_flags_10296 != 1)
    goto L1B; // [541] 556

    /** filesys.e:1728			lPath = lower( lPath )*/
    RefDS(_lPath_10297);
    _0 = _lPath_10297;
    _lPath_10297 = _18lower(_lPath_10297);
    DeRefDS(_0);
    goto L1C; // [553] 1153
L1B: 

    /** filesys.e:1730		elsif case_flags != AS_IS then*/
    if (_case_flags_10296 == 0)
    goto L1D; // [558] 1150

    /** filesys.e:1731			sequence sl = find_all(SLASH,lPath) -- split apart lPath*/
    RefDS(_lPath_10297);
    _0 = _sl_10400;
    _sl_10400 = _20find_all(47, _lPath_10297, 1);
    DeRef(_0);

    /** filesys.e:1732			integer short_name = and_bits(TO_SHORT,case_flags)=TO_SHORT*/
    {uintptr_t tu;
         tu = (uintptr_t)4 & (uintptr_t)_case_flags_10296;
         _5790 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_5790)) {
        _short_name_10403 = (_5790 == 4);
    }
    else {
        _short_name_10403 = (DBL_PTR(_5790)->dbl == (eudouble)4);
    }
    DeRef(_5790);
    _5790 = NOVALUE;

    /** filesys.e:1733			integer correct_name = and_bits(case_flags,CORRECT)=CORRECT*/
    {uintptr_t tu;
         tu = (uintptr_t)_case_flags_10296 & (uintptr_t)2;
         _5792 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_5792)) {
        _correct_name_10406 = (_5792 == 2);
    }
    else {
        _correct_name_10406 = (DBL_PTR(_5792)->dbl == (eudouble)2);
    }
    DeRef(_5792);
    _5792 = NOVALUE;

    /** filesys.e:1734			integer lower_name = and_bits(TO_LOWER,case_flags)=TO_LOWER*/
    {uintptr_t tu;
         tu = (uintptr_t)1 & (uintptr_t)_case_flags_10296;
         _5794 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_5794)) {
        _lower_name_10409 = (_5794 == 1);
    }
    else {
        _lower_name_10409 = (DBL_PTR(_5794)->dbl == (eudouble)1);
    }
    DeRef(_5794);
    _5794 = NOVALUE;

    /** filesys.e:1735			if lPath[$] != SLASH then*/
    if (IS_SEQUENCE(_lPath_10297)){
            _5796 = SEQ_PTR(_lPath_10297)->length;
    }
    else {
        _5796 = 1;
    }
    _2 = (object)SEQ_PTR(_lPath_10297);
    _5797 = (object)*(((s1_ptr)_2)->base + _5796);
    if (binary_op_a(EQUALS, _5797, 47)){
        _5797 = NOVALUE;
        goto L1E; // [611] 633
    }
    _5797 = NOVALUE;

    /** filesys.e:1736				sl = sl & {length(lPath)+1}*/
    if (IS_SEQUENCE(_lPath_10297)){
            _5799 = SEQ_PTR(_lPath_10297)->length;
    }
    else {
        _5799 = 1;
    }
    _5800 = _5799 + 1;
    _5799 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _5800;
    _5801 = MAKE_SEQ(_1);
    _5800 = NOVALUE;
    Concat((object_ptr)&_sl_10400, _sl_10400, _5801);
    DeRefDS(_5801);
    _5801 = NOVALUE;
L1E: 

    /** filesys.e:1739			for i = length(sl)-1 to 1 by -1 label "partloop" do*/
    if (IS_SEQUENCE(_sl_10400)){
            _5803 = SEQ_PTR(_sl_10400)->length;
    }
    else {
        _5803 = 1;
    }
    _5804 = _5803 - 1;
    _5803 = NOVALUE;
    {
        object _i_10421;
        _i_10421 = _5804;
L1F: 
        if (_i_10421 < 1){
            goto L20; // [642] 1115
        }

        /** filesys.e:1740				ifdef WINDOWS then*/

        /** filesys.e:1743					sequence part = lPath[1..sl[i]-1]*/
        _2 = (object)SEQ_PTR(_sl_10400);
        _5806 = (object)*(((s1_ptr)_2)->base + _i_10421);
        if (IS_ATOM_INT(_5806)) {
            _5807 = _5806 - 1;
        }
        else {
            _5807 = binary_op(MINUS, _5806, 1);
        }
        _5806 = NOVALUE;
        rhs_slice_target = (object_ptr)&_part_10425;
        RHS_Slice(_lPath_10297, 1, _5807);

        /** filesys.e:1746				object list = dir( part & SLASH )*/
        Append(&_5809, _part_10425, 47);
        _0 = _list_10429;
        _list_10429 = _14dir(_5809);
        DeRef(_0);
        _5809 = NOVALUE;

        /** filesys.e:1747				sequence supplied_name = lPath[sl[i]+1..sl[i+1]-1]*/
        _2 = (object)SEQ_PTR(_sl_10400);
        _5811 = (object)*(((s1_ptr)_2)->base + _i_10421);
        if (IS_ATOM_INT(_5811)) {
            _5812 = _5811 + 1;
            if (_5812 > MAXINT){
                _5812 = NewDouble((eudouble)_5812);
            }
        }
        else
        _5812 = binary_op(PLUS, 1, _5811);
        _5811 = NOVALUE;
        _5813 = _i_10421 + 1;
        _2 = (object)SEQ_PTR(_sl_10400);
        _5814 = (object)*(((s1_ptr)_2)->base + _5813);
        if (IS_ATOM_INT(_5814)) {
            _5815 = _5814 - 1;
        }
        else {
            _5815 = binary_op(MINUS, _5814, 1);
        }
        _5814 = NOVALUE;
        rhs_slice_target = (object_ptr)&_supplied_name_10432;
        RHS_Slice(_lPath_10297, _5812, _5815);

        /** filesys.e:1749				if atom(list) then*/
        _5817 = IS_ATOM(_list_10429);
        if (_5817 == 0)
        {
            _5817 = NOVALUE;
            goto L21; // [710] 748
        }
        else{
            _5817 = NOVALUE;
        }

        /** filesys.e:1750					if lower_name then*/
        if (_lower_name_10409 == 0)
        {
            goto L22; // [715] 741
        }
        else{
        }

        /** filesys.e:1751						lPath = part & lower(lPath[sl[i]..$])*/
        _2 = (object)SEQ_PTR(_sl_10400);
        _5818 = (object)*(((s1_ptr)_2)->base + _i_10421);
        if (IS_SEQUENCE(_lPath_10297)){
                _5819 = SEQ_PTR(_lPath_10297)->length;
        }
        else {
            _5819 = 1;
        }
        rhs_slice_target = (object_ptr)&_5820;
        RHS_Slice(_lPath_10297, _5818, _5819);
        _5821 = _18lower(_5820);
        _5820 = NOVALUE;
        if (IS_SEQUENCE(_part_10425) && IS_ATOM(_5821)) {
            Ref(_5821);
            Append(&_lPath_10297, _part_10425, _5821);
        }
        else if (IS_ATOM(_part_10425) && IS_SEQUENCE(_5821)) {
        }
        else {
            Concat((object_ptr)&_lPath_10297, _part_10425, _5821);
        }
        DeRef(_5821);
        _5821 = NOVALUE;
L22: 

        /** filesys.e:1753					continue*/
        DeRef(_part_10425);
        _part_10425 = NOVALUE;
        DeRef(_list_10429);
        _list_10429 = NOVALUE;
        DeRef(_supplied_name_10432);
        _supplied_name_10432 = NOVALUE;
        goto L23; // [745] 1110
L21: 

        /** filesys.e:1757				for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_10429)){
                _5823 = SEQ_PTR(_list_10429)->length;
        }
        else {
            _5823 = 1;
        }
        {
            object _j_10449;
            _j_10449 = 1;
L24: 
            if (_j_10449 > _5823){
                goto L25; // [753] 878
            }

            /** filesys.e:1758					sequence read_name = list[j][D_NAME]*/
            _2 = (object)SEQ_PTR(_list_10429);
            _5824 = (object)*(((s1_ptr)_2)->base + _j_10449);
            DeRef(_read_name_10451);
            _2 = (object)SEQ_PTR(_5824);
            _read_name_10451 = (object)*(((s1_ptr)_2)->base + 1);
            Ref(_read_name_10451);
            _5824 = NOVALUE;

            /** filesys.e:1759					if equal(read_name, supplied_name) then*/
            if (_read_name_10451 == _supplied_name_10432)
            _5826 = 1;
            else if (IS_ATOM_INT(_read_name_10451) && IS_ATOM_INT(_supplied_name_10432))
            _5826 = 0;
            else
            _5826 = (compare(_read_name_10451, _supplied_name_10432) == 0);
            if (_5826 == 0)
            {
                _5826 = NOVALUE;
                goto L26; // [778] 869
            }
            else{
                _5826 = NOVALUE;
            }

            /** filesys.e:1760						if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_10403 == 0) {
                goto L27; // [783] 860
            }
            _2 = (object)SEQ_PTR(_list_10429);
            _5828 = (object)*(((s1_ptr)_2)->base + _j_10449);
            _2 = (object)SEQ_PTR(_5828);
            _5829 = (object)*(((s1_ptr)_2)->base + 11);
            _5828 = NOVALUE;
            _5830 = IS_SEQUENCE(_5829);
            _5829 = NOVALUE;
            if (_5830 == 0)
            {
                _5830 = NOVALUE;
                goto L27; // [799] 860
            }
            else{
                _5830 = NOVALUE;
            }

            /** filesys.e:1761							lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (object)SEQ_PTR(_sl_10400);
            _5831 = (object)*(((s1_ptr)_2)->base + _i_10421);
            rhs_slice_target = (object_ptr)&_5832;
            RHS_Slice(_lPath_10297, 1, _5831);
            _2 = (object)SEQ_PTR(_list_10429);
            _5833 = (object)*(((s1_ptr)_2)->base + _j_10449);
            _2 = (object)SEQ_PTR(_5833);
            _5834 = (object)*(((s1_ptr)_2)->base + 11);
            _5833 = NOVALUE;
            _5835 = _i_10421 + 1;
            _2 = (object)SEQ_PTR(_sl_10400);
            _5836 = (object)*(((s1_ptr)_2)->base + _5835);
            if (IS_SEQUENCE(_lPath_10297)){
                    _5837 = SEQ_PTR(_lPath_10297)->length;
            }
            else {
                _5837 = 1;
            }
            rhs_slice_target = (object_ptr)&_5838;
            RHS_Slice(_lPath_10297, _5836, _5837);
            {
                object concat_list[3];

                concat_list[0] = _5838;
                concat_list[1] = _5834;
                concat_list[2] = _5832;
                Concat_N((object_ptr)&_lPath_10297, concat_list, 3);
            }
            DeRefDS(_5838);
            _5838 = NOVALUE;
            _5834 = NOVALUE;
            DeRefDS(_5832);
            _5832 = NOVALUE;

            /** filesys.e:1762							sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_10400)){
                    _5840 = SEQ_PTR(_sl_10400)->length;
            }
            else {
                _5840 = 1;
            }
            if (IS_SEQUENCE(_lPath_10297)){
                    _5841 = SEQ_PTR(_lPath_10297)->length;
            }
            else {
                _5841 = 1;
            }
            _5842 = _5841 + 1;
            _5841 = NOVALUE;
            _2 = (object)SEQ_PTR(_sl_10400);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _sl_10400 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _5840);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _5842;
            if( _1 != _5842 ){
                DeRef(_1);
            }
            _5842 = NOVALUE;
L27: 

            /** filesys.e:1764						continue "partloop"*/
            DeRef(_read_name_10451);
            _read_name_10451 = NOVALUE;
            DeRef(_part_10425);
            _part_10425 = NOVALUE;
            DeRef(_list_10429);
            _list_10429 = NOVALUE;
            DeRef(_supplied_name_10432);
            _supplied_name_10432 = NOVALUE;
            goto L23; // [866] 1110
L26: 
            DeRef(_read_name_10451);
            _read_name_10451 = NOVALUE;

            /** filesys.e:1766				end for*/
            _j_10449 = _j_10449 + 1;
            goto L24; // [873] 760
L25: 
            ;
        }

        /** filesys.e:1770				for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_10429)){
                _5843 = SEQ_PTR(_list_10429)->length;
        }
        else {
            _5843 = 1;
        }
        {
            object _j_10474;
            _j_10474 = 1;
L28: 
            if (_j_10474 > _5843){
                goto L29; // [883] 1055
            }

            /** filesys.e:1771					sequence read_name = list[j][D_NAME]*/
            _2 = (object)SEQ_PTR(_list_10429);
            _5844 = (object)*(((s1_ptr)_2)->base + _j_10474);
            DeRef(_read_name_10476);
            _2 = (object)SEQ_PTR(_5844);
            _read_name_10476 = (object)*(((s1_ptr)_2)->base + 1);
            Ref(_read_name_10476);
            _5844 = NOVALUE;

            /** filesys.e:1772					if equal(lower(read_name), lower(supplied_name)) then*/
            RefDS(_read_name_10476);
            _5846 = _18lower(_read_name_10476);
            RefDS(_supplied_name_10432);
            _5847 = _18lower(_supplied_name_10432);
            if (_5846 == _5847)
            _5848 = 1;
            else if (IS_ATOM_INT(_5846) && IS_ATOM_INT(_5847))
            _5848 = 0;
            else
            _5848 = (compare(_5846, _5847) == 0);
            DeRef(_5846);
            _5846 = NOVALUE;
            DeRef(_5847);
            _5847 = NOVALUE;
            if (_5848 == 0)
            {
                _5848 = NOVALUE;
                goto L2A; // [916] 1046
            }
            else{
                _5848 = NOVALUE;
            }

            /** filesys.e:1773						if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_10403 == 0) {
                goto L2B; // [921] 998
            }
            _2 = (object)SEQ_PTR(_list_10429);
            _5850 = (object)*(((s1_ptr)_2)->base + _j_10474);
            _2 = (object)SEQ_PTR(_5850);
            _5851 = (object)*(((s1_ptr)_2)->base + 11);
            _5850 = NOVALUE;
            _5852 = IS_SEQUENCE(_5851);
            _5851 = NOVALUE;
            if (_5852 == 0)
            {
                _5852 = NOVALUE;
                goto L2B; // [937] 998
            }
            else{
                _5852 = NOVALUE;
            }

            /** filesys.e:1774							lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (object)SEQ_PTR(_sl_10400);
            _5853 = (object)*(((s1_ptr)_2)->base + _i_10421);
            rhs_slice_target = (object_ptr)&_5854;
            RHS_Slice(_lPath_10297, 1, _5853);
            _2 = (object)SEQ_PTR(_list_10429);
            _5855 = (object)*(((s1_ptr)_2)->base + _j_10474);
            _2 = (object)SEQ_PTR(_5855);
            _5856 = (object)*(((s1_ptr)_2)->base + 11);
            _5855 = NOVALUE;
            _5857 = _i_10421 + 1;
            _2 = (object)SEQ_PTR(_sl_10400);
            _5858 = (object)*(((s1_ptr)_2)->base + _5857);
            if (IS_SEQUENCE(_lPath_10297)){
                    _5859 = SEQ_PTR(_lPath_10297)->length;
            }
            else {
                _5859 = 1;
            }
            rhs_slice_target = (object_ptr)&_5860;
            RHS_Slice(_lPath_10297, _5858, _5859);
            {
                object concat_list[3];

                concat_list[0] = _5860;
                concat_list[1] = _5856;
                concat_list[2] = _5854;
                Concat_N((object_ptr)&_lPath_10297, concat_list, 3);
            }
            DeRefDS(_5860);
            _5860 = NOVALUE;
            _5856 = NOVALUE;
            DeRefDS(_5854);
            _5854 = NOVALUE;

            /** filesys.e:1775							sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_10400)){
                    _5862 = SEQ_PTR(_sl_10400)->length;
            }
            else {
                _5862 = 1;
            }
            if (IS_SEQUENCE(_lPath_10297)){
                    _5863 = SEQ_PTR(_lPath_10297)->length;
            }
            else {
                _5863 = 1;
            }
            _5864 = _5863 + 1;
            _5863 = NOVALUE;
            _2 = (object)SEQ_PTR(_sl_10400);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _sl_10400 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _5862);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _5864;
            if( _1 != _5864 ){
                DeRef(_1);
            }
            _5864 = NOVALUE;
L2B: 

            /** filesys.e:1777						if correct_name then*/
            if (_correct_name_10406 == 0)
            {
                goto L2C; // [1000] 1037
            }
            else{
            }

            /** filesys.e:1778							lPath = lPath[1..sl[i]] & read_name & lPath[sl[i+1]..$]*/
            _2 = (object)SEQ_PTR(_sl_10400);
            _5865 = (object)*(((s1_ptr)_2)->base + _i_10421);
            rhs_slice_target = (object_ptr)&_5866;
            RHS_Slice(_lPath_10297, 1, _5865);
            _5867 = _i_10421 + 1;
            _2 = (object)SEQ_PTR(_sl_10400);
            _5868 = (object)*(((s1_ptr)_2)->base + _5867);
            if (IS_SEQUENCE(_lPath_10297)){
                    _5869 = SEQ_PTR(_lPath_10297)->length;
            }
            else {
                _5869 = 1;
            }
            rhs_slice_target = (object_ptr)&_5870;
            RHS_Slice(_lPath_10297, _5868, _5869);
            {
                object concat_list[3];

                concat_list[0] = _5870;
                concat_list[1] = _read_name_10476;
                concat_list[2] = _5866;
                Concat_N((object_ptr)&_lPath_10297, concat_list, 3);
            }
            DeRefDS(_5870);
            _5870 = NOVALUE;
            DeRefDS(_5866);
            _5866 = NOVALUE;
L2C: 

            /** filesys.e:1780						continue "partloop"*/
            DeRef(_read_name_10476);
            _read_name_10476 = NOVALUE;
            DeRef(_part_10425);
            _part_10425 = NOVALUE;
            DeRef(_list_10429);
            _list_10429 = NOVALUE;
            DeRef(_supplied_name_10432);
            _supplied_name_10432 = NOVALUE;
            goto L23; // [1043] 1110
L2A: 
            DeRef(_read_name_10476);
            _read_name_10476 = NOVALUE;

            /** filesys.e:1782				end for*/
            _j_10474 = _j_10474 + 1;
            goto L28; // [1050] 890
L29: 
            ;
        }

        /** filesys.e:1786				if and_bits(TO_LOWER,case_flags) then*/
        {uintptr_t tu;
             tu = (uintptr_t)1 & (uintptr_t)_case_flags_10296;
             _5872 = MAKE_UINT(tu);
        }
        if (_5872 == 0) {
            DeRef(_5872);
            _5872 = NOVALUE;
            goto L2D; // [1061] 1100
        }
        else {
            if (!IS_ATOM_INT(_5872) && DBL_PTR(_5872)->dbl == 0.0){
                DeRef(_5872);
                _5872 = NOVALUE;
                goto L2D; // [1061] 1100
            }
            DeRef(_5872);
            _5872 = NOVALUE;
        }
        DeRef(_5872);
        _5872 = NOVALUE;

        /** filesys.e:1787					lPath = lPath[1..sl[i]-1] & lower(lPath[sl[i]..$])*/
        _2 = (object)SEQ_PTR(_sl_10400);
        _5873 = (object)*(((s1_ptr)_2)->base + _i_10421);
        if (IS_ATOM_INT(_5873)) {
            _5874 = _5873 - 1;
        }
        else {
            _5874 = binary_op(MINUS, _5873, 1);
        }
        _5873 = NOVALUE;
        rhs_slice_target = (object_ptr)&_5875;
        RHS_Slice(_lPath_10297, 1, _5874);
        _2 = (object)SEQ_PTR(_sl_10400);
        _5876 = (object)*(((s1_ptr)_2)->base + _i_10421);
        if (IS_SEQUENCE(_lPath_10297)){
                _5877 = SEQ_PTR(_lPath_10297)->length;
        }
        else {
            _5877 = 1;
        }
        rhs_slice_target = (object_ptr)&_5878;
        RHS_Slice(_lPath_10297, _5876, _5877);
        _5879 = _18lower(_5878);
        _5878 = NOVALUE;
        if (IS_SEQUENCE(_5875) && IS_ATOM(_5879)) {
            Ref(_5879);
            Append(&_lPath_10297, _5875, _5879);
        }
        else if (IS_ATOM(_5875) && IS_SEQUENCE(_5879)) {
        }
        else {
            Concat((object_ptr)&_lPath_10297, _5875, _5879);
            DeRefDS(_5875);
            _5875 = NOVALUE;
        }
        DeRef(_5875);
        _5875 = NOVALUE;
        DeRef(_5879);
        _5879 = NOVALUE;
L2D: 

        /** filesys.e:1789				exit*/
        DeRef(_part_10425);
        _part_10425 = NOVALUE;
        DeRef(_list_10429);
        _list_10429 = NOVALUE;
        DeRef(_supplied_name_10432);
        _supplied_name_10432 = NOVALUE;
        goto L20; // [1104] 1115

        /** filesys.e:1790			end for*/
L23: 
        _i_10421 = _i_10421 + -1;
        goto L1F; // [1110] 649
L20: 
        ;
    }

    /** filesys.e:1791			if and_bits(case_flags,or_bits(CORRECT,TO_LOWER))=TO_LOWER and length(lPath) then*/
    {uintptr_t tu;
         tu = (uintptr_t)2 | (uintptr_t)1;
         _5881 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_5881)) {
        {uintptr_t tu;
             tu = (uintptr_t)_case_flags_10296 & (uintptr_t)_5881;
             _5882 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)_case_flags_10296;
        _5882 = Dand_bits(&temp_d, DBL_PTR(_5881));
    }
    DeRef(_5881);
    _5881 = NOVALUE;
    if (IS_ATOM_INT(_5882)) {
        _5883 = (_5882 == 1);
    }
    else {
        _5883 = (DBL_PTR(_5882)->dbl == (eudouble)1);
    }
    DeRef(_5882);
    _5882 = NOVALUE;
    if (_5883 == 0) {
        goto L2E; // [1129] 1149
    }
    if (IS_SEQUENCE(_lPath_10297)){
            _5885 = SEQ_PTR(_lPath_10297)->length;
    }
    else {
        _5885 = 1;
    }
    if (_5885 == 0)
    {
        _5885 = NOVALUE;
        goto L2E; // [1137] 1149
    }
    else{
        _5885 = NOVALUE;
    }

    /** filesys.e:1792				lPath = lower(lPath)*/
    RefDS(_lPath_10297);
    _0 = _lPath_10297;
    _lPath_10297 = _18lower(_lPath_10297);
    DeRefDS(_0);
L2E: 
L1D: 
    DeRef(_sl_10400);
    _sl_10400 = NOVALUE;
L1C: 

    /** filesys.e:1796		ifdef WINDOWS then*/

    /** filesys.e:1810		return lPath & wildcard_suffix*/
    Concat((object_ptr)&_5887, _lPath_10297, _wildcard_suffix_10343);
    DeRefDS(_path_in_10294);
    DeRefDS(_lPath_10297);
    DeRefi(_lLevel_10300);
    DeRefi(_lHome_10301);
    DeRefDS(_wildcard_suffix_10343);
    DeRef(_5738);
    _5738 = NOVALUE;
    _5853 = NOVALUE;
    DeRef(_5867);
    _5867 = NOVALUE;
    DeRef(_5716);
    _5716 = NOVALUE;
    _5865 = NOVALUE;
    DeRef(_5713);
    _5713 = NOVALUE;
    DeRef(_5767);
    _5767 = NOVALUE;
    DeRef(_5807);
    _5807 = NOVALUE;
    DeRef(_5813);
    _5813 = NOVALUE;
    _5818 = NOVALUE;
    DeRef(_5728);
    _5728 = NOVALUE;
    _5868 = NOVALUE;
    _5836 = NOVALUE;
    DeRef(_5804);
    _5804 = NOVALUE;
    DeRef(_5725);
    _5725 = NOVALUE;
    DeRef(_5780);
    _5780 = NOVALUE;
    DeRef(_5720);
    _5720 = NOVALUE;
    _5831 = NOVALUE;
    _5734 = NOVALUE;
    _5876 = NOVALUE;
    DeRef(_5777);
    _5777 = NOVALUE;
    DeRef(_5812);
    _5812 = NOVALUE;
    DeRef(_5857);
    _5857 = NOVALUE;
    DeRef(_5755);
    _5755 = NOVALUE;
    DeRef(_5815);
    _5815 = NOVALUE;
    _5858 = NOVALUE;
    DeRef(_5722);
    _5722 = NOVALUE;
    DeRef(_5835);
    _5835 = NOVALUE;
    DeRef(_5760);
    _5760 = NOVALUE;
    DeRef(_5874);
    _5874 = NOVALUE;
    DeRef(_5883);
    _5883 = NOVALUE;
    DeRef(_5763);
    _5763 = NOVALUE;
    return _5887;
    ;
}


object _14abbreviate_path(object _orig_path_10535, object _base_paths_10536)
{
    object _expanded_path_10537 = NOVALUE;
    object _fs_case_inlined_fs_case_at_61_10547 = NOVALUE;
    object _lowered_expanded_path_10548 = NOVALUE;
    object _fs_case_inlined_fs_case_at_73_10550 = NOVALUE;
    object _fs_case_inlined_fs_case_at_216_10577 = NOVALUE;
    object _s_inlined_fs_case_at_213_10576 = NOVALUE;
    object _5923 = NOVALUE;
    object _5922 = NOVALUE;
    object _5919 = NOVALUE;
    object _5918 = NOVALUE;
    object _5917 = NOVALUE;
    object _5916 = NOVALUE;
    object _5915 = NOVALUE;
    object _5913 = NOVALUE;
    object _5912 = NOVALUE;
    object _5911 = NOVALUE;
    object _5910 = NOVALUE;
    object _5909 = NOVALUE;
    object _5908 = NOVALUE;
    object _5907 = NOVALUE;
    object _5906 = NOVALUE;
    object _5903 = NOVALUE;
    object _5902 = NOVALUE;
    object _5901 = NOVALUE;
    object _5900 = NOVALUE;
    object _5899 = NOVALUE;
    object _5898 = NOVALUE;
    object _5897 = NOVALUE;
    object _5896 = NOVALUE;
    object _5895 = NOVALUE;
    object _5894 = NOVALUE;
    object _5893 = NOVALUE;
    object _5892 = NOVALUE;
    object _5891 = NOVALUE;
    object _5889 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1881		expanded_path = canonical_path(orig_path)*/
    RefDS(_orig_path_10535);
    _0 = _expanded_path_10537;
    _expanded_path_10537 = _14canonical_path(_orig_path_10535, 0, 0);
    DeRef(_0);

    /** filesys.e:1884		base_paths = append(base_paths, curdir())*/
    _5889 = _14curdir(0);
    Ref(_5889);
    Append(&_base_paths_10536, _base_paths_10536, _5889);
    DeRef(_5889);
    _5889 = NOVALUE;

    /** filesys.e:1886		for i = 1 to length(base_paths) do*/
    _5891 = 1;
    {
        object _i_10542;
        _i_10542 = 1;
L1: 
        if (_i_10542 > 1){
            goto L2; // [30] 60
        }

        /** filesys.e:1887			base_paths[i] = canonical_path(base_paths[i], 1) -- assume each base path is meant to be a directory.*/
        _2 = (object)SEQ_PTR(_base_paths_10536);
        _5892 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_5892);
        _5893 = _14canonical_path(_5892, 1, 0);
        _5892 = NOVALUE;
        _2 = (object)SEQ_PTR(_base_paths_10536);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _base_paths_10536 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5893;
        if( _1 != _5893 ){
            DeRef(_1);
        }
        _5893 = NOVALUE;

        /** filesys.e:1888		end for*/
        _i_10542 = 1 + 1;
        goto L1; // [55] 37
L2: 
        ;
    }

    /** filesys.e:1892		base_paths = fs_case(base_paths)*/

    /** filesys.e:1825		ifdef WINDOWS then*/

    /** filesys.e:1828			return s*/
    RefDS(_base_paths_10536);
    DeRefDS(_base_paths_10536);
    _base_paths_10536 = _base_paths_10536;

    /** filesys.e:1893		sequence lowered_expanded_path = fs_case(expanded_path)*/

    /** filesys.e:1825		ifdef WINDOWS then*/

    /** filesys.e:1828			return s*/
    RefDS(_expanded_path_10537);
    DeRef(_lowered_expanded_path_10548);
    _lowered_expanded_path_10548 = _expanded_path_10537;

    /** filesys.e:1896		for i = 1 to length(base_paths) do*/
    if (IS_SEQUENCE(_base_paths_10536)){
            _5894 = SEQ_PTR(_base_paths_10536)->length;
    }
    else {
        _5894 = 1;
    }
    {
        object _i_10552;
        _i_10552 = 1;
L3: 
        if (_i_10552 > _5894){
            goto L4; // [89] 143
        }

        /** filesys.e:1897			if search:begins(base_paths[i], lowered_expanded_path) then*/
        _2 = (object)SEQ_PTR(_base_paths_10536);
        _5895 = (object)*(((s1_ptr)_2)->base + _i_10552);
        Ref(_5895);
        RefDS(_lowered_expanded_path_10548);
        _5896 = _20begins(_5895, _lowered_expanded_path_10548);
        _5895 = NOVALUE;
        if (_5896 == 0) {
            DeRef(_5896);
            _5896 = NOVALUE;
            goto L5; // [107] 136
        }
        else {
            if (!IS_ATOM_INT(_5896) && DBL_PTR(_5896)->dbl == 0.0){
                DeRef(_5896);
                _5896 = NOVALUE;
                goto L5; // [107] 136
            }
            DeRef(_5896);
            _5896 = NOVALUE;
        }
        DeRef(_5896);
        _5896 = NOVALUE;

        /** filesys.e:1899				return expanded_path[length(base_paths[i]) + 1 .. $]*/
        _2 = (object)SEQ_PTR(_base_paths_10536);
        _5897 = (object)*(((s1_ptr)_2)->base + _i_10552);
        if (IS_SEQUENCE(_5897)){
                _5898 = SEQ_PTR(_5897)->length;
        }
        else {
            _5898 = 1;
        }
        _5897 = NOVALUE;
        _5899 = _5898 + 1;
        _5898 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_10537)){
                _5900 = SEQ_PTR(_expanded_path_10537)->length;
        }
        else {
            _5900 = 1;
        }
        rhs_slice_target = (object_ptr)&_5901;
        RHS_Slice(_expanded_path_10537, _5899, _5900);
        DeRefDS(_orig_path_10535);
        DeRefDS(_base_paths_10536);
        DeRefDS(_expanded_path_10537);
        DeRefDS(_lowered_expanded_path_10548);
        _5899 = NOVALUE;
        _5897 = NOVALUE;
        return _5901;
L5: 

        /** filesys.e:1901		end for*/
        _i_10552 = _i_10552 + 1;
        goto L3; // [138] 96
L4: 
        ;
    }

    /** filesys.e:1904		ifdef WINDOWS then*/

    /** filesys.e:1912		base_paths = stdseq:split(base_paths[$], SLASH)*/
    if (IS_SEQUENCE(_base_paths_10536)){
            _5902 = SEQ_PTR(_base_paths_10536)->length;
    }
    else {
        _5902 = 1;
    }
    _2 = (object)SEQ_PTR(_base_paths_10536);
    _5903 = (object)*(((s1_ptr)_2)->base + _5902);
    Ref(_5903);
    _0 = _base_paths_10536;
    _base_paths_10536 = _24split(_5903, 47, 0, 0);
    DeRefDS(_0);
    _5903 = NOVALUE;

    /** filesys.e:1914		expanded_path = stdseq:split(expanded_path, SLASH)*/
    RefDS(_expanded_path_10537);
    _0 = _expanded_path_10537;
    _expanded_path_10537 = _24split(_expanded_path_10537, 47, 0, 0);
    DeRefDS(_0);

    /** filesys.e:1915		lowered_expanded_path = ""*/
    RefDS(_5);
    DeRef(_lowered_expanded_path_10548);
    _lowered_expanded_path_10548 = _5;

    /** filesys.e:1918		for i = 1 to math:min({length(expanded_path), length(base_paths) - 1}) do*/
    if (IS_SEQUENCE(_expanded_path_10537)){
            _5906 = SEQ_PTR(_expanded_path_10537)->length;
    }
    else {
        _5906 = 1;
    }
    if (IS_SEQUENCE(_base_paths_10536)){
            _5907 = SEQ_PTR(_base_paths_10536)->length;
    }
    else {
        _5907 = 1;
    }
    _5908 = _5907 - 1;
    _5907 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _5906;
    ((intptr_t *)_2)[2] = _5908;
    _5909 = MAKE_SEQ(_1);
    _5908 = NOVALUE;
    _5906 = NOVALUE;
    _5910 = _21min(_5909);
    _5909 = NOVALUE;
    {
        object _i_10567;
        _i_10567 = 1;
L6: 
        if (binary_op_a(GREATER, _i_10567, _5910)){
            goto L7; // [201] 305
        }

        /** filesys.e:1919			if not equal(fs_case(expanded_path[i]), base_paths[i]) then*/
        _2 = (object)SEQ_PTR(_expanded_path_10537);
        if (!IS_ATOM_INT(_i_10567)){
            _5911 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_10567)->dbl));
        }
        else{
            _5911 = (object)*(((s1_ptr)_2)->base + _i_10567);
        }
        Ref(_5911);
        DeRef(_s_inlined_fs_case_at_213_10576);
        _s_inlined_fs_case_at_213_10576 = _5911;
        _5911 = NOVALUE;

        /** filesys.e:1825		ifdef WINDOWS then*/

        /** filesys.e:1828			return s*/
        Ref(_s_inlined_fs_case_at_213_10576);
        DeRef(_fs_case_inlined_fs_case_at_216_10577);
        _fs_case_inlined_fs_case_at_216_10577 = _s_inlined_fs_case_at_213_10576;
        DeRef(_s_inlined_fs_case_at_213_10576);
        _s_inlined_fs_case_at_213_10576 = NOVALUE;
        _2 = (object)SEQ_PTR(_base_paths_10536);
        if (!IS_ATOM_INT(_i_10567)){
            _5912 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_10567)->dbl));
        }
        else{
            _5912 = (object)*(((s1_ptr)_2)->base + _i_10567);
        }
        if (_fs_case_inlined_fs_case_at_216_10577 == _5912)
        _5913 = 1;
        else if (IS_ATOM_INT(_fs_case_inlined_fs_case_at_216_10577) && IS_ATOM_INT(_5912))
        _5913 = 0;
        else
        _5913 = (compare(_fs_case_inlined_fs_case_at_216_10577, _5912) == 0);
        _5912 = NOVALUE;
        if (_5913 != 0)
        goto L8; // [237] 298
        _5913 = NOVALUE;

        /** filesys.e:1923				expanded_path = repeat("..", length(base_paths) - i) & expanded_path[i .. $]*/
        if (IS_SEQUENCE(_base_paths_10536)){
                _5915 = SEQ_PTR(_base_paths_10536)->length;
        }
        else {
            _5915 = 1;
        }
        if (IS_ATOM_INT(_i_10567)) {
            _5916 = _5915 - _i_10567;
        }
        else {
            _5916 = NewDouble((eudouble)_5915 - DBL_PTR(_i_10567)->dbl);
        }
        _5915 = NOVALUE;
        _5917 = Repeat(_5518, _5916);
        DeRef(_5916);
        _5916 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_10537)){
                _5918 = SEQ_PTR(_expanded_path_10537)->length;
        }
        else {
            _5918 = 1;
        }
        rhs_slice_target = (object_ptr)&_5919;
        RHS_Slice(_expanded_path_10537, _i_10567, _5918);
        Concat((object_ptr)&_expanded_path_10537, _5917, _5919);
        DeRefDS(_5917);
        _5917 = NOVALUE;
        DeRef(_5917);
        _5917 = NOVALUE;
        DeRefDS(_5919);
        _5919 = NOVALUE;

        /** filesys.e:1924				expanded_path = stdseq:join(expanded_path, SLASH)*/
        RefDS(_expanded_path_10537);
        _0 = _expanded_path_10537;
        _expanded_path_10537 = _24join(_expanded_path_10537, 47);
        DeRefDS(_0);

        /** filesys.e:1925				if length(expanded_path) < length(orig_path) then*/
        if (IS_SEQUENCE(_expanded_path_10537)){
                _5922 = SEQ_PTR(_expanded_path_10537)->length;
        }
        else {
            _5922 = 1;
        }
        if (IS_SEQUENCE(_orig_path_10535)){
                _5923 = SEQ_PTR(_orig_path_10535)->length;
        }
        else {
            _5923 = 1;
        }
        if (_5922 >= _5923)
        goto L7; // [282] 305

        /** filesys.e:1927			  		return expanded_path*/
        DeRef(_i_10567);
        DeRefDS(_orig_path_10535);
        DeRefDS(_base_paths_10536);
        DeRef(_lowered_expanded_path_10548);
        DeRef(_5899);
        _5899 = NOVALUE;
        DeRef(_5910);
        _5910 = NOVALUE;
        DeRef(_5901);
        _5901 = NOVALUE;
        _5897 = NOVALUE;
        return _expanded_path_10537;

        /** filesys.e:1929				exit*/
        goto L7; // [295] 305
L8: 

        /** filesys.e:1931		end for*/
        _0 = _i_10567;
        if (IS_ATOM_INT(_i_10567)) {
            _i_10567 = _i_10567 + 1;
            if ((object)((uintptr_t)_i_10567 +(uintptr_t) HIGH_BITS) >= 0){
                _i_10567 = NewDouble((eudouble)_i_10567);
            }
        }
        else {
            _i_10567 = binary_op_a(PLUS, _i_10567, 1);
        }
        DeRef(_0);
        goto L6; // [300] 208
L7: 
        ;
        DeRef(_i_10567);
    }

    /** filesys.e:1934		return orig_path*/
    DeRefDS(_base_paths_10536);
    DeRef(_expanded_path_10537);
    DeRef(_lowered_expanded_path_10548);
    DeRef(_5899);
    _5899 = NOVALUE;
    DeRef(_5910);
    _5910 = NOVALUE;
    DeRef(_5901);
    _5901 = NOVALUE;
    _5897 = NOVALUE;
    return _orig_path_10535;
    ;
}


object _14file_type(object _filename_10625)
{
    object _dirfil_10626 = NOVALUE;
    object _5956 = NOVALUE;
    object _5955 = NOVALUE;
    object _5954 = NOVALUE;
    object _5953 = NOVALUE;
    object _5952 = NOVALUE;
    object _5950 = NOVALUE;
    object _5949 = NOVALUE;
    object _5948 = NOVALUE;
    object _5947 = NOVALUE;
    object _5946 = NOVALUE;
    object _5945 = NOVALUE;
    object _5944 = NOVALUE;
    object _5942 = NOVALUE;
    object _5940 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:2040		if eu:find('*', filename) or eu:find('?', filename) then return FILETYPE_UNDEFINED end if*/
    _5940 = find_from(42, _filename_10625, 1);
    if (_5940 != 0) {
        goto L1; // [10] 24
    }
    _5942 = find_from(63, _filename_10625, 1);
    if (_5942 == 0)
    {
        _5942 = NOVALUE;
        goto L2; // [20] 29
    }
    else{
        _5942 = NOVALUE;
    }
L1: 
    DeRefDS(_filename_10625);
    DeRef(_dirfil_10626);
    return -1;
L2: 

    /** filesys.e:2042		ifdef WINDOWS then*/

    /** filesys.e:2048		dirfil = dir(filename)*/
    RefDS(_filename_10625);
    _0 = _dirfil_10626;
    _dirfil_10626 = _14dir(_filename_10625);
    DeRef(_0);

    /** filesys.e:2049		if sequence(dirfil) then*/
    _5944 = IS_SEQUENCE(_dirfil_10626);
    if (_5944 == 0)
    {
        _5944 = NOVALUE;
        goto L3; // [42] 126
    }
    else{
        _5944 = NOVALUE;
    }

    /** filesys.e:2050			if length( dirfil ) > 1 or eu:find('d', dirfil[1][2]) or (length(filename)=3 and filename[2]=':') then*/
    if (IS_SEQUENCE(_dirfil_10626)){
            _5945 = SEQ_PTR(_dirfil_10626)->length;
    }
    else {
        _5945 = 1;
    }
    _5946 = (_5945 > 1);
    _5945 = NOVALUE;
    if (_5946 != 0) {
        _5947 = 1;
        goto L4; // [54] 75
    }
    _2 = (object)SEQ_PTR(_dirfil_10626);
    _5948 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_5948);
    _5949 = (object)*(((s1_ptr)_2)->base + 2);
    _5948 = NOVALUE;
    _5950 = find_from(100, _5949, 1);
    _5949 = NOVALUE;
    _5947 = (_5950 != 0);
L4: 
    if (_5947 != 0) {
        goto L5; // [75] 107
    }
    if (IS_SEQUENCE(_filename_10625)){
            _5952 = SEQ_PTR(_filename_10625)->length;
    }
    else {
        _5952 = 1;
    }
    _5953 = (_5952 == 3);
    _5952 = NOVALUE;
    if (_5953 == 0) {
        DeRef(_5954);
        _5954 = 0;
        goto L6; // [86] 102
    }
    _2 = (object)SEQ_PTR(_filename_10625);
    _5955 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_5955)) {
        _5956 = (_5955 == 58);
    }
    else {
        _5956 = binary_op(EQUALS, _5955, 58);
    }
    _5955 = NOVALUE;
    if (IS_ATOM_INT(_5956))
    _5954 = (_5956 != 0);
    else
    _5954 = DBL_PTR(_5956)->dbl != 0.0;
L6: 
    if (_5954 == 0)
    {
        _5954 = NOVALUE;
        goto L7; // [103] 116
    }
    else{
        _5954 = NOVALUE;
    }
L5: 

    /** filesys.e:2051				return FILETYPE_DIRECTORY*/
    DeRefDS(_filename_10625);
    DeRef(_dirfil_10626);
    DeRef(_5953);
    _5953 = NOVALUE;
    DeRef(_5946);
    _5946 = NOVALUE;
    DeRef(_5956);
    _5956 = NOVALUE;
    return 2;
    goto L8; // [113] 133
L7: 

    /** filesys.e:2053				return FILETYPE_FILE*/
    DeRefDS(_filename_10625);
    DeRef(_dirfil_10626);
    DeRef(_5953);
    _5953 = NOVALUE;
    DeRef(_5946);
    _5946 = NOVALUE;
    DeRef(_5956);
    _5956 = NOVALUE;
    return 1;
    goto L8; // [123] 133
L3: 

    /** filesys.e:2056			return FILETYPE_NOT_FOUND*/
    DeRefDS(_filename_10625);
    DeRef(_dirfil_10626);
    DeRef(_5953);
    _5953 = NOVALUE;
    DeRef(_5946);
    _5946 = NOVALUE;
    DeRef(_5956);
    _5956 = NOVALUE;
    return 0;
L8: 
    ;
}


object _14file_exists(object _name_10665)
{
    object _pName_10668 = NOVALUE;
    object _r_10670 = NOVALUE;
    object _5961 = NOVALUE;
    object _5959 = NOVALUE;
    object _5957 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:2103		if atom(name) then*/
    _5957 = IS_ATOM(_name_10665);
    if (_5957 == 0)
    {
        _5957 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _5957 = NOVALUE;
    }

    /** filesys.e:2104			return 0*/
    DeRef(_name_10665);
    DeRef(_pName_10668);
    DeRef(_r_10670);
    return 0;
L1: 

    /** filesys.e:2107		ifdef WINDOWS then*/

    /** filesys.e:2115			atom pName = machine:allocate_string(name)*/
    Ref(_name_10665);
    _0 = _pName_10668;
    _pName_10668 = _4allocate_string(_name_10665, 0);
    DeRef(_0);

    /** filesys.e:2116			atom r = c_func(xGetFileAttributes, {pName, 0})*/
    Ref(_pName_10668);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _pName_10668;
    ((intptr_t *)_2)[2] = 0;
    _5959 = MAKE_SEQ(_1);
    DeRef(_r_10670);
    _r_10670 = call_c(1, _14xGetFileAttributes_9741, _5959);
    DeRefDS(_5959);
    _5959 = NOVALUE;

    /** filesys.e:2117			machine:free(pName)*/
    Ref(_pName_10668);
    _4free(_pName_10668);

    /** filesys.e:2119			return r = 0*/
    if (IS_ATOM_INT(_r_10670)) {
        _5961 = (_r_10670 == 0);
    }
    else {
        _5961 = (DBL_PTR(_r_10670)->dbl == (eudouble)0);
    }
    DeRef(_name_10665);
    DeRef(_pName_10668);
    DeRef(_r_10670);
    return _5961;
    ;
}


object _14file_timestamp(object _fname_10676)
{
    object _d_10677 = NOVALUE;
    object _5976 = NOVALUE;
    object _5975 = NOVALUE;
    object _5974 = NOVALUE;
    object _5973 = NOVALUE;
    object _5972 = NOVALUE;
    object _5971 = NOVALUE;
    object _5970 = NOVALUE;
    object _5969 = NOVALUE;
    object _5968 = NOVALUE;
    object _5967 = NOVALUE;
    object _5966 = NOVALUE;
    object _5965 = NOVALUE;
    object _5964 = NOVALUE;
    object _5963 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:2139		object d = dir(fname)*/
    RefDS(_fname_10676);
    _0 = _d_10677;
    _d_10677 = _14dir(_fname_10676);
    DeRef(_0);

    /** filesys.e:2140		if atom(d) then return -1 end if*/
    _5963 = IS_ATOM(_d_10677);
    if (_5963 == 0)
    {
        _5963 = NOVALUE;
        goto L1; // [14] 22
    }
    else{
        _5963 = NOVALUE;
    }
    DeRefDS(_fname_10676);
    DeRef(_d_10677);
    return -1;
L1: 

    /** filesys.e:2142		return datetime:new(d[1][D_YEAR], d[1][D_MONTH], d[1][D_DAY],*/
    _2 = (object)SEQ_PTR(_d_10677);
    _5964 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_5964);
    _5965 = (object)*(((s1_ptr)_2)->base + 4);
    _5964 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_10677);
    _5966 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_5966);
    _5967 = (object)*(((s1_ptr)_2)->base + 5);
    _5966 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_10677);
    _5968 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_5968);
    _5969 = (object)*(((s1_ptr)_2)->base + 6);
    _5968 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_10677);
    _5970 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_5970);
    _5971 = (object)*(((s1_ptr)_2)->base + 7);
    _5970 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_10677);
    _5972 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_5972);
    _5973 = (object)*(((s1_ptr)_2)->base + 8);
    _5972 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_10677);
    _5974 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_5974);
    _5975 = (object)*(((s1_ptr)_2)->base + 9);
    _5974 = NOVALUE;
    Ref(_5965);
    Ref(_5967);
    Ref(_5969);
    Ref(_5971);
    Ref(_5973);
    Ref(_5975);
    _5976 = _15new(_5965, _5967, _5969, _5971, _5973, _5975);
    _5965 = NOVALUE;
    _5967 = NOVALUE;
    _5969 = NOVALUE;
    _5971 = NOVALUE;
    _5973 = NOVALUE;
    _5975 = NOVALUE;
    DeRefDS(_fname_10676);
    DeRef(_d_10677);
    return _5976;
    ;
}


object _14locate_file(object _filename_10865, object _search_list_10866, object _subdir_10867)
{
    object _extra_paths_10868 = NOVALUE;
    object _this_path_10869 = NOVALUE;
    object _6145 = NOVALUE;
    object _6144 = NOVALUE;
    object _6142 = NOVALUE;
    object _6140 = NOVALUE;
    object _6138 = NOVALUE;
    object _6137 = NOVALUE;
    object _6136 = NOVALUE;
    object _6134 = NOVALUE;
    object _6133 = NOVALUE;
    object _6132 = NOVALUE;
    object _6130 = NOVALUE;
    object _6129 = NOVALUE;
    object _6128 = NOVALUE;
    object _6125 = NOVALUE;
    object _6124 = NOVALUE;
    object _6122 = NOVALUE;
    object _6120 = NOVALUE;
    object _6119 = NOVALUE;
    object _6116 = NOVALUE;
    object _6111 = NOVALUE;
    object _6107 = NOVALUE;
    object _6099 = NOVALUE;
    object _6096 = NOVALUE;
    object _6093 = NOVALUE;
    object _6092 = NOVALUE;
    object _6088 = NOVALUE;
    object _6085 = NOVALUE;
    object _6083 = NOVALUE;
    object _6079 = NOVALUE;
    object _6077 = NOVALUE;
    object _6076 = NOVALUE;
    object _6072 = NOVALUE;
    object _6071 = NOVALUE;
    object _6068 = NOVALUE;
    object _6066 = NOVALUE;
    object _6065 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:2525		if absolute_path(filename) then*/
    RefDS(_filename_10865);
    _6065 = _14absolute_path(_filename_10865);
    if (_6065 == 0) {
        DeRef(_6065);
        _6065 = NOVALUE;
        goto L1; // [13] 23
    }
    else {
        if (!IS_ATOM_INT(_6065) && DBL_PTR(_6065)->dbl == 0.0){
            DeRef(_6065);
            _6065 = NOVALUE;
            goto L1; // [13] 23
        }
        DeRef(_6065);
        _6065 = NOVALUE;
    }
    DeRef(_6065);
    _6065 = NOVALUE;

    /** filesys.e:2526			return filename*/
    DeRefDS(_search_list_10866);
    DeRefDS(_subdir_10867);
    DeRef(_extra_paths_10868);
    DeRef(_this_path_10869);
    return _filename_10865;
L1: 

    /** filesys.e:2529		if length(search_list) = 0 then*/
    if (IS_SEQUENCE(_search_list_10866)){
            _6066 = SEQ_PTR(_search_list_10866)->length;
    }
    else {
        _6066 = 1;
    }
    if (_6066 != 0)
    goto L2; // [28] 281

    /** filesys.e:2530			search_list = append(search_list, "." & SLASH)*/
    Append(&_6068, _5451, 47);
    RefDS(_6068);
    Append(&_search_list_10866, _search_list_10866, _6068);
    DeRefDS(_6068);
    _6068 = NOVALUE;

    /** filesys.e:2532			extra_paths = command_line()*/
    DeRef(_extra_paths_10868);
    _extra_paths_10868 = Command_Line();

    /** filesys.e:2533			extra_paths = canonical_path(dirname(extra_paths[2]), 1)*/
    _2 = (object)SEQ_PTR(_extra_paths_10868);
    _6071 = (object)*(((s1_ptr)_2)->base + 2);
    RefDS(_6071);
    _6072 = _14dirname(_6071, 0);
    _6071 = NOVALUE;
    _0 = _extra_paths_10868;
    _extra_paths_10868 = _14canonical_path(_6072, 1, 0);
    DeRefDS(_0);
    _6072 = NOVALUE;

    /** filesys.e:2534			search_list = append(search_list, extra_paths)*/
    Ref(_extra_paths_10868);
    Append(&_search_list_10866, _search_list_10866, _extra_paths_10868);

    /** filesys.e:2536			ifdef UNIX then*/

    /** filesys.e:2537				extra_paths = getenv("HOME")*/
    DeRef(_extra_paths_10868);
    _extra_paths_10868 = EGetEnv(_5729);

    /** filesys.e:2543			if sequence(extra_paths) then*/
    _6076 = IS_SEQUENCE(_extra_paths_10868);
    if (_6076 == 0)
    {
        _6076 = NOVALUE;
        goto L3; // [81] 95
    }
    else{
        _6076 = NOVALUE;
    }

    /** filesys.e:2544				search_list = append(search_list, extra_paths & SLASH)*/
    if (IS_SEQUENCE(_extra_paths_10868) && IS_ATOM(47)) {
        Append(&_6077, _extra_paths_10868, 47);
    }
    else if (IS_ATOM(_extra_paths_10868) && IS_SEQUENCE(47)) {
    }
    else {
        Concat((object_ptr)&_6077, _extra_paths_10868, 47);
    }
    RefDS(_6077);
    Append(&_search_list_10866, _search_list_10866, _6077);
    DeRefDS(_6077);
    _6077 = NOVALUE;
L3: 

    /** filesys.e:2547			search_list = append(search_list, ".." & SLASH)*/
    Append(&_6079, _5518, 47);
    RefDS(_6079);
    Append(&_search_list_10866, _search_list_10866, _6079);
    DeRefDS(_6079);
    _6079 = NOVALUE;

    /** filesys.e:2549			extra_paths = getenv("EUDIR")*/
    DeRef(_extra_paths_10868);
    _extra_paths_10868 = EGetEnv(_6081);

    /** filesys.e:2550			if sequence(extra_paths) then*/
    _6083 = IS_SEQUENCE(_extra_paths_10868);
    if (_6083 == 0)
    {
        _6083 = NOVALUE;
        goto L4; // [115] 145
    }
    else{
        _6083 = NOVALUE;
    }

    /** filesys.e:2551				search_list = append(search_list, extra_paths & SLASH & "bin" & SLASH)*/
    {
        object concat_list[4];

        concat_list[0] = 47;
        concat_list[1] = _6084;
        concat_list[2] = 47;
        concat_list[3] = _extra_paths_10868;
        Concat_N((object_ptr)&_6085, concat_list, 4);
    }
    RefDS(_6085);
    Append(&_search_list_10866, _search_list_10866, _6085);
    DeRefDS(_6085);
    _6085 = NOVALUE;

    /** filesys.e:2552				search_list = append(search_list, extra_paths & SLASH & "docs" & SLASH)*/
    {
        object concat_list[4];

        concat_list[0] = 47;
        concat_list[1] = _6087;
        concat_list[2] = 47;
        concat_list[3] = _extra_paths_10868;
        Concat_N((object_ptr)&_6088, concat_list, 4);
    }
    RefDS(_6088);
    Append(&_search_list_10866, _search_list_10866, _6088);
    DeRefDS(_6088);
    _6088 = NOVALUE;
L4: 

    /** filesys.e:2555			extra_paths = getenv("EUDIST")*/
    DeRef(_extra_paths_10868);
    _extra_paths_10868 = EGetEnv(_6090);

    /** filesys.e:2556			if sequence(extra_paths) then*/
    _6092 = IS_SEQUENCE(_extra_paths_10868);
    if (_6092 == 0)
    {
        _6092 = NOVALUE;
        goto L5; // [155] 195
    }
    else{
        _6092 = NOVALUE;
    }

    /** filesys.e:2557				search_list = append(search_list, extra_paths & SLASH)*/
    if (IS_SEQUENCE(_extra_paths_10868) && IS_ATOM(47)) {
        Append(&_6093, _extra_paths_10868, 47);
    }
    else if (IS_ATOM(_extra_paths_10868) && IS_SEQUENCE(47)) {
    }
    else {
        Concat((object_ptr)&_6093, _extra_paths_10868, 47);
    }
    RefDS(_6093);
    Append(&_search_list_10866, _search_list_10866, _6093);
    DeRefDS(_6093);
    _6093 = NOVALUE;

    /** filesys.e:2558				search_list = append(search_list, extra_paths & SLASH & "etc" & SLASH)*/
    {
        object concat_list[4];

        concat_list[0] = 47;
        concat_list[1] = _6095;
        concat_list[2] = 47;
        concat_list[3] = _extra_paths_10868;
        Concat_N((object_ptr)&_6096, concat_list, 4);
    }
    RefDS(_6096);
    Append(&_search_list_10866, _search_list_10866, _6096);
    DeRefDS(_6096);
    _6096 = NOVALUE;

    /** filesys.e:2559				search_list = append(search_list, extra_paths & SLASH & "data" & SLASH)*/
    {
        object concat_list[4];

        concat_list[0] = 47;
        concat_list[1] = _6098;
        concat_list[2] = 47;
        concat_list[3] = _extra_paths_10868;
        Concat_N((object_ptr)&_6099, concat_list, 4);
    }
    RefDS(_6099);
    Append(&_search_list_10866, _search_list_10866, _6099);
    DeRefDS(_6099);
    _6099 = NOVALUE;
L5: 

    /** filesys.e:2562			ifdef UNIX then*/

    /** filesys.e:2564				search_list = append( search_list, "/usr/local/share/euphoria/bin/" )*/
    RefDS(_6101);
    Append(&_search_list_10866, _search_list_10866, _6101);

    /** filesys.e:2565				search_list = append( search_list, "/usr/share/euphoria/bin/" )*/
    RefDS(_6103);
    Append(&_search_list_10866, _search_list_10866, _6103);

    /** filesys.e:2568			search_list &= include_paths(1)*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_6106);
    ((intptr_t*)_2)[1] = _6106;
    RefDS(_6105);
    ((intptr_t*)_2)[2] = _6105;
    _6107 = MAKE_SEQ(_1);
    Concat((object_ptr)&_search_list_10866, _search_list_10866, _6107);
    DeRefDS(_6107);
    _6107 = NOVALUE;

    /** filesys.e:2571			extra_paths = getenv("USERPATH")*/
    DeRef(_extra_paths_10868);
    _extra_paths_10868 = EGetEnv(_6109);

    /** filesys.e:2572			if sequence(extra_paths) then*/
    _6111 = IS_SEQUENCE(_extra_paths_10868);
    if (_6111 == 0)
    {
        _6111 = NOVALUE;
        goto L6; // [230] 249
    }
    else{
        _6111 = NOVALUE;
    }

    /** filesys.e:2573				extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_10868);
    _0 = _extra_paths_10868;
    _extra_paths_10868 = _24split(_extra_paths_10868, 58, 0, 0);
    DeRefi(_0);

    /** filesys.e:2574				search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_10866) && IS_ATOM(_extra_paths_10868)) {
        Ref(_extra_paths_10868);
        Append(&_search_list_10866, _search_list_10866, _extra_paths_10868);
    }
    else if (IS_ATOM(_search_list_10866) && IS_SEQUENCE(_extra_paths_10868)) {
    }
    else {
        Concat((object_ptr)&_search_list_10866, _search_list_10866, _extra_paths_10868);
    }
L6: 

    /** filesys.e:2577			extra_paths = getenv("PATH")*/
    DeRef(_extra_paths_10868);
    _extra_paths_10868 = EGetEnv(_6114);

    /** filesys.e:2578			if sequence(extra_paths) then*/
    _6116 = IS_SEQUENCE(_extra_paths_10868);
    if (_6116 == 0)
    {
        _6116 = NOVALUE;
        goto L7; // [259] 306
    }
    else{
        _6116 = NOVALUE;
    }

    /** filesys.e:2579				extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_10868);
    _0 = _extra_paths_10868;
    _extra_paths_10868 = _24split(_extra_paths_10868, 58, 0, 0);
    DeRefi(_0);

    /** filesys.e:2580				search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_10866) && IS_ATOM(_extra_paths_10868)) {
        Ref(_extra_paths_10868);
        Append(&_search_list_10866, _search_list_10866, _extra_paths_10868);
    }
    else if (IS_ATOM(_search_list_10866) && IS_SEQUENCE(_extra_paths_10868)) {
    }
    else {
        Concat((object_ptr)&_search_list_10866, _search_list_10866, _extra_paths_10868);
    }
    goto L7; // [278] 306
L2: 

    /** filesys.e:2583			if integer(search_list[1]) then*/
    _2 = (object)SEQ_PTR(_search_list_10866);
    _6119 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6119))
    _6120 = 1;
    else if (IS_ATOM_DBL(_6119))
    _6120 = IS_ATOM_INT(DoubleToInt(_6119));
    else
    _6120 = 0;
    _6119 = NOVALUE;
    if (_6120 == 0)
    {
        _6120 = NOVALUE;
        goto L8; // [290] 305
    }
    else{
        _6120 = NOVALUE;
    }

    /** filesys.e:2584				search_list = stdseq:split(search_list, PATHSEP)*/
    RefDS(_search_list_10866);
    _0 = _search_list_10866;
    _search_list_10866 = _24split(_search_list_10866, 58, 0, 0);
    DeRefDS(_0);
L8: 
L7: 

    /** filesys.e:2588		if length(subdir) > 0 then*/
    if (IS_SEQUENCE(_subdir_10867)){
            _6122 = SEQ_PTR(_subdir_10867)->length;
    }
    else {
        _6122 = 1;
    }
    if (_6122 <= 0)
    goto L9; // [311] 336

    /** filesys.e:2589			if subdir[$] != SLASH then*/
    if (IS_SEQUENCE(_subdir_10867)){
            _6124 = SEQ_PTR(_subdir_10867)->length;
    }
    else {
        _6124 = 1;
    }
    _2 = (object)SEQ_PTR(_subdir_10867);
    _6125 = (object)*(((s1_ptr)_2)->base + _6124);
    if (binary_op_a(EQUALS, _6125, 47)){
        _6125 = NOVALUE;
        goto LA; // [324] 335
    }
    _6125 = NOVALUE;

    /** filesys.e:2590				subdir &= SLASH*/
    Append(&_subdir_10867, _subdir_10867, 47);
LA: 
L9: 

    /** filesys.e:2594		for i = 1 to length(search_list) do*/
    if (IS_SEQUENCE(_search_list_10866)){
            _6128 = SEQ_PTR(_search_list_10866)->length;
    }
    else {
        _6128 = 1;
    }
    {
        object _i_10945;
        _i_10945 = 1;
LB: 
        if (_i_10945 > _6128){
            goto LC; // [341] 464
        }

        /** filesys.e:2595			if length(search_list[i]) = 0 then*/
        _2 = (object)SEQ_PTR(_search_list_10866);
        _6129 = (object)*(((s1_ptr)_2)->base + _i_10945);
        if (IS_SEQUENCE(_6129)){
                _6130 = SEQ_PTR(_6129)->length;
        }
        else {
            _6130 = 1;
        }
        _6129 = NOVALUE;
        if (_6130 != 0)
        goto LD; // [357] 366

        /** filesys.e:2596				continue*/
        goto LE; // [363] 459
LD: 

        /** filesys.e:2599			if search_list[i][$] != SLASH then*/
        _2 = (object)SEQ_PTR(_search_list_10866);
        _6132 = (object)*(((s1_ptr)_2)->base + _i_10945);
        if (IS_SEQUENCE(_6132)){
                _6133 = SEQ_PTR(_6132)->length;
        }
        else {
            _6133 = 1;
        }
        _2 = (object)SEQ_PTR(_6132);
        _6134 = (object)*(((s1_ptr)_2)->base + _6133);
        _6132 = NOVALUE;
        if (binary_op_a(EQUALS, _6134, 47)){
            _6134 = NOVALUE;
            goto LF; // [379] 398
        }
        _6134 = NOVALUE;

        /** filesys.e:2600				search_list[i] &= SLASH*/
        _2 = (object)SEQ_PTR(_search_list_10866);
        _6136 = (object)*(((s1_ptr)_2)->base + _i_10945);
        if (IS_SEQUENCE(_6136) && IS_ATOM(47)) {
            Append(&_6137, _6136, 47);
        }
        else if (IS_ATOM(_6136) && IS_SEQUENCE(47)) {
        }
        else {
            Concat((object_ptr)&_6137, _6136, 47);
            _6136 = NOVALUE;
        }
        _6136 = NOVALUE;
        _2 = (object)SEQ_PTR(_search_list_10866);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _search_list_10866 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_10945);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _6137;
        if( _1 != _6137 ){
            DeRef(_1);
        }
        _6137 = NOVALUE;
LF: 

        /** filesys.e:2604			if length(subdir) > 0 then*/
        if (IS_SEQUENCE(_subdir_10867)){
                _6138 = SEQ_PTR(_subdir_10867)->length;
        }
        else {
            _6138 = 1;
        }
        if (_6138 <= 0)
        goto L10; // [403] 422

        /** filesys.e:2605				this_path = search_list[i] & subdir & filename*/
        _2 = (object)SEQ_PTR(_search_list_10866);
        _6140 = (object)*(((s1_ptr)_2)->base + _i_10945);
        {
            object concat_list[3];

            concat_list[0] = _filename_10865;
            concat_list[1] = _subdir_10867;
            concat_list[2] = _6140;
            Concat_N((object_ptr)&_this_path_10869, concat_list, 3);
        }
        _6140 = NOVALUE;
        goto L11; // [419] 433
L10: 

        /** filesys.e:2607				this_path = search_list[i] & filename*/
        _2 = (object)SEQ_PTR(_search_list_10866);
        _6142 = (object)*(((s1_ptr)_2)->base + _i_10945);
        if (IS_SEQUENCE(_6142) && IS_ATOM(_filename_10865)) {
        }
        else if (IS_ATOM(_6142) && IS_SEQUENCE(_filename_10865)) {
            Ref(_6142);
            Prepend(&_this_path_10869, _filename_10865, _6142);
        }
        else {
            Concat((object_ptr)&_this_path_10869, _6142, _filename_10865);
            _6142 = NOVALUE;
        }
        _6142 = NOVALUE;
L11: 

        /** filesys.e:2610			if file_exists(this_path) then*/
        RefDS(_this_path_10869);
        _6144 = _14file_exists(_this_path_10869);
        if (_6144 == 0) {
            DeRef(_6144);
            _6144 = NOVALUE;
            goto L12; // [441] 457
        }
        else {
            if (!IS_ATOM_INT(_6144) && DBL_PTR(_6144)->dbl == 0.0){
                DeRef(_6144);
                _6144 = NOVALUE;
                goto L12; // [441] 457
            }
            DeRef(_6144);
            _6144 = NOVALUE;
        }
        DeRef(_6144);
        _6144 = NOVALUE;

        /** filesys.e:2611				return canonical_path(this_path)*/
        RefDS(_this_path_10869);
        _6145 = _14canonical_path(_this_path_10869, 0, 0);
        DeRefDS(_filename_10865);
        DeRefDS(_search_list_10866);
        DeRefDS(_subdir_10867);
        DeRef(_extra_paths_10868);
        DeRefDS(_this_path_10869);
        _6129 = NOVALUE;
        return _6145;
L12: 

        /** filesys.e:2614		end for*/
LE: 
        _i_10945 = _i_10945 + 1;
        goto LB; // [459] 348
LC: 
        ;
    }

    /** filesys.e:2615		return filename*/
    DeRefDS(_search_list_10866);
    DeRefDS(_subdir_10867);
    DeRef(_extra_paths_10868);
    DeRef(_this_path_10869);
    DeRef(_6145);
    _6145 = NOVALUE;
    _6129 = NOVALUE;
    return _filename_10865;
    ;
}


object _14count_files(object _orig_path_11041, object _dir_info_11042, object _inst_11043)
{
    object _pos_11044 = NOVALUE;
    object _ext_11045 = NOVALUE;
    object _fileext_inlined_fileext_at_218_11086 = NOVALUE;
    object _data_inlined_fileext_at_218_11085 = NOVALUE;
    object _path_inlined_fileext_at_215_11084 = NOVALUE;
    object _6245 = NOVALUE;
    object _6244 = NOVALUE;
    object _6243 = NOVALUE;
    object _6241 = NOVALUE;
    object _6240 = NOVALUE;
    object _6239 = NOVALUE;
    object _6238 = NOVALUE;
    object _6236 = NOVALUE;
    object _6235 = NOVALUE;
    object _6233 = NOVALUE;
    object _6232 = NOVALUE;
    object _6231 = NOVALUE;
    object _6230 = NOVALUE;
    object _6229 = NOVALUE;
    object _6228 = NOVALUE;
    object _6227 = NOVALUE;
    object _6225 = NOVALUE;
    object _6224 = NOVALUE;
    object _6222 = NOVALUE;
    object _6221 = NOVALUE;
    object _6220 = NOVALUE;
    object _6219 = NOVALUE;
    object _6218 = NOVALUE;
    object _6217 = NOVALUE;
    object _6216 = NOVALUE;
    object _6215 = NOVALUE;
    object _6214 = NOVALUE;
    object _6213 = NOVALUE;
    object _6212 = NOVALUE;
    object _6211 = NOVALUE;
    object _6210 = NOVALUE;
    object _6208 = NOVALUE;
    object _6207 = NOVALUE;
    object _6206 = NOVALUE;
    object _6205 = NOVALUE;
    object _6203 = NOVALUE;
    object _6202 = NOVALUE;
    object _6201 = NOVALUE;
    object _6200 = NOVALUE;
    object _6199 = NOVALUE;
    object _6198 = NOVALUE;
    object _6197 = NOVALUE;
    object _6195 = NOVALUE;
    object _6194 = NOVALUE;
    object _6193 = NOVALUE;
    object _6192 = NOVALUE;
    object _6191 = NOVALUE;
    object _6190 = NOVALUE;
    object _6187 = NOVALUE;
    object _6186 = NOVALUE;
    object _6185 = NOVALUE;
    object _6184 = NOVALUE;
    object _6183 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** filesys.e:2777		integer pos = 0*/
    _pos_11044 = 0;

    /** filesys.e:2780		orig_path = orig_path*/
    RefDS(_orig_path_11041);
    DeRefDS(_orig_path_11041);
    _orig_path_11041 = _orig_path_11041;

    /** filesys.e:2781		if equal(dir_info[D_NAME], ".") then*/
    _2 = (object)SEQ_PTR(_dir_info_11042);
    _6183 = (object)*(((s1_ptr)_2)->base + 1);
    if (_6183 == _5451)
    _6184 = 1;
    else if (IS_ATOM_INT(_6183) && IS_ATOM_INT(_5451))
    _6184 = 0;
    else
    _6184 = (compare(_6183, _5451) == 0);
    _6183 = NOVALUE;
    if (_6184 == 0)
    {
        _6184 = NOVALUE;
        goto L1; // [29] 39
    }
    else{
        _6184 = NOVALUE;
    }

    /** filesys.e:2782			return 0*/
    DeRefDS(_orig_path_11041);
    DeRefDS(_dir_info_11042);
    DeRefDS(_inst_11043);
    DeRef(_ext_11045);
    return 0;
L1: 

    /** filesys.e:2784		if equal(dir_info[D_NAME], "..") then*/
    _2 = (object)SEQ_PTR(_dir_info_11042);
    _6185 = (object)*(((s1_ptr)_2)->base + 1);
    if (_6185 == _5518)
    _6186 = 1;
    else if (IS_ATOM_INT(_6185) && IS_ATOM_INT(_5518))
    _6186 = 0;
    else
    _6186 = (compare(_6185, _5518) == 0);
    _6185 = NOVALUE;
    if (_6186 == 0)
    {
        _6186 = NOVALUE;
        goto L2; // [49] 59
    }
    else{
        _6186 = NOVALUE;
    }

    /** filesys.e:2785			return 0*/
    DeRefDS(_orig_path_11041);
    DeRefDS(_dir_info_11042);
    DeRefDS(_inst_11043);
    DeRef(_ext_11045);
    return 0;
L2: 

    /** filesys.e:2789		if inst[1] = 0 then -- count all is false*/
    _2 = (object)SEQ_PTR(_inst_11043);
    _6187 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _6187, 0)){
        _6187 = NOVALUE;
        goto L3; // [65] 112
    }
    _6187 = NOVALUE;

    /** filesys.e:2790			if find('h', dir_info[D_ATTRIBUTES]) then*/
    _2 = (object)SEQ_PTR(_dir_info_11042);
    _6190 = (object)*(((s1_ptr)_2)->base + 2);
    _6191 = find_from(104, _6190, 1);
    _6190 = NOVALUE;
    if (_6191 == 0)
    {
        _6191 = NOVALUE;
        goto L4; // [80] 90
    }
    else{
        _6191 = NOVALUE;
    }

    /** filesys.e:2791				return 0*/
    DeRefDS(_orig_path_11041);
    DeRefDS(_dir_info_11042);
    DeRefDS(_inst_11043);
    DeRef(_ext_11045);
    return 0;
L4: 

    /** filesys.e:2794			if find('s', dir_info[D_ATTRIBUTES]) then*/
    _2 = (object)SEQ_PTR(_dir_info_11042);
    _6192 = (object)*(((s1_ptr)_2)->base + 2);
    _6193 = find_from(115, _6192, 1);
    _6192 = NOVALUE;
    if (_6193 == 0)
    {
        _6193 = NOVALUE;
        goto L5; // [101] 111
    }
    else{
        _6193 = NOVALUE;
    }

    /** filesys.e:2795				return 0*/
    DeRefDS(_orig_path_11041);
    DeRefDS(_dir_info_11042);
    DeRefDS(_inst_11043);
    DeRef(_ext_11045);
    return 0;
L5: 
L3: 

    /** filesys.e:2799		file_counters[inst[2]][COUNT_SIZE] += dir_info[D_SIZE]*/
    _2 = (object)SEQ_PTR(_inst_11043);
    _6194 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_14file_counters_11038);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _14file_counters_11038 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_6194))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_6194)->dbl));
    else
    _3 = (object)(_6194 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_dir_info_11042);
    _6197 = (object)*(((s1_ptr)_2)->base + 3);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _6198 = (object)*(((s1_ptr)_2)->base + 3);
    _6195 = NOVALUE;
    if (IS_ATOM_INT(_6198) && IS_ATOM_INT(_6197)) {
        _6199 = _6198 + _6197;
        if ((object)((uintptr_t)_6199 + (uintptr_t)HIGH_BITS) >= 0){
            _6199 = NewDouble((eudouble)_6199);
        }
    }
    else {
        _6199 = binary_op(PLUS, _6198, _6197);
    }
    _6198 = NOVALUE;
    _6197 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _6199;
    if( _1 != _6199 ){
        DeRef(_1);
    }
    _6199 = NOVALUE;
    _6195 = NOVALUE;

    /** filesys.e:2800		if find('d', dir_info[D_ATTRIBUTES]) then*/
    _2 = (object)SEQ_PTR(_dir_info_11042);
    _6200 = (object)*(((s1_ptr)_2)->base + 2);
    _6201 = find_from(100, _6200, 1);
    _6200 = NOVALUE;
    if (_6201 == 0)
    {
        _6201 = NOVALUE;
        goto L6; // [152] 183
    }
    else{
        _6201 = NOVALUE;
    }

    /** filesys.e:2801			file_counters[inst[2]][COUNT_DIRS] += 1*/
    _2 = (object)SEQ_PTR(_inst_11043);
    _6202 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_14file_counters_11038);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _14file_counters_11038 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_6202))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_6202)->dbl));
    else
    _3 = (object)(_6202 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _6205 = (object)*(((s1_ptr)_2)->base + 1);
    _6203 = NOVALUE;
    if (IS_ATOM_INT(_6205)) {
        _6206 = _6205 + 1;
        if (_6206 > MAXINT){
            _6206 = NewDouble((eudouble)_6206);
        }
    }
    else
    _6206 = binary_op(PLUS, 1, _6205);
    _6205 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _6206;
    if( _1 != _6206 ){
        DeRef(_1);
    }
    _6206 = NOVALUE;
    _6203 = NOVALUE;
    goto L7; // [180] 460
L6: 

    /** filesys.e:2803			file_counters[inst[2]][COUNT_FILES] += 1*/
    _2 = (object)SEQ_PTR(_inst_11043);
    _6207 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_14file_counters_11038);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _14file_counters_11038 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_6207))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_6207)->dbl));
    else
    _3 = (object)(_6207 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _6210 = (object)*(((s1_ptr)_2)->base + 2);
    _6208 = NOVALUE;
    if (IS_ATOM_INT(_6210)) {
        _6211 = _6210 + 1;
        if (_6211 > MAXINT){
            _6211 = NewDouble((eudouble)_6211);
        }
    }
    else
    _6211 = binary_op(PLUS, 1, _6210);
    _6210 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _6211;
    if( _1 != _6211 ){
        DeRef(_1);
    }
    _6211 = NOVALUE;
    _6208 = NOVALUE;

    /** filesys.e:2804			ifdef not UNIX then*/

    /** filesys.e:2807				ext = fileext(dir_info[D_NAME])*/
    _2 = (object)SEQ_PTR(_dir_info_11042);
    _6212 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_6212);
    DeRef(_path_inlined_fileext_at_215_11084);
    _path_inlined_fileext_at_215_11084 = _6212;
    _6212 = NOVALUE;

    /** filesys.e:1403		data = pathinfo(path)*/
    Ref(_path_inlined_fileext_at_215_11084);
    _0 = _data_inlined_fileext_at_218_11085;
    _data_inlined_fileext_at_218_11085 = _14pathinfo(_path_inlined_fileext_at_215_11084, 0);
    DeRef(_0);

    /** filesys.e:1404		return data[4]*/
    DeRef(_ext_11045);
    _2 = (object)SEQ_PTR(_data_inlined_fileext_at_218_11085);
    _ext_11045 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_ext_11045);
    DeRef(_path_inlined_fileext_at_215_11084);
    _path_inlined_fileext_at_215_11084 = NOVALUE;
    DeRef(_data_inlined_fileext_at_218_11085);
    _data_inlined_fileext_at_218_11085 = NOVALUE;

    /** filesys.e:2810			pos = 0*/
    _pos_11044 = 0;

    /** filesys.e:2811			for i = 1 to length(file_counters[inst[2]][COUNT_TYPES]) do*/
    _2 = (object)SEQ_PTR(_inst_11043);
    _6213 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_14file_counters_11038);
    if (!IS_ATOM_INT(_6213)){
        _6214 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_6213)->dbl));
    }
    else{
        _6214 = (object)*(((s1_ptr)_2)->base + _6213);
    }
    _2 = (object)SEQ_PTR(_6214);
    _6215 = (object)*(((s1_ptr)_2)->base + 4);
    _6214 = NOVALUE;
    if (IS_SEQUENCE(_6215)){
            _6216 = SEQ_PTR(_6215)->length;
    }
    else {
        _6216 = 1;
    }
    _6215 = NOVALUE;
    {
        object _i_11088;
        _i_11088 = 1;
L8: 
        if (_i_11088 > _6216){
            goto L9; // [265] 322
        }

        /** filesys.e:2812				if equal(file_counters[inst[2]][COUNT_TYPES][i][EXT_NAME], ext) then*/
        _2 = (object)SEQ_PTR(_inst_11043);
        _6217 = (object)*(((s1_ptr)_2)->base + 2);
        _2 = (object)SEQ_PTR(_14file_counters_11038);
        if (!IS_ATOM_INT(_6217)){
            _6218 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_6217)->dbl));
        }
        else{
            _6218 = (object)*(((s1_ptr)_2)->base + _6217);
        }
        _2 = (object)SEQ_PTR(_6218);
        _6219 = (object)*(((s1_ptr)_2)->base + 4);
        _6218 = NOVALUE;
        _2 = (object)SEQ_PTR(_6219);
        _6220 = (object)*(((s1_ptr)_2)->base + _i_11088);
        _6219 = NOVALUE;
        _2 = (object)SEQ_PTR(_6220);
        _6221 = (object)*(((s1_ptr)_2)->base + 1);
        _6220 = NOVALUE;
        if (_6221 == _ext_11045)
        _6222 = 1;
        else if (IS_ATOM_INT(_6221) && IS_ATOM_INT(_ext_11045))
        _6222 = 0;
        else
        _6222 = (compare(_6221, _ext_11045) == 0);
        _6221 = NOVALUE;
        if (_6222 == 0)
        {
            _6222 = NOVALUE;
            goto LA; // [302] 315
        }
        else{
            _6222 = NOVALUE;
        }

        /** filesys.e:2813					pos = i*/
        _pos_11044 = _i_11088;

        /** filesys.e:2814					exit*/
        goto L9; // [312] 322
LA: 

        /** filesys.e:2816			end for*/
        _i_11088 = _i_11088 + 1;
        goto L8; // [317] 272
L9: 
        ;
    }

    /** filesys.e:2818			if pos = 0 then*/
    if (_pos_11044 != 0)
    goto LB; // [324] 385

    /** filesys.e:2819				file_counters[inst[2]][COUNT_TYPES] &= {{ext, 0, 0}}*/
    _2 = (object)SEQ_PTR(_inst_11043);
    _6224 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_14file_counters_11038);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _14file_counters_11038 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_6224))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_6224)->dbl));
    else
    _3 = (object)(_6224 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_ext_11045);
    ((intptr_t*)_2)[1] = _ext_11045;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 0;
    _6227 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _6227;
    _6228 = MAKE_SEQ(_1);
    _6227 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _6229 = (object)*(((s1_ptr)_2)->base + 4);
    _6225 = NOVALUE;
    if (IS_SEQUENCE(_6229) && IS_ATOM(_6228)) {
    }
    else if (IS_ATOM(_6229) && IS_SEQUENCE(_6228)) {
        Ref(_6229);
        Prepend(&_6230, _6228, _6229);
    }
    else {
        Concat((object_ptr)&_6230, _6229, _6228);
        _6229 = NOVALUE;
    }
    _6229 = NOVALUE;
    DeRefDS(_6228);
    _6228 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _6230;
    if( _1 != _6230 ){
        DeRef(_1);
    }
    _6230 = NOVALUE;
    _6225 = NOVALUE;

    /** filesys.e:2820				pos = length(file_counters[inst[2]][COUNT_TYPES])*/
    _2 = (object)SEQ_PTR(_inst_11043);
    _6231 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_14file_counters_11038);
    if (!IS_ATOM_INT(_6231)){
        _6232 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_6231)->dbl));
    }
    else{
        _6232 = (object)*(((s1_ptr)_2)->base + _6231);
    }
    _2 = (object)SEQ_PTR(_6232);
    _6233 = (object)*(((s1_ptr)_2)->base + 4);
    _6232 = NOVALUE;
    if (IS_SEQUENCE(_6233)){
            _pos_11044 = SEQ_PTR(_6233)->length;
    }
    else {
        _pos_11044 = 1;
    }
    _6233 = NOVALUE;
LB: 

    /** filesys.e:2823			file_counters[inst[2]][COUNT_TYPES][pos][EXT_COUNT] += 1*/
    _2 = (object)SEQ_PTR(_inst_11043);
    _6235 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_14file_counters_11038);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _14file_counters_11038 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_6235))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_6235)->dbl));
    else
    _3 = (object)(_6235 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(4 + ((s1_ptr)_2)->base);
    _6236 = NOVALUE;
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pos_11044 + ((s1_ptr)_2)->base);
    _6236 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _6238 = (object)*(((s1_ptr)_2)->base + 2);
    _6236 = NOVALUE;
    if (IS_ATOM_INT(_6238)) {
        _6239 = _6238 + 1;
        if (_6239 > MAXINT){
            _6239 = NewDouble((eudouble)_6239);
        }
    }
    else
    _6239 = binary_op(PLUS, 1, _6238);
    _6238 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _6239;
    if( _1 != _6239 ){
        DeRef(_1);
    }
    _6239 = NOVALUE;
    _6236 = NOVALUE;

    /** filesys.e:2824			file_counters[inst[2]][COUNT_TYPES][pos][EXT_SIZE] += dir_info[D_SIZE]*/
    _2 = (object)SEQ_PTR(_inst_11043);
    _6240 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_14file_counters_11038);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _14file_counters_11038 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_6240))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_6240)->dbl));
    else
    _3 = (object)(_6240 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(4 + ((s1_ptr)_2)->base);
    _6241 = NOVALUE;
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pos_11044 + ((s1_ptr)_2)->base);
    _6241 = NOVALUE;
    _2 = (object)SEQ_PTR(_dir_info_11042);
    _6243 = (object)*(((s1_ptr)_2)->base + 3);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _6244 = (object)*(((s1_ptr)_2)->base + 3);
    _6241 = NOVALUE;
    if (IS_ATOM_INT(_6244) && IS_ATOM_INT(_6243)) {
        _6245 = _6244 + _6243;
        if ((object)((uintptr_t)_6245 + (uintptr_t)HIGH_BITS) >= 0){
            _6245 = NewDouble((eudouble)_6245);
        }
    }
    else {
        _6245 = binary_op(PLUS, _6244, _6243);
    }
    _6244 = NOVALUE;
    _6243 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _6245;
    if( _1 != _6245 ){
        DeRef(_1);
    }
    _6245 = NOVALUE;
    _6241 = NOVALUE;
L7: 

    /** filesys.e:2827		return 0*/
    DeRefDS(_orig_path_11041);
    DeRefDS(_dir_info_11042);
    DeRefDS(_inst_11043);
    DeRef(_ext_11045);
    _6224 = NOVALUE;
    _6202 = NOVALUE;
    _6240 = NOVALUE;
    _6215 = NOVALUE;
    _6231 = NOVALUE;
    _6194 = NOVALUE;
    _6235 = NOVALUE;
    _6207 = NOVALUE;
    _6233 = NOVALUE;
    _6213 = NOVALUE;
    _6217 = NOVALUE;
    return 0;
    ;
}



// 0x8D79F20D
