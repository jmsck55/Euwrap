// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _43EndLineTable()
{
    object _0, _1, _2;
    

    /** parser.e:120		LineTable = append(LineTable, -2)*/
    Append(&_12LineTable_20316, _12LineTable_20316, -2);

    /** parser.e:121	end procedure*/
    return;
    ;
}


void _43CreateTopLevel()
{
    object _27813 = NOVALUE;
    object _27811 = NOVALUE;
    object _27809 = NOVALUE;
    object _27807 = NOVALUE;
    object _27805 = NOVALUE;
    object _27803 = NOVALUE;
    object _27801 = NOVALUE;
    object _27799 = NOVALUE;
    object _27797 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:125		SymTab[TopLevelSub][S_NUM_ARGS] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _27797 = NOVALUE;

    /** parser.e:126		SymTab[TopLevelSub][S_TEMPS] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TEMPS_19909))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _27799 = NOVALUE;

    /** parser.e:127		SymTab[TopLevelSub][S_CODE] = {}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_22015);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22015;
    DeRef(_1);
    _27801 = NOVALUE;

    /** parser.e:128		SymTab[TopLevelSub][S_LINETAB] = {}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_22015);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_19899))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22015;
    DeRef(_1);
    _27803 = NOVALUE;

    /** parser.e:129		SymTab[TopLevelSub][S_FIRSTLINE] = 1*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FIRSTLINE_19904))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FIRSTLINE_19904)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_FIRSTLINE_19904);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _27805 = NOVALUE;

    /** parser.e:130		SymTab[TopLevelSub][S_REFLIST] = {}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_22015);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22015;
    DeRef(_1);
    _27807 = NOVALUE;

    /** parser.e:131		SymTab[TopLevelSub][S_NREFS] = 1*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _27809 = NOVALUE;

    /** parser.e:132		SymTab[TopLevelSub][S_RESIDENT_TASK] = 1*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _27811 = NOVALUE;

    /** parser.e:133		SymTab[TopLevelSub][S_SAVED_PRIVATES] = {}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_22015);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22015;
    DeRef(_1);
    _27813 = NOVALUE;

    /** parser.e:135		Start_block( PROC, TopLevelSub )*/
    _64Start_block(27, _12TopLevelSub_20233);

    /** parser.e:136	end procedure*/
    return;
    ;
}


void _43CheckForUndefinedGotoLabels()
{
    object _27827 = NOVALUE;
    object _27826 = NOVALUE;
    object _27823 = NOVALUE;
    object _27821 = NOVALUE;
    object _27819 = NOVALUE;
    object _27817 = NOVALUE;
    object _27816 = NOVALUE;
    object _27815 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:139		for i = 1 to length(goto_delay) do*/
    if (IS_SEQUENCE(_12goto_delay_20337)){
            _27815 = SEQ_PTR(_12goto_delay_20337)->length;
    }
    else {
        _27815 = 1;
    }
    {
        object _i_55056;
        _i_55056 = 1;
L1: 
        if (_i_55056 > _27815){
            goto L2; // [8] 106
        }

        /** parser.e:140			if not equal(goto_delay[i],"") then*/
        _2 = (object)SEQ_PTR(_12goto_delay_20337);
        _27816 = (object)*(((s1_ptr)_2)->base + _i_55056);
        if (_27816 == _22015)
        _27817 = 1;
        else if (IS_ATOM_INT(_27816) && IS_ATOM_INT(_22015))
        _27817 = 0;
        else
        _27817 = (compare(_27816, _22015) == 0);
        _27816 = NOVALUE;
        if (_27817 != 0)
        goto L3; // [27] 99
        _27817 = NOVALUE;

        /** parser.e:141				line_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (object)SEQ_PTR(_43goto_line_54962);
        _27819 = (object)*(((s1_ptr)_2)->base + _i_55056);
        _2 = (object)SEQ_PTR(_27819);
        _12line_number_20227 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_12line_number_20227)){
            _12line_number_20227 = (object)DBL_PTR(_12line_number_20227)->dbl;
        }
        _27819 = NOVALUE;

        /** parser.e:142				gline_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (object)SEQ_PTR(_43goto_line_54962);
        _27821 = (object)*(((s1_ptr)_2)->base + _i_55056);
        _2 = (object)SEQ_PTR(_27821);
        _12gline_number_20231 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_12gline_number_20231)){
            _12gline_number_20231 = (object)DBL_PTR(_12gline_number_20231)->dbl;
        }
        _27821 = NOVALUE;

        /** parser.e:143				ThisLine = goto_line[i][2] -- tell compiler the correct line number*/
        _2 = (object)SEQ_PTR(_43goto_line_54962);
        _27823 = (object)*(((s1_ptr)_2)->base + _i_55056);
        DeRef(_49ThisLine_49261);
        _2 = (object)SEQ_PTR(_27823);
        _49ThisLine_49261 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_49ThisLine_49261);
        _27823 = NOVALUE;

        /** parser.e:144				bp = length(ThisLine)*/
        if (IS_SEQUENCE(_49ThisLine_49261)){
                _49bp_49265 = SEQ_PTR(_49ThisLine_49261)->length;
        }
        else {
            _49bp_49265 = 1;
        }

        /** parser.e:145					CompileErr(UNKNOWN_LABEL_1, {goto_delay[i]})*/
        _2 = (object)SEQ_PTR(_12goto_delay_20337);
        _27826 = (object)*(((s1_ptr)_2)->base + _i_55056);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_27826);
        ((intptr_t*)_2)[1] = _27826;
        _27827 = MAKE_SEQ(_1);
        _27826 = NOVALUE;
        _49CompileErr(156, _27827, 0);
        _27827 = NOVALUE;
L3: 

        /** parser.e:147		end for*/
        _i_55056 = _i_55056 + 1;
        goto L1; // [101] 15
L2: 
        ;
    }

    /** parser.e:148	end procedure*/
    return;
    ;
}


void _43PushGoto()
{
    object _new_1__tmp_at88_55091 = NOVALUE;
    object _new_inlined_new_at_88_55090 = NOVALUE;
    object _27828 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:151		goto_stack = append(goto_stack, {goto_addr, goto_list, goto_labels, goto_delay, goto_line, goto_ref, label_block, goto_init })*/
    _1 = NewS1(8);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_43goto_addr_54964);
    ((intptr_t*)_2)[1] = _43goto_addr_54964;
    RefDS(_12goto_list_20338);
    ((intptr_t*)_2)[2] = _12goto_list_20338;
    RefDS(_43goto_labels_54963);
    ((intptr_t*)_2)[3] = _43goto_labels_54963;
    RefDS(_12goto_delay_20337);
    ((intptr_t*)_2)[4] = _12goto_delay_20337;
    RefDS(_43goto_line_54962);
    ((intptr_t*)_2)[5] = _43goto_line_54962;
    RefDS(_43goto_ref_54966);
    ((intptr_t*)_2)[6] = _43goto_ref_54966;
    RefDS(_43label_block_54967);
    ((intptr_t*)_2)[7] = _43label_block_54967;
    Ref(_43goto_init_54969);
    ((intptr_t*)_2)[8] = _43goto_init_54969;
    _27828 = MAKE_SEQ(_1);
    RefDS(_27828);
    Append(&_43goto_stack_54965, _43goto_stack_54965, _27828);
    DeRefDS(_27828);
    _27828 = NOVALUE;

    /** parser.e:152		goto_addr = {}*/
    RefDS(_22015);
    DeRefDS(_43goto_addr_54964);
    _43goto_addr_54964 = _22015;

    /** parser.e:153		goto_list = {}*/
    RefDS(_22015);
    DeRefDS(_12goto_list_20338);
    _12goto_list_20338 = _22015;

    /** parser.e:154		goto_labels = {}*/
    RefDS(_22015);
    DeRefDS(_43goto_labels_54963);
    _43goto_labels_54963 = _22015;

    /** parser.e:155		goto_delay = {}*/
    RefDS(_22015);
    DeRefDS(_12goto_delay_20337);
    _12goto_delay_20337 = _22015;

    /** parser.e:156		goto_line = {}*/
    RefDS(_22015);
    DeRefDS(_43goto_line_54962);
    _43goto_line_54962 = _22015;

    /** parser.e:157		goto_ref = {}*/
    RefDS(_22015);
    DeRefDS(_43goto_ref_54966);
    _43goto_ref_54966 = _22015;

    /** parser.e:158		label_block = {}*/
    RefDS(_22015);
    DeRefDS(_43label_block_54967);
    _43label_block_54967 = _22015;

    /** parser.e:159		goto_init = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at88_55091;
    _new_1__tmp_at88_55091 = _34new_map_seq(8);
    DeRef(_0);
    Ref(_new_1__tmp_at88_55091);
    _0 = _35malloc(_new_1__tmp_at88_55091, 1);
    DeRef(_43goto_init_54969);
    _43goto_init_54969 = _0;
    DeRef(_new_1__tmp_at88_55091);
    _new_1__tmp_at88_55091 = NOVALUE;

    /** parser.e:160	end procedure*/
    return;
    ;
}


void _43PopGoto()
{
    object _27854 = NOVALUE;
    object _27852 = NOVALUE;
    object _27851 = NOVALUE;
    object _27849 = NOVALUE;
    object _27848 = NOVALUE;
    object _27846 = NOVALUE;
    object _27845 = NOVALUE;
    object _27843 = NOVALUE;
    object _27842 = NOVALUE;
    object _27840 = NOVALUE;
    object _27839 = NOVALUE;
    object _27837 = NOVALUE;
    object _27836 = NOVALUE;
    object _27834 = NOVALUE;
    object _27833 = NOVALUE;
    object _27831 = NOVALUE;
    object _27830 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:163		CheckForUndefinedGotoLabels()*/
    _43CheckForUndefinedGotoLabels();

    /** parser.e:164		goto_addr   = goto_stack[$][1]*/
    if (IS_SEQUENCE(_43goto_stack_54965)){
            _27830 = SEQ_PTR(_43goto_stack_54965)->length;
    }
    else {
        _27830 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_54965);
    _27831 = (object)*(((s1_ptr)_2)->base + _27830);
    DeRef(_43goto_addr_54964);
    _2 = (object)SEQ_PTR(_27831);
    _43goto_addr_54964 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_43goto_addr_54964);
    _27831 = NOVALUE;

    /** parser.e:165		goto_list   = goto_stack[$][2]*/
    if (IS_SEQUENCE(_43goto_stack_54965)){
            _27833 = SEQ_PTR(_43goto_stack_54965)->length;
    }
    else {
        _27833 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_54965);
    _27834 = (object)*(((s1_ptr)_2)->base + _27833);
    DeRef(_12goto_list_20338);
    _2 = (object)SEQ_PTR(_27834);
    _12goto_list_20338 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_12goto_list_20338);
    _27834 = NOVALUE;

    /** parser.e:166		goto_labels = goto_stack[$][3]*/
    if (IS_SEQUENCE(_43goto_stack_54965)){
            _27836 = SEQ_PTR(_43goto_stack_54965)->length;
    }
    else {
        _27836 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_54965);
    _27837 = (object)*(((s1_ptr)_2)->base + _27836);
    DeRef(_43goto_labels_54963);
    _2 = (object)SEQ_PTR(_27837);
    _43goto_labels_54963 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_43goto_labels_54963);
    _27837 = NOVALUE;

    /** parser.e:167		goto_delay  = goto_stack[$][4]*/
    if (IS_SEQUENCE(_43goto_stack_54965)){
            _27839 = SEQ_PTR(_43goto_stack_54965)->length;
    }
    else {
        _27839 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_54965);
    _27840 = (object)*(((s1_ptr)_2)->base + _27839);
    DeRef(_12goto_delay_20337);
    _2 = (object)SEQ_PTR(_27840);
    _12goto_delay_20337 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_12goto_delay_20337);
    _27840 = NOVALUE;

    /** parser.e:168		goto_line   = goto_stack[$][5]*/
    if (IS_SEQUENCE(_43goto_stack_54965)){
            _27842 = SEQ_PTR(_43goto_stack_54965)->length;
    }
    else {
        _27842 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_54965);
    _27843 = (object)*(((s1_ptr)_2)->base + _27842);
    DeRef(_43goto_line_54962);
    _2 = (object)SEQ_PTR(_27843);
    _43goto_line_54962 = (object)*(((s1_ptr)_2)->base + 5);
    Ref(_43goto_line_54962);
    _27843 = NOVALUE;

    /** parser.e:169		goto_ref    = goto_stack[$][6]*/
    if (IS_SEQUENCE(_43goto_stack_54965)){
            _27845 = SEQ_PTR(_43goto_stack_54965)->length;
    }
    else {
        _27845 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_54965);
    _27846 = (object)*(((s1_ptr)_2)->base + _27845);
    DeRef(_43goto_ref_54966);
    _2 = (object)SEQ_PTR(_27846);
    _43goto_ref_54966 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_43goto_ref_54966);
    _27846 = NOVALUE;

    /** parser.e:170		label_block = goto_stack[$][7]*/
    if (IS_SEQUENCE(_43goto_stack_54965)){
            _27848 = SEQ_PTR(_43goto_stack_54965)->length;
    }
    else {
        _27848 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_54965);
    _27849 = (object)*(((s1_ptr)_2)->base + _27848);
    DeRef(_43label_block_54967);
    _2 = (object)SEQ_PTR(_27849);
    _43label_block_54967 = (object)*(((s1_ptr)_2)->base + 7);
    Ref(_43label_block_54967);
    _27849 = NOVALUE;

    /** parser.e:171		goto_init   = goto_stack[$][8]*/
    if (IS_SEQUENCE(_43goto_stack_54965)){
            _27851 = SEQ_PTR(_43goto_stack_54965)->length;
    }
    else {
        _27851 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_54965);
    _27852 = (object)*(((s1_ptr)_2)->base + _27851);
    DeRef(_43goto_init_54969);
    _2 = (object)SEQ_PTR(_27852);
    _43goto_init_54969 = (object)*(((s1_ptr)_2)->base + 8);
    Ref(_43goto_init_54969);
    _27852 = NOVALUE;

    /** parser.e:173		goto_stack = remove( goto_stack, length( goto_stack ) )*/
    if (IS_SEQUENCE(_43goto_stack_54965)){
            _27854 = SEQ_PTR(_43goto_stack_54965)->length;
    }
    else {
        _27854 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_43goto_stack_54965);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_27854)) ? _27854 : (object)(DBL_PTR(_27854)->dbl);
        int stop = (IS_ATOM_INT(_27854)) ? _27854 : (object)(DBL_PTR(_27854)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43goto_stack_54965), start, &_43goto_stack_54965 );
            }
            else Tail(SEQ_PTR(_43goto_stack_54965), stop+1, &_43goto_stack_54965);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43goto_stack_54965), start, &_43goto_stack_54965);
        }
        else {
            assign_slice_seq = &assign_space;
            _43goto_stack_54965 = Remove_elements(start, stop, (SEQ_PTR(_43goto_stack_54965)->ref == 1));
        }
    }
    _27854 = NOVALUE;
    _27854 = NOVALUE;

    /** parser.e:175	end procedure*/
    return;
    ;
}


void _43EnterTopLevel(object _end_line_table_55124)
{
    object _27873 = NOVALUE;
    object _27872 = NOVALUE;
    object _27870 = NOVALUE;
    object _27869 = NOVALUE;
    object _27867 = NOVALUE;
    object _27865 = NOVALUE;
    object _27863 = NOVALUE;
    object _27861 = NOVALUE;
    object _27860 = NOVALUE;
    object _27858 = NOVALUE;
    object _27856 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:179		if CurrentSub then*/
    if (_12CurrentSub_20234 == 0)
    {
        goto L1; // [7] 59
    }
    else{
    }

    /** parser.e:180			if end_line_table then*/
    if (_end_line_table_55124 == 0)
    {
        goto L2; // [12] 58
    }
    else{
    }

    /** parser.e:181				EndLineTable()*/
    _43EndLineTable();

    /** parser.e:182				SymTab[CurrentSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    RefDS(_12LineTable_20316);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_19899))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12LineTable_20316;
    DeRef(_1);
    _27856 = NOVALUE;

    /** parser.e:183				SymTab[CurrentSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    RefDS(_12Code_20315);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12Code_20315;
    DeRef(_1);
    _27858 = NOVALUE;
L2: 
L1: 

    /** parser.e:186		if length(goto_stack) then*/
    if (IS_SEQUENCE(_43goto_stack_54965)){
            _27860 = SEQ_PTR(_43goto_stack_54965)->length;
    }
    else {
        _27860 = 1;
    }
    if (_27860 == 0)
    {
        _27860 = NOVALUE;
        goto L3; // [66] 74
    }
    else{
        _27860 = NOVALUE;
    }

    /** parser.e:187			PopGoto()*/
    _43PopGoto();
L3: 

    /** parser.e:189		LineTable = SymTab[TopLevelSub][S_LINETAB]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27861 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    DeRef(_12LineTable_20316);
    _2 = (object)SEQ_PTR(_27861);
    if (!IS_ATOM_INT(_12S_LINETAB_19899)){
        _12LineTable_20316 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    }
    else{
        _12LineTable_20316 = (object)*(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    }
    Ref(_12LineTable_20316);
    _27861 = NOVALUE;

    /** parser.e:190		Code = SymTab[TopLevelSub][S_CODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27863 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    DeRef(_12Code_20315);
    _2 = (object)SEQ_PTR(_27863);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    Ref(_12Code_20315);
    _27863 = NOVALUE;

    /** parser.e:191		SymTab[TopLevelSub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_19899))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _27865 = NOVALUE;

    /** parser.e:192		SymTab[TopLevelSub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _27867 = NOVALUE;

    /** parser.e:193		previous_op = -1*/
    _12previous_op_20325 = -1;

    /** parser.e:194		CurrentSub = TopLevelSub*/
    _12CurrentSub_20234 = _12TopLevelSub_20233;

    /** parser.e:195		clear_last()*/
    _45clear_last();

    /** parser.e:196		if length( branch_stack ) then*/
    if (IS_SEQUENCE(_43branch_stack_54951)){
            _27869 = SEQ_PTR(_43branch_stack_54951)->length;
    }
    else {
        _27869 = 1;
    }
    if (_27869 == 0)
    {
        _27869 = NOVALUE;
        goto L4; // [171] 205
    }
    else{
        _27869 = NOVALUE;
    }

    /** parser.e:197			branch_list = branch_stack[$]*/
    if (IS_SEQUENCE(_43branch_stack_54951)){
            _27870 = SEQ_PTR(_43branch_stack_54951)->length;
    }
    else {
        _27870 = 1;
    }
    DeRef(_43branch_list_54950);
    _2 = (object)SEQ_PTR(_43branch_stack_54951);
    _43branch_list_54950 = (object)*(((s1_ptr)_2)->base + _27870);
    Ref(_43branch_list_54950);

    /** parser.e:198			branch_stack = tail( branch_stack )*/
    if (IS_SEQUENCE(_43branch_stack_54951)){
            _27872 = SEQ_PTR(_43branch_stack_54951)->length;
    }
    else {
        _27872 = 1;
    }
    _27873 = _27872 - 1;
    _27872 = NOVALUE;
    {
        int len = SEQ_PTR(_43branch_stack_54951)->length;
        int size = (IS_ATOM_INT(_27873)) ? _27873 : (object)(DBL_PTR(_27873)->dbl);
        if (size <= 0) {
            DeRef(_43branch_stack_54951);
            _43branch_stack_54951 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_43branch_stack_54951);
            DeRef(_43branch_stack_54951);
            _43branch_stack_54951 = _43branch_stack_54951;
        }
        else Tail(SEQ_PTR(_43branch_stack_54951), len-size+1, &_43branch_stack_54951);
    }
    _27873 = NOVALUE;
L4: 

    /** parser.e:200	end procedure*/
    return;
    ;
}


void _43LeaveTopLevel()
{
    object _27878 = NOVALUE;
    object _27876 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:204		branch_stack = append( branch_stack, branch_list )*/
    RefDS(_43branch_list_54950);
    Append(&_43branch_stack_54951, _43branch_stack_54951, _43branch_list_54950);

    /** parser.e:205		branch_list = {}*/
    RefDS(_22015);
    DeRefDS(_43branch_list_54950);
    _43branch_list_54950 = _22015;

    /** parser.e:206		PushGoto()*/
    _43PushGoto();

    /** parser.e:207		LastLineNumber = -1*/
    _61LastLineNumber_25584 = -1;

    /** parser.e:208		SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_12LineTable_20316);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_19899))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12LineTable_20316;
    DeRef(_1);
    _27876 = NOVALUE;

    /** parser.e:209		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_12Code_20315);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12Code_20315;
    DeRef(_1);
    _27878 = NOVALUE;

    /** parser.e:210		LineTable = {}*/
    RefDS(_22015);
    DeRefDS(_12LineTable_20316);
    _12LineTable_20316 = _22015;

    /** parser.e:211		Code = {}*/
    RefDS(_22015);
    DeRefDS(_12Code_20315);
    _12Code_20315 = _22015;

    /** parser.e:212		previous_op = -1*/
    _12previous_op_20325 = -1;

    /** parser.e:213		clear_last()*/
    _45clear_last();

    /** parser.e:214	end procedure*/
    return;
    ;
}


void _43InitParser()
{
    object _new_1__tmp_at195_55200 = NOVALUE;
    object _new_inlined_new_at_195_55199 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:217		goto_stack = {}*/
    RefDS(_22015);
    DeRef(_43goto_stack_54965);
    _43goto_stack_54965 = _22015;

    /** parser.e:220		goto_labels = {}*/
    RefDS(_22015);
    DeRef(_43goto_labels_54963);
    _43goto_labels_54963 = _22015;

    /** parser.e:221		label_block = {}*/
    RefDS(_22015);
    DeRef(_43label_block_54967);
    _43label_block_54967 = _22015;

    /** parser.e:222		goto_ref = {}*/
    RefDS(_22015);
    DeRef(_43goto_ref_54966);
    _43goto_ref_54966 = _22015;

    /** parser.e:223		goto_addr = {}*/
    RefDS(_22015);
    DeRef(_43goto_addr_54964);
    _43goto_addr_54964 = _22015;

    /** parser.e:224		goto_line = {}*/
    RefDS(_22015);
    DeRef(_43goto_line_54962);
    _43goto_line_54962 = _22015;

    /** parser.e:225		break_list = {}*/
    RefDS(_22015);
    DeRefi(_43break_list_54970);
    _43break_list_54970 = _22015;

    /** parser.e:226		break_delay = {}*/
    RefDS(_22015);
    DeRef(_43break_delay_54971);
    _43break_delay_54971 = _22015;

    /** parser.e:227		exit_list = {}*/
    RefDS(_22015);
    DeRefi(_43exit_list_54972);
    _43exit_list_54972 = _22015;

    /** parser.e:228		exit_delay = {}*/
    RefDS(_22015);
    DeRef(_43exit_delay_54973);
    _43exit_delay_54973 = _22015;

    /** parser.e:229		continue_list = {}*/
    RefDS(_22015);
    DeRefi(_43continue_list_54974);
    _43continue_list_54974 = _22015;

    /** parser.e:230		continue_delay = {}*/
    RefDS(_22015);
    DeRef(_43continue_delay_54975);
    _43continue_delay_54975 = _22015;

    /** parser.e:231		init_stack = {}*/
    RefDS(_22015);
    DeRefi(_43init_stack_54985);
    _43init_stack_54985 = _22015;

    /** parser.e:232		CurrentSub = 0*/
    _12CurrentSub_20234 = 0;

    /** parser.e:233		CreateTopLevel()*/
    _43CreateTopLevel();

    /** parser.e:234		EnterTopLevel()*/
    _43EnterTopLevel(1);

    /** parser.e:235		backed_up_tok = {}*/
    RefDS(_22015);
    DeRef(_43backed_up_tok_54959);
    _43backed_up_tok_54959 = _22015;

    /** parser.e:236		loop_stack = {}*/
    RefDS(_22015);
    DeRefi(_43loop_stack_54986);
    _43loop_stack_54986 = _22015;

    /** parser.e:237		stmt_nest = 0*/
    _43stmt_nest_54984 = 0;

    /** parser.e:238		loop_labels = {}*/
    RefDS(_22015);
    DeRef(_43loop_labels_54980);
    _43loop_labels_54980 = _22015;

    /** parser.e:239		if_labels = {}*/
    RefDS(_22015);
    DeRef(_43if_labels_54981);
    _43if_labels_54981 = _22015;

    /** parser.e:240		if_stack = {}*/
    RefDS(_22015);
    DeRefi(_43if_stack_54987);
    _43if_stack_54987 = _22015;

    /** parser.e:241		continue_addr = {}*/
    RefDS(_22015);
    DeRefi(_43continue_addr_54977);
    _43continue_addr_54977 = _22015;

    /** parser.e:242		retry_addr = {}*/
    RefDS(_22015);
    DeRefi(_43retry_addr_54978);
    _43retry_addr_54978 = _22015;

    /** parser.e:243		entry_addr = {}*/
    RefDS(_22015);
    DeRefi(_43entry_addr_54976);
    _43entry_addr_54976 = _22015;

    /** parser.e:244		block_list = {}*/
    RefDS(_22015);
    DeRefi(_43block_list_54982);
    _43block_list_54982 = _22015;

    /** parser.e:245		block_index = 0*/
    _43block_index_54983 = 0;

    /** parser.e:246		param_num = -1*/
    _43param_num_54961 = -1;

    /** parser.e:247		entry_stack = {}*/
    RefDS(_22015);
    DeRef(_43entry_stack_54979);
    _43entry_stack_54979 = _22015;

    /** parser.e:248		goto_init = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at195_55200;
    _new_1__tmp_at195_55200 = _34new_map_seq(8);
    DeRef(_0);
    Ref(_new_1__tmp_at195_55200);
    _0 = _35malloc(_new_1__tmp_at195_55200, 1);
    DeRef(_43goto_init_54969);
    _43goto_init_54969 = _0;
    DeRef(_new_1__tmp_at195_55200);
    _new_1__tmp_at195_55200 = NOVALUE;

    /** parser.e:249	end procedure*/
    return;
    ;
}


void _43NotReached(object _tok_55217, object _keyword_55218)
{
    object _27893 = NOVALUE;
    object _27892 = NOVALUE;
    object _27891 = NOVALUE;
    object _27890 = NOVALUE;
    object _27889 = NOVALUE;
    object _27888 = NOVALUE;
    object _27886 = NOVALUE;
    object _27885 = NOVALUE;
    object _27884 = NOVALUE;
    object _27883 = NOVALUE;
    object _27881 = NOVALUE;
    object _27880 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tok_55217)) {
        _1 = (object)(DBL_PTR(_tok_55217)->dbl);
        DeRefDS(_tok_55217);
        _tok_55217 = _1;
    }

    /** parser.e:271		if not find(tok, {END, ELSE, ELSIF, END_OF_FILE, CASE, IFDEF, ELSIFDEF, ELSEDEF}) then*/
    _1 = NewS1(8);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 402;
    ((intptr_t*)_2)[2] = 23;
    ((intptr_t*)_2)[3] = 414;
    ((intptr_t*)_2)[4] = -21;
    ((intptr_t*)_2)[5] = 186;
    ((intptr_t*)_2)[6] = 407;
    ((intptr_t*)_2)[7] = 408;
    ((intptr_t*)_2)[8] = 409;
    _27880 = MAKE_SEQ(_1);
    _27881 = find_from(_tok_55217, _27880, 1);
    DeRefDS(_27880);
    _27880 = NOVALUE;
    if (_27881 != 0)
    goto L1; // [39] 135
    _27881 = NOVALUE;

    /** parser.e:272			if equal(keyword, "goto") and find(tok, {LOOP, LABEL, WHILE}) then*/
    if (_keyword_55218 == _26220)
    _27883 = 1;
    else if (IS_ATOM_INT(_keyword_55218) && IS_ATOM_INT(_26220))
    _27883 = 0;
    else
    _27883 = (compare(_keyword_55218, _26220) == 0);
    if (_27883 == 0) {
        goto L2; // [48] 79
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 422;
    ((intptr_t*)_2)[2] = 419;
    ((intptr_t*)_2)[3] = 47;
    _27885 = MAKE_SEQ(_1);
    _27886 = find_from(_tok_55217, _27885, 1);
    DeRefDS(_27885);
    _27885 = NOVALUE;
    if (_27886 == 0)
    {
        _27886 = NOVALUE;
        goto L2; // [70] 79
    }
    else{
        _27886 = NOVALUE;
    }

    /** parser.e:273				return*/
    DeRefDSi(_keyword_55218);
    return;
L2: 

    /** parser.e:275			if equal(keyword, "abort()") and tok = LABEL then*/
    if (_keyword_55218 == _27887)
    _27888 = 1;
    else if (IS_ATOM_INT(_keyword_55218) && IS_ATOM_INT(_27887))
    _27888 = 0;
    else
    _27888 = (compare(_keyword_55218, _27887) == 0);
    if (_27888 == 0) {
        goto L3; // [85] 105
    }
    _27890 = (_tok_55217 == 419);
    if (_27890 == 0)
    {
        DeRef(_27890);
        _27890 = NOVALUE;
        goto L3; // [96] 105
    }
    else{
        DeRef(_27890);
        _27890 = NOVALUE;
    }

    /** parser.e:278				return*/
    DeRefDSi(_keyword_55218);
    return;
L3: 

    /** parser.e:280			Warning(218, not_reached_warning_flag,*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _27891 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    Ref(_27891);
    _27892 = _53name_ext(_27891);
    _27891 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _27892;
    ((intptr_t*)_2)[2] = _12line_number_20227;
    RefDS(_keyword_55218);
    ((intptr_t*)_2)[3] = _keyword_55218;
    _27893 = MAKE_SEQ(_1);
    _27892 = NOVALUE;
    _49Warning(218, 512, _27893);
    _27893 = NOVALUE;
L1: 

    /** parser.e:285	end procedure*/
    DeRefDSi(_keyword_55218);
    return;
    ;
}


void _43Forward_InitCheck(object _tok_55257, object _ref_55258)
{
    object _sym_55260 = NOVALUE;
    object _27899 = NOVALUE;
    object _27898 = NOVALUE;
    object _27897 = NOVALUE;
    object _27895 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:289		if ref then*/
    if (_ref_55258 == 0)
    {
        goto L1; // [5] 83
    }
    else{
    }

    /** parser.e:290			integer sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_55257);
    _sym_55260 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_55260)){
        _sym_55260 = (object)DBL_PTR(_sym_55260)->dbl;
    }

    /** parser.e:291			if tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_55257);
    _27895 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _27895, 512)){
        _27895 = NOVALUE;
        goto L2; // [28] 50
    }
    _27895 = NOVALUE;

    /** parser.e:292				set_qualified_fwd( SymTab[sym][S_FILE_NO] )*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27897 = (object)*(((s1_ptr)_2)->base + _sym_55260);
    _2 = (object)SEQ_PTR(_27897);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _27898 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _27898 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _27897 = NOVALUE;
    Ref(_27898);
    _61set_qualified_fwd(_27898);
    _27898 = NOVALUE;
L2: 

    /** parser.e:294			ref = new_forward_reference( GLOBAL_INIT_CHECK, tok[T_SYM], GLOBAL_INIT_CHECK )*/
    _2 = (object)SEQ_PTR(_tok_55257);
    _27899 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_27899);
    _ref_55258 = _42new_forward_reference(109, _27899, 109);
    _27899 = NOVALUE;
    if (!IS_ATOM_INT(_ref_55258)) {
        _1 = (object)(DBL_PTR(_ref_55258)->dbl);
        DeRefDS(_ref_55258);
        _ref_55258 = _1;
    }

    /** parser.e:296			emit_op( GLOBAL_INIT_CHECK )*/
    _45emit_op(109);

    /** parser.e:297			emit_addr( sym )*/
    _45emit_addr(_sym_55260);
L1: 

    /** parser.e:299	end procedure*/
    DeRef(_tok_55257);
    return;
    ;
}


void _43InitCheck(object _sym_55285, object _ref_55286)
{
    object _27976 = NOVALUE;
    object _27975 = NOVALUE;
    object _27974 = NOVALUE;
    object _27973 = NOVALUE;
    object _27972 = NOVALUE;
    object _27971 = NOVALUE;
    object _27970 = NOVALUE;
    object _27969 = NOVALUE;
    object _27967 = NOVALUE;
    object _27965 = NOVALUE;
    object _27964 = NOVALUE;
    object _27962 = NOVALUE;
    object _27961 = NOVALUE;
    object _27960 = NOVALUE;
    object _27959 = NOVALUE;
    object _27958 = NOVALUE;
    object _27957 = NOVALUE;
    object _27956 = NOVALUE;
    object _27955 = NOVALUE;
    object _27954 = NOVALUE;
    object _27953 = NOVALUE;
    object _27952 = NOVALUE;
    object _27951 = NOVALUE;
    object _27950 = NOVALUE;
    object _27949 = NOVALUE;
    object _27947 = NOVALUE;
    object _27946 = NOVALUE;
    object _27945 = NOVALUE;
    object _27944 = NOVALUE;
    object _27943 = NOVALUE;
    object _27942 = NOVALUE;
    object _27941 = NOVALUE;
    object _27940 = NOVALUE;
    object _27939 = NOVALUE;
    object _27937 = NOVALUE;
    object _27936 = NOVALUE;
    object _27935 = NOVALUE;
    object _27934 = NOVALUE;
    object _27933 = NOVALUE;
    object _27932 = NOVALUE;
    object _27931 = NOVALUE;
    object _27930 = NOVALUE;
    object _27929 = NOVALUE;
    object _27928 = NOVALUE;
    object _27927 = NOVALUE;
    object _27926 = NOVALUE;
    object _27925 = NOVALUE;
    object _27924 = NOVALUE;
    object _27923 = NOVALUE;
    object _27922 = NOVALUE;
    object _27921 = NOVALUE;
    object _27920 = NOVALUE;
    object _27919 = NOVALUE;
    object _27918 = NOVALUE;
    object _27917 = NOVALUE;
    object _27916 = NOVALUE;
    object _27914 = NOVALUE;
    object _27913 = NOVALUE;
    object _27912 = NOVALUE;
    object _27911 = NOVALUE;
    object _27910 = NOVALUE;
    object _27909 = NOVALUE;
    object _27908 = NOVALUE;
    object _27907 = NOVALUE;
    object _27906 = NOVALUE;
    object _27905 = NOVALUE;
    object _27904 = NOVALUE;
    object _27903 = NOVALUE;
    object _27901 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:306		if sym < 0 or (SymTab[sym][S_MODE] = M_NORMAL and*/
    _27901 = (_sym_55285 < 0);
    if (_27901 != 0) {
        goto L1; // [11] 90
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27903 = (object)*(((s1_ptr)_2)->base + _sym_55285);
    _2 = (object)SEQ_PTR(_27903);
    _27904 = (object)*(((s1_ptr)_2)->base + 3);
    _27903 = NOVALUE;
    if (IS_ATOM_INT(_27904)) {
        _27905 = (_27904 == 1);
    }
    else {
        _27905 = binary_op(EQUALS, _27904, 1);
    }
    _27904 = NOVALUE;
    if (IS_ATOM_INT(_27905)) {
        if (_27905 == 0) {
            _27906 = 0;
            goto L2; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_27905)->dbl == 0.0) {
            _27906 = 0;
            goto L2; // [33] 59
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27907 = (object)*(((s1_ptr)_2)->base + _sym_55285);
    _2 = (object)SEQ_PTR(_27907);
    _27908 = (object)*(((s1_ptr)_2)->base + 4);
    _27907 = NOVALUE;
    if (IS_ATOM_INT(_27908)) {
        _27909 = (_27908 != 2);
    }
    else {
        _27909 = binary_op(NOTEQ, _27908, 2);
    }
    _27908 = NOVALUE;
    DeRef(_27906);
    if (IS_ATOM_INT(_27909))
    _27906 = (_27909 != 0);
    else
    _27906 = DBL_PTR(_27909)->dbl != 0.0;
L2: 
    if (_27906 == 0) {
        DeRef(_27910);
        _27910 = 0;
        goto L3; // [59] 85
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27911 = (object)*(((s1_ptr)_2)->base + _sym_55285);
    _2 = (object)SEQ_PTR(_27911);
    _27912 = (object)*(((s1_ptr)_2)->base + 4);
    _27911 = NOVALUE;
    if (IS_ATOM_INT(_27912)) {
        _27913 = (_27912 != 4);
    }
    else {
        _27913 = binary_op(NOTEQ, _27912, 4);
    }
    _27912 = NOVALUE;
    if (IS_ATOM_INT(_27913))
    _27910 = (_27913 != 0);
    else
    _27910 = DBL_PTR(_27913)->dbl != 0.0;
L3: 
    if (_27910 == 0)
    {
        _27910 = NOVALUE;
        goto L4; // [86] 502
    }
    else{
        _27910 = NOVALUE;
    }
L1: 

    /** parser.e:309			if sym < 0 or ((SymTab[sym][S_SCOPE] != SC_PRIVATE and*/
    _27914 = (_sym_55285 < 0);
    if (_27914 != 0) {
        goto L5; // [96] 213
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27916 = (object)*(((s1_ptr)_2)->base + _sym_55285);
    _2 = (object)SEQ_PTR(_27916);
    _27917 = (object)*(((s1_ptr)_2)->base + 4);
    _27916 = NOVALUE;
    if (IS_ATOM_INT(_27917)) {
        _27918 = (_27917 != 3);
    }
    else {
        _27918 = binary_op(NOTEQ, _27917, 3);
    }
    _27917 = NOVALUE;
    if (IS_ATOM_INT(_27918)) {
        if (_27918 == 0) {
            DeRef(_27919);
            _27919 = 0;
            goto L6; // [118] 144
        }
    }
    else {
        if (DBL_PTR(_27918)->dbl == 0.0) {
            DeRef(_27919);
            _27919 = 0;
            goto L6; // [118] 144
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27920 = (object)*(((s1_ptr)_2)->base + _sym_55285);
    _2 = (object)SEQ_PTR(_27920);
    _27921 = (object)*(((s1_ptr)_2)->base + 1);
    _27920 = NOVALUE;
    if (_27921 == _12NOVALUE_20081)
    _27922 = 1;
    else if (IS_ATOM_INT(_27921) && IS_ATOM_INT(_12NOVALUE_20081))
    _27922 = 0;
    else
    _27922 = (compare(_27921, _12NOVALUE_20081) == 0);
    _27921 = NOVALUE;
    DeRef(_27919);
    _27919 = (_27922 != 0);
L6: 
    if (_27919 != 0) {
        DeRef(_27923);
        _27923 = 1;
        goto L7; // [144] 208
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27924 = (object)*(((s1_ptr)_2)->base + _sym_55285);
    _2 = (object)SEQ_PTR(_27924);
    _27925 = (object)*(((s1_ptr)_2)->base + 4);
    _27924 = NOVALUE;
    if (IS_ATOM_INT(_27925)) {
        _27926 = (_27925 == 3);
    }
    else {
        _27926 = binary_op(EQUALS, _27925, 3);
    }
    _27925 = NOVALUE;
    if (IS_ATOM_INT(_27926)) {
        if (_27926 == 0) {
            DeRef(_27927);
            _27927 = 0;
            goto L8; // [166] 204
        }
    }
    else {
        if (DBL_PTR(_27926)->dbl == 0.0) {
            DeRef(_27927);
            _27927 = 0;
            goto L8; // [166] 204
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27928 = (object)*(((s1_ptr)_2)->base + _sym_55285);
    _2 = (object)SEQ_PTR(_27928);
    _27929 = (object)*(((s1_ptr)_2)->base + 16);
    _27928 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27930 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_27930);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _27931 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _27931 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _27930 = NOVALUE;
    if (IS_ATOM_INT(_27929) && IS_ATOM_INT(_27931)) {
        _27932 = (_27929 >= _27931);
    }
    else {
        _27932 = binary_op(GREATEREQ, _27929, _27931);
    }
    _27929 = NOVALUE;
    _27931 = NOVALUE;
    DeRef(_27927);
    if (IS_ATOM_INT(_27932))
    _27927 = (_27932 != 0);
    else
    _27927 = DBL_PTR(_27932)->dbl != 0.0;
L8: 
    DeRef(_27923);
    _27923 = (_27927 != 0);
L7: 
    if (_27923 == 0)
    {
        _27923 = NOVALUE;
        goto L9; // [209] 566
    }
    else{
        _27923 = NOVALUE;
    }
L5: 

    /** parser.e:313				if sym < 0 or (SymTab[sym][S_INITLEVEL] = -1)*/
    _27933 = (_sym_55285 < 0);
    if (_27933 != 0) {
        _27934 = 1;
        goto LA; // [219] 243
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27935 = (object)*(((s1_ptr)_2)->base + _sym_55285);
    _2 = (object)SEQ_PTR(_27935);
    _27936 = (object)*(((s1_ptr)_2)->base + 14);
    _27935 = NOVALUE;
    if (IS_ATOM_INT(_27936)) {
        _27937 = (_27936 == -1);
    }
    else {
        _27937 = binary_op(EQUALS, _27936, -1);
    }
    _27936 = NOVALUE;
    if (IS_ATOM_INT(_27937))
    _27934 = (_27937 != 0);
    else
    _27934 = DBL_PTR(_27937)->dbl != 0.0;
LA: 
    if (_27934 != 0) {
        goto LB; // [243] 270
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27939 = (object)*(((s1_ptr)_2)->base + _sym_55285);
    _2 = (object)SEQ_PTR(_27939);
    _27940 = (object)*(((s1_ptr)_2)->base + 4);
    _27939 = NOVALUE;
    if (IS_ATOM_INT(_27940)) {
        _27941 = (_27940 != 3);
    }
    else {
        _27941 = binary_op(NOTEQ, _27940, 3);
    }
    _27940 = NOVALUE;
    if (_27941 == 0) {
        DeRef(_27941);
        _27941 = NOVALUE;
        goto L9; // [266] 566
    }
    else {
        if (!IS_ATOM_INT(_27941) && DBL_PTR(_27941)->dbl == 0.0){
            DeRef(_27941);
            _27941 = NOVALUE;
            goto L9; // [266] 566
        }
        DeRef(_27941);
        _27941 = NOVALUE;
    }
    DeRef(_27941);
    _27941 = NOVALUE;
LB: 

    /** parser.e:316					if ref then*/
    if (_ref_55286 == 0)
    {
        goto LC; // [272] 375
    }
    else{
    }

    /** parser.e:317						if sym > 0 and (SymTab[sym][S_SCOPE] = SC_UNDEFINED) then*/
    _27942 = (_sym_55285 > 0);
    if (_27942 == 0) {
        goto LD; // [281] 317
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27944 = (object)*(((s1_ptr)_2)->base + _sym_55285);
    _2 = (object)SEQ_PTR(_27944);
    _27945 = (object)*(((s1_ptr)_2)->base + 4);
    _27944 = NOVALUE;
    if (IS_ATOM_INT(_27945)) {
        _27946 = (_27945 == 9);
    }
    else {
        _27946 = binary_op(EQUALS, _27945, 9);
    }
    _27945 = NOVALUE;
    if (_27946 == 0) {
        DeRef(_27946);
        _27946 = NOVALUE;
        goto LD; // [304] 317
    }
    else {
        if (!IS_ATOM_INT(_27946) && DBL_PTR(_27946)->dbl == 0.0){
            DeRef(_27946);
            _27946 = NOVALUE;
            goto LD; // [304] 317
        }
        DeRef(_27946);
        _27946 = NOVALUE;
    }
    DeRef(_27946);
    _27946 = NOVALUE;

    /** parser.e:318							emit_op(PRIVATE_INIT_CHECK)*/
    _45emit_op(30);
    goto LE; // [314] 369
LD: 

    /** parser.e:319						elsif sym < 0 or find(SymTab[sym][S_SCOPE], SCOPE_TYPES) then*/
    _27947 = (_sym_55285 < 0);
    if (_27947 != 0) {
        goto LF; // [323] 351
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27949 = (object)*(((s1_ptr)_2)->base + _sym_55285);
    _2 = (object)SEQ_PTR(_27949);
    _27950 = (object)*(((s1_ptr)_2)->base + 4);
    _27949 = NOVALUE;
    _27951 = find_from(_27950, _43SCOPE_TYPES_54943, 1);
    _27950 = NOVALUE;
    if (_27951 == 0)
    {
        _27951 = NOVALUE;
        goto L10; // [347] 361
    }
    else{
        _27951 = NOVALUE;
    }
LF: 

    /** parser.e:320							emit_op(GLOBAL_INIT_CHECK) -- will become NOP2*/
    _45emit_op(109);
    goto LE; // [358] 369
L10: 

    /** parser.e:322							emit_op(PRIVATE_INIT_CHECK)*/
    _45emit_op(30);
LE: 

    /** parser.e:324						emit_addr(sym)*/
    _45emit_addr(_sym_55285);
LC: 

    /** parser.e:326					if sym > 0 */
    _27952 = (_sym_55285 > 0);
    if (_27952 == 0) {
        _27953 = 0;
        goto L11; // [381] 411
    }
    _27954 = (_43short_circuit_54952 <= 0);
    if (_27954 != 0) {
        _27955 = 1;
        goto L12; // [391] 407
    }
    _27956 = (_43short_circuit_B_54954 == _9FALSE_444);
    _27955 = (_27956 != 0);
L12: 
    _27953 = (_27955 != 0);
L11: 
    if (_27953 == 0) {
        goto L9; // [411] 566
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27958 = (object)*(((s1_ptr)_2)->base + _sym_55285);
    _2 = (object)SEQ_PTR(_27958);
    _27959 = (object)*(((s1_ptr)_2)->base + 4);
    _27958 = NOVALUE;
    if (IS_ATOM_INT(_27959)) {
        _27960 = (_27959 != 3);
    }
    else {
        _27960 = binary_op(NOTEQ, _27959, 3);
    }
    _27959 = NOVALUE;
    if (IS_ATOM_INT(_27960)) {
        _27961 = (_27960 == 0);
    }
    else {
        _27961 = unary_op(NOT, _27960);
    }
    DeRef(_27960);
    _27960 = NOVALUE;
    if (_27961 == 0) {
        DeRef(_27961);
        _27961 = NOVALUE;
        goto L9; // [437] 566
    }
    else {
        if (!IS_ATOM_INT(_27961) && DBL_PTR(_27961)->dbl == 0.0){
            DeRef(_27961);
            _27961 = NOVALUE;
            goto L9; // [437] 566
        }
        DeRef(_27961);
        _27961 = NOVALUE;
    }
    DeRef(_27961);
    _27961 = NOVALUE;

    /** parser.e:330						if CurrentSub != TopLevelSub */
    _27962 = (_12CurrentSub_20234 != _12TopLevelSub_20233);
    if (_27962 != 0) {
        goto L13; // [450] 470
    }
    if (IS_SEQUENCE(_13known_files_11317)){
            _27964 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _27964 = 1;
    }
    _27965 = (_12current_file_no_20226 == _27964);
    _27964 = NOVALUE;
    if (_27965 == 0)
    {
        DeRef(_27965);
        _27965 = NOVALUE;
        goto L9; // [466] 566
    }
    else{
        DeRef(_27965);
        _27965 = NOVALUE;
    }
L13: 

    /** parser.e:335							init_stack = append(init_stack, sym)*/
    Append(&_43init_stack_54985, _43init_stack_54985, _sym_55285);

    /** parser.e:336							SymTab[sym][S_INITLEVEL] = stmt_nest*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_55285 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _43stmt_nest_54984;
    DeRef(_1);
    _27967 = NOVALUE;
    goto L9; // [499] 566
L4: 

    /** parser.e:343		elsif ref and sym > 0 and sym_mode( sym ) = M_CONSTANT and equal( NOVALUE, sym_obj( sym ) ) then*/
    if (_ref_55286 == 0) {
        _27969 = 0;
        goto L14; // [504] 516
    }
    _27970 = (_sym_55285 > 0);
    _27969 = (_27970 != 0);
L14: 
    if (_27969 == 0) {
        _27971 = 0;
        goto L15; // [516] 534
    }
    _27972 = _53sym_mode(_sym_55285);
    if (IS_ATOM_INT(_27972)) {
        _27973 = (_27972 == 2);
    }
    else {
        _27973 = binary_op(EQUALS, _27972, 2);
    }
    DeRef(_27972);
    _27972 = NOVALUE;
    if (IS_ATOM_INT(_27973))
    _27971 = (_27973 != 0);
    else
    _27971 = DBL_PTR(_27973)->dbl != 0.0;
L15: 
    if (_27971 == 0) {
        goto L16; // [534] 565
    }
    _27975 = _53sym_obj(_sym_55285);
    if (_12NOVALUE_20081 == _27975)
    _27976 = 1;
    else if (IS_ATOM_INT(_12NOVALUE_20081) && IS_ATOM_INT(_27975))
    _27976 = 0;
    else
    _27976 = (compare(_12NOVALUE_20081, _27975) == 0);
    DeRef(_27975);
    _27975 = NOVALUE;
    if (_27976 == 0)
    {
        _27976 = NOVALUE;
        goto L16; // [549] 565
    }
    else{
        _27976 = NOVALUE;
    }

    /** parser.e:344			emit_op( GLOBAL_INIT_CHECK )*/
    _45emit_op(109);

    /** parser.e:345			emit_addr(sym)*/
    _45emit_addr(_sym_55285);
L16: 
L9: 

    /** parser.e:349	end procedure*/
    DeRef(_27905);
    _27905 = NOVALUE;
    DeRef(_27956);
    _27956 = NOVALUE;
    DeRef(_27918);
    _27918 = NOVALUE;
    DeRef(_27962);
    _27962 = NOVALUE;
    DeRef(_27947);
    _27947 = NOVALUE;
    DeRef(_27954);
    _27954 = NOVALUE;
    DeRef(_27901);
    _27901 = NOVALUE;
    DeRef(_27914);
    _27914 = NOVALUE;
    DeRef(_27933);
    _27933 = NOVALUE;
    DeRef(_27973);
    _27973 = NOVALUE;
    DeRef(_27952);
    _27952 = NOVALUE;
    DeRef(_27970);
    _27970 = NOVALUE;
    DeRef(_27942);
    _27942 = NOVALUE;
    DeRef(_27926);
    _27926 = NOVALUE;
    DeRef(_27909);
    _27909 = NOVALUE;
    DeRef(_27913);
    _27913 = NOVALUE;
    DeRef(_27937);
    _27937 = NOVALUE;
    DeRef(_27932);
    _27932 = NOVALUE;
    return;
    ;
}


void _43InitDelete()
{
    object _27989 = NOVALUE;
    object _27988 = NOVALUE;
    object _27986 = NOVALUE;
    object _27985 = NOVALUE;
    object _27984 = NOVALUE;
    object _27983 = NOVALUE;
    object _27982 = NOVALUE;
    object _27981 = NOVALUE;
    object _27980 = NOVALUE;
    object _27979 = NOVALUE;
    object _27978 = NOVALUE;
    object _27977 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:354		while length(init_stack) and*/
L1: 
    if (IS_SEQUENCE(_43init_stack_54985)){
            _27977 = SEQ_PTR(_43init_stack_54985)->length;
    }
    else {
        _27977 = 1;
    }
    if (_27977 == 0) {
        goto L2; // [11] 91
    }
    if (IS_SEQUENCE(_43init_stack_54985)){
            _27979 = SEQ_PTR(_43init_stack_54985)->length;
    }
    else {
        _27979 = 1;
    }
    _2 = (object)SEQ_PTR(_43init_stack_54985);
    _27980 = (object)*(((s1_ptr)_2)->base + _27979);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27981 = (object)*(((s1_ptr)_2)->base + _27980);
    _2 = (object)SEQ_PTR(_27981);
    _27982 = (object)*(((s1_ptr)_2)->base + 14);
    _27981 = NOVALUE;
    if (IS_ATOM_INT(_27982)) {
        _27983 = (_27982 > _43stmt_nest_54984);
    }
    else {
        _27983 = binary_op(GREATER, _27982, _43stmt_nest_54984);
    }
    _27982 = NOVALUE;
    if (_27983 <= 0) {
        if (_27983 == 0) {
            DeRef(_27983);
            _27983 = NOVALUE;
            goto L2; // [43] 91
        }
        else {
            if (!IS_ATOM_INT(_27983) && DBL_PTR(_27983)->dbl == 0.0){
                DeRef(_27983);
                _27983 = NOVALUE;
                goto L2; // [43] 91
            }
            DeRef(_27983);
            _27983 = NOVALUE;
        }
    }
    DeRef(_27983);
    _27983 = NOVALUE;

    /** parser.e:356			SymTab[init_stack[$]][S_INITLEVEL] = -1*/
    if (IS_SEQUENCE(_43init_stack_54985)){
            _27984 = SEQ_PTR(_43init_stack_54985)->length;
    }
    else {
        _27984 = 1;
    }
    _2 = (object)SEQ_PTR(_43init_stack_54985);
    _27985 = (object)*(((s1_ptr)_2)->base + _27984);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27985 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1;
    DeRef(_1);
    _27986 = NOVALUE;

    /** parser.e:357			init_stack = init_stack[1..$-1]*/
    if (IS_SEQUENCE(_43init_stack_54985)){
            _27988 = SEQ_PTR(_43init_stack_54985)->length;
    }
    else {
        _27988 = 1;
    }
    _27989 = _27988 - 1;
    _27988 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43init_stack_54985;
    RHS_Slice(_43init_stack_54985, 1, _27989);

    /** parser.e:358		end while*/
    goto L1; // [88] 6
L2: 

    /** parser.e:359	end procedure*/
    _27980 = NOVALUE;
    _27985 = NOVALUE;
    DeRef(_27989);
    _27989 = NOVALUE;
    return;
    ;
}


void _43emit_forward_addr()
{
    object _27991 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:364		emit_addr(0)*/
    _45emit_addr(0);

    /** parser.e:365		branch_list = append(branch_list, length(Code))*/
    if (IS_SEQUENCE(_12Code_20315)){
            _27991 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _27991 = 1;
    }
    Append(&_43branch_list_54950, _43branch_list_54950, _27991);
    _27991 = NOVALUE;

    /** parser.e:366	end procedure*/
    return;
    ;
}


void _43StraightenBranches()
{
    object _br_55459 = NOVALUE;
    object _target_55460 = NOVALUE;
    object _28012 = NOVALUE;
    object _28011 = NOVALUE;
    object _28010 = NOVALUE;
    object _28009 = NOVALUE;
    object _28007 = NOVALUE;
    object _28006 = NOVALUE;
    object _28005 = NOVALUE;
    object _28003 = NOVALUE;
    object _28002 = NOVALUE;
    object _28001 = NOVALUE;
    object _28000 = NOVALUE;
    object _27998 = NOVALUE;
    object _27995 = NOVALUE;
    object _27994 = NOVALUE;
    object _27993 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:373		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** parser.e:374			return -- do it in back-end*/
    return;
L1: 

    /** parser.e:376		for i = length(branch_list) to 1 by -1 do*/
    if (IS_SEQUENCE(_43branch_list_54950)){
            _27993 = SEQ_PTR(_43branch_list_54950)->length;
    }
    else {
        _27993 = 1;
    }
    {
        object _i_55464;
        _i_55464 = _27993;
L2: 
        if (_i_55464 < 1){
            goto L3; // [21] 170
        }

        /** parser.e:377			if branch_list[i] > length(Code) then*/
        _2 = (object)SEQ_PTR(_43branch_list_54950);
        _27994 = (object)*(((s1_ptr)_2)->base + _i_55464);
        if (IS_SEQUENCE(_12Code_20315)){
                _27995 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _27995 = 1;
        }
        if (binary_op_a(LESSEQ, _27994, _27995)){
            _27994 = NOVALUE;
            _27995 = NOVALUE;
            goto L4; // [41] 53
        }
        _27994 = NOVALUE;
        _27995 = NOVALUE;

        /** parser.e:378				CompileErr("wtf")*/
        RefDS(_27997);
        RefDS(_22015);
        _49CompileErr(_27997, _22015, 0);
L4: 

        /** parser.e:380			target = Code[branch_list[i]]*/
        _2 = (object)SEQ_PTR(_43branch_list_54950);
        _27998 = (object)*(((s1_ptr)_2)->base + _i_55464);
        _2 = (object)SEQ_PTR(_12Code_20315);
        if (!IS_ATOM_INT(_27998)){
            _target_55460 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27998)->dbl));
        }
        else{
            _target_55460 = (object)*(((s1_ptr)_2)->base + _27998);
        }
        if (!IS_ATOM_INT(_target_55460)){
            _target_55460 = (object)DBL_PTR(_target_55460)->dbl;
        }

        /** parser.e:381			if target <= length(Code) and target > 0 then*/
        if (IS_SEQUENCE(_12Code_20315)){
                _28000 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _28000 = 1;
        }
        _28001 = (_target_55460 <= _28000);
        _28000 = NOVALUE;
        if (_28001 == 0) {
            goto L5; // [80] 163
        }
        _28003 = (_target_55460 > 0);
        if (_28003 == 0)
        {
            DeRef(_28003);
            _28003 = NOVALUE;
            goto L5; // [89] 163
        }
        else{
            DeRef(_28003);
            _28003 = NOVALUE;
        }

        /** parser.e:382				br = Code[target]*/
        _2 = (object)SEQ_PTR(_12Code_20315);
        _br_55459 = (object)*(((s1_ptr)_2)->base + _target_55460);
        if (!IS_ATOM_INT(_br_55459)){
            _br_55459 = (object)DBL_PTR(_br_55459)->dbl;
        }

        /** parser.e:383				if br = ELSE or br = ENDWHILE or br = EXIT then*/
        _28005 = (_br_55459 == 23);
        if (_28005 != 0) {
            _28006 = 1;
            goto L6; // [110] 124
        }
        _28007 = (_br_55459 == 22);
        _28006 = (_28007 != 0);
L6: 
        if (_28006 != 0) {
            goto L7; // [124] 139
        }
        _28009 = (_br_55459 == 61);
        if (_28009 == 0)
        {
            DeRef(_28009);
            _28009 = NOVALUE;
            goto L8; // [135] 162
        }
        else{
            DeRef(_28009);
            _28009 = NOVALUE;
        }
L7: 

        /** parser.e:384					backpatch(branch_list[i], Code[target+1])*/
        _2 = (object)SEQ_PTR(_43branch_list_54950);
        _28010 = (object)*(((s1_ptr)_2)->base + _i_55464);
        _28011 = _target_55460 + 1;
        _2 = (object)SEQ_PTR(_12Code_20315);
        _28012 = (object)*(((s1_ptr)_2)->base + _28011);
        Ref(_28010);
        Ref(_28012);
        _45backpatch(_28010, _28012);
        _28010 = NOVALUE;
        _28012 = NOVALUE;
L8: 
L5: 

        /** parser.e:387		end for*/
        _i_55464 = _i_55464 + -1;
        goto L2; // [165] 28
L3: 
        ;
    }

    /** parser.e:388		branch_list = {}*/
    RefDS(_22015);
    DeRef(_43branch_list_54950);
    _43branch_list_54950 = _22015;

    /** parser.e:389	end procedure*/
    DeRef(_28011);
    _28011 = NOVALUE;
    DeRef(_28007);
    _28007 = NOVALUE;
    DeRef(_28001);
    _28001 = NOVALUE;
    _27998 = NOVALUE;
    DeRef(_28005);
    _28005 = NOVALUE;
    return;
    ;
}


void _43PatchEList(object _base_55512)
{
    object _break_top_55513 = NOVALUE;
    object _n_55514 = NOVALUE;
    object _28029 = NOVALUE;
    object _28028 = NOVALUE;
    object _28027 = NOVALUE;
    object _28023 = NOVALUE;
    object _28022 = NOVALUE;
    object _28021 = NOVALUE;
    object _28019 = NOVALUE;
    object _28018 = NOVALUE;
    object _28016 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:410		if not length(break_list) then*/
    if (IS_SEQUENCE(_43break_list_54970)){
            _28016 = SEQ_PTR(_43break_list_54970)->length;
    }
    else {
        _28016 = 1;
    }
    if (_28016 != 0)
    goto L1; // [10] 19
    _28016 = NOVALUE;

    /** parser.e:411			return*/
    return;
L1: 

    /** parser.e:414		break_top = 0*/
    _break_top_55513 = 0;

    /** parser.e:415		for i=length(break_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_43break_list_54970)){
            _28018 = SEQ_PTR(_43break_list_54970)->length;
    }
    else {
        _28018 = 1;
    }
    _28019 = _base_55512 + 1;
    if (_28019 > MAXINT){
        _28019 = NewDouble((eudouble)_28019);
    }
    {
        object _i_55519;
        _i_55519 = _28018;
L2: 
        if (binary_op_a(LESS, _i_55519, _28019)){
            goto L3; // [35] 129
        }

        /** parser.e:416			n=break_delay[i]*/
        _2 = (object)SEQ_PTR(_43break_delay_54971);
        if (!IS_ATOM_INT(_i_55519)){
            _n_55514 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55519)->dbl));
        }
        else{
            _n_55514 = (object)*(((s1_ptr)_2)->base + _i_55519);
        }
        if (!IS_ATOM_INT(_n_55514))
        _n_55514 = (object)DBL_PTR(_n_55514)->dbl;

        /** parser.e:417			break_delay[i] -= (n>0)*/
        _28021 = (_n_55514 > 0);
        _2 = (object)SEQ_PTR(_43break_delay_54971);
        if (!IS_ATOM_INT(_i_55519)){
            _28022 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55519)->dbl));
        }
        else{
            _28022 = (object)*(((s1_ptr)_2)->base + _i_55519);
        }
        if (IS_ATOM_INT(_28022)) {
            _28023 = _28022 - _28021;
            if ((object)((uintptr_t)_28023 +(uintptr_t) HIGH_BITS) >= 0){
                _28023 = NewDouble((eudouble)_28023);
            }
        }
        else {
            _28023 = binary_op(MINUS, _28022, _28021);
        }
        _28022 = NOVALUE;
        _28021 = NOVALUE;
        _2 = (object)SEQ_PTR(_43break_delay_54971);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43break_delay_54971 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_55519))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55519)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_55519);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28023;
        if( _1 != _28023 ){
            DeRef(_1);
        }
        _28023 = NOVALUE;

        /** parser.e:418			if n>1 then*/
        if (_n_55514 <= 1)
        goto L4; // [72] 93

        /** parser.e:419				if break_top = 0 then*/
        if (_break_top_55513 != 0)
        goto L5; // [78] 122

        /** parser.e:420					break_top = i*/
        Ref(_i_55519);
        _break_top_55513 = _i_55519;
        if (!IS_ATOM_INT(_break_top_55513)) {
            _1 = (object)(DBL_PTR(_break_top_55513)->dbl);
            DeRefDS(_break_top_55513);
            _break_top_55513 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** parser.e:422			elsif n=1 then*/
        if (_n_55514 != 1)
        goto L6; // [95] 121

        /** parser.e:423				backpatch(break_list[i],length(Code)+1)*/
        _2 = (object)SEQ_PTR(_43break_list_54970);
        if (!IS_ATOM_INT(_i_55519)){
            _28027 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55519)->dbl));
        }
        else{
            _28027 = (object)*(((s1_ptr)_2)->base + _i_55519);
        }
        if (IS_SEQUENCE(_12Code_20315)){
                _28028 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _28028 = 1;
        }
        _28029 = _28028 + 1;
        _28028 = NOVALUE;
        _45backpatch(_28027, _28029);
        _28027 = NOVALUE;
        _28029 = NOVALUE;
L6: 
L5: 

        /** parser.e:425		end for*/
        _0 = _i_55519;
        if (IS_ATOM_INT(_i_55519)) {
            _i_55519 = _i_55519 + -1;
            if ((object)((uintptr_t)_i_55519 +(uintptr_t) HIGH_BITS) >= 0){
                _i_55519 = NewDouble((eudouble)_i_55519);
            }
        }
        else {
            _i_55519 = binary_op_a(PLUS, _i_55519, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_55519);
    }

    /** parser.e:427		if break_top=0 then*/
    if (_break_top_55513 != 0)
    goto L7; // [131] 141

    /** parser.e:428		    break_top=base*/
    _break_top_55513 = _base_55512;
L7: 

    /** parser.e:431		break_delay = break_delay[1..break_top]*/
    rhs_slice_target = (object_ptr)&_43break_delay_54971;
    RHS_Slice(_43break_delay_54971, 1, _break_top_55513);

    /** parser.e:432		break_list = break_list[1..break_top]*/
    rhs_slice_target = (object_ptr)&_43break_list_54970;
    RHS_Slice(_43break_list_54970, 1, _break_top_55513);

    /** parser.e:433	end procedure*/
    DeRef(_28019);
    _28019 = NOVALUE;
    return;
    ;
}


void _43PatchNList(object _base_55543)
{
    object _next_top_55544 = NOVALUE;
    object _n_55545 = NOVALUE;
    object _28046 = NOVALUE;
    object _28045 = NOVALUE;
    object _28044 = NOVALUE;
    object _28040 = NOVALUE;
    object _28039 = NOVALUE;
    object _28038 = NOVALUE;
    object _28036 = NOVALUE;
    object _28035 = NOVALUE;
    object _28033 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:439		if not length(continue_list) then*/
    if (IS_SEQUENCE(_43continue_list_54974)){
            _28033 = SEQ_PTR(_43continue_list_54974)->length;
    }
    else {
        _28033 = 1;
    }
    if (_28033 != 0)
    goto L1; // [10] 19
    _28033 = NOVALUE;

    /** parser.e:440			return*/
    return;
L1: 

    /** parser.e:443		next_top = 0*/
    _next_top_55544 = 0;

    /** parser.e:445		for i=length(continue_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_43continue_list_54974)){
            _28035 = SEQ_PTR(_43continue_list_54974)->length;
    }
    else {
        _28035 = 1;
    }
    _28036 = _base_55543 + 1;
    if (_28036 > MAXINT){
        _28036 = NewDouble((eudouble)_28036);
    }
    {
        object _i_55550;
        _i_55550 = _28035;
L2: 
        if (binary_op_a(LESS, _i_55550, _28036)){
            goto L3; // [35] 129
        }

        /** parser.e:446			n=continue_delay[i]*/
        _2 = (object)SEQ_PTR(_43continue_delay_54975);
        if (!IS_ATOM_INT(_i_55550)){
            _n_55545 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55550)->dbl));
        }
        else{
            _n_55545 = (object)*(((s1_ptr)_2)->base + _i_55550);
        }
        if (!IS_ATOM_INT(_n_55545))
        _n_55545 = (object)DBL_PTR(_n_55545)->dbl;

        /** parser.e:447			continue_delay[i] -= (n>0)*/
        _28038 = (_n_55545 > 0);
        _2 = (object)SEQ_PTR(_43continue_delay_54975);
        if (!IS_ATOM_INT(_i_55550)){
            _28039 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55550)->dbl));
        }
        else{
            _28039 = (object)*(((s1_ptr)_2)->base + _i_55550);
        }
        if (IS_ATOM_INT(_28039)) {
            _28040 = _28039 - _28038;
            if ((object)((uintptr_t)_28040 +(uintptr_t) HIGH_BITS) >= 0){
                _28040 = NewDouble((eudouble)_28040);
            }
        }
        else {
            _28040 = binary_op(MINUS, _28039, _28038);
        }
        _28039 = NOVALUE;
        _28038 = NOVALUE;
        _2 = (object)SEQ_PTR(_43continue_delay_54975);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43continue_delay_54975 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_55550))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55550)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_55550);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28040;
        if( _1 != _28040 ){
            DeRef(_1);
        }
        _28040 = NOVALUE;

        /** parser.e:448			if n>1 then*/
        if (_n_55545 <= 1)
        goto L4; // [72] 93

        /** parser.e:449				if next_top = 0 then*/
        if (_next_top_55544 != 0)
        goto L5; // [78] 122

        /** parser.e:450					next_top = i*/
        Ref(_i_55550);
        _next_top_55544 = _i_55550;
        if (!IS_ATOM_INT(_next_top_55544)) {
            _1 = (object)(DBL_PTR(_next_top_55544)->dbl);
            DeRefDS(_next_top_55544);
            _next_top_55544 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** parser.e:452			elsif n=1 then*/
        if (_n_55545 != 1)
        goto L6; // [95] 121

        /** parser.e:453				backpatch(continue_list[i],length(Code)+1)*/
        _2 = (object)SEQ_PTR(_43continue_list_54974);
        if (!IS_ATOM_INT(_i_55550)){
            _28044 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55550)->dbl));
        }
        else{
            _28044 = (object)*(((s1_ptr)_2)->base + _i_55550);
        }
        if (IS_SEQUENCE(_12Code_20315)){
                _28045 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _28045 = 1;
        }
        _28046 = _28045 + 1;
        _28045 = NOVALUE;
        _45backpatch(_28044, _28046);
        _28044 = NOVALUE;
        _28046 = NOVALUE;
L6: 
L5: 

        /** parser.e:455		end for*/
        _0 = _i_55550;
        if (IS_ATOM_INT(_i_55550)) {
            _i_55550 = _i_55550 + -1;
            if ((object)((uintptr_t)_i_55550 +(uintptr_t) HIGH_BITS) >= 0){
                _i_55550 = NewDouble((eudouble)_i_55550);
            }
        }
        else {
            _i_55550 = binary_op_a(PLUS, _i_55550, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_55550);
    }

    /** parser.e:457		if next_top=0 then*/
    if (_next_top_55544 != 0)
    goto L7; // [131] 141

    /** parser.e:458		    next_top=base*/
    _next_top_55544 = _base_55543;
L7: 

    /** parser.e:461		continue_delay =continue_delay[1..next_top]*/
    rhs_slice_target = (object_ptr)&_43continue_delay_54975;
    RHS_Slice(_43continue_delay_54975, 1, _next_top_55544);

    /** parser.e:462		continue_list = continue_list[1..next_top]*/
    rhs_slice_target = (object_ptr)&_43continue_list_54974;
    RHS_Slice(_43continue_list_54974, 1, _next_top_55544);

    /** parser.e:463	end procedure*/
    DeRef(_28036);
    _28036 = NOVALUE;
    return;
    ;
}


void _43PatchXList(object _base_55574)
{
    object _exit_top_55575 = NOVALUE;
    object _n_55576 = NOVALUE;
    object _28063 = NOVALUE;
    object _28062 = NOVALUE;
    object _28061 = NOVALUE;
    object _28057 = NOVALUE;
    object _28056 = NOVALUE;
    object _28055 = NOVALUE;
    object _28053 = NOVALUE;
    object _28052 = NOVALUE;
    object _28050 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:469		if not length(exit_list) then*/
    if (IS_SEQUENCE(_43exit_list_54972)){
            _28050 = SEQ_PTR(_43exit_list_54972)->length;
    }
    else {
        _28050 = 1;
    }
    if (_28050 != 0)
    goto L1; // [10] 19
    _28050 = NOVALUE;

    /** parser.e:470			return*/
    return;
L1: 

    /** parser.e:473		exit_top = 0*/
    _exit_top_55575 = 0;

    /** parser.e:475		for i=length(exit_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_43exit_list_54972)){
            _28052 = SEQ_PTR(_43exit_list_54972)->length;
    }
    else {
        _28052 = 1;
    }
    _28053 = _base_55574 + 1;
    if (_28053 > MAXINT){
        _28053 = NewDouble((eudouble)_28053);
    }
    {
        object _i_55581;
        _i_55581 = _28052;
L2: 
        if (binary_op_a(LESS, _i_55581, _28053)){
            goto L3; // [35] 129
        }

        /** parser.e:476			n=exit_delay[i]*/
        _2 = (object)SEQ_PTR(_43exit_delay_54973);
        if (!IS_ATOM_INT(_i_55581)){
            _n_55576 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55581)->dbl));
        }
        else{
            _n_55576 = (object)*(((s1_ptr)_2)->base + _i_55581);
        }
        if (!IS_ATOM_INT(_n_55576))
        _n_55576 = (object)DBL_PTR(_n_55576)->dbl;

        /** parser.e:477			exit_delay[i] -= (n>0)*/
        _28055 = (_n_55576 > 0);
        _2 = (object)SEQ_PTR(_43exit_delay_54973);
        if (!IS_ATOM_INT(_i_55581)){
            _28056 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55581)->dbl));
        }
        else{
            _28056 = (object)*(((s1_ptr)_2)->base + _i_55581);
        }
        if (IS_ATOM_INT(_28056)) {
            _28057 = _28056 - _28055;
            if ((object)((uintptr_t)_28057 +(uintptr_t) HIGH_BITS) >= 0){
                _28057 = NewDouble((eudouble)_28057);
            }
        }
        else {
            _28057 = binary_op(MINUS, _28056, _28055);
        }
        _28056 = NOVALUE;
        _28055 = NOVALUE;
        _2 = (object)SEQ_PTR(_43exit_delay_54973);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43exit_delay_54973 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_55581))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55581)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_55581);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28057;
        if( _1 != _28057 ){
            DeRef(_1);
        }
        _28057 = NOVALUE;

        /** parser.e:478			if n>1 then*/
        if (_n_55576 <= 1)
        goto L4; // [72] 93

        /** parser.e:479				if exit_top = 0 then*/
        if (_exit_top_55575 != 0)
        goto L5; // [78] 122

        /** parser.e:480					exit_top = i*/
        Ref(_i_55581);
        _exit_top_55575 = _i_55581;
        if (!IS_ATOM_INT(_exit_top_55575)) {
            _1 = (object)(DBL_PTR(_exit_top_55575)->dbl);
            DeRefDS(_exit_top_55575);
            _exit_top_55575 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** parser.e:482			elsif n=1 then*/
        if (_n_55576 != 1)
        goto L6; // [95] 121

        /** parser.e:483				backpatch(exit_list[i],length(Code)+1)*/
        _2 = (object)SEQ_PTR(_43exit_list_54972);
        if (!IS_ATOM_INT(_i_55581)){
            _28061 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55581)->dbl));
        }
        else{
            _28061 = (object)*(((s1_ptr)_2)->base + _i_55581);
        }
        if (IS_SEQUENCE(_12Code_20315)){
                _28062 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _28062 = 1;
        }
        _28063 = _28062 + 1;
        _28062 = NOVALUE;
        _45backpatch(_28061, _28063);
        _28061 = NOVALUE;
        _28063 = NOVALUE;
L6: 
L5: 

        /** parser.e:485		end for*/
        _0 = _i_55581;
        if (IS_ATOM_INT(_i_55581)) {
            _i_55581 = _i_55581 + -1;
            if ((object)((uintptr_t)_i_55581 +(uintptr_t) HIGH_BITS) >= 0){
                _i_55581 = NewDouble((eudouble)_i_55581);
            }
        }
        else {
            _i_55581 = binary_op_a(PLUS, _i_55581, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_55581);
    }

    /** parser.e:487		if exit_top=0 then*/
    if (_exit_top_55575 != 0)
    goto L7; // [131] 141

    /** parser.e:488		    exit_top=base*/
    _exit_top_55575 = _base_55574;
L7: 

    /** parser.e:491		exit_delay = exit_delay [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_43exit_delay_54973;
    RHS_Slice(_43exit_delay_54973, 1, _exit_top_55575);

    /** parser.e:492		exit_list = exit_list [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_43exit_list_54972;
    RHS_Slice(_43exit_list_54972, 1, _exit_top_55575);

    /** parser.e:493	end procedure*/
    DeRef(_28053);
    _28053 = NOVALUE;
    return;
    ;
}


void _43putback(object _t_55606)
{
    object _28068 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:497		backed_up_tok = append(backed_up_tok, t)*/
    Ref(_t_55606);
    Append(&_43backed_up_tok_54959, _43backed_up_tok_54959, _t_55606);

    /** parser.e:499		if t[T_SYM] then*/
    _2 = (object)SEQ_PTR(_t_55606);
    _28068 = (object)*(((s1_ptr)_2)->base + 2);
    if (_28068 == 0) {
        _28068 = NOVALUE;
        goto L1; // [17] 79
    }
    else {
        if (!IS_ATOM_INT(_28068) && DBL_PTR(_28068)->dbl == 0.0){
            _28068 = NOVALUE;
            goto L1; // [17] 79
        }
        _28068 = NOVALUE;
    }
    _28068 = NOVALUE;

    /** parser.e:500			putback_ForwardLine     = ForwardLine*/
    Ref(_49ForwardLine_49262);
    DeRef(_49putback_ForwardLine_49263);
    _49putback_ForwardLine_49263 = _49ForwardLine_49262;

    /** parser.e:501			putback_forward_bp      = forward_bp*/
    _49putback_forward_bp_49267 = _49forward_bp_49266;

    /** parser.e:502			putback_fwd_line_number = fwd_line_number*/
    _12putback_fwd_line_number_20229 = _12fwd_line_number_20228;

    /** parser.e:504			if last_fwd_line_number then*/
    if (_12last_fwd_line_number_20230 == 0)
    {
        goto L2; // [49] 78
    }
    else{
    }

    /** parser.e:505				ForwardLine     = last_ForwardLine*/
    Ref(_49last_ForwardLine_49264);
    DeRef(_49ForwardLine_49262);
    _49ForwardLine_49262 = _49last_ForwardLine_49264;

    /** parser.e:506				forward_bp      = last_forward_bp*/
    _49forward_bp_49266 = _49last_forward_bp_49268;

    /** parser.e:507				fwd_line_number = last_fwd_line_number*/
    _12fwd_line_number_20228 = _12last_fwd_line_number_20230;
L2: 
L1: 

    /** parser.e:510	end procedure*/
    DeRef(_t_55606);
    return;
    ;
}


void _43start_recording()
{
    object _0, _1, _2;
    

    /** parser.e:519		psm_stack &= Parser_mode*/
    Append(&_43psm_stack_55625, _43psm_stack_55625, _12Parser_mode_20332);

    /** parser.e:520		can_stack = append(can_stack,canned_tokens)*/
    Ref(_43canned_tokens_54996);
    Append(&_43can_stack_55626, _43can_stack_55626, _43canned_tokens_54996);

    /** parser.e:521		idx_stack &= canned_index*/
    Append(&_43idx_stack_55627, _43idx_stack_55627, _43canned_index_54997);

    /** parser.e:522		tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_43backed_up_tok_54959);
    Append(&_43tok_stack_55628, _43tok_stack_55628, _43backed_up_tok_54959);

    /** parser.e:523		canned_tokens = {}*/
    RefDS(_22015);
    DeRef(_43canned_tokens_54996);
    _43canned_tokens_54996 = _22015;

    /** parser.e:524		Parser_mode = PAM_RECORD*/
    _12Parser_mode_20332 = 1;

    /** parser.e:525		clear_last()*/
    _45clear_last();

    /** parser.e:526	end procedure*/
    return;
    ;
}


object _43restore_parser()
{
    object _n_55641 = NOVALUE;
    object _tok_55642 = NOVALUE;
    object _x_55643 = NOVALUE;
    object _28099 = NOVALUE;
    object _28098 = NOVALUE;
    object _28097 = NOVALUE;
    object _28095 = NOVALUE;
    object _28091 = NOVALUE;
    object _28090 = NOVALUE;
    object _28088 = NOVALUE;
    object _28086 = NOVALUE;
    object _28085 = NOVALUE;
    object _28083 = NOVALUE;
    object _28081 = NOVALUE;
    object _28080 = NOVALUE;
    object _28078 = NOVALUE;
    object _28076 = NOVALUE;
    object _28075 = NOVALUE;
    object _28073 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:533		n=Parser_mode*/
    _n_55641 = _12Parser_mode_20332;

    /** parser.e:534		x = canned_tokens*/
    Ref(_43canned_tokens_54996);
    DeRef(_x_55643);
    _x_55643 = _43canned_tokens_54996;

    /** parser.e:535		canned_tokens = can_stack[$]*/
    if (IS_SEQUENCE(_43can_stack_55626)){
            _28073 = SEQ_PTR(_43can_stack_55626)->length;
    }
    else {
        _28073 = 1;
    }
    DeRef(_43canned_tokens_54996);
    _2 = (object)SEQ_PTR(_43can_stack_55626);
    _43canned_tokens_54996 = (object)*(((s1_ptr)_2)->base + _28073);
    Ref(_43canned_tokens_54996);

    /** parser.e:536		can_stack     = can_stack[1..$-1]*/
    if (IS_SEQUENCE(_43can_stack_55626)){
            _28075 = SEQ_PTR(_43can_stack_55626)->length;
    }
    else {
        _28075 = 1;
    }
    _28076 = _28075 - 1;
    _28075 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43can_stack_55626;
    RHS_Slice(_43can_stack_55626, 1, _28076);

    /** parser.e:537		canned_index  = idx_stack[$]*/
    if (IS_SEQUENCE(_43idx_stack_55627)){
            _28078 = SEQ_PTR(_43idx_stack_55627)->length;
    }
    else {
        _28078 = 1;
    }
    _2 = (object)SEQ_PTR(_43idx_stack_55627);
    _43canned_index_54997 = (object)*(((s1_ptr)_2)->base + _28078);

    /** parser.e:538		idx_stack     = idx_stack[1..$-1]*/
    if (IS_SEQUENCE(_43idx_stack_55627)){
            _28080 = SEQ_PTR(_43idx_stack_55627)->length;
    }
    else {
        _28080 = 1;
    }
    _28081 = _28080 - 1;
    _28080 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43idx_stack_55627;
    RHS_Slice(_43idx_stack_55627, 1, _28081);

    /** parser.e:539		Parser_mode   = psm_stack[$]*/
    if (IS_SEQUENCE(_43psm_stack_55625)){
            _28083 = SEQ_PTR(_43psm_stack_55625)->length;
    }
    else {
        _28083 = 1;
    }
    _2 = (object)SEQ_PTR(_43psm_stack_55625);
    _12Parser_mode_20332 = (object)*(((s1_ptr)_2)->base + _28083);

    /** parser.e:540		psm_stack     = psm_stack[1..$-1]*/
    if (IS_SEQUENCE(_43psm_stack_55625)){
            _28085 = SEQ_PTR(_43psm_stack_55625)->length;
    }
    else {
        _28085 = 1;
    }
    _28086 = _28085 - 1;
    _28085 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43psm_stack_55625;
    RHS_Slice(_43psm_stack_55625, 1, _28086);

    /** parser.e:541		tok 		  = tok_stack[$]*/
    if (IS_SEQUENCE(_43tok_stack_55628)){
            _28088 = SEQ_PTR(_43tok_stack_55628)->length;
    }
    else {
        _28088 = 1;
    }
    DeRef(_tok_55642);
    _2 = (object)SEQ_PTR(_43tok_stack_55628);
    _tok_55642 = (object)*(((s1_ptr)_2)->base + _28088);
    RefDS(_tok_55642);

    /** parser.e:542		tok_stack 	  = tok_stack[1..$-1]*/
    if (IS_SEQUENCE(_43tok_stack_55628)){
            _28090 = SEQ_PTR(_43tok_stack_55628)->length;
    }
    else {
        _28090 = 1;
    }
    _28091 = _28090 - 1;
    _28090 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43tok_stack_55628;
    RHS_Slice(_43tok_stack_55628, 1, _28091);

    /** parser.e:543		clear_last()*/
    _45clear_last();

    /** parser.e:544		if n=PAM_PLAYBACK then*/
    if (_n_55641 != -1)
    goto L1; // [137] 150

    /** parser.e:545			return {}*/
    RefDS(_22015);
    DeRefDS(_tok_55642);
    DeRefDS(_x_55643);
    _28091 = NOVALUE;
    _28081 = NOVALUE;
    _28086 = NOVALUE;
    _28076 = NOVALUE;
    return _22015;
    goto L2; // [147] 167
L1: 

    /** parser.e:547		elsif n = PAM_NORMAL then*/
    if (_n_55641 != 0)
    goto L3; // [154] 166

    /** parser.e:548			use_private_list = 0*/
    _12use_private_list_20340 = 0;
L3: 
L2: 

    /** parser.e:550		if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_43backed_up_tok_54959)){
            _28095 = SEQ_PTR(_43backed_up_tok_54959)->length;
    }
    else {
        _28095 = 1;
    }
    if (_28095 <= 0)
    goto L4; // [174] 199

    /** parser.e:551			return x[1..$-1]*/
    if (IS_SEQUENCE(_x_55643)){
            _28097 = SEQ_PTR(_x_55643)->length;
    }
    else {
        _28097 = 1;
    }
    _28098 = _28097 - 1;
    _28097 = NOVALUE;
    rhs_slice_target = (object_ptr)&_28099;
    RHS_Slice(_x_55643, 1, _28098);
    DeRef(_tok_55642);
    DeRefDS(_x_55643);
    DeRef(_28091);
    _28091 = NOVALUE;
    DeRef(_28081);
    _28081 = NOVALUE;
    DeRef(_28086);
    _28086 = NOVALUE;
    _28098 = NOVALUE;
    DeRef(_28076);
    _28076 = NOVALUE;
    return _28099;
    goto L5; // [196] 206
L4: 

    /** parser.e:553			return x*/
    DeRef(_tok_55642);
    DeRef(_28099);
    _28099 = NOVALUE;
    DeRef(_28091);
    _28091 = NOVALUE;
    DeRef(_28081);
    _28081 = NOVALUE;
    DeRef(_28086);
    _28086 = NOVALUE;
    DeRef(_28098);
    _28098 = NOVALUE;
    DeRef(_28076);
    _28076 = NOVALUE;
    return _x_55643;
L5: 
    ;
}


void _43start_playback(object _s_55683)
{
    object _0, _1, _2;
    

    /** parser.e:558		psm_stack &= Parser_mode*/
    Append(&_43psm_stack_55625, _43psm_stack_55625, _12Parser_mode_20332);

    /** parser.e:559		can_stack = append(can_stack,canned_tokens)*/
    Ref(_43canned_tokens_54996);
    Append(&_43can_stack_55626, _43can_stack_55626, _43canned_tokens_54996);

    /** parser.e:560		idx_stack &= canned_index*/
    Append(&_43idx_stack_55627, _43idx_stack_55627, _43canned_index_54997);

    /** parser.e:561		tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_43backed_up_tok_54959);
    Append(&_43tok_stack_55628, _43tok_stack_55628, _43backed_up_tok_54959);

    /** parser.e:562		canned_index = 1*/
    _43canned_index_54997 = 1;

    /** parser.e:563		canned_tokens = s*/
    RefDS(_s_55683);
    DeRef(_43canned_tokens_54996);
    _43canned_tokens_54996 = _s_55683;

    /** parser.e:564		backed_up_tok = {}*/
    RefDS(_22015);
    DeRefDS(_43backed_up_tok_54959);
    _43backed_up_tok_54959 = _22015;

    /** parser.e:565		Parser_mode = PAM_PLAYBACK*/
    _12Parser_mode_20332 = -1;

    /** parser.e:566	end procedure*/
    DeRefDS(_s_55683);
    return;
    ;
}


void _43restore_parseargs_states()
{
    object _s_55702 = NOVALUE;
    object _n_55703 = NOVALUE;
    object _28116 = NOVALUE;
    object _28115 = NOVALUE;
    object _28107 = NOVALUE;
    object _28106 = NOVALUE;
    object _28104 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:584		s = parseargs_states[$]*/
    if (IS_SEQUENCE(_43parseargs_states_55691)){
            _28104 = SEQ_PTR(_43parseargs_states_55691)->length;
    }
    else {
        _28104 = 1;
    }
    DeRef(_s_55702);
    _2 = (object)SEQ_PTR(_43parseargs_states_55691);
    _s_55702 = (object)*(((s1_ptr)_2)->base + _28104);
    RefDS(_s_55702);

    /** parser.e:585		parseargs_states = parseargs_states[1..$-1]*/
    if (IS_SEQUENCE(_43parseargs_states_55691)){
            _28106 = SEQ_PTR(_43parseargs_states_55691)->length;
    }
    else {
        _28106 = 1;
    }
    _28107 = _28106 - 1;
    _28106 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43parseargs_states_55691;
    RHS_Slice(_43parseargs_states_55691, 1, _28107);

    /** parser.e:586		n=s[PS_POSITION]*/
    _2 = (object)SEQ_PTR(_s_55702);
    _n_55703 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_n_55703))
    _n_55703 = (object)DBL_PTR(_n_55703)->dbl;

    /** parser.e:587		private_list = private_list[1..n]*/
    rhs_slice_target = (object_ptr)&_43private_list_55696;
    RHS_Slice(_43private_list_55696, 1, _n_55703);

    /** parser.e:588		private_sym = private_sym[1..n]*/
    rhs_slice_target = (object_ptr)&_12private_sym_20339;
    RHS_Slice(_12private_sym_20339, 1, _n_55703);

    /** parser.e:589		lock_scanner = s[PS_SCAN_LOCK]*/
    _2 = (object)SEQ_PTR(_s_55702);
    _43lock_scanner_55697 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_43lock_scanner_55697))
    _43lock_scanner_55697 = (object)DBL_PTR(_43lock_scanner_55697)->dbl;

    /** parser.e:590		use_private_list = s[PS_USE_LIST]*/
    _2 = (object)SEQ_PTR(_s_55702);
    _12use_private_list_20340 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_12use_private_list_20340)){
        _12use_private_list_20340 = (object)DBL_PTR(_12use_private_list_20340)->dbl;
    }

    /** parser.e:591		on_arg = s[PS_ON_ARG]*/
    _2 = (object)SEQ_PTR(_s_55702);
    _43on_arg_55698 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_43on_arg_55698))
    _43on_arg_55698 = (object)DBL_PTR(_43on_arg_55698)->dbl;

    /** parser.e:592		nested_calls = nested_calls[1..$-1]*/
    if (IS_SEQUENCE(_43nested_calls_55699)){
            _28115 = SEQ_PTR(_43nested_calls_55699)->length;
    }
    else {
        _28115 = 1;
    }
    _28116 = _28115 - 1;
    _28115 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43nested_calls_55699;
    RHS_Slice(_43nested_calls_55699, 1, _28116);

    /** parser.e:593	end procedure*/
    DeRefDS(_s_55702);
    _28107 = NOVALUE;
    _28116 = NOVALUE;
    return;
    ;
}


object _43read_recorded_token(object _n_55723)
{
    object _t_55725 = NOVALUE;
    object _p_55726 = NOVALUE;
    object _prev_Nne_55727 = NOVALUE;
    object _ts_55756 = NOVALUE;
    object _31718 = NOVALUE;
    object _31717 = NOVALUE;
    object _31716 = NOVALUE;
    object _31715 = NOVALUE;
    object _31714 = NOVALUE;
    object _31713 = NOVALUE;
    object _31712 = NOVALUE;
    object _31711 = NOVALUE;
    object _28188 = NOVALUE;
    object _28187 = NOVALUE;
    object _28186 = NOVALUE;
    object _28185 = NOVALUE;
    object _28181 = NOVALUE;
    object _28179 = NOVALUE;
    object _28178 = NOVALUE;
    object _28177 = NOVALUE;
    object _28176 = NOVALUE;
    object _28174 = NOVALUE;
    object _28173 = NOVALUE;
    object _28172 = NOVALUE;
    object _28171 = NOVALUE;
    object _28169 = NOVALUE;
    object _28166 = NOVALUE;
    object _28164 = NOVALUE;
    object _28162 = NOVALUE;
    object _28161 = NOVALUE;
    object _28160 = NOVALUE;
    object _28159 = NOVALUE;
    object _28157 = NOVALUE;
    object _28155 = NOVALUE;
    object _28151 = NOVALUE;
    object _28149 = NOVALUE;
    object _28147 = NOVALUE;
    object _28146 = NOVALUE;
    object _28145 = NOVALUE;
    object _28144 = NOVALUE;
    object _28143 = NOVALUE;
    object _28142 = NOVALUE;
    object _28141 = NOVALUE;
    object _28140 = NOVALUE;
    object _28139 = NOVALUE;
    object _28138 = NOVALUE;
    object _28137 = NOVALUE;
    object _28136 = NOVALUE;
    object _28134 = NOVALUE;
    object _28133 = NOVALUE;
    object _28131 = NOVALUE;
    object _28130 = NOVALUE;
    object _28129 = NOVALUE;
    object _28128 = NOVALUE;
    object _28127 = NOVALUE;
    object _28126 = NOVALUE;
    object _28125 = NOVALUE;
    object _28124 = NOVALUE;
    object _28121 = NOVALUE;
    object _28119 = NOVALUE;
    object _28118 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_55723)) {
        _1 = (object)(DBL_PTR(_n_55723)->dbl);
        DeRefDS(_n_55723);
        _n_55723 = _1;
    }

    /** parser.e:597		integer p, prev_Nne*/

    /** parser.e:598		if atom(Ns_recorded[n]) label "top if" then*/
    _2 = (object)SEQ_PTR(_12Ns_recorded_20334);
    _28118 = (object)*(((s1_ptr)_2)->base + _n_55723);
    _28119 = IS_ATOM(_28118);
    _28118 = NOVALUE;
    if (_28119 == 0)
    {
        _28119 = NOVALUE;
        goto L1; // [16] 405
    }
    else{
        _28119 = NOVALUE;
    }

    /** parser.e:599			if use_private_list then*/
    if (_12use_private_list_20340 == 0)
    {
        goto L2; // [23] 171
    }
    else{
    }

    /** parser.e:600				p = find( Recorded[n], private_list)*/
    _2 = (object)SEQ_PTR(_12Recorded_20333);
    _28121 = (object)*(((s1_ptr)_2)->base + _n_55723);
    _p_55726 = find_from(_28121, _43private_list_55696, 1);
    _28121 = NOVALUE;

    /** parser.e:601				if p > 0 then -- the value of this parameter is known, use it*/
    if (_p_55726 <= 0)
    goto L3; // [43] 170

    /** parser.e:603					if TRANSLATE*/
    if (_12TRANSLATE_19834 == 0) {
        goto L4; // [51] 150
    }
    _2 = (object)SEQ_PTR(_12private_sym_20339);
    _28125 = (object)*(((s1_ptr)_2)->base + _p_55726);
    if (IS_ATOM_INT(_28125)) {
        _28126 = (_28125 < 0);
    }
    else {
        _28126 = binary_op(LESS, _28125, 0);
    }
    _28125 = NOVALUE;
    if (IS_ATOM_INT(_28126)) {
        if (_28126 != 0) {
            _28127 = 1;
            goto L5; // [65] 97
        }
    }
    else {
        if (DBL_PTR(_28126)->dbl != 0.0) {
            _28127 = 1;
            goto L5; // [65] 97
        }
    }
    _2 = (object)SEQ_PTR(_12private_sym_20339);
    _28128 = (object)*(((s1_ptr)_2)->base + _p_55726);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28128)){
        _28129 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28128)->dbl));
    }
    else{
        _28129 = (object)*(((s1_ptr)_2)->base + _28128);
    }
    _2 = (object)SEQ_PTR(_28129);
    _28130 = (object)*(((s1_ptr)_2)->base + 3);
    _28129 = NOVALUE;
    if (IS_ATOM_INT(_28130)) {
        _28131 = (_28130 == 3);
    }
    else {
        _28131 = binary_op(EQUALS, _28130, 3);
    }
    _28130 = NOVALUE;
    DeRef(_28127);
    if (IS_ATOM_INT(_28131))
    _28127 = (_28131 != 0);
    else
    _28127 = DBL_PTR(_28131)->dbl != 0.0;
L5: 
    if (_28127 == 0)
    {
        _28127 = NOVALUE;
        goto L4; // [98] 150
    }
    else{
        _28127 = NOVALUE;
    }

    /** parser.e:610						symtab_index ts = NewTempSym()*/
    _ts_55756 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_ts_55756)) {
        _1 = (object)(DBL_PTR(_ts_55756)->dbl);
        DeRefDS(_ts_55756);
        _ts_55756 = _1;
    }

    /** parser.e:611						Code &= { ASSIGN, private_sym[p], ts }*/
    _2 = (object)SEQ_PTR(_12private_sym_20339);
    _28133 = (object)*(((s1_ptr)_2)->base + _p_55726);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18;
    Ref(_28133);
    ((intptr_t*)_2)[2] = _28133;
    ((intptr_t*)_2)[3] = _ts_55756;
    _28134 = MAKE_SEQ(_1);
    _28133 = NOVALUE;
    Concat((object_ptr)&_12Code_20315, _12Code_20315, _28134);
    DeRefDS(_28134);
    _28134 = NOVALUE;

    /** parser.e:612						return {VARIABLE, ts}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _ts_55756;
    _28136 = MAKE_SEQ(_1);
    DeRef(_t_55725);
    DeRef(_28126);
    _28126 = NOVALUE;
    DeRef(_28131);
    _28131 = NOVALUE;
    _28128 = NOVALUE;
    return _28136;
    goto L6; // [147] 169
L4: 

    /** parser.e:614						return {VARIABLE, private_sym[p]}*/
    _2 = (object)SEQ_PTR(_12private_sym_20339);
    _28137 = (object)*(((s1_ptr)_2)->base + _p_55726);
    Ref(_28137);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _28137;
    _28138 = MAKE_SEQ(_1);
    _28137 = NOVALUE;
    DeRef(_t_55725);
    DeRef(_28126);
    _28126 = NOVALUE;
    DeRef(_28131);
    _28131 = NOVALUE;
    DeRef(_28136);
    _28136 = NOVALUE;
    _28128 = NOVALUE;
    return _28138;
L6: 
L3: 
L2: 

    /** parser.e:620			prev_Nne = No_new_entry*/
    _prev_Nne_55727 = _53No_new_entry_48001;

    /** parser.e:621			No_new_entry = 1*/
    _53No_new_entry_48001 = 1;

    /** parser.e:623			if Recorded_sym[n] > 0 and  sym_scope( Recorded_sym[n] ) != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_12Recorded_sym_20335);
    _28139 = (object)*(((s1_ptr)_2)->base + _n_55723);
    if (IS_ATOM_INT(_28139)) {
        _28140 = (_28139 > 0);
    }
    else {
        _28140 = binary_op(GREATER, _28139, 0);
    }
    _28139 = NOVALUE;
    if (IS_ATOM_INT(_28140)) {
        if (_28140 == 0) {
            goto L7; // [199] 250
        }
    }
    else {
        if (DBL_PTR(_28140)->dbl == 0.0) {
            goto L7; // [199] 250
        }
    }
    _2 = (object)SEQ_PTR(_12Recorded_sym_20335);
    _28142 = (object)*(((s1_ptr)_2)->base + _n_55723);
    Ref(_28142);
    _28143 = _53sym_scope(_28142);
    _28142 = NOVALUE;
    if (IS_ATOM_INT(_28143)) {
        _28144 = (_28143 != 9);
    }
    else {
        _28144 = binary_op(NOTEQ, _28143, 9);
    }
    DeRef(_28143);
    _28143 = NOVALUE;
    if (_28144 == 0) {
        DeRef(_28144);
        _28144 = NOVALUE;
        goto L7; // [220] 250
    }
    else {
        if (!IS_ATOM_INT(_28144) && DBL_PTR(_28144)->dbl == 0.0){
            DeRef(_28144);
            _28144 = NOVALUE;
            goto L7; // [220] 250
        }
        DeRef(_28144);
        _28144 = NOVALUE;
    }
    DeRef(_28144);
    _28144 = NOVALUE;

    /** parser.e:624				t = { sym_token( Recorded_sym[n] ), Recorded_sym[n] }*/
    _2 = (object)SEQ_PTR(_12Recorded_sym_20335);
    _28145 = (object)*(((s1_ptr)_2)->base + _n_55723);
    Ref(_28145);
    _28146 = _53sym_token(_28145);
    _28145 = NOVALUE;
    _2 = (object)SEQ_PTR(_12Recorded_sym_20335);
    _28147 = (object)*(((s1_ptr)_2)->base + _n_55723);
    Ref(_28147);
    DeRef(_t_55725);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28146;
    ((intptr_t *)_2)[2] = _28147;
    _t_55725 = MAKE_SEQ(_1);
    _28147 = NOVALUE;
    _28146 = NOVALUE;

    /** parser.e:625				break "top if"*/
    goto L8; // [247] 734
L7: 

    /** parser.e:628			t = keyfind(Recorded[n],-1)*/
    _2 = (object)SEQ_PTR(_12Recorded_20333);
    _28149 = (object)*(((s1_ptr)_2)->base + _n_55723);
    RefDS(_28149);
    DeRef(_31717);
    _31717 = _28149;
    _31718 = _53hashfn(_31717);
    _31717 = NOVALUE;
    RefDS(_28149);
    _0 = _t_55725;
    _t_55725 = _53keyfind(_28149, -1, _12current_file_no_20226, 0, _31718);
    DeRef(_0);
    _28149 = NOVALUE;
    _31718 = NOVALUE;

    /** parser.e:629			if t[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_t_55725);
    _28151 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28151, 509)){
        _28151 = NOVALUE;
        goto L8; // [286] 734
    }
    _28151 = NOVALUE;

    /** parser.e:630		        p = Recorded_sym[n]*/
    _2 = (object)SEQ_PTR(_12Recorded_sym_20335);
    _p_55726 = (object)*(((s1_ptr)_2)->base + _n_55723);
    if (!IS_ATOM_INT(_p_55726)){
        _p_55726 = (object)DBL_PTR(_p_55726)->dbl;
    }

    /** parser.e:631		        if p = 0 then*/
    if (_p_55726 != 0)
    goto L9; // [302] 382

    /** parser.e:633					No_new_entry = 0*/
    _53No_new_entry_48001 = 0;

    /** parser.e:634					t = keyfind( Recorded[n], -1 )*/
    _2 = (object)SEQ_PTR(_12Recorded_20333);
    _28155 = (object)*(((s1_ptr)_2)->base + _n_55723);
    RefDS(_28155);
    DeRef(_31715);
    _31715 = _28155;
    _31716 = _53hashfn(_31715);
    _31715 = NOVALUE;
    RefDS(_28155);
    _0 = _t_55725;
    _t_55725 = _53keyfind(_28155, -1, _12current_file_no_20226, 0, _31716);
    DeRef(_0);
    _28155 = NOVALUE;
    _31716 = NOVALUE;

    /** parser.e:635					No_new_entry = 1*/
    _53No_new_entry_48001 = 1;

    /** parser.e:636					if t[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_t_55725);
    _28157 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28157, 509)){
        _28157 = NOVALUE;
        goto L8; // [355] 734
    }
    _28157 = NOVALUE;

    /** parser.e:637						CompileErr(VARIABLE_1_HAS_NOT_BEEN_DECLARED,{Recorded[n]})*/
    _2 = (object)SEQ_PTR(_12Recorded_20333);
    _28159 = (object)*(((s1_ptr)_2)->base + _n_55723);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_28159);
    ((intptr_t*)_2)[1] = _28159;
    _28160 = MAKE_SEQ(_1);
    _28159 = NOVALUE;
    _49CompileErr(157, _28160, 0);
    _28160 = NOVALUE;
    goto L8; // [379] 734
L9: 

    /** parser.e:640					t = {SymTab[p][S_TOKEN], p}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28161 = (object)*(((s1_ptr)_2)->base + _p_55726);
    _2 = (object)SEQ_PTR(_28161);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _28162 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _28162 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _28161 = NOVALUE;
    Ref(_28162);
    DeRef(_t_55725);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28162;
    ((intptr_t *)_2)[2] = _p_55726;
    _t_55725 = MAKE_SEQ(_1);
    _28162 = NOVALUE;
    goto L8; // [402] 734
L1: 

    /** parser.e:644			prev_Nne = No_new_entry*/
    _prev_Nne_55727 = _53No_new_entry_48001;

    /** parser.e:645			No_new_entry = 1*/
    _53No_new_entry_48001 = 1;

    /** parser.e:646			t = keyfind(Ns_recorded[n],-1, , 1)*/
    _2 = (object)SEQ_PTR(_12Ns_recorded_20334);
    _28164 = (object)*(((s1_ptr)_2)->base + _n_55723);
    Ref(_28164);
    DeRef(_31713);
    _31713 = _28164;
    _31714 = _53hashfn(_31713);
    _31713 = NOVALUE;
    Ref(_28164);
    _0 = _t_55725;
    _t_55725 = _53keyfind(_28164, -1, _12current_file_no_20226, 1, _31714);
    DeRef(_0);
    _28164 = NOVALUE;
    _31714 = NOVALUE;

    /** parser.e:647			if t[T_ID] != NAMESPACE then*/
    _2 = (object)SEQ_PTR(_t_55725);
    _28166 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28166, 523)){
        _28166 = NOVALUE;
        goto LA; // [456] 524
    }
    _28166 = NOVALUE;

    /** parser.e:648				p = Ns_recorded_sym[n]*/
    _2 = (object)SEQ_PTR(_12Ns_recorded_sym_20336);
    _p_55726 = (object)*(((s1_ptr)_2)->base + _n_55723);
    if (!IS_ATOM_INT(_p_55726)){
        _p_55726 = (object)DBL_PTR(_p_55726)->dbl;
    }

    /** parser.e:649				if p = 0 or sym_token( p ) != NAMESPACE then*/
    _28169 = (_p_55726 == 0);
    if (_28169 != 0) {
        goto LB; // [476] 495
    }
    _28171 = _53sym_token(_p_55726);
    if (IS_ATOM_INT(_28171)) {
        _28172 = (_28171 != 523);
    }
    else {
        _28172 = binary_op(NOTEQ, _28171, 523);
    }
    DeRef(_28171);
    _28171 = NOVALUE;
    if (_28172 == 0) {
        DeRef(_28172);
        _28172 = NOVALUE;
        goto LC; // [491] 515
    }
    else {
        if (!IS_ATOM_INT(_28172) && DBL_PTR(_28172)->dbl == 0.0){
            DeRef(_28172);
            _28172 = NOVALUE;
            goto LC; // [491] 515
        }
        DeRef(_28172);
        _28172 = NOVALUE;
    }
    DeRef(_28172);
    _28172 = NOVALUE;
LB: 

    /** parser.e:650					CompileErr(UNKNOWN_NAMESPACE_1_IN_DEFAULT_ARGUMENT, {Ns_recorded[n]})*/
    _2 = (object)SEQ_PTR(_12Ns_recorded_20334);
    _28173 = (object)*(((s1_ptr)_2)->base + _n_55723);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_28173);
    ((intptr_t*)_2)[1] = _28173;
    _28174 = MAKE_SEQ(_1);
    _28173 = NOVALUE;
    _49CompileErr(153, _28174, 0);
    _28174 = NOVALUE;
LC: 

    /** parser.e:652				t = {NAMESPACE, p}*/
    DeRef(_t_55725);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 523;
    ((intptr_t *)_2)[2] = _p_55726;
    _t_55725 = MAKE_SEQ(_1);
LA: 

    /** parser.e:655			t = keyfind(Recorded[n],SymTab[t[T_SYM]][S_OBJ])*/
    _2 = (object)SEQ_PTR(_12Recorded_20333);
    _28176 = (object)*(((s1_ptr)_2)->base + _n_55723);
    _2 = (object)SEQ_PTR(_t_55725);
    _28177 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28177)){
        _28178 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28177)->dbl));
    }
    else{
        _28178 = (object)*(((s1_ptr)_2)->base + _28177);
    }
    _2 = (object)SEQ_PTR(_28178);
    _28179 = (object)*(((s1_ptr)_2)->base + 1);
    _28178 = NOVALUE;
    RefDS(_28176);
    DeRef(_31711);
    _31711 = _28176;
    _31712 = _53hashfn(_31711);
    _31711 = NOVALUE;
    RefDS(_28176);
    Ref(_28179);
    _0 = _t_55725;
    _t_55725 = _53keyfind(_28176, _28179, _12current_file_no_20226, 0, _31712);
    DeRef(_0);
    _28176 = NOVALUE;
    _28179 = NOVALUE;
    _31712 = NOVALUE;

    /** parser.e:656			if t[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_t_55725);
    _28181 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28181, 509)){
        _28181 = NOVALUE;
        goto LD; // [577] 636
    }
    _28181 = NOVALUE;

    /** parser.e:657		        p = Recorded_sym[n]*/
    _2 = (object)SEQ_PTR(_12Recorded_sym_20335);
    _p_55726 = (object)*(((s1_ptr)_2)->base + _n_55723);
    if (!IS_ATOM_INT(_p_55726)){
        _p_55726 = (object)DBL_PTR(_p_55726)->dbl;
    }

    /** parser.e:658		        if p = 0 then*/
    if (_p_55726 != 0)
    goto LE; // [593] 617

    /** parser.e:659		        	CompileErr(VARIABLE_1_HAS_NOT_BEEN_DECLARED,{Recorded[n]})*/
    _2 = (object)SEQ_PTR(_12Recorded_20333);
    _28185 = (object)*(((s1_ptr)_2)->base + _n_55723);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_28185);
    ((intptr_t*)_2)[1] = _28185;
    _28186 = MAKE_SEQ(_1);
    _28185 = NOVALUE;
    _49CompileErr(157, _28186, 0);
    _28186 = NOVALUE;
LE: 

    /** parser.e:661			    t = {SymTab[p][S_TOKEN], p}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28187 = (object)*(((s1_ptr)_2)->base + _p_55726);
    _2 = (object)SEQ_PTR(_28187);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _28188 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _28188 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _28187 = NOVALUE;
    Ref(_28188);
    DeRef(_t_55725);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28188;
    ((intptr_t *)_2)[2] = _p_55726;
    _t_55725 = MAKE_SEQ(_1);
    _28188 = NOVALUE;
LD: 

    /** parser.e:663			n = t[T_ID]*/
    _2 = (object)SEQ_PTR(_t_55725);
    _n_55723 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_n_55723)){
        _n_55723 = (object)DBL_PTR(_n_55723)->dbl;
    }

    /** parser.e:664			if n = VARIABLE then*/
    if (_n_55723 != -100)
    goto LF; // [650] 666

    /** parser.e:665				n = QUALIFIED_VARIABLE*/
    _n_55723 = 512;
    goto L10; // [663] 725
LF: 

    /** parser.e:666			elsif n = FUNC then*/
    if (_n_55723 != 501)
    goto L11; // [670] 686

    /** parser.e:667				n = QUALIFIED_FUNC*/
    _n_55723 = 520;
    goto L10; // [683] 725
L11: 

    /** parser.e:668			elsif n = PROC then*/
    if (_n_55723 != 27)
    goto L12; // [690] 706

    /** parser.e:669				n = QUALIFIED_PROC*/
    _n_55723 = 521;
    goto L10; // [703] 725
L12: 

    /** parser.e:670			elsif n = TYPE then*/
    if (_n_55723 != 504)
    goto L13; // [710] 724

    /** parser.e:671				n = QUALIFIED_TYPE*/
    _n_55723 = 522;
L13: 
L10: 

    /** parser.e:673			t[T_ID] = n*/
    _2 = (object)SEQ_PTR(_t_55725);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _t_55725 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _n_55723;
    DeRef(_1);
L8: 

    /** parser.e:675		No_new_entry = prev_Nne*/
    _53No_new_entry_48001 = _prev_Nne_55727;

    /** parser.e:676	  	return t*/
    DeRef(_28140);
    _28140 = NOVALUE;
    _28177 = NOVALUE;
    DeRef(_28126);
    _28126 = NOVALUE;
    DeRef(_28169);
    _28169 = NOVALUE;
    DeRef(_28131);
    _28131 = NOVALUE;
    DeRef(_28138);
    _28138 = NOVALUE;
    DeRef(_28136);
    _28136 = NOVALUE;
    _28128 = NOVALUE;
    return _t_55725;
    ;
}


object _43next_token()
{
    object _t_55907 = NOVALUE;
    object _s_55908 = NOVALUE;
    object _28227 = NOVALUE;
    object _28226 = NOVALUE;
    object _28225 = NOVALUE;
    object _28224 = NOVALUE;
    object _28223 = NOVALUE;
    object _28222 = NOVALUE;
    object _28221 = NOVALUE;
    object _28220 = NOVALUE;
    object _28218 = NOVALUE;
    object _28217 = NOVALUE;
    object _28216 = NOVALUE;
    object _28215 = NOVALUE;
    object _28213 = NOVALUE;
    object _28211 = NOVALUE;
    object _28209 = NOVALUE;
    object _28205 = NOVALUE;
    object _28202 = NOVALUE;
    object _28199 = NOVALUE;
    object _28197 = NOVALUE;
    object _28195 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:682		sequence s*/

    /** parser.e:684		if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_43backed_up_tok_54959)){
            _28195 = SEQ_PTR(_43backed_up_tok_54959)->length;
    }
    else {
        _28195 = 1;
    }
    if (_28195 <= 0)
    goto L1; // [10] 82

    /** parser.e:685			t = backed_up_tok[$]*/
    if (IS_SEQUENCE(_43backed_up_tok_54959)){
            _28197 = SEQ_PTR(_43backed_up_tok_54959)->length;
    }
    else {
        _28197 = 1;
    }
    DeRef(_t_55907);
    _2 = (object)SEQ_PTR(_43backed_up_tok_54959);
    _t_55907 = (object)*(((s1_ptr)_2)->base + _28197);
    Ref(_t_55907);

    /** parser.e:686			backed_up_tok = remove( backed_up_tok, length( backed_up_tok ) )*/
    if (IS_SEQUENCE(_43backed_up_tok_54959)){
            _28199 = SEQ_PTR(_43backed_up_tok_54959)->length;
    }
    else {
        _28199 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_43backed_up_tok_54959);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28199)) ? _28199 : (object)(DBL_PTR(_28199)->dbl);
        int stop = (IS_ATOM_INT(_28199)) ? _28199 : (object)(DBL_PTR(_28199)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43backed_up_tok_54959), start, &_43backed_up_tok_54959 );
            }
            else Tail(SEQ_PTR(_43backed_up_tok_54959), stop+1, &_43backed_up_tok_54959);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43backed_up_tok_54959), start, &_43backed_up_tok_54959);
        }
        else {
            assign_slice_seq = &assign_space;
            _43backed_up_tok_54959 = Remove_elements(start, stop, (SEQ_PTR(_43backed_up_tok_54959)->ref == 1));
        }
    }
    _28199 = NOVALUE;
    _28199 = NOVALUE;

    /** parser.e:687			if putback_fwd_line_number then*/
    if (_12putback_fwd_line_number_20229 == 0)
    {
        goto L2; // [43] 349
    }
    else{
    }

    /** parser.e:689				ForwardLine     = putback_ForwardLine*/
    Ref(_49putback_ForwardLine_49263);
    DeRef(_49ForwardLine_49262);
    _49ForwardLine_49262 = _49putback_ForwardLine_49263;

    /** parser.e:690				forward_bp      = putback_forward_bp*/
    _49forward_bp_49266 = _49putback_forward_bp_49267;

    /** parser.e:691				fwd_line_number = putback_fwd_line_number*/
    _12fwd_line_number_20228 = _12putback_fwd_line_number_20229;

    /** parser.e:693				putback_fwd_line_number = 0*/
    _12putback_fwd_line_number_20229 = 0;
    goto L2; // [79] 349
L1: 

    /** parser.e:696		elsif Parser_mode = PAM_PLAYBACK then*/
    if (_12Parser_mode_20332 != -1)
    goto L3; // [88] 302

    /** parser.e:697			if canned_index <= length(canned_tokens) then*/
    if (IS_SEQUENCE(_43canned_tokens_54996)){
            _28202 = SEQ_PTR(_43canned_tokens_54996)->length;
    }
    else {
        _28202 = 1;
    }
    if (_43canned_index_54997 > _28202)
    goto L4; // [101] 150

    /** parser.e:698				t = canned_tokens[canned_index]*/
    DeRef(_t_55907);
    _2 = (object)SEQ_PTR(_43canned_tokens_54996);
    _t_55907 = (object)*(((s1_ptr)_2)->base + _43canned_index_54997);
    Ref(_t_55907);

    /** parser.e:699				if canned_index < length(canned_tokens) then*/
    if (IS_SEQUENCE(_43canned_tokens_54996)){
            _28205 = SEQ_PTR(_43canned_tokens_54996)->length;
    }
    else {
        _28205 = 1;
    }
    if (_43canned_index_54997 >= _28205)
    goto L5; // [124] 139

    /** parser.e:700					canned_index += 1*/
    _43canned_index_54997 = _43canned_index_54997 + 1;
    goto L6; // [136] 157
L5: 

    /** parser.e:702		            s = restore_parser()*/
    _0 = _s_55908;
    _s_55908 = _43restore_parser();
    DeRef(_0);
    goto L6; // [147] 157
L4: 

    /** parser.e:705		    	InternalErr(266)*/
    RefDS(_22015);
    _49InternalErr(266, _22015);
L6: 

    /** parser.e:707			if t[T_ID] = RECORDED then*/
    _2 = (object)SEQ_PTR(_t_55907);
    _28209 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28209, 508)){
        _28209 = NOVALUE;
        goto L7; // [169] 188
    }
    _28209 = NOVALUE;

    /** parser.e:708				t=read_recorded_token(t[T_SYM])*/
    _2 = (object)SEQ_PTR(_t_55907);
    _28211 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28211);
    _0 = _t_55907;
    _t_55907 = _43read_recorded_token(_28211);
    DeRef(_0);
    _28211 = NOVALUE;
    goto L2; // [185] 349
L7: 

    /** parser.e:709			elsif t[T_ID] = DEF_PARAM then*/
    _2 = (object)SEQ_PTR(_t_55907);
    _28213 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28213, 510)){
        _28213 = NOVALUE;
        goto L2; // [198] 349
    }
    _28213 = NOVALUE;

    /** parser.e:710	        	for i=length(nested_calls) to 1 by -1 do*/
    if (IS_SEQUENCE(_43nested_calls_55699)){
            _28215 = SEQ_PTR(_43nested_calls_55699)->length;
    }
    else {
        _28215 = 1;
    }
    {
        object _i_55955;
        _i_55955 = _28215;
L8: 
        if (_i_55955 < 1){
            goto L9; // [209] 288
        }

        /** parser.e:711	        	    if nested_calls[i] = t[T_SYM][2] then*/
        _2 = (object)SEQ_PTR(_43nested_calls_55699);
        _28216 = (object)*(((s1_ptr)_2)->base + _i_55955);
        _2 = (object)SEQ_PTR(_t_55907);
        _28217 = (object)*(((s1_ptr)_2)->base + 2);
        _2 = (object)SEQ_PTR(_28217);
        _28218 = (object)*(((s1_ptr)_2)->base + 2);
        _28217 = NOVALUE;
        if (binary_op_a(NOTEQ, _28216, _28218)){
            _28216 = NOVALUE;
            _28218 = NOVALUE;
            goto LA; // [234] 281
        }
        _28216 = NOVALUE;
        _28218 = NOVALUE;

        /** parser.e:712						return {VARIABLE, private_sym[parseargs_states[i][PS_POSITION]+t[T_SYM][1]]}*/
        _2 = (object)SEQ_PTR(_43parseargs_states_55691);
        _28220 = (object)*(((s1_ptr)_2)->base + _i_55955);
        _2 = (object)SEQ_PTR(_28220);
        _28221 = (object)*(((s1_ptr)_2)->base + 1);
        _28220 = NOVALUE;
        _2 = (object)SEQ_PTR(_t_55907);
        _28222 = (object)*(((s1_ptr)_2)->base + 2);
        _2 = (object)SEQ_PTR(_28222);
        _28223 = (object)*(((s1_ptr)_2)->base + 1);
        _28222 = NOVALUE;
        if (IS_ATOM_INT(_28221) && IS_ATOM_INT(_28223)) {
            _28224 = _28221 + _28223;
        }
        else {
            _28224 = binary_op(PLUS, _28221, _28223);
        }
        _28221 = NOVALUE;
        _28223 = NOVALUE;
        _2 = (object)SEQ_PTR(_12private_sym_20339);
        if (!IS_ATOM_INT(_28224)){
            _28225 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28224)->dbl));
        }
        else{
            _28225 = (object)*(((s1_ptr)_2)->base + _28224);
        }
        Ref(_28225);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -100;
        ((intptr_t *)_2)[2] = _28225;
        _28226 = MAKE_SEQ(_1);
        _28225 = NOVALUE;
        DeRef(_t_55907);
        DeRef(_s_55908);
        DeRef(_28224);
        _28224 = NOVALUE;
        return _28226;
LA: 

        /** parser.e:714				end for*/
        _i_55955 = _i_55955 + -1;
        goto L8; // [283] 216
L9: 
        ;
    }

    /** parser.e:715				CompileErr(INTERNAL_NESTED_CALL_PARSING_ERROR)*/
    RefDS(_22015);
    _49CompileErr(98, _22015, 0);
    goto L2; // [299] 349
L3: 

    /** parser.e:717		elsif lock_scanner then*/
    if (_43lock_scanner_55697 == 0)
    {
        goto LB; // [306] 324
    }
    else{
    }

    /** parser.e:718			return {PLAYBACK_ENDS,0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 505;
    ((intptr_t *)_2)[2] = 0;
    _28227 = MAKE_SEQ(_1);
    DeRef(_t_55907);
    DeRef(_s_55908);
    DeRef(_28226);
    _28226 = NOVALUE;
    DeRef(_28224);
    _28224 = NOVALUE;
    return _28227;
    goto L2; // [321] 349
LB: 

    /** parser.e:720		    t = Scanner()*/
    _0 = _t_55907;
    _t_55907 = _61Scanner();
    DeRef(_0);

    /** parser.e:721		    if Parser_mode = PAM_RECORD then*/
    if (_12Parser_mode_20332 != 1)
    goto LC; // [335] 348

    /** parser.e:722		        canned_tokens = append(canned_tokens,t)*/
    Ref(_t_55907);
    Append(&_43canned_tokens_54996, _43canned_tokens_54996, _t_55907);
LC: 
L2: 

    /** parser.e:725		putback_fwd_line_number = 0*/
    _12putback_fwd_line_number_20229 = 0;

    /** parser.e:726		return t*/
    DeRef(_s_55908);
    DeRef(_28227);
    _28227 = NOVALUE;
    DeRef(_28226);
    _28226 = NOVALUE;
    DeRef(_28224);
    _28224 = NOVALUE;
    return _t_55907;
    ;
}


object _43Expr_list()
{
    object _tok_55991 = NOVALUE;
    object _n_55992 = NOVALUE;
    object _28243 = NOVALUE;
    object _28240 = NOVALUE;
    object _28239 = NOVALUE;
    object _28237 = NOVALUE;
    object _28236 = NOVALUE;
    object _28232 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:734		integer n*/

    /** parser.e:736		tok = next_token()*/
    _0 = _tok_55991;
    _tok_55991 = _43next_token();
    DeRef(_0);

    /** parser.e:737		putback(tok)*/
    Ref(_tok_55991);
    _43putback(_tok_55991);

    /** parser.e:738		if tok[T_ID] = RIGHT_BRACE then*/
    _2 = (object)SEQ_PTR(_tok_55991);
    _28232 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28232, -25)){
        _28232 = NOVALUE;
        goto L1; // [23] 36
    }
    _28232 = NOVALUE;

    /** parser.e:739			return 0*/
    DeRef(_tok_55991);
    return 0;
    goto L2; // [33] 142
L1: 

    /** parser.e:741			n = 0*/
    _n_55992 = 0;

    /** parser.e:742			short_circuit -= 1*/
    _43short_circuit_54952 = _43short_circuit_54952 - 1;

    /** parser.e:743			while TRUE do*/
L3: 
    if (_9TRUE_446 == 0)
    {
        goto L4; // [56] 133
    }
    else{
    }

    /** parser.e:744				gListItem &= 1*/
    Append(&_43gListItem_54988, _43gListItem_54988, 1);

    /** parser.e:745				Expr()*/
    _43Expr();

    /** parser.e:746				n += gListItem[$]*/
    if (IS_SEQUENCE(_43gListItem_54988)){
            _28236 = SEQ_PTR(_43gListItem_54988)->length;
    }
    else {
        _28236 = 1;
    }
    _2 = (object)SEQ_PTR(_43gListItem_54988);
    _28237 = (object)*(((s1_ptr)_2)->base + _28236);
    _n_55992 = _n_55992 + _28237;
    _28237 = NOVALUE;

    /** parser.e:747				gListItem = gListItem[1 .. $-1]*/
    if (IS_SEQUENCE(_43gListItem_54988)){
            _28239 = SEQ_PTR(_43gListItem_54988)->length;
    }
    else {
        _28239 = 1;
    }
    _28240 = _28239 - 1;
    _28239 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43gListItem_54988;
    RHS_Slice(_43gListItem_54988, 1, _28240);

    /** parser.e:748				tok = next_token()*/
    _0 = _tok_55991;
    _tok_55991 = _43next_token();
    DeRef(_0);

    /** parser.e:749				if tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_55991);
    _28243 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28243, -30)){
        _28243 = NOVALUE;
        goto L3; // [119] 54
    }
    _28243 = NOVALUE;

    /** parser.e:750					exit*/
    goto L4; // [125] 133

    /** parser.e:752			end while*/
    goto L3; // [130] 54
L4: 

    /** parser.e:753			short_circuit += 1*/
    _43short_circuit_54952 = _43short_circuit_54952 + 1;
L2: 

    /** parser.e:755		putback(tok)*/
    Ref(_tok_55991);
    _43putback(_tok_55991);

    /** parser.e:756		return n*/
    DeRef(_tok_55991);
    DeRef(_28240);
    _28240 = NOVALUE;
    return _n_55992;
    ;
}


void _43tok_match(object _tok_56020, object _prevtok_56021)
{
    object _t_56023 = NOVALUE;
    object _expected_56024 = NOVALUE;
    object _actual_56025 = NOVALUE;
    object _prevname_56026 = NOVALUE;
    object _28255 = NOVALUE;
    object _28253 = NOVALUE;
    object _28250 = NOVALUE;
    object _28247 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:762		sequence expected, actual, prevname*/

    /** parser.e:764		t = next_token()*/
    _0 = _t_56023;
    _t_56023 = _43next_token();
    DeRef(_0);

    /** parser.e:765		if t[T_ID] != tok then*/
    _2 = (object)SEQ_PTR(_t_56023);
    _28247 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28247, _tok_56020)){
        _28247 = NOVALUE;
        goto L1; // [20] 96
    }
    _28247 = NOVALUE;

    /** parser.e:766			expected = LexName(tok)*/
    RefDS(_26351);
    _0 = _expected_56024;
    _expected_56024 = _45LexName(_tok_56020, _26351);
    DeRef(_0);

    /** parser.e:767			actual = LexName(t[T_ID])*/
    _2 = (object)SEQ_PTR(_t_56023);
    _28250 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_28250);
    RefDS(_26351);
    _0 = _actual_56025;
    _actual_56025 = _45LexName(_28250, _26351);
    DeRef(_0);
    _28250 = NOVALUE;

    /** parser.e:768			if prevtok = 0 then*/
    if (_prevtok_56021 != 0)
    goto L2; // [50] 70

    /** parser.e:769				CompileErr(SYNTAX_ERROR__EXPECTED_TO_SEE_POSSIBLY_1_NOT_2, {expected, actual})*/
    RefDS(_actual_56025);
    RefDS(_expected_56024);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _expected_56024;
    ((intptr_t *)_2)[2] = _actual_56025;
    _28253 = MAKE_SEQ(_1);
    _49CompileErr(132, _28253, 0);
    _28253 = NOVALUE;
    goto L3; // [67] 95
L2: 

    /** parser.e:771				prevname = LexName(prevtok)*/
    RefDS(_26351);
    _0 = _prevname_56026;
    _prevname_56026 = _45LexName(_prevtok_56021, _26351);
    DeRef(_0);

    /** parser.e:772				CompileErr(SYNTAX_ERROR__EXPECTED_TO_SEE_1_AFTER_2_NOT_3, {expected, prevname, actual})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_expected_56024);
    ((intptr_t*)_2)[1] = _expected_56024;
    RefDS(_prevname_56026);
    ((intptr_t*)_2)[2] = _prevname_56026;
    RefDS(_actual_56025);
    ((intptr_t*)_2)[3] = _actual_56025;
    _28255 = MAKE_SEQ(_1);
    _49CompileErr(138, _28255, 0);
    _28255 = NOVALUE;
L3: 
L1: 

    /** parser.e:775	end procedure*/
    DeRef(_t_56023);
    DeRef(_expected_56024);
    DeRef(_actual_56025);
    DeRef(_prevname_56026);
    return;
    ;
}


void _43UndefinedVar(object _s_56062)
{
    object _dup_56064 = NOVALUE;
    object _errmsg_56065 = NOVALUE;
    object _rname_56066 = NOVALUE;
    object _fname_56067 = NOVALUE;
    object _28278 = NOVALUE;
    object _28277 = NOVALUE;
    object _28275 = NOVALUE;
    object _28273 = NOVALUE;
    object _28272 = NOVALUE;
    object _28270 = NOVALUE;
    object _28268 = NOVALUE;
    object _28266 = NOVALUE;
    object _28265 = NOVALUE;
    object _28264 = NOVALUE;
    object _28263 = NOVALUE;
    object _28262 = NOVALUE;
    object _28260 = NOVALUE;
    object _28259 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_56062)) {
        _1 = (object)(DBL_PTR(_s_56062)->dbl);
        DeRefDS(_s_56062);
        _s_56062 = _1;
    }

    /** parser.e:790		sequence errmsg*/

    /** parser.e:791		sequence rname*/

    /** parser.e:792		sequence fname*/

    /** parser.e:794		if SymTab[s][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28259 = (object)*(((s1_ptr)_2)->base + _s_56062);
    _2 = (object)SEQ_PTR(_28259);
    _28260 = (object)*(((s1_ptr)_2)->base + 4);
    _28259 = NOVALUE;
    if (binary_op_a(NOTEQ, _28260, 9)){
        _28260 = NOVALUE;
        goto L1; // [25] 57
    }
    _28260 = NOVALUE;

    /** parser.e:795			CompileErr(MSG_1_HAS_NOT_BEEN_DECLARED, {SymTab[s][S_NAME]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28262 = (object)*(((s1_ptr)_2)->base + _s_56062);
    _2 = (object)SEQ_PTR(_28262);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _28263 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _28263 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _28262 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_28263);
    ((intptr_t*)_2)[1] = _28263;
    _28264 = MAKE_SEQ(_1);
    _28263 = NOVALUE;
    _49CompileErr(19, _28264, 0);
    _28264 = NOVALUE;
    goto L2; // [54] 206
L1: 

    /** parser.e:797		elsif SymTab[s][S_SCOPE] = SC_MULTIPLY_DEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28265 = (object)*(((s1_ptr)_2)->base + _s_56062);
    _2 = (object)SEQ_PTR(_28265);
    _28266 = (object)*(((s1_ptr)_2)->base + 4);
    _28265 = NOVALUE;
    if (binary_op_a(NOTEQ, _28266, 10)){
        _28266 = NOVALUE;
        goto L3; // [73] 183
    }
    _28266 = NOVALUE;

    /** parser.e:798			rname = SymTab[s][S_NAME]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28268 = (object)*(((s1_ptr)_2)->base + _s_56062);
    DeRef(_rname_56066);
    _2 = (object)SEQ_PTR(_28268);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _rname_56066 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _rname_56066 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_rname_56066);
    _28268 = NOVALUE;

    /** parser.e:799			errmsg = ""*/
    RefDS(_22015);
    DeRef(_errmsg_56065);
    _errmsg_56065 = _22015;

    /** parser.e:801			for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_53dup_globals_47990)){
            _28270 = SEQ_PTR(_53dup_globals_47990)->length;
    }
    else {
        _28270 = 1;
    }
    {
        object _i_56094;
        _i_56094 = 1;
L4: 
        if (_i_56094 > _28270){
            goto L5; // [107] 165
        }

        /** parser.e:802				dup = dup_globals[i]*/
        _2 = (object)SEQ_PTR(_53dup_globals_47990);
        _dup_56064 = (object)*(((s1_ptr)_2)->base + _i_56094);
        if (!IS_ATOM_INT(_dup_56064)){
            _dup_56064 = (object)DBL_PTR(_dup_56064)->dbl;
        }

        /** parser.e:803				fname = known_files[SymTab[dup][S_FILE_NO]]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28272 = (object)*(((s1_ptr)_2)->base + _dup_56064);
        _2 = (object)SEQ_PTR(_28272);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _28273 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _28273 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _28272 = NOVALUE;
        DeRef(_fname_56067);
        _2 = (object)SEQ_PTR(_13known_files_11317);
        if (!IS_ATOM_INT(_28273)){
            _fname_56067 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28273)->dbl));
        }
        else{
            _fname_56067 = (object)*(((s1_ptr)_2)->base + _28273);
        }
        Ref(_fname_56067);

        /** parser.e:804				errmsg &= "    " & fname & "\n"*/
        {
            object concat_list[3];

            concat_list[0] = _22210;
            concat_list[1] = _fname_56067;
            concat_list[2] = _24902;
            Concat_N((object_ptr)&_28275, concat_list, 3);
        }
        Concat((object_ptr)&_errmsg_56065, _errmsg_56065, _28275);
        DeRefDS(_28275);
        _28275 = NOVALUE;

        /** parser.e:806			end for*/
        _i_56094 = _i_56094 + 1;
        goto L4; // [160] 114
L5: 
        ;
    }

    /** parser.e:808			CompileErr(A_NAMESPACE_QUALIFIER_IS_NEEDED_TO_RESOLVE_1BECAUSE_2_IS_DECLARED_AS_A_GLOBALPUBLIC_SYMBOL_IN3, {rname, rname, errmsg})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDSn(_rname_56066, 2);
    ((intptr_t*)_2)[1] = _rname_56066;
    ((intptr_t*)_2)[2] = _rname_56066;
    RefDS(_errmsg_56065);
    ((intptr_t*)_2)[3] = _errmsg_56065;
    _28277 = MAKE_SEQ(_1);
    _49CompileErr(23, _28277, 0);
    _28277 = NOVALUE;
    goto L2; // [180] 206
L3: 

    /** parser.e:810		elsif length(symbol_resolution_warning) then*/
    if (IS_SEQUENCE(_12symbol_resolution_warning_20328)){
            _28278 = SEQ_PTR(_12symbol_resolution_warning_20328)->length;
    }
    else {
        _28278 = 1;
    }
    if (_28278 == 0)
    {
        _28278 = NOVALUE;
        goto L6; // [190] 205
    }
    else{
        _28278 = NOVALUE;
    }

    /** parser.e:811			Warning( symbol_resolution_warning, resolution_warning_flag)*/
    RefDS(_12symbol_resolution_warning_20328);
    RefDS(_22015);
    _49Warning(_12symbol_resolution_warning_20328, 1, _22015);
L6: 
L2: 

    /** parser.e:813	end procedure*/
    DeRef(_errmsg_56065);
    DeRef(_rname_56066);
    DeRef(_fname_56067);
    _28273 = NOVALUE;
    return;
    ;
}


void _43WrongNumberArgs(object _subsym_56119, object _only_56120)
{
    object _msgno_56121 = NOVALUE;
    object _28290 = NOVALUE;
    object _28289 = NOVALUE;
    object _28288 = NOVALUE;
    object _28287 = NOVALUE;
    object _28286 = NOVALUE;
    object _28284 = NOVALUE;
    object _28282 = NOVALUE;
    object _28280 = NOVALUE;
    object _28279 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_56119)) {
        _1 = (object)(DBL_PTR(_subsym_56119)->dbl);
        DeRefDS(_subsym_56119);
        _subsym_56119 = _1;
    }

    /** parser.e:819		if SymTab[subsym][S_NUM_ARGS] = 1 then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28279 = (object)*(((s1_ptr)_2)->base + _subsym_56119);
    _2 = (object)SEQ_PTR(_28279);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _28280 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _28280 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _28279 = NOVALUE;
    if (binary_op_a(NOTEQ, _28280, 1)){
        _28280 = NOVALUE;
        goto L1; // [19] 49
    }
    _28280 = NOVALUE;

    /** parser.e:820			if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_56120)){
            _28282 = SEQ_PTR(_only_56120)->length;
    }
    else {
        _28282 = 1;
    }
    if (_28282 != 0)
    goto L2; // [28] 40

    /** parser.e:821				msgno = 20*/
    _msgno_56121 = 20;
    goto L3; // [37] 73
L2: 

    /** parser.e:823				msgno = 237*/
    _msgno_56121 = 237;
    goto L3; // [46] 73
L1: 

    /** parser.e:826			if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_56120)){
            _28284 = SEQ_PTR(_only_56120)->length;
    }
    else {
        _28284 = 1;
    }
    if (_28284 != 0)
    goto L4; // [54] 66

    /** parser.e:827				msgno = 236*/
    _msgno_56121 = 236;
    goto L5; // [63] 72
L4: 

    /** parser.e:829				msgno = 238*/
    _msgno_56121 = 238;
L5: 
L3: 

    /** parser.e:833		CompileErr(msgno, {SymTab[subsym][S_NAME], SymTab[subsym][S_NUM_ARGS]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28286 = (object)*(((s1_ptr)_2)->base + _subsym_56119);
    _2 = (object)SEQ_PTR(_28286);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _28287 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _28287 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _28286 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28288 = (object)*(((s1_ptr)_2)->base + _subsym_56119);
    _2 = (object)SEQ_PTR(_28288);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _28289 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _28289 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _28288 = NOVALUE;
    Ref(_28289);
    Ref(_28287);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28287;
    ((intptr_t *)_2)[2] = _28289;
    _28290 = MAKE_SEQ(_1);
    _28289 = NOVALUE;
    _28287 = NOVALUE;
    _49CompileErr(_msgno_56121, _28290, 0);
    _28290 = NOVALUE;

    /** parser.e:834	end procedure*/
    DeRefDSi(_only_56120);
    return;
    ;
}


void _43MissingArgs(object _subsym_56150)
{
    object _eentry_56151 = NOVALUE;
    object _28295 = NOVALUE;
    object _28294 = NOVALUE;
    object _28293 = NOVALUE;
    object _28292 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:837		sequence eentry = SymTab[subsym]*/
    DeRef(_eentry_56151);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _eentry_56151 = (object)*(((s1_ptr)_2)->base + _subsym_56150);
    Ref(_eentry_56151);

    /** parser.e:839		CompileErr(MSG_1_NEEDS_AT_LEAST_2_PARAMETERS_BUT_SOME_NONDEFAULTABLE_ARGUMENTS_ARE_MISSING, {eentry[S_NAME], eentry[S_DEF_ARGS][2]})*/
    _2 = (object)SEQ_PTR(_eentry_56151);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _28292 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _28292 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _2 = (object)SEQ_PTR(_eentry_56151);
    _28293 = (object)*(((s1_ptr)_2)->base + 28);
    _2 = (object)SEQ_PTR(_28293);
    _28294 = (object)*(((s1_ptr)_2)->base + 2);
    _28293 = NOVALUE;
    Ref(_28294);
    Ref(_28292);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28292;
    ((intptr_t *)_2)[2] = _28294;
    _28295 = MAKE_SEQ(_1);
    _28294 = NOVALUE;
    _28292 = NOVALUE;
    _49CompileErr(235, _28295, 0);
    _28295 = NOVALUE;

    /** parser.e:840	end procedure*/
    DeRefDS(_eentry_56151);
    return;
    ;
}


void _43Parse_default_arg(object _subsym_56165, object _arg_56166, object _fwd_private_list_56167, object _fwd_private_sym_56168)
{
    object _param_56170 = NOVALUE;
    object _28315 = NOVALUE;
    object _28314 = NOVALUE;
    object _28313 = NOVALUE;
    object _28312 = NOVALUE;
    object _28311 = NOVALUE;
    object _28310 = NOVALUE;
    object _28309 = NOVALUE;
    object _28308 = NOVALUE;
    object _28307 = NOVALUE;
    object _28306 = NOVALUE;
    object _28305 = NOVALUE;
    object _28304 = NOVALUE;
    object _28303 = NOVALUE;
    object _28301 = NOVALUE;
    object _28300 = NOVALUE;
    object _28297 = NOVALUE;
    object _28296 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:843		symtab_index param = subsym*/
    _param_56170 = _subsym_56165;

    /** parser.e:844		on_arg = arg*/
    _43on_arg_55698 = _arg_56166;

    /** parser.e:845		parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_43private_list_55696)){
            _28296 = SEQ_PTR(_43private_list_55696)->length;
    }
    else {
        _28296 = 1;
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28296;
    ((intptr_t*)_2)[2] = _43lock_scanner_55697;
    ((intptr_t*)_2)[3] = _12use_private_list_20340;
    ((intptr_t*)_2)[4] = _43on_arg_55698;
    _28297 = MAKE_SEQ(_1);
    _28296 = NOVALUE;
    RefDS(_28297);
    Append(&_43parseargs_states_55691, _43parseargs_states_55691, _28297);
    DeRefDS(_28297);
    _28297 = NOVALUE;

    /** parser.e:847		nested_calls &= subsym*/
    Append(&_43nested_calls_55699, _43nested_calls_55699, _subsym_56165);

    /** parser.e:849		for i = 1 to arg do*/
    _28300 = _arg_56166;
    {
        object _i_56177;
        _i_56177 = 1;
L1: 
        if (_i_56177 > _28300){
            goto L2; // [60] 90
        }

        /** parser.e:850			param = SymTab[param][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28301 = (object)*(((s1_ptr)_2)->base + _param_56170);
        _2 = (object)SEQ_PTR(_28301);
        _param_56170 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_56170)){
            _param_56170 = (object)DBL_PTR(_param_56170)->dbl;
        }
        _28301 = NOVALUE;

        /** parser.e:851		end for*/
        _i_56177 = _i_56177 + 1;
        goto L1; // [85] 67
L2: 
        ;
    }

    /** parser.e:853		private_list = fwd_private_list*/
    RefDS(_fwd_private_list_56167);
    DeRef(_43private_list_55696);
    _43private_list_55696 = _fwd_private_list_56167;

    /** parser.e:854		private_sym  = fwd_private_sym*/
    RefDS(_fwd_private_sym_56168);
    DeRef(_12private_sym_20339);
    _12private_sym_20339 = _fwd_private_sym_56168;

    /** parser.e:856		if atom(SymTab[param][S_CODE]) then  -- but no default set*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28303 = (object)*(((s1_ptr)_2)->base + _param_56170);
    _2 = (object)SEQ_PTR(_28303);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _28304 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _28304 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    _28303 = NOVALUE;
    _28305 = IS_ATOM(_28304);
    _28304 = NOVALUE;
    if (_28305 == 0)
    {
        _28305 = NOVALUE;
        goto L3; // [121] 164
    }
    else{
        _28305 = NOVALUE;
    }

    /** parser.e:857			CompileErr(ARGUMENT_1_OF_2_3_WAS_OMITTED_BUT_THERE_IS_NO_DEFAULT_VALUE_DEFINED, {arg, SymTab[subsym][S_NAME], SymTab[param][S_NAME]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28306 = (object)*(((s1_ptr)_2)->base + _subsym_56165);
    _2 = (object)SEQ_PTR(_28306);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _28307 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _28307 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _28306 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28308 = (object)*(((s1_ptr)_2)->base + _param_56170);
    _2 = (object)SEQ_PTR(_28308);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _28309 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _28309 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _28308 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _arg_56166;
    Ref(_28307);
    ((intptr_t*)_2)[2] = _28307;
    Ref(_28309);
    ((intptr_t*)_2)[3] = _28309;
    _28310 = MAKE_SEQ(_1);
    _28309 = NOVALUE;
    _28307 = NOVALUE;
    _49CompileErr(26, _28310, 0);
    _28310 = NOVALUE;
L3: 

    /** parser.e:860		use_private_list = 1*/
    _12use_private_list_20340 = 1;

    /** parser.e:861		lock_scanner = 1*/
    _43lock_scanner_55697 = 1;

    /** parser.e:862		start_playback(SymTab[param][S_CODE] )*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28311 = (object)*(((s1_ptr)_2)->base + _param_56170);
    _2 = (object)SEQ_PTR(_28311);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _28312 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _28312 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    _28311 = NOVALUE;
    Ref(_28312);
    _43start_playback(_28312);
    _28312 = NOVALUE;

    /** parser.e:863		call_proc(forward_expr, {})*/
    _0 = (object)_00[_43forward_expr_55987].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:865		add_private_symbol( Top(), SymTab[param][S_NAME] )*/
    _28313 = _45Top();
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28314 = (object)*(((s1_ptr)_2)->base + _param_56170);
    _2 = (object)SEQ_PTR(_28314);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _28315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _28315 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _28314 = NOVALUE;
    Ref(_28315);
    _42add_private_symbol(_28313, _28315);
    _28313 = NOVALUE;
    _28315 = NOVALUE;

    /** parser.e:866		lock_scanner = 0*/
    _43lock_scanner_55697 = 0;

    /** parser.e:867		restore_parseargs_states()*/
    _43restore_parseargs_states();

    /** parser.e:868	end procedure*/
    DeRefDS(_fwd_private_list_56167);
    DeRefDSi(_fwd_private_sym_56168);
    return;
    ;
}


void _43ParseArgs(object _subsym_56216)
{
    object _n_56217 = NOVALUE;
    object _fda_56218 = NOVALUE;
    object _lnda_56219 = NOVALUE;
    object _tok_56221 = NOVALUE;
    object _s_56223 = NOVALUE;
    object _var_code_56224 = NOVALUE;
    object _name_56225 = NOVALUE;
    object _28425 = NOVALUE;
    object _28423 = NOVALUE;
    object _28419 = NOVALUE;
    object _28418 = NOVALUE;
    object _28417 = NOVALUE;
    object _28414 = NOVALUE;
    object _28411 = NOVALUE;
    object _28409 = NOVALUE;
    object _28407 = NOVALUE;
    object _28405 = NOVALUE;
    object _28403 = NOVALUE;
    object _28402 = NOVALUE;
    object _28401 = NOVALUE;
    object _28400 = NOVALUE;
    object _28399 = NOVALUE;
    object _28398 = NOVALUE;
    object _28397 = NOVALUE;
    object _28391 = NOVALUE;
    object _28390 = NOVALUE;
    object _28389 = NOVALUE;
    object _28388 = NOVALUE;
    object _28387 = NOVALUE;
    object _28386 = NOVALUE;
    object _28383 = NOVALUE;
    object _28380 = NOVALUE;
    object _28375 = NOVALUE;
    object _28373 = NOVALUE;
    object _28372 = NOVALUE;
    object _28371 = NOVALUE;
    object _28369 = NOVALUE;
    object _28366 = NOVALUE;
    object _28363 = NOVALUE;
    object _28361 = NOVALUE;
    object _28359 = NOVALUE;
    object _28357 = NOVALUE;
    object _28355 = NOVALUE;
    object _28354 = NOVALUE;
    object _28353 = NOVALUE;
    object _28352 = NOVALUE;
    object _28351 = NOVALUE;
    object _28350 = NOVALUE;
    object _28349 = NOVALUE;
    object _28347 = NOVALUE;
    object _28346 = NOVALUE;
    object _28345 = NOVALUE;
    object _28344 = NOVALUE;
    object _28343 = NOVALUE;
    object _28342 = NOVALUE;
    object _28339 = NOVALUE;
    object _28338 = NOVALUE;
    object _28337 = NOVALUE;
    object _28335 = NOVALUE;
    object _28334 = NOVALUE;
    object _28332 = NOVALUE;
    object _28328 = NOVALUE;
    object _28327 = NOVALUE;
    object _28325 = NOVALUE;
    object _28324 = NOVALUE;
    object _28322 = NOVALUE;
    object _28321 = NOVALUE;
    object _28320 = NOVALUE;
    object _28319 = NOVALUE;
    object _28318 = NOVALUE;
    object _28316 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_56216)) {
        _1 = (object)(DBL_PTR(_subsym_56216)->dbl);
        DeRefDS(_subsym_56216);
        _subsym_56216 = _1;
    }

    /** parser.e:875		object var_code*/

    /** parser.e:876		sequence name*/

    /** parser.e:878		n = SymTab[subsym][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28316 = (object)*(((s1_ptr)_2)->base + _subsym_56216);
    _2 = (object)SEQ_PTR(_28316);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _n_56217 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _n_56217 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    if (!IS_ATOM_INT(_n_56217)){
        _n_56217 = (object)DBL_PTR(_n_56217)->dbl;
    }
    _28316 = NOVALUE;

    /** parser.e:879		if sequence(SymTab[subsym][S_DEF_ARGS]) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28318 = (object)*(((s1_ptr)_2)->base + _subsym_56216);
    _2 = (object)SEQ_PTR(_28318);
    _28319 = (object)*(((s1_ptr)_2)->base + 28);
    _28318 = NOVALUE;
    _28320 = IS_SEQUENCE(_28319);
    _28319 = NOVALUE;
    if (_28320 == 0)
    {
        _28320 = NOVALUE;
        goto L1; // [40] 86
    }
    else{
        _28320 = NOVALUE;
    }

    /** parser.e:880			fda = SymTab[subsym][S_DEF_ARGS][1]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28321 = (object)*(((s1_ptr)_2)->base + _subsym_56216);
    _2 = (object)SEQ_PTR(_28321);
    _28322 = (object)*(((s1_ptr)_2)->base + 28);
    _28321 = NOVALUE;
    _2 = (object)SEQ_PTR(_28322);
    _fda_56218 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_fda_56218)){
        _fda_56218 = (object)DBL_PTR(_fda_56218)->dbl;
    }
    _28322 = NOVALUE;

    /** parser.e:881			lnda = SymTab[subsym][S_DEF_ARGS][2]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28324 = (object)*(((s1_ptr)_2)->base + _subsym_56216);
    _2 = (object)SEQ_PTR(_28324);
    _28325 = (object)*(((s1_ptr)_2)->base + 28);
    _28324 = NOVALUE;
    _2 = (object)SEQ_PTR(_28325);
    _lnda_56219 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_lnda_56219)){
        _lnda_56219 = (object)DBL_PTR(_lnda_56219)->dbl;
    }
    _28325 = NOVALUE;
    goto L2; // [83] 97
L1: 

    /** parser.e:883			fda = 0*/
    _fda_56218 = 0;

    /** parser.e:884			lnda = 0*/
    _lnda_56219 = 0;
L2: 

    /** parser.e:886		s = subsym*/
    _s_56223 = _subsym_56216;

    /** parser.e:888		parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_43private_list_55696)){
            _28327 = SEQ_PTR(_43private_list_55696)->length;
    }
    else {
        _28327 = 1;
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28327;
    ((intptr_t*)_2)[2] = _43lock_scanner_55697;
    ((intptr_t*)_2)[3] = _12use_private_list_20340;
    ((intptr_t*)_2)[4] = _43on_arg_55698;
    _28328 = MAKE_SEQ(_1);
    _28327 = NOVALUE;
    RefDS(_28328);
    Append(&_43parseargs_states_55691, _43parseargs_states_55691, _28328);
    DeRefDS(_28328);
    _28328 = NOVALUE;

    /** parser.e:890		nested_calls &= subsym*/
    Append(&_43nested_calls_55699, _43nested_calls_55699, _subsym_56216);

    /** parser.e:891		lock_scanner = 0*/
    _43lock_scanner_55697 = 0;

    /** parser.e:892		on_arg = 0*/
    _43on_arg_55698 = 0;

    /** parser.e:894		short_circuit -= 1*/
    _43short_circuit_54952 = _43short_circuit_54952 - 1;

    /** parser.e:895		for i = 1 to n do*/
    _28332 = _n_56217;
    {
        object _i_56254;
        _i_56254 = 1;
L3: 
        if (_i_56254 > _28332){
            goto L4; // [161] 1050
        }

        /** parser.e:897		  	tok = next_token()*/
        _0 = _tok_56221;
        _tok_56221 = _43next_token();
        DeRef(_0);

        /** parser.e:899			if tok[T_ID] = QUESTION_MARK or tok[T_ID] = COMMA then*/
        _2 = (object)SEQ_PTR(_tok_56221);
        _28334 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_28334)) {
            _28335 = (_28334 == -31);
        }
        else {
            _28335 = binary_op(EQUALS, _28334, -31);
        }
        _28334 = NOVALUE;
        if (IS_ATOM_INT(_28335)) {
            if (_28335 != 0) {
                goto L5; // [187] 208
            }
        }
        else {
            if (DBL_PTR(_28335)->dbl != 0.0) {
                goto L5; // [187] 208
            }
        }
        _2 = (object)SEQ_PTR(_tok_56221);
        _28337 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_28337)) {
            _28338 = (_28337 == -30);
        }
        else {
            _28338 = binary_op(EQUALS, _28337, -30);
        }
        _28337 = NOVALUE;
        if (_28338 == 0) {
            DeRef(_28338);
            _28338 = NOVALUE;
            goto L6; // [204] 505
        }
        else {
            if (!IS_ATOM_INT(_28338) && DBL_PTR(_28338)->dbl == 0.0){
                DeRef(_28338);
                _28338 = NOVALUE;
                goto L6; // [204] 505
            }
            DeRef(_28338);
            _28338 = NOVALUE;
        }
        DeRef(_28338);
        _28338 = NOVALUE;
L5: 

        /** parser.e:902				if tok[T_ID] = QUESTION_MARK then*/
        _2 = (object)SEQ_PTR(_tok_56221);
        _28339 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28339, -31)){
            _28339 = NOVALUE;
            goto L7; // [218] 297
        }
        _28339 = NOVALUE;

        /** parser.e:903					tok = next_token()*/
        _0 = _tok_56221;
        _tok_56221 = _43next_token();
        DeRef(_0);

        /** parser.e:904					if tok[T_ID] != RIGHT_ROUND and tok[T_ID] != COMMA then*/
        _2 = (object)SEQ_PTR(_tok_56221);
        _28342 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_28342)) {
            _28343 = (_28342 != -27);
        }
        else {
            _28343 = binary_op(NOTEQ, _28342, -27);
        }
        _28342 = NOVALUE;
        if (IS_ATOM_INT(_28343)) {
            if (_28343 == 0) {
                goto L8; // [241] 273
            }
        }
        else {
            if (DBL_PTR(_28343)->dbl == 0.0) {
                goto L8; // [241] 273
            }
        }
        _2 = (object)SEQ_PTR(_tok_56221);
        _28345 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_28345)) {
            _28346 = (_28345 != -30);
        }
        else {
            _28346 = binary_op(NOTEQ, _28345, -30);
        }
        _28345 = NOVALUE;
        if (_28346 == 0) {
            DeRef(_28346);
            _28346 = NOVALUE;
            goto L8; // [258] 273
        }
        else {
            if (!IS_ATOM_INT(_28346) && DBL_PTR(_28346)->dbl == 0.0){
                DeRef(_28346);
                _28346 = NOVALUE;
                goto L8; // [258] 273
            }
            DeRef(_28346);
            _28346 = NOVALUE;
        }
        DeRef(_28346);
        _28346 = NOVALUE;

        /** parser.e:905						CompileErr( BADLYFORMED_LIST_OF_PARAMETERS__EXPECTED__OR)*/
        RefDS(_22015);
        _49CompileErr(41, _22015, 0);
        goto L9; // [270] 298
L8: 

        /** parser.e:906					elsif tok[T_ID] = RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56221);
        _28347 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28347, -27)){
            _28347 = NOVALUE;
            goto L9; // [283] 298
        }
        _28347 = NOVALUE;

        /** parser.e:907						putback( tok )*/
        Ref(_tok_56221);
        _43putback(_tok_56221);
        goto L9; // [294] 298
L7: 
L9: 

        /** parser.e:912				if SymTab[subsym][S_OPCODE] then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28349 = (object)*(((s1_ptr)_2)->base + _subsym_56216);
        _2 = (object)SEQ_PTR(_28349);
        _28350 = (object)*(((s1_ptr)_2)->base + 21);
        _28349 = NOVALUE;
        if (_28350 == 0) {
            _28350 = NOVALUE;
            goto LA; // [312] 372
        }
        else {
            if (!IS_ATOM_INT(_28350) && DBL_PTR(_28350)->dbl == 0.0){
                _28350 = NOVALUE;
                goto LA; // [312] 372
            }
            _28350 = NOVALUE;
        }
        _28350 = NOVALUE;

        /** parser.e:913					if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28351 = (object)*(((s1_ptr)_2)->base + _subsym_56216);
        _2 = (object)SEQ_PTR(_28351);
        if (!IS_ATOM_INT(_12S_CODE_19876)){
            _28352 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        }
        else{
            _28352 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
        }
        _28351 = NOVALUE;
        _28353 = IS_ATOM(_28352);
        _28352 = NOVALUE;
        if (_28353 == 0)
        {
            _28353 = NOVALUE;
            goto LB; // [332] 343
        }
        else{
            _28353 = NOVALUE;
        }

        /** parser.e:914						var_code = 0*/
        DeRef(_var_code_56224);
        _var_code_56224 = 0;
        goto LC; // [340] 362
LB: 

        /** parser.e:916						var_code = SymTab[subsym][S_CODE][i]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28354 = (object)*(((s1_ptr)_2)->base + _subsym_56216);
        _2 = (object)SEQ_PTR(_28354);
        if (!IS_ATOM_INT(_12S_CODE_19876)){
            _28355 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        }
        else{
            _28355 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
        }
        _28354 = NOVALUE;
        DeRef(_var_code_56224);
        _2 = (object)SEQ_PTR(_28355);
        _var_code_56224 = (object)*(((s1_ptr)_2)->base + _i_56254);
        Ref(_var_code_56224);
        _28355 = NOVALUE;
LC: 

        /** parser.e:918					name = ""*/
        RefDS(_22015);
        DeRef(_name_56225);
        _name_56225 = _22015;
        goto LD; // [369] 419
LA: 

        /** parser.e:920					s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28357 = (object)*(((s1_ptr)_2)->base + _s_56223);
        _2 = (object)SEQ_PTR(_28357);
        _s_56223 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_56223)){
            _s_56223 = (object)DBL_PTR(_s_56223)->dbl;
        }
        _28357 = NOVALUE;

        /** parser.e:921					var_code = SymTab[s][S_CODE]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28359 = (object)*(((s1_ptr)_2)->base + _s_56223);
        DeRef(_var_code_56224);
        _2 = (object)SEQ_PTR(_28359);
        if (!IS_ATOM_INT(_12S_CODE_19876)){
            _var_code_56224 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        }
        else{
            _var_code_56224 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
        }
        Ref(_var_code_56224);
        _28359 = NOVALUE;

        /** parser.e:922					name = SymTab[s][S_NAME]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28361 = (object)*(((s1_ptr)_2)->base + _s_56223);
        DeRef(_name_56225);
        _2 = (object)SEQ_PTR(_28361);
        if (!IS_ATOM_INT(_12S_NAME_19864)){
            _name_56225 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
        }
        else{
            _name_56225 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
        }
        Ref(_name_56225);
        _28361 = NOVALUE;
LD: 

        /** parser.e:925				if atom(var_code) then  -- but no default set*/
        _28363 = IS_ATOM(_var_code_56224);
        if (_28363 == 0)
        {
            _28363 = NOVALUE;
            goto LE; // [426] 439
        }
        else{
            _28363 = NOVALUE;
        }

        /** parser.e:926					CompileErr(ARGUMENT_1_WAS_OMITTED_BUT_THERE_IS_NO_DEFAULT_VALUE_DEFINED,i)*/
        _49CompileErr(29, _i_56254, 0);
LE: 

        /** parser.e:929				use_private_list = 1*/
        _12use_private_list_20340 = 1;

        /** parser.e:930				start_playback(var_code)*/
        Ref(_var_code_56224);
        _43start_playback(_var_code_56224);

        /** parser.e:931				lock_scanner=1*/
        _43lock_scanner_55697 = 1;

        /** parser.e:934				Expr()*/
        _43Expr();

        /** parser.e:935				lock_scanner=0*/
        _43lock_scanner_55697 = 0;

        /** parser.e:936				on_arg += 1*/
        _43on_arg_55698 = _43on_arg_55698 + 1;

        /** parser.e:937				private_list = append(private_list,name)*/
        RefDS(_name_56225);
        Append(&_43private_list_55696, _43private_list_55696, _name_56225);

        /** parser.e:938				private_sym &= Top()*/
        _28366 = _45Top();
        if (IS_SEQUENCE(_12private_sym_20339) && IS_ATOM(_28366)) {
            Ref(_28366);
            Append(&_12private_sym_20339, _12private_sym_20339, _28366);
        }
        else if (IS_ATOM(_12private_sym_20339) && IS_SEQUENCE(_28366)) {
        }
        else {
            Concat((object_ptr)&_12private_sym_20339, _12private_sym_20339, _28366);
        }
        DeRef(_28366);
        _28366 = NOVALUE;

        /** parser.e:939				backed_up_tok = {tok} -- ????*/
        _0 = _43backed_up_tok_54959;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_tok_56221);
        ((intptr_t*)_2)[1] = _tok_56221;
        _43backed_up_tok_54959 = MAKE_SEQ(_1);
        DeRef(_0);
        goto LF; // [502] 633
L6: 

        /** parser.e:942			elsif tok[T_ID] != RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56221);
        _28369 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(EQUALS, _28369, -27)){
            _28369 = NOVALUE;
            goto L10; // [515] 632
        }
        _28369 = NOVALUE;

        /** parser.e:944				if SymTab[subsym][S_OPCODE] then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28371 = (object)*(((s1_ptr)_2)->base + _subsym_56216);
        _2 = (object)SEQ_PTR(_28371);
        _28372 = (object)*(((s1_ptr)_2)->base + 21);
        _28371 = NOVALUE;
        if (_28372 == 0) {
            _28372 = NOVALUE;
            goto L11; // [533] 546
        }
        else {
            if (!IS_ATOM_INT(_28372) && DBL_PTR(_28372)->dbl == 0.0){
                _28372 = NOVALUE;
                goto L11; // [533] 546
            }
            _28372 = NOVALUE;
        }
        _28372 = NOVALUE;

        /** parser.e:945					name = ""*/
        RefDS(_22015);
        DeRef(_name_56225);
        _name_56225 = _22015;
        goto L12; // [543] 579
L11: 

        /** parser.e:947					s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28373 = (object)*(((s1_ptr)_2)->base + _s_56223);
        _2 = (object)SEQ_PTR(_28373);
        _s_56223 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_56223)){
            _s_56223 = (object)DBL_PTR(_s_56223)->dbl;
        }
        _28373 = NOVALUE;

        /** parser.e:948					name = SymTab[s][S_NAME]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28375 = (object)*(((s1_ptr)_2)->base + _s_56223);
        DeRef(_name_56225);
        _2 = (object)SEQ_PTR(_28375);
        if (!IS_ATOM_INT(_12S_NAME_19864)){
            _name_56225 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
        }
        else{
            _name_56225 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
        }
        Ref(_name_56225);
        _28375 = NOVALUE;
L12: 

        /** parser.e:951				use_private_list = Parser_mode != PAM_NORMAL*/
        _12use_private_list_20340 = (_12Parser_mode_20332 != 0);

        /** parser.e:952				putback(tok)*/
        Ref(_tok_56221);
        _43putback(_tok_56221);

        /** parser.e:953				Expr()*/
        _43Expr();

        /** parser.e:954				on_arg += 1*/
        _43on_arg_55698 = _43on_arg_55698 + 1;

        /** parser.e:955				private_list = append(private_list,name)*/
        RefDS(_name_56225);
        Append(&_43private_list_55696, _43private_list_55696, _name_56225);

        /** parser.e:956				private_sym &= Top()*/
        _28380 = _45Top();
        if (IS_SEQUENCE(_12private_sym_20339) && IS_ATOM(_28380)) {
            Ref(_28380);
            Append(&_12private_sym_20339, _12private_sym_20339, _28380);
        }
        else if (IS_ATOM(_12private_sym_20339) && IS_SEQUENCE(_28380)) {
        }
        else {
            Concat((object_ptr)&_12private_sym_20339, _12private_sym_20339, _28380);
        }
        DeRef(_28380);
        _28380 = NOVALUE;
L10: 
LF: 

        /** parser.e:959			if on_arg != n then*/
        if (_43on_arg_55698 == _n_56217)
        goto L13; // [637] 1043

        /** parser.e:960				if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56221);
        _28383 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28383, -27)){
            _28383 = NOVALUE;
            goto L14; // [651] 661
        }
        _28383 = NOVALUE;

        /** parser.e:961					putback( tok )*/
        Ref(_tok_56221);
        _43putback(_tok_56221);
L14: 

        /** parser.e:963				tok = next_token()*/
        _0 = _tok_56221;
        _tok_56221 = _43next_token();
        DeRef(_0);

        /** parser.e:964				if tok[T_ID] != COMMA and tok[T_ID] != QUESTION_MARK then*/
        _2 = (object)SEQ_PTR(_tok_56221);
        _28386 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_28386)) {
            _28387 = (_28386 != -30);
        }
        else {
            _28387 = binary_op(NOTEQ, _28386, -30);
        }
        _28386 = NOVALUE;
        if (IS_ATOM_INT(_28387)) {
            if (_28387 == 0) {
                goto L15; // [680] 1042
            }
        }
        else {
            if (DBL_PTR(_28387)->dbl == 0.0) {
                goto L15; // [680] 1042
            }
        }
        _2 = (object)SEQ_PTR(_tok_56221);
        _28389 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_28389)) {
            _28390 = (_28389 != -31);
        }
        else {
            _28390 = binary_op(NOTEQ, _28389, -31);
        }
        _28389 = NOVALUE;
        if (_28390 == 0) {
            DeRef(_28390);
            _28390 = NOVALUE;
            goto L15; // [697] 1042
        }
        else {
            if (!IS_ATOM_INT(_28390) && DBL_PTR(_28390)->dbl == 0.0){
                DeRef(_28390);
                _28390 = NOVALUE;
                goto L15; // [697] 1042
            }
            DeRef(_28390);
            _28390 = NOVALUE;
        }
        DeRef(_28390);
        _28390 = NOVALUE;

        /** parser.e:966			  		if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56221);
        _28391 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28391, -27)){
            _28391 = NOVALUE;
            goto L16; // [710] 1027
        }
        _28391 = NOVALUE;

        /** parser.e:968						if fda=0 then*/
        if (_fda_56218 != 0)
        goto L17; // [718] 731

        /** parser.e:969							WrongNumberArgs(subsym, "")*/
        RefDS(_22015);
        _43WrongNumberArgs(_subsym_56216, _22015);
        goto L18; // [728] 746
L17: 

        /** parser.e:970						elsif i<lnda then*/
        if (_i_56254 >= _lnda_56219)
        goto L19; // [735] 745

        /** parser.e:971							MissingArgs(subsym)*/
        _43MissingArgs(_subsym_56216);
L19: 
L18: 

        /** parser.e:973						lock_scanner = 1*/
        _43lock_scanner_55697 = 1;

        /** parser.e:974						use_private_list = 1*/
        _12use_private_list_20340 = 1;

        /** parser.e:977						while on_arg < n do*/
L1A: 
        if (_43on_arg_55698 >= _n_56217)
        goto L1B; // [765] 976

        /** parser.e:978							on_arg += 1*/
        _43on_arg_55698 = _43on_arg_55698 + 1;

        /** parser.e:979							if SymTab[subsym][S_OPCODE] then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28397 = (object)*(((s1_ptr)_2)->base + _subsym_56216);
        _2 = (object)SEQ_PTR(_28397);
        _28398 = (object)*(((s1_ptr)_2)->base + 21);
        _28397 = NOVALUE;
        if (_28398 == 0) {
            _28398 = NOVALUE;
            goto L1C; // [791] 853
        }
        else {
            if (!IS_ATOM_INT(_28398) && DBL_PTR(_28398)->dbl == 0.0){
                _28398 = NOVALUE;
                goto L1C; // [791] 853
            }
            _28398 = NOVALUE;
        }
        _28398 = NOVALUE;

        /** parser.e:980								if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28399 = (object)*(((s1_ptr)_2)->base + _subsym_56216);
        _2 = (object)SEQ_PTR(_28399);
        if (!IS_ATOM_INT(_12S_CODE_19876)){
            _28400 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        }
        else{
            _28400 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
        }
        _28399 = NOVALUE;
        _28401 = IS_ATOM(_28400);
        _28400 = NOVALUE;
        if (_28401 == 0)
        {
            _28401 = NOVALUE;
            goto L1D; // [811] 822
        }
        else{
            _28401 = NOVALUE;
        }

        /** parser.e:981									var_code = 0*/
        DeRef(_var_code_56224);
        _var_code_56224 = 0;
        goto L1E; // [819] 843
L1D: 

        /** parser.e:983									var_code = SymTab[subsym][S_CODE][on_arg]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28402 = (object)*(((s1_ptr)_2)->base + _subsym_56216);
        _2 = (object)SEQ_PTR(_28402);
        if (!IS_ATOM_INT(_12S_CODE_19876)){
            _28403 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        }
        else{
            _28403 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
        }
        _28402 = NOVALUE;
        DeRef(_var_code_56224);
        _2 = (object)SEQ_PTR(_28403);
        _var_code_56224 = (object)*(((s1_ptr)_2)->base + _43on_arg_55698);
        Ref(_var_code_56224);
        _28403 = NOVALUE;
L1E: 

        /** parser.e:986								name = ""*/
        RefDS(_22015);
        DeRef(_name_56225);
        _name_56225 = _22015;
        goto L1F; // [850] 900
L1C: 

        /** parser.e:989								s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28405 = (object)*(((s1_ptr)_2)->base + _s_56223);
        _2 = (object)SEQ_PTR(_28405);
        _s_56223 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_56223)){
            _s_56223 = (object)DBL_PTR(_s_56223)->dbl;
        }
        _28405 = NOVALUE;

        /** parser.e:990								var_code = SymTab[s][S_CODE]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28407 = (object)*(((s1_ptr)_2)->base + _s_56223);
        DeRef(_var_code_56224);
        _2 = (object)SEQ_PTR(_28407);
        if (!IS_ATOM_INT(_12S_CODE_19876)){
            _var_code_56224 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        }
        else{
            _var_code_56224 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
        }
        Ref(_var_code_56224);
        _28407 = NOVALUE;

        /** parser.e:991								name = SymTab[s][S_NAME]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28409 = (object)*(((s1_ptr)_2)->base + _s_56223);
        DeRef(_name_56225);
        _2 = (object)SEQ_PTR(_28409);
        if (!IS_ATOM_INT(_12S_NAME_19864)){
            _name_56225 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
        }
        else{
            _name_56225 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
        }
        Ref(_name_56225);
        _28409 = NOVALUE;
L1F: 

        /** parser.e:993							if sequence(var_code) then*/
        _28411 = IS_SEQUENCE(_var_code_56224);
        if (_28411 == 0)
        {
            _28411 = NOVALUE;
            goto L20; // [907] 959
        }
        else{
            _28411 = NOVALUE;
        }

        /** parser.e:995								putback( tok )*/
        Ref(_tok_56221);
        _43putback(_tok_56221);

        /** parser.e:996								start_playback(var_code)*/
        Ref(_var_code_56224);
        _43start_playback(_var_code_56224);

        /** parser.e:999								Expr()*/
        _43Expr();

        /** parser.e:1000								if on_arg < n then*/
        if (_43on_arg_55698 >= _n_56217)
        goto L1A; // [928] 763

        /** parser.e:1001									private_list = append(private_list,name)*/
        RefDS(_name_56225);
        Append(&_43private_list_55696, _43private_list_55696, _name_56225);

        /** parser.e:1002									private_sym &= Top()*/
        _28414 = _45Top();
        if (IS_SEQUENCE(_12private_sym_20339) && IS_ATOM(_28414)) {
            Ref(_28414);
            Append(&_12private_sym_20339, _12private_sym_20339, _28414);
        }
        else if (IS_ATOM(_12private_sym_20339) && IS_SEQUENCE(_28414)) {
        }
        else {
            Concat((object_ptr)&_12private_sym_20339, _12private_sym_20339, _28414);
        }
        DeRef(_28414);
        _28414 = NOVALUE;
        goto L1A; // [956] 763
L20: 

        /** parser.e:1005								CompileErr(ARGUMENT_1_WAS_OMITTED_BUT_THERE_IS_NO_DEFAULT_VALUE_DEFINED, on_arg)*/
        _49CompileErr(29, _43on_arg_55698, 0);

        /** parser.e:1007			  		    end while*/
        goto L1A; // [973] 763
L1B: 

        /** parser.e:1009						short_circuit += 1*/
        _43short_circuit_54952 = _43short_circuit_54952 + 1;

        /** parser.e:1010						if backed_up_tok[$][T_ID] = PLAYBACK_ENDS then*/
        if (IS_SEQUENCE(_43backed_up_tok_54959)){
                _28417 = SEQ_PTR(_43backed_up_tok_54959)->length;
        }
        else {
            _28417 = 1;
        }
        _2 = (object)SEQ_PTR(_43backed_up_tok_54959);
        _28418 = (object)*(((s1_ptr)_2)->base + _28417);
        _2 = (object)SEQ_PTR(_28418);
        _28419 = (object)*(((s1_ptr)_2)->base + 1);
        _28418 = NOVALUE;
        if (binary_op_a(NOTEQ, _28419, 505)){
            _28419 = NOVALUE;
            goto L21; // [1003] 1015
        }
        _28419 = NOVALUE;

        /** parser.e:1011							backed_up_tok = {}*/
        RefDS(_22015);
        DeRefDS(_43backed_up_tok_54959);
        _43backed_up_tok_54959 = _22015;
L21: 

        /** parser.e:1014						restore_parseargs_states()*/
        _43restore_parseargs_states();

        /** parser.e:1016						return*/
        DeRef(_tok_56221);
        DeRef(_var_code_56224);
        DeRef(_name_56225);
        DeRef(_28335);
        _28335 = NOVALUE;
        DeRef(_28343);
        _28343 = NOVALUE;
        DeRef(_28387);
        _28387 = NOVALUE;
        return;
        goto L22; // [1024] 1041
L16: 

        /** parser.e:1018						putback(tok)*/
        Ref(_tok_56221);
        _43putback(_tok_56221);

        /** parser.e:1019						tok_match(COMMA)*/
        _43tok_match(-30, 0);
L22: 
L15: 
L13: 

        /** parser.e:1024		end for*/
        _i_56254 = _i_56254 + 1;
        goto L3; // [1045] 168
L4: 
        ;
    }

    /** parser.e:1025		tok = next_token()*/
    _0 = _tok_56221;
    _tok_56221 = _43next_token();
    DeRef(_0);

    /** parser.e:1026		short_circuit += 1*/
    _43short_circuit_54952 = _43short_circuit_54952 + 1;

    /** parser.e:1027		if tok[T_ID] != RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_56221);
    _28423 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28423, -27)){
        _28423 = NOVALUE;
        goto L23; // [1073] 1115
    }
    _28423 = NOVALUE;

    /** parser.e:1028			if tok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok_56221);
    _28425 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28425, -30)){
        _28425 = NOVALUE;
        goto L24; // [1087] 1100
    }
    _28425 = NOVALUE;

    /** parser.e:1029				WrongNumberArgs(subsym, "only ")*/
    RefDS(_28427);
    _43WrongNumberArgs(_subsym_56216, _28427);
    goto L25; // [1097] 1114
L24: 

    /** parser.e:1031				putback(tok)*/
    Ref(_tok_56221);
    _43putback(_tok_56221);

    /** parser.e:1032				tok_match(RIGHT_ROUND)*/
    _43tok_match(-27, 0);
L25: 
L23: 

    /** parser.e:1036		restore_parseargs_states()*/
    _43restore_parseargs_states();

    /** parser.e:1037	end procedure*/
    DeRef(_tok_56221);
    DeRef(_var_code_56224);
    DeRef(_name_56225);
    DeRef(_28335);
    _28335 = NOVALUE;
    DeRef(_28343);
    _28343 = NOVALUE;
    DeRef(_28387);
    _28387 = NOVALUE;
    return;
    ;
}


void _43Forward_var(object _tok_56466, object _init_check_56467, object _op_56468)
{
    object _ref_56472 = NOVALUE;
    object _28431 = NOVALUE;
    object _28429 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_op_56468)) {
        _1 = (object)(DBL_PTR(_op_56468)->dbl);
        DeRefDS(_op_56468);
        _op_56468 = _1;
    }

    /** parser.e:1041		ref = new_forward_reference( VARIABLE, tok[T_SYM], op )*/
    _2 = (object)SEQ_PTR(_tok_56466);
    _28429 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28429);
    _ref_56472 = _42new_forward_reference(-100, _28429, _op_56468);
    _28429 = NOVALUE;
    if (!IS_ATOM_INT(_ref_56472)) {
        _1 = (object)(DBL_PTR(_ref_56472)->dbl);
        DeRefDS(_ref_56472);
        _ref_56472 = _1;
    }

    /** parser.e:1042		emit_opnd( - ref )*/
    if ((uintptr_t)_ref_56472 == (uintptr_t)HIGH_BITS){
        _28431 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _28431 = - _ref_56472;
    }
    _45emit_opnd(_28431);
    _28431 = NOVALUE;

    /** parser.e:1043		if init_check != -1 then*/
    if (_init_check_56467 == -1)
    goto L1; // [33] 44

    /** parser.e:1044			Forward_InitCheck( tok, init_check )*/
    Ref(_tok_56466);
    _43Forward_InitCheck(_tok_56466, _init_check_56467);
L1: 

    /** parser.e:1047	end procedure*/
    DeRef(_tok_56466);
    return;
    ;
}


void _43Forward_call(object _tok_56485, object _opcode_56486)
{
    object _args_56489 = NOVALUE;
    object _proc_56491 = NOVALUE;
    object _tok_id_56494 = NOVALUE;
    object _id_56501 = NOVALUE;
    object _fc_pc_56525 = NOVALUE;
    object _28450 = NOVALUE;
    object _28449 = NOVALUE;
    object _28446 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1050		integer args = 0*/
    _args_56489 = 0;

    /** parser.e:1051		symtab_index proc = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_56485);
    _proc_56491 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_proc_56491)){
        _proc_56491 = (object)DBL_PTR(_proc_56491)->dbl;
    }

    /** parser.e:1052		integer tok_id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56485);
    _tok_id_56494 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_tok_id_56494)){
        _tok_id_56494 = (object)DBL_PTR(_tok_id_56494)->dbl;
    }

    /** parser.e:1053		remove_symbol( proc )*/
    _53remove_symbol(_proc_56491);

    /** parser.e:1054		short_circuit -= 1*/
    _43short_circuit_54952 = _43short_circuit_54952 - 1;

    /** parser.e:1055		while 1 do*/
L1: 

    /** parser.e:1056			tok = next_token()*/
    _0 = _tok_56485;
    _tok_56485 = _43next_token();
    DeRef(_0);

    /** parser.e:1057			integer id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56485);
    _id_56501 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_56501)){
        _id_56501 = (object)DBL_PTR(_id_56501)->dbl;
    }

    /** parser.e:1059			switch id do*/
    _0 = _id_56501;
    switch ( _0 ){ 

        /** parser.e:1060				case COMMA then*/
        case -30:

        /** parser.e:1061					emit_opnd( 0 ) -- clean this up later*/
        _45emit_opnd(0);

        /** parser.e:1062					args += 1*/
        _args_56489 = _args_56489 + 1;
        goto L2; // [83] 168

        /** parser.e:1064				case RIGHT_ROUND then*/
        case -27:

        /** parser.e:1065					exit*/
        goto L3; // [93] 175
        goto L2; // [95] 168

        /** parser.e:1067				case else*/
        default:

        /** parser.e:1068					putback( tok )*/
        Ref(_tok_56485);
        _43putback(_tok_56485);

        /** parser.e:1069					call_proc( forward_expr, {} )*/
        _0 = (object)_00[_43forward_expr_55987].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1070					args += 1*/
        _args_56489 = _args_56489 + 1;

        /** parser.e:1072					tok = next_token()*/
        _0 = _tok_56485;
        _tok_56485 = _43next_token();
        DeRef(_0);

        /** parser.e:1073					id = tok[T_ID]*/
        _2 = (object)SEQ_PTR(_tok_56485);
        _id_56501 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_id_56501)){
            _id_56501 = (object)DBL_PTR(_id_56501)->dbl;
        }

        /** parser.e:1074					if id = RIGHT_ROUND then*/
        if (_id_56501 != -27)
        goto L4; // [138] 149

        /** parser.e:1075						exit*/
        goto L3; // [146] 175
L4: 

        /** parser.e:1078					if id != COMMA then*/
        if (_id_56501 == -30)
        goto L5; // [153] 167

        /** parser.e:1079							CompileErr(EXPECTED__OR)*/
        RefDS(_22015);
        _49CompileErr(69, _22015, 0);
L5: 
    ;}L2: 

    /** parser.e:1082		end while*/
    goto L1; // [172] 46
L3: 

    /** parser.e:1084		integer fc_pc = length( Code ) + 1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _28446 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _28446 = 1;
    }
    _fc_pc_56525 = _28446 + 1;
    _28446 = NOVALUE;

    /** parser.e:1085		emit_opnd( args )*/
    _45emit_opnd(_args_56489);

    /** parser.e:1087		op_info1 = proc*/
    _45op_info1_50960 = _proc_56491;

    /** parser.e:1088		if tok_id = QUALIFIED_VARIABLE then*/
    if (_tok_id_56494 != 512)
    goto L6; // [202] 226

    /** parser.e:1089			set_qualified_fwd( SymTab[proc][S_FILE_NO] )*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28449 = (object)*(((s1_ptr)_2)->base + _proc_56491);
    _2 = (object)SEQ_PTR(_28449);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _28450 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _28450 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _28449 = NOVALUE;
    Ref(_28450);
    _61set_qualified_fwd(_28450);
    _28450 = NOVALUE;
    goto L7; // [223] 232
L6: 

    /** parser.e:1091			set_qualified_fwd( -1 )*/
    _61set_qualified_fwd(-1);
L7: 

    /** parser.e:1093		emit_op( opcode )*/
    _45emit_op(_opcode_56486);

    /** parser.e:1094		if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto L8; // [241] 260

    /** parser.e:1095			if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto L9; // [248] 259
    }
    else{
    }

    /** parser.e:1096				emit_op(UPDATE_GLOBALS)*/
    _45emit_op(89);
L9: 
L8: 

    /** parser.e:1099		short_circuit += 1*/
    _43short_circuit_54952 = _43short_circuit_54952 + 1;

    /** parser.e:1100	end procedure*/
    DeRef(_tok_56485);
    return;
    ;
}


void _43Object_call(object _tok_56553)
{
    object _tok2_56555 = NOVALUE;
    object _tok3_56556 = NOVALUE;
    object _save_factors_56557 = NOVALUE;
    object _save_lhs_subs_level_56558 = NOVALUE;
    object _sym_56560 = NOVALUE;
    object _28508 = NOVALUE;
    object _28506 = NOVALUE;
    object _28503 = NOVALUE;
    object _28499 = NOVALUE;
    object _28493 = NOVALUE;
    object _28490 = NOVALUE;
    object _28489 = NOVALUE;
    object _28488 = NOVALUE;
    object _28486 = NOVALUE;
    object _28485 = NOVALUE;
    object _28483 = NOVALUE;
    object _28482 = NOVALUE;
    object _28479 = NOVALUE;
    object _28478 = NOVALUE;
    object _28477 = NOVALUE;
    object _28475 = NOVALUE;
    object _28474 = NOVALUE;
    object _28472 = NOVALUE;
    object _28471 = NOVALUE;
    object _28470 = NOVALUE;
    object _28469 = NOVALUE;
    object _28467 = NOVALUE;
    object _28466 = NOVALUE;
    object _28464 = NOVALUE;
    object _28463 = NOVALUE;
    object _28460 = NOVALUE;
    object _28458 = NOVALUE;
    object _28457 = NOVALUE;
    object _28455 = NOVALUE;
    object _28454 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1104		integer save_factors, save_lhs_subs_level*/

    /** parser.e:1107		tok2 = next_token()*/
    _0 = _tok2_56555;
    _tok2_56555 = _43next_token();
    DeRef(_0);

    /** parser.e:1108		if tok2[T_ID] = VARIABLE or tok2[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok2_56555);
    _28454 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28454)) {
        _28455 = (_28454 == -100);
    }
    else {
        _28455 = binary_op(EQUALS, _28454, -100);
    }
    _28454 = NOVALUE;
    if (IS_ATOM_INT(_28455)) {
        if (_28455 != 0) {
            goto L1; // [22] 43
        }
    }
    else {
        if (DBL_PTR(_28455)->dbl != 0.0) {
            goto L1; // [22] 43
        }
    }
    _2 = (object)SEQ_PTR(_tok2_56555);
    _28457 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28457)) {
        _28458 = (_28457 == 512);
    }
    else {
        _28458 = binary_op(EQUALS, _28457, 512);
    }
    _28457 = NOVALUE;
    if (_28458 == 0) {
        DeRef(_28458);
        _28458 = NOVALUE;
        goto L2; // [39] 582
    }
    else {
        if (!IS_ATOM_INT(_28458) && DBL_PTR(_28458)->dbl == 0.0){
            DeRef(_28458);
            _28458 = NOVALUE;
            goto L2; // [39] 582
        }
        DeRef(_28458);
        _28458 = NOVALUE;
    }
    DeRef(_28458);
    _28458 = NOVALUE;
L1: 

    /** parser.e:1109			tok3 = next_token()*/
    _0 = _tok3_56556;
    _tok3_56556 = _43next_token();
    DeRef(_0);

    /** parser.e:1110			if tok3[T_ID] = RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok3_56556);
    _28460 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28460, -27)){
        _28460 = NOVALUE;
        goto L3; // [58] 155
    }
    _28460 = NOVALUE;

    /** parser.e:1112				sym = tok2[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok2_56555);
    _sym_56560 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_56560)){
        _sym_56560 = (object)DBL_PTR(_sym_56560)->dbl;
    }

    /** parser.e:1113				if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28463 = (object)*(((s1_ptr)_2)->base + _sym_56560);
    _2 = (object)SEQ_PTR(_28463);
    _28464 = (object)*(((s1_ptr)_2)->base + 4);
    _28463 = NOVALUE;
    if (binary_op_a(NOTEQ, _28464, 9)){
        _28464 = NOVALUE;
        goto L4; // [88] 108
    }
    _28464 = NOVALUE;

    /** parser.e:1114					Forward_var( tok2 )*/
    _2 = (object)SEQ_PTR(_tok2_56555);
    _28466 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_tok2_56555);
    Ref(_28466);
    _43Forward_var(_tok2_56555, -1, _28466);
    _28466 = NOVALUE;
    goto L5; // [105] 147
L4: 

    /** parser.e:1116					SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_56560 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28469 = (object)*(((s1_ptr)_2)->base + _sym_56560);
    _2 = (object)SEQ_PTR(_28469);
    _28470 = (object)*(((s1_ptr)_2)->base + 5);
    _28469 = NOVALUE;
    if (IS_ATOM_INT(_28470)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28470 | (uintptr_t)1;
             _28471 = MAKE_UINT(tu);
        }
    }
    else {
        _28471 = binary_op(OR_BITS, _28470, 1);
    }
    _28470 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28471;
    if( _1 != _28471 ){
        DeRef(_1);
    }
    _28471 = NOVALUE;
    _28467 = NOVALUE;

    /** parser.e:1118					emit_opnd(sym)*/
    _45emit_opnd(_sym_56560);
L5: 

    /** parser.e:1120				putback( tok3 )*/
    Ref(_tok3_56556);
    _43putback(_tok3_56556);
    goto L6; // [152] 571
L3: 

    /** parser.e:1122			elsif tok3[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok3_56556);
    _28472 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28472, -30)){
        _28472 = NOVALUE;
        goto L7; // [165] 184
    }
    _28472 = NOVALUE;

    /** parser.e:1124				WrongNumberArgs(tok[T_SYM], "")*/
    _2 = (object)SEQ_PTR(_tok_56553);
    _28474 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28474);
    RefDS(_22015);
    _43WrongNumberArgs(_28474, _22015);
    _28474 = NOVALUE;
    goto L6; // [181] 571
L7: 

    /** parser.e:1126			elsif tok3[T_ID] = LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok3_56556);
    _28475 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28475, -26)){
        _28475 = NOVALUE;
        goto L8; // [194] 244
    }
    _28475 = NOVALUE;

    /** parser.e:1127				if SymTab[tok2[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok2_56555);
    _28477 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28477)){
        _28478 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28477)->dbl));
    }
    else{
        _28478 = (object)*(((s1_ptr)_2)->base + _28477);
    }
    _2 = (object)SEQ_PTR(_28478);
    _28479 = (object)*(((s1_ptr)_2)->base + 4);
    _28478 = NOVALUE;
    if (binary_op_a(NOTEQ, _28479, 9)){
        _28479 = NOVALUE;
        goto L9; // [220] 235
    }
    _28479 = NOVALUE;

    /** parser.e:1128					Forward_call( tok2, FUNC_FORWARD )*/
    Ref(_tok2_56555);
    _43Forward_call(_tok2_56555, 196);
    goto L6; // [232] 571
L9: 

    /** parser.e:1130					Function_call( tok2 )*/
    Ref(_tok2_56555);
    _43Function_call(_tok2_56555);
    goto L6; // [241] 571
L8: 

    /** parser.e:1139				sym = tok2[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok2_56555);
    _sym_56560 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_56560)){
        _sym_56560 = (object)DBL_PTR(_sym_56560)->dbl;
    }

    /** parser.e:1140				if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28482 = (object)*(((s1_ptr)_2)->base + _sym_56560);
    _2 = (object)SEQ_PTR(_28482);
    _28483 = (object)*(((s1_ptr)_2)->base + 4);
    _28482 = NOVALUE;
    if (binary_op_a(NOTEQ, _28483, 9)){
        _28483 = NOVALUE;
        goto LA; // [270] 292
    }
    _28483 = NOVALUE;

    /** parser.e:1141					Forward_var( tok2, TRUE )*/
    _2 = (object)SEQ_PTR(_tok2_56555);
    _28485 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_tok2_56555);
    Ref(_28485);
    _43Forward_var(_tok2_56555, _9TRUE_446, _28485);
    _28485 = NOVALUE;
    goto LB; // [289] 339
LA: 

    /** parser.e:1143					SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_56560 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28488 = (object)*(((s1_ptr)_2)->base + _sym_56560);
    _2 = (object)SEQ_PTR(_28488);
    _28489 = (object)*(((s1_ptr)_2)->base + 5);
    _28488 = NOVALUE;
    if (IS_ATOM_INT(_28489)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28489 | (uintptr_t)1;
             _28490 = MAKE_UINT(tu);
        }
    }
    else {
        _28490 = binary_op(OR_BITS, _28489, 1);
    }
    _28489 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28490;
    if( _1 != _28490 ){
        DeRef(_1);
    }
    _28490 = NOVALUE;
    _28486 = NOVALUE;

    /** parser.e:1144					InitCheck(sym, TRUE)*/
    _43InitCheck(_sym_56560, _9TRUE_446);

    /** parser.e:1145					emit_opnd(sym)*/
    _45emit_opnd(_sym_56560);
LB: 

    /** parser.e:1149				if sym = left_sym then*/
    if (_sym_56560 != _43left_sym_54993)
    goto LC; // [343] 353

    /** parser.e:1150					lhs_subs_level = 0*/
    _43lhs_subs_level_54991 = 0;
LC: 

    /** parser.e:1155				tok2 = tok3*/
    Ref(_tok3_56556);
    DeRef(_tok2_56555);
    _tok2_56555 = _tok3_56556;

    /** parser.e:1156				current_sequence = append(current_sequence, sym)*/
    Append(&_45current_sequence_50968, _45current_sequence_50968, _sym_56560);

    /** parser.e:1157				while tok2[T_ID] = LEFT_SQUARE do*/
LD: 
    _2 = (object)SEQ_PTR(_tok2_56555);
    _28493 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28493, -28)){
        _28493 = NOVALUE;
        goto LE; // [381] 549
    }
    _28493 = NOVALUE;

    /** parser.e:1158					subs_depth += 1*/
    _43subs_depth_54994 = _43subs_depth_54994 + 1;

    /** parser.e:1159					if lhs_subs_level >= 0 then*/
    if (_43lhs_subs_level_54991 < 0)
    goto LF; // [397] 410

    /** parser.e:1160						lhs_subs_level += 1*/
    _43lhs_subs_level_54991 = _43lhs_subs_level_54991 + 1;
LF: 

    /** parser.e:1162					save_factors = factors*/
    _save_factors_56557 = _43factors_54990;

    /** parser.e:1163					save_lhs_subs_level = lhs_subs_level*/
    _save_lhs_subs_level_56558 = _43lhs_subs_level_54991;

    /** parser.e:1164					call_proc(forward_expr, {})*/
    _0 = (object)_00[_43forward_expr_55987].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:1165					tok2 = next_token()*/
    _0 = _tok2_56555;
    _tok2_56555 = _43next_token();
    DeRef(_0);

    /** parser.e:1166					if tok2[T_ID] = SLICE then*/
    _2 = (object)SEQ_PTR(_tok2_56555);
    _28499 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28499, 513)){
        _28499 = NOVALUE;
        goto L10; // [446] 484
    }
    _28499 = NOVALUE;

    /** parser.e:1167						call_proc(forward_expr, {})*/
    _0 = (object)_00[_43forward_expr_55987].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:1168						emit_op(RHS_SLICE)*/
    _45emit_op(46);

    /** parser.e:1169						tok_match(RIGHT_SQUARE)*/
    _43tok_match(-29, 0);

    /** parser.e:1170						tok2 = next_token()*/
    _0 = _tok2_56555;
    _tok2_56555 = _43next_token();
    DeRef(_0);

    /** parser.e:1171						exit*/
    goto LE; // [479] 549
    goto L11; // [481] 529
L10: 

    /** parser.e:1173						putback(tok2)*/
    Ref(_tok2_56555);
    _43putback(_tok2_56555);

    /** parser.e:1174						tok_match(RIGHT_SQUARE)*/
    _43tok_match(-29, 0);

    /** parser.e:1175						subs_depth -= 1*/
    _43subs_depth_54994 = _43subs_depth_54994 - 1;

    /** parser.e:1176						current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_45current_sequence_50968)){
            _28503 = SEQ_PTR(_45current_sequence_50968)->length;
    }
    else {
        _28503 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45current_sequence_50968);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28503)) ? _28503 : (object)(DBL_PTR(_28503)->dbl);
        int stop = (IS_ATOM_INT(_28503)) ? _28503 : (object)(DBL_PTR(_28503)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45current_sequence_50968), start, &_45current_sequence_50968 );
            }
            else Tail(SEQ_PTR(_45current_sequence_50968), stop+1, &_45current_sequence_50968);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45current_sequence_50968), start, &_45current_sequence_50968);
        }
        else {
            assign_slice_seq = &assign_space;
            _45current_sequence_50968 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_50968)->ref == 1));
        }
    }
    _28503 = NOVALUE;
    _28503 = NOVALUE;

    /** parser.e:1177						emit_op(RHS_SUBS)*/
    _45emit_op(25);
L11: 

    /** parser.e:1180					factors = save_factors*/
    _43factors_54990 = _save_factors_56557;

    /** parser.e:1181					lhs_subs_level = save_lhs_subs_level*/
    _43lhs_subs_level_54991 = _save_lhs_subs_level_56558;

    /** parser.e:1182					tok2 = next_token()*/
    _0 = _tok2_56555;
    _tok2_56555 = _43next_token();
    DeRef(_0);

    /** parser.e:1183				end while*/
    goto LD; // [546] 373
LE: 

    /** parser.e:1184				current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_45current_sequence_50968)){
            _28506 = SEQ_PTR(_45current_sequence_50968)->length;
    }
    else {
        _28506 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45current_sequence_50968);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28506)) ? _28506 : (object)(DBL_PTR(_28506)->dbl);
        int stop = (IS_ATOM_INT(_28506)) ? _28506 : (object)(DBL_PTR(_28506)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45current_sequence_50968), start, &_45current_sequence_50968 );
            }
            else Tail(SEQ_PTR(_45current_sequence_50968), stop+1, &_45current_sequence_50968);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45current_sequence_50968), start, &_45current_sequence_50968);
        }
        else {
            assign_slice_seq = &assign_space;
            _45current_sequence_50968 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_50968)->ref == 1));
        }
    }
    _28506 = NOVALUE;
    _28506 = NOVALUE;

    /** parser.e:1185				putback(tok2)*/
    Ref(_tok2_56555);
    _43putback(_tok2_56555);
L6: 

    /** parser.e:1189			tok_match( RIGHT_ROUND )*/
    _43tok_match(-27, 0);
    goto L12; // [579] 599
L2: 

    /** parser.e:1191			putback(tok2)*/
    Ref(_tok2_56555);
    _43putback(_tok2_56555);

    /** parser.e:1192			ParseArgs(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_56553);
    _28508 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28508);
    _43ParseArgs(_28508);
    _28508 = NOVALUE;
L12: 

    /** parser.e:1194	end procedure*/
    DeRef(_tok_56553);
    DeRef(_tok2_56555);
    DeRef(_tok3_56556);
    _28477 = NOVALUE;
    DeRef(_28455);
    _28455 = NOVALUE;
    return;
    ;
}


void _43Function_call(object _tok_56698)
{
    object _id_56699 = NOVALUE;
    object _scope_56700 = NOVALUE;
    object _opcode_56701 = NOVALUE;
    object _e_56702 = NOVALUE;
    object _28549 = NOVALUE;
    object _28548 = NOVALUE;
    object _28547 = NOVALUE;
    object _28546 = NOVALUE;
    object _28545 = NOVALUE;
    object _28544 = NOVALUE;
    object _28543 = NOVALUE;
    object _28541 = NOVALUE;
    object _28540 = NOVALUE;
    object _28538 = NOVALUE;
    object _28537 = NOVALUE;
    object _28536 = NOVALUE;
    object _28535 = NOVALUE;
    object _28534 = NOVALUE;
    object _28533 = NOVALUE;
    object _28532 = NOVALUE;
    object _28531 = NOVALUE;
    object _28530 = NOVALUE;
    object _28529 = NOVALUE;
    object _28528 = NOVALUE;
    object _28527 = NOVALUE;
    object _28526 = NOVALUE;
    object _28525 = NOVALUE;
    object _28524 = NOVALUE;
    object _28522 = NOVALUE;
    object _28520 = NOVALUE;
    object _28519 = NOVALUE;
    object _28517 = NOVALUE;
    object _28515 = NOVALUE;
    object _28514 = NOVALUE;
    object _28513 = NOVALUE;
    object _28512 = NOVALUE;
    object _28510 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1200		id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56698);
    _id_56699 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_56699)){
        _id_56699 = (object)DBL_PTR(_id_56699)->dbl;
    }

    /** parser.e:1201		if id = FUNC or id = TYPE then*/
    _28510 = (_id_56699 == 501);
    if (_28510 != 0) {
        goto L1; // [19] 34
    }
    _28512 = (_id_56699 == 504);
    if (_28512 == 0)
    {
        DeRef(_28512);
        _28512 = NOVALUE;
        goto L2; // [30] 46
    }
    else{
        DeRef(_28512);
        _28512 = NOVALUE;
    }
L1: 

    /** parser.e:1203			UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_56698);
    _28513 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28513);
    _43UndefinedVar(_28513);
    _28513 = NOVALUE;
L2: 

    /** parser.e:1206		e = SymTab[tok[T_SYM]][S_EFFECT]*/
    _2 = (object)SEQ_PTR(_tok_56698);
    _28514 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28514)){
        _28515 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28514)->dbl));
    }
    else{
        _28515 = (object)*(((s1_ptr)_2)->base + _28514);
    }
    _2 = (object)SEQ_PTR(_28515);
    _e_56702 = (object)*(((s1_ptr)_2)->base + 23);
    if (!IS_ATOM_INT(_e_56702)){
        _e_56702 = (object)DBL_PTR(_e_56702)->dbl;
    }
    _28515 = NOVALUE;

    /** parser.e:1207		if e then*/
    if (_e_56702 == 0)
    {
        goto L3; // [70] 229
    }
    else{
    }

    /** parser.e:1209			if e = E_ALL_EFFECT or tok[T_SYM] > left_sym then*/
    _28517 = (_e_56702 == 1073741823);
    if (_28517 != 0) {
        goto L4; // [81] 102
    }
    _2 = (object)SEQ_PTR(_tok_56698);
    _28519 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_28519)) {
        _28520 = (_28519 > _43left_sym_54993);
    }
    else {
        _28520 = binary_op(GREATER, _28519, _43left_sym_54993);
    }
    _28519 = NOVALUE;
    if (_28520 == 0) {
        DeRef(_28520);
        _28520 = NOVALUE;
        goto L5; // [98] 111
    }
    else {
        if (!IS_ATOM_INT(_28520) && DBL_PTR(_28520)->dbl == 0.0){
            DeRef(_28520);
            _28520 = NOVALUE;
            goto L5; // [98] 111
        }
        DeRef(_28520);
        _28520 = NOVALUE;
    }
    DeRef(_28520);
    _28520 = NOVALUE;
L4: 

    /** parser.e:1211				side_effect_calls = or_bits(side_effect_calls, e)*/
    {uintptr_t tu;
         tu = (uintptr_t)_43side_effect_calls_54989 | (uintptr_t)_e_56702;
         _43side_effect_calls_54989 = MAKE_UINT(tu);
    }
L5: 

    /** parser.e:1214			SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT], e)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28524 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_28524);
    _28525 = (object)*(((s1_ptr)_2)->base + 23);
    _28524 = NOVALUE;
    if (IS_ATOM_INT(_28525)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28525 | (uintptr_t)_e_56702;
             _28526 = MAKE_UINT(tu);
        }
    }
    else {
        _28526 = binary_op(OR_BITS, _28525, _e_56702);
    }
    _28525 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28526;
    if( _1 != _28526 ){
        DeRef(_1);
    }
    _28526 = NOVALUE;
    _28522 = NOVALUE;

    /** parser.e:1216			if short_circuit > 0 and short_circuit_B and*/
    _28527 = (_43short_circuit_54952 > 0);
    if (_28527 == 0) {
        _28528 = 0;
        goto L6; // [154] 164
    }
    _28528 = (_43short_circuit_B_54954 != 0);
L6: 
    if (_28528 == 0) {
        goto L7; // [164] 228
    }
    _28530 = find_from(_id_56699, _29FUNC_TOKS_12018, 1);
    if (_28530 == 0)
    {
        _28530 = NOVALUE;
        goto L7; // [176] 228
    }
    else{
        _28530 = NOVALUE;
    }

    /** parser.e:1218				Warning(219, short_circuit_warning_flag,*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _28531 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    Ref(_28531);
    RefDS(_22015);
    _28532 = _14abbreviate_path(_28531, _22015);
    _28531 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_56698);
    _28533 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28533)){
        _28534 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28533)->dbl));
    }
    else{
        _28534 = (object)*(((s1_ptr)_2)->base + _28533);
    }
    _2 = (object)SEQ_PTR(_28534);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _28535 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _28535 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _28534 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28532;
    ((intptr_t*)_2)[2] = _12line_number_20227;
    Ref(_28535);
    ((intptr_t*)_2)[3] = _28535;
    _28536 = MAKE_SEQ(_1);
    _28535 = NOVALUE;
    _28532 = NOVALUE;
    _49Warning(219, 2, _28536);
    _28536 = NOVALUE;
L7: 
L3: 

    /** parser.e:1222		tok_match(LEFT_ROUND)*/
    _43tok_match(-26, 0);

    /** parser.e:1223		scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_tok_56698);
    _28537 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28537)){
        _28538 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28537)->dbl));
    }
    else{
        _28538 = (object)*(((s1_ptr)_2)->base + _28537);
    }
    _2 = (object)SEQ_PTR(_28538);
    _scope_56700 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_56700)){
        _scope_56700 = (object)DBL_PTR(_scope_56700)->dbl;
    }
    _28538 = NOVALUE;

    /** parser.e:1224		opcode = SymTab[tok[T_SYM]][S_OPCODE]*/
    _2 = (object)SEQ_PTR(_tok_56698);
    _28540 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28540)){
        _28541 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28540)->dbl));
    }
    else{
        _28541 = (object)*(((s1_ptr)_2)->base + _28540);
    }
    _2 = (object)SEQ_PTR(_28541);
    _opcode_56701 = (object)*(((s1_ptr)_2)->base + 21);
    if (!IS_ATOM_INT(_opcode_56701)){
        _opcode_56701 = (object)DBL_PTR(_opcode_56701)->dbl;
    }
    _28541 = NOVALUE;

    /** parser.e:1225		if equal(SymTab[tok[T_SYM]][S_NAME],"object") and scope = SC_PREDEF then*/
    _2 = (object)SEQ_PTR(_tok_56698);
    _28543 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28543)){
        _28544 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28543)->dbl));
    }
    else{
        _28544 = (object)*(((s1_ptr)_2)->base + _28543);
    }
    _2 = (object)SEQ_PTR(_28544);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _28545 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _28545 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _28544 = NOVALUE;
    if (_28545 == _22977)
    _28546 = 1;
    else if (IS_ATOM_INT(_28545) && IS_ATOM_INT(_22977))
    _28546 = 0;
    else
    _28546 = (compare(_28545, _22977) == 0);
    _28545 = NOVALUE;
    if (_28546 == 0) {
        goto L8; // [305] 327
    }
    _28548 = (_scope_56700 == 7);
    if (_28548 == 0)
    {
        DeRef(_28548);
        _28548 = NOVALUE;
        goto L8; // [316] 327
    }
    else{
        DeRef(_28548);
        _28548 = NOVALUE;
    }

    /** parser.e:1227			Object_call( tok )*/
    Ref(_tok_56698);
    _43Object_call(_tok_56698);
    goto L9; // [324] 339
L8: 

    /** parser.e:1230			ParseArgs(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_56698);
    _28549 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28549);
    _43ParseArgs(_28549);
    _28549 = NOVALUE;
L9: 

    /** parser.e:1233		if scope = SC_PREDEF then*/
    if (_scope_56700 != 7)
    goto LA; // [343] 355

    /** parser.e:1234			emit_op(opcode)*/
    _45emit_op(_opcode_56701);
    goto LB; // [352] 393
LA: 

    /** parser.e:1236			op_info1 = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_56698);
    _45op_info1_50960 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_45op_info1_50960)){
        _45op_info1_50960 = (object)DBL_PTR(_45op_info1_50960)->dbl;
    }

    /** parser.e:1238			emit_or_inline()*/
    _66emit_or_inline();

    /** parser.e:1239			if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto LC; // [373] 392

    /** parser.e:1240				if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto LD; // [380] 391
    }
    else{
    }

    /** parser.e:1241					emit_op(UPDATE_GLOBALS)*/
    _45emit_op(89);
LD: 
LC: 
LB: 

    /** parser.e:1245	end procedure*/
    DeRef(_tok_56698);
    _28514 = NOVALUE;
    _28543 = NOVALUE;
    _28537 = NOVALUE;
    DeRef(_28510);
    _28510 = NOVALUE;
    _28533 = NOVALUE;
    _28540 = NOVALUE;
    DeRef(_28527);
    _28527 = NOVALUE;
    DeRef(_28517);
    _28517 = NOVALUE;
    return;
    ;
}


void _43Factor()
{
    object _tok_56806 = NOVALUE;
    object _id_56807 = NOVALUE;
    object _n_56808 = NOVALUE;
    object _save_factors_56809 = NOVALUE;
    object _save_lhs_subs_level_56810 = NOVALUE;
    object _sym_56812 = NOVALUE;
    object _forward_56843 = NOVALUE;
    object _28609 = NOVALUE;
    object _28608 = NOVALUE;
    object _28607 = NOVALUE;
    object _28605 = NOVALUE;
    object _28604 = NOVALUE;
    object _28603 = NOVALUE;
    object _28602 = NOVALUE;
    object _28601 = NOVALUE;
    object _28599 = NOVALUE;
    object _28595 = NOVALUE;
    object _28592 = NOVALUE;
    object _28588 = NOVALUE;
    object _28582 = NOVALUE;
    object _28577 = NOVALUE;
    object _28576 = NOVALUE;
    object _28575 = NOVALUE;
    object _28573 = NOVALUE;
    object _28572 = NOVALUE;
    object _28570 = NOVALUE;
    object _28568 = NOVALUE;
    object _28567 = NOVALUE;
    object _28566 = NOVALUE;
    object _28564 = NOVALUE;
    object _28557 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1250		integer id, n*/

    /** parser.e:1251		integer save_factors, save_lhs_subs_level*/

    /** parser.e:1254		factors += 1*/
    _43factors_54990 = _43factors_54990 + 1;

    /** parser.e:1255		tok = next_token()*/
    _0 = _tok_56806;
    _tok_56806 = _43next_token();
    DeRef(_0);

    /** parser.e:1256		id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56806);
    _id_56807 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_56807)){
        _id_56807 = (object)DBL_PTR(_id_56807)->dbl;
    }

    /** parser.e:1257		if id = RECORDED then*/
    if (_id_56807 != 508)
    goto L1; // [32] 59

    /** parser.e:1258			tok = read_recorded_token(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_56806);
    _28557 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28557);
    _0 = _tok_56806;
    _tok_56806 = _43read_recorded_token(_28557);
    DeRef(_0);
    _28557 = NOVALUE;

    /** parser.e:1259			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56806);
    _id_56807 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_56807)){
        _id_56807 = (object)DBL_PTR(_id_56807)->dbl;
    }
L1: 

    /** parser.e:1261		switch id label "factor" do*/
    _0 = _id_56807;
    switch ( _0 ){ 

        /** parser.e:1262			case VARIABLE, QUALIFIED_VARIABLE then*/
        case -100:
        case 512:

        /** parser.e:1263				sym = tok[T_SYM]*/
        _2 = (object)SEQ_PTR(_tok_56806);
        _sym_56812 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_56812)){
            _sym_56812 = (object)DBL_PTR(_sym_56812)->dbl;
        }

        /** parser.e:1264				if sym < 0 or SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
        _28564 = (_sym_56812 < 0);
        if (_28564 != 0) {
            goto L2; // [88] 115
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28566 = (object)*(((s1_ptr)_2)->base + _sym_56812);
        _2 = (object)SEQ_PTR(_28566);
        _28567 = (object)*(((s1_ptr)_2)->base + 4);
        _28566 = NOVALUE;
        if (IS_ATOM_INT(_28567)) {
            _28568 = (_28567 == 9);
        }
        else {
            _28568 = binary_op(EQUALS, _28567, 9);
        }
        _28567 = NOVALUE;
        if (_28568 == 0) {
            DeRef(_28568);
            _28568 = NOVALUE;
            goto L3; // [111] 177
        }
        else {
            if (!IS_ATOM_INT(_28568) && DBL_PTR(_28568)->dbl == 0.0){
                DeRef(_28568);
                _28568 = NOVALUE;
                goto L3; // [111] 177
            }
            DeRef(_28568);
            _28568 = NOVALUE;
        }
        DeRef(_28568);
        _28568 = NOVALUE;
L2: 

        /** parser.e:1265					token forward = next_token()*/
        _0 = _forward_56843;
        _forward_56843 = _43next_token();
        DeRef(_0);

        /** parser.e:1266					if forward[T_ID] = LEFT_ROUND then*/
        _2 = (object)SEQ_PTR(_forward_56843);
        _28570 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28570, -26)){
            _28570 = NOVALUE;
            goto L4; // [130] 151
        }
        _28570 = NOVALUE;

        /** parser.e:1267						Forward_call( tok, FUNC_FORWARD )*/
        Ref(_tok_56806);
        _43Forward_call(_tok_56806, 196);

        /** parser.e:1268						break "factor"*/
        DeRef(_forward_56843);
        _forward_56843 = NOVALUE;
        goto L5; // [146] 694
        goto L6; // [148] 172
L4: 

        /** parser.e:1270						putback( forward )*/
        Ref(_forward_56843);
        _43putback(_forward_56843);

        /** parser.e:1271						Forward_var( tok, TRUE )*/
        _2 = (object)SEQ_PTR(_tok_56806);
        _28572 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_tok_56806);
        Ref(_28572);
        _43Forward_var(_tok_56806, _9TRUE_446, _28572);
        _28572 = NOVALUE;
L6: 
        DeRef(_forward_56843);
        _forward_56843 = NOVALUE;
        goto L7; // [174] 229
L3: 

        /** parser.e:1275					UndefinedVar(sym)*/
        _43UndefinedVar(_sym_56812);

        /** parser.e:1276					SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_sym_56812 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28575 = (object)*(((s1_ptr)_2)->base + _sym_56812);
        _2 = (object)SEQ_PTR(_28575);
        _28576 = (object)*(((s1_ptr)_2)->base + 5);
        _28575 = NOVALUE;
        if (IS_ATOM_INT(_28576)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_28576 | (uintptr_t)1;
                 _28577 = MAKE_UINT(tu);
            }
        }
        else {
            _28577 = binary_op(OR_BITS, _28576, 1);
        }
        _28576 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28577;
        if( _1 != _28577 ){
            DeRef(_1);
        }
        _28577 = NOVALUE;
        _28573 = NOVALUE;

        /** parser.e:1277					InitCheck(sym, TRUE)*/
        _43InitCheck(_sym_56812, _9TRUE_446);

        /** parser.e:1278					emit_opnd(sym)*/
        _45emit_opnd(_sym_56812);
L7: 

        /** parser.e:1281				if sym = left_sym then*/
        if (_sym_56812 != _43left_sym_54993)
        goto L8; // [233] 243

        /** parser.e:1282					lhs_subs_level = 0 -- start counting subscripts*/
        _43lhs_subs_level_54991 = 0;
L8: 

        /** parser.e:1285				short_circuit -= 1*/
        _43short_circuit_54952 = _43short_circuit_54952 - 1;

        /** parser.e:1286				tok = next_token()*/
        _0 = _tok_56806;
        _tok_56806 = _43next_token();
        DeRef(_0);

        /** parser.e:1287				current_sequence = append(current_sequence, sym)*/
        Append(&_45current_sequence_50968, _45current_sequence_50968, _sym_56812);

        /** parser.e:1288				while tok[T_ID] = LEFT_SQUARE do*/
L9: 
        _2 = (object)SEQ_PTR(_tok_56806);
        _28582 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28582, -28)){
            _28582 = NOVALUE;
            goto LA; // [279] 447
        }
        _28582 = NOVALUE;

        /** parser.e:1289					subs_depth += 1*/
        _43subs_depth_54994 = _43subs_depth_54994 + 1;

        /** parser.e:1290					if lhs_subs_level >= 0 then*/
        if (_43lhs_subs_level_54991 < 0)
        goto LB; // [295] 308

        /** parser.e:1291						lhs_subs_level += 1*/
        _43lhs_subs_level_54991 = _43lhs_subs_level_54991 + 1;
LB: 

        /** parser.e:1293					save_factors = factors*/
        _save_factors_56809 = _43factors_54990;

        /** parser.e:1294					save_lhs_subs_level = lhs_subs_level*/
        _save_lhs_subs_level_56810 = _43lhs_subs_level_54991;

        /** parser.e:1295					call_proc(forward_expr, {})*/
        _0 = (object)_00[_43forward_expr_55987].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1296					tok = next_token()*/
        _0 = _tok_56806;
        _tok_56806 = _43next_token();
        DeRef(_0);

        /** parser.e:1297					if tok[T_ID] = SLICE then*/
        _2 = (object)SEQ_PTR(_tok_56806);
        _28588 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28588, 513)){
            _28588 = NOVALUE;
            goto LC; // [344] 382
        }
        _28588 = NOVALUE;

        /** parser.e:1298						call_proc(forward_expr, {})*/
        _0 = (object)_00[_43forward_expr_55987].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1299						emit_op(RHS_SLICE)*/
        _45emit_op(46);

        /** parser.e:1300						tok_match(RIGHT_SQUARE)*/
        _43tok_match(-29, 0);

        /** parser.e:1301						tok = next_token()*/
        _0 = _tok_56806;
        _tok_56806 = _43next_token();
        DeRef(_0);

        /** parser.e:1302						exit*/
        goto LA; // [377] 447
        goto LD; // [379] 427
LC: 

        /** parser.e:1304						putback(tok)*/
        Ref(_tok_56806);
        _43putback(_tok_56806);

        /** parser.e:1305						tok_match(RIGHT_SQUARE)*/
        _43tok_match(-29, 0);

        /** parser.e:1306						subs_depth -= 1*/
        _43subs_depth_54994 = _43subs_depth_54994 - 1;

        /** parser.e:1307						current_sequence = remove( current_sequence, length( current_sequence ) )*/
        if (IS_SEQUENCE(_45current_sequence_50968)){
                _28592 = SEQ_PTR(_45current_sequence_50968)->length;
        }
        else {
            _28592 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_45current_sequence_50968);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_28592)) ? _28592 : (object)(DBL_PTR(_28592)->dbl);
            int stop = (IS_ATOM_INT(_28592)) ? _28592 : (object)(DBL_PTR(_28592)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_45current_sequence_50968), start, &_45current_sequence_50968 );
                }
                else Tail(SEQ_PTR(_45current_sequence_50968), stop+1, &_45current_sequence_50968);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_45current_sequence_50968), start, &_45current_sequence_50968);
            }
            else {
                assign_slice_seq = &assign_space;
                _45current_sequence_50968 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_50968)->ref == 1));
            }
        }
        _28592 = NOVALUE;
        _28592 = NOVALUE;

        /** parser.e:1308						emit_op(RHS_SUBS) -- current_sequence will be updated*/
        _45emit_op(25);
LD: 

        /** parser.e:1310					factors = save_factors*/
        _43factors_54990 = _save_factors_56809;

        /** parser.e:1311					lhs_subs_level = save_lhs_subs_level*/
        _43lhs_subs_level_54991 = _save_lhs_subs_level_56810;

        /** parser.e:1312					tok = next_token()*/
        _0 = _tok_56806;
        _tok_56806 = _43next_token();
        DeRef(_0);

        /** parser.e:1313				end while*/
        goto L9; // [444] 271
LA: 

        /** parser.e:1314				current_sequence = remove( current_sequence, length( current_sequence ) )*/
        if (IS_SEQUENCE(_45current_sequence_50968)){
                _28595 = SEQ_PTR(_45current_sequence_50968)->length;
        }
        else {
            _28595 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_45current_sequence_50968);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_28595)) ? _28595 : (object)(DBL_PTR(_28595)->dbl);
            int stop = (IS_ATOM_INT(_28595)) ? _28595 : (object)(DBL_PTR(_28595)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_45current_sequence_50968), start, &_45current_sequence_50968 );
                }
                else Tail(SEQ_PTR(_45current_sequence_50968), stop+1, &_45current_sequence_50968);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_45current_sequence_50968), start, &_45current_sequence_50968);
            }
            else {
                assign_slice_seq = &assign_space;
                _45current_sequence_50968 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_50968)->ref == 1));
            }
        }
        _28595 = NOVALUE;
        _28595 = NOVALUE;

        /** parser.e:1315				putback(tok)*/
        Ref(_tok_56806);
        _43putback(_tok_56806);

        /** parser.e:1316				short_circuit += 1*/
        _43short_circuit_54952 = _43short_circuit_54952 + 1;
        goto L5; // [476] 694

        /** parser.e:1318			case DOLLAR then*/
        case -22:

        /** parser.e:1319				tok = next_token()*/
        _0 = _tok_56806;
        _tok_56806 = _43next_token();
        DeRef(_0);

        /** parser.e:1320				putback(tok)*/
        Ref(_tok_56806);
        _43putback(_tok_56806);

        /** parser.e:1321				if tok[T_ID] = RIGHT_BRACE then*/
        _2 = (object)SEQ_PTR(_tok_56806);
        _28599 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28599, -25)){
            _28599 = NOVALUE;
            goto LE; // [502] 520
        }
        _28599 = NOVALUE;

        /** parser.e:1322					gListItem[$] = 0*/
        if (IS_SEQUENCE(_43gListItem_54988)){
                _28601 = SEQ_PTR(_43gListItem_54988)->length;
        }
        else {
            _28601 = 1;
        }
        _2 = (object)SEQ_PTR(_43gListItem_54988);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43gListItem_54988 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _28601);
        *(intptr_t *)_2 = 0;
        goto L5; // [517] 694
LE: 

        /** parser.e:1324					if subs_depth > 0 and length(current_sequence) then*/
        _28602 = (_43subs_depth_54994 > 0);
        if (_28602 == 0) {
            goto LF; // [528] 551
        }
        if (IS_SEQUENCE(_45current_sequence_50968)){
                _28604 = SEQ_PTR(_45current_sequence_50968)->length;
        }
        else {
            _28604 = 1;
        }
        if (_28604 == 0)
        {
            _28604 = NOVALUE;
            goto LF; // [538] 551
        }
        else{
            _28604 = NOVALUE;
        }

        /** parser.e:1325						emit_op(DOLLAR)*/
        _45emit_op(-22);
        goto L5; // [548] 694
LF: 

        /** parser.e:1327						CompileErr(MSG__MUST_ONLY_APPEAR_BETWEEN__AND__OR_AS_THE_LAST_ITEM_IN_A_SEQUENCE_LITERAL)*/
        RefDS(_22015);
        _49CompileErr(21, _22015, 0);
        goto L5; // [562] 694

        /** parser.e:1331			case ATOM then*/
        case 502:

        /** parser.e:1332				emit_opnd(tok[T_SYM])*/
        _2 = (object)SEQ_PTR(_tok_56806);
        _28605 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_28605);
        _45emit_opnd(_28605);
        _28605 = NOVALUE;
        goto L5; // [579] 694

        /** parser.e:1334			case LEFT_BRACE then*/
        case -24:

        /** parser.e:1335				n = Expr_list()*/
        _n_56808 = _43Expr_list();
        if (!IS_ATOM_INT(_n_56808)) {
            _1 = (object)(DBL_PTR(_n_56808)->dbl);
            DeRefDS(_n_56808);
            _n_56808 = _1;
        }

        /** parser.e:1336				tok_match(RIGHT_BRACE)*/
        _43tok_match(-25, 0);

        /** parser.e:1337				op_info1 = n*/
        _45op_info1_50960 = _n_56808;

        /** parser.e:1338				emit_op(RIGHT_BRACE_N)*/
        _45emit_op(31);
        goto L5; // [614] 694

        /** parser.e:1340			case STRING then*/
        case 503:

        /** parser.e:1341				emit_opnd(tok[T_SYM])*/
        _2 = (object)SEQ_PTR(_tok_56806);
        _28607 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_28607);
        _45emit_opnd(_28607);
        _28607 = NOVALUE;
        goto L5; // [631] 694

        /** parser.e:1343			case LEFT_ROUND then*/
        case -26:

        /** parser.e:1344				call_proc(forward_expr, {})*/
        _0 = (object)_00[_43forward_expr_55987].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1345				tok_match(RIGHT_ROUND)*/
        _43tok_match(-27, 0);
        goto L5; // [652] 694

        /** parser.e:1347			case FUNC, TYPE, QUALIFIED_FUNC, QUALIFIED_TYPE then*/
        case 501:
        case 504:
        case 520:
        case 522:

        /** parser.e:1348				Function_call( tok )*/
        Ref(_tok_56806);
        _43Function_call(_tok_56806);
        goto L5; // [669] 694

        /** parser.e:1350			case else*/
        default:

        /** parser.e:1351				CompileErr(SYNTAX_ERROR__EXPECTED_TO_SEE_AN_EXPRESSION_NOT_1, {LexName(id)})*/
        RefDS(_26351);
        _28608 = _45LexName(_id_56807, _26351);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _28608;
        _28609 = MAKE_SEQ(_1);
        _28608 = NOVALUE;
        _49CompileErr(135, _28609, 0);
        _28609 = NOVALUE;
    ;}L5: 

    /** parser.e:1353	end procedure*/
    DeRef(_tok_56806);
    DeRef(_28602);
    _28602 = NOVALUE;
    DeRef(_28564);
    _28564 = NOVALUE;
    return;
    ;
}


void _43UFactor()
{
    object _tok_56965 = NOVALUE;
    object _28615 = NOVALUE;
    object _28613 = NOVALUE;
    object _28611 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1359		tok = next_token()*/
    _0 = _tok_56965;
    _tok_56965 = _43next_token();
    DeRef(_0);

    /** parser.e:1361		if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_56965);
    _28611 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28611, 10)){
        _28611 = NOVALUE;
        goto L1; // [16] 34
    }
    _28611 = NOVALUE;

    /** parser.e:1362			Factor()*/
    _43Factor();

    /** parser.e:1363			emit_op(UMINUS)*/
    _45emit_op(12);
    goto L2; // [31] 93
L1: 

    /** parser.e:1365		elsif tok[T_ID] = NOT then*/
    _2 = (object)SEQ_PTR(_tok_56965);
    _28613 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28613, 7)){
        _28613 = NOVALUE;
        goto L3; // [44] 62
    }
    _28613 = NOVALUE;

    /** parser.e:1366			Factor()*/
    _43Factor();

    /** parser.e:1367			emit_op(NOT)*/
    _45emit_op(7);
    goto L2; // [59] 93
L3: 

    /** parser.e:1369		elsif tok[T_ID] = PLUS then*/
    _2 = (object)SEQ_PTR(_tok_56965);
    _28615 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28615, 11)){
        _28615 = NOVALUE;
        goto L4; // [72] 83
    }
    _28615 = NOVALUE;

    /** parser.e:1370			Factor()*/
    _43Factor();
    goto L2; // [80] 93
L4: 

    /** parser.e:1373			putback(tok)*/
    Ref(_tok_56965);
    _43putback(_tok_56965);

    /** parser.e:1374			Factor()*/
    _43Factor();
L2: 

    /** parser.e:1377	end procedure*/
    DeRef(_tok_56965);
    return;
    ;
}


object _43Term()
{
    object _tok_56990 = NOVALUE;
    object _28623 = NOVALUE;
    object _28622 = NOVALUE;
    object _28621 = NOVALUE;
    object _28619 = NOVALUE;
    object _28618 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1383		UFactor()*/
    _43UFactor();

    /** parser.e:1384		tok = next_token()*/
    _0 = _tok_56990;
    _tok_56990 = _43next_token();
    DeRef(_0);

    /** parser.e:1385		while tok[T_ID] = reserved:MULTIPLY or tok[T_ID] = reserved:DIVIDE do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_56990);
    _28618 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28618)) {
        _28619 = (_28618 == 13);
    }
    else {
        _28619 = binary_op(EQUALS, _28618, 13);
    }
    _28618 = NOVALUE;
    if (IS_ATOM_INT(_28619)) {
        if (_28619 != 0) {
            goto L2; // [25] 44
        }
    }
    else {
        if (DBL_PTR(_28619)->dbl != 0.0) {
            goto L2; // [25] 44
        }
    }
    _2 = (object)SEQ_PTR(_tok_56990);
    _28621 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28621)) {
        _28622 = (_28621 == 14);
    }
    else {
        _28622 = binary_op(EQUALS, _28621, 14);
    }
    _28621 = NOVALUE;
    if (_28622 <= 0) {
        if (_28622 == 0) {
            DeRef(_28622);
            _28622 = NOVALUE;
            goto L3; // [40] 69
        }
        else {
            if (!IS_ATOM_INT(_28622) && DBL_PTR(_28622)->dbl == 0.0){
                DeRef(_28622);
                _28622 = NOVALUE;
                goto L3; // [40] 69
            }
            DeRef(_28622);
            _28622 = NOVALUE;
        }
    }
    DeRef(_28622);
    _28622 = NOVALUE;
L2: 

    /** parser.e:1386			UFactor()*/
    _43UFactor();

    /** parser.e:1387			emit_op(tok[T_ID])*/
    _2 = (object)SEQ_PTR(_tok_56990);
    _28623 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_28623);
    _45emit_op(_28623);
    _28623 = NOVALUE;

    /** parser.e:1388			tok = next_token()*/
    _0 = _tok_56990;
    _tok_56990 = _43next_token();
    DeRef(_0);

    /** parser.e:1389		end while*/
    goto L1; // [66] 15
L3: 

    /** parser.e:1390		return tok*/
    DeRef(_28619);
    _28619 = NOVALUE;
    return _tok_56990;
    ;
}


object _43aexpr()
{
    object _tok_57007 = NOVALUE;
    object _id_57008 = NOVALUE;
    object _28630 = NOVALUE;
    object _28629 = NOVALUE;
    object _28627 = NOVALUE;
    object _28626 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1396		integer id*/

    /** parser.e:1398		tok = Term()*/
    _0 = _tok_57007;
    _tok_57007 = _43Term();
    DeRef(_0);

    /** parser.e:1399		while tok[T_ID] = PLUS or tok[T_ID] = MINUS do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57007);
    _28626 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28626)) {
        _28627 = (_28626 == 11);
    }
    else {
        _28627 = binary_op(EQUALS, _28626, 11);
    }
    _28626 = NOVALUE;
    if (IS_ATOM_INT(_28627)) {
        if (_28627 != 0) {
            goto L2; // [25] 46
        }
    }
    else {
        if (DBL_PTR(_28627)->dbl != 0.0) {
            goto L2; // [25] 46
        }
    }
    _2 = (object)SEQ_PTR(_tok_57007);
    _28629 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28629)) {
        _28630 = (_28629 == 10);
    }
    else {
        _28630 = binary_op(EQUALS, _28629, 10);
    }
    _28629 = NOVALUE;
    if (_28630 <= 0) {
        if (_28630 == 0) {
            DeRef(_28630);
            _28630 = NOVALUE;
            goto L3; // [42] 71
        }
        else {
            if (!IS_ATOM_INT(_28630) && DBL_PTR(_28630)->dbl == 0.0){
                DeRef(_28630);
                _28630 = NOVALUE;
                goto L3; // [42] 71
            }
            DeRef(_28630);
            _28630 = NOVALUE;
        }
    }
    DeRef(_28630);
    _28630 = NOVALUE;
L2: 

    /** parser.e:1400			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57007);
    _id_57008 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_57008)){
        _id_57008 = (object)DBL_PTR(_id_57008)->dbl;
    }

    /** parser.e:1401			tok = Term()*/
    _0 = _tok_57007;
    _tok_57007 = _43Term();
    DeRef(_0);

    /** parser.e:1402			emit_op(id)*/
    _45emit_op(_id_57008);

    /** parser.e:1403		end while*/
    goto L1; // [68] 13
L3: 

    /** parser.e:1404		return tok*/
    DeRef(_28627);
    _28627 = NOVALUE;
    return _tok_57007;
    ;
}


object _43cexpr()
{
    object _tok_57027 = NOVALUE;
    object _concat_count_57028 = NOVALUE;
    object _28634 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1410		integer concat_count*/

    /** parser.e:1412		tok = aexpr()*/
    _0 = _tok_57027;
    _tok_57027 = _43aexpr();
    DeRef(_0);

    /** parser.e:1413		concat_count = 0*/
    _concat_count_57028 = 0;

    /** parser.e:1414		while tok[T_ID] = reserved:CONCAT do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57027);
    _28634 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28634, 15)){
        _28634 = NOVALUE;
        goto L2; // [24] 44
    }
    _28634 = NOVALUE;

    /** parser.e:1415			tok = aexpr()*/
    _0 = _tok_57027;
    _tok_57027 = _43aexpr();
    DeRef(_0);

    /** parser.e:1416			concat_count += 1*/
    _concat_count_57028 = _concat_count_57028 + 1;

    /** parser.e:1417		end while*/
    goto L1; // [41] 18
L2: 

    /** parser.e:1419		if concat_count = 1 then*/
    if (_concat_count_57028 != 1)
    goto L3; // [46] 58

    /** parser.e:1420			emit_op( reserved:CONCAT )*/
    _45emit_op(15);
    goto L4; // [55] 81
L3: 

    /** parser.e:1422		elsif concat_count > 1 then*/
    if (_concat_count_57028 <= 1)
    goto L5; // [60] 80

    /** parser.e:1423			op_info1 = concat_count+1*/
    _45op_info1_50960 = _concat_count_57028 + 1;

    /** parser.e:1424			emit_op(CONCAT_N)*/
    _45emit_op(157);
L5: 
L4: 

    /** parser.e:1427		return tok*/
    return _tok_57027;
    ;
}


object _43rexpr()
{
    object _tok_57048 = NOVALUE;
    object _id_57049 = NOVALUE;
    object _28646 = NOVALUE;
    object _28645 = NOVALUE;
    object _28644 = NOVALUE;
    object _28643 = NOVALUE;
    object _28642 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1433		integer id*/

    /** parser.e:1435		tok = cexpr()*/
    _0 = _tok_57048;
    _tok_57048 = _43cexpr();
    DeRef(_0);

    /** parser.e:1436		while tok[T_ID] <= GREATER and tok[T_ID] >= LESS do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57048);
    _28642 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28642)) {
        _28643 = (_28642 <= 6);
    }
    else {
        _28643 = binary_op(LESSEQ, _28642, 6);
    }
    _28642 = NOVALUE;
    if (IS_ATOM_INT(_28643)) {
        if (_28643 == 0) {
            goto L2; // [25] 70
        }
    }
    else {
        if (DBL_PTR(_28643)->dbl == 0.0) {
            goto L2; // [25] 70
        }
    }
    _2 = (object)SEQ_PTR(_tok_57048);
    _28645 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28645)) {
        _28646 = (_28645 >= 1);
    }
    else {
        _28646 = binary_op(GREATEREQ, _28645, 1);
    }
    _28645 = NOVALUE;
    if (_28646 <= 0) {
        if (_28646 == 0) {
            DeRef(_28646);
            _28646 = NOVALUE;
            goto L2; // [42] 70
        }
        else {
            if (!IS_ATOM_INT(_28646) && DBL_PTR(_28646)->dbl == 0.0){
                DeRef(_28646);
                _28646 = NOVALUE;
                goto L2; // [42] 70
            }
            DeRef(_28646);
            _28646 = NOVALUE;
        }
    }
    DeRef(_28646);
    _28646 = NOVALUE;

    /** parser.e:1437			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57048);
    _id_57049 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_57049)){
        _id_57049 = (object)DBL_PTR(_id_57049)->dbl;
    }

    /** parser.e:1438			tok = cexpr()*/
    _0 = _tok_57048;
    _tok_57048 = _43cexpr();
    DeRef(_0);

    /** parser.e:1439			emit_op(id)*/
    _45emit_op(_id_57049);

    /** parser.e:1440		end while*/
    goto L1; // [67] 13
L2: 

    /** parser.e:1441		return tok*/
    DeRef(_28643);
    _28643 = NOVALUE;
    return _tok_57048;
    ;
}


void _43Expr()
{
    object _tok_57075 = NOVALUE;
    object _id_57076 = NOVALUE;
    object _patch_57077 = NOVALUE;
    object _28669 = NOVALUE;
    object _28667 = NOVALUE;
    object _28666 = NOVALUE;
    object _28664 = NOVALUE;
    object _28663 = NOVALUE;
    object _28662 = NOVALUE;
    object _28661 = NOVALUE;
    object _28660 = NOVALUE;
    object _28654 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1451		integer id*/

    /** parser.e:1452		integer patch*/

    /** parser.e:1454		ExprLine = ThisLine*/
    Ref(_49ThisLine_49261);
    DeRef(_43ExprLine_57070);
    _43ExprLine_57070 = _49ThisLine_49261;

    /** parser.e:1455		expr_bp = bp*/
    _43expr_bp_57071 = _49bp_49265;

    /** parser.e:1456		id = -1*/
    _id_57076 = -1;

    /** parser.e:1457		patch = 0*/
    _patch_57077 = 0;

    /** parser.e:1458		while TRUE do*/
L1: 
    if (_9TRUE_446 == 0)
    {
        goto L2; // [40] 300
    }
    else{
    }

    /** parser.e:1459			if id != -1 then*/
    if (_id_57076 == -1)
    goto L3; // [45] 116

    /** parser.e:1460				if id != XOR then*/
    if (_id_57076 == 152)
    goto L4; // [53] 115

    /** parser.e:1461					if short_circuit > 0 then*/
    if (_43short_circuit_54952 <= 0)
    goto L5; // [61] 114

    /** parser.e:1462						if id = OR then*/
    if (_id_57076 != 9)
    goto L6; // [69] 83

    /** parser.e:1463							emit_op(SC1_OR)*/
    _45emit_op(143);
    goto L7; // [80] 91
L6: 

    /** parser.e:1465							emit_op(SC1_AND)*/
    _45emit_op(141);
L7: 

    /** parser.e:1467						patch = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _28654 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _28654 = 1;
    }
    _patch_57077 = _28654 + 1;
    _28654 = NOVALUE;

    /** parser.e:1468						emit_forward_addr()*/
    _43emit_forward_addr();

    /** parser.e:1469						short_circuit_B = TRUE*/
    _43short_circuit_B_54954 = _9TRUE_446;
L5: 
L4: 
L3: 

    /** parser.e:1474			tok = rexpr()*/
    _0 = _tok_57075;
    _tok_57075 = _43rexpr();
    DeRef(_0);

    /** parser.e:1476			if id != -1 then*/
    if (_id_57076 == -1)
    goto L8; // [123] 268

    /** parser.e:1477				if id != XOR then*/
    if (_id_57076 == 152)
    goto L9; // [131] 261

    /** parser.e:1478					if short_circuit > 0 then*/
    if (_43short_circuit_54952 <= 0)
    goto LA; // [139] 252

    /** parser.e:1479						if tok[T_ID] != THEN and tok[T_ID] != DO then*/
    _2 = (object)SEQ_PTR(_tok_57075);
    _28660 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28660)) {
        _28661 = (_28660 != 410);
    }
    else {
        _28661 = binary_op(NOTEQ, _28660, 410);
    }
    _28660 = NOVALUE;
    if (IS_ATOM_INT(_28661)) {
        if (_28661 == 0) {
            goto LB; // [157] 206
        }
    }
    else {
        if (DBL_PTR(_28661)->dbl == 0.0) {
            goto LB; // [157] 206
        }
    }
    _2 = (object)SEQ_PTR(_tok_57075);
    _28663 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28663)) {
        _28664 = (_28663 != 411);
    }
    else {
        _28664 = binary_op(NOTEQ, _28663, 411);
    }
    _28663 = NOVALUE;
    if (_28664 == 0) {
        DeRef(_28664);
        _28664 = NOVALUE;
        goto LB; // [174] 206
    }
    else {
        if (!IS_ATOM_INT(_28664) && DBL_PTR(_28664)->dbl == 0.0){
            DeRef(_28664);
            _28664 = NOVALUE;
            goto LB; // [174] 206
        }
        DeRef(_28664);
        _28664 = NOVALUE;
    }
    DeRef(_28664);
    _28664 = NOVALUE;

    /** parser.e:1480							if id = OR then*/
    if (_id_57076 != 9)
    goto LC; // [181] 195

    /** parser.e:1481								emit_op(SC2_OR)*/
    _45emit_op(144);
    goto LD; // [192] 219
LC: 

    /** parser.e:1483								emit_op(SC2_AND)*/
    _45emit_op(142);
    goto LD; // [203] 219
LB: 

    /** parser.e:1486							SC1_type = id -- if/while/elsif must patch*/
    _43SC1_type_54957 = _id_57076;

    /** parser.e:1487							emit_op(SC2_NULL)*/
    _45emit_op(145);
LD: 

    /** parser.e:1489						if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto LE; // [223] 234
    }
    else{
    }

    /** parser.e:1490							emit_op(NOP1)   -- to get label here*/
    _45emit_op(159);
LE: 

    /** parser.e:1492						backpatch(patch, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _28666 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _28666 = 1;
    }
    _28667 = _28666 + 1;
    _28666 = NOVALUE;
    _45backpatch(_patch_57077, _28667);
    _28667 = NOVALUE;
    goto LF; // [249] 267
LA: 

    /** parser.e:1494						emit_op(id)*/
    _45emit_op(_id_57076);
    goto LF; // [258] 267
L9: 

    /** parser.e:1497					emit_op(id)*/
    _45emit_op(_id_57076);
LF: 
L8: 

    /** parser.e:1500			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57075);
    _id_57076 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_57076)){
        _id_57076 = (object)DBL_PTR(_id_57076)->dbl;
    }

    /** parser.e:1501			if not find(id, boolOps) then*/
    _28669 = find_from(_id_57076, _43boolOps_57065, 1);
    if (_28669 != 0)
    goto L1; // [287] 38
    _28669 = NOVALUE;

    /** parser.e:1502				exit*/
    goto L2; // [292] 300

    /** parser.e:1504		end while*/
    goto L1; // [297] 38
L2: 

    /** parser.e:1505		putback(tok)*/
    Ref(_tok_57075);
    _43putback(_tok_57075);

    /** parser.e:1506		SC1_patch = patch -- extra line*/
    _43SC1_patch_54956 = _patch_57077;

    /** parser.e:1507	end procedure*/
    DeRef(_tok_57075);
    DeRef(_28661);
    _28661 = NOVALUE;
    return;
    ;
}


void _43TypeCheck(object _var_57152)
{
    object _which_type_57153 = NOVALUE;
    object _ref_57163 = NOVALUE;
    object _ref_57196 = NOVALUE;
    object _28725 = NOVALUE;
    object _28724 = NOVALUE;
    object _28723 = NOVALUE;
    object _28722 = NOVALUE;
    object _28721 = NOVALUE;
    object _28719 = NOVALUE;
    object _28718 = NOVALUE;
    object _28717 = NOVALUE;
    object _28716 = NOVALUE;
    object _28715 = NOVALUE;
    object _28714 = NOVALUE;
    object _28712 = NOVALUE;
    object _28711 = NOVALUE;
    object _28708 = NOVALUE;
    object _28707 = NOVALUE;
    object _28706 = NOVALUE;
    object _28705 = NOVALUE;
    object _28700 = NOVALUE;
    object _28699 = NOVALUE;
    object _28695 = NOVALUE;
    object _28693 = NOVALUE;
    object _28692 = NOVALUE;
    object _28691 = NOVALUE;
    object _28689 = NOVALUE;
    object _28688 = NOVALUE;
    object _28687 = NOVALUE;
    object _28686 = NOVALUE;
    object _28685 = NOVALUE;
    object _28684 = NOVALUE;
    object _28681 = NOVALUE;
    object _28679 = NOVALUE;
    object _28677 = NOVALUE;
    object _28676 = NOVALUE;
    object _28675 = NOVALUE;
    object _28673 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_var_57152)) {
        _1 = (object)(DBL_PTR(_var_57152)->dbl);
        DeRefDS(_var_57152);
        _var_57152 = _1;
    }

    /** parser.e:1515		if var < 0 or SymTab[var][S_SCOPE] = SC_UNDEFINED then*/
    _28673 = (_var_57152 < 0);
    if (_28673 != 0) {
        goto L1; // [9] 36
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28675 = (object)*(((s1_ptr)_2)->base + _var_57152);
    _2 = (object)SEQ_PTR(_28675);
    _28676 = (object)*(((s1_ptr)_2)->base + 4);
    _28675 = NOVALUE;
    if (IS_ATOM_INT(_28676)) {
        _28677 = (_28676 == 9);
    }
    else {
        _28677 = binary_op(EQUALS, _28676, 9);
    }
    _28676 = NOVALUE;
    if (_28677 == 0) {
        DeRef(_28677);
        _28677 = NOVALUE;
        goto L2; // [32] 76
    }
    else {
        if (!IS_ATOM_INT(_28677) && DBL_PTR(_28677)->dbl == 0.0){
            DeRef(_28677);
            _28677 = NOVALUE;
            goto L2; // [32] 76
        }
        DeRef(_28677);
        _28677 = NOVALUE;
    }
    DeRef(_28677);
    _28677 = NOVALUE;
L1: 

    /** parser.e:1517			integer ref = new_forward_reference( TYPE_CHECK, var, TYPE_CHECK_FORWARD )*/
    _ref_57163 = _42new_forward_reference(65, _var_57152, 197);
    if (!IS_ATOM_INT(_ref_57163)) {
        _1 = (object)(DBL_PTR(_ref_57163)->dbl);
        DeRefDS(_ref_57163);
        _ref_57163 = _1;
    }

    /** parser.e:1518			Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 197;
    ((intptr_t*)_2)[2] = _var_57152;
    ((intptr_t*)_2)[3] = _12OpTypeCheck_20297;
    _28679 = MAKE_SEQ(_1);
    Concat((object_ptr)&_12Code_20315, _12Code_20315, _28679);
    DeRefDS(_28679);
    _28679 = NOVALUE;

    /** parser.e:1519			return*/
    DeRef(_28673);
    _28673 = NOVALUE;
    return;
L2: 

    /** parser.e:1522		which_type = SymTab[var][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28681 = (object)*(((s1_ptr)_2)->base + _var_57152);
    _2 = (object)SEQ_PTR(_28681);
    _which_type_57153 = (object)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_which_type_57153)){
        _which_type_57153 = (object)DBL_PTR(_which_type_57153)->dbl;
    }
    _28681 = NOVALUE;

    /** parser.e:1523		if which_type = 0 then*/
    if (_which_type_57153 != 0)
    goto L3; // [96] 106

    /** parser.e:1524			return	-- Not a typed identifier.*/
    DeRef(_28673);
    _28673 = NOVALUE;
    return;
L3: 

    /** parser.e:1526		if which_type > 0 and length(SymTab[which_type]) < S_TOKEN then*/
    _28684 = (_which_type_57153 > 0);
    if (_28684 == 0) {
        goto L4; // [112] 141
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28686 = (object)*(((s1_ptr)_2)->base + _which_type_57153);
    if (IS_SEQUENCE(_28686)){
            _28687 = SEQ_PTR(_28686)->length;
    }
    else {
        _28687 = 1;
    }
    _28686 = NOVALUE;
    if (IS_ATOM_INT(_12S_TOKEN_19869)) {
        _28688 = (_28687 < _12S_TOKEN_19869);
    }
    else {
        _28688 = binary_op(LESS, _28687, _12S_TOKEN_19869);
    }
    _28687 = NOVALUE;
    if (_28688 == 0) {
        DeRef(_28688);
        _28688 = NOVALUE;
        goto L4; // [132] 141
    }
    else {
        if (!IS_ATOM_INT(_28688) && DBL_PTR(_28688)->dbl == 0.0){
            DeRef(_28688);
            _28688 = NOVALUE;
            goto L4; // [132] 141
        }
        DeRef(_28688);
        _28688 = NOVALUE;
    }
    DeRef(_28688);
    _28688 = NOVALUE;

    /** parser.e:1527			return	-- Not a typed identifier.*/
    _28686 = NOVALUE;
    DeRef(_28673);
    _28673 = NOVALUE;
    DeRef(_28684);
    _28684 = NOVALUE;
    return;
L4: 

    /** parser.e:1530		if which_type < 0 or SymTab[which_type][S_TOKEN] = VARIABLE  then*/
    _28689 = (_which_type_57153 < 0);
    if (_28689 != 0) {
        goto L5; // [147] 174
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28691 = (object)*(((s1_ptr)_2)->base + _which_type_57153);
    _2 = (object)SEQ_PTR(_28691);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _28692 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _28692 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _28691 = NOVALUE;
    if (IS_ATOM_INT(_28692)) {
        _28693 = (_28692 == -100);
    }
    else {
        _28693 = binary_op(EQUALS, _28692, -100);
    }
    _28692 = NOVALUE;
    if (_28693 == 0) {
        DeRef(_28693);
        _28693 = NOVALUE;
        goto L6; // [170] 214
    }
    else {
        if (!IS_ATOM_INT(_28693) && DBL_PTR(_28693)->dbl == 0.0){
            DeRef(_28693);
            _28693 = NOVALUE;
            goto L6; // [170] 214
        }
        DeRef(_28693);
        _28693 = NOVALUE;
    }
    DeRef(_28693);
    _28693 = NOVALUE;
L5: 

    /** parser.e:1531			integer ref = new_forward_reference( TYPE_CHECK, which_type, TYPE )*/
    _ref_57196 = _42new_forward_reference(65, _which_type_57153, 504);
    if (!IS_ATOM_INT(_ref_57196)) {
        _1 = (object)(DBL_PTR(_ref_57196)->dbl);
        DeRefDS(_ref_57196);
        _ref_57196 = _1;
    }

    /** parser.e:1532			Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 197;
    ((intptr_t*)_2)[2] = _var_57152;
    ((intptr_t*)_2)[3] = _12OpTypeCheck_20297;
    _28695 = MAKE_SEQ(_1);
    Concat((object_ptr)&_12Code_20315, _12Code_20315, _28695);
    DeRefDS(_28695);
    _28695 = NOVALUE;

    /** parser.e:1534			return*/
    _28686 = NOVALUE;
    DeRef(_28673);
    _28673 = NOVALUE;
    DeRef(_28684);
    _28684 = NOVALUE;
    DeRef(_28689);
    _28689 = NOVALUE;
    return;
L6: 

    /** parser.e:1537		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L7; // [220] 317
    }
    else{
    }

    /** parser.e:1538			if OpTypeCheck then*/
    if (_12OpTypeCheck_20297 == 0)
    {
        goto L8; // [227] 481
    }
    else{
    }

    /** parser.e:1539				switch which_type do*/
    if( _43_57210_cases == 0 ){
        _43_57210_cases = 1;
        SEQ_PTR( _28697 )->base[1] = _53object_type_46803;
        SEQ_PTR( _28697 )->base[2] = _53sequence_type_46807;
        SEQ_PTR( _28697 )->base[3] = _53atom_type_46805;
        SEQ_PTR( _28697 )->base[4] = _53integer_type_46809;
    }
    _1 = find(_which_type_57153, _28697);
    switch ( _1 ){ 

        /** parser.e:1540					case object_type, sequence_type, atom_type then*/
        case 1:
        case 2:
        case 3:

        /** parser.e:1542					case integer_type then*/
        goto L8; // [247] 481
        case 4:

        /** parser.e:1544						op_info1 = var*/
        _45op_info1_50960 = _var_57152;

        /** parser.e:1545						emit_op(INTEGER_CHECK)*/
        _45emit_op(96);
        goto L8; // [265] 481

        /** parser.e:1546					case else*/
        case 0:

        /** parser.e:1547						if SymTab[which_type][S_EFFECT] then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28699 = (object)*(((s1_ptr)_2)->base + _which_type_57153);
        _2 = (object)SEQ_PTR(_28699);
        _28700 = (object)*(((s1_ptr)_2)->base + 23);
        _28699 = NOVALUE;
        if (_28700 == 0) {
            _28700 = NOVALUE;
            goto L9; // [285] 312
        }
        else {
            if (!IS_ATOM_INT(_28700) && DBL_PTR(_28700)->dbl == 0.0){
                _28700 = NOVALUE;
                goto L9; // [285] 312
            }
            _28700 = NOVALUE;
        }
        _28700 = NOVALUE;

        /** parser.e:1549							emit_opnd(var)*/
        _45emit_opnd(_var_57152);

        /** parser.e:1550							op_info1 = which_type*/
        _45op_info1_50960 = _which_type_57153;

        /** parser.e:1552							emit_or_inline()*/
        _66emit_or_inline();

        /** parser.e:1553							emit_op(TYPE_CHECK)*/
        _45emit_op(65);
L9: 
    ;}    goto L8; // [314] 481
L7: 

    /** parser.e:1559			if OpTypeCheck then*/
    if (_12OpTypeCheck_20297 == 0)
    {
        goto LA; // [321] 480
    }
    else{
    }

    /** parser.e:1560				if which_type != object_type then*/
    if (_which_type_57153 == _53object_type_46803)
    goto LB; // [328] 479

    /** parser.e:1561					if which_type = integer_type then*/
    if (_which_type_57153 != _53integer_type_46809)
    goto LC; // [336] 357

    /** parser.e:1562							op_info1 = var*/
    _45op_info1_50960 = _var_57152;

    /** parser.e:1563							emit_op(INTEGER_CHECK)*/
    _45emit_op(96);
    goto LD; // [354] 478
LC: 

    /** parser.e:1565					elsif which_type = sequence_type then*/
    if (_which_type_57153 != _53sequence_type_46807)
    goto LE; // [361] 382

    /** parser.e:1566							op_info1 = var*/
    _45op_info1_50960 = _var_57152;

    /** parser.e:1567							emit_op(SEQUENCE_CHECK)*/
    _45emit_op(97);
    goto LD; // [379] 478
LE: 

    /** parser.e:1569					elsif which_type = atom_type then*/
    if (_which_type_57153 != _53atom_type_46805)
    goto LF; // [386] 407

    /** parser.e:1570							op_info1 = var*/
    _45op_info1_50960 = _var_57152;

    /** parser.e:1571							emit_op(ATOM_CHECK)*/
    _45emit_op(101);
    goto LD; // [404] 478
LF: 

    /** parser.e:1575							if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] =*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28705 = (object)*(((s1_ptr)_2)->base + _which_type_57153);
    _2 = (object)SEQ_PTR(_28705);
    _28706 = (object)*(((s1_ptr)_2)->base + 2);
    _28705 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28706)){
        _28707 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28706)->dbl));
    }
    else{
        _28707 = (object)*(((s1_ptr)_2)->base + _28706);
    }
    _2 = (object)SEQ_PTR(_28707);
    _28708 = (object)*(((s1_ptr)_2)->base + 15);
    _28707 = NOVALUE;
    if (binary_op_a(NOTEQ, _28708, _53integer_type_46809)){
        _28708 = NOVALUE;
        goto L10; // [435] 454
    }
    _28708 = NOVALUE;

    /** parser.e:1577								op_info1 = var*/
    _45op_info1_50960 = _var_57152;

    /** parser.e:1578								emit_op(INTEGER_CHECK) -- need integer conversion*/
    _45emit_op(96);
L10: 

    /** parser.e:1580							emit_opnd(var)*/
    _45emit_opnd(_var_57152);

    /** parser.e:1581							op_info1 = which_type*/
    _45op_info1_50960 = _which_type_57153;

    /** parser.e:1582							emit_or_inline()*/
    _66emit_or_inline();

    /** parser.e:1584							emit_op(TYPE_CHECK)*/
    _45emit_op(65);
LD: 
LB: 
LA: 
L8: 

    /** parser.e:1590		if TRANSLATE or not OpTypeCheck then*/
    if (_12TRANSLATE_19834 != 0) {
        goto L11; // [485] 499
    }
    _28711 = (_12OpTypeCheck_20297 == 0);
    if (_28711 == 0)
    {
        DeRef(_28711);
        _28711 = NOVALUE;
        goto L12; // [495] 620
    }
    else{
        DeRef(_28711);
        _28711 = NOVALUE;
    }
L11: 

    /** parser.e:1591			op_info1 = var*/
    _45op_info1_50960 = _var_57152;

    /** parser.e:1592			if which_type = sequence_type or*/
    _28712 = (_which_type_57153 == _53sequence_type_46807);
    if (_28712 != 0) {
        goto L13; // [514] 553
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28714 = (object)*(((s1_ptr)_2)->base + _which_type_57153);
    _2 = (object)SEQ_PTR(_28714);
    _28715 = (object)*(((s1_ptr)_2)->base + 2);
    _28714 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28715)){
        _28716 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28715)->dbl));
    }
    else{
        _28716 = (object)*(((s1_ptr)_2)->base + _28715);
    }
    _2 = (object)SEQ_PTR(_28716);
    _28717 = (object)*(((s1_ptr)_2)->base + 15);
    _28716 = NOVALUE;
    if (IS_ATOM_INT(_28717)) {
        _28718 = (_28717 == _53sequence_type_46807);
    }
    else {
        _28718 = binary_op(EQUALS, _28717, _53sequence_type_46807);
    }
    _28717 = NOVALUE;
    if (_28718 == 0) {
        DeRef(_28718);
        _28718 = NOVALUE;
        goto L14; // [549] 563
    }
    else {
        if (!IS_ATOM_INT(_28718) && DBL_PTR(_28718)->dbl == 0.0){
            DeRef(_28718);
            _28718 = NOVALUE;
            goto L14; // [549] 563
        }
        DeRef(_28718);
        _28718 = NOVALUE;
    }
    DeRef(_28718);
    _28718 = NOVALUE;
L13: 

    /** parser.e:1595				emit_op(SEQUENCE_CHECK)*/
    _45emit_op(97);
    goto L15; // [560] 619
L14: 

    /** parser.e:1597			elsif which_type = integer_type or*/
    _28719 = (_which_type_57153 == _53integer_type_46809);
    if (_28719 != 0) {
        goto L16; // [571] 610
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28721 = (object)*(((s1_ptr)_2)->base + _which_type_57153);
    _2 = (object)SEQ_PTR(_28721);
    _28722 = (object)*(((s1_ptr)_2)->base + 2);
    _28721 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28722)){
        _28723 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28722)->dbl));
    }
    else{
        _28723 = (object)*(((s1_ptr)_2)->base + _28722);
    }
    _2 = (object)SEQ_PTR(_28723);
    _28724 = (object)*(((s1_ptr)_2)->base + 15);
    _28723 = NOVALUE;
    if (IS_ATOM_INT(_28724)) {
        _28725 = (_28724 == _53integer_type_46809);
    }
    else {
        _28725 = binary_op(EQUALS, _28724, _53integer_type_46809);
    }
    _28724 = NOVALUE;
    if (_28725 == 0) {
        DeRef(_28725);
        _28725 = NOVALUE;
        goto L17; // [606] 618
    }
    else {
        if (!IS_ATOM_INT(_28725) && DBL_PTR(_28725)->dbl == 0.0){
            DeRef(_28725);
            _28725 = NOVALUE;
            goto L17; // [606] 618
        }
        DeRef(_28725);
        _28725 = NOVALUE;
    }
    DeRef(_28725);
    _28725 = NOVALUE;
L16: 

    /** parser.e:1600				emit_op(INTEGER_CHECK)*/
    _45emit_op(96);
L17: 
L15: 
L12: 

    /** parser.e:1603	end procedure*/
    _28706 = NOVALUE;
    _28686 = NOVALUE;
    DeRef(_28673);
    _28673 = NOVALUE;
    DeRef(_28684);
    _28684 = NOVALUE;
    _28715 = NOVALUE;
    DeRef(_28689);
    _28689 = NOVALUE;
    DeRef(_28712);
    _28712 = NOVALUE;
    DeRef(_28719);
    _28719 = NOVALUE;
    _28722 = NOVALUE;
    return;
    ;
}


void _43Assignment(object _left_var_57317)
{
    object _tok_57319 = NOVALUE;
    object _subs_57320 = NOVALUE;
    object _slice_57321 = NOVALUE;
    object _assign_op_57322 = NOVALUE;
    object _subs1_patch_57323 = NOVALUE;
    object _dangerous_57325 = NOVALUE;
    object _lname_57450 = NOVALUE;
    object _temp_len_57469 = NOVALUE;
    object _28822 = NOVALUE;
    object _28821 = NOVALUE;
    object _28820 = NOVALUE;
    object _28819 = NOVALUE;
    object _28818 = NOVALUE;
    object _28817 = NOVALUE;
    object _28816 = NOVALUE;
    object _28807 = NOVALUE;
    object _28806 = NOVALUE;
    object _28805 = NOVALUE;
    object _28804 = NOVALUE;
    object _28803 = NOVALUE;
    object _28802 = NOVALUE;
    object _28801 = NOVALUE;
    object _28800 = NOVALUE;
    object _28799 = NOVALUE;
    object _28798 = NOVALUE;
    object _28797 = NOVALUE;
    object _28796 = NOVALUE;
    object _28795 = NOVALUE;
    object _28794 = NOVALUE;
    object _28793 = NOVALUE;
    object _28791 = NOVALUE;
    object _28790 = NOVALUE;
    object _28789 = NOVALUE;
    object _28787 = NOVALUE;
    object _28782 = NOVALUE;
    object _28781 = NOVALUE;
    object _28778 = NOVALUE;
    object _28777 = NOVALUE;
    object _28775 = NOVALUE;
    object _28769 = NOVALUE;
    object _28764 = NOVALUE;
    object _28761 = NOVALUE;
    object _28758 = NOVALUE;
    object _28755 = NOVALUE;
    object _28754 = NOVALUE;
    object _28753 = NOVALUE;
    object _28751 = NOVALUE;
    object _28750 = NOVALUE;
    object _28749 = NOVALUE;
    object _28748 = NOVALUE;
    object _28747 = NOVALUE;
    object _28746 = NOVALUE;
    object _28744 = NOVALUE;
    object _28743 = NOVALUE;
    object _28742 = NOVALUE;
    object _28741 = NOVALUE;
    object _28739 = NOVALUE;
    object _28738 = NOVALUE;
    object _28737 = NOVALUE;
    object _28736 = NOVALUE;
    object _28735 = NOVALUE;
    object _28733 = NOVALUE;
    object _28732 = NOVALUE;
    object _28731 = NOVALUE;
    object _28728 = NOVALUE;
    object _28727 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1608		integer subs, slice, assign_op, subs1_patch*/

    /** parser.e:1611		left_sym = left_var[T_SYM]*/
    _2 = (object)SEQ_PTR(_left_var_57317);
    _43left_sym_54993 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_43left_sym_54993)){
        _43left_sym_54993 = (object)DBL_PTR(_43left_sym_54993)->dbl;
    }

    /** parser.e:1612		if SymTab[left_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28727 = (object)*(((s1_ptr)_2)->base + _43left_sym_54993);
    _2 = (object)SEQ_PTR(_28727);
    _28728 = (object)*(((s1_ptr)_2)->base + 4);
    _28727 = NOVALUE;
    if (binary_op_a(NOTEQ, _28728, 9)){
        _28728 = NOVALUE;
        goto L1; // [31] 54
    }
    _28728 = NOVALUE;

    /** parser.e:1613			Forward_var( left_var, ,ASSIGN )*/
    Ref(_left_var_57317);
    _43Forward_var(_left_var_57317, -1, 18);

    /** parser.e:1614			left_sym = Pop() -- pops off what forward var emitted, because it gets emitted later*/
    _0 = _45Pop();
    _43left_sym_54993 = _0;
    if (!IS_ATOM_INT(_43left_sym_54993)) {
        _1 = (object)(DBL_PTR(_43left_sym_54993)->dbl);
        DeRefDS(_43left_sym_54993);
        _43left_sym_54993 = _1;
    }
    goto L2; // [51] 271
L1: 

    /** parser.e:1616			UndefinedVar(left_sym)*/
    _43UndefinedVar(_43left_sym_54993);

    /** parser.e:1617			if SymTab[left_sym][S_SCOPE] = SC_LOOP_VAR or*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28731 = (object)*(((s1_ptr)_2)->base + _43left_sym_54993);
    _2 = (object)SEQ_PTR(_28731);
    _28732 = (object)*(((s1_ptr)_2)->base + 4);
    _28731 = NOVALUE;
    if (IS_ATOM_INT(_28732)) {
        _28733 = (_28732 == 2);
    }
    else {
        _28733 = binary_op(EQUALS, _28732, 2);
    }
    _28732 = NOVALUE;
    if (IS_ATOM_INT(_28733)) {
        if (_28733 != 0) {
            goto L3; // [83] 112
        }
    }
    else {
        if (DBL_PTR(_28733)->dbl != 0.0) {
            goto L3; // [83] 112
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28735 = (object)*(((s1_ptr)_2)->base + _43left_sym_54993);
    _2 = (object)SEQ_PTR(_28735);
    _28736 = (object)*(((s1_ptr)_2)->base + 4);
    _28735 = NOVALUE;
    if (IS_ATOM_INT(_28736)) {
        _28737 = (_28736 == 4);
    }
    else {
        _28737 = binary_op(EQUALS, _28736, 4);
    }
    _28736 = NOVALUE;
    if (_28737 == 0) {
        DeRef(_28737);
        _28737 = NOVALUE;
        goto L4; // [108] 124
    }
    else {
        if (!IS_ATOM_INT(_28737) && DBL_PTR(_28737)->dbl == 0.0){
            DeRef(_28737);
            _28737 = NOVALUE;
            goto L4; // [108] 124
        }
        DeRef(_28737);
        _28737 = NOVALUE;
    }
    DeRef(_28737);
    _28737 = NOVALUE;
L3: 

    /** parser.e:1619				CompileErr(MAY_NOT_ASSIGN_TO_A_FORLOOP_VARIABLE)*/
    RefDS(_22015);
    _49CompileErr(109, _22015, 0);
    goto L5; // [121] 233
L4: 

    /** parser.e:1621			elsif SymTab[left_sym][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28738 = (object)*(((s1_ptr)_2)->base + _43left_sym_54993);
    _2 = (object)SEQ_PTR(_28738);
    _28739 = (object)*(((s1_ptr)_2)->base + 3);
    _28738 = NOVALUE;
    if (binary_op_a(NOTEQ, _28739, 2)){
        _28739 = NOVALUE;
        goto L6; // [142] 158
    }
    _28739 = NOVALUE;

    /** parser.e:1622				CompileErr(MAY_NOT_CHANGE_THE_VALUE_OF_A_CONSTANT)*/
    RefDS(_22015);
    _49CompileErr(110, _22015, 0);
    goto L5; // [155] 233
L6: 

    /** parser.e:1624			elsif find(SymTab[left_sym][S_SCOPE], SCOPE_TYPES) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28741 = (object)*(((s1_ptr)_2)->base + _43left_sym_54993);
    _2 = (object)SEQ_PTR(_28741);
    _28742 = (object)*(((s1_ptr)_2)->base + 4);
    _28741 = NOVALUE;
    _28743 = find_from(_28742, _43SCOPE_TYPES_54943, 1);
    _28742 = NOVALUE;
    if (_28743 == 0)
    {
        _28743 = NOVALUE;
        goto L7; // [181] 232
    }
    else{
        _28743 = NOVALUE;
    }

    /** parser.e:1626				SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28746 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_28746);
    _28747 = (object)*(((s1_ptr)_2)->base + 23);
    _28746 = NOVALUE;
    _28748 = (_43left_sym_54993 % 29);
    _28749 = power(2, _28748);
    _28748 = NOVALUE;
    if (IS_ATOM_INT(_28747) && IS_ATOM_INT(_28749)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28747 | (uintptr_t)_28749;
             _28750 = MAKE_UINT(tu);
        }
    }
    else {
        _28750 = binary_op(OR_BITS, _28747, _28749);
    }
    _28747 = NOVALUE;
    DeRef(_28749);
    _28749 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28750;
    if( _1 != _28750 ){
        DeRef(_1);
    }
    _28750 = NOVALUE;
    _28744 = NOVALUE;
L7: 
L5: 

    /** parser.e:1630			SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_WRITTEN)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_43left_sym_54993 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28753 = (object)*(((s1_ptr)_2)->base + _43left_sym_54993);
    _2 = (object)SEQ_PTR(_28753);
    _28754 = (object)*(((s1_ptr)_2)->base + 5);
    _28753 = NOVALUE;
    if (IS_ATOM_INT(_28754)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28754 | (uintptr_t)2;
             _28755 = MAKE_UINT(tu);
        }
    }
    else {
        _28755 = binary_op(OR_BITS, _28754, 2);
    }
    _28754 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28755;
    if( _1 != _28755 ){
        DeRef(_1);
    }
    _28755 = NOVALUE;
    _28751 = NOVALUE;
L2: 

    /** parser.e:1635		tok = next_token()*/
    _0 = _tok_57319;
    _tok_57319 = _43next_token();
    DeRef(_0);

    /** parser.e:1636		subs = 0*/
    _subs_57320 = 0;

    /** parser.e:1637		slice = FALSE*/
    _slice_57321 = _9FALSE_444;

    /** parser.e:1639		dangerous = FALSE*/
    _dangerous_57325 = _9FALSE_444;

    /** parser.e:1640		side_effect_calls = 0*/
    _43side_effect_calls_54989 = 0;

    /** parser.e:1643		emit_opnd(left_sym)*/
    _45emit_opnd(_43left_sym_54993);

    /** parser.e:1644		current_sequence = append(current_sequence, left_sym)*/
    Append(&_45current_sequence_50968, _45current_sequence_50968, _43left_sym_54993);

    /** parser.e:1646		while tok[T_ID] = LEFT_SQUARE do*/
L8: 
    _2 = (object)SEQ_PTR(_tok_57319);
    _28758 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28758, -28)){
        _28758 = NOVALUE;
        goto L9; // [334] 523
    }
    _28758 = NOVALUE;

    /** parser.e:1647			subs_depth += 1*/
    _43subs_depth_54994 = _43subs_depth_54994 + 1;

    /** parser.e:1648			if lhs_ptr then*/
    if (_45lhs_ptr_50970 == 0)
    {
        goto LA; // [350] 405
    }
    else{
    }

    /** parser.e:1650				current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_45current_sequence_50968)){
            _28761 = SEQ_PTR(_45current_sequence_50968)->length;
    }
    else {
        _28761 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45current_sequence_50968);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28761)) ? _28761 : (object)(DBL_PTR(_28761)->dbl);
        int stop = (IS_ATOM_INT(_28761)) ? _28761 : (object)(DBL_PTR(_28761)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45current_sequence_50968), start, &_45current_sequence_50968 );
            }
            else Tail(SEQ_PTR(_45current_sequence_50968), stop+1, &_45current_sequence_50968);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45current_sequence_50968), start, &_45current_sequence_50968);
        }
        else {
            assign_slice_seq = &assign_space;
            _45current_sequence_50968 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_50968)->ref == 1));
        }
    }
    _28761 = NOVALUE;
    _28761 = NOVALUE;

    /** parser.e:1651				if subs = 1 then*/
    if (_subs_57320 != 1)
    goto LB; // [371] 396

    /** parser.e:1653					subs1_patch = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _28764 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _28764 = 1;
    }
    _subs1_patch_57323 = _28764 + 1;
    _28764 = NOVALUE;

    /** parser.e:1654					emit_op(LHS_SUBS1) -- creates new current_sequence*/
    _45emit_op(161);
    goto LC; // [393] 404
LB: 

    /** parser.e:1657					emit_op(LHS_SUBS) -- adds to current_sequence*/
    _45emit_op(95);
LC: 
LA: 

    /** parser.e:1660			subs += 1*/
    _subs_57320 = _subs_57320 + 1;

    /** parser.e:1661			if subs = 1 then*/
    if (_subs_57320 != 1)
    goto LD; // [413] 428

    /** parser.e:1662				InitCheck(left_sym, TRUE)*/
    _43InitCheck(_43left_sym_54993, _9TRUE_446);
LD: 

    /** parser.e:1664			Expr()*/
    _43Expr();

    /** parser.e:1665			tok = next_token()*/
    _0 = _tok_57319;
    _tok_57319 = _43next_token();
    DeRef(_0);

    /** parser.e:1666			if tok[T_ID] = SLICE then*/
    _2 = (object)SEQ_PTR(_tok_57319);
    _28769 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28769, 513)){
        _28769 = NOVALUE;
        goto LE; // [447] 484
    }
    _28769 = NOVALUE;

    /** parser.e:1667				Expr()*/
    _43Expr();

    /** parser.e:1668				slice = TRUE*/
    _slice_57321 = _9TRUE_446;

    /** parser.e:1669				tok_match(RIGHT_SQUARE)*/
    _43tok_match(-29, 0);

    /** parser.e:1670				tok = next_token()*/
    _0 = _tok_57319;
    _tok_57319 = _43next_token();
    DeRef(_0);

    /** parser.e:1671				exit  -- no further subs or slices allowed*/
    goto L9; // [479] 523
    goto LF; // [481] 506
LE: 

    /** parser.e:1673				putback(tok)*/
    Ref(_tok_57319);
    _43putback(_tok_57319);

    /** parser.e:1674				tok_match(RIGHT_SQUARE)*/
    _43tok_match(-29, 0);

    /** parser.e:1675				subs_depth -= 1*/
    _43subs_depth_54994 = _43subs_depth_54994 - 1;
LF: 

    /** parser.e:1677			tok = next_token()*/
    _0 = _tok_57319;
    _tok_57319 = _43next_token();
    DeRef(_0);

    /** parser.e:1678			lhs_ptr = TRUE*/
    _45lhs_ptr_50970 = _9TRUE_446;

    /** parser.e:1679		end while*/
    goto L8; // [520] 326
L9: 

    /** parser.e:1681		lhs_ptr = FALSE*/
    _45lhs_ptr_50970 = _9FALSE_444;

    /** parser.e:1683		assign_op = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57319);
    _assign_op_57322 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_assign_op_57322)){
        _assign_op_57322 = (object)DBL_PTR(_assign_op_57322)->dbl;
    }

    /** parser.e:1684		if not find(assign_op, ASSIGN_OPS) then*/
    _28775 = find_from(_assign_op_57322, _43ASSIGN_OPS_54935, 1);
    if (_28775 != 0)
    goto L10; // [549] 613
    _28775 = NOVALUE;

    /** parser.e:1685			sequence lname = SymTab[left_var[T_SYM]][S_NAME]*/
    _2 = (object)SEQ_PTR(_left_var_57317);
    _28777 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28777)){
        _28778 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28777)->dbl));
    }
    else{
        _28778 = (object)*(((s1_ptr)_2)->base + _28777);
    }
    DeRef(_lname_57450);
    _2 = (object)SEQ_PTR(_28778);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _lname_57450 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _lname_57450 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_lname_57450);
    _28778 = NOVALUE;

    /** parser.e:1686			if assign_op = COLON then*/
    if (_assign_op_57322 != -23)
    goto L11; // [578] 598

    /** parser.e:1687				CompileErr(SYNTAX_ERROR__UNKNOWN_NAMESPACE_1_USED, {lname})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_lname_57450);
    ((intptr_t*)_2)[1] = _lname_57450;
    _28781 = MAKE_SEQ(_1);
    _49CompileErr(133, _28781, 0);
    _28781 = NOVALUE;
    goto L12; // [595] 612
L11: 

    /** parser.e:1689				CompileErr(EXPECTED_TO_SEE_AN_ASSIGNMENT_AFTER_1_SUCH_AS__OR, {lname})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_lname_57450);
    ((intptr_t*)_2)[1] = _lname_57450;
    _28782 = MAKE_SEQ(_1);
    _49CompileErr(76, _28782, 0);
    _28782 = NOVALUE;
L12: 
L10: 
    DeRef(_lname_57450);
    _lname_57450 = NOVALUE;

    /** parser.e:1693		if subs = 0 then*/
    if (_subs_57320 != 0)
    goto L13; // [617] 745

    /** parser.e:1695			integer temp_len = length(Code)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _temp_len_57469 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _temp_len_57469 = 1;
    }

    /** parser.e:1696			if assign_op = EQUALS then*/
    if (_assign_op_57322 != 3)
    goto L14; // [632] 653

    /** parser.e:1697				Expr() -- RHS expression*/
    _43Expr();

    /** parser.e:1698				InitCheck(left_sym, FALSE)*/
    _43InitCheck(_43left_sym_54993, _9FALSE_444);
    goto L15; // [650] 726
L14: 

    /** parser.e:1700				InitCheck(left_sym, TRUE)*/
    _43InitCheck(_43left_sym_54993, _9TRUE_446);

    /** parser.e:1701				if left_sym > 0 then*/
    if (_43left_sym_54993 <= 0)
    goto L16; // [667] 709

    /** parser.e:1702					SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_READ)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_43left_sym_54993 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28789 = (object)*(((s1_ptr)_2)->base + _43left_sym_54993);
    _2 = (object)SEQ_PTR(_28789);
    _28790 = (object)*(((s1_ptr)_2)->base + 5);
    _28789 = NOVALUE;
    if (IS_ATOM_INT(_28790)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28790 | (uintptr_t)1;
             _28791 = MAKE_UINT(tu);
        }
    }
    else {
        _28791 = binary_op(OR_BITS, _28790, 1);
    }
    _28790 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28791;
    if( _1 != _28791 ){
        DeRef(_1);
    }
    _28791 = NOVALUE;
    _28787 = NOVALUE;
L16: 

    /** parser.e:1704				emit_opnd(left_sym)*/
    _45emit_opnd(_43left_sym_54993);

    /** parser.e:1705				Expr() -- RHS expression*/
    _43Expr();

    /** parser.e:1706				emit_assign_op(assign_op)*/
    _45emit_assign_op(_assign_op_57322);
L15: 

    /** parser.e:1708			emit_op(ASSIGN)*/
    _45emit_op(18);

    /** parser.e:1709			TypeCheck(left_sym)*/
    _43TypeCheck(_43left_sym_54993);
    goto L17; // [742] 1169
L13: 

    /** parser.e:1712			factors = 0*/
    _43factors_54990 = 0;

    /** parser.e:1713			lhs_subs_level = -1*/
    _43lhs_subs_level_54991 = -1;

    /** parser.e:1714			Expr() -- RHS expression*/
    _43Expr();

    /** parser.e:1716			if subs > 1 then*/
    if (_subs_57320 <= 1)
    goto L18; // [761] 900

    /** parser.e:1717				if left_sym < 0 or SymTab[left_sym][S_SCOPE] != SC_PRIVATE and*/
    _28793 = (_43left_sym_54993 < 0);
    if (_28793 != 0) {
        _28794 = 1;
        goto L19; // [773] 801
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28795 = (object)*(((s1_ptr)_2)->base + _43left_sym_54993);
    _2 = (object)SEQ_PTR(_28795);
    _28796 = (object)*(((s1_ptr)_2)->base + 4);
    _28795 = NOVALUE;
    if (IS_ATOM_INT(_28796)) {
        _28797 = (_28796 != 3);
    }
    else {
        _28797 = binary_op(NOTEQ, _28796, 3);
    }
    _28796 = NOVALUE;
    if (IS_ATOM_INT(_28797))
    _28794 = (_28797 != 0);
    else
    _28794 = DBL_PTR(_28797)->dbl != 0.0;
L19: 
    if (_28794 == 0) {
        goto L1A; // [801] 835
    }
    _28799 = (_43left_sym_54993 % 29);
    _28800 = power(2, _28799);
    _28799 = NOVALUE;
    if (IS_ATOM_INT(_28800)) {
        {uintptr_t tu;
             tu = (uintptr_t)_43side_effect_calls_54989 & (uintptr_t)_28800;
             _28801 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)_43side_effect_calls_54989;
        _28801 = Dand_bits(&temp_d, DBL_PTR(_28800));
    }
    DeRef(_28800);
    _28800 = NOVALUE;
    if (_28801 == 0) {
        DeRef(_28801);
        _28801 = NOVALUE;
        goto L1A; // [824] 835
    }
    else {
        if (!IS_ATOM_INT(_28801) && DBL_PTR(_28801)->dbl == 0.0){
            DeRef(_28801);
            _28801 = NOVALUE;
            goto L1A; // [824] 835
        }
        DeRef(_28801);
        _28801 = NOVALUE;
    }
    DeRef(_28801);
    _28801 = NOVALUE;

    /** parser.e:1722					dangerous = TRUE*/
    _dangerous_57325 = _9TRUE_446;
L1A: 

    /** parser.e:1725				if factors = 1 and*/
    _28802 = (_43factors_54990 == 1);
    if (_28802 == 0) {
        _28803 = 0;
        goto L1B; // [843] 857
    }
    _28804 = (_43lhs_subs_level_54991 >= 0);
    _28803 = (_28804 != 0);
L1B: 
    if (_28803 == 0) {
        goto L1C; // [857] 883
    }
    _28806 = _subs_57320 + _slice_57321;
    if ((object)((uintptr_t)_28806 + (uintptr_t)HIGH_BITS) >= 0){
        _28806 = NewDouble((eudouble)_28806);
    }
    if (IS_ATOM_INT(_28806)) {
        _28807 = (_43lhs_subs_level_54991 < _28806);
    }
    else {
        _28807 = ((eudouble)_43lhs_subs_level_54991 < DBL_PTR(_28806)->dbl);
    }
    DeRef(_28806);
    _28806 = NOVALUE;
    if (_28807 == 0)
    {
        DeRef(_28807);
        _28807 = NOVALUE;
        goto L1C; // [872] 883
    }
    else{
        DeRef(_28807);
        _28807 = NOVALUE;
    }

    /** parser.e:1729					dangerous = TRUE*/
    _dangerous_57325 = _9TRUE_446;
L1C: 

    /** parser.e:1732				if dangerous then*/
    if (_dangerous_57325 == 0)
    {
        goto L1D; // [885] 899
    }
    else{
    }

    /** parser.e:1738					backpatch(subs1_patch, LHS_SUBS1_COPY)*/
    _45backpatch(_subs1_patch_57323, 166);
L1D: 
L18: 

    /** parser.e:1742			if slice then*/
    if (_slice_57321 == 0)
    {
        goto L1E; // [902] 970
    }
    else{
    }

    /** parser.e:1743				if assign_op != EQUALS then*/
    if (_assign_op_57322 == 3)
    goto L1F; // [909] 943

    /** parser.e:1744					if subs = 1 then*/
    if (_subs_57320 != 1)
    goto L20; // [915] 929

    /** parser.e:1745						emit_op(ASSIGN_OP_SLICE)*/
    _45emit_op(150);
    goto L21; // [926] 937
L20: 

    /** parser.e:1747						emit_op(PASSIGN_OP_SLICE)*/
    _45emit_op(165);
L21: 

    /** parser.e:1749					emit_assign_op(assign_op)*/
    _45emit_assign_op(_assign_op_57322);
L1F: 

    /** parser.e:1751				if subs = 1 then*/
    if (_subs_57320 != 1)
    goto L22; // [945] 959

    /** parser.e:1752					emit_op(ASSIGN_SLICE)*/
    _45emit_op(45);
    goto L23; // [956] 1060
L22: 

    /** parser.e:1754					emit_op(PASSIGN_SLICE)*/
    _45emit_op(163);
    goto L23; // [967] 1060
L1E: 

    /** parser.e:1757				if assign_op = EQUALS then*/
    if (_assign_op_57322 != 3)
    goto L24; // [974] 1005

    /** parser.e:1758					if subs = 1 then*/
    if (_subs_57320 != 1)
    goto L25; // [980] 994

    /** parser.e:1759						emit_op(ASSIGN_SUBS)*/
    _45emit_op(16);
    goto L26; // [991] 1059
L25: 

    /** parser.e:1761						emit_op(PASSIGN_SUBS)*/
    _45emit_op(162);
    goto L26; // [1002] 1059
L24: 

    /** parser.e:1764					if subs = 1 then*/
    if (_subs_57320 != 1)
    goto L27; // [1007] 1021

    /** parser.e:1765						emit_op(ASSIGN_OP_SUBS)*/
    _45emit_op(149);
    goto L28; // [1018] 1029
L27: 

    /** parser.e:1767						emit_op(PASSIGN_OP_SUBS)*/
    _45emit_op(164);
L28: 

    /** parser.e:1769					emit_assign_op(assign_op)*/
    _45emit_assign_op(_assign_op_57322);

    /** parser.e:1770					if subs = 1 then*/
    if (_subs_57320 != 1)
    goto L29; // [1036] 1050

    /** parser.e:1771						emit_op(ASSIGN_SUBS2)*/
    _45emit_op(148);
    goto L2A; // [1047] 1058
L29: 

    /** parser.e:1773						emit_op(PASSIGN_SUBS)*/
    _45emit_op(162);
L2A: 
L26: 
L23: 

    /** parser.e:1778			if subs > 1 then*/
    if (_subs_57320 <= 1)
    goto L2B; // [1062] 1114

    /** parser.e:1779				if dangerous then*/
    if (_dangerous_57325 == 0)
    {
        goto L2C; // [1068] 1105
    }
    else{
    }

    /** parser.e:1781					emit_opnd(left_sym)*/
    _45emit_opnd(_43left_sym_54993);

    /** parser.e:1782					emit_opnd(lhs_subs1_copy_temp) -- will be freed*/
    _45emit_opnd(_45lhs_subs1_copy_temp_50973);

    /** parser.e:1783					emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
    _45emit_temp(_45lhs_subs1_copy_temp_50973, 1);

    /** parser.e:1784					emit_op(ASSIGN)*/
    _45emit_op(18);
    goto L2D; // [1102] 1113
L2C: 

    /** parser.e:1787					TempFree(lhs_subs1_copy_temp)*/
    _45TempFree(_45lhs_subs1_copy_temp_50973);
L2D: 
L2B: 

    /** parser.e:1791			if OpTypeCheck and (left_sym < 0 or SymTab[left_sym][S_VTYPE] != sequence_type) then*/
    if (_12OpTypeCheck_20297 == 0) {
        goto L2E; // [1118] 1168
    }
    _28817 = (_43left_sym_54993 < 0);
    if (_28817 != 0) {
        DeRef(_28818);
        _28818 = 1;
        goto L2F; // [1128] 1156
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28819 = (object)*(((s1_ptr)_2)->base + _43left_sym_54993);
    _2 = (object)SEQ_PTR(_28819);
    _28820 = (object)*(((s1_ptr)_2)->base + 15);
    _28819 = NOVALUE;
    if (IS_ATOM_INT(_28820)) {
        _28821 = (_28820 != _53sequence_type_46807);
    }
    else {
        _28821 = binary_op(NOTEQ, _28820, _53sequence_type_46807);
    }
    _28820 = NOVALUE;
    if (IS_ATOM_INT(_28821))
    _28818 = (_28821 != 0);
    else
    _28818 = DBL_PTR(_28821)->dbl != 0.0;
L2F: 
    if (_28818 == 0)
    {
        _28818 = NOVALUE;
        goto L2E; // [1157] 1168
    }
    else{
        _28818 = NOVALUE;
    }

    /** parser.e:1792				TypeCheck(left_sym)*/
    _43TypeCheck(_43left_sym_54993);
L2E: 
L17: 

    /** parser.e:1796		current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_45current_sequence_50968)){
            _28822 = SEQ_PTR(_45current_sequence_50968)->length;
    }
    else {
        _28822 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45current_sequence_50968);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28822)) ? _28822 : (object)(DBL_PTR(_28822)->dbl);
        int stop = (IS_ATOM_INT(_28822)) ? _28822 : (object)(DBL_PTR(_28822)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45current_sequence_50968), start, &_45current_sequence_50968 );
            }
            else Tail(SEQ_PTR(_45current_sequence_50968), stop+1, &_45current_sequence_50968);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45current_sequence_50968), start, &_45current_sequence_50968);
        }
        else {
            assign_slice_seq = &assign_space;
            _45current_sequence_50968 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_50968)->ref == 1));
        }
    }
    _28822 = NOVALUE;
    _28822 = NOVALUE;

    /** parser.e:1798		if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto L30; // [1189] 1215

    /** parser.e:1799			if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto L31; // [1196] 1214
    }
    else{
    }

    /** parser.e:1800				emit_op(DISPLAY_VAR)*/
    _45emit_op(87);

    /** parser.e:1801				emit_addr(left_sym)*/
    _45emit_addr(_43left_sym_54993);
L31: 
L30: 

    /** parser.e:1804	end procedure*/
    DeRef(_left_var_57317);
    DeRef(_tok_57319);
    DeRef(_28733);
    _28733 = NOVALUE;
    DeRef(_28817);
    _28817 = NOVALUE;
    DeRef(_28802);
    _28802 = NOVALUE;
    DeRef(_28821);
    _28821 = NOVALUE;
    DeRef(_28804);
    _28804 = NOVALUE;
    DeRef(_28793);
    _28793 = NOVALUE;
    DeRef(_28797);
    _28797 = NOVALUE;
    _28777 = NOVALUE;
    return;
    ;
}


void _43Multi_assign()
{
    object _lhs_syms_57609 = NOVALUE;
    object _lhs_list_57610 = NOVALUE;
    object _tok_57612 = NOVALUE;
    object _need_comma_57613 = NOVALUE;
    object _temp_sym_57675 = NOVALUE;
    object _temps_57678 = NOVALUE;
    object _len_57726 = NOVALUE;
    object _28881 = NOVALUE;
    object _28879 = NOVALUE;
    object _28877 = NOVALUE;
    object _28875 = NOVALUE;
    object _28874 = NOVALUE;
    object _28873 = NOVALUE;
    object _28872 = NOVALUE;
    object _28871 = NOVALUE;
    object _28870 = NOVALUE;
    object _28868 = NOVALUE;
    object _28867 = NOVALUE;
    object _28866 = NOVALUE;
    object _28865 = NOVALUE;
    object _28864 = NOVALUE;
    object _28862 = NOVALUE;
    object _28861 = NOVALUE;
    object _28860 = NOVALUE;
    object _28859 = NOVALUE;
    object _28858 = NOVALUE;
    object _28854 = NOVALUE;
    object _28853 = NOVALUE;
    object _28852 = NOVALUE;
    object _28851 = NOVALUE;
    object _28848 = NOVALUE;
    object _28847 = NOVALUE;
    object _28845 = NOVALUE;
    object _28844 = NOVALUE;
    object _28843 = NOVALUE;
    object _28841 = NOVALUE;
    object _28840 = NOVALUE;
    object _28839 = NOVALUE;
    object _28838 = NOVALUE;
    object _28836 = NOVALUE;
    object _28835 = NOVALUE;
    object _28834 = NOVALUE;
    object _28832 = NOVALUE;
    object _28831 = NOVALUE;
    object _28828 = NOVALUE;
    object _28825 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1811		sequence lhs_syms = {}*/
    RefDS(_22015);
    DeRef(_lhs_syms_57609);
    _lhs_syms_57609 = _22015;

    /** parser.e:1812		sequence lhs_list = {} -- make sure we don't repeat anything*/
    RefDS(_22015);
    DeRef(_lhs_list_57610);
    _lhs_list_57610 = _22015;

    /** parser.e:1814		integer need_comma = 0*/
    _need_comma_57613 = 0;

    /** parser.e:1815		while tok[T_ID] != RIGHT_BRACE with entry do*/
    goto L1; // [22] 215
L2: 
    _2 = (object)SEQ_PTR(_tok_57612);
    _28825 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28825, -25)){
        _28825 = NOVALUE;
        goto L3; // [35] 225
    }
    _28825 = NOVALUE;

    /** parser.e:1817			if need_comma then*/
    if (_need_comma_57613 == 0)
    {
        goto L4; // [41] 63
    }
    else{
    }

    /** parser.e:1818				putback( tok )*/
    Ref(_tok_57612);
    _43putback(_tok_57612);

    /** parser.e:1819				tok_match( COMMA )*/
    _43tok_match(-30, 0);

    /** parser.e:1820				tok = next_token()*/
    _0 = _tok_57612;
    _tok_57612 = _43next_token();
    DeRef(_0);
L4: 

    /** parser.e:1823			if tok[T_ID] = QUESTION_MARK then*/
    _2 = (object)SEQ_PTR(_tok_57612);
    _28828 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28828, -31)){
        _28828 = NOVALUE;
        goto L5; // [73] 86
    }
    _28828 = NOVALUE;

    /** parser.e:1825				lhs_syms &= 0*/
    Append(&_lhs_syms_57609, _lhs_syms_57609, 0);
    goto L6; // [83] 207
L5: 

    /** parser.e:1826			elsif tok[T_ID] = VARIABLE or tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_57612);
    _28831 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28831)) {
        _28832 = (_28831 == -100);
    }
    else {
        _28832 = binary_op(EQUALS, _28831, -100);
    }
    _28831 = NOVALUE;
    if (IS_ATOM_INT(_28832)) {
        if (_28832 != 0) {
            goto L7; // [100] 121
        }
    }
    else {
        if (DBL_PTR(_28832)->dbl != 0.0) {
            goto L7; // [100] 121
        }
    }
    _2 = (object)SEQ_PTR(_tok_57612);
    _28834 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28834)) {
        _28835 = (_28834 == 512);
    }
    else {
        _28835 = binary_op(EQUALS, _28834, 512);
    }
    _28834 = NOVALUE;
    if (_28835 == 0) {
        DeRef(_28835);
        _28835 = NOVALUE;
        goto L8; // [117] 197
    }
    else {
        if (!IS_ATOM_INT(_28835) && DBL_PTR(_28835)->dbl == 0.0){
            DeRef(_28835);
            _28835 = NOVALUE;
            goto L8; // [117] 197
        }
        DeRef(_28835);
        _28835 = NOVALUE;
    }
    DeRef(_28835);
    _28835 = NOVALUE;
L7: 

    /** parser.e:1827				lhs_syms &= tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_57612);
    _28836 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_lhs_syms_57609) && IS_ATOM(_28836)) {
        Ref(_28836);
        Append(&_lhs_syms_57609, _lhs_syms_57609, _28836);
    }
    else if (IS_ATOM(_lhs_syms_57609) && IS_SEQUENCE(_28836)) {
    }
    else {
        Concat((object_ptr)&_lhs_syms_57609, _lhs_syms_57609, _28836);
    }
    _28836 = NOVALUE;

    /** parser.e:1828				if SymTab[lhs_syms[$]][S_SCOPE] = SC_UNDEFINED then*/
    if (IS_SEQUENCE(_lhs_syms_57609)){
            _28838 = SEQ_PTR(_lhs_syms_57609)->length;
    }
    else {
        _28838 = 1;
    }
    _2 = (object)SEQ_PTR(_lhs_syms_57609);
    _28839 = (object)*(((s1_ptr)_2)->base + _28838);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28839)){
        _28840 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28839)->dbl));
    }
    else{
        _28840 = (object)*(((s1_ptr)_2)->base + _28839);
    }
    _2 = (object)SEQ_PTR(_28840);
    _28841 = (object)*(((s1_ptr)_2)->base + 4);
    _28840 = NOVALUE;
    if (binary_op_a(NOTEQ, _28841, 9)){
        _28841 = NOVALUE;
        goto L9; // [156] 180
    }
    _28841 = NOVALUE;

    /** parser.e:1829					lhs_list = append( lhs_list, sym_name( lhs_syms[$] ) )*/
    if (IS_SEQUENCE(_lhs_syms_57609)){
            _28843 = SEQ_PTR(_lhs_syms_57609)->length;
    }
    else {
        _28843 = 1;
    }
    _2 = (object)SEQ_PTR(_lhs_syms_57609);
    _28844 = (object)*(((s1_ptr)_2)->base + _28843);
    Ref(_28844);
    _28845 = _53sym_name(_28844);
    _28844 = NOVALUE;
    Ref(_28845);
    Append(&_lhs_list_57610, _lhs_list_57610, _28845);
    DeRef(_28845);
    _28845 = NOVALUE;
    goto L6; // [177] 207
L9: 

    /** parser.e:1831					lhs_list &= lhs_syms[$]*/
    if (IS_SEQUENCE(_lhs_syms_57609)){
            _28847 = SEQ_PTR(_lhs_syms_57609)->length;
    }
    else {
        _28847 = 1;
    }
    _2 = (object)SEQ_PTR(_lhs_syms_57609);
    _28848 = (object)*(((s1_ptr)_2)->base + _28847);
    if (IS_SEQUENCE(_lhs_list_57610) && IS_ATOM(_28848)) {
        Ref(_28848);
        Append(&_lhs_list_57610, _lhs_list_57610, _28848);
    }
    else if (IS_ATOM(_lhs_list_57610) && IS_SEQUENCE(_28848)) {
    }
    else {
        Concat((object_ptr)&_lhs_list_57610, _lhs_list_57610, _28848);
    }
    _28848 = NOVALUE;
    goto L6; // [194] 207
L8: 

    /** parser.e:1834				CompileErr( A_VARIABLE_NAME_IS_EXPECTED_HERE)*/
    RefDS(_22015);
    _49CompileErr(24, _22015, 0);
L6: 

    /** parser.e:1837			need_comma = 1*/
    _need_comma_57613 = 1;

    /** parser.e:1838		entry*/
L1: 

    /** parser.e:1839			tok = next_token()*/
    _0 = _tok_57612;
    _tok_57612 = _43next_token();
    DeRef(_0);

    /** parser.e:1840		end while*/
    goto L2; // [222] 25
L3: 

    /** parser.e:1843		if length( lhs_list ) != length( remove_dups( sort( lhs_list ) ) ) then*/
    if (IS_SEQUENCE(_lhs_list_57610)){
            _28851 = SEQ_PTR(_lhs_list_57610)->length;
    }
    else {
        _28851 = 1;
    }
    RefDS(_lhs_list_57610);
    _28852 = _25sort(_lhs_list_57610, 1);
    _28853 = _24remove_dups(_28852, 2);
    _28852 = NOVALUE;
    if (IS_SEQUENCE(_28853)){
            _28854 = SEQ_PTR(_28853)->length;
    }
    else {
        _28854 = 1;
    }
    DeRef(_28853);
    _28853 = NOVALUE;
    if (_28851 == _28854)
    goto LA; // [243] 257

    /** parser.e:1844			CompileErr( DUPLICATE_MULTI_ASSIGN )*/
    RefDS(_22015);
    _49CompileErr(602, _22015, 0);
LA: 

    /** parser.e:1846		tok_match( EQUALS )*/
    _43tok_match(3, 0);

    /** parser.e:1849		Expr()*/
    _43Expr();

    /** parser.e:1851		symtab_index temp_sym = Pop()*/
    _temp_sym_57675 = _45Pop();
    if (!IS_ATOM_INT(_temp_sym_57675)) {
        _1 = (object)(DBL_PTR(_temp_sym_57675)->dbl);
        DeRefDS(_temp_sym_57675);
        _temp_sym_57675 = _1;
    }

    /** parser.e:1852		sequence temps = pop_temps()*/
    _0 = _temps_57678;
    _temps_57678 = _45pop_temps();
    DeRef(_0);

    /** parser.e:1853		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto LB; // [287] 303
    }
    else{
    }

    /** parser.e:1854			emit_opnd( temp_sym )*/
    _45emit_opnd(_temp_sym_57675);

    /** parser.e:1855			emit_op( REF_TEMP )*/
    _45emit_op(207);
LB: 

    /** parser.e:1858		for i = 1 to length( lhs_syms ) do*/
    if (IS_SEQUENCE(_lhs_syms_57609)){
            _28858 = SEQ_PTR(_lhs_syms_57609)->length;
    }
    else {
        _28858 = 1;
    }
    {
        object _i_57687;
        _i_57687 = 1;
LC: 
        if (_i_57687 > _28858){
            goto LD; // [308] 512
        }

        /** parser.e:1859			if lhs_syms[i] then*/
        _2 = (object)SEQ_PTR(_lhs_syms_57609);
        _28859 = (object)*(((s1_ptr)_2)->base + _i_57687);
        if (_28859 == 0) {
            _28859 = NOVALUE;
            goto LE; // [321] 503
        }
        else {
            if (!IS_ATOM_INT(_28859) && DBL_PTR(_28859)->dbl == 0.0){
                _28859 = NOVALUE;
                goto LE; // [321] 503
            }
            _28859 = NOVALUE;
        }
        _28859 = NOVALUE;

        /** parser.e:1860				if SymTab[lhs_syms[i]][S_SCOPE] = SC_UNDEFINED then*/
        _2 = (object)SEQ_PTR(_lhs_syms_57609);
        _28860 = (object)*(((s1_ptr)_2)->base + _i_57687);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!IS_ATOM_INT(_28860)){
            _28861 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28860)->dbl));
        }
        else{
            _28861 = (object)*(((s1_ptr)_2)->base + _28860);
        }
        _2 = (object)SEQ_PTR(_28861);
        _28862 = (object)*(((s1_ptr)_2)->base + 4);
        _28861 = NOVALUE;
        if (binary_op_a(NOTEQ, _28862, 9)){
            _28862 = NOVALUE;
            goto LF; // [344] 379
        }
        _28862 = NOVALUE;

        /** parser.e:1861					Forward_var( { VARIABLE, lhs_syms[i]}, ,ASSIGN )*/
        _2 = (object)SEQ_PTR(_lhs_syms_57609);
        _28864 = (object)*(((s1_ptr)_2)->base + _i_57687);
        Ref(_28864);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -100;
        ((intptr_t *)_2)[2] = _28864;
        _28865 = MAKE_SEQ(_1);
        _28864 = NOVALUE;
        _43Forward_var(_28865, -1, 18);
        _28865 = NOVALUE;

        /** parser.e:1862					lhs_syms[i] = Pop()*/
        _28866 = _45Pop();
        _2 = (object)SEQ_PTR(_lhs_syms_57609);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _lhs_syms_57609 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_57687);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28866;
        if( _1 != _28866 ){
            DeRef(_1);
        }
        _28866 = NOVALUE;
        goto L10; // [376] 421
LF: 

        /** parser.e:1864					SymTab[lhs_syms[i]][S_USAGE] = or_bits(SymTab[lhs_syms[i]][S_USAGE], U_WRITTEN)*/
        _2 = (object)SEQ_PTR(_lhs_syms_57609);
        _28867 = (object)*(((s1_ptr)_2)->base + _i_57687);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_28867))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_28867)->dbl));
        else
        _3 = (object)(_28867 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_lhs_syms_57609);
        _28870 = (object)*(((s1_ptr)_2)->base + _i_57687);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!IS_ATOM_INT(_28870)){
            _28871 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28870)->dbl));
        }
        else{
            _28871 = (object)*(((s1_ptr)_2)->base + _28870);
        }
        _2 = (object)SEQ_PTR(_28871);
        _28872 = (object)*(((s1_ptr)_2)->base + 5);
        _28871 = NOVALUE;
        if (IS_ATOM_INT(_28872)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_28872 | (uintptr_t)2;
                 _28873 = MAKE_UINT(tu);
            }
        }
        else {
            _28873 = binary_op(OR_BITS, _28872, 2);
        }
        _28872 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28873;
        if( _1 != _28873 ){
            DeRef(_1);
        }
        _28873 = NOVALUE;
        _28868 = NOVALUE;
L10: 

        /** parser.e:1867				emit_opnd( lhs_syms[i] )*/
        _2 = (object)SEQ_PTR(_lhs_syms_57609);
        _28874 = (object)*(((s1_ptr)_2)->base + _i_57687);
        Ref(_28874);
        _45emit_opnd(_28874);
        _28874 = NOVALUE;

        /** parser.e:1869				emit_opnd( temp_sym )*/
        _45emit_opnd(_temp_sym_57675);

        /** parser.e:1870				emit_opnd( NewIntSym( i ) )*/
        _28875 = _53NewIntSym(_i_57687);
        _45emit_opnd(_28875);
        _28875 = NOVALUE;

        /** parser.e:1871				emit_op( RHS_SUBS )*/
        _45emit_op(25);

        /** parser.e:1872				integer len = length( Code )*/
        if (IS_SEQUENCE(_12Code_20315)){
                _len_57726 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _len_57726 = 1;
        }

        /** parser.e:1873				if Code[len] = temp_sym then*/
        _2 = (object)SEQ_PTR(_12Code_20315);
        _28877 = (object)*(((s1_ptr)_2)->base + _len_57726);
        if (binary_op_a(NOTEQ, _28877, _temp_sym_57675)){
            _28877 = NOVALUE;
            goto L11; // [466] 486
        }
        _28877 = NOVALUE;

        /** parser.e:1875					Code = remove( Code, len - 1, len )*/
        _28879 = _len_57726 - 1;
        {
            s1_ptr assign_space = SEQ_PTR(_12Code_20315);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_28879)) ? _28879 : (object)(DBL_PTR(_28879)->dbl);
            int stop = (IS_ATOM_INT(_len_57726)) ? _len_57726 : (object)(DBL_PTR(_len_57726)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_12Code_20315), start, &_12Code_20315 );
                }
                else Tail(SEQ_PTR(_12Code_20315), stop+1, &_12Code_20315);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_12Code_20315), start, &_12Code_20315);
            }
            else {
                assign_slice_seq = &assign_space;
                _12Code_20315 = Remove_elements(start, stop, (SEQ_PTR(_12Code_20315)->ref == 1));
            }
        }
        _28879 = NOVALUE;
L11: 

        /** parser.e:1877				emit_op( ASSIGN )*/
        _45emit_op(18);

        /** parser.e:1879				TypeCheck( lhs_syms[i] )*/
        _2 = (object)SEQ_PTR(_lhs_syms_57609);
        _28881 = (object)*(((s1_ptr)_2)->base + _i_57687);
        Ref(_28881);
        _43TypeCheck(_28881);
        _28881 = NOVALUE;
LE: 

        /** parser.e:1882		end for*/
        _i_57687 = _i_57687 + 1;
        goto LC; // [507] 315
LD: 
        ;
    }

    /** parser.e:1884		push_temps( temps )*/
    RefDS(_temps_57678);
    _45push_temps(_temps_57678);

    /** parser.e:1885		flush_temps()*/
    RefDS(_22015);
    _45flush_temps(_22015);

    /** parser.e:1887		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L12; // [526] 542
    }
    else{
    }

    /** parser.e:1888			emit_opnd( temp_sym )*/
    _45emit_opnd(_temp_sym_57675);

    /** parser.e:1889			emit_op( DEREF_TEMP )*/
    _45emit_op(208);
L12: 

    /** parser.e:1891	end procedure*/
    DeRef(_lhs_syms_57609);
    DeRef(_lhs_list_57610);
    DeRef(_tok_57612);
    DeRef(_temps_57678);
    _28870 = NOVALUE;
    _28839 = NOVALUE;
    _28867 = NOVALUE;
    DeRef(_28832);
    _28832 = NOVALUE;
    _28860 = NOVALUE;
    _28853 = NOVALUE;
    return;
    ;
}


void _43Return_statement()
{
    object _tok_57750 = NOVALUE;
    object _pop_57751 = NOVALUE;
    object _last_op_57758 = NOVALUE;
    object _last_pc_57761 = NOVALUE;
    object _is_tail_57764 = NOVALUE;
    object _28913 = NOVALUE;
    object _28911 = NOVALUE;
    object _28910 = NOVALUE;
    object _28909 = NOVALUE;
    object _28908 = NOVALUE;
    object _28906 = NOVALUE;
    object _28905 = NOVALUE;
    object _28904 = NOVALUE;
    object _28903 = NOVALUE;
    object _28902 = NOVALUE;
    object _28901 = NOVALUE;
    object _28900 = NOVALUE;
    object _28899 = NOVALUE;
    object _28895 = NOVALUE;
    object _28894 = NOVALUE;
    object _28892 = NOVALUE;
    object _28891 = NOVALUE;
    object _28890 = NOVALUE;
    object _28889 = NOVALUE;
    object _28888 = NOVALUE;
    object _28887 = NOVALUE;
    object _28886 = NOVALUE;
    object _28885 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1897		integer pop*/

    /** parser.e:1898		if CurrentSub = TopLevelSub then*/
    if (_12CurrentSub_20234 != _12TopLevelSub_20233)
    goto L1; // [9] 23

    /** parser.e:1899			CompileErr(RETURN_MUST_BE_INSIDE_A_PROCEDURE_OR_FUNCTION)*/
    RefDS(_22015);
    _49CompileErr(130, _22015, 0);
L1: 

    /** parser.e:1902		integer*/

    /** parser.e:1903			last_op = Last_op(),*/
    _last_op_57758 = _45Last_op();
    if (!IS_ATOM_INT(_last_op_57758)) {
        _1 = (object)(DBL_PTR(_last_op_57758)->dbl);
        DeRefDS(_last_op_57758);
        _last_op_57758 = _1;
    }

    /** parser.e:1904			last_pc = Last_pc(),*/
    _last_pc_57761 = _45Last_pc();
    if (!IS_ATOM_INT(_last_pc_57761)) {
        _1 = (object)(DBL_PTR(_last_pc_57761)->dbl);
        DeRefDS(_last_pc_57761);
        _last_pc_57761 = _1;
    }

    /** parser.e:1905			is_tail = 0*/
    _is_tail_57764 = 0;

    /** parser.e:1907		if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _28885 = (_last_op_57758 == 27);
    if (_28885 == 0) {
        _28886 = 0;
        goto L2; // [52] 69
    }
    if (IS_SEQUENCE(_12Code_20315)){
            _28887 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _28887 = 1;
    }
    _28888 = (_28887 > _last_pc_57761);
    _28887 = NOVALUE;
    _28886 = (_28888 != 0);
L2: 
    if (_28886 == 0) {
        goto L3; // [69] 99
    }
    _28890 = _last_pc_57761 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _28891 = (object)*(((s1_ptr)_2)->base + _28890);
    if (IS_ATOM_INT(_28891)) {
        _28892 = (_28891 == _12CurrentSub_20234);
    }
    else {
        _28892 = binary_op(EQUALS, _28891, _12CurrentSub_20234);
    }
    _28891 = NOVALUE;
    if (_28892 == 0) {
        DeRef(_28892);
        _28892 = NOVALUE;
        goto L3; // [90] 99
    }
    else {
        if (!IS_ATOM_INT(_28892) && DBL_PTR(_28892)->dbl == 0.0){
            DeRef(_28892);
            _28892 = NOVALUE;
            goto L3; // [90] 99
        }
        DeRef(_28892);
        _28892 = NOVALUE;
    }
    DeRef(_28892);
    _28892 = NOVALUE;

    /** parser.e:1908			is_tail = 1*/
    _is_tail_57764 = 1;
L3: 

    /** parser.e:1911		if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto L4; // [103] 129

    /** parser.e:1912			if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto L5; // [110] 128
    }
    else{
    }

    /** parser.e:1913				emit_op(ERASE_PRIVATE_NAMES)*/
    _45emit_op(88);

    /** parser.e:1914				emit_addr(CurrentSub)*/
    _45emit_addr(_12CurrentSub_20234);
L5: 
L4: 

    /** parser.e:1917		if SymTab[CurrentSub][S_TOKEN] != PROC then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28894 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_28894);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _28895 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _28895 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _28894 = NOVALUE;
    if (binary_op_a(EQUALS, _28895, 27)){
        _28895 = NOVALUE;
        goto L6; // [147] 273
    }
    _28895 = NOVALUE;

    /** parser.e:1918			Expr()*/
    _43Expr();

    /** parser.e:1919			last_op = Last_op()*/
    _last_op_57758 = _45Last_op();
    if (!IS_ATOM_INT(_last_op_57758)) {
        _1 = (object)(DBL_PTR(_last_op_57758)->dbl);
        DeRefDS(_last_op_57758);
        _last_op_57758 = _1;
    }

    /** parser.e:1920			last_pc = Last_pc()*/
    _last_pc_57761 = _45Last_pc();
    if (!IS_ATOM_INT(_last_pc_57761)) {
        _1 = (object)(DBL_PTR(_last_pc_57761)->dbl);
        DeRefDS(_last_pc_57761);
        _last_pc_57761 = _1;
    }

    /** parser.e:1921			if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _28899 = (_last_op_57758 == 27);
    if (_28899 == 0) {
        _28900 = 0;
        goto L7; // [177] 194
    }
    if (IS_SEQUENCE(_12Code_20315)){
            _28901 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _28901 = 1;
    }
    _28902 = (_28901 > _last_pc_57761);
    _28901 = NOVALUE;
    _28900 = (_28902 != 0);
L7: 
    if (_28900 == 0) {
        goto L8; // [194] 253
    }
    _28904 = _last_pc_57761 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _28905 = (object)*(((s1_ptr)_2)->base + _28904);
    if (IS_ATOM_INT(_28905)) {
        _28906 = (_28905 == _12CurrentSub_20234);
    }
    else {
        _28906 = binary_op(EQUALS, _28905, _12CurrentSub_20234);
    }
    _28905 = NOVALUE;
    if (_28906 == 0) {
        DeRef(_28906);
        _28906 = NOVALUE;
        goto L8; // [215] 253
    }
    else {
        if (!IS_ATOM_INT(_28906) && DBL_PTR(_28906)->dbl == 0.0){
            DeRef(_28906);
            _28906 = NOVALUE;
            goto L8; // [215] 253
        }
        DeRef(_28906);
        _28906 = NOVALUE;
    }
    DeRef(_28906);
    _28906 = NOVALUE;

    /** parser.e:1922				pop = Pop() -- prevent cg_stack (code generation stack) leakage*/
    _pop_57751 = _45Pop();
    if (!IS_ATOM_INT(_pop_57751)) {
        _1 = (object)(DBL_PTR(_pop_57751)->dbl);
        DeRefDS(_pop_57751);
        _pop_57751 = _1;
    }

    /** parser.e:1923				Code[Last_pc()] = PROC_TAIL*/
    _28908 = _45Last_pc();
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_28908))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_28908)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _28908);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 203;
    DeRef(_1);

    /** parser.e:1924				if object(pop_temps()) then end if*/
    _28909 = _45pop_temps();
    if( NOVALUE == _28909 ){
        _28910 = 0;
    }
    else{
        if (IS_ATOM_INT(_28909))
        _28910 = 1;
        else if (IS_ATOM_DBL(_28909)) {
             if (IS_ATOM_INT(DoubleToInt(_28909))) {
                 _28910 = 1;
                 } else {
                     _28910 = 2;
                } } else if (IS_SEQUENCE(_28909))
                _28910 = 3;
                else
                _28910 = 0;
            }
            DeRef(_28909);
            _28909 = NOVALUE;
            if (_28910 == 0)
            {
                _28910 = NOVALUE;
                goto L9; // [246] 300
            }
            else{
                _28910 = NOVALUE;
            }
            goto L9; // [250] 300
L8: 

            /** parser.e:1926				FuncReturn = TRUE*/
            _43FuncReturn_54960 = _9TRUE_446;

            /** parser.e:1927				emit_op(RETURNF)*/
            _45emit_op(28);
            goto L9; // [270] 300
L6: 

            /** parser.e:1930			if is_tail then*/
            if (_is_tail_57764 == 0)
            {
                goto LA; // [275] 292
            }
            else{
            }

            /** parser.e:1931				Code[Last_pc()] = PROC_TAIL*/
            _28911 = _45Last_pc();
            _2 = (object)SEQ_PTR(_12Code_20315);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _12Code_20315 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_28911))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_28911)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _28911);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 203;
            DeRef(_1);
LA: 

            /** parser.e:1933			emit_op(RETURNP)*/
            _45emit_op(29);
L9: 

            /** parser.e:1936		tok = next_token()*/
            _0 = _tok_57750;
            _tok_57750 = _43next_token();
            DeRef(_0);

            /** parser.e:1937		putback(tok)*/
            Ref(_tok_57750);
            _43putback(_tok_57750);

            /** parser.e:1938		NotReached(tok[T_ID], "return")*/
            _2 = (object)SEQ_PTR(_tok_57750);
            _28913 = (object)*(((s1_ptr)_2)->base + 1);
            Ref(_28913);
            RefDS(_26278);
            _43NotReached(_28913, _26278);
            _28913 = NOVALUE;

            /** parser.e:1939	end procedure*/
            DeRef(_tok_57750);
            DeRef(_28911);
            _28911 = NOVALUE;
            DeRef(_28888);
            _28888 = NOVALUE;
            DeRef(_28902);
            _28902 = NOVALUE;
            DeRef(_28904);
            _28904 = NOVALUE;
            DeRef(_28885);
            _28885 = NOVALUE;
            DeRef(_28890);
            _28890 = NOVALUE;
            DeRef(_28899);
            _28899 = NOVALUE;
            DeRef(_28908);
            _28908 = NOVALUE;
            return;
    ;
}


object _43exit_level(object _tok_57840, object _flag_57841)
{
    object _arg_57842 = NOVALUE;
    object _n_57843 = NOVALUE;
    object _num_labels_57844 = NOVALUE;
    object _negative_57845 = NOVALUE;
    object _labels_57846 = NOVALUE;
    object _28942 = NOVALUE;
    object _28941 = NOVALUE;
    object _28940 = NOVALUE;
    object _28939 = NOVALUE;
    object _28938 = NOVALUE;
    object _28935 = NOVALUE;
    object _28934 = NOVALUE;
    object _28933 = NOVALUE;
    object _28931 = NOVALUE;
    object _28930 = NOVALUE;
    object _28929 = NOVALUE;
    object _28928 = NOVALUE;
    object _28926 = NOVALUE;
    object _28921 = NOVALUE;
    object _28920 = NOVALUE;
    object _28918 = NOVALUE;
    object _28915 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1946		integer negative = 0*/
    _negative_57845 = 0;

    /** parser.e:1949		if flag then*/
    if (_flag_57841 == 0)
    {
        goto L1; // [10] 25
    }
    else{
    }

    /** parser.e:1950			labels = if_labels*/
    RefDS(_43if_labels_54981);
    DeRef(_labels_57846);
    _labels_57846 = _43if_labels_54981;
    goto L2; // [22] 35
L1: 

    /** parser.e:1952			labels = loop_labels*/
    RefDS(_43loop_labels_54980);
    DeRef(_labels_57846);
    _labels_57846 = _43loop_labels_54980;
L2: 

    /** parser.e:1954		num_labels = length(labels)*/
    if (IS_SEQUENCE(_labels_57846)){
            _num_labels_57844 = SEQ_PTR(_labels_57846)->length;
    }
    else {
        _num_labels_57844 = 1;
    }

    /** parser.e:1956		if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_57840);
    _28915 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28915, 10)){
        _28915 = NOVALUE;
        goto L3; // [52] 67
    }
    _28915 = NOVALUE;

    /** parser.e:1957			tok = next_token()*/
    _0 = _tok_57840;
    _tok_57840 = _43next_token();
    DeRef(_0);

    /** parser.e:1958			negative = 1*/
    _negative_57845 = 1;
L3: 

    /** parser.e:1961		if tok[T_ID]=ATOM then*/
    _2 = (object)SEQ_PTR(_tok_57840);
    _28918 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28918, 502)){
        _28918 = NOVALUE;
        goto L4; // [77] 180
    }
    _28918 = NOVALUE;

    /** parser.e:1962			arg = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_57840);
    _28920 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28920)){
        _28921 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28920)->dbl));
    }
    else{
        _28921 = (object)*(((s1_ptr)_2)->base + _28920);
    }
    DeRef(_arg_57842);
    _2 = (object)SEQ_PTR(_28921);
    _arg_57842 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_arg_57842);
    _28921 = NOVALUE;

    /** parser.e:1963			n = floor(arg)*/
    if (IS_ATOM_INT(_arg_57842))
    _n_57843 = e_floor(_arg_57842);
    else
    _n_57843 = unary_op(FLOOR, _arg_57842);
    if (!IS_ATOM_INT(_n_57843)) {
        _1 = (object)(DBL_PTR(_n_57843)->dbl);
        DeRefDS(_n_57843);
        _n_57843 = _1;
    }

    /** parser.e:1964			if negative then*/
    if (_negative_57845 == 0)
    {
        goto L5; // [110] 122
    }
    else{
    }

    /** parser.e:1965				n = num_labels - n*/
    _n_57843 = _num_labels_57844 - _n_57843;
    goto L6; // [119] 135
L5: 

    /** parser.e:1966			elsif n = 0 then*/
    if (_n_57843 != 0)
    goto L7; // [124] 134

    /** parser.e:1967				n = num_labels*/
    _n_57843 = _num_labels_57844;
L7: 
L6: 

    /** parser.e:1969			if n<=0 or n>num_labels then*/
    _28926 = (_n_57843 <= 0);
    if (_28926 != 0) {
        goto L8; // [141] 154
    }
    _28928 = (_n_57843 > _num_labels_57844);
    if (_28928 == 0)
    {
        DeRef(_28928);
        _28928 = NOVALUE;
        goto L9; // [150] 164
    }
    else{
        DeRef(_28928);
        _28928 = NOVALUE;
    }
L8: 

    /** parser.e:1970				CompileErr(EXITBREAK_ARGUMENT_OUT_OF_RANGE)*/
    RefDS(_22015);
    _49CompileErr(87, _22015, 0);
L9: 

    /** parser.e:1972			return {n, next_token()}*/
    _28929 = _43next_token();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _n_57843;
    ((intptr_t *)_2)[2] = _28929;
    _28930 = MAKE_SEQ(_1);
    _28929 = NOVALUE;
    DeRef(_tok_57840);
    DeRef(_arg_57842);
    DeRef(_labels_57846);
    _28920 = NOVALUE;
    DeRef(_28926);
    _28926 = NOVALUE;
    return _28930;
    goto LA; // [177] 270
L4: 

    /** parser.e:1973		elsif tok[T_ID]=STRING then*/
    _2 = (object)SEQ_PTR(_tok_57840);
    _28931 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28931, 503)){
        _28931 = NOVALUE;
        goto LB; // [190] 259
    }
    _28931 = NOVALUE;

    /** parser.e:1974			n = find(SymTab[tok[T_SYM]][S_OBJ],labels)*/
    _2 = (object)SEQ_PTR(_tok_57840);
    _28933 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28933)){
        _28934 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28933)->dbl));
    }
    else{
        _28934 = (object)*(((s1_ptr)_2)->base + _28933);
    }
    _2 = (object)SEQ_PTR(_28934);
    _28935 = (object)*(((s1_ptr)_2)->base + 1);
    _28934 = NOVALUE;
    _n_57843 = find_from(_28935, _labels_57846, 1);
    _28935 = NOVALUE;

    /** parser.e:1975			if n = 0 then*/
    if (_n_57843 != 0)
    goto LC; // [221] 235

    /** parser.e:1976				CompileErr(UNKNOWN_BLOCK_LABEL)*/
    RefDS(_22015);
    _49CompileErr(152, _22015, 0);
LC: 

    /** parser.e:1978			return {num_labels + 1 - n, next_token()}*/
    _28938 = _num_labels_57844 + 1;
    if (_28938 > MAXINT){
        _28938 = NewDouble((eudouble)_28938);
    }
    if (IS_ATOM_INT(_28938)) {
        _28939 = _28938 - _n_57843;
        if ((object)((uintptr_t)_28939 +(uintptr_t) HIGH_BITS) >= 0){
            _28939 = NewDouble((eudouble)_28939);
        }
    }
    else {
        _28939 = NewDouble(DBL_PTR(_28938)->dbl - (eudouble)_n_57843);
    }
    DeRef(_28938);
    _28938 = NOVALUE;
    _28940 = _43next_token();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28939;
    ((intptr_t *)_2)[2] = _28940;
    _28941 = MAKE_SEQ(_1);
    _28940 = NOVALUE;
    _28939 = NOVALUE;
    DeRef(_tok_57840);
    DeRef(_arg_57842);
    DeRef(_labels_57846);
    DeRef(_28930);
    _28930 = NOVALUE;
    _28920 = NOVALUE;
    _28933 = NOVALUE;
    DeRef(_28926);
    _28926 = NOVALUE;
    return _28941;
    goto LA; // [256] 270
LB: 

    /** parser.e:1980			return {1, tok} -- no parameters*/
    Ref(_tok_57840);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = _tok_57840;
    _28942 = MAKE_SEQ(_1);
    DeRef(_tok_57840);
    DeRef(_arg_57842);
    DeRef(_labels_57846);
    DeRef(_28930);
    _28930 = NOVALUE;
    _28920 = NOVALUE;
    _28933 = NOVALUE;
    DeRef(_28941);
    _28941 = NOVALUE;
    DeRef(_28926);
    _28926 = NOVALUE;
    return _28942;
LA: 
    ;
}


void _43GLabel_statement()
{
    object _tok_57905 = NOVALUE;
    object _labbel_57906 = NOVALUE;
    object _laddr_57907 = NOVALUE;
    object _n_57908 = NOVALUE;
    object _28961 = NOVALUE;
    object _28959 = NOVALUE;
    object _28958 = NOVALUE;
    object _28957 = NOVALUE;
    object _28956 = NOVALUE;
    object _28954 = NOVALUE;
    object _28951 = NOVALUE;
    object _28949 = NOVALUE;
    object _28947 = NOVALUE;
    object _28946 = NOVALUE;
    object _28944 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1986		object labbel*/

    /** parser.e:1987		object laddr*/

    /** parser.e:1988		integer n*/

    /** parser.e:1990		tok = next_token()*/
    _0 = _tok_57905;
    _tok_57905 = _43next_token();
    DeRef(_0);

    /** parser.e:1992		if tok[T_ID] != STRING then*/
    _2 = (object)SEQ_PTR(_tok_57905);
    _28944 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28944, 503)){
        _28944 = NOVALUE;
        goto L1; // [22] 36
    }
    _28944 = NOVALUE;

    /** parser.e:1993			CompileErr(A_LABEL_CLAUSE_MUST_BE_FOLLOWED_BY_A_CONSTANT_STRING)*/
    RefDS(_22015);
    _49CompileErr(35, _22015, 0);
L1: 

    /** parser.e:1996		labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_57905);
    _28946 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28946)){
        _28947 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28946)->dbl));
    }
    else{
        _28947 = (object)*(((s1_ptr)_2)->base + _28946);
    }
    DeRef(_labbel_57906);
    _2 = (object)SEQ_PTR(_28947);
    _labbel_57906 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_labbel_57906);
    _28947 = NOVALUE;

    /** parser.e:1997		laddr = length(Code) + 1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _28949 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _28949 = 1;
    }
    _laddr_57907 = _28949 + 1;
    _28949 = NOVALUE;

    /** parser.e:1999		if find(labbel, goto_labels) then*/
    _28951 = find_from(_labbel_57906, _43goto_labels_54963, 1);
    if (_28951 == 0)
    {
        _28951 = NOVALUE;
        goto L2; // [76] 89
    }
    else{
        _28951 = NOVALUE;
    }

    /** parser.e:2000			CompileErr(DUPLICATE_LABEL_NAME)*/
    RefDS(_22015);
    _49CompileErr(59, _22015, 0);
L2: 

    /** parser.e:2003		goto_labels = append(goto_labels, labbel)*/
    Ref(_labbel_57906);
    Append(&_43goto_labels_54963, _43goto_labels_54963, _labbel_57906);

    /** parser.e:2004		goto_addr = append(goto_addr, laddr)*/
    Append(&_43goto_addr_54964, _43goto_addr_54964, _laddr_57907);

    /** parser.e:2005		label_block = append( label_block, top_block() )*/
    _28954 = _64top_block(0);
    Ref(_28954);
    Append(&_43label_block_54967, _43label_block_54967, _28954);
    DeRef(_28954);
    _28954 = NOVALUE;

    /** parser.e:2007		while n with entry do*/
    goto L3; // [119] 178
L4: 
    if (_n_57908 == 0)
    {
        goto L5; // [124] 192
    }
    else{
    }

    /** parser.e:2008			backpatch(goto_list[n], laddr)*/
    _2 = (object)SEQ_PTR(_12goto_list_20338);
    _28956 = (object)*(((s1_ptr)_2)->base + _n_57908);
    Ref(_28956);
    _45backpatch(_28956, _laddr_57907);
    _28956 = NOVALUE;

    /** parser.e:2009			set_glabel_block( goto_ref[n], top_block() )*/
    _2 = (object)SEQ_PTR(_43goto_ref_54966);
    _28957 = (object)*(((s1_ptr)_2)->base + _n_57908);
    _28958 = _64top_block(0);
    Ref(_28957);
    _42set_glabel_block(_28957, _28958);
    _28957 = NOVALUE;
    _28958 = NOVALUE;

    /** parser.e:2010			goto_delay[n] = "" --clear it*/
    RefDS(_22015);
    _2 = (object)SEQ_PTR(_12goto_delay_20337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12goto_delay_20337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _n_57908);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22015;
    DeRef(_1);

    /** parser.e:2011			goto_line[n] = {-1,""} --clear it*/
    RefDS(_22015);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = _22015;
    _28959 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_43goto_line_54962);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43goto_line_54962 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _n_57908);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28959;
    if( _1 != _28959 ){
        DeRef(_1);
    }
    _28959 = NOVALUE;

    /** parser.e:2013		entry*/
L3: 

    /** parser.e:2014			n = find(labbel, goto_delay)*/
    _n_57908 = find_from(_labbel_57906, _12goto_delay_20337, 1);

    /** parser.e:2015		end while*/
    goto L4; // [189] 122
L5: 

    /** parser.e:2017		force_uninitialize( map:get( goto_init, labbel, {} ) )*/
    Ref(_43goto_init_54969);
    Ref(_labbel_57906);
    RefDS(_22015);
    _28961 = _34get(_43goto_init_54969, _labbel_57906, _22015);
    _43force_uninitialize(_28961);
    _28961 = NOVALUE;

    /** parser.e:2019		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L6; // [209] 225
    }
    else{
    }

    /** parser.e:2020			emit_op(GLABEL)*/
    _45emit_op(189);

    /** parser.e:2021			emit_addr(laddr)*/
    _45emit_addr(_laddr_57907);
L6: 

    /** parser.e:2023	end procedure*/
    DeRef(_tok_57905);
    DeRef(_labbel_57906);
    _28946 = NOVALUE;
    return;
    ;
}


void _43Goto_statement()
{
    object _tok_57957 = NOVALUE;
    object _n_57958 = NOVALUE;
    object _num_labels_57959 = NOVALUE;
    object _31710 = NOVALUE;
    object _29000 = NOVALUE;
    object _28999 = NOVALUE;
    object _28996 = NOVALUE;
    object _28995 = NOVALUE;
    object _28994 = NOVALUE;
    object _28993 = NOVALUE;
    object _28992 = NOVALUE;
    object _28991 = NOVALUE;
    object _28990 = NOVALUE;
    object _28989 = NOVALUE;
    object _28988 = NOVALUE;
    object _28987 = NOVALUE;
    object _28986 = NOVALUE;
    object _28985 = NOVALUE;
    object _28983 = NOVALUE;
    object _28982 = NOVALUE;
    object _28980 = NOVALUE;
    object _28979 = NOVALUE;
    object _28977 = NOVALUE;
    object _28976 = NOVALUE;
    object _28974 = NOVALUE;
    object _28973 = NOVALUE;
    object _28972 = NOVALUE;
    object _28971 = NOVALUE;
    object _28968 = NOVALUE;
    object _28967 = NOVALUE;
    object _28966 = NOVALUE;
    object _28964 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2028		integer n*/

    /** parser.e:2029		integer num_labels*/

    /** parser.e:2031		tok = next_token()*/
    _0 = _tok_57957;
    _tok_57957 = _43next_token();
    DeRef(_0);

    /** parser.e:2032		num_labels = length(goto_labels)*/
    if (IS_SEQUENCE(_43goto_labels_54963)){
            _num_labels_57959 = SEQ_PTR(_43goto_labels_54963)->length;
    }
    else {
        _num_labels_57959 = 1;
    }

    /** parser.e:2034		if tok[T_ID]=STRING then*/
    _2 = (object)SEQ_PTR(_tok_57957);
    _28964 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28964, 503)){
        _28964 = NOVALUE;
        goto L1; // [27] 267
    }
    _28964 = NOVALUE;

    /** parser.e:2035			n = find(SymTab[tok[T_SYM]][S_OBJ],goto_labels)*/
    _2 = (object)SEQ_PTR(_tok_57957);
    _28966 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28966)){
        _28967 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28966)->dbl));
    }
    else{
        _28967 = (object)*(((s1_ptr)_2)->base + _28966);
    }
    _2 = (object)SEQ_PTR(_28967);
    _28968 = (object)*(((s1_ptr)_2)->base + 1);
    _28967 = NOVALUE;
    _n_57958 = find_from(_28968, _43goto_labels_54963, 1);
    _28968 = NOVALUE;

    /** parser.e:2036			if n = 0 then*/
    if (_n_57958 != 0)
    goto L2; // [60] 241

    /** parser.e:2037				goto_delay &= {SymTab[tok[T_SYM]][S_OBJ]}*/
    _2 = (object)SEQ_PTR(_tok_57957);
    _28971 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28971)){
        _28972 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28971)->dbl));
    }
    else{
        _28972 = (object)*(((s1_ptr)_2)->base + _28971);
    }
    _2 = (object)SEQ_PTR(_28972);
    _28973 = (object)*(((s1_ptr)_2)->base + 1);
    _28972 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_28973);
    ((intptr_t*)_2)[1] = _28973;
    _28974 = MAKE_SEQ(_1);
    _28973 = NOVALUE;
    Concat((object_ptr)&_12goto_delay_20337, _12goto_delay_20337, _28974);
    DeRefDS(_28974);
    _28974 = NOVALUE;

    /** parser.e:2038				goto_list &= length(Code)+2 --not 1???*/
    if (IS_SEQUENCE(_12Code_20315)){
            _28976 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _28976 = 1;
    }
    _28977 = _28976 + 2;
    _28976 = NOVALUE;
    Append(&_12goto_list_20338, _12goto_list_20338, _28977);
    _28977 = NOVALUE;

    /** parser.e:2039				goto_line &= {{line_number,ThisLine}}*/
    Ref(_49ThisLine_49261);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _12line_number_20227;
    ((intptr_t *)_2)[2] = _49ThisLine_49261;
    _28979 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28979;
    _28980 = MAKE_SEQ(_1);
    _28979 = NOVALUE;
    Concat((object_ptr)&_43goto_line_54962, _43goto_line_54962, _28980);
    DeRefDS(_28980);
    _28980 = NOVALUE;

    /** parser.e:2040				goto_ref &= new_forward_reference( GOTO, top_block() )*/
    _28982 = _64top_block(0);
    _31710 = 188;
    _28983 = _42new_forward_reference(188, _28982, 188);
    _28982 = NOVALUE;
    _31710 = NOVALUE;
    if (IS_SEQUENCE(_43goto_ref_54966) && IS_ATOM(_28983)) {
        Ref(_28983);
        Append(&_43goto_ref_54966, _43goto_ref_54966, _28983);
    }
    else if (IS_ATOM(_43goto_ref_54966) && IS_SEQUENCE(_28983)) {
    }
    else {
        Concat((object_ptr)&_43goto_ref_54966, _43goto_ref_54966, _28983);
    }
    DeRef(_28983);
    _28983 = NOVALUE;

    /** parser.e:2041				map:put( goto_init, SymTab[tok[T_SYM]][S_OBJ], get_private_uninitialized() )*/
    _2 = (object)SEQ_PTR(_tok_57957);
    _28985 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28985)){
        _28986 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28985)->dbl));
    }
    else{
        _28986 = (object)*(((s1_ptr)_2)->base + _28985);
    }
    _2 = (object)SEQ_PTR(_28986);
    _28987 = (object)*(((s1_ptr)_2)->base + 1);
    _28986 = NOVALUE;
    _28988 = _43get_private_uninitialized();
    Ref(_43goto_init_54969);
    Ref(_28987);
    _34put(_43goto_init_54969, _28987, _28988, 1, 0);
    _28987 = NOVALUE;
    _28988 = NOVALUE;

    /** parser.e:2042				add_data( goto_ref[$], sym_obj( tok[T_SYM] ) )*/
    if (IS_SEQUENCE(_43goto_ref_54966)){
            _28989 = SEQ_PTR(_43goto_ref_54966)->length;
    }
    else {
        _28989 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_ref_54966);
    _28990 = (object)*(((s1_ptr)_2)->base + _28989);
    _2 = (object)SEQ_PTR(_tok_57957);
    _28991 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28991);
    _28992 = _53sym_obj(_28991);
    _28991 = NOVALUE;
    Ref(_28990);
    _42add_data(_28990, _28992);
    _28990 = NOVALUE;
    _28992 = NOVALUE;

    /** parser.e:2043				set_line( goto_ref[$], line_number, ThisLine, bp )*/
    if (IS_SEQUENCE(_43goto_ref_54966)){
            _28993 = SEQ_PTR(_43goto_ref_54966)->length;
    }
    else {
        _28993 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_ref_54966);
    _28994 = (object)*(((s1_ptr)_2)->base + _28993);
    Ref(_28994);
    Ref(_49ThisLine_49261);
    _42set_line(_28994, _12line_number_20227, _49ThisLine_49261, _49bp_49265);
    _28994 = NOVALUE;
    goto L3; // [238] 259
L2: 

    /** parser.e:2045				Goto_block( top_block(), label_block[n] )*/
    _28995 = _64top_block(0);
    _2 = (object)SEQ_PTR(_43label_block_54967);
    _28996 = (object)*(((s1_ptr)_2)->base + _n_57958);
    Ref(_28996);
    _64Goto_block(_28995, _28996, 0);
    _28995 = NOVALUE;
    _28996 = NOVALUE;
L3: 

    /** parser.e:2047			tok = next_token()*/
    _0 = _tok_57957;
    _tok_57957 = _43next_token();
    DeRef(_0);
    goto L4; // [264] 277
L1: 

    /** parser.e:2049			CompileErr(GOTO_STATEMENT_WITHOUT_A_STRING_LABEL)*/
    RefDS(_22015);
    _49CompileErr(96, _22015, 0);
L4: 

    /** parser.e:2052		emit_op(GOTO)*/
    _45emit_op(188);

    /** parser.e:2053		if n = 0 then*/
    if (_n_57958 != 0)
    goto L5; // [288] 300

    /** parser.e:2054			emit_addr(0) -- to be back-patched*/
    _45emit_addr(0);
    goto L6; // [297] 312
L5: 

    /** parser.e:2056			emit_addr(goto_addr[n])*/
    _2 = (object)SEQ_PTR(_43goto_addr_54964);
    _28999 = (object)*(((s1_ptr)_2)->base + _n_57958);
    Ref(_28999);
    _45emit_addr(_28999);
    _28999 = NOVALUE;
L6: 

    /** parser.e:2059		putback(tok)*/
    Ref(_tok_57957);
    _43putback(_tok_57957);

    /** parser.e:2060		NotReached(tok[T_ID], "goto")*/
    _2 = (object)SEQ_PTR(_tok_57957);
    _29000 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29000);
    RefDS(_26220);
    _43NotReached(_29000, _26220);
    _29000 = NOVALUE;

    /** parser.e:2061	end procedure*/
    DeRef(_tok_57957);
    _28971 = NOVALUE;
    _28985 = NOVALUE;
    _28966 = NOVALUE;
    return;
    ;
}


void _43Exit_statement()
{
    object _addr_inlined_AppendXList_at_65_58062 = NOVALUE;
    object _tok_58044 = NOVALUE;
    object _by_ref_58045 = NOVALUE;
    object _29008 = NOVALUE;
    object _29007 = NOVALUE;
    object _29006 = NOVALUE;
    object _29005 = NOVALUE;
    object _29003 = NOVALUE;
    object _29001 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2066		sequence by_ref*/

    /** parser.e:2068		if not length(loop_stack) then*/
    if (IS_SEQUENCE(_43loop_stack_54986)){
            _29001 = SEQ_PTR(_43loop_stack_54986)->length;
    }
    else {
        _29001 = 1;
    }
    if (_29001 != 0)
    goto L1; // [10] 23
    _29001 = NOVALUE;

    /** parser.e:2069			CompileErr(EXIT_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22015);
    _49CompileErr(88, _22015, 0);
L1: 

    /** parser.e:2072		by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29003 = _43next_token();
    _0 = _by_ref_58045;
    _by_ref_58045 = _43exit_level(_29003, 0);
    DeRef(_0);
    _29003 = NOVALUE;

    /** parser.e:2073		Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58045);
    _29005 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29005);
    _64Leave_blocks(_29005, 1);
    _29005 = NOVALUE;

    /** parser.e:2074		emit_op(EXIT)*/
    _45emit_op(61);

    /** parser.e:2075		AppendXList(length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29006 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29006 = 1;
    }
    _29007 = _29006 + 1;
    _29006 = NOVALUE;
    _addr_inlined_AppendXList_at_65_58062 = _29007;
    _29007 = NOVALUE;

    /** parser.e:398		exit_list = append(exit_list, addr)*/
    Append(&_43exit_list_54972, _43exit_list_54972, _addr_inlined_AppendXList_at_65_58062);

    /** parser.e:399	end procedure*/
    goto L2; // [80] 83
L2: 

    /** parser.e:2076		exit_delay &= by_ref[1]*/
    _2 = (object)SEQ_PTR(_by_ref_58045);
    _29008 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_43exit_delay_54973) && IS_ATOM(_29008)) {
        Ref(_29008);
        Append(&_43exit_delay_54973, _43exit_delay_54973, _29008);
    }
    else if (IS_ATOM(_43exit_delay_54973) && IS_SEQUENCE(_29008)) {
    }
    else {
        Concat((object_ptr)&_43exit_delay_54973, _43exit_delay_54973, _29008);
    }
    _29008 = NOVALUE;

    /** parser.e:2077		emit_forward_addr()    -- to be back-patched*/
    _43emit_forward_addr();

    /** parser.e:2078		tok = by_ref[2]*/
    DeRef(_tok_58044);
    _2 = (object)SEQ_PTR(_by_ref_58045);
    _tok_58044 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_58044);

    /** parser.e:2079		putback(tok)*/
    Ref(_tok_58044);
    _43putback(_tok_58044);

    /** parser.e:2080	end procedure*/
    DeRef(_tok_58044);
    DeRefDS(_by_ref_58045);
    return;
    ;
}


void _43Continue_statement()
{
    object _addr_inlined_AppendNList_at_153_58108 = NOVALUE;
    object _tok_58069 = NOVALUE;
    object _by_ref_58070 = NOVALUE;
    object _loop_level_58071 = NOVALUE;
    object _29034 = NOVALUE;
    object _29031 = NOVALUE;
    object _29030 = NOVALUE;
    object _29029 = NOVALUE;
    object _29028 = NOVALUE;
    object _29027 = NOVALUE;
    object _29026 = NOVALUE;
    object _29024 = NOVALUE;
    object _29023 = NOVALUE;
    object _29022 = NOVALUE;
    object _29021 = NOVALUE;
    object _29020 = NOVALUE;
    object _29019 = NOVALUE;
    object _29018 = NOVALUE;
    object _29017 = NOVALUE;
    object _29015 = NOVALUE;
    object _29013 = NOVALUE;
    object _29011 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2085		sequence by_ref*/

    /** parser.e:2086		integer loop_level*/

    /** parser.e:2088		if not length(loop_stack) then*/
    if (IS_SEQUENCE(_43loop_stack_54986)){
            _29011 = SEQ_PTR(_43loop_stack_54986)->length;
    }
    else {
        _29011 = 1;
    }
    if (_29011 != 0)
    goto L1; // [12] 25
    _29011 = NOVALUE;

    /** parser.e:2089			CompileErr(CONTINUE_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22015);
    _49CompileErr(49, _22015, 0);
L1: 

    /** parser.e:2092		by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29013 = _43next_token();
    _0 = _by_ref_58070;
    _by_ref_58070 = _43exit_level(_29013, 0);
    DeRef(_0);
    _29013 = NOVALUE;

    /** parser.e:2093		Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58070);
    _29015 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29015);
    _64Leave_blocks(_29015, 1);
    _29015 = NOVALUE;

    /** parser.e:2094		emit_op(ELSE)*/
    _45emit_op(23);

    /** parser.e:2095		loop_level = by_ref[1]*/
    _2 = (object)SEQ_PTR(_by_ref_58070);
    _loop_level_58071 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_loop_level_58071))
    _loop_level_58071 = (object)DBL_PTR(_loop_level_58071)->dbl;

    /** parser.e:2098		if continue_addr[$+1-loop_level] then -- address is known for while loops*/
    if (IS_SEQUENCE(_43continue_addr_54977)){
            _29017 = SEQ_PTR(_43continue_addr_54977)->length;
    }
    else {
        _29017 = 1;
    }
    _29018 = _29017 + 1;
    _29017 = NOVALUE;
    _29019 = _29018 - _loop_level_58071;
    _29018 = NOVALUE;
    _2 = (object)SEQ_PTR(_43continue_addr_54977);
    _29020 = (object)*(((s1_ptr)_2)->base + _29019);
    if (_29020 == 0)
    {
        _29020 = NOVALUE;
        goto L2; // [81] 142
    }
    else{
        _29020 = NOVALUE;
    }

    /** parser.e:2099			if continue_addr[$+1-loop_level] < 0 then*/
    if (IS_SEQUENCE(_43continue_addr_54977)){
            _29021 = SEQ_PTR(_43continue_addr_54977)->length;
    }
    else {
        _29021 = 1;
    }
    _29022 = _29021 + 1;
    _29021 = NOVALUE;
    _29023 = _29022 - _loop_level_58071;
    _29022 = NOVALUE;
    _2 = (object)SEQ_PTR(_43continue_addr_54977);
    _29024 = (object)*(((s1_ptr)_2)->base + _29023);
    if (_29024 >= 0)
    goto L3; // [103] 117

    /** parser.e:2101				CompileErr(CONTINUE_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22015);
    _49CompileErr(49, _22015, 0);
L3: 

    /** parser.e:2103			emit_addr(continue_addr[$+1-loop_level])*/
    if (IS_SEQUENCE(_43continue_addr_54977)){
            _29026 = SEQ_PTR(_43continue_addr_54977)->length;
    }
    else {
        _29026 = 1;
    }
    _29027 = _29026 + 1;
    _29026 = NOVALUE;
    _29028 = _29027 - _loop_level_58071;
    _29027 = NOVALUE;
    _2 = (object)SEQ_PTR(_43continue_addr_54977);
    _29029 = (object)*(((s1_ptr)_2)->base + _29028);
    _45emit_addr(_29029);
    _29029 = NOVALUE;
    goto L4; // [139] 186
L2: 

    /** parser.e:2105			AppendNList(length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29030 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29030 = 1;
    }
    _29031 = _29030 + 1;
    _29030 = NOVALUE;
    _addr_inlined_AppendNList_at_153_58108 = _29031;
    _29031 = NOVALUE;

    /** parser.e:403		continue_list = append(continue_list, addr)*/
    Append(&_43continue_list_54974, _43continue_list_54974, _addr_inlined_AppendNList_at_153_58108);

    /** parser.e:404	end procedure*/
    goto L5; // [168] 171
L5: 

    /** parser.e:2106			continue_delay &= loop_level*/
    Append(&_43continue_delay_54975, _43continue_delay_54975, _loop_level_58071);

    /** parser.e:2107			emit_forward_addr()    -- to be back-patched*/
    _43emit_forward_addr();
L4: 

    /** parser.e:2110		tok = by_ref[2]*/
    DeRef(_tok_58069);
    _2 = (object)SEQ_PTR(_by_ref_58070);
    _tok_58069 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_58069);

    /** parser.e:2111		putback(tok)*/
    Ref(_tok_58069);
    _43putback(_tok_58069);

    /** parser.e:2113		NotReached(tok[T_ID], "continue")*/
    _2 = (object)SEQ_PTR(_tok_58069);
    _29034 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29034);
    RefDS(_26182);
    _43NotReached(_29034, _26182);
    _29034 = NOVALUE;

    /** parser.e:2114	end procedure*/
    DeRef(_tok_58069);
    DeRefDS(_by_ref_58070);
    DeRef(_29023);
    _29023 = NOVALUE;
    _29024 = NOVALUE;
    DeRef(_29019);
    _29019 = NOVALUE;
    DeRef(_29028);
    _29028 = NOVALUE;
    return;
    ;
}


void _43Retry_statement()
{
    object _by_ref_58115 = NOVALUE;
    object _tok_58117 = NOVALUE;
    object _29058 = NOVALUE;
    object _29056 = NOVALUE;
    object _29055 = NOVALUE;
    object _29054 = NOVALUE;
    object _29053 = NOVALUE;
    object _29052 = NOVALUE;
    object _29050 = NOVALUE;
    object _29049 = NOVALUE;
    object _29048 = NOVALUE;
    object _29047 = NOVALUE;
    object _29046 = NOVALUE;
    object _29044 = NOVALUE;
    object _29043 = NOVALUE;
    object _29042 = NOVALUE;
    object _29041 = NOVALUE;
    object _29040 = NOVALUE;
    object _29039 = NOVALUE;
    object _29037 = NOVALUE;
    object _29035 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2122		if not length(loop_stack) then*/
    if (IS_SEQUENCE(_43loop_stack_54986)){
            _29035 = SEQ_PTR(_43loop_stack_54986)->length;
    }
    else {
        _29035 = 1;
    }
    if (_29035 != 0)
    goto L1; // [8] 21
    _29035 = NOVALUE;

    /** parser.e:2123			CompileErr(RETRY_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22015);
    _49CompileErr(131, _22015, 0);
L1: 

    /** parser.e:2126		by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29037 = _43next_token();
    _0 = _by_ref_58115;
    _by_ref_58115 = _43exit_level(_29037, 0);
    DeRef(_0);
    _29037 = NOVALUE;

    /** parser.e:2127		Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58115);
    _29039 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29039);
    _64Leave_blocks(_29039, 1);
    _29039 = NOVALUE;

    /** parser.e:2128		if loop_stack[$+1-by_ref[1]]=FOR then*/
    if (IS_SEQUENCE(_43loop_stack_54986)){
            _29040 = SEQ_PTR(_43loop_stack_54986)->length;
    }
    else {
        _29040 = 1;
    }
    _29041 = _29040 + 1;
    _29040 = NOVALUE;
    _2 = (object)SEQ_PTR(_by_ref_58115);
    _29042 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29042)) {
        _29043 = _29041 - _29042;
    }
    else {
        _29043 = binary_op(MINUS, _29041, _29042);
    }
    _29041 = NOVALUE;
    _29042 = NOVALUE;
    _2 = (object)SEQ_PTR(_43loop_stack_54986);
    if (!IS_ATOM_INT(_29043)){
        _29044 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29043)->dbl));
    }
    else{
        _29044 = (object)*(((s1_ptr)_2)->base + _29043);
    }
    if (_29044 != 21)
    goto L2; // [70] 84

    /** parser.e:2129			emit_op(RETRY) -- for Translator to emit a label at the right place*/
    _45emit_op(184);
    goto L3; // [81] 129
L2: 

    /** parser.e:2131			if retry_addr[$+1-by_ref[1]] < 0 then*/
    if (IS_SEQUENCE(_43retry_addr_54978)){
            _29046 = SEQ_PTR(_43retry_addr_54978)->length;
    }
    else {
        _29046 = 1;
    }
    _29047 = _29046 + 1;
    _29046 = NOVALUE;
    _2 = (object)SEQ_PTR(_by_ref_58115);
    _29048 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29048)) {
        _29049 = _29047 - _29048;
    }
    else {
        _29049 = binary_op(MINUS, _29047, _29048);
    }
    _29047 = NOVALUE;
    _29048 = NOVALUE;
    _2 = (object)SEQ_PTR(_43retry_addr_54978);
    if (!IS_ATOM_INT(_29049)){
        _29050 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29049)->dbl));
    }
    else{
        _29050 = (object)*(((s1_ptr)_2)->base + _29049);
    }
    if (_29050 >= 0)
    goto L4; // [107] 121

    /** parser.e:2133				CompileErr(RETRY_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22015);
    _49CompileErr(131, _22015, 0);
L4: 

    /** parser.e:2135			emit_op(ELSE)*/
    _45emit_op(23);
L3: 

    /** parser.e:2138		emit_addr(retry_addr[$+1-by_ref[1]])*/
    if (IS_SEQUENCE(_43retry_addr_54978)){
            _29052 = SEQ_PTR(_43retry_addr_54978)->length;
    }
    else {
        _29052 = 1;
    }
    _29053 = _29052 + 1;
    _29052 = NOVALUE;
    _2 = (object)SEQ_PTR(_by_ref_58115);
    _29054 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29054)) {
        _29055 = _29053 - _29054;
    }
    else {
        _29055 = binary_op(MINUS, _29053, _29054);
    }
    _29053 = NOVALUE;
    _29054 = NOVALUE;
    _2 = (object)SEQ_PTR(_43retry_addr_54978);
    if (!IS_ATOM_INT(_29055)){
        _29056 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29055)->dbl));
    }
    else{
        _29056 = (object)*(((s1_ptr)_2)->base + _29055);
    }
    _45emit_addr(_29056);
    _29056 = NOVALUE;

    /** parser.e:2139		tok = by_ref[2]*/
    DeRef(_tok_58117);
    _2 = (object)SEQ_PTR(_by_ref_58115);
    _tok_58117 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_58117);

    /** parser.e:2140		putback(tok)*/
    Ref(_tok_58117);
    _43putback(_tok_58117);

    /** parser.e:2141		NotReached(tok[T_ID], "retry")*/
    _2 = (object)SEQ_PTR(_tok_58117);
    _29058 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29058);
    RefDS(_26276);
    _43NotReached(_29058, _26276);
    _29058 = NOVALUE;

    /** parser.e:2142	end procedure*/
    DeRefDS(_by_ref_58115);
    DeRef(_tok_58117);
    DeRef(_29055);
    _29055 = NOVALUE;
    DeRef(_29049);
    _29049 = NOVALUE;
    DeRef(_29043);
    _29043 = NOVALUE;
    _29044 = NOVALUE;
    _29050 = NOVALUE;
    return;
    ;
}


object _43in_switch()
{
    object _29063 = NOVALUE;
    object _29062 = NOVALUE;
    object _29061 = NOVALUE;
    object _29060 = NOVALUE;
    object _29059 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2145		if length( if_stack ) and if_stack[$] = SWITCH then*/
    if (IS_SEQUENCE(_43if_stack_54987)){
            _29059 = SEQ_PTR(_43if_stack_54987)->length;
    }
    else {
        _29059 = 1;
    }
    if (_29059 == 0) {
        goto L1; // [8] 40
    }
    if (IS_SEQUENCE(_43if_stack_54987)){
            _29061 = SEQ_PTR(_43if_stack_54987)->length;
    }
    else {
        _29061 = 1;
    }
    _2 = (object)SEQ_PTR(_43if_stack_54987);
    _29062 = (object)*(((s1_ptr)_2)->base + _29061);
    _29063 = (_29062 == 185);
    _29062 = NOVALUE;
    if (_29063 == 0)
    {
        DeRef(_29063);
        _29063 = NOVALUE;
        goto L1; // [28] 40
    }
    else{
        DeRef(_29063);
        _29063 = NOVALUE;
    }

    /** parser.e:2146			return 1*/
    return 1;
    goto L2; // [37] 47
L1: 

    /** parser.e:2148			return 0*/
    return 0;
L2: 
    ;
}


void _43Break_statement()
{
    object _addr_inlined_AppendEList_at_65_58190 = NOVALUE;
    object _tok_58172 = NOVALUE;
    object _by_ref_58173 = NOVALUE;
    object _29074 = NOVALUE;
    object _29071 = NOVALUE;
    object _29070 = NOVALUE;
    object _29069 = NOVALUE;
    object _29068 = NOVALUE;
    object _29066 = NOVALUE;
    object _29064 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2154		sequence by_ref*/

    /** parser.e:2156		if not length(if_labels) then*/
    if (IS_SEQUENCE(_43if_labels_54981)){
            _29064 = SEQ_PTR(_43if_labels_54981)->length;
    }
    else {
        _29064 = 1;
    }
    if (_29064 != 0)
    goto L1; // [10] 23
    _29064 = NOVALUE;

    /** parser.e:2157			CompileErr(BREAK_STATEMENT_MUST_BE_INSIDE_A_IF_OR_A_SWITCH_BLOCK)*/
    RefDS(_22015);
    _49CompileErr(40, _22015, 0);
L1: 

    /** parser.e:2160		by_ref = exit_level(next_token(),1)*/
    _29066 = _43next_token();
    _0 = _by_ref_58173;
    _by_ref_58173 = _43exit_level(_29066, 1);
    DeRef(_0);
    _29066 = NOVALUE;

    /** parser.e:2161		Leave_blocks( by_ref[1], CONDITIONAL_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58173);
    _29068 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29068);
    _64Leave_blocks(_29068, 2);
    _29068 = NOVALUE;

    /** parser.e:2162		emit_op(ELSE)*/
    _45emit_op(23);

    /** parser.e:2163		AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29069 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29069 = 1;
    }
    _29070 = _29069 + 1;
    _29069 = NOVALUE;
    _addr_inlined_AppendEList_at_65_58190 = _29070;
    _29070 = NOVALUE;

    /** parser.e:393		break_list = append(break_list, addr)*/
    Append(&_43break_list_54970, _43break_list_54970, _addr_inlined_AppendEList_at_65_58190);

    /** parser.e:394	end procedure*/
    goto L2; // [80] 83
L2: 

    /** parser.e:2165		break_delay &= by_ref[1]*/
    _2 = (object)SEQ_PTR(_by_ref_58173);
    _29071 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_43break_delay_54971) && IS_ATOM(_29071)) {
        Ref(_29071);
        Append(&_43break_delay_54971, _43break_delay_54971, _29071);
    }
    else if (IS_ATOM(_43break_delay_54971) && IS_SEQUENCE(_29071)) {
    }
    else {
        Concat((object_ptr)&_43break_delay_54971, _43break_delay_54971, _29071);
    }
    _29071 = NOVALUE;

    /** parser.e:2166		emit_forward_addr()    -- to be back-patched*/
    _43emit_forward_addr();

    /** parser.e:2167		tok = by_ref[2]*/
    DeRef(_tok_58172);
    _2 = (object)SEQ_PTR(_by_ref_58173);
    _tok_58172 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_58172);

    /** parser.e:2168		putback(tok)*/
    Ref(_tok_58172);
    _43putback(_tok_58172);

    /** parser.e:2169		NotReached(tok[T_ID], "break")*/
    _2 = (object)SEQ_PTR(_tok_58172);
    _29074 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29074);
    RefDS(_26166);
    _43NotReached(_29074, _26166);
    _29074 = NOVALUE;

    /** parser.e:2170	end procedure*/
    DeRef(_tok_58172);
    DeRefDS(_by_ref_58173);
    return;
    ;
}


object _43finish_block_header(object _opcode_58199)
{
    object _tok_58201 = NOVALUE;
    object _labbel_58202 = NOVALUE;
    object _has_entry_58203 = NOVALUE;
    object _29128 = NOVALUE;
    object _29127 = NOVALUE;
    object _29126 = NOVALUE;
    object _29125 = NOVALUE;
    object _29122 = NOVALUE;
    object _29117 = NOVALUE;
    object _29114 = NOVALUE;
    object _29112 = NOVALUE;
    object _29109 = NOVALUE;
    object _29108 = NOVALUE;
    object _29106 = NOVALUE;
    object _29103 = NOVALUE;
    object _29100 = NOVALUE;
    object _29099 = NOVALUE;
    object _29097 = NOVALUE;
    object _29095 = NOVALUE;
    object _29092 = NOVALUE;
    object _29089 = NOVALUE;
    object _29088 = NOVALUE;
    object _29086 = NOVALUE;
    object _29084 = NOVALUE;
    object _29083 = NOVALUE;
    object _29082 = NOVALUE;
    object _29079 = NOVALUE;
    object _29076 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2176		object labbel*/

    /** parser.e:2177		integer has_entry*/

    /** parser.e:2179		tok = next_token()*/
    _0 = _tok_58201;
    _tok_58201 = _43next_token();
    DeRef(_0);

    /** parser.e:2180		has_entry=0*/
    _has_entry_58203 = 0;

    /** parser.e:2182		if tok[T_ID] = WITH then*/
    _2 = (object)SEQ_PTR(_tok_58201);
    _29076 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29076, 420)){
        _29076 = NOVALUE;
        goto L1; // [27] 160
    }
    _29076 = NOVALUE;

    /** parser.e:2183			tok = next_token()*/
    _0 = _tok_58201;
    _tok_58201 = _43next_token();
    DeRef(_0);

    /** parser.e:2184			switch tok[T_ID] do*/
    _2 = (object)SEQ_PTR(_tok_58201);
    _29079 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_29079) ){
        goto L2; // [44] 140
    }
    if(!IS_ATOM_INT(_29079)){
        if( (DBL_PTR(_29079)->dbl != (eudouble) ((object) DBL_PTR(_29079)->dbl) ) ){
            goto L2; // [44] 140
        }
        _0 = (object) DBL_PTR(_29079)->dbl;
    }
    else {
        _0 = _29079;
    };
    _29079 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:2185			    case ENTRY then*/
        case 424:

        /** parser.e:2186					if not (opcode = WHILE or opcode = LOOP) then*/
        _29082 = (_opcode_58199 == 47);
        if (_29082 != 0) {
            DeRef(_29083);
            _29083 = 1;
            goto L3; // [61] 75
        }
        _29084 = (_opcode_58199 == 422);
        _29083 = (_29084 != 0);
L3: 
        if (_29083 != 0)
        goto L4; // [75] 88
        _29083 = NOVALUE;

        /** parser.e:2187						CompileErr(MSG_WITH_ENTRY_IS_ONLY_VALID_ON_A_WHILE_OR_LOOP_STATEMENT)*/
        RefDS(_22015);
        _49CompileErr(14, _22015, 0);
L4: 

        /** parser.e:2190				    has_entry = 1*/
        _has_entry_58203 = 1;
        goto L5; // [93] 152

        /** parser.e:2192				case FALLTHRU then*/
        case 431:

        /** parser.e:2193					if not opcode = SWITCH then*/
        _29086 = (_opcode_58199 == 0);
        if (_29086 != 185)
        goto L6; // [106] 120

        /** parser.e:2194						CompileErr(MSG_WITH_FALLTHRU_IS_ONLY_VALID_IN_A_SWITCH_STATEMENT)*/
        RefDS(_22015);
        _49CompileErr(13, _22015, 0);
L6: 

        /** parser.e:2197					switch_stack[$][SWITCH_FALLTHRU] = 1*/
        if (IS_SEQUENCE(_43switch_stack_55201)){
                _29088 = SEQ_PTR(_43switch_stack_55201)->length;
        }
        else {
            _29088 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55201);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43switch_stack_55201 = MAKE_SEQ(_2);
        }
        _3 = (object)(_29088 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 1;
        DeRef(_1);
        _29089 = NOVALUE;
        goto L5; // [136] 152

        /** parser.e:2199				case else*/
        default:
L2: 

        /** parser.e:2200				    CompileErr(AN_UNKNOWN_WITHWITHOUT_OPTION_HAS_BEEN_SPECIFIED)*/
        RefDS(_22015);
        _49CompileErr(27, _22015, 0);
    ;}L5: 

    /** parser.e:2203	        tok = next_token()*/
    _0 = _tok_58201;
    _tok_58201 = _43next_token();
    DeRef(_0);
    goto L7; // [157] 250
L1: 

    /** parser.e:2204		elsif tok[T_ID] = WITHOUT then*/
    _2 = (object)SEQ_PTR(_tok_58201);
    _29092 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29092, 421)){
        _29092 = NOVALUE;
        goto L8; // [170] 249
    }
    _29092 = NOVALUE;

    /** parser.e:2205			tok = next_token()*/
    _0 = _tok_58201;
    _tok_58201 = _43next_token();
    DeRef(_0);

    /** parser.e:2206			if tok[T_ID] = FALLTHRU then*/
    _2 = (object)SEQ_PTR(_tok_58201);
    _29095 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29095, 431)){
        _29095 = NOVALUE;
        goto L9; // [189] 233
    }
    _29095 = NOVALUE;

    /** parser.e:2207				if not opcode = SWITCH then*/
    _29097 = (_opcode_58199 == 0);
    if (_29097 != 185)
    goto LA; // [200] 214

    /** parser.e:2208					CompileErr(MSG_WITHOUT_FALLTHRU_IS_ONLY_VALID_IN_A_SWITCH_STATEMENT)*/
    RefDS(_22015);
    _49CompileErr(15, _22015, 0);
LA: 

    /** parser.e:2211				switch_stack[$][SWITCH_FALLTHRU] = 0*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29099 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29099 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55201 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29099 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _29100 = NOVALUE;
    goto LB; // [230] 243
L9: 

    /** parser.e:2214				CompileErr(AN_UNKNOWN_WITHWITHOUT_OPTION_HAS_BEEN_SPECIFIED)*/
    RefDS(_22015);
    _49CompileErr(27, _22015, 0);
LB: 

    /** parser.e:2216	        tok = next_token()*/
    _0 = _tok_58201;
    _tok_58201 = _43next_token();
    DeRef(_0);
L8: 
L7: 

    /** parser.e:2219		labbel=0*/
    DeRef(_labbel_58202);
    _labbel_58202 = 0;

    /** parser.e:2220		if tok[T_ID]=LABEL then*/
    _2 = (object)SEQ_PTR(_tok_58201);
    _29103 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29103, 419)){
        _29103 = NOVALUE;
        goto LC; // [265] 329
    }
    _29103 = NOVALUE;

    /** parser.e:2221			tok = next_token()*/
    _0 = _tok_58201;
    _tok_58201 = _43next_token();
    DeRef(_0);

    /** parser.e:2222			if tok[T_ID] != STRING then*/
    _2 = (object)SEQ_PTR(_tok_58201);
    _29106 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29106, 503)){
        _29106 = NOVALUE;
        goto LD; // [284] 298
    }
    _29106 = NOVALUE;

    /** parser.e:2223				CompileErr(A_LABEL_CLAUSE_MUST_BE_FOLLOWED_BY_A_LITERAL_STRING)*/
    RefDS(_22015);
    _49CompileErr(38, _22015, 0);
LD: 

    /** parser.e:2225			labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_58201);
    _29108 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_29108)){
        _29109 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29108)->dbl));
    }
    else{
        _29109 = (object)*(((s1_ptr)_2)->base + _29108);
    }
    DeRef(_labbel_58202);
    _2 = (object)SEQ_PTR(_29109);
    _labbel_58202 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_labbel_58202);
    _29109 = NOVALUE;

    /** parser.e:2226			block_label( labbel )*/
    Ref(_labbel_58202);
    _64block_label(_labbel_58202);

    /** parser.e:2227			tok = next_token()*/
    _0 = _tok_58201;
    _tok_58201 = _43next_token();
    DeRef(_0);
LC: 

    /** parser.e:2229		if opcode = IF or opcode = SWITCH then*/
    _29112 = (_opcode_58199 == 20);
    if (_29112 != 0) {
        goto LE; // [337] 352
    }
    _29114 = (_opcode_58199 == 185);
    if (_29114 == 0)
    {
        DeRef(_29114);
        _29114 = NOVALUE;
        goto LF; // [348] 363
    }
    else{
        DeRef(_29114);
        _29114 = NOVALUE;
    }
LE: 

    /** parser.e:2230			if_labels = append(if_labels,labbel)*/
    Ref(_labbel_58202);
    Append(&_43if_labels_54981, _43if_labels_54981, _labbel_58202);
    goto L10; // [360] 372
LF: 

    /** parser.e:2232			loop_labels = append(loop_labels,labbel)*/
    Ref(_labbel_58202);
    Append(&_43loop_labels_54980, _43loop_labels_54980, _labbel_58202);
L10: 

    /** parser.e:2234		if block_index=length(block_list) then*/
    if (IS_SEQUENCE(_43block_list_54982)){
            _29117 = SEQ_PTR(_43block_list_54982)->length;
    }
    else {
        _29117 = 1;
    }
    if (_43block_index_54983 != _29117)
    goto L11; // [381] 404

    /** parser.e:2235		    block_list &= opcode*/
    Append(&_43block_list_54982, _43block_list_54982, _opcode_58199);

    /** parser.e:2236		    block_index += 1*/
    _43block_index_54983 = _43block_index_54983 + 1;
    goto L12; // [401] 423
L11: 

    /** parser.e:2238		    block_index += 1*/
    _43block_index_54983 = _43block_index_54983 + 1;

    /** parser.e:2239		    block_list[block_index] = opcode*/
    _2 = (object)SEQ_PTR(_43block_list_54982);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43block_list_54982 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _43block_index_54983);
    *(intptr_t *)_2 = _opcode_58199;
L12: 

    /** parser.e:2241		if tok[T_ID]=ENTRY then*/
    _2 = (object)SEQ_PTR(_tok_58201);
    _29122 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29122, 424)){
        _29122 = NOVALUE;
        goto L13; // [433] 463
    }
    _29122 = NOVALUE;

    /** parser.e:2242		    if has_entry then*/
    if (_has_entry_58203 == 0)
    {
        goto L14; // [439] 452
    }
    else{
    }

    /** parser.e:2243		        CompileErr(DUPLICATE_ENTRY_CLAUSE_IN_A_LOOP_HEADER)*/
    RefDS(_22015);
    _49CompileErr(64, _22015, 0);
L14: 

    /** parser.e:2245		    has_entry=1*/
    _has_entry_58203 = 1;

    /** parser.e:2246		    tok=next_token()*/
    _0 = _tok_58201;
    _tok_58201 = _43next_token();
    DeRef(_0);
L13: 

    /** parser.e:2248		if has_entry and (opcode = IF or opcode = SWITCH) then*/
    if (_has_entry_58203 == 0) {
        goto L15; // [465] 503
    }
    _29126 = (_opcode_58199 == 20);
    if (_29126 != 0) {
        DeRef(_29127);
        _29127 = 1;
        goto L16; // [475] 489
    }
    _29128 = (_opcode_58199 == 185);
    _29127 = (_29128 != 0);
L16: 
    if (_29127 == 0)
    {
        _29127 = NOVALUE;
        goto L15; // [490] 503
    }
    else{
        _29127 = NOVALUE;
    }

    /** parser.e:2249			CompileErr(ENTRY_KEYWORD_IS_NOT_SUPPORTED_INSIDE_AN_IF_OR_SWITCH_BLOCK_HEADER)*/
    RefDS(_22015);
    _49CompileErr(80, _22015, 0);
L15: 

    /** parser.e:2251		if opcode = IF then*/
    if (_opcode_58199 != 20)
    goto L17; // [507] 523

    /** parser.e:2252			opcode = THEN*/
    _opcode_58199 = 410;
    goto L18; // [520] 533
L17: 

    /** parser.e:2254			opcode = DO*/
    _opcode_58199 = 411;
L18: 

    /** parser.e:2256		putback(tok)*/
    Ref(_tok_58201);
    _43putback(_tok_58201);

    /** parser.e:2257		tok_match(opcode)*/
    _43tok_match(_opcode_58199, 0);

    /** parser.e:2258		return has_entry*/
    DeRef(_tok_58201);
    DeRef(_labbel_58202);
    DeRef(_29086);
    _29086 = NOVALUE;
    DeRef(_29126);
    _29126 = NOVALUE;
    _29108 = NOVALUE;
    DeRef(_29112);
    _29112 = NOVALUE;
    DeRef(_29082);
    _29082 = NOVALUE;
    DeRef(_29128);
    _29128 = NOVALUE;
    DeRef(_29097);
    _29097 = NOVALUE;
    DeRef(_29084);
    _29084 = NOVALUE;
    return _has_entry_58203;
    ;
}


void _43If_statement()
{
    object _addr_inlined_AppendEList_at_624_58457 = NOVALUE;
    object _addr_inlined_AppendEList_at_260_58386 = NOVALUE;
    object _tok_58329 = NOVALUE;
    object _prev_false_58330 = NOVALUE;
    object _prev_false2_58331 = NOVALUE;
    object _elist_base_58332 = NOVALUE;
    object _temps_58340 = NOVALUE;
    object _31709 = NOVALUE;
    object _29194 = NOVALUE;
    object _29193 = NOVALUE;
    object _29190 = NOVALUE;
    object _29189 = NOVALUE;
    object _29187 = NOVALUE;
    object _29186 = NOVALUE;
    object _29185 = NOVALUE;
    object _29183 = NOVALUE;
    object _29182 = NOVALUE;
    object _29180 = NOVALUE;
    object _29179 = NOVALUE;
    object _29178 = NOVALUE;
    object _29176 = NOVALUE;
    object _29175 = NOVALUE;
    object _29173 = NOVALUE;
    object _29172 = NOVALUE;
    object _29171 = NOVALUE;
    object _29170 = NOVALUE;
    object _29168 = NOVALUE;
    object _29167 = NOVALUE;
    object _29164 = NOVALUE;
    object _29162 = NOVALUE;
    object _29161 = NOVALUE;
    object _29160 = NOVALUE;
    object _29157 = NOVALUE;
    object _29154 = NOVALUE;
    object _29153 = NOVALUE;
    object _29151 = NOVALUE;
    object _29150 = NOVALUE;
    object _29148 = NOVALUE;
    object _29147 = NOVALUE;
    object _29145 = NOVALUE;
    object _29142 = NOVALUE;
    object _29140 = NOVALUE;
    object _29139 = NOVALUE;
    object _29138 = NOVALUE;
    object _29134 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2265		integer prev_false*/

    /** parser.e:2266		integer prev_false2*/

    /** parser.e:2267		integer elist_base*/

    /** parser.e:2269		if_stack &= IF*/
    Append(&_43if_stack_54987, _43if_stack_54987, 20);

    /** parser.e:2271		Start_block( IF )*/
    _64Start_block(20, 0);

    /** parser.e:2273		elist_base = length(break_list)*/
    if (IS_SEQUENCE(_43break_list_54970)){
            _elist_base_58332 = SEQ_PTR(_43break_list_54970)->length;
    }
    else {
        _elist_base_58332 = 1;
    }

    /** parser.e:2274		short_circuit += 1*/
    _43short_circuit_54952 = _43short_circuit_54952 + 1;

    /** parser.e:2275		short_circuit_B = FALSE*/
    _43short_circuit_B_54954 = _9FALSE_444;

    /** parser.e:2276		SC1_type = 0*/
    _43SC1_type_54957 = 0;

    /** parser.e:2277		Expr()*/
    _43Expr();

    /** parser.e:2279		sequence temps = get_temps()*/
    _31709 = Repeat(_22015, 2);
    _0 = _temps_58340;
    _temps_58340 = _45get_temps(_31709);
    DeRef(_0);
    _31709 = NOVALUE;

    /** parser.e:2281		emit_op(IF)*/
    _45emit_op(20);

    /** parser.e:2282		prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29134 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29134 = 1;
    }
    _prev_false_58330 = _29134 + 1;
    _29134 = NOVALUE;

    /** parser.e:2283		emit_forward_addr() -- to be patched*/
    _43emit_forward_addr();

    /** parser.e:2284		prev_false2=finish_block_header(IF)  -- 0*/
    _prev_false2_58331 = _43finish_block_header(20);
    if (!IS_ATOM_INT(_prev_false2_58331)) {
        _1 = (object)(DBL_PTR(_prev_false2_58331)->dbl);
        DeRefDS(_prev_false2_58331);
        _prev_false2_58331 = _1;
    }

    /** parser.e:2285		if SC1_type = OR then*/
    if (_43SC1_type_54957 != 9)
    goto L1; // [106] 159

    /** parser.e:2286			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29138 = _43SC1_patch_54956 - 3;
    if ((object)((uintptr_t)_29138 +(uintptr_t) HIGH_BITS) >= 0){
        _29138 = NewDouble((eudouble)_29138);
    }
    _45backpatch(_29138, 147);
    _29138 = NOVALUE;

    /** parser.e:2287			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L2; // [128] 139
    }
    else{
    }

    /** parser.e:2288				emit_op(NOP1)  -- to get label here*/
    _45emit_op(159);
L2: 

    /** parser.e:2290			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29139 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29139 = 1;
    }
    _29140 = _29139 + 1;
    _29139 = NOVALUE;
    _45backpatch(_43SC1_patch_54956, _29140);
    _29140 = NOVALUE;
    goto L3; // [156] 192
L1: 

    /** parser.e:2291		elsif SC1_type = AND then*/
    if (_43SC1_type_54957 != 8)
    goto L4; // [165] 191

    /** parser.e:2292			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29142 = _43SC1_patch_54956 - 3;
    if ((object)((uintptr_t)_29142 +(uintptr_t) HIGH_BITS) >= 0){
        _29142 = NewDouble((eudouble)_29142);
    }
    _45backpatch(_29142, 146);
    _29142 = NOVALUE;

    /** parser.e:2293			prev_false2 = SC1_patch*/
    _prev_false2_58331 = _43SC1_patch_54956;
L4: 
L3: 

    /** parser.e:2295		short_circuit -= 1*/
    _43short_circuit_54952 = _43short_circuit_54952 - 1;

    /** parser.e:2298		Statement_list()*/
    _43Statement_list();

    /** parser.e:2299		tok = next_token()*/
    _0 = _tok_58329;
    _tok_58329 = _43next_token();
    DeRef(_0);

    /** parser.e:2301		while tok[T_ID] = ELSIF do*/
L5: 
    _2 = (object)SEQ_PTR(_tok_58329);
    _29145 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29145, 414)){
        _29145 = NOVALUE;
        goto L6; // [222] 530
    }
    _29145 = NOVALUE;

    /** parser.e:2302			Sibling_block( IF )*/
    _64Sibling_block(20);

    /** parser.e:2305			emit_op(ELSE)*/
    _45emit_op(23);

    /** parser.e:2306			AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29147 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29147 = 1;
    }
    _29148 = _29147 + 1;
    _29147 = NOVALUE;
    _addr_inlined_AppendEList_at_260_58386 = _29148;
    _29148 = NOVALUE;

    /** parser.e:393		break_list = append(break_list, addr)*/
    Append(&_43break_list_54970, _43break_list_54970, _addr_inlined_AppendEList_at_260_58386);

    /** parser.e:394	end procedure*/
    goto L7; // [266] 269
L7: 

    /** parser.e:2307			break_delay &= 1*/
    Append(&_43break_delay_54971, _43break_delay_54971, 1);

    /** parser.e:2308			emit_forward_addr()  -- to be patched*/
    _43emit_forward_addr();

    /** parser.e:2309			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L8; // [287] 298
    }
    else{
    }

    /** parser.e:2310				emit_op(NOP1)*/
    _45emit_op(159);
L8: 

    /** parser.e:2312			backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29150 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29150 = 1;
    }
    _29151 = _29150 + 1;
    _29150 = NOVALUE;
    _45backpatch(_prev_false_58330, _29151);
    _29151 = NOVALUE;

    /** parser.e:2313			if prev_false2 != 0 then*/
    if (_prev_false2_58331 == 0)
    goto L9; // [315] 335

    /** parser.e:2314				backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29153 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29153 = 1;
    }
    _29154 = _29153 + 1;
    _29153 = NOVALUE;
    _45backpatch(_prev_false2_58331, _29154);
    _29154 = NOVALUE;
L9: 

    /** parser.e:2317			StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:2318			short_circuit += 1*/
    _43short_circuit_54952 = _43short_circuit_54952 + 1;

    /** parser.e:2319			short_circuit_B = FALSE*/
    _43short_circuit_B_54954 = _9FALSE_444;

    /** parser.e:2320			SC1_type = 0*/
    _43SC1_type_54957 = 0;

    /** parser.e:2322			push_temps( temps )*/
    RefDS(_temps_58340);
    _45push_temps(_temps_58340);

    /** parser.e:2323			Expr()*/
    _43Expr();

    /** parser.e:2325			temps = get_temps( temps )*/
    RefDS(_temps_58340);
    _0 = _temps_58340;
    _temps_58340 = _45get_temps(_temps_58340);
    DeRefDS(_0);

    /** parser.e:2327			emit_op(IF)*/
    _45emit_op(20);

    /** parser.e:2328			prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29157 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29157 = 1;
    }
    _prev_false_58330 = _29157 + 1;
    _29157 = NOVALUE;

    /** parser.e:2329			prev_false2 = 0*/
    _prev_false2_58331 = 0;

    /** parser.e:2330			emit_forward_addr() -- to be patched*/
    _43emit_forward_addr();

    /** parser.e:2331			if SC1_type = OR then*/
    if (_43SC1_type_54957 != 9)
    goto LA; // [414] 467

    /** parser.e:2332				backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29160 = _43SC1_patch_54956 - 3;
    if ((object)((uintptr_t)_29160 +(uintptr_t) HIGH_BITS) >= 0){
        _29160 = NewDouble((eudouble)_29160);
    }
    _45backpatch(_29160, 147);
    _29160 = NOVALUE;

    /** parser.e:2333				if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto LB; // [436] 447
    }
    else{
    }

    /** parser.e:2334					emit_op(NOP1)*/
    _45emit_op(159);
LB: 

    /** parser.e:2336				backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29161 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29161 = 1;
    }
    _29162 = _29161 + 1;
    _29161 = NOVALUE;
    _45backpatch(_43SC1_patch_54956, _29162);
    _29162 = NOVALUE;
    goto LC; // [464] 500
LA: 

    /** parser.e:2337			elsif SC1_type = AND then*/
    if (_43SC1_type_54957 != 8)
    goto LD; // [473] 499

    /** parser.e:2338				backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29164 = _43SC1_patch_54956 - 3;
    if ((object)((uintptr_t)_29164 +(uintptr_t) HIGH_BITS) >= 0){
        _29164 = NewDouble((eudouble)_29164);
    }
    _45backpatch(_29164, 146);
    _29164 = NOVALUE;

    /** parser.e:2339				prev_false2 = SC1_patch*/
    _prev_false2_58331 = _43SC1_patch_54956;
LD: 
LC: 

    /** parser.e:2341			short_circuit -= 1*/
    _43short_circuit_54952 = _43short_circuit_54952 - 1;

    /** parser.e:2342			tok_match(THEN)*/
    _43tok_match(410, 0);

    /** parser.e:2345			Statement_list()*/
    _43Statement_list();

    /** parser.e:2346			tok = next_token()*/
    _0 = _tok_58329;
    _tok_58329 = _43next_token();
    DeRef(_0);

    /** parser.e:2347		end while*/
    goto L5; // [527] 214
L6: 

    /** parser.e:2349		if tok[T_ID] = ELSE or length(temps[1]) then*/
    _2 = (object)SEQ_PTR(_tok_58329);
    _29167 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29167)) {
        _29168 = (_29167 == 23);
    }
    else {
        _29168 = binary_op(EQUALS, _29167, 23);
    }
    _29167 = NOVALUE;
    if (IS_ATOM_INT(_29168)) {
        if (_29168 != 0) {
            goto LE; // [544] 560
        }
    }
    else {
        if (DBL_PTR(_29168)->dbl != 0.0) {
            goto LE; // [544] 560
        }
    }
    _2 = (object)SEQ_PTR(_temps_58340);
    _29170 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_29170)){
            _29171 = SEQ_PTR(_29170)->length;
    }
    else {
        _29171 = 1;
    }
    _29170 = NOVALUE;
    if (_29171 == 0)
    {
        _29171 = NOVALUE;
        goto LF; // [556] 715
    }
    else{
        _29171 = NOVALUE;
    }
LE: 

    /** parser.e:2354			Sibling_block( IF )*/
    _64Sibling_block(20);

    /** parser.e:2356			StartSourceLine(FALSE, , COVERAGE_SUPPRESS )*/
    _45StartSourceLine(_9FALSE_444, 0, 1);

    /** parser.e:2357			emit_op(ELSE)*/
    _45emit_op(23);

    /** parser.e:2358			AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29172 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29172 = 1;
    }
    _29173 = _29172 + 1;
    _29172 = NOVALUE;
    _addr_inlined_AppendEList_at_624_58457 = _29173;
    _29173 = NOVALUE;

    /** parser.e:393		break_list = append(break_list, addr)*/
    Append(&_43break_list_54970, _43break_list_54970, _addr_inlined_AppendEList_at_624_58457);

    /** parser.e:394	end procedure*/
    goto L10; // [611] 614
L10: 

    /** parser.e:2359			break_delay &= 1*/
    Append(&_43break_delay_54971, _43break_delay_54971, 1);

    /** parser.e:2360			emit_forward_addr() -- to be patched*/
    _43emit_forward_addr();

    /** parser.e:2361			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L11; // [632] 643
    }
    else{
    }

    /** parser.e:2362				emit_op(NOP1)*/
    _45emit_op(159);
L11: 

    /** parser.e:2364			backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29175 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29175 = 1;
    }
    _29176 = _29175 + 1;
    _29175 = NOVALUE;
    _45backpatch(_prev_false_58330, _29176);
    _29176 = NOVALUE;

    /** parser.e:2365			if prev_false2 != 0 then*/
    if (_prev_false2_58331 == 0)
    goto L12; // [660] 680

    /** parser.e:2366				backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29178 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29178 = 1;
    }
    _29179 = _29178 + 1;
    _29178 = NOVALUE;
    _45backpatch(_prev_false2_58331, _29179);
    _29179 = NOVALUE;
L12: 

    /** parser.e:2369			push_temps( temps )*/
    RefDS(_temps_58340);
    _45push_temps(_temps_58340);

    /** parser.e:2371			if tok[T_ID] = ELSE then*/
    _2 = (object)SEQ_PTR(_tok_58329);
    _29180 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29180, 23)){
        _29180 = NOVALUE;
        goto L13; // [695] 706
    }
    _29180 = NOVALUE;

    /** parser.e:2372				Statement_list()*/
    _43Statement_list();
    goto L14; // [703] 773
L13: 

    /** parser.e:2374				putback(tok)*/
    Ref(_tok_58329);
    _43putback(_tok_58329);
    goto L14; // [712] 773
LF: 

    /** parser.e:2377			putback(tok)*/
    Ref(_tok_58329);
    _43putback(_tok_58329);

    /** parser.e:2378			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L15; // [724] 735
    }
    else{
    }

    /** parser.e:2379				emit_op(NOP1)*/
    _45emit_op(159);
L15: 

    /** parser.e:2381			backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29182 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29182 = 1;
    }
    _29183 = _29182 + 1;
    _29182 = NOVALUE;
    _45backpatch(_prev_false_58330, _29183);
    _29183 = NOVALUE;

    /** parser.e:2382			if prev_false2 != 0 then*/
    if (_prev_false2_58331 == 0)
    goto L16; // [752] 772

    /** parser.e:2383				backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29185 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29185 = 1;
    }
    _29186 = _29185 + 1;
    _29185 = NOVALUE;
    _45backpatch(_prev_false2_58331, _29186);
    _29186 = NOVALUE;
L16: 
L14: 

    /** parser.e:2387		tok_match(END)*/
    _43tok_match(402, 0);

    /** parser.e:2388		tok_match(IF, END)*/
    _43tok_match(20, 402);

    /** parser.e:2390		End_block( IF )*/
    _64End_block(20);

    /** parser.e:2392		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L17; // [802] 825
    }
    else{
    }

    /** parser.e:2393			if length(break_list) > elist_base then*/
    if (IS_SEQUENCE(_43break_list_54970)){
            _29187 = SEQ_PTR(_43break_list_54970)->length;
    }
    else {
        _29187 = 1;
    }
    if (_29187 <= _elist_base_58332)
    goto L18; // [812] 824

    /** parser.e:2394				emit_op(NOP1)  -- to emit label here*/
    _45emit_op(159);
L18: 
L17: 

    /** parser.e:2397		PatchEList(elist_base)*/
    _43PatchEList(_elist_base_58332);

    /** parser.e:2398		if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_43if_labels_54981)){
            _29189 = SEQ_PTR(_43if_labels_54981)->length;
    }
    else {
        _29189 = 1;
    }
    _29190 = _29189 - 1;
    _29189 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43if_labels_54981;
    RHS_Slice(_43if_labels_54981, 1, _29190);

    /** parser.e:2399		block_index -= 1*/
    _43block_index_54983 = _43block_index_54983 - 1;

    /** parser.e:2400		if_stack = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_43if_stack_54987)){
            _29193 = SEQ_PTR(_43if_stack_54987)->length;
    }
    else {
        _29193 = 1;
    }
    _29194 = _29193 - 1;
    _29193 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43if_stack_54987;
    RHS_Slice(_43if_stack_54987, 1, _29194);

    /** parser.e:2402	end procedure*/
    DeRef(_tok_58329);
    DeRef(_temps_58340);
    _29194 = NOVALUE;
    _29170 = NOVALUE;
    DeRef(_29168);
    _29168 = NOVALUE;
    _29190 = NOVALUE;
    return;
    ;
}


void _43exit_loop(object _exit_base_58517)
{
    object _29209 = NOVALUE;
    object _29208 = NOVALUE;
    object _29206 = NOVALUE;
    object _29205 = NOVALUE;
    object _29203 = NOVALUE;
    object _29202 = NOVALUE;
    object _29200 = NOVALUE;
    object _29199 = NOVALUE;
    object _29197 = NOVALUE;
    object _29196 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2405		PatchXList(exit_base)*/
    _43PatchXList(_exit_base_58517);

    /** parser.e:2406		loop_labels = loop_labels[1..$-1]*/
    if (IS_SEQUENCE(_43loop_labels_54980)){
            _29196 = SEQ_PTR(_43loop_labels_54980)->length;
    }
    else {
        _29196 = 1;
    }
    _29197 = _29196 - 1;
    _29196 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43loop_labels_54980;
    RHS_Slice(_43loop_labels_54980, 1, _29197);

    /** parser.e:2407		loop_stack = loop_stack[1..$-1]*/
    if (IS_SEQUENCE(_43loop_stack_54986)){
            _29199 = SEQ_PTR(_43loop_stack_54986)->length;
    }
    else {
        _29199 = 1;
    }
    _29200 = _29199 - 1;
    _29199 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43loop_stack_54986;
    RHS_Slice(_43loop_stack_54986, 1, _29200);

    /** parser.e:2408		continue_addr = continue_addr[1..$-1]*/
    if (IS_SEQUENCE(_43continue_addr_54977)){
            _29202 = SEQ_PTR(_43continue_addr_54977)->length;
    }
    else {
        _29202 = 1;
    }
    _29203 = _29202 - 1;
    _29202 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43continue_addr_54977;
    RHS_Slice(_43continue_addr_54977, 1, _29203);

    /** parser.e:2409		retry_addr = retry_addr[1..$-1]*/
    if (IS_SEQUENCE(_43retry_addr_54978)){
            _29205 = SEQ_PTR(_43retry_addr_54978)->length;
    }
    else {
        _29205 = 1;
    }
    _29206 = _29205 - 1;
    _29205 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43retry_addr_54978;
    RHS_Slice(_43retry_addr_54978, 1, _29206);

    /** parser.e:2410		entry_addr = entry_addr[1..$-1]*/
    if (IS_SEQUENCE(_43entry_addr_54976)){
            _29208 = SEQ_PTR(_43entry_addr_54976)->length;
    }
    else {
        _29208 = 1;
    }
    _29209 = _29208 - 1;
    _29208 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43entry_addr_54976;
    RHS_Slice(_43entry_addr_54976, 1, _29209);

    /** parser.e:2411		block_index -= 1*/
    _43block_index_54983 = _43block_index_54983 - 1;

    /** parser.e:2412	end procedure*/
    _29206 = NOVALUE;
    _29209 = NOVALUE;
    _29203 = NOVALUE;
    _29200 = NOVALUE;
    _29197 = NOVALUE;
    return;
    ;
}


void _43push_switch()
{
    object _new_1__tmp_at14_58540 = NOVALUE;
    object _new_inlined_new_at_14_58539 = NOVALUE;
    object _29213 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2415		if_stack &= SWITCH*/
    Append(&_43if_stack_54987, _43if_stack_54987, 185);

    /** parser.e:2416		switch_stack = append( switch_stack,*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at14_58540;
    _new_1__tmp_at14_58540 = _34new_map_seq(8);
    DeRef(_0);
    Ref(_new_1__tmp_at14_58540);
    _0 = _new_inlined_new_at_14_58539;
    _new_inlined_new_at_14_58539 = _35malloc(_new_1__tmp_at14_58540, 1);
    DeRef(_0);
    DeRef(_new_1__tmp_at14_58540);
    _new_1__tmp_at14_58540 = NOVALUE;
    _1 = NewS1(13);
    _2 = (object)((s1_ptr)_1)->base;
    RefDSn(_22015, 2);
    ((intptr_t*)_2)[1] = _22015;
    ((intptr_t*)_2)[2] = _22015;
    ((intptr_t*)_2)[3] = 0;
    ((intptr_t*)_2)[4] = 0;
    ((intptr_t*)_2)[5] = 0;
    ((intptr_t*)_2)[6] = 0;
    Ref(_new_inlined_new_at_14_58539);
    ((intptr_t*)_2)[7] = _new_inlined_new_at_14_58539;
    RefDS(_22015);
    ((intptr_t*)_2)[8] = _22015;
    ((intptr_t*)_2)[9] = 0;
    RefDSn(_22015, 4);
    ((intptr_t*)_2)[10] = _22015;
    ((intptr_t*)_2)[11] = _22015;
    ((intptr_t*)_2)[12] = _22015;
    ((intptr_t*)_2)[13] = _22015;
    _29213 = MAKE_SEQ(_1);
    RefDS(_29213);
    Append(&_43switch_stack_55201, _43switch_stack_55201, _29213);
    DeRefDS(_29213);
    _29213 = NOVALUE;

    /** parser.e:2433	end procedure*/
    return;
    ;
}


void _43pop_switch(object _break_base_58545)
{
    object _29228 = NOVALUE;
    object _29227 = NOVALUE;
    object _29225 = NOVALUE;
    object _29224 = NOVALUE;
    object _29222 = NOVALUE;
    object _29221 = NOVALUE;
    object _29219 = NOVALUE;
    object _29218 = NOVALUE;
    object _29217 = NOVALUE;
    object _29216 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2438		PatchEList( break_base )*/
    _43PatchEList(_break_base_58545);

    /** parser.e:2439		block_index -= 1*/
    _43block_index_54983 = _43block_index_54983 - 1;

    /** parser.e:2440		if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29216 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29216 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _29217 = (object)*(((s1_ptr)_2)->base + _29216);
    _2 = (object)SEQ_PTR(_29217);
    _29218 = (object)*(((s1_ptr)_2)->base + 1);
    _29217 = NOVALUE;
    if (IS_SEQUENCE(_29218)){
            _29219 = SEQ_PTR(_29218)->length;
    }
    else {
        _29219 = 1;
    }
    _29218 = NOVALUE;
    if (_29219 <= 0)
    goto L1; // [34] 46

    /** parser.e:2441			End_block( CASE )*/
    _64End_block(186);
L1: 

    /** parser.e:2443		if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_43if_labels_54981)){
            _29221 = SEQ_PTR(_43if_labels_54981)->length;
    }
    else {
        _29221 = 1;
    }
    _29222 = _29221 - 1;
    _29221 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43if_labels_54981;
    RHS_Slice(_43if_labels_54981, 1, _29222);

    /** parser.e:2444		if_stack  = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_43if_stack_54987)){
            _29224 = SEQ_PTR(_43if_stack_54987)->length;
    }
    else {
        _29224 = 1;
    }
    _29225 = _29224 - 1;
    _29224 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43if_stack_54987;
    RHS_Slice(_43if_stack_54987, 1, _29225);

    /** parser.e:2445		switch_stack  = switch_stack[1..$-1]*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29227 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29227 = 1;
    }
    _29228 = _29227 - 1;
    _29227 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43switch_stack_55201;
    RHS_Slice(_43switch_stack_55201, 1, _29228);

    /** parser.e:2446	end procedure*/
    _29225 = NOVALUE;
    _29218 = NOVALUE;
    _29228 = NOVALUE;
    _29222 = NOVALUE;
    return;
    ;
}


void _43add_case(object _sym_58566, object _sign_58567)
{
    object _29275 = NOVALUE;
    object _29274 = NOVALUE;
    object _29273 = NOVALUE;
    object _29272 = NOVALUE;
    object _29271 = NOVALUE;
    object _29270 = NOVALUE;
    object _29268 = NOVALUE;
    object _29267 = NOVALUE;
    object _29266 = NOVALUE;
    object _29265 = NOVALUE;
    object _29263 = NOVALUE;
    object _29262 = NOVALUE;
    object _29261 = NOVALUE;
    object _29260 = NOVALUE;
    object _29258 = NOVALUE;
    object _29257 = NOVALUE;
    object _29256 = NOVALUE;
    object _29255 = NOVALUE;
    object _29254 = NOVALUE;
    object _29252 = NOVALUE;
    object _29251 = NOVALUE;
    object _29250 = NOVALUE;
    object _29249 = NOVALUE;
    object _29248 = NOVALUE;
    object _29247 = NOVALUE;
    object _29245 = NOVALUE;
    object _29244 = NOVALUE;
    object _29243 = NOVALUE;
    object _29242 = NOVALUE;
    object _29241 = NOVALUE;
    object _29240 = NOVALUE;
    object _29238 = NOVALUE;
    object _29237 = NOVALUE;
    object _29235 = NOVALUE;
    object _29234 = NOVALUE;
    object _29233 = NOVALUE;
    object _29232 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2450		if sign < 0 then*/
    if (_sign_58567 >= 0)
    goto L1; // [5] 15

    /** parser.e:2451			sym = -sym*/
    _0 = _sym_58566;
    if (IS_ATOM_INT(_sym_58566)) {
        if ((uintptr_t)_sym_58566 == (uintptr_t)HIGH_BITS){
            _sym_58566 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _sym_58566 = - _sym_58566;
        }
    }
    else {
        _sym_58566 = unary_op(UMINUS, _sym_58566);
    }
    DeRefi(_0);
L1: 

    /** parser.e:2454		if find(sym, switch_stack[$][SWITCH_CASES] ) = 0 then*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29232 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29232 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _29233 = (object)*(((s1_ptr)_2)->base + _29232);
    _2 = (object)SEQ_PTR(_29233);
    _29234 = (object)*(((s1_ptr)_2)->base + 1);
    _29233 = NOVALUE;
    _29235 = find_from(_sym_58566, _29234, 1);
    _29234 = NOVALUE;
    if (_29235 != 0)
    goto L2; // [35] 252

    /** parser.e:2455			switch_stack[$][SWITCH_CASES]            = append( switch_stack[$][SWITCH_CASES], sym )*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29237 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29237 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55201 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29237 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29240 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29240 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _29241 = (object)*(((s1_ptr)_2)->base + _29240);
    _2 = (object)SEQ_PTR(_29241);
    _29242 = (object)*(((s1_ptr)_2)->base + 1);
    _29241 = NOVALUE;
    Ref(_sym_58566);
    Append(&_29243, _29242, _sym_58566);
    _29242 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29243;
    if( _1 != _29243 ){
        DeRef(_1);
    }
    _29243 = NOVALUE;
    _29238 = NOVALUE;

    /** parser.e:2456			switch_stack[$][SWITCH_JUMP_TABLE]      &= length(Code) + 1*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29244 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29244 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55201 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29244 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_12Code_20315)){
            _29247 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29247 = 1;
    }
    _29248 = _29247 + 1;
    _29247 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29249 = (object)*(((s1_ptr)_2)->base + 2);
    _29245 = NOVALUE;
    if (IS_SEQUENCE(_29249) && IS_ATOM(_29248)) {
        Append(&_29250, _29249, _29248);
    }
    else if (IS_ATOM(_29249) && IS_SEQUENCE(_29248)) {
    }
    else {
        Concat((object_ptr)&_29250, _29249, _29248);
        _29249 = NOVALUE;
    }
    _29249 = NOVALUE;
    _29248 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29250;
    if( _1 != _29250 ){
        DeRef(_1);
    }
    _29250 = NOVALUE;
    _29245 = NOVALUE;

    /** parser.e:2457			switch_stack[$][SWITCH_THISLINE]        &= {ThisLine}*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29251 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29251 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55201 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29251 + ((s1_ptr)_2)->base);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_49ThisLine_49261);
    ((intptr_t*)_2)[1] = _49ThisLine_49261;
    _29254 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29255 = (object)*(((s1_ptr)_2)->base + 10);
    _29252 = NOVALUE;
    if (IS_SEQUENCE(_29255) && IS_ATOM(_29254)) {
    }
    else if (IS_ATOM(_29255) && IS_SEQUENCE(_29254)) {
        Ref(_29255);
        Prepend(&_29256, _29254, _29255);
    }
    else {
        Concat((object_ptr)&_29256, _29255, _29254);
        _29255 = NOVALUE;
    }
    _29255 = NOVALUE;
    DeRefDS(_29254);
    _29254 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29256;
    if( _1 != _29256 ){
        DeRef(_1);
    }
    _29256 = NOVALUE;
    _29252 = NOVALUE;

    /** parser.e:2458			switch_stack[$][SWITCH_BP]              &= bp*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29257 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29257 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55201 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29257 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29260 = (object)*(((s1_ptr)_2)->base + 11);
    _29258 = NOVALUE;
    if (IS_SEQUENCE(_29260) && IS_ATOM(_49bp_49265)) {
        Append(&_29261, _29260, _49bp_49265);
    }
    else if (IS_ATOM(_29260) && IS_SEQUENCE(_49bp_49265)) {
    }
    else {
        Concat((object_ptr)&_29261, _29260, _49bp_49265);
        _29260 = NOVALUE;
    }
    _29260 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29261;
    if( _1 != _29261 ){
        DeRef(_1);
    }
    _29261 = NOVALUE;
    _29258 = NOVALUE;

    /** parser.e:2459			switch_stack[$][SWITCH_LINE_NUMBER]     &= line_number*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29262 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29262 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55201 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29262 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29265 = (object)*(((s1_ptr)_2)->base + 12);
    _29263 = NOVALUE;
    if (IS_SEQUENCE(_29265) && IS_ATOM(_12line_number_20227)) {
        Append(&_29266, _29265, _12line_number_20227);
    }
    else if (IS_ATOM(_29265) && IS_SEQUENCE(_12line_number_20227)) {
    }
    else {
        Concat((object_ptr)&_29266, _29265, _12line_number_20227);
        _29265 = NOVALUE;
    }
    _29265 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29266;
    if( _1 != _29266 ){
        DeRef(_1);
    }
    _29266 = NOVALUE;
    _29263 = NOVALUE;

    /** parser.e:2460			switch_stack[$][SWITCH_CURRENT_FILE_NO] &= current_file_no*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29267 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29267 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55201 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29267 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29270 = (object)*(((s1_ptr)_2)->base + 13);
    _29268 = NOVALUE;
    if (IS_SEQUENCE(_29270) && IS_ATOM(_12current_file_no_20226)) {
        Append(&_29271, _29270, _12current_file_no_20226);
    }
    else if (IS_ATOM(_29270) && IS_SEQUENCE(_12current_file_no_20226)) {
    }
    else {
        Concat((object_ptr)&_29271, _29270, _12current_file_no_20226);
        _29270 = NOVALUE;
    }
    _29270 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 13);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29271;
    if( _1 != _29271 ){
        DeRef(_1);
    }
    _29271 = NOVALUE;
    _29268 = NOVALUE;

    /** parser.e:2462			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L3; // [217] 262
    }
    else{
    }

    /** parser.e:2463				emit_addr( CASE )*/
    _45emit_addr(186);

    /** parser.e:2464				emit_addr( length( switch_stack[$][SWITCH_CASES] ) )*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29272 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29272 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _29273 = (object)*(((s1_ptr)_2)->base + _29272);
    _2 = (object)SEQ_PTR(_29273);
    _29274 = (object)*(((s1_ptr)_2)->base + 1);
    _29273 = NOVALUE;
    if (IS_SEQUENCE(_29274)){
            _29275 = SEQ_PTR(_29274)->length;
    }
    else {
        _29275 = 1;
    }
    _29274 = NOVALUE;
    _45emit_addr(_29275);
    _29275 = NOVALUE;
    goto L3; // [249] 262
L2: 

    /** parser.e:2467			CompileErr( DUPLICATE_CASE_VALUE_USED)*/
    RefDS(_22015);
    _49CompileErr(63, _22015, 0);
L3: 

    /** parser.e:2469	end procedure*/
    DeRef(_sym_58566);
    _29274 = NOVALUE;
    return;
    ;
}


void _43case_else()
{
    object _29283 = NOVALUE;
    object _29282 = NOVALUE;
    object _29280 = NOVALUE;
    object _29279 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2476		switch_stack[$][SWITCH_ELSE] = length(Code) + 1*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29279 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29279 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55201 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29279 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_12Code_20315)){
            _29282 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29282 = 1;
    }
    _29283 = _29282 + 1;
    _29282 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29283;
    if( _1 != _29283 ){
        DeRef(_1);
    }
    _29283 = NOVALUE;
    _29280 = NOVALUE;

    /** parser.e:2477		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L1; // [30] 46
    }
    else{
    }

    /** parser.e:2478			emit_addr( CASE )*/
    _45emit_addr(186);

    /** parser.e:2479			emit_addr( 0 )*/
    _45emit_addr(0);
L1: 

    /** parser.e:2482	end procedure*/
    return;
    ;
}


void _43Case_statement()
{
    object _else_case_2__tmp_at147_58690 = NOVALUE;
    object _else_case_1__tmp_at147_58689 = NOVALUE;
    object _else_case_inlined_else_case_at_147_58688 = NOVALUE;
    object _tok_58651 = NOVALUE;
    object _condition_58653 = NOVALUE;
    object _start_line_58683 = NOVALUE;
    object _sign_58695 = NOVALUE;
    object _fwd_58708 = NOVALUE;
    object _symi_58718 = NOVALUE;
    object _fwdref_58790 = NOVALUE;
    object _31708 = NOVALUE;
    object _29365 = NOVALUE;
    object _29364 = NOVALUE;
    object _29363 = NOVALUE;
    object _29362 = NOVALUE;
    object _29361 = NOVALUE;
    object _29360 = NOVALUE;
    object _29358 = NOVALUE;
    object _29357 = NOVALUE;
    object _29356 = NOVALUE;
    object _29355 = NOVALUE;
    object _29354 = NOVALUE;
    object _29353 = NOVALUE;
    object _29351 = NOVALUE;
    object _29348 = NOVALUE;
    object _29345 = NOVALUE;
    object _29344 = NOVALUE;
    object _29343 = NOVALUE;
    object _29342 = NOVALUE;
    object _29339 = NOVALUE;
    object _29338 = NOVALUE;
    object _29337 = NOVALUE;
    object _29336 = NOVALUE;
    object _29333 = NOVALUE;
    object _29332 = NOVALUE;
    object _29331 = NOVALUE;
    object _29330 = NOVALUE;
    object _29328 = NOVALUE;
    object _29327 = NOVALUE;
    object _29326 = NOVALUE;
    object _29324 = NOVALUE;
    object _29323 = NOVALUE;
    object _29322 = NOVALUE;
    object _29321 = NOVALUE;
    object _29320 = NOVALUE;
    object _29318 = NOVALUE;
    object _29317 = NOVALUE;
    object _29315 = NOVALUE;
    object _29314 = NOVALUE;
    object _29313 = NOVALUE;
    object _29312 = NOVALUE;
    object _29308 = NOVALUE;
    object _29307 = NOVALUE;
    object _29306 = NOVALUE;
    object _29303 = NOVALUE;
    object _29300 = NOVALUE;
    object _29297 = NOVALUE;
    object _29296 = NOVALUE;
    object _29295 = NOVALUE;
    object _29294 = NOVALUE;
    object _29293 = NOVALUE;
    object _29292 = NOVALUE;
    object _29291 = NOVALUE;
    object _29289 = NOVALUE;
    object _29288 = NOVALUE;
    object _29287 = NOVALUE;
    object _29286 = NOVALUE;
    object _29284 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2489		if not in_switch() then*/
    _29284 = _43in_switch();
    if (IS_ATOM_INT(_29284)) {
        if (_29284 != 0){
            DeRef(_29284);
            _29284 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    else {
        if (DBL_PTR(_29284)->dbl != 0.0){
            DeRef(_29284);
            _29284 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    DeRef(_29284);
    _29284 = NOVALUE;

    /** parser.e:2490			CompileErr( A_CASE_MUST_BE_INSIDE_A_SWITCH)*/
    RefDS(_22015);
    _49CompileErr(34, _22015, 0);
L1: 

    /** parser.e:2493		if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29286 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29286 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _29287 = (object)*(((s1_ptr)_2)->base + _29286);
    _2 = (object)SEQ_PTR(_29287);
    _29288 = (object)*(((s1_ptr)_2)->base + 1);
    _29287 = NOVALUE;
    if (IS_SEQUENCE(_29288)){
            _29289 = SEQ_PTR(_29288)->length;
    }
    else {
        _29289 = 1;
    }
    _29288 = NOVALUE;
    if (_29289 <= 0)
    goto L2; // [37] 103

    /** parser.e:2495			Sibling_block( CASE )*/
    _64Sibling_block(186);

    /** parser.e:2497			if not switch_stack[$][SWITCH_FALLTHRU] and*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29291 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29291 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _29292 = (object)*(((s1_ptr)_2)->base + _29291);
    _2 = (object)SEQ_PTR(_29292);
    _29293 = (object)*(((s1_ptr)_2)->base + 5);
    _29292 = NOVALUE;
    if (IS_ATOM_INT(_29293)) {
        _29294 = (_29293 == 0);
    }
    else {
        _29294 = unary_op(NOT, _29293);
    }
    _29293 = NOVALUE;
    if (IS_ATOM_INT(_29294)) {
        if (_29294 == 0) {
            goto L3; // [66] 112
        }
    }
    else {
        if (DBL_PTR(_29294)->dbl == 0.0) {
            goto L3; // [66] 112
        }
    }
    _29296 = (_43fallthru_case_58647 == 0);
    if (_29296 == 0)
    {
        DeRef(_29296);
        _29296 = NOVALUE;
        goto L3; // [76] 112
    }
    else{
        DeRef(_29296);
        _29296 = NOVALUE;
    }

    /** parser.e:2501				putback( {CASE, 0} )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 186;
    ((intptr_t *)_2)[2] = 0;
    _29297 = MAKE_SEQ(_1);
    _43putback(_29297);
    _29297 = NOVALUE;

    /** parser.e:2502				Break_statement()*/
    _43Break_statement();

    /** parser.e:2503				tok = next_token()*/
    _0 = _tok_58651;
    _tok_58651 = _43next_token();
    DeRef(_0);
    goto L3; // [100] 112
L2: 

    /** parser.e:2506			Start_block( CASE )*/
    _64Start_block(186, 0);
L3: 

    /** parser.e:2509		StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _45StartSourceLine(_9TRUE_446, 0, 1);

    /** parser.e:2511		fallthru_case = 0*/
    _43fallthru_case_58647 = 0;

    /** parser.e:2512		integer start_line = line_number*/
    _start_line_58683 = _12line_number_20227;

    /** parser.e:2513		while 1 do*/
L4: 

    /** parser.e:2515			if else_case() then*/

    /** parser.e:2472		return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _else_case_1__tmp_at147_58689 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _else_case_1__tmp_at147_58689 = 1;
    }
    DeRef(_else_case_2__tmp_at147_58690);
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _else_case_2__tmp_at147_58690 = (object)*(((s1_ptr)_2)->base + _else_case_1__tmp_at147_58689);
    RefDS(_else_case_2__tmp_at147_58690);
    DeRef(_else_case_inlined_else_case_at_147_58688);
    _2 = (object)SEQ_PTR(_else_case_2__tmp_at147_58690);
    _else_case_inlined_else_case_at_147_58688 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_else_case_inlined_else_case_at_147_58688);
    DeRef(_else_case_2__tmp_at147_58690);
    _else_case_2__tmp_at147_58690 = NOVALUE;
    if (_else_case_inlined_else_case_at_147_58688 == 0) {
        goto L5; // [162] 175
    }
    else {
        if (!IS_ATOM_INT(_else_case_inlined_else_case_at_147_58688) && DBL_PTR(_else_case_inlined_else_case_at_147_58688)->dbl == 0.0){
            goto L5; // [162] 175
        }
    }

    /** parser.e:2516				CompileErr( A_CASE_BLOCK_CANNOT_FOLLOW_A_CASE_ELSE_BLOCK)*/
    RefDS(_22015);
    _49CompileErr(33, _22015, 0);
L5: 

    /** parser.e:2518			maybe_namespace()*/
    _61maybe_namespace();

    /** parser.e:2519			tok = next_token()*/
    _0 = _tok_58651;
    _tok_58651 = _43next_token();
    DeRef(_0);

    /** parser.e:2520			integer sign = 1*/
    _sign_58695 = 1;

    /** parser.e:2521			if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_58651);
    _29300 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29300, 10)){
        _29300 = NOVALUE;
        goto L6; // [199] 216
    }
    _29300 = NOVALUE;

    /** parser.e:2522				sign = -1*/
    _sign_58695 = -1;

    /** parser.e:2523				tok = next_token()*/
    _0 = _tok_58651;
    _tok_58651 = _43next_token();
    DeRef(_0);
    goto L7; // [213] 237
L6: 

    /** parser.e:2524			elsif tok[T_ID] = PLUS then*/
    _2 = (object)SEQ_PTR(_tok_58651);
    _29303 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29303, 11)){
        _29303 = NOVALUE;
        goto L8; // [226] 236
    }
    _29303 = NOVALUE;

    /** parser.e:2525				tok = next_token()*/
    _0 = _tok_58651;
    _tok_58651 = _43next_token();
    DeRef(_0);
L8: 
L7: 

    /** parser.e:2528			integer fwd*/

    /** parser.e:2529			if not find( tok[T_ID], {ATOM, STRING, ELSE} ) then*/
    _2 = (object)SEQ_PTR(_tok_58651);
    _29306 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 502;
    ((intptr_t*)_2)[2] = 503;
    ((intptr_t*)_2)[3] = 23;
    _29307 = MAKE_SEQ(_1);
    _29308 = find_from(_29306, _29307, 1);
    _29306 = NOVALUE;
    DeRefDS(_29307);
    _29307 = NOVALUE;
    if (_29308 != 0)
    goto L9; // [264] 439
    _29308 = NOVALUE;

    /** parser.e:2531				integer symi = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_58651);
    _symi_58718 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_symi_58718)){
        _symi_58718 = (object)DBL_PTR(_symi_58718)->dbl;
    }

    /** parser.e:2532				fwd = -1*/
    _fwd_58708 = -1;

    /** parser.e:2533				if symi > 0 then*/
    if (_symi_58718 <= 0)
    goto LA; // [284] 434

    /** parser.e:2534					if find(tok[T_ID] , VAR_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_58651);
    _29312 = (object)*(((s1_ptr)_2)->base + 1);
    _29313 = find_from(_29312, _29VAR_TOKS_12016, 1);
    _29312 = NOVALUE;
    if (_29313 == 0)
    {
        _29313 = NOVALUE;
        goto LB; // [303] 433
    }
    else{
        _29313 = NOVALUE;
    }

    /** parser.e:2535						if SymTab[symi][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29314 = (object)*(((s1_ptr)_2)->base + _symi_58718);
    _2 = (object)SEQ_PTR(_29314);
    _29315 = (object)*(((s1_ptr)_2)->base + 4);
    _29314 = NOVALUE;
    if (binary_op_a(NOTEQ, _29315, 9)){
        _29315 = NOVALUE;
        goto LC; // [322] 334
    }
    _29315 = NOVALUE;

    /** parser.e:2537							fwd = symi*/
    _fwd_58708 = _symi_58718;
    goto LD; // [331] 432
LC: 

    /** parser.e:2538						elsif SymTab[symi][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29317 = (object)*(((s1_ptr)_2)->base + _symi_58718);
    _2 = (object)SEQ_PTR(_29317);
    _29318 = (object)*(((s1_ptr)_2)->base + 3);
    _29317 = NOVALUE;
    if (binary_op_a(NOTEQ, _29318, 2)){
        _29318 = NOVALUE;
        goto LE; // [350] 431
    }
    _29318 = NOVALUE;

    /** parser.e:2539							fwd = 0*/
    _fwd_58708 = 0;

    /** parser.e:2540							if SymTab[symi][S_CODE] then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29320 = (object)*(((s1_ptr)_2)->base + _symi_58718);
    _2 = (object)SEQ_PTR(_29320);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _29321 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _29321 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    _29320 = NOVALUE;
    if (_29321 == 0) {
        _29321 = NOVALUE;
        goto LF; // [373] 397
    }
    else {
        if (!IS_ATOM_INT(_29321) && DBL_PTR(_29321)->dbl == 0.0){
            _29321 = NOVALUE;
            goto LF; // [373] 397
        }
        _29321 = NOVALUE;
    }
    _29321 = NOVALUE;

    /** parser.e:2541								tok[T_SYM] = SymTab[symi][S_CODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29322 = (object)*(((s1_ptr)_2)->base + _symi_58718);
    _2 = (object)SEQ_PTR(_29322);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _29323 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _29323 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    _29322 = NOVALUE;
    Ref(_29323);
    _2 = (object)SEQ_PTR(_tok_58651);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_58651 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29323;
    if( _1 != _29323 ){
        DeRef(_1);
    }
    _29323 = NOVALUE;
LF: 

    /** parser.e:2543							SymTab[symi][S_USAGE] = or_bits( SymTab[symi][S_USAGE], U_READ )*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_symi_58718 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29326 = (object)*(((s1_ptr)_2)->base + _symi_58718);
    _2 = (object)SEQ_PTR(_29326);
    _29327 = (object)*(((s1_ptr)_2)->base + 5);
    _29326 = NOVALUE;
    if (IS_ATOM_INT(_29327)) {
        {uintptr_t tu;
             tu = (uintptr_t)_29327 | (uintptr_t)1;
             _29328 = MAKE_UINT(tu);
        }
    }
    else {
        _29328 = binary_op(OR_BITS, _29327, 1);
    }
    _29327 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29328;
    if( _1 != _29328 ){
        DeRef(_1);
    }
    _29328 = NOVALUE;
    _29324 = NOVALUE;
LE: 
LD: 
LB: 
LA: 
    goto L10; // [436] 445
L9: 

    /** parser.e:2548				fwd = 0*/
    _fwd_58708 = 0;
L10: 

    /** parser.e:2551			if fwd < 0 then*/
    if (_fwd_58708 >= 0)
    goto L11; // [449] 477

    /** parser.e:2552				CompileErr( FOUND_1_BUT_EXPECTED_ELSE_AN_ATOM_STRING_CONSTANT_OR_ENUM, {find_category(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_58651);
    _29330 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29330);
    _29331 = _62find_category(_29330);
    _29330 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _29331;
    _29332 = MAKE_SEQ(_1);
    _29331 = NOVALUE;
    _49CompileErr(91, _29332, 0);
    _29332 = NOVALUE;
L11: 

    /** parser.e:2555			if tok[T_ID] = ELSE then*/
    _2 = (object)SEQ_PTR(_tok_58651);
    _29333 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29333, 23)){
        _29333 = NOVALUE;
        goto L12; // [487] 552
    }
    _29333 = NOVALUE;

    /** parser.e:2556				if sign = -1 then*/
    if (_sign_58695 != -1)
    goto L13; // [493] 507

    /** parser.e:2557					CompileErr( EXPECTED_AN_ATOM_STRING_OR_A_CONSTANT_ASSIGNED_AN_ATOM_OR_A_STRING)*/
    RefDS(_22015);
    _49CompileErr(71, _22015, 0);
L13: 

    /** parser.e:2559				if length(switch_stack[$][SWITCH_CASES]) = 0 then*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29336 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29336 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _29337 = (object)*(((s1_ptr)_2)->base + _29336);
    _2 = (object)SEQ_PTR(_29337);
    _29338 = (object)*(((s1_ptr)_2)->base + 1);
    _29337 = NOVALUE;
    if (IS_SEQUENCE(_29338)){
            _29339 = SEQ_PTR(_29338)->length;
    }
    else {
        _29339 = 1;
    }
    _29338 = NOVALUE;
    if (_29339 != 0)
    goto L14; // [525] 539

    /** parser.e:2560					CompileErr( CASE_ELSE_CANNOT_BE_FIRST_CASE_IN_SWITCH)*/
    RefDS(_22015);
    _49CompileErr(44, _22015, 0);
L14: 

    /** parser.e:2562				case_else()*/
    _43case_else();

    /** parser.e:2563				exit*/
    goto L15; // [547] 789
    goto L16; // [549] 623
L12: 

    /** parser.e:2565			elsif fwd then*/
    if (_fwd_58708 == 0)
    {
        goto L17; // [554] 606
    }
    else{
    }

    /** parser.e:2566				integer fwdref = new_forward_reference( CASE, fwd )*/
    DeRef(_31708);
    _31708 = 186;
    _fwdref_58790 = _42new_forward_reference(186, _fwd_58708, 186);
    _31708 = NOVALUE;
    if (!IS_ATOM_INT(_fwdref_58790)) {
        _1 = (object)(DBL_PTR(_fwdref_58790)->dbl);
        DeRefDS(_fwdref_58790);
        _fwdref_58790 = _1;
    }

    /** parser.e:2567				add_case( {fwdref}, sign )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _fwdref_58790;
    _29342 = MAKE_SEQ(_1);
    _43add_case(_29342, _sign_58695);
    _29342 = NOVALUE;

    /** parser.e:2568				fwd:set_data( fwdref, switch_stack[$][SWITCH_PC] )*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29343 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29343 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _29344 = (object)*(((s1_ptr)_2)->base + _29343);
    _2 = (object)SEQ_PTR(_29344);
    _29345 = (object)*(((s1_ptr)_2)->base + 4);
    _29344 = NOVALUE;
    Ref(_29345);
    _42set_data(_fwdref_58790, _29345);
    _29345 = NOVALUE;
    goto L16; // [603] 623
L17: 

    /** parser.e:2571				condition = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_58651);
    _condition_58653 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_condition_58653)){
        _condition_58653 = (object)DBL_PTR(_condition_58653)->dbl;
    }

    /** parser.e:2572				add_case( condition, sign )*/
    _43add_case(_condition_58653, _sign_58695);
L16: 

    /** parser.e:2575			tok = next_token()*/
    _0 = _tok_58651;
    _tok_58651 = _43next_token();
    DeRef(_0);

    /** parser.e:2576			if tok[T_ID] = THEN then*/
    _2 = (object)SEQ_PTR(_tok_58651);
    _29348 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29348, 410)){
        _29348 = NOVALUE;
        goto L18; // [638] 742
    }
    _29348 = NOVALUE;

    /** parser.e:2577				tok = next_token()*/
    _0 = _tok_58651;
    _tok_58651 = _43next_token();
    DeRef(_0);

    /** parser.e:2579				if tok[T_ID] = CASE then*/
    _2 = (object)SEQ_PTR(_tok_58651);
    _29351 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29351, 186)){
        _29351 = NOVALUE;
        goto L19; // [657] 727
    }
    _29351 = NOVALUE;

    /** parser.e:2580					if switch_stack[$][SWITCH_FALLTHRU] then*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29353 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29353 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _29354 = (object)*(((s1_ptr)_2)->base + _29353);
    _2 = (object)SEQ_PTR(_29354);
    _29355 = (object)*(((s1_ptr)_2)->base + 5);
    _29354 = NOVALUE;
    if (_29355 == 0) {
        _29355 = NOVALUE;
        goto L1A; // [676] 691
    }
    else {
        if (!IS_ATOM_INT(_29355) && DBL_PTR(_29355)->dbl == 0.0){
            _29355 = NOVALUE;
            goto L1A; // [676] 691
        }
        _29355 = NOVALUE;
    }
    _29355 = NOVALUE;

    /** parser.e:2581						start_line = line_number*/
    _start_line_58683 = _12line_number_20227;
    goto L1B; // [688] 782
L1A: 

    /** parser.e:2583						putback( tok )*/
    Ref(_tok_58651);
    _43putback(_tok_58651);

    /** parser.e:2584						Warning(220, empty_case_warning_flag,*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _29356 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    Ref(_29356);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _29356;
    ((intptr_t *)_2)[2] = _start_line_58683;
    _29357 = MAKE_SEQ(_1);
    _29356 = NOVALUE;
    _49Warning(220, 2048, _29357);
    _29357 = NOVALUE;

    /** parser.e:2586						exit*/
    goto L15; // [721] 789
    goto L1B; // [724] 782
L19: 

    /** parser.e:2589					putback( tok )*/
    Ref(_tok_58651);
    _43putback(_tok_58651);

    /** parser.e:2590					exit*/
    goto L15; // [736] 789
    goto L1B; // [739] 782
L18: 

    /** parser.e:2593			elsif tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_58651);
    _29358 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29358, -30)){
        _29358 = NOVALUE;
        goto L1C; // [752] 781
    }
    _29358 = NOVALUE;

    /** parser.e:2594				CompileErr(EXPECTED_THEN_OR__NOT_1,{LexName(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_58651);
    _29360 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29360);
    RefDS(_26351);
    _29361 = _45LexName(_29360, _26351);
    _29360 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _29361;
    _29362 = MAKE_SEQ(_1);
    _29361 = NOVALUE;
    _49CompileErr(66, _29362, 0);
    _29362 = NOVALUE;
L1C: 
L1B: 

    /** parser.e:2597		end while*/
    goto L4; // [786] 142
L15: 

    /** parser.e:2598		StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:2599		emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29363 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29363 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _29364 = (object)*(((s1_ptr)_2)->base + _29363);
    _2 = (object)SEQ_PTR(_29364);
    _29365 = (object)*(((s1_ptr)_2)->base + 6);
    _29364 = NOVALUE;
    Ref(_29365);
    _45emit_temp(_29365, 1);
    _29365 = NOVALUE;

    /** parser.e:2600		flush_temps()*/
    RefDS(_22015);
    _45flush_temps(_22015);

    /** parser.e:2601	end procedure*/
    DeRef(_tok_58651);
    DeRef(_29294);
    _29294 = NOVALUE;
    _29338 = NOVALUE;
    _29288 = NOVALUE;
    return;
    ;
}


void _43Fallthru_statement()
{
    object _29366 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2604		if not in_switch() then*/
    _29366 = _43in_switch();
    if (IS_ATOM_INT(_29366)) {
        if (_29366 != 0){
            DeRef(_29366);
            _29366 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    else {
        if (DBL_PTR(_29366)->dbl != 0.0){
            DeRef(_29366);
            _29366 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    DeRef(_29366);
    _29366 = NOVALUE;

    /** parser.e:2605			CompileErr( A_FALLTHRU_MUST_BE_INSIDE_A_SWITCH)*/
    RefDS(_22015);
    _49CompileErr(22, _22015, 0);
L1: 

    /** parser.e:2607		tok_match( CASE )*/
    _43tok_match(186, 0);

    /** parser.e:2608		fallthru_case = 1*/
    _43fallthru_case_58647 = 1;

    /** parser.e:2609		Case_statement()*/
    _43Case_statement();

    /** parser.e:2610	end procedure*/
    return;
    ;
}


void _43update_translator_info(object _sym_58858, object _all_ints_58859, object _has_integer_58860, object _has_atom_58861, object _has_sequence_58862)
{
    object _29391 = NOVALUE;
    object _29389 = NOVALUE;
    object _29387 = NOVALUE;
    object _29385 = NOVALUE;
    object _29383 = NOVALUE;
    object _29382 = NOVALUE;
    object _29380 = NOVALUE;
    object _29378 = NOVALUE;
    object _29377 = NOVALUE;
    object _29376 = NOVALUE;
    object _29375 = NOVALUE;
    object _29374 = NOVALUE;
    object _29372 = NOVALUE;
    object _29370 = NOVALUE;
    object _29368 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2615		SymTab[sym][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58858 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _29368 = NOVALUE;

    /** parser.e:2616		SymTab[sym][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58858 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8;
    DeRef(_1);
    _29370 = NOVALUE;

    /** parser.e:2617		SymTab[sym][S_SEQ_LEN] = length( SymTab[sym][S_OBJ] )*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58858 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29374 = (object)*(((s1_ptr)_2)->base + _sym_58858);
    _2 = (object)SEQ_PTR(_29374);
    _29375 = (object)*(((s1_ptr)_2)->base + 1);
    _29374 = NOVALUE;
    if (IS_SEQUENCE(_29375)){
            _29376 = SEQ_PTR(_29375)->length;
    }
    else {
        _29376 = 1;
    }
    _29375 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29376;
    if( _1 != _29376 ){
        DeRef(_1);
    }
    _29376 = NOVALUE;
    _29372 = NOVALUE;

    /** parser.e:2619		if SymTab[sym][S_SEQ_LEN] > 0 then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29377 = (object)*(((s1_ptr)_2)->base + _sym_58858);
    _2 = (object)SEQ_PTR(_29377);
    _29378 = (object)*(((s1_ptr)_2)->base + 32);
    _29377 = NOVALUE;
    if (binary_op_a(LESSEQ, _29378, 0)){
        _29378 = NOVALUE;
        goto L1; // [89] 198
    }
    _29378 = NOVALUE;

    /** parser.e:2620			if all_ints then*/
    if (_all_ints_58859 == 0)
    {
        goto L2; // [95] 118
    }
    else{
    }

    /** parser.e:2621				SymTab[sym][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58858 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _29380 = NOVALUE;
    goto L3; // [115] 216
L2: 

    /** parser.e:2623			elsif has_atom + has_sequence + has_integer > 1 then*/
    _29382 = _has_atom_58861 + _has_sequence_58862;
    if ((object)((uintptr_t)_29382 + (uintptr_t)HIGH_BITS) >= 0){
        _29382 = NewDouble((eudouble)_29382);
    }
    if (IS_ATOM_INT(_29382)) {
        _29383 = _29382 + _has_integer_58860;
        if ((object)((uintptr_t)_29383 + (uintptr_t)HIGH_BITS) >= 0){
            _29383 = NewDouble((eudouble)_29383);
        }
    }
    else {
        _29383 = NewDouble(DBL_PTR(_29382)->dbl + (eudouble)_has_integer_58860);
    }
    DeRef(_29382);
    _29382 = NOVALUE;
    if (binary_op_a(LESSEQ, _29383, 1)){
        DeRef(_29383);
        _29383 = NOVALUE;
        goto L4; // [128] 152
    }
    DeRef(_29383);
    _29383 = NOVALUE;

    /** parser.e:2624				SymTab[sym][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58858 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    _29385 = NOVALUE;
    goto L3; // [149] 216
L4: 

    /** parser.e:2626			elsif has_atom then*/
    if (_has_atom_58861 == 0)
    {
        goto L5; // [154] 177
    }
    else{
    }

    /** parser.e:2627				SymTab[sym][S_SEQ_ELEM] = TYPE_ATOM*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58858 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4;
    DeRef(_1);
    _29387 = NOVALUE;
    goto L3; // [174] 216
L5: 

    /** parser.e:2630				SymTab[sym][S_SEQ_ELEM] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58858 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8;
    DeRef(_1);
    _29389 = NOVALUE;
    goto L3; // [195] 216
L1: 

    /** parser.e:2634			SymTab[sym][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58858 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _29391 = NOVALUE;
L3: 

    /** parser.e:2636	end procedure*/
    _29375 = NOVALUE;
    return;
    ;
}


void _43optimize_switch(object _switch_pc_58923, object _else_bp_58924, object _cases_58925, object _jump_table_58926)
{
    object _values_58927 = NOVALUE;
    object _min_58931 = NOVALUE;
    object _max_58933 = NOVALUE;
    object _all_ints_58935 = NOVALUE;
    object _has_integer_58936 = NOVALUE;
    object _has_atom_58937 = NOVALUE;
    object _has_sequence_58938 = NOVALUE;
    object _has_unassigned_58939 = NOVALUE;
    object _has_fwdref_58940 = NOVALUE;
    object _unique_values_58941 = NOVALUE;
    object _unique_jumps_58943 = NOVALUE;
    object _new_1__tmp_at74_58946 = NOVALUE;
    object _new_inlined_new_at_74_58945 = NOVALUE;
    object _jump_58947 = NOVALUE;
    object _jump_offset_58951 = NOVALUE;
    object _sym_58958 = NOVALUE;
    object _sign_58960 = NOVALUE;
    object _value_i_58973 = NOVALUE;
    object _v_58997 = NOVALUE;
    object _else_target_59083 = NOVALUE;
    object _opcode_59086 = NOVALUE;
    object _delta_59092 = NOVALUE;
    object _switch_table_59102 = NOVALUE;
    object _offset_59105 = NOVALUE;
    object _29505 = NOVALUE;
    object _29504 = NOVALUE;
    object _29503 = NOVALUE;
    object _29502 = NOVALUE;
    object _29500 = NOVALUE;
    object _29498 = NOVALUE;
    object _29495 = NOVALUE;
    object _29494 = NOVALUE;
    object _29493 = NOVALUE;
    object _29492 = NOVALUE;
    object _29491 = NOVALUE;
    object _29490 = NOVALUE;
    object _29489 = NOVALUE;
    object _29486 = NOVALUE;
    object _29485 = NOVALUE;
    object _29484 = NOVALUE;
    object _29483 = NOVALUE;
    object _29482 = NOVALUE;
    object _29481 = NOVALUE;
    object _29477 = NOVALUE;
    object _29476 = NOVALUE;
    object _29474 = NOVALUE;
    object _29473 = NOVALUE;
    object _29472 = NOVALUE;
    object _29471 = NOVALUE;
    object _29470 = NOVALUE;
    object _29469 = NOVALUE;
    object _29468 = NOVALUE;
    object _29467 = NOVALUE;
    object _29466 = NOVALUE;
    object _29465 = NOVALUE;
    object _29463 = NOVALUE;
    object _29462 = NOVALUE;
    object _29458 = NOVALUE;
    object _29456 = NOVALUE;
    object _29455 = NOVALUE;
    object _29454 = NOVALUE;
    object _29452 = NOVALUE;
    object _29449 = NOVALUE;
    object _29448 = NOVALUE;
    object _29447 = NOVALUE;
    object _29445 = NOVALUE;
    object _29444 = NOVALUE;
    object _29443 = NOVALUE;
    object _29441 = NOVALUE;
    object _29440 = NOVALUE;
    object _29439 = NOVALUE;
    object _29437 = NOVALUE;
    object _29436 = NOVALUE;
    object _29435 = NOVALUE;
    object _29433 = NOVALUE;
    object _29430 = NOVALUE;
    object _29429 = NOVALUE;
    object _29428 = NOVALUE;
    object _29427 = NOVALUE;
    object _29426 = NOVALUE;
    object _29425 = NOVALUE;
    object _29424 = NOVALUE;
    object _29423 = NOVALUE;
    object _29422 = NOVALUE;
    object _29421 = NOVALUE;
    object _29420 = NOVALUE;
    object _29419 = NOVALUE;
    object _29416 = NOVALUE;
    object _29415 = NOVALUE;
    object _29414 = NOVALUE;
    object _29412 = NOVALUE;
    object _29411 = NOVALUE;
    object _29409 = NOVALUE;
    object _29408 = NOVALUE;
    object _29407 = NOVALUE;
    object _29403 = NOVALUE;
    object _29402 = NOVALUE;
    object _29401 = NOVALUE;
    object _29399 = NOVALUE;
    object _29398 = NOVALUE;
    object _29394 = NOVALUE;
    object _29393 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2641		sequence values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29393 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29393 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _29394 = (object)*(((s1_ptr)_2)->base + _29393);
    DeRef(_values_58927);
    _2 = (object)SEQ_PTR(_29394);
    _values_58927 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_values_58927);
    _29394 = NOVALUE;

    /** parser.e:2642		atom min =  1e+300*/
    RefDS(_29396);
    DeRef(_min_58931);
    _min_58931 = _29396;

    /** parser.e:2643		atom max = -1e+300*/
    RefDS(_29397);
    DeRef(_max_58933);
    _max_58933 = _29397;

    /** parser.e:2644		integer all_ints = 1*/
    _all_ints_58935 = 1;

    /** parser.e:2645		integer has_integer    = 0*/
    _has_integer_58936 = 0;

    /** parser.e:2646		integer has_atom       = 0*/
    _has_atom_58937 = 0;

    /** parser.e:2647		integer has_sequence   = 0*/
    _has_sequence_58938 = 0;

    /** parser.e:2648		integer has_unassigned = 0*/
    _has_unassigned_58939 = 0;

    /** parser.e:2649		integer has_fwdref     = 0*/
    _has_fwdref_58940 = 0;

    /** parser.e:2650		sequence unique_values = {}*/
    RefDS(_22015);
    DeRef(_unique_values_58941);
    _unique_values_58941 = _22015;

    /** parser.e:2651		map unique_jumps = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at74_58946;
    _new_1__tmp_at74_58946 = _34new_map_seq(8);
    DeRef(_0);
    Ref(_new_1__tmp_at74_58946);
    _0 = _unique_jumps_58943;
    _unique_jumps_58943 = _35malloc(_new_1__tmp_at74_58946, 1);
    DeRef(_0);
    DeRef(_new_1__tmp_at74_58946);
    _new_1__tmp_at74_58946 = NOVALUE;

    /** parser.e:2653		sequence jump = switch_stack[$][SWITCH_JUMP_TABLE]*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29398 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29398 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _29399 = (object)*(((s1_ptr)_2)->base + _29398);
    DeRef(_jump_58947);
    _2 = (object)SEQ_PTR(_29399);
    _jump_58947 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_jump_58947);
    _29399 = NOVALUE;

    /** parser.e:2654		integer jump_offset = 0*/
    _jump_offset_58951 = 0;

    /** parser.e:2655		for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_58927)){
            _29401 = SEQ_PTR(_values_58927)->length;
    }
    else {
        _29401 = 1;
    }
    {
        object _i_58953;
        _i_58953 = 1;
L1: 
        if (_i_58953 > _29401){
            goto L2; // [116] 586
        }

        /** parser.e:2656			if sequence( values[i] ) then*/
        _2 = (object)SEQ_PTR(_values_58927);
        _29402 = (object)*(((s1_ptr)_2)->base + _i_58953);
        _29403 = IS_SEQUENCE(_29402);
        _29402 = NOVALUE;
        if (_29403 == 0)
        {
            _29403 = NOVALUE;
            goto L3; // [132] 145
        }
        else{
            _29403 = NOVALUE;
        }

        /** parser.e:2657				has_fwdref = 1*/
        _has_fwdref_58940 = 1;

        /** parser.e:2658				exit*/
        goto L2; // [142] 586
L3: 

        /** parser.e:2660			integer sym = values[i]*/
        _2 = (object)SEQ_PTR(_values_58927);
        _sym_58958 = (object)*(((s1_ptr)_2)->base + _i_58953);
        if (!IS_ATOM_INT(_sym_58958))
        _sym_58958 = (object)DBL_PTR(_sym_58958)->dbl;

        /** parser.e:2661			integer sign*/

        /** parser.e:2663			if sym < 0 then*/
        if (_sym_58958 >= 0)
        goto L4; // [155] 174

        /** parser.e:2664				sign = -1*/
        _sign_58960 = -1;

        /** parser.e:2665				sym = -sym*/
        _sym_58958 = - _sym_58958;
        goto L5; // [171] 180
L4: 

        /** parser.e:2667				sign = 1*/
        _sign_58960 = 1;
L5: 

        /** parser.e:2669			if not equal(SymTab[sym][S_OBJ], NOVALUE) then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _29407 = (object)*(((s1_ptr)_2)->base + _sym_58958);
        _2 = (object)SEQ_PTR(_29407);
        _29408 = (object)*(((s1_ptr)_2)->base + 1);
        _29407 = NOVALUE;
        if (_29408 == _12NOVALUE_20081)
        _29409 = 1;
        else if (IS_ATOM_INT(_29408) && IS_ATOM_INT(_12NOVALUE_20081))
        _29409 = 0;
        else
        _29409 = (compare(_29408, _12NOVALUE_20081) == 0);
        _29408 = NOVALUE;
        if (_29409 != 0)
        goto L6; // [200] 565
        _29409 = NOVALUE;

        /** parser.e:2670				object value_i = sign * SymTab[sym][S_OBJ]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _29411 = (object)*(((s1_ptr)_2)->base + _sym_58958);
        _2 = (object)SEQ_PTR(_29411);
        _29412 = (object)*(((s1_ptr)_2)->base + 1);
        _29411 = NOVALUE;
        DeRef(_value_i_58973);
        if (IS_ATOM_INT(_29412)) {
            if (_sign_58960 == (short)_sign_58960 && _29412 <= INT15 && _29412 >= -INT15){
                _value_i_58973 = _sign_58960 * _29412;
            }
            else{
                _value_i_58973 = NewDouble(_sign_58960 * (eudouble)_29412);
            }
        }
        else {
            _value_i_58973 = binary_op(MULTIPLY, _sign_58960, _29412);
        }
        _29412 = NOVALUE;

        /** parser.e:2671				values[i] = value_i*/
        Ref(_value_i_58973);
        _2 = (object)SEQ_PTR(_values_58927);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _values_58927 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_58953);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _value_i_58973;
        DeRef(_1);

        /** parser.e:2672				if TRANSLATE then*/
        if (_12TRANSLATE_19834 == 0)
        {
            goto L7; // [233] 274
        }
        else{
        }

        /** parser.e:2673					if Code[jump[i]-2] = CASE then*/
        _2 = (object)SEQ_PTR(_jump_58947);
        _29414 = (object)*(((s1_ptr)_2)->base + _i_58953);
        if (IS_ATOM_INT(_29414)) {
            _29415 = _29414 - 2;
        }
        else {
            _29415 = binary_op(MINUS, _29414, 2);
        }
        _29414 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        if (!IS_ATOM_INT(_29415)){
            _29416 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29415)->dbl));
        }
        else{
            _29416 = (object)*(((s1_ptr)_2)->base + _29415);
        }
        if (binary_op_a(NOTEQ, _29416, 186)){
            _29416 = NOVALUE;
            goto L8; // [254] 267
        }
        _29416 = NOVALUE;

        /** parser.e:2674						jump_offset -=2*/
        _jump_offset_58951 = _jump_offset_58951 - 2;
        goto L9; // [264] 273
L8: 

        /** parser.e:2676						jump_offset = 0*/
        _jump_offset_58951 = 0;
L9: 
L7: 

        /** parser.e:2680				if find( value_i, map:get( unique_jumps, jump[i] + jump_offset, {}) ) then*/
        _2 = (object)SEQ_PTR(_jump_58947);
        _29419 = (object)*(((s1_ptr)_2)->base + _i_58953);
        if (IS_ATOM_INT(_29419)) {
            _29420 = _29419 + _jump_offset_58951;
            if ((object)((uintptr_t)_29420 + (uintptr_t)HIGH_BITS) >= 0){
                _29420 = NewDouble((eudouble)_29420);
            }
        }
        else {
            _29420 = binary_op(PLUS, _29419, _jump_offset_58951);
        }
        _29419 = NOVALUE;
        Ref(_unique_jumps_58943);
        RefDS(_22015);
        _29421 = _34get(_unique_jumps_58943, _29420, _22015);
        _29420 = NOVALUE;
        _29422 = find_from(_value_i_58973, _29421, 1);
        DeRef(_29421);
        _29421 = NOVALUE;
        if (_29422 == 0)
        {
            _29422 = NOVALUE;
            goto LA; // [295] 301
        }
        else{
            _29422 = NOVALUE;
        }
        goto LB; // [298] 560
LA: 

        /** parser.e:2683				elsif find( value_i, unique_values ) then*/
        _29423 = find_from(_value_i_58973, _unique_values_58941, 1);
        if (_29423 == 0)
        {
            _29423 = NOVALUE;
            goto LC; // [308] 467
        }
        else{
            _29423 = NOVALUE;
        }

        /** parser.e:2686					object v = ""*/
        RefDS(_22015);
        DeRef(_v_58997);
        _v_58997 = _22015;

        /** parser.e:2687					if length( SymTab[sym] ) > S_NAME and sequence( sym_name( sym ) ) then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _29424 = (object)*(((s1_ptr)_2)->base + _sym_58958);
        if (IS_SEQUENCE(_29424)){
                _29425 = SEQ_PTR(_29424)->length;
        }
        else {
            _29425 = 1;
        }
        _29424 = NOVALUE;
        if (IS_ATOM_INT(_12S_NAME_19864)) {
            _29426 = (_29425 > _12S_NAME_19864);
        }
        else {
            _29426 = binary_op(GREATER, _29425, _12S_NAME_19864);
        }
        _29425 = NOVALUE;
        if (IS_ATOM_INT(_29426)) {
            if (_29426 == 0) {
                goto LD; // [333] 359
            }
        }
        else {
            if (DBL_PTR(_29426)->dbl == 0.0) {
                goto LD; // [333] 359
            }
        }
        _29428 = _53sym_name(_sym_58958);
        _29429 = IS_SEQUENCE(_29428);
        DeRef(_29428);
        _29428 = NOVALUE;
        if (_29429 == 0)
        {
            _29429 = NOVALUE;
            goto LD; // [345] 359
        }
        else{
            _29429 = NOVALUE;
        }

        /** parser.e:2688						v = sym_name( sym ) & " = " */
        _29430 = _53sym_name(_sym_58958);
        if (IS_SEQUENCE(_29430) && IS_ATOM(_29431)) {
        }
        else if (IS_ATOM(_29430) && IS_SEQUENCE(_29431)) {
            Ref(_29430);
            Prepend(&_v_58997, _29431, _29430);
        }
        else {
            Concat((object_ptr)&_v_58997, _29430, _29431);
            DeRef(_29430);
            _29430 = NOVALUE;
        }
        DeRef(_29430);
        _29430 = NOVALUE;
LD: 

        /** parser.e:2691					v &= sprint( value_i )*/
        Ref(_value_i_58973);
        _29433 = _18sprint(_value_i_58973);
        if (IS_SEQUENCE(_v_58997) && IS_ATOM(_29433)) {
            Ref(_29433);
            Append(&_v_58997, _v_58997, _29433);
        }
        else if (IS_ATOM(_v_58997) && IS_SEQUENCE(_29433)) {
            Ref(_v_58997);
            Prepend(&_v_58997, _29433, _v_58997);
        }
        else {
            Concat((object_ptr)&_v_58997, _v_58997, _29433);
        }
        DeRef(_29433);
        _29433 = NOVALUE;

        /** parser.e:2692					ThisLine        = switch_stack[$][SWITCH_THISLINE][i]*/
        if (IS_SEQUENCE(_43switch_stack_55201)){
                _29435 = SEQ_PTR(_43switch_stack_55201)->length;
        }
        else {
            _29435 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55201);
        _29436 = (object)*(((s1_ptr)_2)->base + _29435);
        _2 = (object)SEQ_PTR(_29436);
        _29437 = (object)*(((s1_ptr)_2)->base + 10);
        _29436 = NOVALUE;
        DeRef(_49ThisLine_49261);
        _2 = (object)SEQ_PTR(_29437);
        _49ThisLine_49261 = (object)*(((s1_ptr)_2)->base + _i_58953);
        Ref(_49ThisLine_49261);
        _29437 = NOVALUE;

        /** parser.e:2693					bp              = switch_stack[$][SWITCH_BP][i]*/
        if (IS_SEQUENCE(_43switch_stack_55201)){
                _29439 = SEQ_PTR(_43switch_stack_55201)->length;
        }
        else {
            _29439 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55201);
        _29440 = (object)*(((s1_ptr)_2)->base + _29439);
        _2 = (object)SEQ_PTR(_29440);
        _29441 = (object)*(((s1_ptr)_2)->base + 11);
        _29440 = NOVALUE;
        _2 = (object)SEQ_PTR(_29441);
        _49bp_49265 = (object)*(((s1_ptr)_2)->base + _i_58953);
        if (!IS_ATOM_INT(_49bp_49265)){
            _49bp_49265 = (object)DBL_PTR(_49bp_49265)->dbl;
        }
        _29441 = NOVALUE;

        /** parser.e:2694					line_number     = switch_stack[$][SWITCH_LINE_NUMBER][i]*/
        if (IS_SEQUENCE(_43switch_stack_55201)){
                _29443 = SEQ_PTR(_43switch_stack_55201)->length;
        }
        else {
            _29443 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55201);
        _29444 = (object)*(((s1_ptr)_2)->base + _29443);
        _2 = (object)SEQ_PTR(_29444);
        _29445 = (object)*(((s1_ptr)_2)->base + 12);
        _29444 = NOVALUE;
        _2 = (object)SEQ_PTR(_29445);
        _12line_number_20227 = (object)*(((s1_ptr)_2)->base + _i_58953);
        if (!IS_ATOM_INT(_12line_number_20227)){
            _12line_number_20227 = (object)DBL_PTR(_12line_number_20227)->dbl;
        }
        _29445 = NOVALUE;

        /** parser.e:2695					current_file_no = switch_stack[$][SWITCH_CURRENT_FILE_NO][i]*/
        if (IS_SEQUENCE(_43switch_stack_55201)){
                _29447 = SEQ_PTR(_43switch_stack_55201)->length;
        }
        else {
            _29447 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55201);
        _29448 = (object)*(((s1_ptr)_2)->base + _29447);
        _2 = (object)SEQ_PTR(_29448);
        _29449 = (object)*(((s1_ptr)_2)->base + 13);
        _29448 = NOVALUE;
        _2 = (object)SEQ_PTR(_29449);
        _12current_file_no_20226 = (object)*(((s1_ptr)_2)->base + _i_58953);
        if (!IS_ATOM_INT(_12current_file_no_20226)){
            _12current_file_no_20226 = (object)DBL_PTR(_12current_file_no_20226)->dbl;
        }
        _29449 = NOVALUE;

        /** parser.e:2697					CompileErr("duplicate case value used in switch: [1]", {v})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_v_58997);
        ((intptr_t*)_2)[1] = _v_58997;
        _29452 = MAKE_SEQ(_1);
        RefDS(_29451);
        _49CompileErr(_29451, _29452, 0);
        _29452 = NOVALUE;
        DeRefDS(_v_58997);
        _v_58997 = NOVALUE;
        goto LB; // [464] 560
LC: 

        /** parser.e:2700					unique_values   &= value_i*/
        if (IS_SEQUENCE(_unique_values_58941) && IS_ATOM(_value_i_58973)) {
            Ref(_value_i_58973);
            Append(&_unique_values_58941, _unique_values_58941, _value_i_58973);
        }
        else if (IS_ATOM(_unique_values_58941) && IS_SEQUENCE(_value_i_58973)) {
        }
        else {
            Concat((object_ptr)&_unique_values_58941, _unique_values_58941, _value_i_58973);
        }

        /** parser.e:2701					map:put( unique_jumps, jump[i] + jump_offset, value_i, map:APPEND )*/
        _2 = (object)SEQ_PTR(_jump_58947);
        _29454 = (object)*(((s1_ptr)_2)->base + _i_58953);
        if (IS_ATOM_INT(_29454)) {
            _29455 = _29454 + _jump_offset_58951;
            if ((object)((uintptr_t)_29455 + (uintptr_t)HIGH_BITS) >= 0){
                _29455 = NewDouble((eudouble)_29455);
            }
        }
        else {
            _29455 = binary_op(PLUS, _29454, _jump_offset_58951);
        }
        _29454 = NOVALUE;
        Ref(_unique_jumps_58943);
        Ref(_value_i_58973);
        _34put(_unique_jumps_58943, _29455, _value_i_58973, 6, 0);
        _29455 = NOVALUE;

        /** parser.e:2703					if not is_integer( value_i ) then*/
        Ref(_value_i_58973);
        _29456 = _12is_integer(_value_i_58973);
        if (IS_ATOM_INT(_29456)) {
            if (_29456 != 0){
                DeRef(_29456);
                _29456 = NOVALUE;
                goto LE; // [496] 529
            }
        }
        else {
            if (DBL_PTR(_29456)->dbl != 0.0){
                DeRef(_29456);
                _29456 = NOVALUE;
                goto LE; // [496] 529
            }
        }
        DeRef(_29456);
        _29456 = NOVALUE;

        /** parser.e:2704						all_ints = 0*/
        _all_ints_58935 = 0;

        /** parser.e:2705						if atom( value_i ) then*/
        _29458 = IS_ATOM(_value_i_58973);
        if (_29458 == 0)
        {
            _29458 = NOVALUE;
            goto LF; // [509] 520
        }
        else{
            _29458 = NOVALUE;
        }

        /** parser.e:2706							has_atom = 1*/
        _has_atom_58937 = 1;
        goto L10; // [517] 559
LF: 

        /** parser.e:2708							has_sequence = 1*/
        _has_sequence_58938 = 1;
        goto L10; // [526] 559
LE: 

        /** parser.e:2711						has_integer = 1*/
        _has_integer_58936 = 1;

        /** parser.e:2713						if value_i < min then*/
        if (binary_op_a(GREATEREQ, _value_i_58973, _min_58931)){
            goto L11; // [536] 546
        }

        /** parser.e:2714							min = value_i*/
        Ref(_value_i_58973);
        DeRef(_min_58931);
        _min_58931 = _value_i_58973;
L11: 

        /** parser.e:2717						if value_i > max then*/
        if (binary_op_a(LESSEQ, _value_i_58973, _max_58933)){
            goto L12; // [548] 558
        }

        /** parser.e:2718							max = value_i*/
        Ref(_value_i_58973);
        DeRef(_max_58933);
        _max_58933 = _value_i_58973;
L12: 
L10: 
LB: 
        DeRef(_value_i_58973);
        _value_i_58973 = NOVALUE;
        goto L13; // [562] 577
L6: 

        /** parser.e:2723				has_unassigned = 1*/
        _has_unassigned_58939 = 1;

        /** parser.e:2724				exit*/
        goto L2; // [574] 586
L13: 

        /** parser.e:2726		end for*/
        _i_58953 = _i_58953 + 1;
        goto L1; // [581] 123
L2: 
        ;
    }

    /** parser.e:2728		if has_unassigned or has_fwdref then*/
    if (_has_unassigned_58939 != 0) {
        goto L14; // [588] 597
    }
    if (_has_fwdref_58940 == 0)
    {
        goto L15; // [593] 615
    }
    else{
    }
L14: 

    /** parser.e:2729			values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29462 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29462 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _29463 = (object)*(((s1_ptr)_2)->base + _29462);
    DeRef(_values_58927);
    _2 = (object)SEQ_PTR(_29463);
    _values_58927 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_values_58927);
    _29463 = NOVALUE;
L15: 

    /** parser.e:2732		if switch_stack[$][SWITCH_ELSE] then*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29465 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29465 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _29466 = (object)*(((s1_ptr)_2)->base + _29465);
    _2 = (object)SEQ_PTR(_29466);
    _29467 = (object)*(((s1_ptr)_2)->base + 3);
    _29466 = NOVALUE;
    if (_29467 == 0) {
        _29467 = NOVALUE;
        goto L16; // [630] 657
    }
    else {
        if (!IS_ATOM_INT(_29467) && DBL_PTR(_29467)->dbl == 0.0){
            _29467 = NOVALUE;
            goto L16; // [630] 657
        }
        _29467 = NOVALUE;
    }
    _29467 = NOVALUE;

    /** parser.e:2733				Code[else_bp] = switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29468 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29468 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _29469 = (object)*(((s1_ptr)_2)->base + _29468);
    _2 = (object)SEQ_PTR(_29469);
    _29470 = (object)*(((s1_ptr)_2)->base + 3);
    _29469 = NOVALUE;
    Ref(_29470);
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _else_bp_58924);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29470;
    if( _1 != _29470 ){
        DeRef(_1);
    }
    _29470 = NOVALUE;
    goto L17; // [654] 681
L16: 

    /** parser.e:2736			Code[else_bp] = length(Code) + 1 + TRANSLATE*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29471 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29471 = 1;
    }
    _29472 = _29471 + 1;
    _29471 = NOVALUE;
    _29473 = _29472 + _12TRANSLATE_19834;
    _29472 = NOVALUE;
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _else_bp_58924);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29473;
    if( _1 != _29473 ){
        DeRef(_1);
    }
    _29473 = NOVALUE;
L17: 

    /** parser.e:2739		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L18; // [685] 712
    }
    else{
    }

    /** parser.e:2744			SymTab[cases][S_OBJ] &= 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_cases_58925 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29476 = (object)*(((s1_ptr)_2)->base + 1);
    _29474 = NOVALUE;
    if (IS_SEQUENCE(_29476) && IS_ATOM(0)) {
        Append(&_29477, _29476, 0);
    }
    else if (IS_ATOM(_29476) && IS_SEQUENCE(0)) {
    }
    else {
        Concat((object_ptr)&_29477, _29476, 0);
        _29476 = NOVALUE;
    }
    _29476 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29477;
    if( _1 != _29477 ){
        DeRef(_1);
    }
    _29477 = NOVALUE;
    _29474 = NOVALUE;
L18: 

    /** parser.e:2748		integer else_target = Code[else_bp]*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _else_target_59083 = (object)*(((s1_ptr)_2)->base + _else_bp_58924);
    if (!IS_ATOM_INT(_else_target_59083)){
        _else_target_59083 = (object)DBL_PTR(_else_target_59083)->dbl;
    }

    /** parser.e:2749		integer opcode = SWITCH*/
    _opcode_59086 = 185;

    /** parser.e:2750		if has_unassigned or has_fwdref then*/
    if (_has_unassigned_58939 != 0) {
        goto L19; // [733] 742
    }
    if (_has_fwdref_58940 == 0)
    {
        goto L1A; // [738] 754
    }
    else{
    }
L19: 

    /** parser.e:2751			opcode = SWITCH_RT*/
    _opcode_59086 = 202;
    goto L1B; // [751] 907
L1A: 

    /** parser.e:2753		elsif all_ints then*/
    if (_all_ints_58935 == 0)
    {
        goto L1C; // [756] 904
    }
    else{
    }

    /** parser.e:2754			atom delta = max - min*/
    DeRef(_delta_59092);
    if (IS_ATOM_INT(_max_58933) && IS_ATOM_INT(_min_58931)) {
        _delta_59092 = _max_58933 - _min_58931;
        if ((object)((uintptr_t)_delta_59092 +(uintptr_t) HIGH_BITS) >= 0){
            _delta_59092 = NewDouble((eudouble)_delta_59092);
        }
    }
    else {
        if (IS_ATOM_INT(_max_58933)) {
            _delta_59092 = NewDouble((eudouble)_max_58933 - DBL_PTR(_min_58931)->dbl);
        }
        else {
            if (IS_ATOM_INT(_min_58931)) {
                _delta_59092 = NewDouble(DBL_PTR(_max_58933)->dbl - (eudouble)_min_58931);
            }
            else
            _delta_59092 = NewDouble(DBL_PTR(_max_58933)->dbl - DBL_PTR(_min_58931)->dbl);
        }
    }

    /** parser.e:2755			if not TRANSLATE and  delta < 1024 and delta >= 0 then*/
    _29481 = (_12TRANSLATE_19834 == 0);
    if (_29481 == 0) {
        _29482 = 0;
        goto L1D; // [772] 784
    }
    if (IS_ATOM_INT(_delta_59092)) {
        _29483 = (_delta_59092 < 1024);
    }
    else {
        _29483 = (DBL_PTR(_delta_59092)->dbl < (eudouble)1024);
    }
    _29482 = (_29483 != 0);
L1D: 
    if (_29482 == 0) {
        goto L1E; // [784] 893
    }
    if (IS_ATOM_INT(_delta_59092)) {
        _29485 = (_delta_59092 >= 0);
    }
    else {
        _29485 = (DBL_PTR(_delta_59092)->dbl >= (eudouble)0);
    }
    if (_29485 == 0)
    {
        DeRef(_29485);
        _29485 = NOVALUE;
        goto L1E; // [793] 893
    }
    else{
        DeRef(_29485);
        _29485 = NOVALUE;
    }

    /** parser.e:2756				opcode = SWITCH_SPI*/
    _opcode_59086 = 192;

    /** parser.e:2758				sequence switch_table = repeat( else_target, delta + 1 )*/
    if (IS_ATOM_INT(_delta_59092)) {
        _29486 = _delta_59092 + 1;
    }
    else
    _29486 = binary_op(PLUS, 1, _delta_59092);
    DeRef(_switch_table_59102);
    _switch_table_59102 = Repeat(_else_target_59083, _29486);
    DeRef(_29486);
    _29486 = NOVALUE;

    /** parser.e:2759				integer offset = min - 1*/
    if (IS_ATOM_INT(_min_58931)) {
        _offset_59105 = _min_58931 - 1;
    }
    else {
        _offset_59105 = NewDouble(DBL_PTR(_min_58931)->dbl - (eudouble)1);
    }
    if (!IS_ATOM_INT(_offset_59105)) {
        _1 = (object)(DBL_PTR(_offset_59105)->dbl);
        DeRefDS(_offset_59105);
        _offset_59105 = _1;
    }

    /** parser.e:2760				for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_58927)){
            _29489 = SEQ_PTR(_values_58927)->length;
    }
    else {
        _29489 = 1;
    }
    {
        object _i_59108;
        _i_59108 = 1;
L1F: 
        if (_i_59108 > _29489){
            goto L20; // [828] 860
        }

        /** parser.e:2761					switch_table[values[i] - offset] = jump[i]*/
        _2 = (object)SEQ_PTR(_values_58927);
        _29490 = (object)*(((s1_ptr)_2)->base + _i_59108);
        if (IS_ATOM_INT(_29490)) {
            _29491 = _29490 - _offset_59105;
            if ((object)((uintptr_t)_29491 +(uintptr_t) HIGH_BITS) >= 0){
                _29491 = NewDouble((eudouble)_29491);
            }
        }
        else {
            _29491 = binary_op(MINUS, _29490, _offset_59105);
        }
        _29490 = NOVALUE;
        _2 = (object)SEQ_PTR(_jump_58947);
        _29492 = (object)*(((s1_ptr)_2)->base + _i_59108);
        Ref(_29492);
        _2 = (object)SEQ_PTR(_switch_table_59102);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _switch_table_59102 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_29491))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29491)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _29491);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _29492;
        if( _1 != _29492 ){
            DeRef(_1);
        }
        _29492 = NOVALUE;

        /** parser.e:2762				end for*/
        _i_59108 = _i_59108 + 1;
        goto L1F; // [855] 835
L20: 
        ;
    }

    /** parser.e:2763				Code[switch_pc + 2] = offset*/
    _29493 = _switch_pc_58923 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _29493);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _offset_59105;
    DeRef(_1);

    /** parser.e:2764				switch_stack[$][SWITCH_JUMP_TABLE] = switch_table*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29494 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29494 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55201 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29494 + ((s1_ptr)_2)->base);
    RefDS(_switch_table_59102);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _switch_table_59102;
    DeRef(_1);
    _29495 = NOVALUE;
    DeRefDS(_switch_table_59102);
    _switch_table_59102 = NOVALUE;
    goto L21; // [890] 903
L1E: 

    /** parser.e:2766				opcode = SWITCH_I*/
    _opcode_59086 = 193;
L21: 
L1C: 
    DeRef(_delta_59092);
    _delta_59092 = NOVALUE;
L1B: 

    /** parser.e:2770		Code[switch_pc] = opcode*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _switch_pc_58923);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _opcode_59086;
    DeRef(_1);

    /** parser.e:2771		if opcode != SWITCH_SPI then*/
    if (_opcode_59086 == 192)
    goto L22; // [919] 956

    /** parser.e:2772			SymTab[cases][S_OBJ] = values*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_cases_58925 + ((s1_ptr)_2)->base);
    RefDS(_values_58927);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _values_58927;
    DeRef(_1);
    _29498 = NOVALUE;

    /** parser.e:2773			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L23; // [942] 955
    }
    else{
    }

    /** parser.e:2774				update_translator_info( cases, all_ints, has_integer, has_atom, has_sequence )*/
    _43update_translator_info(_cases_58925, _all_ints_58935, _has_integer_58936, _has_atom_58937, _has_sequence_58938);
L23: 
L22: 

    /** parser.e:2779		SymTab[jump_table][S_OBJ] = switch_stack[$][SWITCH_JUMP_TABLE] - switch_pc*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_jump_table_58926 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29502 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29502 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _29503 = (object)*(((s1_ptr)_2)->base + _29502);
    _2 = (object)SEQ_PTR(_29503);
    _29504 = (object)*(((s1_ptr)_2)->base + 2);
    _29503 = NOVALUE;
    if (IS_ATOM_INT(_29504)) {
        _29505 = _29504 - _switch_pc_58923;
        if ((object)((uintptr_t)_29505 +(uintptr_t) HIGH_BITS) >= 0){
            _29505 = NewDouble((eudouble)_29505);
        }
    }
    else {
        _29505 = binary_op(MINUS, _29504, _switch_pc_58923);
    }
    _29504 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29505;
    if( _1 != _29505 ){
        DeRef(_1);
    }
    _29505 = NOVALUE;
    _29500 = NOVALUE;

    /** parser.e:2781	end procedure*/
    DeRef(_values_58927);
    DeRef(_min_58931);
    DeRef(_max_58933);
    DeRef(_unique_values_58941);
    DeRef(_unique_jumps_58943);
    DeRef(_jump_58947);
    DeRef(_29493);
    _29493 = NOVALUE;
    DeRef(_29426);
    _29426 = NOVALUE;
    DeRef(_29481);
    _29481 = NOVALUE;
    DeRef(_29415);
    _29415 = NOVALUE;
    DeRef(_29483);
    _29483 = NOVALUE;
    DeRef(_29491);
    _29491 = NOVALUE;
    _29424 = NOVALUE;
    return;
    ;
}


void _43Switch_statement()
{
    object _else_case_2__tmp_at250_59202 = NOVALUE;
    object _else_case_1__tmp_at250_59201 = NOVALUE;
    object _else_case_inlined_else_case_at_250_59200 = NOVALUE;
    object _break_base_59140 = NOVALUE;
    object _cases_59142 = NOVALUE;
    object _jump_table_59143 = NOVALUE;
    object _else_bp_59144 = NOVALUE;
    object _switch_pc_59145 = NOVALUE;
    object _t_59182 = NOVALUE;
    object _29536 = NOVALUE;
    object _29535 = NOVALUE;
    object _29534 = NOVALUE;
    object _29533 = NOVALUE;
    object _29532 = NOVALUE;
    object _29528 = NOVALUE;
    object _29524 = NOVALUE;
    object _29523 = NOVALUE;
    object _29521 = NOVALUE;
    object _29520 = NOVALUE;
    object _29518 = NOVALUE;
    object _29517 = NOVALUE;
    object _29515 = NOVALUE;
    object _29514 = NOVALUE;
    object _29513 = NOVALUE;
    object _29512 = NOVALUE;
    object _29511 = NOVALUE;
    object _29510 = NOVALUE;
    object _29508 = NOVALUE;
    object _29507 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2786		integer else_bp*/

    /** parser.e:2787		integer switch_pc*/

    /** parser.e:2789		push_switch()*/
    _43push_switch();

    /** parser.e:2790		break_base = length(break_list)*/
    if (IS_SEQUENCE(_43break_list_54970)){
            _break_base_59140 = SEQ_PTR(_43break_list_54970)->length;
    }
    else {
        _break_base_59140 = 1;
    }

    /** parser.e:2792		Expr()*/
    _43Expr();

    /** parser.e:2793		switch_stack[$][SWITCH_VALUE] = Top()*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29507 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29507 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55201 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29507 + ((s1_ptr)_2)->base);
    _29510 = _45Top();
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29510;
    if( _1 != _29510 ){
        DeRef(_1);
    }
    _29510 = NOVALUE;
    _29508 = NOVALUE;

    /** parser.e:2794		clear_temp( switch_stack[$][SWITCH_VALUE] )*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29511 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29511 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _29512 = (object)*(((s1_ptr)_2)->base + _29511);
    _2 = (object)SEQ_PTR(_29512);
    _29513 = (object)*(((s1_ptr)_2)->base + 6);
    _29512 = NOVALUE;
    Ref(_29513);
    _45clear_temp(_29513);
    _29513 = NOVALUE;

    /** parser.e:2796		cases = NewStringSym( {-1, length(SymTab) } )*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _29514 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _29514 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = _29514;
    _29515 = MAKE_SEQ(_1);
    _29514 = NOVALUE;
    _cases_59142 = _53NewStringSym(_29515);
    _29515 = NOVALUE;
    if (!IS_ATOM_INT(_cases_59142)) {
        _1 = (object)(DBL_PTR(_cases_59142)->dbl);
        DeRefDS(_cases_59142);
        _cases_59142 = _1;
    }

    /** parser.e:2798		emit_opnd( cases )*/
    _45emit_opnd(_cases_59142);

    /** parser.e:2800		jump_table = NewStringSym( {-2, length(SymTab) } )*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _29517 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _29517 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -2;
    ((intptr_t *)_2)[2] = _29517;
    _29518 = MAKE_SEQ(_1);
    _29517 = NOVALUE;
    _jump_table_59143 = _53NewStringSym(_29518);
    _29518 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_59143)) {
        _1 = (object)(DBL_PTR(_jump_table_59143)->dbl);
        DeRefDS(_jump_table_59143);
        _jump_table_59143 = _1;
    }

    /** parser.e:2801		emit_opnd( jump_table )*/
    _45emit_opnd(_jump_table_59143);

    /** parser.e:2803		if finish_block_header(SWITCH) then end if*/
    _29520 = _43finish_block_header(185);
    if (_29520 == 0) {
        DeRef(_29520);
        _29520 = NOVALUE;
        goto L1; // [109] 113
    }
    else {
        if (!IS_ATOM_INT(_29520) && DBL_PTR(_29520)->dbl == 0.0){
            DeRef(_29520);
            _29520 = NOVALUE;
            goto L1; // [109] 113
        }
        DeRef(_29520);
        _29520 = NOVALUE;
    }
    DeRef(_29520);
    _29520 = NOVALUE;
L1: 

    /** parser.e:2805		switch_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29521 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29521 = 1;
    }
    _switch_pc_59145 = _29521 + 1;
    _29521 = NOVALUE;

    /** parser.e:2806		switch_stack[$][SWITCH_PC] = switch_pc*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29523 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29523 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55201 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29523 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _switch_pc_59145;
    DeRef(_1);
    _29524 = NOVALUE;

    /** parser.e:2808		emit_op(SWITCH)*/
    _45emit_op(185);

    /** parser.e:2809		emit_forward_addr()  -- the else*/
    _43emit_forward_addr();

    /** parser.e:2810		else_bp = length( Code )*/
    if (IS_SEQUENCE(_12Code_20315)){
            _else_bp_59144 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _else_bp_59144 = 1;
    }

    /** parser.e:2813		t = next_token()*/
    _0 = _t_59182;
    _t_59182 = _43next_token();
    DeRef(_0);

    /** parser.e:2814		if t[T_ID] = CASE then*/
    _2 = (object)SEQ_PTR(_t_59182);
    _29528 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29528, 186)){
        _29528 = NOVALUE;
        goto L2; // [173] 188
    }
    _29528 = NOVALUE;

    /** parser.e:2816			Case_statement()*/
    _43Case_statement();

    /** parser.e:2818			Statement_list()*/
    _43Statement_list();
    goto L3; // [185] 194
L2: 

    /** parser.e:2821			putback(t)*/
    Ref(_t_59182);
    _43putback(_t_59182);
L3: 

    /** parser.e:2824		optimize_switch( switch_pc, else_bp, cases, jump_table )*/
    _43optimize_switch(_switch_pc_59145, _else_bp_59144, _cases_59142, _jump_table_59143);

    /** parser.e:2825		tok_match(END)*/
    _43tok_match(402, 0);

    /** parser.e:2826		tok_match(SWITCH, END)*/
    _43tok_match(185, 402);

    /** parser.e:2827		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L4; // [224] 235
    }
    else{
    }

    /** parser.e:2828			emit_op(NOPSWITCH)*/
    _45emit_op(187);
L4: 

    /** parser.e:2831		if not else_case() then*/

    /** parser.e:2472		return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _else_case_1__tmp_at250_59201 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _else_case_1__tmp_at250_59201 = 1;
    }
    DeRef(_else_case_2__tmp_at250_59202);
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _else_case_2__tmp_at250_59202 = (object)*(((s1_ptr)_2)->base + _else_case_1__tmp_at250_59201);
    RefDS(_else_case_2__tmp_at250_59202);
    DeRef(_else_case_inlined_else_case_at_250_59200);
    _2 = (object)SEQ_PTR(_else_case_2__tmp_at250_59202);
    _else_case_inlined_else_case_at_250_59200 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_else_case_inlined_else_case_at_250_59200);
    DeRef(_else_case_2__tmp_at250_59202);
    _else_case_2__tmp_at250_59202 = NOVALUE;
    if (IS_ATOM_INT(_else_case_inlined_else_case_at_250_59200)) {
        if (_else_case_inlined_else_case_at_250_59200 != 0){
            goto L5; // [255] 327
        }
    }
    else {
        if (DBL_PTR(_else_case_inlined_else_case_at_250_59200)->dbl != 0.0){
            goto L5; // [255] 327
        }
    }

    /** parser.e:2832			if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto L6; // [262] 303

    /** parser.e:2833				StartSourceLine( TRUE, , COVERAGE_SUPPRESS )*/
    _45StartSourceLine(_9TRUE_446, 0, 1);

    /** parser.e:2834				emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_43switch_stack_55201)){
            _29532 = SEQ_PTR(_43switch_stack_55201)->length;
    }
    else {
        _29532 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55201);
    _29533 = (object)*(((s1_ptr)_2)->base + _29532);
    _2 = (object)SEQ_PTR(_29533);
    _29534 = (object)*(((s1_ptr)_2)->base + 6);
    _29533 = NOVALUE;
    Ref(_29534);
    _45emit_temp(_29534, 1);
    _29534 = NOVALUE;

    /** parser.e:2835				flush_temps()*/
    RefDS(_22015);
    _45flush_temps(_22015);
L6: 

    /** parser.e:2838			Warning(221, no_case_else_warning_flag,*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _29535 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    Ref(_29535);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _29535;
    ((intptr_t *)_2)[2] = _12line_number_20227;
    _29536 = MAKE_SEQ(_1);
    _29535 = NOVALUE;
    _49Warning(221, 4096, _29536);
    _29536 = NOVALUE;
L5: 

    /** parser.e:2841		pop_switch( break_base )*/
    _43pop_switch(_break_base_59140);

    /** parser.e:2842	end procedure*/
    DeRef(_t_59182);
    return;
    ;
}


object _43get_private_uninitialized()
{
    object _uninitialized_59225 = NOVALUE;
    object _s_59231 = NOVALUE;
    object _pu_59237 = NOVALUE;
    object _29553 = NOVALUE;
    object _29551 = NOVALUE;
    object _29550 = NOVALUE;
    object _29549 = NOVALUE;
    object _29548 = NOVALUE;
    object _29547 = NOVALUE;
    object _29546 = NOVALUE;
    object _29545 = NOVALUE;
    object _29544 = NOVALUE;
    object _29543 = NOVALUE;
    object _29542 = NOVALUE;
    object _29541 = NOVALUE;
    object _29538 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2845		sequence uninitialized = {}*/
    RefDS(_22015);
    DeRefi(_uninitialized_59225);
    _uninitialized_59225 = _22015;

    /** parser.e:2846		if CurrentSub != TopLevelSub then*/
    if (_12CurrentSub_20234 == _12TopLevelSub_20233)
    goto L1; // [14] 149

    /** parser.e:2847			symtab_pointer s = SymTab[CurrentSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29538 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_29538);
    _s_59231 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_59231)){
        _s_59231 = (object)DBL_PTR(_s_59231)->dbl;
    }
    _29538 = NOVALUE;

    /** parser.e:2848			sequence pu = { SC_PRIVATE, SC_UNDEFINED }*/
    DeRefi(_pu_59237);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 3;
    ((intptr_t *)_2)[2] = 9;
    _pu_59237 = MAKE_SEQ(_1);

    /** parser.e:2849			while s and find( SymTab[s][S_SCOPE], pu ) do*/
L2: 
    if (_s_59231 == 0) {
        goto L3; // [51] 148
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29542 = (object)*(((s1_ptr)_2)->base + _s_59231);
    _2 = (object)SEQ_PTR(_29542);
    _29543 = (object)*(((s1_ptr)_2)->base + 4);
    _29542 = NOVALUE;
    _29544 = find_from(_29543, _pu_59237, 1);
    _29543 = NOVALUE;
    if (_29544 == 0)
    {
        _29544 = NOVALUE;
        goto L3; // [73] 148
    }
    else{
        _29544 = NOVALUE;
    }

    /** parser.e:2850				if SymTab[s][S_SCOPE] = SC_PRIVATE and SymTab[s][S_INITLEVEL] = -1 then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29545 = (object)*(((s1_ptr)_2)->base + _s_59231);
    _2 = (object)SEQ_PTR(_29545);
    _29546 = (object)*(((s1_ptr)_2)->base + 4);
    _29545 = NOVALUE;
    if (IS_ATOM_INT(_29546)) {
        _29547 = (_29546 == 3);
    }
    else {
        _29547 = binary_op(EQUALS, _29546, 3);
    }
    _29546 = NOVALUE;
    if (IS_ATOM_INT(_29547)) {
        if (_29547 == 0) {
            goto L4; // [96] 127
        }
    }
    else {
        if (DBL_PTR(_29547)->dbl == 0.0) {
            goto L4; // [96] 127
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29549 = (object)*(((s1_ptr)_2)->base + _s_59231);
    _2 = (object)SEQ_PTR(_29549);
    _29550 = (object)*(((s1_ptr)_2)->base + 14);
    _29549 = NOVALUE;
    if (IS_ATOM_INT(_29550)) {
        _29551 = (_29550 == -1);
    }
    else {
        _29551 = binary_op(EQUALS, _29550, -1);
    }
    _29550 = NOVALUE;
    if (_29551 == 0) {
        DeRef(_29551);
        _29551 = NOVALUE;
        goto L4; // [117] 127
    }
    else {
        if (!IS_ATOM_INT(_29551) && DBL_PTR(_29551)->dbl == 0.0){
            DeRef(_29551);
            _29551 = NOVALUE;
            goto L4; // [117] 127
        }
        DeRef(_29551);
        _29551 = NOVALUE;
    }
    DeRef(_29551);
    _29551 = NOVALUE;

    /** parser.e:2851					uninitialized &= s*/
    Append(&_uninitialized_59225, _uninitialized_59225, _s_59231);
L4: 

    /** parser.e:2853				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29553 = (object)*(((s1_ptr)_2)->base + _s_59231);
    _2 = (object)SEQ_PTR(_29553);
    _s_59231 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_59231)){
        _s_59231 = (object)DBL_PTR(_s_59231)->dbl;
    }
    _29553 = NOVALUE;

    /** parser.e:2854			end while*/
    goto L2; // [145] 51
L3: 
L1: 
    DeRefi(_pu_59237);
    _pu_59237 = NOVALUE;

    /** parser.e:2856		return uninitialized*/
    DeRef(_29547);
    _29547 = NOVALUE;
    return _uninitialized_59225;
    ;
}


void _43While_statement()
{
    object _bp1_59268 = NOVALUE;
    object _bp2_59269 = NOVALUE;
    object _exit_base_59270 = NOVALUE;
    object _next_base_59271 = NOVALUE;
    object _uninitialized_59272 = NOVALUE;
    object _temps_59342 = NOVALUE;
    object _29589 = NOVALUE;
    object _29588 = NOVALUE;
    object _29587 = NOVALUE;
    object _29583 = NOVALUE;
    object _29582 = NOVALUE;
    object _29580 = NOVALUE;
    object _29578 = NOVALUE;
    object _29577 = NOVALUE;
    object _29576 = NOVALUE;
    object _29572 = NOVALUE;
    object _29570 = NOVALUE;
    object _29568 = NOVALUE;
    object _29562 = NOVALUE;
    object _29560 = NOVALUE;
    object _29559 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2865		sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_59272;
    _uninitialized_59272 = _43get_private_uninitialized();
    DeRef(_0);

    /** parser.e:2867		entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_59272);
    Append(&_43entry_stack_54979, _43entry_stack_54979, _uninitialized_59272);

    /** parser.e:2869		Start_block( WHILE )*/
    _64Start_block(47, 0);

    /** parser.e:2871		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_54972)){
            _exit_base_59270 = SEQ_PTR(_43exit_list_54972)->length;
    }
    else {
        _exit_base_59270 = 1;
    }

    /** parser.e:2872		next_base = length(continue_list)*/
    if (IS_SEQUENCE(_43continue_list_54974)){
            _next_base_59271 = SEQ_PTR(_43continue_list_54974)->length;
    }
    else {
        _next_base_59271 = 1;
    }

    /** parser.e:2873		entry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29559 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29559 = 1;
    }
    _29560 = _29559 + 1;
    _29559 = NOVALUE;
    Append(&_43entry_addr_54976, _43entry_addr_54976, _29560);
    _29560 = NOVALUE;

    /** parser.e:2874		emit_op(NOP2) -- Entry_statement may patch this later*/
    _45emit_op(110);

    /** parser.e:2875		emit_addr(0)*/
    _45emit_addr(0);

    /** parser.e:2876		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L1; // [71] 82
    }
    else{
    }

    /** parser.e:2877			emit_op(NOPWHILE)*/
    _45emit_op(158);
L1: 

    /** parser.e:2879		bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29562 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29562 = 1;
    }
    _bp1_59268 = _29562 + 1;
    _29562 = NOVALUE;

    /** parser.e:2880		continue_addr &= bp1*/
    Append(&_43continue_addr_54977, _43continue_addr_54977, _bp1_59268);

    /** parser.e:2881		short_circuit += 1*/
    _43short_circuit_54952 = _43short_circuit_54952 + 1;

    /** parser.e:2882		short_circuit_B = FALSE*/
    _43short_circuit_B_54954 = _9FALSE_444;

    /** parser.e:2883		SC1_type = 0*/
    _43SC1_type_54957 = 0;

    /** parser.e:2884		Expr()*/
    _43Expr();

    /** parser.e:2885		optimized_while = FALSE*/
    _45optimized_while_50962 = _9FALSE_444;

    /** parser.e:2886		emit_op(WHILE)*/
    _45emit_op(47);

    /** parser.e:2887		short_circuit -= 1*/
    _43short_circuit_54952 = _43short_circuit_54952 - 1;

    /** parser.e:2888		if not optimized_while then*/
    if (_45optimized_while_50962 != 0)
    goto L2; // [153] 174

    /** parser.e:2890			bp2 = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29568 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29568 = 1;
    }
    _bp2_59269 = _29568 + 1;
    _29568 = NOVALUE;

    /** parser.e:2891			emit_forward_addr() -- will be patched*/
    _43emit_forward_addr();
    goto L3; // [171] 180
L2: 

    /** parser.e:2893			bp2 = 0*/
    _bp2_59269 = 0;
L3: 

    /** parser.e:2895		if finish_block_header(WHILE)=0 then*/
    _29570 = _43finish_block_header(47);
    if (binary_op_a(NOTEQ, _29570, 0)){
        DeRef(_29570);
        _29570 = NOVALUE;
        goto L4; // [188] 204
    }
    DeRef(_29570);
    _29570 = NOVALUE;

    /** parser.e:2896			entry_addr[$]=-1*/
    if (IS_SEQUENCE(_43entry_addr_54976)){
            _29572 = SEQ_PTR(_43entry_addr_54976)->length;
    }
    else {
        _29572 = 1;
    }
    _2 = (object)SEQ_PTR(_43entry_addr_54976);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43entry_addr_54976 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _29572);
    *(intptr_t *)_2 = -1;
L4: 

    /** parser.e:2899		loop_stack &= WHILE*/
    Append(&_43loop_stack_54986, _43loop_stack_54986, 47);

    /** parser.e:2901		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_54972)){
            _exit_base_59270 = SEQ_PTR(_43exit_list_54972)->length;
    }
    else {
        _exit_base_59270 = 1;
    }

    /** parser.e:2902		if SC1_type = OR then*/
    if (_43SC1_type_54957 != 9)
    goto L5; // [227] 280

    /** parser.e:2903			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29576 = _43SC1_patch_54956 - 3;
    if ((object)((uintptr_t)_29576 +(uintptr_t) HIGH_BITS) >= 0){
        _29576 = NewDouble((eudouble)_29576);
    }
    _45backpatch(_29576, 147);
    _29576 = NOVALUE;

    /** parser.e:2904			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L6; // [249] 260
    }
    else{
    }

    /** parser.e:2905				emit_op(NOP1)*/
    _45emit_op(159);
L6: 

    /** parser.e:2907			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29577 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29577 = 1;
    }
    _29578 = _29577 + 1;
    _29577 = NOVALUE;
    _45backpatch(_43SC1_patch_54956, _29578);
    _29578 = NOVALUE;
    goto L7; // [277] 331
L5: 

    /** parser.e:2908		elsif SC1_type = AND then*/
    if (_43SC1_type_54957 != 8)
    goto L8; // [286] 330

    /** parser.e:2909			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29580 = _43SC1_patch_54956 - 3;
    if ((object)((uintptr_t)_29580 +(uintptr_t) HIGH_BITS) >= 0){
        _29580 = NewDouble((eudouble)_29580);
    }
    _45backpatch(_29580, 146);
    _29580 = NOVALUE;

    /** parser.e:2910			AppendXList(SC1_patch)*/

    /** parser.e:398		exit_list = append(exit_list, addr)*/
    Append(&_43exit_list_54972, _43exit_list_54972, _43SC1_patch_54956);

    /** parser.e:399	end procedure*/
    goto L9; // [318] 321
L9: 

    /** parser.e:2911			exit_delay &= 1*/
    Append(&_43exit_delay_54973, _43exit_delay_54973, 1);
L8: 
L7: 

    /** parser.e:2913		retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29582 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29582 = 1;
    }
    _29583 = _29582 + 1;
    _29582 = NOVALUE;
    Append(&_43retry_addr_54978, _43retry_addr_54978, _29583);
    _29583 = NOVALUE;

    /** parser.e:2915		sequence temps = pop_temps()*/
    _0 = _temps_59342;
    _temps_59342 = _45pop_temps();
    DeRef(_0);

    /** parser.e:2917		push_temps( temps )*/
    RefDS(_temps_59342);
    _45push_temps(_temps_59342);

    /** parser.e:2919		Statement_list()*/
    _43Statement_list();

    /** parser.e:2920		PatchNList(next_base)*/
    _43PatchNList(_next_base_59271);

    /** parser.e:2921		tok_match(END)*/
    _43tok_match(402, 0);

    /** parser.e:2922		tok_match(WHILE, END)*/
    _43tok_match(47, 402);

    /** parser.e:2924		End_block( WHILE )*/
    _64End_block(47);

    /** parser.e:2926		StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:2927		emit_op(ENDWHILE)*/
    _45emit_op(22);

    /** parser.e:2928		emit_addr(bp1)*/
    _45emit_addr(_bp1_59268);

    /** parser.e:2929		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto LA; // [419] 430
    }
    else{
    }

    /** parser.e:2930			emit_op(NOP1)*/
    _45emit_op(159);
LA: 

    /** parser.e:2932		if bp2 != 0 then*/
    if (_bp2_59269 == 0)
    goto LB; // [434] 454

    /** parser.e:2933			backpatch(bp2, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29587 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29587 = 1;
    }
    _29588 = _29587 + 1;
    _29587 = NOVALUE;
    _45backpatch(_bp2_59269, _29588);
    _29588 = NOVALUE;
LB: 

    /** parser.e:2935		exit_loop(exit_base)*/
    _43exit_loop(_exit_base_59270);

    /** parser.e:2936		entry_stack = remove( entry_stack, length( entry_stack ) )*/
    if (IS_SEQUENCE(_43entry_stack_54979)){
            _29589 = SEQ_PTR(_43entry_stack_54979)->length;
    }
    else {
        _29589 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_43entry_stack_54979);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_29589)) ? _29589 : (object)(DBL_PTR(_29589)->dbl);
        int stop = (IS_ATOM_INT(_29589)) ? _29589 : (object)(DBL_PTR(_29589)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43entry_stack_54979), start, &_43entry_stack_54979 );
            }
            else Tail(SEQ_PTR(_43entry_stack_54979), stop+1, &_43entry_stack_54979);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43entry_stack_54979), start, &_43entry_stack_54979);
        }
        else {
            assign_slice_seq = &assign_space;
            _43entry_stack_54979 = Remove_elements(start, stop, (SEQ_PTR(_43entry_stack_54979)->ref == 1));
        }
    }
    _29589 = NOVALUE;
    _29589 = NOVALUE;

    /** parser.e:2937		push_temps( temps )*/
    RefDS(_temps_59342);
    _45push_temps(_temps_59342);

    /** parser.e:2938	end procedure*/
    DeRef(_uninitialized_59272);
    DeRefDS(_temps_59342);
    return;
    ;
}


void _43Loop_statement()
{
    object _bp1_59372 = NOVALUE;
    object _exit_base_59373 = NOVALUE;
    object _next_base_59374 = NOVALUE;
    object _t_59376 = NOVALUE;
    object _uninitialized_59379 = NOVALUE;
    object _29613 = NOVALUE;
    object _29611 = NOVALUE;
    object _29610 = NOVALUE;
    object _29609 = NOVALUE;
    object _29603 = NOVALUE;
    object _29602 = NOVALUE;
    object _29600 = NOVALUE;
    object _29597 = NOVALUE;
    object _29596 = NOVALUE;
    object _29595 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2946		Start_block( LOOP )*/
    _64Start_block(422, 0);

    /** parser.e:2948		sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_59379;
    _uninitialized_59379 = _43get_private_uninitialized();
    DeRef(_0);

    /** parser.e:2949		entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_59379);
    Append(&_43entry_stack_54979, _43entry_stack_54979, _uninitialized_59379);

    /** parser.e:2951		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_54972)){
            _exit_base_59373 = SEQ_PTR(_43exit_list_54972)->length;
    }
    else {
        _exit_base_59373 = 1;
    }

    /** parser.e:2952		next_base = length(continue_list)*/
    if (IS_SEQUENCE(_43continue_list_54974)){
            _next_base_59374 = SEQ_PTR(_43continue_list_54974)->length;
    }
    else {
        _next_base_59374 = 1;
    }

    /** parser.e:2953		emit_op(NOP2) -- Entry_statement() may patch this*/
    _45emit_op(110);

    /** parser.e:2954		emit_addr(0)*/
    _45emit_addr(0);

    /** parser.e:2955		if finish_block_header(LOOP) then*/
    _29595 = _43finish_block_header(422);
    if (_29595 == 0) {
        DeRef(_29595);
        _29595 = NOVALUE;
        goto L1; // [58] 81
    }
    else {
        if (!IS_ATOM_INT(_29595) && DBL_PTR(_29595)->dbl == 0.0){
            DeRef(_29595);
            _29595 = NOVALUE;
            goto L1; // [58] 81
        }
        DeRef(_29595);
        _29595 = NOVALUE;
    }
    DeRef(_29595);
    _29595 = NOVALUE;

    /** parser.e:2956		    entry_addr &= length(Code)-1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29596 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29596 = 1;
    }
    _29597 = _29596 - 1;
    _29596 = NOVALUE;
    Append(&_43entry_addr_54976, _43entry_addr_54976, _29597);
    _29597 = NOVALUE;
    goto L2; // [78] 90
L1: 

    /** parser.e:2958			entry_addr &= -1*/
    Append(&_43entry_addr_54976, _43entry_addr_54976, -1);
L2: 

    /** parser.e:2962		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L3; // [94] 105
    }
    else{
    }

    /** parser.e:2963			emit_op(NOP1)*/
    _45emit_op(159);
L3: 

    /** parser.e:2965		bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29600 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29600 = 1;
    }
    _bp1_59372 = _29600 + 1;
    _29600 = NOVALUE;

    /** parser.e:2966		retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29602 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29602 = 1;
    }
    _29603 = _29602 + 1;
    _29602 = NOVALUE;
    Append(&_43retry_addr_54978, _43retry_addr_54978, _29603);
    _29603 = NOVALUE;

    /** parser.e:2967		continue_addr &= 0*/
    Append(&_43continue_addr_54977, _43continue_addr_54977, 0);

    /** parser.e:2968		loop_stack &= LOOP*/
    Append(&_43loop_stack_54986, _43loop_stack_54986, 422);

    /** parser.e:2970		Statement_list()*/
    _43Statement_list();

    /** parser.e:2972		End_block( LOOP )*/
    _64End_block(422);

    /** parser.e:2974		tok_match(UNTIL)*/
    _43tok_match(423, 0);

    /** parser.e:2975		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L4; // [174] 185
    }
    else{
    }

    /** parser.e:2976			emit_op(NOP1)*/
    _45emit_op(159);
L4: 

    /** parser.e:2978		PatchNList(next_base)*/
    _43PatchNList(_next_base_59374);

    /** parser.e:2979		StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:2980		short_circuit += 1*/
    _43short_circuit_54952 = _43short_circuit_54952 + 1;

    /** parser.e:2981		short_circuit_B = FALSE*/
    _43short_circuit_B_54954 = _9FALSE_444;

    /** parser.e:2982		SC1_type = 0*/
    _43SC1_type_54957 = 0;

    /** parser.e:2983		Expr()*/
    _43Expr();

    /** parser.e:2984		if SC1_type = OR then*/
    if (_43SC1_type_54957 != 9)
    goto L5; // [229] 282

    /** parser.e:2985			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29609 = _43SC1_patch_54956 - 3;
    if ((object)((uintptr_t)_29609 +(uintptr_t) HIGH_BITS) >= 0){
        _29609 = NewDouble((eudouble)_29609);
    }
    _45backpatch(_29609, 147);
    _29609 = NOVALUE;

    /** parser.e:2986			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L6; // [251] 262
    }
    else{
    }

    /** parser.e:2987			    emit_op(NOP1)  -- to get label here*/
    _45emit_op(159);
L6: 

    /** parser.e:2989			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29610 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29610 = 1;
    }
    _29611 = _29610 + 1;
    _29610 = NOVALUE;
    _45backpatch(_43SC1_patch_54956, _29611);
    _29611 = NOVALUE;
    goto L7; // [279] 308
L5: 

    /** parser.e:2990		elsif SC1_type = AND then*/
    if (_43SC1_type_54957 != 8)
    goto L8; // [288] 307

    /** parser.e:2991			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29613 = _43SC1_patch_54956 - 3;
    if ((object)((uintptr_t)_29613 +(uintptr_t) HIGH_BITS) >= 0){
        _29613 = NewDouble((eudouble)_29613);
    }
    _45backpatch(_29613, 146);
    _29613 = NOVALUE;
L8: 
L7: 

    /** parser.e:2993		short_circuit -= 1*/
    _43short_circuit_54952 = _43short_circuit_54952 - 1;

    /** parser.e:2994		emit_op(IF)*/
    _45emit_op(20);

    /** parser.e:2995		emit_addr(bp1)*/
    _45emit_addr(_bp1_59372);

    /** parser.e:2996		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L9; // [332] 343
    }
    else{
    }

    /** parser.e:2997			emit_op(NOP1)*/
    _45emit_op(159);
L9: 

    /** parser.e:2999		exit_loop(exit_base)*/
    _43exit_loop(_exit_base_59373);

    /** parser.e:3001		tok_match(END)*/
    _43tok_match(402, 0);

    /** parser.e:3002		tok_match(LOOP, END)*/
    _43tok_match(422, 402);

    /** parser.e:3004	end procedure*/
    DeRef(_uninitialized_59379);
    return;
    ;
}


void _43Ifdef_statement()
{
    object _option_59458 = NOVALUE;
    object _matched_59459 = NOVALUE;
    object _has_matched_59460 = NOVALUE;
    object _in_matched_59461 = NOVALUE;
    object _dead_ifdef_59462 = NOVALUE;
    object _in_elsedef_59463 = NOVALUE;
    object _tok_59465 = NOVALUE;
    object _keyw_59466 = NOVALUE;
    object _parser_id_59470 = NOVALUE;
    object _negate_59486 = NOVALUE;
    object _conjunction_59487 = NOVALUE;
    object _at_start_59488 = NOVALUE;
    object _prev_conj_59489 = NOVALUE;
    object _this_matched_59574 = NOVALUE;
    object _gotword_59590 = NOVALUE;
    object _gotthen_59591 = NOVALUE;
    object _if_lvl_59592 = NOVALUE;
    object _29730 = NOVALUE;
    object _29729 = NOVALUE;
    object _29725 = NOVALUE;
    object _29723 = NOVALUE;
    object _29720 = NOVALUE;
    object _29718 = NOVALUE;
    object _29717 = NOVALUE;
    object _29713 = NOVALUE;
    object _29710 = NOVALUE;
    object _29707 = NOVALUE;
    object _29703 = NOVALUE;
    object _29701 = NOVALUE;
    object _29700 = NOVALUE;
    object _29699 = NOVALUE;
    object _29698 = NOVALUE;
    object _29697 = NOVALUE;
    object _29696 = NOVALUE;
    object _29695 = NOVALUE;
    object _29691 = NOVALUE;
    object _29688 = NOVALUE;
    object _29687 = NOVALUE;
    object _29686 = NOVALUE;
    object _29682 = NOVALUE;
    object _29681 = NOVALUE;
    object _29680 = NOVALUE;
    object _29677 = NOVALUE;
    object _29674 = NOVALUE;
    object _29673 = NOVALUE;
    object _29672 = NOVALUE;
    object _29670 = NOVALUE;
    object _29659 = NOVALUE;
    object _29657 = NOVALUE;
    object _29656 = NOVALUE;
    object _29655 = NOVALUE;
    object _29654 = NOVALUE;
    object _29653 = NOVALUE;
    object _29652 = NOVALUE;
    object _29651 = NOVALUE;
    object _29648 = NOVALUE;
    object _29647 = NOVALUE;
    object _29645 = NOVALUE;
    object _29643 = NOVALUE;
    object _29642 = NOVALUE;
    object _29640 = NOVALUE;
    object _29638 = NOVALUE;
    object _29637 = NOVALUE;
    object _29635 = NOVALUE;
    object _29634 = NOVALUE;
    object _29633 = NOVALUE;
    object _29630 = NOVALUE;
    object _29628 = NOVALUE;
    object _29625 = NOVALUE;
    object _29624 = NOVALUE;
    object _29623 = NOVALUE;
    object _29621 = NOVALUE;
    object _29619 = NOVALUE;
    object _29618 = NOVALUE;
    object _29617 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3012		integer matched = 0, has_matched = 0,  in_matched = 0, dead_ifdef = 0, in_elsedef = 0*/
    _matched_59459 = 0;
    _has_matched_59460 = 0;
    _in_matched_59461 = 0;
    _dead_ifdef_59462 = 0;
    _in_elsedef_59463 = 0;

    /** parser.e:3014		sequence keyw ="ifdef"*/
    RefDS(_26228);
    DeRefi(_keyw_59466);
    _keyw_59466 = _26228;

    /** parser.e:3016		live_ifdef += 1*/
    _43live_ifdef_59454 = _43live_ifdef_59454 + 1;

    /** parser.e:3017		ifdef_lineno &= line_number*/
    Append(&_43ifdef_lineno_59455, _43ifdef_lineno_59455, _12line_number_20227);

    /** parser.e:3019		integer parser_id*/

    /** parser.e:3020		if CurrentSub != TopLevelSub or length(if_labels) or length(loop_labels) then*/
    _29617 = (_12CurrentSub_20234 != _12TopLevelSub_20233);
    if (_29617 != 0) {
        _29618 = 1;
        goto L1; // [55] 68
    }
    if (IS_SEQUENCE(_43if_labels_54981)){
            _29619 = SEQ_PTR(_43if_labels_54981)->length;
    }
    else {
        _29619 = 1;
    }
    _29618 = (_29619 != 0);
L1: 
    if (_29618 != 0) {
        goto L2; // [68] 82
    }
    if (IS_SEQUENCE(_43loop_labels_54980)){
            _29621 = SEQ_PTR(_43loop_labels_54980)->length;
    }
    else {
        _29621 = 1;
    }
    if (_29621 == 0)
    {
        _29621 = NOVALUE;
        goto L3; // [78] 92
    }
    else{
        _29621 = NOVALUE;
    }
L2: 

    /** parser.e:3021			parser_id = forward_Statement_list*/
    _parser_id_59470 = _43forward_Statement_list_58196;
    goto L4; // [89] 100
L3: 

    /** parser.e:3023			parser_id = top_level_parser*/
    _parser_id_59470 = _43top_level_parser_59453;
L4: 

    /** parser.e:3026		while 1 label "top" do*/
L5: 

    /** parser.e:3027			if matched = 0 and in_elsedef = 0 then*/
    _29623 = (_matched_59459 == 0);
    if (_29623 == 0) {
        goto L6; // [111] 656
    }
    _29625 = (_in_elsedef_59463 == 0);
    if (_29625 == 0)
    {
        DeRef(_29625);
        _29625 = NOVALUE;
        goto L6; // [120] 656
    }
    else{
        DeRef(_29625);
        _29625 = NOVALUE;
    }

    /** parser.e:3028				integer negate = 0, conjunction = 0*/
    _negate_59486 = 0;
    _conjunction_59487 = 0;

    /** parser.e:3029				integer at_start = 1*/
    _at_start_59488 = 1;

    /** parser.e:3030				sequence prev_conj = ""*/
    RefDS(_22015);
    DeRef(_prev_conj_59489);
    _prev_conj_59489 = _22015;

    /** parser.e:3032				while 1 label "deflist" do*/
L7: 

    /** parser.e:3033					option = StringToken()*/
    RefDS(_5);
    _0 = _option_59458;
    _option_59458 = _61StringToken(_5);
    DeRef(_0);

    /** parser.e:3034					if equal(option, "then") then*/
    if (_option_59458 == _26295)
    _29628 = 1;
    else if (IS_ATOM_INT(_option_59458) && IS_ATOM_INT(_26295))
    _29628 = 0;
    else
    _29628 = (compare(_option_59458, _26295) == 0);
    if (_29628 == 0)
    {
        _29628 = NOVALUE;
        goto L8; // [162] 240
    }
    else{
        _29628 = NOVALUE;
    }

    /** parser.e:3035						if at_start = 1 then*/
    if (_at_start_59488 != 1)
    goto L9; // [167] 187

    /** parser.e:3036							CompileErr(MSG_1_IS_MISSING_DEFINED_WORD_BEFORE_THEN, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59466);
    ((intptr_t*)_2)[1] = _keyw_59466;
    _29630 = MAKE_SEQ(_1);
    _49CompileErr(6, _29630, 0);
    _29630 = NOVALUE;
    goto LA; // [184] 542
L9: 

    /** parser.e:3037						elsif conjunction = 0 then*/
    if (_conjunction_59487 != 0)
    goto LB; // [189] 223

    /** parser.e:3038							if negate = 0 then*/
    if (_negate_59486 != 0)
    goto LC; // [195] 206

    /** parser.e:3039								exit "deflist"*/
    goto LD; // [201] 630
    goto LA; // [203] 542
LC: 

    /** parser.e:3041								CompileErr(MSG_1_THEN_FOLLOWS_NOT, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59466);
    ((intptr_t*)_2)[1] = _keyw_59466;
    _29633 = MAKE_SEQ(_1);
    _49CompileErr(11, _29633, 0);
    _29633 = NOVALUE;
    goto LA; // [220] 542
LB: 

    /** parser.e:3044							CompileErr(MSG_1_THEN_FOLLOWS_2, {keyw, prev_conj})*/
    RefDS(_prev_conj_59489);
    RefDS(_keyw_59466);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _keyw_59466;
    ((intptr_t *)_2)[2] = _prev_conj_59489;
    _29634 = MAKE_SEQ(_1);
    _49CompileErr(8, _29634, 0);
    _29634 = NOVALUE;
    goto LA; // [237] 542
L8: 

    /** parser.e:3046					elsif equal(option, "not") then*/
    if (_option_59458 == _26256)
    _29635 = 1;
    else if (IS_ATOM_INT(_option_59458) && IS_ATOM_INT(_26256))
    _29635 = 0;
    else
    _29635 = (compare(_option_59458, _26256) == 0);
    if (_29635 == 0)
    {
        _29635 = NOVALUE;
        goto LE; // [246] 284
    }
    else{
        _29635 = NOVALUE;
    }

    /** parser.e:3047						if negate = 0 then*/
    if (_negate_59486 != 0)
    goto LF; // [251] 267

    /** parser.e:3048							negate = 1*/
    _negate_59486 = 1;

    /** parser.e:3049							continue "deflist"*/
    goto L7; // [262] 148
    goto LA; // [264] 542
LF: 

    /** parser.e:3051							CompileErr(MSG_1_DUPLICATE_NOT, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59466);
    ((intptr_t*)_2)[1] = _keyw_59466;
    _29637 = MAKE_SEQ(_1);
    _49CompileErr(7, _29637, 0);
    _29637 = NOVALUE;
    goto LA; // [281] 542
LE: 

    /** parser.e:3053					elsif equal(option, "and") then*/
    if (_option_59458 == _26160)
    _29638 = 1;
    else if (IS_ATOM_INT(_option_59458) && IS_ATOM_INT(_26160))
    _29638 = 0;
    else
    _29638 = (compare(_option_59458, _26160) == 0);
    if (_29638 == 0)
    {
        _29638 = NOVALUE;
        goto L10; // [290] 357
    }
    else{
        _29638 = NOVALUE;
    }

    /** parser.e:3054						if at_start = 1 then*/
    if (_at_start_59488 != 1)
    goto L11; // [295] 315

    /** parser.e:3055							CompileErr(MSG_1_IS_MISSING_DEFINED_WORD_BEFORE_AND, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59466);
    ((intptr_t*)_2)[1] = _keyw_59466;
    _29640 = MAKE_SEQ(_1);
    _49CompileErr(2, _29640, 0);
    _29640 = NOVALUE;
    goto LA; // [312] 542
L11: 

    /** parser.e:3056						elsif conjunction = 0 then*/
    if (_conjunction_59487 != 0)
    goto L12; // [317] 340

    /** parser.e:3057							conjunction = 1*/
    _conjunction_59487 = 1;

    /** parser.e:3058							prev_conj = option*/
    RefDS(_option_59458);
    DeRef(_prev_conj_59489);
    _prev_conj_59489 = _option_59458;

    /** parser.e:3059							continue "deflist"*/
    goto L7; // [335] 148
    goto LA; // [337] 542
L12: 

    /** parser.e:3061							CompileErr(MSG_1_AND_FOLLOWS_2,{keyw,prev_conj})*/
    RefDS(_prev_conj_59489);
    RefDS(_keyw_59466);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _keyw_59466;
    ((intptr_t *)_2)[2] = _prev_conj_59489;
    _29642 = MAKE_SEQ(_1);
    _49CompileErr(10, _29642, 0);
    _29642 = NOVALUE;
    goto LA; // [354] 542
L10: 

    /** parser.e:3063					elsif equal(option, "or") then*/
    if (_option_59458 == _26260)
    _29643 = 1;
    else if (IS_ATOM_INT(_option_59458) && IS_ATOM_INT(_26260))
    _29643 = 0;
    else
    _29643 = (compare(_option_59458, _26260) == 0);
    if (_29643 == 0)
    {
        _29643 = NOVALUE;
        goto L13; // [363] 430
    }
    else{
        _29643 = NOVALUE;
    }

    /** parser.e:3064						if at_start = 1 then*/
    if (_at_start_59488 != 1)
    goto L14; // [368] 388

    /** parser.e:3065							CompileErr(MSG_1_IS_MISSING_DEFINED_WORD_BEFORE_THEN, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59466);
    ((intptr_t*)_2)[1] = _keyw_59466;
    _29645 = MAKE_SEQ(_1);
    _49CompileErr(6, _29645, 0);
    _29645 = NOVALUE;
    goto LA; // [385] 542
L14: 

    /** parser.e:3066						elsif conjunction = 0 then*/
    if (_conjunction_59487 != 0)
    goto L15; // [390] 413

    /** parser.e:3067							conjunction = 2*/
    _conjunction_59487 = 2;

    /** parser.e:3068							prev_conj = option*/
    RefDS(_option_59458);
    DeRef(_prev_conj_59489);
    _prev_conj_59489 = _option_59458;

    /** parser.e:3069							continue "deflist"*/
    goto L7; // [408] 148
    goto LA; // [410] 542
L15: 

    /** parser.e:3071							CompileErr(MSG_1_OR_FOLLOWS_2, {keyw, prev_conj})*/
    RefDS(_prev_conj_59489);
    RefDS(_keyw_59466);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _keyw_59466;
    ((intptr_t *)_2)[2] = _prev_conj_59489;
    _29647 = MAKE_SEQ(_1);
    _49CompileErr(9, _29647, 0);
    _29647 = NOVALUE;
    goto LA; // [427] 542
L13: 

    /** parser.e:3073					elsif length(option) = 0 then*/
    if (IS_SEQUENCE(_option_59458)){
            _29648 = SEQ_PTR(_option_59458)->length;
    }
    else {
        _29648 = 1;
    }
    if (_29648 != 0)
    goto L16; // [435] 474

    /** parser.e:3074						if at_start = 1 then*/
    if (_at_start_59488 != 1)
    goto L17; // [441] 461

    /** parser.e:3075							CompileErr(NO_WORD_WAS_FOUND_FOLLOWING_1, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59466);
    ((intptr_t*)_2)[1] = _keyw_59466;
    _29651 = MAKE_SEQ(_1);
    _49CompileErr(122, _29651, 0);
    _29651 = NOVALUE;
    goto LA; // [458] 542
L17: 

    /** parser.e:3077							CompileErr(EXPECTING_POSSIBLY_THEN_NOT_END_OF_LINE)*/
    RefDS(_22015);
    _49CompileErr(82, _22015, 0);
    goto LA; // [471] 542
L16: 

    /** parser.e:3079					elsif not at_start and length(prev_conj) = 0 then*/
    _29652 = (_at_start_59488 == 0);
    if (_29652 == 0) {
        goto L18; // [479] 510
    }
    if (IS_SEQUENCE(_prev_conj_59489)){
            _29654 = SEQ_PTR(_prev_conj_59489)->length;
    }
    else {
        _29654 = 1;
    }
    _29655 = (_29654 == 0);
    _29654 = NOVALUE;
    if (_29655 == 0)
    {
        DeRef(_29655);
        _29655 = NOVALUE;
        goto L18; // [491] 510
    }
    else{
        DeRef(_29655);
        _29655 = NOVALUE;
    }

    /** parser.e:3080						CompileErr(MSG_1_NOT_UNDERSTOOD, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59466);
    ((intptr_t*)_2)[1] = _keyw_59466;
    _29656 = MAKE_SEQ(_1);
    _49CompileErr(4, _29656, 0);
    _29656 = NOVALUE;
    goto LA; // [507] 542
L18: 

    /** parser.e:3081					elsif t_identifier(option) = 0 then*/
    RefDS(_option_59458);
    _29657 = _9t_identifier(_option_59458);
    if (binary_op_a(NOTEQ, _29657, 0)){
        DeRef(_29657);
        _29657 = NOVALUE;
        goto L19; // [516] 536
    }
    DeRef(_29657);
    _29657 = NOVALUE;

    /** parser.e:3082						CompileErr(MSG_1_WORD_MUST_BE_AN_IDENTIFIER, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59466);
    ((intptr_t*)_2)[1] = _keyw_59466;
    _29659 = MAKE_SEQ(_1);
    _49CompileErr(3, _29659, 0);
    _29659 = NOVALUE;
    goto LA; // [533] 542
L19: 

    /** parser.e:3084						at_start = 0*/
    _at_start_59488 = 0;
LA: 

    /** parser.e:3087					integer this_matched = find(option, OpDefines)*/
    _this_matched_59574 = find_from(_option_59458, _12OpDefines_20300, 1);

    /** parser.e:3088					if negate then*/
    if (_negate_59486 == 0)
    {
        goto L1A; // [553] 567
    }
    else{
    }

    /** parser.e:3089						this_matched = not this_matched*/
    _this_matched_59574 = (_this_matched_59574 == 0);

    /** parser.e:3090						negate = 0*/
    _negate_59486 = 0;
L1A: 

    /** parser.e:3093					if conjunction = 0 then*/
    if (_conjunction_59487 != 0)
    goto L1B; // [569] 581

    /** parser.e:3094						matched = this_matched*/
    _matched_59459 = _this_matched_59574;
    goto L1C; // [578] 623
L1B: 

    /** parser.e:3096						if conjunction = 1 then*/
    if (_conjunction_59487 != 1)
    goto L1D; // [583] 596

    /** parser.e:3097							matched = matched and this_matched*/
    _matched_59459 = (_matched_59459 != 0 && _this_matched_59574 != 0);
    goto L1E; // [593] 610
L1D: 

    /** parser.e:3098						elsif conjunction = 2 then*/
    if (_conjunction_59487 != 2)
    goto L1F; // [598] 609

    /** parser.e:3099							matched = matched or this_matched*/
    _matched_59459 = (_matched_59459 != 0 || _this_matched_59574 != 0);
L1F: 
L1E: 

    /** parser.e:3101						conjunction = 0*/
    _conjunction_59487 = 0;

    /** parser.e:3102						prev_conj = ""*/
    RefDS(_22015);
    DeRef(_prev_conj_59489);
    _prev_conj_59489 = _22015;
L1C: 

    /** parser.e:3104				end while*/
    goto L7; // [627] 148
LD: 

    /** parser.e:3106				in_matched = matched*/
    _in_matched_59461 = _matched_59459;

    /** parser.e:3107				if matched then*/
    if (_matched_59459 == 0)
    {
        goto L20; // [637] 655
    }
    else{
    }

    /** parser.e:3108					No_new_entry = 0*/
    _53No_new_entry_48001 = 0;

    /** parser.e:3109					call_proc(parser_id, {})*/
    _0 = (object)_00[_parser_id_59470].addr;
    (*(intptr_t (*)())_0)(
                         );
L20: 
L6: 
    DeRef(_prev_conj_59489);
    _prev_conj_59489 = NOVALUE;

    /** parser.e:3115			integer gotword = 0*/
    _gotword_59590 = 0;

    /** parser.e:3116			integer gotthen = 0*/
    _gotthen_59591 = 0;

    /** parser.e:3117			integer if_lvl  = 0*/
    _if_lvl_59592 = 0;

    /** parser.e:3118			No_new_entry = not matched*/
    _53No_new_entry_48001 = (_matched_59459 == 0);

    /** parser.e:3119			has_matched = has_matched or matched*/
    _has_matched_59460 = (_has_matched_59460 != 0 || _matched_59459 != 0);

    /** parser.e:3120			keyw = "elsifdef"*/
    RefDS(_26196);
    DeRefi(_keyw_59466);
    _keyw_59466 = _26196;

    /** parser.e:3121			while 1 do*/
L21: 

    /** parser.e:3122				tok = next_token()*/
    _0 = _tok_59465;
    _tok_59465 = _43next_token();
    DeRef(_0);

    /** parser.e:3123				if tok[T_ID] = END_OF_FILE then*/
    _2 = (object)SEQ_PTR(_tok_59465);
    _29670 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29670, -21)){
        _29670 = NOVALUE;
        goto L22; // [713] 738
    }
    _29670 = NOVALUE;

    /** parser.e:3124					CompileErr(END_OF_FILE_REACHED_WHILE_SEARCHING_FOR_END_IFDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59455)){
            _29672 = SEQ_PTR(_43ifdef_lineno_59455)->length;
    }
    else {
        _29672 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59455);
    _29673 = (object)*(((s1_ptr)_2)->base + _29672);
    _49CompileErr(65, _29673, 0);
    _29673 = NOVALUE;
    goto L21; // [735] 698
L22: 

    /** parser.e:3125				elsif tok[T_ID] = END then*/
    _2 = (object)SEQ_PTR(_tok_59465);
    _29674 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29674, 402)){
        _29674 = NOVALUE;
        goto L23; // [748] 874
    }
    _29674 = NOVALUE;

    /** parser.e:3126					tok = next_token()*/
    _0 = _tok_59465;
    _tok_59465 = _43next_token();
    DeRef(_0);

    /** parser.e:3127					if tok[T_ID] = IFDEF then*/
    _2 = (object)SEQ_PTR(_tok_59465);
    _29677 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29677, 407)){
        _29677 = NOVALUE;
        goto L24; // [767] 795
    }
    _29677 = NOVALUE;

    /** parser.e:3128						if dead_ifdef then*/
    if (_dead_ifdef_59462 == 0)
    {
        goto L25; // [773] 785
    }
    else{
    }

    /** parser.e:3129							dead_ifdef -= 1*/
    _dead_ifdef_59462 = _dead_ifdef_59462 - 1;
    goto L21; // [782] 698
L25: 

    /** parser.e:3131							exit "top"*/
    goto L26; // [789] 1350
    goto L21; // [792] 698
L24: 

    /** parser.e:3133					elsif in_matched then*/
    if (_in_matched_59461 == 0)
    {
        goto L27; // [797] 821
    }
    else{
    }

    /** parser.e:3135						CompileErr(EXPECTING_END_IFDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59455)){
            _29680 = SEQ_PTR(_43ifdef_lineno_59455)->length;
    }
    else {
        _29680 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59455);
    _29681 = (object)*(((s1_ptr)_2)->base + _29680);
    _49CompileErr(75, _29681, 0);
    _29681 = NOVALUE;
    goto L21; // [818] 698
L27: 

    /** parser.e:3137						if tok[T_ID] = IF then*/
    _2 = (object)SEQ_PTR(_tok_59465);
    _29682 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29682, 20)){
        _29682 = NOVALUE;
        goto L21; // [831] 698
    }
    _29682 = NOVALUE;

    /** parser.e:3138							if if_lvl > 0 then*/
    if (_if_lvl_59592 <= 0)
    goto L28; // [837] 850

    /** parser.e:3139								if_lvl -= 1*/
    _if_lvl_59592 = _if_lvl_59592 - 1;
    goto L21; // [847] 698
L28: 

    /** parser.e:3141								CompileErr(MISMATCHED_END_IF_SHOULD_THIS_BE_AN_END_IFDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59455)){
            _29686 = SEQ_PTR(_43ifdef_lineno_59455)->length;
    }
    else {
        _29686 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59455);
    _29687 = (object)*(((s1_ptr)_2)->base + _29686);
    _49CompileErr(111, _29687, 0);
    _29687 = NOVALUE;
    goto L21; // [871] 698
L23: 

    /** parser.e:3145				elsif tok[T_ID] = IF then*/
    _2 = (object)SEQ_PTR(_tok_59465);
    _29688 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29688, 20)){
        _29688 = NOVALUE;
        goto L29; // [884] 897
    }
    _29688 = NOVALUE;

    /** parser.e:3146					if_lvl += 1*/
    _if_lvl_59592 = _if_lvl_59592 + 1;
    goto L21; // [894] 698
L29: 

    /** parser.e:3147				elsif tok[T_ID] = ELSE then*/
    _2 = (object)SEQ_PTR(_tok_59465);
    _29691 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29691, 23)){
        _29691 = NOVALUE;
        goto L2A; // [907] 945
    }
    _29691 = NOVALUE;

    /** parser.e:3148					if not in_matched then*/
    if (_in_matched_59461 != 0)
    goto L21; // [913] 698

    /** parser.e:3149						if if_lvl = 0 then*/
    if (_if_lvl_59592 != 0)
    goto L21; // [918] 698

    /** parser.e:3150							CompileErr(MISMATCHED_ELSE_SHOULD_THIS_BE_AN_ELSEDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59455)){
            _29695 = SEQ_PTR(_43ifdef_lineno_59455)->length;
    }
    else {
        _29695 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59455);
    _29696 = (object)*(((s1_ptr)_2)->base + _29695);
    _49CompileErr(108, _29696, 0);
    _29696 = NOVALUE;
    goto L21; // [942] 698
L2A: 

    /** parser.e:3153				elsif tok[T_ID] = ELSIFDEF and not dead_ifdef then*/
    _2 = (object)SEQ_PTR(_tok_59465);
    _29697 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29697)) {
        _29698 = (_29697 == 408);
    }
    else {
        _29698 = binary_op(EQUALS, _29697, 408);
    }
    _29697 = NOVALUE;
    if (IS_ATOM_INT(_29698)) {
        if (_29698 == 0) {
            goto L2B; // [959] 1101
        }
    }
    else {
        if (DBL_PTR(_29698)->dbl == 0.0) {
            goto L2B; // [959] 1101
        }
    }
    _29700 = (_dead_ifdef_59462 == 0);
    if (_29700 == 0)
    {
        DeRef(_29700);
        _29700 = NOVALUE;
        goto L2B; // [967] 1101
    }
    else{
        DeRef(_29700);
        _29700 = NOVALUE;
    }

    /** parser.e:3154					if has_matched then*/
    if (_has_matched_59460 == 0)
    {
        goto L2C; // [972] 1343
    }
    else{
    }

    /** parser.e:3155						in_matched = 0*/
    _in_matched_59461 = 0;

    /** parser.e:3156						No_new_entry = 1*/
    _53No_new_entry_48001 = 1;

    /** parser.e:3157						gotword = 0*/
    _gotword_59590 = 0;

    /** parser.e:3158						gotthen = 0*/
    _gotthen_59591 = 0;

    /** parser.e:3159						while length(option) > 0 with entry do*/
    goto L2D; // [999] 1041
L2E: 
    if (IS_SEQUENCE(_option_59458)){
            _29701 = SEQ_PTR(_option_59458)->length;
    }
    else {
        _29701 = 1;
    }
    if (_29701 <= 0)
    goto L2F; // [1007] 1054

    /** parser.e:3160							if equal(option, "then") then*/
    if (_option_59458 == _26295)
    _29703 = 1;
    else if (IS_ATOM_INT(_option_59458) && IS_ATOM_INT(_26295))
    _29703 = 0;
    else
    _29703 = (compare(_option_59458, _26295) == 0);
    if (_29703 == 0)
    {
        _29703 = NOVALUE;
        goto L30; // [1017] 1032
    }
    else{
        _29703 = NOVALUE;
    }

    /** parser.e:3161								gotthen = 1*/
    _gotthen_59591 = 1;

    /** parser.e:3162								exit*/
    goto L2F; // [1027] 1054
    goto L31; // [1029] 1038
L30: 

    /** parser.e:3164								gotword = 1*/
    _gotword_59590 = 1;
L31: 

    /** parser.e:3166						entry*/
L2D: 

    /** parser.e:3167							option = StringToken()*/
    RefDS(_5);
    _0 = _option_59458;
    _option_59458 = _61StringToken(_5);
    DeRef(_0);

    /** parser.e:3168						end while*/
    goto L2E; // [1051] 1002
L2F: 

    /** parser.e:3169						if gotword = 0 then*/
    if (_gotword_59590 != 0)
    goto L32; // [1056] 1070

    /** parser.e:3170							CompileErr(EXPECTING_A_WORD_TO_FOLLOW_ELSIFDEF)*/
    RefDS(_22015);
    _49CompileErr(78, _22015, 0);
L32: 

    /** parser.e:3172						if gotthen = 0 then*/
    if (_gotthen_59591 != 0)
    goto L33; // [1072] 1086

    /** parser.e:3173							CompileErr(EXPECTING_THEN_ON_ELSIFDEF_LINE)*/
    RefDS(_22015);
    _49CompileErr(77, _22015, 0);
L33: 

    /** parser.e:3175						read_line()*/
    _61read_line();
    goto L21; // [1090] 698

    /** parser.e:3177						exit*/
    goto L2C; // [1095] 1343
    goto L21; // [1098] 698
L2B: 

    /** parser.e:3179				elsif tok[T_ID] = ELSEDEF then*/
    _2 = (object)SEQ_PTR(_tok_59465);
    _29707 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29707, 409)){
        _29707 = NOVALUE;
        goto L34; // [1111] 1273
    }
    _29707 = NOVALUE;

    /** parser.e:3180					gotword = line_number*/
    _gotword_59590 = _12line_number_20227;

    /** parser.e:3181					option = StringToken()*/
    RefDS(_5);
    _0 = _option_59458;
    _option_59458 = _61StringToken(_5);
    DeRef(_0);

    /** parser.e:3182					if length(option) > 0 then*/
    if (IS_SEQUENCE(_option_59458)){
            _29710 = SEQ_PTR(_option_59458)->length;
    }
    else {
        _29710 = 1;
    }
    if (_29710 <= 0)
    goto L35; // [1137] 1173

    /** parser.e:3183						if line_number = gotword then*/
    if (_12line_number_20227 != _gotword_59590)
    goto L36; // [1145] 1159

    /** parser.e:3184							CompileErr(NOT_EXPECTING_ANYTHING_ON_SAME_LINE_AS_ELSDEF)*/
    RefDS(_22015);
    _49CompileErr(116, _22015, 0);
L36: 

    /** parser.e:3186						bp -= length(option)*/
    if (IS_SEQUENCE(_option_59458)){
            _29713 = SEQ_PTR(_option_59458)->length;
    }
    else {
        _29713 = 1;
    }
    _49bp_49265 = _49bp_49265 - _29713;
    _29713 = NOVALUE;
L35: 

    /** parser.e:3188					if not dead_ifdef then*/
    if (_dead_ifdef_59462 != 0)
    goto L21; // [1175] 698

    /** parser.e:3189						if has_matched then*/
    if (_has_matched_59460 == 0)
    {
        goto L37; // [1180] 1202
    }
    else{
    }

    /** parser.e:3190							in_matched = 0*/
    _in_matched_59461 = 0;

    /** parser.e:3191							No_new_entry = 1*/
    _53No_new_entry_48001 = 1;

    /** parser.e:3192							read_line()*/
    _61read_line();
    goto L21; // [1199] 698
L37: 

    /** parser.e:3194							No_new_entry = 0*/
    _53No_new_entry_48001 = 0;

    /** parser.e:3195							in_elsedef = 1*/
    _in_elsedef_59463 = 1;

    /** parser.e:3196							call_proc(parser_id, {})*/
    _0 = (object)_00[_parser_id_59470].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:3197							tok_match(END)*/
    _43tok_match(402, 0);

    /** parser.e:3198							tok_match(IFDEF, END)*/
    _43tok_match(407, 402);

    /** parser.e:3199							live_ifdef -= 1*/
    _43live_ifdef_59454 = _43live_ifdef_59454 - 1;

    /** parser.e:3200							ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_43ifdef_lineno_59455)){
            _29717 = SEQ_PTR(_43ifdef_lineno_59455)->length;
    }
    else {
        _29717 = 1;
    }
    _29718 = _29717 - 1;
    _29717 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43ifdef_lineno_59455;
    RHS_Slice(_43ifdef_lineno_59455, 1, _29718);

    /** parser.e:3201							return*/
    DeRef(_option_59458);
    DeRef(_tok_59465);
    DeRefi(_keyw_59466);
    DeRef(_29617);
    _29617 = NOVALUE;
    DeRef(_29623);
    _29623 = NOVALUE;
    DeRef(_29698);
    _29698 = NOVALUE;
    DeRef(_29652);
    _29652 = NOVALUE;
    _29718 = NOVALUE;
    return;
    goto L21; // [1270] 698
L34: 

    /** parser.e:3204				elsif tok[T_ID] = IFDEF then*/
    _2 = (object)SEQ_PTR(_tok_59465);
    _29720 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29720, 407)){
        _29720 = NOVALUE;
        goto L38; // [1283] 1296
    }
    _29720 = NOVALUE;

    /** parser.e:3205					dead_ifdef += 1*/
    _dead_ifdef_59462 = _dead_ifdef_59462 + 1;
    goto L21; // [1293] 698
L38: 

    /** parser.e:3207				elsif tok[T_ID] = INCLUDE then*/
    _2 = (object)SEQ_PTR(_tok_59465);
    _29723 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29723, 418)){
        _29723 = NOVALUE;
        goto L39; // [1306] 1317
    }
    _29723 = NOVALUE;

    /** parser.e:3209					read_line()*/
    _61read_line();
    goto L21; // [1314] 698
L39: 

    /** parser.e:3211				elsif tok[T_ID] = CASE then*/
    _2 = (object)SEQ_PTR(_tok_59465);
    _29725 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29725, 186)){
        _29725 = NOVALUE;
        goto L21; // [1327] 698
    }
    _29725 = NOVALUE;

    /** parser.e:3213					tok = next_token()*/
    _0 = _tok_59465;
    _tok_59465 = _43next_token();
    DeRef(_0);

    /** parser.e:3216			end while*/
    goto L21; // [1340] 698
L2C: 

    /** parser.e:3217		end while*/
    goto L5; // [1347] 105
L26: 

    /** parser.e:3219		live_ifdef -= 1*/
    _43live_ifdef_59454 = _43live_ifdef_59454 - 1;

    /** parser.e:3220		ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_43ifdef_lineno_59455)){
            _29729 = SEQ_PTR(_43ifdef_lineno_59455)->length;
    }
    else {
        _29729 = 1;
    }
    _29730 = _29729 - 1;
    _29729 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43ifdef_lineno_59455;
    RHS_Slice(_43ifdef_lineno_59455, 1, _29730);

    /** parser.e:3221		No_new_entry = 0*/
    _53No_new_entry_48001 = 0;

    /** parser.e:3222	end procedure*/
    DeRef(_option_59458);
    DeRef(_tok_59465);
    DeRefi(_keyw_59466);
    DeRef(_29617);
    _29617 = NOVALUE;
    DeRef(_29623);
    _29623 = NOVALUE;
    _29730 = NOVALUE;
    DeRef(_29698);
    _29698 = NOVALUE;
    DeRef(_29652);
    _29652 = NOVALUE;
    DeRef(_29718);
    _29718 = NOVALUE;
    return;
    ;
}


object _43SetPrivateScope(object _s_59745, object _type_sym_59747, object _n_59748)
{
    object _hashval_59749 = NOVALUE;
    object _scope_59750 = NOVALUE;
    object _t_59752 = NOVALUE;
    object _29751 = NOVALUE;
    object _29750 = NOVALUE;
    object _29749 = NOVALUE;
    object _29748 = NOVALUE;
    object _29747 = NOVALUE;
    object _29746 = NOVALUE;
    object _29743 = NOVALUE;
    object _29740 = NOVALUE;
    object _29738 = NOVALUE;
    object _29736 = NOVALUE;
    object _29732 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_59745)) {
        _1 = (object)(DBL_PTR(_s_59745)->dbl);
        DeRefDS(_s_59745);
        _s_59745 = _1;
    }

    /** parser.e:3230		scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29732 = (object)*(((s1_ptr)_2)->base + _s_59745);
    _2 = (object)SEQ_PTR(_29732);
    _scope_59750 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_59750)){
        _scope_59750 = (object)DBL_PTR(_scope_59750)->dbl;
    }
    _29732 = NOVALUE;

    /** parser.e:3231		switch scope do*/
    _0 = _scope_59750;
    switch ( _0 ){ 

        /** parser.e:3232			case SC_PRIVATE then*/
        case 3:

        /** parser.e:3233				DefinedYet(s)*/
        _53DefinedYet(_s_59745);

        /** parser.e:3234				Block_var( s )*/
        _64Block_var(_s_59745);

        /** parser.e:3235				return s*/
        return _s_59745;
        goto L1; // [50] 260

        /** parser.e:3237			case SC_LOOP_VAR then*/
        case 2:

        /** parser.e:3238				DefinedYet(s)*/
        _53DefinedYet(_s_59745);

        /** parser.e:3239				return s*/
        return _s_59745;
        goto L1; // [67] 260

        /** parser.e:3241			case SC_UNDEFINED, SC_MULTIPLY_DEFINED then*/
        case 9:
        case 10:

        /** parser.e:3242				SymTab[s][S_SCOPE] = SC_PRIVATE*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_59745 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 3;
        DeRef(_1);
        _29736 = NOVALUE;

        /** parser.e:3243				SymTab[s][S_VARNUM] = n*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_59745 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 16);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _n_59748;
        DeRef(_1);
        _29738 = NOVALUE;

        /** parser.e:3244				SymTab[s][S_VTYPE] = type_sym*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_59745 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 15);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _type_sym_59747;
        DeRef(_1);
        _29740 = NOVALUE;

        /** parser.e:3245				if type_sym < 0 then*/
        if (_type_sym_59747 >= 0)
        goto L2; // [124] 135

        /** parser.e:3246					register_forward_type( s, type_sym )*/
        _42register_forward_type(_s_59745, _type_sym_59747);
L2: 

        /** parser.e:3248				Block_var( s )*/
        _64Block_var(_s_59745);

        /** parser.e:3249				return s*/
        return _s_59745;
        goto L1; // [146] 260

        /** parser.e:3251			case SC_LOCAL, SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT then*/
        case 5:
        case 6:
        case 7:
        case 13:
        case 11:

        /** parser.e:3252				hashval = SymTab[s][S_HASHVAL]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _29743 = (object)*(((s1_ptr)_2)->base + _s_59745);
        _2 = (object)SEQ_PTR(_29743);
        _hashval_59749 = (object)*(((s1_ptr)_2)->base + 11);
        if (!IS_ATOM_INT(_hashval_59749)){
            _hashval_59749 = (object)DBL_PTR(_hashval_59749)->dbl;
        }
        _29743 = NOVALUE;

        /** parser.e:3253				t = buckets[hashval]*/
        _2 = (object)SEQ_PTR(_53buckets_46799);
        _t_59752 = (object)*(((s1_ptr)_2)->base + _hashval_59749);
        if (!IS_ATOM_INT(_t_59752)){
            _t_59752 = (object)DBL_PTR(_t_59752)->dbl;
        }

        /** parser.e:3254				buckets[hashval] = NewEntry(SymTab[s][S_NAME], n, SC_PRIVATE,*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _29746 = (object)*(((s1_ptr)_2)->base + _s_59745);
        _2 = (object)SEQ_PTR(_29746);
        if (!IS_ATOM_INT(_12S_NAME_19864)){
            _29747 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
        }
        else{
            _29747 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
        }
        _29746 = NOVALUE;
        Ref(_29747);
        _29748 = _53NewEntry(_29747, _n_59748, 3, -100, _hashval_59749, _t_59752, _type_sym_59747);
        _29747 = NOVALUE;
        _2 = (object)SEQ_PTR(_53buckets_46799);
        _2 = (object)(((s1_ptr)_2)->base + _hashval_59749);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _29748;
        if( _1 != _29748 ){
            DeRef(_1);
        }
        _29748 = NOVALUE;

        /** parser.e:3256				Block_var( buckets[hashval] )*/
        _2 = (object)SEQ_PTR(_53buckets_46799);
        _29749 = (object)*(((s1_ptr)_2)->base + _hashval_59749);
        Ref(_29749);
        _64Block_var(_29749);
        _29749 = NOVALUE;

        /** parser.e:3257				return buckets[hashval]*/
        _2 = (object)SEQ_PTR(_53buckets_46799);
        _29750 = (object)*(((s1_ptr)_2)->base + _hashval_59749);
        Ref(_29750);
        return _29750;
        goto L1; // [243] 260

        /** parser.e:3259			case else*/
        default:

        /** parser.e:3260				InternalErr(267, {scope})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _scope_59750;
        _29751 = MAKE_SEQ(_1);
        _49InternalErr(267, _29751);
        _29751 = NOVALUE;
    ;}L1: 

    /** parser.e:3264		return 0*/
    _29750 = NOVALUE;
    return 0;
    ;
}


void _43For_statement()
{
    object _bp1_59817 = NOVALUE;
    object _bp2_59818 = NOVALUE;
    object _exit_base_59819 = NOVALUE;
    object _next_base_59820 = NOVALUE;
    object _end_op_59821 = NOVALUE;
    object _tok_59823 = NOVALUE;
    object _loop_var_59824 = NOVALUE;
    object _loop_var_sym_59826 = NOVALUE;
    object _save_syms_59827 = NOVALUE;
    object _29798 = NOVALUE;
    object _29796 = NOVALUE;
    object _29795 = NOVALUE;
    object _29789 = NOVALUE;
    object _29787 = NOVALUE;
    object _29785 = NOVALUE;
    object _29784 = NOVALUE;
    object _29783 = NOVALUE;
    object _29782 = NOVALUE;
    object _29780 = NOVALUE;
    object _29778 = NOVALUE;
    object _29777 = NOVALUE;
    object _29776 = NOVALUE;
    object _29775 = NOVALUE;
    object _29773 = NOVALUE;
    object _29771 = NOVALUE;
    object _29767 = NOVALUE;
    object _29765 = NOVALUE;
    object _29762 = NOVALUE;
    object _29760 = NOVALUE;
    object _29754 = NOVALUE;
    object _29753 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3273		sequence save_syms*/

    /** parser.e:3275		Start_block( FOR )*/
    _64Start_block(21, 0);

    /** parser.e:3276		loop_var = next_token()*/
    _0 = _loop_var_59824;
    _loop_var_59824 = _43next_token();
    DeRef(_0);

    /** parser.e:3277		if not find(loop_var[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_loop_var_59824);
    _29753 = (object)*(((s1_ptr)_2)->base + 1);
    _29754 = find_from(_29753, _29ADDR_TOKS_12010, 1);
    _29753 = NOVALUE;
    if (_29754 != 0)
    goto L1; // [31] 44
    _29754 = NOVALUE;

    /** parser.e:3278			CompileErr(A_LOOP_VARIABLE_NAME_IS_EXPECTED_HERE)*/
    RefDS(_22015);
    _49CompileErr(28, _22015, 0);
L1: 

    /** parser.e:3281		if BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto L2; // [48] 57
    }
    else{
    }

    /** parser.e:3282			add_ref(loop_var)*/
    Ref(_loop_var_59824);
    _53add_ref(_loop_var_59824);
L2: 

    /** parser.e:3285		tok_match(EQUALS)*/
    _43tok_match(3, 0);

    /** parser.e:3286		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_54972)){
            _exit_base_59819 = SEQ_PTR(_43exit_list_54972)->length;
    }
    else {
        _exit_base_59819 = 1;
    }

    /** parser.e:3287		next_base = length(continue_list)*/
    if (IS_SEQUENCE(_43continue_list_54974)){
            _next_base_59820 = SEQ_PTR(_43continue_list_54974)->length;
    }
    else {
        _next_base_59820 = 1;
    }

    /** parser.e:3288		Expr()*/
    _43Expr();

    /** parser.e:3289		tok_match(TO)*/
    _43tok_match(403, 0);

    /** parser.e:3290		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_54972)){
            _exit_base_59819 = SEQ_PTR(_43exit_list_54972)->length;
    }
    else {
        _exit_base_59819 = 1;
    }

    /** parser.e:3291		Expr()*/
    _43Expr();

    /** parser.e:3292		tok = next_token()*/
    _0 = _tok_59823;
    _tok_59823 = _43next_token();
    DeRef(_0);

    /** parser.e:3293		if tok[T_ID] = BY then*/
    _2 = (object)SEQ_PTR(_tok_59823);
    _29760 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29760, 404)){
        _29760 = NOVALUE;
        goto L3; // [117] 137
    }
    _29760 = NOVALUE;

    /** parser.e:3294			Expr()*/
    _43Expr();

    /** parser.e:3295			end_op = ENDFOR_GENERAL -- will be set at runtime by FOR op*/
    _end_op_59821 = 39;
    goto L4; // [134] 161
L3: 

    /** parser.e:3298			emit_opnd(NewIntSym(1))*/
    _29762 = _53NewIntSym(1);
    _45emit_opnd(_29762);
    _29762 = NOVALUE;

    /** parser.e:3299			putback(tok)*/
    Ref(_tok_59823);
    _43putback(_tok_59823);

    /** parser.e:3300			end_op = ENDFOR_INT_UP1*/
    _end_op_59821 = 54;
L4: 

    /** parser.e:3303		loop_var_sym = loop_var[T_SYM]*/
    _2 = (object)SEQ_PTR(_loop_var_59824);
    _loop_var_sym_59826 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_loop_var_sym_59826)){
        _loop_var_sym_59826 = (object)DBL_PTR(_loop_var_sym_59826)->dbl;
    }

    /** parser.e:3304		if CurrentSub = TopLevelSub then*/
    if (_12CurrentSub_20234 != _12TopLevelSub_20233)
    goto L5; // [177] 223

    /** parser.e:3305			DefinedYet(loop_var_sym)*/
    _53DefinedYet(_loop_var_sym_59826);

    /** parser.e:3306			SymTab[loop_var_sym][S_SCOPE] = SC_GLOOP_VAR*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_59826 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4;
    DeRef(_1);
    _29765 = NOVALUE;

    /** parser.e:3307			SymTab[loop_var_sym][S_VTYPE] = object_type*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_59826 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53object_type_46803;
    DeRef(_1);
    _29767 = NOVALUE;
    goto L6; // [220] 267
L5: 

    /** parser.e:3309			loop_var_sym = SetPrivateScope(loop_var_sym, object_type, param_num)*/
    _loop_var_sym_59826 = _43SetPrivateScope(_loop_var_sym_59826, _53object_type_46803, _43param_num_54961);
    if (!IS_ATOM_INT(_loop_var_sym_59826)) {
        _1 = (object)(DBL_PTR(_loop_var_sym_59826)->dbl);
        DeRefDS(_loop_var_sym_59826);
        _loop_var_sym_59826 = _1;
    }

    /** parser.e:3310			param_num += 1*/
    _43param_num_54961 = _43param_num_54961 + 1;

    /** parser.e:3311			SymTab[loop_var_sym][S_SCOPE] = SC_LOOP_VAR*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_59826 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _29771 = NOVALUE;

    /** parser.e:3312			Pop_block_var()*/
    _64Pop_block_var();
L6: 

    /** parser.e:3314		SymTab[loop_var_sym][S_USAGE] = or_bits(SymTab[loop_var_sym][S_USAGE], U_USED)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_59826 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29775 = (object)*(((s1_ptr)_2)->base + _loop_var_sym_59826);
    _2 = (object)SEQ_PTR(_29775);
    _29776 = (object)*(((s1_ptr)_2)->base + 5);
    _29775 = NOVALUE;
    if (IS_ATOM_INT(_29776)) {
        {uintptr_t tu;
             tu = (uintptr_t)_29776 | (uintptr_t)3;
             _29777 = MAKE_UINT(tu);
        }
    }
    else {
        _29777 = binary_op(OR_BITS, _29776, 3);
    }
    _29776 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29777;
    if( _1 != _29777 ){
        DeRef(_1);
    }
    _29777 = NOVALUE;
    _29773 = NOVALUE;

    /** parser.e:3316		op_info1 = loop_var_sym*/
    _45op_info1_50960 = _loop_var_sym_59826;

    /** parser.e:3317		emit_op(FOR)*/
    _45emit_op(21);

    /** parser.e:3318		emit_addr(loop_var_sym)*/
    _45emit_addr(_loop_var_sym_59826);

    /** parser.e:3319		if finish_block_header(FOR) then*/
    _29778 = _43finish_block_header(21);
    if (_29778 == 0) {
        DeRef(_29778);
        _29778 = NOVALUE;
        goto L7; // [327] 340
    }
    else {
        if (!IS_ATOM_INT(_29778) && DBL_PTR(_29778)->dbl == 0.0){
            DeRef(_29778);
            _29778 = NOVALUE;
            goto L7; // [327] 340
        }
        DeRef(_29778);
        _29778 = NOVALUE;
    }
    DeRef(_29778);
    _29778 = NOVALUE;

    /** parser.e:3320			CompileErr(ENTRY_IS_NOT_SUPPORTED_IN_FOR_LOOPS)*/
    RefDS(_22015);
    _49CompileErr(83, _22015, 0);
L7: 

    /** parser.e:3322		entry_addr &= 0*/
    Append(&_43entry_addr_54976, _43entry_addr_54976, 0);

    /** parser.e:3323		bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29780 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29780 = 1;
    }
    _bp1_59817 = _29780 + 1;
    _29780 = NOVALUE;

    /** parser.e:3324		emit_addr(0) -- will be patched - don't straighten*/
    _45emit_addr(0);

    /** parser.e:3326		save_syms = Code[$-5..$-3] -- could be temps, but can't get rid of them yet*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29782 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29782 = 1;
    }
    _29783 = _29782 - 5;
    _29782 = NOVALUE;
    if (IS_SEQUENCE(_12Code_20315)){
            _29784 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29784 = 1;
    }
    _29785 = _29784 - 3;
    _29784 = NOVALUE;
    rhs_slice_target = (object_ptr)&_save_syms_59827;
    RHS_Slice(_12Code_20315, _29783, _29785);

    /** parser.e:3327		for i = 1 to 3 do*/
    {
        object _i_59917;
        _i_59917 = 1;
L8: 
        if (_i_59917 > 3){
            goto L9; // [389] 412
        }

        /** parser.e:3328			clear_temp( save_syms[i] )*/
        _2 = (object)SEQ_PTR(_save_syms_59827);
        _29787 = (object)*(((s1_ptr)_2)->base + _i_59917);
        Ref(_29787);
        _45clear_temp(_29787);
        _29787 = NOVALUE;

        /** parser.e:3329		end for*/
        _i_59917 = _i_59917 + 1;
        goto L8; // [407] 396
L9: 
        ;
    }

    /** parser.e:3330		flush_temps()*/
    RefDS(_22015);
    _45flush_temps(_22015);

    /** parser.e:3332		bp2 = length(Code)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _bp2_59818 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _bp2_59818 = 1;
    }

    /** parser.e:3333		retry_addr &= bp2 + 1*/
    _29789 = _bp2_59818 + 1;
    Append(&_43retry_addr_54978, _43retry_addr_54978, _29789);
    _29789 = NOVALUE;

    /** parser.e:3334		continue_addr &= 0*/
    Append(&_43continue_addr_54977, _43continue_addr_54977, 0);

    /** parser.e:3336		loop_stack &= FOR*/
    Append(&_43loop_stack_54986, _43loop_stack_54986, 21);

    /** parser.e:3338		if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto LA; // [458] 482

    /** parser.e:3339			if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto LB; // [465] 481
    }
    else{
    }

    /** parser.e:3340				emit_op(DISPLAY_VAR)*/
    _45emit_op(87);

    /** parser.e:3341				emit_addr(loop_var_sym)*/
    _45emit_addr(_loop_var_sym_59826);
LB: 
LA: 

    /** parser.e:3345		Statement_list()*/
    _43Statement_list();

    /** parser.e:3346		tok_match(END)*/
    _43tok_match(402, 0);

    /** parser.e:3347		tok_match(FOR, END)*/
    _43tok_match(21, 402);

    /** parser.e:3349		End_block( FOR )*/
    _64End_block(21);

    /** parser.e:3351		StartSourceLine(TRUE, TRANSLATE)*/
    _45StartSourceLine(_9TRUE_446, _12TRANSLATE_19834, 2);

    /** parser.e:3352		op_info1 = loop_var_sym*/
    _45op_info1_50960 = _loop_var_sym_59826;

    /** parser.e:3353		op_info2 = bp2 + 1*/
    _45op_info2_50961 = _bp2_59818 + 1;

    /** parser.e:3354		PatchNList(next_base)*/
    _43PatchNList(_next_base_59820);

    /** parser.e:3355		emit_op(end_op)*/
    _45emit_op(_end_op_59821);

    /** parser.e:3356		backpatch(bp1, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29795 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29795 = 1;
    }
    _29796 = _29795 + 1;
    _29795 = NOVALUE;
    _45backpatch(_bp1_59817, _29796);
    _29796 = NOVALUE;

    /** parser.e:3357		if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto LC; // [568] 592

    /** parser.e:3358			if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto LD; // [575] 591
    }
    else{
    }

    /** parser.e:3359				emit_op(ERASE_SYMBOL)*/
    _45emit_op(90);

    /** parser.e:3360				emit_addr(loop_var_sym)*/
    _45emit_addr(_loop_var_sym_59826);
LD: 
LC: 

    /** parser.e:3364		Hide(loop_var_sym)*/
    _53Hide(_loop_var_sym_59826);

    /** parser.e:3365		exit_loop(exit_base)*/
    _43exit_loop(_exit_base_59819);

    /** parser.e:3366		for i = 1 to 3 do*/
    {
        object _i_59963;
        _i_59963 = 1;
LE: 
        if (_i_59963 > 3){
            goto LF; // [604] 630
        }

        /** parser.e:3367			emit_temp( save_syms[i], NEW_REFERENCE )*/
        _2 = (object)SEQ_PTR(_save_syms_59827);
        _29798 = (object)*(((s1_ptr)_2)->base + _i_59963);
        Ref(_29798);
        _45emit_temp(_29798, 1);
        _29798 = NOVALUE;

        /** parser.e:3368		end for*/
        _i_59963 = _i_59963 + 1;
        goto LE; // [625] 611
LF: 
        ;
    }

    /** parser.e:3369		flush_temps()*/
    RefDS(_22015);
    _45flush_temps(_22015);

    /** parser.e:3370	end procedure*/
    DeRef(_tok_59823);
    DeRef(_loop_var_59824);
    DeRef(_save_syms_59827);
    DeRef(_29783);
    _29783 = NOVALUE;
    DeRef(_29785);
    _29785 = NOVALUE;
    return;
    ;
}


object _43CompileType(object _type_ptr_59971)
{
    object _t_59972 = NOVALUE;
    object _29809 = NOVALUE;
    object _29808 = NOVALUE;
    object _29807 = NOVALUE;
    object _29801 = NOVALUE;
    object _29800 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_type_ptr_59971)) {
        _1 = (object)(DBL_PTR(_type_ptr_59971)->dbl);
        DeRefDS(_type_ptr_59971);
        _type_ptr_59971 = _1;
    }

    /** parser.e:3376		if type_ptr < 0 then*/
    if (_type_ptr_59971 >= 0)
    goto L1; // [5] 16

    /** parser.e:3378			return type_ptr*/
    return _type_ptr_59971;
L1: 

    /** parser.e:3381		if SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29800 = (object)*(((s1_ptr)_2)->base + _type_ptr_59971);
    _2 = (object)SEQ_PTR(_29800);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _29801 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _29801 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _29800 = NOVALUE;
    if (binary_op_a(NOTEQ, _29801, 415)){
        _29801 = NOVALUE;
        goto L2; // [32] 47
    }
    _29801 = NOVALUE;

    /** parser.e:3382			return TYPE_OBJECT*/
    return 16;
    goto L3; // [44] 218
L2: 

    /** parser.e:3384		elsif type_ptr = integer_type then*/
    if (_type_ptr_59971 != _53integer_type_46809)
    goto L4; // [51] 66

    /** parser.e:3385			return TYPE_INTEGER*/
    return 1;
    goto L3; // [63] 218
L4: 

    /** parser.e:3387		elsif type_ptr = atom_type then*/
    if (_type_ptr_59971 != _53atom_type_46805)
    goto L5; // [70] 85

    /** parser.e:3388			return TYPE_ATOM*/
    return 4;
    goto L3; // [82] 218
L5: 

    /** parser.e:3390		elsif type_ptr = sequence_type then*/
    if (_type_ptr_59971 != _53sequence_type_46807)
    goto L6; // [89] 104

    /** parser.e:3391			return TYPE_SEQUENCE*/
    return 8;
    goto L3; // [101] 218
L6: 

    /** parser.e:3393		elsif type_ptr = object_type then*/
    if (_type_ptr_59971 != _53object_type_46803)
    goto L7; // [108] 123

    /** parser.e:3394			return TYPE_OBJECT*/
    return 16;
    goto L3; // [120] 218
L7: 

    /** parser.e:3398			t = SymTab[SymTab[type_ptr][S_NEXT]][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29807 = (object)*(((s1_ptr)_2)->base + _type_ptr_59971);
    _2 = (object)SEQ_PTR(_29807);
    _29808 = (object)*(((s1_ptr)_2)->base + 2);
    _29807 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_29808)){
        _29809 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29808)->dbl));
    }
    else{
        _29809 = (object)*(((s1_ptr)_2)->base + _29808);
    }
    _2 = (object)SEQ_PTR(_29809);
    _t_59972 = (object)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_t_59972)){
        _t_59972 = (object)DBL_PTR(_t_59972)->dbl;
    }
    _29809 = NOVALUE;

    /** parser.e:3399			if t = integer_type then*/
    if (_t_59972 != _53integer_type_46809)
    goto L8; // [155] 170

    /** parser.e:3400				return TYPE_INTEGER*/
    _29808 = NOVALUE;
    return 1;
    goto L9; // [167] 217
L8: 

    /** parser.e:3401			elsif t = atom_type then*/
    if (_t_59972 != _53atom_type_46805)
    goto LA; // [174] 189

    /** parser.e:3402				return TYPE_ATOM*/
    _29808 = NOVALUE;
    return 4;
    goto L9; // [186] 217
LA: 

    /** parser.e:3403			elsif t = sequence_type then*/
    if (_t_59972 != _53sequence_type_46807)
    goto LB; // [193] 208

    /** parser.e:3404				return TYPE_SEQUENCE*/
    _29808 = NOVALUE;
    return 8;
    goto L9; // [205] 217
LB: 

    /** parser.e:3406				return TYPE_OBJECT*/
    _29808 = NOVALUE;
    return 16;
L9: 
L3: 
    ;
}


object _43get_assigned_sym()
{
    object _29822 = NOVALUE;
    object _29821 = NOVALUE;
    object _29820 = NOVALUE;
    object _29818 = NOVALUE;
    object _29817 = NOVALUE;
    object _29816 = NOVALUE;
    object _29815 = NOVALUE;
    object _29814 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3416		if not find( Code[$-2], {ASSIGN, ASSIGN_I}) then*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29814 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29814 = 1;
    }
    _29815 = _29814 - 2;
    _29814 = NOVALUE;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _29816 = (object)*(((s1_ptr)_2)->base + _29815);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 18;
    ((intptr_t *)_2)[2] = 113;
    _29817 = MAKE_SEQ(_1);
    _29818 = find_from(_29816, _29817, 1);
    _29816 = NOVALUE;
    DeRefDS(_29817);
    _29817 = NOVALUE;
    if (_29818 != 0)
    goto L1; // [29] 39
    _29818 = NOVALUE;

    /** parser.e:3417			return 0*/
    _29815 = NOVALUE;
    return 0;
L1: 

    /** parser.e:3419		return Code[$-1]*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29820 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29820 = 1;
    }
    _29821 = _29820 - 1;
    _29820 = NOVALUE;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _29822 = (object)*(((s1_ptr)_2)->base + _29821);
    Ref(_29822);
    _29821 = NOVALUE;
    DeRef(_29815);
    _29815 = NOVALUE;
    return _29822;
    ;
}


void _43Assign_Constant(object _sym_60041)
{
    object _valsym_60043 = NOVALUE;
    object _val_60046 = NOVALUE;
    object _29849 = NOVALUE;
    object _29848 = NOVALUE;
    object _29846 = NOVALUE;
    object _29845 = NOVALUE;
    object _29844 = NOVALUE;
    object _29842 = NOVALUE;
    object _29841 = NOVALUE;
    object _29840 = NOVALUE;
    object _29838 = NOVALUE;
    object _29837 = NOVALUE;
    object _29836 = NOVALUE;
    object _29834 = NOVALUE;
    object _29833 = NOVALUE;
    object _29832 = NOVALUE;
    object _29830 = NOVALUE;
    object _29828 = NOVALUE;
    object _29826 = NOVALUE;
    object _29824 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3423		symtab_index valsym = Pop() -- pop the sym for the constant, too*/
    _valsym_60043 = _45Pop();
    if (!IS_ATOM_INT(_valsym_60043)) {
        _1 = (object)(DBL_PTR(_valsym_60043)->dbl);
        DeRefDS(_valsym_60043);
        _valsym_60043 = _1;
    }

    /** parser.e:3424		object val = SymTab[valsym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29824 = (object)*(((s1_ptr)_2)->base + _valsym_60043);
    DeRef(_val_60046);
    _2 = (object)SEQ_PTR(_29824);
    _val_60046 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_val_60046);
    _29824 = NOVALUE;

    /** parser.e:3426		SymTab[sym][S_OBJ] = val*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60041 + ((s1_ptr)_2)->base);
    Ref(_val_60046);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _val_60046;
    DeRef(_1);
    _29826 = NOVALUE;

    /** parser.e:3427		SymTab[sym][S_INITLEVEL] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60041 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _29828 = NOVALUE;

    /** parser.e:3429		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L1; // [58] 197
    }
    else{
    }

    /** parser.e:3431			SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60041 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29832 = (object)*(((s1_ptr)_2)->base + _valsym_60043);
    _2 = (object)SEQ_PTR(_29832);
    _29833 = (object)*(((s1_ptr)_2)->base + 36);
    _29832 = NOVALUE;
    Ref(_29833);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29833;
    if( _1 != _29833 ){
        DeRef(_1);
    }
    _29833 = NOVALUE;
    _29830 = NOVALUE;

    /** parser.e:3432			SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60041 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29836 = (object)*(((s1_ptr)_2)->base + _valsym_60043);
    _2 = (object)SEQ_PTR(_29836);
    _29837 = (object)*(((s1_ptr)_2)->base + 33);
    _29836 = NOVALUE;
    Ref(_29837);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29837;
    if( _1 != _29837 ){
        DeRef(_1);
    }
    _29837 = NOVALUE;
    _29834 = NOVALUE;

    /** parser.e:3433			SymTab[sym][S_OBJ_MIN] = SymTab[valsym][S_OBJ_MIN]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60041 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29840 = (object)*(((s1_ptr)_2)->base + _valsym_60043);
    _2 = (object)SEQ_PTR(_29840);
    _29841 = (object)*(((s1_ptr)_2)->base + 30);
    _29840 = NOVALUE;
    Ref(_29841);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29841;
    if( _1 != _29841 ){
        DeRef(_1);
    }
    _29841 = NOVALUE;
    _29838 = NOVALUE;

    /** parser.e:3434			SymTab[sym][S_OBJ_MAX] = SymTab[valsym][S_OBJ_MAX]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60041 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29844 = (object)*(((s1_ptr)_2)->base + _valsym_60043);
    _2 = (object)SEQ_PTR(_29844);
    _29845 = (object)*(((s1_ptr)_2)->base + 31);
    _29844 = NOVALUE;
    Ref(_29845);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29845;
    if( _1 != _29845 ){
        DeRef(_1);
    }
    _29845 = NOVALUE;
    _29842 = NOVALUE;

    /** parser.e:3435			SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60041 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29848 = (object)*(((s1_ptr)_2)->base + _valsym_60043);
    _2 = (object)SEQ_PTR(_29848);
    _29849 = (object)*(((s1_ptr)_2)->base + 32);
    _29848 = NOVALUE;
    Ref(_29849);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29849;
    if( _1 != _29849 ){
        DeRef(_1);
    }
    _29849 = NOVALUE;
    _29846 = NOVALUE;
L1: 

    /** parser.e:3437	end procedure*/
    DeRef(_val_60046);
    return;
    ;
}


object _43Global_declaration(object _type_ptr_60103, object _scope_60104)
{
    object _new_symbols_60105 = NOVALUE;
    object _tok_60107 = NOVALUE;
    object _tsym_60108 = NOVALUE;
    object _prevtok_60109 = NOVALUE;
    object _sym_60111 = NOVALUE;
    object _valsym_60112 = NOVALUE;
    object _h_60113 = NOVALUE;
    object _count_60114 = NOVALUE;
    object _val_60115 = NOVALUE;
    object _usedval_60116 = NOVALUE;
    object _deltafunc_60117 = NOVALUE;
    object _delta_60118 = NOVALUE;
    object _is_fwd_ref_60119 = NOVALUE;
    object _ptok_60136 = NOVALUE;
    object _negate_60152 = NOVALUE;
    object _negate_60401 = NOVALUE;
    object _31707 = NOVALUE;
    object _31706 = NOVALUE;
    object _31705 = NOVALUE;
    object _30089 = NOVALUE;
    object _30087 = NOVALUE;
    object _30085 = NOVALUE;
    object _30083 = NOVALUE;
    object _30081 = NOVALUE;
    object _30078 = NOVALUE;
    object _30076 = NOVALUE;
    object _30075 = NOVALUE;
    object _30074 = NOVALUE;
    object _30073 = NOVALUE;
    object _30072 = NOVALUE;
    object _30071 = NOVALUE;
    object _30069 = NOVALUE;
    object _30065 = NOVALUE;
    object _30063 = NOVALUE;
    object _30061 = NOVALUE;
    object _30059 = NOVALUE;
    object _30057 = NOVALUE;
    object _30055 = NOVALUE;
    object _30054 = NOVALUE;
    object _30052 = NOVALUE;
    object _30051 = NOVALUE;
    object _30050 = NOVALUE;
    object _30048 = NOVALUE;
    object _30046 = NOVALUE;
    object _30044 = NOVALUE;
    object _30043 = NOVALUE;
    object _30042 = NOVALUE;
    object _30040 = NOVALUE;
    object _30039 = NOVALUE;
    object _30038 = NOVALUE;
    object _30036 = NOVALUE;
    object _30034 = NOVALUE;
    object _30032 = NOVALUE;
    object _30031 = NOVALUE;
    object _30030 = NOVALUE;
    object _30029 = NOVALUE;
    object _30028 = NOVALUE;
    object _30025 = NOVALUE;
    object _30023 = NOVALUE;
    object _30021 = NOVALUE;
    object _30020 = NOVALUE;
    object _30019 = NOVALUE;
    object _30015 = NOVALUE;
    object _30014 = NOVALUE;
    object _30013 = NOVALUE;
    object _30009 = NOVALUE;
    object _30008 = NOVALUE;
    object _30007 = NOVALUE;
    object _30005 = NOVALUE;
    object _30004 = NOVALUE;
    object _30003 = NOVALUE;
    object _30002 = NOVALUE;
    object _30001 = NOVALUE;
    object _30000 = NOVALUE;
    object _29999 = NOVALUE;
    object _29998 = NOVALUE;
    object _29997 = NOVALUE;
    object _29994 = NOVALUE;
    object _29992 = NOVALUE;
    object _29991 = NOVALUE;
    object _29989 = NOVALUE;
    object _29988 = NOVALUE;
    object _29986 = NOVALUE;
    object _29985 = NOVALUE;
    object _29984 = NOVALUE;
    object _29983 = NOVALUE;
    object _29981 = NOVALUE;
    object _29979 = NOVALUE;
    object _29977 = NOVALUE;
    object _29974 = NOVALUE;
    object _29971 = NOVALUE;
    object _29968 = NOVALUE;
    object _29966 = NOVALUE;
    object _29965 = NOVALUE;
    object _29964 = NOVALUE;
    object _29963 = NOVALUE;
    object _29961 = NOVALUE;
    object _29960 = NOVALUE;
    object _29959 = NOVALUE;
    object _29958 = NOVALUE;
    object _29954 = NOVALUE;
    object _29953 = NOVALUE;
    object _29952 = NOVALUE;
    object _29951 = NOVALUE;
    object _29950 = NOVALUE;
    object _29949 = NOVALUE;
    object _29946 = NOVALUE;
    object _29944 = NOVALUE;
    object _29943 = NOVALUE;
    object _29942 = NOVALUE;
    object _29941 = NOVALUE;
    object _29940 = NOVALUE;
    object _29937 = NOVALUE;
    object _29935 = NOVALUE;
    object _29933 = NOVALUE;
    object _29932 = NOVALUE;
    object _29931 = NOVALUE;
    object _29930 = NOVALUE;
    object _29929 = NOVALUE;
    object _29928 = NOVALUE;
    object _29927 = NOVALUE;
    object _29925 = NOVALUE;
    object _29922 = NOVALUE;
    object _29920 = NOVALUE;
    object _29919 = NOVALUE;
    object _29918 = NOVALUE;
    object _29917 = NOVALUE;
    object _29916 = NOVALUE;
    object _29915 = NOVALUE;
    object _29914 = NOVALUE;
    object _29913 = NOVALUE;
    object _29910 = NOVALUE;
    object _29909 = NOVALUE;
    object _29908 = NOVALUE;
    object _29906 = NOVALUE;
    object _29905 = NOVALUE;
    object _29904 = NOVALUE;
    object _29903 = NOVALUE;
    object _29902 = NOVALUE;
    object _29900 = NOVALUE;
    object _29899 = NOVALUE;
    object _29898 = NOVALUE;
    object _29896 = NOVALUE;
    object _29895 = NOVALUE;
    object _29893 = NOVALUE;
    object _29890 = NOVALUE;
    object _29888 = NOVALUE;
    object _29886 = NOVALUE;
    object _29878 = NOVALUE;
    object _29877 = NOVALUE;
    object _29875 = NOVALUE;
    object _29872 = NOVALUE;
    object _29865 = NOVALUE;
    object _29862 = NOVALUE;
    object _29861 = NOVALUE;
    object _29859 = NOVALUE;
    object _29855 = NOVALUE;
    object _29854 = NOVALUE;
    object _29853 = NOVALUE;
    object _29852 = NOVALUE;
    object _29851 = NOVALUE;
    object _29850 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_ptr_60103)) {
        _1 = (object)(DBL_PTR(_type_ptr_60103)->dbl);
        DeRefDS(_type_ptr_60103);
        _type_ptr_60103 = _1;
    }

    /** parser.e:3447		object tsym*/

    /** parser.e:3448		object prevtok = 0*/
    DeRef(_prevtok_60109);
    _prevtok_60109 = 0;

    /** parser.e:3450		integer h, count = 0*/
    _count_60114 = 0;

    /** parser.e:3451		atom val = 1, usedval*/
    DeRef(_val_60115);
    _val_60115 = 1;

    /** parser.e:3452		integer deltafunc = '+'*/
    _deltafunc_60117 = 43;

    /** parser.e:3453		atom delta = 1*/
    DeRef(_delta_60118);
    _delta_60118 = 1;

    /** parser.e:3455		new_symbols = {}*/
    RefDS(_22015);
    DeRefi(_new_symbols_60105);
    _new_symbols_60105 = _22015;

    /** parser.e:3456		integer is_fwd_ref = 0*/
    _is_fwd_ref_60119 = 0;

    /** parser.e:3457		if type_ptr > 0 and SymTab[type_ptr][S_SCOPE] = SC_UNDEFINED then*/
    _29850 = (_type_ptr_60103 > 0);
    if (_29850 == 0) {
        goto L1; // [50] 105
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29852 = (object)*(((s1_ptr)_2)->base + _type_ptr_60103);
    _2 = (object)SEQ_PTR(_29852);
    _29853 = (object)*(((s1_ptr)_2)->base + 4);
    _29852 = NOVALUE;
    if (IS_ATOM_INT(_29853)) {
        _29854 = (_29853 == 9);
    }
    else {
        _29854 = binary_op(EQUALS, _29853, 9);
    }
    _29853 = NOVALUE;
    if (_29854 == 0) {
        DeRef(_29854);
        _29854 = NOVALUE;
        goto L1; // [73] 105
    }
    else {
        if (!IS_ATOM_INT(_29854) && DBL_PTR(_29854)->dbl == 0.0){
            DeRef(_29854);
            _29854 = NOVALUE;
            goto L1; // [73] 105
        }
        DeRef(_29854);
        _29854 = NOVALUE;
    }
    DeRef(_29854);
    _29854 = NOVALUE;

    /** parser.e:3458			is_fwd_ref = 1*/
    _is_fwd_ref_60119 = 1;

    /** parser.e:3459			Hide(type_ptr)*/
    _53Hide(_type_ptr_60103);

    /** parser.e:3460			type_ptr = -new_forward_reference( TYPE, type_ptr )*/
    DeRef(_31707);
    _31707 = 504;
    _29855 = _42new_forward_reference(504, _type_ptr_60103, 504);
    _31707 = NOVALUE;
    if (IS_ATOM_INT(_29855)) {
        if ((uintptr_t)_29855 == (uintptr_t)HIGH_BITS){
            _type_ptr_60103 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _type_ptr_60103 = - _29855;
        }
    }
    else {
        _type_ptr_60103 = unary_op(UMINUS, _29855);
    }
    DeRef(_29855);
    _29855 = NOVALUE;
    if (!IS_ATOM_INT(_type_ptr_60103)) {
        _1 = (object)(DBL_PTR(_type_ptr_60103)->dbl);
        DeRefDS(_type_ptr_60103);
        _type_ptr_60103 = _1;
    }
L1: 

    /** parser.e:3463		if type_ptr = -1 then*/
    if (_type_ptr_60103 != -1)
    goto L2; // [107] 426

    /** parser.e:3465			sequence ptok = next_token()*/
    _0 = _ptok_60136;
    _ptok_60136 = _43next_token();
    DeRef(_0);

    /** parser.e:3466			if ptok[T_ID] = TYPE_DECL then*/
    _2 = (object)SEQ_PTR(_ptok_60136);
    _29859 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29859, 416)){
        _29859 = NOVALUE;
        goto L3; // [128] 172
    }
    _29859 = NOVALUE;

    /** parser.e:3469				putback(keyfind("enum",-1))*/
    RefDS(_26204);
    DeRef(_31705);
    _31705 = _26204;
    _31706 = _53hashfn(_31705);
    _31705 = NOVALUE;
    RefDS(_26204);
    _29861 = _53keyfind(_26204, -1, _12current_file_no_20226, 0, _31706);
    _31706 = NOVALUE;
    _43putback(_29861);
    _29861 = NOVALUE;

    /** parser.e:3470				SubProg(TYPE_DECL, scope, 0)*/
    _43SubProg(416, _scope_60104, 0);

    /** parser.e:3471				return {}*/
    RefDS(_22015);
    DeRefDS(_ptok_60136);
    DeRefi(_new_symbols_60105);
    DeRef(_tok_60107);
    DeRef(_tsym_60108);
    DeRef(_prevtok_60109);
    DeRef(_val_60115);
    DeRef(_usedval_60116);
    DeRef(_delta_60118);
    DeRef(_29850);
    _29850 = NOVALUE;
    return _22015;
    goto L4; // [169] 425
L3: 

    /** parser.e:3472			elsif ptok[T_ID] = BY then*/
    _2 = (object)SEQ_PTR(_ptok_60136);
    _29862 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29862, 404)){
        _29862 = NOVALUE;
        goto L5; // [182] 419
    }
    _29862 = NOVALUE;

    /** parser.e:3474				integer negate = 0*/
    _negate_60152 = 0;

    /** parser.e:3475				ptok = next_token()*/
    _0 = _ptok_60136;
    _ptok_60136 = _43next_token();
    DeRefDS(_0);

    /** parser.e:3476				switch ptok[T_ID] do*/
    _2 = (object)SEQ_PTR(_ptok_60136);
    _29865 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_29865) ){
        goto L6; // [206] 285
    }
    if(!IS_ATOM_INT(_29865)){
        if( (DBL_PTR(_29865)->dbl != (eudouble) ((object) DBL_PTR(_29865)->dbl) ) ){
            goto L6; // [206] 285
        }
        _0 = (object) DBL_PTR(_29865)->dbl;
    }
    else {
        _0 = _29865;
    };
    _29865 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:3477					case reserved:MULTIPLY then*/
        case 13:

        /** parser.e:3478						deltafunc = '*'*/
        _deltafunc_60117 = 42;

        /** parser.e:3479						ptok = next_token()*/
        _0 = _ptok_60136;
        _ptok_60136 = _43next_token();
        DeRef(_0);
        goto L7; // [227] 293

        /** parser.e:3481					case reserved:DIVIDE then*/
        case 14:

        /** parser.e:3482						deltafunc = '/'*/
        _deltafunc_60117 = 47;

        /** parser.e:3483						ptok = next_token()*/
        _0 = _ptok_60136;
        _ptok_60136 = _43next_token();
        DeRef(_0);
        goto L7; // [245] 293

        /** parser.e:3485					case MINUS then*/
        case 10:

        /** parser.e:3486						deltafunc = '-'*/
        _deltafunc_60117 = 45;

        /** parser.e:3487						ptok = next_token()*/
        _0 = _ptok_60136;
        _ptok_60136 = _43next_token();
        DeRef(_0);
        goto L7; // [263] 293

        /** parser.e:3489					case PLUS then*/
        case 11:

        /** parser.e:3490						deltafunc = '+'*/
        _deltafunc_60117 = 43;

        /** parser.e:3491						ptok = next_token()*/
        _0 = _ptok_60136;
        _ptok_60136 = _43next_token();
        DeRef(_0);
        goto L7; // [281] 293

        /** parser.e:3493					case else*/
        default:
L6: 

        /** parser.e:3494						deltafunc = '+'*/
        _deltafunc_60117 = 43;
    ;}L7: 

    /** parser.e:3498				if ptok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_ptok_60136);
    _29872 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29872, 10)){
        _29872 = NOVALUE;
        goto L8; // [303] 320
    }
    _29872 = NOVALUE;

    /** parser.e:3499					negate = 1*/
    _negate_60152 = 1;

    /** parser.e:3500					ptok = next_token()*/
    _0 = _ptok_60136;
    _ptok_60136 = _43next_token();
    DeRefDS(_0);
L8: 

    /** parser.e:3502				if ptok[T_ID] != ATOM then*/
    _2 = (object)SEQ_PTR(_ptok_60136);
    _29875 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29875, 502)){
        _29875 = NOVALUE;
        goto L9; // [330] 344
    }
    _29875 = NOVALUE;

    /** parser.e:3503					CompileErr( A_NUMERIC_LITERAL_WAS_EXPECTED)*/
    RefDS(_22015);
    _49CompileErr(344, _22015, 0);
L9: 

    /** parser.e:3506				delta = SymTab[ptok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_ptok_60136);
    _29877 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_29877)){
        _29878 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29877)->dbl));
    }
    else{
        _29878 = (object)*(((s1_ptr)_2)->base + _29877);
    }
    DeRef(_delta_60118);
    _2 = (object)SEQ_PTR(_29878);
    _delta_60118 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_delta_60118);
    _29878 = NOVALUE;

    /** parser.e:3507				if negate then*/
    if (_negate_60152 == 0)
    {
        goto LA; // [366] 375
    }
    else{
    }

    /** parser.e:3508					delta = -delta*/
    _0 = _delta_60118;
    if (IS_ATOM_INT(_delta_60118)) {
        if ((uintptr_t)_delta_60118 == (uintptr_t)HIGH_BITS){
            _delta_60118 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _delta_60118 = - _delta_60118;
        }
    }
    else {
        _delta_60118 = unary_op(UMINUS, _delta_60118);
    }
    DeRef(_0);
LA: 

    /** parser.e:3511				switch deltafunc do*/
    _0 = _deltafunc_60117;
    switch ( _0 ){ 

        /** parser.e:3512					case '/' then*/
        case 47:

        /** parser.e:3513						delta = 1 / delta*/
        _0 = _delta_60118;
        if (IS_ATOM_INT(_delta_60118)) {
            _delta_60118 = (1 % _delta_60118) ? NewDouble((eudouble)1 / _delta_60118) : (1 / _delta_60118);
        }
        else {
            _delta_60118 = NewDouble((eudouble)1 / DBL_PTR(_delta_60118)->dbl);
        }
        DeRef(_0);

        /** parser.e:3514						deltafunc = '*'*/
        _deltafunc_60117 = 42;
        goto LB; // [397] 414

        /** parser.e:3516					case '-' then*/
        case 45:

        /** parser.e:3517						delta = -delta*/
        _0 = _delta_60118;
        if (IS_ATOM_INT(_delta_60118)) {
            if ((uintptr_t)_delta_60118 == (uintptr_t)HIGH_BITS){
                _delta_60118 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _delta_60118 = - _delta_60118;
            }
        }
        else {
            _delta_60118 = unary_op(UMINUS, _delta_60118);
        }
        DeRef(_0);

        /** parser.e:3518						deltafunc = '+'*/
        _deltafunc_60117 = 43;
    ;}LB: 
    goto L4; // [416] 425
L5: 

    /** parser.e:3523				putback(ptok)*/
    RefDS(_ptok_60136);
    _43putback(_ptok_60136);
L4: 
L2: 
    DeRef(_ptok_60136);
    _ptok_60136 = NOVALUE;

    /** parser.e:3527		valsym = 0*/
    _valsym_60112 = 0;

    /** parser.e:3528		while TRUE do*/
LC: 
    if (_9TRUE_446 == 0)
    {
        goto LD; // [442] 2303
    }
    else{
    }

    /** parser.e:3529			tok = next_token()*/
    _0 = _tok_60107;
    _tok_60107 = _43next_token();
    DeRef(_0);

    /** parser.e:3530			if tok[T_ID] = DOLLAR then*/
    _2 = (object)SEQ_PTR(_tok_60107);
    _29886 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29886, -22)){
        _29886 = NOVALUE;
        goto LE; // [460] 499
    }
    _29886 = NOVALUE;

    /** parser.e:3531				if not equal(prevtok, 0) then*/
    if (_prevtok_60109 == 0)
    _29888 = 1;
    else if (IS_ATOM_INT(_prevtok_60109) && IS_ATOM_INT(0))
    _29888 = 0;
    else
    _29888 = (compare(_prevtok_60109, 0) == 0);
    if (_29888 != 0)
    goto LF; // [470] 498
    _29888 = NOVALUE;

    /** parser.e:3532					if prevtok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_prevtok_60109);
    _29890 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29890, -30)){
        _29890 = NOVALUE;
        goto L10; // [483] 497
    }
    _29890 = NOVALUE;

    /** parser.e:3534						tok = next_token()*/
    _0 = _tok_60107;
    _tok_60107 = _43next_token();
    DeRef(_0);

    /** parser.e:3535						exit*/
    goto LD; // [494] 2303
L10: 
LF: 
LE: 

    /** parser.e:3539			if tok[T_ID] = END_OF_FILE then*/
    _2 = (object)SEQ_PTR(_tok_60107);
    _29893 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29893, -21)){
        _29893 = NOVALUE;
        goto L11; // [509] 523
    }
    _29893 = NOVALUE;

    /** parser.e:3540				CompileErr( AN_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_22015);
    _49CompileErr(32, _22015, 0);
L11: 

    /** parser.e:3543			if not find(tok[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_60107);
    _29895 = (object)*(((s1_ptr)_2)->base + 1);
    _29896 = find_from(_29895, _29ADDR_TOKS_12010, 1);
    _29895 = NOVALUE;
    if (_29896 != 0)
    goto L12; // [538] 565
    _29896 = NOVALUE;

    /** parser.e:3544				CompileErr(FOUND__1__BUT_WAS_EXPECTING_AN_IDENTIFIER_NAME, {find_category(tok[T_ID])} )*/
    _2 = (object)SEQ_PTR(_tok_60107);
    _29898 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29898);
    _29899 = _62find_category(_29898);
    _29898 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _29899;
    _29900 = MAKE_SEQ(_1);
    _29899 = NOVALUE;
    _49CompileErr(25, _29900, 0);
    _29900 = NOVALUE;
L12: 

    /** parser.e:3546			sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60107);
    _sym_60111 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_60111)){
        _sym_60111 = (object)DBL_PTR(_sym_60111)->dbl;
    }

    /** parser.e:3547			DefinedYet(sym)*/
    _53DefinedYet(_sym_60111);

    /** parser.e:3548			if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT}) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29902 = (object)*(((s1_ptr)_2)->base + _sym_60111);
    _2 = (object)SEQ_PTR(_29902);
    _29903 = (object)*(((s1_ptr)_2)->base + 4);
    _29902 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 6;
    ((intptr_t*)_2)[2] = 7;
    ((intptr_t*)_2)[3] = 13;
    ((intptr_t*)_2)[4] = 11;
    _29904 = MAKE_SEQ(_1);
    _29905 = find_from(_29903, _29904, 1);
    _29903 = NOVALUE;
    DeRefDS(_29904);
    _29904 = NOVALUE;
    if (_29905 == 0)
    {
        _29905 = NOVALUE;
        goto L13; // [614] 676
    }
    else{
        _29905 = NOVALUE;
    }

    /** parser.e:3549				h = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29906 = (object)*(((s1_ptr)_2)->base + _sym_60111);
    _2 = (object)SEQ_PTR(_29906);
    _h_60113 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_60113)){
        _h_60113 = (object)DBL_PTR(_h_60113)->dbl;
    }
    _29906 = NOVALUE;

    /** parser.e:3551				sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29908 = (object)*(((s1_ptr)_2)->base + _sym_60111);
    _2 = (object)SEQ_PTR(_29908);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _29909 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _29909 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _29908 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_46799);
    _29910 = (object)*(((s1_ptr)_2)->base + _h_60113);
    Ref(_29909);
    Ref(_29910);
    _sym_60111 = _53NewEntry(_29909, 0, 0, -100, _h_60113, _29910, 0);
    _29909 = NOVALUE;
    _29910 = NOVALUE;
    if (!IS_ATOM_INT(_sym_60111)) {
        _1 = (object)(DBL_PTR(_sym_60111)->dbl);
        DeRefDS(_sym_60111);
        _sym_60111 = _1;
    }

    /** parser.e:3552				buckets[h] = sym*/
    _2 = (object)SEQ_PTR(_53buckets_46799);
    _2 = (object)(((s1_ptr)_2)->base + _h_60113);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_60111;
    DeRef(_1);
L13: 

    /** parser.e:3555			new_symbols = append(new_symbols, sym)*/
    Append(&_new_symbols_60105, _new_symbols_60105, _sym_60111);

    /** parser.e:3556			Block_var( sym )*/
    _64Block_var(_sym_60111);

    /** parser.e:3557			if SymTab[sym][S_SCOPE] = SC_UNDEFINED and SymTab[sym][S_FILE_NO] != current_file_no then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29913 = (object)*(((s1_ptr)_2)->base + _sym_60111);
    _2 = (object)SEQ_PTR(_29913);
    _29914 = (object)*(((s1_ptr)_2)->base + 4);
    _29913 = NOVALUE;
    if (IS_ATOM_INT(_29914)) {
        _29915 = (_29914 == 9);
    }
    else {
        _29915 = binary_op(EQUALS, _29914, 9);
    }
    _29914 = NOVALUE;
    if (IS_ATOM_INT(_29915)) {
        if (_29915 == 0) {
            goto L14; // [707] 751
        }
    }
    else {
        if (DBL_PTR(_29915)->dbl == 0.0) {
            goto L14; // [707] 751
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29917 = (object)*(((s1_ptr)_2)->base + _sym_60111);
    _2 = (object)SEQ_PTR(_29917);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _29918 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _29918 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _29917 = NOVALUE;
    if (IS_ATOM_INT(_29918)) {
        _29919 = (_29918 != _12current_file_no_20226);
    }
    else {
        _29919 = binary_op(NOTEQ, _29918, _12current_file_no_20226);
    }
    _29918 = NOVALUE;
    if (_29919 == 0) {
        DeRef(_29919);
        _29919 = NOVALUE;
        goto L14; // [730] 751
    }
    else {
        if (!IS_ATOM_INT(_29919) && DBL_PTR(_29919)->dbl == 0.0){
            DeRef(_29919);
            _29919 = NOVALUE;
            goto L14; // [730] 751
        }
        DeRef(_29919);
        _29919 = NOVALUE;
    }
    DeRef(_29919);
    _29919 = NOVALUE;

    /** parser.e:3558				SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FILE_NO_19860))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12current_file_no_20226;
    DeRef(_1);
    _29920 = NOVALUE;
L14: 

    /** parser.e:3560			SymTab[sym][S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_60104;
    DeRef(_1);
    _29922 = NOVALUE;

    /** parser.e:3562			if type_ptr = 0 then*/
    if (_type_ptr_60103 != 0)
    goto L15; // [768] 1103

    /** parser.e:3564				SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _29925 = NOVALUE;

    /** parser.e:3566				buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29927 = (object)*(((s1_ptr)_2)->base + _sym_60111);
    _2 = (object)SEQ_PTR(_29927);
    _29928 = (object)*(((s1_ptr)_2)->base + 11);
    _29927 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29929 = (object)*(((s1_ptr)_2)->base + _sym_60111);
    _2 = (object)SEQ_PTR(_29929);
    _29930 = (object)*(((s1_ptr)_2)->base + 9);
    _29929 = NOVALUE;
    Ref(_29930);
    _2 = (object)SEQ_PTR(_53buckets_46799);
    if (!IS_ATOM_INT(_29928))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29928)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _29928);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29930;
    if( _1 != _29930 ){
        DeRef(_1);
    }
    _29930 = NOVALUE;

    /** parser.e:3567				tok_match(EQUALS)*/
    _43tok_match(3, 0);

    /** parser.e:3568				StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _45StartSourceLine(_9FALSE_444, 0, 3);

    /** parser.e:3569				emit_opnd(sym)*/
    _45emit_opnd(_sym_60111);

    /** parser.e:3570				Expr()  -- no new symbols can be defined in here*/
    _43Expr();

    /** parser.e:3571				buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29931 = (object)*(((s1_ptr)_2)->base + _sym_60111);
    _2 = (object)SEQ_PTR(_29931);
    _29932 = (object)*(((s1_ptr)_2)->base + 11);
    _29931 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_46799);
    if (!IS_ATOM_INT(_29932))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29932)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _29932);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_60111;
    DeRef(_1);

    /** parser.e:3572				SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _29933 = NOVALUE;

    /** parser.e:3573				if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L16; // [890] 928
    }
    else{
    }

    /** parser.e:3574					SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    _29935 = NOVALUE;

    /** parser.e:3575					SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
    _29937 = NOVALUE;
L16: 

    /** parser.e:3577				valsym = Top()*/
    _valsym_60112 = _45Top();
    if (!IS_ATOM_INT(_valsym_60112)) {
        _1 = (object)(DBL_PTR(_valsym_60112)->dbl);
        DeRefDS(_valsym_60112);
        _valsym_60112 = _1;
    }

    /** parser.e:3579				if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _29940 = (_valsym_60112 > 0);
    if (_29940 == 0) {
        goto L17; // [941] 982
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29942 = (object)*(((s1_ptr)_2)->base + _valsym_60112);
    _2 = (object)SEQ_PTR(_29942);
    _29943 = (object)*(((s1_ptr)_2)->base + 1);
    _29942 = NOVALUE;
    if (IS_ATOM_INT(_29943) && IS_ATOM_INT(_12NOVALUE_20081)){
        _29944 = (_29943 < _12NOVALUE_20081) ? -1 : (_29943 > _12NOVALUE_20081);
    }
    else{
        _29944 = compare(_29943, _12NOVALUE_20081);
    }
    _29943 = NOVALUE;
    if (_29944 == 0)
    {
        _29944 = NOVALUE;
        goto L17; // [964] 982
    }
    else{
        _29944 = NOVALUE;
    }

    /** parser.e:3580					Assign_Constant( sym )*/
    _43Assign_Constant(_sym_60111);

    /** parser.e:3581					sym = Pop()*/
    _sym_60111 = _45Pop();
    if (!IS_ATOM_INT(_sym_60111)) {
        _1 = (object)(DBL_PTR(_sym_60111)->dbl);
        DeRefDS(_sym_60111);
        _sym_60111 = _1;
    }
    goto L18; // [979] 2269
L17: 

    /** parser.e:3584					emit_op(ASSIGN)*/
    _45emit_op(18);

    /** parser.e:3585					if Last_op() = ASSIGN then*/
    _29946 = _45Last_op();
    if (binary_op_a(NOTEQ, _29946, 18)){
        DeRef(_29946);
        _29946 = NOVALUE;
        goto L19; // [996] 1010
    }
    DeRef(_29946);
    _29946 = NOVALUE;

    /** parser.e:3586						valsym = get_assigned_sym()*/
    _valsym_60112 = _43get_assigned_sym();
    if (!IS_ATOM_INT(_valsym_60112)) {
        _1 = (object)(DBL_PTR(_valsym_60112)->dbl);
        DeRefDS(_valsym_60112);
        _valsym_60112 = _1;
    }
    goto L1A; // [1007] 1018
L19: 

    /** parser.e:3589						valsym = -1*/
    _valsym_60112 = -1;
L1A: 

    /** parser.e:3591					if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _29949 = (_valsym_60112 > 0);
    if (_29949 == 0) {
        goto L1B; // [1024] 1066
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29951 = (object)*(((s1_ptr)_2)->base + _valsym_60112);
    _2 = (object)SEQ_PTR(_29951);
    _29952 = (object)*(((s1_ptr)_2)->base + 1);
    _29951 = NOVALUE;
    if (IS_ATOM_INT(_29952) && IS_ATOM_INT(_12NOVALUE_20081)){
        _29953 = (_29952 < _12NOVALUE_20081) ? -1 : (_29952 > _12NOVALUE_20081);
    }
    else{
        _29953 = compare(_29952, _12NOVALUE_20081);
    }
    _29952 = NOVALUE;
    if (_29953 == 0)
    {
        _29953 = NOVALUE;
        goto L1B; // [1047] 1066
    }
    else{
        _29953 = NOVALUE;
    }

    /** parser.e:3593						SymTab[sym][S_CODE] = valsym*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _valsym_60112;
    DeRef(_1);
    _29954 = NOVALUE;
L1B: 

    /** parser.e:3596					if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L18; // [1070] 2269
    }
    else{
    }

    /** parser.e:3597						count += 1*/
    _count_60114 = _count_60114 + 1;

    /** parser.e:3598						if count = 10 then*/
    if (_count_60114 != 10)
    goto L18; // [1081] 2269

    /** parser.e:3599							count = 0*/
    _count_60114 = 0;

    /** parser.e:3601							emit_op( RETURNT )*/
    _45emit_op(34);
    goto L18; // [1100] 2269
L15: 

    /** parser.e:3606			elsif type_ptr = -1 and not is_fwd_ref then*/
    _29958 = (_type_ptr_60103 == -1);
    if (_29958 == 0) {
        goto L1C; // [1109] 2096
    }
    _29960 = (_is_fwd_ref_60119 == 0);
    if (_29960 == 0)
    {
        DeRef(_29960);
        _29960 = NOVALUE;
        goto L1C; // [1117] 2096
    }
    else{
        DeRef(_29960);
        _29960 = NOVALUE;
    }

    /** parser.e:3608				StartSourceLine(FALSE, , COVERAGE_OVERRIDE )*/
    _45StartSourceLine(_9FALSE_444, 0, 3);

    /** parser.e:3609				SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _29961 = NOVALUE;

    /** parser.e:3611				buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29963 = (object)*(((s1_ptr)_2)->base + _sym_60111);
    _2 = (object)SEQ_PTR(_29963);
    _29964 = (object)*(((s1_ptr)_2)->base + 11);
    _29963 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29965 = (object)*(((s1_ptr)_2)->base + _sym_60111);
    _2 = (object)SEQ_PTR(_29965);
    _29966 = (object)*(((s1_ptr)_2)->base + 9);
    _29965 = NOVALUE;
    Ref(_29966);
    _2 = (object)SEQ_PTR(_53buckets_46799);
    if (!IS_ATOM_INT(_29964))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29964)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _29964);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29966;
    if( _1 != _29966 ){
        DeRef(_1);
    }
    _29966 = NOVALUE;

    /** parser.e:3612				tok = next_token()*/
    _0 = _tok_60107;
    _tok_60107 = _43next_token();
    DeRef(_0);

    /** parser.e:3615				emit_opnd(sym)*/
    _45emit_opnd(_sym_60111);

    /** parser.e:3617				if tok[T_ID] = EQUALS then*/
    _2 = (object)SEQ_PTR(_tok_60107);
    _29968 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29968, 3)){
        _29968 = NOVALUE;
        goto L1D; // [1200] 1607
    }
    _29968 = NOVALUE;

    /** parser.e:3618					integer negate = 1*/
    _negate_60401 = 1;

    /** parser.e:3620					tok = next_token()*/
    _0 = _tok_60107;
    _tok_60107 = _43next_token();
    DeRef(_0);

    /** parser.e:3621					if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_60107);
    _29971 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29971, 10)){
        _29971 = NOVALUE;
        goto L1E; // [1224] 1239
    }
    _29971 = NOVALUE;

    /** parser.e:3622						negate = -1*/
    _negate_60401 = -1;

    /** parser.e:3623						tok = next_token()*/
    _0 = _tok_60107;
    _tok_60107 = _43next_token();
    DeRef(_0);
L1E: 

    /** parser.e:3626					if tok[T_ID] = ATOM then*/
    _2 = (object)SEQ_PTR(_tok_60107);
    _29974 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29974, 502)){
        _29974 = NOVALUE;
        goto L1F; // [1249] 1266
    }
    _29974 = NOVALUE;

    /** parser.e:3627						valsym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60107);
    _valsym_60112 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_60112)){
        _valsym_60112 = (object)DBL_PTR(_valsym_60112)->dbl;
    }
    goto L20; // [1263] 1464
L1F: 

    /** parser.e:3628					elsif tok[T_SYM] > 0 then*/
    _2 = (object)SEQ_PTR(_tok_60107);
    _29977 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(LESSEQ, _29977, 0)){
        _29977 = NOVALUE;
        goto L21; // [1274] 1454
    }
    _29977 = NOVALUE;

    /** parser.e:3629						tsym = SymTab[tok[T_SYM]]*/
    _2 = (object)SEQ_PTR(_tok_60107);
    _29979 = (object)*(((s1_ptr)_2)->base + 2);
    DeRef(_tsym_60108);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_29979)){
        _tsym_60108 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29979)->dbl));
    }
    else{
        _tsym_60108 = (object)*(((s1_ptr)_2)->base + _29979);
    }
    Ref(_tsym_60108);

    /** parser.e:3630						if tsym[S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_tsym_60108);
    _29981 = (object)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _29981, 2)){
        _29981 = NOVALUE;
        goto L22; // [1302] 1415
    }
    _29981 = NOVALUE;

    /** parser.e:3631							if length(tsym) >= S_CODE and tsym[S_CODE] then*/
    if (IS_SEQUENCE(_tsym_60108)){
            _29983 = SEQ_PTR(_tsym_60108)->length;
    }
    else {
        _29983 = 1;
    }
    if (IS_ATOM_INT(_12S_CODE_19876)) {
        _29984 = (_29983 >= _12S_CODE_19876);
    }
    else {
        _29984 = binary_op(GREATEREQ, _29983, _12S_CODE_19876);
    }
    _29983 = NOVALUE;
    if (IS_ATOM_INT(_29984)) {
        if (_29984 == 0) {
            goto L23; // [1317] 1344
        }
    }
    else {
        if (DBL_PTR(_29984)->dbl == 0.0) {
            goto L23; // [1317] 1344
        }
    }
    _2 = (object)SEQ_PTR(_tsym_60108);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _29986 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _29986 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    if (_29986 == 0) {
        _29986 = NOVALUE;
        goto L23; // [1328] 1344
    }
    else {
        if (!IS_ATOM_INT(_29986) && DBL_PTR(_29986)->dbl == 0.0){
            _29986 = NOVALUE;
            goto L23; // [1328] 1344
        }
        _29986 = NOVALUE;
    }
    _29986 = NOVALUE;

    /** parser.e:3632								valsym = tsym[S_CODE]*/
    _2 = (object)SEQ_PTR(_tsym_60108);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _valsym_60112 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _valsym_60112 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    if (!IS_ATOM_INT(_valsym_60112)){
        _valsym_60112 = (object)DBL_PTR(_valsym_60112)->dbl;
    }
    goto L20; // [1341] 1464
L23: 

    /** parser.e:3634							elsif not equal( tsym[S_OBJ], NOVALUE ) then*/
    _2 = (object)SEQ_PTR(_tsym_60108);
    _29988 = (object)*(((s1_ptr)_2)->base + 1);
    if (_29988 == _12NOVALUE_20081)
    _29989 = 1;
    else if (IS_ATOM_INT(_29988) && IS_ATOM_INT(_12NOVALUE_20081))
    _29989 = 0;
    else
    _29989 = (compare(_29988, _12NOVALUE_20081) == 0);
    _29988 = NOVALUE;
    if (_29989 != 0)
    goto L24; // [1358] 1402
    _29989 = NOVALUE;

    /** parser.e:3635								if is_integer(tsym[S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_tsym_60108);
    _29991 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29991);
    _29992 = _12is_integer(_29991);
    _29991 = NOVALUE;
    if (_29992 == 0) {
        DeRef(_29992);
        _29992 = NOVALUE;
        goto L25; // [1373] 1389
    }
    else {
        if (!IS_ATOM_INT(_29992) && DBL_PTR(_29992)->dbl == 0.0){
            DeRef(_29992);
            _29992 = NOVALUE;
            goto L25; // [1373] 1389
        }
        DeRef(_29992);
        _29992 = NOVALUE;
    }
    DeRef(_29992);
    _29992 = NOVALUE;

    /** parser.e:3636									valsym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60107);
    _valsym_60112 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_60112)){
        _valsym_60112 = (object)DBL_PTR(_valsym_60112)->dbl;
    }
    goto L20; // [1386] 1464
L25: 

    /** parser.e:3638									CompileErr(AN_ENUM_CONSTANT_MUST_BE_AN_INTEGER)*/
    RefDS(_22015);
    _49CompileErr(30, _22015, 0);
    goto L20; // [1399] 1464
L24: 

    /** parser.e:3641								CompileErr(ENUM_CONSTANTS_MUST_BE_ASSIGNED_AN_INTEGER)*/
    RefDS(_22015);
    _49CompileErr(70, _22015, 0);
    goto L20; // [1412] 1464
L22: 

    /** parser.e:3643						elsif tsym[S_OBJ] = NOVALUE then*/
    _2 = (object)SEQ_PTR(_tsym_60108);
    _29994 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29994, _12NOVALUE_20081)){
        _29994 = NOVALUE;
        goto L26; // [1425] 1441
    }
    _29994 = NOVALUE;

    /** parser.e:3645							CompileErr(ENUM_FWD_REFERENCES_NOT_SUPPORTED)*/
    RefDS(_22015);
    _49CompileErr(331, _22015, 0);
    goto L20; // [1438] 1464
L26: 

    /** parser.e:3647							CompileErr(INTEGER_OR_CONSTANT_EXPECTED)*/
    RefDS(_22015);
    _49CompileErr(99, _22015, 0);
    goto L20; // [1451] 1464
L21: 

    /** parser.e:3651							CompileErr(INTEGER_OR_CONSTANT_EXPECTED)*/
    RefDS(_22015);
    _49CompileErr(99, _22015, 0);
L20: 

    /** parser.e:3653					valsym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60107);
    _valsym_60112 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_60112)){
        _valsym_60112 = (object)DBL_PTR(_valsym_60112)->dbl;
    }

    /** parser.e:3654					if not atom( SymTab[valsym][S_OBJ] ) and tsym[S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29997 = (object)*(((s1_ptr)_2)->base + _valsym_60112);
    _2 = (object)SEQ_PTR(_29997);
    _29998 = (object)*(((s1_ptr)_2)->base + 1);
    _29997 = NOVALUE;
    _29999 = IS_ATOM(_29998);
    _29998 = NOVALUE;
    _30000 = (_29999 == 0);
    _29999 = NOVALUE;
    if (_30000 == 0) {
        goto L27; // [1494] 1526
    }
    _2 = (object)SEQ_PTR(_tsym_60108);
    _30002 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_30002)) {
        _30003 = (_30002 != 9);
    }
    else {
        _30003 = binary_op(NOTEQ, _30002, 9);
    }
    _30002 = NOVALUE;
    if (_30003 == 0) {
        DeRef(_30003);
        _30003 = NOVALUE;
        goto L27; // [1513] 1526
    }
    else {
        if (!IS_ATOM_INT(_30003) && DBL_PTR(_30003)->dbl == 0.0){
            DeRef(_30003);
            _30003 = NOVALUE;
            goto L27; // [1513] 1526
        }
        DeRef(_30003);
        _30003 = NOVALUE;
    }
    DeRef(_30003);
    _30003 = NOVALUE;

    /** parser.e:3655						CompileErr(ENUM_CONSTANTS_MUST_BE_INTEGERS)*/
    RefDS(_22015);
    _49CompileErr(84, _22015, 0);
L27: 

    /** parser.e:3657					val = SymTab[valsym][S_OBJ] * negate*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30004 = (object)*(((s1_ptr)_2)->base + _valsym_60112);
    _2 = (object)SEQ_PTR(_30004);
    _30005 = (object)*(((s1_ptr)_2)->base + 1);
    _30004 = NOVALUE;
    DeRef(_val_60115);
    if (IS_ATOM_INT(_30005)) {
        if (_30005 == (short)_30005 && _negate_60401 <= INT15 && _negate_60401 >= -INT15){
            _val_60115 = _30005 * _negate_60401;
        }
        else{
            _val_60115 = NewDouble(_30005 * (eudouble)_negate_60401);
        }
    }
    else {
        _val_60115 = binary_op(MULTIPLY, _30005, _negate_60401);
    }
    _30005 = NOVALUE;

    /** parser.e:3658					if is_integer(val) then*/
    Ref(_val_60115);
    _30007 = _12is_integer(_val_60115);
    if (_30007 == 0) {
        DeRef(_30007);
        _30007 = NOVALUE;
        goto L28; // [1550] 1565
    }
    else {
        if (!IS_ATOM_INT(_30007) && DBL_PTR(_30007)->dbl == 0.0){
            DeRef(_30007);
            _30007 = NOVALUE;
            goto L28; // [1550] 1565
        }
        DeRef(_30007);
        _30007 = NOVALUE;
    }
    DeRef(_30007);
    _30007 = NOVALUE;

    /** parser.e:3659						Push(NewIntSym(val))*/
    Ref(_val_60115);
    _30008 = _53NewIntSym(_val_60115);
    _45Push(_30008);
    _30008 = NOVALUE;
    goto L29; // [1562] 1575
L28: 

    /** parser.e:3661						Push(NewDoubleSym(val))*/
    Ref(_val_60115);
    _30009 = _53NewDoubleSym(_val_60115);
    _45Push(_30009);
    _30009 = NOVALUE;
L29: 

    /** parser.e:3663					usedval = val*/
    Ref(_val_60115);
    DeRef(_usedval_60116);
    _usedval_60116 = _val_60115;

    /** parser.e:3664					if deltafunc = '+' then*/
    if (_deltafunc_60117 != 43)
    goto L2A; // [1582] 1595

    /** parser.e:3665						val += delta*/
    _0 = _val_60115;
    if (IS_ATOM_INT(_val_60115) && IS_ATOM_INT(_delta_60118)) {
        _val_60115 = _val_60115 + _delta_60118;
        if ((object)((uintptr_t)_val_60115 + (uintptr_t)HIGH_BITS) >= 0){
            _val_60115 = NewDouble((eudouble)_val_60115);
        }
    }
    else {
        if (IS_ATOM_INT(_val_60115)) {
            _val_60115 = NewDouble((eudouble)_val_60115 + DBL_PTR(_delta_60118)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60118)) {
                _val_60115 = NewDouble(DBL_PTR(_val_60115)->dbl + (eudouble)_delta_60118);
            }
            else
            _val_60115 = NewDouble(DBL_PTR(_val_60115)->dbl + DBL_PTR(_delta_60118)->dbl);
        }
    }
    DeRef(_0);
    goto L2B; // [1592] 1602
L2A: 

    /** parser.e:3667						val *= delta*/
    _0 = _val_60115;
    if (IS_ATOM_INT(_val_60115) && IS_ATOM_INT(_delta_60118)) {
        if (_val_60115 == (short)_val_60115 && _delta_60118 <= INT15 && _delta_60118 >= -INT15){
            _val_60115 = _val_60115 * _delta_60118;
        }
        else{
            _val_60115 = NewDouble(_val_60115 * (eudouble)_delta_60118);
        }
    }
    else {
        if (IS_ATOM_INT(_val_60115)) {
            _val_60115 = NewDouble((eudouble)_val_60115 * DBL_PTR(_delta_60118)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60118)) {
                _val_60115 = NewDouble(DBL_PTR(_val_60115)->dbl * (eudouble)_delta_60118);
            }
            else
            _val_60115 = NewDouble(DBL_PTR(_val_60115)->dbl * DBL_PTR(_delta_60118)->dbl);
        }
    }
    DeRef(_0);
L2B: 
    goto L2C; // [1604] 1678
L1D: 

    /** parser.e:3670					putback(tok)*/
    Ref(_tok_60107);
    _43putback(_tok_60107);

    /** parser.e:3671					if is_integer(val) then*/
    Ref(_val_60115);
    _30013 = _12is_integer(_val_60115);
    if (_30013 == 0) {
        DeRef(_30013);
        _30013 = NOVALUE;
        goto L2D; // [1618] 1633
    }
    else {
        if (!IS_ATOM_INT(_30013) && DBL_PTR(_30013)->dbl == 0.0){
            DeRef(_30013);
            _30013 = NOVALUE;
            goto L2D; // [1618] 1633
        }
        DeRef(_30013);
        _30013 = NOVALUE;
    }
    DeRef(_30013);
    _30013 = NOVALUE;

    /** parser.e:3672						Push(NewIntSym(val))*/
    Ref(_val_60115);
    _30014 = _53NewIntSym(_val_60115);
    _45Push(_30014);
    _30014 = NOVALUE;
    goto L2E; // [1630] 1643
L2D: 

    /** parser.e:3674						Push(NewDoubleSym(val))*/
    Ref(_val_60115);
    _30015 = _53NewDoubleSym(_val_60115);
    _45Push(_30015);
    _30015 = NOVALUE;
L2E: 

    /** parser.e:3676					usedval = val*/
    Ref(_val_60115);
    DeRef(_usedval_60116);
    _usedval_60116 = _val_60115;

    /** parser.e:3677					if deltafunc = '+' then*/
    if (_deltafunc_60117 != 43)
    goto L2F; // [1650] 1663

    /** parser.e:3678						val += delta*/
    _0 = _val_60115;
    if (IS_ATOM_INT(_val_60115) && IS_ATOM_INT(_delta_60118)) {
        _val_60115 = _val_60115 + _delta_60118;
        if ((object)((uintptr_t)_val_60115 + (uintptr_t)HIGH_BITS) >= 0){
            _val_60115 = NewDouble((eudouble)_val_60115);
        }
    }
    else {
        if (IS_ATOM_INT(_val_60115)) {
            _val_60115 = NewDouble((eudouble)_val_60115 + DBL_PTR(_delta_60118)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60118)) {
                _val_60115 = NewDouble(DBL_PTR(_val_60115)->dbl + (eudouble)_delta_60118);
            }
            else
            _val_60115 = NewDouble(DBL_PTR(_val_60115)->dbl + DBL_PTR(_delta_60118)->dbl);
        }
    }
    DeRef(_0);
    goto L30; // [1660] 1670
L2F: 

    /** parser.e:3680						val *= delta*/
    _0 = _val_60115;
    if (IS_ATOM_INT(_val_60115) && IS_ATOM_INT(_delta_60118)) {
        if (_val_60115 == (short)_val_60115 && _delta_60118 <= INT15 && _delta_60118 >= -INT15){
            _val_60115 = _val_60115 * _delta_60118;
        }
        else{
            _val_60115 = NewDouble(_val_60115 * (eudouble)_delta_60118);
        }
    }
    else {
        if (IS_ATOM_INT(_val_60115)) {
            _val_60115 = NewDouble((eudouble)_val_60115 * DBL_PTR(_delta_60118)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60118)) {
                _val_60115 = NewDouble(DBL_PTR(_val_60115)->dbl * (eudouble)_delta_60118);
            }
            else
            _val_60115 = NewDouble(DBL_PTR(_val_60115)->dbl * DBL_PTR(_delta_60118)->dbl);
        }
    }
    DeRef(_0);
L30: 

    /** parser.e:3682					valsym = 0*/
    _valsym_60112 = 0;
L2C: 

    /** parser.e:3684				buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30019 = (object)*(((s1_ptr)_2)->base + _sym_60111);
    _2 = (object)SEQ_PTR(_30019);
    _30020 = (object)*(((s1_ptr)_2)->base + 11);
    _30019 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_46799);
    if (!IS_ATOM_INT(_30020))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30020)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _30020);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_60111;
    DeRef(_1);

    /** parser.e:3685				SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _30021 = NOVALUE;

    /** parser.e:3687				if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L31; // [1719] 1757
    }
    else{
    }

    /** parser.e:3688					SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    _30023 = NOVALUE;

    /** parser.e:3689					SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
    _30025 = NOVALUE;
L31: 

    /** parser.e:3692				if valsym < 0 then*/
    if (_valsym_60112 >= 0)
    goto L32; // [1759] 1764
L32: 

    /** parser.e:3697				if valsym and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    if (_valsym_60112 == 0) {
        goto L33; // [1766] 1946
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30029 = (object)*(((s1_ptr)_2)->base + _valsym_60112);
    _2 = (object)SEQ_PTR(_30029);
    _30030 = (object)*(((s1_ptr)_2)->base + 1);
    _30029 = NOVALUE;
    if (IS_ATOM_INT(_30030) && IS_ATOM_INT(_12NOVALUE_20081)){
        _30031 = (_30030 < _12NOVALUE_20081) ? -1 : (_30030 > _12NOVALUE_20081);
    }
    else{
        _30031 = compare(_30030, _12NOVALUE_20081);
    }
    _30030 = NOVALUE;
    if (_30031 == 0)
    {
        _30031 = NOVALUE;
        goto L33; // [1789] 1946
    }
    else{
        _30031 = NOVALUE;
    }

    /** parser.e:3699					SymTab[sym][S_CODE] = valsym*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _valsym_60112;
    DeRef(_1);
    _30032 = NOVALUE;

    /** parser.e:3700					SymTab[sym][S_OBJ]  = usedval*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    Ref(_usedval_60116);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60116;
    DeRef(_1);
    _30034 = NOVALUE;

    /** parser.e:3702					if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L34; // [1828] 2079
    }
    else{
    }

    /** parser.e:3704						SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30038 = (object)*(((s1_ptr)_2)->base + _valsym_60112);
    _2 = (object)SEQ_PTR(_30038);
    _30039 = (object)*(((s1_ptr)_2)->base + 36);
    _30038 = NOVALUE;
    Ref(_30039);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30039;
    if( _1 != _30039 ){
        DeRef(_1);
    }
    _30039 = NOVALUE;
    _30036 = NOVALUE;

    /** parser.e:3705						SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30042 = (object)*(((s1_ptr)_2)->base + _valsym_60112);
    _2 = (object)SEQ_PTR(_30042);
    _30043 = (object)*(((s1_ptr)_2)->base + 33);
    _30042 = NOVALUE;
    Ref(_30043);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30043;
    if( _1 != _30043 ){
        DeRef(_1);
    }
    _30043 = NOVALUE;
    _30040 = NOVALUE;

    /** parser.e:3706						SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    Ref(_usedval_60116);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60116;
    DeRef(_1);
    _30044 = NOVALUE;

    /** parser.e:3707						SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    Ref(_usedval_60116);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60116;
    DeRef(_1);
    _30046 = NOVALUE;

    /** parser.e:3708						SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30050 = (object)*(((s1_ptr)_2)->base + _valsym_60112);
    _2 = (object)SEQ_PTR(_30050);
    _30051 = (object)*(((s1_ptr)_2)->base + 32);
    _30050 = NOVALUE;
    Ref(_30051);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30051;
    if( _1 != _30051 ){
        DeRef(_1);
    }
    _30051 = NOVALUE;
    _30048 = NOVALUE;
    goto L34; // [1943] 2079
L33: 

    /** parser.e:3711					SymTab[sym][S_OBJ] = usedval*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    Ref(_usedval_60116);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60116;
    DeRef(_1);
    _30052 = NOVALUE;

    /** parser.e:3712					if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L35; // [1967] 2078
    }
    else{
    }

    /** parser.e:3714						if is_integer( usedval ) then*/
    Ref(_usedval_60116);
    _30054 = _12is_integer(_usedval_60116);
    if (_30054 == 0) {
        DeRef(_30054);
        _30054 = NOVALUE;
        goto L36; // [1976] 1999
    }
    else {
        if (!IS_ATOM_INT(_30054) && DBL_PTR(_30054)->dbl == 0.0){
            DeRef(_30054);
            _30054 = NOVALUE;
            goto L36; // [1976] 1999
        }
        DeRef(_30054);
        _30054 = NOVALUE;
    }
    DeRef(_30054);
    _30054 = NOVALUE;

    /** parser.e:3715							SymTab[sym][S_GTYPE] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _30055 = NOVALUE;
    goto L37; // [1996] 2017
L36: 

    /** parser.e:3717							SymTab[sym][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _30057 = NOVALUE;
L37: 

    /** parser.e:3719						SymTab[sym][S_SEQ_ELEM] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30059 = NOVALUE;

    /** parser.e:3720						SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    Ref(_usedval_60116);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60116;
    DeRef(_1);
    _30061 = NOVALUE;

    /** parser.e:3721						SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    Ref(_usedval_60116);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60116;
    DeRef(_1);
    _30063 = NOVALUE;

    /** parser.e:3722						SymTab[sym][S_SEQ_LEN] = 0 --SymTab[valsym][S_SEQ_LEN]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30065 = NOVALUE;
L35: 
L34: 

    /** parser.e:3725				valsym = Pop()*/
    _valsym_60112 = _45Pop();
    if (!IS_ATOM_INT(_valsym_60112)) {
        _1 = (object)(DBL_PTR(_valsym_60112)->dbl);
        DeRefDS(_valsym_60112);
        _valsym_60112 = _1;
    }

    /** parser.e:3726				valsym = Pop()*/
    _valsym_60112 = _45Pop();
    if (!IS_ATOM_INT(_valsym_60112)) {
        _1 = (object)(DBL_PTR(_valsym_60112)->dbl);
        DeRefDS(_valsym_60112);
        _valsym_60112 = _1;
    }
    goto L18; // [2093] 2269
L1C: 

    /** parser.e:3729				SymTab[sym][S_MODE] = M_NORMAL*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _30069 = NOVALUE;

    /** parser.e:3730				if type_ptr > 0 and SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _30071 = (_type_ptr_60103 > 0);
    if (_30071 == 0) {
        goto L38; // [2119] 2165
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30073 = (object)*(((s1_ptr)_2)->base + _type_ptr_60103);
    _2 = (object)SEQ_PTR(_30073);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _30074 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _30074 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _30073 = NOVALUE;
    if (IS_ATOM_INT(_30074)) {
        _30075 = (_30074 == 415);
    }
    else {
        _30075 = binary_op(EQUALS, _30074, 415);
    }
    _30074 = NOVALUE;
    if (_30075 == 0) {
        DeRef(_30075);
        _30075 = NOVALUE;
        goto L38; // [2142] 2165
    }
    else {
        if (!IS_ATOM_INT(_30075) && DBL_PTR(_30075)->dbl == 0.0){
            DeRef(_30075);
            _30075 = NOVALUE;
            goto L38; // [2142] 2165
        }
        DeRef(_30075);
        _30075 = NOVALUE;
    }
    DeRef(_30075);
    _30075 = NOVALUE;

    /** parser.e:3731					SymTab[sym][S_VTYPE] = object_type*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53object_type_46803;
    DeRef(_1);
    _30076 = NOVALUE;
    goto L39; // [2162] 2194
L38: 

    /** parser.e:3733					SymTab[sym][S_VTYPE] = type_ptr*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_ptr_60103;
    DeRef(_1);
    _30078 = NOVALUE;

    /** parser.e:3734					if type_ptr < 0 then*/
    if (_type_ptr_60103 >= 0)
    goto L3A; // [2182] 2193

    /** parser.e:3735						register_forward_type( sym, type_ptr )*/
    _42register_forward_type(_sym_60111, _type_ptr_60103);
L3A: 
L39: 

    /** parser.e:3739				if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L3B; // [2198] 2221
    }
    else{
    }

    /** parser.e:3740					SymTab[sym][S_GTYPE] = CompileType(type_ptr)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60111 + ((s1_ptr)_2)->base);
    _30083 = _43CompileType(_type_ptr_60103);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30083;
    if( _1 != _30083 ){
        DeRef(_1);
    }
    _30083 = NOVALUE;
    _30081 = NOVALUE;
L3B: 

    /** parser.e:3743		   		tok = next_token()*/
    _0 = _tok_60107;
    _tok_60107 = _43next_token();
    DeRef(_0);

    /** parser.e:3744	   			putback(tok)*/
    Ref(_tok_60107);
    _43putback(_tok_60107);

    /** parser.e:3745		   		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (object)SEQ_PTR(_tok_60107);
    _30085 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30085, 3)){
        _30085 = NOVALUE;
        goto L3C; // [2241] 2268
    }
    _30085 = NOVALUE;

    /** parser.e:3746		   			StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _45StartSourceLine(_9FALSE_444, 0, 3);

    /** parser.e:3747		   			Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _sym_60111;
    _30087 = MAKE_SEQ(_1);
    _43Assignment(_30087);
    _30087 = NOVALUE;
L3C: 
L18: 

    /** parser.e:3750			tok = next_token()*/
    _0 = _tok_60107;
    _tok_60107 = _43next_token();
    DeRef(_0);

    /** parser.e:3751			if tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_60107);
    _30089 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30089, -30)){
        _30089 = NOVALUE;
        goto L3D; // [2284] 2293
    }
    _30089 = NOVALUE;

    /** parser.e:3752				exit*/
    goto LD; // [2290] 2303
L3D: 

    /** parser.e:3754			prevtok = tok*/
    Ref(_tok_60107);
    DeRef(_prevtok_60109);
    _prevtok_60109 = _tok_60107;

    /** parser.e:3755		end while*/
    goto LC; // [2300] 440
LD: 

    /** parser.e:3756		putback(tok)*/
    Ref(_tok_60107);
    _43putback(_tok_60107);

    /** parser.e:3757		return new_symbols*/
    DeRef(_tok_60107);
    DeRef(_tsym_60108);
    DeRef(_prevtok_60109);
    DeRef(_val_60115);
    DeRef(_usedval_60116);
    DeRef(_delta_60118);
    DeRef(_30000);
    _30000 = NOVALUE;
    _29932 = NOVALUE;
    DeRef(_29850);
    _29850 = NOVALUE;
    DeRef(_29940);
    _29940 = NOVALUE;
    _29877 = NOVALUE;
    DeRef(_29915);
    _29915 = NOVALUE;
    DeRef(_29958);
    _29958 = NOVALUE;
    DeRef(_30071);
    _30071 = NOVALUE;
    DeRef(_29949);
    _29949 = NOVALUE;
    _30020 = NOVALUE;
    _29928 = NOVALUE;
    _29979 = NOVALUE;
    _29964 = NOVALUE;
    DeRef(_29984);
    _29984 = NOVALUE;
    return _new_symbols_60105;
    ;
}


void _43Private_declaration(object _type_sym_60692)
{
    object _tok_60694 = NOVALUE;
    object _sym_60696 = NOVALUE;
    object _31704 = NOVALUE;
    object _31703 = NOVALUE;
    object _31702 = NOVALUE;
    object _30115 = NOVALUE;
    object _30113 = NOVALUE;
    object _30111 = NOVALUE;
    object _30109 = NOVALUE;
    object _30107 = NOVALUE;
    object _30105 = NOVALUE;
    object _30103 = NOVALUE;
    object _30100 = NOVALUE;
    object _30098 = NOVALUE;
    object _30097 = NOVALUE;
    object _30094 = NOVALUE;
    object _30092 = NOVALUE;
    object _30091 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_sym_60692)) {
        _1 = (object)(DBL_PTR(_type_sym_60692)->dbl);
        DeRefDS(_type_sym_60692);
        _type_sym_60692 = _1;
    }

    /** parser.e:3765		if SymTab[type_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30091 = (object)*(((s1_ptr)_2)->base + _type_sym_60692);
    _2 = (object)SEQ_PTR(_30091);
    _30092 = (object)*(((s1_ptr)_2)->base + 4);
    _30091 = NOVALUE;
    if (binary_op_a(NOTEQ, _30092, 9)){
        _30092 = NOVALUE;
        goto L1; // [19] 47
    }
    _30092 = NOVALUE;

    /** parser.e:3766			Hide( type_sym )*/
    _53Hide(_type_sym_60692);

    /** parser.e:3767			type_sym = -new_forward_reference( TYPE, type_sym )*/
    _31704 = 504;
    _30094 = _42new_forward_reference(504, _type_sym_60692, 504);
    _31704 = NOVALUE;
    if (IS_ATOM_INT(_30094)) {
        if ((uintptr_t)_30094 == (uintptr_t)HIGH_BITS){
            _type_sym_60692 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _type_sym_60692 = - _30094;
        }
    }
    else {
        _type_sym_60692 = unary_op(UMINUS, _30094);
    }
    DeRef(_30094);
    _30094 = NOVALUE;
    if (!IS_ATOM_INT(_type_sym_60692)) {
        _1 = (object)(DBL_PTR(_type_sym_60692)->dbl);
        DeRefDS(_type_sym_60692);
        _type_sym_60692 = _1;
    }
L1: 

    /** parser.e:3770		while TRUE do*/
L2: 
    if (_9TRUE_446 == 0)
    {
        goto L3; // [54] 257
    }
    else{
    }

    /** parser.e:3771			tok = next_token()*/
    _0 = _tok_60694;
    _tok_60694 = _43next_token();
    DeRef(_0);

    /** parser.e:3772			if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_60694);
    _30097 = (object)*(((s1_ptr)_2)->base + 1);
    _30098 = find_from(_30097, _29ID_TOKS_12012, 1);
    _30097 = NOVALUE;
    if (_30098 != 0)
    goto L4; // [77] 90
    _30098 = NOVALUE;

    /** parser.e:3773				CompileErr(A_VARIABLE_NAME_IS_EXPECTED_HERE)*/
    RefDS(_22015);
    _49CompileErr(24, _22015, 0);
L4: 

    /** parser.e:3775			sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (object)SEQ_PTR(_tok_60694);
    _30100 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30100);
    _sym_60696 = _43SetPrivateScope(_30100, _type_sym_60692, _43param_num_54961);
    _30100 = NOVALUE;
    if (!IS_ATOM_INT(_sym_60696)) {
        _1 = (object)(DBL_PTR(_sym_60696)->dbl);
        DeRefDS(_sym_60696);
        _sym_60696 = _1;
    }

    /** parser.e:3776			param_num += 1*/
    _43param_num_54961 = _43param_num_54961 + 1;

    /** parser.e:3778			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L5; // [120] 143
    }
    else{
    }

    /** parser.e:3779				SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60696 + ((s1_ptr)_2)->base);
    _30105 = _43CompileType(_type_sym_60692);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30105;
    if( _1 != _30105 ){
        DeRef(_1);
    }
    _30105 = NOVALUE;
    _30103 = NOVALUE;
L5: 

    /** parser.e:3782	   		tok = next_token()*/
    _0 = _tok_60694;
    _tok_60694 = _43next_token();
    DeRef(_0);

    /** parser.e:3783	   		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (object)SEQ_PTR(_tok_60694);
    _30107 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30107, 3)){
        _30107 = NOVALUE;
        goto L6; // [158] 233
    }
    _30107 = NOVALUE;

    /** parser.e:3784			    putback(tok)*/
    Ref(_tok_60694);
    _43putback(_tok_60694);

    /** parser.e:3785			    StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:3797			    Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _sym_60696;
    _30109 = MAKE_SEQ(_1);
    _43Assignment(_30109);
    _30109 = NOVALUE;

    /** parser.e:3800				tok = next_token()*/
    _0 = _tok_60694;
    _tok_60694 = _43next_token();
    DeRef(_0);

    /** parser.e:3801				if tok[T_ID]=IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_60694);
    _30111 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30111, 509)){
        _30111 = NOVALUE;
        goto L7; // [202] 232
    }
    _30111 = NOVALUE;

    /** parser.e:3802					tok = keyfind(tok[T_SYM],-1)*/
    _2 = (object)SEQ_PTR(_tok_60694);
    _30113 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30113);
    DeRef(_31702);
    _31702 = _30113;
    _31703 = _53hashfn(_31702);
    _31702 = NOVALUE;
    Ref(_30113);
    _0 = _tok_60694;
    _tok_60694 = _53keyfind(_30113, -1, _12current_file_no_20226, 0, _31703);
    DeRef(_0);
    _30113 = NOVALUE;
    _31703 = NOVALUE;
L7: 
L6: 

    /** parser.e:3806			if tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_60694);
    _30115 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30115, -30)){
        _30115 = NOVALUE;
        goto L2; // [243] 52
    }
    _30115 = NOVALUE;

    /** parser.e:3807				exit*/
    goto L3; // [249] 257

    /** parser.e:3809		end while*/
    goto L2; // [254] 52
L3: 

    /** parser.e:3810		putback(tok)*/
    Ref(_tok_60694);
    _43putback(_tok_60694);

    /** parser.e:3811	end procedure*/
    DeRef(_tok_60694);
    return;
    ;
}


void _43Procedure_call(object _tok_60759)
{
    object _n_60760 = NOVALUE;
    object _scope_60761 = NOVALUE;
    object _opcode_60762 = NOVALUE;
    object _temp_tok_60764 = NOVALUE;
    object _s_60766 = NOVALUE;
    object _sub_60767 = NOVALUE;
    object _30151 = NOVALUE;
    object _30146 = NOVALUE;
    object _30145 = NOVALUE;
    object _30144 = NOVALUE;
    object _30143 = NOVALUE;
    object _30142 = NOVALUE;
    object _30141 = NOVALUE;
    object _30140 = NOVALUE;
    object _30139 = NOVALUE;
    object _30138 = NOVALUE;
    object _30137 = NOVALUE;
    object _30136 = NOVALUE;
    object _30134 = NOVALUE;
    object _30133 = NOVALUE;
    object _30132 = NOVALUE;
    object _30131 = NOVALUE;
    object _30130 = NOVALUE;
    object _30129 = NOVALUE;
    object _30128 = NOVALUE;
    object _30126 = NOVALUE;
    object _30125 = NOVALUE;
    object _30124 = NOVALUE;
    object _30122 = NOVALUE;
    object _30120 = NOVALUE;
    object _30118 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3820		tok_match(LEFT_ROUND)*/
    _43tok_match(-26, 0);

    /** parser.e:3821		s = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60759);
    _s_60766 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_60766)){
        _s_60766 = (object)DBL_PTR(_s_60766)->dbl;
    }

    /** parser.e:3822		sub=s*/
    _sub_60767 = _s_60766;

    /** parser.e:3823		n = SymTab[s][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30118 = (object)*(((s1_ptr)_2)->base + _s_60766);
    _2 = (object)SEQ_PTR(_30118);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _n_60760 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _n_60760 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    if (!IS_ATOM_INT(_n_60760)){
        _n_60760 = (object)DBL_PTR(_n_60760)->dbl;
    }
    _30118 = NOVALUE;

    /** parser.e:3824		scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30120 = (object)*(((s1_ptr)_2)->base + _s_60766);
    _2 = (object)SEQ_PTR(_30120);
    _scope_60761 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_60761)){
        _scope_60761 = (object)DBL_PTR(_scope_60761)->dbl;
    }
    _30120 = NOVALUE;

    /** parser.e:3825		opcode = SymTab[s][S_OPCODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30122 = (object)*(((s1_ptr)_2)->base + _s_60766);
    _2 = (object)SEQ_PTR(_30122);
    _opcode_60762 = (object)*(((s1_ptr)_2)->base + 21);
    if (!IS_ATOM_INT(_opcode_60762)){
        _opcode_60762 = (object)DBL_PTR(_opcode_60762)->dbl;
    }
    _30122 = NOVALUE;

    /** parser.e:3826		if SymTab[s][S_EFFECT] then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30124 = (object)*(((s1_ptr)_2)->base + _s_60766);
    _2 = (object)SEQ_PTR(_30124);
    _30125 = (object)*(((s1_ptr)_2)->base + 23);
    _30124 = NOVALUE;
    if (_30125 == 0) {
        _30125 = NOVALUE;
        goto L1; // [88] 139
    }
    else {
        if (!IS_ATOM_INT(_30125) && DBL_PTR(_30125)->dbl == 0.0){
            _30125 = NOVALUE;
            goto L1; // [88] 139
        }
        _30125 = NOVALUE;
    }
    _30125 = NOVALUE;

    /** parser.e:3827			SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30128 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_30128);
    _30129 = (object)*(((s1_ptr)_2)->base + 23);
    _30128 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30130 = (object)*(((s1_ptr)_2)->base + _s_60766);
    _2 = (object)SEQ_PTR(_30130);
    _30131 = (object)*(((s1_ptr)_2)->base + 23);
    _30130 = NOVALUE;
    if (IS_ATOM_INT(_30129) && IS_ATOM_INT(_30131)) {
        {uintptr_t tu;
             tu = (uintptr_t)_30129 | (uintptr_t)_30131;
             _30132 = MAKE_UINT(tu);
        }
    }
    else {
        _30132 = binary_op(OR_BITS, _30129, _30131);
    }
    _30129 = NOVALUE;
    _30131 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30132;
    if( _1 != _30132 ){
        DeRef(_1);
    }
    _30132 = NOVALUE;
    _30126 = NOVALUE;
L1: 

    /** parser.e:3830		ParseArgs(s)*/
    _43ParseArgs(_s_60766);

    /** parser.e:3833		for i=1 to n+1 do*/
    _30133 = _n_60760 + 1;
    if (_30133 > MAXINT){
        _30133 = NewDouble((eudouble)_30133);
    }
    {
        object _i_60804;
        _i_60804 = 1;
L2: 
        if (binary_op_a(GREATER, _i_60804, _30133)){
            goto L3; // [150] 180
        }

        /** parser.e:3834			s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _30134 = (object)*(((s1_ptr)_2)->base + _s_60766);
        _2 = (object)SEQ_PTR(_30134);
        _s_60766 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_60766)){
            _s_60766 = (object)DBL_PTR(_s_60766)->dbl;
        }
        _30134 = NOVALUE;

        /** parser.e:3835		end for*/
        _0 = _i_60804;
        if (IS_ATOM_INT(_i_60804)) {
            _i_60804 = _i_60804 + 1;
            if ((object)((uintptr_t)_i_60804 +(uintptr_t) HIGH_BITS) >= 0){
                _i_60804 = NewDouble((eudouble)_i_60804);
            }
        }
        else {
            _i_60804 = binary_op_a(PLUS, _i_60804, 1);
        }
        DeRef(_0);
        goto L2; // [175] 157
L3: 
        ;
        DeRef(_i_60804);
    }

    /** parser.e:3836		while s and SymTab[s][S_SCOPE]=SC_PRIVATE do*/
L4: 
    if (_s_60766 == 0) {
        goto L5; // [185] 281
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30137 = (object)*(((s1_ptr)_2)->base + _s_60766);
    _2 = (object)SEQ_PTR(_30137);
    _30138 = (object)*(((s1_ptr)_2)->base + 4);
    _30137 = NOVALUE;
    if (IS_ATOM_INT(_30138)) {
        _30139 = (_30138 == 3);
    }
    else {
        _30139 = binary_op(EQUALS, _30138, 3);
    }
    _30138 = NOVALUE;
    if (_30139 <= 0) {
        if (_30139 == 0) {
            DeRef(_30139);
            _30139 = NOVALUE;
            goto L5; // [208] 281
        }
        else {
            if (!IS_ATOM_INT(_30139) && DBL_PTR(_30139)->dbl == 0.0){
                DeRef(_30139);
                _30139 = NOVALUE;
                goto L5; // [208] 281
            }
            DeRef(_30139);
            _30139 = NOVALUE;
        }
    }
    DeRef(_30139);
    _30139 = NOVALUE;

    /** parser.e:3837			if sequence(SymTab[s][S_CODE]) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30140 = (object)*(((s1_ptr)_2)->base + _s_60766);
    _2 = (object)SEQ_PTR(_30140);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _30141 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _30141 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    _30140 = NOVALUE;
    _30142 = IS_SEQUENCE(_30141);
    _30141 = NOVALUE;
    if (_30142 == 0)
    {
        _30142 = NOVALUE;
        goto L6; // [228] 260
    }
    else{
        _30142 = NOVALUE;
    }

    /** parser.e:3838				start_playback(SymTab[s][S_CODE])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30143 = (object)*(((s1_ptr)_2)->base + _s_60766);
    _2 = (object)SEQ_PTR(_30143);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _30144 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _30144 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    _30143 = NOVALUE;
    Ref(_30144);
    _43start_playback(_30144);
    _30144 = NOVALUE;

    /** parser.e:3839				Assignment({VARIABLE,s})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _s_60766;
    _30145 = MAKE_SEQ(_1);
    _43Assignment(_30145);
    _30145 = NOVALUE;
L6: 

    /** parser.e:3841			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30146 = (object)*(((s1_ptr)_2)->base + _s_60766);
    _2 = (object)SEQ_PTR(_30146);
    _s_60766 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_60766)){
        _s_60766 = (object)DBL_PTR(_s_60766)->dbl;
    }
    _30146 = NOVALUE;

    /** parser.e:3842		end while*/
    goto L4; // [278] 185
L5: 

    /** parser.e:3844		s = sub*/
    _s_60766 = _sub_60767;

    /** parser.e:3845		if scope = SC_PREDEF then*/
    if (_scope_60761 != 7)
    goto L7; // [292] 335

    /** parser.e:3846			emit_op(opcode)*/
    _45emit_op(_opcode_60762);

    /** parser.e:3847			if opcode = ABORT then*/
    if (_opcode_60762 != 126)
    goto L8; // [305] 370

    /** parser.e:3848				temp_tok = next_token()*/
    _0 = _temp_tok_60764;
    _temp_tok_60764 = _43next_token();
    DeRef(_0);

    /** parser.e:3849				putback(temp_tok)*/
    Ref(_temp_tok_60764);
    _43putback(_temp_tok_60764);

    /** parser.e:3850				NotReached(temp_tok[T_ID], "abort()")*/
    _2 = (object)SEQ_PTR(_temp_tok_60764);
    _30151 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30151);
    RefDS(_27887);
    _43NotReached(_30151, _27887);
    _30151 = NOVALUE;
    goto L8; // [332] 370
L7: 

    /** parser.e:3853			op_info1 = s*/
    _45op_info1_50960 = _s_60766;

    /** parser.e:3855			emit_or_inline()*/
    _66emit_or_inline();

    /** parser.e:3856			if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto L9; // [350] 369

    /** parser.e:3857				if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto LA; // [357] 368
    }
    else{
    }

    /** parser.e:3858					emit_op(UPDATE_GLOBALS)*/
    _45emit_op(89);
LA: 
L9: 
L8: 

    /** parser.e:3862	end procedure*/
    DeRef(_tok_60759);
    DeRef(_temp_tok_60764);
    DeRef(_30133);
    _30133 = NOVALUE;
    return;
    ;
}


void _43Print_statement()
{
    object _30158 = NOVALUE;
    object _30157 = NOVALUE;
    object _30156 = NOVALUE;
    object _30154 = NOVALUE;
    object _30153 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3866		emit_opnd(NewIntSym(1)) -- stdout*/
    _30153 = _53NewIntSym(1);
    _45emit_opnd(_30153);
    _30153 = NOVALUE;

    /** parser.e:3867		Expr()*/
    _43Expr();

    /** parser.e:3868		emit_op(QPRINT)*/
    _45emit_op(36);

    /** parser.e:3869		SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30156 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_30156);
    _30157 = (object)*(((s1_ptr)_2)->base + 23);
    _30156 = NOVALUE;
    if (IS_ATOM_INT(_30157)) {
        {uintptr_t tu;
             tu = (uintptr_t)_30157 | (uintptr_t)536870912;
             _30158 = MAKE_UINT(tu);
        }
    }
    else {
        _30158 = binary_op(OR_BITS, _30157, 536870912);
    }
    _30157 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30158;
    if( _1 != _30158 ){
        DeRef(_1);
    }
    _30158 = NOVALUE;
    _30154 = NOVALUE;

    /** parser.e:3871	end procedure*/
    return;
    ;
}


void _43Entry_statement()
{
    object _addr_60875 = NOVALUE;
    object _30182 = NOVALUE;
    object _30181 = NOVALUE;
    object _30180 = NOVALUE;
    object _30179 = NOVALUE;
    object _30178 = NOVALUE;
    object _30177 = NOVALUE;
    object _30176 = NOVALUE;
    object _30175 = NOVALUE;
    object _30171 = NOVALUE;
    object _30169 = NOVALUE;
    object _30168 = NOVALUE;
    object _30167 = NOVALUE;
    object _30166 = NOVALUE;
    object _30164 = NOVALUE;
    object _30163 = NOVALUE;
    object _30162 = NOVALUE;
    object _30160 = NOVALUE;
    object _30159 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3878		if not length(loop_stack) or block_index=0 then*/
    if (IS_SEQUENCE(_43loop_stack_54986)){
            _30159 = SEQ_PTR(_43loop_stack_54986)->length;
    }
    else {
        _30159 = 1;
    }
    _30160 = (_30159 == 0);
    _30159 = NOVALUE;
    if (_30160 != 0) {
        goto L1; // [11] 26
    }
    _30162 = (_43block_index_54983 == 0);
    if (_30162 == 0)
    {
        DeRef(_30162);
        _30162 = NOVALUE;
        goto L2; // [22] 36
    }
    else{
        DeRef(_30162);
        _30162 = NOVALUE;
    }
L1: 

    /** parser.e:3879			CompileErr(THE_ENTRY_STATEMENT_MUST_APPEAR_INSIDE_A_LOOP)*/
    RefDS(_22015);
    _49CompileErr(144, _22015, 0);
L2: 

    /** parser.e:3881		if block_list[block_index]=IF or block_list[block_index]=SWITCH then*/
    _2 = (object)SEQ_PTR(_43block_list_54982);
    _30163 = (object)*(((s1_ptr)_2)->base + _43block_index_54983);
    _30164 = (_30163 == 20);
    _30163 = NOVALUE;
    if (_30164 != 0) {
        goto L3; // [52] 75
    }
    _2 = (object)SEQ_PTR(_43block_list_54982);
    _30166 = (object)*(((s1_ptr)_2)->base + _43block_index_54983);
    _30167 = (_30166 == 185);
    _30166 = NOVALUE;
    if (_30167 == 0)
    {
        DeRef(_30167);
        _30167 = NOVALUE;
        goto L4; // [71] 87
    }
    else{
        DeRef(_30167);
        _30167 = NOVALUE;
    }
L3: 

    /** parser.e:3882			CompileErr(THE_INNERMOST_BLOCK_CONTAINING_AN_ENTRY_STATEMENT_MUST_BE_THE_LOOP_IT_DEFINES_AN_ENTRY_IN)*/
    RefDS(_22015);
    _49CompileErr(143, _22015, 0);
    goto L5; // [84] 115
L4: 

    /** parser.e:3883		elsif loop_stack[$] = FOR then  -- not allowed in an innermost for loop*/
    if (IS_SEQUENCE(_43loop_stack_54986)){
            _30168 = SEQ_PTR(_43loop_stack_54986)->length;
    }
    else {
        _30168 = 1;
    }
    _2 = (object)SEQ_PTR(_43loop_stack_54986);
    _30169 = (object)*(((s1_ptr)_2)->base + _30168);
    if (_30169 != 21)
    goto L6; // [100] 114

    /** parser.e:3884			CompileErr(THE_ENTRY_STATEMENT_CAN_NOT_BE_USED_IN_A_FOR_BLOCK)*/
    RefDS(_22015);
    _49CompileErr(142, _22015, 0);
L6: 
L5: 

    /** parser.e:3886		addr = entry_addr[$]*/
    if (IS_SEQUENCE(_43entry_addr_54976)){
            _30171 = SEQ_PTR(_43entry_addr_54976)->length;
    }
    else {
        _30171 = 1;
    }
    _2 = (object)SEQ_PTR(_43entry_addr_54976);
    _addr_60875 = (object)*(((s1_ptr)_2)->base + _30171);

    /** parser.e:3887		if addr=0  then*/
    if (_addr_60875 != 0)
    goto L7; // [128] 144

    /** parser.e:3888			CompileErr(THE_ENTRY_STATEMENT_MUST_APPEAR_AT_MOST_ONCE_INSIDE_A_LOOP)*/
    RefDS(_22015);
    _49CompileErr(141, _22015, 0);
    goto L8; // [141] 161
L7: 

    /** parser.e:3889		elsif addr<0 then*/
    if (_addr_60875 >= 0)
    goto L9; // [146] 160

    /** parser.e:3890			CompileErr(ENTRY_STATEMENT_IS_BEING_USED_WITHOUT_A_CORRESPONDING_ENTRY_CLAUSE_IN_THE_LOOP_HEADER)*/
    RefDS(_22015);
    _49CompileErr(73, _22015, 0);
L9: 
L8: 

    /** parser.e:3892		backpatch(addr,ELSE)*/
    _45backpatch(_addr_60875, 23);

    /** parser.e:3893		backpatch(addr+1,length(Code)+1+(TRANSLATE>0))*/
    _30175 = _addr_60875 + 1;
    if (_30175 > MAXINT){
        _30175 = NewDouble((eudouble)_30175);
    }
    if (IS_SEQUENCE(_12Code_20315)){
            _30176 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _30176 = 1;
    }
    _30177 = _30176 + 1;
    _30176 = NOVALUE;
    _30178 = (_12TRANSLATE_19834 > 0);
    _30179 = _30177 + _30178;
    _30177 = NOVALUE;
    _30178 = NOVALUE;
    _45backpatch(_30175, _30179);
    _30175 = NOVALUE;
    _30179 = NOVALUE;

    /** parser.e:3894		entry_addr[$] = 0*/
    if (IS_SEQUENCE(_43entry_addr_54976)){
            _30180 = SEQ_PTR(_43entry_addr_54976)->length;
    }
    else {
        _30180 = 1;
    }
    _2 = (object)SEQ_PTR(_43entry_addr_54976);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43entry_addr_54976 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _30180);
    *(intptr_t *)_2 = 0;

    /** parser.e:3895		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto LA; // [213] 224
    }
    else{
    }

    /** parser.e:3896		    emit_op(NOP1)*/
    _45emit_op(159);
LA: 

    /** parser.e:3899		force_uninitialize( entry_stack[$] )*/
    if (IS_SEQUENCE(_43entry_stack_54979)){
            _30181 = SEQ_PTR(_43entry_stack_54979)->length;
    }
    else {
        _30181 = 1;
    }
    _2 = (object)SEQ_PTR(_43entry_stack_54979);
    _30182 = (object)*(((s1_ptr)_2)->base + _30181);
    Ref(_30182);
    _43force_uninitialize(_30182);
    _30182 = NOVALUE;

    /** parser.e:3901	end procedure*/
    DeRef(_30164);
    _30164 = NOVALUE;
    _30169 = NOVALUE;
    DeRef(_30160);
    _30160 = NOVALUE;
    return;
    ;
}


void _43force_uninitialize(object _uninitialized_60930)
{
    object _30185 = NOVALUE;
    object _30184 = NOVALUE;
    object _30183 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3907		for i = 1 to length( uninitialized ) do*/
    if (IS_SEQUENCE(_uninitialized_60930)){
            _30183 = SEQ_PTR(_uninitialized_60930)->length;
    }
    else {
        _30183 = 1;
    }
    {
        object _i_60932;
        _i_60932 = 1;
L1: 
        if (_i_60932 > _30183){
            goto L2; // [8] 41
        }

        /** parser.e:3908			SymTab[uninitialized[i]][S_INITLEVEL] = -1*/
        _2 = (object)SEQ_PTR(_uninitialized_60930);
        _30184 = (object)*(((s1_ptr)_2)->base + _i_60932);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_30184))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30184)->dbl));
        else
        _3 = (object)(_30184 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 14);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = -1;
        DeRef(_1);
        _30185 = NOVALUE;

        /** parser.e:3909		end for*/
        _i_60932 = _i_60932 + 1;
        goto L1; // [36] 15
L2: 
        ;
    }

    /** parser.e:3910	end procedure*/
    DeRefDS(_uninitialized_60930);
    _30184 = NOVALUE;
    return;
    ;
}


void _43Statement_list()
{
    object _tok_60942 = NOVALUE;
    object _id_60943 = NOVALUE;
    object _forward_60966 = NOVALUE;
    object _test_61115 = NOVALUE;
    object _30258 = NOVALUE;
    object _30257 = NOVALUE;
    object _30254 = NOVALUE;
    object _30252 = NOVALUE;
    object _30251 = NOVALUE;
    object _30248 = NOVALUE;
    object _30245 = NOVALUE;
    object _30244 = NOVALUE;
    object _30243 = NOVALUE;
    object _30240 = NOVALUE;
    object _30238 = NOVALUE;
    object _30236 = NOVALUE;
    object _30234 = NOVALUE;
    object _30216 = NOVALUE;
    object _30215 = NOVALUE;
    object _30213 = NOVALUE;
    object _30211 = NOVALUE;
    object _30210 = NOVALUE;
    object _30208 = NOVALUE;
    object _30206 = NOVALUE;
    object _30205 = NOVALUE;
    object _30204 = NOVALUE;
    object _30203 = NOVALUE;
    object _30198 = NOVALUE;
    object _30195 = NOVALUE;
    object _30194 = NOVALUE;
    object _30193 = NOVALUE;
    object _30192 = NOVALUE;
    object _30190 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3915		integer id*/

    /** parser.e:3917		stmt_nest += 1*/
    _43stmt_nest_54984 = _43stmt_nest_54984 + 1;

    /** parser.e:3918		while TRUE do*/
L1: 
    if (_9TRUE_446 == 0)
    {
        goto L2; // [18] 1125
    }
    else{
    }

    /** parser.e:3919			tok = next_token()*/
    _0 = _tok_60942;
    _tok_60942 = _43next_token();
    DeRef(_0);

    /** parser.e:3920			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_60942);
    _id_60943 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_60943)){
        _id_60943 = (object)DBL_PTR(_id_60943)->dbl;
    }

    /** parser.e:3921			if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _30190 = (_id_60943 == -100);
    if (_30190 != 0) {
        goto L3; // [44] 59
    }
    _30192 = (_id_60943 == 512);
    if (_30192 == 0)
    {
        DeRef(_30192);
        _30192 = NOVALUE;
        goto L4; // [55] 229
    }
    else{
        DeRef(_30192);
        _30192 = NOVALUE;
    }
L3: 

    /** parser.e:3922				if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok_60942);
    _30193 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30193)){
        _30194 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30193)->dbl));
    }
    else{
        _30194 = (object)*(((s1_ptr)_2)->base + _30193);
    }
    _2 = (object)SEQ_PTR(_30194);
    _30195 = (object)*(((s1_ptr)_2)->base + 4);
    _30194 = NOVALUE;
    if (binary_op_a(NOTEQ, _30195, 9)){
        _30195 = NOVALUE;
        goto L5; // [81] 210
    }
    _30195 = NOVALUE;

    /** parser.e:3923					token forward = next_token()*/
    _0 = _forward_60966;
    _forward_60966 = _43next_token();
    DeRef(_0);

    /** parser.e:3924					switch forward[T_ID] do*/
    _2 = (object)SEQ_PTR(_forward_60966);
    _30198 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_30198) ){
        goto L6; // [98] 204
    }
    if(!IS_ATOM_INT(_30198)){
        if( (DBL_PTR(_30198)->dbl != (eudouble) ((object) DBL_PTR(_30198)->dbl) ) ){
            goto L6; // [98] 204
        }
        _0 = (object) DBL_PTR(_30198)->dbl;
    }
    else {
        _0 = _30198;
    };
    _30198 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:3925						case LEFT_ROUND then*/
        case -26:

        /** parser.e:3926							StartSourceLine( TRUE )*/
        _45StartSourceLine(_9TRUE_446, 0, 2);

        /** parser.e:3928							Forward_call( tok )*/
        Ref(_tok_60942);
        _43Forward_call(_tok_60942, 195);

        /** parser.e:3929							flush_temps()*/
        RefDS(_22015);
        _45flush_temps(_22015);

        /** parser.e:3930							continue*/
        DeRef(_forward_60966);
        _forward_60966 = NOVALUE;
        goto L1; // [133] 16
        goto L6; // [135] 204

        /** parser.e:3932						case VARIABLE then*/
        case -100:

        /** parser.e:3933							putback( forward )*/
        Ref(_forward_60966);
        _43putback(_forward_60966);

        /** parser.e:3934							if param_num != -1 then*/
        if (_43param_num_54961 == -1)
        goto L7; // [150] 176

        /** parser.e:3936								param_num += 1*/
        _43param_num_54961 = _43param_num_54961 + 1;

        /** parser.e:3937								Private_declaration( tok[T_SYM] )*/
        _2 = (object)SEQ_PTR(_tok_60942);
        _30203 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_30203);
        _43Private_declaration(_30203);
        _30203 = NOVALUE;
        goto L8; // [173] 192
L7: 

        /** parser.e:3939								Global_declaration( tok[T_SYM], SC_LOCAL )*/
        _2 = (object)SEQ_PTR(_tok_60942);
        _30204 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_30204);
        _30205 = _43Global_declaration(_30204, 5);
        _30204 = NOVALUE;
L8: 

        /** parser.e:3941							flush_temps()*/
        RefDS(_22015);
        _45flush_temps(_22015);

        /** parser.e:3942							continue*/
        DeRef(_forward_60966);
        _forward_60966 = NOVALUE;
        goto L1; // [201] 16
    ;}L6: 

    /** parser.e:3945					putback( forward )*/
    Ref(_forward_60966);
    _43putback(_forward_60966);
L5: 
    DeRef(_forward_60966);
    _forward_60966 = NOVALUE;

    /** parser.e:3947				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:3948				Assignment(tok)*/
    Ref(_tok_60942);
    _43Assignment(_tok_60942);
    goto L9; // [226] 1115
L4: 

    /** parser.e:3950			elsif id = PROC or id = QUALIFIED_PROC then*/
    _30206 = (_id_60943 == 27);
    if (_30206 != 0) {
        goto LA; // [237] 252
    }
    _30208 = (_id_60943 == 521);
    if (_30208 == 0)
    {
        DeRef(_30208);
        _30208 = NOVALUE;
        goto LB; // [248] 289
    }
    else{
        DeRef(_30208);
        _30208 = NOVALUE;
    }
LA: 

    /** parser.e:3951				if id = PROC then*/
    if (_id_60943 != 27)
    goto LC; // [256] 272

    /** parser.e:3953					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_60942);
    _30210 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30210);
    _43UndefinedVar(_30210);
    _30210 = NOVALUE;
LC: 

    /** parser.e:3955				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:3956				Procedure_call(tok)*/
    Ref(_tok_60942);
    _43Procedure_call(_tok_60942);
    goto L9; // [286] 1115
LB: 

    /** parser.e:3958			elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _30211 = (_id_60943 == 501);
    if (_30211 != 0) {
        goto LD; // [297] 312
    }
    _30213 = (_id_60943 == 520);
    if (_30213 == 0)
    {
        DeRef(_30213);
        _30213 = NOVALUE;
        goto LE; // [308] 362
    }
    else{
        DeRef(_30213);
        _30213 = NOVALUE;
    }
LD: 

    /** parser.e:3959				if id = FUNC then*/
    if (_id_60943 != 501)
    goto LF; // [316] 332

    /** parser.e:3961					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_60942);
    _30215 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30215);
    _43UndefinedVar(_30215);
    _30215 = NOVALUE;
LF: 

    /** parser.e:3963				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:3964				Procedure_call(tok)*/
    Ref(_tok_60942);
    _43Procedure_call(_tok_60942);

    /** parser.e:3965				clear_op()*/
    _45clear_op();

    /** parser.e:3966				if Pop() then end if*/
    _30216 = _45Pop();
    if (_30216 == 0) {
        DeRef(_30216);
        _30216 = NOVALUE;
        goto L9; // [355] 1115
    }
    else {
        if (!IS_ATOM_INT(_30216) && DBL_PTR(_30216)->dbl == 0.0){
            DeRef(_30216);
            _30216 = NOVALUE;
            goto L9; // [355] 1115
        }
        DeRef(_30216);
        _30216 = NOVALUE;
    }
    DeRef(_30216);
    _30216 = NOVALUE;
    goto L9; // [359] 1115
LE: 

    /** parser.e:3968			elsif id = IF then*/
    if (_id_60943 != 20)
    goto L10; // [366] 386

    /** parser.e:3969				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:3970				If_statement()*/
    _43If_statement();
    goto L9; // [383] 1115
L10: 

    /** parser.e:3972			elsif id = FOR then*/
    if (_id_60943 != 21)
    goto L11; // [390] 410

    /** parser.e:3973				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:3974				For_statement()*/
    _43For_statement();
    goto L9; // [407] 1115
L11: 

    /** parser.e:3976			elsif id = RETURN then*/
    if (_id_60943 != 413)
    goto L12; // [414] 434

    /** parser.e:3977				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:3978				Return_statement()*/
    _43Return_statement();
    goto L9; // [431] 1115
L12: 

    /** parser.e:3980			elsif id = LABEL then*/
    if (_id_60943 != 419)
    goto L13; // [438] 460

    /** parser.e:3981				StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _45StartSourceLine(_9TRUE_446, 0, 1);

    /** parser.e:3982				GLabel_statement()*/
    _43GLabel_statement();
    goto L9; // [457] 1115
L13: 

    /** parser.e:3984			elsif id = GOTO then*/
    if (_id_60943 != 188)
    goto L14; // [464] 484

    /** parser.e:3985				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:3986				Goto_statement()*/
    _43Goto_statement();
    goto L9; // [481] 1115
L14: 

    /** parser.e:3988			elsif id = EXIT then*/
    if (_id_60943 != 61)
    goto L15; // [488] 508

    /** parser.e:3989				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:3990				Exit_statement()*/
    _43Exit_statement();
    goto L9; // [505] 1115
L15: 

    /** parser.e:3992			elsif id = BREAK then*/
    if (_id_60943 != 425)
    goto L16; // [512] 532

    /** parser.e:3993				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:3994				Break_statement()*/
    _43Break_statement();
    goto L9; // [529] 1115
L16: 

    /** parser.e:3996			elsif id = WHILE then*/
    if (_id_60943 != 47)
    goto L17; // [536] 556

    /** parser.e:3997				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:3998				While_statement()*/
    _43While_statement();
    goto L9; // [553] 1115
L17: 

    /** parser.e:4000			elsif id = LOOP then*/
    if (_id_60943 != 422)
    goto L18; // [560] 580

    /** parser.e:4001			    StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4002		        Loop_statement()*/
    _43Loop_statement();
    goto L9; // [577] 1115
L18: 

    /** parser.e:4004			elsif id = ENTRY then*/
    if (_id_60943 != 424)
    goto L19; // [584] 606

    /** parser.e:4005			    StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _45StartSourceLine(_9TRUE_446, 0, 1);

    /** parser.e:4006			    Entry_statement()*/
    _43Entry_statement();
    goto L9; // [603] 1115
L19: 

    /** parser.e:4008			elsif id = QUESTION_MARK then*/
    if (_id_60943 != -31)
    goto L1A; // [610] 630

    /** parser.e:4009				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4010				Print_statement()*/
    _43Print_statement();
    goto L9; // [627] 1115
L1A: 

    /** parser.e:4012			elsif id = CONTINUE then*/
    if (_id_60943 != 426)
    goto L1B; // [634] 654

    /** parser.e:4013				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4014				Continue_statement()*/
    _43Continue_statement();
    goto L9; // [651] 1115
L1B: 

    /** parser.e:4016			elsif id = RETRY then*/
    if (_id_60943 != 184)
    goto L1C; // [658] 678

    /** parser.e:4017				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4018				Retry_statement()*/
    _43Retry_statement();
    goto L9; // [675] 1115
L1C: 

    /** parser.e:4020			elsif id = IFDEF then*/
    if (_id_60943 != 407)
    goto L1D; // [682] 702

    /** parser.e:4021				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4022				Ifdef_statement()*/
    _43Ifdef_statement();
    goto L9; // [699] 1115
L1D: 

    /** parser.e:4024			elsif id = CASE then*/
    if (_id_60943 != 186)
    goto L1E; // [706] 717

    /** parser.e:4025				Case_statement()*/
    _43Case_statement();
    goto L9; // [714] 1115
L1E: 

    /** parser.e:4027			elsif id = SWITCH then*/
    if (_id_60943 != 185)
    goto L1F; // [721] 741

    /** parser.e:4028				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4029				Switch_statement()*/
    _43Switch_statement();
    goto L9; // [738] 1115
L1F: 

    /** parser.e:4031			elsif id = FALLTHRU then*/
    if (_id_60943 != 431)
    goto L20; // [745] 756

    /** parser.e:4032				Fallthru_statement()*/
    _43Fallthru_statement();
    goto L9; // [753] 1115
L20: 

    /** parser.e:4034			elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _30234 = (_id_60943 == 504);
    if (_30234 != 0) {
        goto L21; // [764] 779
    }
    _30236 = (_id_60943 == 522);
    if (_30236 == 0)
    {
        DeRef(_30236);
        _30236 = NOVALUE;
        goto L22; // [775] 904
    }
    else{
        DeRef(_30236);
        _30236 = NOVALUE;
    }
L21: 

    /** parser.e:4035				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4036				token test = next_token()*/
    _0 = _test_61115;
    _test_61115 = _43next_token();
    DeRef(_0);

    /** parser.e:4037				putback( test )*/
    Ref(_test_61115);
    _43putback(_test_61115);

    /** parser.e:4038				if test[T_ID] = LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_test_61115);
    _30238 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30238, -26)){
        _30238 = NOVALUE;
        goto L23; // [808] 852
    }
    _30238 = NOVALUE;

    /** parser.e:4039					StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4040					Procedure_call(tok)*/
    Ref(_tok_60942);
    _43Procedure_call(_tok_60942);

    /** parser.e:4041					clear_op()*/
    _45clear_op();

    /** parser.e:4042					if Pop() then end if*/
    _30240 = _45Pop();
    if (_30240 == 0) {
        DeRef(_30240);
        _30240 = NOVALUE;
        goto L24; // [835] 839
    }
    else {
        if (!IS_ATOM_INT(_30240) && DBL_PTR(_30240)->dbl == 0.0){
            DeRef(_30240);
            _30240 = NOVALUE;
            goto L24; // [835] 839
        }
        DeRef(_30240);
        _30240 = NOVALUE;
    }
    DeRef(_30240);
    _30240 = NOVALUE;
L24: 

    /** parser.e:4043					ExecCommand()*/
    _43ExecCommand();

    /** parser.e:4044					continue*/
    DeRef(_test_61115);
    _test_61115 = NOVALUE;
    goto L1; // [847] 16
    goto L25; // [849] 899
L23: 

    /** parser.e:4047					if param_num != -1 then*/
    if (_43param_num_54961 == -1)
    goto L26; // [856] 882

    /** parser.e:4049						param_num += 1*/
    _43param_num_54961 = _43param_num_54961 + 1;

    /** parser.e:4050						Private_declaration( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_60942);
    _30243 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30243);
    _43Private_declaration(_30243);
    _30243 = NOVALUE;
    goto L27; // [879] 898
L26: 

    /** parser.e:4052						Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (object)SEQ_PTR(_tok_60942);
    _30244 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30244);
    _30245 = _43Global_declaration(_30244, 5);
    _30244 = NOVALUE;
L27: 
L25: 
    DeRef(_test_61115);
    _test_61115 = NOVALUE;
    goto L9; // [901] 1115
L22: 

    /** parser.e:4055			elsif id = LEFT_BRACE then*/
    if (_id_60943 != -24)
    goto L28; // [908] 928

    /** parser.e:4056				StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4057				Multi_assign()*/
    _43Multi_assign();
    goto L9; // [925] 1115
L28: 

    /** parser.e:4060				if id = ELSE then*/
    if (_id_60943 != 23)
    goto L29; // [932] 990

    /** parser.e:4061					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_43if_stack_54987)){
            _30248 = SEQ_PTR(_43if_stack_54987)->length;
    }
    else {
        _30248 = 1;
    }
    if (_30248 != 0)
    goto L2A; // [943] 1051

    /** parser.e:4062						if live_ifdef > 0 then*/
    if (_43live_ifdef_59454 <= 0)
    goto L2B; // [951] 976

    /** parser.e:4063							CompileErr(SHOULD_THIS_BE_ELSEDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59455)){
            _30251 = SEQ_PTR(_43ifdef_lineno_59455)->length;
    }
    else {
        _30251 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59455);
    _30252 = (object)*(((s1_ptr)_2)->base + _30251);
    _49CompileErr(134, _30252, 0);
    _30252 = NOVALUE;
    goto L2A; // [973] 1051
L2B: 

    /** parser.e:4065							CompileErr(NOT_EXPECTING_ELSE)*/
    RefDS(_22015);
    _49CompileErr(118, _22015, 0);
    goto L2A; // [987] 1051
L29: 

    /** parser.e:4068				elsif id = ELSIF then*/
    if (_id_60943 != 414)
    goto L2C; // [994] 1050

    /** parser.e:4069					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_43if_stack_54987)){
            _30254 = SEQ_PTR(_43if_stack_54987)->length;
    }
    else {
        _30254 = 1;
    }
    if (_30254 != 0)
    goto L2D; // [1005] 1049

    /** parser.e:4070						if live_ifdef > 0 then*/
    if (_43live_ifdef_59454 <= 0)
    goto L2E; // [1013] 1038

    /** parser.e:4071							CompileErr(SHOULD_THIS_BE_ELSIFDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59455)){
            _30257 = SEQ_PTR(_43ifdef_lineno_59455)->length;
    }
    else {
        _30257 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59455);
    _30258 = (object)*(((s1_ptr)_2)->base + _30257);
    _49CompileErr(139, _30258, 0);
    _30258 = NOVALUE;
    goto L2F; // [1035] 1048
L2E: 

    /** parser.e:4073							CompileErr(NOT_EXPECTING_ELSIF)*/
    RefDS(_22015);
    _49CompileErr(119, _22015, 0);
L2F: 
L2D: 
L2C: 
L2A: 

    /** parser.e:4078				putback( tok )*/
    Ref(_tok_60942);
    _43putback(_tok_60942);

    /** parser.e:4080				switch id do*/
    _0 = _id_60943;
    switch ( _0 ){ 

        /** parser.e:4081					case END, ELSEDEF, ELSIFDEF, ELSIF, ELSE, UNTIL then*/
        case 402:
        case 409:
        case 408:
        case 414:
        case 23:
        case 423:

        /** parser.e:4083						stmt_nest -= 1*/
        _43stmt_nest_54984 = _43stmt_nest_54984 - 1;

        /** parser.e:4084						InitDelete()*/
        _43InitDelete();

        /** parser.e:4085						flush_temps()*/
        RefDS(_22015);
        _45flush_temps(_22015);

        /** parser.e:4086						return*/
        DeRef(_tok_60942);
        DeRef(_30190);
        _30190 = NOVALUE;
        _30193 = NOVALUE;
        DeRef(_30211);
        _30211 = NOVALUE;
        DeRef(_30234);
        _30234 = NOVALUE;
        DeRef(_30206);
        _30206 = NOVALUE;
        DeRef(_30245);
        _30245 = NOVALUE;
        DeRef(_30205);
        _30205 = NOVALUE;
        return;
        goto L30; // [1099] 1114

        /** parser.e:4088					case else*/
        default:

        /** parser.e:4089						tok_match( END )*/
        _43tok_match(402, 0);
    ;}L30: 
L9: 

    /** parser.e:4094			flush_temps()*/
    RefDS(_22015);
    _45flush_temps(_22015);

    /** parser.e:4095		end while*/
    goto L1; // [1122] 16
L2: 

    /** parser.e:4096	end procedure*/
    DeRef(_tok_60942);
    DeRef(_30190);
    _30190 = NOVALUE;
    _30193 = NOVALUE;
    DeRef(_30211);
    _30211 = NOVALUE;
    DeRef(_30234);
    _30234 = NOVALUE;
    DeRef(_30206);
    _30206 = NOVALUE;
    DeRef(_30245);
    _30245 = NOVALUE;
    DeRef(_30205);
    _30205 = NOVALUE;
    return;
    ;
}


void _43SubProg(object _prog_type_61194, object _scope_61195, object _deprecated_61196)
{
    object _h_61197 = NOVALUE;
    object _pt_61198 = NOVALUE;
    object _p_61200 = NOVALUE;
    object _type_sym_61201 = NOVALUE;
    object _sym_61202 = NOVALUE;
    object _tok_61204 = NOVALUE;
    object _prog_name_61205 = NOVALUE;
    object _first_def_arg_61206 = NOVALUE;
    object _again_61207 = NOVALUE;
    object _type_enum_61208 = NOVALUE;
    object _seq_sym_61209 = NOVALUE;
    object _i1_sym_61210 = NOVALUE;
    object _enum_syms_61211 = NOVALUE;
    object _type_enum_gline_61212 = NOVALUE;
    object _real_gline_61213 = NOVALUE;
    object _tsym_61225 = NOVALUE;
    object _seq_symbol_61236 = NOVALUE;
    object _middle_def_args_61441 = NOVALUE;
    object _last_nda_61442 = NOVALUE;
    object _start_def_61443 = NOVALUE;
    object _last_link_61445 = NOVALUE;
    object _temptok_61472 = NOVALUE;
    object _undef_type_61474 = NOVALUE;
    object _tokcat_61526 = NOVALUE;
    object _31701 = NOVALUE;
    object _31700 = NOVALUE;
    object _31699 = NOVALUE;
    object _31698 = NOVALUE;
    object _31697 = NOVALUE;
    object _31696 = NOVALUE;
    object _31695 = NOVALUE;
    object _31694 = NOVALUE;
    object _31693 = NOVALUE;
    object _30524 = NOVALUE;
    object _30522 = NOVALUE;
    object _30521 = NOVALUE;
    object _30519 = NOVALUE;
    object _30518 = NOVALUE;
    object _30517 = NOVALUE;
    object _30516 = NOVALUE;
    object _30515 = NOVALUE;
    object _30513 = NOVALUE;
    object _30512 = NOVALUE;
    object _30509 = NOVALUE;
    object _30508 = NOVALUE;
    object _30507 = NOVALUE;
    object _30506 = NOVALUE;
    object _30504 = NOVALUE;
    object _30495 = NOVALUE;
    object _30493 = NOVALUE;
    object _30492 = NOVALUE;
    object _30491 = NOVALUE;
    object _30490 = NOVALUE;
    object _30487 = NOVALUE;
    object _30486 = NOVALUE;
    object _30485 = NOVALUE;
    object _30483 = NOVALUE;
    object _30480 = NOVALUE;
    object _30479 = NOVALUE;
    object _30478 = NOVALUE;
    object _30476 = NOVALUE;
    object _30475 = NOVALUE;
    object _30472 = NOVALUE;
    object _30470 = NOVALUE;
    object _30468 = NOVALUE;
    object _30467 = NOVALUE;
    object _30466 = NOVALUE;
    object _30465 = NOVALUE;
    object _30463 = NOVALUE;
    object _30462 = NOVALUE;
    object _30461 = NOVALUE;
    object _30460 = NOVALUE;
    object _30459 = NOVALUE;
    object _30458 = NOVALUE;
    object _30455 = NOVALUE;
    object _30453 = NOVALUE;
    object _30451 = NOVALUE;
    object _30449 = NOVALUE;
    object _30447 = NOVALUE;
    object _30444 = NOVALUE;
    object _30442 = NOVALUE;
    object _30441 = NOVALUE;
    object _30438 = NOVALUE;
    object _30434 = NOVALUE;
    object _30433 = NOVALUE;
    object _30431 = NOVALUE;
    object _30429 = NOVALUE;
    object _30427 = NOVALUE;
    object _30425 = NOVALUE;
    object _30423 = NOVALUE;
    object _30421 = NOVALUE;
    object _30420 = NOVALUE;
    object _30419 = NOVALUE;
    object _30418 = NOVALUE;
    object _30417 = NOVALUE;
    object _30416 = NOVALUE;
    object _30415 = NOVALUE;
    object _30414 = NOVALUE;
    object _30413 = NOVALUE;
    object _30412 = NOVALUE;
    object _30411 = NOVALUE;
    object _30410 = NOVALUE;
    object _30407 = NOVALUE;
    object _30406 = NOVALUE;
    object _30405 = NOVALUE;
    object _30404 = NOVALUE;
    object _30403 = NOVALUE;
    object _30402 = NOVALUE;
    object _30401 = NOVALUE;
    object _30400 = NOVALUE;
    object _30399 = NOVALUE;
    object _30398 = NOVALUE;
    object _30397 = NOVALUE;
    object _30396 = NOVALUE;
    object _30395 = NOVALUE;
    object _30394 = NOVALUE;
    object _30393 = NOVALUE;
    object _30391 = NOVALUE;
    object _30389 = NOVALUE;
    object _30388 = NOVALUE;
    object _30383 = NOVALUE;
    object _30382 = NOVALUE;
    object _30380 = NOVALUE;
    object _30379 = NOVALUE;
    object _30378 = NOVALUE;
    object _30377 = NOVALUE;
    object _30376 = NOVALUE;
    object _30375 = NOVALUE;
    object _30374 = NOVALUE;
    object _30373 = NOVALUE;
    object _30372 = NOVALUE;
    object _30371 = NOVALUE;
    object _30369 = NOVALUE;
    object _30368 = NOVALUE;
    object _30366 = NOVALUE;
    object _30365 = NOVALUE;
    object _30364 = NOVALUE;
    object _30363 = NOVALUE;
    object _30362 = NOVALUE;
    object _30361 = NOVALUE;
    object _30360 = NOVALUE;
    object _30358 = NOVALUE;
    object _30355 = NOVALUE;
    object _30353 = NOVALUE;
    object _30351 = NOVALUE;
    object _30349 = NOVALUE;
    object _30347 = NOVALUE;
    object _30345 = NOVALUE;
    object _30343 = NOVALUE;
    object _30341 = NOVALUE;
    object _30339 = NOVALUE;
    object _30337 = NOVALUE;
    object _30336 = NOVALUE;
    object _30335 = NOVALUE;
    object _30334 = NOVALUE;
    object _30333 = NOVALUE;
    object _30332 = NOVALUE;
    object _30331 = NOVALUE;
    object _30329 = NOVALUE;
    object _30328 = NOVALUE;
    object _30326 = NOVALUE;
    object _30324 = NOVALUE;
    object _30322 = NOVALUE;
    object _30321 = NOVALUE;
    object _30318 = NOVALUE;
    object _30317 = NOVALUE;
    object _30316 = NOVALUE;
    object _30315 = NOVALUE;
    object _30314 = NOVALUE;
    object _30312 = NOVALUE;
    object _30311 = NOVALUE;
    object _30310 = NOVALUE;
    object _30309 = NOVALUE;
    object _30308 = NOVALUE;
    object _30306 = NOVALUE;
    object _30305 = NOVALUE;
    object _30304 = NOVALUE;
    object _30302 = NOVALUE;
    object _30301 = NOVALUE;
    object _30300 = NOVALUE;
    object _30299 = NOVALUE;
    object _30295 = NOVALUE;
    object _30294 = NOVALUE;
    object _30293 = NOVALUE;
    object _30291 = NOVALUE;
    object _30290 = NOVALUE;
    object _30289 = NOVALUE;
    object _30288 = NOVALUE;
    object _30287 = NOVALUE;
    object _30286 = NOVALUE;
    object _30282 = NOVALUE;
    object _30281 = NOVALUE;
    object _30280 = NOVALUE;
    object _30278 = NOVALUE;
    object _30277 = NOVALUE;
    object _30276 = NOVALUE;
    object _30274 = NOVALUE;
    object _30273 = NOVALUE;
    object _30271 = NOVALUE;
    object _30270 = NOVALUE;
    object _30269 = NOVALUE;
    object _30265 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_prog_type_61194)) {
        _1 = (object)(DBL_PTR(_prog_type_61194)->dbl);
        DeRefDS(_prog_type_61194);
        _prog_type_61194 = _1;
    }

    /** parser.e:4105		integer first_def_arg*/

    /** parser.e:4106		integer again*/

    /** parser.e:4107		integer type_enum*/

    /** parser.e:4108		object seq_sym*/

    /** parser.e:4109		object i1_sym*/

    /** parser.e:4110		sequence enum_syms = {}*/
    RefDS(_22015);
    DeRef(_enum_syms_61211);
    _enum_syms_61211 = _22015;

    /** parser.e:4111		integer type_enum_gline, real_gline*/

    /** parser.e:4113		LeaveTopLevel()*/
    _43LeaveTopLevel();

    /** parser.e:4114		prog_name = next_token()*/
    _0 = _prog_name_61205;
    _prog_name_61205 = _43next_token();
    DeRef(_0);

    /** parser.e:4115		if prog_name[T_ID] = END_OF_FILE then*/
    _2 = (object)SEQ_PTR(_prog_name_61205);
    _30265 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30265, -21)){
        _30265 = NOVALUE;
        goto L1; // [45] 59
    }
    _30265 = NOVALUE;

    /** parser.e:4116			CompileErr( AN_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_22015);
    _49CompileErr(32, _22015, 0);
L1: 

    /** parser.e:4118		type_enum =  0*/
    _type_enum_61208 = 0;

    /** parser.e:4119		if prog_type = TYPE_DECL then*/
    if (_prog_type_61194 != 416)
    goto L2; // [68] 322

    /** parser.e:4120			object tsym = prog_name[T_SYM]*/
    DeRef(_tsym_61225);
    _2 = (object)SEQ_PTR(_prog_name_61205);
    _tsym_61225 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tsym_61225);

    /** parser.e:4121			if equal(sym_name(prog_name[T_SYM]),"enum") then*/
    _2 = (object)SEQ_PTR(_prog_name_61205);
    _30269 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30269);
    _30270 = _53sym_name(_30269);
    _30269 = NOVALUE;
    if (_30270 == _26204)
    _30271 = 1;
    else if (IS_ATOM_INT(_30270) && IS_ATOM_INT(_26204))
    _30271 = 0;
    else
    _30271 = (compare(_30270, _26204) == 0);
    DeRef(_30270);
    _30270 = NOVALUE;
    if (_30271 == 0)
    {
        _30271 = NOVALUE;
        goto L3; // [96] 319
    }
    else{
        _30271 = NOVALUE;
    }

    /** parser.e:4125				EnterTopLevel( FALSE )*/
    _43EnterTopLevel(_9FALSE_444);

    /** parser.e:4126				type_enum_gline = gline_number*/
    _type_enum_gline_61212 = _12gline_number_20231;

    /** parser.e:4127				type_enum = 1*/
    _type_enum_61208 = 1;

    /** parser.e:4128				sequence seq_symbol*/

    /** parser.e:4129				prog_name = next_token()*/
    _0 = _prog_name_61205;
    _prog_name_61205 = _43next_token();
    DeRef(_0);

    /** parser.e:4130				if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_prog_name_61205);
    _30273 = (object)*(((s1_ptr)_2)->base + 1);
    _30274 = find_from(_30273, _29ADDR_TOKS_12010, 1);
    _30273 = NOVALUE;
    if (_30274 != 0)
    goto L4; // [142] 169
    _30274 = NOVALUE;

    /** parser.e:4131					CompileErr(FOUND__1__BUT_WAS_EXPECTING_AN_IDENTIFIER_NAME, {find_category(prog_name[T_ID])} )*/
    _2 = (object)SEQ_PTR(_prog_name_61205);
    _30276 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30276);
    _30277 = _62find_category(_30276);
    _30276 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30277;
    _30278 = MAKE_SEQ(_1);
    _30277 = NOVALUE;
    _49CompileErr(25, _30278, 0);
    _30278 = NOVALUE;
L4: 

    /** parser.e:4133				enum_syms = Global_declaration(-1, scope)*/
    _0 = _enum_syms_61211;
    _enum_syms_61211 = _43Global_declaration(-1, _scope_61195);
    DeRef(_0);

    /** parser.e:4134				seq_symbol = enum_syms*/
    RefDS(_enum_syms_61211);
    DeRef(_seq_symbol_61236);
    _seq_symbol_61236 = _enum_syms_61211;

    /** parser.e:4135				for i = 1 to length( enum_syms ) do*/
    if (IS_SEQUENCE(_enum_syms_61211)){
            _30280 = SEQ_PTR(_enum_syms_61211)->length;
    }
    else {
        _30280 = 1;
    }
    {
        object _i_61253;
        _i_61253 = 1;
L5: 
        if (_i_61253 > _30280){
            goto L6; // [190] 218
        }

        /** parser.e:4136					seq_symbol[i] = sym_obj(enum_syms[i])*/
        _2 = (object)SEQ_PTR(_enum_syms_61211);
        _30281 = (object)*(((s1_ptr)_2)->base + _i_61253);
        Ref(_30281);
        _30282 = _53sym_obj(_30281);
        _30281 = NOVALUE;
        _2 = (object)SEQ_PTR(_seq_symbol_61236);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _seq_symbol_61236 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_61253);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _30282;
        if( _1 != _30282 ){
            DeRef(_1);
        }
        _30282 = NOVALUE;

        /** parser.e:4137				end for*/
        _i_61253 = _i_61253 + 1;
        goto L5; // [213] 197
L6: 
        ;
    }

    /** parser.e:4142				i1_sym = keyfind("i1",-1)*/
    RefDS(_30283);
    DeRef(_31700);
    _31700 = _30283;
    _31701 = _53hashfn(_31700);
    _31700 = NOVALUE;
    RefDS(_30283);
    _0 = _i1_sym_61210;
    _i1_sym_61210 = _53keyfind(_30283, -1, _12current_file_no_20226, 0, _31701);
    DeRef(_0);
    _31701 = NOVALUE;

    /** parser.e:4143				seq_sym = NewStringSym(seq_symbol)*/
    RefDS(_seq_symbol_61236);
    _0 = _seq_sym_61209;
    _seq_sym_61209 = _53NewStringSym(_seq_symbol_61236);
    DeRef(_0);

    /** parser.e:4144				putback(keyfind("return",-1))*/
    RefDS(_26278);
    DeRef(_31698);
    _31698 = _26278;
    _31699 = _53hashfn(_31698);
    _31698 = NOVALUE;
    RefDS(_26278);
    _30286 = _53keyfind(_26278, -1, _12current_file_no_20226, 0, _31699);
    _31699 = NOVALUE;
    _43putback(_30286);
    _30286 = NOVALUE;

    /** parser.e:4145				putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -27;
    ((intptr_t *)_2)[2] = 0;
    _30287 = MAKE_SEQ(_1);
    _43putback(_30287);
    _30287 = NOVALUE;

    /** parser.e:4146				putback(i1_sym)*/
    Ref(_i1_sym_61210);
    _43putback(_i1_sym_61210);

    /** parser.e:4147				putback(keyfind("object",-1))*/
    RefDS(_22977);
    DeRef(_31696);
    _31696 = _22977;
    _31697 = _53hashfn(_31696);
    _31696 = NOVALUE;
    RefDS(_22977);
    _30288 = _53keyfind(_22977, -1, _12current_file_no_20226, 0, _31697);
    _31697 = NOVALUE;
    _43putback(_30288);
    _30288 = NOVALUE;

    /** parser.e:4148				putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -26;
    ((intptr_t *)_2)[2] = 0;
    _30289 = MAKE_SEQ(_1);
    _43putback(_30289);
    _30289 = NOVALUE;

    /** parser.e:4150				LeaveTopLevel()*/
    _43LeaveTopLevel();
L3: 
    DeRef(_seq_symbol_61236);
    _seq_symbol_61236 = NOVALUE;
L2: 
    DeRef(_tsym_61225);
    _tsym_61225 = NOVALUE;

    /** parser.e:4153		if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_prog_name_61205);
    _30290 = (object)*(((s1_ptr)_2)->base + 1);
    _30291 = find_from(_30290, _29ADDR_TOKS_12010, 1);
    _30290 = NOVALUE;
    if (_30291 != 0)
    goto L7; // [339] 366
    _30291 = NOVALUE;

    /** parser.e:4154			CompileErr(FOUND__1__BUT_WAS_EXPECTING_AN_IDENTIFIER_NAME, {find_category(prog_name[T_ID])} )*/
    _2 = (object)SEQ_PTR(_prog_name_61205);
    _30293 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30293);
    _30294 = _62find_category(_30293);
    _30293 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30294;
    _30295 = MAKE_SEQ(_1);
    _30294 = NOVALUE;
    _49CompileErr(25, _30295, 0);
    _30295 = NOVALUE;
L7: 

    /** parser.e:4156		p = prog_name[T_SYM]*/
    _2 = (object)SEQ_PTR(_prog_name_61205);
    _p_61200 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_61200)){
        _p_61200 = (object)DBL_PTR(_p_61200)->dbl;
    }

    /** parser.e:4157		DefinedYet(p)*/
    _53DefinedYet(_p_61200);

    /** parser.e:4158		if prog_type = PROCEDURE then*/
    if (_prog_type_61194 != 405)
    goto L8; // [385] 401

    /** parser.e:4159			pt = PROC*/
    _pt_61198 = 27;
    goto L9; // [398] 431
L8: 

    /** parser.e:4160		elsif prog_type = FUNCTION then*/
    if (_prog_type_61194 != 406)
    goto LA; // [405] 421

    /** parser.e:4161			pt = FUNC*/
    _pt_61198 = 501;
    goto L9; // [418] 431
LA: 

    /** parser.e:4163			pt = TYPE*/
    _pt_61198 = 504;
L9: 

    /** parser.e:4166		clear_fwd_refs()*/
    _42clear_fwd_refs();

    /** parser.e:4167		if find(SymTab[p][S_SCOPE], {SC_PREDEF, SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_OVERRIDE}) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30299 = (object)*(((s1_ptr)_2)->base + _p_61200);
    _2 = (object)SEQ_PTR(_30299);
    _30300 = (object)*(((s1_ptr)_2)->base + 4);
    _30299 = NOVALUE;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 7;
    ((intptr_t*)_2)[2] = 6;
    ((intptr_t*)_2)[3] = 13;
    ((intptr_t*)_2)[4] = 11;
    ((intptr_t*)_2)[5] = 12;
    _30301 = MAKE_SEQ(_1);
    _30302 = find_from(_30300, _30301, 1);
    _30300 = NOVALUE;
    DeRefDS(_30301);
    _30301 = NOVALUE;
    if (_30302 == 0)
    {
        _30302 = NOVALUE;
        goto LB; // [472] 668
    }
    else{
        _30302 = NOVALUE;
    }

    /** parser.e:4169			if scope = SC_OVERRIDE then*/
    if (_scope_61195 != 12)
    goto LC; // [479] 605

    /** parser.e:4170				if SymTab[p][S_SCOPE] = SC_PREDEF or SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30304 = (object)*(((s1_ptr)_2)->base + _p_61200);
    _2 = (object)SEQ_PTR(_30304);
    _30305 = (object)*(((s1_ptr)_2)->base + 4);
    _30304 = NOVALUE;
    if (IS_ATOM_INT(_30305)) {
        _30306 = (_30305 == 7);
    }
    else {
        _30306 = binary_op(EQUALS, _30305, 7);
    }
    _30305 = NOVALUE;
    if (IS_ATOM_INT(_30306)) {
        if (_30306 != 0) {
            goto LD; // [503] 530
        }
    }
    else {
        if (DBL_PTR(_30306)->dbl != 0.0) {
            goto LD; // [503] 530
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30308 = (object)*(((s1_ptr)_2)->base + _p_61200);
    _2 = (object)SEQ_PTR(_30308);
    _30309 = (object)*(((s1_ptr)_2)->base + 4);
    _30308 = NOVALUE;
    if (IS_ATOM_INT(_30309)) {
        _30310 = (_30309 == 12);
    }
    else {
        _30310 = binary_op(EQUALS, _30309, 12);
    }
    _30309 = NOVALUE;
    if (_30310 == 0) {
        DeRef(_30310);
        _30310 = NOVALUE;
        goto LE; // [526] 604
    }
    else {
        if (!IS_ATOM_INT(_30310) && DBL_PTR(_30310)->dbl == 0.0){
            DeRef(_30310);
            _30310 = NOVALUE;
            goto LE; // [526] 604
        }
        DeRef(_30310);
        _30310 = NOVALUE;
    }
    DeRef(_30310);
    _30310 = NOVALUE;
LD: 

    /** parser.e:4171						if SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30311 = (object)*(((s1_ptr)_2)->base + _p_61200);
    _2 = (object)SEQ_PTR(_30311);
    _30312 = (object)*(((s1_ptr)_2)->base + 4);
    _30311 = NOVALUE;
    if (binary_op_a(NOTEQ, _30312, 12)){
        _30312 = NOVALUE;
        goto LF; // [546] 558
    }
    _30312 = NOVALUE;

    /** parser.e:4172							again = 223*/
    _again_61207 = 223;
    goto L10; // [555] 564
LF: 

    /** parser.e:4174							again = 222*/
    _again_61207 = 222;
L10: 

    /** parser.e:4176						Warning(again, override_warning_flag,*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _30314 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30315 = (object)*(((s1_ptr)_2)->base + _p_61200);
    _2 = (object)SEQ_PTR(_30315);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _30316 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _30316 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _30315 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_30314);
    ((intptr_t*)_2)[1] = _30314;
    ((intptr_t*)_2)[2] = _12line_number_20227;
    Ref(_30316);
    ((intptr_t*)_2)[3] = _30316;
    _30317 = MAKE_SEQ(_1);
    _30316 = NOVALUE;
    _30314 = NOVALUE;
    _49Warning(_again_61207, 4, _30317);
    _30317 = NOVALUE;
LE: 
LC: 

    /** parser.e:4181			h = SymTab[p][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30318 = (object)*(((s1_ptr)_2)->base + _p_61200);
    _2 = (object)SEQ_PTR(_30318);
    _h_61197 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_61197)){
        _h_61197 = (object)DBL_PTR(_h_61197)->dbl;
    }
    _30318 = NOVALUE;

    /** parser.e:4182			sym = buckets[h]*/
    _2 = (object)SEQ_PTR(_53buckets_46799);
    _sym_61202 = (object)*(((s1_ptr)_2)->base + _h_61197);
    if (!IS_ATOM_INT(_sym_61202)){
        _sym_61202 = (object)DBL_PTR(_sym_61202)->dbl;
    }

    /** parser.e:4183			p = NewEntry(SymTab[p][S_NAME], 0, 0, pt, h, sym, 0)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30321 = (object)*(((s1_ptr)_2)->base + _p_61200);
    _2 = (object)SEQ_PTR(_30321);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _30322 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _30322 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _30321 = NOVALUE;
    Ref(_30322);
    _p_61200 = _53NewEntry(_30322, 0, 0, _pt_61198, _h_61197, _sym_61202, 0);
    _30322 = NOVALUE;
    if (!IS_ATOM_INT(_p_61200)) {
        _1 = (object)(DBL_PTR(_p_61200)->dbl);
        DeRefDS(_p_61200);
        _p_61200 = _1;
    }

    /** parser.e:4184			buckets[h] = p*/
    _2 = (object)SEQ_PTR(_53buckets_46799);
    _2 = (object)(((s1_ptr)_2)->base + _h_61197);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_61200;
    DeRef(_1);
LB: 

    /** parser.e:4187		Start_block( pt, p )*/
    _64Start_block(_pt_61198, _p_61200);

    /** parser.e:4189		CurrentSub = p*/
    _12CurrentSub_20234 = _p_61200;

    /** parser.e:4190		first_def_arg = 0*/
    _first_def_arg_61206 = 0;

    /** parser.e:4191		temps_allocated = 0*/
    _53temps_allocated_47334 = 0;

    /** parser.e:4193		SymTab[p][S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61200 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_61195;
    DeRef(_1);
    _30324 = NOVALUE;

    /** parser.e:4195		SymTab[p][S_TOKEN] = pt*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61200 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TOKEN_19869))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _pt_61198;
    DeRef(_1);
    _30326 = NOVALUE;

    /** parser.e:4197		if length(SymTab[p]) < SIZEOF_ROUTINE_ENTRY then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30328 = (object)*(((s1_ptr)_2)->base + _p_61200);
    if (IS_SEQUENCE(_30328)){
            _30329 = SEQ_PTR(_30328)->length;
    }
    else {
        _30329 = 1;
    }
    _30328 = NOVALUE;
    if (_30329 >= _12SIZEOF_ROUTINE_ENTRY_19990)
    goto L11; // [738] 780

    /** parser.e:4199			SymTab[p] = SymTab[p] & repeat(0, SIZEOF_ROUTINE_ENTRY -*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30331 = (object)*(((s1_ptr)_2)->base + _p_61200);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30332 = (object)*(((s1_ptr)_2)->base + _p_61200);
    if (IS_SEQUENCE(_30332)){
            _30333 = SEQ_PTR(_30332)->length;
    }
    else {
        _30333 = 1;
    }
    _30332 = NOVALUE;
    _30334 = _12SIZEOF_ROUTINE_ENTRY_19990 - _30333;
    _30333 = NOVALUE;
    _30335 = Repeat(0, _30334);
    _30334 = NOVALUE;
    if (IS_SEQUENCE(_30331) && IS_ATOM(_30335)) {
    }
    else if (IS_ATOM(_30331) && IS_SEQUENCE(_30335)) {
        Ref(_30331);
        Prepend(&_30336, _30335, _30331);
    }
    else {
        Concat((object_ptr)&_30336, _30331, _30335);
        _30331 = NOVALUE;
    }
    _30331 = NOVALUE;
    DeRefDS(_30335);
    _30335 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_61200);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30336;
    if( _1 != _30336 ){
        DeRef(_1);
    }
    _30336 = NOVALUE;
L11: 

    /** parser.e:4203		SymTab[p][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61200 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30337 = NOVALUE;

    /** parser.e:4204		SymTab[p][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61200 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_19899))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30339 = NOVALUE;

    /** parser.e:4205		SymTab[p][S_EFFECT] = E_PURE*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61200 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30341 = NOVALUE;

    /** parser.e:4206		SymTab[p][S_REFLIST] = {}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61200 + ((s1_ptr)_2)->base);
    RefDS(_22015);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22015;
    DeRef(_1);
    _30343 = NOVALUE;

    /** parser.e:4207		SymTab[p][S_FIRSTLINE] = gline_number*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61200 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FIRSTLINE_19904))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FIRSTLINE_19904)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_FIRSTLINE_19904);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12gline_number_20231;
    DeRef(_1);
    _30345 = NOVALUE;

    /** parser.e:4208		SymTab[p][S_TEMPS] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61200 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TEMPS_19909))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30347 = NOVALUE;

    /** parser.e:4209		SymTab[p][S_RESIDENT_TASK] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61200 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30349 = NOVALUE;

    /** parser.e:4210		SymTab[p][S_SAVED_PRIVATES] = {}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61200 + ((s1_ptr)_2)->base);
    RefDS(_22015);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22015;
    DeRef(_1);
    _30351 = NOVALUE;

    /** parser.e:4211		SymTab[p][S_DEPRECATED] = deprecated*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61200 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _deprecated_61196;
    DeRef(_1);
    _30353 = NOVALUE;

    /** parser.e:4213		if type_enum then*/
    if (_type_enum_61208 == 0)
    {
        goto L12; // [921] 978
    }
    else{
    }

    /** parser.e:4214			SymTab[p][S_FIRSTLINE] = type_enum_gline*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61200 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FIRSTLINE_19904))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FIRSTLINE_19904)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_FIRSTLINE_19904);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_enum_gline_61212;
    DeRef(_1);
    _30355 = NOVALUE;

    /** parser.e:4215			real_gline = gline_number*/
    _real_gline_61213 = _12gline_number_20231;

    /** parser.e:4216			gline_number = type_enum_gline*/
    _12gline_number_20231 = _type_enum_gline_61212;

    /** parser.e:4217			StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _45StartSourceLine(_9FALSE_444, 0, 3);

    /** parser.e:4218			gline_number = real_gline*/
    _12gline_number_20231 = _real_gline_61213;
    goto L13; // [975] 990
L12: 

    /** parser.e:4220			StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _45StartSourceLine(_9FALSE_444, 0, 3);
L13: 

    /** parser.e:4223		tok_match(LEFT_ROUND)*/
    _43tok_match(-26, 0);

    /** parser.e:4224		tok = next_token()*/
    _0 = _tok_61204;
    _tok_61204 = _43next_token();
    DeRef(_0);

    /** parser.e:4225		param_num = 0*/
    _43param_num_54961 = 0;

    /** parser.e:4228		sequence middle_def_args = {}*/
    RefDS(_22015);
    DeRef(_middle_def_args_61441);
    _middle_def_args_61441 = _22015;

    /** parser.e:4229		integer last_nda = 0, start_def = 0*/
    _last_nda_61442 = 0;
    _start_def_61443 = 0;

    /** parser.e:4230		symtab_index last_link = p*/
    _last_link_61445 = _p_61200;

    /** parser.e:4231		while tok[T_ID] != RIGHT_ROUND do*/
L14: 
    _2 = (object)SEQ_PTR(_tok_61204);
    _30358 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30358, -27)){
        _30358 = NOVALUE;
        goto L15; // [1043] 1830
    }
    _30358 = NOVALUE;

    /** parser.e:4234			if tok[T_ID] != TYPE and tok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (object)SEQ_PTR(_tok_61204);
    _30360 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30360)) {
        _30361 = (_30360 != 504);
    }
    else {
        _30361 = binary_op(NOTEQ, _30360, 504);
    }
    _30360 = NOVALUE;
    if (IS_ATOM_INT(_30361)) {
        if (_30361 == 0) {
            goto L16; // [1061] 1291
        }
    }
    else {
        if (DBL_PTR(_30361)->dbl == 0.0) {
            goto L16; // [1061] 1291
        }
    }
    _2 = (object)SEQ_PTR(_tok_61204);
    _30363 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30363)) {
        _30364 = (_30363 != 522);
    }
    else {
        _30364 = binary_op(NOTEQ, _30363, 522);
    }
    _30363 = NOVALUE;
    if (_30364 == 0) {
        DeRef(_30364);
        _30364 = NOVALUE;
        goto L16; // [1078] 1291
    }
    else {
        if (!IS_ATOM_INT(_30364) && DBL_PTR(_30364)->dbl == 0.0){
            DeRef(_30364);
            _30364 = NOVALUE;
            goto L16; // [1078] 1291
        }
        DeRef(_30364);
        _30364 = NOVALUE;
    }
    DeRef(_30364);
    _30364 = NOVALUE;

    /** parser.e:4235				if tok[T_ID] = VARIABLE or tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_61204);
    _30365 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30365)) {
        _30366 = (_30365 == -100);
    }
    else {
        _30366 = binary_op(EQUALS, _30365, -100);
    }
    _30365 = NOVALUE;
    if (IS_ATOM_INT(_30366)) {
        if (_30366 != 0) {
            goto L17; // [1095] 1116
        }
    }
    else {
        if (DBL_PTR(_30366)->dbl != 0.0) {
            goto L17; // [1095] 1116
        }
    }
    _2 = (object)SEQ_PTR(_tok_61204);
    _30368 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30368)) {
        _30369 = (_30368 == 512);
    }
    else {
        _30369 = binary_op(EQUALS, _30368, 512);
    }
    _30368 = NOVALUE;
    if (_30369 == 0) {
        DeRef(_30369);
        _30369 = NOVALUE;
        goto L18; // [1112] 1280
    }
    else {
        if (!IS_ATOM_INT(_30369) && DBL_PTR(_30369)->dbl == 0.0){
            DeRef(_30369);
            _30369 = NOVALUE;
            goto L18; // [1112] 1280
        }
        DeRef(_30369);
        _30369 = NOVALUE;
    }
    DeRef(_30369);
    _30369 = NOVALUE;
L17: 

    /** parser.e:4237					token temptok = next_token()*/
    _0 = _temptok_61472;
    _temptok_61472 = _43next_token();
    DeRef(_0);

    /** parser.e:4238					integer undef_type = 0*/
    _undef_type_61474 = 0;

    /** parser.e:4239					if temptok[T_ID] != TYPE and temptok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (object)SEQ_PTR(_temptok_61472);
    _30371 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30371)) {
        _30372 = (_30371 != 504);
    }
    else {
        _30372 = binary_op(NOTEQ, _30371, 504);
    }
    _30371 = NOVALUE;
    if (IS_ATOM_INT(_30372)) {
        if (_30372 == 0) {
            goto L19; // [1140] 1243
        }
    }
    else {
        if (DBL_PTR(_30372)->dbl == 0.0) {
            goto L19; // [1140] 1243
        }
    }
    _2 = (object)SEQ_PTR(_temptok_61472);
    _30374 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30374)) {
        _30375 = (_30374 != 522);
    }
    else {
        _30375 = binary_op(NOTEQ, _30374, 522);
    }
    _30374 = NOVALUE;
    if (_30375 == 0) {
        DeRef(_30375);
        _30375 = NOVALUE;
        goto L19; // [1157] 1243
    }
    else {
        if (!IS_ATOM_INT(_30375) && DBL_PTR(_30375)->dbl == 0.0){
            DeRef(_30375);
            _30375 = NOVALUE;
            goto L19; // [1157] 1243
        }
        DeRef(_30375);
        _30375 = NOVALUE;
    }
    DeRef(_30375);
    _30375 = NOVALUE;

    /** parser.e:4240						if find( temptok[T_ID], FULL_ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_temptok_61472);
    _30376 = (object)*(((s1_ptr)_2)->base + 1);
    _30377 = find_from(_30376, _29FULL_ID_TOKS_12014, 1);
    _30376 = NOVALUE;
    if (_30377 == 0)
    {
        _30377 = NOVALUE;
        goto L1A; // [1175] 1242
    }
    else{
        _30377 = NOVALUE;
    }

    /** parser.e:4242							if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok_61204);
    _30378 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30378)){
        _30379 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30378)->dbl));
    }
    else{
        _30379 = (object)*(((s1_ptr)_2)->base + _30378);
    }
    _2 = (object)SEQ_PTR(_30379);
    _30380 = (object)*(((s1_ptr)_2)->base + 4);
    _30379 = NOVALUE;
    if (binary_op_a(NOTEQ, _30380, 9)){
        _30380 = NOVALUE;
        goto L1B; // [1200] 1231
    }
    _30380 = NOVALUE;

    /** parser.e:4245								undef_type = - new_forward_reference( TYPE, tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_61204);
    _30382 = (object)*(((s1_ptr)_2)->base + 2);
    DeRef(_31695);
    _31695 = 504;
    Ref(_30382);
    _30383 = _42new_forward_reference(504, _30382, 504);
    _30382 = NOVALUE;
    _31695 = NOVALUE;
    if (IS_ATOM_INT(_30383)) {
        if ((uintptr_t)_30383 == (uintptr_t)HIGH_BITS){
            _undef_type_61474 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _undef_type_61474 = - _30383;
        }
    }
    else {
        _undef_type_61474 = unary_op(UMINUS, _30383);
    }
    DeRef(_30383);
    _30383 = NOVALUE;
    if (!IS_ATOM_INT(_undef_type_61474)) {
        _1 = (object)(DBL_PTR(_undef_type_61474)->dbl);
        DeRefDS(_undef_type_61474);
        _undef_type_61474 = _1;
    }
    goto L1C; // [1228] 1241
L1B: 

    /** parser.e:4247								CompileErr(A_TYPE_IS_EXPECTED_HERE)*/
    RefDS(_22015);
    _49CompileErr(37, _22015, 0);
L1C: 
L1A: 
L19: 

    /** parser.e:4251					putback(temptok) -- Return whatever came after the name back onto the token stream.*/
    Ref(_temptok_61472);
    _43putback(_temptok_61472);

    /** parser.e:4252					if undef_type != 0 then*/
    if (_undef_type_61474 == 0)
    goto L1D; // [1250] 1265

    /** parser.e:4254						tok[T_SYM] = undef_type*/
    _2 = (object)SEQ_PTR(_tok_61204);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_61204 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _undef_type_61474;
    DeRef(_1);
    goto L1E; // [1262] 1275
L1D: 

    /** parser.e:4256						CompileErr(A_TYPE_IS_EXPECTED_HERE)*/
    RefDS(_22015);
    _49CompileErr(37, _22015, 0);
L1E: 
    DeRef(_temptok_61472);
    _temptok_61472 = NOVALUE;
    goto L1F; // [1277] 1290
L18: 

    /** parser.e:4259					CompileErr(A_TYPE_IS_EXPECTED_HERE)*/
    RefDS(_22015);
    _49CompileErr(37, _22015, 0);
L1F: 
L16: 

    /** parser.e:4262			type_sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_61204);
    _type_sym_61201 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_type_sym_61201)){
        _type_sym_61201 = (object)DBL_PTR(_type_sym_61201)->dbl;
    }

    /** parser.e:4263			tok = next_token()*/
    _0 = _tok_61204;
    _tok_61204 = _43next_token();
    DeRef(_0);

    /** parser.e:4264			if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_61204);
    _30388 = (object)*(((s1_ptr)_2)->base + 1);
    _30389 = find_from(_30388, _29ID_TOKS_12012, 1);
    _30388 = NOVALUE;
    if (_30389 != 0)
    goto L20; // [1321] 1439
    _30389 = NOVALUE;

    /** parser.e:4265				sequence tokcat = find_category(tok[T_ID])*/
    _2 = (object)SEQ_PTR(_tok_61204);
    _30391 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30391);
    _0 = _tokcat_61526;
    _tokcat_61526 = _62find_category(_30391);
    DeRef(_0);
    _30391 = NOVALUE;

    /** parser.e:4266				if tok[T_SYM] != 0 and length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (object)SEQ_PTR(_tok_61204);
    _30393 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_30393)) {
        _30394 = (_30393 != 0);
    }
    else {
        _30394 = binary_op(NOTEQ, _30393, 0);
    }
    _30393 = NOVALUE;
    if (IS_ATOM_INT(_30394)) {
        if (_30394 == 0) {
            goto L21; // [1350] 1413
        }
    }
    else {
        if (DBL_PTR(_30394)->dbl == 0.0) {
            goto L21; // [1350] 1413
        }
    }
    _2 = (object)SEQ_PTR(_tok_61204);
    _30396 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30396)){
        _30397 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30396)->dbl));
    }
    else{
        _30397 = (object)*(((s1_ptr)_2)->base + _30396);
    }
    if (IS_SEQUENCE(_30397)){
            _30398 = SEQ_PTR(_30397)->length;
    }
    else {
        _30398 = 1;
    }
    _30397 = NOVALUE;
    if (IS_ATOM_INT(_12S_NAME_19864)) {
        _30399 = (_30398 >= _12S_NAME_19864);
    }
    else {
        _30399 = binary_op(GREATEREQ, _30398, _12S_NAME_19864);
    }
    _30398 = NOVALUE;
    if (_30399 == 0) {
        DeRef(_30399);
        _30399 = NOVALUE;
        goto L21; // [1376] 1413
    }
    else {
        if (!IS_ATOM_INT(_30399) && DBL_PTR(_30399)->dbl == 0.0){
            DeRef(_30399);
            _30399 = NOVALUE;
            goto L21; // [1376] 1413
        }
        DeRef(_30399);
        _30399 = NOVALUE;
    }
    DeRef(_30399);
    _30399 = NOVALUE;

    /** parser.e:4267					CompileErr(FOUND_1_2_BUT_WAS_EXPECTING_A_PARAMETER_NAME_INSTEAD, {tokcat, SymTab[tok[T_SYM]][S_NAME]})*/
    _2 = (object)SEQ_PTR(_tok_61204);
    _30400 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30400)){
        _30401 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30400)->dbl));
    }
    else{
        _30401 = (object)*(((s1_ptr)_2)->base + _30400);
    }
    _2 = (object)SEQ_PTR(_30401);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _30402 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _30402 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _30401 = NOVALUE;
    Ref(_30402);
    RefDS(_tokcat_61526);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _tokcat_61526;
    ((intptr_t *)_2)[2] = _30402;
    _30403 = MAKE_SEQ(_1);
    _30402 = NOVALUE;
    _49CompileErr(90, _30403, 0);
    _30403 = NOVALUE;
    goto L22; // [1410] 1438
L21: 

    /** parser.e:4269					CompileErr(FOUND_1_BUT_WAS_EXPECTING_A_PARAMETER_NAME_INSTEAD, {LexName(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_61204);
    _30404 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30404);
    RefDS(_26351);
    _30405 = _45LexName(_30404, _26351);
    _30404 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30405;
    _30406 = MAKE_SEQ(_1);
    _30405 = NOVALUE;
    _49CompileErr(92, _30406, 0);
    _30406 = NOVALUE;
L22: 
L20: 
    DeRef(_tokcat_61526);
    _tokcat_61526 = NOVALUE;

    /** parser.e:4272			sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (object)SEQ_PTR(_tok_61204);
    _30407 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30407);
    _sym_61202 = _43SetPrivateScope(_30407, _type_sym_61201, _43param_num_54961);
    _30407 = NOVALUE;
    if (!IS_ATOM_INT(_sym_61202)) {
        _1 = (object)(DBL_PTR(_sym_61202)->dbl);
        DeRefDS(_sym_61202);
        _sym_61202 = _1;
    }

    /** parser.e:4273			param_num += 1*/
    _43param_num_54961 = _43param_num_54961 + 1;

    /** parser.e:4275			if SymTab[last_link][S_NEXT] != sym*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30410 = (object)*(((s1_ptr)_2)->base + _last_link_61445);
    _2 = (object)SEQ_PTR(_30410);
    _30411 = (object)*(((s1_ptr)_2)->base + 2);
    _30410 = NOVALUE;
    if (IS_ATOM_INT(_30411)) {
        _30412 = (_30411 != _sym_61202);
    }
    else {
        _30412 = binary_op(NOTEQ, _30411, _sym_61202);
    }
    _30411 = NOVALUE;
    if (IS_ATOM_INT(_30412)) {
        if (_30412 == 0) {
            goto L23; // [1485] 1566
        }
    }
    else {
        if (DBL_PTR(_30412)->dbl == 0.0) {
            goto L23; // [1485] 1566
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30414 = (object)*(((s1_ptr)_2)->base + _last_link_61445);
    _2 = (object)SEQ_PTR(_30414);
    _30415 = (object)*(((s1_ptr)_2)->base + 2);
    _30414 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30415)){
        _30416 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30415)->dbl));
    }
    else{
        _30416 = (object)*(((s1_ptr)_2)->base + _30415);
    }
    _2 = (object)SEQ_PTR(_30416);
    _30417 = (object)*(((s1_ptr)_2)->base + 4);
    _30416 = NOVALUE;
    if (IS_ATOM_INT(_30417)) {
        _30418 = (_30417 == 9);
    }
    else {
        _30418 = binary_op(EQUALS, _30417, 9);
    }
    _30417 = NOVALUE;
    if (_30418 == 0) {
        DeRef(_30418);
        _30418 = NOVALUE;
        goto L23; // [1520] 1566
    }
    else {
        if (!IS_ATOM_INT(_30418) && DBL_PTR(_30418)->dbl == 0.0){
            DeRef(_30418);
            _30418 = NOVALUE;
            goto L23; // [1520] 1566
        }
        DeRef(_30418);
        _30418 = NOVALUE;
    }
    DeRef(_30418);
    _30418 = NOVALUE;

    /** parser.e:4278				SymTab[SymTab[last_link][S_NEXT]][S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30419 = (object)*(((s1_ptr)_2)->base + _last_link_61445);
    _2 = (object)SEQ_PTR(_30419);
    _30420 = (object)*(((s1_ptr)_2)->base + 2);
    _30419 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_30420))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30420)->dbl));
    else
    _3 = (object)(_30420 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30421 = NOVALUE;

    /** parser.e:4279				SymTab[last_link][S_NEXT] = sym*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_last_link_61445 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_61202;
    DeRef(_1);
    _30423 = NOVALUE;
L23: 

    /** parser.e:4282			last_link = sym*/
    _last_link_61445 = _sym_61202;

    /** parser.e:4284			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L24; // [1577] 1600
    }
    else{
    }

    /** parser.e:4285				SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_61202 + ((s1_ptr)_2)->base);
    _30427 = _43CompileType(_type_sym_61201);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30427;
    if( _1 != _30427 ){
        DeRef(_1);
    }
    _30427 = NOVALUE;
    _30425 = NOVALUE;
L24: 

    /** parser.e:4289			tok = next_token()*/
    _0 = _tok_61204;
    _tok_61204 = _43next_token();
    DeRef(_0);

    /** parser.e:4290			if tok[T_ID] = EQUALS then -- defaulted parameter*/
    _2 = (object)SEQ_PTR(_tok_61204);
    _30429 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30429, 3)){
        _30429 = NOVALUE;
        goto L25; // [1615] 1697
    }
    _30429 = NOVALUE;

    /** parser.e:4291				start_recording()*/
    _43start_recording();

    /** parser.e:4292				Expr()*/
    _43Expr();

    /** parser.e:4293				SymTab[sym][S_CODE] = restore_parser()*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_61202 + ((s1_ptr)_2)->base);
    _30433 = _43restore_parser();
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30433;
    if( _1 != _30433 ){
        DeRef(_1);
    }
    _30433 = NOVALUE;
    _30431 = NOVALUE;

    /** parser.e:4294				if Pop() then end if -- don't leak the default argument*/
    _30434 = _45Pop();
    if (_30434 == 0) {
        DeRef(_30434);
        _30434 = NOVALUE;
        goto L26; // [1650] 1654
    }
    else {
        if (!IS_ATOM_INT(_30434) && DBL_PTR(_30434)->dbl == 0.0){
            DeRef(_30434);
            _30434 = NOVALUE;
            goto L26; // [1650] 1654
        }
        DeRef(_30434);
        _30434 = NOVALUE;
    }
    DeRef(_30434);
    _30434 = NOVALUE;
L26: 

    /** parser.e:4295				tok = next_token()*/
    _0 = _tok_61204;
    _tok_61204 = _43next_token();
    DeRef(_0);

    /** parser.e:4296				if first_def_arg = 0 then*/
    if (_first_def_arg_61206 != 0)
    goto L27; // [1661] 1673

    /** parser.e:4297					first_def_arg = param_num*/
    _first_def_arg_61206 = _43param_num_54961;
L27: 

    /** parser.e:4299				previous_op = -1 -- no interferences betwen defparms, or them and subsequent code*/
    _12previous_op_20325 = -1;

    /** parser.e:4300				if start_def = 0 then*/
    if (_start_def_61443 != 0)
    goto L28; // [1682] 1754

    /** parser.e:4301					start_def = param_num*/
    _start_def_61443 = _43param_num_54961;
    goto L28; // [1694] 1754
L25: 

    /** parser.e:4304				last_nda = param_num*/
    _last_nda_61442 = _43param_num_54961;

    /** parser.e:4305				if start_def then*/
    if (_start_def_61443 == 0)
    {
        goto L29; // [1706] 1753
    }
    else{
    }

    /** parser.e:4306					if start_def = param_num-1 then*/
    _30438 = _43param_num_54961 - 1;
    if ((object)((uintptr_t)_30438 +(uintptr_t) HIGH_BITS) >= 0){
        _30438 = NewDouble((eudouble)_30438);
    }
    if (binary_op_a(NOTEQ, _start_def_61443, _30438)){
        DeRef(_30438);
        _30438 = NOVALUE;
        goto L2A; // [1717] 1730
    }
    DeRef(_30438);
    _30438 = NOVALUE;

    /** parser.e:4307						middle_def_args &= start_def*/
    Append(&_middle_def_args_61441, _middle_def_args_61441, _start_def_61443);
    goto L2B; // [1727] 1747
L2A: 

    /** parser.e:4309						middle_def_args = append(middle_def_args, {start_def, param_num-1})*/
    _30441 = _43param_num_54961 - 1;
    if ((object)((uintptr_t)_30441 +(uintptr_t) HIGH_BITS) >= 0){
        _30441 = NewDouble((eudouble)_30441);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _start_def_61443;
    ((intptr_t *)_2)[2] = _30441;
    _30442 = MAKE_SEQ(_1);
    _30441 = NOVALUE;
    RefDS(_30442);
    Append(&_middle_def_args_61441, _middle_def_args_61441, _30442);
    DeRefDS(_30442);
    _30442 = NOVALUE;
L2B: 

    /** parser.e:4311					start_def = 0*/
    _start_def_61443 = 0;
L29: 
L28: 

    /** parser.e:4314			if tok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok_61204);
    _30444 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30444, -30)){
        _30444 = NOVALUE;
        goto L2C; // [1764] 1800
    }
    _30444 = NOVALUE;

    /** parser.e:4315				tok = next_token()*/
    _0 = _tok_61204;
    _tok_61204 = _43next_token();
    DeRef(_0);

    /** parser.e:4316				if tok[T_ID] = RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_61204);
    _30447 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30447, -27)){
        _30447 = NOVALUE;
        goto L14; // [1783] 1035
    }
    _30447 = NOVALUE;

    /** parser.e:4317					CompileErr(EXPECTED_TO_SEE_A_PARAMETER_DECLARATION_NOT)*/
    RefDS(_22015);
    _49CompileErr(85, _22015, 0);
    goto L14; // [1797] 1035
L2C: 

    /** parser.e:4319			elsif tok[T_ID] != RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_61204);
    _30449 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30449, -27)){
        _30449 = NOVALUE;
        goto L14; // [1810] 1035
    }
    _30449 = NOVALUE;

    /** parser.e:4320				CompileErr(BADLYFORMED_LIST_OF_PARAMETERS__EXPECTED__OR)*/
    RefDS(_22015);
    _49CompileErr(41, _22015, 0);

    /** parser.e:4322		end while*/
    goto L14; // [1827] 1035
L15: 

    /** parser.e:4323		Code = {} -- removes any spurious code emitted while recording parameters*/
    RefDS(_22015);
    DeRef(_12Code_20315);
    _12Code_20315 = _22015;

    /** parser.e:4325		SymTab[p][S_NUM_ARGS] = param_num*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61200 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _43param_num_54961;
    DeRef(_1);
    _30451 = NOVALUE;

    /** parser.e:4326		SymTab[p][S_DEF_ARGS] = {first_def_arg, last_nda, middle_def_args}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61200 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _first_def_arg_61206;
    ((intptr_t*)_2)[2] = _last_nda_61442;
    RefDS(_middle_def_args_61441);
    ((intptr_t*)_2)[3] = _middle_def_args_61441;
    _30455 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 28);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30455;
    if( _1 != _30455 ){
        DeRef(_1);
    }
    _30455 = NOVALUE;
    _30453 = NOVALUE;

    /** parser.e:4327		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L2D; // [1879] 1913
    }
    else{
    }

    /** parser.e:4328			if param_num > max_params then*/
    if (_43param_num_54961 <= _45max_params_50966)
    goto L2E; // [1888] 1902

    /** parser.e:4329				max_params = param_num*/
    _45max_params_50966 = _43param_num_54961;
L2E: 

    /** parser.e:4331			num_routines += 1*/
    _12num_routines_20235 = _12num_routines_20235 + 1;
L2D: 

    /** parser.e:4333		if SymTab[p][S_TOKEN] = TYPE and param_num != 1 then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30458 = (object)*(((s1_ptr)_2)->base + _p_61200);
    _2 = (object)SEQ_PTR(_30458);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _30459 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _30459 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _30458 = NOVALUE;
    if (IS_ATOM_INT(_30459)) {
        _30460 = (_30459 == 504);
    }
    else {
        _30460 = binary_op(EQUALS, _30459, 504);
    }
    _30459 = NOVALUE;
    if (IS_ATOM_INT(_30460)) {
        if (_30460 == 0) {
            goto L2F; // [1933] 1957
        }
    }
    else {
        if (DBL_PTR(_30460)->dbl == 0.0) {
            goto L2F; // [1933] 1957
        }
    }
    _30462 = (_43param_num_54961 != 1);
    if (_30462 == 0)
    {
        DeRef(_30462);
        _30462 = NOVALUE;
        goto L2F; // [1944] 1957
    }
    else{
        DeRef(_30462);
        _30462 = NOVALUE;
    }

    /** parser.e:4334			CompileErr(TYPES_MUST_HAVE_EXACTLY_ONE_PARAMETER)*/
    RefDS(_22015);
    _49CompileErr(148, _22015, 0);
L2F: 

    /** parser.e:4337		include_routine()*/
    _50include_routine();

    /** parser.e:4340		sym = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30463 = (object)*(((s1_ptr)_2)->base + _p_61200);
    _2 = (object)SEQ_PTR(_30463);
    _sym_61202 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_61202)){
        _sym_61202 = (object)DBL_PTR(_sym_61202)->dbl;
    }
    _30463 = NOVALUE;

    /** parser.e:4341		for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30465 = (object)*(((s1_ptr)_2)->base + _p_61200);
    _2 = (object)SEQ_PTR(_30465);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _30466 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _30466 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _30465 = NOVALUE;
    {
        object _i_61685;
        _i_61685 = 1;
L30: 
        if (binary_op_a(GREATER, _i_61685, _30466)){
            goto L31; // [1991] 2070
        }

        /** parser.e:4342			while SymTab[sym][S_SCOPE] != SC_PRIVATE do*/
L32: 
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _30467 = (object)*(((s1_ptr)_2)->base + _sym_61202);
        _2 = (object)SEQ_PTR(_30467);
        _30468 = (object)*(((s1_ptr)_2)->base + 4);
        _30467 = NOVALUE;
        if (binary_op_a(EQUALS, _30468, 3)){
            _30468 = NOVALUE;
            goto L33; // [2017] 2042
        }
        _30468 = NOVALUE;

        /** parser.e:4343				sym = SymTab[sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _30470 = (object)*(((s1_ptr)_2)->base + _sym_61202);
        _2 = (object)SEQ_PTR(_30470);
        _sym_61202 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_61202)){
            _sym_61202 = (object)DBL_PTR(_sym_61202)->dbl;
        }
        _30470 = NOVALUE;

        /** parser.e:4344			end while*/
        goto L32; // [2039] 2003
L33: 

        /** parser.e:4345			TypeCheck(sym)*/
        _43TypeCheck(_sym_61202);

        /** parser.e:4346			sym = SymTab[sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _30472 = (object)*(((s1_ptr)_2)->base + _sym_61202);
        _2 = (object)SEQ_PTR(_30472);
        _sym_61202 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_61202)){
            _sym_61202 = (object)DBL_PTR(_sym_61202)->dbl;
        }
        _30472 = NOVALUE;

        /** parser.e:4347		end for*/
        _0 = _i_61685;
        if (IS_ATOM_INT(_i_61685)) {
            _i_61685 = _i_61685 + 1;
            if ((object)((uintptr_t)_i_61685 +(uintptr_t) HIGH_BITS) >= 0){
                _i_61685 = NewDouble((eudouble)_i_61685);
            }
        }
        else {
            _i_61685 = binary_op_a(PLUS, _i_61685, 1);
        }
        DeRef(_0);
        goto L30; // [2065] 1998
L31: 
        ;
        DeRef(_i_61685);
    }

    /** parser.e:4352		tok = next_token()*/
    _0 = _tok_61204;
    _tok_61204 = _43next_token();
    DeRef(_0);

    /** parser.e:4353		while tok[T_ID] = TYPE or tok[T_ID] = QUALIFIED_TYPE do*/
L34: 
    _2 = (object)SEQ_PTR(_tok_61204);
    _30475 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30475)) {
        _30476 = (_30475 == 504);
    }
    else {
        _30476 = binary_op(EQUALS, _30475, 504);
    }
    _30475 = NOVALUE;
    if (IS_ATOM_INT(_30476)) {
        if (_30476 != 0) {
            goto L35; // [2092] 2113
        }
    }
    else {
        if (DBL_PTR(_30476)->dbl != 0.0) {
            goto L35; // [2092] 2113
        }
    }
    _2 = (object)SEQ_PTR(_tok_61204);
    _30478 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30478)) {
        _30479 = (_30478 == 522);
    }
    else {
        _30479 = binary_op(EQUALS, _30478, 522);
    }
    _30478 = NOVALUE;
    if (_30479 <= 0) {
        if (_30479 == 0) {
            DeRef(_30479);
            _30479 = NOVALUE;
            goto L36; // [2109] 2134
        }
        else {
            if (!IS_ATOM_INT(_30479) && DBL_PTR(_30479)->dbl == 0.0){
                DeRef(_30479);
                _30479 = NOVALUE;
                goto L36; // [2109] 2134
            }
            DeRef(_30479);
            _30479 = NOVALUE;
        }
    }
    DeRef(_30479);
    _30479 = NOVALUE;
L35: 

    /** parser.e:4354			Private_declaration(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_61204);
    _30480 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30480);
    _43Private_declaration(_30480);
    _30480 = NOVALUE;

    /** parser.e:4355			tok = next_token()*/
    _0 = _tok_61204;
    _tok_61204 = _43next_token();
    DeRef(_0);

    /** parser.e:4356		end while*/
    goto L34; // [2131] 2080
L36: 

    /** parser.e:4358		if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto L37; // [2138] 2241

    /** parser.e:4359			if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto L38; // [2145] 2240
    }
    else{
    }

    /** parser.e:4361				emit_op(ERASE_PRIVATE_NAMES)*/
    _45emit_op(88);

    /** parser.e:4362				emit_addr(p)*/
    _45emit_addr(_p_61200);

    /** parser.e:4364				sym = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30483 = (object)*(((s1_ptr)_2)->base + _p_61200);
    _2 = (object)SEQ_PTR(_30483);
    _sym_61202 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_61202)){
        _sym_61202 = (object)DBL_PTR(_sym_61202)->dbl;
    }
    _30483 = NOVALUE;

    /** parser.e:4365				for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30485 = (object)*(((s1_ptr)_2)->base + _p_61200);
    _2 = (object)SEQ_PTR(_30485);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _30486 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _30486 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _30485 = NOVALUE;
    {
        object _i_61732;
        _i_61732 = 1;
L39: 
        if (binary_op_a(GREATER, _i_61732, _30486)){
            goto L3A; // [2190] 2232
        }

        /** parser.e:4366					emit_op(DISPLAY_VAR)*/
        _45emit_op(87);

        /** parser.e:4367					emit_addr(sym)*/
        _45emit_addr(_sym_61202);

        /** parser.e:4368					sym = SymTab[sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _30487 = (object)*(((s1_ptr)_2)->base + _sym_61202);
        _2 = (object)SEQ_PTR(_30487);
        _sym_61202 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_61202)){
            _sym_61202 = (object)DBL_PTR(_sym_61202)->dbl;
        }
        _30487 = NOVALUE;

        /** parser.e:4369				end for*/
        _0 = _i_61732;
        if (IS_ATOM_INT(_i_61732)) {
            _i_61732 = _i_61732 + 1;
            if ((object)((uintptr_t)_i_61732 +(uintptr_t) HIGH_BITS) >= 0){
                _i_61732 = NewDouble((eudouble)_i_61732);
            }
        }
        else {
            _i_61732 = binary_op_a(PLUS, _i_61732, 1);
        }
        DeRef(_0);
        goto L39; // [2227] 2197
L3A: 
        ;
        DeRef(_i_61732);
    }

    /** parser.e:4371				emit_op(UPDATE_GLOBALS)*/
    _45emit_op(89);
L38: 
L37: 

    /** parser.e:4374		putback(tok)*/
    Ref(_tok_61204);
    _43putback(_tok_61204);

    /** parser.e:4377		FuncReturn = FALSE*/
    _43FuncReturn_54960 = _9FALSE_444;

    /** parser.e:4378		if type_enum then*/
    if (_type_enum_61208 == 0)
    {
        goto L3B; // [2257] 2426
    }
    else{
    }

    /** parser.e:4380			stmt_nest += 1*/
    _43stmt_nest_54984 = _43stmt_nest_54984 + 1;

    /** parser.e:4381			tok_match(RETURN)*/
    _43tok_match(413, 0);

    /** parser.e:4382			putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -27;
    ((intptr_t *)_2)[2] = 0;
    _30490 = MAKE_SEQ(_1);
    _43putback(_30490);
    _30490 = NOVALUE;

    /** parser.e:4383			putback({VARIABLE,seq_sym})*/
    Ref(_seq_sym_61209);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _seq_sym_61209;
    _30491 = MAKE_SEQ(_1);
    _43putback(_30491);
    _30491 = NOVALUE;

    /** parser.e:4384			putback({COMMA,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -30;
    ((intptr_t *)_2)[2] = 0;
    _30492 = MAKE_SEQ(_1);
    _43putback(_30492);
    _30492 = NOVALUE;

    /** parser.e:4385			putback(i1_sym)*/
    Ref(_i1_sym_61210);
    _43putback(_i1_sym_61210);

    /** parser.e:4386			putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -26;
    ((intptr_t *)_2)[2] = 0;
    _30493 = MAKE_SEQ(_1);
    _43putback(_30493);
    _30493 = NOVALUE;

    /** parser.e:4387			putback(keyfind("find",-1))*/
    RefDS(_30494);
    DeRef(_31693);
    _31693 = _30494;
    _31694 = _53hashfn(_31693);
    _31693 = NOVALUE;
    RefDS(_30494);
    _30495 = _53keyfind(_30494, -1, _12current_file_no_20226, 0, _31694);
    _31694 = NOVALUE;
    _43putback(_30495);
    _30495 = NOVALUE;

    /** parser.e:4388			if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto L3C; // [2355] 2381

    /** parser.e:4389				if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto L3D; // [2362] 2380
    }
    else{
    }

    /** parser.e:4390					emit_op(ERASE_PRIVATE_NAMES)*/
    _45emit_op(88);

    /** parser.e:4391					emit_addr(CurrentSub)*/
    _45emit_addr(_12CurrentSub_20234);
L3D: 
L3C: 

    /** parser.e:4394			Expr()*/
    _43Expr();

    /** parser.e:4395			FuncReturn = TRUE*/
    _43FuncReturn_54960 = _9TRUE_446;

    /** parser.e:4396			emit_op(RETURNF)*/
    _45emit_op(28);

    /** parser.e:4397			flush_temps()*/
    RefDS(_22015);
    _45flush_temps(_22015);

    /** parser.e:4398			stmt_nest -= 1*/
    _43stmt_nest_54984 = _43stmt_nest_54984 - 1;

    /** parser.e:4399			InitDelete()*/
    _43InitDelete();

    /** parser.e:4400			flush_temps()*/
    RefDS(_22015);
    _45flush_temps(_22015);
    goto L3E; // [2423] 2439
L3B: 

    /** parser.e:4402			Statement_list()*/
    _43Statement_list();

    /** parser.e:4404			tok_match(END)*/
    _43tok_match(402, 0);
L3E: 

    /** parser.e:4408		tok_match(prog_type, END)*/
    _43tok_match(_prog_type_61194, 402);

    /** parser.e:4410		if prog_type != PROCEDURE then*/
    if (_prog_type_61194 == 405)
    goto L3F; // [2451] 2503

    /** parser.e:4411			if not FuncReturn then*/
    if (_43FuncReturn_54960 != 0)
    goto L40; // [2459] 2493

    /** parser.e:4412				if prog_type = FUNCTION then*/
    if (_prog_type_61194 != 406)
    goto L41; // [2466] 2482

    /** parser.e:4413					CompileErr(NO_VALUE_RETURNED_FROM_FUNCTION)*/
    RefDS(_22015);
    _49CompileErr(120, _22015, 0);
    goto L42; // [2479] 2492
L41: 

    /** parser.e:4415					CompileErr(TYPE_MUST_RETURN_TRUE__FALSE_VALUE)*/
    RefDS(_22015);
    _49CompileErr(149, _22015, 0);
L42: 
L40: 

    /** parser.e:4418			emit_op(BADRETURNF) -- function/type shouldn't reach here*/
    _45emit_op(43);
    goto L43; // [2500] 2563
L3F: 

    /** parser.e:4421			StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4422			if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto L44; // [2516] 2540

    /** parser.e:4423				if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto L45; // [2523] 2539
    }
    else{
    }

    /** parser.e:4424					emit_op(ERASE_PRIVATE_NAMES)*/
    _45emit_op(88);

    /** parser.e:4425					emit_addr(p)*/
    _45emit_addr(_p_61200);
L45: 
L44: 

    /** parser.e:4428			emit_op(RETURNP)*/
    _45emit_op(29);

    /** parser.e:4429			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L46; // [2551] 2562
    }
    else{
    }

    /** parser.e:4430				emit_op(BADRETURNF) -- just to mark end of procedure*/
    _45emit_op(43);
L46: 
L43: 

    /** parser.e:4433		Drop_block( pt )*/
    _64Drop_block(_pt_61198);

    /** parser.e:4435		if Strict_Override > 0 then*/
    if (_12Strict_Override_20293 <= 0)
    goto L47; // [2572] 2587

    /** parser.e:4436			Strict_Override -= 1	-- Reset at the end of each routine.*/
    _12Strict_Override_20293 = _12Strict_Override_20293 - 1;
L47: 

    /** parser.e:4439		SymTab[p][S_STACK_SPACE] += temps_allocated + param_num*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61200 + ((s1_ptr)_2)->base);
    _30506 = _53temps_allocated_47334 + _43param_num_54961;
    if ((object)((uintptr_t)_30506 + (uintptr_t)HIGH_BITS) >= 0){
        _30506 = NewDouble((eudouble)_30506);
    }
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_12S_STACK_SPACE_19924)){
        _30507 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_STACK_SPACE_19924)->dbl));
    }
    else{
        _30507 = (object)*(((s1_ptr)_2)->base + _12S_STACK_SPACE_19924);
    }
    _30504 = NOVALUE;
    if (IS_ATOM_INT(_30507) && IS_ATOM_INT(_30506)) {
        _30508 = _30507 + _30506;
        if ((object)((uintptr_t)_30508 + (uintptr_t)HIGH_BITS) >= 0){
            _30508 = NewDouble((eudouble)_30508);
        }
    }
    else {
        _30508 = binary_op(PLUS, _30507, _30506);
    }
    _30507 = NOVALUE;
    DeRef(_30506);
    _30506 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_STACK_SPACE_19924))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_STACK_SPACE_19924)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_STACK_SPACE_19924);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30508;
    if( _1 != _30508 ){
        DeRef(_1);
    }
    _30508 = NOVALUE;
    _30504 = NOVALUE;

    /** parser.e:4440		if temps_allocated + param_num > max_stack_per_call then*/
    _30509 = _53temps_allocated_47334 + _43param_num_54961;
    if ((object)((uintptr_t)_30509 + (uintptr_t)HIGH_BITS) >= 0){
        _30509 = NewDouble((eudouble)_30509);
    }
    if (binary_op_a(LESSEQ, _30509, _12max_stack_per_call_20326)){
        DeRef(_30509);
        _30509 = NOVALUE;
        goto L48; // [2630] 2647
    }
    DeRef(_30509);
    _30509 = NOVALUE;

    /** parser.e:4441			max_stack_per_call = temps_allocated + param_num*/
    _12max_stack_per_call_20326 = _53temps_allocated_47334 + _43param_num_54961;
L48: 

    /** parser.e:4443		param_num = -1*/
    _43param_num_54961 = -1;

    /** parser.e:4445		StraightenBranches()*/
    _43StraightenBranches();

    /** parser.e:4446		check_inline( p )*/
    _66check_inline(_p_61200);

    /** parser.e:4447		param_num = -1*/
    _43param_num_54961 = -1;

    /** parser.e:4448		EnterTopLevel()*/
    _43EnterTopLevel(1);

    /** parser.e:4451		if length( enum_syms ) then*/
    if (IS_SEQUENCE(_enum_syms_61211)){
            _30512 = SEQ_PTR(_enum_syms_61211)->length;
    }
    else {
        _30512 = 1;
    }
    if (_30512 == 0)
    {
        _30512 = NOVALUE;
        goto L49; // [2676] 2763
    }
    else{
        _30512 = NOVALUE;
    }

    /** parser.e:4452			SymTab[p][S_NEXT] = SymTab[enum_syms[$]][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61200 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_enum_syms_61211)){
            _30515 = SEQ_PTR(_enum_syms_61211)->length;
    }
    else {
        _30515 = 1;
    }
    _2 = (object)SEQ_PTR(_enum_syms_61211);
    _30516 = (object)*(((s1_ptr)_2)->base + _30515);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30516)){
        _30517 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30516)->dbl));
    }
    else{
        _30517 = (object)*(((s1_ptr)_2)->base + _30516);
    }
    _2 = (object)SEQ_PTR(_30517);
    _30518 = (object)*(((s1_ptr)_2)->base + 2);
    _30517 = NOVALUE;
    Ref(_30518);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30518;
    if( _1 != _30518 ){
        DeRef(_1);
    }
    _30518 = NOVALUE;
    _30513 = NOVALUE;

    /** parser.e:4453			SymTab[last_sym][S_NEXT] = enum_syms[1]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_53last_sym_46812 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_enum_syms_61211);
    _30521 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30521);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30521;
    if( _1 != _30521 ){
        DeRef(_1);
    }
    _30521 = NOVALUE;
    _30519 = NOVALUE;

    /** parser.e:4454			last_sym = enum_syms[$]*/
    if (IS_SEQUENCE(_enum_syms_61211)){
            _30522 = SEQ_PTR(_enum_syms_61211)->length;
    }
    else {
        _30522 = 1;
    }
    _2 = (object)SEQ_PTR(_enum_syms_61211);
    _53last_sym_46812 = (object)*(((s1_ptr)_2)->base + _30522);
    if (!IS_ATOM_INT(_53last_sym_46812)){
        _53last_sym_46812 = (object)DBL_PTR(_53last_sym_46812)->dbl;
    }

    /** parser.e:4455			SymTab[last_sym][S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_53last_sym_46812 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30524 = NOVALUE;
L49: 

    /** parser.e:4457	end procedure*/
    DeRef(_tok_61204);
    DeRef(_prog_name_61205);
    DeRef(_seq_sym_61209);
    DeRef(_i1_sym_61210);
    DeRef(_enum_syms_61211);
    DeRef(_middle_def_args_61441);
    DeRef(_30306);
    _30306 = NOVALUE;
    _30397 = NOVALUE;
    _30396 = NOVALUE;
    _30332 = NOVALUE;
    _30415 = NOVALUE;
    _30466 = NOVALUE;
    DeRef(_30366);
    _30366 = NOVALUE;
    _30400 = NOVALUE;
    DeRef(_30372);
    _30372 = NOVALUE;
    _30516 = NOVALUE;
    _30420 = NOVALUE;
    DeRef(_30460);
    _30460 = NOVALUE;
    _30486 = NOVALUE;
    DeRef(_30476);
    _30476 = NOVALUE;
    DeRef(_30361);
    _30361 = NOVALUE;
    _30328 = NOVALUE;
    DeRef(_30394);
    _30394 = NOVALUE;
    _30378 = NOVALUE;
    DeRef(_30412);
    _30412 = NOVALUE;
    return;
    ;
}


void _43InitGlobals()
{
    object _30543 = NOVALUE;
    object _30541 = NOVALUE;
    object _30540 = NOVALUE;
    object _30539 = NOVALUE;
    object _30538 = NOVALUE;
    object _30537 = NOVALUE;
    object _30536 = NOVALUE;
    object _30534 = NOVALUE;
    object _30533 = NOVALUE;
    object _30532 = NOVALUE;
    object _30531 = NOVALUE;
    object _30529 = NOVALUE;
    object _30528 = NOVALUE;
    object _30527 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4461		ResetTP()*/
    _61ResetTP();

    /** parser.e:4462		OpTypeCheck = TRUE*/
    _12OpTypeCheck_20297 = _9TRUE_446;

    /** parser.e:4464		OpDefines &= {*/
    _30527 = _40version_major();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30527;
    _30528 = MAKE_SEQ(_1);
    _30527 = NOVALUE;
    _30529 = EPrintf(-9999999, _30526, _30528);
    DeRefDS(_30528);
    _30528 = NOVALUE;
    _30531 = _40version_major();
    _30532 = _40version_minor();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _30531;
    ((intptr_t *)_2)[2] = _30532;
    _30533 = MAKE_SEQ(_1);
    _30532 = NOVALUE;
    _30531 = NOVALUE;
    _30534 = EPrintf(-9999999, _30530, _30533);
    DeRefDS(_30533);
    _30533 = NOVALUE;
    _30536 = _40version_major();
    _30537 = _40version_minor();
    _30538 = _40version_patch();
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30536;
    ((intptr_t*)_2)[2] = _30537;
    ((intptr_t*)_2)[3] = _30538;
    _30539 = MAKE_SEQ(_1);
    _30538 = NOVALUE;
    _30537 = NOVALUE;
    _30536 = NOVALUE;
    _30540 = EPrintf(-9999999, _30535, _30539);
    DeRefDS(_30539);
    _30539 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30529;
    ((intptr_t*)_2)[2] = _30534;
    ((intptr_t*)_2)[3] = _30540;
    _30541 = MAKE_SEQ(_1);
    _30540 = NOVALUE;
    _30534 = NOVALUE;
    _30529 = NOVALUE;
    Concat((object_ptr)&_12OpDefines_20300, _12OpDefines_20300, _30541);
    DeRefDS(_30541);
    _30541 = NOVALUE;

    /** parser.e:4470		OpDefines &= GetPlatformDefines()*/
    _30543 = _44GetPlatformDefines(0);
    if (IS_SEQUENCE(_12OpDefines_20300) && IS_ATOM(_30543)) {
        Ref(_30543);
        Append(&_12OpDefines_20300, _12OpDefines_20300, _30543);
    }
    else if (IS_ATOM(_12OpDefines_20300) && IS_SEQUENCE(_30543)) {
    }
    else {
        Concat((object_ptr)&_12OpDefines_20300, _12OpDefines_20300, _30543);
    }
    DeRef(_30543);
    _30543 = NOVALUE;

    /** parser.e:4472		if repl then*/

    /** parser.e:4476			OpInline = DEFAULT_INLINE*/
    _12OpInline_20301 = 30;

    /** parser.e:4478		OpIndirectInclude = 1*/
    _12OpIndirectInclude_20302 = 1;

    /** parser.e:4479	end procedure*/
    return;
    ;
}


void _43not_supported_compile(object _feature_61902)
{
    object _30545 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4483		CompileErr(MSG_1_IS_NOT_SUPPORTED_IN_EUPHORIA_FOR_2, {feature, version_name})*/
    RefDS(_12version_name_19848);
    RefDS(_feature_61902);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _feature_61902;
    ((intptr_t *)_2)[2] = _12version_name_19848;
    _30545 = MAKE_SEQ(_1);
    _49CompileErr(5, _30545, 0);
    _30545 = NOVALUE;

    /** parser.e:4484	end procedure*/
    DeRefDSi(_feature_61902);
    return;
    ;
}


void _43SetWith(object _on_off_61909)
{
    object _option_61910 = NOVALUE;
    object _idx_61911 = NOVALUE;
    object _reset_flags_61912 = NOVALUE;
    object _tok_61964 = NOVALUE;
    object _good_sofar_62014 = NOVALUE;
    object _tok_62017 = NOVALUE;
    object _warning_extra_62019 = NOVALUE;
    object _endlist_62112 = NOVALUE;
    object _tok_62261 = NOVALUE;
    object _30692 = NOVALUE;
    object _30691 = NOVALUE;
    object _30690 = NOVALUE;
    object _30689 = NOVALUE;
    object _30688 = NOVALUE;
    object _30685 = NOVALUE;
    object _30684 = NOVALUE;
    object _30683 = NOVALUE;
    object _30681 = NOVALUE;
    object _30679 = NOVALUE;
    object _30678 = NOVALUE;
    object _30677 = NOVALUE;
    object _30674 = NOVALUE;
    object _30672 = NOVALUE;
    object _30671 = NOVALUE;
    object _30670 = NOVALUE;
    object _30669 = NOVALUE;
    object _30668 = NOVALUE;
    object _30664 = NOVALUE;
    object _30662 = NOVALUE;
    object _30660 = NOVALUE;
    object _30656 = NOVALUE;
    object _30651 = NOVALUE;
    object _30650 = NOVALUE;
    object _30645 = NOVALUE;
    object _30644 = NOVALUE;
    object _30643 = NOVALUE;
    object _30642 = NOVALUE;
    object _30641 = NOVALUE;
    object _30640 = NOVALUE;
    object _30639 = NOVALUE;
    object _30638 = NOVALUE;
    object _30637 = NOVALUE;
    object _30636 = NOVALUE;
    object _30634 = NOVALUE;
    object _30633 = NOVALUE;
    object _30631 = NOVALUE;
    object _30630 = NOVALUE;
    object _30629 = NOVALUE;
    object _30627 = NOVALUE;
    object _30626 = NOVALUE;
    object _30624 = NOVALUE;
    object _30621 = NOVALUE;
    object _30619 = NOVALUE;
    object _30616 = NOVALUE;
    object _30615 = NOVALUE;
    object _30614 = NOVALUE;
    object _30613 = NOVALUE;
    object _30606 = NOVALUE;
    object _30605 = NOVALUE;
    object _30603 = NOVALUE;
    object _30600 = NOVALUE;
    object _30599 = NOVALUE;
    object _30597 = NOVALUE;
    object _30596 = NOVALUE;
    object _30595 = NOVALUE;
    object _30594 = NOVALUE;
    object _30593 = NOVALUE;
    object _30592 = NOVALUE;
    object _30589 = NOVALUE;
    object _30588 = NOVALUE;
    object _30587 = NOVALUE;
    object _30586 = NOVALUE;
    object _30585 = NOVALUE;
    object _30584 = NOVALUE;
    object _30581 = NOVALUE;
    object _30580 = NOVALUE;
    object _30579 = NOVALUE;
    object _30577 = NOVALUE;
    object _30574 = NOVALUE;
    object _30572 = NOVALUE;
    object _30571 = NOVALUE;
    object _30569 = NOVALUE;
    object _30568 = NOVALUE;
    object _30567 = NOVALUE;
    object _30566 = NOVALUE;
    object _30565 = NOVALUE;
    object _30564 = NOVALUE;
    object _30562 = NOVALUE;
    object _30559 = NOVALUE;
    object _30558 = NOVALUE;
    object _30557 = NOVALUE;
    object _30556 = NOVALUE;
    object _30554 = NOVALUE;
    object _30553 = NOVALUE;
    object _30552 = NOVALUE;
    object _30551 = NOVALUE;
    object _30549 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4490		integer reset_flags = 1*/
    _reset_flags_61912 = 1;

    /** parser.e:4493		option = StringToken("&+=")*/
    RefDS(_30546);
    _0 = _option_61910;
    _option_61910 = _61StringToken(_30546);
    DeRef(_0);

    /** parser.e:4495		if equal(option, "type_check") then*/
    if (_option_61910 == _30548)
    _30549 = 1;
    else if (IS_ATOM_INT(_option_61910) && IS_ATOM_INT(_30548))
    _30549 = 0;
    else
    _30549 = (compare(_option_61910, _30548) == 0);
    if (_30549 == 0)
    {
        _30549 = NOVALUE;
        goto L1; // [22] 35
    }
    else{
        _30549 = NOVALUE;
    }

    /** parser.e:4496			OpTypeCheck = on_off*/
    _12OpTypeCheck_20297 = _on_off_61909;
    goto L2; // [32] 1546
L1: 

    /** parser.e:4498		elsif equal(option, "profile") then*/
    if (_option_61910 == _30550)
    _30551 = 1;
    else if (IS_ATOM_INT(_option_61910) && IS_ATOM_INT(_30550))
    _30551 = 0;
    else
    _30551 = (compare(_option_61910, _30550) == 0);
    if (_30551 == 0)
    {
        _30551 = NOVALUE;
        goto L3; // [41] 121
    }
    else{
        _30551 = NOVALUE;
    }

    /** parser.e:4499			if not TRANSLATE and not BIND then*/
    _30552 = (_12TRANSLATE_19834 == 0);
    if (_30552 == 0) {
        goto L2; // [51] 1546
    }
    _30554 = (_12BIND_19837 == 0);
    if (_30554 == 0)
    {
        DeRef(_30554);
        _30554 = NOVALUE;
        goto L2; // [61] 1546
    }
    else{
        DeRef(_30554);
        _30554 = NOVALUE;
    }

    /** parser.e:4500				OpProfileStatement = on_off*/
    _12OpProfileStatement_20298 = _on_off_61909;

    /** parser.e:4501				if OpProfileStatement then*/
    if (_12OpProfileStatement_20298 == 0)
    {
        goto L2; // [75] 1546
    }
    else{
    }

    /** parser.e:4502					if AnyTimeProfile then*/
    if (_13AnyTimeProfile_11339 == 0)
    {
        goto L4; // [82] 106
    }
    else{
    }

    /** parser.e:4503						Warning(224, mixed_profile_warning_flag)*/
    RefDS(_22015);
    _49Warning(224, 1024, _22015);

    /** parser.e:4504						OpProfileStatement = FALSE*/
    _12OpProfileStatement_20298 = _9FALSE_444;
    goto L2; // [103] 1546
L4: 

    /** parser.e:4506						AnyStatementProfile = TRUE*/
    _13AnyStatementProfile_11340 = _9TRUE_446;
    goto L2; // [118] 1546
L3: 

    /** parser.e:4511		elsif equal(option, "profile_time") then*/
    if (_option_61910 == _30555)
    _30556 = 1;
    else if (IS_ATOM_INT(_option_61910) && IS_ATOM_INT(_30555))
    _30556 = 0;
    else
    _30556 = (compare(_option_61910, _30555) == 0);
    if (_30556 == 0)
    {
        _30556 = NOVALUE;
        goto L5; // [127] 364
    }
    else{
        _30556 = NOVALUE;
    }

    /** parser.e:4512			if not TRANSLATE and not BIND then*/
    _30557 = (_12TRANSLATE_19834 == 0);
    if (_30557 == 0) {
        goto L2; // [137] 1546
    }
    _30559 = (_12BIND_19837 == 0);
    if (_30559 == 0)
    {
        DeRef(_30559);
        _30559 = NOVALUE;
        goto L2; // [147] 1546
    }
    else{
        DeRef(_30559);
        _30559 = NOVALUE;
    }

    /** parser.e:4513				if not IWINDOWS then*/

    /** parser.e:4514					if on_off then*/
    if (_on_off_61909 == 0)
    {
        goto L6; // [159] 168
    }
    else{
    }

    /** parser.e:4515						not_supported_compile("profile_time")*/
    RefDS(_30555);
    _43not_supported_compile(_30555);
L6: 

    /** parser.e:4518				OpProfileTime = on_off*/
    _12OpProfileTime_20299 = _on_off_61909;

    /** parser.e:4519				if OpProfileTime then*/
    if (_12OpProfileTime_20299 == 0)
    {
        goto L7; // [180] 358
    }
    else{
    }

    /** parser.e:4520					if AnyStatementProfile then*/
    if (_13AnyStatementProfile_11340 == 0)
    {
        goto L8; // [187] 209
    }
    else{
    }

    /** parser.e:4521						Warning(224,mixed_profile_warning_flag)*/
    RefDS(_22015);
    _49Warning(224, 1024, _22015);

    /** parser.e:4522						OpProfileTime = FALSE*/
    _12OpProfileTime_20299 = _9FALSE_444;
L8: 

    /** parser.e:4524					token tok = next_token()*/
    _0 = _tok_61964;
    _tok_61964 = _43next_token();
    DeRef(_0);

    /** parser.e:4525					if tok[T_ID] = ATOM then*/
    _2 = (object)SEQ_PTR(_tok_61964);
    _30562 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30562, 502)){
        _30562 = NOVALUE;
        goto L9; // [224] 319
    }
    _30562 = NOVALUE;

    /** parser.e:4526						if is_integer(SymTab[tok[T_SYM]][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_tok_61964);
    _30564 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30564)){
        _30565 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30564)->dbl));
    }
    else{
        _30565 = (object)*(((s1_ptr)_2)->base + _30564);
    }
    _2 = (object)SEQ_PTR(_30565);
    _30566 = (object)*(((s1_ptr)_2)->base + 1);
    _30565 = NOVALUE;
    Ref(_30566);
    _30567 = _12is_integer(_30566);
    _30566 = NOVALUE;
    if (_30567 == 0) {
        DeRef(_30567);
        _30567 = NOVALUE;
        goto LA; // [252] 280
    }
    else {
        if (!IS_ATOM_INT(_30567) && DBL_PTR(_30567)->dbl == 0.0){
            DeRef(_30567);
            _30567 = NOVALUE;
            goto LA; // [252] 280
        }
        DeRef(_30567);
        _30567 = NOVALUE;
    }
    DeRef(_30567);
    _30567 = NOVALUE;

    /** parser.e:4527							sample_size = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_61964);
    _30568 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30568)){
        _30569 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30568)->dbl));
    }
    else{
        _30569 = (object)*(((s1_ptr)_2)->base + _30568);
    }
    _2 = (object)SEQ_PTR(_30569);
    _12sample_size_20327 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_12sample_size_20327)){
        _12sample_size_20327 = (object)DBL_PTR(_12sample_size_20327)->dbl;
    }
    _30569 = NOVALUE;
    goto LB; // [277] 288
LA: 

    /** parser.e:4529							sample_size = -1*/
    _12sample_size_20327 = -1;
LB: 

    /** parser.e:4531						if sample_size < 1 and OpProfileTime then*/
    _30571 = (_12sample_size_20327 < 1);
    if (_30571 == 0) {
        goto LC; // [296] 332
    }
    if (_12OpProfileTime_20299 == 0)
    {
        goto LC; // [303] 332
    }
    else{
    }

    /** parser.e:4532							CompileErr(SAMPLE_SIZE_MUST_BE_A_POSITIVE_INTEGER)*/
    RefDS(_22015);
    _49CompileErr(136, _22015, 0);
    goto LC; // [316] 332
L9: 

    /** parser.e:4535						putback(tok)*/
    Ref(_tok_61964);
    _43putback(_tok_61964);

    /** parser.e:4536						sample_size = DEFAULT_SAMPLE_SIZE*/
    _12sample_size_20327 = 25000;
LC: 

    /** parser.e:4538					if OpProfileTime then*/
    if (_12OpProfileTime_20299 == 0)
    {
        goto LD; // [336] 357
    }
    else{
    }

    /** parser.e:4539						if IWINDOWS then*/
LD: 
L7: 
    DeRef(_tok_61964);
    _tok_61964 = NOVALUE;
    goto L2; // [361] 1546
L5: 

    /** parser.e:4546		elsif equal(option, "trace") then*/
    if (_option_61910 == _30573)
    _30574 = 1;
    else if (IS_ATOM_INT(_option_61910) && IS_ATOM_INT(_30573))
    _30574 = 0;
    else
    _30574 = (compare(_option_61910, _30573) == 0);
    if (_30574 == 0)
    {
        _30574 = NOVALUE;
        goto LE; // [370] 391
    }
    else{
        _30574 = NOVALUE;
    }

    /** parser.e:4547			if not BIND then*/
    if (_12BIND_19837 != 0)
    goto L2; // [377] 1546

    /** parser.e:4548				OpTrace = on_off*/
    _12OpTrace_20296 = _on_off_61909;
    goto L2; // [388] 1546
LE: 

    /** parser.e:4551		elsif equal(option, "warning") then*/
    if (_option_61910 == _30576)
    _30577 = 1;
    else if (IS_ATOM_INT(_option_61910) && IS_ATOM_INT(_30576))
    _30577 = 0;
    else
    _30577 = (compare(_option_61910, _30576) == 0);
    if (_30577 == 0)
    {
        _30577 = NOVALUE;
        goto LF; // [397] 1243
    }
    else{
        _30577 = NOVALUE;
    }

    /** parser.e:4552			integer good_sofar = line_number*/
    _good_sofar_62014 = _12line_number_20227;

    /** parser.e:4553			reset_flags = 1*/
    _reset_flags_61912 = 1;

    /** parser.e:4554			token tok = next_token()*/
    _0 = _tok_62017;
    _tok_62017 = _43next_token();
    DeRef(_0);

    /** parser.e:4555			integer warning_extra = 1*/
    _warning_extra_62019 = 1;

    /** parser.e:4556			if find(tok[T_ID], {CONCAT_EQUALS, PLUS_EQUALS}) != 0 then*/
    _2 = (object)SEQ_PTR(_tok_62017);
    _30579 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 519;
    ((intptr_t *)_2)[2] = 515;
    _30580 = MAKE_SEQ(_1);
    _30581 = find_from(_30579, _30580, 1);
    _30579 = NOVALUE;
    DeRefDS(_30580);
    _30580 = NOVALUE;
    if (_30581 == 0)
    goto L10; // [445] 506

    /** parser.e:4557				tok = next_token()*/
    _0 = _tok_62017;
    _tok_62017 = _43next_token();
    DeRef(_0);

    /** parser.e:4558				if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_62017);
    _30584 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30584)) {
        _30585 = (_30584 != -24);
    }
    else {
        _30585 = binary_op(NOTEQ, _30584, -24);
    }
    _30584 = NOVALUE;
    if (IS_ATOM_INT(_30585)) {
        if (_30585 == 0) {
            goto L11; // [468] 498
        }
    }
    else {
        if (DBL_PTR(_30585)->dbl == 0.0) {
            goto L11; // [468] 498
        }
    }
    _2 = (object)SEQ_PTR(_tok_62017);
    _30587 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30587)) {
        _30588 = (_30587 != -26);
    }
    else {
        _30588 = binary_op(NOTEQ, _30587, -26);
    }
    _30587 = NOVALUE;
    if (_30588 == 0) {
        DeRef(_30588);
        _30588 = NOVALUE;
        goto L11; // [485] 498
    }
    else {
        if (!IS_ATOM_INT(_30588) && DBL_PTR(_30588)->dbl == 0.0){
            DeRef(_30588);
            _30588 = NOVALUE;
            goto L11; // [485] 498
        }
        DeRef(_30588);
        _30588 = NOVALUE;
    }
    DeRef(_30588);
    _30588 = NOVALUE;

    /** parser.e:4559					CompileErr(WARNING_NAMES_MUST_BE_ENCLOSED_IN)*/
    RefDS(_22015);
    _49CompileErr(160, _22015, 0);
L11: 

    /** parser.e:4561				reset_flags = 0*/
    _reset_flags_61912 = 0;
    goto L12; // [503] 734
L10: 

    /** parser.e:4562			elsif tok[T_ID] = EQUALS then*/
    _2 = (object)SEQ_PTR(_tok_62017);
    _30589 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30589, 3)){
        _30589 = NOVALUE;
        goto L13; // [516] 577
    }
    _30589 = NOVALUE;

    /** parser.e:4563				tok = next_token()*/
    _0 = _tok_62017;
    _tok_62017 = _43next_token();
    DeRef(_0);

    /** parser.e:4564				if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_62017);
    _30592 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30592)) {
        _30593 = (_30592 != -24);
    }
    else {
        _30593 = binary_op(NOTEQ, _30592, -24);
    }
    _30592 = NOVALUE;
    if (IS_ATOM_INT(_30593)) {
        if (_30593 == 0) {
            goto L14; // [539] 569
        }
    }
    else {
        if (DBL_PTR(_30593)->dbl == 0.0) {
            goto L14; // [539] 569
        }
    }
    _2 = (object)SEQ_PTR(_tok_62017);
    _30595 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30595)) {
        _30596 = (_30595 != -26);
    }
    else {
        _30596 = binary_op(NOTEQ, _30595, -26);
    }
    _30595 = NOVALUE;
    if (_30596 == 0) {
        DeRef(_30596);
        _30596 = NOVALUE;
        goto L14; // [556] 569
    }
    else {
        if (!IS_ATOM_INT(_30596) && DBL_PTR(_30596)->dbl == 0.0){
            DeRef(_30596);
            _30596 = NOVALUE;
            goto L14; // [556] 569
        }
        DeRef(_30596);
        _30596 = NOVALUE;
    }
    DeRef(_30596);
    _30596 = NOVALUE;

    /** parser.e:4565					CompileErr(WARNING_NAMES_MUST_BE_ENCLOSED_IN)*/
    RefDS(_22015);
    _49CompileErr(160, _22015, 0);
L14: 

    /** parser.e:4567				reset_flags = 1*/
    _reset_flags_61912 = 1;
    goto L12; // [574] 734
L13: 

    /** parser.e:4568			elsif tok[T_ID] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_62017);
    _30597 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30597, -100)){
        _30597 = NOVALUE;
        goto L15; // [587] 733
    }
    _30597 = NOVALUE;

    /** parser.e:4569				option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (object)SEQ_PTR(_tok_62017);
    _30599 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30599)){
        _30600 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30599)->dbl));
    }
    else{
        _30600 = (object)*(((s1_ptr)_2)->base + _30599);
    }
    DeRef(_option_61910);
    _2 = (object)SEQ_PTR(_30600);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _option_61910 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _option_61910 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_option_61910);
    _30600 = NOVALUE;

    /** parser.e:4570				if equal(option, "save") then*/
    if (_option_61910 == _30602)
    _30603 = 1;
    else if (IS_ATOM_INT(_option_61910) && IS_ATOM_INT(_30602))
    _30603 = 0;
    else
    _30603 = (compare(_option_61910, _30602) == 0);
    if (_30603 == 0)
    {
        _30603 = NOVALUE;
        goto L16; // [619] 643
    }
    else{
        _30603 = NOVALUE;
    }

    /** parser.e:4571					prev_OpWarning = OpWarning*/
    _12prev_OpWarning_20295 = _12OpWarning_20294;

    /** parser.e:4572					warning_extra = FALSE*/
    _warning_extra_62019 = _9FALSE_444;
    goto L17; // [640] 732
L16: 

    /** parser.e:4574				elsif equal(option, "restore") then*/
    if (_option_61910 == _30604)
    _30605 = 1;
    else if (IS_ATOM_INT(_option_61910) && IS_ATOM_INT(_30604))
    _30605 = 0;
    else
    _30605 = (compare(_option_61910, _30604) == 0);
    if (_30605 == 0)
    {
        _30605 = NOVALUE;
        goto L18; // [649] 673
    }
    else{
        _30605 = NOVALUE;
    }

    /** parser.e:4575					OpWarning = prev_OpWarning*/
    _12OpWarning_20294 = _12prev_OpWarning_20295;

    /** parser.e:4576					warning_extra = FALSE*/
    _warning_extra_62019 = _9FALSE_444;
    goto L17; // [670] 732
L18: 

    /** parser.e:4578				elsif equal(option, "strict") then*/
    if (_option_61910 == _25490)
    _30606 = 1;
    else if (IS_ATOM_INT(_option_61910) && IS_ATOM_INT(_25490))
    _30606 = 0;
    else
    _30606 = (compare(_option_61910, _25490) == 0);
    if (_30606 == 0)
    {
        _30606 = NOVALUE;
        goto L19; // [679] 731
    }
    else{
        _30606 = NOVALUE;
    }

    /** parser.e:4579					if on_off = 0 then*/
    if (_on_off_61909 != 0)
    goto L1A; // [684] 701

    /** parser.e:4580						Strict_Override += 1*/
    _12Strict_Override_20293 = _12Strict_Override_20293 + 1;
    goto L1B; // [698] 721
L1A: 

    /** parser.e:4581					elsif Strict_Override > 0 then*/
    if (_12Strict_Override_20293 <= 0)
    goto L1C; // [705] 720

    /** parser.e:4582						Strict_Override -= 1*/
    _12Strict_Override_20293 = _12Strict_Override_20293 - 1;
L1C: 
L1B: 

    /** parser.e:4584					warning_extra = FALSE*/
    _warning_extra_62019 = _9FALSE_444;
L19: 
L17: 
L15: 
L12: 

    /** parser.e:4588			if warning_extra = TRUE then*/
    if (_warning_extra_62019 != _9TRUE_446)
    goto L1D; // [738] 1238

    /** parser.e:4589				if reset_flags then*/
    if (_reset_flags_61912 == 0)
    {
        goto L1E; // [744] 776
    }
    else{
    }

    /** parser.e:4590					if on_off = 0 then*/
    if (_on_off_61909 != 0)
    goto L1F; // [749] 765

    /** parser.e:4591						OpWarning = no_warning_flag*/
    _12OpWarning_20294 = 0;
    goto L20; // [762] 775
L1F: 

    /** parser.e:4593						OpWarning = all_warning_flag*/
    _12OpWarning_20294 = 32767;
L20: 
L1E: 

    /** parser.e:4597				if find(tok[T_ID], {LEFT_BRACE, LEFT_ROUND}) then*/
    _2 = (object)SEQ_PTR(_tok_62017);
    _30613 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -24;
    ((intptr_t *)_2)[2] = -26;
    _30614 = MAKE_SEQ(_1);
    _30615 = find_from(_30613, _30614, 1);
    _30613 = NOVALUE;
    DeRefDS(_30614);
    _30614 = NOVALUE;
    if (_30615 == 0)
    {
        _30615 = NOVALUE;
        goto L21; // [797] 1231
    }
    else{
        _30615 = NOVALUE;
    }

    /** parser.e:4598					integer endlist*/

    /** parser.e:4599					if tok[T_ID] = LEFT_BRACE then*/
    _2 = (object)SEQ_PTR(_tok_62017);
    _30616 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30616, -24)){
        _30616 = NOVALUE;
        goto L22; // [812] 828
    }
    _30616 = NOVALUE;

    /** parser.e:4600						endlist = RIGHT_BRACE*/
    _endlist_62112 = -25;
    goto L23; // [825] 838
L22: 

    /** parser.e:4602						endlist = RIGHT_ROUND*/
    _endlist_62112 = -27;
L23: 

    /** parser.e:4604					tok = next_token()*/
    _0 = _tok_62017;
    _tok_62017 = _43next_token();
    DeRef(_0);

    /** parser.e:4605					while tok[T_ID] != endlist do*/
L24: 
    _2 = (object)SEQ_PTR(_tok_62017);
    _30619 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30619, _endlist_62112)){
        _30619 = NOVALUE;
        goto L25; // [856] 1226
    }
    _30619 = NOVALUE;

    /** parser.e:4606						if tok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok_62017);
    _30621 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30621, -30)){
        _30621 = NOVALUE;
        goto L26; // [870] 884
    }
    _30621 = NOVALUE;

    /** parser.e:4607							tok = next_token()*/
    _0 = _tok_62017;
    _tok_62017 = _43next_token();
    DeRef(_0);

    /** parser.e:4608							continue*/
    goto L24; // [881] 848
L26: 

    /** parser.e:4611						if tok[T_ID] = STRING then*/
    _2 = (object)SEQ_PTR(_tok_62017);
    _30624 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30624, 503)){
        _30624 = NOVALUE;
        goto L27; // [894] 923
    }
    _30624 = NOVALUE;

    /** parser.e:4612							option = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_62017);
    _30626 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30626)){
        _30627 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30626)->dbl));
    }
    else{
        _30627 = (object)*(((s1_ptr)_2)->base + _30626);
    }
    DeRef(_option_61910);
    _2 = (object)SEQ_PTR(_30627);
    _option_61910 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_option_61910);
    _30627 = NOVALUE;
    goto L28; // [920] 1071
L27: 

    /** parser.e:4613						elsif length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (object)SEQ_PTR(_tok_62017);
    _30629 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30629)){
        _30630 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30629)->dbl));
    }
    else{
        _30630 = (object)*(((s1_ptr)_2)->base + _30629);
    }
    if (IS_SEQUENCE(_30630)){
            _30631 = SEQ_PTR(_30630)->length;
    }
    else {
        _30631 = 1;
    }
    _30630 = NOVALUE;
    if (binary_op_a(LESS, _30631, _12S_NAME_19864)){
        _30631 = NOVALUE;
        goto L29; // [942] 971
    }
    _30631 = NOVALUE;

    /** parser.e:4614							option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (object)SEQ_PTR(_tok_62017);
    _30633 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30633)){
        _30634 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30633)->dbl));
    }
    else{
        _30634 = (object)*(((s1_ptr)_2)->base + _30633);
    }
    DeRef(_option_61910);
    _2 = (object)SEQ_PTR(_30634);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _option_61910 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _option_61910 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_option_61910);
    _30634 = NOVALUE;
    goto L28; // [968] 1071
L29: 

    /** parser.e:4616							option = ""*/
    RefDS(_22015);
    DeRef(_option_61910);
    _option_61910 = _22015;

    /** parser.e:4617							for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_62keylist_23148)){
            _30636 = SEQ_PTR(_62keylist_23148)->length;
    }
    else {
        _30636 = 1;
    }
    {
        object _k_62159;
        _k_62159 = 1;
L2A: 
        if (_k_62159 > _30636){
            goto L2B; // [985] 1070
        }

        /** parser.e:4618								if keylist[k][S_SCOPE] = SC_KEYWORD and*/
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _30637 = (object)*(((s1_ptr)_2)->base + _k_62159);
        _2 = (object)SEQ_PTR(_30637);
        _30638 = (object)*(((s1_ptr)_2)->base + 4);
        _30637 = NOVALUE;
        if (IS_ATOM_INT(_30638)) {
            _30639 = (_30638 == 8);
        }
        else {
            _30639 = binary_op(EQUALS, _30638, 8);
        }
        _30638 = NOVALUE;
        if (IS_ATOM_INT(_30639)) {
            if (_30639 == 0) {
                goto L2C; // [1012] 1063
            }
        }
        else {
            if (DBL_PTR(_30639)->dbl == 0.0) {
                goto L2C; // [1012] 1063
            }
        }
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _30641 = (object)*(((s1_ptr)_2)->base + _k_62159);
        _2 = (object)SEQ_PTR(_30641);
        if (!IS_ATOM_INT(_12S_TOKEN_19869)){
            _30642 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
        }
        else{
            _30642 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
        }
        _30641 = NOVALUE;
        _2 = (object)SEQ_PTR(_tok_62017);
        _30643 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_30642) && IS_ATOM_INT(_30643)) {
            _30644 = (_30642 == _30643);
        }
        else {
            _30644 = binary_op(EQUALS, _30642, _30643);
        }
        _30642 = NOVALUE;
        _30643 = NOVALUE;
        if (_30644 == 0) {
            DeRef(_30644);
            _30644 = NOVALUE;
            goto L2C; // [1039] 1063
        }
        else {
            if (!IS_ATOM_INT(_30644) && DBL_PTR(_30644)->dbl == 0.0){
                DeRef(_30644);
                _30644 = NOVALUE;
                goto L2C; // [1039] 1063
            }
            DeRef(_30644);
            _30644 = NOVALUE;
        }
        DeRef(_30644);
        _30644 = NOVALUE;

        /** parser.e:4621										option = keylist[k][S_NAME]*/
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _30645 = (object)*(((s1_ptr)_2)->base + _k_62159);
        DeRef(_option_61910);
        _2 = (object)SEQ_PTR(_30645);
        if (!IS_ATOM_INT(_12S_NAME_19864)){
            _option_61910 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
        }
        else{
            _option_61910 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
        }
        Ref(_option_61910);
        _30645 = NOVALUE;

        /** parser.e:4622										exit*/
        goto L2B; // [1060] 1070
L2C: 

        /** parser.e:4624							end for*/
        _k_62159 = _k_62159 + 1;
        goto L2A; // [1065] 992
L2B: 
        ;
    }
L28: 

    /** parser.e:4628						idx = find(option, warning_names)*/
    _idx_61911 = find_from(_option_61910, _12warning_names_20271, 1);

    /** parser.e:4629						if idx = 0 then*/
    if (_idx_61911 != 0)
    goto L2D; // [1082] 1137

    /** parser.e:4630		 					if good_sofar != line_number then*/
    if (_good_sofar_62014 == _12line_number_20227)
    goto L2E; // [1090] 1104

    /** parser.e:4631	 							CompileErr(TOO_MANY_WARNING_ERRORS)*/
    RefDS(_22015);
    _49CompileErr(147, _22015, 0);
L2E: 

    /** parser.e:4633							Warning(225, 0,*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _30650 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_30650);
    ((intptr_t*)_2)[1] = _30650;
    ((intptr_t*)_2)[2] = _12line_number_20227;
    RefDS(_option_61910);
    ((intptr_t*)_2)[3] = _option_61910;
    _30651 = MAKE_SEQ(_1);
    _30650 = NOVALUE;
    _49Warning(225, 0, _30651);
    _30651 = NOVALUE;

    /** parser.e:4635							tok = next_token()*/
    _0 = _tok_62017;
    _tok_62017 = _43next_token();
    DeRef(_0);

    /** parser.e:4636							continue*/
    goto L24; // [1134] 848
L2D: 

    /** parser.e:4639						idx = warning_flags[idx]*/
    _2 = (object)SEQ_PTR(_12warning_flags_20269);
    _idx_61911 = (object)*(((s1_ptr)_2)->base + _idx_61911);

    /** parser.e:4640						if idx = 0 then*/
    if (_idx_61911 != 0)
    goto L2F; // [1149] 1183

    /** parser.e:4641							if on_off then*/
    if (_on_off_61909 == 0)
    {
        goto L30; // [1155] 1170
    }
    else{
    }

    /** parser.e:4642								OpWarning = no_warning_flag*/
    _12OpWarning_20294 = 0;
    goto L31; // [1167] 1216
L30: 

    /** parser.e:4644							    OpWarning = all_warning_flag*/
    _12OpWarning_20294 = 32767;
    goto L31; // [1180] 1216
L2F: 

    /** parser.e:4647							if on_off then*/
    if (_on_off_61909 == 0)
    {
        goto L32; // [1185] 1201
    }
    else{
    }

    /** parser.e:4648								OpWarning = or_bits(OpWarning, idx)*/
    {uintptr_t tu;
         tu = (uintptr_t)_12OpWarning_20294 | (uintptr_t)_idx_61911;
         _12OpWarning_20294 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_12OpWarning_20294)) {
        _1 = (object)(DBL_PTR(_12OpWarning_20294)->dbl);
        DeRefDS(_12OpWarning_20294);
        _12OpWarning_20294 = _1;
    }
    goto L33; // [1198] 1215
L32: 

    /** parser.e:4650							    OpWarning = and_bits(OpWarning, not_bits(idx))*/
    _30656 = not_bits(_idx_61911);
    if (IS_ATOM_INT(_30656)) {
        {uintptr_t tu;
             tu = (uintptr_t)_12OpWarning_20294 & (uintptr_t)_30656;
             _12OpWarning_20294 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)_12OpWarning_20294;
        _12OpWarning_20294 = Dand_bits(&temp_d, DBL_PTR(_30656));
    }
    DeRef(_30656);
    _30656 = NOVALUE;
    if (!IS_ATOM_INT(_12OpWarning_20294)) {
        _1 = (object)(DBL_PTR(_12OpWarning_20294)->dbl);
        DeRefDS(_12OpWarning_20294);
        _12OpWarning_20294 = _1;
    }
L33: 
L31: 

    /** parser.e:4653						tok = next_token()*/
    _0 = _tok_62017;
    _tok_62017 = _43next_token();
    DeRef(_0);

    /** parser.e:4654					end while*/
    goto L24; // [1223] 848
L25: 
    goto L34; // [1228] 1237
L21: 

    /** parser.e:4656					putback(tok)*/
    Ref(_tok_62017);
    _43putback(_tok_62017);
L34: 
L1D: 
    DeRef(_tok_62017);
    _tok_62017 = NOVALUE;
    goto L2; // [1240] 1546
LF: 

    /** parser.e:4659		elsif equal(option, "define") then*/
    if (_option_61910 == _30659)
    _30660 = 1;
    else if (IS_ATOM_INT(_option_61910) && IS_ATOM_INT(_30659))
    _30660 = 0;
    else
    _30660 = (compare(_option_61910, _30659) == 0);
    if (_30660 == 0)
    {
        _30660 = NOVALUE;
        goto L35; // [1249] 1376
    }
    else{
        _30660 = NOVALUE;
    }

    /** parser.e:4660			option = StringToken()*/
    RefDS(_5);
    _0 = _option_61910;
    _option_61910 = _61StringToken(_5);
    DeRefDS(_0);

    /** parser.e:4661			if length(option) = 0 then*/
    if (IS_SEQUENCE(_option_61910)){
            _30662 = SEQ_PTR(_option_61910)->length;
    }
    else {
        _30662 = 1;
    }
    if (_30662 != 0)
    goto L36; // [1265] 1281

    /** parser.e:4662				CompileErr(EXPECTING_TO_FIND_A_WORD_TO_DEFINE_BUT_REACHED_END_OF_LINE_FIRST)*/
    RefDS(_22015);
    _49CompileErr(81, _22015, 0);
    goto L37; // [1278] 1301
L36: 

    /** parser.e:4664			elsif not t_identifier(option) then*/
    RefDS(_option_61910);
    _30664 = _9t_identifier(_option_61910);
    if (IS_ATOM_INT(_30664)) {
        if (_30664 != 0){
            DeRef(_30664);
            _30664 = NOVALUE;
            goto L38; // [1287] 1300
        }
    }
    else {
        if (DBL_PTR(_30664)->dbl != 0.0){
            DeRef(_30664);
            _30664 = NOVALUE;
            goto L38; // [1287] 1300
        }
    }
    DeRef(_30664);
    _30664 = NOVALUE;

    /** parser.e:4665				CompileErr(DEFINED_WORD_MUST_ONLY_HAVE_ALPHANUMERICS_AND_UNDERSCORE)*/
    RefDS(_22015);
    _49CompileErr(61, _22015, 0);
L38: 
L37: 

    /** parser.e:4668			if on_off = 0 then*/
    if (_on_off_61909 != 0)
    goto L39; // [1303] 1358

    /** parser.e:4669				idx = find(option, OpDefines)*/
    _idx_61911 = find_from(_option_61910, _12OpDefines_20300, 1);

    /** parser.e:4670				if idx then*/
    if (_idx_61911 == 0)
    {
        goto L2; // [1318] 1546
    }
    else{
    }

    /** parser.e:4671					OpDefines = OpDefines[1..idx-1]&OpDefines[idx+1..$]*/
    _30668 = _idx_61911 - 1;
    rhs_slice_target = (object_ptr)&_30669;
    RHS_Slice(_12OpDefines_20300, 1, _30668);
    _30670 = _idx_61911 + 1;
    if (IS_SEQUENCE(_12OpDefines_20300)){
            _30671 = SEQ_PTR(_12OpDefines_20300)->length;
    }
    else {
        _30671 = 1;
    }
    rhs_slice_target = (object_ptr)&_30672;
    RHS_Slice(_12OpDefines_20300, _30670, _30671);
    Concat((object_ptr)&_12OpDefines_20300, _30669, _30672);
    DeRefDS(_30669);
    _30669 = NOVALUE;
    DeRef(_30669);
    _30669 = NOVALUE;
    DeRefDS(_30672);
    _30672 = NOVALUE;
    goto L2; // [1355] 1546
L39: 

    /** parser.e:4674				OpDefines &= {option}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_option_61910);
    ((intptr_t*)_2)[1] = _option_61910;
    _30674 = MAKE_SEQ(_1);
    Concat((object_ptr)&_12OpDefines_20300, _12OpDefines_20300, _30674);
    DeRefDS(_30674);
    _30674 = NOVALUE;
    goto L2; // [1373] 1546
L35: 

    /** parser.e:4677		elsif equal(option, "inline") then*/
    if (_option_61910 == _30676)
    _30677 = 1;
    else if (IS_ATOM_INT(_option_61910) && IS_ATOM_INT(_30676))
    _30677 = 0;
    else
    _30677 = (compare(_option_61910, _30676) == 0);
    if (_30677 == 0)
    {
        _30677 = NOVALUE;
        goto L3A; // [1382] 1478
    }
    else{
        _30677 = NOVALUE;
    }

    /** parser.e:4679			if on_off and not repl then*/
    if (_on_off_61909 == 0) {
        goto L3B; // [1387] 1467
    }
    _30679 = (0 == 0);
    if (_30679 == 0)
    {
        DeRef(_30679);
        _30679 = NOVALUE;
        goto L3B; // [1397] 1467
    }
    else{
        DeRef(_30679);
        _30679 = NOVALUE;
    }

    /** parser.e:4680				token tok = next_token()*/
    _0 = _tok_62261;
    _tok_62261 = _43next_token();
    DeRef(_0);

    /** parser.e:4681				if tok[T_ID] = ATOM then*/
    _2 = (object)SEQ_PTR(_tok_62261);
    _30681 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30681, 502)){
        _30681 = NOVALUE;
        goto L3C; // [1415] 1447
    }
    _30681 = NOVALUE;

    /** parser.e:4682					OpInline = floor( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (object)SEQ_PTR(_tok_62261);
    _30683 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30683)){
        _30684 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30683)->dbl));
    }
    else{
        _30684 = (object)*(((s1_ptr)_2)->base + _30683);
    }
    _2 = (object)SEQ_PTR(_30684);
    _30685 = (object)*(((s1_ptr)_2)->base + 1);
    _30684 = NOVALUE;
    if (IS_ATOM_INT(_30685))
    _12OpInline_20301 = e_floor(_30685);
    else
    _12OpInline_20301 = unary_op(FLOOR, _30685);
    _30685 = NOVALUE;
    if (!IS_ATOM_INT(_12OpInline_20301)) {
        _1 = (object)(DBL_PTR(_12OpInline_20301)->dbl);
        DeRefDS(_12OpInline_20301);
        _12OpInline_20301 = _1;
    }
    goto L3D; // [1444] 1462
L3C: 

    /** parser.e:4684					putback(tok)*/
    Ref(_tok_62261);
    _43putback(_tok_62261);

    /** parser.e:4685					OpInline = DEFAULT_INLINE*/
    _12OpInline_20301 = 30;
L3D: 
    DeRef(_tok_62261);
    _tok_62261 = NOVALUE;
    goto L2; // [1464] 1546
L3B: 

    /** parser.e:4688				OpInline = 0*/
    _12OpInline_20301 = 0;
    goto L2; // [1475] 1546
L3A: 

    /** parser.e:4692		elsif equal( option, "indirect_includes" ) then*/
    if (_option_61910 == _30687)
    _30688 = 1;
    else if (IS_ATOM_INT(_option_61910) && IS_ATOM_INT(_30687))
    _30688 = 0;
    else
    _30688 = (compare(_option_61910, _30687) == 0);
    if (_30688 == 0)
    {
        _30688 = NOVALUE;
        goto L3E; // [1484] 1497
    }
    else{
        _30688 = NOVALUE;
    }

    /** parser.e:4693			OpIndirectInclude = on_off*/
    _12OpIndirectInclude_20302 = _on_off_61909;
    goto L2; // [1494] 1546
L3E: 

    /** parser.e:4695		elsif equal(option, "batch") then*/
    if (_option_61910 == _25487)
    _30689 = 1;
    else if (IS_ATOM_INT(_option_61910) && IS_ATOM_INT(_25487))
    _30689 = 0;
    else
    _30689 = (compare(_option_61910, _25487) == 0);
    if (_30689 == 0)
    {
        _30689 = NOVALUE;
        goto L3F; // [1503] 1516
    }
    else{
        _30689 = NOVALUE;
    }

    /** parser.e:4696			batch_job = on_off*/
    _12batch_job_20239 = _on_off_61909;
    goto L2; // [1513] 1546
L3F: 

    /** parser.e:4698		elsif integer(to_number(option, -1)) then*/
    RefDS(_option_61910);
    _30690 = _19to_number(_option_61910, -1);
    if (IS_ATOM_INT(_30690))
    _30691 = 1;
    else if (IS_ATOM_DBL(_30690))
    _30691 = IS_ATOM_INT(DoubleToInt(_30690));
    else
    _30691 = 0;
    DeRef(_30690);
    _30690 = NOVALUE;
    if (_30691 == 0)
    {
        _30691 = NOVALUE;
        goto L40; // [1526] 1532
    }
    else{
        _30691 = NOVALUE;
    }
    goto L2; // [1529] 1546
L40: 

    /** parser.e:4702			CompileErr(UNKNOWN_WITHWITHOUT_OPTION_1, {option})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_option_61910);
    ((intptr_t*)_2)[1] = _option_61910;
    _30692 = MAKE_SEQ(_1);
    _49CompileErr(154, _30692, 0);
    _30692 = NOVALUE;
L2: 

    /** parser.e:4705	end procedure*/
    DeRef(_option_61910);
    DeRef(_30639);
    _30639 = NOVALUE;
    DeRef(_30585);
    _30585 = NOVALUE;
    _30683 = NOVALUE;
    _30633 = NOVALUE;
    DeRef(_30668);
    _30668 = NOVALUE;
    DeRef(_30552);
    _30552 = NOVALUE;
    DeRef(_30670);
    _30670 = NOVALUE;
    DeRef(_30571);
    _30571 = NOVALUE;
    _30629 = NOVALUE;
    DeRef(_30593);
    _30593 = NOVALUE;
    _30599 = NOVALUE;
    _30626 = NOVALUE;
    _30630 = NOVALUE;
    _30568 = NOVALUE;
    _30564 = NOVALUE;
    DeRef(_30557);
    _30557 = NOVALUE;
    return;
    ;
}


void _43ExecCommand()
{
    object _0, _1, _2;
    

    /** parser.e:4709		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L1; // [5] 16
    }
    else{
    }

    /** parser.e:4710			emit_op(RETURNT)*/
    _45emit_op(34);
L1: 

    /** parser.e:4712		StraightenBranches()  -- straighten top-level*/
    _43StraightenBranches();

    /** parser.e:4713	end procedure*/
    return;
    ;
}


object _43undefined_var(object _tok_62305, object _scope_62306)
{
    object _forward_62308 = NOVALUE;
    object _30698 = NOVALUE;
    object _30697 = NOVALUE;
    object _30694 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4716		token forward = next_token()*/
    _0 = _forward_62308;
    _forward_62308 = _43next_token();
    DeRef(_0);

    /** parser.e:4717			switch forward[T_ID] do*/
    _2 = (object)SEQ_PTR(_forward_62308);
    _30694 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_30694) ){
        goto L1; // [16] 82
    }
    if(!IS_ATOM_INT(_30694)){
        if( (DBL_PTR(_30694)->dbl != (eudouble) ((object) DBL_PTR(_30694)->dbl) ) ){
            goto L1; // [16] 82
        }
        _0 = (object) DBL_PTR(_30694)->dbl;
    }
    else {
        _0 = _30694;
    };
    _30694 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:4718				case LEFT_ROUND then*/
        case -26:

        /** parser.e:4719					StartSourceLine( TRUE )*/
        _45StartSourceLine(_9TRUE_446, 0, 2);

        /** parser.e:4720					Forward_call( tok )*/
        Ref(_tok_62305);
        _43Forward_call(_tok_62305, 195);

        /** parser.e:4721					return 1*/
        DeRef(_tok_62305);
        DeRef(_forward_62308);
        return 1;
        goto L2; // [48] 96

        /** parser.e:4723				case VARIABLE then*/
        case -100:

        /** parser.e:4724					putback( forward )*/
        Ref(_forward_62308);
        _43putback(_forward_62308);

        /** parser.e:4725					Global_declaration( tok[T_SYM], scope )*/
        _2 = (object)SEQ_PTR(_tok_62305);
        _30697 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_30697);
        _30698 = _43Global_declaration(_30697, _scope_62306);
        _30697 = NOVALUE;

        /** parser.e:4726					return 1*/
        DeRef(_tok_62305);
        DeRef(_forward_62308);
        DeRef(_30698);
        _30698 = NOVALUE;
        return 1;
        goto L2; // [78] 96

        /** parser.e:4728				case else*/
        default:
L1: 

        /** parser.e:4729					putback( forward )*/
        Ref(_forward_62308);
        _43putback(_forward_62308);

        /** parser.e:4730					return 0*/
        DeRef(_tok_62305);
        DeRef(_forward_62308);
        DeRef(_30698);
        _30698 = NOVALUE;
        return 0;
    ;}L2: 
    ;
}


void _43real_parser(object _nested_62327)
{
    object _tok_62329 = NOVALUE;
    object _id_62330 = NOVALUE;
    object _scope_62331 = NOVALUE;
    object _deprecated_62393 = NOVALUE;
    object _test_62488 = NOVALUE;
    object _30838 = NOVALUE;
    object _30836 = NOVALUE;
    object _30835 = NOVALUE;
    object _30834 = NOVALUE;
    object _30833 = NOVALUE;
    object _30832 = NOVALUE;
    object _30831 = NOVALUE;
    object _30830 = NOVALUE;
    object _30825 = NOVALUE;
    object _30824 = NOVALUE;
    object _30821 = NOVALUE;
    object _30819 = NOVALUE;
    object _30818 = NOVALUE;
    object _30815 = NOVALUE;
    object _30801 = NOVALUE;
    object _30794 = NOVALUE;
    object _30793 = NOVALUE;
    object _30791 = NOVALUE;
    object _30789 = NOVALUE;
    object _30788 = NOVALUE;
    object _30786 = NOVALUE;
    object _30784 = NOVALUE;
    object _30779 = NOVALUE;
    object _30777 = NOVALUE;
    object _30775 = NOVALUE;
    object _30774 = NOVALUE;
    object _30773 = NOVALUE;
    object _30771 = NOVALUE;
    object _30769 = NOVALUE;
    object _30767 = NOVALUE;
    object _30765 = NOVALUE;
    object _30764 = NOVALUE;
    object _30763 = NOVALUE;
    object _30762 = NOVALUE;
    object _30761 = NOVALUE;
    object _30760 = NOVALUE;
    object _30759 = NOVALUE;
    object _30758 = NOVALUE;
    object _30757 = NOVALUE;
    object _30756 = NOVALUE;
    object _30755 = NOVALUE;
    object _30754 = NOVALUE;
    object _30753 = NOVALUE;
    object _30752 = NOVALUE;
    object _30750 = NOVALUE;
    object _30749 = NOVALUE;
    object _30748 = NOVALUE;
    object _30747 = NOVALUE;
    object _30745 = NOVALUE;
    object _30743 = NOVALUE;
    object _30742 = NOVALUE;
    object _30741 = NOVALUE;
    object _30739 = NOVALUE;
    object _30728 = NOVALUE;
    object _30726 = NOVALUE;
    object _30725 = NOVALUE;
    object _30724 = NOVALUE;
    object _30723 = NOVALUE;
    object _30722 = NOVALUE;
    object _30721 = NOVALUE;
    object _30720 = NOVALUE;
    object _30719 = NOVALUE;
    object _30718 = NOVALUE;
    object _30716 = NOVALUE;
    object _30715 = NOVALUE;
    object _30714 = NOVALUE;
    object _30713 = NOVALUE;
    object _30712 = NOVALUE;
    object _30711 = NOVALUE;
    object _30710 = NOVALUE;
    object _30709 = NOVALUE;
    object _30708 = NOVALUE;
    object _30707 = NOVALUE;
    object _30705 = NOVALUE;
    object _30701 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:4737		integer id*/

    /** parser.e:4738		integer scope*/

    /** parser.e:4740		while TRUE do  -- infinite loop until scanner aborts*/
L1: 
    if (_9TRUE_446 == 0)
    {
        goto L2; // [14] 1925
    }
    else{
    }

    /** parser.e:4741			if OpInline = 25000 then*/
    if (_12OpInline_20301 != 25000)
    goto L3; // [21] 35

    /** parser.e:4742				CompileErr("OpInline went nuts: [1]", OpInline )*/
    RefDS(_30700);
    _49CompileErr(_30700, _12OpInline_20301, 0);
L3: 

    /** parser.e:4744			start_index = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _30701 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _30701 = 1;
    }
    _43start_index_54958 = _30701 + 1;
    _30701 = NOVALUE;

    /** parser.e:4745			tok = next_token()*/
    _0 = _tok_62329;
    _tok_62329 = _43next_token();
    DeRef(_0);

    /** parser.e:4746			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_62329);
    _id_62330 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_62330)){
        _id_62330 = (object)DBL_PTR(_id_62330)->dbl;
    }

    /** parser.e:4747			if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _30705 = (_id_62330 == -100);
    if (_30705 != 0) {
        goto L4; // [69] 84
    }
    _30707 = (_id_62330 == 512);
    if (_30707 == 0)
    {
        DeRef(_30707);
        _30707 = NOVALUE;
        goto L5; // [80] 151
    }
    else{
        DeRef(_30707);
        _30707 = NOVALUE;
    }
L4: 

    /** parser.e:4748				if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED*/
    _2 = (object)SEQ_PTR(_tok_62329);
    _30708 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30708)){
        _30709 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30708)->dbl));
    }
    else{
        _30709 = (object)*(((s1_ptr)_2)->base + _30708);
    }
    _2 = (object)SEQ_PTR(_30709);
    _30710 = (object)*(((s1_ptr)_2)->base + 4);
    _30709 = NOVALUE;
    if (IS_ATOM_INT(_30710)) {
        _30711 = (_30710 == 9);
    }
    else {
        _30711 = binary_op(EQUALS, _30710, 9);
    }
    _30710 = NOVALUE;
    if (IS_ATOM_INT(_30711)) {
        if (_30711 == 0) {
            goto L6; // [110] 130
        }
    }
    else {
        if (DBL_PTR(_30711)->dbl == 0.0) {
            goto L6; // [110] 130
        }
    }
    Ref(_tok_62329);
    _30713 = _43undefined_var(_tok_62329, 5);
    if (_30713 == 0) {
        DeRef(_30713);
        _30713 = NOVALUE;
        goto L6; // [122] 130
    }
    else {
        if (!IS_ATOM_INT(_30713) && DBL_PTR(_30713)->dbl == 0.0){
            DeRef(_30713);
            _30713 = NOVALUE;
            goto L6; // [122] 130
        }
        DeRef(_30713);
        _30713 = NOVALUE;
    }
    DeRef(_30713);
    _30713 = NOVALUE;

    /** parser.e:4750					continue*/
    goto L1; // [127] 12
L6: 

    /** parser.e:4752				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4753				Assignment(tok)*/
    Ref(_tok_62329);
    _43Assignment(_tok_62329);

    /** parser.e:4754				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [148] 1915
L5: 

    /** parser.e:4756			elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _30714 = (_id_62330 == 405);
    if (_30714 != 0) {
        _30715 = 1;
        goto L8; // [159] 173
    }
    _30716 = (_id_62330 == 406);
    _30715 = (_30716 != 0);
L8: 
    if (_30715 != 0) {
        goto L9; // [173] 188
    }
    _30718 = (_id_62330 == 416);
    if (_30718 == 0)
    {
        DeRef(_30718);
        _30718 = NOVALUE;
        goto LA; // [184] 206
    }
    else{
        DeRef(_30718);
        _30718 = NOVALUE;
    }
L9: 

    /** parser.e:4757				SubProg(tok[T_ID], SC_LOCAL, 0)*/
    _2 = (object)SEQ_PTR(_tok_62329);
    _30719 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30719);
    _43SubProg(_30719, 5, 0);
    _30719 = NOVALUE;
    goto L7; // [203] 1915
LA: 

    /** parser.e:4759			elsif id = GLOBAL or id = EXPORT or id = OVERRIDE or id = PUBLIC or id = DEPRECATE then*/
    _30720 = (_id_62330 == 412);
    if (_30720 != 0) {
        _30721 = 1;
        goto LB; // [214] 228
    }
    _30722 = (_id_62330 == 428);
    _30721 = (_30722 != 0);
LB: 
    if (_30721 != 0) {
        _30723 = 1;
        goto LC; // [228] 242
    }
    _30724 = (_id_62330 == 429);
    _30723 = (_30724 != 0);
LC: 
    if (_30723 != 0) {
        _30725 = 1;
        goto LD; // [242] 256
    }
    _30726 = (_id_62330 == 430);
    _30725 = (_30726 != 0);
LD: 
    if (_30725 != 0) {
        goto LE; // [256] 271
    }
    _30728 = (_id_62330 == 433);
    if (_30728 == 0)
    {
        DeRef(_30728);
        _30728 = NOVALUE;
        goto LF; // [267] 692
    }
    else{
        DeRef(_30728);
        _30728 = NOVALUE;
    }
LE: 

    /** parser.e:4760				integer deprecated = 0*/
    _deprecated_62393 = 0;

    /** parser.e:4762				if id = DEPRECATE then*/
    if (_id_62330 != 433)
    goto L10; // [280] 305

    /** parser.e:4763					deprecated = 1*/
    _deprecated_62393 = 1;

    /** parser.e:4765					tok = next_token()*/
    _0 = _tok_62329;
    _tok_62329 = _43next_token();
    DeRef(_0);

    /** parser.e:4766					id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_62329);
    _id_62330 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_62330)){
        _id_62330 = (object)DBL_PTR(_id_62330)->dbl;
    }
L10: 

    /** parser.e:4769				scope = SC_LOCAL*/
    _scope_62331 = 5;

    /** parser.e:4770				if id = GLOBAL then*/
    if (_id_62330 != 412)
    goto L11; // [318] 334

    /** parser.e:4771				    scope = SC_GLOBAL*/
    _scope_62331 = 6;
    goto L12; // [331] 393
L11: 

    /** parser.e:4772				elsif id = EXPORT then*/
    if (_id_62330 != 428)
    goto L13; // [338] 354

    /** parser.e:4773					scope = SC_EXPORT*/
    _scope_62331 = 11;
    goto L12; // [351] 393
L13: 

    /** parser.e:4774				elsif id = OVERRIDE then*/
    if (_id_62330 != 429)
    goto L14; // [358] 374

    /** parser.e:4775					scope = SC_OVERRIDE*/
    _scope_62331 = 12;
    goto L12; // [371] 393
L14: 

    /** parser.e:4776				elsif id = PUBLIC then*/
    if (_id_62330 != 430)
    goto L15; // [378] 392

    /** parser.e:4777					scope = SC_PUBLIC*/
    _scope_62331 = 13;
L15: 
L12: 

    /** parser.e:4781				if scope != SC_LOCAL then*/
    if (_scope_62331 == 5)
    goto L16; // [397] 417

    /** parser.e:4782					tok = next_token()*/
    _0 = _tok_62329;
    _tok_62329 = _43next_token();
    DeRef(_0);

    /** parser.e:4783					id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_62329);
    _id_62330 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_62330)){
        _id_62330 = (object)DBL_PTR(_id_62330)->dbl;
    }
L16: 

    /** parser.e:4786				if id = TYPE or id = QUALIFIED_TYPE then*/
    _30739 = (_id_62330 == 504);
    if (_30739 != 0) {
        goto L17; // [425] 440
    }
    _30741 = (_id_62330 == 522);
    if (_30741 == 0)
    {
        DeRef(_30741);
        _30741 = NOVALUE;
        goto L18; // [436] 456
    }
    else{
        DeRef(_30741);
        _30741 = NOVALUE;
    }
L17: 

    /** parser.e:4787					Global_declaration(tok[T_SYM], scope )*/
    _2 = (object)SEQ_PTR(_tok_62329);
    _30742 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30742);
    _30743 = _43Global_declaration(_30742, _scope_62331);
    _30742 = NOVALUE;
    goto L19; // [453] 687
L18: 

    /** parser.e:4789				elsif id = CONSTANT then*/
    if (_id_62330 != 417)
    goto L1A; // [460] 478

    /** parser.e:4790					Global_declaration(0, scope )*/
    _30745 = _43Global_declaration(0, _scope_62331);

    /** parser.e:4791					ExecCommand()*/
    _43ExecCommand();
    goto L19; // [475] 687
L1A: 

    /** parser.e:4793				elsif id = ENUM then*/
    if (_id_62330 != 427)
    goto L1B; // [482] 500

    /** parser.e:4794					Global_declaration(-1, scope )*/
    _30747 = _43Global_declaration(-1, _scope_62331);

    /** parser.e:4795					ExecCommand()*/
    _43ExecCommand();
    goto L19; // [497] 687
L1B: 

    /** parser.e:4797				elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _30748 = (_id_62330 == 405);
    if (_30748 != 0) {
        _30749 = 1;
        goto L1C; // [508] 522
    }
    _30750 = (_id_62330 == 406);
    _30749 = (_30750 != 0);
L1C: 
    if (_30749 != 0) {
        goto L1D; // [522] 537
    }
    _30752 = (_id_62330 == 416);
    if (_30752 == 0)
    {
        DeRef(_30752);
        _30752 = NOVALUE;
        goto L1E; // [533] 547
    }
    else{
        DeRef(_30752);
        _30752 = NOVALUE;
    }
L1D: 

    /** parser.e:4798					SubProg(id, scope, deprecated)*/
    _43SubProg(_id_62330, _scope_62331, _deprecated_62393);
    goto L19; // [544] 687
L1E: 

    /** parser.e:4800				elsif (scope = SC_PUBLIC) and id = INCLUDE then*/
    _30753 = (_scope_62331 == 13);
    if (_30753 == 0) {
        goto L1F; // [555] 581
    }
    _30755 = (_id_62330 == 418);
    if (_30755 == 0)
    {
        DeRef(_30755);
        _30755 = NOVALUE;
        goto L1F; // [566] 581
    }
    else{
        DeRef(_30755);
        _30755 = NOVALUE;
    }

    /** parser.e:4801					IncludeScan( 1 )*/
    _61IncludeScan(1);

    /** parser.e:4802					PushGoto()*/
    _43PushGoto();
    goto L19; // [578] 687
L1F: 

    /** parser.e:4803				elsif (id = VARIABLE or id = QUALIFIED_VARIABLE)*/
    _30756 = (_id_62330 == -100);
    if (_30756 != 0) {
        _30757 = 1;
        goto L20; // [589] 603
    }
    _30758 = (_id_62330 == 512);
    _30757 = (_30758 != 0);
L20: 
    if (_30757 == 0) {
        _30759 = 0;
        goto L21; // [603] 635
    }
    _2 = (object)SEQ_PTR(_tok_62329);
    _30760 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30760)){
        _30761 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30760)->dbl));
    }
    else{
        _30761 = (object)*(((s1_ptr)_2)->base + _30760);
    }
    _2 = (object)SEQ_PTR(_30761);
    _30762 = (object)*(((s1_ptr)_2)->base + 4);
    _30761 = NOVALUE;
    if (IS_ATOM_INT(_30762)) {
        _30763 = (_30762 == 9);
    }
    else {
        _30763 = binary_op(EQUALS, _30762, 9);
    }
    _30762 = NOVALUE;
    if (IS_ATOM_INT(_30763))
    _30759 = (_30763 != 0);
    else
    _30759 = DBL_PTR(_30763)->dbl != 0.0;
L21: 
    if (_30759 == 0) {
        goto L22; // [635] 657
    }
    Ref(_tok_62329);
    _30765 = _43undefined_var(_tok_62329, _scope_62331);
    if (_30765 == 0) {
        DeRef(_30765);
        _30765 = NOVALUE;
        goto L22; // [645] 657
    }
    else {
        if (!IS_ATOM_INT(_30765) && DBL_PTR(_30765)->dbl == 0.0){
            DeRef(_30765);
            _30765 = NOVALUE;
            goto L22; // [645] 657
        }
        DeRef(_30765);
        _30765 = NOVALUE;
    }
    DeRef(_30765);
    _30765 = NOVALUE;

    /** parser.e:4807					continue*/
    goto L1; // [652] 12
    goto L19; // [654] 687
L22: 

    /** parser.e:4809				elsif scope = SC_GLOBAL then*/
    if (_scope_62331 != 6)
    goto L23; // [661] 677

    /** parser.e:4810					CompileErr( MSG_GLOBAL_MUST_BE_FOLLOWED_BYA_TYPE_CONSTANT_ENUM_PROCEDURE_TYPE_OR_FUNCTION)*/
    RefDS(_22015);
    _49CompileErr(18, _22015, 0);
    goto L19; // [674] 687
L23: 

    /** parser.e:4812					CompileErr( MSG_PUBLIC_OR_EXPORT_MUST_BE_FOLLOWED_BYA_TYPE_CONSTANT_ENUM_PROCEDURE_TYPE_OR_FUNCTION)*/
    RefDS(_22015);
    _49CompileErr(16, _22015, 0);
L19: 
    goto L7; // [689] 1915
LF: 

    /** parser.e:4815			elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _30767 = (_id_62330 == 504);
    if (_30767 != 0) {
        goto L24; // [700] 715
    }
    _30769 = (_id_62330 == 522);
    if (_30769 == 0)
    {
        DeRef(_30769);
        _30769 = NOVALUE;
        goto L25; // [711] 800
    }
    else{
        DeRef(_30769);
        _30769 = NOVALUE;
    }
L24: 

    /** parser.e:4816				token test = next_token()*/
    _0 = _test_62488;
    _test_62488 = _43next_token();
    DeRef(_0);

    /** parser.e:4817				putback( test )*/
    Ref(_test_62488);
    _43putback(_test_62488);

    /** parser.e:4818				if test[T_ID] = LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_test_62488);
    _30771 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30771, -26)){
        _30771 = NOVALUE;
        goto L26; // [735] 773
    }
    _30771 = NOVALUE;

    /** parser.e:4819						StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4820						Procedure_call(tok)*/
    Ref(_tok_62329);
    _43Procedure_call(_tok_62329);

    /** parser.e:4821						clear_op()*/
    _45clear_op();

    /** parser.e:4822						if Pop() then end if*/
    _30773 = _45Pop();
    if (_30773 == 0) {
        DeRef(_30773);
        _30773 = NOVALUE;
        goto L27; // [762] 766
    }
    else {
        if (!IS_ATOM_INT(_30773) && DBL_PTR(_30773)->dbl == 0.0){
            DeRef(_30773);
            _30773 = NOVALUE;
            goto L27; // [762] 766
        }
        DeRef(_30773);
        _30773 = NOVALUE;
    }
    DeRef(_30773);
    _30773 = NOVALUE;
L27: 

    /** parser.e:4823						ExecCommand()*/
    _43ExecCommand();
    goto L28; // [770] 789
L26: 

    /** parser.e:4826					Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (object)SEQ_PTR(_tok_62329);
    _30774 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30774);
    _30775 = _43Global_declaration(_30774, 5);
    _30774 = NOVALUE;
L28: 

    /** parser.e:4829				continue*/
    DeRef(_test_62488);
    _test_62488 = NOVALUE;
    goto L1; // [793] 12
    goto L7; // [797] 1915
L25: 

    /** parser.e:4831			elsif id = CONSTANT then*/
    if (_id_62330 != 417)
    goto L29; // [804] 824

    /** parser.e:4832				Global_declaration(0, SC_LOCAL)*/
    _30777 = _43Global_declaration(0, 5);

    /** parser.e:4833				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [821] 1915
L29: 

    /** parser.e:4835			elsif id = ENUM then*/
    if (_id_62330 != 427)
    goto L2A; // [828] 848

    /** parser.e:4836				Global_declaration(-1, SC_LOCAL)*/
    _30779 = _43Global_declaration(-1, 5);

    /** parser.e:4837				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [845] 1915
L2A: 

    /** parser.e:4839			elsif id = IF then*/
    if (_id_62330 != 20)
    goto L2B; // [852] 876

    /** parser.e:4840				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4841				If_statement()*/
    _43If_statement();

    /** parser.e:4842				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [873] 1915
L2B: 

    /** parser.e:4844			elsif id = FOR then*/
    if (_id_62330 != 21)
    goto L2C; // [880] 904

    /** parser.e:4845				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4846				For_statement()*/
    _43For_statement();

    /** parser.e:4847				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [901] 1915
L2C: 

    /** parser.e:4849			elsif id = WHILE then*/
    if (_id_62330 != 47)
    goto L2D; // [908] 932

    /** parser.e:4850				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4851				While_statement()*/
    _43While_statement();

    /** parser.e:4852				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [929] 1915
L2D: 

    /** parser.e:4854			elsif id = LOOP then*/
    if (_id_62330 != 422)
    goto L2E; // [936] 960

    /** parser.e:4855			    StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4856			    Loop_statement()*/
    _43Loop_statement();

    /** parser.e:4857			    ExecCommand()*/
    _43ExecCommand();
    goto L7; // [957] 1915
L2E: 

    /** parser.e:4859			elsif id = PROC or id = QUALIFIED_PROC then*/
    _30784 = (_id_62330 == 27);
    if (_30784 != 0) {
        goto L2F; // [968] 983
    }
    _30786 = (_id_62330 == 521);
    if (_30786 == 0)
    {
        DeRef(_30786);
        _30786 = NOVALUE;
        goto L30; // [979] 1024
    }
    else{
        DeRef(_30786);
        _30786 = NOVALUE;
    }
L2F: 

    /** parser.e:4860				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4861				if id = PROC then*/
    if (_id_62330 != 27)
    goto L31; // [996] 1012

    /** parser.e:4863					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_62329);
    _30788 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30788);
    _43UndefinedVar(_30788);
    _30788 = NOVALUE;
L31: 

    /** parser.e:4866				Procedure_call(tok)*/
    Ref(_tok_62329);
    _43Procedure_call(_tok_62329);

    /** parser.e:4867				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [1021] 1915
L30: 

    /** parser.e:4869			elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _30789 = (_id_62330 == 501);
    if (_30789 != 0) {
        goto L32; // [1032] 1047
    }
    _30791 = (_id_62330 == 520);
    if (_30791 == 0)
    {
        DeRef(_30791);
        _30791 = NOVALUE;
        goto L33; // [1043] 1101
    }
    else{
        DeRef(_30791);
        _30791 = NOVALUE;
    }
L32: 

    /** parser.e:4870				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4871				if id = FUNC then*/
    if (_id_62330 != 501)
    goto L34; // [1060] 1076

    /** parser.e:4873					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_62329);
    _30793 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30793);
    _43UndefinedVar(_30793);
    _30793 = NOVALUE;
L34: 

    /** parser.e:4876				Procedure_call(tok)*/
    Ref(_tok_62329);
    _43Procedure_call(_tok_62329);

    /** parser.e:4877				clear_op()*/
    _45clear_op();

    /** parser.e:4878				if Pop() then end if*/
    _30794 = _45Pop();
    if (_30794 == 0) {
        DeRef(_30794);
        _30794 = NOVALUE;
        goto L35; // [1090] 1094
    }
    else {
        if (!IS_ATOM_INT(_30794) && DBL_PTR(_30794)->dbl == 0.0){
            DeRef(_30794);
            _30794 = NOVALUE;
            goto L35; // [1090] 1094
        }
        DeRef(_30794);
        _30794 = NOVALUE;
    }
    DeRef(_30794);
    _30794 = NOVALUE;
L35: 

    /** parser.e:4879				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [1098] 1915
L33: 

    /** parser.e:4881			elsif id = RETURN then*/
    if (_id_62330 != 413)
    goto L36; // [1105] 1116

    /** parser.e:4882				Return_statement() -- will fail - not allowed at top level*/
    _43Return_statement();
    goto L7; // [1113] 1915
L36: 

    /** parser.e:4884			elsif id = EXIT then*/
    if (_id_62330 != 61)
    goto L37; // [1120] 1158

    /** parser.e:4885				if nested then*/
    if (_nested_62327 == 0)
    {
        goto L38; // [1126] 1145
    }
    else{
    }

    /** parser.e:4886				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4887				Exit_statement()*/
    _43Exit_statement();
    goto L7; // [1142] 1915
L38: 

    /** parser.e:4889				CompileErr(EXIT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22015);
    _49CompileErr(89, _22015, 0);
    goto L7; // [1155] 1915
L37: 

    /** parser.e:4892			elsif id = INCLUDE then*/
    if (_id_62330 != 418)
    goto L39; // [1162] 1178

    /** parser.e:4893				IncludeScan( 0 )*/
    _61IncludeScan(0);

    /** parser.e:4894				PushGoto()*/
    _43PushGoto();
    goto L7; // [1175] 1915
L39: 

    /** parser.e:4896			elsif id = WITH then*/
    if (_id_62330 != 420)
    goto L3A; // [1182] 1196

    /** parser.e:4897				SetWith(TRUE)*/
    _43SetWith(_9TRUE_446);
    goto L7; // [1193] 1915
L3A: 

    /** parser.e:4899			elsif id = WITHOUT then*/
    if (_id_62330 != 421)
    goto L3B; // [1200] 1214

    /** parser.e:4900				SetWith(FALSE)*/
    _43SetWith(_9FALSE_444);
    goto L7; // [1211] 1915
L3B: 

    /** parser.e:4902			elsif id = END_OF_FILE then*/
    if (_id_62330 != -21)
    goto L3C; // [1218] 1335

    /** parser.e:4903				if IncludePop() then*/
    _30801 = _61IncludePop();
    if (_30801 == 0) {
        DeRef(_30801);
        _30801 = NOVALUE;
        goto L3D; // [1227] 1323
    }
    else {
        if (!IS_ATOM_INT(_30801) && DBL_PTR(_30801)->dbl == 0.0){
            DeRef(_30801);
            _30801 = NOVALUE;
            goto L3D; // [1227] 1323
        }
        DeRef(_30801);
        _30801 = NOVALUE;
    }
    DeRef(_30801);
    _30801 = NOVALUE;

    /** parser.e:4904					backed_up_tok = {}*/
    RefDS(_22015);
    DeRef(_43backed_up_tok_54959);
    _43backed_up_tok_54959 = _22015;

    /** parser.e:4905					PopGoto()*/
    _43PopGoto();

    /** parser.e:4906					read_line()*/
    _61read_line();

    /** parser.e:4908					last_ForwardLine     = ThisLine*/
    Ref(_49ThisLine_49261);
    DeRef(_49last_ForwardLine_49264);
    _49last_ForwardLine_49264 = _49ThisLine_49261;

    /** parser.e:4909					last_fwd_line_number = line_number*/
    _12last_fwd_line_number_20230 = _12line_number_20227;

    /** parser.e:4910					last_forward_bp      = bp*/
    _49last_forward_bp_49268 = _49bp_49265;

    /** parser.e:4912					putback_ForwardLine     = ThisLine*/
    Ref(_49ThisLine_49261);
    DeRef(_49putback_ForwardLine_49263);
    _49putback_ForwardLine_49263 = _49ThisLine_49261;

    /** parser.e:4913					putback_fwd_line_number = line_number*/
    _12putback_fwd_line_number_20229 = _12line_number_20227;

    /** parser.e:4914					putback_forward_bp      = bp*/
    _49putback_forward_bp_49267 = _49bp_49265;

    /** parser.e:4916					ForwardLine     = ThisLine*/
    Ref(_49ThisLine_49261);
    DeRef(_49ForwardLine_49262);
    _49ForwardLine_49262 = _49ThisLine_49261;

    /** parser.e:4917					fwd_line_number = line_number*/
    _12fwd_line_number_20228 = _12line_number_20227;

    /** parser.e:4918					forward_bp      = bp*/
    _49forward_bp_49266 = _49bp_49265;
    goto L7; // [1320] 1915
L3D: 

    /** parser.e:4921					CheckForUndefinedGotoLabels()*/
    _43CheckForUndefinedGotoLabels();

    /** parser.e:4922					exit -- all finished*/
    goto L2; // [1329] 1925
    goto L7; // [1332] 1915
L3C: 

    /** parser.e:4925			elsif id = QUESTION_MARK then*/
    if (_id_62330 != -31)
    goto L3E; // [1339] 1363

    /** parser.e:4926				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4927				Print_statement()*/
    _43Print_statement();

    /** parser.e:4928				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [1360] 1915
L3E: 

    /** parser.e:4930			elsif id = LABEL then*/
    if (_id_62330 != 419)
    goto L3F; // [1367] 1389

    /** parser.e:4931				StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _45StartSourceLine(_9TRUE_446, 0, 1);

    /** parser.e:4932				GLabel_statement()*/
    _43GLabel_statement();
    goto L7; // [1386] 1915
L3F: 

    /** parser.e:4934			elsif id = GOTO then*/
    if (_id_62330 != 188)
    goto L40; // [1393] 1413

    /** parser.e:4935				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4936				Goto_statement()*/
    _43Goto_statement();
    goto L7; // [1410] 1915
L40: 

    /** parser.e:4938			elsif id = CONTINUE then*/
    if (_id_62330 != 426)
    goto L41; // [1417] 1455

    /** parser.e:4939				if nested then*/
    if (_nested_62327 == 0)
    {
        goto L42; // [1423] 1442
    }
    else{
    }

    /** parser.e:4940					StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4941					Continue_statement()*/
    _43Continue_statement();
    goto L7; // [1439] 1915
L42: 

    /** parser.e:4943					CompileErr(CONTINUE_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22015);
    _49CompileErr(50, _22015, 0);
    goto L7; // [1452] 1915
L41: 

    /** parser.e:4946			elsif id = RETRY then*/
    if (_id_62330 != 184)
    goto L43; // [1459] 1497

    /** parser.e:4947				if nested then*/
    if (_nested_62327 == 0)
    {
        goto L44; // [1465] 1484
    }
    else{
    }

    /** parser.e:4948					StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4949					Retry_statement()*/
    _43Retry_statement();
    goto L7; // [1481] 1915
L44: 

    /** parser.e:4951					CompileErr(RETRY_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22015);
    _49CompileErr(128, _22015, 0);
    goto L7; // [1494] 1915
L43: 

    /** parser.e:4954			elsif id = BREAK then*/
    if (_id_62330 != 425)
    goto L45; // [1501] 1539

    /** parser.e:4955				if nested then*/
    if (_nested_62327 == 0)
    {
        goto L46; // [1507] 1526
    }
    else{
    }

    /** parser.e:4956					StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4957					Break_statement()*/
    _43Break_statement();
    goto L7; // [1523] 1915
L46: 

    /** parser.e:4959					CompileErr(BREAK_MUST_BE_INSIDE_AN_IF_BLOCK)*/
    RefDS(_22015);
    _49CompileErr(39, _22015, 0);
    goto L7; // [1536] 1915
L45: 

    /** parser.e:4962			elsif id = ENTRY then*/
    if (_id_62330 != 424)
    goto L47; // [1543] 1583

    /** parser.e:4963				if nested then*/
    if (_nested_62327 == 0)
    {
        goto L48; // [1549] 1570
    }
    else{
    }

    /** parser.e:4964				    StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _45StartSourceLine(_9TRUE_446, 0, 1);

    /** parser.e:4965				    Entry_statement()*/
    _43Entry_statement();
    goto L7; // [1567] 1915
L48: 

    /** parser.e:4967					CompileErr(ENTRY_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22015);
    _49CompileErr(72, _22015, 0);
    goto L7; // [1580] 1915
L47: 

    /** parser.e:4970			elsif id = IFDEF then*/
    if (_id_62330 != 407)
    goto L49; // [1587] 1607

    /** parser.e:4971				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4972				Ifdef_statement()*/
    _43Ifdef_statement();
    goto L7; // [1604] 1915
L49: 

    /** parser.e:4974			elsif id = CASE then*/
    if (_id_62330 != 186)
    goto L4A; // [1611] 1622

    /** parser.e:4975				Case_statement()*/
    _43Case_statement();
    goto L7; // [1619] 1915
L4A: 

    /** parser.e:4977			elsif id = SWITCH then*/
    if (_id_62330 != 185)
    goto L4B; // [1626] 1646

    /** parser.e:4978				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4979				Switch_statement()*/
    _43Switch_statement();
    goto L7; // [1643] 1915
L4B: 

    /** parser.e:4981			elsif id = LEFT_BRACE then*/
    if (_id_62330 != -24)
    goto L4C; // [1650] 1670

    /** parser.e:4982				StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_446, 0, 2);

    /** parser.e:4983				Multi_assign()*/
    _43Multi_assign();
    goto L7; // [1667] 1915
L4C: 

    /** parser.e:4985			elsif id = ILLEGAL_CHAR then*/
    if (_id_62330 != -20)
    goto L4D; // [1674] 1690

    /** parser.e:4986				CompileErr(ILLEGAL_CHARACTER)*/
    RefDS(_22015);
    _49CompileErr(102, _22015, 0);
    goto L7; // [1687] 1915
L4D: 

    /** parser.e:4989				if nested then*/
    if (_nested_62327 == 0)
    {
        goto L4E; // [1692] 1852
    }
    else{
    }

    /** parser.e:4990					if id = ELSE then*/
    if (_id_62330 != 23)
    goto L4F; // [1699] 1757

    /** parser.e:4991						if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_43if_stack_54987)){
            _30815 = SEQ_PTR(_43if_stack_54987)->length;
    }
    else {
        _30815 = 1;
    }
    if (_30815 != 0)
    goto L50; // [1710] 1818

    /** parser.e:4992							if live_ifdef > 0 then*/
    if (_43live_ifdef_59454 <= 0)
    goto L51; // [1718] 1743

    /** parser.e:4993								CompileErr(SHOULD_THIS_BE_ELSEDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59455)){
            _30818 = SEQ_PTR(_43ifdef_lineno_59455)->length;
    }
    else {
        _30818 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59455);
    _30819 = (object)*(((s1_ptr)_2)->base + _30818);
    _49CompileErr(134, _30819, 0);
    _30819 = NOVALUE;
    goto L50; // [1740] 1818
L51: 

    /** parser.e:4995								CompileErr(NOT_EXPECTING_ELSE)*/
    RefDS(_22015);
    _49CompileErr(118, _22015, 0);
    goto L50; // [1754] 1818
L4F: 

    /** parser.e:4998					elsif id = ELSIF then*/
    if (_id_62330 != 414)
    goto L52; // [1761] 1817

    /** parser.e:4999						if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_43if_stack_54987)){
            _30821 = SEQ_PTR(_43if_stack_54987)->length;
    }
    else {
        _30821 = 1;
    }
    if (_30821 != 0)
    goto L53; // [1772] 1816

    /** parser.e:5000							if live_ifdef > 0 then*/
    if (_43live_ifdef_59454 <= 0)
    goto L54; // [1780] 1805

    /** parser.e:5001								CompileErr(SHOULD_THIS_BE_ELSIFDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59455)){
            _30824 = SEQ_PTR(_43ifdef_lineno_59455)->length;
    }
    else {
        _30824 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59455);
    _30825 = (object)*(((s1_ptr)_2)->base + _30824);
    _49CompileErr(139, _30825, 0);
    _30825 = NOVALUE;
    goto L55; // [1802] 1815
L54: 

    /** parser.e:5003								CompileErr(NOT_EXPECTING_ELSIF)*/
    RefDS(_22015);
    _49CompileErr(119, _22015, 0);
L55: 
L53: 
L52: 
L50: 

    /** parser.e:5007					putback(tok)*/
    Ref(_tok_62329);
    _43putback(_tok_62329);

    /** parser.e:5008					if stmt_nest > 0 then*/
    if (_43stmt_nest_54984 <= 0)
    goto L56; // [1827] 1844

    /** parser.e:5009						stmt_nest -= 1*/
    _43stmt_nest_54984 = _43stmt_nest_54984 - 1;

    /** parser.e:5010						InitDelete()*/
    _43InitDelete();
L56: 

    /** parser.e:5012					return*/
    DeRef(_tok_62329);
    DeRef(_30775);
    _30775 = NOVALUE;
    DeRef(_30758);
    _30758 = NOVALUE;
    DeRef(_30789);
    _30789 = NOVALUE;
    _30708 = NOVALUE;
    DeRef(_30750);
    _30750 = NOVALUE;
    DeRef(_30705);
    _30705 = NOVALUE;
    DeRef(_30714);
    _30714 = NOVALUE;
    DeRef(_30716);
    _30716 = NOVALUE;
    _30760 = NOVALUE;
    DeRef(_30779);
    _30779 = NOVALUE;
    DeRef(_30743);
    _30743 = NOVALUE;
    DeRef(_30784);
    _30784 = NOVALUE;
    DeRef(_30726);
    _30726 = NOVALUE;
    DeRef(_30777);
    _30777 = NOVALUE;
    DeRef(_30739);
    _30739 = NOVALUE;
    DeRef(_30767);
    _30767 = NOVALUE;
    DeRef(_30745);
    _30745 = NOVALUE;
    DeRef(_30747);
    _30747 = NOVALUE;
    DeRef(_30724);
    _30724 = NOVALUE;
    DeRef(_30763);
    _30763 = NOVALUE;
    DeRef(_30748);
    _30748 = NOVALUE;
    DeRef(_30720);
    _30720 = NOVALUE;
    DeRef(_30722);
    _30722 = NOVALUE;
    DeRef(_30756);
    _30756 = NOVALUE;
    DeRef(_30753);
    _30753 = NOVALUE;
    DeRef(_30711);
    _30711 = NOVALUE;
    return;
    goto L57; // [1849] 1914
L4E: 

    /** parser.e:5014					if id = END then*/
    if (_id_62330 != 402)
    goto L58; // [1856] 1889

    /** parser.e:5015						tok = next_token()*/
    _0 = _tok_62329;
    _tok_62329 = _43next_token();
    DeRef(_0);

    /** parser.e:5016						CompileErr(MSG_END_HAS_NO_MATCHING_1, {find_token_text(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_62329);
    _30830 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30830);
    _30831 = _62find_token_text(_30830);
    _30830 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30831;
    _30832 = MAKE_SEQ(_1);
    _30831 = NOVALUE;
    _49CompileErr(17, _30832, 0);
    _30832 = NOVALUE;
L58: 

    /** parser.e:5019					CompileErr(NOT_EXPECTING_TO_SEE_1_HERE, { match_replace(",", find_token_text(id), "") })*/
    _30833 = _62find_token_text(_id_62330);
    RefDS(_26174);
    RefDS(_22015);
    _30834 = _20match_replace(_26174, _30833, _22015, 0);
    _30833 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30834;
    _30835 = MAKE_SEQ(_1);
    _30834 = NOVALUE;
    _49CompileErr(117, _30835, 0);
    _30835 = NOVALUE;
L57: 
L7: 

    /** parser.e:5024			flush_temps()*/
    RefDS(_22015);
    _45flush_temps(_22015);

    /** parser.e:5025		end while*/
    goto L1; // [1922] 12
L2: 

    /** parser.e:5026		emit_op(RETURNT)*/
    _45emit_op(34);

    /** parser.e:5027		clear_last()*/
    _45clear_last();

    /** parser.e:5028		StraightenBranches()*/
    _43StraightenBranches();

    /** parser.e:5029		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_12Code_20315);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12Code_20315;
    DeRef(_1);
    _30836 = NOVALUE;

    /** parser.e:5030		EndLineTable()*/
    _43EndLineTable();

    /** parser.e:5031		SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_12LineTable_20316);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_19899))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12LineTable_20316;
    DeRef(_1);
    _30838 = NOVALUE;

    /** parser.e:5032	end procedure*/
    DeRef(_tok_62329);
    DeRef(_30775);
    _30775 = NOVALUE;
    DeRef(_30758);
    _30758 = NOVALUE;
    DeRef(_30789);
    _30789 = NOVALUE;
    _30708 = NOVALUE;
    DeRef(_30750);
    _30750 = NOVALUE;
    DeRef(_30705);
    _30705 = NOVALUE;
    DeRef(_30714);
    _30714 = NOVALUE;
    DeRef(_30716);
    _30716 = NOVALUE;
    _30760 = NOVALUE;
    DeRef(_30779);
    _30779 = NOVALUE;
    DeRef(_30743);
    _30743 = NOVALUE;
    DeRef(_30784);
    _30784 = NOVALUE;
    DeRef(_30726);
    _30726 = NOVALUE;
    DeRef(_30777);
    _30777 = NOVALUE;
    DeRef(_30739);
    _30739 = NOVALUE;
    DeRef(_30767);
    _30767 = NOVALUE;
    DeRef(_30745);
    _30745 = NOVALUE;
    DeRef(_30747);
    _30747 = NOVALUE;
    DeRef(_30724);
    _30724 = NOVALUE;
    DeRef(_30763);
    _30763 = NOVALUE;
    DeRef(_30748);
    _30748 = NOVALUE;
    DeRef(_30720);
    _30720 = NOVALUE;
    DeRef(_30722);
    _30722 = NOVALUE;
    DeRef(_30756);
    _30756 = NOVALUE;
    DeRef(_30753);
    _30753 = NOVALUE;
    DeRef(_30711);
    _30711 = NOVALUE;
    return;
    ;
}


void _43parser()
{
    object _30842 = NOVALUE;
    object _30840 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:5035		real_parser(0)*/
    _43real_parser(0);

    /** parser.e:5036		mark_final_targets()*/
    _53mark_final_targets();

    /** parser.e:5037		resolve_unincluded_globals( 1 )*/
    _53resolve_unincluded_globals(1);

    /** parser.e:5038		Resolve_forward_references( 1 )*/
    _42Resolve_forward_references(1);

    /** parser.e:5039		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_12Code_20315);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12Code_20315;
    DeRef(_1);
    _30840 = NOVALUE;

    /** parser.e:5040		SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_12LineTable_20316);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_19899))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12LineTable_20316;
    DeRef(_1);
    _30842 = NOVALUE;

    /** parser.e:5041		Code = {}*/
    RefDS(_22015);
    DeRefDS(_12Code_20315);
    _12Code_20315 = _22015;

    /** parser.e:5042		LineTable = {}*/
    RefDS(_22015);
    DeRefDS(_12LineTable_20316);
    _12LineTable_20316 = _22015;

    /** parser.e:5043		inline_deferred_calls()*/
    _66inline_deferred_calls();

    /** parser.e:5044		if not repl then*/

    /** parser.e:5045		End_block( PROC )*/
    _64End_block(27);

    /** parser.e:5046		Code = {}*/
    RefDS(_22015);
    DeRefDS(_12Code_20315);
    _12Code_20315 = _22015;

    /** parser.e:5047		LineTable = {}*/
    RefDS(_22015);
    DeRefDS(_12LineTable_20316);
    _12LineTable_20316 = _22015;

    /** parser.e:5049	end procedure*/
    return;
    ;
}


void _43nested_parser()
{
    object _0, _1, _2;
    

    /** parser.e:5052		real_parser(1)*/
    _43real_parser(1);

    /** parser.e:5053	end procedure*/
    return;
    ;
}



// 0x4F1030FE
