// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _38any_key(object _prompt_14297, object _con_14299)
{
    object _wait_key_inlined_wait_key_at_27_14305 = NOVALUE;
    object _8202 = NOVALUE;
    object _0, _1, _2;
    

    /** console.e:883		if not find(con, {1,2}) then*/
    _8202 = find_from(_con_14299, _8201, 1);
    if (_8202 != 0)
    goto L1; // [12] 21
    _8202 = NOVALUE;

    /** console.e:884			con = 1*/
    _con_14299 = 1;
L1: 

    /** console.e:886		puts(con, prompt)*/
    EPuts(_con_14299, _prompt_14297); // DJP 

    /** console.e:887		wait_key()*/

    /** console.e:854		return machine_func(M_WAIT_KEY, 0)*/
    _wait_key_inlined_wait_key_at_27_14305 = machine(26, 0);

    /** console.e:888		puts(con, "\n")*/
    EPuts(_con_14299, _8204); // DJP 

    /** console.e:889	end procedure*/
    DeRefDS(_prompt_14297);
    return;
    ;
}


void _38maybe_any_key(object _prompt_14309, object _con_14310)
{
    object _has_console_inlined_has_console_at_6_14313 = NOVALUE;
    object _0, _1, _2;
    

    /** console.e:923		if not has_console() then*/

    /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
    DeRef(_has_console_inlined_has_console_at_6_14313);
    _has_console_inlined_has_console_at_6_14313 = machine(99, 0);
    if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_14313)) {
        if (_has_console_inlined_has_console_at_6_14313 != 0){
            goto L1; // [14] 24
        }
    }
    else {
        if (DBL_PTR(_has_console_inlined_has_console_at_6_14313)->dbl != 0.0){
            goto L1; // [14] 24
        }
    }

    /** console.e:924			any_key(prompt, con)*/
    RefDS(_prompt_14309);
    _38any_key(_prompt_14309, _con_14310);
L1: 

    /** console.e:926	end procedure*/
    DeRefDS(_prompt_14309);
    return;
    ;
}



// 0x1DDFC180
