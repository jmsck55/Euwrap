// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _72default_state()
{
    object _35157 = NOVALUE;
    object _0, _1, _2;
    

    /** tokenize.e:177		return {*/
    _1 = NewS1(8);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    ((intptr_t*)_2)[3] = 0;
    ((intptr_t*)_2)[4] = 1;
    ((intptr_t*)_2)[5] = 0;
    ((intptr_t*)_2)[6] = 1;
    ((intptr_t*)_2)[7] = 0;
    ((intptr_t*)_2)[8] = 0;
    _35157 = MAKE_SEQ(_1);
    return _35157;
    ;
}


object _72new()
{
    object _state_70863 = NOVALUE;
    object _0, _1, _2;
    

    /** tokenize.e:200		atom state = eumem:malloc()*/
    _0 = _state_70863;
    _state_70863 = _35malloc(1, 1);
    DeRef(_0);

    /** tokenize.e:202		reset(state)*/
    Ref(_state_70863);
    _72reset(_state_70863);

    /** tokenize.e:204		return state*/
    return _state_70863;
    ;
}


void _72reset(object _state_70868)
{
    object _35161 = NOVALUE;
    object _0, _1, _2;
    

    /** tokenize.e:215		eumem:ram_space[state] = default_state()*/
    _35161 = _72default_state();
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_70868))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_70868)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _state_70868);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35161;
    if( _1 != _35161 ){
        DeRef(_1);
    }
    _35161 = NOVALUE;

    /** tokenize.e:216	end procedure*/
    DeRef(_state_70868);
    return;
    ;
}



// 0x090CF88C
