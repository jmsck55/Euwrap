// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _25sort(object _x_3425, object _order_3426)
{
    object _gap_3427 = NOVALUE;
    object _j_3428 = NOVALUE;
    object _first_3429 = NOVALUE;
    object _last_3430 = NOVALUE;
    object _tempi_3431 = NOVALUE;
    object _tempj_3432 = NOVALUE;
    object _1595 = NOVALUE;
    object _1591 = NOVALUE;
    object _1588 = NOVALUE;
    object _1584 = NOVALUE;
    object _1581 = NOVALUE;
    object _0, _1, _2;
    

    /** sort.e:72		if order >= 0 then*/

    /** sort.e:73			order = -1*/
    _order_3426 = -1;
    goto L1; // [16] 25

    /** sort.e:75			order = 1*/
    _order_3426 = 1;
L1: 

    /** sort.e:79		last = length(x)*/
    if (IS_SEQUENCE(_x_3425)){
            _last_3430 = SEQ_PTR(_x_3425)->length;
    }
    else {
        _last_3430 = 1;
    }

    /** sort.e:80		gap = floor(last / 10) + 1*/
    if (10 > 0 && _last_3430 >= 0) {
        _1581 = _last_3430 / 10;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_last_3430 / (eudouble)10);
        _1581 = (object)temp_dbl;
    }
    _gap_3427 = _1581 + 1;
    _1581 = NOVALUE;

    /** sort.e:81		while 1 do*/
L2: 

    /** sort.e:82			first = gap + 1*/
    _first_3429 = _gap_3427 + 1;

    /** sort.e:83			for i = first to last do*/
    _1584 = _last_3430;
    {
        object _i_3442;
        _i_3442 = _first_3429;
L3: 
        if (_i_3442 > _1584){
            goto L4; // [56] 152
        }

        /** sort.e:84				tempi = x[i]*/
        DeRef(_tempi_3431);
        _2 = (object)SEQ_PTR(_x_3425);
        _tempi_3431 = (object)*(((s1_ptr)_2)->base + _i_3442);
        Ref(_tempi_3431);

        /** sort.e:85				j = i - gap*/
        _j_3428 = _i_3442 - _gap_3427;

        /** sort.e:86				while 1 do*/
L5: 

        /** sort.e:87					tempj = x[j]*/
        DeRef(_tempj_3432);
        _2 = (object)SEQ_PTR(_x_3425);
        _tempj_3432 = (object)*(((s1_ptr)_2)->base + _j_3428);
        Ref(_tempj_3432);

        /** sort.e:88					if eu:compare(tempi, tempj) != order then*/
        if (IS_ATOM_INT(_tempi_3431) && IS_ATOM_INT(_tempj_3432)){
            _1588 = (_tempi_3431 < _tempj_3432) ? -1 : (_tempi_3431 > _tempj_3432);
        }
        else{
            _1588 = compare(_tempi_3431, _tempj_3432);
        }
        if (_1588 == _order_3426)
        goto L6; // [92] 107

        /** sort.e:89						j += gap*/
        _j_3428 = _j_3428 + _gap_3427;

        /** sort.e:90						exit*/
        goto L7; // [104] 139
L6: 

        /** sort.e:92					x[j+gap] = tempj*/
        _1591 = _j_3428 + _gap_3427;
        Ref(_tempj_3432);
        _2 = (object)SEQ_PTR(_x_3425);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _x_3425 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _1591);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempj_3432;
        DeRef(_1);

        /** sort.e:93					if j <= gap then*/
        if (_j_3428 > _gap_3427)
        goto L8; // [119] 128

        /** sort.e:94						exit*/
        goto L7; // [125] 139
L8: 

        /** sort.e:96					j -= gap*/
        _j_3428 = _j_3428 - _gap_3427;

        /** sort.e:97				end while*/
        goto L5; // [136] 80
L7: 

        /** sort.e:98				x[j] = tempi*/
        Ref(_tempi_3431);
        _2 = (object)SEQ_PTR(_x_3425);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _x_3425 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _j_3428);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempi_3431;
        DeRef(_1);

        /** sort.e:99			end for*/
        _i_3442 = _i_3442 + 1;
        goto L3; // [147] 63
L4: 
        ;
    }

    /** sort.e:100			if gap = 1 then*/
    if (_gap_3427 != 1)
    goto L9; // [154] 167

    /** sort.e:101				return x*/
    DeRef(_tempi_3431);
    DeRef(_tempj_3432);
    DeRef(_1591);
    _1591 = NOVALUE;
    return _x_3425;
    goto L2; // [164] 45
L9: 

    /** sort.e:103				gap = floor(gap / 7) + 1*/
    if (7 > 0 && _gap_3427 >= 0) {
        _1595 = _gap_3427 / 7;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_gap_3427 / (eudouble)7);
        _1595 = (object)temp_dbl;
    }
    _gap_3427 = _1595 + 1;
    _1595 = NOVALUE;

    /** sort.e:105		end while*/
    goto L2; // [180] 45
    ;
}


object _25custom_sort(object _custom_compare_3463, object _x_3464, object _data_3465, object _order_3466)
{
    object _gap_3467 = NOVALUE;
    object _j_3468 = NOVALUE;
    object _first_3469 = NOVALUE;
    object _last_3470 = NOVALUE;
    object _tempi_3471 = NOVALUE;
    object _tempj_3472 = NOVALUE;
    object _result_3473 = NOVALUE;
    object _args_3474 = NOVALUE;
    object _1623 = NOVALUE;
    object _1619 = NOVALUE;
    object _1616 = NOVALUE;
    object _1614 = NOVALUE;
    object _1613 = NOVALUE;
    object _1608 = NOVALUE;
    object _1605 = NOVALUE;
    object _1601 = NOVALUE;
    object _1599 = NOVALUE;
    object _0, _1, _2;
    

    /** sort.e:253		sequence args = {0, 0}*/
    DeRef(_args_3474);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = 0;
    _args_3474 = MAKE_SEQ(_1);

    /** sort.e:255		if order >= 0 then*/

    /** sort.e:256			order = -1*/
    _order_3466 = -1;
    goto L1; // [24] 33

    /** sort.e:258			order = 1*/
    _order_3466 = 1;
L1: 

    /** sort.e:261		if atom(data) then*/
    _1599 = IS_ATOM(_data_3465);
    if (_1599 == 0)
    {
        _1599 = NOVALUE;
        goto L2; // [38] 50
    }
    else{
        _1599 = NOVALUE;
    }

    /** sort.e:262			args &= data*/
    if (IS_SEQUENCE(_args_3474) && IS_ATOM(_data_3465)) {
        Ref(_data_3465);
        Append(&_args_3474, _args_3474, _data_3465);
    }
    else if (IS_ATOM(_args_3474) && IS_SEQUENCE(_data_3465)) {
    }
    else {
        Concat((object_ptr)&_args_3474, _args_3474, _data_3465);
    }
    goto L3; // [47] 70
L2: 

    /** sort.e:263		elsif length(data) then*/
    _1601 = 0;
L3: 

    /** sort.e:267		last = length(x)*/
    if (IS_SEQUENCE(_x_3464)){
            _last_3470 = SEQ_PTR(_x_3464)->length;
    }
    else {
        _last_3470 = 1;
    }

    /** sort.e:268		gap = floor(last / 10) + 1*/
    if (10 > 0 && _last_3470 >= 0) {
        _1605 = _last_3470 / 10;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_last_3470 / (eudouble)10);
        _1605 = (object)temp_dbl;
    }
    _gap_3467 = _1605 + 1;
    _1605 = NOVALUE;

    /** sort.e:269		while 1 do*/
L4: 

    /** sort.e:270			first = gap + 1*/
    _first_3469 = _gap_3467 + 1;

    /** sort.e:271			for i = first to last do*/
    _1608 = _last_3470;
    {
        object _i_3492;
        _i_3492 = _first_3469;
L5: 
        if (_i_3492 > _1608){
            goto L6; // [101] 240
        }

        /** sort.e:272				tempi = x[i]*/
        DeRef(_tempi_3471);
        _2 = (object)SEQ_PTR(_x_3464);
        _tempi_3471 = (object)*(((s1_ptr)_2)->base + _i_3492);
        Ref(_tempi_3471);

        /** sort.e:273				args[1] = tempi*/
        Ref(_tempi_3471);
        _2 = (object)SEQ_PTR(_args_3474);
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempi_3471;
        DeRef(_1);

        /** sort.e:274				j = i - gap*/
        _j_3468 = _i_3492 - _gap_3467;

        /** sort.e:275				while 1 do*/
L7: 

        /** sort.e:276					tempj = x[j]*/
        DeRef(_tempj_3472);
        _2 = (object)SEQ_PTR(_x_3464);
        _tempj_3472 = (object)*(((s1_ptr)_2)->base + _j_3468);
        Ref(_tempj_3472);

        /** sort.e:277					args[2] = tempj*/
        Ref(_tempj_3472);
        _2 = (object)SEQ_PTR(_args_3474);
        _2 = (object)(((s1_ptr)_2)->base + 2);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempj_3472;
        DeRef(_1);

        /** sort.e:278					result = call_func(custom_compare, args)*/
        _1 = (object)SEQ_PTR(_args_3474);
        _2 = (object)((s1_ptr)_1)->base;
        _0 = (object)_00[_custom_compare_3463].addr;
        switch(((s1_ptr)_1)->length) {
            case 0:
                _1 = (*(intptr_t (*)())_0)(
                                     );
                break;
            case 1:
                Ref( *(( (intptr_t*)_2) + 1) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1)
                                     );
                break;
            case 2:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2)
                                     );
                break;
            case 3:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3)
                                     );
                break;
            case 4:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4)
                                     );
                break;
            case 5:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5)
                                     );
                break;
            case 6:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6)
                                     );
                break;
            case 7:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7)
                                     );
                break;
            case 8:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8)
                                     );
                break;
            case 9:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                Ref( *(( (intptr_t*)_2) + 9) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8), 
                                    *( ((intptr_t *)_2) + 9)
                                     );
                break;
            case 10:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                Ref( *(( (intptr_t*)_2) + 9) );
                Ref( *(( (intptr_t*)_2) + 10) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8), 
                                    *( ((intptr_t *)_2) + 9), 
                                    *( ((intptr_t *)_2) + 10)
                                     );
                break;
            case 11:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                Ref( *(( (intptr_t*)_2) + 9) );
                Ref( *(( (intptr_t*)_2) + 10) );
                Ref( *(( (intptr_t*)_2) + 11) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8), 
                                    *( ((intptr_t *)_2) + 9), 
                                    *( ((intptr_t *)_2) + 10), 
                                    *( ((intptr_t *)_2) + 11)
                                     );
                break;
            case 12:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                Ref( *(( (intptr_t*)_2) + 9) );
                Ref( *(( (intptr_t*)_2) + 10) );
                Ref( *(( (intptr_t*)_2) + 11) );
                Ref( *(( (intptr_t*)_2) + 12) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8), 
                                    *( ((intptr_t *)_2) + 9), 
                                    *( ((intptr_t *)_2) + 10), 
                                    *( ((intptr_t *)_2) + 11), 
                                    *( ((intptr_t *)_2) + 12)
                                     );
                break;
        }
        DeRef(_result_3473);
        _result_3473 = _1;

        /** sort.e:279					if sequence(result) then*/
        _1613 = IS_SEQUENCE(_result_3473);
        if (_1613 == 0)
        {
            _1613 = NOVALUE;
            goto L8; // [154] 174
        }
        else{
            _1613 = NOVALUE;
        }

        /** sort.e:280						args[3] = result[2]*/
        _2 = (object)SEQ_PTR(_result_3473);
        _1614 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_1614);
        _2 = (object)SEQ_PTR(_args_3474);
        _2 = (object)(((s1_ptr)_2)->base + 3);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _1614;
        if( _1 != _1614 ){
            DeRef(_1);
        }
        _1614 = NOVALUE;

        /** sort.e:281						result = result[1]*/
        _0 = _result_3473;
        _2 = (object)SEQ_PTR(_result_3473);
        _result_3473 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_result_3473);
        DeRef(_0);
L8: 

        /** sort.e:283					if eu:compare(result, 0) != order then*/
        if (IS_ATOM_INT(_result_3473) && IS_ATOM_INT(0)){
            _1616 = (_result_3473 < 0) ? -1 : (_result_3473 > 0);
        }
        else{
            _1616 = compare(_result_3473, 0);
        }
        if (_1616 == _order_3466)
        goto L9; // [180] 195

        /** sort.e:284						j += gap*/
        _j_3468 = _j_3468 + _gap_3467;

        /** sort.e:285						exit*/
        goto LA; // [192] 227
L9: 

        /** sort.e:287					x[j+gap] = tempj*/
        _1619 = _j_3468 + _gap_3467;
        Ref(_tempj_3472);
        _2 = (object)SEQ_PTR(_x_3464);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _x_3464 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _1619);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempj_3472;
        DeRef(_1);

        /** sort.e:288					if j <= gap then*/
        if (_j_3468 > _gap_3467)
        goto LB; // [207] 216

        /** sort.e:289						exit*/
        goto LA; // [213] 227
LB: 

        /** sort.e:291					j -= gap*/
        _j_3468 = _j_3468 - _gap_3467;

        /** sort.e:292				end while*/
        goto L7; // [224] 131
LA: 

        /** sort.e:293				x[j] = tempi*/
        Ref(_tempi_3471);
        _2 = (object)SEQ_PTR(_x_3464);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _x_3464 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _j_3468);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempi_3471;
        DeRef(_1);

        /** sort.e:294			end for*/
        _i_3492 = _i_3492 + 1;
        goto L5; // [235] 108
L6: 
        ;
    }

    /** sort.e:295			if gap = 1 then*/
    if (_gap_3467 != 1)
    goto LC; // [242] 255

    /** sort.e:296				return x*/
    DeRef(_data_3465);
    DeRef(_tempi_3471);
    DeRef(_tempj_3472);
    DeRef(_result_3473);
    DeRef(_args_3474);
    DeRef(_1619);
    _1619 = NOVALUE;
    return _x_3464;
    goto L4; // [252] 90
LC: 

    /** sort.e:298				gap = floor(gap / 7) + 1*/
    if (7 > 0 && _gap_3467 >= 0) {
        _1623 = _gap_3467 / 7;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_gap_3467 / (eudouble)7);
        _1623 = (object)temp_dbl;
    }
    _gap_3467 = _1623 + 1;
    _1623 = NOVALUE;

    /** sort.e:300		end while*/
    goto L4; // [268] 90
    ;
}


object _25column_compare(object _a_3518, object _b_3519, object _cols_3520)
{
    object _sign_3521 = NOVALUE;
    object _column_3522 = NOVALUE;
    object _1646 = NOVALUE;
    object _1644 = NOVALUE;
    object _1643 = NOVALUE;
    object _1642 = NOVALUE;
    object _1641 = NOVALUE;
    object _1640 = NOVALUE;
    object _1639 = NOVALUE;
    object _1637 = NOVALUE;
    object _1636 = NOVALUE;
    object _1635 = NOVALUE;
    object _1633 = NOVALUE;
    object _1631 = NOVALUE;
    object _1628 = NOVALUE;
    object _1626 = NOVALUE;
    object _1625 = NOVALUE;
    object _0, _1, _2;
    

    /** sort.e:309		for i = 1 to length(cols) do*/
    if (IS_SEQUENCE(_cols_3520)){
            _1625 = SEQ_PTR(_cols_3520)->length;
    }
    else {
        _1625 = 1;
    }
    {
        object _i_3524;
        _i_3524 = 1;
L1: 
        if (_i_3524 > _1625){
            goto L2; // [6] 176
        }

        /** sort.e:310			if cols[i] < 0 then*/
        _2 = (object)SEQ_PTR(_cols_3520);
        _1626 = (object)*(((s1_ptr)_2)->base + _i_3524);
        if (binary_op_a(GREATEREQ, _1626, 0)){
            _1626 = NOVALUE;
            goto L3; // [19] 42
        }
        _1626 = NOVALUE;

        /** sort.e:311				sign = -1*/
        _sign_3521 = -1;

        /** sort.e:312				column = -cols[i]*/
        _2 = (object)SEQ_PTR(_cols_3520);
        _1628 = (object)*(((s1_ptr)_2)->base + _i_3524);
        if (IS_ATOM_INT(_1628)) {
            if ((uintptr_t)_1628 == (uintptr_t)HIGH_BITS){
                _column_3522 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _column_3522 = - _1628;
            }
        }
        else {
            _column_3522 = unary_op(UMINUS, _1628);
        }
        _1628 = NOVALUE;
        if (!IS_ATOM_INT(_column_3522)) {
            _1 = (object)(DBL_PTR(_column_3522)->dbl);
            DeRefDS(_column_3522);
            _column_3522 = _1;
        }
        goto L4; // [39] 56
L3: 

        /** sort.e:314				sign = 1*/
        _sign_3521 = 1;

        /** sort.e:315				column = cols[i]*/
        _2 = (object)SEQ_PTR(_cols_3520);
        _column_3522 = (object)*(((s1_ptr)_2)->base + _i_3524);
        if (!IS_ATOM_INT(_column_3522)){
            _column_3522 = (object)DBL_PTR(_column_3522)->dbl;
        }
L4: 

        /** sort.e:317			if column <= length(a) then*/
        if (IS_SEQUENCE(_a_3518)){
                _1631 = SEQ_PTR(_a_3518)->length;
        }
        else {
            _1631 = 1;
        }
        if (_column_3522 > _1631)
        goto L5; // [63] 137

        /** sort.e:318				if column <= length(b) then*/
        if (IS_SEQUENCE(_b_3519)){
                _1633 = SEQ_PTR(_b_3519)->length;
        }
        else {
            _1633 = 1;
        }
        if (_column_3522 > _1633)
        goto L6; // [72] 121

        /** sort.e:319					if not equal(a[column], b[column]) then*/
        _2 = (object)SEQ_PTR(_a_3518);
        _1635 = (object)*(((s1_ptr)_2)->base + _column_3522);
        _2 = (object)SEQ_PTR(_b_3519);
        _1636 = (object)*(((s1_ptr)_2)->base + _column_3522);
        if (_1635 == _1636)
        _1637 = 1;
        else if (IS_ATOM_INT(_1635) && IS_ATOM_INT(_1636))
        _1637 = 0;
        else
        _1637 = (compare(_1635, _1636) == 0);
        _1635 = NOVALUE;
        _1636 = NOVALUE;
        if (_1637 != 0)
        goto L7; // [90] 169
        _1637 = NOVALUE;

        /** sort.e:320						return sign * eu:compare(a[column], b[column])*/
        _2 = (object)SEQ_PTR(_a_3518);
        _1639 = (object)*(((s1_ptr)_2)->base + _column_3522);
        _2 = (object)SEQ_PTR(_b_3519);
        _1640 = (object)*(((s1_ptr)_2)->base + _column_3522);
        if (IS_ATOM_INT(_1639) && IS_ATOM_INT(_1640)){
            _1641 = (_1639 < _1640) ? -1 : (_1639 > _1640);
        }
        else{
            _1641 = compare(_1639, _1640);
        }
        _1639 = NOVALUE;
        _1640 = NOVALUE;
        if (_sign_3521 == (short)_sign_3521){
            _1642 = _sign_3521 * _1641;
        }
        else{
            _1642 = NewDouble(_sign_3521 * (eudouble)_1641);
        }
        _1641 = NOVALUE;
        DeRef(_a_3518);
        DeRef(_b_3519);
        DeRef(_cols_3520);
        return _1642;
        goto L7; // [118] 169
L6: 

        /** sort.e:323					return sign * -1*/
        if (_sign_3521 == (short)_sign_3521){
            _1643 = _sign_3521 * -1;
        }
        else{
            _1643 = NewDouble(_sign_3521 * (eudouble)-1);
        }
        DeRef(_a_3518);
        DeRef(_b_3519);
        DeRef(_cols_3520);
        DeRef(_1642);
        _1642 = NOVALUE;
        return _1643;
        goto L7; // [134] 169
L5: 

        /** sort.e:326				if column <= length(b) then*/
        if (IS_SEQUENCE(_b_3519)){
                _1644 = SEQ_PTR(_b_3519)->length;
        }
        else {
            _1644 = 1;
        }
        if (_column_3522 > _1644)
        goto L8; // [142] 161

        /** sort.e:327					return sign * 1*/
        _1646 = _sign_3521 * 1;
        DeRef(_a_3518);
        DeRef(_b_3519);
        DeRef(_cols_3520);
        DeRef(_1642);
        _1642 = NOVALUE;
        DeRef(_1643);
        _1643 = NOVALUE;
        return _1646;
        goto L9; // [158] 168
L8: 

        /** sort.e:329					return 0*/
        DeRef(_a_3518);
        DeRef(_b_3519);
        DeRef(_cols_3520);
        DeRef(_1642);
        _1642 = NOVALUE;
        DeRef(_1643);
        _1643 = NOVALUE;
        DeRef(_1646);
        _1646 = NOVALUE;
        return 0;
L9: 
L7: 

        /** sort.e:332		end for*/
        _i_3524 = _i_3524 + 1;
        goto L1; // [171] 13
L2: 
        ;
    }

    /** sort.e:333		return 0*/
    DeRef(_a_3518);
    DeRef(_b_3519);
    DeRef(_cols_3520);
    DeRef(_1642);
    _1642 = NOVALUE;
    DeRef(_1643);
    _1643 = NOVALUE;
    DeRef(_1646);
    _1646 = NOVALUE;
    return 0;
    ;
}



// 0xBC8C7529
