// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _19int_to_bytes(object _x_2221, object _size_2222)
{
    object _984 = NOVALUE;
    object _983 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:68		switch size do*/
    _0 = _size_2222;
    switch ( _0 ){ 

        /** convert.e:69			case 1 then*/
        case 1:

        /** convert.e:70				poke( mem, x )*/
        if (IS_ATOM_INT(_19mem_2217)){
            poke_addr = (uint8_t *)_19mem_2217;
        }
        else {
            poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_19mem_2217)->dbl);
        }
        if (IS_ATOM_INT(_x_2221)) {
            *poke_addr = (uint8_t)_x_2221;
        }
        else {
            *poke_addr = (uint8_t)DBL_PTR(_x_2221)->dbl;
        }
        goto L1; // [21] 73

        /** convert.e:71			case 2 then*/
        case 2:

        /** convert.e:72				poke2( mem, x )*/
        if (IS_ATOM_INT(_19mem_2217)){
            poke2_addr = (uint16_t *)_19mem_2217;
        }
        else {
            poke2_addr = (uint16_t *)(uintptr_t)(DBL_PTR(_19mem_2217)->dbl);
        }
        if (IS_ATOM_INT(_x_2221)) {
            *poke2_addr = (uint16_t)_x_2221;
        }
        else {
            *poke2_addr = (uint16_t)DBL_PTR(_x_2221)->dbl;
        }
        goto L1; // [34] 73

        /** convert.e:73			case 4 then*/
        case 4:

        /** convert.e:74				poke4( mem, x )*/
        if (IS_ATOM_INT(_19mem_2217)){
            poke4_addr = (uint32_t *)_19mem_2217;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_19mem_2217)->dbl);
        }
        if (IS_ATOM_INT(_x_2221)) {
            *poke4_addr = (uint32_t)_x_2221;
        }
        else {
            *poke4_addr = (uint32_t)DBL_PTR(_x_2221)->dbl;
        }
        goto L1; // [47] 73

        /** convert.e:75			case 8 then*/
        case 8:

        /** convert.e:76				poke8( mem, x )*/
        if (IS_ATOM_INT(_19mem_2217)){
            poke8_addr = (uint64_t *)_19mem_2217;
        }
        else {
            poke8_addr = (uint64_t *)(uintptr_t)(DBL_PTR(_19mem_2217)->dbl);
        }
        if (IS_ATOM_INT(_x_2221)) {
            *poke8_addr = (uint64_t)_x_2221;
        }
        else {
            *poke8_addr = (uint64_t)DBL_PTR(_x_2221)->dbl;
        }
        goto L1; // [60] 73

        /** convert.e:77			case else*/
        default:

        /** convert.e:78				return {}*/
        RefDS(_5);
        DeRef(_x_2221);
        return _5;
    ;}L1: 

    /** convert.e:80		return peek( mem & size )*/
    Concat((object_ptr)&_983, _19mem_2217, _size_2222);
    _1 = (object)SEQ_PTR(_983);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _984 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_983);
    _983 = NOVALUE;
    DeRef(_x_2221);
    return _984;
    ;
}


object _19int_to_bits(object _x_2260, object _nbits_2261)
{
    object _bits_2262 = NOVALUE;
    object _mask_2263 = NOVALUE;
    object _1010 = NOVALUE;
    object _1009 = NOVALUE;
    object _1007 = NOVALUE;
    object _1004 = NOVALUE;
    object _1003 = NOVALUE;
    object _1002 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:167		if nbits < 1 then*/
    if (_nbits_2261 >= 1)
    goto L1; // [5] 16

    /** convert.e:168			return {}*/
    RefDS(_5);
    DeRef(_x_2260);
    DeRef(_bits_2262);
    DeRef(_mask_2263);
    return _5;
L1: 

    /** convert.e:170		bits = repeat(0, nbits)*/
    DeRef(_bits_2262);
    _bits_2262 = Repeat(0, _nbits_2261);

    /** convert.e:171		if nbits <= 32 then*/
    if (_nbits_2261 > 32)
    goto L2; // [24] 75

    /** convert.e:173			mask = 1*/
    DeRef(_mask_2263);
    _mask_2263 = 1;

    /** convert.e:174			for i = 1 to nbits do*/
    _1002 = _nbits_2261;
    {
        object _i_2270;
        _i_2270 = 1;
L3: 
        if (_i_2270 > _1002){
            goto L4; // [38] 72
        }

        /** convert.e:175				bits[i] = and_bits(x, mask) and 1*/
        if (IS_ATOM_INT(_x_2260) && IS_ATOM_INT(_mask_2263)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_x_2260 & (uintptr_t)_mask_2263;
                 _1003 = MAKE_UINT(tu);
            }
        }
        else {
            if (IS_ATOM_INT(_x_2260)) {
                temp_d.dbl = (eudouble)_x_2260;
                _1003 = Dand_bits(&temp_d, DBL_PTR(_mask_2263));
            }
            else {
                if (IS_ATOM_INT(_mask_2263)) {
                    temp_d.dbl = (eudouble)_mask_2263;
                    _1003 = Dand_bits(DBL_PTR(_x_2260), &temp_d);
                }
                else
                _1003 = Dand_bits(DBL_PTR(_x_2260), DBL_PTR(_mask_2263));
            }
        }
        if (IS_ATOM_INT(_1003)) {
            _1004 = (_1003 != 0 && 1 != 0);
        }
        else {
            temp_d.dbl = (eudouble)1;
            _1004 = Dand(DBL_PTR(_1003), &temp_d);
        }
        DeRef(_1003);
        _1003 = NOVALUE;
        _2 = (object)SEQ_PTR(_bits_2262);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _bits_2262 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_2270);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _1004;
        if( _1 != _1004 ){
            DeRef(_1);
        }
        _1004 = NOVALUE;

        /** convert.e:176				mask *= 2*/
        _0 = _mask_2263;
        if (IS_ATOM_INT(_mask_2263) && IS_ATOM_INT(_mask_2263)) {
            _mask_2263 = _mask_2263 + _mask_2263;
            if ((object)((uintptr_t)_mask_2263 + (uintptr_t)HIGH_BITS) >= 0){
                _mask_2263 = NewDouble((eudouble)_mask_2263);
            }
        }
        else {
            if (IS_ATOM_INT(_mask_2263)) {
                _mask_2263 = NewDouble((eudouble)_mask_2263 + DBL_PTR(_mask_2263)->dbl);
            }
            else {
                if (IS_ATOM_INT(_mask_2263)) {
                    _mask_2263 = NewDouble(DBL_PTR(_mask_2263)->dbl + (eudouble)_mask_2263);
                }
                else
                _mask_2263 = NewDouble(DBL_PTR(_mask_2263)->dbl + DBL_PTR(_mask_2263)->dbl);
            }
        }
        DeRef(_0);

        /** convert.e:177			end for*/
        _i_2270 = _i_2270 + 1;
        goto L3; // [67] 45
L4: 
        ;
    }
    goto L5; // [72] 128
L2: 

    /** convert.e:180			if x < 0 then*/
    if (binary_op_a(GREATEREQ, _x_2260, 0)){
        goto L6; // [77] 92
    }

    /** convert.e:181				x += power(2, nbits) -- for 2's complement bit pattern*/
    _1007 = power(2, _nbits_2261);
    _0 = _x_2260;
    if (IS_ATOM_INT(_x_2260) && IS_ATOM_INT(_1007)) {
        _x_2260 = _x_2260 + _1007;
        if ((object)((uintptr_t)_x_2260 + (uintptr_t)HIGH_BITS) >= 0){
            _x_2260 = NewDouble((eudouble)_x_2260);
        }
    }
    else {
        if (IS_ATOM_INT(_x_2260)) {
            _x_2260 = NewDouble((eudouble)_x_2260 + DBL_PTR(_1007)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1007)) {
                _x_2260 = NewDouble(DBL_PTR(_x_2260)->dbl + (eudouble)_1007);
            }
            else
            _x_2260 = NewDouble(DBL_PTR(_x_2260)->dbl + DBL_PTR(_1007)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1007);
    _1007 = NOVALUE;
L6: 

    /** convert.e:183			for i = 1 to nbits do*/
    _1009 = _nbits_2261;
    {
        object _i_2281;
        _i_2281 = 1;
L7: 
        if (_i_2281 > _1009){
            goto L8; // [97] 127
        }

        /** convert.e:184				bits[i] = remainder(x, 2)*/
        if (IS_ATOM_INT(_x_2260)) {
            _1010 = (_x_2260 % 2);
        }
        else {
            temp_d.dbl = (eudouble)2;
            _1010 = Dremainder(DBL_PTR(_x_2260), &temp_d);
        }
        _2 = (object)SEQ_PTR(_bits_2262);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _bits_2262 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_2281);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _1010;
        if( _1 != _1010 ){
            DeRef(_1);
        }
        _1010 = NOVALUE;

        /** convert.e:185				x = floor(x / 2)*/
        _0 = _x_2260;
        if (IS_ATOM_INT(_x_2260)) {
            _x_2260 = _x_2260 >> 1;
        }
        else {
            _1 = binary_op(DIVIDE, _x_2260, 2);
            _x_2260 = unary_op(FLOOR, _1);
            DeRef(_1);
        }
        DeRef(_0);

        /** convert.e:186			end for*/
        _i_2281 = _i_2281 + 1;
        goto L7; // [122] 104
L8: 
        ;
    }
L5: 

    /** convert.e:188		return bits*/
    DeRef(_x_2260);
    DeRef(_mask_2263);
    return _bits_2262;
    ;
}


object _19bits_to_int(object _bits_2287)
{
    object _value_2288 = NOVALUE;
    object _p_2289 = NOVALUE;
    object _1013 = NOVALUE;
    object _1012 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:225		value = 0*/
    DeRef(_value_2288);
    _value_2288 = 0;

    /** convert.e:226		p = 1*/
    DeRef(_p_2289);
    _p_2289 = 1;

    /** convert.e:227		for i = 1 to length(bits) do*/
    if (IS_SEQUENCE(_bits_2287)){
            _1012 = SEQ_PTR(_bits_2287)->length;
    }
    else {
        _1012 = 1;
    }
    {
        object _i_2291;
        _i_2291 = 1;
L1: 
        if (_i_2291 > _1012){
            goto L2; // [18] 54
        }

        /** convert.e:228			if bits[i] then*/
        _2 = (object)SEQ_PTR(_bits_2287);
        _1013 = (object)*(((s1_ptr)_2)->base + _i_2291);
        if (_1013 == 0) {
            _1013 = NOVALUE;
            goto L3; // [31] 41
        }
        else {
            if (!IS_ATOM_INT(_1013) && DBL_PTR(_1013)->dbl == 0.0){
                _1013 = NOVALUE;
                goto L3; // [31] 41
            }
            _1013 = NOVALUE;
        }
        _1013 = NOVALUE;

        /** convert.e:229				value += p*/
        _0 = _value_2288;
        if (IS_ATOM_INT(_value_2288) && IS_ATOM_INT(_p_2289)) {
            _value_2288 = _value_2288 + _p_2289;
            if ((object)((uintptr_t)_value_2288 + (uintptr_t)HIGH_BITS) >= 0){
                _value_2288 = NewDouble((eudouble)_value_2288);
            }
        }
        else {
            if (IS_ATOM_INT(_value_2288)) {
                _value_2288 = NewDouble((eudouble)_value_2288 + DBL_PTR(_p_2289)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_2289)) {
                    _value_2288 = NewDouble(DBL_PTR(_value_2288)->dbl + (eudouble)_p_2289);
                }
                else
                _value_2288 = NewDouble(DBL_PTR(_value_2288)->dbl + DBL_PTR(_p_2289)->dbl);
            }
        }
        DeRef(_0);
L3: 

        /** convert.e:231			p += p*/
        _0 = _p_2289;
        if (IS_ATOM_INT(_p_2289) && IS_ATOM_INT(_p_2289)) {
            _p_2289 = _p_2289 + _p_2289;
            if ((object)((uintptr_t)_p_2289 + (uintptr_t)HIGH_BITS) >= 0){
                _p_2289 = NewDouble((eudouble)_p_2289);
            }
        }
        else {
            if (IS_ATOM_INT(_p_2289)) {
                _p_2289 = NewDouble((eudouble)_p_2289 + DBL_PTR(_p_2289)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_2289)) {
                    _p_2289 = NewDouble(DBL_PTR(_p_2289)->dbl + (eudouble)_p_2289);
                }
                else
                _p_2289 = NewDouble(DBL_PTR(_p_2289)->dbl + DBL_PTR(_p_2289)->dbl);
            }
        }
        DeRef(_0);

        /** convert.e:232		end for*/
        _i_2291 = _i_2291 + 1;
        goto L1; // [49] 25
L2: 
        ;
    }

    /** convert.e:233		return value*/
    DeRefDS(_bits_2287);
    DeRef(_p_2289);
    return _value_2288;
    ;
}


object _19atom_to_float64(object _a_2299)
{
    object _1016 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:262		return machine_func(M_A_TO_F64, a)*/
    _1016 = machine(46, _a_2299);
    DeRef(_a_2299);
    return _1016;
    ;
}


object _19atom_to_float80(object _a_2303)
{
    object _1017 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:268		return machine_func(M_A_TO_F80, a)*/
    _1017 = machine(105, _a_2303);
    DeRef(_a_2303);
    return _1017;
    ;
}


object _19float80_to_atom(object _bytes_2307)
{
    object _1018 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:274		return machine_func(M_F80_TO_A, bytes )*/
    _1018 = machine(101, _bytes_2307);
    DeRefDS(_bytes_2307);
    return _1018;
    ;
}


object _19atom_to_float32(object _a_2311)
{
    object _1019 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:312		return machine_func(M_A_TO_F32, a)*/
    _1019 = machine(48, _a_2311);
    DeRef(_a_2311);
    return _1019;
    ;
}


object _19float64_to_atom(object _ieee64_2315)
{
    object _1020 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:343		return machine_func(M_F64_TO_A, ieee64)*/
    _1020 = machine(47, _ieee64_2315);
    DeRefDS(_ieee64_2315);
    return _1020;
    ;
}


object _19float32_to_atom(object _ieee32_2319)
{
    object _1021 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:374		return machine_func(M_F32_TO_A, ieee32)*/
    _1021 = machine(49, _ieee32_2319);
    DeRefDS(_ieee32_2319);
    return _1021;
    ;
}


object _19to_number(object _text_in_2397, object _return_bad_pos_2398)
{
    object _lDotFound_2399 = NOVALUE;
    object _lSignFound_2400 = NOVALUE;
    object _lCharValue_2401 = NOVALUE;
    object _lBadPos_2402 = NOVALUE;
    object _lLeftSize_2403 = NOVALUE;
    object _lRightSize_2404 = NOVALUE;
    object _lLeftValue_2405 = NOVALUE;
    object _lRightValue_2406 = NOVALUE;
    object _lBase_2407 = NOVALUE;
    object _lPercent_2408 = NOVALUE;
    object _lResult_2409 = NOVALUE;
    object _lDigitCount_2410 = NOVALUE;
    object _lCurrencyFound_2411 = NOVALUE;
    object _lLastDigit_2412 = NOVALUE;
    object _lChar_2413 = NOVALUE;
    object _1141 = NOVALUE;
    object _1140 = NOVALUE;
    object _1133 = NOVALUE;
    object _1131 = NOVALUE;
    object _1130 = NOVALUE;
    object _1125 = NOVALUE;
    object _1124 = NOVALUE;
    object _1123 = NOVALUE;
    object _1122 = NOVALUE;
    object _1121 = NOVALUE;
    object _1120 = NOVALUE;
    object _1116 = NOVALUE;
    object _1112 = NOVALUE;
    object _1104 = NOVALUE;
    object _1094 = NOVALUE;
    object _1093 = NOVALUE;
    object _1087 = NOVALUE;
    object _1085 = NOVALUE;
    object _1079 = NOVALUE;
    object _1078 = NOVALUE;
    object _1077 = NOVALUE;
    object _1076 = NOVALUE;
    object _1075 = NOVALUE;
    object _1074 = NOVALUE;
    object _1073 = NOVALUE;
    object _1072 = NOVALUE;
    object _1071 = NOVALUE;
    object _1063 = NOVALUE;
    object _1062 = NOVALUE;
    object _1061 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:593		integer lDotFound = 0*/
    _lDotFound_2399 = 0;

    /** convert.e:594		integer lSignFound = 2*/
    _lSignFound_2400 = 2;

    /** convert.e:596		integer lBadPos = 0*/
    _lBadPos_2402 = 0;

    /** convert.e:597		atom    lLeftSize = 0*/
    DeRef(_lLeftSize_2403);
    _lLeftSize_2403 = 0;

    /** convert.e:598		atom    lRightSize = 1*/
    DeRef(_lRightSize_2404);
    _lRightSize_2404 = 1;

    /** convert.e:599		atom    lLeftValue = 0*/
    DeRef(_lLeftValue_2405);
    _lLeftValue_2405 = 0;

    /** convert.e:600		atom    lRightValue = 0*/
    DeRef(_lRightValue_2406);
    _lRightValue_2406 = 0;

    /** convert.e:601		integer lBase = 10*/
    _lBase_2407 = 10;

    /** convert.e:602		integer lPercent = 1*/
    _lPercent_2408 = 1;

    /** convert.e:604		integer lDigitCount = 0*/
    _lDigitCount_2410 = 0;

    /** convert.e:605		integer lCurrencyFound = 0*/
    _lCurrencyFound_2411 = 0;

    /** convert.e:606		integer lLastDigit = 0*/
    _lLastDigit_2412 = 0;

    /** convert.e:609		for i = 1 to length(text_in) do*/
    if (IS_SEQUENCE(_text_in_2397)){
            _1061 = SEQ_PTR(_text_in_2397)->length;
    }
    else {
        _1061 = 1;
    }
    {
        object _i_2415;
        _i_2415 = 1;
L1: 
        if (_i_2415 > _1061){
            goto L2; // [70] 672
        }

        /** convert.e:610			if not integer(text_in[i]) then*/
        _2 = (object)SEQ_PTR(_text_in_2397);
        _1062 = (object)*(((s1_ptr)_2)->base + _i_2415);
        if (IS_ATOM_INT(_1062))
        _1063 = 1;
        else if (IS_ATOM_DBL(_1062))
        _1063 = IS_ATOM_INT(DoubleToInt(_1062));
        else
        _1063 = 0;
        _1062 = NOVALUE;
        if (_1063 != 0)
        goto L3; // [86] 94
        _1063 = NOVALUE;

        /** convert.e:611				exit*/
        goto L2; // [91] 672
L3: 

        /** convert.e:614			lChar = text_in[i]*/
        _2 = (object)SEQ_PTR(_text_in_2397);
        _lChar_2413 = (object)*(((s1_ptr)_2)->base + _i_2415);
        if (!IS_ATOM_INT(_lChar_2413))
        _lChar_2413 = (object)DBL_PTR(_lChar_2413)->dbl;

        /** convert.e:615			switch lChar do*/
        _0 = _lChar_2413;
        switch ( _0 ){ 

            /** convert.e:616				case '-' then*/
            case 45:

            /** convert.e:617					if lSignFound = 2 then*/
            if (_lSignFound_2400 != 2)
            goto L4; // [113] 130

            /** convert.e:618						lSignFound = -1*/
            _lSignFound_2400 = -1;

            /** convert.e:619						lLastDigit = lDigitCount*/
            _lLastDigit_2412 = _lDigitCount_2410;
            goto L5; // [127] 654
L4: 

            /** convert.e:621						lBadPos = i*/
            _lBadPos_2402 = _i_2415;
            goto L5; // [136] 654

            /** convert.e:624				case '+' then*/
            case 43:

            /** convert.e:625					if lSignFound = 2 then*/
            if (_lSignFound_2400 != 2)
            goto L6; // [144] 161

            /** convert.e:626						lSignFound = 1*/
            _lSignFound_2400 = 1;

            /** convert.e:627						lLastDigit = lDigitCount*/
            _lLastDigit_2412 = _lDigitCount_2410;
            goto L5; // [158] 654
L6: 

            /** convert.e:629						lBadPos = i*/
            _lBadPos_2402 = _i_2415;
            goto L5; // [167] 654

            /** convert.e:632				case '#' then*/
            case 35:

            /** convert.e:633					if lDigitCount = 0 and lBase = 10 then*/
            _1071 = (_lDigitCount_2410 == 0);
            if (_1071 == 0) {
                goto L7; // [179] 199
            }
            _1073 = (_lBase_2407 == 10);
            if (_1073 == 0)
            {
                DeRef(_1073);
                _1073 = NOVALUE;
                goto L7; // [188] 199
            }
            else{
                DeRef(_1073);
                _1073 = NOVALUE;
            }

            /** convert.e:634						lBase = 16*/
            _lBase_2407 = 16;
            goto L5; // [196] 654
L7: 

            /** convert.e:636						lBadPos = i*/
            _lBadPos_2402 = _i_2415;
            goto L5; // [205] 654

            /** convert.e:639				case '@' then*/
            case 64:

            /** convert.e:640					if lDigitCount = 0  and lBase = 10 then*/
            _1074 = (_lDigitCount_2410 == 0);
            if (_1074 == 0) {
                goto L8; // [217] 237
            }
            _1076 = (_lBase_2407 == 10);
            if (_1076 == 0)
            {
                DeRef(_1076);
                _1076 = NOVALUE;
                goto L8; // [226] 237
            }
            else{
                DeRef(_1076);
                _1076 = NOVALUE;
            }

            /** convert.e:641						lBase = 8*/
            _lBase_2407 = 8;
            goto L5; // [234] 654
L8: 

            /** convert.e:643						lBadPos = i*/
            _lBadPos_2402 = _i_2415;
            goto L5; // [243] 654

            /** convert.e:646				case '!' then*/
            case 33:

            /** convert.e:647					if lDigitCount = 0  and lBase = 10 then*/
            _1077 = (_lDigitCount_2410 == 0);
            if (_1077 == 0) {
                goto L9; // [255] 275
            }
            _1079 = (_lBase_2407 == 10);
            if (_1079 == 0)
            {
                DeRef(_1079);
                _1079 = NOVALUE;
                goto L9; // [264] 275
            }
            else{
                DeRef(_1079);
                _1079 = NOVALUE;
            }

            /** convert.e:648						lBase = 2*/
            _lBase_2407 = 2;
            goto L5; // [272] 654
L9: 

            /** convert.e:650						lBadPos = i*/
            _lBadPos_2402 = _i_2415;
            goto L5; // [281] 654

            /** convert.e:653				case '$', '�', '�', '�', '�' then*/
            case 36:
            case 163:
            case 164:
            case 165:
            case 128:

            /** convert.e:654					if lCurrencyFound = 0 then*/
            if (_lCurrencyFound_2411 != 0)
            goto LA; // [297] 314

            /** convert.e:655						lCurrencyFound = 1*/
            _lCurrencyFound_2411 = 1;

            /** convert.e:656						lLastDigit = lDigitCount*/
            _lLastDigit_2412 = _lDigitCount_2410;
            goto L5; // [311] 654
LA: 

            /** convert.e:658						lBadPos = i*/
            _lBadPos_2402 = _i_2415;
            goto L5; // [320] 654

            /** convert.e:661				case '_' then -- grouping character*/
            case 95:

            /** convert.e:662					if lDigitCount = 0 or lLastDigit != 0 then*/
            _1085 = (_lDigitCount_2410 == 0);
            if (_1085 != 0) {
                goto LB; // [332] 345
            }
            _1087 = (_lLastDigit_2412 != 0);
            if (_1087 == 0)
            {
                DeRef(_1087);
                _1087 = NOVALUE;
                goto L5; // [341] 654
            }
            else{
                DeRef(_1087);
                _1087 = NOVALUE;
            }
LB: 

            /** convert.e:663						lBadPos = i*/
            _lBadPos_2402 = _i_2415;
            goto L5; // [351] 654

            /** convert.e:666				case '.', ',' then*/
            case 46:
            case 44:

            /** convert.e:667					if lLastDigit = 0 then*/
            if (_lLastDigit_2412 != 0)
            goto LC; // [361] 400

            /** convert.e:668						if decimal_mark = lChar then*/
            if (46 != _lChar_2413)
            goto L5; // [369] 654

            /** convert.e:669							if lDotFound = 0 then*/
            if (_lDotFound_2399 != 0)
            goto LD; // [375] 387

            /** convert.e:670								lDotFound = 1*/
            _lDotFound_2399 = 1;
            goto L5; // [384] 654
LD: 

            /** convert.e:672								lBadPos = i*/
            _lBadPos_2402 = _i_2415;
            goto L5; // [393] 654
            goto L5; // [397] 654
LC: 

            /** convert.e:678						lBadPos = i*/
            _lBadPos_2402 = _i_2415;
            goto L5; // [406] 654

            /** convert.e:681				case '%' then*/
            case 37:

            /** convert.e:682					lLastDigit = lDigitCount*/
            _lLastDigit_2412 = _lDigitCount_2410;

            /** convert.e:683					if lPercent = 1 then*/
            if (_lPercent_2408 != 1)
            goto LE; // [419] 431

            /** convert.e:684						lPercent = 100*/
            _lPercent_2408 = 100;
            goto L5; // [428] 654
LE: 

            /** convert.e:686						if text_in[i-1] = '%' then*/
            _1093 = _i_2415 - 1;
            _2 = (object)SEQ_PTR(_text_in_2397);
            _1094 = (object)*(((s1_ptr)_2)->base + _1093);
            if (binary_op_a(NOTEQ, _1094, 37)){
                _1094 = NOVALUE;
                goto LF; // [441] 456
            }
            _1094 = NOVALUE;

            /** convert.e:687							lPercent *= 10 -- Yes ten not one hundred.*/
            _lPercent_2408 = _lPercent_2408 * 10;
            goto L5; // [453] 654
LF: 

            /** convert.e:689							lBadPos = i*/
            _lBadPos_2402 = _i_2415;
            goto L5; // [463] 654

            /** convert.e:693				case '\t', ' ', #A0 then*/
            case 9:
            case 32:
            case 160:

            /** convert.e:694					if lDigitCount = 0 then*/
            if (_lDigitCount_2410 != 0)
            goto L10; // [475] 482
            goto L5; // [479] 654
L10: 

            /** convert.e:697						lLastDigit = i*/
            _lLastDigit_2412 = _i_2415;
            goto L5; // [488] 654

            /** convert.e:700				case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',*/
            case 48:
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
            case 65:
            case 66:
            case 67:
            case 68:
            case 69:
            case 70:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 102:

            /** convert.e:703		            lCharValue = find(lChar, vDigits) - 1*/
            _1104 = find_from(_lChar_2413, _19vDigits_2384, 1);
            _lCharValue_2401 = _1104 - 1;
            _1104 = NOVALUE;

            /** convert.e:704		            if lCharValue > 15 then*/
            if (_lCharValue_2401 <= 15)
            goto L11; // [549] 560

            /** convert.e:705		            	lCharValue -= 6*/
            _lCharValue_2401 = _lCharValue_2401 - 6;
L11: 

            /** convert.e:708		            if lCharValue >= lBase then*/
            if (_lCharValue_2401 < _lBase_2407)
            goto L12; // [562] 574

            /** convert.e:709		                lBadPos = i*/
            _lBadPos_2402 = _i_2415;
            goto L5; // [571] 654
L12: 

            /** convert.e:711		            elsif lLastDigit != 0 then  -- shouldn't be any more digits*/
            if (_lLastDigit_2412 == 0)
            goto L13; // [576] 588

            /** convert.e:712						lBadPos = i*/
            _lBadPos_2402 = _i_2415;
            goto L5; // [585] 654
L13: 

            /** convert.e:714					elsif lDotFound = 1 then*/
            if (_lDotFound_2399 != 1)
            goto L14; // [590] 619

            /** convert.e:715						lRightSize *= lBase*/
            _0 = _lRightSize_2404;
            if (IS_ATOM_INT(_lRightSize_2404)) {
                if (_lRightSize_2404 == (short)_lRightSize_2404 && _lBase_2407 <= INT15 && _lBase_2407 >= -INT15){
                    _lRightSize_2404 = _lRightSize_2404 * _lBase_2407;
                }
                else{
                    _lRightSize_2404 = NewDouble(_lRightSize_2404 * (eudouble)_lBase_2407);
                }
            }
            else {
                _lRightSize_2404 = NewDouble(DBL_PTR(_lRightSize_2404)->dbl * (eudouble)_lBase_2407);
            }
            DeRef(_0);

            /** convert.e:716						lRightValue = (lRightValue * lBase) + lCharValue*/
            if (IS_ATOM_INT(_lRightValue_2406)) {
                if (_lRightValue_2406 == (short)_lRightValue_2406 && _lBase_2407 <= INT15 && _lBase_2407 >= -INT15){
                    _1112 = _lRightValue_2406 * _lBase_2407;
                }
                else{
                    _1112 = NewDouble(_lRightValue_2406 * (eudouble)_lBase_2407);
                }
            }
            else {
                _1112 = NewDouble(DBL_PTR(_lRightValue_2406)->dbl * (eudouble)_lBase_2407);
            }
            DeRef(_lRightValue_2406);
            if (IS_ATOM_INT(_1112)) {
                _lRightValue_2406 = _1112 + _lCharValue_2401;
                if ((object)((uintptr_t)_lRightValue_2406 + (uintptr_t)HIGH_BITS) >= 0){
                    _lRightValue_2406 = NewDouble((eudouble)_lRightValue_2406);
                }
            }
            else {
                _lRightValue_2406 = NewDouble(DBL_PTR(_1112)->dbl + (eudouble)_lCharValue_2401);
            }
            DeRef(_1112);
            _1112 = NOVALUE;

            /** convert.e:717						lDigitCount += 1*/
            _lDigitCount_2410 = _lDigitCount_2410 + 1;
            goto L5; // [616] 654
L14: 

            /** convert.e:719						lLeftSize += 1*/
            _0 = _lLeftSize_2403;
            if (IS_ATOM_INT(_lLeftSize_2403)) {
                _lLeftSize_2403 = _lLeftSize_2403 + 1;
                if (_lLeftSize_2403 > MAXINT){
                    _lLeftSize_2403 = NewDouble((eudouble)_lLeftSize_2403);
                }
            }
            else
            _lLeftSize_2403 = binary_op(PLUS, 1, _lLeftSize_2403);
            DeRef(_0);

            /** convert.e:720						lLeftValue = (lLeftValue * lBase) + lCharValue*/
            if (IS_ATOM_INT(_lLeftValue_2405)) {
                if (_lLeftValue_2405 == (short)_lLeftValue_2405 && _lBase_2407 <= INT15 && _lBase_2407 >= -INT15){
                    _1116 = _lLeftValue_2405 * _lBase_2407;
                }
                else{
                    _1116 = NewDouble(_lLeftValue_2405 * (eudouble)_lBase_2407);
                }
            }
            else {
                _1116 = NewDouble(DBL_PTR(_lLeftValue_2405)->dbl * (eudouble)_lBase_2407);
            }
            DeRef(_lLeftValue_2405);
            if (IS_ATOM_INT(_1116)) {
                _lLeftValue_2405 = _1116 + _lCharValue_2401;
                if ((object)((uintptr_t)_lLeftValue_2405 + (uintptr_t)HIGH_BITS) >= 0){
                    _lLeftValue_2405 = NewDouble((eudouble)_lLeftValue_2405);
                }
            }
            else {
                _lLeftValue_2405 = NewDouble(DBL_PTR(_1116)->dbl + (eudouble)_lCharValue_2401);
            }
            DeRef(_1116);
            _1116 = NOVALUE;

            /** convert.e:721						lDigitCount += 1*/
            _lDigitCount_2410 = _lDigitCount_2410 + 1;
            goto L5; // [642] 654

            /** convert.e:724				case else*/
            default:

            /** convert.e:725					lBadPos = i*/
            _lBadPos_2402 = _i_2415;
        ;}L5: 

        /** convert.e:729			if lBadPos != 0 then*/
        if (_lBadPos_2402 == 0)
        goto L15; // [656] 665

        /** convert.e:730				exit*/
        goto L2; // [662] 672
L15: 

        /** convert.e:732		end for*/
        _i_2415 = _i_2415 + 1;
        goto L1; // [667] 77
L2: 
        ;
    }

    /** convert.e:736		if lBadPos = 0 and lDigitCount = 0 then*/
    _1120 = (_lBadPos_2402 == 0);
    if (_1120 == 0) {
        goto L16; // [678] 696
    }
    _1122 = (_lDigitCount_2410 == 0);
    if (_1122 == 0)
    {
        DeRef(_1122);
        _1122 = NOVALUE;
        goto L16; // [687] 696
    }
    else{
        DeRef(_1122);
        _1122 = NOVALUE;
    }

    /** convert.e:737			lBadPos = 1*/
    _lBadPos_2402 = 1;
L16: 

    /** convert.e:740		if return_bad_pos = 0 and lBadPos != 0 then*/
    _1123 = (_return_bad_pos_2398 == 0);
    if (_1123 == 0) {
        goto L17; // [702] 721
    }
    _1125 = (_lBadPos_2402 != 0);
    if (_1125 == 0)
    {
        DeRef(_1125);
        _1125 = NOVALUE;
        goto L17; // [711] 721
    }
    else{
        DeRef(_1125);
        _1125 = NOVALUE;
    }

    /** convert.e:741			return 0*/
    DeRefDS(_text_in_2397);
    DeRef(_lLeftSize_2403);
    DeRef(_lRightSize_2404);
    DeRef(_lLeftValue_2405);
    DeRef(_lRightValue_2406);
    DeRef(_lResult_2409);
    DeRef(_1120);
    _1120 = NOVALUE;
    DeRef(_1077);
    _1077 = NOVALUE;
    DeRef(_1085);
    _1085 = NOVALUE;
    DeRef(_1074);
    _1074 = NOVALUE;
    DeRef(_1071);
    _1071 = NOVALUE;
    DeRef(_1123);
    _1123 = NOVALUE;
    DeRef(_1093);
    _1093 = NOVALUE;
    return 0;
L17: 

    /** convert.e:744		if lRightValue = 0 then*/
    if (binary_op_a(NOTEQ, _lRightValue_2406, 0)){
        goto L18; // [723] 751
    }

    /** convert.e:746		    if lPercent != 1 then*/
    if (_lPercent_2408 == 1)
    goto L19; // [729] 742

    /** convert.e:747				lResult = (lLeftValue / lPercent)*/
    DeRef(_lResult_2409);
    if (IS_ATOM_INT(_lLeftValue_2405)) {
        _lResult_2409 = (_lLeftValue_2405 % _lPercent_2408) ? NewDouble((eudouble)_lLeftValue_2405 / _lPercent_2408) : (_lLeftValue_2405 / _lPercent_2408);
    }
    else {
        _lResult_2409 = NewDouble(DBL_PTR(_lLeftValue_2405)->dbl / (eudouble)_lPercent_2408);
    }
    goto L1A; // [739] 786
L19: 

    /** convert.e:749		        lResult = lLeftValue*/
    Ref(_lLeftValue_2405);
    DeRef(_lResult_2409);
    _lResult_2409 = _lLeftValue_2405;
    goto L1A; // [748] 786
L18: 

    /** convert.e:752		    if lPercent != 1 then*/
    if (_lPercent_2408 == 1)
    goto L1B; // [753] 774

    /** convert.e:753		        lResult = (lLeftValue  + (lRightValue / (lRightSize))) / lPercent*/
    if (IS_ATOM_INT(_lRightValue_2406) && IS_ATOM_INT(_lRightSize_2404)) {
        _1130 = (_lRightValue_2406 % _lRightSize_2404) ? NewDouble((eudouble)_lRightValue_2406 / _lRightSize_2404) : (_lRightValue_2406 / _lRightSize_2404);
    }
    else {
        if (IS_ATOM_INT(_lRightValue_2406)) {
            _1130 = NewDouble((eudouble)_lRightValue_2406 / DBL_PTR(_lRightSize_2404)->dbl);
        }
        else {
            if (IS_ATOM_INT(_lRightSize_2404)) {
                _1130 = NewDouble(DBL_PTR(_lRightValue_2406)->dbl / (eudouble)_lRightSize_2404);
            }
            else
            _1130 = NewDouble(DBL_PTR(_lRightValue_2406)->dbl / DBL_PTR(_lRightSize_2404)->dbl);
        }
    }
    if (IS_ATOM_INT(_lLeftValue_2405) && IS_ATOM_INT(_1130)) {
        _1131 = _lLeftValue_2405 + _1130;
        if ((object)((uintptr_t)_1131 + (uintptr_t)HIGH_BITS) >= 0){
            _1131 = NewDouble((eudouble)_1131);
        }
    }
    else {
        if (IS_ATOM_INT(_lLeftValue_2405)) {
            _1131 = NewDouble((eudouble)_lLeftValue_2405 + DBL_PTR(_1130)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1130)) {
                _1131 = NewDouble(DBL_PTR(_lLeftValue_2405)->dbl + (eudouble)_1130);
            }
            else
            _1131 = NewDouble(DBL_PTR(_lLeftValue_2405)->dbl + DBL_PTR(_1130)->dbl);
        }
    }
    DeRef(_1130);
    _1130 = NOVALUE;
    DeRef(_lResult_2409);
    if (IS_ATOM_INT(_1131)) {
        _lResult_2409 = (_1131 % _lPercent_2408) ? NewDouble((eudouble)_1131 / _lPercent_2408) : (_1131 / _lPercent_2408);
    }
    else {
        _lResult_2409 = NewDouble(DBL_PTR(_1131)->dbl / (eudouble)_lPercent_2408);
    }
    DeRef(_1131);
    _1131 = NOVALUE;
    goto L1C; // [771] 785
L1B: 

    /** convert.e:755		        lResult = lLeftValue + (lRightValue / lRightSize)*/
    if (IS_ATOM_INT(_lRightValue_2406) && IS_ATOM_INT(_lRightSize_2404)) {
        _1133 = (_lRightValue_2406 % _lRightSize_2404) ? NewDouble((eudouble)_lRightValue_2406 / _lRightSize_2404) : (_lRightValue_2406 / _lRightSize_2404);
    }
    else {
        if (IS_ATOM_INT(_lRightValue_2406)) {
            _1133 = NewDouble((eudouble)_lRightValue_2406 / DBL_PTR(_lRightSize_2404)->dbl);
        }
        else {
            if (IS_ATOM_INT(_lRightSize_2404)) {
                _1133 = NewDouble(DBL_PTR(_lRightValue_2406)->dbl / (eudouble)_lRightSize_2404);
            }
            else
            _1133 = NewDouble(DBL_PTR(_lRightValue_2406)->dbl / DBL_PTR(_lRightSize_2404)->dbl);
        }
    }
    DeRef(_lResult_2409);
    if (IS_ATOM_INT(_lLeftValue_2405) && IS_ATOM_INT(_1133)) {
        _lResult_2409 = _lLeftValue_2405 + _1133;
        if ((object)((uintptr_t)_lResult_2409 + (uintptr_t)HIGH_BITS) >= 0){
            _lResult_2409 = NewDouble((eudouble)_lResult_2409);
        }
    }
    else {
        if (IS_ATOM_INT(_lLeftValue_2405)) {
            _lResult_2409 = NewDouble((eudouble)_lLeftValue_2405 + DBL_PTR(_1133)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1133)) {
                _lResult_2409 = NewDouble(DBL_PTR(_lLeftValue_2405)->dbl + (eudouble)_1133);
            }
            else
            _lResult_2409 = NewDouble(DBL_PTR(_lLeftValue_2405)->dbl + DBL_PTR(_1133)->dbl);
        }
    }
    DeRef(_1133);
    _1133 = NOVALUE;
L1C: 
L1A: 

    /** convert.e:759		if lSignFound < 0 then*/
    if (_lSignFound_2400 >= 0)
    goto L1D; // [788] 800

    /** convert.e:760			lResult = -lResult*/
    _0 = _lResult_2409;
    if (IS_ATOM_INT(_lResult_2409)) {
        if ((uintptr_t)_lResult_2409 == (uintptr_t)HIGH_BITS){
            _lResult_2409 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _lResult_2409 = - _lResult_2409;
        }
    }
    else {
        _lResult_2409 = unary_op(UMINUS, _lResult_2409);
    }
    DeRef(_0);
L1D: 

    /** convert.e:763		if return_bad_pos = 0 then*/
    if (_return_bad_pos_2398 != 0)
    goto L1E; // [802] 815

    /** convert.e:764			return lResult*/
    DeRefDS(_text_in_2397);
    DeRef(_lLeftSize_2403);
    DeRef(_lRightSize_2404);
    DeRef(_lLeftValue_2405);
    DeRef(_lRightValue_2406);
    DeRef(_1120);
    _1120 = NOVALUE;
    DeRef(_1077);
    _1077 = NOVALUE;
    DeRef(_1085);
    _1085 = NOVALUE;
    DeRef(_1074);
    _1074 = NOVALUE;
    DeRef(_1071);
    _1071 = NOVALUE;
    DeRef(_1123);
    _1123 = NOVALUE;
    DeRef(_1093);
    _1093 = NOVALUE;
    return _lResult_2409;
L1E: 

    /** convert.e:767		if return_bad_pos = -1 then*/
    if (_return_bad_pos_2398 != -1)
    goto L1F; // [817] 850

    /** convert.e:768			if lBadPos = 0 then*/
    if (_lBadPos_2402 != 0)
    goto L20; // [823] 838

    /** convert.e:769				return lResult*/
    DeRefDS(_text_in_2397);
    DeRef(_lLeftSize_2403);
    DeRef(_lRightSize_2404);
    DeRef(_lLeftValue_2405);
    DeRef(_lRightValue_2406);
    DeRef(_1120);
    _1120 = NOVALUE;
    DeRef(_1077);
    _1077 = NOVALUE;
    DeRef(_1085);
    _1085 = NOVALUE;
    DeRef(_1074);
    _1074 = NOVALUE;
    DeRef(_1071);
    _1071 = NOVALUE;
    DeRef(_1123);
    _1123 = NOVALUE;
    DeRef(_1093);
    _1093 = NOVALUE;
    return _lResult_2409;
    goto L21; // [835] 849
L20: 

    /** convert.e:771				return {lBadPos}	*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _lBadPos_2402;
    _1140 = MAKE_SEQ(_1);
    DeRefDS(_text_in_2397);
    DeRef(_lLeftSize_2403);
    DeRef(_lRightSize_2404);
    DeRef(_lLeftValue_2405);
    DeRef(_lRightValue_2406);
    DeRef(_lResult_2409);
    DeRef(_1120);
    _1120 = NOVALUE;
    DeRef(_1077);
    _1077 = NOVALUE;
    DeRef(_1085);
    _1085 = NOVALUE;
    DeRef(_1074);
    _1074 = NOVALUE;
    DeRef(_1071);
    _1071 = NOVALUE;
    DeRef(_1123);
    _1123 = NOVALUE;
    DeRef(_1093);
    _1093 = NOVALUE;
    return _1140;
L21: 
L1F: 

    /** convert.e:775		return {lResult, lBadPos}*/
    Ref(_lResult_2409);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _lResult_2409;
    ((intptr_t *)_2)[2] = _lBadPos_2402;
    _1141 = MAKE_SEQ(_1);
    DeRefDS(_text_in_2397);
    DeRef(_lLeftSize_2403);
    DeRef(_lRightSize_2404);
    DeRef(_lLeftValue_2405);
    DeRef(_lRightValue_2406);
    DeRef(_lResult_2409);
    DeRef(_1140);
    _1140 = NOVALUE;
    DeRef(_1120);
    _1120 = NOVALUE;
    DeRef(_1077);
    _1077 = NOVALUE;
    DeRef(_1085);
    _1085 = NOVALUE;
    DeRef(_1074);
    _1074 = NOVALUE;
    DeRef(_1071);
    _1071 = NOVALUE;
    DeRef(_1123);
    _1123 = NOVALUE;
    DeRef(_1093);
    _1093 = NOVALUE;
    return _1141;
    ;
}



// 0x09F018B6
