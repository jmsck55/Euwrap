// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _49screen_output(object _f_49272, object _msg_49273)
{
    object _0, _1, _2;
    

    /** error.e:44		puts(f, msg)*/
    EPuts(2, _msg_49273); // DJP 

    /** error.e:45	end procedure*/
    DeRefDS(_msg_49273);
    return;
    ;
}


void _49Warning(object _msg_49276, object _mask_49277, object _args_49278)
{
    object _orig_mask_49279 = NOVALUE;
    object _text_49280 = NOVALUE;
    object _w_name_49281 = NOVALUE;
    object _25314 = NOVALUE;
    object _25312 = NOVALUE;
    object _25310 = NOVALUE;
    object _25307 = NOVALUE;
    object _25302 = NOVALUE;
    object _25300 = NOVALUE;
    object _25299 = NOVALUE;
    object _25298 = NOVALUE;
    object _25297 = NOVALUE;
    object _25295 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:54		if display_warnings = 0 then*/
    if (_49display_warnings_49260 != 0)
    goto L1; // [9] 19

    /** error.e:55			return*/
    DeRef(_msg_49276);
    DeRefDS(_args_49278);
    DeRef(_text_49280);
    DeRef(_w_name_49281);
    return;
L1: 

    /** error.e:58		if not Strict_is_on or Strict_Override then*/
    _25295 = (_12Strict_is_on_20292 == 0);
    if (_25295 != 0) {
        goto L2; // [26] 37
    }
    if (_12Strict_Override_20293 == 0)
    {
        goto L3; // [33] 56
    }
    else{
    }
L2: 

    /** error.e:59			if find(mask, strict_only_warnings) then*/
    _25297 = find_from(_mask_49277, _12strict_only_warnings_20290, 1);
    if (_25297 == 0)
    {
        _25297 = NOVALUE;
        goto L4; // [46] 55
    }
    else{
        _25297 = NOVALUE;
    }

    /** error.e:60				return*/
    DeRef(_msg_49276);
    DeRefDS(_args_49278);
    DeRef(_text_49280);
    DeRef(_w_name_49281);
    DeRef(_25295);
    _25295 = NOVALUE;
    return;
L4: 
L3: 

    /** error.e:64		orig_mask = mask -- =0 for non maskable warnings - none implemented so far*/
    _orig_mask_49279 = _mask_49277;

    /** error.e:65		if Strict_is_on and Strict_Override = 0 then*/
    if (_12Strict_is_on_20292 == 0) {
        goto L5; // [65] 85
    }
    _25299 = (_12Strict_Override_20293 == 0);
    if (_25299 == 0)
    {
        DeRef(_25299);
        _25299 = NOVALUE;
        goto L5; // [76] 85
    }
    else{
        DeRef(_25299);
        _25299 = NOVALUE;
    }

    /** error.e:66			mask = 0*/
    _mask_49277 = 0;
L5: 

    /** error.e:69		if mask = 0 or and_bits(OpWarning, mask) then*/
    _25300 = (_mask_49277 == 0);
    if (_25300 != 0) {
        goto L6; // [91] 106
    }
    {uintptr_t tu;
         tu = (uintptr_t)_12OpWarning_20294 & (uintptr_t)_mask_49277;
         _25302 = MAKE_UINT(tu);
    }
    if (_25302 == 0) {
        DeRef(_25302);
        _25302 = NOVALUE;
        goto L7; // [102] 215
    }
    else {
        if (!IS_ATOM_INT(_25302) && DBL_PTR(_25302)->dbl == 0.0){
            DeRef(_25302);
            _25302 = NOVALUE;
            goto L7; // [102] 215
        }
        DeRef(_25302);
        _25302 = NOVALUE;
    }
    DeRef(_25302);
    _25302 = NOVALUE;
L6: 

    /** error.e:70			if orig_mask != 0 then*/
    if (_orig_mask_49279 == 0)
    goto L8; // [108] 122

    /** error.e:71				orig_mask = find(orig_mask,warning_flags)*/
    _orig_mask_49279 = find_from(_orig_mask_49279, _12warning_flags_20269, 1);
L8: 

    /** error.e:74			if orig_mask != 0 then*/
    if (_orig_mask_49279 == 0)
    goto L9; // [124] 145

    /** error.e:75				w_name = "{ " & warning_names[orig_mask] & " }"*/
    _2 = (object)SEQ_PTR(_12warning_names_20271);
    _25307 = (object)*(((s1_ptr)_2)->base + _orig_mask_49279);
    {
        object concat_list[3];

        concat_list[0] = _25308;
        concat_list[1] = _25307;
        concat_list[2] = _25306;
        Concat_N((object_ptr)&_w_name_49281, concat_list, 3);
    }
    _25307 = NOVALUE;
    goto LA; // [142] 153
L9: 

    /** error.e:77				w_name = "" -- not maskable*/
    RefDS(_22015);
    DeRef(_w_name_49281);
    _w_name_49281 = _22015;
LA: 

    /** error.e:80			if atom(msg) then*/
    _25310 = IS_ATOM(_msg_49276);
    if (_25310 == 0)
    {
        _25310 = NOVALUE;
        goto LB; // [158] 170
    }
    else{
        _25310 = NOVALUE;
    }

    /** error.e:81				msg = GetMsgText(msg, 1, args)*/
    Ref(_msg_49276);
    RefDS(_args_49278);
    _0 = _msg_49276;
    _msg_49276 = _30GetMsgText(_msg_49276, 1, _args_49278);
    DeRef(_0);
LB: 

    /** error.e:84			text = GetMsgText(WARNING_1T2, 0, {w_name, msg})*/
    Ref(_msg_49276);
    RefDS(_w_name_49281);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _w_name_49281;
    ((intptr_t *)_2)[2] = _msg_49276;
    _25312 = MAKE_SEQ(_1);
    _0 = _text_49280;
    _text_49280 = _30GetMsgText(204, 0, _25312);
    DeRef(_0);
    _25312 = NOVALUE;

    /** error.e:85			if find(text, warning_list) then*/
    _25314 = find_from(_text_49280, _49warning_list_49269, 1);
    if (_25314 == 0)
    {
        _25314 = NOVALUE;
        goto LC; // [197] 206
    }
    else{
        _25314 = NOVALUE;
    }

    /** error.e:86				return -- duplicate*/
    DeRef(_msg_49276);
    DeRefDS(_args_49278);
    DeRefDS(_text_49280);
    DeRefDS(_w_name_49281);
    DeRef(_25295);
    _25295 = NOVALUE;
    DeRef(_25300);
    _25300 = NOVALUE;
    return;
LC: 

    /** error.e:89			warning_list = append(warning_list, text)*/
    RefDS(_text_49280);
    Append(&_49warning_list_49269, _49warning_list_49269, _text_49280);
L7: 

    /** error.e:91	end procedure*/
    DeRef(_msg_49276);
    DeRefDS(_args_49278);
    DeRef(_text_49280);
    DeRef(_w_name_49281);
    DeRef(_25295);
    _25295 = NOVALUE;
    DeRef(_25300);
    _25300 = NOVALUE;
    return;
    ;
}


object _49ShowWarnings()
{
    object _c_49346 = NOVALUE;
    object _errfile_49347 = NOVALUE;
    object _twf_49348 = NOVALUE;
    object _25353 = NOVALUE;
    object _25350 = NOVALUE;
    object _25349 = NOVALUE;
    object _25348 = NOVALUE;
    object _25347 = NOVALUE;
    object _25346 = NOVALUE;
    object _25345 = NOVALUE;
    object _25343 = NOVALUE;
    object _25342 = NOVALUE;
    object _25341 = NOVALUE;
    object _25339 = NOVALUE;
    object _25338 = NOVALUE;
    object _25337 = NOVALUE;
    object _25336 = NOVALUE;
    object _25334 = NOVALUE;
    object _25330 = NOVALUE;
    object _25328 = NOVALUE;
    object _25327 = NOVALUE;
    object _25326 = NOVALUE;
    object _25324 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:117		if display_warnings = 0 or length(warning_list) = 0 then*/
    _25324 = (_49display_warnings_49260 == 0);
    if (_25324 != 0) {
        goto L1; // [9] 27
    }
    if (IS_SEQUENCE(_49warning_list_49269)){
            _25326 = SEQ_PTR(_49warning_list_49269)->length;
    }
    else {
        _25326 = 1;
    }
    _25327 = (_25326 == 0);
    _25326 = NOVALUE;
    if (_25327 == 0)
    {
        DeRef(_25327);
        _25327 = NOVALUE;
        goto L2; // [23] 39
    }
    else{
        DeRef(_25327);
        _25327 = NOVALUE;
    }
L1: 

    /** error.e:118			return length(warning_list)*/
    if (IS_SEQUENCE(_49warning_list_49269)){
            _25328 = SEQ_PTR(_49warning_list_49269)->length;
    }
    else {
        _25328 = 1;
    }
    DeRef(_25324);
    _25324 = NOVALUE;
    return _25328;
L2: 

    /** error.e:121		if TempErrFile > 0 then*/
    if (_49TempErrFile_49258 <= 0)
    goto L3; // [43] 57

    /** error.e:122			errfile = TempErrFile*/
    _errfile_49347 = _49TempErrFile_49258;
    goto L4; // [54] 67
L3: 

    /** error.e:124			errfile = STDERR*/
    _errfile_49347 = 2;
L4: 

    /** error.e:127		if not integer(TempWarningName) then*/
    if (IS_ATOM_INT(_12TempWarningName_20240))
    _25330 = 1;
    else if (IS_ATOM_DBL(_12TempWarningName_20240))
    _25330 = IS_ATOM_INT(DoubleToInt(_12TempWarningName_20240));
    else
    _25330 = 0;
    if (_25330 != 0)
    goto L5; // [74] 183
    _25330 = NOVALUE;

    /** error.e:128			twf = open(TempWarningName,"w")*/
    _twf_49348 = EOpen(_12TempWarningName_20240, _22151, 0);

    /** error.e:129			if twf = -1 then*/
    if (_twf_49348 != -1)
    goto L6; // [88] 140

    /** error.e:130				ShowMsg(errfile, UNABLE_TO_CREATE_WARNING_FILE_1, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_12TempWarningName_20240);
    ((intptr_t*)_2)[1] = _12TempWarningName_20240;
    _25334 = MAKE_SEQ(_1);
    _30ShowMsg(_errfile_49347, 205, _25334, 1);
    _25334 = NOVALUE;

    /** error.e:131				if errfile != STDERR then*/
    if (_errfile_49347 == 2)
    goto L7; // [114] 177

    /** error.e:132					ShowMsg(STDERR, UNABLE_TO_CREATE_WARNING_FILE_1, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_12TempWarningName_20240);
    ((intptr_t*)_2)[1] = _12TempWarningName_20240;
    _25336 = MAKE_SEQ(_1);
    _30ShowMsg(2, 205, _25336, 1);
    _25336 = NOVALUE;
    goto L7; // [137] 177
L6: 

    /** error.e:135				for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_49warning_list_49269)){
            _25337 = SEQ_PTR(_49warning_list_49269)->length;
    }
    else {
        _25337 = 1;
    }
    {
        object _i_49381;
        _i_49381 = 1;
L8: 
        if (_i_49381 > _25337){
            goto L9; // [147] 172
        }

        /** error.e:136					puts(twf, warning_list[i])*/
        _2 = (object)SEQ_PTR(_49warning_list_49269);
        _25338 = (object)*(((s1_ptr)_2)->base + _i_49381);
        EPuts(_twf_49348, _25338); // DJP 
        _25338 = NOVALUE;

        /** error.e:137				end for*/
        _i_49381 = _i_49381 + 1;
        goto L8; // [167] 154
L9: 
        ;
    }

    /** error.e:138			    close(twf)*/
    EClose(_twf_49348);
L7: 

    /** error.e:140			TempWarningName = 99 -- Flag that we have done this already.*/
    DeRef(_12TempWarningName_20240);
    _12TempWarningName_20240 = 99;
L5: 

    /** error.e:143		if batch_job = 0 or errfile != STDERR then*/
    _25339 = (_12batch_job_20239 == 0);
    if (_25339 != 0) {
        goto LA; // [191] 208
    }
    _25341 = (_errfile_49347 != 2);
    if (_25341 == 0)
    {
        DeRef(_25341);
        _25341 = NOVALUE;
        goto LB; // [204] 317
    }
    else{
        DeRef(_25341);
        _25341 = NOVALUE;
    }
LA: 

    /** error.e:144			for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_49warning_list_49269)){
            _25342 = SEQ_PTR(_49warning_list_49269)->length;
    }
    else {
        _25342 = 1;
    }
    {
        object _i_49392;
        _i_49392 = 1;
LC: 
        if (_i_49392 > _25342){
            goto LD; // [215] 316
        }

        /** error.e:145				puts(errfile, warning_list[i])*/
        _2 = (object)SEQ_PTR(_49warning_list_49269);
        _25343 = (object)*(((s1_ptr)_2)->base + _i_49392);
        EPuts(_errfile_49347, _25343); // DJP 
        _25343 = NOVALUE;

        /** error.e:146				if errfile = STDERR then*/
        if (_errfile_49347 != 2)
        goto LE; // [239] 309

        /** error.e:147					if remainder(i, 20) = 0 and batch_job = 0 and test_only = 0 then*/
        _25345 = (_i_49392 % 20);
        _25346 = (_25345 == 0);
        _25345 = NOVALUE;
        if (_25346 == 0) {
            _25347 = 0;
            goto LF; // [253] 267
        }
        _25348 = (_12batch_job_20239 == 0);
        _25347 = (_25348 != 0);
LF: 
        if (_25347 == 0) {
            goto L10; // [267] 308
        }
        _25350 = (_12test_only_20238 == 0);
        if (_25350 == 0)
        {
            DeRef(_25350);
            _25350 = NOVALUE;
            goto L10; // [278] 308
        }
        else{
            DeRef(_25350);
            _25350 = NOVALUE;
        }

        /** error.e:148						ShowMsg(errfile, PRESS_ENTER_TO_CONTINUE_Q_TO_QUIT)*/
        RefDS(_22015);
        _30ShowMsg(_errfile_49347, 206, _22015, 1);

        /** error.e:149						c = getc(0)*/
        if (0 != last_r_file_no) {
            last_r_file_ptr = which_file(0, EF_READ);
            last_r_file_no = 0;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _c_49346 = getc((FILE*)xstdin);
            }
            else{
                _c_49346 = getc(last_r_file_ptr);
            }
        }
        else{
            _c_49346 = getc(last_r_file_ptr);
        }

        /** error.e:150						if c = 'q' then*/
        if (_c_49346 != 113)
        goto L11; // [298] 307

        /** error.e:151							exit*/
        goto LD; // [304] 316
L11: 
L10: 
LE: 

        /** error.e:155			end for*/
        _i_49392 = _i_49392 + 1;
        goto LC; // [311] 222
LD: 
        ;
    }
LB: 

    /** error.e:158		return length(warning_list)*/
    if (IS_SEQUENCE(_49warning_list_49269)){
            _25353 = SEQ_PTR(_49warning_list_49269)->length;
    }
    else {
        _25353 = 1;
    }
    DeRef(_25346);
    _25346 = NOVALUE;
    DeRef(_25348);
    _25348 = NOVALUE;
    DeRef(_25324);
    _25324 = NOVALUE;
    DeRef(_25339);
    _25339 = NOVALUE;
    return _25353;
    ;
}


void _49ShowDefines(object _errfile_49415)
{
    object _c_49416 = NOVALUE;
    object _25367 = NOVALUE;
    object _25366 = NOVALUE;
    object _25364 = NOVALUE;
    object _25363 = NOVALUE;
    object _25360 = NOVALUE;
    object _25359 = NOVALUE;
    object _25358 = NOVALUE;
    object _25357 = NOVALUE;
    object _25356 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:164		if errfile=0 then*/
    if (_errfile_49415 != 0)
    goto L1; // [5] 19

    /** error.e:165			errfile = STDERR*/
    _errfile_49415 = 2;
L1: 

    /** error.e:168		puts(errfile, format("\n--- [1] ---\n", {GetMsgText(DEFINED_WORDS,0)}))*/
    RefDS(_22015);
    _25356 = _30GetMsgText(207, 0, _22015);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25356;
    _25357 = MAKE_SEQ(_1);
    _25356 = NOVALUE;
    RefDS(_25355);
    _25358 = _18format(_25355, _25357);
    _25357 = NOVALUE;
    EPuts(_errfile_49415, _25358); // DJP 
    DeRef(_25358);
    _25358 = NOVALUE;

    /** error.e:170		for i = 1 to length(OpDefines) do*/
    if (IS_SEQUENCE(_12OpDefines_20300)){
            _25359 = SEQ_PTR(_12OpDefines_20300)->length;
    }
    else {
        _25359 = 1;
    }
    {
        object _i_49428;
        _i_49428 = 1;
L2: 
        if (_i_49428 > _25359){
            goto L3; // [48] 100
        }

        /** error.e:171			if find(OpDefines[i], {"_PLAT_START", "_PLAT_STOP"}) = 0 then*/
        _2 = (object)SEQ_PTR(_12OpDefines_20300);
        _25360 = (object)*(((s1_ptr)_2)->base + _i_49428);
        RefDS(_25362);
        RefDS(_25361);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _25361;
        ((intptr_t *)_2)[2] = _25362;
        _25363 = MAKE_SEQ(_1);
        _25364 = find_from(_25360, _25363, 1);
        _25360 = NOVALUE;
        DeRefDS(_25363);
        _25363 = NOVALUE;
        if (_25364 != 0)
        goto L4; // [72] 93

        /** error.e:172				printf(errfile, "%s\n", {OpDefines[i]})*/
        _2 = (object)SEQ_PTR(_12OpDefines_20300);
        _25366 = (object)*(((s1_ptr)_2)->base + _i_49428);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_25366);
        ((intptr_t*)_2)[1] = _25366;
        _25367 = MAKE_SEQ(_1);
        _25366 = NOVALUE;
        EPrintf(_errfile_49415, _25248, _25367);
        DeRefDS(_25367);
        _25367 = NOVALUE;
L4: 

        /** error.e:174		end for*/
        _i_49428 = _i_49428 + 1;
        goto L2; // [95] 55
L3: 
        ;
    }

    /** error.e:175		puts(errfile, "-------------------\n")*/
    EPuts(_errfile_49415, _25368); // DJP 

    /** error.e:177	end procedure*/
    return;
    ;
}


void _49Cleanup(object _status_49445)
{
    object _w_49446 = NOVALUE;
    object _show_error_49447 = NOVALUE;
    object _31721 = NOVALUE;
    object _25386 = NOVALUE;
    object _25385 = NOVALUE;
    object _25384 = NOVALUE;
    object _25383 = NOVALUE;
    object _25382 = NOVALUE;
    object _25381 = NOVALUE;
    object _25380 = NOVALUE;
    object _25379 = NOVALUE;
    object _25378 = NOVALUE;
    object _25377 = NOVALUE;
    object _25375 = NOVALUE;
    object _25374 = NOVALUE;
    object _25373 = NOVALUE;
    object _25372 = NOVALUE;
    object _25371 = NOVALUE;
    object _25369 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_status_49445)) {
        _1 = (object)(DBL_PTR(_status_49445)->dbl);
        DeRefDS(_status_49445);
        _status_49445 = _1;
    }

    /** error.e:182		integer w, show_error = 0*/
    _show_error_49447 = 0;

    /** error.e:184		ifdef EU_EX then*/

    /** error.e:187			write_coverage_db()*/
    _31721 = _50write_coverage_db();
    DeRef(_31721);
    _31721 = NOVALUE;

    /** error.e:190		show_error = 1*/
    _show_error_49447 = 1;

    /** error.e:196		if object(src_file) = 0 then*/
    if( NOVALUE == _12src_file_20348 ){
        _25369 = 0;
    }
    else{
        _25369 = 1;
    }
    if (_25369 != 0)
    goto L1; // [27] 41

    /** error.e:197			src_file = -1*/
    _12src_file_20348 = -1;
    goto L2; // [38] 93
L1: 

    /** error.e:198		elsif src_file >= 0 and (src_file != repl_file or not repl) then*/
    _25371 = (_12src_file_20348 >= 0);
    if (_25371 == 0) {
        goto L3; // [49] 92
    }
    _25373 = (_12src_file_20348 != 5555);
    if (_25373 != 0) {
        DeRef(_25374);
        _25374 = 1;
        goto L4; // [61] 74
    }
    _25375 = (0 == 0);
    _25374 = (_25375 != 0);
L4: 
    if (_25374 == 0)
    {
        _25374 = NOVALUE;
        goto L3; // [75] 92
    }
    else{
        _25374 = NOVALUE;
    }

    /** error.e:199			close(src_file)*/
    EClose(_12src_file_20348);

    /** error.e:200			src_file = -1*/
    _12src_file_20348 = -1;
L3: 
L2: 

    /** error.e:203		w = ShowWarnings()*/
    _w_49446 = _49ShowWarnings();
    if (!IS_ATOM_INT(_w_49446)) {
        _1 = (object)(DBL_PTR(_w_49446)->dbl);
        DeRefDS(_w_49446);
        _w_49446 = _1;
    }

    /** error.e:204		if not TRANSLATE and (BIND or show_error) and (w or Errors) then*/
    _25377 = (_12TRANSLATE_19834 == 0);
    if (_25377 == 0) {
        _25378 = 0;
        goto L5; // [107] 125
    }
    if (_12BIND_19837 != 0) {
        _25379 = 1;
        goto L6; // [113] 121
    }
    _25379 = (_show_error_49447 != 0);
L6: 
    _25378 = (_25379 != 0);
L5: 
    if (_25378 == 0) {
        goto L7; // [125] 186
    }
    if (_w_49446 != 0) {
        DeRef(_25381);
        _25381 = 1;
        goto L8; // [129] 139
    }
    _25381 = (_49Errors_49257 != 0);
L8: 
    if (_25381 == 0)
    {
        _25381 = NOVALUE;
        goto L7; // [140] 186
    }
    else{
        _25381 = NOVALUE;
    }

    /** error.e:205			if not batch_job and not test_only then*/
    _25382 = (_12batch_job_20239 == 0);
    if (_25382 == 0) {
        goto L9; // [150] 185
    }
    _25384 = (_12test_only_20238 == 0);
    if (_25384 == 0)
    {
        DeRef(_25384);
        _25384 = NOVALUE;
        goto L9; // [160] 185
    }
    else{
        DeRef(_25384);
        _25384 = NOVALUE;
    }

    /** error.e:206				screen_output(STDERR, GetMsgText(PRESS_ENTER,0))*/
    RefDS(_22015);
    _25385 = _30GetMsgText(208, 0, _22015);
    _49screen_output(2, _25385);
    _25385 = NOVALUE;

    /** error.e:207				getc(0) -- wait*/
    if (0 != last_r_file_no) {
        last_r_file_ptr = which_file(0, EF_READ);
        last_r_file_no = 0;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _25386 = getc((FILE*)xstdin);
        }
        else{
            _25386 = getc(last_r_file_ptr);
        }
    }
    else{
        _25386 = getc(last_r_file_ptr);
    }
L9: 
L7: 

    /** error.e:212		cleanup_open_includes()*/
    _61cleanup_open_includes();

    /** error.e:213		abort(status)*/
    UserCleanup(_status_49445);

    /** error.e:214	end procedure*/
    DeRef(_25375);
    _25375 = NOVALUE;
    DeRef(_25377);
    _25377 = NOVALUE;
    DeRef(_25373);
    _25373 = NOVALUE;
    DeRef(_25371);
    _25371 = NOVALUE;
    DeRef(_25382);
    _25382 = NOVALUE;
    return;
    ;
}


void _49OpenErrFile()
{
    object _25393 = NOVALUE;
    object _25392 = NOVALUE;
    object _25390 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:219	    if TempErrFile != -1 then*/
    if (_49TempErrFile_49258 == -1)
    goto L1; // [5] 19

    /** error.e:220			TempErrFile = open(TempErrName, "w")*/
    _49TempErrFile_49258 = EOpen(_49TempErrName_49259, _22151, 0);
L1: 

    /** error.e:223		if TempErrFile = -1 then*/
    if (_49TempErrFile_49258 != -1)
    goto L2; // [23] 66

    /** error.e:224			if length(TempErrName) > 0 then*/
    _25390 = 6;

    /** error.e:225				screen_output(STDERR, GetMsgText(CANT_CREATE_ERROR_MESSAGE_FILE_1, 0, {TempErrName}))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_49TempErrName_49259);
    ((intptr_t*)_2)[1] = _49TempErrName_49259;
    _25392 = MAKE_SEQ(_1);
    _25393 = _30GetMsgText(209, 0, _25392);
    _25392 = NOVALUE;
    _49screen_output(2, _25393);
    _25393 = NOVALUE;

    /** error.e:227			abort(1) -- with no clean up*/
    UserCleanup(1);
L2: 

    /** error.e:229	end procedure*/
    return;
    ;
}


void _49ShowErr(object _f_49504)
{
    object _msg_inlined_screen_output_at_43_49517 = NOVALUE;
    object _25400 = NOVALUE;
    object _25399 = NOVALUE;
    object _25398 = NOVALUE;
    object _25396 = NOVALUE;
    object _25394 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:234		if length(known_files) = 0 then*/
    if (IS_SEQUENCE(_13known_files_11317)){
            _25394 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _25394 = 1;
    }
    if (_25394 != 0)
    goto L1; // [10] 20

    /** error.e:235			return*/
    return;
L1: 

    /** error.e:238		if ThisLine[1] = END_OF_FILE_CHAR then*/
    _2 = (object)SEQ_PTR(_49ThisLine_49261);
    _25396 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _25396, 26)){
        _25396 = NOVALUE;
        goto L2; // [30] 64
    }
    _25396 = NOVALUE;

    /** error.e:239			screen_output(f, GetMsgText(MSG_ENDOFFILE,0))*/
    RefDS(_22015);
    _25398 = _30GetMsgText(210, 0, _22015);
    DeRef(_msg_inlined_screen_output_at_43_49517);
    _msg_inlined_screen_output_at_43_49517 = _25398;
    _25398 = NOVALUE;

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49504, _msg_inlined_screen_output_at_43_49517); // DJP 

    /** error.e:45	end procedure*/
    goto L3; // [56] 59
L3: 
    DeRef(_msg_inlined_screen_output_at_43_49517);
    _msg_inlined_screen_output_at_43_49517 = NOVALUE;
    goto L4; // [61] 81
L2: 

    /** error.e:241			screen_output(f, ThisLine)*/

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49504, _49ThisLine_49261); // DJP 

    /** error.e:45	end procedure*/
    goto L5; // [77] 80
L5: 
L4: 

    /** error.e:244		for i = 1 to bp-2 do -- bp-1 points to last character read*/
    _25399 = _49bp_49265 - 2;
    if ((object)((uintptr_t)_25399 +(uintptr_t) HIGH_BITS) >= 0){
        _25399 = NewDouble((eudouble)_25399);
    }
    {
        object _i_49521;
        _i_49521 = 1;
L6: 
        if (binary_op_a(GREATER, _i_49521, _25399)){
            goto L7; // [89] 143
        }

        /** error.e:245			if ThisLine[i] = '\t' then*/
        _2 = (object)SEQ_PTR(_49ThisLine_49261);
        if (!IS_ATOM_INT(_i_49521)){
            _25400 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_49521)->dbl));
        }
        else{
            _25400 = (object)*(((s1_ptr)_2)->base + _i_49521);
        }
        if (binary_op_a(NOTEQ, _25400, 9)){
            _25400 = NOVALUE;
            goto L8; // [104] 123
        }
        _25400 = NOVALUE;

        /** error.e:246				screen_output(f, "\t")*/

        /** error.e:44		puts(f, msg)*/
        EPuts(_f_49504, _23961); // DJP 

        /** error.e:45	end procedure*/
        goto L9; // [117] 136
        goto L9; // [120] 136
L8: 

        /** error.e:248				screen_output(f, " ")*/

        /** error.e:44		puts(f, msg)*/
        EPuts(_f_49504, _23406); // DJP 

        /** error.e:45	end procedure*/
        goto LA; // [132] 135
LA: 
L9: 

        /** error.e:250		end for*/
        _0 = _i_49521;
        if (IS_ATOM_INT(_i_49521)) {
            _i_49521 = _i_49521 + 1;
            if ((object)((uintptr_t)_i_49521 +(uintptr_t) HIGH_BITS) >= 0){
                _i_49521 = NewDouble((eudouble)_i_49521);
            }
        }
        else {
            _i_49521 = binary_op_a(PLUS, _i_49521, 1);
        }
        DeRef(_0);
        goto L6; // [138] 96
L7: 
        ;
        DeRef(_i_49521);
    }

    /** error.e:252		screen_output(f, "^\n\n")*/

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49504, _25402); // DJP 

    /** error.e:45	end procedure*/
    goto LB; // [152] 155
LB: 

    /** error.e:253	end procedure*/
    DeRef(_25399);
    _25399 = NOVALUE;
    return;
    ;
}


void _49CompileErr(object _msg_49533, object _args_49534, object _preproc_49535)
{
    object _errmsg_49536 = NOVALUE;
    object _25423 = NOVALUE;
    object _25419 = NOVALUE;
    object _25418 = NOVALUE;
    object _25417 = NOVALUE;
    object _25416 = NOVALUE;
    object _25415 = NOVALUE;
    object _25414 = NOVALUE;
    object _25412 = NOVALUE;
    object _25411 = NOVALUE;
    object _25409 = NOVALUE;
    object _25408 = NOVALUE;
    object _25407 = NOVALUE;
    object _25403 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:260		if integer(msg) then*/
    if (IS_ATOM_INT(_msg_49533))
    _25403 = 1;
    else if (IS_ATOM_DBL(_msg_49533))
    _25403 = IS_ATOM_INT(DoubleToInt(_msg_49533));
    else
    _25403 = 0;
    if (_25403 == 0)
    {
        _25403 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25403 = NOVALUE;
    }

    /** error.e:261			msg = GetMsgText(msg)*/
    Ref(_msg_49533);
    RefDS(_22015);
    _0 = _msg_49533;
    _msg_49533 = _30GetMsgText(_msg_49533, 1, _22015);
    DeRefi(_0);
L1: 

    /** error.e:264		msg = format(msg, args)*/
    Ref(_msg_49533);
    Ref(_args_49534);
    _0 = _msg_49533;
    _msg_49533 = _18format(_msg_49533, _args_49534);
    DeRef(_0);

    /** error.e:266		Errors += 1*/
    _49Errors_49257 = _49Errors_49257 + 1;

    /** error.e:267		if not preproc and length(known_files) then*/
    _25407 = (_preproc_49535 == 0);
    if (_25407 == 0) {
        goto L2; // [40] 78
    }
    if (IS_SEQUENCE(_13known_files_11317)){
            _25409 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _25409 = 1;
    }
    if (_25409 == 0)
    {
        _25409 = NOVALUE;
        goto L2; // [50] 78
    }
    else{
        _25409 = NOVALUE;
    }

    /** error.e:268			errmsg = sprintf("%s:%d\n%s\n", {known_files[current_file_no],*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _25411 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_25411);
    ((intptr_t*)_2)[1] = _25411;
    ((intptr_t*)_2)[2] = _12line_number_20227;
    Ref(_msg_49533);
    ((intptr_t*)_2)[3] = _msg_49533;
    _25412 = MAKE_SEQ(_1);
    _25411 = NOVALUE;
    DeRef(_errmsg_49536);
    _errmsg_49536 = EPrintf(-9999999, _25410, _25412);
    DeRefDS(_25412);
    _25412 = NOVALUE;
    goto L3; // [75] 121
L2: 

    /** error.e:271			errmsg = msg*/
    Ref(_msg_49533);
    DeRef(_errmsg_49536);
    _errmsg_49536 = _msg_49533;

    /** error.e:272			if length(msg) > 0 and msg[$] != '\n' then*/
    if (IS_SEQUENCE(_msg_49533)){
            _25414 = SEQ_PTR(_msg_49533)->length;
    }
    else {
        _25414 = 1;
    }
    _25415 = (_25414 > 0);
    _25414 = NOVALUE;
    if (_25415 == 0) {
        goto L4; // [94] 120
    }
    if (IS_SEQUENCE(_msg_49533)){
            _25417 = SEQ_PTR(_msg_49533)->length;
    }
    else {
        _25417 = 1;
    }
    _2 = (object)SEQ_PTR(_msg_49533);
    _25418 = (object)*(((s1_ptr)_2)->base + _25417);
    if (IS_ATOM_INT(_25418)) {
        _25419 = (_25418 != 10);
    }
    else {
        _25419 = binary_op(NOTEQ, _25418, 10);
    }
    _25418 = NOVALUE;
    if (_25419 == 0) {
        DeRef(_25419);
        _25419 = NOVALUE;
        goto L4; // [110] 120
    }
    else {
        if (!IS_ATOM_INT(_25419) && DBL_PTR(_25419)->dbl == 0.0){
            DeRef(_25419);
            _25419 = NOVALUE;
            goto L4; // [110] 120
        }
        DeRef(_25419);
        _25419 = NOVALUE;
    }
    DeRef(_25419);
    _25419 = NOVALUE;

    /** error.e:273				errmsg &= '\n'*/
    Append(&_errmsg_49536, _errmsg_49536, 10);
L4: 
L3: 

    /** error.e:277		if not preproc then*/
    if (_preproc_49535 != 0)
    goto L5; // [123] 131

    /** error.e:279			OpenErrFile() -- exits if error filename is ""*/
    _49OpenErrFile();
L5: 

    /** error.e:281		screen_output(STDERR, errmsg)*/
    RefDS(_errmsg_49536);
    _49screen_output(2, _errmsg_49536);

    /** error.e:283		if not preproc then*/
    if (_preproc_49535 != 0)
    goto L6; // [143] 198

    /** error.e:284			ShowErr(STDERR)*/
    _49ShowErr(2);

    /** error.e:286			puts(TempErrFile, errmsg)*/
    EPuts(_49TempErrFile_49258, _errmsg_49536); // DJP 

    /** error.e:288			ShowErr(TempErrFile)*/
    _49ShowErr(_49TempErrFile_49258);

    /** error.e:290			ShowWarnings()*/
    _25423 = _49ShowWarnings();

    /** error.e:292			ShowDefines(TempErrFile)*/
    _49ShowDefines(_49TempErrFile_49258);

    /** error.e:294			close(TempErrFile)*/
    EClose(_49TempErrFile_49258);

    /** error.e:295			TempErrFile = -2*/
    _49TempErrFile_49258 = -2;

    /** error.e:296			ifdef CRASH_ON_ERROR then*/

    /** error.e:299			Cleanup(1)*/
    _49Cleanup(1);
L6: 

    /** error.e:302	end procedure*/
    DeRef(_msg_49533);
    DeRef(_args_49534);
    DeRef(_errmsg_49536);
    DeRef(_25407);
    _25407 = NOVALUE;
    DeRef(_25415);
    _25415 = NOVALUE;
    DeRef(_25423);
    _25423 = NOVALUE;
    return;
    ;
}


void _49InternalErr(object _msgno_49580, object _args_49581)
{
    object _msg_49582 = NOVALUE;
    object _25438 = NOVALUE;
    object _25437 = NOVALUE;
    object _25436 = NOVALUE;
    object _25435 = NOVALUE;
    object _25434 = NOVALUE;
    object _25433 = NOVALUE;
    object _25432 = NOVALUE;
    object _25431 = NOVALUE;
    object _25430 = NOVALUE;
    object _25429 = NOVALUE;
    object _25428 = NOVALUE;
    object _25425 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:316		if atom(args) then*/
    _25425 = 0;
    if (_25425 == 0)
    {
        _25425 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _25425 = NOVALUE;
    }

    /** error.e:317			args = {args}*/
    _0 = _args_49581;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_args_49581);
    ((intptr_t*)_2)[1] = _args_49581;
    _args_49581 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** error.e:320		msg = GetMsgText(msgno, 1, args)*/
    Ref(_args_49581);
    _0 = _msg_49582;
    _msg_49582 = _30GetMsgText(_msgno_49580, 1, _args_49581);
    DeRef(_0);

    /** error.e:321		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L2; // [32] 58
    }
    else{
    }

    /** error.e:322			screen_output(STDERR, GetMsgText(INTERNAL_ERRORT1, 1, {msg}))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_msg_49582);
    ((intptr_t*)_2)[1] = _msg_49582;
    _25428 = MAKE_SEQ(_1);
    _25429 = _30GetMsgText(211, 1, _25428);
    _25428 = NOVALUE;
    _49screen_output(2, _25429);
    _25429 = NOVALUE;
    goto L3; // [55] 91
L2: 

    /** error.e:324			screen_output(STDERR, GetMsgText(INTERNAL_ERROR_AT_12T3, 1, {known_files[current_file_no], line_number, msg}))*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _25430 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_25430);
    ((intptr_t*)_2)[1] = _25430;
    ((intptr_t*)_2)[2] = _12line_number_20227;
    RefDS(_msg_49582);
    ((intptr_t*)_2)[3] = _msg_49582;
    _25431 = MAKE_SEQ(_1);
    _25430 = NOVALUE;
    _25432 = _30GetMsgText(212, 1, _25431);
    _25431 = NOVALUE;
    _49screen_output(2, _25432);
    _25432 = NOVALUE;
L3: 

    /** error.e:327		if not batch_job and not test_only then*/
    _25433 = (_12batch_job_20239 == 0);
    if (_25433 == 0) {
        goto L4; // [98] 133
    }
    _25435 = (_12test_only_20238 == 0);
    if (_25435 == 0)
    {
        DeRef(_25435);
        _25435 = NOVALUE;
        goto L4; // [108] 133
    }
    else{
        DeRef(_25435);
        _25435 = NOVALUE;
    }

    /** error.e:328			screen_output(STDERR, GetMsgText(PRESS_ENTER, 0))*/
    RefDS(_22015);
    _25436 = _30GetMsgText(208, 0, _22015);
    _49screen_output(2, _25436);
    _25436 = NOVALUE;

    /** error.e:329			getc(0)*/
    if (0 != last_r_file_no) {
        last_r_file_ptr = which_file(0, EF_READ);
        last_r_file_no = 0;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _25437 = getc((FILE*)xstdin);
        }
        else{
            _25437 = getc(last_r_file_ptr);
        }
    }
    else{
        _25437 = getc(last_r_file_ptr);
    }
L4: 

    /** error.e:333		machine_proc(67, GetMsgText(FAILED_DUE_TO_INTERNAL_ERROR))*/
    RefDS(_22015);
    _25438 = _30GetMsgText(213, 1, _22015);
    machine(67, _25438);
    DeRef(_25438);
    _25438 = NOVALUE;

    /** error.e:334	end procedure*/
    DeRef(_args_49581);
    DeRef(_msg_49582);
    DeRef(_25433);
    _25433 = NOVALUE;
    return;
    ;
}



// 0x4330ECE6
