// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _50check_coverage()
{
    object _25125 = NOVALUE;
    object _25124 = NOVALUE;
    object _25123 = NOVALUE;
    object _25122 = NOVALUE;
    object _25121 = NOVALUE;
    object _25120 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:45		for i = length( file_coverage ) + 1 to length( known_files ) do*/
    if (IS_SEQUENCE(_50file_coverage_48848)){
            _25120 = SEQ_PTR(_50file_coverage_48848)->length;
    }
    else {
        _25120 = 1;
    }
    _25121 = _25120 + 1;
    _25120 = NOVALUE;
    if (IS_SEQUENCE(_13known_files_11317)){
            _25122 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _25122 = 1;
    }
    {
        object _i_48859;
        _i_48859 = _25121;
L1: 
        if (_i_48859 > _25122){
            goto L2; // [17] 58
        }

        /** coverage.e:46			file_coverage &= find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (object)SEQ_PTR(_13known_files_11317);
        _25123 = (object)*(((s1_ptr)_2)->base + _i_48859);
        Ref(_25123);
        _25124 = _14canonical_path(_25123, 0, 1);
        _25123 = NOVALUE;
        _25125 = find_from(_25124, _50covered_files_48847, 1);
        DeRef(_25124);
        _25124 = NOVALUE;
        Append(&_50file_coverage_48848, _50file_coverage_48848, _25125);
        _25125 = NOVALUE;

        /** coverage.e:47		end for*/
        _i_48859 = _i_48859 + 1;
        goto L1; // [53] 24
L2: 
        ;
    }

    /** coverage.e:48	end procedure*/
    DeRef(_25121);
    _25121 = NOVALUE;
    return;
    ;
}


void _50init_coverage()
{
    object _cmd_48883 = NOVALUE;
    object _25143 = NOVALUE;
    object _25142 = NOVALUE;
    object _25140 = NOVALUE;
    object _25139 = NOVALUE;
    object _25138 = NOVALUE;
    object _25136 = NOVALUE;
    object _25134 = NOVALUE;
    object _25133 = NOVALUE;
    object _25131 = NOVALUE;
    object _25130 = NOVALUE;
    object _25129 = NOVALUE;
    object _25128 = NOVALUE;
    object _25127 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:54		if initialized_coverage then*/
    if (_50initialized_coverage_48855 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** coverage.e:55			return*/
    return;
L1: 

    /** coverage.e:57		initialized_coverage = 1*/
    _50initialized_coverage_48855 = 1;

    /** coverage.e:58		for i = 1 to length( file_coverage ) do*/
    if (IS_SEQUENCE(_50file_coverage_48848)){
            _25127 = SEQ_PTR(_50file_coverage_48848)->length;
    }
    else {
        _25127 = 1;
    }
    {
        object _i_48874;
        _i_48874 = 1;
L2: 
        if (_i_48874 > _25127){
            goto L3; // [26] 67
        }

        /** coverage.e:59			file_coverage[i] = find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (object)SEQ_PTR(_13known_files_11317);
        _25128 = (object)*(((s1_ptr)_2)->base + _i_48874);
        Ref(_25128);
        _25129 = _14canonical_path(_25128, 0, 1);
        _25128 = NOVALUE;
        _25130 = find_from(_25129, _50covered_files_48847, 1);
        DeRef(_25129);
        _25129 = NOVALUE;
        _2 = (object)SEQ_PTR(_50file_coverage_48848);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _50file_coverage_48848 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_48874);
        *(intptr_t *)_2 = _25130;
        if( _1 != _25130 ){
        }
        _25130 = NOVALUE;

        /** coverage.e:60		end for*/
        _i_48874 = _i_48874 + 1;
        goto L2; // [62] 33
L3: 
        ;
    }

    /** coverage.e:62		if equal( coverage_db_name, "" ) then*/
    if (_50coverage_db_name_48849 == _22015)
    _25131 = 1;
    else if (IS_ATOM_INT(_50coverage_db_name_48849) && IS_ATOM_INT(_22015))
    _25131 = 0;
    else
    _25131 = (compare(_50coverage_db_name_48849, _22015) == 0);
    if (_25131 == 0)
    {
        _25131 = NOVALUE;
        goto L4; // [75] 105
    }
    else{
        _25131 = NOVALUE;
    }

    /** coverage.e:63			sequence cmd = command_line()*/
    DeRef(_cmd_48883);
    _cmd_48883 = Command_Line();

    /** coverage.e:64			coverage_db_name = canonical_path( filebase( cmd[2] ) & "-cvg.edb" )*/
    _2 = (object)SEQ_PTR(_cmd_48883);
    _25133 = (object)*(((s1_ptr)_2)->base + 2);
    RefDS(_25133);
    _25134 = _14filebase(_25133);
    _25133 = NOVALUE;
    if (IS_SEQUENCE(_25134) && IS_ATOM(_25135)) {
    }
    else if (IS_ATOM(_25134) && IS_SEQUENCE(_25135)) {
        Ref(_25134);
        Prepend(&_25136, _25135, _25134);
    }
    else {
        Concat((object_ptr)&_25136, _25134, _25135);
        DeRef(_25134);
        _25134 = NOVALUE;
    }
    DeRef(_25134);
    _25134 = NOVALUE;
    _0 = _14canonical_path(_25136, 0, 0);
    DeRefDS(_50coverage_db_name_48849);
    _50coverage_db_name_48849 = _0;
    _25136 = NOVALUE;
L4: 
    DeRef(_cmd_48883);
    _cmd_48883 = NOVALUE;

    /** coverage.e:67		if coverage_erase and file_exists( coverage_db_name ) then*/
    if (_50coverage_erase_48850 == 0) {
        goto L5; // [111] 153
    }
    RefDS(_50coverage_db_name_48849);
    _25139 = _14file_exists(_50coverage_db_name_48849);
    if (_25139 == 0) {
        DeRef(_25139);
        _25139 = NOVALUE;
        goto L5; // [122] 153
    }
    else {
        if (!IS_ATOM_INT(_25139) && DBL_PTR(_25139)->dbl == 0.0){
            DeRef(_25139);
            _25139 = NOVALUE;
            goto L5; // [122] 153
        }
        DeRef(_25139);
        _25139 = NOVALUE;
    }
    DeRef(_25139);
    _25139 = NOVALUE;

    /** coverage.e:68			if not delete_file( coverage_db_name ) then*/
    RefDS(_50coverage_db_name_48849);
    _25140 = _14delete_file(_50coverage_db_name_48849);
    if (IS_ATOM_INT(_25140)) {
        if (_25140 != 0){
            DeRef(_25140);
            _25140 = NOVALUE;
            goto L6; // [133] 152
        }
    }
    else {
        if (DBL_PTR(_25140)->dbl != 0.0){
            DeRef(_25140);
            _25140 = NOVALUE;
            goto L6; // [133] 152
        }
    }
    DeRef(_25140);
    _25140 = NOVALUE;

    /** coverage.e:69				CompileErr( COULD_NOT_ERASE_COVERAGE_DATABASE_1, { coverage_db_name } )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_50coverage_db_name_48849);
    ((intptr_t*)_2)[1] = _50coverage_db_name_48849;
    _25142 = MAKE_SEQ(_1);
    _49CompileErr(335, _25142, 0);
    _25142 = NOVALUE;
L6: 
L5: 

    /** coverage.e:73		if db_open( coverage_db_name ) = DB_OK then*/
    RefDS(_50coverage_db_name_48849);
    _25143 = _41db_open(_50coverage_db_name_48849, 0);
    if (binary_op_a(NOTEQ, _25143, 0)){
        DeRef(_25143);
        _25143 = NOVALUE;
        goto L7; // [164] 177
    }
    DeRef(_25143);
    _25143 = NOVALUE;

    /** coverage.e:74			read_coverage_db()*/
    _50read_coverage_db();

    /** coverage.e:75			db_close()*/
    _41db_close();
L7: 

    /** coverage.e:77	end procedure*/
    return;
    ;
}


void _50write_map(object _coverage_48913, object _table_name_48914)
{
    object _keys_48938 = NOVALUE;
    object _rec_48943 = NOVALUE;
    object _val_48947 = NOVALUE;
    object _31723 = NOVALUE;
    object _25160 = NOVALUE;
    object _25157 = NOVALUE;
    object _25155 = NOVALUE;
    object _25154 = NOVALUE;
    object _25152 = NOVALUE;
    object _25151 = NOVALUE;
    object _25149 = NOVALUE;
    object _25147 = NOVALUE;
    object _25145 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:80		if db_select( coverage_db_name, DB_LOCK_EXCLUSIVE) = DB_OK then*/
    RefDS(_50coverage_db_name_48849);
    _25145 = _41db_select(_50coverage_db_name_48849, 2);
    if (binary_op_a(NOTEQ, _25145, 0)){
        DeRef(_25145);
        _25145 = NOVALUE;
        goto L1; // [16] 63
    }
    DeRef(_25145);
    _25145 = NOVALUE;

    /** coverage.e:81			if db_select_table( table_name ) != DB_OK then*/
    RefDS(_table_name_48914);
    _25147 = _41db_select_table(_table_name_48914);
    if (binary_op_a(EQUALS, _25147, 0)){
        DeRef(_25147);
        _25147 = NOVALUE;
        goto L2; // [28] 77
    }
    DeRef(_25147);
    _25147 = NOVALUE;

    /** coverage.e:82				if db_create_table( table_name ) != DB_OK then*/
    RefDS(_table_name_48914);
    _25149 = _41db_create_table(_table_name_48914, 50);
    if (binary_op_a(EQUALS, _25149, 0)){
        DeRef(_25149);
        _25149 = NOVALUE;
        goto L2; // [41] 77
    }
    DeRef(_25149);
    _25149 = NOVALUE;

    /** coverage.e:83					CompileErr( COULD_NOT_CREATE_COVERAGE_TABLE_1, {table_name} )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_table_name_48914);
    ((intptr_t*)_2)[1] = _table_name_48914;
    _25151 = MAKE_SEQ(_1);
    _49CompileErr(336, _25151, 0);
    _25151 = NOVALUE;
    goto L2; // [60] 77
L1: 

    /** coverage.e:87			CompileErr( COULD_NOT_CREATE_COVERAGE_TABLE_1, {table_name} )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_table_name_48914);
    ((intptr_t*)_2)[1] = _table_name_48914;
    _25152 = MAKE_SEQ(_1);
    _49CompileErr(336, _25152, 0);
    _25152 = NOVALUE;
L2: 

    /** coverage.e:90		sequence keys = map:keys( coverage )*/
    Ref(_coverage_48913);
    _0 = _keys_48938;
    _keys_48938 = _34keys(_coverage_48913, 0);
    DeRef(_0);

    /** coverage.e:91		for i = 1 to length( keys ) do*/
    if (IS_SEQUENCE(_keys_48938)){
            _25154 = SEQ_PTR(_keys_48938)->length;
    }
    else {
        _25154 = 1;
    }
    {
        object _i_48941;
        _i_48941 = 1;
L3: 
        if (_i_48941 > _25154){
            goto L4; // [91] 171
        }

        /** coverage.e:92			integer rec = db_find_key( keys[i] )*/
        _2 = (object)SEQ_PTR(_keys_48938);
        _25155 = (object)*(((s1_ptr)_2)->base + _i_48941);
        Ref(_25155);
        RefDS(_41current_table_name_15736);
        _rec_48943 = _41db_find_key(_25155, _41current_table_name_15736);
        _25155 = NOVALUE;
        if (!IS_ATOM_INT(_rec_48943)) {
            _1 = (object)(DBL_PTR(_rec_48943)->dbl);
            DeRefDS(_rec_48943);
            _rec_48943 = _1;
        }

        /** coverage.e:93			integer val = map:get( coverage, keys[i] )*/
        _2 = (object)SEQ_PTR(_keys_48938);
        _25157 = (object)*(((s1_ptr)_2)->base + _i_48941);
        Ref(_coverage_48913);
        Ref(_25157);
        _val_48947 = _34get(_coverage_48913, _25157, 0);
        _25157 = NOVALUE;
        if (!IS_ATOM_INT(_val_48947)) {
            _1 = (object)(DBL_PTR(_val_48947)->dbl);
            DeRefDS(_val_48947);
            _val_48947 = _1;
        }

        /** coverage.e:94			if rec > 0 then*/
        if (_rec_48943 <= 0)
        goto L5; // [129] 145

        /** coverage.e:95				db_replace_data( rec, val )*/
        RefDS(_41current_table_name_15736);
        _41db_replace_data(_rec_48943, _val_48947, _41current_table_name_15736);
        goto L6; // [142] 162
L5: 

        /** coverage.e:97				db_insert( keys[i], val )*/
        _2 = (object)SEQ_PTR(_keys_48938);
        _25160 = (object)*(((s1_ptr)_2)->base + _i_48941);
        Ref(_25160);
        RefDS(_41current_table_name_15736);
        _31723 = _41db_insert(_25160, _val_48947, _41current_table_name_15736);
        _25160 = NOVALUE;
        DeRef(_31723);
        _31723 = NOVALUE;
L6: 

        /** coverage.e:99		end for*/
        _i_48941 = _i_48941 + 1;
        goto L3; // [166] 98
L4: 
        ;
    }

    /** coverage.e:101	end procedure*/
    DeRef(_coverage_48913);
    DeRefDS(_table_name_48914);
    DeRef(_keys_48938);
    return;
    ;
}


object _50write_coverage_db()
{
    object _25175 = NOVALUE;
    object _25174 = NOVALUE;
    object _25173 = NOVALUE;
    object _25172 = NOVALUE;
    object _25171 = NOVALUE;
    object _25170 = NOVALUE;
    object _25169 = NOVALUE;
    object _25168 = NOVALUE;
    object _25165 = NOVALUE;
    object _25163 = NOVALUE;
    object _25161 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:105		if wrote_coverage then*/
    if (_50wrote_coverage_48956 == 0)
    {
        goto L1; // [5] 15
    }
    else{
    }

    /** coverage.e:106			return 1*/
    return 1;
L1: 

    /** coverage.e:108		wrote_coverage = 1*/
    _50wrote_coverage_48956 = 1;

    /** coverage.e:109		init_coverage()*/
    _50init_coverage();

    /** coverage.e:110		if not length( covered_files ) then*/
    if (IS_SEQUENCE(_50covered_files_48847)){
            _25161 = SEQ_PTR(_50covered_files_48847)->length;
    }
    else {
        _25161 = 1;
    }
    if (_25161 != 0)
    goto L2; // [31] 41
    _25161 = NOVALUE;

    /** coverage.e:111			return 1*/
    return 1;
L2: 

    /** coverage.e:114		if DB_OK != db_open( coverage_db_name, DB_LOCK_EXCLUSIVE) then*/
    RefDS(_50coverage_db_name_48849);
    _25163 = _41db_open(_50coverage_db_name_48849, 2);
    if (binary_op_a(EQUALS, 0, _25163)){
        DeRef(_25163);
        _25163 = NOVALUE;
        goto L3; // [54] 95
    }
    DeRef(_25163);
    _25163 = NOVALUE;

    /** coverage.e:115			if DB_OK != db_create( coverage_db_name ) then*/
    RefDS(_50coverage_db_name_48849);
    _25165 = _41db_create(_50coverage_db_name_48849, 0, 5, 5);
    if (binary_op_a(EQUALS, 0, _25165)){
        DeRef(_25165);
        _25165 = NOVALUE;
        goto L4; // [71] 94
    }
    DeRef(_25165);
    _25165 = NOVALUE;

    /** coverage.e:116				printf(2, "error opening %s\n", {coverage_db_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_50coverage_db_name_48849);
    ((intptr_t*)_2)[1] = _50coverage_db_name_48849;
    _25168 = MAKE_SEQ(_1);
    EPrintf(2, _25167, _25168);
    DeRefDS(_25168);
    _25168 = NOVALUE;

    /** coverage.e:117				return 0*/
    return 0;
L4: 
L3: 

    /** coverage.e:121		process_lines()*/
    _50process_lines();

    /** coverage.e:122		for tx = 1 to length( routine_map ) do*/
    if (IS_SEQUENCE(_50routine_map_48853)){
            _25169 = SEQ_PTR(_50routine_map_48853)->length;
    }
    else {
        _25169 = 1;
    }
    {
        object _tx_48978;
        _tx_48978 = 1;
L5: 
        if (_tx_48978 > _25169){
            goto L6; // [106] 164
        }

        /** coverage.e:123			write_map( routine_map[tx], 'r' & covered_files[tx] )*/
        _2 = (object)SEQ_PTR(_50routine_map_48853);
        _25170 = (object)*(((s1_ptr)_2)->base + _tx_48978);
        _2 = (object)SEQ_PTR(_50covered_files_48847);
        _25171 = (object)*(((s1_ptr)_2)->base + _tx_48978);
        if (IS_SEQUENCE(114) && IS_ATOM(_25171)) {
        }
        else if (IS_ATOM(114) && IS_SEQUENCE(_25171)) {
            Prepend(&_25172, _25171, 114);
        }
        else {
            Concat((object_ptr)&_25172, 114, _25171);
        }
        _25171 = NOVALUE;
        Ref(_25170);
        _50write_map(_25170, _25172);
        _25170 = NOVALUE;
        _25172 = NOVALUE;

        /** coverage.e:124			write_map( line_map[tx],    'l' & covered_files[tx] )*/
        _2 = (object)SEQ_PTR(_50line_map_48852);
        _25173 = (object)*(((s1_ptr)_2)->base + _tx_48978);
        _2 = (object)SEQ_PTR(_50covered_files_48847);
        _25174 = (object)*(((s1_ptr)_2)->base + _tx_48978);
        if (IS_SEQUENCE(108) && IS_ATOM(_25174)) {
        }
        else if (IS_ATOM(108) && IS_SEQUENCE(_25174)) {
            Prepend(&_25175, _25174, 108);
        }
        else {
            Concat((object_ptr)&_25175, 108, _25174);
        }
        _25174 = NOVALUE;
        Ref(_25173);
        _50write_map(_25173, _25175);
        _25173 = NOVALUE;
        _25175 = NOVALUE;

        /** coverage.e:125		end for*/
        _tx_48978 = _tx_48978 + 1;
        goto L5; // [159] 113
L6: 
        ;
    }

    /** coverage.e:127		db_close()*/
    _41db_close();

    /** coverage.e:129		routine_map = {}*/
    RefDS(_22015);
    DeRef(_50routine_map_48853);
    _50routine_map_48853 = _22015;

    /** coverage.e:130		line_map    = {}*/
    RefDS(_22015);
    DeRef(_50line_map_48852);
    _50line_map_48852 = _22015;

    /** coverage.e:131		return 1*/
    return 1;
    ;
}


void _50read_coverage_db()
{
    object _tables_48989 = NOVALUE;
    object _name_48995 = NOVALUE;
    object _fx_48999 = NOVALUE;
    object _the_map_49006 = NOVALUE;
    object _31722 = NOVALUE;
    object _25191 = NOVALUE;
    object _25190 = NOVALUE;
    object _25189 = NOVALUE;
    object _25185 = NOVALUE;
    object _25184 = NOVALUE;
    object _25183 = NOVALUE;
    object _25179 = NOVALUE;
    object _25178 = NOVALUE;
    object _25177 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:135		sequence tables = db_table_list()*/
    _0 = _tables_48989;
    _tables_48989 = _41db_table_list();
    DeRef(_0);

    /** coverage.e:137		for i = 1 to length( tables ) do*/
    if (IS_SEQUENCE(_tables_48989)){
            _25177 = SEQ_PTR(_tables_48989)->length;
    }
    else {
        _25177 = 1;
    }
    {
        object _i_48993;
        _i_48993 = 1;
L1: 
        if (_i_48993 > _25177){
            goto L2; // [13] 157
        }

        /** coverage.e:138			sequence name = tables[i][2..$]*/
        _2 = (object)SEQ_PTR(_tables_48989);
        _25178 = (object)*(((s1_ptr)_2)->base + _i_48993);
        if (IS_SEQUENCE(_25178)){
                _25179 = SEQ_PTR(_25178)->length;
        }
        else {
            _25179 = 1;
        }
        rhs_slice_target = (object_ptr)&_name_48995;
        RHS_Slice(_25178, 2, _25179);
        _25178 = NOVALUE;

        /** coverage.e:139			integer fx = find( name, covered_files )*/
        _fx_48999 = find_from(_name_48995, _50covered_files_48847, 1);

        /** coverage.e:140			if not fx then*/
        if (_fx_48999 != 0)
        goto L3; // [45] 55

        /** coverage.e:141				continue*/
        DeRefDS(_name_48995);
        _name_48995 = NOVALUE;
        DeRef(_the_map_49006);
        _the_map_49006 = NOVALUE;
        goto L4; // [52] 152
L3: 

        /** coverage.e:144			db_select_table( tables[i] )*/
        _2 = (object)SEQ_PTR(_tables_48989);
        _25183 = (object)*(((s1_ptr)_2)->base + _i_48993);
        Ref(_25183);
        _31722 = _41db_select_table(_25183);
        _25183 = NOVALUE;
        DeRef(_31722);
        _31722 = NOVALUE;

        /** coverage.e:146			if tables[i][1] = 'r' then*/
        _2 = (object)SEQ_PTR(_tables_48989);
        _25184 = (object)*(((s1_ptr)_2)->base + _i_48993);
        _2 = (object)SEQ_PTR(_25184);
        _25185 = (object)*(((s1_ptr)_2)->base + 1);
        _25184 = NOVALUE;
        if (binary_op_a(NOTEQ, _25185, 114)){
            _25185 = NOVALUE;
            goto L5; // [77] 92
        }
        _25185 = NOVALUE;

        /** coverage.e:148				the_map = routine_map[fx]*/
        DeRef(_the_map_49006);
        _2 = (object)SEQ_PTR(_50routine_map_48853);
        _the_map_49006 = (object)*(((s1_ptr)_2)->base + _fx_48999);
        Ref(_the_map_49006);
        goto L6; // [89] 101
L5: 

        /** coverage.e:152				the_map = line_map[fx]*/
        DeRef(_the_map_49006);
        _2 = (object)SEQ_PTR(_50line_map_48852);
        _the_map_49006 = (object)*(((s1_ptr)_2)->base + _fx_48999);
        Ref(_the_map_49006);
L6: 

        /** coverage.e:156			for j = 1 to db_table_size() do*/
        RefDS(_41current_table_name_15736);
        _25189 = _41db_table_size(_41current_table_name_15736);
        {
            object _j_49015;
            _j_49015 = 1;
L7: 
            if (binary_op_a(GREATER, _j_49015, _25189)){
                goto L8; // [109] 148
            }

            /** coverage.e:157				map:put( the_map, db_record_key( j ), db_record_data( j ), map:ADD )*/
            Ref(_j_49015);
            RefDS(_41current_table_name_15736);
            _25190 = _41db_record_key(_j_49015, _41current_table_name_15736);
            Ref(_j_49015);
            RefDS(_41current_table_name_15736);
            _25191 = _41db_record_data(_j_49015, _41current_table_name_15736);
            Ref(_the_map_49006);
            _34put(_the_map_49006, _25190, _25191, 2, 0);
            _25190 = NOVALUE;
            _25191 = NOVALUE;

            /** coverage.e:158			end for*/
            _0 = _j_49015;
            if (IS_ATOM_INT(_j_49015)) {
                _j_49015 = _j_49015 + 1;
                if ((object)((uintptr_t)_j_49015 +(uintptr_t) HIGH_BITS) >= 0){
                    _j_49015 = NewDouble((eudouble)_j_49015);
                }
            }
            else {
                _j_49015 = binary_op_a(PLUS, _j_49015, 1);
            }
            DeRef(_0);
            goto L7; // [143] 116
L8: 
            ;
            DeRef(_j_49015);
        }
        DeRef(_name_48995);
        _name_48995 = NOVALUE;
        DeRef(_the_map_49006);
        _the_map_49006 = NOVALUE;

        /** coverage.e:160		end for*/
L4: 
        _i_48993 = _i_48993 + 1;
        goto L1; // [152] 20
L2: 
        ;
    }

    /** coverage.e:161	end procedure*/
    DeRef(_tables_48989);
    DeRef(_25189);
    _25189 = NOVALUE;
    return;
    ;
}


void _50coverage_db(object _name_49024)
{
    object _0, _1, _2;
    

    /** coverage.e:164		coverage_db_name = name*/
    RefDS(_name_49024);
    DeRef(_50coverage_db_name_48849);
    _50coverage_db_name_48849 = _name_49024;

    /** coverage.e:165	end procedure*/
    DeRefDS(_name_49024);
    return;
    ;
}


object _50coverage_on()
{
    object _25192 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:170		return file_coverage[current_file_no]*/
    _2 = (object)SEQ_PTR(_50file_coverage_48848);
    _25192 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    return _25192;
    ;
}


void _50new_covered_path(object _name_49036)
{
    object _new_1__tmp_at14_49040 = NOVALUE;
    object _new_inlined_new_at_14_49039 = NOVALUE;
    object _new_1__tmp_at36_49044 = NOVALUE;
    object _new_inlined_new_at_36_49043 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:176		covered_files = append( covered_files, name )*/
    RefDS(_name_49036);
    Append(&_50covered_files_48847, _50covered_files_48847, _name_49036);

    /** coverage.e:177		routine_map &= map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at14_49040;
    _new_1__tmp_at14_49040 = _34new_map_seq(8);
    DeRef(_0);
    Ref(_new_1__tmp_at14_49040);
    _0 = _new_inlined_new_at_14_49039;
    _new_inlined_new_at_14_49039 = _35malloc(_new_1__tmp_at14_49040, 1);
    DeRef(_0);
    DeRef(_new_1__tmp_at14_49040);
    _new_1__tmp_at14_49040 = NOVALUE;
    if (IS_SEQUENCE(_50routine_map_48853) && IS_ATOM(_new_inlined_new_at_14_49039)) {
        Ref(_new_inlined_new_at_14_49039);
        Append(&_50routine_map_48853, _50routine_map_48853, _new_inlined_new_at_14_49039);
    }
    else if (IS_ATOM(_50routine_map_48853) && IS_SEQUENCE(_new_inlined_new_at_14_49039)) {
    }
    else {
        Concat((object_ptr)&_50routine_map_48853, _50routine_map_48853, _new_inlined_new_at_14_49039);
    }

    /** coverage.e:178		line_map    &= map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at36_49044;
    _new_1__tmp_at36_49044 = _34new_map_seq(8);
    DeRef(_0);
    Ref(_new_1__tmp_at36_49044);
    _0 = _new_inlined_new_at_36_49043;
    _new_inlined_new_at_36_49043 = _35malloc(_new_1__tmp_at36_49044, 1);
    DeRef(_0);
    DeRef(_new_1__tmp_at36_49044);
    _new_1__tmp_at36_49044 = NOVALUE;
    if (IS_SEQUENCE(_50line_map_48852) && IS_ATOM(_new_inlined_new_at_36_49043)) {
        Ref(_new_inlined_new_at_36_49043);
        Append(&_50line_map_48852, _50line_map_48852, _new_inlined_new_at_36_49043);
    }
    else if (IS_ATOM(_50line_map_48852) && IS_SEQUENCE(_new_inlined_new_at_36_49043)) {
    }
    else {
        Concat((object_ptr)&_50line_map_48852, _50line_map_48852, _new_inlined_new_at_36_49043);
    }

    /** coverage.e:179	end procedure*/
    DeRefDS(_name_49036);
    return;
    ;
}


void _50add_coverage(object _cover_this_49048)
{
    object _path_49049 = NOVALUE;
    object _files_49058 = NOVALUE;
    object _subpath_49086 = NOVALUE;
    object _25231 = NOVALUE;
    object _25230 = NOVALUE;
    object _25229 = NOVALUE;
    object _25228 = NOVALUE;
    object _25227 = NOVALUE;
    object _25226 = NOVALUE;
    object _25225 = NOVALUE;
    object _25224 = NOVALUE;
    object _25223 = NOVALUE;
    object _25222 = NOVALUE;
    object _25221 = NOVALUE;
    object _25220 = NOVALUE;
    object _25218 = NOVALUE;
    object _25217 = NOVALUE;
    object _25216 = NOVALUE;
    object _25215 = NOVALUE;
    object _25214 = NOVALUE;
    object _25213 = NOVALUE;
    object _25212 = NOVALUE;
    object _25211 = NOVALUE;
    object _25209 = NOVALUE;
    object _25208 = NOVALUE;
    object _25207 = NOVALUE;
    object _25206 = NOVALUE;
    object _25205 = NOVALUE;
    object _25204 = NOVALUE;
    object _25203 = NOVALUE;
    object _25202 = NOVALUE;
    object _25199 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:185		sequence path = canonical_path( cover_this,, CORRECT )*/
    RefDS(_cover_this_49048);
    _0 = _path_49049;
    _path_49049 = _14canonical_path(_cover_this_49048, 0, 2);
    DeRef(_0);

    /** coverage.e:187		if file_type( path ) = FILETYPE_DIRECTORY then*/
    RefDS(_path_49049);
    _25199 = _14file_type(_path_49049);
    if (binary_op_a(NOTEQ, _25199, 2)){
        DeRef(_25199);
        _25199 = NOVALUE;
        goto L1; // [23] 211
    }
    DeRef(_25199);
    _25199 = NOVALUE;

    /** coverage.e:188			sequence files = dir( path  )*/
    RefDS(_path_49049);
    _0 = _files_49058;
    _files_49058 = _14dir(_path_49049);
    DeRef(_0);

    /** coverage.e:190			for i = 1 to length( files ) do*/
    if (IS_SEQUENCE(_files_49058)){
            _25202 = SEQ_PTR(_files_49058)->length;
    }
    else {
        _25202 = 1;
    }
    {
        object _i_49062;
        _i_49062 = 1;
L2: 
        if (_i_49062 > _25202){
            goto L3; // [40] 206
        }

        /** coverage.e:191				if find( 'd', files[i][D_ATTRIBUTES] ) then*/
        _2 = (object)SEQ_PTR(_files_49058);
        _25203 = (object)*(((s1_ptr)_2)->base + _i_49062);
        _2 = (object)SEQ_PTR(_25203);
        _25204 = (object)*(((s1_ptr)_2)->base + 2);
        _25203 = NOVALUE;
        _25205 = find_from(100, _25204, 1);
        _25204 = NOVALUE;
        if (_25205 == 0)
        {
            _25205 = NOVALUE;
            goto L4; // [64] 118
        }
        else{
            _25205 = NOVALUE;
        }

        /** coverage.e:192					if not eu:find(files[i][D_NAME], {".", ".."}) then*/
        _2 = (object)SEQ_PTR(_files_49058);
        _25206 = (object)*(((s1_ptr)_2)->base + _i_49062);
        _2 = (object)SEQ_PTR(_25206);
        _25207 = (object)*(((s1_ptr)_2)->base + 1);
        _25206 = NOVALUE;
        RefDS(_23204);
        RefDS(_23205);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23205;
        ((intptr_t *)_2)[2] = _23204;
        _25208 = MAKE_SEQ(_1);
        _25209 = find_from(_25207, _25208, 1);
        _25207 = NOVALUE;
        DeRefDS(_25208);
        _25208 = NOVALUE;
        if (_25209 != 0)
        goto L5; // [88] 199
        _25209 = NOVALUE;

        /** coverage.e:193						add_coverage( cover_this & SLASH & files[i][D_NAME] )*/
        _2 = (object)SEQ_PTR(_files_49058);
        _25211 = (object)*(((s1_ptr)_2)->base + _i_49062);
        _2 = (object)SEQ_PTR(_25211);
        _25212 = (object)*(((s1_ptr)_2)->base + 1);
        _25211 = NOVALUE;
        {
            object concat_list[3];

            concat_list[0] = _25212;
            concat_list[1] = 47;
            concat_list[2] = _cover_this_49048;
            Concat_N((object_ptr)&_25213, concat_list, 3);
        }
        _25212 = NOVALUE;
        _50add_coverage(_25213);
        _25213 = NOVALUE;
        goto L5; // [115] 199
L4: 

        /** coverage.e:196				elsif regex:has_match( eu_file, files[i][D_NAME] ) then*/
        _2 = (object)SEQ_PTR(_files_49058);
        _25214 = (object)*(((s1_ptr)_2)->base + _i_49062);
        _2 = (object)SEQ_PTR(_25214);
        _25215 = (object)*(((s1_ptr)_2)->base + 1);
        _25214 = NOVALUE;
        Ref(_50eu_file_49030);
        Ref(_25215);
        _25216 = _51has_match(_50eu_file_49030, _25215, 1, 0);
        _25215 = NOVALUE;
        if (_25216 == 0) {
            DeRef(_25216);
            _25216 = NOVALUE;
            goto L6; // [139] 196
        }
        else {
            if (!IS_ATOM_INT(_25216) && DBL_PTR(_25216)->dbl == 0.0){
                DeRef(_25216);
                _25216 = NOVALUE;
                goto L6; // [139] 196
            }
            DeRef(_25216);
            _25216 = NOVALUE;
        }
        DeRef(_25216);
        _25216 = NOVALUE;

        /** coverage.e:198					sequence subpath = path & SLASH & files[i][D_NAME]*/
        _2 = (object)SEQ_PTR(_files_49058);
        _25217 = (object)*(((s1_ptr)_2)->base + _i_49062);
        _2 = (object)SEQ_PTR(_25217);
        _25218 = (object)*(((s1_ptr)_2)->base + 1);
        _25217 = NOVALUE;
        {
            object concat_list[3];

            concat_list[0] = _25218;
            concat_list[1] = 47;
            concat_list[2] = _path_49049;
            Concat_N((object_ptr)&_subpath_49086, concat_list, 3);
        }
        _25218 = NOVALUE;

        /** coverage.e:199					if not find( subpath, covered_files ) and not excluded( subpath ) then*/
        _25220 = find_from(_subpath_49086, _50covered_files_48847, 1);
        _25221 = (_25220 == 0);
        _25220 = NOVALUE;
        if (_25221 == 0) {
            goto L7; // [174] 195
        }
        RefDS(_subpath_49086);
        _25223 = _50excluded(_subpath_49086);
        if (IS_ATOM_INT(_25223)) {
            _25224 = (_25223 == 0);
        }
        else {
            _25224 = unary_op(NOT, _25223);
        }
        DeRef(_25223);
        _25223 = NOVALUE;
        if (_25224 == 0) {
            DeRef(_25224);
            _25224 = NOVALUE;
            goto L7; // [186] 195
        }
        else {
            if (!IS_ATOM_INT(_25224) && DBL_PTR(_25224)->dbl == 0.0){
                DeRef(_25224);
                _25224 = NOVALUE;
                goto L7; // [186] 195
            }
            DeRef(_25224);
            _25224 = NOVALUE;
        }
        DeRef(_25224);
        _25224 = NOVALUE;

        /** coverage.e:200						new_covered_path( subpath )*/
        RefDS(_subpath_49086);
        _50new_covered_path(_subpath_49086);
L7: 
L6: 
        DeRef(_subpath_49086);
        _subpath_49086 = NOVALUE;
L5: 

        /** coverage.e:203			end for*/
        _i_49062 = _i_49062 + 1;
        goto L2; // [201] 47
L3: 
        ;
    }
    DeRef(_files_49058);
    _files_49058 = NOVALUE;
    goto L8; // [208] 262
L1: 

    /** coverage.e:204		elsif regex:has_match( eu_file, path ) and*/
    Ref(_50eu_file_49030);
    RefDS(_path_49049);
    _25225 = _51has_match(_50eu_file_49030, _path_49049, 1, 0);
    if (IS_ATOM_INT(_25225)) {
        if (_25225 == 0) {
            DeRef(_25226);
            _25226 = 0;
            goto L9; // [222] 240
        }
    }
    else {
        if (DBL_PTR(_25225)->dbl == 0.0) {
            DeRef(_25226);
            _25226 = 0;
            goto L9; // [222] 240
        }
    }
    _25227 = find_from(_path_49049, _50covered_files_48847, 1);
    _25228 = (_25227 == 0);
    _25227 = NOVALUE;
    DeRef(_25226);
    _25226 = (_25228 != 0);
L9: 
    if (_25226 == 0) {
        goto LA; // [240] 261
    }
    RefDS(_path_49049);
    _25230 = _50excluded(_path_49049);
    if (IS_ATOM_INT(_25230)) {
        _25231 = (_25230 == 0);
    }
    else {
        _25231 = unary_op(NOT, _25230);
    }
    DeRef(_25230);
    _25230 = NOVALUE;
    if (_25231 == 0) {
        DeRef(_25231);
        _25231 = NOVALUE;
        goto LA; // [252] 261
    }
    else {
        if (!IS_ATOM_INT(_25231) && DBL_PTR(_25231)->dbl == 0.0){
            DeRef(_25231);
            _25231 = NOVALUE;
            goto LA; // [252] 261
        }
        DeRef(_25231);
        _25231 = NOVALUE;
    }
    DeRef(_25231);
    _25231 = NOVALUE;

    /** coverage.e:207			new_covered_path( path )*/
    RefDS(_path_49049);
    _50new_covered_path(_path_49049);
LA: 
L8: 

    /** coverage.e:209	end procedure*/
    DeRefDS(_cover_this_49048);
    DeRef(_path_49049);
    DeRef(_25228);
    _25228 = NOVALUE;
    DeRef(_25225);
    _25225 = NOVALUE;
    DeRef(_25221);
    _25221 = NOVALUE;
    return;
    ;
}


object _50excluded(object _file_49110)
{
    object _25234 = NOVALUE;
    object _25233 = NOVALUE;
    object _25232 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:212		for i = 1 to length( exclusion_patterns ) do*/
    if (IS_SEQUENCE(_50exclusion_patterns_48851)){
            _25232 = SEQ_PTR(_50exclusion_patterns_48851)->length;
    }
    else {
        _25232 = 1;
    }
    {
        object _i_49112;
        _i_49112 = 1;
L1: 
        if (_i_49112 > _25232){
            goto L2; // [10] 49
        }

        /** coverage.e:213			if regex:has_match( exclusion_patterns[i], file ) then*/
        _2 = (object)SEQ_PTR(_50exclusion_patterns_48851);
        _25233 = (object)*(((s1_ptr)_2)->base + _i_49112);
        Ref(_25233);
        RefDS(_file_49110);
        _25234 = _51has_match(_25233, _file_49110, 1, 0);
        _25233 = NOVALUE;
        if (_25234 == 0) {
            DeRef(_25234);
            _25234 = NOVALUE;
            goto L3; // [32] 42
        }
        else {
            if (!IS_ATOM_INT(_25234) && DBL_PTR(_25234)->dbl == 0.0){
                DeRef(_25234);
                _25234 = NOVALUE;
                goto L3; // [32] 42
            }
            DeRef(_25234);
            _25234 = NOVALUE;
        }
        DeRef(_25234);
        _25234 = NOVALUE;

        /** coverage.e:214				return 1*/
        DeRefDS(_file_49110);
        return 1;
L3: 

        /** coverage.e:216		end for*/
        _i_49112 = _i_49112 + 1;
        goto L1; // [44] 17
L2: 
        ;
    }

    /** coverage.e:217		return 0*/
    DeRefDS(_file_49110);
    return 0;
    ;
}


void _50coverage_exclude(object _patterns_49119)
{
    object _ex_49124 = NOVALUE;
    object _fx_49131 = NOVALUE;
    object _25252 = NOVALUE;
    object _25251 = NOVALUE;
    object _25250 = NOVALUE;
    object _25249 = NOVALUE;
    object _25243 = NOVALUE;
    object _25242 = NOVALUE;
    object _25240 = NOVALUE;
    object _25238 = NOVALUE;
    object _25236 = NOVALUE;
    object _25235 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:221		for i = 1 to length( patterns ) do*/
    if (IS_SEQUENCE(_patterns_49119)){
            _25235 = SEQ_PTR(_patterns_49119)->length;
    }
    else {
        _25235 = 1;
    }
    {
        object _i_49121;
        _i_49121 = 1;
L1: 
        if (_i_49121 > _25235){
            goto L2; // [8] 163
        }

        /** coverage.e:222			regex ex = regex:new( patterns[i] )*/
        _2 = (object)SEQ_PTR(_patterns_49119);
        _25236 = (object)*(((s1_ptr)_2)->base + _i_49121);
        Ref(_25236);
        _0 = _ex_49124;
        _ex_49124 = _51new(_25236, 0);
        DeRef(_0);
        _25236 = NOVALUE;

        /** coverage.e:223			if regex( ex ) then*/
        Ref(_ex_49124);
        _25238 = _51regex(_ex_49124);
        if (_25238 == 0) {
            DeRef(_25238);
            _25238 = NOVALUE;
            goto L3; // [32] 127
        }
        else {
            if (!IS_ATOM_INT(_25238) && DBL_PTR(_25238)->dbl == 0.0){
                DeRef(_25238);
                _25238 = NOVALUE;
                goto L3; // [32] 127
            }
            DeRef(_25238);
            _25238 = NOVALUE;
        }
        DeRef(_25238);
        _25238 = NOVALUE;

        /** coverage.e:224				exclusion_patterns = append( exclusion_patterns, ex )*/
        Ref(_ex_49124);
        Append(&_50exclusion_patterns_48851, _50exclusion_patterns_48851, _ex_49124);

        /** coverage.e:225				integer fx = 1*/
        _fx_49131 = 1;

        /** coverage.e:226				while fx <= length( covered_files ) do*/
L4: 
        if (IS_SEQUENCE(_50covered_files_48847)){
                _25240 = SEQ_PTR(_50covered_files_48847)->length;
        }
        else {
            _25240 = 1;
        }
        if (_fx_49131 > _25240)
        goto L5; // [58] 122

        /** coverage.e:227					if regex:has_match( ex, covered_files[fx] ) then*/
        _2 = (object)SEQ_PTR(_50covered_files_48847);
        _25242 = (object)*(((s1_ptr)_2)->base + _fx_49131);
        Ref(_ex_49124);
        Ref(_25242);
        _25243 = _51has_match(_ex_49124, _25242, 1, 0);
        _25242 = NOVALUE;
        if (_25243 == 0) {
            DeRef(_25243);
            _25243 = NOVALUE;
            goto L6; // [77] 110
        }
        else {
            if (!IS_ATOM_INT(_25243) && DBL_PTR(_25243)->dbl == 0.0){
                DeRef(_25243);
                _25243 = NOVALUE;
                goto L6; // [77] 110
            }
            DeRef(_25243);
            _25243 = NOVALUE;
        }
        DeRef(_25243);
        _25243 = NOVALUE;

        /** coverage.e:228						covered_files = remove( covered_files, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_50covered_files_48847);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_49131)) ? _fx_49131 : (object)(DBL_PTR(_fx_49131)->dbl);
            int stop = (IS_ATOM_INT(_fx_49131)) ? _fx_49131 : (object)(DBL_PTR(_fx_49131)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_50covered_files_48847), start, &_50covered_files_48847 );
                }
                else Tail(SEQ_PTR(_50covered_files_48847), stop+1, &_50covered_files_48847);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_50covered_files_48847), start, &_50covered_files_48847);
            }
            else {
                assign_slice_seq = &assign_space;
                _50covered_files_48847 = Remove_elements(start, stop, (SEQ_PTR(_50covered_files_48847)->ref == 1));
            }
        }

        /** coverage.e:229						routine_map   = remove( routine_map, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_50routine_map_48853);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_49131)) ? _fx_49131 : (object)(DBL_PTR(_fx_49131)->dbl);
            int stop = (IS_ATOM_INT(_fx_49131)) ? _fx_49131 : (object)(DBL_PTR(_fx_49131)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_50routine_map_48853), start, &_50routine_map_48853 );
                }
                else Tail(SEQ_PTR(_50routine_map_48853), stop+1, &_50routine_map_48853);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_50routine_map_48853), start, &_50routine_map_48853);
            }
            else {
                assign_slice_seq = &assign_space;
                _50routine_map_48853 = Remove_elements(start, stop, (SEQ_PTR(_50routine_map_48853)->ref == 1));
            }
        }

        /** coverage.e:230						line_map      = remove( line_map, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_50line_map_48852);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_49131)) ? _fx_49131 : (object)(DBL_PTR(_fx_49131)->dbl);
            int stop = (IS_ATOM_INT(_fx_49131)) ? _fx_49131 : (object)(DBL_PTR(_fx_49131)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_50line_map_48852), start, &_50line_map_48852 );
                }
                else Tail(SEQ_PTR(_50line_map_48852), stop+1, &_50line_map_48852);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_50line_map_48852), start, &_50line_map_48852);
            }
            else {
                assign_slice_seq = &assign_space;
                _50line_map_48852 = Remove_elements(start, stop, (SEQ_PTR(_50line_map_48852)->ref == 1));
            }
        }
        goto L4; // [107] 53
L6: 

        /** coverage.e:232						fx += 1*/
        _fx_49131 = _fx_49131 + 1;

        /** coverage.e:234				end while*/
        goto L4; // [119] 53
L5: 
        goto L7; // [124] 154
L3: 

        /** coverage.e:236				printf( 2,"%s\n", { GetMsgText( ERROR_CREATING_REGEX_FOR_COVERAGE_EXCLUSION_PATTERN_1, 1, {patterns[i]}) } )*/
        _2 = (object)SEQ_PTR(_patterns_49119);
        _25249 = (object)*(((s1_ptr)_2)->base + _i_49121);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_25249);
        ((intptr_t*)_2)[1] = _25249;
        _25250 = MAKE_SEQ(_1);
        _25249 = NOVALUE;
        _25251 = _30GetMsgText(339, 1, _25250);
        _25250 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _25251;
        _25252 = MAKE_SEQ(_1);
        _25251 = NOVALUE;
        EPrintf(2, _25248, _25252);
        DeRefDS(_25252);
        _25252 = NOVALUE;
L7: 
        DeRef(_ex_49124);
        _ex_49124 = NOVALUE;

        /** coverage.e:238		end for*/
        _i_49121 = _i_49121 + 1;
        goto L1; // [158] 15
L2: 
        ;
    }

    /** coverage.e:240	end procedure*/
    DeRefDS(_patterns_49119);
    return;
    ;
}


void _50new_coverage_db()
{
    object _0, _1, _2;
    

    /** coverage.e:243		coverage_erase = 1*/
    _50coverage_erase_48850 = 1;

    /** coverage.e:244	end procedure*/
    return;
    ;
}


void _50include_line(object _line_number_49155)
{
    object _25253 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:247		if coverage_on() then*/
    _25253 = _50coverage_on();
    if (_25253 == 0) {
        DeRef(_25253);
        _25253 = NOVALUE;
        goto L1; // [8] 34
    }
    else {
        if (!IS_ATOM_INT(_25253) && DBL_PTR(_25253)->dbl == 0.0){
            DeRef(_25253);
            _25253 = NOVALUE;
            goto L1; // [8] 34
        }
        DeRef(_25253);
        _25253 = NOVALUE;
    }
    DeRef(_25253);
    _25253 = NOVALUE;

    /** coverage.e:248			emit_op( COVERAGE_LINE )*/
    _45emit_op(210);

    /** coverage.e:249			emit_addr( gline_number )*/
    _45emit_addr(_12gline_number_20231);

    /** coverage.e:251			included_lines &= line_number*/
    Append(&_50included_lines_48854, _50included_lines_48854, _line_number_49155);
L1: 

    /** coverage.e:253	end procedure*/
    return;
    ;
}


void _50include_routine()
{
    object _file_no_49171 = NOVALUE;
    object _25260 = NOVALUE;
    object _25259 = NOVALUE;
    object _25258 = NOVALUE;
    object _25256 = NOVALUE;
    object _25255 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:256		if coverage_on() then*/
    _25255 = _50coverage_on();
    if (_25255 == 0) {
        DeRef(_25255);
        _25255 = NOVALUE;
        goto L1; // [6] 69
    }
    else {
        if (!IS_ATOM_INT(_25255) && DBL_PTR(_25255)->dbl == 0.0){
            DeRef(_25255);
            _25255 = NOVALUE;
            goto L1; // [6] 69
        }
        DeRef(_25255);
        _25255 = NOVALUE;
    }
    DeRef(_25255);
    _25255 = NOVALUE;

    /** coverage.e:257			emit_op( COVERAGE_ROUTINE )*/
    _45emit_op(211);

    /** coverage.e:258			emit_addr( CurrentSub )*/
    _45emit_addr(_12CurrentSub_20234);

    /** coverage.e:261			integer file_no = SymTab[CurrentSub][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25256 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_25256);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _file_no_49171 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _file_no_49171 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    if (!IS_ATOM_INT(_file_no_49171)){
        _file_no_49171 = (object)DBL_PTR(_file_no_49171)->dbl;
    }
    _25256 = NOVALUE;

    /** coverage.e:262			map:put( routine_map[file_coverage[file_no]], sym_name( CurrentSub ), 0, map:ADD )*/
    _2 = (object)SEQ_PTR(_50file_coverage_48848);
    _25258 = (object)*(((s1_ptr)_2)->base + _file_no_49171);
    _2 = (object)SEQ_PTR(_50routine_map_48853);
    _25259 = (object)*(((s1_ptr)_2)->base + _25258);
    _25260 = _53sym_name(_12CurrentSub_20234);
    Ref(_25259);
    _34put(_25259, _25260, 0, 2, 0);
    _25259 = NOVALUE;
    _25260 = NOVALUE;
L1: 

    /** coverage.e:264	end procedure*/
    _25258 = NOVALUE;
    return;
    ;
}


void _50process_lines()
{
    object _sline_49199 = NOVALUE;
    object _file_49203 = NOVALUE;
    object _line_49213 = NOVALUE;
    object _25278 = NOVALUE;
    object _25276 = NOVALUE;
    object _25275 = NOVALUE;
    object _25274 = NOVALUE;
    object _25273 = NOVALUE;
    object _25272 = NOVALUE;
    object _25270 = NOVALUE;
    object _25268 = NOVALUE;
    object _25267 = NOVALUE;
    object _25265 = NOVALUE;
    object _25264 = NOVALUE;
    object _25263 = NOVALUE;
    object _25261 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:267		if not length( included_lines ) then*/
    if (IS_SEQUENCE(_50included_lines_48854)){
            _25261 = SEQ_PTR(_50included_lines_48854)->length;
    }
    else {
        _25261 = 1;
    }
    if (_25261 != 0)
    goto L1; // [8] 17
    _25261 = NOVALUE;

    /** coverage.e:268			return*/
    return;
L1: 

    /** coverage.e:270		if atom(slist[$]) then*/
    if (IS_SEQUENCE(_12slist_20317)){
            _25263 = SEQ_PTR(_12slist_20317)->length;
    }
    else {
        _25263 = 1;
    }
    _2 = (object)SEQ_PTR(_12slist_20317);
    _25264 = (object)*(((s1_ptr)_2)->base + _25263);
    _25265 = IS_ATOM(_25264);
    _25264 = NOVALUE;
    if (_25265 == 0)
    {
        _25265 = NOVALUE;
        goto L2; // [31] 45
    }
    else{
        _25265 = NOVALUE;
    }

    /** coverage.e:271			slist = s_expand( slist )*/
    RefDS(_12slist_20317);
    _0 = _61s_expand(_12slist_20317);
    DeRefDS(_12slist_20317);
    _12slist_20317 = _0;
L2: 

    /** coverage.e:273		for i = 1 to length( included_lines ) do*/
    if (IS_SEQUENCE(_50included_lines_48854)){
            _25267 = SEQ_PTR(_50included_lines_48854)->length;
    }
    else {
        _25267 = 1;
    }
    {
        object _i_49197;
        _i_49197 = 1;
L3: 
        if (_i_49197 > _25267){
            goto L4; // [52] 157
        }

        /** coverage.e:274			sequence sline = slist[included_lines[i]]*/
        _2 = (object)SEQ_PTR(_50included_lines_48854);
        _25268 = (object)*(((s1_ptr)_2)->base + _i_49197);
        DeRef(_sline_49199);
        _2 = (object)SEQ_PTR(_12slist_20317);
        _sline_49199 = (object)*(((s1_ptr)_2)->base + _25268);
        Ref(_sline_49199);

        /** coverage.e:275			integer file = file_coverage[sline[LOCAL_FILE_NO]]*/
        _2 = (object)SEQ_PTR(_sline_49199);
        _25270 = (object)*(((s1_ptr)_2)->base + 3);
        _2 = (object)SEQ_PTR(_50file_coverage_48848);
        if (!IS_ATOM_INT(_25270)){
            _file_49203 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25270)->dbl));
        }
        else{
            _file_49203 = (object)*(((s1_ptr)_2)->base + _25270);
        }

        /** coverage.e:276			if file and file <= length( line_map ) and line_map[file] then*/
        if (_file_49203 == 0) {
            _25272 = 0;
            goto L5; // [91] 108
        }
        if (IS_SEQUENCE(_50line_map_48852)){
                _25273 = SEQ_PTR(_50line_map_48852)->length;
        }
        else {
            _25273 = 1;
        }
        _25274 = (_file_49203 <= _25273);
        _25273 = NOVALUE;
        _25272 = (_25274 != 0);
L5: 
        if (_25272 == 0) {
            goto L6; // [108] 146
        }
        _2 = (object)SEQ_PTR(_50line_map_48852);
        _25276 = (object)*(((s1_ptr)_2)->base + _file_49203);
        if (_25276 == 0) {
            _25276 = NOVALUE;
            goto L6; // [119] 146
        }
        else {
            if (!IS_ATOM_INT(_25276) && DBL_PTR(_25276)->dbl == 0.0){
                _25276 = NOVALUE;
                goto L6; // [119] 146
            }
            _25276 = NOVALUE;
        }
        _25276 = NOVALUE;

        /** coverage.e:277				integer line = sline[LINE]*/
        _2 = (object)SEQ_PTR(_sline_49199);
        _line_49213 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_line_49213))
        _line_49213 = (object)DBL_PTR(_line_49213)->dbl;

        /** coverage.e:278				map:put( line_map[file], line, 0, map:ADD )*/
        _2 = (object)SEQ_PTR(_50line_map_48852);
        _25278 = (object)*(((s1_ptr)_2)->base + _file_49203);
        Ref(_25278);
        _34put(_25278, _line_49213, 0, 2, 0);
        _25278 = NOVALUE;
L6: 
        DeRef(_sline_49199);
        _sline_49199 = NOVALUE;

        /** coverage.e:280		end for*/
        _i_49197 = _i_49197 + 1;
        goto L3; // [152] 59
L4: 
        ;
    }

    /** coverage.e:281	end procedure*/
    DeRef(_25274);
    _25274 = NOVALUE;
    _25270 = NOVALUE;
    _25268 = NOVALUE;
    return;
    ;
}


object _50cover_line(object _gline_number_49219)
{
    object _sline_49229 = NOVALUE;
    object _file_49232 = NOVALUE;
    object _line_49237 = NOVALUE;
    object _25287 = NOVALUE;
    object _25284 = NOVALUE;
    object _25281 = NOVALUE;
    object _25280 = NOVALUE;
    object _25279 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_gline_number_49219)) {
        _1 = (object)(DBL_PTR(_gline_number_49219)->dbl);
        DeRefDS(_gline_number_49219);
        _gline_number_49219 = _1;
    }

    /** coverage.e:284		if atom(slist[$]) then*/
    if (IS_SEQUENCE(_12slist_20317)){
            _25279 = SEQ_PTR(_12slist_20317)->length;
    }
    else {
        _25279 = 1;
    }
    _2 = (object)SEQ_PTR(_12slist_20317);
    _25280 = (object)*(((s1_ptr)_2)->base + _25279);
    _25281 = IS_ATOM(_25280);
    _25280 = NOVALUE;
    if (_25281 == 0)
    {
        _25281 = NOVALUE;
        goto L1; // [17] 31
    }
    else{
        _25281 = NOVALUE;
    }

    /** coverage.e:285			slist = s_expand(slist)*/
    RefDS(_12slist_20317);
    _0 = _61s_expand(_12slist_20317);
    DeRefDS(_12slist_20317);
    _12slist_20317 = _0;
L1: 

    /** coverage.e:287		sequence sline = slist[gline_number]*/
    DeRef(_sline_49229);
    _2 = (object)SEQ_PTR(_12slist_20317);
    _sline_49229 = (object)*(((s1_ptr)_2)->base + _gline_number_49219);
    Ref(_sline_49229);

    /** coverage.e:288		integer file = file_coverage[sline[LOCAL_FILE_NO]]*/
    _2 = (object)SEQ_PTR(_sline_49229);
    _25284 = (object)*(((s1_ptr)_2)->base + 3);
    _2 = (object)SEQ_PTR(_50file_coverage_48848);
    if (!IS_ATOM_INT(_25284)){
        _file_49232 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25284)->dbl));
    }
    else{
        _file_49232 = (object)*(((s1_ptr)_2)->base + _25284);
    }

    /** coverage.e:289		if file then*/
    if (_file_49232 == 0)
    {
        goto L2; // [57] 84
    }
    else{
    }

    /** coverage.e:290			integer line = sline[LINE]*/
    _2 = (object)SEQ_PTR(_sline_49229);
    _line_49237 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_line_49237))
    _line_49237 = (object)DBL_PTR(_line_49237)->dbl;

    /** coverage.e:291			map:put( line_map[file], line, 1, map:ADD )*/
    _2 = (object)SEQ_PTR(_50line_map_48852);
    _25287 = (object)*(((s1_ptr)_2)->base + _file_49232);
    Ref(_25287);
    _34put(_25287, _line_49237, 1, 2, 0);
    _25287 = NOVALUE;
L2: 

    /** coverage.e:293		return 0*/
    DeRef(_sline_49229);
    _25284 = NOVALUE;
    return 0;
    ;
}


object _50cover_routine(object _sub_49244)
{
    object _file_no_49245 = NOVALUE;
    object _25292 = NOVALUE;
    object _25291 = NOVALUE;
    object _25290 = NOVALUE;
    object _25288 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sub_49244)) {
        _1 = (object)(DBL_PTR(_sub_49244)->dbl);
        DeRefDS(_sub_49244);
        _sub_49244 = _1;
    }

    /** coverage.e:297		integer file_no = SymTab[sub][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25288 = (object)*(((s1_ptr)_2)->base + _sub_49244);
    _2 = (object)SEQ_PTR(_25288);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _file_no_49245 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _file_no_49245 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    if (!IS_ATOM_INT(_file_no_49245)){
        _file_no_49245 = (object)DBL_PTR(_file_no_49245)->dbl;
    }
    _25288 = NOVALUE;

    /** coverage.e:298		map:put( routine_map[file_coverage[file_no]], sym_name( sub ), 1, map:ADD )*/
    _2 = (object)SEQ_PTR(_50file_coverage_48848);
    _25290 = (object)*(((s1_ptr)_2)->base + _file_no_49245);
    _2 = (object)SEQ_PTR(_50routine_map_48853);
    _25291 = (object)*(((s1_ptr)_2)->base + _25290);
    _25292 = _53sym_name(_sub_49244);
    Ref(_25291);
    _34put(_25291, _25292, 1, 2, 0);
    _25291 = NOVALUE;
    _25292 = NOVALUE;

    /** coverage.e:299		return 0*/
    _25290 = NOVALUE;
    return 0;
    ;
}



// 0xFF664FE9
