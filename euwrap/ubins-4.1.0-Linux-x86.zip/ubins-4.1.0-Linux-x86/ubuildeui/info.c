// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _40arch_bits()
{
    object _8371 = NOVALUE;
    object _8370 = NOVALUE;
    object _8369 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:72		return sprintf( "%d-bit", 8 * sizeof( C_POINTER ) )*/
    _8369 = eu_sizeof( 50331649 );
    if (_8369 <= INT15){
        _8370 = 8 * _8369;
    }
    else{
        _8370 = NewDouble(8 * (eudouble)_8369);
    }
    _8369 = NOVALUE;
    _8371 = EPrintf(-9999999, _8368, _8370);
    DeRef(_8370);
    _8370 = NOVALUE;
    return _8371;
    ;
}


object _40version_major()
{
    object _8380 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:100		return version_info[MAJ_VER]*/
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _8380 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_8380);
    return _8380;
    ;
}


object _40version_minor()
{
    object _8381 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:112		return version_info[MIN_VER]*/
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _8381 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_8381);
    return _8381;
    ;
}


object _40version_patch()
{
    object _8382 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:124		return version_info[PAT_VER]*/
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _8382 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_8382);
    return _8382;
    ;
}


object _40version_node(object _full_14634)
{
    object _8389 = NOVALUE;
    object _8388 = NOVALUE;
    object _8387 = NOVALUE;
    object _8386 = NOVALUE;
    object _8385 = NOVALUE;
    object _8384 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:141		if full or length(version_info[NODE]) < 12 then*/
    if (0 != 0) {
        goto L1; // [5] 27
    }
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _8384 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_8384)){
            _8385 = SEQ_PTR(_8384)->length;
    }
    else {
        _8385 = 1;
    }
    _8384 = NOVALUE;
    _8386 = (_8385 < 12);
    _8385 = NOVALUE;
    if (_8386 == 0)
    {
        DeRef(_8386);
        _8386 = NOVALUE;
        goto L2; // [23] 40
    }
    else{
        DeRef(_8386);
        _8386 = NOVALUE;
    }
L1: 

    /** info.e:142			return version_info[NODE]*/
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _8387 = (object)*(((s1_ptr)_2)->base + 5);
    Ref(_8387);
    _8384 = NOVALUE;
    return _8387;
L2: 

    /** info.e:145		return version_info[NODE][1..12]*/
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _8388 = (object)*(((s1_ptr)_2)->base + 5);
    rhs_slice_target = (object_ptr)&_8389;
    RHS_Slice(_8388, 1, 12);
    _8388 = NOVALUE;
    _8384 = NOVALUE;
    _8387 = NOVALUE;
    return _8389;
    ;
}


object _40version_date(object _full_14648)
{
    object _8398 = NOVALUE;
    object _8397 = NOVALUE;
    object _8396 = NOVALUE;
    object _8395 = NOVALUE;
    object _8394 = NOVALUE;
    object _8393 = NOVALUE;
    object _8391 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:181		if full or is_developmental or length(version_info[REVISION_DATE]) < 10 then*/
    if (_full_14648 != 0) {
        _8391 = 1;
        goto L1; // [5] 15
    }
    _8391 = (_40is_developmental_14591 != 0);
L1: 
    if (_8391 != 0) {
        goto L2; // [15] 37
    }
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _8393 = (object)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_8393)){
            _8394 = SEQ_PTR(_8393)->length;
    }
    else {
        _8394 = 1;
    }
    _8393 = NOVALUE;
    _8395 = (_8394 < 10);
    _8394 = NOVALUE;
    if (_8395 == 0)
    {
        DeRef(_8395);
        _8395 = NOVALUE;
        goto L3; // [33] 50
    }
    else{
        DeRef(_8395);
        _8395 = NOVALUE;
    }
L2: 

    /** info.e:182			return version_info[REVISION_DATE]*/
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _8396 = (object)*(((s1_ptr)_2)->base + 7);
    Ref(_8396);
    _8393 = NOVALUE;
    return _8396;
L3: 

    /** info.e:185		return version_info[REVISION_DATE][1..10]*/
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _8397 = (object)*(((s1_ptr)_2)->base + 7);
    rhs_slice_target = (object_ptr)&_8398;
    RHS_Slice(_8397, 1, 10);
    _8397 = NOVALUE;
    _8396 = NOVALUE;
    _8393 = NOVALUE;
    return _8398;
    ;
}


object _40version_string(object _full_14663)
{
    object _version_revision_inlined_version_revision_at_41_14672 = NOVALUE;
    object _8418 = NOVALUE;
    object _8417 = NOVALUE;
    object _8416 = NOVALUE;
    object _8415 = NOVALUE;
    object _8414 = NOVALUE;
    object _8413 = NOVALUE;
    object _8412 = NOVALUE;
    object _8411 = NOVALUE;
    object _8409 = NOVALUE;
    object _8408 = NOVALUE;
    object _8407 = NOVALUE;
    object _8406 = NOVALUE;
    object _8405 = NOVALUE;
    object _8404 = NOVALUE;
    object _8403 = NOVALUE;
    object _8402 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:225		if full or is_developmental then*/
    if (0 != 0) {
        goto L1; // [5] 16
    }
    if (_40is_developmental_14591 == 0)
    {
        goto L2; // [12] 80
    }
    else{
    }
L1: 

    /** info.e:226			return sprintf("%d.%d.%d %s (%d:%s, %s)", {*/
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _8402 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _8403 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _8404 = (object)*(((s1_ptr)_2)->base + 3);
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _8405 = (object)*(((s1_ptr)_2)->base + 4);

    /** info.e:157		return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_41_14672);
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _version_revision_inlined_version_revision_at_41_14672 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_version_revision_inlined_version_revision_at_41_14672);
    _8406 = _40version_node(0);
    _8407 = _40version_date(_full_14663);
    _1 = NewS1(7);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_8402);
    ((intptr_t*)_2)[1] = _8402;
    Ref(_8403);
    ((intptr_t*)_2)[2] = _8403;
    Ref(_8404);
    ((intptr_t*)_2)[3] = _8404;
    Ref(_8405);
    ((intptr_t*)_2)[4] = _8405;
    Ref(_version_revision_inlined_version_revision_at_41_14672);
    ((intptr_t*)_2)[5] = _version_revision_inlined_version_revision_at_41_14672;
    ((intptr_t*)_2)[6] = _8406;
    ((intptr_t*)_2)[7] = _8407;
    _8408 = MAKE_SEQ(_1);
    _8407 = NOVALUE;
    _8406 = NOVALUE;
    _8405 = NOVALUE;
    _8404 = NOVALUE;
    _8403 = NOVALUE;
    _8402 = NOVALUE;
    _8409 = EPrintf(-9999999, _8401, _8408);
    DeRefDS(_8408);
    _8408 = NOVALUE;
    return _8409;
    goto L3; // [77] 132
L2: 

    /** info.e:236			return sprintf("%d.%d.%d %s (%s, %s)", {*/
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _8411 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _8412 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _8413 = (object)*(((s1_ptr)_2)->base + 3);
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _8414 = (object)*(((s1_ptr)_2)->base + 4);
    _8415 = _40version_node(0);
    _8416 = _40version_date(_full_14663);
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_8411);
    ((intptr_t*)_2)[1] = _8411;
    Ref(_8412);
    ((intptr_t*)_2)[2] = _8412;
    Ref(_8413);
    ((intptr_t*)_2)[3] = _8413;
    Ref(_8414);
    ((intptr_t*)_2)[4] = _8414;
    ((intptr_t*)_2)[5] = _8415;
    ((intptr_t*)_2)[6] = _8416;
    _8417 = MAKE_SEQ(_1);
    _8416 = NOVALUE;
    _8415 = NOVALUE;
    _8414 = NOVALUE;
    _8413 = NOVALUE;
    _8412 = NOVALUE;
    _8411 = NOVALUE;
    _8418 = EPrintf(-9999999, _8410, _8417);
    DeRefDS(_8417);
    _8417 = NOVALUE;
    DeRef(_8409);
    _8409 = NOVALUE;
    return _8418;
L3: 
    ;
}


object _40version_string_long(object _full_14694)
{
    object _platform_name_inlined_platform_name_at_8_14698 = NOVALUE;
    object _8426 = NOVALUE;
    object _8425 = NOVALUE;
    object _8422 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:284		return version_string(full) & " for " & platform_name() & " " & arch_bits()*/
    _8422 = _40version_string(0);

    /** info.e:48		ifdef WINDOWS then*/

    /** info.e:51			return "Linux"*/
    RefDS(_8362);
    DeRefi(_platform_name_inlined_platform_name_at_8_14698);
    _platform_name_inlined_platform_name_at_8_14698 = _8362;
    _8425 = _40arch_bits();
    {
        object concat_list[5];

        concat_list[0] = _8425;
        concat_list[1] = _8424;
        concat_list[2] = _platform_name_inlined_platform_name_at_8_14698;
        concat_list[3] = _8423;
        concat_list[4] = _8422;
        Concat_N((object_ptr)&_8426, concat_list, 5);
    }
    DeRef(_8425);
    _8425 = NOVALUE;
    DeRef(_8422);
    _8422 = NOVALUE;
    return _8426;
    ;
}


object _40all_copyrights()
{
    object _pcre_copyright_inlined_pcre_copyright_at_19_14721 = NOVALUE;
    object _euphoria_copyright_2__tmp_at2_14719 = NOVALUE;
    object _euphoria_copyright_1__tmp_at2_14718 = NOVALUE;
    object _euphoria_copyright_inlined_euphoria_copyright_at_2_14717 = NOVALUE;
    object _8435 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:355		return {*/

    /** info.e:309		return {*/
    _0 = _euphoria_copyright_1__tmp_at2_14718;
    _euphoria_copyright_1__tmp_at2_14718 = _40version_string_long(0);
    DeRef(_0);
    if (IS_SEQUENCE(_8427) && IS_ATOM(_euphoria_copyright_1__tmp_at2_14718)) {
        Ref(_euphoria_copyright_1__tmp_at2_14718);
        Append(&_euphoria_copyright_2__tmp_at2_14719, _8427, _euphoria_copyright_1__tmp_at2_14718);
    }
    else if (IS_ATOM(_8427) && IS_SEQUENCE(_euphoria_copyright_1__tmp_at2_14718)) {
    }
    else {
        Concat((object_ptr)&_euphoria_copyright_2__tmp_at2_14719, _8427, _euphoria_copyright_1__tmp_at2_14718);
    }
    RefDS(_8430);
    RefDS(_euphoria_copyright_2__tmp_at2_14719);
    DeRef(_euphoria_copyright_inlined_euphoria_copyright_at_2_14717);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _euphoria_copyright_2__tmp_at2_14719;
    ((intptr_t *)_2)[2] = _8430;
    _euphoria_copyright_inlined_euphoria_copyright_at_2_14717 = MAKE_SEQ(_1);
    DeRef(_euphoria_copyright_1__tmp_at2_14718);
    _euphoria_copyright_1__tmp_at2_14718 = NOVALUE;
    DeRef(_euphoria_copyright_2__tmp_at2_14719);
    _euphoria_copyright_2__tmp_at2_14719 = NOVALUE;

    /** info.e:331		return {*/
    RefDS(_8433);
    RefDS(_8432);
    DeRef(_pcre_copyright_inlined_pcre_copyright_at_19_14721);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _8432;
    ((intptr_t *)_2)[2] = _8433;
    _pcre_copyright_inlined_pcre_copyright_at_19_14721 = MAKE_SEQ(_1);
    RefDS(_pcre_copyright_inlined_pcre_copyright_at_19_14721);
    RefDS(_euphoria_copyright_inlined_euphoria_copyright_at_2_14717);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _euphoria_copyright_inlined_euphoria_copyright_at_2_14717;
    ((intptr_t *)_2)[2] = _pcre_copyright_inlined_pcre_copyright_at_19_14721;
    _8435 = MAKE_SEQ(_1);
    return _8435;
    ;
}



// 0xB263EEDF
