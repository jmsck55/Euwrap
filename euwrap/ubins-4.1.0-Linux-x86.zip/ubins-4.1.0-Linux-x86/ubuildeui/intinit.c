// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _68intoptions()
{
    object _pause_msg_64646 = NOVALUE;
    object _opts_array_64657 = NOVALUE;
    object _opts_64662 = NOVALUE;
    object _opt_keys_64671 = NOVALUE;
    object _option_w_64673 = NOVALUE;
    object _key_64677 = NOVALUE;
    object _val_64679 = NOVALUE;
    object _31791 = NOVALUE;
    object _31789 = NOVALUE;
    object _31788 = NOVALUE;
    object _31787 = NOVALUE;
    object _31786 = NOVALUE;
    object _31785 = NOVALUE;
    object _31784 = NOVALUE;
    object _31783 = NOVALUE;
    object _31782 = NOVALUE;
    object _31781 = NOVALUE;
    object _31780 = NOVALUE;
    object _31775 = NOVALUE;
    object _31772 = NOVALUE;
    object _31770 = NOVALUE;
    object _0, _1, _2;
    

    /** intinit.e:43		sequence pause_msg = GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE, 0)*/
    RefDS(_22015);
    _0 = _pause_msg_64646;
    _pause_msg_64646 = _30GetMsgText(278, 0, _22015);
    DeRef(_0);

    /** intinit.e:45		Argv = expand_config_options(Argv)*/
    RefDS(_12Argv_20237);
    _0 = _47expand_config_options(_12Argv_20237);
    DeRefDS(_12Argv_20237);
    _12Argv_20237 = _0;

    /** intinit.e:46		Argc = length(Argv)*/
    if (IS_SEQUENCE(_12Argv_20237)){
            _12Argc_20236 = SEQ_PTR(_12Argv_20237)->length;
    }
    else {
        _12Argc_20236 = 1;
    }

    /** intinit.e:48		sequence opts_array = sort( get_options() )*/
    _31770 = _47get_options();
    _0 = _opts_array_64657;
    _opts_array_64657 = _25sort(_31770, 1);
    DeRef(_0);
    _31770 = NOVALUE;

    /** intinit.e:50		m:map opts = cmd_parse( opts_array, */
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 10;
    ((intptr_t*)_2)[2] = 4;
    ((intptr_t*)_2)[3] = 8;
    RefDS(_pause_msg_64646);
    ((intptr_t*)_2)[4] = _pause_msg_64646;
    _31772 = MAKE_SEQ(_1);
    RefDS(_opts_array_64657);
    RefDS(_12Argv_20237);
    _0 = _opts_64662;
    _opts_64662 = _48cmd_parse(_opts_array_64657, _31772, _12Argv_20237);
    DeRef(_0);
    _31772 = NOVALUE;

    /** intinit.e:53		handle_common_options(opts)*/
    Ref(_opts_64662);
    _47handle_common_options(_opts_64662);

    /** intinit.e:55		sequence opt_keys = map:keys(opts)*/
    Ref(_opts_64662);
    _0 = _opt_keys_64671;
    _opt_keys_64671 = _34keys(_opts_64662, 0);
    DeRef(_0);

    /** intinit.e:56		integer option_w = 0*/
    _option_w_64673 = 0;

    /** intinit.e:58		for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_64671)){
            _31775 = SEQ_PTR(_opt_keys_64671)->length;
    }
    else {
        _31775 = 1;
    }
    {
        object _idx_64675;
        _idx_64675 = 1;
L1: 
        if (_idx_64675 > _31775){
            goto L2; // [91] 206
        }

        /** intinit.e:59			sequence key = opt_keys[idx]*/
        DeRef(_key_64677);
        _2 = (object)SEQ_PTR(_opt_keys_64671);
        _key_64677 = (object)*(((s1_ptr)_2)->base + _idx_64675);
        Ref(_key_64677);

        /** intinit.e:60			object val = map:get(opts, key)*/
        Ref(_opts_64662);
        RefDS(_key_64677);
        _0 = _val_64679;
        _val_64679 = _34get(_opts_64662, _key_64677, 0);
        DeRef(_0);

        /** intinit.e:62			switch key do*/
        _1 = find(_key_64677, _31778);
        switch ( _1 ){ 

            /** intinit.e:63				case "coverage" then*/
            case 1:

            /** intinit.e:64					for i = 1 to length( val ) do*/
            if (IS_SEQUENCE(_val_64679)){
                    _31780 = SEQ_PTR(_val_64679)->length;
            }
            else {
                _31780 = 1;
            }
            {
                object _i_64685;
                _i_64685 = 1;
L3: 
                if (_i_64685 > _31780){
                    goto L4; // [130] 153
                }

                /** intinit.e:65						add_coverage( val[i] )*/
                _2 = (object)SEQ_PTR(_val_64679);
                _31781 = (object)*(((s1_ptr)_2)->base + _i_64685);
                Ref(_31781);
                _50add_coverage(_31781);
                _31781 = NOVALUE;

                /** intinit.e:66					end for*/
                _i_64685 = _i_64685 + 1;
                goto L3; // [148] 137
L4: 
                ;
            }
            goto L5; // [153] 197

            /** intinit.e:68				case "coverage-db" then*/
            case 2:

            /** intinit.e:69					coverage_db( val )*/
            Ref(_val_64679);
            _50coverage_db(_val_64679);
            goto L5; // [164] 197

            /** intinit.e:71				case "coverage-erase" then*/
            case 3:

            /** intinit.e:72					new_coverage_db()*/
            _50new_coverage_db();
            goto L5; // [174] 197

            /** intinit.e:74				case "coverage-exclude" then*/
            case 4:

            /** intinit.e:75					coverage_exclude( val )*/
            Ref(_val_64679);
            _50coverage_exclude(_val_64679);
            goto L5; // [185] 197

            /** intinit.e:77				case "debugger" then*/
            case 5:

            /** intinit.e:78					external_debugger = val*/
            Ref(_val_64679);
            DeRef(_68external_debugger_64643);
            _68external_debugger_64643 = _val_64679;
        ;}L5: 
        DeRef(_key_64677);
        _key_64677 = NOVALUE;
        DeRef(_val_64679);
        _val_64679 = NOVALUE;

        /** intinit.e:81		end for*/
        _idx_64675 = _idx_64675 + 1;
        goto L1; // [201] 98
L2: 
        ;
    }

    /** intinit.e:83		if length(m:get(opts, cmdline:EXTRAS)) = 0 and not repl then*/
    Ref(_opts_64662);
    RefDS(_48EXTRAS_20639);
    _31782 = _34get(_opts_64662, _48EXTRAS_20639, 0);
    if (IS_SEQUENCE(_31782)){
            _31783 = SEQ_PTR(_31782)->length;
    }
    else {
        _31783 = 1;
    }
    DeRef(_31782);
    _31782 = NOVALUE;
    _31784 = (_31783 == 0);
    _31783 = NOVALUE;
    if (_31784 == 0) {
        goto L6; // [223] 282
    }
    _31786 = (0 == 0);
    if (_31786 == 0)
    {
        DeRef(_31786);
        _31786 = NOVALUE;
        goto L6; // [233] 282
    }
    else{
        DeRef(_31786);
        _31786 = NOVALUE;
    }

    /** intinit.e:84			show_banner()*/
    _47show_banner();

    /** intinit.e:85			ShowMsg(2, ERROR_MUST_SPECIFY_THE_FILE_TO_BE_INTERPRETED_ON_THE_COMMAND_LINE)*/
    RefDS(_22015);
    _30ShowMsg(2, 249, _22015, 1);

    /** intinit.e:87			if not batch_job and not test_only then*/
    _31787 = (_12batch_job_20239 == 0);
    if (_31787 == 0) {
        goto L7; // [257] 277
    }
    _31789 = (_12test_only_20238 == 0);
    if (_31789 == 0)
    {
        DeRef(_31789);
        _31789 = NOVALUE;
        goto L7; // [267] 277
    }
    else{
        DeRef(_31789);
        _31789 = NOVALUE;
    }

    /** intinit.e:88				maybe_any_key(pause_msg)*/
    RefDS(_pause_msg_64646);
    _38maybe_any_key(_pause_msg_64646, 1);
L7: 

    /** intinit.e:91			abort(1)*/
    UserCleanup(1);
L6: 

    /** intinit.e:94		OpDefines &= { "EUI" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_31790);
    ((intptr_t*)_2)[1] = _31790;
    _31791 = MAKE_SEQ(_1);
    Concat((object_ptr)&_12OpDefines_20300, _12OpDefines_20300, _31791);
    DeRefDS(_31791);
    _31791 = NOVALUE;

    /** intinit.e:96		finalize_command_line(opts)*/
    Ref(_opts_64662);
    _47finalize_command_line(_opts_64662);

    /** intinit.e:97	end procedure*/
    DeRef(_pause_msg_64646);
    DeRef(_opts_array_64657);
    DeRef(_opts_64662);
    DeRef(_opt_keys_64671);
    DeRef(_31784);
    _31784 = NOVALUE;
    _31782 = NOVALUE;
    DeRef(_31787);
    _31787 = NOVALUE;
    return;
    ;
}



// 0x70B51AFB
