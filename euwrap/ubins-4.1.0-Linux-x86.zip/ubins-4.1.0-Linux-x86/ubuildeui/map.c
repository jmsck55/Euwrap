// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _34map(object _m_14761)
{
    object _8461 = NOVALUE;
    object _8460 = NOVALUE;
    object _8459 = NOVALUE;
    object _8457 = NOVALUE;
    object _8456 = NOVALUE;
    object _8455 = NOVALUE;
    object _8453 = NOVALUE;
    object _8452 = NOVALUE;
    object _8451 = NOVALUE;
    object _8449 = NOVALUE;
    object _8448 = NOVALUE;
    object _8445 = NOVALUE;
    object _8443 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:126		if not atom( m ) then*/
    _8443 = IS_ATOM(_m_14761);
    if (_8443 != 0)
    goto L1; // [6] 16
    _8443 = NOVALUE;

    /** map.e:127			return 0*/
    DeRef(_m_14761);
    return 0;
L1: 

    /** map.e:129		if length( eumem:ram_space ) < m then*/
    if (IS_SEQUENCE(_35ram_space_12732)){
            _8445 = SEQ_PTR(_35ram_space_12732)->length;
    }
    else {
        _8445 = 1;
    }
    if (binary_op_a(GREATEREQ, _8445, _m_14761)){
        _8445 = NOVALUE;
        goto L2; // [23] 34
    }
    _8445 = NOVALUE;

    /** map.e:130			return 0*/
    DeRef(_m_14761);
    return 0;
L2: 

    /** map.e:132		if m < 1 then*/
    if (binary_op_a(GREATEREQ, _m_14761, 1)){
        goto L3; // [36] 47
    }

    /** map.e:133			return 0*/
    DeRef(_m_14761);
    return 0;
L3: 

    /** map.e:135		if length( eumem:ram_space[m] ) != MAP_MAX then*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_m_14761)){
        _8448 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_14761)->dbl));
    }
    else{
        _8448 = (object)*(((s1_ptr)_2)->base + _m_14761);
    }
    if (IS_SEQUENCE(_8448)){
            _8449 = SEQ_PTR(_8448)->length;
    }
    else {
        _8449 = 1;
    }
    _8448 = NOVALUE;
    if (_8449 == 3)
    goto L4; // [58] 69

    /** map.e:136			return 0*/
    DeRef(_m_14761);
    _8448 = NOVALUE;
    return 0;
L4: 

    /** map.e:138		if not atom( eumem:ram_space[m][MAP_SIZE] ) then*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_m_14761)){
        _8451 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_14761)->dbl));
    }
    else{
        _8451 = (object)*(((s1_ptr)_2)->base + _m_14761);
    }
    _2 = (object)SEQ_PTR(_8451);
    _8452 = (object)*(((s1_ptr)_2)->base + 1);
    _8451 = NOVALUE;
    _8453 = IS_ATOM(_8452);
    _8452 = NOVALUE;
    if (_8453 != 0)
    goto L5; // [84] 94
    _8453 = NOVALUE;

    /** map.e:139			return 0*/
    DeRef(_m_14761);
    _8448 = NOVALUE;
    return 0;
L5: 

    /** map.e:141		if not sequence( eumem:ram_space[m][MAP_SLOTS] ) then*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_m_14761)){
        _8455 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_14761)->dbl));
    }
    else{
        _8455 = (object)*(((s1_ptr)_2)->base + _m_14761);
    }
    _2 = (object)SEQ_PTR(_8455);
    _8456 = (object)*(((s1_ptr)_2)->base + 2);
    _8455 = NOVALUE;
    _8457 = IS_SEQUENCE(_8456);
    _8456 = NOVALUE;
    if (_8457 != 0)
    goto L6; // [109] 119
    _8457 = NOVALUE;

    /** map.e:142			return 0*/
    DeRef(_m_14761);
    _8448 = NOVALUE;
    return 0;
L6: 

    /** map.e:144		if not atom( eumem:ram_space[m][MAP_MAX] ) then*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_m_14761)){
        _8459 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_14761)->dbl));
    }
    else{
        _8459 = (object)*(((s1_ptr)_2)->base + _m_14761);
    }
    _2 = (object)SEQ_PTR(_8459);
    _8460 = (object)*(((s1_ptr)_2)->base + 3);
    _8459 = NOVALUE;
    _8461 = IS_ATOM(_8460);
    _8460 = NOVALUE;
    if (_8461 != 0)
    goto L7; // [134] 144
    _8461 = NOVALUE;

    /** map.e:145			return 0*/
    DeRef(_m_14761);
    _8448 = NOVALUE;
    return 0;
L7: 

    /** map.e:147		return 1*/
    DeRef(_m_14761);
    _8448 = NOVALUE;
    return 1;
    ;
}


object _34new_map_seq(object _size_14792)
{
    object _slots_14793 = NOVALUE;
    object _8473 = NOVALUE;
    object _8472 = NOVALUE;
    object _8471 = NOVALUE;
    object _8470 = NOVALUE;
    object _8466 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:155		integer slots = DEFAULT_SIZE * 2*/
    _slots_14793 = 16;

    /** map.e:156		if size <= DEFAULT_SIZE then*/
    if (_size_14792 > 8)
    goto L1; // [11] 23

    /** map.e:157			size = DEFAULT_SIZE*/
    _size_14792 = 8;
    goto L2; // [20] 55
L1: 

    /** map.e:159			size = floor( size * 1.5 )*/
    _8466 = NewDouble((eudouble)_size_14792 * DBL_PTR(_8465)->dbl);
    _size_14792 = unary_op(FLOOR, _8466);
    DeRefDS(_8466);
    _8466 = NOVALUE;
    if (!IS_ATOM_INT(_size_14792)) {
        _1 = (object)(DBL_PTR(_size_14792)->dbl);
        DeRefDS(_size_14792);
        _size_14792 = _1;
    }

    /** map.e:160			while slots < size do*/
L3: 
    if (_slots_14793 >= _size_14792)
    goto L4; // [39] 54

    /** map.e:162				slots *= 2*/
    _slots_14793 = _slots_14793 + _slots_14793;

    /** map.e:163			end while*/
    goto L3; // [51] 39
L4: 
L2: 

    /** map.e:165		return { 0, repeat( EMPTY_SLOT, slots ), floor( size * 2/3 ) }*/
    _8470 = Repeat(_34EMPTY_SLOT_14749, _slots_14793);
    _8471 = _size_14792 + _size_14792;
    if ((object)((uintptr_t)_8471 + (uintptr_t)HIGH_BITS) >= 0){
        _8471 = NewDouble((eudouble)_8471);
    }
    if (IS_ATOM_INT(_8471)) {
        if (3 > 0 && _8471 >= 0) {
            _8472 = _8471 / 3;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_8471 / (eudouble)3);
            if (_8471 != MININT)
            _8472 = (object)temp_dbl;
            else
            _8472 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _8471, 3);
        _8472 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_8471);
    _8471 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    ((intptr_t*)_2)[2] = _8470;
    ((intptr_t*)_2)[3] = _8472;
    _8473 = MAKE_SEQ(_1);
    _8472 = NOVALUE;
    _8470 = NOVALUE;
    return _8473;
    ;
}


object _34lookup(object _key_14836, object _hashval_14837, object _slots_14839)
{
    object _mask_14840 = NOVALUE;
    object _index_14843 = NOVALUE;
    object _index_hash_14846 = NOVALUE;
    object _slot_14847 = NOVALUE;
    object _perturb_14848 = NOVALUE;
    object _this_hash_14849 = NOVALUE;
    object _this_key_14850 = NOVALUE;
    object _looks_14851 = NOVALUE;
    object _removed_slot_14852 = NOVALUE;
    object _8502 = NOVALUE;
    object _8489 = NOVALUE;
    object _8488 = NOVALUE;
    object _8487 = NOVALUE;
    object _8486 = NOVALUE;
    object _8484 = NOVALUE;
    object _8482 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:275		integer mask = length( slots ) - 1*/
    if (IS_SEQUENCE(_slots_14839)){
            _8482 = SEQ_PTR(_slots_14839)->length;
    }
    else {
        _8482 = 1;
    }
    _mask_14840 = _8482 - 1;
    _8482 = NOVALUE;

    /** map.e:276		integer index = and_bits( hashval, mask ) + 1*/
    {uintptr_t tu;
         tu = (uintptr_t)_hashval_14837 & (uintptr_t)_mask_14840;
         _8484 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_8484)) {
        _index_14843 = _8484 + 1;
    }
    else
    { // coercing _index_14843 to an integer 1
        _index_14843 = 1+(object)(DBL_PTR(_8484)->dbl);
        if( !IS_ATOM_INT(_index_14843) ){
            _index_14843 = (object)DBL_PTR(_index_14843)->dbl;
        }
    }
    DeRef(_8484);
    _8484 = NOVALUE;

    /** map.e:277		ifdef BITS64 then*/

    /** map.e:280			atom index_hash = index*/
    DeRef(_index_hash_14846);
    _index_hash_14846 = _index_14843;

    /** map.e:282		sequence slot*/

    /** map.e:284		integer perturb = hashval*/
    _perturb_14848 = _hashval_14837;

    /** map.e:285		integer this_hash*/

    /** map.e:286		object this_key*/

    /** map.e:287		integer looks = 0*/
    _looks_14851 = 0;

    /** map.e:288		integer removed_slot = 0*/
    _removed_slot_14852 = 0;

    /** map.e:289		while this_hash != hashval or not equal( this_key, key ) with entry do*/
    goto L1; // [54] 140
L2: 
    _8486 = (_this_hash_14849 != _hashval_14837);
    if (_8486 != 0) {
        DeRef(_8487);
        _8487 = 1;
        goto L3; // [63] 80
    }
    if (_this_key_14850 == _key_14836)
    _8488 = 1;
    else if (IS_ATOM_INT(_this_key_14850) && IS_ATOM_INT(_key_14836))
    _8488 = 0;
    else
    _8488 = (compare(_this_key_14850, _key_14836) == 0);
    _8489 = (_8488 == 0);
    _8488 = NOVALUE;
    _8487 = (_8489 != 0);
L3: 
    if (_8487 == 0)
    {
        _8487 = NOVALUE;
        goto L4; // [80] 217
    }
    else{
        _8487 = NOVALUE;
    }

    /** map.e:290			index_hash *= 4*/
    _0 = _index_hash_14846;
    if (IS_ATOM_INT(_index_hash_14846)) {
        if (_index_hash_14846 == (short)_index_hash_14846){
            _index_hash_14846 = _index_hash_14846 * 4;
        }
        else{
            _index_hash_14846 = NewDouble(_index_hash_14846 * (eudouble)4);
        }
    }
    else {
        _index_hash_14846 = NewDouble(DBL_PTR(_index_hash_14846)->dbl * (eudouble)4);
    }
    DeRef(_0);

    /** map.e:291			index_hash += index*/
    _0 = _index_hash_14846;
    if (IS_ATOM_INT(_index_hash_14846)) {
        _index_hash_14846 = _index_hash_14846 + _index_14843;
        if ((object)((uintptr_t)_index_hash_14846 + (uintptr_t)HIGH_BITS) >= 0){
            _index_hash_14846 = NewDouble((eudouble)_index_hash_14846);
        }
    }
    else {
        _index_hash_14846 = NewDouble(DBL_PTR(_index_hash_14846)->dbl + (eudouble)_index_14843);
    }
    DeRef(_0);

    /** map.e:292			index_hash += perturb*/
    _0 = _index_hash_14846;
    if (IS_ATOM_INT(_index_hash_14846)) {
        _index_hash_14846 = _index_hash_14846 + _perturb_14848;
        if ((object)((uintptr_t)_index_hash_14846 + (uintptr_t)HIGH_BITS) >= 0){
            _index_hash_14846 = NewDouble((eudouble)_index_hash_14846);
        }
    }
    else {
        _index_hash_14846 = NewDouble(DBL_PTR(_index_hash_14846)->dbl + (eudouble)_perturb_14848);
    }
    DeRef(_0);

    /** map.e:293			index_hash += 1*/
    _0 = _index_hash_14846;
    if (IS_ATOM_INT(_index_hash_14846)) {
        _index_hash_14846 = _index_hash_14846 + 1;
        if (_index_hash_14846 > MAXINT){
            _index_hash_14846 = NewDouble((eudouble)_index_hash_14846);
        }
    }
    else
    _index_hash_14846 = binary_op(PLUS, 1, _index_hash_14846);
    DeRef(_0);

    /** map.e:294			index_hash = and_bits( 0xffff_ffff, index_hash )*/
    _0 = _index_hash_14846;
    if (IS_ATOM_INT(_index_hash_14846)) {
        temp_d.dbl = (eudouble)_index_hash_14846;
        _index_hash_14846 = Dand_bits(DBL_PTR(_8494), &temp_d);
    }
    else
    _index_hash_14846 = Dand_bits(DBL_PTR(_8494), DBL_PTR(_index_hash_14846));
    DeRef(_0);

    /** map.e:295			index = and_bits( mask, index_hash )*/
    if (IS_ATOM_INT(_index_hash_14846)) {
        {uintptr_t tu;
             tu = (uintptr_t)_mask_14840 & (uintptr_t)_index_hash_14846;
             _index_14843 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)_mask_14840;
        _index_14843 = Dand_bits(&temp_d, DBL_PTR(_index_hash_14846));
    }
    if (!IS_ATOM_INT(_index_14843)) {
        _1 = (object)(DBL_PTR(_index_14843)->dbl);
        DeRefDS(_index_14843);
        _index_14843 = _1;
    }

    /** map.e:296			index += 1*/
    _index_14843 = _index_14843 + 1;

    /** map.e:297			perturb = floor( perturb / 32 )*/
    if (32 > 0 && _perturb_14848 >= 0) {
        _perturb_14848 = _perturb_14848 / 32;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_perturb_14848 / (eudouble)32);
        _perturb_14848 = (object)temp_dbl;
    }

    /** map.e:298		entry*/
L1: 

    /** map.e:299			slot = slots[index]*/
    DeRef(_slot_14847);
    _2 = (object)SEQ_PTR(_slots_14839);
    _slot_14847 = (object)*(((s1_ptr)_2)->base + _index_14843);
    Ref(_slot_14847);

    /** map.e:300			this_hash = slot[SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slot_14847);
    _this_hash_14849 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_this_hash_14849))
    _this_hash_14849 = (object)DBL_PTR(_this_hash_14849)->dbl;

    /** map.e:301			if this_hash = EMPTY then*/
    if (_this_hash_14849 != -2)
    goto L5; // [156] 169

    /** map.e:302				return index*/
    DeRef(_key_14836);
    DeRefDS(_slots_14839);
    DeRef(_index_hash_14846);
    DeRefDS(_slot_14847);
    DeRef(_this_key_14850);
    DeRef(_8486);
    _8486 = NOVALUE;
    DeRef(_8489);
    _8489 = NOVALUE;
    return _index_14843;
    goto L6; // [166] 200
L5: 

    /** map.e:303			elsif looks > length( slots ) then*/
    if (IS_SEQUENCE(_slots_14839)){
            _8502 = SEQ_PTR(_slots_14839)->length;
    }
    else {
        _8502 = 1;
    }
    if (_looks_14851 <= _8502)
    goto L7; // [174] 187

    /** map.e:304				return removed_slot*/
    DeRef(_key_14836);
    DeRefDS(_slots_14839);
    DeRef(_index_hash_14846);
    DeRef(_slot_14847);
    DeRef(_this_key_14850);
    DeRef(_8486);
    _8486 = NOVALUE;
    DeRef(_8489);
    _8489 = NOVALUE;
    return _removed_slot_14852;
    goto L6; // [184] 200
L7: 

    /** map.e:305			elsif this_hash = REMOVED then*/
    if (_this_hash_14849 != -1)
    goto L8; // [189] 199

    /** map.e:306				removed_slot = index*/
    _removed_slot_14852 = _index_14843;
L8: 
L6: 

    /** map.e:308			this_key = slot[SLOT_KEY]*/
    DeRef(_this_key_14850);
    _2 = (object)SEQ_PTR(_slot_14847);
    _this_key_14850 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_this_key_14850);

    /** map.e:309			looks += 1*/
    _looks_14851 = _looks_14851 + 1;

    /** map.e:310		end while*/
    goto L2; // [214] 57
L4: 

    /** map.e:311		return index*/
    DeRef(_key_14836);
    DeRefDS(_slots_14839);
    DeRef(_index_hash_14846);
    DeRef(_slot_14847);
    DeRef(_this_key_14850);
    DeRef(_8486);
    _8486 = NOVALUE;
    DeRef(_8489);
    _8489 = NOVALUE;
    return _index_14843;
    ;
}


object _34rehash_seq(object _old_map_14880, object _size_14881)
{
    object _old_size_14882 = NOVALUE;
    object _index_14884 = NOVALUE;
    object _new_map_14897 = NOVALUE;
    object _slots_14899 = NOVALUE;
    object _old_slots_14902 = NOVALUE;
    object _old_slot_14907 = NOVALUE;
    object _old_hash_14909 = NOVALUE;
    object _8523 = NOVALUE;
    object _8519 = NOVALUE;
    object _8517 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:316		integer old_size = old_map[MAP_SIZE]*/
    _2 = (object)SEQ_PTR(_old_map_14880);
    _old_size_14882 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_old_size_14882))
    _old_size_14882 = (object)DBL_PTR(_old_size_14882)->dbl;

    /** map.e:319		if size = 0 then*/

    /** map.e:320			if old_size > 50_000 then*/
    if (_old_size_14882 <= 50000)
    goto L1; // [19] 32

    /** map.e:321				size = old_size * 2*/
    _size_14881 = _old_size_14882 + _old_size_14882;
    goto L2; // [29] 69
L1: 

    /** map.e:323				size = old_size * 4*/
    _size_14881 = _old_size_14882 * 4;
    goto L2; // [41] 69

    /** map.e:325		elsif size < old_size then*/
    if (_size_14881 >= _old_size_14882)
    goto L3; // [46] 68

    /** map.e:326			size = old_size*/
    _size_14881 = _old_size_14882;

    /** map.e:327			if size < DEFAULT_SIZE then*/
    if (_size_14881 >= 8)
    goto L4; // [57] 67

    /** map.e:328				size = DEFAULT_SIZE*/
    _size_14881 = 8;
L4: 
L3: 
L2: 

    /** map.e:332		sequence new_map = new_map_seq( size )*/
    _0 = _new_map_14897;
    _new_map_14897 = _34new_map_seq(_size_14881);
    DeRef(_0);

    /** map.e:333		sequence slots = new_map[MAP_SLOTS]*/
    DeRef(_slots_14899);
    _2 = (object)SEQ_PTR(_new_map_14897);
    _slots_14899 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_14899);

    /** map.e:334		new_map[MAP_SLOTS] = 0*/
    _2 = (object)SEQ_PTR(_new_map_14897);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_map_14897 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** map.e:335		new_map[MAP_SIZE] = old_map[MAP_SIZE]*/
    _2 = (object)SEQ_PTR(_old_map_14880);
    _8517 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_8517);
    _2 = (object)SEQ_PTR(_new_map_14897);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_map_14897 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _8517;
    if( _1 != _8517 ){
        DeRef(_1);
    }
    _8517 = NOVALUE;

    /** map.e:337		sequence old_slots = old_map[MAP_SLOTS]*/
    DeRef(_old_slots_14902);
    _2 = (object)SEQ_PTR(_old_map_14880);
    _old_slots_14902 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_old_slots_14902);

    /** map.e:338		for i = 1 to length( old_slots ) do*/
    if (IS_SEQUENCE(_old_slots_14902)){
            _8519 = SEQ_PTR(_old_slots_14902)->length;
    }
    else {
        _8519 = 1;
    }
    {
        object _i_14905;
        _i_14905 = 1;
L5: 
        if (_i_14905 > _8519){
            goto L6; // [114] 171
        }

        /** map.e:339			sequence old_slot = old_slots[i]*/
        DeRef(_old_slot_14907);
        _2 = (object)SEQ_PTR(_old_slots_14902);
        _old_slot_14907 = (object)*(((s1_ptr)_2)->base + _i_14905);
        Ref(_old_slot_14907);

        /** map.e:340			integer old_hash = old_slot[SLOT_HASH]*/
        _2 = (object)SEQ_PTR(_old_slot_14907);
        _old_hash_14909 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_old_hash_14909))
        _old_hash_14909 = (object)DBL_PTR(_old_hash_14909)->dbl;

        /** map.e:341			if old_hash != -1 then*/
        if (_old_hash_14909 == -1)
        goto L7; // [137] 162

        /** map.e:342				index = lookup( old_slot[SLOT_KEY], old_hash, slots )*/
        _2 = (object)SEQ_PTR(_old_slot_14907);
        _8523 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_8523);
        RefDS(_slots_14899);
        _index_14884 = _34lookup(_8523, _old_hash_14909, _slots_14899);
        _8523 = NOVALUE;
        if (!IS_ATOM_INT(_index_14884)) {
            _1 = (object)(DBL_PTR(_index_14884)->dbl);
            DeRefDS(_index_14884);
            _index_14884 = _1;
        }

        /** map.e:343				slots[index] = old_slot*/
        RefDS(_old_slot_14907);
        _2 = (object)SEQ_PTR(_slots_14899);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_14899 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_14884);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _old_slot_14907;
        DeRef(_1);
L7: 
        DeRef(_old_slot_14907);
        _old_slot_14907 = NOVALUE;

        /** map.e:345		end for*/
        _i_14905 = _i_14905 + 1;
        goto L5; // [166] 121
L6: 
        ;
    }

    /** map.e:346		new_map[MAP_SLOTS] = slots*/
    RefDS(_slots_14899);
    _2 = (object)SEQ_PTR(_new_map_14897);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_map_14897 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _slots_14899;
    DeRef(_1);

    /** map.e:347		return new_map*/
    DeRefDS(_old_map_14880);
    DeRefDS(_slots_14899);
    DeRef(_old_slots_14902);
    return _new_map_14897;
    ;
}


object _34new_extra(object _the_map_p_14917, object _initial_size_p_14918)
{
    object _new_1__tmp_at22_14924 = NOVALUE;
    object _new_inlined_new_at_22_14923 = NOVALUE;
    object _8525 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:376		if map(the_map_p) then*/
    Ref(_the_map_p_14917);
    _8525 = _34map(_the_map_p_14917);
    if (_8525 == 0) {
        DeRef(_8525);
        _8525 = NOVALUE;
        goto L1; // [9] 21
    }
    else {
        if (!IS_ATOM_INT(_8525) && DBL_PTR(_8525)->dbl == 0.0){
            DeRef(_8525);
            _8525 = NOVALUE;
            goto L1; // [9] 21
        }
        DeRef(_8525);
        _8525 = NOVALUE;
    }
    DeRef(_8525);
    _8525 = NOVALUE;

    /** map.e:377			return the_map_p*/
    return _the_map_p_14917;
    goto L2; // [18] 42
L1: 

    /** map.e:379			return new(initial_size_p)*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at22_14924;
    _new_1__tmp_at22_14924 = _34new_map_seq(_initial_size_p_14918);
    DeRef(_0);
    Ref(_new_1__tmp_at22_14924);
    _0 = _new_inlined_new_at_22_14923;
    _new_inlined_new_at_22_14923 = _35malloc(_new_1__tmp_at22_14924, 1);
    DeRef(_0);
    DeRef(_new_1__tmp_at22_14924);
    _new_1__tmp_at22_14924 = NOVALUE;
    DeRef(_the_map_p_14917);
    return _new_inlined_new_at_22_14923;
L2: 
    ;
}


object _34has(object _the_map_p_14958, object _key_14959)
{
    object _hashval_14960 = NOVALUE;
    object _hash_inlined_hash_at_2_14962 = NOVALUE;
    object _slots_14963 = NOVALUE;
    object _index_14966 = NOVALUE;
    object _8544 = NOVALUE;
    object _8543 = NOVALUE;
    object _8542 = NOVALUE;
    object _8539 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:464		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_14960 = calc_hash(_key_14959, -6);

    /** map.e:465		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_the_map_p_14958)){
        _8539 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_14958)->dbl));
    }
    else{
        _8539 = (object)*(((s1_ptr)_2)->base + _the_map_p_14958);
    }
    DeRef(_slots_14963);
    _2 = (object)SEQ_PTR(_8539);
    _slots_14963 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_14963);
    _8539 = NOVALUE;

    /** map.e:466		integer index = lookup( key, hashval, slots )*/
    Ref(_key_14959);
    RefDS(_slots_14963);
    _index_14966 = _34lookup(_key_14959, _hashval_14960, _slots_14963);
    if (!IS_ATOM_INT(_index_14966)) {
        _1 = (object)(DBL_PTR(_index_14966)->dbl);
        DeRefDS(_index_14966);
        _index_14966 = _1;
    }

    /** map.e:468		return hashval = slots[index][SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slots_14963);
    _8542 = (object)*(((s1_ptr)_2)->base + _index_14966);
    _2 = (object)SEQ_PTR(_8542);
    _8543 = (object)*(((s1_ptr)_2)->base + 1);
    _8542 = NOVALUE;
    if (IS_ATOM_INT(_8543)) {
        _8544 = (_hashval_14960 == _8543);
    }
    else {
        _8544 = binary_op(EQUALS, _hashval_14960, _8543);
    }
    _8543 = NOVALUE;
    DeRef(_the_map_p_14958);
    DeRef(_key_14959);
    DeRefDS(_slots_14963);
    return _8544;
    ;
}


object _34get(object _the_map_p_14973, object _key_14974, object _default_14975)
{
    object _hashval_14976 = NOVALUE;
    object _hash_inlined_hash_at_2_14978 = NOVALUE;
    object _slots_14979 = NOVALUE;
    object _index_14982 = NOVALUE;
    object _slot_14984 = NOVALUE;
    object _8551 = NOVALUE;
    object _8549 = NOVALUE;
    object _8545 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:505		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_14976 = calc_hash(_key_14974, -6);

    /** map.e:506		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_the_map_p_14973)){
        _8545 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_14973)->dbl));
    }
    else{
        _8545 = (object)*(((s1_ptr)_2)->base + _the_map_p_14973);
    }
    DeRef(_slots_14979);
    _2 = (object)SEQ_PTR(_8545);
    _slots_14979 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_14979);
    _8545 = NOVALUE;

    /** map.e:507		integer index = lookup( key, hashval, slots )*/
    Ref(_key_14974);
    RefDS(_slots_14979);
    _index_14982 = _34lookup(_key_14974, _hashval_14976, _slots_14979);
    if (!IS_ATOM_INT(_index_14982)) {
        _1 = (object)(DBL_PTR(_index_14982)->dbl);
        DeRefDS(_index_14982);
        _index_14982 = _1;
    }

    /** map.e:508		sequence slot = slots[index]*/
    DeRef(_slot_14984);
    _2 = (object)SEQ_PTR(_slots_14979);
    _slot_14984 = (object)*(((s1_ptr)_2)->base + _index_14982);
    Ref(_slot_14984);

    /** map.e:509		if hashval = slot[SLOT_HASH] then*/
    _2 = (object)SEQ_PTR(_slot_14984);
    _8549 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _hashval_14976, _8549)){
        _8549 = NOVALUE;
        goto L1; // [50] 65
    }
    _8549 = NOVALUE;

    /** map.e:510			return slot[SLOT_VALUE]*/
    _2 = (object)SEQ_PTR(_slot_14984);
    _8551 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_8551);
    DeRef(_the_map_p_14973);
    DeRef(_key_14974);
    DeRef(_default_14975);
    DeRefDS(_slots_14979);
    DeRefDS(_slot_14984);
    return _8551;
L1: 

    /** map.e:512		return default*/
    DeRef(_the_map_p_14973);
    DeRef(_key_14974);
    DeRef(_slots_14979);
    DeRef(_slot_14984);
    _8551 = NOVALUE;
    return _default_14975;
    ;
}


void _34put(object _the_map_p_15012, object _key_15013, object _val_15014, object _op_15015, object _deprecated_15016)
{
    object _hashval_15017 = NOVALUE;
    object _hash_inlined_hash_at_2_15019 = NOVALUE;
    object _the_map_seq_15020 = NOVALUE;
    object _slots_15022 = NOVALUE;
    object _index_15024 = NOVALUE;
    object _old_hash_15026 = NOVALUE;
    object _msg_inlined_crash_at_288_15069 = NOVALUE;
    object _msg_inlined_crash_at_348_15079 = NOVALUE;
    object _msg_inlined_crash_at_535_15111 = NOVALUE;
    object _8618 = NOVALUE;
    object _8616 = NOVALUE;
    object _8615 = NOVALUE;
    object _8614 = NOVALUE;
    object _8613 = NOVALUE;
    object _8612 = NOVALUE;
    object _8610 = NOVALUE;
    object _8609 = NOVALUE;
    object _8608 = NOVALUE;
    object _8607 = NOVALUE;
    object _8606 = NOVALUE;
    object _8605 = NOVALUE;
    object _8603 = NOVALUE;
    object _8602 = NOVALUE;
    object _8601 = NOVALUE;
    object _8600 = NOVALUE;
    object _8598 = NOVALUE;
    object _8597 = NOVALUE;
    object _8596 = NOVALUE;
    object _8595 = NOVALUE;
    object _8592 = NOVALUE;
    object _8591 = NOVALUE;
    object _8590 = NOVALUE;
    object _8589 = NOVALUE;
    object _8588 = NOVALUE;
    object _8586 = NOVALUE;
    object _8585 = NOVALUE;
    object _8584 = NOVALUE;
    object _8583 = NOVALUE;
    object _8582 = NOVALUE;
    object _8580 = NOVALUE;
    object _8577 = NOVALUE;
    object _8576 = NOVALUE;
    object _8574 = NOVALUE;
    object _8569 = NOVALUE;
    object _8568 = NOVALUE;
    object _8565 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:579		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_15017 = calc_hash(_key_15013, -6);

    /** map.e:580		sequence the_map_seq = eumem:ram_space[the_map_p]*/
    DeRef(_the_map_seq_15020);
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_the_map_p_15012)){
        _the_map_seq_15020 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15012)->dbl));
    }
    else{
        _the_map_seq_15020 = (object)*(((s1_ptr)_2)->base + _the_map_p_15012);
    }
    Ref(_the_map_seq_15020);

    /** map.e:581		eumem:ram_space[the_map_p] = 0*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15012))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15012)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _the_map_p_15012);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** map.e:582		sequence slots = the_map_seq[MAP_SLOTS]*/
    DeRef(_slots_15022);
    _2 = (object)SEQ_PTR(_the_map_seq_15020);
    _slots_15022 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_15022);

    /** map.e:584		integer index = lookup( key, hashval, slots )*/
    Ref(_key_15013);
    RefDS(_slots_15022);
    _index_15024 = _34lookup(_key_15013, _hashval_15017, _slots_15022);
    if (!IS_ATOM_INT(_index_15024)) {
        _1 = (object)(DBL_PTR(_index_15024)->dbl);
        DeRefDS(_index_15024);
        _index_15024 = _1;
    }

    /** map.e:585		integer old_hash = slots[index][SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slots_15022);
    _8565 = (object)*(((s1_ptr)_2)->base + _index_15024);
    _2 = (object)SEQ_PTR(_8565);
    _old_hash_15026 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_old_hash_15026)){
        _old_hash_15026 = (object)DBL_PTR(_old_hash_15026)->dbl;
    }
    _8565 = NOVALUE;

    /** map.e:587		if old_hash < 0 then*/
    if (_old_hash_15026 >= 0)
    goto L1; // [62] 142

    /** map.e:589			if the_map_seq[MAP_SIZE] > the_map_seq[MAP_MAX] then*/
    _2 = (object)SEQ_PTR(_the_map_seq_15020);
    _8568 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_the_map_seq_15020);
    _8569 = (object)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(LESSEQ, _8568, _8569)){
        _8568 = NOVALUE;
        _8569 = NOVALUE;
        goto L2; // [76] 127
    }
    _8568 = NOVALUE;
    _8569 = NOVALUE;

    /** map.e:590				slots = {}*/
    RefDS(_5);
    DeRefDS(_slots_15022);
    _slots_15022 = _5;

    /** map.e:591				the_map_seq = rehash_seq( the_map_seq )*/
    RefDS(_the_map_seq_15020);
    _0 = _the_map_seq_15020;
    _the_map_seq_15020 = _34rehash_seq(_the_map_seq_15020, 0);
    DeRefDS(_0);

    /** map.e:592				slots = the_map_seq[MAP_SLOTS]*/
    DeRefDS(_slots_15022);
    _2 = (object)SEQ_PTR(_the_map_seq_15020);
    _slots_15022 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_15022);

    /** map.e:593				index = lookup( key, hashval, slots )*/
    Ref(_key_15013);
    RefDS(_slots_15022);
    _index_15024 = _34lookup(_key_15013, _hashval_15017, _slots_15022);
    if (!IS_ATOM_INT(_index_15024)) {
        _1 = (object)(DBL_PTR(_index_15024)->dbl);
        DeRefDS(_index_15024);
        _index_15024 = _1;
    }

    /** map.e:594				old_hash = slots[index][SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slots_15022);
    _8574 = (object)*(((s1_ptr)_2)->base + _index_15024);
    _2 = (object)SEQ_PTR(_8574);
    _old_hash_15026 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_old_hash_15026)){
        _old_hash_15026 = (object)DBL_PTR(_old_hash_15026)->dbl;
    }
    _8574 = NOVALUE;
L2: 

    /** map.e:596			the_map_seq[MAP_SIZE] += 1*/
    _2 = (object)SEQ_PTR(_the_map_seq_15020);
    _8576 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8576)) {
        _8577 = _8576 + 1;
        if (_8577 > MAXINT){
            _8577 = NewDouble((eudouble)_8577);
        }
    }
    else
    _8577 = binary_op(PLUS, 1, _8576);
    _8576 = NOVALUE;
    _2 = (object)SEQ_PTR(_the_map_seq_15020);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _the_map_seq_15020 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _8577;
    if( _1 != _8577 ){
        DeRef(_1);
    }
    _8577 = NOVALUE;
L1: 

    /** map.e:599		the_map_seq[MAP_SLOTS] = 0*/
    _2 = (object)SEQ_PTR(_the_map_seq_15020);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _the_map_seq_15020 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** map.e:601		switch op do*/
    _0 = _op_15015;
    switch ( _0 ){ 

        /** map.e:602			case PUT then*/
        case 1:

        /** map.e:603				slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15017;
        Ref(_key_15013);
        ((intptr_t*)_2)[2] = _key_15013;
        Ref(_val_15014);
        ((intptr_t*)_2)[3] = _val_15014;
        _8580 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15022);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15022 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15024);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8580;
        if( _1 != _8580 ){
            DeRef(_1);
        }
        _8580 = NOVALUE;
        goto L3; // [171] 555

        /** map.e:604			case ADD then*/
        case 2:

        /** map.e:605				if old_hash < 0 then*/
        if (_old_hash_15026 >= 0)
        goto L4; // [179] 198

        /** map.e:606					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15017;
        Ref(_key_15013);
        ((intptr_t*)_2)[2] = _key_15013;
        Ref(_val_15014);
        ((intptr_t*)_2)[3] = _val_15014;
        _8582 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15022);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15022 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15024);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8582;
        if( _1 != _8582 ){
            DeRef(_1);
        }
        _8582 = NOVALUE;
        goto L3; // [195] 555
L4: 

        /** map.e:608					slots[index] = { hashval, key, val + slots[index][SLOT_VALUE] }*/
        _2 = (object)SEQ_PTR(_slots_15022);
        _8583 = (object)*(((s1_ptr)_2)->base + _index_15024);
        _2 = (object)SEQ_PTR(_8583);
        _8584 = (object)*(((s1_ptr)_2)->base + 3);
        _8583 = NOVALUE;
        if (IS_ATOM_INT(_val_15014) && IS_ATOM_INT(_8584)) {
            _8585 = _val_15014 + _8584;
            if ((object)((uintptr_t)_8585 + (uintptr_t)HIGH_BITS) >= 0){
                _8585 = NewDouble((eudouble)_8585);
            }
        }
        else {
            _8585 = binary_op(PLUS, _val_15014, _8584);
        }
        _8584 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15017;
        Ref(_key_15013);
        ((intptr_t*)_2)[2] = _key_15013;
        ((intptr_t*)_2)[3] = _8585;
        _8586 = MAKE_SEQ(_1);
        _8585 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15022);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15022 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15024);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8586;
        if( _1 != _8586 ){
            DeRef(_1);
        }
        _8586 = NOVALUE;
        goto L3; // [223] 555

        /** map.e:610			case SUBTRACT then*/
        case 3:

        /** map.e:611				if old_hash < 0 then*/
        if (_old_hash_15026 >= 0)
        goto L5; // [231] 250

        /** map.e:612					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15017;
        Ref(_key_15013);
        ((intptr_t*)_2)[2] = _key_15013;
        Ref(_val_15014);
        ((intptr_t*)_2)[3] = _val_15014;
        _8588 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15022);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15022 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15024);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8588;
        if( _1 != _8588 ){
            DeRef(_1);
        }
        _8588 = NOVALUE;
        goto L3; // [247] 555
L5: 

        /** map.e:614					slots[index] = { hashval, key, slots[index][SLOT_VALUE] - val }*/
        _2 = (object)SEQ_PTR(_slots_15022);
        _8589 = (object)*(((s1_ptr)_2)->base + _index_15024);
        _2 = (object)SEQ_PTR(_8589);
        _8590 = (object)*(((s1_ptr)_2)->base + 3);
        _8589 = NOVALUE;
        if (IS_ATOM_INT(_8590) && IS_ATOM_INT(_val_15014)) {
            _8591 = _8590 - _val_15014;
            if ((object)((uintptr_t)_8591 +(uintptr_t) HIGH_BITS) >= 0){
                _8591 = NewDouble((eudouble)_8591);
            }
        }
        else {
            _8591 = binary_op(MINUS, _8590, _val_15014);
        }
        _8590 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15017;
        Ref(_key_15013);
        ((intptr_t*)_2)[2] = _key_15013;
        ((intptr_t*)_2)[3] = _8591;
        _8592 = MAKE_SEQ(_1);
        _8591 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15022);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15022 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15024);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8592;
        if( _1 != _8592 ){
            DeRef(_1);
        }
        _8592 = NOVALUE;
        goto L3; // [275] 555

        /** map.e:617			case MULTIPLY then*/
        case 4:

        /** map.e:618				if old_hash < 0 then*/
        if (_old_hash_15026 >= 0)
        goto L6; // [283] 310

        /** map.e:619					error:crash("Inappropriate initial operation given to map.e:put()")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_288_15069);
        _msg_inlined_crash_at_288_15069 = EPrintf(-9999999, _8594, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_288_15069);

        /** error.e:53	end procedure*/
        goto L7; // [302] 305
L7: 
        DeRefi(_msg_inlined_crash_at_288_15069);
        _msg_inlined_crash_at_288_15069 = NOVALUE;
        goto L3; // [307] 555
L6: 

        /** map.e:621					slots[index] = { hashval, key, val * slots[index][SLOT_VALUE] }*/
        _2 = (object)SEQ_PTR(_slots_15022);
        _8595 = (object)*(((s1_ptr)_2)->base + _index_15024);
        _2 = (object)SEQ_PTR(_8595);
        _8596 = (object)*(((s1_ptr)_2)->base + 3);
        _8595 = NOVALUE;
        if (IS_ATOM_INT(_val_15014) && IS_ATOM_INT(_8596)) {
            if (_val_15014 == (short)_val_15014 && _8596 <= INT15 && _8596 >= -INT15){
                _8597 = _val_15014 * _8596;
            }
            else{
                _8597 = NewDouble(_val_15014 * (eudouble)_8596);
            }
        }
        else {
            _8597 = binary_op(MULTIPLY, _val_15014, _8596);
        }
        _8596 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15017;
        Ref(_key_15013);
        ((intptr_t*)_2)[2] = _key_15013;
        ((intptr_t*)_2)[3] = _8597;
        _8598 = MAKE_SEQ(_1);
        _8597 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15022);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15022 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15024);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8598;
        if( _1 != _8598 ){
            DeRef(_1);
        }
        _8598 = NOVALUE;
        goto L3; // [335] 555

        /** map.e:624			case DIVIDE then*/
        case 5:

        /** map.e:625				if old_hash < 0 then*/
        if (_old_hash_15026 >= 0)
        goto L8; // [343] 370

        /** map.e:626					error:crash("Inappropriate initial operation given to map.e:put()")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_348_15079);
        _msg_inlined_crash_at_348_15079 = EPrintf(-9999999, _8594, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_348_15079);

        /** error.e:53	end procedure*/
        goto L9; // [362] 365
L9: 
        DeRefi(_msg_inlined_crash_at_348_15079);
        _msg_inlined_crash_at_348_15079 = NOVALUE;
        goto L3; // [367] 555
L8: 

        /** map.e:628					slots[index] = { hashval, key, slots[index][SLOT_VALUE] / val }*/
        _2 = (object)SEQ_PTR(_slots_15022);
        _8600 = (object)*(((s1_ptr)_2)->base + _index_15024);
        _2 = (object)SEQ_PTR(_8600);
        _8601 = (object)*(((s1_ptr)_2)->base + 3);
        _8600 = NOVALUE;
        if (IS_ATOM_INT(_8601) && IS_ATOM_INT(_val_15014)) {
            _8602 = (_8601 % _val_15014) ? NewDouble((eudouble)_8601 / _val_15014) : (_8601 / _val_15014);
        }
        else {
            _8602 = binary_op(DIVIDE, _8601, _val_15014);
        }
        _8601 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15017;
        Ref(_key_15013);
        ((intptr_t*)_2)[2] = _key_15013;
        ((intptr_t*)_2)[3] = _8602;
        _8603 = MAKE_SEQ(_1);
        _8602 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15022);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15022 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15024);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8603;
        if( _1 != _8603 ){
            DeRef(_1);
        }
        _8603 = NOVALUE;
        goto L3; // [395] 555

        /** map.e:631			case APPEND then*/
        case 6:

        /** map.e:632				if old_hash < 0 then*/
        if (_old_hash_15026 >= 0)
        goto LA; // [403] 426

        /** map.e:633					slots[index] = { hashval, key, {val} }*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_val_15014);
        ((intptr_t*)_2)[1] = _val_15014;
        _8605 = MAKE_SEQ(_1);
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15017;
        Ref(_key_15013);
        ((intptr_t*)_2)[2] = _key_15013;
        ((intptr_t*)_2)[3] = _8605;
        _8606 = MAKE_SEQ(_1);
        _8605 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15022);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15022 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15024);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8606;
        if( _1 != _8606 ){
            DeRef(_1);
        }
        _8606 = NOVALUE;
        goto L3; // [423] 555
LA: 

        /** map.e:635					slots[index] = { hashval, key, append( slots[index][SLOT_VALUE], val ) }*/
        _2 = (object)SEQ_PTR(_slots_15022);
        _8607 = (object)*(((s1_ptr)_2)->base + _index_15024);
        _2 = (object)SEQ_PTR(_8607);
        _8608 = (object)*(((s1_ptr)_2)->base + 3);
        _8607 = NOVALUE;
        Ref(_val_15014);
        Append(&_8609, _8608, _val_15014);
        _8608 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15017;
        Ref(_key_15013);
        ((intptr_t*)_2)[2] = _key_15013;
        ((intptr_t*)_2)[3] = _8609;
        _8610 = MAKE_SEQ(_1);
        _8609 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15022);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15022 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15024);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8610;
        if( _1 != _8610 ){
            DeRef(_1);
        }
        _8610 = NOVALUE;
        goto L3; // [451] 555

        /** map.e:638			case CONCAT then*/
        case 7:

        /** map.e:639				if old_hash < 0 then*/
        if (_old_hash_15026 >= 0)
        goto LB; // [459] 478

        /** map.e:640					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15017;
        Ref(_key_15013);
        ((intptr_t*)_2)[2] = _key_15013;
        Ref(_val_15014);
        ((intptr_t*)_2)[3] = _val_15014;
        _8612 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15022);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15022 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15024);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8612;
        if( _1 != _8612 ){
            DeRef(_1);
        }
        _8612 = NOVALUE;
        goto L3; // [475] 555
LB: 

        /** map.e:642					slots[index] = { hashval, key, slots[index][SLOT_VALUE] & val }*/
        _2 = (object)SEQ_PTR(_slots_15022);
        _8613 = (object)*(((s1_ptr)_2)->base + _index_15024);
        _2 = (object)SEQ_PTR(_8613);
        _8614 = (object)*(((s1_ptr)_2)->base + 3);
        _8613 = NOVALUE;
        if (IS_SEQUENCE(_8614) && IS_ATOM(_val_15014)) {
            Ref(_val_15014);
            Append(&_8615, _8614, _val_15014);
        }
        else if (IS_ATOM(_8614) && IS_SEQUENCE(_val_15014)) {
            Ref(_8614);
            Prepend(&_8615, _val_15014, _8614);
        }
        else {
            Concat((object_ptr)&_8615, _8614, _val_15014);
            _8614 = NOVALUE;
        }
        _8614 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15017;
        Ref(_key_15013);
        ((intptr_t*)_2)[2] = _key_15013;
        ((intptr_t*)_2)[3] = _8615;
        _8616 = MAKE_SEQ(_1);
        _8615 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15022);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15022 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15024);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8616;
        if( _1 != _8616 ){
            DeRef(_1);
        }
        _8616 = NOVALUE;
        goto L3; // [503] 555

        /** map.e:645			case LEAVE then*/
        case 8:

        /** map.e:646				if old_hash < 0 then*/
        if (_old_hash_15026 >= 0)
        goto L3; // [511] 555

        /** map.e:647					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15017;
        Ref(_key_15013);
        ((intptr_t*)_2)[2] = _key_15013;
        Ref(_val_15014);
        ((intptr_t*)_2)[3] = _val_15014;
        _8618 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15022);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15022 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15024);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8618;
        if( _1 != _8618 ){
            DeRef(_1);
        }
        _8618 = NOVALUE;
        goto L3; // [528] 555

        /** map.e:649			case else*/
        default:

        /** map.e:650				error:crash("Unknown operation given to map.e:put()")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_535_15111);
        _msg_inlined_crash_at_535_15111 = EPrintf(-9999999, _8619, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_535_15111);

        /** error.e:53	end procedure*/
        goto LC; // [549] 552
LC: 
        DeRefi(_msg_inlined_crash_at_535_15111);
        _msg_inlined_crash_at_535_15111 = NOVALUE;
    ;}L3: 

    /** map.e:654		the_map_seq[MAP_SLOTS] = slots*/
    RefDS(_slots_15022);
    _2 = (object)SEQ_PTR(_the_map_seq_15020);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _the_map_seq_15020 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _slots_15022;
    DeRef(_1);

    /** map.e:655		eumem:ram_space[the_map_p] = the_map_seq*/
    RefDS(_the_map_seq_15020);
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15012))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15012)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _the_map_p_15012);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _the_map_seq_15020;
    DeRef(_1);

    /** map.e:656	end procedure*/
    DeRef(_the_map_p_15012);
    DeRef(_key_15013);
    DeRef(_val_15014);
    DeRefDS(_the_map_seq_15020);
    DeRefDS(_slots_15022);
    return;
    ;
}


void _34nested_put(object _the_map_p_15114, object _the_keys_p_15115, object _the_value_p_15116, object _operation_p_15117, object _deprecated_trigger_p_15118)
{
    object _temp_map__15119 = NOVALUE;
    object _8630 = NOVALUE;
    object _8629 = NOVALUE;
    object _8628 = NOVALUE;
    object _8627 = NOVALUE;
    object _8626 = NOVALUE;
    object _8624 = NOVALUE;
    object _8623 = NOVALUE;
    object _8622 = NOVALUE;
    object _8620 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:701		if length( the_keys_p ) = 1 then*/
    if (IS_SEQUENCE(_the_keys_p_15115)){
            _8620 = SEQ_PTR(_the_keys_p_15115)->length;
    }
    else {
        _8620 = 1;
    }
    if (_8620 != 1)
    goto L1; // [10] 30

    /** map.e:702			put( the_map_p, the_keys_p[1], the_value_p, operation_p )*/
    _2 = (object)SEQ_PTR(_the_keys_p_15115);
    _8622 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_15114);
    Ref(_8622);
    Ref(_the_value_p_15116);
    _34put(_the_map_p_15114, _8622, _the_value_p_15116, _operation_p_15117, 0);
    _8622 = NOVALUE;
    goto L2; // [27] 84
L1: 

    /** map.e:704			temp_map_ = new_extra( get( the_map_p, the_keys_p[1] ) )*/
    _2 = (object)SEQ_PTR(_the_keys_p_15115);
    _8623 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_15114);
    Ref(_8623);
    _8624 = _34get(_the_map_p_15114, _8623, 0);
    _8623 = NOVALUE;
    _0 = _temp_map__15119;
    _temp_map__15119 = _34new_extra(_8624, 8);
    DeRef(_0);
    _8624 = NOVALUE;

    /** map.e:705			nested_put( temp_map_, the_keys_p[2..$], the_value_p, operation_p )*/
    if (IS_SEQUENCE(_the_keys_p_15115)){
            _8626 = SEQ_PTR(_the_keys_p_15115)->length;
    }
    else {
        _8626 = 1;
    }
    rhs_slice_target = (object_ptr)&_8627;
    RHS_Slice(_the_keys_p_15115, 2, _8626);
    Ref(_the_value_p_15116);
    DeRef(_8628);
    _8628 = _the_value_p_15116;
    DeRef(_8629);
    _8629 = _operation_p_15117;
    Ref(_temp_map__15119);
    _34nested_put(_temp_map__15119, _8627, _8628, _8629, 0);
    _8627 = NOVALUE;
    _8628 = NOVALUE;
    _8629 = NOVALUE;

    /** map.e:706			put( the_map_p, the_keys_p[1], temp_map_, PUT )*/
    _2 = (object)SEQ_PTR(_the_keys_p_15115);
    _8630 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_15114);
    Ref(_8630);
    Ref(_temp_map__15119);
    _34put(_the_map_p_15114, _8630, _temp_map__15119, 1, 0);
    _8630 = NOVALUE;
L2: 

    /** map.e:708	end procedure*/
    DeRef(_the_map_p_15114);
    DeRefDS(_the_keys_p_15115);
    DeRef(_the_value_p_15116);
    DeRef(_temp_map__15119);
    return;
    ;
}


void _34remove(object _the_map_p_15135, object _key_15136)
{
    object _hashval_15137 = NOVALUE;
    object _hash_inlined_hash_at_2_15139 = NOVALUE;
    object _slots_15140 = NOVALUE;
    object _index_15143 = NOVALUE;
    object _8642 = NOVALUE;
    object _8641 = NOVALUE;
    object _8639 = NOVALUE;
    object _8637 = NOVALUE;
    object _8635 = NOVALUE;
    object _8634 = NOVALUE;
    object _8631 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** map.e:733		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_15137 = calc_hash(_key_15136, -6);

    /** map.e:734		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_the_map_p_15135)){
        _8631 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15135)->dbl));
    }
    else{
        _8631 = (object)*(((s1_ptr)_2)->base + _the_map_p_15135);
    }
    DeRef(_slots_15140);
    _2 = (object)SEQ_PTR(_8631);
    _slots_15140 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_15140);
    _8631 = NOVALUE;

    /** map.e:736		integer index = lookup( key, hashval, slots )*/
    Ref(_key_15136);
    RefDS(_slots_15140);
    _index_15143 = _34lookup(_key_15136, _hashval_15137, _slots_15140);
    if (!IS_ATOM_INT(_index_15143)) {
        _1 = (object)(DBL_PTR(_index_15143)->dbl);
        DeRefDS(_index_15143);
        _index_15143 = _1;
    }

    /** map.e:737		if hashval = slots[index][SLOT_HASH] then*/
    _2 = (object)SEQ_PTR(_slots_15140);
    _8634 = (object)*(((s1_ptr)_2)->base + _index_15143);
    _2 = (object)SEQ_PTR(_8634);
    _8635 = (object)*(((s1_ptr)_2)->base + 1);
    _8634 = NOVALUE;
    if (binary_op_a(NOTEQ, _hashval_15137, _8635)){
        _8635 = NOVALUE;
        goto L1; // [46] 99
    }
    _8635 = NOVALUE;

    /** map.e:738			slots = {}*/
    RefDS(_5);
    DeRefDS(_slots_15140);
    _slots_15140 = _5;

    /** map.e:739			eumem:ram_space[the_map_p][MAP_SLOTS][index] = REMOVED_SLOT*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15135))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15135)->dbl));
    else
    _3 = (object)(_the_map_p_15135 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(2 + ((s1_ptr)_2)->base);
    _8637 = NOVALUE;
    RefDS(_34REMOVED_SLOT_14751);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _index_15143);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34REMOVED_SLOT_14751;
    DeRef(_1);
    _8637 = NOVALUE;

    /** map.e:740			eumem:ram_space[the_map_p][MAP_SIZE] -= 1*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15135))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15135)->dbl));
    else
    _3 = (object)(_the_map_p_15135 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _8641 = (object)*(((s1_ptr)_2)->base + 1);
    _8639 = NOVALUE;
    if (IS_ATOM_INT(_8641)) {
        _8642 = _8641 - 1;
        if ((object)((uintptr_t)_8642 +(uintptr_t) HIGH_BITS) >= 0){
            _8642 = NewDouble((eudouble)_8642);
        }
    }
    else {
        _8642 = binary_op(MINUS, _8641, 1);
    }
    _8641 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _8642;
    if( _1 != _8642 ){
        DeRef(_1);
    }
    _8642 = NOVALUE;
    _8639 = NOVALUE;
L1: 

    /** map.e:742	end procedure*/
    DeRef(_the_map_p_15135);
    DeRef(_key_15136);
    DeRef(_slots_15140);
    return;
    ;
}


void _34clear(object _the_map_p_15157)
{
    object _8649 = NOVALUE;
    object _8648 = NOVALUE;
    object _8647 = NOVALUE;
    object _8646 = NOVALUE;
    object _8645 = NOVALUE;
    object _8643 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** map.e:771		eumem:ram_space[the_map_p][MAP_SLOTS] = repeat( EMPTY_SLOT, length( eumem:ram_space[the_map_p][MAP_SLOTS] ) )*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15157))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15157)->dbl));
    else
    _3 = (object)(_the_map_p_15157 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_the_map_p_15157)){
        _8645 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15157)->dbl));
    }
    else{
        _8645 = (object)*(((s1_ptr)_2)->base + _the_map_p_15157);
    }
    _2 = (object)SEQ_PTR(_8645);
    _8646 = (object)*(((s1_ptr)_2)->base + 2);
    _8645 = NOVALUE;
    if (IS_SEQUENCE(_8646)){
            _8647 = SEQ_PTR(_8646)->length;
    }
    else {
        _8647 = 1;
    }
    _8646 = NOVALUE;
    _8648 = Repeat(_34EMPTY_SLOT_14749, _8647);
    _8647 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _8648;
    if( _1 != _8648 ){
        DeRef(_1);
    }
    _8648 = NOVALUE;
    _8643 = NOVALUE;

    /** map.e:772		eumem:ram_space[the_map_p][MAP_SIZE]  = 0*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15157))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15157)->dbl));
    else
    _3 = (object)(_the_map_p_15157 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _8649 = NOVALUE;

    /** map.e:773	end procedure*/
    DeRef(_the_map_p_15157);
    _8646 = NOVALUE;
    return;
    ;
}


object _34keys(object _the_map_p_15212, object _sorted_result_15213)
{
    object _slots_15214 = NOVALUE;
    object _keys_15217 = NOVALUE;
    object _kx_15221 = NOVALUE;
    object _8680 = NOVALUE;
    object _8678 = NOVALUE;
    object _8677 = NOVALUE;
    object _8676 = NOVALUE;
    object _8673 = NOVALUE;
    object _8672 = NOVALUE;
    object _8671 = NOVALUE;
    object _8669 = NOVALUE;
    object _8668 = NOVALUE;
    object _8666 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:901		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_the_map_p_15212)){
        _8666 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15212)->dbl));
    }
    else{
        _8666 = (object)*(((s1_ptr)_2)->base + _the_map_p_15212);
    }
    DeRef(_slots_15214);
    _2 = (object)SEQ_PTR(_8666);
    _slots_15214 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_15214);
    _8666 = NOVALUE;

    /** map.e:902		sequence keys = repeat( 0, eumem:ram_space[the_map_p][MAP_SIZE] )*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_the_map_p_15212)){
        _8668 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15212)->dbl));
    }
    else{
        _8668 = (object)*(((s1_ptr)_2)->base + _the_map_p_15212);
    }
    _2 = (object)SEQ_PTR(_8668);
    _8669 = (object)*(((s1_ptr)_2)->base + 1);
    _8668 = NOVALUE;
    DeRef(_keys_15217);
    _keys_15217 = Repeat(0, _8669);
    _8669 = NOVALUE;

    /** map.e:903		integer kx = 0*/
    _kx_15221 = 0;

    /** map.e:904		for i = 1 to length( slots ) do*/
    if (IS_SEQUENCE(_slots_15214)){
            _8671 = SEQ_PTR(_slots_15214)->length;
    }
    else {
        _8671 = 1;
    }
    {
        object _i_15223;
        _i_15223 = 1;
L1: 
        if (_i_15223 > _8671){
            goto L2; // [43] 106
        }

        /** map.e:905			if slots[i][SLOT_HASH] >= 0 then*/
        _2 = (object)SEQ_PTR(_slots_15214);
        _8672 = (object)*(((s1_ptr)_2)->base + _i_15223);
        _2 = (object)SEQ_PTR(_8672);
        _8673 = (object)*(((s1_ptr)_2)->base + 1);
        _8672 = NOVALUE;
        if (binary_op_a(LESS, _8673, 0)){
            _8673 = NOVALUE;
            goto L3; // [60] 99
        }
        _8673 = NOVALUE;

        /** map.e:906				kx += 1*/
        _kx_15221 = _kx_15221 + 1;

        /** map.e:907				keys[kx] = slots[i][SLOT_KEY]*/
        _2 = (object)SEQ_PTR(_slots_15214);
        _8676 = (object)*(((s1_ptr)_2)->base + _i_15223);
        _2 = (object)SEQ_PTR(_8676);
        _8677 = (object)*(((s1_ptr)_2)->base + 2);
        _8676 = NOVALUE;
        Ref(_8677);
        _2 = (object)SEQ_PTR(_keys_15217);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _keys_15217 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _kx_15221);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8677;
        if( _1 != _8677 ){
            DeRef(_1);
        }
        _8677 = NOVALUE;

        /** map.e:908				if kx = length( keys ) then*/
        if (IS_SEQUENCE(_keys_15217)){
                _8678 = SEQ_PTR(_keys_15217)->length;
        }
        else {
            _8678 = 1;
        }
        if (_kx_15221 != _8678)
        goto L4; // [89] 98

        /** map.e:909					exit*/
        goto L2; // [95] 106
L4: 
L3: 

        /** map.e:912		end for*/
        _i_15223 = _i_15223 + 1;
        goto L1; // [101] 50
L2: 
        ;
    }

    /** map.e:913		if sorted_result then*/
    if (_sorted_result_15213 == 0)
    {
        goto L5; // [108] 123
    }
    else{
    }

    /** map.e:914			return stdsort:sort( keys )*/
    RefDS(_keys_15217);
    _8680 = _25sort(_keys_15217, 1);
    DeRef(_the_map_p_15212);
    DeRef(_slots_15214);
    DeRefDS(_keys_15217);
    return _8680;
L5: 

    /** map.e:916		return keys*/
    DeRef(_the_map_p_15212);
    DeRef(_slots_15214);
    DeRef(_8680);
    _8680 = NOVALUE;
    return _keys_15217;
    ;
}


object _34pairs(object _the_map_15288, object _sorted_result_15289)
{
    object _slots_15290 = NOVALUE;
    object _pairs_15293 = NOVALUE;
    object _px_15297 = NOVALUE;
    object _8730 = NOVALUE;
    object _8728 = NOVALUE;
    object _8727 = NOVALUE;
    object _8726 = NOVALUE;
    object _8725 = NOVALUE;
    object _8724 = NOVALUE;
    object _8723 = NOVALUE;
    object _8720 = NOVALUE;
    object _8719 = NOVALUE;
    object _8718 = NOVALUE;
    object _8716 = NOVALUE;
    object _8715 = NOVALUE;
    object _8713 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:1045		sequence slots = eumem:ram_space[the_map][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_the_map_15288)){
        _8713 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_15288)->dbl));
    }
    else{
        _8713 = (object)*(((s1_ptr)_2)->base + _the_map_15288);
    }
    DeRef(_slots_15290);
    _2 = (object)SEQ_PTR(_8713);
    _slots_15290 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_15290);
    _8713 = NOVALUE;

    /** map.e:1046		sequence pairs = repeat( 0, eumem:ram_space[the_map][MAP_SIZE] )*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_the_map_15288)){
        _8715 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_15288)->dbl));
    }
    else{
        _8715 = (object)*(((s1_ptr)_2)->base + _the_map_15288);
    }
    _2 = (object)SEQ_PTR(_8715);
    _8716 = (object)*(((s1_ptr)_2)->base + 1);
    _8715 = NOVALUE;
    DeRef(_pairs_15293);
    _pairs_15293 = Repeat(0, _8716);
    _8716 = NOVALUE;

    /** map.e:1047		integer px = 0*/
    _px_15297 = 0;

    /** map.e:1048		for i = 1 to length( slots ) do*/
    if (IS_SEQUENCE(_slots_15290)){
            _8718 = SEQ_PTR(_slots_15290)->length;
    }
    else {
        _8718 = 1;
    }
    {
        object _i_15299;
        _i_15299 = 1;
L1: 
        if (_i_15299 > _8718){
            goto L2; // [43] 118
        }

        /** map.e:1049			if slots[i][SLOT_HASH] >= 0 then*/
        _2 = (object)SEQ_PTR(_slots_15290);
        _8719 = (object)*(((s1_ptr)_2)->base + _i_15299);
        _2 = (object)SEQ_PTR(_8719);
        _8720 = (object)*(((s1_ptr)_2)->base + 1);
        _8719 = NOVALUE;
        if (binary_op_a(LESS, _8720, 0)){
            _8720 = NOVALUE;
            goto L3; // [60] 111
        }
        _8720 = NOVALUE;

        /** map.e:1050				px += 1*/
        _px_15297 = _px_15297 + 1;

        /** map.e:1051				pairs[px] = { slots[i][SLOT_KEY], slots[i][SLOT_VALUE] }*/
        _2 = (object)SEQ_PTR(_slots_15290);
        _8723 = (object)*(((s1_ptr)_2)->base + _i_15299);
        _2 = (object)SEQ_PTR(_8723);
        _8724 = (object)*(((s1_ptr)_2)->base + 2);
        _8723 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15290);
        _8725 = (object)*(((s1_ptr)_2)->base + _i_15299);
        _2 = (object)SEQ_PTR(_8725);
        _8726 = (object)*(((s1_ptr)_2)->base + 3);
        _8725 = NOVALUE;
        Ref(_8726);
        Ref(_8724);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _8724;
        ((intptr_t *)_2)[2] = _8726;
        _8727 = MAKE_SEQ(_1);
        _8726 = NOVALUE;
        _8724 = NOVALUE;
        _2 = (object)SEQ_PTR(_pairs_15293);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _pairs_15293 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _px_15297);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8727;
        if( _1 != _8727 ){
            DeRef(_1);
        }
        _8727 = NOVALUE;

        /** map.e:1052				if px = length( pairs ) then*/
        if (IS_SEQUENCE(_pairs_15293)){
                _8728 = SEQ_PTR(_pairs_15293)->length;
        }
        else {
            _8728 = 1;
        }
        if (_px_15297 != _8728)
        goto L4; // [101] 110

        /** map.e:1053					exit*/
        goto L2; // [107] 118
L4: 
L3: 

        /** map.e:1056		end for*/
        _i_15299 = _i_15299 + 1;
        goto L1; // [113] 50
L2: 
        ;
    }

    /** map.e:1057		if sorted_result then*/
    if (_sorted_result_15289 == 0)
    {
        goto L5; // [120] 135
    }
    else{
    }

    /** map.e:1058			return stdsort:sort( pairs )*/
    RefDS(_pairs_15293);
    _8730 = _25sort(_pairs_15293, 1);
    DeRef(_the_map_15288);
    DeRef(_slots_15290);
    DeRefDS(_pairs_15293);
    return _8730;
L5: 

    /** map.e:1060		return pairs*/
    DeRef(_the_map_15288);
    DeRef(_slots_15290);
    DeRef(_8730);
    _8730 = NOVALUE;
    return _pairs_15293;
    ;
}



// 0x7018F17E
