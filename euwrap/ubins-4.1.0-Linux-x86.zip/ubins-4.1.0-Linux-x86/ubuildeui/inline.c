// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _66advance(object _pc_53502, object _code_53503)
{
    object _27124 = NOVALUE;
    object _27122 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:63		prev_pc = pc*/
    _66prev_pc_53485 = _pc_53502;

    /** inline.e:64		if pc > length( code ) then*/
    if (IS_SEQUENCE(_code_53503)){
            _27122 = SEQ_PTR(_code_53503)->length;
    }
    else {
        _27122 = 1;
    }
    if (_pc_53502 <= _27122)
    goto L1; // [15] 26

    /** inline.e:65			return pc*/
    DeRefDS(_code_53503);
    return _pc_53502;
L1: 

    /** inline.e:67		return shift:advance( pc, code )*/
    RefDS(_code_53503);
    _27124 = _65advance(_pc_53502, _code_53503);
    DeRefDS(_code_53503);
    return _27124;
    ;
}


void _66shift(object _start_53510, object _amount_53511, object _bound_53512)
{
    object _temp_LineTable_53513 = NOVALUE;
    object _temp_Code_53515 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_amount_53511)) {
        _1 = (object)(DBL_PTR(_amount_53511)->dbl);
        DeRefDS(_amount_53511);
        _amount_53511 = _1;
    }

    /** inline.e:72			temp_LineTable = LineTable,*/
    RefDS(_12LineTable_20316);
    DeRef(_temp_LineTable_53513);
    _temp_LineTable_53513 = _12LineTable_20316;

    /** inline.e:73			temp_Code = Code*/
    RefDS(_12Code_20315);
    DeRef(_temp_Code_53515);
    _temp_Code_53515 = _12Code_20315;

    /** inline.e:74		LineTable = {}*/
    RefDS(_22015);
    DeRefDS(_12LineTable_20316);
    _12LineTable_20316 = _22015;

    /** inline.e:75		Code = inline_code*/
    RefDS(_66inline_code_53477);
    DeRefDS(_12Code_20315);
    _12Code_20315 = _66inline_code_53477;

    /** inline.e:76		inline_code = {}*/
    RefDS(_22015);
    DeRefDS(_66inline_code_53477);
    _66inline_code_53477 = _22015;

    /** inline.e:78		shift:shift( start, amount, bound )*/
    _65shift(_start_53510, _amount_53511, _bound_53512);

    /** inline.e:80		LineTable = temp_LineTable*/
    RefDS(_temp_LineTable_53513);
    DeRefDS(_12LineTable_20316);
    _12LineTable_20316 = _temp_LineTable_53513;

    /** inline.e:81		inline_code = Code*/
    RefDS(_12Code_20315);
    DeRefDS(_66inline_code_53477);
    _66inline_code_53477 = _12Code_20315;

    /** inline.e:82		Code = temp_Code*/
    RefDS(_temp_Code_53515);
    DeRefDS(_12Code_20315);
    _12Code_20315 = _temp_Code_53515;

    /** inline.e:83	end procedure*/
    DeRefDS(_temp_LineTable_53513);
    DeRefDS(_temp_Code_53515);
    return;
    ;
}


void _66replace_code(object _code_53530, object _start_53531, object _finish_53532)
{
    object _27131 = NOVALUE;
    object _27130 = NOVALUE;
    object _27129 = NOVALUE;
    object _27128 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_finish_53532)) {
        _1 = (object)(DBL_PTR(_finish_53532)->dbl);
        DeRefDS(_finish_53532);
        _finish_53532 = _1;
    }

    /** inline.e:92		inline_code = replace( inline_code, code, start, finish )*/
    {
        intptr_t p1 = _66inline_code_53477;
        intptr_t p2 = _code_53530;
        intptr_t p3 = _start_53531;
        intptr_t p4 = _finish_53532;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_66inline_code_53477;
        Replace( &replace_params );
    }

    /** inline.e:93		shift( start , length( code ) - (finish - start + 1), finish )*/
    if (IS_SEQUENCE(_code_53530)){
            _27128 = SEQ_PTR(_code_53530)->length;
    }
    else {
        _27128 = 1;
    }
    _27129 = _finish_53532 - _start_53531;
    if ((object)((uintptr_t)_27129 +(uintptr_t) HIGH_BITS) >= 0){
        _27129 = NewDouble((eudouble)_27129);
    }
    if (IS_ATOM_INT(_27129)) {
        _27130 = _27129 + 1;
        if (_27130 > MAXINT){
            _27130 = NewDouble((eudouble)_27130);
        }
    }
    else
    _27130 = binary_op(PLUS, 1, _27129);
    DeRef(_27129);
    _27129 = NOVALUE;
    if (IS_ATOM_INT(_27130)) {
        _27131 = _27128 - _27130;
        if ((object)((uintptr_t)_27131 +(uintptr_t) HIGH_BITS) >= 0){
            _27131 = NewDouble((eudouble)_27131);
        }
    }
    else {
        _27131 = NewDouble((eudouble)_27128 - DBL_PTR(_27130)->dbl);
    }
    _27128 = NOVALUE;
    DeRef(_27130);
    _27130 = NOVALUE;
    _66shift(_start_53531, _27131, _finish_53532);
    _27131 = NOVALUE;

    /** inline.e:94	end procedure*/
    DeRefDS(_code_53530);
    return;
    ;
}


void _66defer()
{
    object _dx_53540 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:101		integer dx = find( inline_sub, deferred_inline_decisions )*/
    _dx_53540 = find_from(_66inline_sub_53491, _66deferred_inline_decisions_53493, 1);

    /** inline.e:102		if not dx then*/
    if (_dx_53540 != 0)
    goto L1; // [14] 36

    /** inline.e:103			deferred_inline_decisions &= inline_sub*/
    Append(&_66deferred_inline_decisions_53493, _66deferred_inline_decisions_53493, _66inline_sub_53491);

    /** inline.e:104			deferred_inline_calls = append( deferred_inline_calls, {} )*/
    RefDS(_22015);
    Append(&_66deferred_inline_calls_53494, _66deferred_inline_calls_53494, _22015);
L1: 

    /** inline.e:106	end procedure*/
    return;
    ;
}


object _66new_inline_temp(object _sym_53549)
{
    object _27137 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:110		inline_temps &= sym*/
    Append(&_66inline_temps_53479, _66inline_temps_53479, _sym_53549);

    /** inline.e:111		return length( inline_temps )*/
    if (IS_SEQUENCE(_66inline_temps_53479)){
            _27137 = SEQ_PTR(_66inline_temps_53479)->length;
    }
    else {
        _27137 = 1;
    }
    return _27137;
    ;
}


object _66get_inline_temp(object _sym_53555)
{
    object _temp_num_53556 = NOVALUE;
    object _27141 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:117		integer temp_num = find( sym, inline_params )*/
    _temp_num_53556 = find_from(_sym_53555, _66inline_params_53482, 1);

    /** inline.e:118		if temp_num then*/
    if (_temp_num_53556 == 0)
    {
        goto L1; // [14] 24
    }
    else{
    }

    /** inline.e:119			return temp_num*/
    return _temp_num_53556;
L1: 

    /** inline.e:122		temp_num = find( sym, proc_vars )*/
    _temp_num_53556 = find_from(_sym_53555, _66proc_vars_53478, 1);

    /** inline.e:123		if temp_num then*/
    if (_temp_num_53556 == 0)
    {
        goto L2; // [35] 45
    }
    else{
    }

    /** inline.e:124			return temp_num*/
    return _temp_num_53556;
L2: 

    /** inline.e:127		temp_num = find( sym, inline_temps )*/
    _temp_num_53556 = find_from(_sym_53555, _66inline_temps_53479, 1);

    /** inline.e:128		if temp_num then*/
    if (_temp_num_53556 == 0)
    {
        goto L3; // [56] 66
    }
    else{
    }

    /** inline.e:129			return temp_num*/
    return _temp_num_53556;
L3: 

    /** inline.e:132		return new_inline_temp( sym )*/
    _27141 = _66new_inline_temp(_sym_53555);
    return _27141;
    ;
}


object _66generic_symbol(object _sym_53567)
{
    object _inline_type_53568 = NOVALUE;
    object _px_53569 = NOVALUE;
    object _eentry_53576 = NOVALUE;
    object _27150 = NOVALUE;
    object _27149 = NOVALUE;
    object _27148 = NOVALUE;
    object _27147 = NOVALUE;
    object _27145 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:137		integer px = find( sym, inline_params )*/
    _px_53569 = find_from(_sym_53567, _66inline_params_53482, 1);

    /** inline.e:138		if px then*/
    if (_px_53569 == 0)
    {
        goto L1; // [14] 25
    }
    else{
    }

    /** inline.e:139			inline_type = INLINE_PARAM*/
    _inline_type_53568 = 1;
    goto L2; // [22] 100
L1: 

    /** inline.e:141			px = find( sym, proc_vars )*/
    _px_53569 = find_from(_sym_53567, _66proc_vars_53478, 1);

    /** inline.e:142			if px then*/
    if (_px_53569 == 0)
    {
        goto L3; // [36] 47
    }
    else{
    }

    /** inline.e:143				inline_type = INLINE_VAR*/
    _inline_type_53568 = 6;
    goto L4; // [44] 99
L3: 

    /** inline.e:145				sequence eentry = SymTab[sym]*/
    DeRef(_eentry_53576);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _eentry_53576 = (object)*(((s1_ptr)_2)->base + _sym_53567);
    Ref(_eentry_53576);

    /** inline.e:146				if is_literal( sym ) or eentry[S_SCOPE] > SC_PRIVATE then*/
    _27145 = _66is_literal(_sym_53567);
    if (IS_ATOM_INT(_27145)) {
        if (_27145 != 0) {
            goto L5; // [63] 84
        }
    }
    else {
        if (DBL_PTR(_27145)->dbl != 0.0) {
            goto L5; // [63] 84
        }
    }
    _2 = (object)SEQ_PTR(_eentry_53576);
    _27147 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_27147)) {
        _27148 = (_27147 > 3);
    }
    else {
        _27148 = binary_op(GREATER, _27147, 3);
    }
    _27147 = NOVALUE;
    if (_27148 == 0) {
        DeRef(_27148);
        _27148 = NOVALUE;
        goto L6; // [80] 91
    }
    else {
        if (!IS_ATOM_INT(_27148) && DBL_PTR(_27148)->dbl == 0.0){
            DeRef(_27148);
            _27148 = NOVALUE;
            goto L6; // [80] 91
        }
        DeRef(_27148);
        _27148 = NOVALUE;
    }
    DeRef(_27148);
    _27148 = NOVALUE;
L5: 

    /** inline.e:147					return sym*/
    DeRef(_eentry_53576);
    DeRef(_27145);
    _27145 = NOVALUE;
    return _sym_53567;
L6: 

    /** inline.e:149				inline_type = INLINE_TEMP*/
    _inline_type_53568 = 2;
    DeRef(_eentry_53576);
    _eentry_53576 = NOVALUE;
L4: 
L2: 

    /** inline.e:153		return { inline_type, get_inline_temp( sym ) }*/
    _27149 = _66get_inline_temp(_sym_53567);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _inline_type_53568;
    ((intptr_t *)_2)[2] = _27149;
    _27150 = MAKE_SEQ(_1);
    _27149 = NOVALUE;
    DeRef(_27145);
    _27145 = NOVALUE;
    return _27150;
    ;
}


object _66adjust_symbol(object _pc_53591)
{
    object _sym_53593 = NOVALUE;
    object _eentry_53599 = NOVALUE;
    object _27158 = NOVALUE;
    object _27156 = NOVALUE;
    object _27155 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_53591)) {
        _1 = (object)(DBL_PTR(_pc_53591)->dbl);
        DeRefDS(_pc_53591);
        _pc_53591 = _1;
    }

    /** inline.e:160		symtab_index sym = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    _sym_53593 = (object)*(((s1_ptr)_2)->base + _pc_53591);
    if (!IS_ATOM_INT(_sym_53593)){
        _sym_53593 = (object)DBL_PTR(_sym_53593)->dbl;
    }

    /** inline.e:161		if sym < 0 then*/
    if (_sym_53593 >= 0)
    goto L1; // [15] 28

    /** inline.e:162			return 0*/
    DeRef(_eentry_53599);
    return 0;
    goto L2; // [25] 41
L1: 

    /** inline.e:163		elsif not sym then*/
    if (_sym_53593 != 0)
    goto L3; // [30] 40

    /** inline.e:165			return 1*/
    DeRef(_eentry_53599);
    return 1;
L3: 
L2: 

    /** inline.e:168		sequence eentry = SymTab[sym]*/
    DeRef(_eentry_53599);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _eentry_53599 = (object)*(((s1_ptr)_2)->base + _sym_53593);
    Ref(_eentry_53599);

    /** inline.e:169		if is_literal( sym ) then*/
    _27155 = _66is_literal(_sym_53593);
    if (_27155 == 0) {
        DeRef(_27155);
        _27155 = NOVALUE;
        goto L4; // [57] 69
    }
    else {
        if (!IS_ATOM_INT(_27155) && DBL_PTR(_27155)->dbl == 0.0){
            DeRef(_27155);
            _27155 = NOVALUE;
            goto L4; // [57] 69
        }
        DeRef(_27155);
        _27155 = NOVALUE;
    }
    DeRef(_27155);
    _27155 = NOVALUE;

    /** inline.e:170			return 1*/
    DeRefDS(_eentry_53599);
    return 1;
    goto L5; // [66] 95
L4: 

    /** inline.e:172		elsif eentry[S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_eentry_53599);
    _27156 = (object)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _27156, 9)){
        _27156 = NOVALUE;
        goto L6; // [79] 94
    }
    _27156 = NOVALUE;

    /** inline.e:173			defer()*/
    _66defer();

    /** inline.e:174			return 0*/
    DeRefDS(_eentry_53599);
    return 0;
L6: 
L5: 

    /** inline.e:177		inline_code[pc] = generic_symbol( sym )*/
    _27158 = _66generic_symbol(_sym_53593);
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53477 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_53591);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27158;
    if( _1 != _27158 ){
        DeRef(_1);
    }
    _27158 = NOVALUE;

    /** inline.e:178		return 1*/
    DeRef(_eentry_53599);
    return 1;
    ;
}


object _66check_for_param(object _pc_53613)
{
    object _px_53614 = NOVALUE;
    object _27161 = NOVALUE;
    object _27159 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_53613)) {
        _1 = (object)(DBL_PTR(_pc_53613)->dbl);
        DeRefDS(_pc_53613);
        _pc_53613 = _1;
    }

    /** inline.e:182		integer px = find( inline_code[pc], inline_params )*/
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    _27159 = (object)*(((s1_ptr)_2)->base + _pc_53613);
    _px_53614 = find_from(_27159, _66inline_params_53482, 1);
    _27159 = NOVALUE;

    /** inline.e:183		if px then*/
    if (_px_53614 == 0)
    {
        goto L1; // [20] 51
    }
    else{
    }

    /** inline.e:184			if not find( px, assigned_params ) then*/
    _27161 = find_from(_px_53614, _66assigned_params_53483, 1);
    if (_27161 != 0)
    goto L2; // [32] 44
    _27161 = NOVALUE;

    /** inline.e:185				assigned_params &= px*/
    Append(&_66assigned_params_53483, _66assigned_params_53483, _px_53614);
L2: 

    /** inline.e:187			return 1*/
    return 1;
L1: 

    /** inline.e:189		return 0*/
    return 0;
    ;
}


void _66check_target(object _pc_53624, object _op_53625)
{
    object _targets_53626 = NOVALUE;
    object _27170 = NOVALUE;
    object _27169 = NOVALUE;
    object _27168 = NOVALUE;
    object _27167 = NOVALUE;
    object _27166 = NOVALUE;
    object _27164 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:194		sequence targets = op_info[op][OP_TARGET]*/
    _2 = (object)SEQ_PTR(_65op_info_24268);
    _27164 = (object)*(((s1_ptr)_2)->base + _op_53625);
    DeRef(_targets_53626);
    _2 = (object)SEQ_PTR(_27164);
    _targets_53626 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_targets_53626);
    _27164 = NOVALUE;

    /** inline.e:196		if length( targets ) then*/
    if (IS_SEQUENCE(_targets_53626)){
            _27166 = SEQ_PTR(_targets_53626)->length;
    }
    else {
        _27166 = 1;
    }
    if (_27166 == 0)
    {
        _27166 = NOVALUE;
        goto L1; // [26] 72
    }
    else{
        _27166 = NOVALUE;
    }

    /** inline.e:197		for i = 1 to length( targets ) do*/
    if (IS_SEQUENCE(_targets_53626)){
            _27167 = SEQ_PTR(_targets_53626)->length;
    }
    else {
        _27167 = 1;
    }
    {
        object _i_53634;
        _i_53634 = 1;
L2: 
        if (_i_53634 > _27167){
            goto L3; // [34] 71
        }

        /** inline.e:198				if check_for_param( pc + targets[i] ) then*/
        _2 = (object)SEQ_PTR(_targets_53626);
        _27168 = (object)*(((s1_ptr)_2)->base + _i_53634);
        if (IS_ATOM_INT(_27168)) {
            _27169 = _pc_53624 + _27168;
            if ((object)((uintptr_t)_27169 + (uintptr_t)HIGH_BITS) >= 0){
                _27169 = NewDouble((eudouble)_27169);
            }
        }
        else {
            _27169 = binary_op(PLUS, _pc_53624, _27168);
        }
        _27168 = NOVALUE;
        _27170 = _66check_for_param(_27169);
        _27169 = NOVALUE;
        if (_27170 == 0) {
            DeRef(_27170);
            _27170 = NOVALUE;
            goto L4; // [55] 64
        }
        else {
            if (!IS_ATOM_INT(_27170) && DBL_PTR(_27170)->dbl == 0.0){
                DeRef(_27170);
                _27170 = NOVALUE;
                goto L4; // [55] 64
            }
            DeRef(_27170);
            _27170 = NOVALUE;
        }
        DeRef(_27170);
        _27170 = NOVALUE;

        /** inline.e:199					return*/
        DeRefDS(_targets_53626);
        return;
L4: 

        /** inline.e:201			end for*/
        _i_53634 = _i_53634 + 1;
        goto L2; // [66] 41
L3: 
        ;
    }
L1: 

    /** inline.e:203	end procedure*/
    DeRef(_targets_53626);
    return;
    ;
}


object _66adjust_il(object _pc_53642, object _op_53643)
{
    object _addr_53651 = NOVALUE;
    object _sub_53657 = NOVALUE;
    object _27195 = NOVALUE;
    object _27194 = NOVALUE;
    object _27193 = NOVALUE;
    object _27192 = NOVALUE;
    object _27191 = NOVALUE;
    object _27190 = NOVALUE;
    object _27189 = NOVALUE;
    object _27187 = NOVALUE;
    object _27186 = NOVALUE;
    object _27185 = NOVALUE;
    object _27184 = NOVALUE;
    object _27183 = NOVALUE;
    object _27182 = NOVALUE;
    object _27181 = NOVALUE;
    object _27180 = NOVALUE;
    object _27178 = NOVALUE;
    object _27177 = NOVALUE;
    object _27175 = NOVALUE;
    object _27174 = NOVALUE;
    object _27173 = NOVALUE;
    object _27172 = NOVALUE;
    object _27171 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:208		for i = 1 to op_info[op][OP_SIZE] - 1 do*/
    _2 = (object)SEQ_PTR(_65op_info_24268);
    _27171 = (object)*(((s1_ptr)_2)->base + _op_53643);
    _2 = (object)SEQ_PTR(_27171);
    _27172 = (object)*(((s1_ptr)_2)->base + 2);
    _27171 = NOVALUE;
    if (IS_ATOM_INT(_27172)) {
        _27173 = _27172 - 1;
        if ((object)((uintptr_t)_27173 +(uintptr_t) HIGH_BITS) >= 0){
            _27173 = NewDouble((eudouble)_27173);
        }
    }
    else {
        _27173 = binary_op(MINUS, _27172, 1);
    }
    _27172 = NOVALUE;
    {
        object _i_53645;
        _i_53645 = 1;
L1: 
        if (binary_op_a(GREATER, _i_53645, _27173)){
            goto L2; // [23] 214
        }

        /** inline.e:210			integer addr = find( i, op_info[op][OP_ADDR] )*/
        _2 = (object)SEQ_PTR(_65op_info_24268);
        _27174 = (object)*(((s1_ptr)_2)->base + _op_53643);
        _2 = (object)SEQ_PTR(_27174);
        _27175 = (object)*(((s1_ptr)_2)->base + 3);
        _27174 = NOVALUE;
        _addr_53651 = find_from(_i_53645, _27175, 1);
        _27175 = NOVALUE;

        /** inline.e:211			integer sub  = find( i, op_info[op][OP_SUB] )*/
        _2 = (object)SEQ_PTR(_65op_info_24268);
        _27177 = (object)*(((s1_ptr)_2)->base + _op_53643);
        _2 = (object)SEQ_PTR(_27177);
        _27178 = (object)*(((s1_ptr)_2)->base + 5);
        _27177 = NOVALUE;
        _sub_53657 = find_from(_i_53645, _27178, 1);
        _27178 = NOVALUE;

        /** inline.e:212			if addr then*/
        if (_addr_53651 == 0)
        {
            goto L3; // [70] 121
        }
        else{
        }

        /** inline.e:213				if integer( inline_code[pc+i] ) then*/
        if (IS_ATOM_INT(_i_53645)) {
            _27180 = _pc_53642 + _i_53645;
        }
        else {
            _27180 = NewDouble((eudouble)_pc_53642 + DBL_PTR(_i_53645)->dbl);
        }
        _2 = (object)SEQ_PTR(_66inline_code_53477);
        if (!IS_ATOM_INT(_27180)){
            _27181 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27180)->dbl));
        }
        else{
            _27181 = (object)*(((s1_ptr)_2)->base + _27180);
        }
        if (IS_ATOM_INT(_27181))
        _27182 = 1;
        else if (IS_ATOM_DBL(_27181))
        _27182 = IS_ATOM_INT(DoubleToInt(_27181));
        else
        _27182 = 0;
        _27181 = NOVALUE;
        if (_27182 == 0)
        {
            _27182 = NOVALUE;
            goto L4; // [88] 205
        }
        else{
            _27182 = NOVALUE;
        }

        /** inline.e:214					inline_code[pc + i] = { INLINE_ADDR, inline_code[pc + i] }*/
        if (IS_ATOM_INT(_i_53645)) {
            _27183 = _pc_53642 + _i_53645;
            if ((object)((uintptr_t)_27183 + (uintptr_t)HIGH_BITS) >= 0){
                _27183 = NewDouble((eudouble)_27183);
            }
        }
        else {
            _27183 = NewDouble((eudouble)_pc_53642 + DBL_PTR(_i_53645)->dbl);
        }
        if (IS_ATOM_INT(_i_53645)) {
            _27184 = _pc_53642 + _i_53645;
        }
        else {
            _27184 = NewDouble((eudouble)_pc_53642 + DBL_PTR(_i_53645)->dbl);
        }
        _2 = (object)SEQ_PTR(_66inline_code_53477);
        if (!IS_ATOM_INT(_27184)){
            _27185 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27184)->dbl));
        }
        else{
            _27185 = (object)*(((s1_ptr)_2)->base + _27184);
        }
        Ref(_27185);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 4;
        ((intptr_t *)_2)[2] = _27185;
        _27186 = MAKE_SEQ(_1);
        _27185 = NOVALUE;
        _2 = (object)SEQ_PTR(_66inline_code_53477);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _66inline_code_53477 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27183))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27183)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27183);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27186;
        if( _1 != _27186 ){
            DeRef(_1);
        }
        _27186 = NOVALUE;
        goto L4; // [118] 205
L3: 

        /** inline.e:217			elsif sub then*/
        if (_sub_53657 == 0)
        {
            goto L5; // [123] 141
        }
        else{
        }

        /** inline.e:218				inline_code[pc+i] = {INLINE_SUB}*/
        if (IS_ATOM_INT(_i_53645)) {
            _27187 = _pc_53642 + _i_53645;
        }
        else {
            _27187 = NewDouble((eudouble)_pc_53642 + DBL_PTR(_i_53645)->dbl);
        }
        RefDS(_27188);
        _2 = (object)SEQ_PTR(_66inline_code_53477);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _66inline_code_53477 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27187))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27187)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27187);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27188;
        DeRef(_1);
        goto L4; // [138] 205
L5: 

        /** inline.e:220				if op != STARTLINE and op != COVERAGE_LINE and op != COVERAGE_ROUTINE then*/
        _27189 = (_op_53643 != 58);
        if (_27189 == 0) {
            _27190 = 0;
            goto L6; // [149] 163
        }
        _27191 = (_op_53643 != 210);
        _27190 = (_27191 != 0);
L6: 
        if (_27190 == 0) {
            goto L7; // [163] 204
        }
        _27193 = (_op_53643 != 211);
        if (_27193 == 0)
        {
            DeRef(_27193);
            _27193 = NOVALUE;
            goto L7; // [174] 204
        }
        else{
            DeRef(_27193);
            _27193 = NOVALUE;
        }

        /** inline.e:221					check_target( pc, op )*/
        _66check_target(_pc_53642, _op_53643);

        /** inline.e:222					if not adjust_symbol( pc + i ) then*/
        if (IS_ATOM_INT(_i_53645)) {
            _27194 = _pc_53642 + _i_53645;
            if ((object)((uintptr_t)_27194 + (uintptr_t)HIGH_BITS) >= 0){
                _27194 = NewDouble((eudouble)_27194);
            }
        }
        else {
            _27194 = NewDouble((eudouble)_pc_53642 + DBL_PTR(_i_53645)->dbl);
        }
        _27195 = _66adjust_symbol(_27194);
        _27194 = NOVALUE;
        if (IS_ATOM_INT(_27195)) {
            if (_27195 != 0){
                DeRef(_27195);
                _27195 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        else {
            if (DBL_PTR(_27195)->dbl != 0.0){
                DeRef(_27195);
                _27195 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        DeRef(_27195);
        _27195 = NOVALUE;

        /** inline.e:223						return 0*/
        DeRef(_i_53645);
        DeRef(_27183);
        _27183 = NOVALUE;
        DeRef(_27180);
        _27180 = NOVALUE;
        DeRef(_27191);
        _27191 = NOVALUE;
        DeRef(_27184);
        _27184 = NOVALUE;
        DeRef(_27173);
        _27173 = NOVALUE;
        DeRef(_27187);
        _27187 = NOVALUE;
        DeRef(_27189);
        _27189 = NOVALUE;
        return 0;
L8: 
L7: 
L4: 

        /** inline.e:227		end for*/
        _0 = _i_53645;
        if (IS_ATOM_INT(_i_53645)) {
            _i_53645 = _i_53645 + 1;
            if ((object)((uintptr_t)_i_53645 +(uintptr_t) HIGH_BITS) >= 0){
                _i_53645 = NewDouble((eudouble)_i_53645);
            }
        }
        else {
            _i_53645 = binary_op_a(PLUS, _i_53645, 1);
        }
        DeRef(_0);
        goto L1; // [209] 30
L2: 
        ;
        DeRef(_i_53645);
    }

    /** inline.e:228		return 1*/
    DeRef(_27183);
    _27183 = NOVALUE;
    DeRef(_27180);
    _27180 = NOVALUE;
    DeRef(_27191);
    _27191 = NOVALUE;
    DeRef(_27184);
    _27184 = NOVALUE;
    DeRef(_27173);
    _27173 = NOVALUE;
    DeRef(_27187);
    _27187 = NOVALUE;
    DeRef(_27189);
    _27189 = NOVALUE;
    return 1;
    ;
}


object _66is_temp(object _sym_53692)
{
    object _27206 = NOVALUE;
    object _27205 = NOVALUE;
    object _27204 = NOVALUE;
    object _27203 = NOVALUE;
    object _27202 = NOVALUE;
    object _27201 = NOVALUE;
    object _27200 = NOVALUE;
    object _27199 = NOVALUE;
    object _27198 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:232		if sym <= 0 then*/
    if (_sym_53692 > 0)
    goto L1; // [5] 16

    /** inline.e:233			return 0*/
    return 0;
L1: 

    /** inline.e:236		return (SymTab[sym][S_MODE] = M_TEMP) and (not TRANSLATE or equal( NOVALUE, SymTab[sym][S_OBJ]) )*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27198 = (object)*(((s1_ptr)_2)->base + _sym_53692);
    _2 = (object)SEQ_PTR(_27198);
    _27199 = (object)*(((s1_ptr)_2)->base + 3);
    _27198 = NOVALUE;
    if (IS_ATOM_INT(_27199)) {
        _27200 = (_27199 == 3);
    }
    else {
        _27200 = binary_op(EQUALS, _27199, 3);
    }
    _27199 = NOVALUE;
    _27201 = (_12TRANSLATE_19834 == 0);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27202 = (object)*(((s1_ptr)_2)->base + _sym_53692);
    _2 = (object)SEQ_PTR(_27202);
    _27203 = (object)*(((s1_ptr)_2)->base + 1);
    _27202 = NOVALUE;
    if (_12NOVALUE_20081 == _27203)
    _27204 = 1;
    else if (IS_ATOM_INT(_12NOVALUE_20081) && IS_ATOM_INT(_27203))
    _27204 = 0;
    else
    _27204 = (compare(_12NOVALUE_20081, _27203) == 0);
    _27203 = NOVALUE;
    _27205 = (_27201 != 0 || _27204 != 0);
    _27201 = NOVALUE;
    _27204 = NOVALUE;
    if (IS_ATOM_INT(_27200)) {
        _27206 = (_27200 != 0 && _27205 != 0);
    }
    else {
        _27206 = binary_op(AND, _27200, _27205);
    }
    DeRef(_27200);
    _27200 = NOVALUE;
    _27205 = NOVALUE;
    return _27206;
    ;
}


object _66is_literal(object _sym_53714)
{
    object _mode_53717 = NOVALUE;
    object _27221 = NOVALUE;
    object _27220 = NOVALUE;
    object _27219 = NOVALUE;
    object _27218 = NOVALUE;
    object _27217 = NOVALUE;
    object _27216 = NOVALUE;
    object _27214 = NOVALUE;
    object _27213 = NOVALUE;
    object _27212 = NOVALUE;
    object _27211 = NOVALUE;
    object _27210 = NOVALUE;
    object _27208 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:240		if sym <= 0 then*/
    if (_sym_53714 > 0)
    goto L1; // [5] 16

    /** inline.e:241			return 0*/
    return 0;
L1: 

    /** inline.e:244		integer mode = SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27208 = (object)*(((s1_ptr)_2)->base + _sym_53714);
    _2 = (object)SEQ_PTR(_27208);
    _mode_53717 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_53717)){
        _mode_53717 = (object)DBL_PTR(_mode_53717)->dbl;
    }
    _27208 = NOVALUE;

    /** inline.e:245		if (mode = M_CONSTANT and eu:compare( NOVALUE, SymTab[sym][S_OBJ]) ) */
    _27210 = (_mode_53717 == 2);
    if (_27210 == 0) {
        _27211 = 0;
        goto L2; // [40] 66
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27212 = (object)*(((s1_ptr)_2)->base + _sym_53714);
    _2 = (object)SEQ_PTR(_27212);
    _27213 = (object)*(((s1_ptr)_2)->base + 1);
    _27212 = NOVALUE;
    if (IS_ATOM_INT(_12NOVALUE_20081) && IS_ATOM_INT(_27213)){
        _27214 = (_12NOVALUE_20081 < _27213) ? -1 : (_12NOVALUE_20081 > _27213);
    }
    else{
        _27214 = compare(_12NOVALUE_20081, _27213);
    }
    _27213 = NOVALUE;
    _27211 = (_27214 != 0);
L2: 
    if (_27211 != 0) {
        goto L3; // [66] 117
    }
    if (_12TRANSLATE_19834 == 0) {
        _27216 = 0;
        goto L4; // [72] 86
    }
    _27217 = (_mode_53717 == 3);
    _27216 = (_27217 != 0);
L4: 
    if (_27216 == 0) {
        DeRef(_27218);
        _27218 = 0;
        goto L5; // [86] 112
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27219 = (object)*(((s1_ptr)_2)->base + _sym_53714);
    _2 = (object)SEQ_PTR(_27219);
    _27220 = (object)*(((s1_ptr)_2)->base + 1);
    _27219 = NOVALUE;
    if (IS_ATOM_INT(_27220) && IS_ATOM_INT(_12NOVALUE_20081)){
        _27221 = (_27220 < _12NOVALUE_20081) ? -1 : (_27220 > _12NOVALUE_20081);
    }
    else{
        _27221 = compare(_27220, _12NOVALUE_20081);
    }
    _27220 = NOVALUE;
    _27218 = (_27221 != 0);
L5: 
    if (_27218 == 0)
    {
        _27218 = NOVALUE;
        goto L6; // [113] 126
    }
    else{
        _27218 = NOVALUE;
    }
L3: 

    /** inline.e:247			return 1*/
    DeRef(_27210);
    _27210 = NOVALUE;
    DeRef(_27217);
    _27217 = NOVALUE;
    return 1;
    goto L7; // [123] 133
L6: 

    /** inline.e:249			return 0*/
    DeRef(_27210);
    _27210 = NOVALUE;
    DeRef(_27217);
    _27217 = NOVALUE;
    return 0;
L7: 
    ;
}


object _66returnf(object _pc_53764)
{
    object _retsym_53766 = NOVALUE;
    object _code_53799 = NOVALUE;
    object _ret_pc_53800 = NOVALUE;
    object _code_53845 = NOVALUE;
    object _ret_pc_53859 = NOVALUE;
    object _27294 = NOVALUE;
    object _27293 = NOVALUE;
    object _27291 = NOVALUE;
    object _27289 = NOVALUE;
    object _27288 = NOVALUE;
    object _27286 = NOVALUE;
    object _27285 = NOVALUE;
    object _27283 = NOVALUE;
    object _27282 = NOVALUE;
    object _27281 = NOVALUE;
    object _27279 = NOVALUE;
    object _27278 = NOVALUE;
    object _27276 = NOVALUE;
    object _27274 = NOVALUE;
    object _27273 = NOVALUE;
    object _27271 = NOVALUE;
    object _27270 = NOVALUE;
    object _27268 = NOVALUE;
    object _27267 = NOVALUE;
    object _27266 = NOVALUE;
    object _27264 = NOVALUE;
    object _27263 = NOVALUE;
    object _27262 = NOVALUE;
    object _27261 = NOVALUE;
    object _27260 = NOVALUE;
    object _27258 = NOVALUE;
    object _27257 = NOVALUE;
    object _27256 = NOVALUE;
    object _27255 = NOVALUE;
    object _27253 = NOVALUE;
    object _27251 = NOVALUE;
    object _27250 = NOVALUE;
    object _27249 = NOVALUE;
    object _27248 = NOVALUE;
    object _27247 = NOVALUE;
    object _27246 = NOVALUE;
    object _27245 = NOVALUE;
    object _27244 = NOVALUE;
    object _27243 = NOVALUE;
    object _27241 = NOVALUE;
    object _27240 = NOVALUE;
    object _27239 = NOVALUE;
    object _27237 = NOVALUE;
    object _27236 = NOVALUE;
    object _27235 = NOVALUE;
    object _27234 = NOVALUE;
    object _27233 = NOVALUE;
    object _27232 = NOVALUE;
    object _27230 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:259		symtab_index retsym = inline_code[pc+3]*/
    _27230 = _pc_53764 + 3;
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    _retsym_53766 = (object)*(((s1_ptr)_2)->base + _27230);
    if (!IS_ATOM_INT(_retsym_53766)){
        _retsym_53766 = (object)DBL_PTR(_retsym_53766)->dbl;
    }

    /** inline.e:260		if equal( inline_code[$], BADRETURNF ) then*/
    if (IS_SEQUENCE(_66inline_code_53477)){
            _27232 = SEQ_PTR(_66inline_code_53477)->length;
    }
    else {
        _27232 = 1;
    }
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    _27233 = (object)*(((s1_ptr)_2)->base + _27232);
    if (_27233 == 43)
    _27234 = 1;
    else if (IS_ATOM_INT(_27233) && IS_ATOM_INT(43))
    _27234 = 0;
    else
    _27234 = (compare(_27233, 43) == 0);
    _27233 = NOVALUE;
    if (_27234 == 0)
    {
        _27234 = NOVALUE;
        goto L1; // [34] 102
    }
    else{
        _27234 = NOVALUE;
    }

    /** inline.e:261			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L2; // [41] 60
    }
    else{
    }

    /** inline.e:262				inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_66inline_code_53477)){
            _27235 = SEQ_PTR(_66inline_code_53477)->length;
    }
    else {
        _27235 = 1;
    }
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53477 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27235);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 159;
    DeRef(_1);
    goto L3; // [57] 101
L2: 

    /** inline.e:263			elsif SymTab[inline_sub][S_TOKEN] = PROC then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27236 = (object)*(((s1_ptr)_2)->base + _66inline_sub_53491);
    _2 = (object)SEQ_PTR(_27236);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _27237 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _27237 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _27236 = NOVALUE;
    if (binary_op_a(NOTEQ, _27237, 27)){
        _27237 = NOVALUE;
        goto L4; // [78] 100
    }
    _27237 = NOVALUE;

    /** inline.e:264				replace_code( {}, length(inline_code), length(inline_code) )*/
    if (IS_SEQUENCE(_66inline_code_53477)){
            _27239 = SEQ_PTR(_66inline_code_53477)->length;
    }
    else {
        _27239 = 1;
    }
    if (IS_SEQUENCE(_66inline_code_53477)){
            _27240 = SEQ_PTR(_66inline_code_53477)->length;
    }
    else {
        _27240 = 1;
    }
    RefDS(_22015);
    _66replace_code(_22015, _27239, _27240);
    _27239 = NOVALUE;
    _27240 = NOVALUE;
L4: 
L3: 
L1: 

    /** inline.e:270		if is_temp( retsym ) */
    _27241 = _66is_temp(_retsym_53766);
    if (IS_ATOM_INT(_27241)) {
        if (_27241 != 0) {
            goto L5; // [108] 150
        }
    }
    else {
        if (DBL_PTR(_27241)->dbl != 0.0) {
            goto L5; // [108] 150
        }
    }
    _27243 = _66is_literal(_retsym_53766);
    if (IS_ATOM_INT(_27243)) {
        _27244 = (_27243 == 0);
    }
    else {
        _27244 = unary_op(NOT, _27243);
    }
    DeRef(_27243);
    _27243 = NOVALUE;
    if (IS_ATOM_INT(_27244)) {
        if (_27244 == 0) {
            DeRef(_27245);
            _27245 = 0;
            goto L6; // [119] 145
        }
    }
    else {
        if (DBL_PTR(_27244)->dbl == 0.0) {
            DeRef(_27245);
            _27245 = 0;
            goto L6; // [119] 145
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27246 = (object)*(((s1_ptr)_2)->base + _retsym_53766);
    _2 = (object)SEQ_PTR(_27246);
    _27247 = (object)*(((s1_ptr)_2)->base + 4);
    _27246 = NOVALUE;
    if (IS_ATOM_INT(_27247)) {
        _27248 = (_27247 <= 3);
    }
    else {
        _27248 = binary_op(LESSEQ, _27247, 3);
    }
    _27247 = NOVALUE;
    DeRef(_27245);
    if (IS_ATOM_INT(_27248))
    _27245 = (_27248 != 0);
    else
    _27245 = DBL_PTR(_27248)->dbl != 0.0;
L6: 
    if (_27245 == 0)
    {
        _27245 = NOVALUE;
        goto L7; // [146] 393
    }
    else{
        _27245 = NOVALUE;
    }
L5: 

    /** inline.e:272			sequence code = {}*/
    RefDS(_22015);
    DeRef(_code_53799);
    _code_53799 = _22015;

    /** inline.e:274			integer ret_pc = 0*/
    _ret_pc_53800 = 0;

    /** inline.e:276			if not (find( retsym, inline_params ) or find( retsym, proc_vars )) then*/
    _27249 = find_from(_retsym_53766, _66inline_params_53482, 1);
    if (_27249 != 0) {
        DeRef(_27250);
        _27250 = 1;
        goto L8; // [171] 186
    }
    _27251 = find_from(_retsym_53766, _66proc_vars_53478, 1);
    _27250 = (_27251 != 0);
L8: 
    if (_27250 != 0)
    goto L9; // [186] 206
    _27250 = NOVALUE;

    /** inline.e:277				ret_pc = rfind( generic_symbol( retsym ), inline_code, pc )*/
    _27253 = _66generic_symbol(_retsym_53766);
    RefDS(_66inline_code_53477);
    _ret_pc_53800 = _20rfind(_27253, _66inline_code_53477, _pc_53764);
    _27253 = NOVALUE;
    if (!IS_ATOM_INT(_ret_pc_53800)) {
        _1 = (object)(DBL_PTR(_ret_pc_53800)->dbl);
        DeRefDS(_ret_pc_53800);
        _ret_pc_53800 = _1;
    }
L9: 

    /** inline.e:281			if ret_pc and eu:compare( inline_code[ret_pc-1], PRIVATE_INIT_CHECK ) then*/
    if (_ret_pc_53800 == 0) {
        goto LA; // [208] 277
    }
    _27256 = _ret_pc_53800 - 1;
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    _27257 = (object)*(((s1_ptr)_2)->base + _27256);
    if (IS_ATOM_INT(_27257) && IS_ATOM_INT(30)){
        _27258 = (_27257 < 30) ? -1 : (_27257 > 30);
    }
    else{
        _27258 = compare(_27257, 30);
    }
    _27257 = NOVALUE;
    if (_27258 == 0)
    {
        _27258 = NOVALUE;
        goto LA; // [229] 277
    }
    else{
        _27258 = NOVALUE;
    }

    /** inline.e:282				inline_code[ret_pc] = {INLINE_TARGET}*/
    RefDS(_27259);
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53477 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ret_pc_53800);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27259;
    DeRef(_1);

    /** inline.e:284				if equal( inline_code[ret_pc-1], REF_TEMP ) then*/
    _27260 = _ret_pc_53800 - 1;
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    _27261 = (object)*(((s1_ptr)_2)->base + _27260);
    if (_27261 == 207)
    _27262 = 1;
    else if (IS_ATOM_INT(_27261) && IS_ATOM_INT(207))
    _27262 = 0;
    else
    _27262 = (compare(_27261, 207) == 0);
    _27261 = NOVALUE;
    if (_27262 == 0)
    {
        _27262 = NOVALUE;
        goto LB; // [258] 292
    }
    else{
        _27262 = NOVALUE;
    }

    /** inline.e:287					inline_code[ret_pc-2] = {INLINE_TARGET}*/
    _27263 = _ret_pc_53800 - 2;
    RefDS(_27259);
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53477 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27263);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27259;
    DeRef(_1);
    goto LB; // [274] 292
LA: 

    /** inline.e:290				code = {ASSIGN, generic_symbol( retsym ), {INLINE_TARGET}}*/
    _27264 = _66generic_symbol(_retsym_53766);
    _0 = _code_53799;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18;
    ((intptr_t*)_2)[2] = _27264;
    RefDS(_27259);
    ((intptr_t*)_2)[3] = _27259;
    _code_53799 = MAKE_SEQ(_1);
    DeRef(_0);
    _27264 = NOVALUE;
LB: 

    /** inline.e:293			if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_66inline_code_53477)){
            _27266 = SEQ_PTR(_66inline_code_53477)->length;
    }
    else {
        _27266 = 1;
    }
    _27267 = 3 + _12TRANSLATE_19834;
    _27268 = _27266 - _27267;
    _27266 = NOVALUE;
    _27267 = NOVALUE;
    if (_pc_53764 == _27268)
    goto LC; // [309] 330

    /** inline.e:294				code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = -1;
    _27270 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 23;
    ((intptr_t *)_2)[2] = _27270;
    _27271 = MAKE_SEQ(_1);
    _27270 = NOVALUE;
    Concat((object_ptr)&_code_53799, _code_53799, _27271);
    DeRefDS(_27271);
    _27271 = NOVALUE;
LC: 

    /** inline.e:298			replace_code( code, pc, pc + 3 )*/
    _27273 = _pc_53764 + 3;
    if ((object)((uintptr_t)_27273 + (uintptr_t)HIGH_BITS) >= 0){
        _27273 = NewDouble((eudouble)_27273);
    }
    RefDS(_code_53799);
    _66replace_code(_code_53799, _pc_53764, _27273);
    _27273 = NOVALUE;

    /** inline.e:299			ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = -1;
    _27274 = MAKE_SEQ(_1);
    _ret_pc_53800 = find_from(_27274, _66inline_code_53477, _pc_53764);
    DeRefDS(_27274);
    _27274 = NOVALUE;

    /** inline.e:300			if ret_pc then*/
    if (_ret_pc_53800 == 0)
    {
        goto LD; // [356] 382
    }
    else{
    }

    /** inline.e:301				inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53477 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ret_pc_53800 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_66inline_code_53477)){
            _27278 = SEQ_PTR(_66inline_code_53477)->length;
    }
    else {
        _27278 = 1;
    }
    _27279 = _27278 + 1;
    _27278 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27279;
    if( _1 != _27279 ){
        DeRef(_1);
    }
    _27279 = NOVALUE;
    _27276 = NOVALUE;
LD: 

    /** inline.e:303			return 1*/
    DeRef(_code_53799);
    DeRef(_27241);
    _27241 = NOVALUE;
    DeRef(_27263);
    _27263 = NOVALUE;
    DeRef(_27256);
    _27256 = NOVALUE;
    DeRef(_27230);
    _27230 = NOVALUE;
    DeRef(_27260);
    _27260 = NOVALUE;
    DeRef(_27268);
    _27268 = NOVALUE;
    DeRef(_27244);
    _27244 = NOVALUE;
    DeRef(_27248);
    _27248 = NOVALUE;
    return 1;
    goto LE; // [390] 502
L7: 

    /** inline.e:306			sequence code = {ASSIGN, retsym, {INLINE_TARGET}}*/
    _0 = _code_53845;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18;
    ((intptr_t*)_2)[2] = _retsym_53766;
    RefDS(_27259);
    ((intptr_t*)_2)[3] = _27259;
    _code_53845 = MAKE_SEQ(_1);
    DeRef(_0);

    /** inline.e:307			if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_66inline_code_53477)){
            _27281 = SEQ_PTR(_66inline_code_53477)->length;
    }
    else {
        _27281 = 1;
    }
    _27282 = 3 + _12TRANSLATE_19834;
    _27283 = _27281 - _27282;
    _27281 = NOVALUE;
    _27282 = NOVALUE;
    if (_pc_53764 == _27283)
    goto LF; // [420] 441

    /** inline.e:308				code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = -1;
    _27285 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 23;
    ((intptr_t *)_2)[2] = _27285;
    _27286 = MAKE_SEQ(_1);
    _27285 = NOVALUE;
    Concat((object_ptr)&_code_53845, _code_53845, _27286);
    DeRefDS(_27286);
    _27286 = NOVALUE;
LF: 

    /** inline.e:312			replace_code( code, pc, pc + 3 )*/
    _27288 = _pc_53764 + 3;
    if ((object)((uintptr_t)_27288 + (uintptr_t)HIGH_BITS) >= 0){
        _27288 = NewDouble((eudouble)_27288);
    }
    RefDS(_code_53845);
    _66replace_code(_code_53845, _pc_53764, _27288);
    _27288 = NOVALUE;

    /** inline.e:313			integer ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = -1;
    _27289 = MAKE_SEQ(_1);
    _ret_pc_53859 = find_from(_27289, _66inline_code_53477, _pc_53764);
    DeRefDS(_27289);
    _27289 = NOVALUE;

    /** inline.e:314			if ret_pc then*/
    if (_ret_pc_53859 == 0)
    {
        goto L10; // [467] 493
    }
    else{
    }

    /** inline.e:315				inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53477 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ret_pc_53859 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_66inline_code_53477)){
            _27293 = SEQ_PTR(_66inline_code_53477)->length;
    }
    else {
        _27293 = 1;
    }
    _27294 = _27293 + 1;
    _27293 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27294;
    if( _1 != _27294 ){
        DeRef(_1);
    }
    _27294 = NOVALUE;
    _27291 = NOVALUE;
L10: 

    /** inline.e:317			return 1*/
    DeRef(_code_53845);
    DeRef(_27241);
    _27241 = NOVALUE;
    DeRef(_27263);
    _27263 = NOVALUE;
    DeRef(_27283);
    _27283 = NOVALUE;
    DeRef(_27256);
    _27256 = NOVALUE;
    DeRef(_27230);
    _27230 = NOVALUE;
    DeRef(_27260);
    _27260 = NOVALUE;
    DeRef(_27268);
    _27268 = NOVALUE;
    DeRef(_27244);
    _27244 = NOVALUE;
    DeRef(_27248);
    _27248 = NOVALUE;
    return 1;
LE: 

    /** inline.e:319		return 0*/
    DeRef(_27241);
    _27241 = NOVALUE;
    DeRef(_27263);
    _27263 = NOVALUE;
    DeRef(_27283);
    _27283 = NOVALUE;
    DeRef(_27256);
    _27256 = NOVALUE;
    DeRef(_27230);
    _27230 = NOVALUE;
    DeRef(_27260);
    _27260 = NOVALUE;
    DeRef(_27268);
    _27268 = NOVALUE;
    DeRef(_27244);
    _27244 = NOVALUE;
    DeRef(_27248);
    _27248 = NOVALUE;
    return 0;
    ;
}


object _66inline_op(object _pc_53869)
{
    object _op_53870 = NOVALUE;
    object _code_53875 = NOVALUE;
    object _stlen_53908 = NOVALUE;
    object _file_53913 = NOVALUE;
    object _ok_53918 = NOVALUE;
    object _original_table_53941 = NOVALUE;
    object _jump_table_53945 = NOVALUE;
    object _27355 = NOVALUE;
    object _27354 = NOVALUE;
    object _27353 = NOVALUE;
    object _27352 = NOVALUE;
    object _27351 = NOVALUE;
    object _27350 = NOVALUE;
    object _27349 = NOVALUE;
    object _27348 = NOVALUE;
    object _27347 = NOVALUE;
    object _27346 = NOVALUE;
    object _27345 = NOVALUE;
    object _27344 = NOVALUE;
    object _27341 = NOVALUE;
    object _27340 = NOVALUE;
    object _27339 = NOVALUE;
    object _27338 = NOVALUE;
    object _27336 = NOVALUE;
    object _27334 = NOVALUE;
    object _27333 = NOVALUE;
    object _27331 = NOVALUE;
    object _27327 = NOVALUE;
    object _27326 = NOVALUE;
    object _27325 = NOVALUE;
    object _27324 = NOVALUE;
    object _27323 = NOVALUE;
    object _27322 = NOVALUE;
    object _27319 = NOVALUE;
    object _27318 = NOVALUE;
    object _27316 = NOVALUE;
    object _27315 = NOVALUE;
    object _27313 = NOVALUE;
    object _27311 = NOVALUE;
    object _27310 = NOVALUE;
    object _27309 = NOVALUE;
    object _27308 = NOVALUE;
    object _27307 = NOVALUE;
    object _27306 = NOVALUE;
    object _27305 = NOVALUE;
    object _27303 = NOVALUE;
    object _27302 = NOVALUE;
    object _27301 = NOVALUE;
    object _27299 = NOVALUE;
    object _27298 = NOVALUE;
    object _27297 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:324		integer op = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    _op_53870 = (object)*(((s1_ptr)_2)->base + _pc_53869);
    if (!IS_ATOM_INT(_op_53870))
    _op_53870 = (object)DBL_PTR(_op_53870)->dbl;

    /** inline.e:326		if op = RETURNP then*/
    if (_op_53870 != 29)
    goto L1; // [15] 150

    /** inline.e:333			sequence code = ""*/
    RefDS(_22015);
    DeRef(_code_53875);
    _code_53875 = _22015;

    /** inline.e:335			if pc != length( inline_code ) - 1 - TRANSLATE then*/
    if (IS_SEQUENCE(_66inline_code_53477)){
            _27297 = SEQ_PTR(_66inline_code_53477)->length;
    }
    else {
        _27297 = 1;
    }
    _27298 = _27297 - 1;
    _27297 = NOVALUE;
    _27299 = _27298 - _12TRANSLATE_19834;
    _27298 = NOVALUE;
    if (_pc_53869 == _27299)
    goto L2; // [43] 92

    /** inline.e:336				code = { ELSE, {INLINE_ADDR, length( inline_code ) + 1 }}*/
    if (IS_SEQUENCE(_66inline_code_53477)){
            _27301 = SEQ_PTR(_66inline_code_53477)->length;
    }
    else {
        _27301 = 1;
    }
    _27302 = _27301 + 1;
    _27301 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = _27302;
    _27303 = MAKE_SEQ(_1);
    _27302 = NOVALUE;
    DeRefDS(_code_53875);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 23;
    ((intptr_t *)_2)[2] = _27303;
    _code_53875 = MAKE_SEQ(_1);
    _27303 = NOVALUE;

    /** inline.e:337				if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L3; // [72] 134
    }
    else{
    }

    /** inline.e:338					inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_66inline_code_53477)){
            _27305 = SEQ_PTR(_66inline_code_53477)->length;
    }
    else {
        _27305 = 1;
    }
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53477 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27305);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 159;
    DeRef(_1);
    goto L3; // [89] 134
L2: 

    /** inline.e:341			elsif TRANSLATE and inline_code[$] = BADRETURNF then*/
    if (_12TRANSLATE_19834 == 0) {
        goto L4; // [96] 133
    }
    if (IS_SEQUENCE(_66inline_code_53477)){
            _27307 = SEQ_PTR(_66inline_code_53477)->length;
    }
    else {
        _27307 = 1;
    }
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    _27308 = (object)*(((s1_ptr)_2)->base + _27307);
    if (IS_ATOM_INT(_27308)) {
        _27309 = (_27308 == 43);
    }
    else {
        _27309 = binary_op(EQUALS, _27308, 43);
    }
    _27308 = NOVALUE;
    if (_27309 == 0) {
        DeRef(_27309);
        _27309 = NOVALUE;
        goto L4; // [116] 133
    }
    else {
        if (!IS_ATOM_INT(_27309) && DBL_PTR(_27309)->dbl == 0.0){
            DeRef(_27309);
            _27309 = NOVALUE;
            goto L4; // [116] 133
        }
        DeRef(_27309);
        _27309 = NOVALUE;
    }
    DeRef(_27309);
    _27309 = NOVALUE;

    /** inline.e:342				inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_66inline_code_53477)){
            _27310 = SEQ_PTR(_66inline_code_53477)->length;
    }
    else {
        _27310 = 1;
    }
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53477 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27310);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 159;
    DeRef(_1);
L4: 
L3: 

    /** inline.e:344			replace_code( code, pc, pc + 2 )*/
    _27311 = _pc_53869 + 2;
    if ((object)((uintptr_t)_27311 + (uintptr_t)HIGH_BITS) >= 0){
        _27311 = NewDouble((eudouble)_27311);
    }
    RefDS(_code_53875);
    _66replace_code(_code_53875, _pc_53869, _27311);
    _27311 = NOVALUE;
    DeRefDS(_code_53875);
    _code_53875 = NOVALUE;
    goto L5; // [147] 526
L1: 

    /** inline.e:346		elsif op = RETURNF then*/
    if (_op_53870 != 28)
    goto L6; // [154] 171

    /** inline.e:347			return returnf( pc )*/
    _27313 = _66returnf(_pc_53869);
    DeRef(_27299);
    _27299 = NOVALUE;
    return _27313;
    goto L5; // [168] 526
L6: 

    /** inline.e:349		elsif op = ROUTINE_ID then*/
    if (_op_53870 != 134)
    goto L7; // [175] 273

    /** inline.e:351			integer*/

    /** inline.e:352				stlen = inline_code[pc+2+TRANSLATE],*/
    _27315 = _pc_53869 + 2;
    if ((object)((uintptr_t)_27315 + (uintptr_t)HIGH_BITS) >= 0){
        _27315 = NewDouble((eudouble)_27315);
    }
    if (IS_ATOM_INT(_27315)) {
        _27316 = _27315 + _12TRANSLATE_19834;
    }
    else {
        _27316 = NewDouble(DBL_PTR(_27315)->dbl + (eudouble)_12TRANSLATE_19834);
    }
    DeRef(_27315);
    _27315 = NOVALUE;
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    if (!IS_ATOM_INT(_27316)){
        _stlen_53908 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27316)->dbl));
    }
    else{
        _stlen_53908 = (object)*(((s1_ptr)_2)->base + _27316);
    }
    if (!IS_ATOM_INT(_stlen_53908))
    _stlen_53908 = (object)DBL_PTR(_stlen_53908)->dbl;

    /** inline.e:353				file  = inline_code[pc+4+TRANSLATE],*/
    _27318 = _pc_53869 + 4;
    if ((object)((uintptr_t)_27318 + (uintptr_t)HIGH_BITS) >= 0){
        _27318 = NewDouble((eudouble)_27318);
    }
    if (IS_ATOM_INT(_27318)) {
        _27319 = _27318 + _12TRANSLATE_19834;
    }
    else {
        _27319 = NewDouble(DBL_PTR(_27318)->dbl + (eudouble)_12TRANSLATE_19834);
    }
    DeRef(_27318);
    _27318 = NOVALUE;
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    if (!IS_ATOM_INT(_27319)){
        _file_53913 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27319)->dbl));
    }
    else{
        _file_53913 = (object)*(((s1_ptr)_2)->base + _27319);
    }
    if (!IS_ATOM_INT(_file_53913))
    _file_53913 = (object)DBL_PTR(_file_53913)->dbl;

    /** inline.e:354				ok    = adjust_il( pc, op )*/
    _ok_53918 = _66adjust_il(_pc_53869, _op_53870);
    if (!IS_ATOM_INT(_ok_53918)) {
        _1 = (object)(DBL_PTR(_ok_53918)->dbl);
        DeRefDS(_ok_53918);
        _ok_53918 = _1;
    }

    /** inline.e:355			inline_code[pc+2+TRANSLATE] = stlen*/
    _27322 = _pc_53869 + 2;
    if ((object)((uintptr_t)_27322 + (uintptr_t)HIGH_BITS) >= 0){
        _27322 = NewDouble((eudouble)_27322);
    }
    if (IS_ATOM_INT(_27322)) {
        _27323 = _27322 + _12TRANSLATE_19834;
    }
    else {
        _27323 = NewDouble(DBL_PTR(_27322)->dbl + (eudouble)_12TRANSLATE_19834);
    }
    DeRef(_27322);
    _27322 = NOVALUE;
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53477 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27323))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27323)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27323);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _stlen_53908;
    DeRef(_1);

    /** inline.e:356			inline_code[pc+4+TRANSLATE] = file*/
    _27324 = _pc_53869 + 4;
    if ((object)((uintptr_t)_27324 + (uintptr_t)HIGH_BITS) >= 0){
        _27324 = NewDouble((eudouble)_27324);
    }
    if (IS_ATOM_INT(_27324)) {
        _27325 = _27324 + _12TRANSLATE_19834;
    }
    else {
        _27325 = NewDouble(DBL_PTR(_27324)->dbl + (eudouble)_12TRANSLATE_19834);
    }
    DeRef(_27324);
    _27324 = NOVALUE;
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53477 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27325))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27325)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27325);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _file_53913;
    DeRef(_1);

    /** inline.e:358			return ok*/
    DeRef(_27325);
    _27325 = NOVALUE;
    DeRef(_27319);
    _27319 = NOVALUE;
    DeRef(_27313);
    _27313 = NOVALUE;
    DeRef(_27323);
    _27323 = NOVALUE;
    DeRef(_27316);
    _27316 = NOVALUE;
    DeRef(_27299);
    _27299 = NOVALUE;
    return _ok_53918;
    goto L5; // [270] 526
L7: 

    /** inline.e:360		elsif op_info[op][OP_SIZE_TYPE] = FIXED_SIZE then*/
    _2 = (object)SEQ_PTR(_65op_info_24268);
    _27326 = (object)*(((s1_ptr)_2)->base + _op_53870);
    _2 = (object)SEQ_PTR(_27326);
    _27327 = (object)*(((s1_ptr)_2)->base + 1);
    _27326 = NOVALUE;
    if (binary_op_a(NOTEQ, _27327, 1)){
        _27327 = NOVALUE;
        goto L8; // [289] 397
    }
    _27327 = NOVALUE;

    /** inline.e:361			switch op do*/
    _0 = _op_53870;
    switch ( _0 ){ 

        /** inline.e:362				case SWITCH, SWITCH_RT, SWITCH_I, SWITCH_SPI then*/
        case 185:
        case 202:
        case 193:
        case 192:

        /** inline.e:364					symtab_index original_table = inline_code[pc + 3]*/
        _27331 = _pc_53869 + 3;
        _2 = (object)SEQ_PTR(_66inline_code_53477);
        _original_table_53941 = (object)*(((s1_ptr)_2)->base + _27331);
        if (!IS_ATOM_INT(_original_table_53941)){
            _original_table_53941 = (object)DBL_PTR(_original_table_53941)->dbl;
        }

        /** inline.e:365					symtab_index jump_table = NewStringSym( {-2, length(SymTab) } )*/
        if (IS_SEQUENCE(_13SymTab_11316)){
                _27333 = SEQ_PTR(_13SymTab_11316)->length;
        }
        else {
            _27333 = 1;
        }
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -2;
        ((intptr_t *)_2)[2] = _27333;
        _27334 = MAKE_SEQ(_1);
        _27333 = NOVALUE;
        _jump_table_53945 = _53NewStringSym(_27334);
        _27334 = NOVALUE;
        if (!IS_ATOM_INT(_jump_table_53945)) {
            _1 = (object)(DBL_PTR(_jump_table_53945)->dbl);
            DeRefDS(_jump_table_53945);
            _jump_table_53945 = _1;
        }

        /** inline.e:366					SymTab[jump_table][S_OBJ] = SymTab[original_table][S_OBJ]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_jump_table_53945 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27338 = (object)*(((s1_ptr)_2)->base + _original_table_53941);
        _2 = (object)SEQ_PTR(_27338);
        _27339 = (object)*(((s1_ptr)_2)->base + 1);
        _27338 = NOVALUE;
        Ref(_27339);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27339;
        if( _1 != _27339 ){
            DeRef(_1);
        }
        _27339 = NOVALUE;
        _27336 = NOVALUE;

        /** inline.e:367					inline_code[pc+3] = jump_table*/
        _27340 = _pc_53869 + 3;
        _2 = (object)SEQ_PTR(_66inline_code_53477);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _66inline_code_53477 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _27340);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _jump_table_53945;
        DeRef(_1);
    ;}
    /** inline.e:369			return adjust_il( pc, op )*/
    _27341 = _66adjust_il(_pc_53869, _op_53870);
    DeRef(_27325);
    _27325 = NOVALUE;
    DeRef(_27319);
    _27319 = NOVALUE;
    DeRef(_27313);
    _27313 = NOVALUE;
    DeRef(_27323);
    _27323 = NOVALUE;
    DeRef(_27316);
    _27316 = NOVALUE;
    DeRef(_27340);
    _27340 = NOVALUE;
    DeRef(_27331);
    _27331 = NOVALUE;
    DeRef(_27299);
    _27299 = NOVALUE;
    return _27341;
    goto L5; // [394] 526
L8: 

    /** inline.e:372			switch op with fallthru do*/
    _0 = _op_53870;
    switch ( _0 ){ 

        /** inline.e:373				case REF_TEMP then*/
        case 207:

        /** inline.e:374					inline_code[pc+1] = {INLINE_TARGET}*/
        _27344 = _pc_53869 + 1;
        RefDS(_27259);
        _2 = (object)SEQ_PTR(_66inline_code_53477);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _66inline_code_53477 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _27344);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27259;
        DeRef(_1);

        /** inline.e:376				case CONCAT_N then*/
        case 157:
        case 31:

        /** inline.e:379					if check_for_param( pc + 2 + inline_code[pc+1] ) then*/
        _27345 = _pc_53869 + 2;
        if ((object)((uintptr_t)_27345 + (uintptr_t)HIGH_BITS) >= 0){
            _27345 = NewDouble((eudouble)_27345);
        }
        _27346 = _pc_53869 + 1;
        _2 = (object)SEQ_PTR(_66inline_code_53477);
        _27347 = (object)*(((s1_ptr)_2)->base + _27346);
        if (IS_ATOM_INT(_27345) && IS_ATOM_INT(_27347)) {
            _27348 = _27345 + _27347;
            if ((object)((uintptr_t)_27348 + (uintptr_t)HIGH_BITS) >= 0){
                _27348 = NewDouble((eudouble)_27348);
            }
        }
        else {
            _27348 = binary_op(PLUS, _27345, _27347);
        }
        DeRef(_27345);
        _27345 = NOVALUE;
        _27347 = NOVALUE;
        _27349 = _66check_for_param(_27348);
        _27348 = NOVALUE;
        if (_27349 == 0) {
            DeRef(_27349);
            _27349 = NOVALUE;
            goto L9; // [450] 454
        }
        else {
            if (!IS_ATOM_INT(_27349) && DBL_PTR(_27349)->dbl == 0.0){
                DeRef(_27349);
                _27349 = NOVALUE;
                goto L9; // [450] 454
            }
            DeRef(_27349);
            _27349 = NOVALUE;
        }
        DeRef(_27349);
        _27349 = NOVALUE;
L9: 

        /** inline.e:383					for i = pc + 2 to pc + 2 + inline_code[pc+1] do*/
        _27350 = _pc_53869 + 2;
        if ((object)((uintptr_t)_27350 + (uintptr_t)HIGH_BITS) >= 0){
            _27350 = NewDouble((eudouble)_27350);
        }
        _27351 = _pc_53869 + 2;
        if ((object)((uintptr_t)_27351 + (uintptr_t)HIGH_BITS) >= 0){
            _27351 = NewDouble((eudouble)_27351);
        }
        _27352 = _pc_53869 + 1;
        _2 = (object)SEQ_PTR(_66inline_code_53477);
        _27353 = (object)*(((s1_ptr)_2)->base + _27352);
        if (IS_ATOM_INT(_27351) && IS_ATOM_INT(_27353)) {
            _27354 = _27351 + _27353;
            if ((object)((uintptr_t)_27354 + (uintptr_t)HIGH_BITS) >= 0){
                _27354 = NewDouble((eudouble)_27354);
            }
        }
        else {
            _27354 = binary_op(PLUS, _27351, _27353);
        }
        DeRef(_27351);
        _27351 = NOVALUE;
        _27353 = NOVALUE;
        {
            object _i_53977;
            Ref(_27350);
            _i_53977 = _27350;
LA: 
            if (binary_op_a(GREATER, _i_53977, _27354)){
                goto LB; // [478] 508
            }

            /** inline.e:384						if not adjust_symbol( i ) then*/
            Ref(_i_53977);
            _27355 = _66adjust_symbol(_i_53977);
            if (IS_ATOM_INT(_27355)) {
                if (_27355 != 0){
                    DeRef(_27355);
                    _27355 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            else {
                if (DBL_PTR(_27355)->dbl != 0.0){
                    DeRef(_27355);
                    _27355 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            DeRef(_27355);
            _27355 = NOVALUE;

            /** inline.e:385							return 0*/
            DeRef(_i_53977);
            DeRef(_27325);
            _27325 = NOVALUE;
            DeRef(_27319);
            _27319 = NOVALUE;
            DeRef(_27313);
            _27313 = NOVALUE;
            DeRef(_27352);
            _27352 = NOVALUE;
            DeRef(_27323);
            _27323 = NOVALUE;
            DeRef(_27316);
            _27316 = NOVALUE;
            DeRef(_27350);
            _27350 = NOVALUE;
            DeRef(_27354);
            _27354 = NOVALUE;
            DeRef(_27346);
            _27346 = NOVALUE;
            DeRef(_27340);
            _27340 = NOVALUE;
            DeRef(_27341);
            _27341 = NOVALUE;
            DeRef(_27344);
            _27344 = NOVALUE;
            DeRef(_27331);
            _27331 = NOVALUE;
            DeRef(_27299);
            _27299 = NOVALUE;
            return 0;
LC: 

            /** inline.e:388					end for*/
            _0 = _i_53977;
            if (IS_ATOM_INT(_i_53977)) {
                _i_53977 = _i_53977 + 1;
                if ((object)((uintptr_t)_i_53977 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_53977 = NewDouble((eudouble)_i_53977);
                }
            }
            else {
                _i_53977 = binary_op_a(PLUS, _i_53977, 1);
            }
            DeRef(_0);
            goto LA; // [503] 485
LB: 
            ;
            DeRef(_i_53977);
        }

        /** inline.e:389					return 1*/
        DeRef(_27325);
        _27325 = NOVALUE;
        DeRef(_27319);
        _27319 = NOVALUE;
        DeRef(_27313);
        _27313 = NOVALUE;
        DeRef(_27352);
        _27352 = NOVALUE;
        DeRef(_27323);
        _27323 = NOVALUE;
        DeRef(_27316);
        _27316 = NOVALUE;
        DeRef(_27350);
        _27350 = NOVALUE;
        DeRef(_27354);
        _27354 = NOVALUE;
        DeRef(_27346);
        _27346 = NOVALUE;
        DeRef(_27340);
        _27340 = NOVALUE;
        DeRef(_27341);
        _27341 = NOVALUE;
        DeRef(_27344);
        _27344 = NOVALUE;
        DeRef(_27331);
        _27331 = NOVALUE;
        DeRef(_27299);
        _27299 = NOVALUE;
        return 1;

        /** inline.e:390				case else*/
        default:

        /** inline.e:391					return 0*/
        DeRef(_27325);
        _27325 = NOVALUE;
        DeRef(_27319);
        _27319 = NOVALUE;
        DeRef(_27313);
        _27313 = NOVALUE;
        DeRef(_27352);
        _27352 = NOVALUE;
        DeRef(_27323);
        _27323 = NOVALUE;
        DeRef(_27316);
        _27316 = NOVALUE;
        DeRef(_27350);
        _27350 = NOVALUE;
        DeRef(_27354);
        _27354 = NOVALUE;
        DeRef(_27346);
        _27346 = NOVALUE;
        DeRef(_27340);
        _27340 = NOVALUE;
        DeRef(_27341);
        _27341 = NOVALUE;
        DeRef(_27344);
        _27344 = NOVALUE;
        DeRef(_27331);
        _27331 = NOVALUE;
        DeRef(_27299);
        _27299 = NOVALUE;
        return 0;
    ;}L5: 

    /** inline.e:394		return 1*/
    DeRef(_27325);
    _27325 = NOVALUE;
    DeRef(_27319);
    _27319 = NOVALUE;
    DeRef(_27313);
    _27313 = NOVALUE;
    DeRef(_27352);
    _27352 = NOVALUE;
    DeRef(_27323);
    _27323 = NOVALUE;
    DeRef(_27316);
    _27316 = NOVALUE;
    DeRef(_27350);
    _27350 = NOVALUE;
    DeRef(_27354);
    _27354 = NOVALUE;
    DeRef(_27346);
    _27346 = NOVALUE;
    DeRef(_27340);
    _27340 = NOVALUE;
    DeRef(_27341);
    _27341 = NOVALUE;
    DeRef(_27344);
    _27344 = NOVALUE;
    DeRef(_27331);
    _27331 = NOVALUE;
    DeRef(_27299);
    _27299 = NOVALUE;
    return 1;
    ;
}


void _66restore_code()
{
    object _27357 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:399		if length( temp_code ) then*/
    if (IS_SEQUENCE(_66temp_code_53987)){
            _27357 = SEQ_PTR(_66temp_code_53987)->length;
    }
    else {
        _27357 = 1;
    }
    if (_27357 == 0)
    {
        _27357 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _27357 = NOVALUE;
    }

    /** inline.e:400			Code = temp_code*/
    RefDS(_66temp_code_53987);
    DeRef(_12Code_20315);
    _12Code_20315 = _66temp_code_53987;
L1: 

    /** inline.e:402	end procedure*/
    return;
    ;
}


void _66check_inline(object _sub_53996)
{
    object _pc_54025 = NOVALUE;
    object _s_54027 = NOVALUE;
    object _backpatch_op_54065 = NOVALUE;
    object _op_54069 = NOVALUE;
    object _rtn_idx_54080 = NOVALUE;
    object _args_54085 = NOVALUE;
    object _args_54117 = NOVALUE;
    object _values_54146 = NOVALUE;
    object _27444 = NOVALUE;
    object _27443 = NOVALUE;
    object _27441 = NOVALUE;
    object _27438 = NOVALUE;
    object _27436 = NOVALUE;
    object _27435 = NOVALUE;
    object _27434 = NOVALUE;
    object _27432 = NOVALUE;
    object _27431 = NOVALUE;
    object _27430 = NOVALUE;
    object _27429 = NOVALUE;
    object _27428 = NOVALUE;
    object _27427 = NOVALUE;
    object _27426 = NOVALUE;
    object _27425 = NOVALUE;
    object _27424 = NOVALUE;
    object _27422 = NOVALUE;
    object _27421 = NOVALUE;
    object _27420 = NOVALUE;
    object _27419 = NOVALUE;
    object _27418 = NOVALUE;
    object _27416 = NOVALUE;
    object _27415 = NOVALUE;
    object _27414 = NOVALUE;
    object _27413 = NOVALUE;
    object _27412 = NOVALUE;
    object _27410 = NOVALUE;
    object _27409 = NOVALUE;
    object _27408 = NOVALUE;
    object _27407 = NOVALUE;
    object _27406 = NOVALUE;
    object _27405 = NOVALUE;
    object _27404 = NOVALUE;
    object _27403 = NOVALUE;
    object _27402 = NOVALUE;
    object _27401 = NOVALUE;
    object _27400 = NOVALUE;
    object _27399 = NOVALUE;
    object _27398 = NOVALUE;
    object _27397 = NOVALUE;
    object _27395 = NOVALUE;
    object _27392 = NOVALUE;
    object _27387 = NOVALUE;
    object _27385 = NOVALUE;
    object _27382 = NOVALUE;
    object _27381 = NOVALUE;
    object _27380 = NOVALUE;
    object _27379 = NOVALUE;
    object _27378 = NOVALUE;
    object _27377 = NOVALUE;
    object _27376 = NOVALUE;
    object _27375 = NOVALUE;
    object _27373 = NOVALUE;
    object _27371 = NOVALUE;
    object _27370 = NOVALUE;
    object _27368 = NOVALUE;
    object _27366 = NOVALUE;
    object _27364 = NOVALUE;
    object _27362 = NOVALUE;
    object _27361 = NOVALUE;
    object _27360 = NOVALUE;
    object _27359 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:411		if OpTrace or SymTab[sub][S_TOKEN] = TYPE then*/
    if (_12OpTrace_20296 != 0) {
        goto L1; // [7] 34
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27359 = (object)*(((s1_ptr)_2)->base + _sub_53996);
    _2 = (object)SEQ_PTR(_27359);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _27360 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _27360 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _27359 = NOVALUE;
    if (IS_ATOM_INT(_27360)) {
        _27361 = (_27360 == 504);
    }
    else {
        _27361 = binary_op(EQUALS, _27360, 504);
    }
    _27360 = NOVALUE;
    if (_27361 == 0) {
        DeRef(_27361);
        _27361 = NOVALUE;
        goto L2; // [30] 40
    }
    else {
        if (!IS_ATOM_INT(_27361) && DBL_PTR(_27361)->dbl == 0.0){
            DeRef(_27361);
            _27361 = NOVALUE;
            goto L2; // [30] 40
        }
        DeRef(_27361);
        _27361 = NOVALUE;
    }
    DeRef(_27361);
    _27361 = NOVALUE;
L1: 

    /** inline.e:412			return*/
    DeRefi(_backpatch_op_54065);
    return;
L2: 

    /** inline.e:414		inline_sub      = sub*/
    _66inline_sub_53491 = _sub_53996;

    /** inline.e:415		if get_fwdref_count() then*/
    _27362 = _42get_fwdref_count();
    if (_27362 == 0) {
        DeRef(_27362);
        _27362 = NOVALUE;
        goto L3; // [52] 65
    }
    else {
        if (!IS_ATOM_INT(_27362) && DBL_PTR(_27362)->dbl == 0.0){
            DeRef(_27362);
            _27362 = NOVALUE;
            goto L3; // [52] 65
        }
        DeRef(_27362);
        _27362 = NOVALUE;
    }
    DeRef(_27362);
    _27362 = NOVALUE;

    /** inline.e:416			defer()*/
    _66defer();

    /** inline.e:417			return*/
    DeRefi(_backpatch_op_54065);
    return;
L3: 

    /** inline.e:419		temp_code = ""*/
    RefDS(_22015);
    DeRef(_66temp_code_53987);
    _66temp_code_53987 = _22015;

    /** inline.e:420		if sub != CurrentSub then*/
    if (_sub_53996 == _12CurrentSub_20234)
    goto L4; // [76] 99

    /** inline.e:421			Code = SymTab[sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27364 = (object)*(((s1_ptr)_2)->base + _sub_53996);
    DeRef(_12Code_20315);
    _2 = (object)SEQ_PTR(_27364);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    Ref(_12Code_20315);
    _27364 = NOVALUE;
    goto L5; // [96] 109
L4: 

    /** inline.e:423			temp_code = Code*/
    RefDS(_12Code_20315);
    DeRef(_66temp_code_53987);
    _66temp_code_53987 = _12Code_20315;
L5: 

    /** inline.e:426		if length(Code) > OpInline then*/
    if (IS_SEQUENCE(_12Code_20315)){
            _27366 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _27366 = 1;
    }
    if (_27366 <= _12OpInline_20301)
    goto L6; // [118] 128

    /** inline.e:427			return*/
    DeRefi(_backpatch_op_54065);
    return;
L6: 

    /** inline.e:430		inline_code     = Code*/
    RefDS(_12Code_20315);
    DeRef(_66inline_code_53477);
    _66inline_code_53477 = _12Code_20315;

    /** inline.e:431		return_gotos    = 0*/
    _66return_gotos_53486 = 0;

    /** inline.e:432		prev_pc         = 1*/
    _66prev_pc_53485 = 1;

    /** inline.e:433		proc_vars       = {}*/
    RefDS(_22015);
    DeRefi(_66proc_vars_53478);
    _66proc_vars_53478 = _22015;

    /** inline.e:434		inline_temps    = {}*/
    RefDS(_22015);
    DeRef(_66inline_temps_53479);
    _66inline_temps_53479 = _22015;

    /** inline.e:435		inline_params   = {}*/
    RefDS(_22015);
    DeRefi(_66inline_params_53482);
    _66inline_params_53482 = _22015;

    /** inline.e:436		assigned_params = {}*/
    RefDS(_22015);
    DeRef(_66assigned_params_53483);
    _66assigned_params_53483 = _22015;

    /** inline.e:438		integer pc = 1*/
    _pc_54025 = 1;

    /** inline.e:439		symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27368 = (object)*(((s1_ptr)_2)->base + _sub_53996);
    _2 = (object)SEQ_PTR(_27368);
    _s_54027 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_54027)){
        _s_54027 = (object)DBL_PTR(_s_54027)->dbl;
    }
    _27368 = NOVALUE;

    /** inline.e:440		for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27370 = (object)*(((s1_ptr)_2)->base + _sub_53996);
    _2 = (object)SEQ_PTR(_27370);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _27371 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _27371 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _27370 = NOVALUE;
    {
        object _p_54033;
        _p_54033 = 1;
L7: 
        if (binary_op_a(GREATER, _p_54033, _27371)){
            goto L8; // [210] 248
        }

        /** inline.e:441			inline_params &= s*/
        Append(&_66inline_params_53482, _66inline_params_53482, _s_54027);

        /** inline.e:442			s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27373 = (object)*(((s1_ptr)_2)->base + _s_54027);
        _2 = (object)SEQ_PTR(_27373);
        _s_54027 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_54027)){
            _s_54027 = (object)DBL_PTR(_s_54027)->dbl;
        }
        _27373 = NOVALUE;

        /** inline.e:443		end for*/
        _0 = _p_54033;
        if (IS_ATOM_INT(_p_54033)) {
            _p_54033 = _p_54033 + 1;
            if ((object)((uintptr_t)_p_54033 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54033 = NewDouble((eudouble)_p_54033);
            }
        }
        else {
            _p_54033 = binary_op_a(PLUS, _p_54033, 1);
        }
        DeRef(_0);
        goto L7; // [243] 217
L8: 
        ;
        DeRef(_p_54033);
    }

    /** inline.e:445		while s != 0 and */
L9: 
    _27375 = (_s_54027 != 0);
    if (_27375 == 0) {
        goto LA; // [257] 335
    }
    _27377 = _53sym_scope(_s_54027);
    if (IS_ATOM_INT(_27377)) {
        _27378 = (_27377 <= 3);
    }
    else {
        _27378 = binary_op(LESSEQ, _27377, 3);
    }
    DeRef(_27377);
    _27377 = NOVALUE;
    if (IS_ATOM_INT(_27378)) {
        if (_27378 != 0) {
            DeRef(_27379);
            _27379 = 1;
            goto LB; // [271] 289
        }
    }
    else {
        if (DBL_PTR(_27378)->dbl != 0.0) {
            DeRef(_27379);
            _27379 = 1;
            goto LB; // [271] 289
        }
    }
    _27380 = _53sym_scope(_s_54027);
    if (IS_ATOM_INT(_27380)) {
        _27381 = (_27380 == 9);
    }
    else {
        _27381 = binary_op(EQUALS, _27380, 9);
    }
    DeRef(_27380);
    _27380 = NOVALUE;
    DeRef(_27379);
    if (IS_ATOM_INT(_27381))
    _27379 = (_27381 != 0);
    else
    _27379 = DBL_PTR(_27381)->dbl != 0.0;
LB: 
    if (_27379 == 0)
    {
        _27379 = NOVALUE;
        goto LA; // [290] 335
    }
    else{
        _27379 = NOVALUE;
    }

    /** inline.e:447			if sym_scope( s ) != SC_UNDEFINED then*/
    _27382 = _53sym_scope(_s_54027);
    if (binary_op_a(EQUALS, _27382, 9)){
        DeRef(_27382);
        _27382 = NOVALUE;
        goto LC; // [301] 314
    }
    DeRef(_27382);
    _27382 = NOVALUE;

    /** inline.e:448				proc_vars &= s*/
    Append(&_66proc_vars_53478, _66proc_vars_53478, _s_54027);
LC: 

    /** inline.e:451			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27385 = (object)*(((s1_ptr)_2)->base + _s_54027);
    _2 = (object)SEQ_PTR(_27385);
    _s_54027 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_54027)){
        _s_54027 = (object)DBL_PTR(_s_54027)->dbl;
    }
    _27385 = NOVALUE;

    /** inline.e:452		end while*/
    goto L9; // [332] 253
LA: 

    /** inline.e:453		sequence backpatch_op = {}*/
    RefDS(_22015);
    DeRefi(_backpatch_op_54065);
    _backpatch_op_54065 = _22015;

    /** inline.e:454		while pc < length( inline_code ) do*/
LD: 
    if (IS_SEQUENCE(_66inline_code_53477)){
            _27387 = SEQ_PTR(_66inline_code_53477)->length;
    }
    else {
        _27387 = 1;
    }
    if (_pc_54025 >= _27387)
    goto LE; // [352] 869

    /** inline.e:456			integer op = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    _op_54069 = (object)*(((s1_ptr)_2)->base + _pc_54025);
    if (!IS_ATOM_INT(_op_54069))
    _op_54069 = (object)DBL_PTR(_op_54069)->dbl;

    /** inline.e:457			switch op do*/
    _0 = _op_54069;
    switch ( _0 ){ 

        /** inline.e:458				case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** inline.e:459					defer()*/
        _66defer();

        /** inline.e:460					restore_code()*/
        _66restore_code();

        /** inline.e:461					return*/
        DeRefi(_backpatch_op_54065);
        DeRef(_27375);
        _27375 = NOVALUE;
        DeRef(_27378);
        _27378 = NOVALUE;
        _27371 = NOVALUE;
        DeRef(_27381);
        _27381 = NOVALUE;
        return;
        goto LF; // [390] 851

        /** inline.e:463				case PROC, FUNC then*/
        case 27:
        case 501:

        /** inline.e:464					symtab_index rtn_idx = inline_code[pc+1]*/
        _27392 = _pc_54025 + 1;
        _2 = (object)SEQ_PTR(_66inline_code_53477);
        _rtn_idx_54080 = (object)*(((s1_ptr)_2)->base + _27392);
        if (!IS_ATOM_INT(_rtn_idx_54080)){
            _rtn_idx_54080 = (object)DBL_PTR(_rtn_idx_54080)->dbl;
        }

        /** inline.e:465					if rtn_idx = sub then*/
        if (_rtn_idx_54080 != _sub_53996)
        goto L10; // [414] 428

        /** inline.e:467						restore_code()*/
        _66restore_code();

        /** inline.e:468						return*/
        DeRefi(_backpatch_op_54065);
        DeRef(_27375);
        _27375 = NOVALUE;
        DeRef(_27378);
        _27378 = NOVALUE;
        _27392 = NOVALUE;
        _27371 = NOVALUE;
        DeRef(_27381);
        _27381 = NOVALUE;
        return;
L10: 

        /** inline.e:471					integer args = SymTab[rtn_idx][S_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27395 = (object)*(((s1_ptr)_2)->base + _rtn_idx_54080);
        _2 = (object)SEQ_PTR(_27395);
        if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
            _args_54085 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
        }
        else{
            _args_54085 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
        }
        if (!IS_ATOM_INT(_args_54085)){
            _args_54085 = (object)DBL_PTR(_args_54085)->dbl;
        }
        _27395 = NOVALUE;

        /** inline.e:472					if SymTab[rtn_idx][S_TOKEN] != PROC and check_for_param( pc + args + 2 ) then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27397 = (object)*(((s1_ptr)_2)->base + _rtn_idx_54080);
        _2 = (object)SEQ_PTR(_27397);
        if (!IS_ATOM_INT(_12S_TOKEN_19869)){
            _27398 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
        }
        else{
            _27398 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
        }
        _27397 = NOVALUE;
        if (IS_ATOM_INT(_27398)) {
            _27399 = (_27398 != 27);
        }
        else {
            _27399 = binary_op(NOTEQ, _27398, 27);
        }
        _27398 = NOVALUE;
        if (IS_ATOM_INT(_27399)) {
            if (_27399 == 0) {
                goto L11; // [464] 485
            }
        }
        else {
            if (DBL_PTR(_27399)->dbl == 0.0) {
                goto L11; // [464] 485
            }
        }
        _27401 = _pc_54025 + _args_54085;
        if ((object)((uintptr_t)_27401 + (uintptr_t)HIGH_BITS) >= 0){
            _27401 = NewDouble((eudouble)_27401);
        }
        if (IS_ATOM_INT(_27401)) {
            _27402 = _27401 + 2;
            if ((object)((uintptr_t)_27402 + (uintptr_t)HIGH_BITS) >= 0){
                _27402 = NewDouble((eudouble)_27402);
            }
        }
        else {
            _27402 = NewDouble(DBL_PTR(_27401)->dbl + (eudouble)2);
        }
        DeRef(_27401);
        _27401 = NOVALUE;
        _27403 = _66check_for_param(_27402);
        _27402 = NOVALUE;
        if (_27403 == 0) {
            DeRef(_27403);
            _27403 = NOVALUE;
            goto L11; // [481] 485
        }
        else {
            if (!IS_ATOM_INT(_27403) && DBL_PTR(_27403)->dbl == 0.0){
                DeRef(_27403);
                _27403 = NOVALUE;
                goto L11; // [481] 485
            }
            DeRef(_27403);
            _27403 = NOVALUE;
        }
        DeRef(_27403);
        _27403 = NOVALUE;
L11: 

        /** inline.e:475					for i = 2 to args + 1 + (SymTab[rtn_idx][S_TOKEN] != PROC) do*/
        _27404 = _args_54085 + 1;
        if (_27404 > MAXINT){
            _27404 = NewDouble((eudouble)_27404);
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27405 = (object)*(((s1_ptr)_2)->base + _rtn_idx_54080);
        _2 = (object)SEQ_PTR(_27405);
        if (!IS_ATOM_INT(_12S_TOKEN_19869)){
            _27406 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
        }
        else{
            _27406 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
        }
        _27405 = NOVALUE;
        if (IS_ATOM_INT(_27406)) {
            _27407 = (_27406 != 27);
        }
        else {
            _27407 = binary_op(NOTEQ, _27406, 27);
        }
        _27406 = NOVALUE;
        if (IS_ATOM_INT(_27404) && IS_ATOM_INT(_27407)) {
            _27408 = _27404 + _27407;
            if ((object)((uintptr_t)_27408 + (uintptr_t)HIGH_BITS) >= 0){
                _27408 = NewDouble((eudouble)_27408);
            }
        }
        else {
            _27408 = binary_op(PLUS, _27404, _27407);
        }
        DeRef(_27404);
        _27404 = NOVALUE;
        DeRef(_27407);
        _27407 = NOVALUE;
        {
            object _i_54102;
            _i_54102 = 2;
L12: 
            if (binary_op_a(GREATER, _i_54102, _27408)){
                goto L13; // [513] 550
            }

            /** inline.e:476						if not adjust_symbol( pc + i ) then */
            if (IS_ATOM_INT(_i_54102)) {
                _27409 = _pc_54025 + _i_54102;
                if ((object)((uintptr_t)_27409 + (uintptr_t)HIGH_BITS) >= 0){
                    _27409 = NewDouble((eudouble)_27409);
                }
            }
            else {
                _27409 = NewDouble((eudouble)_pc_54025 + DBL_PTR(_i_54102)->dbl);
            }
            _27410 = _66adjust_symbol(_27409);
            _27409 = NOVALUE;
            if (IS_ATOM_INT(_27410)) {
                if (_27410 != 0){
                    DeRef(_27410);
                    _27410 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            else {
                if (DBL_PTR(_27410)->dbl != 0.0){
                    DeRef(_27410);
                    _27410 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            DeRef(_27410);
            _27410 = NOVALUE;

            /** inline.e:477							defer()*/
            _66defer();

            /** inline.e:478							return*/
            DeRef(_i_54102);
            DeRefi(_backpatch_op_54065);
            DeRef(_27375);
            _27375 = NOVALUE;
            DeRef(_27378);
            _27378 = NOVALUE;
            DeRef(_27392);
            _27392 = NOVALUE;
            DeRef(_27399);
            _27399 = NOVALUE;
            DeRef(_27408);
            _27408 = NOVALUE;
            _27371 = NOVALUE;
            DeRef(_27381);
            _27381 = NOVALUE;
            return;
L14: 

            /** inline.e:480					end for*/
            _0 = _i_54102;
            if (IS_ATOM_INT(_i_54102)) {
                _i_54102 = _i_54102 + 1;
                if ((object)((uintptr_t)_i_54102 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_54102 = NewDouble((eudouble)_i_54102);
                }
            }
            else {
                _i_54102 = binary_op_a(PLUS, _i_54102, 1);
            }
            DeRef(_0);
            goto L12; // [545] 520
L13: 
            ;
            DeRef(_i_54102);
        }
        goto LF; // [552] 851

        /** inline.e:482				case RIGHT_BRACE_N then*/
        case 31:

        /** inline.e:484					sequence args = inline_code[pc+2..inline_code[pc+1] + pc + 1]*/
        _27412 = _pc_54025 + 2;
        if ((object)((uintptr_t)_27412 + (uintptr_t)HIGH_BITS) >= 0){
            _27412 = NewDouble((eudouble)_27412);
        }
        _27413 = _pc_54025 + 1;
        _2 = (object)SEQ_PTR(_66inline_code_53477);
        _27414 = (object)*(((s1_ptr)_2)->base + _27413);
        if (IS_ATOM_INT(_27414)) {
            _27415 = _27414 + _pc_54025;
            if ((object)((uintptr_t)_27415 + (uintptr_t)HIGH_BITS) >= 0){
                _27415 = NewDouble((eudouble)_27415);
            }
        }
        else {
            _27415 = binary_op(PLUS, _27414, _pc_54025);
        }
        _27414 = NOVALUE;
        if (IS_ATOM_INT(_27415)) {
            _27416 = _27415 + 1;
        }
        else
        _27416 = binary_op(PLUS, 1, _27415);
        DeRef(_27415);
        _27415 = NOVALUE;
        rhs_slice_target = (object_ptr)&_args_54117;
        RHS_Slice(_66inline_code_53477, _27412, _27416);

        /** inline.e:486					for i = 1 to length(args) - 1 do*/
        if (IS_SEQUENCE(_args_54117)){
                _27418 = SEQ_PTR(_args_54117)->length;
        }
        else {
            _27418 = 1;
        }
        _27419 = _27418 - 1;
        _27418 = NOVALUE;
        {
            object _i_54125;
            _i_54125 = 1;
L15: 
            if (_i_54125 > _27419){
                goto L16; // [598] 644
            }

            /** inline.e:487						if find( args[i], args, i + 1 ) then*/
            _2 = (object)SEQ_PTR(_args_54117);
            _27420 = (object)*(((s1_ptr)_2)->base + _i_54125);
            _27421 = _i_54125 + 1;
            _27422 = find_from(_27420, _args_54117, _27421);
            _27420 = NOVALUE;
            _27421 = NOVALUE;
            if (_27422 == 0)
            {
                _27422 = NOVALUE;
                goto L17; // [620] 637
            }
            else{
                _27422 = NOVALUE;
            }

            /** inline.e:488							defer()*/
            _66defer();

            /** inline.e:489							restore_code()*/
            _66restore_code();

            /** inline.e:490							return*/
            DeRefDS(_args_54117);
            DeRefi(_backpatch_op_54065);
            DeRef(_27375);
            _27375 = NOVALUE;
            DeRef(_27378);
            _27378 = NOVALUE;
            DeRef(_27412);
            _27412 = NOVALUE;
            DeRef(_27416);
            _27416 = NOVALUE;
            DeRef(_27392);
            _27392 = NOVALUE;
            DeRef(_27419);
            _27419 = NOVALUE;
            DeRef(_27399);
            _27399 = NOVALUE;
            DeRef(_27413);
            _27413 = NOVALUE;
            DeRef(_27408);
            _27408 = NOVALUE;
            _27371 = NOVALUE;
            DeRef(_27381);
            _27381 = NOVALUE;
            return;
L17: 

            /** inline.e:492					end for*/
            _i_54125 = _i_54125 + 1;
            goto L15; // [639] 605
L16: 
            ;
        }

        /** inline.e:493					goto "inline op"*/
        DeRef(_args_54117);
        _args_54117 = NOVALUE;
        goto G18;
        goto LF; // [654] 851

        /** inline.e:495				case RIGHT_BRACE_2 then*/
        case 85:

        /** inline.e:496					if equal( inline_code[pc+1], inline_code[pc+2] ) then*/
        _27424 = _pc_54025 + 1;
        _2 = (object)SEQ_PTR(_66inline_code_53477);
        _27425 = (object)*(((s1_ptr)_2)->base + _27424);
        _27426 = _pc_54025 + 2;
        _2 = (object)SEQ_PTR(_66inline_code_53477);
        _27427 = (object)*(((s1_ptr)_2)->base + _27426);
        if (_27425 == _27427)
        _27428 = 1;
        else if (IS_ATOM_INT(_27425) && IS_ATOM_INT(_27427))
        _27428 = 0;
        else
        _27428 = (compare(_27425, _27427) == 0);
        _27425 = NOVALUE;
        _27427 = NOVALUE;
        if (_27428 == 0)
        {
            _27428 = NOVALUE;
            goto L19; // [686] 703
        }
        else{
            _27428 = NOVALUE;
        }

        /** inline.e:497						defer()*/
        _66defer();

        /** inline.e:498						restore_code()*/
        _66restore_code();

        /** inline.e:499						return*/
        DeRefi(_backpatch_op_54065);
        DeRef(_27375);
        _27375 = NOVALUE;
        DeRef(_27378);
        _27378 = NOVALUE;
        _27426 = NOVALUE;
        DeRef(_27412);
        _27412 = NOVALUE;
        DeRef(_27416);
        _27416 = NOVALUE;
        DeRef(_27392);
        _27392 = NOVALUE;
        DeRef(_27419);
        _27419 = NOVALUE;
        DeRef(_27399);
        _27399 = NOVALUE;
        DeRef(_27413);
        _27413 = NOVALUE;
        DeRef(_27408);
        _27408 = NOVALUE;
        _27371 = NOVALUE;
        DeRef(_27381);
        _27381 = NOVALUE;
        _27424 = NOVALUE;
        return;
L19: 

        /** inline.e:501					goto "inline op"*/
        goto G18;
        goto LF; // [711] 851

        /** inline.e:503				case EXIT_BLOCK then*/
        case 206:

        /** inline.e:504					replace_code( "", pc, pc + 1 )*/
        _27429 = _pc_54025 + 1;
        if (_27429 > MAXINT){
            _27429 = NewDouble((eudouble)_27429);
        }
        RefDS(_22015);
        _66replace_code(_22015, _pc_54025, _27429);
        _27429 = NOVALUE;

        /** inline.e:505					continue*/
        goto LD; // [732] 347
        goto LF; // [734] 851

        /** inline.e:507				case SWITCH_RT then*/
        case 202:

        /** inline.e:508					sequence values = SymTab[inline_code[pc+2]][S_OBJ]*/
        _27430 = _pc_54025 + 2;
        _2 = (object)SEQ_PTR(_66inline_code_53477);
        _27431 = (object)*(((s1_ptr)_2)->base + _27430);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!IS_ATOM_INT(_27431)){
            _27432 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27431)->dbl));
        }
        else{
            _27432 = (object)*(((s1_ptr)_2)->base + _27431);
        }
        DeRef(_values_54146);
        _2 = (object)SEQ_PTR(_27432);
        _values_54146 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_values_54146);
        _27432 = NOVALUE;

        /** inline.e:509					for i = 1 to length( values ) do*/
        if (IS_SEQUENCE(_values_54146)){
                _27434 = SEQ_PTR(_values_54146)->length;
        }
        else {
            _27434 = 1;
        }
        {
            object _i_54154;
            _i_54154 = 1;
L1A: 
            if (_i_54154 > _27434){
                goto L1B; // [771] 811
            }

            /** inline.e:510						if sequence( values[i] ) then*/
            _2 = (object)SEQ_PTR(_values_54146);
            _27435 = (object)*(((s1_ptr)_2)->base + _i_54154);
            _27436 = IS_SEQUENCE(_27435);
            _27435 = NOVALUE;
            if (_27436 == 0)
            {
                _27436 = NOVALUE;
                goto L1C; // [787] 804
            }
            else{
                _27436 = NOVALUE;
            }

            /** inline.e:512							defer()*/
            _66defer();

            /** inline.e:513							restore_code()*/
            _66restore_code();

            /** inline.e:514							return*/
            DeRefDS(_values_54146);
            DeRefi(_backpatch_op_54065);
            DeRef(_27375);
            _27375 = NOVALUE;
            DeRef(_27430);
            _27430 = NOVALUE;
            DeRef(_27378);
            _27378 = NOVALUE;
            DeRef(_27426);
            _27426 = NOVALUE;
            DeRef(_27412);
            _27412 = NOVALUE;
            DeRef(_27416);
            _27416 = NOVALUE;
            DeRef(_27392);
            _27392 = NOVALUE;
            DeRef(_27419);
            _27419 = NOVALUE;
            DeRef(_27399);
            _27399 = NOVALUE;
            _27431 = NOVALUE;
            DeRef(_27413);
            _27413 = NOVALUE;
            DeRef(_27408);
            _27408 = NOVALUE;
            _27371 = NOVALUE;
            DeRef(_27381);
            _27381 = NOVALUE;
            DeRef(_27424);
            _27424 = NOVALUE;
            return;
L1C: 

            /** inline.e:516					end for*/
            _i_54154 = _i_54154 + 1;
            goto L1A; // [806] 778
L1B: 
            ;
        }

        /** inline.e:517					backpatch_op = append( backpatch_op, pc )*/
        Append(&_backpatch_op_54065, _backpatch_op_54065, _pc_54025);
        DeRef(_values_54146);
        _values_54146 = NOVALUE;

        /** inline.e:520				case else*/
        default:

        /** inline.e:521				label "inline op"*/
G18:

        /** inline.e:522					if not inline_op( pc ) then*/
        _27438 = _66inline_op(_pc_54025);
        if (IS_ATOM_INT(_27438)) {
            if (_27438 != 0){
                DeRef(_27438);
                _27438 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        else {
            if (DBL_PTR(_27438)->dbl != 0.0){
                DeRef(_27438);
                _27438 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        DeRef(_27438);
        _27438 = NOVALUE;

        /** inline.e:524						defer()*/
        _66defer();

        /** inline.e:525						restore_code()*/
        _66restore_code();

        /** inline.e:526						return*/
        DeRefi(_backpatch_op_54065);
        DeRef(_27375);
        _27375 = NOVALUE;
        DeRef(_27430);
        _27430 = NOVALUE;
        DeRef(_27378);
        _27378 = NOVALUE;
        DeRef(_27426);
        _27426 = NOVALUE;
        DeRef(_27412);
        _27412 = NOVALUE;
        DeRef(_27416);
        _27416 = NOVALUE;
        DeRef(_27392);
        _27392 = NOVALUE;
        DeRef(_27419);
        _27419 = NOVALUE;
        DeRef(_27399);
        _27399 = NOVALUE;
        _27431 = NOVALUE;
        DeRef(_27413);
        _27413 = NOVALUE;
        DeRef(_27408);
        _27408 = NOVALUE;
        _27371 = NOVALUE;
        DeRef(_27381);
        _27381 = NOVALUE;
        DeRef(_27424);
        _27424 = NOVALUE;
        return;
L1D: 
    ;}LF: 

    /** inline.e:530			pc = advance( pc, inline_code )*/
    RefDS(_66inline_code_53477);
    _pc_54025 = _66advance(_pc_54025, _66inline_code_53477);
    if (!IS_ATOM_INT(_pc_54025)) {
        _1 = (object)(DBL_PTR(_pc_54025)->dbl);
        DeRefDS(_pc_54025);
        _pc_54025 = _1;
    }

    /** inline.e:532		end while*/
    goto LD; // [866] 347
LE: 

    /** inline.e:534		SymTab[sub][S_INLINE] = { sort( assigned_params ), inline_code, backpatch_op }*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_53996 + ((s1_ptr)_2)->base);
    RefDS(_66assigned_params_53483);
    _27443 = _25sort(_66assigned_params_53483, 1);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _27443;
    RefDS(_66inline_code_53477);
    ((intptr_t*)_2)[2] = _66inline_code_53477;
    RefDS(_backpatch_op_54065);
    ((intptr_t*)_2)[3] = _backpatch_op_54065;
    _27444 = MAKE_SEQ(_1);
    _27443 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 29);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27444;
    if( _1 != _27444 ){
        DeRef(_1);
    }
    _27444 = NOVALUE;
    _27441 = NOVALUE;

    /** inline.e:535		restore_code()*/
    _66restore_code();

    /** inline.e:536	end procedure*/
    DeRefDSi(_backpatch_op_54065);
    DeRef(_27375);
    _27375 = NOVALUE;
    DeRef(_27430);
    _27430 = NOVALUE;
    DeRef(_27378);
    _27378 = NOVALUE;
    DeRef(_27426);
    _27426 = NOVALUE;
    DeRef(_27412);
    _27412 = NOVALUE;
    DeRef(_27416);
    _27416 = NOVALUE;
    DeRef(_27392);
    _27392 = NOVALUE;
    DeRef(_27419);
    _27419 = NOVALUE;
    DeRef(_27399);
    _27399 = NOVALUE;
    _27431 = NOVALUE;
    DeRef(_27413);
    _27413 = NOVALUE;
    DeRef(_27408);
    _27408 = NOVALUE;
    _27371 = NOVALUE;
    DeRef(_27381);
    _27381 = NOVALUE;
    DeRef(_27424);
    _27424 = NOVALUE;
    return;
    ;
}


void _66replace_temp(object _pc_54174)
{
    object _temp_num_54175 = NOVALUE;
    object _needed_54178 = NOVALUE;
    object _27457 = NOVALUE;
    object _27456 = NOVALUE;
    object _27455 = NOVALUE;
    object _27454 = NOVALUE;
    object _27452 = NOVALUE;
    object _27450 = NOVALUE;
    object _27447 = NOVALUE;
    object _27445 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:539		integer temp_num = inline_code[pc][2]*/
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    _27445 = (object)*(((s1_ptr)_2)->base + _pc_54174);
    _2 = (object)SEQ_PTR(_27445);
    _temp_num_54175 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_temp_num_54175)){
        _temp_num_54175 = (object)DBL_PTR(_temp_num_54175)->dbl;
    }
    _27445 = NOVALUE;

    /** inline.e:540		integer needed = temp_num - length( inline_temps )*/
    if (IS_SEQUENCE(_66inline_temps_53479)){
            _27447 = SEQ_PTR(_66inline_temps_53479)->length;
    }
    else {
        _27447 = 1;
    }
    _needed_54178 = _temp_num_54175 - _27447;
    _27447 = NOVALUE;

    /** inline.e:541		if needed > 0 then*/
    if (_needed_54178 <= 0)
    goto L1; // [30] 47

    /** inline.e:542			inline_temps &= repeat( 0, needed )*/
    _27450 = Repeat(0, _needed_54178);
    Concat((object_ptr)&_66inline_temps_53479, _66inline_temps_53479, _27450);
    DeRefDS(_27450);
    _27450 = NOVALUE;
L1: 

    /** inline.e:545		if not inline_temps[temp_num] then*/
    _2 = (object)SEQ_PTR(_66inline_temps_53479);
    _27452 = (object)*(((s1_ptr)_2)->base + _temp_num_54175);
    if (IS_ATOM_INT(_27452)) {
        if (_27452 != 0){
            _27452 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    else {
        if (DBL_PTR(_27452)->dbl != 0.0){
            _27452 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    _27452 = NOVALUE;

    /** inline.e:546			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L3; // [62] 84
    }
    else{
    }

    /** inline.e:547				inline_temps[temp_num] = new_inline_var( -temp_num, 0 )*/
    if ((uintptr_t)_temp_num_54175 == (uintptr_t)HIGH_BITS){
        _27454 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _27454 = - _temp_num_54175;
    }
    _27455 = _66new_inline_var(_27454, 0);
    _27454 = NOVALUE;
    _2 = (object)SEQ_PTR(_66inline_temps_53479);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_temps_53479 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _temp_num_54175);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27455;
    if( _1 != _27455 ){
        DeRef(_1);
    }
    _27455 = NOVALUE;
    goto L4; // [81] 99
L3: 

    /** inline.e:549				inline_temps[temp_num] = NewTempSym( TRUE )*/
    _27456 = _53NewTempSym(_9TRUE_446);
    _2 = (object)SEQ_PTR(_66inline_temps_53479);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_temps_53479 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _temp_num_54175);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27456;
    if( _1 != _27456 ){
        DeRef(_1);
    }
    _27456 = NOVALUE;
L4: 
L2: 

    /** inline.e:554		inline_code[pc] = inline_temps[temp_num]*/
    _2 = (object)SEQ_PTR(_66inline_temps_53479);
    _27457 = (object)*(((s1_ptr)_2)->base + _temp_num_54175);
    Ref(_27457);
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53477 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_54174);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27457;
    if( _1 != _27457 ){
        DeRef(_1);
    }
    _27457 = NOVALUE;

    /** inline.e:555	end procedure*/
    return;
    ;
}


object _66get_param_sym(object _pc_54200)
{
    object _il_54201 = NOVALUE;
    object _px_54209 = NOVALUE;
    object _27464 = NOVALUE;
    object _27461 = NOVALUE;
    object _27460 = NOVALUE;
    object _27459 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:558		object il = inline_code[pc]*/
    DeRef(_il_54201);
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    _il_54201 = (object)*(((s1_ptr)_2)->base + _pc_54200);
    Ref(_il_54201);

    /** inline.e:559		if integer( il ) then*/
    if (IS_ATOM_INT(_il_54201))
    _27459 = 1;
    else if (IS_ATOM_DBL(_il_54201))
    _27459 = IS_ATOM_INT(DoubleToInt(_il_54201));
    else
    _27459 = 0;
    if (_27459 == 0)
    {
        _27459 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27459 = NOVALUE;
    }

    /** inline.e:560			return inline_code[pc]*/
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    _27460 = (object)*(((s1_ptr)_2)->base + _pc_54200);
    Ref(_27460);
    DeRef(_il_54201);
    return _27460;
    goto L2; // [31] 53
L1: 

    /** inline.e:562		elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_54201)){
            _27461 = SEQ_PTR(_il_54201)->length;
    }
    else {
        _27461 = 1;
    }
    if (_27461 != 1)
    goto L3; // [39] 52

    /** inline.e:563			return inline_target*/
    DeRef(_il_54201);
    _27460 = NOVALUE;
    return _66inline_target_53484;
L3: 
L2: 

    /** inline.e:567		integer px = il[2]*/
    _2 = (object)SEQ_PTR(_il_54201);
    _px_54209 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_px_54209)){
        _px_54209 = (object)DBL_PTR(_px_54209)->dbl;
    }

    /** inline.e:568		return passed_params[px]*/
    _2 = (object)SEQ_PTR(_66passed_params_53480);
    _27464 = (object)*(((s1_ptr)_2)->base + _px_54209);
    Ref(_27464);
    DeRef(_il_54201);
    _27460 = NOVALUE;
    return _27464;
    ;
}


object _66get_original_sym(object _pc_54214)
{
    object _il_54215 = NOVALUE;
    object _px_54223 = NOVALUE;
    object _27471 = NOVALUE;
    object _27468 = NOVALUE;
    object _27467 = NOVALUE;
    object _27466 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_54214)) {
        _1 = (object)(DBL_PTR(_pc_54214)->dbl);
        DeRefDS(_pc_54214);
        _pc_54214 = _1;
    }

    /** inline.e:572		object il = inline_code[pc]*/
    DeRef(_il_54215);
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    _il_54215 = (object)*(((s1_ptr)_2)->base + _pc_54214);
    Ref(_il_54215);

    /** inline.e:573		if integer( il ) then*/
    if (IS_ATOM_INT(_il_54215))
    _27466 = 1;
    else if (IS_ATOM_DBL(_il_54215))
    _27466 = IS_ATOM_INT(DoubleToInt(_il_54215));
    else
    _27466 = 0;
    if (_27466 == 0)
    {
        _27466 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27466 = NOVALUE;
    }

    /** inline.e:574			return inline_code[pc]*/
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    _27467 = (object)*(((s1_ptr)_2)->base + _pc_54214);
    Ref(_27467);
    DeRef(_il_54215);
    return _27467;
    goto L2; // [31] 53
L1: 

    /** inline.e:576		elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_54215)){
            _27468 = SEQ_PTR(_il_54215)->length;
    }
    else {
        _27468 = 1;
    }
    if (_27468 != 1)
    goto L3; // [39] 52

    /** inline.e:577			return inline_target*/
    DeRef(_il_54215);
    _27467 = NOVALUE;
    return _66inline_target_53484;
L3: 
L2: 

    /** inline.e:581		integer px = il[2]*/
    _2 = (object)SEQ_PTR(_il_54215);
    _px_54223 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_px_54223)){
        _px_54223 = (object)DBL_PTR(_px_54223)->dbl;
    }

    /** inline.e:582		return original_params[px]*/
    _2 = (object)SEQ_PTR(_66original_params_53481);
    _27471 = (object)*(((s1_ptr)_2)->base + _px_54223);
    Ref(_27471);
    DeRef(_il_54215);
    _27467 = NOVALUE;
    return _27471;
    ;
}


void _66replace_var(object _pc_54232)
{
    object _27475 = NOVALUE;
    object _27474 = NOVALUE;
    object _27473 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:590		inline_code[pc] = proc_vars[inline_code[pc][2]]*/
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    _27473 = (object)*(((s1_ptr)_2)->base + _pc_54232);
    _2 = (object)SEQ_PTR(_27473);
    _27474 = (object)*(((s1_ptr)_2)->base + 2);
    _27473 = NOVALUE;
    _2 = (object)SEQ_PTR(_66proc_vars_53478);
    if (!IS_ATOM_INT(_27474)){
        _27475 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27474)->dbl));
    }
    else{
        _27475 = (object)*(((s1_ptr)_2)->base + _27474);
    }
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53477 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_54232);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27475;
    if( _1 != _27475 ){
        DeRef(_1);
    }
    _27475 = NOVALUE;

    /** inline.e:591	end procedure*/
    _27474 = NOVALUE;
    return;
    ;
}


void _66fix_switch_rt(object _pc_54238)
{
    object _value_table_54240 = NOVALUE;
    object _jump_table_54247 = NOVALUE;
    object _27495 = NOVALUE;
    object _27494 = NOVALUE;
    object _27493 = NOVALUE;
    object _27492 = NOVALUE;
    object _27491 = NOVALUE;
    object _27490 = NOVALUE;
    object _27488 = NOVALUE;
    object _27487 = NOVALUE;
    object _27486 = NOVALUE;
    object _27485 = NOVALUE;
    object _27484 = NOVALUE;
    object _27482 = NOVALUE;
    object _27480 = NOVALUE;
    object _27479 = NOVALUE;
    object _27477 = NOVALUE;
    object _27476 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:594		symtab_index value_table = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _27476 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _27476 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = _27476;
    _27477 = MAKE_SEQ(_1);
    _27476 = NOVALUE;
    _value_table_54240 = _53NewStringSym(_27477);
    _27477 = NOVALUE;
    if (!IS_ATOM_INT(_value_table_54240)) {
        _1 = (object)(DBL_PTR(_value_table_54240)->dbl);
        DeRefDS(_value_table_54240);
        _value_table_54240 = _1;
    }

    /** inline.e:595		symtab_index jump_table  = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _27479 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _27479 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = _27479;
    _27480 = MAKE_SEQ(_1);
    _27479 = NOVALUE;
    _jump_table_54247 = _53NewStringSym(_27480);
    _27480 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_54247)) {
        _1 = (object)(DBL_PTR(_jump_table_54247)->dbl);
        DeRefDS(_jump_table_54247);
        _jump_table_54247 = _1;
    }

    /** inline.e:597		SymTab[value_table][S_OBJ] = SymTab[inline_code[pc+2]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_value_table_54240 + ((s1_ptr)_2)->base);
    _27484 = _pc_54238 + 2;
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    _27485 = (object)*(((s1_ptr)_2)->base + _27484);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_27485)){
        _27486 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27485)->dbl));
    }
    else{
        _27486 = (object)*(((s1_ptr)_2)->base + _27485);
    }
    _2 = (object)SEQ_PTR(_27486);
    _27487 = (object)*(((s1_ptr)_2)->base + 1);
    _27486 = NOVALUE;
    Ref(_27487);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27487;
    if( _1 != _27487 ){
        DeRef(_1);
    }
    _27487 = NOVALUE;
    _27482 = NOVALUE;

    /** inline.e:598		SymTab[jump_table][S_OBJ]  = SymTab[inline_code[pc+3]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_jump_table_54247 + ((s1_ptr)_2)->base);
    _27490 = _pc_54238 + 3;
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    _27491 = (object)*(((s1_ptr)_2)->base + _27490);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_27491)){
        _27492 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27491)->dbl));
    }
    else{
        _27492 = (object)*(((s1_ptr)_2)->base + _27491);
    }
    _2 = (object)SEQ_PTR(_27492);
    _27493 = (object)*(((s1_ptr)_2)->base + 1);
    _27492 = NOVALUE;
    Ref(_27493);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27493;
    if( _1 != _27493 ){
        DeRef(_1);
    }
    _27493 = NOVALUE;
    _27488 = NOVALUE;

    /** inline.e:600		inline_code[pc+2] = value_table*/
    _27494 = _pc_54238 + 2;
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53477 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27494);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _value_table_54240;
    DeRef(_1);

    /** inline.e:601		inline_code[pc+3] = jump_table*/
    _27495 = _pc_54238 + 3;
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53477 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27495);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _jump_table_54247;
    DeRef(_1);

    /** inline.e:603	end procedure*/
    _27490 = NOVALUE;
    _27484 = NOVALUE;
    _27485 = NOVALUE;
    _27495 = NOVALUE;
    _27491 = NOVALUE;
    _27494 = NOVALUE;
    return;
    ;
}


void _66fixup_special_op(object _pc_54277)
{
    object _op_54278 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_54277)) {
        _1 = (object)(DBL_PTR(_pc_54277)->dbl);
        DeRefDS(_pc_54277);
        _pc_54277 = _1;
    }

    /** inline.e:606		integer op = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    _op_54278 = (object)*(((s1_ptr)_2)->base + _pc_54277);
    if (!IS_ATOM_INT(_op_54278))
    _op_54278 = (object)DBL_PTR(_op_54278)->dbl;

    /** inline.e:607		switch op with fallthru do*/
    _0 = _op_54278;
    switch ( _0 ){ 

        /** inline.e:608			case SWITCH_RT then*/
        case 202:

        /** inline.e:609				fix_switch_rt( pc )*/
        _66fix_switch_rt(_pc_54277);

        /** inline.e:610				break*/
        goto L1; // [29] 32
    ;}L1: 

    /** inline.e:612	end procedure*/
    return;
    ;
}


object _66new_inline_var(object _ps_54289, object _reuse_54290)
{
    object _var_54292 = NOVALUE;
    object _vtype_54293 = NOVALUE;
    object _name_54294 = NOVALUE;
    object _s_54296 = NOVALUE;
    object _27558 = NOVALUE;
    object _27557 = NOVALUE;
    object _27555 = NOVALUE;
    object _27552 = NOVALUE;
    object _27551 = NOVALUE;
    object _27549 = NOVALUE;
    object _27546 = NOVALUE;
    object _27545 = NOVALUE;
    object _27544 = NOVALUE;
    object _27542 = NOVALUE;
    object _27537 = NOVALUE;
    object _27532 = NOVALUE;
    object _27531 = NOVALUE;
    object _27530 = NOVALUE;
    object _27529 = NOVALUE;
    object _27526 = NOVALUE;
    object _27524 = NOVALUE;
    object _27521 = NOVALUE;
    object _27516 = NOVALUE;
    object _27515 = NOVALUE;
    object _27514 = NOVALUE;
    object _27513 = NOVALUE;
    object _27512 = NOVALUE;
    object _27509 = NOVALUE;
    object _27508 = NOVALUE;
    object _27507 = NOVALUE;
    object _27506 = NOVALUE;
    object _27505 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ps_54289)) {
        _1 = (object)(DBL_PTR(_ps_54289)->dbl);
        DeRefDS(_ps_54289);
        _ps_54289 = _1;
    }

    /** inline.e:622			var = 0, */
    _var_54292 = 0;

    /** inline.e:624		sequence name*/

    /** inline.e:627		if reuse then*/

    /** inline.e:631		if not var then*/

    /** inline.e:632			if ps > 0 then*/
    if (_ps_54289 <= 0)
    goto L1; // [45] 222

    /** inline.e:633				s = ps*/
    _s_54296 = _ps_54289;

    /** inline.e:634				if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L2; // [60] 102
    }
    else{
    }

    /** inline.e:635					name = sprintf( "%s_inlined_%s", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27505 = (object)*(((s1_ptr)_2)->base + _s_54296);
    _2 = (object)SEQ_PTR(_27505);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _27506 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _27506 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _27505 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27507 = (object)*(((s1_ptr)_2)->base + _66inline_sub_53491);
    _2 = (object)SEQ_PTR(_27507);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _27508 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _27508 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _27507 = NOVALUE;
    Ref(_27508);
    Ref(_27506);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27506;
    ((intptr_t *)_2)[2] = _27508;
    _27509 = MAKE_SEQ(_1);
    _27508 = NOVALUE;
    _27506 = NOVALUE;
    DeRefi(_name_54294);
    _name_54294 = EPrintf(-9999999, _27504, _27509);
    DeRefDS(_27509);
    _27509 = NOVALUE;
    goto L3; // [99] 139
L2: 

    /** inline.e:637					name = sprintf( "%s (from inlined routine '%s'", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27512 = (object)*(((s1_ptr)_2)->base + _s_54296);
    _2 = (object)SEQ_PTR(_27512);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _27513 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _27513 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _27512 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27514 = (object)*(((s1_ptr)_2)->base + _66inline_sub_53491);
    _2 = (object)SEQ_PTR(_27514);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _27515 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _27515 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _27514 = NOVALUE;
    Ref(_27515);
    Ref(_27513);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27513;
    ((intptr_t *)_2)[2] = _27515;
    _27516 = MAKE_SEQ(_1);
    _27515 = NOVALUE;
    _27513 = NOVALUE;
    DeRefi(_name_54294);
    _name_54294 = EPrintf(-9999999, _27511, _27516);
    DeRefDS(_27516);
    _27516 = NOVALUE;
L3: 

    /** inline.e:640				if reuse then*/
    if (_reuse_54290 == 0)
    {
        goto L4; // [141] 163
    }
    else{
    }

    /** inline.e:641					if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto L5; // [148] 203

    /** inline.e:642						name &= ")"*/
    Concat((object_ptr)&_name_54294, _name_54294, _26281);
    goto L5; // [160] 203
L4: 

    /** inline.e:645					if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L6; // [167] 187
    }
    else{
    }

    /** inline.e:646						name &= sprintf( "_at_%d", inline_start)*/
    _27521 = EPrintf(-9999999, _27520, _66inline_start_53489);
    Concat((object_ptr)&_name_54294, _name_54294, _27521);
    DeRefDS(_27521);
    _27521 = NOVALUE;
    goto L7; // [184] 202
L6: 

    /** inline.e:648						name &= sprintf( " at %d)", inline_start)*/
    _27524 = EPrintf(-9999999, _27523, _66inline_start_53489);
    Concat((object_ptr)&_name_54294, _name_54294, _27524);
    DeRefDS(_27524);
    _27524 = NOVALUE;
L7: 
L5: 

    /** inline.e:652				vtype = SymTab[s][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27526 = (object)*(((s1_ptr)_2)->base + _s_54296);
    _2 = (object)SEQ_PTR(_27526);
    _vtype_54293 = (object)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_vtype_54293)){
        _vtype_54293 = (object)DBL_PTR(_vtype_54293)->dbl;
    }
    _27526 = NOVALUE;
    goto L8; // [219] 286
L1: 

    /** inline.e:654				name = sprintf( "%s_%d", {SymTab[inline_sub][S_NAME], -ps})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27529 = (object)*(((s1_ptr)_2)->base + _66inline_sub_53491);
    _2 = (object)SEQ_PTR(_27529);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _27530 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _27530 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _27529 = NOVALUE;
    if ((uintptr_t)_ps_54289 == (uintptr_t)HIGH_BITS){
        _27531 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _27531 = - _ps_54289;
    }
    Ref(_27530);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27530;
    ((intptr_t *)_2)[2] = _27531;
    _27532 = MAKE_SEQ(_1);
    _27531 = NOVALUE;
    _27530 = NOVALUE;
    DeRefi(_name_54294);
    _name_54294 = EPrintf(-9999999, _27528, _27532);
    DeRefDS(_27532);
    _27532 = NOVALUE;

    /** inline.e:655				if reuse then*/
    if (_reuse_54290 == 0)
    {
        goto L9; // [251] 263
    }
    else{
    }

    /** inline.e:656					name &= "__tmp"*/
    Concat((object_ptr)&_name_54294, _name_54294, _27534);
    goto LA; // [260] 276
L9: 

    /** inline.e:658					name &= sprintf( "__tmp_at%d", inline_start)*/
    _27537 = EPrintf(-9999999, _27536, _66inline_start_53489);
    Concat((object_ptr)&_name_54294, _name_54294, _27537);
    DeRefDS(_27537);
    _27537 = NOVALUE;
LA: 

    /** inline.e:660				vtype = object_type*/
    _vtype_54293 = _53object_type_46803;
L8: 

    /** inline.e:662			if CurrentSub = TopLevelSub then*/
    if (_12CurrentSub_20234 != _12TopLevelSub_20233)
    goto LB; // [292] 325

    /** inline.e:663				var = NewEntry( name, varnum, SC_LOCAL, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_54294);
    _var_54292 = _53NewEntry(_name_54294, _66varnum_53488, 5, -100, 2004, 0, _vtype_54293);
    if (!IS_ATOM_INT(_var_54292)) {
        _1 = (object)(DBL_PTR(_var_54292)->dbl);
        DeRefDS(_var_54292);
        _var_54292 = _1;
    }
    goto LC; // [322] 416
LB: 

    /** inline.e:666				var = NewBasicEntry( name, varnum, SC_PRIVATE, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_54294);
    _var_54292 = _53NewBasicEntry(_name_54294, _66varnum_53488, 3, -100, 2004, 0, _vtype_54293);
    if (!IS_ATOM_INT(_var_54292)) {
        _1 = (object)(DBL_PTR(_var_54292)->dbl);
        DeRefDS(_var_54292);
        _var_54292 = _1;
    }

    /** inline.e:667				SymTab[var][S_NEXT] = SymTab[last_param][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_var_54292 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27544 = (object)*(((s1_ptr)_2)->base + _66last_param_53492);
    _2 = (object)SEQ_PTR(_27544);
    _27545 = (object)*(((s1_ptr)_2)->base + 2);
    _27544 = NOVALUE;
    Ref(_27545);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27545;
    if( _1 != _27545 ){
        DeRef(_1);
    }
    _27545 = NOVALUE;
    _27542 = NOVALUE;

    /** inline.e:668				SymTab[last_param][S_NEXT] = var*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_66last_param_53492 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _var_54292;
    DeRef(_1);
    _27546 = NOVALUE;

    /** inline.e:669				if last_param = last_sym then*/
    if (_66last_param_53492 != _53last_sym_46812)
    goto LD; // [403] 415

    /** inline.e:670					last_sym = var*/
    _53last_sym_46812 = _var_54292;
LD: 
LC: 

    /** inline.e:673			if deferred_inlining then*/
    if (_66deferred_inlining_53487 == 0)
    {
        goto LE; // [420] 451
    }
    else{
    }

    /** inline.e:674				SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_12S_STACK_SPACE_19924)){
        _27551 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_STACK_SPACE_19924)->dbl));
    }
    else{
        _27551 = (object)*(((s1_ptr)_2)->base + _12S_STACK_SPACE_19924);
    }
    _27549 = NOVALUE;
    if (IS_ATOM_INT(_27551)) {
        _27552 = _27551 + 1;
        if (_27552 > MAXINT){
            _27552 = NewDouble((eudouble)_27552);
        }
    }
    else
    _27552 = binary_op(PLUS, 1, _27551);
    _27551 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_STACK_SPACE_19924))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_STACK_SPACE_19924)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_STACK_SPACE_19924);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27552;
    if( _1 != _27552 ){
        DeRef(_1);
    }
    _27552 = NOVALUE;
    _27549 = NOVALUE;
    goto LF; // [448] 471
LE: 

    /** inline.e:676				if param_num != -1 then*/
    if (_43param_num_54961 == -1)
    goto L10; // [455] 470

    /** inline.e:677					param_num += 1*/
    _43param_num_54961 = _43param_num_54961 + 1;
L10: 
LF: 

    /** inline.e:680			SymTab[var][S_USAGE] = U_USED*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_var_54292 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _27555 = NOVALUE;

    /** inline.e:681			if reuse then*/
    if (_reuse_54290 == 0)
    {
        goto L11; // [490] 511
    }
    else{
    }

    /** inline.e:682				map:nested_put( inline_var_map, {CurrentSub, ps }, var )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _12CurrentSub_20234;
    ((intptr_t *)_2)[2] = _ps_54289;
    _27557 = MAKE_SEQ(_1);
    Ref(_66inline_var_map_53496);
    _34nested_put(_66inline_var_map_53496, _27557, _var_54292, 1, 0);
    _27557 = NOVALUE;
L11: 

    /** inline.e:686		Block_var( var )*/
    _64Block_var(_var_54292);

    /** inline.e:687		if BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto L12; // [521] 536
    }
    else{
    }

    /** inline.e:688			add_ref( {VARIABLE, var} )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _var_54292;
    _27558 = MAKE_SEQ(_1);
    _53add_ref(_27558);
    _27558 = NOVALUE;
L12: 

    /** inline.e:690		return var*/
    DeRefi(_name_54294);
    return _var_54292;
    ;
}


object _66get_inlined_code(object _sub_54426, object _start_54427, object _deferred_54428)
{
    object _is_proc_54429 = NOVALUE;
    object _backpatches_54447 = NOVALUE;
    object _prolog_54453 = NOVALUE;
    object _epilog_54454 = NOVALUE;
    object _s_54470 = NOVALUE;
    object _last_sym_54493 = NOVALUE;
    object _int_sym_54520 = NOVALUE;
    object _param_54528 = NOVALUE;
    object _ax_54531 = NOVALUE;
    object _var_54538 = NOVALUE;
    object _final_target_54553 = NOVALUE;
    object _var_54572 = NOVALUE;
    object _create_target_var_54585 = NOVALUE;
    object _check_pc_54608 = NOVALUE;
    object _op_54612 = NOVALUE;
    object _sym_54621 = NOVALUE;
    object _check_result_54626 = NOVALUE;
    object _inline_type_54704 = NOVALUE;
    object _replace_param_1__tmp_at1343_54715 = NOVALUE;
    object _27712 = NOVALUE;
    object _27711 = NOVALUE;
    object _27710 = NOVALUE;
    object _27709 = NOVALUE;
    object _27708 = NOVALUE;
    object _27707 = NOVALUE;
    object _27706 = NOVALUE;
    object _27705 = NOVALUE;
    object _27703 = NOVALUE;
    object _27700 = NOVALUE;
    object _27697 = NOVALUE;
    object _27696 = NOVALUE;
    object _27695 = NOVALUE;
    object _27694 = NOVALUE;
    object _27693 = NOVALUE;
    object _27692 = NOVALUE;
    object _27691 = NOVALUE;
    object _27690 = NOVALUE;
    object _27686 = NOVALUE;
    object _27685 = NOVALUE;
    object _27684 = NOVALUE;
    object _27683 = NOVALUE;
    object _27679 = NOVALUE;
    object _27678 = NOVALUE;
    object _27677 = NOVALUE;
    object _27676 = NOVALUE;
    object _27675 = NOVALUE;
    object _27674 = NOVALUE;
    object _27673 = NOVALUE;
    object _27671 = NOVALUE;
    object _27670 = NOVALUE;
    object _27669 = NOVALUE;
    object _27668 = NOVALUE;
    object _27667 = NOVALUE;
    object _27666 = NOVALUE;
    object _27665 = NOVALUE;
    object _27664 = NOVALUE;
    object _27663 = NOVALUE;
    object _27662 = NOVALUE;
    object _27661 = NOVALUE;
    object _27659 = NOVALUE;
    object _27658 = NOVALUE;
    object _27656 = NOVALUE;
    object _27655 = NOVALUE;
    object _27653 = NOVALUE;
    object _27652 = NOVALUE;
    object _27649 = NOVALUE;
    object _27648 = NOVALUE;
    object _27646 = NOVALUE;
    object _27644 = NOVALUE;
    object _27639 = NOVALUE;
    object _27635 = NOVALUE;
    object _27632 = NOVALUE;
    object _27628 = NOVALUE;
    object _27621 = NOVALUE;
    object _27620 = NOVALUE;
    object _27619 = NOVALUE;
    object _27618 = NOVALUE;
    object _27617 = NOVALUE;
    object _27616 = NOVALUE;
    object _27615 = NOVALUE;
    object _27613 = NOVALUE;
    object _27608 = NOVALUE;
    object _27605 = NOVALUE;
    object _27600 = NOVALUE;
    object _27599 = NOVALUE;
    object _27597 = NOVALUE;
    object _27596 = NOVALUE;
    object _27595 = NOVALUE;
    object _27592 = NOVALUE;
    object _27591 = NOVALUE;
    object _27590 = NOVALUE;
    object _27589 = NOVALUE;
    object _27588 = NOVALUE;
    object _27587 = NOVALUE;
    object _27586 = NOVALUE;
    object _27584 = NOVALUE;
    object _27583 = NOVALUE;
    object _27582 = NOVALUE;
    object _27580 = NOVALUE;
    object _27578 = NOVALUE;
    object _27577 = NOVALUE;
    object _27576 = NOVALUE;
    object _27575 = NOVALUE;
    object _27574 = NOVALUE;
    object _27573 = NOVALUE;
    object _27572 = NOVALUE;
    object _27569 = NOVALUE;
    object _27568 = NOVALUE;
    object _27566 = NOVALUE;
    object _27565 = NOVALUE;
    object _27563 = NOVALUE;
    object _27562 = NOVALUE;
    object _27560 = NOVALUE;
    object _27559 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_start_54427)) {
        _1 = (object)(DBL_PTR(_start_54427)->dbl);
        DeRefDS(_start_54427);
        _start_54427 = _1;
    }

    /** inline.e:694		integer is_proc = SymTab[sub][S_TOKEN] = PROC*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27559 = (object)*(((s1_ptr)_2)->base + _sub_54426);
    _2 = (object)SEQ_PTR(_27559);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _27560 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _27560 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _27559 = NOVALUE;
    if (IS_ATOM_INT(_27560)) {
        _is_proc_54429 = (_27560 == 27);
    }
    else {
        _is_proc_54429 = binary_op(EQUALS, _27560, 27);
    }
    _27560 = NOVALUE;
    if (!IS_ATOM_INT(_is_proc_54429)) {
        _1 = (object)(DBL_PTR(_is_proc_54429)->dbl);
        DeRefDS(_is_proc_54429);
        _is_proc_54429 = _1;
    }

    /** inline.e:695		clear_inline_targets()*/
    _45clear_inline_targets();

    /** inline.e:697		inline_temps = {}*/
    RefDS(_22015);
    DeRef(_66inline_temps_53479);
    _66inline_temps_53479 = _22015;

    /** inline.e:698		inline_params = {}*/
    RefDS(_22015);
    DeRefi(_66inline_params_53482);
    _66inline_params_53482 = _22015;

    /** inline.e:699		assigned_params      = SymTab[sub][S_INLINE][1]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27562 = (object)*(((s1_ptr)_2)->base + _sub_54426);
    _2 = (object)SEQ_PTR(_27562);
    _27563 = (object)*(((s1_ptr)_2)->base + 29);
    _27562 = NOVALUE;
    DeRef(_66assigned_params_53483);
    _2 = (object)SEQ_PTR(_27563);
    _66assigned_params_53483 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_66assigned_params_53483);
    _27563 = NOVALUE;

    /** inline.e:700		inline_code          = SymTab[sub][S_INLINE][2]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27565 = (object)*(((s1_ptr)_2)->base + _sub_54426);
    _2 = (object)SEQ_PTR(_27565);
    _27566 = (object)*(((s1_ptr)_2)->base + 29);
    _27565 = NOVALUE;
    DeRef(_66inline_code_53477);
    _2 = (object)SEQ_PTR(_27566);
    _66inline_code_53477 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_66inline_code_53477);
    _27566 = NOVALUE;

    /** inline.e:701		sequence backpatches = SymTab[sub][S_INLINE][3]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27568 = (object)*(((s1_ptr)_2)->base + _sub_54426);
    _2 = (object)SEQ_PTR(_27568);
    _27569 = (object)*(((s1_ptr)_2)->base + 29);
    _27568 = NOVALUE;
    DeRef(_backpatches_54447);
    _2 = (object)SEQ_PTR(_27569);
    _backpatches_54447 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_backpatches_54447);
    _27569 = NOVALUE;

    /** inline.e:703		passed_params = {}*/
    RefDS(_22015);
    DeRef(_66passed_params_53480);
    _66passed_params_53480 = _22015;

    /** inline.e:704		original_params = {}*/
    RefDS(_22015);
    DeRef(_66original_params_53481);
    _66original_params_53481 = _22015;

    /** inline.e:705		proc_vars = {}*/
    RefDS(_22015);
    DeRefi(_66proc_vars_53478);
    _66proc_vars_53478 = _22015;

    /** inline.e:706		sequence prolog = {}*/
    RefDS(_22015);
    DeRefi(_prolog_54453);
    _prolog_54453 = _22015;

    /** inline.e:707		sequence epilog = {}*/
    RefDS(_22015);
    DeRef(_epilog_54454);
    _epilog_54454 = _22015;

    /** inline.e:709		Start_block( EXIT_BLOCK, sprintf("Inline-%s from %s @ %d", */
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27572 = (object)*(((s1_ptr)_2)->base + _sub_54426);
    _2 = (object)SEQ_PTR(_27572);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _27573 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _27573 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _27572 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27574 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_27574);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _27575 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _27575 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _27574 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_27573);
    ((intptr_t*)_2)[1] = _27573;
    Ref(_27575);
    ((intptr_t*)_2)[2] = _27575;
    ((intptr_t*)_2)[3] = _start_54427;
    _27576 = MAKE_SEQ(_1);
    _27575 = NOVALUE;
    _27573 = NOVALUE;
    _27577 = EPrintf(-9999999, _27571, _27576);
    DeRefDS(_27576);
    _27576 = NOVALUE;
    _64Start_block(206, _27577);
    _27577 = NOVALUE;

    /** inline.e:712		symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27578 = (object)*(((s1_ptr)_2)->base + _sub_54426);
    _2 = (object)SEQ_PTR(_27578);
    _s_54470 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_54470)){
        _s_54470 = (object)DBL_PTR(_s_54470)->dbl;
    }
    _27578 = NOVALUE;

    /** inline.e:714		varnum = SymTab[CurrentSub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27580 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_27580);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _66varnum_53488 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _66varnum_53488 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    if (!IS_ATOM_INT(_66varnum_53488)){
        _66varnum_53488 = (object)DBL_PTR(_66varnum_53488)->dbl;
    }
    _27580 = NOVALUE;

    /** inline.e:715		inline_start = start*/
    _66inline_start_53489 = _start_54427;

    /** inline.e:717		last_param = CurrentSub*/
    _66last_param_53492 = _12CurrentSub_20234;

    /** inline.e:718		for p = 1 to SymTab[CurrentSub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27582 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_27582);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _27583 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _27583 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _27582 = NOVALUE;
    {
        object _p_54482;
        _p_54482 = 1;
L1: 
        if (binary_op_a(GREATER, _p_54482, _27583)){
            goto L2; // [250] 282
        }

        /** inline.e:719			last_param = SymTab[last_param][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27584 = (object)*(((s1_ptr)_2)->base + _66last_param_53492);
        _2 = (object)SEQ_PTR(_27584);
        _66last_param_53492 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_66last_param_53492)){
            _66last_param_53492 = (object)DBL_PTR(_66last_param_53492)->dbl;
        }
        _27584 = NOVALUE;

        /** inline.e:720		end for*/
        _0 = _p_54482;
        if (IS_ATOM_INT(_p_54482)) {
            _p_54482 = _p_54482 + 1;
            if ((object)((uintptr_t)_p_54482 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54482 = NewDouble((eudouble)_p_54482);
            }
        }
        else {
            _p_54482 = binary_op_a(PLUS, _p_54482, 1);
        }
        DeRef(_0);
        goto L1; // [277] 257
L2: 
        ;
        DeRef(_p_54482);
    }

    /** inline.e:722		symtab_index last_sym = last_param*/
    _last_sym_54493 = _66last_param_53492;

    /** inline.e:723		while last_sym and */
L3: 
    if (_last_sym_54493 == 0) {
        goto L4; // [296] 368
    }
    _27587 = _53sym_scope(_last_sym_54493);
    if (IS_ATOM_INT(_27587)) {
        _27588 = (_27587 <= 3);
    }
    else {
        _27588 = binary_op(LESSEQ, _27587, 3);
    }
    DeRef(_27587);
    _27587 = NOVALUE;
    if (IS_ATOM_INT(_27588)) {
        if (_27588 != 0) {
            DeRef(_27589);
            _27589 = 1;
            goto L5; // [310] 328
        }
    }
    else {
        if (DBL_PTR(_27588)->dbl != 0.0) {
            DeRef(_27589);
            _27589 = 1;
            goto L5; // [310] 328
        }
    }
    _27590 = _53sym_scope(_last_sym_54493);
    if (IS_ATOM_INT(_27590)) {
        _27591 = (_27590 == 9);
    }
    else {
        _27591 = binary_op(EQUALS, _27590, 9);
    }
    DeRef(_27590);
    _27590 = NOVALUE;
    DeRef(_27589);
    if (IS_ATOM_INT(_27591))
    _27589 = (_27591 != 0);
    else
    _27589 = DBL_PTR(_27591)->dbl != 0.0;
L5: 
    if (_27589 == 0)
    {
        _27589 = NOVALUE;
        goto L4; // [329] 368
    }
    else{
        _27589 = NOVALUE;
    }

    /** inline.e:725			last_param = last_sym*/
    _66last_param_53492 = _last_sym_54493;

    /** inline.e:726			last_sym = SymTab[last_sym][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27592 = (object)*(((s1_ptr)_2)->base + _last_sym_54493);
    _2 = (object)SEQ_PTR(_27592);
    _last_sym_54493 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_last_sym_54493)){
        _last_sym_54493 = (object)DBL_PTR(_last_sym_54493)->dbl;
    }
    _27592 = NOVALUE;

    /** inline.e:727			varnum += 1*/
    _66varnum_53488 = _66varnum_53488 + 1;

    /** inline.e:728		end while*/
    goto L3; // [365] 296
L4: 

    /** inline.e:729		for p = SymTab[sub][S_NUM_ARGS] to 1 by -1 do*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27595 = (object)*(((s1_ptr)_2)->base + _sub_54426);
    _2 = (object)SEQ_PTR(_27595);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _27596 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _27596 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _27595 = NOVALUE;
    {
        object _p_54511;
        Ref(_27596);
        _p_54511 = _27596;
L6: 
        if (binary_op_a(LESS, _p_54511, 1)){
            goto L7; // [382] 407
        }

        /** inline.e:730			passed_params = prepend( passed_params, Pop() )*/
        _27597 = _45Pop();
        Ref(_27597);
        Prepend(&_66passed_params_53480, _66passed_params_53480, _27597);
        DeRef(_27597);
        _27597 = NOVALUE;

        /** inline.e:731		end for*/
        _0 = _p_54511;
        if (IS_ATOM_INT(_p_54511)) {
            _p_54511 = _p_54511 + -1;
            if ((object)((uintptr_t)_p_54511 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54511 = NewDouble((eudouble)_p_54511);
            }
        }
        else {
            _p_54511 = binary_op_a(PLUS, _p_54511, -1);
        }
        DeRef(_0);
        goto L6; // [402] 389
L7: 
        ;
        DeRef(_p_54511);
    }

    /** inline.e:733		original_params = passed_params*/
    RefDS(_66passed_params_53480);
    DeRef(_66original_params_53481);
    _66original_params_53481 = _66passed_params_53480;

    /** inline.e:735		symtab_index int_sym = 0*/
    _int_sym_54520 = 0;

    /** inline.e:736		for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27599 = (object)*(((s1_ptr)_2)->base + _sub_54426);
    _2 = (object)SEQ_PTR(_27599);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _27600 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _27600 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _27599 = NOVALUE;
    {
        object _p_54522;
        _p_54522 = 1;
L8: 
        if (binary_op_a(GREATER, _p_54522, _27600)){
            goto L9; // [437] 575
        }

        /** inline.e:737			symtab_index param = passed_params[p]*/
        _2 = (object)SEQ_PTR(_66passed_params_53480);
        if (!IS_ATOM_INT(_p_54522)){
            _param_54528 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_p_54522)->dbl));
        }
        else{
            _param_54528 = (object)*(((s1_ptr)_2)->base + _p_54522);
        }
        if (!IS_ATOM_INT(_param_54528)){
            _param_54528 = (object)DBL_PTR(_param_54528)->dbl;
        }

        /** inline.e:738			inline_params &= s*/
        Append(&_66inline_params_53482, _66inline_params_53482, _s_54470);

        /** inline.e:739			integer ax = find( p, assigned_params )*/
        _ax_54531 = find_from(_p_54522, _66assigned_params_53483, 1);

        /** inline.e:740			if ax or is_temp( param ) then*/
        if (_ax_54531 != 0) {
            goto LA; // [473] 486
        }
        _27605 = _66is_temp(_param_54528);
        if (_27605 == 0) {
            DeRef(_27605);
            _27605 = NOVALUE;
            goto LB; // [482] 548
        }
        else {
            if (!IS_ATOM_INT(_27605) && DBL_PTR(_27605)->dbl == 0.0){
                DeRef(_27605);
                _27605 = NOVALUE;
                goto LB; // [482] 548
            }
            DeRef(_27605);
            _27605 = NOVALUE;
        }
        DeRef(_27605);
        _27605 = NOVALUE;
LA: 

        /** inline.e:743				varnum += 1*/
        _66varnum_53488 = _66varnum_53488 + 1;

        /** inline.e:744				symtab_index var = new_inline_var( s, 0 )*/
        _var_54538 = _66new_inline_var(_s_54470, 0);
        if (!IS_ATOM_INT(_var_54538)) {
            _1 = (object)(DBL_PTR(_var_54538)->dbl);
            DeRefDS(_var_54538);
            _var_54538 = _1;
        }

        /** inline.e:745				prolog &= {ASSIGN, param, var}*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 18;
        ((intptr_t*)_2)[2] = _param_54528;
        ((intptr_t*)_2)[3] = _var_54538;
        _27608 = MAKE_SEQ(_1);
        Concat((object_ptr)&_prolog_54453, _prolog_54453, _27608);
        DeRefDS(_27608);
        _27608 = NOVALUE;

        /** inline.e:746				if not int_sym then*/
        if (_int_sym_54520 != 0)
        goto LC; // [519] 531

        /** inline.e:747					int_sym = NewIntSym( 0 )*/
        _int_sym_54520 = _53NewIntSym(0);
        if (!IS_ATOM_INT(_int_sym_54520)) {
            _1 = (object)(DBL_PTR(_int_sym_54520)->dbl);
            DeRefDS(_int_sym_54520);
            _int_sym_54520 = _1;
        }
LC: 

        /** inline.e:750				inline_start += 3*/
        _66inline_start_53489 = _66inline_start_53489 + 3;

        /** inline.e:751				passed_params[p] = var*/
        _2 = (object)SEQ_PTR(_66passed_params_53480);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _66passed_params_53480 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_p_54522))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_p_54522)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _p_54522);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _var_54538;
        DeRef(_1);
LB: 

        /** inline.e:753			s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27613 = (object)*(((s1_ptr)_2)->base + _s_54470);
        _2 = (object)SEQ_PTR(_27613);
        _s_54470 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_54470)){
            _s_54470 = (object)DBL_PTR(_s_54470)->dbl;
        }
        _27613 = NOVALUE;

        /** inline.e:755		end for*/
        _0 = _p_54522;
        if (IS_ATOM_INT(_p_54522)) {
            _p_54522 = _p_54522 + 1;
            if ((object)((uintptr_t)_p_54522 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54522 = NewDouble((eudouble)_p_54522);
            }
        }
        else {
            _p_54522 = binary_op_a(PLUS, _p_54522, 1);
        }
        DeRef(_0);
        goto L8; // [570] 444
L9: 
        ;
        DeRef(_p_54522);
    }

    /** inline.e:757		symtab_index final_target = 0*/
    _final_target_54553 = 0;

    /** inline.e:758		while s and */
LD: 
    if (_s_54470 == 0) {
        goto LE; // [587] 699
    }
    _27616 = _53sym_scope(_s_54470);
    if (IS_ATOM_INT(_27616)) {
        _27617 = (_27616 <= 3);
    }
    else {
        _27617 = binary_op(LESSEQ, _27616, 3);
    }
    DeRef(_27616);
    _27616 = NOVALUE;
    if (IS_ATOM_INT(_27617)) {
        if (_27617 != 0) {
            DeRef(_27618);
            _27618 = 1;
            goto LF; // [601] 619
        }
    }
    else {
        if (DBL_PTR(_27617)->dbl != 0.0) {
            DeRef(_27618);
            _27618 = 1;
            goto LF; // [601] 619
        }
    }
    _27619 = _53sym_scope(_s_54470);
    if (IS_ATOM_INT(_27619)) {
        _27620 = (_27619 == 9);
    }
    else {
        _27620 = binary_op(EQUALS, _27619, 9);
    }
    DeRef(_27619);
    _27619 = NOVALUE;
    DeRef(_27618);
    if (IS_ATOM_INT(_27620))
    _27618 = (_27620 != 0);
    else
    _27618 = DBL_PTR(_27620)->dbl != 0.0;
LF: 
    if (_27618 == 0)
    {
        _27618 = NOVALUE;
        goto LE; // [620] 699
    }
    else{
        _27618 = NOVALUE;
    }

    /** inline.e:760			if sym_scope( s ) != SC_UNDEFINED then*/
    _27621 = _53sym_scope(_s_54470);
    if (binary_op_a(EQUALS, _27621, 9)){
        DeRef(_27621);
        _27621 = NOVALUE;
        goto L10; // [631] 676
    }
    DeRef(_27621);
    _27621 = NOVALUE;

    /** inline.e:763				varnum += 1*/
    _66varnum_53488 = _66varnum_53488 + 1;

    /** inline.e:764				symtab_index var = new_inline_var( s, 0 )*/
    _var_54572 = _66new_inline_var(_s_54470, 0);
    if (!IS_ATOM_INT(_var_54572)) {
        _1 = (object)(DBL_PTR(_var_54572)->dbl);
        DeRefDS(_var_54572);
        _var_54572 = _1;
    }

    /** inline.e:765				proc_vars &= var*/
    Append(&_66proc_vars_53478, _66proc_vars_53478, _var_54572);

    /** inline.e:766				if int_sym = 0 then*/
    if (_int_sym_54520 != 0)
    goto L11; // [662] 675

    /** inline.e:767					int_sym = NewIntSym( 0 )*/
    _int_sym_54520 = _53NewIntSym(0);
    if (!IS_ATOM_INT(_int_sym_54520)) {
        _1 = (object)(DBL_PTR(_int_sym_54520)->dbl);
        DeRefDS(_int_sym_54520);
        _int_sym_54520 = _1;
    }
L11: 
L10: 

    /** inline.e:770			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27628 = (object)*(((s1_ptr)_2)->base + _s_54470);
    _2 = (object)SEQ_PTR(_27628);
    _s_54470 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_54470)){
        _s_54470 = (object)DBL_PTR(_s_54470)->dbl;
    }
    _27628 = NOVALUE;

    /** inline.e:771		end while*/
    goto LD; // [696] 587
LE: 

    /** inline.e:773		if not is_proc then*/
    if (_is_proc_54429 != 0)
    goto L12; // [701] 831

    /** inline.e:774			integer create_target_var = 1*/
    _create_target_var_54585 = 1;

    /** inline.e:775			if deferred then*/
    if (_deferred_54428 == 0)
    {
        goto L13; // [711] 751
    }
    else{
    }

    /** inline.e:776				inline_target = Pop()*/
    _0 = _45Pop();
    _66inline_target_53484 = _0;
    if (!IS_ATOM_INT(_66inline_target_53484)) {
        _1 = (object)(DBL_PTR(_66inline_target_53484)->dbl);
        DeRefDS(_66inline_target_53484);
        _66inline_target_53484 = _1;
    }

    /** inline.e:777				if is_temp( inline_target ) then*/
    _27632 = _66is_temp(_66inline_target_53484);
    if (_27632 == 0) {
        DeRef(_27632);
        _27632 = NOVALUE;
        goto L14; // [729] 744
    }
    else {
        if (!IS_ATOM_INT(_27632) && DBL_PTR(_27632)->dbl == 0.0){
            DeRef(_27632);
            _27632 = NOVALUE;
            goto L14; // [729] 744
        }
        DeRef(_27632);
        _27632 = NOVALUE;
    }
    DeRef(_27632);
    _27632 = NOVALUE;

    /** inline.e:778					final_target = inline_target*/
    _final_target_54553 = _66inline_target_53484;
    goto L15; // [741] 750
L14: 

    /** inline.e:780					create_target_var = 0*/
    _create_target_var_54585 = 0;
L15: 
L13: 

    /** inline.e:784			if create_target_var then*/
    if (_create_target_var_54585 == 0)
    {
        goto L16; // [753] 816
    }
    else{
    }

    /** inline.e:785				varnum += 1*/
    _66varnum_53488 = _66varnum_53488 + 1;

    /** inline.e:786				if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L17; // [768] 806
    }
    else{
    }

    /** inline.e:787					inline_target = new_inline_var( sub, 0 )*/
    _0 = _66new_inline_var(_sub_54426, 0);
    _66inline_target_53484 = _0;
    if (!IS_ATOM_INT(_66inline_target_53484)) {
        _1 = (object)(DBL_PTR(_66inline_target_53484)->dbl);
        DeRefDS(_66inline_target_53484);
        _66inline_target_53484 = _1;
    }

    /** inline.e:788					SymTab[inline_target][S_VTYPE] = object_type*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_66inline_target_53484 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53object_type_46803;
    DeRef(_1);
    _27635 = NOVALUE;

    /** inline.e:789					Pop_block_var()*/
    _64Pop_block_var();
    goto L18; // [803] 815
L17: 

    /** inline.e:791					inline_target = NewTempSym()*/
    _0 = _53NewTempSym(0);
    _66inline_target_53484 = _0;
    if (!IS_ATOM_INT(_66inline_target_53484)) {
        _1 = (object)(DBL_PTR(_66inline_target_53484)->dbl);
        DeRefDS(_66inline_target_53484);
        _66inline_target_53484 = _1;
    }
L18: 
L16: 

    /** inline.e:794			proc_vars &= inline_target*/
    Append(&_66proc_vars_53478, _66proc_vars_53478, _66inline_target_53484);
    goto L19; // [828] 837
L12: 

    /** inline.e:796			inline_target = 0*/
    _66inline_target_53484 = 0;
L19: 

    /** inline.e:800		integer check_pc = 1*/
    _check_pc_54608 = 1;

    /** inline.e:802		while length(inline_code) > check_pc do*/
L1A: 
    if (IS_SEQUENCE(_66inline_code_53477)){
            _27639 = SEQ_PTR(_66inline_code_53477)->length;
    }
    else {
        _27639 = 1;
    }
    if (_27639 <= _check_pc_54608)
    goto L1B; // [852] 1218

    /** inline.e:803			integer op = inline_code[check_pc]*/
    _2 = (object)SEQ_PTR(_66inline_code_53477);
    _op_54612 = (object)*(((s1_ptr)_2)->base + _check_pc_54608);
    if (!IS_ATOM_INT(_op_54612))
    _op_54612 = (object)DBL_PTR(_op_54612)->dbl;

    /** inline.e:805			switch op with fallthru do*/
    _0 = _op_54612;
    switch ( _0 ){ 

        /** inline.e:806				case ATOM_CHECK then*/
        case 101:
        case 97:
        case 96:

        /** inline.e:809					symtab_index sym = get_original_sym( check_pc + 1 )*/
        _27644 = _check_pc_54608 + 1;
        if (_27644 > MAXINT){
            _27644 = NewDouble((eudouble)_27644);
        }
        _sym_54621 = _66get_original_sym(_27644);
        _27644 = NOVALUE;
        if (!IS_ATOM_INT(_sym_54621)) {
            _1 = (object)(DBL_PTR(_sym_54621)->dbl);
            DeRefDS(_sym_54621);
            _sym_54621 = _1;
        }

        /** inline.e:810					if is_literal( sym ) then*/
        _27646 = _66is_literal(_sym_54621);
        if (_27646 == 0) {
            DeRef(_27646);
            _27646 = NOVALUE;
            goto L1C; // [897] 1012
        }
        else {
            if (!IS_ATOM_INT(_27646) && DBL_PTR(_27646)->dbl == 0.0){
                DeRef(_27646);
                _27646 = NOVALUE;
                goto L1C; // [897] 1012
            }
            DeRef(_27646);
            _27646 = NOVALUE;
        }
        DeRef(_27646);
        _27646 = NOVALUE;

        /** inline.e:811						integer check_result*/

        /** inline.e:813						if op = INTEGER_CHECK then*/
        if (_op_54612 != 96)
        goto L1D; // [906] 930

        /** inline.e:814							check_result = integer( SymTab[sym][S_OBJ] )*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27648 = (object)*(((s1_ptr)_2)->base + _sym_54621);
        _2 = (object)SEQ_PTR(_27648);
        _27649 = (object)*(((s1_ptr)_2)->base + 1);
        _27648 = NOVALUE;
        if (IS_ATOM_INT(_27649))
        _check_result_54626 = 1;
        else if (IS_ATOM_DBL(_27649))
        _check_result_54626 = IS_ATOM_INT(DoubleToInt(_27649));
        else
        _check_result_54626 = 0;
        _27649 = NOVALUE;
        goto L1E; // [927] 976
L1D: 

        /** inline.e:815						elsif op = SEQUENCE_CHECK then*/
        if (_op_54612 != 97)
        goto L1F; // [934] 958

        /** inline.e:816							check_result = sequence( SymTab[sym][S_OBJ] )*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27652 = (object)*(((s1_ptr)_2)->base + _sym_54621);
        _2 = (object)SEQ_PTR(_27652);
        _27653 = (object)*(((s1_ptr)_2)->base + 1);
        _27652 = NOVALUE;
        _check_result_54626 = IS_SEQUENCE(_27653);
        _27653 = NOVALUE;
        goto L1E; // [955] 976
L1F: 

        /** inline.e:818							check_result = atom( SymTab[sym][S_OBJ] )*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27655 = (object)*(((s1_ptr)_2)->base + _sym_54621);
        _2 = (object)SEQ_PTR(_27655);
        _27656 = (object)*(((s1_ptr)_2)->base + 1);
        _27655 = NOVALUE;
        _check_result_54626 = IS_ATOM(_27656);
        _27656 = NOVALUE;
L1E: 

        /** inline.e:821						if check_result then*/
        if (_check_result_54626 == 0)
        {
            goto L20; // [980] 997
        }
        else{
        }

        /** inline.e:822							replace_code( {}, check_pc, check_pc+1 )*/
        _27658 = _check_pc_54608 + 1;
        if (_27658 > MAXINT){
            _27658 = NewDouble((eudouble)_27658);
        }
        RefDS(_22015);
        _66replace_code(_22015, _check_pc_54608, _27658);
        _27658 = NOVALUE;
        goto L21; // [994] 1007
L20: 

        /** inline.e:826							CompileErr(TYPE_CHECK_ERROR_WHEN_INLINING_LITERAL)*/
        RefDS(_22015);
        _49CompileErr(146, _22015, 0);
L21: 
        goto L22; // [1009] 1174
L1C: 

        /** inline.e:829					elsif not is_temp( sym ) then*/
        _27659 = _66is_temp(_sym_54621);
        if (IS_ATOM_INT(_27659)) {
            if (_27659 != 0){
                DeRef(_27659);
                _27659 = NOVALUE;
                goto L23; // [1018] 1167
            }
        }
        else {
            if (DBL_PTR(_27659)->dbl != 0.0){
                DeRef(_27659);
                _27659 = NOVALUE;
                goto L23; // [1018] 1167
            }
        }
        DeRef(_27659);
        _27659 = NOVALUE;

        /** inline.e:831						if (op = INTEGER_CHECK and SymTab[sym][S_VTYPE] = integer_type )*/
        _27661 = (_op_54612 == 96);
        if (_27661 == 0) {
            _27662 = 0;
            goto L24; // [1029] 1055
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27663 = (object)*(((s1_ptr)_2)->base + _sym_54621);
        _2 = (object)SEQ_PTR(_27663);
        _27664 = (object)*(((s1_ptr)_2)->base + 15);
        _27663 = NOVALUE;
        if (IS_ATOM_INT(_27664)) {
            _27665 = (_27664 == _53integer_type_46809);
        }
        else {
            _27665 = binary_op(EQUALS, _27664, _53integer_type_46809);
        }
        _27664 = NOVALUE;
        if (IS_ATOM_INT(_27665))
        _27662 = (_27665 != 0);
        else
        _27662 = DBL_PTR(_27665)->dbl != 0.0;
L24: 
        if (_27662 != 0) {
            _27666 = 1;
            goto L25; // [1055] 1095
        }
        _27667 = (_op_54612 == 97);
        if (_27667 == 0) {
            _27668 = 0;
            goto L26; // [1065] 1091
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27669 = (object)*(((s1_ptr)_2)->base + _sym_54621);
        _2 = (object)SEQ_PTR(_27669);
        _27670 = (object)*(((s1_ptr)_2)->base + 15);
        _27669 = NOVALUE;
        if (IS_ATOM_INT(_27670)) {
            _27671 = (_27670 == _53sequence_type_46807);
        }
        else {
            _27671 = binary_op(EQUALS, _27670, _53sequence_type_46807);
        }
        _27670 = NOVALUE;
        if (IS_ATOM_INT(_27671))
        _27668 = (_27671 != 0);
        else
        _27668 = DBL_PTR(_27671)->dbl != 0.0;
L26: 
        _27666 = (_27668 != 0);
L25: 
        if (_27666 != 0) {
            goto L27; // [1095] 1143
        }
        _27673 = (_op_54612 == 101);
        if (_27673 == 0) {
            DeRef(_27674);
            _27674 = 0;
            goto L28; // [1105] 1138
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27675 = (object)*(((s1_ptr)_2)->base + _sym_54621);
        _2 = (object)SEQ_PTR(_27675);
        _27676 = (object)*(((s1_ptr)_2)->base + 15);
        _27675 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _53integer_type_46809;
        ((intptr_t *)_2)[2] = _53atom_type_46805;
        _27677 = MAKE_SEQ(_1);
        _27678 = find_from(_27676, _27677, 1);
        _27676 = NOVALUE;
        DeRefDS(_27677);
        _27677 = NOVALUE;
        _27674 = (_27678 != 0);
L28: 
        if (_27674 == 0)
        {
            _27674 = NOVALUE;
            goto L29; // [1139] 1157
        }
        else{
            _27674 = NOVALUE;
        }
L27: 

        /** inline.e:834							replace_code( {}, check_pc, check_pc+1 )*/
        _27679 = _check_pc_54608 + 1;
        if (_27679 > MAXINT){
            _27679 = NewDouble((eudouble)_27679);
        }
        RefDS(_22015);
        _66replace_code(_22015, _check_pc_54608, _27679);
        _27679 = NOVALUE;
        goto L22; // [1154] 1174
L29: 

        /** inline.e:837							check_pc += 2*/
        _check_pc_54608 = _check_pc_54608 + 2;
        goto L22; // [1164] 1174
L23: 

        /** inline.e:841						check_pc += 2*/
        _check_pc_54608 = _check_pc_54608 + 2;
L22: 

        /** inline.e:843					continue*/
        goto L1A; // [1180] 847

        /** inline.e:844				case STARTLINE then*/
        case 58:

        /** inline.e:845					check_pc += 2*/
        _check_pc_54608 = _check_pc_54608 + 2;

        /** inline.e:846					continue*/
        goto L1A; // [1198] 847

        /** inline.e:848				case else*/
        default:

        /** inline.e:849					exit*/
        goto L1B; // [1208] 1218
    ;}
    /** inline.e:851		end while*/
    goto L1A; // [1215] 847
L1B: 

    /** inline.e:853		for pc = 1 to length( inline_code ) do*/
    if (IS_SEQUENCE(_66inline_code_53477)){
            _27683 = SEQ_PTR(_66inline_code_53477)->length;
    }
    else {
        _27683 = 1;
    }
    {
        object _pc_54699;
        _pc_54699 = 1;
L2A: 
        if (_pc_54699 > _27683){
            goto L2B; // [1225] 1422
        }

        /** inline.e:854			if sequence( inline_code[pc] ) then*/
        _2 = (object)SEQ_PTR(_66inline_code_53477);
        _27684 = (object)*(((s1_ptr)_2)->base + _pc_54699);
        _27685 = IS_SEQUENCE(_27684);
        _27684 = NOVALUE;
        if (_27685 == 0)
        {
            _27685 = NOVALUE;
            goto L2C; // [1243] 1413
        }
        else{
            _27685 = NOVALUE;
        }

        /** inline.e:855				integer inline_type = inline_code[pc][1]*/
        _2 = (object)SEQ_PTR(_66inline_code_53477);
        _27686 = (object)*(((s1_ptr)_2)->base + _pc_54699);
        _2 = (object)SEQ_PTR(_27686);
        _inline_type_54704 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_inline_type_54704)){
            _inline_type_54704 = (object)DBL_PTR(_inline_type_54704)->dbl;
        }
        _27686 = NOVALUE;

        /** inline.e:856				switch inline_type do*/
        _0 = _inline_type_54704;
        switch ( _0 ){ 

            /** inline.e:857					case INLINE_SUB then*/
            case 5:

            /** inline.e:858						inline_code[pc] = CurrentSub*/
            _2 = (object)SEQ_PTR(_66inline_code_53477);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _66inline_code_53477 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_54699);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _12CurrentSub_20234;
            DeRef(_1);
            goto L2D; // [1281] 1412

            /** inline.e:860					case INLINE_VAR then*/
            case 6:

            /** inline.e:861						replace_var( pc )*/
            _66replace_var(_pc_54699);

            /** inline.e:862						break*/
            goto L2D; // [1294] 1412
            goto L2D; // [1296] 1412

            /** inline.e:863					case INLINE_TEMP then*/
            case 2:

            /** inline.e:864						replace_temp( pc )*/
            _66replace_temp(_pc_54699);
            goto L2D; // [1307] 1412

            /** inline.e:866					case INLINE_PARAM then*/
            case 1:

            /** inline.e:867						replace_param( pc )*/

            /** inline.e:586		inline_code[pc] = get_param_sym( pc )*/
            _0 = _replace_param_1__tmp_at1343_54715;
            _replace_param_1__tmp_at1343_54715 = _66get_param_sym(_pc_54699);
            DeRef(_0);
            Ref(_replace_param_1__tmp_at1343_54715);
            _2 = (object)SEQ_PTR(_66inline_code_53477);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _66inline_code_53477 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_54699);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _replace_param_1__tmp_at1343_54715;
            DeRef(_1);

            /** inline.e:587	end procedure*/
            goto L2E; // [1329] 1332
L2E: 
            DeRef(_replace_param_1__tmp_at1343_54715);
            _replace_param_1__tmp_at1343_54715 = NOVALUE;
            goto L2D; // [1334] 1412

            /** inline.e:869					case INLINE_ADDR then*/
            case 4:

            /** inline.e:870						inline_code[pc] = inline_start + inline_code[pc][2]*/
            _2 = (object)SEQ_PTR(_66inline_code_53477);
            _27690 = (object)*(((s1_ptr)_2)->base + _pc_54699);
            _2 = (object)SEQ_PTR(_27690);
            _27691 = (object)*(((s1_ptr)_2)->base + 2);
            _27690 = NOVALUE;
            if (IS_ATOM_INT(_27691)) {
                _27692 = _66inline_start_53489 + _27691;
                if ((object)((uintptr_t)_27692 + (uintptr_t)HIGH_BITS) >= 0){
                    _27692 = NewDouble((eudouble)_27692);
                }
            }
            else {
                _27692 = binary_op(PLUS, _66inline_start_53489, _27691);
            }
            _27691 = NOVALUE;
            _2 = (object)SEQ_PTR(_66inline_code_53477);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _66inline_code_53477 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_54699);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _27692;
            if( _1 != _27692 ){
                DeRef(_1);
            }
            _27692 = NOVALUE;
            goto L2D; // [1364] 1412

            /** inline.e:872					case INLINE_TARGET then*/
            case 3:

            /** inline.e:873						inline_code[pc] = inline_target*/
            _2 = (object)SEQ_PTR(_66inline_code_53477);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _66inline_code_53477 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_54699);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _66inline_target_53484;
            DeRef(_1);

            /** inline.e:874						add_inline_target( pc + inline_start )*/
            _27693 = _pc_54699 + _66inline_start_53489;
            if ((object)((uintptr_t)_27693 + (uintptr_t)HIGH_BITS) >= 0){
                _27693 = NewDouble((eudouble)_27693);
            }
            _45add_inline_target(_27693);
            _27693 = NOVALUE;

            /** inline.e:875						break*/
            goto L2D; // [1393] 1412
            goto L2D; // [1395] 1412

            /** inline.e:877					case else*/
            default:

            /** inline.e:878						InternalErr( 265, {inline_type} )*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t*)_2)[1] = _inline_type_54704;
            _27694 = MAKE_SEQ(_1);
            _49InternalErr(265, _27694);
            _27694 = NOVALUE;
        ;}L2D: 
L2C: 

        /** inline.e:881		end for*/
        _pc_54699 = _pc_54699 + 1;
        goto L2A; // [1417] 1232
L2B: 
        ;
    }

    /** inline.e:883		for i = 1 to length(backpatches) do*/
    if (IS_SEQUENCE(_backpatches_54447)){
            _27695 = SEQ_PTR(_backpatches_54447)->length;
    }
    else {
        _27695 = 1;
    }
    {
        object _i_54727;
        _i_54727 = 1;
L2F: 
        if (_i_54727 > _27695){
            goto L30; // [1427] 1450
        }

        /** inline.e:884			fixup_special_op( backpatches[i] )*/
        _2 = (object)SEQ_PTR(_backpatches_54447);
        _27696 = (object)*(((s1_ptr)_2)->base + _i_54727);
        Ref(_27696);
        _66fixup_special_op(_27696);
        _27696 = NOVALUE;

        /** inline.e:885		end for*/
        _i_54727 = _i_54727 + 1;
        goto L2F; // [1445] 1434
L30: 
        ;
    }

    /** inline.e:887		epilog &= End_inline_block( EXIT_BLOCK )*/
    _27697 = _64End_inline_block(206);
    if (IS_SEQUENCE(_epilog_54454) && IS_ATOM(_27697)) {
        Ref(_27697);
        Append(&_epilog_54454, _epilog_54454, _27697);
    }
    else if (IS_ATOM(_epilog_54454) && IS_SEQUENCE(_27697)) {
    }
    else {
        Concat((object_ptr)&_epilog_54454, _epilog_54454, _27697);
    }
    DeRef(_27697);
    _27697 = NOVALUE;

    /** inline.e:889		if is_proc then*/
    if (_is_proc_54429 == 0)
    {
        goto L31; // [1464] 1474
    }
    else{
    }

    /** inline.e:890			clear_op()*/
    _45clear_op();
    goto L32; // [1471] 1597
L31: 

    /** inline.e:892			if not deferred then*/
    if (_deferred_54428 != 0)
    goto L33; // [1476] 1491

    /** inline.e:893				Push( inline_target )*/
    _45Push(_66inline_target_53484);

    /** inline.e:894				inlined_function()*/
    _45inlined_function();
L33: 

    /** inline.e:897			if final_target then*/
    if (_final_target_54553 == 0)
    {
        goto L34; // [1493] 1523
    }
    else{
    }

    /** inline.e:898				epilog &= { ASSIGN, inline_target, final_target }*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18;
    ((intptr_t*)_2)[2] = _66inline_target_53484;
    ((intptr_t*)_2)[3] = _final_target_54553;
    _27700 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_54454, _epilog_54454, _27700);
    DeRefDS(_27700);
    _27700 = NOVALUE;

    /** inline.e:899				emit_temp( final_target, NEW_REFERENCE )*/
    _45emit_temp(_final_target_54553, 1);
    goto L35; // [1520] 1596
L34: 

    /** inline.e:905				emit_temp( inline_target, NEW_REFERENCE )*/
    _45emit_temp(_66inline_target_53484, 1);

    /** inline.e:906				if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto L36; // [1537] 1595

    /** inline.e:907					epilog &= { ELSE, 0, PRIVATE_INIT_CHECK, inline_target }*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 23;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 30;
    ((intptr_t*)_2)[4] = _66inline_target_53484;
    _27703 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_54454, _epilog_54454, _27703);
    DeRefDS(_27703);
    _27703 = NOVALUE;

    /** inline.e:908					epilog[$-2] = length(inline_code) + length(epilog) + inline_start + 1*/
    if (IS_SEQUENCE(_epilog_54454)){
            _27705 = SEQ_PTR(_epilog_54454)->length;
    }
    else {
        _27705 = 1;
    }
    _27706 = _27705 - 2;
    _27705 = NOVALUE;
    if (IS_SEQUENCE(_66inline_code_53477)){
            _27707 = SEQ_PTR(_66inline_code_53477)->length;
    }
    else {
        _27707 = 1;
    }
    if (IS_SEQUENCE(_epilog_54454)){
            _27708 = SEQ_PTR(_epilog_54454)->length;
    }
    else {
        _27708 = 1;
    }
    _27709 = _27707 + _27708;
    if ((object)((uintptr_t)_27709 + (uintptr_t)HIGH_BITS) >= 0){
        _27709 = NewDouble((eudouble)_27709);
    }
    _27707 = NOVALUE;
    _27708 = NOVALUE;
    if (IS_ATOM_INT(_27709)) {
        _27710 = _27709 + _66inline_start_53489;
        if ((object)((uintptr_t)_27710 + (uintptr_t)HIGH_BITS) >= 0){
            _27710 = NewDouble((eudouble)_27710);
        }
    }
    else {
        _27710 = NewDouble(DBL_PTR(_27709)->dbl + (eudouble)_66inline_start_53489);
    }
    DeRef(_27709);
    _27709 = NOVALUE;
    if (IS_ATOM_INT(_27710)) {
        _27711 = _27710 + 1;
        if (_27711 > MAXINT){
            _27711 = NewDouble((eudouble)_27711);
        }
    }
    else
    _27711 = binary_op(PLUS, 1, _27710);
    DeRef(_27710);
    _27710 = NOVALUE;
    _2 = (object)SEQ_PTR(_epilog_54454);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _epilog_54454 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27706);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27711;
    if( _1 != _27711 ){
        DeRef(_1);
    }
    _27711 = NOVALUE;
L36: 
L35: 
L32: 

    /** inline.e:914		return prolog & inline_code & epilog*/
    {
        object concat_list[3];

        concat_list[0] = _epilog_54454;
        concat_list[1] = _66inline_code_53477;
        concat_list[2] = _prolog_54453;
        Concat_N((object_ptr)&_27712, concat_list, 3);
    }
    DeRef(_backpatches_54447);
    DeRefDSi(_prolog_54453);
    DeRefDS(_epilog_54454);
    DeRef(_27671);
    _27671 = NOVALUE;
    DeRef(_27673);
    _27673 = NOVALUE;
    DeRef(_27706);
    _27706 = NOVALUE;
    DeRef(_27591);
    _27591 = NOVALUE;
    DeRef(_27588);
    _27588 = NOVALUE;
    DeRef(_27617);
    _27617 = NOVALUE;
    _27583 = NOVALUE;
    _27596 = NOVALUE;
    DeRef(_27661);
    _27661 = NOVALUE;
    DeRef(_27620);
    _27620 = NOVALUE;
    DeRef(_27667);
    _27667 = NOVALUE;
    DeRef(_27665);
    _27665 = NOVALUE;
    _27600 = NOVALUE;
    return _27712;
    ;
}


void _66defer_call()
{
    object _defer_54767 = NOVALUE;
    object _27715 = NOVALUE;
    object _27714 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:918		integer defer = find( inline_sub, deferred_inline_decisions )*/
    _defer_54767 = find_from(_66inline_sub_53491, _66deferred_inline_decisions_53493, 1);

    /** inline.e:919		if defer then*/
    if (_defer_54767 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** inline.e:921			deferred_inline_calls[defer] &= CurrentSub*/
    _2 = (object)SEQ_PTR(_66deferred_inline_calls_53494);
    _27714 = (object)*(((s1_ptr)_2)->base + _defer_54767);
    if (IS_SEQUENCE(_27714) && IS_ATOM(_12CurrentSub_20234)) {
        Append(&_27715, _27714, _12CurrentSub_20234);
    }
    else if (IS_ATOM(_27714) && IS_SEQUENCE(_12CurrentSub_20234)) {
    }
    else {
        Concat((object_ptr)&_27715, _27714, _12CurrentSub_20234);
        _27714 = NOVALUE;
    }
    _27714 = NOVALUE;
    _2 = (object)SEQ_PTR(_66deferred_inline_calls_53494);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66deferred_inline_calls_53494 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _defer_54767);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27715;
    if( _1 != _27715 ){
        DeRef(_1);
    }
    _27715 = NOVALUE;
L1: 

    /** inline.e:923	end procedure*/
    return;
    ;
}


void _66emit_or_inline()
{
    object _sub_54776 = NOVALUE;
    object _code_54807 = NOVALUE;
    object _27727 = NOVALUE;
    object _27726 = NOVALUE;
    object _27724 = NOVALUE;
    object _27723 = NOVALUE;
    object _27722 = NOVALUE;
    object _27720 = NOVALUE;
    object _27719 = NOVALUE;
    object _27718 = NOVALUE;
    object _27717 = NOVALUE;
    object _27716 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:928		symtab_index sub = op_info1*/
    _sub_54776 = _45op_info1_50960;

    /** inline.e:929		inline_sub = sub*/
    _66inline_sub_53491 = _sub_54776;

    /** inline.e:931		if SymTab[sub][S_DEPRECATED] then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27716 = (object)*(((s1_ptr)_2)->base + _sub_54776);
    _2 = (object)SEQ_PTR(_27716);
    _27717 = (object)*(((s1_ptr)_2)->base + 30);
    _27716 = NOVALUE;
    if (_27717 == 0) {
        _27717 = NOVALUE;
        goto L1; // [31] 60
    }
    else {
        if (!IS_ATOM_INT(_27717) && DBL_PTR(_27717)->dbl == 0.0){
            _27717 = NOVALUE;
            goto L1; // [31] 60
        }
        _27717 = NOVALUE;
    }
    _27717 = NOVALUE;

    /** inline.e:932			Warning(327, deprecated_warning_flag, { SymTab[sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27718 = (object)*(((s1_ptr)_2)->base + _sub_54776);
    _2 = (object)SEQ_PTR(_27718);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _27719 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _27719 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _27718 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_27719);
    ((intptr_t*)_2)[1] = _27719;
    _27720 = MAKE_SEQ(_1);
    _27719 = NOVALUE;
    _49Warning(327, 16384, _27720);
    _27720 = NOVALUE;
L1: 

    /** inline.e:935		if Parser_mode != PAM_NORMAL then*/
    if (_12Parser_mode_20332 == 0)
    goto L2; // [66] 85

    /** inline.e:938			emit_op( PROC )*/
    _45emit_op(27);

    /** inline.e:939			return*/
    DeRef(_code_54807);
    return;
    goto L3; // [82] 133
L2: 

    /** inline.e:941		elsif atom( SymTab[sub][S_INLINE] ) or has_forward_params(sub) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27722 = (object)*(((s1_ptr)_2)->base + _sub_54776);
    _2 = (object)SEQ_PTR(_27722);
    _27723 = (object)*(((s1_ptr)_2)->base + 29);
    _27722 = NOVALUE;
    _27724 = IS_ATOM(_27723);
    _27723 = NOVALUE;
    if (_27724 != 0) {
        goto L4; // [102] 115
    }
    _27726 = _45has_forward_params(_sub_54776);
    if (_27726 == 0) {
        DeRef(_27726);
        _27726 = NOVALUE;
        goto L5; // [111] 132
    }
    else {
        if (!IS_ATOM_INT(_27726) && DBL_PTR(_27726)->dbl == 0.0){
            DeRef(_27726);
            _27726 = NOVALUE;
            goto L5; // [111] 132
        }
        DeRef(_27726);
        _27726 = NOVALUE;
    }
    DeRef(_27726);
    _27726 = NOVALUE;
L4: 

    /** inline.e:942			defer_call()*/
    _66defer_call();

    /** inline.e:943			emit_op( PROC )*/
    _45emit_op(27);

    /** inline.e:944			return*/
    DeRef(_code_54807);
    return;
L5: 
L3: 

    /** inline.e:947		sequence code = get_inlined_code( sub, length(Code) )*/
    if (IS_SEQUENCE(_12Code_20315)){
            _27727 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _27727 = 1;
    }
    _0 = _code_54807;
    _code_54807 = _66get_inlined_code(_sub_54776, _27727, 0);
    DeRef(_0);
    _27727 = NOVALUE;

    /** inline.e:948		emit_inline( code )*/
    RefDS(_code_54807);
    _45emit_inline(_code_54807);

    /** inline.e:949		clear_last()*/
    _45clear_last();

    /** inline.e:951	end procedure*/
    DeRefDS(_code_54807);
    return;
    ;
}


void _66inline_deferred_calls()
{
    object _sub_54821 = NOVALUE;
    object _ix_54833 = NOVALUE;
    object _calling_sub_54835 = NOVALUE;
    object _code_54857 = NOVALUE;
    object _calls_54858 = NOVALUE;
    object _is_func_54862 = NOVALUE;
    object _offset_54869 = NOVALUE;
    object _op_54880 = NOVALUE;
    object _size_54883 = NOVALUE;
    object _27789 = NOVALUE;
    object _27787 = NOVALUE;
    object _27785 = NOVALUE;
    object _27784 = NOVALUE;
    object _27783 = NOVALUE;
    object _27781 = NOVALUE;
    object _27780 = NOVALUE;
    object _27779 = NOVALUE;
    object _27778 = NOVALUE;
    object _27777 = NOVALUE;
    object _27776 = NOVALUE;
    object _27775 = NOVALUE;
    object _27774 = NOVALUE;
    object _27773 = NOVALUE;
    object _27772 = NOVALUE;
    object _27770 = NOVALUE;
    object _27769 = NOVALUE;
    object _27768 = NOVALUE;
    object _27767 = NOVALUE;
    object _27765 = NOVALUE;
    object _27764 = NOVALUE;
    object _27763 = NOVALUE;
    object _27761 = NOVALUE;
    object _27759 = NOVALUE;
    object _27757 = NOVALUE;
    object _27755 = NOVALUE;
    object _27754 = NOVALUE;
    object _27753 = NOVALUE;
    object _27752 = NOVALUE;
    object _27750 = NOVALUE;
    object _27749 = NOVALUE;
    object _27746 = NOVALUE;
    object _27744 = NOVALUE;
    object _27742 = NOVALUE;
    object _27740 = NOVALUE;
    object _27738 = NOVALUE;
    object _27737 = NOVALUE;
    object _27736 = NOVALUE;
    object _27735 = NOVALUE;
    object _27734 = NOVALUE;
    object _27733 = NOVALUE;
    object _27731 = NOVALUE;
    object _27730 = NOVALUE;
    object _27729 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:957		deferred_inlining = 1*/
    _66deferred_inlining_53487 = 1;

    /** inline.e:958		for i = 1 to length( deferred_inline_decisions ) do*/
    if (IS_SEQUENCE(_66deferred_inline_decisions_53493)){
            _27729 = SEQ_PTR(_66deferred_inline_decisions_53493)->length;
    }
    else {
        _27729 = 1;
    }
    {
        object _i_54816;
        _i_54816 = 1;
L1: 
        if (_i_54816 > _27729){
            goto L2; // [13] 506
        }

        /** inline.e:960			if length( deferred_inline_calls[i] ) then*/
        _2 = (object)SEQ_PTR(_66deferred_inline_calls_53494);
        _27730 = (object)*(((s1_ptr)_2)->base + _i_54816);
        if (IS_SEQUENCE(_27730)){
                _27731 = SEQ_PTR(_27730)->length;
        }
        else {
            _27731 = 1;
        }
        _27730 = NOVALUE;
        if (_27731 == 0)
        {
            _27731 = NOVALUE;
            goto L3; // [31] 497
        }
        else{
            _27731 = NOVALUE;
        }

        /** inline.e:962				integer sub = deferred_inline_decisions[i]*/
        _2 = (object)SEQ_PTR(_66deferred_inline_decisions_53493);
        _sub_54821 = (object)*(((s1_ptr)_2)->base + _i_54816);

        /** inline.e:963				check_inline( sub )*/
        _66check_inline(_sub_54821);

        /** inline.e:964				if atom( SymTab[sub][S_INLINE] ) then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27733 = (object)*(((s1_ptr)_2)->base + _sub_54821);
        _2 = (object)SEQ_PTR(_27733);
        _27734 = (object)*(((s1_ptr)_2)->base + 29);
        _27733 = NOVALUE;
        _27735 = IS_ATOM(_27734);
        _27734 = NOVALUE;
        if (_27735 == 0)
        {
            _27735 = NOVALUE;
            goto L4; // [64] 74
        }
        else{
            _27735 = NOVALUE;
        }

        /** inline.e:965					continue*/
        goto L5; // [71] 501
L4: 

        /** inline.e:967				for cx = 1 to length( deferred_inline_calls[i] ) do*/
        _2 = (object)SEQ_PTR(_66deferred_inline_calls_53494);
        _27736 = (object)*(((s1_ptr)_2)->base + _i_54816);
        if (IS_SEQUENCE(_27736)){
                _27737 = SEQ_PTR(_27736)->length;
        }
        else {
            _27737 = 1;
        }
        _27736 = NOVALUE;
        {
            object _cx_54830;
            _cx_54830 = 1;
L6: 
            if (_cx_54830 > _27737){
                goto L7; // [85] 496
            }

            /** inline.e:968					integer ix = 1*/
            _ix_54833 = 1;

            /** inline.e:969					symtab_index calling_sub = deferred_inline_calls[i][cx]*/
            _2 = (object)SEQ_PTR(_66deferred_inline_calls_53494);
            _27738 = (object)*(((s1_ptr)_2)->base + _i_54816);
            _2 = (object)SEQ_PTR(_27738);
            _calling_sub_54835 = (object)*(((s1_ptr)_2)->base + _cx_54830);
            if (!IS_ATOM_INT(_calling_sub_54835)){
                _calling_sub_54835 = (object)DBL_PTR(_calling_sub_54835)->dbl;
            }
            _27738 = NOVALUE;

            /** inline.e:970					CurrentSub = calling_sub*/
            _12CurrentSub_20234 = _calling_sub_54835;

            /** inline.e:971					Code = SymTab[calling_sub][S_CODE]*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _27740 = (object)*(((s1_ptr)_2)->base + _calling_sub_54835);
            DeRef(_12Code_20315);
            _2 = (object)SEQ_PTR(_27740);
            if (!IS_ATOM_INT(_12S_CODE_19876)){
                _12Code_20315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
            }
            else{
                _12Code_20315 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
            }
            Ref(_12Code_20315);
            _27740 = NOVALUE;

            /** inline.e:972					LineTable = SymTab[calling_sub][S_LINETAB]*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _27742 = (object)*(((s1_ptr)_2)->base + _calling_sub_54835);
            DeRef(_12LineTable_20316);
            _2 = (object)SEQ_PTR(_27742);
            if (!IS_ATOM_INT(_12S_LINETAB_19899)){
                _12LineTable_20316 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
            }
            else{
                _12LineTable_20316 = (object)*(((s1_ptr)_2)->base + _12S_LINETAB_19899);
            }
            Ref(_12LineTable_20316);
            _27742 = NOVALUE;

            /** inline.e:973					SymTab[calling_sub][S_CODE] = 0*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _13SymTab_11316 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_54835 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_12S_CODE_19876))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 0;
            DeRef(_1);
            _27744 = NOVALUE;

            /** inline.e:974					SymTab[calling_sub][S_LINETAB] = 0*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _13SymTab_11316 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_54835 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_12S_LINETAB_19899))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _12S_LINETAB_19899);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 0;
            DeRef(_1);
            _27746 = NOVALUE;

            /** inline.e:975					sequence code = {}*/
            RefDS(_22015);
            DeRef(_code_54857);
            _code_54857 = _22015;

            /** inline.e:977					sequence calls = find_ops( 1, PROC )*/
            RefDS(_12Code_20315);
            _0 = _calls_54858;
            _calls_54858 = _65find_ops(1, 27, _12Code_20315);
            DeRef(_0);

            /** inline.e:978					integer is_func = SymTab[sub][S_TOKEN] != PROC */
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            _27749 = (object)*(((s1_ptr)_2)->base + _sub_54821);
            _2 = (object)SEQ_PTR(_27749);
            if (!IS_ATOM_INT(_12S_TOKEN_19869)){
                _27750 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
            }
            else{
                _27750 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
            }
            _27749 = NOVALUE;
            if (IS_ATOM_INT(_27750)) {
                _is_func_54862 = (_27750 != 27);
            }
            else {
                _is_func_54862 = binary_op(NOTEQ, _27750, 27);
            }
            _27750 = NOVALUE;
            if (!IS_ATOM_INT(_is_func_54862)) {
                _1 = (object)(DBL_PTR(_is_func_54862)->dbl);
                DeRefDS(_is_func_54862);
                _is_func_54862 = _1;
            }

            /** inline.e:979					integer offset = 0*/
            _offset_54869 = 0;

            /** inline.e:980					for o = 1 to length( calls ) do*/
            if (IS_SEQUENCE(_calls_54858)){
                    _27752 = SEQ_PTR(_calls_54858)->length;
            }
            else {
                _27752 = 1;
            }
            {
                object _o_54871;
                _o_54871 = 1;
L8: 
                if (_o_54871 > _27752){
                    goto L9; // [233] 453
                }

                /** inline.e:981						if calls[o][2][2] = sub then*/
                _2 = (object)SEQ_PTR(_calls_54858);
                _27753 = (object)*(((s1_ptr)_2)->base + _o_54871);
                _2 = (object)SEQ_PTR(_27753);
                _27754 = (object)*(((s1_ptr)_2)->base + 2);
                _27753 = NOVALUE;
                _2 = (object)SEQ_PTR(_27754);
                _27755 = (object)*(((s1_ptr)_2)->base + 2);
                _27754 = NOVALUE;
                if (binary_op_a(NOTEQ, _27755, _sub_54821)){
                    _27755 = NOVALUE;
                    goto LA; // [254] 444
                }
                _27755 = NOVALUE;

                /** inline.e:982							ix = calls[o][1]*/
                _2 = (object)SEQ_PTR(_calls_54858);
                _27757 = (object)*(((s1_ptr)_2)->base + _o_54871);
                _2 = (object)SEQ_PTR(_27757);
                _ix_54833 = (object)*(((s1_ptr)_2)->base + 1);
                if (!IS_ATOM_INT(_ix_54833)){
                    _ix_54833 = (object)DBL_PTR(_ix_54833)->dbl;
                }
                _27757 = NOVALUE;

                /** inline.e:983							sequence op = calls[o][2]*/
                _2 = (object)SEQ_PTR(_calls_54858);
                _27759 = (object)*(((s1_ptr)_2)->base + _o_54871);
                DeRef(_op_54880);
                _2 = (object)SEQ_PTR(_27759);
                _op_54880 = (object)*(((s1_ptr)_2)->base + 2);
                Ref(_op_54880);
                _27759 = NOVALUE;

                /** inline.e:984							integer size = length( op ) - 1*/
                if (IS_SEQUENCE(_op_54880)){
                        _27761 = SEQ_PTR(_op_54880)->length;
                }
                else {
                    _27761 = 1;
                }
                _size_54883 = _27761 - 1;
                _27761 = NOVALUE;

                /** inline.e:985							if is_func then*/
                if (_is_func_54862 == 0)
                {
                    goto LB; // [293] 319
                }
                else{
                }

                /** inline.e:987								Push( op[$] )*/
                if (IS_SEQUENCE(_op_54880)){
                        _27763 = SEQ_PTR(_op_54880)->length;
                }
                else {
                    _27763 = 1;
                }
                _2 = (object)SEQ_PTR(_op_54880);
                _27764 = (object)*(((s1_ptr)_2)->base + _27763);
                Ref(_27764);
                _45Push(_27764);
                _27764 = NOVALUE;

                /** inline.e:988								op = remove( op, length(op) )*/
                if (IS_SEQUENCE(_op_54880)){
                        _27765 = SEQ_PTR(_op_54880)->length;
                }
                else {
                    _27765 = 1;
                }
                {
                    s1_ptr assign_space = SEQ_PTR(_op_54880);
                    int len = assign_space->length;
                    int start = (IS_ATOM_INT(_27765)) ? _27765 : (object)(DBL_PTR(_27765)->dbl);
                    int stop = (IS_ATOM_INT(_27765)) ? _27765 : (object)(DBL_PTR(_27765)->dbl);
                    if (stop > len){
                        stop = len;
                    }
                    if (start > len || start > stop || stop<1) {
                    }
                    else if (start < 2) {
                        if (stop >= len) {
                            Head( SEQ_PTR(_op_54880), start, &_op_54880 );
                        }
                        else Tail(SEQ_PTR(_op_54880), stop+1, &_op_54880);
                    }
                    else if (stop >= len){
                        Head(SEQ_PTR(_op_54880), start, &_op_54880);
                    }
                    else {
                        assign_slice_seq = &assign_space;
                        _op_54880 = Remove_elements(start, stop, (SEQ_PTR(_op_54880)->ref == 1));
                    }
                }
                _27765 = NOVALUE;
                _27765 = NOVALUE;
LB: 

                /** inline.e:992							for p = 3 to length( op ) do*/
                if (IS_SEQUENCE(_op_54880)){
                        _27767 = SEQ_PTR(_op_54880)->length;
                }
                else {
                    _27767 = 1;
                }
                {
                    object _p_54893;
                    _p_54893 = 3;
LC: 
                    if (_p_54893 > _27767){
                        goto LD; // [324] 347
                    }

                    /** inline.e:993								Push( op[p] )*/
                    _2 = (object)SEQ_PTR(_op_54880);
                    _27768 = (object)*(((s1_ptr)_2)->base + _p_54893);
                    Ref(_27768);
                    _45Push(_27768);
                    _27768 = NOVALUE;

                    /** inline.e:994							end for*/
                    _p_54893 = _p_54893 + 1;
                    goto LC; // [342] 331
LD: 
                    ;
                }

                /** inline.e:995							code = get_inlined_code( sub, ix + offset - 1, 1 )*/
                _27769 = _ix_54833 + _offset_54869;
                if ((object)((uintptr_t)_27769 + (uintptr_t)HIGH_BITS) >= 0){
                    _27769 = NewDouble((eudouble)_27769);
                }
                if (IS_ATOM_INT(_27769)) {
                    _27770 = _27769 - 1;
                    if ((object)((uintptr_t)_27770 +(uintptr_t) HIGH_BITS) >= 0){
                        _27770 = NewDouble((eudouble)_27770);
                    }
                }
                else {
                    _27770 = NewDouble(DBL_PTR(_27769)->dbl - (eudouble)1);
                }
                DeRef(_27769);
                _27769 = NOVALUE;
                _0 = _code_54857;
                _code_54857 = _66get_inlined_code(_sub_54821, _27770, 1);
                DeRef(_0);
                _27770 = NOVALUE;

                /** inline.e:996							shift:replace_code( repeat( NOP1, length(code) ), ix + offset, ix + offset + size )*/
                if (IS_SEQUENCE(_code_54857)){
                        _27772 = SEQ_PTR(_code_54857)->length;
                }
                else {
                    _27772 = 1;
                }
                _27773 = Repeat(159, _27772);
                _27772 = NOVALUE;
                _27774 = _ix_54833 + _offset_54869;
                if ((object)((uintptr_t)_27774 + (uintptr_t)HIGH_BITS) >= 0){
                    _27774 = NewDouble((eudouble)_27774);
                }
                _27775 = _ix_54833 + _offset_54869;
                if ((object)((uintptr_t)_27775 + (uintptr_t)HIGH_BITS) >= 0){
                    _27775 = NewDouble((eudouble)_27775);
                }
                if (IS_ATOM_INT(_27775)) {
                    _27776 = _27775 + _size_54883;
                    if ((object)((uintptr_t)_27776 + (uintptr_t)HIGH_BITS) >= 0){
                        _27776 = NewDouble((eudouble)_27776);
                    }
                }
                else {
                    _27776 = NewDouble(DBL_PTR(_27775)->dbl + (eudouble)_size_54883);
                }
                DeRef(_27775);
                _27775 = NOVALUE;
                _65replace_code(_27773, _27774, _27776);
                _27773 = NOVALUE;
                _27774 = NOVALUE;
                _27776 = NOVALUE;

                /** inline.e:999							Code = eu:replace( Code, code, ix + offset, ix + offset + length( code ) -1 )*/
                _27777 = _ix_54833 + _offset_54869;
                if ((object)((uintptr_t)_27777 + (uintptr_t)HIGH_BITS) >= 0){
                    _27777 = NewDouble((eudouble)_27777);
                }
                _27778 = _ix_54833 + _offset_54869;
                if ((object)((uintptr_t)_27778 + (uintptr_t)HIGH_BITS) >= 0){
                    _27778 = NewDouble((eudouble)_27778);
                }
                if (IS_SEQUENCE(_code_54857)){
                        _27779 = SEQ_PTR(_code_54857)->length;
                }
                else {
                    _27779 = 1;
                }
                if (IS_ATOM_INT(_27778)) {
                    _27780 = _27778 + _27779;
                    if ((object)((uintptr_t)_27780 + (uintptr_t)HIGH_BITS) >= 0){
                        _27780 = NewDouble((eudouble)_27780);
                    }
                }
                else {
                    _27780 = NewDouble(DBL_PTR(_27778)->dbl + (eudouble)_27779);
                }
                DeRef(_27778);
                _27778 = NOVALUE;
                _27779 = NOVALUE;
                if (IS_ATOM_INT(_27780)) {
                    _27781 = _27780 - 1;
                    if ((object)((uintptr_t)_27781 +(uintptr_t) HIGH_BITS) >= 0){
                        _27781 = NewDouble((eudouble)_27781);
                    }
                }
                else {
                    _27781 = NewDouble(DBL_PTR(_27780)->dbl - (eudouble)1);
                }
                DeRef(_27780);
                _27780 = NOVALUE;
                {
                    intptr_t p1 = _12Code_20315;
                    intptr_t p2 = _code_54857;
                    intptr_t p3 = _27777;
                    intptr_t p4 = _27781;
                    struct replace_block replace_params;
                    replace_params.copy_to   = &p1;
                    replace_params.copy_from = &p2;
                    replace_params.start     = &p3;
                    replace_params.stop      = &p4;
                    replace_params.target    = &_12Code_20315;
                    Replace( &replace_params );
                }
                DeRef(_27777);
                _27777 = NOVALUE;
                DeRef(_27781);
                _27781 = NOVALUE;

                /** inline.e:1000							offset += length(code) - size - 1*/
                if (IS_SEQUENCE(_code_54857)){
                        _27783 = SEQ_PTR(_code_54857)->length;
                }
                else {
                    _27783 = 1;
                }
                _27784 = _27783 - _size_54883;
                if ((object)((uintptr_t)_27784 +(uintptr_t) HIGH_BITS) >= 0){
                    _27784 = NewDouble((eudouble)_27784);
                }
                _27783 = NOVALUE;
                if (IS_ATOM_INT(_27784)) {
                    _27785 = _27784 - 1;
                    if ((object)((uintptr_t)_27785 +(uintptr_t) HIGH_BITS) >= 0){
                        _27785 = NewDouble((eudouble)_27785);
                    }
                }
                else {
                    _27785 = NewDouble(DBL_PTR(_27784)->dbl - (eudouble)1);
                }
                DeRef(_27784);
                _27784 = NOVALUE;
                if (IS_ATOM_INT(_27785)) {
                    _offset_54869 = _offset_54869 + _27785;
                }
                else {
                    _offset_54869 = NewDouble((eudouble)_offset_54869 + DBL_PTR(_27785)->dbl);
                }
                DeRef(_27785);
                _27785 = NOVALUE;
                if (!IS_ATOM_INT(_offset_54869)) {
                    _1 = (object)(DBL_PTR(_offset_54869)->dbl);
                    DeRefDS(_offset_54869);
                    _offset_54869 = _1;
                }
LA: 
                DeRef(_op_54880);
                _op_54880 = NOVALUE;

                /** inline.e:1003					end for*/
                _o_54871 = _o_54871 + 1;
                goto L8; // [448] 240
L9: 
                ;
            }

            /** inline.e:1004					SymTab[calling_sub][S_CODE] = Code*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _13SymTab_11316 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_54835 + ((s1_ptr)_2)->base);
            RefDS(_12Code_20315);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_12S_CODE_19876))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _12Code_20315;
            DeRef(_1);
            _27787 = NOVALUE;

            /** inline.e:1005					SymTab[calling_sub][S_LINETAB] = LineTable*/
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _13SymTab_11316 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_54835 + ((s1_ptr)_2)->base);
            RefDS(_12LineTable_20316);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_12S_LINETAB_19899))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _12S_LINETAB_19899);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _12LineTable_20316;
            DeRef(_1);
            _27789 = NOVALUE;
            DeRef(_code_54857);
            _code_54857 = NOVALUE;
            DeRef(_calls_54858);
            _calls_54858 = NOVALUE;

            /** inline.e:1006				end for*/
            _cx_54830 = _cx_54830 + 1;
            goto L6; // [491] 92
L7: 
            ;
        }
L3: 

        /** inline.e:1008		end for*/
L5: 
        _i_54816 = _i_54816 + 1;
        goto L1; // [501] 20
L2: 
        ;
    }

    /** inline.e:1009	end procedure*/
    _27736 = NOVALUE;
    _27730 = NOVALUE;
    return;
    ;
}



// 0x8C019C12
