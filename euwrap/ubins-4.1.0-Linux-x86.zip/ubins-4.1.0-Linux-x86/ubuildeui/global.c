// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _12set_target_integer_size(object _sizeof_pointer_20062)
{
    object _11314 = NOVALUE;
    object _0, _1, _2;
    

    /** global.e:297		if sizeof_pointer = 4 then*/

    /** global.e:298			TMAXINT = max_int32*/
    DeRef(_12TMAXINT_20056);
    _12TMAXINT_20056 = 1073741823;
    goto L1; // [14] 25

    /** global.e:300			TMAXINT = max_int64*/
    Ref(_12max_int64_20045);
    DeRef(_12TMAXINT_20056);
    _12TMAXINT_20056 = _12max_int64_20045;
L1: 

    /** global.e:303		TMININT = -TMAXINT - 1*/
    if (IS_ATOM_INT(_12TMAXINT_20056)) {
        if ((uintptr_t)_12TMAXINT_20056 == (uintptr_t)HIGH_BITS){
            _11314 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _11314 = - _12TMAXINT_20056;
        }
    }
    else {
        _11314 = unary_op(UMINUS, _12TMAXINT_20056);
    }
    DeRef(_12TMININT_20057);
    if (IS_ATOM_INT(_11314)) {
        _12TMININT_20057 = _11314 - 1;
        if ((object)((uintptr_t)_12TMININT_20057 +(uintptr_t) HIGH_BITS) >= 0){
            _12TMININT_20057 = NewDouble((eudouble)_12TMININT_20057);
        }
    }
    else {
        _12TMININT_20057 = NewDouble(DBL_PTR(_11314)->dbl - (eudouble)1);
    }
    DeRef(_11314);
    _11314 = NOVALUE;

    /** global.e:304		TMAXINT_DBL = TMAXINT*/
    Ref(_12TMAXINT_20056);
    DeRef(_12TMAXINT_DBL_20059);
    _12TMAXINT_DBL_20059 = _12TMAXINT_20056;

    /** global.e:305		TMININT_DBL = TMININT*/
    Ref(_12TMININT_20057);
    DeRef(_12TMININT_DBL_20058);
    _12TMININT_DBL_20058 = _12TMININT_20057;

    /** global.e:306	end procedure*/
    return;
    ;
}


object _12is_integer(object _o_20070)
{
    object _11322 = NOVALUE;
    object _11321 = NOVALUE;
    object _11320 = NOVALUE;
    object _11318 = NOVALUE;
    object _11316 = NOVALUE;
    object _0, _1, _2;
    

    /** global.e:310		if not atom( o ) then*/
    _11316 = IS_ATOM(_o_20070);
    if (_11316 != 0)
    goto L1; // [6] 16
    _11316 = NOVALUE;

    /** global.e:311			return 0*/
    DeRef(_o_20070);
    return 0;
L1: 

    /** global.e:314		if o = floor( o ) then*/
    if (IS_ATOM_INT(_o_20070))
    _11318 = e_floor(_o_20070);
    else
    _11318 = unary_op(FLOOR, _o_20070);
    if (binary_op_a(NOTEQ, _o_20070, _11318)){
        DeRef(_11318);
        _11318 = NOVALUE;
        goto L2; // [21] 55
    }
    DeRef(_11318);
    _11318 = NOVALUE;

    /** global.e:315			if o <= TMAXINT and o >= TMININT then*/
    if (IS_ATOM_INT(_o_20070) && IS_ATOM_INT(_12TMAXINT_20056)) {
        _11320 = (_o_20070 <= _12TMAXINT_20056);
    }
    else {
        _11320 = binary_op(LESSEQ, _o_20070, _12TMAXINT_20056);
    }
    if (IS_ATOM_INT(_11320)) {
        if (_11320 == 0) {
            goto L3; // [33] 54
        }
    }
    else {
        if (DBL_PTR(_11320)->dbl == 0.0) {
            goto L3; // [33] 54
        }
    }
    if (IS_ATOM_INT(_o_20070) && IS_ATOM_INT(_12TMININT_20057)) {
        _11322 = (_o_20070 >= _12TMININT_20057);
    }
    else {
        _11322 = binary_op(GREATEREQ, _o_20070, _12TMININT_20057);
    }
    if (_11322 == 0) {
        DeRef(_11322);
        _11322 = NOVALUE;
        goto L3; // [44] 54
    }
    else {
        if (!IS_ATOM_INT(_11322) && DBL_PTR(_11322)->dbl == 0.0){
            DeRef(_11322);
            _11322 = NOVALUE;
            goto L3; // [44] 54
        }
        DeRef(_11322);
        _11322 = NOVALUE;
    }
    DeRef(_11322);
    _11322 = NOVALUE;

    /** global.e:316				return 1*/
    DeRef(_o_20070);
    DeRef(_11320);
    _11320 = NOVALUE;
    return 1;
L3: 
L2: 

    /** global.e:319		return 0*/
    DeRef(_o_20070);
    DeRef(_11320);
    _11320 = NOVALUE;
    return 0;
    ;
}


object _12symtab_index(object _x_20094)
{
    object _11338 = NOVALUE;
    object _11337 = NOVALUE;
    object _11336 = NOVALUE;
    object _11335 = NOVALUE;
    object _11334 = NOVALUE;
    object _11333 = NOVALUE;
    object _11331 = NOVALUE;
    object _0, _1, _2;
    

    /** global.e:337		if x = 0 then*/
    if (_x_20094 != 0)
    goto L1; // [5] 18

    /** global.e:338			return TRUE -- NULL value*/
    return _9TRUE_446;
L1: 

    /** global.e:340		if x < 0 or x > length(SymTab) then*/
    _11331 = (_x_20094 < 0);
    if (_11331 != 0) {
        goto L2; // [24] 42
    }
    if (IS_SEQUENCE(_13SymTab_11316)){
            _11333 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _11333 = 1;
    }
    _11334 = (_x_20094 > _11333);
    _11333 = NOVALUE;
    if (_11334 == 0)
    {
        DeRef(_11334);
        _11334 = NOVALUE;
        goto L3; // [38] 51
    }
    else{
        DeRef(_11334);
        _11334 = NOVALUE;
    }
L2: 

    /** global.e:341			return FALSE*/
    DeRef(_11331);
    _11331 = NOVALUE;
    return _9FALSE_444;
L3: 

    /** global.e:343		return find(length(SymTab[x]), {SIZEOF_VAR_ENTRY, SIZEOF_ROUTINE_ENTRY,*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _11335 = (object)*(((s1_ptr)_2)->base + _x_20094);
    if (IS_SEQUENCE(_11335)){
            _11336 = SEQ_PTR(_11335)->length;
    }
    else {
        _11336 = 1;
    }
    _11335 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _12SIZEOF_VAR_ENTRY_19993;
    ((intptr_t*)_2)[2] = _12SIZEOF_ROUTINE_ENTRY_19990;
    ((intptr_t*)_2)[3] = _12SIZEOF_TEMP_ENTRY_19999;
    ((intptr_t*)_2)[4] = _12SIZEOF_BLOCK_ENTRY_19996;
    _11337 = MAKE_SEQ(_1);
    _11338 = find_from(_11336, _11337, 1);
    _11336 = NOVALUE;
    DeRefDS(_11337);
    _11337 = NOVALUE;
    DeRef(_11331);
    _11331 = NOVALUE;
    _11335 = NOVALUE;
    return _11338;
    ;
}



// 0x6122A032
