// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _15isLeap(object _year_8884)
{
    object _ly_8885 = NOVALUE;
    object _4918 = NOVALUE;
    object _4917 = NOVALUE;
    object _4916 = NOVALUE;
    object _4915 = NOVALUE;
    object _4914 = NOVALUE;
    object _4913 = NOVALUE;
    object _4912 = NOVALUE;
    object _4911 = NOVALUE;
    object _4910 = NOVALUE;
    object _4907 = NOVALUE;
    object _4905 = NOVALUE;
    object _4904 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:89			ly = (remainder(year, {4, 100, 400, 3200, 80000})=0)*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 4;
    ((intptr_t*)_2)[2] = 100;
    ((intptr_t*)_2)[3] = 400;
    ((intptr_t*)_2)[4] = 3200;
    ((intptr_t*)_2)[5] = 80000;
    _4904 = MAKE_SEQ(_1);
    _4905 = binary_op(REMAINDER, _year_8884, _4904);
    DeRefDS(_4904);
    _4904 = NOVALUE;
    DeRefi(_ly_8885);
    _ly_8885 = binary_op(EQUALS, _4905, 0);
    DeRefDS(_4905);
    _4905 = NOVALUE;

    /** datetime.e:91			if not ly[1] then return 0 end if*/
    _2 = (object)SEQ_PTR(_ly_8885);
    _4907 = (object)*(((s1_ptr)_2)->base + 1);
    if (_4907 != 0)
    goto L1; // [29] 37
    _4907 = NOVALUE;
    DeRefDSi(_ly_8885);
    return 0;
L1: 

    /** datetime.e:93			if year <= Gregorian_Reformation then*/
    if (_year_8884 > 1752)
    goto L2; // [39] 52

    /** datetime.e:94					return 1 -- ly[1] can't possibly be 0 here so set shortcut as '1'.*/
    DeRefi(_ly_8885);
    return 1;
    goto L3; // [49] 95
L2: 

    /** datetime.e:96					return ly[1] - ly[2] + ly[3] - ly[4] + ly[5]*/
    _2 = (object)SEQ_PTR(_ly_8885);
    _4910 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_ly_8885);
    _4911 = (object)*(((s1_ptr)_2)->base + 2);
    _4912 = _4910 - _4911;
    if ((object)((uintptr_t)_4912 +(uintptr_t) HIGH_BITS) >= 0){
        _4912 = NewDouble((eudouble)_4912);
    }
    _4910 = NOVALUE;
    _4911 = NOVALUE;
    _2 = (object)SEQ_PTR(_ly_8885);
    _4913 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_4912)) {
        _4914 = _4912 + _4913;
        if ((object)((uintptr_t)_4914 + (uintptr_t)HIGH_BITS) >= 0){
            _4914 = NewDouble((eudouble)_4914);
        }
    }
    else {
        _4914 = NewDouble(DBL_PTR(_4912)->dbl + (eudouble)_4913);
    }
    DeRef(_4912);
    _4912 = NOVALUE;
    _4913 = NOVALUE;
    _2 = (object)SEQ_PTR(_ly_8885);
    _4915 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_4914)) {
        _4916 = _4914 - _4915;
        if ((object)((uintptr_t)_4916 +(uintptr_t) HIGH_BITS) >= 0){
            _4916 = NewDouble((eudouble)_4916);
        }
    }
    else {
        _4916 = NewDouble(DBL_PTR(_4914)->dbl - (eudouble)_4915);
    }
    DeRef(_4914);
    _4914 = NOVALUE;
    _4915 = NOVALUE;
    _2 = (object)SEQ_PTR(_ly_8885);
    _4917 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_4916)) {
        _4918 = _4916 + _4917;
        if ((object)((uintptr_t)_4918 + (uintptr_t)HIGH_BITS) >= 0){
            _4918 = NewDouble((eudouble)_4918);
        }
    }
    else {
        _4918 = NewDouble(DBL_PTR(_4916)->dbl + (eudouble)_4917);
    }
    DeRef(_4916);
    _4916 = NOVALUE;
    _4917 = NOVALUE;
    DeRefDSi(_ly_8885);
    return _4918;
L3: 
    ;
}


object _15daysInMonth(object _year_8909, object _month_8910)
{
    object _4926 = NOVALUE;
    object _4925 = NOVALUE;
    object _4924 = NOVALUE;
    object _4923 = NOVALUE;
    object _4921 = NOVALUE;
    object _4920 = NOVALUE;
    object _4919 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_month_8910)) {
        _1 = (object)(DBL_PTR(_month_8910)->dbl);
        DeRefDS(_month_8910);
        _month_8910 = _1;
    }

    /** datetime.e:101		if year = Gregorian_Reformation and month = 9 then*/
    _4919 = (_year_8909 == 1752);
    if (_4919 == 0) {
        goto L1; // [11] 32
    }
    _4921 = (_month_8910 == 9);
    if (_4921 == 0)
    {
        DeRef(_4921);
        _4921 = NOVALUE;
        goto L1; // [20] 32
    }
    else{
        DeRef(_4921);
        _4921 = NOVALUE;
    }

    /** datetime.e:102			return 19*/
    DeRef(_4919);
    _4919 = NOVALUE;
    return 19;
    goto L2; // [29] 70
L1: 

    /** datetime.e:103		elsif month != 2 then*/
    if (_month_8910 == 2)
    goto L3; // [34] 51

    /** datetime.e:104			return DaysPerMonth[month]*/
    _2 = (object)SEQ_PTR(_15DaysPerMonth_8867);
    _4923 = (object)*(((s1_ptr)_2)->base + _month_8910);
    Ref(_4923);
    DeRef(_4919);
    _4919 = NOVALUE;
    return _4923;
    goto L2; // [48] 70
L3: 

    /** datetime.e:106			return DaysPerMonth[month] + isLeap(year)*/
    _2 = (object)SEQ_PTR(_15DaysPerMonth_8867);
    _4924 = (object)*(((s1_ptr)_2)->base + _month_8910);
    _4925 = _15isLeap(_year_8909);
    if (IS_ATOM_INT(_4924) && IS_ATOM_INT(_4925)) {
        _4926 = _4924 + _4925;
        if ((object)((uintptr_t)_4926 + (uintptr_t)HIGH_BITS) >= 0){
            _4926 = NewDouble((eudouble)_4926);
        }
    }
    else {
        _4926 = binary_op(PLUS, _4924, _4925);
    }
    _4924 = NOVALUE;
    DeRef(_4925);
    _4925 = NOVALUE;
    DeRef(_4919);
    _4919 = NOVALUE;
    _4923 = NOVALUE;
    return _4926;
L2: 
    ;
}


object _15julianDayOfYear(object _ymd_8933)
{
    object _year_8934 = NOVALUE;
    object _month_8935 = NOVALUE;
    object _day_8936 = NOVALUE;
    object _d_8937 = NOVALUE;
    object _4942 = NOVALUE;
    object _4941 = NOVALUE;
    object _4940 = NOVALUE;
    object _4937 = NOVALUE;
    object _4936 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:124		year = ymd[1]*/
    _2 = (object)SEQ_PTR(_ymd_8933);
    _year_8934 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_year_8934)){
        _year_8934 = (object)DBL_PTR(_year_8934)->dbl;
    }

    /** datetime.e:125		month = ymd[2]*/
    _2 = (object)SEQ_PTR(_ymd_8933);
    _month_8935 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_month_8935)){
        _month_8935 = (object)DBL_PTR(_month_8935)->dbl;
    }

    /** datetime.e:126		day = ymd[3]*/
    _2 = (object)SEQ_PTR(_ymd_8933);
    _day_8936 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_day_8936)){
        _day_8936 = (object)DBL_PTR(_day_8936)->dbl;
    }

    /** datetime.e:128		if month = 1 then return day end if*/
    if (_month_8935 != 1)
    goto L1; // [27] 36
    DeRef(_ymd_8933);
    return _day_8936;
L1: 

    /** datetime.e:130		d = 0*/
    _d_8937 = 0;

    /** datetime.e:131		for i = 1 to month - 1 do*/
    _4936 = _month_8935 - 1;
    if ((object)((uintptr_t)_4936 +(uintptr_t) HIGH_BITS) >= 0){
        _4936 = NewDouble((eudouble)_4936);
    }
    {
        object _i_8944;
        _i_8944 = 1;
L2: 
        if (binary_op_a(GREATER, _i_8944, _4936)){
            goto L3; // [47] 74
        }

        /** datetime.e:132			d += daysInMonth(year, i)*/
        Ref(_i_8944);
        _4937 = _15daysInMonth(_year_8934, _i_8944);
        if (IS_ATOM_INT(_4937)) {
            _d_8937 = _d_8937 + _4937;
        }
        else {
            _d_8937 = binary_op(PLUS, _d_8937, _4937);
        }
        DeRef(_4937);
        _4937 = NOVALUE;
        if (!IS_ATOM_INT(_d_8937)) {
            _1 = (object)(DBL_PTR(_d_8937)->dbl);
            DeRefDS(_d_8937);
            _d_8937 = _1;
        }

        /** datetime.e:133		end for*/
        _0 = _i_8944;
        if (IS_ATOM_INT(_i_8944)) {
            _i_8944 = _i_8944 + 1;
            if ((object)((uintptr_t)_i_8944 +(uintptr_t) HIGH_BITS) >= 0){
                _i_8944 = NewDouble((eudouble)_i_8944);
            }
        }
        else {
            _i_8944 = binary_op_a(PLUS, _i_8944, 1);
        }
        DeRef(_0);
        goto L2; // [69] 54
L3: 
        ;
        DeRef(_i_8944);
    }

    /** datetime.e:135		d += day*/
    _d_8937 = _d_8937 + _day_8936;

    /** datetime.e:137		if year = Gregorian_Reformation and month = 9 then*/
    _4940 = (_year_8934 == 1752);
    if (_4940 == 0) {
        goto L4; // [86] 128
    }
    _4942 = (_month_8935 == 9);
    if (_4942 == 0)
    {
        DeRef(_4942);
        _4942 = NOVALUE;
        goto L4; // [95] 128
    }
    else{
        DeRef(_4942);
        _4942 = NOVALUE;
    }

    /** datetime.e:138			if day > 13 then*/
    if (_day_8936 <= 13)
    goto L5; // [100] 113

    /** datetime.e:139				d -= 11*/
    _d_8937 = _d_8937 - 11;
    goto L6; // [110] 127
L5: 

    /** datetime.e:140			elsif day > 2 then*/
    if (_day_8936 <= 2)
    goto L7; // [115] 126

    /** datetime.e:141				return 0*/
    DeRef(_ymd_8933);
    DeRef(_4936);
    _4936 = NOVALUE;
    DeRef(_4940);
    _4940 = NOVALUE;
    return 0;
L7: 
L6: 
L4: 

    /** datetime.e:145		return d*/
    DeRef(_ymd_8933);
    DeRef(_4936);
    _4936 = NOVALUE;
    DeRef(_4940);
    _4940 = NOVALUE;
    return _d_8937;
    ;
}


object _15julianDay(object _ymd_8960)
{
    object _year_8961 = NOVALUE;
    object _j_8962 = NOVALUE;
    object _greg00_8963 = NOVALUE;
    object _4971 = NOVALUE;
    object _4968 = NOVALUE;
    object _4965 = NOVALUE;
    object _4964 = NOVALUE;
    object _4963 = NOVALUE;
    object _4962 = NOVALUE;
    object _4961 = NOVALUE;
    object _4960 = NOVALUE;
    object _4959 = NOVALUE;
    object _4958 = NOVALUE;
    object _4956 = NOVALUE;
    object _4955 = NOVALUE;
    object _4954 = NOVALUE;
    object _4953 = NOVALUE;
    object _4952 = NOVALUE;
    object _4951 = NOVALUE;
    object _4950 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:152		year = ymd[1]*/
    _2 = (object)SEQ_PTR(_ymd_8960);
    _year_8961 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_year_8961)){
        _year_8961 = (object)DBL_PTR(_year_8961)->dbl;
    }

    /** datetime.e:153		j = julianDayOfYear(ymd)*/
    Ref(_ymd_8960);
    _j_8962 = _15julianDayOfYear(_ymd_8960);
    if (!IS_ATOM_INT(_j_8962)) {
        _1 = (object)(DBL_PTR(_j_8962)->dbl);
        DeRefDS(_j_8962);
        _j_8962 = _1;
    }

    /** datetime.e:155		year  -= 1*/
    _year_8961 = _year_8961 - 1;

    /** datetime.e:156		greg00 = year - Gregorian_Reformation00*/
    _greg00_8963 = _year_8961 - 1700;

    /** datetime.e:158		j += (*/
    if (_year_8961 <= INT15 && _year_8961 >= -INT15){
        _4950 = 365 * _year_8961;
    }
    else{
        _4950 = NewDouble(365 * (eudouble)_year_8961);
    }
    if (4 > 0 && _year_8961 >= 0) {
        _4951 = _year_8961 / 4;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_year_8961 / (eudouble)4);
        _4951 = (object)temp_dbl;
    }
    if (IS_ATOM_INT(_4950)) {
        _4952 = _4950 + _4951;
        if ((object)((uintptr_t)_4952 + (uintptr_t)HIGH_BITS) >= 0){
            _4952 = NewDouble((eudouble)_4952);
        }
    }
    else {
        _4952 = NewDouble(DBL_PTR(_4950)->dbl + (eudouble)_4951);
    }
    DeRef(_4950);
    _4950 = NOVALUE;
    _4951 = NOVALUE;
    _4953 = (_greg00_8963 > 0);
    if (100 > 0 && _greg00_8963 >= 0) {
        _4954 = _greg00_8963 / 100;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_greg00_8963 / (eudouble)100);
        _4954 = (object)temp_dbl;
    }
    _4955 = - _4954;
    _4956 = (_greg00_8963 % 400) ? NewDouble((eudouble)_greg00_8963 / 400) : (_greg00_8963 / 400);
    if (IS_ATOM_INT(_4956)) {
        _4958 = NewDouble((eudouble)_4956 + DBL_PTR(_4957)->dbl);
    }
    else {
        _4958 = NewDouble(DBL_PTR(_4956)->dbl + DBL_PTR(_4957)->dbl);
    }
    DeRef(_4956);
    _4956 = NOVALUE;
    _4959 = unary_op(FLOOR, _4958);
    DeRefDS(_4958);
    _4958 = NOVALUE;
    if (IS_ATOM_INT(_4959)) {
        _4960 = _4955 + _4959;
        if ((object)((uintptr_t)_4960 + (uintptr_t)HIGH_BITS) >= 0){
            _4960 = NewDouble((eudouble)_4960);
        }
    }
    else {
        _4960 = binary_op(PLUS, _4955, _4959);
    }
    _4955 = NOVALUE;
    DeRef(_4959);
    _4959 = NOVALUE;
    if (IS_ATOM_INT(_4960)) {
        if (_4960 <= INT15 && _4960 >= -INT15){
            _4961 = _4953 * _4960;
        }
        else{
            _4961 = NewDouble(_4953 * (eudouble)_4960);
        }
    }
    else {
        _4961 = binary_op(MULTIPLY, _4953, _4960);
    }
    _4953 = NOVALUE;
    DeRef(_4960);
    _4960 = NOVALUE;
    if (IS_ATOM_INT(_4952) && IS_ATOM_INT(_4961)) {
        _4962 = _4952 + _4961;
        if ((object)((uintptr_t)_4962 + (uintptr_t)HIGH_BITS) >= 0){
            _4962 = NewDouble((eudouble)_4962);
        }
    }
    else {
        _4962 = binary_op(PLUS, _4952, _4961);
    }
    DeRef(_4952);
    _4952 = NOVALUE;
    DeRef(_4961);
    _4961 = NOVALUE;
    _4963 = (_year_8961 >= 1752);
    _4964 = 11 * _4963;
    _4963 = NOVALUE;
    if (IS_ATOM_INT(_4962)) {
        _4965 = _4962 - _4964;
        if ((object)((uintptr_t)_4965 +(uintptr_t) HIGH_BITS) >= 0){
            _4965 = NewDouble((eudouble)_4965);
        }
    }
    else {
        _4965 = binary_op(MINUS, _4962, _4964);
    }
    DeRef(_4962);
    _4962 = NOVALUE;
    _4964 = NOVALUE;
    if (IS_ATOM_INT(_4965)) {
        _j_8962 = _j_8962 + _4965;
    }
    else {
        _j_8962 = binary_op(PLUS, _j_8962, _4965);
    }
    DeRef(_4965);
    _4965 = NOVALUE;
    if (!IS_ATOM_INT(_j_8962)) {
        _1 = (object)(DBL_PTR(_j_8962)->dbl);
        DeRefDS(_j_8962);
        _j_8962 = _1;
    }

    /** datetime.e:169		if year >= 3200 then*/
    if (_year_8961 < 3200)
    goto L1; // [97] 133

    /** datetime.e:170			j -= floor(year/ 3200)*/
    if (3200 > 0 && _year_8961 >= 0) {
        _4968 = _year_8961 / 3200;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_year_8961 / (eudouble)3200);
        _4968 = (object)temp_dbl;
    }
    _j_8962 = _j_8962 - _4968;
    _4968 = NOVALUE;

    /** datetime.e:171			if year >= 80000 then*/
    if (_year_8961 < 80000)
    goto L2; // [115] 132

    /** datetime.e:172				j += floor(year/80000)*/
    if (80000 > 0 && _year_8961 >= 0) {
        _4971 = _year_8961 / 80000;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_year_8961 / (eudouble)80000);
        _4971 = (object)temp_dbl;
    }
    _j_8962 = _j_8962 + _4971;
    _4971 = NOVALUE;
L2: 
L1: 

    /** datetime.e:176		return j*/
    DeRef(_ymd_8960);
    DeRef(_4954);
    _4954 = NOVALUE;
    return _j_8962;
    ;
}


object _15datetimeToSeconds(object _dt_9049)
{
    object _5014 = NOVALUE;
    object _5013 = NOVALUE;
    object _5012 = NOVALUE;
    object _5011 = NOVALUE;
    object _5010 = NOVALUE;
    object _5009 = NOVALUE;
    object _5008 = NOVALUE;
    object _5007 = NOVALUE;
    object _5006 = NOVALUE;
    object _5005 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:226		return julianDay(dt) * DayLengthInSeconds + (dt[4] * 60 + dt[5]) * 60 + dt[6]*/
    Ref(_dt_9049);
    _5005 = _15julianDay(_dt_9049);
    if (IS_ATOM_INT(_5005)) {
        _5006 = NewDouble(_5005 * (eudouble)86400);
    }
    else {
        _5006 = binary_op(MULTIPLY, _5005, 86400);
    }
    DeRef(_5005);
    _5005 = NOVALUE;
    _2 = (object)SEQ_PTR(_dt_9049);
    _5007 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_5007)) {
        if (_5007 == (short)_5007){
            _5008 = _5007 * 60;
        }
        else{
            _5008 = NewDouble(_5007 * (eudouble)60);
        }
    }
    else {
        _5008 = binary_op(MULTIPLY, _5007, 60);
    }
    _5007 = NOVALUE;
    _2 = (object)SEQ_PTR(_dt_9049);
    _5009 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_5008) && IS_ATOM_INT(_5009)) {
        _5010 = _5008 + _5009;
        if ((object)((uintptr_t)_5010 + (uintptr_t)HIGH_BITS) >= 0){
            _5010 = NewDouble((eudouble)_5010);
        }
    }
    else {
        _5010 = binary_op(PLUS, _5008, _5009);
    }
    DeRef(_5008);
    _5008 = NOVALUE;
    _5009 = NOVALUE;
    if (IS_ATOM_INT(_5010)) {
        if (_5010 == (short)_5010){
            _5011 = _5010 * 60;
        }
        else{
            _5011 = NewDouble(_5010 * (eudouble)60);
        }
    }
    else {
        _5011 = binary_op(MULTIPLY, _5010, 60);
    }
    DeRef(_5010);
    _5010 = NOVALUE;
    if (IS_ATOM_INT(_5006) && IS_ATOM_INT(_5011)) {
        _5012 = _5006 + _5011;
        if ((object)((uintptr_t)_5012 + (uintptr_t)HIGH_BITS) >= 0){
            _5012 = NewDouble((eudouble)_5012);
        }
    }
    else {
        _5012 = binary_op(PLUS, _5006, _5011);
    }
    DeRef(_5006);
    _5006 = NOVALUE;
    DeRef(_5011);
    _5011 = NOVALUE;
    _2 = (object)SEQ_PTR(_dt_9049);
    _5013 = (object)*(((s1_ptr)_2)->base + 6);
    if (IS_ATOM_INT(_5012) && IS_ATOM_INT(_5013)) {
        _5014 = _5012 + _5013;
        if ((object)((uintptr_t)_5014 + (uintptr_t)HIGH_BITS) >= 0){
            _5014 = NewDouble((eudouble)_5014);
        }
    }
    else {
        _5014 = binary_op(PLUS, _5012, _5013);
    }
    DeRef(_5012);
    _5012 = NOVALUE;
    _5013 = NOVALUE;
    DeRef(_dt_9049);
    return _5014;
    ;
}


object _15from_date(object _src_9213)
{
    object _5127 = NOVALUE;
    object _5126 = NOVALUE;
    object _5125 = NOVALUE;
    object _5124 = NOVALUE;
    object _5123 = NOVALUE;
    object _5122 = NOVALUE;
    object _5121 = NOVALUE;
    object _5119 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:513		return {src[YEAR]+1900, src[MONTH], src[DAY], src[HOUR], src[MINUTE], src[SECOND]}*/
    _2 = (object)SEQ_PTR(_src_9213);
    _5119 = (object)*(((s1_ptr)_2)->base + 1);
    _5121 = _5119 + 1900;
    if ((object)((uintptr_t)_5121 + (uintptr_t)HIGH_BITS) >= 0){
        _5121 = NewDouble((eudouble)_5121);
    }
    _5119 = NOVALUE;
    _2 = (object)SEQ_PTR(_src_9213);
    _5122 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_src_9213);
    _5123 = (object)*(((s1_ptr)_2)->base + 3);
    _2 = (object)SEQ_PTR(_src_9213);
    _5124 = (object)*(((s1_ptr)_2)->base + 4);
    _2 = (object)SEQ_PTR(_src_9213);
    _5125 = (object)*(((s1_ptr)_2)->base + 5);
    _2 = (object)SEQ_PTR(_src_9213);
    _5126 = (object)*(((s1_ptr)_2)->base + 6);
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _5121;
    ((intptr_t*)_2)[2] = _5122;
    ((intptr_t*)_2)[3] = _5123;
    ((intptr_t*)_2)[4] = _5124;
    ((intptr_t*)_2)[5] = _5125;
    ((intptr_t*)_2)[6] = _5126;
    _5127 = MAKE_SEQ(_1);
    _5126 = NOVALUE;
    _5125 = NOVALUE;
    _5124 = NOVALUE;
    _5123 = NOVALUE;
    _5122 = NOVALUE;
    _5121 = NOVALUE;
    DeRefDSi(_src_9213);
    return _5127;
    ;
}


object _15new(object _year_9245, object _month_9246, object _day_9247, object _hour_9248, object _minute_9249, object _second_9250)
{
    object _d_9251 = NOVALUE;
    object _now_1__tmp_at41_9258 = NOVALUE;
    object _now_inlined_now_at_41_9257 = NOVALUE;
    object _5142 = NOVALUE;
    object _5141 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_year_9245)) {
        _1 = (object)(DBL_PTR(_year_9245)->dbl);
        DeRefDS(_year_9245);
        _year_9245 = _1;
    }
    if (!IS_ATOM_INT(_month_9246)) {
        _1 = (object)(DBL_PTR(_month_9246)->dbl);
        DeRefDS(_month_9246);
        _month_9246 = _1;
    }
    if (!IS_ATOM_INT(_day_9247)) {
        _1 = (object)(DBL_PTR(_day_9247)->dbl);
        DeRefDS(_day_9247);
        _day_9247 = _1;
    }
    if (!IS_ATOM_INT(_hour_9248)) {
        _1 = (object)(DBL_PTR(_hour_9248)->dbl);
        DeRefDS(_hour_9248);
        _hour_9248 = _1;
    }
    if (!IS_ATOM_INT(_minute_9249)) {
        _1 = (object)(DBL_PTR(_minute_9249)->dbl);
        DeRefDS(_minute_9249);
        _minute_9249 = _1;
    }

    /** datetime.e:587		d = {year, month, day, hour, minute, second}*/
    _0 = _d_9251;
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _year_9245;
    ((intptr_t*)_2)[2] = _month_9246;
    ((intptr_t*)_2)[3] = _day_9247;
    ((intptr_t*)_2)[4] = _hour_9248;
    ((intptr_t*)_2)[5] = _minute_9249;
    Ref(_second_9250);
    ((intptr_t*)_2)[6] = _second_9250;
    _d_9251 = MAKE_SEQ(_1);
    DeRef(_0);

    /** datetime.e:588		if equal(d, {0,0,0,0,0,0}) then*/
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 0;
    ((intptr_t*)_2)[4] = 0;
    ((intptr_t*)_2)[5] = 0;
    ((intptr_t*)_2)[6] = 0;
    _5141 = MAKE_SEQ(_1);
    if (_d_9251 == _5141)
    _5142 = 1;
    else if (IS_ATOM_INT(_d_9251) && IS_ATOM_INT(_5141))
    _5142 = 0;
    else
    _5142 = (compare(_d_9251, _5141) == 0);
    DeRefDS(_5141);
    _5141 = NOVALUE;
    if (_5142 == 0)
    {
        _5142 = NOVALUE;
        goto L1; // [37] 60
    }
    else{
        _5142 = NOVALUE;
    }

    /** datetime.e:589			return now()*/

    /** datetime.e:533		return from_date(date())*/
    DeRefi(_now_1__tmp_at41_9258);
    _now_1__tmp_at41_9258 = Date();
    RefDS(_now_1__tmp_at41_9258);
    _0 = _now_inlined_now_at_41_9257;
    _now_inlined_now_at_41_9257 = _15from_date(_now_1__tmp_at41_9258);
    DeRef(_0);
    DeRefi(_now_1__tmp_at41_9258);
    _now_1__tmp_at41_9258 = NOVALUE;
    DeRef(_second_9250);
    DeRef(_d_9251);
    return _now_inlined_now_at_41_9257;
    goto L2; // [57] 67
L1: 

    /** datetime.e:591			return d*/
    DeRef(_second_9250);
    return _d_9251;
L2: 
    ;
}



// 0x8C592122
