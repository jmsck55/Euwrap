// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _47add_options(object _new_options_49751)
{
    object _0, _1, _2;
    

    /** cominit.e:65		options = splice(options, new_options, COMMON_OPTIONS_SPLICE_IDX)*/
    {
        s1_ptr assign_space;
        insert_pos = 16;
        if (insert_pos <= 0) {
            Concat(&_47options_49747,_new_options_49751,_47options_49747);
        }
        else if (insert_pos > SEQ_PTR(_47options_49747)->length){
            Concat(&_47options_49747,_47options_49747,_new_options_49751);
        }
        else if (IS_SEQUENCE(_new_options_49751)) {
            if( _47options_49747 != _47options_49747 || SEQ_PTR( _47options_49747 )->ref != 1 ){
                DeRef( _47options_49747 );
                RefDS( _47options_49747 );
            }
            assign_space = Add_internal_space( _47options_49747, insert_pos,((s1_ptr)SEQ_PTR(_new_options_49751))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_new_options_49751), _47options_49747 == _47options_49747 );
            _47options_49747 = MAKE_SEQ( assign_space );
        }
        else {
            if( _47options_49747 == _47options_49747 && SEQ_PTR( _47options_49747 )->ref == 1 ){
                _47options_49747 = Insert( _47options_49747, _new_options_49751, insert_pos);
            }
            else {
                DeRef( _47options_49747 );
                RefDS( _47options_49747 );
                _47options_49747 = Insert( _47options_49747, _new_options_49751, insert_pos);
            }
        }
    }

    /** cominit.e:67	end procedure*/
    DeRefDS(_new_options_49751);
    return;
    ;
}


object _47get_options()
{
    object _0, _1, _2;
    

    /** cominit.e:73		return options*/
    RefDS(_47options_49747);
    return _47options_49747;
    ;
}


object _47get_switches()
{
    object _0, _1, _2;
    

    /** cominit.e:87		return switches*/
    RefDS(_47switches_49620);
    return _47switches_49620;
    ;
}


void _47show_copyrights()
{
    object _notices_49761 = NOVALUE;
    object _25521 = NOVALUE;
    object _25520 = NOVALUE;
    object _25518 = NOVALUE;
    object _25517 = NOVALUE;
    object _25516 = NOVALUE;
    object _25515 = NOVALUE;
    object _25513 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:94		sequence notices = all_copyrights()*/
    _0 = _notices_49761;
    _notices_49761 = _40all_copyrights();
    DeRef(_0);

    /** cominit.e:95		for i = 1 to length(notices) do*/
    if (IS_SEQUENCE(_notices_49761)){
            _25513 = SEQ_PTR(_notices_49761)->length;
    }
    else {
        _25513 = 1;
    }
    {
        object _i_49765;
        _i_49765 = 1;
L1: 
        if (_i_49765 > _25513){
            goto L2; // [13] 60
        }

        /** cominit.e:96			printf(2, "%s\n  %s\n\n", { notices[i][1], match_replace("\n", notices[i][2], "\n  ") })*/
        _2 = (object)SEQ_PTR(_notices_49761);
        _25515 = (object)*(((s1_ptr)_2)->base + _i_49765);
        _2 = (object)SEQ_PTR(_25515);
        _25516 = (object)*(((s1_ptr)_2)->base + 1);
        _25515 = NOVALUE;
        _2 = (object)SEQ_PTR(_notices_49761);
        _25517 = (object)*(((s1_ptr)_2)->base + _i_49765);
        _2 = (object)SEQ_PTR(_25517);
        _25518 = (object)*(((s1_ptr)_2)->base + 2);
        _25517 = NOVALUE;
        RefDS(_22210);
        Ref(_25518);
        RefDS(_25519);
        _25520 = _20match_replace(_22210, _25518, _25519, 0);
        _25518 = NOVALUE;
        Ref(_25516);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _25516;
        ((intptr_t *)_2)[2] = _25520;
        _25521 = MAKE_SEQ(_1);
        _25520 = NOVALUE;
        _25516 = NOVALUE;
        EPrintf(2, _25514, _25521);
        DeRefDS(_25521);
        _25521 = NOVALUE;

        /** cominit.e:97		end for*/
        _i_49765 = _i_49765 + 1;
        goto L1; // [55] 20
L2: 
        ;
    }

    /** cominit.e:98	end procedure*/
    DeRef(_notices_49761);
    return;
    ;
}


void _47show_banner()
{
    object _version_type_inlined_version_type_at_220_49834 = NOVALUE;
    object _version_string_short_1__tmp_at204_49832 = NOVALUE;
    object _version_string_short_inlined_version_string_short_at_204_49831 = NOVALUE;
    object _version_revision_inlined_version_revision_at_133_49812 = NOVALUE;
    object _platform_name_inlined_platform_name_at_94_49804 = NOVALUE;
    object _prod_name_49778 = NOVALUE;
    object _memory_type_49779 = NOVALUE;
    object _misc_info_49801 = NOVALUE;
    object _EuConsole_49816 = NOVALUE;
    object _25546 = NOVALUE;
    object _25545 = NOVALUE;
    object _25544 = NOVALUE;
    object _25541 = NOVALUE;
    object _25540 = NOVALUE;
    object _25536 = NOVALUE;
    object _25535 = NOVALUE;
    object _25534 = NOVALUE;
    object _25532 = NOVALUE;
    object _25530 = NOVALUE;
    object _25529 = NOVALUE;
    object _25528 = NOVALUE;
    object _25523 = NOVALUE;
    object _25522 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:109		if INTERPRET and not BIND then*/
    if (_12INTERPRET_19831 == 0) {
        goto L1; // [5] 33
    }
    _25523 = (_12BIND_19837 == 0);
    if (_25523 == 0)
    {
        DeRef(_25523);
        _25523 = NOVALUE;
        goto L1; // [15] 33
    }
    else{
        DeRef(_25523);
        _25523 = NOVALUE;
    }

    /** cominit.e:110			prod_name = GetMsgText(EUPHORIA_INTERPRETER,0)*/
    RefDS(_22015);
    _0 = _prod_name_49778;
    _prod_name_49778 = _30GetMsgText(270, 0, _22015);
    DeRef(_0);
    goto L2; // [30] 76
L1: 

    /** cominit.e:112		elsif TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L3; // [37] 55
    }
    else{
    }

    /** cominit.e:113			prod_name = GetMsgText(EUPHORIA_TO_C_TRANSLATOR,0)*/
    RefDS(_22015);
    _0 = _prod_name_49778;
    _prod_name_49778 = _30GetMsgText(271, 0, _22015);
    DeRef(_0);
    goto L2; // [52] 76
L3: 

    /** cominit.e:115		elsif BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto L4; // [59] 75
    }
    else{
    }

    /** cominit.e:116			prod_name = GetMsgText(EUPHORIA_BINDER,0)*/
    RefDS(_22015);
    _0 = _prod_name_49778;
    _prod_name_49778 = _30GetMsgText(272, 0, _22015);
    DeRef(_0);
L4: 
L2: 

    /** cominit.e:119		ifdef EU_MANAGED_MEM then*/

    /** cominit.e:122			memory_type = GetMsgText(USING_SYSTEM_MEMORY,0)*/
    RefDS(_22015);
    _0 = _memory_type_49779;
    _memory_type_49779 = _30GetMsgText(274, 0, _22015);
    DeRef(_0);

    /** cominit.e:125		sequence misc_info = {*/
    _25528 = _40arch_bits();

    /** info.e:48		ifdef WINDOWS then*/

    /** info.e:51			return "Linux"*/
    RefDS(_8362);
    DeRefi(_platform_name_inlined_platform_name_at_94_49804);
    _platform_name_inlined_platform_name_at_94_49804 = _8362;
    _25529 = _40version_date(0);
    _25530 = _40version_node(0);
    _0 = _misc_info_49801;
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25528;
    RefDS(_platform_name_inlined_platform_name_at_94_49804);
    ((intptr_t*)_2)[2] = _platform_name_inlined_platform_name_at_94_49804;
    RefDS(_memory_type_49779);
    ((intptr_t*)_2)[3] = _memory_type_49779;
    RefDS(_22015);
    ((intptr_t*)_2)[4] = _22015;
    ((intptr_t*)_2)[5] = _25529;
    ((intptr_t*)_2)[6] = _25530;
    _misc_info_49801 = MAKE_SEQ(_1);
    DeRef(_0);
    _25530 = NOVALUE;
    _25529 = NOVALUE;
    _25528 = NOVALUE;

    /** cominit.e:134		if info:is_developmental then*/
    if (_40is_developmental_14591 == 0)
    {
        goto L5; // [126] 160
    }
    else{
    }

    /** cominit.e:135			misc_info[$] = sprintf("%d:%s", { info:version_revision(), info:version_node() })*/
    _25532 = 6;

    /** info.e:157		return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_133_49812);
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _version_revision_inlined_version_revision_at_133_49812 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_version_revision_inlined_version_revision_at_133_49812);
    _25534 = _40version_node(0);
    Ref(_version_revision_inlined_version_revision_at_133_49812);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _version_revision_inlined_version_revision_at_133_49812;
    ((intptr_t *)_2)[2] = _25534;
    _25535 = MAKE_SEQ(_1);
    _25534 = NOVALUE;
    _25536 = EPrintf(-9999999, _25533, _25535);
    DeRefDS(_25535);
    _25535 = NOVALUE;
    _2 = (object)SEQ_PTR(_misc_info_49801);
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25536;
    if( _1 != _25536 ){
        DeRef(_1);
    }
    _25536 = NOVALUE;
L5: 

    /** cominit.e:138		object EuConsole = getenv("EUCONS")*/
    DeRefi(_EuConsole_49816);
    _EuConsole_49816 = EGetEnv(_25537);

    /** cominit.e:139		if equal(EuConsole, "1") then*/
    if (_EuConsole_49816 == _25539)
    _25540 = 1;
    else if (IS_ATOM_INT(_EuConsole_49816) && IS_ATOM_INT(_25539))
    _25540 = 0;
    else
    _25540 = (compare(_EuConsole_49816, _25539) == 0);
    if (_25540 == 0)
    {
        _25540 = NOVALUE;
        goto L6; // [171] 191
    }
    else{
        _25540 = NOVALUE;
    }

    /** cominit.e:140			misc_info[4] = GetMsgText(EUCONSOLE,0)*/
    RefDS(_22015);
    _25541 = _30GetMsgText(275, 0, _22015);
    _2 = (object)SEQ_PTR(_misc_info_49801);
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25541;
    if( _1 != _25541 ){
        DeRef(_1);
    }
    _25541 = NOVALUE;
    goto L7; // [188] 199
L6: 

    /** cominit.e:142			misc_info = remove(misc_info, 4)*/
    {
        s1_ptr assign_space = SEQ_PTR(_misc_info_49801);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(4)) ? 4 : (object)(DBL_PTR(4)->dbl);
        int stop = (IS_ATOM_INT(4)) ? 4 : (object)(DBL_PTR(4)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_misc_info_49801), start, &_misc_info_49801 );
            }
            else Tail(SEQ_PTR(_misc_info_49801), stop+1, &_misc_info_49801);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_misc_info_49801), start, &_misc_info_49801);
        }
        else {
            assign_slice_seq = &assign_space;
            _misc_info_49801 = Remove_elements(start, stop, (SEQ_PTR(_misc_info_49801)->ref == 1));
        }
    }
L7: 

    /** cominit.e:145		screen_output(STDERR, sprintf("%s v%s %s\n   %s %s, %s\n   Revision Date: %s, Id: %s\n", {*/

    /** info.e:261		return sprintf("%d.%d.%d", version_info[MAJ_VER..PAT_VER])*/
    rhs_slice_target = (object_ptr)&_version_string_short_1__tmp_at204_49832;
    RHS_Slice(_40version_info_14589, 1, 3);
    DeRefi(_version_string_short_inlined_version_string_short_at_204_49831);
    _version_string_short_inlined_version_string_short_at_204_49831 = EPrintf(-9999999, _8419, _version_string_short_1__tmp_at204_49832);
    DeRef(_version_string_short_1__tmp_at204_49832);
    _version_string_short_1__tmp_at204_49832 = NOVALUE;

    /** info.e:202		return version_info[VER_TYPE]*/
    DeRef(_version_type_inlined_version_type_at_220_49834);
    _2 = (object)SEQ_PTR(_40version_info_14589);
    _version_type_inlined_version_type_at_220_49834 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_version_type_inlined_version_type_at_220_49834);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_prod_name_49778);
    ((intptr_t*)_2)[1] = _prod_name_49778;
    RefDS(_version_string_short_inlined_version_string_short_at_204_49831);
    ((intptr_t*)_2)[2] = _version_string_short_inlined_version_string_short_at_204_49831;
    Ref(_version_type_inlined_version_type_at_220_49834);
    ((intptr_t*)_2)[3] = _version_type_inlined_version_type_at_220_49834;
    _25544 = MAKE_SEQ(_1);
    Concat((object_ptr)&_25545, _25544, _misc_info_49801);
    DeRefDS(_25544);
    _25544 = NOVALUE;
    DeRef(_25544);
    _25544 = NOVALUE;
    _25546 = EPrintf(-9999999, _25543, _25545);
    DeRefDS(_25545);
    _25545 = NOVALUE;
    _49screen_output(2, _25546);
    _25546 = NOVALUE;

    /** cominit.e:147	end procedure*/
    DeRefDS(_prod_name_49778);
    DeRef(_memory_type_49779);
    DeRefDS(_misc_info_49801);
    DeRefi(_EuConsole_49816);
    return;
    ;
}


object _47find_opt(object _name_type_49846, object _opt_49847, object _opts_49848)
{
    object _o_49852 = NOVALUE;
    object _has_case_49854 = NOVALUE;
    object _25559 = NOVALUE;
    object _25558 = NOVALUE;
    object _25557 = NOVALUE;
    object _25556 = NOVALUE;
    object _25555 = NOVALUE;
    object _25554 = NOVALUE;
    object _25553 = NOVALUE;
    object _25552 = NOVALUE;
    object _25551 = NOVALUE;
    object _25549 = NOVALUE;
    object _25547 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:172		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_49848)){
            _25547 = SEQ_PTR(_opts_49848)->length;
    }
    else {
        _25547 = 1;
    }
    {
        object _i_49850;
        _i_49850 = 1;
L1: 
        if (_i_49850 > _25547){
            goto L2; // [12] 113
        }

        /** cominit.e:173			sequence o = opts[i]		*/
        DeRef(_o_49852);
        _2 = (object)SEQ_PTR(_opts_49848);
        _o_49852 = (object)*(((s1_ptr)_2)->base + _i_49850);
        Ref(_o_49852);

        /** cominit.e:174			integer has_case = find(HAS_CASE, o[OPTIONS])*/
        _2 = (object)SEQ_PTR(_o_49852);
        _25549 = (object)*(((s1_ptr)_2)->base + 4);
        _has_case_49854 = find_from(99, _25549, 1);
        _25549 = NOVALUE;

        /** cominit.e:176			if has_case and equal(o[name_type], opt) then*/
        if (_has_case_49854 == 0) {
            goto L3; // [42] 67
        }
        _2 = (object)SEQ_PTR(_o_49852);
        _25552 = (object)*(((s1_ptr)_2)->base + _name_type_49846);
        if (_25552 == _opt_49847)
        _25553 = 1;
        else if (IS_ATOM_INT(_25552) && IS_ATOM_INT(_opt_49847))
        _25553 = 0;
        else
        _25553 = (compare(_25552, _opt_49847) == 0);
        _25552 = NOVALUE;
        if (_25553 == 0)
        {
            _25553 = NOVALUE;
            goto L3; // [55] 67
        }
        else{
            _25553 = NOVALUE;
        }

        /** cominit.e:177				return o*/
        DeRefDS(_opt_49847);
        DeRefDS(_opts_49848);
        return _o_49852;
        goto L4; // [64] 104
L3: 

        /** cominit.e:178			elsif not has_case and equal(text:lower(o[name_type]), text:lower(opt)) then*/
        _25554 = (_has_case_49854 == 0);
        if (_25554 == 0) {
            goto L5; // [72] 103
        }
        _2 = (object)SEQ_PTR(_o_49852);
        _25556 = (object)*(((s1_ptr)_2)->base + _name_type_49846);
        Ref(_25556);
        _25557 = _18lower(_25556);
        _25556 = NOVALUE;
        RefDS(_opt_49847);
        _25558 = _18lower(_opt_49847);
        if (_25557 == _25558)
        _25559 = 1;
        else if (IS_ATOM_INT(_25557) && IS_ATOM_INT(_25558))
        _25559 = 0;
        else
        _25559 = (compare(_25557, _25558) == 0);
        DeRef(_25557);
        _25557 = NOVALUE;
        DeRef(_25558);
        _25558 = NOVALUE;
        if (_25559 == 0)
        {
            _25559 = NOVALUE;
            goto L5; // [93] 103
        }
        else{
            _25559 = NOVALUE;
        }

        /** cominit.e:179				return o*/
        DeRefDS(_opt_49847);
        DeRefDS(_opts_49848);
        DeRef(_25554);
        _25554 = NOVALUE;
        return _o_49852;
L5: 
L4: 
        DeRef(_o_49852);
        _o_49852 = NOVALUE;

        /** cominit.e:181		end for*/
        _i_49850 = _i_49850 + 1;
        goto L1; // [108] 19
L2: 
        ;
    }

    /** cominit.e:183		return {}*/
    RefDS(_22015);
    DeRefDS(_opt_49847);
    DeRefDS(_opts_49848);
    DeRef(_25554);
    _25554 = NOVALUE;
    return _22015;
    ;
}


object _47merge_parameters(object _a_49871, object _b_49872, object _opts_49873, object _dedupe_49874)
{
    object _i_49875 = NOVALUE;
    object _opt_49879 = NOVALUE;
    object _this_opt_49885 = NOVALUE;
    object _bi_49886 = NOVALUE;
    object _beginLen_49946 = NOVALUE;
    object _first_extra_49968 = NOVALUE;
    object _opt_49972 = NOVALUE;
    object _this_opt_49977 = NOVALUE;
    object _25653 = NOVALUE;
    object _25652 = NOVALUE;
    object _25649 = NOVALUE;
    object _25648 = NOVALUE;
    object _25647 = NOVALUE;
    object _25645 = NOVALUE;
    object _25644 = NOVALUE;
    object _25643 = NOVALUE;
    object _25642 = NOVALUE;
    object _25640 = NOVALUE;
    object _25639 = NOVALUE;
    object _25637 = NOVALUE;
    object _25636 = NOVALUE;
    object _25635 = NOVALUE;
    object _25634 = NOVALUE;
    object _25633 = NOVALUE;
    object _25632 = NOVALUE;
    object _25631 = NOVALUE;
    object _25629 = NOVALUE;
    object _25626 = NOVALUE;
    object _25625 = NOVALUE;
    object _25620 = NOVALUE;
    object _25618 = NOVALUE;
    object _25617 = NOVALUE;
    object _25616 = NOVALUE;
    object _25615 = NOVALUE;
    object _25614 = NOVALUE;
    object _25613 = NOVALUE;
    object _25612 = NOVALUE;
    object _25611 = NOVALUE;
    object _25607 = NOVALUE;
    object _25606 = NOVALUE;
    object _25605 = NOVALUE;
    object _25604 = NOVALUE;
    object _25603 = NOVALUE;
    object _25602 = NOVALUE;
    object _25601 = NOVALUE;
    object _25600 = NOVALUE;
    object _25599 = NOVALUE;
    object _25598 = NOVALUE;
    object _25597 = NOVALUE;
    object _25596 = NOVALUE;
    object _25595 = NOVALUE;
    object _25594 = NOVALUE;
    object _25593 = NOVALUE;
    object _25591 = NOVALUE;
    object _25590 = NOVALUE;
    object _25589 = NOVALUE;
    object _25588 = NOVALUE;
    object _25587 = NOVALUE;
    object _25586 = NOVALUE;
    object _25585 = NOVALUE;
    object _25584 = NOVALUE;
    object _25582 = NOVALUE;
    object _25581 = NOVALUE;
    object _25580 = NOVALUE;
    object _25579 = NOVALUE;
    object _25577 = NOVALUE;
    object _25576 = NOVALUE;
    object _25575 = NOVALUE;
    object _25574 = NOVALUE;
    object _25573 = NOVALUE;
    object _25572 = NOVALUE;
    object _25571 = NOVALUE;
    object _25569 = NOVALUE;
    object _25568 = NOVALUE;
    object _25566 = NOVALUE;
    object _25563 = NOVALUE;
    object _25560 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:199		integer i = 1*/
    _i_49875 = 1;

    /** cominit.e:201		while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_49871)){
            _25560 = SEQ_PTR(_a_49871)->length;
    }
    else {
        _25560 = 1;
    }
    if (_i_49875 > _25560)
    goto L2; // [22] 465

    /** cominit.e:202			sequence opt = a[i]*/
    DeRef(_opt_49879);
    _2 = (object)SEQ_PTR(_a_49871);
    _opt_49879 = (object)*(((s1_ptr)_2)->base + _i_49875);
    Ref(_opt_49879);

    /** cominit.e:203			if length(opt) < 2 then*/
    if (IS_SEQUENCE(_opt_49879)){
            _25563 = SEQ_PTR(_opt_49879)->length;
    }
    else {
        _25563 = 1;
    }
    if (_25563 >= 2)
    goto L3; // [39] 56

    /** cominit.e:204				i += 1*/
    _i_49875 = _i_49875 + 1;

    /** cominit.e:205				continue*/
    DeRefDS(_opt_49879);
    _opt_49879 = NOVALUE;
    DeRef(_this_opt_49885);
    _this_opt_49885 = NOVALUE;
    goto L1; // [53] 19
L3: 

    /** cominit.e:208			sequence this_opt = {}*/
    RefDS(_22015);
    DeRef(_this_opt_49885);
    _this_opt_49885 = _22015;

    /** cominit.e:209			integer bi = 0*/
    _bi_49886 = 0;

    /** cominit.e:211			if opt[2] = '-' then*/
    _2 = (object)SEQ_PTR(_opt_49879);
    _25566 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _25566, 45)){
        _25566 = NOVALUE;
        goto L4; // [74] 149
    }
    _25566 = NOVALUE;

    /** cominit.e:214				this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_49879)){
            _25568 = SEQ_PTR(_opt_49879)->length;
    }
    else {
        _25568 = 1;
    }
    rhs_slice_target = (object_ptr)&_25569;
    RHS_Slice(_opt_49879, 3, _25568);
    RefDS(_opts_49873);
    _0 = _this_opt_49885;
    _this_opt_49885 = _47find_opt(2, _25569, _opts_49873);
    DeRefDS(_0);
    _25569 = NOVALUE;

    /** cominit.e:216				for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_49872)){
            _25571 = SEQ_PTR(_b_49872)->length;
    }
    else {
        _25571 = 1;
    }
    {
        object _j_49894;
        _j_49894 = 1;
L5: 
        if (_j_49894 > _25571){
            goto L6; // [101] 146
        }

        /** cominit.e:217					if equal(text:lower(b[j]), text:lower(opt)) then*/
        _2 = (object)SEQ_PTR(_b_49872);
        _25572 = (object)*(((s1_ptr)_2)->base + _j_49894);
        Ref(_25572);
        _25573 = _18lower(_25572);
        _25572 = NOVALUE;
        RefDS(_opt_49879);
        _25574 = _18lower(_opt_49879);
        if (_25573 == _25574)
        _25575 = 1;
        else if (IS_ATOM_INT(_25573) && IS_ATOM_INT(_25574))
        _25575 = 0;
        else
        _25575 = (compare(_25573, _25574) == 0);
        DeRef(_25573);
        _25573 = NOVALUE;
        DeRef(_25574);
        _25574 = NOVALUE;
        if (_25575 == 0)
        {
            _25575 = NOVALUE;
            goto L7; // [126] 139
        }
        else{
            _25575 = NOVALUE;
        }

        /** cominit.e:218						bi = j*/
        _bi_49886 = _j_49894;

        /** cominit.e:219						exit*/
        goto L6; // [136] 146
L7: 

        /** cominit.e:221				end for*/
        _j_49894 = _j_49894 + 1;
        goto L5; // [141] 108
L6: 
        ;
    }
    goto L8; // [146] 292
L4: 

    /** cominit.e:223			elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (object)SEQ_PTR(_opt_49879);
    _25576 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25576)) {
        _25577 = (_25576 == 45);
    }
    else {
        _25577 = binary_op(EQUALS, _25576, 45);
    }
    _25576 = NOVALUE;
    if (IS_ATOM_INT(_25577)) {
        if (_25577 != 0) {
            goto L9; // [159] 176
        }
    }
    else {
        if (DBL_PTR(_25577)->dbl != 0.0) {
            goto L9; // [159] 176
        }
    }
    _2 = (object)SEQ_PTR(_opt_49879);
    _25579 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25579)) {
        _25580 = (_25579 == 47);
    }
    else {
        _25580 = binary_op(EQUALS, _25579, 47);
    }
    _25579 = NOVALUE;
    if (_25580 == 0) {
        DeRef(_25580);
        _25580 = NOVALUE;
        goto LA; // [172] 291
    }
    else {
        if (!IS_ATOM_INT(_25580) && DBL_PTR(_25580)->dbl == 0.0){
            DeRef(_25580);
            _25580 = NOVALUE;
            goto LA; // [172] 291
        }
        DeRef(_25580);
        _25580 = NOVALUE;
    }
    DeRef(_25580);
    _25580 = NOVALUE;
L9: 

    /** cominit.e:226				this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_49879)){
            _25581 = SEQ_PTR(_opt_49879)->length;
    }
    else {
        _25581 = 1;
    }
    rhs_slice_target = (object_ptr)&_25582;
    RHS_Slice(_opt_49879, 2, _25581);
    RefDS(_opts_49873);
    _0 = _this_opt_49885;
    _this_opt_49885 = _47find_opt(1, _25582, _opts_49873);
    DeRef(_0);
    _25582 = NOVALUE;

    /** cominit.e:228				for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_49872)){
            _25584 = SEQ_PTR(_b_49872)->length;
    }
    else {
        _25584 = 1;
    }
    {
        object _j_49911;
        _j_49911 = 1;
LB: 
        if (_j_49911 > _25584){
            goto LC; // [199] 290
        }

        /** cominit.e:229					if equal(text:lower(b[j]), '-' & text:lower(opt[2..$])) or */
        _2 = (object)SEQ_PTR(_b_49872);
        _25585 = (object)*(((s1_ptr)_2)->base + _j_49911);
        Ref(_25585);
        _25586 = _18lower(_25585);
        _25585 = NOVALUE;
        if (IS_SEQUENCE(_opt_49879)){
                _25587 = SEQ_PTR(_opt_49879)->length;
        }
        else {
            _25587 = 1;
        }
        rhs_slice_target = (object_ptr)&_25588;
        RHS_Slice(_opt_49879, 2, _25587);
        _25589 = _18lower(_25588);
        _25588 = NOVALUE;
        if (IS_SEQUENCE(45) && IS_ATOM(_25589)) {
        }
        else if (IS_ATOM(45) && IS_SEQUENCE(_25589)) {
            Prepend(&_25590, _25589, 45);
        }
        else {
            Concat((object_ptr)&_25590, 45, _25589);
        }
        DeRef(_25589);
        _25589 = NOVALUE;
        if (_25586 == _25590)
        _25591 = 1;
        else if (IS_ATOM_INT(_25586) && IS_ATOM_INT(_25590))
        _25591 = 0;
        else
        _25591 = (compare(_25586, _25590) == 0);
        DeRef(_25586);
        _25586 = NOVALUE;
        DeRefDS(_25590);
        _25590 = NOVALUE;
        if (_25591 != 0) {
            goto LD; // [236] 273
        }
        _2 = (object)SEQ_PTR(_b_49872);
        _25593 = (object)*(((s1_ptr)_2)->base + _j_49911);
        Ref(_25593);
        _25594 = _18lower(_25593);
        _25593 = NOVALUE;
        if (IS_SEQUENCE(_opt_49879)){
                _25595 = SEQ_PTR(_opt_49879)->length;
        }
        else {
            _25595 = 1;
        }
        rhs_slice_target = (object_ptr)&_25596;
        RHS_Slice(_opt_49879, 2, _25595);
        _25597 = _18lower(_25596);
        _25596 = NOVALUE;
        if (IS_SEQUENCE(47) && IS_ATOM(_25597)) {
        }
        else if (IS_ATOM(47) && IS_SEQUENCE(_25597)) {
            Prepend(&_25598, _25597, 47);
        }
        else {
            Concat((object_ptr)&_25598, 47, _25597);
        }
        DeRef(_25597);
        _25597 = NOVALUE;
        if (_25594 == _25598)
        _25599 = 1;
        else if (IS_ATOM_INT(_25594) && IS_ATOM_INT(_25598))
        _25599 = 0;
        else
        _25599 = (compare(_25594, _25598) == 0);
        DeRef(_25594);
        _25594 = NOVALUE;
        DeRefDS(_25598);
        _25598 = NOVALUE;
        if (_25599 == 0)
        {
            _25599 = NOVALUE;
            goto LE; // [269] 283
        }
        else{
            _25599 = NOVALUE;
        }
LD: 

        /** cominit.e:232						bi = j*/
        _bi_49886 = _j_49911;

        /** cominit.e:233						exit*/
        goto LC; // [280] 290
LE: 

        /** cominit.e:235				end for*/
        _j_49911 = _j_49911 + 1;
        goto LB; // [285] 206
LC: 
        ;
    }
LA: 
L8: 

    /** cominit.e:243			if length(this_opt) and not find(MULTIPLE, this_opt[OPTIONS]) then*/
    if (IS_SEQUENCE(_this_opt_49885)){
            _25600 = SEQ_PTR(_this_opt_49885)->length;
    }
    else {
        _25600 = 1;
    }
    if (_25600 == 0) {
        goto LF; // [297] 451
    }
    _2 = (object)SEQ_PTR(_this_opt_49885);
    _25602 = (object)*(((s1_ptr)_2)->base + 4);
    _25603 = find_from(42, _25602, 1);
    _25602 = NOVALUE;
    _25604 = (_25603 == 0);
    _25603 = NOVALUE;
    if (_25604 == 0)
    {
        DeRef(_25604);
        _25604 = NOVALUE;
        goto LF; // [316] 451
    }
    else{
        DeRef(_25604);
        _25604 = NOVALUE;
    }

    /** cominit.e:244				if bi then*/
    if (_bi_49886 == 0)
    {
        goto L10; // [321] 365
    }
    else{
    }

    /** cominit.e:245					if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_this_opt_49885);
    _25605 = (object)*(((s1_ptr)_2)->base + 4);
    _25606 = find_from(112, _25605, 1);
    _25605 = NOVALUE;
    if (_25606 == 0)
    {
        _25606 = NOVALUE;
        goto L11; // [337] 354
    }
    else{
        _25606 = NOVALUE;
    }

    /** cominit.e:247						a = remove(a, i, i + 1)*/
    _25607 = _i_49875 + 1;
    if (_25607 > MAXINT){
        _25607 = NewDouble((eudouble)_25607);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_a_49871);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_49875)) ? _i_49875 : (object)(DBL_PTR(_i_49875)->dbl);
        int stop = (IS_ATOM_INT(_25607)) ? _25607 : (object)(DBL_PTR(_25607)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_49871), start, &_a_49871 );
            }
            else Tail(SEQ_PTR(_a_49871), stop+1, &_a_49871);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_49871), start, &_a_49871);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_49871 = Remove_elements(start, stop, (SEQ_PTR(_a_49871)->ref == 1));
        }
    }
    DeRef(_25607);
    _25607 = NOVALUE;
    goto L12; // [351] 458
L11: 

    /** cominit.e:250						a = remove(a, i)*/
    {
        s1_ptr assign_space = SEQ_PTR(_a_49871);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_49875)) ? _i_49875 : (object)(DBL_PTR(_i_49875)->dbl);
        int stop = (IS_ATOM_INT(_i_49875)) ? _i_49875 : (object)(DBL_PTR(_i_49875)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_49871), start, &_a_49871 );
            }
            else Tail(SEQ_PTR(_a_49871), stop+1, &_a_49871);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_49871), start, &_a_49871);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_49871 = Remove_elements(start, stop, (SEQ_PTR(_a_49871)->ref == 1));
        }
    }
    goto L12; // [362] 458
L10: 

    /** cominit.e:265					integer beginLen = length(a)*/
    if (IS_SEQUENCE(_a_49871)){
            _beginLen_49946 = SEQ_PTR(_a_49871)->length;
    }
    else {
        _beginLen_49946 = 1;
    }

    /** cominit.e:267					if dedupe = 0 and i < beginLen then*/
    _25611 = (_dedupe_49874 == 0);
    if (_25611 == 0) {
        goto L13; // [376] 438
    }
    _25613 = (_i_49875 < _beginLen_49946);
    if (_25613 == 0)
    {
        DeRef(_25613);
        _25613 = NOVALUE;
        goto L13; // [385] 438
    }
    else{
        DeRef(_25613);
        _25613 = NOVALUE;
    }

    /** cominit.e:268						a = merge_parameters( a[i + 1..$], a[1..i], opts, 1)*/
    _25614 = _i_49875 + 1;
    if (_25614 > MAXINT){
        _25614 = NewDouble((eudouble)_25614);
    }
    if (IS_SEQUENCE(_a_49871)){
            _25615 = SEQ_PTR(_a_49871)->length;
    }
    else {
        _25615 = 1;
    }
    rhs_slice_target = (object_ptr)&_25616;
    RHS_Slice(_a_49871, _25614, _25615);
    rhs_slice_target = (object_ptr)&_25617;
    RHS_Slice(_a_49871, 1, _i_49875);
    RefDS(_opts_49873);
    DeRef(_25618);
    _25618 = _opts_49873;
    _0 = _a_49871;
    _a_49871 = _47merge_parameters(_25616, _25617, _25618, 1);
    DeRefDS(_0);
    _25616 = NOVALUE;
    _25617 = NOVALUE;
    _25618 = NOVALUE;

    /** cominit.e:270						if beginLen = length(a) then*/
    if (IS_SEQUENCE(_a_49871)){
            _25620 = SEQ_PTR(_a_49871)->length;
    }
    else {
        _25620 = 1;
    }
    if (_beginLen_49946 != _25620)
    goto L14; // [424] 445

    /** cominit.e:272							i += 1*/
    _i_49875 = _i_49875 + 1;
    goto L14; // [435] 445
L13: 

    /** cominit.e:276						i += 1*/
    _i_49875 = _i_49875 + 1;
L14: 
    goto L12; // [448] 458
LF: 

    /** cominit.e:282				i += 1*/
    _i_49875 = _i_49875 + 1;
L12: 
    DeRef(_opt_49879);
    _opt_49879 = NOVALUE;
    DeRef(_this_opt_49885);
    _this_opt_49885 = NOVALUE;

    /** cominit.e:284		end while*/
    goto L1; // [462] 19
L2: 

    /** cominit.e:286		if dedupe then*/
    if (_dedupe_49874 == 0)
    {
        goto L15; // [467] 481
    }
    else{
    }

    /** cominit.e:287			return b & a*/
    Concat((object_ptr)&_25625, _b_49872, _a_49871);
    DeRefDS(_a_49871);
    DeRefDS(_b_49872);
    DeRefDS(_opts_49873);
    DeRef(_25611);
    _25611 = NOVALUE;
    DeRef(_25614);
    _25614 = NOVALUE;
    DeRef(_25577);
    _25577 = NOVALUE;
    return _25625;
L15: 

    /** cominit.e:290		integer first_extra = 0*/
    _first_extra_49968 = 0;

    /** cominit.e:292		i = 1*/
    _i_49875 = 1;

    /** cominit.e:295		while i <= length(b) do*/
L16: 
    if (IS_SEQUENCE(_b_49872)){
            _25626 = SEQ_PTR(_b_49872)->length;
    }
    else {
        _25626 = 1;
    }
    if (_i_49875 > _25626)
    goto L17; // [499] 692

    /** cominit.e:296			sequence opt = b[i]*/
    DeRef(_opt_49972);
    _2 = (object)SEQ_PTR(_b_49872);
    _opt_49972 = (object)*(((s1_ptr)_2)->base + _i_49875);
    Ref(_opt_49972);

    /** cominit.e:299			if length(opt) <= 1 then*/
    if (IS_SEQUENCE(_opt_49972)){
            _25629 = SEQ_PTR(_opt_49972)->length;
    }
    else {
        _25629 = 1;
    }
    if (_25629 > 1)
    goto L18; // [516] 532

    /** cominit.e:300				first_extra = i*/
    _first_extra_49968 = _i_49875;

    /** cominit.e:301				exit*/
    DeRefDS(_opt_49972);
    _opt_49972 = NOVALUE;
    DeRef(_this_opt_49977);
    _this_opt_49977 = NOVALUE;
    goto L17; // [529] 692
L18: 

    /** cominit.e:304			sequence this_opt = {}*/
    RefDS(_22015);
    DeRef(_this_opt_49977);
    _this_opt_49977 = _22015;

    /** cominit.e:305			if opt[2] = '-' and opt[1] = '-' then*/
    _2 = (object)SEQ_PTR(_opt_49972);
    _25631 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_25631)) {
        _25632 = (_25631 == 45);
    }
    else {
        _25632 = binary_op(EQUALS, _25631, 45);
    }
    _25631 = NOVALUE;
    if (IS_ATOM_INT(_25632)) {
        if (_25632 == 0) {
            goto L19; // [549] 586
        }
    }
    else {
        if (DBL_PTR(_25632)->dbl == 0.0) {
            goto L19; // [549] 586
        }
    }
    _2 = (object)SEQ_PTR(_opt_49972);
    _25634 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25634)) {
        _25635 = (_25634 == 45);
    }
    else {
        _25635 = binary_op(EQUALS, _25634, 45);
    }
    _25634 = NOVALUE;
    if (_25635 == 0) {
        DeRef(_25635);
        _25635 = NOVALUE;
        goto L19; // [562] 586
    }
    else {
        if (!IS_ATOM_INT(_25635) && DBL_PTR(_25635)->dbl == 0.0){
            DeRef(_25635);
            _25635 = NOVALUE;
            goto L19; // [562] 586
        }
        DeRef(_25635);
        _25635 = NOVALUE;
    }
    DeRef(_25635);
    _25635 = NOVALUE;

    /** cominit.e:306				this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_49972)){
            _25636 = SEQ_PTR(_opt_49972)->length;
    }
    else {
        _25636 = 1;
    }
    rhs_slice_target = (object_ptr)&_25637;
    RHS_Slice(_opt_49972, 3, _25636);
    RefDS(_opts_49873);
    _0 = _this_opt_49977;
    _this_opt_49977 = _47find_opt(2, _25637, _opts_49873);
    DeRef(_0);
    _25637 = NOVALUE;
    goto L1A; // [583] 633
L19: 

    /** cominit.e:307			elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (object)SEQ_PTR(_opt_49972);
    _25639 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25639)) {
        _25640 = (_25639 == 45);
    }
    else {
        _25640 = binary_op(EQUALS, _25639, 45);
    }
    _25639 = NOVALUE;
    if (IS_ATOM_INT(_25640)) {
        if (_25640 != 0) {
            goto L1B; // [596] 613
        }
    }
    else {
        if (DBL_PTR(_25640)->dbl != 0.0) {
            goto L1B; // [596] 613
        }
    }
    _2 = (object)SEQ_PTR(_opt_49972);
    _25642 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25642)) {
        _25643 = (_25642 == 47);
    }
    else {
        _25643 = binary_op(EQUALS, _25642, 47);
    }
    _25642 = NOVALUE;
    if (_25643 == 0) {
        DeRef(_25643);
        _25643 = NOVALUE;
        goto L1C; // [609] 632
    }
    else {
        if (!IS_ATOM_INT(_25643) && DBL_PTR(_25643)->dbl == 0.0){
            DeRef(_25643);
            _25643 = NOVALUE;
            goto L1C; // [609] 632
        }
        DeRef(_25643);
        _25643 = NOVALUE;
    }
    DeRef(_25643);
    _25643 = NOVALUE;
L1B: 

    /** cominit.e:308				this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_49972)){
            _25644 = SEQ_PTR(_opt_49972)->length;
    }
    else {
        _25644 = 1;
    }
    rhs_slice_target = (object_ptr)&_25645;
    RHS_Slice(_opt_49972, 2, _25644);
    RefDS(_opts_49873);
    _0 = _this_opt_49977;
    _this_opt_49977 = _47find_opt(1, _25645, _opts_49873);
    DeRef(_0);
    _25645 = NOVALUE;
L1C: 
L1A: 

    /** cominit.e:311			if length(this_opt) then*/
    if (IS_SEQUENCE(_this_opt_49977)){
            _25647 = SEQ_PTR(_this_opt_49977)->length;
    }
    else {
        _25647 = 1;
    }
    if (_25647 == 0)
    {
        _25647 = NOVALUE;
        goto L1D; // [638] 667
    }
    else{
        _25647 = NOVALUE;
    }

    /** cominit.e:312				if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_this_opt_49977);
    _25648 = (object)*(((s1_ptr)_2)->base + 4);
    _25649 = find_from(112, _25648, 1);
    _25648 = NOVALUE;
    if (_25649 == 0)
    {
        _25649 = NOVALUE;
        goto L1E; // [654] 679
    }
    else{
        _25649 = NOVALUE;
    }

    /** cominit.e:313					i += 1*/
    _i_49875 = _i_49875 + 1;
    goto L1E; // [664] 679
L1D: 

    /** cominit.e:316				first_extra = i*/
    _first_extra_49968 = _i_49875;

    /** cominit.e:317				exit*/
    DeRef(_opt_49972);
    _opt_49972 = NOVALUE;
    DeRef(_this_opt_49977);
    _this_opt_49977 = NOVALUE;
    goto L17; // [676] 692
L1E: 

    /** cominit.e:320			i += 1*/
    _i_49875 = _i_49875 + 1;
    DeRef(_opt_49972);
    _opt_49972 = NOVALUE;
    DeRef(_this_opt_49977);
    _this_opt_49977 = NOVALUE;

    /** cominit.e:321		end while*/
    goto L16; // [689] 496
L17: 

    /** cominit.e:323		if first_extra then*/
    if (_first_extra_49968 == 0)
    {
        goto L1F; // [694] 709
    }
    else{
    }

    /** cominit.e:324			return splice(b, a, first_extra)*/
    {
        s1_ptr assign_space;
        insert_pos = _first_extra_49968;
        if (insert_pos <= 0) {
            Concat(&_25652,_a_49871,_b_49872);
        }
        else if (insert_pos > SEQ_PTR(_b_49872)->length){
            Concat(&_25652,_b_49872,_a_49871);
        }
        else if (IS_SEQUENCE(_a_49871)) {
            if( _25652 != _b_49872 || SEQ_PTR( _b_49872 )->ref != 1 ){
                DeRef( _25652 );
                RefDS( _b_49872 );
            }
            assign_space = Add_internal_space( _b_49872, insert_pos,((s1_ptr)SEQ_PTR(_a_49871))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_a_49871), _b_49872 == _25652 );
            _25652 = MAKE_SEQ( assign_space );
        }
        else {
            if( _25652 == _b_49872 && SEQ_PTR( _b_49872 )->ref == 1 ){
                _25652 = Insert( _b_49872, _a_49871, insert_pos);
            }
            else {
                DeRef( _25652 );
                RefDS( _b_49872 );
                _25652 = Insert( _b_49872, _a_49871, insert_pos);
            }
        }
    }
    DeRefDS(_a_49871);
    DeRefDS(_b_49872);
    DeRefDS(_opts_49873);
    DeRef(_25632);
    _25632 = NOVALUE;
    DeRef(_25640);
    _25640 = NOVALUE;
    DeRef(_25611);
    _25611 = NOVALUE;
    DeRef(_25625);
    _25625 = NOVALUE;
    DeRef(_25614);
    _25614 = NOVALUE;
    DeRef(_25577);
    _25577 = NOVALUE;
    return _25652;
L1F: 

    /** cominit.e:328		return b & a*/
    Concat((object_ptr)&_25653, _b_49872, _a_49871);
    DeRefDS(_a_49871);
    DeRefDS(_b_49872);
    DeRefDS(_opts_49873);
    DeRef(_25632);
    _25632 = NOVALUE;
    DeRef(_25640);
    _25640 = NOVALUE;
    DeRef(_25611);
    _25611 = NOVALUE;
    DeRef(_25625);
    _25625 = NOVALUE;
    DeRef(_25652);
    _25652 = NOVALUE;
    DeRef(_25614);
    _25614 = NOVALUE;
    DeRef(_25577);
    _25577 = NOVALUE;
    return _25653;
    ;
}


object _47validate_opt(object _opt_type_50010, object _arg_50011, object _args_50012, object _ix_50013)
{
    object _opt_50014 = NOVALUE;
    object _this_opt_50022 = NOVALUE;
    object _25672 = NOVALUE;
    object _25671 = NOVALUE;
    object _25670 = NOVALUE;
    object _25669 = NOVALUE;
    object _25668 = NOVALUE;
    object _25666 = NOVALUE;
    object _25665 = NOVALUE;
    object _25664 = NOVALUE;
    object _25663 = NOVALUE;
    object _25662 = NOVALUE;
    object _25660 = NOVALUE;
    object _25657 = NOVALUE;
    object _25655 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:336		if opt_type = SHORTNAME then*/
    if (_opt_type_50010 != 1)
    goto L1; // [11] 28

    /** cominit.e:337			opt = arg[2..$]*/
    if (IS_SEQUENCE(_arg_50011)){
            _25655 = SEQ_PTR(_arg_50011)->length;
    }
    else {
        _25655 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_50014;
    RHS_Slice(_arg_50011, 2, _25655);
    goto L2; // [25] 39
L1: 

    /** cominit.e:339			opt = arg[3..$]*/
    if (IS_SEQUENCE(_arg_50011)){
            _25657 = SEQ_PTR(_arg_50011)->length;
    }
    else {
        _25657 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_50014;
    RHS_Slice(_arg_50011, 3, _25657);
L2: 

    /** cominit.e:342		sequence this_opt = find_opt( opt_type, opt, options )*/
    RefDS(_opt_50014);
    RefDS(_47options_49747);
    _0 = _this_opt_50022;
    _this_opt_50022 = _47find_opt(_opt_type_50010, _opt_50014, _47options_49747);
    DeRef(_0);

    /** cominit.e:343		if not length( this_opt ) then*/
    if (IS_SEQUENCE(_this_opt_50022)){
            _25660 = SEQ_PTR(_this_opt_50022)->length;
    }
    else {
        _25660 = 1;
    }
    if (_25660 != 0)
    goto L3; // [58] 72
    _25660 = NOVALUE;

    /** cominit.e:345			return { 0, 0 }*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = 0;
    _25662 = MAKE_SEQ(_1);
    DeRefDS(_arg_50011);
    DeRefDS(_args_50012);
    DeRefDS(_opt_50014);
    DeRefDS(_this_opt_50022);
    return _25662;
L3: 

    /** cominit.e:348		if find( HAS_PARAMETER, this_opt[OPTIONS] ) then*/
    _2 = (object)SEQ_PTR(_this_opt_50022);
    _25663 = (object)*(((s1_ptr)_2)->base + 4);
    _25664 = find_from(112, _25663, 1);
    _25663 = NOVALUE;
    if (_25664 == 0)
    {
        _25664 = NOVALUE;
        goto L4; // [85] 135
    }
    else{
        _25664 = NOVALUE;
    }

    /** cominit.e:349			if ix = length( args ) - 1 then*/
    if (IS_SEQUENCE(_args_50012)){
            _25665 = SEQ_PTR(_args_50012)->length;
    }
    else {
        _25665 = 1;
    }
    _25666 = _25665 - 1;
    _25665 = NOVALUE;
    if (_ix_50013 != _25666)
    goto L5; // [97] 117

    /** cominit.e:351				CompileErr( MISSING_CMD_PARAMETER, { arg } )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_arg_50011);
    ((intptr_t*)_2)[1] = _arg_50011;
    _25668 = MAKE_SEQ(_1);
    _49CompileErr(353, _25668, 0);
    _25668 = NOVALUE;
    goto L6; // [114] 150
L5: 

    /** cominit.e:353				return { ix, ix + 2 }*/
    _25669 = _ix_50013 + 2;
    if ((object)((uintptr_t)_25669 + (uintptr_t)HIGH_BITS) >= 0){
        _25669 = NewDouble((eudouble)_25669);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _ix_50013;
    ((intptr_t *)_2)[2] = _25669;
    _25670 = MAKE_SEQ(_1);
    _25669 = NOVALUE;
    DeRefDS(_arg_50011);
    DeRefDS(_args_50012);
    DeRef(_opt_50014);
    DeRef(_this_opt_50022);
    DeRef(_25666);
    _25666 = NOVALUE;
    DeRef(_25662);
    _25662 = NOVALUE;
    return _25670;
    goto L6; // [132] 150
L4: 

    /** cominit.e:356			return { ix, ix + 1 }*/
    _25671 = _ix_50013 + 1;
    if (_25671 > MAXINT){
        _25671 = NewDouble((eudouble)_25671);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _ix_50013;
    ((intptr_t *)_2)[2] = _25671;
    _25672 = MAKE_SEQ(_1);
    _25671 = NOVALUE;
    DeRefDS(_arg_50011);
    DeRefDS(_args_50012);
    DeRef(_opt_50014);
    DeRef(_this_opt_50022);
    DeRef(_25670);
    _25670 = NOVALUE;
    DeRef(_25666);
    _25666 = NOVALUE;
    DeRef(_25662);
    _25662 = NOVALUE;
    return _25672;
L6: 
    ;
}


object _47find_next_opt(object _ix_50047, object _args_50048)
{
    object _arg_50052 = NOVALUE;
    object _25694 = NOVALUE;
    object _25693 = NOVALUE;
    object _25691 = NOVALUE;
    object _25690 = NOVALUE;
    object _25689 = NOVALUE;
    object _25688 = NOVALUE;
    object _25687 = NOVALUE;
    object _25686 = NOVALUE;
    object _25685 = NOVALUE;
    object _25684 = NOVALUE;
    object _25682 = NOVALUE;
    object _25680 = NOVALUE;
    object _25678 = NOVALUE;
    object _25676 = NOVALUE;
    object _25673 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:374		while ix < length( args ) do*/
L1: 
    if (IS_SEQUENCE(_args_50048)){
            _25673 = SEQ_PTR(_args_50048)->length;
    }
    else {
        _25673 = 1;
    }
    if (_ix_50047 >= _25673)
    goto L2; // [13] 157

    /** cominit.e:375			sequence arg = args[ix]*/
    DeRef(_arg_50052);
    _2 = (object)SEQ_PTR(_args_50048);
    _arg_50052 = (object)*(((s1_ptr)_2)->base + _ix_50047);
    Ref(_arg_50052);

    /** cominit.e:376			if length( arg ) > 1 then*/
    if (IS_SEQUENCE(_arg_50052)){
            _25676 = SEQ_PTR(_arg_50052)->length;
    }
    else {
        _25676 = 1;
    }
    if (_25676 <= 1)
    goto L3; // [30] 129

    /** cominit.e:377				if arg[1] = '-' then*/
    _2 = (object)SEQ_PTR(_arg_50052);
    _25678 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _25678, 45)){
        _25678 = NOVALUE;
        goto L4; // [40] 111
    }
    _25678 = NOVALUE;

    /** cominit.e:378					if arg[2] = '-' then*/
    _2 = (object)SEQ_PTR(_arg_50052);
    _25680 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _25680, 45)){
        _25680 = NOVALUE;
        goto L5; // [50] 94
    }
    _25680 = NOVALUE;

    /** cominit.e:380						if length( arg ) = 2 then*/
    if (IS_SEQUENCE(_arg_50052)){
            _25682 = SEQ_PTR(_arg_50052)->length;
    }
    else {
        _25682 = 1;
    }
    if (_25682 != 2)
    goto L6; // [59] 78

    /** cominit.e:382							return { 0, ix - 1 }*/
    _25684 = _ix_50047 - 1;
    if ((object)((uintptr_t)_25684 +(uintptr_t) HIGH_BITS) >= 0){
        _25684 = NewDouble((eudouble)_25684);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _25684;
    _25685 = MAKE_SEQ(_1);
    _25684 = NOVALUE;
    DeRefDS(_arg_50052);
    DeRefDS(_args_50048);
    return _25685;
L6: 

    /** cominit.e:385						return validate_opt( LONGNAME, arg, args, ix )*/
    RefDS(_arg_50052);
    RefDS(_args_50048);
    _25686 = _47validate_opt(2, _arg_50052, _args_50048, _ix_50047);
    DeRefDS(_arg_50052);
    DeRefDS(_args_50048);
    DeRef(_25685);
    _25685 = NOVALUE;
    return _25686;
    goto L7; // [91] 144
L5: 

    /** cominit.e:389						return validate_opt( SHORTNAME, arg, args, ix )*/
    RefDS(_arg_50052);
    RefDS(_args_50048);
    _25687 = _47validate_opt(1, _arg_50052, _args_50048, _ix_50047);
    DeRefDS(_arg_50052);
    DeRefDS(_args_50048);
    DeRef(_25686);
    _25686 = NOVALUE;
    DeRef(_25685);
    _25685 = NOVALUE;
    return _25687;
    goto L7; // [108] 144
L4: 

    /** cominit.e:393					return {0, ix-1}*/
    _25688 = _ix_50047 - 1;
    if ((object)((uintptr_t)_25688 +(uintptr_t) HIGH_BITS) >= 0){
        _25688 = NewDouble((eudouble)_25688);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _25688;
    _25689 = MAKE_SEQ(_1);
    _25688 = NOVALUE;
    DeRef(_arg_50052);
    DeRefDS(_args_50048);
    DeRef(_25686);
    _25686 = NOVALUE;
    DeRef(_25687);
    _25687 = NOVALUE;
    DeRef(_25685);
    _25685 = NOVALUE;
    return _25689;
    goto L7; // [126] 144
L3: 

    /** cominit.e:397				return { 0, ix-1 }*/
    _25690 = _ix_50047 - 1;
    if ((object)((uintptr_t)_25690 +(uintptr_t) HIGH_BITS) >= 0){
        _25690 = NewDouble((eudouble)_25690);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _25690;
    _25691 = MAKE_SEQ(_1);
    _25690 = NOVALUE;
    DeRef(_arg_50052);
    DeRefDS(_args_50048);
    DeRef(_25686);
    _25686 = NOVALUE;
    DeRef(_25687);
    _25687 = NOVALUE;
    DeRef(_25689);
    _25689 = NOVALUE;
    DeRef(_25685);
    _25685 = NOVALUE;
    return _25691;
L7: 

    /** cominit.e:400			ix += 1*/
    _ix_50047 = _ix_50047 + 1;
    DeRef(_arg_50052);
    _arg_50052 = NOVALUE;

    /** cominit.e:401		end while*/
    goto L1; // [154] 10
L2: 

    /** cominit.e:402		return {0, ix-1}*/
    _25693 = _ix_50047 - 1;
    if ((object)((uintptr_t)_25693 +(uintptr_t) HIGH_BITS) >= 0){
        _25693 = NewDouble((eudouble)_25693);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _25693;
    _25694 = MAKE_SEQ(_1);
    _25693 = NOVALUE;
    DeRefDS(_args_50048);
    DeRef(_25686);
    _25686 = NOVALUE;
    DeRef(_25687);
    _25687 = NOVALUE;
    DeRef(_25691);
    _25691 = NOVALUE;
    DeRef(_25689);
    _25689 = NOVALUE;
    DeRef(_25685);
    _25685 = NOVALUE;
    return _25694;
    ;
}


object _47expand_config_options(object _args_50082)
{
    object _idx_50083 = NOVALUE;
    object _next_idx_50084 = NOVALUE;
    object _files_50085 = NOVALUE;
    object _cmd_1_2_50086 = NOVALUE;
    object _25717 = NOVALUE;
    object _25716 = NOVALUE;
    object _25715 = NOVALUE;
    object _25714 = NOVALUE;
    object _25713 = NOVALUE;
    object _25712 = NOVALUE;
    object _25711 = NOVALUE;
    object _25710 = NOVALUE;
    object _25709 = NOVALUE;
    object _25704 = NOVALUE;
    object _25702 = NOVALUE;
    object _25701 = NOVALUE;
    object _25700 = NOVALUE;
    object _25698 = NOVALUE;
    object _25697 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:410		integer idx = 1*/
    _idx_50083 = 1;

    /** cominit.e:412		sequence files = {}*/
    RefDS(_22015);
    DeRef(_files_50085);
    _files_50085 = _22015;

    /** cominit.e:413		sequence cmd_1_2 = args[1..2]*/
    rhs_slice_target = (object_ptr)&_cmd_1_2_50086;
    RHS_Slice(_args_50082, 1, 2);

    /** cominit.e:414		args = remove( args, 1, 2 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_args_50082);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1)) ? 1 : (object)(DBL_PTR(1)->dbl);
        int stop = (IS_ATOM_INT(2)) ? 2 : (object)(DBL_PTR(2)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_50082), start, &_args_50082 );
            }
            else Tail(SEQ_PTR(_args_50082), stop+1, &_args_50082);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_50082), start, &_args_50082);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_50082 = Remove_elements(start, stop, (SEQ_PTR(_args_50082)->ref == 1));
        }
    }

    /** cominit.e:416		while idx with entry do*/
    goto L1; // [31] 94
L2: 
    if (_idx_50083 == 0)
    {
        goto L3; // [34] 114
    }
    else{
    }

    /** cominit.e:417			if equal(upper(args[idx]), "-C") then*/
    _2 = (object)SEQ_PTR(_args_50082);
    _25697 = (object)*(((s1_ptr)_2)->base + _idx_50083);
    Ref(_25697);
    _25698 = _18upper(_25697);
    _25697 = NOVALUE;
    if (_25698 == _25699)
    _25700 = 1;
    else if (IS_ATOM_INT(_25698) && IS_ATOM_INT(_25699))
    _25700 = 0;
    else
    _25700 = (compare(_25698, _25699) == 0);
    DeRef(_25698);
    _25698 = NOVALUE;
    if (_25700 == 0)
    {
        _25700 = NOVALUE;
        goto L4; // [51] 82
    }
    else{
        _25700 = NOVALUE;
    }

    /** cominit.e:418				files = append( files, args[idx+1] )*/
    _25701 = _idx_50083 + 1;
    _2 = (object)SEQ_PTR(_args_50082);
    _25702 = (object)*(((s1_ptr)_2)->base + _25701);
    Ref(_25702);
    Append(&_files_50085, _files_50085, _25702);
    _25702 = NOVALUE;

    /** cominit.e:419				args = remove( args, idx, idx + 1 )*/
    _25704 = _idx_50083 + 1;
    if (_25704 > MAXINT){
        _25704 = NewDouble((eudouble)_25704);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_args_50082);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_idx_50083)) ? _idx_50083 : (object)(DBL_PTR(_idx_50083)->dbl);
        int stop = (IS_ATOM_INT(_25704)) ? _25704 : (object)(DBL_PTR(_25704)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_50082), start, &_args_50082 );
            }
            else Tail(SEQ_PTR(_args_50082), stop+1, &_args_50082);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_50082), start, &_args_50082);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_50082 = Remove_elements(start, stop, (SEQ_PTR(_args_50082)->ref == 1));
        }
    }
    DeRef(_25704);
    _25704 = NOVALUE;
    goto L5; // [79] 91
L4: 

    /** cominit.e:422				idx = next_idx[2]*/
    _2 = (object)SEQ_PTR(_next_idx_50084);
    _idx_50083 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_idx_50083))
    _idx_50083 = (object)DBL_PTR(_idx_50083)->dbl;
L5: 

    /** cominit.e:424		entry*/
L1: 

    /** cominit.e:425			next_idx = find_next_opt( idx, args )*/
    RefDS(_args_50082);
    _0 = _next_idx_50084;
    _next_idx_50084 = _47find_next_opt(_idx_50083, _args_50082);
    DeRef(_0);

    /** cominit.e:426			idx = next_idx[1]*/
    _2 = (object)SEQ_PTR(_next_idx_50084);
    _idx_50083 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_idx_50083))
    _idx_50083 = (object)DBL_PTR(_idx_50083)->dbl;

    /** cominit.e:427		end while*/
    goto L2; // [111] 34
L3: 

    /** cominit.e:428		return cmd_1_2 & merge_parameters( GetDefaultArgs( files ), args[1..next_idx[2]], options, 1 ) & args[next_idx[2]+1..$]*/
    RefDS(_files_50085);
    _25709 = _46GetDefaultArgs(_files_50085);
    _2 = (object)SEQ_PTR(_next_idx_50084);
    _25710 = (object)*(((s1_ptr)_2)->base + 2);
    rhs_slice_target = (object_ptr)&_25711;
    RHS_Slice(_args_50082, 1, _25710);
    RefDS(_47options_49747);
    _25712 = _47merge_parameters(_25709, _25711, _47options_49747, 1);
    _25709 = NOVALUE;
    _25711 = NOVALUE;
    _2 = (object)SEQ_PTR(_next_idx_50084);
    _25713 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_25713)) {
        _25714 = _25713 + 1;
        if (_25714 > MAXINT){
            _25714 = NewDouble((eudouble)_25714);
        }
    }
    else
    _25714 = binary_op(PLUS, 1, _25713);
    _25713 = NOVALUE;
    if (IS_SEQUENCE(_args_50082)){
            _25715 = SEQ_PTR(_args_50082)->length;
    }
    else {
        _25715 = 1;
    }
    rhs_slice_target = (object_ptr)&_25716;
    RHS_Slice(_args_50082, _25714, _25715);
    {
        object concat_list[3];

        concat_list[0] = _25716;
        concat_list[1] = _25712;
        concat_list[2] = _cmd_1_2_50086;
        Concat_N((object_ptr)&_25717, concat_list, 3);
    }
    DeRefDS(_25716);
    _25716 = NOVALUE;
    DeRef(_25712);
    _25712 = NOVALUE;
    DeRefDS(_args_50082);
    DeRefDS(_next_idx_50084);
    DeRefDS(_files_50085);
    DeRefDS(_cmd_1_2_50086);
    _25710 = NOVALUE;
    DeRef(_25701);
    _25701 = NOVALUE;
    DeRef(_25714);
    _25714 = NOVALUE;
    return _25717;
    ;
}


void _47handle_common_options(object _opts_50117)
{
    object _opt_keys_50118 = NOVALUE;
    object _option_w_50120 = NOVALUE;
    object _key_50124 = NOVALUE;
    object _val_50126 = NOVALUE;
    object _this_warn_50172 = NOVALUE;
    object _auto_add_warn_50174 = NOVALUE;
    object _n_50180 = NOVALUE;
    object _this_warn_50203 = NOVALUE;
    object _auto_add_warn_50205 = NOVALUE;
    object _n_50211 = NOVALUE;
    object _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50248 = NOVALUE;
    object _prompt_inlined_maybe_any_key_at_617_50247 = NOVALUE;
    object _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50261 = NOVALUE;
    object _prompt_inlined_maybe_any_key_at_693_50260 = NOVALUE;
    object _25776 = NOVALUE;
    object _25775 = NOVALUE;
    object _25773 = NOVALUE;
    object _25771 = NOVALUE;
    object _25769 = NOVALUE;
    object _25768 = NOVALUE;
    object _25767 = NOVALUE;
    object _25766 = NOVALUE;
    object _25765 = NOVALUE;
    object _25764 = NOVALUE;
    object _25763 = NOVALUE;
    object _25762 = NOVALUE;
    object _25760 = NOVALUE;
    object _25758 = NOVALUE;
    object _25757 = NOVALUE;
    object _25756 = NOVALUE;
    object _25751 = NOVALUE;
    object _25749 = NOVALUE;
    object _25747 = NOVALUE;
    object _25744 = NOVALUE;
    object _25743 = NOVALUE;
    object _25738 = NOVALUE;
    object _25736 = NOVALUE;
    object _25734 = NOVALUE;
    object _25732 = NOVALUE;
    object _25731 = NOVALUE;
    object _25730 = NOVALUE;
    object _25729 = NOVALUE;
    object _25728 = NOVALUE;
    object _25727 = NOVALUE;
    object _25725 = NOVALUE;
    object _25724 = NOVALUE;
    object _25719 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:435		sequence opt_keys = m:keys(opts)*/
    Ref(_opts_50117);
    _0 = _opt_keys_50118;
    _opt_keys_50118 = _34keys(_opts_50117, 0);
    DeRef(_0);

    /** cominit.e:436		integer option_w = 0*/
    _option_w_50120 = 0;

    /** cominit.e:438		for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_50118)){
            _25719 = SEQ_PTR(_opt_keys_50118)->length;
    }
    else {
        _25719 = 1;
    }
    {
        object _idx_50122;
        _idx_50122 = 1;
L1: 
        if (_idx_50122 > _25719){
            goto L2; // [20] 795
        }

        /** cominit.e:439			sequence key = opt_keys[idx]*/
        DeRef(_key_50124);
        _2 = (object)SEQ_PTR(_opt_keys_50118);
        _key_50124 = (object)*(((s1_ptr)_2)->base + _idx_50122);
        Ref(_key_50124);

        /** cominit.e:440			object val = m:get(opts, key)*/
        Ref(_opts_50117);
        RefDS(_key_50124);
        _0 = _val_50126;
        _val_50126 = _34get(_opts_50117, _key_50124, 0);
        DeRef(_0);

        /** cominit.e:442			switch key do*/
        _1 = find(_key_50124, _25722);
        switch ( _1 ){ 

            /** cominit.e:443				case "i" then*/
            case 1:

            /** cominit.e:444					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50126)){
                    _25724 = SEQ_PTR(_val_50126)->length;
            }
            else {
                _25724 = 1;
            }
            {
                object _i_50132;
                _i_50132 = 1;
L3: 
                if (_i_50132 > _25724){
                    goto L4; // [59] 82
                }

                /** cominit.e:445						add_include_directory(val[i])*/
                _2 = (object)SEQ_PTR(_val_50126);
                _25725 = (object)*(((s1_ptr)_2)->base + _i_50132);
                Ref(_25725);
                _46add_include_directory(_25725);
                _25725 = NOVALUE;

                /** cominit.e:446					end for*/
                _i_50132 = _i_50132 + 1;
                goto L3; // [77] 66
L4: 
                ;
            }
            goto L5; // [82] 786

            /** cominit.e:448				case "d" then*/
            case 2:

            /** cominit.e:449					OpDefines &= val*/
            if (IS_SEQUENCE(_12OpDefines_20300) && IS_ATOM(_val_50126)) {
                Ref(_val_50126);
                Append(&_12OpDefines_20300, _12OpDefines_20300, _val_50126);
            }
            else if (IS_ATOM(_12OpDefines_20300) && IS_SEQUENCE(_val_50126)) {
            }
            else {
                Concat((object_ptr)&_12OpDefines_20300, _12OpDefines_20300, _val_50126);
            }
            goto L5; // [98] 786

            /** cominit.e:451				case "batch" then*/
            case 3:

            /** cominit.e:452					batch_job = 1*/
            _12batch_job_20239 = 1;
            goto L5; // [111] 786

            /** cominit.e:454				case "test" then*/
            case 4:

            /** cominit.e:455					test_only = 1*/
            _12test_only_20238 = 1;
            goto L5; // [124] 786

            /** cominit.e:457				case "strict" then*/
            case 5:

            /** cominit.e:458					Strict_is_on = 1*/
            _12Strict_is_on_20292 = 1;
            goto L5; // [137] 786

            /** cominit.e:460				case "p" then*/
            case 6:

            /** cominit.e:461					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50126)){
                    _25727 = SEQ_PTR(_val_50126)->length;
            }
            else {
                _25727 = 1;
            }
            {
                object _i_50147;
                _i_50147 = 1;
L6: 
                if (_i_50147 > _25727){
                    goto L7; // [148] 173
                }

                /** cominit.e:462						add_preprocessor(val[i])*/
                _2 = (object)SEQ_PTR(_val_50126);
                _25728 = (object)*(((s1_ptr)_2)->base + _i_50147);
                Ref(_25728);
                _63add_preprocessor(_25728, 0, 0);
                _25728 = NOVALUE;

                /** cominit.e:463					end for*/
                _i_50147 = _i_50147 + 1;
                goto L6; // [168] 155
L7: 
                ;
            }
            goto L5; // [173] 786

            /** cominit.e:465				case "pf" then*/
            case 7:

            /** cominit.e:466					force_preprocessor = 1*/
            _13force_preprocessor_11335 = 1;
            goto L5; // [186] 786

            /** cominit.e:468				case "l" then*/
            case 8:

            /** cominit.e:469					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50126)){
                    _25729 = SEQ_PTR(_val_50126)->length;
            }
            else {
                _25729 = 1;
            }
            {
                object _i_50155;
                _i_50155 = 1;
L8: 
                if (_i_50155 > _25729){
                    goto L9; // [197] 238
                }

                /** cominit.e:470						LocalizeQual = append(LocalizeQual, (filter(lower(val[i]), STDFLTR_ALPHA)))*/
                _2 = (object)SEQ_PTR(_val_50126);
                _25730 = (object)*(((s1_ptr)_2)->base + _i_50155);
                Ref(_25730);
                _25731 = _18lower(_25730);
                _25730 = NOVALUE;
                RefDS(_22015);
                RefDS(_5);
                _25732 = _24filter(_25731, _24STDFLTR_ALPHA_4569, _22015, _5);
                _25731 = NOVALUE;
                Ref(_25732);
                Append(&_13LocalizeQual_11336, _13LocalizeQual_11336, _25732);
                DeRef(_25732);
                _25732 = NOVALUE;

                /** cominit.e:471					end for*/
                _i_50155 = _i_50155 + 1;
                goto L8; // [233] 204
L9: 
                ;
            }
            goto L5; // [238] 786

            /** cominit.e:473				case "ldb" then*/
            case 9:

            /** cominit.e:474					LocalDB = val*/
            Ref(_val_50126);
            DeRef(_13LocalDB_11337);
            _13LocalDB_11337 = _val_50126;
            goto L5; // [251] 786

            /** cominit.e:476				case "w" then*/
            case 10:

            /** cominit.e:477					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50126)){
                    _25734 = SEQ_PTR(_val_50126)->length;
            }
            else {
                _25734 = 1;
            }
            {
                object _i_50170;
                _i_50170 = 1;
LA: 
                if (_i_50170 > _25734){
                    goto LB; // [262] 392
                }

                /** cominit.e:478						sequence this_warn = val[i]*/
                DeRef(_this_warn_50172);
                _2 = (object)SEQ_PTR(_val_50126);
                _this_warn_50172 = (object)*(((s1_ptr)_2)->base + _i_50170);
                Ref(_this_warn_50172);

                /** cominit.e:479						integer auto_add_warn = 0*/
                _auto_add_warn_50174 = 0;

                /** cominit.e:480						if this_warn[1] = '+' then*/
                _2 = (object)SEQ_PTR(_this_warn_50172);
                _25736 = (object)*(((s1_ptr)_2)->base + 1);
                if (binary_op_a(NOTEQ, _25736, 43)){
                    _25736 = NOVALUE;
                    goto LC; // [288] 308
                }
                _25736 = NOVALUE;

                /** cominit.e:481							auto_add_warn = 1*/
                _auto_add_warn_50174 = 1;

                /** cominit.e:482							this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_50172)){
                        _25738 = SEQ_PTR(_this_warn_50172)->length;
                }
                else {
                    _25738 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_50172;
                RHS_Slice(_this_warn_50172, 2, _25738);
LC: 

                /** cominit.e:484						integer n = find(this_warn, warning_names)*/
                _n_50180 = find_from(_this_warn_50172, _12warning_names_20271, 1);

                /** cominit.e:485						if n != 0 then*/
                if (_n_50180 == 0)
                goto LD; // [319] 383

                /** cominit.e:486							if auto_add_warn or option_w = 1 then*/
                if (_auto_add_warn_50174 != 0) {
                    goto LE; // [325] 338
                }
                _25743 = (_option_w_50120 == 1);
                if (_25743 == 0)
                {
                    DeRef(_25743);
                    _25743 = NOVALUE;
                    goto LF; // [334] 357
                }
                else{
                    DeRef(_25743);
                    _25743 = NOVALUE;
                }
LE: 

                /** cominit.e:487								OpWarning = or_bits(OpWarning, warning_flags[n])*/
                _2 = (object)SEQ_PTR(_12warning_flags_20269);
                _25744 = (object)*(((s1_ptr)_2)->base + _n_50180);
                {uintptr_t tu;
                     tu = (uintptr_t)_12OpWarning_20294 | (uintptr_t)_25744;
                     _12OpWarning_20294 = MAKE_UINT(tu);
                }
                _25744 = NOVALUE;
                if (!IS_ATOM_INT(_12OpWarning_20294)) {
                    _1 = (object)(DBL_PTR(_12OpWarning_20294)->dbl);
                    DeRefDS(_12OpWarning_20294);
                    _12OpWarning_20294 = _1;
                }
                goto L10; // [354] 373
LF: 

                /** cominit.e:489								option_w = 1*/
                _option_w_50120 = 1;

                /** cominit.e:490								OpWarning = warning_flags[n]*/
                _2 = (object)SEQ_PTR(_12warning_flags_20269);
                _12OpWarning_20294 = (object)*(((s1_ptr)_2)->base + _n_50180);
L10: 

                /** cominit.e:493							prev_OpWarning = OpWarning*/
                _12prev_OpWarning_20295 = _12OpWarning_20294;
LD: 
                DeRef(_this_warn_50172);
                _this_warn_50172 = NOVALUE;

                /** cominit.e:495					end for*/
                _i_50170 = _i_50170 + 1;
                goto LA; // [387] 269
LB: 
                ;
            }
            goto L5; // [392] 786

            /** cominit.e:497				case "x" then*/
            case 11:

            /** cominit.e:498					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50126)){
                    _25747 = SEQ_PTR(_val_50126)->length;
            }
            else {
                _25747 = 1;
            }
            {
                object _i_50201;
                _i_50201 = 1;
L11: 
                if (_i_50201 > _25747){
                    goto L12; // [403] 542
                }

                /** cominit.e:499						sequence this_warn = val[i]*/
                DeRef(_this_warn_50203);
                _2 = (object)SEQ_PTR(_val_50126);
                _this_warn_50203 = (object)*(((s1_ptr)_2)->base + _i_50201);
                Ref(_this_warn_50203);

                /** cominit.e:500						integer auto_add_warn = 0*/
                _auto_add_warn_50205 = 0;

                /** cominit.e:501						if this_warn[1] = '+' then*/
                _2 = (object)SEQ_PTR(_this_warn_50203);
                _25749 = (object)*(((s1_ptr)_2)->base + 1);
                if (binary_op_a(NOTEQ, _25749, 43)){
                    _25749 = NOVALUE;
                    goto L13; // [429] 449
                }
                _25749 = NOVALUE;

                /** cominit.e:502							auto_add_warn = 1*/
                _auto_add_warn_50205 = 1;

                /** cominit.e:503							this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_50203)){
                        _25751 = SEQ_PTR(_this_warn_50203)->length;
                }
                else {
                    _25751 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_50203;
                RHS_Slice(_this_warn_50203, 2, _25751);
L13: 

                /** cominit.e:505						integer n = find(this_warn, warning_names)*/
                _n_50211 = find_from(_this_warn_50203, _12warning_names_20271, 1);

                /** cominit.e:506						if n != 0 then*/
                if (_n_50211 == 0)
                goto L14; // [460] 533

                /** cominit.e:507							if auto_add_warn or option_w = -1 then*/
                if (_auto_add_warn_50205 != 0) {
                    goto L15; // [466] 479
                }
                _25756 = (_option_w_50120 == -1);
                if (_25756 == 0)
                {
                    DeRef(_25756);
                    _25756 = NOVALUE;
                    goto L16; // [475] 501
                }
                else{
                    DeRef(_25756);
                    _25756 = NOVALUE;
                }
L15: 

                /** cominit.e:508								OpWarning = and_bits(OpWarning, not_bits(warning_flags[n]))*/
                _2 = (object)SEQ_PTR(_12warning_flags_20269);
                _25757 = (object)*(((s1_ptr)_2)->base + _n_50211);
                _25758 = not_bits(_25757);
                _25757 = NOVALUE;
                if (IS_ATOM_INT(_25758)) {
                    {uintptr_t tu;
                         tu = (uintptr_t)_12OpWarning_20294 & (uintptr_t)_25758;
                         _12OpWarning_20294 = MAKE_UINT(tu);
                    }
                }
                else {
                    temp_d.dbl = (eudouble)_12OpWarning_20294;
                    _12OpWarning_20294 = Dand_bits(&temp_d, DBL_PTR(_25758));
                }
                DeRef(_25758);
                _25758 = NOVALUE;
                if (!IS_ATOM_INT(_12OpWarning_20294)) {
                    _1 = (object)(DBL_PTR(_12OpWarning_20294)->dbl);
                    DeRefDS(_12OpWarning_20294);
                    _12OpWarning_20294 = _1;
                }
                goto L17; // [498] 523
L16: 

                /** cominit.e:510								option_w = -1*/
                _option_w_50120 = -1;

                /** cominit.e:511								OpWarning = all_warning_flag - warning_flags[n]*/
                _2 = (object)SEQ_PTR(_12warning_flags_20269);
                _25760 = (object)*(((s1_ptr)_2)->base + _n_50211);
                _12OpWarning_20294 = 32767 - _25760;
                _25760 = NOVALUE;
L17: 

                /** cominit.e:514							prev_OpWarning = OpWarning*/
                _12prev_OpWarning_20295 = _12OpWarning_20294;
L14: 
                DeRef(_this_warn_50203);
                _this_warn_50203 = NOVALUE;

                /** cominit.e:516					end for*/
                _i_50201 = _i_50201 + 1;
                goto L11; // [537] 410
L12: 
                ;
            }
            goto L5; // [542] 786

            /** cominit.e:518				case "wf" then*/
            case 12:

            /** cominit.e:519					TempWarningName = val*/
            Ref(_val_50126);
            DeRef(_12TempWarningName_20240);
            _12TempWarningName_20240 = _val_50126;

            /** cominit.e:520				  	error:warning_file(TempWarningName)*/
            Ref(_12TempWarningName_20240);
            _8warning_file(_12TempWarningName_20240);
            goto L5; // [560] 786

            /** cominit.e:522				case "v", "version" then*/
            case 13:
            case 14:

            /** cominit.e:523					show_banner()*/
            _47show_banner();

            /** cominit.e:524					if not batch_job and not test_only then*/
            _25762 = (_12batch_job_20239 == 0);
            if (_25762 == 0) {
                goto L18; // [579] 634
            }
            _25764 = (_12test_only_20238 == 0);
            if (_25764 == 0)
            {
                DeRef(_25764);
                _25764 = NOVALUE;
                goto L18; // [589] 634
            }
            else{
                DeRef(_25764);
                _25764 = NOVALUE;
            }

            /** cominit.e:525						console:maybe_any_key(GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE,0), 2)*/
            RefDS(_22015);
            _25765 = _30GetMsgText(278, 0, _22015);
            DeRef(_prompt_inlined_maybe_any_key_at_617_50247);
            _prompt_inlined_maybe_any_key_at_617_50247 = _25765;
            _25765 = NOVALUE;

            /** console.e:923		if not has_console() then*/

            /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50248);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50248 = machine(99, 0);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50248)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50248 != 0){
                    goto L19; // [616] 631
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50248)->dbl != 0.0){
                    goto L19; // [616] 631
                }
            }

            /** console.e:924			any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_617_50247);
            _38any_key(_prompt_inlined_maybe_any_key_at_617_50247, 2);

            /** console.e:926	end procedure*/
            goto L19; // [628] 631
L19: 
            DeRef(_prompt_inlined_maybe_any_key_at_617_50247);
            _prompt_inlined_maybe_any_key_at_617_50247 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50248);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50248 = NOVALUE;
L18: 

            /** cominit.e:528					abort(0)*/
            UserCleanup(0);
            goto L5; // [638] 786

            /** cominit.e:530				case "copyright" then*/
            case 15:

            /** cominit.e:531					show_copyrights()*/
            _47show_copyrights();

            /** cominit.e:532					if not batch_job and not test_only then*/
            _25766 = (_12batch_job_20239 == 0);
            if (_25766 == 0) {
                goto L1A; // [655] 710
            }
            _25768 = (_12test_only_20238 == 0);
            if (_25768 == 0)
            {
                DeRef(_25768);
                _25768 = NOVALUE;
                goto L1A; // [665] 710
            }
            else{
                DeRef(_25768);
                _25768 = NOVALUE;
            }

            /** cominit.e:533						console:maybe_any_key(GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE,0), 2)*/
            RefDS(_22015);
            _25769 = _30GetMsgText(278, 0, _22015);
            DeRef(_prompt_inlined_maybe_any_key_at_693_50260);
            _prompt_inlined_maybe_any_key_at_693_50260 = _25769;
            _25769 = NOVALUE;

            /** console.e:923		if not has_console() then*/

            /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50261);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50261 = machine(99, 0);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50261)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50261 != 0){
                    goto L1B; // [692] 707
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50261)->dbl != 0.0){
                    goto L1B; // [692] 707
                }
            }

            /** console.e:924			any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_693_50260);
            _38any_key(_prompt_inlined_maybe_any_key_at_693_50260, 2);

            /** console.e:926	end procedure*/
            goto L1B; // [704] 707
L1B: 
            DeRef(_prompt_inlined_maybe_any_key_at_693_50260);
            _prompt_inlined_maybe_any_key_at_693_50260 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50261);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50261 = NOVALUE;
L1A: 

            /** cominit.e:535					abort(0)*/
            UserCleanup(0);
            goto L5; // [714] 786

            /** cominit.e:537				case "eudir" then*/
            case 16:

            /** cominit.e:538					set_eudir( val )*/
            Ref(_val_50126);
            _13set_eudir(_val_50126);
            goto L5; // [725] 786

            /** cominit.e:540				case "trace-lines" then*/
            case 17:

            /** cominit.e:541					val = value( val )*/
            Ref(_val_50126);
            _0 = _val_50126;
            _val_50126 = _16value(_val_50126, 1, _16GET_SHORT_ANSWER_8754);
            DeRef(_0);

            /** cominit.e:542					if val[1] = GET_SUCCESS then*/
            _2 = (object)SEQ_PTR(_val_50126);
            _25771 = (object)*(((s1_ptr)_2)->base + 1);
            if (binary_op_a(NOTEQ, _25771, 0)){
                _25771 = NOVALUE;
                goto L1C; // [749] 767
            }
            _25771 = NOVALUE;

            /** cominit.e:543						trace_lines = floor( val[2] )*/
            _2 = (object)SEQ_PTR(_val_50126);
            _25773 = (object)*(((s1_ptr)_2)->base + 2);
            if (IS_ATOM_INT(_25773))
            _12trace_lines_64535 = e_floor(_25773);
            else
            _12trace_lines_64535 = unary_op(FLOOR, _25773);
            _25773 = NOVALUE;
            if (!IS_ATOM_INT(_12trace_lines_64535)) {
                _1 = (object)(DBL_PTR(_12trace_lines_64535)->dbl);
                DeRefDS(_12trace_lines_64535);
                _12trace_lines_64535 = _1;
            }
            goto L1D; // [764] 785
L1C: 

            /** cominit.e:545						puts(2, GetMsgText( BAD_TRACE_LINES ) )*/
            RefDS(_22015);
            _25775 = _30GetMsgText(604, 1, _22015);
            EPuts(2, _25775); // DJP 
            DeRef(_25775);
            _25775 = NOVALUE;

            /** cominit.e:546						abort( 1 )*/
            UserCleanup(1);
L1D: 
        ;}L5: 
        DeRef(_key_50124);
        _key_50124 = NOVALUE;
        DeRef(_val_50126);
        _val_50126 = NOVALUE;

        /** cominit.e:549		end for*/
        _idx_50122 = _idx_50122 + 1;
        goto L1; // [790] 27
L2: 
        ;
    }

    /** cominit.e:551		if length(LocalizeQual) = 0 then*/
    if (IS_SEQUENCE(_13LocalizeQual_11336)){
            _25776 = SEQ_PTR(_13LocalizeQual_11336)->length;
    }
    else {
        _25776 = 1;
    }
    if (_25776 != 0)
    goto L1E; // [802] 815

    /** cominit.e:552			LocalizeQual = {"en"}*/
    _0 = _13LocalizeQual_11336;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_25778);
    ((intptr_t*)_2)[1] = _25778;
    _13LocalizeQual_11336 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1E: 

    /** cominit.e:554	end procedure*/
    DeRef(_opts_50117);
    DeRef(_opt_keys_50118);
    DeRef(_25766);
    _25766 = NOVALUE;
    DeRef(_25762);
    _25762 = NOVALUE;
    return;
    ;
}


void _47finalize_command_line(object _opts_50287)
{
    object _extras_50294 = NOVALUE;
    object _pairs_50299 = NOVALUE;
    object _pair_50304 = NOVALUE;
    object _25808 = NOVALUE;
    object _25806 = NOVALUE;
    object _25803 = NOVALUE;
    object _25802 = NOVALUE;
    object _25801 = NOVALUE;
    object _25800 = NOVALUE;
    object _25799 = NOVALUE;
    object _25798 = NOVALUE;
    object _25797 = NOVALUE;
    object _25796 = NOVALUE;
    object _25795 = NOVALUE;
    object _25794 = NOVALUE;
    object _25793 = NOVALUE;
    object _25792 = NOVALUE;
    object _25791 = NOVALUE;
    object _25790 = NOVALUE;
    object _25789 = NOVALUE;
    object _25788 = NOVALUE;
    object _25787 = NOVALUE;
    object _25786 = NOVALUE;
    object _25784 = NOVALUE;
    object _25781 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:562		if Strict_is_on then -- overrides any -W/-X switches*/
    if (_12Strict_is_on_20292 == 0)
    {
        goto L1; // [5] 27
    }
    else{
    }

    /** cominit.e:563			OpWarning = all_warning_flag*/
    _12OpWarning_20294 = 32767;

    /** cominit.e:564			prev_OpWarning = OpWarning*/
    _12prev_OpWarning_20295 = 32767;
L1: 

    /** cominit.e:569		sequence extras = m:get(opts, cmdline:EXTRAS)*/
    Ref(_opts_50287);
    RefDS(_48EXTRAS_20639);
    _0 = _extras_50294;
    _extras_50294 = _34get(_opts_50287, _48EXTRAS_20639, 0);
    DeRef(_0);

    /** cominit.e:570		if length(extras) > 0 then*/
    if (IS_SEQUENCE(_extras_50294)){
            _25781 = SEQ_PTR(_extras_50294)->length;
    }
    else {
        _25781 = 1;
    }
    if (_25781 <= 0)
    goto L2; // [44] 270

    /** cominit.e:571			sequence pairs = m:pairs( opts )*/
    Ref(_opts_50287);
    _0 = _pairs_50299;
    _pairs_50299 = _34pairs(_opts_50287, 0);
    DeRef(_0);

    /** cominit.e:573			for i = 1 to length( pairs ) do*/
    if (IS_SEQUENCE(_pairs_50299)){
            _25784 = SEQ_PTR(_pairs_50299)->length;
    }
    else {
        _25784 = 1;
    }
    {
        object _i_50302;
        _i_50302 = 1;
L3: 
        if (_i_50302 > _25784){
            goto L4; // [62] 237
        }

        /** cominit.e:574				sequence pair = pairs[i]*/
        DeRef(_pair_50304);
        _2 = (object)SEQ_PTR(_pairs_50299);
        _pair_50304 = (object)*(((s1_ptr)_2)->base + _i_50302);
        Ref(_pair_50304);

        /** cominit.e:575				if equal( pair[1], cmdline:EXTRAS ) then*/
        _2 = (object)SEQ_PTR(_pair_50304);
        _25786 = (object)*(((s1_ptr)_2)->base + 1);
        if (_25786 == _48EXTRAS_20639)
        _25787 = 1;
        else if (IS_ATOM_INT(_25786) && IS_ATOM_INT(_48EXTRAS_20639))
        _25787 = 0;
        else
        _25787 = (compare(_25786, _48EXTRAS_20639) == 0);
        _25786 = NOVALUE;
        if (_25787 == 0)
        {
            _25787 = NOVALUE;
            goto L5; // [89] 99
        }
        else{
            _25787 = NOVALUE;
        }

        /** cominit.e:576					continue*/
        DeRefDS(_pair_50304);
        _pair_50304 = NOVALUE;
        goto L6; // [96] 232
L5: 

        /** cominit.e:578				pair[1] = prepend( pair[1], '-' )*/
        _2 = (object)SEQ_PTR(_pair_50304);
        _25788 = (object)*(((s1_ptr)_2)->base + 1);
        Prepend(&_25789, _25788, 45);
        _25788 = NOVALUE;
        _2 = (object)SEQ_PTR(_pair_50304);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _pair_50304 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _25789;
        if( _1 != _25789 ){
            DeRef(_1);
        }
        _25789 = NOVALUE;

        /** cominit.e:579				if sequence( pair[2] ) then*/
        _2 = (object)SEQ_PTR(_pair_50304);
        _25790 = (object)*(((s1_ptr)_2)->base + 2);
        _25791 = IS_SEQUENCE(_25790);
        _25790 = NOVALUE;
        if (_25791 == 0)
        {
            _25791 = NOVALUE;
            goto L7; // [122] 215
        }
        else{
            _25791 = NOVALUE;
        }

        /** cominit.e:580					if length( pair[2] ) and sequence( pair[2][1] ) then*/
        _2 = (object)SEQ_PTR(_pair_50304);
        _25792 = (object)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_25792)){
                _25793 = SEQ_PTR(_25792)->length;
        }
        else {
            _25793 = 1;
        }
        _25792 = NOVALUE;
        if (_25793 == 0) {
            goto L8; // [134] 203
        }
        _2 = (object)SEQ_PTR(_pair_50304);
        _25795 = (object)*(((s1_ptr)_2)->base + 2);
        _2 = (object)SEQ_PTR(_25795);
        _25796 = (object)*(((s1_ptr)_2)->base + 1);
        _25795 = NOVALUE;
        _25797 = IS_SEQUENCE(_25796);
        _25796 = NOVALUE;
        if (_25797 == 0)
        {
            _25797 = NOVALUE;
            goto L8; // [150] 203
        }
        else{
            _25797 = NOVALUE;
        }

        /** cominit.e:581						for j = 1 to length( pair[2] ) do*/
        _2 = (object)SEQ_PTR(_pair_50304);
        _25798 = (object)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_25798)){
                _25799 = SEQ_PTR(_25798)->length;
        }
        else {
            _25799 = 1;
        }
        _25798 = NOVALUE;
        {
            object _j_50322;
            _j_50322 = 1;
L9: 
            if (_j_50322 > _25799){
                goto LA; // [162] 200
            }

            /** cominit.e:582							switches &= { pair[1], pair[2][j] }*/
            _2 = (object)SEQ_PTR(_pair_50304);
            _25800 = (object)*(((s1_ptr)_2)->base + 1);
            _2 = (object)SEQ_PTR(_pair_50304);
            _25801 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_25801);
            _25802 = (object)*(((s1_ptr)_2)->base + _j_50322);
            _25801 = NOVALUE;
            Ref(_25802);
            Ref(_25800);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _25800;
            ((intptr_t *)_2)[2] = _25802;
            _25803 = MAKE_SEQ(_1);
            _25802 = NOVALUE;
            _25800 = NOVALUE;
            Concat((object_ptr)&_47switches_49620, _47switches_49620, _25803);
            DeRefDS(_25803);
            _25803 = NOVALUE;

            /** cominit.e:583						end for*/
            _j_50322 = _j_50322 + 1;
            goto L9; // [195] 169
LA: 
            ;
        }
        goto LB; // [200] 228
L8: 

        /** cominit.e:585						switches &= pair*/
        Concat((object_ptr)&_47switches_49620, _47switches_49620, _pair_50304);
        goto LB; // [212] 228
L7: 

        /** cominit.e:588					switches = append( switches, pair[1] )*/
        _2 = (object)SEQ_PTR(_pair_50304);
        _25806 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_25806);
        Append(&_47switches_49620, _47switches_49620, _25806);
        _25806 = NOVALUE;
LB: 
        DeRef(_pair_50304);
        _pair_50304 = NOVALUE;

        /** cominit.e:590			end for*/
L6: 
        _i_50302 = _i_50302 + 1;
        goto L3; // [232] 69
L4: 
        ;
    }

    /** cominit.e:592			Argv = Argv[2..3] & extras*/
    rhs_slice_target = (object_ptr)&_25808;
    RHS_Slice(_12Argv_20237, 2, 3);
    Concat((object_ptr)&_12Argv_20237, _25808, _extras_50294);
    DeRefDS(_25808);
    _25808 = NOVALUE;
    DeRef(_25808);
    _25808 = NOVALUE;

    /** cominit.e:593			Argc = length(Argv)*/
    if (IS_SEQUENCE(_12Argv_20237)){
            _12Argc_20236 = SEQ_PTR(_12Argv_20237)->length;
    }
    else {
        _12Argc_20236 = 1;
    }

    /** cominit.e:595			src_name = extras[1]*/
    DeRef(_47src_name_49619);
    _2 = (object)SEQ_PTR(_extras_50294);
    _47src_name_49619 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_47src_name_49619);
L2: 
    DeRef(_pairs_50299);
    _pairs_50299 = NOVALUE;

    /** cominit.e:597	end procedure*/
    DeRef(_opts_50287);
    DeRef(_extras_50294);
    _25798 = NOVALUE;
    _25792 = NOVALUE;
    return;
    ;
}



// 0xE79DF5A0
