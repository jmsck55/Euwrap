// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _61set_qualified_fwd(object _fwd_25615)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_fwd_25615)) {
        _1 = (object)(DBL_PTR(_fwd_25615)->dbl);
        DeRefDS(_fwd_25615);
        _fwd_25615 = _1;
    }

    /** scanner.e:104		qualified_fwd = fwd*/
    _61qualified_fwd_25612 = _fwd_25615;

    /** scanner.e:105	end procedure*/
    return;
    ;
}


object _61get_qualified_fwd()
{
    object _fwd_25618 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:108		integer fwd = qualified_fwd*/
    _fwd_25618 = _61qualified_fwd_25612;

    /** scanner.e:109		set_qualified_fwd( -1 )*/

    /** scanner.e:104		qualified_fwd = fwd*/
    _61qualified_fwd_25612 = -1;

    /** scanner.e:105	end procedure*/
    goto L1; // [17] 20
L1: 

    /** scanner.e:110		return fwd*/
    return _fwd_25618;
    ;
}


void _61InitLex()
{
    object _14277 = NOVALUE;
    object _14276 = NOVALUE;
    object _14275 = NOVALUE;
    object _14273 = NOVALUE;
    object _14272 = NOVALUE;
    object _14271 = NOVALUE;
    object _14270 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:117		gline_number = 0*/
    _12gline_number_20231 = 0;

    /** scanner.e:118		line_number = 0*/
    _12line_number_20227 = 0;

    /** scanner.e:119		IncludeStk = {}*/
    RefDS(_5);
    DeRef(_61IncludeStk_25589);
    _61IncludeStk_25589 = _5;

    /** scanner.e:120		char_class = repeat(ILLEGAL_CHAR, 255)  -- we screen out the 0 character*/
    DeRefi(_61char_class_25587);
    _61char_class_25587 = Repeat(-20, 255);

    /** scanner.e:122		char_class['0'..'9'] = DIGIT*/
    assign_slice_seq = (s1_ptr *)&_61char_class_25587;
    AssignSlice(48, 57, -7);

    /** scanner.e:123		char_class['_']      = DIGIT*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 95);
    *(intptr_t *)_2 = -7;

    /** scanner.e:124		char_class['a'..'z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_61char_class_25587;
    AssignSlice(97, 122, -2);

    /** scanner.e:125		char_class['A'..'Z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_61char_class_25587;
    AssignSlice(65, 90, -2);

    /** scanner.e:126		char_class[KEYWORD_BASE+1..KEYWORD_BASE+NUM_KEYWORDS] = KEYWORD*/
    _14270 = 129;
    _14271 = 152;
    assign_slice_seq = (s1_ptr *)&_61char_class_25587;
    AssignSlice(129, 152, -10);
    _14270 = NOVALUE;
    _14271 = NOVALUE;

    /** scanner.e:127		char_class[BUILTIN_BASE+1..BUILTIN_BASE+NUM_BUILTINS] = BUILTIN*/
    _14272 = 171;
    _14273 = 234;
    assign_slice_seq = (s1_ptr *)&_61char_class_25587;
    AssignSlice(171, 234, -9);
    _14272 = NOVALUE;
    _14273 = NOVALUE;

    /** scanner.e:129		char_class[' '] = BLANK*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 32);
    *(intptr_t *)_2 = -8;

    /** scanner.e:130		char_class['\t'] = BLANK*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 9);
    *(intptr_t *)_2 = -8;

    /** scanner.e:131		char_class['+'] = PLUS*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 43);
    *(intptr_t *)_2 = 11;

    /** scanner.e:132		char_class['-'] = MINUS*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 45);
    *(intptr_t *)_2 = 10;

    /** scanner.e:133		char_class['*'] = res:MULTIPLY*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 42);
    *(intptr_t *)_2 = 13;

    /** scanner.e:134		char_class['/'] = res:DIVIDE*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 47);
    *(intptr_t *)_2 = 14;

    /** scanner.e:135		char_class['='] = EQUALS*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 61);
    *(intptr_t *)_2 = 3;

    /** scanner.e:136		char_class['<'] = LESS*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 60);
    *(intptr_t *)_2 = 1;

    /** scanner.e:137		char_class['>'] = GREATER*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 62);
    *(intptr_t *)_2 = 6;

    /** scanner.e:138		char_class['\''] = SINGLE_QUOTE*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 39);
    *(intptr_t *)_2 = -5;

    /** scanner.e:139		char_class['"'] = DOUBLE_QUOTE*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 34);
    *(intptr_t *)_2 = -4;

    /** scanner.e:140		char_class['`'] = BACK_QUOTE*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 96);
    *(intptr_t *)_2 = -12;

    /** scanner.e:141		char_class['.'] = DOT*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 46);
    *(intptr_t *)_2 = -3;

    /** scanner.e:142		char_class[':'] = COLON*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 58);
    *(intptr_t *)_2 = -23;

    /** scanner.e:143		char_class['\r'] = NEWLINE*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 13);
    *(intptr_t *)_2 = -6;

    /** scanner.e:144		char_class['\n'] = NEWLINE*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 10);
    *(intptr_t *)_2 = -6;

    /** scanner.e:145		char_class['!'] = BANG*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 33);
    *(intptr_t *)_2 = -1;

    /** scanner.e:146		char_class['{'] = LEFT_BRACE*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 123);
    *(intptr_t *)_2 = -24;

    /** scanner.e:147		char_class['}'] = RIGHT_BRACE*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 125);
    *(intptr_t *)_2 = -25;

    /** scanner.e:148		char_class['('] = LEFT_ROUND*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 40);
    *(intptr_t *)_2 = -26;

    /** scanner.e:149		char_class[')'] = RIGHT_ROUND*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 41);
    *(intptr_t *)_2 = -27;

    /** scanner.e:150		char_class['['] = LEFT_SQUARE*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 91);
    *(intptr_t *)_2 = -28;

    /** scanner.e:151		char_class[']'] = RIGHT_SQUARE*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 93);
    *(intptr_t *)_2 = -29;

    /** scanner.e:152		char_class['$'] = DOLLAR*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 36);
    *(intptr_t *)_2 = -22;

    /** scanner.e:153		char_class[','] = COMMA*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 44);
    *(intptr_t *)_2 = -30;

    /** scanner.e:154		char_class['&'] = res:CONCAT*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 38);
    *(intptr_t *)_2 = 15;

    /** scanner.e:155		char_class['?'] = QUESTION_MARK*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 63);
    *(intptr_t *)_2 = -31;

    /** scanner.e:156		char_class['#'] = NUMBER_SIGN*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 35);
    *(intptr_t *)_2 = -11;

    /** scanner.e:159		char_class[END_OF_FILE_CHAR] = END_OF_FILE*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _2 = (object)(((s1_ptr)_2)->base + 26);
    *(intptr_t *)_2 = -21;

    /** scanner.e:162		id_char = repeat(FALSE, 255)*/
    DeRefi(_61id_char_25588);
    _61id_char_25588 = Repeat(_9FALSE_444, 255);

    /** scanner.e:163		for i = 1 to 255 do*/
    {
        object _i_25666;
        _i_25666 = 1;
L1: 
        if (_i_25666 > 255){
            goto L2; // [407] 456
        }

        /** scanner.e:164			if find(char_class[i], {LETTER, DIGIT}) then*/
        _2 = (object)SEQ_PTR(_61char_class_25587);
        _14275 = (object)*(((s1_ptr)_2)->base + _i_25666);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -2;
        ((intptr_t *)_2)[2] = -7;
        _14276 = MAKE_SEQ(_1);
        _14277 = find_from(_14275, _14276, 1);
        _14275 = NOVALUE;
        DeRefDS(_14276);
        _14276 = NOVALUE;
        if (_14277 == 0)
        {
            _14277 = NOVALUE;
            goto L3; // [435] 449
        }
        else{
            _14277 = NOVALUE;
        }

        /** scanner.e:165				id_char[i] = TRUE*/
        _2 = (object)SEQ_PTR(_61id_char_25588);
        _2 = (object)(((s1_ptr)_2)->base + _i_25666);
        *(intptr_t *)_2 = _9TRUE_446;
L3: 

        /** scanner.e:167		end for*/
        _i_25666 = _i_25666 + 1;
        goto L1; // [451] 414
L2: 
        ;
    }

    /** scanner.e:169		default_namespaces = {0}*/
    _0 = _61default_namespaces_25586;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    _61default_namespaces_25586 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:170	end procedure*/
    return;
    ;
}


void _61ResetTP()
{
    object _0, _1, _2;
    

    /** scanner.e:174		OpTrace = FALSE*/
    _12OpTrace_20296 = _9FALSE_444;

    /** scanner.e:175		OpProfileStatement = FALSE*/
    _12OpProfileStatement_20298 = _9FALSE_444;

    /** scanner.e:176		OpProfileTime = FALSE*/
    _12OpProfileTime_20299 = _9FALSE_444;

    /** scanner.e:177		AnyStatementProfile = FALSE*/
    _13AnyStatementProfile_11340 = _9FALSE_444;

    /** scanner.e:178		AnyTimeProfile = FALSE*/
    _13AnyTimeProfile_11339 = _9FALSE_444;

    /** scanner.e:179	end procedure*/
    return;
    ;
}


object _61pack_source(object _src_25695)
{
    object _start_25696 = NOVALUE;
    object _14300 = NOVALUE;
    object _14299 = NOVALUE;
    object _14298 = NOVALUE;
    object _14297 = NOVALUE;
    object _14295 = NOVALUE;
    object _14293 = NOVALUE;
    object _14292 = NOVALUE;
    object _14291 = NOVALUE;
    object _14287 = NOVALUE;
    object _14285 = NOVALUE;
    object _14284 = NOVALUE;
    object _14281 = NOVALUE;
    object _14280 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:197		if equal(src, 0) then*/
    if (_src_25695 == 0)
    _14280 = 1;
    else if (IS_ATOM_INT(_src_25695) && IS_ATOM_INT(0))
    _14280 = 0;
    else
    _14280 = (compare(_src_25695, 0) == 0);
    if (_14280 == 0)
    {
        _14280 = NOVALUE;
        goto L1; // [7] 17
    }
    else{
        _14280 = NOVALUE;
    }

    /** scanner.e:198			return 0*/
    DeRef(_src_25695);
    return 0;
L1: 

    /** scanner.e:201		if length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_25695)){
            _14281 = SEQ_PTR(_src_25695)->length;
    }
    else {
        _14281 = 1;
    }
    if (_14281 < 10000)
    goto L2; // [22] 34

    /** scanner.e:202			src = src[1..100] -- enough for trace or profile display*/
    rhs_slice_target = (object_ptr)&_src_25695;
    RHS_Slice(_src_25695, 1, 100);
L2: 

    /** scanner.e:205		if current_source_next + length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_25695)){
            _14284 = SEQ_PTR(_src_25695)->length;
    }
    else {
        _14284 = 1;
    }
    _14285 = _61current_source_next_25691 + _14284;
    if ((object)((uintptr_t)_14285 + (uintptr_t)HIGH_BITS) >= 0){
        _14285 = NewDouble((eudouble)_14285);
    }
    _14284 = NOVALUE;
    if (binary_op_a(LESS, _14285, 10000)){
        DeRef(_14285);
        _14285 = NOVALUE;
        goto L3; // [45] 96
    }
    DeRef(_14285);
    _14285 = NOVALUE;

    /** scanner.e:207			current_source = allocate(SOURCE_CHUNK + LINE_BUFLEN)*/
    _14287 = 10400;
    _0 = _4allocate(10400, 0);
    DeRef(_61current_source_25690);
    _61current_source_25690 = _0;
    _14287 = NOVALUE;

    /** scanner.e:208			if current_source = 0 then*/
    if (binary_op_a(NOTEQ, _61current_source_25690, 0)){
        goto L4; // [64] 78
    }

    /** scanner.e:209				CompileErr(OUT_OF_MEMORY__TURN_OFF_TRACE_AND_PROFILE)*/
    RefDS(_22015);
    _49CompileErr(123, _22015, 0);
L4: 

    /** scanner.e:211			all_source = append(all_source, current_source)*/
    Ref(_61current_source_25690);
    Append(&_13all_source_11341, _13all_source_11341, _61current_source_25690);

    /** scanner.e:213			current_source_next = 1*/
    _61current_source_next_25691 = 1;
L3: 

    /** scanner.e:216		start = current_source_next*/
    _start_25696 = _61current_source_next_25691;

    /** scanner.e:217		poke(current_source+current_source_next, src)*/
    if (IS_ATOM_INT(_61current_source_25690)) {
        _14291 = _61current_source_25690 + _61current_source_next_25691;
        if ((object)((uintptr_t)_14291 + (uintptr_t)HIGH_BITS) >= 0){
            _14291 = NewDouble((eudouble)_14291);
        }
    }
    else {
        _14291 = NewDouble(DBL_PTR(_61current_source_25690)->dbl + (eudouble)_61current_source_next_25691);
    }
    if (IS_ATOM_INT(_14291)){
        poke_addr = (uint8_t *)_14291;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_14291)->dbl);
    }
    if (IS_ATOM_INT(_src_25695)) {
        *poke_addr = (uint8_t)_src_25695;
    }
    else if (IS_ATOM(_src_25695)) {
        *poke_addr = (uint8_t)DBL_PTR(_src_25695)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_src_25695);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke_addr++ = (uint8_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_14291);
    _14291 = NOVALUE;

    /** scanner.e:218		current_source_next += length(src)-1*/
    if (IS_SEQUENCE(_src_25695)){
            _14292 = SEQ_PTR(_src_25695)->length;
    }
    else {
        _14292 = 1;
    }
    _14293 = _14292 - 1;
    _14292 = NOVALUE;
    _61current_source_next_25691 = _61current_source_next_25691 + _14293;
    _14293 = NOVALUE;

    /** scanner.e:219		poke(current_source+current_source_next, 0) -- overwrite \n*/
    if (IS_ATOM_INT(_61current_source_25690)) {
        _14295 = _61current_source_25690 + _61current_source_next_25691;
        if ((object)((uintptr_t)_14295 + (uintptr_t)HIGH_BITS) >= 0){
            _14295 = NewDouble((eudouble)_14295);
        }
    }
    else {
        _14295 = NewDouble(DBL_PTR(_61current_source_25690)->dbl + (eudouble)_61current_source_next_25691);
    }
    if (IS_ATOM_INT(_14295)){
        poke_addr = (uint8_t *)_14295;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_14295)->dbl);
    }
    *poke_addr = (uint8_t)0;
    DeRef(_14295);
    _14295 = NOVALUE;

    /** scanner.e:220		current_source_next += 1*/
    _61current_source_next_25691 = _61current_source_next_25691 + 1;

    /** scanner.e:221		return start + SOURCE_CHUNK * (length(all_source)-1)*/
    if (IS_SEQUENCE(_13all_source_11341)){
            _14297 = SEQ_PTR(_13all_source_11341)->length;
    }
    else {
        _14297 = 1;
    }
    _14298 = _14297 - 1;
    _14297 = NOVALUE;
    if (_14298 <= INT15){
        _14299 = 10000 * _14298;
    }
    else{
        _14299 = NewDouble(10000 * (eudouble)_14298);
    }
    _14298 = NOVALUE;
    if (IS_ATOM_INT(_14299)) {
        _14300 = _start_25696 + _14299;
        if ((object)((uintptr_t)_14300 + (uintptr_t)HIGH_BITS) >= 0){
            _14300 = NewDouble((eudouble)_14300);
        }
    }
    else {
        _14300 = NewDouble((eudouble)_start_25696 + DBL_PTR(_14299)->dbl);
    }
    DeRef(_14299);
    _14299 = NOVALUE;
    DeRef(_src_25695);
    return _14300;
    ;
}


object _61fetch_line(object _start_25730)
{
    object _line_25731 = NOVALUE;
    object _memdata_25732 = NOVALUE;
    object _c_25733 = NOVALUE;
    object _chunk_25734 = NOVALUE;
    object _p_25735 = NOVALUE;
    object _n_25736 = NOVALUE;
    object _m_25737 = NOVALUE;
    object _14325 = NOVALUE;
    object _14324 = NOVALUE;
    object _14322 = NOVALUE;
    object _14320 = NOVALUE;
    object _14314 = NOVALUE;
    object _14312 = NOVALUE;
    object _14308 = NOVALUE;
    object _14306 = NOVALUE;
    object _14303 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_25730)) {
        _1 = (object)(DBL_PTR(_start_25730)->dbl);
        DeRefDS(_start_25730);
        _start_25730 = _1;
    }

    /** scanner.e:234		if start = 0 then*/
    if (_start_25730 != 0)
    goto L1; // [5] 16

    /** scanner.e:235			return ""*/
    RefDS(_5);
    DeRef(_line_25731);
    DeRefi(_memdata_25732);
    DeRef(_p_25735);
    return _5;
L1: 

    /** scanner.e:237		line = repeat(0, LINE_BUFLEN)*/
    DeRef(_line_25731);
    _line_25731 = Repeat(0, 400);

    /** scanner.e:238		n = 0*/
    _n_25736 = 0;

    /** scanner.e:239		chunk = 1+floor(start / SOURCE_CHUNK)*/
    if (10000 > 0 && _start_25730 >= 0) {
        _14303 = _start_25730 / 10000;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_start_25730 / (eudouble)10000);
        _14303 = (object)temp_dbl;
    }
    _chunk_25734 = _14303 + 1;
    _14303 = NOVALUE;

    /** scanner.e:240		start = remainder(start, SOURCE_CHUNK)*/
    _start_25730 = (_start_25730 % 10000);

    /** scanner.e:241		p = all_source[chunk] + start*/
    _2 = (object)SEQ_PTR(_13all_source_11341);
    _14306 = (object)*(((s1_ptr)_2)->base + _chunk_25734);
    DeRef(_p_25735);
    if (IS_ATOM_INT(_14306)) {
        _p_25735 = _14306 + _start_25730;
        if ((object)((uintptr_t)_p_25735 + (uintptr_t)HIGH_BITS) >= 0){
            _p_25735 = NewDouble((eudouble)_p_25735);
        }
    }
    else {
        _p_25735 = NewDouble(DBL_PTR(_14306)->dbl + (eudouble)_start_25730);
    }
    _14306 = NOVALUE;

    /** scanner.e:242		memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_25735);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _p_25735;
    ((intptr_t *)_2)[2] = 400;
    _14308 = MAKE_SEQ(_1);
    DeRefi(_memdata_25732);
    _1 = (object)SEQ_PTR(_14308);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _memdata_25732 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_14308);
    _14308 = NOVALUE;

    /** scanner.e:243		p += LINE_BUFLEN*/
    _0 = _p_25735;
    if (IS_ATOM_INT(_p_25735)) {
        _p_25735 = _p_25735 + 400;
        if ((object)((uintptr_t)_p_25735 + (uintptr_t)HIGH_BITS) >= 0){
            _p_25735 = NewDouble((eudouble)_p_25735);
        }
    }
    else {
        _p_25735 = NewDouble(DBL_PTR(_p_25735)->dbl + (eudouble)400);
    }
    DeRef(_0);

    /** scanner.e:244		m = 0*/
    _m_25737 = 0;

    /** scanner.e:245		while TRUE do*/
L2: 
    if (_9TRUE_446 == 0)
    {
        goto L3; // [84] 179
    }
    else{
    }

    /** scanner.e:246			m += 1*/
    _m_25737 = _m_25737 + 1;

    /** scanner.e:247			if m > length(memdata) then*/
    if (IS_SEQUENCE(_memdata_25732)){
            _14312 = SEQ_PTR(_memdata_25732)->length;
    }
    else {
        _14312 = 1;
    }
    if (_m_25737 <= _14312)
    goto L4; // [98] 125

    /** scanner.e:248				memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_25735);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _p_25735;
    ((intptr_t *)_2)[2] = 400;
    _14314 = MAKE_SEQ(_1);
    DeRefDSi(_memdata_25732);
    _1 = (object)SEQ_PTR(_14314);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _memdata_25732 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_14314);
    _14314 = NOVALUE;

    /** scanner.e:249				p += LINE_BUFLEN*/
    _0 = _p_25735;
    if (IS_ATOM_INT(_p_25735)) {
        _p_25735 = _p_25735 + 400;
        if ((object)((uintptr_t)_p_25735 + (uintptr_t)HIGH_BITS) >= 0){
            _p_25735 = NewDouble((eudouble)_p_25735);
        }
    }
    else {
        _p_25735 = NewDouble(DBL_PTR(_p_25735)->dbl + (eudouble)400);
    }
    DeRef(_0);

    /** scanner.e:250				m = 1*/
    _m_25737 = 1;
L4: 

    /** scanner.e:252			c = memdata[m]*/
    _2 = (object)SEQ_PTR(_memdata_25732);
    _c_25733 = (object)*(((s1_ptr)_2)->base + _m_25737);

    /** scanner.e:253			if c = 0 then*/
    if (_c_25733 != 0)
    goto L5; // [133] 142

    /** scanner.e:254				exit*/
    goto L3; // [139] 179
L5: 

    /** scanner.e:256			n += 1*/
    _n_25736 = _n_25736 + 1;

    /** scanner.e:257			if n > length(line) then*/
    if (IS_SEQUENCE(_line_25731)){
            _14320 = SEQ_PTR(_line_25731)->length;
    }
    else {
        _14320 = 1;
    }
    if (_n_25736 <= _14320)
    goto L6; // [153] 168

    /** scanner.e:258				line &= repeat(0, LINE_BUFLEN)*/
    _14322 = Repeat(0, 400);
    Concat((object_ptr)&_line_25731, _line_25731, _14322);
    DeRefDS(_14322);
    _14322 = NOVALUE;
L6: 

    /** scanner.e:260			line[n] = c*/
    _2 = (object)SEQ_PTR(_line_25731);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _line_25731 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _n_25736);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _c_25733;
    DeRef(_1);

    /** scanner.e:261		end while*/
    goto L2; // [176] 82
L3: 

    /** scanner.e:262		line = remove( line, n+1, length( line ) )*/
    _14324 = _n_25736 + 1;
    if (_14324 > MAXINT){
        _14324 = NewDouble((eudouble)_14324);
    }
    if (IS_SEQUENCE(_line_25731)){
            _14325 = SEQ_PTR(_line_25731)->length;
    }
    else {
        _14325 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_line_25731);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_14324)) ? _14324 : (object)(DBL_PTR(_14324)->dbl);
        int stop = (IS_ATOM_INT(_14325)) ? _14325 : (object)(DBL_PTR(_14325)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_line_25731), start, &_line_25731 );
            }
            else Tail(SEQ_PTR(_line_25731), stop+1, &_line_25731);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_line_25731), start, &_line_25731);
        }
        else {
            assign_slice_seq = &assign_space;
            _line_25731 = Remove_elements(start, stop, (SEQ_PTR(_line_25731)->ref == 1));
        }
    }
    DeRef(_14324);
    _14324 = NOVALUE;
    _14325 = NOVALUE;

    /** scanner.e:263		return line*/
    DeRefi(_memdata_25732);
    DeRef(_p_25735);
    return _line_25731;
    ;
}


void _61AppendSourceLine()
{
    object _new_25773 = NOVALUE;
    object _old_25774 = NOVALUE;
    object _options_25775 = NOVALUE;
    object _src_25776 = NOVALUE;
    object _14366 = NOVALUE;
    object _14362 = NOVALUE;
    object _14360 = NOVALUE;
    object _14359 = NOVALUE;
    object _14356 = NOVALUE;
    object _14355 = NOVALUE;
    object _14354 = NOVALUE;
    object _14353 = NOVALUE;
    object _14352 = NOVALUE;
    object _14351 = NOVALUE;
    object _14350 = NOVALUE;
    object _14349 = NOVALUE;
    object _14348 = NOVALUE;
    object _14347 = NOVALUE;
    object _14346 = NOVALUE;
    object _14345 = NOVALUE;
    object _14344 = NOVALUE;
    object _14343 = NOVALUE;
    object _14342 = NOVALUE;
    object _14341 = NOVALUE;
    object _14340 = NOVALUE;
    object _14339 = NOVALUE;
    object _14337 = NOVALUE;
    object _14336 = NOVALUE;
    object _14335 = NOVALUE;
    object _14333 = NOVALUE;
    object _14328 = NOVALUE;
    object _14327 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:272		src = 0*/
    DeRef(_src_25776);
    _src_25776 = 0;

    /** scanner.e:273		options = 0*/
    _options_25775 = 0;

    /** scanner.e:275		if TRANSLATE or OpTrace or OpProfileStatement or OpProfileTime then*/
    if (_12TRANSLATE_19834 != 0) {
        _14327 = 1;
        goto L1; // [15] 25
    }
    _14327 = (_12OpTrace_20296 != 0);
L1: 
    if (_14327 != 0) {
        _14328 = 1;
        goto L2; // [25] 35
    }
    _14328 = (_12OpProfileStatement_20298 != 0);
L2: 
    if (_14328 != 0) {
        goto L3; // [35] 46
    }
    if (_12OpProfileTime_20299 == 0)
    {
        goto L4; // [42] 136
    }
    else{
    }
L3: 

    /** scanner.e:277			src = ThisLine*/
    Ref(_49ThisLine_49261);
    DeRef(_src_25776);
    _src_25776 = _49ThisLine_49261;

    /** scanner.e:279			if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto L5; // [57] 70
    }
    else{
    }

    /** scanner.e:280				options = SOP_TRACE*/
    _options_25775 = 1;
L5: 

    /** scanner.e:282			if OpProfileTime then*/
    if (_12OpProfileTime_20299 == 0)
    {
        goto L6; // [74] 88
    }
    else{
    }

    /** scanner.e:283				options = or_bits(options, SOP_PROFILE_TIME)*/
    {uintptr_t tu;
         tu = (uintptr_t)_options_25775 | (uintptr_t)2;
         _options_25775 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_25775)) {
        _1 = (object)(DBL_PTR(_options_25775)->dbl);
        DeRefDS(_options_25775);
        _options_25775 = _1;
    }
L6: 

    /** scanner.e:285			if OpProfileStatement then*/
    if (_12OpProfileStatement_20298 == 0)
    {
        goto L7; // [92] 106
    }
    else{
    }

    /** scanner.e:286				options = or_bits(options, SOP_PROFILE_STATEMENT)*/
    {uintptr_t tu;
         tu = (uintptr_t)_options_25775 | (uintptr_t)4;
         _options_25775 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_25775)) {
        _1 = (object)(DBL_PTR(_options_25775)->dbl);
        DeRefDS(_options_25775);
        _options_25775 = _1;
    }
L7: 

    /** scanner.e:288			if OpProfileStatement or OpProfileTime then*/
    if (_12OpProfileStatement_20298 != 0) {
        goto L8; // [110] 121
    }
    if (_12OpProfileTime_20299 == 0)
    {
        goto L9; // [117] 135
    }
    else{
    }
L8: 

    /** scanner.e:289				src = {0,0,0,0} & src*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 0;
    ((intptr_t*)_2)[4] = 0;
    _14333 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_14333) && IS_ATOM(_src_25776)) {
        Ref(_src_25776);
        Append(&_src_25776, _14333, _src_25776);
    }
    else if (IS_ATOM(_14333) && IS_SEQUENCE(_src_25776)) {
    }
    else {
        Concat((object_ptr)&_src_25776, _14333, _src_25776);
        DeRefDS(_14333);
        _14333 = NOVALUE;
    }
    DeRef(_14333);
    _14333 = NOVALUE;
L9: 
L4: 

    /** scanner.e:293		if length(slist) then*/
    if (IS_SEQUENCE(_12slist_20317)){
            _14335 = SEQ_PTR(_12slist_20317)->length;
    }
    else {
        _14335 = 1;
    }
    if (_14335 == 0)
    {
        _14335 = NOVALUE;
        goto LA; // [143] 345
    }
    else{
        _14335 = NOVALUE;
    }

    /** scanner.e:294			old = slist[$-1]*/
    if (IS_SEQUENCE(_12slist_20317)){
            _14336 = SEQ_PTR(_12slist_20317)->length;
    }
    else {
        _14336 = 1;
    }
    _14337 = _14336 - 1;
    _14336 = NOVALUE;
    DeRef(_old_25774);
    _2 = (object)SEQ_PTR(_12slist_20317);
    _old_25774 = (object)*(((s1_ptr)_2)->base + _14337);
    Ref(_old_25774);

    /** scanner.e:296			if equal(src, old[SRC]) and*/
    _2 = (object)SEQ_PTR(_old_25774);
    _14339 = (object)*(((s1_ptr)_2)->base + 1);
    if (_src_25776 == _14339)
    _14340 = 1;
    else if (IS_ATOM_INT(_src_25776) && IS_ATOM_INT(_14339))
    _14340 = 0;
    else
    _14340 = (compare(_src_25776, _14339) == 0);
    _14339 = NOVALUE;
    if (_14340 == 0) {
        _14341 = 0;
        goto LB; // [175] 195
    }
    _2 = (object)SEQ_PTR(_old_25774);
    _14342 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_14342)) {
        _14343 = (_12current_file_no_20226 == _14342);
    }
    else {
        _14343 = binary_op(EQUALS, _12current_file_no_20226, _14342);
    }
    _14342 = NOVALUE;
    if (IS_ATOM_INT(_14343))
    _14341 = (_14343 != 0);
    else
    _14341 = DBL_PTR(_14343)->dbl != 0.0;
LB: 
    if (_14341 == 0) {
        _14344 = 0;
        goto LC; // [195] 232
    }
    _2 = (object)SEQ_PTR(_old_25774);
    _14345 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_14345)) {
        _14346 = _14345 + 1;
        if (_14346 > MAXINT){
            _14346 = NewDouble((eudouble)_14346);
        }
    }
    else
    _14346 = binary_op(PLUS, 1, _14345);
    _14345 = NOVALUE;
    if (IS_SEQUENCE(_12slist_20317)){
            _14347 = SEQ_PTR(_12slist_20317)->length;
    }
    else {
        _14347 = 1;
    }
    _2 = (object)SEQ_PTR(_12slist_20317);
    _14348 = (object)*(((s1_ptr)_2)->base + _14347);
    if (IS_ATOM_INT(_14346) && IS_ATOM_INT(_14348)) {
        _14349 = _14346 + _14348;
        if ((object)((uintptr_t)_14349 + (uintptr_t)HIGH_BITS) >= 0){
            _14349 = NewDouble((eudouble)_14349);
        }
    }
    else {
        _14349 = binary_op(PLUS, _14346, _14348);
    }
    DeRef(_14346);
    _14346 = NOVALUE;
    _14348 = NOVALUE;
    if (IS_ATOM_INT(_14349)) {
        _14350 = (_12line_number_20227 == _14349);
    }
    else {
        _14350 = binary_op(EQUALS, _12line_number_20227, _14349);
    }
    DeRef(_14349);
    _14349 = NOVALUE;
    if (IS_ATOM_INT(_14350))
    _14344 = (_14350 != 0);
    else
    _14344 = DBL_PTR(_14350)->dbl != 0.0;
LC: 
    if (_14344 == 0) {
        goto LD; // [232] 272
    }
    _2 = (object)SEQ_PTR(_old_25774);
    _14352 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_14352)) {
        _14353 = (_options_25775 == _14352);
    }
    else {
        _14353 = binary_op(EQUALS, _options_25775, _14352);
    }
    _14352 = NOVALUE;
    if (_14353 == 0) {
        DeRef(_14353);
        _14353 = NOVALUE;
        goto LD; // [247] 272
    }
    else {
        if (!IS_ATOM_INT(_14353) && DBL_PTR(_14353)->dbl == 0.0){
            DeRef(_14353);
            _14353 = NOVALUE;
            goto LD; // [247] 272
        }
        DeRef(_14353);
        _14353 = NOVALUE;
    }
    DeRef(_14353);
    _14353 = NOVALUE;

    /** scanner.e:302				slist[$] += 1*/
    if (IS_SEQUENCE(_12slist_20317)){
            _14354 = SEQ_PTR(_12slist_20317)->length;
    }
    else {
        _14354 = 1;
    }
    _2 = (object)SEQ_PTR(_12slist_20317);
    _14355 = (object)*(((s1_ptr)_2)->base + _14354);
    if (IS_ATOM_INT(_14355)) {
        _14356 = _14355 + 1;
        if (_14356 > MAXINT){
            _14356 = NewDouble((eudouble)_14356);
        }
    }
    else
    _14356 = binary_op(PLUS, 1, _14355);
    _14355 = NOVALUE;
    _2 = (object)SEQ_PTR(_12slist_20317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12slist_20317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14354);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14356;
    if( _1 != _14356 ){
        DeRef(_1);
    }
    _14356 = NOVALUE;
    goto LE; // [269] 371
LD: 

    /** scanner.e:304				src = pack_source(src)*/
    Ref(_src_25776);
    _0 = _src_25776;
    _src_25776 = _61pack_source(_src_25776);
    DeRef(_0);

    /** scanner.e:305				new = {src, line_number, current_file_no, options}*/
    _0 = _new_25773;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_src_25776);
    ((intptr_t*)_2)[1] = _src_25776;
    ((intptr_t*)_2)[2] = _12line_number_20227;
    ((intptr_t*)_2)[3] = _12current_file_no_20226;
    ((intptr_t*)_2)[4] = _options_25775;
    _new_25773 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:306				if slist[$] = 0 then*/
    if (IS_SEQUENCE(_12slist_20317)){
            _14359 = SEQ_PTR(_12slist_20317)->length;
    }
    else {
        _14359 = 1;
    }
    _2 = (object)SEQ_PTR(_12slist_20317);
    _14360 = (object)*(((s1_ptr)_2)->base + _14359);
    if (binary_op_a(NOTEQ, _14360, 0)){
        _14360 = NOVALUE;
        goto LF; // [302] 320
    }
    _14360 = NOVALUE;

    /** scanner.e:307					slist[$] = new*/
    if (IS_SEQUENCE(_12slist_20317)){
            _14362 = SEQ_PTR(_12slist_20317)->length;
    }
    else {
        _14362 = 1;
    }
    RefDS(_new_25773);
    _2 = (object)SEQ_PTR(_12slist_20317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12slist_20317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14362);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_25773;
    DeRef(_1);
    goto L10; // [317] 331
LF: 

    /** scanner.e:309					slist = append(slist, new)*/
    RefDS(_new_25773);
    Append(&_12slist_20317, _12slist_20317, _new_25773);
L10: 

    /** scanner.e:311				slist = append(slist, 0)*/
    Append(&_12slist_20317, _12slist_20317, 0);
    goto LE; // [342] 371
LA: 

    /** scanner.e:314			src = pack_source(src)*/
    Ref(_src_25776);
    _0 = _src_25776;
    _src_25776 = _61pack_source(_src_25776);
    DeRef(_0);

    /** scanner.e:315			slist = {{src, line_number, current_file_no, options}, 0}*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_src_25776);
    ((intptr_t*)_2)[1] = _src_25776;
    ((intptr_t*)_2)[2] = _12line_number_20227;
    ((intptr_t*)_2)[3] = _12current_file_no_20226;
    ((intptr_t*)_2)[4] = _options_25775;
    _14366 = MAKE_SEQ(_1);
    DeRef(_12slist_20317);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14366;
    ((intptr_t *)_2)[2] = 0;
    _12slist_20317 = MAKE_SEQ(_1);
    _14366 = NOVALUE;
LE: 

    /** scanner.e:317	end procedure*/
    DeRef(_new_25773);
    DeRef(_old_25774);
    DeRef(_src_25776);
    DeRef(_14337);
    _14337 = NOVALUE;
    DeRef(_14350);
    _14350 = NOVALUE;
    DeRef(_14343);
    _14343 = NOVALUE;
    return;
    ;
}


object _61s_expand(object _slist_25865)
{
    object _new_slist_25866 = NOVALUE;
    object _14380 = NOVALUE;
    object _14379 = NOVALUE;
    object _14378 = NOVALUE;
    object _14377 = NOVALUE;
    object _14375 = NOVALUE;
    object _14374 = NOVALUE;
    object _14373 = NOVALUE;
    object _14371 = NOVALUE;
    object _14370 = NOVALUE;
    object _14369 = NOVALUE;
    object _14368 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:323		new_slist = {}*/
    RefDS(_5);
    DeRef(_new_slist_25866);
    _new_slist_25866 = _5;

    /** scanner.e:325		for i = 1 to length(slist) do*/
    if (IS_SEQUENCE(_slist_25865)){
            _14368 = SEQ_PTR(_slist_25865)->length;
    }
    else {
        _14368 = 1;
    }
    {
        object _i_25868;
        _i_25868 = 1;
L1: 
        if (_i_25868 > _14368){
            goto L2; // [15] 114
        }

        /** scanner.e:326			if sequence(slist[i]) then*/
        _2 = (object)SEQ_PTR(_slist_25865);
        _14369 = (object)*(((s1_ptr)_2)->base + _i_25868);
        _14370 = IS_SEQUENCE(_14369);
        _14369 = NOVALUE;
        if (_14370 == 0)
        {
            _14370 = NOVALUE;
            goto L3; // [31] 47
        }
        else{
            _14370 = NOVALUE;
        }

        /** scanner.e:327				new_slist = append(new_slist, slist[i])*/
        _2 = (object)SEQ_PTR(_slist_25865);
        _14371 = (object)*(((s1_ptr)_2)->base + _i_25868);
        Ref(_14371);
        Append(&_new_slist_25866, _new_slist_25866, _14371);
        _14371 = NOVALUE;
        goto L4; // [44] 107
L3: 

        /** scanner.e:329				for j = 1 to slist[i] do*/
        _2 = (object)SEQ_PTR(_slist_25865);
        _14373 = (object)*(((s1_ptr)_2)->base + _i_25868);
        {
            object _j_25877;
            _j_25877 = 1;
L5: 
            if (binary_op_a(GREATER, _j_25877, _14373)){
                goto L6; // [53] 106
            }

            /** scanner.e:330					slist[i-1][LINE] += 1*/
            _14374 = _i_25868 - 1;
            _2 = (object)SEQ_PTR(_slist_25865);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _slist_25865 = MAKE_SEQ(_2);
            }
            _3 = (object)(_14374 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            _14377 = (object)*(((s1_ptr)_2)->base + 2);
            _14375 = NOVALUE;
            if (IS_ATOM_INT(_14377)) {
                _14378 = _14377 + 1;
                if (_14378 > MAXINT){
                    _14378 = NewDouble((eudouble)_14378);
                }
            }
            else
            _14378 = binary_op(PLUS, 1, _14377);
            _14377 = NOVALUE;
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 2);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _14378;
            if( _1 != _14378 ){
                DeRef(_1);
            }
            _14378 = NOVALUE;
            _14375 = NOVALUE;

            /** scanner.e:331					new_slist = append(new_slist, slist[i-1])*/
            _14379 = _i_25868 - 1;
            _2 = (object)SEQ_PTR(_slist_25865);
            _14380 = (object)*(((s1_ptr)_2)->base + _14379);
            Ref(_14380);
            Append(&_new_slist_25866, _new_slist_25866, _14380);
            _14380 = NOVALUE;

            /** scanner.e:332				end for*/
            _0 = _j_25877;
            if (IS_ATOM_INT(_j_25877)) {
                _j_25877 = _j_25877 + 1;
                if ((object)((uintptr_t)_j_25877 +(uintptr_t) HIGH_BITS) >= 0){
                    _j_25877 = NewDouble((eudouble)_j_25877);
                }
            }
            else {
                _j_25877 = binary_op_a(PLUS, _j_25877, 1);
            }
            DeRef(_0);
            goto L5; // [101] 60
L6: 
            ;
            DeRef(_j_25877);
        }
L4: 

        /** scanner.e:334		end for*/
        _i_25868 = _i_25868 + 1;
        goto L1; // [109] 22
L2: 
        ;
    }

    /** scanner.e:335		return new_slist*/
    DeRefDS(_slist_25865);
    _14373 = NOVALUE;
    DeRef(_14374);
    _14374 = NOVALUE;
    DeRef(_14379);
    _14379 = NOVALUE;
    return _new_slist_25866;
    ;
}


void _61set_dont_read(object _read_25892)
{
    object _0, _1, _2;
    

    /** scanner.e:357		dont_read = read*/
    _61dont_read_25889 = _read_25892;

    /** scanner.e:358	end procedure*/
    return;
    ;
}


void _61read_line()
{
    object _n_25898 = NOVALUE;
    object _14411 = NOVALUE;
    object _14410 = NOVALUE;
    object _14409 = NOVALUE;
    object _14408 = NOVALUE;
    object _14407 = NOVALUE;
    object _14405 = NOVALUE;
    object _14404 = NOVALUE;
    object _14402 = NOVALUE;
    object _14401 = NOVALUE;
    object _14399 = NOVALUE;
    object _14398 = NOVALUE;
    object _14390 = NOVALUE;
    object _14388 = NOVALUE;
    object _14387 = NOVALUE;
    object _14386 = NOVALUE;
    object _14385 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:367		line_number += 1*/
    _12line_number_20227 = _12line_number_20227 + 1;

    /** scanner.e:368		gline_number += 1*/
    _12gline_number_20231 = _12gline_number_20231 + 1;

    /** scanner.e:370		if dont_read then*/
    if (_61dont_read_25889 == 0)
    {
        goto L1; // [25] 36
    }
    else{
    }

    /** scanner.e:371			ThisLine = -1*/
    DeRef(_49ThisLine_49261);
    _49ThisLine_49261 = -1;
    goto L2; // [33] 216
L1: 

    /** scanner.e:372		elsif repl and src_file = repl_file then*/
    if (0 == 0) {
        goto L3; // [40] 144
    }
    _14386 = (_12src_file_20348 == 5555);
    if (_14386 == 0)
    {
        DeRef(_14386);
        _14386 = NOVALUE;
        goto L3; // [53] 144
    }
    else{
        DeRef(_14386);
        _14386 = NOVALUE;
    }

    /** scanner.e:373			if repl_line_was_read and current_block = top_level_block then*/
    if (_61repl_line_was_read_25893 == 0) {
        goto L4; // [60] 118
    }
    _14388 = (_64current_block_25147 == _64top_level_block_25148);
    if (_14388 == 0)
    {
        DeRef(_14388);
        _14388 = NOVALUE;
        goto L4; // [73] 118
    }
    else{
        DeRef(_14388);
        _14388 = NOVALUE;
    }

    /** scanner.e:374				if repl_line_was_read > 1 then*/
    if (_61repl_line_was_read_25893 <= 1)
    goto L5; // [80] 110

    /** scanner.e:375					if not match("end", ThisLine) then*/
    _14390 = e_match_from(_13165, _49ThisLine_49261, 1);
    if (_14390 != 0)
    goto L6; // [93] 109
    _14390 = NOVALUE;

    /** scanner.e:376						goto "lol"*/
    goto G7;
L6: 
L5: 

    /** scanner.e:379				ThisLine = -1*/
    DeRef(_49ThisLine_49261);
    _49ThisLine_49261 = -1;
    goto L2; // [115] 216
L4: 

    /** scanner.e:381				label "lol"*/
G7:

    /** scanner.e:382				puts(1, "Enter line:\n")*/
    EPuts(1, _14393); // DJP 

    /** scanner.e:383				repl_line_was_read += 1*/
    _61repl_line_was_read_25893 = _61repl_line_was_read_25893 + 1;

    /** scanner.e:384				ThisLine = gets(0)*/
    DeRef(_49ThisLine_49261);
    _49ThisLine_49261 = EGets(0);
    goto L2; // [141] 216
L3: 

    /** scanner.e:386		elsif src_file < 0 then*/
    if (_12src_file_20348 >= 0)
    goto L8; // [148] 160

    /** scanner.e:387			ThisLine = -1*/
    DeRef(_49ThisLine_49261);
    _49ThisLine_49261 = -1;
    goto L2; // [157] 216
L8: 

    /** scanner.e:389			ThisLine = gets(src_file)*/
    DeRef(_49ThisLine_49261);
    _49ThisLine_49261 = EGets(_12src_file_20348);

    /** scanner.e:390			if sequence(ThisLine) and ends( {13,10}, ThisLine ) then*/
    _14398 = IS_SEQUENCE(_49ThisLine_49261);
    if (_14398 == 0) {
        goto L9; // [174] 215
    }
    RefDS(_14400);
    Ref(_49ThisLine_49261);
    _14401 = _20ends(_14400, _49ThisLine_49261);
    if (_14401 == 0) {
        DeRef(_14401);
        _14401 = NOVALUE;
        goto L9; // [186] 215
    }
    else {
        if (!IS_ATOM_INT(_14401) && DBL_PTR(_14401)->dbl == 0.0){
            DeRef(_14401);
            _14401 = NOVALUE;
            goto L9; // [186] 215
        }
        DeRef(_14401);
        _14401 = NOVALUE;
    }
    DeRef(_14401);
    _14401 = NOVALUE;

    /** scanner.e:391				ThisLine = remove(ThisLine, length(ThisLine))*/
    if (IS_SEQUENCE(_49ThisLine_49261)){
            _14402 = SEQ_PTR(_49ThisLine_49261)->length;
    }
    else {
        _14402 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_49ThisLine_49261);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_14402)) ? _14402 : (object)(DBL_PTR(_14402)->dbl);
        int stop = (IS_ATOM_INT(_14402)) ? _14402 : (object)(DBL_PTR(_14402)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_49ThisLine_49261), start, &_49ThisLine_49261 );
            }
            else Tail(SEQ_PTR(_49ThisLine_49261), stop+1, &_49ThisLine_49261);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_49ThisLine_49261), start, &_49ThisLine_49261);
        }
        else {
            assign_slice_seq = &assign_space;
            _49ThisLine_49261 = Remove_elements(start, stop, (SEQ_PTR(_49ThisLine_49261)->ref == 1));
        }
    }
    _14402 = NOVALUE;
    _14402 = NOVALUE;

    /** scanner.e:392				ThisLine[$] = 10*/
    if (IS_SEQUENCE(_49ThisLine_49261)){
            _14404 = SEQ_PTR(_49ThisLine_49261)->length;
    }
    else {
        _14404 = 1;
    }
    _2 = (object)SEQ_PTR(_49ThisLine_49261);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _49ThisLine_49261 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14404);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 10;
    DeRef(_1);
L9: 
L2: 

    /** scanner.e:395		if atom(ThisLine) then*/
    _14405 = IS_ATOM(_49ThisLine_49261);
    if (_14405 == 0)
    {
        _14405 = NOVALUE;
        goto LA; // [223] 286
    }
    else{
        _14405 = NOVALUE;
    }

    /** scanner.e:396			ThisLine = {END_OF_FILE_CHAR}*/
    _0 = _49ThisLine_49261;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 26;
    _49ThisLine_49261 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:397			if src_file >= 0 and (src_file != repl_file or not repl) then*/
    _14407 = (_12src_file_20348 >= 0);
    if (_14407 == 0) {
        goto LB; // [242] 278
    }
    _14409 = (_12src_file_20348 != 5555);
    if (_14409 != 0) {
        DeRef(_14410);
        _14410 = 1;
        goto LC; // [254] 267
    }
    _14411 = (0 == 0);
    _14410 = (_14411 != 0);
LC: 
    if (_14410 == 0)
    {
        _14410 = NOVALUE;
        goto LB; // [268] 278
    }
    else{
        _14410 = NOVALUE;
    }

    /** scanner.e:398				close(src_file)*/
    EClose(_12src_file_20348);
LB: 

    /** scanner.e:400			src_file = -1*/
    _12src_file_20348 = -1;
LA: 

    /** scanner.e:403		bp = 1*/
    _49bp_49265 = 1;

    /** scanner.e:411		AppendSourceLine()*/
    _61AppendSourceLine();

    /** scanner.e:412	end procedure*/
    DeRef(_14409);
    _14409 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    DeRef(_14407);
    _14407 = NOVALUE;
    return;
    ;
}


object _61getch()
{
    object _c_25973 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:417		c = ThisLine[bp]*/
    _2 = (object)SEQ_PTR(_49ThisLine_49261);
    _c_25973 = (object)*(((s1_ptr)_2)->base + _49bp_49265);
    if (!IS_ATOM_INT(_c_25973)){
        _c_25973 = (object)DBL_PTR(_c_25973)->dbl;
    }

    /** scanner.e:418		bp += 1*/
    _49bp_49265 = _49bp_49265 + 1;

    /** scanner.e:419		return c*/
    return _c_25973;
    ;
}


void _61ungetch()
{
    object _0, _1, _2;
    

    /** scanner.e:424		bp -= 1*/
    _49bp_49265 = _49bp_49265 - 1;

    /** scanner.e:425	end procedure*/
    return;
    ;
}


object _61get_file_path(object _s_25985)
{
    object _14420 = NOVALUE;
    object _14418 = NOVALUE;
    object _14417 = NOVALUE;
    object _14416 = NOVALUE;
    object _14415 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:429			for t=length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_25985)){
            _14415 = SEQ_PTR(_s_25985)->length;
    }
    else {
        _14415 = 1;
    }
    {
        object _t_25987;
        _t_25987 = _14415;
L1: 
        if (_t_25987 < 1){
            goto L2; // [8] 50
        }

        /** scanner.e:430					if find(s[t],SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_s_25985);
        _14416 = (object)*(((s1_ptr)_2)->base + _t_25987);
        _14417 = find_from(_14416, _44SLASH_CHARS_20390, 1);
        _14416 = NOVALUE;
        if (_14417 == 0)
        {
            _14417 = NOVALUE;
            goto L3; // [28] 43
        }
        else{
            _14417 = NOVALUE;
        }

        /** scanner.e:431							return s[1..t]*/
        rhs_slice_target = (object_ptr)&_14418;
        RHS_Slice(_s_25985, 1, _t_25987);
        DeRefDS(_s_25985);
        return _14418;
L3: 

        /** scanner.e:433			end for*/
        _t_25987 = _t_25987 + -1;
        goto L1; // [45] 15
L2: 
        ;
    }

    /** scanner.e:435			return "." & SLASH*/
    Append(&_14420, _14419, 47);
    DeRefDS(_s_25985);
    DeRef(_14418);
    _14418 = NOVALUE;
    return _14420;
    ;
}


object _61find_file(object _fname_25999)
{
    object _try_26000 = NOVALUE;
    object _full_path_26001 = NOVALUE;
    object _errbuff_26002 = NOVALUE;
    object _currdir_26003 = NOVALUE;
    object _conf_path_26004 = NOVALUE;
    object _scan_result_26005 = NOVALUE;
    object _inc_path_26006 = NOVALUE;
    object _mainpath_26026 = NOVALUE;
    object _31742 = NOVALUE;
    object _31741 = NOVALUE;
    object _14517 = NOVALUE;
    object _14515 = NOVALUE;
    object _14514 = NOVALUE;
    object _14513 = NOVALUE;
    object _14511 = NOVALUE;
    object _14509 = NOVALUE;
    object _14507 = NOVALUE;
    object _14506 = NOVALUE;
    object _14504 = NOVALUE;
    object _14503 = NOVALUE;
    object _14500 = NOVALUE;
    object _14497 = NOVALUE;
    object _14496 = NOVALUE;
    object _14495 = NOVALUE;
    object _14494 = NOVALUE;
    object _14493 = NOVALUE;
    object _14492 = NOVALUE;
    object _14491 = NOVALUE;
    object _14490 = NOVALUE;
    object _14487 = NOVALUE;
    object _14486 = NOVALUE;
    object _14482 = NOVALUE;
    object _14479 = NOVALUE;
    object _14478 = NOVALUE;
    object _14477 = NOVALUE;
    object _14476 = NOVALUE;
    object _14475 = NOVALUE;
    object _14474 = NOVALUE;
    object _14473 = NOVALUE;
    object _14472 = NOVALUE;
    object _14469 = NOVALUE;
    object _14465 = NOVALUE;
    object _14463 = NOVALUE;
    object _14462 = NOVALUE;
    object _14461 = NOVALUE;
    object _14460 = NOVALUE;
    object _14459 = NOVALUE;
    object _14456 = NOVALUE;
    object _14455 = NOVALUE;
    object _14454 = NOVALUE;
    object _14453 = NOVALUE;
    object _14452 = NOVALUE;
    object _14451 = NOVALUE;
    object _14449 = NOVALUE;
    object _14448 = NOVALUE;
    object _14447 = NOVALUE;
    object _14446 = NOVALUE;
    object _14445 = NOVALUE;
    object _14443 = NOVALUE;
    object _14442 = NOVALUE;
    object _14439 = NOVALUE;
    object _14436 = NOVALUE;
    object _14434 = NOVALUE;
    object _14431 = NOVALUE;
    object _14429 = NOVALUE;
    object _14428 = NOVALUE;
    object _14425 = NOVALUE;
    object _14424 = NOVALUE;
    object _14422 = NOVALUE;
    object _14421 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:449		if absolute_path(fname) then*/
    RefDS(_fname_25999);
    _14421 = _14absolute_path(_fname_25999);
    if (_14421 == 0) {
        DeRef(_14421);
        _14421 = NOVALUE;
        goto L1; // [9] 44
    }
    else {
        if (!IS_ATOM_INT(_14421) && DBL_PTR(_14421)->dbl == 0.0){
            DeRef(_14421);
            _14421 = NOVALUE;
            goto L1; // [9] 44
        }
        DeRef(_14421);
        _14421 = NOVALUE;
    }
    DeRef(_14421);
    _14421 = NOVALUE;

    /** scanner.e:451			if not file_exists(fname) then*/
    RefDS(_fname_25999);
    _14422 = _14file_exists(_fname_25999);
    if (IS_ATOM_INT(_14422)) {
        if (_14422 != 0){
            DeRef(_14422);
            _14422 = NOVALUE;
            goto L2; // [18] 37
        }
    }
    else {
        if (DBL_PTR(_14422)->dbl != 0.0){
            DeRef(_14422);
            _14422 = NOVALUE;
            goto L2; // [18] 37
        }
    }
    DeRef(_14422);
    _14422 = NOVALUE;

    /** scanner.e:452				CompileErr(CANT_OPEN_1, {new_include_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12new_include_name_20349);
    ((intptr_t*)_2)[1] = _12new_include_name_20349;
    _14424 = MAKE_SEQ(_1);
    _49CompileErr(51, _14424, 0);
    _14424 = NOVALUE;
L2: 

    /** scanner.e:455			return fname*/
    DeRef(_full_path_26001);
    DeRef(_errbuff_26002);
    DeRef(_currdir_26003);
    DeRef(_conf_path_26004);
    DeRef(_scan_result_26005);
    DeRef(_inc_path_26006);
    DeRef(_mainpath_26026);
    return _fname_25999;
L1: 

    /** scanner.e:460		currdir = get_file_path( known_files[current_file_no] )*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _14425 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    Ref(_14425);
    _0 = _currdir_26003;
    _currdir_26003 = _61get_file_path(_14425);
    DeRef(_0);
    _14425 = NOVALUE;

    /** scanner.e:461		full_path = currdir & fname*/
    Concat((object_ptr)&_full_path_26001, _currdir_26003, _fname_25999);

    /** scanner.e:462		if file_exists(full_path) then*/
    RefDS(_full_path_26001);
    _14428 = _14file_exists(_full_path_26001);
    if (_14428 == 0) {
        DeRef(_14428);
        _14428 = NOVALUE;
        goto L3; // [72] 82
    }
    else {
        if (!IS_ATOM_INT(_14428) && DBL_PTR(_14428)->dbl == 0.0){
            DeRef(_14428);
            _14428 = NOVALUE;
            goto L3; // [72] 82
        }
        DeRef(_14428);
        _14428 = NOVALUE;
    }
    DeRef(_14428);
    _14428 = NOVALUE;

    /** scanner.e:463			return full_path*/
    DeRefDS(_fname_25999);
    DeRef(_errbuff_26002);
    DeRefDS(_currdir_26003);
    DeRef(_conf_path_26004);
    DeRef(_scan_result_26005);
    DeRef(_inc_path_26006);
    DeRef(_mainpath_26026);
    return _full_path_26001;
L3: 

    /** scanner.e:467		sequence mainpath = main_path[1..rfind(SLASH, main_path)]*/
    RefDS(_12main_path_20347);
    DeRef(_31741);
    _31741 = _12main_path_20347;
    if (IS_SEQUENCE(_31741)){
            _31742 = SEQ_PTR(_31741)->length;
    }
    else {
        _31742 = 1;
    }
    _31741 = NOVALUE;
    RefDS(_12main_path_20347);
    _14429 = _20rfind(47, _12main_path_20347, _31742);
    _31742 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mainpath_26026;
    RHS_Slice(_12main_path_20347, 1, _14429);

    /** scanner.e:468		if not equal(mainpath, currdir) then*/
    if (_mainpath_26026 == _currdir_26003)
    _14431 = 1;
    else if (IS_ATOM_INT(_mainpath_26026) && IS_ATOM_INT(_currdir_26003))
    _14431 = 0;
    else
    _14431 = (compare(_mainpath_26026, _currdir_26003) == 0);
    if (_14431 != 0)
    goto L4; // [113] 141
    _14431 = NOVALUE;

    /** scanner.e:469			full_path = mainpath & new_include_name*/
    Concat((object_ptr)&_full_path_26001, _mainpath_26026, _12new_include_name_20349);

    /** scanner.e:470			if file_exists(full_path) then*/
    RefDS(_full_path_26001);
    _14434 = _14file_exists(_full_path_26001);
    if (_14434 == 0) {
        DeRef(_14434);
        _14434 = NOVALUE;
        goto L5; // [130] 140
    }
    else {
        if (!IS_ATOM_INT(_14434) && DBL_PTR(_14434)->dbl == 0.0){
            DeRef(_14434);
            _14434 = NOVALUE;
            goto L5; // [130] 140
        }
        DeRef(_14434);
        _14434 = NOVALUE;
    }
    DeRef(_14434);
    _14434 = NOVALUE;

    /** scanner.e:471				return full_path*/
    DeRefDS(_fname_25999);
    DeRef(_errbuff_26002);
    DeRefDS(_currdir_26003);
    DeRef(_conf_path_26004);
    DeRef(_scan_result_26005);
    DeRef(_inc_path_26006);
    DeRefDS(_mainpath_26026);
    _31741 = NOVALUE;
    DeRef(_14429);
    _14429 = NOVALUE;
    return _full_path_26001;
L5: 
L4: 

    /** scanner.e:475		scan_result = ConfPath(new_include_name)*/
    RefDS(_12new_include_name_20349);
    _0 = _scan_result_26005;
    _scan_result_26005 = _46ConfPath(_12new_include_name_20349);
    DeRef(_0);

    /** scanner.e:477		if atom(scan_result) then*/
    _14436 = IS_ATOM(_scan_result_26005);
    if (_14436 == 0)
    {
        _14436 = NOVALUE;
        goto L6; // [154] 166
    }
    else{
        _14436 = NOVALUE;
    }

    /** scanner.e:478			scan_result = ScanPath(fname,"EUINC",0)*/
    RefDS(_fname_25999);
    RefDS(_14437);
    _0 = _scan_result_26005;
    _scan_result_26005 = _46ScanPath(_fname_25999, _14437, 0);
    DeRef(_0);
L6: 

    /** scanner.e:481		if atom(scan_result) then*/
    _14439 = IS_ATOM(_scan_result_26005);
    if (_14439 == 0)
    {
        _14439 = NOVALUE;
        goto L7; // [171] 183
    }
    else{
        _14439 = NOVALUE;
    }

    /** scanner.e:482			scan_result = ScanPath(fname, "EUDIR",1)*/
    RefDS(_fname_25999);
    RefDS(_14440);
    _0 = _scan_result_26005;
    _scan_result_26005 = _46ScanPath(_fname_25999, _14440, 1);
    DeRef(_0);
L7: 

    /** scanner.e:485		if atom(scan_result) then*/
    _14442 = IS_ATOM(_scan_result_26005);
    if (_14442 == 0)
    {
        _14442 = NOVALUE;
        goto L8; // [188] 225
    }
    else{
        _14442 = NOVALUE;
    }

    /** scanner.e:487			full_path = get_eudir() & SLASH & "include" & SLASH & fname*/
    _14443 = _13get_eudir();
    {
        object concat_list[5];

        concat_list[0] = _fname_25999;
        concat_list[1] = 47;
        concat_list[2] = _13203;
        concat_list[3] = 47;
        concat_list[4] = _14443;
        Concat_N((object_ptr)&_full_path_26001, concat_list, 5);
    }
    DeRef(_14443);
    _14443 = NOVALUE;

    /** scanner.e:488			if file_exists(full_path) then*/
    RefDS(_full_path_26001);
    _14445 = _14file_exists(_full_path_26001);
    if (_14445 == 0) {
        DeRef(_14445);
        _14445 = NOVALUE;
        goto L9; // [214] 224
    }
    else {
        if (!IS_ATOM_INT(_14445) && DBL_PTR(_14445)->dbl == 0.0){
            DeRef(_14445);
            _14445 = NOVALUE;
            goto L9; // [214] 224
        }
        DeRef(_14445);
        _14445 = NOVALUE;
    }
    DeRef(_14445);
    _14445 = NOVALUE;

    /** scanner.e:489				return full_path*/
    DeRefDS(_fname_25999);
    DeRef(_errbuff_26002);
    DeRef(_currdir_26003);
    DeRef(_conf_path_26004);
    DeRef(_scan_result_26005);
    DeRef(_inc_path_26006);
    DeRef(_mainpath_26026);
    _31741 = NOVALUE;
    DeRef(_14429);
    _14429 = NOVALUE;
    return _full_path_26001;
L9: 
L8: 

    /** scanner.e:493		if sequence(scan_result) then*/
    _14446 = IS_SEQUENCE(_scan_result_26005);
    if (_14446 == 0)
    {
        _14446 = NOVALUE;
        goto LA; // [230] 252
    }
    else{
        _14446 = NOVALUE;
    }

    /** scanner.e:495			close(scan_result[2])*/
    _2 = (object)SEQ_PTR(_scan_result_26005);
    _14447 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_14447))
    EClose(_14447);
    else
    EClose((object)DBL_PTR(_14447)->dbl);
    _14447 = NOVALUE;

    /** scanner.e:496			return scan_result[1]*/
    _2 = (object)SEQ_PTR(_scan_result_26005);
    _14448 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_14448);
    DeRefDS(_fname_25999);
    DeRef(_full_path_26001);
    DeRef(_errbuff_26002);
    DeRef(_currdir_26003);
    DeRef(_conf_path_26004);
    DeRef(_scan_result_26005);
    DeRef(_inc_path_26006);
    DeRef(_mainpath_26026);
    _31741 = NOVALUE;
    DeRef(_14429);
    _14429 = NOVALUE;
    return _14448;
LA: 

    /** scanner.e:500		errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_26002);
    _errbuff_26002 = _5;

    /** scanner.e:501		full_path = {}*/
    RefDS(_5);
    DeRef(_full_path_26001);
    _full_path_26001 = _5;

    /** scanner.e:502		if length(currdir) > 0 then*/
    if (IS_SEQUENCE(_currdir_26003)){
            _14449 = SEQ_PTR(_currdir_26003)->length;
    }
    else {
        _14449 = 1;
    }
    if (_14449 <= 0)
    goto LB; // [271] 323

    /** scanner.e:503			if find(currdir[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_currdir_26003)){
            _14451 = SEQ_PTR(_currdir_26003)->length;
    }
    else {
        _14451 = 1;
    }
    _2 = (object)SEQ_PTR(_currdir_26003);
    _14452 = (object)*(((s1_ptr)_2)->base + _14451);
    _14453 = find_from(_14452, _44SLASH_CHARS_20390, 1);
    _14452 = NOVALUE;
    if (_14453 == 0)
    {
        _14453 = NOVALUE;
        goto LC; // [291] 315
    }
    else{
        _14453 = NOVALUE;
    }

    /** scanner.e:504				full_path = append(full_path, currdir[1..$-1])*/
    if (IS_SEQUENCE(_currdir_26003)){
            _14454 = SEQ_PTR(_currdir_26003)->length;
    }
    else {
        _14454 = 1;
    }
    _14455 = _14454 - 1;
    _14454 = NOVALUE;
    rhs_slice_target = (object_ptr)&_14456;
    RHS_Slice(_currdir_26003, 1, _14455);
    RefDS(_14456);
    Append(&_full_path_26001, _full_path_26001, _14456);
    DeRefDS(_14456);
    _14456 = NOVALUE;
    goto LD; // [312] 322
LC: 

    /** scanner.e:506				full_path = append(full_path, currdir)*/
    RefDS(_currdir_26003);
    Append(&_full_path_26001, _full_path_26001, _currdir_26003);
LD: 
LB: 

    /** scanner.e:511		if find(main_path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_12main_path_20347)){
            _14459 = SEQ_PTR(_12main_path_20347)->length;
    }
    else {
        _14459 = 1;
    }
    _2 = (object)SEQ_PTR(_12main_path_20347);
    _14460 = (object)*(((s1_ptr)_2)->base + _14459);
    _14461 = find_from(_14460, _44SLASH_CHARS_20390, 1);
    _14460 = NOVALUE;
    if (_14461 == 0)
    {
        _14461 = NOVALUE;
        goto LE; // [341] 363
    }
    else{
        _14461 = NOVALUE;
    }

    /** scanner.e:512			errbuff = main_path[1..$-1]  -- looks better*/
    if (IS_SEQUENCE(_12main_path_20347)){
            _14462 = SEQ_PTR(_12main_path_20347)->length;
    }
    else {
        _14462 = 1;
    }
    _14463 = _14462 - 1;
    _14462 = NOVALUE;
    rhs_slice_target = (object_ptr)&_errbuff_26002;
    RHS_Slice(_12main_path_20347, 1, _14463);
    goto LF; // [360] 373
LE: 

    /** scanner.e:514			errbuff = main_path*/
    RefDS(_12main_path_20347);
    DeRef(_errbuff_26002);
    _errbuff_26002 = _12main_path_20347;
LF: 

    /** scanner.e:516		if not find(errbuff, full_path) then*/
    _14465 = find_from(_errbuff_26002, _full_path_26001, 1);
    if (_14465 != 0)
    goto L10; // [380] 390
    _14465 = NOVALUE;

    /** scanner.e:517			full_path = append(full_path, errbuff)*/
    RefDS(_errbuff_26002);
    Append(&_full_path_26001, _full_path_26001, _errbuff_26002);
L10: 

    /** scanner.e:520		conf_path = get_conf_dirs()*/
    _0 = _conf_path_26004;
    _conf_path_26004 = _46get_conf_dirs();
    DeRef(_0);

    /** scanner.e:521		if length(conf_path) > 0 then*/
    if (IS_SEQUENCE(_conf_path_26004)){
            _14469 = SEQ_PTR(_conf_path_26004)->length;
    }
    else {
        _14469 = 1;
    }
    if (_14469 <= 0)
    goto L11; // [402] 509

    /** scanner.e:522			conf_path = split(conf_path, PATHSEP)*/
    RefDS(_conf_path_26004);
    _0 = _conf_path_26004;
    _conf_path_26004 = _24split(_conf_path_26004, 58, 0, 0);
    DeRefDS(_0);

    /** scanner.e:523			for i = 1 to length(conf_path) do*/
    if (IS_SEQUENCE(_conf_path_26004)){
            _14472 = SEQ_PTR(_conf_path_26004)->length;
    }
    else {
        _14472 = 1;
    }
    {
        object _i_26107;
        _i_26107 = 1;
L12: 
        if (_i_26107 > _14472){
            goto L13; // [424] 508
        }

        /** scanner.e:524				if find(conf_path[i][$], SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_conf_path_26004);
        _14473 = (object)*(((s1_ptr)_2)->base + _i_26107);
        if (IS_SEQUENCE(_14473)){
                _14474 = SEQ_PTR(_14473)->length;
        }
        else {
            _14474 = 1;
        }
        _2 = (object)SEQ_PTR(_14473);
        _14475 = (object)*(((s1_ptr)_2)->base + _14474);
        _14473 = NOVALUE;
        _14476 = find_from(_14475, _44SLASH_CHARS_20390, 1);
        _14475 = NOVALUE;
        if (_14476 == 0)
        {
            _14476 = NOVALUE;
            goto L14; // [451] 475
        }
        else{
            _14476 = NOVALUE;
        }

        /** scanner.e:525					errbuff = conf_path[i][1..$-1]  -- looks better*/
        _2 = (object)SEQ_PTR(_conf_path_26004);
        _14477 = (object)*(((s1_ptr)_2)->base + _i_26107);
        if (IS_SEQUENCE(_14477)){
                _14478 = SEQ_PTR(_14477)->length;
        }
        else {
            _14478 = 1;
        }
        _14479 = _14478 - 1;
        _14478 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_26002;
        RHS_Slice(_14477, 1, _14479);
        _14477 = NOVALUE;
        goto L15; // [472] 484
L14: 

        /** scanner.e:527					errbuff = conf_path[i]*/
        DeRef(_errbuff_26002);
        _2 = (object)SEQ_PTR(_conf_path_26004);
        _errbuff_26002 = (object)*(((s1_ptr)_2)->base + _i_26107);
        Ref(_errbuff_26002);
L15: 

        /** scanner.e:529				if not find(errbuff, full_path) then*/
        _14482 = find_from(_errbuff_26002, _full_path_26001, 1);
        if (_14482 != 0)
        goto L16; // [491] 501
        _14482 = NOVALUE;

        /** scanner.e:530					full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_26002);
        Append(&_full_path_26001, _full_path_26001, _errbuff_26002);
L16: 

        /** scanner.e:532			end for*/
        _i_26107 = _i_26107 + 1;
        goto L12; // [503] 431
L13: 
        ;
    }
L11: 

    /** scanner.e:535		inc_path = getenv("EUINC")*/
    DeRef(_inc_path_26006);
    _inc_path_26006 = EGetEnv(_14437);

    /** scanner.e:536		if sequence(inc_path) then*/
    _14486 = IS_SEQUENCE(_inc_path_26006);
    if (_14486 == 0)
    {
        _14486 = NOVALUE;
        goto L17; // [519] 633
    }
    else{
        _14486 = NOVALUE;
    }

    /** scanner.e:537			if length(inc_path) > 0 then*/
    if (IS_SEQUENCE(_inc_path_26006)){
            _14487 = SEQ_PTR(_inc_path_26006)->length;
    }
    else {
        _14487 = 1;
    }
    if (_14487 <= 0)
    goto L18; // [527] 632

    /** scanner.e:538				inc_path = split(inc_path, PATHSEP)*/
    Ref(_inc_path_26006);
    _0 = _inc_path_26006;
    _inc_path_26006 = _24split(_inc_path_26006, 58, 0, 0);
    DeRefi(_0);

    /** scanner.e:539				for i = 1 to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_26006)){
            _14490 = SEQ_PTR(_inc_path_26006)->length;
    }
    else {
        _14490 = 1;
    }
    {
        object _i_26135;
        _i_26135 = 1;
L19: 
        if (_i_26135 > _14490){
            goto L1A; // [547] 631
        }

        /** scanner.e:540					if find(inc_path[i][$], SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_inc_path_26006);
        _14491 = (object)*(((s1_ptr)_2)->base + _i_26135);
        if (IS_SEQUENCE(_14491)){
                _14492 = SEQ_PTR(_14491)->length;
        }
        else {
            _14492 = 1;
        }
        _2 = (object)SEQ_PTR(_14491);
        _14493 = (object)*(((s1_ptr)_2)->base + _14492);
        _14491 = NOVALUE;
        _14494 = find_from(_14493, _44SLASH_CHARS_20390, 1);
        _14493 = NOVALUE;
        if (_14494 == 0)
        {
            _14494 = NOVALUE;
            goto L1B; // [574] 598
        }
        else{
            _14494 = NOVALUE;
        }

        /** scanner.e:541						errbuff = inc_path[i][1..$-1]  -- looks better*/
        _2 = (object)SEQ_PTR(_inc_path_26006);
        _14495 = (object)*(((s1_ptr)_2)->base + _i_26135);
        if (IS_SEQUENCE(_14495)){
                _14496 = SEQ_PTR(_14495)->length;
        }
        else {
            _14496 = 1;
        }
        _14497 = _14496 - 1;
        _14496 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_26002;
        RHS_Slice(_14495, 1, _14497);
        _14495 = NOVALUE;
        goto L1C; // [595] 607
L1B: 

        /** scanner.e:543						errbuff = inc_path[i]*/
        DeRef(_errbuff_26002);
        _2 = (object)SEQ_PTR(_inc_path_26006);
        _errbuff_26002 = (object)*(((s1_ptr)_2)->base + _i_26135);
        Ref(_errbuff_26002);
L1C: 

        /** scanner.e:545					if not find(errbuff, full_path) then*/
        _14500 = find_from(_errbuff_26002, _full_path_26001, 1);
        if (_14500 != 0)
        goto L1D; // [614] 624
        _14500 = NOVALUE;

        /** scanner.e:546						full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_26002);
        Append(&_full_path_26001, _full_path_26001, _errbuff_26002);
L1D: 

        /** scanner.e:548				end for*/
        _i_26135 = _i_26135 + 1;
        goto L19; // [626] 554
L1A: 
        ;
    }
L18: 
L17: 

    /** scanner.e:552		if length(get_eudir()) > 0 then*/
    _14503 = _13get_eudir();
    if (IS_SEQUENCE(_14503)){
            _14504 = SEQ_PTR(_14503)->length;
    }
    else {
        _14504 = 1;
    }
    DeRef(_14503);
    _14503 = NOVALUE;
    if (_14504 <= 0)
    goto L1E; // [641] 669

    /** scanner.e:553			if not find(get_eudir(), full_path) then*/
    _14506 = _13get_eudir();
    _14507 = find_from(_14506, _full_path_26001, 1);
    DeRef(_14506);
    _14506 = NOVALUE;
    if (_14507 != 0)
    goto L1F; // [655] 668
    _14507 = NOVALUE;

    /** scanner.e:554				full_path = append(full_path, get_eudir())*/
    _14509 = _13get_eudir();
    Ref(_14509);
    Append(&_full_path_26001, _full_path_26001, _14509);
    DeRef(_14509);
    _14509 = NOVALUE;
L1F: 
L1E: 

    /** scanner.e:558		errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_26002);
    _errbuff_26002 = _5;

    /** scanner.e:559		for i = 1 to length(full_path) do*/
    if (IS_SEQUENCE(_full_path_26001)){
            _14511 = SEQ_PTR(_full_path_26001)->length;
    }
    else {
        _14511 = 1;
    }
    {
        object _i_26167;
        _i_26167 = 1;
L20: 
        if (_i_26167 > _14511){
            goto L21; // [681] 713
        }

        /** scanner.e:560			errbuff &= sprintf("\t%s\n", {full_path[i]})*/
        _2 = (object)SEQ_PTR(_full_path_26001);
        _14513 = (object)*(((s1_ptr)_2)->base + _i_26167);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_14513);
        ((intptr_t*)_2)[1] = _14513;
        _14514 = MAKE_SEQ(_1);
        _14513 = NOVALUE;
        _14515 = EPrintf(-9999999, _14512, _14514);
        DeRefDS(_14514);
        _14514 = NOVALUE;
        Concat((object_ptr)&_errbuff_26002, _errbuff_26002, _14515);
        DeRefDS(_14515);
        _14515 = NOVALUE;

        /** scanner.e:561		end for*/
        _i_26167 = _i_26167 + 1;
        goto L20; // [708] 688
L21: 
        ;
    }

    /** scanner.e:563		CompileErr(CANT_FIND_1_IN_ANY_OF_2, {new_include_name, errbuff})*/
    RefDS(_errbuff_26002);
    RefDS(_12new_include_name_20349);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _12new_include_name_20349;
    ((intptr_t *)_2)[2] = _errbuff_26002;
    _14517 = MAKE_SEQ(_1);
    _49CompileErr(52, _14517, 0);
    _14517 = NOVALUE;
    ;
}


object _61path_open()
{
    object _fh_26180 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:569		new_include_name = find_file(new_include_name)*/
    RefDS(_12new_include_name_20349);
    _0 = _61find_file(_12new_include_name_20349);
    DeRefDS(_12new_include_name_20349);
    _12new_include_name_20349 = _0;

    /** scanner.e:570		new_include_name = maybe_preprocess(new_include_name)*/
    RefDS(_12new_include_name_20349);
    _0 = _63maybe_preprocess(_12new_include_name_20349);
    DeRefDS(_12new_include_name_20349);
    _12new_include_name_20349 = _0;

    /** scanner.e:572		fh = open_locked(new_include_name)*/
    RefDS(_12new_include_name_20349);
    _fh_26180 = _13open_locked(_12new_include_name_20349);
    if (!IS_ATOM_INT(_fh_26180)) {
        _1 = (object)(DBL_PTR(_fh_26180)->dbl);
        DeRefDS(_fh_26180);
        _fh_26180 = _1;
    }

    /** scanner.e:573		return fh*/
    return _fh_26180;
    ;
}


object _61NameSpace_declaration(object _sym_26204)
{
    object _h_26205 = NOVALUE;
    object _14539 = NOVALUE;
    object _14537 = NOVALUE;
    object _14535 = NOVALUE;
    object _14533 = NOVALUE;
    object _14532 = NOVALUE;
    object _14531 = NOVALUE;
    object _14529 = NOVALUE;
    object _14528 = NOVALUE;
    object _14527 = NOVALUE;
    object _14526 = NOVALUE;
    object _14525 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_26204)) {
        _1 = (object)(DBL_PTR(_sym_26204)->dbl);
        DeRefDS(_sym_26204);
        _sym_26204 = _1;
    }

    /** scanner.e:594		DefinedYet(sym)*/
    _53DefinedYet(_sym_26204);

    /** scanner.e:595		if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_PREDEF}) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _14525 = (object)*(((s1_ptr)_2)->base + _sym_26204);
    _2 = (object)SEQ_PTR(_14525);
    _14526 = (object)*(((s1_ptr)_2)->base + 4);
    _14525 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 6;
    ((intptr_t*)_2)[2] = 13;
    ((intptr_t*)_2)[3] = 11;
    ((intptr_t*)_2)[4] = 7;
    _14527 = MAKE_SEQ(_1);
    _14528 = find_from(_14526, _14527, 1);
    _14526 = NOVALUE;
    DeRefDS(_14527);
    _14527 = NOVALUE;
    if (_14528 == 0)
    {
        _14528 = NOVALUE;
        goto L1; // [42] 104
    }
    else{
        _14528 = NOVALUE;
    }

    /** scanner.e:597			h = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _14529 = (object)*(((s1_ptr)_2)->base + _sym_26204);
    _2 = (object)SEQ_PTR(_14529);
    _h_26205 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_26205)){
        _h_26205 = (object)DBL_PTR(_h_26205)->dbl;
    }
    _14529 = NOVALUE;

    /** scanner.e:599			sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _14531 = (object)*(((s1_ptr)_2)->base + _sym_26204);
    _2 = (object)SEQ_PTR(_14531);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _14532 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _14532 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _14531 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_46799);
    _14533 = (object)*(((s1_ptr)_2)->base + _h_26205);
    Ref(_14532);
    Ref(_14533);
    _sym_26204 = _53NewEntry(_14532, 0, 0, -100, _h_26205, _14533, 0);
    _14532 = NOVALUE;
    _14533 = NOVALUE;
    if (!IS_ATOM_INT(_sym_26204)) {
        _1 = (object)(DBL_PTR(_sym_26204)->dbl);
        DeRefDS(_sym_26204);
        _sym_26204 = _1;
    }

    /** scanner.e:600			buckets[h] = sym*/
    _2 = (object)SEQ_PTR(_53buckets_46799);
    _2 = (object)(((s1_ptr)_2)->base + _h_26205);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_26204;
    DeRef(_1);
L1: 

    /** scanner.e:602		SymTab[sym][S_SCOPE] = SC_LOCAL*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26204 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 5;
    DeRef(_1);
    _14535 = NOVALUE;

    /** scanner.e:603		SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26204 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _14537 = NOVALUE;

    /** scanner.e:604		SymTab[sym][S_TOKEN] = NAMESPACE -- [S_OBJ] will get the file number referred-to*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26204 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TOKEN_19869))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 523;
    DeRef(_1);
    _14539 = NOVALUE;

    /** scanner.e:605		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L2; // [159] 173
    }
    else{
    }

    /** scanner.e:606			num_routines += 1 -- order of ns declaration relative to routines*/
    _12num_routines_20235 = _12num_routines_20235 + 1;
L2: 

    /** scanner.e:609		return sym*/
    return _sym_26204;
    ;
}


void _61default_namespace()
{
    object _tok_26255 = NOVALUE;
    object _sym_26257 = NOVALUE;
    object _14563 = NOVALUE;
    object _14562 = NOVALUE;
    object _14560 = NOVALUE;
    object _14558 = NOVALUE;
    object _14555 = NOVALUE;
    object _14552 = NOVALUE;
    object _14550 = NOVALUE;
    object _14548 = NOVALUE;
    object _14547 = NOVALUE;
    object _14546 = NOVALUE;
    object _14545 = NOVALUE;
    object _14544 = NOVALUE;
    object _14543 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:618		tok = call_func( scanner_rid, {} )*/
    _0 = (object)_00[_61scanner_rid_26251].addr;
    _1 = (*(intptr_t (*)())_0)(
                         );
    DeRef(_tok_26255);
    _tok_26255 = _1;

    /** scanner.e:619		if tok[T_ID] = VARIABLE and equal( SymTab[tok[T_SYM]][S_NAME], "namespace" ) then*/
    _2 = (object)SEQ_PTR(_tok_26255);
    _14543 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_14543)) {
        _14544 = (_14543 == -100);
    }
    else {
        _14544 = binary_op(EQUALS, _14543, -100);
    }
    _14543 = NOVALUE;
    if (IS_ATOM_INT(_14544)) {
        if (_14544 == 0) {
            goto L1; // [23] 179
        }
    }
    else {
        if (DBL_PTR(_14544)->dbl == 0.0) {
            goto L1; // [23] 179
        }
    }
    _2 = (object)SEQ_PTR(_tok_26255);
    _14546 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_14546)){
        _14547 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14546)->dbl));
    }
    else{
        _14547 = (object)*(((s1_ptr)_2)->base + _14546);
    }
    _2 = (object)SEQ_PTR(_14547);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _14548 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _14548 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _14547 = NOVALUE;
    if (_14548 == _14549)
    _14550 = 1;
    else if (IS_ATOM_INT(_14548) && IS_ATOM_INT(_14549))
    _14550 = 0;
    else
    _14550 = (compare(_14548, _14549) == 0);
    _14548 = NOVALUE;
    if (_14550 == 0)
    {
        _14550 = NOVALUE;
        goto L1; // [50] 179
    }
    else{
        _14550 = NOVALUE;
    }

    /** scanner.e:621			tok = call_func( scanner_rid, {} )*/
    _0 = (object)_00[_61scanner_rid_26251].addr;
    _1 = (*(intptr_t (*)())_0)(
                         );
    DeRef(_tok_26255);
    _tok_26255 = _1;

    /** scanner.e:622			if tok[T_ID] != VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_26255);
    _14552 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _14552, -100)){
        _14552 = NOVALUE;
        goto L2; // [71] 85
    }
    _14552 = NOVALUE;

    /** scanner.e:623				CompileErr(MISSING_DEFAULT_NAMESPACE_QUALIFIER)*/
    RefDS(_22015);
    _49CompileErr(114, _22015, 0);
L2: 

    /** scanner.e:626			sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_26255);
    _sym_26257 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_26257)){
        _sym_26257 = (object)DBL_PTR(_sym_26257)->dbl;
    }

    /** scanner.e:628			SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26257 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FILE_NO_19860))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12current_file_no_20226;
    DeRef(_1);
    _14555 = NOVALUE;

    /** scanner.e:629			sym  = NameSpace_declaration( sym )*/
    _sym_26257 = _61NameSpace_declaration(_sym_26257);
    if (!IS_ATOM_INT(_sym_26257)) {
        _1 = (object)(DBL_PTR(_sym_26257)->dbl);
        DeRefDS(_sym_26257);
        _sym_26257 = _1;
    }

    /** scanner.e:630			SymTab[sym][S_OBJ] = current_file_no*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26257 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12current_file_no_20226;
    DeRef(_1);
    _14558 = NOVALUE;

    /** scanner.e:631			SymTab[sym][S_SCOPE] = SC_PUBLIC*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26257 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 13;
    DeRef(_1);
    _14560 = NOVALUE;

    /** scanner.e:633			default_namespaces[current_file_no] = SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _14562 = (object)*(((s1_ptr)_2)->base + _sym_26257);
    _2 = (object)SEQ_PTR(_14562);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _14563 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _14563 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _14562 = NOVALUE;
    Ref(_14563);
    _2 = (object)SEQ_PTR(_61default_namespaces_25586);
    _2 = (object)(((s1_ptr)_2)->base + _12current_file_no_20226);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14563;
    if( _1 != _14563 ){
        DeRef(_1);
    }
    _14563 = NOVALUE;
    goto L3; // [176] 187
L1: 

    /** scanner.e:637			bp = 1*/
    _49bp_49265 = 1;
L3: 

    /** scanner.e:640	end procedure*/
    DeRef(_tok_26255);
    DeRef(_14544);
    _14544 = NOVALUE;
    _14546 = NOVALUE;
    return;
    ;
}


void _61add_exports(object _from_file_26308, object _to_file_26309)
{
    object _exports_26310 = NOVALUE;
    object _direct_26311 = NOVALUE;
    object _14583 = NOVALUE;
    object _14582 = NOVALUE;
    object _14581 = NOVALUE;
    object _14580 = NOVALUE;
    object _14579 = NOVALUE;
    object _14577 = NOVALUE;
    object _14575 = NOVALUE;
    object _14574 = NOVALUE;
    object _14572 = NOVALUE;
    object _14571 = NOVALUE;
    object _14570 = NOVALUE;
    object _14568 = NOVALUE;
    object _14567 = NOVALUE;
    object _14566 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:645		direct = file_include[to_file]*/
    DeRef(_direct_26311);
    _2 = (object)SEQ_PTR(_13file_include_11321);
    _direct_26311 = (object)*(((s1_ptr)_2)->base + _to_file_26309);
    Ref(_direct_26311);

    /** scanner.e:646		exports = file_public[from_file]*/
    DeRef(_exports_26310);
    _2 = (object)SEQ_PTR(_13file_public_11328);
    _exports_26310 = (object)*(((s1_ptr)_2)->base + _from_file_26308);
    Ref(_exports_26310);

    /** scanner.e:647		for i = 1 to length(exports) do*/
    if (IS_SEQUENCE(_exports_26310)){
            _14566 = SEQ_PTR(_exports_26310)->length;
    }
    else {
        _14566 = 1;
    }
    {
        object _i_26317;
        _i_26317 = 1;
L1: 
        if (_i_26317 > _14566){
            goto L2; // [30] 127
        }

        /** scanner.e:648			if not find( exports[i], direct ) then*/
        _2 = (object)SEQ_PTR(_exports_26310);
        _14567 = (object)*(((s1_ptr)_2)->base + _i_26317);
        _14568 = find_from(_14567, _direct_26311, 1);
        _14567 = NOVALUE;
        if (_14568 != 0)
        goto L3; // [48] 120
        _14568 = NOVALUE;

        /** scanner.e:649				if not find( -exports[i], direct ) then*/
        _2 = (object)SEQ_PTR(_exports_26310);
        _14570 = (object)*(((s1_ptr)_2)->base + _i_26317);
        if (IS_ATOM_INT(_14570)) {
            if ((uintptr_t)_14570 == (uintptr_t)HIGH_BITS){
                _14571 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _14571 = - _14570;
            }
        }
        else {
            _14571 = unary_op(UMINUS, _14570);
        }
        _14570 = NOVALUE;
        _14572 = find_from(_14571, _direct_26311, 1);
        DeRef(_14571);
        _14571 = NOVALUE;
        if (_14572 != 0)
        goto L4; // [65] 82
        _14572 = NOVALUE;

        /** scanner.e:650					direct &= -exports[i]*/
        _2 = (object)SEQ_PTR(_exports_26310);
        _14574 = (object)*(((s1_ptr)_2)->base + _i_26317);
        if (IS_ATOM_INT(_14574)) {
            if ((uintptr_t)_14574 == (uintptr_t)HIGH_BITS){
                _14575 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _14575 = - _14574;
            }
        }
        else {
            _14575 = unary_op(UMINUS, _14574);
        }
        _14574 = NOVALUE;
        if (IS_SEQUENCE(_direct_26311) && IS_ATOM(_14575)) {
            Ref(_14575);
            Append(&_direct_26311, _direct_26311, _14575);
        }
        else if (IS_ATOM(_direct_26311) && IS_SEQUENCE(_14575)) {
        }
        else {
            Concat((object_ptr)&_direct_26311, _direct_26311, _14575);
        }
        DeRef(_14575);
        _14575 = NOVALUE;
L4: 

        /** scanner.e:654				include_matrix[to_file][exports[i]] = or_bits( PUBLIC_INCLUDE, include_matrix[to_file][exports[i]] )*/
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13include_matrix_11323 = MAKE_SEQ(_2);
        }
        _3 = (object)(_to_file_26309 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_exports_26310);
        _14579 = (object)*(((s1_ptr)_2)->base + _i_26317);
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _14580 = (object)*(((s1_ptr)_2)->base + _to_file_26309);
        _2 = (object)SEQ_PTR(_exports_26310);
        _14581 = (object)*(((s1_ptr)_2)->base + _i_26317);
        _2 = (object)SEQ_PTR(_14580);
        if (!IS_ATOM_INT(_14581)){
            _14582 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14581)->dbl));
        }
        else{
            _14582 = (object)*(((s1_ptr)_2)->base + _14581);
        }
        _14580 = NOVALUE;
        if (IS_ATOM_INT(_14582)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 | (uintptr_t)_14582;
                 _14583 = MAKE_UINT(tu);
            }
        }
        else {
            _14583 = binary_op(OR_BITS, 4, _14582);
        }
        _14582 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14579))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14579)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _14579);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14583;
        if( _1 != _14583 ){
            DeRef(_1);
        }
        _14583 = NOVALUE;
        _14577 = NOVALUE;
L3: 

        /** scanner.e:656		end for*/
        _i_26317 = _i_26317 + 1;
        goto L1; // [122] 37
L2: 
        ;
    }

    /** scanner.e:657		file_include[to_file] = direct*/
    RefDS(_direct_26311);
    _2 = (object)SEQ_PTR(_13file_include_11321);
    _2 = (object)(((s1_ptr)_2)->base + _to_file_26309);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _direct_26311;
    DeRef(_1);

    /** scanner.e:658	end procedure*/
    DeRef(_exports_26310);
    DeRefDS(_direct_26311);
    _14579 = NOVALUE;
    _14581 = NOVALUE;
    return;
    ;
}


void _61patch_exports(object _for_file_26344)
{
    object _export_len_26345 = NOVALUE;
    object _14594 = NOVALUE;
    object _14593 = NOVALUE;
    object _14591 = NOVALUE;
    object _14590 = NOVALUE;
    object _14589 = NOVALUE;
    object _14588 = NOVALUE;
    object _14586 = NOVALUE;
    object _14585 = NOVALUE;
    object _14584 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:663		for i = 1 to length(file_include) do*/
    if (IS_SEQUENCE(_13file_include_11321)){
            _14584 = SEQ_PTR(_13file_include_11321)->length;
    }
    else {
        _14584 = 1;
    }
    {
        object _i_26347;
        _i_26347 = 1;
L1: 
        if (_i_26347 > _14584){
            goto L2; // [10] 99
        }

        /** scanner.e:664			if find( for_file, file_include[i] ) or find( -for_file, file_include[i] ) then*/
        _2 = (object)SEQ_PTR(_13file_include_11321);
        _14585 = (object)*(((s1_ptr)_2)->base + _i_26347);
        _14586 = find_from(_for_file_26344, _14585, 1);
        _14585 = NOVALUE;
        if (_14586 != 0) {
            goto L3; // [30] 53
        }
        if ((uintptr_t)_for_file_26344 == (uintptr_t)HIGH_BITS){
            _14588 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _14588 = - _for_file_26344;
        }
        _2 = (object)SEQ_PTR(_13file_include_11321);
        _14589 = (object)*(((s1_ptr)_2)->base + _i_26347);
        _14590 = find_from(_14588, _14589, 1);
        DeRef(_14588);
        _14588 = NOVALUE;
        _14589 = NOVALUE;
        if (_14590 == 0)
        {
            _14590 = NOVALUE;
            goto L4; // [49] 92
        }
        else{
            _14590 = NOVALUE;
        }
L3: 

        /** scanner.e:665				export_len = length( file_include[i] )*/
        _2 = (object)SEQ_PTR(_13file_include_11321);
        _14591 = (object)*(((s1_ptr)_2)->base + _i_26347);
        if (IS_SEQUENCE(_14591)){
                _export_len_26345 = SEQ_PTR(_14591)->length;
        }
        else {
            _export_len_26345 = 1;
        }
        _14591 = NOVALUE;

        /** scanner.e:666				add_exports( for_file, i )*/
        _61add_exports(_for_file_26344, _i_26347);

        /** scanner.e:667				if length( file_include[i] ) != export_len then*/
        _2 = (object)SEQ_PTR(_13file_include_11321);
        _14593 = (object)*(((s1_ptr)_2)->base + _i_26347);
        if (IS_SEQUENCE(_14593)){
                _14594 = SEQ_PTR(_14593)->length;
        }
        else {
            _14594 = 1;
        }
        _14593 = NOVALUE;
        if (_14594 == _export_len_26345)
        goto L5; // [81] 91

        /** scanner.e:669					patch_exports( i )*/
        _61patch_exports(_i_26347);
L5: 
L4: 

        /** scanner.e:672		end for*/
        _i_26347 = _i_26347 + 1;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** scanner.e:673	end procedure*/
    _14591 = NOVALUE;
    _14593 = NOVALUE;
    return;
    ;
}


void _61update_include_matrix(object _included_file_26369, object _from_file_26370)
{
    object _add_public_26380 = NOVALUE;
    object _px_26398 = NOVALUE;
    object _indirect_26457 = NOVALUE;
    object _mask_26460 = NOVALUE;
    object _ix_26471 = NOVALUE;
    object _indirect_file_26475 = NOVALUE;
    object _14670 = NOVALUE;
    object _14669 = NOVALUE;
    object _14667 = NOVALUE;
    object _14666 = NOVALUE;
    object _14665 = NOVALUE;
    object _14664 = NOVALUE;
    object _14663 = NOVALUE;
    object _14662 = NOVALUE;
    object _14661 = NOVALUE;
    object _14660 = NOVALUE;
    object _14659 = NOVALUE;
    object _14656 = NOVALUE;
    object _14654 = NOVALUE;
    object _14653 = NOVALUE;
    object _14652 = NOVALUE;
    object _14650 = NOVALUE;
    object _14648 = NOVALUE;
    object _14647 = NOVALUE;
    object _14645 = NOVALUE;
    object _14644 = NOVALUE;
    object _14643 = NOVALUE;
    object _14642 = NOVALUE;
    object _14641 = NOVALUE;
    object _14639 = NOVALUE;
    object _14638 = NOVALUE;
    object _14637 = NOVALUE;
    object _14636 = NOVALUE;
    object _14635 = NOVALUE;
    object _14634 = NOVALUE;
    object _14632 = NOVALUE;
    object _14631 = NOVALUE;
    object _14630 = NOVALUE;
    object _14628 = NOVALUE;
    object _14627 = NOVALUE;
    object _14626 = NOVALUE;
    object _14625 = NOVALUE;
    object _14624 = NOVALUE;
    object _14623 = NOVALUE;
    object _14622 = NOVALUE;
    object _14621 = NOVALUE;
    object _14620 = NOVALUE;
    object _14619 = NOVALUE;
    object _14618 = NOVALUE;
    object _14616 = NOVALUE;
    object _14615 = NOVALUE;
    object _14613 = NOVALUE;
    object _14611 = NOVALUE;
    object _14609 = NOVALUE;
    object _14608 = NOVALUE;
    object _14607 = NOVALUE;
    object _14606 = NOVALUE;
    object _14604 = NOVALUE;
    object _14603 = NOVALUE;
    object _14602 = NOVALUE;
    object _14600 = NOVALUE;
    object _14599 = NOVALUE;
    object _14598 = NOVALUE;
    object _14596 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:684		include_matrix[from_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[from_file][included_file] )*/
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13include_matrix_11323 = MAKE_SEQ(_2);
    }
    _3 = (object)(_from_file_26370 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _14598 = (object)*(((s1_ptr)_2)->base + _from_file_26370);
    _2 = (object)SEQ_PTR(_14598);
    _14599 = (object)*(((s1_ptr)_2)->base + _included_file_26369);
    _14598 = NOVALUE;
    if (IS_ATOM_INT(_14599)) {
        {uintptr_t tu;
             tu = (uintptr_t)2 | (uintptr_t)_14599;
             _14600 = MAKE_UINT(tu);
        }
    }
    else {
        _14600 = binary_op(OR_BITS, 2, _14599);
    }
    _14599 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26369);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14600;
    if( _1 != _14600 ){
        DeRef(_1);
    }
    _14600 = NOVALUE;
    _14596 = NOVALUE;

    /** scanner.e:686		if public_include then*/
    if (_61public_include_25583 == 0)
    {
        goto L1; // [38] 339
    }
    else{
    }

    /** scanner.e:689			sequence add_public = file_include_by[from_file]*/
    DeRef(_add_public_26380);
    _2 = (object)SEQ_PTR(_13file_include_by_11330);
    _add_public_26380 = (object)*(((s1_ptr)_2)->base + _from_file_26370);
    Ref(_add_public_26380);

    /** scanner.e:690			for i = 1 to length( add_public ) do*/
    if (IS_SEQUENCE(_add_public_26380)){
            _14602 = SEQ_PTR(_add_public_26380)->length;
    }
    else {
        _14602 = 1;
    }
    {
        object _i_26384;
        _i_26384 = 1;
L2: 
        if (_i_26384 > _14602){
            goto L3; // [56] 107
        }

        /** scanner.e:692				include_matrix[add_public[i]][included_file] =*/
        _2 = (object)SEQ_PTR(_add_public_26380);
        _14603 = (object)*(((s1_ptr)_2)->base + _i_26384);
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13include_matrix_11323 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14603))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14603)->dbl));
        else
        _3 = (object)(_14603 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_add_public_26380);
        _14606 = (object)*(((s1_ptr)_2)->base + _i_26384);
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        if (!IS_ATOM_INT(_14606)){
            _14607 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14606)->dbl));
        }
        else{
            _14607 = (object)*(((s1_ptr)_2)->base + _14606);
        }
        _2 = (object)SEQ_PTR(_14607);
        _14608 = (object)*(((s1_ptr)_2)->base + _included_file_26369);
        _14607 = NOVALUE;
        if (IS_ATOM_INT(_14608)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 | (uintptr_t)_14608;
                 _14609 = MAKE_UINT(tu);
            }
        }
        else {
            _14609 = binary_op(OR_BITS, 4, _14608);
        }
        _14608 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _included_file_26369);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14609;
        if( _1 != _14609 ){
            DeRef(_1);
        }
        _14609 = NOVALUE;
        _14604 = NOVALUE;

        /** scanner.e:695			end for*/
        _i_26384 = _i_26384 + 1;
        goto L2; // [102] 63
L3: 
        ;
    }

    /** scanner.e:698			add_public = file_public_by[from_file]*/
    DeRef(_add_public_26380);
    _2 = (object)SEQ_PTR(_13file_public_by_11332);
    _add_public_26380 = (object)*(((s1_ptr)_2)->base + _from_file_26370);
    Ref(_add_public_26380);

    /** scanner.e:699			integer px = length( add_public ) + 1*/
    if (IS_SEQUENCE(_add_public_26380)){
            _14611 = SEQ_PTR(_add_public_26380)->length;
    }
    else {
        _14611 = 1;
    }
    _px_26398 = _14611 + 1;
    _14611 = NOVALUE;

    /** scanner.e:700			while px <= length( add_public ) do*/
L4: 
    if (IS_SEQUENCE(_add_public_26380)){
            _14613 = SEQ_PTR(_add_public_26380)->length;
    }
    else {
        _14613 = 1;
    }
    if (_px_26398 > _14613)
    goto L5; // [134] 338

    /** scanner.e:701				include_matrix[add_public[px]][included_file] =*/
    _2 = (object)SEQ_PTR(_add_public_26380);
    _14615 = (object)*(((s1_ptr)_2)->base + _px_26398);
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13include_matrix_11323 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14615))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14615)->dbl));
    else
    _3 = (object)(_14615 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_add_public_26380);
    _14618 = (object)*(((s1_ptr)_2)->base + _px_26398);
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    if (!IS_ATOM_INT(_14618)){
        _14619 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14618)->dbl));
    }
    else{
        _14619 = (object)*(((s1_ptr)_2)->base + _14618);
    }
    _2 = (object)SEQ_PTR(_14619);
    _14620 = (object)*(((s1_ptr)_2)->base + _included_file_26369);
    _14619 = NOVALUE;
    if (IS_ATOM_INT(_14620)) {
        {uintptr_t tu;
             tu = (uintptr_t)4 | (uintptr_t)_14620;
             _14621 = MAKE_UINT(tu);
        }
    }
    else {
        _14621 = binary_op(OR_BITS, 4, _14620);
    }
    _14620 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26369);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14621;
    if( _1 != _14621 ){
        DeRef(_1);
    }
    _14621 = NOVALUE;
    _14616 = NOVALUE;

    /** scanner.e:704				for i = 1 to length( file_public_by[add_public[px]] ) do*/
    _2 = (object)SEQ_PTR(_add_public_26380);
    _14622 = (object)*(((s1_ptr)_2)->base + _px_26398);
    _2 = (object)SEQ_PTR(_13file_public_by_11332);
    if (!IS_ATOM_INT(_14622)){
        _14623 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14622)->dbl));
    }
    else{
        _14623 = (object)*(((s1_ptr)_2)->base + _14622);
    }
    if (IS_SEQUENCE(_14623)){
            _14624 = SEQ_PTR(_14623)->length;
    }
    else {
        _14624 = 1;
    }
    _14623 = NOVALUE;
    {
        object _i_26415;
        _i_26415 = 1;
L6: 
        if (_i_26415 > _14624){
            goto L7; // [190] 249
        }

        /** scanner.e:705					if not find( file_public[add_public[px]][i], add_public ) then*/
        _2 = (object)SEQ_PTR(_add_public_26380);
        _14625 = (object)*(((s1_ptr)_2)->base + _px_26398);
        _2 = (object)SEQ_PTR(_13file_public_11328);
        if (!IS_ATOM_INT(_14625)){
            _14626 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14625)->dbl));
        }
        else{
            _14626 = (object)*(((s1_ptr)_2)->base + _14625);
        }
        _2 = (object)SEQ_PTR(_14626);
        _14627 = (object)*(((s1_ptr)_2)->base + _i_26415);
        _14626 = NOVALUE;
        _14628 = find_from(_14627, _add_public_26380, 1);
        _14627 = NOVALUE;
        if (_14628 != 0)
        goto L8; // [218] 242
        _14628 = NOVALUE;

        /** scanner.e:706						add_public &= file_public[add_public[px]][i]*/
        _2 = (object)SEQ_PTR(_add_public_26380);
        _14630 = (object)*(((s1_ptr)_2)->base + _px_26398);
        _2 = (object)SEQ_PTR(_13file_public_11328);
        if (!IS_ATOM_INT(_14630)){
            _14631 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14630)->dbl));
        }
        else{
            _14631 = (object)*(((s1_ptr)_2)->base + _14630);
        }
        _2 = (object)SEQ_PTR(_14631);
        _14632 = (object)*(((s1_ptr)_2)->base + _i_26415);
        _14631 = NOVALUE;
        if (IS_SEQUENCE(_add_public_26380) && IS_ATOM(_14632)) {
            Ref(_14632);
            Append(&_add_public_26380, _add_public_26380, _14632);
        }
        else if (IS_ATOM(_add_public_26380) && IS_SEQUENCE(_14632)) {
        }
        else {
            Concat((object_ptr)&_add_public_26380, _add_public_26380, _14632);
        }
        _14632 = NOVALUE;
L8: 

        /** scanner.e:708				end for*/
        _i_26415 = _i_26415 + 1;
        goto L6; // [244] 197
L7: 
        ;
    }

    /** scanner.e:710				for i = 1 to length( file_include_by[add_public[px]] ) do*/
    _2 = (object)SEQ_PTR(_add_public_26380);
    _14634 = (object)*(((s1_ptr)_2)->base + _px_26398);
    _2 = (object)SEQ_PTR(_13file_include_by_11330);
    if (!IS_ATOM_INT(_14634)){
        _14635 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14634)->dbl));
    }
    else{
        _14635 = (object)*(((s1_ptr)_2)->base + _14634);
    }
    if (IS_SEQUENCE(_14635)){
            _14636 = SEQ_PTR(_14635)->length;
    }
    else {
        _14636 = 1;
    }
    _14635 = NOVALUE;
    {
        object _i_26433;
        _i_26433 = 1;
L9: 
        if (_i_26433 > _14636){
            goto LA; // [264] 327
        }

        /** scanner.e:711					include_matrix[file_include_by[add_public[px]]][included_file] =*/
        _2 = (object)SEQ_PTR(_add_public_26380);
        _14637 = (object)*(((s1_ptr)_2)->base + _px_26398);
        _2 = (object)SEQ_PTR(_13file_include_by_11330);
        if (!IS_ATOM_INT(_14637)){
            _14638 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14637)->dbl));
        }
        else{
            _14638 = (object)*(((s1_ptr)_2)->base + _14637);
        }
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13include_matrix_11323 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14638))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14638)->dbl));
        else
        _3 = (object)(_14638 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_add_public_26380);
        _14641 = (object)*(((s1_ptr)_2)->base + _px_26398);
        _2 = (object)SEQ_PTR(_13file_include_by_11330);
        if (!IS_ATOM_INT(_14641)){
            _14642 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14641)->dbl));
        }
        else{
            _14642 = (object)*(((s1_ptr)_2)->base + _14641);
        }
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        if (!IS_ATOM_INT(_14642)){
            _14643 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14642)->dbl));
        }
        else{
            _14643 = (object)*(((s1_ptr)_2)->base + _14642);
        }
        _2 = (object)SEQ_PTR(_14643);
        _14644 = (object)*(((s1_ptr)_2)->base + _included_file_26369);
        _14643 = NOVALUE;
        if (IS_ATOM_INT(_14644)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 | (uintptr_t)_14644;
                 _14645 = MAKE_UINT(tu);
            }
        }
        else {
            _14645 = binary_op(OR_BITS, 4, _14644);
        }
        _14644 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _included_file_26369);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14645;
        if( _1 != _14645 ){
            DeRef(_1);
        }
        _14645 = NOVALUE;
        _14639 = NOVALUE;

        /** scanner.e:713				end for*/
        _i_26433 = _i_26433 + 1;
        goto L9; // [322] 271
LA: 
        ;
    }

    /** scanner.e:715				px += 1*/
    _px_26398 = _px_26398 + 1;

    /** scanner.e:716			end while*/
    goto L4; // [335] 131
L5: 
L1: 
    DeRef(_add_public_26380);
    _add_public_26380 = NOVALUE;

    /** scanner.e:721		if indirect_include[from_file][included_file] then*/
    _2 = (object)SEQ_PTR(_13indirect_include_11326);
    _14647 = (object)*(((s1_ptr)_2)->base + _from_file_26370);
    _2 = (object)SEQ_PTR(_14647);
    _14648 = (object)*(((s1_ptr)_2)->base + _included_file_26369);
    _14647 = NOVALUE;
    if (_14648 == 0) {
        _14648 = NOVALUE;
        goto LB; // [353] 545
    }
    else {
        if (!IS_ATOM_INT(_14648) && DBL_PTR(_14648)->dbl == 0.0){
            _14648 = NOVALUE;
            goto LB; // [353] 545
        }
        _14648 = NOVALUE;
    }
    _14648 = NOVALUE;

    /** scanner.e:723			sequence indirect = file_include_by[from_file]*/
    DeRef(_indirect_26457);
    _2 = (object)SEQ_PTR(_13file_include_by_11330);
    _indirect_26457 = (object)*(((s1_ptr)_2)->base + _from_file_26370);
    Ref(_indirect_26457);

    /** scanner.e:725			sequence mask = include_matrix[included_file] != 0*/
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _14650 = (object)*(((s1_ptr)_2)->base + _included_file_26369);
    DeRef(_mask_26460);
    if (IS_ATOM_INT(_14650)) {
        _mask_26460 = (_14650 != 0);
    }
    else {
        _mask_26460 = binary_op(NOTEQ, _14650, 0);
    }
    _14650 = NOVALUE;

    /** scanner.e:726			include_matrix[from_file] = or_bits( include_matrix[from_file], mask )*/
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _14652 = (object)*(((s1_ptr)_2)->base + _from_file_26370);
    _14653 = binary_op(OR_BITS, _14652, _mask_26460);
    _14652 = NOVALUE;
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _2 = (object)(((s1_ptr)_2)->base + _from_file_26370);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14653;
    if( _1 != _14653 ){
        DeRef(_1);
    }
    _14653 = NOVALUE;

    /** scanner.e:727			mask = include_matrix[from_file] != 0*/
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _14654 = (object)*(((s1_ptr)_2)->base + _from_file_26370);
    DeRefDS(_mask_26460);
    if (IS_ATOM_INT(_14654)) {
        _mask_26460 = (_14654 != 0);
    }
    else {
        _mask_26460 = binary_op(NOTEQ, _14654, 0);
    }
    _14654 = NOVALUE;

    /** scanner.e:728			integer ix = 1*/
    _ix_26471 = 1;

    /** scanner.e:729			while ix <= length(indirect) do*/
LC: 
    if (IS_SEQUENCE(_indirect_26457)){
            _14656 = SEQ_PTR(_indirect_26457)->length;
    }
    else {
        _14656 = 1;
    }
    if (_ix_26471 > _14656)
    goto LD; // [425] 544

    /** scanner.e:730				integer indirect_file = indirect[ix]*/
    _2 = (object)SEQ_PTR(_indirect_26457);
    _indirect_file_26475 = (object)*(((s1_ptr)_2)->base + _ix_26471);
    if (!IS_ATOM_INT(_indirect_file_26475))
    _indirect_file_26475 = (object)DBL_PTR(_indirect_file_26475)->dbl;

    /** scanner.e:731				if indirect_include[indirect_file][included_file] then*/
    _2 = (object)SEQ_PTR(_13indirect_include_11326);
    _14659 = (object)*(((s1_ptr)_2)->base + _indirect_file_26475);
    _2 = (object)SEQ_PTR(_14659);
    _14660 = (object)*(((s1_ptr)_2)->base + _included_file_26369);
    _14659 = NOVALUE;
    if (_14660 == 0) {
        _14660 = NOVALUE;
        goto LE; // [447] 531
    }
    else {
        if (!IS_ATOM_INT(_14660) && DBL_PTR(_14660)->dbl == 0.0){
            _14660 = NOVALUE;
            goto LE; // [447] 531
        }
        _14660 = NOVALUE;
    }
    _14660 = NOVALUE;

    /** scanner.e:732					include_matrix[indirect_file] =*/
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _14661 = (object)*(((s1_ptr)_2)->base + _indirect_file_26475);
    _14662 = binary_op(OR_BITS, _mask_26460, _14661);
    _14661 = NOVALUE;
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _2 = (object)(((s1_ptr)_2)->base + _indirect_file_26475);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14662;
    if( _1 != _14662 ){
        DeRef(_1);
    }
    _14662 = NOVALUE;

    /** scanner.e:734					for i = 1 to length( file_include_by[indirect_file] ) do*/
    _2 = (object)SEQ_PTR(_13file_include_by_11330);
    _14663 = (object)*(((s1_ptr)_2)->base + _indirect_file_26475);
    if (IS_SEQUENCE(_14663)){
            _14664 = SEQ_PTR(_14663)->length;
    }
    else {
        _14664 = 1;
    }
    _14663 = NOVALUE;
    {
        object _i_26486;
        _i_26486 = 1;
LF: 
        if (_i_26486 > _14664){
            goto L10; // [479] 530
        }

        /** scanner.e:736						if not find( file_include_by[indirect_file][i], indirect ) then*/
        _2 = (object)SEQ_PTR(_13file_include_by_11330);
        _14665 = (object)*(((s1_ptr)_2)->base + _indirect_file_26475);
        _2 = (object)SEQ_PTR(_14665);
        _14666 = (object)*(((s1_ptr)_2)->base + _i_26486);
        _14665 = NOVALUE;
        _14667 = find_from(_14666, _indirect_26457, 1);
        _14666 = NOVALUE;
        if (_14667 != 0)
        goto L11; // [503] 523
        _14667 = NOVALUE;

        /** scanner.e:737							indirect &= file_include_by[indirect_file][i]*/
        _2 = (object)SEQ_PTR(_13file_include_by_11330);
        _14669 = (object)*(((s1_ptr)_2)->base + _indirect_file_26475);
        _2 = (object)SEQ_PTR(_14669);
        _14670 = (object)*(((s1_ptr)_2)->base + _i_26486);
        _14669 = NOVALUE;
        if (IS_SEQUENCE(_indirect_26457) && IS_ATOM(_14670)) {
            Ref(_14670);
            Append(&_indirect_26457, _indirect_26457, _14670);
        }
        else if (IS_ATOM(_indirect_26457) && IS_SEQUENCE(_14670)) {
        }
        else {
            Concat((object_ptr)&_indirect_26457, _indirect_26457, _14670);
        }
        _14670 = NOVALUE;
L11: 

        /** scanner.e:740					end for*/
        _i_26486 = _i_26486 + 1;
        goto LF; // [525] 486
L10: 
        ;
    }
LE: 

    /** scanner.e:742				ix += 1*/
    _ix_26471 = _ix_26471 + 1;

    /** scanner.e:743			end while*/
    goto LC; // [541] 422
LD: 
LB: 
    DeRef(_indirect_26457);
    _indirect_26457 = NOVALUE;
    DeRef(_mask_26460);
    _mask_26460 = NOVALUE;

    /** scanner.e:746		public_include = FALSE*/
    _61public_include_25583 = _9FALSE_444;

    /** scanner.e:747	end procedure*/
    _14635 = NOVALUE;
    _14637 = NOVALUE;
    _14641 = NOVALUE;
    _14630 = NOVALUE;
    _14603 = NOVALUE;
    _14606 = NOVALUE;
    _14638 = NOVALUE;
    _14615 = NOVALUE;
    _14622 = NOVALUE;
    _14634 = NOVALUE;
    _14663 = NOVALUE;
    _14642 = NOVALUE;
    _14625 = NOVALUE;
    _14623 = NOVALUE;
    _14618 = NOVALUE;
    return;
    ;
}


void _61add_include_by(object _by_file_26504, object _included_file_26505, object _is_public_26506)
{
    object _14717 = NOVALUE;
    object _14716 = NOVALUE;
    object _14715 = NOVALUE;
    object _14713 = NOVALUE;
    object _14712 = NOVALUE;
    object _14711 = NOVALUE;
    object _14710 = NOVALUE;
    object _14708 = NOVALUE;
    object _14707 = NOVALUE;
    object _14706 = NOVALUE;
    object _14705 = NOVALUE;
    object _14704 = NOVALUE;
    object _14703 = NOVALUE;
    object _14702 = NOVALUE;
    object _14701 = NOVALUE;
    object _14699 = NOVALUE;
    object _14698 = NOVALUE;
    object _14697 = NOVALUE;
    object _14696 = NOVALUE;
    object _14694 = NOVALUE;
    object _14693 = NOVALUE;
    object _14692 = NOVALUE;
    object _14691 = NOVALUE;
    object _14689 = NOVALUE;
    object _14688 = NOVALUE;
    object _14687 = NOVALUE;
    object _14686 = NOVALUE;
    object _14684 = NOVALUE;
    object _14683 = NOVALUE;
    object _14682 = NOVALUE;
    object _14681 = NOVALUE;
    object _14680 = NOVALUE;
    object _14678 = NOVALUE;
    object _14677 = NOVALUE;
    object _14676 = NOVALUE;
    object _14675 = NOVALUE;
    object _14673 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:750		include_matrix[by_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13include_matrix_11323 = MAKE_SEQ(_2);
    }
    _3 = (object)(_by_file_26504 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _14675 = (object)*(((s1_ptr)_2)->base + _by_file_26504);
    _2 = (object)SEQ_PTR(_14675);
    _14676 = (object)*(((s1_ptr)_2)->base + _included_file_26505);
    _14675 = NOVALUE;
    if (IS_ATOM_INT(_14676)) {
        {uintptr_t tu;
             tu = (uintptr_t)2 | (uintptr_t)_14676;
             _14677 = MAKE_UINT(tu);
        }
    }
    else {
        _14677 = binary_op(OR_BITS, 2, _14676);
    }
    _14676 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26505);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14677;
    if( _1 != _14677 ){
        DeRef(_1);
    }
    _14677 = NOVALUE;
    _14673 = NOVALUE;

    /** scanner.e:751		if is_public then*/
    if (_is_public_26506 == 0)
    {
        goto L1; // [38] 71
    }
    else{
    }

    /** scanner.e:752			include_matrix[by_file][included_file] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13include_matrix_11323 = MAKE_SEQ(_2);
    }
    _3 = (object)(_by_file_26504 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _14680 = (object)*(((s1_ptr)_2)->base + _by_file_26504);
    _2 = (object)SEQ_PTR(_14680);
    _14681 = (object)*(((s1_ptr)_2)->base + _included_file_26505);
    _14680 = NOVALUE;
    if (IS_ATOM_INT(_14681)) {
        {uintptr_t tu;
             tu = (uintptr_t)4 | (uintptr_t)_14681;
             _14682 = MAKE_UINT(tu);
        }
    }
    else {
        _14682 = binary_op(OR_BITS, 4, _14681);
    }
    _14681 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26505);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14682;
    if( _1 != _14682 ){
        DeRef(_1);
    }
    _14682 = NOVALUE;
    _14678 = NOVALUE;
L1: 

    /** scanner.e:754		if not find( by_file, file_include_by[included_file] ) then*/
    _2 = (object)SEQ_PTR(_13file_include_by_11330);
    _14683 = (object)*(((s1_ptr)_2)->base + _included_file_26505);
    _14684 = find_from(_by_file_26504, _14683, 1);
    _14683 = NOVALUE;
    if (_14684 != 0)
    goto L2; // [84] 104
    _14684 = NOVALUE;

    /** scanner.e:755			file_include_by[included_file] &= by_file*/
    _2 = (object)SEQ_PTR(_13file_include_by_11330);
    _14686 = (object)*(((s1_ptr)_2)->base + _included_file_26505);
    if (IS_SEQUENCE(_14686) && IS_ATOM(_by_file_26504)) {
        Append(&_14687, _14686, _by_file_26504);
    }
    else if (IS_ATOM(_14686) && IS_SEQUENCE(_by_file_26504)) {
    }
    else {
        Concat((object_ptr)&_14687, _14686, _by_file_26504);
        _14686 = NOVALUE;
    }
    _14686 = NOVALUE;
    _2 = (object)SEQ_PTR(_13file_include_by_11330);
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26505);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14687;
    if( _1 != _14687 ){
        DeRef(_1);
    }
    _14687 = NOVALUE;
L2: 

    /** scanner.e:758		if not find( included_file, file_include[by_file] ) then*/
    _2 = (object)SEQ_PTR(_13file_include_11321);
    _14688 = (object)*(((s1_ptr)_2)->base + _by_file_26504);
    _14689 = find_from(_included_file_26505, _14688, 1);
    _14688 = NOVALUE;
    if (_14689 != 0)
    goto L3; // [117] 137
    _14689 = NOVALUE;

    /** scanner.e:759			file_include[by_file] &= included_file*/
    _2 = (object)SEQ_PTR(_13file_include_11321);
    _14691 = (object)*(((s1_ptr)_2)->base + _by_file_26504);
    if (IS_SEQUENCE(_14691) && IS_ATOM(_included_file_26505)) {
        Append(&_14692, _14691, _included_file_26505);
    }
    else if (IS_ATOM(_14691) && IS_SEQUENCE(_included_file_26505)) {
    }
    else {
        Concat((object_ptr)&_14692, _14691, _included_file_26505);
        _14691 = NOVALUE;
    }
    _14691 = NOVALUE;
    _2 = (object)SEQ_PTR(_13file_include_11321);
    _2 = (object)(((s1_ptr)_2)->base + _by_file_26504);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14692;
    if( _1 != _14692 ){
        DeRef(_1);
    }
    _14692 = NOVALUE;
L3: 

    /** scanner.e:762		if is_public then*/
    if (_is_public_26506 == 0)
    {
        goto L4; // [139] 209
    }
    else{
    }

    /** scanner.e:763			if not find( by_file, file_public_by[included_file] ) then*/
    _2 = (object)SEQ_PTR(_13file_public_by_11332);
    _14693 = (object)*(((s1_ptr)_2)->base + _included_file_26505);
    _14694 = find_from(_by_file_26504, _14693, 1);
    _14693 = NOVALUE;
    if (_14694 != 0)
    goto L5; // [155] 175
    _14694 = NOVALUE;

    /** scanner.e:764				file_public_by[included_file] &= by_file*/
    _2 = (object)SEQ_PTR(_13file_public_by_11332);
    _14696 = (object)*(((s1_ptr)_2)->base + _included_file_26505);
    if (IS_SEQUENCE(_14696) && IS_ATOM(_by_file_26504)) {
        Append(&_14697, _14696, _by_file_26504);
    }
    else if (IS_ATOM(_14696) && IS_SEQUENCE(_by_file_26504)) {
    }
    else {
        Concat((object_ptr)&_14697, _14696, _by_file_26504);
        _14696 = NOVALUE;
    }
    _14696 = NOVALUE;
    _2 = (object)SEQ_PTR(_13file_public_by_11332);
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26505);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14697;
    if( _1 != _14697 ){
        DeRef(_1);
    }
    _14697 = NOVALUE;
L5: 

    /** scanner.e:767			if not find( included_file, file_public[by_file] ) then*/
    _2 = (object)SEQ_PTR(_13file_public_11328);
    _14698 = (object)*(((s1_ptr)_2)->base + _by_file_26504);
    _14699 = find_from(_included_file_26505, _14698, 1);
    _14698 = NOVALUE;
    if (_14699 != 0)
    goto L6; // [188] 208
    _14699 = NOVALUE;

    /** scanner.e:768				file_public[by_file] &= included_file*/
    _2 = (object)SEQ_PTR(_13file_public_11328);
    _14701 = (object)*(((s1_ptr)_2)->base + _by_file_26504);
    if (IS_SEQUENCE(_14701) && IS_ATOM(_included_file_26505)) {
        Append(&_14702, _14701, _included_file_26505);
    }
    else if (IS_ATOM(_14701) && IS_SEQUENCE(_included_file_26505)) {
    }
    else {
        Concat((object_ptr)&_14702, _14701, _included_file_26505);
        _14701 = NOVALUE;
    }
    _14701 = NOVALUE;
    _2 = (object)SEQ_PTR(_13file_public_11328);
    _2 = (object)(((s1_ptr)_2)->base + _by_file_26504);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14702;
    if( _1 != _14702 ){
        DeRef(_1);
    }
    _14702 = NOVALUE;
L6: 
L4: 

    /** scanner.e:772		for propagate = 1 to length( include_matrix[included_file] ) do*/
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _14703 = (object)*(((s1_ptr)_2)->base + _included_file_26505);
    if (IS_SEQUENCE(_14703)){
            _14704 = SEQ_PTR(_14703)->length;
    }
    else {
        _14704 = 1;
    }
    _14703 = NOVALUE;
    {
        object _propagate_26558;
        _propagate_26558 = 1;
L7: 
        if (_propagate_26558 > _14704){
            goto L8; // [220] 320
        }

        /** scanner.e:773			if and_bits( PUBLIC_INCLUDE, include_matrix[included_file][propagate] ) then*/
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _14705 = (object)*(((s1_ptr)_2)->base + _included_file_26505);
        _2 = (object)SEQ_PTR(_14705);
        _14706 = (object)*(((s1_ptr)_2)->base + _propagate_26558);
        _14705 = NOVALUE;
        if (IS_ATOM_INT(_14706)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 & (uintptr_t)_14706;
                 _14707 = MAKE_UINT(tu);
            }
        }
        else {
            _14707 = binary_op(AND_BITS, 4, _14706);
        }
        _14706 = NOVALUE;
        if (_14707 == 0) {
            DeRef(_14707);
            _14707 = NOVALUE;
            goto L9; // [245] 313
        }
        else {
            if (!IS_ATOM_INT(_14707) && DBL_PTR(_14707)->dbl == 0.0){
                DeRef(_14707);
                _14707 = NOVALUE;
                goto L9; // [245] 313
            }
            DeRef(_14707);
            _14707 = NOVALUE;
        }
        DeRef(_14707);
        _14707 = NOVALUE;

        /** scanner.e:774				include_matrix[by_file][propagate] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13include_matrix_11323 = MAKE_SEQ(_2);
        }
        _3 = (object)(_by_file_26504 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _14710 = (object)*(((s1_ptr)_2)->base + _by_file_26504);
        _2 = (object)SEQ_PTR(_14710);
        _14711 = (object)*(((s1_ptr)_2)->base + _propagate_26558);
        _14710 = NOVALUE;
        if (IS_ATOM_INT(_14711)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2 | (uintptr_t)_14711;
                 _14712 = MAKE_UINT(tu);
            }
        }
        else {
            _14712 = binary_op(OR_BITS, 2, _14711);
        }
        _14711 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _propagate_26558);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14712;
        if( _1 != _14712 ){
            DeRef(_1);
        }
        _14712 = NOVALUE;
        _14708 = NOVALUE;

        /** scanner.e:775				if is_public then*/
        if (_is_public_26506 == 0)
        {
            goto LA; // [279] 312
        }
        else{
        }

        /** scanner.e:776					include_matrix[by_file][propagate] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13include_matrix_11323 = MAKE_SEQ(_2);
        }
        _3 = (object)(_by_file_26504 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _14715 = (object)*(((s1_ptr)_2)->base + _by_file_26504);
        _2 = (object)SEQ_PTR(_14715);
        _14716 = (object)*(((s1_ptr)_2)->base + _propagate_26558);
        _14715 = NOVALUE;
        if (IS_ATOM_INT(_14716)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 | (uintptr_t)_14716;
                 _14717 = MAKE_UINT(tu);
            }
        }
        else {
            _14717 = binary_op(OR_BITS, 4, _14716);
        }
        _14716 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _propagate_26558);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14717;
        if( _1 != _14717 ){
            DeRef(_1);
        }
        _14717 = NOVALUE;
        _14713 = NOVALUE;
LA: 
L9: 

        /** scanner.e:779		end for*/
        _propagate_26558 = _propagate_26558 + 1;
        goto L7; // [315] 227
L8: 
        ;
    }

    /** scanner.e:780	end procedure*/
    _14703 = NOVALUE;
    return;
    ;
}


void _61IncludePush()
{
    object _new_file_handle_26587 = NOVALUE;
    object _old_file_no_26588 = NOVALUE;
    object _new_hash_26589 = NOVALUE;
    object _idx_26590 = NOVALUE;
    object _14804 = NOVALUE;
    object _14801 = NOVALUE;
    object _14799 = NOVALUE;
    object _14798 = NOVALUE;
    object _14797 = NOVALUE;
    object _14795 = NOVALUE;
    object _14794 = NOVALUE;
    object _14788 = NOVALUE;
    object _14787 = NOVALUE;
    object _14786 = NOVALUE;
    object _14785 = NOVALUE;
    object _14784 = NOVALUE;
    object _14783 = NOVALUE;
    object _14782 = NOVALUE;
    object _14779 = NOVALUE;
    object _14777 = NOVALUE;
    object _14775 = NOVALUE;
    object _14774 = NOVALUE;
    object _14773 = NOVALUE;
    object _14771 = NOVALUE;
    object _14770 = NOVALUE;
    object _14768 = NOVALUE;
    object _14767 = NOVALUE;
    object _14765 = NOVALUE;
    object _14764 = NOVALUE;
    object _14763 = NOVALUE;
    object _14762 = NOVALUE;
    object _14761 = NOVALUE;
    object _14760 = NOVALUE;
    object _14759 = NOVALUE;
    object _14755 = NOVALUE;
    object _14753 = NOVALUE;
    object _14752 = NOVALUE;
    object _14751 = NOVALUE;
    object _14750 = NOVALUE;
    object _14749 = NOVALUE;
    object _14748 = NOVALUE;
    object _14747 = NOVALUE;
    object _14746 = NOVALUE;
    object _14745 = NOVALUE;
    object _14743 = NOVALUE;
    object _14742 = NOVALUE;
    object _14741 = NOVALUE;
    object _14739 = NOVALUE;
    object _14738 = NOVALUE;
    object _14737 = NOVALUE;
    object _14736 = NOVALUE;
    object _14734 = NOVALUE;
    object _14733 = NOVALUE;
    object _14732 = NOVALUE;
    object _14731 = NOVALUE;
    object _14730 = NOVALUE;
    object _14728 = NOVALUE;
    object _14727 = NOVALUE;
    object _14726 = NOVALUE;
    object _14725 = NOVALUE;
    object _14723 = NOVALUE;
    object _14719 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:788		start_include = FALSE*/
    _61start_include_25580 = _9FALSE_444;

    /** scanner.e:790		new_file_handle = path_open() -- sets new_include_name to full path*/
    _new_file_handle_26587 = _61path_open();
    if (!IS_ATOM_INT(_new_file_handle_26587)) {
        _1 = (object)(DBL_PTR(_new_file_handle_26587)->dbl);
        DeRefDS(_new_file_handle_26587);
        _new_file_handle_26587 = _1;
    }

    /** scanner.e:792		new_hash = hash(canonical_path(new_include_name,,CORRECT), stdhash:HSIEH32)*/
    RefDS(_12new_include_name_20349);
    _14719 = _14canonical_path(_12new_include_name_20349, 0, 2);
    DeRef(_new_hash_26589);
    _new_hash_26589 = calc_hash(_14719, -5);
    DeRef(_14719);
    _14719 = NOVALUE;

    /** scanner.e:794		idx = find(new_hash, known_files_hash)*/
    _idx_26590 = find_from(_new_hash_26589, _13known_files_hash_11318, 1);

    /** scanner.e:795		if idx then*/
    if (_idx_26590 == 0)
    {
        goto L1; // [42] 335
    }
    else{
    }

    /** scanner.e:797			if new_include_space != 0 then*/
    if (_61new_include_space_25578 == 0)
    goto L2; // [49] 71

    /** scanner.e:798				SymTab[new_include_space][S_OBJ] = idx -- but note any namespace*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_61new_include_space_25578 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _idx_26590;
    DeRef(_1);
    _14723 = NOVALUE;
L2: 

    /** scanner.e:801			close(new_file_handle)*/
    EClose(_new_file_handle_26587);

    /** scanner.e:803			if find( -idx, file_include[current_file_no] ) then*/
    if ((uintptr_t)_idx_26590 == (uintptr_t)HIGH_BITS){
        _14725 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _14725 = - _idx_26590;
    }
    _2 = (object)SEQ_PTR(_13file_include_11321);
    _14726 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    _14727 = find_from(_14725, _14726, 1);
    DeRef(_14725);
    _14725 = NOVALUE;
    _14726 = NOVALUE;
    if (_14727 == 0)
    {
        _14727 = NOVALUE;
        goto L3; // [93] 130
    }
    else{
        _14727 = NOVALUE;
    }

    /** scanner.e:805				file_include[current_file_no][ find( -idx, file_include[current_file_no] ) ] = idx*/
    _2 = (object)SEQ_PTR(_13file_include_11321);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13file_include_11321 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12current_file_no_20226 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_idx_26590 == (uintptr_t)HIGH_BITS){
        _14730 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _14730 = - _idx_26590;
    }
    _2 = (object)SEQ_PTR(_13file_include_11321);
    _14731 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    _14732 = find_from(_14730, _14731, 1);
    DeRef(_14730);
    _14730 = NOVALUE;
    _14731 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14732);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _idx_26590;
    DeRef(_1);
    _14728 = NOVALUE;
    goto L4; // [127] 228
L3: 

    /** scanner.e:809			elsif not find( idx, file_include[current_file_no] ) then*/
    _2 = (object)SEQ_PTR(_13file_include_11321);
    _14733 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    _14734 = find_from(_idx_26590, _14733, 1);
    _14733 = NOVALUE;
    if (_14734 != 0)
    goto L5; // [145] 227
    _14734 = NOVALUE;

    /** scanner.e:811				file_include[current_file_no] &= idx*/
    _2 = (object)SEQ_PTR(_13file_include_11321);
    _14736 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    if (IS_SEQUENCE(_14736) && IS_ATOM(_idx_26590)) {
        Append(&_14737, _14736, _idx_26590);
    }
    else if (IS_ATOM(_14736) && IS_SEQUENCE(_idx_26590)) {
    }
    else {
        Concat((object_ptr)&_14737, _14736, _idx_26590);
        _14736 = NOVALUE;
    }
    _14736 = NOVALUE;
    _2 = (object)SEQ_PTR(_13file_include_11321);
    _2 = (object)(((s1_ptr)_2)->base + _12current_file_no_20226);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14737;
    if( _1 != _14737 ){
        DeRef(_1);
    }
    _14737 = NOVALUE;

    /** scanner.e:814				add_exports( idx, current_file_no )*/
    _61add_exports(_idx_26590, _12current_file_no_20226);

    /** scanner.e:816				if public_include then*/
    if (_61public_include_25583 == 0)
    {
        goto L6; // [178] 226
    }
    else{
    }

    /** scanner.e:818					if not find( idx, file_public[current_file_no] ) then*/
    _2 = (object)SEQ_PTR(_13file_public_11328);
    _14738 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    _14739 = find_from(_idx_26590, _14738, 1);
    _14738 = NOVALUE;
    if (_14739 != 0)
    goto L7; // [196] 225
    _14739 = NOVALUE;

    /** scanner.e:819						file_public[current_file_no] &= idx*/
    _2 = (object)SEQ_PTR(_13file_public_11328);
    _14741 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    if (IS_SEQUENCE(_14741) && IS_ATOM(_idx_26590)) {
        Append(&_14742, _14741, _idx_26590);
    }
    else if (IS_ATOM(_14741) && IS_SEQUENCE(_idx_26590)) {
    }
    else {
        Concat((object_ptr)&_14742, _14741, _idx_26590);
        _14741 = NOVALUE;
    }
    _14741 = NOVALUE;
    _2 = (object)SEQ_PTR(_13file_public_11328);
    _2 = (object)(((s1_ptr)_2)->base + _12current_file_no_20226);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14742;
    if( _1 != _14742 ){
        DeRef(_1);
    }
    _14742 = NOVALUE;

    /** scanner.e:820						patch_exports( current_file_no )*/
    _61patch_exports(_12current_file_no_20226);
L7: 
L6: 
L5: 
L4: 

    /** scanner.e:825			indirect_include[current_file_no][idx] = OpIndirectInclude*/
    _2 = (object)SEQ_PTR(_13indirect_include_11326);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13indirect_include_11326 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12current_file_no_20226 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _idx_26590);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12OpIndirectInclude_20302;
    DeRef(_1);
    _14743 = NOVALUE;

    /** scanner.e:826			add_include_by( current_file_no, idx, public_include )*/
    _61add_include_by(_12current_file_no_20226, _idx_26590, _61public_include_25583);

    /** scanner.e:827			update_include_matrix( idx, current_file_no )*/
    _61update_include_matrix(_idx_26590, _12current_file_no_20226);

    /** scanner.e:828			public_include = FALSE*/
    _61public_include_25583 = _9FALSE_444;

    /** scanner.e:829			read_line() -- we can't return without reading a line first*/
    _61read_line();

    /** scanner.e:830			if not find( idx, file_include_depend[current_file_no] ) and not finished_files[idx] then*/
    _2 = (object)SEQ_PTR(_13file_include_depend_11320);
    _14745 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    _14746 = find_from(_idx_26590, _14745, 1);
    _14745 = NOVALUE;
    _14747 = (_14746 == 0);
    _14746 = NOVALUE;
    if (_14747 == 0) {
        goto L8; // [293] 329
    }
    _2 = (object)SEQ_PTR(_13finished_files_11319);
    _14749 = (object)*(((s1_ptr)_2)->base + _idx_26590);
    _14750 = (_14749 == 0);
    _14749 = NOVALUE;
    if (_14750 == 0)
    {
        DeRef(_14750);
        _14750 = NOVALUE;
        goto L8; // [307] 329
    }
    else{
        DeRef(_14750);
        _14750 = NOVALUE;
    }

    /** scanner.e:831				file_include_depend[current_file_no] &= idx*/
    _2 = (object)SEQ_PTR(_13file_include_depend_11320);
    _14751 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    if (IS_SEQUENCE(_14751) && IS_ATOM(_idx_26590)) {
        Append(&_14752, _14751, _idx_26590);
    }
    else if (IS_ATOM(_14751) && IS_SEQUENCE(_idx_26590)) {
    }
    else {
        Concat((object_ptr)&_14752, _14751, _idx_26590);
        _14751 = NOVALUE;
    }
    _14751 = NOVALUE;
    _2 = (object)SEQ_PTR(_13file_include_depend_11320);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13file_include_depend_11320 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _12current_file_no_20226);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14752;
    if( _1 != _14752 ){
        DeRef(_1);
    }
    _14752 = NOVALUE;
L8: 

    /** scanner.e:833			return -- ignore it*/
    DeRef(_new_hash_26589);
    DeRef(_14747);
    _14747 = NOVALUE;
    return;
L1: 

    /** scanner.e:836		if length(IncludeStk) >= INCLUDE_LIMIT then*/
    if (IS_SEQUENCE(_61IncludeStk_25589)){
            _14753 = SEQ_PTR(_61IncludeStk_25589)->length;
    }
    else {
        _14753 = 1;
    }
    if (_14753 < 30)
    goto L9; // [342] 356

    /** scanner.e:837			CompileErr(INCLUDES_ARE_NESTED_TOO_DEEPLY)*/
    RefDS(_22015);
    _49CompileErr(104, _22015, 0);
L9: 

    /** scanner.e:840		IncludeStk = append(IncludeStk,*/
    _1 = NewS1(22);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _12current_file_no_20226;
    ((intptr_t*)_2)[2] = _12line_number_20227;
    ((intptr_t*)_2)[3] = _12src_file_20348;
    ((intptr_t*)_2)[4] = _12file_start_sym_20232;
    ((intptr_t*)_2)[5] = _12OpWarning_20294;
    ((intptr_t*)_2)[6] = _12OpTrace_20296;
    ((intptr_t*)_2)[7] = _12OpTypeCheck_20297;
    ((intptr_t*)_2)[8] = _12OpProfileTime_20299;
    ((intptr_t*)_2)[9] = _12OpProfileStatement_20298;
    RefDS(_12OpDefines_20300);
    ((intptr_t*)_2)[10] = _12OpDefines_20300;
    ((intptr_t*)_2)[11] = _12prev_OpWarning_20295;
    ((intptr_t*)_2)[12] = _12OpInline_20301;
    ((intptr_t*)_2)[13] = _12OpIndirectInclude_20302;
    ((intptr_t*)_2)[14] = _12putback_fwd_line_number_20229;
    Ref(_49putback_ForwardLine_49263);
    ((intptr_t*)_2)[15] = _49putback_ForwardLine_49263;
    ((intptr_t*)_2)[16] = _49putback_forward_bp_49267;
    ((intptr_t*)_2)[17] = _12last_fwd_line_number_20230;
    Ref(_49last_ForwardLine_49264);
    ((intptr_t*)_2)[18] = _49last_ForwardLine_49264;
    ((intptr_t*)_2)[19] = _49last_forward_bp_49268;
    Ref(_49ThisLine_49261);
    ((intptr_t*)_2)[20] = _49ThisLine_49261;
    ((intptr_t*)_2)[21] = _12fwd_line_number_20228;
    ((intptr_t*)_2)[22] = _49forward_bp_49266;
    _14755 = MAKE_SEQ(_1);
    RefDS(_14755);
    Append(&_61IncludeStk_25589, _61IncludeStk_25589, _14755);
    DeRefDS(_14755);
    _14755 = NOVALUE;

    /** scanner.e:864		file_include = append( file_include, {} )*/
    RefDS(_5);
    Append(&_13file_include_11321, _13file_include_11321, _5);

    /** scanner.e:865		file_include_by = append( file_include_by, {} )*/
    RefDS(_5);
    Append(&_13file_include_by_11330, _13file_include_by_11330, _5);

    /** scanner.e:866		for i = 1 to length( include_matrix) do*/
    if (IS_SEQUENCE(_13include_matrix_11323)){
            _14759 = SEQ_PTR(_13include_matrix_11323)->length;
    }
    else {
        _14759 = 1;
    }
    {
        object _i_26703;
        _i_26703 = 1;
LA: 
        if (_i_26703 > _14759){
            goto LB; // [460] 506
        }

        /** scanner.e:867			include_matrix[i]   &= 0*/
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _14760 = (object)*(((s1_ptr)_2)->base + _i_26703);
        if (IS_SEQUENCE(_14760) && IS_ATOM(0)) {
            Append(&_14761, _14760, 0);
        }
        else if (IS_ATOM(_14760) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_14761, _14760, 0);
            _14760 = NOVALUE;
        }
        _14760 = NOVALUE;
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _2 = (object)(((s1_ptr)_2)->base + _i_26703);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14761;
        if( _1 != _14761 ){
            DeRef(_1);
        }
        _14761 = NOVALUE;

        /** scanner.e:868			indirect_include[i] &= 0*/
        _2 = (object)SEQ_PTR(_13indirect_include_11326);
        _14762 = (object)*(((s1_ptr)_2)->base + _i_26703);
        if (IS_SEQUENCE(_14762) && IS_ATOM(0)) {
            Append(&_14763, _14762, 0);
        }
        else if (IS_ATOM(_14762) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_14763, _14762, 0);
            _14762 = NOVALUE;
        }
        _14762 = NOVALUE;
        _2 = (object)SEQ_PTR(_13indirect_include_11326);
        _2 = (object)(((s1_ptr)_2)->base + _i_26703);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14763;
        if( _1 != _14763 ){
            DeRef(_1);
        }
        _14763 = NOVALUE;

        /** scanner.e:869		end for*/
        _i_26703 = _i_26703 + 1;
        goto LA; // [501] 467
LB: 
        ;
    }

    /** scanner.e:870		include_matrix = append( include_matrix, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_13file_include_11321)){
            _14764 = SEQ_PTR(_13file_include_11321)->length;
    }
    else {
        _14764 = 1;
    }
    _14765 = Repeat(0, _14764);
    _14764 = NOVALUE;
    RefDS(_14765);
    Append(&_13include_matrix_11323, _13include_matrix_11323, _14765);
    DeRefDS(_14765);
    _14765 = NOVALUE;

    /** scanner.e:871		include_matrix[$][$] = DIRECT_INCLUDE*/
    if (IS_SEQUENCE(_13include_matrix_11323)){
            _14767 = SEQ_PTR(_13include_matrix_11323)->length;
    }
    else {
        _14767 = 1;
    }
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13include_matrix_11323 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14767 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14770 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14770 = 1;
    }
    _14768 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14770);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _14768 = NOVALUE;

    /** scanner.e:872		include_matrix[current_file_no][$] = DIRECT_INCLUDE*/
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13include_matrix_11323 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12current_file_no_20226 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14773 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14773 = 1;
    }
    _14771 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14773);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _14771 = NOVALUE;

    /** scanner.e:874		indirect_include = append( indirect_include, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_13file_include_11321)){
            _14774 = SEQ_PTR(_13file_include_11321)->length;
    }
    else {
        _14774 = 1;
    }
    _14775 = Repeat(0, _14774);
    _14774 = NOVALUE;
    RefDS(_14775);
    Append(&_13indirect_include_11326, _13indirect_include_11326, _14775);
    DeRefDS(_14775);
    _14775 = NOVALUE;

    /** scanner.e:875		indirect_include[current_file_no][$] = OpIndirectInclude*/
    _2 = (object)SEQ_PTR(_13indirect_include_11326);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13indirect_include_11326 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12current_file_no_20226 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14779 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14779 = 1;
    }
    _14777 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14779);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12OpIndirectInclude_20302;
    DeRef(_1);
    _14777 = NOVALUE;

    /** scanner.e:876		OpIndirectInclude = 1*/
    _12OpIndirectInclude_20302 = 1;

    /** scanner.e:878		file_public  = append( file_public, {} )*/
    RefDS(_5);
    Append(&_13file_public_11328, _13file_public_11328, _5);

    /** scanner.e:879		file_public_by = append( file_public_by, {} )*/
    RefDS(_5);
    Append(&_13file_public_by_11332, _13file_public_by_11332, _5);

    /** scanner.e:880		file_include[current_file_no] &= length( file_include )*/
    if (IS_SEQUENCE(_13file_include_11321)){
            _14782 = SEQ_PTR(_13file_include_11321)->length;
    }
    else {
        _14782 = 1;
    }
    _2 = (object)SEQ_PTR(_13file_include_11321);
    _14783 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    if (IS_SEQUENCE(_14783) && IS_ATOM(_14782)) {
        Append(&_14784, _14783, _14782);
    }
    else if (IS_ATOM(_14783) && IS_SEQUENCE(_14782)) {
    }
    else {
        Concat((object_ptr)&_14784, _14783, _14782);
        _14783 = NOVALUE;
    }
    _14783 = NOVALUE;
    _14782 = NOVALUE;
    _2 = (object)SEQ_PTR(_13file_include_11321);
    _2 = (object)(((s1_ptr)_2)->base + _12current_file_no_20226);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14784;
    if( _1 != _14784 ){
        DeRef(_1);
    }
    _14784 = NOVALUE;

    /** scanner.e:881		add_include_by( current_file_no, length(file_include), public_include )*/
    if (IS_SEQUENCE(_13file_include_11321)){
            _14785 = SEQ_PTR(_13file_include_11321)->length;
    }
    else {
        _14785 = 1;
    }
    _61add_include_by(_12current_file_no_20226, _14785, _61public_include_25583);
    _14785 = NOVALUE;

    /** scanner.e:882		if public_include then*/
    if (_61public_include_25583 == 0)
    {
        goto LC; // [675] 709
    }
    else{
    }

    /** scanner.e:883			file_public[current_file_no] &= length( file_public )*/
    if (IS_SEQUENCE(_13file_public_11328)){
            _14786 = SEQ_PTR(_13file_public_11328)->length;
    }
    else {
        _14786 = 1;
    }
    _2 = (object)SEQ_PTR(_13file_public_11328);
    _14787 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    if (IS_SEQUENCE(_14787) && IS_ATOM(_14786)) {
        Append(&_14788, _14787, _14786);
    }
    else if (IS_ATOM(_14787) && IS_SEQUENCE(_14786)) {
    }
    else {
        Concat((object_ptr)&_14788, _14787, _14786);
        _14787 = NOVALUE;
    }
    _14787 = NOVALUE;
    _14786 = NOVALUE;
    _2 = (object)SEQ_PTR(_13file_public_11328);
    _2 = (object)(((s1_ptr)_2)->base + _12current_file_no_20226);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14788;
    if( _1 != _14788 ){
        DeRef(_1);
    }
    _14788 = NOVALUE;

    /** scanner.e:884			patch_exports( current_file_no )*/
    _61patch_exports(_12current_file_no_20226);
LC: 

    /** scanner.e:887	ifdef STDDEBUG then*/

    /** scanner.e:893		src_file = new_file_handle*/
    _12src_file_20348 = _new_file_handle_26587;

    /** scanner.e:894		file_start_sym = last_sym*/
    _12file_start_sym_20232 = _53last_sym_46812;

    /** scanner.e:895		if current_file_no >= MAX_FILE then*/
    if (_12current_file_no_20226 < 256)
    goto LD; // [731] 745

    /** scanner.e:896			CompileErr(PROGRAM_INCLUDES_TOO_MANY_FILES)*/
    RefDS(_22015);
    _49CompileErr(126, _22015, 0);
LD: 

    /** scanner.e:898		known_files = append(known_files, new_include_name)*/
    RefDS(_12new_include_name_20349);
    Append(&_13known_files_11317, _13known_files_11317, _12new_include_name_20349);

    /** scanner.e:899		known_files_hash &= new_hash*/
    Ref(_new_hash_26589);
    Append(&_13known_files_hash_11318, _13known_files_hash_11318, _new_hash_26589);

    /** scanner.e:900		finished_files &= 0*/
    Append(&_13finished_files_11319, _13finished_files_11319, 0);

    /** scanner.e:901		file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_13known_files_11317)){
            _14794 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _14794 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _14794;
    _14795 = MAKE_SEQ(_1);
    _14794 = NOVALUE;
    RefDS(_14795);
    Append(&_13file_include_depend_11320, _13file_include_depend_11320, _14795);
    DeRefDS(_14795);
    _14795 = NOVALUE;

    /** scanner.e:902		file_include_depend[current_file_no] &= length( known_files )*/
    if (IS_SEQUENCE(_13known_files_11317)){
            _14797 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _14797 = 1;
    }
    _2 = (object)SEQ_PTR(_13file_include_depend_11320);
    _14798 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    if (IS_SEQUENCE(_14798) && IS_ATOM(_14797)) {
        Append(&_14799, _14798, _14797);
    }
    else if (IS_ATOM(_14798) && IS_SEQUENCE(_14797)) {
    }
    else {
        Concat((object_ptr)&_14799, _14798, _14797);
        _14798 = NOVALUE;
    }
    _14798 = NOVALUE;
    _14797 = NOVALUE;
    _2 = (object)SEQ_PTR(_13file_include_depend_11320);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13file_include_depend_11320 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _12current_file_no_20226);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14799;
    if( _1 != _14799 ){
        DeRef(_1);
    }
    _14799 = NOVALUE;

    /** scanner.e:903		check_coverage()*/
    _50check_coverage();

    /** scanner.e:904		default_namespaces &= 0*/
    Append(&_61default_namespaces_25586, _61default_namespaces_25586, 0);

    /** scanner.e:906		update_include_matrix( length( file_include ), current_file_no )*/
    if (IS_SEQUENCE(_13file_include_11321)){
            _14801 = SEQ_PTR(_13file_include_11321)->length;
    }
    else {
        _14801 = 1;
    }
    _61update_include_matrix(_14801, _12current_file_no_20226);
    _14801 = NOVALUE;

    /** scanner.e:907		old_file_no = current_file_no*/
    _old_file_no_26588 = _12current_file_no_20226;

    /** scanner.e:908		current_file_no = length(known_files)*/
    if (IS_SEQUENCE(_13known_files_11317)){
            _12current_file_no_20226 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _12current_file_no_20226 = 1;
    }

    /** scanner.e:909		line_number = 0*/
    _12line_number_20227 = 0;

    /** scanner.e:910		read_line()*/
    _61read_line();

    /** scanner.e:912		if new_include_space != 0 then*/
    if (_61new_include_space_25578 == 0)
    goto LE; // [877] 901

    /** scanner.e:913			SymTab[new_include_space][S_OBJ] = current_file_no*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_61new_include_space_25578 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12current_file_no_20226;
    DeRef(_1);
    _14804 = NOVALUE;
LE: 

    /** scanner.e:915		default_namespace( )*/
    _61default_namespace();

    /** scanner.e:916	end procedure*/
    DeRef(_new_hash_26589);
    DeRef(_14747);
    _14747 = NOVALUE;
    return;
    ;
}


void _61update_include_completion(object _file_no_26814)
{
    object _fx_26823 = NOVALUE;
    object _14814 = NOVALUE;
    object _14813 = NOVALUE;
    object _14812 = NOVALUE;
    object _14811 = NOVALUE;
    object _14809 = NOVALUE;
    object _14808 = NOVALUE;
    object _14807 = NOVALUE;
    object _14806 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:919		for i = 1 to length( file_include_depend ) do*/
    if (IS_SEQUENCE(_13file_include_depend_11320)){
            _14806 = SEQ_PTR(_13file_include_depend_11320)->length;
    }
    else {
        _14806 = 1;
    }
    {
        object _i_26816;
        _i_26816 = 1;
L1: 
        if (_i_26816 > _14806){
            goto L2; // [10] 114
        }

        /** scanner.e:920			if length( file_include_depend[i] ) then*/
        _2 = (object)SEQ_PTR(_13file_include_depend_11320);
        _14807 = (object)*(((s1_ptr)_2)->base + _i_26816);
        if (IS_SEQUENCE(_14807)){
                _14808 = SEQ_PTR(_14807)->length;
        }
        else {
            _14808 = 1;
        }
        _14807 = NOVALUE;
        if (_14808 == 0)
        {
            _14808 = NOVALUE;
            goto L3; // [28] 105
        }
        else{
            _14808 = NOVALUE;
        }

        /** scanner.e:921				integer fx = find( file_no, file_include_depend[i] )*/
        _2 = (object)SEQ_PTR(_13file_include_depend_11320);
        _14809 = (object)*(((s1_ptr)_2)->base + _i_26816);
        _fx_26823 = find_from(_file_no_26814, _14809, 1);
        _14809 = NOVALUE;

        /** scanner.e:922				if fx then*/
        if (_fx_26823 == 0)
        {
            goto L4; // [46] 104
        }
        else{
        }

        /** scanner.e:923					file_include_depend[i] = remove( file_include_depend[i], fx )*/
        _2 = (object)SEQ_PTR(_13file_include_depend_11320);
        _14811 = (object)*(((s1_ptr)_2)->base + _i_26816);
        {
            s1_ptr assign_space = SEQ_PTR(_14811);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_26823)) ? _fx_26823 : (object)(DBL_PTR(_fx_26823)->dbl);
            int stop = (IS_ATOM_INT(_fx_26823)) ? _fx_26823 : (object)(DBL_PTR(_fx_26823)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
                RefDS(_14811);
                DeRef(_14812);
                _14812 = _14811;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_14811), start, &_14812 );
                }
                else Tail(SEQ_PTR(_14811), stop+1, &_14812);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_14811), start, &_14812);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_14812);
                _14812 = _1;
            }
        }
        _14811 = NOVALUE;
        _2 = (object)SEQ_PTR(_13file_include_depend_11320);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13file_include_depend_11320 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_26816);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14812;
        if( _1 != _14812 ){
            DeRef(_1);
        }
        _14812 = NOVALUE;

        /** scanner.e:924					if not length( file_include_depend[i] ) then*/
        _2 = (object)SEQ_PTR(_13file_include_depend_11320);
        _14813 = (object)*(((s1_ptr)_2)->base + _i_26816);
        if (IS_SEQUENCE(_14813)){
                _14814 = SEQ_PTR(_14813)->length;
        }
        else {
            _14814 = 1;
        }
        _14813 = NOVALUE;
        if (_14814 != 0)
        goto L5; // [79] 103
        _14814 = NOVALUE;

        /** scanner.e:925						finished_files[i] = 1*/
        _2 = (object)SEQ_PTR(_13finished_files_11319);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13finished_files_11319 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_26816);
        *(intptr_t *)_2 = 1;

        /** scanner.e:926						if i != file_no then*/
        if (_i_26816 == _file_no_26814)
        goto L6; // [92] 102

        /** scanner.e:927							update_include_completion( i )*/
        _61update_include_completion(_i_26816);
L6: 
L5: 
L4: 
L3: 

        /** scanner.e:932		end for*/
        _i_26816 = _i_26816 + 1;
        goto L1; // [109] 17
L2: 
        ;
    }

    /** scanner.e:933	end procedure*/
    _14807 = NOVALUE;
    _14813 = NOVALUE;
    return;
    ;
}


object _61IncludePop()
{
    object _top_26854 = NOVALUE;
    object _14845 = NOVALUE;
    object _14843 = NOVALUE;
    object _14842 = NOVALUE;
    object _14820 = NOVALUE;
    object _14818 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:940		update_include_completion( current_file_no )*/
    _61update_include_completion(_12current_file_no_20226);

    /** scanner.e:941		Resolve_forward_references()*/
    _42Resolve_forward_references(0);

    /** scanner.e:942		HideLocals()*/
    _53HideLocals();

    /** scanner.e:944		if src_file >= 0 then*/
    if (_12src_file_20348 < 0)
    goto L1; // [21] 39

    /** scanner.e:945			close(src_file)*/
    EClose(_12src_file_20348);

    /** scanner.e:946			src_file = -1*/
    _12src_file_20348 = -1;
L1: 

    /** scanner.e:949		if length(IncludeStk) = 0 then*/
    if (IS_SEQUENCE(_61IncludeStk_25589)){
            _14818 = SEQ_PTR(_61IncludeStk_25589)->length;
    }
    else {
        _14818 = 1;
    }
    if (_14818 != 0)
    goto L2; // [46] 59

    /** scanner.e:950			return FALSE  -- the end*/
    DeRef(_top_26854);
    return _9FALSE_444;
L2: 

    /** scanner.e:953		sequence top = IncludeStk[$]*/
    if (IS_SEQUENCE(_61IncludeStk_25589)){
            _14820 = SEQ_PTR(_61IncludeStk_25589)->length;
    }
    else {
        _14820 = 1;
    }
    DeRef(_top_26854);
    _2 = (object)SEQ_PTR(_61IncludeStk_25589);
    _top_26854 = (object)*(((s1_ptr)_2)->base + _14820);
    RefDS(_top_26854);

    /** scanner.e:955		current_file_no    = top[FILE_NO]*/
    _2 = (object)SEQ_PTR(_top_26854);
    _12current_file_no_20226 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_12current_file_no_20226)){
        _12current_file_no_20226 = (object)DBL_PTR(_12current_file_no_20226)->dbl;
    }

    /** scanner.e:956		line_number        = top[LINE_NO]*/
    _2 = (object)SEQ_PTR(_top_26854);
    _12line_number_20227 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_12line_number_20227)){
        _12line_number_20227 = (object)DBL_PTR(_12line_number_20227)->dbl;
    }

    /** scanner.e:957		src_file           = top[FILE_PTR]*/
    _2 = (object)SEQ_PTR(_top_26854);
    _12src_file_20348 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_12src_file_20348)){
        _12src_file_20348 = (object)DBL_PTR(_12src_file_20348)->dbl;
    }

    /** scanner.e:958		file_start_sym     = top[FILE_START_SYM]*/
    _2 = (object)SEQ_PTR(_top_26854);
    _12file_start_sym_20232 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_12file_start_sym_20232)){
        _12file_start_sym_20232 = (object)DBL_PTR(_12file_start_sym_20232)->dbl;
    }

    /** scanner.e:959		OpWarning          = top[OP_WARNING]*/
    _2 = (object)SEQ_PTR(_top_26854);
    _12OpWarning_20294 = (object)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_12OpWarning_20294)){
        _12OpWarning_20294 = (object)DBL_PTR(_12OpWarning_20294)->dbl;
    }

    /** scanner.e:960		OpTrace            = top[OP_TRACE]*/
    _2 = (object)SEQ_PTR(_top_26854);
    _12OpTrace_20296 = (object)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_12OpTrace_20296)){
        _12OpTrace_20296 = (object)DBL_PTR(_12OpTrace_20296)->dbl;
    }

    /** scanner.e:961		OpTypeCheck        = top[OP_TYPE_CHECK]*/
    _2 = (object)SEQ_PTR(_top_26854);
    _12OpTypeCheck_20297 = (object)*(((s1_ptr)_2)->base + 7);
    if (!IS_ATOM_INT(_12OpTypeCheck_20297)){
        _12OpTypeCheck_20297 = (object)DBL_PTR(_12OpTypeCheck_20297)->dbl;
    }

    /** scanner.e:962		OpProfileTime      = top[OP_PROFILE_TIME]*/
    _2 = (object)SEQ_PTR(_top_26854);
    _12OpProfileTime_20299 = (object)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_12OpProfileTime_20299)){
        _12OpProfileTime_20299 = (object)DBL_PTR(_12OpProfileTime_20299)->dbl;
    }

    /** scanner.e:963		OpProfileStatement = top[OP_PROFILE_STATEMENT]*/
    _2 = (object)SEQ_PTR(_top_26854);
    _12OpProfileStatement_20298 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_12OpProfileStatement_20298)){
        _12OpProfileStatement_20298 = (object)DBL_PTR(_12OpProfileStatement_20298)->dbl;
    }

    /** scanner.e:964		OpDefines          = top[OP_DEFINES]*/
    DeRef(_12OpDefines_20300);
    _2 = (object)SEQ_PTR(_top_26854);
    _12OpDefines_20300 = (object)*(((s1_ptr)_2)->base + 10);
    Ref(_12OpDefines_20300);

    /** scanner.e:965		prev_OpWarning     = top[PREV_OP_WARNING]*/
    _2 = (object)SEQ_PTR(_top_26854);
    _12prev_OpWarning_20295 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_12prev_OpWarning_20295)){
        _12prev_OpWarning_20295 = (object)DBL_PTR(_12prev_OpWarning_20295)->dbl;
    }

    /** scanner.e:966		OpInline           = top[OP_INLINE]*/
    _2 = (object)SEQ_PTR(_top_26854);
    _12OpInline_20301 = (object)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_12OpInline_20301)){
        _12OpInline_20301 = (object)DBL_PTR(_12OpInline_20301)->dbl;
    }

    /** scanner.e:967		OpIndirectInclude  = top[OP_INDIRECT_INCLUDE]*/
    _2 = (object)SEQ_PTR(_top_26854);
    _12OpIndirectInclude_20302 = (object)*(((s1_ptr)_2)->base + 13);
    if (!IS_ATOM_INT(_12OpIndirectInclude_20302)){
        _12OpIndirectInclude_20302 = (object)DBL_PTR(_12OpIndirectInclude_20302)->dbl;
    }

    /** scanner.e:968		putback_fwd_line_number = line_number -- top[PUTBACK_FWD_LINE_NUMBER]*/
    _12putback_fwd_line_number_20229 = _12line_number_20227;

    /** scanner.e:969		putback_ForwardLine = top[PUTBACK_FORWARDLINE]*/
    DeRef(_49putback_ForwardLine_49263);
    _2 = (object)SEQ_PTR(_top_26854);
    _49putback_ForwardLine_49263 = (object)*(((s1_ptr)_2)->base + 15);
    Ref(_49putback_ForwardLine_49263);

    /** scanner.e:970		putback_forward_bp = top[PUTBACK_FORWARD_BP]*/
    _2 = (object)SEQ_PTR(_top_26854);
    _49putback_forward_bp_49267 = (object)*(((s1_ptr)_2)->base + 16);
    if (!IS_ATOM_INT(_49putback_forward_bp_49267)){
        _49putback_forward_bp_49267 = (object)DBL_PTR(_49putback_forward_bp_49267)->dbl;
    }

    /** scanner.e:971		last_fwd_line_number = top[LAST_FWD_LINE_NUMBER]*/
    _2 = (object)SEQ_PTR(_top_26854);
    _12last_fwd_line_number_20230 = (object)*(((s1_ptr)_2)->base + 17);
    if (!IS_ATOM_INT(_12last_fwd_line_number_20230)){
        _12last_fwd_line_number_20230 = (object)DBL_PTR(_12last_fwd_line_number_20230)->dbl;
    }

    /** scanner.e:972		last_ForwardLine = top[LAST_FORWARDLINE]*/
    DeRef(_49last_ForwardLine_49264);
    _2 = (object)SEQ_PTR(_top_26854);
    _49last_ForwardLine_49264 = (object)*(((s1_ptr)_2)->base + 18);
    Ref(_49last_ForwardLine_49264);

    /** scanner.e:973		last_forward_bp = top[LAST_FORWARD_BP]*/
    _2 = (object)SEQ_PTR(_top_26854);
    _49last_forward_bp_49268 = (object)*(((s1_ptr)_2)->base + 19);
    if (!IS_ATOM_INT(_49last_forward_bp_49268)){
        _49last_forward_bp_49268 = (object)DBL_PTR(_49last_forward_bp_49268)->dbl;
    }

    /** scanner.e:974		ThisLine = top[THISLINE]*/
    DeRef(_49ThisLine_49261);
    _2 = (object)SEQ_PTR(_top_26854);
    _49ThisLine_49261 = (object)*(((s1_ptr)_2)->base + 20);
    Ref(_49ThisLine_49261);

    /** scanner.e:976		fwd_line_number = line_number --top[FWD_LINE_NUMBER]*/
    _12fwd_line_number_20228 = _12line_number_20227;

    /** scanner.e:977		forward_bp = top[FORWARD_BP]*/
    _2 = (object)SEQ_PTR(_top_26854);
    _49forward_bp_49266 = (object)*(((s1_ptr)_2)->base + 22);
    if (!IS_ATOM_INT(_49forward_bp_49266)){
        _49forward_bp_49266 = (object)DBL_PTR(_49forward_bp_49266)->dbl;
    }

    /** scanner.e:978		ForwardLine = ThisLine*/
    Ref(_49ThisLine_49261);
    DeRef(_49ForwardLine_49262);
    _49ForwardLine_49262 = _49ThisLine_49261;

    /** scanner.e:980		putback_ForwardLine = ThisLine*/
    Ref(_49ThisLine_49261);
    DeRef(_49putback_ForwardLine_49263);
    _49putback_ForwardLine_49263 = _49ThisLine_49261;

    /** scanner.e:981		last_ForwardLine = ThisLine*/
    Ref(_49ThisLine_49261);
    DeRef(_49last_ForwardLine_49264);
    _49last_ForwardLine_49264 = _49ThisLine_49261;

    /** scanner.e:983		IncludeStk = IncludeStk[1..$-1]*/
    if (IS_SEQUENCE(_61IncludeStk_25589)){
            _14842 = SEQ_PTR(_61IncludeStk_25589)->length;
    }
    else {
        _14842 = 1;
    }
    _14843 = _14842 - 1;
    _14842 = NOVALUE;
    rhs_slice_target = (object_ptr)&_61IncludeStk_25589;
    RHS_Slice(_61IncludeStk_25589, 1, _14843);

    /** scanner.e:984		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_12Code_20315);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12Code_20315;
    DeRef(_1);
    _14845 = NOVALUE;

    /** scanner.e:987		return TRUE*/
    DeRefDS(_top_26854);
    _14843 = NOVALUE;
    return _9TRUE_446;
    ;
}


object _61MakeInt(object _text_26952, object _nBase_26953)
{
    object _num_26954 = NOVALUE;
    object _maxchk_26955 = NOVALUE;
    object _fnum_26956 = NOVALUE;
    object _digit_26957 = NOVALUE;
    object _14892 = NOVALUE;
    object _14890 = NOVALUE;
    object _14888 = NOVALUE;
    object _14885 = NOVALUE;
    object _14884 = NOVALUE;
    object _14883 = NOVALUE;
    object _14881 = NOVALUE;
    object _14879 = NOVALUE;
    object _14878 = NOVALUE;
    object _14877 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_nBase_26953)) {
        _1 = (object)(DBL_PTR(_nBase_26953)->dbl);
        DeRefDS(_nBase_26953);
        _nBase_26953 = _1;
    }

    /** scanner.e:1012		ifdef BITS32 then*/

    /** scanner.e:1013			atom num, maxchk*/

    /** scanner.e:1017		atom fnum*/

    /** scanner.e:1018		integer digit*/

    /** scanner.e:1021		switch nBase do*/
    _0 = _nBase_26953;
    switch ( _0 ){ 

        /** scanner.e:1022			case 2 then*/
        case 2:

        /** scanner.e:1023				maxchk = MAXCHK2*/
        _maxchk_26955 = 536870911;
        goto L1; // [29] 90

        /** scanner.e:1025			case 8 then*/
        case 8:

        /** scanner.e:1026				maxchk = MAXCHK8*/
        _maxchk_26955 = 134217727;
        goto L1; // [40] 90

        /** scanner.e:1028			case 10 then*/
        case 10:

        /** scanner.e:1030				num = find(text, common_int_text)*/
        DeRef(_num_26954);
        _num_26954 = find_from(_text_26952, _61common_int_text_26930, 1);

        /** scanner.e:1031				if num then*/
        if (_num_26954 == 0)
        {
            goto L2; // [57] 73
        }
        else{
        }

        /** scanner.e:1032					return common_ints[num]*/
        _2 = (object)SEQ_PTR(_61common_ints_26948);
        _14877 = (object)*(((s1_ptr)_2)->base + _num_26954);
        DeRefDS(_text_26952);
        DeRef(_fnum_26956);
        return _14877;
L2: 

        /** scanner.e:1035				maxchk = MAXCHK10*/
        _maxchk_26955 = 107374181;
        goto L1; // [78] 90

        /** scanner.e:1037			case 16 then*/
        case 16:

        /** scanner.e:1038				maxchk = MAXCHK16*/
        _maxchk_26955 = 67108863;
    ;}L1: 

    /** scanner.e:1042		num = 0*/
    DeRef(_num_26954);
    _num_26954 = 0;

    /** scanner.e:1043		fnum = 0*/
    DeRef(_fnum_26956);
    _fnum_26956 = 0;

    /** scanner.e:1044		for i = 1 to length(text) do*/
    if (IS_SEQUENCE(_text_26952)){
            _14878 = SEQ_PTR(_text_26952)->length;
    }
    else {
        _14878 = 1;
    }
    {
        object _i_26968;
        _i_26968 = 1;
L3: 
        if (_i_26968 > _14878){
            goto L4; // [105] 220
        }

        /** scanner.e:1045			digit = (text[i] - '0')*/
        _2 = (object)SEQ_PTR(_text_26952);
        _14879 = (object)*(((s1_ptr)_2)->base + _i_26968);
        if (IS_ATOM_INT(_14879)) {
            _digit_26957 = _14879 - 48;
        }
        else {
            _digit_26957 = binary_op(MINUS, _14879, 48);
        }
        _14879 = NOVALUE;
        if (!IS_ATOM_INT(_digit_26957)) {
            _1 = (object)(DBL_PTR(_digit_26957)->dbl);
            DeRefDS(_digit_26957);
            _digit_26957 = _1;
        }

        /** scanner.e:1046			if digit >= nBase or digit < 0 then*/
        _14881 = (_digit_26957 >= _nBase_26953);
        if (_14881 != 0) {
            goto L5; // [130] 143
        }
        _14883 = (_digit_26957 < 0);
        if (_14883 == 0)
        {
            DeRef(_14883);
            _14883 = NOVALUE;
            goto L6; // [139] 161
        }
        else{
            DeRef(_14883);
            _14883 = NOVALUE;
        }
L5: 

        /** scanner.e:1047				CompileErr(DIGIT_1_AT_POSITION_2_IS_OUTSIDE_OF_NUMBER_BASE, {text[i],i})*/
        _2 = (object)SEQ_PTR(_text_26952);
        _14884 = (object)*(((s1_ptr)_2)->base + _i_26968);
        Ref(_14884);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _14884;
        ((intptr_t *)_2)[2] = _i_26968;
        _14885 = MAKE_SEQ(_1);
        _14884 = NOVALUE;
        _49CompileErr(62, _14885, 0);
        _14885 = NOVALUE;
L6: 

        /** scanner.e:1049			if fnum = 0 then*/
        if (binary_op_a(NOTEQ, _fnum_26956, 0)){
            goto L7; // [163] 202
        }

        /** scanner.e:1050				if num <= maxchk then*/
        if (binary_op_a(GREATER, _num_26954, _maxchk_26955)){
            goto L8; // [171] 188
        }

        /** scanner.e:1051					num = num * nBase + digit*/
        if (IS_ATOM_INT(_num_26954)) {
            if (_num_26954 == (short)_num_26954 && _nBase_26953 <= INT15 && _nBase_26953 >= -INT15){
                _14888 = _num_26954 * _nBase_26953;
            }
            else{
                _14888 = NewDouble(_num_26954 * (eudouble)_nBase_26953);
            }
        }
        else {
            _14888 = NewDouble(DBL_PTR(_num_26954)->dbl * (eudouble)_nBase_26953);
        }
        DeRef(_num_26954);
        if (IS_ATOM_INT(_14888)) {
            _num_26954 = _14888 + _digit_26957;
            if ((object)((uintptr_t)_num_26954 + (uintptr_t)HIGH_BITS) >= 0){
                _num_26954 = NewDouble((eudouble)_num_26954);
            }
        }
        else {
            _num_26954 = NewDouble(DBL_PTR(_14888)->dbl + (eudouble)_digit_26957);
        }
        DeRef(_14888);
        _14888 = NOVALUE;
        goto L9; // [185] 213
L8: 

        /** scanner.e:1053					fnum = num * nBase + digit*/
        if (IS_ATOM_INT(_num_26954)) {
            if (_num_26954 == (short)_num_26954 && _nBase_26953 <= INT15 && _nBase_26953 >= -INT15){
                _14890 = _num_26954 * _nBase_26953;
            }
            else{
                _14890 = NewDouble(_num_26954 * (eudouble)_nBase_26953);
            }
        }
        else {
            _14890 = NewDouble(DBL_PTR(_num_26954)->dbl * (eudouble)_nBase_26953);
        }
        DeRef(_fnum_26956);
        if (IS_ATOM_INT(_14890)) {
            _fnum_26956 = _14890 + _digit_26957;
            if ((object)((uintptr_t)_fnum_26956 + (uintptr_t)HIGH_BITS) >= 0){
                _fnum_26956 = NewDouble((eudouble)_fnum_26956);
            }
        }
        else {
            _fnum_26956 = NewDouble(DBL_PTR(_14890)->dbl + (eudouble)_digit_26957);
        }
        DeRef(_14890);
        _14890 = NOVALUE;
        goto L9; // [199] 213
L7: 

        /** scanner.e:1056				fnum = fnum * nBase + digit*/
        if (IS_ATOM_INT(_fnum_26956)) {
            if (_fnum_26956 == (short)_fnum_26956 && _nBase_26953 <= INT15 && _nBase_26953 >= -INT15){
                _14892 = _fnum_26956 * _nBase_26953;
            }
            else{
                _14892 = NewDouble(_fnum_26956 * (eudouble)_nBase_26953);
            }
        }
        else {
            _14892 = NewDouble(DBL_PTR(_fnum_26956)->dbl * (eudouble)_nBase_26953);
        }
        DeRef(_fnum_26956);
        if (IS_ATOM_INT(_14892)) {
            _fnum_26956 = _14892 + _digit_26957;
            if ((object)((uintptr_t)_fnum_26956 + (uintptr_t)HIGH_BITS) >= 0){
                _fnum_26956 = NewDouble((eudouble)_fnum_26956);
            }
        }
        else {
            _fnum_26956 = NewDouble(DBL_PTR(_14892)->dbl + (eudouble)_digit_26957);
        }
        DeRef(_14892);
        _14892 = NOVALUE;
L9: 

        /** scanner.e:1058		end for*/
        _i_26968 = _i_26968 + 1;
        goto L3; // [215] 112
L4: 
        ;
    }

    /** scanner.e:1060		if fnum = 0 then*/
    if (binary_op_a(NOTEQ, _fnum_26956, 0)){
        goto LA; // [222] 235
    }

    /** scanner.e:1061			return num*/
    DeRefDS(_text_26952);
    DeRef(_fnum_26956);
    DeRef(_14881);
    _14881 = NOVALUE;
    _14877 = NOVALUE;
    return _num_26954;
    goto LB; // [232] 242
LA: 

    /** scanner.e:1063			return fnum*/
    DeRefDS(_text_26952);
    DeRef(_num_26954);
    DeRef(_14881);
    _14881 = NOVALUE;
    _14877 = NOVALUE;
    return _fnum_26956;
LB: 
    ;
}


object _61GetHexChar(object _cnt_26997, object _errno_26998)
{
    object _val_26999 = NOVALUE;
    object _d_27000 = NOVALUE;
    object _14902 = NOVALUE;
    object _14901 = NOVALUE;
    object _14896 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1070		val = 0*/
    DeRef(_val_26999);
    _val_26999 = 0;

    /** scanner.e:1072		while cnt > 0 do*/
L1: 
    if (_cnt_26997 <= 0)
    goto L2; // [15] 88

    /** scanner.e:1073			d = find(getch(), "0123456789ABCDEFabcdef_")*/
    _14896 = _61getch();
    _d_27000 = find_from(_14896, _14897, 1);
    DeRef(_14896);
    _14896 = NOVALUE;

    /** scanner.e:1074			if d = 0 then*/
    if (_d_27000 != 0)
    goto L3; // [31] 43

    /** scanner.e:1075				CompileErr( errno )*/
    RefDS(_22015);
    _49CompileErr(_errno_26998, _22015, 0);
L3: 

    /** scanner.e:1077			if d != 23 then*/
    if (_d_27000 == 23)
    goto L1; // [45] 15

    /** scanner.e:1078				val = val * 16 + d - 1*/
    if (IS_ATOM_INT(_val_26999)) {
        if (_val_26999 == (short)_val_26999){
            _14901 = _val_26999 * 16;
        }
        else{
            _14901 = NewDouble(_val_26999 * (eudouble)16);
        }
    }
    else {
        _14901 = NewDouble(DBL_PTR(_val_26999)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_14901)) {
        _14902 = _14901 + _d_27000;
        if ((object)((uintptr_t)_14902 + (uintptr_t)HIGH_BITS) >= 0){
            _14902 = NewDouble((eudouble)_14902);
        }
    }
    else {
        _14902 = NewDouble(DBL_PTR(_14901)->dbl + (eudouble)_d_27000);
    }
    DeRef(_14901);
    _14901 = NOVALUE;
    DeRef(_val_26999);
    if (IS_ATOM_INT(_14902)) {
        _val_26999 = _14902 - 1;
        if ((object)((uintptr_t)_val_26999 +(uintptr_t) HIGH_BITS) >= 0){
            _val_26999 = NewDouble((eudouble)_val_26999);
        }
    }
    else {
        _val_26999 = NewDouble(DBL_PTR(_14902)->dbl - (eudouble)1);
    }
    DeRef(_14902);
    _14902 = NOVALUE;

    /** scanner.e:1079				if d > 16 then*/
    if (_d_27000 <= 16)
    goto L4; // [65] 76

    /** scanner.e:1080					val -= 6*/
    _0 = _val_26999;
    if (IS_ATOM_INT(_val_26999)) {
        _val_26999 = _val_26999 - 6;
        if ((object)((uintptr_t)_val_26999 +(uintptr_t) HIGH_BITS) >= 0){
            _val_26999 = NewDouble((eudouble)_val_26999);
        }
    }
    else {
        _val_26999 = NewDouble(DBL_PTR(_val_26999)->dbl - (eudouble)6);
    }
    DeRef(_0);
L4: 

    /** scanner.e:1082				cnt -= 1*/
    _cnt_26997 = _cnt_26997 - 1;

    /** scanner.e:1084		end while*/
    goto L1; // [85] 15
L2: 

    /** scanner.e:1086		return val*/
    return _val_26999;
    ;
}


object _61GetBinaryChar(object _delim_27020)
{
    object _val_27021 = NOVALUE;
    object _d_27022 = NOVALUE;
    object _vchars_27023 = NOVALUE;
    object _cnt_27026 = NOVALUE;
    object _14916 = NOVALUE;
    object _14915 = NOVALUE;
    object _14909 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1092		sequence vchars = "01_ " & delim*/
    Append(&_vchars_27023, _14907, _delim_27020);

    /** scanner.e:1093		integer cnt = 0*/
    _cnt_27026 = 0;

    /** scanner.e:1094		val = 0*/
    DeRef(_val_27021);
    _val_27021 = 0;

    /** scanner.e:1095		while 1 do*/
L1: 

    /** scanner.e:1096			d = find(getch(), vchars)*/
    _14909 = _61getch();
    _d_27022 = find_from(_14909, _vchars_27023, 1);
    DeRef(_14909);
    _14909 = NOVALUE;

    /** scanner.e:1097			if d = 0 then*/
    if (_d_27022 != 0)
    goto L2; // [36] 50

    /** scanner.e:1098				CompileErr( EXPECTING_ONLY_0_1_OR_SPACE_TO_FOLLOW_THE_B)*/
    RefDS(_22015);
    _49CompileErr(343, _22015, 0);
L2: 

    /** scanner.e:1100			if d = 5 then*/
    if (_d_27022 != 5)
    goto L3; // [52] 65

    /** scanner.e:1101				ungetch()*/
    _61ungetch();

    /** scanner.e:1102				exit*/
    goto L4; // [62] 108
L3: 

    /** scanner.e:1104			if d = 4 then*/
    if (_d_27022 != 4)
    goto L5; // [67] 76

    /** scanner.e:1105				exit*/
    goto L4; // [73] 108
L5: 

    /** scanner.e:1107			if d != 3 then*/
    if (_d_27022 == 3)
    goto L1; // [78] 24

    /** scanner.e:1108				val = val * 2 + d - 1*/
    if (IS_ATOM_INT(_val_27021) && IS_ATOM_INT(_val_27021)) {
        _14915 = _val_27021 + _val_27021;
        if ((object)((uintptr_t)_14915 + (uintptr_t)HIGH_BITS) >= 0){
            _14915 = NewDouble((eudouble)_14915);
        }
    }
    else {
        if (IS_ATOM_INT(_val_27021)) {
            _14915 = NewDouble((eudouble)_val_27021 + DBL_PTR(_val_27021)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_27021)) {
                _14915 = NewDouble(DBL_PTR(_val_27021)->dbl + (eudouble)_val_27021);
            }
            else
            _14915 = NewDouble(DBL_PTR(_val_27021)->dbl + DBL_PTR(_val_27021)->dbl);
        }
    }
    if (IS_ATOM_INT(_14915)) {
        _14916 = _14915 + _d_27022;
        if ((object)((uintptr_t)_14916 + (uintptr_t)HIGH_BITS) >= 0){
            _14916 = NewDouble((eudouble)_14916);
        }
    }
    else {
        _14916 = NewDouble(DBL_PTR(_14915)->dbl + (eudouble)_d_27022);
    }
    DeRef(_14915);
    _14915 = NOVALUE;
    DeRef(_val_27021);
    if (IS_ATOM_INT(_14916)) {
        _val_27021 = _14916 - 1;
        if ((object)((uintptr_t)_val_27021 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27021 = NewDouble((eudouble)_val_27021);
        }
    }
    else {
        _val_27021 = NewDouble(DBL_PTR(_14916)->dbl - (eudouble)1);
    }
    DeRef(_14916);
    _14916 = NOVALUE;

    /** scanner.e:1109				cnt += 1*/
    _cnt_27026 = _cnt_27026 + 1;

    /** scanner.e:1111		end while*/
    goto L1; // [105] 24
L4: 

    /** scanner.e:1113		if cnt = 0 then*/
    if (_cnt_27026 != 0)
    goto L6; // [110] 124

    /** scanner.e:1114			CompileErr(EXPECTING_ONLY_0_1_OR_SPACE_TO_FOLLOW_THE_B)*/
    RefDS(_22015);
    _49CompileErr(343, _22015, 0);
L6: 

    /** scanner.e:1116		return val*/
    DeRefi(_vchars_27023);
    return _val_27021;
    ;
}


object _61EscapeChar(object _delim_27050)
{
    object _c_27051 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1124		c = getch()*/
    _0 = _c_27051;
    _c_27051 = _61getch();
    DeRef(_0);

    /** scanner.e:1125		switch c do*/
    if (IS_SEQUENCE(_c_27051) ){
        goto L1; // [10] 135
    }
    if(!IS_ATOM_INT(_c_27051)){
        if( (DBL_PTR(_c_27051)->dbl != (eudouble) ((object) DBL_PTR(_c_27051)->dbl) ) ){
            goto L1; // [10] 135
        }
        _0 = (object) DBL_PTR(_c_27051)->dbl;
    }
    else {
        _0 = _c_27051;
    };
    switch ( _0 ){ 

        /** scanner.e:1126			case 'n' then*/
        case 110:

        /** scanner.e:1127				c = 10 -- Newline*/
        DeRef(_c_27051);
        _c_27051 = 10;
        goto L2; // [24] 147

        /** scanner.e:1129			case 't' then*/
        case 116:

        /** scanner.e:1130				c = 9 -- Tabulator*/
        DeRef(_c_27051);
        _c_27051 = 9;
        goto L2; // [35] 147

        /** scanner.e:1132			case '"', '\\', '\'' then*/
        case 34:
        case 92:
        case 39:

        /** scanner.e:1137			case 'r' then*/
        goto L2; // [47] 147
        case 114:

        /** scanner.e:1138				c = 13 -- Carriage Return*/
        DeRef(_c_27051);
        _c_27051 = 13;
        goto L2; // [56] 147

        /** scanner.e:1140			case '0' then*/
        case 48:

        /** scanner.e:1141				c = 0 -- Null*/
        DeRef(_c_27051);
        _c_27051 = 0;
        goto L2; // [67] 147

        /** scanner.e:1143			case 'e', 'E' then*/
        case 101:
        case 69:

        /** scanner.e:1144				c = 27 -- escape char.*/
        DeRef(_c_27051);
        _c_27051 = 27;
        goto L2; // [80] 147

        /** scanner.e:1146			case 'x' then*/
        case 120:

        /** scanner.e:1148				c = GetHexChar(2, 340)*/
        _0 = _c_27051;
        _c_27051 = _61GetHexChar(2, 340);
        DeRef(_0);
        goto L2; // [93] 147

        /** scanner.e:1150			case 'u' then*/
        case 117:

        /** scanner.e:1152				c = GetHexChar(4, 341)*/
        _0 = _c_27051;
        _c_27051 = _61GetHexChar(4, 341);
        DeRef(_0);
        goto L2; // [106] 147

        /** scanner.e:1154			case 'U' then*/
        case 85:

        /** scanner.e:1156				c = GetHexChar(8, 342)*/
        _0 = _c_27051;
        _c_27051 = _61GetHexChar(8, 342);
        DeRef(_0);
        goto L2; // [119] 147

        /** scanner.e:1158			case 'b' then*/
        case 98:

        /** scanner.e:1160				c = GetBinaryChar(delim)*/
        _0 = _c_27051;
        _c_27051 = _61GetBinaryChar(_delim_27050);
        DeRef(_0);
        goto L2; // [131] 147

        /** scanner.e:1162			case else*/
        default:
L1: 

        /** scanner.e:1163				CompileErr(UNKNOWN_ESCAPE_CHARACTER)*/
        RefDS(_22015);
        _49CompileErr(155, _22015, 0);
    ;}L2: 

    /** scanner.e:1166		return c*/
    return _c_27051;
    ;
}


object _61my_sscanf(object _yytext_27074)
{
    object _e_sign_27075 = NOVALUE;
    object _ndigits_27076 = NOVALUE;
    object _e_mag_27077 = NOVALUE;
    object _mantissa_27078 = NOVALUE;
    object _c_27079 = NOVALUE;
    object _i_27080 = NOVALUE;
    object _dec_27081 = NOVALUE;
    object _frac_27114 = NOVALUE;
    object _14961 = NOVALUE;
    object _14956 = NOVALUE;
    object _14955 = NOVALUE;
    object _14953 = NOVALUE;
    object _14952 = NOVALUE;
    object _14951 = NOVALUE;
    object _14943 = NOVALUE;
    object _14942 = NOVALUE;
    object _14939 = NOVALUE;
    object _14938 = NOVALUE;
    object _14937 = NOVALUE;
    object _14932 = NOVALUE;
    object _14931 = NOVALUE;
    object _14929 = NOVALUE;
    object _14927 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1179		if length(yytext) < 2 then*/
    if (IS_SEQUENCE(_yytext_27074)){
            _14927 = SEQ_PTR(_yytext_27074)->length;
    }
    else {
        _14927 = 1;
    }
    if (_14927 >= 2)
    goto L1; // [8] 22

    /** scanner.e:1180			CompileErr(NUMBER_NOT_FORMED_CORRECTLY)*/
    RefDS(_22015);
    _49CompileErr(121, _22015, 0);
L1: 

    /** scanner.e:1184		if find( 'e', yytext ) or find( 'E', yytext ) then*/
    _14929 = find_from(101, _yytext_27074, 1);
    if (_14929 != 0) {
        goto L2; // [29] 43
    }
    _14931 = find_from(69, _yytext_27074, 1);
    if (_14931 == 0)
    {
        _14931 = NOVALUE;
        goto L3; // [39] 59
    }
    else{
        _14931 = NOVALUE;
    }
L2: 

    /** scanner.e:1185			ifdef BITS32 then*/

    /** scanner.e:1186				return scientific_to_atom( yytext, DOUBLE )*/
    RefDS(_yytext_27074);
    _14932 = _27scientific_to_atom(_yytext_27074, 2);
    DeRefDS(_yytext_27074);
    DeRef(_mantissa_27078);
    DeRef(_dec_27081);
    return _14932;
L3: 

    /** scanner.e:1193		mantissa = 0.0*/
    RefDS(_14934);
    DeRef(_mantissa_27078);
    _mantissa_27078 = _14934;

    /** scanner.e:1194		ndigits = 0*/
    _ndigits_27076 = 0;

    /** scanner.e:1198		yytext &= 0 -- end marker*/
    Append(&_yytext_27074, _yytext_27074, 0);

    /** scanner.e:1199		c = yytext[1]*/
    _2 = (object)SEQ_PTR(_yytext_27074);
    _c_27079 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_c_27079))
    _c_27079 = (object)DBL_PTR(_c_27079)->dbl;

    /** scanner.e:1200		i = 2*/
    _i_27080 = 2;

    /** scanner.e:1201		while c >= '0' and c <= '9' do*/
L4: 
    _14937 = (_c_27079 >= 48);
    if (_14937 == 0) {
        goto L5; // [95] 144
    }
    _14939 = (_c_27079 <= 57);
    if (_14939 == 0)
    {
        DeRef(_14939);
        _14939 = NOVALUE;
        goto L5; // [104] 144
    }
    else{
        DeRef(_14939);
        _14939 = NOVALUE;
    }

    /** scanner.e:1202			ndigits += 1*/
    _ndigits_27076 = _ndigits_27076 + 1;

    /** scanner.e:1203			mantissa = mantissa * 10.0 + (c - '0')*/
    if (IS_ATOM_INT(_mantissa_27078)) {
        _14942 = NewDouble((eudouble)_mantissa_27078 * DBL_PTR(_14941)->dbl);
    }
    else {
        _14942 = NewDouble(DBL_PTR(_mantissa_27078)->dbl * DBL_PTR(_14941)->dbl);
    }
    _14943 = _c_27079 - 48;
    if ((object)((uintptr_t)_14943 +(uintptr_t) HIGH_BITS) >= 0){
        _14943 = NewDouble((eudouble)_14943);
    }
    DeRef(_mantissa_27078);
    if (IS_ATOM_INT(_14943)) {
        _mantissa_27078 = NewDouble(DBL_PTR(_14942)->dbl + (eudouble)_14943);
    }
    else
    _mantissa_27078 = NewDouble(DBL_PTR(_14942)->dbl + DBL_PTR(_14943)->dbl);
    DeRefDS(_14942);
    _14942 = NOVALUE;
    DeRef(_14943);
    _14943 = NOVALUE;

    /** scanner.e:1204			c = yytext[i]*/
    _2 = (object)SEQ_PTR(_yytext_27074);
    _c_27079 = (object)*(((s1_ptr)_2)->base + _i_27080);
    if (!IS_ATOM_INT(_c_27079))
    _c_27079 = (object)DBL_PTR(_c_27079)->dbl;

    /** scanner.e:1205			i += 1*/
    _i_27080 = _i_27080 + 1;

    /** scanner.e:1206		end while*/
    goto L4; // [141] 91
L5: 

    /** scanner.e:1208		if c = '.' then*/
    if (_c_27079 != 46)
    goto L6; // [146] 247

    /** scanner.e:1210			c = yytext[i]*/
    _2 = (object)SEQ_PTR(_yytext_27074);
    _c_27079 = (object)*(((s1_ptr)_2)->base + _i_27080);
    if (!IS_ATOM_INT(_c_27079))
    _c_27079 = (object)DBL_PTR(_c_27079)->dbl;

    /** scanner.e:1211			i += 1*/
    _i_27080 = _i_27080 + 1;

    /** scanner.e:1212			dec = 1.0*/
    RefDS(_14950);
    DeRef(_dec_27081);
    _dec_27081 = _14950;

    /** scanner.e:1213			atom frac = 0*/
    DeRef(_frac_27114);
    _frac_27114 = 0;

    /** scanner.e:1214			while c >= '0' and c <= '9' do*/
L7: 
    _14951 = (_c_27079 >= 48);
    if (_14951 == 0) {
        goto L8; // [181] 236
    }
    _14953 = (_c_27079 <= 57);
    if (_14953 == 0)
    {
        DeRef(_14953);
        _14953 = NOVALUE;
        goto L8; // [190] 236
    }
    else{
        DeRef(_14953);
        _14953 = NOVALUE;
    }

    /** scanner.e:1215				ndigits += 1*/
    _ndigits_27076 = _ndigits_27076 + 1;

    /** scanner.e:1216				frac = frac * 10 + (c - '0')*/
    if (IS_ATOM_INT(_frac_27114)) {
        if (_frac_27114 == (short)_frac_27114){
            _14955 = _frac_27114 * 10;
        }
        else{
            _14955 = NewDouble(_frac_27114 * (eudouble)10);
        }
    }
    else {
        _14955 = NewDouble(DBL_PTR(_frac_27114)->dbl * (eudouble)10);
    }
    _14956 = _c_27079 - 48;
    if ((object)((uintptr_t)_14956 +(uintptr_t) HIGH_BITS) >= 0){
        _14956 = NewDouble((eudouble)_14956);
    }
    DeRef(_frac_27114);
    if (IS_ATOM_INT(_14955) && IS_ATOM_INT(_14956)) {
        _frac_27114 = _14955 + _14956;
        if ((object)((uintptr_t)_frac_27114 + (uintptr_t)HIGH_BITS) >= 0){
            _frac_27114 = NewDouble((eudouble)_frac_27114);
        }
    }
    else {
        if (IS_ATOM_INT(_14955)) {
            _frac_27114 = NewDouble((eudouble)_14955 + DBL_PTR(_14956)->dbl);
        }
        else {
            if (IS_ATOM_INT(_14956)) {
                _frac_27114 = NewDouble(DBL_PTR(_14955)->dbl + (eudouble)_14956);
            }
            else
            _frac_27114 = NewDouble(DBL_PTR(_14955)->dbl + DBL_PTR(_14956)->dbl);
        }
    }
    DeRef(_14955);
    _14955 = NOVALUE;
    DeRef(_14956);
    _14956 = NOVALUE;

    /** scanner.e:1217				dec *= 10.0*/
    _0 = _dec_27081;
    if (IS_ATOM_INT(_dec_27081)) {
        _dec_27081 = NewDouble((eudouble)_dec_27081 * DBL_PTR(_14941)->dbl);
    }
    else {
        _dec_27081 = NewDouble(DBL_PTR(_dec_27081)->dbl * DBL_PTR(_14941)->dbl);
    }
    DeRef(_0);

    /** scanner.e:1218				c = yytext[i]*/
    _2 = (object)SEQ_PTR(_yytext_27074);
    _c_27079 = (object)*(((s1_ptr)_2)->base + _i_27080);
    if (!IS_ATOM_INT(_c_27079))
    _c_27079 = (object)DBL_PTR(_c_27079)->dbl;

    /** scanner.e:1219				i += 1*/
    _i_27080 = _i_27080 + 1;

    /** scanner.e:1220			end while*/
    goto L7; // [233] 177
L8: 

    /** scanner.e:1221			mantissa += frac / dec*/
    if (IS_ATOM_INT(_frac_27114) && IS_ATOM_INT(_dec_27081)) {
        _14961 = (_frac_27114 % _dec_27081) ? NewDouble((eudouble)_frac_27114 / _dec_27081) : (_frac_27114 / _dec_27081);
    }
    else {
        if (IS_ATOM_INT(_frac_27114)) {
            _14961 = NewDouble((eudouble)_frac_27114 / DBL_PTR(_dec_27081)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec_27081)) {
                _14961 = NewDouble(DBL_PTR(_frac_27114)->dbl / (eudouble)_dec_27081);
            }
            else
            _14961 = NewDouble(DBL_PTR(_frac_27114)->dbl / DBL_PTR(_dec_27081)->dbl);
        }
    }
    _0 = _mantissa_27078;
    if (IS_ATOM_INT(_mantissa_27078) && IS_ATOM_INT(_14961)) {
        _mantissa_27078 = _mantissa_27078 + _14961;
        if ((object)((uintptr_t)_mantissa_27078 + (uintptr_t)HIGH_BITS) >= 0){
            _mantissa_27078 = NewDouble((eudouble)_mantissa_27078);
        }
    }
    else {
        if (IS_ATOM_INT(_mantissa_27078)) {
            _mantissa_27078 = NewDouble((eudouble)_mantissa_27078 + DBL_PTR(_14961)->dbl);
        }
        else {
            if (IS_ATOM_INT(_14961)) {
                _mantissa_27078 = NewDouble(DBL_PTR(_mantissa_27078)->dbl + (eudouble)_14961);
            }
            else
            _mantissa_27078 = NewDouble(DBL_PTR(_mantissa_27078)->dbl + DBL_PTR(_14961)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_14961);
    _14961 = NOVALUE;
L6: 
    DeRef(_frac_27114);
    _frac_27114 = NOVALUE;

    /** scanner.e:1224		if ndigits = 0 then*/
    if (_ndigits_27076 != 0)
    goto L9; // [251] 265

    /** scanner.e:1225			CompileErr(NUMBER_NOT_FORMED_CORRECTLY)  -- no digits*/
    RefDS(_22015);
    _49CompileErr(121, _22015, 0);
L9: 

    /** scanner.e:1271		return mantissa*/
    DeRefDS(_yytext_27074);
    DeRef(_dec_27081);
    DeRef(_14951);
    _14951 = NOVALUE;
    DeRef(_14932);
    _14932 = NOVALUE;
    DeRef(_14937);
    _14937 = NOVALUE;
    return _mantissa_27078;
    ;
}


void _61maybe_namespace()
{
    object _0, _1, _2;
    

    /** scanner.e:1276		might_be_namespace = 1*/
    _61might_be_namespace_27132 = 1;

    /** scanner.e:1277	end procedure*/
    return;
    ;
}


object _61ExtendedString(object _ech_27142)
{
    object _ch_27143 = NOVALUE;
    object _fch_27144 = NOVALUE;
    object _cline_27145 = NOVALUE;
    object _string_text_27146 = NOVALUE;
    object _trimming_27147 = NOVALUE;
    object _15014 = NOVALUE;
    object _15013 = NOVALUE;
    object _15011 = NOVALUE;
    object _15010 = NOVALUE;
    object _15009 = NOVALUE;
    object _15008 = NOVALUE;
    object _15007 = NOVALUE;
    object _15006 = NOVALUE;
    object _15005 = NOVALUE;
    object _15004 = NOVALUE;
    object _15002 = NOVALUE;
    object _15001 = NOVALUE;
    object _15000 = NOVALUE;
    object _14999 = NOVALUE;
    object _14998 = NOVALUE;
    object _14997 = NOVALUE;
    object _14994 = NOVALUE;
    object _14993 = NOVALUE;
    object _14992 = NOVALUE;
    object _14990 = NOVALUE;
    object _14989 = NOVALUE;
    object _14988 = NOVALUE;
    object _14987 = NOVALUE;
    object _14984 = NOVALUE;
    object _14969 = NOVALUE;
    object _14967 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1290		cline = line_number*/
    _cline_27145 = _12line_number_20227;

    /** scanner.e:1291		string_text = ""*/
    RefDS(_5);
    DeRefi(_string_text_27146);
    _string_text_27146 = _5;

    /** scanner.e:1292		trimming = 0*/
    _trimming_27147 = 0;

    /** scanner.e:1293		ch = getch()*/
    _ch_27143 = _61getch();
    if (!IS_ATOM_INT(_ch_27143)) {
        _1 = (object)(DBL_PTR(_ch_27143)->dbl);
        DeRefDS(_ch_27143);
        _ch_27143 = _1;
    }

    /** scanner.e:1294		if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_49ThisLine_49261)){
            _14967 = SEQ_PTR(_49ThisLine_49261)->length;
    }
    else {
        _14967 = 1;
    }
    if (_49bp_49265 <= _14967)
    goto L1; // [40] 101

    /** scanner.e:1296			read_line()*/
    _61read_line();

    /** scanner.e:1297			while ThisLine[bp] = '_' do*/
L2: 
    _2 = (object)SEQ_PTR(_49ThisLine_49261);
    _14969 = (object)*(((s1_ptr)_2)->base + _49bp_49265);
    if (binary_op_a(NOTEQ, _14969, 95)){
        _14969 = NOVALUE;
        goto L3; // [61] 86
    }
    _14969 = NOVALUE;

    /** scanner.e:1298				trimming += 1*/
    _trimming_27147 = _trimming_27147 + 1;

    /** scanner.e:1299				bp += 1*/
    _49bp_49265 = _49bp_49265 + 1;

    /** scanner.e:1300			end while*/
    goto L2; // [83] 53
L3: 

    /** scanner.e:1301			if trimming > 0 then*/
    if (_trimming_27147 <= 0)
    goto L4; // [88] 100

    /** scanner.e:1302				ch = getch()*/
    _ch_27143 = _61getch();
    if (!IS_ATOM_INT(_ch_27143)) {
        _1 = (object)(DBL_PTR(_ch_27143)->dbl);
        DeRefDS(_ch_27143);
        _ch_27143 = _1;
    }
L4: 
L1: 

    /** scanner.e:1306		while 1 do*/
L5: 

    /** scanner.e:1307			if ch = END_OF_FILE_CHAR then*/
    if (_ch_27143 != 26)
    goto L6; // [110] 124

    /** scanner.e:1308				CompileErr(RAW_STRING_LITERAL_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _49CompileErr(129, _cline_27145, 0);
L6: 

    /** scanner.e:1311			if ch = ech then*/
    if (_ch_27143 != _ech_27142)
    goto L7; // [126] 182

    /** scanner.e:1312				if ech != '"' then*/
    if (_ech_27142 == 34)
    goto L8; // [132] 141

    /** scanner.e:1313					exit*/
    goto L9; // [138] 312
L8: 

    /** scanner.e:1315				fch = getch()*/
    _fch_27144 = _61getch();
    if (!IS_ATOM_INT(_fch_27144)) {
        _1 = (object)(DBL_PTR(_fch_27144)->dbl);
        DeRefDS(_fch_27144);
        _fch_27144 = _1;
    }

    /** scanner.e:1316				if fch = '"' then*/
    if (_fch_27144 != 34)
    goto LA; // [150] 177

    /** scanner.e:1317					fch = getch()*/
    _fch_27144 = _61getch();
    if (!IS_ATOM_INT(_fch_27144)) {
        _1 = (object)(DBL_PTR(_fch_27144)->dbl);
        DeRefDS(_fch_27144);
        _fch_27144 = _1;
    }

    /** scanner.e:1318					if fch = '"' then*/
    if (_fch_27144 != 34)
    goto LB; // [163] 172

    /** scanner.e:1319						exit*/
    goto L9; // [169] 312
LB: 

    /** scanner.e:1321					ungetch()*/
    _61ungetch();
LA: 

    /** scanner.e:1323				ungetch()*/
    _61ungetch();
L7: 

    /** scanner.e:1326			if ch != '\r' then*/
    if (_ch_27143 == 13)
    goto LC; // [184] 195

    /** scanner.e:1329				string_text &= ch*/
    Append(&_string_text_27146, _string_text_27146, _ch_27143);
LC: 

    /** scanner.e:1332			if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_49ThisLine_49261)){
            _14984 = SEQ_PTR(_49ThisLine_49261)->length;
    }
    else {
        _14984 = 1;
    }
    if (_49bp_49265 <= _14984)
    goto LD; // [204] 300

    /** scanner.e:1333				read_line() -- sets bp to 1, btw.*/
    _61read_line();

    /** scanner.e:1334				if trimming > 0 then*/
    if (_trimming_27147 <= 0)
    goto LE; // [214] 299

    /** scanner.e:1335					while bp <= trimming and bp <= length(ThisLine) do*/
LF: 
    _14987 = (_49bp_49265 <= _trimming_27147);
    if (_14987 == 0) {
        goto L10; // [229] 298
    }
    if (IS_SEQUENCE(_49ThisLine_49261)){
            _14989 = SEQ_PTR(_49ThisLine_49261)->length;
    }
    else {
        _14989 = 1;
    }
    _14990 = (_49bp_49265 <= _14989);
    _14989 = NOVALUE;
    if (_14990 == 0)
    {
        DeRef(_14990);
        _14990 = NOVALUE;
        goto L10; // [245] 298
    }
    else{
        DeRef(_14990);
        _14990 = NOVALUE;
    }

    /** scanner.e:1336						ch = ThisLine[bp]*/
    _2 = (object)SEQ_PTR(_49ThisLine_49261);
    _ch_27143 = (object)*(((s1_ptr)_2)->base + _49bp_49265);
    if (!IS_ATOM_INT(_ch_27143)){
        _ch_27143 = (object)DBL_PTR(_ch_27143)->dbl;
    }

    /** scanner.e:1337						if ch != ' ' and ch != '\t' then*/
    _14992 = (_ch_27143 != 32);
    if (_14992 == 0) {
        goto L11; // [266] 283
    }
    _14994 = (_ch_27143 != 9);
    if (_14994 == 0)
    {
        DeRef(_14994);
        _14994 = NOVALUE;
        goto L11; // [275] 283
    }
    else{
        DeRef(_14994);
        _14994 = NOVALUE;
    }

    /** scanner.e:1338							exit*/
    goto L10; // [280] 298
L11: 

    /** scanner.e:1340						bp += 1*/
    _49bp_49265 = _49bp_49265 + 1;

    /** scanner.e:1341					end while*/
    goto LF; // [295] 223
L10: 
LE: 
LD: 

    /** scanner.e:1344			ch = getch()*/
    _ch_27143 = _61getch();
    if (!IS_ATOM_INT(_ch_27143)) {
        _1 = (object)(DBL_PTR(_ch_27143)->dbl);
        DeRefDS(_ch_27143);
        _ch_27143 = _1;
    }

    /** scanner.e:1345		end while*/
    goto L5; // [309] 106
L9: 

    /** scanner.e:1346		if length(string_text) > 0 and string_text[1] = '\n' then*/
    if (IS_SEQUENCE(_string_text_27146)){
            _14997 = SEQ_PTR(_string_text_27146)->length;
    }
    else {
        _14997 = 1;
    }
    _14998 = (_14997 > 0);
    _14997 = NOVALUE;
    if (_14998 == 0) {
        goto L12; // [321] 391
    }
    _2 = (object)SEQ_PTR(_string_text_27146);
    _15000 = (object)*(((s1_ptr)_2)->base + 1);
    _15001 = (_15000 == 10);
    _15000 = NOVALUE;
    if (_15001 == 0)
    {
        DeRef(_15001);
        _15001 = NOVALUE;
        goto L12; // [334] 391
    }
    else{
        DeRef(_15001);
        _15001 = NOVALUE;
    }

    /** scanner.e:1347			string_text = string_text[2 .. $]*/
    if (IS_SEQUENCE(_string_text_27146)){
            _15002 = SEQ_PTR(_string_text_27146)->length;
    }
    else {
        _15002 = 1;
    }
    rhs_slice_target = (object_ptr)&_string_text_27146;
    RHS_Slice(_string_text_27146, 2, _15002);

    /** scanner.e:1348			if length(string_text) > 0 and string_text[$] = '\n' then*/
    if (IS_SEQUENCE(_string_text_27146)){
            _15004 = SEQ_PTR(_string_text_27146)->length;
    }
    else {
        _15004 = 1;
    }
    _15005 = (_15004 > 0);
    _15004 = NOVALUE;
    if (_15005 == 0) {
        goto L13; // [356] 390
    }
    if (IS_SEQUENCE(_string_text_27146)){
            _15007 = SEQ_PTR(_string_text_27146)->length;
    }
    else {
        _15007 = 1;
    }
    _2 = (object)SEQ_PTR(_string_text_27146);
    _15008 = (object)*(((s1_ptr)_2)->base + _15007);
    _15009 = (_15008 == 10);
    _15008 = NOVALUE;
    if (_15009 == 0)
    {
        DeRef(_15009);
        _15009 = NOVALUE;
        goto L13; // [372] 390
    }
    else{
        DeRef(_15009);
        _15009 = NOVALUE;
    }

    /** scanner.e:1349				string_text = string_text[1 .. $-1]*/
    if (IS_SEQUENCE(_string_text_27146)){
            _15010 = SEQ_PTR(_string_text_27146)->length;
    }
    else {
        _15010 = 1;
    }
    _15011 = _15010 - 1;
    _15010 = NOVALUE;
    rhs_slice_target = (object_ptr)&_string_text_27146;
    RHS_Slice(_string_text_27146, 1, _15011);
L13: 
L12: 

    /** scanner.e:1352		return {STRING, NewStringSym(string_text)}*/
    RefDS(_string_text_27146);
    _15013 = _53NewStringSym(_string_text_27146);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 503;
    ((intptr_t *)_2)[2] = _15013;
    _15014 = MAKE_SEQ(_1);
    _15013 = NOVALUE;
    DeRefDSi(_string_text_27146);
    DeRef(_14987);
    _14987 = NOVALUE;
    DeRef(_15005);
    _15005 = NOVALUE;
    DeRef(_15011);
    _15011 = NOVALUE;
    DeRef(_14998);
    _14998 = NOVALUE;
    DeRef(_14992);
    _14992 = NOVALUE;
    return _15014;
    ;
}


object _61GetHexString(object _maxnibbles_27234)
{
    object _ch_27235 = NOVALUE;
    object _digit_27236 = NOVALUE;
    object _val_27237 = NOVALUE;
    object _cline_27238 = NOVALUE;
    object _nibble_27239 = NOVALUE;
    object _string_text_27240 = NOVALUE;
    object _15028 = NOVALUE;
    object _15027 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1363		cline = line_number*/
    _cline_27238 = _12line_number_20227;

    /** scanner.e:1364		string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_27240);
    _string_text_27240 = _5;

    /** scanner.e:1365		nibble = 1*/
    _nibble_27239 = 1;

    /** scanner.e:1366		val = -1*/
    DeRef(_val_27237);
    _val_27237 = -1;

    /** scanner.e:1367		ch = getch()*/
    _ch_27235 = _61getch();
    if (!IS_ATOM_INT(_ch_27235)) {
        _1 = (object)(DBL_PTR(_ch_27235)->dbl);
        DeRefDS(_ch_27235);
        _ch_27235 = _1;
    }

    /** scanner.e:1368		while 1 do*/
L1: 

    /** scanner.e:1369			if ch = END_OF_FILE_CHAR then*/
    if (_ch_27235 != 26)
    goto L2; // [45] 59

    /** scanner.e:1370				CompileErr(RAW_STRING_LITERAL_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _49CompileErr(129, _cline_27238, 0);
L2: 

    /** scanner.e:1373			if ch = '"' then*/
    if (_ch_27235 != 34)
    goto L3; // [61] 70

    /** scanner.e:1374				exit*/
    goto L4; // [67] 228
L3: 

    /** scanner.e:1377			digit = find(ch, "0123456789ABCDEFabcdef_ \t\n\r")*/
    _digit_27236 = find_from(_ch_27235, _15018, 1);

    /** scanner.e:1378			if digit = 0 then*/
    if (_digit_27236 != 0)
    goto L5; // [79] 93

    /** scanner.e:1379				CompileErr(INVALID_CHARACTER_IN_HEX_STRING)*/
    RefDS(_22015);
    _49CompileErr(329, _22015, 0);
L5: 

    /** scanner.e:1381			if digit <= 23 then*/
    if (_digit_27236 > 23)
    goto L6; // [95] 181

    /** scanner.e:1382				if digit != 23 then*/
    if (_digit_27236 == 23)
    goto L7; // [101] 216

    /** scanner.e:1383					if digit > 16 then*/
    if (_digit_27236 <= 16)
    goto L8; // [107] 118

    /** scanner.e:1384						digit -= 6*/
    _digit_27236 = _digit_27236 - 6;
L8: 

    /** scanner.e:1386					if nibble = 1 then*/
    if (_nibble_27239 != 1)
    goto L9; // [120] 133

    /** scanner.e:1387						val = digit - 1*/
    DeRef(_val_27237);
    _val_27237 = _digit_27236 - 1;
    if ((object)((uintptr_t)_val_27237 +(uintptr_t) HIGH_BITS) >= 0){
        _val_27237 = NewDouble((eudouble)_val_27237);
    }
    goto LA; // [130] 171
L9: 

    /** scanner.e:1389						val = val * 16 + digit - 1*/
    if (IS_ATOM_INT(_val_27237)) {
        if (_val_27237 == (short)_val_27237){
            _15027 = _val_27237 * 16;
        }
        else{
            _15027 = NewDouble(_val_27237 * (eudouble)16);
        }
    }
    else {
        _15027 = NewDouble(DBL_PTR(_val_27237)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_15027)) {
        _15028 = _15027 + _digit_27236;
        if ((object)((uintptr_t)_15028 + (uintptr_t)HIGH_BITS) >= 0){
            _15028 = NewDouble((eudouble)_15028);
        }
    }
    else {
        _15028 = NewDouble(DBL_PTR(_15027)->dbl + (eudouble)_digit_27236);
    }
    DeRef(_15027);
    _15027 = NOVALUE;
    DeRef(_val_27237);
    if (IS_ATOM_INT(_15028)) {
        _val_27237 = _15028 - 1;
        if ((object)((uintptr_t)_val_27237 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27237 = NewDouble((eudouble)_val_27237);
        }
    }
    else {
        _val_27237 = NewDouble(DBL_PTR(_15028)->dbl - (eudouble)1);
    }
    DeRef(_15028);
    _15028 = NOVALUE;

    /** scanner.e:1390						if nibble = maxnibbles then*/
    if (_nibble_27239 != _maxnibbles_27234)
    goto LB; // [149] 170

    /** scanner.e:1391							string_text &= val*/
    Ref(_val_27237);
    Append(&_string_text_27240, _string_text_27240, _val_27237);

    /** scanner.e:1392							val = -1*/
    DeRef(_val_27237);
    _val_27237 = -1;

    /** scanner.e:1393							nibble = 0*/
    _nibble_27239 = 0;
LB: 
LA: 

    /** scanner.e:1396					nibble += 1*/
    _nibble_27239 = _nibble_27239 + 1;
    goto L7; // [178] 216
L6: 

    /** scanner.e:1399				if val >= 0 then*/
    if (binary_op_a(LESS, _val_27237, 0)){
        goto LC; // [183] 199
    }

    /** scanner.e:1401					string_text &= val*/
    Ref(_val_27237);
    Append(&_string_text_27240, _string_text_27240, _val_27237);

    /** scanner.e:1402					val = -1*/
    DeRef(_val_27237);
    _val_27237 = -1;
LC: 

    /** scanner.e:1404				nibble = 1*/
    _nibble_27239 = 1;

    /** scanner.e:1405				if ch = '\n' then*/
    if (_ch_27235 != 10)
    goto LD; // [206] 215

    /** scanner.e:1406					read_line()*/
    _61read_line();
LD: 
L7: 

    /** scanner.e:1409			ch = getch()*/
    _ch_27235 = _61getch();
    if (!IS_ATOM_INT(_ch_27235)) {
        _1 = (object)(DBL_PTR(_ch_27235)->dbl);
        DeRefDS(_ch_27235);
        _ch_27235 = _1;
    }

    /** scanner.e:1410		end while*/
    goto L1; // [225] 41
L4: 

    /** scanner.e:1412		if val >= 0 then	*/
    if (binary_op_a(LESS, _val_27237, 0)){
        goto LE; // [230] 241
    }

    /** scanner.e:1414			string_text &= val*/
    Ref(_val_27237);
    Append(&_string_text_27240, _string_text_27240, _val_27237);
LE: 

    /** scanner.e:1417		return string_text*/
    DeRef(_val_27237);
    return _string_text_27240;
    ;
}


object _61GetBitString()
{
    object _ch_27287 = NOVALUE;
    object _digit_27288 = NOVALUE;
    object _val_27289 = NOVALUE;
    object _cline_27290 = NOVALUE;
    object _bitcnt_27291 = NOVALUE;
    object _string_text_27292 = NOVALUE;
    object _15050 = NOVALUE;
    object _15049 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1428		cline = line_number*/
    _cline_27290 = _12line_number_20227;

    /** scanner.e:1429		string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_27292);
    _string_text_27292 = _5;

    /** scanner.e:1430		bitcnt = 1*/
    _bitcnt_27291 = 1;

    /** scanner.e:1431		val = -1*/
    DeRef(_val_27289);
    _val_27289 = -1;

    /** scanner.e:1432		ch = getch()*/
    _ch_27287 = _61getch();
    if (!IS_ATOM_INT(_ch_27287)) {
        _1 = (object)(DBL_PTR(_ch_27287)->dbl);
        DeRefDS(_ch_27287);
        _ch_27287 = _1;
    }

    /** scanner.e:1433		while 1 do*/
L1: 

    /** scanner.e:1434			if ch = END_OF_FILE_CHAR then*/
    if (_ch_27287 != 26)
    goto L2; // [43] 57

    /** scanner.e:1435				CompileErr(RAW_STRING_LITERAL_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _49CompileErr(129, _cline_27290, 0);
L2: 

    /** scanner.e:1438			if ch = '"' then*/
    if (_ch_27287 != 34)
    goto L3; // [59] 68

    /** scanner.e:1439				exit*/
    goto L4; // [65] 190
L3: 

    /** scanner.e:1442			digit = find(ch, "01_ \t\n\r")*/
    _digit_27288 = find_from(_ch_27287, _15042, 1);

    /** scanner.e:1443			if digit = 0 then*/
    if (_digit_27288 != 0)
    goto L5; // [77] 91

    /** scanner.e:1444				CompileErr(INVALID_CHARACTER_IN_HEX_STRING)*/
    RefDS(_22015);
    _49CompileErr(329, _22015, 0);
L5: 

    /** scanner.e:1446			if digit <= 3 then*/
    if (_digit_27288 > 3)
    goto L6; // [93] 143

    /** scanner.e:1447				if digit != 3 then*/
    if (_digit_27288 == 3)
    goto L7; // [99] 178

    /** scanner.e:1448					if bitcnt = 1 then*/
    if (_bitcnt_27291 != 1)
    goto L8; // [105] 118

    /** scanner.e:1449						val = digit - 1*/
    DeRef(_val_27289);
    _val_27289 = _digit_27288 - 1;
    if ((object)((uintptr_t)_val_27289 +(uintptr_t) HIGH_BITS) >= 0){
        _val_27289 = NewDouble((eudouble)_val_27289);
    }
    goto L9; // [115] 133
L8: 

    /** scanner.e:1451						val = val * 2 + digit - 1*/
    if (IS_ATOM_INT(_val_27289) && IS_ATOM_INT(_val_27289)) {
        _15049 = _val_27289 + _val_27289;
        if ((object)((uintptr_t)_15049 + (uintptr_t)HIGH_BITS) >= 0){
            _15049 = NewDouble((eudouble)_15049);
        }
    }
    else {
        if (IS_ATOM_INT(_val_27289)) {
            _15049 = NewDouble((eudouble)_val_27289 + DBL_PTR(_val_27289)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_27289)) {
                _15049 = NewDouble(DBL_PTR(_val_27289)->dbl + (eudouble)_val_27289);
            }
            else
            _15049 = NewDouble(DBL_PTR(_val_27289)->dbl + DBL_PTR(_val_27289)->dbl);
        }
    }
    if (IS_ATOM_INT(_15049)) {
        _15050 = _15049 + _digit_27288;
        if ((object)((uintptr_t)_15050 + (uintptr_t)HIGH_BITS) >= 0){
            _15050 = NewDouble((eudouble)_15050);
        }
    }
    else {
        _15050 = NewDouble(DBL_PTR(_15049)->dbl + (eudouble)_digit_27288);
    }
    DeRef(_15049);
    _15049 = NOVALUE;
    DeRef(_val_27289);
    if (IS_ATOM_INT(_15050)) {
        _val_27289 = _15050 - 1;
        if ((object)((uintptr_t)_val_27289 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27289 = NewDouble((eudouble)_val_27289);
        }
    }
    else {
        _val_27289 = NewDouble(DBL_PTR(_15050)->dbl - (eudouble)1);
    }
    DeRef(_15050);
    _15050 = NOVALUE;
L9: 

    /** scanner.e:1453					bitcnt += 1*/
    _bitcnt_27291 = _bitcnt_27291 + 1;
    goto L7; // [140] 178
L6: 

    /** scanner.e:1456				if val >= 0 then*/
    if (binary_op_a(LESS, _val_27289, 0)){
        goto LA; // [145] 161
    }

    /** scanner.e:1458					string_text &= val*/
    Ref(_val_27289);
    Append(&_string_text_27292, _string_text_27292, _val_27289);

    /** scanner.e:1459					val = -1*/
    DeRef(_val_27289);
    _val_27289 = -1;
LA: 

    /** scanner.e:1461				bitcnt = 1*/
    _bitcnt_27291 = 1;

    /** scanner.e:1462				if ch = '\n' then*/
    if (_ch_27287 != 10)
    goto LB; // [168] 177

    /** scanner.e:1463					read_line()*/
    _61read_line();
LB: 
L7: 

    /** scanner.e:1466			ch = getch()*/
    _ch_27287 = _61getch();
    if (!IS_ATOM_INT(_ch_27287)) {
        _1 = (object)(DBL_PTR(_ch_27287)->dbl);
        DeRefDS(_ch_27287);
        _ch_27287 = _1;
    }

    /** scanner.e:1467		end while*/
    goto L1; // [187] 39
L4: 

    /** scanner.e:1469		if val >= 0 then	*/
    if (binary_op_a(LESS, _val_27289, 0)){
        goto LC; // [192] 203
    }

    /** scanner.e:1471			string_text &= val*/
    Ref(_val_27289);
    Append(&_string_text_27292, _string_text_27292, _val_27289);
LC: 

    /** scanner.e:1474		return string_text*/
    DeRef(_val_27289);
    return _string_text_27292;
    ;
}


object _61Scanner()
{
    object _fwd_inlined_set_qualified_fwd_at_441_27432 = NOVALUE;
    object _ch_27333 = NOVALUE;
    object _sp_27334 = NOVALUE;
    object _prev_Nne_27335 = NOVALUE;
    object _i_27336 = NOVALUE;
    object _pch_27337 = NOVALUE;
    object _cline_27338 = NOVALUE;
    object _yytext_27339 = NOVALUE;
    object _namespaces_27340 = NOVALUE;
    object _d_27341 = NOVALUE;
    object _tok_27343 = NOVALUE;
    object _is_int_27344 = NOVALUE;
    object _class_27345 = NOVALUE;
    object _name_27346 = NOVALUE;
    object _is_namespace_27405 = NOVALUE;
    object _basetype_27641 = NOVALUE;
    object _hdigit_27682 = NOVALUE;
    object _fch_27822 = NOVALUE;
    object _cnest_28006 = NOVALUE;
    object _ach_28036 = NOVALUE;
    object _31740 = NOVALUE;
    object _31739 = NOVALUE;
    object _31738 = NOVALUE;
    object _31737 = NOVALUE;
    object _31736 = NOVALUE;
    object _31735 = NOVALUE;
    object _31734 = NOVALUE;
    object _15443 = NOVALUE;
    object _15442 = NOVALUE;
    object _15440 = NOVALUE;
    object _15438 = NOVALUE;
    object _15437 = NOVALUE;
    object _15436 = NOVALUE;
    object _15434 = NOVALUE;
    object _15433 = NOVALUE;
    object _15432 = NOVALUE;
    object _15431 = NOVALUE;
    object _15429 = NOVALUE;
    object _15428 = NOVALUE;
    object _15426 = NOVALUE;
    object _15424 = NOVALUE;
    object _15423 = NOVALUE;
    object _15421 = NOVALUE;
    object _15419 = NOVALUE;
    object _15418 = NOVALUE;
    object _15416 = NOVALUE;
    object _15414 = NOVALUE;
    object _15413 = NOVALUE;
    object _15412 = NOVALUE;
    object _15411 = NOVALUE;
    object _15410 = NOVALUE;
    object _15408 = NOVALUE;
    object _15407 = NOVALUE;
    object _15397 = NOVALUE;
    object _15384 = NOVALUE;
    object _15380 = NOVALUE;
    object _15379 = NOVALUE;
    object _15375 = NOVALUE;
    object _15374 = NOVALUE;
    object _15373 = NOVALUE;
    object _15372 = NOVALUE;
    object _15370 = NOVALUE;
    object _15369 = NOVALUE;
    object _15368 = NOVALUE;
    object _15367 = NOVALUE;
    object _15364 = NOVALUE;
    object _15363 = NOVALUE;
    object _15362 = NOVALUE;
    object _15361 = NOVALUE;
    object _15360 = NOVALUE;
    object _15359 = NOVALUE;
    object _15357 = NOVALUE;
    object _15356 = NOVALUE;
    object _15355 = NOVALUE;
    object _15354 = NOVALUE;
    object _15353 = NOVALUE;
    object _15352 = NOVALUE;
    object _15350 = NOVALUE;
    object _15349 = NOVALUE;
    object _15346 = NOVALUE;
    object _15343 = NOVALUE;
    object _15338 = NOVALUE;
    object _15337 = NOVALUE;
    object _15336 = NOVALUE;
    object _15335 = NOVALUE;
    object _15334 = NOVALUE;
    object _15333 = NOVALUE;
    object _15331 = NOVALUE;
    object _15330 = NOVALUE;
    object _15329 = NOVALUE;
    object _15328 = NOVALUE;
    object _15327 = NOVALUE;
    object _15326 = NOVALUE;
    object _15324 = NOVALUE;
    object _15323 = NOVALUE;
    object _15320 = NOVALUE;
    object _15317 = NOVALUE;
    object _15315 = NOVALUE;
    object _15314 = NOVALUE;
    object _15310 = NOVALUE;
    object _15309 = NOVALUE;
    object _15305 = NOVALUE;
    object _15304 = NOVALUE;
    object _15303 = NOVALUE;
    object _15301 = NOVALUE;
    object _15296 = NOVALUE;
    object _15293 = NOVALUE;
    object _15292 = NOVALUE;
    object _15291 = NOVALUE;
    object _15290 = NOVALUE;
    object _15284 = NOVALUE;
    object _15282 = NOVALUE;
    object _15277 = NOVALUE;
    object _15276 = NOVALUE;
    object _15275 = NOVALUE;
    object _15274 = NOVALUE;
    object _15273 = NOVALUE;
    object _15272 = NOVALUE;
    object _15271 = NOVALUE;
    object _15269 = NOVALUE;
    object _15267 = NOVALUE;
    object _15266 = NOVALUE;
    object _15265 = NOVALUE;
    object _15264 = NOVALUE;
    object _15263 = NOVALUE;
    object _15261 = NOVALUE;
    object _15256 = NOVALUE;
    object _15255 = NOVALUE;
    object _15253 = NOVALUE;
    object _15249 = NOVALUE;
    object _15246 = NOVALUE;
    object _15245 = NOVALUE;
    object _15243 = NOVALUE;
    object _15242 = NOVALUE;
    object _15241 = NOVALUE;
    object _15238 = NOVALUE;
    object _15236 = NOVALUE;
    object _15235 = NOVALUE;
    object _15231 = NOVALUE;
    object _15227 = NOVALUE;
    object _15224 = NOVALUE;
    object _15218 = NOVALUE;
    object _15210 = NOVALUE;
    object _15209 = NOVALUE;
    object _15208 = NOVALUE;
    object _15206 = NOVALUE;
    object _15203 = NOVALUE;
    object _15201 = NOVALUE;
    object _15199 = NOVALUE;
    object _15196 = NOVALUE;
    object _15193 = NOVALUE;
    object _15191 = NOVALUE;
    object _15189 = NOVALUE;
    object _15187 = NOVALUE;
    object _15186 = NOVALUE;
    object _15182 = NOVALUE;
    object _15179 = NOVALUE;
    object _15177 = NOVALUE;
    object _15174 = NOVALUE;
    object _15167 = NOVALUE;
    object _15165 = NOVALUE;
    object _15162 = NOVALUE;
    object _15156 = NOVALUE;
    object _15155 = NOVALUE;
    object _15154 = NOVALUE;
    object _15153 = NOVALUE;
    object _15152 = NOVALUE;
    object _15151 = NOVALUE;
    object _15150 = NOVALUE;
    object _15148 = NOVALUE;
    object _15146 = NOVALUE;
    object _15144 = NOVALUE;
    object _15142 = NOVALUE;
    object _15140 = NOVALUE;
    object _15139 = NOVALUE;
    object _15138 = NOVALUE;
    object _15137 = NOVALUE;
    object _15136 = NOVALUE;
    object _15134 = NOVALUE;
    object _15131 = NOVALUE;
    object _15129 = NOVALUE;
    object _15128 = NOVALUE;
    object _15127 = NOVALUE;
    object _15125 = NOVALUE;
    object _15120 = NOVALUE;
    object _15116 = NOVALUE;
    object _15113 = NOVALUE;
    object _15111 = NOVALUE;
    object _15110 = NOVALUE;
    object _15108 = NOVALUE;
    object _15106 = NOVALUE;
    object _15104 = NOVALUE;
    object _15103 = NOVALUE;
    object _15102 = NOVALUE;
    object _15100 = NOVALUE;
    object _15095 = NOVALUE;
    object _15092 = NOVALUE;
    object _15090 = NOVALUE;
    object _15087 = NOVALUE;
    object _15086 = NOVALUE;
    object _15084 = NOVALUE;
    object _15083 = NOVALUE;
    object _15082 = NOVALUE;
    object _15081 = NOVALUE;
    object _15080 = NOVALUE;
    object _15079 = NOVALUE;
    object _15078 = NOVALUE;
    object _15077 = NOVALUE;
    object _15076 = NOVALUE;
    object _15075 = NOVALUE;
    object _15074 = NOVALUE;
    object _15073 = NOVALUE;
    object _15072 = NOVALUE;
    object _15067 = NOVALUE;
    object _15065 = NOVALUE;
    object _15062 = NOVALUE;
    object _15060 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1486		integer is_int, class*/

    /** scanner.e:1487		sequence name*/

    /** scanner.e:1489		while TRUE do*/
L1: 
    if (_9TRUE_446 == 0)
    {
        goto L2; // [12] 3821
    }
    else{
    }

    /** scanner.e:1490			ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1491			while ch = ' ' or ch = '\t' do*/
L3: 
    _15060 = (_ch_27333 == 32);
    if (_15060 != 0) {
        goto L4; // [31] 44
    }
    _15062 = (_ch_27333 == 9);
    if (_15062 == 0)
    {
        DeRef(_15062);
        _15062 = NOVALUE;
        goto L5; // [40] 56
    }
    else{
        DeRef(_15062);
        _15062 = NOVALUE;
    }
L4: 

    /** scanner.e:1492				ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1493			end while*/
    goto L3; // [53] 27
L5: 

    /** scanner.e:1495			class = char_class[ch]*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _class_27345 = (object)*(((s1_ptr)_2)->base + _ch_27333);

    /** scanner.e:1498			if class = LETTER or ch = '_' then*/
    _15065 = (_class_27345 == -2);
    if (_15065 != 0) {
        goto L6; // [72] 85
    }
    _15067 = (_ch_27333 == 95);
    if (_15067 == 0)
    {
        DeRef(_15067);
        _15067 = NOVALUE;
        goto L7; // [81] 1284
    }
    else{
        DeRef(_15067);
        _15067 = NOVALUE;
    }
L6: 

    /** scanner.e:1499				sp = bp*/
    _sp_27334 = _49bp_49265;

    /** scanner.e:1500				pch = ch*/
    _pch_27337 = _ch_27333;

    /** scanner.e:1501				ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1502				if ch = '"' then*/
    if (_ch_27333 != 34)
    goto L8; // [108] 222

    /** scanner.e:1503					switch pch do*/
    _0 = _pch_27337;
    switch ( _0 ){ 

        /** scanner.e:1504						case 'x' then*/
        case 120:

        /** scanner.e:1505							return {STRING, NewStringSym(GetHexString(2))}*/
        _15072 = _61GetHexString(2);
        _15073 = _53NewStringSym(_15072);
        _15072 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503;
        ((intptr_t *)_2)[2] = _15073;
        _15074 = MAKE_SEQ(_1);
        _15073 = NOVALUE;
        DeRef(_i_27336);
        DeRef(_yytext_27339);
        DeRef(_namespaces_27340);
        DeRef(_d_27341);
        DeRef(_tok_27343);
        DeRef(_name_27346);
        DeRef(_15065);
        _15065 = NOVALUE;
        DeRef(_15060);
        _15060 = NOVALUE;
        return _15074;
        goto L9; // [143] 221

        /** scanner.e:1507						case 'u' then*/
        case 117:

        /** scanner.e:1508							return {STRING, NewStringSym(GetHexString(4))}*/
        _15075 = _61GetHexString(4);
        _15076 = _53NewStringSym(_15075);
        _15075 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503;
        ((intptr_t *)_2)[2] = _15076;
        _15077 = MAKE_SEQ(_1);
        _15076 = NOVALUE;
        DeRef(_i_27336);
        DeRef(_yytext_27339);
        DeRef(_namespaces_27340);
        DeRef(_d_27341);
        DeRef(_tok_27343);
        DeRef(_name_27346);
        DeRef(_15065);
        _15065 = NOVALUE;
        DeRef(_15060);
        _15060 = NOVALUE;
        DeRef(_15074);
        _15074 = NOVALUE;
        return _15077;
        goto L9; // [169] 221

        /** scanner.e:1510						case 'U' then*/
        case 85:

        /** scanner.e:1511							return {STRING, NewStringSym(GetHexString(8))}*/
        _15078 = _61GetHexString(8);
        _15079 = _53NewStringSym(_15078);
        _15078 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503;
        ((intptr_t *)_2)[2] = _15079;
        _15080 = MAKE_SEQ(_1);
        _15079 = NOVALUE;
        DeRef(_i_27336);
        DeRef(_yytext_27339);
        DeRef(_namespaces_27340);
        DeRef(_d_27341);
        DeRef(_tok_27343);
        DeRef(_name_27346);
        DeRef(_15065);
        _15065 = NOVALUE;
        DeRef(_15060);
        _15060 = NOVALUE;
        DeRef(_15074);
        _15074 = NOVALUE;
        DeRef(_15077);
        _15077 = NOVALUE;
        return _15080;
        goto L9; // [195] 221

        /** scanner.e:1513						case 'b' then*/
        case 98:

        /** scanner.e:1514							return {STRING, NewStringSym(GetBitString())}*/
        _15081 = _61GetBitString();
        _15082 = _53NewStringSym(_15081);
        _15081 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503;
        ((intptr_t *)_2)[2] = _15082;
        _15083 = MAKE_SEQ(_1);
        _15082 = NOVALUE;
        DeRef(_i_27336);
        DeRef(_yytext_27339);
        DeRef(_namespaces_27340);
        DeRef(_d_27341);
        DeRef(_tok_27343);
        DeRef(_name_27346);
        DeRef(_15065);
        _15065 = NOVALUE;
        DeRef(_15060);
        _15060 = NOVALUE;
        DeRef(_15080);
        _15080 = NOVALUE;
        DeRef(_15074);
        _15074 = NOVALUE;
        DeRef(_15077);
        _15077 = NOVALUE;
        return _15083;
    ;}L9: 
L8: 

    /** scanner.e:1519				while id_char[ch] do*/
LA: 
    _2 = (object)SEQ_PTR(_61id_char_25588);
    _15084 = (object)*(((s1_ptr)_2)->base + _ch_27333);
    if (_15084 == 0)
    {
        _15084 = NOVALUE;
        goto LB; // [233] 248
    }
    else{
        _15084 = NOVALUE;
    }

    /** scanner.e:1520					ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1521				end while*/
    goto LA; // [245] 227
LB: 

    /** scanner.e:1522				yytext = ThisLine[sp-1..bp-2]*/
    _15086 = _sp_27334 - 1;
    if ((object)((uintptr_t)_15086 +(uintptr_t) HIGH_BITS) >= 0){
        _15086 = NewDouble((eudouble)_15086);
    }
    _15087 = _49bp_49265 - 2;
    rhs_slice_target = (object_ptr)&_yytext_27339;
    RHS_Slice(_49ThisLine_49261, _15086, _15087);

    /** scanner.e:1523				ungetch()*/
    _61ungetch();

    /** scanner.e:1525				ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1526				while ch = ' ' or ch = '\t' do*/
LC: 
    _15090 = (_ch_27333 == 32);
    if (_15090 != 0) {
        goto LD; // [287] 300
    }
    _15092 = (_ch_27333 == 9);
    if (_15092 == 0)
    {
        DeRef(_15092);
        _15092 = NOVALUE;
        goto LE; // [296] 312
    }
    else{
        DeRef(_15092);
        _15092 = NOVALUE;
    }
LD: 

    /** scanner.e:1527					ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1528				end while*/
    goto LC; // [309] 283
LE: 

    /** scanner.e:1529				integer is_namespace*/

    /** scanner.e:1531				if might_be_namespace then*/
    if (_61might_be_namespace_27132 == 0)
    {
        goto LF; // [318] 361
    }
    else{
    }

    /** scanner.e:1532					tok = keyfind(yytext, -1, , -1 )*/
    RefDS(_yytext_27339);
    _31740 = _53hashfn(_yytext_27339);
    RefDS(_yytext_27339);
    _0 = _tok_27343;
    _tok_27343 = _53keyfind(_yytext_27339, -1, _12current_file_no_20226, -1, _31740);
    DeRef(_0);
    _31740 = NOVALUE;

    /** scanner.e:1533					is_namespace = tok[T_ID] = NAMESPACE*/
    _2 = (object)SEQ_PTR(_tok_27343);
    _15095 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_15095)) {
        _is_namespace_27405 = (_15095 == 523);
    }
    else {
        _is_namespace_27405 = binary_op(EQUALS, _15095, 523);
    }
    _15095 = NOVALUE;
    if (!IS_ATOM_INT(_is_namespace_27405)) {
        _1 = (object)(DBL_PTR(_is_namespace_27405)->dbl);
        DeRefDS(_is_namespace_27405);
        _is_namespace_27405 = _1;
    }

    /** scanner.e:1534					might_be_namespace = 0*/
    _61might_be_namespace_27132 = 0;
    goto L10; // [358] 384
LF: 

    /** scanner.e:1536					is_namespace = ch = ':'*/
    _is_namespace_27405 = (_ch_27333 == 58);

    /** scanner.e:1537					tok = keyfind(yytext, -1, , is_namespace )*/
    RefDS(_yytext_27339);
    _31739 = _53hashfn(_yytext_27339);
    RefDS(_yytext_27339);
    _0 = _tok_27343;
    _tok_27343 = _53keyfind(_yytext_27339, -1, _12current_file_no_20226, _is_namespace_27405, _31739);
    DeRef(_0);
    _31739 = NOVALUE;
L10: 

    /** scanner.e:1541				if not is_namespace then*/
    if (_is_namespace_27405 != 0)
    goto L11; // [388] 396

    /** scanner.e:1542					ungetch()*/
    _61ungetch();
L11: 

    /** scanner.e:1545				if is_namespace then*/
    if (_is_namespace_27405 == 0)
    {
        goto L12; // [398] 1121
    }
    else{
    }

    /** scanner.e:1547					namespaces = yytext*/
    RefDS(_yytext_27339);
    DeRef(_namespaces_27340);
    _namespaces_27340 = _yytext_27339;

    /** scanner.e:1550					if tok[T_ID] = NAMESPACE then -- known namespace*/
    _2 = (object)SEQ_PTR(_tok_27343);
    _15100 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15100, 523)){
        _15100 = NOVALUE;
        goto L13; // [420] 976
    }
    _15100 = NOVALUE;

    /** scanner.e:1551						set_qualified_fwd( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (object)SEQ_PTR(_tok_27343);
    _15102 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_15102)){
        _15103 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15102)->dbl));
    }
    else{
        _15103 = (object)*(((s1_ptr)_2)->base + _15102);
    }
    _2 = (object)SEQ_PTR(_15103);
    _15104 = (object)*(((s1_ptr)_2)->base + 1);
    _15103 = NOVALUE;
    Ref(_15104);
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_27432);
    _fwd_inlined_set_qualified_fwd_at_441_27432 = _15104;
    _15104 = NOVALUE;
    if (!IS_ATOM_INT(_fwd_inlined_set_qualified_fwd_at_441_27432)) {
        _1 = (object)(DBL_PTR(_fwd_inlined_set_qualified_fwd_at_441_27432)->dbl);
        DeRefDS(_fwd_inlined_set_qualified_fwd_at_441_27432);
        _fwd_inlined_set_qualified_fwd_at_441_27432 = _1;
    }

    /** scanner.e:104		qualified_fwd = fwd*/
    _61qualified_fwd_25612 = _fwd_inlined_set_qualified_fwd_at_441_27432;

    /** scanner.e:105	end procedure*/
    goto L14; // [456] 459
L14: 
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_27432);
    _fwd_inlined_set_qualified_fwd_at_441_27432 = NOVALUE;

    /** scanner.e:1554						ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1555						while ch = ' ' or ch = '\t' do*/
L15: 
    _15106 = (_ch_27333 == 32);
    if (_15106 != 0) {
        goto L16; // [477] 490
    }
    _15108 = (_ch_27333 == 9);
    if (_15108 == 0)
    {
        DeRef(_15108);
        _15108 = NOVALUE;
        goto L17; // [486] 502
    }
    else{
        DeRef(_15108);
        _15108 = NOVALUE;
    }
L16: 

    /** scanner.e:1556							ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1557						end while*/
    goto L15; // [499] 473
L17: 

    /** scanner.e:1558						yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_27339);
    _yytext_27339 = _5;

    /** scanner.e:1559						if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _15110 = (object)*(((s1_ptr)_2)->base + _ch_27333);
    _15111 = (_15110 == -2);
    _15110 = NOVALUE;
    if (_15111 != 0) {
        goto L18; // [523] 536
    }
    _15113 = (_ch_27333 == 95);
    if (_15113 == 0)
    {
        DeRef(_15113);
        _15113 = NOVALUE;
        goto L19; // [532] 589
    }
    else{
        DeRef(_15113);
        _15113 = NOVALUE;
    }
L18: 

    /** scanner.e:1560							yytext &= ch*/
    Append(&_yytext_27339, _yytext_27339, _ch_27333);

    /** scanner.e:1561							ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1562							while id_char[ch] = TRUE do*/
L1A: 
    _2 = (object)SEQ_PTR(_61id_char_25588);
    _15116 = (object)*(((s1_ptr)_2)->base + _ch_27333);
    if (_15116 != _9TRUE_446)
    goto L1B; // [562] 584

    /** scanner.e:1563								yytext &= ch*/
    Append(&_yytext_27339, _yytext_27339, _ch_27333);

    /** scanner.e:1564								ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1565							end while*/
    goto L1A; // [581] 554
L1B: 

    /** scanner.e:1566							ungetch()*/
    _61ungetch();
L19: 

    /** scanner.e:1569						if length(yytext) = 0 then*/
    if (IS_SEQUENCE(_yytext_27339)){
            _15120 = SEQ_PTR(_yytext_27339)->length;
    }
    else {
        _15120 = 1;
    }
    if (_15120 != 0)
    goto L1C; // [594] 608

    /** scanner.e:1570							CompileErr(AN_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_22015);
    _49CompileErr(32, _22015, 0);
L1C: 

    /** scanner.e:1576					    if Parser_mode = PAM_RECORD then*/
    if (_12Parser_mode_20332 != 1)
    goto L1D; // [614] 775

    /** scanner.e:1577			                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_27339);
    Append(&_12Recorded_20333, _12Recorded_20333, _yytext_27339);

    /** scanner.e:1578			                Ns_recorded = append(Ns_recorded,namespaces)*/
    RefDS(_namespaces_27340);
    Append(&_12Ns_recorded_20334, _12Ns_recorded_20334, _namespaces_27340);

    /** scanner.e:1579			                Ns_recorded_sym &= tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_27343);
    _15125 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_12Ns_recorded_sym_20336) && IS_ATOM(_15125)) {
        Ref(_15125);
        Append(&_12Ns_recorded_sym_20336, _12Ns_recorded_sym_20336, _15125);
    }
    else if (IS_ATOM(_12Ns_recorded_sym_20336) && IS_SEQUENCE(_15125)) {
    }
    else {
        Concat((object_ptr)&_12Ns_recorded_sym_20336, _12Ns_recorded_sym_20336, _15125);
    }
    _15125 = NOVALUE;

    /** scanner.e:1580			                prev_Nne = No_new_entry*/
    _prev_Nne_27335 = _53No_new_entry_48001;

    /** scanner.e:1581							No_new_entry = 1*/
    _53No_new_entry_48001 = 1;

    /** scanner.e:1582							tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (object)SEQ_PTR(_tok_27343);
    _15127 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_15127)){
        _15128 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15127)->dbl));
    }
    else{
        _15128 = (object)*(((s1_ptr)_2)->base + _15127);
    }
    _2 = (object)SEQ_PTR(_15128);
    _15129 = (object)*(((s1_ptr)_2)->base + 1);
    _15128 = NOVALUE;
    RefDS(_yytext_27339);
    _31738 = _53hashfn(_yytext_27339);
    RefDS(_yytext_27339);
    Ref(_15129);
    _0 = _tok_27343;
    _tok_27343 = _53keyfind(_yytext_27339, _15129, _12current_file_no_20226, 0, _31738);
    DeRef(_0);
    _15129 = NOVALUE;
    _31738 = NOVALUE;

    /** scanner.e:1583							if tok[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_27343);
    _15131 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15131, 509)){
        _15131 = NOVALUE;
        goto L1E; // [714] 731
    }
    _15131 = NOVALUE;

    /** scanner.e:1584								Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_12Recorded_sym_20335, _12Recorded_sym_20335, 0);
    goto L1F; // [728] 748
L1E: 

    /** scanner.e:1586								Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (object)SEQ_PTR(_tok_27343);
    _15134 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_12Recorded_sym_20335) && IS_ATOM(_15134)) {
        Ref(_15134);
        Append(&_12Recorded_sym_20335, _12Recorded_sym_20335, _15134);
    }
    else if (IS_ATOM(_12Recorded_sym_20335) && IS_SEQUENCE(_15134)) {
    }
    else {
        Concat((object_ptr)&_12Recorded_sym_20335, _12Recorded_sym_20335, _15134);
    }
    _15134 = NOVALUE;
L1F: 

    /** scanner.e:1588			                No_new_entry = prev_Nne*/
    _53No_new_entry_48001 = _prev_Nne_27335;

    /** scanner.e:1589			                return {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_12Recorded_20333)){
            _15136 = SEQ_PTR(_12Recorded_20333)->length;
    }
    else {
        _15136 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508;
    ((intptr_t *)_2)[2] = _15136;
    _15137 = MAKE_SEQ(_1);
    _15136 = NOVALUE;
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15137;
    goto L20; // [772] 917
L1D: 

    /** scanner.e:1591							tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (object)SEQ_PTR(_tok_27343);
    _15138 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_15138)){
        _15139 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15138)->dbl));
    }
    else{
        _15139 = (object)*(((s1_ptr)_2)->base + _15138);
    }
    _2 = (object)SEQ_PTR(_15139);
    _15140 = (object)*(((s1_ptr)_2)->base + 1);
    _15139 = NOVALUE;
    RefDS(_yytext_27339);
    _31737 = _53hashfn(_yytext_27339);
    RefDS(_yytext_27339);
    Ref(_15140);
    _0 = _tok_27343;
    _tok_27343 = _53keyfind(_yytext_27339, _15140, _12current_file_no_20226, 0, _31737);
    DeRef(_0);
    _15140 = NOVALUE;
    _31737 = NOVALUE;

    /** scanner.e:1593							if tok[T_ID] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_27343);
    _15142 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15142, -100)){
        _15142 = NOVALUE;
        goto L21; // [819] 836
    }
    _15142 = NOVALUE;

    /** scanner.e:1594								tok[T_ID] = QUALIFIED_VARIABLE*/
    _2 = (object)SEQ_PTR(_tok_27343);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27343 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 512;
    DeRef(_1);
    goto L22; // [833] 916
L21: 

    /** scanner.e:1595							elsif tok[T_ID] = FUNC then*/
    _2 = (object)SEQ_PTR(_tok_27343);
    _15144 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15144, 501)){
        _15144 = NOVALUE;
        goto L23; // [846] 863
    }
    _15144 = NOVALUE;

    /** scanner.e:1596								tok[T_ID] = QUALIFIED_FUNC*/
    _2 = (object)SEQ_PTR(_tok_27343);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27343 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 520;
    DeRef(_1);
    goto L22; // [860] 916
L23: 

    /** scanner.e:1597							elsif tok[T_ID] = PROC then*/
    _2 = (object)SEQ_PTR(_tok_27343);
    _15146 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15146, 27)){
        _15146 = NOVALUE;
        goto L24; // [873] 890
    }
    _15146 = NOVALUE;

    /** scanner.e:1598								tok[T_ID] = QUALIFIED_PROC*/
    _2 = (object)SEQ_PTR(_tok_27343);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27343 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 521;
    DeRef(_1);
    goto L22; // [887] 916
L24: 

    /** scanner.e:1599							elsif tok[T_ID] = TYPE then*/
    _2 = (object)SEQ_PTR(_tok_27343);
    _15148 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15148, 504)){
        _15148 = NOVALUE;
        goto L25; // [900] 915
    }
    _15148 = NOVALUE;

    /** scanner.e:1600								tok[T_ID] = QUALIFIED_TYPE*/
    _2 = (object)SEQ_PTR(_tok_27343);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27343 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 522;
    DeRef(_1);
L25: 
L22: 
L20: 

    /** scanner.e:1605						if atom( tok[T_SYM] ) and  SymTab[tok[T_SYM]][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok_27343);
    _15150 = (object)*(((s1_ptr)_2)->base + 2);
    _15151 = IS_ATOM(_15150);
    _15150 = NOVALUE;
    if (_15151 == 0) {
        goto L26; // [928] 1271
    }
    _2 = (object)SEQ_PTR(_tok_27343);
    _15153 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_15153)){
        _15154 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15153)->dbl));
    }
    else{
        _15154 = (object)*(((s1_ptr)_2)->base + _15153);
    }
    _2 = (object)SEQ_PTR(_15154);
    _15155 = (object)*(((s1_ptr)_2)->base + 4);
    _15154 = NOVALUE;
    if (IS_ATOM_INT(_15155)) {
        _15156 = (_15155 != 9);
    }
    else {
        _15156 = binary_op(NOTEQ, _15155, 9);
    }
    _15155 = NOVALUE;
    if (_15156 == 0) {
        DeRef(_15156);
        _15156 = NOVALUE;
        goto L26; // [957] 1271
    }
    else {
        if (!IS_ATOM_INT(_15156) && DBL_PTR(_15156)->dbl == 0.0){
            DeRef(_15156);
            _15156 = NOVALUE;
            goto L26; // [957] 1271
        }
        DeRef(_15156);
        _15156 = NOVALUE;
    }
    DeRef(_15156);
    _15156 = NOVALUE;

    /** scanner.e:1606							set_qualified_fwd( -1 )*/

    /** scanner.e:104		qualified_fwd = fwd*/
    _61qualified_fwd_25612 = -1;

    /** scanner.e:105	end procedure*/
    goto L26; // [969] 1271
    goto L26; // [973] 1271
L13: 

    /** scanner.e:1610						ungetch()*/
    _61ungetch();

    /** scanner.e:1611					    if Parser_mode = PAM_RECORD then*/
    if (_12Parser_mode_20332 != 1)
    goto L26; // [986] 1271

    /** scanner.e:1612			                Ns_recorded &= 0*/
    Append(&_12Ns_recorded_20334, _12Ns_recorded_20334, 0);

    /** scanner.e:1613			                Ns_recorded_sym &= 0*/
    Append(&_12Ns_recorded_sym_20336, _12Ns_recorded_sym_20336, 0);

    /** scanner.e:1614			                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_27339);
    Append(&_12Recorded_20333, _12Recorded_20333, _yytext_27339);

    /** scanner.e:1615			                prev_Nne = No_new_entry*/
    _prev_Nne_27335 = _53No_new_entry_48001;

    /** scanner.e:1616							No_new_entry = 1*/
    _53No_new_entry_48001 = 1;

    /** scanner.e:1617							tok = keyfind(yytext, -1)*/
    RefDS(_yytext_27339);
    _31736 = _53hashfn(_yytext_27339);
    RefDS(_yytext_27339);
    _0 = _tok_27343;
    _tok_27343 = _53keyfind(_yytext_27339, -1, _12current_file_no_20226, 0, _31736);
    DeRef(_0);
    _31736 = NOVALUE;

    /** scanner.e:1618							if tok[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_27343);
    _15162 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15162, 509)){
        _15162 = NOVALUE;
        goto L27; // [1062] 1079
    }
    _15162 = NOVALUE;

    /** scanner.e:1619								Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_12Recorded_sym_20335, _12Recorded_sym_20335, 0);
    goto L28; // [1076] 1096
L27: 

    /** scanner.e:1621								Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (object)SEQ_PTR(_tok_27343);
    _15165 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_12Recorded_sym_20335) && IS_ATOM(_15165)) {
        Ref(_15165);
        Append(&_12Recorded_sym_20335, _12Recorded_sym_20335, _15165);
    }
    else if (IS_ATOM(_12Recorded_sym_20335) && IS_SEQUENCE(_15165)) {
    }
    else {
        Concat((object_ptr)&_12Recorded_sym_20335, _12Recorded_sym_20335, _15165);
    }
    _15165 = NOVALUE;
L28: 

    /** scanner.e:1623			                No_new_entry = prev_Nne*/
    _53No_new_entry_48001 = _prev_Nne_27335;

    /** scanner.e:1624			                tok = {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_12Recorded_20333)){
            _15167 = SEQ_PTR(_12Recorded_20333)->length;
    }
    else {
        _15167 = 1;
    }
    DeRef(_tok_27343);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508;
    ((intptr_t *)_2)[2] = _15167;
    _tok_27343 = MAKE_SEQ(_1);
    _15167 = NOVALUE;
    goto L26; // [1118] 1271
L12: 

    /** scanner.e:1628					set_qualified_fwd( -1 )*/

    /** scanner.e:104		qualified_fwd = fwd*/
    _61qualified_fwd_25612 = -1;

    /** scanner.e:105	end procedure*/
    goto L29; // [1130] 1133
L29: 

    /** scanner.e:1629				    if Parser_mode = PAM_RECORD then*/
    if (_12Parser_mode_20332 != 1)
    goto L2A; // [1139] 1270

    /** scanner.e:1630		                Ns_recorded_sym &= 0*/
    Append(&_12Ns_recorded_sym_20336, _12Ns_recorded_sym_20336, 0);

    /** scanner.e:1631							Recorded = append(Recorded, yytext)*/
    RefDS(_yytext_27339);
    Append(&_12Recorded_20333, _12Recorded_20333, _yytext_27339);

    /** scanner.e:1632			                Ns_recorded &= 0*/
    Append(&_12Ns_recorded_20334, _12Ns_recorded_20334, 0);

    /** scanner.e:1633			                prev_Nne = No_new_entry*/
    _prev_Nne_27335 = _53No_new_entry_48001;

    /** scanner.e:1634							No_new_entry = 1*/
    _53No_new_entry_48001 = 1;

    /** scanner.e:1635							tok = keyfind(yytext, -1)*/
    RefDS(_yytext_27339);
    _31735 = _53hashfn(_yytext_27339);
    RefDS(_yytext_27339);
    _0 = _tok_27343;
    _tok_27343 = _53keyfind(_yytext_27339, -1, _12current_file_no_20226, 0, _31735);
    DeRef(_0);
    _31735 = NOVALUE;

    /** scanner.e:1636							if tok[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_27343);
    _15174 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15174, 509)){
        _15174 = NOVALUE;
        goto L2B; // [1215] 1232
    }
    _15174 = NOVALUE;

    /** scanner.e:1637								Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_12Recorded_sym_20335, _12Recorded_sym_20335, 0);
    goto L2C; // [1229] 1249
L2B: 

    /** scanner.e:1639								Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (object)SEQ_PTR(_tok_27343);
    _15177 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_12Recorded_sym_20335) && IS_ATOM(_15177)) {
        Ref(_15177);
        Append(&_12Recorded_sym_20335, _12Recorded_sym_20335, _15177);
    }
    else if (IS_ATOM(_12Recorded_sym_20335) && IS_SEQUENCE(_15177)) {
    }
    else {
        Concat((object_ptr)&_12Recorded_sym_20335, _12Recorded_sym_20335, _15177);
    }
    _15177 = NOVALUE;
L2C: 

    /** scanner.e:1641			                No_new_entry = prev_Nne*/
    _53No_new_entry_48001 = _prev_Nne_27335;

    /** scanner.e:1642		                tok = {RECORDED, length(Recorded)}*/
    if (IS_SEQUENCE(_12Recorded_20333)){
            _15179 = SEQ_PTR(_12Recorded_20333)->length;
    }
    else {
        _15179 = 1;
    }
    DeRef(_tok_27343);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508;
    ((intptr_t *)_2)[2] = _15179;
    _tok_27343 = MAKE_SEQ(_1);
    _15179 = NOVALUE;
L2A: 
L26: 

    /** scanner.e:1646				return tok*/
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_name_27346);
    DeRef(_15111);
    _15111 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _tok_27343;
    goto L1; // [1281] 10
L7: 

    /** scanner.e:1648			elsif class < ILLEGAL_CHAR then*/
    if (_class_27345 >= -20)
    goto L2D; // [1288] 1305

    /** scanner.e:1649				return {class, 0}  -- brackets, punctuation, eof, illegal char etc.*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _class_27345;
    ((intptr_t *)_2)[2] = 0;
    _15182 = MAKE_SEQ(_1);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    DeRef(_15111);
    _15111 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15182;
    goto L1; // [1302] 10
L2D: 

    /** scanner.e:1651			elsif class = ILLEGAL_CHAR then*/
    if (_class_27345 != -20)
    goto L2E; // [1309] 1325

    /** scanner.e:1652				CompileErr(ILLEGAL_CHARACTER_IN_SOURCE)*/
    RefDS(_22015);
    _49CompileErr(101, _22015, 0);
    goto L1; // [1322] 10
L2E: 

    /** scanner.e:1654			elsif class = NEWLINE then*/
    if (_class_27345 != -6)
    goto L2F; // [1329] 1355

    /** scanner.e:1655				if start_include then*/
    if (_61start_include_25580 == 0)
    {
        goto L30; // [1337] 1347
    }
    else{
    }

    /** scanner.e:1656					IncludePush()*/
    _61IncludePush();
    goto L1; // [1344] 10
L30: 

    /** scanner.e:1658					read_line()*/
    _61read_line();
    goto L1; // [1352] 10
L2F: 

    /** scanner.e:1662			elsif class = EQUALS then*/
    if (_class_27345 != 3)
    goto L31; // [1359] 1376

    /** scanner.e:1663				return {class, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _class_27345;
    ((intptr_t *)_2)[2] = 0;
    _15186 = MAKE_SEQ(_1);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    DeRef(_15111);
    _15111 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15186;
    goto L1; // [1373] 10
L31: 

    /** scanner.e:1665			elsif class = DOT or class = DIGIT then*/
    _15187 = (_class_27345 == -3);
    if (_15187 != 0) {
        goto L32; // [1384] 1399
    }
    _15189 = (_class_27345 == -7);
    if (_15189 == 0)
    {
        DeRef(_15189);
        _15189 = NOVALUE;
        goto L33; // [1395] 2195
    }
    else{
        DeRef(_15189);
        _15189 = NOVALUE;
    }
L32: 

    /** scanner.e:1666				integer basetype*/

    /** scanner.e:1667				if class = DOT then*/
    if (_class_27345 != -3)
    goto L34; // [1405] 1439

    /** scanner.e:1668					if getch() = '.' then*/
    _15191 = _61getch();
    if (binary_op_a(NOTEQ, _15191, 46)){
        DeRef(_15191);
        _15191 = NOVALUE;
        goto L35; // [1414] 1433
    }
    DeRef(_15191);
    _15191 = NOVALUE;

    /** scanner.e:1669						return {SLICE, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 513;
    ((intptr_t *)_2)[2] = 0;
    _15193 = MAKE_SEQ(_1);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    DeRef(_15111);
    _15111 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15193;
    goto L36; // [1430] 1438
L35: 

    /** scanner.e:1671						ungetch()*/
    _61ungetch();
L36: 
L34: 

    /** scanner.e:1675				yytext = {ch}*/
    _0 = _yytext_27339;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ch_27333;
    _yytext_27339 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:1676				is_int = (ch != '.')*/
    _is_int_27344 = (_ch_27333 != 46);

    /** scanner.e:1677				basetype = -1 -- default is decimal*/
    _basetype_27641 = -1;

    /** scanner.e:1678				while 1 with entry do*/
    goto L37; // [1458] 1651
L38: 

    /** scanner.e:1679					if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _15196 = (object)*(((s1_ptr)_2)->base + _ch_27333);
    if (_15196 != -7)
    goto L39; // [1471] 1484

    /** scanner.e:1680						yytext &= ch*/
    Append(&_yytext_27339, _yytext_27339, _ch_27333);
    goto L3A; // [1481] 1648
L39: 

    /** scanner.e:1682					elsif equal(yytext, "0") then*/
    if (_yytext_27339 == _12006)
    _15199 = 1;
    else if (IS_ATOM_INT(_yytext_27339) && IS_ATOM_INT(_12006))
    _15199 = 0;
    else
    _15199 = (compare(_yytext_27339, _12006) == 0);
    if (_15199 == 0)
    {
        _15199 = NOVALUE;
        goto L3B; // [1490] 1587
    }
    else{
        _15199 = NOVALUE;
    }

    /** scanner.e:1683						basetype = find(ch, nbasecode)*/
    _basetype_27641 = find_from(_ch_27333, _61nbasecode_27136, 1);

    /** scanner.e:1684						if basetype > length(nbase) then*/
    if (IS_SEQUENCE(_61nbase_27135)){
            _15201 = SEQ_PTR(_61nbase_27135)->length;
    }
    else {
        _15201 = 1;
    }
    if (_basetype_27641 <= _15201)
    goto L3C; // [1505] 1519

    /** scanner.e:1685							basetype -= length(nbase)*/
    if (IS_SEQUENCE(_61nbase_27135)){
            _15203 = SEQ_PTR(_61nbase_27135)->length;
    }
    else {
        _15203 = 1;
    }
    _basetype_27641 = _basetype_27641 - _15203;
    _15203 = NOVALUE;
L3C: 

    /** scanner.e:1688						if basetype = 0 then*/
    if (_basetype_27641 != 0)
    goto L3D; // [1521] 1578

    /** scanner.e:1689							if char_class[ch] = LETTER then*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _15206 = (object)*(((s1_ptr)_2)->base + _ch_27333);
    if (_15206 != -2)
    goto L3E; // [1535] 1568

    /** scanner.e:1690								if ch != 'e' and ch != 'E' then*/
    _15208 = (_ch_27333 != 101);
    if (_15208 == 0) {
        goto L3F; // [1545] 1567
    }
    _15210 = (_ch_27333 != 69);
    if (_15210 == 0)
    {
        DeRef(_15210);
        _15210 = NOVALUE;
        goto L3F; // [1554] 1567
    }
    else{
        DeRef(_15210);
        _15210 = NOVALUE;
    }

    /** scanner.e:1691									CompileErr(INVALID_NUMBER_BASE_SPECIFIER_1, ch)*/
    _49CompileErr(105, _ch_27333, 0);
L3F: 
L3E: 

    /** scanner.e:1695							basetype = -1 -- decimal*/
    _basetype_27641 = -1;

    /** scanner.e:1696							exit*/
    goto L40; // [1575] 1663
L3D: 

    /** scanner.e:1698						yytext &= '0'*/
    Append(&_yytext_27339, _yytext_27339, 48);
    goto L3A; // [1584] 1648
L3B: 

    /** scanner.e:1700					elsif basetype = 4 then -- hexadecimal*/
    if (_basetype_27641 != 4)
    goto L40; // [1589] 1663

    /** scanner.e:1701						integer hdigit*/

    /** scanner.e:1702						hdigit = find(ch, "ABCDEFabcdef")*/
    _hdigit_27682 = find_from(_ch_27333, _15213, 1);

    /** scanner.e:1703						if hdigit = 0 then*/
    if (_hdigit_27682 != 0)
    goto L41; // [1604] 1615

    /** scanner.e:1704							exit*/
    goto L40; // [1612] 1663
L41: 

    /** scanner.e:1706						if hdigit > 6 then*/
    if (_hdigit_27682 <= 6)
    goto L42; // [1617] 1628

    /** scanner.e:1707							hdigit -= 6*/
    _hdigit_27682 = _hdigit_27682 - 6;
L42: 

    /** scanner.e:1709						yytext &= hexasc[hdigit]*/
    _2 = (object)SEQ_PTR(_61hexasc_27138);
    _15218 = (object)*(((s1_ptr)_2)->base + _hdigit_27682);
    if (IS_SEQUENCE(_yytext_27339) && IS_ATOM(_15218)) {
        Ref(_15218);
        Append(&_yytext_27339, _yytext_27339, _15218);
    }
    else if (IS_ATOM(_yytext_27339) && IS_SEQUENCE(_15218)) {
    }
    else {
        Concat((object_ptr)&_yytext_27339, _yytext_27339, _15218);
    }
    _15218 = NOVALUE;
    goto L3A; // [1640] 1648

    /** scanner.e:1712						exit*/
    goto L40; // [1645] 1663
L3A: 

    /** scanner.e:1714				entry*/
L37: 

    /** scanner.e:1715					ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1716				end while*/
    goto L38; // [1660] 1461
L40: 

    /** scanner.e:1718				if ch = '.' then*/
    if (_ch_27333 != 46)
    goto L43; // [1665] 1804

    /** scanner.e:1719					ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1720					if ch = '.' then*/
    if (_ch_27333 != 46)
    goto L44; // [1678] 1689

    /** scanner.e:1722						ungetch()*/
    _61ungetch();
    goto L45; // [1686] 1803
L44: 

    /** scanner.e:1724						is_int = FALSE*/
    _is_int_27344 = _9FALSE_444;

    /** scanner.e:1725						if yytext[1] = '.' then*/
    _2 = (object)SEQ_PTR(_yytext_27339);
    _15224 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15224, 46)){
        _15224 = NOVALUE;
        goto L46; // [1704] 1720
    }
    _15224 = NOVALUE;

    /** scanner.e:1726							CompileErr(ONLY_ONE_DECIMAL_POINT_ALLOWED)*/
    RefDS(_22015);
    _49CompileErr(124, _22015, 0);
    goto L47; // [1717] 1727
L46: 

    /** scanner.e:1728							yytext &= '.'*/
    Append(&_yytext_27339, _yytext_27339, 46);
L47: 

    /** scanner.e:1730						if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _15227 = (object)*(((s1_ptr)_2)->base + _ch_27333);
    if (_15227 != -7)
    goto L48; // [1737] 1792

    /** scanner.e:1731							yytext &= ch*/
    Append(&_yytext_27339, _yytext_27339, _ch_27333);

    /** scanner.e:1732							ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1733							while char_class[ch] = DIGIT do*/
L49: 
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _15231 = (object)*(((s1_ptr)_2)->base + _ch_27333);
    if (_15231 != -7)
    goto L4A; // [1767] 1802

    /** scanner.e:1734								yytext &= ch*/
    Append(&_yytext_27339, _yytext_27339, _ch_27333);

    /** scanner.e:1735								ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1736							end while*/
    goto L49; // [1786] 1759
    goto L4A; // [1789] 1802
L48: 

    /** scanner.e:1738							CompileErr(FRACTIONAL_PART_OF_NUMBER_IS_MISSING)*/
    RefDS(_22015);
    _49CompileErr(94, _22015, 0);
L4A: 
L45: 
L43: 

    /** scanner.e:1743				if basetype = -1 and find(ch, "eE") then*/
    _15235 = (_basetype_27641 == -1);
    if (_15235 == 0) {
        goto L4B; // [1810] 1948
    }
    _15238 = find_from(_ch_27333, _15237, 1);
    if (_15238 == 0)
    {
        _15238 = NOVALUE;
        goto L4B; // [1820] 1948
    }
    else{
        _15238 = NOVALUE;
    }

    /** scanner.e:1744					is_int = FALSE*/
    _is_int_27344 = _9FALSE_444;

    /** scanner.e:1745					yytext &= ch*/
    Append(&_yytext_27339, _yytext_27339, _ch_27333);

    /** scanner.e:1746					ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1747					if ch = '-' or ch = '+' or char_class[ch] = DIGIT then*/
    _15241 = (_ch_27333 == 45);
    if (_15241 != 0) {
        _15242 = 1;
        goto L4C; // [1851] 1863
    }
    _15243 = (_ch_27333 == 43);
    _15242 = (_15243 != 0);
L4C: 
    if (_15242 != 0) {
        goto L4D; // [1863] 1884
    }
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _15245 = (object)*(((s1_ptr)_2)->base + _ch_27333);
    _15246 = (_15245 == -7);
    _15245 = NOVALUE;
    if (_15246 == 0)
    {
        DeRef(_15246);
        _15246 = NOVALUE;
        goto L4E; // [1880] 1893
    }
    else{
        DeRef(_15246);
        _15246 = NOVALUE;
    }
L4D: 

    /** scanner.e:1748						yytext &= ch*/
    Append(&_yytext_27339, _yytext_27339, _ch_27333);
    goto L4F; // [1890] 1903
L4E: 

    /** scanner.e:1750						CompileErr(EXPONENT_NOT_FORMED_CORRECTLY)*/
    RefDS(_22015);
    _49CompileErr(86, _22015, 0);
L4F: 

    /** scanner.e:1752					ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1753					while char_class[ch] = DIGIT do*/
L50: 
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _15249 = (object)*(((s1_ptr)_2)->base + _ch_27333);
    if (_15249 != -7)
    goto L51; // [1923] 1981

    /** scanner.e:1754						yytext &= ch*/
    Append(&_yytext_27339, _yytext_27339, _ch_27333);

    /** scanner.e:1755						ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1756					end while*/
    goto L50; // [1942] 1915
    goto L51; // [1945] 1981
L4B: 

    /** scanner.e:1757				elsif char_class[ch] = LETTER then*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _15253 = (object)*(((s1_ptr)_2)->base + _ch_27333);
    if (_15253 != -2)
    goto L52; // [1958] 1980

    /** scanner.e:1758					CompileErr(PUNCTUATION_MISSING_IN_BETWEEN_NUMBER_AND_1, {{ch}})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ch_27333;
    _15255 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _15255;
    _15256 = MAKE_SEQ(_1);
    _15255 = NOVALUE;
    _49CompileErr(127, _15256, 0);
    _15256 = NOVALUE;
L52: 
L51: 

    /** scanner.e:1761				ungetch()*/
    _61ungetch();

    /** scanner.e:1763				while i != 0 with entry do*/
    goto L53; // [1987] 2006
L54: 
    if (binary_op_a(EQUALS, _i_27336, 0)){
        goto L55; // [1992] 2018
    }

    /** scanner.e:1764					yytext = remove( yytext, i )*/
    {
        s1_ptr assign_space = SEQ_PTR(_yytext_27339);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_27336)) ? _i_27336 : (object)(DBL_PTR(_i_27336)->dbl);
        int stop = (IS_ATOM_INT(_i_27336)) ? _i_27336 : (object)(DBL_PTR(_i_27336)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_yytext_27339), start, &_yytext_27339 );
            }
            else Tail(SEQ_PTR(_yytext_27339), stop+1, &_yytext_27339);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_yytext_27339), start, &_yytext_27339);
        }
        else {
            assign_slice_seq = &assign_space;
            _yytext_27339 = Remove_elements(start, stop, (SEQ_PTR(_yytext_27339)->ref == 1));
        }
    }

    /** scanner.e:1765				  entry*/
L53: 

    /** scanner.e:1766				    i = find('_', yytext)*/
    DeRef(_i_27336);
    _i_27336 = find_from(95, _yytext_27339, 1);

    /** scanner.e:1767				end while*/
    goto L54; // [2015] 1990
L55: 

    /** scanner.e:1769				if is_int then*/
    if (_is_int_27344 == 0)
    {
        goto L56; // [2020] 2092
    }
    else{
    }

    /** scanner.e:1770					if basetype = -1 then*/
    if (_basetype_27641 != -1)
    goto L57; // [2025] 2035

    /** scanner.e:1771						basetype = 3 -- decimal*/
    _basetype_27641 = 3;
L57: 

    /** scanner.e:1773					d = MakeInt(yytext, nbase[basetype])*/
    _2 = (object)SEQ_PTR(_61nbase_27135);
    _15261 = (object)*(((s1_ptr)_2)->base + _basetype_27641);
    RefDS(_yytext_27339);
    Ref(_15261);
    _0 = _d_27341;
    _d_27341 = _61MakeInt(_yytext_27339, _15261);
    DeRef(_0);
    _15261 = NOVALUE;

    /** scanner.e:1774					if is_integer(d) then*/
    Ref(_d_27341);
    _15263 = _12is_integer(_d_27341);
    if (_15263 == 0) {
        DeRef(_15263);
        _15263 = NOVALUE;
        goto L58; // [2052] 2074
    }
    else {
        if (!IS_ATOM_INT(_15263) && DBL_PTR(_15263)->dbl == 0.0){
            DeRef(_15263);
            _15263 = NOVALUE;
            goto L58; // [2052] 2074
        }
        DeRef(_15263);
        _15263 = NOVALUE;
    }
    DeRef(_15263);
    _15263 = NOVALUE;

    /** scanner.e:1775						return {ATOM, NewIntSym(d)}*/
    Ref(_d_27341);
    _15264 = _53NewIntSym(_d_27341);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15264;
    _15265 = MAKE_SEQ(_1);
    _15264 = NOVALUE;
    DeRef(_i_27336);
    DeRefDS(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15265;
    goto L59; // [2071] 2091
L58: 

    /** scanner.e:1777						return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_27341);
    _15266 = _53NewDoubleSym(_d_27341);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15266;
    _15267 = MAKE_SEQ(_1);
    _15266 = NOVALUE;
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15267;
L59: 
L56: 

    /** scanner.e:1782				if basetype != -1 then*/
    if (_basetype_27641 == -1)
    goto L5A; // [2094] 2112

    /** scanner.e:1783					CompileErr(ONLY_INTEGER_LITERALS_CAN_USE_THE_01_FORMAT, nbasecode[basetype])*/
    _2 = (object)SEQ_PTR(_61nbasecode_27136);
    _15269 = (object)*(((s1_ptr)_2)->base + _basetype_27641);
    Ref(_15269);
    _49CompileErr(125, _15269, 0);
    _15269 = NOVALUE;
L5A: 

    /** scanner.e:1787				d = my_sscanf(yytext)*/
    RefDS(_yytext_27339);
    _0 = _d_27341;
    _d_27341 = _61my_sscanf(_yytext_27339);
    DeRef(_0);

    /** scanner.e:1788				if sequence(d) then*/
    _15271 = IS_SEQUENCE(_d_27341);
    if (_15271 == 0)
    {
        _15271 = NOVALUE;
        goto L5B; // [2123] 2138
    }
    else{
        _15271 = NOVALUE;
    }

    /** scanner.e:1789					CompileErr(NUMBER_NOT_FORMED_CORRECTLY)*/
    RefDS(_22015);
    _49CompileErr(121, _22015, 0);
    goto L5C; // [2135] 2190
L5B: 

    /** scanner.e:1790				elsif is_int and d <= TMAXINT_DBL then*/
    if (_is_int_27344 == 0) {
        goto L5D; // [2140] 2173
    }
    if (IS_ATOM_INT(_d_27341) && IS_ATOM_INT(_12TMAXINT_DBL_20059)) {
        _15273 = (_d_27341 <= _12TMAXINT_DBL_20059);
    }
    else {
        _15273 = binary_op(LESSEQ, _d_27341, _12TMAXINT_DBL_20059);
    }
    if (_15273 == 0) {
        DeRef(_15273);
        _15273 = NOVALUE;
        goto L5D; // [2151] 2173
    }
    else {
        if (!IS_ATOM_INT(_15273) && DBL_PTR(_15273)->dbl == 0.0){
            DeRef(_15273);
            _15273 = NOVALUE;
            goto L5D; // [2151] 2173
        }
        DeRef(_15273);
        _15273 = NOVALUE;
    }
    DeRef(_15273);
    _15273 = NOVALUE;

    /** scanner.e:1791					return {ATOM, NewIntSym(d)}  -- 1 to 1.07 billion*/
    Ref(_d_27341);
    _15274 = _53NewIntSym(_d_27341);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15274;
    _15275 = MAKE_SEQ(_1);
    _15274 = NOVALUE;
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15275;
    goto L5C; // [2170] 2190
L5D: 

    /** scanner.e:1793					return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_27341);
    _15276 = _53NewDoubleSym(_d_27341);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15276;
    _15277 = MAKE_SEQ(_1);
    _15276 = NOVALUE;
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15277;
L5C: 
    goto L1; // [2192] 10
L33: 

    /** scanner.e:1797			elsif class = MINUS then*/
    if (_class_27345 != 10)
    goto L5E; // [2199] 2285

    /** scanner.e:1798				ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1799				if ch = '-' then*/
    if (_ch_27333 != 45)
    goto L5F; // [2212] 2238

    /** scanner.e:1801					if start_include then*/
    if (_61start_include_25580 == 0)
    {
        goto L60; // [2220] 2230
    }
    else{
    }

    /** scanner.e:1802						IncludePush()*/
    _61IncludePush();
    goto L1; // [2227] 10
L60: 

    /** scanner.e:1804						read_line()*/
    _61read_line();
    goto L1; // [2235] 10
L5F: 

    /** scanner.e:1806				elsif ch = '=' then*/
    if (_ch_27333 != 61)
    goto L61; // [2240] 2259

    /** scanner.e:1807					return {MINUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 516;
    ((intptr_t *)_2)[2] = 0;
    _15282 = MAKE_SEQ(_1);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15282;
    goto L1; // [2256] 10
L61: 

    /** scanner.e:1809					bp -= 1*/
    _49bp_49265 = _49bp_49265 - 1;

    /** scanner.e:1810					return {MINUS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 10;
    ((intptr_t *)_2)[2] = 0;
    _15284 = MAKE_SEQ(_1);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15284;
    goto L1; // [2282] 10
L5E: 

    /** scanner.e:1812			elsif class = DOUBLE_QUOTE then*/
    if (_class_27345 != -4)
    goto L62; // [2289] 2487

    /** scanner.e:1813				integer fch*/

    /** scanner.e:1814				ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1815				if ch = '"' then*/
    if (_ch_27333 != 34)
    goto L63; // [2304] 2340

    /** scanner.e:1816					fch = getch()*/
    _fch_27822 = _61getch();
    if (!IS_ATOM_INT(_fch_27822)) {
        _1 = (object)(DBL_PTR(_fch_27822)->dbl);
        DeRefDS(_fch_27822);
        _fch_27822 = _1;
    }

    /** scanner.e:1817					if fch = '"' then*/
    if (_fch_27822 != 34)
    goto L64; // [2317] 2334

    /** scanner.e:1819						return ExtendedString( fch )*/
    _15290 = _61ExtendedString(_fch_27822);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15290;
    goto L65; // [2331] 2339
L64: 

    /** scanner.e:1821						ungetch()*/
    _61ungetch();
L65: 
L63: 

    /** scanner.e:1824				yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_27339);
    _yytext_27339 = _5;

    /** scanner.e:1825				while ch != '\n' and ch != '\r' do -- can't be EOF*/
L66: 
    _15291 = (_ch_27333 != 10);
    if (_15291 == 0) {
        goto L67; // [2356] 2437
    }
    _15293 = (_ch_27333 != 13);
    if (_15293 == 0)
    {
        DeRef(_15293);
        _15293 = NOVALUE;
        goto L67; // [2365] 2437
    }
    else{
        DeRef(_15293);
        _15293 = NOVALUE;
    }

    /** scanner.e:1826					if ch = '"' then*/
    if (_ch_27333 != 34)
    goto L68; // [2370] 2381

    /** scanner.e:1827						exit*/
    goto L67; // [2376] 2437
    goto L69; // [2378] 2425
L68: 

    /** scanner.e:1828					elsif ch = '\\' then*/
    if (_ch_27333 != 92)
    goto L6A; // [2383] 2400

    /** scanner.e:1829						yytext &= EscapeChar('"')*/
    _15296 = _61EscapeChar(34);
    if (IS_SEQUENCE(_yytext_27339) && IS_ATOM(_15296)) {
        Ref(_15296);
        Append(&_yytext_27339, _yytext_27339, _15296);
    }
    else if (IS_ATOM(_yytext_27339) && IS_SEQUENCE(_15296)) {
    }
    else {
        Concat((object_ptr)&_yytext_27339, _yytext_27339, _15296);
    }
    DeRef(_15296);
    _15296 = NOVALUE;
    goto L69; // [2397] 2425
L6A: 

    /** scanner.e:1830					elsif ch = '\t' then*/
    if (_ch_27333 != 9)
    goto L6B; // [2402] 2418

    /** scanner.e:1831						CompileErr(MSG_TAB_CHARACTER_FOUND_IN_STRING__USE_T_INSTEAD)*/
    RefDS(_22015);
    _49CompileErr(145, _22015, 0);
    goto L69; // [2415] 2425
L6B: 

    /** scanner.e:1833						yytext &= ch*/
    Append(&_yytext_27339, _yytext_27339, _ch_27333);
L69: 

    /** scanner.e:1835					ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1836				end while*/
    goto L66; // [2434] 2352
L67: 

    /** scanner.e:1837				if ch = '\n' or ch = '\r' then*/
    _15301 = (_ch_27333 == 10);
    if (_15301 != 0) {
        goto L6C; // [2443] 2456
    }
    _15303 = (_ch_27333 == 13);
    if (_15303 == 0)
    {
        DeRef(_15303);
        _15303 = NOVALUE;
        goto L6D; // [2452] 2466
    }
    else{
        DeRef(_15303);
        _15303 = NOVALUE;
    }
L6C: 

    /** scanner.e:1838					CompileErr(END_OF_LINE_REACHED_WITH_NO_CLOSING)*/
    RefDS(_22015);
    _49CompileErr(67, _22015, 0);
L6D: 

    /** scanner.e:1840				return {STRING, NewStringSym(yytext)}*/
    RefDS(_yytext_27339);
    _15304 = _53NewStringSym(_yytext_27339);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 503;
    ((intptr_t *)_2)[2] = _15304;
    _15305 = MAKE_SEQ(_1);
    _15304 = NOVALUE;
    DeRef(_i_27336);
    DeRefDS(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15305;
    goto L1; // [2484] 10
L62: 

    /** scanner.e:1842			elsif class = PLUS then*/
    if (_class_27345 != 11)
    goto L6E; // [2491] 2543

    /** scanner.e:1843				ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1844				if ch = '=' then*/
    if (_ch_27333 != 61)
    goto L6F; // [2504] 2523

    /** scanner.e:1845					return {PLUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 515;
    ((intptr_t *)_2)[2] = 0;
    _15309 = MAKE_SEQ(_1);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15309;
    goto L1; // [2520] 10
L6F: 

    /** scanner.e:1847					ungetch()*/
    _61ungetch();

    /** scanner.e:1848					return {PLUS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 11;
    ((intptr_t *)_2)[2] = 0;
    _15310 = MAKE_SEQ(_1);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15310;
    goto L1; // [2540] 10
L6E: 

    /** scanner.e:1851			elsif class = res:CONCAT then*/
    if (_class_27345 != 15)
    goto L70; // [2545] 2595

    /** scanner.e:1852				ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1853				if ch = '=' then*/
    if (_ch_27333 != 61)
    goto L71; // [2558] 2577

    /** scanner.e:1854					return {CONCAT_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 519;
    ((intptr_t *)_2)[2] = 0;
    _15314 = MAKE_SEQ(_1);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15314;
    goto L1; // [2574] 10
L71: 

    /** scanner.e:1856					ungetch()*/
    _61ungetch();

    /** scanner.e:1857					return {res:CONCAT, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 15;
    ((intptr_t *)_2)[2] = 0;
    _15315 = MAKE_SEQ(_1);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15315;
    goto L1; // [2592] 10
L70: 

    /** scanner.e:1860			elsif class = NUMBER_SIGN then*/
    if (_class_27345 != -11)
    goto L72; // [2599] 3122

    /** scanner.e:1861				i = 0*/
    DeRef(_i_27336);
    _i_27336 = 0;

    /** scanner.e:1862				is_int = -1*/
    _is_int_27344 = -1;

    /** scanner.e:1863				while i < TMAXINT/32 do*/
L73: 
    if (IS_ATOM_INT(_12TMAXINT_20056)) {
        _15317 = (_12TMAXINT_20056 % 32) ? NewDouble((eudouble)_12TMAXINT_20056 / 32) : (_12TMAXINT_20056 / 32);
    }
    else {
        _15317 = NewDouble(DBL_PTR(_12TMAXINT_20056)->dbl / (eudouble)32);
    }
    if (binary_op_a(GREATEREQ, _i_27336, _15317)){
        DeRef(_15317);
        _15317 = NOVALUE;
        goto L74; // [2624] 2788
    }
    DeRef(_15317);
    _15317 = NOVALUE;

    /** scanner.e:1864					ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1865					if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _15320 = (object)*(((s1_ptr)_2)->base + _ch_27333);
    if (_15320 != -7)
    goto L75; // [2645] 2682

    /** scanner.e:1866						if ch != '_' then*/
    if (_ch_27333 == 95)
    goto L73; // [2651] 2618

    /** scanner.e:1867							i = i * 16 + ch - '0'*/
    if (IS_ATOM_INT(_i_27336)) {
        if (_i_27336 == (short)_i_27336){
            _15323 = _i_27336 * 16;
        }
        else{
            _15323 = NewDouble(_i_27336 * (eudouble)16);
        }
    }
    else {
        _15323 = NewDouble(DBL_PTR(_i_27336)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_15323)) {
        _15324 = _15323 + _ch_27333;
        if ((object)((uintptr_t)_15324 + (uintptr_t)HIGH_BITS) >= 0){
            _15324 = NewDouble((eudouble)_15324);
        }
    }
    else {
        _15324 = NewDouble(DBL_PTR(_15323)->dbl + (eudouble)_ch_27333);
    }
    DeRef(_15323);
    _15323 = NOVALUE;
    DeRef(_i_27336);
    if (IS_ATOM_INT(_15324)) {
        _i_27336 = _15324 - 48;
        if ((object)((uintptr_t)_i_27336 +(uintptr_t) HIGH_BITS) >= 0){
            _i_27336 = NewDouble((eudouble)_i_27336);
        }
    }
    else {
        _i_27336 = NewDouble(DBL_PTR(_15324)->dbl - (eudouble)48);
    }
    DeRef(_15324);
    _15324 = NOVALUE;

    /** scanner.e:1868							is_int = TRUE*/
    _is_int_27344 = _9TRUE_446;
    goto L73; // [2679] 2618
L75: 

    /** scanner.e:1870					elsif ch >= 'A' and ch <= 'F' then*/
    _15326 = (_ch_27333 >= 65);
    if (_15326 == 0) {
        goto L76; // [2688] 2730
    }
    _15328 = (_ch_27333 <= 70);
    if (_15328 == 0)
    {
        DeRef(_15328);
        _15328 = NOVALUE;
        goto L76; // [2697] 2730
    }
    else{
        DeRef(_15328);
        _15328 = NOVALUE;
    }

    /** scanner.e:1871						i = (i * 16) + ch - ('A'-10)*/
    if (IS_ATOM_INT(_i_27336)) {
        if (_i_27336 == (short)_i_27336){
            _15329 = _i_27336 * 16;
        }
        else{
            _15329 = NewDouble(_i_27336 * (eudouble)16);
        }
    }
    else {
        _15329 = NewDouble(DBL_PTR(_i_27336)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_15329)) {
        _15330 = _15329 + _ch_27333;
        if ((object)((uintptr_t)_15330 + (uintptr_t)HIGH_BITS) >= 0){
            _15330 = NewDouble((eudouble)_15330);
        }
    }
    else {
        _15330 = NewDouble(DBL_PTR(_15329)->dbl + (eudouble)_ch_27333);
    }
    DeRef(_15329);
    _15329 = NOVALUE;
    _15331 = 55;
    DeRef(_i_27336);
    if (IS_ATOM_INT(_15330)) {
        _i_27336 = _15330 - 55;
        if ((object)((uintptr_t)_i_27336 +(uintptr_t) HIGH_BITS) >= 0){
            _i_27336 = NewDouble((eudouble)_i_27336);
        }
    }
    else {
        _i_27336 = NewDouble(DBL_PTR(_15330)->dbl - (eudouble)55);
    }
    DeRef(_15330);
    _15330 = NOVALUE;
    _15331 = NOVALUE;

    /** scanner.e:1872						is_int = TRUE*/
    _is_int_27344 = _9TRUE_446;
    goto L73; // [2727] 2618
L76: 

    /** scanner.e:1873					elsif ch >= 'a' and ch <= 'f' then*/
    _15333 = (_ch_27333 >= 97);
    if (_15333 == 0) {
        goto L74; // [2736] 2788
    }
    _15335 = (_ch_27333 <= 102);
    if (_15335 == 0)
    {
        DeRef(_15335);
        _15335 = NOVALUE;
        goto L74; // [2745] 2788
    }
    else{
        DeRef(_15335);
        _15335 = NOVALUE;
    }

    /** scanner.e:1874						i = (i * 16) + ch - ('a'-10)*/
    if (IS_ATOM_INT(_i_27336)) {
        if (_i_27336 == (short)_i_27336){
            _15336 = _i_27336 * 16;
        }
        else{
            _15336 = NewDouble(_i_27336 * (eudouble)16);
        }
    }
    else {
        _15336 = NewDouble(DBL_PTR(_i_27336)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_15336)) {
        _15337 = _15336 + _ch_27333;
        if ((object)((uintptr_t)_15337 + (uintptr_t)HIGH_BITS) >= 0){
            _15337 = NewDouble((eudouble)_15337);
        }
    }
    else {
        _15337 = NewDouble(DBL_PTR(_15336)->dbl + (eudouble)_ch_27333);
    }
    DeRef(_15336);
    _15336 = NOVALUE;
    _15338 = 87;
    DeRef(_i_27336);
    if (IS_ATOM_INT(_15337)) {
        _i_27336 = _15337 - 87;
        if ((object)((uintptr_t)_i_27336 +(uintptr_t) HIGH_BITS) >= 0){
            _i_27336 = NewDouble((eudouble)_i_27336);
        }
    }
    else {
        _i_27336 = NewDouble(DBL_PTR(_15337)->dbl - (eudouble)87);
    }
    DeRef(_15337);
    _15337 = NOVALUE;
    _15338 = NOVALUE;

    /** scanner.e:1875						is_int = TRUE*/
    _is_int_27344 = _9TRUE_446;
    goto L73; // [2775] 2618

    /** scanner.e:1877						exit*/
    goto L74; // [2780] 2788

    /** scanner.e:1879				end while*/
    goto L73; // [2785] 2618
L74: 

    /** scanner.e:1881				if is_int = -1 then*/
    if (_is_int_27344 != -1)
    goto L77; // [2790] 2857

    /** scanner.e:1882					if ch = '!' then*/
    if (_ch_27333 != 33)
    goto L78; // [2796] 2844

    /** scanner.e:1883						if line_number > 1 then*/
    if (_12line_number_20227 <= 1)
    goto L79; // [2804] 2818

    /** scanner.e:1884							CompileErr(MSG__MAY_ONLY_BE_ON_THE_FIRST_LINE_OF_A_PROGRAM)*/
    RefDS(_22015);
    _49CompileErr(161, _22015, 0);
L79: 

    /** scanner.e:1887						shebang = ThisLine*/
    Ref(_49ThisLine_49261);
    DeRef(_61shebang_25585);
    _61shebang_25585 = _49ThisLine_49261;

    /** scanner.e:1888						if start_include then*/
    if (_61start_include_25580 == 0)
    {
        goto L7A; // [2829] 2837
    }
    else{
    }

    /** scanner.e:1889							IncludePush()*/
    _61IncludePush();
L7A: 

    /** scanner.e:1891						read_line()*/
    _61read_line();
    goto L1; // [2841] 10
L78: 

    /** scanner.e:1893						CompileErr(HEX_NUMBER_NOT_FORMED_CORRECTLY)*/
    RefDS(_22015);
    _49CompileErr(97, _22015, 0);
    goto L1; // [2854] 10
L77: 

    /** scanner.e:1896					d = i*/
    Ref(_i_27336);
    DeRef(_d_27341);
    _d_27341 = _i_27336;

    /** scanner.e:1897					if i >= TMAXINT/32 then*/
    if (IS_ATOM_INT(_12TMAXINT_20056)) {
        _15343 = (_12TMAXINT_20056 % 32) ? NewDouble((eudouble)_12TMAXINT_20056 / 32) : (_12TMAXINT_20056 / 32);
    }
    else {
        _15343 = NewDouble(DBL_PTR(_12TMAXINT_20056)->dbl / (eudouble)32);
    }
    if (binary_op_a(LESS, _i_27336, _15343)){
        DeRef(_15343);
        _15343 = NOVALUE;
        goto L7B; // [2870] 3036
    }
    DeRef(_15343);
    _15343 = NOVALUE;

    /** scanner.e:1898						is_int = FALSE*/
    _is_int_27344 = _9FALSE_444;

    /** scanner.e:1899						while TRUE do*/
L7C: 
    if (_9TRUE_446 == 0)
    {
        goto L7D; // [2890] 3035
    }
    else{
    }

    /** scanner.e:1900							ch = getch()  -- eventually END_OF_FILE_CHAR or new-line*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1901							if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _15346 = (object)*(((s1_ptr)_2)->base + _ch_27333);
    if (_15346 != -7)
    goto L7E; // [2910] 2938

    /** scanner.e:1902								if ch != '_' then*/
    if (_ch_27333 == 95)
    goto L7C; // [2916] 2888

    /** scanner.e:1903									d = (d * 16) + ch - '0'*/
    if (IS_ATOM_INT(_d_27341)) {
        if (_d_27341 == (short)_d_27341){
            _15349 = _d_27341 * 16;
        }
        else{
            _15349 = NewDouble(_d_27341 * (eudouble)16);
        }
    }
    else {
        _15349 = binary_op(MULTIPLY, _d_27341, 16);
    }
    if (IS_ATOM_INT(_15349)) {
        _15350 = _15349 + _ch_27333;
        if ((object)((uintptr_t)_15350 + (uintptr_t)HIGH_BITS) >= 0){
            _15350 = NewDouble((eudouble)_15350);
        }
    }
    else {
        _15350 = binary_op(PLUS, _15349, _ch_27333);
    }
    DeRef(_15349);
    _15349 = NOVALUE;
    DeRef(_d_27341);
    if (IS_ATOM_INT(_15350)) {
        _d_27341 = _15350 - 48;
        if ((object)((uintptr_t)_d_27341 +(uintptr_t) HIGH_BITS) >= 0){
            _d_27341 = NewDouble((eudouble)_d_27341);
        }
    }
    else {
        _d_27341 = binary_op(MINUS, _15350, 48);
    }
    DeRef(_15350);
    _15350 = NOVALUE;
    goto L7C; // [2935] 2888
L7E: 

    /** scanner.e:1905							elsif ch >= 'A' and ch <= 'F' then*/
    _15352 = (_ch_27333 >= 65);
    if (_15352 == 0) {
        goto L7F; // [2944] 2977
    }
    _15354 = (_ch_27333 <= 70);
    if (_15354 == 0)
    {
        DeRef(_15354);
        _15354 = NOVALUE;
        goto L7F; // [2953] 2977
    }
    else{
        DeRef(_15354);
        _15354 = NOVALUE;
    }

    /** scanner.e:1906								d = (d * 16) + ch - ('A'- 10)*/
    if (IS_ATOM_INT(_d_27341)) {
        if (_d_27341 == (short)_d_27341){
            _15355 = _d_27341 * 16;
        }
        else{
            _15355 = NewDouble(_d_27341 * (eudouble)16);
        }
    }
    else {
        _15355 = binary_op(MULTIPLY, _d_27341, 16);
    }
    if (IS_ATOM_INT(_15355)) {
        _15356 = _15355 + _ch_27333;
        if ((object)((uintptr_t)_15356 + (uintptr_t)HIGH_BITS) >= 0){
            _15356 = NewDouble((eudouble)_15356);
        }
    }
    else {
        _15356 = binary_op(PLUS, _15355, _ch_27333);
    }
    DeRef(_15355);
    _15355 = NOVALUE;
    _15357 = 55;
    DeRef(_d_27341);
    if (IS_ATOM_INT(_15356)) {
        _d_27341 = _15356 - 55;
        if ((object)((uintptr_t)_d_27341 +(uintptr_t) HIGH_BITS) >= 0){
            _d_27341 = NewDouble((eudouble)_d_27341);
        }
    }
    else {
        _d_27341 = binary_op(MINUS, _15356, 55);
    }
    DeRef(_15356);
    _15356 = NOVALUE;
    _15357 = NOVALUE;
    goto L7C; // [2974] 2888
L7F: 

    /** scanner.e:1907							elsif ch >= 'a' and ch <= 'f' then*/
    _15359 = (_ch_27333 >= 97);
    if (_15359 == 0) {
        goto L80; // [2983] 3016
    }
    _15361 = (_ch_27333 <= 102);
    if (_15361 == 0)
    {
        DeRef(_15361);
        _15361 = NOVALUE;
        goto L80; // [2992] 3016
    }
    else{
        DeRef(_15361);
        _15361 = NOVALUE;
    }

    /** scanner.e:1908								d = (d * 16) + ch - ('a'-10)*/
    if (IS_ATOM_INT(_d_27341)) {
        if (_d_27341 == (short)_d_27341){
            _15362 = _d_27341 * 16;
        }
        else{
            _15362 = NewDouble(_d_27341 * (eudouble)16);
        }
    }
    else {
        _15362 = binary_op(MULTIPLY, _d_27341, 16);
    }
    if (IS_ATOM_INT(_15362)) {
        _15363 = _15362 + _ch_27333;
        if ((object)((uintptr_t)_15363 + (uintptr_t)HIGH_BITS) >= 0){
            _15363 = NewDouble((eudouble)_15363);
        }
    }
    else {
        _15363 = binary_op(PLUS, _15362, _ch_27333);
    }
    DeRef(_15362);
    _15362 = NOVALUE;
    _15364 = 87;
    DeRef(_d_27341);
    if (IS_ATOM_INT(_15363)) {
        _d_27341 = _15363 - 87;
        if ((object)((uintptr_t)_d_27341 +(uintptr_t) HIGH_BITS) >= 0){
            _d_27341 = NewDouble((eudouble)_d_27341);
        }
    }
    else {
        _d_27341 = binary_op(MINUS, _15363, 87);
    }
    DeRef(_15363);
    _15363 = NOVALUE;
    _15364 = NOVALUE;
    goto L7C; // [3013] 2888
L80: 

    /** scanner.e:1909							elsif ch = '_' then*/
    if (_ch_27333 != 95)
    goto L7D; // [3018] 3035
    goto L7C; // [3022] 2888

    /** scanner.e:1912								exit*/
    goto L7D; // [3027] 3035

    /** scanner.e:1914						end while*/
    goto L7C; // [3032] 2888
L7D: 
L7B: 

    /** scanner.e:1917					ungetch()*/
    _61ungetch();

    /** scanner.e:1918					if is_int and is_integer(i) then*/
    if (_is_int_27344 == 0) {
        goto L81; // [3042] 3073
    }
    Ref(_i_27336);
    _15368 = _12is_integer(_i_27336);
    if (_15368 == 0) {
        DeRef(_15368);
        _15368 = NOVALUE;
        goto L81; // [3051] 3073
    }
    else {
        if (!IS_ATOM_INT(_15368) && DBL_PTR(_15368)->dbl == 0.0){
            DeRef(_15368);
            _15368 = NOVALUE;
            goto L81; // [3051] 3073
        }
        DeRef(_15368);
        _15368 = NOVALUE;
    }
    DeRef(_15368);
    _15368 = NOVALUE;

    /** scanner.e:1919						return {ATOM, NewIntSym(i)}*/
    Ref(_i_27336);
    _15369 = _53NewIntSym(_i_27336);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15369;
    _15370 = MAKE_SEQ(_1);
    _15369 = NOVALUE;
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15315);
    _15315 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    DeRef(_15352);
    _15352 = NOVALUE;
    _15346 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15326);
    _15326 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15370;
    goto L1; // [3070] 10
L81: 

    /** scanner.e:1921						if d <= TMAXINT_DBL then            -- d is always >= 0*/
    if (binary_op_a(GREATER, _d_27341, _12TMAXINT_DBL_20059)){
        goto L82; // [3077] 3100
    }

    /** scanner.e:1922							return {ATOM, NewIntSym(d)}*/
    Ref(_d_27341);
    _15372 = _53NewIntSym(_d_27341);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15372;
    _15373 = MAKE_SEQ(_1);
    _15372 = NOVALUE;
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15315);
    _15315 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    DeRef(_15352);
    _15352 = NOVALUE;
    _15346 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15370);
    _15370 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15326);
    _15326 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15373;
    goto L1; // [3097] 10
L82: 

    /** scanner.e:1924							return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_27341);
    _15374 = _53NewDoubleSym(_d_27341);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15374;
    _15375 = MAKE_SEQ(_1);
    _15374 = NOVALUE;
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15315);
    _15315 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    DeRef(_15352);
    _15352 = NOVALUE;
    _15346 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15370);
    _15370 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15326);
    _15326 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15375;
    goto L1; // [3119] 10
L72: 

    /** scanner.e:1929			elsif class = res:MULTIPLY then*/
    if (_class_27345 != 13)
    goto L83; // [3124] 3174

    /** scanner.e:1930				ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1931				if ch = '=' then*/
    if (_ch_27333 != 61)
    goto L84; // [3137] 3156

    /** scanner.e:1932					return {MULTIPLY_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 517;
    ((intptr_t *)_2)[2] = 0;
    _15379 = MAKE_SEQ(_1);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15315);
    _15315 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    DeRef(_15352);
    _15352 = NOVALUE;
    _15346 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15370);
    _15370 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15326);
    _15326 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15379;
    goto L1; // [3153] 10
L84: 

    /** scanner.e:1934					ungetch()*/
    _61ungetch();

    /** scanner.e:1935					return {res:MULTIPLY, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 13;
    ((intptr_t *)_2)[2] = 0;
    _15380 = MAKE_SEQ(_1);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15315);
    _15315 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    DeRef(_15352);
    _15352 = NOVALUE;
    _15346 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15370);
    _15370 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15326);
    _15326 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15380;
    goto L1; // [3171] 10
L83: 

    /** scanner.e:1938			elsif class = res:DIVIDE then*/
    if (_class_27345 != 14)
    goto L85; // [3176] 3380

    /** scanner.e:1939				ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1940				if ch = '=' then*/
    if (_ch_27333 != 61)
    goto L86; // [3189] 3208

    /** scanner.e:1941					return {DIVIDE_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 518;
    ((intptr_t *)_2)[2] = 0;
    _15384 = MAKE_SEQ(_1);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15315);
    _15315 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    DeRef(_15352);
    _15352 = NOVALUE;
    _15346 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15370);
    _15370 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15326);
    _15326 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15384;
    goto L1; // [3205] 10
L86: 

    /** scanner.e:1942				elsif ch = '*' then*/
    if (_ch_27333 != 42)
    goto L87; // [3210] 3362

    /** scanner.e:1944					cline = line_number*/
    _cline_27338 = _12line_number_20227;

    /** scanner.e:1945					integer cnest = 1*/
    _cnest_28006 = 1;

    /** scanner.e:1946					while cnest > 0 do*/
L88: 
    if (_cnest_28006 <= 0)
    goto L89; // [3233] 3341

    /** scanner.e:1947						ch = getch()*/
    _ch_27333 = _61getch();
    if (!IS_ATOM_INT(_ch_27333)) {
        _1 = (object)(DBL_PTR(_ch_27333)->dbl);
        DeRefDS(_ch_27333);
        _ch_27333 = _1;
    }

    /** scanner.e:1948						switch ch do*/
    _0 = _ch_27333;
    switch ( _0 ){ 

        /** scanner.e:1949							case  END_OF_FILE_CHAR then*/
        case 26:

        /** scanner.e:1950								exit*/
        goto L89; // [3257] 3341
        goto L88; // [3259] 3233

        /** scanner.e:1952							case '\n' then*/
        case 10:

        /** scanner.e:1953								read_line()*/
        _61read_line();
        goto L88; // [3269] 3233

        /** scanner.e:1955							case '*' then*/
        case 42:

        /** scanner.e:1956								ch = getch()*/
        _ch_27333 = _61getch();
        if (!IS_ATOM_INT(_ch_27333)) {
            _1 = (object)(DBL_PTR(_ch_27333)->dbl);
            DeRefDS(_ch_27333);
            _ch_27333 = _1;
        }

        /** scanner.e:1957								if ch = '/' then*/
        if (_ch_27333 != 47)
        goto L8A; // [3284] 3297

        /** scanner.e:1958									cnest -= 1*/
        _cnest_28006 = _cnest_28006 - 1;
        goto L88; // [3294] 3233
L8A: 

        /** scanner.e:1960									ungetch()*/
        _61ungetch();
        goto L88; // [3302] 3233

        /** scanner.e:1963							case '/' then*/
        case 47:

        /** scanner.e:1964								ch = getch()*/
        _ch_27333 = _61getch();
        if (!IS_ATOM_INT(_ch_27333)) {
            _1 = (object)(DBL_PTR(_ch_27333)->dbl);
            DeRefDS(_ch_27333);
            _ch_27333 = _1;
        }

        /** scanner.e:1965								if ch = '*' then*/
        if (_ch_27333 != 42)
        goto L8B; // [3317] 3330

        /** scanner.e:1966									cnest += 1*/
        _cnest_28006 = _cnest_28006 + 1;
        goto L8C; // [3327] 3335
L8B: 

        /** scanner.e:1968									ungetch()*/
        _61ungetch();
L8C: 
    ;}
    /** scanner.e:1972					end while*/
    goto L88; // [3338] 3233
L89: 

    /** scanner.e:1974					if cnest > 0 then*/
    if (_cnest_28006 <= 0)
    goto L8D; // [3343] 3357

    /** scanner.e:1975						CompileErr(BLOCK_COMMENT_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _49CompileErr(42, _cline_27338, 0);
L8D: 
    goto L1; // [3359] 10
L87: 

    /** scanner.e:1978					ungetch()*/
    _61ungetch();

    /** scanner.e:1979					return {res:DIVIDE, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 14;
    ((intptr_t *)_2)[2] = 0;
    _15397 = MAKE_SEQ(_1);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15315);
    _15315 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    DeRef(_15352);
    _15352 = NOVALUE;
    _15346 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15370);
    _15370 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15326);
    _15326 = NOVALUE;
    DeRef(_15384);
    _15384 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15397;
    goto L1; // [3377] 10
L85: 

    /** scanner.e:1981			elsif class = SINGLE_QUOTE then*/
    if (_class_27345 != -5)
    goto L8E; // [3384] 3534

    /** scanner.e:1982				atom ach = getch()*/
    _0 = _ach_28036;
    _ach_28036 = _61getch();
    DeRef(_0);

    /** scanner.e:1983				if ach = '\\' then*/
    if (binary_op_a(NOTEQ, _ach_28036, 92)){
        goto L8F; // [3395] 3408
    }

    /** scanner.e:1984					ach = EscapeChar('\'')*/
    _0 = _ach_28036;
    _ach_28036 = _61EscapeChar(39);
    DeRef(_0);
    goto L90; // [3405] 3465
L8F: 

    /** scanner.e:1985				elsif ach = '\t' then*/
    if (binary_op_a(NOTEQ, _ach_28036, 9)){
        goto L91; // [3410] 3426
    }

    /** scanner.e:1986					CompileErr(MSG_TAB_CHARACTER_FOUND_IN_STRING__USE_T_INSTEAD)*/
    RefDS(_22015);
    _49CompileErr(145, _22015, 0);
    goto L90; // [3423] 3465
L91: 

    /** scanner.e:1987				elsif ach = '\'' then*/
    if (binary_op_a(NOTEQ, _ach_28036, 39)){
        goto L92; // [3428] 3444
    }

    /** scanner.e:1988					CompileErr(SINGLEQUOTE_CHARACTER_IS_EMPTY)*/
    RefDS(_22015);
    _49CompileErr(137, _22015, 0);
    goto L90; // [3441] 3465
L92: 

    /** scanner.e:1989				elsif ach = '\n' then*/
    if (binary_op_a(NOTEQ, _ach_28036, 10)){
        goto L93; // [3446] 3464
    }

    /** scanner.e:1990					CompileErr(EXPECTED_1_NOT_2, {"character", "end of line"})*/
    RefDS(_15406);
    RefDS(_15405);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _15405;
    ((intptr_t *)_2)[2] = _15406;
    _15407 = MAKE_SEQ(_1);
    _49CompileErr(68, _15407, 0);
    _15407 = NOVALUE;
L93: 
L90: 

    /** scanner.e:1992				if getch() != '\'' then*/
    _15408 = _61getch();
    if (binary_op_a(EQUALS, _15408, 39)){
        DeRef(_15408);
        _15408 = NOVALUE;
        goto L94; // [3470] 3484
    }
    DeRef(_15408);
    _15408 = NOVALUE;

    /** scanner.e:1993					CompileErr(CHARACTER_CONSTANT_IS_MISSING_A_CLOSING)*/
    RefDS(_22015);
    _49CompileErr(56, _22015, 0);
L94: 

    /** scanner.e:1995				if is_integer(ach) then*/
    Ref(_ach_28036);
    _15410 = _12is_integer(_ach_28036);
    if (_15410 == 0) {
        DeRef(_15410);
        _15410 = NOVALUE;
        goto L95; // [3490] 3512
    }
    else {
        if (!IS_ATOM_INT(_15410) && DBL_PTR(_15410)->dbl == 0.0){
            DeRef(_15410);
            _15410 = NOVALUE;
            goto L95; // [3490] 3512
        }
        DeRef(_15410);
        _15410 = NOVALUE;
    }
    DeRef(_15410);
    _15410 = NOVALUE;

    /** scanner.e:1996					return {ATOM, NewIntSym(ach)}*/
    Ref(_ach_28036);
    _15411 = _53NewIntSym(_ach_28036);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15411;
    _15412 = MAKE_SEQ(_1);
    _15411 = NOVALUE;
    DeRef(_ach_28036);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15315);
    _15315 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15397);
    _15397 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    DeRef(_15352);
    _15352 = NOVALUE;
    _15346 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15370);
    _15370 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15326);
    _15326 = NOVALUE;
    DeRef(_15384);
    _15384 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15412;
    goto L96; // [3509] 3529
L95: 

    /** scanner.e:1998					return {ATOM, NewDoubleSym(ach)}*/
    Ref(_ach_28036);
    _15413 = _53NewDoubleSym(_ach_28036);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15413;
    _15414 = MAKE_SEQ(_1);
    _15413 = NOVALUE;
    DeRef(_ach_28036);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15315);
    _15315 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15397);
    _15397 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15412);
    _15412 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    DeRef(_15352);
    _15352 = NOVALUE;
    _15346 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15370);
    _15370 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15326);
    _15326 = NOVALUE;
    DeRef(_15384);
    _15384 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15414;
L96: 
    DeRef(_ach_28036);
    _ach_28036 = NOVALUE;
    goto L1; // [3531] 10
L8E: 

    /** scanner.e:2001			elsif class = LESS then*/
    if (_class_27345 != 1)
    goto L97; // [3538] 3586

    /** scanner.e:2002				if getch() = '=' then*/
    _15416 = _61getch();
    if (binary_op_a(NOTEQ, _15416, 61)){
        DeRef(_15416);
        _15416 = NOVALUE;
        goto L98; // [3547] 3566
    }
    DeRef(_15416);
    _15416 = NOVALUE;

    /** scanner.e:2003					return {LESSEQ, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 5;
    ((intptr_t *)_2)[2] = 0;
    _15418 = MAKE_SEQ(_1);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15315);
    _15315 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15397);
    _15397 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15412);
    _15412 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    DeRef(_15352);
    _15352 = NOVALUE;
    _15346 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15370);
    _15370 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15326);
    _15326 = NOVALUE;
    DeRef(_15384);
    _15384 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15418;
    goto L1; // [3563] 10
L98: 

    /** scanner.e:2005					ungetch()*/
    _61ungetch();

    /** scanner.e:2006					return {LESS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _15419 = MAKE_SEQ(_1);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    DeRef(_15418);
    _15418 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15315);
    _15315 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15397);
    _15397 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15412);
    _15412 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    DeRef(_15352);
    _15352 = NOVALUE;
    _15346 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15370);
    _15370 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15326);
    _15326 = NOVALUE;
    DeRef(_15384);
    _15384 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15419;
    goto L1; // [3583] 10
L97: 

    /** scanner.e:2009			elsif class = GREATER then*/
    if (_class_27345 != 6)
    goto L99; // [3590] 3638

    /** scanner.e:2010				if getch() = '=' then*/
    _15421 = _61getch();
    if (binary_op_a(NOTEQ, _15421, 61)){
        DeRef(_15421);
        _15421 = NOVALUE;
        goto L9A; // [3599] 3618
    }
    DeRef(_15421);
    _15421 = NOVALUE;

    /** scanner.e:2011					return {GREATEREQ, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 2;
    ((intptr_t *)_2)[2] = 0;
    _15423 = MAKE_SEQ(_1);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    DeRef(_15418);
    _15418 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15315);
    _15315 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15397);
    _15397 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15412);
    _15412 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    DeRef(_15352);
    _15352 = NOVALUE;
    DeRef(_15419);
    _15419 = NOVALUE;
    _15346 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15370);
    _15370 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15326);
    _15326 = NOVALUE;
    DeRef(_15384);
    _15384 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15423;
    goto L1; // [3615] 10
L9A: 

    /** scanner.e:2013					ungetch()*/
    _61ungetch();

    /** scanner.e:2014					return {GREATER, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 6;
    ((intptr_t *)_2)[2] = 0;
    _15424 = MAKE_SEQ(_1);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    DeRef(_15418);
    _15418 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15423);
    _15423 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15315);
    _15315 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15397);
    _15397 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15412);
    _15412 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    DeRef(_15352);
    _15352 = NOVALUE;
    DeRef(_15419);
    _15419 = NOVALUE;
    _15346 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15370);
    _15370 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15326);
    _15326 = NOVALUE;
    DeRef(_15384);
    _15384 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15424;
    goto L1; // [3635] 10
L99: 

    /** scanner.e:2017			elsif class = BANG then*/
    if (_class_27345 != -1)
    goto L9B; // [3642] 3690

    /** scanner.e:2018				if getch() = '=' then*/
    _15426 = _61getch();
    if (binary_op_a(NOTEQ, _15426, 61)){
        DeRef(_15426);
        _15426 = NOVALUE;
        goto L9C; // [3651] 3670
    }
    DeRef(_15426);
    _15426 = NOVALUE;

    /** scanner.e:2019					return {NOTEQ, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = 0;
    _15428 = MAKE_SEQ(_1);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    DeRef(_15418);
    _15418 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15423);
    _15423 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15315);
    _15315 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15397);
    _15397 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15424);
    _15424 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15412);
    _15412 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    DeRef(_15352);
    _15352 = NOVALUE;
    DeRef(_15419);
    _15419 = NOVALUE;
    _15346 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15370);
    _15370 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15326);
    _15326 = NOVALUE;
    DeRef(_15384);
    _15384 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15428;
    goto L1; // [3667] 10
L9C: 

    /** scanner.e:2021					ungetch()*/
    _61ungetch();

    /** scanner.e:2022					return {BANG, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = 0;
    _15429 = MAKE_SEQ(_1);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    DeRef(_15418);
    _15418 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15423);
    _15423 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15315);
    _15315 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15397);
    _15397 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15424);
    _15424 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15412);
    _15412 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    DeRef(_15352);
    _15352 = NOVALUE;
    DeRef(_15419);
    _15419 = NOVALUE;
    _15346 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15370);
    _15370 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15326);
    _15326 = NOVALUE;
    DeRef(_15384);
    _15384 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    return _15429;
    goto L1; // [3687] 10
L9B: 

    /** scanner.e:2025			elsif class = KEYWORD then*/
    if (_class_27345 != -10)
    goto L9D; // [3694] 3727

    /** scanner.e:2026				return {keylist[ch - KEYWORD_BASE][K_TOKEN], 0}*/
    _15431 = _ch_27333 - 128;
    _2 = (object)SEQ_PTR(_62keylist_23148);
    _15432 = (object)*(((s1_ptr)_2)->base + _15431);
    _2 = (object)SEQ_PTR(_15432);
    _15433 = (object)*(((s1_ptr)_2)->base + 3);
    _15432 = NOVALUE;
    Ref(_15433);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _15433;
    ((intptr_t *)_2)[2] = 0;
    _15434 = MAKE_SEQ(_1);
    _15433 = NOVALUE;
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    DeRef(_15418);
    _15418 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15423);
    _15423 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15315);
    _15315 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15397);
    _15397 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15424);
    _15424 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15412);
    _15412 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    DeRef(_15352);
    _15352 = NOVALUE;
    DeRef(_15419);
    _15419 = NOVALUE;
    _15346 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15370);
    _15370 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15429);
    _15429 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15326);
    _15326 = NOVALUE;
    DeRef(_15384);
    _15384 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    _15431 = NOVALUE;
    return _15434;
    goto L1; // [3724] 10
L9D: 

    /** scanner.e:2028			elsif class = BUILTIN then*/
    if (_class_27345 != -9)
    goto L9E; // [3731] 3784

    /** scanner.e:2029				name = keylist[ch - BUILTIN_BASE + NUM_KEYWORDS][K_NAME]*/
    _15436 = _ch_27333 - 170;
    if ((object)((uintptr_t)_15436 +(uintptr_t) HIGH_BITS) >= 0){
        _15436 = NewDouble((eudouble)_15436);
    }
    if (IS_ATOM_INT(_15436)) {
        _15437 = _15436 + 24;
    }
    else {
        _15437 = NewDouble(DBL_PTR(_15436)->dbl + (eudouble)24);
    }
    DeRef(_15436);
    _15436 = NOVALUE;
    _2 = (object)SEQ_PTR(_62keylist_23148);
    if (!IS_ATOM_INT(_15437)){
        _15438 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15437)->dbl));
    }
    else{
        _15438 = (object)*(((s1_ptr)_2)->base + _15437);
    }
    DeRef(_name_27346);
    _2 = (object)SEQ_PTR(_15438);
    _name_27346 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_name_27346);
    _15438 = NOVALUE;

    /** scanner.e:2030				return keyfind(name, -1)*/
    RefDS(_name_27346);
    _31734 = _53hashfn(_name_27346);
    RefDS(_name_27346);
    _15440 = _53keyfind(_name_27346, -1, _12current_file_no_20226, 0, _31734);
    _31734 = NOVALUE;
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRefDS(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    DeRef(_15418);
    _15418 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15423);
    _15423 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15437);
    _15437 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15315);
    _15315 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15397);
    _15397 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15424);
    _15424 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15412);
    _15412 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    DeRef(_15352);
    _15352 = NOVALUE;
    DeRef(_15419);
    _15419 = NOVALUE;
    _15346 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15370);
    _15370 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15429);
    _15429 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15326);
    _15326 = NOVALUE;
    DeRef(_15384);
    _15384 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    DeRef(_15431);
    _15431 = NOVALUE;
    return _15440;
    goto L1; // [3781] 10
L9E: 

    /** scanner.e:2032			elsif class = BACK_QUOTE then*/
    if (_class_27345 != -12)
    goto L9F; // [3788] 3805

    /** scanner.e:2033				return ExtendedString( '`' )*/
    _15442 = _61ExtendedString(96);
    DeRef(_i_27336);
    DeRef(_yytext_27339);
    DeRef(_namespaces_27340);
    DeRef(_d_27341);
    DeRef(_tok_27343);
    DeRef(_name_27346);
    _15206 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;
    DeRef(_15282);
    _15282 = NOVALUE;
    DeRef(_15284);
    _15284 = NOVALUE;
    _15153 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    DeRef(_15418);
    _15418 = NOVALUE;
    DeRef(_15083);
    _15083 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15187);
    _15187 = NOVALUE;
    DeRef(_15301);
    _15301 = NOVALUE;
    DeRef(_15423);
    _15423 = NOVALUE;
    DeRef(_15333);
    _15333 = NOVALUE;
    DeRef(_15137);
    _15137 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15086);
    _15086 = NOVALUE;
    DeRef(_15310);
    _15310 = NOVALUE;
    DeRef(_15437);
    _15437 = NOVALUE;
    DeRef(_15314);
    _15314 = NOVALUE;
    DeRef(_15235);
    _15235 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    _15231 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15414);
    _15414 = NOVALUE;
    DeRef(_15193);
    _15193 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15208);
    _15208 = NOVALUE;
    _15249 = NOVALUE;
    _15227 = NOVALUE;
    _15116 = NOVALUE;
    DeRef(_15315);
    _15315 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15065);
    _15065 = NOVALUE;
    DeRef(_15397);
    _15397 = NOVALUE;
    DeRef(_15060);
    _15060 = NOVALUE;
    DeRef(_15424);
    _15424 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15186);
    _15186 = NOVALUE;
    _15253 = NOVALUE;
    DeRef(_15412);
    _15412 = NOVALUE;
    DeRef(_15182);
    _15182 = NOVALUE;
    DeRef(_15352);
    _15352 = NOVALUE;
    DeRef(_15419);
    _15419 = NOVALUE;
    _15346 = NOVALUE;
    DeRef(_15359);
    _15359 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15138 = NOVALUE;
    DeRef(_15370);
    _15370 = NOVALUE;
    DeRef(_15275);
    _15275 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    DeRef(_15265);
    _15265 = NOVALUE;
    DeRef(_15429);
    _15429 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15080);
    _15080 = NOVALUE;
    _15196 = NOVALUE;
    DeRef(_15440);
    _15440 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15127 = NOVALUE;
    _15102 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15326);
    _15326 = NOVALUE;
    DeRef(_15384);
    _15384 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    DeRef(_15106);
    _15106 = NOVALUE;
    DeRef(_15077);
    _15077 = NOVALUE;
    DeRef(_15431);
    _15431 = NOVALUE;
    return _15442;
    goto L1; // [3802] 10
L9F: 

    /** scanner.e:2036				InternalErr(268, {class})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _class_27345;
    _15443 = MAKE_SEQ(_1);
    _49InternalErr(268, _15443);
    _15443 = NOVALUE;

    /** scanner.e:2039	   end while*/
    goto L1; // [3818] 10
L2: 
    ;
}


void _61eu_namespace()
{
    object _eu_tok_28138 = NOVALUE;
    object _eu_ns_28140 = NOVALUE;
    object _31733 = NOVALUE;
    object _31732 = NOVALUE;
    object _15452 = NOVALUE;
    object _15450 = NOVALUE;
    object _15448 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:2047		eu_tok = keyfind("eu", -1, , 1)*/
    RefDS(_15446);
    _31732 = _15446;
    _31733 = _53hashfn(_31732);
    _31732 = NOVALUE;
    RefDS(_15446);
    _0 = _eu_tok_28138;
    _eu_tok_28138 = _53keyfind(_15446, -1, _12current_file_no_20226, 1, _31733);
    DeRef(_0);
    _31733 = NOVALUE;

    /** scanner.e:2050		eu_ns  = NameSpace_declaration(eu_tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_eu_tok_28138);
    _15448 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_15448);
    _eu_ns_28140 = _61NameSpace_declaration(_15448);
    _15448 = NOVALUE;
    if (!IS_ATOM_INT(_eu_ns_28140)) {
        _1 = (object)(DBL_PTR(_eu_ns_28140)->dbl);
        DeRefDS(_eu_ns_28140);
        _eu_ns_28140 = _1;
    }

    /** scanner.e:2051		SymTab[eu_ns][S_OBJ] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_eu_ns_28140 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _15450 = NOVALUE;

    /** scanner.e:2052		SymTab[eu_ns][S_SCOPE] = SC_GLOBAL*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_eu_ns_28140 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 6;
    DeRef(_1);
    _15452 = NOVALUE;

    /** scanner.e:2053	end procedure*/
    DeRef(_eu_tok_28138);
    return;
    ;
}


object _61StringToken(object _pDelims_28158)
{
    object _ch_28159 = NOVALUE;
    object _m_28160 = NOVALUE;
    object _gtext_28161 = NOVALUE;
    object _level_28192 = NOVALUE;
    object _15491 = NOVALUE;
    object _15489 = NOVALUE;
    object _15487 = NOVALUE;
    object _15468 = NOVALUE;
    object _15467 = NOVALUE;
    object _15461 = NOVALUE;
    object _15459 = NOVALUE;
    object _15457 = NOVALUE;
    object _15455 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2064		ch = getch()*/
    _ch_28159 = _61getch();
    if (!IS_ATOM_INT(_ch_28159)) {
        _1 = (object)(DBL_PTR(_ch_28159)->dbl);
        DeRefDS(_ch_28159);
        _ch_28159 = _1;
    }

    /** scanner.e:2065		while ch = ' ' or ch = '\t' do*/
L1: 
    _15455 = (_ch_28159 == 32);
    if (_15455 != 0) {
        goto L2; // [19] 32
    }
    _15457 = (_ch_28159 == 9);
    if (_15457 == 0)
    {
        DeRef(_15457);
        _15457 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_15457);
        _15457 = NOVALUE;
    }
L2: 

    /** scanner.e:2066			ch = getch()*/
    _ch_28159 = _61getch();
    if (!IS_ATOM_INT(_ch_28159)) {
        _1 = (object)(DBL_PTR(_ch_28159)->dbl);
        DeRefDS(_ch_28159);
        _ch_28159 = _1;
    }

    /** scanner.e:2067		end while*/
    goto L1; // [41] 15
L3: 

    /** scanner.e:2069		pDelims &= {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 32;
    ((intptr_t*)_2)[2] = 9;
    ((intptr_t*)_2)[3] = 10;
    ((intptr_t*)_2)[4] = 13;
    ((intptr_t*)_2)[5] = 26;
    _15459 = MAKE_SEQ(_1);
    Concat((object_ptr)&_pDelims_28158, _pDelims_28158, _15459);
    DeRefDS(_15459);
    _15459 = NOVALUE;

    /** scanner.e:2070		gtext = ""*/
    RefDS(_5);
    DeRefi(_gtext_28161);
    _gtext_28161 = _5;

    /** scanner.e:2071		while not find(ch,  pDelims) label "top" do*/
L4: 
    _15461 = find_from(_ch_28159, _pDelims_28158, 1);
    if (_15461 != 0)
    goto L5; // [77] 391
    _15461 = NOVALUE;

    /** scanner.e:2072			if ch = '-' then*/
    if (_ch_28159 != 45)
    goto L6; // [82] 145

    /** scanner.e:2073				ch = getch()*/
    _ch_28159 = _61getch();
    if (!IS_ATOM_INT(_ch_28159)) {
        _1 = (object)(DBL_PTR(_ch_28159)->dbl);
        DeRefDS(_ch_28159);
        _ch_28159 = _1;
    }

    /** scanner.e:2074				if ch = '-' then*/
    if (_ch_28159 != 45)
    goto L7; // [95] 137

    /** scanner.e:2075					while not find(ch, {'\n', END_OF_FILE_CHAR}) do*/
L8: 
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 10;
    ((intptr_t *)_2)[2] = 26;
    _15467 = MAKE_SEQ(_1);
    _15468 = find_from(_ch_28159, _15467, 1);
    DeRefDS(_15467);
    _15467 = NOVALUE;
    if (_15468 != 0)
    goto L5; // [115] 391
    _15468 = NOVALUE;

    /** scanner.e:2076						ch = getch()*/
    _ch_28159 = _61getch();
    if (!IS_ATOM_INT(_ch_28159)) {
        _1 = (object)(DBL_PTR(_ch_28159)->dbl);
        DeRefDS(_ch_28159);
        _ch_28159 = _1;
    }

    /** scanner.e:2077					end while*/
    goto L8; // [127] 104

    /** scanner.e:2078					exit*/
    goto L5; // [132] 391
    goto L9; // [134] 373
L7: 

    /** scanner.e:2080					ungetch()*/
    _61ungetch();
    goto L9; // [142] 373
L6: 

    /** scanner.e:2082			elsif ch = '/' then*/
    if (_ch_28159 != 47)
    goto LA; // [147] 372

    /** scanner.e:2083				ch = getch()*/
    _ch_28159 = _61getch();
    if (!IS_ATOM_INT(_ch_28159)) {
        _1 = (object)(DBL_PTR(_ch_28159)->dbl);
        DeRefDS(_ch_28159);
        _ch_28159 = _1;
    }

    /** scanner.e:2084				if ch = '*' then*/
    if (_ch_28159 != 42)
    goto LB; // [160] 361

    /** scanner.e:2085					integer level = 1*/
    _level_28192 = 1;

    /** scanner.e:2086					while level > 0 do*/
LC: 
    if (_level_28192 <= 0)
    goto LD; // [174] 293

    /** scanner.e:2087						ch = getch()*/
    _ch_28159 = _61getch();
    if (!IS_ATOM_INT(_ch_28159)) {
        _1 = (object)(DBL_PTR(_ch_28159)->dbl);
        DeRefDS(_ch_28159);
        _ch_28159 = _1;
    }

    /** scanner.e:2088						if ch = '/' then*/
    if (_ch_28159 != 47)
    goto LE; // [187] 221

    /** scanner.e:2089							ch = getch()*/
    _ch_28159 = _61getch();
    if (!IS_ATOM_INT(_ch_28159)) {
        _1 = (object)(DBL_PTR(_ch_28159)->dbl);
        DeRefDS(_ch_28159);
        _ch_28159 = _1;
    }

    /** scanner.e:2090							if ch = '*' then*/
    if (_ch_28159 != 42)
    goto LF; // [200] 213

    /** scanner.e:2091								level += 1*/
    _level_28192 = _level_28192 + 1;
    goto LC; // [210] 174
LF: 

    /** scanner.e:2093								ungetch()*/
    _61ungetch();
    goto LC; // [218] 174
LE: 

    /** scanner.e:2095						elsif ch = '*' then*/
    if (_ch_28159 != 42)
    goto L10; // [223] 257

    /** scanner.e:2096							ch = getch()*/
    _ch_28159 = _61getch();
    if (!IS_ATOM_INT(_ch_28159)) {
        _1 = (object)(DBL_PTR(_ch_28159)->dbl);
        DeRefDS(_ch_28159);
        _ch_28159 = _1;
    }

    /** scanner.e:2097							if ch = '/' then*/
    if (_ch_28159 != 47)
    goto L11; // [236] 249

    /** scanner.e:2098								level -= 1*/
    _level_28192 = _level_28192 - 1;
    goto LC; // [246] 174
L11: 

    /** scanner.e:2100								ungetch()*/
    _61ungetch();
    goto LC; // [254] 174
L10: 

    /** scanner.e:2102						elsif ch = '\n' then*/
    if (_ch_28159 != 10)
    goto L12; // [259] 270

    /** scanner.e:2103							read_line()*/
    _61read_line();
    goto LC; // [267] 174
L12: 

    /** scanner.e:2104						elsif ch = END_OF_FILE_CHAR then*/
    if (_ch_28159 != 26)
    goto LC; // [274] 174

    /** scanner.e:2105							ungetch()*/
    _61ungetch();

    /** scanner.e:2106							exit*/
    goto LD; // [284] 293

    /** scanner.e:2108					end while*/
    goto LC; // [290] 174
LD: 

    /** scanner.e:2109					ch = getch()*/
    _ch_28159 = _61getch();
    if (!IS_ATOM_INT(_ch_28159)) {
        _1 = (object)(DBL_PTR(_ch_28159)->dbl);
        DeRefDS(_ch_28159);
        _ch_28159 = _1;
    }

    /** scanner.e:2110					if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_28161)){
            _15487 = SEQ_PTR(_gtext_28161)->length;
    }
    else {
        _15487 = 1;
    }
    if (_15487 != 0)
    goto L13; // [305] 350

    /** scanner.e:2111						while ch = ' ' or ch = '\t' do*/
L14: 
    _15489 = (_ch_28159 == 32);
    if (_15489 != 0) {
        goto L15; // [318] 331
    }
    _15491 = (_ch_28159 == 9);
    if (_15491 == 0)
    {
        DeRef(_15491);
        _15491 = NOVALUE;
        goto L16; // [327] 343
    }
    else{
        DeRef(_15491);
        _15491 = NOVALUE;
    }
L15: 

    /** scanner.e:2112							ch = getch()*/
    _ch_28159 = _61getch();
    if (!IS_ATOM_INT(_ch_28159)) {
        _1 = (object)(DBL_PTR(_ch_28159)->dbl);
        DeRefDS(_ch_28159);
        _ch_28159 = _1;
    }

    /** scanner.e:2113						end while*/
    goto L14; // [340] 314
L16: 

    /** scanner.e:2114						continue "top"*/
    goto L4; // [347] 72
L13: 

    /** scanner.e:2116					exit*/
    goto L5; // [354] 391
    goto L17; // [358] 371
LB: 

    /** scanner.e:2119					ungetch()*/
    _61ungetch();

    /** scanner.e:2120					ch = '/'*/
    _ch_28159 = 47;
L17: 
LA: 
L9: 

    /** scanner.e:2123			gtext &= ch*/
    Append(&_gtext_28161, _gtext_28161, _ch_28159);

    /** scanner.e:2124			ch = getch()*/
    _ch_28159 = _61getch();
    if (!IS_ATOM_INT(_ch_28159)) {
        _1 = (object)(DBL_PTR(_ch_28159)->dbl);
        DeRefDS(_ch_28159);
        _ch_28159 = _1;
    }

    /** scanner.e:2125		end while*/
    goto L4; // [388] 72
L5: 

    /** scanner.e:2127		ungetch() -- put back end-word token.*/
    _61ungetch();

    /** scanner.e:2129		return gtext*/
    DeRefDSi(_pDelims_28158);
    DeRef(_15489);
    _15489 = NOVALUE;
    DeRef(_15455);
    _15455 = NOVALUE;
    return _gtext_28161;
    ;
}


void _61IncludeScan(object _is_public_28229)
{
    object _ch_28230 = NOVALUE;
    object _gtext_28231 = NOVALUE;
    object _s_28233 = NOVALUE;
    object _31731 = NOVALUE;
    object _15554 = NOVALUE;
    object _15553 = NOVALUE;
    object _15551 = NOVALUE;
    object _15549 = NOVALUE;
    object _15548 = NOVALUE;
    object _15543 = NOVALUE;
    object _15540 = NOVALUE;
    object _15538 = NOVALUE;
    object _15537 = NOVALUE;
    object _15535 = NOVALUE;
    object _15533 = NOVALUE;
    object _15531 = NOVALUE;
    object _15529 = NOVALUE;
    object _15523 = NOVALUE;
    object _15521 = NOVALUE;
    object _15516 = NOVALUE;
    object _15512 = NOVALUE;
    object _15511 = NOVALUE;
    object _15506 = NOVALUE;
    object _15503 = NOVALUE;
    object _15502 = NOVALUE;
    object _15498 = NOVALUE;
    object _15496 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2149		ch = getch()*/
    _ch_28230 = _61getch();
    if (!IS_ATOM_INT(_ch_28230)) {
        _1 = (object)(DBL_PTR(_ch_28230)->dbl);
        DeRefDS(_ch_28230);
        _ch_28230 = _1;
    }

    /** scanner.e:2150		while ch = ' ' or ch = '\t' do*/
L1: 
    _15496 = (_ch_28230 == 32);
    if (_15496 != 0) {
        goto L2; // [19] 32
    }
    _15498 = (_ch_28230 == 9);
    if (_15498 == 0)
    {
        DeRef(_15498);
        _15498 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_15498);
        _15498 = NOVALUE;
    }
L2: 

    /** scanner.e:2151			ch = getch()*/
    _ch_28230 = _61getch();
    if (!IS_ATOM_INT(_ch_28230)) {
        _1 = (object)(DBL_PTR(_ch_28230)->dbl);
        DeRefDS(_ch_28230);
        _ch_28230 = _1;
    }

    /** scanner.e:2152		end while*/
    goto L1; // [41] 15
L3: 

    /** scanner.e:2155		gtext = ""*/
    RefDS(_5);
    DeRef(_gtext_28231);
    _gtext_28231 = _5;

    /** scanner.e:2157		if ch = '"' then*/
    if (_ch_28230 != 34)
    goto L4; // [53] 143

    /** scanner.e:2159			ch = getch()*/
    _ch_28230 = _61getch();
    if (!IS_ATOM_INT(_ch_28230)) {
        _1 = (object)(DBL_PTR(_ch_28230)->dbl);
        DeRefDS(_ch_28230);
        _ch_28230 = _1;
    }

    /** scanner.e:2160			while not find(ch, {'\n', '\r', '"', END_OF_FILE_CHAR}) do*/
L5: 
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 10;
    ((intptr_t*)_2)[2] = 13;
    ((intptr_t*)_2)[3] = 34;
    ((intptr_t*)_2)[4] = 26;
    _15502 = MAKE_SEQ(_1);
    _15503 = find_from(_ch_28230, _15502, 1);
    DeRefDS(_15502);
    _15502 = NOVALUE;
    if (_15503 != 0)
    goto L6; // [83] 124
    _15503 = NOVALUE;

    /** scanner.e:2161				if ch = '\\' then*/
    if (_ch_28230 != 92)
    goto L7; // [88] 105

    /** scanner.e:2162					gtext &= EscapeChar('"')*/
    _15506 = _61EscapeChar(34);
    if (IS_SEQUENCE(_gtext_28231) && IS_ATOM(_15506)) {
        Ref(_15506);
        Append(&_gtext_28231, _gtext_28231, _15506);
    }
    else if (IS_ATOM(_gtext_28231) && IS_SEQUENCE(_15506)) {
    }
    else {
        Concat((object_ptr)&_gtext_28231, _gtext_28231, _15506);
    }
    DeRef(_15506);
    _15506 = NOVALUE;
    goto L8; // [102] 112
L7: 

    /** scanner.e:2164					gtext &= ch*/
    Append(&_gtext_28231, _gtext_28231, _ch_28230);
L8: 

    /** scanner.e:2166				ch = getch()*/
    _ch_28230 = _61getch();
    if (!IS_ATOM_INT(_ch_28230)) {
        _1 = (object)(DBL_PTR(_ch_28230)->dbl);
        DeRefDS(_ch_28230);
        _ch_28230 = _1;
    }

    /** scanner.e:2167			end while*/
    goto L5; // [121] 69
L6: 

    /** scanner.e:2168			if ch != '"' then*/
    if (_ch_28230 == 34)
    goto L9; // [126] 189

    /** scanner.e:2169				CompileErr(MISSING_CLOSING_QUOTE_ON_FILE_NAME)*/
    RefDS(_22015);
    _49CompileErr(115, _22015, 0);
    goto L9; // [140] 189
L4: 

    /** scanner.e:2173			while not find(ch, {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}) do*/
LA: 
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 32;
    ((intptr_t*)_2)[2] = 9;
    ((intptr_t*)_2)[3] = 10;
    ((intptr_t*)_2)[4] = 13;
    ((intptr_t*)_2)[5] = 26;
    _15511 = MAKE_SEQ(_1);
    _15512 = find_from(_ch_28230, _15511, 1);
    DeRefDS(_15511);
    _15511 = NOVALUE;
    if (_15512 != 0)
    goto LB; // [163] 184
    _15512 = NOVALUE;

    /** scanner.e:2174				gtext &= ch*/
    Append(&_gtext_28231, _gtext_28231, _ch_28230);

    /** scanner.e:2175				ch = getch()*/
    _ch_28230 = _61getch();
    if (!IS_ATOM_INT(_ch_28230)) {
        _1 = (object)(DBL_PTR(_ch_28230)->dbl);
        DeRefDS(_ch_28230);
        _ch_28230 = _1;
    }

    /** scanner.e:2176			end while*/
    goto LA; // [181] 148
LB: 

    /** scanner.e:2177			ungetch()*/
    _61ungetch();
L9: 

    /** scanner.e:2180		if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_28231)){
            _15516 = SEQ_PTR(_gtext_28231)->length;
    }
    else {
        _15516 = 1;
    }
    if (_15516 != 0)
    goto LC; // [194] 208

    /** scanner.e:2181			CompileErr(FILE_NAME_IS_MISSING)*/
    RefDS(_22015);
    _49CompileErr(95, _22015, 0);
LC: 

    /** scanner.e:2185		ifdef WINDOWS then*/

    /** scanner.e:2188			new_include_name = gtext*/
    RefDS(_gtext_28231);
    DeRef(_12new_include_name_20349);
    _12new_include_name_20349 = _gtext_28231;

    /** scanner.e:2192		ch = getch()*/
    _ch_28230 = _61getch();
    if (!IS_ATOM_INT(_ch_28230)) {
        _1 = (object)(DBL_PTR(_ch_28230)->dbl);
        DeRefDS(_ch_28230);
        _ch_28230 = _1;
    }

    /** scanner.e:2193		while ch = ' ' or ch = '\t' do*/
LD: 
    _15521 = (_ch_28230 == 32);
    if (_15521 != 0) {
        goto LE; // [233] 246
    }
    _15523 = (_ch_28230 == 9);
    if (_15523 == 0)
    {
        DeRef(_15523);
        _15523 = NOVALUE;
        goto LF; // [242] 258
    }
    else{
        DeRef(_15523);
        _15523 = NOVALUE;
    }
LE: 

    /** scanner.e:2194			ch = getch()*/
    _ch_28230 = _61getch();
    if (!IS_ATOM_INT(_ch_28230)) {
        _1 = (object)(DBL_PTR(_ch_28230)->dbl);
        DeRefDS(_ch_28230);
        _ch_28230 = _1;
    }

    /** scanner.e:2195		end while*/
    goto LD; // [255] 229
LF: 

    /** scanner.e:2197		new_include_space = 0*/
    _61new_include_space_25578 = 0;

    /** scanner.e:2199		if ch = 'a' then*/
    if (_ch_28230 != 97)
    goto L10; // [267] 532

    /** scanner.e:2201			ch = getch()*/
    _ch_28230 = _61getch();
    if (!IS_ATOM_INT(_ch_28230)) {
        _1 = (object)(DBL_PTR(_ch_28230)->dbl);
        DeRefDS(_ch_28230);
        _ch_28230 = _1;
    }

    /** scanner.e:2202			if ch = 's' then*/
    if (_ch_28230 != 115)
    goto L11; // [280] 519

    /** scanner.e:2203				ch = getch()*/
    _ch_28230 = _61getch();
    if (!IS_ATOM_INT(_ch_28230)) {
        _1 = (object)(DBL_PTR(_ch_28230)->dbl);
        DeRefDS(_ch_28230);
        _ch_28230 = _1;
    }

    /** scanner.e:2204				if ch = ' ' or ch = '\t' then*/
    _15529 = (_ch_28230 == 32);
    if (_15529 != 0) {
        goto L12; // [297] 310
    }
    _15531 = (_ch_28230 == 9);
    if (_15531 == 0)
    {
        DeRef(_15531);
        _15531 = NOVALUE;
        goto L13; // [306] 506
    }
    else{
        DeRef(_15531);
        _15531 = NOVALUE;
    }
L12: 

    /** scanner.e:2207					ch = getch()*/
    _ch_28230 = _61getch();
    if (!IS_ATOM_INT(_ch_28230)) {
        _1 = (object)(DBL_PTR(_ch_28230)->dbl);
        DeRefDS(_ch_28230);
        _ch_28230 = _1;
    }

    /** scanner.e:2208					while ch = ' ' or ch = '\t' do*/
L14: 
    _15533 = (_ch_28230 == 32);
    if (_15533 != 0) {
        goto L15; // [326] 339
    }
    _15535 = (_ch_28230 == 9);
    if (_15535 == 0)
    {
        DeRef(_15535);
        _15535 = NOVALUE;
        goto L16; // [335] 351
    }
    else{
        DeRef(_15535);
        _15535 = NOVALUE;
    }
L15: 

    /** scanner.e:2209						ch = getch()*/
    _ch_28230 = _61getch();
    if (!IS_ATOM_INT(_ch_28230)) {
        _1 = (object)(DBL_PTR(_ch_28230)->dbl);
        DeRefDS(_ch_28230);
        _ch_28230 = _1;
    }

    /** scanner.e:2210					end while*/
    goto L14; // [348] 322
L16: 

    /** scanner.e:2213					if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (object)SEQ_PTR(_61char_class_25587);
    _15537 = (object)*(((s1_ptr)_2)->base + _ch_28230);
    _15538 = (_15537 == -2);
    _15537 = NOVALUE;
    if (_15538 != 0) {
        goto L17; // [365] 378
    }
    _15540 = (_ch_28230 == 95);
    if (_15540 == 0)
    {
        DeRef(_15540);
        _15540 = NOVALUE;
        goto L18; // [374] 493
    }
    else{
        DeRef(_15540);
        _15540 = NOVALUE;
    }
L17: 

    /** scanner.e:2214						gtext = {ch}*/
    _0 = _gtext_28231;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ch_28230;
    _gtext_28231 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:2215						ch = getch()*/
    _ch_28230 = _61getch();
    if (!IS_ATOM_INT(_ch_28230)) {
        _1 = (object)(DBL_PTR(_ch_28230)->dbl);
        DeRefDS(_ch_28230);
        _ch_28230 = _1;
    }

    /** scanner.e:2216						while id_char[ch] = TRUE do*/
L19: 
    _2 = (object)SEQ_PTR(_61id_char_25588);
    _15543 = (object)*(((s1_ptr)_2)->base + _ch_28230);
    if (_15543 != _9TRUE_446)
    goto L1A; // [404] 426

    /** scanner.e:2217							gtext &= ch*/
    Append(&_gtext_28231, _gtext_28231, _ch_28230);

    /** scanner.e:2218							ch = getch()*/
    _ch_28230 = _61getch();
    if (!IS_ATOM_INT(_ch_28230)) {
        _1 = (object)(DBL_PTR(_ch_28230)->dbl);
        DeRefDS(_ch_28230);
        _ch_28230 = _1;
    }

    /** scanner.e:2219						end while*/
    goto L19; // [423] 396
L1A: 

    /** scanner.e:2221						ungetch()*/
    _61ungetch();

    /** scanner.e:2222						s = keyfind(gtext, -1, , 1)*/
    RefDS(_gtext_28231);
    _31731 = _53hashfn(_gtext_28231);
    RefDS(_gtext_28231);
    _0 = _s_28233;
    _s_28233 = _53keyfind(_gtext_28231, -1, _12current_file_no_20226, 1, _31731);
    DeRef(_0);
    _31731 = NOVALUE;

    /** scanner.e:2223						if not find(s[T_ID], ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_s_28233);
    _15548 = (object)*(((s1_ptr)_2)->base + 1);
    _15549 = find_from(_15548, _29ID_TOKS_12012, 1);
    _15548 = NOVALUE;
    if (_15549 != 0)
    goto L1B; // [463] 476
    _15549 = NOVALUE;

    /** scanner.e:2224							CompileErr(A_NEW_NAMESPACE_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_22015);
    _49CompileErr(36, _22015, 0);
L1B: 

    /** scanner.e:2226						new_include_space = NameSpace_declaration(s[T_SYM])*/
    _2 = (object)SEQ_PTR(_s_28233);
    _15551 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_15551);
    _0 = _61NameSpace_declaration(_15551);
    _61new_include_space_25578 = _0;
    _15551 = NOVALUE;
    if (!IS_ATOM_INT(_61new_include_space_25578)) {
        _1 = (object)(DBL_PTR(_61new_include_space_25578)->dbl);
        DeRefDS(_61new_include_space_25578);
        _61new_include_space_25578 = _1;
    }
    goto L1C; // [490] 647
L18: 

    /** scanner.e:2228						CompileErr(MISSING_NAMESPACE_QUALIFIER)*/
    RefDS(_22015);
    _49CompileErr(113, _22015, 0);
    goto L1C; // [503] 647
L13: 

    /** scanner.e:2231					CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22015);
    _49CompileErr(100, _22015, 0);
    goto L1C; // [516] 647
L11: 

    /** scanner.e:2234				CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22015);
    _49CompileErr(100, _22015, 0);
    goto L1C; // [529] 647
L10: 

    /** scanner.e:2237		elsif find(ch, {'\n', '\r', END_OF_FILE_CHAR}) then*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 10;
    ((intptr_t*)_2)[2] = 13;
    ((intptr_t*)_2)[3] = 26;
    _15553 = MAKE_SEQ(_1);
    _15554 = find_from(_ch_28230, _15553, 1);
    DeRefDS(_15553);
    _15553 = NOVALUE;
    if (_15554 == 0)
    {
        _15554 = NOVALUE;
        goto L1D; // [547] 557
    }
    else{
        _15554 = NOVALUE;
    }

    /** scanner.e:2238			ungetch()*/
    _61ungetch();
    goto L1C; // [554] 647
L1D: 

    /** scanner.e:2240		elsif ch = '-' then*/
    if (_ch_28230 != 45)
    goto L1E; // [559] 597

    /** scanner.e:2241			ch = getch()*/
    _ch_28230 = _61getch();
    if (!IS_ATOM_INT(_ch_28230)) {
        _1 = (object)(DBL_PTR(_ch_28230)->dbl);
        DeRefDS(_ch_28230);
        _ch_28230 = _1;
    }

    /** scanner.e:2242			if ch != '-' then*/
    if (_ch_28230 == 45)
    goto L1F; // [572] 586

    /** scanner.e:2243				CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22015);
    _49CompileErr(100, _22015, 0);
L1F: 

    /** scanner.e:2245			ungetch()*/
    _61ungetch();

    /** scanner.e:2246			ungetch()*/
    _61ungetch();
    goto L1C; // [594] 647
L1E: 

    /** scanner.e:2248		elsif ch = '/' then*/
    if (_ch_28230 != 47)
    goto L20; // [599] 637

    /** scanner.e:2249			ch = getch()*/
    _ch_28230 = _61getch();
    if (!IS_ATOM_INT(_ch_28230)) {
        _1 = (object)(DBL_PTR(_ch_28230)->dbl);
        DeRefDS(_ch_28230);
        _ch_28230 = _1;
    }

    /** scanner.e:2250			if ch != '*' then*/
    if (_ch_28230 == 42)
    goto L21; // [612] 626

    /** scanner.e:2251				CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22015);
    _49CompileErr(100, _22015, 0);
L21: 

    /** scanner.e:2253			ungetch()*/
    _61ungetch();

    /** scanner.e:2254			ungetch()*/
    _61ungetch();
    goto L1C; // [634] 647
L20: 

    /** scanner.e:2257			CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22015);
    _49CompileErr(100, _22015, 0);
L1C: 

    /** scanner.e:2260		start_include = TRUE -- let scanner know*/
    _61start_include_25580 = _9TRUE_446;

    /** scanner.e:2261		public_include = is_public*/
    _61public_include_25583 = _is_public_28229;

    /** scanner.e:2262	end procedure*/
    DeRef(_gtext_28231);
    DeRef(_s_28233);
    DeRef(_15529);
    _15529 = NOVALUE;
    DeRef(_15533);
    _15533 = NOVALUE;
    DeRef(_15521);
    _15521 = NOVALUE;
    _15543 = NOVALUE;
    DeRef(_15538);
    _15538 = NOVALUE;
    DeRef(_15496);
    _15496 = NOVALUE;
    return;
    ;
}


void _61main_file()
{
    object _15563 = NOVALUE;
    object _15562 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2275		if repl and top_level_block = -1 then*/
    if (0 == 0) {
        goto L1; // [5] 29
    }
    _15563 = (_64top_level_block_25148 == -1);
    if (_15563 == 0)
    {
        DeRef(_15563);
        _15563 = NOVALUE;
        goto L1; // [16] 29
    }
    else{
        DeRef(_15563);
        _15563 = NOVALUE;
    }

    /** scanner.e:2276			top_level_block = current_block*/
    _64top_level_block_25148 = _64current_block_25147;
L1: 

    /** scanner.e:2278		ifdef STDDEBUG then*/

    /** scanner.e:2283			read_line()*/
    _61read_line();

    /** scanner.e:2284			default_namespace( )*/
    _61default_namespace();

    /** scanner.e:2286	end procedure*/
    return;
    ;
}


void _61cleanup_open_includes()
{
    object _15566 = NOVALUE;
    object _15565 = NOVALUE;
    object _15564 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2289		for i = 1 to length( IncludeStk ) do*/
    if (IS_SEQUENCE(_61IncludeStk_25589)){
            _15564 = SEQ_PTR(_61IncludeStk_25589)->length;
    }
    else {
        _15564 = 1;
    }
    {
        object _i_28368;
        _i_28368 = 1;
L1: 
        if (_i_28368 > _15564){
            goto L2; // [8] 36
        }

        /** scanner.e:2290			close( IncludeStk[i][FILE_PTR] )*/
        _2 = (object)SEQ_PTR(_61IncludeStk_25589);
        _15565 = (object)*(((s1_ptr)_2)->base + _i_28368);
        _2 = (object)SEQ_PTR(_15565);
        _15566 = (object)*(((s1_ptr)_2)->base + 3);
        _15565 = NOVALUE;
        if (IS_ATOM_INT(_15566))
        EClose(_15566);
        else
        EClose((object)DBL_PTR(_15566)->dbl);
        _15566 = NOVALUE;

        /** scanner.e:2291		end for*/
        _i_28368 = _i_28368 + 1;
        goto L1; // [31] 15
L2: 
        ;
    }

    /** scanner.e:2292	end procedure*/
    return;
    ;
}



// 0xD4BB4FF8
