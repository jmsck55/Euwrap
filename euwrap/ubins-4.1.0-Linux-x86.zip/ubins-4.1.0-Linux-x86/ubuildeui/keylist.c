// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _62find_category(object _tokid_24029)
{
    object _catname_24030 = NOVALUE;
    object _13533 = NOVALUE;
    object _13532 = NOVALUE;
    object _13530 = NOVALUE;
    object _13529 = NOVALUE;
    object _13528 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_24029)) {
        _1 = (object)(DBL_PTR(_tokid_24029)->dbl);
        DeRefDS(_tokid_24029);
        _tokid_24029 = _1;
    }

    /** keylist.e:194		sequence catname = "reserved word"*/
    RefDS(_13527);
    DeRef(_catname_24030);
    _catname_24030 = _13527;

    /** keylist.e:195		for i = 1 to length(token_category) do*/
    _13528 = 73;
    {
        object _i_24033;
        _i_24033 = 1;
L1: 
        if (_i_24033 > 73){
            goto L2; // [17] 72
        }

        /** keylist.e:196			if token_category[i][1] = tokid then*/
        _2 = (object)SEQ_PTR(_29token_category_11933);
        _13529 = (object)*(((s1_ptr)_2)->base + _i_24033);
        _2 = (object)SEQ_PTR(_13529);
        _13530 = (object)*(((s1_ptr)_2)->base + 1);
        _13529 = NOVALUE;
        if (binary_op_a(NOTEQ, _13530, _tokid_24029)){
            _13530 = NOVALUE;
            goto L3; // [36] 65
        }
        _13530 = NOVALUE;

        /** keylist.e:197				catname = token_catname[token_category[i][2]]*/
        _2 = (object)SEQ_PTR(_29token_category_11933);
        _13532 = (object)*(((s1_ptr)_2)->base + _i_24033);
        _2 = (object)SEQ_PTR(_13532);
        _13533 = (object)*(((s1_ptr)_2)->base + 2);
        _13532 = NOVALUE;
        DeRef(_catname_24030);
        _2 = (object)SEQ_PTR(_29token_catname_11920);
        if (!IS_ATOM_INT(_13533)){
            _catname_24030 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_13533)->dbl));
        }
        else{
            _catname_24030 = (object)*(((s1_ptr)_2)->base + _13533);
        }
        RefDS(_catname_24030);

        /** keylist.e:198				exit*/
        goto L2; // [62] 72
L3: 

        /** keylist.e:200		end for*/
        _i_24033 = _i_24033 + 1;
        goto L1; // [67] 24
L2: 
        ;
    }

    /** keylist.e:201		return catname*/
    _13533 = NOVALUE;
    return _catname_24030;
    ;
}


object _62find_token_text(object _tokid_24048)
{
    object _13542 = NOVALUE;
    object _13540 = NOVALUE;
    object _13539 = NOVALUE;
    object _13537 = NOVALUE;
    object _13536 = NOVALUE;
    object _13535 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_24048)) {
        _1 = (object)(DBL_PTR(_tokid_24048)->dbl);
        DeRefDS(_tokid_24048);
        _tokid_24048 = _1;
    }

    /** keylist.e:205		for i = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_62keylist_23148)){
            _13535 = SEQ_PTR(_62keylist_23148)->length;
    }
    else {
        _13535 = 1;
    }
    {
        object _i_24050;
        _i_24050 = 1;
L1: 
        if (_i_24050 > _13535){
            goto L2; // [10] 57
        }

        /** keylist.e:206			if keylist[i][3] = tokid then*/
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _13536 = (object)*(((s1_ptr)_2)->base + _i_24050);
        _2 = (object)SEQ_PTR(_13536);
        _13537 = (object)*(((s1_ptr)_2)->base + 3);
        _13536 = NOVALUE;
        if (binary_op_a(NOTEQ, _13537, _tokid_24048)){
            _13537 = NOVALUE;
            goto L3; // [29] 50
        }
        _13537 = NOVALUE;

        /** keylist.e:207				return keylist[i][1]*/
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _13539 = (object)*(((s1_ptr)_2)->base + _i_24050);
        _2 = (object)SEQ_PTR(_13539);
        _13540 = (object)*(((s1_ptr)_2)->base + 1);
        _13539 = NOVALUE;
        Ref(_13540);
        return _13540;
L3: 

        /** keylist.e:209		end for*/
        _i_24050 = _i_24050 + 1;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** keylist.e:210		return LexName(tokid, "unknown word")*/
    RefDS(_13541);
    _13542 = _45LexName(_tokid_24048, _13541);
    _13540 = NOVALUE;
    return _13542;
    ;
}



// 0x1F49A72D
