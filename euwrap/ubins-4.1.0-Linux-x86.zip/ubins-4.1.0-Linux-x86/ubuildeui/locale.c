// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _31get_text(object _MsgNum_18408, object _LocalQuals_18409, object _DBBase_18410)
{
    object _db_res_18412 = NOVALUE;
    object _lMsgText_18413 = NOVALUE;
    object _dbname_18414 = NOVALUE;
    object _10278 = NOVALUE;
    object _10276 = NOVALUE;
    object _10274 = NOVALUE;
    object _10273 = NOVALUE;
    object _10272 = NOVALUE;
    object _10270 = NOVALUE;
    object _10269 = NOVALUE;
    object _10268 = NOVALUE;
    object _10262 = NOVALUE;
    object _10261 = NOVALUE;
    object _10260 = NOVALUE;
    object _10253 = NOVALUE;
    object _10250 = NOVALUE;
    object _10248 = NOVALUE;
    object _10246 = NOVALUE;
    object _10245 = NOVALUE;
    object _10244 = NOVALUE;
    object _10243 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_MsgNum_18408)) {
        _1 = (object)(DBL_PTR(_MsgNum_18408)->dbl);
        DeRefDS(_MsgNum_18408);
        _MsgNum_18408 = _1;
    }

    /** locale.e:798		db_res = -1*/
    _db_res_18412 = -1;

    /** locale.e:799		lMsgText = 0*/
    DeRef(_lMsgText_18413);
    _lMsgText_18413 = 0;

    /** locale.e:801		if string(LocalQuals) and length(LocalQuals) > 0 then*/
    RefDS(_LocalQuals_18409);
    _10243 = _9string(_LocalQuals_18409);
    if (IS_ATOM_INT(_10243)) {
        if (_10243 == 0) {
            goto L1; // [23] 45
        }
    }
    else {
        if (DBL_PTR(_10243)->dbl == 0.0) {
            goto L1; // [23] 45
        }
    }
    if (IS_SEQUENCE(_LocalQuals_18409)){
            _10245 = SEQ_PTR(_LocalQuals_18409)->length;
    }
    else {
        _10245 = 1;
    }
    _10246 = (_10245 > 0);
    _10245 = NOVALUE;
    if (_10246 == 0)
    {
        DeRef(_10246);
        _10246 = NOVALUE;
        goto L1; // [35] 45
    }
    else{
        DeRef(_10246);
        _10246 = NOVALUE;
    }

    /** locale.e:802			LocalQuals = {LocalQuals}*/
    _0 = _LocalQuals_18409;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_LocalQuals_18409);
    ((intptr_t*)_2)[1] = _LocalQuals_18409;
    _LocalQuals_18409 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** locale.e:804		for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_18409)){
            _10248 = SEQ_PTR(_LocalQuals_18409)->length;
    }
    else {
        _10248 = 1;
    }
    {
        object _i_18423;
        _i_18423 = 1;
L2: 
        if (_i_18423 > _10248){
            goto L3; // [50] 136
        }

        /** locale.e:805			dbname = DBBase & "_" & LocalQuals[i] & ".edb"*/
        _2 = (object)SEQ_PTR(_LocalQuals_18409);
        _10250 = (object)*(((s1_ptr)_2)->base + _i_18423);
        {
            object concat_list[4];

            concat_list[0] = _10251;
            concat_list[1] = _10250;
            concat_list[2] = _10249;
            concat_list[3] = _DBBase_18410;
            Concat_N((object_ptr)&_dbname_18414, concat_list, 4);
        }
        _10250 = NOVALUE;

        /** locale.e:806			db_res = eds:db_select( filesys:locate_file( dbname ), eds:DB_LOCK_READ_ONLY)*/
        RefDS(_dbname_18414);
        RefDS(_5);
        RefDS(_5);
        _10253 = _14locate_file(_dbname_18414, _5, _5);
        _db_res_18412 = _41db_select(_10253, 3);
        _10253 = NOVALUE;
        if (!IS_ATOM_INT(_db_res_18412)) {
            _1 = (object)(DBL_PTR(_db_res_18412)->dbl);
            DeRefDS(_db_res_18412);
            _db_res_18412 = _1;
        }

        /** locale.e:807			if db_res = eds:DB_OK then*/
        if (_db_res_18412 != 0)
        goto L4; // [87] 129

        /** locale.e:808				db_res = eds:db_select_table("1")*/
        RefDS(_10256);
        _db_res_18412 = _41db_select_table(_10256);
        if (!IS_ATOM_INT(_db_res_18412)) {
            _1 = (object)(DBL_PTR(_db_res_18412)->dbl);
            DeRefDS(_db_res_18412);
            _db_res_18412 = _1;
        }

        /** locale.e:809				if db_res = eds:DB_OK then*/
        if (_db_res_18412 != 0)
        goto L5; // [101] 128

        /** locale.e:810					lMsgText = eds:db_fetch_record(MsgNum)*/
        RefDS(_41current_table_name_15736);
        _0 = _lMsgText_18413;
        _lMsgText_18413 = _41db_fetch_record(_MsgNum_18408, _41current_table_name_15736);
        DeRef(_0);

        /** locale.e:811					if sequence(lMsgText) then*/
        _10260 = IS_SEQUENCE(_lMsgText_18413);
        if (_10260 == 0)
        {
            _10260 = NOVALUE;
            goto L6; // [119] 127
        }
        else{
            _10260 = NOVALUE;
        }

        /** locale.e:812						exit*/
        goto L3; // [124] 136
L6: 
L5: 
L4: 

        /** locale.e:816		end for*/
        _i_18423 = _i_18423 + 1;
        goto L2; // [131] 57
L3: 
        ;
    }

    /** locale.e:819		if atom(lMsgText) then*/
    _10261 = IS_ATOM(_lMsgText_18413);
    if (_10261 == 0)
    {
        _10261 = NOVALUE;
        goto L7; // [141] 281
    }
    else{
        _10261 = NOVALUE;
    }

    /** locale.e:820			dbname = filesys:locate_file( DBBase & ".edb" )*/
    Concat((object_ptr)&_10262, _DBBase_18410, _10251);
    RefDS(_5);
    RefDS(_5);
    _0 = _dbname_18414;
    _dbname_18414 = _14locate_file(_10262, _5, _5);
    DeRef(_0);
    _10262 = NOVALUE;

    /** locale.e:821			db_res = eds:db_select(	dbname, DB_LOCK_READ_ONLY)*/
    RefDS(_dbname_18414);
    _db_res_18412 = _41db_select(_dbname_18414, 3);
    if (!IS_ATOM_INT(_db_res_18412)) {
        _1 = (object)(DBL_PTR(_db_res_18412)->dbl);
        DeRefDS(_db_res_18412);
        _db_res_18412 = _1;
    }

    /** locale.e:822			if db_res = eds:DB_OK then*/
    if (_db_res_18412 != 0)
    goto L8; // [171] 280

    /** locale.e:823				db_res = eds:db_select_table("1")*/
    RefDS(_10256);
    _db_res_18412 = _41db_select_table(_10256);
    if (!IS_ATOM_INT(_db_res_18412)) {
        _1 = (object)(DBL_PTR(_db_res_18412)->dbl);
        DeRefDS(_db_res_18412);
        _db_res_18412 = _1;
    }

    /** locale.e:824				if db_res = eds:DB_OK then*/
    if (_db_res_18412 != 0)
    goto L9; // [185] 279

    /** locale.e:825					for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_18409)){
            _10268 = SEQ_PTR(_LocalQuals_18409)->length;
    }
    else {
        _10268 = 1;
    }
    {
        object _i_18452;
        _i_18452 = 1;
LA: 
        if (_i_18452 > _10268){
            goto LB; // [194] 238
        }

        /** locale.e:826						lMsgText = eds:db_fetch_record({LocalQuals[i],MsgNum})*/
        _2 = (object)SEQ_PTR(_LocalQuals_18409);
        _10269 = (object)*(((s1_ptr)_2)->base + _i_18452);
        Ref(_10269);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _10269;
        ((intptr_t *)_2)[2] = _MsgNum_18408;
        _10270 = MAKE_SEQ(_1);
        _10269 = NOVALUE;
        RefDS(_41current_table_name_15736);
        _0 = _lMsgText_18413;
        _lMsgText_18413 = _41db_fetch_record(_10270, _41current_table_name_15736);
        DeRef(_0);
        _10270 = NOVALUE;

        /** locale.e:827						if sequence(lMsgText) then*/
        _10272 = IS_SEQUENCE(_lMsgText_18413);
        if (_10272 == 0)
        {
            _10272 = NOVALUE;
            goto LC; // [223] 231
        }
        else{
            _10272 = NOVALUE;
        }

        /** locale.e:828							exit*/
        goto LB; // [228] 238
LC: 

        /** locale.e:830					end for*/
        _i_18452 = _i_18452 + 1;
        goto LA; // [233] 201
LB: 
        ;
    }

    /** locale.e:831					if atom(lMsgText) then*/
    _10273 = IS_ATOM(_lMsgText_18413);
    if (_10273 == 0)
    {
        _10273 = NOVALUE;
        goto LD; // [243] 260
    }
    else{
        _10273 = NOVALUE;
    }

    /** locale.e:832						lMsgText = eds:db_fetch_record({"",MsgNum})*/
    RefDS(_5);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _5;
    ((intptr_t *)_2)[2] = _MsgNum_18408;
    _10274 = MAKE_SEQ(_1);
    RefDS(_41current_table_name_15736);
    _0 = _lMsgText_18413;
    _lMsgText_18413 = _41db_fetch_record(_10274, _41current_table_name_15736);
    DeRef(_0);
    _10274 = NOVALUE;
LD: 

    /** locale.e:834					if atom(lMsgText) then*/
    _10276 = IS_ATOM(_lMsgText_18413);
    if (_10276 == 0)
    {
        _10276 = NOVALUE;
        goto LE; // [265] 278
    }
    else{
        _10276 = NOVALUE;
    }

    /** locale.e:835						lMsgText = eds:db_fetch_record(MsgNum)*/
    RefDS(_41current_table_name_15736);
    _0 = _lMsgText_18413;
    _lMsgText_18413 = _41db_fetch_record(_MsgNum_18408, _41current_table_name_15736);
    DeRef(_0);
LE: 
L9: 
L8: 
L7: 

    /** locale.e:840		if atom(lMsgText) then*/
    _10278 = IS_ATOM(_lMsgText_18413);
    if (_10278 == 0)
    {
        _10278 = NOVALUE;
        goto LF; // [286] 298
    }
    else{
        _10278 = NOVALUE;
    }

    /** locale.e:841			return 0*/
    DeRefDS(_LocalQuals_18409);
    DeRefDS(_DBBase_18410);
    DeRef(_lMsgText_18413);
    DeRef(_dbname_18414);
    DeRef(_10243);
    _10243 = NOVALUE;
    return 0;
    goto L10; // [295] 305
LF: 

    /** locale.e:843			return lMsgText*/
    DeRefDS(_LocalQuals_18409);
    DeRefDS(_DBBase_18410);
    DeRef(_dbname_18414);
    DeRef(_10243);
    _10243 = NOVALUE;
    return _lMsgText_18413;
L10: 
    ;
}



// 0xCF5661FA
