// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _48local_abort(object _lvl_20653)
{
    object _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_20658 = NOVALUE;
    object _11581 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:171		if length(pause_msg) != 0 then*/
    if (IS_SEQUENCE(_48pause_msg_20650)){
            _11581 = SEQ_PTR(_48pause_msg_20650)->length;
    }
    else {
        _11581 = 1;
    }
    if (_11581 == 0)
    goto L1; // [10] 45

    /** cmdline.e:172			console:maybe_any_key(pause_msg, 1)*/

    /** console.e:923		if not has_console() then*/

    /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
    DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_20658);
    _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_20658 = machine(99, 0);
    if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_20658)) {
        if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_20658 != 0){
            goto L2; // [27] 42
        }
    }
    else {
        if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_20658)->dbl != 0.0){
            goto L2; // [27] 42
        }
    }

    /** console.e:924			any_key(prompt, con)*/
    RefDS(_48pause_msg_20650);
    _38any_key(_48pause_msg_20650, 1);

    /** console.e:926	end procedure*/
    goto L2; // [39] 42
L2: 
    DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_20658);
    _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_20658 = NOVALUE;
L1: 

    /** cmdline.e:175		abort(lvl)*/
    UserCleanup(_lvl_20653);

    /** cmdline.e:176	end procedure*/
    return;
    ;
}


void _48check_for_bad_combos(object _opts_20661, object _opt1_20662, object _opt2_20663, object _error_message_20664)
{
    object _msg_inlined_crash_at_38_20672 = NOVALUE;
    object _11586 = NOVALUE;
    object _11585 = NOVALUE;
    object _11584 = NOVALUE;
    object _11583 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:180		if find( opt1, opts[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_opts_20661);
    _11583 = (object)*(((s1_ptr)_2)->base + 4);
    _11584 = find_from(_opt1_20662, _11583, 1);
    _11583 = NOVALUE;
    if (_11584 == 0)
    {
        _11584 = NOVALUE;
        goto L1; // [20] 59
    }
    else{
        _11584 = NOVALUE;
    }

    /** cmdline.e:181			if find( opt2, opts[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_opts_20661);
    _11585 = (object)*(((s1_ptr)_2)->base + 4);
    _11586 = find_from(_opt2_20663, _11585, 1);
    _11585 = NOVALUE;
    if (_11586 == 0)
    {
        _11586 = NOVALUE;
        goto L2; // [34] 58
    }
    else{
        _11586 = NOVALUE;
    }

    /** cmdline.e:182				error:crash( error_message )*/

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_38_20672);
    _msg_inlined_crash_at_38_20672 = EPrintf(-9999999, _error_message_20664, _5);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_38_20672);

    /** error.e:53	end procedure*/
    goto L3; // [52] 55
L3: 
    DeRefi(_msg_inlined_crash_at_38_20672);
    _msg_inlined_crash_at_38_20672 = NOVALUE;
L2: 
L1: 

    /** cmdline.e:185	end procedure*/
    DeRefDS(_opts_20661);
    DeRefDSi(_error_message_20664);
    return;
    ;
}


object _48has_duplicate(object _opts_20675, object _opt_20676, object _name_type_20677, object _start_from_20678)
{
    object _opt_name_20682 = NOVALUE;
    object _11594 = NOVALUE;
    object _11593 = NOVALUE;
    object _11592 = NOVALUE;
    object _11591 = NOVALUE;
    object _11590 = NOVALUE;
    object _11588 = NOVALUE;
    object _11587 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:188		if sequence( opt[name_type] ) then*/
    _2 = (object)SEQ_PTR(_opt_20676);
    _11587 = (object)*(((s1_ptr)_2)->base + _name_type_20677);
    _11588 = IS_SEQUENCE(_11587);
    _11587 = NOVALUE;
    if (_11588 == 0)
    {
        _11588 = NOVALUE;
        goto L1; // [18] 77
    }
    else{
        _11588 = NOVALUE;
    }

    /** cmdline.e:189			sequence opt_name = opt[name_type]*/
    DeRef(_opt_name_20682);
    _2 = (object)SEQ_PTR(_opt_20676);
    _opt_name_20682 = (object)*(((s1_ptr)_2)->base + _name_type_20677);
    Ref(_opt_name_20682);

    /** cmdline.e:190			for i = start_from + 1 to length( opts ) do*/
    _11590 = _start_from_20678 + 1;
    if (IS_SEQUENCE(_opts_20675)){
            _11591 = SEQ_PTR(_opts_20675)->length;
    }
    else {
        _11591 = 1;
    }
    {
        object _i_20685;
        _i_20685 = _11590;
L2: 
        if (_i_20685 > _11591){
            goto L3; // [38] 76
        }

        /** cmdline.e:191				if equal( opt_name, opts[i][name_type] ) then*/
        _2 = (object)SEQ_PTR(_opts_20675);
        _11592 = (object)*(((s1_ptr)_2)->base + _i_20685);
        _2 = (object)SEQ_PTR(_11592);
        _11593 = (object)*(((s1_ptr)_2)->base + _name_type_20677);
        _11592 = NOVALUE;
        if (_opt_name_20682 == _11593)
        _11594 = 1;
        else if (IS_ATOM_INT(_opt_name_20682) && IS_ATOM_INT(_11593))
        _11594 = 0;
        else
        _11594 = (compare(_opt_name_20682, _11593) == 0);
        _11593 = NOVALUE;
        if (_11594 == 0)
        {
            _11594 = NOVALUE;
            goto L4; // [59] 69
        }
        else{
            _11594 = NOVALUE;
        }

        /** cmdline.e:192					return 1*/
        DeRefDS(_opt_name_20682);
        DeRefDS(_opts_20675);
        DeRefDS(_opt_20676);
        DeRef(_11590);
        _11590 = NOVALUE;
        return 1;
L4: 

        /** cmdline.e:194			end for*/
        _i_20685 = _i_20685 + 1;
        goto L2; // [71] 45
L3: 
        ;
    }
L1: 
    DeRef(_opt_name_20682);
    _opt_name_20682 = NOVALUE;

    /** cmdline.e:196		return 0*/
    DeRefDS(_opts_20675);
    DeRefDS(_opt_20676);
    DeRef(_11590);
    _11590 = NOVALUE;
    return 0;
    ;
}


void _48check_for_duplicates(object _opts_20694)
{
    object _opt_20698 = NOVALUE;
    object _msg_inlined_crash_at_49_20707 = NOVALUE;
    object _data_inlined_crash_at_46_20706 = NOVALUE;
    object _msg_inlined_crash_at_95_20715 = NOVALUE;
    object _data_inlined_crash_at_92_20714 = NOVALUE;
    object _11604 = NOVALUE;
    object _11603 = NOVALUE;
    object _11601 = NOVALUE;
    object _11600 = NOVALUE;
    object _11599 = NOVALUE;
    object _11597 = NOVALUE;
    object _11595 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:201		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_20694)){
            _11595 = SEQ_PTR(_opts_20694)->length;
    }
    else {
        _11595 = 1;
    }
    {
        object _i_20696;
        _i_20696 = 1;
L1: 
        if (_i_20696 > _11595){
            goto L2; // [8] 125
        }

        /** cmdline.e:202			sequence opt*/

        /** cmdline.e:203			opt = opts[i]*/
        DeRef(_opt_20698);
        _2 = (object)SEQ_PTR(_opts_20694);
        _opt_20698 = (object)*(((s1_ptr)_2)->base + _i_20696);
        Ref(_opt_20698);

        /** cmdline.e:204			if has_duplicate( opts, opt, SHORTNAME, i ) then*/
        RefDS(_opts_20694);
        RefDS(_opt_20698);
        _11597 = _48has_duplicate(_opts_20694, _opt_20698, 1, _i_20696);
        if (_11597 == 0) {
            DeRef(_11597);
            _11597 = NOVALUE;
            goto L3; // [34] 71
        }
        else {
            if (!IS_ATOM_INT(_11597) && DBL_PTR(_11597)->dbl == 0.0){
                DeRef(_11597);
                _11597 = NOVALUE;
                goto L3; // [34] 71
            }
            DeRef(_11597);
            _11597 = NOVALUE;
        }
        DeRef(_11597);
        _11597 = NOVALUE;

        /** cmdline.e:206				error:crash("cmd_opts: Duplicate Short Names (%s) are not allowed in an option record.\n",*/
        _2 = (object)SEQ_PTR(_opt_20698);
        _11599 = (object)*(((s1_ptr)_2)->base + 1);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_11599);
        ((intptr_t*)_2)[1] = _11599;
        _11600 = MAKE_SEQ(_1);
        _11599 = NOVALUE;
        DeRef(_data_inlined_crash_at_46_20706);
        _data_inlined_crash_at_46_20706 = _11600;
        _11600 = NOVALUE;

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_49_20707);
        _msg_inlined_crash_at_49_20707 = EPrintf(-9999999, _11598, _data_inlined_crash_at_46_20706);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_49_20707);

        /** error.e:53	end procedure*/
        goto L4; // [63] 66
L4: 
        DeRef(_data_inlined_crash_at_46_20706);
        _data_inlined_crash_at_46_20706 = NOVALUE;
        DeRefi(_msg_inlined_crash_at_49_20707);
        _msg_inlined_crash_at_49_20707 = NOVALUE;
        goto L5; // [68] 116
L3: 

        /** cmdline.e:209			elsif has_duplicate( opts, opt, LONGNAME, i ) then*/
        RefDS(_opts_20694);
        RefDS(_opt_20698);
        _11601 = _48has_duplicate(_opts_20694, _opt_20698, 2, _i_20696);
        if (_11601 == 0) {
            DeRef(_11601);
            _11601 = NOVALUE;
            goto L6; // [80] 115
        }
        else {
            if (!IS_ATOM_INT(_11601) && DBL_PTR(_11601)->dbl == 0.0){
                DeRef(_11601);
                _11601 = NOVALUE;
                goto L6; // [80] 115
            }
            DeRef(_11601);
            _11601 = NOVALUE;
        }
        DeRef(_11601);
        _11601 = NOVALUE;

        /** cmdline.e:211				error:crash("cmd_opts: Duplicate Long Names (%s) are not allowed in an option record.\n",*/
        _2 = (object)SEQ_PTR(_opt_20698);
        _11603 = (object)*(((s1_ptr)_2)->base + 2);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_11603);
        ((intptr_t*)_2)[1] = _11603;
        _11604 = MAKE_SEQ(_1);
        _11603 = NOVALUE;
        DeRef(_data_inlined_crash_at_92_20714);
        _data_inlined_crash_at_92_20714 = _11604;
        _11604 = NOVALUE;

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_95_20715);
        _msg_inlined_crash_at_95_20715 = EPrintf(-9999999, _11602, _data_inlined_crash_at_92_20714);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_95_20715);

        /** error.e:53	end procedure*/
        goto L7; // [109] 112
L7: 
        DeRef(_data_inlined_crash_at_92_20714);
        _data_inlined_crash_at_92_20714 = NOVALUE;
        DeRefi(_msg_inlined_crash_at_95_20715);
        _msg_inlined_crash_at_95_20715 = NOVALUE;
L6: 
L5: 
        DeRef(_opt_20698);
        _opt_20698 = NOVALUE;

        /** cmdline.e:214		end for*/
        _i_20696 = _i_20696 + 1;
        goto L1; // [120] 15
L2: 
        ;
    }

    /** cmdline.e:216	end procedure*/
    DeRefDS(_opts_20694);
    return;
    ;
}


object _48update_opts(object _opts_20718)
{
    object _lExtras_20719 = NOVALUE;
    object _opt_20723 = NOVALUE;
    object _msg_inlined_crash_at_162_20756 = NOVALUE;
    object _msg_inlined_crash_at_323_20787 = NOVALUE;
    object _11675 = NOVALUE;
    object _11674 = NOVALUE;
    object _11673 = NOVALUE;
    object _11672 = NOVALUE;
    object _11671 = NOVALUE;
    object _11670 = NOVALUE;
    object _11669 = NOVALUE;
    object _11668 = NOVALUE;
    object _11667 = NOVALUE;
    object _11666 = NOVALUE;
    object _11665 = NOVALUE;
    object _11664 = NOVALUE;
    object _11663 = NOVALUE;
    object _11662 = NOVALUE;
    object _11660 = NOVALUE;
    object _11658 = NOVALUE;
    object _11657 = NOVALUE;
    object _11656 = NOVALUE;
    object _11655 = NOVALUE;
    object _11648 = NOVALUE;
    object _11647 = NOVALUE;
    object _11646 = NOVALUE;
    object _11645 = NOVALUE;
    object _11644 = NOVALUE;
    object _11643 = NOVALUE;
    object _11642 = NOVALUE;
    object _11641 = NOVALUE;
    object _11639 = NOVALUE;
    object _11638 = NOVALUE;
    object _11637 = NOVALUE;
    object _11636 = NOVALUE;
    object _11635 = NOVALUE;
    object _11634 = NOVALUE;
    object _11633 = NOVALUE;
    object _11632 = NOVALUE;
    object _11629 = NOVALUE;
    object _11628 = NOVALUE;
    object _11627 = NOVALUE;
    object _11626 = NOVALUE;
    object _11625 = NOVALUE;
    object _11624 = NOVALUE;
    object _11623 = NOVALUE;
    object _11622 = NOVALUE;
    object _11621 = NOVALUE;
    object _11620 = NOVALUE;
    object _11619 = NOVALUE;
    object _11618 = NOVALUE;
    object _11617 = NOVALUE;
    object _11616 = NOVALUE;
    object _11615 = NOVALUE;
    object _11614 = NOVALUE;
    object _11613 = NOVALUE;
    object _11611 = NOVALUE;
    object _11610 = NOVALUE;
    object _11609 = NOVALUE;
    object _11607 = NOVALUE;
    object _11605 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:223		integer lExtras = 0 -- Ensure that there is zero or one 'extras' record only.*/
    _lExtras_20719 = 0;

    /** cmdline.e:224		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_20718)){
            _11605 = SEQ_PTR(_opts_20718)->length;
    }
    else {
        _11605 = 1;
    }
    {
        object _i_20721;
        _i_20721 = 1;
L1: 
        if (_i_20721 > _11605){
            goto L2; // [13] 565
        }

        /** cmdline.e:225			sequence opt = opts[i]*/
        DeRef(_opt_20723);
        _2 = (object)SEQ_PTR(_opts_20718);
        _opt_20723 = (object)*(((s1_ptr)_2)->base + _i_20721);
        Ref(_opt_20723);

        /** cmdline.e:226			opts[i] = 0*/
        _2 = (object)SEQ_PTR(_opts_20718);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opts_20718 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_20721);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);

        /** cmdline.e:228			if length(opt) < MAPNAME then*/
        if (IS_SEQUENCE(_opt_20723)){
                _11607 = SEQ_PTR(_opt_20723)->length;
        }
        else {
            _11607 = 1;
        }
        if (_11607 >= 6)
        goto L3; // [39] 61

        /** cmdline.e:229				opt &= repeat(-1, MAPNAME - length(opt))*/
        if (IS_SEQUENCE(_opt_20723)){
                _11609 = SEQ_PTR(_opt_20723)->length;
        }
        else {
            _11609 = 1;
        }
        _11610 = 6 - _11609;
        _11609 = NOVALUE;
        _11611 = Repeat(-1, _11610);
        _11610 = NOVALUE;
        Concat((object_ptr)&_opt_20723, _opt_20723, _11611);
        DeRefDS(_11611);
        _11611 = NOVALUE;
L3: 

        /** cmdline.e:232			if sequence(opt[SHORTNAME]) and length(opt[SHORTNAME]) = 0 then*/
        _2 = (object)SEQ_PTR(_opt_20723);
        _11613 = (object)*(((s1_ptr)_2)->base + 1);
        _11614 = IS_SEQUENCE(_11613);
        _11613 = NOVALUE;
        if (_11614 == 0) {
            goto L4; // [70] 96
        }
        _2 = (object)SEQ_PTR(_opt_20723);
        _11616 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_SEQUENCE(_11616)){
                _11617 = SEQ_PTR(_11616)->length;
        }
        else {
            _11617 = 1;
        }
        _11616 = NOVALUE;
        _11618 = (_11617 == 0);
        _11617 = NOVALUE;
        if (_11618 == 0)
        {
            DeRef(_11618);
            _11618 = NOVALUE;
            goto L4; // [86] 96
        }
        else{
            DeRef(_11618);
            _11618 = NOVALUE;
        }

        /** cmdline.e:233				opt[SHORTNAME] = 0*/
        _2 = (object)SEQ_PTR(_opt_20723);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_20723 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);
L4: 

        /** cmdline.e:236			if sequence(opt[LONGNAME]) and length(opt[LONGNAME]) = 0 then*/
        _2 = (object)SEQ_PTR(_opt_20723);
        _11619 = (object)*(((s1_ptr)_2)->base + 2);
        _11620 = IS_SEQUENCE(_11619);
        _11619 = NOVALUE;
        if (_11620 == 0) {
            goto L5; // [105] 131
        }
        _2 = (object)SEQ_PTR(_opt_20723);
        _11622 = (object)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_11622)){
                _11623 = SEQ_PTR(_11622)->length;
        }
        else {
            _11623 = 1;
        }
        _11622 = NOVALUE;
        _11624 = (_11623 == 0);
        _11623 = NOVALUE;
        if (_11624 == 0)
        {
            DeRef(_11624);
            _11624 = NOVALUE;
            goto L5; // [121] 131
        }
        else{
            DeRef(_11624);
            _11624 = NOVALUE;
        }

        /** cmdline.e:237				opt[LONGNAME] = 0*/
        _2 = (object)SEQ_PTR(_opt_20723);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_20723 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 2);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);
L5: 

        /** cmdline.e:240			if atom(opt[LONGNAME]) and atom(opt[SHORTNAME]) then*/
        _2 = (object)SEQ_PTR(_opt_20723);
        _11625 = (object)*(((s1_ptr)_2)->base + 2);
        _11626 = IS_ATOM(_11625);
        _11625 = NOVALUE;
        if (_11626 == 0) {
            goto L6; // [140] 212
        }
        _2 = (object)SEQ_PTR(_opt_20723);
        _11628 = (object)*(((s1_ptr)_2)->base + 1);
        _11629 = IS_ATOM(_11628);
        _11628 = NOVALUE;
        if (_11629 == 0)
        {
            _11629 = NOVALUE;
            goto L6; // [152] 212
        }
        else{
            _11629 = NOVALUE;
        }

        /** cmdline.e:241				if lExtras != 0 then*/
        if (_lExtras_20719 == 0)
        goto L7; // [157] 184

        /** cmdline.e:242					error:crash("cmd_opts: There must be less than two 'extras' option records.\n")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_162_20756);
        _msg_inlined_crash_at_162_20756 = EPrintf(-9999999, _11631, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_162_20756);

        /** error.e:53	end procedure*/
        goto L8; // [176] 179
L8: 
        DeRefi(_msg_inlined_crash_at_162_20756);
        _msg_inlined_crash_at_162_20756 = NOVALUE;
        goto L9; // [181] 211
L7: 

        /** cmdline.e:244					lExtras = i*/
        _lExtras_20719 = _i_20721;

        /** cmdline.e:245					if atom(opt[MAPNAME]) then*/
        _2 = (object)SEQ_PTR(_opt_20723);
        _11632 = (object)*(((s1_ptr)_2)->base + 6);
        _11633 = IS_ATOM(_11632);
        _11632 = NOVALUE;
        if (_11633 == 0)
        {
            _11633 = NOVALUE;
            goto LA; // [198] 210
        }
        else{
            _11633 = NOVALUE;
        }

        /** cmdline.e:246						opt[MAPNAME] = EXTRAS*/
        RefDS(_48EXTRAS_20639);
        _2 = (object)SEQ_PTR(_opt_20723);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_20723 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 6);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _48EXTRAS_20639;
        DeRef(_1);
LA: 
L9: 
L6: 

        /** cmdline.e:251			if atom(opt[DESCRIPTION]) then*/
        _2 = (object)SEQ_PTR(_opt_20723);
        _11634 = (object)*(((s1_ptr)_2)->base + 3);
        _11635 = IS_ATOM(_11634);
        _11634 = NOVALUE;
        if (_11635 == 0)
        {
            _11635 = NOVALUE;
            goto LB; // [221] 231
        }
        else{
            _11635 = NOVALUE;
        }

        /** cmdline.e:252				opt[DESCRIPTION] = ""*/
        RefDS(_5);
        _2 = (object)SEQ_PTR(_opt_20723);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_20723 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 3);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5;
        DeRef(_1);
LB: 

        /** cmdline.e:256			if atom(opt[OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opt_20723);
        _11636 = (object)*(((s1_ptr)_2)->base + 4);
        _11637 = IS_ATOM(_11636);
        _11636 = NOVALUE;
        if (_11637 == 0)
        {
            _11637 = NOVALUE;
            goto LC; // [240] 279
        }
        else{
            _11637 = NOVALUE;
        }

        /** cmdline.e:257				if equal(opt[OPTIONS], HAS_PARAMETER) then*/
        _2 = (object)SEQ_PTR(_opt_20723);
        _11638 = (object)*(((s1_ptr)_2)->base + 4);
        if (_11638 == 112)
        _11639 = 1;
        else if (IS_ATOM_INT(_11638) && IS_ATOM_INT(112))
        _11639 = 0;
        else
        _11639 = (compare(_11638, 112) == 0);
        _11638 = NOVALUE;
        if (_11639 == 0)
        {
            _11639 = NOVALUE;
            goto LD; // [253] 269
        }
        else{
            _11639 = NOVALUE;
        }

        /** cmdline.e:258					opt[OPTIONS] = {HAS_PARAMETER,"x"}*/
        RefDS(_11640);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 112;
        ((intptr_t *)_2)[2] = _11640;
        _11641 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_opt_20723);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_20723 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _11641;
        if( _1 != _11641 ){
            DeRef(_1);
        }
        _11641 = NOVALUE;
        goto LE; // [266] 383
LD: 

        /** cmdline.e:260					opt[OPTIONS] = {}*/
        RefDS(_5);
        _2 = (object)SEQ_PTR(_opt_20723);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_20723 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5;
        DeRef(_1);
        goto LE; // [276] 383
LC: 

        /** cmdline.e:263				for j = 1 to length(opt[OPTIONS]) do*/
        _2 = (object)SEQ_PTR(_opt_20723);
        _11642 = (object)*(((s1_ptr)_2)->base + 4);
        if (IS_SEQUENCE(_11642)){
                _11643 = SEQ_PTR(_11642)->length;
        }
        else {
            _11643 = 1;
        }
        _11642 = NOVALUE;
        {
            object _j_20775;
            _j_20775 = 1;
LF: 
            if (_j_20775 > _11643){
                goto L10; // [288] 350
            }

            /** cmdline.e:264					if find(opt[OPTIONS][j], opt[OPTIONS], j + 1) != 0 then*/
            _2 = (object)SEQ_PTR(_opt_20723);
            _11644 = (object)*(((s1_ptr)_2)->base + 4);
            _2 = (object)SEQ_PTR(_11644);
            _11645 = (object)*(((s1_ptr)_2)->base + _j_20775);
            _11644 = NOVALUE;
            _2 = (object)SEQ_PTR(_opt_20723);
            _11646 = (object)*(((s1_ptr)_2)->base + 4);
            _11647 = _j_20775 + 1;
            _11648 = find_from(_11645, _11646, _11647);
            _11645 = NOVALUE;
            _11646 = NOVALUE;
            _11647 = NOVALUE;
            if (_11648 == 0)
            goto L11; // [318] 343

            /** cmdline.e:265						error:crash("cmd_opts: Duplicate processing options are not allowed in an option record.\n")*/

            /** error.e:51		msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_323_20787);
            _msg_inlined_crash_at_323_20787 = EPrintf(-9999999, _11650, _5);

            /** error.e:52		machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_323_20787);

            /** error.e:53	end procedure*/
            goto L12; // [337] 340
L12: 
            DeRefi(_msg_inlined_crash_at_323_20787);
            _msg_inlined_crash_at_323_20787 = NOVALUE;
L11: 

            /** cmdline.e:267				end for*/
            _j_20775 = _j_20775 + 1;
            goto LF; // [345] 295
L10: 
            ;
        }

        /** cmdline.e:269				check_for_bad_combos( opt, HAS_PARAMETER, NO_PARAMETER, */
        RefDS(_opt_20723);
        RefDS(_11651);
        _48check_for_bad_combos(_opt_20723, 112, 110, _11651);

        /** cmdline.e:272				check_for_bad_combos( opt, HAS_CASE, NO_CASE, */
        RefDS(_opt_20723);
        RefDS(_11652);
        _48check_for_bad_combos(_opt_20723, 99, 105, _11652);

        /** cmdline.e:275				check_for_bad_combos( opt, MANDATORY, OPTIONAL, */
        RefDS(_opt_20723);
        RefDS(_11653);
        _48check_for_bad_combos(_opt_20723, 109, 111, _11653);

        /** cmdline.e:278				check_for_bad_combos( opt, ONCE, MULTIPLE, */
        RefDS(_opt_20723);
        RefDS(_11654);
        _48check_for_bad_combos(_opt_20723, 49, 42, _11654);
LE: 

        /** cmdline.e:283			if sequence(opt[CALLBACK]) then*/
        _2 = (object)SEQ_PTR(_opt_20723);
        _11655 = (object)*(((s1_ptr)_2)->base + 5);
        _11656 = IS_SEQUENCE(_11655);
        _11655 = NOVALUE;
        if (_11656 == 0)
        {
            _11656 = NOVALUE;
            goto L13; // [392] 404
        }
        else{
            _11656 = NOVALUE;
        }

        /** cmdline.e:284				opt[CALLBACK] = -1*/
        _2 = (object)SEQ_PTR(_opt_20723);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_20723 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = -1;
        DeRef(_1);
        goto L14; // [401] 443
L13: 

        /** cmdline.e:285			elsif not integer(opt[CALLBACK]) then*/
        _2 = (object)SEQ_PTR(_opt_20723);
        _11657 = (object)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_11657))
        _11658 = 1;
        else if (IS_ATOM_DBL(_11657))
        _11658 = IS_ATOM_INT(DoubleToInt(_11657));
        else
        _11658 = 0;
        _11657 = NOVALUE;
        if (_11658 != 0)
        goto L15; // [413] 425
        _11658 = NOVALUE;

        /** cmdline.e:286				opt[CALLBACK] = -1*/
        _2 = (object)SEQ_PTR(_opt_20723);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_20723 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = -1;
        DeRef(_1);
        goto L14; // [422] 443
L15: 

        /** cmdline.e:287			elsif opt[CALLBACK] < 0 then*/
        _2 = (object)SEQ_PTR(_opt_20723);
        _11660 = (object)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(GREATEREQ, _11660, 0)){
            _11660 = NOVALUE;
            goto L16; // [431] 442
        }
        _11660 = NOVALUE;

        /** cmdline.e:288				opt[CALLBACK] = -1*/
        _2 = (object)SEQ_PTR(_opt_20723);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_20723 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = -1;
        DeRef(_1);
L16: 
L14: 

        /** cmdline.e:291			if sequence(opt[MAPNAME]) and length(opt[MAPNAME]) = 0 then*/
        _2 = (object)SEQ_PTR(_opt_20723);
        _11662 = (object)*(((s1_ptr)_2)->base + 6);
        _11663 = IS_SEQUENCE(_11662);
        _11662 = NOVALUE;
        if (_11663 == 0) {
            goto L17; // [452] 478
        }
        _2 = (object)SEQ_PTR(_opt_20723);
        _11665 = (object)*(((s1_ptr)_2)->base + 6);
        if (IS_SEQUENCE(_11665)){
                _11666 = SEQ_PTR(_11665)->length;
        }
        else {
            _11666 = 1;
        }
        _11665 = NOVALUE;
        _11667 = (_11666 == 0);
        _11666 = NOVALUE;
        if (_11667 == 0)
        {
            DeRef(_11667);
            _11667 = NOVALUE;
            goto L17; // [468] 478
        }
        else{
            DeRef(_11667);
            _11667 = NOVALUE;
        }

        /** cmdline.e:292				opt[MAPNAME] = 0*/
        _2 = (object)SEQ_PTR(_opt_20723);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_20723 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 6);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);
L17: 

        /** cmdline.e:295			if atom(opt[MAPNAME]) then*/
        _2 = (object)SEQ_PTR(_opt_20723);
        _11668 = (object)*(((s1_ptr)_2)->base + 6);
        _11669 = IS_ATOM(_11668);
        _11668 = NOVALUE;
        if (_11669 == 0)
        {
            _11669 = NOVALUE;
            goto L18; // [487] 550
        }
        else{
            _11669 = NOVALUE;
        }

        /** cmdline.e:296				if sequence(opt[LONGNAME]) then*/
        _2 = (object)SEQ_PTR(_opt_20723);
        _11670 = (object)*(((s1_ptr)_2)->base + 2);
        _11671 = IS_SEQUENCE(_11670);
        _11670 = NOVALUE;
        if (_11671 == 0)
        {
            _11671 = NOVALUE;
            goto L19; // [499] 515
        }
        else{
            _11671 = NOVALUE;
        }

        /** cmdline.e:297					opt[MAPNAME] = opt[LONGNAME]*/
        _2 = (object)SEQ_PTR(_opt_20723);
        _11672 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_11672);
        _2 = (object)SEQ_PTR(_opt_20723);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_20723 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 6);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _11672;
        if( _1 != _11672 ){
            DeRef(_1);
        }
        _11672 = NOVALUE;
        goto L1A; // [512] 549
L19: 

        /** cmdline.e:298				elsif sequence(opt[SHORTNAME]) then*/
        _2 = (object)SEQ_PTR(_opt_20723);
        _11673 = (object)*(((s1_ptr)_2)->base + 1);
        _11674 = IS_SEQUENCE(_11673);
        _11673 = NOVALUE;
        if (_11674 == 0)
        {
            _11674 = NOVALUE;
            goto L1B; // [524] 540
        }
        else{
            _11674 = NOVALUE;
        }

        /** cmdline.e:299					opt[MAPNAME] = opt[SHORTNAME]*/
        _2 = (object)SEQ_PTR(_opt_20723);
        _11675 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_11675);
        _2 = (object)SEQ_PTR(_opt_20723);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_20723 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 6);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _11675;
        if( _1 != _11675 ){
            DeRef(_1);
        }
        _11675 = NOVALUE;
        goto L1A; // [537] 549
L1B: 

        /** cmdline.e:301					opt[MAPNAME] = EXTRAS*/
        RefDS(_48EXTRAS_20639);
        _2 = (object)SEQ_PTR(_opt_20723);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_20723 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 6);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _48EXTRAS_20639;
        DeRef(_1);
L1A: 
L18: 

        /** cmdline.e:305			opts[i] = opt*/
        RefDS(_opt_20723);
        _2 = (object)SEQ_PTR(_opts_20718);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opts_20718 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_20721);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _opt_20723;
        DeRef(_1);
        DeRefDS(_opt_20723);
        _opt_20723 = NOVALUE;

        /** cmdline.e:306		end for*/
        _i_20721 = _i_20721 + 1;
        goto L1; // [560] 20
L2: 
        ;
    }

    /** cmdline.e:307		return opts*/
    _11665 = NOVALUE;
    _11642 = NOVALUE;
    _11616 = NOVALUE;
    _11622 = NOVALUE;
    return _opts_20718;
    ;
}


object _48standardize_help_options(object _opts_20823, object _auto_help_switches_20824)
{
    object _has_h_20825 = NOVALUE;
    object _has_help_20826 = NOVALUE;
    object _has_question_20827 = NOVALUE;
    object _appended_opts_20847 = NOVALUE;
    object _11702 = NOVALUE;
    object _11699 = NOVALUE;
    object _11696 = NOVALUE;
    object _11693 = NOVALUE;
    object _11691 = NOVALUE;
    object _11690 = NOVALUE;
    object _11689 = NOVALUE;
    object _11688 = NOVALUE;
    object _11686 = NOVALUE;
    object _11685 = NOVALUE;
    object _11684 = NOVALUE;
    object _11682 = NOVALUE;
    object _11681 = NOVALUE;
    object _11680 = NOVALUE;
    object _11678 = NOVALUE;
    object _11677 = NOVALUE;
    object _11676 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:313		integer has_h = 0, has_help = 0, has_question = 0*/
    _has_h_20825 = 0;
    _has_help_20826 = 0;
    _has_question_20827 = 0;

    /** cmdline.e:314		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_20823)){
            _11676 = SEQ_PTR(_opts_20823)->length;
    }
    else {
        _11676 = 1;
    }
    {
        object _i_20829;
        _i_20829 = 1;
L1: 
        if (_i_20829 > _11676){
            goto L2; // [21] 107
        }

        /** cmdline.e:315			if equal(opts[i][SHORTNAME], "h") then*/
        _2 = (object)SEQ_PTR(_opts_20823);
        _11677 = (object)*(((s1_ptr)_2)->base + _i_20829);
        _2 = (object)SEQ_PTR(_11677);
        _11678 = (object)*(((s1_ptr)_2)->base + 1);
        _11677 = NOVALUE;
        if (_11678 == _11679)
        _11680 = 1;
        else if (IS_ATOM_INT(_11678) && IS_ATOM_INT(_11679))
        _11680 = 0;
        else
        _11680 = (compare(_11678, _11679) == 0);
        _11678 = NOVALUE;
        if (_11680 == 0)
        {
            _11680 = NOVALUE;
            goto L3; // [42] 53
        }
        else{
            _11680 = NOVALUE;
        }

        /** cmdline.e:316				has_h = 1*/
        _has_h_20825 = 1;
        goto L4; // [50] 77
L3: 

        /** cmdline.e:317			elsif equal(opts[i][SHORTNAME], "?") then*/
        _2 = (object)SEQ_PTR(_opts_20823);
        _11681 = (object)*(((s1_ptr)_2)->base + _i_20829);
        _2 = (object)SEQ_PTR(_11681);
        _11682 = (object)*(((s1_ptr)_2)->base + 1);
        _11681 = NOVALUE;
        if (_11682 == _11683)
        _11684 = 1;
        else if (IS_ATOM_INT(_11682) && IS_ATOM_INT(_11683))
        _11684 = 0;
        else
        _11684 = (compare(_11682, _11683) == 0);
        _11682 = NOVALUE;
        if (_11684 == 0)
        {
            _11684 = NOVALUE;
            goto L5; // [67] 76
        }
        else{
            _11684 = NOVALUE;
        }

        /** cmdline.e:318				has_question = 1*/
        _has_question_20827 = 1;
L5: 
L4: 

        /** cmdline.e:321			if equal(opts[i][LONGNAME], "help") then*/
        _2 = (object)SEQ_PTR(_opts_20823);
        _11685 = (object)*(((s1_ptr)_2)->base + _i_20829);
        _2 = (object)SEQ_PTR(_11685);
        _11686 = (object)*(((s1_ptr)_2)->base + 2);
        _11685 = NOVALUE;
        if (_11686 == _11687)
        _11688 = 1;
        else if (IS_ATOM_INT(_11686) && IS_ATOM_INT(_11687))
        _11688 = 0;
        else
        _11688 = (compare(_11686, _11687) == 0);
        _11686 = NOVALUE;
        if (_11688 == 0)
        {
            _11688 = NOVALUE;
            goto L6; // [91] 100
        }
        else{
            _11688 = NOVALUE;
        }

        /** cmdline.e:322				has_help = 1*/
        _has_help_20826 = 1;
L6: 

        /** cmdline.e:324		end for*/
        _i_20829 = _i_20829 + 1;
        goto L1; // [102] 28
L2: 
        ;
    }

    /** cmdline.e:326		if auto_help_switches then*/
    if (_auto_help_switches_20824 == 0)
    {
        goto L7; // [109] 249
    }
    else{
    }

    /** cmdline.e:327			integer appended_opts = 0*/
    _appended_opts_20847 = 0;

    /** cmdline.e:328			if not has_h and not has_help then*/
    _11689 = (_has_h_20825 == 0);
    if (_11689 == 0) {
        goto L8; // [122] 155
    }
    _11691 = (_has_help_20826 == 0);
    if (_11691 == 0)
    {
        DeRef(_11691);
        _11691 = NOVALUE;
        goto L8; // [130] 155
    }
    else{
        DeRef(_11691);
        _11691 = NOVALUE;
    }

    /** cmdline.e:329				opts = append(opts, {"h", "help", "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11679);
    ((intptr_t*)_2)[1] = _11679;
    RefDS(_11687);
    ((intptr_t*)_2)[2] = _11687;
    RefDS(_11692);
    ((intptr_t*)_2)[3] = _11692;
    RefDS(_11679);
    ((intptr_t*)_2)[4] = _11679;
    ((intptr_t*)_2)[5] = -1;
    _11693 = MAKE_SEQ(_1);
    RefDS(_11693);
    Append(&_opts_20823, _opts_20823, _11693);
    DeRefDS(_11693);
    _11693 = NOVALUE;

    /** cmdline.e:330				appended_opts = 1*/
    _appended_opts_20847 = 1;
    goto L9; // [152] 208
L8: 

    /** cmdline.e:332			elsif not has_h then*/
    if (_has_h_20825 != 0)
    goto LA; // [157] 182

    /** cmdline.e:333				opts = append(opts, {"h", 0, "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11679);
    ((intptr_t*)_2)[1] = _11679;
    ((intptr_t*)_2)[2] = 0;
    RefDS(_11692);
    ((intptr_t*)_2)[3] = _11692;
    RefDS(_11679);
    ((intptr_t*)_2)[4] = _11679;
    ((intptr_t*)_2)[5] = -1;
    _11696 = MAKE_SEQ(_1);
    RefDS(_11696);
    Append(&_opts_20823, _opts_20823, _11696);
    DeRefDS(_11696);
    _11696 = NOVALUE;

    /** cmdline.e:334				appended_opts = 1*/
    _appended_opts_20847 = 1;
    goto L9; // [179] 208
LA: 

    /** cmdline.e:336			elsif not has_help then*/
    if (_has_help_20826 != 0)
    goto LB; // [184] 207

    /** cmdline.e:337				opts = append(opts, {0, "help", "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    RefDS(_11687);
    ((intptr_t*)_2)[2] = _11687;
    RefDS(_11692);
    ((intptr_t*)_2)[3] = _11692;
    RefDS(_11679);
    ((intptr_t*)_2)[4] = _11679;
    ((intptr_t*)_2)[5] = -1;
    _11699 = MAKE_SEQ(_1);
    RefDS(_11699);
    Append(&_opts_20823, _opts_20823, _11699);
    DeRefDS(_11699);
    _11699 = NOVALUE;

    /** cmdline.e:338				appended_opts = 1*/
    _appended_opts_20847 = 1;
LB: 
L9: 

    /** cmdline.e:342			if not has_question then			*/
    if (_has_question_20827 != 0)
    goto LC; // [210] 233

    /** cmdline.e:343				opts = append(opts, {"?", 0, "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11683);
    ((intptr_t*)_2)[1] = _11683;
    ((intptr_t*)_2)[2] = 0;
    RefDS(_11692);
    ((intptr_t*)_2)[3] = _11692;
    RefDS(_11679);
    ((intptr_t*)_2)[4] = _11679;
    ((intptr_t*)_2)[5] = -1;
    _11702 = MAKE_SEQ(_1);
    RefDS(_11702);
    Append(&_opts_20823, _opts_20823, _11702);
    DeRefDS(_11702);
    _11702 = NOVALUE;

    /** cmdline.e:344				appended_opts = 1*/
    _appended_opts_20847 = 1;
LC: 

    /** cmdline.e:347			if appended_opts then*/
    if (_appended_opts_20847 == 0)
    {
        goto LD; // [235] 248
    }
    else{
    }

    /** cmdline.e:349				opts = standardize_opts(opts, 0)*/
    RefDS(_opts_20823);
    _0 = _opts_20823;
    _opts_20823 = _48standardize_opts(_opts_20823, 0);
    DeRefDS(_0);
LD: 
L7: 

    /** cmdline.e:352		return opts*/
    DeRef(_11689);
    _11689 = NOVALUE;
    return _opts_20823;
    ;
}


object _48standardize_opts(object _opts_20872, object _auto_help_switches_20873)
{
    object _11741 = NOVALUE;
    object _11740 = NOVALUE;
    object _11738 = NOVALUE;
    object _11737 = NOVALUE;
    object _11736 = NOVALUE;
    object _11735 = NOVALUE;
    object _11734 = NOVALUE;
    object _11733 = NOVALUE;
    object _11732 = NOVALUE;
    object _11731 = NOVALUE;
    object _11730 = NOVALUE;
    object _11729 = NOVALUE;
    object _11728 = NOVALUE;
    object _11727 = NOVALUE;
    object _11725 = NOVALUE;
    object _11724 = NOVALUE;
    object _11723 = NOVALUE;
    object _11722 = NOVALUE;
    object _11721 = NOVALUE;
    object _11720 = NOVALUE;
    object _11719 = NOVALUE;
    object _11718 = NOVALUE;
    object _11717 = NOVALUE;
    object _11716 = NOVALUE;
    object _11715 = NOVALUE;
    object _11714 = NOVALUE;
    object _11712 = NOVALUE;
    object _11710 = NOVALUE;
    object _11709 = NOVALUE;
    object _11708 = NOVALUE;
    object _11707 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** cmdline.e:357		opts = update_opts( opts )*/
    RefDS(_opts_20872);
    _0 = _opts_20872;
    _opts_20872 = _48update_opts(_opts_20872);
    DeRefDS(_0);

    /** cmdline.e:359		check_for_duplicates( opts )*/
    RefDS(_opts_20872);
    _48check_for_duplicates(_opts_20872);

    /** cmdline.e:361		opts = standardize_help_options( opts, auto_help_switches )*/
    RefDS(_opts_20872);
    _0 = _opts_20872;
    _opts_20872 = _48standardize_help_options(_opts_20872, _auto_help_switches_20873);
    DeRefDS(_0);

    /** cmdline.e:364		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_20872)){
            _11707 = SEQ_PTR(_opts_20872)->length;
    }
    else {
        _11707 = 1;
    }
    {
        object _i_20877;
        _i_20877 = 1;
L1: 
        if (_i_20877 > _11707){
            goto L2; // [32] 208
        }

        /** cmdline.e:365			if not find(HAS_PARAMETER, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_20872);
        _11708 = (object)*(((s1_ptr)_2)->base + _i_20877);
        _2 = (object)SEQ_PTR(_11708);
        _11709 = (object)*(((s1_ptr)_2)->base + 4);
        _11708 = NOVALUE;
        _11710 = find_from(112, _11709, 1);
        _11709 = NOVALUE;
        if (_11710 != 0)
        goto L3; // [54] 77
        _11710 = NOVALUE;

        /** cmdline.e:366				opts[i][OPTIONS] &= NO_PARAMETER*/
        _2 = (object)SEQ_PTR(_opts_20872);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opts_20872 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_20877 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _11714 = (object)*(((s1_ptr)_2)->base + 4);
        _11712 = NOVALUE;
        if (IS_SEQUENCE(_11714) && IS_ATOM(110)) {
            Append(&_11715, _11714, 110);
        }
        else if (IS_ATOM(_11714) && IS_SEQUENCE(110)) {
        }
        else {
            Concat((object_ptr)&_11715, _11714, 110);
            _11714 = NOVALUE;
        }
        _11714 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _11715;
        if( _1 != _11715 ){
            DeRef(_1);
        }
        _11715 = NOVALUE;
        _11712 = NOVALUE;
L3: 

        /** cmdline.e:369			if not find(MULTIPLE, opts[i][OPTIONS]) and not find(ONCE, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_20872);
        _11716 = (object)*(((s1_ptr)_2)->base + _i_20877);
        _2 = (object)SEQ_PTR(_11716);
        _11717 = (object)*(((s1_ptr)_2)->base + 4);
        _11716 = NOVALUE;
        _11718 = find_from(42, _11717, 1);
        _11717 = NOVALUE;
        _11719 = (_11718 == 0);
        _11718 = NOVALUE;
        if (_11719 == 0) {
            goto L4; // [95] 139
        }
        _2 = (object)SEQ_PTR(_opts_20872);
        _11721 = (object)*(((s1_ptr)_2)->base + _i_20877);
        _2 = (object)SEQ_PTR(_11721);
        _11722 = (object)*(((s1_ptr)_2)->base + 4);
        _11721 = NOVALUE;
        _11723 = find_from(49, _11722, 1);
        _11722 = NOVALUE;
        _11724 = (_11723 == 0);
        _11723 = NOVALUE;
        if (_11724 == 0)
        {
            DeRef(_11724);
            _11724 = NOVALUE;
            goto L4; // [116] 139
        }
        else{
            DeRef(_11724);
            _11724 = NOVALUE;
        }

        /** cmdline.e:370				opts[i][OPTIONS] &= ONCE*/
        _2 = (object)SEQ_PTR(_opts_20872);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opts_20872 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_20877 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _11727 = (object)*(((s1_ptr)_2)->base + 4);
        _11725 = NOVALUE;
        if (IS_SEQUENCE(_11727) && IS_ATOM(49)) {
            Append(&_11728, _11727, 49);
        }
        else if (IS_ATOM(_11727) && IS_SEQUENCE(49)) {
        }
        else {
            Concat((object_ptr)&_11728, _11727, 49);
            _11727 = NOVALUE;
        }
        _11727 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _11728;
        if( _1 != _11728 ){
            DeRef(_1);
        }
        _11728 = NOVALUE;
        _11725 = NOVALUE;
L4: 

        /** cmdline.e:373			if not find(HAS_CASE, opts[i][OPTIONS]) and not find(NO_CASE, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_20872);
        _11729 = (object)*(((s1_ptr)_2)->base + _i_20877);
        _2 = (object)SEQ_PTR(_11729);
        _11730 = (object)*(((s1_ptr)_2)->base + 4);
        _11729 = NOVALUE;
        _11731 = find_from(99, _11730, 1);
        _11730 = NOVALUE;
        _11732 = (_11731 == 0);
        _11731 = NOVALUE;
        if (_11732 == 0) {
            goto L5; // [157] 201
        }
        _2 = (object)SEQ_PTR(_opts_20872);
        _11734 = (object)*(((s1_ptr)_2)->base + _i_20877);
        _2 = (object)SEQ_PTR(_11734);
        _11735 = (object)*(((s1_ptr)_2)->base + 4);
        _11734 = NOVALUE;
        _11736 = find_from(105, _11735, 1);
        _11735 = NOVALUE;
        _11737 = (_11736 == 0);
        _11736 = NOVALUE;
        if (_11737 == 0)
        {
            DeRef(_11737);
            _11737 = NOVALUE;
            goto L5; // [178] 201
        }
        else{
            DeRef(_11737);
            _11737 = NOVALUE;
        }

        /** cmdline.e:374				opts[i][OPTIONS] &= NO_CASE*/
        _2 = (object)SEQ_PTR(_opts_20872);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opts_20872 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_20877 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _11740 = (object)*(((s1_ptr)_2)->base + 4);
        _11738 = NOVALUE;
        if (IS_SEQUENCE(_11740) && IS_ATOM(105)) {
            Append(&_11741, _11740, 105);
        }
        else if (IS_ATOM(_11740) && IS_SEQUENCE(105)) {
        }
        else {
            Concat((object_ptr)&_11741, _11740, 105);
            _11740 = NOVALUE;
        }
        _11740 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _11741;
        if( _1 != _11741 ){
            DeRef(_1);
        }
        _11741 = NOVALUE;
        _11738 = NOVALUE;
L5: 

        /** cmdline.e:376		end for*/
        _i_20877 = _i_20877 + 1;
        goto L1; // [203] 39
L2: 
        ;
    }

    /** cmdline.e:378		return opts*/
    DeRef(_11719);
    _11719 = NOVALUE;
    DeRef(_11732);
    _11732 = NOVALUE;
    return _opts_20872;
    ;
}


object _48print_help(object _opts_20918, object _cmds_20919)
{
    object _pad_size_20920 = NOVALUE;
    object _this_size_20921 = NOVALUE;
    object _extras_mandatory_20922 = NOVALUE;
    object _extras_opt_20923 = NOVALUE;
    object _param_name_20924 = NOVALUE;
    object _has_param_20925 = NOVALUE;
    object _11831 = NOVALUE;
    object _11830 = NOVALUE;
    object _11829 = NOVALUE;
    object _11828 = NOVALUE;
    object _11825 = NOVALUE;
    object _11824 = NOVALUE;
    object _11823 = NOVALUE;
    object _11822 = NOVALUE;
    object _11821 = NOVALUE;
    object _11820 = NOVALUE;
    object _11819 = NOVALUE;
    object _11818 = NOVALUE;
    object _11817 = NOVALUE;
    object _11816 = NOVALUE;
    object _11811 = NOVALUE;
    object _11810 = NOVALUE;
    object _11808 = NOVALUE;
    object _11807 = NOVALUE;
    object _11806 = NOVALUE;
    object _11805 = NOVALUE;
    object _11804 = NOVALUE;
    object _11803 = NOVALUE;
    object _11801 = NOVALUE;
    object _11800 = NOVALUE;
    object _11799 = NOVALUE;
    object _11795 = NOVALUE;
    object _11794 = NOVALUE;
    object _11792 = NOVALUE;
    object _11791 = NOVALUE;
    object _11790 = NOVALUE;
    object _11789 = NOVALUE;
    object _11788 = NOVALUE;
    object _11787 = NOVALUE;
    object _11786 = NOVALUE;
    object _11783 = NOVALUE;
    object _11782 = NOVALUE;
    object _11781 = NOVALUE;
    object _11779 = NOVALUE;
    object _11778 = NOVALUE;
    object _11777 = NOVALUE;
    object _11776 = NOVALUE;
    object _11775 = NOVALUE;
    object _11774 = NOVALUE;
    object _11773 = NOVALUE;
    object _11770 = NOVALUE;
    object _11769 = NOVALUE;
    object _11768 = NOVALUE;
    object _11766 = NOVALUE;
    object _11765 = NOVALUE;
    object _11764 = NOVALUE;
    object _11763 = NOVALUE;
    object _11762 = NOVALUE;
    object _11761 = NOVALUE;
    object _11760 = NOVALUE;
    object _11759 = NOVALUE;
    object _11758 = NOVALUE;
    object _11757 = NOVALUE;
    object _11756 = NOVALUE;
    object _11755 = NOVALUE;
    object _11754 = NOVALUE;
    object _11753 = NOVALUE;
    object _11752 = NOVALUE;
    object _11751 = NOVALUE;
    object _11750 = NOVALUE;
    object _11749 = NOVALUE;
    object _11748 = NOVALUE;
    object _11747 = NOVALUE;
    object _11746 = NOVALUE;
    object _11745 = NOVALUE;
    object _11744 = NOVALUE;
    object _11743 = NOVALUE;
    object _11742 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:384		integer pad_size = 0*/
    _pad_size_20920 = 0;

    /** cmdline.e:386		integer extras_mandatory = 0*/
    _extras_mandatory_20922 = 0;

    /** cmdline.e:387		integer extras_opt = 0*/
    _extras_opt_20923 = 0;

    /** cmdline.e:391		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_20918)){
            _11742 = SEQ_PTR(_opts_20918)->length;
    }
    else {
        _11742 = 1;
    }
    {
        object _i_20927;
        _i_20927 = 1;
L1: 
        if (_i_20927 > _11742){
            goto L2; // [25] 456
        }

        /** cmdline.e:392			this_size = 0*/
        _this_size_20921 = 0;

        /** cmdline.e:393			param_name = ""*/
        RefDS(_5);
        DeRef(_param_name_20924);
        _param_name_20924 = _5;

        /** cmdline.e:395			if atom(opts[i][SHORTNAME]) and opts[i][SHORTNAME] = HEADER then*/
        _2 = (object)SEQ_PTR(_opts_20918);
        _11743 = (object)*(((s1_ptr)_2)->base + _i_20927);
        _2 = (object)SEQ_PTR(_11743);
        _11744 = (object)*(((s1_ptr)_2)->base + 1);
        _11743 = NOVALUE;
        _11745 = IS_ATOM(_11744);
        _11744 = NOVALUE;
        if (_11745 == 0) {
            goto L3; // [57] 82
        }
        _2 = (object)SEQ_PTR(_opts_20918);
        _11747 = (object)*(((s1_ptr)_2)->base + _i_20927);
        _2 = (object)SEQ_PTR(_11747);
        _11748 = (object)*(((s1_ptr)_2)->base + 1);
        _11747 = NOVALUE;
        if (IS_ATOM_INT(_11748)) {
            _11749 = (_11748 == 72);
        }
        else {
            _11749 = binary_op(EQUALS, _11748, 72);
        }
        _11748 = NOVALUE;
        if (_11749 == 0) {
            DeRef(_11749);
            _11749 = NOVALUE;
            goto L3; // [74] 82
        }
        else {
            if (!IS_ATOM_INT(_11749) && DBL_PTR(_11749)->dbl == 0.0){
                DeRef(_11749);
                _11749 = NOVALUE;
                goto L3; // [74] 82
            }
            DeRef(_11749);
            _11749 = NOVALUE;
        }
        DeRef(_11749);
        _11749 = NOVALUE;

        /** cmdline.e:396				continue*/
        goto L4; // [79] 451
L3: 

        /** cmdline.e:399			if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_20918);
        _11750 = (object)*(((s1_ptr)_2)->base + _i_20927);
        _2 = (object)SEQ_PTR(_11750);
        _11751 = (object)*(((s1_ptr)_2)->base + 1);
        _11750 = NOVALUE;
        _11752 = IS_ATOM(_11751);
        _11751 = NOVALUE;
        if (_11752 == 0) {
            goto L5; // [95] 148
        }
        _2 = (object)SEQ_PTR(_opts_20918);
        _11754 = (object)*(((s1_ptr)_2)->base + _i_20927);
        _2 = (object)SEQ_PTR(_11754);
        _11755 = (object)*(((s1_ptr)_2)->base + 2);
        _11754 = NOVALUE;
        _11756 = IS_ATOM(_11755);
        _11755 = NOVALUE;
        if (_11756 == 0)
        {
            _11756 = NOVALUE;
            goto L5; // [111] 148
        }
        else{
            _11756 = NOVALUE;
        }

        /** cmdline.e:400				extras_opt = i*/
        _extras_opt_20923 = _i_20927;

        /** cmdline.e:401				if find(MANDATORY, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_20918);
        _11757 = (object)*(((s1_ptr)_2)->base + _i_20927);
        _2 = (object)SEQ_PTR(_11757);
        _11758 = (object)*(((s1_ptr)_2)->base + 4);
        _11757 = NOVALUE;
        _11759 = find_from(109, _11758, 1);
        _11758 = NOVALUE;
        if (_11759 == 0)
        {
            _11759 = NOVALUE;
            goto L4; // [134] 451
        }
        else{
            _11759 = NOVALUE;
        }

        /** cmdline.e:402					extras_mandatory = 1*/
        _extras_mandatory_20922 = 1;

        /** cmdline.e:405				continue*/
        goto L4; // [145] 451
L5: 

        /** cmdline.e:408			if sequence(opts[i][SHORTNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_20918);
        _11760 = (object)*(((s1_ptr)_2)->base + _i_20927);
        _2 = (object)SEQ_PTR(_11760);
        _11761 = (object)*(((s1_ptr)_2)->base + 1);
        _11760 = NOVALUE;
        _11762 = IS_SEQUENCE(_11761);
        _11761 = NOVALUE;
        if (_11762 == 0)
        {
            _11762 = NOVALUE;
            goto L6; // [161] 214
        }
        else{
            _11762 = NOVALUE;
        }

        /** cmdline.e:409				this_size += length(opts[i][SHORTNAME]) + 1 -- Allow for "-"*/
        _2 = (object)SEQ_PTR(_opts_20918);
        _11763 = (object)*(((s1_ptr)_2)->base + _i_20927);
        _2 = (object)SEQ_PTR(_11763);
        _11764 = (object)*(((s1_ptr)_2)->base + 1);
        _11763 = NOVALUE;
        if (IS_SEQUENCE(_11764)){
                _11765 = SEQ_PTR(_11764)->length;
        }
        else {
            _11765 = 1;
        }
        _11764 = NOVALUE;
        _11766 = _11765 + 1;
        _11765 = NOVALUE;
        _this_size_20921 = _this_size_20921 + _11766;
        _11766 = NOVALUE;

        /** cmdline.e:410				if find(MANDATORY, opts[i][OPTIONS]) = 0 then*/
        _2 = (object)SEQ_PTR(_opts_20918);
        _11768 = (object)*(((s1_ptr)_2)->base + _i_20927);
        _2 = (object)SEQ_PTR(_11768);
        _11769 = (object)*(((s1_ptr)_2)->base + 4);
        _11768 = NOVALUE;
        _11770 = find_from(109, _11769, 1);
        _11769 = NOVALUE;
        if (_11770 != 0)
        goto L7; // [202] 213

        /** cmdline.e:411					this_size += 2 -- Allow for '[' ']'*/
        _this_size_20921 = _this_size_20921 + 2;
L7: 
L6: 

        /** cmdline.e:415			if sequence(opts[i][LONGNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_20918);
        _11773 = (object)*(((s1_ptr)_2)->base + _i_20927);
        _2 = (object)SEQ_PTR(_11773);
        _11774 = (object)*(((s1_ptr)_2)->base + 2);
        _11773 = NOVALUE;
        _11775 = IS_SEQUENCE(_11774);
        _11774 = NOVALUE;
        if (_11775 == 0)
        {
            _11775 = NOVALUE;
            goto L8; // [227] 280
        }
        else{
            _11775 = NOVALUE;
        }

        /** cmdline.e:416				this_size += length(opts[i][LONGNAME]) + 2 -- Allow for "--"*/
        _2 = (object)SEQ_PTR(_opts_20918);
        _11776 = (object)*(((s1_ptr)_2)->base + _i_20927);
        _2 = (object)SEQ_PTR(_11776);
        _11777 = (object)*(((s1_ptr)_2)->base + 2);
        _11776 = NOVALUE;
        if (IS_SEQUENCE(_11777)){
                _11778 = SEQ_PTR(_11777)->length;
        }
        else {
            _11778 = 1;
        }
        _11777 = NOVALUE;
        _11779 = _11778 + 2;
        _11778 = NOVALUE;
        _this_size_20921 = _this_size_20921 + _11779;
        _11779 = NOVALUE;

        /** cmdline.e:417				if find(MANDATORY, opts[i][OPTIONS]) = 0 then*/
        _2 = (object)SEQ_PTR(_opts_20918);
        _11781 = (object)*(((s1_ptr)_2)->base + _i_20927);
        _2 = (object)SEQ_PTR(_11781);
        _11782 = (object)*(((s1_ptr)_2)->base + 4);
        _11781 = NOVALUE;
        _11783 = find_from(109, _11782, 1);
        _11782 = NOVALUE;
        if (_11783 != 0)
        goto L9; // [268] 279

        /** cmdline.e:418					this_size += 2 -- Allow for '[' ']'*/
        _this_size_20921 = _this_size_20921 + 2;
L9: 
L8: 

        /** cmdline.e:422			if sequence(opts[i][SHORTNAME]) and sequence(opts[i][LONGNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_20918);
        _11786 = (object)*(((s1_ptr)_2)->base + _i_20927);
        _2 = (object)SEQ_PTR(_11786);
        _11787 = (object)*(((s1_ptr)_2)->base + 1);
        _11786 = NOVALUE;
        _11788 = IS_SEQUENCE(_11787);
        _11787 = NOVALUE;
        if (_11788 == 0) {
            goto LA; // [293] 319
        }
        _2 = (object)SEQ_PTR(_opts_20918);
        _11790 = (object)*(((s1_ptr)_2)->base + _i_20927);
        _2 = (object)SEQ_PTR(_11790);
        _11791 = (object)*(((s1_ptr)_2)->base + 2);
        _11790 = NOVALUE;
        _11792 = IS_SEQUENCE(_11791);
        _11791 = NOVALUE;
        if (_11792 == 0)
        {
            _11792 = NOVALUE;
            goto LA; // [309] 319
        }
        else{
            _11792 = NOVALUE;
        }

        /** cmdline.e:423				this_size += 2 -- Allow for ", " between short and long names*/
        _this_size_20921 = _this_size_20921 + 2;
LA: 

        /** cmdline.e:426			has_param = find(HAS_PARAMETER, opts[i][OPTIONS])*/
        _2 = (object)SEQ_PTR(_opts_20918);
        _11794 = (object)*(((s1_ptr)_2)->base + _i_20927);
        _2 = (object)SEQ_PTR(_11794);
        _11795 = (object)*(((s1_ptr)_2)->base + 4);
        _11794 = NOVALUE;
        _has_param_20925 = find_from(112, _11795, 1);
        _11795 = NOVALUE;

        /** cmdline.e:427			if has_param != 0 then*/
        if (_has_param_20925 == 0)
        goto LB; // [336] 437

        /** cmdline.e:428				this_size += 1 -- Allow for " "*/
        _this_size_20921 = _this_size_20921 + 1;

        /** cmdline.e:429				if has_param < length(opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_20918);
        _11799 = (object)*(((s1_ptr)_2)->base + _i_20927);
        _2 = (object)SEQ_PTR(_11799);
        _11800 = (object)*(((s1_ptr)_2)->base + 4);
        _11799 = NOVALUE;
        if (IS_SEQUENCE(_11800)){
                _11801 = SEQ_PTR(_11800)->length;
        }
        else {
            _11801 = 1;
        }
        _11800 = NOVALUE;
        if (_has_param_20925 >= _11801)
        goto LC; // [359] 413

        /** cmdline.e:431					if sequence(opts[i][OPTIONS][has_param]) then*/
        _2 = (object)SEQ_PTR(_opts_20918);
        _11803 = (object)*(((s1_ptr)_2)->base + _i_20927);
        _2 = (object)SEQ_PTR(_11803);
        _11804 = (object)*(((s1_ptr)_2)->base + 4);
        _11803 = NOVALUE;
        _2 = (object)SEQ_PTR(_11804);
        _11805 = (object)*(((s1_ptr)_2)->base + _has_param_20925);
        _11804 = NOVALUE;
        _11806 = IS_SEQUENCE(_11805);
        _11805 = NOVALUE;
        if (_11806 == 0)
        {
            _11806 = NOVALUE;
            goto LD; // [380] 402
        }
        else{
            _11806 = NOVALUE;
        }

        /** cmdline.e:432						param_name = opts[i][OPTIONS][has_param]*/
        _2 = (object)SEQ_PTR(_opts_20918);
        _11807 = (object)*(((s1_ptr)_2)->base + _i_20927);
        _2 = (object)SEQ_PTR(_11807);
        _11808 = (object)*(((s1_ptr)_2)->base + 4);
        _11807 = NOVALUE;
        DeRef(_param_name_20924);
        _2 = (object)SEQ_PTR(_11808);
        _param_name_20924 = (object)*(((s1_ptr)_2)->base + _has_param_20925);
        Ref(_param_name_20924);
        _11808 = NOVALUE;
        goto LE; // [399] 421
LD: 

        /** cmdline.e:434						param_name = "x"*/
        RefDS(_11640);
        DeRef(_param_name_20924);
        _param_name_20924 = _11640;
        goto LE; // [410] 421
LC: 

        /** cmdline.e:437					param_name = "x"*/
        RefDS(_11640);
        DeRef(_param_name_20924);
        _param_name_20924 = _11640;
LE: 

        /** cmdline.e:439				this_size += 2 + length(param_name)*/
        if (IS_SEQUENCE(_param_name_20924)){
                _11810 = SEQ_PTR(_param_name_20924)->length;
        }
        else {
            _11810 = 1;
        }
        _11811 = 2 + _11810;
        _11810 = NOVALUE;
        _this_size_20921 = _this_size_20921 + _11811;
        _11811 = NOVALUE;
LB: 

        /** cmdline.e:442			if pad_size < this_size then*/
        if (_pad_size_20920 >= _this_size_20921)
        goto LF; // [439] 449

        /** cmdline.e:443				pad_size = this_size*/
        _pad_size_20920 = _this_size_20921;
LF: 

        /** cmdline.e:445		end for*/
L4: 
        _i_20927 = _i_20927 + 1;
        goto L1; // [451] 32
L2: 
        ;
    }

    /** cmdline.e:446		pad_size += 3 -- Allow for minimum gap between cmd and its description*/
    _pad_size_20920 = _pad_size_20920 + 3;

    /** cmdline.e:448		printf(1, "%s options:\n", {cmds[2]})*/
    _2 = (object)SEQ_PTR(_cmds_20919);
    _11816 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_11816);
    ((intptr_t*)_2)[1] = _11816;
    _11817 = MAKE_SEQ(_1);
    _11816 = NOVALUE;
    EPrintf(1, _11815, _11817);
    DeRefDS(_11817);
    _11817 = NOVALUE;

    /** cmdline.e:450		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_20918)){
            _11818 = SEQ_PTR(_opts_20918)->length;
    }
    else {
        _11818 = 1;
    }
    {
        object _i_21019;
        _i_21019 = 1;
L10: 
        if (_i_21019 > _11818){
            goto L11; // [481] 574
        }

        /** cmdline.e:451			if atom(opts[i][1]) and opts[i][1] = HEADER then*/
        _2 = (object)SEQ_PTR(_opts_20918);
        _11819 = (object)*(((s1_ptr)_2)->base + _i_21019);
        _2 = (object)SEQ_PTR(_11819);
        _11820 = (object)*(((s1_ptr)_2)->base + 1);
        _11819 = NOVALUE;
        _11821 = IS_ATOM(_11820);
        _11820 = NOVALUE;
        if (_11821 == 0) {
            goto L12; // [501] 557
        }
        _2 = (object)SEQ_PTR(_opts_20918);
        _11823 = (object)*(((s1_ptr)_2)->base + _i_21019);
        _2 = (object)SEQ_PTR(_11823);
        _11824 = (object)*(((s1_ptr)_2)->base + 1);
        _11823 = NOVALUE;
        if (IS_ATOM_INT(_11824)) {
            _11825 = (_11824 == 72);
        }
        else {
            _11825 = binary_op(EQUALS, _11824, 72);
        }
        _11824 = NOVALUE;
        if (_11825 == 0) {
            DeRef(_11825);
            _11825 = NOVALUE;
            goto L12; // [518] 557
        }
        else {
            if (!IS_ATOM_INT(_11825) && DBL_PTR(_11825)->dbl == 0.0){
                DeRef(_11825);
                _11825 = NOVALUE;
                goto L12; // [518] 557
            }
            DeRef(_11825);
            _11825 = NOVALUE;
        }
        DeRef(_11825);
        _11825 = NOVALUE;

        /** cmdline.e:452				if i > 1 then*/
        if (_i_21019 <= 1)
        goto L13; // [523] 534

        /** cmdline.e:453					printf(1, "\n")*/
        EPrintf(1, _8204, _5);
L13: 

        /** cmdline.e:456				printf(1, "%s\n", { opts[i][2] })*/
        _2 = (object)SEQ_PTR(_opts_20918);
        _11828 = (object)*(((s1_ptr)_2)->base + _i_21019);
        _2 = (object)SEQ_PTR(_11828);
        _11829 = (object)*(((s1_ptr)_2)->base + 2);
        _11828 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_11829);
        ((intptr_t*)_2)[1] = _11829;
        _11830 = MAKE_SEQ(_1);
        _11829 = NOVALUE;
        EPrintf(1, _11827, _11830);
        DeRefDS(_11830);
        _11830 = NOVALUE;

        /** cmdline.e:457				continue*/
        goto L14; // [554] 569
L12: 

        /** cmdline.e:460			print_option_help( opts[i], pad_size )*/
        _2 = (object)SEQ_PTR(_opts_20918);
        _11831 = (object)*(((s1_ptr)_2)->base + _i_21019);
        Ref(_11831);
        _48print_option_help(_11831, _pad_size_20920);
        _11831 = NOVALUE;

        /** cmdline.e:461		end for*/
L14: 
        _i_21019 = _i_21019 + 1;
        goto L10; // [569] 488
L11: 
        ;
    }

    /** cmdline.e:463		print_extras_help( opts, extras_mandatory, extras_opt )*/
    RefDS(_opts_20918);
    _48print_extras_help(_opts_20918, _extras_mandatory_20922, _extras_opt_20923);

    /** cmdline.e:465		return pad_size*/
    DeRefDS(_opts_20918);
    DeRefDS(_cmds_20919);
    DeRef(_param_name_20924);
    _11764 = NOVALUE;
    _11800 = NOVALUE;
    _11777 = NOVALUE;
    return _pad_size_20920;
    ;
}


void _48print_extras_help(object _opts_21040, object _extras_mandatory_21041, object _extras_opt_21042)
{
    object _11848 = NOVALUE;
    object _11847 = NOVALUE;
    object _11846 = NOVALUE;
    object _11844 = NOVALUE;
    object _11843 = NOVALUE;
    object _11842 = NOVALUE;
    object _11839 = NOVALUE;
    object _11838 = NOVALUE;
    object _11837 = NOVALUE;
    object _11835 = NOVALUE;
    object _11834 = NOVALUE;
    object _11833 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:470		if extras_mandatory != 0 then*/
    if (_extras_mandatory_21041 == 0)
    goto L1; // [9] 64

    /** cmdline.e:471			if length(opts[extras_opt][DESCRIPTION]) > 0 then*/
    _2 = (object)SEQ_PTR(_opts_21040);
    _11833 = (object)*(((s1_ptr)_2)->base + _extras_opt_21042);
    _2 = (object)SEQ_PTR(_11833);
    _11834 = (object)*(((s1_ptr)_2)->base + 3);
    _11833 = NOVALUE;
    if (IS_SEQUENCE(_11834)){
            _11835 = SEQ_PTR(_11834)->length;
    }
    else {
        _11835 = 1;
    }
    _11834 = NOVALUE;
    if (_11835 <= 0)
    goto L2; // [26] 55

    /** cmdline.e:472				puts(1, "\n" & opts[extras_opt][DESCRIPTION])*/
    _2 = (object)SEQ_PTR(_opts_21040);
    _11837 = (object)*(((s1_ptr)_2)->base + _extras_opt_21042);
    _2 = (object)SEQ_PTR(_11837);
    _11838 = (object)*(((s1_ptr)_2)->base + 3);
    _11837 = NOVALUE;
    if (IS_SEQUENCE(_8204) && IS_ATOM(_11838)) {
        Ref(_11838);
        Append(&_11839, _8204, _11838);
    }
    else if (IS_ATOM(_8204) && IS_SEQUENCE(_11838)) {
    }
    else {
        Concat((object_ptr)&_11839, _8204, _11838);
    }
    _11838 = NOVALUE;
    EPuts(1, _11839); // DJP 
    DeRefDS(_11839);
    _11839 = NOVALUE;

    /** cmdline.e:473				puts(1, '\n')*/
    EPuts(1, 10); // DJP 
    goto L3; // [52] 120
L2: 

    /** cmdline.e:475				puts(1, "One or more additional arguments are also required\n")*/
    EPuts(1, _11840); // DJP 
    goto L3; // [61] 120
L1: 

    /** cmdline.e:477		elsif extras_opt > 0 then*/
    if (_extras_opt_21042 <= 0)
    goto L4; // [66] 119

    /** cmdline.e:478			if length(opts[extras_opt][DESCRIPTION]) > 0 then*/
    _2 = (object)SEQ_PTR(_opts_21040);
    _11842 = (object)*(((s1_ptr)_2)->base + _extras_opt_21042);
    _2 = (object)SEQ_PTR(_11842);
    _11843 = (object)*(((s1_ptr)_2)->base + 3);
    _11842 = NOVALUE;
    if (IS_SEQUENCE(_11843)){
            _11844 = SEQ_PTR(_11843)->length;
    }
    else {
        _11844 = 1;
    }
    _11843 = NOVALUE;
    if (_11844 <= 0)
    goto L5; // [83] 112

    /** cmdline.e:479				puts(1, "\n" & opts[extras_opt][DESCRIPTION])*/
    _2 = (object)SEQ_PTR(_opts_21040);
    _11846 = (object)*(((s1_ptr)_2)->base + _extras_opt_21042);
    _2 = (object)SEQ_PTR(_11846);
    _11847 = (object)*(((s1_ptr)_2)->base + 3);
    _11846 = NOVALUE;
    if (IS_SEQUENCE(_8204) && IS_ATOM(_11847)) {
        Ref(_11847);
        Append(&_11848, _8204, _11847);
    }
    else if (IS_ATOM(_8204) && IS_SEQUENCE(_11847)) {
    }
    else {
        Concat((object_ptr)&_11848, _8204, _11847);
    }
    _11847 = NOVALUE;
    EPuts(1, _11848); // DJP 
    DeRefDS(_11848);
    _11848 = NOVALUE;

    /** cmdline.e:480				puts(1, '\n')*/
    EPuts(1, 10); // DJP 
    goto L6; // [109] 118
L5: 

    /** cmdline.e:482				puts(1, "One or more additional arguments can be supplied.\n")*/
    EPuts(1, _11849); // DJP 
L6: 
L4: 
L3: 

    /** cmdline.e:485	end procedure*/
    DeRefDS(_opts_21040);
    _11843 = NOVALUE;
    _11834 = NOVALUE;
    return;
    ;
}


void _48local_help(object _opts_21069, object _add_help_rid_21070, object _cmds_21071, object _std_21073, object _parse_options_21074)
{
    object _cmd_21075 = NOVALUE;
    object _is_mandatory_21076 = NOVALUE;
    object _extras_mandatory_21077 = NOVALUE;
    object _extras_opt_21078 = NOVALUE;
    object _auto_help_21079 = NOVALUE;
    object _po_21080 = NOVALUE;
    object _msg_inlined_crash_at_94_21099 = NOVALUE;
    object _pad_size_21106 = NOVALUE;
    object _11858 = NOVALUE;
    object _11855 = NOVALUE;
    object _11853 = NOVALUE;
    object _11851 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:492		integer extras_mandatory = 0*/
    _extras_mandatory_21077 = 0;

    /** cmdline.e:493		integer extras_opt = 0*/
    _extras_opt_21078 = 0;

    /** cmdline.e:494		integer auto_help = 1*/
    _auto_help_21079 = 1;

    /** cmdline.e:496		integer po = 1*/
    _po_21080 = 1;

    /** cmdline.e:497		if atom(parse_options) then*/
    _11851 = IS_ATOM(_parse_options_21074);
    if (_11851 == 0)
    {
        _11851 = NOVALUE;
        goto L1; // [32] 42
    }
    else{
        _11851 = NOVALUE;
    }

    /** cmdline.e:498			parse_options = {parse_options}*/
    _0 = _parse_options_21074;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_parse_options_21074);
    ((intptr_t*)_2)[1] = _parse_options_21074;
    _parse_options_21074 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** cmdline.e:501		while po <= length(parse_options) do*/
L2: 
    if (IS_SEQUENCE(_parse_options_21074)){
            _11853 = SEQ_PTR(_parse_options_21074)->length;
    }
    else {
        _11853 = 1;
    }
    if (_po_21080 > _11853)
    goto L3; // [50] 143

    /** cmdline.e:502			switch parse_options[po] do*/
    _2 = (object)SEQ_PTR(_parse_options_21074);
    _11855 = (object)*(((s1_ptr)_2)->base + _po_21080);
    if (IS_SEQUENCE(_11855) ){
        goto L4; // [60] 129
    }
    if(!IS_ATOM_INT(_11855)){
        if( (DBL_PTR(_11855)->dbl != (eudouble) ((object) DBL_PTR(_11855)->dbl) ) ){
            goto L4; // [60] 129
        }
        _0 = (object) DBL_PTR(_11855)->dbl;
    }
    else {
        _0 = _11855;
    };
    _11855 = NOVALUE;
    switch ( _0 ){ 

        /** cmdline.e:503				case HELP_RID then*/
        case 1:

        /** cmdline.e:504					if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_21074)){
                _11858 = SEQ_PTR(_parse_options_21074)->length;
        }
        else {
            _11858 = 1;
        }
        if (_po_21080 >= _11858)
        goto L5; // [74] 93

        /** cmdline.e:505						po += 1*/
        _po_21080 = _po_21080 + 1;

        /** cmdline.e:506						add_help_rid = parse_options[po]*/
        DeRef(_add_help_rid_21070);
        _2 = (object)SEQ_PTR(_parse_options_21074);
        _add_help_rid_21070 = (object)*(((s1_ptr)_2)->base + _po_21080);
        Ref(_add_help_rid_21070);
        goto L6; // [90] 132
L5: 

        /** cmdline.e:508						error:crash("HELP_RID was given to cmd_parse with no routine_id")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_94_21099);
        _msg_inlined_crash_at_94_21099 = EPrintf(-9999999, _11862, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_94_21099);

        /** error.e:53	end procedure*/
        goto L7; // [108] 111
L7: 
        DeRefi(_msg_inlined_crash_at_94_21099);
        _msg_inlined_crash_at_94_21099 = NOVALUE;
        goto L6; // [114] 132

        /** cmdline.e:511				case NO_HELP then*/
        case 9:

        /** cmdline.e:512					auto_help = 0*/
        _auto_help_21079 = 0;
        goto L6; // [125] 132

        /** cmdline.e:514				case else*/
        default:
L4: 
    ;}L6: 

    /** cmdline.e:518			po += 1*/
    _po_21080 = _po_21080 + 1;

    /** cmdline.e:519		end while*/
    goto L2; // [140] 47
L3: 

    /** cmdline.e:521		if std = 0 then*/
    if (_std_21073 != 0)
    goto L8; // [145] 159

    /** cmdline.e:522			opts = standardize_opts(opts, auto_help)*/
    RefDS(_opts_21069);
    _0 = _opts_21069;
    _opts_21069 = _48standardize_opts(_opts_21069, _auto_help_21079);
    DeRefDS(_0);
L8: 

    /** cmdline.e:525		integer pad_size = print_help( opts, cmds )*/
    RefDS(_opts_21069);
    RefDS(_cmds_21071);
    _pad_size_21106 = _48print_help(_opts_21069, _cmds_21071);
    if (!IS_ATOM_INT(_pad_size_21106)) {
        _1 = (object)(DBL_PTR(_pad_size_21106)->dbl);
        DeRefDS(_pad_size_21106);
        _pad_size_21106 = _1;
    }

    /** cmdline.e:527		call_user_help( add_help_rid )*/
    Ref(_add_help_rid_21070);
    _48call_user_help(_add_help_rid_21070);

    /** cmdline.e:529	end procedure*/
    DeRefDS(_opts_21069);
    DeRef(_add_help_rid_21070);
    DeRefDS(_cmds_21071);
    DeRef(_parse_options_21074);
    return;
    ;
}


void _48call_user_help(object _add_help_rid_21111)
{
    object _11882 = NOVALUE;
    object _11881 = NOVALUE;
    object _11880 = NOVALUE;
    object _11879 = NOVALUE;
    object _11877 = NOVALUE;
    object _11876 = NOVALUE;
    object _11875 = NOVALUE;
    object _11874 = NOVALUE;
    object _11873 = NOVALUE;
    object _11871 = NOVALUE;
    object _11869 = NOVALUE;
    object _11867 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:532		if atom(add_help_rid) then*/
    _11867 = IS_ATOM(_add_help_rid_21111);
    if (_11867 == 0)
    {
        _11867 = NOVALUE;
        goto L1; // [6] 34
    }
    else{
        _11867 = NOVALUE;
    }

    /** cmdline.e:533			if add_help_rid >= 0 then*/
    if (binary_op_a(LESS, _add_help_rid_21111, 0)){
        goto L2; // [11] 142
    }

    /** cmdline.e:534				puts(1, "\n")*/
    EPuts(1, _8204); // DJP 

    /** cmdline.e:535				call_proc(add_help_rid, {})*/
    _0 = (object)_00[_add_help_rid_21111].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** cmdline.e:536				puts(1, "\n")*/
    EPuts(1, _8204); // DJP 
    goto L2; // [31] 142
L1: 

    /** cmdline.e:539			if length(add_help_rid) > 0 then*/
    if (IS_SEQUENCE(_add_help_rid_21111)){
            _11869 = SEQ_PTR(_add_help_rid_21111)->length;
    }
    else {
        _11869 = 1;
    }
    if (_11869 <= 0)
    goto L3; // [39] 141

    /** cmdline.e:540				puts(1, "\n")*/
    EPuts(1, _8204); // DJP 

    /** cmdline.e:541				if types:t_display(add_help_rid) then*/
    Ref(_add_help_rid_21111);
    _11871 = _9t_display(_add_help_rid_21111);
    if (_11871 == 0) {
        DeRef(_11871);
        _11871 = NOVALUE;
        goto L4; // [54] 64
    }
    else {
        if (!IS_ATOM_INT(_11871) && DBL_PTR(_11871)->dbl == 0.0){
            DeRef(_11871);
            _11871 = NOVALUE;
            goto L4; // [54] 64
        }
        DeRef(_11871);
        _11871 = NOVALUE;
    }
    DeRef(_11871);
    _11871 = NOVALUE;

    /** cmdline.e:542					add_help_rid = {add_help_rid}*/
    _0 = _add_help_rid_21111;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_add_help_rid_21111);
    ((intptr_t*)_2)[1] = _add_help_rid_21111;
    _add_help_rid_21111 = MAKE_SEQ(_1);
    DeRef(_0);
L4: 

    /** cmdline.e:545				for i = 1 to length(add_help_rid) do*/
    if (IS_SEQUENCE(_add_help_rid_21111)){
            _11873 = SEQ_PTR(_add_help_rid_21111)->length;
    }
    else {
        _11873 = 1;
    }
    {
        object _i_21124;
        _i_21124 = 1;
L5: 
        if (_i_21124 > _11873){
            goto L6; // [69] 135
        }

        /** cmdline.e:546					puts(1, add_help_rid[i])*/
        _2 = (object)SEQ_PTR(_add_help_rid_21111);
        _11874 = (object)*(((s1_ptr)_2)->base + _i_21124);
        EPuts(1, _11874); // DJP 
        _11874 = NOVALUE;

        /** cmdline.e:547					if length(add_help_rid[i]) = 0 or add_help_rid[i][$] != '\n' then*/
        _2 = (object)SEQ_PTR(_add_help_rid_21111);
        _11875 = (object)*(((s1_ptr)_2)->base + _i_21124);
        if (IS_SEQUENCE(_11875)){
                _11876 = SEQ_PTR(_11875)->length;
        }
        else {
            _11876 = 1;
        }
        _11875 = NOVALUE;
        _11877 = (_11876 == 0);
        _11876 = NOVALUE;
        if (_11877 != 0) {
            goto L7; // [98] 122
        }
        _2 = (object)SEQ_PTR(_add_help_rid_21111);
        _11879 = (object)*(((s1_ptr)_2)->base + _i_21124);
        if (IS_SEQUENCE(_11879)){
                _11880 = SEQ_PTR(_11879)->length;
        }
        else {
            _11880 = 1;
        }
        _2 = (object)SEQ_PTR(_11879);
        _11881 = (object)*(((s1_ptr)_2)->base + _11880);
        _11879 = NOVALUE;
        if (IS_ATOM_INT(_11881)) {
            _11882 = (_11881 != 10);
        }
        else {
            _11882 = binary_op(NOTEQ, _11881, 10);
        }
        _11881 = NOVALUE;
        if (_11882 == 0) {
            DeRef(_11882);
            _11882 = NOVALUE;
            goto L8; // [118] 128
        }
        else {
            if (!IS_ATOM_INT(_11882) && DBL_PTR(_11882)->dbl == 0.0){
                DeRef(_11882);
                _11882 = NOVALUE;
                goto L8; // [118] 128
            }
            DeRef(_11882);
            _11882 = NOVALUE;
        }
        DeRef(_11882);
        _11882 = NOVALUE;
L7: 

        /** cmdline.e:548						puts(1, '\n')*/
        EPuts(1, 10); // DJP 
L8: 

        /** cmdline.e:550				end for*/
        _i_21124 = _i_21124 + 1;
        goto L5; // [130] 76
L6: 
        ;
    }

    /** cmdline.e:552				puts(1, "\n")*/
    EPuts(1, _8204); // DJP 
L3: 
L2: 

    /** cmdline.e:555	end procedure*/
    DeRef(_add_help_rid_21111);
    _11875 = NOVALUE;
    DeRef(_11877);
    _11877 = NOVALUE;
    return;
    ;
}


void _48print_option_help(object _opt_21138, object _pad_size_21139)
{
    object _has_param_21146 = NOVALUE;
    object _param_name_21149 = NOVALUE;
    object _is_mandatory_21165 = NOVALUE;
    object _cmd_21169 = NOVALUE;
    object _11941 = NOVALUE;
    object _11940 = NOVALUE;
    object _11939 = NOVALUE;
    object _11938 = NOVALUE;
    object _11937 = NOVALUE;
    object _11936 = NOVALUE;
    object _11935 = NOVALUE;
    object _11932 = NOVALUE;
    object _11928 = NOVALUE;
    object _11925 = NOVALUE;
    object _11924 = NOVALUE;
    object _11917 = NOVALUE;
    object _11916 = NOVALUE;
    object _11915 = NOVALUE;
    object _11911 = NOVALUE;
    object _11908 = NOVALUE;
    object _11907 = NOVALUE;
    object _11904 = NOVALUE;
    object _11903 = NOVALUE;
    object _11901 = NOVALUE;
    object _11900 = NOVALUE;
    object _11898 = NOVALUE;
    object _11897 = NOVALUE;
    object _11896 = NOVALUE;
    object _11895 = NOVALUE;
    object _11892 = NOVALUE;
    object _11891 = NOVALUE;
    object _11888 = NOVALUE;
    object _11887 = NOVALUE;
    object _11886 = NOVALUE;
    object _11885 = NOVALUE;
    object _11884 = NOVALUE;
    object _11883 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:558		if atom(opt[SHORTNAME]) and atom(opt[LONGNAME]) then*/
    _2 = (object)SEQ_PTR(_opt_21138);
    _11883 = (object)*(((s1_ptr)_2)->base + 1);
    _11884 = IS_ATOM(_11883);
    _11883 = NOVALUE;
    if (_11884 == 0) {
        goto L1; // [14] 35
    }
    _2 = (object)SEQ_PTR(_opt_21138);
    _11886 = (object)*(((s1_ptr)_2)->base + 2);
    _11887 = IS_ATOM(_11886);
    _11886 = NOVALUE;
    if (_11887 == 0)
    {
        _11887 = NOVALUE;
        goto L1; // [26] 35
    }
    else{
        _11887 = NOVALUE;
    }

    /** cmdline.e:560			return*/
    DeRefDS(_opt_21138);
    DeRef(_param_name_21149);
    DeRef(_cmd_21169);
    return;
L1: 

    /** cmdline.e:563		integer has_param = find(HAS_PARAMETER, opt[OPTIONS])*/
    _2 = (object)SEQ_PTR(_opt_21138);
    _11888 = (object)*(((s1_ptr)_2)->base + 4);
    _has_param_21146 = find_from(112, _11888, 1);
    _11888 = NOVALUE;

    /** cmdline.e:564		sequence param_name*/

    /** cmdline.e:565		if has_param != 0 then*/
    if (_has_param_21146 == 0)
    goto L2; // [50] 124

    /** cmdline.e:566			if has_param < length(opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_opt_21138);
    _11891 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_11891)){
            _11892 = SEQ_PTR(_11891)->length;
    }
    else {
        _11892 = 1;
    }
    _11891 = NOVALUE;
    if (_has_param_21146 >= _11892)
    goto L3; // [63] 115

    /** cmdline.e:567				has_param += 1*/
    _has_param_21146 = _has_param_21146 + 1;

    /** cmdline.e:568				if sequence(opt[OPTIONS][has_param]) then*/
    _2 = (object)SEQ_PTR(_opt_21138);
    _11895 = (object)*(((s1_ptr)_2)->base + 4);
    _2 = (object)SEQ_PTR(_11895);
    _11896 = (object)*(((s1_ptr)_2)->base + _has_param_21146);
    _11895 = NOVALUE;
    _11897 = IS_SEQUENCE(_11896);
    _11896 = NOVALUE;
    if (_11897 == 0)
    {
        _11897 = NOVALUE;
        goto L4; // [86] 104
    }
    else{
        _11897 = NOVALUE;
    }

    /** cmdline.e:569					param_name = opt[OPTIONS][has_param]*/
    _2 = (object)SEQ_PTR(_opt_21138);
    _11898 = (object)*(((s1_ptr)_2)->base + 4);
    DeRef(_param_name_21149);
    _2 = (object)SEQ_PTR(_11898);
    _param_name_21149 = (object)*(((s1_ptr)_2)->base + _has_param_21146);
    Ref(_param_name_21149);
    _11898 = NOVALUE;
    goto L5; // [101] 123
L4: 

    /** cmdline.e:571					param_name = "x"*/
    RefDS(_11640);
    DeRef(_param_name_21149);
    _param_name_21149 = _11640;
    goto L5; // [112] 123
L3: 

    /** cmdline.e:574				param_name = "x"*/
    RefDS(_11640);
    DeRef(_param_name_21149);
    _param_name_21149 = _11640;
L5: 
L2: 

    /** cmdline.e:577		integer is_mandatory = (find(MANDATORY, opt[OPTIONS]) != 0)*/
    _2 = (object)SEQ_PTR(_opt_21138);
    _11900 = (object)*(((s1_ptr)_2)->base + 4);
    _11901 = find_from(109, _11900, 1);
    _11900 = NOVALUE;
    _is_mandatory_21165 = (_11901 != 0);
    _11901 = NOVALUE;

    /** cmdline.e:578		sequence cmd = ""*/
    RefDS(_5);
    DeRef(_cmd_21169);
    _cmd_21169 = _5;

    /** cmdline.e:580		if sequence(opt[SHORTNAME]) then*/
    _2 = (object)SEQ_PTR(_opt_21138);
    _11903 = (object)*(((s1_ptr)_2)->base + 1);
    _11904 = IS_SEQUENCE(_11903);
    _11903 = NOVALUE;
    if (_11904 == 0)
    {
        _11904 = NOVALUE;
        goto L6; // [155] 216
    }
    else{
        _11904 = NOVALUE;
    }

    /** cmdline.e:581			if not is_mandatory then*/
    if (_is_mandatory_21165 != 0)
    goto L7; // [160] 170

    /** cmdline.e:582				cmd &= '['*/
    Append(&_cmd_21169, _cmd_21169, 91);
L7: 

    /** cmdline.e:584			cmd &= '-' & opt[SHORTNAME]*/
    _2 = (object)SEQ_PTR(_opt_21138);
    _11907 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(45) && IS_ATOM(_11907)) {
    }
    else if (IS_ATOM(45) && IS_SEQUENCE(_11907)) {
        Prepend(&_11908, _11907, 45);
    }
    else {
        Concat((object_ptr)&_11908, 45, _11907);
    }
    _11907 = NOVALUE;
    Concat((object_ptr)&_cmd_21169, _cmd_21169, _11908);
    DeRefDS(_11908);
    _11908 = NOVALUE;

    /** cmdline.e:585			if has_param != 0 then*/
    if (_has_param_21146 == 0)
    goto L8; // [186] 203

    /** cmdline.e:586				cmd &= ' ' & param_name*/
    Prepend(&_11911, _param_name_21149, 32);
    Concat((object_ptr)&_cmd_21169, _cmd_21169, _11911);
    DeRefDS(_11911);
    _11911 = NOVALUE;
L8: 

    /** cmdline.e:588			if not is_mandatory then*/
    if (_is_mandatory_21165 != 0)
    goto L9; // [205] 215

    /** cmdline.e:589				cmd &= ']'*/
    Append(&_cmd_21169, _cmd_21169, 93);
L9: 
L6: 

    /** cmdline.e:593		if sequence(opt[LONGNAME]) then*/
    _2 = (object)SEQ_PTR(_opt_21138);
    _11915 = (object)*(((s1_ptr)_2)->base + 2);
    _11916 = IS_SEQUENCE(_11915);
    _11915 = NOVALUE;
    if (_11916 == 0)
    {
        _11916 = NOVALUE;
        goto LA; // [225] 300
    }
    else{
        _11916 = NOVALUE;
    }

    /** cmdline.e:594			if length(cmd) > 0 then cmd &= ", " end if*/
    if (IS_SEQUENCE(_cmd_21169)){
            _11917 = SEQ_PTR(_cmd_21169)->length;
    }
    else {
        _11917 = 1;
    }
    if (_11917 <= 0)
    goto LB; // [233] 242
    Concat((object_ptr)&_cmd_21169, _cmd_21169, _11919);
LB: 

    /** cmdline.e:595			if not is_mandatory then*/
    if (_is_mandatory_21165 != 0)
    goto LC; // [244] 254

    /** cmdline.e:596				cmd &= '['*/
    Append(&_cmd_21169, _cmd_21169, 91);
LC: 

    /** cmdline.e:598			cmd &= "--" & opt[LONGNAME]*/
    _2 = (object)SEQ_PTR(_opt_21138);
    _11924 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_11923) && IS_ATOM(_11924)) {
        Ref(_11924);
        Append(&_11925, _11923, _11924);
    }
    else if (IS_ATOM(_11923) && IS_SEQUENCE(_11924)) {
    }
    else {
        Concat((object_ptr)&_11925, _11923, _11924);
    }
    _11924 = NOVALUE;
    Concat((object_ptr)&_cmd_21169, _cmd_21169, _11925);
    DeRefDS(_11925);
    _11925 = NOVALUE;

    /** cmdline.e:599			if has_param != 0 then*/
    if (_has_param_21146 == 0)
    goto LD; // [270] 287

    /** cmdline.e:600				cmd &= '=' & param_name*/
    Prepend(&_11928, _param_name_21149, 61);
    Concat((object_ptr)&_cmd_21169, _cmd_21169, _11928);
    DeRefDS(_11928);
    _11928 = NOVALUE;
LD: 

    /** cmdline.e:602			if not is_mandatory then*/
    if (_is_mandatory_21165 != 0)
    goto LE; // [289] 299

    /** cmdline.e:603				cmd &= ']'*/
    Append(&_cmd_21169, _cmd_21169, 93);
LE: 
LA: 

    /** cmdline.e:610		if length(cmd) > pad_size then*/
    if (IS_SEQUENCE(_cmd_21169)){
            _11932 = SEQ_PTR(_cmd_21169)->length;
    }
    else {
        _11932 = 1;
    }
    if (_11932 <= _pad_size_21139)
    goto LF; // [305] 336

    /** cmdline.e:611			puts(1, "   " & cmd & '\n')*/
    {
        object concat_list[3];

        concat_list[0] = 10;
        concat_list[1] = _cmd_21169;
        concat_list[2] = _11934;
        Concat_N((object_ptr)&_11935, concat_list, 3);
    }
    EPuts(1, _11935); // DJP 
    DeRefDS(_11935);
    _11935 = NOVALUE;

    /** cmdline.e:612			puts(1, repeat(' ', pad_size + 3))*/
    _11936 = _pad_size_21139 + 3;
    _11937 = Repeat(32, _11936);
    _11936 = NOVALUE;
    EPuts(1, _11937); // DJP 
    DeRefDS(_11937);
    _11937 = NOVALUE;
    goto L10; // [333] 352
LF: 

    /** cmdline.e:614			puts(1, "   " & stdseq:pad_tail(cmd, pad_size))*/
    RefDS(_cmd_21169);
    _11938 = _24pad_tail(_cmd_21169, _pad_size_21139, 32);
    if (IS_SEQUENCE(_11934) && IS_ATOM(_11938)) {
        Ref(_11938);
        Append(&_11939, _11934, _11938);
    }
    else if (IS_ATOM(_11934) && IS_SEQUENCE(_11938)) {
    }
    else {
        Concat((object_ptr)&_11939, _11934, _11938);
    }
    DeRef(_11938);
    _11938 = NOVALUE;
    EPuts(1, _11939); // DJP 
    DeRefDS(_11939);
    _11939 = NOVALUE;
L10: 

    /** cmdline.e:617		puts(1, opt[DESCRIPTION] & '\n')*/
    _2 = (object)SEQ_PTR(_opt_21138);
    _11940 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_11940) && IS_ATOM(10)) {
        Append(&_11941, _11940, 10);
    }
    else if (IS_ATOM(_11940) && IS_SEQUENCE(10)) {
    }
    else {
        Concat((object_ptr)&_11941, _11940, 10);
        _11940 = NOVALUE;
    }
    _11940 = NOVALUE;
    EPuts(1, _11941); // DJP 
    DeRefDS(_11941);
    _11941 = NOVALUE;

    /** cmdline.e:618	end procedure*/
    DeRefDS(_opt_21138);
    DeRef(_param_name_21149);
    DeRef(_cmd_21169);
    _11891 = NOVALUE;
    return;
    ;
}


object _48find_opt(object _opts_21229, object _opt_style_21230, object _cmd_text_21231)
{
    object _opt_name_21232 = NOVALUE;
    object _opt_param_21233 = NOVALUE;
    object _param_found_21234 = NOVALUE;
    object _reversed_21235 = NOVALUE;
    object _12044 = NOVALUE;
    object _12042 = NOVALUE;
    object _12041 = NOVALUE;
    object _12039 = NOVALUE;
    object _12038 = NOVALUE;
    object _12037 = NOVALUE;
    object _12036 = NOVALUE;
    object _12035 = NOVALUE;
    object _12032 = NOVALUE;
    object _12031 = NOVALUE;
    object _12030 = NOVALUE;
    object _12028 = NOVALUE;
    object _12027 = NOVALUE;
    object _12026 = NOVALUE;
    object _12025 = NOVALUE;
    object _12023 = NOVALUE;
    object _12022 = NOVALUE;
    object _12021 = NOVALUE;
    object _12020 = NOVALUE;
    object _12019 = NOVALUE;
    object _12018 = NOVALUE;
    object _12017 = NOVALUE;
    object _12016 = NOVALUE;
    object _12015 = NOVALUE;
    object _12014 = NOVALUE;
    object _12013 = NOVALUE;
    object _12012 = NOVALUE;
    object _12005 = NOVALUE;
    object _12004 = NOVALUE;
    object _12003 = NOVALUE;
    object _11996 = NOVALUE;
    object _11995 = NOVALUE;
    object _11993 = NOVALUE;
    object _11991 = NOVALUE;
    object _11990 = NOVALUE;
    object _11988 = NOVALUE;
    object _11987 = NOVALUE;
    object _11986 = NOVALUE;
    object _11985 = NOVALUE;
    object _11984 = NOVALUE;
    object _11982 = NOVALUE;
    object _11981 = NOVALUE;
    object _11979 = NOVALUE;
    object _11977 = NOVALUE;
    object _11976 = NOVALUE;
    object _11974 = NOVALUE;
    object _11973 = NOVALUE;
    object _11971 = NOVALUE;
    object _11970 = NOVALUE;
    object _11968 = NOVALUE;
    object _11967 = NOVALUE;
    object _11964 = NOVALUE;
    object _11962 = NOVALUE;
    object _11961 = NOVALUE;
    object _11959 = NOVALUE;
    object _11957 = NOVALUE;
    object _11955 = NOVALUE;
    object _11954 = NOVALUE;
    object _11952 = NOVALUE;
    object _11951 = NOVALUE;
    object _11950 = NOVALUE;
    object _11949 = NOVALUE;
    object _11948 = NOVALUE;
    object _11946 = NOVALUE;
    object _11945 = NOVALUE;
    object _11943 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:793		integer param_found = 0*/
    _param_found_21234 = 0;

    /** cmdline.e:794		integer reversed = 0*/
    _reversed_21235 = 0;

    /** cmdline.e:796		if length(cmd_text) >= 2 then*/
    if (IS_SEQUENCE(_cmd_text_21231)){
            _11943 = SEQ_PTR(_cmd_text_21231)->length;
    }
    else {
        _11943 = 1;
    }
    if (_11943 < 2)
    goto L1; // [20] 85

    /** cmdline.e:798			if cmd_text[1] = '\'' or cmd_text[1] = '"' then*/
    _2 = (object)SEQ_PTR(_cmd_text_21231);
    _11945 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_11945)) {
        _11946 = (_11945 == 39);
    }
    else {
        _11946 = binary_op(EQUALS, _11945, 39);
    }
    _11945 = NOVALUE;
    if (IS_ATOM_INT(_11946)) {
        if (_11946 != 0) {
            goto L2; // [34] 51
        }
    }
    else {
        if (DBL_PTR(_11946)->dbl != 0.0) {
            goto L2; // [34] 51
        }
    }
    _2 = (object)SEQ_PTR(_cmd_text_21231);
    _11948 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_11948)) {
        _11949 = (_11948 == 34);
    }
    else {
        _11949 = binary_op(EQUALS, _11948, 34);
    }
    _11948 = NOVALUE;
    if (_11949 == 0) {
        DeRef(_11949);
        _11949 = NOVALUE;
        goto L3; // [47] 84
    }
    else {
        if (!IS_ATOM_INT(_11949) && DBL_PTR(_11949)->dbl == 0.0){
            DeRef(_11949);
            _11949 = NOVALUE;
            goto L3; // [47] 84
        }
        DeRef(_11949);
        _11949 = NOVALUE;
    }
    DeRef(_11949);
    _11949 = NOVALUE;
L2: 

    /** cmdline.e:799				if cmd_text[$] = cmd_text[1] then*/
    if (IS_SEQUENCE(_cmd_text_21231)){
            _11950 = SEQ_PTR(_cmd_text_21231)->length;
    }
    else {
        _11950 = 1;
    }
    _2 = (object)SEQ_PTR(_cmd_text_21231);
    _11951 = (object)*(((s1_ptr)_2)->base + _11950);
    _2 = (object)SEQ_PTR(_cmd_text_21231);
    _11952 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _11951, _11952)){
        _11951 = NOVALUE;
        _11952 = NOVALUE;
        goto L4; // [64] 83
    }
    _11951 = NOVALUE;
    _11952 = NOVALUE;

    /** cmdline.e:800					cmd_text = cmd_text[2 .. $-1]*/
    if (IS_SEQUENCE(_cmd_text_21231)){
            _11954 = SEQ_PTR(_cmd_text_21231)->length;
    }
    else {
        _11954 = 1;
    }
    _11955 = _11954 - 1;
    _11954 = NOVALUE;
    rhs_slice_target = (object_ptr)&_cmd_text_21231;
    RHS_Slice(_cmd_text_21231, 2, _11955);
L4: 
L3: 
L1: 

    /** cmdline.e:805		if length(cmd_text) > 0 then*/
    if (IS_SEQUENCE(_cmd_text_21231)){
            _11957 = SEQ_PTR(_cmd_text_21231)->length;
    }
    else {
        _11957 = 1;
    }
    if (_11957 <= 0)
    goto L5; // [90] 125

    /** cmdline.e:806			if find(cmd_text[1], "!-") then*/
    _2 = (object)SEQ_PTR(_cmd_text_21231);
    _11959 = (object)*(((s1_ptr)_2)->base + 1);
    _11961 = find_from(_11959, _11960, 1);
    _11959 = NOVALUE;
    if (_11961 == 0)
    {
        _11961 = NOVALUE;
        goto L6; // [105] 124
    }
    else{
        _11961 = NOVALUE;
    }

    /** cmdline.e:807				reversed = 1*/
    _reversed_21235 = 1;

    /** cmdline.e:808				cmd_text = cmd_text[2 .. $]*/
    if (IS_SEQUENCE(_cmd_text_21231)){
            _11962 = SEQ_PTR(_cmd_text_21231)->length;
    }
    else {
        _11962 = 1;
    }
    rhs_slice_target = (object_ptr)&_cmd_text_21231;
    RHS_Slice(_cmd_text_21231, 2, _11962);
L6: 
L5: 

    /** cmdline.e:812		if length(cmd_text) < 1 then*/
    if (IS_SEQUENCE(_cmd_text_21231)){
            _11964 = SEQ_PTR(_cmd_text_21231)->length;
    }
    else {
        _11964 = 1;
    }
    if (_11964 >= 1)
    goto L7; // [130] 145

    /** cmdline.e:813			return {-1, "Empty command text"}*/
    RefDS(_11966);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = _11966;
    _11967 = MAKE_SEQ(_1);
    DeRefDS(_opts_21229);
    DeRefDS(_opt_style_21230);
    DeRef(_cmd_text_21231);
    DeRef(_opt_name_21232);
    DeRef(_opt_param_21233);
    DeRef(_11946);
    _11946 = NOVALUE;
    DeRef(_11955);
    _11955 = NOVALUE;
    return _11967;
L7: 

    /** cmdline.e:816		opt_name = repeat(' ', length(cmd_text))*/
    if (IS_SEQUENCE(_cmd_text_21231)){
            _11968 = SEQ_PTR(_cmd_text_21231)->length;
    }
    else {
        _11968 = 1;
    }
    DeRef(_opt_name_21232);
    _opt_name_21232 = Repeat(32, _11968);
    _11968 = NOVALUE;

    /** cmdline.e:817		opt_param = 0*/
    DeRef(_opt_param_21233);
    _opt_param_21233 = 0;

    /** cmdline.e:818		for i = 1 to length(cmd_text) do*/
    if (IS_SEQUENCE(_cmd_text_21231)){
            _11970 = SEQ_PTR(_cmd_text_21231)->length;
    }
    else {
        _11970 = 1;
    }
    {
        object _i_21270;
        _i_21270 = 1;
L8: 
        if (_i_21270 > _11970){
            goto L9; // [164] 320
        }

        /** cmdline.e:819			if find(cmd_text[i], ":=") then*/
        _2 = (object)SEQ_PTR(_cmd_text_21231);
        _11971 = (object)*(((s1_ptr)_2)->base + _i_21270);
        _11973 = find_from(_11971, _11972, 1);
        _11971 = NOVALUE;
        if (_11973 == 0)
        {
            _11973 = NOVALUE;
            goto LA; // [182] 302
        }
        else{
            _11973 = NOVALUE;
        }

        /** cmdline.e:820				opt_name = opt_name[1 .. i - 1]*/
        _11974 = _i_21270 - 1;
        rhs_slice_target = (object_ptr)&_opt_name_21232;
        RHS_Slice(_opt_name_21232, 1, _11974);

        /** cmdline.e:821				opt_param = cmd_text[i + 1 .. $]*/
        _11976 = _i_21270 + 1;
        if (IS_SEQUENCE(_cmd_text_21231)){
                _11977 = SEQ_PTR(_cmd_text_21231)->length;
        }
        else {
            _11977 = 1;
        }
        rhs_slice_target = (object_ptr)&_opt_param_21233;
        RHS_Slice(_cmd_text_21231, _11976, _11977);

        /** cmdline.e:822				if length(opt_param) >= 2 then*/
        if (IS_SEQUENCE(_opt_param_21233)){
                _11979 = SEQ_PTR(_opt_param_21233)->length;
        }
        else {
            _11979 = 1;
        }
        if (_11979 < 2)
        goto LB; // [215] 280

        /** cmdline.e:824					if opt_param[1] = '\'' or opt_param[1] = '"' then*/
        _2 = (object)SEQ_PTR(_opt_param_21233);
        _11981 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_11981)) {
            _11982 = (_11981 == 39);
        }
        else {
            _11982 = binary_op(EQUALS, _11981, 39);
        }
        _11981 = NOVALUE;
        if (IS_ATOM_INT(_11982)) {
            if (_11982 != 0) {
                goto LC; // [229] 246
            }
        }
        else {
            if (DBL_PTR(_11982)->dbl != 0.0) {
                goto LC; // [229] 246
            }
        }
        _2 = (object)SEQ_PTR(_opt_param_21233);
        _11984 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_11984)) {
            _11985 = (_11984 == 34);
        }
        else {
            _11985 = binary_op(EQUALS, _11984, 34);
        }
        _11984 = NOVALUE;
        if (_11985 == 0) {
            DeRef(_11985);
            _11985 = NOVALUE;
            goto LD; // [242] 279
        }
        else {
            if (!IS_ATOM_INT(_11985) && DBL_PTR(_11985)->dbl == 0.0){
                DeRef(_11985);
                _11985 = NOVALUE;
                goto LD; // [242] 279
            }
            DeRef(_11985);
            _11985 = NOVALUE;
        }
        DeRef(_11985);
        _11985 = NOVALUE;
LC: 

        /** cmdline.e:825						if opt_param[$] = opt_param[1] then*/
        if (IS_SEQUENCE(_opt_param_21233)){
                _11986 = SEQ_PTR(_opt_param_21233)->length;
        }
        else {
            _11986 = 1;
        }
        _2 = (object)SEQ_PTR(_opt_param_21233);
        _11987 = (object)*(((s1_ptr)_2)->base + _11986);
        _2 = (object)SEQ_PTR(_opt_param_21233);
        _11988 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _11987, _11988)){
            _11987 = NOVALUE;
            _11988 = NOVALUE;
            goto LE; // [259] 278
        }
        _11987 = NOVALUE;
        _11988 = NOVALUE;

        /** cmdline.e:826							opt_param = opt_param[2 .. $-1]*/
        if (IS_SEQUENCE(_opt_param_21233)){
                _11990 = SEQ_PTR(_opt_param_21233)->length;
        }
        else {
            _11990 = 1;
        }
        _11991 = _11990 - 1;
        _11990 = NOVALUE;
        rhs_slice_target = (object_ptr)&_opt_param_21233;
        RHS_Slice(_opt_param_21233, 2, _11991);
LE: 
LD: 
LB: 

        /** cmdline.e:831				if length(opt_param) > 0 then*/
        if (IS_SEQUENCE(_opt_param_21233)){
                _11993 = SEQ_PTR(_opt_param_21233)->length;
        }
        else {
            _11993 = 1;
        }
        if (_11993 <= 0)
        goto L9; // [285] 320

        /** cmdline.e:832					param_found = 1*/
        _param_found_21234 = 1;

        /** cmdline.e:835				exit*/
        goto L9; // [297] 320
        goto LF; // [299] 313
LA: 

        /** cmdline.e:837				opt_name[i] = cmd_text[i]*/
        _2 = (object)SEQ_PTR(_cmd_text_21231);
        _11995 = (object)*(((s1_ptr)_2)->base + _i_21270);
        Ref(_11995);
        _2 = (object)SEQ_PTR(_opt_name_21232);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_name_21232 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_21270);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _11995;
        if( _1 != _11995 ){
            DeRef(_1);
        }
        _11995 = NOVALUE;
LF: 

        /** cmdline.e:839		end for*/
        _i_21270 = _i_21270 + 1;
        goto L8; // [315] 171
L9: 
        ;
    }

    /** cmdline.e:841		if param_found then*/
    if (_param_found_21234 == 0)
    {
        goto L10; // [322] 388
    }
    else{
    }

    /** cmdline.e:842			if find( text:lower(opt_param), {"1", "on", "yes", "y", "true", "ok", "+"}) then*/
    Ref(_opt_param_21233);
    _11996 = _18lower(_opt_param_21233);
    _1 = NewS1(7);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_10256);
    ((intptr_t*)_2)[1] = _10256;
    RefDS(_11997);
    ((intptr_t*)_2)[2] = _11997;
    RefDS(_11998);
    ((intptr_t*)_2)[3] = _11998;
    RefDS(_11999);
    ((intptr_t*)_2)[4] = _11999;
    RefDS(_12000);
    ((intptr_t*)_2)[5] = _12000;
    RefDS(_12001);
    ((intptr_t*)_2)[6] = _12001;
    RefDS(_12002);
    ((intptr_t*)_2)[7] = _12002;
    _12003 = MAKE_SEQ(_1);
    _12004 = find_from(_11996, _12003, 1);
    DeRef(_11996);
    _11996 = NOVALUE;
    DeRefDS(_12003);
    _12003 = NOVALUE;
    if (_12004 == 0)
    {
        _12004 = NOVALUE;
        goto L11; // [346] 357
    }
    else{
        _12004 = NOVALUE;
    }

    /** cmdline.e:843				opt_param = 1*/
    DeRef(_opt_param_21233);
    _opt_param_21233 = 1;
    goto L12; // [354] 387
L11: 

    /** cmdline.e:844			elsif find( text:lower(opt_param), {"0", "off", "no", "n", "false", "-"}) then*/
    Ref(_opt_param_21233);
    _12005 = _18lower(_opt_param_21233);
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12006);
    ((intptr_t*)_2)[1] = _12006;
    RefDS(_12007);
    ((intptr_t*)_2)[2] = _12007;
    RefDS(_12008);
    ((intptr_t*)_2)[3] = _12008;
    RefDS(_12009);
    ((intptr_t*)_2)[4] = _12009;
    RefDS(_12010);
    ((intptr_t*)_2)[5] = _12010;
    RefDS(_12011);
    ((intptr_t*)_2)[6] = _12011;
    _12012 = MAKE_SEQ(_1);
    _12013 = find_from(_12005, _12012, 1);
    DeRef(_12005);
    _12005 = NOVALUE;
    DeRefDS(_12012);
    _12012 = NOVALUE;
    if (_12013 == 0)
    {
        _12013 = NOVALUE;
        goto L13; // [377] 386
    }
    else{
        _12013 = NOVALUE;
    }

    /** cmdline.e:845				opt_param = 0*/
    DeRef(_opt_param_21233);
    _opt_param_21233 = 0;
L13: 
L12: 
L10: 

    /** cmdline.e:849		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_21229)){
            _12014 = SEQ_PTR(_opts_21229)->length;
    }
    else {
        _12014 = 1;
    }
    {
        object _i_21325;
        _i_21325 = 1;
L14: 
        if (_i_21325 > _12014){
            goto L15; // [393] 592
        }

        /** cmdline.e:850			if find(NO_CASE,  opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_21229);
        _12015 = (object)*(((s1_ptr)_2)->base + _i_21325);
        _2 = (object)SEQ_PTR(_12015);
        _12016 = (object)*(((s1_ptr)_2)->base + 4);
        _12015 = NOVALUE;
        _12017 = find_from(105, _12016, 1);
        _12016 = NOVALUE;
        if (_12017 == 0)
        {
            _12017 = NOVALUE;
            goto L16; // [415] 455
        }
        else{
            _12017 = NOVALUE;
        }

        /** cmdline.e:851				if not equal( text:lower(opt_name), text:lower(opts[i][opt_style[1]])) then*/
        RefDS(_opt_name_21232);
        _12018 = _18lower(_opt_name_21232);
        _2 = (object)SEQ_PTR(_opts_21229);
        _12019 = (object)*(((s1_ptr)_2)->base + _i_21325);
        _2 = (object)SEQ_PTR(_opt_style_21230);
        _12020 = (object)*(((s1_ptr)_2)->base + 1);
        _2 = (object)SEQ_PTR(_12019);
        if (!IS_ATOM_INT(_12020)){
            _12021 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12020)->dbl));
        }
        else{
            _12021 = (object)*(((s1_ptr)_2)->base + _12020);
        }
        _12019 = NOVALUE;
        Ref(_12021);
        _12022 = _18lower(_12021);
        _12021 = NOVALUE;
        if (_12018 == _12022)
        _12023 = 1;
        else if (IS_ATOM_INT(_12018) && IS_ATOM_INT(_12022))
        _12023 = 0;
        else
        _12023 = (compare(_12018, _12022) == 0);
        DeRef(_12018);
        _12018 = NOVALUE;
        DeRef(_12022);
        _12022 = NOVALUE;
        if (_12023 != 0)
        goto L17; // [444] 482
        _12023 = NOVALUE;

        /** cmdline.e:852					continue*/
        goto L18; // [449] 587
        goto L17; // [452] 482
L16: 

        /** cmdline.e:855				if not equal(opt_name, opts[i][opt_style[1]]) then*/
        _2 = (object)SEQ_PTR(_opts_21229);
        _12025 = (object)*(((s1_ptr)_2)->base + _i_21325);
        _2 = (object)SEQ_PTR(_opt_style_21230);
        _12026 = (object)*(((s1_ptr)_2)->base + 1);
        _2 = (object)SEQ_PTR(_12025);
        if (!IS_ATOM_INT(_12026)){
            _12027 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12026)->dbl));
        }
        else{
            _12027 = (object)*(((s1_ptr)_2)->base + _12026);
        }
        _12025 = NOVALUE;
        if (_opt_name_21232 == _12027)
        _12028 = 1;
        else if (IS_ATOM_INT(_opt_name_21232) && IS_ATOM_INT(_12027))
        _12028 = 0;
        else
        _12028 = (compare(_opt_name_21232, _12027) == 0);
        _12027 = NOVALUE;
        if (_12028 != 0)
        goto L19; // [473] 481
        _12028 = NOVALUE;

        /** cmdline.e:856					continue*/
        goto L18; // [478] 587
L19: 
L17: 

        /** cmdline.e:860			if find(HAS_PARAMETER,  opts[i][OPTIONS]) = 0 then*/
        _2 = (object)SEQ_PTR(_opts_21229);
        _12030 = (object)*(((s1_ptr)_2)->base + _i_21325);
        _2 = (object)SEQ_PTR(_12030);
        _12031 = (object)*(((s1_ptr)_2)->base + 4);
        _12030 = NOVALUE;
        _12032 = find_from(112, _12031, 1);
        _12031 = NOVALUE;
        if (_12032 != 0)
        goto L1A; // [497] 518

        /** cmdline.e:861				if param_found then*/
        if (_param_found_21234 == 0)
        {
            goto L1B; // [503] 517
        }
        else{
        }

        /** cmdline.e:862					return {0, "Option should not have a parameter"}*/
        RefDS(_12034);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 0;
        ((intptr_t *)_2)[2] = _12034;
        _12035 = MAKE_SEQ(_1);
        DeRefDS(_opts_21229);
        DeRefDS(_opt_style_21230);
        DeRef(_cmd_text_21231);
        DeRef(_opt_name_21232);
        DeRef(_opt_param_21233);
        _12026 = NOVALUE;
        DeRef(_11991);
        _11991 = NOVALUE;
        DeRef(_11976);
        _11976 = NOVALUE;
        DeRef(_11946);
        _11946 = NOVALUE;
        DeRef(_11955);
        _11955 = NOVALUE;
        DeRef(_11967);
        _11967 = NOVALUE;
        DeRef(_11982);
        _11982 = NOVALUE;
        _12020 = NOVALUE;
        DeRef(_11974);
        _11974 = NOVALUE;
        return _12035;
L1B: 
L1A: 

        /** cmdline.e:866			if param_found then*/
        if (_param_found_21234 == 0)
        {
            goto L1C; // [520] 539
        }
        else{
        }

        /** cmdline.e:867				return {i, opt_name, reversed, opt_param}*/
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _i_21325;
        RefDS(_opt_name_21232);
        ((intptr_t*)_2)[2] = _opt_name_21232;
        ((intptr_t*)_2)[3] = _reversed_21235;
        Ref(_opt_param_21233);
        ((intptr_t*)_2)[4] = _opt_param_21233;
        _12036 = MAKE_SEQ(_1);
        DeRefDS(_opts_21229);
        DeRefDS(_opt_style_21230);
        DeRef(_cmd_text_21231);
        DeRefDS(_opt_name_21232);
        DeRef(_opt_param_21233);
        _12026 = NOVALUE;
        DeRef(_11991);
        _11991 = NOVALUE;
        DeRef(_11976);
        _11976 = NOVALUE;
        DeRef(_11946);
        _11946 = NOVALUE;
        DeRef(_12035);
        _12035 = NOVALUE;
        DeRef(_11955);
        _11955 = NOVALUE;
        DeRef(_11967);
        _11967 = NOVALUE;
        DeRef(_11982);
        _11982 = NOVALUE;
        _12020 = NOVALUE;
        DeRef(_11974);
        _11974 = NOVALUE;
        return _12036;
        goto L1D; // [536] 585
L1C: 

        /** cmdline.e:869				if find(HAS_PARAMETER, opts[i][OPTIONS]) = 0 then*/
        _2 = (object)SEQ_PTR(_opts_21229);
        _12037 = (object)*(((s1_ptr)_2)->base + _i_21325);
        _2 = (object)SEQ_PTR(_12037);
        _12038 = (object)*(((s1_ptr)_2)->base + 4);
        _12037 = NOVALUE;
        _12039 = find_from(112, _12038, 1);
        _12038 = NOVALUE;
        if (_12039 != 0)
        goto L1E; // [554] 572

        /** cmdline.e:870					return {i, opt_name, reversed, 1 }*/
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _i_21325;
        RefDS(_opt_name_21232);
        ((intptr_t*)_2)[2] = _opt_name_21232;
        ((intptr_t*)_2)[3] = _reversed_21235;
        ((intptr_t*)_2)[4] = 1;
        _12041 = MAKE_SEQ(_1);
        DeRefDS(_opts_21229);
        DeRefDS(_opt_style_21230);
        DeRef(_cmd_text_21231);
        DeRefDS(_opt_name_21232);
        DeRef(_opt_param_21233);
        _12026 = NOVALUE;
        DeRef(_11991);
        _11991 = NOVALUE;
        DeRef(_12036);
        _12036 = NOVALUE;
        DeRef(_11976);
        _11976 = NOVALUE;
        DeRef(_11946);
        _11946 = NOVALUE;
        DeRef(_12035);
        _12035 = NOVALUE;
        DeRef(_11955);
        _11955 = NOVALUE;
        DeRef(_11967);
        _11967 = NOVALUE;
        DeRef(_11982);
        _11982 = NOVALUE;
        _12020 = NOVALUE;
        DeRef(_11974);
        _11974 = NOVALUE;
        return _12041;
L1E: 

        /** cmdline.e:873				return {i, opt_name, reversed}*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _i_21325;
        RefDS(_opt_name_21232);
        ((intptr_t*)_2)[2] = _opt_name_21232;
        ((intptr_t*)_2)[3] = _reversed_21235;
        _12042 = MAKE_SEQ(_1);
        DeRefDS(_opts_21229);
        DeRefDS(_opt_style_21230);
        DeRef(_cmd_text_21231);
        DeRefDS(_opt_name_21232);
        DeRef(_opt_param_21233);
        _12026 = NOVALUE;
        DeRef(_11991);
        _11991 = NOVALUE;
        DeRef(_12036);
        _12036 = NOVALUE;
        DeRef(_11976);
        _11976 = NOVALUE;
        DeRef(_12041);
        _12041 = NOVALUE;
        DeRef(_11946);
        _11946 = NOVALUE;
        DeRef(_12035);
        _12035 = NOVALUE;
        DeRef(_11955);
        _11955 = NOVALUE;
        DeRef(_11967);
        _11967 = NOVALUE;
        DeRef(_11982);
        _11982 = NOVALUE;
        _12020 = NOVALUE;
        DeRef(_11974);
        _11974 = NOVALUE;
        return _12042;
L1D: 

        /** cmdline.e:875		end for*/
L18: 
        _i_21325 = _i_21325 + 1;
        goto L14; // [587] 400
L15: 
        ;
    }

    /** cmdline.e:877		return {0, "Unrecognised"}*/
    RefDS(_12043);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _12043;
    _12044 = MAKE_SEQ(_1);
    DeRefDS(_opts_21229);
    DeRefDS(_opt_style_21230);
    DeRef(_cmd_text_21231);
    DeRef(_opt_name_21232);
    DeRef(_opt_param_21233);
    _12026 = NOVALUE;
    DeRef(_11991);
    _11991 = NOVALUE;
    DeRef(_12036);
    _12036 = NOVALUE;
    DeRef(_11976);
    _11976 = NOVALUE;
    DeRef(_12041);
    _12041 = NOVALUE;
    DeRef(_11946);
    _11946 = NOVALUE;
    DeRef(_12035);
    _12035 = NOVALUE;
    DeRef(_11955);
    _11955 = NOVALUE;
    DeRef(_11967);
    _11967 = NOVALUE;
    DeRef(_12042);
    _12042 = NOVALUE;
    DeRef(_11982);
    _11982 = NOVALUE;
    _12020 = NOVALUE;
    DeRef(_11974);
    _11974 = NOVALUE;
    return _12044;
    ;
}


object _48get_help_options(object _opts_21368)
{
    object _help_opts_21369 = NOVALUE;
    object _12067 = NOVALUE;
    object _12066 = NOVALUE;
    object _12065 = NOVALUE;
    object _12063 = NOVALUE;
    object _12062 = NOVALUE;
    object _12061 = NOVALUE;
    object _12059 = NOVALUE;
    object _12058 = NOVALUE;
    object _12057 = NOVALUE;
    object _12056 = NOVALUE;
    object _12055 = NOVALUE;
    object _12053 = NOVALUE;
    object _12052 = NOVALUE;
    object _12051 = NOVALUE;
    object _12050 = NOVALUE;
    object _12049 = NOVALUE;
    object _12048 = NOVALUE;
    object _12047 = NOVALUE;
    object _12046 = NOVALUE;
    object _12045 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:881		sequence help_opts = {}*/
    RefDS(_5);
    DeRef(_help_opts_21369);
    _help_opts_21369 = _5;

    /** cmdline.e:883		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_21368)){
            _12045 = SEQ_PTR(_opts_21368)->length;
    }
    else {
        _12045 = 1;
    }
    {
        object _i_21371;
        _i_21371 = 1;
L1: 
        if (_i_21371 > _12045){
            goto L2; // [15] 170
        }

        /** cmdline.e:884			if find(HELP, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_21368);
        _12046 = (object)*(((s1_ptr)_2)->base + _i_21371);
        _2 = (object)SEQ_PTR(_12046);
        _12047 = (object)*(((s1_ptr)_2)->base + 4);
        _12046 = NOVALUE;
        _12048 = find_from(104, _12047, 1);
        _12047 = NOVALUE;
        if (_12048 == 0)
        {
            _12048 = NOVALUE;
            goto L3; // [37] 163
        }
        else{
            _12048 = NOVALUE;
        }

        /** cmdline.e:885				if sequence(opts[i][SHORTNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_21368);
        _12049 = (object)*(((s1_ptr)_2)->base + _i_21371);
        _2 = (object)SEQ_PTR(_12049);
        _12050 = (object)*(((s1_ptr)_2)->base + 1);
        _12049 = NOVALUE;
        _12051 = IS_SEQUENCE(_12050);
        _12050 = NOVALUE;
        if (_12051 == 0)
        {
            _12051 = NOVALUE;
            goto L4; // [53] 71
        }
        else{
            _12051 = NOVALUE;
        }

        /** cmdline.e:886					help_opts = append(help_opts, opts[i][SHORTNAME])*/
        _2 = (object)SEQ_PTR(_opts_21368);
        _12052 = (object)*(((s1_ptr)_2)->base + _i_21371);
        _2 = (object)SEQ_PTR(_12052);
        _12053 = (object)*(((s1_ptr)_2)->base + 1);
        _12052 = NOVALUE;
        Ref(_12053);
        Append(&_help_opts_21369, _help_opts_21369, _12053);
        _12053 = NOVALUE;
L4: 

        /** cmdline.e:889				if sequence(opts[i][LONGNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_21368);
        _12055 = (object)*(((s1_ptr)_2)->base + _i_21371);
        _2 = (object)SEQ_PTR(_12055);
        _12056 = (object)*(((s1_ptr)_2)->base + 2);
        _12055 = NOVALUE;
        _12057 = IS_SEQUENCE(_12056);
        _12056 = NOVALUE;
        if (_12057 == 0)
        {
            _12057 = NOVALUE;
            goto L5; // [84] 102
        }
        else{
            _12057 = NOVALUE;
        }

        /** cmdline.e:890					help_opts = append(help_opts, opts[i][LONGNAME])*/
        _2 = (object)SEQ_PTR(_opts_21368);
        _12058 = (object)*(((s1_ptr)_2)->base + _i_21371);
        _2 = (object)SEQ_PTR(_12058);
        _12059 = (object)*(((s1_ptr)_2)->base + 2);
        _12058 = NOVALUE;
        Ref(_12059);
        Append(&_help_opts_21369, _help_opts_21369, _12059);
        _12059 = NOVALUE;
L5: 

        /** cmdline.e:893				if find(NO_CASE, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_21368);
        _12061 = (object)*(((s1_ptr)_2)->base + _i_21371);
        _2 = (object)SEQ_PTR(_12061);
        _12062 = (object)*(((s1_ptr)_2)->base + 4);
        _12061 = NOVALUE;
        _12063 = find_from(105, _12062, 1);
        _12062 = NOVALUE;
        if (_12063 == 0)
        {
            _12063 = NOVALUE;
            goto L6; // [117] 162
        }
        else{
            _12063 = NOVALUE;
        }

        /** cmdline.e:894					help_opts = text:lower(help_opts)*/
        RefDS(_help_opts_21369);
        _0 = _help_opts_21369;
        _help_opts_21369 = _18lower(_help_opts_21369);
        DeRefDS(_0);

        /** cmdline.e:895					for j = 1 to length(help_opts) do*/
        if (IS_SEQUENCE(_help_opts_21369)){
                _12065 = SEQ_PTR(_help_opts_21369)->length;
        }
        else {
            _12065 = 1;
        }
        {
            object _j_21397;
            _j_21397 = 1;
L7: 
            if (_j_21397 > _12065){
                goto L8; // [133] 161
            }

            /** cmdline.e:896						help_opts = append( help_opts, text:upper(help_opts[j]) )*/
            _2 = (object)SEQ_PTR(_help_opts_21369);
            _12066 = (object)*(((s1_ptr)_2)->base + _j_21397);
            Ref(_12066);
            _12067 = _18upper(_12066);
            _12066 = NOVALUE;
            Ref(_12067);
            Append(&_help_opts_21369, _help_opts_21369, _12067);
            DeRef(_12067);
            _12067 = NOVALUE;

            /** cmdline.e:897					end for*/
            _j_21397 = _j_21397 + 1;
            goto L7; // [156] 140
L8: 
            ;
        }
L6: 
L3: 

        /** cmdline.e:900		end for*/
        _i_21371 = _i_21371 + 1;
        goto L1; // [165] 22
L2: 
        ;
    }

    /** cmdline.e:901		return help_opts*/
    DeRefDS(_opts_21368);
    return _help_opts_21369;
    ;
}


object _48parse_at_cmds(object _cmd_21404, object _cmds_21405, object _opts_21406, object _arg_idx_21407, object _add_help_rid_21408, object _parse_options_21409, object _help_on_error_21410, object _auto_help_21411)
{
    object _at_cmds_21412 = NOVALUE;
    object _j_21413 = NOVALUE;
    object _cmdex_21497 = NOVALUE;
    object _12148 = NOVALUE;
    object _12147 = NOVALUE;
    object _12144 = NOVALUE;
    object _12143 = NOVALUE;
    object _12142 = NOVALUE;
    object _12141 = NOVALUE;
    object _12140 = NOVALUE;
    object _12139 = NOVALUE;
    object _12138 = NOVALUE;
    object _12137 = NOVALUE;
    object _12136 = NOVALUE;
    object _12135 = NOVALUE;
    object _12134 = NOVALUE;
    object _12133 = NOVALUE;
    object _12132 = NOVALUE;
    object _12131 = NOVALUE;
    object _12130 = NOVALUE;
    object _12129 = NOVALUE;
    object _12128 = NOVALUE;
    object _12127 = NOVALUE;
    object _12126 = NOVALUE;
    object _12125 = NOVALUE;
    object _12124 = NOVALUE;
    object _12123 = NOVALUE;
    object _12122 = NOVALUE;
    object _12121 = NOVALUE;
    object _12120 = NOVALUE;
    object _12119 = NOVALUE;
    object _12118 = NOVALUE;
    object _12117 = NOVALUE;
    object _12116 = NOVALUE;
    object _12115 = NOVALUE;
    object _12114 = NOVALUE;
    object _12113 = NOVALUE;
    object _12110 = NOVALUE;
    object _12109 = NOVALUE;
    object _12108 = NOVALUE;
    object _12107 = NOVALUE;
    object _12106 = NOVALUE;
    object _12104 = NOVALUE;
    object _12103 = NOVALUE;
    object _12100 = NOVALUE;
    object _12099 = NOVALUE;
    object _12098 = NOVALUE;
    object _12097 = NOVALUE;
    object _12096 = NOVALUE;
    object _12094 = NOVALUE;
    object _12093 = NOVALUE;
    object _12092 = NOVALUE;
    object _12091 = NOVALUE;
    object _12088 = NOVALUE;
    object _12086 = NOVALUE;
    object _12085 = NOVALUE;
    object _12084 = NOVALUE;
    object _12082 = NOVALUE;
    object _12080 = NOVALUE;
    object _12079 = NOVALUE;
    object _12077 = NOVALUE;
    object _12075 = NOVALUE;
    object _12074 = NOVALUE;
    object _12073 = NOVALUE;
    object _12072 = NOVALUE;
    object _12071 = NOVALUE;
    object _12070 = NOVALUE;
    object _12069 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:912		if length(cmd) > 2 and cmd[2] = '@' then*/
    if (IS_SEQUENCE(_cmd_21404)){
            _12069 = SEQ_PTR(_cmd_21404)->length;
    }
    else {
        _12069 = 1;
    }
    _12070 = (_12069 > 2);
    _12069 = NOVALUE;
    if (_12070 == 0) {
        goto L1; // [22] 78
    }
    _2 = (object)SEQ_PTR(_cmd_21404);
    _12072 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_12072)) {
        _12073 = (_12072 == 64);
    }
    else {
        _12073 = binary_op(EQUALS, _12072, 64);
    }
    _12072 = NOVALUE;
    if (_12073 == 0) {
        DeRef(_12073);
        _12073 = NOVALUE;
        goto L1; // [35] 78
    }
    else {
        if (!IS_ATOM_INT(_12073) && DBL_PTR(_12073)->dbl == 0.0){
            DeRef(_12073);
            _12073 = NOVALUE;
            goto L1; // [35] 78
        }
        DeRef(_12073);
        _12073 = NOVALUE;
    }
    DeRef(_12073);
    _12073 = NOVALUE;

    /** cmdline.e:914			at_cmds = io:read_lines(cmd[3..$])*/
    if (IS_SEQUENCE(_cmd_21404)){
            _12074 = SEQ_PTR(_cmd_21404)->length;
    }
    else {
        _12074 = 1;
    }
    rhs_slice_target = (object_ptr)&_12075;
    RHS_Slice(_cmd_21404, 3, _12074);
    _0 = _at_cmds_21412;
    _at_cmds_21412 = _17read_lines(_12075);
    DeRef(_0);
    _12075 = NOVALUE;

    /** cmdline.e:915			if equal(at_cmds, -1) then*/
    if (_at_cmds_21412 == -1)
    _12077 = 1;
    else if (IS_ATOM_INT(_at_cmds_21412) && IS_ATOM_INT(-1))
    _12077 = 0;
    else
    _12077 = (compare(_at_cmds_21412, -1) == 0);
    if (_12077 == 0)
    {
        _12077 = NOVALUE;
        goto L2; // [58] 156
    }
    else{
        _12077 = NOVALUE;
    }

    /** cmdline.e:918				cmds = eu:remove(cmds, arg_idx)*/
    {
        s1_ptr assign_space = SEQ_PTR(_cmds_21405);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_arg_idx_21407)) ? _arg_idx_21407 : (object)(DBL_PTR(_arg_idx_21407)->dbl);
        int stop = (IS_ATOM_INT(_arg_idx_21407)) ? _arg_idx_21407 : (object)(DBL_PTR(_arg_idx_21407)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_cmds_21405), start, &_cmds_21405 );
            }
            else Tail(SEQ_PTR(_cmds_21405), stop+1, &_cmds_21405);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_cmds_21405), start, &_cmds_21405);
        }
        else {
            assign_slice_seq = &assign_space;
            _cmds_21405 = Remove_elements(start, stop, (SEQ_PTR(_cmds_21405)->ref == 1));
        }
    }

    /** cmdline.e:919				return cmds*/
    DeRefDS(_cmd_21404);
    DeRefDS(_opts_21406);
    DeRef(_add_help_rid_21408);
    DeRef(_parse_options_21409);
    DeRef(_at_cmds_21412);
    DeRef(_12070);
    _12070 = NOVALUE;
    return _cmds_21405;
    goto L2; // [75] 156
L1: 

    /** cmdline.e:923			at_cmds = io:read_lines(cmd[2..$])*/
    if (IS_SEQUENCE(_cmd_21404)){
            _12079 = SEQ_PTR(_cmd_21404)->length;
    }
    else {
        _12079 = 1;
    }
    rhs_slice_target = (object_ptr)&_12080;
    RHS_Slice(_cmd_21404, 2, _12079);
    _0 = _at_cmds_21412;
    _at_cmds_21412 = _17read_lines(_12080);
    DeRef(_0);
    _12080 = NOVALUE;

    /** cmdline.e:924			if equal(at_cmds, -1) then*/
    if (_at_cmds_21412 == -1)
    _12082 = 1;
    else if (IS_ATOM_INT(_at_cmds_21412) && IS_ATOM_INT(-1))
    _12082 = 0;
    else
    _12082 = (compare(_at_cmds_21412, -1) == 0);
    if (_12082 == 0)
    {
        _12082 = NOVALUE;
        goto L3; // [98] 155
    }
    else{
        _12082 = NOVALUE;
    }

    /** cmdline.e:925				printf(2, "Cannot access '@' argument file '%s'\n", {cmd[2..$]})*/
    if (IS_SEQUENCE(_cmd_21404)){
            _12084 = SEQ_PTR(_cmd_21404)->length;
    }
    else {
        _12084 = 1;
    }
    rhs_slice_target = (object_ptr)&_12085;
    RHS_Slice(_cmd_21404, 2, _12084);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _12085;
    _12086 = MAKE_SEQ(_1);
    _12085 = NOVALUE;
    EPrintf(2, _12083, _12086);
    DeRefDS(_12086);
    _12086 = NOVALUE;

    /** cmdline.e:926				if help_on_error then*/
    if (_help_on_error_21410 == 0)
    {
        goto L4; // [121] 136
    }
    else{
    }

    /** cmdline.e:927					local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_21406);
    Ref(_add_help_rid_21408);
    RefDS(_cmds_21405);
    Ref(_parse_options_21409);
    _48local_help(_opts_21406, _add_help_rid_21408, _cmds_21405, 1, _parse_options_21409);
    goto L5; // [133] 149
L4: 

    /** cmdline.e:928				elsif auto_help then*/
    if (_auto_help_21411 == 0)
    {
        goto L6; // [138] 148
    }
    else{
    }

    /** cmdline.e:929					printf(2,"Try '--help' for more information.\n",{})          */
    EPrintf(2, _12087, _5);
L6: 
L5: 

    /** cmdline.e:931				local_abort(1)*/
    _48local_abort(1);
L3: 
L2: 

    /** cmdline.e:936		j = 0*/
    _j_21413 = 0;

    /** cmdline.e:937		while j < length(at_cmds) do*/
L7: 
    if (IS_SEQUENCE(_at_cmds_21412)){
            _12088 = SEQ_PTR(_at_cmds_21412)->length;
    }
    else {
        _12088 = 1;
    }
    if (_j_21413 >= _12088)
    goto L8; // [171] 492

    /** cmdline.e:938			j += 1*/
    _j_21413 = _j_21413 + 1;

    /** cmdline.e:939			at_cmds[j] = text:trim(at_cmds[j])*/
    _2 = (object)SEQ_PTR(_at_cmds_21412);
    _12091 = (object)*(((s1_ptr)_2)->base + _j_21413);
    Ref(_12091);
    RefDS(_3010);
    _12092 = _18trim(_12091, _3010, 0);
    _12091 = NOVALUE;
    _2 = (object)SEQ_PTR(_at_cmds_21412);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _at_cmds_21412 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _j_21413);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12092;
    if( _1 != _12092 ){
        DeRef(_1);
    }
    _12092 = NOVALUE;

    /** cmdline.e:940			if length(at_cmds[j]) = 0 then*/
    _2 = (object)SEQ_PTR(_at_cmds_21412);
    _12093 = (object)*(((s1_ptr)_2)->base + _j_21413);
    if (IS_SEQUENCE(_12093)){
            _12094 = SEQ_PTR(_12093)->length;
    }
    else {
        _12094 = 1;
    }
    _12093 = NOVALUE;
    if (_12094 != 0)
    goto L9; // [206] 246

    /** cmdline.e:941				at_cmds = at_cmds[1 .. j-1] & at_cmds[j+1 ..$]*/
    _12096 = _j_21413 - 1;
    rhs_slice_target = (object_ptr)&_12097;
    RHS_Slice(_at_cmds_21412, 1, _12096);
    _12098 = _j_21413 + 1;
    if (_12098 > MAXINT){
        _12098 = NewDouble((eudouble)_12098);
    }
    if (IS_SEQUENCE(_at_cmds_21412)){
            _12099 = SEQ_PTR(_at_cmds_21412)->length;
    }
    else {
        _12099 = 1;
    }
    rhs_slice_target = (object_ptr)&_12100;
    RHS_Slice(_at_cmds_21412, _12098, _12099);
    Concat((object_ptr)&_at_cmds_21412, _12097, _12100);
    DeRefDS(_12097);
    _12097 = NOVALUE;
    DeRef(_12097);
    _12097 = NOVALUE;
    DeRefDS(_12100);
    _12100 = NOVALUE;

    /** cmdline.e:942				j -= 1*/
    _j_21413 = _j_21413 - 1;
    goto L7; // [243] 166
L9: 

    /** cmdline.e:944			elsif at_cmds[j][1] = '#' then*/
    _2 = (object)SEQ_PTR(_at_cmds_21412);
    _12103 = (object)*(((s1_ptr)_2)->base + _j_21413);
    _2 = (object)SEQ_PTR(_12103);
    _12104 = (object)*(((s1_ptr)_2)->base + 1);
    _12103 = NOVALUE;
    if (binary_op_a(NOTEQ, _12104, 35)){
        _12104 = NOVALUE;
        goto LA; // [256] 296
    }
    _12104 = NOVALUE;

    /** cmdline.e:945				at_cmds = at_cmds[1 .. j-1] & at_cmds[j+1 ..$]*/
    _12106 = _j_21413 - 1;
    rhs_slice_target = (object_ptr)&_12107;
    RHS_Slice(_at_cmds_21412, 1, _12106);
    _12108 = _j_21413 + 1;
    if (_12108 > MAXINT){
        _12108 = NewDouble((eudouble)_12108);
    }
    if (IS_SEQUENCE(_at_cmds_21412)){
            _12109 = SEQ_PTR(_at_cmds_21412)->length;
    }
    else {
        _12109 = 1;
    }
    rhs_slice_target = (object_ptr)&_12110;
    RHS_Slice(_at_cmds_21412, _12108, _12109);
    Concat((object_ptr)&_at_cmds_21412, _12107, _12110);
    DeRefDS(_12107);
    _12107 = NOVALUE;
    DeRef(_12107);
    _12107 = NOVALUE;
    DeRefDS(_12110);
    _12110 = NOVALUE;

    /** cmdline.e:946				j -= 1*/
    _j_21413 = _j_21413 - 1;
    goto L7; // [293] 166
LA: 

    /** cmdline.e:948			elsif at_cmds[j][1] = '"' and at_cmds[j][$] = '"' and length(at_cmds[j]) >= 2 then*/
    _2 = (object)SEQ_PTR(_at_cmds_21412);
    _12113 = (object)*(((s1_ptr)_2)->base + _j_21413);
    _2 = (object)SEQ_PTR(_12113);
    _12114 = (object)*(((s1_ptr)_2)->base + 1);
    _12113 = NOVALUE;
    if (IS_ATOM_INT(_12114)) {
        _12115 = (_12114 == 34);
    }
    else {
        _12115 = binary_op(EQUALS, _12114, 34);
    }
    _12114 = NOVALUE;
    if (IS_ATOM_INT(_12115)) {
        if (_12115 == 0) {
            DeRef(_12116);
            _12116 = 0;
            goto LB; // [310] 333
        }
    }
    else {
        if (DBL_PTR(_12115)->dbl == 0.0) {
            DeRef(_12116);
            _12116 = 0;
            goto LB; // [310] 333
        }
    }
    _2 = (object)SEQ_PTR(_at_cmds_21412);
    _12117 = (object)*(((s1_ptr)_2)->base + _j_21413);
    if (IS_SEQUENCE(_12117)){
            _12118 = SEQ_PTR(_12117)->length;
    }
    else {
        _12118 = 1;
    }
    _2 = (object)SEQ_PTR(_12117);
    _12119 = (object)*(((s1_ptr)_2)->base + _12118);
    _12117 = NOVALUE;
    if (IS_ATOM_INT(_12119)) {
        _12120 = (_12119 == 34);
    }
    else {
        _12120 = binary_op(EQUALS, _12119, 34);
    }
    _12119 = NOVALUE;
    DeRef(_12116);
    if (IS_ATOM_INT(_12120))
    _12116 = (_12120 != 0);
    else
    _12116 = DBL_PTR(_12120)->dbl != 0.0;
LB: 
    if (_12116 == 0) {
        goto LC; // [333] 377
    }
    _2 = (object)SEQ_PTR(_at_cmds_21412);
    _12122 = (object)*(((s1_ptr)_2)->base + _j_21413);
    if (IS_SEQUENCE(_12122)){
            _12123 = SEQ_PTR(_12122)->length;
    }
    else {
        _12123 = 1;
    }
    _12122 = NOVALUE;
    _12124 = (_12123 >= 2);
    _12123 = NOVALUE;
    if (_12124 == 0)
    {
        DeRef(_12124);
        _12124 = NOVALUE;
        goto LC; // [349] 377
    }
    else{
        DeRef(_12124);
        _12124 = NOVALUE;
    }

    /** cmdline.e:949				at_cmds[j] = at_cmds[j][2 .. $-1]*/
    _2 = (object)SEQ_PTR(_at_cmds_21412);
    _12125 = (object)*(((s1_ptr)_2)->base + _j_21413);
    if (IS_SEQUENCE(_12125)){
            _12126 = SEQ_PTR(_12125)->length;
    }
    else {
        _12126 = 1;
    }
    _12127 = _12126 - 1;
    _12126 = NOVALUE;
    rhs_slice_target = (object_ptr)&_12128;
    RHS_Slice(_12125, 2, _12127);
    _12125 = NOVALUE;
    _2 = (object)SEQ_PTR(_at_cmds_21412);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _at_cmds_21412 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _j_21413);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12128;
    if( _1 != _12128 ){
        DeRef(_1);
    }
    _12128 = NOVALUE;
    goto L7; // [374] 166
LC: 

    /** cmdline.e:951			elsif at_cmds[j][1] = '\'' and at_cmds[j][$] = '\'' and length(at_cmds[j]) >= 2 then*/
    _2 = (object)SEQ_PTR(_at_cmds_21412);
    _12129 = (object)*(((s1_ptr)_2)->base + _j_21413);
    _2 = (object)SEQ_PTR(_12129);
    _12130 = (object)*(((s1_ptr)_2)->base + 1);
    _12129 = NOVALUE;
    if (IS_ATOM_INT(_12130)) {
        _12131 = (_12130 == 39);
    }
    else {
        _12131 = binary_op(EQUALS, _12130, 39);
    }
    _12130 = NOVALUE;
    if (IS_ATOM_INT(_12131)) {
        if (_12131 == 0) {
            DeRef(_12132);
            _12132 = 0;
            goto LD; // [391] 414
        }
    }
    else {
        if (DBL_PTR(_12131)->dbl == 0.0) {
            DeRef(_12132);
            _12132 = 0;
            goto LD; // [391] 414
        }
    }
    _2 = (object)SEQ_PTR(_at_cmds_21412);
    _12133 = (object)*(((s1_ptr)_2)->base + _j_21413);
    if (IS_SEQUENCE(_12133)){
            _12134 = SEQ_PTR(_12133)->length;
    }
    else {
        _12134 = 1;
    }
    _2 = (object)SEQ_PTR(_12133);
    _12135 = (object)*(((s1_ptr)_2)->base + _12134);
    _12133 = NOVALUE;
    if (IS_ATOM_INT(_12135)) {
        _12136 = (_12135 == 39);
    }
    else {
        _12136 = binary_op(EQUALS, _12135, 39);
    }
    _12135 = NOVALUE;
    DeRef(_12132);
    if (IS_ATOM_INT(_12136))
    _12132 = (_12136 != 0);
    else
    _12132 = DBL_PTR(_12136)->dbl != 0.0;
LD: 
    if (_12132 == 0) {
        goto LE; // [414] 484
    }
    _2 = (object)SEQ_PTR(_at_cmds_21412);
    _12138 = (object)*(((s1_ptr)_2)->base + _j_21413);
    if (IS_SEQUENCE(_12138)){
            _12139 = SEQ_PTR(_12138)->length;
    }
    else {
        _12139 = 1;
    }
    _12138 = NOVALUE;
    _12140 = (_12139 >= 2);
    _12139 = NOVALUE;
    if (_12140 == 0)
    {
        DeRef(_12140);
        _12140 = NOVALUE;
        goto LE; // [430] 484
    }
    else{
        DeRef(_12140);
        _12140 = NOVALUE;
    }

    /** cmdline.e:952				sequence cmdex = stdseq:split(at_cmds[j][2 .. $-1],' ', 1) -- Empty words removed.*/
    _2 = (object)SEQ_PTR(_at_cmds_21412);
    _12141 = (object)*(((s1_ptr)_2)->base + _j_21413);
    if (IS_SEQUENCE(_12141)){
            _12142 = SEQ_PTR(_12141)->length;
    }
    else {
        _12142 = 1;
    }
    _12143 = _12142 - 1;
    _12142 = NOVALUE;
    rhs_slice_target = (object_ptr)&_12144;
    RHS_Slice(_12141, 2, _12143);
    _12141 = NOVALUE;
    _0 = _cmdex_21497;
    _cmdex_21497 = _24split(_12144, 32, 1, 0);
    DeRef(_0);
    _12144 = NOVALUE;

    /** cmdline.e:954				at_cmds = replace(at_cmds, cmdex, j)*/
    {
        intptr_t p1 = _at_cmds_21412;
        intptr_t p2 = _cmdex_21497;
        intptr_t p3 = _j_21413;
        intptr_t p4 = _j_21413;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_at_cmds_21412;
        Replace( &replace_params );
    }

    /** cmdline.e:955				j = j + length(cmdex) - 1*/
    if (IS_SEQUENCE(_cmdex_21497)){
            _12147 = SEQ_PTR(_cmdex_21497)->length;
    }
    else {
        _12147 = 1;
    }
    _12148 = _j_21413 + _12147;
    if ((object)((uintptr_t)_12148 + (uintptr_t)HIGH_BITS) >= 0){
        _12148 = NewDouble((eudouble)_12148);
    }
    _12147 = NOVALUE;
    if (IS_ATOM_INT(_12148)) {
        _j_21413 = _12148 - 1;
    }
    else {
        _j_21413 = NewDouble(DBL_PTR(_12148)->dbl - (eudouble)1);
    }
    DeRef(_12148);
    _12148 = NOVALUE;
    if (!IS_ATOM_INT(_j_21413)) {
        _1 = (object)(DBL_PTR(_j_21413)->dbl);
        DeRefDS(_j_21413);
        _j_21413 = _1;
    }
LE: 
    DeRef(_cmdex_21497);
    _cmdex_21497 = NOVALUE;

    /** cmdline.e:958		end while*/
    goto L7; // [489] 166
L8: 

    /** cmdline.e:961		cmds = replace(cmds, at_cmds, arg_idx)*/
    {
        intptr_t p1 = _cmds_21405;
        intptr_t p2 = _at_cmds_21412;
        intptr_t p3 = _arg_idx_21407;
        intptr_t p4 = _arg_idx_21407;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_cmds_21405;
        Replace( &replace_params );
    }

    /** cmdline.e:962		return cmds*/
    DeRefDS(_cmd_21404);
    DeRefDS(_opts_21406);
    DeRef(_add_help_rid_21408);
    DeRef(_parse_options_21409);
    DeRef(_at_cmds_21412);
    _12093 = NOVALUE;
    DeRef(_12127);
    _12127 = NOVALUE;
    _12122 = NOVALUE;
    DeRef(_12098);
    _12098 = NOVALUE;
    _12138 = NOVALUE;
    DeRef(_12115);
    _12115 = NOVALUE;
    DeRef(_12136);
    _12136 = NOVALUE;
    DeRef(_12120);
    _12120 = NOVALUE;
    DeRef(_12131);
    _12131 = NOVALUE;
    DeRef(_12106);
    _12106 = NOVALUE;
    DeRef(_12096);
    _12096 = NOVALUE;
    DeRef(_12108);
    _12108 = NOVALUE;
    DeRef(_12070);
    _12070 = NOVALUE;
    DeRef(_12143);
    _12143 = NOVALUE;
    return _cmds_21405;
    ;
}


void _48check_mandatory(object _opts_21510, object _parsed_opts_21512, object _add_help_rid_21513, object _cmds_21514, object _parse_options_21515, object _help_on_error_21516, object _auto_help_21517)
{
    object _12175 = NOVALUE;
    object _12174 = NOVALUE;
    object _12173 = NOVALUE;
    object _12170 = NOVALUE;
    object _12169 = NOVALUE;
    object _12168 = NOVALUE;
    object _12165 = NOVALUE;
    object _12164 = NOVALUE;
    object _12163 = NOVALUE;
    object _12162 = NOVALUE;
    object _12161 = NOVALUE;
    object _12160 = NOVALUE;
    object _12159 = NOVALUE;
    object _12158 = NOVALUE;
    object _12157 = NOVALUE;
    object _12156 = NOVALUE;
    object _12155 = NOVALUE;
    object _12154 = NOVALUE;
    object _12153 = NOVALUE;
    object _12152 = NOVALUE;
    object _12151 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:969		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_21510)){
            _12151 = SEQ_PTR(_opts_21510)->length;
    }
    else {
        _12151 = 1;
    }
    {
        object _i_21519;
        _i_21519 = 1;
L1: 
        if (_i_21519 > _12151){
            goto L2; // [14] 219
        }

        /** cmdline.e:970			if find(MANDATORY, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_21510);
        _12152 = (object)*(((s1_ptr)_2)->base + _i_21519);
        _2 = (object)SEQ_PTR(_12152);
        _12153 = (object)*(((s1_ptr)_2)->base + 4);
        _12152 = NOVALUE;
        _12154 = find_from(109, _12153, 1);
        _12153 = NOVALUE;
        if (_12154 == 0)
        {
            _12154 = NOVALUE;
            goto L3; // [36] 212
        }
        else{
            _12154 = NOVALUE;
        }

        /** cmdline.e:971				if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_21510);
        _12155 = (object)*(((s1_ptr)_2)->base + _i_21519);
        _2 = (object)SEQ_PTR(_12155);
        _12156 = (object)*(((s1_ptr)_2)->base + 1);
        _12155 = NOVALUE;
        _12157 = IS_ATOM(_12156);
        _12156 = NOVALUE;
        if (_12157 == 0) {
            goto L4; // [52] 138
        }
        _2 = (object)SEQ_PTR(_opts_21510);
        _12159 = (object)*(((s1_ptr)_2)->base + _i_21519);
        _2 = (object)SEQ_PTR(_12159);
        _12160 = (object)*(((s1_ptr)_2)->base + 2);
        _12159 = NOVALUE;
        _12161 = IS_ATOM(_12160);
        _12160 = NOVALUE;
        if (_12161 == 0)
        {
            _12161 = NOVALUE;
            goto L4; // [68] 138
        }
        else{
            _12161 = NOVALUE;
        }

        /** cmdline.e:972					if length(map:get(parsed_opts, opts[i][MAPNAME])) = 0 then*/
        _2 = (object)SEQ_PTR(_opts_21510);
        _12162 = (object)*(((s1_ptr)_2)->base + _i_21519);
        _2 = (object)SEQ_PTR(_12162);
        _12163 = (object)*(((s1_ptr)_2)->base + 6);
        _12162 = NOVALUE;
        Ref(_parsed_opts_21512);
        Ref(_12163);
        _12164 = _34get(_parsed_opts_21512, _12163, 0);
        _12163 = NOVALUE;
        if (IS_SEQUENCE(_12164)){
                _12165 = SEQ_PTR(_12164)->length;
        }
        else {
            _12165 = 1;
        }
        DeRef(_12164);
        _12164 = NOVALUE;
        if (_12165 != 0)
        goto L5; // [90] 211

        /** cmdline.e:973						puts(1, "Additional arguments were expected.\n\n")*/
        EPuts(1, _12167); // DJP 

        /** cmdline.e:974						if help_on_error then*/
        if (_help_on_error_21516 == 0)
        {
            goto L6; // [101] 116
        }
        else{
        }

        /** cmdline.e:975							local_help(opts, add_help_rid, cmds, 1, parse_options)*/
        RefDS(_opts_21510);
        Ref(_add_help_rid_21513);
        RefDS(_cmds_21514);
        Ref(_parse_options_21515);
        _48local_help(_opts_21510, _add_help_rid_21513, _cmds_21514, 1, _parse_options_21515);
        goto L7; // [113] 129
L6: 

        /** cmdline.e:976						elsif auto_help then*/
        if (_auto_help_21517 == 0)
        {
            goto L8; // [118] 128
        }
        else{
        }

        /** cmdline.e:977							printf(2,"Try '--help' for more information.\n",{})          */
        EPrintf(2, _12087, _5);
L8: 
L7: 

        /** cmdline.e:979						local_abort(1)*/
        _48local_abort(1);
        goto L5; // [135] 211
L4: 

        /** cmdline.e:982					if not map:has(parsed_opts, opts[i][MAPNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_21510);
        _12168 = (object)*(((s1_ptr)_2)->base + _i_21519);
        _2 = (object)SEQ_PTR(_12168);
        _12169 = (object)*(((s1_ptr)_2)->base + 6);
        _12168 = NOVALUE;
        Ref(_parsed_opts_21512);
        Ref(_12169);
        _12170 = _34has(_parsed_opts_21512, _12169);
        _12169 = NOVALUE;
        if (IS_ATOM_INT(_12170)) {
            if (_12170 != 0){
                DeRef(_12170);
                _12170 = NOVALUE;
                goto L9; // [153] 210
            }
        }
        else {
            if (DBL_PTR(_12170)->dbl != 0.0){
                DeRef(_12170);
                _12170 = NOVALUE;
                goto L9; // [153] 210
            }
        }
        DeRef(_12170);
        _12170 = NOVALUE;

        /** cmdline.e:983						printf(1, "option '%s' is mandatory but was not supplied.\n\n", {opts[i][MAPNAME]})*/
        _2 = (object)SEQ_PTR(_opts_21510);
        _12173 = (object)*(((s1_ptr)_2)->base + _i_21519);
        _2 = (object)SEQ_PTR(_12173);
        _12174 = (object)*(((s1_ptr)_2)->base + 6);
        _12173 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_12174);
        ((intptr_t*)_2)[1] = _12174;
        _12175 = MAKE_SEQ(_1);
        _12174 = NOVALUE;
        EPrintf(1, _12172, _12175);
        DeRefDS(_12175);
        _12175 = NOVALUE;

        /** cmdline.e:984						if help_on_error then*/
        if (_help_on_error_21516 == 0)
        {
            goto LA; // [176] 191
        }
        else{
        }

        /** cmdline.e:985							local_help(opts, add_help_rid, cmds, 1, parse_options)*/
        RefDS(_opts_21510);
        Ref(_add_help_rid_21513);
        RefDS(_cmds_21514);
        Ref(_parse_options_21515);
        _48local_help(_opts_21510, _add_help_rid_21513, _cmds_21514, 1, _parse_options_21515);
        goto LB; // [188] 204
LA: 

        /** cmdline.e:986						elsif auto_help then*/
        if (_auto_help_21517 == 0)
        {
            goto LC; // [193] 203
        }
        else{
        }

        /** cmdline.e:987							printf(2,"Try '--help' for more information.\n",{})          */
        EPrintf(2, _12087, _5);
LC: 
LB: 

        /** cmdline.e:989						local_abort(1)*/
        _48local_abort(1);
L9: 
L5: 
L3: 

        /** cmdline.e:993		end for*/
        _i_21519 = _i_21519 + 1;
        goto L1; // [214] 21
L2: 
        ;
    }

    /** cmdline.e:994	end procedure*/
    DeRefDS(_opts_21510);
    DeRef(_parsed_opts_21512);
    DeRef(_add_help_rid_21513);
    DeRefDS(_cmds_21514);
    DeRef(_parse_options_21515);
    _12164 = NOVALUE;
    return;
    ;
}


void _48parse_abort(object _format_msg_21556, object _msg_data_21557, object _opts_21558, object _add_help_rid_21559, object _cmds_21560, object _parse_options_21561, object _help_on_error_21562, object _auto_help_21563)
{
    object _0, _1, _2;
    

    /** cmdline.e:999		printf(1, format_msg, msg_data)*/
    EPrintf(1, _format_msg_21556, _msg_data_21557);

    /** cmdline.e:1000		if help_on_error then*/
    if (_help_on_error_21562 == 0)
    {
        goto L1; // [21] 36
    }
    else{
    }

    /** cmdline.e:1001			local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_21558);
    Ref(_add_help_rid_21559);
    RefDS(_cmds_21560);
    Ref(_parse_options_21561);
    _48local_help(_opts_21558, _add_help_rid_21559, _cmds_21560, 1, _parse_options_21561);
    goto L2; // [33] 49
L1: 

    /** cmdline.e:1002		elsif auto_help then*/
    if (_auto_help_21563 == 0)
    {
        goto L3; // [38] 48
    }
    else{
    }

    /** cmdline.e:1003			printf(2,"Try '--help' for more information.\n",{})          */
    EPrintf(2, _12087, _5);
L3: 
L2: 

    /** cmdline.e:1005		local_abort(1)*/
    _48local_abort(1);

    /** cmdline.e:1006	end procedure*/
    DeRefDSi(_format_msg_21556);
    DeRefDS(_msg_data_21557);
    DeRefDS(_opts_21558);
    DeRef(_add_help_rid_21559);
    DeRefDS(_cmds_21560);
    DeRef(_parse_options_21561);
    return;
    ;
}


object _48parse_commands(object _cmds_21568, object _opts_21569, object _parsed_opts_21571, object _help_opts_21572, object _add_help_rid_21573, object _parse_options_21574, object _use_at_21575, object _validation_21576, object _has_extra_21577, object _call_count_21578, object _help_on_error_21579, object _auto_help_21580)
{
    object _arg_idx_21581 = NOVALUE;
    object _opts_done_21582 = NOVALUE;
    object _find_result_21583 = NOVALUE;
    object _type__21584 = NOVALUE;
    object _from__21585 = NOVALUE;
    object _cmd_21586 = NOVALUE;
    object _handle_result_21651 = NOVALUE;
    object _12227 = NOVALUE;
    object _12223 = NOVALUE;
    object _12222 = NOVALUE;
    object _12220 = NOVALUE;
    object _12219 = NOVALUE;
    object _12218 = NOVALUE;
    object _12216 = NOVALUE;
    object _12214 = NOVALUE;
    object _12212 = NOVALUE;
    object _12210 = NOVALUE;
    object _12209 = NOVALUE;
    object _12208 = NOVALUE;
    object _12207 = NOVALUE;
    object _12206 = NOVALUE;
    object _12202 = NOVALUE;
    object _12200 = NOVALUE;
    object _12199 = NOVALUE;
    object _12198 = NOVALUE;
    object _12197 = NOVALUE;
    object _12196 = NOVALUE;
    object _12195 = NOVALUE;
    object _12193 = NOVALUE;
    object _12192 = NOVALUE;
    object _12191 = NOVALUE;
    object _12190 = NOVALUE;
    object _12189 = NOVALUE;
    object _12188 = NOVALUE;
    object _12187 = NOVALUE;
    object _12184 = NOVALUE;
    object _12183 = NOVALUE;
    object _12182 = NOVALUE;
    object _12180 = NOVALUE;
    object _12176 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:1016		integer arg_idx = 2*/
    _arg_idx_21581 = 2;

    /** cmdline.e:1017		integer opts_done = 0*/
    _opts_done_21582 = 0;

    /** cmdline.e:1023		while arg_idx < length(cmds) do*/
L1: 
    if (IS_SEQUENCE(_cmds_21568)){
            _12176 = SEQ_PTR(_cmds_21568)->length;
    }
    else {
        _12176 = 1;
    }
    if (_arg_idx_21581 >= _12176)
    goto L2; // [37] 488

    /** cmdline.e:1024			arg_idx += 1*/
    _arg_idx_21581 = _arg_idx_21581 + 1;

    /** cmdline.e:1026			cmd = cmds[arg_idx]*/
    DeRef(_cmd_21586);
    _2 = (object)SEQ_PTR(_cmds_21568);
    _cmd_21586 = (object)*(((s1_ptr)_2)->base + _arg_idx_21581);
    Ref(_cmd_21586);

    /** cmdline.e:1027			if length(cmd) = 0 then*/
    if (IS_SEQUENCE(_cmd_21586)){
            _12180 = SEQ_PTR(_cmd_21586)->length;
    }
    else {
        _12180 = 1;
    }
    if (_12180 != 0)
    goto L3; // [60] 69

    /** cmdline.e:1028				continue*/
    goto L1; // [66] 34
L3: 

    /** cmdline.e:1031			if cmd[1] = '@' and use_at then*/
    _2 = (object)SEQ_PTR(_cmd_21586);
    _12182 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_12182)) {
        _12183 = (_12182 == 64);
    }
    else {
        _12183 = binary_op(EQUALS, _12182, 64);
    }
    _12182 = NOVALUE;
    if (IS_ATOM_INT(_12183)) {
        if (_12183 == 0) {
            goto L4; // [79] 113
        }
    }
    else {
        if (DBL_PTR(_12183)->dbl == 0.0) {
            goto L4; // [79] 113
        }
    }
    if (_use_at_21575 == 0)
    {
        goto L4; // [84] 113
    }
    else{
    }

    /** cmdline.e:1032				cmds = parse_at_cmds( cmd, cmds, opts, arg_idx, add_help_rid, parse_options, help_on_error, auto_help )*/
    RefDS(_cmd_21586);
    RefDS(_cmds_21568);
    RefDS(_opts_21569);
    Ref(_add_help_rid_21573);
    Ref(_parse_options_21574);
    _0 = _cmds_21568;
    _cmds_21568 = _48parse_at_cmds(_cmd_21586, _cmds_21568, _opts_21569, _arg_idx_21581, _add_help_rid_21573, _parse_options_21574, _help_on_error_21579, _auto_help_21580);
    DeRefDS(_0);

    /** cmdline.e:1033				arg_idx -= 1*/
    _arg_idx_21581 = _arg_idx_21581 - 1;

    /** cmdline.e:1034				continue*/
    goto L1; // [110] 34
L4: 

    /** cmdline.e:1037			if (opts_done or find(cmd[1], os:CMD_SWITCHES) = 0 or length(cmd) = 1)*/
    if (_opts_done_21582 != 0) {
        _12187 = 1;
        goto L5; // [115] 136
    }
    _2 = (object)SEQ_PTR(_cmd_21586);
    _12188 = (object)*(((s1_ptr)_2)->base + 1);
    _12189 = find_from(_12188, _3CMD_SWITCHES_1331, 1);
    _12188 = NOVALUE;
    _12190 = (_12189 == 0);
    _12189 = NOVALUE;
    _12187 = (_12190 != 0);
L5: 
    if (_12187 != 0) {
        DeRef(_12191);
        _12191 = 1;
        goto L6; // [136] 151
    }
    if (IS_SEQUENCE(_cmd_21586)){
            _12192 = SEQ_PTR(_cmd_21586)->length;
    }
    else {
        _12192 = 1;
    }
    _12193 = (_12192 == 1);
    _12192 = NOVALUE;
    _12191 = (_12193 != 0);
L6: 
    if (_12191 == 0)
    {
        _12191 = NOVALUE;
        goto L7; // [151] 227
    }
    else{
        _12191 = NOVALUE;
    }

    /** cmdline.e:1039				map:put(parsed_opts, EXTRAS, cmd, map:APPEND)*/
    Ref(_parsed_opts_21571);
    RefDS(_48EXTRAS_20639);
    RefDS(_cmd_21586);
    _34put(_parsed_opts_21571, _48EXTRAS_20639, _cmd_21586, 6, 0);

    /** cmdline.e:1040				has_extra = 1*/
    _has_extra_21577 = 1;

    /** cmdline.e:1041				if validation = NO_VALIDATION_AFTER_FIRST_EXTRA then*/
    if (_validation_21576 != 4)
    goto L1; // [172] 34

    /** cmdline.e:1042					for i = arg_idx + 1 to length(cmds) do*/
    _12195 = _arg_idx_21581 + 1;
    if (_12195 > MAXINT){
        _12195 = NewDouble((eudouble)_12195);
    }
    if (IS_SEQUENCE(_cmds_21568)){
            _12196 = SEQ_PTR(_cmds_21568)->length;
    }
    else {
        _12196 = 1;
    }
    {
        object _i_21612;
        Ref(_12195);
        _i_21612 = _12195;
L8: 
        if (binary_op_a(GREATER, _i_21612, _12196)){
            goto L9; // [185] 214
        }

        /** cmdline.e:1043						map:put(parsed_opts, EXTRAS, cmds[i], map:APPEND)*/
        _2 = (object)SEQ_PTR(_cmds_21568);
        if (!IS_ATOM_INT(_i_21612)){
            _12197 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_21612)->dbl));
        }
        else{
            _12197 = (object)*(((s1_ptr)_2)->base + _i_21612);
        }
        Ref(_parsed_opts_21571);
        RefDS(_48EXTRAS_20639);
        Ref(_12197);
        _34put(_parsed_opts_21571, _48EXTRAS_20639, _12197, 6, 0);
        _12197 = NOVALUE;

        /** cmdline.e:1044					end for*/
        _0 = _i_21612;
        if (IS_ATOM_INT(_i_21612)) {
            _i_21612 = _i_21612 + 1;
            if ((object)((uintptr_t)_i_21612 +(uintptr_t) HIGH_BITS) >= 0){
                _i_21612 = NewDouble((eudouble)_i_21612);
            }
        }
        else {
            _i_21612 = binary_op_a(PLUS, _i_21612, 1);
        }
        DeRef(_0);
        goto L8; // [209] 192
L9: 
        ;
        DeRef(_i_21612);
    }

    /** cmdline.e:1046					exit*/
    goto L2; // [216] 488
    goto LA; // [218] 226

    /** cmdline.e:1048					continue*/
    goto L1; // [223] 34
LA: 
L7: 

    /** cmdline.e:1052			if equal(cmd, "--") then*/
    if (_cmd_21586 == _11923)
    _12198 = 1;
    else if (IS_ATOM_INT(_cmd_21586) && IS_ATOM_INT(_11923))
    _12198 = 0;
    else
    _12198 = (compare(_cmd_21586, _11923) == 0);
    if (_12198 == 0)
    {
        _12198 = NOVALUE;
        goto LB; // [233] 246
    }
    else{
        _12198 = NOVALUE;
    }

    /** cmdline.e:1053				opts_done = 1*/
    _opts_done_21582 = 1;

    /** cmdline.e:1054				continue*/
    goto L1; // [243] 34
LB: 

    /** cmdline.e:1057			if equal(cmd[1..2], "--") then	  -- found --opt-name*/
    rhs_slice_target = (object_ptr)&_12199;
    RHS_Slice(_cmd_21586, 1, 2);
    if (_12199 == _11923)
    _12200 = 1;
    else if (IS_ATOM_INT(_12199) && IS_ATOM_INT(_11923))
    _12200 = 0;
    else
    _12200 = (compare(_12199, _11923) == 0);
    DeRefDS(_12199);
    _12199 = NOVALUE;
    if (_12200 == 0)
    {
        _12200 = NOVALUE;
        goto LC; // [257] 274
    }
    else{
        _12200 = NOVALUE;
    }

    /** cmdline.e:1058				type_ = {LONGNAME, "--"}*/
    RefDS(_11923);
    DeRef(_type__21584);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 2;
    ((intptr_t *)_2)[2] = _11923;
    _type__21584 = MAKE_SEQ(_1);

    /** cmdline.e:1059				from_ = 3*/
    _from__21585 = 3;
    goto LD; // [271] 310
LC: 

    /** cmdline.e:1060			elsif cmd[1] = '-' then -- found -opt*/
    _2 = (object)SEQ_PTR(_cmd_21586);
    _12202 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _12202, 45)){
        _12202 = NOVALUE;
        goto LE; // [280] 298
    }
    _12202 = NOVALUE;

    /** cmdline.e:1061				type_ = {SHORTNAME, "-"}*/
    RefDS(_12011);
    DeRef(_type__21584);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = _12011;
    _type__21584 = MAKE_SEQ(_1);

    /** cmdline.e:1062				from_ = 2*/
    _from__21585 = 2;
    goto LD; // [295] 310
LE: 

    /** cmdline.e:1064				type_ = {SHORTNAME, "/"}*/
    RefDS(_11430);
    DeRef(_type__21584);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = _11430;
    _type__21584 = MAKE_SEQ(_1);

    /** cmdline.e:1065				from_ = 2*/
    _from__21585 = 2;
LD: 

    /** cmdline.e:1068			if find(cmd[from_..$], help_opts) then*/
    if (IS_SEQUENCE(_cmd_21586)){
            _12206 = SEQ_PTR(_cmd_21586)->length;
    }
    else {
        _12206 = 1;
    }
    rhs_slice_target = (object_ptr)&_12207;
    RHS_Slice(_cmd_21586, _from__21585, _12206);
    _12208 = find_from(_12207, _help_opts_21572, 1);
    DeRefDS(_12207);
    _12207 = NOVALUE;
    if (_12208 == 0)
    {
        _12208 = NOVALUE;
        goto LF; // [327] 347
    }
    else{
        _12208 = NOVALUE;
    }

    /** cmdline.e:1069				local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_21569);
    Ref(_add_help_rid_21573);
    RefDS(_cmds_21568);
    Ref(_parse_options_21574);
    _48local_help(_opts_21569, _add_help_rid_21573, _cmds_21568, 1, _parse_options_21574);

    /** cmdline.e:1070				ifdef UNITTEST then*/

    /** cmdline.e:1073				local_abort(0)*/
    _48local_abort(0);
LF: 

    /** cmdline.e:1076			find_result = find_opt(opts, type_, cmd[from_..$])*/
    if (IS_SEQUENCE(_cmd_21586)){
            _12209 = SEQ_PTR(_cmd_21586)->length;
    }
    else {
        _12209 = 1;
    }
    rhs_slice_target = (object_ptr)&_12210;
    RHS_Slice(_cmd_21586, _from__21585, _12209);
    RefDS(_opts_21569);
    RefDS(_type__21584);
    _0 = _find_result_21583;
    _find_result_21583 = _48find_opt(_opts_21569, _type__21584, _12210);
    DeRef(_0);
    _12210 = NOVALUE;

    /** cmdline.e:1078			if find_result[1] < 0 then*/
    _2 = (object)SEQ_PTR(_find_result_21583);
    _12212 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _12212, 0)){
        _12212 = NOVALUE;
        goto L10; // [373] 382
    }
    _12212 = NOVALUE;

    /** cmdline.e:1079				continue -- Couldn't use this command argument for anything.*/
    goto L1; // [379] 34
L10: 

    /** cmdline.e:1082			if find_result[1] = 0 then*/
    _2 = (object)SEQ_PTR(_find_result_21583);
    _12214 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _12214, 0)){
        _12214 = NOVALUE;
        goto L11; // [388] 449
    }
    _12214 = NOVALUE;

    /** cmdline.e:1083				if validation = VALIDATE_ALL or*/
    _12216 = (_validation_21576 == 2);
    if (_12216 != 0) {
        goto L12; // [398] 423
    }
    _12218 = (_validation_21576 == 4);
    if (_12218 == 0) {
        DeRef(_12219);
        _12219 = 0;
        goto L13; // [406] 418
    }
    _12220 = (_has_extra_21577 == 0);
    _12219 = (_12220 != 0);
L13: 
    if (_12219 == 0)
    {
        _12219 = NOVALUE;
        goto L1; // [419] 34
    }
    else{
        _12219 = NOVALUE;
    }
L12: 

    /** cmdline.e:1087					parse_abort( "option '%s': %s\n\n", {cmd, find_result[2]}, */
    _2 = (object)SEQ_PTR(_find_result_21583);
    _12222 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_12222);
    RefDS(_cmd_21586);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _cmd_21586;
    ((intptr_t *)_2)[2] = _12222;
    _12223 = MAKE_SEQ(_1);
    _12222 = NOVALUE;
    RefDS(_12221);
    RefDS(_opts_21569);
    Ref(_add_help_rid_21573);
    RefDS(_cmds_21568);
    Ref(_parse_options_21574);
    _48parse_abort(_12221, _12223, _opts_21569, _add_help_rid_21573, _cmds_21568, _parse_options_21574, _help_on_error_21579, _auto_help_21580);
    _12223 = NOVALUE;

    /** cmdline.e:1091				continue*/
    goto L1; // [446] 34
L11: 

    /** cmdline.e:1094			sequence handle_result = handle_opt( find_result, arg_idx, opts, parsed_opts, cmds, add_help_rid,*/
    RefDS(_find_result_21583);
    RefDS(_opts_21569);
    Ref(_parsed_opts_21571);
    RefDS(_cmds_21568);
    Ref(_add_help_rid_21573);
    Ref(_parse_options_21574);
    RefDS(_call_count_21578);
    _0 = _handle_result_21651;
    _handle_result_21651 = _48handle_opt(_find_result_21583, _arg_idx_21581, _opts_21569, _parsed_opts_21571, _cmds_21568, _add_help_rid_21573, _parse_options_21574, _call_count_21578, _validation_21576, _help_on_error_21579, _auto_help_21580);
    DeRef(_0);

    /** cmdline.e:1096			arg_idx     = handle_result[1]*/
    _2 = (object)SEQ_PTR(_handle_result_21651);
    _arg_idx_21581 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_arg_idx_21581))
    _arg_idx_21581 = (object)DBL_PTR(_arg_idx_21581)->dbl;

    /** cmdline.e:1097			call_count = handle_result[2]*/
    DeRefDS(_call_count_21578);
    _2 = (object)SEQ_PTR(_handle_result_21651);
    _call_count_21578 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_call_count_21578);
    DeRefDS(_handle_result_21651);
    _handle_result_21651 = NOVALUE;

    /** cmdline.e:1098		end while*/
    goto L1; // [485] 34
L2: 

    /** cmdline.e:1099		return { cmds, call_count }*/
    RefDS(_call_count_21578);
    RefDS(_cmds_21568);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _cmds_21568;
    ((intptr_t *)_2)[2] = _call_count_21578;
    _12227 = MAKE_SEQ(_1);
    DeRefDS(_cmds_21568);
    DeRefDS(_opts_21569);
    DeRef(_parsed_opts_21571);
    DeRefDS(_help_opts_21572);
    DeRef(_add_help_rid_21573);
    DeRef(_parse_options_21574);
    DeRefDS(_call_count_21578);
    DeRef(_find_result_21583);
    DeRef(_type__21584);
    DeRef(_cmd_21586);
    DeRef(_12195);
    _12195 = NOVALUE;
    DeRef(_12193);
    _12193 = NOVALUE;
    DeRef(_12218);
    _12218 = NOVALUE;
    DeRef(_12216);
    _12216 = NOVALUE;
    DeRef(_12190);
    _12190 = NOVALUE;
    DeRef(_12220);
    _12220 = NOVALUE;
    DeRef(_12183);
    _12183 = NOVALUE;
    return _12227;
    ;
}


object _48handle_opt(object _find_result_21659, object _arg_idx_21660, object _opts_21661, object _parsed_opts_21663, object _cmds_21664, object _add_help_rid_21665, object _parse_options_21666, object _call_count_21667, object _validation_21668, object _help_on_error_21669, object _auto_help_21670)
{
    object _map_add_operation_21671 = NOVALUE;
    object _opt_21672 = NOVALUE;
    object _param_21675 = NOVALUE;
    object _pos_21713 = NOVALUE;
    object _ver_pos_21759 = NOVALUE;
    object _msg_inlined_crash_at_524_21776 = NOVALUE;
    object _fmt_inlined_crash_at_521_21775 = NOVALUE;
    object _12306 = NOVALUE;
    object _12305 = NOVALUE;
    object _12302 = NOVALUE;
    object _12301 = NOVALUE;
    object _12300 = NOVALUE;
    object _12298 = NOVALUE;
    object _12297 = NOVALUE;
    object _12295 = NOVALUE;
    object _12294 = NOVALUE;
    object _12293 = NOVALUE;
    object _12292 = NOVALUE;
    object _12291 = NOVALUE;
    object _12290 = NOVALUE;
    object _12289 = NOVALUE;
    object _12288 = NOVALUE;
    object _12286 = NOVALUE;
    object _12285 = NOVALUE;
    object _12283 = NOVALUE;
    object _12282 = NOVALUE;
    object _12281 = NOVALUE;
    object _12280 = NOVALUE;
    object _12279 = NOVALUE;
    object _12278 = NOVALUE;
    object _12277 = NOVALUE;
    object _12276 = NOVALUE;
    object _12274 = NOVALUE;
    object _12273 = NOVALUE;
    object _12272 = NOVALUE;
    object _12270 = NOVALUE;
    object _12269 = NOVALUE;
    object _12267 = NOVALUE;
    object _12266 = NOVALUE;
    object _12265 = NOVALUE;
    object _12264 = NOVALUE;
    object _12263 = NOVALUE;
    object _12262 = NOVALUE;
    object _12261 = NOVALUE;
    object _12260 = NOVALUE;
    object _12259 = NOVALUE;
    object _12256 = NOVALUE;
    object _12253 = NOVALUE;
    object _12252 = NOVALUE;
    object _12250 = NOVALUE;
    object _12249 = NOVALUE;
    object _12248 = NOVALUE;
    object _12247 = NOVALUE;
    object _12246 = NOVALUE;
    object _12245 = NOVALUE;
    object _12244 = NOVALUE;
    object _12242 = NOVALUE;
    object _12241 = NOVALUE;
    object _12240 = NOVALUE;
    object _12239 = NOVALUE;
    object _12236 = NOVALUE;
    object _12233 = NOVALUE;
    object _12231 = NOVALUE;
    object _12230 = NOVALUE;
    object _12228 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:1110		integer map_add_operation = map:ADD*/
    _map_add_operation_21671 = 2;

    /** cmdline.e:1111		sequence opt = opts[find_result[1]]*/
    _2 = (object)SEQ_PTR(_find_result_21659);
    _12228 = (object)*(((s1_ptr)_2)->base + 1);
    DeRef(_opt_21672);
    _2 = (object)SEQ_PTR(_opts_21661);
    if (!IS_ATOM_INT(_12228)){
        _opt_21672 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12228)->dbl));
    }
    else{
        _opt_21672 = (object)*(((s1_ptr)_2)->base + _12228);
    }
    Ref(_opt_21672);

    /** cmdline.e:1114		if find(HAS_PARAMETER, opt[OPTIONS]) != 0 then*/
    _2 = (object)SEQ_PTR(_opt_21672);
    _12230 = (object)*(((s1_ptr)_2)->base + 4);
    _12231 = find_from(112, _12230, 1);
    _12230 = NOVALUE;
    if (_12231 == 0)
    goto L1; // [45] 194

    /** cmdline.e:1115			map_add_operation = map:APPEND*/
    _map_add_operation_21671 = 6;

    /** cmdline.e:1116			if length(find_result) < 4 then*/
    if (IS_SEQUENCE(_find_result_21659)){
            _12233 = SEQ_PTR(_find_result_21659)->length;
    }
    else {
        _12233 = 1;
    }
    if (_12233 >= 4)
    goto L2; // [59] 184

    /** cmdline.e:1117				arg_idx += 1*/
    _arg_idx_21660 = _arg_idx_21660 + 1;

    /** cmdline.e:1118				if arg_idx <= length(cmds) then*/
    if (IS_SEQUENCE(_cmds_21664)){
            _12236 = SEQ_PTR(_cmds_21664)->length;
    }
    else {
        _12236 = 1;
    }
    if (_arg_idx_21660 > _12236)
    goto L3; // [74] 119

    /** cmdline.e:1119					param = cmds[arg_idx]*/
    DeRef(_param_21675);
    _2 = (object)SEQ_PTR(_cmds_21664);
    _param_21675 = (object)*(((s1_ptr)_2)->base + _arg_idx_21660);
    Ref(_param_21675);

    /** cmdline.e:1120					if length(param) = 2 and find(param[1], "-/") then*/
    if (IS_SEQUENCE(_param_21675)){
            _12239 = SEQ_PTR(_param_21675)->length;
    }
    else {
        _12239 = 1;
    }
    _12240 = (_12239 == 2);
    _12239 = NOVALUE;
    if (_12240 == 0) {
        goto L4; // [93] 125
    }
    _2 = (object)SEQ_PTR(_param_21675);
    _12242 = (object)*(((s1_ptr)_2)->base + 1);
    _12244 = find_from(_12242, _12243, 1);
    _12242 = NOVALUE;
    if (_12244 == 0)
    {
        _12244 = NOVALUE;
        goto L4; // [107] 125
    }
    else{
        _12244 = NOVALUE;
    }

    /** cmdline.e:1121						param = ""*/
    RefDS(_5);
    DeRef(_param_21675);
    _param_21675 = _5;
    goto L4; // [116] 125
L3: 

    /** cmdline.e:1124					param = ""*/
    RefDS(_5);
    DeRef(_param_21675);
    _param_21675 = _5;
L4: 

    /** cmdline.e:1127				if length(param) = 0 and (validation = VALIDATE_ALL or (*/
    if (IS_SEQUENCE(_param_21675)){
            _12245 = SEQ_PTR(_param_21675)->length;
    }
    else {
        _12245 = 1;
    }
    _12246 = (_12245 == 0);
    _12245 = NOVALUE;
    if (_12246 == 0) {
        goto L5; // [136] 201
    }
    _12248 = (_validation_21668 == 2);
    if (_12248 != 0) {
        DeRef(_12249);
        _12249 = 1;
        goto L6; // [144] 156
    }
    _12250 = (_validation_21668 == 4);
    _12249 = (_12250 != 0);
L6: 
    if (_12249 == 0)
    {
        _12249 = NOVALUE;
        goto L5; // [157] 201
    }
    else{
        _12249 = NOVALUE;
    }

    /** cmdline.e:1130					parse_abort( "option '%s' must have a parameter\n\n", {find_result[2]}, */
    _2 = (object)SEQ_PTR(_find_result_21659);
    _12252 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_12252);
    ((intptr_t*)_2)[1] = _12252;
    _12253 = MAKE_SEQ(_1);
    _12252 = NOVALUE;
    RefDS(_12251);
    RefDS(_opts_21661);
    Ref(_add_help_rid_21665);
    RefDS(_cmds_21664);
    Ref(_parse_options_21666);
    _48parse_abort(_12251, _12253, _opts_21661, _add_help_rid_21665, _cmds_21664, _parse_options_21666, _help_on_error_21669, _auto_help_21670);
    _12253 = NOVALUE;
    goto L5; // [181] 201
L2: 

    /** cmdline.e:1134				param = find_result[4]*/
    DeRef(_param_21675);
    _2 = (object)SEQ_PTR(_find_result_21659);
    _param_21675 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_param_21675);
    goto L5; // [191] 201
L1: 

    /** cmdline.e:1137			param = find_result[4]*/
    DeRef(_param_21675);
    _2 = (object)SEQ_PTR(_find_result_21659);
    _param_21675 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_param_21675);
L5: 

    /** cmdline.e:1140		if opt[CALLBACK] >= 0 then*/
    _2 = (object)SEQ_PTR(_opt_21672);
    _12256 = (object)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(LESS, _12256, 0)){
        _12256 = NOVALUE;
        goto L7; // [207] 282
    }
    _12256 = NOVALUE;

    /** cmdline.e:1141			integer pos = find_result[1]*/
    _2 = (object)SEQ_PTR(_find_result_21659);
    _pos_21713 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_pos_21713))
    _pos_21713 = (object)DBL_PTR(_pos_21713)->dbl;

    /** cmdline.e:1142			call_count[pos] += 1*/
    _2 = (object)SEQ_PTR(_call_count_21667);
    _12259 = (object)*(((s1_ptr)_2)->base + _pos_21713);
    if (IS_ATOM_INT(_12259)) {
        _12260 = _12259 + 1;
        if (_12260 > MAXINT){
            _12260 = NewDouble((eudouble)_12260);
        }
    }
    else
    _12260 = binary_op(PLUS, 1, _12259);
    _12259 = NOVALUE;
    _2 = (object)SEQ_PTR(_call_count_21667);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _call_count_21667 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pos_21713);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12260;
    if( _1 != _12260 ){
        DeRef(_1);
    }
    _12260 = NOVALUE;

    /** cmdline.e:1144			if call_func(opt[CALLBACK], {{find_result[1], call_count[pos], param,  find_result[3]}}) = 0 then*/
    _2 = (object)SEQ_PTR(_opt_21672);
    _12261 = (object)*(((s1_ptr)_2)->base + 5);
    _2 = (object)SEQ_PTR(_find_result_21659);
    _12262 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_call_count_21667);
    _12263 = (object)*(((s1_ptr)_2)->base + _pos_21713);
    _2 = (object)SEQ_PTR(_find_result_21659);
    _12264 = (object)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_12262);
    ((intptr_t*)_2)[1] = _12262;
    Ref(_12263);
    ((intptr_t*)_2)[2] = _12263;
    Ref(_param_21675);
    ((intptr_t*)_2)[3] = _param_21675;
    Ref(_12264);
    ((intptr_t*)_2)[4] = _12264;
    _12265 = MAKE_SEQ(_1);
    _12264 = NOVALUE;
    _12263 = NOVALUE;
    _12262 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _12265;
    _12266 = MAKE_SEQ(_1);
    _12265 = NOVALUE;
    _1 = (object)SEQ_PTR(_12266);
    _2 = (object)((s1_ptr)_1)->base;
    _0 = (object)_00[_12261].addr;
    Ref( *(( (intptr_t*)_2) + 1) );
    _1 = (*(intptr_t (*)())_0)(
                        *( ((intptr_t *)_2) + 1)
                         );
    DeRef(_12267);
    _12267 = _1;
    DeRefDS(_12266);
    _12266 = NOVALUE;
    if (binary_op_a(NOTEQ, _12267, 0)){
        DeRef(_12267);
        _12267 = NOVALUE;
        goto L8; // [266] 281
    }
    DeRef(_12267);
    _12267 = NOVALUE;

    /** cmdline.e:1145				return { arg_idx, call_count }*/
    RefDS(_call_count_21667);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _arg_idx_21660;
    ((intptr_t *)_2)[2] = _call_count_21667;
    _12269 = MAKE_SEQ(_1);
    DeRefDS(_find_result_21659);
    DeRefDS(_opts_21661);
    DeRef(_parsed_opts_21663);
    DeRefDS(_cmds_21664);
    DeRef(_add_help_rid_21665);
    DeRef(_parse_options_21666);
    DeRefDS(_call_count_21667);
    DeRefDS(_opt_21672);
    DeRef(_param_21675);
    _12261 = NOVALUE;
    DeRef(_12240);
    _12240 = NOVALUE;
    _12228 = NOVALUE;
    DeRef(_12246);
    _12246 = NOVALUE;
    DeRef(_12250);
    _12250 = NOVALUE;
    DeRef(_12248);
    _12248 = NOVALUE;
    return _12269;
L8: 
L7: 

    /** cmdline.e:1149		if find_result[3] = 1 then*/
    _2 = (object)SEQ_PTR(_find_result_21659);
    _12270 = (object)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _12270, 1)){
        _12270 = NOVALUE;
        goto L9; // [290] 307
    }
    _12270 = NOVALUE;

    /** cmdline.e:1150			map:remove(parsed_opts, opt[MAPNAME])*/
    _2 = (object)SEQ_PTR(_opt_21672);
    _12272 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_21663);
    Ref(_12272);
    _34remove(_parsed_opts_21663, _12272);
    _12272 = NOVALUE;
    goto LA; // [304] 446
L9: 

    /** cmdline.e:1152			if find(MULTIPLE, opt[OPTIONS]) = 0 then*/
    _2 = (object)SEQ_PTR(_opt_21672);
    _12273 = (object)*(((s1_ptr)_2)->base + 4);
    _12274 = find_from(42, _12273, 1);
    _12273 = NOVALUE;
    if (_12274 != 0)
    goto LB; // [318] 429

    /** cmdline.e:1153				if map:has(parsed_opts, opt[MAPNAME]) and (validation = VALIDATE_ALL or*/
    _2 = (object)SEQ_PTR(_opt_21672);
    _12276 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_21663);
    Ref(_12276);
    _12277 = _34has(_parsed_opts_21663, _12276);
    _12276 = NOVALUE;
    if (IS_ATOM_INT(_12277)) {
        if (_12277 == 0) {
            goto LC; // [333] 410
        }
    }
    else {
        if (DBL_PTR(_12277)->dbl == 0.0) {
            goto LC; // [333] 410
        }
    }
    _12279 = (_validation_21668 == 2);
    if (_12279 != 0) {
        DeRef(_12280);
        _12280 = 1;
        goto LD; // [341] 353
    }
    _12281 = (_validation_21668 == 4);
    _12280 = (_12281 != 0);
LD: 
    if (_12280 == 0)
    {
        _12280 = NOVALUE;
        goto LC; // [354] 410
    }
    else{
        _12280 = NOVALUE;
    }

    /** cmdline.e:1156					if find(HAS_PARAMETER, opt[OPTIONS]) or find(ONCE, opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_opt_21672);
    _12282 = (object)*(((s1_ptr)_2)->base + 4);
    _12283 = find_from(112, _12282, 1);
    _12282 = NOVALUE;
    if (_12283 != 0) {
        goto LE; // [368] 386
    }
    _2 = (object)SEQ_PTR(_opt_21672);
    _12285 = (object)*(((s1_ptr)_2)->base + 4);
    _12286 = find_from(49, _12285, 1);
    _12285 = NOVALUE;
    if (_12286 == 0)
    {
        _12286 = NOVALUE;
        goto LF; // [382] 445
    }
    else{
        _12286 = NOVALUE;
    }
LE: 

    /** cmdline.e:1157						parse_abort( "option '%s' must not occur more than once in the command line.\n\n", */
    _2 = (object)SEQ_PTR(_find_result_21659);
    _12288 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_12288);
    ((intptr_t*)_2)[1] = _12288;
    _12289 = MAKE_SEQ(_1);
    _12288 = NOVALUE;
    RefDS(_12287);
    RefDS(_opts_21661);
    Ref(_add_help_rid_21665);
    RefDS(_cmds_21664);
    Ref(_parse_options_21666);
    _48parse_abort(_12287, _12289, _opts_21661, _add_help_rid_21665, _cmds_21664, _parse_options_21666, _help_on_error_21669, _auto_help_21670);
    _12289 = NOVALUE;
    goto LF; // [407] 445
LC: 

    /** cmdline.e:1161					map:put(parsed_opts, opt[MAPNAME], param)*/
    _2 = (object)SEQ_PTR(_opt_21672);
    _12290 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_21663);
    Ref(_12290);
    Ref(_param_21675);
    _34put(_parsed_opts_21663, _12290, _param_21675, 1, 0);
    _12290 = NOVALUE;
    goto LF; // [426] 445
LB: 

    /** cmdline.e:1164				map:put(parsed_opts, opt[MAPNAME], param, map_add_operation)*/
    _2 = (object)SEQ_PTR(_opt_21672);
    _12291 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_21663);
    Ref(_12291);
    Ref(_param_21675);
    _34put(_parsed_opts_21663, _12291, _param_21675, _map_add_operation_21671, 0);
    _12291 = NOVALUE;
LF: 
LA: 

    /** cmdline.e:1168		if find(VERSIONING, opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_opt_21672);
    _12292 = (object)*(((s1_ptr)_2)->base + 4);
    _12293 = find_from(118, _12292, 1);
    _12292 = NOVALUE;
    if (_12293 == 0)
    {
        _12293 = NOVALUE;
        goto L10; // [457] 544
    }
    else{
        _12293 = NOVALUE;
    }

    /** cmdline.e:1169			integer ver_pos = find(VERSIONING, opt[OPTIONS]) + 1*/
    _2 = (object)SEQ_PTR(_opt_21672);
    _12294 = (object)*(((s1_ptr)_2)->base + 4);
    _12295 = find_from(118, _12294, 1);
    _12294 = NOVALUE;
    _ver_pos_21759 = _12295 + 1;
    _12295 = NOVALUE;

    /** cmdline.e:1170			if length(opt[OPTIONS]) >= ver_pos then*/
    _2 = (object)SEQ_PTR(_opt_21672);
    _12297 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_12297)){
            _12298 = SEQ_PTR(_12297)->length;
    }
    else {
        _12298 = 1;
    }
    _12297 = NOVALUE;
    if (_12298 < _ver_pos_21759)
    goto L11; // [484] 513

    /** cmdline.e:1171				printf(1, "%s\n", { opt[OPTIONS][ver_pos] })*/
    _2 = (object)SEQ_PTR(_opt_21672);
    _12300 = (object)*(((s1_ptr)_2)->base + 4);
    _2 = (object)SEQ_PTR(_12300);
    _12301 = (object)*(((s1_ptr)_2)->base + _ver_pos_21759);
    _12300 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_12301);
    ((intptr_t*)_2)[1] = _12301;
    _12302 = MAKE_SEQ(_1);
    _12301 = NOVALUE;
    EPrintf(1, _11827, _12302);
    DeRefDS(_12302);
    _12302 = NOVALUE;

    /** cmdline.e:1172				abort(0)*/
    UserCleanup(0);
    goto L12; // [510] 543
L11: 

    /** cmdline.e:1174				error:crash("help options are incorrect,\n" &*/
    Concat((object_ptr)&_12305, _12303, _12304);
    DeRefi(_fmt_inlined_crash_at_521_21775);
    _fmt_inlined_crash_at_521_21775 = _12305;
    _12305 = NOVALUE;

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_524_21776);
    _msg_inlined_crash_at_524_21776 = EPrintf(-9999999, _fmt_inlined_crash_at_521_21775, _5);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_524_21776);

    /** error.e:53	end procedure*/
    goto L13; // [537] 540
L13: 
    DeRefi(_fmt_inlined_crash_at_521_21775);
    _fmt_inlined_crash_at_521_21775 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_524_21776);
    _msg_inlined_crash_at_524_21776 = NOVALUE;
L12: 
L10: 

    /** cmdline.e:1178		return {arg_idx, call_count}*/
    RefDS(_call_count_21667);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _arg_idx_21660;
    ((intptr_t *)_2)[2] = _call_count_21667;
    _12306 = MAKE_SEQ(_1);
    DeRefDS(_find_result_21659);
    DeRefDS(_opts_21661);
    DeRef(_parsed_opts_21663);
    DeRefDS(_cmds_21664);
    DeRef(_add_help_rid_21665);
    DeRef(_parse_options_21666);
    DeRefDS(_call_count_21667);
    DeRef(_opt_21672);
    DeRef(_param_21675);
    _12261 = NOVALUE;
    _12297 = NOVALUE;
    DeRef(_12277);
    _12277 = NOVALUE;
    DeRef(_12240);
    _12240 = NOVALUE;
    _12228 = NOVALUE;
    DeRef(_12246);
    _12246 = NOVALUE;
    DeRef(_12250);
    _12250 = NOVALUE;
    DeRef(_12269);
    _12269 = NOVALUE;
    DeRef(_12281);
    _12281 = NOVALUE;
    DeRef(_12279);
    _12279 = NOVALUE;
    DeRef(_12248);
    _12248 = NOVALUE;
    return _12306;
    ;
}


object _48cmd_parse(object _opts_21780, object _parse_options_21781, object _cmds_21782)
{
    object _cmd_21784 = NOVALUE;
    object _help_opts_21785 = NOVALUE;
    object _call_count_21786 = NOVALUE;
    object _add_help_rid_21787 = NOVALUE;
    object _validation_21788 = NOVALUE;
    object _has_extra_21789 = NOVALUE;
    object _use_at_21790 = NOVALUE;
    object _auto_help_21791 = NOVALUE;
    object _help_on_error_21792 = NOVALUE;
    object _po_21793 = NOVALUE;
    object _msg_inlined_crash_at_161_21817 = NOVALUE;
    object _msg_inlined_crash_at_225_21828 = NOVALUE;
    object _msg_inlined_crash_at_263_21835 = NOVALUE;
    object _fmt_inlined_crash_at_260_21834 = NOVALUE;
    object _parsed_opts_21840 = NOVALUE;
    object _new_1__tmp_at315_21843 = NOVALUE;
    object _new_inlined_new_at_315_21842 = NOVALUE;
    object _cmds_ok_21845 = NOVALUE;
    object _12333 = NOVALUE;
    object _12329 = NOVALUE;
    object _12326 = NOVALUE;
    object _12325 = NOVALUE;
    object _12319 = NOVALUE;
    object _12315 = NOVALUE;
    object _12312 = NOVALUE;
    object _12310 = NOVALUE;
    object _12308 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:1428		object add_help_rid = -1*/
    DeRef(_add_help_rid_21787);
    _add_help_rid_21787 = -1;

    /** cmdline.e:1429		integer validation = VALIDATE_ALL*/
    _validation_21788 = 2;

    /** cmdline.e:1430		integer has_extra = 0*/
    _has_extra_21789 = 0;

    /** cmdline.e:1431		integer use_at = 1*/
    _use_at_21790 = 1;

    /** cmdline.e:1432		integer auto_help = 1*/
    _auto_help_21791 = 1;

    /** cmdline.e:1433		integer help_on_error = 1*/
    _help_on_error_21792 = 1;

    /** cmdline.e:1435		integer po = 1*/
    _po_21793 = 1;

    /** cmdline.e:1436		if atom(parse_options) then*/
    _12308 = 0;
    if (_12308 == 0)
    {
        _12308 = NOVALUE;
        goto L1; // [45] 55
    }
    else{
        _12308 = NOVALUE;
    }

    /** cmdline.e:1437			parse_options = {parse_options}*/
    _0 = _parse_options_21781;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_parse_options_21781);
    ((intptr_t*)_2)[1] = _parse_options_21781;
    _parse_options_21781 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** cmdline.e:1441		while po <= length(parse_options) do*/
L2: 
    if (IS_SEQUENCE(_parse_options_21781)){
            _12310 = SEQ_PTR(_parse_options_21781)->length;
    }
    else {
        _12310 = 1;
    }
    if (_po_21793 > _12310)
    goto L3; // [63] 296

    /** cmdline.e:1442			switch parse_options[po] do*/
    _2 = (object)SEQ_PTR(_parse_options_21781);
    _12312 = (object)*(((s1_ptr)_2)->base + _po_21793);
    if (IS_SEQUENCE(_12312) ){
        goto L4; // [73] 249
    }
    if(!IS_ATOM_INT(_12312)){
        if( (DBL_PTR(_12312)->dbl != (eudouble) ((object) DBL_PTR(_12312)->dbl) ) ){
            goto L4; // [73] 249
        }
        _0 = (object) DBL_PTR(_12312)->dbl;
    }
    else {
        _0 = _12312;
    };
    _12312 = NOVALUE;
    switch ( _0 ){ 

        /** cmdline.e:1444				case NO_HELP then                         auto_help = 0*/
        case 9:
        _auto_help_21791 = 0;
        goto L5; // [85] 285

        /** cmdline.e:1445				case VALIDATE_ALL then                    validation = VALIDATE_ALL*/
        case 2:
        _validation_21788 = 2;
        goto L5; // [94] 285

        /** cmdline.e:1446				case NO_VALIDATION then                   validation = NO_VALIDATION*/
        case 3:
        _validation_21788 = 3;
        goto L5; // [103] 285

        /** cmdline.e:1447				case NO_VALIDATION_AFTER_FIRST_EXTRA then validation = NO_VALIDATION_AFTER_FIRST_EXTRA*/
        case 4:
        _validation_21788 = 4;
        goto L5; // [112] 285

        /** cmdline.e:1448				case NO_AT_EXPANSION then                 use_at = 0*/
        case 7:
        _use_at_21790 = 0;
        goto L5; // [121] 285

        /** cmdline.e:1449				case AT_EXPANSION then                    use_at = 1*/
        case 6:
        _use_at_21790 = 1;
        goto L5; // [130] 285

        /** cmdline.e:1451				case HELP_RID then*/
        case 1:

        /** cmdline.e:1452					if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_21781)){
                _12315 = SEQ_PTR(_parse_options_21781)->length;
        }
        else {
            _12315 = 1;
        }
        if (_po_21793 >= _12315)
        goto L6; // [141] 160

        /** cmdline.e:1453						po += 1*/
        _po_21793 = _po_21793 + 1;

        /** cmdline.e:1454						add_help_rid = parse_options[po]*/
        DeRef(_add_help_rid_21787);
        _2 = (object)SEQ_PTR(_parse_options_21781);
        _add_help_rid_21787 = (object)*(((s1_ptr)_2)->base + _po_21793);
        Ref(_add_help_rid_21787);
        goto L5; // [157] 285
L6: 

        /** cmdline.e:1456						error:crash("HELP_RID was given to cmd_parse with no routine_id")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_161_21817);
        _msg_inlined_crash_at_161_21817 = EPrintf(-9999999, _11862, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_161_21817);

        /** error.e:53	end procedure*/
        goto L7; // [175] 178
L7: 
        DeRefi(_msg_inlined_crash_at_161_21817);
        _msg_inlined_crash_at_161_21817 = NOVALUE;
        goto L5; // [181] 285

        /** cmdline.e:1459				case NO_HELP_ON_ERROR then*/
        case 10:

        /** cmdline.e:1461					help_on_error = 0*/
        _help_on_error_21792 = 0;
        goto L5; // [192] 285

        /** cmdline.e:1463				case PAUSE_MSG then*/
        case 8:

        /** cmdline.e:1464					if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_21781)){
                _12319 = SEQ_PTR(_parse_options_21781)->length;
        }
        else {
            _12319 = 1;
        }
        if (_po_21793 >= _12319)
        goto L8; // [203] 224

        /** cmdline.e:1465						po += 1*/
        _po_21793 = _po_21793 + 1;

        /** cmdline.e:1466						pause_msg = parse_options[po]*/
        DeRef(_48pause_msg_20650);
        _2 = (object)SEQ_PTR(_parse_options_21781);
        _48pause_msg_20650 = (object)*(((s1_ptr)_2)->base + _po_21793);
        Ref(_48pause_msg_20650);
        goto L5; // [221] 285
L8: 

        /** cmdline.e:1468						error:crash("PAUSE_MSG was given to cmd_parse with no actual message text")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_225_21828);
        _msg_inlined_crash_at_225_21828 = EPrintf(-9999999, _12323, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_225_21828);

        /** error.e:53	end procedure*/
        goto L9; // [239] 242
L9: 
        DeRefi(_msg_inlined_crash_at_225_21828);
        _msg_inlined_crash_at_225_21828 = NOVALUE;
        goto L5; // [245] 285

        /** cmdline.e:1471				case else*/
        default:
L4: 

        /** cmdline.e:1472					error:crash(sprintf("Unrecognised cmdline PARSE OPTION - %d", parse_options[po]) )*/
        _2 = (object)SEQ_PTR(_parse_options_21781);
        _12325 = (object)*(((s1_ptr)_2)->base + _po_21793);
        _12326 = EPrintf(-9999999, _12324, _12325);
        _12325 = NOVALUE;
        DeRefi(_fmt_inlined_crash_at_260_21834);
        _fmt_inlined_crash_at_260_21834 = _12326;
        _12326 = NOVALUE;

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_263_21835);
        _msg_inlined_crash_at_263_21835 = EPrintf(-9999999, _fmt_inlined_crash_at_260_21834, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_263_21835);

        /** error.e:53	end procedure*/
        goto LA; // [279] 282
LA: 
        DeRefi(_fmt_inlined_crash_at_260_21834);
        _fmt_inlined_crash_at_260_21834 = NOVALUE;
        DeRefi(_msg_inlined_crash_at_263_21835);
        _msg_inlined_crash_at_263_21835 = NOVALUE;
    ;}L5: 

    /** cmdline.e:1475			po += 1*/
    _po_21793 = _po_21793 + 1;

    /** cmdline.e:1476		end while*/
    goto L2; // [293] 60
L3: 

    /** cmdline.e:1478		opts = standardize_opts(opts, auto_help)*/
    RefDS(_opts_21780);
    _0 = _opts_21780;
    _opts_21780 = _48standardize_opts(_opts_21780, _auto_help_21791);
    DeRefDS(_0);

    /** cmdline.e:1479		call_count = repeat(0, length(opts))*/
    if (IS_SEQUENCE(_opts_21780)){
            _12329 = SEQ_PTR(_opts_21780)->length;
    }
    else {
        _12329 = 1;
    }
    DeRef(_call_count_21786);
    _call_count_21786 = Repeat(0, _12329);
    _12329 = NOVALUE;

    /** cmdline.e:1481		map:map parsed_opts = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at315_21843;
    _new_1__tmp_at315_21843 = _34new_map_seq(8);
    DeRef(_0);
    Ref(_new_1__tmp_at315_21843);
    _0 = _parsed_opts_21840;
    _parsed_opts_21840 = _35malloc(_new_1__tmp_at315_21843, 1);
    DeRef(_0);
    DeRef(_new_1__tmp_at315_21843);
    _new_1__tmp_at315_21843 = NOVALUE;

    /** cmdline.e:1482		map:put(parsed_opts, EXTRAS, {})*/
    Ref(_parsed_opts_21840);
    RefDS(_48EXTRAS_20639);
    RefDS(_5);
    _34put(_parsed_opts_21840, _48EXTRAS_20639, _5, 1, 0);

    /** cmdline.e:1485		help_opts = get_help_options( opts )*/
    RefDS(_opts_21780);
    _0 = _help_opts_21785;
    _help_opts_21785 = _48get_help_options(_opts_21780);
    DeRef(_0);

    /** cmdline.e:1487		object cmds_ok = parse_commands( cmds, opts, parsed_opts, help_opts, add_help_rid, parse_options, */
    RefDS(_cmds_21782);
    RefDS(_opts_21780);
    Ref(_parsed_opts_21840);
    RefDS(_help_opts_21785);
    Ref(_add_help_rid_21787);
    Ref(_parse_options_21781);
    RefDS(_call_count_21786);
    _0 = _cmds_ok_21845;
    _cmds_ok_21845 = _48parse_commands(_cmds_21782, _opts_21780, _parsed_opts_21840, _help_opts_21785, _add_help_rid_21787, _parse_options_21781, _use_at_21790, _validation_21788, _has_extra_21789, _call_count_21786, _help_on_error_21792, _auto_help_21791);
    DeRef(_0);

    /** cmdline.e:1489		if atom( cmds_ok ) then*/
    _12333 = IS_ATOM(_cmds_ok_21845);
    if (_12333 == 0)
    {
        _12333 = NOVALUE;
        goto LB; // [371] 381
    }
    else{
        _12333 = NOVALUE;
    }

    /** cmdline.e:1490			return 0*/
    DeRefDS(_opts_21780);
    DeRef(_parse_options_21781);
    DeRefDS(_cmds_21782);
    DeRefDS(_help_opts_21785);
    DeRefDS(_call_count_21786);
    DeRef(_add_help_rid_21787);
    DeRef(_parsed_opts_21840);
    DeRef(_cmds_ok_21845);
    return 0;
LB: 

    /** cmdline.e:1492		cmds       = cmds_ok[1]*/
    DeRefDS(_cmds_21782);
    _2 = (object)SEQ_PTR(_cmds_ok_21845);
    _cmds_21782 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_cmds_21782);

    /** cmdline.e:1493		call_count = cmds_ok[2]*/
    DeRef(_call_count_21786);
    _2 = (object)SEQ_PTR(_cmds_ok_21845);
    _call_count_21786 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_call_count_21786);

    /** cmdline.e:1496		check_mandatory( opts, parsed_opts, add_help_rid, cmds, parse_options, help_on_error, auto_help )*/
    RefDS(_opts_21780);
    Ref(_parsed_opts_21840);
    Ref(_add_help_rid_21787);
    RefDS(_cmds_21782);
    Ref(_parse_options_21781);
    _48check_mandatory(_opts_21780, _parsed_opts_21840, _add_help_rid_21787, _cmds_21782, _parse_options_21781, _help_on_error_21792, _auto_help_21791);

    /** cmdline.e:1498		return parsed_opts*/
    DeRefDS(_opts_21780);
    DeRef(_parse_options_21781);
    DeRefDS(_cmds_21782);
    DeRef(_help_opts_21785);
    DeRefDS(_call_count_21786);
    DeRef(_add_help_rid_21787);
    DeRef(_cmds_ok_21845);
    return _parsed_opts_21840;
    ;
}


object _48build_commandline(object _cmds_21853)
{
    object _12339 = NOVALUE;
    object _12338 = NOVALUE;
    object _12336 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:1551		return stdseq:flatten( text:quote( cmds,,'\\'," " ), " ")*/
    RefDS(_3383);
    RefDS(_3383);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _3383;
    ((intptr_t *)_2)[2] = _3383;
    _12336 = MAKE_SEQ(_1);
    RefDS(_cmds_21853);
    RefDS(_12337);
    _12338 = _18quote(_cmds_21853, _12336, 92, _12337);
    _12336 = NOVALUE;
    RefDS(_12337);
    _12339 = _24flatten(_12338, _12337);
    _12338 = NOVALUE;
    DeRefDS(_cmds_21853);
    return _12339;
    ;
}



// 0x8F3E7355
