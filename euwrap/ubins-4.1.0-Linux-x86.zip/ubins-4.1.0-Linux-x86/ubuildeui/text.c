// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _18sprint(object _x_5782)
{
    object _s_5783 = NOVALUE;
    object _3008 = NOVALUE;
    object _3006 = NOVALUE;
    object _3005 = NOVALUE;
    object _3002 = NOVALUE;
    object _3001 = NOVALUE;
    object _2999 = NOVALUE;
    object _2998 = NOVALUE;
    object _2997 = NOVALUE;
    object _2996 = NOVALUE;
    object _2995 = NOVALUE;
    object _2994 = NOVALUE;
    object _2993 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:93		if atom(x) then*/
    _2993 = IS_ATOM(_x_5782);
    if (_2993 == 0)
    {
        _2993 = NOVALUE;
        goto L1; // [6] 22
    }
    else{
        _2993 = NOVALUE;
    }

    /** text.e:94			return sprintf("%.10g", x)*/
    _2994 = EPrintf(-9999999, _658, _x_5782);
    DeRef(_x_5782);
    DeRef(_s_5783);
    return _2994;
    goto L2; // [19] 137
L1: 

    /** text.e:96			s = "{"*/
    RefDS(_1171);
    DeRef(_s_5783);
    _s_5783 = _1171;

    /** text.e:97			for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_5782)){
            _2995 = SEQ_PTR(_x_5782)->length;
    }
    else {
        _2995 = 1;
    }
    {
        object _i_5789;
        _i_5789 = 1;
L3: 
        if (_i_5789 > _2995){
            goto L4; // [34] 98
        }

        /** text.e:98				if atom(x[i]) then*/
        _2 = (object)SEQ_PTR(_x_5782);
        _2996 = (object)*(((s1_ptr)_2)->base + _i_5789);
        _2997 = IS_ATOM(_2996);
        _2996 = NOVALUE;
        if (_2997 == 0)
        {
            _2997 = NOVALUE;
            goto L5; // [50] 70
        }
        else{
            _2997 = NOVALUE;
        }

        /** text.e:99					s &= sprintf("%.10g", x[i])*/
        _2 = (object)SEQ_PTR(_x_5782);
        _2998 = (object)*(((s1_ptr)_2)->base + _i_5789);
        _2999 = EPrintf(-9999999, _658, _2998);
        _2998 = NOVALUE;
        Concat((object_ptr)&_s_5783, _s_5783, _2999);
        DeRefDS(_2999);
        _2999 = NOVALUE;
        goto L6; // [67] 85
L5: 

        /** text.e:101					s &= sprint(x[i])*/
        _2 = (object)SEQ_PTR(_x_5782);
        _3001 = (object)*(((s1_ptr)_2)->base + _i_5789);
        Ref(_3001);
        _3002 = _18sprint(_3001);
        _3001 = NOVALUE;
        if (IS_SEQUENCE(_s_5783) && IS_ATOM(_3002)) {
            Ref(_3002);
            Append(&_s_5783, _s_5783, _3002);
        }
        else if (IS_ATOM(_s_5783) && IS_SEQUENCE(_3002)) {
        }
        else {
            Concat((object_ptr)&_s_5783, _s_5783, _3002);
        }
        DeRef(_3002);
        _3002 = NOVALUE;
L6: 

        /** text.e:103				s &= ','*/
        Append(&_s_5783, _s_5783, 44);

        /** text.e:104			end for*/
        _i_5789 = _i_5789 + 1;
        goto L3; // [93] 41
L4: 
        ;
    }

    /** text.e:105			if s[$] = ',' then*/
    if (IS_SEQUENCE(_s_5783)){
            _3005 = SEQ_PTR(_s_5783)->length;
    }
    else {
        _3005 = 1;
    }
    _2 = (object)SEQ_PTR(_s_5783);
    _3006 = (object)*(((s1_ptr)_2)->base + _3005);
    if (binary_op_a(NOTEQ, _3006, 44)){
        _3006 = NOVALUE;
        goto L7; // [107] 123
    }
    _3006 = NOVALUE;

    /** text.e:106				s[$] = '}'*/
    if (IS_SEQUENCE(_s_5783)){
            _3008 = SEQ_PTR(_s_5783)->length;
    }
    else {
        _3008 = 1;
    }
    _2 = (object)SEQ_PTR(_s_5783);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _s_5783 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _3008);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 125;
    DeRef(_1);
    goto L8; // [120] 130
L7: 

    /** text.e:108				s &= '}'*/
    Append(&_s_5783, _s_5783, 125);
L8: 

    /** text.e:110			return s*/
    DeRef(_x_5782);
    DeRef(_2994);
    _2994 = NOVALUE;
    return _s_5783;
L2: 
    ;
}


object _18trim(object _source_5853, object _what_5854, object _ret_index_5855)
{
    object _rpos_5856 = NOVALUE;
    object _lpos_5857 = NOVALUE;
    object _3050 = NOVALUE;
    object _3048 = NOVALUE;
    object _3046 = NOVALUE;
    object _3044 = NOVALUE;
    object _3041 = NOVALUE;
    object _3040 = NOVALUE;
    object _3035 = NOVALUE;
    object _3034 = NOVALUE;
    object _3032 = NOVALUE;
    object _3030 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:243		if atom(what) then*/
    _3030 = 0;
    if (_3030 == 0)
    {
        _3030 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _3030 = NOVALUE;
    }

    /** text.e:244			what = {what}*/
    _0 = _what_5854;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_what_5854);
    ((intptr_t*)_2)[1] = _what_5854;
    _what_5854 = MAKE_SEQ(_1);
    DeRefDSi(_0);
L1: 

    /** text.e:247		lpos = 1*/
    _lpos_5857 = 1;

    /** text.e:248		while lpos <= length(source) do*/
L2: 
    if (IS_SEQUENCE(_source_5853)){
            _3032 = SEQ_PTR(_source_5853)->length;
    }
    else {
        _3032 = 1;
    }
    if (_lpos_5857 > _3032)
    goto L3; // [33] 67

    /** text.e:249			if not find(source[lpos], what) then*/
    _2 = (object)SEQ_PTR(_source_5853);
    _3034 = (object)*(((s1_ptr)_2)->base + _lpos_5857);
    _3035 = find_from(_3034, _what_5854, 1);
    _3034 = NOVALUE;
    if (_3035 != 0)
    goto L4; // [48] 56
    _3035 = NOVALUE;

    /** text.e:250				exit*/
    goto L3; // [53] 67
L4: 

    /** text.e:252			lpos += 1*/
    _lpos_5857 = _lpos_5857 + 1;

    /** text.e:253		end while*/
    goto L2; // [64] 30
L3: 

    /** text.e:255		rpos = length(source)*/
    if (IS_SEQUENCE(_source_5853)){
            _rpos_5856 = SEQ_PTR(_source_5853)->length;
    }
    else {
        _rpos_5856 = 1;
    }

    /** text.e:256		while rpos > lpos do*/
L5: 
    if (_rpos_5856 <= _lpos_5857)
    goto L6; // [77] 111

    /** text.e:257			if not find(source[rpos], what) then*/
    _2 = (object)SEQ_PTR(_source_5853);
    _3040 = (object)*(((s1_ptr)_2)->base + _rpos_5856);
    _3041 = find_from(_3040, _what_5854, 1);
    _3040 = NOVALUE;
    if (_3041 != 0)
    goto L7; // [92] 100
    _3041 = NOVALUE;

    /** text.e:258				exit*/
    goto L6; // [97] 111
L7: 

    /** text.e:260			rpos -= 1*/
    _rpos_5856 = _rpos_5856 - 1;

    /** text.e:261		end while*/
    goto L5; // [108] 77
L6: 

    /** text.e:263		if ret_index then*/
    if (_ret_index_5855 == 0)
    {
        goto L8; // [113] 129
    }
    else{
    }

    /** text.e:264			return {lpos, rpos}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _lpos_5857;
    ((intptr_t *)_2)[2] = _rpos_5856;
    _3044 = MAKE_SEQ(_1);
    DeRefDS(_source_5853);
    DeRef(_what_5854);
    return _3044;
    goto L9; // [126] 180
L8: 

    /** text.e:266			if lpos = 1 then*/
    if (_lpos_5857 != 1)
    goto LA; // [131] 152

    /** text.e:267				if rpos = length(source) then*/
    if (IS_SEQUENCE(_source_5853)){
            _3046 = SEQ_PTR(_source_5853)->length;
    }
    else {
        _3046 = 1;
    }
    if (_rpos_5856 != _3046)
    goto LB; // [140] 151

    /** text.e:268					return source*/
    DeRef(_what_5854);
    DeRef(_3044);
    _3044 = NOVALUE;
    return _source_5853;
LB: 
LA: 

    /** text.e:271			if lpos > length(source) then*/
    if (IS_SEQUENCE(_source_5853)){
            _3048 = SEQ_PTR(_source_5853)->length;
    }
    else {
        _3048 = 1;
    }
    if (_lpos_5857 <= _3048)
    goto LC; // [157] 168

    /** text.e:272				return {}*/
    RefDS(_5);
    DeRefDS(_source_5853);
    DeRef(_what_5854);
    DeRef(_3044);
    _3044 = NOVALUE;
    return _5;
LC: 

    /** text.e:274			return source[lpos..rpos]*/
    rhs_slice_target = (object_ptr)&_3050;
    RHS_Slice(_source_5853, _lpos_5857, _rpos_5856);
    DeRefDS(_source_5853);
    DeRef(_what_5854);
    DeRef(_3044);
    _3044 = NOVALUE;
    return _3050;
L9: 
    ;
}


object _18lower(object _x_6053)
{
    object _3167 = NOVALUE;
    object _3166 = NOVALUE;
    object _3165 = NOVALUE;
    object _3164 = NOVALUE;
    object _3163 = NOVALUE;
    object _3160 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:535		if length(lower_case_SET) != 0 then*/
    _3160 = 0;

    /** text.e:539		ifdef WINDOWS then*/

    /** text.e:542			return x + (x >= 'A' and x <= 'Z') * TO_LOWER*/
    if (IS_ATOM_INT(_x_6053)) {
        _3163 = (_x_6053 >= 65);
    }
    else {
        _3163 = binary_op(GREATEREQ, _x_6053, 65);
    }
    if (IS_ATOM_INT(_x_6053)) {
        _3164 = (_x_6053 <= 90);
    }
    else {
        _3164 = binary_op(LESSEQ, _x_6053, 90);
    }
    if (IS_ATOM_INT(_3163) && IS_ATOM_INT(_3164)) {
        _3165 = (_3163 != 0 && _3164 != 0);
    }
    else {
        _3165 = binary_op(AND, _3163, _3164);
    }
    DeRef(_3163);
    _3163 = NOVALUE;
    DeRef(_3164);
    _3164 = NOVALUE;
    if (IS_ATOM_INT(_3165)) {
        if (_3165 == (short)_3165){
            _3166 = _3165 * 32;
        }
        else{
            _3166 = NewDouble(_3165 * (eudouble)32);
        }
    }
    else {
        _3166 = binary_op(MULTIPLY, _3165, 32);
    }
    DeRef(_3165);
    _3165 = NOVALUE;
    if (IS_ATOM_INT(_x_6053) && IS_ATOM_INT(_3166)) {
        _3167 = _x_6053 + _3166;
        if ((object)((uintptr_t)_3167 + (uintptr_t)HIGH_BITS) >= 0){
            _3167 = NewDouble((eudouble)_3167);
        }
    }
    else {
        _3167 = binary_op(PLUS, _x_6053, _3166);
    }
    DeRef(_3166);
    _3166 = NOVALUE;
    DeRef(_x_6053);
    return _3167;
    ;
}


object _18upper(object _x_6065)
{
    object _3175 = NOVALUE;
    object _3174 = NOVALUE;
    object _3173 = NOVALUE;
    object _3172 = NOVALUE;
    object _3171 = NOVALUE;
    object _3168 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:581		if length(upper_case_SET) != 0 then*/
    _3168 = 0;

    /** text.e:584		ifdef WINDOWS then*/

    /** text.e:587			return x - (x >= 'a' and x <= 'z') * TO_LOWER*/
    if (IS_ATOM_INT(_x_6065)) {
        _3171 = (_x_6065 >= 97);
    }
    else {
        _3171 = binary_op(GREATEREQ, _x_6065, 97);
    }
    if (IS_ATOM_INT(_x_6065)) {
        _3172 = (_x_6065 <= 122);
    }
    else {
        _3172 = binary_op(LESSEQ, _x_6065, 122);
    }
    if (IS_ATOM_INT(_3171) && IS_ATOM_INT(_3172)) {
        _3173 = (_3171 != 0 && _3172 != 0);
    }
    else {
        _3173 = binary_op(AND, _3171, _3172);
    }
    DeRef(_3171);
    _3171 = NOVALUE;
    DeRef(_3172);
    _3172 = NOVALUE;
    if (IS_ATOM_INT(_3173)) {
        if (_3173 == (short)_3173){
            _3174 = _3173 * 32;
        }
        else{
            _3174 = NewDouble(_3173 * (eudouble)32);
        }
    }
    else {
        _3174 = binary_op(MULTIPLY, _3173, 32);
    }
    DeRef(_3173);
    _3173 = NOVALUE;
    if (IS_ATOM_INT(_x_6065) && IS_ATOM_INT(_3174)) {
        _3175 = _x_6065 - _3174;
        if ((object)((uintptr_t)_3175 +(uintptr_t) HIGH_BITS) >= 0){
            _3175 = NewDouble((eudouble)_3175);
        }
    }
    else {
        _3175 = binary_op(MINUS, _x_6065, _3174);
    }
    DeRef(_3174);
    _3174 = NOVALUE;
    DeRef(_x_6065);
    return _3175;
    ;
}


object _18proper(object _x_6077)
{
    object _pos_6078 = NOVALUE;
    object _inword_6079 = NOVALUE;
    object _convert_6080 = NOVALUE;
    object _res_6081 = NOVALUE;
    object _3205 = NOVALUE;
    object _3204 = NOVALUE;
    object _3203 = NOVALUE;
    object _3202 = NOVALUE;
    object _3201 = NOVALUE;
    object _3200 = NOVALUE;
    object _3199 = NOVALUE;
    object _3198 = NOVALUE;
    object _3197 = NOVALUE;
    object _3196 = NOVALUE;
    object _3194 = NOVALUE;
    object _3193 = NOVALUE;
    object _3188 = NOVALUE;
    object _3185 = NOVALUE;
    object _3182 = NOVALUE;
    object _3179 = NOVALUE;
    object _3178 = NOVALUE;
    object _3177 = NOVALUE;
    object _3176 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:633		inword = 0	-- Initially not in a word*/
    _inword_6079 = 0;

    /** text.e:634		convert = 1	-- Initially convert text*/
    _convert_6080 = 1;

    /** text.e:635		res = x		-- Work on a copy of the original, in case we need to restore.*/
    RefDS(_x_6077);
    DeRef(_res_6081);
    _res_6081 = _x_6077;

    /** text.e:636		for i = 1 to length(res) do*/
    if (IS_SEQUENCE(_res_6081)){
            _3176 = SEQ_PTR(_res_6081)->length;
    }
    else {
        _3176 = 1;
    }
    {
        object _i_6083;
        _i_6083 = 1;
L1: 
        if (_i_6083 > _3176){
            goto L2; // [25] 298
        }

        /** text.e:637			if integer(res[i]) then*/
        _2 = (object)SEQ_PTR(_res_6081);
        _3177 = (object)*(((s1_ptr)_2)->base + _i_6083);
        if (IS_ATOM_INT(_3177))
        _3178 = 1;
        else if (IS_ATOM_DBL(_3177))
        _3178 = IS_ATOM_INT(DoubleToInt(_3177));
        else
        _3178 = 0;
        _3177 = NOVALUE;
        if (_3178 == 0)
        {
            _3178 = NOVALUE;
            goto L3; // [41] 209
        }
        else{
            _3178 = NOVALUE;
        }

        /** text.e:638				if convert then*/
        if (_convert_6080 == 0)
        {
            goto L4; // [46] 291
        }
        else{
        }

        /** text.e:640					pos = types:t_upper(res[i])*/
        _2 = (object)SEQ_PTR(_res_6081);
        _3179 = (object)*(((s1_ptr)_2)->base + _i_6083);
        Ref(_3179);
        _pos_6078 = _9t_upper(_3179);
        _3179 = NOVALUE;
        if (!IS_ATOM_INT(_pos_6078)) {
            _1 = (object)(DBL_PTR(_pos_6078)->dbl);
            DeRefDS(_pos_6078);
            _pos_6078 = _1;
        }

        /** text.e:641					if pos = 0 then*/
        if (_pos_6078 != 0)
        goto L5; // [63] 175

        /** text.e:643						pos = types:t_lower(res[i])*/
        _2 = (object)SEQ_PTR(_res_6081);
        _3182 = (object)*(((s1_ptr)_2)->base + _i_6083);
        Ref(_3182);
        _pos_6078 = _9t_lower(_3182);
        _3182 = NOVALUE;
        if (!IS_ATOM_INT(_pos_6078)) {
            _1 = (object)(DBL_PTR(_pos_6078)->dbl);
            DeRefDS(_pos_6078);
            _pos_6078 = _1;
        }

        /** text.e:644						if pos = 0 then*/
        if (_pos_6078 != 0)
        goto L6; // [81] 138

        /** text.e:647							pos = t_digit(res[i])*/
        _2 = (object)SEQ_PTR(_res_6081);
        _3185 = (object)*(((s1_ptr)_2)->base + _i_6083);
        Ref(_3185);
        _pos_6078 = _9t_digit(_3185);
        _3185 = NOVALUE;
        if (!IS_ATOM_INT(_pos_6078)) {
            _1 = (object)(DBL_PTR(_pos_6078)->dbl);
            DeRefDS(_pos_6078);
            _pos_6078 = _1;
        }

        /** text.e:648							if pos = 0 then*/
        if (_pos_6078 != 0)
        goto L4; // [99] 291

        /** text.e:650								pos = t_specword(res[i])*/
        _2 = (object)SEQ_PTR(_res_6081);
        _3188 = (object)*(((s1_ptr)_2)->base + _i_6083);
        Ref(_3188);
        _pos_6078 = _9t_specword(_3188);
        _3188 = NOVALUE;
        if (!IS_ATOM_INT(_pos_6078)) {
            _1 = (object)(DBL_PTR(_pos_6078)->dbl);
            DeRefDS(_pos_6078);
            _pos_6078 = _1;
        }

        /** text.e:651								if pos then*/
        if (_pos_6078 == 0)
        {
            goto L7; // [117] 128
        }
        else{
        }

        /** text.e:652									inword = 1*/
        _inword_6079 = 1;
        goto L4; // [125] 291
L7: 

        /** text.e:654									inword = 0*/
        _inword_6079 = 0;
        goto L4; // [135] 291
L6: 

        /** text.e:658							if inword = 0 then*/
        if (_inword_6079 != 0)
        goto L4; // [140] 291

        /** text.e:660								if pos <= 26 then*/
        if (_pos_6078 > 26)
        goto L8; // [146] 165

        /** text.e:661									res[i] = upper(res[i]) -- Convert to uppercase*/
        _2 = (object)SEQ_PTR(_res_6081);
        _3193 = (object)*(((s1_ptr)_2)->base + _i_6083);
        Ref(_3193);
        _3194 = _18upper(_3193);
        _3193 = NOVALUE;
        _2 = (object)SEQ_PTR(_res_6081);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _res_6081 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_6083);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _3194;
        if( _1 != _3194 ){
            DeRef(_1);
        }
        _3194 = NOVALUE;
L8: 

        /** text.e:663								inword = 1	-- now we are in a word*/
        _inword_6079 = 1;
        goto L4; // [172] 291
L5: 

        /** text.e:667						if inword = 1 then*/
        if (_inword_6079 != 1)
        goto L9; // [177] 198

        /** text.e:669							res[i] = lower(res[i]) -- Convert to lowercase*/
        _2 = (object)SEQ_PTR(_res_6081);
        _3196 = (object)*(((s1_ptr)_2)->base + _i_6083);
        Ref(_3196);
        _3197 = _18lower(_3196);
        _3196 = NOVALUE;
        _2 = (object)SEQ_PTR(_res_6081);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _res_6081 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_6083);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _3197;
        if( _1 != _3197 ){
            DeRef(_1);
        }
        _3197 = NOVALUE;
        goto L4; // [195] 291
L9: 

        /** text.e:671							inword = 1	-- now we are in a word*/
        _inword_6079 = 1;
        goto L4; // [206] 291
L3: 

        /** text.e:678				if convert then*/
        if (_convert_6080 == 0)
        {
            goto LA; // [211] 263
        }
        else{
        }

        /** text.e:680					for j = 1 to i-1 do*/
        _3198 = _i_6083 - 1;
        {
            object _j_6124;
            _j_6124 = 1;
LB: 
            if (_j_6124 > _3198){
                goto LC; // [220] 257
            }

            /** text.e:681						if atom(x[j]) then*/
            _2 = (object)SEQ_PTR(_x_6077);
            _3199 = (object)*(((s1_ptr)_2)->base + _j_6124);
            _3200 = IS_ATOM(_3199);
            _3199 = NOVALUE;
            if (_3200 == 0)
            {
                _3200 = NOVALUE;
                goto LD; // [236] 250
            }
            else{
                _3200 = NOVALUE;
            }

            /** text.e:682							res[j] = x[j]*/
            _2 = (object)SEQ_PTR(_x_6077);
            _3201 = (object)*(((s1_ptr)_2)->base + _j_6124);
            Ref(_3201);
            _2 = (object)SEQ_PTR(_res_6081);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _res_6081 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _j_6124);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _3201;
            if( _1 != _3201 ){
                DeRef(_1);
            }
            _3201 = NOVALUE;
LD: 

            /** text.e:684					end for*/
            _j_6124 = _j_6124 + 1;
            goto LB; // [252] 227
LC: 
            ;
        }

        /** text.e:686					convert = 0*/
        _convert_6080 = 0;
LA: 

        /** text.e:689				if sequence(res[i]) then*/
        _2 = (object)SEQ_PTR(_res_6081);
        _3202 = (object)*(((s1_ptr)_2)->base + _i_6083);
        _3203 = IS_SEQUENCE(_3202);
        _3202 = NOVALUE;
        if (_3203 == 0)
        {
            _3203 = NOVALUE;
            goto LE; // [272] 290
        }
        else{
            _3203 = NOVALUE;
        }

        /** text.e:690					res[i] = proper(res[i])	-- recursive conversion*/
        _2 = (object)SEQ_PTR(_res_6081);
        _3204 = (object)*(((s1_ptr)_2)->base + _i_6083);
        Ref(_3204);
        _3205 = _18proper(_3204);
        _3204 = NOVALUE;
        _2 = (object)SEQ_PTR(_res_6081);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _res_6081 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_6083);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _3205;
        if( _1 != _3205 ){
            DeRef(_1);
        }
        _3205 = NOVALUE;
LE: 
L4: 

        /** text.e:693		end for*/
        _i_6083 = _i_6083 + 1;
        goto L1; // [293] 32
L2: 
        ;
    }

    /** text.e:694		return res*/
    DeRefDS(_x_6077);
    DeRef(_3198);
    _3198 = NOVALUE;
    return _res_6081;
    ;
}


object _18quote(object _text_in_6400, object _quote_pair_6401, object _esc_6403, object _sp_6405)
{
    object _3476 = NOVALUE;
    object _3475 = NOVALUE;
    object _3474 = NOVALUE;
    object _3472 = NOVALUE;
    object _3471 = NOVALUE;
    object _3470 = NOVALUE;
    object _3468 = NOVALUE;
    object _3467 = NOVALUE;
    object _3466 = NOVALUE;
    object _3465 = NOVALUE;
    object _3464 = NOVALUE;
    object _3463 = NOVALUE;
    object _3462 = NOVALUE;
    object _3461 = NOVALUE;
    object _3460 = NOVALUE;
    object _3458 = NOVALUE;
    object _3457 = NOVALUE;
    object _3456 = NOVALUE;
    object _3454 = NOVALUE;
    object _3453 = NOVALUE;
    object _3452 = NOVALUE;
    object _3451 = NOVALUE;
    object _3450 = NOVALUE;
    object _3449 = NOVALUE;
    object _3448 = NOVALUE;
    object _3447 = NOVALUE;
    object _3446 = NOVALUE;
    object _3444 = NOVALUE;
    object _3443 = NOVALUE;
    object _3441 = NOVALUE;
    object _3440 = NOVALUE;
    object _3439 = NOVALUE;
    object _3437 = NOVALUE;
    object _3436 = NOVALUE;
    object _3435 = NOVALUE;
    object _3434 = NOVALUE;
    object _3433 = NOVALUE;
    object _3432 = NOVALUE;
    object _3431 = NOVALUE;
    object _3430 = NOVALUE;
    object _3429 = NOVALUE;
    object _3428 = NOVALUE;
    object _3427 = NOVALUE;
    object _3426 = NOVALUE;
    object _3425 = NOVALUE;
    object _3424 = NOVALUE;
    object _3423 = NOVALUE;
    object _3422 = NOVALUE;
    object _3421 = NOVALUE;
    object _3418 = NOVALUE;
    object _3417 = NOVALUE;
    object _3416 = NOVALUE;
    object _3415 = NOVALUE;
    object _3414 = NOVALUE;
    object _3413 = NOVALUE;
    object _3412 = NOVALUE;
    object _3411 = NOVALUE;
    object _3410 = NOVALUE;
    object _3409 = NOVALUE;
    object _3408 = NOVALUE;
    object _3407 = NOVALUE;
    object _3406 = NOVALUE;
    object _3405 = NOVALUE;
    object _3402 = NOVALUE;
    object _3400 = NOVALUE;
    object _3399 = NOVALUE;
    object _3397 = NOVALUE;
    object _3395 = NOVALUE;
    object _3394 = NOVALUE;
    object _3393 = NOVALUE;
    object _3391 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:1118		if length(text_in) = 0 then*/
    if (IS_SEQUENCE(_text_in_6400)){
            _3391 = SEQ_PTR(_text_in_6400)->length;
    }
    else {
        _3391 = 1;
    }
    if (_3391 != 0)
    goto L1; // [10] 21

    /** text.e:1119			return text_in*/
    DeRef(_quote_pair_6401);
    DeRef(_sp_6405);
    return _text_in_6400;
L1: 

    /** text.e:1122		if atom(quote_pair) then*/
    _3393 = IS_ATOM(_quote_pair_6401);
    if (_3393 == 0)
    {
        _3393 = NOVALUE;
        goto L2; // [26] 46
    }
    else{
        _3393 = NOVALUE;
    }

    /** text.e:1123			quote_pair = {{quote_pair}, {quote_pair}}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_quote_pair_6401);
    ((intptr_t*)_2)[1] = _quote_pair_6401;
    _3394 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_quote_pair_6401);
    ((intptr_t*)_2)[1] = _quote_pair_6401;
    _3395 = MAKE_SEQ(_1);
    DeRef(_quote_pair_6401);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _3394;
    ((intptr_t *)_2)[2] = _3395;
    _quote_pair_6401 = MAKE_SEQ(_1);
    _3395 = NOVALUE;
    _3394 = NOVALUE;
    goto L3; // [43] 89
L2: 

    /** text.e:1124		elsif length(quote_pair) = 1 then*/
    if (IS_SEQUENCE(_quote_pair_6401)){
            _3397 = SEQ_PTR(_quote_pair_6401)->length;
    }
    else {
        _3397 = 1;
    }
    if (_3397 != 1)
    goto L4; // [51] 72

    /** text.e:1125			quote_pair = {quote_pair[1], quote_pair[1]}*/
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3399 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3400 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_3400);
    Ref(_3399);
    DeRef(_quote_pair_6401);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _3399;
    ((intptr_t *)_2)[2] = _3400;
    _quote_pair_6401 = MAKE_SEQ(_1);
    _3400 = NOVALUE;
    _3399 = NOVALUE;
    goto L3; // [69] 89
L4: 

    /** text.e:1126		elsif length(quote_pair) = 0 then*/
    if (IS_SEQUENCE(_quote_pair_6401)){
            _3402 = SEQ_PTR(_quote_pair_6401)->length;
    }
    else {
        _3402 = 1;
    }
    if (_3402 != 0)
    goto L5; // [77] 88

    /** text.e:1127			quote_pair = {"\"", "\""}*/
    RefDS(_3383);
    RefDS(_3383);
    DeRef(_quote_pair_6401);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _3383;
    ((intptr_t *)_2)[2] = _3383;
    _quote_pair_6401 = MAKE_SEQ(_1);
L5: 
L3: 

    /** text.e:1130		if sequence(text_in[1]) then*/
    _2 = (object)SEQ_PTR(_text_in_6400);
    _3405 = (object)*(((s1_ptr)_2)->base + 1);
    _3406 = IS_SEQUENCE(_3405);
    _3405 = NOVALUE;
    if (_3406 == 0)
    {
        _3406 = NOVALUE;
        goto L6; // [98] 166
    }
    else{
        _3406 = NOVALUE;
    }

    /** text.e:1131			for i = 1 to length(text_in) do*/
    if (IS_SEQUENCE(_text_in_6400)){
            _3407 = SEQ_PTR(_text_in_6400)->length;
    }
    else {
        _3407 = 1;
    }
    {
        object _i_6428;
        _i_6428 = 1;
L7: 
        if (_i_6428 > _3407){
            goto L8; // [106] 159
        }

        /** text.e:1132				if sequence(text_in[i]) then*/
        _2 = (object)SEQ_PTR(_text_in_6400);
        _3408 = (object)*(((s1_ptr)_2)->base + _i_6428);
        _3409 = IS_SEQUENCE(_3408);
        _3408 = NOVALUE;
        if (_3409 == 0)
        {
            _3409 = NOVALUE;
            goto L9; // [122] 152
        }
        else{
            _3409 = NOVALUE;
        }

        /** text.e:1133					text_in[i] = quote(text_in[i], quote_pair, esc, sp)*/
        _2 = (object)SEQ_PTR(_text_in_6400);
        _3410 = (object)*(((s1_ptr)_2)->base + _i_6428);
        Ref(_quote_pair_6401);
        DeRef(_3411);
        _3411 = _quote_pair_6401;
        DeRef(_3412);
        _3412 = _esc_6403;
        Ref(_sp_6405);
        DeRef(_3413);
        _3413 = _sp_6405;
        Ref(_3410);
        _3414 = _18quote(_3410, _3411, _3412, _3413);
        _3410 = NOVALUE;
        _3411 = NOVALUE;
        _3412 = NOVALUE;
        _3413 = NOVALUE;
        _2 = (object)SEQ_PTR(_text_in_6400);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _text_in_6400 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_6428);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _3414;
        if( _1 != _3414 ){
            DeRef(_1);
        }
        _3414 = NOVALUE;
L9: 

        /** text.e:1135			end for*/
        _i_6428 = _i_6428 + 1;
        goto L7; // [154] 113
L8: 
        ;
    }

    /** text.e:1137			return text_in*/
    DeRef(_quote_pair_6401);
    DeRef(_sp_6405);
    return _text_in_6400;
L6: 

    /** text.e:1141		for i = 1 to length(sp) do*/
    if (IS_SEQUENCE(_sp_6405)){
            _3415 = SEQ_PTR(_sp_6405)->length;
    }
    else {
        _3415 = 1;
    }
    {
        object _i_6439;
        _i_6439 = 1;
LA: 
        if (_i_6439 > _3415){
            goto LB; // [171] 220
        }

        /** text.e:1142			if find(sp[i], text_in) then*/
        _2 = (object)SEQ_PTR(_sp_6405);
        _3416 = (object)*(((s1_ptr)_2)->base + _i_6439);
        _3417 = find_from(_3416, _text_in_6400, 1);
        _3416 = NOVALUE;
        if (_3417 == 0)
        {
            _3417 = NOVALUE;
            goto LC; // [189] 197
        }
        else{
            _3417 = NOVALUE;
        }

        /** text.e:1143				exit*/
        goto LB; // [194] 220
LC: 

        /** text.e:1146			if i = length(sp) then*/
        if (IS_SEQUENCE(_sp_6405)){
                _3418 = SEQ_PTR(_sp_6405)->length;
        }
        else {
            _3418 = 1;
        }
        if (_i_6439 != _3418)
        goto LD; // [202] 213

        /** text.e:1148				return text_in*/
        DeRef(_quote_pair_6401);
        DeRef(_sp_6405);
        return _text_in_6400;
LD: 

        /** text.e:1150		end for*/
        _i_6439 = _i_6439 + 1;
        goto LA; // [215] 178
LB: 
        ;
    }

    /** text.e:1152		if esc >= 0  then*/
    if (_esc_6403 < 0)
    goto LE; // [222] 561

    /** text.e:1156			if atom(quote_pair[1]) then*/
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3421 = (object)*(((s1_ptr)_2)->base + 1);
    _3422 = IS_ATOM(_3421);
    _3421 = NOVALUE;
    if (_3422 == 0)
    {
        _3422 = NOVALUE;
        goto LF; // [235] 253
    }
    else{
        _3422 = NOVALUE;
    }

    /** text.e:1157				quote_pair[1] = {quote_pair[1]}*/
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3423 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_3423);
    ((intptr_t*)_2)[1] = _3423;
    _3424 = MAKE_SEQ(_1);
    _3423 = NOVALUE;
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _quote_pair_6401 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _3424;
    if( _1 != _3424 ){
        DeRef(_1);
    }
    _3424 = NOVALUE;
LF: 

    /** text.e:1159			if atom(quote_pair[2]) then*/
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3425 = (object)*(((s1_ptr)_2)->base + 2);
    _3426 = IS_ATOM(_3425);
    _3425 = NOVALUE;
    if (_3426 == 0)
    {
        _3426 = NOVALUE;
        goto L10; // [262] 280
    }
    else{
        _3426 = NOVALUE;
    }

    /** text.e:1160				quote_pair[2] = {quote_pair[2]}*/
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3427 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_3427);
    ((intptr_t*)_2)[1] = _3427;
    _3428 = MAKE_SEQ(_1);
    _3427 = NOVALUE;
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _quote_pair_6401 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _3428;
    if( _1 != _3428 ){
        DeRef(_1);
    }
    _3428 = NOVALUE;
L10: 

    /** text.e:1163			if equal(quote_pair[1], quote_pair[2]) then*/
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3429 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3430 = (object)*(((s1_ptr)_2)->base + 2);
    if (_3429 == _3430)
    _3431 = 1;
    else if (IS_ATOM_INT(_3429) && IS_ATOM_INT(_3430))
    _3431 = 0;
    else
    _3431 = (compare(_3429, _3430) == 0);
    _3429 = NOVALUE;
    _3430 = NOVALUE;
    if (_3431 == 0)
    {
        _3431 = NOVALUE;
        goto L11; // [294] 372
    }
    else{
        _3431 = NOVALUE;
    }

    /** text.e:1165				if match(quote_pair[1], text_in) then*/
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3432 = (object)*(((s1_ptr)_2)->base + 1);
    _3433 = e_match_from(_3432, _text_in_6400, 1);
    _3432 = NOVALUE;
    if (_3433 == 0)
    {
        _3433 = NOVALUE;
        goto L12; // [308] 560
    }
    else{
        _3433 = NOVALUE;
    }

    /** text.e:1166					if match(esc & quote_pair[1], text_in) then*/
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3434 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_6403) && IS_ATOM(_3434)) {
    }
    else if (IS_ATOM(_esc_6403) && IS_SEQUENCE(_3434)) {
        Prepend(&_3435, _3434, _esc_6403);
    }
    else {
        Concat((object_ptr)&_3435, _esc_6403, _3434);
    }
    _3434 = NOVALUE;
    _3436 = e_match_from(_3435, _text_in_6400, 1);
    DeRefDS(_3435);
    _3435 = NOVALUE;
    if (_3436 == 0)
    {
        _3436 = NOVALUE;
        goto L13; // [326] 345
    }
    else{
        _3436 = NOVALUE;
    }

    /** text.e:1167						text_in = search:match_replace(esc, text_in, esc & esc)*/
    Concat((object_ptr)&_3437, _esc_6403, _esc_6403);
    RefDS(_text_in_6400);
    _0 = _text_in_6400;
    _text_in_6400 = _20match_replace(_esc_6403, _text_in_6400, _3437, 0);
    DeRefDS(_0);
    _3437 = NOVALUE;
L13: 

    /** text.e:1169					text_in = search:match_replace(quote_pair[1], text_in, esc & quote_pair[1])*/
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3439 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3440 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_6403) && IS_ATOM(_3440)) {
    }
    else if (IS_ATOM(_esc_6403) && IS_SEQUENCE(_3440)) {
        Prepend(&_3441, _3440, _esc_6403);
    }
    else {
        Concat((object_ptr)&_3441, _esc_6403, _3440);
    }
    _3440 = NOVALUE;
    Ref(_3439);
    RefDS(_text_in_6400);
    _0 = _text_in_6400;
    _text_in_6400 = _20match_replace(_3439, _text_in_6400, _3441, 0);
    DeRefDS(_0);
    _3439 = NOVALUE;
    _3441 = NOVALUE;
    goto L12; // [369] 560
L11: 

    /** text.e:1172				if match(quote_pair[1], text_in) or*/
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3443 = (object)*(((s1_ptr)_2)->base + 1);
    _3444 = e_match_from(_3443, _text_in_6400, 1);
    _3443 = NOVALUE;
    if (_3444 != 0) {
        goto L14; // [383] 401
    }
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3446 = (object)*(((s1_ptr)_2)->base + 2);
    _3447 = e_match_from(_3446, _text_in_6400, 1);
    _3446 = NOVALUE;
    if (_3447 == 0)
    {
        _3447 = NOVALUE;
        goto L15; // [397] 473
    }
    else{
        _3447 = NOVALUE;
    }
L14: 

    /** text.e:1174					if match(esc & quote_pair[1], text_in) then*/
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3448 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_6403) && IS_ATOM(_3448)) {
    }
    else if (IS_ATOM(_esc_6403) && IS_SEQUENCE(_3448)) {
        Prepend(&_3449, _3448, _esc_6403);
    }
    else {
        Concat((object_ptr)&_3449, _esc_6403, _3448);
    }
    _3448 = NOVALUE;
    _3450 = e_match_from(_3449, _text_in_6400, 1);
    DeRefDS(_3449);
    _3449 = NOVALUE;
    if (_3450 == 0)
    {
        _3450 = NOVALUE;
        goto L16; // [416] 449
    }
    else{
        _3450 = NOVALUE;
    }

    /** text.e:1175						text_in = search:match_replace(esc & quote_pair[1], text_in, esc & esc & quote_pair[1])*/
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3451 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_6403) && IS_ATOM(_3451)) {
    }
    else if (IS_ATOM(_esc_6403) && IS_SEQUENCE(_3451)) {
        Prepend(&_3452, _3451, _esc_6403);
    }
    else {
        Concat((object_ptr)&_3452, _esc_6403, _3451);
    }
    _3451 = NOVALUE;
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3453 = (object)*(((s1_ptr)_2)->base + 1);
    {
        object concat_list[3];

        concat_list[0] = _3453;
        concat_list[1] = _esc_6403;
        concat_list[2] = _esc_6403;
        Concat_N((object_ptr)&_3454, concat_list, 3);
    }
    _3453 = NOVALUE;
    RefDS(_text_in_6400);
    _0 = _text_in_6400;
    _text_in_6400 = _20match_replace(_3452, _text_in_6400, _3454, 0);
    DeRefDS(_0);
    _3452 = NOVALUE;
    _3454 = NOVALUE;
L16: 

    /** text.e:1177					text_in = match_replace(quote_pair[1], text_in, esc & quote_pair[1])*/
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3456 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3457 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_6403) && IS_ATOM(_3457)) {
    }
    else if (IS_ATOM(_esc_6403) && IS_SEQUENCE(_3457)) {
        Prepend(&_3458, _3457, _esc_6403);
    }
    else {
        Concat((object_ptr)&_3458, _esc_6403, _3457);
    }
    _3457 = NOVALUE;
    Ref(_3456);
    RefDS(_text_in_6400);
    _0 = _text_in_6400;
    _text_in_6400 = _20match_replace(_3456, _text_in_6400, _3458, 0);
    DeRefDS(_0);
    _3456 = NOVALUE;
    _3458 = NOVALUE;
L15: 

    /** text.e:1180				if match(quote_pair[2], text_in) then*/
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3460 = (object)*(((s1_ptr)_2)->base + 2);
    _3461 = e_match_from(_3460, _text_in_6400, 1);
    _3460 = NOVALUE;
    if (_3461 == 0)
    {
        _3461 = NOVALUE;
        goto L17; // [484] 559
    }
    else{
        _3461 = NOVALUE;
    }

    /** text.e:1181					if match(esc & quote_pair[2], text_in) then*/
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3462 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_6403) && IS_ATOM(_3462)) {
    }
    else if (IS_ATOM(_esc_6403) && IS_SEQUENCE(_3462)) {
        Prepend(&_3463, _3462, _esc_6403);
    }
    else {
        Concat((object_ptr)&_3463, _esc_6403, _3462);
    }
    _3462 = NOVALUE;
    _3464 = e_match_from(_3463, _text_in_6400, 1);
    DeRefDS(_3463);
    _3463 = NOVALUE;
    if (_3464 == 0)
    {
        _3464 = NOVALUE;
        goto L18; // [502] 535
    }
    else{
        _3464 = NOVALUE;
    }

    /** text.e:1182						text_in = search:match_replace(esc & quote_pair[2], text_in, esc & esc & quote_pair[2])*/
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3465 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_6403) && IS_ATOM(_3465)) {
    }
    else if (IS_ATOM(_esc_6403) && IS_SEQUENCE(_3465)) {
        Prepend(&_3466, _3465, _esc_6403);
    }
    else {
        Concat((object_ptr)&_3466, _esc_6403, _3465);
    }
    _3465 = NOVALUE;
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3467 = (object)*(((s1_ptr)_2)->base + 2);
    {
        object concat_list[3];

        concat_list[0] = _3467;
        concat_list[1] = _esc_6403;
        concat_list[2] = _esc_6403;
        Concat_N((object_ptr)&_3468, concat_list, 3);
    }
    _3467 = NOVALUE;
    RefDS(_text_in_6400);
    _0 = _text_in_6400;
    _text_in_6400 = _20match_replace(_3466, _text_in_6400, _3468, 0);
    DeRefDS(_0);
    _3466 = NOVALUE;
    _3468 = NOVALUE;
L18: 

    /** text.e:1184					text_in = search:match_replace(quote_pair[2], text_in, esc & quote_pair[2])*/
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3470 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3471 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_6403) && IS_ATOM(_3471)) {
    }
    else if (IS_ATOM(_esc_6403) && IS_SEQUENCE(_3471)) {
        Prepend(&_3472, _3471, _esc_6403);
    }
    else {
        Concat((object_ptr)&_3472, _esc_6403, _3471);
    }
    _3471 = NOVALUE;
    Ref(_3470);
    RefDS(_text_in_6400);
    _0 = _text_in_6400;
    _text_in_6400 = _20match_replace(_3470, _text_in_6400, _3472, 0);
    DeRefDS(_0);
    _3470 = NOVALUE;
    _3472 = NOVALUE;
L17: 
L12: 
LE: 

    /** text.e:1189		return quote_pair[1] & text_in & quote_pair[2]*/
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3474 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_quote_pair_6401);
    _3475 = (object)*(((s1_ptr)_2)->base + 2);
    {
        object concat_list[3];

        concat_list[0] = _3475;
        concat_list[1] = _text_in_6400;
        concat_list[2] = _3474;
        Concat_N((object_ptr)&_3476, concat_list, 3);
    }
    _3475 = NOVALUE;
    _3474 = NOVALUE;
    DeRefDS(_text_in_6400);
    DeRef(_quote_pair_6401);
    DeRef(_sp_6405);
    return _3476;
    ;
}


object _18format(object _format_pattern_6621, object _arg_list_6622)
{
    object _result_6623 = NOVALUE;
    object _in_token_6624 = NOVALUE;
    object _tch_6625 = NOVALUE;
    object _i_6626 = NOVALUE;
    object _tend_6627 = NOVALUE;
    object _cap_6628 = NOVALUE;
    object _align_6629 = NOVALUE;
    object _psign_6630 = NOVALUE;
    object _msign_6631 = NOVALUE;
    object _zfill_6632 = NOVALUE;
    object _bwz_6633 = NOVALUE;
    object _spacer_6634 = NOVALUE;
    object _alt_6635 = NOVALUE;
    object _width_6636 = NOVALUE;
    object _decs_6637 = NOVALUE;
    object _pos_6638 = NOVALUE;
    object _argn_6639 = NOVALUE;
    object _argl_6640 = NOVALUE;
    object _trimming_6641 = NOVALUE;
    object _hexout_6642 = NOVALUE;
    object _binout_6643 = NOVALUE;
    object _tsep_6644 = NOVALUE;
    object _istext_6645 = NOVALUE;
    object _prevargv_6646 = NOVALUE;
    object _currargv_6647 = NOVALUE;
    object _idname_6648 = NOVALUE;
    object _envsym_6649 = NOVALUE;
    object _envvar_6650 = NOVALUE;
    object _ep_6651 = NOVALUE;
    object _pflag_6652 = NOVALUE;
    object _count_6653 = NOVALUE;
    object _sp_6733 = NOVALUE;
    object _sp_6769 = NOVALUE;
    object _argtext_6816 = NOVALUE;
    object _tempv_7061 = NOVALUE;
    object _pretty_sprint_inlined_pretty_sprint_at_2521_7116 = NOVALUE;
    object _options_inlined_pretty_sprint_at_2518_7115 = NOVALUE;
    object _pretty_sprint_inlined_pretty_sprint_at_2577_7123 = NOVALUE;
    object _options_inlined_pretty_sprint_at_2574_7122 = NOVALUE;
    object _x_inlined_pretty_sprint_at_2571_7121 = NOVALUE;
    object _msg_inlined_crash_at_2725_7145 = NOVALUE;
    object _dpos_7207 = NOVALUE;
    object _dist_7208 = NOVALUE;
    object _bracketed_7209 = NOVALUE;
    object _4017 = NOVALUE;
    object _4016 = NOVALUE;
    object _4015 = NOVALUE;
    object _4013 = NOVALUE;
    object _4012 = NOVALUE;
    object _4011 = NOVALUE;
    object _4008 = NOVALUE;
    object _4007 = NOVALUE;
    object _4004 = NOVALUE;
    object _4002 = NOVALUE;
    object _3999 = NOVALUE;
    object _3998 = NOVALUE;
    object _3997 = NOVALUE;
    object _3994 = NOVALUE;
    object _3991 = NOVALUE;
    object _3990 = NOVALUE;
    object _3989 = NOVALUE;
    object _3988 = NOVALUE;
    object _3985 = NOVALUE;
    object _3984 = NOVALUE;
    object _3983 = NOVALUE;
    object _3980 = NOVALUE;
    object _3978 = NOVALUE;
    object _3975 = NOVALUE;
    object _3974 = NOVALUE;
    object _3973 = NOVALUE;
    object _3972 = NOVALUE;
    object _3969 = NOVALUE;
    object _3964 = NOVALUE;
    object _3963 = NOVALUE;
    object _3962 = NOVALUE;
    object _3961 = NOVALUE;
    object _3959 = NOVALUE;
    object _3958 = NOVALUE;
    object _3957 = NOVALUE;
    object _3956 = NOVALUE;
    object _3955 = NOVALUE;
    object _3954 = NOVALUE;
    object _3953 = NOVALUE;
    object _3948 = NOVALUE;
    object _3944 = NOVALUE;
    object _3943 = NOVALUE;
    object _3941 = NOVALUE;
    object _3939 = NOVALUE;
    object _3938 = NOVALUE;
    object _3937 = NOVALUE;
    object _3936 = NOVALUE;
    object _3935 = NOVALUE;
    object _3932 = NOVALUE;
    object _3930 = NOVALUE;
    object _3929 = NOVALUE;
    object _3928 = NOVALUE;
    object _3927 = NOVALUE;
    object _3924 = NOVALUE;
    object _3923 = NOVALUE;
    object _3921 = NOVALUE;
    object _3920 = NOVALUE;
    object _3919 = NOVALUE;
    object _3918 = NOVALUE;
    object _3917 = NOVALUE;
    object _3914 = NOVALUE;
    object _3913 = NOVALUE;
    object _3912 = NOVALUE;
    object _3909 = NOVALUE;
    object _3908 = NOVALUE;
    object _3906 = NOVALUE;
    object _3902 = NOVALUE;
    object _3901 = NOVALUE;
    object _3899 = NOVALUE;
    object _3898 = NOVALUE;
    object _3890 = NOVALUE;
    object _3886 = NOVALUE;
    object _3884 = NOVALUE;
    object _3883 = NOVALUE;
    object _3882 = NOVALUE;
    object _3879 = NOVALUE;
    object _3877 = NOVALUE;
    object _3876 = NOVALUE;
    object _3875 = NOVALUE;
    object _3873 = NOVALUE;
    object _3872 = NOVALUE;
    object _3871 = NOVALUE;
    object _3870 = NOVALUE;
    object _3867 = NOVALUE;
    object _3866 = NOVALUE;
    object _3865 = NOVALUE;
    object _3863 = NOVALUE;
    object _3862 = NOVALUE;
    object _3861 = NOVALUE;
    object _3860 = NOVALUE;
    object _3858 = NOVALUE;
    object _3856 = NOVALUE;
    object _3854 = NOVALUE;
    object _3852 = NOVALUE;
    object _3850 = NOVALUE;
    object _3848 = NOVALUE;
    object _3847 = NOVALUE;
    object _3846 = NOVALUE;
    object _3845 = NOVALUE;
    object _3844 = NOVALUE;
    object _3843 = NOVALUE;
    object _3841 = NOVALUE;
    object _3840 = NOVALUE;
    object _3838 = NOVALUE;
    object _3837 = NOVALUE;
    object _3835 = NOVALUE;
    object _3833 = NOVALUE;
    object _3832 = NOVALUE;
    object _3829 = NOVALUE;
    object _3827 = NOVALUE;
    object _3823 = NOVALUE;
    object _3821 = NOVALUE;
    object _3820 = NOVALUE;
    object _3819 = NOVALUE;
    object _3817 = NOVALUE;
    object _3816 = NOVALUE;
    object _3815 = NOVALUE;
    object _3814 = NOVALUE;
    object _3813 = NOVALUE;
    object _3811 = NOVALUE;
    object _3809 = NOVALUE;
    object _3808 = NOVALUE;
    object _3807 = NOVALUE;
    object _3806 = NOVALUE;
    object _3802 = NOVALUE;
    object _3799 = NOVALUE;
    object _3798 = NOVALUE;
    object _3795 = NOVALUE;
    object _3794 = NOVALUE;
    object _3793 = NOVALUE;
    object _3791 = NOVALUE;
    object _3790 = NOVALUE;
    object _3789 = NOVALUE;
    object _3788 = NOVALUE;
    object _3786 = NOVALUE;
    object _3784 = NOVALUE;
    object _3783 = NOVALUE;
    object _3782 = NOVALUE;
    object _3781 = NOVALUE;
    object _3780 = NOVALUE;
    object _3779 = NOVALUE;
    object _3777 = NOVALUE;
    object _3776 = NOVALUE;
    object _3775 = NOVALUE;
    object _3773 = NOVALUE;
    object _3772 = NOVALUE;
    object _3771 = NOVALUE;
    object _3770 = NOVALUE;
    object _3768 = NOVALUE;
    object _3765 = NOVALUE;
    object _3764 = NOVALUE;
    object _3762 = NOVALUE;
    object _3761 = NOVALUE;
    object _3759 = NOVALUE;
    object _3756 = NOVALUE;
    object _3755 = NOVALUE;
    object _3752 = NOVALUE;
    object _3750 = NOVALUE;
    object _3746 = NOVALUE;
    object _3744 = NOVALUE;
    object _3743 = NOVALUE;
    object _3742 = NOVALUE;
    object _3740 = NOVALUE;
    object _3738 = NOVALUE;
    object _3737 = NOVALUE;
    object _3736 = NOVALUE;
    object _3735 = NOVALUE;
    object _3734 = NOVALUE;
    object _3732 = NOVALUE;
    object _3730 = NOVALUE;
    object _3729 = NOVALUE;
    object _3728 = NOVALUE;
    object _3727 = NOVALUE;
    object _3725 = NOVALUE;
    object _3722 = NOVALUE;
    object _3720 = NOVALUE;
    object _3719 = NOVALUE;
    object _3718 = NOVALUE;
    object _3717 = NOVALUE;
    object _3716 = NOVALUE;
    object _3714 = NOVALUE;
    object _3713 = NOVALUE;
    object _3712 = NOVALUE;
    object _3710 = NOVALUE;
    object _3709 = NOVALUE;
    object _3708 = NOVALUE;
    object _3707 = NOVALUE;
    object _3705 = NOVALUE;
    object _3704 = NOVALUE;
    object _3703 = NOVALUE;
    object _3700 = NOVALUE;
    object _3699 = NOVALUE;
    object _3698 = NOVALUE;
    object _3697 = NOVALUE;
    object _3695 = NOVALUE;
    object _3694 = NOVALUE;
    object _3693 = NOVALUE;
    object _3692 = NOVALUE;
    object _3689 = NOVALUE;
    object _3688 = NOVALUE;
    object _3687 = NOVALUE;
    object _3685 = NOVALUE;
    object _3684 = NOVALUE;
    object _3683 = NOVALUE;
    object _3682 = NOVALUE;
    object _3679 = NOVALUE;
    object _3678 = NOVALUE;
    object _3677 = NOVALUE;
    object _3676 = NOVALUE;
    object _3674 = NOVALUE;
    object _3673 = NOVALUE;
    object _3672 = NOVALUE;
    object _3670 = NOVALUE;
    object _3669 = NOVALUE;
    object _3668 = NOVALUE;
    object _3666 = NOVALUE;
    object _3659 = NOVALUE;
    object _3657 = NOVALUE;
    object _3656 = NOVALUE;
    object _3649 = NOVALUE;
    object _3646 = NOVALUE;
    object _3642 = NOVALUE;
    object _3640 = NOVALUE;
    object _3639 = NOVALUE;
    object _3636 = NOVALUE;
    object _3634 = NOVALUE;
    object _3632 = NOVALUE;
    object _3629 = NOVALUE;
    object _3627 = NOVALUE;
    object _3626 = NOVALUE;
    object _3625 = NOVALUE;
    object _3624 = NOVALUE;
    object _3623 = NOVALUE;
    object _3620 = NOVALUE;
    object _3617 = NOVALUE;
    object _3616 = NOVALUE;
    object _3615 = NOVALUE;
    object _3612 = NOVALUE;
    object _3610 = NOVALUE;
    object _3608 = NOVALUE;
    object _3605 = NOVALUE;
    object _3604 = NOVALUE;
    object _3597 = NOVALUE;
    object _3594 = NOVALUE;
    object _3593 = NOVALUE;
    object _3585 = NOVALUE;
    object _3574 = NOVALUE;
    object _3571 = NOVALUE;
    object _3560 = NOVALUE;
    object _3558 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:1445		if atom(arg_list) then*/
    _3558 = IS_ATOM(_arg_list_6622);
    if (_3558 == 0)
    {
        _3558 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _3558 = NOVALUE;
    }

    /** text.e:1446			arg_list = {arg_list}*/
    _0 = _arg_list_6622;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_arg_list_6622);
    ((intptr_t*)_2)[1] = _arg_list_6622;
    _arg_list_6622 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** text.e:1449		result = ""*/
    RefDS(_5);
    DeRef(_result_6623);
    _result_6623 = _5;

    /** text.e:1450		in_token = 0*/
    _in_token_6624 = 0;

    /** text.e:1453		i = 0*/
    _i_6626 = 0;

    /** text.e:1454		tend = 0*/
    _tend_6627 = 0;

    /** text.e:1455		argl = 0*/
    _argl_6640 = 0;

    /** text.e:1456		spacer = 0*/
    _spacer_6634 = 0;

    /** text.e:1457		prevargv = 0*/
    DeRef(_prevargv_6646);
    _prevargv_6646 = 0;

    /** text.e:1458	    while i < length(format_pattern) do*/
L2: 
    if (IS_SEQUENCE(_format_pattern_6621)){
            _3560 = SEQ_PTR(_format_pattern_6621)->length;
    }
    else {
        _3560 = 1;
    }
    if (_i_6626 >= _3560)
    goto L3; // [63] 3614

    /** text.e:1459	    	i += 1*/
    _i_6626 = _i_6626 + 1;

    /** text.e:1460	    	tch = format_pattern[i]*/
    _2 = (object)SEQ_PTR(_format_pattern_6621);
    _tch_6625 = (object)*(((s1_ptr)_2)->base + _i_6626);
    if (!IS_ATOM_INT(_tch_6625))
    _tch_6625 = (object)DBL_PTR(_tch_6625)->dbl;

    /** text.e:1461	    	if not in_token then*/
    if (_in_token_6624 != 0)
    goto L4; // [81] 210

    /** text.e:1462	    		if tch = '[' then*/
    if (_tch_6625 != 91)
    goto L5; // [86] 200

    /** text.e:1463	    			in_token = 1*/
    _in_token_6624 = 1;

    /** text.e:1464	    			tend = 0*/
    _tend_6627 = 0;

    /** text.e:1465					cap = 0*/
    _cap_6628 = 0;

    /** text.e:1466					align = 0*/
    _align_6629 = 0;

    /** text.e:1467					psign = 0*/
    _psign_6630 = 0;

    /** text.e:1468					msign = 0*/
    _msign_6631 = 0;

    /** text.e:1469					zfill = 0*/
    _zfill_6632 = 0;

    /** text.e:1470					bwz = 0*/
    _bwz_6633 = 0;

    /** text.e:1471					spacer = 0*/
    _spacer_6634 = 0;

    /** text.e:1472					alt = 0*/
    _alt_6635 = 0;

    /** text.e:1473	    			width = 0*/
    _width_6636 = 0;

    /** text.e:1474	    			decs = -1*/
    _decs_6637 = -1;

    /** text.e:1475	    			argn = 0*/
    _argn_6639 = 0;

    /** text.e:1476	    			hexout = 0*/
    _hexout_6642 = 0;

    /** text.e:1477	    			binout = 0*/
    _binout_6643 = 0;

    /** text.e:1478	    			trimming = 0*/
    _trimming_6641 = 0;

    /** text.e:1479	    			tsep = 0*/
    _tsep_6644 = 0;

    /** text.e:1480	    			istext = 0*/
    _istext_6645 = 0;

    /** text.e:1481	    			idname = ""*/
    RefDS(_5);
    DeRef(_idname_6648);
    _idname_6648 = _5;

    /** text.e:1482	    			envvar = ""*/
    RefDS(_5);
    DeRefi(_envvar_6650);
    _envvar_6650 = _5;

    /** text.e:1483	    			envsym = ""*/
    RefDS(_5);
    DeRef(_envsym_6649);
    _envsym_6649 = _5;
    goto L2; // [197] 60
L5: 

    /** text.e:1485	    			result &= tch*/
    Append(&_result_6623, _result_6623, _tch_6625);
    goto L2; // [207] 60
L4: 

    /** text.e:1488				switch tch do*/
    _0 = _tch_6625;
    switch ( _0 ){ 

        /** text.e:1489	    			case ']' then*/
        case 93:

        /** text.e:1490	    				in_token = 0*/
        _in_token_6624 = 0;

        /** text.e:1491	    				tend = i*/
        _tend_6627 = _i_6626;
        goto L6; // [231] 1072

        /** text.e:1493	    			case '[' then*/
        case 91:

        /** text.e:1494		    			result &= tch*/
        Append(&_result_6623, _result_6623, _tch_6625);

        /** text.e:1495		    			while i < length(format_pattern) do*/
L7: 
        if (IS_SEQUENCE(_format_pattern_6621)){
                _3571 = SEQ_PTR(_format_pattern_6621)->length;
        }
        else {
            _3571 = 1;
        }
        if (_i_6626 >= _3571)
        goto L6; // [251] 1072

        /** text.e:1496		    				i += 1*/
        _i_6626 = _i_6626 + 1;

        /** text.e:1497		    				if format_pattern[i] = ']' then*/
        _2 = (object)SEQ_PTR(_format_pattern_6621);
        _3574 = (object)*(((s1_ptr)_2)->base + _i_6626);
        if (binary_op_a(NOTEQ, _3574, 93)){
            _3574 = NOVALUE;
            goto L7; // [267] 248
        }
        _3574 = NOVALUE;

        /** text.e:1498		    					in_token = 0*/
        _in_token_6624 = 0;

        /** text.e:1499		    					tend = 0*/
        _tend_6627 = 0;

        /** text.e:1500		    					exit*/
        goto L6; // [283] 1072

        /** text.e:1502		    			end while*/
        goto L7; // [288] 248
        goto L6; // [291] 1072

        /** text.e:1504		    		case 'w', 'u', 'l' then*/
        case 119:
        case 117:
        case 108:

        /** text.e:1505		    			cap = tch*/
        _cap_6628 = _tch_6625;
        goto L6; // [306] 1072

        /** text.e:1507		    		case 'b' then*/
        case 98:

        /** text.e:1508		    			bwz = 1*/
        _bwz_6633 = 1;
        goto L6; // [317] 1072

        /** text.e:1510		    		case 's' then*/
        case 115:

        /** text.e:1511		    			spacer = 1*/
        _spacer_6634 = 1;
        goto L6; // [328] 1072

        /** text.e:1513		    		case 't' then*/
        case 116:

        /** text.e:1514		    			trimming = 1*/
        _trimming_6641 = 1;
        goto L6; // [339] 1072

        /** text.e:1516		    		case 'z' then*/
        case 122:

        /** text.e:1517		    			zfill = 1*/
        _zfill_6632 = 1;
        goto L6; // [350] 1072

        /** text.e:1519		    		case 'X' then*/
        case 88:

        /** text.e:1520		    			hexout = 1*/
        _hexout_6642 = 1;
        goto L6; // [361] 1072

        /** text.e:1522		    		case 'B' then*/
        case 66:

        /** text.e:1523		    			binout = 1*/
        _binout_6643 = 1;
        goto L6; // [372] 1072

        /** text.e:1525		    		case 'c', '<', '>' then*/
        case 99:
        case 60:
        case 62:

        /** text.e:1526		    			align = tch*/
        _align_6629 = _tch_6625;
        goto L6; // [387] 1072

        /** text.e:1528		    		case '+' then*/
        case 43:

        /** text.e:1529		    			psign = 1*/
        _psign_6630 = 1;
        goto L6; // [398] 1072

        /** text.e:1531		    		case '(' then*/
        case 40:

        /** text.e:1532		    			msign = 1*/
        _msign_6631 = 1;
        goto L6; // [409] 1072

        /** text.e:1534		    		case '?' then*/
        case 63:

        /** text.e:1535		    			alt = 1*/
        _alt_6635 = 1;
        goto L6; // [420] 1072

        /** text.e:1537		    		case 'T' then*/
        case 84:

        /** text.e:1538		    			istext = 1*/
        _istext_6645 = 1;
        goto L6; // [431] 1072

        /** text.e:1540		    		case ':' then*/
        case 58:

        /** text.e:1541		    			while i < length(format_pattern) do*/
L8: 
        if (IS_SEQUENCE(_format_pattern_6621)){
                _3585 = SEQ_PTR(_format_pattern_6621)->length;
        }
        else {
            _3585 = 1;
        }
        if (_i_6626 >= _3585)
        goto L6; // [445] 1072

        /** text.e:1542		    				i += 1*/
        _i_6626 = _i_6626 + 1;

        /** text.e:1543		    				tch = format_pattern[i]*/
        _2 = (object)SEQ_PTR(_format_pattern_6621);
        _tch_6625 = (object)*(((s1_ptr)_2)->base + _i_6626);
        if (!IS_ATOM_INT(_tch_6625))
        _tch_6625 = (object)DBL_PTR(_tch_6625)->dbl;

        /** text.e:1544		    				pos = find(tch, "0123456789")*/
        _pos_6638 = find_from(_tch_6625, _3589, 1);

        /** text.e:1545		    				if pos = 0 then*/
        if (_pos_6638 != 0)
        goto L9; // [470] 485

        /** text.e:1546		    					i -= 1*/
        _i_6626 = _i_6626 - 1;

        /** text.e:1547		    					exit*/
        goto L6; // [482] 1072
L9: 

        /** text.e:1549		    				width = width * 10 + pos - 1*/
        if (_width_6636 == (short)_width_6636){
            _3593 = _width_6636 * 10;
        }
        else{
            _3593 = NewDouble(_width_6636 * (eudouble)10);
        }
        if (IS_ATOM_INT(_3593)) {
            _3594 = _3593 + _pos_6638;
            if ((object)((uintptr_t)_3594 + (uintptr_t)HIGH_BITS) >= 0){
                _3594 = NewDouble((eudouble)_3594);
            }
        }
        else {
            _3594 = NewDouble(DBL_PTR(_3593)->dbl + (eudouble)_pos_6638);
        }
        DeRef(_3593);
        _3593 = NOVALUE;
        if (IS_ATOM_INT(_3594)) {
            _width_6636 = _3594 - 1;
        }
        else {
            _width_6636 = NewDouble(DBL_PTR(_3594)->dbl - (eudouble)1);
        }
        DeRef(_3594);
        _3594 = NOVALUE;
        if (!IS_ATOM_INT(_width_6636)) {
            _1 = (object)(DBL_PTR(_width_6636)->dbl);
            DeRefDS(_width_6636);
            _width_6636 = _1;
        }

        /** text.e:1550		    				if width = 0 then*/
        if (_width_6636 != 0)
        goto L8; // [505] 442

        /** text.e:1551		    					zfill = '0'*/
        _zfill_6632 = 48;

        /** text.e:1553		    			end while*/
        goto L8; // [517] 442
        goto L6; // [520] 1072

        /** text.e:1555		    		case '.' then*/
        case 46:

        /** text.e:1556		    			decs = 0*/
        _decs_6637 = 0;

        /** text.e:1557		    			while i < length(format_pattern) do*/
LA: 
        if (IS_SEQUENCE(_format_pattern_6621)){
                _3597 = SEQ_PTR(_format_pattern_6621)->length;
        }
        else {
            _3597 = 1;
        }
        if (_i_6626 >= _3597)
        goto L6; // [539] 1072

        /** text.e:1558		    				i += 1*/
        _i_6626 = _i_6626 + 1;

        /** text.e:1559		    				tch = format_pattern[i]*/
        _2 = (object)SEQ_PTR(_format_pattern_6621);
        _tch_6625 = (object)*(((s1_ptr)_2)->base + _i_6626);
        if (!IS_ATOM_INT(_tch_6625))
        _tch_6625 = (object)DBL_PTR(_tch_6625)->dbl;

        /** text.e:1560		    				pos = find(tch, "0123456789")*/
        _pos_6638 = find_from(_tch_6625, _3589, 1);

        /** text.e:1561		    				if pos = 0 then*/
        if (_pos_6638 != 0)
        goto LB; // [564] 579

        /** text.e:1562		    					i -= 1*/
        _i_6626 = _i_6626 - 1;

        /** text.e:1563		    					exit*/
        goto L6; // [576] 1072
LB: 

        /** text.e:1565		    				decs = decs * 10 + pos - 1*/
        if (_decs_6637 == (short)_decs_6637){
            _3604 = _decs_6637 * 10;
        }
        else{
            _3604 = NewDouble(_decs_6637 * (eudouble)10);
        }
        if (IS_ATOM_INT(_3604)) {
            _3605 = _3604 + _pos_6638;
            if ((object)((uintptr_t)_3605 + (uintptr_t)HIGH_BITS) >= 0){
                _3605 = NewDouble((eudouble)_3605);
            }
        }
        else {
            _3605 = NewDouble(DBL_PTR(_3604)->dbl + (eudouble)_pos_6638);
        }
        DeRef(_3604);
        _3604 = NOVALUE;
        if (IS_ATOM_INT(_3605)) {
            _decs_6637 = _3605 - 1;
        }
        else {
            _decs_6637 = NewDouble(DBL_PTR(_3605)->dbl - (eudouble)1);
        }
        DeRef(_3605);
        _3605 = NOVALUE;
        if (!IS_ATOM_INT(_decs_6637)) {
            _1 = (object)(DBL_PTR(_decs_6637)->dbl);
            DeRefDS(_decs_6637);
            _decs_6637 = _1;
        }

        /** text.e:1566		    			end while*/
        goto LA; // [597] 536
        goto L6; // [600] 1072

        /** text.e:1568		    		case '{' then*/
        case 123:

        /** text.e:1570		    			integer sp*/

        /** text.e:1572		    			sp = i + 1*/
        _sp_6733 = _i_6626 + 1;

        /** text.e:1573		    			i = sp*/
        _i_6626 = _sp_6733;

        /** text.e:1574		    			while i < length(format_pattern) do*/
LC: 
        if (IS_SEQUENCE(_format_pattern_6621)){
                _3608 = SEQ_PTR(_format_pattern_6621)->length;
        }
        else {
            _3608 = 1;
        }
        if (_i_6626 >= _3608)
        goto LD; // [627] 672

        /** text.e:1575		    				if format_pattern[i] = '}' then*/
        _2 = (object)SEQ_PTR(_format_pattern_6621);
        _3610 = (object)*(((s1_ptr)_2)->base + _i_6626);
        if (binary_op_a(NOTEQ, _3610, 125)){
            _3610 = NOVALUE;
            goto LE; // [637] 646
        }
        _3610 = NOVALUE;

        /** text.e:1576		    					exit*/
        goto LD; // [643] 672
LE: 

        /** text.e:1578		    				if format_pattern[i] = ']' then*/
        _2 = (object)SEQ_PTR(_format_pattern_6621);
        _3612 = (object)*(((s1_ptr)_2)->base + _i_6626);
        if (binary_op_a(NOTEQ, _3612, 93)){
            _3612 = NOVALUE;
            goto LF; // [652] 661
        }
        _3612 = NOVALUE;

        /** text.e:1579		    					exit*/
        goto LD; // [658] 672
LF: 

        /** text.e:1581		    				i += 1*/
        _i_6626 = _i_6626 + 1;

        /** text.e:1582		    			end while*/
        goto LC; // [669] 624
LD: 

        /** text.e:1583		    			idname = trim(format_pattern[sp .. i-1]) & '='*/
        _3615 = _i_6626 - 1;
        rhs_slice_target = (object_ptr)&_3616;
        RHS_Slice(_format_pattern_6621, _sp_6733, _3615);
        RefDS(_3010);
        _3617 = _18trim(_3616, _3010, 0);
        _3616 = NOVALUE;
        if (IS_SEQUENCE(_3617) && IS_ATOM(61)) {
            Append(&_idname_6648, _3617, 61);
        }
        else if (IS_ATOM(_3617) && IS_SEQUENCE(61)) {
        }
        else {
            Concat((object_ptr)&_idname_6648, _3617, 61);
            DeRef(_3617);
            _3617 = NOVALUE;
        }
        DeRef(_3617);
        _3617 = NOVALUE;

        /** text.e:1584	    				if format_pattern[i] = ']' then*/
        _2 = (object)SEQ_PTR(_format_pattern_6621);
        _3620 = (object)*(((s1_ptr)_2)->base + _i_6626);
        if (binary_op_a(NOTEQ, _3620, 93)){
            _3620 = NOVALUE;
            goto L10; // [699] 710
        }
        _3620 = NOVALUE;

        /** text.e:1585	    					i -= 1*/
        _i_6626 = _i_6626 - 1;
L10: 

        /** text.e:1588	    				for j = 1 to length(arg_list) do*/
        if (IS_SEQUENCE(_arg_list_6622)){
                _3623 = SEQ_PTR(_arg_list_6622)->length;
        }
        else {
            _3623 = 1;
        }
        {
            object _j_6755;
            _j_6755 = 1;
L11: 
            if (_j_6755 > _3623){
                goto L12; // [715] 797
            }

            /** text.e:1589	    					if sequence(arg_list[j]) then*/
            _2 = (object)SEQ_PTR(_arg_list_6622);
            _3624 = (object)*(((s1_ptr)_2)->base + _j_6755);
            _3625 = IS_SEQUENCE(_3624);
            _3624 = NOVALUE;
            if (_3625 == 0)
            {
                _3625 = NOVALUE;
                goto L13; // [731] 768
            }
            else{
                _3625 = NOVALUE;
            }

            /** text.e:1590	    						if search:begins(idname, arg_list[j]) then*/
            _2 = (object)SEQ_PTR(_arg_list_6622);
            _3626 = (object)*(((s1_ptr)_2)->base + _j_6755);
            RefDS(_idname_6648);
            Ref(_3626);
            _3627 = _20begins(_idname_6648, _3626);
            _3626 = NOVALUE;
            if (_3627 == 0) {
                DeRef(_3627);
                _3627 = NOVALUE;
                goto L14; // [745] 767
            }
            else {
                if (!IS_ATOM_INT(_3627) && DBL_PTR(_3627)->dbl == 0.0){
                    DeRef(_3627);
                    _3627 = NOVALUE;
                    goto L14; // [745] 767
                }
                DeRef(_3627);
                _3627 = NOVALUE;
            }
            DeRef(_3627);
            _3627 = NOVALUE;

            /** text.e:1591	    							if argn = 0 then*/
            if (_argn_6639 != 0)
            goto L15; // [752] 766

            /** text.e:1592	    								argn = j*/
            _argn_6639 = _j_6755;

            /** text.e:1593	    								exit*/
            goto L12; // [763] 797
L15: 
L14: 
L13: 

            /** text.e:1597	    					if j = length(arg_list) then*/
            if (IS_SEQUENCE(_arg_list_6622)){
                    _3629 = SEQ_PTR(_arg_list_6622)->length;
            }
            else {
                _3629 = 1;
            }
            if (_j_6755 != _3629)
            goto L16; // [773] 790

            /** text.e:1598	    						idname = ""*/
            RefDS(_5);
            DeRef(_idname_6648);
            _idname_6648 = _5;

            /** text.e:1599	    						argn = -1*/
            _argn_6639 = -1;
L16: 

            /** text.e:1601	    				end for*/
            _j_6755 = _j_6755 + 1;
            goto L11; // [792] 722
L12: 
            ;
        }
        goto L6; // [799] 1072

        /** text.e:1602		    		case '%' then*/
        case 37:

        /** text.e:1604		    			integer sp*/

        /** text.e:1606		    			sp = i + 1*/
        _sp_6769 = _i_6626 + 1;

        /** text.e:1607		    			i = sp*/
        _i_6626 = _sp_6769;

        /** text.e:1608		    			while i < length(format_pattern) do*/
L17: 
        if (IS_SEQUENCE(_format_pattern_6621)){
                _3632 = SEQ_PTR(_format_pattern_6621)->length;
        }
        else {
            _3632 = 1;
        }
        if (_i_6626 >= _3632)
        goto L18; // [826] 871

        /** text.e:1609		    				if format_pattern[i] = '%' then*/
        _2 = (object)SEQ_PTR(_format_pattern_6621);
        _3634 = (object)*(((s1_ptr)_2)->base + _i_6626);
        if (binary_op_a(NOTEQ, _3634, 37)){
            _3634 = NOVALUE;
            goto L19; // [836] 845
        }
        _3634 = NOVALUE;

        /** text.e:1610		    					exit*/
        goto L18; // [842] 871
L19: 

        /** text.e:1612		    				if format_pattern[i] = ']' then*/
        _2 = (object)SEQ_PTR(_format_pattern_6621);
        _3636 = (object)*(((s1_ptr)_2)->base + _i_6626);
        if (binary_op_a(NOTEQ, _3636, 93)){
            _3636 = NOVALUE;
            goto L1A; // [851] 860
        }
        _3636 = NOVALUE;

        /** text.e:1613		    					exit*/
        goto L18; // [857] 871
L1A: 

        /** text.e:1615		    				i += 1*/
        _i_6626 = _i_6626 + 1;

        /** text.e:1616		    			end while*/
        goto L17; // [868] 823
L18: 

        /** text.e:1617		    			envsym = trim(format_pattern[sp .. i-1])*/
        _3639 = _i_6626 - 1;
        rhs_slice_target = (object_ptr)&_3640;
        RHS_Slice(_format_pattern_6621, _sp_6769, _3639);
        RefDS(_3010);
        _0 = _envsym_6649;
        _envsym_6649 = _18trim(_3640, _3010, 0);
        DeRef(_0);
        _3640 = NOVALUE;

        /** text.e:1618	    				if format_pattern[i] = ']' then*/
        _2 = (object)SEQ_PTR(_format_pattern_6621);
        _3642 = (object)*(((s1_ptr)_2)->base + _i_6626);
        if (binary_op_a(NOTEQ, _3642, 93)){
            _3642 = NOVALUE;
            goto L1B; // [894] 905
        }
        _3642 = NOVALUE;

        /** text.e:1619	    					i -= 1*/
        _i_6626 = _i_6626 - 1;
L1B: 

        /** text.e:1622	    				envvar = getenv(envsym)*/
        DeRefi(_envvar_6650);
        _envvar_6650 = EGetEnv(_envsym_6649);

        /** text.e:1624	    				argn = -1*/
        _argn_6639 = -1;

        /** text.e:1625	    				if atom(envvar) then*/
        _3646 = IS_ATOM(_envvar_6650);
        if (_3646 == 0)
        {
            _3646 = NOVALUE;
            goto L1C; // [920] 929
        }
        else{
            _3646 = NOVALUE;
        }

        /** text.e:1626	    					envvar = ""*/
        RefDS(_5);
        DeRefi(_envvar_6650);
        _envvar_6650 = _5;
L1C: 
        goto L6; // [931] 1072

        /** text.e:1630		    		case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' then*/
        case 48:
        case 49:
        case 50:
        case 51:
        case 52:
        case 53:
        case 54:
        case 55:
        case 56:
        case 57:

        /** text.e:1631		    			if argn = 0 then*/
        if (_argn_6639 != 0)
        goto L6; // [957] 1072

        /** text.e:1632			    			i -= 1*/
        _i_6626 = _i_6626 - 1;

        /** text.e:1633			    			while i < length(format_pattern) do*/
L1D: 
        if (IS_SEQUENCE(_format_pattern_6621)){
                _3649 = SEQ_PTR(_format_pattern_6621)->length;
        }
        else {
            _3649 = 1;
        }
        if (_i_6626 >= _3649)
        goto L6; // [975] 1072

        /** text.e:1634			    				i += 1*/
        _i_6626 = _i_6626 + 1;

        /** text.e:1635			    				tch = format_pattern[i]*/
        _2 = (object)SEQ_PTR(_format_pattern_6621);
        _tch_6625 = (object)*(((s1_ptr)_2)->base + _i_6626);
        if (!IS_ATOM_INT(_tch_6625))
        _tch_6625 = (object)DBL_PTR(_tch_6625)->dbl;

        /** text.e:1636			    				pos = find(tch, "0123456789")*/
        _pos_6638 = find_from(_tch_6625, _3589, 1);

        /** text.e:1637			    				if pos = 0 then*/
        if (_pos_6638 != 0)
        goto L1E; // [1000] 1015

        /** text.e:1638			    					i -= 1*/
        _i_6626 = _i_6626 - 1;

        /** text.e:1639			    					exit*/
        goto L6; // [1012] 1072
L1E: 

        /** text.e:1641			    				argn = argn * 10 + pos - 1*/
        if (_argn_6639 == (short)_argn_6639){
            _3656 = _argn_6639 * 10;
        }
        else{
            _3656 = NewDouble(_argn_6639 * (eudouble)10);
        }
        if (IS_ATOM_INT(_3656)) {
            _3657 = _3656 + _pos_6638;
            if ((object)((uintptr_t)_3657 + (uintptr_t)HIGH_BITS) >= 0){
                _3657 = NewDouble((eudouble)_3657);
            }
        }
        else {
            _3657 = NewDouble(DBL_PTR(_3656)->dbl + (eudouble)_pos_6638);
        }
        DeRef(_3656);
        _3656 = NOVALUE;
        if (IS_ATOM_INT(_3657)) {
            _argn_6639 = _3657 - 1;
        }
        else {
            _argn_6639 = NewDouble(DBL_PTR(_3657)->dbl - (eudouble)1);
        }
        DeRef(_3657);
        _3657 = NOVALUE;
        if (!IS_ATOM_INT(_argn_6639)) {
            _1 = (object)(DBL_PTR(_argn_6639)->dbl);
            DeRefDS(_argn_6639);
            _argn_6639 = _1;
        }

        /** text.e:1642			    			end while*/
        goto L1D; // [1033] 972
        goto L6; // [1037] 1072

        /** text.e:1645		    		case ',' then*/
        case 44:

        /** text.e:1646		    			if i < length(format_pattern) then*/
        if (IS_SEQUENCE(_format_pattern_6621)){
                _3659 = SEQ_PTR(_format_pattern_6621)->length;
        }
        else {
            _3659 = 1;
        }
        if (_i_6626 >= _3659)
        goto L6; // [1048] 1072

        /** text.e:1647		    				i +=1*/
        _i_6626 = _i_6626 + 1;

        /** text.e:1648		    				tsep = format_pattern[i]*/
        _2 = (object)SEQ_PTR(_format_pattern_6621);
        _tsep_6644 = (object)*(((s1_ptr)_2)->base + _i_6626);
        if (!IS_ATOM_INT(_tsep_6644))
        _tsep_6644 = (object)DBL_PTR(_tsep_6644)->dbl;
        goto L6; // [1065] 1072

        /** text.e:1651		    		case else*/
        default:
    ;}L6: 

    /** text.e:1655	    		if tend > 0 then*/
    if (_tend_6627 <= 0)
    goto L1F; // [1074] 3606

    /** text.e:1657	    			sequence argtext = ""*/
    RefDS(_5);
    DeRef(_argtext_6816);
    _argtext_6816 = _5;

    /** text.e:1659	    			if argn = 0 then*/
    if (_argn_6639 != 0)
    goto L20; // [1089] 1100

    /** text.e:1660	    				argn = argl + 1*/
    _argn_6639 = _argl_6640 + 1;
L20: 

    /** text.e:1662	    			argl = argn*/
    _argl_6640 = _argn_6639;

    /** text.e:1664	    			if argn < 1 or argn > length(arg_list) then*/
    _3666 = (_argn_6639 < 1);
    if (_3666 != 0) {
        goto L21; // [1111] 1127
    }
    if (IS_SEQUENCE(_arg_list_6622)){
            _3668 = SEQ_PTR(_arg_list_6622)->length;
    }
    else {
        _3668 = 1;
    }
    _3669 = (_argn_6639 > _3668);
    _3668 = NOVALUE;
    if (_3669 == 0)
    {
        DeRef(_3669);
        _3669 = NOVALUE;
        goto L22; // [1123] 1169
    }
    else{
        DeRef(_3669);
        _3669 = NOVALUE;
    }
L21: 

    /** text.e:1665	    				if length(envvar) > 0 then*/
    if (IS_SEQUENCE(_envvar_6650)){
            _3670 = SEQ_PTR(_envvar_6650)->length;
    }
    else {
        _3670 = 1;
    }
    if (_3670 <= 0)
    goto L23; // [1134] 1153

    /** text.e:1666	    					argtext = envvar*/
    Ref(_envvar_6650);
    DeRef(_argtext_6816);
    _argtext_6816 = _envvar_6650;

    /** text.e:1667		    				currargv = envvar*/
    Ref(_envvar_6650);
    DeRef(_currargv_6647);
    _currargv_6647 = _envvar_6650;
    goto L24; // [1150] 2647
L23: 

    /** text.e:1669	    					argtext = ""*/
    RefDS(_5);
    DeRef(_argtext_6816);
    _argtext_6816 = _5;

    /** text.e:1670		    				currargv =""*/
    RefDS(_5);
    DeRef(_currargv_6647);
    _currargv_6647 = _5;
    goto L24; // [1166] 2647
L22: 

    /** text.e:1673						if string(arg_list[argn]) then*/
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3672 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    Ref(_3672);
    _3673 = _9string(_3672);
    _3672 = NOVALUE;
    if (_3673 == 0) {
        DeRef(_3673);
        _3673 = NOVALUE;
        goto L25; // [1179] 1229
    }
    else {
        if (!IS_ATOM_INT(_3673) && DBL_PTR(_3673)->dbl == 0.0){
            DeRef(_3673);
            _3673 = NOVALUE;
            goto L25; // [1179] 1229
        }
        DeRef(_3673);
        _3673 = NOVALUE;
    }
    DeRef(_3673);
    _3673 = NOVALUE;

    /** text.e:1674							if length(idname) > 0 then*/
    if (IS_SEQUENCE(_idname_6648)){
            _3674 = SEQ_PTR(_idname_6648)->length;
    }
    else {
        _3674 = 1;
    }
    if (_3674 <= 0)
    goto L26; // [1189] 1217

    /** text.e:1675								argtext = arg_list[argn][length(idname) + 1 .. $]*/
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3676 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    if (IS_SEQUENCE(_idname_6648)){
            _3677 = SEQ_PTR(_idname_6648)->length;
    }
    else {
        _3677 = 1;
    }
    _3678 = _3677 + 1;
    _3677 = NOVALUE;
    if (IS_SEQUENCE(_3676)){
            _3679 = SEQ_PTR(_3676)->length;
    }
    else {
        _3679 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_6816;
    RHS_Slice(_3676, _3678, _3679);
    _3676 = NOVALUE;
    goto L27; // [1214] 2640
L26: 

    /** text.e:1677								argtext = arg_list[argn]*/
    DeRef(_argtext_6816);
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _argtext_6816 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    Ref(_argtext_6816);
    goto L27; // [1226] 2640
L25: 

    /** text.e:1680						elsif integer(arg_list[argn]) */
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3682 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    if (IS_ATOM_INT(_3682))
    _3683 = 1;
    else if (IS_ATOM_DBL(_3682))
    _3683 = IS_ATOM_INT(DoubleToInt(_3682));
    else
    _3683 = 0;
    _3682 = NOVALUE;
    if (_3683 == 0) {
        _3684 = 0;
        goto L28; // [1238] 1254
    }
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3685 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    if (IS_ATOM_INT(_3685)) {
        _3687 = (_3685 <= 1073741823);
    }
    else {
        _3687 = binary_op(LESSEQ, _3685, 1073741823);
    }
    _3685 = NOVALUE;
    if (IS_ATOM_INT(_3687))
    _3684 = (_3687 != 0);
    else
    _3684 = DBL_PTR(_3687)->dbl != 0.0;
L28: 
    if (_3684 == 0) {
        goto L29; // [1254] 1812
    }
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3689 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    _3692 = binary_op(GREATEREQ, _3689, _3691);
    _3689 = NOVALUE;
    if (_3692 == 0) {
        DeRef(_3692);
        _3692 = NOVALUE;
        goto L29; // [1267] 1812
    }
    else {
        if (!IS_ATOM_INT(_3692) && DBL_PTR(_3692)->dbl == 0.0){
            DeRef(_3692);
            _3692 = NOVALUE;
            goto L29; // [1267] 1812
        }
        DeRef(_3692);
        _3692 = NOVALUE;
    }
    DeRef(_3692);
    _3692 = NOVALUE;

    /** text.e:1684							if istext then*/
    if (_istext_6645 == 0)
    {
        goto L2A; // [1274] 1298
    }
    else{
    }

    /** text.e:1685								argtext = {and_bits(0xFFFF_FFFF, math:abs(arg_list[argn]))}*/
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3693 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    Ref(_3693);
    _3694 = _21abs(_3693);
    _3693 = NOVALUE;
    _3695 = binary_op(AND_BITS, _390, _3694);
    DeRef(_3694);
    _3694 = NOVALUE;
    _0 = _argtext_6816;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _3695;
    _argtext_6816 = MAKE_SEQ(_1);
    DeRef(_0);
    _3695 = NOVALUE;
    goto L27; // [1295] 2640
L2A: 

    /** text.e:1687							elsif bwz != 0 and arg_list[argn] = 0 then*/
    _3697 = (_bwz_6633 != 0);
    if (_3697 == 0) {
        goto L2B; // [1306] 1333
    }
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3699 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    if (IS_ATOM_INT(_3699)) {
        _3700 = (_3699 == 0);
    }
    else {
        _3700 = binary_op(EQUALS, _3699, 0);
    }
    _3699 = NOVALUE;
    if (_3700 == 0) {
        DeRef(_3700);
        _3700 = NOVALUE;
        goto L2B; // [1319] 1333
    }
    else {
        if (!IS_ATOM_INT(_3700) && DBL_PTR(_3700)->dbl == 0.0){
            DeRef(_3700);
            _3700 = NOVALUE;
            goto L2B; // [1319] 1333
        }
        DeRef(_3700);
        _3700 = NOVALUE;
    }
    DeRef(_3700);
    _3700 = NOVALUE;

    /** text.e:1688								argtext = repeat(' ', width)*/
    DeRef(_argtext_6816);
    _argtext_6816 = Repeat(32, _width_6636);
    goto L27; // [1330] 2640
L2B: 

    /** text.e:1690							elsif binout = 1 then*/
    if (_binout_6643 != 1)
    goto L2C; // [1337] 1476

    /** text.e:1691								argtext = stdseq:reverse( convert:int_to_bits(arg_list[argn], 32)) + '0'*/
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3703 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    Ref(_3703);
    _3704 = _19int_to_bits(_3703, 32);
    _3703 = NOVALUE;
    _3705 = _24reverse(_3704, 1, 0);
    _3704 = NOVALUE;
    DeRef(_argtext_6816);
    if (IS_ATOM_INT(_3705)) {
        _argtext_6816 = _3705 + 48;
        if ((object)((uintptr_t)_argtext_6816 + (uintptr_t)HIGH_BITS) >= 0){
            _argtext_6816 = NewDouble((eudouble)_argtext_6816);
        }
    }
    else {
        _argtext_6816 = binary_op(PLUS, _3705, 48);
    }
    DeRef(_3705);
    _3705 = NOVALUE;

    /** text.e:1692								if zfill != 0 and width > 0 then*/
    _3707 = (_zfill_6632 != 0);
    if (_3707 == 0) {
        goto L2D; // [1372] 1418
    }
    _3709 = (_width_6636 > 0);
    if (_3709 == 0)
    {
        DeRef(_3709);
        _3709 = NOVALUE;
        goto L2D; // [1383] 1418
    }
    else{
        DeRef(_3709);
        _3709 = NOVALUE;
    }

    /** text.e:1693									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3710 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3710 = 1;
    }
    if (_width_6636 <= _3710)
    goto L27; // [1393] 2640

    /** text.e:1694										argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3712 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3712 = 1;
    }
    _3713 = _width_6636 - _3712;
    _3712 = NOVALUE;
    _3714 = Repeat(48, _3713);
    _3713 = NOVALUE;
    Concat((object_ptr)&_argtext_6816, _3714, _argtext_6816);
    DeRefDS(_3714);
    _3714 = NOVALUE;
    DeRef(_3714);
    _3714 = NOVALUE;
    goto L27; // [1415] 2640
L2D: 

    /** text.e:1697									count = 1*/
    _count_6653 = 1;

    /** text.e:1698									while count < length(argtext) and argtext[count] = '0' do*/
L2E: 
    if (IS_SEQUENCE(_argtext_6816)){
            _3716 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3716 = 1;
    }
    _3717 = (_count_6653 < _3716);
    _3716 = NOVALUE;
    if (_3717 == 0) {
        goto L2F; // [1435] 1462
    }
    _2 = (object)SEQ_PTR(_argtext_6816);
    _3719 = (object)*(((s1_ptr)_2)->base + _count_6653);
    if (IS_ATOM_INT(_3719)) {
        _3720 = (_3719 == 48);
    }
    else {
        _3720 = binary_op(EQUALS, _3719, 48);
    }
    _3719 = NOVALUE;
    if (_3720 <= 0) {
        if (_3720 == 0) {
            DeRef(_3720);
            _3720 = NOVALUE;
            goto L2F; // [1448] 1462
        }
        else {
            if (!IS_ATOM_INT(_3720) && DBL_PTR(_3720)->dbl == 0.0){
                DeRef(_3720);
                _3720 = NOVALUE;
                goto L2F; // [1448] 1462
            }
            DeRef(_3720);
            _3720 = NOVALUE;
        }
    }
    DeRef(_3720);
    _3720 = NOVALUE;

    /** text.e:1699										count += 1*/
    _count_6653 = _count_6653 + 1;

    /** text.e:1700									end while*/
    goto L2E; // [1459] 1428
L2F: 

    /** text.e:1701									argtext = argtext[count .. $]*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3722 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3722 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_6816;
    RHS_Slice(_argtext_6816, _count_6653, _3722);
    goto L27; // [1473] 2640
L2C: 

    /** text.e:1704							elsif hexout = 0 then*/
    if (_hexout_6642 != 0)
    goto L30; // [1480] 1746

    /** text.e:1705								argtext = sprintf("%d", arg_list[argn])*/
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3725 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    DeRef(_argtext_6816);
    _argtext_6816 = EPrintf(-9999999, _657, _3725);
    _3725 = NOVALUE;

    /** text.e:1706								if zfill != 0 and width > 0 then*/
    _3727 = (_zfill_6632 != 0);
    if (_3727 == 0) {
        goto L31; // [1502] 1599
    }
    _3729 = (_width_6636 > 0);
    if (_3729 == 0)
    {
        DeRef(_3729);
        _3729 = NOVALUE;
        goto L31; // [1513] 1599
    }
    else{
        DeRef(_3729);
        _3729 = NOVALUE;
    }

    /** text.e:1707									if argtext[1] = '-' then*/
    _2 = (object)SEQ_PTR(_argtext_6816);
    _3730 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _3730, 45)){
        _3730 = NOVALUE;
        goto L32; // [1522] 1568
    }
    _3730 = NOVALUE;

    /** text.e:1708										if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3732 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3732 = 1;
    }
    if (_width_6636 <= _3732)
    goto L33; // [1533] 1598

    /** text.e:1709											argtext = '-' & repeat('0', width - length(argtext)) & argtext[2..$]*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3734 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3734 = 1;
    }
    _3735 = _width_6636 - _3734;
    _3734 = NOVALUE;
    _3736 = Repeat(48, _3735);
    _3735 = NOVALUE;
    if (IS_SEQUENCE(_argtext_6816)){
            _3737 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3737 = 1;
    }
    rhs_slice_target = (object_ptr)&_3738;
    RHS_Slice(_argtext_6816, 2, _3737);
    {
        object concat_list[3];

        concat_list[0] = _3738;
        concat_list[1] = _3736;
        concat_list[2] = 45;
        Concat_N((object_ptr)&_argtext_6816, concat_list, 3);
    }
    DeRefDS(_3738);
    _3738 = NOVALUE;
    DeRefDS(_3736);
    _3736 = NOVALUE;
    goto L33; // [1565] 1598
L32: 

    /** text.e:1712										if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3740 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3740 = 1;
    }
    if (_width_6636 <= _3740)
    goto L34; // [1575] 1597

    /** text.e:1713											argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3742 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3742 = 1;
    }
    _3743 = _width_6636 - _3742;
    _3742 = NOVALUE;
    _3744 = Repeat(48, _3743);
    _3743 = NOVALUE;
    Concat((object_ptr)&_argtext_6816, _3744, _argtext_6816);
    DeRefDS(_3744);
    _3744 = NOVALUE;
    DeRef(_3744);
    _3744 = NOVALUE;
L34: 
L33: 
L31: 

    /** text.e:1718								if arg_list[argn] > 0 then*/
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3746 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    if (binary_op_a(LESSEQ, _3746, 0)){
        _3746 = NOVALUE;
        goto L35; // [1605] 1653
    }
    _3746 = NOVALUE;

    /** text.e:1719									if psign then*/
    if (_psign_6630 == 0)
    {
        goto L27; // [1613] 2640
    }
    else{
    }

    /** text.e:1720										if zfill = 0 then*/
    if (_zfill_6632 != 0)
    goto L36; // [1618] 1631

    /** text.e:1721											argtext = '+' & argtext*/
    Prepend(&_argtext_6816, _argtext_6816, 43);
    goto L27; // [1628] 2640
L36: 

    /** text.e:1722										elsif argtext[1] = '0' then*/
    _2 = (object)SEQ_PTR(_argtext_6816);
    _3750 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _3750, 48)){
        _3750 = NOVALUE;
        goto L27; // [1637] 2640
    }
    _3750 = NOVALUE;

    /** text.e:1723											argtext[1] = '+'*/
    _2 = (object)SEQ_PTR(_argtext_6816);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _argtext_6816 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 43;
    DeRef(_1);
    goto L27; // [1650] 2640
L35: 

    /** text.e:1726								elsif arg_list[argn] < 0 then*/
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3752 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    if (binary_op_a(GREATEREQ, _3752, 0)){
        _3752 = NOVALUE;
        goto L27; // [1659] 2640
    }
    _3752 = NOVALUE;

    /** text.e:1727									if msign then*/
    if (_msign_6631 == 0)
    {
        goto L27; // [1667] 2640
    }
    else{
    }

    /** text.e:1728										if zfill = 0 then*/
    if (_zfill_6632 != 0)
    goto L37; // [1672] 1695

    /** text.e:1729											argtext = '(' & argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3755 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3755 = 1;
    }
    rhs_slice_target = (object_ptr)&_3756;
    RHS_Slice(_argtext_6816, 2, _3755);
    {
        object concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _3756;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_6816, concat_list, 3);
    }
    DeRefDS(_3756);
    _3756 = NOVALUE;
    goto L27; // [1692] 2640
L37: 

    /** text.e:1731											if argtext[2] = '0' then*/
    _2 = (object)SEQ_PTR(_argtext_6816);
    _3759 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _3759, 48)){
        _3759 = NOVALUE;
        goto L38; // [1701] 1724
    }
    _3759 = NOVALUE;

    /** text.e:1732												argtext = '(' & argtext[3..$] & ')'*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3761 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3761 = 1;
    }
    rhs_slice_target = (object_ptr)&_3762;
    RHS_Slice(_argtext_6816, 3, _3761);
    {
        object concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _3762;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_6816, concat_list, 3);
    }
    DeRefDS(_3762);
    _3762 = NOVALUE;
    goto L27; // [1721] 2640
L38: 

    /** text.e:1736												argtext = argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3764 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3764 = 1;
    }
    rhs_slice_target = (object_ptr)&_3765;
    RHS_Slice(_argtext_6816, 2, _3764);
    Append(&_argtext_6816, _3765, 41);
    DeRefDS(_3765);
    _3765 = NOVALUE;
    goto L27; // [1743] 2640
L30: 

    /** text.e:1742								argtext = sprintf("%x", arg_list[argn])*/
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3768 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    DeRef(_argtext_6816);
    _argtext_6816 = EPrintf(-9999999, _3767, _3768);
    _3768 = NOVALUE;

    /** text.e:1743								if zfill != 0 and width > 0 then*/
    _3770 = (_zfill_6632 != 0);
    if (_3770 == 0) {
        goto L27; // [1764] 2640
    }
    _3772 = (_width_6636 > 0);
    if (_3772 == 0)
    {
        DeRef(_3772);
        _3772 = NOVALUE;
        goto L27; // [1775] 2640
    }
    else{
        DeRef(_3772);
        _3772 = NOVALUE;
    }

    /** text.e:1744									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3773 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3773 = 1;
    }
    if (_width_6636 <= _3773)
    goto L27; // [1785] 2640

    /** text.e:1745										argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3775 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3775 = 1;
    }
    _3776 = _width_6636 - _3775;
    _3775 = NOVALUE;
    _3777 = Repeat(48, _3776);
    _3776 = NOVALUE;
    Concat((object_ptr)&_argtext_6816, _3777, _argtext_6816);
    DeRefDS(_3777);
    _3777 = NOVALUE;
    DeRef(_3777);
    _3777 = NOVALUE;
    goto L27; // [1809] 2640
L29: 

    /** text.e:1750						elsif atom(arg_list[argn]) then*/
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3779 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    _3780 = IS_ATOM(_3779);
    _3779 = NOVALUE;
    if (_3780 == 0)
    {
        _3780 = NOVALUE;
        goto L39; // [1821] 2224
    }
    else{
        _3780 = NOVALUE;
    }

    /** text.e:1751							if istext then*/
    if (_istext_6645 == 0)
    {
        goto L3A; // [1828] 1855
    }
    else{
    }

    /** text.e:1752								argtext = {and_bits(0xFFFF_FFFF, math:abs(floor(arg_list[argn])))}*/
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3781 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    if (IS_ATOM_INT(_3781))
    _3782 = e_floor(_3781);
    else
    _3782 = unary_op(FLOOR, _3781);
    _3781 = NOVALUE;
    _3783 = _21abs(_3782);
    _3782 = NOVALUE;
    _3784 = binary_op(AND_BITS, _390, _3783);
    DeRef(_3783);
    _3783 = NOVALUE;
    _0 = _argtext_6816;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _3784;
    _argtext_6816 = MAKE_SEQ(_1);
    DeRef(_0);
    _3784 = NOVALUE;
    goto L27; // [1852] 2640
L3A: 

    /** text.e:1755								if hexout then*/
    if (_hexout_6642 == 0)
    {
        goto L3B; // [1859] 1927
    }
    else{
    }

    /** text.e:1756									argtext = sprintf("%x", arg_list[argn])*/
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3786 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    DeRef(_argtext_6816);
    _argtext_6816 = EPrintf(-9999999, _3767, _3786);
    _3786 = NOVALUE;

    /** text.e:1757									if zfill != 0 and width > 0 then*/
    _3788 = (_zfill_6632 != 0);
    if (_3788 == 0) {
        goto L27; // [1880] 2640
    }
    _3790 = (_width_6636 > 0);
    if (_3790 == 0)
    {
        DeRef(_3790);
        _3790 = NOVALUE;
        goto L27; // [1891] 2640
    }
    else{
        DeRef(_3790);
        _3790 = NOVALUE;
    }

    /** text.e:1758										if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3791 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3791 = 1;
    }
    if (_width_6636 <= _3791)
    goto L27; // [1901] 2640

    /** text.e:1759											argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3793 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3793 = 1;
    }
    _3794 = _width_6636 - _3793;
    _3793 = NOVALUE;
    _3795 = Repeat(48, _3794);
    _3794 = NOVALUE;
    Concat((object_ptr)&_argtext_6816, _3795, _argtext_6816);
    DeRefDS(_3795);
    _3795 = NOVALUE;
    DeRef(_3795);
    _3795 = NOVALUE;
    goto L27; // [1924] 2640
L3B: 

    /** text.e:1763									argtext = trim(sprintf("%15.15g", arg_list[argn]))*/
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3798 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    _3799 = EPrintf(-9999999, _3797, _3798);
    _3798 = NOVALUE;
    RefDS(_3010);
    _0 = _argtext_6816;
    _argtext_6816 = _18trim(_3799, _3010, 0);
    DeRef(_0);
    _3799 = NOVALUE;

    /** text.e:1765									while ep != 0 with entry do*/
    goto L3C; // [1947] 1970
L3D: 
    if (_ep_6651 == 0)
    goto L3E; // [1952] 1982

    /** text.e:1766										argtext = remove(argtext, ep+2)*/
    _3802 = _ep_6651 + 2;
    if ((object)((uintptr_t)_3802 + (uintptr_t)HIGH_BITS) >= 0){
        _3802 = NewDouble((eudouble)_3802);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_argtext_6816);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_3802)) ? _3802 : (object)(DBL_PTR(_3802)->dbl);
        int stop = (IS_ATOM_INT(_3802)) ? _3802 : (object)(DBL_PTR(_3802)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_argtext_6816), start, &_argtext_6816 );
            }
            else Tail(SEQ_PTR(_argtext_6816), stop+1, &_argtext_6816);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_argtext_6816), start, &_argtext_6816);
        }
        else {
            assign_slice_seq = &assign_space;
            _argtext_6816 = Remove_elements(start, stop, (SEQ_PTR(_argtext_6816)->ref == 1));
        }
    }
    DeRef(_3802);
    _3802 = NOVALUE;
    _3802 = NOVALUE;

    /** text.e:1767									entry*/
L3C: 

    /** text.e:1768										ep = match("e+0", argtext)*/
    _ep_6651 = e_match_from(_3804, _argtext_6816, 1);

    /** text.e:1769									end while*/
    goto L3D; // [1979] 1950
L3E: 

    /** text.e:1770									if zfill != 0 and width > 0 then*/
    _3806 = (_zfill_6632 != 0);
    if (_3806 == 0) {
        goto L3F; // [1990] 2075
    }
    _3808 = (_width_6636 > 0);
    if (_3808 == 0)
    {
        DeRef(_3808);
        _3808 = NOVALUE;
        goto L3F; // [2001] 2075
    }
    else{
        DeRef(_3808);
        _3808 = NOVALUE;
    }

    /** text.e:1771										if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3809 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3809 = 1;
    }
    if (_width_6636 <= _3809)
    goto L40; // [2011] 2074

    /** text.e:1772											if argtext[1] = '-' then*/
    _2 = (object)SEQ_PTR(_argtext_6816);
    _3811 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _3811, 45)){
        _3811 = NOVALUE;
        goto L41; // [2021] 2055
    }
    _3811 = NOVALUE;

    /** text.e:1773												argtext = '-' & repeat('0', width - length(argtext)) & argtext[2..$]*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3813 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3813 = 1;
    }
    _3814 = _width_6636 - _3813;
    _3813 = NOVALUE;
    _3815 = Repeat(48, _3814);
    _3814 = NOVALUE;
    if (IS_SEQUENCE(_argtext_6816)){
            _3816 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3816 = 1;
    }
    rhs_slice_target = (object_ptr)&_3817;
    RHS_Slice(_argtext_6816, 2, _3816);
    {
        object concat_list[3];

        concat_list[0] = _3817;
        concat_list[1] = _3815;
        concat_list[2] = 45;
        Concat_N((object_ptr)&_argtext_6816, concat_list, 3);
    }
    DeRefDS(_3817);
    _3817 = NOVALUE;
    DeRefDS(_3815);
    _3815 = NOVALUE;
    goto L42; // [2052] 2073
L41: 

    /** text.e:1775												argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3819 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3819 = 1;
    }
    _3820 = _width_6636 - _3819;
    _3819 = NOVALUE;
    _3821 = Repeat(48, _3820);
    _3820 = NOVALUE;
    Concat((object_ptr)&_argtext_6816, _3821, _argtext_6816);
    DeRefDS(_3821);
    _3821 = NOVALUE;
    DeRef(_3821);
    _3821 = NOVALUE;
L42: 
L40: 
L3F: 

    /** text.e:1779									if arg_list[argn] > 0 then*/
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3823 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    if (binary_op_a(LESSEQ, _3823, 0)){
        _3823 = NOVALUE;
        goto L43; // [2081] 2129
    }
    _3823 = NOVALUE;

    /** text.e:1780										if psign  then*/
    if (_psign_6630 == 0)
    {
        goto L27; // [2089] 2640
    }
    else{
    }

    /** text.e:1781											if zfill = 0 then*/
    if (_zfill_6632 != 0)
    goto L44; // [2094] 2107

    /** text.e:1782												argtext = '+' & argtext*/
    Prepend(&_argtext_6816, _argtext_6816, 43);
    goto L27; // [2104] 2640
L44: 

    /** text.e:1783											elsif argtext[1] = '0' then*/
    _2 = (object)SEQ_PTR(_argtext_6816);
    _3827 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _3827, 48)){
        _3827 = NOVALUE;
        goto L27; // [2113] 2640
    }
    _3827 = NOVALUE;

    /** text.e:1784												argtext[1] = '+'*/
    _2 = (object)SEQ_PTR(_argtext_6816);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _argtext_6816 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 43;
    DeRef(_1);
    goto L27; // [2126] 2640
L43: 

    /** text.e:1787									elsif arg_list[argn] < 0 then*/
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3829 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    if (binary_op_a(GREATEREQ, _3829, 0)){
        _3829 = NOVALUE;
        goto L27; // [2135] 2640
    }
    _3829 = NOVALUE;

    /** text.e:1788										if msign then*/
    if (_msign_6631 == 0)
    {
        goto L27; // [2143] 2640
    }
    else{
    }

    /** text.e:1789											if zfill = 0 then*/
    if (_zfill_6632 != 0)
    goto L45; // [2148] 2171

    /** text.e:1790												argtext = '(' & argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3832 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3832 = 1;
    }
    rhs_slice_target = (object_ptr)&_3833;
    RHS_Slice(_argtext_6816, 2, _3832);
    {
        object concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _3833;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_6816, concat_list, 3);
    }
    DeRefDS(_3833);
    _3833 = NOVALUE;
    goto L27; // [2168] 2640
L45: 

    /** text.e:1792												if argtext[2] = '0' then*/
    _2 = (object)SEQ_PTR(_argtext_6816);
    _3835 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _3835, 48)){
        _3835 = NOVALUE;
        goto L46; // [2177] 2200
    }
    _3835 = NOVALUE;

    /** text.e:1793													argtext = '(' & argtext[3..$] & ')'*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3837 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3837 = 1;
    }
    rhs_slice_target = (object_ptr)&_3838;
    RHS_Slice(_argtext_6816, 3, _3837);
    {
        object concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _3838;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_6816, concat_list, 3);
    }
    DeRefDS(_3838);
    _3838 = NOVALUE;
    goto L27; // [2197] 2640
L46: 

    /** text.e:1795													argtext = argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3840 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3840 = 1;
    }
    rhs_slice_target = (object_ptr)&_3841;
    RHS_Slice(_argtext_6816, 2, _3840);
    Append(&_argtext_6816, _3841, 41);
    DeRefDS(_3841);
    _3841 = NOVALUE;
    goto L27; // [2221] 2640
L39: 

    /** text.e:1804							if alt != 0 and length(arg_list[argn]) = 2 then*/
    _3843 = (_alt_6635 != 0);
    if (_3843 == 0) {
        goto L47; // [2232] 2551
    }
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3845 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    if (IS_SEQUENCE(_3845)){
            _3846 = SEQ_PTR(_3845)->length;
    }
    else {
        _3846 = 1;
    }
    _3845 = NOVALUE;
    _3847 = (_3846 == 2);
    _3846 = NOVALUE;
    if (_3847 == 0)
    {
        DeRef(_3847);
        _3847 = NOVALUE;
        goto L47; // [2248] 2551
    }
    else{
        DeRef(_3847);
        _3847 = NOVALUE;
    }

    /** text.e:1805								object tempv*/

    /** text.e:1806								if atom(prevargv) then*/
    _3848 = IS_ATOM(_prevargv_6646);
    if (_3848 == 0)
    {
        _3848 = NOVALUE;
        goto L48; // [2258] 2294
    }
    else{
        _3848 = NOVALUE;
    }

    /** text.e:1807									if prevargv != 1 then*/
    if (binary_op_a(EQUALS, _prevargv_6646, 1)){
        goto L49; // [2263] 2280
    }

    /** text.e:1808										tempv = arg_list[argn][1]*/
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3850 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    DeRef(_tempv_7061);
    _2 = (object)SEQ_PTR(_3850);
    _tempv_7061 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_tempv_7061);
    _3850 = NOVALUE;
    goto L4A; // [2277] 2328
L49: 

    /** text.e:1810										tempv = arg_list[argn][2]*/
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3852 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    DeRef(_tempv_7061);
    _2 = (object)SEQ_PTR(_3852);
    _tempv_7061 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tempv_7061);
    _3852 = NOVALUE;
    goto L4A; // [2291] 2328
L48: 

    /** text.e:1813									if length(prevargv) = 0 then*/
    if (IS_SEQUENCE(_prevargv_6646)){
            _3854 = SEQ_PTR(_prevargv_6646)->length;
    }
    else {
        _3854 = 1;
    }
    if (_3854 != 0)
    goto L4B; // [2299] 2316

    /** text.e:1814										tempv = arg_list[argn][1]*/
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3856 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    DeRef(_tempv_7061);
    _2 = (object)SEQ_PTR(_3856);
    _tempv_7061 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_tempv_7061);
    _3856 = NOVALUE;
    goto L4C; // [2313] 2327
L4B: 

    /** text.e:1816										tempv = arg_list[argn][2]*/
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3858 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    DeRef(_tempv_7061);
    _2 = (object)SEQ_PTR(_3858);
    _tempv_7061 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tempv_7061);
    _3858 = NOVALUE;
L4C: 
L4A: 

    /** text.e:1820								if string(tempv) then*/
    Ref(_tempv_7061);
    _3860 = _9string(_tempv_7061);
    if (_3860 == 0) {
        DeRef(_3860);
        _3860 = NOVALUE;
        goto L4D; // [2336] 2349
    }
    else {
        if (!IS_ATOM_INT(_3860) && DBL_PTR(_3860)->dbl == 0.0){
            DeRef(_3860);
            _3860 = NOVALUE;
            goto L4D; // [2336] 2349
        }
        DeRef(_3860);
        _3860 = NOVALUE;
    }
    DeRef(_3860);
    _3860 = NOVALUE;

    /** text.e:1821									argtext = tempv*/
    Ref(_tempv_7061);
    DeRef(_argtext_6816);
    _argtext_6816 = _tempv_7061;
    goto L4E; // [2346] 2546
L4D: 

    /** text.e:1822								elsif integer(tempv) then*/
    if (IS_ATOM_INT(_tempv_7061))
    _3861 = 1;
    else if (IS_ATOM_DBL(_tempv_7061))
    _3861 = IS_ATOM_INT(DoubleToInt(_tempv_7061));
    else
    _3861 = 0;
    if (_3861 == 0)
    {
        _3861 = NOVALUE;
        goto L4F; // [2354] 2420
    }
    else{
        _3861 = NOVALUE;
    }

    /** text.e:1823									if istext then*/
    if (_istext_6645 == 0)
    {
        goto L50; // [2359] 2379
    }
    else{
    }

    /** text.e:1824										argtext = {and_bits(0xFFFF_FFFF, math:abs(tempv))}*/
    Ref(_tempv_7061);
    _3862 = _21abs(_tempv_7061);
    _3863 = binary_op(AND_BITS, _390, _3862);
    DeRef(_3862);
    _3862 = NOVALUE;
    _0 = _argtext_6816;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _3863;
    _argtext_6816 = MAKE_SEQ(_1);
    DeRef(_0);
    _3863 = NOVALUE;
    goto L4E; // [2376] 2546
L50: 

    /** text.e:1826									elsif bwz != 0 and tempv = 0 then*/
    _3865 = (_bwz_6633 != 0);
    if (_3865 == 0) {
        goto L51; // [2387] 2410
    }
    if (IS_ATOM_INT(_tempv_7061)) {
        _3867 = (_tempv_7061 == 0);
    }
    else {
        _3867 = binary_op(EQUALS, _tempv_7061, 0);
    }
    if (_3867 == 0) {
        DeRef(_3867);
        _3867 = NOVALUE;
        goto L51; // [2396] 2410
    }
    else {
        if (!IS_ATOM_INT(_3867) && DBL_PTR(_3867)->dbl == 0.0){
            DeRef(_3867);
            _3867 = NOVALUE;
            goto L51; // [2396] 2410
        }
        DeRef(_3867);
        _3867 = NOVALUE;
    }
    DeRef(_3867);
    _3867 = NOVALUE;

    /** text.e:1827										argtext = repeat(' ', width)*/
    DeRef(_argtext_6816);
    _argtext_6816 = Repeat(32, _width_6636);
    goto L4E; // [2407] 2546
L51: 

    /** text.e:1829										argtext = sprintf("%d", tempv)*/
    DeRef(_argtext_6816);
    _argtext_6816 = EPrintf(-9999999, _657, _tempv_7061);
    goto L4E; // [2417] 2546
L4F: 

    /** text.e:1832								elsif atom(tempv) then*/
    _3870 = IS_ATOM(_tempv_7061);
    if (_3870 == 0)
    {
        _3870 = NOVALUE;
        goto L52; // [2425] 2502
    }
    else{
        _3870 = NOVALUE;
    }

    /** text.e:1833									if istext then*/
    if (_istext_6645 == 0)
    {
        goto L53; // [2430] 2453
    }
    else{
    }

    /** text.e:1834										argtext = {and_bits(0xFFFF_FFFF, math:abs(floor(tempv)))}*/
    if (IS_ATOM_INT(_tempv_7061))
    _3871 = e_floor(_tempv_7061);
    else
    _3871 = unary_op(FLOOR, _tempv_7061);
    _3872 = _21abs(_3871);
    _3871 = NOVALUE;
    _3873 = binary_op(AND_BITS, _390, _3872);
    DeRef(_3872);
    _3872 = NOVALUE;
    _0 = _argtext_6816;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _3873;
    _argtext_6816 = MAKE_SEQ(_1);
    DeRef(_0);
    _3873 = NOVALUE;
    goto L4E; // [2450] 2546
L53: 

    /** text.e:1835									elsif bwz != 0 and tempv = 0 then*/
    _3875 = (_bwz_6633 != 0);
    if (_3875 == 0) {
        goto L54; // [2461] 2484
    }
    if (IS_ATOM_INT(_tempv_7061)) {
        _3877 = (_tempv_7061 == 0);
    }
    else {
        _3877 = binary_op(EQUALS, _tempv_7061, 0);
    }
    if (_3877 == 0) {
        DeRef(_3877);
        _3877 = NOVALUE;
        goto L54; // [2470] 2484
    }
    else {
        if (!IS_ATOM_INT(_3877) && DBL_PTR(_3877)->dbl == 0.0){
            DeRef(_3877);
            _3877 = NOVALUE;
            goto L54; // [2470] 2484
        }
        DeRef(_3877);
        _3877 = NOVALUE;
    }
    DeRef(_3877);
    _3877 = NOVALUE;

    /** text.e:1836										argtext = repeat(' ', width)*/
    DeRef(_argtext_6816);
    _argtext_6816 = Repeat(32, _width_6636);
    goto L4E; // [2481] 2546
L54: 

    /** text.e:1838										argtext = trim(sprintf("%15.15g", tempv))*/
    _3879 = EPrintf(-9999999, _3797, _tempv_7061);
    RefDS(_3010);
    _0 = _argtext_6816;
    _argtext_6816 = _18trim(_3879, _3010, 0);
    DeRef(_0);
    _3879 = NOVALUE;
    goto L4E; // [2499] 2546
L52: 

    /** text.e:1841									argtext = pretty:pretty_sprint( tempv,*/
    _1 = NewS1(10);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 1;
    ((intptr_t*)_2)[4] = 1000;
    RefDS(_657);
    ((intptr_t*)_2)[5] = _657;
    RefDS(_3881);
    ((intptr_t*)_2)[6] = _3881;
    ((intptr_t*)_2)[7] = 32;
    ((intptr_t*)_2)[8] = 127;
    ((intptr_t*)_2)[9] = 1;
    ((intptr_t*)_2)[10] = 0;
    _3882 = MAKE_SEQ(_1);
    DeRef(_options_inlined_pretty_sprint_at_2518_7115);
    _options_inlined_pretty_sprint_at_2518_7115 = _3882;
    _3882 = NOVALUE;

    /** pretty.e:364		pretty_printing = 0*/
    _10pretty_printing_1423 = 0;

    /** pretty.e:365		pretty( x, options )*/
    Ref(_tempv_7061);
    RefDS(_options_inlined_pretty_sprint_at_2518_7115);
    _10pretty(_tempv_7061, _options_inlined_pretty_sprint_at_2518_7115);

    /** pretty.e:366		return pretty_line*/
    RefDS(_10pretty_line_1426);
    DeRef(_argtext_6816);
    _argtext_6816 = _10pretty_line_1426;
    DeRef(_options_inlined_pretty_sprint_at_2518_7115);
    _options_inlined_pretty_sprint_at_2518_7115 = NOVALUE;
L4E: 
    DeRef(_tempv_7061);
    _tempv_7061 = NOVALUE;
    goto L55; // [2548] 2627
L47: 

    /** text.e:1846								argtext = pretty:pretty_sprint( arg_list[argn],*/
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _3883 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    _1 = NewS1(10);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 1;
    ((intptr_t*)_2)[4] = 1000;
    RefDS(_657);
    ((intptr_t*)_2)[5] = _657;
    RefDS(_3881);
    ((intptr_t*)_2)[6] = _3881;
    ((intptr_t*)_2)[7] = 32;
    ((intptr_t*)_2)[8] = 127;
    ((intptr_t*)_2)[9] = 1;
    ((intptr_t*)_2)[10] = 0;
    _3884 = MAKE_SEQ(_1);
    Ref(_3883);
    DeRef(_x_inlined_pretty_sprint_at_2571_7121);
    _x_inlined_pretty_sprint_at_2571_7121 = _3883;
    _3883 = NOVALUE;
    DeRef(_options_inlined_pretty_sprint_at_2574_7122);
    _options_inlined_pretty_sprint_at_2574_7122 = _3884;
    _3884 = NOVALUE;

    /** pretty.e:364		pretty_printing = 0*/
    _10pretty_printing_1423 = 0;

    /** pretty.e:365		pretty( x, options )*/
    Ref(_x_inlined_pretty_sprint_at_2571_7121);
    RefDS(_options_inlined_pretty_sprint_at_2574_7122);
    _10pretty(_x_inlined_pretty_sprint_at_2571_7121, _options_inlined_pretty_sprint_at_2574_7122);

    /** pretty.e:366		return pretty_line*/
    RefDS(_10pretty_line_1426);
    DeRef(_argtext_6816);
    _argtext_6816 = _10pretty_line_1426;
    DeRef(_x_inlined_pretty_sprint_at_2571_7121);
    _x_inlined_pretty_sprint_at_2571_7121 = NOVALUE;
    DeRef(_options_inlined_pretty_sprint_at_2574_7122);
    _options_inlined_pretty_sprint_at_2574_7122 = NOVALUE;

    /** text.e:1851							while ep != 0 with entry do*/
    goto L55; // [2604] 2627
L56: 
    if (_ep_6651 == 0)
    goto L57; // [2609] 2639

    /** text.e:1852								argtext = remove(argtext, ep+2)*/
    _3886 = _ep_6651 + 2;
    if ((object)((uintptr_t)_3886 + (uintptr_t)HIGH_BITS) >= 0){
        _3886 = NewDouble((eudouble)_3886);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_argtext_6816);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_3886)) ? _3886 : (object)(DBL_PTR(_3886)->dbl);
        int stop = (IS_ATOM_INT(_3886)) ? _3886 : (object)(DBL_PTR(_3886)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_argtext_6816), start, &_argtext_6816 );
            }
            else Tail(SEQ_PTR(_argtext_6816), stop+1, &_argtext_6816);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_argtext_6816), start, &_argtext_6816);
        }
        else {
            assign_slice_seq = &assign_space;
            _argtext_6816 = Remove_elements(start, stop, (SEQ_PTR(_argtext_6816)->ref == 1));
        }
    }
    DeRef(_3886);
    _3886 = NOVALUE;
    _3886 = NOVALUE;

    /** text.e:1853							entry*/
L55: 

    /** text.e:1854								ep = match("e+0", argtext)*/
    _ep_6651 = e_match_from(_3804, _argtext_6816, 1);

    /** text.e:1855							end while*/
    goto L56; // [2636] 2607
L57: 
L27: 

    /** text.e:1857		    			currargv = arg_list[argn]*/
    DeRef(_currargv_6647);
    _2 = (object)SEQ_PTR(_arg_list_6622);
    _currargv_6647 = (object)*(((s1_ptr)_2)->base + _argn_6639);
    Ref(_currargv_6647);
L24: 

    /** text.e:1861	    			if length(argtext) > 0 then*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3890 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3890 = 1;
    }
    if (_3890 <= 0)
    goto L58; // [2652] 3562

    /** text.e:1862	    				switch cap do*/
    _0 = _cap_6628;
    switch ( _0 ){ 

        /** text.e:1863	    					case 'u' then*/
        case 117:

        /** text.e:1864	    						argtext = upper(argtext)*/
        RefDS(_argtext_6816);
        _0 = _argtext_6816;
        _argtext_6816 = _18upper(_argtext_6816);
        DeRefDS(_0);
        goto L59; // [2677] 2743

        /** text.e:1865	    					case 'l' then*/
        case 108:

        /** text.e:1866	    						argtext = lower(argtext)*/
        RefDS(_argtext_6816);
        _0 = _argtext_6816;
        _argtext_6816 = _18lower(_argtext_6816);
        DeRefDS(_0);
        goto L59; // [2691] 2743

        /** text.e:1867	    					case 'w' then*/
        case 119:

        /** text.e:1868	    						argtext = proper(argtext)*/
        RefDS(_argtext_6816);
        _0 = _argtext_6816;
        _argtext_6816 = _18proper(_argtext_6816);
        DeRefDS(_0);
        goto L59; // [2705] 2743

        /** text.e:1869	    					case 0 then*/
        case 0:

        /** text.e:1871								cap = cap*/
        _cap_6628 = _cap_6628;
        goto L59; // [2716] 2743

        /** text.e:1873	    					case else*/
        default:

        /** text.e:1874	    						error:crash("logic error: 'cap' mode in format.")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_2725_7145);
        _msg_inlined_crash_at_2725_7145 = EPrintf(-9999999, _3897, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_2725_7145);

        /** error.e:53	end procedure*/
        goto L5A; // [2737] 2740
L5A: 
        DeRefi(_msg_inlined_crash_at_2725_7145);
        _msg_inlined_crash_at_2725_7145 = NOVALUE;
    ;}L59: 

    /** text.e:1878						if atom(currargv) then*/
    _3898 = IS_ATOM(_currargv_6647);
    if (_3898 == 0)
    {
        _3898 = NOVALUE;
        goto L5B; // [2750] 2993
    }
    else{
        _3898 = NOVALUE;
    }

    /** text.e:1879							if find('e', argtext) = 0 then*/
    _3899 = find_from(101, _argtext_6816, 1);
    if (_3899 != 0)
    goto L5C; // [2760] 2992

    /** text.e:1881								pflag = 0*/
    _pflag_6652 = 0;

    /** text.e:1882								if msign and currargv < 0 then*/
    if (_msign_6631 == 0) {
        goto L5D; // [2773] 2791
    }
    if (IS_ATOM_INT(_currargv_6647)) {
        _3902 = (_currargv_6647 < 0);
    }
    else {
        _3902 = binary_op(LESS, _currargv_6647, 0);
    }
    if (_3902 == 0) {
        DeRef(_3902);
        _3902 = NOVALUE;
        goto L5D; // [2782] 2791
    }
    else {
        if (!IS_ATOM_INT(_3902) && DBL_PTR(_3902)->dbl == 0.0){
            DeRef(_3902);
            _3902 = NOVALUE;
            goto L5D; // [2782] 2791
        }
        DeRef(_3902);
        _3902 = NOVALUE;
    }
    DeRef(_3902);
    _3902 = NOVALUE;

    /** text.e:1883									pflag = 1*/
    _pflag_6652 = 1;
L5D: 

    /** text.e:1885								if decs != -1 then*/
    if (_decs_6637 == -1)
    goto L5E; // [2795] 2991

    /** text.e:1886									pos = find('.', argtext)*/
    _pos_6638 = find_from(46, _argtext_6816, 1);

    /** text.e:1887									if pos then*/
    if (_pos_6638 == 0)
    {
        goto L5F; // [2808] 2936
    }
    else{
    }

    /** text.e:1888										if decs = 0 then*/
    if (_decs_6637 != 0)
    goto L60; // [2813] 2831

    /** text.e:1889											argtext = argtext [1 .. pos-1 ]*/
    _3906 = _pos_6638 - 1;
    rhs_slice_target = (object_ptr)&_argtext_6816;
    RHS_Slice(_argtext_6816, 1, _3906);
    goto L61; // [2828] 2990
L60: 

    /** text.e:1891											pos = length(argtext) - pos - pflag*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3908 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3908 = 1;
    }
    _3909 = _3908 - _pos_6638;
    if ((object)((uintptr_t)_3909 +(uintptr_t) HIGH_BITS) >= 0){
        _3909 = NewDouble((eudouble)_3909);
    }
    _3908 = NOVALUE;
    if (IS_ATOM_INT(_3909)) {
        _pos_6638 = _3909 - _pflag_6652;
    }
    else {
        _pos_6638 = NewDouble(DBL_PTR(_3909)->dbl - (eudouble)_pflag_6652);
    }
    DeRef(_3909);
    _3909 = NOVALUE;
    if (!IS_ATOM_INT(_pos_6638)) {
        _1 = (object)(DBL_PTR(_pos_6638)->dbl);
        DeRefDS(_pos_6638);
        _pos_6638 = _1;
    }

    /** text.e:1892											if pos > decs then*/
    if (_pos_6638 <= _decs_6637)
    goto L62; // [2848] 2873

    /** text.e:1893												argtext = argtext[ 1 .. $ - pos + decs ]*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3912 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3912 = 1;
    }
    _3913 = _3912 - _pos_6638;
    if ((object)((uintptr_t)_3913 +(uintptr_t) HIGH_BITS) >= 0){
        _3913 = NewDouble((eudouble)_3913);
    }
    _3912 = NOVALUE;
    if (IS_ATOM_INT(_3913)) {
        _3914 = _3913 + _decs_6637;
    }
    else {
        _3914 = NewDouble(DBL_PTR(_3913)->dbl + (eudouble)_decs_6637);
    }
    DeRef(_3913);
    _3913 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_6816;
    RHS_Slice(_argtext_6816, 1, _3914);
    goto L61; // [2870] 2990
L62: 

    /** text.e:1894											elsif pos < decs then*/
    if (_pos_6638 >= _decs_6637)
    goto L61; // [2875] 2990

    /** text.e:1895												if pflag then*/
    if (_pflag_6652 == 0)
    {
        goto L63; // [2881] 2915
    }
    else{
    }

    /** text.e:1896													argtext = argtext[ 1 .. $ - 1 ] & repeat('0', decs - pos) & ')'*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3917 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3917 = 1;
    }
    _3918 = _3917 - 1;
    _3917 = NOVALUE;
    rhs_slice_target = (object_ptr)&_3919;
    RHS_Slice(_argtext_6816, 1, _3918);
    _3920 = _decs_6637 - _pos_6638;
    _3921 = Repeat(48, _3920);
    _3920 = NOVALUE;
    {
        object concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _3921;
        concat_list[2] = _3919;
        Concat_N((object_ptr)&_argtext_6816, concat_list, 3);
    }
    DeRefDS(_3921);
    _3921 = NOVALUE;
    DeRefDS(_3919);
    _3919 = NOVALUE;
    goto L61; // [2912] 2990
L63: 

    /** text.e:1898													argtext = argtext & repeat('0', decs - pos)*/
    _3923 = _decs_6637 - _pos_6638;
    _3924 = Repeat(48, _3923);
    _3923 = NOVALUE;
    Concat((object_ptr)&_argtext_6816, _argtext_6816, _3924);
    DeRefDS(_3924);
    _3924 = NOVALUE;
    goto L61; // [2933] 2990
L5F: 

    /** text.e:1902									elsif decs > 0 then*/
    if (_decs_6637 <= 0)
    goto L64; // [2938] 2989

    /** text.e:1903										if pflag then*/
    if (_pflag_6652 == 0)
    {
        goto L65; // [2944] 2975
    }
    else{
    }

    /** text.e:1904											argtext = argtext[1 .. $ - 1] & '.' & repeat('0', decs) & ')'*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3927 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3927 = 1;
    }
    _3928 = _3927 - 1;
    _3927 = NOVALUE;
    rhs_slice_target = (object_ptr)&_3929;
    RHS_Slice(_argtext_6816, 1, _3928);
    _3930 = Repeat(48, _decs_6637);
    {
        object concat_list[4];

        concat_list[0] = 41;
        concat_list[1] = _3930;
        concat_list[2] = 46;
        concat_list[3] = _3929;
        Concat_N((object_ptr)&_argtext_6816, concat_list, 4);
    }
    DeRefDS(_3930);
    _3930 = NOVALUE;
    DeRefDS(_3929);
    _3929 = NOVALUE;
    goto L66; // [2972] 2988
L65: 

    /** text.e:1906											argtext = argtext & '.' & repeat('0', decs)*/
    _3932 = Repeat(48, _decs_6637);
    {
        object concat_list[3];

        concat_list[0] = _3932;
        concat_list[1] = 46;
        concat_list[2] = _argtext_6816;
        Concat_N((object_ptr)&_argtext_6816, concat_list, 3);
    }
    DeRefDS(_3932);
    _3932 = NOVALUE;
L66: 
L64: 
L61: 
L5E: 
L5C: 
L5B: 

    /** text.e:1914	    				if align = 0 then*/
    if (_align_6629 != 0)
    goto L67; // [2997] 3024

    /** text.e:1915	    					if atom(currargv) then*/
    _3935 = IS_ATOM(_currargv_6647);
    if (_3935 == 0)
    {
        _3935 = NOVALUE;
        goto L68; // [3006] 3017
    }
    else{
        _3935 = NOVALUE;
    }

    /** text.e:1916	    						align = '>'*/
    _align_6629 = 62;
    goto L69; // [3014] 3023
L68: 

    /** text.e:1918	    						align = '<'*/
    _align_6629 = 60;
L69: 
L67: 

    /** text.e:1922	    				if atom(currargv) then*/
    _3936 = IS_ATOM(_currargv_6647);
    if (_3936 == 0)
    {
        _3936 = NOVALUE;
        goto L6A; // [3029] 3266
    }
    else{
        _3936 = NOVALUE;
    }

    /** text.e:1923		    				if tsep != 0 and zfill = 0 then*/
    _3937 = (_tsep_6644 != 0);
    if (_3937 == 0) {
        goto L6B; // [3040] 3263
    }
    _3939 = (_zfill_6632 == 0);
    if (_3939 == 0)
    {
        DeRef(_3939);
        _3939 = NOVALUE;
        goto L6B; // [3051] 3263
    }
    else{
        DeRef(_3939);
        _3939 = NOVALUE;
    }

    /** text.e:1924		    					integer dpos*/

    /** text.e:1925		    					integer dist*/

    /** text.e:1926		    					integer bracketed*/

    /** text.e:1928		    					if binout or hexout then*/
    if (_binout_6643 != 0) {
        goto L6C; // [3064] 3073
    }
    if (_hexout_6642 == 0)
    {
        goto L6D; // [3069] 3086
    }
    else{
    }
L6C: 

    /** text.e:1929		    						dist = 4*/
    _dist_7208 = 4;

    /** text.e:1930								psign = 0*/
    _psign_6630 = 0;
    goto L6E; // [3083] 3092
L6D: 

    /** text.e:1932		    						dist = 3*/
    _dist_7208 = 3;
L6E: 

    /** text.e:1934		    					bracketed = (argtext[1] = '(')*/
    _2 = (object)SEQ_PTR(_argtext_6816);
    _3941 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_3941)) {
        _bracketed_7209 = (_3941 == 40);
    }
    else {
        _bracketed_7209 = binary_op(EQUALS, _3941, 40);
    }
    _3941 = NOVALUE;
    if (!IS_ATOM_INT(_bracketed_7209)) {
        _1 = (object)(DBL_PTR(_bracketed_7209)->dbl);
        DeRefDS(_bracketed_7209);
        _bracketed_7209 = _1;
    }

    /** text.e:1935		    					if bracketed then*/
    if (_bracketed_7209 == 0)
    {
        goto L6F; // [3106] 3124
    }
    else{
    }

    /** text.e:1936		    						argtext = argtext[2 .. $-1]*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3943 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3943 = 1;
    }
    _3944 = _3943 - 1;
    _3943 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_6816;
    RHS_Slice(_argtext_6816, 2, _3944);
L6F: 

    /** text.e:1938		    					dpos = find('.', argtext)*/
    _dpos_7207 = find_from(46, _argtext_6816, 1);

    /** text.e:1939		    					if dpos = 0 then*/
    if (_dpos_7207 != 0)
    goto L70; // [3133] 3149

    /** text.e:1940		    						dpos = length(argtext) + 1*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3948 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3948 = 1;
    }
    _dpos_7207 = _3948 + 1;
    _3948 = NOVALUE;
    goto L71; // [3146] 3163
L70: 

    /** text.e:1942		    						if tsep = '.' then*/
    if (_tsep_6644 != 46)
    goto L72; // [3151] 3162

    /** text.e:1943		    							argtext[dpos] = ','*/
    _2 = (object)SEQ_PTR(_argtext_6816);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _argtext_6816 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _dpos_7207);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 44;
    DeRef(_1);
L72: 
L71: 

    /** text.e:1946		    					while dpos > dist do*/
L73: 
    if (_dpos_7207 <= _dist_7208)
    goto L74; // [3170] 3248

    /** text.e:1947		    						dpos -= dist*/
    _dpos_7207 = _dpos_7207 - _dist_7208;

    /** text.e:1948		    						if dpos > 1 + (currargv < 0) * not msign + (currargv > 0) * psign then*/
    if (IS_ATOM_INT(_currargv_6647)) {
        _3953 = (_currargv_6647 < 0);
    }
    else {
        _3953 = binary_op(LESS, _currargv_6647, 0);
    }
    _3954 = (_msign_6631 == 0);
    if (IS_ATOM_INT(_3953)) {
        if (_3953 == (short)_3953 && _3954 <= INT15 && _3954 >= -INT15){
            _3955 = _3953 * _3954;
        }
        else{
            _3955 = NewDouble(_3953 * (eudouble)_3954);
        }
    }
    else {
        _3955 = binary_op(MULTIPLY, _3953, _3954);
    }
    DeRef(_3953);
    _3953 = NOVALUE;
    _3954 = NOVALUE;
    if (IS_ATOM_INT(_3955)) {
        _3956 = _3955 + 1;
        if (_3956 > MAXINT){
            _3956 = NewDouble((eudouble)_3956);
        }
    }
    else
    _3956 = binary_op(PLUS, 1, _3955);
    DeRef(_3955);
    _3955 = NOVALUE;
    if (IS_ATOM_INT(_currargv_6647)) {
        _3957 = (_currargv_6647 > 0);
    }
    else {
        _3957 = binary_op(GREATER, _currargv_6647, 0);
    }
    if (IS_ATOM_INT(_3957)) {
        if (_3957 == (short)_3957 && _psign_6630 <= INT15 && _psign_6630 >= -INT15){
            _3958 = _3957 * _psign_6630;
        }
        else{
            _3958 = NewDouble(_3957 * (eudouble)_psign_6630);
        }
    }
    else {
        _3958 = binary_op(MULTIPLY, _3957, _psign_6630);
    }
    DeRef(_3957);
    _3957 = NOVALUE;
    if (IS_ATOM_INT(_3956) && IS_ATOM_INT(_3958)) {
        _3959 = _3956 + _3958;
        if ((object)((uintptr_t)_3959 + (uintptr_t)HIGH_BITS) >= 0){
            _3959 = NewDouble((eudouble)_3959);
        }
    }
    else {
        _3959 = binary_op(PLUS, _3956, _3958);
    }
    DeRef(_3956);
    _3956 = NOVALUE;
    DeRef(_3958);
    _3958 = NOVALUE;
    if (binary_op_a(LESSEQ, _dpos_7207, _3959)){
        DeRef(_3959);
        _3959 = NOVALUE;
        goto L73; // [3213] 3168
    }
    DeRef(_3959);
    _3959 = NOVALUE;

    /** text.e:1949		    							argtext = argtext[1.. dpos - 1] & tsep & argtext[dpos .. $]*/
    _3961 = _dpos_7207 - 1;
    rhs_slice_target = (object_ptr)&_3962;
    RHS_Slice(_argtext_6816, 1, _3961);
    if (IS_SEQUENCE(_argtext_6816)){
            _3963 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3963 = 1;
    }
    rhs_slice_target = (object_ptr)&_3964;
    RHS_Slice(_argtext_6816, _dpos_7207, _3963);
    {
        object concat_list[3];

        concat_list[0] = _3964;
        concat_list[1] = _tsep_6644;
        concat_list[2] = _3962;
        Concat_N((object_ptr)&_argtext_6816, concat_list, 3);
    }
    DeRefDS(_3964);
    _3964 = NOVALUE;
    DeRefDS(_3962);
    _3962 = NOVALUE;

    /** text.e:1951		    					end while*/
    goto L73; // [3245] 3168
L74: 

    /** text.e:1952		    					if bracketed then*/
    if (_bracketed_7209 == 0)
    {
        goto L75; // [3250] 3262
    }
    else{
    }

    /** text.e:1953		    						argtext = '(' & argtext & ')'*/
    {
        object concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _argtext_6816;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_6816, concat_list, 3);
    }
L75: 
L6B: 
L6A: 

    /** text.e:1958	    				if width <= 0 then*/
    if (_width_6636 > 0)
    goto L76; // [3270] 3280

    /** text.e:1959	    					width = length(argtext)*/
    if (IS_SEQUENCE(_argtext_6816)){
            _width_6636 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _width_6636 = 1;
    }
L76: 

    /** text.e:1963	    				if width < length(argtext) then*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3969 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3969 = 1;
    }
    if (_width_6636 >= _3969)
    goto L77; // [3285] 3416

    /** text.e:1964	    					if align = '>' then*/
    if (_align_6629 != 62)
    goto L78; // [3291] 3319

    /** text.e:1965	    						argtext = argtext[ $ - width + 1 .. $]*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3972 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3972 = 1;
    }
    _3973 = _3972 - _width_6636;
    if ((object)((uintptr_t)_3973 +(uintptr_t) HIGH_BITS) >= 0){
        _3973 = NewDouble((eudouble)_3973);
    }
    _3972 = NOVALUE;
    if (IS_ATOM_INT(_3973)) {
        _3974 = _3973 + 1;
        if (_3974 > MAXINT){
            _3974 = NewDouble((eudouble)_3974);
        }
    }
    else
    _3974 = binary_op(PLUS, 1, _3973);
    DeRef(_3973);
    _3973 = NOVALUE;
    if (IS_SEQUENCE(_argtext_6816)){
            _3975 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3975 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_6816;
    RHS_Slice(_argtext_6816, _3974, _3975);
    goto L79; // [3316] 3553
L78: 

    /** text.e:1966	    					elsif align = 'c' then*/
    if (_align_6629 != 99)
    goto L7A; // [3321] 3405

    /** text.e:1967	    						pos = length(argtext) - width*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3978 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3978 = 1;
    }
    _pos_6638 = _3978 - _width_6636;
    _3978 = NOVALUE;

    /** text.e:1968	    						if remainder(pos, 2) = 0 then*/
    _3980 = (_pos_6638 % 2);
    if (_3980 != 0)
    goto L7B; // [3340] 3373

    /** text.e:1969	    							pos = pos / 2*/
    if (_pos_6638 & 1) {
        _pos_6638 = NewDouble((_pos_6638 >> 1) + 0.5);
    }
    else
    _pos_6638 = _pos_6638 >> 1;
    if (!IS_ATOM_INT(_pos_6638)) {
        _1 = (object)(DBL_PTR(_pos_6638)->dbl);
        DeRefDS(_pos_6638);
        _pos_6638 = _1;
    }

    /** text.e:1970	    							argtext = argtext[ pos + 1 .. $ - pos ]*/
    _3983 = _pos_6638 + 1;
    if (_3983 > MAXINT){
        _3983 = NewDouble((eudouble)_3983);
    }
    if (IS_SEQUENCE(_argtext_6816)){
            _3984 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3984 = 1;
    }
    _3985 = _3984 - _pos_6638;
    _3984 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_6816;
    RHS_Slice(_argtext_6816, _3983, _3985);
    goto L79; // [3370] 3553
L7B: 

    /** text.e:1972	    							pos = floor(pos / 2)*/
    _pos_6638 = _pos_6638 >> 1;

    /** text.e:1973	    							argtext = argtext[ pos + 1 .. $ - pos - 1]*/
    _3988 = _pos_6638 + 1;
    if (_3988 > MAXINT){
        _3988 = NewDouble((eudouble)_3988);
    }
    if (IS_SEQUENCE(_argtext_6816)){
            _3989 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3989 = 1;
    }
    _3990 = _3989 - _pos_6638;
    if ((object)((uintptr_t)_3990 +(uintptr_t) HIGH_BITS) >= 0){
        _3990 = NewDouble((eudouble)_3990);
    }
    _3989 = NOVALUE;
    if (IS_ATOM_INT(_3990)) {
        _3991 = _3990 - 1;
    }
    else {
        _3991 = NewDouble(DBL_PTR(_3990)->dbl - (eudouble)1);
    }
    DeRef(_3990);
    _3990 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_6816;
    RHS_Slice(_argtext_6816, _3988, _3991);
    goto L79; // [3402] 3553
L7A: 

    /** text.e:1976	    						argtext = argtext[ 1 .. width]*/
    rhs_slice_target = (object_ptr)&_argtext_6816;
    RHS_Slice(_argtext_6816, 1, _width_6636);
    goto L79; // [3413] 3553
L77: 

    /** text.e:1978	    				elsif width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3994 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3994 = 1;
    }
    if (_width_6636 <= _3994)
    goto L7C; // [3421] 3552

    /** text.e:1979							if align = '>' then*/
    if (_align_6629 != 62)
    goto L7D; // [3427] 3451

    /** text.e:1980								argtext = repeat(' ', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_6816)){
            _3997 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _3997 = 1;
    }
    _3998 = _width_6636 - _3997;
    _3997 = NOVALUE;
    _3999 = Repeat(32, _3998);
    _3998 = NOVALUE;
    Concat((object_ptr)&_argtext_6816, _3999, _argtext_6816);
    DeRefDS(_3999);
    _3999 = NOVALUE;
    DeRef(_3999);
    _3999 = NOVALUE;
    goto L7E; // [3448] 3551
L7D: 

    /** text.e:1981	    					elsif align = 'c' then*/
    if (_align_6629 != 99)
    goto L7F; // [3453] 3533

    /** text.e:1982	    						pos = width - length(argtext)*/
    if (IS_SEQUENCE(_argtext_6816)){
            _4002 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _4002 = 1;
    }
    _pos_6638 = _width_6636 - _4002;
    _4002 = NOVALUE;

    /** text.e:1983	    						if remainder(pos, 2) = 0 then*/
    _4004 = (_pos_6638 % 2);
    if (_4004 != 0)
    goto L80; // [3472] 3503

    /** text.e:1984	    							pos = pos / 2*/
    if (_pos_6638 & 1) {
        _pos_6638 = NewDouble((_pos_6638 >> 1) + 0.5);
    }
    else
    _pos_6638 = _pos_6638 >> 1;
    if (!IS_ATOM_INT(_pos_6638)) {
        _1 = (object)(DBL_PTR(_pos_6638)->dbl);
        DeRefDS(_pos_6638);
        _pos_6638 = _1;
    }

    /** text.e:1985	    							argtext = repeat(' ', pos) & argtext & repeat(' ', pos)*/
    _4007 = Repeat(32, _pos_6638);
    _4008 = Repeat(32, _pos_6638);
    {
        object concat_list[3];

        concat_list[0] = _4008;
        concat_list[1] = _argtext_6816;
        concat_list[2] = _4007;
        Concat_N((object_ptr)&_argtext_6816, concat_list, 3);
    }
    DeRefDS(_4008);
    _4008 = NOVALUE;
    DeRefDS(_4007);
    _4007 = NOVALUE;
    goto L7E; // [3500] 3551
L80: 

    /** text.e:1987	    							pos = floor(pos / 2)*/
    _pos_6638 = _pos_6638 >> 1;

    /** text.e:1988	    							argtext = repeat(' ', pos) & argtext & repeat(' ', pos + 1)*/
    _4011 = Repeat(32, _pos_6638);
    _4012 = _pos_6638 + 1;
    _4013 = Repeat(32, _4012);
    _4012 = NOVALUE;
    {
        object concat_list[3];

        concat_list[0] = _4013;
        concat_list[1] = _argtext_6816;
        concat_list[2] = _4011;
        Concat_N((object_ptr)&_argtext_6816, concat_list, 3);
    }
    DeRefDS(_4013);
    _4013 = NOVALUE;
    DeRefDS(_4011);
    _4011 = NOVALUE;
    goto L7E; // [3530] 3551
L7F: 

    /** text.e:1992								argtext = argtext & repeat(' ', width - length(argtext))*/
    if (IS_SEQUENCE(_argtext_6816)){
            _4015 = SEQ_PTR(_argtext_6816)->length;
    }
    else {
        _4015 = 1;
    }
    _4016 = _width_6636 - _4015;
    _4015 = NOVALUE;
    _4017 = Repeat(32, _4016);
    _4016 = NOVALUE;
    Concat((object_ptr)&_argtext_6816, _argtext_6816, _4017);
    DeRefDS(_4017);
    _4017 = NOVALUE;
L7E: 
L7C: 
L79: 

    /** text.e:1995	    				result &= argtext*/
    Concat((object_ptr)&_result_6623, _result_6623, _argtext_6816);
    goto L81; // [3559] 3575
L58: 

    /** text.e:1998	    				if spacer then*/
    if (_spacer_6634 == 0)
    {
        goto L82; // [3564] 3574
    }
    else{
    }

    /** text.e:1999	    					result &= ' '*/
    Append(&_result_6623, _result_6623, 32);
L82: 
L81: 

    /** text.e:2003	   				if trimming then*/
    if (_trimming_6641 == 0)
    {
        goto L83; // [3579] 3593
    }
    else{
    }

    /** text.e:2004	   					result = trim(result)*/
    RefDS(_result_6623);
    RefDS(_3010);
    _0 = _result_6623;
    _result_6623 = _18trim(_result_6623, _3010, 0);
    DeRefDS(_0);
L83: 

    /** text.e:2007	    			tend = 0*/
    _tend_6627 = 0;

    /** text.e:2008			    	prevargv = currargv*/
    Ref(_currargv_6647);
    DeRef(_prevargv_6646);
    _prevargv_6646 = _currargv_6647;
L1F: 
    DeRef(_argtext_6816);
    _argtext_6816 = NOVALUE;

    /** text.e:2011	    end while*/
    goto L2; // [3611] 60
L3: 

    /** text.e:2013		return result*/
    DeRefDS(_format_pattern_6621);
    DeRef(_arg_list_6622);
    DeRef(_prevargv_6646);
    DeRef(_currargv_6647);
    DeRef(_idname_6648);
    DeRef(_envsym_6649);
    DeRefi(_envvar_6650);
    DeRef(_3961);
    _3961 = NOVALUE;
    DeRef(_3707);
    _3707 = NOVALUE;
    DeRef(_3615);
    _3615 = NOVALUE;
    _3845 = NOVALUE;
    DeRef(_3980);
    _3980 = NOVALUE;
    DeRef(_3918);
    _3918 = NOVALUE;
    DeRef(_3806);
    _3806 = NOVALUE;
    DeRef(_3865);
    _3865 = NOVALUE;
    DeRef(_3937);
    _3937 = NOVALUE;
    DeRef(_3697);
    _3697 = NOVALUE;
    DeRef(_3717);
    _3717 = NOVALUE;
    DeRef(_3639);
    _3639 = NOVALUE;
    DeRef(_3983);
    _3983 = NOVALUE;
    DeRef(_3770);
    _3770 = NOVALUE;
    DeRef(_3843);
    _3843 = NOVALUE;
    DeRef(_3687);
    _3687 = NOVALUE;
    DeRef(_3666);
    _3666 = NOVALUE;
    DeRef(_3988);
    _3988 = NOVALUE;
    DeRef(_3678);
    _3678 = NOVALUE;
    DeRef(_3914);
    _3914 = NOVALUE;
    DeRef(_3991);
    _3991 = NOVALUE;
    DeRef(_3906);
    _3906 = NOVALUE;
    DeRef(_3928);
    _3928 = NOVALUE;
    DeRef(_4004);
    _4004 = NOVALUE;
    DeRef(_3788);
    _3788 = NOVALUE;
    DeRef(_3944);
    _3944 = NOVALUE;
    DeRef(_3727);
    _3727 = NOVALUE;
    DeRef(_3875);
    _3875 = NOVALUE;
    DeRef(_3985);
    _3985 = NOVALUE;
    DeRef(_3974);
    _3974 = NOVALUE;
    return _result_6623;
    ;
}



// 0xC1E1CD9B
