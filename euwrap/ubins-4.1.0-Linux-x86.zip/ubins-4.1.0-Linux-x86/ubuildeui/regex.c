// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _51regex(object _o_22155)
{
    object _12523 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:609		return sequence(o)*/
    _12523 = IS_SEQUENCE(_o_22155);
    DeRef(_o_22155);
    return _12523;
    ;
}


object _51new(object _pattern_22196, object _options_22197)
{
    object _12544 = NOVALUE;
    object _12543 = NOVALUE;
    object _12541 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:723		if sequence(options) then */
    _12541 = 0;
    if (_12541 == 0)
    {
        _12541 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _12541 = NOVALUE;
    }

    /** regex.e:724			options = math:or_all(options) */
    _options_22197 = _21or_all(_options_22197);
L1: 

    /** regex.e:730		return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_options_22197);
    Ref(_pattern_22196);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _pattern_22196;
    ((intptr_t *)_2)[2] = _options_22197;
    _12543 = MAKE_SEQ(_1);
    _12544 = machine(68, _12543);
    DeRefDS(_12543);
    _12543 = NOVALUE;
    DeRef(_pattern_22196);
    DeRef(_options_22197);
    return _12544;
    ;
}


object _51get_ovector_size(object _ex_22216, object _maxsize_22217)
{
    object _m_22218 = NOVALUE;
    object _12552 = NOVALUE;
    object _12549 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:804		integer m = machine_func(M_PCRE_GET_OVECTOR_SIZE, {ex})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_ex_22216);
    ((intptr_t*)_2)[1] = _ex_22216;
    _12549 = MAKE_SEQ(_1);
    _m_22218 = machine(97, _12549);
    DeRefDS(_12549);
    _12549 = NOVALUE;
    if (!IS_ATOM_INT(_m_22218)) {
        _1 = (object)(DBL_PTR(_m_22218)->dbl);
        DeRefDS(_m_22218);
        _m_22218 = _1;
    }

    /** regex.e:805		if (m > maxsize) then*/
    if (_m_22218 <= 30)
    goto L1; // [17] 28

    /** regex.e:806			return maxsize*/
    DeRef(_ex_22216);
    return 30;
L1: 

    /** regex.e:809		return m+1*/
    _12552 = _m_22218 + 1;
    if (_12552 > MAXINT){
        _12552 = NewDouble((eudouble)_12552);
    }
    DeRef(_ex_22216);
    return _12552;
    ;
}


object _51find(object _re_22226, object _haystack_22228, object _from_22229, object _options_22230, object _size_22231)
{
    object _12559 = NOVALUE;
    object _12558 = NOVALUE;
    object _12557 = NOVALUE;
    object _12554 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_22231)) {
        _1 = (object)(DBL_PTR(_size_22231)->dbl);
        DeRefDS(_size_22231);
        _size_22231 = _1;
    }

    /** regex.e:872		if sequence(options) then */
    _12554 = 0;
    if (_12554 == 0)
    {
        _12554 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12554 = NOVALUE;
    }

    /** regex.e:873			options = math:or_all(options) */
    _options_22230 = _21or_all(0);
L1: 

    /** regex.e:876		if size < 0 then*/
    if (_size_22231 >= 0)
    goto L2; // [22] 32

    /** regex.e:877			size = 0*/
    _size_22231 = 0;
L2: 

    /** regex.e:880		return machine_func(M_PCRE_EXEC, { re, haystack, length(haystack), options, from, size })*/
    if (IS_SEQUENCE(_haystack_22228)){
            _12557 = SEQ_PTR(_haystack_22228)->length;
    }
    else {
        _12557 = 1;
    }
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_re_22226);
    ((intptr_t*)_2)[1] = _re_22226;
    Ref(_haystack_22228);
    ((intptr_t*)_2)[2] = _haystack_22228;
    ((intptr_t*)_2)[3] = _12557;
    Ref(_options_22230);
    ((intptr_t*)_2)[4] = _options_22230;
    ((intptr_t*)_2)[5] = _from_22229;
    ((intptr_t*)_2)[6] = _size_22231;
    _12558 = MAKE_SEQ(_1);
    _12557 = NOVALUE;
    _12559 = machine(70, _12558);
    DeRefDS(_12558);
    _12558 = NOVALUE;
    DeRef(_re_22226);
    DeRef(_haystack_22228);
    DeRef(_options_22230);
    return _12559;
    ;
}


object _51has_match(object _re_22272, object _haystack_22274, object _from_22275, object _options_22276)
{
    object _12576 = NOVALUE;
    object _12575 = NOVALUE;
    object _12574 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:961		return sequence(find(re, haystack, from, options))*/
    Ref(_re_22272);
    _12574 = _51get_ovector_size(_re_22272, 30);
    Ref(_re_22272);
    Ref(_haystack_22274);
    _12575 = _51find(_re_22272, _haystack_22274, 1, 0, _12574);
    _12574 = NOVALUE;
    _12576 = IS_SEQUENCE(_12575);
    DeRef(_12575);
    _12575 = NOVALUE;
    DeRef(_re_22272);
    DeRef(_haystack_22274);
    return _12576;
    ;
}



// 0x3D19024D
