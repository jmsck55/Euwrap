// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _54c_putc(object _c_46660)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_46660)) {
        _1 = (object)(DBL_PTR(_c_46660)->dbl);
        DeRefDS(_c_46660);
        _c_46660 = _1;
    }

    /** c_out.e:62		if emit_c_output then*/
    if (_54emit_c_output_46647 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** c_out.e:63			puts(c_code, c)*/
    EPuts(_54c_code_46650, _c_46660); // DJP 

    /** c_out.e:64			update_checksum( c )*/
    _55update_checksum(_c_46660);
L1: 

    /** c_out.e:66	end procedure*/
    return;
    ;
}


void _54c_hputs(object _c_source_46665)
{
    object _0, _1, _2;
    

    /** c_out.e:71		if emit_c_output then*/
    if (_54emit_c_output_46647 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** c_out.e:72			puts(c_h, c_source)    */
    EPuts(_54c_h_46651, _c_source_46665); // DJP 
L1: 

    /** c_out.e:74	end procedure*/
    DeRefDS(_c_source_46665);
    return;
    ;
}


void _54c_puts(object _c_source_46669)
{
    object _0, _1, _2;
    

    /** c_out.e:79		if emit_c_output then*/
    if (_54emit_c_output_46647 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** c_out.e:80			puts(c_code, c_source)*/
    EPuts(_54c_code_46650, _c_source_46669); // DJP 

    /** c_out.e:81			update_checksum( c_source )*/
    RefDS(_c_source_46669);
    _55update_checksum(_c_source_46669);
L1: 

    /** c_out.e:83	end procedure*/
    DeRefDS(_c_source_46669);
    return;
    ;
}


void _54c_hprintf(object _format_46674, object _value_46675)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_value_46675)) {
        _1 = (object)(DBL_PTR(_value_46675)->dbl);
        DeRefDS(_value_46675);
        _value_46675 = _1;
    }

    /** c_out.e:88		if emit_c_output then*/
    if (_54emit_c_output_46647 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** c_out.e:89			printf(c_h, format, value)*/
    EPrintf(_54c_h_46651, _format_46674, _value_46675);
L1: 

    /** c_out.e:91	end procedure*/
    DeRefDSi(_format_46674);
    return;
    ;
}


void _54c_printf(object _format_46679, object _value_46680)
{
    object _text_46682 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:96		if emit_c_output then*/
    if (_54emit_c_output_46647 == 0)
    {
        goto L1; // [7] 29
    }
    else{
    }

    /** c_out.e:97			sequence text = sprintf( format, value )*/
    DeRefi(_text_46682);
    _text_46682 = EPrintf(-9999999, _format_46679, _value_46680);

    /** c_out.e:98			puts(c_code, text)*/
    EPuts(_54c_code_46650, _text_46682); // DJP 

    /** c_out.e:99			update_checksum( text )*/
    RefDS(_text_46682);
    _55update_checksum(_text_46682);
L1: 
    DeRefi(_text_46682);
    _text_46682 = NOVALUE;

    /** c_out.e:101	end procedure*/
    DeRefDSi(_format_46679);
    DeRef(_value_46680);
    return;
    ;
}


void _54c_printf8(object _value_46693)
{
    object _buff_46694 = NOVALUE;
    object _neg_46695 = NOVALUE;
    object _p_46696 = NOVALUE;
    object _24256 = NOVALUE;
    object _24255 = NOVALUE;
    object _24253 = NOVALUE;
    object _24252 = NOVALUE;
    object _24250 = NOVALUE;
    object _24249 = NOVALUE;
    object _24247 = NOVALUE;
    object _24246 = NOVALUE;
    object _24244 = NOVALUE;
    object _24242 = NOVALUE;
    object _24240 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:115		if emit_c_output then*/
    if (_54emit_c_output_46647 == 0)
    {
        goto L1; // [5] 182
    }
    else{
    }

    /** c_out.e:116			neg = 0*/
    _neg_46695 = 0;

    /** c_out.e:117			buff = sprintf("%.20eL", value)*/
    DeRef(_buff_46694);
    _buff_46694 = EPrintf(-9999999, _24238, _value_46693);

    /** c_out.e:118			if length(buff) < 10 then*/
    if (IS_SEQUENCE(_buff_46694)){
            _24240 = SEQ_PTR(_buff_46694)->length;
    }
    else {
        _24240 = 1;
    }
    if (_24240 >= 10)
    goto L2; // [24] 174

    /** c_out.e:120				p = 1*/
    _p_46696 = 1;

    /** c_out.e:121				while p <= length(buff) do*/
L3: 
    if (IS_SEQUENCE(_buff_46694)){
            _24242 = SEQ_PTR(_buff_46694)->length;
    }
    else {
        _24242 = 1;
    }
    if (_p_46696 > _24242)
    goto L4; // [41] 173

    /** c_out.e:122					if buff[p] = '-' then*/
    _2 = (object)SEQ_PTR(_buff_46694);
    _24244 = (object)*(((s1_ptr)_2)->base + _p_46696);
    if (binary_op_a(NOTEQ, _24244, 45)){
        _24244 = NOVALUE;
        goto L5; // [51] 63
    }
    _24244 = NOVALUE;

    /** c_out.e:123						neg = 1*/
    _neg_46695 = 1;
    goto L6; // [60] 162
L5: 

    /** c_out.e:125					elsif buff[p] = 'i' or buff[p] = 'I' then*/
    _2 = (object)SEQ_PTR(_buff_46694);
    _24246 = (object)*(((s1_ptr)_2)->base + _p_46696);
    if (IS_ATOM_INT(_24246)) {
        _24247 = (_24246 == 105);
    }
    else {
        _24247 = binary_op(EQUALS, _24246, 105);
    }
    _24246 = NOVALUE;
    if (IS_ATOM_INT(_24247)) {
        if (_24247 != 0) {
            goto L7; // [73] 90
        }
    }
    else {
        if (DBL_PTR(_24247)->dbl != 0.0) {
            goto L7; // [73] 90
        }
    }
    _2 = (object)SEQ_PTR(_buff_46694);
    _24249 = (object)*(((s1_ptr)_2)->base + _p_46696);
    if (IS_ATOM_INT(_24249)) {
        _24250 = (_24249 == 73);
    }
    else {
        _24250 = binary_op(EQUALS, _24249, 73);
    }
    _24249 = NOVALUE;
    if (_24250 == 0) {
        DeRef(_24250);
        _24250 = NOVALUE;
        goto L8; // [86] 114
    }
    else {
        if (!IS_ATOM_INT(_24250) && DBL_PTR(_24250)->dbl == 0.0){
            DeRef(_24250);
            _24250 = NOVALUE;
            goto L8; // [86] 114
        }
        DeRef(_24250);
        _24250 = NOVALUE;
    }
    DeRef(_24250);
    _24250 = NOVALUE;
L7: 

    /** c_out.e:127						buff = CREATE_INF*/
    RefDS(_54CREATE_INF_46685);
    DeRef(_buff_46694);
    _buff_46694 = _54CREATE_INF_46685;

    /** c_out.e:128						if neg then*/
    if (_neg_46695 == 0)
    {
        goto L4; // [97] 173
    }
    else{
    }

    /** c_out.e:129							buff = prepend(buff, '-')*/
    Prepend(&_buff_46694, _buff_46694, 45);

    /** c_out.e:131						exit*/
    goto L4; // [109] 173
    goto L6; // [111] 162
L8: 

    /** c_out.e:133					elsif buff[p] = 'n' or buff[p] = 'N' then*/
    _2 = (object)SEQ_PTR(_buff_46694);
    _24252 = (object)*(((s1_ptr)_2)->base + _p_46696);
    if (IS_ATOM_INT(_24252)) {
        _24253 = (_24252 == 110);
    }
    else {
        _24253 = binary_op(EQUALS, _24252, 110);
    }
    _24252 = NOVALUE;
    if (IS_ATOM_INT(_24253)) {
        if (_24253 != 0) {
            goto L9; // [124] 141
        }
    }
    else {
        if (DBL_PTR(_24253)->dbl != 0.0) {
            goto L9; // [124] 141
        }
    }
    _2 = (object)SEQ_PTR(_buff_46694);
    _24255 = (object)*(((s1_ptr)_2)->base + _p_46696);
    if (IS_ATOM_INT(_24255)) {
        _24256 = (_24255 == 78);
    }
    else {
        _24256 = binary_op(EQUALS, _24255, 78);
    }
    _24255 = NOVALUE;
    if (_24256 == 0) {
        DeRef(_24256);
        _24256 = NOVALUE;
        goto LA; // [137] 161
    }
    else {
        if (!IS_ATOM_INT(_24256) && DBL_PTR(_24256)->dbl == 0.0){
            DeRef(_24256);
            _24256 = NOVALUE;
            goto LA; // [137] 161
        }
        DeRef(_24256);
        _24256 = NOVALUE;
    }
    DeRef(_24256);
    _24256 = NOVALUE;
L9: 

    /** c_out.e:135						ifdef UNIX then*/

    /** c_out.e:136							buff = CREATE_NAN1*/
    RefDS(_54CREATE_NAN1_46687);
    DeRef(_buff_46694);
    _buff_46694 = _54CREATE_NAN1_46687;

    /** c_out.e:137							if neg then*/
    if (_neg_46695 == 0)
    {
        goto LB; // [150] 160
    }
    else{
    }

    /** c_out.e:138								buff = prepend(buff, '-')*/
    Prepend(&_buff_46694, _buff_46694, 45);
LB: 
LA: 
L6: 

    /** c_out.e:156					p += 1*/
    _p_46696 = _p_46696 + 1;

    /** c_out.e:157				end while*/
    goto L3; // [170] 38
L4: 
L2: 

    /** c_out.e:159			puts(c_code, buff)*/
    EPuts(_54c_code_46650, _buff_46694); // DJP 
L1: 

    /** c_out.e:161	end procedure*/
    DeRef(_value_46693);
    DeRef(_buff_46694);
    DeRef(_24247);
    _24247 = NOVALUE;
    DeRef(_24253);
    _24253 = NOVALUE;
    return;
    ;
}


void _54adjust_indent_before(object _stmt_46732)
{
    object _i_46733 = NOVALUE;
    object _lb_46735 = NOVALUE;
    object _rb_46736 = NOVALUE;
    object _24271 = NOVALUE;
    object _24269 = NOVALUE;
    object _24267 = NOVALUE;
    object _24261 = NOVALUE;
    object _24260 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:177		lb = FALSE*/
    _lb_46735 = _9FALSE_444;

    /** c_out.e:178		rb = FALSE*/
    _rb_46736 = _9FALSE_444;

    /** c_out.e:180		for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_46732)){
            _24260 = SEQ_PTR(_stmt_46732)->length;
    }
    else {
        _24260 = 1;
    }
    {
        object _p_46740;
        _p_46740 = 1;
L1: 
        if (_p_46740 > _24260){
            goto L2; // [22] 102
        }

        /** c_out.e:181			switch stmt[p] do*/
        _2 = (object)SEQ_PTR(_stmt_46732);
        _24261 = (object)*(((s1_ptr)_2)->base + _p_46740);
        if (IS_SEQUENCE(_24261) ){
            goto L3; // [35] 95
        }
        if(!IS_ATOM_INT(_24261)){
            if( (DBL_PTR(_24261)->dbl != (eudouble) ((object) DBL_PTR(_24261)->dbl) ) ){
                goto L3; // [35] 95
            }
            _0 = (object) DBL_PTR(_24261)->dbl;
        }
        else {
            _0 = _24261;
        };
        _24261 = NOVALUE;
        switch ( _0 ){ 

            /** c_out.e:182				case '\n' then*/
            case 10:

            /** c_out.e:183					exit*/
            goto L2; // [46] 102
            goto L3; // [48] 95

            /** c_out.e:185				case  '}' then*/
            case 125:

            /** c_out.e:186					rb = TRUE*/
            _rb_46736 = _9TRUE_446;

            /** c_out.e:187					if lb then*/
            if (_lb_46735 == 0)
            {
                goto L3; // [63] 95
            }
            else{
            }

            /** c_out.e:188						exit*/
            goto L2; // [68] 102
            goto L3; // [71] 95

            /** c_out.e:191				case '{' then*/
            case 123:

            /** c_out.e:192					lb = TRUE*/
            _lb_46735 = _9TRUE_446;

            /** c_out.e:193					if rb then */
            if (_rb_46736 == 0)
            {
                goto L4; // [86] 94
            }
            else{
            }

            /** c_out.e:194						exit*/
            goto L2; // [91] 102
L4: 
        ;}L3: 

        /** c_out.e:198		end for*/
        _p_46740 = _p_46740 + 1;
        goto L1; // [97] 29
L2: 
        ;
    }

    /** c_out.e:200		if rb then*/
    if (_rb_46736 == 0)
    {
        goto L5; // [104] 122
    }
    else{
    }

    /** c_out.e:201			if not lb then*/
    if (_lb_46735 != 0)
    goto L6; // [109] 121

    /** c_out.e:202				indent -= 4*/
    _54indent_46726 = _54indent_46726 - 4;
L6: 
L5: 

    /** c_out.e:206		i = indent + temp_indent*/
    _i_46733 = _54indent_46726 + _54temp_indent_46727;

    /** c_out.e:207		while i >= length(big_blanks) do*/
L7: 
    if (IS_SEQUENCE(_54big_blanks_46728)){
            _24267 = SEQ_PTR(_54big_blanks_46728)->length;
    }
    else {
        _24267 = 1;
    }
    if (_i_46733 < _24267)
    goto L8; // [140] 163

    /** c_out.e:208			c_puts(big_blanks)*/
    RefDS(_54big_blanks_46728);
    _54c_puts(_54big_blanks_46728);

    /** c_out.e:209			i -= length(big_blanks)*/
    if (IS_SEQUENCE(_54big_blanks_46728)){
            _24269 = SEQ_PTR(_54big_blanks_46728)->length;
    }
    else {
        _24269 = 1;
    }
    _i_46733 = _i_46733 - _24269;
    _24269 = NOVALUE;

    /** c_out.e:210		end while*/
    goto L7; // [160] 137
L8: 

    /** c_out.e:212		c_puts(big_blanks[1..i])*/
    rhs_slice_target = (object_ptr)&_24271;
    RHS_Slice(_54big_blanks_46728, 1, _i_46733);
    _54c_puts(_24271);
    _24271 = NOVALUE;

    /** c_out.e:214		temp_indent = 0    */
    _54temp_indent_46727 = 0;

    /** c_out.e:215	end procedure*/
    DeRefDS(_stmt_46732);
    return;
    ;
}


void _54adjust_indent_after(object _stmt_46765)
{
    object _24292 = NOVALUE;
    object _24291 = NOVALUE;
    object _24289 = NOVALUE;
    object _24287 = NOVALUE;
    object _24286 = NOVALUE;
    object _24283 = NOVALUE;
    object _24281 = NOVALUE;
    object _24280 = NOVALUE;
    object _24277 = NOVALUE;
    object _24273 = NOVALUE;
    object _24272 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:221		for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_46765)){
            _24272 = SEQ_PTR(_stmt_46765)->length;
    }
    else {
        _24272 = 1;
    }
    {
        object _p_46767;
        _p_46767 = 1;
L1: 
        if (_p_46767 > _24272){
            goto L2; // [8] 61
        }

        /** c_out.e:222			switch stmt[p] do*/
        _2 = (object)SEQ_PTR(_stmt_46765);
        _24273 = (object)*(((s1_ptr)_2)->base + _p_46767);
        if (IS_SEQUENCE(_24273) ){
            goto L3; // [21] 54
        }
        if(!IS_ATOM_INT(_24273)){
            if( (DBL_PTR(_24273)->dbl != (eudouble) ((object) DBL_PTR(_24273)->dbl) ) ){
                goto L3; // [21] 54
            }
            _0 = (object) DBL_PTR(_24273)->dbl;
        }
        else {
            _0 = _24273;
        };
        _24273 = NOVALUE;
        switch ( _0 ){ 

            /** c_out.e:223				case '\n' then*/
            case 10:

            /** c_out.e:224					exit*/
            goto L2; // [32] 61
            goto L3; // [34] 54

            /** c_out.e:226				case '{' then*/
            case 123:

            /** c_out.e:227					indent += 4*/
            _54indent_46726 = _54indent_46726 + 4;

            /** c_out.e:228					return*/
            DeRefDS(_stmt_46765);
            return;
        ;}L3: 

        /** c_out.e:230		end for*/
        _p_46767 = _p_46767 + 1;
        goto L1; // [56] 15
L2: 
        ;
    }

    /** c_out.e:232		if length(stmt) < 3 then*/
    if (IS_SEQUENCE(_stmt_46765)){
            _24277 = SEQ_PTR(_stmt_46765)->length;
    }
    else {
        _24277 = 1;
    }
    if (_24277 >= 3)
    goto L4; // [66] 76

    /** c_out.e:233			return*/
    DeRefDS(_stmt_46765);
    return;
L4: 

    /** c_out.e:236		if not equal("if ", stmt[1..3]) then*/
    rhs_slice_target = (object_ptr)&_24280;
    RHS_Slice(_stmt_46765, 1, 3);
    if (_24279 == _24280)
    _24281 = 1;
    else if (IS_ATOM_INT(_24279) && IS_ATOM_INT(_24280))
    _24281 = 0;
    else
    _24281 = (compare(_24279, _24280) == 0);
    DeRefDS(_24280);
    _24280 = NOVALUE;
    if (_24281 != 0)
    goto L5; // [87] 96
    _24281 = NOVALUE;

    /** c_out.e:237			return*/
    DeRefDS(_stmt_46765);
    return;
L5: 

    /** c_out.e:240		if length(stmt) < 5 then*/
    if (IS_SEQUENCE(_stmt_46765)){
            _24283 = SEQ_PTR(_stmt_46765)->length;
    }
    else {
        _24283 = 1;
    }
    if (_24283 >= 5)
    goto L6; // [101] 111

    /** c_out.e:241			return*/
    DeRefDS(_stmt_46765);
    return;
L6: 

    /** c_out.e:244		if not equal("else", stmt[1..4]) then*/
    rhs_slice_target = (object_ptr)&_24286;
    RHS_Slice(_stmt_46765, 1, 4);
    if (_24285 == _24286)
    _24287 = 1;
    else if (IS_ATOM_INT(_24285) && IS_ATOM_INT(_24286))
    _24287 = 0;
    else
    _24287 = (compare(_24285, _24286) == 0);
    DeRefDS(_24286);
    _24286 = NOVALUE;
    if (_24287 != 0)
    goto L7; // [122] 131
    _24287 = NOVALUE;

    /** c_out.e:245			return*/
    DeRefDS(_stmt_46765);
    return;
L7: 

    /** c_out.e:248		if not find(stmt[5], {" \n"}) then*/
    _2 = (object)SEQ_PTR(_stmt_46765);
    _24289 = (object)*(((s1_ptr)_2)->base + 5);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_24290);
    ((intptr_t*)_2)[1] = _24290;
    _24291 = MAKE_SEQ(_1);
    _24292 = find_from(_24289, _24291, 1);
    _24289 = NOVALUE;
    DeRefDS(_24291);
    _24291 = NOVALUE;
    if (_24292 != 0)
    goto L8; // [146] 155
    _24292 = NOVALUE;

    /** c_out.e:249			return*/
    DeRefDS(_stmt_46765);
    return;
L8: 

    /** c_out.e:252		temp_indent = 4*/
    _54temp_indent_46727 = 4;

    /** c_out.e:254	end procedure*/
    DeRefDS(_stmt_46765);
    return;
    ;
}



// 0x03547EF9
