// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _24reverse(object _target_3946, object _pFrom_3947, object _pTo_3948)
{
    object _uppr_3949 = NOVALUE;
    object _n_3950 = NOVALUE;
    object _lLimit_3951 = NOVALUE;
    object _t_3952 = NOVALUE;
    object _1889 = NOVALUE;
    object _1888 = NOVALUE;
    object _1887 = NOVALUE;
    object _1885 = NOVALUE;
    object _1884 = NOVALUE;
    object _1882 = NOVALUE;
    object _1880 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:549		n = length(target)*/
    if (IS_SEQUENCE(_target_3946)){
            _n_3950 = SEQ_PTR(_target_3946)->length;
    }
    else {
        _n_3950 = 1;
    }

    /** sequence.e:550		if n < 2 then*/
    if (_n_3950 >= 2)
    goto L1; // [12] 23

    /** sequence.e:551			return target*/
    DeRef(_t_3952);
    return _target_3946;
L1: 

    /** sequence.e:553		if pFrom < 1 then*/
    if (_pFrom_3947 >= 1)
    goto L2; // [25] 35

    /** sequence.e:554			pFrom = 1*/
    _pFrom_3947 = 1;
L2: 

    /** sequence.e:556		if pTo < 1 then*/
    if (_pTo_3948 >= 1)
    goto L3; // [37] 48

    /** sequence.e:557			pTo = n + pTo*/
    _pTo_3948 = _n_3950 + _pTo_3948;
L3: 

    /** sequence.e:559		if pTo < pFrom or pFrom >= n then*/
    _1880 = (_pTo_3948 < _pFrom_3947);
    if (_1880 != 0) {
        goto L4; // [54] 67
    }
    _1882 = (_pFrom_3947 >= _n_3950);
    if (_1882 == 0)
    {
        DeRef(_1882);
        _1882 = NOVALUE;
        goto L5; // [63] 74
    }
    else{
        DeRef(_1882);
        _1882 = NOVALUE;
    }
L4: 

    /** sequence.e:560			return target*/
    DeRef(_t_3952);
    DeRef(_1880);
    _1880 = NOVALUE;
    return _target_3946;
L5: 

    /** sequence.e:562		if pTo > n then*/
    if (_pTo_3948 <= _n_3950)
    goto L6; // [76] 86

    /** sequence.e:563			pTo = n*/
    _pTo_3948 = _n_3950;
L6: 

    /** sequence.e:566		lLimit = floor((pFrom+pTo-1)/2)*/
    _1884 = _pFrom_3947 + _pTo_3948;
    if ((object)((uintptr_t)_1884 + (uintptr_t)HIGH_BITS) >= 0){
        _1884 = NewDouble((eudouble)_1884);
    }
    if (IS_ATOM_INT(_1884)) {
        _1885 = _1884 - 1;
        if ((object)((uintptr_t)_1885 +(uintptr_t) HIGH_BITS) >= 0){
            _1885 = NewDouble((eudouble)_1885);
        }
    }
    else {
        _1885 = NewDouble(DBL_PTR(_1884)->dbl - (eudouble)1);
    }
    DeRef(_1884);
    _1884 = NOVALUE;
    if (IS_ATOM_INT(_1885)) {
        _lLimit_3951 = _1885 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _1885, 2);
        _lLimit_3951 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_1885);
    _1885 = NOVALUE;
    if (!IS_ATOM_INT(_lLimit_3951)) {
        _1 = (object)(DBL_PTR(_lLimit_3951)->dbl);
        DeRefDS(_lLimit_3951);
        _lLimit_3951 = _1;
    }

    /** sequence.e:567		t = target*/
    Ref(_target_3946);
    DeRef(_t_3952);
    _t_3952 = _target_3946;

    /** sequence.e:568		uppr = pTo*/
    _uppr_3949 = _pTo_3948;

    /** sequence.e:569		for lowr = pFrom to lLimit do*/
    _1887 = _lLimit_3951;
    {
        object _lowr_3971;
        _lowr_3971 = _pFrom_3947;
L7: 
        if (_lowr_3971 > _1887){
            goto L8; // [119] 159
        }

        /** sequence.e:570			t[uppr] = target[lowr]*/
        _2 = (object)SEQ_PTR(_target_3946);
        _1888 = (object)*(((s1_ptr)_2)->base + _lowr_3971);
        Ref(_1888);
        _2 = (object)SEQ_PTR(_t_3952);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _t_3952 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _uppr_3949);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _1888;
        if( _1 != _1888 ){
            DeRef(_1);
        }
        _1888 = NOVALUE;

        /** sequence.e:571			t[lowr] = target[uppr]*/
        _2 = (object)SEQ_PTR(_target_3946);
        _1889 = (object)*(((s1_ptr)_2)->base + _uppr_3949);
        Ref(_1889);
        _2 = (object)SEQ_PTR(_t_3952);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _t_3952 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _lowr_3971);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _1889;
        if( _1 != _1889 ){
            DeRef(_1);
        }
        _1889 = NOVALUE;

        /** sequence.e:572			uppr -= 1*/
        _uppr_3949 = _uppr_3949 - 1;

        /** sequence.e:573		end for*/
        _lowr_3971 = _lowr_3971 + 1;
        goto L7; // [154] 126
L8: 
        ;
    }

    /** sequence.e:574		return t*/
    DeRef(_target_3946);
    DeRef(_1880);
    _1880 = NOVALUE;
    return _t_3952;
    ;
}


object _24pad_tail(object _target_4046, object _size_4047, object _ch_4048)
{
    object _1925 = NOVALUE;
    object _1924 = NOVALUE;
    object _1923 = NOVALUE;
    object _1922 = NOVALUE;
    object _1920 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:1022		if size <= length(target) then*/
    if (IS_SEQUENCE(_target_4046)){
            _1920 = SEQ_PTR(_target_4046)->length;
    }
    else {
        _1920 = 1;
    }
    if (_size_4047 > _1920)
    goto L1; // [8] 19

    /** sequence.e:1023			return target*/
    return _target_4046;
L1: 

    /** sequence.e:1026		return target & repeat(ch, size - length(target))*/
    if (IS_SEQUENCE(_target_4046)){
            _1922 = SEQ_PTR(_target_4046)->length;
    }
    else {
        _1922 = 1;
    }
    _1923 = _size_4047 - _1922;
    _1922 = NOVALUE;
    _1924 = Repeat(_ch_4048, _1923);
    _1923 = NOVALUE;
    if (IS_SEQUENCE(_target_4046) && IS_ATOM(_1924)) {
    }
    else if (IS_ATOM(_target_4046) && IS_SEQUENCE(_1924)) {
        Ref(_target_4046);
        Prepend(&_1925, _1924, _target_4046);
    }
    else {
        Concat((object_ptr)&_1925, _target_4046, _1924);
    }
    DeRefDS(_1924);
    _1924 = NOVALUE;
    DeRef(_target_4046);
    return _1925;
    ;
}


object _24filter(object _source_4300, object _rid_4301, object _userdata_4302, object _rangetype_4303)
{
    object _dest_4304 = NOVALUE;
    object _idx_4305 = NOVALUE;
    object _2239 = NOVALUE;
    object _2238 = NOVALUE;
    object _2236 = NOVALUE;
    object _2235 = NOVALUE;
    object _2234 = NOVALUE;
    object _2233 = NOVALUE;
    object _2232 = NOVALUE;
    object _2229 = NOVALUE;
    object _2228 = NOVALUE;
    object _2227 = NOVALUE;
    object _2226 = NOVALUE;
    object _2223 = NOVALUE;
    object _2222 = NOVALUE;
    object _2221 = NOVALUE;
    object _2220 = NOVALUE;
    object _2219 = NOVALUE;
    object _2216 = NOVALUE;
    object _2215 = NOVALUE;
    object _2214 = NOVALUE;
    object _2213 = NOVALUE;
    object _2210 = NOVALUE;
    object _2209 = NOVALUE;
    object _2208 = NOVALUE;
    object _2207 = NOVALUE;
    object _2206 = NOVALUE;
    object _2203 = NOVALUE;
    object _2202 = NOVALUE;
    object _2201 = NOVALUE;
    object _2200 = NOVALUE;
    object _2197 = NOVALUE;
    object _2196 = NOVALUE;
    object _2195 = NOVALUE;
    object _2194 = NOVALUE;
    object _2193 = NOVALUE;
    object _2190 = NOVALUE;
    object _2189 = NOVALUE;
    object _2188 = NOVALUE;
    object _2187 = NOVALUE;
    object _2184 = NOVALUE;
    object _2183 = NOVALUE;
    object _2182 = NOVALUE;
    object _2181 = NOVALUE;
    object _2180 = NOVALUE;
    object _2177 = NOVALUE;
    object _2176 = NOVALUE;
    object _2175 = NOVALUE;
    object _2171 = NOVALUE;
    object _2168 = NOVALUE;
    object _2167 = NOVALUE;
    object _2166 = NOVALUE;
    object _2164 = NOVALUE;
    object _2163 = NOVALUE;
    object _2162 = NOVALUE;
    object _2161 = NOVALUE;
    object _2160 = NOVALUE;
    object _2157 = NOVALUE;
    object _2156 = NOVALUE;
    object _2155 = NOVALUE;
    object _2153 = NOVALUE;
    object _2152 = NOVALUE;
    object _2151 = NOVALUE;
    object _2150 = NOVALUE;
    object _2149 = NOVALUE;
    object _2146 = NOVALUE;
    object _2145 = NOVALUE;
    object _2144 = NOVALUE;
    object _2142 = NOVALUE;
    object _2141 = NOVALUE;
    object _2140 = NOVALUE;
    object _2139 = NOVALUE;
    object _2138 = NOVALUE;
    object _2135 = NOVALUE;
    object _2134 = NOVALUE;
    object _2133 = NOVALUE;
    object _2131 = NOVALUE;
    object _2130 = NOVALUE;
    object _2129 = NOVALUE;
    object _2128 = NOVALUE;
    object _2127 = NOVALUE;
    object _2125 = NOVALUE;
    object _2124 = NOVALUE;
    object _2123 = NOVALUE;
    object _2119 = NOVALUE;
    object _2116 = NOVALUE;
    object _2115 = NOVALUE;
    object _2114 = NOVALUE;
    object _2111 = NOVALUE;
    object _2108 = NOVALUE;
    object _2107 = NOVALUE;
    object _2106 = NOVALUE;
    object _2103 = NOVALUE;
    object _2100 = NOVALUE;
    object _2099 = NOVALUE;
    object _2098 = NOVALUE;
    object _2095 = NOVALUE;
    object _2092 = NOVALUE;
    object _2091 = NOVALUE;
    object _2090 = NOVALUE;
    object _2086 = NOVALUE;
    object _2083 = NOVALUE;
    object _2082 = NOVALUE;
    object _2081 = NOVALUE;
    object _2078 = NOVALUE;
    object _2075 = NOVALUE;
    object _2074 = NOVALUE;
    object _2073 = NOVALUE;
    object _2067 = NOVALUE;
    object _2065 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:1731		if length(source) = 0 then*/
    if (IS_SEQUENCE(_source_4300)){
            _2065 = SEQ_PTR(_source_4300)->length;
    }
    else {
        _2065 = 1;
    }
    if (_2065 != 0)
    goto L1; // [8] 19

    /** sequence.e:1732			return source*/
    DeRefDS(_userdata_4302);
    DeRefDS(_rangetype_4303);
    DeRef(_dest_4304);
    return _source_4300;
L1: 

    /** sequence.e:1734		dest = repeat(0, length(source))*/
    if (IS_SEQUENCE(_source_4300)){
            _2067 = SEQ_PTR(_source_4300)->length;
    }
    else {
        _2067 = 1;
    }
    DeRef(_dest_4304);
    _dest_4304 = Repeat(0, _2067);
    _2067 = NOVALUE;

    /** sequence.e:1735		idx = 0*/
    _idx_4305 = 0;

    /** sequence.e:1736		switch rid do*/
    _1 = find(_rid_4301, _2069);
    switch ( _1 ){ 

        /** sequence.e:1737			case "<", "lt" then*/
        case 1:
        case 2:

        /** sequence.e:1738				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4300)){
                _2073 = SEQ_PTR(_source_4300)->length;
        }
        else {
            _2073 = 1;
        }
        {
            object _a_4317;
            _a_4317 = 1;
L2: 
            if (_a_4317 > _2073){
                goto L3; // [51] 96
            }

            /** sequence.e:1739					if compare(source[a], userdata) < 0 then*/
            _2 = (object)SEQ_PTR(_source_4300);
            _2074 = (object)*(((s1_ptr)_2)->base + _a_4317);
            if (IS_ATOM_INT(_2074) && IS_ATOM_INT(_userdata_4302)){
                _2075 = (_2074 < _userdata_4302) ? -1 : (_2074 > _userdata_4302);
            }
            else{
                _2075 = compare(_2074, _userdata_4302);
            }
            _2074 = NOVALUE;
            if (_2075 >= 0)
            goto L4; // [68] 89

            /** sequence.e:1740						idx += 1*/
            _idx_4305 = _idx_4305 + 1;

            /** sequence.e:1741						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4300);
            _2078 = (object)*(((s1_ptr)_2)->base + _a_4317);
            Ref(_2078);
            _2 = (object)SEQ_PTR(_dest_4304);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2078;
            if( _1 != _2078 ){
                DeRef(_1);
            }
            _2078 = NOVALUE;
L4: 

            /** sequence.e:1743				end for*/
            _a_4317 = _a_4317 + 1;
            goto L2; // [91] 58
L3: 
            ;
        }
        goto L5; // [96] 1304

        /** sequence.e:1745			case "<=", "le" then*/
        case 3:
        case 4:

        /** sequence.e:1746				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4300)){
                _2081 = SEQ_PTR(_source_4300)->length;
        }
        else {
            _2081 = 1;
        }
        {
            object _a_4329;
            _a_4329 = 1;
L6: 
            if (_a_4329 > _2081){
                goto L7; // [109] 154
            }

            /** sequence.e:1747					if compare(source[a], userdata) <= 0 then*/
            _2 = (object)SEQ_PTR(_source_4300);
            _2082 = (object)*(((s1_ptr)_2)->base + _a_4329);
            if (IS_ATOM_INT(_2082) && IS_ATOM_INT(_userdata_4302)){
                _2083 = (_2082 < _userdata_4302) ? -1 : (_2082 > _userdata_4302);
            }
            else{
                _2083 = compare(_2082, _userdata_4302);
            }
            _2082 = NOVALUE;
            if (_2083 > 0)
            goto L8; // [126] 147

            /** sequence.e:1748						idx += 1*/
            _idx_4305 = _idx_4305 + 1;

            /** sequence.e:1749						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4300);
            _2086 = (object)*(((s1_ptr)_2)->base + _a_4329);
            Ref(_2086);
            _2 = (object)SEQ_PTR(_dest_4304);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2086;
            if( _1 != _2086 ){
                DeRef(_1);
            }
            _2086 = NOVALUE;
L8: 

            /** sequence.e:1751				end for*/
            _a_4329 = _a_4329 + 1;
            goto L6; // [149] 116
L7: 
            ;
        }
        goto L5; // [154] 1304

        /** sequence.e:1753			case "=", "==", "eq" then*/
        case 5:
        case 6:
        case 7:

        /** sequence.e:1754				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4300)){
                _2090 = SEQ_PTR(_source_4300)->length;
        }
        else {
            _2090 = 1;
        }
        {
            object _a_4342;
            _a_4342 = 1;
L9: 
            if (_a_4342 > _2090){
                goto LA; // [169] 214
            }

            /** sequence.e:1755					if compare(source[a], userdata) = 0 then*/
            _2 = (object)SEQ_PTR(_source_4300);
            _2091 = (object)*(((s1_ptr)_2)->base + _a_4342);
            if (IS_ATOM_INT(_2091) && IS_ATOM_INT(_userdata_4302)){
                _2092 = (_2091 < _userdata_4302) ? -1 : (_2091 > _userdata_4302);
            }
            else{
                _2092 = compare(_2091, _userdata_4302);
            }
            _2091 = NOVALUE;
            if (_2092 != 0)
            goto LB; // [186] 207

            /** sequence.e:1756						idx += 1*/
            _idx_4305 = _idx_4305 + 1;

            /** sequence.e:1757						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4300);
            _2095 = (object)*(((s1_ptr)_2)->base + _a_4342);
            Ref(_2095);
            _2 = (object)SEQ_PTR(_dest_4304);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2095;
            if( _1 != _2095 ){
                DeRef(_1);
            }
            _2095 = NOVALUE;
LB: 

            /** sequence.e:1759				end for*/
            _a_4342 = _a_4342 + 1;
            goto L9; // [209] 176
LA: 
            ;
        }
        goto L5; // [214] 1304

        /** sequence.e:1761			case "!=", "ne" then*/
        case 8:
        case 9:

        /** sequence.e:1762				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4300)){
                _2098 = SEQ_PTR(_source_4300)->length;
        }
        else {
            _2098 = 1;
        }
        {
            object _a_4354;
            _a_4354 = 1;
LC: 
            if (_a_4354 > _2098){
                goto LD; // [227] 272
            }

            /** sequence.e:1763					if compare(source[a], userdata) != 0 then*/
            _2 = (object)SEQ_PTR(_source_4300);
            _2099 = (object)*(((s1_ptr)_2)->base + _a_4354);
            if (IS_ATOM_INT(_2099) && IS_ATOM_INT(_userdata_4302)){
                _2100 = (_2099 < _userdata_4302) ? -1 : (_2099 > _userdata_4302);
            }
            else{
                _2100 = compare(_2099, _userdata_4302);
            }
            _2099 = NOVALUE;
            if (_2100 == 0)
            goto LE; // [244] 265

            /** sequence.e:1764						idx += 1*/
            _idx_4305 = _idx_4305 + 1;

            /** sequence.e:1765						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4300);
            _2103 = (object)*(((s1_ptr)_2)->base + _a_4354);
            Ref(_2103);
            _2 = (object)SEQ_PTR(_dest_4304);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2103;
            if( _1 != _2103 ){
                DeRef(_1);
            }
            _2103 = NOVALUE;
LE: 

            /** sequence.e:1767				end for*/
            _a_4354 = _a_4354 + 1;
            goto LC; // [267] 234
LD: 
            ;
        }
        goto L5; // [272] 1304

        /** sequence.e:1769			case ">", "gt" then*/
        case 10:
        case 11:

        /** sequence.e:1770				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4300)){
                _2106 = SEQ_PTR(_source_4300)->length;
        }
        else {
            _2106 = 1;
        }
        {
            object _a_4366;
            _a_4366 = 1;
LF: 
            if (_a_4366 > _2106){
                goto L10; // [285] 330
            }

            /** sequence.e:1771					if compare(source[a], userdata) > 0 then*/
            _2 = (object)SEQ_PTR(_source_4300);
            _2107 = (object)*(((s1_ptr)_2)->base + _a_4366);
            if (IS_ATOM_INT(_2107) && IS_ATOM_INT(_userdata_4302)){
                _2108 = (_2107 < _userdata_4302) ? -1 : (_2107 > _userdata_4302);
            }
            else{
                _2108 = compare(_2107, _userdata_4302);
            }
            _2107 = NOVALUE;
            if (_2108 <= 0)
            goto L11; // [302] 323

            /** sequence.e:1772						idx += 1*/
            _idx_4305 = _idx_4305 + 1;

            /** sequence.e:1773						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4300);
            _2111 = (object)*(((s1_ptr)_2)->base + _a_4366);
            Ref(_2111);
            _2 = (object)SEQ_PTR(_dest_4304);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2111;
            if( _1 != _2111 ){
                DeRef(_1);
            }
            _2111 = NOVALUE;
L11: 

            /** sequence.e:1775				end for*/
            _a_4366 = _a_4366 + 1;
            goto LF; // [325] 292
L10: 
            ;
        }
        goto L5; // [330] 1304

        /** sequence.e:1777			case ">=", "ge" then*/
        case 12:
        case 13:

        /** sequence.e:1778				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4300)){
                _2114 = SEQ_PTR(_source_4300)->length;
        }
        else {
            _2114 = 1;
        }
        {
            object _a_4378;
            _a_4378 = 1;
L12: 
            if (_a_4378 > _2114){
                goto L13; // [343] 388
            }

            /** sequence.e:1779					if compare(source[a], userdata) >= 0 then*/
            _2 = (object)SEQ_PTR(_source_4300);
            _2115 = (object)*(((s1_ptr)_2)->base + _a_4378);
            if (IS_ATOM_INT(_2115) && IS_ATOM_INT(_userdata_4302)){
                _2116 = (_2115 < _userdata_4302) ? -1 : (_2115 > _userdata_4302);
            }
            else{
                _2116 = compare(_2115, _userdata_4302);
            }
            _2115 = NOVALUE;
            if (_2116 < 0)
            goto L14; // [360] 381

            /** sequence.e:1780						idx += 1*/
            _idx_4305 = _idx_4305 + 1;

            /** sequence.e:1781						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4300);
            _2119 = (object)*(((s1_ptr)_2)->base + _a_4378);
            Ref(_2119);
            _2 = (object)SEQ_PTR(_dest_4304);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2119;
            if( _1 != _2119 ){
                DeRef(_1);
            }
            _2119 = NOVALUE;
L14: 

            /** sequence.e:1783				end for*/
            _a_4378 = _a_4378 + 1;
            goto L12; // [383] 350
L13: 
            ;
        }
        goto L5; // [388] 1304

        /** sequence.e:1785			case "in" then*/
        case 14:

        /** sequence.e:1786				switch rangetype do*/
        _1 = find(_rangetype_4303, _2121);
        switch ( _1 ){ 

            /** sequence.e:1787					case "" then*/
            case 1:

            /** sequence.e:1788						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4300)){
                    _2123 = SEQ_PTR(_source_4300)->length;
            }
            else {
                _2123 = 1;
            }
            {
                object _a_4392;
                _a_4392 = 1;
L15: 
                if (_a_4392 > _2123){
                    goto L16; // [410] 455
                }

                /** sequence.e:1789							if find(source[a], userdata)  then*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2124 = (object)*(((s1_ptr)_2)->base + _a_4392);
                _2125 = find_from(_2124, _userdata_4302, 1);
                _2124 = NOVALUE;
                if (_2125 == 0)
                {
                    _2125 = NOVALUE;
                    goto L17; // [428] 448
                }
                else{
                    _2125 = NOVALUE;
                }

                /** sequence.e:1790								idx += 1*/
                _idx_4305 = _idx_4305 + 1;

                /** sequence.e:1791								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2127 = (object)*(((s1_ptr)_2)->base + _a_4392);
                Ref(_2127);
                _2 = (object)SEQ_PTR(_dest_4304);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2127;
                if( _1 != _2127 ){
                    DeRef(_1);
                }
                _2127 = NOVALUE;
L17: 

                /** sequence.e:1793						end for*/
                _a_4392 = _a_4392 + 1;
                goto L15; // [450] 417
L16: 
                ;
            }
            goto L5; // [455] 1304

            /** sequence.e:1795					case "[]" then*/
            case 2:

            /** sequence.e:1796						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4300)){
                    _2128 = SEQ_PTR(_source_4300)->length;
            }
            else {
                _2128 = 1;
            }
            {
                object _a_4401;
                _a_4401 = 1;
L18: 
                if (_a_4401 > _2128){
                    goto L19; // [466] 534
                }

                /** sequence.e:1797							if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2129 = (object)*(((s1_ptr)_2)->base + _a_4401);
                _2 = (object)SEQ_PTR(_userdata_4302);
                _2130 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2129) && IS_ATOM_INT(_2130)){
                    _2131 = (_2129 < _2130) ? -1 : (_2129 > _2130);
                }
                else{
                    _2131 = compare(_2129, _2130);
                }
                _2129 = NOVALUE;
                _2130 = NOVALUE;
                if (_2131 < 0)
                goto L1A; // [487] 527

                /** sequence.e:1798								if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2133 = (object)*(((s1_ptr)_2)->base + _a_4401);
                _2 = (object)SEQ_PTR(_userdata_4302);
                _2134 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2133) && IS_ATOM_INT(_2134)){
                    _2135 = (_2133 < _2134) ? -1 : (_2133 > _2134);
                }
                else{
                    _2135 = compare(_2133, _2134);
                }
                _2133 = NOVALUE;
                _2134 = NOVALUE;
                if (_2135 > 0)
                goto L1B; // [505] 526

                /** sequence.e:1799									idx += 1*/
                _idx_4305 = _idx_4305 + 1;

                /** sequence.e:1800									dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2138 = (object)*(((s1_ptr)_2)->base + _a_4401);
                Ref(_2138);
                _2 = (object)SEQ_PTR(_dest_4304);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2138;
                if( _1 != _2138 ){
                    DeRef(_1);
                }
                _2138 = NOVALUE;
L1B: 
L1A: 

                /** sequence.e:1803						end for*/
                _a_4401 = _a_4401 + 1;
                goto L18; // [529] 473
L19: 
                ;
            }
            goto L5; // [534] 1304

            /** sequence.e:1805					case "[)" then*/
            case 3:

            /** sequence.e:1806						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4300)){
                    _2139 = SEQ_PTR(_source_4300)->length;
            }
            else {
                _2139 = 1;
            }
            {
                object _a_4417;
                _a_4417 = 1;
L1C: 
                if (_a_4417 > _2139){
                    goto L1D; // [545] 613
                }

                /** sequence.e:1807							if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2140 = (object)*(((s1_ptr)_2)->base + _a_4417);
                _2 = (object)SEQ_PTR(_userdata_4302);
                _2141 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2140) && IS_ATOM_INT(_2141)){
                    _2142 = (_2140 < _2141) ? -1 : (_2140 > _2141);
                }
                else{
                    _2142 = compare(_2140, _2141);
                }
                _2140 = NOVALUE;
                _2141 = NOVALUE;
                if (_2142 < 0)
                goto L1E; // [566] 606

                /** sequence.e:1808								if compare(source[a], userdata[2]) < 0 then*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2144 = (object)*(((s1_ptr)_2)->base + _a_4417);
                _2 = (object)SEQ_PTR(_userdata_4302);
                _2145 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2144) && IS_ATOM_INT(_2145)){
                    _2146 = (_2144 < _2145) ? -1 : (_2144 > _2145);
                }
                else{
                    _2146 = compare(_2144, _2145);
                }
                _2144 = NOVALUE;
                _2145 = NOVALUE;
                if (_2146 >= 0)
                goto L1F; // [584] 605

                /** sequence.e:1809									idx += 1*/
                _idx_4305 = _idx_4305 + 1;

                /** sequence.e:1810									dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2149 = (object)*(((s1_ptr)_2)->base + _a_4417);
                Ref(_2149);
                _2 = (object)SEQ_PTR(_dest_4304);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2149;
                if( _1 != _2149 ){
                    DeRef(_1);
                }
                _2149 = NOVALUE;
L1F: 
L1E: 

                /** sequence.e:1813						end for*/
                _a_4417 = _a_4417 + 1;
                goto L1C; // [608] 552
L1D: 
                ;
            }
            goto L5; // [613] 1304

            /** sequence.e:1814					case "(]" then*/
            case 4:

            /** sequence.e:1815						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4300)){
                    _2150 = SEQ_PTR(_source_4300)->length;
            }
            else {
                _2150 = 1;
            }
            {
                object _a_4433;
                _a_4433 = 1;
L20: 
                if (_a_4433 > _2150){
                    goto L21; // [624] 692
                }

                /** sequence.e:1816							if compare(source[a], userdata[1]) > 0 then*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2151 = (object)*(((s1_ptr)_2)->base + _a_4433);
                _2 = (object)SEQ_PTR(_userdata_4302);
                _2152 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2151) && IS_ATOM_INT(_2152)){
                    _2153 = (_2151 < _2152) ? -1 : (_2151 > _2152);
                }
                else{
                    _2153 = compare(_2151, _2152);
                }
                _2151 = NOVALUE;
                _2152 = NOVALUE;
                if (_2153 <= 0)
                goto L22; // [645] 685

                /** sequence.e:1817								if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2155 = (object)*(((s1_ptr)_2)->base + _a_4433);
                _2 = (object)SEQ_PTR(_userdata_4302);
                _2156 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2155) && IS_ATOM_INT(_2156)){
                    _2157 = (_2155 < _2156) ? -1 : (_2155 > _2156);
                }
                else{
                    _2157 = compare(_2155, _2156);
                }
                _2155 = NOVALUE;
                _2156 = NOVALUE;
                if (_2157 > 0)
                goto L23; // [663] 684

                /** sequence.e:1818									idx += 1*/
                _idx_4305 = _idx_4305 + 1;

                /** sequence.e:1819									dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2160 = (object)*(((s1_ptr)_2)->base + _a_4433);
                Ref(_2160);
                _2 = (object)SEQ_PTR(_dest_4304);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2160;
                if( _1 != _2160 ){
                    DeRef(_1);
                }
                _2160 = NOVALUE;
L23: 
L22: 

                /** sequence.e:1822						end for*/
                _a_4433 = _a_4433 + 1;
                goto L20; // [687] 631
L21: 
                ;
            }
            goto L5; // [692] 1304

            /** sequence.e:1823					case "()" then*/
            case 5:

            /** sequence.e:1824						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4300)){
                    _2161 = SEQ_PTR(_source_4300)->length;
            }
            else {
                _2161 = 1;
            }
            {
                object _a_4449;
                _a_4449 = 1;
L24: 
                if (_a_4449 > _2161){
                    goto L25; // [703] 771
                }

                /** sequence.e:1825							if compare(source[a], userdata[1]) > 0 then*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2162 = (object)*(((s1_ptr)_2)->base + _a_4449);
                _2 = (object)SEQ_PTR(_userdata_4302);
                _2163 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2162) && IS_ATOM_INT(_2163)){
                    _2164 = (_2162 < _2163) ? -1 : (_2162 > _2163);
                }
                else{
                    _2164 = compare(_2162, _2163);
                }
                _2162 = NOVALUE;
                _2163 = NOVALUE;
                if (_2164 <= 0)
                goto L26; // [724] 764

                /** sequence.e:1826								if compare(source[a], userdata[2]) < 0 then*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2166 = (object)*(((s1_ptr)_2)->base + _a_4449);
                _2 = (object)SEQ_PTR(_userdata_4302);
                _2167 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2166) && IS_ATOM_INT(_2167)){
                    _2168 = (_2166 < _2167) ? -1 : (_2166 > _2167);
                }
                else{
                    _2168 = compare(_2166, _2167);
                }
                _2166 = NOVALUE;
                _2167 = NOVALUE;
                if (_2168 >= 0)
                goto L27; // [742] 763

                /** sequence.e:1827									idx += 1*/
                _idx_4305 = _idx_4305 + 1;

                /** sequence.e:1828									dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2171 = (object)*(((s1_ptr)_2)->base + _a_4449);
                Ref(_2171);
                _2 = (object)SEQ_PTR(_dest_4304);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2171;
                if( _1 != _2171 ){
                    DeRef(_1);
                }
                _2171 = NOVALUE;
L27: 
L26: 

                /** sequence.e:1831						end for*/
                _a_4449 = _a_4449 + 1;
                goto L24; // [766] 710
L25: 
                ;
            }
            goto L5; // [771] 1304

            /** sequence.e:1833					case else*/
            case 0:
        ;}        goto L5; // [778] 1304

        /** sequence.e:1838			case "out" then*/
        case 15:

        /** sequence.e:1839				switch rangetype do*/
        _1 = find(_rangetype_4303, _2173);
        switch ( _1 ){ 

            /** sequence.e:1840					case "" then*/
            case 1:

            /** sequence.e:1841						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4300)){
                    _2175 = SEQ_PTR(_source_4300)->length;
            }
            else {
                _2175 = 1;
            }
            {
                object _a_4470;
                _a_4470 = 1;
L28: 
                if (_a_4470 > _2175){
                    goto L29; // [800] 845
                }

                /** sequence.e:1842							if not find(source[a], userdata)  then*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2176 = (object)*(((s1_ptr)_2)->base + _a_4470);
                _2177 = find_from(_2176, _userdata_4302, 1);
                _2176 = NOVALUE;
                if (_2177 != 0)
                goto L2A; // [818] 838
                _2177 = NOVALUE;

                /** sequence.e:1843								idx += 1*/
                _idx_4305 = _idx_4305 + 1;

                /** sequence.e:1844								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2180 = (object)*(((s1_ptr)_2)->base + _a_4470);
                Ref(_2180);
                _2 = (object)SEQ_PTR(_dest_4304);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2180;
                if( _1 != _2180 ){
                    DeRef(_1);
                }
                _2180 = NOVALUE;
L2A: 

                /** sequence.e:1846						end for*/
                _a_4470 = _a_4470 + 1;
                goto L28; // [840] 807
L29: 
                ;
            }
            goto L5; // [845] 1304

            /** sequence.e:1848					case "[]" then*/
            case 2:

            /** sequence.e:1849						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4300)){
                    _2181 = SEQ_PTR(_source_4300)->length;
            }
            else {
                _2181 = 1;
            }
            {
                object _a_4480;
                _a_4480 = 1;
L2B: 
                if (_a_4480 > _2181){
                    goto L2C; // [856] 943
                }

                /** sequence.e:1850							if compare(source[a], userdata[1]) < 0 then*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2182 = (object)*(((s1_ptr)_2)->base + _a_4480);
                _2 = (object)SEQ_PTR(_userdata_4302);
                _2183 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2182) && IS_ATOM_INT(_2183)){
                    _2184 = (_2182 < _2183) ? -1 : (_2182 > _2183);
                }
                else{
                    _2184 = compare(_2182, _2183);
                }
                _2182 = NOVALUE;
                _2183 = NOVALUE;
                if (_2184 >= 0)
                goto L2D; // [877] 900

                /** sequence.e:1851								idx += 1*/
                _idx_4305 = _idx_4305 + 1;

                /** sequence.e:1852								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2187 = (object)*(((s1_ptr)_2)->base + _a_4480);
                Ref(_2187);
                _2 = (object)SEQ_PTR(_dest_4304);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2187;
                if( _1 != _2187 ){
                    DeRef(_1);
                }
                _2187 = NOVALUE;
                goto L2E; // [897] 936
L2D: 

                /** sequence.e:1853							elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2188 = (object)*(((s1_ptr)_2)->base + _a_4480);
                _2 = (object)SEQ_PTR(_userdata_4302);
                _2189 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2188) && IS_ATOM_INT(_2189)){
                    _2190 = (_2188 < _2189) ? -1 : (_2188 > _2189);
                }
                else{
                    _2190 = compare(_2188, _2189);
                }
                _2188 = NOVALUE;
                _2189 = NOVALUE;
                if (_2190 <= 0)
                goto L2F; // [914] 935

                /** sequence.e:1854								idx += 1*/
                _idx_4305 = _idx_4305 + 1;

                /** sequence.e:1855								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2193 = (object)*(((s1_ptr)_2)->base + _a_4480);
                Ref(_2193);
                _2 = (object)SEQ_PTR(_dest_4304);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2193;
                if( _1 != _2193 ){
                    DeRef(_1);
                }
                _2193 = NOVALUE;
L2F: 
L2E: 

                /** sequence.e:1857						end for*/
                _a_4480 = _a_4480 + 1;
                goto L2B; // [938] 863
L2C: 
                ;
            }
            goto L5; // [943] 1304

            /** sequence.e:1859					case "[)" then*/
            case 3:

            /** sequence.e:1860						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4300)){
                    _2194 = SEQ_PTR(_source_4300)->length;
            }
            else {
                _2194 = 1;
            }
            {
                object _a_4498;
                _a_4498 = 1;
L30: 
                if (_a_4498 > _2194){
                    goto L31; // [954] 1041
                }

                /** sequence.e:1861							if compare(source[a], userdata[1]) < 0 then*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2195 = (object)*(((s1_ptr)_2)->base + _a_4498);
                _2 = (object)SEQ_PTR(_userdata_4302);
                _2196 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2195) && IS_ATOM_INT(_2196)){
                    _2197 = (_2195 < _2196) ? -1 : (_2195 > _2196);
                }
                else{
                    _2197 = compare(_2195, _2196);
                }
                _2195 = NOVALUE;
                _2196 = NOVALUE;
                if (_2197 >= 0)
                goto L32; // [975] 998

                /** sequence.e:1862								idx += 1*/
                _idx_4305 = _idx_4305 + 1;

                /** sequence.e:1863								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2200 = (object)*(((s1_ptr)_2)->base + _a_4498);
                Ref(_2200);
                _2 = (object)SEQ_PTR(_dest_4304);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2200;
                if( _1 != _2200 ){
                    DeRef(_1);
                }
                _2200 = NOVALUE;
                goto L33; // [995] 1034
L32: 

                /** sequence.e:1864							elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2201 = (object)*(((s1_ptr)_2)->base + _a_4498);
                _2 = (object)SEQ_PTR(_userdata_4302);
                _2202 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2201) && IS_ATOM_INT(_2202)){
                    _2203 = (_2201 < _2202) ? -1 : (_2201 > _2202);
                }
                else{
                    _2203 = compare(_2201, _2202);
                }
                _2201 = NOVALUE;
                _2202 = NOVALUE;
                if (_2203 < 0)
                goto L34; // [1012] 1033

                /** sequence.e:1865								idx += 1*/
                _idx_4305 = _idx_4305 + 1;

                /** sequence.e:1866								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2206 = (object)*(((s1_ptr)_2)->base + _a_4498);
                Ref(_2206);
                _2 = (object)SEQ_PTR(_dest_4304);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2206;
                if( _1 != _2206 ){
                    DeRef(_1);
                }
                _2206 = NOVALUE;
L34: 
L33: 

                /** sequence.e:1868						end for*/
                _a_4498 = _a_4498 + 1;
                goto L30; // [1036] 961
L31: 
                ;
            }
            goto L5; // [1041] 1304

            /** sequence.e:1869					case "(]" then*/
            case 4:

            /** sequence.e:1870						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4300)){
                    _2207 = SEQ_PTR(_source_4300)->length;
            }
            else {
                _2207 = 1;
            }
            {
                object _a_4516;
                _a_4516 = 1;
L35: 
                if (_a_4516 > _2207){
                    goto L36; // [1052] 1139
                }

                /** sequence.e:1871							if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2208 = (object)*(((s1_ptr)_2)->base + _a_4516);
                _2 = (object)SEQ_PTR(_userdata_4302);
                _2209 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2208) && IS_ATOM_INT(_2209)){
                    _2210 = (_2208 < _2209) ? -1 : (_2208 > _2209);
                }
                else{
                    _2210 = compare(_2208, _2209);
                }
                _2208 = NOVALUE;
                _2209 = NOVALUE;
                if (_2210 > 0)
                goto L37; // [1073] 1096

                /** sequence.e:1872								idx += 1*/
                _idx_4305 = _idx_4305 + 1;

                /** sequence.e:1873								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2213 = (object)*(((s1_ptr)_2)->base + _a_4516);
                Ref(_2213);
                _2 = (object)SEQ_PTR(_dest_4304);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2213;
                if( _1 != _2213 ){
                    DeRef(_1);
                }
                _2213 = NOVALUE;
                goto L38; // [1093] 1132
L37: 

                /** sequence.e:1874							elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2214 = (object)*(((s1_ptr)_2)->base + _a_4516);
                _2 = (object)SEQ_PTR(_userdata_4302);
                _2215 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2214) && IS_ATOM_INT(_2215)){
                    _2216 = (_2214 < _2215) ? -1 : (_2214 > _2215);
                }
                else{
                    _2216 = compare(_2214, _2215);
                }
                _2214 = NOVALUE;
                _2215 = NOVALUE;
                if (_2216 <= 0)
                goto L39; // [1110] 1131

                /** sequence.e:1875								idx += 1*/
                _idx_4305 = _idx_4305 + 1;

                /** sequence.e:1876								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2219 = (object)*(((s1_ptr)_2)->base + _a_4516);
                Ref(_2219);
                _2 = (object)SEQ_PTR(_dest_4304);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2219;
                if( _1 != _2219 ){
                    DeRef(_1);
                }
                _2219 = NOVALUE;
L39: 
L38: 

                /** sequence.e:1878						end for*/
                _a_4516 = _a_4516 + 1;
                goto L35; // [1134] 1059
L36: 
                ;
            }
            goto L5; // [1139] 1304

            /** sequence.e:1879					case "()" then*/
            case 5:

            /** sequence.e:1880						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4300)){
                    _2220 = SEQ_PTR(_source_4300)->length;
            }
            else {
                _2220 = 1;
            }
            {
                object _a_4534;
                _a_4534 = 1;
L3A: 
                if (_a_4534 > _2220){
                    goto L3B; // [1150] 1237
                }

                /** sequence.e:1881							if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2221 = (object)*(((s1_ptr)_2)->base + _a_4534);
                _2 = (object)SEQ_PTR(_userdata_4302);
                _2222 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2221) && IS_ATOM_INT(_2222)){
                    _2223 = (_2221 < _2222) ? -1 : (_2221 > _2222);
                }
                else{
                    _2223 = compare(_2221, _2222);
                }
                _2221 = NOVALUE;
                _2222 = NOVALUE;
                if (_2223 > 0)
                goto L3C; // [1171] 1194

                /** sequence.e:1882								idx += 1*/
                _idx_4305 = _idx_4305 + 1;

                /** sequence.e:1883								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2226 = (object)*(((s1_ptr)_2)->base + _a_4534);
                Ref(_2226);
                _2 = (object)SEQ_PTR(_dest_4304);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2226;
                if( _1 != _2226 ){
                    DeRef(_1);
                }
                _2226 = NOVALUE;
                goto L3D; // [1191] 1230
L3C: 

                /** sequence.e:1884							elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2227 = (object)*(((s1_ptr)_2)->base + _a_4534);
                _2 = (object)SEQ_PTR(_userdata_4302);
                _2228 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2227) && IS_ATOM_INT(_2228)){
                    _2229 = (_2227 < _2228) ? -1 : (_2227 > _2228);
                }
                else{
                    _2229 = compare(_2227, _2228);
                }
                _2227 = NOVALUE;
                _2228 = NOVALUE;
                if (_2229 < 0)
                goto L3E; // [1208] 1229

                /** sequence.e:1885								idx += 1*/
                _idx_4305 = _idx_4305 + 1;

                /** sequence.e:1886								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4300);
                _2232 = (object)*(((s1_ptr)_2)->base + _a_4534);
                Ref(_2232);
                _2 = (object)SEQ_PTR(_dest_4304);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2232;
                if( _1 != _2232 ){
                    DeRef(_1);
                }
                _2232 = NOVALUE;
L3E: 
L3D: 

                /** sequence.e:1888						end for*/
                _a_4534 = _a_4534 + 1;
                goto L3A; // [1232] 1157
L3B: 
                ;
            }
            goto L5; // [1237] 1304

            /** sequence.e:1889					case else*/
            case 0:
        ;}        goto L5; // [1244] 1304

        /** sequence.e:1894			case else*/
        case 0:

        /** sequence.e:1895				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4300)){
                _2233 = SEQ_PTR(_source_4300)->length;
        }
        else {
            _2233 = 1;
        }
        {
            object _a_4553;
            _a_4553 = 1;
L3F: 
            if (_a_4553 > _2233){
                goto L40; // [1255] 1303
            }

            /** sequence.e:1896					if call_func(rid, {source[a], userdata}) then*/
            _2 = (object)SEQ_PTR(_source_4300);
            _2234 = (object)*(((s1_ptr)_2)->base + _a_4553);
            Ref(_userdata_4302);
            Ref(_2234);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _2234;
            ((intptr_t *)_2)[2] = _userdata_4302;
            _2235 = MAKE_SEQ(_1);
            _2234 = NOVALUE;
            _1 = (object)SEQ_PTR(_2235);
            _2 = (object)((s1_ptr)_1)->base;
            _0 = (object)_00[_rid_4301].addr;
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            _1 = (*(intptr_t (*)())_0)(
                                *( ((intptr_t *)_2) + 1), 
                                *( ((intptr_t *)_2) + 2)
                                 );
            DeRef(_2236);
            _2236 = _1;
            DeRefDS(_2235);
            _2235 = NOVALUE;
            if (_2236 == 0) {
                DeRef(_2236);
                _2236 = NOVALUE;
                goto L41; // [1276] 1296
            }
            else {
                if (!IS_ATOM_INT(_2236) && DBL_PTR(_2236)->dbl == 0.0){
                    DeRef(_2236);
                    _2236 = NOVALUE;
                    goto L41; // [1276] 1296
                }
                DeRef(_2236);
                _2236 = NOVALUE;
            }
            DeRef(_2236);
            _2236 = NOVALUE;

            /** sequence.e:1897						idx += 1*/
            _idx_4305 = _idx_4305 + 1;

            /** sequence.e:1898						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4300);
            _2238 = (object)*(((s1_ptr)_2)->base + _a_4553);
            Ref(_2238);
            _2 = (object)SEQ_PTR(_dest_4304);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4305);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2238;
            if( _1 != _2238 ){
                DeRef(_1);
            }
            _2238 = NOVALUE;
L41: 

            /** sequence.e:1900				end for*/
            _a_4553 = _a_4553 + 1;
            goto L3F; // [1298] 1262
L40: 
            ;
        }
    ;}L5: 

    /** sequence.e:1902		return dest[1..idx]*/
    rhs_slice_target = (object_ptr)&_2239;
    RHS_Slice(_dest_4304, 1, _idx_4305);
    DeRefDS(_source_4300);
    DeRef(_userdata_4302);
    DeRef(_rangetype_4303);
    DeRefDS(_dest_4304);
    return _2239;
    ;
}


object _24filter_alpha(object _elem_4565, object _ud_4566)
{
    object _2240 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:1907		return t_alpha(elem)*/
    Ref(_elem_4565);
    _2240 = _9t_alpha(_elem_4565);
    DeRef(_elem_4565);
    return _2240;
    ;
}


object _24split(object _st_4610, object _delim_4611, object _no_empty_4612, object _limit_4613)
{
    object _ret_4614 = NOVALUE;
    object _start_4615 = NOVALUE;
    object _pos_4616 = NOVALUE;
    object _k_4668 = NOVALUE;
    object _2308 = NOVALUE;
    object _2306 = NOVALUE;
    object _2305 = NOVALUE;
    object _2301 = NOVALUE;
    object _2300 = NOVALUE;
    object _2299 = NOVALUE;
    object _2296 = NOVALUE;
    object _2295 = NOVALUE;
    object _2290 = NOVALUE;
    object _2289 = NOVALUE;
    object _2285 = NOVALUE;
    object _2281 = NOVALUE;
    object _2279 = NOVALUE;
    object _2278 = NOVALUE;
    object _2274 = NOVALUE;
    object _2272 = NOVALUE;
    object _2271 = NOVALUE;
    object _2270 = NOVALUE;
    object _2269 = NOVALUE;
    object _2266 = NOVALUE;
    object _2265 = NOVALUE;
    object _2264 = NOVALUE;
    object _2263 = NOVALUE;
    object _2262 = NOVALUE;
    object _2260 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:2088		sequence ret = {}*/
    RefDS(_5);
    DeRef(_ret_4614);
    _ret_4614 = _5;

    /** sequence.e:2092		if length(st) = 0 then*/
    if (IS_SEQUENCE(_st_4610)){
            _2260 = SEQ_PTR(_st_4610)->length;
    }
    else {
        _2260 = 1;
    }
    if (_2260 != 0)
    goto L1; // [19] 30

    /** sequence.e:2093			return ret*/
    DeRefDS(_st_4610);
    DeRefi(_delim_4611);
    return _ret_4614;
L1: 

    /** sequence.e:2097		if sequence(delim) then*/
    _2262 = IS_SEQUENCE(_delim_4611);
    if (_2262 == 0)
    {
        _2262 = NOVALUE;
        goto L2; // [35] 211
    }
    else{
        _2262 = NOVALUE;
    }

    /** sequence.e:2099			if equal(delim, "") then*/
    if (_delim_4611 == _5)
    _2263 = 1;
    else if (IS_ATOM_INT(_delim_4611) && IS_ATOM_INT(_5))
    _2263 = 0;
    else
    _2263 = (compare(_delim_4611, _5) == 0);
    if (_2263 == 0)
    {
        _2263 = NOVALUE;
        goto L3; // [44] 127
    }
    else{
        _2263 = NOVALUE;
    }

    /** sequence.e:2100				for i = 1 to length(st) do*/
    if (IS_SEQUENCE(_st_4610)){
            _2264 = SEQ_PTR(_st_4610)->length;
    }
    else {
        _2264 = 1;
    }
    {
        object _i_4625;
        _i_4625 = 1;
L4: 
        if (_i_4625 > _2264){
            goto L5; // [52] 120
        }

        /** sequence.e:2101					st[i] = {st[i]}*/
        _2 = (object)SEQ_PTR(_st_4610);
        _2265 = (object)*(((s1_ptr)_2)->base + _i_4625);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_2265);
        ((intptr_t*)_2)[1] = _2265;
        _2266 = MAKE_SEQ(_1);
        _2265 = NOVALUE;
        _2 = (object)SEQ_PTR(_st_4610);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _st_4610 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_4625);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _2266;
        if( _1 != _2266 ){
            DeRef(_1);
        }
        _2266 = NOVALUE;

        /** sequence.e:2102					limit -= 1*/
        _limit_4613 = _limit_4613 - 1;

        /** sequence.e:2103					if limit = 0 then*/
        if (_limit_4613 != 0)
        goto L6; // [81] 113

        /** sequence.e:2104						st = append(st[1 .. i],st[i+1 .. $])*/
        rhs_slice_target = (object_ptr)&_2269;
        RHS_Slice(_st_4610, 1, _i_4625);
        _2270 = _i_4625 + 1;
        if (IS_SEQUENCE(_st_4610)){
                _2271 = SEQ_PTR(_st_4610)->length;
        }
        else {
            _2271 = 1;
        }
        rhs_slice_target = (object_ptr)&_2272;
        RHS_Slice(_st_4610, _2270, _2271);
        RefDS(_2272);
        Append(&_st_4610, _2269, _2272);
        DeRefDS(_2269);
        _2269 = NOVALUE;
        DeRefDS(_2272);
        _2272 = NOVALUE;

        /** sequence.e:2105						exit*/
        goto L5; // [110] 120
L6: 

        /** sequence.e:2107				end for*/
        _i_4625 = _i_4625 + 1;
        goto L4; // [115] 59
L5: 
        ;
    }

    /** sequence.e:2109				return st*/
    DeRefi(_delim_4611);
    DeRef(_ret_4614);
    DeRef(_2270);
    _2270 = NOVALUE;
    return _st_4610;
L3: 

    /** sequence.e:2112			start = 1*/
    _start_4615 = 1;

    /** sequence.e:2113			while start <= length(st) do*/
L7: 
    if (IS_SEQUENCE(_st_4610)){
            _2274 = SEQ_PTR(_st_4610)->length;
    }
    else {
        _2274 = 1;
    }
    if (_start_4615 > _2274)
    goto L8; // [140] 290

    /** sequence.e:2114				pos = match(delim, st, start)*/
    _pos_4616 = e_match_from(_delim_4611, _st_4610, _start_4615);

    /** sequence.e:2116				if pos = 0 then*/
    if (_pos_4616 != 0)
    goto L9; // [153] 162

    /** sequence.e:2117					exit*/
    goto L8; // [159] 290
L9: 

    /** sequence.e:2120				ret = append(ret, st[start..pos-1])*/
    _2278 = _pos_4616 - 1;
    rhs_slice_target = (object_ptr)&_2279;
    RHS_Slice(_st_4610, _start_4615, _2278);
    RefDS(_2279);
    Append(&_ret_4614, _ret_4614, _2279);
    DeRefDS(_2279);
    _2279 = NOVALUE;

    /** sequence.e:2121				start = pos+length(delim)*/
    if (IS_SEQUENCE(_delim_4611)){
            _2281 = SEQ_PTR(_delim_4611)->length;
    }
    else {
        _2281 = 1;
    }
    _start_4615 = _pos_4616 + _2281;
    _2281 = NOVALUE;

    /** sequence.e:2122				limit -= 1*/
    _limit_4613 = _limit_4613 - 1;

    /** sequence.e:2123				if limit = 0 then*/
    if (_limit_4613 != 0)
    goto L7; // [194] 137

    /** sequence.e:2124					exit*/
    goto L8; // [200] 290

    /** sequence.e:2126			end while*/
    goto L7; // [205] 137
    goto L8; // [208] 290
L2: 

    /** sequence.e:2128			start = 1*/
    _start_4615 = 1;

    /** sequence.e:2129			while start <= length(st) do*/
LA: 
    if (IS_SEQUENCE(_st_4610)){
            _2285 = SEQ_PTR(_st_4610)->length;
    }
    else {
        _2285 = 1;
    }
    if (_start_4615 > _2285)
    goto LB; // [224] 289

    /** sequence.e:2130				pos = find(delim, st, start)*/
    _pos_4616 = find_from(_delim_4611, _st_4610, _start_4615);

    /** sequence.e:2132				if pos = 0 then*/
    if (_pos_4616 != 0)
    goto LC; // [237] 246

    /** sequence.e:2133					exit*/
    goto LB; // [243] 289
LC: 

    /** sequence.e:2136				ret = append(ret, st[start..pos-1])*/
    _2289 = _pos_4616 - 1;
    rhs_slice_target = (object_ptr)&_2290;
    RHS_Slice(_st_4610, _start_4615, _2289);
    RefDS(_2290);
    Append(&_ret_4614, _ret_4614, _2290);
    DeRefDS(_2290);
    _2290 = NOVALUE;

    /** sequence.e:2137				start = pos + 1*/
    _start_4615 = _pos_4616 + 1;

    /** sequence.e:2138				limit -= 1*/
    _limit_4613 = _limit_4613 - 1;

    /** sequence.e:2139				if limit = 0 then*/
    if (_limit_4613 != 0)
    goto LA; // [275] 221

    /** sequence.e:2140					exit*/
    goto LB; // [281] 289

    /** sequence.e:2142			end while*/
    goto LA; // [286] 221
LB: 
L8: 

    /** sequence.e:2145		ret = append(ret, st[start..$])*/
    if (IS_SEQUENCE(_st_4610)){
            _2295 = SEQ_PTR(_st_4610)->length;
    }
    else {
        _2295 = 1;
    }
    rhs_slice_target = (object_ptr)&_2296;
    RHS_Slice(_st_4610, _start_4615, _2295);
    RefDS(_2296);
    Append(&_ret_4614, _ret_4614, _2296);
    DeRefDS(_2296);
    _2296 = NOVALUE;

    /** sequence.e:2147		integer k = length(ret)*/
    if (IS_SEQUENCE(_ret_4614)){
            _k_4668 = SEQ_PTR(_ret_4614)->length;
    }
    else {
        _k_4668 = 1;
    }

    /** sequence.e:2148		if no_empty then*/
    if (_no_empty_4612 == 0)
    {
        goto LD; // [313] 378
    }
    else{
    }

    /** sequence.e:2149			k = 0*/
    _k_4668 = 0;

    /** sequence.e:2150			for i = 1 to length(ret) do*/
    if (IS_SEQUENCE(_ret_4614)){
            _2299 = SEQ_PTR(_ret_4614)->length;
    }
    else {
        _2299 = 1;
    }
    {
        object _i_4672;
        _i_4672 = 1;
LE: 
        if (_i_4672 > _2299){
            goto LF; // [326] 377
        }

        /** sequence.e:2151				if length(ret[i]) != 0 then*/
        _2 = (object)SEQ_PTR(_ret_4614);
        _2300 = (object)*(((s1_ptr)_2)->base + _i_4672);
        if (IS_SEQUENCE(_2300)){
                _2301 = SEQ_PTR(_2300)->length;
        }
        else {
            _2301 = 1;
        }
        _2300 = NOVALUE;
        if (_2301 == 0)
        goto L10; // [342] 370

        /** sequence.e:2152					k += 1*/
        _k_4668 = _k_4668 + 1;

        /** sequence.e:2153					if k != i then*/
        if (_k_4668 == _i_4672)
        goto L11; // [354] 369

        /** sequence.e:2154						ret[k] = ret[i]*/
        _2 = (object)SEQ_PTR(_ret_4614);
        _2305 = (object)*(((s1_ptr)_2)->base + _i_4672);
        Ref(_2305);
        _2 = (object)SEQ_PTR(_ret_4614);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _ret_4614 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _k_4668);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _2305;
        if( _1 != _2305 ){
            DeRef(_1);
        }
        _2305 = NOVALUE;
L11: 
L10: 

        /** sequence.e:2157			end for*/
        _i_4672 = _i_4672 + 1;
        goto LE; // [372] 333
LF: 
        ;
    }
LD: 

    /** sequence.e:2160		if k < length(ret) then*/
    if (IS_SEQUENCE(_ret_4614)){
            _2306 = SEQ_PTR(_ret_4614)->length;
    }
    else {
        _2306 = 1;
    }
    if (_k_4668 >= _2306)
    goto L12; // [383] 401

    /** sequence.e:2161			return ret[1 .. k]*/
    rhs_slice_target = (object_ptr)&_2308;
    RHS_Slice(_ret_4614, 1, _k_4668);
    DeRefDS(_st_4610);
    DeRefi(_delim_4611);
    DeRefDS(_ret_4614);
    DeRef(_2270);
    _2270 = NOVALUE;
    DeRef(_2289);
    _2289 = NOVALUE;
    DeRef(_2278);
    _2278 = NOVALUE;
    _2300 = NOVALUE;
    return _2308;
    goto L13; // [398] 408
L12: 

    /** sequence.e:2163			return ret*/
    DeRefDS(_st_4610);
    DeRefi(_delim_4611);
    DeRef(_2270);
    _2270 = NOVALUE;
    DeRef(_2289);
    _2289 = NOVALUE;
    DeRef(_2278);
    _2278 = NOVALUE;
    _2300 = NOVALUE;
    DeRef(_2308);
    _2308 = NOVALUE;
    return _ret_4614;
L13: 
    ;
}


object _24join(object _items_4737, object _delim_4738)
{
    object _ret_4740 = NOVALUE;
    object _2343 = NOVALUE;
    object _2342 = NOVALUE;
    object _2340 = NOVALUE;
    object _2339 = NOVALUE;
    object _2338 = NOVALUE;
    object _2337 = NOVALUE;
    object _2335 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:2279		if not length(items) then return {} end if*/
    if (IS_SEQUENCE(_items_4737)){
            _2335 = SEQ_PTR(_items_4737)->length;
    }
    else {
        _2335 = 1;
    }
    if (_2335 != 0)
    goto L1; // [8] 16
    _2335 = NOVALUE;
    RefDS(_5);
    DeRefDS(_items_4737);
    DeRef(_ret_4740);
    return _5;
L1: 

    /** sequence.e:2281		ret = {}*/
    RefDS(_5);
    DeRef(_ret_4740);
    _ret_4740 = _5;

    /** sequence.e:2282		for i=1 to length(items)-1 do*/
    if (IS_SEQUENCE(_items_4737)){
            _2337 = SEQ_PTR(_items_4737)->length;
    }
    else {
        _2337 = 1;
    }
    _2338 = _2337 - 1;
    _2337 = NOVALUE;
    {
        object _i_4745;
        _i_4745 = 1;
L2: 
        if (_i_4745 > _2338){
            goto L3; // [30] 58
        }

        /** sequence.e:2283			ret &= items[i] & delim*/
        _2 = (object)SEQ_PTR(_items_4737);
        _2339 = (object)*(((s1_ptr)_2)->base + _i_4745);
        if (IS_SEQUENCE(_2339) && IS_ATOM(_delim_4738)) {
            Append(&_2340, _2339, _delim_4738);
        }
        else if (IS_ATOM(_2339) && IS_SEQUENCE(_delim_4738)) {
        }
        else {
            Concat((object_ptr)&_2340, _2339, _delim_4738);
            _2339 = NOVALUE;
        }
        _2339 = NOVALUE;
        if (IS_SEQUENCE(_ret_4740) && IS_ATOM(_2340)) {
        }
        else if (IS_ATOM(_ret_4740) && IS_SEQUENCE(_2340)) {
            Ref(_ret_4740);
            Prepend(&_ret_4740, _2340, _ret_4740);
        }
        else {
            Concat((object_ptr)&_ret_4740, _ret_4740, _2340);
        }
        DeRefDS(_2340);
        _2340 = NOVALUE;

        /** sequence.e:2284		end for*/
        _i_4745 = _i_4745 + 1;
        goto L2; // [53] 37
L3: 
        ;
    }

    /** sequence.e:2286		ret &= items[$]*/
    if (IS_SEQUENCE(_items_4737)){
            _2342 = SEQ_PTR(_items_4737)->length;
    }
    else {
        _2342 = 1;
    }
    _2 = (object)SEQ_PTR(_items_4737);
    _2343 = (object)*(((s1_ptr)_2)->base + _2342);
    if (IS_SEQUENCE(_ret_4740) && IS_ATOM(_2343)) {
        Ref(_2343);
        Append(&_ret_4740, _ret_4740, _2343);
    }
    else if (IS_ATOM(_ret_4740) && IS_SEQUENCE(_2343)) {
        Ref(_ret_4740);
        Prepend(&_ret_4740, _2343, _ret_4740);
    }
    else {
        Concat((object_ptr)&_ret_4740, _ret_4740, _2343);
    }
    _2343 = NOVALUE;

    /** sequence.e:2288		return ret*/
    DeRefDS(_items_4737);
    DeRef(_2338);
    _2338 = NOVALUE;
    return _ret_4740;
    ;
}


object _24flatten(object _s_4847, object _delim_4848)
{
    object _ret_4849 = NOVALUE;
    object _x_4850 = NOVALUE;
    object _len_4851 = NOVALUE;
    object _pos_4852 = NOVALUE;
    object _temp_4870 = NOVALUE;
    object _2429 = NOVALUE;
    object _2428 = NOVALUE;
    object _2427 = NOVALUE;
    object _2425 = NOVALUE;
    object _2424 = NOVALUE;
    object _2423 = NOVALUE;
    object _2421 = NOVALUE;
    object _2419 = NOVALUE;
    object _2418 = NOVALUE;
    object _2417 = NOVALUE;
    object _2415 = NOVALUE;
    object _2414 = NOVALUE;
    object _2413 = NOVALUE;
    object _2412 = NOVALUE;
    object _2411 = NOVALUE;
    object _2410 = NOVALUE;
    object _2408 = NOVALUE;
    object _2407 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:2491		ret = s*/
    RefDS(_s_4847);
    DeRef(_ret_4849);
    _ret_4849 = _s_4847;

    /** sequence.e:2492		pos = 1*/
    _pos_4852 = 1;

    /** sequence.e:2493		len = length(ret)*/
    if (IS_SEQUENCE(_ret_4849)){
            _len_4851 = SEQ_PTR(_ret_4849)->length;
    }
    else {
        _len_4851 = 1;
    }

    /** sequence.e:2494		while pos <= len do*/
L1: 
    if (_pos_4852 > _len_4851)
    goto L2; // [25] 183

    /** sequence.e:2495			x = ret[pos]*/
    DeRef(_x_4850);
    _2 = (object)SEQ_PTR(_ret_4849);
    _x_4850 = (object)*(((s1_ptr)_2)->base + _pos_4852);
    Ref(_x_4850);

    /** sequence.e:2496			if sequence(x) then*/
    _2407 = IS_SEQUENCE(_x_4850);
    if (_2407 == 0)
    {
        _2407 = NOVALUE;
        goto L3; // [40] 171
    }
    else{
        _2407 = NOVALUE;
    }

    /** sequence.e:2497				if length(delim) = 0 then*/
    if (IS_SEQUENCE(_delim_4848)){
            _2408 = SEQ_PTR(_delim_4848)->length;
    }
    else {
        _2408 = 1;
    }
    if (_2408 != 0)
    goto L4; // [48] 89

    /** sequence.e:2498					ret = ret[1..pos-1] & flatten(x) & ret[pos+1 .. $]*/
    _2410 = _pos_4852 - 1;
    rhs_slice_target = (object_ptr)&_2411;
    RHS_Slice(_ret_4849, 1, _2410);
    Ref(_x_4850);
    RefDS(_5);
    _2412 = _24flatten(_x_4850, _5);
    _2413 = _pos_4852 + 1;
    if (_2413 > MAXINT){
        _2413 = NewDouble((eudouble)_2413);
    }
    if (IS_SEQUENCE(_ret_4849)){
            _2414 = SEQ_PTR(_ret_4849)->length;
    }
    else {
        _2414 = 1;
    }
    rhs_slice_target = (object_ptr)&_2415;
    RHS_Slice(_ret_4849, _2413, _2414);
    {
        object concat_list[3];

        concat_list[0] = _2415;
        concat_list[1] = _2412;
        concat_list[2] = _2411;
        Concat_N((object_ptr)&_ret_4849, concat_list, 3);
    }
    DeRefDS(_2415);
    _2415 = NOVALUE;
    DeRef(_2412);
    _2412 = NOVALUE;
    DeRefDS(_2411);
    _2411 = NOVALUE;
    goto L5; // [86] 163
L4: 

    /** sequence.e:2500					sequence temp = ret[1..pos-1] & flatten(x)*/
    _2417 = _pos_4852 - 1;
    rhs_slice_target = (object_ptr)&_2418;
    RHS_Slice(_ret_4849, 1, _2417);
    Ref(_x_4850);
    RefDS(_5);
    _2419 = _24flatten(_x_4850, _5);
    if (IS_SEQUENCE(_2418) && IS_ATOM(_2419)) {
        Ref(_2419);
        Append(&_temp_4870, _2418, _2419);
    }
    else if (IS_ATOM(_2418) && IS_SEQUENCE(_2419)) {
    }
    else {
        Concat((object_ptr)&_temp_4870, _2418, _2419);
        DeRefDS(_2418);
        _2418 = NOVALUE;
    }
    DeRef(_2418);
    _2418 = NOVALUE;
    DeRef(_2419);
    _2419 = NOVALUE;

    /** sequence.e:2501					if pos != length(ret) then*/
    if (IS_SEQUENCE(_ret_4849)){
            _2421 = SEQ_PTR(_ret_4849)->length;
    }
    else {
        _2421 = 1;
    }
    if (_pos_4852 == _2421)
    goto L6; // [114] 141

    /** sequence.e:2502						ret = temp &  delim & ret[pos+1 .. $]*/
    _2423 = _pos_4852 + 1;
    if (_2423 > MAXINT){
        _2423 = NewDouble((eudouble)_2423);
    }
    if (IS_SEQUENCE(_ret_4849)){
            _2424 = SEQ_PTR(_ret_4849)->length;
    }
    else {
        _2424 = 1;
    }
    rhs_slice_target = (object_ptr)&_2425;
    RHS_Slice(_ret_4849, _2423, _2424);
    {
        object concat_list[3];

        concat_list[0] = _2425;
        concat_list[1] = _delim_4848;
        concat_list[2] = _temp_4870;
        Concat_N((object_ptr)&_ret_4849, concat_list, 3);
    }
    DeRefDS(_2425);
    _2425 = NOVALUE;
    goto L7; // [138] 160
L6: 

    /** sequence.e:2504						ret = temp & ret[pos+1 .. $]*/
    _2427 = _pos_4852 + 1;
    if (_2427 > MAXINT){
        _2427 = NewDouble((eudouble)_2427);
    }
    if (IS_SEQUENCE(_ret_4849)){
            _2428 = SEQ_PTR(_ret_4849)->length;
    }
    else {
        _2428 = 1;
    }
    rhs_slice_target = (object_ptr)&_2429;
    RHS_Slice(_ret_4849, _2427, _2428);
    Concat((object_ptr)&_ret_4849, _temp_4870, _2429);
    DeRefDS(_2429);
    _2429 = NOVALUE;
L7: 
    DeRef(_temp_4870);
    _temp_4870 = NOVALUE;
L5: 

    /** sequence.e:2507				len = length(ret)*/
    if (IS_SEQUENCE(_ret_4849)){
            _len_4851 = SEQ_PTR(_ret_4849)->length;
    }
    else {
        _len_4851 = 1;
    }
    goto L1; // [168] 25
L3: 

    /** sequence.e:2509				pos += 1*/
    _pos_4852 = _pos_4852 + 1;

    /** sequence.e:2511		end while*/
    goto L1; // [180] 25
L2: 

    /** sequence.e:2513		return ret*/
    DeRefDS(_s_4847);
    DeRefi(_delim_4848);
    DeRef(_x_4850);
    DeRef(_2427);
    _2427 = NOVALUE;
    DeRef(_2423);
    _2423 = NOVALUE;
    DeRef(_2410);
    _2410 = NOVALUE;
    DeRef(_2413);
    _2413 = NOVALUE;
    DeRef(_2417);
    _2417 = NOVALUE;
    return _ret_4849;
    ;
}


object _24remove_dups(object _source_data_5217, object _proc_option_5218)
{
    object _lTo_5219 = NOVALUE;
    object _lFrom_5220 = NOVALUE;
    object _lResult_5243 = NOVALUE;
    object _2658 = NOVALUE;
    object _2656 = NOVALUE;
    object _2655 = NOVALUE;
    object _2654 = NOVALUE;
    object _2653 = NOVALUE;
    object _2651 = NOVALUE;
    object _2647 = NOVALUE;
    object _2646 = NOVALUE;
    object _2645 = NOVALUE;
    object _2643 = NOVALUE;
    object _2638 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:3111		if length(source_data) < 2 then*/
    if (IS_SEQUENCE(_source_data_5217)){
            _2638 = SEQ_PTR(_source_data_5217)->length;
    }
    else {
        _2638 = 1;
    }
    if (_2638 >= 2)
    goto L1; // [10] 21

    /** sequence.e:3112			return source_data*/
    DeRef(_lResult_5243);
    return _source_data_5217;
L1: 

    /** sequence.e:3115		if proc_option = RD_SORT then*/
    if (_proc_option_5218 != 3)
    goto L2; // [23] 42

    /** sequence.e:3116			source_data = stdsort:sort(source_data)*/
    RefDS(_source_data_5217);
    _0 = _source_data_5217;
    _source_data_5217 = _25sort(_source_data_5217, 1);
    DeRefDS(_0);

    /** sequence.e:3117			proc_option = RD_PRESORTED*/
    _proc_option_5218 = 2;
L2: 

    /** sequence.e:3119		if proc_option = RD_PRESORTED then*/
    if (_proc_option_5218 != 2)
    goto L3; // [44] 134

    /** sequence.e:3120			lTo = 1*/
    _lTo_5219 = 1;

    /** sequence.e:3121			lFrom = 2*/
    _lFrom_5220 = 2;

    /** sequence.e:3123			while lFrom <= length(source_data) do*/
L4: 
    if (IS_SEQUENCE(_source_data_5217)){
            _2643 = SEQ_PTR(_source_data_5217)->length;
    }
    else {
        _2643 = 1;
    }
    if (_lFrom_5220 > _2643)
    goto L5; // [66] 122

    /** sequence.e:3124				if not equal(source_data[lFrom], source_data[lTo]) then*/
    _2 = (object)SEQ_PTR(_source_data_5217);
    _2645 = (object)*(((s1_ptr)_2)->base + _lFrom_5220);
    _2 = (object)SEQ_PTR(_source_data_5217);
    _2646 = (object)*(((s1_ptr)_2)->base + _lTo_5219);
    if (_2645 == _2646)
    _2647 = 1;
    else if (IS_ATOM_INT(_2645) && IS_ATOM_INT(_2646))
    _2647 = 0;
    else
    _2647 = (compare(_2645, _2646) == 0);
    _2645 = NOVALUE;
    _2646 = NOVALUE;
    if (_2647 != 0)
    goto L6; // [84] 111
    _2647 = NOVALUE;

    /** sequence.e:3125					lTo += 1*/
    _lTo_5219 = _lTo_5219 + 1;

    /** sequence.e:3126					if lTo != lFrom then*/
    if (_lTo_5219 == _lFrom_5220)
    goto L7; // [95] 110

    /** sequence.e:3127						source_data[lTo] = source_data[lFrom]*/
    _2 = (object)SEQ_PTR(_source_data_5217);
    _2651 = (object)*(((s1_ptr)_2)->base + _lFrom_5220);
    Ref(_2651);
    _2 = (object)SEQ_PTR(_source_data_5217);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _source_data_5217 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _lTo_5219);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _2651;
    if( _1 != _2651 ){
        DeRef(_1);
    }
    _2651 = NOVALUE;
L7: 
L6: 

    /** sequence.e:3130				lFrom += 1*/
    _lFrom_5220 = _lFrom_5220 + 1;

    /** sequence.e:3131			end while*/
    goto L4; // [119] 63
L5: 

    /** sequence.e:3132			return source_data[1 .. lTo]*/
    rhs_slice_target = (object_ptr)&_2653;
    RHS_Slice(_source_data_5217, 1, _lTo_5219);
    DeRefDS(_source_data_5217);
    DeRef(_lResult_5243);
    return _2653;
L3: 

    /** sequence.e:3135		sequence lResult*/

    /** sequence.e:3136		lResult = {}*/
    RefDS(_5);
    DeRef(_lResult_5243);
    _lResult_5243 = _5;

    /** sequence.e:3137		for i = 1 to length(source_data) do*/
    if (IS_SEQUENCE(_source_data_5217)){
            _2654 = SEQ_PTR(_source_data_5217)->length;
    }
    else {
        _2654 = 1;
    }
    {
        object _i_5245;
        _i_5245 = 1;
L8: 
        if (_i_5245 > _2654){
            goto L9; // [148] 187
        }

        /** sequence.e:3138			if not find(source_data[i], lResult) then*/
        _2 = (object)SEQ_PTR(_source_data_5217);
        _2655 = (object)*(((s1_ptr)_2)->base + _i_5245);
        _2656 = find_from(_2655, _lResult_5243, 1);
        _2655 = NOVALUE;
        if (_2656 != 0)
        goto LA; // [166] 180
        _2656 = NOVALUE;

        /** sequence.e:3139				lResult = append(lResult, source_data[i])*/
        _2 = (object)SEQ_PTR(_source_data_5217);
        _2658 = (object)*(((s1_ptr)_2)->base + _i_5245);
        Ref(_2658);
        Append(&_lResult_5243, _lResult_5243, _2658);
        _2658 = NOVALUE;
LA: 

        /** sequence.e:3141		end for*/
        _i_5245 = _i_5245 + 1;
        goto L8; // [182] 155
L9: 
        ;
    }

    /** sequence.e:3142		return lResult*/
    DeRefDS(_source_data_5217);
    DeRef(_2653);
    _2653 = NOVALUE;
    return _lResult_5243;
    ;
}



// 0x7A3BFCB8
