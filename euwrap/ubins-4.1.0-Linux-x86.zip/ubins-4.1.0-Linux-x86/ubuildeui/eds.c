// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _41fatal(object _errcode_15761, object _msg_15762, object _routine_name_15763, object _parms_15764)
{
    object _8971 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:231		vLastErrors = append(vLastErrors, {errcode, msg, routine_name, parms})*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _errcode_15761;
    RefDS(_msg_15762);
    ((intptr_t*)_2)[2] = _msg_15762;
    RefDS(_routine_name_15763);
    ((intptr_t*)_2)[3] = _routine_name_15763;
    RefDS(_parms_15764);
    ((intptr_t*)_2)[4] = _parms_15764;
    _8971 = MAKE_SEQ(_1);
    RefDS(_8971);
    Append(&_41vLastErrors_15758, _41vLastErrors_15758, _8971);
    DeRefDS(_8971);
    _8971 = NOVALUE;

    /** eds.e:232		if db_fatal_id >= 0 then*/

    /** eds.e:235	end procedure*/
    DeRefDSi(_msg_15762);
    DeRefDSi(_routine_name_15763);
    DeRefDS(_parms_15764);
    return;
    ;
}


object _41get4()
{
    object _8987 = NOVALUE;
    object _8986 = NOVALUE;
    object _8985 = NOVALUE;
    object _8984 = NOVALUE;
    object _8983 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:250		poke(mem0, getc(current_db))*/
    if (_41current_db_15734 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
        last_r_file_no = _41current_db_15734;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _8983 = getc((FILE*)xstdin);
        }
        else{
            _8983 = getc(last_r_file_ptr);
        }
    }
    else{
        _8983 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_41mem0_15776)){
        poke_addr = (uint8_t *)_41mem0_15776;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    *poke_addr = (uint8_t)_8983;
    _8983 = NOVALUE;

    /** eds.e:251		poke(mem1, getc(current_db))*/
    if (_41current_db_15734 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
        last_r_file_no = _41current_db_15734;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _8984 = getc((FILE*)xstdin);
        }
        else{
            _8984 = getc(last_r_file_ptr);
        }
    }
    else{
        _8984 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_41mem1_15777)){
        poke_addr = (uint8_t *)_41mem1_15777;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_41mem1_15777)->dbl);
    }
    *poke_addr = (uint8_t)_8984;
    _8984 = NOVALUE;

    /** eds.e:252		poke(mem2, getc(current_db))*/
    if (_41current_db_15734 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
        last_r_file_no = _41current_db_15734;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _8985 = getc((FILE*)xstdin);
        }
        else{
            _8985 = getc(last_r_file_ptr);
        }
    }
    else{
        _8985 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_41mem2_15778)){
        poke_addr = (uint8_t *)_41mem2_15778;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_41mem2_15778)->dbl);
    }
    *poke_addr = (uint8_t)_8985;
    _8985 = NOVALUE;

    /** eds.e:253		poke(mem3, getc(current_db))*/
    if (_41current_db_15734 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
        last_r_file_no = _41current_db_15734;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _8986 = getc((FILE*)xstdin);
        }
        else{
            _8986 = getc(last_r_file_ptr);
        }
    }
    else{
        _8986 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_41mem3_15779)){
        poke_addr = (uint8_t *)_41mem3_15779;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_41mem3_15779)->dbl);
    }
    *poke_addr = (uint8_t)_8986;
    _8986 = NOVALUE;

    /** eds.e:254		return peek4u(mem0)*/
    if (IS_ATOM_INT(_41mem0_15776)) {
        _8987 = (object)*(uint32_t *)_41mem0_15776;
        if ((uintptr_t)_8987 > (uintptr_t)MAXINT){
            _8987 = NewDouble((eudouble)(uintptr_t)_8987);
        }
    }
    else {
        _8987 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
        if ((uintptr_t)_8987 > (uintptr_t)MAXINT){
            _8987 = NewDouble((eudouble)(uintptr_t)_8987);
        }
    }
    return _8987;
    ;
}


object _41get_string()
{
    object _where_inlined_where_at_31_15804 = NOVALUE;
    object _s_15793 = NOVALUE;
    object _c_15794 = NOVALUE;
    object _i_15795 = NOVALUE;
    object _9000 = NOVALUE;
    object _8997 = NOVALUE;
    object _8995 = NOVALUE;
    object _8993 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:263		s = repeat(0, 256)*/
    DeRefi(_s_15793);
    _s_15793 = Repeat(0, 256);

    /** eds.e:264		i = 0*/
    _i_15795 = 0;

    /** eds.e:265		while c with entry do*/
    goto L1; // [14] 89
L2: 
    if (_c_15794 == 0)
    {
        goto L3; // [19] 101
    }
    else{
    }

    /** eds.e:266			if c = -1 then*/
    if (_c_15794 != -1)
    goto L4; // [24] 54

    /** eds.e:267				fatal(MISSING_END, "string is missing 0 terminator", "get_string", {io:where(current_db)})*/

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_31_15804);
    _where_inlined_where_at_31_15804 = machine(20, _41current_db_15734);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_31_15804);
    ((intptr_t*)_2)[1] = _where_inlined_where_at_31_15804;
    _8993 = MAKE_SEQ(_1);
    RefDS(_8991);
    RefDS(_8992);
    _41fatal(900, _8991, _8992, _8993);
    _8993 = NOVALUE;

    /** eds.e:268				exit*/
    goto L3; // [51] 101
L4: 

    /** eds.e:270			i += 1*/
    _i_15795 = _i_15795 + 1;

    /** eds.e:271			if i > length(s) then*/
    if (IS_SEQUENCE(_s_15793)){
            _8995 = SEQ_PTR(_s_15793)->length;
    }
    else {
        _8995 = 1;
    }
    if (_i_15795 <= _8995)
    goto L5; // [65] 80

    /** eds.e:272				s &= repeat(0, 256)*/
    _8997 = Repeat(0, 256);
    Concat((object_ptr)&_s_15793, _s_15793, _8997);
    DeRefDS(_8997);
    _8997 = NOVALUE;
L5: 

    /** eds.e:274			s[i] = c*/
    _2 = (object)SEQ_PTR(_s_15793);
    _2 = (object)(((s1_ptr)_2)->base + _i_15795);
    *(intptr_t *)_2 = _c_15794;

    /** eds.e:275		  entry*/
L1: 

    /** eds.e:276			c = getc(current_db)*/
    if (_41current_db_15734 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
        last_r_file_no = _41current_db_15734;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_15794 = getc((FILE*)xstdin);
        }
        else{
            _c_15794 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_15794 = getc(last_r_file_ptr);
    }

    /** eds.e:277		end while*/
    goto L2; // [98] 17
L3: 

    /** eds.e:278		return s[1..i]*/
    rhs_slice_target = (object_ptr)&_9000;
    RHS_Slice(_s_15793, 1, _i_15795);
    DeRefDSi(_s_15793);
    return _9000;
    ;
}


object _41equal_string(object _target_15816)
{
    object _c_15817 = NOVALUE;
    object _i_15818 = NOVALUE;
    object _where_inlined_where_at_27_15824 = NOVALUE;
    object _9011 = NOVALUE;
    object _9010 = NOVALUE;
    object _9007 = NOVALUE;
    object _9005 = NOVALUE;
    object _9003 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:286		i = 0*/
    _i_15818 = 0;

    /** eds.e:287		while c with entry do*/
    goto L1; // [10] 94
L2: 
    if (_c_15817 == 0)
    {
        goto L3; // [15] 106
    }
    else{
    }

    /** eds.e:288			if c = -1 then*/
    if (_c_15817 != -1)
    goto L4; // [20] 52

    /** eds.e:289				fatal(MISSING_END, "string is missing 0 terminator", "equal_string", {io:where(current_db)})*/

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_27_15824);
    _where_inlined_where_at_27_15824 = machine(20, _41current_db_15734);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_27_15824);
    ((intptr_t*)_2)[1] = _where_inlined_where_at_27_15824;
    _9003 = MAKE_SEQ(_1);
    RefDS(_8991);
    RefDS(_9002);
    _41fatal(900, _8991, _9002, _9003);
    _9003 = NOVALUE;

    /** eds.e:290				return DB_FATAL_FAIL*/
    DeRefDS(_target_15816);
    return -404;
L4: 

    /** eds.e:292			i += 1*/
    _i_15818 = _i_15818 + 1;

    /** eds.e:293			if i > length(target) then*/
    if (IS_SEQUENCE(_target_15816)){
            _9005 = SEQ_PTR(_target_15816)->length;
    }
    else {
        _9005 = 1;
    }
    if (_i_15818 <= _9005)
    goto L5; // [63] 74

    /** eds.e:294				return 0*/
    DeRefDS(_target_15816);
    return 0;
L5: 

    /** eds.e:296			if target[i] != c then*/
    _2 = (object)SEQ_PTR(_target_15816);
    _9007 = (object)*(((s1_ptr)_2)->base + _i_15818);
    if (binary_op_a(EQUALS, _9007, _c_15817)){
        _9007 = NOVALUE;
        goto L6; // [80] 91
    }
    _9007 = NOVALUE;

    /** eds.e:297				return 0*/
    DeRefDS(_target_15816);
    return 0;
L6: 

    /** eds.e:299		  entry*/
L1: 

    /** eds.e:300			c = getc(current_db)*/
    if (_41current_db_15734 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
        last_r_file_no = _41current_db_15734;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_15817 = getc((FILE*)xstdin);
        }
        else{
            _c_15817 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_15817 = getc(last_r_file_ptr);
    }

    /** eds.e:301		end while*/
    goto L2; // [103] 13
L3: 

    /** eds.e:302		return (i = length(target))*/
    if (IS_SEQUENCE(_target_15816)){
            _9010 = SEQ_PTR(_target_15816)->length;
    }
    else {
        _9010 = 1;
    }
    _9011 = (_i_15818 == _9010);
    _9010 = NOVALUE;
    DeRefDS(_target_15816);
    return _9011;
    ;
}


object _41decompress(object _c_15864)
{
    object _s_15865 = NOVALUE;
    object _len_15866 = NOVALUE;
    object _float32_to_atom_inlined_float32_to_atom_at_176_15902 = NOVALUE;
    object _ieee32_inlined_float32_to_atom_at_173_15901 = NOVALUE;
    object _float64_to_atom_inlined_float64_to_atom_at_251_15915 = NOVALUE;
    object _ieee64_inlined_float64_to_atom_at_248_15914 = NOVALUE;
    object _9069 = NOVALUE;
    object _9068 = NOVALUE;
    object _9067 = NOVALUE;
    object _9064 = NOVALUE;
    object _9059 = NOVALUE;
    object _9058 = NOVALUE;
    object _9057 = NOVALUE;
    object _9056 = NOVALUE;
    object _9055 = NOVALUE;
    object _9054 = NOVALUE;
    object _9053 = NOVALUE;
    object _9052 = NOVALUE;
    object _9051 = NOVALUE;
    object _9050 = NOVALUE;
    object _9049 = NOVALUE;
    object _9048 = NOVALUE;
    object _9047 = NOVALUE;
    object _9046 = NOVALUE;
    object _9045 = NOVALUE;
    object _9044 = NOVALUE;
    object _9043 = NOVALUE;
    object _9042 = NOVALUE;
    object _9041 = NOVALUE;
    object _9040 = NOVALUE;
    object _9038 = NOVALUE;
    object _9037 = NOVALUE;
    object _9036 = NOVALUE;
    object _9035 = NOVALUE;
    object _9034 = NOVALUE;
    object _9033 = NOVALUE;
    object _9032 = NOVALUE;
    object _9031 = NOVALUE;
    object _9030 = NOVALUE;
    object _9027 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:332		if c = 0 then*/
    if (_c_15864 != 0)
    goto L1; // [5] 34

    /** eds.e:333			c = getc(current_db)*/
    if (_41current_db_15734 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
        last_r_file_no = _41current_db_15734;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_15864 = getc((FILE*)xstdin);
        }
        else{
            _c_15864 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_15864 = getc(last_r_file_ptr);
    }

    /** eds.e:334			if c < I2B then*/
    if (_c_15864 >= 249)
    goto L2; // [18] 33

    /** eds.e:335				return c + MIN1B*/
    _9027 = _c_15864 + -9;
    DeRef(_s_15865);
    return _9027;
L2: 
L1: 

    /** eds.e:339		switch c with fallthru do*/
    _0 = _c_15864;
    switch ( _0 ){ 

        /** eds.e:340			case I2B then*/
        case 249:

        /** eds.e:341				return getc(current_db) +*/
        if (_41current_db_15734 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
            last_r_file_no = _41current_db_15734;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9030 = getc((FILE*)xstdin);
            }
            else{
                _9030 = getc(last_r_file_ptr);
            }
        }
        else{
            _9030 = getc(last_r_file_ptr);
        }
        if (_41current_db_15734 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
            last_r_file_no = _41current_db_15734;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9031 = getc((FILE*)xstdin);
            }
            else{
                _9031 = getc(last_r_file_ptr);
            }
        }
        else{
            _9031 = getc(last_r_file_ptr);
        }
        _9032 = 256 * _9031;
        _9031 = NOVALUE;
        _9033 = _9030 + _9032;
        _9030 = NOVALUE;
        _9032 = NOVALUE;
        _9034 = _9033 + _41MIN2B_15847;
        if ((object)((uintptr_t)_9034 + (uintptr_t)HIGH_BITS) >= 0){
            _9034 = NewDouble((eudouble)_9034);
        }
        _9033 = NOVALUE;
        DeRef(_s_15865);
        DeRef(_9027);
        _9027 = NOVALUE;
        return _9034;

        /** eds.e:345			case I3B then*/
        case 250:

        /** eds.e:346				return getc(current_db) +*/
        if (_41current_db_15734 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
            last_r_file_no = _41current_db_15734;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9035 = getc((FILE*)xstdin);
            }
            else{
                _9035 = getc(last_r_file_ptr);
            }
        }
        else{
            _9035 = getc(last_r_file_ptr);
        }
        if (_41current_db_15734 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
            last_r_file_no = _41current_db_15734;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9036 = getc((FILE*)xstdin);
            }
            else{
                _9036 = getc(last_r_file_ptr);
            }
        }
        else{
            _9036 = getc(last_r_file_ptr);
        }
        _9037 = 256 * _9036;
        _9036 = NOVALUE;
        _9038 = _9035 + _9037;
        _9035 = NOVALUE;
        _9037 = NOVALUE;
        if (_41current_db_15734 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
            last_r_file_no = _41current_db_15734;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9040 = getc((FILE*)xstdin);
            }
            else{
                _9040 = getc(last_r_file_ptr);
            }
        }
        else{
            _9040 = getc(last_r_file_ptr);
        }
        _9041 = 65536 * _9040;
        _9040 = NOVALUE;
        _9042 = _9038 + _9041;
        _9038 = NOVALUE;
        _9041 = NOVALUE;
        _9043 = _9042 + _41MIN3B_15853;
        if ((object)((uintptr_t)_9043 + (uintptr_t)HIGH_BITS) >= 0){
            _9043 = NewDouble((eudouble)_9043);
        }
        _9042 = NOVALUE;
        DeRef(_s_15865);
        DeRef(_9034);
        _9034 = NOVALUE;
        DeRef(_9027);
        _9027 = NOVALUE;
        return _9043;

        /** eds.e:351			case I4B then*/
        case 251:

        /** eds.e:352				return get4() + MIN4B*/
        _9044 = _41get4();
        if (IS_ATOM_INT(_9044) && IS_ATOM_INT(_41MIN4B_15859)) {
            _9045 = _9044 + _41MIN4B_15859;
            if ((object)((uintptr_t)_9045 + (uintptr_t)HIGH_BITS) >= 0){
                _9045 = NewDouble((eudouble)_9045);
            }
        }
        else {
            _9045 = binary_op(PLUS, _9044, _41MIN4B_15859);
        }
        DeRef(_9044);
        _9044 = NOVALUE;
        DeRef(_s_15865);
        DeRef(_9034);
        _9034 = NOVALUE;
        DeRef(_9027);
        _9027 = NOVALUE;
        DeRef(_9043);
        _9043 = NOVALUE;
        return _9045;

        /** eds.e:354			case F4B then*/
        case 252:

        /** eds.e:355				return convert:float32_to_atom({getc(current_db), getc(current_db),*/
        if (_41current_db_15734 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
            last_r_file_no = _41current_db_15734;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9046 = getc((FILE*)xstdin);
            }
            else{
                _9046 = getc(last_r_file_ptr);
            }
        }
        else{
            _9046 = getc(last_r_file_ptr);
        }
        if (_41current_db_15734 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
            last_r_file_no = _41current_db_15734;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9047 = getc((FILE*)xstdin);
            }
            else{
                _9047 = getc(last_r_file_ptr);
            }
        }
        else{
            _9047 = getc(last_r_file_ptr);
        }
        if (_41current_db_15734 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
            last_r_file_no = _41current_db_15734;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9048 = getc((FILE*)xstdin);
            }
            else{
                _9048 = getc(last_r_file_ptr);
            }
        }
        else{
            _9048 = getc(last_r_file_ptr);
        }
        if (_41current_db_15734 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
            last_r_file_no = _41current_db_15734;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9049 = getc((FILE*)xstdin);
            }
            else{
                _9049 = getc(last_r_file_ptr);
            }
        }
        else{
            _9049 = getc(last_r_file_ptr);
        }
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _9046;
        ((intptr_t*)_2)[2] = _9047;
        ((intptr_t*)_2)[3] = _9048;
        ((intptr_t*)_2)[4] = _9049;
        _9050 = MAKE_SEQ(_1);
        _9049 = NOVALUE;
        _9048 = NOVALUE;
        _9047 = NOVALUE;
        _9046 = NOVALUE;
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_15901);
        _ieee32_inlined_float32_to_atom_at_173_15901 = _9050;
        _9050 = NOVALUE;

        /** convert.e:374		return machine_func(M_F32_TO_A, ieee32)*/
        DeRef(_float32_to_atom_inlined_float32_to_atom_at_176_15902);
        _float32_to_atom_inlined_float32_to_atom_at_176_15902 = machine(49, _ieee32_inlined_float32_to_atom_at_173_15901);
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_15901);
        _ieee32_inlined_float32_to_atom_at_173_15901 = NOVALUE;
        DeRef(_s_15865);
        DeRef(_9045);
        _9045 = NOVALUE;
        DeRef(_9034);
        _9034 = NOVALUE;
        DeRef(_9027);
        _9027 = NOVALUE;
        DeRef(_9043);
        _9043 = NOVALUE;
        return _float32_to_atom_inlined_float32_to_atom_at_176_15902;

        /** eds.e:358			case F8B then*/
        case 253:

        /** eds.e:359				return convert:float64_to_atom({getc(current_db), getc(current_db),*/
        if (_41current_db_15734 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
            last_r_file_no = _41current_db_15734;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9051 = getc((FILE*)xstdin);
            }
            else{
                _9051 = getc(last_r_file_ptr);
            }
        }
        else{
            _9051 = getc(last_r_file_ptr);
        }
        if (_41current_db_15734 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
            last_r_file_no = _41current_db_15734;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9052 = getc((FILE*)xstdin);
            }
            else{
                _9052 = getc(last_r_file_ptr);
            }
        }
        else{
            _9052 = getc(last_r_file_ptr);
        }
        if (_41current_db_15734 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
            last_r_file_no = _41current_db_15734;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9053 = getc((FILE*)xstdin);
            }
            else{
                _9053 = getc(last_r_file_ptr);
            }
        }
        else{
            _9053 = getc(last_r_file_ptr);
        }
        if (_41current_db_15734 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
            last_r_file_no = _41current_db_15734;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9054 = getc((FILE*)xstdin);
            }
            else{
                _9054 = getc(last_r_file_ptr);
            }
        }
        else{
            _9054 = getc(last_r_file_ptr);
        }
        if (_41current_db_15734 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
            last_r_file_no = _41current_db_15734;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9055 = getc((FILE*)xstdin);
            }
            else{
                _9055 = getc(last_r_file_ptr);
            }
        }
        else{
            _9055 = getc(last_r_file_ptr);
        }
        if (_41current_db_15734 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
            last_r_file_no = _41current_db_15734;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9056 = getc((FILE*)xstdin);
            }
            else{
                _9056 = getc(last_r_file_ptr);
            }
        }
        else{
            _9056 = getc(last_r_file_ptr);
        }
        if (_41current_db_15734 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
            last_r_file_no = _41current_db_15734;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9057 = getc((FILE*)xstdin);
            }
            else{
                _9057 = getc(last_r_file_ptr);
            }
        }
        else{
            _9057 = getc(last_r_file_ptr);
        }
        if (_41current_db_15734 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
            last_r_file_no = _41current_db_15734;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9058 = getc((FILE*)xstdin);
            }
            else{
                _9058 = getc(last_r_file_ptr);
            }
        }
        else{
            _9058 = getc(last_r_file_ptr);
        }
        _1 = NewS1(8);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _9051;
        ((intptr_t*)_2)[2] = _9052;
        ((intptr_t*)_2)[3] = _9053;
        ((intptr_t*)_2)[4] = _9054;
        ((intptr_t*)_2)[5] = _9055;
        ((intptr_t*)_2)[6] = _9056;
        ((intptr_t*)_2)[7] = _9057;
        ((intptr_t*)_2)[8] = _9058;
        _9059 = MAKE_SEQ(_1);
        _9058 = NOVALUE;
        _9057 = NOVALUE;
        _9056 = NOVALUE;
        _9055 = NOVALUE;
        _9054 = NOVALUE;
        _9053 = NOVALUE;
        _9052 = NOVALUE;
        _9051 = NOVALUE;
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_15914);
        _ieee64_inlined_float64_to_atom_at_248_15914 = _9059;
        _9059 = NOVALUE;

        /** convert.e:343		return machine_func(M_F64_TO_A, ieee64)*/
        DeRef(_float64_to_atom_inlined_float64_to_atom_at_251_15915);
        _float64_to_atom_inlined_float64_to_atom_at_251_15915 = machine(47, _ieee64_inlined_float64_to_atom_at_248_15914);
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_15914);
        _ieee64_inlined_float64_to_atom_at_248_15914 = NOVALUE;
        DeRef(_s_15865);
        DeRef(_9045);
        _9045 = NOVALUE;
        DeRef(_9034);
        _9034 = NOVALUE;
        DeRef(_9027);
        _9027 = NOVALUE;
        DeRef(_9043);
        _9043 = NOVALUE;
        return _float64_to_atom_inlined_float64_to_atom_at_251_15915;

        /** eds.e:364			case else*/
        default:

        /** eds.e:366				if c = S1B then*/
        if (_c_15864 != 254)
        goto L3; // [273] 287

        /** eds.e:367					len = getc(current_db)*/
        if (_41current_db_15734 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
            last_r_file_no = _41current_db_15734;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _len_15866 = getc((FILE*)xstdin);
            }
            else{
                _len_15866 = getc(last_r_file_ptr);
            }
        }
        else{
            _len_15866 = getc(last_r_file_ptr);
        }
        goto L4; // [284] 295
L3: 

        /** eds.e:369					len = get4()*/
        _len_15866 = _41get4();
        if (!IS_ATOM_INT(_len_15866)) {
            _1 = (object)(DBL_PTR(_len_15866)->dbl);
            DeRefDS(_len_15866);
            _len_15866 = _1;
        }
L4: 

        /** eds.e:371				s = repeat(0, len)*/
        DeRef(_s_15865);
        _s_15865 = Repeat(0, _len_15866);

        /** eds.e:372				for i = 1 to len do*/
        _9064 = _len_15866;
        {
            object _i_15924;
            _i_15924 = 1;
L5: 
            if (_i_15924 > _9064){
                goto L6; // [308] 362
            }

            /** eds.e:374					c = getc(current_db)*/
            if (_41current_db_15734 != last_r_file_no) {
                last_r_file_ptr = which_file(_41current_db_15734, EF_READ);
                last_r_file_no = _41current_db_15734;
            }
            if (last_r_file_ptr == xstdin) {
                if (in_from_keyb) {
                    _c_15864 = getc((FILE*)xstdin);
                }
                else{
                    _c_15864 = getc(last_r_file_ptr);
                }
            }
            else{
                _c_15864 = getc(last_r_file_ptr);
            }

            /** eds.e:375					if c < I2B then*/
            if (_c_15864 >= 249)
            goto L7; // [324] 341

            /** eds.e:376						s[i] = c + MIN1B*/
            _9067 = _c_15864 + -9;
            _2 = (object)SEQ_PTR(_s_15865);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _s_15865 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _i_15924);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _9067;
            if( _1 != _9067 ){
                DeRef(_1);
            }
            _9067 = NOVALUE;
            goto L8; // [338] 355
L7: 

            /** eds.e:378						s[i] = decompress(c)*/
            DeRef(_9068);
            _9068 = _c_15864;
            _9069 = _41decompress(_9068);
            _9068 = NOVALUE;
            _2 = (object)SEQ_PTR(_s_15865);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _s_15865 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _i_15924);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _9069;
            if( _1 != _9069 ){
                DeRef(_1);
            }
            _9069 = NOVALUE;
L8: 

            /** eds.e:380				end for*/
            _i_15924 = _i_15924 + 1;
            goto L5; // [357] 315
L6: 
            ;
        }

        /** eds.e:381				return s*/
        DeRef(_9045);
        _9045 = NOVALUE;
        DeRef(_9034);
        _9034 = NOVALUE;
        DeRef(_9027);
        _9027 = NOVALUE;
        DeRef(_9043);
        _9043 = NOVALUE;
        return _s_15865;
    ;}    ;
}


object _41compress(object _x_15935)
{
    object _x4_15936 = NOVALUE;
    object _s_15937 = NOVALUE;
    object _atom_to_float32_inlined_atom_to_float32_at_193_15971 = NOVALUE;
    object _float32_to_atom_inlined_float32_to_atom_at_204_15974 = NOVALUE;
    object _atom_to_float64_inlined_atom_to_float64_at_230_15979 = NOVALUE;
    object _9108 = NOVALUE;
    object _9107 = NOVALUE;
    object _9106 = NOVALUE;
    object _9104 = NOVALUE;
    object _9103 = NOVALUE;
    object _9101 = NOVALUE;
    object _9099 = NOVALUE;
    object _9098 = NOVALUE;
    object _9097 = NOVALUE;
    object _9095 = NOVALUE;
    object _9094 = NOVALUE;
    object _9093 = NOVALUE;
    object _9092 = NOVALUE;
    object _9091 = NOVALUE;
    object _9090 = NOVALUE;
    object _9089 = NOVALUE;
    object _9088 = NOVALUE;
    object _9087 = NOVALUE;
    object _9085 = NOVALUE;
    object _9084 = NOVALUE;
    object _9083 = NOVALUE;
    object _9082 = NOVALUE;
    object _9081 = NOVALUE;
    object _9080 = NOVALUE;
    object _9078 = NOVALUE;
    object _9077 = NOVALUE;
    object _9076 = NOVALUE;
    object _9075 = NOVALUE;
    object _9074 = NOVALUE;
    object _9073 = NOVALUE;
    object _9072 = NOVALUE;
    object _9071 = NOVALUE;
    object _9070 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:390		if integer(x) then*/
    if (IS_ATOM_INT(_x_15935))
    _9070 = 1;
    else if (IS_ATOM_DBL(_x_15935))
    _9070 = IS_ATOM_INT(DoubleToInt(_x_15935));
    else
    _9070 = 0;
    if (_9070 == 0)
    {
        _9070 = NOVALUE;
        goto L1; // [6] 184
    }
    else{
        _9070 = NOVALUE;
    }

    /** eds.e:391			if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_15935)) {
        _9071 = (_x_15935 >= -9);
    }
    else {
        _9071 = binary_op(GREATEREQ, _x_15935, -9);
    }
    if (IS_ATOM_INT(_9071)) {
        if (_9071 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_9071)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_15935)) {
        _9073 = (_x_15935 <= 239);
    }
    else {
        _9073 = binary_op(LESSEQ, _x_15935, 239);
    }
    if (_9073 == 0) {
        DeRef(_9073);
        _9073 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_9073) && DBL_PTR(_9073)->dbl == 0.0){
            DeRef(_9073);
            _9073 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_9073);
        _9073 = NOVALUE;
    }
    DeRef(_9073);
    _9073 = NOVALUE;

    /** eds.e:392				return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_15935)) {
        _9074 = _x_15935 - -9;
        if ((object)((uintptr_t)_9074 +(uintptr_t) HIGH_BITS) >= 0){
            _9074 = NewDouble((eudouble)_9074);
        }
    }
    else {
        _9074 = binary_op(MINUS, _x_15935, -9);
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _9074;
    _9075 = MAKE_SEQ(_1);
    _9074 = NOVALUE;
    DeRef(_x_15935);
    DeRefi(_x4_15936);
    DeRef(_s_15937);
    DeRef(_9071);
    _9071 = NOVALUE;
    return _9075;
    goto L3; // [41] 330
L2: 

    /** eds.e:394			elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_15935)) {
        _9076 = (_x_15935 >= _41MIN2B_15847);
    }
    else {
        _9076 = binary_op(GREATEREQ, _x_15935, _41MIN2B_15847);
    }
    if (IS_ATOM_INT(_9076)) {
        if (_9076 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_9076)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_15935)) {
        _9078 = (_x_15935 <= 32767);
    }
    else {
        _9078 = binary_op(LESSEQ, _x_15935, 32767);
    }
    if (_9078 == 0) {
        DeRef(_9078);
        _9078 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_9078) && DBL_PTR(_9078)->dbl == 0.0){
            DeRef(_9078);
            _9078 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_9078);
        _9078 = NOVALUE;
    }
    DeRef(_9078);
    _9078 = NOVALUE;

    /** eds.e:395				x -= MIN2B*/
    _0 = _x_15935;
    if (IS_ATOM_INT(_x_15935)) {
        _x_15935 = _x_15935 - _41MIN2B_15847;
        if ((object)((uintptr_t)_x_15935 +(uintptr_t) HIGH_BITS) >= 0){
            _x_15935 = NewDouble((eudouble)_x_15935);
        }
    }
    else {
        _x_15935 = binary_op(MINUS, _x_15935, _41MIN2B_15847);
    }
    DeRef(_0);

    /** eds.e:396				return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_15935)) {
        {uintptr_t tu;
             tu = (uintptr_t)_x_15935 & (uintptr_t)255;
             _9080 = MAKE_UINT(tu);
        }
    }
    else {
        _9080 = binary_op(AND_BITS, _x_15935, 255);
    }
    if (IS_ATOM_INT(_x_15935)) {
        if (256 > 0 && _x_15935 >= 0) {
            _9081 = _x_15935 / 256;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_15935 / (eudouble)256);
            if (_x_15935 != MININT)
            _9081 = (object)temp_dbl;
            else
            _9081 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_15935, 256);
        _9081 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 249;
    ((intptr_t*)_2)[2] = _9080;
    ((intptr_t*)_2)[3] = _9081;
    _9082 = MAKE_SEQ(_1);
    _9081 = NOVALUE;
    _9080 = NOVALUE;
    DeRef(_x_15935);
    DeRefi(_x4_15936);
    DeRef(_s_15937);
    DeRef(_9075);
    _9075 = NOVALUE;
    DeRef(_9076);
    _9076 = NOVALUE;
    DeRef(_9071);
    _9071 = NOVALUE;
    return _9082;
    goto L3; // [94] 330
L4: 

    /** eds.e:398			elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_15935)) {
        _9083 = (_x_15935 >= _41MIN3B_15853);
    }
    else {
        _9083 = binary_op(GREATEREQ, _x_15935, _41MIN3B_15853);
    }
    if (IS_ATOM_INT(_9083)) {
        if (_9083 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_9083)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_15935)) {
        _9085 = (_x_15935 <= 8388607);
    }
    else {
        _9085 = binary_op(LESSEQ, _x_15935, 8388607);
    }
    if (_9085 == 0) {
        DeRef(_9085);
        _9085 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_9085) && DBL_PTR(_9085)->dbl == 0.0){
            DeRef(_9085);
            _9085 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_9085);
        _9085 = NOVALUE;
    }
    DeRef(_9085);
    _9085 = NOVALUE;

    /** eds.e:399				x -= MIN3B*/
    _0 = _x_15935;
    if (IS_ATOM_INT(_x_15935)) {
        _x_15935 = _x_15935 - _41MIN3B_15853;
        if ((object)((uintptr_t)_x_15935 +(uintptr_t) HIGH_BITS) >= 0){
            _x_15935 = NewDouble((eudouble)_x_15935);
        }
    }
    else {
        _x_15935 = binary_op(MINUS, _x_15935, _41MIN3B_15853);
    }
    DeRef(_0);

    /** eds.e:400				return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_15935)) {
        {uintptr_t tu;
             tu = (uintptr_t)_x_15935 & (uintptr_t)255;
             _9087 = MAKE_UINT(tu);
        }
    }
    else {
        _9087 = binary_op(AND_BITS, _x_15935, 255);
    }
    if (IS_ATOM_INT(_x_15935)) {
        if (256 > 0 && _x_15935 >= 0) {
            _9088 = _x_15935 / 256;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_15935 / (eudouble)256);
            if (_x_15935 != MININT)
            _9088 = (object)temp_dbl;
            else
            _9088 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_15935, 256);
        _9088 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_9088)) {
        {uintptr_t tu;
             tu = (uintptr_t)_9088 & (uintptr_t)255;
             _9089 = MAKE_UINT(tu);
        }
    }
    else {
        _9089 = binary_op(AND_BITS, _9088, 255);
    }
    DeRef(_9088);
    _9088 = NOVALUE;
    if (IS_ATOM_INT(_x_15935)) {
        if (65536 > 0 && _x_15935 >= 0) {
            _9090 = _x_15935 / 65536;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_15935 / (eudouble)65536);
            if (_x_15935 != MININT)
            _9090 = (object)temp_dbl;
            else
            _9090 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_15935, 65536);
        _9090 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 250;
    ((intptr_t*)_2)[2] = _9087;
    ((intptr_t*)_2)[3] = _9089;
    ((intptr_t*)_2)[4] = _9090;
    _9091 = MAKE_SEQ(_1);
    _9090 = NOVALUE;
    _9089 = NOVALUE;
    _9087 = NOVALUE;
    DeRef(_x_15935);
    DeRefi(_x4_15936);
    DeRef(_s_15937);
    DeRef(_9083);
    _9083 = NOVALUE;
    DeRef(_9075);
    _9075 = NOVALUE;
    DeRef(_9082);
    _9082 = NOVALUE;
    DeRef(_9076);
    _9076 = NOVALUE;
    DeRef(_9071);
    _9071 = NOVALUE;
    return _9091;
    goto L3; // [156] 330
L5: 

    /** eds.e:403				return I4B & convert:int_to_bytes(x-MIN4B)*/
    if (IS_ATOM_INT(_x_15935) && IS_ATOM_INT(_41MIN4B_15859)) {
        _9092 = _x_15935 - _41MIN4B_15859;
        if ((object)((uintptr_t)_9092 +(uintptr_t) HIGH_BITS) >= 0){
            _9092 = NewDouble((eudouble)_9092);
        }
    }
    else {
        _9092 = binary_op(MINUS, _x_15935, _41MIN4B_15859);
    }
    _9093 = _19int_to_bytes(_9092, 4);
    _9092 = NOVALUE;
    if (IS_SEQUENCE(251) && IS_ATOM(_9093)) {
    }
    else if (IS_ATOM(251) && IS_SEQUENCE(_9093)) {
        Prepend(&_9094, _9093, 251);
    }
    else {
        Concat((object_ptr)&_9094, 251, _9093);
    }
    DeRef(_9093);
    _9093 = NOVALUE;
    DeRef(_x_15935);
    DeRefi(_x4_15936);
    DeRef(_s_15937);
    DeRef(_9091);
    _9091 = NOVALUE;
    DeRef(_9083);
    _9083 = NOVALUE;
    DeRef(_9075);
    _9075 = NOVALUE;
    DeRef(_9082);
    _9082 = NOVALUE;
    DeRef(_9076);
    _9076 = NOVALUE;
    DeRef(_9071);
    _9071 = NOVALUE;
    return _9094;
    goto L3; // [181] 330
L1: 

    /** eds.e:407		elsif atom(x) then*/
    _9095 = IS_ATOM(_x_15935);
    if (_9095 == 0)
    {
        _9095 = NOVALUE;
        goto L6; // [189] 250
    }
    else{
        _9095 = NOVALUE;
    }

    /** eds.e:409			x4 = convert:atom_to_float32(x)*/

    /** convert.e:312		return machine_func(M_A_TO_F32, a)*/
    DeRefi(_x4_15936);
    _x4_15936 = machine(48, _x_15935);

    /** eds.e:410			if x = convert:float32_to_atom(x4) then*/

    /** convert.e:374		return machine_func(M_F32_TO_A, ieee32)*/
    DeRef(_float32_to_atom_inlined_float32_to_atom_at_204_15974);
    _float32_to_atom_inlined_float32_to_atom_at_204_15974 = machine(49, _x4_15936);
    if (binary_op_a(NOTEQ, _x_15935, _float32_to_atom_inlined_float32_to_atom_at_204_15974)){
        goto L7; // [212] 229
    }

    /** eds.e:412				return F4B & x4*/
    Prepend(&_9097, _x4_15936, 252);
    DeRef(_x_15935);
    DeRefDSi(_x4_15936);
    DeRef(_s_15937);
    DeRef(_9091);
    _9091 = NOVALUE;
    DeRef(_9083);
    _9083 = NOVALUE;
    DeRef(_9075);
    _9075 = NOVALUE;
    DeRef(_9082);
    _9082 = NOVALUE;
    DeRef(_9094);
    _9094 = NOVALUE;
    DeRef(_9076);
    _9076 = NOVALUE;
    DeRef(_9071);
    _9071 = NOVALUE;
    return _9097;
    goto L3; // [226] 330
L7: 

    /** eds.e:414				return F8B & convert:atom_to_float64(x)*/

    /** convert.e:262		return machine_func(M_A_TO_F64, a)*/
    DeRefi(_atom_to_float64_inlined_atom_to_float64_at_230_15979);
    _atom_to_float64_inlined_atom_to_float64_at_230_15979 = machine(46, _x_15935);
    Prepend(&_9098, _atom_to_float64_inlined_atom_to_float64_at_230_15979, 253);
    DeRef(_x_15935);
    DeRefi(_x4_15936);
    DeRef(_s_15937);
    DeRef(_9091);
    _9091 = NOVALUE;
    DeRef(_9083);
    _9083 = NOVALUE;
    DeRef(_9075);
    _9075 = NOVALUE;
    DeRef(_9082);
    _9082 = NOVALUE;
    DeRef(_9094);
    _9094 = NOVALUE;
    DeRef(_9076);
    _9076 = NOVALUE;
    DeRef(_9071);
    _9071 = NOVALUE;
    DeRef(_9097);
    _9097 = NOVALUE;
    return _9098;
    goto L3; // [247] 330
L6: 

    /** eds.e:419			if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_15935)){
            _9099 = SEQ_PTR(_x_15935)->length;
    }
    else {
        _9099 = 1;
    }
    if (_9099 > 255)
    goto L8; // [255] 271

    /** eds.e:420				s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_15935)){
            _9101 = SEQ_PTR(_x_15935)->length;
    }
    else {
        _9101 = 1;
    }
    DeRef(_s_15937);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 254;
    ((intptr_t *)_2)[2] = _9101;
    _s_15937 = MAKE_SEQ(_1);
    _9101 = NOVALUE;
    goto L9; // [268] 286
L8: 

    /** eds.e:422				s = S4B & convert:int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_15935)){
            _9103 = SEQ_PTR(_x_15935)->length;
    }
    else {
        _9103 = 1;
    }
    _9104 = _19int_to_bytes(_9103, 4);
    _9103 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_9104)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_9104)) {
        Prepend(&_s_15937, _9104, 255);
    }
    else {
        Concat((object_ptr)&_s_15937, 255, _9104);
    }
    DeRef(_9104);
    _9104 = NOVALUE;
L9: 

    /** eds.e:424			for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_15935)){
            _9106 = SEQ_PTR(_x_15935)->length;
    }
    else {
        _9106 = 1;
    }
    {
        object _i_15992;
        _i_15992 = 1;
LA: 
        if (_i_15992 > _9106){
            goto LB; // [291] 321
        }

        /** eds.e:425				s &= compress(x[i])*/
        _2 = (object)SEQ_PTR(_x_15935);
        _9107 = (object)*(((s1_ptr)_2)->base + _i_15992);
        Ref(_9107);
        _9108 = _41compress(_9107);
        _9107 = NOVALUE;
        if (IS_SEQUENCE(_s_15937) && IS_ATOM(_9108)) {
            Ref(_9108);
            Append(&_s_15937, _s_15937, _9108);
        }
        else if (IS_ATOM(_s_15937) && IS_SEQUENCE(_9108)) {
        }
        else {
            Concat((object_ptr)&_s_15937, _s_15937, _9108);
        }
        DeRef(_9108);
        _9108 = NOVALUE;

        /** eds.e:426			end for*/
        _i_15992 = _i_15992 + 1;
        goto LA; // [316] 298
LB: 
        ;
    }

    /** eds.e:427			return s*/
    DeRef(_x_15935);
    DeRefi(_x4_15936);
    DeRef(_9091);
    _9091 = NOVALUE;
    DeRef(_9083);
    _9083 = NOVALUE;
    DeRef(_9075);
    _9075 = NOVALUE;
    DeRef(_9082);
    _9082 = NOVALUE;
    DeRef(_9098);
    _9098 = NOVALUE;
    DeRef(_9094);
    _9094 = NOVALUE;
    DeRef(_9076);
    _9076 = NOVALUE;
    DeRef(_9071);
    _9071 = NOVALUE;
    DeRef(_9097);
    _9097 = NOVALUE;
    return _s_15937;
L3: 
    ;
}


object _41db_allocate(object _n_16363)
{
    object _free_list_16364 = NOVALUE;
    object _size_16365 = NOVALUE;
    object _size_ptr_16366 = NOVALUE;
    object _addr_16367 = NOVALUE;
    object _free_count_16368 = NOVALUE;
    object _remaining_16369 = NOVALUE;
    object _seek_1__tmp_at4_16372 = NOVALUE;
    object _seek_inlined_seek_at_4_16371 = NOVALUE;
    object _seek_1__tmp_at39_16379 = NOVALUE;
    object _seek_inlined_seek_at_39_16378 = NOVALUE;
    object _seek_1__tmp_at111_16396 = NOVALUE;
    object _seek_inlined_seek_at_111_16395 = NOVALUE;
    object _pos_inlined_seek_at_108_16394 = NOVALUE;
    object _put4_1__tmp_at137_16401 = NOVALUE;
    object _x_inlined_put4_at_134_16400 = NOVALUE;
    object _seek_1__tmp_at167_16404 = NOVALUE;
    object _seek_inlined_seek_at_167_16403 = NOVALUE;
    object _put4_1__tmp_at193_16409 = NOVALUE;
    object _x_inlined_put4_at_190_16408 = NOVALUE;
    object _seek_1__tmp_at244_16417 = NOVALUE;
    object _seek_inlined_seek_at_244_16416 = NOVALUE;
    object _pos_inlined_seek_at_241_16415 = NOVALUE;
    object _put4_1__tmp_at266_16421 = NOVALUE;
    object _x_inlined_put4_at_263_16420 = NOVALUE;
    object _seek_1__tmp_at333_16432 = NOVALUE;
    object _seek_inlined_seek_at_333_16431 = NOVALUE;
    object _pos_inlined_seek_at_330_16430 = NOVALUE;
    object _seek_1__tmp_at364_16436 = NOVALUE;
    object _seek_inlined_seek_at_364_16435 = NOVALUE;
    object _put4_1__tmp_at386_16440 = NOVALUE;
    object _x_inlined_put4_at_383_16439 = NOVALUE;
    object _seek_1__tmp_at423_16445 = NOVALUE;
    object _seek_inlined_seek_at_423_16444 = NOVALUE;
    object _pos_inlined_seek_at_420_16443 = NOVALUE;
    object _put4_1__tmp_at438_16447 = NOVALUE;
    object _seek_1__tmp_at490_16451 = NOVALUE;
    object _seek_inlined_seek_at_490_16450 = NOVALUE;
    object _put4_1__tmp_at512_16455 = NOVALUE;
    object _x_inlined_put4_at_509_16454 = NOVALUE;
    object _where_inlined_where_at_542_16457 = NOVALUE;
    object _9307 = NOVALUE;
    object _9305 = NOVALUE;
    object _9304 = NOVALUE;
    object _9303 = NOVALUE;
    object _9302 = NOVALUE;
    object _9301 = NOVALUE;
    object _9299 = NOVALUE;
    object _9298 = NOVALUE;
    object _9297 = NOVALUE;
    object _9296 = NOVALUE;
    object _9294 = NOVALUE;
    object _9293 = NOVALUE;
    object _9292 = NOVALUE;
    object _9291 = NOVALUE;
    object _9290 = NOVALUE;
    object _9289 = NOVALUE;
    object _9288 = NOVALUE;
    object _9286 = NOVALUE;
    object _9284 = NOVALUE;
    object _9281 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:795		io:seek(current_db, FREE_COUNT)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_16372);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = 7;
    _seek_1__tmp_at4_16372 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_16371 = machine(19, _seek_1__tmp_at4_16372);
    DeRefi(_seek_1__tmp_at4_16372);
    _seek_1__tmp_at4_16372 = NOVALUE;

    /** eds.e:796		free_count = get4()*/
    _free_count_16368 = _41get4();
    if (!IS_ATOM_INT(_free_count_16368)) {
        _1 = (object)(DBL_PTR(_free_count_16368)->dbl);
        DeRefDS(_free_count_16368);
        _free_count_16368 = _1;
    }

    /** eds.e:797		if free_count > 0 then*/
    if (_free_count_16368 <= 0)
    goto L1; // [27] 487

    /** eds.e:798			free_list = get4()*/
    _0 = _free_list_16364;
    _free_list_16364 = _41get4();
    DeRef(_0);

    /** eds.e:799			io:seek(current_db, free_list)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_16364);
    DeRef(_seek_1__tmp_at39_16379);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _free_list_16364;
    _seek_1__tmp_at39_16379 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_39_16378 = machine(19, _seek_1__tmp_at39_16379);
    DeRef(_seek_1__tmp_at39_16379);
    _seek_1__tmp_at39_16379 = NOVALUE;

    /** eds.e:800			size_ptr = free_list + 4*/
    DeRef(_size_ptr_16366);
    if (IS_ATOM_INT(_free_list_16364)) {
        _size_ptr_16366 = _free_list_16364 + 4;
        if ((object)((uintptr_t)_size_ptr_16366 + (uintptr_t)HIGH_BITS) >= 0){
            _size_ptr_16366 = NewDouble((eudouble)_size_ptr_16366);
        }
    }
    else {
        _size_ptr_16366 = NewDouble(DBL_PTR(_free_list_16364)->dbl + (eudouble)4);
    }

    /** eds.e:801			for i = 1 to free_count do*/
    _9281 = _free_count_16368;
    {
        object _i_16382;
        _i_16382 = 1;
L2: 
        if (_i_16382 > _9281){
            goto L3; // [64] 486
        }

        /** eds.e:802				addr = get4()*/
        _0 = _addr_16367;
        _addr_16367 = _41get4();
        DeRef(_0);

        /** eds.e:803				size = get4()*/
        _0 = _size_16365;
        _size_16365 = _41get4();
        DeRef(_0);

        /** eds.e:804				if size >= n+4 then*/
        if (IS_ATOM_INT(_n_16363)) {
            _9284 = _n_16363 + 4;
            if ((object)((uintptr_t)_9284 + (uintptr_t)HIGH_BITS) >= 0){
                _9284 = NewDouble((eudouble)_9284);
            }
        }
        else {
            _9284 = NewDouble(DBL_PTR(_n_16363)->dbl + (eudouble)4);
        }
        if (binary_op_a(LESS, _size_16365, _9284)){
            DeRef(_9284);
            _9284 = NOVALUE;
            goto L4; // [87] 473
        }
        DeRef(_9284);
        _9284 = NOVALUE;

        /** eds.e:806					if size >= n+16 then*/
        if (IS_ATOM_INT(_n_16363)) {
            _9286 = _n_16363 + 16;
            if ((object)((uintptr_t)_9286 + (uintptr_t)HIGH_BITS) >= 0){
                _9286 = NewDouble((eudouble)_9286);
            }
        }
        else {
            _9286 = NewDouble(DBL_PTR(_n_16363)->dbl + (eudouble)16);
        }
        if (binary_op_a(LESS, _size_16365, _9286)){
            DeRef(_9286);
            _9286 = NOVALUE;
            goto L5; // [97] 296
        }
        DeRef(_9286);
        _9286 = NOVALUE;

        /** eds.e:808						io:seek(current_db, addr - 4)*/
        if (IS_ATOM_INT(_addr_16367)) {
            _9288 = _addr_16367 - 4;
            if ((object)((uintptr_t)_9288 +(uintptr_t) HIGH_BITS) >= 0){
                _9288 = NewDouble((eudouble)_9288);
            }
        }
        else {
            _9288 = NewDouble(DBL_PTR(_addr_16367)->dbl - (eudouble)4);
        }
        DeRef(_pos_inlined_seek_at_108_16394);
        _pos_inlined_seek_at_108_16394 = _9288;
        _9288 = NOVALUE;

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_108_16394);
        DeRef(_seek_1__tmp_at111_16396);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_15734;
        ((intptr_t *)_2)[2] = _pos_inlined_seek_at_108_16394;
        _seek_1__tmp_at111_16396 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_111_16395 = machine(19, _seek_1__tmp_at111_16396);
        DeRef(_pos_inlined_seek_at_108_16394);
        _pos_inlined_seek_at_108_16394 = NOVALUE;
        DeRef(_seek_1__tmp_at111_16396);
        _seek_1__tmp_at111_16396 = NOVALUE;

        /** eds.e:809						put4(size-n-4) -- shrink the block*/
        if (IS_ATOM_INT(_size_16365) && IS_ATOM_INT(_n_16363)) {
            _9289 = _size_16365 - _n_16363;
            if ((object)((uintptr_t)_9289 +(uintptr_t) HIGH_BITS) >= 0){
                _9289 = NewDouble((eudouble)_9289);
            }
        }
        else {
            if (IS_ATOM_INT(_size_16365)) {
                _9289 = NewDouble((eudouble)_size_16365 - DBL_PTR(_n_16363)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_16363)) {
                    _9289 = NewDouble(DBL_PTR(_size_16365)->dbl - (eudouble)_n_16363);
                }
                else
                _9289 = NewDouble(DBL_PTR(_size_16365)->dbl - DBL_PTR(_n_16363)->dbl);
            }
        }
        if (IS_ATOM_INT(_9289)) {
            _9290 = _9289 - 4;
            if ((object)((uintptr_t)_9290 +(uintptr_t) HIGH_BITS) >= 0){
                _9290 = NewDouble((eudouble)_9290);
            }
        }
        else {
            _9290 = NewDouble(DBL_PTR(_9289)->dbl - (eudouble)4);
        }
        DeRef(_9289);
        _9289 = NOVALUE;
        DeRef(_x_inlined_put4_at_134_16400);
        _x_inlined_put4_at_134_16400 = _9290;
        _9290 = NOVALUE;

        /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_41mem0_15776)){
            poke4_addr = (uint32_t *)_41mem0_15776;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_134_16400)) {
            *poke4_addr = (uint32_t)_x_inlined_put4_at_134_16400;
        }
        else {
            *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_134_16400)->dbl;
        }

        /** eds.e:443		puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at137_16401);
        _1 = (object)SEQ_PTR(_41memseq_16000);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _put4_1__tmp_at137_16401 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        EPuts(_41current_db_15734, _put4_1__tmp_at137_16401); // DJP 

        /** eds.e:444	end procedure*/
        goto L6; // [159] 162
L6: 
        DeRef(_x_inlined_put4_at_134_16400);
        _x_inlined_put4_at_134_16400 = NOVALUE;
        DeRefi(_put4_1__tmp_at137_16401);
        _put4_1__tmp_at137_16401 = NOVALUE;

        /** eds.e:810						io:seek(current_db, size_ptr)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_size_ptr_16366);
        DeRef(_seek_1__tmp_at167_16404);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_15734;
        ((intptr_t *)_2)[2] = _size_ptr_16366;
        _seek_1__tmp_at167_16404 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_167_16403 = machine(19, _seek_1__tmp_at167_16404);
        DeRef(_seek_1__tmp_at167_16404);
        _seek_1__tmp_at167_16404 = NOVALUE;

        /** eds.e:811						put4(size-n-4) -- update size on free list too*/
        if (IS_ATOM_INT(_size_16365) && IS_ATOM_INT(_n_16363)) {
            _9291 = _size_16365 - _n_16363;
            if ((object)((uintptr_t)_9291 +(uintptr_t) HIGH_BITS) >= 0){
                _9291 = NewDouble((eudouble)_9291);
            }
        }
        else {
            if (IS_ATOM_INT(_size_16365)) {
                _9291 = NewDouble((eudouble)_size_16365 - DBL_PTR(_n_16363)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_16363)) {
                    _9291 = NewDouble(DBL_PTR(_size_16365)->dbl - (eudouble)_n_16363);
                }
                else
                _9291 = NewDouble(DBL_PTR(_size_16365)->dbl - DBL_PTR(_n_16363)->dbl);
            }
        }
        if (IS_ATOM_INT(_9291)) {
            _9292 = _9291 - 4;
            if ((object)((uintptr_t)_9292 +(uintptr_t) HIGH_BITS) >= 0){
                _9292 = NewDouble((eudouble)_9292);
            }
        }
        else {
            _9292 = NewDouble(DBL_PTR(_9291)->dbl - (eudouble)4);
        }
        DeRef(_9291);
        _9291 = NOVALUE;
        DeRef(_x_inlined_put4_at_190_16408);
        _x_inlined_put4_at_190_16408 = _9292;
        _9292 = NOVALUE;

        /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_41mem0_15776)){
            poke4_addr = (uint32_t *)_41mem0_15776;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_190_16408)) {
            *poke4_addr = (uint32_t)_x_inlined_put4_at_190_16408;
        }
        else {
            *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_190_16408)->dbl;
        }

        /** eds.e:443		puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at193_16409);
        _1 = (object)SEQ_PTR(_41memseq_16000);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _put4_1__tmp_at193_16409 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        EPuts(_41current_db_15734, _put4_1__tmp_at193_16409); // DJP 

        /** eds.e:444	end procedure*/
        goto L7; // [215] 218
L7: 
        DeRef(_x_inlined_put4_at_190_16408);
        _x_inlined_put4_at_190_16408 = NOVALUE;
        DeRefi(_put4_1__tmp_at193_16409);
        _put4_1__tmp_at193_16409 = NOVALUE;

        /** eds.e:812						addr += size-n-4*/
        if (IS_ATOM_INT(_size_16365) && IS_ATOM_INT(_n_16363)) {
            _9293 = _size_16365 - _n_16363;
            if ((object)((uintptr_t)_9293 +(uintptr_t) HIGH_BITS) >= 0){
                _9293 = NewDouble((eudouble)_9293);
            }
        }
        else {
            if (IS_ATOM_INT(_size_16365)) {
                _9293 = NewDouble((eudouble)_size_16365 - DBL_PTR(_n_16363)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_16363)) {
                    _9293 = NewDouble(DBL_PTR(_size_16365)->dbl - (eudouble)_n_16363);
                }
                else
                _9293 = NewDouble(DBL_PTR(_size_16365)->dbl - DBL_PTR(_n_16363)->dbl);
            }
        }
        if (IS_ATOM_INT(_9293)) {
            _9294 = _9293 - 4;
            if ((object)((uintptr_t)_9294 +(uintptr_t) HIGH_BITS) >= 0){
                _9294 = NewDouble((eudouble)_9294);
            }
        }
        else {
            _9294 = NewDouble(DBL_PTR(_9293)->dbl - (eudouble)4);
        }
        DeRef(_9293);
        _9293 = NOVALUE;
        _0 = _addr_16367;
        if (IS_ATOM_INT(_addr_16367) && IS_ATOM_INT(_9294)) {
            _addr_16367 = _addr_16367 + _9294;
            if ((object)((uintptr_t)_addr_16367 + (uintptr_t)HIGH_BITS) >= 0){
                _addr_16367 = NewDouble((eudouble)_addr_16367);
            }
        }
        else {
            if (IS_ATOM_INT(_addr_16367)) {
                _addr_16367 = NewDouble((eudouble)_addr_16367 + DBL_PTR(_9294)->dbl);
            }
            else {
                if (IS_ATOM_INT(_9294)) {
                    _addr_16367 = NewDouble(DBL_PTR(_addr_16367)->dbl + (eudouble)_9294);
                }
                else
                _addr_16367 = NewDouble(DBL_PTR(_addr_16367)->dbl + DBL_PTR(_9294)->dbl);
            }
        }
        DeRef(_0);
        DeRef(_9294);
        _9294 = NOVALUE;

        /** eds.e:813						io:seek(current_db, addr - 4) */
        if (IS_ATOM_INT(_addr_16367)) {
            _9296 = _addr_16367 - 4;
            if ((object)((uintptr_t)_9296 +(uintptr_t) HIGH_BITS) >= 0){
                _9296 = NewDouble((eudouble)_9296);
            }
        }
        else {
            _9296 = NewDouble(DBL_PTR(_addr_16367)->dbl - (eudouble)4);
        }
        DeRef(_pos_inlined_seek_at_241_16415);
        _pos_inlined_seek_at_241_16415 = _9296;
        _9296 = NOVALUE;

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_241_16415);
        DeRef(_seek_1__tmp_at244_16417);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_15734;
        ((intptr_t *)_2)[2] = _pos_inlined_seek_at_241_16415;
        _seek_1__tmp_at244_16417 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_244_16416 = machine(19, _seek_1__tmp_at244_16417);
        DeRef(_pos_inlined_seek_at_241_16415);
        _pos_inlined_seek_at_241_16415 = NOVALUE;
        DeRef(_seek_1__tmp_at244_16417);
        _seek_1__tmp_at244_16417 = NOVALUE;

        /** eds.e:814						put4(n+4)*/
        if (IS_ATOM_INT(_n_16363)) {
            _9297 = _n_16363 + 4;
            if ((object)((uintptr_t)_9297 + (uintptr_t)HIGH_BITS) >= 0){
                _9297 = NewDouble((eudouble)_9297);
            }
        }
        else {
            _9297 = NewDouble(DBL_PTR(_n_16363)->dbl + (eudouble)4);
        }
        DeRef(_x_inlined_put4_at_263_16420);
        _x_inlined_put4_at_263_16420 = _9297;
        _9297 = NOVALUE;

        /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_41mem0_15776)){
            poke4_addr = (uint32_t *)_41mem0_15776;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_263_16420)) {
            *poke4_addr = (uint32_t)_x_inlined_put4_at_263_16420;
        }
        else {
            *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_263_16420)->dbl;
        }

        /** eds.e:443		puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at266_16421);
        _1 = (object)SEQ_PTR(_41memseq_16000);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _put4_1__tmp_at266_16421 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        EPuts(_41current_db_15734, _put4_1__tmp_at266_16421); // DJP 

        /** eds.e:444	end procedure*/
        goto L8; // [288] 291
L8: 
        DeRef(_x_inlined_put4_at_263_16420);
        _x_inlined_put4_at_263_16420 = NOVALUE;
        DeRefi(_put4_1__tmp_at266_16421);
        _put4_1__tmp_at266_16421 = NOVALUE;
        goto L9; // [293] 466
L5: 

        /** eds.e:817						remaining = io:get_bytes(current_db, (free_count-i) * 8)*/
        _9298 = _free_count_16368 - _i_16382;
        if ((object)((uintptr_t)_9298 +(uintptr_t) HIGH_BITS) >= 0){
            _9298 = NewDouble((eudouble)_9298);
        }
        if (IS_ATOM_INT(_9298)) {
            if (_9298 == (short)_9298){
                _9299 = _9298 * 8;
            }
            else{
                _9299 = NewDouble(_9298 * (eudouble)8);
            }
        }
        else {
            _9299 = NewDouble(DBL_PTR(_9298)->dbl * (eudouble)8);
        }
        DeRef(_9298);
        _9298 = NOVALUE;
        _0 = _remaining_16369;
        _remaining_16369 = _17get_bytes(_41current_db_15734, _9299);
        DeRef(_0);
        _9299 = NOVALUE;

        /** eds.e:818						io:seek(current_db, free_list+8*(i-1))*/
        _9301 = _i_16382 - 1;
        if (_9301 <= INT15){
            _9302 = 8 * _9301;
        }
        else{
            _9302 = NewDouble(8 * (eudouble)_9301);
        }
        _9301 = NOVALUE;
        if (IS_ATOM_INT(_free_list_16364) && IS_ATOM_INT(_9302)) {
            _9303 = _free_list_16364 + _9302;
            if ((object)((uintptr_t)_9303 + (uintptr_t)HIGH_BITS) >= 0){
                _9303 = NewDouble((eudouble)_9303);
            }
        }
        else {
            if (IS_ATOM_INT(_free_list_16364)) {
                _9303 = NewDouble((eudouble)_free_list_16364 + DBL_PTR(_9302)->dbl);
            }
            else {
                if (IS_ATOM_INT(_9302)) {
                    _9303 = NewDouble(DBL_PTR(_free_list_16364)->dbl + (eudouble)_9302);
                }
                else
                _9303 = NewDouble(DBL_PTR(_free_list_16364)->dbl + DBL_PTR(_9302)->dbl);
            }
        }
        DeRef(_9302);
        _9302 = NOVALUE;
        DeRef(_pos_inlined_seek_at_330_16430);
        _pos_inlined_seek_at_330_16430 = _9303;
        _9303 = NOVALUE;

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_330_16430);
        DeRef(_seek_1__tmp_at333_16432);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_15734;
        ((intptr_t *)_2)[2] = _pos_inlined_seek_at_330_16430;
        _seek_1__tmp_at333_16432 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_333_16431 = machine(19, _seek_1__tmp_at333_16432);
        DeRef(_pos_inlined_seek_at_330_16430);
        _pos_inlined_seek_at_330_16430 = NOVALUE;
        DeRef(_seek_1__tmp_at333_16432);
        _seek_1__tmp_at333_16432 = NOVALUE;

        /** eds.e:819						putn(remaining)*/

        /** eds.e:448		puts(current_db, s)*/
        EPuts(_41current_db_15734, _remaining_16369); // DJP 

        /** eds.e:449	end procedure*/
        goto LA; // [358] 361
LA: 

        /** eds.e:820						io:seek(current_db, FREE_COUNT)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        DeRefi(_seek_1__tmp_at364_16436);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_15734;
        ((intptr_t *)_2)[2] = 7;
        _seek_1__tmp_at364_16436 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_364_16435 = machine(19, _seek_1__tmp_at364_16436);
        DeRefi(_seek_1__tmp_at364_16436);
        _seek_1__tmp_at364_16436 = NOVALUE;

        /** eds.e:821						put4(free_count-1)*/
        _9304 = _free_count_16368 - 1;
        if ((object)((uintptr_t)_9304 +(uintptr_t) HIGH_BITS) >= 0){
            _9304 = NewDouble((eudouble)_9304);
        }
        DeRef(_x_inlined_put4_at_383_16439);
        _x_inlined_put4_at_383_16439 = _9304;
        _9304 = NOVALUE;

        /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_41mem0_15776)){
            poke4_addr = (uint32_t *)_41mem0_15776;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_383_16439)) {
            *poke4_addr = (uint32_t)_x_inlined_put4_at_383_16439;
        }
        else {
            *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_383_16439)->dbl;
        }

        /** eds.e:443		puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at386_16440);
        _1 = (object)SEQ_PTR(_41memseq_16000);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _put4_1__tmp_at386_16440 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        EPuts(_41current_db_15734, _put4_1__tmp_at386_16440); // DJP 

        /** eds.e:444	end procedure*/
        goto LB; // [408] 411
LB: 
        DeRef(_x_inlined_put4_at_383_16439);
        _x_inlined_put4_at_383_16439 = NOVALUE;
        DeRefi(_put4_1__tmp_at386_16440);
        _put4_1__tmp_at386_16440 = NOVALUE;

        /** eds.e:822						io:seek(current_db, addr - 4)*/
        if (IS_ATOM_INT(_addr_16367)) {
            _9305 = _addr_16367 - 4;
            if ((object)((uintptr_t)_9305 +(uintptr_t) HIGH_BITS) >= 0){
                _9305 = NewDouble((eudouble)_9305);
            }
        }
        else {
            _9305 = NewDouble(DBL_PTR(_addr_16367)->dbl - (eudouble)4);
        }
        DeRef(_pos_inlined_seek_at_420_16443);
        _pos_inlined_seek_at_420_16443 = _9305;
        _9305 = NOVALUE;

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_420_16443);
        DeRef(_seek_1__tmp_at423_16445);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_15734;
        ((intptr_t *)_2)[2] = _pos_inlined_seek_at_420_16443;
        _seek_1__tmp_at423_16445 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_423_16444 = machine(19, _seek_1__tmp_at423_16445);
        DeRef(_pos_inlined_seek_at_420_16443);
        _pos_inlined_seek_at_420_16443 = NOVALUE;
        DeRef(_seek_1__tmp_at423_16445);
        _seek_1__tmp_at423_16445 = NOVALUE;

        /** eds.e:823						put4(size) -- in case size was not updated by db_free()*/

        /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_41mem0_15776)){
            poke4_addr = (uint32_t *)_41mem0_15776;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
        }
        if (IS_ATOM_INT(_size_16365)) {
            *poke4_addr = (uint32_t)_size_16365;
        }
        else {
            *poke4_addr = (uint32_t)DBL_PTR(_size_16365)->dbl;
        }

        /** eds.e:443		puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at438_16447);
        _1 = (object)SEQ_PTR(_41memseq_16000);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _put4_1__tmp_at438_16447 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        EPuts(_41current_db_15734, _put4_1__tmp_at438_16447); // DJP 

        /** eds.e:444	end procedure*/
        goto LC; // [460] 463
LC: 
        DeRefi(_put4_1__tmp_at438_16447);
        _put4_1__tmp_at438_16447 = NOVALUE;
L9: 

        /** eds.e:825					return addr*/
        DeRef(_n_16363);
        DeRef(_free_list_16364);
        DeRef(_size_16365);
        DeRef(_size_ptr_16366);
        DeRef(_remaining_16369);
        return _addr_16367;
L4: 

        /** eds.e:827				size_ptr += 8*/
        _0 = _size_ptr_16366;
        if (IS_ATOM_INT(_size_ptr_16366)) {
            _size_ptr_16366 = _size_ptr_16366 + 8;
            if ((object)((uintptr_t)_size_ptr_16366 + (uintptr_t)HIGH_BITS) >= 0){
                _size_ptr_16366 = NewDouble((eudouble)_size_ptr_16366);
            }
        }
        else {
            _size_ptr_16366 = NewDouble(DBL_PTR(_size_ptr_16366)->dbl + (eudouble)8);
        }
        DeRef(_0);

        /** eds.e:828			end for*/
        _i_16382 = _i_16382 + 1;
        goto L2; // [481] 71
L3: 
        ;
    }
L1: 

    /** eds.e:831		io:seek(current_db, -1)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at490_16451);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = -1;
    _seek_1__tmp_at490_16451 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_490_16450 = machine(19, _seek_1__tmp_at490_16451);
    DeRefi(_seek_1__tmp_at490_16451);
    _seek_1__tmp_at490_16451 = NOVALUE;

    /** eds.e:832		put4(n+4)*/
    if (IS_ATOM_INT(_n_16363)) {
        _9307 = _n_16363 + 4;
        if ((object)((uintptr_t)_9307 + (uintptr_t)HIGH_BITS) >= 0){
            _9307 = NewDouble((eudouble)_9307);
        }
    }
    else {
        _9307 = NewDouble(DBL_PTR(_n_16363)->dbl + (eudouble)4);
    }
    DeRef(_x_inlined_put4_at_509_16454);
    _x_inlined_put4_at_509_16454 = _9307;
    _9307 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_509_16454)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_509_16454;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_509_16454)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at512_16455);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at512_16455 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at512_16455); // DJP 

    /** eds.e:444	end procedure*/
    goto LD; // [534] 537
LD: 
    DeRef(_x_inlined_put4_at_509_16454);
    _x_inlined_put4_at_509_16454 = NOVALUE;
    DeRefi(_put4_1__tmp_at512_16455);
    _put4_1__tmp_at512_16455 = NOVALUE;

    /** eds.e:833		return io:where(current_db)*/

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_542_16457);
    _where_inlined_where_at_542_16457 = machine(20, _41current_db_15734);
    DeRef(_n_16363);
    DeRef(_free_list_16364);
    DeRef(_size_16365);
    DeRef(_size_ptr_16366);
    DeRef(_addr_16367);
    DeRef(_remaining_16369);
    return _where_inlined_where_at_542_16457;
    ;
}


void _41db_free(object _p_16460)
{
    object _psize_16461 = NOVALUE;
    object _i_16462 = NOVALUE;
    object _size_16463 = NOVALUE;
    object _addr_16464 = NOVALUE;
    object _free_list_16465 = NOVALUE;
    object _free_list_space_16466 = NOVALUE;
    object _new_space_16467 = NOVALUE;
    object _to_be_freed_16468 = NOVALUE;
    object _prev_addr_16469 = NOVALUE;
    object _prev_size_16470 = NOVALUE;
    object _free_count_16471 = NOVALUE;
    object _remaining_16472 = NOVALUE;
    object _seek_1__tmp_at11_16477 = NOVALUE;
    object _seek_inlined_seek_at_11_16476 = NOVALUE;
    object _pos_inlined_seek_at_8_16475 = NOVALUE;
    object _seek_1__tmp_at33_16481 = NOVALUE;
    object _seek_inlined_seek_at_33_16480 = NOVALUE;
    object _seek_1__tmp_at69_16488 = NOVALUE;
    object _seek_inlined_seek_at_69_16487 = NOVALUE;
    object _pos_inlined_seek_at_66_16486 = NOVALUE;
    object _seek_1__tmp_at133_16501 = NOVALUE;
    object _seek_inlined_seek_at_133_16500 = NOVALUE;
    object _seek_1__tmp_at157_16505 = NOVALUE;
    object _seek_inlined_seek_at_157_16504 = NOVALUE;
    object _put4_1__tmp_at172_16507 = NOVALUE;
    object _seek_1__tmp_at202_16510 = NOVALUE;
    object _seek_inlined_seek_at_202_16509 = NOVALUE;
    object _seek_1__tmp_at234_16515 = NOVALUE;
    object _seek_inlined_seek_at_234_16514 = NOVALUE;
    object _s_inlined_putn_at_274_16521 = NOVALUE;
    object _seek_1__tmp_at297_16524 = NOVALUE;
    object _seek_inlined_seek_at_297_16523 = NOVALUE;
    object _seek_1__tmp_at430_16545 = NOVALUE;
    object _seek_inlined_seek_at_430_16544 = NOVALUE;
    object _pos_inlined_seek_at_427_16543 = NOVALUE;
    object _put4_1__tmp_at482_16555 = NOVALUE;
    object _x_inlined_put4_at_479_16554 = NOVALUE;
    object _seek_1__tmp_at523_16561 = NOVALUE;
    object _seek_inlined_seek_at_523_16560 = NOVALUE;
    object _pos_inlined_seek_at_520_16559 = NOVALUE;
    object _seek_1__tmp_at574_16571 = NOVALUE;
    object _seek_inlined_seek_at_574_16570 = NOVALUE;
    object _pos_inlined_seek_at_571_16569 = NOVALUE;
    object _seek_1__tmp_at611_16576 = NOVALUE;
    object _seek_inlined_seek_at_611_16575 = NOVALUE;
    object _put4_1__tmp_at626_16578 = NOVALUE;
    object _put4_1__tmp_at664_16583 = NOVALUE;
    object _x_inlined_put4_at_661_16582 = NOVALUE;
    object _seek_1__tmp_at737_16595 = NOVALUE;
    object _seek_inlined_seek_at_737_16594 = NOVALUE;
    object _pos_inlined_seek_at_734_16593 = NOVALUE;
    object _put4_1__tmp_at752_16597 = NOVALUE;
    object _put4_1__tmp_at789_16601 = NOVALUE;
    object _x_inlined_put4_at_786_16600 = NOVALUE;
    object _seek_1__tmp_at837_16609 = NOVALUE;
    object _seek_inlined_seek_at_837_16608 = NOVALUE;
    object _pos_inlined_seek_at_834_16607 = NOVALUE;
    object _seek_1__tmp_at883_16617 = NOVALUE;
    object _seek_inlined_seek_at_883_16616 = NOVALUE;
    object _put4_1__tmp_at898_16619 = NOVALUE;
    object _seek_1__tmp_at943_16626 = NOVALUE;
    object _seek_inlined_seek_at_943_16625 = NOVALUE;
    object _pos_inlined_seek_at_940_16624 = NOVALUE;
    object _put4_1__tmp_at958_16628 = NOVALUE;
    object _put4_1__tmp_at986_16630 = NOVALUE;
    object _9375 = NOVALUE;
    object _9374 = NOVALUE;
    object _9373 = NOVALUE;
    object _9370 = NOVALUE;
    object _9369 = NOVALUE;
    object _9368 = NOVALUE;
    object _9367 = NOVALUE;
    object _9366 = NOVALUE;
    object _9365 = NOVALUE;
    object _9364 = NOVALUE;
    object _9363 = NOVALUE;
    object _9362 = NOVALUE;
    object _9361 = NOVALUE;
    object _9360 = NOVALUE;
    object _9359 = NOVALUE;
    object _9358 = NOVALUE;
    object _9357 = NOVALUE;
    object _9356 = NOVALUE;
    object _9354 = NOVALUE;
    object _9353 = NOVALUE;
    object _9352 = NOVALUE;
    object _9350 = NOVALUE;
    object _9349 = NOVALUE;
    object _9348 = NOVALUE;
    object _9347 = NOVALUE;
    object _9346 = NOVALUE;
    object _9345 = NOVALUE;
    object _9344 = NOVALUE;
    object _9343 = NOVALUE;
    object _9342 = NOVALUE;
    object _9341 = NOVALUE;
    object _9340 = NOVALUE;
    object _9339 = NOVALUE;
    object _9338 = NOVALUE;
    object _9337 = NOVALUE;
    object _9336 = NOVALUE;
    object _9335 = NOVALUE;
    object _9334 = NOVALUE;
    object _9333 = NOVALUE;
    object _9327 = NOVALUE;
    object _9326 = NOVALUE;
    object _9325 = NOVALUE;
    object _9323 = NOVALUE;
    object _9319 = NOVALUE;
    object _9318 = NOVALUE;
    object _9316 = NOVALUE;
    object _9315 = NOVALUE;
    object _9313 = NOVALUE;
    object _9312 = NOVALUE;
    object _9308 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:844		io:seek(current_db, p-4)*/
    if (IS_ATOM_INT(_p_16460)) {
        _9308 = _p_16460 - 4;
        if ((object)((uintptr_t)_9308 +(uintptr_t) HIGH_BITS) >= 0){
            _9308 = NewDouble((eudouble)_9308);
        }
    }
    else {
        _9308 = NewDouble(DBL_PTR(_p_16460)->dbl - (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_8_16475);
    _pos_inlined_seek_at_8_16475 = _9308;
    _9308 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_16475);
    DeRef(_seek_1__tmp_at11_16477);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_8_16475;
    _seek_1__tmp_at11_16477 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_16476 = machine(19, _seek_1__tmp_at11_16477);
    DeRef(_pos_inlined_seek_at_8_16475);
    _pos_inlined_seek_at_8_16475 = NOVALUE;
    DeRef(_seek_1__tmp_at11_16477);
    _seek_1__tmp_at11_16477 = NOVALUE;

    /** eds.e:845		psize = get4()*/
    _0 = _psize_16461;
    _psize_16461 = _41get4();
    DeRef(_0);

    /** eds.e:847		io:seek(current_db, FREE_COUNT)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at33_16481);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = 7;
    _seek_1__tmp_at33_16481 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_33_16480 = machine(19, _seek_1__tmp_at33_16481);
    DeRefi(_seek_1__tmp_at33_16481);
    _seek_1__tmp_at33_16481 = NOVALUE;

    /** eds.e:848		free_count = get4()*/
    _free_count_16471 = _41get4();
    if (!IS_ATOM_INT(_free_count_16471)) {
        _1 = (object)(DBL_PTR(_free_count_16471)->dbl);
        DeRefDS(_free_count_16471);
        _free_count_16471 = _1;
    }

    /** eds.e:849		free_list = get4()*/
    _0 = _free_list_16465;
    _free_list_16465 = _41get4();
    DeRef(_0);

    /** eds.e:850		io:seek(current_db, free_list - 4)*/
    if (IS_ATOM_INT(_free_list_16465)) {
        _9312 = _free_list_16465 - 4;
        if ((object)((uintptr_t)_9312 +(uintptr_t) HIGH_BITS) >= 0){
            _9312 = NewDouble((eudouble)_9312);
        }
    }
    else {
        _9312 = NewDouble(DBL_PTR(_free_list_16465)->dbl - (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_66_16486);
    _pos_inlined_seek_at_66_16486 = _9312;
    _9312 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_66_16486);
    DeRef(_seek_1__tmp_at69_16488);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_66_16486;
    _seek_1__tmp_at69_16488 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_69_16487 = machine(19, _seek_1__tmp_at69_16488);
    DeRef(_pos_inlined_seek_at_66_16486);
    _pos_inlined_seek_at_66_16486 = NOVALUE;
    DeRef(_seek_1__tmp_at69_16488);
    _seek_1__tmp_at69_16488 = NOVALUE;

    /** eds.e:851		free_list_space = get4()-4*/
    _9313 = _41get4();
    DeRef(_free_list_space_16466);
    if (IS_ATOM_INT(_9313)) {
        _free_list_space_16466 = _9313 - 4;
        if ((object)((uintptr_t)_free_list_space_16466 +(uintptr_t) HIGH_BITS) >= 0){
            _free_list_space_16466 = NewDouble((eudouble)_free_list_space_16466);
        }
    }
    else {
        _free_list_space_16466 = binary_op(MINUS, _9313, 4);
    }
    DeRef(_9313);
    _9313 = NOVALUE;

    /** eds.e:852		if free_list_space < 8 * (free_count+1) then*/
    _9315 = _free_count_16471 + 1;
    if (_9315 > MAXINT){
        _9315 = NewDouble((eudouble)_9315);
    }
    if (IS_ATOM_INT(_9315)) {
        if (_9315 <= INT15 && _9315 >= -INT15){
            _9316 = 8 * _9315;
        }
        else{
            _9316 = NewDouble(8 * (eudouble)_9315);
        }
    }
    else {
        _9316 = NewDouble((eudouble)8 * DBL_PTR(_9315)->dbl);
    }
    DeRef(_9315);
    _9315 = NOVALUE;
    if (binary_op_a(GREATEREQ, _free_list_space_16466, _9316)){
        DeRef(_9316);
        _9316 = NOVALUE;
        goto L1; // [102] 314
    }
    DeRef(_9316);
    _9316 = NOVALUE;

    /** eds.e:854			new_space = floor(free_list_space + free_list_space / 2)*/
    if (IS_ATOM_INT(_free_list_space_16466)) {
        if (_free_list_space_16466 & 1) {
            _9318 = NewDouble((_free_list_space_16466 >> 1) + 0.5);
        }
        else
        _9318 = _free_list_space_16466 >> 1;
    }
    else {
        _9318 = binary_op(DIVIDE, _free_list_space_16466, 2);
    }
    if (IS_ATOM_INT(_free_list_space_16466) && IS_ATOM_INT(_9318)) {
        _9319 = _free_list_space_16466 + _9318;
        if ((object)((uintptr_t)_9319 + (uintptr_t)HIGH_BITS) >= 0){
            _9319 = NewDouble((eudouble)_9319);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_space_16466)) {
            _9319 = NewDouble((eudouble)_free_list_space_16466 + DBL_PTR(_9318)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9318)) {
                _9319 = NewDouble(DBL_PTR(_free_list_space_16466)->dbl + (eudouble)_9318);
            }
            else
            _9319 = NewDouble(DBL_PTR(_free_list_space_16466)->dbl + DBL_PTR(_9318)->dbl);
        }
    }
    DeRef(_9318);
    _9318 = NOVALUE;
    DeRef(_new_space_16467);
    if (IS_ATOM_INT(_9319))
    _new_space_16467 = e_floor(_9319);
    else
    _new_space_16467 = unary_op(FLOOR, _9319);
    DeRef(_9319);
    _9319 = NOVALUE;

    /** eds.e:855			to_be_freed = free_list*/
    Ref(_free_list_16465);
    DeRef(_to_be_freed_16468);
    _to_be_freed_16468 = _free_list_16465;

    /** eds.e:856			free_list = db_allocate(new_space)*/
    Ref(_new_space_16467);
    _0 = _free_list_16465;
    _free_list_16465 = _41db_allocate(_new_space_16467);
    DeRef(_0);

    /** eds.e:857			io:seek(current_db, FREE_COUNT)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at133_16501);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = 7;
    _seek_1__tmp_at133_16501 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_133_16500 = machine(19, _seek_1__tmp_at133_16501);
    DeRefi(_seek_1__tmp_at133_16501);
    _seek_1__tmp_at133_16501 = NOVALUE;

    /** eds.e:858			free_count = get4() -- db_allocate may have changed it*/
    _free_count_16471 = _41get4();
    if (!IS_ATOM_INT(_free_count_16471)) {
        _1 = (object)(DBL_PTR(_free_count_16471)->dbl);
        DeRefDS(_free_count_16471);
        _free_count_16471 = _1;
    }

    /** eds.e:859			io:seek(current_db, FREE_LIST)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at157_16505);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = 11;
    _seek_1__tmp_at157_16505 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_157_16504 = machine(19, _seek_1__tmp_at157_16505);
    DeRefi(_seek_1__tmp_at157_16505);
    _seek_1__tmp_at157_16505 = NOVALUE;

    /** eds.e:860			put4(free_list)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_free_list_16465)) {
        *poke4_addr = (uint32_t)_free_list_16465;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_free_list_16465)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at172_16507);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at172_16507 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at172_16507); // DJP 

    /** eds.e:444	end procedure*/
    goto L2; // [194] 197
L2: 
    DeRefi(_put4_1__tmp_at172_16507);
    _put4_1__tmp_at172_16507 = NOVALUE;

    /** eds.e:861			io:seek(current_db, to_be_freed)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_to_be_freed_16468);
    DeRef(_seek_1__tmp_at202_16510);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _to_be_freed_16468;
    _seek_1__tmp_at202_16510 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_202_16509 = machine(19, _seek_1__tmp_at202_16510);
    DeRef(_seek_1__tmp_at202_16510);
    _seek_1__tmp_at202_16510 = NOVALUE;

    /** eds.e:862			remaining = io:get_bytes(current_db, 8*free_count)*/
    if (_free_count_16471 <= INT15 && _free_count_16471 >= -INT15){
        _9323 = 8 * _free_count_16471;
    }
    else{
        _9323 = NewDouble(8 * (eudouble)_free_count_16471);
    }
    _0 = _remaining_16472;
    _remaining_16472 = _17get_bytes(_41current_db_15734, _9323);
    DeRef(_0);
    _9323 = NOVALUE;

    /** eds.e:863			io:seek(current_db, free_list)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_16465);
    DeRef(_seek_1__tmp_at234_16515);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _free_list_16465;
    _seek_1__tmp_at234_16515 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_234_16514 = machine(19, _seek_1__tmp_at234_16515);
    DeRef(_seek_1__tmp_at234_16515);
    _seek_1__tmp_at234_16515 = NOVALUE;

    /** eds.e:864			putn(remaining)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_15734, _remaining_16472); // DJP 

    /** eds.e:449	end procedure*/
    goto L3; // [259] 262
L3: 

    /** eds.e:865			putn(repeat(0, new_space-length(remaining)))*/
    if (IS_SEQUENCE(_remaining_16472)){
            _9325 = SEQ_PTR(_remaining_16472)->length;
    }
    else {
        _9325 = 1;
    }
    if (IS_ATOM_INT(_new_space_16467)) {
        _9326 = _new_space_16467 - _9325;
    }
    else {
        _9326 = NewDouble(DBL_PTR(_new_space_16467)->dbl - (eudouble)_9325);
    }
    _9325 = NOVALUE;
    _9327 = Repeat(0, _9326);
    DeRef(_9326);
    _9326 = NOVALUE;
    DeRefi(_s_inlined_putn_at_274_16521);
    _s_inlined_putn_at_274_16521 = _9327;
    _9327 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_15734, _s_inlined_putn_at_274_16521); // DJP 

    /** eds.e:449	end procedure*/
    goto L4; // [289] 292
L4: 
    DeRefi(_s_inlined_putn_at_274_16521);
    _s_inlined_putn_at_274_16521 = NOVALUE;

    /** eds.e:866			io:seek(current_db, free_list)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_16465);
    DeRef(_seek_1__tmp_at297_16524);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _free_list_16465;
    _seek_1__tmp_at297_16524 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_297_16523 = machine(19, _seek_1__tmp_at297_16524);
    DeRef(_seek_1__tmp_at297_16524);
    _seek_1__tmp_at297_16524 = NOVALUE;
    goto L5; // [311] 320
L1: 

    /** eds.e:868			new_space = 0*/
    DeRef(_new_space_16467);
    _new_space_16467 = 0;
L5: 

    /** eds.e:871		i = 1*/
    DeRef(_i_16462);
    _i_16462 = 1;

    /** eds.e:872		prev_addr = 0*/
    DeRef(_prev_addr_16469);
    _prev_addr_16469 = 0;

    /** eds.e:873		prev_size = 0*/
    DeRef(_prev_size_16470);
    _prev_size_16470 = 0;

    /** eds.e:874		while i <= free_count do*/
L6: 
    if (binary_op_a(GREATER, _i_16462, _free_count_16471)){
        goto L7; // [340] 386
    }

    /** eds.e:875			addr = get4()*/
    _0 = _addr_16464;
    _addr_16464 = _41get4();
    DeRef(_0);

    /** eds.e:876			size = get4()*/
    _0 = _size_16463;
    _size_16463 = _41get4();
    DeRef(_0);

    /** eds.e:877			if p < addr then*/
    if (binary_op_a(GREATEREQ, _p_16460, _addr_16464)){
        goto L8; // [356] 365
    }

    /** eds.e:878				exit*/
    goto L7; // [362] 386
L8: 

    /** eds.e:880			prev_addr = addr*/
    Ref(_addr_16464);
    DeRef(_prev_addr_16469);
    _prev_addr_16469 = _addr_16464;

    /** eds.e:881			prev_size = size*/
    Ref(_size_16463);
    DeRef(_prev_size_16470);
    _prev_size_16470 = _size_16463;

    /** eds.e:882			i += 1*/
    _0 = _i_16462;
    if (IS_ATOM_INT(_i_16462)) {
        _i_16462 = _i_16462 + 1;
        if (_i_16462 > MAXINT){
            _i_16462 = NewDouble((eudouble)_i_16462);
        }
    }
    else
    _i_16462 = binary_op(PLUS, 1, _i_16462);
    DeRef(_0);

    /** eds.e:883		end while*/
    goto L6; // [383] 340
L7: 

    /** eds.e:885		if i > 1 and prev_addr + prev_size = p then*/
    if (IS_ATOM_INT(_i_16462)) {
        _9333 = (_i_16462 > 1);
    }
    else {
        _9333 = (DBL_PTR(_i_16462)->dbl > (eudouble)1);
    }
    if (_9333 == 0) {
        goto L9; // [392] 695
    }
    if (IS_ATOM_INT(_prev_addr_16469) && IS_ATOM_INT(_prev_size_16470)) {
        _9335 = _prev_addr_16469 + _prev_size_16470;
        if ((object)((uintptr_t)_9335 + (uintptr_t)HIGH_BITS) >= 0){
            _9335 = NewDouble((eudouble)_9335);
        }
    }
    else {
        if (IS_ATOM_INT(_prev_addr_16469)) {
            _9335 = NewDouble((eudouble)_prev_addr_16469 + DBL_PTR(_prev_size_16470)->dbl);
        }
        else {
            if (IS_ATOM_INT(_prev_size_16470)) {
                _9335 = NewDouble(DBL_PTR(_prev_addr_16469)->dbl + (eudouble)_prev_size_16470);
            }
            else
            _9335 = NewDouble(DBL_PTR(_prev_addr_16469)->dbl + DBL_PTR(_prev_size_16470)->dbl);
        }
    }
    if (IS_ATOM_INT(_9335) && IS_ATOM_INT(_p_16460)) {
        _9336 = (_9335 == _p_16460);
    }
    else {
        if (IS_ATOM_INT(_9335)) {
            _9336 = ((eudouble)_9335 == DBL_PTR(_p_16460)->dbl);
        }
        else {
            if (IS_ATOM_INT(_p_16460)) {
                _9336 = (DBL_PTR(_9335)->dbl == (eudouble)_p_16460);
            }
            else
            _9336 = (DBL_PTR(_9335)->dbl == DBL_PTR(_p_16460)->dbl);
        }
    }
    DeRef(_9335);
    _9335 = NOVALUE;
    if (_9336 == 0)
    {
        DeRef(_9336);
        _9336 = NOVALUE;
        goto L9; // [405] 695
    }
    else{
        DeRef(_9336);
        _9336 = NOVALUE;
    }

    /** eds.e:887			io:seek(current_db, free_list+(i-2)*8+4)*/
    if (IS_ATOM_INT(_i_16462)) {
        _9337 = _i_16462 - 2;
        if ((object)((uintptr_t)_9337 +(uintptr_t) HIGH_BITS) >= 0){
            _9337 = NewDouble((eudouble)_9337);
        }
    }
    else {
        _9337 = NewDouble(DBL_PTR(_i_16462)->dbl - (eudouble)2);
    }
    if (IS_ATOM_INT(_9337)) {
        if (_9337 == (short)_9337){
            _9338 = _9337 * 8;
        }
        else{
            _9338 = NewDouble(_9337 * (eudouble)8);
        }
    }
    else {
        _9338 = NewDouble(DBL_PTR(_9337)->dbl * (eudouble)8);
    }
    DeRef(_9337);
    _9337 = NOVALUE;
    if (IS_ATOM_INT(_free_list_16465) && IS_ATOM_INT(_9338)) {
        _9339 = _free_list_16465 + _9338;
        if ((object)((uintptr_t)_9339 + (uintptr_t)HIGH_BITS) >= 0){
            _9339 = NewDouble((eudouble)_9339);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_16465)) {
            _9339 = NewDouble((eudouble)_free_list_16465 + DBL_PTR(_9338)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9338)) {
                _9339 = NewDouble(DBL_PTR(_free_list_16465)->dbl + (eudouble)_9338);
            }
            else
            _9339 = NewDouble(DBL_PTR(_free_list_16465)->dbl + DBL_PTR(_9338)->dbl);
        }
    }
    DeRef(_9338);
    _9338 = NOVALUE;
    if (IS_ATOM_INT(_9339)) {
        _9340 = _9339 + 4;
        if ((object)((uintptr_t)_9340 + (uintptr_t)HIGH_BITS) >= 0){
            _9340 = NewDouble((eudouble)_9340);
        }
    }
    else {
        _9340 = NewDouble(DBL_PTR(_9339)->dbl + (eudouble)4);
    }
    DeRef(_9339);
    _9339 = NOVALUE;
    DeRef(_pos_inlined_seek_at_427_16543);
    _pos_inlined_seek_at_427_16543 = _9340;
    _9340 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_427_16543);
    DeRef(_seek_1__tmp_at430_16545);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_427_16543;
    _seek_1__tmp_at430_16545 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_430_16544 = machine(19, _seek_1__tmp_at430_16545);
    DeRef(_pos_inlined_seek_at_427_16543);
    _pos_inlined_seek_at_427_16543 = NOVALUE;
    DeRef(_seek_1__tmp_at430_16545);
    _seek_1__tmp_at430_16545 = NOVALUE;

    /** eds.e:888			if i < free_count and p + psize = addr then*/
    if (IS_ATOM_INT(_i_16462)) {
        _9341 = (_i_16462 < _free_count_16471);
    }
    else {
        _9341 = (DBL_PTR(_i_16462)->dbl < (eudouble)_free_count_16471);
    }
    if (_9341 == 0) {
        goto LA; // [450] 656
    }
    if (IS_ATOM_INT(_p_16460) && IS_ATOM_INT(_psize_16461)) {
        _9343 = _p_16460 + _psize_16461;
        if ((object)((uintptr_t)_9343 + (uintptr_t)HIGH_BITS) >= 0){
            _9343 = NewDouble((eudouble)_9343);
        }
    }
    else {
        if (IS_ATOM_INT(_p_16460)) {
            _9343 = NewDouble((eudouble)_p_16460 + DBL_PTR(_psize_16461)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_16461)) {
                _9343 = NewDouble(DBL_PTR(_p_16460)->dbl + (eudouble)_psize_16461);
            }
            else
            _9343 = NewDouble(DBL_PTR(_p_16460)->dbl + DBL_PTR(_psize_16461)->dbl);
        }
    }
    if (IS_ATOM_INT(_9343) && IS_ATOM_INT(_addr_16464)) {
        _9344 = (_9343 == _addr_16464);
    }
    else {
        if (IS_ATOM_INT(_9343)) {
            _9344 = ((eudouble)_9343 == DBL_PTR(_addr_16464)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_16464)) {
                _9344 = (DBL_PTR(_9343)->dbl == (eudouble)_addr_16464);
            }
            else
            _9344 = (DBL_PTR(_9343)->dbl == DBL_PTR(_addr_16464)->dbl);
        }
    }
    DeRef(_9343);
    _9343 = NOVALUE;
    if (_9344 == 0)
    {
        DeRef(_9344);
        _9344 = NOVALUE;
        goto LA; // [465] 656
    }
    else{
        DeRef(_9344);
        _9344 = NOVALUE;
    }

    /** eds.e:890				put4(prev_size+psize+size) -- update size on free list (only)*/
    if (IS_ATOM_INT(_prev_size_16470) && IS_ATOM_INT(_psize_16461)) {
        _9345 = _prev_size_16470 + _psize_16461;
        if ((object)((uintptr_t)_9345 + (uintptr_t)HIGH_BITS) >= 0){
            _9345 = NewDouble((eudouble)_9345);
        }
    }
    else {
        if (IS_ATOM_INT(_prev_size_16470)) {
            _9345 = NewDouble((eudouble)_prev_size_16470 + DBL_PTR(_psize_16461)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_16461)) {
                _9345 = NewDouble(DBL_PTR(_prev_size_16470)->dbl + (eudouble)_psize_16461);
            }
            else
            _9345 = NewDouble(DBL_PTR(_prev_size_16470)->dbl + DBL_PTR(_psize_16461)->dbl);
        }
    }
    if (IS_ATOM_INT(_9345) && IS_ATOM_INT(_size_16463)) {
        _9346 = _9345 + _size_16463;
        if ((object)((uintptr_t)_9346 + (uintptr_t)HIGH_BITS) >= 0){
            _9346 = NewDouble((eudouble)_9346);
        }
    }
    else {
        if (IS_ATOM_INT(_9345)) {
            _9346 = NewDouble((eudouble)_9345 + DBL_PTR(_size_16463)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size_16463)) {
                _9346 = NewDouble(DBL_PTR(_9345)->dbl + (eudouble)_size_16463);
            }
            else
            _9346 = NewDouble(DBL_PTR(_9345)->dbl + DBL_PTR(_size_16463)->dbl);
        }
    }
    DeRef(_9345);
    _9345 = NOVALUE;
    DeRef(_x_inlined_put4_at_479_16554);
    _x_inlined_put4_at_479_16554 = _9346;
    _9346 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_479_16554)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_479_16554;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_479_16554)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at482_16555);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at482_16555 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at482_16555); // DJP 

    /** eds.e:444	end procedure*/
    goto LB; // [504] 507
LB: 
    DeRef(_x_inlined_put4_at_479_16554);
    _x_inlined_put4_at_479_16554 = NOVALUE;
    DeRefi(_put4_1__tmp_at482_16555);
    _put4_1__tmp_at482_16555 = NOVALUE;

    /** eds.e:891				io:seek(current_db, free_list+i*8)*/
    if (IS_ATOM_INT(_i_16462)) {
        if (_i_16462 == (short)_i_16462){
            _9347 = _i_16462 * 8;
        }
        else{
            _9347 = NewDouble(_i_16462 * (eudouble)8);
        }
    }
    else {
        _9347 = NewDouble(DBL_PTR(_i_16462)->dbl * (eudouble)8);
    }
    if (IS_ATOM_INT(_free_list_16465) && IS_ATOM_INT(_9347)) {
        _9348 = _free_list_16465 + _9347;
        if ((object)((uintptr_t)_9348 + (uintptr_t)HIGH_BITS) >= 0){
            _9348 = NewDouble((eudouble)_9348);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_16465)) {
            _9348 = NewDouble((eudouble)_free_list_16465 + DBL_PTR(_9347)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9347)) {
                _9348 = NewDouble(DBL_PTR(_free_list_16465)->dbl + (eudouble)_9347);
            }
            else
            _9348 = NewDouble(DBL_PTR(_free_list_16465)->dbl + DBL_PTR(_9347)->dbl);
        }
    }
    DeRef(_9347);
    _9347 = NOVALUE;
    DeRef(_pos_inlined_seek_at_520_16559);
    _pos_inlined_seek_at_520_16559 = _9348;
    _9348 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_520_16559);
    DeRef(_seek_1__tmp_at523_16561);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_520_16559;
    _seek_1__tmp_at523_16561 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_523_16560 = machine(19, _seek_1__tmp_at523_16561);
    DeRef(_pos_inlined_seek_at_520_16559);
    _pos_inlined_seek_at_520_16559 = NOVALUE;
    DeRef(_seek_1__tmp_at523_16561);
    _seek_1__tmp_at523_16561 = NOVALUE;

    /** eds.e:892				remaining = io:get_bytes(current_db, (free_count-i)*8)*/
    if (IS_ATOM_INT(_i_16462)) {
        _9349 = _free_count_16471 - _i_16462;
        if ((object)((uintptr_t)_9349 +(uintptr_t) HIGH_BITS) >= 0){
            _9349 = NewDouble((eudouble)_9349);
        }
    }
    else {
        _9349 = NewDouble((eudouble)_free_count_16471 - DBL_PTR(_i_16462)->dbl);
    }
    if (IS_ATOM_INT(_9349)) {
        if (_9349 == (short)_9349){
            _9350 = _9349 * 8;
        }
        else{
            _9350 = NewDouble(_9349 * (eudouble)8);
        }
    }
    else {
        _9350 = NewDouble(DBL_PTR(_9349)->dbl * (eudouble)8);
    }
    DeRef(_9349);
    _9349 = NOVALUE;
    _0 = _remaining_16472;
    _remaining_16472 = _17get_bytes(_41current_db_15734, _9350);
    DeRef(_0);
    _9350 = NOVALUE;

    /** eds.e:893				io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_16462)) {
        _9352 = _i_16462 - 1;
        if ((object)((uintptr_t)_9352 +(uintptr_t) HIGH_BITS) >= 0){
            _9352 = NewDouble((eudouble)_9352);
        }
    }
    else {
        _9352 = NewDouble(DBL_PTR(_i_16462)->dbl - (eudouble)1);
    }
    if (IS_ATOM_INT(_9352)) {
        if (_9352 == (short)_9352){
            _9353 = _9352 * 8;
        }
        else{
            _9353 = NewDouble(_9352 * (eudouble)8);
        }
    }
    else {
        _9353 = NewDouble(DBL_PTR(_9352)->dbl * (eudouble)8);
    }
    DeRef(_9352);
    _9352 = NOVALUE;
    if (IS_ATOM_INT(_free_list_16465) && IS_ATOM_INT(_9353)) {
        _9354 = _free_list_16465 + _9353;
        if ((object)((uintptr_t)_9354 + (uintptr_t)HIGH_BITS) >= 0){
            _9354 = NewDouble((eudouble)_9354);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_16465)) {
            _9354 = NewDouble((eudouble)_free_list_16465 + DBL_PTR(_9353)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9353)) {
                _9354 = NewDouble(DBL_PTR(_free_list_16465)->dbl + (eudouble)_9353);
            }
            else
            _9354 = NewDouble(DBL_PTR(_free_list_16465)->dbl + DBL_PTR(_9353)->dbl);
        }
    }
    DeRef(_9353);
    _9353 = NOVALUE;
    DeRef(_pos_inlined_seek_at_571_16569);
    _pos_inlined_seek_at_571_16569 = _9354;
    _9354 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_571_16569);
    DeRef(_seek_1__tmp_at574_16571);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_571_16569;
    _seek_1__tmp_at574_16571 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_574_16570 = machine(19, _seek_1__tmp_at574_16571);
    DeRef(_pos_inlined_seek_at_571_16569);
    _pos_inlined_seek_at_571_16569 = NOVALUE;
    DeRef(_seek_1__tmp_at574_16571);
    _seek_1__tmp_at574_16571 = NOVALUE;

    /** eds.e:894				putn(remaining)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_15734, _remaining_16472); // DJP 

    /** eds.e:449	end procedure*/
    goto LC; // [599] 602
LC: 

    /** eds.e:895				free_count -= 1*/
    _free_count_16471 = _free_count_16471 - 1;

    /** eds.e:896				io:seek(current_db, FREE_COUNT)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at611_16576);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = 7;
    _seek_1__tmp_at611_16576 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_611_16575 = machine(19, _seek_1__tmp_at611_16576);
    DeRefi(_seek_1__tmp_at611_16576);
    _seek_1__tmp_at611_16576 = NOVALUE;

    /** eds.e:897				put4(free_count)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    *poke4_addr = (uint32_t)_free_count_16471;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at626_16578);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at626_16578 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at626_16578); // DJP 

    /** eds.e:444	end procedure*/
    goto LD; // [648] 651
LD: 
    DeRefi(_put4_1__tmp_at626_16578);
    _put4_1__tmp_at626_16578 = NOVALUE;
    goto LE; // [653] 1028
LA: 

    /** eds.e:899				put4(prev_size+psize) -- increase previous size on free list (only)*/
    if (IS_ATOM_INT(_prev_size_16470) && IS_ATOM_INT(_psize_16461)) {
        _9356 = _prev_size_16470 + _psize_16461;
        if ((object)((uintptr_t)_9356 + (uintptr_t)HIGH_BITS) >= 0){
            _9356 = NewDouble((eudouble)_9356);
        }
    }
    else {
        if (IS_ATOM_INT(_prev_size_16470)) {
            _9356 = NewDouble((eudouble)_prev_size_16470 + DBL_PTR(_psize_16461)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_16461)) {
                _9356 = NewDouble(DBL_PTR(_prev_size_16470)->dbl + (eudouble)_psize_16461);
            }
            else
            _9356 = NewDouble(DBL_PTR(_prev_size_16470)->dbl + DBL_PTR(_psize_16461)->dbl);
        }
    }
    DeRef(_x_inlined_put4_at_661_16582);
    _x_inlined_put4_at_661_16582 = _9356;
    _9356 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_661_16582)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_661_16582;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_661_16582)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at664_16583);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at664_16583 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at664_16583); // DJP 

    /** eds.e:444	end procedure*/
    goto LF; // [686] 689
LF: 
    DeRef(_x_inlined_put4_at_661_16582);
    _x_inlined_put4_at_661_16582 = NOVALUE;
    DeRefi(_put4_1__tmp_at664_16583);
    _put4_1__tmp_at664_16583 = NOVALUE;
    goto LE; // [692] 1028
L9: 

    /** eds.e:901		elsif i < free_count and p + psize = addr then*/
    if (IS_ATOM_INT(_i_16462)) {
        _9357 = (_i_16462 < _free_count_16471);
    }
    else {
        _9357 = (DBL_PTR(_i_16462)->dbl < (eudouble)_free_count_16471);
    }
    if (_9357 == 0) {
        goto L10; // [701] 819
    }
    if (IS_ATOM_INT(_p_16460) && IS_ATOM_INT(_psize_16461)) {
        _9359 = _p_16460 + _psize_16461;
        if ((object)((uintptr_t)_9359 + (uintptr_t)HIGH_BITS) >= 0){
            _9359 = NewDouble((eudouble)_9359);
        }
    }
    else {
        if (IS_ATOM_INT(_p_16460)) {
            _9359 = NewDouble((eudouble)_p_16460 + DBL_PTR(_psize_16461)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_16461)) {
                _9359 = NewDouble(DBL_PTR(_p_16460)->dbl + (eudouble)_psize_16461);
            }
            else
            _9359 = NewDouble(DBL_PTR(_p_16460)->dbl + DBL_PTR(_psize_16461)->dbl);
        }
    }
    if (IS_ATOM_INT(_9359) && IS_ATOM_INT(_addr_16464)) {
        _9360 = (_9359 == _addr_16464);
    }
    else {
        if (IS_ATOM_INT(_9359)) {
            _9360 = ((eudouble)_9359 == DBL_PTR(_addr_16464)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_16464)) {
                _9360 = (DBL_PTR(_9359)->dbl == (eudouble)_addr_16464);
            }
            else
            _9360 = (DBL_PTR(_9359)->dbl == DBL_PTR(_addr_16464)->dbl);
        }
    }
    DeRef(_9359);
    _9359 = NOVALUE;
    if (_9360 == 0)
    {
        DeRef(_9360);
        _9360 = NOVALUE;
        goto L10; // [716] 819
    }
    else{
        DeRef(_9360);
        _9360 = NOVALUE;
    }

    /** eds.e:903			io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_16462)) {
        _9361 = _i_16462 - 1;
        if ((object)((uintptr_t)_9361 +(uintptr_t) HIGH_BITS) >= 0){
            _9361 = NewDouble((eudouble)_9361);
        }
    }
    else {
        _9361 = NewDouble(DBL_PTR(_i_16462)->dbl - (eudouble)1);
    }
    if (IS_ATOM_INT(_9361)) {
        if (_9361 == (short)_9361){
            _9362 = _9361 * 8;
        }
        else{
            _9362 = NewDouble(_9361 * (eudouble)8);
        }
    }
    else {
        _9362 = NewDouble(DBL_PTR(_9361)->dbl * (eudouble)8);
    }
    DeRef(_9361);
    _9361 = NOVALUE;
    if (IS_ATOM_INT(_free_list_16465) && IS_ATOM_INT(_9362)) {
        _9363 = _free_list_16465 + _9362;
        if ((object)((uintptr_t)_9363 + (uintptr_t)HIGH_BITS) >= 0){
            _9363 = NewDouble((eudouble)_9363);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_16465)) {
            _9363 = NewDouble((eudouble)_free_list_16465 + DBL_PTR(_9362)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9362)) {
                _9363 = NewDouble(DBL_PTR(_free_list_16465)->dbl + (eudouble)_9362);
            }
            else
            _9363 = NewDouble(DBL_PTR(_free_list_16465)->dbl + DBL_PTR(_9362)->dbl);
        }
    }
    DeRef(_9362);
    _9362 = NOVALUE;
    DeRef(_pos_inlined_seek_at_734_16593);
    _pos_inlined_seek_at_734_16593 = _9363;
    _9363 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_734_16593);
    DeRef(_seek_1__tmp_at737_16595);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_734_16593;
    _seek_1__tmp_at737_16595 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_737_16594 = machine(19, _seek_1__tmp_at737_16595);
    DeRef(_pos_inlined_seek_at_734_16593);
    _pos_inlined_seek_at_734_16593 = NOVALUE;
    DeRef(_seek_1__tmp_at737_16595);
    _seek_1__tmp_at737_16595 = NOVALUE;

    /** eds.e:904			put4(p)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_p_16460)) {
        *poke4_addr = (uint32_t)_p_16460;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_p_16460)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at752_16597);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at752_16597 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at752_16597); // DJP 

    /** eds.e:444	end procedure*/
    goto L11; // [774] 777
L11: 
    DeRefi(_put4_1__tmp_at752_16597);
    _put4_1__tmp_at752_16597 = NOVALUE;

    /** eds.e:905			put4(psize+size)*/
    if (IS_ATOM_INT(_psize_16461) && IS_ATOM_INT(_size_16463)) {
        _9364 = _psize_16461 + _size_16463;
        if ((object)((uintptr_t)_9364 + (uintptr_t)HIGH_BITS) >= 0){
            _9364 = NewDouble((eudouble)_9364);
        }
    }
    else {
        if (IS_ATOM_INT(_psize_16461)) {
            _9364 = NewDouble((eudouble)_psize_16461 + DBL_PTR(_size_16463)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size_16463)) {
                _9364 = NewDouble(DBL_PTR(_psize_16461)->dbl + (eudouble)_size_16463);
            }
            else
            _9364 = NewDouble(DBL_PTR(_psize_16461)->dbl + DBL_PTR(_size_16463)->dbl);
        }
    }
    DeRef(_x_inlined_put4_at_786_16600);
    _x_inlined_put4_at_786_16600 = _9364;
    _9364 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_786_16600)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_786_16600;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_786_16600)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at789_16601);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at789_16601 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at789_16601); // DJP 

    /** eds.e:444	end procedure*/
    goto L12; // [811] 814
L12: 
    DeRef(_x_inlined_put4_at_786_16600);
    _x_inlined_put4_at_786_16600 = NOVALUE;
    DeRefi(_put4_1__tmp_at789_16601);
    _put4_1__tmp_at789_16601 = NOVALUE;
    goto LE; // [816] 1028
L10: 

    /** eds.e:908			io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_16462)) {
        _9365 = _i_16462 - 1;
        if ((object)((uintptr_t)_9365 +(uintptr_t) HIGH_BITS) >= 0){
            _9365 = NewDouble((eudouble)_9365);
        }
    }
    else {
        _9365 = NewDouble(DBL_PTR(_i_16462)->dbl - (eudouble)1);
    }
    if (IS_ATOM_INT(_9365)) {
        if (_9365 == (short)_9365){
            _9366 = _9365 * 8;
        }
        else{
            _9366 = NewDouble(_9365 * (eudouble)8);
        }
    }
    else {
        _9366 = NewDouble(DBL_PTR(_9365)->dbl * (eudouble)8);
    }
    DeRef(_9365);
    _9365 = NOVALUE;
    if (IS_ATOM_INT(_free_list_16465) && IS_ATOM_INT(_9366)) {
        _9367 = _free_list_16465 + _9366;
        if ((object)((uintptr_t)_9367 + (uintptr_t)HIGH_BITS) >= 0){
            _9367 = NewDouble((eudouble)_9367);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_16465)) {
            _9367 = NewDouble((eudouble)_free_list_16465 + DBL_PTR(_9366)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9366)) {
                _9367 = NewDouble(DBL_PTR(_free_list_16465)->dbl + (eudouble)_9366);
            }
            else
            _9367 = NewDouble(DBL_PTR(_free_list_16465)->dbl + DBL_PTR(_9366)->dbl);
        }
    }
    DeRef(_9366);
    _9366 = NOVALUE;
    DeRef(_pos_inlined_seek_at_834_16607);
    _pos_inlined_seek_at_834_16607 = _9367;
    _9367 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_834_16607);
    DeRef(_seek_1__tmp_at837_16609);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_834_16607;
    _seek_1__tmp_at837_16609 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_837_16608 = machine(19, _seek_1__tmp_at837_16609);
    DeRef(_pos_inlined_seek_at_834_16607);
    _pos_inlined_seek_at_834_16607 = NOVALUE;
    DeRef(_seek_1__tmp_at837_16609);
    _seek_1__tmp_at837_16609 = NOVALUE;

    /** eds.e:909			remaining = io:get_bytes(current_db, (free_count-i+1)*8)*/
    if (IS_ATOM_INT(_i_16462)) {
        _9368 = _free_count_16471 - _i_16462;
        if ((object)((uintptr_t)_9368 +(uintptr_t) HIGH_BITS) >= 0){
            _9368 = NewDouble((eudouble)_9368);
        }
    }
    else {
        _9368 = NewDouble((eudouble)_free_count_16471 - DBL_PTR(_i_16462)->dbl);
    }
    if (IS_ATOM_INT(_9368)) {
        _9369 = _9368 + 1;
        if (_9369 > MAXINT){
            _9369 = NewDouble((eudouble)_9369);
        }
    }
    else
    _9369 = binary_op(PLUS, 1, _9368);
    DeRef(_9368);
    _9368 = NOVALUE;
    if (IS_ATOM_INT(_9369)) {
        if (_9369 == (short)_9369){
            _9370 = _9369 * 8;
        }
        else{
            _9370 = NewDouble(_9369 * (eudouble)8);
        }
    }
    else {
        _9370 = NewDouble(DBL_PTR(_9369)->dbl * (eudouble)8);
    }
    DeRef(_9369);
    _9369 = NOVALUE;
    _0 = _remaining_16472;
    _remaining_16472 = _17get_bytes(_41current_db_15734, _9370);
    DeRef(_0);
    _9370 = NOVALUE;

    /** eds.e:910			free_count += 1*/
    _free_count_16471 = _free_count_16471 + 1;

    /** eds.e:911			io:seek(current_db, FREE_COUNT)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at883_16617);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = 7;
    _seek_1__tmp_at883_16617 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_883_16616 = machine(19, _seek_1__tmp_at883_16617);
    DeRefi(_seek_1__tmp_at883_16617);
    _seek_1__tmp_at883_16617 = NOVALUE;

    /** eds.e:912			put4(free_count)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    *poke4_addr = (uint32_t)_free_count_16471;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at898_16619);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at898_16619 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at898_16619); // DJP 

    /** eds.e:444	end procedure*/
    goto L13; // [920] 923
L13: 
    DeRefi(_put4_1__tmp_at898_16619);
    _put4_1__tmp_at898_16619 = NOVALUE;

    /** eds.e:913			io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_16462)) {
        _9373 = _i_16462 - 1;
        if ((object)((uintptr_t)_9373 +(uintptr_t) HIGH_BITS) >= 0){
            _9373 = NewDouble((eudouble)_9373);
        }
    }
    else {
        _9373 = NewDouble(DBL_PTR(_i_16462)->dbl - (eudouble)1);
    }
    if (IS_ATOM_INT(_9373)) {
        if (_9373 == (short)_9373){
            _9374 = _9373 * 8;
        }
        else{
            _9374 = NewDouble(_9373 * (eudouble)8);
        }
    }
    else {
        _9374 = NewDouble(DBL_PTR(_9373)->dbl * (eudouble)8);
    }
    DeRef(_9373);
    _9373 = NOVALUE;
    if (IS_ATOM_INT(_free_list_16465) && IS_ATOM_INT(_9374)) {
        _9375 = _free_list_16465 + _9374;
        if ((object)((uintptr_t)_9375 + (uintptr_t)HIGH_BITS) >= 0){
            _9375 = NewDouble((eudouble)_9375);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_16465)) {
            _9375 = NewDouble((eudouble)_free_list_16465 + DBL_PTR(_9374)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9374)) {
                _9375 = NewDouble(DBL_PTR(_free_list_16465)->dbl + (eudouble)_9374);
            }
            else
            _9375 = NewDouble(DBL_PTR(_free_list_16465)->dbl + DBL_PTR(_9374)->dbl);
        }
    }
    DeRef(_9374);
    _9374 = NOVALUE;
    DeRef(_pos_inlined_seek_at_940_16624);
    _pos_inlined_seek_at_940_16624 = _9375;
    _9375 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_940_16624);
    DeRef(_seek_1__tmp_at943_16626);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_940_16624;
    _seek_1__tmp_at943_16626 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_943_16625 = machine(19, _seek_1__tmp_at943_16626);
    DeRef(_pos_inlined_seek_at_940_16624);
    _pos_inlined_seek_at_940_16624 = NOVALUE;
    DeRef(_seek_1__tmp_at943_16626);
    _seek_1__tmp_at943_16626 = NOVALUE;

    /** eds.e:914			put4(p)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_p_16460)) {
        *poke4_addr = (uint32_t)_p_16460;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_p_16460)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at958_16628);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at958_16628 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at958_16628); // DJP 

    /** eds.e:444	end procedure*/
    goto L14; // [980] 983
L14: 
    DeRefi(_put4_1__tmp_at958_16628);
    _put4_1__tmp_at958_16628 = NOVALUE;

    /** eds.e:915			put4(psize)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_psize_16461)) {
        *poke4_addr = (uint32_t)_psize_16461;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_psize_16461)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at986_16630);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at986_16630 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at986_16630); // DJP 

    /** eds.e:444	end procedure*/
    goto L15; // [1008] 1011
L15: 
    DeRefi(_put4_1__tmp_at986_16630);
    _put4_1__tmp_at986_16630 = NOVALUE;

    /** eds.e:916			putn(remaining)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_15734, _remaining_16472); // DJP 

    /** eds.e:449	end procedure*/
    goto L16; // [1024] 1027
L16: 
LE: 

    /** eds.e:919		if new_space then*/
    if (_new_space_16467 == 0) {
        goto L17; // [1032] 1043
    }
    else {
        if (!IS_ATOM_INT(_new_space_16467) && DBL_PTR(_new_space_16467)->dbl == 0.0){
            goto L17; // [1032] 1043
        }
    }

    /** eds.e:920			db_free(to_be_freed) -- free the old space*/
    Ref(_to_be_freed_16468);
    _41db_free(_to_be_freed_16468);
L17: 

    /** eds.e:922	end procedure*/
    DeRef(_p_16460);
    DeRef(_psize_16461);
    DeRef(_i_16462);
    DeRef(_size_16463);
    DeRef(_addr_16464);
    DeRef(_free_list_16465);
    DeRef(_free_list_space_16466);
    DeRef(_new_space_16467);
    DeRef(_to_be_freed_16468);
    DeRef(_prev_addr_16469);
    DeRef(_prev_size_16470);
    DeRef(_remaining_16472);
    DeRef(_9341);
    _9341 = NOVALUE;
    DeRef(_9357);
    _9357 = NOVALUE;
    DeRef(_9333);
    _9333 = NOVALUE;
    return;
    ;
}


void _41save_keys()
{
    object _k_16635 = NOVALUE;
    object _9382 = NOVALUE;
    object _9378 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:926		if caching_option = 1 then*/

    /** eds.e:927			if current_table_pos > 0 then*/
    if (binary_op_a(LESSEQ, _41current_table_pos_15735, 0)){
        goto L1; // [13] 81
    }

    /** eds.e:928				k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_41current_table_pos_15735);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _41current_table_pos_15735;
    _9378 = MAKE_SEQ(_1);
    _k_16635 = find_from(_9378, _41cache_index_15743, 1);
    DeRefDS(_9378);
    _9378 = NOVALUE;

    /** eds.e:929				if k != 0 then*/
    if (_k_16635 == 0)
    goto L2; // [36] 53

    /** eds.e:930					key_cache[k] = key_pointers*/
    RefDS(_41key_pointers_15741);
    _2 = (object)SEQ_PTR(_41key_cache_15742);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _41key_cache_15742 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _k_16635);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _41key_pointers_15741;
    DeRef(_1);
    goto L3; // [50] 80
L2: 

    /** eds.e:932					key_cache = append(key_cache, key_pointers)*/
    RefDS(_41key_pointers_15741);
    Append(&_41key_cache_15742, _41key_cache_15742, _41key_pointers_15741);

    /** eds.e:933					cache_index = append(cache_index, {current_db, current_table_pos})*/
    Ref(_41current_table_pos_15735);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _41current_table_pos_15735;
    _9382 = MAKE_SEQ(_1);
    RefDS(_9382);
    Append(&_41cache_index_15743, _41cache_index_15743, _9382);
    DeRefDS(_9382);
    _9382 = NOVALUE;
L3: 
L1: 

    /** eds.e:937	end procedure*/
    return;
    ;
}


object _41db_create(object _path_16732, object _lock_method_16733, object _init_tables_16734, object _init_free_16735)
{
    object _db_16736 = NOVALUE;
    object _lock_file_1__tmp_at222_16775 = NOVALUE;
    object _lock_file_inlined_lock_file_at_222_16774 = NOVALUE;
    object _put4_1__tmp_at342_16784 = NOVALUE;
    object _put4_1__tmp_at370_16786 = NOVALUE;
    object _put4_1__tmp_at413_16792 = NOVALUE;
    object _x_inlined_put4_at_410_16791 = NOVALUE;
    object _put4_1__tmp_at452_16797 = NOVALUE;
    object _x_inlined_put4_at_449_16796 = NOVALUE;
    object _put4_1__tmp_at480_16799 = NOVALUE;
    object _s_inlined_putn_at_516_16803 = NOVALUE;
    object _put4_1__tmp_at548_16808 = NOVALUE;
    object _x_inlined_put4_at_545_16807 = NOVALUE;
    object _s_inlined_putn_at_584_16812 = NOVALUE;
    object _9480 = NOVALUE;
    object _9479 = NOVALUE;
    object _9478 = NOVALUE;
    object _9477 = NOVALUE;
    object _9476 = NOVALUE;
    object _9475 = NOVALUE;
    object _9474 = NOVALUE;
    object _9473 = NOVALUE;
    object _9472 = NOVALUE;
    object _9471 = NOVALUE;
    object _9470 = NOVALUE;
    object _9453 = NOVALUE;
    object _9451 = NOVALUE;
    object _9450 = NOVALUE;
    object _9448 = NOVALUE;
    object _9447 = NOVALUE;
    object _9445 = NOVALUE;
    object _9444 = NOVALUE;
    object _9442 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1133		db = find(path, Known_Aliases)*/
    _db_16736 = find_from(_path_16732, _41Known_Aliases_15755, 1);

    /** eds.e:1134		if db then*/
    if (_db_16736 == 0)
    {
        goto L1; // [20] 94
    }
    else{
    }

    /** eds.e:1136			path = Alias_Details[db][1]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_15756);
    _9442 = (object)*(((s1_ptr)_2)->base + _db_16736);
    DeRefDS(_path_16732);
    _2 = (object)SEQ_PTR(_9442);
    _path_16732 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_path_16732);
    _9442 = NOVALUE;

    /** eds.e:1137			lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_15756);
    _9444 = (object)*(((s1_ptr)_2)->base + _db_16736);
    _2 = (object)SEQ_PTR(_9444);
    _9445 = (object)*(((s1_ptr)_2)->base + 2);
    _9444 = NOVALUE;
    _2 = (object)SEQ_PTR(_9445);
    _lock_method_16733 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_16733)){
        _lock_method_16733 = (object)DBL_PTR(_lock_method_16733)->dbl;
    }
    _9445 = NOVALUE;

    /** eds.e:1138			init_tables = Alias_Details[db][2][CONNECT_TABLES]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_15756);
    _9447 = (object)*(((s1_ptr)_2)->base + _db_16736);
    _2 = (object)SEQ_PTR(_9447);
    _9448 = (object)*(((s1_ptr)_2)->base + 2);
    _9447 = NOVALUE;
    _2 = (object)SEQ_PTR(_9448);
    _init_tables_16734 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_init_tables_16734)){
        _init_tables_16734 = (object)DBL_PTR(_init_tables_16734)->dbl;
    }
    _9448 = NOVALUE;

    /** eds.e:1139			init_free = Alias_Details[db][2][CONNECT_FREE]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_15756);
    _9450 = (object)*(((s1_ptr)_2)->base + _db_16736);
    _2 = (object)SEQ_PTR(_9450);
    _9451 = (object)*(((s1_ptr)_2)->base + 2);
    _9450 = NOVALUE;
    _2 = (object)SEQ_PTR(_9451);
    _init_free_16735 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_init_free_16735)){
        _init_free_16735 = (object)DBL_PTR(_init_free_16735)->dbl;
    }
    _9451 = NOVALUE;
    goto L2; // [91] 134
L1: 

    /** eds.e:1141			path = filesys:canonical_path( defaultext(path, "edb") )*/
    RefDS(_path_16732);
    RefDS(_9436);
    _9453 = _14defaultext(_path_16732, _9436);
    _0 = _path_16732;
    _path_16732 = _14canonical_path(_9453, 0, 0);
    DeRefDS(_0);
    _9453 = NOVALUE;

    /** eds.e:1143			if init_tables < 1 then*/
    if (_init_tables_16734 >= 1)
    goto L3; // [111] 121

    /** eds.e:1144				init_tables = 1*/
    _init_tables_16734 = 1;
L3: 

    /** eds.e:1147			if init_free < 0 then*/
    if (_init_free_16735 >= 0)
    goto L4; // [123] 133

    /** eds.e:1148				init_free = 0*/
    _init_free_16735 = 0;
L4: 
L2: 

    /** eds.e:1154		db = open(path, "rb")*/
    _db_16736 = EOpen(_path_16732, _8733, 0);

    /** eds.e:1155		if db != -1 then*/
    if (_db_16736 == -1)
    goto L5; // [143] 158

    /** eds.e:1157			close(db)*/
    EClose(_db_16736);

    /** eds.e:1158			return DB_EXISTS_ALREADY*/
    DeRefDS(_path_16732);
    return -2;
L5: 

    /** eds.e:1162		db = open(path, "wb")*/
    _db_16736 = EOpen(_path_16732, _8862, 0);

    /** eds.e:1163		if db = -1 then*/
    if (_db_16736 != -1)
    goto L6; // [167] 178

    /** eds.e:1164			return DB_OPEN_FAIL*/
    DeRefDS(_path_16732);
    return -1;
L6: 

    /** eds.e:1166		close(db)*/
    EClose(_db_16736);

    /** eds.e:1169		db = open(path, "ub")*/
    _db_16736 = EOpen(_path_16732, _9461, 0);

    /** eds.e:1170		if db = -1 then*/
    if (_db_16736 != -1)
    goto L7; // [191] 202

    /** eds.e:1171			return DB_OPEN_FAIL*/
    DeRefDS(_path_16732);
    return -1;
L7: 

    /** eds.e:1173		if lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_16733 != 1)
    goto L8; // [204] 214

    /** eds.e:1175			lock_method = DB_LOCK_NO*/
    _lock_method_16733 = 0;
L8: 

    /** eds.e:1177		if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_16733 != 2)
    goto L9; // [216] 248

    /** eds.e:1178			if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** io.e:1055		return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at222_16775;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _db_16736;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    _lock_file_1__tmp_at222_16775 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_222_16774 = machine(61, _lock_file_1__tmp_at222_16775);
    DeRef(_lock_file_1__tmp_at222_16775);
    _lock_file_1__tmp_at222_16775 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_222_16774 != 0)
    goto LA; // [237] 247

    /** eds.e:1179				return DB_LOCK_FAIL*/
    DeRefDS(_path_16732);
    return -3;
LA: 
L9: 

    /** eds.e:1182		save_keys()*/
    _41save_keys();

    /** eds.e:1183		current_db = db*/
    _41current_db_15734 = _db_16736;

    /** eds.e:1184		current_lock = lock_method*/
    _41current_lock_15740 = _lock_method_16733;

    /** eds.e:1185		current_table_pos = -1*/
    DeRef(_41current_table_pos_15735);
    _41current_table_pos_15735 = -1;

    /** eds.e:1186		current_table_name = ""*/
    RefDS(_5);
    DeRef(_41current_table_name_15736);
    _41current_table_name_15736 = _5;

    /** eds.e:1187		db_names = append(db_names, path)*/
    RefDS(_path_16732);
    Append(&_41db_names_15737, _41db_names_15737, _path_16732);

    /** eds.e:1188		db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_41db_lock_methods_15739, _41db_lock_methods_15739, _lock_method_16733);

    /** eds.e:1189		db_file_nums = append(db_file_nums, db)*/
    Append(&_41db_file_nums_15738, _41db_file_nums_15738, _db_16736);

    /** eds.e:1192		put1(DB_MAGIC) -- so we know what type of file it is*/

    /** eds.e:433		puts(current_db, x)*/
    EPuts(_41current_db_15734, 77); // DJP 

    /** eds.e:434	end procedure*/
    goto LB; // [309] 312
LB: 

    /** eds.e:1193		put1(DB_MAJOR) -- major version*/

    /** eds.e:433		puts(current_db, x)*/
    EPuts(_41current_db_15734, 4); // DJP 

    /** eds.e:434	end procedure*/
    goto LC; // [323] 326
LC: 

    /** eds.e:1194		put1(DB_MINOR) -- minor version*/

    /** eds.e:433		puts(current_db, x)*/
    EPuts(_41current_db_15734, 0); // DJP 

    /** eds.e:434	end procedure*/
    goto LD; // [337] 340
LD: 

    /** eds.e:1196		put4(19)  -- pointer to tables*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    *poke4_addr = (uint32_t)19;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at342_16784);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at342_16784 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at342_16784); // DJP 

    /** eds.e:444	end procedure*/
    goto LE; // [363] 366
LE: 
    DeRefi(_put4_1__tmp_at342_16784);
    _put4_1__tmp_at342_16784 = NOVALUE;

    /** eds.e:1198		put4(0)   -- number of free blocks*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    *poke4_addr = (uint32_t)0;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at370_16786);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at370_16786 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at370_16786); // DJP 

    /** eds.e:444	end procedure*/
    goto LF; // [391] 394
LF: 
    DeRefi(_put4_1__tmp_at370_16786);
    _put4_1__tmp_at370_16786 = NOVALUE;

    /** eds.e:1200		put4(23 + init_tables * SIZEOF_TABLE_HEADER + 4)   -- pointer to free list*/
    if (_init_tables_16734 == (short)_init_tables_16734){
        _9470 = _init_tables_16734 * 16;
    }
    else{
        _9470 = NewDouble(_init_tables_16734 * (eudouble)16);
    }
    if (IS_ATOM_INT(_9470)) {
        _9471 = 23 + _9470;
        if ((object)((uintptr_t)_9471 + (uintptr_t)HIGH_BITS) >= 0){
            _9471 = NewDouble((eudouble)_9471);
        }
    }
    else {
        _9471 = NewDouble((eudouble)23 + DBL_PTR(_9470)->dbl);
    }
    DeRef(_9470);
    _9470 = NOVALUE;
    if (IS_ATOM_INT(_9471)) {
        _9472 = _9471 + 4;
        if ((object)((uintptr_t)_9472 + (uintptr_t)HIGH_BITS) >= 0){
            _9472 = NewDouble((eudouble)_9472);
        }
    }
    else {
        _9472 = NewDouble(DBL_PTR(_9471)->dbl + (eudouble)4);
    }
    DeRef(_9471);
    _9471 = NOVALUE;
    DeRef(_x_inlined_put4_at_410_16791);
    _x_inlined_put4_at_410_16791 = _9472;
    _9472 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_410_16791)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_410_16791;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_410_16791)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at413_16792);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at413_16792 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at413_16792); // DJP 

    /** eds.e:444	end procedure*/
    goto L10; // [434] 437
L10: 
    DeRef(_x_inlined_put4_at_410_16791);
    _x_inlined_put4_at_410_16791 = NOVALUE;
    DeRefi(_put4_1__tmp_at413_16792);
    _put4_1__tmp_at413_16792 = NOVALUE;

    /** eds.e:1202		put4( 8 + init_tables * SIZEOF_TABLE_HEADER)  -- allocated size*/
    if (_init_tables_16734 == (short)_init_tables_16734){
        _9473 = _init_tables_16734 * 16;
    }
    else{
        _9473 = NewDouble(_init_tables_16734 * (eudouble)16);
    }
    if (IS_ATOM_INT(_9473)) {
        _9474 = 8 + _9473;
        if ((object)((uintptr_t)_9474 + (uintptr_t)HIGH_BITS) >= 0){
            _9474 = NewDouble((eudouble)_9474);
        }
    }
    else {
        _9474 = NewDouble((eudouble)8 + DBL_PTR(_9473)->dbl);
    }
    DeRef(_9473);
    _9473 = NOVALUE;
    DeRef(_x_inlined_put4_at_449_16796);
    _x_inlined_put4_at_449_16796 = _9474;
    _9474 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_449_16796)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_449_16796;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_449_16796)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at452_16797);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at452_16797 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at452_16797); // DJP 

    /** eds.e:444	end procedure*/
    goto L11; // [473] 476
L11: 
    DeRef(_x_inlined_put4_at_449_16796);
    _x_inlined_put4_at_449_16796 = NOVALUE;
    DeRefi(_put4_1__tmp_at452_16797);
    _put4_1__tmp_at452_16797 = NOVALUE;

    /** eds.e:1204		put4(0)   -- number of tables that currently exist*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    *poke4_addr = (uint32_t)0;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at480_16799);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at480_16799 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at480_16799); // DJP 

    /** eds.e:444	end procedure*/
    goto L12; // [501] 504
L12: 
    DeRefi(_put4_1__tmp_at480_16799);
    _put4_1__tmp_at480_16799 = NOVALUE;

    /** eds.e:1206		putn(repeat(0, init_tables * SIZEOF_TABLE_HEADER))*/
    _9475 = _init_tables_16734 * 16;
    _9476 = Repeat(0, _9475);
    _9475 = NOVALUE;
    DeRefi(_s_inlined_putn_at_516_16803);
    _s_inlined_putn_at_516_16803 = _9476;
    _9476 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_15734, _s_inlined_putn_at_516_16803); // DJP 

    /** eds.e:449	end procedure*/
    goto L13; // [530] 533
L13: 
    DeRefi(_s_inlined_putn_at_516_16803);
    _s_inlined_putn_at_516_16803 = NOVALUE;

    /** eds.e:1208		put4(4+init_free*8)   -- allocated size*/
    if (_init_free_16735 == (short)_init_free_16735){
        _9477 = _init_free_16735 * 8;
    }
    else{
        _9477 = NewDouble(_init_free_16735 * (eudouble)8);
    }
    if (IS_ATOM_INT(_9477)) {
        _9478 = 4 + _9477;
        if ((object)((uintptr_t)_9478 + (uintptr_t)HIGH_BITS) >= 0){
            _9478 = NewDouble((eudouble)_9478);
        }
    }
    else {
        _9478 = NewDouble((eudouble)4 + DBL_PTR(_9477)->dbl);
    }
    DeRef(_9477);
    _9477 = NOVALUE;
    DeRef(_x_inlined_put4_at_545_16807);
    _x_inlined_put4_at_545_16807 = _9478;
    _9478 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_545_16807)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_545_16807;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_545_16807)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at548_16808);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at548_16808 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at548_16808); // DJP 

    /** eds.e:444	end procedure*/
    goto L14; // [569] 572
L14: 
    DeRef(_x_inlined_put4_at_545_16807);
    _x_inlined_put4_at_545_16807 = NOVALUE;
    DeRefi(_put4_1__tmp_at548_16808);
    _put4_1__tmp_at548_16808 = NOVALUE;

    /** eds.e:1209		putn(repeat(0, init_free * 8))*/
    _9479 = _init_free_16735 * 8;
    _9480 = Repeat(0, _9479);
    _9479 = NOVALUE;
    DeRefi(_s_inlined_putn_at_584_16812);
    _s_inlined_putn_at_584_16812 = _9480;
    _9480 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_15734, _s_inlined_putn_at_584_16812); // DJP 

    /** eds.e:449	end procedure*/
    goto L15; // [598] 601
L15: 
    DeRefi(_s_inlined_putn_at_584_16812);
    _s_inlined_putn_at_584_16812 = NOVALUE;

    /** eds.e:1210		return DB_OK*/
    DeRefDS(_path_16732);
    return 0;
    ;
}


object _41db_open(object _path_16815, object _lock_method_16816)
{
    object _db_16817 = NOVALUE;
    object _magic_16818 = NOVALUE;
    object _lock_file_1__tmp_at129_16843 = NOVALUE;
    object _lock_file_inlined_lock_file_at_129_16842 = NOVALUE;
    object _lock_file_1__tmp_at169_16850 = NOVALUE;
    object _lock_file_inlined_lock_file_at_169_16849 = NOVALUE;
    object _9491 = NOVALUE;
    object _9489 = NOVALUE;
    object _9487 = NOVALUE;
    object _9485 = NOVALUE;
    object _9484 = NOVALUE;
    object _9482 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1273		db = find(path, Known_Aliases)*/
    _db_16817 = find_from(_path_16815, _41Known_Aliases_15755, 1);

    /** eds.e:1274		if db then*/
    if (_db_16817 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** eds.e:1276			path = Alias_Details[db][1]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_15756);
    _9482 = (object)*(((s1_ptr)_2)->base + _db_16817);
    DeRefDS(_path_16815);
    _2 = (object)SEQ_PTR(_9482);
    _path_16815 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_path_16815);
    _9482 = NOVALUE;

    /** eds.e:1277			lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_15756);
    _9484 = (object)*(((s1_ptr)_2)->base + _db_16817);
    _2 = (object)SEQ_PTR(_9484);
    _9485 = (object)*(((s1_ptr)_2)->base + 2);
    _9484 = NOVALUE;
    _2 = (object)SEQ_PTR(_9485);
    _lock_method_16816 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_16816)){
        _lock_method_16816 = (object)DBL_PTR(_lock_method_16816)->dbl;
    }
    _9485 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** eds.e:1279			path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_16815);
    RefDS(_9436);
    _9487 = _14defaultext(_path_16815, _9436);
    _0 = _path_16815;
    _path_16815 = _14canonical_path(_9487, 0, 0);
    DeRefDS(_0);
    _9487 = NOVALUE;
L2: 

    /** eds.e:1282		if lock_method = DB_LOCK_NO or*/
    _9489 = (_lock_method_16816 == 0);
    if (_9489 != 0) {
        goto L3; // [76] 89
    }
    _9491 = (_lock_method_16816 == 2);
    if (_9491 == 0)
    {
        DeRef(_9491);
        _9491 = NOVALUE;
        goto L4; // [85] 99
    }
    else{
        DeRef(_9491);
        _9491 = NOVALUE;
    }
L3: 

    /** eds.e:1285			db = open(path, "ub")*/
    _db_16817 = EOpen(_path_16815, _9461, 0);
    goto L5; // [96] 107
L4: 

    /** eds.e:1288			db = open(path, "rb")*/
    _db_16817 = EOpen(_path_16815, _8733, 0);
L5: 

    /** eds.e:1291	ifdef WINDOWS then*/

    /** eds.e:1298		if db = -1 then*/
    if (_db_16817 != -1)
    goto L6; // [111] 122

    /** eds.e:1299			return DB_OPEN_FAIL*/
    DeRefDS(_path_16815);
    DeRef(_9489);
    _9489 = NOVALUE;
    return -1;
L6: 

    /** eds.e:1301		if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_16816 != 2)
    goto L7; // [124] 162

    /** eds.e:1302			if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** io.e:1055		return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at129_16843;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _db_16817;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    _lock_file_1__tmp_at129_16843 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_129_16842 = machine(61, _lock_file_1__tmp_at129_16843);
    DeRef(_lock_file_1__tmp_at129_16843);
    _lock_file_1__tmp_at129_16843 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_129_16842 != 0)
    goto L8; // [145] 201

    /** eds.e:1303				close(db)*/
    EClose(_db_16817);

    /** eds.e:1304				return DB_LOCK_FAIL*/
    DeRefDS(_path_16815);
    DeRef(_9489);
    _9489 = NOVALUE;
    return -3;
    goto L8; // [159] 201
L7: 

    /** eds.e:1306		elsif lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_16816 != 1)
    goto L9; // [164] 200

    /** eds.e:1307			if not io:lock_file(db, io:LOCK_SHARED, {}) then*/

    /** io.e:1055		return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at169_16850;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _db_16817;
    ((intptr_t*)_2)[2] = 1;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    _lock_file_1__tmp_at169_16850 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_169_16849 = machine(61, _lock_file_1__tmp_at169_16850);
    DeRef(_lock_file_1__tmp_at169_16850);
    _lock_file_1__tmp_at169_16850 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_169_16849 != 0)
    goto LA; // [185] 199

    /** eds.e:1308				close(db)*/
    EClose(_db_16817);

    /** eds.e:1309				return DB_LOCK_FAIL*/
    DeRefDS(_path_16815);
    DeRef(_9489);
    _9489 = NOVALUE;
    return -3;
LA: 
L9: 
L8: 

    /** eds.e:1312		magic = getc(db)*/
    if (_db_16817 != last_r_file_no) {
        last_r_file_ptr = which_file(_db_16817, EF_READ);
        last_r_file_no = _db_16817;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _magic_16818 = getc((FILE*)xstdin);
        }
        else{
            _magic_16818 = getc(last_r_file_ptr);
        }
    }
    else{
        _magic_16818 = getc(last_r_file_ptr);
    }

    /** eds.e:1313		if magic != DB_MAGIC then*/
    if (_magic_16818 == 77)
    goto LB; // [208] 223

    /** eds.e:1314			close(db)*/
    EClose(_db_16817);

    /** eds.e:1315			return DB_OPEN_FAIL*/
    DeRefDS(_path_16815);
    DeRef(_9489);
    _9489 = NOVALUE;
    return -1;
LB: 

    /** eds.e:1317		save_keys()*/
    _41save_keys();

    /** eds.e:1318		current_db = db */
    _41current_db_15734 = _db_16817;

    /** eds.e:1319		current_table_pos = -1*/
    DeRef(_41current_table_pos_15735);
    _41current_table_pos_15735 = -1;

    /** eds.e:1320		current_table_name = ""*/
    RefDS(_5);
    DeRef(_41current_table_name_15736);
    _41current_table_name_15736 = _5;

    /** eds.e:1321		current_lock = lock_method*/
    _41current_lock_15740 = _lock_method_16816;

    /** eds.e:1322		db_names = append(db_names, path)*/
    RefDS(_path_16815);
    Append(&_41db_names_15737, _41db_names_15737, _path_16815);

    /** eds.e:1323		db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_41db_lock_methods_15739, _41db_lock_methods_15739, _lock_method_16816);

    /** eds.e:1324		db_file_nums = append(db_file_nums, db)*/
    Append(&_41db_file_nums_15738, _41db_file_nums_15738, _db_16817);

    /** eds.e:1325		return DB_OK*/
    DeRefDS(_path_16815);
    DeRef(_9489);
    _9489 = NOVALUE;
    return 0;
    ;
}


object _41db_select(object _path_16860, object _lock_method_16861)
{
    object _index_16862 = NOVALUE;
    object _9510 = NOVALUE;
    object _9508 = NOVALUE;
    object _9507 = NOVALUE;
    object _9505 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1372		index = find(path, Known_Aliases)*/
    _index_16862 = find_from(_path_16860, _41Known_Aliases_15755, 1);

    /** eds.e:1373		if index then*/
    if (_index_16862 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** eds.e:1375			path = Alias_Details[index][1]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_15756);
    _9505 = (object)*(((s1_ptr)_2)->base + _index_16862);
    DeRefDS(_path_16860);
    _2 = (object)SEQ_PTR(_9505);
    _path_16860 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_path_16860);
    _9505 = NOVALUE;

    /** eds.e:1376			lock_method = Alias_Details[index][2][CONNECT_LOCK]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_15756);
    _9507 = (object)*(((s1_ptr)_2)->base + _index_16862);
    _2 = (object)SEQ_PTR(_9507);
    _9508 = (object)*(((s1_ptr)_2)->base + 2);
    _9507 = NOVALUE;
    _2 = (object)SEQ_PTR(_9508);
    _lock_method_16861 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_16861)){
        _lock_method_16861 = (object)DBL_PTR(_lock_method_16861)->dbl;
    }
    _9508 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** eds.e:1378			path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_16860);
    RefDS(_9436);
    _9510 = _14defaultext(_path_16860, _9436);
    _0 = _path_16860;
    _path_16860 = _14canonical_path(_9510, 0, 0);
    DeRefDS(_0);
    _9510 = NOVALUE;
L2: 

    /** eds.e:1381		index = eu:find(path, db_names)*/
    _index_16862 = find_from(_path_16860, _41db_names_15737, 1);

    /** eds.e:1382		if index = 0 then*/
    if (_index_16862 != 0)
    goto L3; // [81] 130

    /** eds.e:1383			if lock_method = -1 then*/
    if (_lock_method_16861 != -1)
    goto L4; // [87] 98

    /** eds.e:1384				return DB_OPEN_FAIL*/
    DeRefDS(_path_16860);
    return -1;
L4: 

    /** eds.e:1386			index = db_open(path, lock_method)*/
    RefDS(_path_16860);
    _index_16862 = _41db_open(_path_16860, _lock_method_16861);
    if (!IS_ATOM_INT(_index_16862)) {
        _1 = (object)(DBL_PTR(_index_16862)->dbl);
        DeRefDS(_index_16862);
        _index_16862 = _1;
    }

    /** eds.e:1387			if index != DB_OK then*/
    if (_index_16862 == 0)
    goto L5; // [109] 120

    /** eds.e:1388				return index*/
    DeRefDS(_path_16860);
    return _index_16862;
L5: 

    /** eds.e:1390			index = eu:find(path, db_names)*/
    _index_16862 = find_from(_path_16860, _41db_names_15737, 1);
L3: 

    /** eds.e:1392		save_keys()*/
    _41save_keys();

    /** eds.e:1393		current_db = db_file_nums[index]*/
    _2 = (object)SEQ_PTR(_41db_file_nums_15738);
    _41current_db_15734 = (object)*(((s1_ptr)_2)->base + _index_16862);
    if (!IS_ATOM_INT(_41current_db_15734))
    _41current_db_15734 = (object)DBL_PTR(_41current_db_15734)->dbl;

    /** eds.e:1394		current_lock = db_lock_methods[index]*/
    _2 = (object)SEQ_PTR(_41db_lock_methods_15739);
    _41current_lock_15740 = (object)*(((s1_ptr)_2)->base + _index_16862);
    if (!IS_ATOM_INT(_41current_lock_15740))
    _41current_lock_15740 = (object)DBL_PTR(_41current_lock_15740)->dbl;

    /** eds.e:1395		current_table_pos = -1*/
    DeRef(_41current_table_pos_15735);
    _41current_table_pos_15735 = -1;

    /** eds.e:1396		current_table_name = ""*/
    RefDS(_5);
    DeRef(_41current_table_name_15736);
    _41current_table_name_15736 = _5;

    /** eds.e:1397		key_pointers = {}*/
    RefDS(_5);
    DeRef(_41key_pointers_15741);
    _41key_pointers_15741 = _5;

    /** eds.e:1398		return DB_OK*/
    DeRefDS(_path_16860);
    return 0;
    ;
}


void _41db_close()
{
    object _unlock_file_1__tmp_at25_16891 = NOVALUE;
    object _index_16886 = NOVALUE;
    object _9527 = NOVALUE;
    object _9526 = NOVALUE;
    object _9525 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1413		if current_db = -1 then*/
    if (_41current_db_15734 != -1)
    goto L1; // [5] 15

    /** eds.e:1414			return*/
    return;
L1: 

    /** eds.e:1417		if current_lock then*/
    if (_41current_lock_15740 == 0)
    {
        goto L2; // [19] 43
    }
    else{
    }

    /** eds.e:1418			io:unlock_file(current_db, {})*/

    /** io.e:1086		machine_proc(M_UNLOCK_FILE, {fn, r})*/
    RefDS(_5);
    DeRef(_unlock_file_1__tmp_at25_16891);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _5;
    _unlock_file_1__tmp_at25_16891 = MAKE_SEQ(_1);
    machine(62, _unlock_file_1__tmp_at25_16891);

    /** io.e:1087	end procedure*/
    goto L3; // [37] 40
L3: 
    DeRef(_unlock_file_1__tmp_at25_16891);
    _unlock_file_1__tmp_at25_16891 = NOVALUE;
L2: 

    /** eds.e:1420		close(current_db)*/
    EClose(_41current_db_15734);

    /** eds.e:1422		index = eu:find(current_db, db_file_nums)*/
    _index_16886 = find_from(_41current_db_15734, _41db_file_nums_15738, 1);

    /** eds.e:1423		db_names = remove(db_names, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_41db_names_15737);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_16886)) ? _index_16886 : (object)(DBL_PTR(_index_16886)->dbl);
        int stop = (IS_ATOM_INT(_index_16886)) ? _index_16886 : (object)(DBL_PTR(_index_16886)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_41db_names_15737), start, &_41db_names_15737 );
            }
            else Tail(SEQ_PTR(_41db_names_15737), stop+1, &_41db_names_15737);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_41db_names_15737), start, &_41db_names_15737);
        }
        else {
            assign_slice_seq = &assign_space;
            _41db_names_15737 = Remove_elements(start, stop, (SEQ_PTR(_41db_names_15737)->ref == 1));
        }
    }

    /** eds.e:1424		db_file_nums = remove(db_file_nums, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_41db_file_nums_15738);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_16886)) ? _index_16886 : (object)(DBL_PTR(_index_16886)->dbl);
        int stop = (IS_ATOM_INT(_index_16886)) ? _index_16886 : (object)(DBL_PTR(_index_16886)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_41db_file_nums_15738), start, &_41db_file_nums_15738 );
            }
            else Tail(SEQ_PTR(_41db_file_nums_15738), stop+1, &_41db_file_nums_15738);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_41db_file_nums_15738), start, &_41db_file_nums_15738);
        }
        else {
            assign_slice_seq = &assign_space;
            _41db_file_nums_15738 = Remove_elements(start, stop, (SEQ_PTR(_41db_file_nums_15738)->ref == 1));
        }
    }

    /** eds.e:1425		db_lock_methods = remove(db_lock_methods, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_41db_lock_methods_15739);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_16886)) ? _index_16886 : (object)(DBL_PTR(_index_16886)->dbl);
        int stop = (IS_ATOM_INT(_index_16886)) ? _index_16886 : (object)(DBL_PTR(_index_16886)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_41db_lock_methods_15739), start, &_41db_lock_methods_15739 );
            }
            else Tail(SEQ_PTR(_41db_lock_methods_15739), stop+1, &_41db_lock_methods_15739);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_41db_lock_methods_15739), start, &_41db_lock_methods_15739);
        }
        else {
            assign_slice_seq = &assign_space;
            _41db_lock_methods_15739 = Remove_elements(start, stop, (SEQ_PTR(_41db_lock_methods_15739)->ref == 1));
        }
    }

    /** eds.e:1427		for i = length(cache_index) to 1 by -1 do*/
    if (IS_SEQUENCE(_41cache_index_15743)){
            _9525 = SEQ_PTR(_41cache_index_15743)->length;
    }
    else {
        _9525 = 1;
    }
    {
        object _i_16897;
        _i_16897 = _9525;
L4: 
        if (_i_16897 < 1){
            goto L5; // [94] 145
        }

        /** eds.e:1428			if cache_index[i][1] = current_db then*/
        _2 = (object)SEQ_PTR(_41cache_index_15743);
        _9526 = (object)*(((s1_ptr)_2)->base + _i_16897);
        _2 = (object)SEQ_PTR(_9526);
        _9527 = (object)*(((s1_ptr)_2)->base + 1);
        _9526 = NOVALUE;
        if (binary_op_a(NOTEQ, _9527, _41current_db_15734)){
            _9527 = NOVALUE;
            goto L6; // [115] 138
        }
        _9527 = NOVALUE;

        /** eds.e:1429				cache_index = remove(cache_index, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_41cache_index_15743);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_16897)) ? _i_16897 : (object)(DBL_PTR(_i_16897)->dbl);
            int stop = (IS_ATOM_INT(_i_16897)) ? _i_16897 : (object)(DBL_PTR(_i_16897)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_41cache_index_15743), start, &_41cache_index_15743 );
                }
                else Tail(SEQ_PTR(_41cache_index_15743), stop+1, &_41cache_index_15743);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_41cache_index_15743), start, &_41cache_index_15743);
            }
            else {
                assign_slice_seq = &assign_space;
                _41cache_index_15743 = Remove_elements(start, stop, (SEQ_PTR(_41cache_index_15743)->ref == 1));
            }
        }

        /** eds.e:1430				key_cache = remove(key_cache, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_41key_cache_15742);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_16897)) ? _i_16897 : (object)(DBL_PTR(_i_16897)->dbl);
            int stop = (IS_ATOM_INT(_i_16897)) ? _i_16897 : (object)(DBL_PTR(_i_16897)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_41key_cache_15742), start, &_41key_cache_15742 );
                }
                else Tail(SEQ_PTR(_41key_cache_15742), stop+1, &_41key_cache_15742);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_41key_cache_15742), start, &_41key_cache_15742);
            }
            else {
                assign_slice_seq = &assign_space;
                _41key_cache_15742 = Remove_elements(start, stop, (SEQ_PTR(_41key_cache_15742)->ref == 1));
            }
        }
L6: 

        /** eds.e:1432		end for*/
        _i_16897 = _i_16897 + -1;
        goto L4; // [140] 101
L5: 
        ;
    }

    /** eds.e:1433		current_table_pos = -1*/
    DeRef(_41current_table_pos_15735);
    _41current_table_pos_15735 = -1;

    /** eds.e:1434		current_table_name = ""	*/
    RefDS(_5);
    DeRef(_41current_table_name_15736);
    _41current_table_name_15736 = _5;

    /** eds.e:1435		current_db = -1*/
    _41current_db_15734 = -1;

    /** eds.e:1436		key_pointers = {}*/
    RefDS(_5);
    DeRef(_41key_pointers_15741);
    _41key_pointers_15741 = _5;

    /** eds.e:1437	end procedure*/
    return;
    ;
}


object _41table_find(object _name_16907)
{
    object _tables_16908 = NOVALUE;
    object _nt_16909 = NOVALUE;
    object _t_header_16910 = NOVALUE;
    object _name_ptr_16911 = NOVALUE;
    object _seek_1__tmp_at6_16914 = NOVALUE;
    object _seek_inlined_seek_at_6_16913 = NOVALUE;
    object _seek_1__tmp_at44_16921 = NOVALUE;
    object _seek_inlined_seek_at_44_16920 = NOVALUE;
    object _seek_1__tmp_at84_16929 = NOVALUE;
    object _seek_inlined_seek_at_84_16928 = NOVALUE;
    object _seek_1__tmp_at106_16933 = NOVALUE;
    object _seek_inlined_seek_at_106_16932 = NOVALUE;
    object _9538 = NOVALUE;
    object _9536 = NOVALUE;
    object _9531 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1446		io:seek(current_db, TABLE_HEADERS)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at6_16914);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = 3;
    _seek_1__tmp_at6_16914 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_6_16913 = machine(19, _seek_1__tmp_at6_16914);
    DeRefi(_seek_1__tmp_at6_16914);
    _seek_1__tmp_at6_16914 = NOVALUE;

    /** eds.e:1447		if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_41vLastErrors_15758)){
            _9531 = SEQ_PTR(_41vLastErrors_15758)->length;
    }
    else {
        _9531 = 1;
    }
    if (_9531 <= 0)
    goto L1; // [27] 36
    DeRefDS(_name_16907);
    DeRef(_tables_16908);
    DeRef(_nt_16909);
    DeRef(_t_header_16910);
    DeRef(_name_ptr_16911);
    return -1;
L1: 

    /** eds.e:1448		tables = get4()*/
    _0 = _tables_16908;
    _tables_16908 = _41get4();
    DeRef(_0);

    /** eds.e:1449		io:seek(current_db, tables)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_16908);
    DeRef(_seek_1__tmp_at44_16921);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _tables_16908;
    _seek_1__tmp_at44_16921 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_44_16920 = machine(19, _seek_1__tmp_at44_16921);
    DeRef(_seek_1__tmp_at44_16921);
    _seek_1__tmp_at44_16921 = NOVALUE;

    /** eds.e:1450		nt = get4()*/
    _0 = _nt_16909;
    _nt_16909 = _41get4();
    DeRef(_0);

    /** eds.e:1451		t_header = tables+4*/
    DeRef(_t_header_16910);
    if (IS_ATOM_INT(_tables_16908)) {
        _t_header_16910 = _tables_16908 + 4;
        if ((object)((uintptr_t)_t_header_16910 + (uintptr_t)HIGH_BITS) >= 0){
            _t_header_16910 = NewDouble((eudouble)_t_header_16910);
        }
    }
    else {
        _t_header_16910 = NewDouble(DBL_PTR(_tables_16908)->dbl + (eudouble)4);
    }

    /** eds.e:1452		for i = 1 to nt do*/
    Ref(_nt_16909);
    DeRef(_9536);
    _9536 = _nt_16909;
    {
        object _i_16925;
        _i_16925 = 1;
L2: 
        if (binary_op_a(GREATER, _i_16925, _9536)){
            goto L3; // [74] 150
        }

        /** eds.e:1453			io:seek(current_db, t_header)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_t_header_16910);
        DeRef(_seek_1__tmp_at84_16929);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_15734;
        ((intptr_t *)_2)[2] = _t_header_16910;
        _seek_1__tmp_at84_16929 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_84_16928 = machine(19, _seek_1__tmp_at84_16929);
        DeRef(_seek_1__tmp_at84_16929);
        _seek_1__tmp_at84_16929 = NOVALUE;

        /** eds.e:1454			name_ptr = get4()*/
        _0 = _name_ptr_16911;
        _name_ptr_16911 = _41get4();
        DeRef(_0);

        /** eds.e:1455			io:seek(current_db, name_ptr)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_ptr_16911);
        DeRef(_seek_1__tmp_at106_16933);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_15734;
        ((intptr_t *)_2)[2] = _name_ptr_16911;
        _seek_1__tmp_at106_16933 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_106_16932 = machine(19, _seek_1__tmp_at106_16933);
        DeRef(_seek_1__tmp_at106_16933);
        _seek_1__tmp_at106_16933 = NOVALUE;

        /** eds.e:1456			if equal_string(name) > 0 then*/
        RefDS(_name_16907);
        _9538 = _41equal_string(_name_16907);
        if (binary_op_a(LESSEQ, _9538, 0)){
            DeRef(_9538);
            _9538 = NOVALUE;
            goto L4; // [126] 137
        }
        DeRef(_9538);
        _9538 = NOVALUE;

        /** eds.e:1458				return t_header*/
        DeRef(_i_16925);
        DeRefDS(_name_16907);
        DeRef(_tables_16908);
        DeRef(_nt_16909);
        DeRef(_name_ptr_16911);
        return _t_header_16910;
L4: 

        /** eds.e:1460			t_header += SIZEOF_TABLE_HEADER*/
        _0 = _t_header_16910;
        if (IS_ATOM_INT(_t_header_16910)) {
            _t_header_16910 = _t_header_16910 + 16;
            if ((object)((uintptr_t)_t_header_16910 + (uintptr_t)HIGH_BITS) >= 0){
                _t_header_16910 = NewDouble((eudouble)_t_header_16910);
            }
        }
        else {
            _t_header_16910 = NewDouble(DBL_PTR(_t_header_16910)->dbl + (eudouble)16);
        }
        DeRef(_0);

        /** eds.e:1461		end for*/
        _0 = _i_16925;
        if (IS_ATOM_INT(_i_16925)) {
            _i_16925 = _i_16925 + 1;
            if ((object)((uintptr_t)_i_16925 +(uintptr_t) HIGH_BITS) >= 0){
                _i_16925 = NewDouble((eudouble)_i_16925);
            }
        }
        else {
            _i_16925 = binary_op_a(PLUS, _i_16925, 1);
        }
        DeRef(_0);
        goto L2; // [145] 81
L3: 
        ;
        DeRef(_i_16925);
    }

    /** eds.e:1462		return -1*/
    DeRefDS(_name_16907);
    DeRef(_tables_16908);
    DeRef(_nt_16909);
    DeRef(_t_header_16910);
    DeRef(_name_ptr_16911);
    return -1;
    ;
}


object _41db_select_table(object _name_16940)
{
    object _table_16941 = NOVALUE;
    object _nkeys_16942 = NOVALUE;
    object _index_16943 = NOVALUE;
    object _block_ptr_16944 = NOVALUE;
    object _block_size_16945 = NOVALUE;
    object _blocks_16946 = NOVALUE;
    object _k_16947 = NOVALUE;
    object _seek_1__tmp_at120_16966 = NOVALUE;
    object _seek_inlined_seek_at_120_16965 = NOVALUE;
    object _pos_inlined_seek_at_117_16964 = NOVALUE;
    object _seek_1__tmp_at178_16976 = NOVALUE;
    object _seek_inlined_seek_at_178_16975 = NOVALUE;
    object _seek_1__tmp_at205_16981 = NOVALUE;
    object _seek_inlined_seek_at_205_16980 = NOVALUE;
    object _9559 = NOVALUE;
    object _9558 = NOVALUE;
    object _9555 = NOVALUE;
    object _9550 = NOVALUE;
    object _9545 = NOVALUE;
    object _9541 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1501		if equal(current_table_name, name) then*/
    if (_41current_table_name_15736 == _name_16940)
    _9541 = 1;
    else if (IS_ATOM_INT(_41current_table_name_15736) && IS_ATOM_INT(_name_16940))
    _9541 = 0;
    else
    _9541 = (compare(_41current_table_name_15736, _name_16940) == 0);
    if (_9541 == 0)
    {
        _9541 = NOVALUE;
        goto L1; // [11] 21
    }
    else{
        _9541 = NOVALUE;
    }

    /** eds.e:1502			return DB_OK*/
    DeRefDS(_name_16940);
    DeRef(_table_16941);
    DeRef(_nkeys_16942);
    DeRef(_index_16943);
    DeRef(_block_ptr_16944);
    DeRef(_block_size_16945);
    return 0;
L1: 

    /** eds.e:1504		table = table_find(name)*/
    RefDS(_name_16940);
    _0 = _table_16941;
    _table_16941 = _41table_find(_name_16940);
    DeRef(_0);

    /** eds.e:1505		if table = -1 then*/
    if (binary_op_a(NOTEQ, _table_16941, -1)){
        goto L2; // [29] 40
    }

    /** eds.e:1506			return DB_OPEN_FAIL*/
    DeRefDS(_name_16940);
    DeRef(_table_16941);
    DeRef(_nkeys_16942);
    DeRef(_index_16943);
    DeRef(_block_ptr_16944);
    DeRef(_block_size_16945);
    return -1;
L2: 

    /** eds.e:1509		save_keys()*/
    _41save_keys();

    /** eds.e:1511		current_table_pos = table*/
    Ref(_table_16941);
    DeRef(_41current_table_pos_15735);
    _41current_table_pos_15735 = _table_16941;

    /** eds.e:1512		current_table_name = name*/
    RefDS(_name_16940);
    DeRef(_41current_table_name_15736);
    _41current_table_name_15736 = _name_16940;

    /** eds.e:1514		k = 0*/
    _k_16947 = 0;

    /** eds.e:1515		if caching_option = 1 then*/

    /** eds.e:1516			k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_41current_table_pos_15735);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _41current_table_pos_15735;
    _9545 = MAKE_SEQ(_1);
    _k_16947 = find_from(_9545, _41cache_index_15743, 1);
    DeRefDS(_9545);
    _9545 = NOVALUE;

    /** eds.e:1517			if k != 0 then*/
    if (_k_16947 == 0)
    goto L3; // [88] 103

    /** eds.e:1518				key_pointers = key_cache[k]*/
    DeRef(_41key_pointers_15741);
    _2 = (object)SEQ_PTR(_41key_cache_15742);
    _41key_pointers_15741 = (object)*(((s1_ptr)_2)->base + _k_16947);
    Ref(_41key_pointers_15741);
L3: 

    /** eds.e:1521		if k = 0 then*/
    if (_k_16947 != 0)
    goto L4; // [106] 269

    /** eds.e:1523			io:seek(current_db, table+4)*/
    if (IS_ATOM_INT(_table_16941)) {
        _9550 = _table_16941 + 4;
        if ((object)((uintptr_t)_9550 + (uintptr_t)HIGH_BITS) >= 0){
            _9550 = NewDouble((eudouble)_9550);
        }
    }
    else {
        _9550 = NewDouble(DBL_PTR(_table_16941)->dbl + (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_117_16964);
    _pos_inlined_seek_at_117_16964 = _9550;
    _9550 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_117_16964);
    DeRef(_seek_1__tmp_at120_16966);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_117_16964;
    _seek_1__tmp_at120_16966 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_120_16965 = machine(19, _seek_1__tmp_at120_16966);
    DeRef(_pos_inlined_seek_at_117_16964);
    _pos_inlined_seek_at_117_16964 = NOVALUE;
    DeRef(_seek_1__tmp_at120_16966);
    _seek_1__tmp_at120_16966 = NOVALUE;

    /** eds.e:1524			nkeys = get4()*/
    _0 = _nkeys_16942;
    _nkeys_16942 = _41get4();
    DeRef(_0);

    /** eds.e:1525			blocks = get4()*/
    _blocks_16946 = _41get4();
    if (!IS_ATOM_INT(_blocks_16946)) {
        _1 = (object)(DBL_PTR(_blocks_16946)->dbl);
        DeRefDS(_blocks_16946);
        _blocks_16946 = _1;
    }

    /** eds.e:1526			index = get4()*/
    _0 = _index_16943;
    _index_16943 = _41get4();
    DeRef(_0);

    /** eds.e:1527			key_pointers = repeat(0, nkeys)*/
    DeRef(_41key_pointers_15741);
    _41key_pointers_15741 = Repeat(0, _nkeys_16942);

    /** eds.e:1528			k = 1*/
    _k_16947 = 1;

    /** eds.e:1529			for b = 0 to blocks-1 do*/
    _9555 = _blocks_16946 - 1;
    if ((object)((uintptr_t)_9555 +(uintptr_t) HIGH_BITS) >= 0){
        _9555 = NewDouble((eudouble)_9555);
    }
    {
        object _b_16972;
        _b_16972 = 0;
L5: 
        if (binary_op_a(GREATER, _b_16972, _9555)){
            goto L6; // [168] 268
        }

        /** eds.e:1530				io:seek(current_db, index)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_index_16943);
        DeRef(_seek_1__tmp_at178_16976);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_15734;
        ((intptr_t *)_2)[2] = _index_16943;
        _seek_1__tmp_at178_16976 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_178_16975 = machine(19, _seek_1__tmp_at178_16976);
        DeRef(_seek_1__tmp_at178_16976);
        _seek_1__tmp_at178_16976 = NOVALUE;

        /** eds.e:1531				block_size = get4()*/
        _0 = _block_size_16945;
        _block_size_16945 = _41get4();
        DeRef(_0);

        /** eds.e:1532				block_ptr = get4()*/
        _0 = _block_ptr_16944;
        _block_ptr_16944 = _41get4();
        DeRef(_0);

        /** eds.e:1533				io:seek(current_db, block_ptr)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_block_ptr_16944);
        DeRef(_seek_1__tmp_at205_16981);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_15734;
        ((intptr_t *)_2)[2] = _block_ptr_16944;
        _seek_1__tmp_at205_16981 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_205_16980 = machine(19, _seek_1__tmp_at205_16981);
        DeRef(_seek_1__tmp_at205_16981);
        _seek_1__tmp_at205_16981 = NOVALUE;

        /** eds.e:1534				for j = 1 to block_size do*/
        Ref(_block_size_16945);
        DeRef(_9558);
        _9558 = _block_size_16945;
        {
            object _j_16983;
            _j_16983 = 1;
L7: 
            if (binary_op_a(GREATER, _j_16983, _9558)){
                goto L8; // [224] 255
            }

            /** eds.e:1535					key_pointers[k] = get4()*/
            _9559 = _41get4();
            _2 = (object)SEQ_PTR(_41key_pointers_15741);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _41key_pointers_15741 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _k_16947);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _9559;
            if( _1 != _9559 ){
                DeRef(_1);
            }
            _9559 = NOVALUE;

            /** eds.e:1536					k += 1*/
            _k_16947 = _k_16947 + 1;

            /** eds.e:1537				end for*/
            _0 = _j_16983;
            if (IS_ATOM_INT(_j_16983)) {
                _j_16983 = _j_16983 + 1;
                if ((object)((uintptr_t)_j_16983 +(uintptr_t) HIGH_BITS) >= 0){
                    _j_16983 = NewDouble((eudouble)_j_16983);
                }
            }
            else {
                _j_16983 = binary_op_a(PLUS, _j_16983, 1);
            }
            DeRef(_0);
            goto L7; // [250] 231
L8: 
            ;
            DeRef(_j_16983);
        }

        /** eds.e:1538				index += 8*/
        _0 = _index_16943;
        if (IS_ATOM_INT(_index_16943)) {
            _index_16943 = _index_16943 + 8;
            if ((object)((uintptr_t)_index_16943 + (uintptr_t)HIGH_BITS) >= 0){
                _index_16943 = NewDouble((eudouble)_index_16943);
            }
        }
        else {
            _index_16943 = NewDouble(DBL_PTR(_index_16943)->dbl + (eudouble)8);
        }
        DeRef(_0);

        /** eds.e:1539			end for*/
        _0 = _b_16972;
        if (IS_ATOM_INT(_b_16972)) {
            _b_16972 = _b_16972 + 1;
            if ((object)((uintptr_t)_b_16972 +(uintptr_t) HIGH_BITS) >= 0){
                _b_16972 = NewDouble((eudouble)_b_16972);
            }
        }
        else {
            _b_16972 = binary_op_a(PLUS, _b_16972, 1);
        }
        DeRef(_0);
        goto L5; // [263] 175
L6: 
        ;
        DeRef(_b_16972);
    }
L4: 

    /** eds.e:1541		return DB_OK*/
    DeRefDS(_name_16940);
    DeRef(_table_16941);
    DeRef(_nkeys_16942);
    DeRef(_index_16943);
    DeRef(_block_ptr_16944);
    DeRef(_block_size_16945);
    DeRef(_9555);
    _9555 = NOVALUE;
    return 0;
    ;
}


object _41db_create_table(object _name_16992, object _init_records_16993)
{
    object _name_ptr_16994 = NOVALUE;
    object _nt_16995 = NOVALUE;
    object _tables_16996 = NOVALUE;
    object _newtables_16997 = NOVALUE;
    object _table_16998 = NOVALUE;
    object _records_ptr_16999 = NOVALUE;
    object _size_17000 = NOVALUE;
    object _newsize_17001 = NOVALUE;
    object _index_ptr_17002 = NOVALUE;
    object _remaining_17003 = NOVALUE;
    object _init_index_17004 = NOVALUE;
    object _seek_1__tmp_at61_17016 = NOVALUE;
    object _seek_inlined_seek_at_61_17015 = NOVALUE;
    object _seek_1__tmp_at90_17022 = NOVALUE;
    object _seek_inlined_seek_at_90_17021 = NOVALUE;
    object _pos_inlined_seek_at_87_17020 = NOVALUE;
    object _put4_1__tmp_at152_17035 = NOVALUE;
    object _seek_1__tmp_at189_17040 = NOVALUE;
    object _seek_inlined_seek_at_189_17039 = NOVALUE;
    object _pos_inlined_seek_at_186_17038 = NOVALUE;
    object _seek_1__tmp_at232_17048 = NOVALUE;
    object _seek_inlined_seek_at_232_17047 = NOVALUE;
    object _pos_inlined_seek_at_229_17046 = NOVALUE;
    object _s_inlined_putn_at_281_17056 = NOVALUE;
    object _seek_1__tmp_at309_17059 = NOVALUE;
    object _seek_inlined_seek_at_309_17058 = NOVALUE;
    object _put4_1__tmp_at324_17061 = NOVALUE;
    object _seek_1__tmp_at362_17065 = NOVALUE;
    object _seek_inlined_seek_at_362_17064 = NOVALUE;
    object _put4_1__tmp_at377_17067 = NOVALUE;
    object _s_inlined_putn_at_424_17073 = NOVALUE;
    object _put4_1__tmp_at455_17077 = NOVALUE;
    object _put4_1__tmp_at483_17079 = NOVALUE;
    object _s_inlined_putn_at_523_17084 = NOVALUE;
    object _s_inlined_putn_at_561_17090 = NOVALUE;
    object _seek_1__tmp_at603_17098 = NOVALUE;
    object _seek_inlined_seek_at_603_17097 = NOVALUE;
    object _pos_inlined_seek_at_600_17096 = NOVALUE;
    object _put4_1__tmp_at618_17100 = NOVALUE;
    object _put4_1__tmp_at646_17102 = NOVALUE;
    object _put4_1__tmp_at674_17104 = NOVALUE;
    object _put4_1__tmp_at702_17106 = NOVALUE;
    object _9606 = NOVALUE;
    object _9605 = NOVALUE;
    object _9604 = NOVALUE;
    object _9603 = NOVALUE;
    object _9602 = NOVALUE;
    object _9601 = NOVALUE;
    object _9599 = NOVALUE;
    object _9598 = NOVALUE;
    object _9597 = NOVALUE;
    object _9596 = NOVALUE;
    object _9595 = NOVALUE;
    object _9593 = NOVALUE;
    object _9592 = NOVALUE;
    object _9591 = NOVALUE;
    object _9589 = NOVALUE;
    object _9588 = NOVALUE;
    object _9587 = NOVALUE;
    object _9586 = NOVALUE;
    object _9585 = NOVALUE;
    object _9584 = NOVALUE;
    object _9583 = NOVALUE;
    object _9581 = NOVALUE;
    object _9580 = NOVALUE;
    object _9579 = NOVALUE;
    object _9576 = NOVALUE;
    object _9575 = NOVALUE;
    object _9573 = NOVALUE;
    object _9572 = NOVALUE;
    object _9570 = NOVALUE;
    object _9568 = NOVALUE;
    object _9562 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1603		if not cstring(name) then*/
    RefDS(_name_16992);
    _9562 = _9cstring(_name_16992);
    if (IS_ATOM_INT(_9562)) {
        if (_9562 != 0){
            DeRef(_9562);
            _9562 = NOVALUE;
            goto L1; // [11] 21
        }
    }
    else {
        if (DBL_PTR(_9562)->dbl != 0.0){
            DeRef(_9562);
            _9562 = NOVALUE;
            goto L1; // [11] 21
        }
    }
    DeRef(_9562);
    _9562 = NOVALUE;

    /** eds.e:1604			return DB_BAD_NAME*/
    DeRefDS(_name_16992);
    DeRef(_name_ptr_16994);
    DeRef(_nt_16995);
    DeRef(_tables_16996);
    DeRef(_newtables_16997);
    DeRef(_table_16998);
    DeRef(_records_ptr_16999);
    DeRef(_size_17000);
    DeRef(_newsize_17001);
    DeRef(_index_ptr_17002);
    DeRef(_remaining_17003);
    return -4;
L1: 

    /** eds.e:1607		table = table_find(name)*/
    RefDS(_name_16992);
    _0 = _table_16998;
    _table_16998 = _41table_find(_name_16992);
    DeRef(_0);

    /** eds.e:1608		if table != -1 then*/
    if (binary_op_a(EQUALS, _table_16998, -1)){
        goto L2; // [29] 40
    }

    /** eds.e:1609			return DB_EXISTS_ALREADY*/
    DeRefDS(_name_16992);
    DeRef(_name_ptr_16994);
    DeRef(_nt_16995);
    DeRef(_tables_16996);
    DeRef(_newtables_16997);
    DeRef(_table_16998);
    DeRef(_records_ptr_16999);
    DeRef(_size_17000);
    DeRef(_newsize_17001);
    DeRef(_index_ptr_17002);
    DeRef(_remaining_17003);
    return -2;
L2: 

    /** eds.e:1612		if init_records < MAX_INDEX then*/
    if (_init_records_16993 >= 10)
    goto L3; // [42] 52

    /** eds.e:1613			init_records = MAX_INDEX*/
    _init_records_16993 = 10;
L3: 

    /** eds.e:1615		init_index = MAX_INDEX*/
    _init_index_17004 = 10;

    /** eds.e:1618		io:seek(current_db, TABLE_HEADERS)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at61_17016);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = 3;
    _seek_1__tmp_at61_17016 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_61_17015 = machine(19, _seek_1__tmp_at61_17016);
    DeRefi(_seek_1__tmp_at61_17016);
    _seek_1__tmp_at61_17016 = NOVALUE;

    /** eds.e:1619		tables = get4()*/
    _0 = _tables_16996;
    _tables_16996 = _41get4();
    DeRef(_0);

    /** eds.e:1620		io:seek(current_db, tables-4)*/
    if (IS_ATOM_INT(_tables_16996)) {
        _9568 = _tables_16996 - 4;
        if ((object)((uintptr_t)_9568 +(uintptr_t) HIGH_BITS) >= 0){
            _9568 = NewDouble((eudouble)_9568);
        }
    }
    else {
        _9568 = NewDouble(DBL_PTR(_tables_16996)->dbl - (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_87_17020);
    _pos_inlined_seek_at_87_17020 = _9568;
    _9568 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_87_17020);
    DeRef(_seek_1__tmp_at90_17022);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_87_17020;
    _seek_1__tmp_at90_17022 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_90_17021 = machine(19, _seek_1__tmp_at90_17022);
    DeRef(_pos_inlined_seek_at_87_17020);
    _pos_inlined_seek_at_87_17020 = NOVALUE;
    DeRef(_seek_1__tmp_at90_17022);
    _seek_1__tmp_at90_17022 = NOVALUE;

    /** eds.e:1621		size = get4()*/
    _0 = _size_17000;
    _size_17000 = _41get4();
    DeRef(_0);

    /** eds.e:1622		nt = get4()+1*/
    _9570 = _41get4();
    DeRef(_nt_16995);
    if (IS_ATOM_INT(_9570)) {
        _nt_16995 = _9570 + 1;
        if (_nt_16995 > MAXINT){
            _nt_16995 = NewDouble((eudouble)_nt_16995);
        }
    }
    else
    _nt_16995 = binary_op(PLUS, 1, _9570);
    DeRef(_9570);
    _9570 = NOVALUE;

    /** eds.e:1623		if nt*SIZEOF_TABLE_HEADER + 8 > size then*/
    if (IS_ATOM_INT(_nt_16995)) {
        if (_nt_16995 == (short)_nt_16995){
            _9572 = _nt_16995 * 16;
        }
        else{
            _9572 = NewDouble(_nt_16995 * (eudouble)16);
        }
    }
    else {
        _9572 = NewDouble(DBL_PTR(_nt_16995)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_9572)) {
        _9573 = _9572 + 8;
        if ((object)((uintptr_t)_9573 + (uintptr_t)HIGH_BITS) >= 0){
            _9573 = NewDouble((eudouble)_9573);
        }
    }
    else {
        _9573 = NewDouble(DBL_PTR(_9572)->dbl + (eudouble)8);
    }
    DeRef(_9572);
    _9572 = NOVALUE;
    if (binary_op_a(LESSEQ, _9573, _size_17000)){
        DeRef(_9573);
        _9573 = NOVALUE;
        goto L4; // [127] 358
    }
    DeRef(_9573);
    _9573 = NOVALUE;

    /** eds.e:1625			newsize = floor(size + size / 2)*/
    if (IS_ATOM_INT(_size_17000)) {
        if (_size_17000 & 1) {
            _9575 = NewDouble((_size_17000 >> 1) + 0.5);
        }
        else
        _9575 = _size_17000 >> 1;
    }
    else {
        _9575 = binary_op(DIVIDE, _size_17000, 2);
    }
    if (IS_ATOM_INT(_size_17000) && IS_ATOM_INT(_9575)) {
        _9576 = _size_17000 + _9575;
        if ((object)((uintptr_t)_9576 + (uintptr_t)HIGH_BITS) >= 0){
            _9576 = NewDouble((eudouble)_9576);
        }
    }
    else {
        if (IS_ATOM_INT(_size_17000)) {
            _9576 = NewDouble((eudouble)_size_17000 + DBL_PTR(_9575)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9575)) {
                _9576 = NewDouble(DBL_PTR(_size_17000)->dbl + (eudouble)_9575);
            }
            else
            _9576 = NewDouble(DBL_PTR(_size_17000)->dbl + DBL_PTR(_9575)->dbl);
        }
    }
    DeRef(_9575);
    _9575 = NOVALUE;
    DeRef(_newsize_17001);
    if (IS_ATOM_INT(_9576))
    _newsize_17001 = e_floor(_9576);
    else
    _newsize_17001 = unary_op(FLOOR, _9576);
    DeRef(_9576);
    _9576 = NOVALUE;

    /** eds.e:1626			newtables = db_allocate(newsize)*/
    Ref(_newsize_17001);
    _0 = _newtables_16997;
    _newtables_16997 = _41db_allocate(_newsize_17001);
    DeRef(_0);

    /** eds.e:1627			put4(nt)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_nt_16995)) {
        *poke4_addr = (uint32_t)_nt_16995;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_nt_16995)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at152_17035);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at152_17035 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at152_17035); // DJP 

    /** eds.e:444	end procedure*/
    goto L5; // [173] 176
L5: 
    DeRefi(_put4_1__tmp_at152_17035);
    _put4_1__tmp_at152_17035 = NOVALUE;

    /** eds.e:1629			io:seek(current_db, tables+4)*/
    if (IS_ATOM_INT(_tables_16996)) {
        _9579 = _tables_16996 + 4;
        if ((object)((uintptr_t)_9579 + (uintptr_t)HIGH_BITS) >= 0){
            _9579 = NewDouble((eudouble)_9579);
        }
    }
    else {
        _9579 = NewDouble(DBL_PTR(_tables_16996)->dbl + (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_186_17038);
    _pos_inlined_seek_at_186_17038 = _9579;
    _9579 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_186_17038);
    DeRef(_seek_1__tmp_at189_17040);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_186_17038;
    _seek_1__tmp_at189_17040 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_189_17039 = machine(19, _seek_1__tmp_at189_17040);
    DeRef(_pos_inlined_seek_at_186_17038);
    _pos_inlined_seek_at_186_17038 = NOVALUE;
    DeRef(_seek_1__tmp_at189_17040);
    _seek_1__tmp_at189_17040 = NOVALUE;

    /** eds.e:1630			remaining = io:get_bytes(current_db, (nt-1)*SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_nt_16995)) {
        _9580 = _nt_16995 - 1;
        if ((object)((uintptr_t)_9580 +(uintptr_t) HIGH_BITS) >= 0){
            _9580 = NewDouble((eudouble)_9580);
        }
    }
    else {
        _9580 = NewDouble(DBL_PTR(_nt_16995)->dbl - (eudouble)1);
    }
    if (IS_ATOM_INT(_9580)) {
        if (_9580 == (short)_9580){
            _9581 = _9580 * 16;
        }
        else{
            _9581 = NewDouble(_9580 * (eudouble)16);
        }
    }
    else {
        _9581 = NewDouble(DBL_PTR(_9580)->dbl * (eudouble)16);
    }
    DeRef(_9580);
    _9580 = NOVALUE;
    _0 = _remaining_17003;
    _remaining_17003 = _17get_bytes(_41current_db_15734, _9581);
    DeRef(_0);
    _9581 = NOVALUE;

    /** eds.e:1631			io:seek(current_db, newtables+4)*/
    if (IS_ATOM_INT(_newtables_16997)) {
        _9583 = _newtables_16997 + 4;
        if ((object)((uintptr_t)_9583 + (uintptr_t)HIGH_BITS) >= 0){
            _9583 = NewDouble((eudouble)_9583);
        }
    }
    else {
        _9583 = NewDouble(DBL_PTR(_newtables_16997)->dbl + (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_229_17046);
    _pos_inlined_seek_at_229_17046 = _9583;
    _9583 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_229_17046);
    DeRef(_seek_1__tmp_at232_17048);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_229_17046;
    _seek_1__tmp_at232_17048 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_232_17047 = machine(19, _seek_1__tmp_at232_17048);
    DeRef(_pos_inlined_seek_at_229_17046);
    _pos_inlined_seek_at_229_17046 = NOVALUE;
    DeRef(_seek_1__tmp_at232_17048);
    _seek_1__tmp_at232_17048 = NOVALUE;

    /** eds.e:1632			putn(remaining)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_15734, _remaining_17003); // DJP 

    /** eds.e:449	end procedure*/
    goto L6; // [256] 259
L6: 

    /** eds.e:1634			putn(repeat(0, newsize - 4 - (nt-1)*SIZEOF_TABLE_HEADER))*/
    if (IS_ATOM_INT(_newsize_17001)) {
        _9584 = _newsize_17001 - 4;
        if ((object)((uintptr_t)_9584 +(uintptr_t) HIGH_BITS) >= 0){
            _9584 = NewDouble((eudouble)_9584);
        }
    }
    else {
        _9584 = NewDouble(DBL_PTR(_newsize_17001)->dbl - (eudouble)4);
    }
    if (IS_ATOM_INT(_nt_16995)) {
        _9585 = _nt_16995 - 1;
        if ((object)((uintptr_t)_9585 +(uintptr_t) HIGH_BITS) >= 0){
            _9585 = NewDouble((eudouble)_9585);
        }
    }
    else {
        _9585 = NewDouble(DBL_PTR(_nt_16995)->dbl - (eudouble)1);
    }
    if (IS_ATOM_INT(_9585)) {
        if (_9585 == (short)_9585){
            _9586 = _9585 * 16;
        }
        else{
            _9586 = NewDouble(_9585 * (eudouble)16);
        }
    }
    else {
        _9586 = NewDouble(DBL_PTR(_9585)->dbl * (eudouble)16);
    }
    DeRef(_9585);
    _9585 = NOVALUE;
    if (IS_ATOM_INT(_9584) && IS_ATOM_INT(_9586)) {
        _9587 = _9584 - _9586;
    }
    else {
        if (IS_ATOM_INT(_9584)) {
            _9587 = NewDouble((eudouble)_9584 - DBL_PTR(_9586)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9586)) {
                _9587 = NewDouble(DBL_PTR(_9584)->dbl - (eudouble)_9586);
            }
            else
            _9587 = NewDouble(DBL_PTR(_9584)->dbl - DBL_PTR(_9586)->dbl);
        }
    }
    DeRef(_9584);
    _9584 = NOVALUE;
    DeRef(_9586);
    _9586 = NOVALUE;
    _9588 = Repeat(0, _9587);
    DeRef(_9587);
    _9587 = NOVALUE;
    DeRefi(_s_inlined_putn_at_281_17056);
    _s_inlined_putn_at_281_17056 = _9588;
    _9588 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_15734, _s_inlined_putn_at_281_17056); // DJP 

    /** eds.e:449	end procedure*/
    goto L7; // [295] 298
L7: 
    DeRefi(_s_inlined_putn_at_281_17056);
    _s_inlined_putn_at_281_17056 = NOVALUE;

    /** eds.e:1635			db_free(tables)*/
    Ref(_tables_16996);
    _41db_free(_tables_16996);

    /** eds.e:1636			io:seek(current_db, TABLE_HEADERS)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at309_17059);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = 3;
    _seek_1__tmp_at309_17059 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_309_17058 = machine(19, _seek_1__tmp_at309_17059);
    DeRefi(_seek_1__tmp_at309_17059);
    _seek_1__tmp_at309_17059 = NOVALUE;

    /** eds.e:1637			put4(newtables)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_newtables_16997)) {
        *poke4_addr = (uint32_t)_newtables_16997;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_newtables_16997)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at324_17061);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at324_17061 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at324_17061); // DJP 

    /** eds.e:444	end procedure*/
    goto L8; // [345] 348
L8: 
    DeRefi(_put4_1__tmp_at324_17061);
    _put4_1__tmp_at324_17061 = NOVALUE;

    /** eds.e:1638			tables = newtables*/
    Ref(_newtables_16997);
    DeRef(_tables_16996);
    _tables_16996 = _newtables_16997;
    goto L9; // [355] 404
L4: 

    /** eds.e:1640			io:seek(current_db, tables)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_16996);
    DeRef(_seek_1__tmp_at362_17065);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _tables_16996;
    _seek_1__tmp_at362_17065 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_362_17064 = machine(19, _seek_1__tmp_at362_17065);
    DeRef(_seek_1__tmp_at362_17065);
    _seek_1__tmp_at362_17065 = NOVALUE;

    /** eds.e:1641			put4(nt)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_nt_16995)) {
        *poke4_addr = (uint32_t)_nt_16995;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_nt_16995)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at377_17067);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at377_17067 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at377_17067); // DJP 

    /** eds.e:444	end procedure*/
    goto LA; // [398] 401
LA: 
    DeRefi(_put4_1__tmp_at377_17067);
    _put4_1__tmp_at377_17067 = NOVALUE;
L9: 

    /** eds.e:1645		records_ptr = db_allocate(init_records * 4)*/
    if (_init_records_16993 == (short)_init_records_16993){
        _9589 = _init_records_16993 * 4;
    }
    else{
        _9589 = NewDouble(_init_records_16993 * (eudouble)4);
    }
    _0 = _records_ptr_16999;
    _records_ptr_16999 = _41db_allocate(_9589);
    DeRef(_0);
    _9589 = NOVALUE;

    /** eds.e:1646		putn(repeat(0, init_records * 4))*/
    _9591 = _init_records_16993 * 4;
    _9592 = Repeat(0, _9591);
    _9591 = NOVALUE;
    DeRefi(_s_inlined_putn_at_424_17073);
    _s_inlined_putn_at_424_17073 = _9592;
    _9592 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_15734, _s_inlined_putn_at_424_17073); // DJP 

    /** eds.e:449	end procedure*/
    goto LB; // [438] 441
LB: 
    DeRefi(_s_inlined_putn_at_424_17073);
    _s_inlined_putn_at_424_17073 = NOVALUE;

    /** eds.e:1649		index_ptr = db_allocate(init_index * 8)*/
    if (_init_index_17004 == (short)_init_index_17004){
        _9593 = _init_index_17004 * 8;
    }
    else{
        _9593 = NewDouble(_init_index_17004 * (eudouble)8);
    }
    _0 = _index_ptr_17002;
    _index_ptr_17002 = _41db_allocate(_9593);
    DeRef(_0);
    _9593 = NOVALUE;

    /** eds.e:1650		put4(0)  -- 0 records*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    *poke4_addr = (uint32_t)0;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at455_17077);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at455_17077 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at455_17077); // DJP 

    /** eds.e:444	end procedure*/
    goto LC; // [476] 479
LC: 
    DeRefi(_put4_1__tmp_at455_17077);
    _put4_1__tmp_at455_17077 = NOVALUE;

    /** eds.e:1651		put4(records_ptr) -- point to 1st block*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_records_ptr_16999)) {
        *poke4_addr = (uint32_t)_records_ptr_16999;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_records_ptr_16999)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at483_17079);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at483_17079 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at483_17079); // DJP 

    /** eds.e:444	end procedure*/
    goto LD; // [504] 507
LD: 
    DeRefi(_put4_1__tmp_at483_17079);
    _put4_1__tmp_at483_17079 = NOVALUE;

    /** eds.e:1652		putn(repeat(0, (init_index-1) * 8))*/
    _9595 = _init_index_17004 - 1;
    if ((object)((uintptr_t)_9595 +(uintptr_t) HIGH_BITS) >= 0){
        _9595 = NewDouble((eudouble)_9595);
    }
    if (IS_ATOM_INT(_9595)) {
        _9596 = _9595 * 8;
    }
    else {
        _9596 = NewDouble(DBL_PTR(_9595)->dbl * (eudouble)8);
    }
    DeRef(_9595);
    _9595 = NOVALUE;
    _9597 = Repeat(0, _9596);
    DeRef(_9596);
    _9596 = NOVALUE;
    DeRefi(_s_inlined_putn_at_523_17084);
    _s_inlined_putn_at_523_17084 = _9597;
    _9597 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_15734, _s_inlined_putn_at_523_17084); // DJP 

    /** eds.e:449	end procedure*/
    goto LE; // [537] 540
LE: 
    DeRefi(_s_inlined_putn_at_523_17084);
    _s_inlined_putn_at_523_17084 = NOVALUE;

    /** eds.e:1655		name_ptr = db_allocate(length(name)+1)*/
    if (IS_SEQUENCE(_name_16992)){
            _9598 = SEQ_PTR(_name_16992)->length;
    }
    else {
        _9598 = 1;
    }
    _9599 = _9598 + 1;
    _9598 = NOVALUE;
    _0 = _name_ptr_16994;
    _name_ptr_16994 = _41db_allocate(_9599);
    DeRef(_0);
    _9599 = NOVALUE;

    /** eds.e:1656		putn(name & 0)*/
    Append(&_9601, _name_16992, 0);
    DeRef(_s_inlined_putn_at_561_17090);
    _s_inlined_putn_at_561_17090 = _9601;
    _9601 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_15734, _s_inlined_putn_at_561_17090); // DJP 

    /** eds.e:449	end procedure*/
    goto LF; // [575] 578
LF: 
    DeRef(_s_inlined_putn_at_561_17090);
    _s_inlined_putn_at_561_17090 = NOVALUE;

    /** eds.e:1658		io:seek(current_db, tables+4+(nt-1)*SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_tables_16996)) {
        _9602 = _tables_16996 + 4;
        if ((object)((uintptr_t)_9602 + (uintptr_t)HIGH_BITS) >= 0){
            _9602 = NewDouble((eudouble)_9602);
        }
    }
    else {
        _9602 = NewDouble(DBL_PTR(_tables_16996)->dbl + (eudouble)4);
    }
    if (IS_ATOM_INT(_nt_16995)) {
        _9603 = _nt_16995 - 1;
        if ((object)((uintptr_t)_9603 +(uintptr_t) HIGH_BITS) >= 0){
            _9603 = NewDouble((eudouble)_9603);
        }
    }
    else {
        _9603 = NewDouble(DBL_PTR(_nt_16995)->dbl - (eudouble)1);
    }
    if (IS_ATOM_INT(_9603)) {
        if (_9603 == (short)_9603){
            _9604 = _9603 * 16;
        }
        else{
            _9604 = NewDouble(_9603 * (eudouble)16);
        }
    }
    else {
        _9604 = NewDouble(DBL_PTR(_9603)->dbl * (eudouble)16);
    }
    DeRef(_9603);
    _9603 = NOVALUE;
    if (IS_ATOM_INT(_9602) && IS_ATOM_INT(_9604)) {
        _9605 = _9602 + _9604;
        if ((object)((uintptr_t)_9605 + (uintptr_t)HIGH_BITS) >= 0){
            _9605 = NewDouble((eudouble)_9605);
        }
    }
    else {
        if (IS_ATOM_INT(_9602)) {
            _9605 = NewDouble((eudouble)_9602 + DBL_PTR(_9604)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9604)) {
                _9605 = NewDouble(DBL_PTR(_9602)->dbl + (eudouble)_9604);
            }
            else
            _9605 = NewDouble(DBL_PTR(_9602)->dbl + DBL_PTR(_9604)->dbl);
        }
    }
    DeRef(_9602);
    _9602 = NOVALUE;
    DeRef(_9604);
    _9604 = NOVALUE;
    DeRef(_pos_inlined_seek_at_600_17096);
    _pos_inlined_seek_at_600_17096 = _9605;
    _9605 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_600_17096);
    DeRef(_seek_1__tmp_at603_17098);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_600_17096;
    _seek_1__tmp_at603_17098 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_603_17097 = machine(19, _seek_1__tmp_at603_17098);
    DeRef(_pos_inlined_seek_at_600_17096);
    _pos_inlined_seek_at_600_17096 = NOVALUE;
    DeRef(_seek_1__tmp_at603_17098);
    _seek_1__tmp_at603_17098 = NOVALUE;

    /** eds.e:1659		put4(name_ptr)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_name_ptr_16994)) {
        *poke4_addr = (uint32_t)_name_ptr_16994;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_name_ptr_16994)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at618_17100);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at618_17100 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at618_17100); // DJP 

    /** eds.e:444	end procedure*/
    goto L10; // [639] 642
L10: 
    DeRefi(_put4_1__tmp_at618_17100);
    _put4_1__tmp_at618_17100 = NOVALUE;

    /** eds.e:1660		put4(0)  -- start with 0 records total*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    *poke4_addr = (uint32_t)0;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at646_17102);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at646_17102 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at646_17102); // DJP 

    /** eds.e:444	end procedure*/
    goto L11; // [667] 670
L11: 
    DeRefi(_put4_1__tmp_at646_17102);
    _put4_1__tmp_at646_17102 = NOVALUE;

    /** eds.e:1661		put4(1)  -- start with 1 block of records in index*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    *poke4_addr = (uint32_t)1;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at674_17104);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at674_17104 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at674_17104); // DJP 

    /** eds.e:444	end procedure*/
    goto L12; // [695] 698
L12: 
    DeRefi(_put4_1__tmp_at674_17104);
    _put4_1__tmp_at674_17104 = NOVALUE;

    /** eds.e:1662		put4(index_ptr)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_index_ptr_17002)) {
        *poke4_addr = (uint32_t)_index_ptr_17002;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_index_ptr_17002)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at702_17106);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at702_17106 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at702_17106); // DJP 

    /** eds.e:444	end procedure*/
    goto L13; // [723] 726
L13: 
    DeRefi(_put4_1__tmp_at702_17106);
    _put4_1__tmp_at702_17106 = NOVALUE;

    /** eds.e:1663		if db_select_table(name) then*/
    RefDS(_name_16992);
    _9606 = _41db_select_table(_name_16992);
    if (_9606 == 0) {
        DeRef(_9606);
        _9606 = NOVALUE;
        goto L14; // [734] 738
    }
    else {
        if (!IS_ATOM_INT(_9606) && DBL_PTR(_9606)->dbl == 0.0){
            DeRef(_9606);
            _9606 = NOVALUE;
            goto L14; // [734] 738
        }
        DeRef(_9606);
        _9606 = NOVALUE;
    }
    DeRef(_9606);
    _9606 = NOVALUE;
L14: 

    /** eds.e:1665		return DB_OK*/
    DeRefDS(_name_16992);
    DeRef(_name_ptr_16994);
    DeRef(_nt_16995);
    DeRef(_tables_16996);
    DeRef(_newtables_16997);
    DeRef(_table_16998);
    DeRef(_records_ptr_16999);
    DeRef(_size_17000);
    DeRef(_newsize_17001);
    DeRef(_index_ptr_17002);
    DeRef(_remaining_17003);
    return 0;
    ;
}


object _41db_table_list()
{
    object _seek_1__tmp_at120_17363 = NOVALUE;
    object _seek_inlined_seek_at_120_17362 = NOVALUE;
    object _seek_1__tmp_at98_17359 = NOVALUE;
    object _seek_inlined_seek_at_98_17358 = NOVALUE;
    object _pos_inlined_seek_at_95_17357 = NOVALUE;
    object _seek_1__tmp_at42_17347 = NOVALUE;
    object _seek_inlined_seek_at_42_17346 = NOVALUE;
    object _seek_1__tmp_at4_17340 = NOVALUE;
    object _seek_inlined_seek_at_4_17339 = NOVALUE;
    object _table_names_17334 = NOVALUE;
    object _tables_17335 = NOVALUE;
    object _nt_17336 = NOVALUE;
    object _name_17337 = NOVALUE;
    object _9703 = NOVALUE;
    object _9702 = NOVALUE;
    object _9700 = NOVALUE;
    object _9699 = NOVALUE;
    object _9698 = NOVALUE;
    object _9697 = NOVALUE;
    object _9692 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1923		io:seek(current_db, TABLE_HEADERS)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_17340);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = 3;
    _seek_1__tmp_at4_17340 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_17339 = machine(19, _seek_1__tmp_at4_17340);
    DeRefi(_seek_1__tmp_at4_17340);
    _seek_1__tmp_at4_17340 = NOVALUE;

    /** eds.e:1924		if length(vLastErrors) > 0 then return {} end if*/
    if (IS_SEQUENCE(_41vLastErrors_15758)){
            _9692 = SEQ_PTR(_41vLastErrors_15758)->length;
    }
    else {
        _9692 = 1;
    }
    if (_9692 <= 0)
    goto L1; // [25] 34
    RefDS(_5);
    DeRef(_table_names_17334);
    DeRef(_tables_17335);
    DeRef(_nt_17336);
    DeRef(_name_17337);
    return _5;
L1: 

    /** eds.e:1925		tables = get4()*/
    _0 = _tables_17335;
    _tables_17335 = _41get4();
    DeRef(_0);

    /** eds.e:1926		io:seek(current_db, tables)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_17335);
    DeRef(_seek_1__tmp_at42_17347);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _tables_17335;
    _seek_1__tmp_at42_17347 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_42_17346 = machine(19, _seek_1__tmp_at42_17347);
    DeRef(_seek_1__tmp_at42_17347);
    _seek_1__tmp_at42_17347 = NOVALUE;

    /** eds.e:1927		nt = get4()*/
    _0 = _nt_17336;
    _nt_17336 = _41get4();
    DeRef(_0);

    /** eds.e:1928		table_names = repeat(0, nt)*/
    DeRef(_table_names_17334);
    _table_names_17334 = Repeat(0, _nt_17336);

    /** eds.e:1929		for i = 0 to nt-1 do*/
    if (IS_ATOM_INT(_nt_17336)) {
        _9697 = _nt_17336 - 1;
        if ((object)((uintptr_t)_9697 +(uintptr_t) HIGH_BITS) >= 0){
            _9697 = NewDouble((eudouble)_9697);
        }
    }
    else {
        _9697 = NewDouble(DBL_PTR(_nt_17336)->dbl - (eudouble)1);
    }
    {
        object _i_17351;
        _i_17351 = 0;
L2: 
        if (binary_op_a(GREATER, _i_17351, _9697)){
            goto L3; // [73] 154
        }

        /** eds.e:1930			io:seek(current_db, tables + 4 + i*SIZEOF_TABLE_HEADER)*/
        if (IS_ATOM_INT(_tables_17335)) {
            _9698 = _tables_17335 + 4;
            if ((object)((uintptr_t)_9698 + (uintptr_t)HIGH_BITS) >= 0){
                _9698 = NewDouble((eudouble)_9698);
            }
        }
        else {
            _9698 = NewDouble(DBL_PTR(_tables_17335)->dbl + (eudouble)4);
        }
        if (IS_ATOM_INT(_i_17351)) {
            if (_i_17351 == (short)_i_17351){
                _9699 = _i_17351 * 16;
            }
            else{
                _9699 = NewDouble(_i_17351 * (eudouble)16);
            }
        }
        else {
            _9699 = NewDouble(DBL_PTR(_i_17351)->dbl * (eudouble)16);
        }
        if (IS_ATOM_INT(_9698) && IS_ATOM_INT(_9699)) {
            _9700 = _9698 + _9699;
            if ((object)((uintptr_t)_9700 + (uintptr_t)HIGH_BITS) >= 0){
                _9700 = NewDouble((eudouble)_9700);
            }
        }
        else {
            if (IS_ATOM_INT(_9698)) {
                _9700 = NewDouble((eudouble)_9698 + DBL_PTR(_9699)->dbl);
            }
            else {
                if (IS_ATOM_INT(_9699)) {
                    _9700 = NewDouble(DBL_PTR(_9698)->dbl + (eudouble)_9699);
                }
                else
                _9700 = NewDouble(DBL_PTR(_9698)->dbl + DBL_PTR(_9699)->dbl);
            }
        }
        DeRef(_9698);
        _9698 = NOVALUE;
        DeRef(_9699);
        _9699 = NOVALUE;
        DeRef(_pos_inlined_seek_at_95_17357);
        _pos_inlined_seek_at_95_17357 = _9700;
        _9700 = NOVALUE;

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_95_17357);
        DeRef(_seek_1__tmp_at98_17359);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_15734;
        ((intptr_t *)_2)[2] = _pos_inlined_seek_at_95_17357;
        _seek_1__tmp_at98_17359 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_98_17358 = machine(19, _seek_1__tmp_at98_17359);
        DeRef(_pos_inlined_seek_at_95_17357);
        _pos_inlined_seek_at_95_17357 = NOVALUE;
        DeRef(_seek_1__tmp_at98_17359);
        _seek_1__tmp_at98_17359 = NOVALUE;

        /** eds.e:1931			name = get4()*/
        _0 = _name_17337;
        _name_17337 = _41get4();
        DeRef(_0);

        /** eds.e:1932			io:seek(current_db, name)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_17337);
        DeRef(_seek_1__tmp_at120_17363);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_15734;
        ((intptr_t *)_2)[2] = _name_17337;
        _seek_1__tmp_at120_17363 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_120_17362 = machine(19, _seek_1__tmp_at120_17363);
        DeRef(_seek_1__tmp_at120_17363);
        _seek_1__tmp_at120_17363 = NOVALUE;

        /** eds.e:1933			table_names[i+1] = get_string()*/
        if (IS_ATOM_INT(_i_17351)) {
            _9702 = _i_17351 + 1;
            if (_9702 > MAXINT){
                _9702 = NewDouble((eudouble)_9702);
            }
        }
        else
        _9702 = binary_op(PLUS, 1, _i_17351);
        _9703 = _41get_string();
        _2 = (object)SEQ_PTR(_table_names_17334);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _table_names_17334 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_9702))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_9702)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _9702);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _9703;
        if( _1 != _9703 ){
            DeRef(_1);
        }
        _9703 = NOVALUE;

        /** eds.e:1934		end for*/
        _0 = _i_17351;
        if (IS_ATOM_INT(_i_17351)) {
            _i_17351 = _i_17351 + 1;
            if ((object)((uintptr_t)_i_17351 +(uintptr_t) HIGH_BITS) >= 0){
                _i_17351 = NewDouble((eudouble)_i_17351);
            }
        }
        else {
            _i_17351 = binary_op_a(PLUS, _i_17351, 1);
        }
        DeRef(_0);
        goto L2; // [149] 80
L3: 
        ;
        DeRef(_i_17351);
    }

    /** eds.e:1935		return table_names*/
    DeRef(_tables_17335);
    DeRef(_nt_17336);
    DeRef(_name_17337);
    DeRef(_9702);
    _9702 = NOVALUE;
    DeRef(_9697);
    _9697 = NOVALUE;
    return _table_names_17334;
    ;
}


object _41key_value(object _ptr_17368)
{
    object _seek_1__tmp_at11_17373 = NOVALUE;
    object _seek_inlined_seek_at_11_17372 = NOVALUE;
    object _pos_inlined_seek_at_8_17371 = NOVALUE;
    object _9705 = NOVALUE;
    object _9704 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1941		io:seek(current_db, ptr+4) -- skip ptr to data*/
    if (IS_ATOM_INT(_ptr_17368)) {
        _9704 = _ptr_17368 + 4;
        if ((object)((uintptr_t)_9704 + (uintptr_t)HIGH_BITS) >= 0){
            _9704 = NewDouble((eudouble)_9704);
        }
    }
    else {
        _9704 = NewDouble(DBL_PTR(_ptr_17368)->dbl + (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_8_17371);
    _pos_inlined_seek_at_8_17371 = _9704;
    _9704 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_17371);
    DeRef(_seek_1__tmp_at11_17373);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_8_17371;
    _seek_1__tmp_at11_17373 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_17372 = machine(19, _seek_1__tmp_at11_17373);
    DeRef(_pos_inlined_seek_at_8_17371);
    _pos_inlined_seek_at_8_17371 = NOVALUE;
    DeRef(_seek_1__tmp_at11_17373);
    _seek_1__tmp_at11_17373 = NOVALUE;

    /** eds.e:1942		return decompress(0)*/
    _9705 = _41decompress(0);
    DeRef(_ptr_17368);
    return _9705;
    ;
}


object _41db_find_key(object _key_17377, object _table_name_17378)
{
    object _lo_17379 = NOVALUE;
    object _hi_17380 = NOVALUE;
    object _mid_17381 = NOVALUE;
    object _c_17382 = NOVALUE;
    object _9729 = NOVALUE;
    object _9721 = NOVALUE;
    object _9720 = NOVALUE;
    object _9718 = NOVALUE;
    object _9715 = NOVALUE;
    object _9712 = NOVALUE;
    object _9708 = NOVALUE;
    object _9706 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2003		if not equal(table_name, current_table_name) then*/
    if (_table_name_17378 == _41current_table_name_15736)
    _9706 = 1;
    else if (IS_ATOM_INT(_table_name_17378) && IS_ATOM_INT(_41current_table_name_15736))
    _9706 = 0;
    else
    _9706 = (compare(_table_name_17378, _41current_table_name_15736) == 0);
    if (_9706 != 0)
    goto L1; // [9] 42
    _9706 = NOVALUE;

    /** eds.e:2004			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_17378);
    _9708 = _41db_select_table(_table_name_17378);
    if (binary_op_a(EQUALS, _9708, 0)){
        DeRef(_9708);
        _9708 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_9708);
    _9708 = NOVALUE;

    /** eds.e:2005				fatal(NO_TABLE, "invalid table name given", "db_find_key", {key, table_name})*/
    RefDS(_table_name_17378);
    Ref(_key_17377);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_17377;
    ((intptr_t *)_2)[2] = _table_name_17378;
    _9712 = MAKE_SEQ(_1);
    RefDS(_9710);
    RefDS(_9711);
    _41fatal(903, _9710, _9711, _9712);
    _9712 = NOVALUE;

    /** eds.e:2006				return 0*/
    DeRef(_key_17377);
    DeRefDS(_table_name_17378);
    return 0;
L2: 
L1: 

    /** eds.e:2010		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _41current_table_pos_15735, -1)){
        goto L3; // [46] 69
    }

    /** eds.e:2011			fatal(NO_TABLE, "no table selected", "db_find_key", {key, table_name})*/
    Ref(_table_name_17378);
    Ref(_key_17377);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_17377;
    ((intptr_t *)_2)[2] = _table_name_17378;
    _9715 = MAKE_SEQ(_1);
    RefDS(_9714);
    RefDS(_9711);
    _41fatal(903, _9714, _9711, _9715);
    _9715 = NOVALUE;

    /** eds.e:2012			return 0*/
    DeRef(_key_17377);
    DeRef(_table_name_17378);
    return 0;
L3: 

    /** eds.e:2015		lo = 1*/
    _lo_17379 = 1;

    /** eds.e:2016		hi = length(key_pointers)*/
    if (IS_SEQUENCE(_41key_pointers_15741)){
            _hi_17380 = SEQ_PTR(_41key_pointers_15741)->length;
    }
    else {
        _hi_17380 = 1;
    }

    /** eds.e:2017		mid = 1*/
    _mid_17381 = 1;

    /** eds.e:2018		c = 0*/
    _c_17382 = 0;

    /** eds.e:2019		while lo <= hi do*/
L4: 
    if (_lo_17379 > _hi_17380)
    goto L5; // [96] 170

    /** eds.e:2020			mid = floor((lo + hi) / 2)*/
    _9718 = _lo_17379 + _hi_17380;
    if ((object)((uintptr_t)_9718 + (uintptr_t)HIGH_BITS) >= 0){
        _9718 = NewDouble((eudouble)_9718);
    }
    if (IS_ATOM_INT(_9718)) {
        _mid_17381 = _9718 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _9718, 2);
        _mid_17381 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_9718);
    _9718 = NOVALUE;
    if (!IS_ATOM_INT(_mid_17381)) {
        _1 = (object)(DBL_PTR(_mid_17381)->dbl);
        DeRefDS(_mid_17381);
        _mid_17381 = _1;
    }

    /** eds.e:2021			c = eu:compare(key, key_value(key_pointers[mid]))*/
    _2 = (object)SEQ_PTR(_41key_pointers_15741);
    _9720 = (object)*(((s1_ptr)_2)->base + _mid_17381);
    Ref(_9720);
    _9721 = _41key_value(_9720);
    _9720 = NOVALUE;
    if (IS_ATOM_INT(_key_17377) && IS_ATOM_INT(_9721)){
        _c_17382 = (_key_17377 < _9721) ? -1 : (_key_17377 > _9721);
    }
    else{
        _c_17382 = compare(_key_17377, _9721);
    }
    DeRef(_9721);
    _9721 = NOVALUE;

    /** eds.e:2022			if c < 0 then*/
    if (_c_17382 >= 0)
    goto L6; // [130] 143

    /** eds.e:2023				hi = mid - 1*/
    _hi_17380 = _mid_17381 - 1;
    goto L4; // [140] 96
L6: 

    /** eds.e:2024			elsif c > 0 then*/
    if (_c_17382 <= 0)
    goto L7; // [145] 158

    /** eds.e:2025				lo = mid + 1*/
    _lo_17379 = _mid_17381 + 1;
    goto L4; // [155] 96
L7: 

    /** eds.e:2027				return mid*/
    DeRef(_key_17377);
    DeRef(_table_name_17378);
    return _mid_17381;

    /** eds.e:2029		end while*/
    goto L4; // [167] 96
L5: 

    /** eds.e:2031		if c > 0 then*/
    if (_c_17382 <= 0)
    goto L8; // [172] 183

    /** eds.e:2032			mid += 1*/
    _mid_17381 = _mid_17381 + 1;
L8: 

    /** eds.e:2034		return -mid*/
    if ((uintptr_t)_mid_17381 == (uintptr_t)HIGH_BITS){
        _9729 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _9729 = - _mid_17381;
    }
    DeRef(_key_17377);
    DeRef(_table_name_17378);
    return _9729;
    ;
}


object _41db_insert(object _key_17417, object _data_17418, object _table_name_17419)
{
    object _key_string_17420 = NOVALUE;
    object _data_string_17421 = NOVALUE;
    object _last_part_17422 = NOVALUE;
    object _remaining_17423 = NOVALUE;
    object _key_ptr_17424 = NOVALUE;
    object _data_ptr_17425 = NOVALUE;
    object _records_ptr_17426 = NOVALUE;
    object _nrecs_17427 = NOVALUE;
    object _current_block_17428 = NOVALUE;
    object _size_17429 = NOVALUE;
    object _new_size_17430 = NOVALUE;
    object _key_location_17431 = NOVALUE;
    object _new_block_17432 = NOVALUE;
    object _index_ptr_17433 = NOVALUE;
    object _new_index_ptr_17434 = NOVALUE;
    object _total_recs_17435 = NOVALUE;
    object _r_17436 = NOVALUE;
    object _blocks_17437 = NOVALUE;
    object _new_recs_17438 = NOVALUE;
    object _n_17439 = NOVALUE;
    object _put4_1__tmp_at79_17453 = NOVALUE;
    object _seek_1__tmp_at132_17459 = NOVALUE;
    object _seek_inlined_seek_at_132_17458 = NOVALUE;
    object _pos_inlined_seek_at_129_17457 = NOVALUE;
    object _seek_1__tmp_at174_17467 = NOVALUE;
    object _seek_inlined_seek_at_174_17466 = NOVALUE;
    object _pos_inlined_seek_at_171_17465 = NOVALUE;
    object _put4_1__tmp_at189_17469 = NOVALUE;
    object _seek_1__tmp_at317_17486 = NOVALUE;
    object _seek_inlined_seek_at_317_17485 = NOVALUE;
    object _pos_inlined_seek_at_314_17484 = NOVALUE;
    object _seek_1__tmp_at339_17490 = NOVALUE;
    object _seek_inlined_seek_at_339_17489 = NOVALUE;
    object _where_inlined_where_at_404_17499 = NOVALUE;
    object _seek_1__tmp_at448_17509 = NOVALUE;
    object _seek_inlined_seek_at_448_17508 = NOVALUE;
    object _pos_inlined_seek_at_445_17507 = NOVALUE;
    object _put4_1__tmp_at493_17518 = NOVALUE;
    object _x_inlined_put4_at_490_17517 = NOVALUE;
    object _seek_1__tmp_at530_17521 = NOVALUE;
    object _seek_inlined_seek_at_530_17520 = NOVALUE;
    object _put4_1__tmp_at551_17524 = NOVALUE;
    object _seek_1__tmp_at588_17529 = NOVALUE;
    object _seek_inlined_seek_at_588_17528 = NOVALUE;
    object _pos_inlined_seek_at_585_17527 = NOVALUE;
    object _seek_1__tmp_at690_17552 = NOVALUE;
    object _seek_inlined_seek_at_690_17551 = NOVALUE;
    object _pos_inlined_seek_at_687_17550 = NOVALUE;
    object _s_inlined_putn_at_751_17561 = NOVALUE;
    object _seek_1__tmp_at774_17564 = NOVALUE;
    object _seek_inlined_seek_at_774_17563 = NOVALUE;
    object _put4_1__tmp_at796_17568 = NOVALUE;
    object _x_inlined_put4_at_793_17567 = NOVALUE;
    object _seek_1__tmp_at833_17573 = NOVALUE;
    object _seek_inlined_seek_at_833_17572 = NOVALUE;
    object _pos_inlined_seek_at_830_17571 = NOVALUE;
    object _seek_1__tmp_at884_17583 = NOVALUE;
    object _seek_inlined_seek_at_884_17582 = NOVALUE;
    object _pos_inlined_seek_at_881_17581 = NOVALUE;
    object _put4_1__tmp_at899_17585 = NOVALUE;
    object _put4_1__tmp_at927_17587 = NOVALUE;
    object _seek_1__tmp_at980_17593 = NOVALUE;
    object _seek_inlined_seek_at_980_17592 = NOVALUE;
    object _pos_inlined_seek_at_977_17591 = NOVALUE;
    object _put4_1__tmp_at1001_17596 = NOVALUE;
    object _seek_1__tmp_at1038_17601 = NOVALUE;
    object _seek_inlined_seek_at_1038_17600 = NOVALUE;
    object _pos_inlined_seek_at_1035_17599 = NOVALUE;
    object _s_inlined_putn_at_1136_17619 = NOVALUE;
    object _seek_1__tmp_at1173_17624 = NOVALUE;
    object _seek_inlined_seek_at_1173_17623 = NOVALUE;
    object _pos_inlined_seek_at_1170_17622 = NOVALUE;
    object _put4_1__tmp_at1188_17626 = NOVALUE;
    object _9822 = NOVALUE;
    object _9821 = NOVALUE;
    object _9820 = NOVALUE;
    object _9819 = NOVALUE;
    object _9816 = NOVALUE;
    object _9815 = NOVALUE;
    object _9813 = NOVALUE;
    object _9811 = NOVALUE;
    object _9810 = NOVALUE;
    object _9808 = NOVALUE;
    object _9807 = NOVALUE;
    object _9805 = NOVALUE;
    object _9804 = NOVALUE;
    object _9802 = NOVALUE;
    object _9801 = NOVALUE;
    object _9800 = NOVALUE;
    object _9799 = NOVALUE;
    object _9798 = NOVALUE;
    object _9797 = NOVALUE;
    object _9796 = NOVALUE;
    object _9795 = NOVALUE;
    object _9794 = NOVALUE;
    object _9791 = NOVALUE;
    object _9790 = NOVALUE;
    object _9789 = NOVALUE;
    object _9788 = NOVALUE;
    object _9785 = NOVALUE;
    object _9782 = NOVALUE;
    object _9781 = NOVALUE;
    object _9780 = NOVALUE;
    object _9779 = NOVALUE;
    object _9777 = NOVALUE;
    object _9776 = NOVALUE;
    object _9774 = NOVALUE;
    object _9773 = NOVALUE;
    object _9771 = NOVALUE;
    object _9770 = NOVALUE;
    object _9769 = NOVALUE;
    object _9768 = NOVALUE;
    object _9767 = NOVALUE;
    object _9766 = NOVALUE;
    object _9765 = NOVALUE;
    object _9763 = NOVALUE;
    object _9760 = NOVALUE;
    object _9755 = NOVALUE;
    object _9754 = NOVALUE;
    object _9753 = NOVALUE;
    object _9751 = NOVALUE;
    object _9750 = NOVALUE;
    object _9749 = NOVALUE;
    object _9746 = NOVALUE;
    object _9744 = NOVALUE;
    object _9741 = NOVALUE;
    object _9740 = NOVALUE;
    object _9738 = NOVALUE;
    object _9737 = NOVALUE;
    object _9735 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2071		key_location = db_find_key(key, table_name) -- Let it set the current table if necessary*/
    Ref(_key_17417);
    RefDS(_table_name_17419);
    _0 = _key_location_17431;
    _key_location_17431 = _41db_find_key(_key_17417, _table_name_17419);
    DeRef(_0);

    /** eds.e:2073		if key_location > 0 then*/
    if (binary_op_a(LESSEQ, _key_location_17431, 0)){
        goto L1; // [10] 21
    }

    /** eds.e:2075			return DB_EXISTS_ALREADY*/
    DeRef(_key_17417);
    DeRefDS(_table_name_17419);
    DeRef(_key_string_17420);
    DeRef(_data_string_17421);
    DeRef(_last_part_17422);
    DeRef(_remaining_17423);
    DeRef(_key_ptr_17424);
    DeRef(_data_ptr_17425);
    DeRef(_records_ptr_17426);
    DeRef(_nrecs_17427);
    DeRef(_current_block_17428);
    DeRef(_size_17429);
    DeRef(_new_size_17430);
    DeRef(_key_location_17431);
    DeRef(_new_block_17432);
    DeRef(_index_ptr_17433);
    DeRef(_new_index_ptr_17434);
    DeRef(_total_recs_17435);
    return -2;
L1: 

    /** eds.e:2077		key_location = -key_location*/
    _0 = _key_location_17431;
    if (IS_ATOM_INT(_key_location_17431)) {
        if ((uintptr_t)_key_location_17431 == (uintptr_t)HIGH_BITS){
            _key_location_17431 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _key_location_17431 = - _key_location_17431;
        }
    }
    else {
        _key_location_17431 = unary_op(UMINUS, _key_location_17431);
    }
    DeRef(_0);

    /** eds.e:2079		data_string = compress(data)*/
    _0 = _data_string_17421;
    _data_string_17421 = _41compress(_data_17418);
    DeRef(_0);

    /** eds.e:2080		key_string  = compress(key)*/
    Ref(_key_17417);
    _0 = _key_string_17420;
    _key_string_17420 = _41compress(_key_17417);
    DeRef(_0);

    /** eds.e:2082		data_ptr = db_allocate(length(data_string))*/
    if (IS_SEQUENCE(_data_string_17421)){
            _9735 = SEQ_PTR(_data_string_17421)->length;
    }
    else {
        _9735 = 1;
    }
    _0 = _data_ptr_17425;
    _data_ptr_17425 = _41db_allocate(_9735);
    DeRef(_0);
    _9735 = NOVALUE;

    /** eds.e:2083		putn(data_string)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_15734, _data_string_17421); // DJP 

    /** eds.e:449	end procedure*/
    goto L2; // [62] 65
L2: 

    /** eds.e:2085		key_ptr = db_allocate(4+length(key_string))*/
    if (IS_SEQUENCE(_key_string_17420)){
            _9737 = SEQ_PTR(_key_string_17420)->length;
    }
    else {
        _9737 = 1;
    }
    _9738 = 4 + _9737;
    _9737 = NOVALUE;
    _0 = _key_ptr_17424;
    _key_ptr_17424 = _41db_allocate(_9738);
    DeRef(_0);
    _9738 = NOVALUE;

    /** eds.e:2086		put4(data_ptr)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_17425)) {
        *poke4_addr = (uint32_t)_data_ptr_17425;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_data_ptr_17425)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at79_17453);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at79_17453 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at79_17453); // DJP 

    /** eds.e:444	end procedure*/
    goto L3; // [101] 104
L3: 
    DeRefi(_put4_1__tmp_at79_17453);
    _put4_1__tmp_at79_17453 = NOVALUE;

    /** eds.e:2087		putn(key_string)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_15734, _key_string_17420); // DJP 

    /** eds.e:449	end procedure*/
    goto L4; // [117] 120
L4: 

    /** eds.e:2091		io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_41current_table_pos_15735)) {
        _9740 = _41current_table_pos_15735 + 4;
        if ((object)((uintptr_t)_9740 + (uintptr_t)HIGH_BITS) >= 0){
            _9740 = NewDouble((eudouble)_9740);
        }
    }
    else {
        _9740 = NewDouble(DBL_PTR(_41current_table_pos_15735)->dbl + (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_129_17457);
    _pos_inlined_seek_at_129_17457 = _9740;
    _9740 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_129_17457);
    DeRef(_seek_1__tmp_at132_17459);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_129_17457;
    _seek_1__tmp_at132_17459 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_132_17458 = machine(19, _seek_1__tmp_at132_17459);
    DeRef(_pos_inlined_seek_at_129_17457);
    _pos_inlined_seek_at_129_17457 = NOVALUE;
    DeRef(_seek_1__tmp_at132_17459);
    _seek_1__tmp_at132_17459 = NOVALUE;

    /** eds.e:2092		total_recs = get4()+1*/
    _9741 = _41get4();
    DeRef(_total_recs_17435);
    if (IS_ATOM_INT(_9741)) {
        _total_recs_17435 = _9741 + 1;
        if (_total_recs_17435 > MAXINT){
            _total_recs_17435 = NewDouble((eudouble)_total_recs_17435);
        }
    }
    else
    _total_recs_17435 = binary_op(PLUS, 1, _9741);
    DeRef(_9741);
    _9741 = NOVALUE;

    /** eds.e:2093		blocks = get4()*/
    _blocks_17437 = _41get4();
    if (!IS_ATOM_INT(_blocks_17437)) {
        _1 = (object)(DBL_PTR(_blocks_17437)->dbl);
        DeRefDS(_blocks_17437);
        _blocks_17437 = _1;
    }

    /** eds.e:2094		io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_41current_table_pos_15735)) {
        _9744 = _41current_table_pos_15735 + 4;
        if ((object)((uintptr_t)_9744 + (uintptr_t)HIGH_BITS) >= 0){
            _9744 = NewDouble((eudouble)_9744);
        }
    }
    else {
        _9744 = NewDouble(DBL_PTR(_41current_table_pos_15735)->dbl + (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_171_17465);
    _pos_inlined_seek_at_171_17465 = _9744;
    _9744 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_171_17465);
    DeRef(_seek_1__tmp_at174_17467);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_171_17465;
    _seek_1__tmp_at174_17467 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_174_17466 = machine(19, _seek_1__tmp_at174_17467);
    DeRef(_pos_inlined_seek_at_171_17465);
    _pos_inlined_seek_at_171_17465 = NOVALUE;
    DeRef(_seek_1__tmp_at174_17467);
    _seek_1__tmp_at174_17467 = NOVALUE;

    /** eds.e:2095		put4(total_recs)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_total_recs_17435)) {
        *poke4_addr = (uint32_t)_total_recs_17435;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_total_recs_17435)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at189_17469);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at189_17469 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at189_17469); // DJP 

    /** eds.e:444	end procedure*/
    goto L5; // [211] 214
L5: 
    DeRefi(_put4_1__tmp_at189_17469);
    _put4_1__tmp_at189_17469 = NOVALUE;

    /** eds.e:2097		n = length(key_pointers)*/
    if (IS_SEQUENCE(_41key_pointers_15741)){
            _n_17439 = SEQ_PTR(_41key_pointers_15741)->length;
    }
    else {
        _n_17439 = 1;
    }

    /** eds.e:2098		if key_location >= floor(n/2) then*/
    _9746 = _n_17439 >> 1;
    if (binary_op_a(LESS, _key_location_17431, _9746)){
        _9746 = NOVALUE;
        goto L6; // [229] 268
    }
    DeRef(_9746);
    _9746 = NOVALUE;

    /** eds.e:2100			key_pointers = append(key_pointers, 0)*/
    Append(&_41key_pointers_15741, _41key_pointers_15741, 0);

    /** eds.e:2102			key_pointers[key_location+1..n+1] = key_pointers[key_location..n]*/
    if (IS_ATOM_INT(_key_location_17431)) {
        _9749 = _key_location_17431 + 1;
        if (_9749 > MAXINT){
            _9749 = NewDouble((eudouble)_9749);
        }
    }
    else
    _9749 = binary_op(PLUS, 1, _key_location_17431);
    _9750 = _n_17439 + 1;
    rhs_slice_target = (object_ptr)&_9751;
    RHS_Slice(_41key_pointers_15741, _key_location_17431, _n_17439);
    assign_slice_seq = (s1_ptr *)&_41key_pointers_15741;
    AssignSlice(_9749, _9750, _9751);
    DeRef(_9749);
    _9749 = NOVALUE;
    _9750 = NOVALUE;
    DeRefDS(_9751);
    _9751 = NOVALUE;
    goto L7; // [265] 297
L6: 

    /** eds.e:2105			key_pointers = prepend(key_pointers, 0)*/
    Prepend(&_41key_pointers_15741, _41key_pointers_15741, 0);

    /** eds.e:2107			key_pointers[1..key_location-1] = key_pointers[2..key_location]*/
    if (IS_ATOM_INT(_key_location_17431)) {
        _9753 = _key_location_17431 - 1;
        if ((object)((uintptr_t)_9753 +(uintptr_t) HIGH_BITS) >= 0){
            _9753 = NewDouble((eudouble)_9753);
        }
    }
    else {
        _9753 = NewDouble(DBL_PTR(_key_location_17431)->dbl - (eudouble)1);
    }
    rhs_slice_target = (object_ptr)&_9754;
    RHS_Slice(_41key_pointers_15741, 2, _key_location_17431);
    assign_slice_seq = (s1_ptr *)&_41key_pointers_15741;
    AssignSlice(1, _9753, _9754);
    DeRef(_9753);
    _9753 = NOVALUE;
    DeRefDS(_9754);
    _9754 = NOVALUE;
L7: 

    /** eds.e:2109		key_pointers[key_location] = key_ptr*/
    Ref(_key_ptr_17424);
    _2 = (object)SEQ_PTR(_41key_pointers_15741);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _41key_pointers_15741 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_key_location_17431))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_key_location_17431)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _key_location_17431);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _key_ptr_17424;
    DeRef(_1);

    /** eds.e:2111		io:seek(current_db, current_table_pos+12) -- get after put - seek is necessary*/
    if (IS_ATOM_INT(_41current_table_pos_15735)) {
        _9755 = _41current_table_pos_15735 + 12;
        if ((object)((uintptr_t)_9755 + (uintptr_t)HIGH_BITS) >= 0){
            _9755 = NewDouble((eudouble)_9755);
        }
    }
    else {
        _9755 = NewDouble(DBL_PTR(_41current_table_pos_15735)->dbl + (eudouble)12);
    }
    DeRef(_pos_inlined_seek_at_314_17484);
    _pos_inlined_seek_at_314_17484 = _9755;
    _9755 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_314_17484);
    DeRef(_seek_1__tmp_at317_17486);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_314_17484;
    _seek_1__tmp_at317_17486 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_317_17485 = machine(19, _seek_1__tmp_at317_17486);
    DeRef(_pos_inlined_seek_at_314_17484);
    _pos_inlined_seek_at_314_17484 = NOVALUE;
    DeRef(_seek_1__tmp_at317_17486);
    _seek_1__tmp_at317_17486 = NOVALUE;

    /** eds.e:2112		index_ptr = get4()*/
    _0 = _index_ptr_17433;
    _index_ptr_17433 = _41get4();
    DeRef(_0);

    /** eds.e:2114		io:seek(current_db, index_ptr)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_index_ptr_17433);
    DeRef(_seek_1__tmp_at339_17490);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _index_ptr_17433;
    _seek_1__tmp_at339_17490 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_339_17489 = machine(19, _seek_1__tmp_at339_17490);
    DeRef(_seek_1__tmp_at339_17490);
    _seek_1__tmp_at339_17490 = NOVALUE;

    /** eds.e:2115		r = 0*/
    _r_17436 = 0;

    /** eds.e:2116		while TRUE do*/
L8: 

    /** eds.e:2117			nrecs = get4()*/
    _0 = _nrecs_17427;
    _nrecs_17427 = _41get4();
    DeRef(_0);

    /** eds.e:2118			records_ptr = get4()*/
    _0 = _records_ptr_17426;
    _records_ptr_17426 = _41get4();
    DeRef(_0);

    /** eds.e:2119			r += nrecs*/
    if (IS_ATOM_INT(_nrecs_17427)) {
        _r_17436 = _r_17436 + _nrecs_17427;
    }
    else {
        _r_17436 = NewDouble((eudouble)_r_17436 + DBL_PTR(_nrecs_17427)->dbl);
    }
    if (!IS_ATOM_INT(_r_17436)) {
        _1 = (object)(DBL_PTR(_r_17436)->dbl);
        DeRefDS(_r_17436);
        _r_17436 = _1;
    }

    /** eds.e:2120			if r + 1 >= key_location then*/
    _9760 = _r_17436 + 1;
    if (_9760 > MAXINT){
        _9760 = NewDouble((eudouble)_9760);
    }
    if (binary_op_a(LESS, _9760, _key_location_17431)){
        DeRef(_9760);
        _9760 = NOVALUE;
        goto L8; // [387] 363
    }
    DeRef(_9760);
    _9760 = NOVALUE;

    /** eds.e:2121				exit*/
    goto L9; // [393] 401

    /** eds.e:2123		end while*/
    goto L8; // [398] 363
L9: 

    /** eds.e:2125		current_block = io:where(current_db)-8*/

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_404_17499);
    _where_inlined_where_at_404_17499 = machine(20, _41current_db_15734);
    DeRef(_current_block_17428);
    if (IS_ATOM_INT(_where_inlined_where_at_404_17499)) {
        _current_block_17428 = _where_inlined_where_at_404_17499 - 8;
        if ((object)((uintptr_t)_current_block_17428 +(uintptr_t) HIGH_BITS) >= 0){
            _current_block_17428 = NewDouble((eudouble)_current_block_17428);
        }
    }
    else {
        _current_block_17428 = NewDouble(DBL_PTR(_where_inlined_where_at_404_17499)->dbl - (eudouble)8);
    }

    /** eds.e:2127		key_location -= (r-nrecs)*/
    if (IS_ATOM_INT(_nrecs_17427)) {
        _9763 = _r_17436 - _nrecs_17427;
        if ((object)((uintptr_t)_9763 +(uintptr_t) HIGH_BITS) >= 0){
            _9763 = NewDouble((eudouble)_9763);
        }
    }
    else {
        _9763 = NewDouble((eudouble)_r_17436 - DBL_PTR(_nrecs_17427)->dbl);
    }
    _0 = _key_location_17431;
    if (IS_ATOM_INT(_key_location_17431) && IS_ATOM_INT(_9763)) {
        _key_location_17431 = _key_location_17431 - _9763;
        if ((object)((uintptr_t)_key_location_17431 +(uintptr_t) HIGH_BITS) >= 0){
            _key_location_17431 = NewDouble((eudouble)_key_location_17431);
        }
    }
    else {
        if (IS_ATOM_INT(_key_location_17431)) {
            _key_location_17431 = NewDouble((eudouble)_key_location_17431 - DBL_PTR(_9763)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9763)) {
                _key_location_17431 = NewDouble(DBL_PTR(_key_location_17431)->dbl - (eudouble)_9763);
            }
            else
            _key_location_17431 = NewDouble(DBL_PTR(_key_location_17431)->dbl - DBL_PTR(_9763)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_9763);
    _9763 = NOVALUE;

    /** eds.e:2129		io:seek(current_db, records_ptr+4*(key_location-1))*/
    if (IS_ATOM_INT(_key_location_17431)) {
        _9765 = _key_location_17431 - 1;
        if ((object)((uintptr_t)_9765 +(uintptr_t) HIGH_BITS) >= 0){
            _9765 = NewDouble((eudouble)_9765);
        }
    }
    else {
        _9765 = NewDouble(DBL_PTR(_key_location_17431)->dbl - (eudouble)1);
    }
    if (IS_ATOM_INT(_9765)) {
        if (_9765 <= INT15 && _9765 >= -INT15){
            _9766 = 4 * _9765;
        }
        else{
            _9766 = NewDouble(4 * (eudouble)_9765);
        }
    }
    else {
        _9766 = NewDouble((eudouble)4 * DBL_PTR(_9765)->dbl);
    }
    DeRef(_9765);
    _9765 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_17426) && IS_ATOM_INT(_9766)) {
        _9767 = _records_ptr_17426 + _9766;
        if ((object)((uintptr_t)_9767 + (uintptr_t)HIGH_BITS) >= 0){
            _9767 = NewDouble((eudouble)_9767);
        }
    }
    else {
        if (IS_ATOM_INT(_records_ptr_17426)) {
            _9767 = NewDouble((eudouble)_records_ptr_17426 + DBL_PTR(_9766)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9766)) {
                _9767 = NewDouble(DBL_PTR(_records_ptr_17426)->dbl + (eudouble)_9766);
            }
            else
            _9767 = NewDouble(DBL_PTR(_records_ptr_17426)->dbl + DBL_PTR(_9766)->dbl);
        }
    }
    DeRef(_9766);
    _9766 = NOVALUE;
    DeRef(_pos_inlined_seek_at_445_17507);
    _pos_inlined_seek_at_445_17507 = _9767;
    _9767 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_445_17507);
    DeRef(_seek_1__tmp_at448_17509);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_445_17507;
    _seek_1__tmp_at448_17509 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_448_17508 = machine(19, _seek_1__tmp_at448_17509);
    DeRef(_pos_inlined_seek_at_445_17507);
    _pos_inlined_seek_at_445_17507 = NOVALUE;
    DeRef(_seek_1__tmp_at448_17509);
    _seek_1__tmp_at448_17509 = NOVALUE;

    /** eds.e:2130		for i = key_location to nrecs+1 do*/
    if (IS_ATOM_INT(_nrecs_17427)) {
        _9768 = _nrecs_17427 + 1;
        if (_9768 > MAXINT){
            _9768 = NewDouble((eudouble)_9768);
        }
    }
    else
    _9768 = binary_op(PLUS, 1, _nrecs_17427);
    {
        object _i_17511;
        Ref(_key_location_17431);
        _i_17511 = _key_location_17431;
LA: 
        if (binary_op_a(GREATER, _i_17511, _9768)){
            goto LB; // [468] 527
        }

        /** eds.e:2131			put4(key_pointers[i+r-nrecs])*/
        if (IS_ATOM_INT(_i_17511)) {
            _9769 = _i_17511 + _r_17436;
            if ((object)((uintptr_t)_9769 + (uintptr_t)HIGH_BITS) >= 0){
                _9769 = NewDouble((eudouble)_9769);
            }
        }
        else {
            _9769 = NewDouble(DBL_PTR(_i_17511)->dbl + (eudouble)_r_17436);
        }
        if (IS_ATOM_INT(_9769) && IS_ATOM_INT(_nrecs_17427)) {
            _9770 = _9769 - _nrecs_17427;
        }
        else {
            if (IS_ATOM_INT(_9769)) {
                _9770 = NewDouble((eudouble)_9769 - DBL_PTR(_nrecs_17427)->dbl);
            }
            else {
                if (IS_ATOM_INT(_nrecs_17427)) {
                    _9770 = NewDouble(DBL_PTR(_9769)->dbl - (eudouble)_nrecs_17427);
                }
                else
                _9770 = NewDouble(DBL_PTR(_9769)->dbl - DBL_PTR(_nrecs_17427)->dbl);
            }
        }
        DeRef(_9769);
        _9769 = NOVALUE;
        _2 = (object)SEQ_PTR(_41key_pointers_15741);
        if (!IS_ATOM_INT(_9770)){
            _9771 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_9770)->dbl));
        }
        else{
            _9771 = (object)*(((s1_ptr)_2)->base + _9770);
        }
        Ref(_9771);
        DeRef(_x_inlined_put4_at_490_17517);
        _x_inlined_put4_at_490_17517 = _9771;
        _9771 = NOVALUE;

        /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_41mem0_15776)){
            poke4_addr = (uint32_t *)_41mem0_15776;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_490_17517)) {
            *poke4_addr = (uint32_t)_x_inlined_put4_at_490_17517;
        }
        else if (IS_ATOM(_x_inlined_put4_at_490_17517)) {
            *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_490_17517)->dbl;
        }
        else {
            _1 = (object)SEQ_PTR(_x_inlined_put4_at_490_17517);
            _1 = (object)((s1_ptr)_1)->base;
            while (1) {
                _1 += sizeof(object);
                _2 = *((object *)_1);
                if (IS_ATOM_INT(_2)) {
                    *poke4_addr++ = (int32_t)_2;
                }
                else if (_2 == NOVALUE) {
                    break;
                }
                else {
                    *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
                }
            }
        }

        /** eds.e:443		puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at493_17518);
        _1 = (object)SEQ_PTR(_41memseq_16000);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _put4_1__tmp_at493_17518 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        EPuts(_41current_db_15734, _put4_1__tmp_at493_17518); // DJP 

        /** eds.e:444	end procedure*/
        goto LC; // [515] 518
LC: 
        DeRef(_x_inlined_put4_at_490_17517);
        _x_inlined_put4_at_490_17517 = NOVALUE;
        DeRefi(_put4_1__tmp_at493_17518);
        _put4_1__tmp_at493_17518 = NOVALUE;

        /** eds.e:2132		end for*/
        _0 = _i_17511;
        if (IS_ATOM_INT(_i_17511)) {
            _i_17511 = _i_17511 + 1;
            if ((object)((uintptr_t)_i_17511 +(uintptr_t) HIGH_BITS) >= 0){
                _i_17511 = NewDouble((eudouble)_i_17511);
            }
        }
        else {
            _i_17511 = binary_op_a(PLUS, _i_17511, 1);
        }
        DeRef(_0);
        goto LA; // [522] 475
LB: 
        ;
        DeRef(_i_17511);
    }

    /** eds.e:2135		io:seek(current_db, current_block)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_17428);
    DeRef(_seek_1__tmp_at530_17521);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _current_block_17428;
    _seek_1__tmp_at530_17521 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_530_17520 = machine(19, _seek_1__tmp_at530_17521);
    DeRef(_seek_1__tmp_at530_17521);
    _seek_1__tmp_at530_17521 = NOVALUE;

    /** eds.e:2136		nrecs += 1*/
    _0 = _nrecs_17427;
    if (IS_ATOM_INT(_nrecs_17427)) {
        _nrecs_17427 = _nrecs_17427 + 1;
        if (_nrecs_17427 > MAXINT){
            _nrecs_17427 = NewDouble((eudouble)_nrecs_17427);
        }
    }
    else
    _nrecs_17427 = binary_op(PLUS, 1, _nrecs_17427);
    DeRef(_0);

    /** eds.e:2137		put4(nrecs)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_nrecs_17427)) {
        *poke4_addr = (uint32_t)_nrecs_17427;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_nrecs_17427)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at551_17524);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at551_17524 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at551_17524); // DJP 

    /** eds.e:444	end procedure*/
    goto LD; // [573] 576
LD: 
    DeRefi(_put4_1__tmp_at551_17524);
    _put4_1__tmp_at551_17524 = NOVALUE;

    /** eds.e:2140		io:seek(current_db, records_ptr - 4)*/
    if (IS_ATOM_INT(_records_ptr_17426)) {
        _9773 = _records_ptr_17426 - 4;
        if ((object)((uintptr_t)_9773 +(uintptr_t) HIGH_BITS) >= 0){
            _9773 = NewDouble((eudouble)_9773);
        }
    }
    else {
        _9773 = NewDouble(DBL_PTR(_records_ptr_17426)->dbl - (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_585_17527);
    _pos_inlined_seek_at_585_17527 = _9773;
    _9773 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_585_17527);
    DeRef(_seek_1__tmp_at588_17529);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_585_17527;
    _seek_1__tmp_at588_17529 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_588_17528 = machine(19, _seek_1__tmp_at588_17529);
    DeRef(_pos_inlined_seek_at_585_17527);
    _pos_inlined_seek_at_585_17527 = NOVALUE;
    DeRef(_seek_1__tmp_at588_17529);
    _seek_1__tmp_at588_17529 = NOVALUE;

    /** eds.e:2141		size = get4() - 4*/
    _9774 = _41get4();
    DeRef(_size_17429);
    if (IS_ATOM_INT(_9774)) {
        _size_17429 = _9774 - 4;
        if ((object)((uintptr_t)_size_17429 +(uintptr_t) HIGH_BITS) >= 0){
            _size_17429 = NewDouble((eudouble)_size_17429);
        }
    }
    else {
        _size_17429 = binary_op(MINUS, _9774, 4);
    }
    DeRef(_9774);
    _9774 = NOVALUE;

    /** eds.e:2142		if nrecs*4 > size-4 then*/
    if (IS_ATOM_INT(_nrecs_17427)) {
        if (_nrecs_17427 == (short)_nrecs_17427){
            _9776 = _nrecs_17427 * 4;
        }
        else{
            _9776 = NewDouble(_nrecs_17427 * (eudouble)4);
        }
    }
    else {
        _9776 = NewDouble(DBL_PTR(_nrecs_17427)->dbl * (eudouble)4);
    }
    if (IS_ATOM_INT(_size_17429)) {
        _9777 = _size_17429 - 4;
        if ((object)((uintptr_t)_9777 +(uintptr_t) HIGH_BITS) >= 0){
            _9777 = NewDouble((eudouble)_9777);
        }
    }
    else {
        _9777 = NewDouble(DBL_PTR(_size_17429)->dbl - (eudouble)4);
    }
    if (binary_op_a(LESSEQ, _9776, _9777)){
        DeRef(_9776);
        _9776 = NOVALUE;
        DeRef(_9777);
        _9777 = NOVALUE;
        goto LE; // [621] 1217
    }
    DeRef(_9776);
    _9776 = NOVALUE;
    DeRef(_9777);
    _9777 = NOVALUE;

    /** eds.e:2150			new_size = 8 * (20 + floor(sqrt(1.5 * total_recs)))*/
    if (IS_ATOM_INT(_total_recs_17435)) {
        _9779 = NewDouble(DBL_PTR(_8465)->dbl * (eudouble)_total_recs_17435);
    }
    else
    _9779 = NewDouble(DBL_PTR(_8465)->dbl * DBL_PTR(_total_recs_17435)->dbl);
    _9780 = unary_op(SQRT, _9779);
    DeRefDS(_9779);
    _9779 = NOVALUE;
    _9781 = unary_op(FLOOR, _9780);
    DeRefDS(_9780);
    _9780 = NOVALUE;
    if (IS_ATOM_INT(_9781)) {
        _9782 = 20 + _9781;
        if ((object)((uintptr_t)_9782 + (uintptr_t)HIGH_BITS) >= 0){
            _9782 = NewDouble((eudouble)_9782);
        }
    }
    else {
        _9782 = binary_op(PLUS, 20, _9781);
    }
    DeRef(_9781);
    _9781 = NOVALUE;
    DeRef(_new_size_17430);
    if (IS_ATOM_INT(_9782)) {
        if (_9782 <= INT15 && _9782 >= -INT15){
            _new_size_17430 = 8 * _9782;
        }
        else{
            _new_size_17430 = NewDouble(8 * (eudouble)_9782);
        }
    }
    else {
        _new_size_17430 = binary_op(MULTIPLY, 8, _9782);
    }
    DeRef(_9782);
    _9782 = NOVALUE;

    /** eds.e:2152			new_recs = floor(new_size/8)*/
    if (IS_ATOM_INT(_new_size_17430)) {
        if (8 > 0 && _new_size_17430 >= 0) {
            _new_recs_17438 = _new_size_17430 / 8;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_new_size_17430 / (eudouble)8);
            _new_recs_17438 = (object)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _new_size_17430, 8);
        _new_recs_17438 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_new_recs_17438)) {
        _1 = (object)(DBL_PTR(_new_recs_17438)->dbl);
        DeRefDS(_new_recs_17438);
        _new_recs_17438 = _1;
    }

    /** eds.e:2153			if new_recs > floor(nrecs/2) then*/
    if (IS_ATOM_INT(_nrecs_17427)) {
        _9785 = _nrecs_17427 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs_17427, 2);
        _9785 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (binary_op_a(LESSEQ, _new_recs_17438, _9785)){
        DeRef(_9785);
        _9785 = NOVALUE;
        goto LF; // [659] 672
    }
    DeRef(_9785);
    _9785 = NOVALUE;

    /** eds.e:2154				new_recs = floor(nrecs/2)*/
    if (IS_ATOM_INT(_nrecs_17427)) {
        _new_recs_17438 = _nrecs_17427 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs_17427, 2);
        _new_recs_17438 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (!IS_ATOM_INT(_new_recs_17438)) {
        _1 = (object)(DBL_PTR(_new_recs_17438)->dbl);
        DeRefDS(_new_recs_17438);
        _new_recs_17438 = _1;
    }
LF: 

    /** eds.e:2158			io:seek(current_db, records_ptr + (nrecs-new_recs)*4)*/
    if (IS_ATOM_INT(_nrecs_17427)) {
        _9788 = _nrecs_17427 - _new_recs_17438;
        if ((object)((uintptr_t)_9788 +(uintptr_t) HIGH_BITS) >= 0){
            _9788 = NewDouble((eudouble)_9788);
        }
    }
    else {
        _9788 = NewDouble(DBL_PTR(_nrecs_17427)->dbl - (eudouble)_new_recs_17438);
    }
    if (IS_ATOM_INT(_9788)) {
        if (_9788 == (short)_9788){
            _9789 = _9788 * 4;
        }
        else{
            _9789 = NewDouble(_9788 * (eudouble)4);
        }
    }
    else {
        _9789 = NewDouble(DBL_PTR(_9788)->dbl * (eudouble)4);
    }
    DeRef(_9788);
    _9788 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_17426) && IS_ATOM_INT(_9789)) {
        _9790 = _records_ptr_17426 + _9789;
        if ((object)((uintptr_t)_9790 + (uintptr_t)HIGH_BITS) >= 0){
            _9790 = NewDouble((eudouble)_9790);
        }
    }
    else {
        if (IS_ATOM_INT(_records_ptr_17426)) {
            _9790 = NewDouble((eudouble)_records_ptr_17426 + DBL_PTR(_9789)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9789)) {
                _9790 = NewDouble(DBL_PTR(_records_ptr_17426)->dbl + (eudouble)_9789);
            }
            else
            _9790 = NewDouble(DBL_PTR(_records_ptr_17426)->dbl + DBL_PTR(_9789)->dbl);
        }
    }
    DeRef(_9789);
    _9789 = NOVALUE;
    DeRef(_pos_inlined_seek_at_687_17550);
    _pos_inlined_seek_at_687_17550 = _9790;
    _9790 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_687_17550);
    DeRef(_seek_1__tmp_at690_17552);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_687_17550;
    _seek_1__tmp_at690_17552 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_690_17551 = machine(19, _seek_1__tmp_at690_17552);
    DeRef(_pos_inlined_seek_at_687_17550);
    _pos_inlined_seek_at_687_17550 = NOVALUE;
    DeRef(_seek_1__tmp_at690_17552);
    _seek_1__tmp_at690_17552 = NOVALUE;

    /** eds.e:2159			last_part = io:get_bytes(current_db, new_recs*4)*/
    if (_new_recs_17438 == (short)_new_recs_17438){
        _9791 = _new_recs_17438 * 4;
    }
    else{
        _9791 = NewDouble(_new_recs_17438 * (eudouble)4);
    }
    _0 = _last_part_17422;
    _last_part_17422 = _17get_bytes(_41current_db_15734, _9791);
    DeRef(_0);
    _9791 = NOVALUE;

    /** eds.e:2160			new_block = db_allocate(new_size)*/
    Ref(_new_size_17430);
    _0 = _new_block_17432;
    _new_block_17432 = _41db_allocate(_new_size_17430);
    DeRef(_0);

    /** eds.e:2161			putn(last_part)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_15734, _last_part_17422); // DJP 

    /** eds.e:449	end procedure*/
    goto L10; // [736] 739
L10: 

    /** eds.e:2163			putn(repeat(0, new_size-length(last_part)))*/
    if (IS_SEQUENCE(_last_part_17422)){
            _9794 = SEQ_PTR(_last_part_17422)->length;
    }
    else {
        _9794 = 1;
    }
    if (IS_ATOM_INT(_new_size_17430)) {
        _9795 = _new_size_17430 - _9794;
    }
    else {
        _9795 = NewDouble(DBL_PTR(_new_size_17430)->dbl - (eudouble)_9794);
    }
    _9794 = NOVALUE;
    _9796 = Repeat(0, _9795);
    DeRef(_9795);
    _9795 = NOVALUE;
    DeRefi(_s_inlined_putn_at_751_17561);
    _s_inlined_putn_at_751_17561 = _9796;
    _9796 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_15734, _s_inlined_putn_at_751_17561); // DJP 

    /** eds.e:449	end procedure*/
    goto L11; // [766] 769
L11: 
    DeRefi(_s_inlined_putn_at_751_17561);
    _s_inlined_putn_at_751_17561 = NOVALUE;

    /** eds.e:2166			io:seek(current_db, current_block)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_17428);
    DeRef(_seek_1__tmp_at774_17564);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _current_block_17428;
    _seek_1__tmp_at774_17564 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_774_17563 = machine(19, _seek_1__tmp_at774_17564);
    DeRef(_seek_1__tmp_at774_17564);
    _seek_1__tmp_at774_17564 = NOVALUE;

    /** eds.e:2167			put4(nrecs-new_recs)*/
    if (IS_ATOM_INT(_nrecs_17427)) {
        _9797 = _nrecs_17427 - _new_recs_17438;
        if ((object)((uintptr_t)_9797 +(uintptr_t) HIGH_BITS) >= 0){
            _9797 = NewDouble((eudouble)_9797);
        }
    }
    else {
        _9797 = NewDouble(DBL_PTR(_nrecs_17427)->dbl - (eudouble)_new_recs_17438);
    }
    DeRef(_x_inlined_put4_at_793_17567);
    _x_inlined_put4_at_793_17567 = _9797;
    _9797 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_793_17567)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_793_17567;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_793_17567)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at796_17568);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at796_17568 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at796_17568); // DJP 

    /** eds.e:444	end procedure*/
    goto L12; // [818] 821
L12: 
    DeRef(_x_inlined_put4_at_793_17567);
    _x_inlined_put4_at_793_17567 = NOVALUE;
    DeRefi(_put4_1__tmp_at796_17568);
    _put4_1__tmp_at796_17568 = NOVALUE;

    /** eds.e:2170			io:seek(current_db, current_block+8)*/
    if (IS_ATOM_INT(_current_block_17428)) {
        _9798 = _current_block_17428 + 8;
        if ((object)((uintptr_t)_9798 + (uintptr_t)HIGH_BITS) >= 0){
            _9798 = NewDouble((eudouble)_9798);
        }
    }
    else {
        _9798 = NewDouble(DBL_PTR(_current_block_17428)->dbl + (eudouble)8);
    }
    DeRef(_pos_inlined_seek_at_830_17571);
    _pos_inlined_seek_at_830_17571 = _9798;
    _9798 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_830_17571);
    DeRef(_seek_1__tmp_at833_17573);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_830_17571;
    _seek_1__tmp_at833_17573 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_833_17572 = machine(19, _seek_1__tmp_at833_17573);
    DeRef(_pos_inlined_seek_at_830_17571);
    _pos_inlined_seek_at_830_17571 = NOVALUE;
    DeRef(_seek_1__tmp_at833_17573);
    _seek_1__tmp_at833_17573 = NOVALUE;

    /** eds.e:2171			remaining = io:get_bytes(current_db, index_ptr+blocks*8-(current_block+8))*/
    if (_blocks_17437 == (short)_blocks_17437){
        _9799 = _blocks_17437 * 8;
    }
    else{
        _9799 = NewDouble(_blocks_17437 * (eudouble)8);
    }
    if (IS_ATOM_INT(_index_ptr_17433) && IS_ATOM_INT(_9799)) {
        _9800 = _index_ptr_17433 + _9799;
        if ((object)((uintptr_t)_9800 + (uintptr_t)HIGH_BITS) >= 0){
            _9800 = NewDouble((eudouble)_9800);
        }
    }
    else {
        if (IS_ATOM_INT(_index_ptr_17433)) {
            _9800 = NewDouble((eudouble)_index_ptr_17433 + DBL_PTR(_9799)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9799)) {
                _9800 = NewDouble(DBL_PTR(_index_ptr_17433)->dbl + (eudouble)_9799);
            }
            else
            _9800 = NewDouble(DBL_PTR(_index_ptr_17433)->dbl + DBL_PTR(_9799)->dbl);
        }
    }
    DeRef(_9799);
    _9799 = NOVALUE;
    if (IS_ATOM_INT(_current_block_17428)) {
        _9801 = _current_block_17428 + 8;
        if ((object)((uintptr_t)_9801 + (uintptr_t)HIGH_BITS) >= 0){
            _9801 = NewDouble((eudouble)_9801);
        }
    }
    else {
        _9801 = NewDouble(DBL_PTR(_current_block_17428)->dbl + (eudouble)8);
    }
    if (IS_ATOM_INT(_9800) && IS_ATOM_INT(_9801)) {
        _9802 = _9800 - _9801;
        if ((object)((uintptr_t)_9802 +(uintptr_t) HIGH_BITS) >= 0){
            _9802 = NewDouble((eudouble)_9802);
        }
    }
    else {
        if (IS_ATOM_INT(_9800)) {
            _9802 = NewDouble((eudouble)_9800 - DBL_PTR(_9801)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9801)) {
                _9802 = NewDouble(DBL_PTR(_9800)->dbl - (eudouble)_9801);
            }
            else
            _9802 = NewDouble(DBL_PTR(_9800)->dbl - DBL_PTR(_9801)->dbl);
        }
    }
    DeRef(_9800);
    _9800 = NOVALUE;
    DeRef(_9801);
    _9801 = NOVALUE;
    _0 = _remaining_17423;
    _remaining_17423 = _17get_bytes(_41current_db_15734, _9802);
    DeRef(_0);
    _9802 = NOVALUE;

    /** eds.e:2172			io:seek(current_db, current_block+8)*/
    if (IS_ATOM_INT(_current_block_17428)) {
        _9804 = _current_block_17428 + 8;
        if ((object)((uintptr_t)_9804 + (uintptr_t)HIGH_BITS) >= 0){
            _9804 = NewDouble((eudouble)_9804);
        }
    }
    else {
        _9804 = NewDouble(DBL_PTR(_current_block_17428)->dbl + (eudouble)8);
    }
    DeRef(_pos_inlined_seek_at_881_17581);
    _pos_inlined_seek_at_881_17581 = _9804;
    _9804 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_881_17581);
    DeRef(_seek_1__tmp_at884_17583);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_881_17581;
    _seek_1__tmp_at884_17583 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_884_17582 = machine(19, _seek_1__tmp_at884_17583);
    DeRef(_pos_inlined_seek_at_881_17581);
    _pos_inlined_seek_at_881_17581 = NOVALUE;
    DeRef(_seek_1__tmp_at884_17583);
    _seek_1__tmp_at884_17583 = NOVALUE;

    /** eds.e:2173			put4(new_recs)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    *poke4_addr = (uint32_t)_new_recs_17438;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at899_17585);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at899_17585 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at899_17585); // DJP 

    /** eds.e:444	end procedure*/
    goto L13; // [921] 924
L13: 
    DeRefi(_put4_1__tmp_at899_17585);
    _put4_1__tmp_at899_17585 = NOVALUE;

    /** eds.e:2174			put4(new_block)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_new_block_17432)) {
        *poke4_addr = (uint32_t)_new_block_17432;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_new_block_17432)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at927_17587);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at927_17587 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at927_17587); // DJP 

    /** eds.e:444	end procedure*/
    goto L14; // [949] 952
L14: 
    DeRefi(_put4_1__tmp_at927_17587);
    _put4_1__tmp_at927_17587 = NOVALUE;

    /** eds.e:2175			putn(remaining)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_15734, _remaining_17423); // DJP 

    /** eds.e:449	end procedure*/
    goto L15; // [965] 968
L15: 

    /** eds.e:2176			io:seek(current_db, current_table_pos+8)*/
    if (IS_ATOM_INT(_41current_table_pos_15735)) {
        _9805 = _41current_table_pos_15735 + 8;
        if ((object)((uintptr_t)_9805 + (uintptr_t)HIGH_BITS) >= 0){
            _9805 = NewDouble((eudouble)_9805);
        }
    }
    else {
        _9805 = NewDouble(DBL_PTR(_41current_table_pos_15735)->dbl + (eudouble)8);
    }
    DeRef(_pos_inlined_seek_at_977_17591);
    _pos_inlined_seek_at_977_17591 = _9805;
    _9805 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_977_17591);
    DeRef(_seek_1__tmp_at980_17593);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_977_17591;
    _seek_1__tmp_at980_17593 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_980_17592 = machine(19, _seek_1__tmp_at980_17593);
    DeRef(_pos_inlined_seek_at_977_17591);
    _pos_inlined_seek_at_977_17591 = NOVALUE;
    DeRef(_seek_1__tmp_at980_17593);
    _seek_1__tmp_at980_17593 = NOVALUE;

    /** eds.e:2177			blocks += 1*/
    _blocks_17437 = _blocks_17437 + 1;

    /** eds.e:2178			put4(blocks)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    *poke4_addr = (uint32_t)_blocks_17437;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at1001_17596);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at1001_17596 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at1001_17596); // DJP 

    /** eds.e:444	end procedure*/
    goto L16; // [1023] 1026
L16: 
    DeRefi(_put4_1__tmp_at1001_17596);
    _put4_1__tmp_at1001_17596 = NOVALUE;

    /** eds.e:2180			io:seek(current_db, index_ptr-4)*/
    if (IS_ATOM_INT(_index_ptr_17433)) {
        _9807 = _index_ptr_17433 - 4;
        if ((object)((uintptr_t)_9807 +(uintptr_t) HIGH_BITS) >= 0){
            _9807 = NewDouble((eudouble)_9807);
        }
    }
    else {
        _9807 = NewDouble(DBL_PTR(_index_ptr_17433)->dbl - (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_1035_17599);
    _pos_inlined_seek_at_1035_17599 = _9807;
    _9807 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_1035_17599);
    DeRef(_seek_1__tmp_at1038_17601);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_1035_17599;
    _seek_1__tmp_at1038_17601 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1038_17600 = machine(19, _seek_1__tmp_at1038_17601);
    DeRef(_pos_inlined_seek_at_1035_17599);
    _pos_inlined_seek_at_1035_17599 = NOVALUE;
    DeRef(_seek_1__tmp_at1038_17601);
    _seek_1__tmp_at1038_17601 = NOVALUE;

    /** eds.e:2181			size = get4() - 4*/
    _9808 = _41get4();
    DeRef(_size_17429);
    if (IS_ATOM_INT(_9808)) {
        _size_17429 = _9808 - 4;
        if ((object)((uintptr_t)_size_17429 +(uintptr_t) HIGH_BITS) >= 0){
            _size_17429 = NewDouble((eudouble)_size_17429);
        }
    }
    else {
        _size_17429 = binary_op(MINUS, _9808, 4);
    }
    DeRef(_9808);
    _9808 = NOVALUE;

    /** eds.e:2182			if blocks*8 > size-8 then*/
    if (_blocks_17437 == (short)_blocks_17437){
        _9810 = _blocks_17437 * 8;
    }
    else{
        _9810 = NewDouble(_blocks_17437 * (eudouble)8);
    }
    if (IS_ATOM_INT(_size_17429)) {
        _9811 = _size_17429 - 8;
        if ((object)((uintptr_t)_9811 +(uintptr_t) HIGH_BITS) >= 0){
            _9811 = NewDouble((eudouble)_9811);
        }
    }
    else {
        _9811 = NewDouble(DBL_PTR(_size_17429)->dbl - (eudouble)8);
    }
    if (binary_op_a(LESSEQ, _9810, _9811)){
        DeRef(_9810);
        _9810 = NOVALUE;
        DeRef(_9811);
        _9811 = NOVALUE;
        goto L17; // [1071] 1216
    }
    DeRef(_9810);
    _9810 = NOVALUE;
    DeRef(_9811);
    _9811 = NOVALUE;

    /** eds.e:2184				remaining = io:get_bytes(current_db, blocks*8)*/
    if (_blocks_17437 == (short)_blocks_17437){
        _9813 = _blocks_17437 * 8;
    }
    else{
        _9813 = NewDouble(_blocks_17437 * (eudouble)8);
    }
    _0 = _remaining_17423;
    _remaining_17423 = _17get_bytes(_41current_db_15734, _9813);
    DeRef(_0);
    _9813 = NOVALUE;

    /** eds.e:2185				new_size = floor(size + size/2)*/
    if (IS_ATOM_INT(_size_17429)) {
        if (_size_17429 & 1) {
            _9815 = NewDouble((_size_17429 >> 1) + 0.5);
        }
        else
        _9815 = _size_17429 >> 1;
    }
    else {
        _9815 = binary_op(DIVIDE, _size_17429, 2);
    }
    if (IS_ATOM_INT(_size_17429) && IS_ATOM_INT(_9815)) {
        _9816 = _size_17429 + _9815;
        if ((object)((uintptr_t)_9816 + (uintptr_t)HIGH_BITS) >= 0){
            _9816 = NewDouble((eudouble)_9816);
        }
    }
    else {
        if (IS_ATOM_INT(_size_17429)) {
            _9816 = NewDouble((eudouble)_size_17429 + DBL_PTR(_9815)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9815)) {
                _9816 = NewDouble(DBL_PTR(_size_17429)->dbl + (eudouble)_9815);
            }
            else
            _9816 = NewDouble(DBL_PTR(_size_17429)->dbl + DBL_PTR(_9815)->dbl);
        }
    }
    DeRef(_9815);
    _9815 = NOVALUE;
    DeRef(_new_size_17430);
    if (IS_ATOM_INT(_9816))
    _new_size_17430 = e_floor(_9816);
    else
    _new_size_17430 = unary_op(FLOOR, _9816);
    DeRef(_9816);
    _9816 = NOVALUE;

    /** eds.e:2186				new_index_ptr = db_allocate(new_size)*/
    Ref(_new_size_17430);
    _0 = _new_index_ptr_17434;
    _new_index_ptr_17434 = _41db_allocate(_new_size_17430);
    DeRef(_0);

    /** eds.e:2187				putn(remaining)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_15734, _remaining_17423); // DJP 

    /** eds.e:449	end procedure*/
    goto L18; // [1120] 1123
L18: 

    /** eds.e:2188				putn(repeat(0, new_size-blocks*8))*/
    if (_blocks_17437 == (short)_blocks_17437){
        _9819 = _blocks_17437 * 8;
    }
    else{
        _9819 = NewDouble(_blocks_17437 * (eudouble)8);
    }
    if (IS_ATOM_INT(_new_size_17430) && IS_ATOM_INT(_9819)) {
        _9820 = _new_size_17430 - _9819;
    }
    else {
        if (IS_ATOM_INT(_new_size_17430)) {
            _9820 = NewDouble((eudouble)_new_size_17430 - DBL_PTR(_9819)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9819)) {
                _9820 = NewDouble(DBL_PTR(_new_size_17430)->dbl - (eudouble)_9819);
            }
            else
            _9820 = NewDouble(DBL_PTR(_new_size_17430)->dbl - DBL_PTR(_9819)->dbl);
        }
    }
    DeRef(_9819);
    _9819 = NOVALUE;
    _9821 = Repeat(0, _9820);
    DeRef(_9820);
    _9820 = NOVALUE;
    DeRefi(_s_inlined_putn_at_1136_17619);
    _s_inlined_putn_at_1136_17619 = _9821;
    _9821 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_15734, _s_inlined_putn_at_1136_17619); // DJP 

    /** eds.e:449	end procedure*/
    goto L19; // [1151] 1154
L19: 
    DeRefi(_s_inlined_putn_at_1136_17619);
    _s_inlined_putn_at_1136_17619 = NOVALUE;

    /** eds.e:2189				db_free(index_ptr)*/
    Ref(_index_ptr_17433);
    _41db_free(_index_ptr_17433);

    /** eds.e:2190				io:seek(current_db, current_table_pos+12)*/
    if (IS_ATOM_INT(_41current_table_pos_15735)) {
        _9822 = _41current_table_pos_15735 + 12;
        if ((object)((uintptr_t)_9822 + (uintptr_t)HIGH_BITS) >= 0){
            _9822 = NewDouble((eudouble)_9822);
        }
    }
    else {
        _9822 = NewDouble(DBL_PTR(_41current_table_pos_15735)->dbl + (eudouble)12);
    }
    DeRef(_pos_inlined_seek_at_1170_17622);
    _pos_inlined_seek_at_1170_17622 = _9822;
    _9822 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_1170_17622);
    DeRef(_seek_1__tmp_at1173_17624);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_1170_17622;
    _seek_1__tmp_at1173_17624 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1173_17623 = machine(19, _seek_1__tmp_at1173_17624);
    DeRef(_pos_inlined_seek_at_1170_17622);
    _pos_inlined_seek_at_1170_17622 = NOVALUE;
    DeRef(_seek_1__tmp_at1173_17624);
    _seek_1__tmp_at1173_17624 = NOVALUE;

    /** eds.e:2191				put4(new_index_ptr)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_new_index_ptr_17434)) {
        *poke4_addr = (uint32_t)_new_index_ptr_17434;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_new_index_ptr_17434)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at1188_17626);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at1188_17626 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at1188_17626); // DJP 

    /** eds.e:444	end procedure*/
    goto L1A; // [1210] 1213
L1A: 
    DeRefi(_put4_1__tmp_at1188_17626);
    _put4_1__tmp_at1188_17626 = NOVALUE;
L17: 
LE: 

    /** eds.e:2194		return DB_OK*/
    DeRef(_key_17417);
    DeRef(_table_name_17419);
    DeRef(_key_string_17420);
    DeRef(_data_string_17421);
    DeRef(_last_part_17422);
    DeRef(_remaining_17423);
    DeRef(_key_ptr_17424);
    DeRef(_data_ptr_17425);
    DeRef(_records_ptr_17426);
    DeRef(_nrecs_17427);
    DeRef(_current_block_17428);
    DeRef(_size_17429);
    DeRef(_new_size_17430);
    DeRef(_key_location_17431);
    DeRef(_new_block_17432);
    DeRef(_index_ptr_17433);
    DeRef(_new_index_ptr_17434);
    DeRef(_total_recs_17435);
    DeRef(_9768);
    _9768 = NOVALUE;
    DeRef(_9770);
    _9770 = NOVALUE;
    return 0;
    ;
}


void _41db_replace_data(object _key_location_17761, object _data_17762, object _table_name_17763)
{
    object _9896 = NOVALUE;
    object _9895 = NOVALUE;
    object _9894 = NOVALUE;
    object _9893 = NOVALUE;
    object _9891 = NOVALUE;
    object _9890 = NOVALUE;
    object _9888 = NOVALUE;
    object _9885 = NOVALUE;
    object _9883 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2323		if not equal(table_name, current_table_name) then*/
    if (_table_name_17763 == _41current_table_name_15736)
    _9883 = 1;
    else if (IS_ATOM_INT(_table_name_17763) && IS_ATOM_INT(_41current_table_name_15736))
    _9883 = 0;
    else
    _9883 = (compare(_table_name_17763, _41current_table_name_15736) == 0);
    if (_9883 != 0)
    goto L1; // [11] 45
    _9883 = NOVALUE;

    /** eds.e:2324			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_17763);
    _9885 = _41db_select_table(_table_name_17763);
    if (binary_op_a(EQUALS, _9885, 0)){
        DeRef(_9885);
        _9885 = NOVALUE;
        goto L2; // [20] 44
    }
    DeRef(_9885);
    _9885 = NOVALUE;

    /** eds.e:2325				fatal(NO_TABLE, "invalid table name given", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _key_location_17761;
    ((intptr_t*)_2)[2] = _data_17762;
    RefDS(_table_name_17763);
    ((intptr_t*)_2)[3] = _table_name_17763;
    _9888 = MAKE_SEQ(_1);
    RefDS(_9710);
    RefDS(_9887);
    _41fatal(903, _9710, _9887, _9888);
    _9888 = NOVALUE;

    /** eds.e:2326				return*/
    DeRefDS(_table_name_17763);
    return;
L2: 
L1: 

    /** eds.e:2330		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _41current_table_pos_15735, -1)){
        goto L3; // [49] 73
    }

    /** eds.e:2331			fatal(NO_TABLE, "no table selected", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _key_location_17761;
    ((intptr_t*)_2)[2] = _data_17762;
    Ref(_table_name_17763);
    ((intptr_t*)_2)[3] = _table_name_17763;
    _9890 = MAKE_SEQ(_1);
    RefDS(_9714);
    RefDS(_9887);
    _41fatal(903, _9714, _9887, _9890);
    _9890 = NOVALUE;

    /** eds.e:2332			return*/
    DeRef(_table_name_17763);
    return;
L3: 

    /** eds.e:2334		if key_location < 1 or key_location > length(key_pointers) then*/
    _9891 = (_key_location_17761 < 1);
    if (_9891 != 0) {
        goto L4; // [79] 97
    }
    if (IS_SEQUENCE(_41key_pointers_15741)){
            _9893 = SEQ_PTR(_41key_pointers_15741)->length;
    }
    else {
        _9893 = 1;
    }
    _9894 = (_key_location_17761 > _9893);
    _9893 = NOVALUE;
    if (_9894 == 0)
    {
        DeRef(_9894);
        _9894 = NOVALUE;
        goto L5; // [93] 117
    }
    else{
        DeRef(_9894);
        _9894 = NOVALUE;
    }
L4: 

    /** eds.e:2335			fatal(BAD_RECNO, "bad record number", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _key_location_17761;
    ((intptr_t*)_2)[2] = _data_17762;
    Ref(_table_name_17763);
    ((intptr_t*)_2)[3] = _table_name_17763;
    _9895 = MAKE_SEQ(_1);
    RefDS(_9835);
    RefDS(_9887);
    _41fatal(905, _9835, _9887, _9895);
    _9895 = NOVALUE;

    /** eds.e:2336			return*/
    DeRef(_table_name_17763);
    DeRef(_9891);
    _9891 = NOVALUE;
    return;
L5: 

    /** eds.e:2338		db_replace_recid(key_pointers[key_location], data)*/
    _2 = (object)SEQ_PTR(_41key_pointers_15741);
    _9896 = (object)*(((s1_ptr)_2)->base + _key_location_17761);
    Ref(_9896);
    _41db_replace_recid(_9896, _data_17762);
    _9896 = NOVALUE;

    /** eds.e:2339	end procedure*/
    DeRef(_table_name_17763);
    DeRef(_9891);
    _9891 = NOVALUE;
    return;
    ;
}


object _41db_table_size(object _table_name_17785)
{
    object _9905 = NOVALUE;
    object _9904 = NOVALUE;
    object _9902 = NOVALUE;
    object _9899 = NOVALUE;
    object _9897 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2369		if not equal(table_name, current_table_name) then*/
    if (_table_name_17785 == _41current_table_name_15736)
    _9897 = 1;
    else if (IS_ATOM_INT(_table_name_17785) && IS_ATOM_INT(_41current_table_name_15736))
    _9897 = 0;
    else
    _9897 = (compare(_table_name_17785, _41current_table_name_15736) == 0);
    if (_9897 != 0)
    goto L1; // [9] 42
    _9897 = NOVALUE;

    /** eds.e:2370			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_17785);
    _9899 = _41db_select_table(_table_name_17785);
    if (binary_op_a(EQUALS, _9899, 0)){
        DeRef(_9899);
        _9899 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_9899);
    _9899 = NOVALUE;

    /** eds.e:2371				fatal(NO_TABLE, "invalid table name given", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_table_name_17785);
    ((intptr_t*)_2)[1] = _table_name_17785;
    _9902 = MAKE_SEQ(_1);
    RefDS(_9710);
    RefDS(_9901);
    _41fatal(903, _9710, _9901, _9902);
    _9902 = NOVALUE;

    /** eds.e:2372				return -1*/
    DeRefDS(_table_name_17785);
    return -1;
L2: 
L1: 

    /** eds.e:2376		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _41current_table_pos_15735, -1)){
        goto L3; // [46] 69
    }

    /** eds.e:2377			fatal(NO_TABLE, "no table selected", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_table_name_17785);
    ((intptr_t*)_2)[1] = _table_name_17785;
    _9904 = MAKE_SEQ(_1);
    RefDS(_9714);
    RefDS(_9901);
    _41fatal(903, _9714, _9901, _9904);
    _9904 = NOVALUE;

    /** eds.e:2378			return -1*/
    DeRef(_table_name_17785);
    return -1;
L3: 

    /** eds.e:2380		return length(key_pointers)*/
    if (IS_SEQUENCE(_41key_pointers_15741)){
            _9905 = SEQ_PTR(_41key_pointers_15741)->length;
    }
    else {
        _9905 = 1;
    }
    DeRef(_table_name_17785);
    return _9905;
    ;
}


object _41db_record_data(object _key_location_17800, object _table_name_17801)
{
    object _data_ptr_17802 = NOVALUE;
    object _data_value_17803 = NOVALUE;
    object _seek_1__tmp_at126_17825 = NOVALUE;
    object _seek_inlined_seek_at_126_17824 = NOVALUE;
    object _pos_inlined_seek_at_123_17823 = NOVALUE;
    object _seek_1__tmp_at164_17832 = NOVALUE;
    object _seek_inlined_seek_at_164_17831 = NOVALUE;
    object _9920 = NOVALUE;
    object _9919 = NOVALUE;
    object _9918 = NOVALUE;
    object _9917 = NOVALUE;
    object _9916 = NOVALUE;
    object _9914 = NOVALUE;
    object _9913 = NOVALUE;
    object _9911 = NOVALUE;
    object _9908 = NOVALUE;
    object _9906 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_17800)) {
        _1 = (object)(DBL_PTR(_key_location_17800)->dbl);
        DeRefDS(_key_location_17800);
        _key_location_17800 = _1;
    }

    /** eds.e:2417		if not equal(table_name, current_table_name) then*/
    if (_table_name_17801 == _41current_table_name_15736)
    _9906 = 1;
    else if (IS_ATOM_INT(_table_name_17801) && IS_ATOM_INT(_41current_table_name_15736))
    _9906 = 0;
    else
    _9906 = (compare(_table_name_17801, _41current_table_name_15736) == 0);
    if (_9906 != 0)
    goto L1; // [11] 44
    _9906 = NOVALUE;

    /** eds.e:2418			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_17801);
    _9908 = _41db_select_table(_table_name_17801);
    if (binary_op_a(EQUALS, _9908, 0)){
        DeRef(_9908);
        _9908 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_9908);
    _9908 = NOVALUE;

    /** eds.e:2419				fatal(NO_TABLE, "invalid table name given", "db_record_data", {key_location, table_name})*/
    RefDS(_table_name_17801);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_17800;
    ((intptr_t *)_2)[2] = _table_name_17801;
    _9911 = MAKE_SEQ(_1);
    RefDS(_9710);
    RefDS(_9910);
    _41fatal(903, _9710, _9910, _9911);
    _9911 = NOVALUE;

    /** eds.e:2420				return -1*/
    DeRefDS(_table_name_17801);
    DeRef(_data_ptr_17802);
    DeRef(_data_value_17803);
    return -1;
L2: 
L1: 

    /** eds.e:2424		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _41current_table_pos_15735, -1)){
        goto L3; // [48] 71
    }

    /** eds.e:2425			fatal(NO_TABLE, "no table selected", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_17801);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_17800;
    ((intptr_t *)_2)[2] = _table_name_17801;
    _9913 = MAKE_SEQ(_1);
    RefDS(_9714);
    RefDS(_9910);
    _41fatal(903, _9714, _9910, _9913);
    _9913 = NOVALUE;

    /** eds.e:2426			return -1*/
    DeRef(_table_name_17801);
    DeRef(_data_ptr_17802);
    DeRef(_data_value_17803);
    return -1;
L3: 

    /** eds.e:2428		if key_location < 1 or key_location > length(key_pointers) then*/
    _9914 = (_key_location_17800 < 1);
    if (_9914 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_41key_pointers_15741)){
            _9916 = SEQ_PTR(_41key_pointers_15741)->length;
    }
    else {
        _9916 = 1;
    }
    _9917 = (_key_location_17800 > _9916);
    _9916 = NOVALUE;
    if (_9917 == 0)
    {
        DeRef(_9917);
        _9917 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_9917);
        _9917 = NOVALUE;
    }
L4: 

    /** eds.e:2429			fatal(BAD_RECNO, "bad record number", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_17801);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_17800;
    ((intptr_t *)_2)[2] = _table_name_17801;
    _9918 = MAKE_SEQ(_1);
    RefDS(_9835);
    RefDS(_9910);
    _41fatal(905, _9835, _9910, _9918);
    _9918 = NOVALUE;

    /** eds.e:2430			return -1*/
    DeRef(_table_name_17801);
    DeRef(_data_ptr_17802);
    DeRef(_data_value_17803);
    DeRef(_9914);
    _9914 = NOVALUE;
    return -1;
L5: 

    /** eds.e:2433		io:seek(current_db, key_pointers[key_location])*/
    _2 = (object)SEQ_PTR(_41key_pointers_15741);
    _9919 = (object)*(((s1_ptr)_2)->base + _key_location_17800);
    Ref(_9919);
    DeRef(_pos_inlined_seek_at_123_17823);
    _pos_inlined_seek_at_123_17823 = _9919;
    _9919 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_123_17823);
    DeRef(_seek_1__tmp_at126_17825);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_123_17823;
    _seek_1__tmp_at126_17825 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_126_17824 = machine(19, _seek_1__tmp_at126_17825);
    DeRef(_pos_inlined_seek_at_123_17823);
    _pos_inlined_seek_at_123_17823 = NOVALUE;
    DeRef(_seek_1__tmp_at126_17825);
    _seek_1__tmp_at126_17825 = NOVALUE;

    /** eds.e:2434		if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_41vLastErrors_15758)){
            _9920 = SEQ_PTR(_41vLastErrors_15758)->length;
    }
    else {
        _9920 = 1;
    }
    if (_9920 <= 0)
    goto L6; // [147] 156
    DeRef(_table_name_17801);
    DeRef(_data_ptr_17802);
    DeRef(_data_value_17803);
    DeRef(_9914);
    _9914 = NOVALUE;
    return -1;
L6: 

    /** eds.e:2435		data_ptr = get4()*/
    _0 = _data_ptr_17802;
    _data_ptr_17802 = _41get4();
    DeRef(_0);

    /** eds.e:2436		io:seek(current_db, data_ptr)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_data_ptr_17802);
    DeRef(_seek_1__tmp_at164_17832);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_15734;
    ((intptr_t *)_2)[2] = _data_ptr_17802;
    _seek_1__tmp_at164_17832 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_164_17831 = machine(19, _seek_1__tmp_at164_17832);
    DeRef(_seek_1__tmp_at164_17832);
    _seek_1__tmp_at164_17832 = NOVALUE;

    /** eds.e:2437		data_value = decompress(0)*/
    _0 = _data_value_17803;
    _data_value_17803 = _41decompress(0);
    DeRef(_0);

    /** eds.e:2439		return data_value*/
    DeRef(_table_name_17801);
    DeRef(_data_ptr_17802);
    DeRef(_9914);
    _9914 = NOVALUE;
    return _data_value_17803;
    ;
}


object _41db_fetch_record(object _key_17836, object _table_name_17837)
{
    object _pos_17838 = NOVALUE;
    object _9926 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2481		pos = db_find_key(key, table_name)*/
    Ref(_key_17836);
    RefDS(_table_name_17837);
    _pos_17838 = _41db_find_key(_key_17836, _table_name_17837);
    if (!IS_ATOM_INT(_pos_17838)) {
        _1 = (object)(DBL_PTR(_pos_17838)->dbl);
        DeRefDS(_pos_17838);
        _pos_17838 = _1;
    }

    /** eds.e:2482		if pos > 0 then*/
    if (_pos_17838 <= 0)
    goto L1; // [12] 30

    /** eds.e:2483			return db_record_data(pos, table_name)*/
    RefDS(_table_name_17837);
    _9926 = _41db_record_data(_pos_17838, _table_name_17837);
    DeRef(_key_17836);
    DeRefDS(_table_name_17837);
    return _9926;
    goto L2; // [27] 37
L1: 

    /** eds.e:2485			return pos*/
    DeRef(_key_17836);
    DeRef(_table_name_17837);
    DeRef(_9926);
    _9926 = NOVALUE;
    return _pos_17838;
L2: 
    ;
}


object _41db_record_key(object _key_location_17846, object _table_name_17847)
{
    object _9941 = NOVALUE;
    object _9940 = NOVALUE;
    object _9939 = NOVALUE;
    object _9938 = NOVALUE;
    object _9937 = NOVALUE;
    object _9935 = NOVALUE;
    object _9934 = NOVALUE;
    object _9932 = NOVALUE;
    object _9929 = NOVALUE;
    object _9927 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_17846)) {
        _1 = (object)(DBL_PTR(_key_location_17846)->dbl);
        DeRefDS(_key_location_17846);
        _key_location_17846 = _1;
    }

    /** eds.e:2519		if not equal(table_name, current_table_name) then*/
    if (_table_name_17847 == _41current_table_name_15736)
    _9927 = 1;
    else if (IS_ATOM_INT(_table_name_17847) && IS_ATOM_INT(_41current_table_name_15736))
    _9927 = 0;
    else
    _9927 = (compare(_table_name_17847, _41current_table_name_15736) == 0);
    if (_9927 != 0)
    goto L1; // [11] 44
    _9927 = NOVALUE;

    /** eds.e:2520			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_17847);
    _9929 = _41db_select_table(_table_name_17847);
    if (binary_op_a(EQUALS, _9929, 0)){
        DeRef(_9929);
        _9929 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_9929);
    _9929 = NOVALUE;

    /** eds.e:2521				fatal(NO_TABLE, "invalid table name given", "db_record_key", {key_location, table_name})*/
    RefDS(_table_name_17847);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_17846;
    ((intptr_t *)_2)[2] = _table_name_17847;
    _9932 = MAKE_SEQ(_1);
    RefDS(_9710);
    RefDS(_9931);
    _41fatal(903, _9710, _9931, _9932);
    _9932 = NOVALUE;

    /** eds.e:2522				return -1*/
    DeRefDS(_table_name_17847);
    return -1;
L2: 
L1: 

    /** eds.e:2526		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _41current_table_pos_15735, -1)){
        goto L3; // [48] 71
    }

    /** eds.e:2527			fatal(NO_TABLE, "no table selected", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_17847);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_17846;
    ((intptr_t *)_2)[2] = _table_name_17847;
    _9934 = MAKE_SEQ(_1);
    RefDS(_9714);
    RefDS(_9931);
    _41fatal(903, _9714, _9931, _9934);
    _9934 = NOVALUE;

    /** eds.e:2528			return -1*/
    DeRef(_table_name_17847);
    return -1;
L3: 

    /** eds.e:2530		if key_location < 1 or key_location > length(key_pointers) then*/
    _9935 = (_key_location_17846 < 1);
    if (_9935 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_41key_pointers_15741)){
            _9937 = SEQ_PTR(_41key_pointers_15741)->length;
    }
    else {
        _9937 = 1;
    }
    _9938 = (_key_location_17846 > _9937);
    _9937 = NOVALUE;
    if (_9938 == 0)
    {
        DeRef(_9938);
        _9938 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_9938);
        _9938 = NOVALUE;
    }
L4: 

    /** eds.e:2531			fatal(BAD_RECNO, "bad record number", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_17847);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_17846;
    ((intptr_t *)_2)[2] = _table_name_17847;
    _9939 = MAKE_SEQ(_1);
    RefDS(_9835);
    RefDS(_9931);
    _41fatal(905, _9835, _9931, _9939);
    _9939 = NOVALUE;

    /** eds.e:2532			return -1*/
    DeRef(_table_name_17847);
    DeRef(_9935);
    _9935 = NOVALUE;
    return -1;
L5: 

    /** eds.e:2534		return key_value(key_pointers[key_location])*/
    _2 = (object)SEQ_PTR(_41key_pointers_15741);
    _9940 = (object)*(((s1_ptr)_2)->base + _key_location_17846);
    Ref(_9940);
    _9941 = _41key_value(_9940);
    _9940 = NOVALUE;
    DeRef(_table_name_17847);
    DeRef(_9935);
    _9935 = NOVALUE;
    return _9941;
    ;
}


void _41db_replace_recid(object _recid_17959, object _data_17960)
{
    object _old_size_17961 = NOVALUE;
    object _new_size_17962 = NOVALUE;
    object _data_ptr_17963 = NOVALUE;
    object _data_string_17964 = NOVALUE;
    object _put4_1__tmp_at111_17984 = NOVALUE;
    object _10039 = NOVALUE;
    object _10038 = NOVALUE;
    object _10037 = NOVALUE;
    object _10036 = NOVALUE;
    object _10035 = NOVALUE;
    object _10007 = NOVALUE;
    object _10005 = NOVALUE;
    object _10004 = NOVALUE;
    object _10003 = NOVALUE;
    object _10002 = NOVALUE;
    object _10001 = NOVALUE;
    object _9997 = NOVALUE;
    object _9996 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_recid_17959)) {
        _1 = (object)(DBL_PTR(_recid_17959)->dbl);
        DeRefDS(_recid_17959);
        _recid_17959 = _1;
    }

    /** eds.e:2760		seek(current_db, recid)*/
    _10039 = _17seek(_41current_db_15734, _recid_17959);
    DeRef(_10039);
    _10039 = NOVALUE;

    /** eds.e:2761		data_ptr = get4()*/
    _0 = _data_ptr_17963;
    _data_ptr_17963 = _41get4();
    DeRef(_0);

    /** eds.e:2762		seek(current_db, data_ptr-4)*/
    if (IS_ATOM_INT(_data_ptr_17963)) {
        _9996 = _data_ptr_17963 - 4;
        if ((object)((uintptr_t)_9996 +(uintptr_t) HIGH_BITS) >= 0){
            _9996 = NewDouble((eudouble)_9996);
        }
    }
    else {
        _9996 = NewDouble(DBL_PTR(_data_ptr_17963)->dbl - (eudouble)4);
    }
    _10038 = _17seek(_41current_db_15734, _9996);
    _9996 = NOVALUE;
    DeRef(_10038);
    _10038 = NOVALUE;

    /** eds.e:2763		old_size = get4()-4*/
    _9997 = _41get4();
    DeRef(_old_size_17961);
    if (IS_ATOM_INT(_9997)) {
        _old_size_17961 = _9997 - 4;
        if ((object)((uintptr_t)_old_size_17961 +(uintptr_t) HIGH_BITS) >= 0){
            _old_size_17961 = NewDouble((eudouble)_old_size_17961);
        }
    }
    else {
        _old_size_17961 = binary_op(MINUS, _9997, 4);
    }
    DeRef(_9997);
    _9997 = NOVALUE;

    /** eds.e:2764		data_string = compress(data)*/
    _0 = _data_string_17964;
    _data_string_17964 = _41compress(_data_17960);
    DeRef(_0);

    /** eds.e:2765		new_size = length(data_string)*/
    if (IS_SEQUENCE(_data_string_17964)){
            _new_size_17962 = SEQ_PTR(_data_string_17964)->length;
    }
    else {
        _new_size_17962 = 1;
    }

    /** eds.e:2766		if new_size <= old_size and*/
    if (IS_ATOM_INT(_old_size_17961)) {
        _10001 = (_new_size_17962 <= _old_size_17961);
    }
    else {
        _10001 = ((eudouble)_new_size_17962 <= DBL_PTR(_old_size_17961)->dbl);
    }
    if (_10001 == 0) {
        goto L1; // [62] 92
    }
    if (IS_ATOM_INT(_old_size_17961)) {
        _10003 = _old_size_17961 - 16;
        if ((object)((uintptr_t)_10003 +(uintptr_t) HIGH_BITS) >= 0){
            _10003 = NewDouble((eudouble)_10003);
        }
    }
    else {
        _10003 = NewDouble(DBL_PTR(_old_size_17961)->dbl - (eudouble)16);
    }
    if (IS_ATOM_INT(_10003)) {
        _10004 = (_new_size_17962 >= _10003);
    }
    else {
        _10004 = ((eudouble)_new_size_17962 >= DBL_PTR(_10003)->dbl);
    }
    DeRef(_10003);
    _10003 = NOVALUE;
    if (_10004 == 0)
    {
        DeRef(_10004);
        _10004 = NOVALUE;
        goto L1; // [75] 92
    }
    else{
        DeRef(_10004);
        _10004 = NOVALUE;
    }

    /** eds.e:2769			seek(current_db, data_ptr)*/
    Ref(_data_ptr_17963);
    _10037 = _17seek(_41current_db_15734, _data_ptr_17963);
    DeRef(_10037);
    _10037 = NOVALUE;
    goto L2; // [89] 168
L1: 

    /** eds.e:2772			db_free(data_ptr)*/
    Ref(_data_ptr_17963);
    _41db_free(_data_ptr_17963);

    /** eds.e:2774			data_ptr = db_allocate(new_size + 8)*/
    _10005 = _new_size_17962 + 8;
    if ((object)((uintptr_t)_10005 + (uintptr_t)HIGH_BITS) >= 0){
        _10005 = NewDouble((eudouble)_10005);
    }
    _0 = _data_ptr_17963;
    _data_ptr_17963 = _41db_allocate(_10005);
    DeRef(_0);
    _10005 = NOVALUE;

    /** eds.e:2775			seek(current_db, recid)*/
    _10036 = _17seek(_41current_db_15734, _recid_17959);
    DeRef(_10036);
    _10036 = NOVALUE;

    /** eds.e:2776			put4(data_ptr)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_15776)){
        poke4_addr = (uint32_t *)_41mem0_15776;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_15776)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_17963)) {
        *poke4_addr = (uint32_t)_data_ptr_17963;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_data_ptr_17963)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at111_17984);
    _1 = (object)SEQ_PTR(_41memseq_16000);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at111_17984 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_15734, _put4_1__tmp_at111_17984); // DJP 

    /** eds.e:444	end procedure*/
    goto L3; // [141] 144
L3: 
    DeRefi(_put4_1__tmp_at111_17984);
    _put4_1__tmp_at111_17984 = NOVALUE;

    /** eds.e:2777			seek(current_db, data_ptr)*/
    Ref(_data_ptr_17963);
    _10035 = _17seek(_41current_db_15734, _data_ptr_17963);
    DeRef(_10035);
    _10035 = NOVALUE;

    /** eds.e:2781			data_string &= repeat( 0, 8 )*/
    _10007 = Repeat(0, 8);
    Concat((object_ptr)&_data_string_17964, _data_string_17964, _10007);
    DeRefDS(_10007);
    _10007 = NOVALUE;
L2: 

    /** eds.e:2784		putn(data_string)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_15734, _data_string_17964); // DJP 

    /** eds.e:449	end procedure*/
    goto L4; // [179] 182
L4: 

    /** eds.e:2785	end procedure*/
    DeRef(_old_size_17961);
    DeRef(_data_ptr_17963);
    DeRef(_data_string_17964);
    DeRef(_10001);
    _10001 = NOVALUE;
    return;
    ;
}



// 0x1E957CF5
