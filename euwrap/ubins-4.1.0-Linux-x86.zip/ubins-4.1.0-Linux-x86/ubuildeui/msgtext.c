// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _30GetMsgText(object _MsgNum_19778, object _WithNum_19779, object _Args_19780)
{
    object _idx_19781 = NOVALUE;
    object _msgtext_19782 = NOVALUE;
    object _11234 = NOVALUE;
    object _11233 = NOVALUE;
    object _11229 = NOVALUE;
    object _11228 = NOVALUE;
    object _11226 = NOVALUE;
    object _11223 = NOVALUE;
    object _11221 = NOVALUE;
    object _11220 = NOVALUE;
    object _11219 = NOVALUE;
    object _11218 = NOVALUE;
    object _0, _1, _2;
    

    /** msgtext.e:757		integer idx = 1*/
    _idx_19781 = 1;

    /** msgtext.e:761		msgtext = get_text( MsgNum, LocalizeQual, LocalDB )*/
    Ref(_MsgNum_19778);
    RefDS(_13LocalizeQual_11336);
    RefDS(_13LocalDB_11337);
    _0 = _msgtext_19782;
    _msgtext_19782 = _31get_text(_MsgNum_19778, _13LocalizeQual_11336, _13LocalDB_11337);
    DeRef(_0);

    /** msgtext.e:764		if atom(msgtext) then*/
    _11218 = IS_ATOM(_msgtext_19782);
    if (_11218 == 0)
    {
        _11218 = NOVALUE;
        goto L1; // [25] 100
    }
    else{
        _11218 = NOVALUE;
    }

    /** msgtext.e:765			for i = 1 to length(StdErrMsgs) do*/
    _11219 = 365;
    {
        object _i_19790;
        _i_19790 = 1;
L2: 
        if (_i_19790 > 365){
            goto L3; // [35] 75
        }

        /** msgtext.e:766				if StdErrMsgs[i][1] = MsgNum then*/
        _2 = (object)SEQ_PTR(_30StdErrMsgs_19049);
        _11220 = (object)*(((s1_ptr)_2)->base + _i_19790);
        _2 = (object)SEQ_PTR(_11220);
        _11221 = (object)*(((s1_ptr)_2)->base + 1);
        _11220 = NOVALUE;
        if (binary_op_a(NOTEQ, _11221, _MsgNum_19778)){
            _11221 = NOVALUE;
            goto L4; // [54] 68
        }
        _11221 = NOVALUE;

        /** msgtext.e:767					idx = i*/
        _idx_19781 = _i_19790;

        /** msgtext.e:768					exit*/
        goto L3; // [65] 75
L4: 

        /** msgtext.e:770			end for*/
        _i_19790 = _i_19790 + 1;
        goto L2; // [70] 42
L3: 
        ;
    }

    /** msgtext.e:771			msgtext = StdErrMsgs[idx][2]*/
    _2 = (object)SEQ_PTR(_30StdErrMsgs_19049);
    _11223 = (object)*(((s1_ptr)_2)->base + _idx_19781);
    DeRef(_msgtext_19782);
    _2 = (object)SEQ_PTR(_11223);
    _msgtext_19782 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_msgtext_19782);
    _11223 = NOVALUE;

    /** msgtext.e:772			if idx = 1 then*/
    if (_idx_19781 != 1)
    goto L5; // [89] 99

    /** msgtext.e:773				Args = MsgNum*/
    Ref(_MsgNum_19778);
    DeRef(_Args_19780);
    _Args_19780 = _MsgNum_19778;
L5: 
L1: 

    /** msgtext.e:777		if atom(Args) or length(Args) != 0 then*/
    _11226 = IS_ATOM(_Args_19780);
    if (_11226 != 0) {
        goto L6; // [105] 121
    }
    if (IS_SEQUENCE(_Args_19780)){
            _11228 = SEQ_PTR(_Args_19780)->length;
    }
    else {
        _11228 = 1;
    }
    _11229 = (_11228 != 0);
    _11228 = NOVALUE;
    if (_11229 == 0)
    {
        DeRef(_11229);
        _11229 = NOVALUE;
        goto L7; // [117] 129
    }
    else{
        DeRef(_11229);
        _11229 = NOVALUE;
    }
L6: 

    /** msgtext.e:778			msgtext = format(msgtext, Args)*/
    Ref(_msgtext_19782);
    Ref(_Args_19780);
    _0 = _msgtext_19782;
    _msgtext_19782 = _18format(_msgtext_19782, _Args_19780);
    DeRef(_0);
L7: 

    /** msgtext.e:781		if WithNum != 0 then*/
    if (_WithNum_19779 == 0)
    goto L8; // [131] 152

    /** msgtext.e:782			return sprintf("<%04d>:: %s", {MsgNum, msgtext})*/
    Ref(_msgtext_19782);
    Ref(_MsgNum_19778);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _MsgNum_19778;
    ((intptr_t *)_2)[2] = _msgtext_19782;
    _11233 = MAKE_SEQ(_1);
    _11234 = EPrintf(-9999999, _11232, _11233);
    DeRefDS(_11233);
    _11233 = NOVALUE;
    DeRef(_MsgNum_19778);
    DeRef(_Args_19780);
    DeRef(_msgtext_19782);
    return _11234;
    goto L9; // [149] 159
L8: 

    /** msgtext.e:784			return msgtext*/
    DeRef(_MsgNum_19778);
    DeRef(_Args_19780);
    DeRef(_11234);
    _11234 = NOVALUE;
    return _msgtext_19782;
L9: 
    ;
}


void _30ShowMsg(object _Cons_19815, object _Msg_19816, object _Args_19817, object _NL_19818)
{
    object _11241 = NOVALUE;
    object _11240 = NOVALUE;
    object _11238 = NOVALUE;
    object _11236 = NOVALUE;
    object _11235 = NOVALUE;
    object _0, _1, _2;
    

    /** msgtext.e:790		if atom(Msg) then*/
    _11235 = 1;
    if (_11235 == 0)
    {
        _11235 = NOVALUE;
        goto L1; // [10] 25
    }
    else{
        _11235 = NOVALUE;
    }

    /** msgtext.e:791			Msg = GetMsgText(floor(Msg), 0)*/
    _11236 = e_floor(_Msg_19816);
    RefDS(_5);
    _Msg_19816 = _30GetMsgText(_11236, 0, _5);
    _11236 = NOVALUE;
L1: 

    /** msgtext.e:794		if atom(Args) or length(Args) != 0 then*/
    _11238 = IS_ATOM(_Args_19817);
    if (_11238 != 0) {
        goto L2; // [30] 46
    }
    if (IS_SEQUENCE(_Args_19817)){
            _11240 = SEQ_PTR(_Args_19817)->length;
    }
    else {
        _11240 = 1;
    }
    _11241 = (_11240 != 0);
    _11240 = NOVALUE;
    if (_11241 == 0)
    {
        DeRef(_11241);
        _11241 = NOVALUE;
        goto L3; // [42] 54
    }
    else{
        DeRef(_11241);
        _11241 = NOVALUE;
    }
L2: 

    /** msgtext.e:795			Msg = format(Msg, Args)*/
    Ref(_Msg_19816);
    Ref(_Args_19817);
    _0 = _Msg_19816;
    _Msg_19816 = _18format(_Msg_19816, _Args_19817);
    DeRef(_0);
L3: 

    /** msgtext.e:798		puts(Cons, Msg)*/
    EPuts(_Cons_19815, _Msg_19816); // DJP 

    /** msgtext.e:800		if NL then*/
    if (_NL_19818 == 0)
    {
        goto L4; // [61] 70
    }
    else{
    }

    /** msgtext.e:801			puts(Cons, '\n')*/
    EPuts(_Cons_19815, 10); // DJP 
L4: 

    /** msgtext.e:804	end procedure*/
    DeRef(_Msg_19816);
    DeRef(_Args_19817);
    return;
    ;
}



// 0xDEE7571C
