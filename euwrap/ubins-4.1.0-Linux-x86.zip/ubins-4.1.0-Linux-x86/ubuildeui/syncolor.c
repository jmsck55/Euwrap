// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _71set_colors(object _pColorList_71884)
{
    object _lColorName_71885 = NOVALUE;
    object _35810 = NOVALUE;
    object _35807 = NOVALUE;
    object _35804 = NOVALUE;
    object _35801 = NOVALUE;
    object _35798 = NOVALUE;
    object _35795 = NOVALUE;
    object _35792 = NOVALUE;
    object _35787 = NOVALUE;
    object _35786 = NOVALUE;
    object _35785 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:48		for i = 1 to length(pColorList) do*/
    _35785 = 6;
    {
        object _i_71887;
        _i_71887 = 1;
L1: 
        if (_i_71887 > 6){
            goto L2; // [8] 168
        }

        /** syncolor.e:49			lColorName = text:upper(pColorList[i][1])*/
        _2 = (object)SEQ_PTR(_pColorList_71884);
        _35786 = (object)*(((s1_ptr)_2)->base + _i_71887);
        _2 = (object)SEQ_PTR(_35786);
        _35787 = (object)*(((s1_ptr)_2)->base + 1);
        _35786 = NOVALUE;
        Ref(_35787);
        _0 = _lColorName_71885;
        _lColorName_71885 = _18upper(_35787);
        DeRef(_0);
        _35787 = NOVALUE;

        /** syncolor.e:50			switch lColorName do*/
        _1 = find(_lColorName_71885, _35789);
        switch ( _1 ){ 

            /** syncolor.e:51				case "NORMAL" then*/
            case 1:

            /** syncolor.e:52					NORMAL_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_71884);
            _35792 = (object)*(((s1_ptr)_2)->base + _i_71887);
            _2 = (object)SEQ_PTR(_35792);
            _71NORMAL_COLOR_71873 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_71NORMAL_COLOR_71873)){
                _71NORMAL_COLOR_71873 = (object)DBL_PTR(_71NORMAL_COLOR_71873)->dbl;
            }
            _35792 = NOVALUE;
            goto L3; // [54] 161

            /** syncolor.e:53				case "COMMENT" then*/
            case 2:

            /** syncolor.e:54					COMMENT_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_71884);
            _35795 = (object)*(((s1_ptr)_2)->base + _i_71887);
            _2 = (object)SEQ_PTR(_35795);
            _71COMMENT_COLOR_71874 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_71COMMENT_COLOR_71874)){
                _71COMMENT_COLOR_71874 = (object)DBL_PTR(_71COMMENT_COLOR_71874)->dbl;
            }
            _35795 = NOVALUE;
            goto L3; // [72] 161

            /** syncolor.e:55				case "KEYWORD" then*/
            case 3:

            /** syncolor.e:56					KEYWORD_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_71884);
            _35798 = (object)*(((s1_ptr)_2)->base + _i_71887);
            _2 = (object)SEQ_PTR(_35798);
            _71KEYWORD_COLOR_71875 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_71KEYWORD_COLOR_71875)){
                _71KEYWORD_COLOR_71875 = (object)DBL_PTR(_71KEYWORD_COLOR_71875)->dbl;
            }
            _35798 = NOVALUE;
            goto L3; // [90] 161

            /** syncolor.e:57				case "BUILTIN" then*/
            case 4:

            /** syncolor.e:58					BUILTIN_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_71884);
            _35801 = (object)*(((s1_ptr)_2)->base + _i_71887);
            _2 = (object)SEQ_PTR(_35801);
            _71BUILTIN_COLOR_71876 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_71BUILTIN_COLOR_71876)){
                _71BUILTIN_COLOR_71876 = (object)DBL_PTR(_71BUILTIN_COLOR_71876)->dbl;
            }
            _35801 = NOVALUE;
            goto L3; // [108] 161

            /** syncolor.e:59				case "STRING" then*/
            case 5:

            /** syncolor.e:60					STRING_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_71884);
            _35804 = (object)*(((s1_ptr)_2)->base + _i_71887);
            _2 = (object)SEQ_PTR(_35804);
            _71STRING_COLOR_71877 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_71STRING_COLOR_71877)){
                _71STRING_COLOR_71877 = (object)DBL_PTR(_71STRING_COLOR_71877)->dbl;
            }
            _35804 = NOVALUE;
            goto L3; // [126] 161

            /** syncolor.e:61				case "BRACKET" then*/
            case 6:

            /** syncolor.e:62					BRACKET_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_71884);
            _35807 = (object)*(((s1_ptr)_2)->base + _i_71887);
            DeRef(_71BRACKET_COLOR_71878);
            _2 = (object)SEQ_PTR(_35807);
            _71BRACKET_COLOR_71878 = (object)*(((s1_ptr)_2)->base + 2);
            Ref(_71BRACKET_COLOR_71878);
            _35807 = NOVALUE;
            goto L3; // [144] 161

            /** syncolor.e:63				case else*/
            case 0:

            /** syncolor.e:64					printf(2, "syncolor.e: Unknown color name '%s', ignored.\n", {lColorName})*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            RefDS(_lColorName_71885);
            ((intptr_t*)_2)[1] = _lColorName_71885;
            _35810 = MAKE_SEQ(_1);
            EPrintf(2, _35809, _35810);
            DeRefDS(_35810);
            _35810 = NOVALUE;
        ;}L3: 

        /** syncolor.e:66		end for*/
        _i_71887 = _i_71887 + 1;
        goto L1; // [163] 15
L2: 
        ;
    }

    /** syncolor.e:67	end procedure*/
    DeRefDS(_pColorList_71884);
    DeRef(_lColorName_71885);
    return;
    ;
}


void _71init_class()
{
    object _0, _1, _2;
    

    /** syncolor.e:71		NORMAL_COLOR  = #330033*/
    _71NORMAL_COLOR_71873 = 3342387;

    /** syncolor.e:72		COMMENT_COLOR = #FF0055*/
    _71COMMENT_COLOR_71874 = 16711765;

    /** syncolor.e:73		KEYWORD_COLOR = #0000FF*/
    _71KEYWORD_COLOR_71875 = 255;

    /** syncolor.e:74		BUILTIN_COLOR = #FF00FF*/
    _71BUILTIN_COLOR_71876 = 16711935;

    /** syncolor.e:75		STRING_COLOR  = #00A033*/
    _71STRING_COLOR_71877 = 41011;

    /** syncolor.e:76		BRACKET_COLOR = {NORMAL_COLOR, #993333, #0000FF, #5500FF, #00FF00}*/
    _0 = _71BRACKET_COLOR_71878;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 3342387;
    ((intptr_t*)_2)[2] = 10040115;
    ((intptr_t*)_2)[3] = 255;
    ((intptr_t*)_2)[4] = 5570815;
    ((intptr_t*)_2)[5] = 65280;
    _71BRACKET_COLOR_71878 = MAKE_SEQ(_1);
    DeRef(_0);

    /** syncolor.e:78	end procedure*/
    return;
    ;
}


object _71default_state(object _token_71951)
{
    object _35828 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:103		if not token then*/
    if (IS_ATOM_INT(_token_71951)) {
        if (_token_71951 != 0){
            goto L1; // [3] 12
        }
    }
    else {
        if (DBL_PTR(_token_71951)->dbl != 0.0){
            goto L1; // [3] 12
        }
    }

    /** syncolor.e:104			token = tokenize:new()*/
    _0 = _token_71951;
    _token_71951 = _72new();
    DeRef(_0);
L1: 

    /** syncolor.e:106		return {*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_token_71951);
    ((intptr_t*)_2)[1] = _token_71951;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 0;
    _35828 = MAKE_SEQ(_1);
    DeRef(_token_71951);
    return _35828;
    ;
}


object _71new()
{
    object _state_71961 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:124		atom state = eumem:malloc()*/
    _0 = _state_71961;
    _state_71961 = _35malloc(1, 1);
    DeRef(_0);

    /** syncolor.e:126		reset(state)*/
    Ref(_state_71961);
    _71reset(_state_71961);

    /** syncolor.e:128		return state*/
    return _state_71961;
    ;
}


void _71tokenize_reset(object _token_71966)
{
    object _reset_1__tmp_at7_71969 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:138		if token then*/
    if (_token_71966 == 0) {
        goto L1; // [3] 27
    }
    else {
        if (!IS_ATOM_INT(_token_71966) && DBL_PTR(_token_71966)->dbl == 0.0){
            goto L1; // [3] 27
        }
    }

    /** syncolor.e:139			tokenize:reset(token)*/

    /** tokenize.e:215		eumem:ram_space[state] = default_state()*/
    _0 = _reset_1__tmp_at7_71969;
    _reset_1__tmp_at7_71969 = _72default_state();
    DeRef(_0);
    Ref(_reset_1__tmp_at7_71969);
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_token_71966))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_token_71966)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _token_71966);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _reset_1__tmp_at7_71969;
    DeRef(_1);

    /** tokenize.e:216	end procedure*/
    goto L2; // [21] 24
L2: 
    DeRef(_reset_1__tmp_at7_71969);
    _reset_1__tmp_at7_71969 = NOVALUE;
L1: 

    /** syncolor.e:141	end procedure*/
    DeRef(_token_71966);
    return;
    ;
}


void _71reset(object _state_71972)
{
    object _token_71973 = NOVALUE;
    object _35835 = NOVALUE;
    object _35834 = NOVALUE;
    object _35832 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:144		atom token = eumem:ram_space[state][S_TOKENIZER]*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_state_71972)){
        _35832 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_71972)->dbl));
    }
    else{
        _35832 = (object)*(((s1_ptr)_2)->base + _state_71972);
    }
    DeRef(_token_71973);
    _2 = (object)SEQ_PTR(_35832);
    _token_71973 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_token_71973);
    _35832 = NOVALUE;

    /** syncolor.e:145		tokenize_reset(token)*/
    Ref(_token_71973);
    _71tokenize_reset(_token_71973);

    /** syncolor.e:146		eumem:ram_space[state] = default_state(token)*/
    Ref(_token_71973);
    _35834 = _71default_state(_token_71973);
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_71972))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_71972)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _state_71972);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35834;
    if( _1 != _35834 ){
        DeRef(_1);
    }
    _35834 = NOVALUE;

    /** syncolor.e:147		eumem:ram_space[state] = default_state()*/
    _35835 = _71default_state(0);
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_71972))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_71972)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _state_71972);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35835;
    if( _1 != _35835 ){
        DeRef(_1);
    }
    _35835 = NOVALUE;

    /** syncolor.e:148	end procedure*/
    DeRef(_state_71972);
    DeRef(_token_71973);
    return;
    ;
}



// 0x831F840F
