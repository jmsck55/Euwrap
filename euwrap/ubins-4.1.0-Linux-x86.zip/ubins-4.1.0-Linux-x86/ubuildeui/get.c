// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _16get_ch()
{
    object _4569 = NOVALUE;
    object _4568 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:47		if sequence(input_string) then*/
    _4568 = IS_SEQUENCE(_16input_string_8320);
    if (_4568 == 0)
    {
        _4568 = NOVALUE;
        goto L1; // [8] 56
    }
    else{
        _4568 = NOVALUE;
    }

    /** get.e:48			if string_next <= length(input_string) then*/
    if (IS_SEQUENCE(_16input_string_8320)){
            _4569 = SEQ_PTR(_16input_string_8320)->length;
    }
    else {
        _4569 = 1;
    }
    if (_16string_next_8321 > _4569)
    goto L2; // [20] 47

    /** get.e:49				ch = input_string[string_next]*/
    _2 = (object)SEQ_PTR(_16input_string_8320);
    _16ch_8322 = (object)*(((s1_ptr)_2)->base + _16string_next_8321);
    if (!IS_ATOM_INT(_16ch_8322)){
        _16ch_8322 = (object)DBL_PTR(_16ch_8322)->dbl;
    }

    /** get.e:50				string_next += 1*/
    _16string_next_8321 = _16string_next_8321 + 1;
    goto L3; // [44] 81
L2: 

    /** get.e:52				ch = GET_EOF*/
    _16ch_8322 = -1;
    goto L3; // [53] 81
L1: 

    /** get.e:55			ch = getc(input_file)*/
    if (_16input_file_8319 != last_r_file_no) {
        last_r_file_ptr = which_file(_16input_file_8319, EF_READ);
        last_r_file_no = _16input_file_8319;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _16ch_8322 = getc((FILE*)xstdin);
        }
        else{
            _16ch_8322 = getc(last_r_file_ptr);
        }
    }
    else{
        _16ch_8322 = getc(last_r_file_ptr);
    }

    /** get.e:56			if ch = GET_EOF then*/
    if (_16ch_8322 != -1)
    goto L4; // [67] 80

    /** get.e:57				string_next += 1*/
    _16string_next_8321 = _16string_next_8321 + 1;
L4: 
L3: 

    /** get.e:60	end procedure*/
    return;
    ;
}


object _16escape_char(object _c_8349)
{
    object _i_8350 = NOVALUE;
    object _4581 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:79		i = find(c, ESCAPE_CHARS)*/
    _i_8350 = find_from(_c_8349, _16ESCAPE_CHARS_8343, 1);

    /** get.e:80		if i = 0 then*/
    if (_i_8350 != 0)
    goto L1; // [12] 25

    /** get.e:81			return GET_FAIL*/
    return 1;
    goto L2; // [22] 36
L1: 

    /** get.e:83			return ESCAPED_CHARS[i]*/
    _2 = (object)SEQ_PTR(_16ESCAPED_CHARS_8345);
    _4581 = (object)*(((s1_ptr)_2)->base + _i_8350);
    Ref(_4581);
    return _4581;
L2: 
    ;
}


object _16get_qchar()
{
    object _c_8358 = NOVALUE;
    object _4590 = NOVALUE;
    object _4589 = NOVALUE;
    object _4587 = NOVALUE;
    object _4585 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:92		get_ch()*/
    _16get_ch();

    /** get.e:93		c = ch*/
    _c_8358 = _16ch_8322;

    /** get.e:94		if ch = '\\' then*/
    if (_16ch_8322 != 92)
    goto L1; // [16] 54

    /** get.e:95			get_ch()*/
    _16get_ch();

    /** get.e:96			c = escape_char(ch)*/
    _c_8358 = _16escape_char(_16ch_8322);
    if (!IS_ATOM_INT(_c_8358)) {
        _1 = (object)(DBL_PTR(_c_8358)->dbl);
        DeRefDS(_c_8358);
        _c_8358 = _1;
    }

    /** get.e:97			if c = GET_FAIL then*/
    if (_c_8358 != 1)
    goto L2; // [36] 74

    /** get.e:98				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _4585 = MAKE_SEQ(_1);
    return _4585;
    goto L2; // [51] 74
L1: 

    /** get.e:100		elsif ch = '\'' then*/
    if (_16ch_8322 != 39)
    goto L3; // [58] 73

    /** get.e:101			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _4587 = MAKE_SEQ(_1);
    DeRef(_4585);
    _4585 = NOVALUE;
    return _4587;
L3: 
L2: 

    /** get.e:103		get_ch()*/
    _16get_ch();

    /** get.e:104		if ch != '\'' then*/
    if (_16ch_8322 == 39)
    goto L4; // [82] 99

    /** get.e:105			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _4589 = MAKE_SEQ(_1);
    DeRef(_4587);
    _4587 = NOVALUE;
    DeRef(_4585);
    _4585 = NOVALUE;
    return _4589;
    goto L5; // [96] 114
L4: 

    /** get.e:107			get_ch()*/
    _16get_ch();

    /** get.e:108			return {GET_SUCCESS, c}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _c_8358;
    _4590 = MAKE_SEQ(_1);
    DeRef(_4589);
    _4589 = NOVALUE;
    DeRef(_4587);
    _4587 = NOVALUE;
    DeRef(_4585);
    _4585 = NOVALUE;
    return _4590;
L5: 
    ;
}


object _16get_heredoc(object _terminator_8375)
{
    object _text_8376 = NOVALUE;
    object _ends_at_8377 = NOVALUE;
    object _4605 = NOVALUE;
    object _4604 = NOVALUE;
    object _4603 = NOVALUE;
    object _4602 = NOVALUE;
    object _4601 = NOVALUE;
    object _4598 = NOVALUE;
    object _4596 = NOVALUE;
    object _4595 = NOVALUE;
    object _4594 = NOVALUE;
    object _4593 = NOVALUE;
    object _4591 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:113		sequence text = ""*/
    RefDS(_5);
    DeRefi(_text_8376);
    _text_8376 = _5;

    /** get.e:114		integer ends_at = 1 - length( terminator )*/
    if (IS_SEQUENCE(_terminator_8375)){
            _4591 = SEQ_PTR(_terminator_8375)->length;
    }
    else {
        _4591 = 1;
    }
    _ends_at_8377 = 1 - _4591;
    _4591 = NOVALUE;

    /** get.e:115		while ends_at < 1 or not match( terminator, text, ends_at ) with entry do*/
    goto L1; // [21] 69
L2: 
    _4593 = (_ends_at_8377 < 1);
    if (_4593 != 0) {
        DeRef(_4594);
        _4594 = 1;
        goto L3; // [28] 44
    }
    _4595 = e_match_from(_terminator_8375, _text_8376, _ends_at_8377);
    _4596 = (_4595 == 0);
    _4595 = NOVALUE;
    _4594 = (_4596 != 0);
L3: 
    if (_4594 == 0)
    {
        _4594 = NOVALUE;
        goto L4; // [44] 92
    }
    else{
        _4594 = NOVALUE;
    }

    /** get.e:116			if ch = GET_EOF then*/
    if (_16ch_8322 != -1)
    goto L5; // [51] 66

    /** get.e:117				return { GET_FAIL, 0 }*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _4598 = MAKE_SEQ(_1);
    DeRefDSi(_terminator_8375);
    DeRefi(_text_8376);
    DeRef(_4593);
    _4593 = NOVALUE;
    DeRef(_4596);
    _4596 = NOVALUE;
    return _4598;
L5: 

    /** get.e:119		entry*/
L1: 

    /** get.e:120			get_ch()*/
    _16get_ch();

    /** get.e:121			text &= ch*/
    Append(&_text_8376, _text_8376, _16ch_8322);

    /** get.e:122			ends_at += 1*/
    _ends_at_8377 = _ends_at_8377 + 1;

    /** get.e:123		end while*/
    goto L2; // [89] 24
L4: 

    /** get.e:124		return { GET_SUCCESS, head( text, length( text ) - length( terminator ) ) }*/
    if (IS_SEQUENCE(_text_8376)){
            _4601 = SEQ_PTR(_text_8376)->length;
    }
    else {
        _4601 = 1;
    }
    if (IS_SEQUENCE(_terminator_8375)){
            _4602 = SEQ_PTR(_terminator_8375)->length;
    }
    else {
        _4602 = 1;
    }
    _4603 = _4601 - _4602;
    _4601 = NOVALUE;
    _4602 = NOVALUE;
    {
        int len = SEQ_PTR(_text_8376)->length;
        int size = (IS_ATOM_INT(_4603)) ? _4603 : (object)(DBL_PTR(_4603)->dbl);
        if (size <= 0){
            DeRef( _4604 );
            _4604 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_text_8376);
            DeRef(_4604);
            _4604 = _text_8376;
        }
        else{
            Head(SEQ_PTR(_text_8376),size+1,&_4604);
        }
    }
    _4603 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _4604;
    _4605 = MAKE_SEQ(_1);
    _4604 = NOVALUE;
    DeRefDSi(_terminator_8375);
    DeRefDSi(_text_8376);
    DeRef(_4593);
    _4593 = NOVALUE;
    DeRef(_4598);
    _4598 = NOVALUE;
    DeRef(_4596);
    _4596 = NOVALUE;
    return _4605;
    ;
}


object _16get_string()
{
    object _text_8397 = NOVALUE;
    object _4622 = NOVALUE;
    object _4618 = NOVALUE;
    object _4617 = NOVALUE;
    object _4614 = NOVALUE;
    object _4613 = NOVALUE;
    object _4612 = NOVALUE;
    object _4611 = NOVALUE;
    object _4609 = NOVALUE;
    object _4608 = NOVALUE;
    object _4606 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:132		text = ""*/
    RefDS(_5);
    DeRefi(_text_8397);
    _text_8397 = _5;

    /** get.e:133		while TRUE do*/
L1: 

    /** get.e:134			get_ch()*/
    _16get_ch();

    /** get.e:135			if ch = GET_EOF or ch = '\n' then*/
    _4606 = (_16ch_8322 == -1);
    if (_4606 != 0) {
        goto L2; // [25] 40
    }
    _4608 = (_16ch_8322 == 10);
    if (_4608 == 0)
    {
        DeRef(_4608);
        _4608 = NOVALUE;
        goto L3; // [36] 53
    }
    else{
        DeRef(_4608);
        _4608 = NOVALUE;
    }
L2: 

    /** get.e:136				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _4609 = MAKE_SEQ(_1);
    DeRefi(_text_8397);
    DeRef(_4606);
    _4606 = NOVALUE;
    return _4609;
    goto L4; // [50] 164
L3: 

    /** get.e:137			elsif ch = '"' then*/
    if (_16ch_8322 != 34)
    goto L5; // [57] 121

    /** get.e:138				get_ch()*/
    _16get_ch();

    /** get.e:139				if length( text ) = 0 and ch = '"' then*/
    if (IS_SEQUENCE(_text_8397)){
            _4611 = SEQ_PTR(_text_8397)->length;
    }
    else {
        _4611 = 1;
    }
    _4612 = (_4611 == 0);
    _4611 = NOVALUE;
    if (_4612 == 0) {
        goto L6; // [74] 108
    }
    _4614 = (_16ch_8322 == 34);
    if (_4614 == 0)
    {
        DeRef(_4614);
        _4614 = NOVALUE;
        goto L6; // [85] 108
    }
    else{
        DeRef(_4614);
        _4614 = NOVALUE;
    }

    /** get.e:140					if ch = '"' then*/
    if (_16ch_8322 != 34)
    goto L7; // [92] 107

    /** get.e:141						return get_heredoc( `"""` )*/
    RefDS(_4616);
    _4617 = _16get_heredoc(_4616);
    DeRefi(_text_8397);
    DeRef(_4609);
    _4609 = NOVALUE;
    DeRef(_4612);
    _4612 = NOVALUE;
    DeRef(_4606);
    _4606 = NOVALUE;
    return _4617;
L7: 
L6: 

    /** get.e:144				return {GET_SUCCESS, text}*/
    RefDS(_text_8397);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _text_8397;
    _4618 = MAKE_SEQ(_1);
    DeRefDSi(_text_8397);
    DeRef(_4609);
    _4609 = NOVALUE;
    DeRef(_4612);
    _4612 = NOVALUE;
    DeRef(_4606);
    _4606 = NOVALUE;
    DeRef(_4617);
    _4617 = NOVALUE;
    return _4618;
    goto L4; // [118] 164
L5: 

    /** get.e:145			elsif ch = '\\' then*/
    if (_16ch_8322 != 92)
    goto L8; // [125] 163

    /** get.e:146				get_ch()*/
    _16get_ch();

    /** get.e:147				ch = escape_char(ch)*/
    _0 = _16escape_char(_16ch_8322);
    _16ch_8322 = _0;
    if (!IS_ATOM_INT(_16ch_8322)) {
        _1 = (object)(DBL_PTR(_16ch_8322)->dbl);
        DeRefDS(_16ch_8322);
        _16ch_8322 = _1;
    }

    /** get.e:148				if ch = GET_FAIL then*/
    if (_16ch_8322 != 1)
    goto L9; // [147] 162

    /** get.e:149					return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _4622 = MAKE_SEQ(_1);
    DeRefi(_text_8397);
    DeRef(_4609);
    _4609 = NOVALUE;
    DeRef(_4612);
    _4612 = NOVALUE;
    DeRef(_4606);
    _4606 = NOVALUE;
    DeRef(_4618);
    _4618 = NOVALUE;
    DeRef(_4617);
    _4617 = NOVALUE;
    return _4622;
L9: 
L8: 
L4: 

    /** get.e:152			text = text & ch*/
    Append(&_text_8397, _text_8397, _16ch_8322);

    /** get.e:153		end while*/
    goto L1; // [174] 13
    ;
}


object _16read_comment()
{
    object _4643 = NOVALUE;
    object _4642 = NOVALUE;
    object _4640 = NOVALUE;
    object _4638 = NOVALUE;
    object _4636 = NOVALUE;
    object _4635 = NOVALUE;
    object _4634 = NOVALUE;
    object _4632 = NOVALUE;
    object _4631 = NOVALUE;
    object _4630 = NOVALUE;
    object _4629 = NOVALUE;
    object _4628 = NOVALUE;
    object _4627 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:163		if atom(input_string) then*/
    _4627 = IS_ATOM(_16input_string_8320);
    if (_4627 == 0)
    {
        _4627 = NOVALUE;
        goto L1; // [8] 98
    }
    else{
        _4627 = NOVALUE;
    }

    /** get.e:164			while ch!='\n' and ch!='\r' and ch!=-1 do*/
L2: 
    _4628 = (_16ch_8322 != 10);
    if (_4628 == 0) {
        _4629 = 0;
        goto L3; // [22] 36
    }
    _4630 = (_16ch_8322 != 13);
    _4629 = (_4630 != 0);
L3: 
    if (_4629 == 0) {
        goto L4; // [36] 59
    }
    _4632 = (_16ch_8322 != -1);
    if (_4632 == 0)
    {
        DeRef(_4632);
        _4632 = NOVALUE;
        goto L4; // [47] 59
    }
    else{
        DeRef(_4632);
        _4632 = NOVALUE;
    }

    /** get.e:165				get_ch()*/
    _16get_ch();

    /** get.e:166			end while*/
    goto L2; // [56] 16
L4: 

    /** get.e:167			get_ch()*/
    _16get_ch();

    /** get.e:168			if ch=-1 then*/
    if (_16ch_8322 != -1)
    goto L5; // [67] 84

    /** get.e:169				return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = 0;
    _4634 = MAKE_SEQ(_1);
    DeRef(_4628);
    _4628 = NOVALUE;
    DeRef(_4630);
    _4630 = NOVALUE;
    return _4634;
    goto L6; // [81] 182
L5: 

    /** get.e:171				return {GET_IGNORE, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -2;
    ((intptr_t *)_2)[2] = 0;
    _4635 = MAKE_SEQ(_1);
    DeRef(_4628);
    _4628 = NOVALUE;
    DeRef(_4634);
    _4634 = NOVALUE;
    DeRef(_4630);
    _4630 = NOVALUE;
    return _4635;
    goto L6; // [95] 182
L1: 

    /** get.e:174			for i=string_next to length(input_string) do*/
    if (IS_SEQUENCE(_16input_string_8320)){
            _4636 = SEQ_PTR(_16input_string_8320)->length;
    }
    else {
        _4636 = 1;
    }
    {
        object _i_8447;
        _i_8447 = _16string_next_8321;
L7: 
        if (_i_8447 > _4636){
            goto L8; // [107] 171
        }

        /** get.e:175				ch=input_string[i]*/
        _2 = (object)SEQ_PTR(_16input_string_8320);
        _16ch_8322 = (object)*(((s1_ptr)_2)->base + _i_8447);
        if (!IS_ATOM_INT(_16ch_8322)){
            _16ch_8322 = (object)DBL_PTR(_16ch_8322)->dbl;
        }

        /** get.e:176				if ch='\n' or ch='\r' then*/
        _4638 = (_16ch_8322 == 10);
        if (_4638 != 0) {
            goto L9; // [132] 147
        }
        _4640 = (_16ch_8322 == 13);
        if (_4640 == 0)
        {
            DeRef(_4640);
            _4640 = NOVALUE;
            goto LA; // [143] 164
        }
        else{
            DeRef(_4640);
            _4640 = NOVALUE;
        }
L9: 

        /** get.e:177					string_next=i+1*/
        _16string_next_8321 = _i_8447 + 1;

        /** get.e:178					return {GET_IGNORE, 0}*/
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -2;
        ((intptr_t *)_2)[2] = 0;
        _4642 = MAKE_SEQ(_1);
        DeRef(_4628);
        _4628 = NOVALUE;
        DeRef(_4634);
        _4634 = NOVALUE;
        DeRef(_4638);
        _4638 = NOVALUE;
        DeRef(_4630);
        _4630 = NOVALUE;
        DeRef(_4635);
        _4635 = NOVALUE;
        return _4642;
LA: 

        /** get.e:180			end for*/
        _i_8447 = _i_8447 + 1;
        goto L7; // [166] 114
L8: 
        ;
    }

    /** get.e:181			return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = 0;
    _4643 = MAKE_SEQ(_1);
    DeRef(_4628);
    _4628 = NOVALUE;
    DeRef(_4634);
    _4634 = NOVALUE;
    DeRef(_4638);
    _4638 = NOVALUE;
    DeRef(_4630);
    _4630 = NOVALUE;
    DeRef(_4635);
    _4635 = NOVALUE;
    DeRef(_4642);
    _4642 = NOVALUE;
    return _4643;
L6: 
    ;
}


object _16get_number()
{
    object _sign_8459 = NOVALUE;
    object _e_sign_8460 = NOVALUE;
    object _ndigits_8461 = NOVALUE;
    object _hex_digit_8462 = NOVALUE;
    object _mantissa_8463 = NOVALUE;
    object _dec_8464 = NOVALUE;
    object _e_mag_8465 = NOVALUE;
    object _number_string_8466 = NOVALUE;
    object _4703 = NOVALUE;
    object _4701 = NOVALUE;
    object _4699 = NOVALUE;
    object _4698 = NOVALUE;
    object _4697 = NOVALUE;
    object _4696 = NOVALUE;
    object _4695 = NOVALUE;
    object _4694 = NOVALUE;
    object _4688 = NOVALUE;
    object _4686 = NOVALUE;
    object _4684 = NOVALUE;
    object _4679 = NOVALUE;
    object _4678 = NOVALUE;
    object _4676 = NOVALUE;
    object _4675 = NOVALUE;
    object _4674 = NOVALUE;
    object _4669 = NOVALUE;
    object _4668 = NOVALUE;
    object _4666 = NOVALUE;
    object _4665 = NOVALUE;
    object _4664 = NOVALUE;
    object _4663 = NOVALUE;
    object _4662 = NOVALUE;
    object _4661 = NOVALUE;
    object _4657 = NOVALUE;
    object _4653 = NOVALUE;
    object _4648 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:192		sequence number_string = { ch }*/
    _0 = _number_string_8466;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _16ch_8322;
    _number_string_8466 = MAKE_SEQ(_1);
    DeRefi(_0);

    /** get.e:194		sign = +1*/
    _sign_8459 = 1;

    /** get.e:195		mantissa = 0*/
    DeRef(_mantissa_8463);
    _mantissa_8463 = 0;

    /** get.e:196		ndigits = 0*/
    _ndigits_8461 = 0;

    /** get.e:199		if ch = '-' then*/
    if (_16ch_8322 != 45)
    goto L1; // [28] 70

    /** get.e:200			sign = -1*/
    _sign_8459 = -1;

    /** get.e:201			get_ch()*/
    _16get_ch();

    /** get.e:202			number_string &= ch*/
    Append(&_number_string_8466, _number_string_8466, _16ch_8322);

    /** get.e:203			if ch='-' then*/
    if (_16ch_8322 != 45)
    goto L2; // [53] 92

    /** get.e:204				return read_comment()*/
    _4648 = _16read_comment();
    DeRef(_dec_8464);
    DeRefDSi(_number_string_8466);
    return _4648;
    goto L2; // [67] 92
L1: 

    /** get.e:206		elsif ch = '+' then*/
    if (_16ch_8322 != 43)
    goto L3; // [74] 91

    /** get.e:207			get_ch()*/
    _16get_ch();

    /** get.e:208			number_string &= ch*/
    Append(&_number_string_8466, _number_string_8466, _16ch_8322);
L3: 
L2: 

    /** get.e:212		if ch = '#' then*/
    if (_16ch_8322 != 35)
    goto L4; // [96] 210

    /** get.e:214			get_ch()*/
    _16get_ch();

    /** get.e:215			number_string &= ch*/
    Append(&_number_string_8466, _number_string_8466, _16ch_8322);

    /** get.e:216			while TRUE do*/
L5: 

    /** get.e:217				hex_digit = find(ch, HEX_DIGITS)-1*/
    _4653 = find_from(_16ch_8322, _16HEX_DIGITS_8302, 1);
    _hex_digit_8462 = _4653 - 1;
    _4653 = NOVALUE;

    /** get.e:218				if hex_digit >= 0 then*/
    if (_hex_digit_8462 < 0)
    goto L6; // [134] 169

    /** get.e:219					ndigits += 1*/
    _ndigits_8461 = _ndigits_8461 + 1;

    /** get.e:220					mantissa = mantissa * 16 + hex_digit*/
    if (IS_ATOM_INT(_mantissa_8463)) {
        if (_mantissa_8463 == (short)_mantissa_8463){
            _4657 = _mantissa_8463 * 16;
        }
        else{
            _4657 = NewDouble(_mantissa_8463 * (eudouble)16);
        }
    }
    else {
        _4657 = NewDouble(DBL_PTR(_mantissa_8463)->dbl * (eudouble)16);
    }
    DeRef(_mantissa_8463);
    if (IS_ATOM_INT(_4657)) {
        _mantissa_8463 = _4657 + _hex_digit_8462;
        if ((object)((uintptr_t)_mantissa_8463 + (uintptr_t)HIGH_BITS) >= 0){
            _mantissa_8463 = NewDouble((eudouble)_mantissa_8463);
        }
    }
    else {
        _mantissa_8463 = NewDouble(DBL_PTR(_4657)->dbl + (eudouble)_hex_digit_8462);
    }
    DeRef(_4657);
    _4657 = NOVALUE;

    /** get.e:221					get_ch()*/
    _16get_ch();

    /** get.e:222					number_string &= ch*/
    Append(&_number_string_8466, _number_string_8466, _16ch_8322);
    goto L5; // [166] 117
L6: 

    /** get.e:224					if ndigits > 0 then*/
    if (_ndigits_8461 <= 0)
    goto L7; // [171] 192

    /** get.e:225						return {GET_SUCCESS, sign * mantissa}*/
    if (IS_ATOM_INT(_mantissa_8463)) {
        if (_sign_8459 == (short)_sign_8459 && _mantissa_8463 <= INT15 && _mantissa_8463 >= -INT15){
            _4661 = _sign_8459 * _mantissa_8463;
        }
        else{
            _4661 = NewDouble(_sign_8459 * (eudouble)_mantissa_8463);
        }
    }
    else {
        _4661 = NewDouble((eudouble)_sign_8459 * DBL_PTR(_mantissa_8463)->dbl);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _4661;
    _4662 = MAKE_SEQ(_1);
    _4661 = NOVALUE;
    DeRef(_mantissa_8463);
    DeRef(_dec_8464);
    DeRefi(_number_string_8466);
    DeRef(_4648);
    _4648 = NOVALUE;
    return _4662;
    goto L5; // [189] 117
L7: 

    /** get.e:227						return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _4663 = MAKE_SEQ(_1);
    DeRef(_mantissa_8463);
    DeRef(_dec_8464);
    DeRefi(_number_string_8466);
    DeRef(_4648);
    _4648 = NOVALUE;
    DeRef(_4662);
    _4662 = NOVALUE;
    return _4663;

    /** get.e:230			end while*/
    goto L5; // [206] 117
L4: 

    /** get.e:234		while ch >= '0' and ch <= '9' do*/
L8: 
    _4664 = (_16ch_8322 >= 48);
    if (_4664 == 0) {
        goto L9; // [221] 274
    }
    _4666 = (_16ch_8322 <= 57);
    if (_4666 == 0)
    {
        DeRef(_4666);
        _4666 = NOVALUE;
        goto L9; // [232] 274
    }
    else{
        DeRef(_4666);
        _4666 = NOVALUE;
    }

    /** get.e:235			ndigits += 1*/
    _ndigits_8461 = _ndigits_8461 + 1;

    /** get.e:236			mantissa = mantissa * 10 + (ch - '0')*/
    if (IS_ATOM_INT(_mantissa_8463)) {
        if (_mantissa_8463 == (short)_mantissa_8463){
            _4668 = _mantissa_8463 * 10;
        }
        else{
            _4668 = NewDouble(_mantissa_8463 * (eudouble)10);
        }
    }
    else {
        _4668 = NewDouble(DBL_PTR(_mantissa_8463)->dbl * (eudouble)10);
    }
    _4669 = _16ch_8322 - 48;
    if ((object)((uintptr_t)_4669 +(uintptr_t) HIGH_BITS) >= 0){
        _4669 = NewDouble((eudouble)_4669);
    }
    DeRef(_mantissa_8463);
    if (IS_ATOM_INT(_4668) && IS_ATOM_INT(_4669)) {
        _mantissa_8463 = _4668 + _4669;
        if ((object)((uintptr_t)_mantissa_8463 + (uintptr_t)HIGH_BITS) >= 0){
            _mantissa_8463 = NewDouble((eudouble)_mantissa_8463);
        }
    }
    else {
        if (IS_ATOM_INT(_4668)) {
            _mantissa_8463 = NewDouble((eudouble)_4668 + DBL_PTR(_4669)->dbl);
        }
        else {
            if (IS_ATOM_INT(_4669)) {
                _mantissa_8463 = NewDouble(DBL_PTR(_4668)->dbl + (eudouble)_4669);
            }
            else
            _mantissa_8463 = NewDouble(DBL_PTR(_4668)->dbl + DBL_PTR(_4669)->dbl);
        }
    }
    DeRef(_4668);
    _4668 = NOVALUE;
    DeRef(_4669);
    _4669 = NOVALUE;

    /** get.e:237			get_ch()*/
    _16get_ch();

    /** get.e:238			number_string &= ch*/
    Append(&_number_string_8466, _number_string_8466, _16ch_8322);

    /** get.e:239		end while*/
    goto L8; // [271] 215
L9: 

    /** get.e:241		if ch = '.' then*/
    if (_16ch_8322 != 46)
    goto LA; // [278] 370

    /** get.e:243			get_ch()*/
    _16get_ch();

    /** get.e:244			number_string &= ch*/
    Append(&_number_string_8466, _number_string_8466, _16ch_8322);

    /** get.e:245			dec = 10*/
    DeRef(_dec_8464);
    _dec_8464 = 10;

    /** get.e:246			while ch >= '0' and ch <= '9' do*/
LB: 
    _4674 = (_16ch_8322 >= 48);
    if (_4674 == 0) {
        goto LC; // [310] 369
    }
    _4676 = (_16ch_8322 <= 57);
    if (_4676 == 0)
    {
        DeRef(_4676);
        _4676 = NOVALUE;
        goto LC; // [321] 369
    }
    else{
        DeRef(_4676);
        _4676 = NOVALUE;
    }

    /** get.e:247				ndigits += 1*/
    _ndigits_8461 = _ndigits_8461 + 1;

    /** get.e:248				mantissa += (ch - '0') / dec*/
    _4678 = _16ch_8322 - 48;
    if ((object)((uintptr_t)_4678 +(uintptr_t) HIGH_BITS) >= 0){
        _4678 = NewDouble((eudouble)_4678);
    }
    if (IS_ATOM_INT(_4678) && IS_ATOM_INT(_dec_8464)) {
        _4679 = (_4678 % _dec_8464) ? NewDouble((eudouble)_4678 / _dec_8464) : (_4678 / _dec_8464);
    }
    else {
        if (IS_ATOM_INT(_4678)) {
            _4679 = NewDouble((eudouble)_4678 / DBL_PTR(_dec_8464)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec_8464)) {
                _4679 = NewDouble(DBL_PTR(_4678)->dbl / (eudouble)_dec_8464);
            }
            else
            _4679 = NewDouble(DBL_PTR(_4678)->dbl / DBL_PTR(_dec_8464)->dbl);
        }
    }
    DeRef(_4678);
    _4678 = NOVALUE;
    _0 = _mantissa_8463;
    if (IS_ATOM_INT(_mantissa_8463) && IS_ATOM_INT(_4679)) {
        _mantissa_8463 = _mantissa_8463 + _4679;
        if ((object)((uintptr_t)_mantissa_8463 + (uintptr_t)HIGH_BITS) >= 0){
            _mantissa_8463 = NewDouble((eudouble)_mantissa_8463);
        }
    }
    else {
        if (IS_ATOM_INT(_mantissa_8463)) {
            _mantissa_8463 = NewDouble((eudouble)_mantissa_8463 + DBL_PTR(_4679)->dbl);
        }
        else {
            if (IS_ATOM_INT(_4679)) {
                _mantissa_8463 = NewDouble(DBL_PTR(_mantissa_8463)->dbl + (eudouble)_4679);
            }
            else
            _mantissa_8463 = NewDouble(DBL_PTR(_mantissa_8463)->dbl + DBL_PTR(_4679)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_4679);
    _4679 = NOVALUE;

    /** get.e:249				dec *= 10*/
    _0 = _dec_8464;
    if (IS_ATOM_INT(_dec_8464)) {
        if (_dec_8464 == (short)_dec_8464){
            _dec_8464 = _dec_8464 * 10;
        }
        else{
            _dec_8464 = NewDouble(_dec_8464 * (eudouble)10);
        }
    }
    else {
        _dec_8464 = NewDouble(DBL_PTR(_dec_8464)->dbl * (eudouble)10);
    }
    DeRef(_0);

    /** get.e:250				get_ch()*/
    _16get_ch();

    /** get.e:251				number_string &= ch*/
    Append(&_number_string_8466, _number_string_8466, _16ch_8322);

    /** get.e:252			end while*/
    goto LB; // [366] 304
LC: 
LA: 

    /** get.e:255		if ndigits = 0 then*/
    if (_ndigits_8461 != 0)
    goto LD; // [372] 387

    /** get.e:256			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _4684 = MAKE_SEQ(_1);
    DeRef(_mantissa_8463);
    DeRef(_dec_8464);
    DeRefi(_number_string_8466);
    DeRef(_4663);
    _4663 = NOVALUE;
    DeRef(_4664);
    _4664 = NOVALUE;
    DeRef(_4674);
    _4674 = NOVALUE;
    DeRef(_4648);
    _4648 = NOVALUE;
    DeRef(_4662);
    _4662 = NOVALUE;
    return _4684;
LD: 

    /** get.e:259		mantissa = sign * mantissa*/
    _0 = _mantissa_8463;
    if (IS_ATOM_INT(_mantissa_8463)) {
        if (_sign_8459 == (short)_sign_8459 && _mantissa_8463 <= INT15 && _mantissa_8463 >= -INT15){
            _mantissa_8463 = _sign_8459 * _mantissa_8463;
        }
        else{
            _mantissa_8463 = NewDouble(_sign_8459 * (eudouble)_mantissa_8463);
        }
    }
    else {
        _mantissa_8463 = NewDouble((eudouble)_sign_8459 * DBL_PTR(_mantissa_8463)->dbl);
    }
    DeRef(_0);

    /** get.e:261		if ch = 'e' or ch = 'E' then*/
    _4686 = (_16ch_8322 == 101);
    if (_4686 != 0) {
        goto LE; // [401] 416
    }
    _4688 = (_16ch_8322 == 69);
    if (_4688 == 0)
    {
        DeRef(_4688);
        _4688 = NOVALUE;
        goto LF; // [412] 565
    }
    else{
        DeRef(_4688);
        _4688 = NOVALUE;
    }
LE: 

    /** get.e:264			get_ch()*/
    _16get_ch();

    /** get.e:265			number_string &= ch*/
    Append(&_number_string_8466, _number_string_8466, _16ch_8322);

    /** get.e:266			if ch = '-' then*/
    if (_16ch_8322 != 45)
    goto L10; // [432] 451

    /** get.e:267				get_ch()*/
    _16get_ch();

    /** get.e:268				number_string &= ch*/
    Append(&_number_string_8466, _number_string_8466, _16ch_8322);
    goto L11; // [448] 473
L10: 

    /** get.e:269			elsif ch = '+' then*/
    if (_16ch_8322 != 43)
    goto L12; // [455] 472

    /** get.e:270				get_ch()*/
    _16get_ch();

    /** get.e:271				number_string &= ch*/
    Append(&_number_string_8466, _number_string_8466, _16ch_8322);
L12: 
L11: 

    /** get.e:275			if ch >= '0' and ch <= '9' then*/
    _4694 = (_16ch_8322 >= 48);
    if (_4694 == 0) {
        goto L13; // [481] 546
    }
    _4696 = (_16ch_8322 <= 57);
    if (_4696 == 0)
    {
        DeRef(_4696);
        _4696 = NOVALUE;
        goto L13; // [492] 546
    }
    else{
        DeRef(_4696);
        _4696 = NOVALUE;
    }

    /** get.e:277				while ch >= '0' and ch <= '9' with entry do*/
    goto L14; // [497] 534
L15: 
    _4697 = (_16ch_8322 >= 48);
    if (_4697 == 0) {
        DeRef(_4698);
        _4698 = 0;
        goto L16; // [506] 520
    }
    _4699 = (_16ch_8322 <= 57);
    _4698 = (_4699 != 0);
L16: 
    if (_4698 == 0)
    {
        _4698 = NOVALUE;
        goto L17; // [520] 557
    }
    else{
        _4698 = NOVALUE;
    }

    /** get.e:278					number_string &= ch*/
    Append(&_number_string_8466, _number_string_8466, _16ch_8322);

    /** get.e:279				entry*/
L14: 

    /** get.e:280					get_ch()*/
    _16get_ch();

    /** get.e:281				end while*/
    goto L15; // [540] 500
    goto L17; // [543] 557
L13: 

    /** get.e:283				return {GET_FAIL, 0} -- no exponent*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _4701 = MAKE_SEQ(_1);
    DeRef(_mantissa_8463);
    DeRef(_dec_8464);
    DeRefi(_number_string_8466);
    DeRef(_4663);
    _4663 = NOVALUE;
    DeRef(_4664);
    _4664 = NOVALUE;
    DeRef(_4674);
    _4674 = NOVALUE;
    DeRef(_4697);
    _4697 = NOVALUE;
    DeRef(_4684);
    _4684 = NOVALUE;
    DeRef(_4648);
    _4648 = NOVALUE;
    DeRef(_4686);
    _4686 = NOVALUE;
    DeRef(_4662);
    _4662 = NOVALUE;
    DeRef(_4694);
    _4694 = NOVALUE;
    DeRef(_4699);
    _4699 = NOVALUE;
    return _4701;
L17: 

    /** get.e:286			mantissa = scientific_to_atom( number_string )*/
    RefDS(_number_string_8466);
    _0 = _mantissa_8463;
    _mantissa_8463 = _27scientific_to_atom(_number_string_8466, 1);
    DeRef(_0);
LF: 

    /** get.e:289		return {GET_SUCCESS, mantissa}*/
    Ref(_mantissa_8463);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _mantissa_8463;
    _4703 = MAKE_SEQ(_1);
    DeRef(_mantissa_8463);
    DeRef(_dec_8464);
    DeRefi(_number_string_8466);
    DeRef(_4663);
    _4663 = NOVALUE;
    DeRef(_4664);
    _4664 = NOVALUE;
    DeRef(_4701);
    _4701 = NOVALUE;
    DeRef(_4674);
    _4674 = NOVALUE;
    DeRef(_4697);
    _4697 = NOVALUE;
    DeRef(_4684);
    _4684 = NOVALUE;
    DeRef(_4648);
    _4648 = NOVALUE;
    DeRef(_4686);
    _4686 = NOVALUE;
    DeRef(_4662);
    _4662 = NOVALUE;
    DeRef(_4694);
    _4694 = NOVALUE;
    DeRef(_4699);
    _4699 = NOVALUE;
    return _4703;
    ;
}


object _16Get()
{
    object _skip_blanks_1__tmp_at328_8593 = NOVALUE;
    object _skip_blanks_1__tmp_at177_8574 = NOVALUE;
    object _skip_blanks_1__tmp_at88_8565 = NOVALUE;
    object _s_8549 = NOVALUE;
    object _e_8550 = NOVALUE;
    object _e1_8551 = NOVALUE;
    object _4742 = NOVALUE;
    object _4741 = NOVALUE;
    object _4739 = NOVALUE;
    object _4736 = NOVALUE;
    object _4734 = NOVALUE;
    object _4732 = NOVALUE;
    object _4730 = NOVALUE;
    object _4727 = NOVALUE;
    object _4725 = NOVALUE;
    object _4721 = NOVALUE;
    object _4717 = NOVALUE;
    object _4714 = NOVALUE;
    object _4713 = NOVALUE;
    object _4711 = NOVALUE;
    object _4709 = NOVALUE;
    object _4707 = NOVALUE;
    object _4706 = NOVALUE;
    object _4704 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:300		while find(ch, white_space) do*/
L1: 
    _4704 = find_from(_16ch_8322, _16white_space_8338, 1);
    if (_4704 == 0)
    {
        _4704 = NOVALUE;
        goto L2; // [13] 25
    }
    else{
        _4704 = NOVALUE;
    }

    /** get.e:301			get_ch()*/
    _16get_ch();

    /** get.e:302		end while*/
    goto L1; // [22] 6
L2: 

    /** get.e:304		if ch = -1 then -- string is made of whitespace only*/
    if (_16ch_8322 != -1)
    goto L3; // [29] 44

    /** get.e:305			return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = 0;
    _4706 = MAKE_SEQ(_1);
    DeRef(_s_8549);
    DeRef(_e_8550);
    return _4706;
L3: 

    /** get.e:308		while 1 do*/
L4: 

    /** get.e:309			if find(ch, START_NUMERIC) then*/
    _4707 = find_from(_16ch_8322, _16START_NUMERIC_8305, 1);
    if (_4707 == 0)
    {
        _4707 = NOVALUE;
        goto L5; // [60] 157
    }
    else{
        _4707 = NOVALUE;
    }

    /** get.e:310				e = get_number()*/
    _0 = _e_8550;
    _e_8550 = _16get_number();
    DeRef(_0);

    /** get.e:311				if e[1] != GET_IGNORE then -- either a number or something illegal was read, so exit: the other goto*/
    _2 = (object)SEQ_PTR(_e_8550);
    _4709 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _4709, -2)){
        _4709 = NOVALUE;
        goto L6; // [76] 87
    }
    _4709 = NOVALUE;

    /** get.e:312					return e*/
    DeRef(_s_8549);
    DeRef(_4706);
    _4706 = NOVALUE;
    return _e_8550;
L6: 

    /** get.e:314				skip_blanks()*/

    /** get.e:67		while find(ch, white_space) do*/
L7: 
    _skip_blanks_1__tmp_at88_8565 = find_from(_16ch_8322, _16white_space_8338, 1);
    if (_skip_blanks_1__tmp_at88_8565 == 0)
    {
        goto L8; // [101] 118
    }
    else{
    }

    /** get.e:68			get_ch()*/
    _16get_ch();

    /** get.e:69		end while*/
    goto L7; // [110] 94

    /** get.e:70	end procedure*/
    goto L8; // [115] 118
L8: 

    /** get.e:315				if ch=-1 or ch='}' then -- '}' is expected only in the "{--\n}" case*/
    _4711 = (_16ch_8322 == -1);
    if (_4711 != 0) {
        goto L9; // [128] 143
    }
    _4713 = (_16ch_8322 == 125);
    if (_4713 == 0)
    {
        DeRef(_4713);
        _4713 = NOVALUE;
        goto L4; // [139] 49
    }
    else{
        DeRef(_4713);
        _4713 = NOVALUE;
    }
L9: 

    /** get.e:316					return {GET_NOTHING, 0} -- just a comment*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -2;
    ((intptr_t *)_2)[2] = 0;
    _4714 = MAKE_SEQ(_1);
    DeRef(_s_8549);
    DeRef(_e_8550);
    DeRef(_4711);
    _4711 = NOVALUE;
    DeRef(_4706);
    _4706 = NOVALUE;
    return _4714;
    goto L4; // [154] 49
L5: 

    /** get.e:318			elsif ch = '{' then*/
    if (_16ch_8322 != 123)
    goto LA; // [161] 465

    /** get.e:320				s = {}*/
    RefDS(_5);
    DeRef(_s_8549);
    _s_8549 = _5;

    /** get.e:321				get_ch()*/
    _16get_ch();

    /** get.e:322				skip_blanks()*/

    /** get.e:67		while find(ch, white_space) do*/
LB: 
    _skip_blanks_1__tmp_at177_8574 = find_from(_16ch_8322, _16white_space_8338, 1);
    if (_skip_blanks_1__tmp_at177_8574 == 0)
    {
        goto LC; // [190] 207
    }
    else{
    }

    /** get.e:68			get_ch()*/
    _16get_ch();

    /** get.e:69		end while*/
    goto LB; // [199] 183

    /** get.e:70	end procedure*/
    goto LC; // [204] 207
LC: 

    /** get.e:323				if ch = '}' then -- empty sequence*/
    if (_16ch_8322 != 125)
    goto LD; // [213] 232

    /** get.e:324					get_ch()*/
    _16get_ch();

    /** get.e:325					return {GET_SUCCESS, s} -- empty sequence*/
    RefDS(_s_8549);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _s_8549;
    _4717 = MAKE_SEQ(_1);
    DeRefDS(_s_8549);
    DeRef(_e_8550);
    DeRef(_4711);
    _4711 = NOVALUE;
    DeRef(_4706);
    _4706 = NOVALUE;
    DeRef(_4714);
    _4714 = NOVALUE;
    return _4717;
LD: 

    /** get.e:328				while TRUE do -- read: comment(s), element, comment(s), comma and so on till it terminates or errors out*/
LE: 

    /** get.e:329					while 1 do -- read zero or more comments and an element*/
LF: 

    /** get.e:330						e = Get() -- read next element, using standard function*/
    _0 = _e_8550;
    _e_8550 = _16Get();
    DeRef(_0);

    /** get.e:331						e1 = e[1]*/
    _2 = (object)SEQ_PTR(_e_8550);
    _e1_8551 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_e1_8551))
    _e1_8551 = (object)DBL_PTR(_e1_8551)->dbl;

    /** get.e:332						if e1 = GET_SUCCESS then*/
    if (_e1_8551 != 0)
    goto L10; // [257] 278

    /** get.e:333							s = append(s, e[2])*/
    _2 = (object)SEQ_PTR(_e_8550);
    _4721 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_4721);
    Append(&_s_8549, _s_8549, _4721);
    _4721 = NOVALUE;

    /** get.e:334							exit  -- element read and added to result*/
    goto L11; // [273] 322
    goto LF; // [275] 242
L10: 

    /** get.e:335						elsif e1 != GET_IGNORE then*/
    if (_e1_8551 == -2)
    goto L12; // [280] 293

    /** get.e:336							return e*/
    DeRef(_s_8549);
    DeRef(_4711);
    _4711 = NOVALUE;
    DeRef(_4706);
    _4706 = NOVALUE;
    DeRef(_4714);
    _4714 = NOVALUE;
    DeRef(_4717);
    _4717 = NOVALUE;
    return _e_8550;
    goto LF; // [290] 242
L12: 

    /** get.e:338						elsif ch='}' then*/
    if (_16ch_8322 != 125)
    goto LF; // [297] 242

    /** get.e:339							get_ch()*/
    _16get_ch();

    /** get.e:340							return {GET_SUCCESS, s} -- empty sequence*/
    RefDS(_s_8549);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _s_8549;
    _4725 = MAKE_SEQ(_1);
    DeRefDS(_s_8549);
    DeRef(_e_8550);
    DeRef(_4711);
    _4711 = NOVALUE;
    DeRef(_4706);
    _4706 = NOVALUE;
    DeRef(_4714);
    _4714 = NOVALUE;
    DeRef(_4717);
    _4717 = NOVALUE;
    return _4725;

    /** get.e:342					end while*/
    goto LF; // [319] 242
L11: 

    /** get.e:344					while 1 do -- now read zero or more post element comments*/
L13: 

    /** get.e:345						skip_blanks()*/

    /** get.e:67		while find(ch, white_space) do*/
L14: 
    _skip_blanks_1__tmp_at328_8593 = find_from(_16ch_8322, _16white_space_8338, 1);
    if (_skip_blanks_1__tmp_at328_8593 == 0)
    {
        goto L15; // [341] 358
    }
    else{
    }

    /** get.e:68			get_ch()*/
    _16get_ch();

    /** get.e:69		end while*/
    goto L14; // [350] 334

    /** get.e:70	end procedure*/
    goto L15; // [355] 358
L15: 

    /** get.e:346						if ch = '}' then*/
    if (_16ch_8322 != 125)
    goto L16; // [364] 385

    /** get.e:347							get_ch()*/
    _16get_ch();

    /** get.e:348						return {GET_SUCCESS, s}*/
    RefDS(_s_8549);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _s_8549;
    _4727 = MAKE_SEQ(_1);
    DeRefDS(_s_8549);
    DeRef(_e_8550);
    DeRef(_4711);
    _4711 = NOVALUE;
    DeRef(_4706);
    _4706 = NOVALUE;
    DeRef(_4714);
    _4714 = NOVALUE;
    DeRef(_4717);
    _4717 = NOVALUE;
    DeRef(_4725);
    _4725 = NOVALUE;
    return _4727;
    goto L13; // [382] 327
L16: 

    /** get.e:349						elsif ch!='-' then*/
    if (_16ch_8322 == 45)
    goto L17; // [389] 400

    /** get.e:350							exit*/
    goto L18; // [395] 434
    goto L13; // [397] 327
L17: 

    /** get.e:352							e = get_number() -- reads anything starting with '-'*/
    _0 = _e_8550;
    _e_8550 = _16get_number();
    DeRef(_0);

    /** get.e:353							if e[1] != GET_IGNORE then  -- it wasn't a comment, this is illegal*/
    _2 = (object)SEQ_PTR(_e_8550);
    _4730 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _4730, -2)){
        _4730 = NOVALUE;
        goto L13; // [413] 327
    }
    _4730 = NOVALUE;

    /** get.e:354								return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _4732 = MAKE_SEQ(_1);
    DeRef(_s_8549);
    DeRefDS(_e_8550);
    DeRef(_4711);
    _4711 = NOVALUE;
    DeRef(_4706);
    _4706 = NOVALUE;
    DeRef(_4714);
    _4714 = NOVALUE;
    DeRef(_4717);
    _4717 = NOVALUE;
    DeRef(_4725);
    _4725 = NOVALUE;
    DeRef(_4727);
    _4727 = NOVALUE;
    return _4732;

    /** get.e:358				end while*/
    goto L13; // [431] 327
L18: 

    /** get.e:359					if ch != ',' then*/
    if (_16ch_8322 == 44)
    goto L19; // [438] 453

    /** get.e:360					return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _4734 = MAKE_SEQ(_1);
    DeRef(_s_8549);
    DeRef(_e_8550);
    DeRef(_4711);
    _4711 = NOVALUE;
    DeRef(_4706);
    _4706 = NOVALUE;
    DeRef(_4714);
    _4714 = NOVALUE;
    DeRef(_4717);
    _4717 = NOVALUE;
    DeRef(_4732);
    _4732 = NOVALUE;
    DeRef(_4725);
    _4725 = NOVALUE;
    DeRef(_4727);
    _4727 = NOVALUE;
    return _4734;
L19: 

    /** get.e:362				get_ch() -- skip comma*/
    _16get_ch();

    /** get.e:363				end while*/
    goto LE; // [459] 237
    goto L4; // [462] 49
LA: 

    /** get.e:365			elsif ch = '\"' then*/
    if (_16ch_8322 != 34)
    goto L1A; // [469] 485

    /** get.e:366				return get_string()*/
    _4736 = _16get_string();
    DeRef(_s_8549);
    DeRef(_e_8550);
    DeRef(_4711);
    _4711 = NOVALUE;
    DeRef(_4706);
    _4706 = NOVALUE;
    DeRef(_4734);
    _4734 = NOVALUE;
    DeRef(_4714);
    _4714 = NOVALUE;
    DeRef(_4717);
    _4717 = NOVALUE;
    DeRef(_4732);
    _4732 = NOVALUE;
    DeRef(_4725);
    _4725 = NOVALUE;
    DeRef(_4727);
    _4727 = NOVALUE;
    return _4736;
    goto L4; // [482] 49
L1A: 

    /** get.e:367			elsif ch = '`' then*/
    if (_16ch_8322 != 96)
    goto L1B; // [489] 506

    /** get.e:368				return get_heredoc("`")*/
    RefDS(_4738);
    _4739 = _16get_heredoc(_4738);
    DeRef(_s_8549);
    DeRef(_e_8550);
    DeRef(_4711);
    _4711 = NOVALUE;
    DeRef(_4706);
    _4706 = NOVALUE;
    DeRef(_4734);
    _4734 = NOVALUE;
    DeRef(_4714);
    _4714 = NOVALUE;
    DeRef(_4717);
    _4717 = NOVALUE;
    DeRef(_4736);
    _4736 = NOVALUE;
    DeRef(_4732);
    _4732 = NOVALUE;
    DeRef(_4725);
    _4725 = NOVALUE;
    DeRef(_4727);
    _4727 = NOVALUE;
    return _4739;
    goto L4; // [503] 49
L1B: 

    /** get.e:369			elsif ch = '\'' then*/
    if (_16ch_8322 != 39)
    goto L1C; // [510] 526

    /** get.e:370				return get_qchar()*/
    _4741 = _16get_qchar();
    DeRef(_s_8549);
    DeRef(_e_8550);
    DeRef(_4711);
    _4711 = NOVALUE;
    DeRef(_4706);
    _4706 = NOVALUE;
    DeRef(_4734);
    _4734 = NOVALUE;
    DeRef(_4714);
    _4714 = NOVALUE;
    DeRef(_4717);
    _4717 = NOVALUE;
    DeRef(_4736);
    _4736 = NOVALUE;
    DeRef(_4732);
    _4732 = NOVALUE;
    DeRef(_4725);
    _4725 = NOVALUE;
    DeRef(_4727);
    _4727 = NOVALUE;
    DeRef(_4739);
    _4739 = NOVALUE;
    return _4741;
    goto L4; // [523] 49
L1C: 

    /** get.e:372				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _4742 = MAKE_SEQ(_1);
    DeRef(_s_8549);
    DeRef(_e_8550);
    DeRef(_4711);
    _4711 = NOVALUE;
    DeRef(_4741);
    _4741 = NOVALUE;
    DeRef(_4706);
    _4706 = NOVALUE;
    DeRef(_4734);
    _4734 = NOVALUE;
    DeRef(_4714);
    _4714 = NOVALUE;
    DeRef(_4717);
    _4717 = NOVALUE;
    DeRef(_4736);
    _4736 = NOVALUE;
    DeRef(_4732);
    _4732 = NOVALUE;
    DeRef(_4725);
    _4725 = NOVALUE;
    DeRef(_4727);
    _4727 = NOVALUE;
    DeRef(_4739);
    _4739 = NOVALUE;
    return _4742;

    /** get.e:376		end while*/
    goto L4; // [539] 49
    ;
}


object _16Get2()
{
    object _skip_blanks_1__tmp_at464_8694 = NOVALUE;
    object _skip_blanks_1__tmp_at233_8661 = NOVALUE;
    object _s_8623 = NOVALUE;
    object _e_8624 = NOVALUE;
    object _e1_8625 = NOVALUE;
    object _offset_8626 = NOVALUE;
    object _4842 = NOVALUE;
    object _4841 = NOVALUE;
    object _4840 = NOVALUE;
    object _4839 = NOVALUE;
    object _4838 = NOVALUE;
    object _4837 = NOVALUE;
    object _4836 = NOVALUE;
    object _4835 = NOVALUE;
    object _4834 = NOVALUE;
    object _4833 = NOVALUE;
    object _4832 = NOVALUE;
    object _4829 = NOVALUE;
    object _4828 = NOVALUE;
    object _4827 = NOVALUE;
    object _4826 = NOVALUE;
    object _4825 = NOVALUE;
    object _4824 = NOVALUE;
    object _4821 = NOVALUE;
    object _4820 = NOVALUE;
    object _4819 = NOVALUE;
    object _4818 = NOVALUE;
    object _4817 = NOVALUE;
    object _4816 = NOVALUE;
    object _4813 = NOVALUE;
    object _4812 = NOVALUE;
    object _4811 = NOVALUE;
    object _4810 = NOVALUE;
    object _4809 = NOVALUE;
    object _4807 = NOVALUE;
    object _4806 = NOVALUE;
    object _4805 = NOVALUE;
    object _4804 = NOVALUE;
    object _4803 = NOVALUE;
    object _4801 = NOVALUE;
    object _4798 = NOVALUE;
    object _4797 = NOVALUE;
    object _4796 = NOVALUE;
    object _4795 = NOVALUE;
    object _4794 = NOVALUE;
    object _4792 = NOVALUE;
    object _4791 = NOVALUE;
    object _4790 = NOVALUE;
    object _4789 = NOVALUE;
    object _4788 = NOVALUE;
    object _4786 = NOVALUE;
    object _4785 = NOVALUE;
    object _4784 = NOVALUE;
    object _4783 = NOVALUE;
    object _4782 = NOVALUE;
    object _4781 = NOVALUE;
    object _4778 = NOVALUE;
    object _4774 = NOVALUE;
    object _4773 = NOVALUE;
    object _4772 = NOVALUE;
    object _4771 = NOVALUE;
    object _4770 = NOVALUE;
    object _4767 = NOVALUE;
    object _4766 = NOVALUE;
    object _4765 = NOVALUE;
    object _4764 = NOVALUE;
    object _4763 = NOVALUE;
    object _4761 = NOVALUE;
    object _4760 = NOVALUE;
    object _4759 = NOVALUE;
    object _4758 = NOVALUE;
    object _4757 = NOVALUE;
    object _4756 = NOVALUE;
    object _4754 = NOVALUE;
    object _4752 = NOVALUE;
    object _4750 = NOVALUE;
    object _4749 = NOVALUE;
    object _4748 = NOVALUE;
    object _4747 = NOVALUE;
    object _4746 = NOVALUE;
    object _4744 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:392		offset = string_next-1*/
    _offset_8626 = _16string_next_8321 - 1;

    /** get.e:393		get_ch()*/
    _16get_ch();

    /** get.e:394		while find(ch, white_space) do*/
L1: 
    _4744 = find_from(_16ch_8322, _16white_space_8338, 1);
    if (_4744 == 0)
    {
        _4744 = NOVALUE;
        goto L2; // [25] 37
    }
    else{
        _4744 = NOVALUE;
    }

    /** get.e:395			get_ch()*/
    _16get_ch();

    /** get.e:396		end while*/
    goto L1; // [34] 18
L2: 

    /** get.e:398		if ch = -1 then -- string is made of whitespace only*/
    if (_16ch_8322 != -1)
    goto L3; // [41] 75

    /** get.e:399			return {GET_EOF, 0, string_next-1-offset ,string_next-1}*/
    _4746 = _16string_next_8321 - 1;
    if ((object)((uintptr_t)_4746 +(uintptr_t) HIGH_BITS) >= 0){
        _4746 = NewDouble((eudouble)_4746);
    }
    if (IS_ATOM_INT(_4746)) {
        _4747 = _4746 - _offset_8626;
        if ((object)((uintptr_t)_4747 +(uintptr_t) HIGH_BITS) >= 0){
            _4747 = NewDouble((eudouble)_4747);
        }
    }
    else {
        _4747 = NewDouble(DBL_PTR(_4746)->dbl - (eudouble)_offset_8626);
    }
    DeRef(_4746);
    _4746 = NOVALUE;
    _4748 = _16string_next_8321 - 1;
    if ((object)((uintptr_t)_4748 +(uintptr_t) HIGH_BITS) >= 0){
        _4748 = NewDouble((eudouble)_4748);
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = -1;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = _4747;
    ((intptr_t*)_2)[4] = _4748;
    _4749 = MAKE_SEQ(_1);
    _4748 = NOVALUE;
    _4747 = NOVALUE;
    DeRef(_s_8623);
    DeRef(_e_8624);
    return _4749;
L3: 

    /** get.e:402		leading_whitespace = string_next-2-offset -- index of the last whitespace: string_next points past the first non whitespace*/
    _4750 = _16string_next_8321 - 2;
    if ((object)((uintptr_t)_4750 +(uintptr_t) HIGH_BITS) >= 0){
        _4750 = NewDouble((eudouble)_4750);
    }
    if (IS_ATOM_INT(_4750)) {
        _16leading_whitespace_8620 = _4750 - _offset_8626;
    }
    else {
        _16leading_whitespace_8620 = NewDouble(DBL_PTR(_4750)->dbl - (eudouble)_offset_8626);
    }
    DeRef(_4750);
    _4750 = NOVALUE;
    if (!IS_ATOM_INT(_16leading_whitespace_8620)) {
        _1 = (object)(DBL_PTR(_16leading_whitespace_8620)->dbl);
        DeRefDS(_16leading_whitespace_8620);
        _16leading_whitespace_8620 = _1;
    }

    /** get.e:404		while 1 do*/
L4: 

    /** get.e:405			if find(ch, START_NUMERIC) then*/
    _4752 = find_from(_16ch_8322, _16START_NUMERIC_8305, 1);
    if (_4752 == 0)
    {
        _4752 = NOVALUE;
        goto L5; // [105] 213
    }
    else{
        _4752 = NOVALUE;
    }

    /** get.e:406				e = get_number()*/
    _0 = _e_8624;
    _e_8624 = _16get_number();
    DeRef(_0);

    /** get.e:407				if e[1] != GET_IGNORE then -- either a number or something illegal was read, so exit: the other goto*/
    _2 = (object)SEQ_PTR(_e_8624);
    _4754 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _4754, -2)){
        _4754 = NOVALUE;
        goto L6; // [121] 162
    }
    _4754 = NOVALUE;

    /** get.e:408					return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _4756 = _16string_next_8321 - 1;
    if ((object)((uintptr_t)_4756 +(uintptr_t) HIGH_BITS) >= 0){
        _4756 = NewDouble((eudouble)_4756);
    }
    if (IS_ATOM_INT(_4756)) {
        _4757 = _4756 - _offset_8626;
        if ((object)((uintptr_t)_4757 +(uintptr_t) HIGH_BITS) >= 0){
            _4757 = NewDouble((eudouble)_4757);
        }
    }
    else {
        _4757 = NewDouble(DBL_PTR(_4756)->dbl - (eudouble)_offset_8626);
    }
    DeRef(_4756);
    _4756 = NOVALUE;
    _4758 = (_16ch_8322 != -1);
    if (IS_ATOM_INT(_4757)) {
        _4759 = _4757 - _4758;
        if ((object)((uintptr_t)_4759 +(uintptr_t) HIGH_BITS) >= 0){
            _4759 = NewDouble((eudouble)_4759);
        }
    }
    else {
        _4759 = NewDouble(DBL_PTR(_4757)->dbl - (eudouble)_4758);
    }
    DeRef(_4757);
    _4757 = NOVALUE;
    _4758 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _4759;
    ((intptr_t *)_2)[2] = _16leading_whitespace_8620;
    _4760 = MAKE_SEQ(_1);
    _4759 = NOVALUE;
    Concat((object_ptr)&_4761, _e_8624, _4760);
    DeRefDS(_4760);
    _4760 = NOVALUE;
    DeRef(_s_8623);
    DeRefDS(_e_8624);
    DeRef(_4749);
    _4749 = NOVALUE;
    return _4761;
L6: 

    /** get.e:410				get_ch()*/
    _16get_ch();

    /** get.e:411				if ch=-1 then*/
    if (_16ch_8322 != -1)
    goto L4; // [170] 94

    /** get.e:412					return {GET_NOTHING, 0, string_next-1-offset-(ch!=-1), leading_whitespace} -- empty sequence*/
    _4763 = _16string_next_8321 - 1;
    if ((object)((uintptr_t)_4763 +(uintptr_t) HIGH_BITS) >= 0){
        _4763 = NewDouble((eudouble)_4763);
    }
    if (IS_ATOM_INT(_4763)) {
        _4764 = _4763 - _offset_8626;
        if ((object)((uintptr_t)_4764 +(uintptr_t) HIGH_BITS) >= 0){
            _4764 = NewDouble((eudouble)_4764);
        }
    }
    else {
        _4764 = NewDouble(DBL_PTR(_4763)->dbl - (eudouble)_offset_8626);
    }
    DeRef(_4763);
    _4763 = NOVALUE;
    _4765 = (_16ch_8322 != -1);
    if (IS_ATOM_INT(_4764)) {
        _4766 = _4764 - _4765;
        if ((object)((uintptr_t)_4766 +(uintptr_t) HIGH_BITS) >= 0){
            _4766 = NewDouble((eudouble)_4766);
        }
    }
    else {
        _4766 = NewDouble(DBL_PTR(_4764)->dbl - (eudouble)_4765);
    }
    DeRef(_4764);
    _4764 = NOVALUE;
    _4765 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = -2;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = _4766;
    ((intptr_t*)_2)[4] = _16leading_whitespace_8620;
    _4767 = MAKE_SEQ(_1);
    _4766 = NOVALUE;
    DeRef(_s_8623);
    DeRef(_e_8624);
    DeRef(_4749);
    _4749 = NOVALUE;
    DeRef(_4761);
    _4761 = NOVALUE;
    return _4767;
    goto L4; // [210] 94
L5: 

    /** get.e:415			elsif ch = '{' then*/
    if (_16ch_8322 != 123)
    goto L7; // [217] 676

    /** get.e:417				s = {}*/
    RefDS(_5);
    DeRef(_s_8623);
    _s_8623 = _5;

    /** get.e:418				get_ch()*/
    _16get_ch();

    /** get.e:419				skip_blanks()*/

    /** get.e:67		while find(ch, white_space) do*/
L8: 
    _skip_blanks_1__tmp_at233_8661 = find_from(_16ch_8322, _16white_space_8338, 1);
    if (_skip_blanks_1__tmp_at233_8661 == 0)
    {
        goto L9; // [246] 263
    }
    else{
    }

    /** get.e:68			get_ch()*/
    _16get_ch();

    /** get.e:69		end while*/
    goto L8; // [255] 239

    /** get.e:70	end procedure*/
    goto L9; // [260] 263
L9: 

    /** get.e:420				if ch = '}' then -- empty sequence*/
    if (_16ch_8322 != 125)
    goto LA; // [269] 313

    /** get.e:421					get_ch()*/
    _16get_ch();

    /** get.e:422					return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1), leading_whitespace} -- empty sequence*/
    _4770 = _16string_next_8321 - 1;
    if ((object)((uintptr_t)_4770 +(uintptr_t) HIGH_BITS) >= 0){
        _4770 = NewDouble((eudouble)_4770);
    }
    if (IS_ATOM_INT(_4770)) {
        _4771 = _4770 - _offset_8626;
        if ((object)((uintptr_t)_4771 +(uintptr_t) HIGH_BITS) >= 0){
            _4771 = NewDouble((eudouble)_4771);
        }
    }
    else {
        _4771 = NewDouble(DBL_PTR(_4770)->dbl - (eudouble)_offset_8626);
    }
    DeRef(_4770);
    _4770 = NOVALUE;
    _4772 = (_16ch_8322 != -1);
    if (IS_ATOM_INT(_4771)) {
        _4773 = _4771 - _4772;
        if ((object)((uintptr_t)_4773 +(uintptr_t) HIGH_BITS) >= 0){
            _4773 = NewDouble((eudouble)_4773);
        }
    }
    else {
        _4773 = NewDouble(DBL_PTR(_4771)->dbl - (eudouble)_4772);
    }
    DeRef(_4771);
    _4771 = NOVALUE;
    _4772 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    RefDS(_s_8623);
    ((intptr_t*)_2)[2] = _s_8623;
    ((intptr_t*)_2)[3] = _4773;
    ((intptr_t*)_2)[4] = _16leading_whitespace_8620;
    _4774 = MAKE_SEQ(_1);
    _4773 = NOVALUE;
    DeRefDS(_s_8623);
    DeRef(_e_8624);
    DeRef(_4767);
    _4767 = NOVALUE;
    DeRef(_4749);
    _4749 = NOVALUE;
    DeRef(_4761);
    _4761 = NOVALUE;
    return _4774;
LA: 

    /** get.e:425				while TRUE do -- read: comment(s), element, comment(s), comma and so on till it terminates or errors out*/
LB: 

    /** get.e:426					while 1 do -- read zero or more comments and an element*/
LC: 

    /** get.e:427						e = Get() -- read next element, using standard function*/
    _0 = _e_8624;
    _e_8624 = _16Get();
    DeRef(_0);

    /** get.e:428						e1 = e[1]*/
    _2 = (object)SEQ_PTR(_e_8624);
    _e1_8625 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_e1_8625))
    _e1_8625 = (object)DBL_PTR(_e1_8625)->dbl;

    /** get.e:429						if e1 = GET_SUCCESS then*/
    if (_e1_8625 != 0)
    goto LD; // [338] 359

    /** get.e:430							s = append(s, e[2])*/
    _2 = (object)SEQ_PTR(_e_8624);
    _4778 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_4778);
    Append(&_s_8623, _s_8623, _4778);
    _4778 = NOVALUE;

    /** get.e:431							exit  -- element read and added to result*/
    goto LE; // [354] 458
    goto LC; // [356] 323
LD: 

    /** get.e:432						elsif e1 != GET_IGNORE then*/
    if (_e1_8625 == -2)
    goto LF; // [361] 404

    /** get.e:433							return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _4781 = _16string_next_8321 - 1;
    if ((object)((uintptr_t)_4781 +(uintptr_t) HIGH_BITS) >= 0){
        _4781 = NewDouble((eudouble)_4781);
    }
    if (IS_ATOM_INT(_4781)) {
        _4782 = _4781 - _offset_8626;
        if ((object)((uintptr_t)_4782 +(uintptr_t) HIGH_BITS) >= 0){
            _4782 = NewDouble((eudouble)_4782);
        }
    }
    else {
        _4782 = NewDouble(DBL_PTR(_4781)->dbl - (eudouble)_offset_8626);
    }
    DeRef(_4781);
    _4781 = NOVALUE;
    _4783 = (_16ch_8322 != -1);
    if (IS_ATOM_INT(_4782)) {
        _4784 = _4782 - _4783;
        if ((object)((uintptr_t)_4784 +(uintptr_t) HIGH_BITS) >= 0){
            _4784 = NewDouble((eudouble)_4784);
        }
    }
    else {
        _4784 = NewDouble(DBL_PTR(_4782)->dbl - (eudouble)_4783);
    }
    DeRef(_4782);
    _4782 = NOVALUE;
    _4783 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _4784;
    ((intptr_t *)_2)[2] = _16leading_whitespace_8620;
    _4785 = MAKE_SEQ(_1);
    _4784 = NOVALUE;
    Concat((object_ptr)&_4786, _e_8624, _4785);
    DeRefDS(_4785);
    _4785 = NOVALUE;
    DeRef(_s_8623);
    DeRefDS(_e_8624);
    DeRef(_4767);
    _4767 = NOVALUE;
    DeRef(_4749);
    _4749 = NOVALUE;
    DeRef(_4761);
    _4761 = NOVALUE;
    DeRef(_4774);
    _4774 = NOVALUE;
    return _4786;
    goto LC; // [401] 323
LF: 

    /** get.e:435						elsif ch='}' then*/
    if (_16ch_8322 != 125)
    goto LC; // [408] 323

    /** get.e:436							get_ch()*/
    _16get_ch();

    /** get.e:437							return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1),leading_whitespace} -- empty sequence*/
    _4788 = _16string_next_8321 - 1;
    if ((object)((uintptr_t)_4788 +(uintptr_t) HIGH_BITS) >= 0){
        _4788 = NewDouble((eudouble)_4788);
    }
    if (IS_ATOM_INT(_4788)) {
        _4789 = _4788 - _offset_8626;
        if ((object)((uintptr_t)_4789 +(uintptr_t) HIGH_BITS) >= 0){
            _4789 = NewDouble((eudouble)_4789);
        }
    }
    else {
        _4789 = NewDouble(DBL_PTR(_4788)->dbl - (eudouble)_offset_8626);
    }
    DeRef(_4788);
    _4788 = NOVALUE;
    _4790 = (_16ch_8322 != -1);
    if (IS_ATOM_INT(_4789)) {
        _4791 = _4789 - _4790;
        if ((object)((uintptr_t)_4791 +(uintptr_t) HIGH_BITS) >= 0){
            _4791 = NewDouble((eudouble)_4791);
        }
    }
    else {
        _4791 = NewDouble(DBL_PTR(_4789)->dbl - (eudouble)_4790);
    }
    DeRef(_4789);
    _4789 = NOVALUE;
    _4790 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    RefDS(_s_8623);
    ((intptr_t*)_2)[2] = _s_8623;
    ((intptr_t*)_2)[3] = _4791;
    ((intptr_t*)_2)[4] = _16leading_whitespace_8620;
    _4792 = MAKE_SEQ(_1);
    _4791 = NOVALUE;
    DeRefDS(_s_8623);
    DeRef(_e_8624);
    DeRef(_4767);
    _4767 = NOVALUE;
    DeRef(_4786);
    _4786 = NOVALUE;
    DeRef(_4749);
    _4749 = NOVALUE;
    DeRef(_4761);
    _4761 = NOVALUE;
    DeRef(_4774);
    _4774 = NOVALUE;
    return _4792;

    /** get.e:439					end while*/
    goto LC; // [455] 323
LE: 

    /** get.e:441					while 1 do -- now read zero or more post element comments*/
L10: 

    /** get.e:442						skip_blanks()*/

    /** get.e:67		while find(ch, white_space) do*/
L11: 
    _skip_blanks_1__tmp_at464_8694 = find_from(_16ch_8322, _16white_space_8338, 1);
    if (_skip_blanks_1__tmp_at464_8694 == 0)
    {
        goto L12; // [477] 494
    }
    else{
    }

    /** get.e:68			get_ch()*/
    _16get_ch();

    /** get.e:69		end while*/
    goto L11; // [486] 470

    /** get.e:70	end procedure*/
    goto L12; // [491] 494
L12: 

    /** get.e:443						if ch = '}' then*/
    if (_16ch_8322 != 125)
    goto L13; // [500] 546

    /** get.e:444							get_ch()*/
    _16get_ch();

    /** get.e:445						return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _4794 = _16string_next_8321 - 1;
    if ((object)((uintptr_t)_4794 +(uintptr_t) HIGH_BITS) >= 0){
        _4794 = NewDouble((eudouble)_4794);
    }
    if (IS_ATOM_INT(_4794)) {
        _4795 = _4794 - _offset_8626;
        if ((object)((uintptr_t)_4795 +(uintptr_t) HIGH_BITS) >= 0){
            _4795 = NewDouble((eudouble)_4795);
        }
    }
    else {
        _4795 = NewDouble(DBL_PTR(_4794)->dbl - (eudouble)_offset_8626);
    }
    DeRef(_4794);
    _4794 = NOVALUE;
    _4796 = (_16ch_8322 != -1);
    if (IS_ATOM_INT(_4795)) {
        _4797 = _4795 - _4796;
        if ((object)((uintptr_t)_4797 +(uintptr_t) HIGH_BITS) >= 0){
            _4797 = NewDouble((eudouble)_4797);
        }
    }
    else {
        _4797 = NewDouble(DBL_PTR(_4795)->dbl - (eudouble)_4796);
    }
    DeRef(_4795);
    _4795 = NOVALUE;
    _4796 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    RefDS(_s_8623);
    ((intptr_t*)_2)[2] = _s_8623;
    ((intptr_t*)_2)[3] = _4797;
    ((intptr_t*)_2)[4] = _16leading_whitespace_8620;
    _4798 = MAKE_SEQ(_1);
    _4797 = NOVALUE;
    DeRefDS(_s_8623);
    DeRef(_e_8624);
    DeRef(_4767);
    _4767 = NOVALUE;
    DeRef(_4786);
    _4786 = NOVALUE;
    DeRef(_4792);
    _4792 = NOVALUE;
    DeRef(_4749);
    _4749 = NOVALUE;
    DeRef(_4761);
    _4761 = NOVALUE;
    DeRef(_4774);
    _4774 = NOVALUE;
    return _4798;
    goto L10; // [543] 463
L13: 

    /** get.e:446						elsif ch!='-' then*/
    if (_16ch_8322 == 45)
    goto L14; // [550] 561

    /** get.e:447							exit*/
    goto L15; // [556] 620
    goto L10; // [558] 463
L14: 

    /** get.e:449							e = get_number() -- reads anything starting with '-'*/
    _0 = _e_8624;
    _e_8624 = _16get_number();
    DeRef(_0);

    /** get.e:450							if e[1] != GET_IGNORE then  -- it was not a comment, this is illegal*/
    _2 = (object)SEQ_PTR(_e_8624);
    _4801 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _4801, -2)){
        _4801 = NOVALUE;
        goto L10; // [574] 463
    }
    _4801 = NOVALUE;

    /** get.e:451								return {GET_FAIL, 0, string_next-1-offset-(ch!=-1),leading_whitespace}*/
    _4803 = _16string_next_8321 - 1;
    if ((object)((uintptr_t)_4803 +(uintptr_t) HIGH_BITS) >= 0){
        _4803 = NewDouble((eudouble)_4803);
    }
    if (IS_ATOM_INT(_4803)) {
        _4804 = _4803 - _offset_8626;
        if ((object)((uintptr_t)_4804 +(uintptr_t) HIGH_BITS) >= 0){
            _4804 = NewDouble((eudouble)_4804);
        }
    }
    else {
        _4804 = NewDouble(DBL_PTR(_4803)->dbl - (eudouble)_offset_8626);
    }
    DeRef(_4803);
    _4803 = NOVALUE;
    _4805 = (_16ch_8322 != -1);
    if (IS_ATOM_INT(_4804)) {
        _4806 = _4804 - _4805;
        if ((object)((uintptr_t)_4806 +(uintptr_t) HIGH_BITS) >= 0){
            _4806 = NewDouble((eudouble)_4806);
        }
    }
    else {
        _4806 = NewDouble(DBL_PTR(_4804)->dbl - (eudouble)_4805);
    }
    DeRef(_4804);
    _4804 = NOVALUE;
    _4805 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = _4806;
    ((intptr_t*)_2)[4] = _16leading_whitespace_8620;
    _4807 = MAKE_SEQ(_1);
    _4806 = NOVALUE;
    DeRef(_s_8623);
    DeRefDS(_e_8624);
    DeRef(_4798);
    _4798 = NOVALUE;
    DeRef(_4767);
    _4767 = NOVALUE;
    DeRef(_4786);
    _4786 = NOVALUE;
    DeRef(_4792);
    _4792 = NOVALUE;
    DeRef(_4749);
    _4749 = NOVALUE;
    DeRef(_4761);
    _4761 = NOVALUE;
    DeRef(_4774);
    _4774 = NOVALUE;
    return _4807;

    /** get.e:455				end while*/
    goto L10; // [617] 463
L15: 

    /** get.e:456					if ch != ',' then*/
    if (_16ch_8322 == 44)
    goto L16; // [624] 664

    /** get.e:457					return {GET_FAIL, 0, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _4809 = _16string_next_8321 - 1;
    if ((object)((uintptr_t)_4809 +(uintptr_t) HIGH_BITS) >= 0){
        _4809 = NewDouble((eudouble)_4809);
    }
    if (IS_ATOM_INT(_4809)) {
        _4810 = _4809 - _offset_8626;
        if ((object)((uintptr_t)_4810 +(uintptr_t) HIGH_BITS) >= 0){
            _4810 = NewDouble((eudouble)_4810);
        }
    }
    else {
        _4810 = NewDouble(DBL_PTR(_4809)->dbl - (eudouble)_offset_8626);
    }
    DeRef(_4809);
    _4809 = NOVALUE;
    _4811 = (_16ch_8322 != -1);
    if (IS_ATOM_INT(_4810)) {
        _4812 = _4810 - _4811;
        if ((object)((uintptr_t)_4812 +(uintptr_t) HIGH_BITS) >= 0){
            _4812 = NewDouble((eudouble)_4812);
        }
    }
    else {
        _4812 = NewDouble(DBL_PTR(_4810)->dbl - (eudouble)_4811);
    }
    DeRef(_4810);
    _4810 = NOVALUE;
    _4811 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = _4812;
    ((intptr_t*)_2)[4] = _16leading_whitespace_8620;
    _4813 = MAKE_SEQ(_1);
    _4812 = NOVALUE;
    DeRef(_s_8623);
    DeRef(_e_8624);
    DeRef(_4798);
    _4798 = NOVALUE;
    DeRef(_4767);
    _4767 = NOVALUE;
    DeRef(_4786);
    _4786 = NOVALUE;
    DeRef(_4792);
    _4792 = NOVALUE;
    DeRef(_4749);
    _4749 = NOVALUE;
    DeRef(_4761);
    _4761 = NOVALUE;
    DeRef(_4774);
    _4774 = NOVALUE;
    DeRef(_4807);
    _4807 = NOVALUE;
    return _4813;
L16: 

    /** get.e:459				get_ch() -- skip comma*/
    _16get_ch();

    /** get.e:460				end while*/
    goto LB; // [670] 318
    goto L4; // [673] 94
L7: 

    /** get.e:462			elsif ch = '\"' then*/
    if (_16ch_8322 != 34)
    goto L17; // [680] 730

    /** get.e:463				e = get_string()*/
    _0 = _e_8624;
    _e_8624 = _16get_string();
    DeRef(_0);

    /** get.e:464				return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _4816 = _16string_next_8321 - 1;
    if ((object)((uintptr_t)_4816 +(uintptr_t) HIGH_BITS) >= 0){
        _4816 = NewDouble((eudouble)_4816);
    }
    if (IS_ATOM_INT(_4816)) {
        _4817 = _4816 - _offset_8626;
        if ((object)((uintptr_t)_4817 +(uintptr_t) HIGH_BITS) >= 0){
            _4817 = NewDouble((eudouble)_4817);
        }
    }
    else {
        _4817 = NewDouble(DBL_PTR(_4816)->dbl - (eudouble)_offset_8626);
    }
    DeRef(_4816);
    _4816 = NOVALUE;
    _4818 = (_16ch_8322 != -1);
    if (IS_ATOM_INT(_4817)) {
        _4819 = _4817 - _4818;
        if ((object)((uintptr_t)_4819 +(uintptr_t) HIGH_BITS) >= 0){
            _4819 = NewDouble((eudouble)_4819);
        }
    }
    else {
        _4819 = NewDouble(DBL_PTR(_4817)->dbl - (eudouble)_4818);
    }
    DeRef(_4817);
    _4817 = NOVALUE;
    _4818 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _4819;
    ((intptr_t *)_2)[2] = _16leading_whitespace_8620;
    _4820 = MAKE_SEQ(_1);
    _4819 = NOVALUE;
    Concat((object_ptr)&_4821, _e_8624, _4820);
    DeRefDS(_4820);
    _4820 = NOVALUE;
    DeRef(_s_8623);
    DeRefDS(_e_8624);
    DeRef(_4798);
    _4798 = NOVALUE;
    DeRef(_4767);
    _4767 = NOVALUE;
    DeRef(_4786);
    _4786 = NOVALUE;
    DeRef(_4792);
    _4792 = NOVALUE;
    DeRef(_4813);
    _4813 = NOVALUE;
    DeRef(_4749);
    _4749 = NOVALUE;
    DeRef(_4761);
    _4761 = NOVALUE;
    DeRef(_4774);
    _4774 = NOVALUE;
    DeRef(_4807);
    _4807 = NOVALUE;
    return _4821;
    goto L4; // [727] 94
L17: 

    /** get.e:465			elsif ch = '`' then*/
    if (_16ch_8322 != 96)
    goto L18; // [734] 785

    /** get.e:466				e = get_heredoc("`")*/
    RefDS(_4738);
    _0 = _e_8624;
    _e_8624 = _16get_heredoc(_4738);
    DeRef(_0);

    /** get.e:467				return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _4824 = _16string_next_8321 - 1;
    if ((object)((uintptr_t)_4824 +(uintptr_t) HIGH_BITS) >= 0){
        _4824 = NewDouble((eudouble)_4824);
    }
    if (IS_ATOM_INT(_4824)) {
        _4825 = _4824 - _offset_8626;
        if ((object)((uintptr_t)_4825 +(uintptr_t) HIGH_BITS) >= 0){
            _4825 = NewDouble((eudouble)_4825);
        }
    }
    else {
        _4825 = NewDouble(DBL_PTR(_4824)->dbl - (eudouble)_offset_8626);
    }
    DeRef(_4824);
    _4824 = NOVALUE;
    _4826 = (_16ch_8322 != -1);
    if (IS_ATOM_INT(_4825)) {
        _4827 = _4825 - _4826;
        if ((object)((uintptr_t)_4827 +(uintptr_t) HIGH_BITS) >= 0){
            _4827 = NewDouble((eudouble)_4827);
        }
    }
    else {
        _4827 = NewDouble(DBL_PTR(_4825)->dbl - (eudouble)_4826);
    }
    DeRef(_4825);
    _4825 = NOVALUE;
    _4826 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _4827;
    ((intptr_t *)_2)[2] = _16leading_whitespace_8620;
    _4828 = MAKE_SEQ(_1);
    _4827 = NOVALUE;
    Concat((object_ptr)&_4829, _e_8624, _4828);
    DeRefDS(_4828);
    _4828 = NOVALUE;
    DeRef(_s_8623);
    DeRefDS(_e_8624);
    DeRef(_4798);
    _4798 = NOVALUE;
    DeRef(_4767);
    _4767 = NOVALUE;
    DeRef(_4786);
    _4786 = NOVALUE;
    DeRef(_4792);
    _4792 = NOVALUE;
    DeRef(_4813);
    _4813 = NOVALUE;
    DeRef(_4749);
    _4749 = NOVALUE;
    DeRef(_4761);
    _4761 = NOVALUE;
    DeRef(_4821);
    _4821 = NOVALUE;
    DeRef(_4774);
    _4774 = NOVALUE;
    DeRef(_4807);
    _4807 = NOVALUE;
    return _4829;
    goto L4; // [782] 94
L18: 

    /** get.e:468			elsif ch = '\'' then*/
    if (_16ch_8322 != 39)
    goto L19; // [789] 839

    /** get.e:469				e = get_qchar()*/
    _0 = _e_8624;
    _e_8624 = _16get_qchar();
    DeRef(_0);

    /** get.e:470				return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _4832 = _16string_next_8321 - 1;
    if ((object)((uintptr_t)_4832 +(uintptr_t) HIGH_BITS) >= 0){
        _4832 = NewDouble((eudouble)_4832);
    }
    if (IS_ATOM_INT(_4832)) {
        _4833 = _4832 - _offset_8626;
        if ((object)((uintptr_t)_4833 +(uintptr_t) HIGH_BITS) >= 0){
            _4833 = NewDouble((eudouble)_4833);
        }
    }
    else {
        _4833 = NewDouble(DBL_PTR(_4832)->dbl - (eudouble)_offset_8626);
    }
    DeRef(_4832);
    _4832 = NOVALUE;
    _4834 = (_16ch_8322 != -1);
    if (IS_ATOM_INT(_4833)) {
        _4835 = _4833 - _4834;
        if ((object)((uintptr_t)_4835 +(uintptr_t) HIGH_BITS) >= 0){
            _4835 = NewDouble((eudouble)_4835);
        }
    }
    else {
        _4835 = NewDouble(DBL_PTR(_4833)->dbl - (eudouble)_4834);
    }
    DeRef(_4833);
    _4833 = NOVALUE;
    _4834 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _4835;
    ((intptr_t *)_2)[2] = _16leading_whitespace_8620;
    _4836 = MAKE_SEQ(_1);
    _4835 = NOVALUE;
    Concat((object_ptr)&_4837, _e_8624, _4836);
    DeRefDS(_4836);
    _4836 = NOVALUE;
    DeRef(_s_8623);
    DeRefDS(_e_8624);
    DeRef(_4798);
    _4798 = NOVALUE;
    DeRef(_4767);
    _4767 = NOVALUE;
    DeRef(_4786);
    _4786 = NOVALUE;
    DeRef(_4792);
    _4792 = NOVALUE;
    DeRef(_4813);
    _4813 = NOVALUE;
    DeRef(_4749);
    _4749 = NOVALUE;
    DeRef(_4761);
    _4761 = NOVALUE;
    DeRef(_4821);
    _4821 = NOVALUE;
    DeRef(_4774);
    _4774 = NOVALUE;
    DeRef(_4829);
    _4829 = NOVALUE;
    DeRef(_4807);
    _4807 = NOVALUE;
    return _4837;
    goto L4; // [836] 94
L19: 

    /** get.e:472				return {GET_FAIL, 0, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _4838 = _16string_next_8321 - 1;
    if ((object)((uintptr_t)_4838 +(uintptr_t) HIGH_BITS) >= 0){
        _4838 = NewDouble((eudouble)_4838);
    }
    if (IS_ATOM_INT(_4838)) {
        _4839 = _4838 - _offset_8626;
        if ((object)((uintptr_t)_4839 +(uintptr_t) HIGH_BITS) >= 0){
            _4839 = NewDouble((eudouble)_4839);
        }
    }
    else {
        _4839 = NewDouble(DBL_PTR(_4838)->dbl - (eudouble)_offset_8626);
    }
    DeRef(_4838);
    _4838 = NOVALUE;
    _4840 = (_16ch_8322 != -1);
    if (IS_ATOM_INT(_4839)) {
        _4841 = _4839 - _4840;
        if ((object)((uintptr_t)_4841 +(uintptr_t) HIGH_BITS) >= 0){
            _4841 = NewDouble((eudouble)_4841);
        }
    }
    else {
        _4841 = NewDouble(DBL_PTR(_4839)->dbl - (eudouble)_4840);
    }
    DeRef(_4839);
    _4839 = NOVALUE;
    _4840 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = _4841;
    ((intptr_t*)_2)[4] = _16leading_whitespace_8620;
    _4842 = MAKE_SEQ(_1);
    _4841 = NOVALUE;
    DeRef(_s_8623);
    DeRef(_e_8624);
    DeRef(_4798);
    _4798 = NOVALUE;
    DeRef(_4767);
    _4767 = NOVALUE;
    DeRef(_4786);
    _4786 = NOVALUE;
    DeRef(_4792);
    _4792 = NOVALUE;
    DeRef(_4813);
    _4813 = NOVALUE;
    DeRef(_4749);
    _4749 = NOVALUE;
    DeRef(_4761);
    _4761 = NOVALUE;
    DeRef(_4821);
    _4821 = NOVALUE;
    DeRef(_4774);
    _4774 = NOVALUE;
    DeRef(_4829);
    _4829 = NOVALUE;
    DeRef(_4807);
    _4807 = NOVALUE;
    DeRef(_4837);
    _4837 = NOVALUE;
    return _4842;

    /** get.e:476		end while*/
    goto L4; // [877] 94
    ;
}


object _16get_value(object _target_8762, object _start_point_8763, object _answer_type_8764)
{
    object _msg_inlined_crash_at_35_8775 = NOVALUE;
    object _data_inlined_crash_at_32_8774 = NOVALUE;
    object _where_inlined_where_at_76_8781 = NOVALUE;
    object _seek_1__tmp_at90_8786 = NOVALUE;
    object _seek_inlined_seek_at_90_8785 = NOVALUE;
    object _pos_inlined_seek_at_87_8784 = NOVALUE;
    object _msg_inlined_crash_at_108_8789 = NOVALUE;
    object _4858 = NOVALUE;
    object _4855 = NOVALUE;
    object _4854 = NOVALUE;
    object _4853 = NOVALUE;
    object _4849 = NOVALUE;
    object _4848 = NOVALUE;
    object _4847 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:488		if answer_type != GET_SHORT_ANSWER and answer_type != GET_LONG_ANSWER then*/
    _4847 = (_answer_type_8764 != _16GET_SHORT_ANSWER_8754);
    if (_4847 == 0) {
        goto L1; // [13] 55
    }
    _4849 = (_answer_type_8764 != _16GET_LONG_ANSWER_8757);
    if (_4849 == 0)
    {
        DeRef(_4849);
        _4849 = NOVALUE;
        goto L1; // [24] 55
    }
    else{
        DeRef(_4849);
        _4849 = NOVALUE;
    }

    /** get.e:489			error:crash("Invalid type of answer, please only use %s (the default) or %s.", {"GET_SHORT_ANSWER", "GET_LONG_ANSWER"})*/
    RefDS(_4852);
    RefDS(_4851);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _4851;
    ((intptr_t *)_2)[2] = _4852;
    _4853 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_32_8774);
    _data_inlined_crash_at_32_8774 = _4853;
    _4853 = NOVALUE;

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_35_8775);
    _msg_inlined_crash_at_35_8775 = EPrintf(-9999999, _4850, _data_inlined_crash_at_32_8774);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_35_8775);

    /** error.e:53	end procedure*/
    goto L2; // [49] 52
L2: 
    DeRef(_data_inlined_crash_at_32_8774);
    _data_inlined_crash_at_32_8774 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_35_8775);
    _msg_inlined_crash_at_35_8775 = NOVALUE;
L1: 

    /** get.e:491		if atom(target) then -- get()*/
    _4854 = IS_ATOM(_target_8762);
    if (_4854 == 0)
    {
        _4854 = NOVALUE;
        goto L3; // [60] 142
    }
    else{
        _4854 = NOVALUE;
    }

    /** get.e:492			input_file = target*/
    Ref(_target_8762);
    _16input_file_8319 = _target_8762;
    if (!IS_ATOM_INT(_16input_file_8319)) {
        _1 = (object)(DBL_PTR(_16input_file_8319)->dbl);
        DeRefDS(_16input_file_8319);
        _16input_file_8319 = _1;
    }

    /** get.e:493			if start_point then*/
    if (_start_point_8763 == 0)
    {
        goto L4; // [72] 129
    }
    else{
    }

    /** get.e:494				if io:seek(target, io:where(target)+start_point) then*/

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_76_8781);
    _where_inlined_where_at_76_8781 = machine(20, _target_8762);
    if (IS_ATOM_INT(_where_inlined_where_at_76_8781)) {
        _4855 = _where_inlined_where_at_76_8781 + _start_point_8763;
        if ((object)((uintptr_t)_4855 + (uintptr_t)HIGH_BITS) >= 0){
            _4855 = NewDouble((eudouble)_4855);
        }
    }
    else {
        _4855 = NewDouble(DBL_PTR(_where_inlined_where_at_76_8781)->dbl + (eudouble)_start_point_8763);
    }
    DeRef(_pos_inlined_seek_at_87_8784);
    _pos_inlined_seek_at_87_8784 = _4855;
    _4855 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_87_8784);
    Ref(_target_8762);
    DeRef(_seek_1__tmp_at90_8786);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _target_8762;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_87_8784;
    _seek_1__tmp_at90_8786 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_90_8785 = machine(19, _seek_1__tmp_at90_8786);
    DeRef(_pos_inlined_seek_at_87_8784);
    _pos_inlined_seek_at_87_8784 = NOVALUE;
    DeRef(_seek_1__tmp_at90_8786);
    _seek_1__tmp_at90_8786 = NOVALUE;
    if (_seek_inlined_seek_at_90_8785 == 0)
    {
        goto L5; // [104] 128
    }
    else{
    }

    /** get.e:495					error:crash("Initial seek() for get() failed!")*/

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_108_8789);
    _msg_inlined_crash_at_108_8789 = EPrintf(-9999999, _4856, _5);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_108_8789);

    /** error.e:53	end procedure*/
    goto L6; // [122] 125
L6: 
    DeRefi(_msg_inlined_crash_at_108_8789);
    _msg_inlined_crash_at_108_8789 = NOVALUE;
L5: 
L4: 

    /** get.e:498			string_next = 1*/
    _16string_next_8321 = 1;

    /** get.e:499			input_string = 0*/
    DeRef(_16input_string_8320);
    _16input_string_8320 = 0;
    goto L7; // [139] 153
L3: 

    /** get.e:501			input_string = target*/
    Ref(_target_8762);
    DeRef(_16input_string_8320);
    _16input_string_8320 = _target_8762;

    /** get.e:502			string_next = start_point*/
    _16string_next_8321 = _start_point_8763;
L7: 

    /** get.e:504		if answer_type = GET_SHORT_ANSWER then*/
    if (_answer_type_8764 != _16GET_SHORT_ANSWER_8754)
    goto L8; // [157] 166

    /** get.e:505			get_ch()*/
    _16get_ch();
L8: 

    /** get.e:507		return call_func(answer_type, {})*/
    _0 = (object)_00[_answer_type_8764].addr;
    _1 = (*(intptr_t (*)())_0)(
                         );
    DeRef(_4858);
    _4858 = _1;
    DeRef(_target_8762);
    DeRef(_4847);
    _4847 = NOVALUE;
    return _4858;
    ;
}


object _16value(object _st_8802, object _start_point_8803, object _answer_8804)
{
    object _4860 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:684		return get_value(st, start_point, answer)*/
    RefDS(_st_8802);
    _4860 = _16get_value(_st_8802, 1, _answer_8804);
    DeRefDS(_st_8802);
    return _4860;
    ;
}



// 0x1405F232
