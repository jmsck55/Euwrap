// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _35malloc(object _mem_struct_p_12740, object _cleanup_p_12742)
{
    object _temp__12743 = NOVALUE;
    object _7361 = NOVALUE;
    object _7359 = NOVALUE;
    object _7358 = NOVALUE;
    object _7357 = NOVALUE;
    object _7353 = NOVALUE;
    object _0, _1, _2;
    

    /** eumem.e:51		if atom(mem_struct_p) then*/
    _7353 = IS_ATOM(_mem_struct_p_12740);
    if (_7353 == 0)
    {
        _7353 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _7353 = NOVALUE;
    }

    /** eumem.e:52			mem_struct_p = repeat(0, mem_struct_p)*/
    _0 = _mem_struct_p_12740;
    _mem_struct_p_12740 = Repeat(0, _mem_struct_p_12740);
    DeRef(_0);
L1: 

    /** eumem.e:54		if ram_free_list = 0 then*/
    if (_35ram_free_list_12736 != 0)
    goto L2; // [22] 72

    /** eumem.e:55			ram_space = append(ram_space, mem_struct_p)*/
    Ref(_mem_struct_p_12740);
    Append(&_35ram_space_12732, _35ram_space_12732, _mem_struct_p_12740);

    /** eumem.e:56			if cleanup_p then*/
    if (_cleanup_p_12742 == 0)
    {
        goto L3; // [36] 59
    }
    else{
    }

    /** eumem.e:57				return delete_routine( length(ram_space), free_rid )*/
    if (IS_SEQUENCE(_35ram_space_12732)){
            _7357 = SEQ_PTR(_35ram_space_12732)->length;
    }
    else {
        _7357 = 1;
    }
    _7358 = NewDouble( (eudouble) _7357 );
    _1 = (object) _00[_35free_rid_12737].cleanup;
    if( _1 == 0 ){
        _1 = (object) TransAlloc( sizeof(struct cleanup) );
        _00[_35free_rid_12737].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _35free_rid_12737;
    ((cleanup_ptr)_1)->next = 0;
    if(DBL_PTR(_7358)->cleanup != 0 ){
        _1 = (object) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_7358)->cleanup );
    }
    else if( !UNIQUE(DBL_PTR(_7358)) ){
        DeRefDS(_7358);
        _7358 = NewDouble( DBL_PTR(_7358)->dbl );
    }
    DBL_PTR(_7358)->cleanup = (cleanup_ptr)_1;
    _7357 = NOVALUE;
    DeRef(_mem_struct_p_12740);
    return _7358;
    goto L4; // [56] 71
L3: 

    /** eumem.e:59				return length(ram_space)*/
    if (IS_SEQUENCE(_35ram_space_12732)){
            _7359 = SEQ_PTR(_35ram_space_12732)->length;
    }
    else {
        _7359 = 1;
    }
    DeRef(_mem_struct_p_12740);
    DeRef(_7358);
    _7358 = NOVALUE;
    return _7359;
L4: 
L2: 

    /** eumem.e:63		temp_ = ram_free_list*/
    _temp__12743 = _35ram_free_list_12736;

    /** eumem.e:64		ram_free_list = ram_space[temp_]*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    _35ram_free_list_12736 = (object)*(((s1_ptr)_2)->base + _temp__12743);
    if (!IS_ATOM_INT(_35ram_free_list_12736))
    _35ram_free_list_12736 = (object)DBL_PTR(_35ram_free_list_12736)->dbl;

    /** eumem.e:65		ram_space[temp_] = mem_struct_p*/
    Ref(_mem_struct_p_12740);
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _temp__12743);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _mem_struct_p_12740;
    DeRef(_1);

    /** eumem.e:67		if cleanup_p then*/
    if (_cleanup_p_12742 == 0)
    {
        goto L5; // [97] 115
    }
    else{
    }

    /** eumem.e:68			return delete_routine( temp_, free_rid )*/
    _7361 = NewDouble( (eudouble) _temp__12743 );
    _1 = (object) _00[_35free_rid_12737].cleanup;
    if( _1 == 0 ){
        _1 = (object) TransAlloc( sizeof(struct cleanup) );
        _00[_35free_rid_12737].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _35free_rid_12737;
    ((cleanup_ptr)_1)->next = 0;
    if(DBL_PTR(_7361)->cleanup != 0 ){
        _1 = (object) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_7361)->cleanup );
    }
    else if( !UNIQUE(DBL_PTR(_7361)) ){
        DeRefDS(_7361);
        _7361 = NewDouble( DBL_PTR(_7361)->dbl );
    }
    DBL_PTR(_7361)->cleanup = (cleanup_ptr)_1;
    DeRef(_mem_struct_p_12740);
    DeRef(_7358);
    _7358 = NOVALUE;
    return _7361;
    goto L6; // [112] 122
L5: 

    /** eumem.e:70			return temp_*/
    DeRef(_mem_struct_p_12740);
    DeRef(_7361);
    _7361 = NOVALUE;
    DeRef(_7358);
    _7358 = NOVALUE;
    return _temp__12743;
L6: 
    ;
}


void _35free(object _mem_p_12761)
{
    object _7364 = NOVALUE;
    object _7362 = NOVALUE;
    object _0, _1, _2;
    

    /** eumem.e:95		if object( ram_space ) then*/
    if( NOVALUE == _35ram_space_12732 ){
        _7362 = 0;
    }
    else{
        _7362 = 3;
    }
    if (_7362 == 0)
    {
        _7362 = NOVALUE;
        goto L1; // [6] 52
    }
    else{
        _7362 = NOVALUE;
    }

    /** eumem.e:96			if mem_p < 1 then return end if*/
    if (binary_op_a(GREATEREQ, _mem_p_12761, 1)){
        goto L2; // [11] 19
    }
    DeRef(_mem_p_12761);
    return;
L2: 

    /** eumem.e:97			if mem_p > length(ram_space) then return end if*/
    if (IS_SEQUENCE(_35ram_space_12732)){
            _7364 = SEQ_PTR(_35ram_space_12732)->length;
    }
    else {
        _7364 = 1;
    }
    if (binary_op_a(LESSEQ, _mem_p_12761, _7364)){
        _7364 = NOVALUE;
        goto L3; // [26] 34
    }
    _7364 = NOVALUE;
    DeRef(_mem_p_12761);
    return;
L3: 

    /** eumem.e:99			ram_space[mem_p] = ram_free_list*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_mem_p_12761))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_mem_p_12761)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _mem_p_12761);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35ram_free_list_12736;
    DeRef(_1);

    /** eumem.e:100			ram_free_list = floor(mem_p)*/
    if (IS_ATOM_INT(_mem_p_12761))
    _35ram_free_list_12736 = e_floor(_mem_p_12761);
    else
    _35ram_free_list_12736 = unary_op(FLOOR, _mem_p_12761);
    if (!IS_ATOM_INT(_35ram_free_list_12736)) {
        _1 = (object)(DBL_PTR(_35ram_free_list_12736)->dbl);
        DeRefDS(_35ram_free_list_12736);
        _35ram_free_list_12736 = _1;
    }
L1: 

    /** eumem.e:102	end procedure*/
    DeRef(_mem_p_12761);
    return;
    ;
}



// 0xBB9C6DF7
