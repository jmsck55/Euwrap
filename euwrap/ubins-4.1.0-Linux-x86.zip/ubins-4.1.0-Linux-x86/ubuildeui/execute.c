// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _67new_arg_assign()
{
    object _0, _1, _2;
    

    /** execute.e:81		arg_assign += 1*/
    _0 = _67arg_assign_64746;
    if (IS_ATOM_INT(_67arg_assign_64746)) {
        _67arg_assign_64746 = _67arg_assign_64746 + 1;
        if (_67arg_assign_64746 > MAXINT){
            _67arg_assign_64746 = NewDouble((eudouble)_67arg_assign_64746);
        }
    }
    else
    _67arg_assign_64746 = binary_op(PLUS, 1, _67arg_assign_64746);
    DeRef(_0);

    /** execute.e:82		return arg_assign*/
    Ref(_67arg_assign_64746);
    return _67arg_assign_64746;
    ;
}


void _67open_err_file()
{
    object _31831 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:187		err_file = open(err_file_name, "w")*/
    _67err_file_64851 = EOpen(_67err_file_name_64852, _22151, 0);

    /** execute.e:188		if err_file = -1 then*/
    if (_67err_file_64851 != -1)
    goto L1; // [14] 36

    /** execute.e:189			puts(2, "Can't open " & err_file_name & '\n')*/
    {
        object concat_list[3];

        concat_list[0] = 10;
        concat_list[1] = _67err_file_name_64852;
        concat_list[2] = _31830;
        Concat_N((object_ptr)&_31831, concat_list, 3);
    }
    EPuts(2, _31831); // DJP 
    DeRefDS(_31831);
    _31831 = NOVALUE;

    /** execute.e:190			abort(1)*/
    UserCleanup(1);
L1: 

    /** execute.e:192	end procedure*/
    return;
    ;
}


void _67both_puts(object _s_64865)
{
    object _0, _1, _2;
    

    /** execute.e:198		if screen_err_out then*/
    if (_67screen_err_out_64862 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** execute.e:199			puts(2, s)*/
    EPuts(2, _s_64865); // DJP 
L1: 

    /** execute.e:201		puts(err_file, s)*/
    EPuts(_67err_file_64851, _s_64865); // DJP 

    /** execute.e:202	end procedure*/
    DeRef(_s_64865);
    return;
    ;
}


void _67both_printf(object _format_64869, object _items_64870)
{
    object _0, _1, _2;
    

    /** execute.e:206		if screen_err_out then*/
    if (_67screen_err_out_64862 == 0)
    {
        goto L1; // [9] 19
    }
    else{
    }

    /** execute.e:207			printf(2, format, items)*/
    EPrintf(2, _format_64869, _items_64870);
L1: 

    /** execute.e:209		printf(err_file, format, items)*/
    EPrintf(_67err_file_64851, _format_64869, _items_64870);

    /** execute.e:210	end procedure*/
    DeRefDSi(_format_64869);
    DeRefDS(_items_64870);
    return;
    ;
}


object _67find_line(object _sub_64875, object _pc_64876)
{
    object _linetab_64877 = NOVALUE;
    object _line_64878 = NOVALUE;
    object _gline_64879 = NOVALUE;
    object _31855 = NOVALUE;
    object _31854 = NOVALUE;
    object _31853 = NOVALUE;
    object _31852 = NOVALUE;
    object _31851 = NOVALUE;
    object _31850 = NOVALUE;
    object _31848 = NOVALUE;
    object _31847 = NOVALUE;
    object _31846 = NOVALUE;
    object _31844 = NOVALUE;
    object _31843 = NOVALUE;
    object _31842 = NOVALUE;
    object _31841 = NOVALUE;
    object _31839 = NOVALUE;
    object _31838 = NOVALUE;
    object _31836 = NOVALUE;
    object _31835 = NOVALUE;
    object _31834 = NOVALUE;
    object _31832 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:217		linetab = SymTab[sub][S_LINETAB]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31832 = (object)*(((s1_ptr)_2)->base + _sub_64875);
    DeRef(_linetab_64877);
    _2 = (object)SEQ_PTR(_31832);
    if (!IS_ATOM_INT(_12S_LINETAB_19899)){
        _linetab_64877 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    }
    else{
        _linetab_64877 = (object)*(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    }
    Ref(_linetab_64877);
    _31832 = NOVALUE;

    /** execute.e:218		line = 1*/
    _line_64878 = 1;

    /** execute.e:219		for i = 1 to length(linetab) do*/
    if (IS_SEQUENCE(_linetab_64877)){
            _31834 = SEQ_PTR(_linetab_64877)->length;
    }
    else {
        _31834 = 1;
    }
    {
        object _i_64885;
        _i_64885 = 1;
L1: 
        if (_i_64885 > _31834){
            goto L2; // [31] 119
        }

        /** execute.e:220			if linetab[i] >= pc or linetab[i] = -2 then*/
        _2 = (object)SEQ_PTR(_linetab_64877);
        _31835 = (object)*(((s1_ptr)_2)->base + _i_64885);
        if (IS_ATOM_INT(_31835)) {
            _31836 = (_31835 >= _pc_64876);
        }
        else {
            _31836 = binary_op(GREATEREQ, _31835, _pc_64876);
        }
        _31835 = NOVALUE;
        if (IS_ATOM_INT(_31836)) {
            if (_31836 != 0) {
                goto L3; // [48] 65
            }
        }
        else {
            if (DBL_PTR(_31836)->dbl != 0.0) {
                goto L3; // [48] 65
            }
        }
        _2 = (object)SEQ_PTR(_linetab_64877);
        _31838 = (object)*(((s1_ptr)_2)->base + _i_64885);
        if (IS_ATOM_INT(_31838)) {
            _31839 = (_31838 == -2);
        }
        else {
            _31839 = binary_op(EQUALS, _31838, -2);
        }
        _31838 = NOVALUE;
        if (_31839 == 0) {
            DeRef(_31839);
            _31839 = NOVALUE;
            goto L4; // [61] 112
        }
        else {
            if (!IS_ATOM_INT(_31839) && DBL_PTR(_31839)->dbl == 0.0){
                DeRef(_31839);
                _31839 = NOVALUE;
                goto L4; // [61] 112
            }
            DeRef(_31839);
            _31839 = NOVALUE;
        }
        DeRef(_31839);
        _31839 = NOVALUE;
L3: 

        /** execute.e:221				line = i-1*/
        _line_64878 = _i_64885 - 1;

        /** execute.e:222				while line > 1 and linetab[line] = -1 do*/
L5: 
        _31841 = (_line_64878 > 1);
        if (_31841 == 0) {
            goto L2; // [80] 119
        }
        _2 = (object)SEQ_PTR(_linetab_64877);
        _31843 = (object)*(((s1_ptr)_2)->base + _line_64878);
        if (IS_ATOM_INT(_31843)) {
            _31844 = (_31843 == -1);
        }
        else {
            _31844 = binary_op(EQUALS, _31843, -1);
        }
        _31843 = NOVALUE;
        if (_31844 <= 0) {
            if (_31844 == 0) {
                DeRef(_31844);
                _31844 = NOVALUE;
                goto L2; // [93] 119
            }
            else {
                if (!IS_ATOM_INT(_31844) && DBL_PTR(_31844)->dbl == 0.0){
                    DeRef(_31844);
                    _31844 = NOVALUE;
                    goto L2; // [93] 119
                }
                DeRef(_31844);
                _31844 = NOVALUE;
            }
        }
        DeRef(_31844);
        _31844 = NOVALUE;

        /** execute.e:223					line -= 1*/
        _line_64878 = _line_64878 - 1;

        /** execute.e:224				end while*/
        goto L5; // [104] 76

        /** execute.e:225				exit*/
        goto L2; // [109] 119
L4: 

        /** execute.e:227		end for*/
        _i_64885 = _i_64885 + 1;
        goto L1; // [114] 38
L2: 
        ;
    }

    /** execute.e:228		gline = SymTab[sub][S_FIRSTLINE] + line - 1*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31846 = (object)*(((s1_ptr)_2)->base + _sub_64875);
    _2 = (object)SEQ_PTR(_31846);
    if (!IS_ATOM_INT(_12S_FIRSTLINE_19904)){
        _31847 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FIRSTLINE_19904)->dbl));
    }
    else{
        _31847 = (object)*(((s1_ptr)_2)->base + _12S_FIRSTLINE_19904);
    }
    _31846 = NOVALUE;
    if (IS_ATOM_INT(_31847)) {
        _31848 = _31847 + _line_64878;
        if ((object)((uintptr_t)_31848 + (uintptr_t)HIGH_BITS) >= 0){
            _31848 = NewDouble((eudouble)_31848);
        }
    }
    else {
        _31848 = binary_op(PLUS, _31847, _line_64878);
    }
    _31847 = NOVALUE;
    if (IS_ATOM_INT(_31848)) {
        _gline_64879 = _31848 - 1;
    }
    else {
        _gline_64879 = binary_op(MINUS, _31848, 1);
    }
    DeRef(_31848);
    _31848 = NOVALUE;
    if (!IS_ATOM_INT(_gline_64879)) {
        _1 = (object)(DBL_PTR(_gline_64879)->dbl);
        DeRefDS(_gline_64879);
        _gline_64879 = _1;
    }

    /** execute.e:229		return {known_files[slist[gline][LOCAL_FILE_NO]], slist[gline][LINE]}*/
    _2 = (object)SEQ_PTR(_12slist_20317);
    _31850 = (object)*(((s1_ptr)_2)->base + _gline_64879);
    _2 = (object)SEQ_PTR(_31850);
    _31851 = (object)*(((s1_ptr)_2)->base + 3);
    _31850 = NOVALUE;
    _2 = (object)SEQ_PTR(_13known_files_11317);
    if (!IS_ATOM_INT(_31851)){
        _31852 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31851)->dbl));
    }
    else{
        _31852 = (object)*(((s1_ptr)_2)->base + _31851);
    }
    _2 = (object)SEQ_PTR(_12slist_20317);
    _31853 = (object)*(((s1_ptr)_2)->base + _gline_64879);
    _2 = (object)SEQ_PTR(_31853);
    _31854 = (object)*(((s1_ptr)_2)->base + 2);
    _31853 = NOVALUE;
    Ref(_31854);
    Ref(_31852);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _31852;
    ((intptr_t *)_2)[2] = _31854;
    _31855 = MAKE_SEQ(_1);
    _31854 = NOVALUE;
    _31852 = NOVALUE;
    DeRef(_linetab_64877);
    _31851 = NOVALUE;
    DeRef(_31841);
    _31841 = NOVALUE;
    DeRef(_31836);
    _31836 = NOVALUE;
    return _31855;
    ;
}


void _67show_var(object _x_64920)
{
    object _31869 = NOVALUE;
    object _31866 = NOVALUE;
    object _31865 = NOVALUE;
    object _31864 = NOVALUE;
    object _31863 = NOVALUE;
    object _31862 = NOVALUE;
    object _31860 = NOVALUE;
    object _31859 = NOVALUE;
    object _31858 = NOVALUE;
    object _31857 = NOVALUE;
    object _31856 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:235		puts(err_file, "    " & SymTab[x][S_NAME] & " = ")*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31856 = (object)*(((s1_ptr)_2)->base + _x_64920);
    _2 = (object)SEQ_PTR(_31856);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _31857 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _31857 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _31856 = NOVALUE;
    {
        object concat_list[3];

        concat_list[0] = _29431;
        concat_list[1] = _31857;
        concat_list[2] = _24902;
        Concat_N((object_ptr)&_31858, concat_list, 3);
    }
    _31857 = NOVALUE;
    EPuts(_67err_file_64851, _31858); // DJP 
    DeRefDS(_31858);
    _31858 = NOVALUE;

    /** execute.e:236		if equal(val[x], NOVALUE) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _31859 = (object)*(((s1_ptr)_2)->base + _x_64920);
    if (_31859 == _12NOVALUE_20081)
    _31860 = 1;
    else if (IS_ATOM_INT(_31859) && IS_ATOM_INT(_12NOVALUE_20081))
    _31860 = 0;
    else
    _31860 = (compare(_31859, _12NOVALUE_20081) == 0);
    _31859 = NOVALUE;
    if (_31860 == 0)
    {
        _31860 = NOVALUE;
        goto L1; // [42] 55
    }
    else{
        _31860 = NOVALUE;
    }

    /** execute.e:237			puts(err_file, "<no value>")*/
    EPuts(_67err_file_64851, _31861); // DJP 
    goto L2; // [52] 102
L1: 

    /** execute.e:239			pretty_print(err_file, val[x],*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _31862 = (object)*(((s1_ptr)_2)->base + _x_64920);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31863 = (object)*(((s1_ptr)_2)->base + _x_64920);
    _2 = (object)SEQ_PTR(_31863);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _31864 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _31864 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _31863 = NOVALUE;
    if (IS_SEQUENCE(_31864)){
            _31865 = SEQ_PTR(_31864)->length;
    }
    else {
        _31865 = 1;
    }
    _31864 = NOVALUE;
    _31866 = _31865 + 7;
    _31865 = NOVALUE;
    _1 = NewS1(9);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    ((intptr_t*)_2)[3] = _31866;
    ((intptr_t*)_2)[4] = 78;
    RefDS(_31867);
    ((intptr_t*)_2)[5] = _31867;
    RefDS(_31868);
    ((intptr_t*)_2)[6] = _31868;
    ((intptr_t*)_2)[7] = 32;
    ((intptr_t*)_2)[8] = 127;
    ((intptr_t*)_2)[9] = 500;
    _31869 = MAKE_SEQ(_1);
    _31866 = NOVALUE;
    Ref(_31862);
    _10pretty_print(_67err_file_64851, _31862, _31869);
    _31862 = NOVALUE;
    _31869 = NOVALUE;
L2: 

    /** execute.e:242		puts(err_file, '\n')*/
    EPuts(_67err_file_64851, 10); // DJP 

    /** execute.e:243	end procedure*/
    _31864 = NOVALUE;
    return;
    ;
}


void _67save_private_block(object _rtn_idx_64950, object _block_64951)
{
    object _saved_64952 = NOVALUE;
    object _saved_list_64953 = NOVALUE;
    object _eentry_64954 = NOVALUE;
    object _task_64955 = NOVALUE;
    object _spot_64956 = NOVALUE;
    object _tn_64957 = NOVALUE;
    object _31896 = NOVALUE;
    object _31892 = NOVALUE;
    object _31891 = NOVALUE;
    object _31890 = NOVALUE;
    object _31889 = NOVALUE;
    object _31888 = NOVALUE;
    object _31887 = NOVALUE;
    object _31885 = NOVALUE;
    object _31883 = NOVALUE;
    object _31882 = NOVALUE;
    object _31879 = NOVALUE;
    object _31877 = NOVALUE;
    object _31875 = NOVALUE;
    object _31873 = NOVALUE;
    object _31872 = NOVALUE;
    object _31870 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:259		task = SymTab[rtn_idx][S_RESIDENT_TASK]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31870 = (object)*(((s1_ptr)_2)->base + _rtn_idx_64950);
    _2 = (object)SEQ_PTR(_31870);
    _task_64955 = (object)*(((s1_ptr)_2)->base + 25);
    if (!IS_ATOM_INT(_task_64955)){
        _task_64955 = (object)DBL_PTR(_task_64955)->dbl;
    }
    _31870 = NOVALUE;

    /** execute.e:261		eentry = {task, tcb[task][TASK_TID], block, 0}*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _31872 = (object)*(((s1_ptr)_2)->base + _task_64955);
    _2 = (object)SEQ_PTR(_31872);
    _31873 = (object)*(((s1_ptr)_2)->base + 2);
    _31872 = NOVALUE;
    _0 = _eentry_64954;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _task_64955;
    Ref(_31873);
    ((intptr_t*)_2)[2] = _31873;
    RefDS(_block_64951);
    ((intptr_t*)_2)[3] = _block_64951;
    ((intptr_t*)_2)[4] = 0;
    _eentry_64954 = MAKE_SEQ(_1);
    DeRef(_0);
    _31873 = NOVALUE;

    /** execute.e:262		saved = SymTab[rtn_idx][S_SAVED_PRIVATES]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31875 = (object)*(((s1_ptr)_2)->base + _rtn_idx_64950);
    DeRef(_saved_64952);
    _2 = (object)SEQ_PTR(_31875);
    _saved_64952 = (object)*(((s1_ptr)_2)->base + 26);
    Ref(_saved_64952);
    _31875 = NOVALUE;

    /** execute.e:264		if length(saved) = 0 then*/
    if (IS_SEQUENCE(_saved_64952)){
            _31877 = SEQ_PTR(_saved_64952)->length;
    }
    else {
        _31877 = 1;
    }
    if (_31877 != 0)
    goto L1; // [61] 78

    /** execute.e:266			saved = {1, -- index of first item*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_eentry_64954);
    ((intptr_t*)_2)[1] = _eentry_64954;
    _31879 = MAKE_SEQ(_1);
    DeRefDS(_saved_64952);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = _31879;
    _saved_64952 = MAKE_SEQ(_1);
    _31879 = NOVALUE;
    goto L2; // [75] 219
L1: 

    /** execute.e:270			saved_list = saved[2]*/
    DeRef(_saved_list_64953);
    _2 = (object)SEQ_PTR(_saved_64952);
    _saved_list_64953 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_saved_list_64953);

    /** execute.e:271			spot = 0*/
    _spot_64956 = 0;

    /** execute.e:272			for i = 1 to length(saved_list) do*/
    if (IS_SEQUENCE(_saved_list_64953)){
            _31882 = SEQ_PTR(_saved_list_64953)->length;
    }
    else {
        _31882 = 1;
    }
    {
        object _i_64977;
        _i_64977 = 1;
L3: 
        if (_i_64977 > _31882){
            goto L4; // [96] 169
        }

        /** execute.e:273				tn = saved_list[i][SP_TASK_NUMBER]*/
        _2 = (object)SEQ_PTR(_saved_list_64953);
        _31883 = (object)*(((s1_ptr)_2)->base + _i_64977);
        _2 = (object)SEQ_PTR(_31883);
        _tn_64957 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_tn_64957)){
            _tn_64957 = (object)DBL_PTR(_tn_64957)->dbl;
        }
        _31883 = NOVALUE;

        /** execute.e:274				if tn = -1 or*/
        _31885 = (_tn_64957 == -1);
        if (_31885 != 0) {
            goto L5; // [121] 152
        }
        _2 = (object)SEQ_PTR(_saved_list_64953);
        _31887 = (object)*(((s1_ptr)_2)->base + _i_64977);
        _2 = (object)SEQ_PTR(_31887);
        _31888 = (object)*(((s1_ptr)_2)->base + 2);
        _31887 = NOVALUE;
        _2 = (object)SEQ_PTR(_67tcb_64845);
        _31889 = (object)*(((s1_ptr)_2)->base + _tn_64957);
        _2 = (object)SEQ_PTR(_31889);
        _31890 = (object)*(((s1_ptr)_2)->base + 2);
        _31889 = NOVALUE;
        if (IS_ATOM_INT(_31888) && IS_ATOM_INT(_31890)) {
            _31891 = (_31888 != _31890);
        }
        else {
            _31891 = binary_op(NOTEQ, _31888, _31890);
        }
        _31888 = NOVALUE;
        _31890 = NOVALUE;
        if (_31891 == 0) {
            DeRef(_31891);
            _31891 = NOVALUE;
            goto L6; // [148] 162
        }
        else {
            if (!IS_ATOM_INT(_31891) && DBL_PTR(_31891)->dbl == 0.0){
                DeRef(_31891);
                _31891 = NOVALUE;
                goto L6; // [148] 162
            }
            DeRef(_31891);
            _31891 = NOVALUE;
        }
        DeRef(_31891);
        _31891 = NOVALUE;
L5: 

        /** execute.e:277					spot = i*/
        _spot_64956 = _i_64977;

        /** execute.e:278					exit*/
        goto L4; // [159] 169
L6: 

        /** execute.e:280			end for*/
        _i_64977 = _i_64977 + 1;
        goto L3; // [164] 103
L4: 
        ;
    }

    /** execute.e:282			eentry[SP_NEXT] = saved[1] -- new eentry points to previous first*/
    _2 = (object)SEQ_PTR(_saved_64952);
    _31892 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_31892);
    _2 = (object)SEQ_PTR(_eentry_64954);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _eentry_64954 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31892;
    if( _1 != _31892 ){
        DeRef(_1);
    }
    _31892 = NOVALUE;

    /** execute.e:283			if spot = 0 then*/
    if (_spot_64956 != 0)
    goto L7; // [181] 199

    /** execute.e:285				saved_list = append(saved_list, eentry)*/
    RefDS(_eentry_64954);
    Append(&_saved_list_64953, _saved_list_64953, _eentry_64954);

    /** execute.e:286				spot = length(saved_list)*/
    if (IS_SEQUENCE(_saved_list_64953)){
            _spot_64956 = SEQ_PTR(_saved_list_64953)->length;
    }
    else {
        _spot_64956 = 1;
    }
    goto L8; // [196] 206
L7: 

    /** execute.e:288				saved_list[spot] = eentry*/
    RefDS(_eentry_64954);
    _2 = (object)SEQ_PTR(_saved_list_64953);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_list_64953 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _spot_64956);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _eentry_64954;
    DeRef(_1);
L8: 

    /** execute.e:291			saved[1] = spot -- it becomes the first on the list*/
    _2 = (object)SEQ_PTR(_saved_64952);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_64952 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _spot_64956;
    DeRef(_1);

    /** execute.e:292			saved[2] = saved_list*/
    RefDS(_saved_list_64953);
    _2 = (object)SEQ_PTR(_saved_64952);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_64952 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _saved_list_64953;
    DeRef(_1);
L2: 

    /** execute.e:295		SymTab[rtn_idx][S_SAVED_PRIVATES] = saved*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_rtn_idx_64950 + ((s1_ptr)_2)->base);
    RefDS(_saved_64952);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _saved_64952;
    DeRef(_1);
    _31896 = NOVALUE;

    /** execute.e:296	end procedure*/
    DeRefDS(_block_64951);
    DeRefDS(_saved_64952);
    DeRef(_saved_list_64953);
    DeRef(_eentry_64954);
    DeRef(_31885);
    _31885 = NOVALUE;
    return;
    ;
}


object _67load_private_block(object _rtn_idx_65002, object _task_65003)
{
    object _saved_65004 = NOVALUE;
    object _saved_list_65005 = NOVALUE;
    object _block_65006 = NOVALUE;
    object _p_65007 = NOVALUE;
    object _prev_p_65008 = NOVALUE;
    object _first_65009 = NOVALUE;
    object _31920 = NOVALUE;
    object _31918 = NOVALUE;
    object _31917 = NOVALUE;
    object _31916 = NOVALUE;
    object _31914 = NOVALUE;
    object _31912 = NOVALUE;
    object _31909 = NOVALUE;
    object _31907 = NOVALUE;
    object _31905 = NOVALUE;
    object _31903 = NOVALUE;
    object _31902 = NOVALUE;
    object _31898 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:304		saved = SymTab[rtn_idx][S_SAVED_PRIVATES]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31898 = (object)*(((s1_ptr)_2)->base + _rtn_idx_65002);
    DeRef(_saved_65004);
    _2 = (object)SEQ_PTR(_31898);
    _saved_65004 = (object)*(((s1_ptr)_2)->base + 26);
    Ref(_saved_65004);
    _31898 = NOVALUE;

    /** execute.e:305		first = saved[1]*/
    _2 = (object)SEQ_PTR(_saved_65004);
    _first_65009 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_first_65009))
    _first_65009 = (object)DBL_PTR(_first_65009)->dbl;

    /** execute.e:306		p = first -- won't be 0*/
    _p_65007 = _first_65009;

    /** execute.e:307		prev_p = -1*/
    _prev_p_65008 = -1;

    /** execute.e:308		saved_list = saved[2]*/
    DeRef(_saved_list_65005);
    _2 = (object)SEQ_PTR(_saved_65004);
    _saved_list_65005 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_saved_list_65005);

    /** execute.e:309		while TRUE do*/
L1: 
    if (_9TRUE_446 == 0)
    {
        goto L2; // [52] 200
    }
    else{
    }

    /** execute.e:310			if saved_list[p][SP_TASK_NUMBER] = task then*/
    _2 = (object)SEQ_PTR(_saved_list_65005);
    _31902 = (object)*(((s1_ptr)_2)->base + _p_65007);
    _2 = (object)SEQ_PTR(_31902);
    _31903 = (object)*(((s1_ptr)_2)->base + 1);
    _31902 = NOVALUE;
    if (binary_op_a(NOTEQ, _31903, _task_65003)){
        _31903 = NOVALUE;
        goto L3; // [65] 178
    }
    _31903 = NOVALUE;

    /** execute.e:312				block = saved_list[p][SP_BLOCK]*/
    _2 = (object)SEQ_PTR(_saved_list_65005);
    _31905 = (object)*(((s1_ptr)_2)->base + _p_65007);
    DeRef(_block_65006);
    _2 = (object)SEQ_PTR(_31905);
    _block_65006 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_block_65006);
    _31905 = NOVALUE;

    /** execute.e:313				saved_list[p][SP_TASK_NUMBER] = -1 -- mark it as deleted*/
    _2 = (object)SEQ_PTR(_saved_list_65005);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_list_65005 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_65007 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1;
    DeRef(_1);
    _31907 = NOVALUE;

    /** execute.e:314				saved_list[p][SP_BLOCK] = {}*/
    _2 = (object)SEQ_PTR(_saved_list_65005);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_list_65005 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_65007 + ((s1_ptr)_2)->base);
    RefDS(_22015);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22015;
    DeRef(_1);
    _31909 = NOVALUE;

    /** execute.e:315				if prev_p = -1 then*/
    if (_prev_p_65008 != -1)
    goto L4; // [105] 124

    /** execute.e:316					first = saved_list[p][SP_NEXT]*/
    _2 = (object)SEQ_PTR(_saved_list_65005);
    _31912 = (object)*(((s1_ptr)_2)->base + _p_65007);
    _2 = (object)SEQ_PTR(_31912);
    _first_65009 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_first_65009)){
        _first_65009 = (object)DBL_PTR(_first_65009)->dbl;
    }
    _31912 = NOVALUE;
    goto L5; // [121] 144
L4: 

    /** execute.e:318					saved_list[prev_p][SP_NEXT] = saved_list[p][SP_NEXT]*/
    _2 = (object)SEQ_PTR(_saved_list_65005);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_list_65005 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_p_65008 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_saved_list_65005);
    _31916 = (object)*(((s1_ptr)_2)->base + _p_65007);
    _2 = (object)SEQ_PTR(_31916);
    _31917 = (object)*(((s1_ptr)_2)->base + 4);
    _31916 = NOVALUE;
    Ref(_31917);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31917;
    if( _1 != _31917 ){
        DeRef(_1);
    }
    _31917 = NOVALUE;
    _31914 = NOVALUE;
L5: 

    /** execute.e:320				saved[1] = first*/
    _2 = (object)SEQ_PTR(_saved_65004);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_65004 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _first_65009;
    DeRef(_1);

    /** execute.e:321				saved[2] = saved_list*/
    RefDS(_saved_list_65005);
    _2 = (object)SEQ_PTR(_saved_65004);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_65004 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _saved_list_65005;
    DeRef(_1);

    /** execute.e:322				SymTab[rtn_idx][S_SAVED_PRIVATES] = saved*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_rtn_idx_65002 + ((s1_ptr)_2)->base);
    RefDS(_saved_65004);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _saved_65004;
    DeRef(_1);
    _31918 = NOVALUE;

    /** execute.e:323				return block*/
    DeRefDS(_saved_65004);
    DeRefDS(_saved_list_65005);
    return _block_65006;
L3: 

    /** execute.e:325			prev_p = p*/
    _prev_p_65008 = _p_65007;

    /** execute.e:326			p = saved_list[p][SP_NEXT]*/
    _2 = (object)SEQ_PTR(_saved_list_65005);
    _31920 = (object)*(((s1_ptr)_2)->base + _p_65007);
    _2 = (object)SEQ_PTR(_31920);
    _p_65007 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_p_65007)){
        _p_65007 = (object)DBL_PTR(_p_65007)->dbl;
    }
    _31920 = NOVALUE;

    /** execute.e:327		end while*/
    goto L1; // [197] 50
L2: 
    ;
}


void _67restore_privates(object _this_routine_65046)
{
    object _arg_65048 = NOVALUE;
    object _private_block_65049 = NOVALUE;
    object _base_65050 = NOVALUE;
    object _31987 = NOVALUE;
    object _31985 = NOVALUE;
    object _31983 = NOVALUE;
    object _31980 = NOVALUE;
    object _31978 = NOVALUE;
    object _31976 = NOVALUE;
    object _31974 = NOVALUE;
    object _31973 = NOVALUE;
    object _31972 = NOVALUE;
    object _31971 = NOVALUE;
    object _31970 = NOVALUE;
    object _31969 = NOVALUE;
    object _31968 = NOVALUE;
    object _31967 = NOVALUE;
    object _31966 = NOVALUE;
    object _31965 = NOVALUE;
    object _31964 = NOVALUE;
    object _31963 = NOVALUE;
    object _31962 = NOVALUE;
    object _31961 = NOVALUE;
    object _31960 = NOVALUE;
    object _31958 = NOVALUE;
    object _31955 = NOVALUE;
    object _31953 = NOVALUE;
    object _31950 = NOVALUE;
    object _31948 = NOVALUE;
    object _31946 = NOVALUE;
    object _31944 = NOVALUE;
    object _31943 = NOVALUE;
    object _31942 = NOVALUE;
    object _31941 = NOVALUE;
    object _31940 = NOVALUE;
    object _31939 = NOVALUE;
    object _31938 = NOVALUE;
    object _31937 = NOVALUE;
    object _31936 = NOVALUE;
    object _31935 = NOVALUE;
    object _31934 = NOVALUE;
    object _31933 = NOVALUE;
    object _31932 = NOVALUE;
    object _31931 = NOVALUE;
    object _31930 = NOVALUE;
    object _31928 = NOVALUE;
    object _31926 = NOVALUE;
    object _31925 = NOVALUE;
    object _31923 = NOVALUE;
    object _31922 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_this_routine_65046)) {
        _1 = (object)(DBL_PTR(_this_routine_65046)->dbl);
        DeRefDS(_this_routine_65046);
        _this_routine_65046 = _1;
    }

    /** execute.e:334		sequence private_block*/

    /** execute.e:335		integer base*/

    /** execute.e:337		if SymTab[this_routine][S_RESIDENT_TASK] != current_task then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31922 = (object)*(((s1_ptr)_2)->base + _this_routine_65046);
    _2 = (object)SEQ_PTR(_31922);
    _31923 = (object)*(((s1_ptr)_2)->base + 25);
    _31922 = NOVALUE;
    if (binary_op_a(EQUALS, _31923, _67current_task_64819)){
        _31923 = NOVALUE;
        goto L1; // [23] 535
    }
    _31923 = NOVALUE;

    /** execute.e:340			if SymTab[this_routine][S_RESIDENT_TASK] != 0 then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31925 = (object)*(((s1_ptr)_2)->base + _this_routine_65046);
    _2 = (object)SEQ_PTR(_31925);
    _31926 = (object)*(((s1_ptr)_2)->base + 25);
    _31925 = NOVALUE;
    if (binary_op_a(EQUALS, _31926, 0)){
        _31926 = NOVALUE;
        goto L2; // [41] 274
    }
    _31926 = NOVALUE;

    /** execute.e:346				arg = SymTab[this_routine][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31928 = (object)*(((s1_ptr)_2)->base + _this_routine_65046);
    _2 = (object)SEQ_PTR(_31928);
    _arg_65048 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_65048)){
        _arg_65048 = (object)DBL_PTR(_arg_65048)->dbl;
    }
    _31928 = NOVALUE;

    /** execute.e:347				private_block = {}*/
    RefDS(_22015);
    DeRef(_private_block_65049);
    _private_block_65049 = _22015;

    /** execute.e:349				while arg != 0 */
L3: 
    _31930 = (_arg_65048 != 0);
    if (_31930 == 0) {
        goto L4; // [77] 209
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31932 = (object)*(((s1_ptr)_2)->base + _arg_65048);
    _2 = (object)SEQ_PTR(_31932);
    _31933 = (object)*(((s1_ptr)_2)->base + 4);
    _31932 = NOVALUE;
    if (IS_ATOM_INT(_31933)) {
        _31934 = (_31933 <= 3);
    }
    else {
        _31934 = binary_op(LESSEQ, _31933, 3);
    }
    _31933 = NOVALUE;
    if (IS_ATOM_INT(_31934)) {
        if (_31934 != 0) {
            DeRef(_31935);
            _31935 = 1;
            goto L5; // [99] 125
        }
    }
    else {
        if (DBL_PTR(_31934)->dbl != 0.0) {
            DeRef(_31935);
            _31935 = 1;
            goto L5; // [99] 125
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31936 = (object)*(((s1_ptr)_2)->base + _arg_65048);
    _2 = (object)SEQ_PTR(_31936);
    _31937 = (object)*(((s1_ptr)_2)->base + 4);
    _31936 = NOVALUE;
    if (IS_ATOM_INT(_31937)) {
        _31938 = (_31937 == 2);
    }
    else {
        _31938 = binary_op(EQUALS, _31937, 2);
    }
    _31937 = NOVALUE;
    DeRef(_31935);
    if (IS_ATOM_INT(_31938))
    _31935 = (_31938 != 0);
    else
    _31935 = DBL_PTR(_31938)->dbl != 0.0;
L5: 
    if (_31935 != 0) {
        DeRef(_31939);
        _31939 = 1;
        goto L6; // [125] 151
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31940 = (object)*(((s1_ptr)_2)->base + _arg_65048);
    _2 = (object)SEQ_PTR(_31940);
    _31941 = (object)*(((s1_ptr)_2)->base + 4);
    _31940 = NOVALUE;
    if (IS_ATOM_INT(_31941)) {
        _31942 = (_31941 == 9);
    }
    else {
        _31942 = binary_op(EQUALS, _31941, 9);
    }
    _31941 = NOVALUE;
    if (IS_ATOM_INT(_31942))
    _31939 = (_31942 != 0);
    else
    _31939 = DBL_PTR(_31942)->dbl != 0.0;
L6: 
    if (_31939 == 0)
    {
        _31939 = NOVALUE;
        goto L4; // [152] 209
    }
    else{
        _31939 = NOVALUE;
    }

    /** execute.e:354					if SymTab[arg][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31943 = (object)*(((s1_ptr)_2)->base + _arg_65048);
    _2 = (object)SEQ_PTR(_31943);
    _31944 = (object)*(((s1_ptr)_2)->base + 4);
    _31943 = NOVALUE;
    if (binary_op_a(EQUALS, _31944, 9)){
        _31944 = NOVALUE;
        goto L7; // [171] 188
    }
    _31944 = NOVALUE;

    /** execute.e:355						private_block = append(private_block, val[arg])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _31946 = (object)*(((s1_ptr)_2)->base + _arg_65048);
    Ref(_31946);
    Append(&_private_block_65049, _private_block_65049, _31946);
    _31946 = NOVALUE;
L7: 

    /** execute.e:357					arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31948 = (object)*(((s1_ptr)_2)->base + _arg_65048);
    _2 = (object)SEQ_PTR(_31948);
    _arg_65048 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_65048)){
        _arg_65048 = (object)DBL_PTR(_arg_65048)->dbl;
    }
    _31948 = NOVALUE;

    /** execute.e:358				end while*/
    goto L3; // [206] 73
L4: 

    /** execute.e:361				arg = SymTab[this_routine][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31950 = (object)*(((s1_ptr)_2)->base + _this_routine_65046);
    _2 = (object)SEQ_PTR(_31950);
    if (!IS_ATOM_INT(_12S_TEMPS_19909)){
        _arg_65048 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    }
    else{
        _arg_65048 = (object)*(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    }
    if (!IS_ATOM_INT(_arg_65048)){
        _arg_65048 = (object)DBL_PTR(_arg_65048)->dbl;
    }
    _31950 = NOVALUE;

    /** execute.e:362				while arg != 0 do*/
L8: 
    if (_arg_65048 == 0)
    goto L9; // [230] 267

    /** execute.e:363					private_block = append(private_block, val[arg])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _31953 = (object)*(((s1_ptr)_2)->base + _arg_65048);
    Ref(_31953);
    Append(&_private_block_65049, _private_block_65049, _31953);
    _31953 = NOVALUE;

    /** execute.e:364					arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31955 = (object)*(((s1_ptr)_2)->base + _arg_65048);
    _2 = (object)SEQ_PTR(_31955);
    _arg_65048 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_65048)){
        _arg_65048 = (object)DBL_PTR(_arg_65048)->dbl;
    }
    _31955 = NOVALUE;

    /** execute.e:365				end while*/
    goto L8; // [264] 230
L9: 

    /** execute.e:367				save_private_block(this_routine, private_block)*/
    RefDS(_private_block_65049);
    _67save_private_block(_this_routine_65046, _private_block_65049);
L2: 

    /** execute.e:371			private_block = load_private_block(this_routine, current_task)*/
    _0 = _private_block_65049;
    _private_block_65049 = _67load_private_block(_this_routine_65046, _67current_task_64819);
    DeRef(_0);

    /** execute.e:374			base = 1*/
    _base_65050 = 1;

    /** execute.e:375			arg = SymTab[this_routine][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31958 = (object)*(((s1_ptr)_2)->base + _this_routine_65046);
    _2 = (object)SEQ_PTR(_31958);
    _arg_65048 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_65048)){
        _arg_65048 = (object)DBL_PTR(_arg_65048)->dbl;
    }
    _31958 = NOVALUE;

    /** execute.e:376			while arg != 0 */
LA: 
    _31960 = (_arg_65048 != 0);
    if (_31960 == 0) {
        goto LB; // [315] 453
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31962 = (object)*(((s1_ptr)_2)->base + _arg_65048);
    _2 = (object)SEQ_PTR(_31962);
    _31963 = (object)*(((s1_ptr)_2)->base + 4);
    _31962 = NOVALUE;
    if (IS_ATOM_INT(_31963)) {
        _31964 = (_31963 <= 3);
    }
    else {
        _31964 = binary_op(LESSEQ, _31963, 3);
    }
    _31963 = NOVALUE;
    if (IS_ATOM_INT(_31964)) {
        if (_31964 != 0) {
            DeRef(_31965);
            _31965 = 1;
            goto LC; // [337] 363
        }
    }
    else {
        if (DBL_PTR(_31964)->dbl != 0.0) {
            DeRef(_31965);
            _31965 = 1;
            goto LC; // [337] 363
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31966 = (object)*(((s1_ptr)_2)->base + _arg_65048);
    _2 = (object)SEQ_PTR(_31966);
    _31967 = (object)*(((s1_ptr)_2)->base + 4);
    _31966 = NOVALUE;
    if (IS_ATOM_INT(_31967)) {
        _31968 = (_31967 == 2);
    }
    else {
        _31968 = binary_op(EQUALS, _31967, 2);
    }
    _31967 = NOVALUE;
    DeRef(_31965);
    if (IS_ATOM_INT(_31968))
    _31965 = (_31968 != 0);
    else
    _31965 = DBL_PTR(_31968)->dbl != 0.0;
LC: 
    if (_31965 != 0) {
        DeRef(_31969);
        _31969 = 1;
        goto LD; // [363] 389
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31970 = (object)*(((s1_ptr)_2)->base + _arg_65048);
    _2 = (object)SEQ_PTR(_31970);
    _31971 = (object)*(((s1_ptr)_2)->base + 4);
    _31970 = NOVALUE;
    if (IS_ATOM_INT(_31971)) {
        _31972 = (_31971 == 9);
    }
    else {
        _31972 = binary_op(EQUALS, _31971, 9);
    }
    _31971 = NOVALUE;
    if (IS_ATOM_INT(_31972))
    _31969 = (_31972 != 0);
    else
    _31969 = DBL_PTR(_31972)->dbl != 0.0;
LD: 
    if (_31969 == 0)
    {
        _31969 = NOVALUE;
        goto LB; // [390] 453
    }
    else{
        _31969 = NOVALUE;
    }

    /** execute.e:381				if SymTab[arg][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31973 = (object)*(((s1_ptr)_2)->base + _arg_65048);
    _2 = (object)SEQ_PTR(_31973);
    _31974 = (object)*(((s1_ptr)_2)->base + 4);
    _31973 = NOVALUE;
    if (binary_op_a(EQUALS, _31974, 9)){
        _31974 = NOVALUE;
        goto LE; // [409] 432
    }
    _31974 = NOVALUE;

    /** execute.e:382					val[arg] = private_block[base]*/
    _2 = (object)SEQ_PTR(_private_block_65049);
    _31976 = (object)*(((s1_ptr)_2)->base + _base_65050);
    Ref(_31976);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_65048);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31976;
    if( _1 != _31976 ){
        DeRef(_1);
    }
    _31976 = NOVALUE;

    /** execute.e:383					base += 1*/
    _base_65050 = _base_65050 + 1;
LE: 

    /** execute.e:385				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31978 = (object)*(((s1_ptr)_2)->base + _arg_65048);
    _2 = (object)SEQ_PTR(_31978);
    _arg_65048 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_65048)){
        _arg_65048 = (object)DBL_PTR(_arg_65048)->dbl;
    }
    _31978 = NOVALUE;

    /** execute.e:386			end while*/
    goto LA; // [450] 311
LB: 

    /** execute.e:389			arg = SymTab[this_routine][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31980 = (object)*(((s1_ptr)_2)->base + _this_routine_65046);
    _2 = (object)SEQ_PTR(_31980);
    if (!IS_ATOM_INT(_12S_TEMPS_19909)){
        _arg_65048 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    }
    else{
        _arg_65048 = (object)*(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    }
    if (!IS_ATOM_INT(_arg_65048)){
        _arg_65048 = (object)DBL_PTR(_arg_65048)->dbl;
    }
    _31980 = NOVALUE;

    /** execute.e:390			while arg != 0 do*/
LF: 
    if (_arg_65048 == 0)
    goto L10; // [474] 517

    /** execute.e:391				val[arg] = private_block[base]*/
    _2 = (object)SEQ_PTR(_private_block_65049);
    _31983 = (object)*(((s1_ptr)_2)->base + _base_65050);
    Ref(_31983);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_65048);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31983;
    if( _1 != _31983 ){
        DeRef(_1);
    }
    _31983 = NOVALUE;

    /** execute.e:392				base += 1*/
    _base_65050 = _base_65050 + 1;

    /** execute.e:393				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31985 = (object)*(((s1_ptr)_2)->base + _arg_65048);
    _2 = (object)SEQ_PTR(_31985);
    _arg_65048 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_65048)){
        _arg_65048 = (object)DBL_PTR(_arg_65048)->dbl;
    }
    _31985 = NOVALUE;

    /** execute.e:394			end while*/
    goto LF; // [514] 474
L10: 

    /** execute.e:396			SymTab[this_routine][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_this_routine_65046 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_64819;
    DeRef(_1);
    _31987 = NOVALUE;
L1: 

    /** execute.e:398	end procedure*/
    DeRef(_private_block_65049);
    DeRef(_31938);
    _31938 = NOVALUE;
    DeRef(_31972);
    _31972 = NOVALUE;
    DeRef(_31942);
    _31942 = NOVALUE;
    DeRef(_31960);
    _31960 = NOVALUE;
    DeRef(_31930);
    _31930 = NOVALUE;
    DeRef(_31968);
    _31968 = NOVALUE;
    DeRef(_31964);
    _31964 = NOVALUE;
    DeRef(_31934);
    _31934 = NOVALUE;
    return;
    ;
}


object _67is_slice(object _op_65195)
{
    object _31991 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:426		return find( op, SLICE_OPS )*/
    _31991 = find_from(_op_65195, _67SLICE_OPS_65186, 1);
    return _31991;
    ;
}


object _67is_subs(object _op_65199)
{
    object _31993 = NOVALUE;
    object _31992 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:430		if find( op, SUB_OPS ) then*/
    _31992 = find_from(_op_65199, _67SUB_OPS_65172, 1);
    if (_31992 == 0)
    {
        _31992 = NOVALUE;
        goto L1; // [12] 24
    }
    else{
        _31992 = NOVALUE;
    }

    /** execute.e:431			return 1*/
    return 1;
    goto L2; // [21] 35
L1: 

    /** execute.e:433			return is_slice( op )*/
    _31993 = _67is_slice(_op_65199);
    return _31993;
L2: 
    ;
}


object _67subs_opsize(object _op_65206)
{
    object _32025 = NOVALUE;
    object _32023 = NOVALUE;
    object _32022 = NOVALUE;
    object _32021 = NOVALUE;
    object _32020 = NOVALUE;
    object _32019 = NOVALUE;
    object _32018 = NOVALUE;
    object _32017 = NOVALUE;
    object _32016 = NOVALUE;
    object _32015 = NOVALUE;
    object _32014 = NOVALUE;
    object _32013 = NOVALUE;
    object _32012 = NOVALUE;
    object _32011 = NOVALUE;
    object _32010 = NOVALUE;
    object _32009 = NOVALUE;
    object _32008 = NOVALUE;
    object _32006 = NOVALUE;
    object _32005 = NOVALUE;
    object _32004 = NOVALUE;
    object _32003 = NOVALUE;
    object _32002 = NOVALUE;
    object _32001 = NOVALUE;
    object _32000 = NOVALUE;
    object _31999 = NOVALUE;
    object _31998 = NOVALUE;
    object _31997 = NOVALUE;
    object _31996 = NOVALUE;
    object _31995 = NOVALUE;
    object _31994 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:438		if op = RHS_SUBS or op = RHS_SUBS_CHECK or op = PASSIGN_SUBS or op = ASSIGN_SUBS*/
    _31994 = (_op_65206 == 25);
    if (_31994 != 0) {
        _31995 = 1;
        goto L1; // [11] 25
    }
    _31996 = (_op_65206 == 92);
    _31995 = (_31996 != 0);
L1: 
    if (_31995 != 0) {
        _31997 = 1;
        goto L2; // [25] 39
    }
    _31998 = (_op_65206 == 162);
    _31997 = (_31998 != 0);
L2: 
    if (_31997 != 0) {
        _31999 = 1;
        goto L3; // [39] 53
    }
    _32000 = (_op_65206 == 16);
    _31999 = (_32000 != 0);
L3: 
    if (_31999 != 0) {
        _32001 = 1;
        goto L4; // [53] 67
    }
    _32002 = (_op_65206 == 149);
    _32001 = (_32002 != 0);
L4: 
    if (_32001 != 0) {
        _32003 = 1;
        goto L5; // [67] 81
    }
    _32004 = (_op_65206 == 84);
    _32003 = (_32004 != 0);
L5: 
    if (_32003 != 0) {
        _32005 = 1;
        goto L6; // [81] 95
    }
    _32006 = (_op_65206 == 118);
    _32005 = (_32006 != 0);
L6: 
    if (_32005 != 0) {
        goto L7; // [95] 110
    }
    _32008 = (_op_65206 == 164);
    if (_32008 == 0)
    {
        DeRef(_32008);
        _32008 = NOVALUE;
        goto L8; // [106] 119
    }
    else{
        DeRef(_32008);
        _32008 = NOVALUE;
    }
L7: 

    /** execute.e:442			return 4*/
    DeRef(_32000);
    _32000 = NOVALUE;
    DeRef(_31994);
    _31994 = NOVALUE;
    DeRef(_31998);
    _31998 = NOVALUE;
    DeRef(_31996);
    _31996 = NOVALUE;
    DeRef(_32002);
    _32002 = NOVALUE;
    DeRef(_32006);
    _32006 = NOVALUE;
    DeRef(_32004);
    _32004 = NOVALUE;
    return 4;
    goto L9; // [116] 256
L8: 

    /** execute.e:443		elsif op = LHS_SUBS1 or op = LHS_SUBS or op = LHS_SUBS1_COPY*/
    _32009 = (_op_65206 == 161);
    if (_32009 != 0) {
        _32010 = 1;
        goto LA; // [127] 141
    }
    _32011 = (_op_65206 == 95);
    _32010 = (_32011 != 0);
LA: 
    if (_32010 != 0) {
        _32012 = 1;
        goto LB; // [141] 155
    }
    _32013 = (_op_65206 == 166);
    _32012 = (_32013 != 0);
LB: 
    if (_32012 != 0) {
        _32014 = 1;
        goto LC; // [155] 169
    }
    _32015 = (_op_65206 == 45);
    _32014 = (_32015 != 0);
LC: 
    if (_32014 != 0) {
        _32016 = 1;
        goto LD; // [169] 183
    }
    _32017 = (_op_65206 == 163);
    _32016 = (_32017 != 0);
LD: 
    if (_32016 != 0) {
        _32018 = 1;
        goto LE; // [183] 197
    }
    _32019 = (_op_65206 == 46);
    _32018 = (_32019 != 0);
LE: 
    if (_32018 != 0) {
        _32020 = 1;
        goto LF; // [197] 211
    }
    _32021 = (_op_65206 == 150);
    _32020 = (_32021 != 0);
LF: 
    if (_32020 != 0) {
        _32022 = 1;
        goto L10; // [211] 225
    }
    _32023 = (_op_65206 == 165);
    _32022 = (_32023 != 0);
L10: 
    if (_32022 != 0) {
        goto L11; // [225] 240
    }
    _32025 = (_op_65206 == 163);
    if (_32025 == 0)
    {
        DeRef(_32025);
        _32025 = NOVALUE;
        goto L12; // [236] 249
    }
    else{
        DeRef(_32025);
        _32025 = NOVALUE;
    }
L11: 

    /** execute.e:448			return 5*/
    DeRef(_32023);
    _32023 = NOVALUE;
    DeRef(_32017);
    _32017 = NOVALUE;
    DeRef(_32009);
    _32009 = NOVALUE;
    DeRef(_32000);
    _32000 = NOVALUE;
    DeRef(_32015);
    _32015 = NOVALUE;
    DeRef(_32011);
    _32011 = NOVALUE;
    DeRef(_31994);
    _31994 = NOVALUE;
    DeRef(_31998);
    _31998 = NOVALUE;
    DeRef(_32021);
    _32021 = NOVALUE;
    DeRef(_31996);
    _31996 = NOVALUE;
    DeRef(_32002);
    _32002 = NOVALUE;
    DeRef(_32006);
    _32006 = NOVALUE;
    DeRef(_32013);
    _32013 = NOVALUE;
    DeRef(_32019);
    _32019 = NOVALUE;
    DeRef(_32004);
    _32004 = NOVALUE;
    return 5;
    goto L9; // [246] 256
L12: 

    /** execute.e:450			return 1*/
    DeRef(_32023);
    _32023 = NOVALUE;
    DeRef(_32017);
    _32017 = NOVALUE;
    DeRef(_32009);
    _32009 = NOVALUE;
    DeRef(_32000);
    _32000 = NOVALUE;
    DeRef(_32015);
    _32015 = NOVALUE;
    DeRef(_32011);
    _32011 = NOVALUE;
    DeRef(_31994);
    _31994 = NOVALUE;
    DeRef(_31998);
    _31998 = NOVALUE;
    DeRef(_32021);
    _32021 = NOVALUE;
    DeRef(_31996);
    _31996 = NOVALUE;
    DeRef(_32002);
    _32002 = NOVALUE;
    DeRef(_32006);
    _32006 = NOVALUE;
    DeRef(_32013);
    _32013 = NOVALUE;
    DeRef(_32019);
    _32019 = NOVALUE;
    DeRef(_32004);
    _32004 = NOVALUE;
    return 1;
L9: 
    ;
}


object _67sub_dest_offset(object _op_65261)
{
    object _offset_65262 = NOVALUE;
    object _32030 = NOVALUE;
    object _32028 = NOVALUE;
    object _32026 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:455		integer offset = subs_opsize( op ) - 1*/
    _32026 = _67subs_opsize(_op_65261);
    if (IS_ATOM_INT(_32026)) {
        _offset_65262 = _32026 - 1;
    }
    else {
        _offset_65262 = binary_op(MINUS, _32026, 1);
    }
    DeRef(_32026);
    _32026 = NOVALUE;
    if (!IS_ATOM_INT(_offset_65262)) {
        _1 = (object)(DBL_PTR(_offset_65262)->dbl);
        DeRefDS(_offset_65262);
        _offset_65262 = _1;
    }

    /** execute.e:456		if op = LHS_SUBS1_COPY or op = LHS_SUBS1 then*/
    _32028 = (_op_65261 == 166);
    if (_32028 != 0) {
        goto L1; // [23] 38
    }
    _32030 = (_op_65261 == 161);
    if (_32030 == 0)
    {
        DeRef(_32030);
        _32030 = NOVALUE;
        goto L2; // [34] 45
    }
    else{
        DeRef(_32030);
        _32030 = NOVALUE;
    }
L1: 

    /** execute.e:457			offset -= 1*/
    _offset_65262 = _offset_65262 - 1;
L2: 

    /** execute.e:459		return offset*/
    DeRef(_32028);
    _32028 = NOVALUE;
    return _offset_65262;
    ;
}


void _67LookBackForSubscriptSymbol(object _pc_65274, object _sublevel_65275, object _has_slice_65276)
{
    object _op_65277 = NOVALUE;
    object _start_pc_65280 = NOVALUE;
    object _sym_65282 = NOVALUE;
    object _subtext_65298 = NOVALUE;
    object _32071 = NOVALUE;
    object _32070 = NOVALUE;
    object _32069 = NOVALUE;
    object _32068 = NOVALUE;
    object _32067 = NOVALUE;
    object _32066 = NOVALUE;
    object _32065 = NOVALUE;
    object _32064 = NOVALUE;
    object _32063 = NOVALUE;
    object _32060 = NOVALUE;
    object _32059 = NOVALUE;
    object _32058 = NOVALUE;
    object _32057 = NOVALUE;
    object _32056 = NOVALUE;
    object _32055 = NOVALUE;
    object _32054 = NOVALUE;
    object _32053 = NOVALUE;
    object _32052 = NOVALUE;
    object _32051 = NOVALUE;
    object _32050 = NOVALUE;
    object _32049 = NOVALUE;
    object _32048 = NOVALUE;
    object _32047 = NOVALUE;
    object _32046 = NOVALUE;
    object _32042 = NOVALUE;
    object _32041 = NOVALUE;
    object _32040 = NOVALUE;
    object _32039 = NOVALUE;
    object _32038 = NOVALUE;
    object _32037 = NOVALUE;
    object _32035 = NOVALUE;
    object _32033 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sublevel_65275)) {
        _1 = (object)(DBL_PTR(_sublevel_65275)->dbl);
        DeRefDS(_sublevel_65275);
        _sublevel_65275 = _1;
    }

    /** execute.e:464		integer op = Code[pc]*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _op_65277 = (object)*(((s1_ptr)_2)->base + _pc_65274);
    if (!IS_ATOM_INT(_op_65277)){
        _op_65277 = (object)DBL_PTR(_op_65277)->dbl;
    }

    /** execute.e:465		integer start_pc = pc*/
    _start_pc_65280 = _pc_65274;

    /** execute.e:466		symtab_pointer sym = Code[pc+1]*/
    _32033 = _pc_65274 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _sym_65282 = (object)*(((s1_ptr)_2)->base + _32033);
    if (!IS_ATOM_INT(_sym_65282)){
        _sym_65282 = (object)DBL_PTR(_sym_65282)->dbl;
    }

    /** execute.e:467		has_slice = has_slice or is_slice( op )*/
    _32035 = _67is_slice(_op_65277);
    if (IS_ATOM_INT(_32035)) {
        _has_slice_65276 = (_has_slice_65276 != 0 || _32035 != 0);
    }
    else {
        _has_slice_65276 = binary_op(OR, _has_slice_65276, _32035);
    }
    DeRef(_32035);
    _32035 = NOVALUE;
    if (!IS_ATOM_INT(_has_slice_65276)) {
        _1 = (object)(DBL_PTR(_has_slice_65276)->dbl);
        DeRefDS(_has_slice_65276);
        _has_slice_65276 = _1;
    }

    /** execute.e:469		if length( SymTab[sym] ) >= S_NAME and length( sym_name( sym ) ) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32037 = (object)*(((s1_ptr)_2)->base + _sym_65282);
    if (IS_SEQUENCE(_32037)){
            _32038 = SEQ_PTR(_32037)->length;
    }
    else {
        _32038 = 1;
    }
    _32037 = NOVALUE;
    if (IS_ATOM_INT(_12S_NAME_19864)) {
        _32039 = (_32038 >= _12S_NAME_19864);
    }
    else {
        _32039 = binary_op(GREATEREQ, _32038, _12S_NAME_19864);
    }
    _32038 = NOVALUE;
    if (IS_ATOM_INT(_32039)) {
        if (_32039 == 0) {
            goto L1; // [65] 204
        }
    }
    else {
        if (DBL_PTR(_32039)->dbl == 0.0) {
            goto L1; // [65] 204
        }
    }
    _32041 = _53sym_name(_sym_65282);
    if (IS_SEQUENCE(_32041)){
            _32042 = SEQ_PTR(_32041)->length;
    }
    else {
        _32042 = 1;
    }
    DeRef(_32041);
    _32041 = NOVALUE;
    if (_32042 == 0)
    {
        _32042 = NOVALUE;
        goto L1; // [77] 204
    }
    else{
        _32042 = NOVALUE;
    }

    /** execute.e:470			sequence subtext*/

    /** execute.e:471			if has_slice then*/
    if (_has_slice_65276 == 0)
    {
        goto L2; // [84] 97
    }
    else{
    }

    /** execute.e:472				subtext = "slice/subscript"*/
    RefDS(_32043);
    DeRefi(_subtext_65298);
    _subtext_65298 = _32043;
    goto L3; // [94] 105
L2: 

    /** execute.e:474				subtext = "subscript"*/
    RefDS(_32044);
    DeRefi(_subtext_65298);
    _subtext_65298 = _32044;
L3: 

    /** execute.e:476			both_printf(" - in %s #%d of '%s'", { subtext, sublevel, sym_name( sym ) } )*/
    _32046 = _53sym_name(_sym_65282);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_subtext_65298);
    ((intptr_t*)_2)[1] = _subtext_65298;
    ((intptr_t*)_2)[2] = _sublevel_65275;
    ((intptr_t*)_2)[3] = _32046;
    _32047 = MAKE_SEQ(_1);
    _32046 = NOVALUE;
    RefDS(_32045);
    _67both_printf(_32045, _32047);
    _32047 = NOVALUE;
    DeRefDSi(_subtext_65298);
    _subtext_65298 = NOVALUE;
    goto L4; // [125] 276

    /** execute.e:480			while pc > 1*/
    goto L1; // [130] 204
L5: 
    _32048 = (_pc_65274 > 1);
    if (_32048 == 0) {
        DeRef(_32049);
        _32049 = 0;
        goto L6; // [137] 198
    }
    _32050 = _67is_subs(_op_65277);
    if (IS_ATOM_INT(_32050)) {
        if (_32050 == 0) {
            DeRef(_32051);
            _32051 = 0;
            goto L7; // [145] 171
        }
    }
    else {
        if (DBL_PTR(_32050)->dbl == 0.0) {
            DeRef(_32051);
            _32051 = 0;
            goto L7; // [145] 171
        }
    }
    _32052 = _67sub_dest_offset(_op_65277);
    if (IS_ATOM_INT(_32052)) {
        _32053 = _pc_65274 + _32052;
    }
    else {
        _32053 = binary_op(PLUS, _pc_65274, _32052);
    }
    DeRef(_32052);
    _32052 = NOVALUE;
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!IS_ATOM_INT(_32053)){
        _32054 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32053)->dbl));
    }
    else{
        _32054 = (object)*(((s1_ptr)_2)->base + _32053);
    }
    if (IS_ATOM_INT(_32054)) {
        _32055 = (_32054 == _sym_65282);
    }
    else {
        _32055 = binary_op(EQUALS, _32054, _sym_65282);
    }
    _32054 = NOVALUE;
    DeRef(_32051);
    if (IS_ATOM_INT(_32055))
    _32051 = (_32055 != 0);
    else
    _32051 = DBL_PTR(_32055)->dbl != 0.0;
L7: 
    _32056 = (_32051 == 0);
    _32051 = NOVALUE;
    if (_32056 != 0) {
        _32057 = 1;
        goto L8; // [174] 194
    }
    _32058 = _67subs_opsize(_op_65277);
    if (IS_ATOM_INT(_32058)) {
        _32059 = _pc_65274 + _32058;
        if ((object)((uintptr_t)_32059 + (uintptr_t)HIGH_BITS) >= 0){
            _32059 = NewDouble((eudouble)_32059);
        }
    }
    else {
        _32059 = binary_op(PLUS, _pc_65274, _32058);
    }
    DeRef(_32058);
    _32058 = NOVALUE;
    if (IS_ATOM_INT(_32059)) {
        _32060 = (_start_pc_65280 <= _32059);
    }
    else {
        _32060 = binary_op(LESSEQ, _start_pc_65280, _32059);
    }
    DeRef(_32059);
    _32059 = NOVALUE;
    if (IS_ATOM_INT(_32060))
    _32057 = (_32060 != 0);
    else
    _32057 = DBL_PTR(_32060)->dbl != 0.0;
L8: 
    DeRef(_32049);
    _32049 = (_32057 != 0);
L6: 
    if (_32049 == 0)
    {
        _32049 = NOVALUE;
        goto L9; // [198] 225
    }
    else{
        _32049 = NOVALUE;
    }

    /** execute.e:487			entry*/
L1: 

    /** execute.e:488				pc -= 1*/
    _pc_65274 = _pc_65274 - 1;

    /** execute.e:489				op = Code[pc]*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _op_65277 = (object)*(((s1_ptr)_2)->base + _pc_65274);
    if (!IS_ATOM_INT(_op_65277)){
        _op_65277 = (object)DBL_PTR(_op_65277)->dbl;
    }

    /** execute.e:490			end while*/
    goto L5; // [222] 133
L9: 

    /** execute.e:492			if is_subs( op ) and (Code[pc + sub_dest_offset( op )] = sym) then*/
    _32063 = _67is_subs(_op_65277);
    if (IS_ATOM_INT(_32063)) {
        if (_32063 == 0) {
            goto LA; // [231] 275
        }
    }
    else {
        if (DBL_PTR(_32063)->dbl == 0.0) {
            goto LA; // [231] 275
        }
    }
    _32065 = _67sub_dest_offset(_op_65277);
    if (IS_ATOM_INT(_32065)) {
        _32066 = _pc_65274 + _32065;
    }
    else {
        _32066 = binary_op(PLUS, _pc_65274, _32065);
    }
    DeRef(_32065);
    _32065 = NOVALUE;
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!IS_ATOM_INT(_32066)){
        _32067 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32066)->dbl));
    }
    else{
        _32067 = (object)*(((s1_ptr)_2)->base + _32066);
    }
    if (IS_ATOM_INT(_32067)) {
        _32068 = (_32067 == _sym_65282);
    }
    else {
        _32068 = binary_op(EQUALS, _32067, _sym_65282);
    }
    _32067 = NOVALUE;
    if (_32068 == 0) {
        DeRef(_32068);
        _32068 = NOVALUE;
        goto LA; // [254] 275
    }
    else {
        if (!IS_ATOM_INT(_32068) && DBL_PTR(_32068)->dbl == 0.0){
            DeRef(_32068);
            _32068 = NOVALUE;
            goto LA; // [254] 275
        }
        DeRef(_32068);
        _32068 = NOVALUE;
    }
    DeRef(_32068);
    _32068 = NOVALUE;

    /** execute.e:493				LookBackForSubscriptSymbol( pc, sublevel + 1, has_slice )*/
    _32069 = _sublevel_65275 + 1;
    if (_32069 > MAXINT){
        _32069 = NewDouble((eudouble)_32069);
    }
    DeRef(_32070);
    _32070 = _pc_65274;
    DeRef(_32071);
    _32071 = _has_slice_65276;
    _67LookBackForSubscriptSymbol(_32070, _32069, _32071);
    _32070 = NOVALUE;
    _32069 = NOVALUE;
    _32071 = NOVALUE;
LA: 
L4: 

    /** execute.e:496	end procedure*/
    DeRef(_32055);
    _32055 = NOVALUE;
    DeRef(_32066);
    _32066 = NOVALUE;
    DeRef(_32056);
    _32056 = NOVALUE;
    _32041 = NOVALUE;
    DeRef(_32063);
    _32063 = NOVALUE;
    DeRef(_32060);
    _32060 = NOVALUE;
    _32037 = NOVALUE;
    DeRef(_32053);
    _32053 = NOVALUE;
    DeRef(_32050);
    _32050 = NOVALUE;
    DeRef(_32048);
    _32048 = NOVALUE;
    DeRef(_32039);
    _32039 = NOVALUE;
    DeRef(_32033);
    _32033 = NOVALUE;
    return;
    ;
}


void _67CheckSubsError()
{
    object _op_65339 = NOVALUE;
    object _32073 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:499		integer op = Code[pc]*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _op_65339 = (object)*(((s1_ptr)_2)->base + _67pc_64802);
    if (!IS_ATOM_INT(_op_65339)){
        _op_65339 = (object)DBL_PTR(_op_65339)->dbl;
    }

    /** execute.e:500		if is_subs( op ) then*/
    _32073 = _67is_subs(_op_65339);
    if (_32073 == 0) {
        DeRef(_32073);
        _32073 = NOVALUE;
        goto L1; // [19] 32
    }
    else {
        if (!IS_ATOM_INT(_32073) && DBL_PTR(_32073)->dbl == 0.0){
            DeRef(_32073);
            _32073 = NOVALUE;
            goto L1; // [19] 32
        }
        DeRef(_32073);
        _32073 = NOVALUE;
    }
    DeRef(_32073);
    _32073 = NOVALUE;

    /** execute.e:501			LookBackForSubscriptSymbol( pc, 1, 0 )*/
    _67LookBackForSubscriptSymbol(_67pc_64802, 1, 0);
L1: 

    /** execute.e:503	end procedure*/
    return;
    ;
}


void _67trace_back(object _msg_65346)
{
    object _sub_65348 = NOVALUE;
    object _v_65349 = NOVALUE;
    object _levels_65350 = NOVALUE;
    object _prev_file_no_65351 = NOVALUE;
    object _task_65352 = NOVALUE;
    object _dash_count_65353 = NOVALUE;
    object _routine_name_65354 = NOVALUE;
    object _title_65355 = NOVALUE;
    object _show_message_65357 = NOVALUE;
    object _32223 = NOVALUE;
    object _32222 = NOVALUE;
    object _32220 = NOVALUE;
    object _32217 = NOVALUE;
    object _32215 = NOVALUE;
    object _32214 = NOVALUE;
    object _32213 = NOVALUE;
    object _32212 = NOVALUE;
    object _32211 = NOVALUE;
    object _32210 = NOVALUE;
    object _32209 = NOVALUE;
    object _32208 = NOVALUE;
    object _32207 = NOVALUE;
    object _32206 = NOVALUE;
    object _32205 = NOVALUE;
    object _32204 = NOVALUE;
    object _32203 = NOVALUE;
    object _32202 = NOVALUE;
    object _32200 = NOVALUE;
    object _32198 = NOVALUE;
    object _32194 = NOVALUE;
    object _32192 = NOVALUE;
    object _32190 = NOVALUE;
    object _32189 = NOVALUE;
    object _32188 = NOVALUE;
    object _32187 = NOVALUE;
    object _32186 = NOVALUE;
    object _32185 = NOVALUE;
    object _32184 = NOVALUE;
    object _32183 = NOVALUE;
    object _32182 = NOVALUE;
    object _32181 = NOVALUE;
    object _32179 = NOVALUE;
    object _32176 = NOVALUE;
    object _32175 = NOVALUE;
    object _32173 = NOVALUE;
    object _32172 = NOVALUE;
    object _32171 = NOVALUE;
    object _32169 = NOVALUE;
    object _32168 = NOVALUE;
    object _32167 = NOVALUE;
    object _32166 = NOVALUE;
    object _32165 = NOVALUE;
    object _32164 = NOVALUE;
    object _32163 = NOVALUE;
    object _32162 = NOVALUE;
    object _32161 = NOVALUE;
    object _32160 = NOVALUE;
    object _32158 = NOVALUE;
    object _32156 = NOVALUE;
    object _32155 = NOVALUE;
    object _32154 = NOVALUE;
    object _32153 = NOVALUE;
    object _32152 = NOVALUE;
    object _32151 = NOVALUE;
    object _32150 = NOVALUE;
    object _32149 = NOVALUE;
    object _32148 = NOVALUE;
    object _32147 = NOVALUE;
    object _32146 = NOVALUE;
    object _32145 = NOVALUE;
    object _32144 = NOVALUE;
    object _32143 = NOVALUE;
    object _32142 = NOVALUE;
    object _32140 = NOVALUE;
    object _32138 = NOVALUE;
    object _32137 = NOVALUE;
    object _32136 = NOVALUE;
    object _32135 = NOVALUE;
    object _32134 = NOVALUE;
    object _32126 = NOVALUE;
    object _32125 = NOVALUE;
    object _32123 = NOVALUE;
    object _32122 = NOVALUE;
    object _32121 = NOVALUE;
    object _32120 = NOVALUE;
    object _32109 = NOVALUE;
    object _32108 = NOVALUE;
    object _32107 = NOVALUE;
    object _32104 = NOVALUE;
    object _32102 = NOVALUE;
    object _32101 = NOVALUE;
    object _32100 = NOVALUE;
    object _32099 = NOVALUE;
    object _32096 = NOVALUE;
    object _32094 = NOVALUE;
    object _32092 = NOVALUE;
    object _32091 = NOVALUE;
    object _32090 = NOVALUE;
    object _32087 = NOVALUE;
    object _32086 = NOVALUE;
    object _32085 = NOVALUE;
    object _32084 = NOVALUE;
    object _32083 = NOVALUE;
    object _32079 = NOVALUE;
    object _32076 = NOVALUE;
    object _32075 = NOVALUE;
    object _32074 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:508		integer levels, prev_file_no, task, dash_count*/

    /** execute.e:509		sequence routine_name, title*/

    /** execute.e:512		if atom(slist[$]) then*/
    if (IS_SEQUENCE(_12slist_20317)){
            _32074 = SEQ_PTR(_12slist_20317)->length;
    }
    else {
        _32074 = 1;
    }
    _2 = (object)SEQ_PTR(_12slist_20317);
    _32075 = (object)*(((s1_ptr)_2)->base + _32074);
    _32076 = IS_ATOM(_32075);
    _32075 = NOVALUE;
    if (_32076 == 0)
    {
        _32076 = NOVALUE;
        goto L1; // [21] 35
    }
    else{
        _32076 = NOVALUE;
    }

    /** execute.e:513			slist = s_expand(slist)*/
    RefDS(_12slist_20317);
    _0 = _61s_expand(_12slist_20317);
    DeRefDS(_12slist_20317);
    _12slist_20317 = _0;
L1: 

    /** execute.e:518		show_message = TRUE*/
    _show_message_65357 = _9TRUE_446;

    /** execute.e:520		screen_err_out = atom(crash_msg)*/
    _67screen_err_out_64862 = IS_ATOM(_67crash_msg_64728);

    /** execute.e:522		while TRUE do*/
L2: 
    if (_9TRUE_446 == 0)
    {
        goto L3; // [56] 978
    }
    else{
    }

    /** execute.e:523			if length(tcb) > 1 then*/
    if (IS_SEQUENCE(_67tcb_64845)){
            _32079 = SEQ_PTR(_67tcb_64845)->length;
    }
    else {
        _32079 = 1;
    }
    if (_32079 <= 1)
    goto L4; // [66] 208

    /** execute.e:526				if current_task = 1 then*/
    if (_67current_task_64819 != 1)
    goto L5; // [74] 88

    /** execute.e:527					routine_name = "initial task"*/
    RefDS(_32082);
    DeRef(_routine_name_65354);
    _routine_name_65354 = _32082;
    goto L6; // [85] 127
L5: 

    /** execute.e:529					routine_name = SymTab[e_routine[1+tcb[current_task][TASK_RID]]][S_NAME]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32083 = (object)*(((s1_ptr)_2)->base + _67current_task_64819);
    _2 = (object)SEQ_PTR(_32083);
    _32084 = (object)*(((s1_ptr)_2)->base + 1);
    _32083 = NOVALUE;
    if (IS_ATOM_INT(_32084)) {
        _32085 = _32084 + 1;
    }
    else
    _32085 = binary_op(PLUS, 1, _32084);
    _32084 = NOVALUE;
    _2 = (object)SEQ_PTR(_67e_routine_64850);
    if (!IS_ATOM_INT(_32085)){
        _32086 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32085)->dbl));
    }
    else{
        _32086 = (object)*(((s1_ptr)_2)->base + _32085);
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32087 = (object)*(((s1_ptr)_2)->base + _32086);
    DeRef(_routine_name_65354);
    _2 = (object)SEQ_PTR(_32087);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _routine_name_65354 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _routine_name_65354 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_routine_name_65354);
    _32087 = NOVALUE;
L6: 

    /** execute.e:532				title = sprintf(" TASK ID %d: %s ",*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32090 = (object)*(((s1_ptr)_2)->base + _67current_task_64819);
    _2 = (object)SEQ_PTR(_32090);
    _32091 = (object)*(((s1_ptr)_2)->base + 2);
    _32090 = NOVALUE;
    RefDS(_routine_name_65354);
    Ref(_32091);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _32091;
    ((intptr_t *)_2)[2] = _routine_name_65354;
    _32092 = MAKE_SEQ(_1);
    _32091 = NOVALUE;
    DeRefi(_title_65355);
    _title_65355 = EPrintf(-9999999, _32089, _32092);
    DeRefDS(_32092);
    _32092 = NOVALUE;

    /** execute.e:534				dash_count = 60*/
    _dash_count_65353 = 60;

    /** execute.e:535				if length(title) < dash_count then*/
    if (IS_SEQUENCE(_title_65355)){
            _32094 = SEQ_PTR(_title_65355)->length;
    }
    else {
        _32094 = 1;
    }
    if (_32094 >= 60)
    goto L7; // [161] 175

    /** execute.e:536					dash_count = 52 - length(title)*/
    if (IS_SEQUENCE(_title_65355)){
            _32096 = SEQ_PTR(_title_65355)->length;
    }
    else {
        _32096 = 1;
    }
    _dash_count_65353 = 52 - _32096;
    _32096 = NOVALUE;
L7: 

    /** execute.e:538				if dash_count < 1 then*/
    if (_dash_count_65353 >= 1)
    goto L8; // [177] 187

    /** execute.e:539					dash_count = 1*/
    _dash_count_65353 = 1;
L8: 

    /** execute.e:541				both_puts(repeat('-', 22) & title & repeat('-', dash_count) & "\n")*/
    _32099 = Repeat(45, 22);
    _32100 = Repeat(45, _dash_count_65353);
    {
        object concat_list[4];

        concat_list[0] = _22210;
        concat_list[1] = _32100;
        concat_list[2] = _title_65355;
        concat_list[3] = _32099;
        Concat_N((object_ptr)&_32101, concat_list, 4);
    }
    DeRefDS(_32100);
    _32100 = NOVALUE;
    DeRefDS(_32099);
    _32099 = NOVALUE;
    _67both_puts(_32101);
    _32101 = NOVALUE;
L4: 

    /** execute.e:544			levels = 1*/
    _levels_65350 = 1;

    /** execute.e:546			while length(call_stack) > 0 do*/
L9: 
    if (IS_SEQUENCE(_67call_stack_64820)){
            _32102 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _32102 = 1;
    }
    if (_32102 <= 0)
    goto LA; // [223] 812

    /** execute.e:547				sub = call_stack[$]*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _32104 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _32104 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_64820);
    _sub_65348 = (object)*(((s1_ptr)_2)->base + _32104);
    if (!IS_ATOM_INT(_sub_65348)){
        _sub_65348 = (object)DBL_PTR(_sub_65348)->dbl;
    }

    /** execute.e:548				if levels = 1 then*/
    if (_levels_65350 != 1)
    goto LB; // [242] 254

    /** execute.e:549					puts(2, '\n')*/
    EPuts(2, 10); // DJP 
    goto LC; // [251] 283
LB: 

    /** execute.e:551				elsif sub != call_back_routine and sub != delete_code_routine then*/
    _32107 = (_sub_65348 != _67call_back_routine_64736);
    if (_32107 == 0) {
        goto LD; // [262] 282
    }
    _32109 = (_sub_65348 != _67delete_code_routine_64737);
    if (_32109 == 0)
    {
        DeRef(_32109);
        _32109 = NOVALUE;
        goto LD; // [273] 282
    }
    else{
        DeRef(_32109);
        _32109 = NOVALUE;
    }

    /** execute.e:552					both_puts("... called from ")*/
    RefDS(_32110);
    _67both_puts(_32110);
LD: 
LC: 

    /** execute.e:556				if sub = call_back_routine then*/
    if (_sub_65348 != _67call_back_routine_64736)
    goto LE; // [287] 327

    /** execute.e:557					if crash_count > 0 then*/
    if (_67crash_count_64739 <= 0)
    goto LF; // [295] 311

    /** execute.e:558						both_puts("^^^ called to handle run-time crash\n")*/
    RefDS(_32113);
    _67both_puts(_32113);

    /** execute.e:559						exit*/
    goto LA; // [306] 812
    goto L10; // [308] 757
LF: 

    /** execute.e:561						both_puts("^^^ call-back from ")*/
    RefDS(_32114);
    _67both_puts(_32114);

    /** execute.e:562						ifdef WINDOWS then*/

    /** execute.e:565							both_puts("external program\n")*/
    RefDS(_32116);
    _67both_puts(_32116);
    goto L10; // [324] 757
LE: 

    /** execute.e:568				elsif sub = delete_code_routine then*/
    if (_sub_65348 != _67delete_code_routine_64737)
    goto L11; // [331] 343

    /** execute.e:569					both_puts("^^^ delete routine\n")*/
    RefDS(_32118);
    _67both_puts(_32118);
    goto L10; // [340] 757
L11: 

    /** execute.e:572					both_printf("%s:%d", find_line(sub, pc))*/
    _32120 = _67find_line(_sub_65348, _67pc_64802);
    RefDS(_32119);
    _67both_printf(_32119, _32120);
    _32120 = NOVALUE;

    /** execute.e:574					if not equal(SymTab[sub][S_NAME], "<TopLevel>") then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32121 = (object)*(((s1_ptr)_2)->base + _sub_65348);
    _2 = (object)SEQ_PTR(_32121);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _32122 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _32122 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _32121 = NOVALUE;
    if (_32122 == _24583)
    _32123 = 1;
    else if (IS_ATOM_INT(_32122) && IS_ATOM_INT(_24583))
    _32123 = 0;
    else
    _32123 = (compare(_32122, _24583) == 0);
    _32122 = NOVALUE;
    if (_32123 != 0)
    goto L12; // [374] 462
    _32123 = NOVALUE;

    /** execute.e:575						switch SymTab[sub][S_TOKEN] do*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32125 = (object)*(((s1_ptr)_2)->base + _sub_65348);
    _2 = (object)SEQ_PTR(_32125);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _32126 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _32126 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _32125 = NOVALUE;
    if (IS_SEQUENCE(_32126) ){
        goto L13; // [391] 431
    }
    if(!IS_ATOM_INT(_32126)){
        if( (DBL_PTR(_32126)->dbl != (eudouble) ((object) DBL_PTR(_32126)->dbl) ) ){
            goto L13; // [391] 431
        }
        _0 = (object) DBL_PTR(_32126)->dbl;
    }
    else {
        _0 = _32126;
    };
    _32126 = NOVALUE;
    switch ( _0 ){ 

        /** execute.e:576							case PROC then*/
        case 27:

        /** execute.e:577								both_puts(" in procedure ")*/
        RefDS(_32129);
        _67both_puts(_32129);
        goto L14; // [405] 439

        /** execute.e:579							case FUNC then*/
        case 501:

        /** execute.e:580								both_puts(" in function ")*/
        RefDS(_32130);
        _67both_puts(_32130);
        goto L14; // [416] 439

        /** execute.e:582							case TYPE then*/
        case 504:

        /** execute.e:583								both_puts(" in type ")*/
        RefDS(_32131);
        _67both_puts(_32131);
        goto L14; // [427] 439

        /** execute.e:585							case else*/
        default:
L13: 

        /** execute.e:586								RTInternal("SymTab[sub][S_TOKEN] is not a routine")*/
        RefDS(_32132);
        _67RTInternal(_32132);
    ;}L14: 

    /** execute.e:590						both_printf("%s()", {SymTab[sub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32134 = (object)*(((s1_ptr)_2)->base + _sub_65348);
    _2 = (object)SEQ_PTR(_32134);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _32135 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _32135 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _32134 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_32135);
    ((intptr_t*)_2)[1] = _32135;
    _32136 = MAKE_SEQ(_1);
    _32135 = NOVALUE;
    RefDS(_32133);
    _67both_printf(_32133, _32136);
    _32136 = NOVALUE;
L12: 

    /** execute.e:593					both_puts("\n")*/
    RefDS(_22210);
    _67both_puts(_22210);

    /** execute.e:595					if show_message then*/
    if (_show_message_65357 == 0)
    {
        goto L15; // [469] 515
    }
    else{
    }

    /** execute.e:596						if sequence(crash_msg) then*/
    _32137 = IS_SEQUENCE(_67crash_msg_64728);
    if (_32137 == 0)
    {
        _32137 = NOVALUE;
        goto L16; // [479] 493
    }
    else{
        _32137 = NOVALUE;
    }

    /** execute.e:597							clear_screen()*/
    ClearScreen();

    /** execute.e:598							puts(2, crash_msg)*/
    EPuts(2, _67crash_msg_64728); // DJP 
L16: 

    /** execute.e:600						both_puts(msg)*/
    RefDS(_msg_65346);
    _67both_puts(_msg_65346);

    /** execute.e:601						CheckSubsError()*/
    _67CheckSubsError();

    /** execute.e:602						both_puts(" \n")*/
    RefDS(_24290);
    _67both_puts(_24290);

    /** execute.e:603						show_message = FALSE*/
    _show_message_65357 = _9FALSE_444;
L15: 

    /** execute.e:606					if length(call_stack) < 2 then*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _32138 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _32138 = 1;
    }
    if (_32138 >= 2)
    goto L17; // [522] 536

    /** execute.e:607						both_puts('\n')*/
    _67both_puts(10);

    /** execute.e:608						exit*/
    goto LA; // [533] 812
L17: 

    /** execute.e:612					v = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32140 = (object)*(((s1_ptr)_2)->base + _sub_65348);
    _2 = (object)SEQ_PTR(_32140);
    _v_65349 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_v_65349)){
        _v_65349 = (object)DBL_PTR(_v_65349)->dbl;
    }
    _32140 = NOVALUE;

    /** execute.e:614					while v != 0 and*/
L18: 
    _32142 = (_v_65349 != 0);
    if (_32142 == 0) {
        goto L19; // [561] 686
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32144 = (object)*(((s1_ptr)_2)->base + _v_65349);
    _2 = (object)SEQ_PTR(_32144);
    _32145 = (object)*(((s1_ptr)_2)->base + 4);
    _32144 = NOVALUE;
    if (IS_ATOM_INT(_32145)) {
        _32146 = (_32145 == 3);
    }
    else {
        _32146 = binary_op(EQUALS, _32145, 3);
    }
    _32145 = NOVALUE;
    if (IS_ATOM_INT(_32146)) {
        if (_32146 != 0) {
            DeRef(_32147);
            _32147 = 1;
            goto L1A; // [583] 609
        }
    }
    else {
        if (DBL_PTR(_32146)->dbl != 0.0) {
            DeRef(_32147);
            _32147 = 1;
            goto L1A; // [583] 609
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32148 = (object)*(((s1_ptr)_2)->base + _v_65349);
    _2 = (object)SEQ_PTR(_32148);
    _32149 = (object)*(((s1_ptr)_2)->base + 4);
    _32148 = NOVALUE;
    if (IS_ATOM_INT(_32149)) {
        _32150 = (_32149 == 2);
    }
    else {
        _32150 = binary_op(EQUALS, _32149, 2);
    }
    _32149 = NOVALUE;
    DeRef(_32147);
    if (IS_ATOM_INT(_32150))
    _32147 = (_32150 != 0);
    else
    _32147 = DBL_PTR(_32150)->dbl != 0.0;
L1A: 
    if (_32147 != 0) {
        DeRef(_32151);
        _32151 = 1;
        goto L1B; // [609] 635
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32152 = (object)*(((s1_ptr)_2)->base + _v_65349);
    _2 = (object)SEQ_PTR(_32152);
    _32153 = (object)*(((s1_ptr)_2)->base + 4);
    _32152 = NOVALUE;
    if (IS_ATOM_INT(_32153)) {
        _32154 = (_32153 == 9);
    }
    else {
        _32154 = binary_op(EQUALS, _32153, 9);
    }
    _32153 = NOVALUE;
    if (IS_ATOM_INT(_32154))
    _32151 = (_32154 != 0);
    else
    _32151 = DBL_PTR(_32154)->dbl != 0.0;
L1B: 
    if (_32151 == 0)
    {
        _32151 = NOVALUE;
        goto L19; // [636] 686
    }
    else{
        _32151 = NOVALUE;
    }

    /** execute.e:618						if SymTab[v][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32155 = (object)*(((s1_ptr)_2)->base + _v_65349);
    _2 = (object)SEQ_PTR(_32155);
    _32156 = (object)*(((s1_ptr)_2)->base + 4);
    _32155 = NOVALUE;
    if (binary_op_a(EQUALS, _32156, 9)){
        _32156 = NOVALUE;
        goto L1C; // [655] 665
    }
    _32156 = NOVALUE;

    /** execute.e:619							show_var(v)*/
    _67show_var(_v_65349);
L1C: 

    /** execute.e:622						v = SymTab[v][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32158 = (object)*(((s1_ptr)_2)->base + _v_65349);
    _2 = (object)SEQ_PTR(_32158);
    _v_65349 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_v_65349)){
        _v_65349 = (object)DBL_PTR(_v_65349)->dbl;
    }
    _32158 = NOVALUE;

    /** execute.e:623					end while*/
    goto L18; // [683] 557
L19: 

    /** execute.e:625					if length(SymTab[sub][S_SAVED_PRIVATES]) > 0 and*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32160 = (object)*(((s1_ptr)_2)->base + _sub_65348);
    _2 = (object)SEQ_PTR(_32160);
    _32161 = (object)*(((s1_ptr)_2)->base + 26);
    _32160 = NOVALUE;
    if (IS_SEQUENCE(_32161)){
            _32162 = SEQ_PTR(_32161)->length;
    }
    else {
        _32162 = 1;
    }
    _32161 = NOVALUE;
    _32163 = (_32162 > 0);
    _32162 = NOVALUE;
    if (_32163 == 0) {
        goto L1D; // [707] 756
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32165 = (object)*(((s1_ptr)_2)->base + _sub_65348);
    _2 = (object)SEQ_PTR(_32165);
    _32166 = (object)*(((s1_ptr)_2)->base + 26);
    _32165 = NOVALUE;
    _2 = (object)SEQ_PTR(_32166);
    _32167 = (object)*(((s1_ptr)_2)->base + 1);
    _32166 = NOVALUE;
    if (IS_ATOM_INT(_32167)) {
        _32168 = (_32167 != 0);
    }
    else {
        _32168 = binary_op(NOTEQ, _32167, 0);
    }
    _32167 = NOVALUE;
    if (_32168 == 0) {
        DeRef(_32168);
        _32168 = NOVALUE;
        goto L1D; // [732] 756
    }
    else {
        if (!IS_ATOM_INT(_32168) && DBL_PTR(_32168)->dbl == 0.0){
            DeRef(_32168);
            _32168 = NOVALUE;
            goto L1D; // [732] 756
        }
        DeRef(_32168);
        _32168 = NOVALUE;
    }
    DeRef(_32168);
    _32168 = NOVALUE;

    /** execute.e:627						SymTab[sub][S_RESIDENT_TASK] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_65348 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _32169 = NOVALUE;

    /** execute.e:628						restore_privates(sub)*/
    _67restore_privates(_sub_65348);
L1D: 
L10: 

    /** execute.e:632				puts(err_file, '\n')*/
    EPuts(_67err_file_64851, 10); // DJP 

    /** execute.e:635				pc = call_stack[$-1] - 1*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _32171 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _32171 = 1;
    }
    _32172 = _32171 - 1;
    _32171 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_64820);
    _32173 = (object)*(((s1_ptr)_2)->base + _32172);
    if (IS_ATOM_INT(_32173)) {
        _67pc_64802 = _32173 - 1;
    }
    else {
        _67pc_64802 = binary_op(MINUS, _32173, 1);
    }
    _32173 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_64802)) {
        _1 = (object)(DBL_PTR(_67pc_64802)->dbl);
        DeRefDS(_67pc_64802);
        _67pc_64802 = _1;
    }

    /** execute.e:636				call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _32175 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _32175 = 1;
    }
    _32176 = _32175 - 2;
    _32175 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_64820;
    RHS_Slice(_67call_stack_64820, 1, _32176);

    /** execute.e:637				levels += 1*/
    _levels_65350 = _levels_65350 + 1;

    /** execute.e:638			end while*/
    goto L9; // [809] 218
LA: 

    /** execute.e:640			tcb[current_task][TASK_STATE] = ST_DEAD -- mark as "deleted"*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64819 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _32179 = NOVALUE;

    /** execute.e:643			task = current_task*/
    _task_65352 = _67current_task_64819;

    /** execute.e:644			for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_64845)){
            _32181 = SEQ_PTR(_67tcb_64845)->length;
    }
    else {
        _32181 = 1;
    }
    {
        object _i_65533;
        _i_65533 = 1;
L1E: 
        if (_i_65533 > _32181){
            goto L1F; // [841] 955
        }

        /** execute.e:645				if tcb[i][TASK_STATE] != ST_DEAD and*/
        _2 = (object)SEQ_PTR(_67tcb_64845);
        _32182 = (object)*(((s1_ptr)_2)->base + _i_65533);
        _2 = (object)SEQ_PTR(_32182);
        _32183 = (object)*(((s1_ptr)_2)->base + 4);
        _32182 = NOVALUE;
        if (IS_ATOM_INT(_32183)) {
            _32184 = (_32183 != 2);
        }
        else {
            _32184 = binary_op(NOTEQ, _32183, 2);
        }
        _32183 = NOVALUE;
        if (IS_ATOM_INT(_32184)) {
            if (_32184 == 0) {
                goto L20; // [864] 948
            }
        }
        else {
            if (DBL_PTR(_32184)->dbl == 0.0) {
                goto L20; // [864] 948
            }
        }
        _2 = (object)SEQ_PTR(_67tcb_64845);
        _32186 = (object)*(((s1_ptr)_2)->base + _i_65533);
        _2 = (object)SEQ_PTR(_32186);
        _32187 = (object)*(((s1_ptr)_2)->base + 16);
        _32186 = NOVALUE;
        if (IS_SEQUENCE(_32187)){
                _32188 = SEQ_PTR(_32187)->length;
        }
        else {
            _32188 = 1;
        }
        _32187 = NOVALUE;
        _32189 = (_32188 > 0);
        _32188 = NOVALUE;
        if (_32189 == 0)
        {
            DeRef(_32189);
            _32189 = NOVALUE;
            goto L20; // [886] 948
        }
        else{
            DeRef(_32189);
            _32189 = NOVALUE;
        }

        /** execute.e:647					current_task = i*/
        _67current_task_64819 = _i_65533;

        /** execute.e:648					call_stack = tcb[i][TASK_STACK]*/
        _2 = (object)SEQ_PTR(_67tcb_64845);
        _32190 = (object)*(((s1_ptr)_2)->base + _i_65533);
        DeRef(_67call_stack_64820);
        _2 = (object)SEQ_PTR(_32190);
        _67call_stack_64820 = (object)*(((s1_ptr)_2)->base + 16);
        Ref(_67call_stack_64820);
        _32190 = NOVALUE;

        /** execute.e:649					pc = tcb[i][TASK_PC]*/
        _2 = (object)SEQ_PTR(_67tcb_64845);
        _32192 = (object)*(((s1_ptr)_2)->base + _i_65533);
        _2 = (object)SEQ_PTR(_32192);
        _67pc_64802 = (object)*(((s1_ptr)_2)->base + 14);
        if (!IS_ATOM_INT(_67pc_64802)){
            _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
        }
        _32192 = NOVALUE;

        /** execute.e:650					Code = tcb[i][TASK_CODE]*/
        _2 = (object)SEQ_PTR(_67tcb_64845);
        _32194 = (object)*(((s1_ptr)_2)->base + _i_65533);
        DeRef(_12Code_20315);
        _2 = (object)SEQ_PTR(_32194);
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + 15);
        Ref(_12Code_20315);
        _32194 = NOVALUE;

        /** execute.e:651					screen_err_out = FALSE  -- just show offending task on screen*/
        _67screen_err_out_64862 = _9FALSE_444;

        /** execute.e:652					exit*/
        goto L1F; // [945] 955
L20: 

        /** execute.e:654			end for*/
        _i_65533 = _i_65533 + 1;
        goto L1E; // [950] 848
L1F: 
        ;
    }

    /** execute.e:655			if task = current_task then*/
    if (_task_65352 != _67current_task_64819)
    goto L21; // [959] 968

    /** execute.e:656				exit*/
    goto L3; // [965] 978
L21: 

    /** execute.e:658			both_puts("\n")*/
    RefDS(_22210);
    _67both_puts(_22210);

    /** execute.e:659		end while*/
    goto L2; // [975] 54
L3: 

    /** execute.e:661		puts(2, "\n--> see " & err_file_name & '\n')*/
    {
        object concat_list[3];

        concat_list[0] = 10;
        concat_list[1] = _67err_file_name_64852;
        concat_list[2] = _32197;
        Concat_N((object_ptr)&_32198, concat_list, 3);
    }
    EPuts(2, _32198); // DJP 
    DeRefDS(_32198);
    _32198 = NOVALUE;

    /** execute.e:663		puts(err_file, "\n\nGlobal & Local Variables\n")*/
    EPuts(_67err_file_64851, _32199); // DJP 

    /** execute.e:664		prev_file_no = -1*/
    _prev_file_no_65351 = -1;

    /** execute.e:665		v = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32200 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    _2 = (object)SEQ_PTR(_32200);
    _v_65349 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_v_65349)){
        _v_65349 = (object)DBL_PTR(_v_65349)->dbl;
    }
    _32200 = NOVALUE;

    /** execute.e:666		while v do*/
L22: 
    if (_v_65349 == 0)
    {
        goto L23; // [1026] 1193
    }
    else{
    }

    /** execute.e:667			if SymTab[v][S_TOKEN] = VARIABLE and*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32202 = (object)*(((s1_ptr)_2)->base + _v_65349);
    _2 = (object)SEQ_PTR(_32202);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _32203 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _32203 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _32202 = NOVALUE;
    if (IS_ATOM_INT(_32203)) {
        _32204 = (_32203 == -100);
    }
    else {
        _32204 = binary_op(EQUALS, _32203, -100);
    }
    _32203 = NOVALUE;
    if (IS_ATOM_INT(_32204)) {
        if (_32204 == 0) {
            DeRef(_32205);
            _32205 = 0;
            goto L24; // [1049] 1075
        }
    }
    else {
        if (DBL_PTR(_32204)->dbl == 0.0) {
            DeRef(_32205);
            _32205 = 0;
            goto L24; // [1049] 1075
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32206 = (object)*(((s1_ptr)_2)->base + _v_65349);
    _2 = (object)SEQ_PTR(_32206);
    _32207 = (object)*(((s1_ptr)_2)->base + 3);
    _32206 = NOVALUE;
    if (IS_ATOM_INT(_32207)) {
        _32208 = (_32207 == 1);
    }
    else {
        _32208 = binary_op(EQUALS, _32207, 1);
    }
    _32207 = NOVALUE;
    DeRef(_32205);
    if (IS_ATOM_INT(_32208))
    _32205 = (_32208 != 0);
    else
    _32205 = DBL_PTR(_32208)->dbl != 0.0;
L24: 
    if (_32205 == 0) {
        goto L25; // [1075] 1172
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32210 = (object)*(((s1_ptr)_2)->base + _v_65349);
    _2 = (object)SEQ_PTR(_32210);
    _32211 = (object)*(((s1_ptr)_2)->base + 4);
    _32210 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 5;
    ((intptr_t*)_2)[2] = 6;
    ((intptr_t*)_2)[3] = 4;
    _32212 = MAKE_SEQ(_1);
    _32213 = find_from(_32211, _32212, 1);
    _32211 = NOVALUE;
    DeRefDS(_32212);
    _32212 = NOVALUE;
    if (_32213 == 0)
    {
        _32213 = NOVALUE;
        goto L25; // [1109] 1172
    }
    else{
        _32213 = NOVALUE;
    }

    /** execute.e:670				if SymTab[v][S_FILE_NO] != prev_file_no then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32214 = (object)*(((s1_ptr)_2)->base + _v_65349);
    _2 = (object)SEQ_PTR(_32214);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _32215 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _32215 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _32214 = NOVALUE;
    if (binary_op_a(EQUALS, _32215, _prev_file_no_65351)){
        _32215 = NOVALUE;
        goto L26; // [1126] 1166
    }
    _32215 = NOVALUE;

    /** execute.e:671					prev_file_no = SymTab[v][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32217 = (object)*(((s1_ptr)_2)->base + _v_65349);
    _2 = (object)SEQ_PTR(_32217);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _prev_file_no_65351 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _prev_file_no_65351 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    if (!IS_ATOM_INT(_prev_file_no_65351)){
        _prev_file_no_65351 = (object)DBL_PTR(_prev_file_no_65351)->dbl;
    }
    _32217 = NOVALUE;

    /** execute.e:672					puts(err_file, "\n " & known_files[prev_file_no] & ":\n")*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _32220 = (object)*(((s1_ptr)_2)->base + _prev_file_no_65351);
    {
        object concat_list[3];

        concat_list[0] = _32221;
        concat_list[1] = _32220;
        concat_list[2] = _32219;
        Concat_N((object_ptr)&_32222, concat_list, 3);
    }
    _32220 = NOVALUE;
    EPuts(_67err_file_64851, _32222); // DJP 
    DeRefDS(_32222);
    _32222 = NOVALUE;
L26: 

    /** execute.e:674				show_var(v)*/
    _67show_var(_v_65349);
L25: 

    /** execute.e:676			v = SymTab[v][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32223 = (object)*(((s1_ptr)_2)->base + _v_65349);
    _2 = (object)SEQ_PTR(_32223);
    _v_65349 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_v_65349)){
        _v_65349 = (object)DBL_PTR(_v_65349)->dbl;
    }
    _32223 = NOVALUE;

    /** execute.e:677		end while*/
    goto L22; // [1190] 1026
L23: 

    /** execute.e:678		puts(err_file, '\n')*/
    EPuts(_67err_file_64851, 10); // DJP 

    /** execute.e:679		close(err_file)*/
    EClose(_67err_file_64851);

    /** execute.e:680	end procedure*/
    DeRefDS(_msg_65346);
    DeRef(_routine_name_65354);
    DeRefi(_title_65355);
    DeRef(_32154);
    _32154 = NOVALUE;
    DeRef(_32176);
    _32176 = NOVALUE;
    DeRef(_32184);
    _32184 = NOVALUE;
    DeRef(_32107);
    _32107 = NOVALUE;
    DeRef(_32150);
    _32150 = NOVALUE;
    _32187 = NOVALUE;
    _32086 = NOVALUE;
    DeRef(_32146);
    _32146 = NOVALUE;
    DeRef(_32163);
    _32163 = NOVALUE;
    DeRef(_32204);
    _32204 = NOVALUE;
    DeRef(_32142);
    _32142 = NOVALUE;
    DeRef(_32085);
    _32085 = NOVALUE;
    _32161 = NOVALUE;
    DeRef(_32172);
    _32172 = NOVALUE;
    DeRef(_32208);
    _32208 = NOVALUE;
    return;
    ;
}


void _67call_crash_routines()
{
    object _quit_65610 = NOVALUE;
    object _32234 = NOVALUE;
    object _32232 = NOVALUE;
    object _32231 = NOVALUE;
    object _32230 = NOVALUE;
    object _32229 = NOVALUE;
    object _32228 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:688		if crash_count > 0 then*/
    if (_67crash_count_64739 <= 0)
    goto L1; // [5] 15

    /** execute.e:689			return*/
    DeRef(_quit_65610);
    return;
L1: 

    /** execute.e:692		crash_count += 1*/
    _67crash_count_64739 = _67crash_count_64739 + 1;

    /** execute.e:695		err_file_name = "ex_crash.err"*/
    RefDS(_32227);
    DeRef(_67err_file_name_64852);
    _67err_file_name_64852 = _32227;

    /** execute.e:697		for i = length(crash_list) to 1 by -1 do*/
    if (IS_SEQUENCE(_67crash_list_64738)){
            _32228 = SEQ_PTR(_67crash_list_64738)->length;
    }
    else {
        _32228 = 1;
    }
    {
        object _i_65616;
        _i_65616 = _32228;
L2: 
        if (_i_65616 < 1){
            goto L3; // [37] 94
        }

        /** execute.e:699			quit = call_func(forward_general_callback,*/
        _2 = (object)SEQ_PTR(_67crash_list_64738);
        _32229 = (object)*(((s1_ptr)_2)->base + _i_65616);
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 0;
        Ref(_32229);
        ((intptr_t*)_2)[2] = _32229;
        ((intptr_t*)_2)[3] = 1;
        _32230 = MAKE_SEQ(_1);
        _32229 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 0;
        _32231 = MAKE_SEQ(_1);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _32230;
        ((intptr_t *)_2)[2] = _32231;
        _32232 = MAKE_SEQ(_1);
        _32231 = NOVALUE;
        _32230 = NOVALUE;
        _1 = (object)SEQ_PTR(_32232);
        _2 = (object)((s1_ptr)_1)->base;
        _0 = (object)_00[_67forward_general_callback_65606].addr;
        Ref( *(( (intptr_t*)_2) + 1) );
        Ref( *(( (intptr_t*)_2) + 2) );
        _1 = (*(intptr_t (*)())_0)(
                            *( ((intptr_t *)_2) + 1), 
                            *( ((intptr_t *)_2) + 2)
                             );
        DeRef(_quit_65610);
        _quit_65610 = _1;
        DeRefDS(_32232);
        _32232 = NOVALUE;

        /** execute.e:701			if not equal(quit, 0) then*/
        if (_quit_65610 == 0)
        _32234 = 1;
        else if (IS_ATOM_INT(_quit_65610) && IS_ATOM_INT(0))
        _32234 = 0;
        else
        _32234 = (compare(_quit_65610, 0) == 0);
        if (_32234 != 0)
        goto L4; // [78] 87
        _32234 = NOVALUE;

        /** execute.e:702				return -- don't call the others*/
        DeRef(_quit_65610);
        return;
L4: 

        /** execute.e:704		end for*/
        _i_65616 = _i_65616 + -1;
        goto L2; // [89] 44
L3: 
        ;
    }

    /** execute.e:705	end procedure*/
    DeRef(_quit_65610);
    return;
    ;
}


void _67quit_after_error()
{
    object _35033 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:709		write_coverage_db()*/
    _35033 = _50write_coverage_db();
    DeRef(_35033);
    _35033 = NOVALUE;

    /** execute.e:711		ifdef WINDOWS then*/

    /** execute.e:718		abort(1)*/
    UserCleanup(1);

    /** execute.e:719	end procedure*/
    return;
    ;
}


void _67RTFatalType(object _x_65632)
{
    object _msg_65633 = NOVALUE;
    object _v_65634 = NOVALUE;
    object _vname_65635 = NOVALUE;
    object _32268 = NOVALUE;
    object _32264 = NOVALUE;
    object _32263 = NOVALUE;
    object _32262 = NOVALUE;
    object _32261 = NOVALUE;
    object _32259 = NOVALUE;
    object _32258 = NOVALUE;
    object _32257 = NOVALUE;
    object _32256 = NOVALUE;
    object _32254 = NOVALUE;
    object _32253 = NOVALUE;
    object _32251 = NOVALUE;
    object _32250 = NOVALUE;
    object _32249 = NOVALUE;
    object _32247 = NOVALUE;
    object _32245 = NOVALUE;
    object _32241 = NOVALUE;
    object _32239 = NOVALUE;
    object _32238 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_65632)) {
        _1 = (object)(DBL_PTR(_x_65632)->dbl);
        DeRefDS(_x_65632);
        _x_65632 = _1;
    }

    /** execute.e:726		open_err_file()*/
    _67open_err_file();

    /** execute.e:727		a = Code[x]*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _x_65632);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:728		if length(SymTab[a]) >= S_NAME then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32238 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_SEQUENCE(_32238)){
            _32239 = SEQ_PTR(_32238)->length;
    }
    else {
        _32239 = 1;
    }
    _32238 = NOVALUE;
    if (binary_op_a(LESS, _32239, _12S_NAME_19864)){
        _32239 = NOVALUE;
        goto L1; // [32] 57
    }
    _32239 = NOVALUE;

    /** execute.e:729			vname = SymTab[a][S_NAME]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32241 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    DeRef(_vname_65635);
    _2 = (object)SEQ_PTR(_32241);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _vname_65635 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _vname_65635 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_vname_65635);
    _32241 = NOVALUE;
    goto L2; // [54] 65
L1: 

    /** execute.e:732			vname = "inlined variable"*/
    RefDS(_32243);
    DeRef(_vname_65635);
    _vname_65635 = _32243;
L2: 

    /** execute.e:734		msg = sprintf("type_check failure, %s is ", {vname})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_vname_65635);
    ((intptr_t*)_2)[1] = _vname_65635;
    _32245 = MAKE_SEQ(_1);
    DeRefi(_msg_65633);
    _msg_65633 = EPrintf(-9999999, _32244, _32245);
    DeRefDS(_32245);
    _32245 = NOVALUE;

    /** execute.e:735		v = sprint(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _32247 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    Ref(_32247);
    _0 = _v_65634;
    _v_65634 = _18sprint(_32247);
    DeRef(_0);
    _32247 = NOVALUE;

    /** execute.e:736		if length(v) > 70 - length(vname) then*/
    if (IS_SEQUENCE(_v_65634)){
            _32249 = SEQ_PTR(_v_65634)->length;
    }
    else {
        _32249 = 1;
    }
    if (IS_SEQUENCE(_vname_65635)){
            _32250 = SEQ_PTR(_vname_65635)->length;
    }
    else {
        _32250 = 1;
    }
    _32251 = 70 - _32250;
    _32250 = NOVALUE;
    if (_32249 <= _32251)
    goto L3; // [105] 180

    /** execute.e:737			v = v[1..70 - length(vname)]*/
    if (IS_SEQUENCE(_vname_65635)){
            _32253 = SEQ_PTR(_vname_65635)->length;
    }
    else {
        _32253 = 1;
    }
    _32254 = 70 - _32253;
    _32253 = NOVALUE;
    rhs_slice_target = (object_ptr)&_v_65634;
    RHS_Slice(_v_65634, 1, _32254);

    /** execute.e:738			while length(v) and not find(v[$], ",}")  do*/
L4: 
    if (IS_SEQUENCE(_v_65634)){
            _32256 = SEQ_PTR(_v_65634)->length;
    }
    else {
        _32256 = 1;
    }
    if (_32256 == 0) {
        goto L5; // [131] 173
    }
    if (IS_SEQUENCE(_v_65634)){
            _32258 = SEQ_PTR(_v_65634)->length;
    }
    else {
        _32258 = 1;
    }
    _2 = (object)SEQ_PTR(_v_65634);
    _32259 = (object)*(((s1_ptr)_2)->base + _32258);
    _32261 = find_from(_32259, _32260, 1);
    _32259 = NOVALUE;
    _32262 = (_32261 == 0);
    _32261 = NOVALUE;
    if (_32262 == 0)
    {
        DeRef(_32262);
        _32262 = NOVALUE;
        goto L5; // [151] 173
    }
    else{
        DeRef(_32262);
        _32262 = NOVALUE;
    }

    /** execute.e:739				v = v[1..$-1]*/
    if (IS_SEQUENCE(_v_65634)){
            _32263 = SEQ_PTR(_v_65634)->length;
    }
    else {
        _32263 = 1;
    }
    _32264 = _32263 - 1;
    _32263 = NOVALUE;
    rhs_slice_target = (object_ptr)&_v_65634;
    RHS_Slice(_v_65634, 1, _32264);

    /** execute.e:740			end while*/
    goto L4; // [170] 128
L5: 

    /** execute.e:741			v = v & " ..."*/
    Concat((object_ptr)&_v_65634, _v_65634, _32266);
L3: 

    /** execute.e:743		trace_back(msg & v)*/
    Concat((object_ptr)&_32268, _msg_65633, _v_65634);
    _67trace_back(_32268);
    _32268 = NOVALUE;

    /** execute.e:744		call_crash_routines()*/
    _67call_crash_routines();

    /** execute.e:745		quit_after_error()*/
    _67quit_after_error();

    /** execute.e:746	end procedure*/
    DeRefDSi(_msg_65633);
    DeRefDS(_v_65634);
    DeRef(_vname_65635);
    DeRef(_32264);
    _32264 = NOVALUE;
    _32238 = NOVALUE;
    DeRef(_32251);
    _32251 = NOVALUE;
    DeRef(_32254);
    _32254 = NOVALUE;
    return;
    ;
}


void _67RTFatal(object _msg_65680)
{
    object _0, _1, _2;
    

    /** execute.e:750		open_err_file()*/
    _67open_err_file();

    /** execute.e:751		trace_back(msg)*/
    RefDS(_msg_65680);
    _67trace_back(_msg_65680);

    /** execute.e:752		call_crash_routines()*/
    _67call_crash_routines();

    /** execute.e:753		quit_after_error()*/
    _67quit_after_error();

    /** execute.e:754	end procedure*/
    DeRefDS(_msg_65680);
    return;
    ;
}


void _67RTInternal(object _msg_65683)
{
    object _0, _1, _2;
    

    /** execute.e:761		machine_proc(67, msg)*/
    machine(67, _msg_65683);

    /** execute.e:762	end procedure*/
    DeRefDSi(_msg_65683);
    return;
    ;
}


void _67wait(object _t_65686)
{
    object _t1_65687 = NOVALUE;
    object _t2_65688 = NOVALUE;
    object _32274 = NOVALUE;
    object _32272 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:771		t1 = floor(t)*/
    DeRef(_t1_65687);
    if (IS_ATOM_INT(_t_65686))
    _t1_65687 = e_floor(_t_65686);
    else
    _t1_65687 = unary_op(FLOOR, _t_65686);

    /** execute.e:772		if t1 >= 1 then*/
    if (binary_op_a(LESS, _t1_65687, 1)){
        goto L1; // [8] 24
    }

    /** execute.e:773			sleep(t1)*/
    Ref(_t1_65687);
    _3sleep(_t1_65687);

    /** execute.e:774			t -= t1*/
    _0 = _t_65686;
    if (IS_ATOM_INT(_t_65686) && IS_ATOM_INT(_t1_65687)) {
        _t_65686 = _t_65686 - _t1_65687;
        if ((object)((uintptr_t)_t_65686 +(uintptr_t) HIGH_BITS) >= 0){
            _t_65686 = NewDouble((eudouble)_t_65686);
        }
    }
    else {
        if (IS_ATOM_INT(_t_65686)) {
            _t_65686 = NewDouble((eudouble)_t_65686 - DBL_PTR(_t1_65687)->dbl);
        }
        else {
            if (IS_ATOM_INT(_t1_65687)) {
                _t_65686 = NewDouble(DBL_PTR(_t_65686)->dbl - (eudouble)_t1_65687);
            }
            else
            _t_65686 = NewDouble(DBL_PTR(_t_65686)->dbl - DBL_PTR(_t1_65687)->dbl);
        }
    }
    DeRef(_0);
L1: 

    /** execute.e:777		t2 = time() + t*/
    DeRef(_32272);
    _32272 = NewDouble(current_time());
    DeRef(_t2_65688);
    if (IS_ATOM_INT(_t_65686)) {
        _t2_65688 = NewDouble(DBL_PTR(_32272)->dbl + (eudouble)_t_65686);
    }
    else
    _t2_65688 = NewDouble(DBL_PTR(_32272)->dbl + DBL_PTR(_t_65686)->dbl);
    DeRefDS(_32272);
    _32272 = NOVALUE;

    /** execute.e:778		while time() < t2 do*/
L2: 
    DeRef(_32274);
    _32274 = NewDouble(current_time());
    if (binary_op_a(GREATEREQ, _32274, _t2_65688)){
        DeRefDS(_32274);
        _32274 = NOVALUE;
        goto L3; // [39] 48
    }
    DeRef(_32274);
    _32274 = NOVALUE;

    /** execute.e:779		end while*/
    goto L2; // [45] 37
L3: 

    /** execute.e:780	end procedure*/
    DeRef(_t_65686);
    DeRef(_t1_65687);
    DeRef(_t2_65688);
    return;
    ;
}


void _67scheduler()
{
    object _earliest_time_65704 = NOVALUE;
    object _start_time_65705 = NOVALUE;
    object _now_65706 = NOVALUE;
    object _ts_found_65708 = NOVALUE;
    object _tp_65709 = NOVALUE;
    object _p_65710 = NOVALUE;
    object _earliest_task_65711 = NOVALUE;
    object _32351 = NOVALUE;
    object _32350 = NOVALUE;
    object _32347 = NOVALUE;
    object _32346 = NOVALUE;
    object _32345 = NOVALUE;
    object _32344 = NOVALUE;
    object _32343 = NOVALUE;
    object _32341 = NOVALUE;
    object _32340 = NOVALUE;
    object _32338 = NOVALUE;
    object _32336 = NOVALUE;
    object _32334 = NOVALUE;
    object _32332 = NOVALUE;
    object _32330 = NOVALUE;
    object _32328 = NOVALUE;
    object _32325 = NOVALUE;
    object _32323 = NOVALUE;
    object _32322 = NOVALUE;
    object _32320 = NOVALUE;
    object _32319 = NOVALUE;
    object _32316 = NOVALUE;
    object _32314 = NOVALUE;
    object _32308 = NOVALUE;
    object _32304 = NOVALUE;
    object _32303 = NOVALUE;
    object _32301 = NOVALUE;
    object _32299 = NOVALUE;
    object _32297 = NOVALUE;
    object _32296 = NOVALUE;
    object _32295 = NOVALUE;
    object _32294 = NOVALUE;
    object _32293 = NOVALUE;
    object _32292 = NOVALUE;
    object _32291 = NOVALUE;
    object _32289 = NOVALUE;
    object _32284 = NOVALUE;
    object _32280 = NOVALUE;
    object _32278 = NOVALUE;
    object _32277 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:789		sequence tp*/

    /** execute.e:790		integer p, earliest_task*/

    /** execute.e:795		earliest_task = rt_first*/
    _earliest_task_65711 = _67rt_first_64848;

    /** execute.e:797		if clock_stopped or earliest_task = 0 then*/
    if (_67clock_stopped_65700 != 0) {
        goto L1; // [16] 29
    }
    _32277 = (_earliest_task_65711 == 0);
    if (_32277 == 0)
    {
        DeRef(_32277);
        _32277 = NOVALUE;
        goto L2; // [25] 42
    }
    else{
        DeRef(_32277);
        _32277 = NOVALUE;
    }
L1: 

    /** execute.e:799			start_time = 1*/
    DeRef(_start_time_65705);
    _start_time_65705 = 1;

    /** execute.e:800			now = -1*/
    DeRef(_now_65706);
    _now_65706 = -1;
    goto L3; // [39] 232
L2: 

    /** execute.e:804			earliest_time = tcb[earliest_task][TASK_MAX_TIME]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32278 = (object)*(((s1_ptr)_2)->base + _earliest_task_65711);
    DeRef(_earliest_time_65704);
    _2 = (object)SEQ_PTR(_32278);
    _earliest_time_65704 = (object)*(((s1_ptr)_2)->base + 9);
    Ref(_earliest_time_65704);
    _32278 = NOVALUE;

    /** execute.e:806			p = tcb[rt_first][TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32280 = (object)*(((s1_ptr)_2)->base + _67rt_first_64848);
    _2 = (object)SEQ_PTR(_32280);
    _p_65710 = (object)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_65710)){
        _p_65710 = (object)DBL_PTR(_p_65710)->dbl;
    }
    _32280 = NOVALUE;

    /** execute.e:807			while p != 0 do*/
L4: 
    if (_p_65710 == 0)
    goto L5; // [75] 122

    /** execute.e:808				tp = tcb[p]*/
    DeRef(_tp_65709);
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _tp_65709 = (object)*(((s1_ptr)_2)->base + _p_65710);
    RefDS(_tp_65709);

    /** execute.e:809				if tp[TASK_MAX_TIME] < earliest_time then*/
    _2 = (object)SEQ_PTR(_tp_65709);
    _32284 = (object)*(((s1_ptr)_2)->base + 9);
    if (binary_op_a(GREATEREQ, _32284, _earliest_time_65704)){
        _32284 = NOVALUE;
        goto L6; // [95] 111
    }
    _32284 = NOVALUE;

    /** execute.e:810					earliest_task = p*/
    _earliest_task_65711 = _p_65710;

    /** execute.e:811					earliest_time = tp[TASK_MAX_TIME]*/
    DeRef(_earliest_time_65704);
    _2 = (object)SEQ_PTR(_tp_65709);
    _earliest_time_65704 = (object)*(((s1_ptr)_2)->base + 9);
    Ref(_earliest_time_65704);
L6: 

    /** execute.e:813				p = tp[TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_tp_65709);
    _p_65710 = (object)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_65710))
    _p_65710 = (object)DBL_PTR(_p_65710)->dbl;

    /** execute.e:814			end while*/
    goto L4; // [119] 75
L5: 

    /** execute.e:817			now = time()*/
    DeRef(_now_65706);
    _now_65706 = NewDouble(current_time());

    /** execute.e:819			start_time = tcb[earliest_task][TASK_MIN_TIME]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32289 = (object)*(((s1_ptr)_2)->base + _earliest_task_65711);
    DeRef(_start_time_65705);
    _2 = (object)SEQ_PTR(_32289);
    _start_time_65705 = (object)*(((s1_ptr)_2)->base + 8);
    Ref(_start_time_65705);
    _32289 = NOVALUE;

    /** execute.e:821			if earliest_task = current_task and*/
    _32291 = (_earliest_task_65711 == _67current_task_64819);
    if (_32291 == 0) {
        goto L7; // [146] 173
    }
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32293 = (object)*(((s1_ptr)_2)->base + _67current_task_64819);
    _2 = (object)SEQ_PTR(_32293);
    _32294 = (object)*(((s1_ptr)_2)->base + 10);
    _32293 = NOVALUE;
    if (IS_ATOM_INT(_32294)) {
        _32295 = (_32294 > 0);
    }
    else {
        _32295 = binary_op(GREATER, _32294, 0);
    }
    _32294 = NOVALUE;
    if (_32295 == 0) {
        DeRef(_32295);
        _32295 = NOVALUE;
        goto L7; // [167] 173
    }
    else {
        if (!IS_ATOM_INT(_32295) && DBL_PTR(_32295)->dbl == 0.0){
            DeRef(_32295);
            _32295 = NOVALUE;
            goto L7; // [167] 173
        }
        DeRef(_32295);
        _32295 = NOVALUE;
    }
    DeRef(_32295);
    _32295 = NOVALUE;
    goto L8; // [170] 231
L7: 

    /** execute.e:825				if tcb[current_task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32296 = (object)*(((s1_ptr)_2)->base + _67current_task_64819);
    _2 = (object)SEQ_PTR(_32296);
    _32297 = (object)*(((s1_ptr)_2)->base + 3);
    _32296 = NOVALUE;
    if (binary_op_a(NOTEQ, _32297, 1)){
        _32297 = NOVALUE;
        goto L9; // [187] 207
    }
    _32297 = NOVALUE;

    /** execute.e:826					tcb[current_task][TASK_RUNS_LEFT] = 0*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64819 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _32299 = NOVALUE;
L9: 

    /** execute.e:828				tcb[earliest_task][TASK_RUNS_LEFT] = tcb[earliest_task][TASK_RUNS_MAX]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_earliest_task_65711 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32303 = (object)*(((s1_ptr)_2)->base + _earliest_task_65711);
    _2 = (object)SEQ_PTR(_32303);
    _32304 = (object)*(((s1_ptr)_2)->base + 11);
    _32303 = NOVALUE;
    Ref(_32304);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32304;
    if( _1 != _32304 ){
        DeRef(_1);
    }
    _32304 = NOVALUE;
    _32301 = NOVALUE;
L8: 
L3: 

    /** execute.e:832		if start_time > now then*/
    if (binary_op_a(LESSEQ, _start_time_65705, _now_65706)){
        goto LA; // [238] 416
    }

    /** execute.e:836			ts_found = FALSE*/
    _ts_found_65708 = _9FALSE_444;

    /** execute.e:837			p = ts_first*/
    _p_65710 = _67ts_first_64849;

    /** execute.e:838			while p != 0 do*/
LB: 
    if (_p_65710 == 0)
    goto LC; // [261] 313

    /** execute.e:839				tp = tcb[p]*/
    DeRef(_tp_65709);
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _tp_65709 = (object)*(((s1_ptr)_2)->base + _p_65710);
    RefDS(_tp_65709);

    /** execute.e:840				if tp[TASK_RUNS_LEFT] > 0 then*/
    _2 = (object)SEQ_PTR(_tp_65709);
    _32308 = (object)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(LESSEQ, _32308, 0)){
        _32308 = NOVALUE;
        goto LD; // [281] 302
    }
    _32308 = NOVALUE;

    /** execute.e:841					  earliest_task = p*/
    _earliest_task_65711 = _p_65710;

    /** execute.e:842					  ts_found = TRUE*/
    _ts_found_65708 = _9TRUE_446;

    /** execute.e:843					  exit*/
    goto LC; // [299] 313
LD: 

    /** execute.e:845				p = tp[TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_tp_65709);
    _p_65710 = (object)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_65710))
    _p_65710 = (object)DBL_PTR(_p_65710)->dbl;

    /** execute.e:846			end while*/
    goto LB; // [310] 261
LC: 

    /** execute.e:848			if not ts_found then*/
    if (_ts_found_65708 != 0)
    goto LE; // [315] 378

    /** execute.e:851				p = ts_first*/
    _p_65710 = _67ts_first_64849;

    /** execute.e:852				while p != 0 do*/
LF: 
    if (_p_65710 == 0)
    goto L10; // [330] 377

    /** execute.e:853					tp = tcb[p]*/
    DeRef(_tp_65709);
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _tp_65709 = (object)*(((s1_ptr)_2)->base + _p_65710);
    RefDS(_tp_65709);

    /** execute.e:854					earliest_task = p*/
    _earliest_task_65711 = _p_65710;

    /** execute.e:855					tcb[p][TASK_RUNS_LEFT] = tp[TASK_RUNS_MAX]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_65710 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_tp_65709);
    _32316 = (object)*(((s1_ptr)_2)->base + 11);
    Ref(_32316);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32316;
    if( _1 != _32316 ){
        DeRef(_1);
    }
    _32316 = NOVALUE;
    _32314 = NOVALUE;

    /** execute.e:856					p = tp[TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_tp_65709);
    _p_65710 = (object)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_65710))
    _p_65710 = (object)DBL_PTR(_p_65710)->dbl;

    /** execute.e:857				end while*/
    goto LF; // [374] 330
L10: 
LE: 

    /** execute.e:860			if earliest_task = 0 then*/
    if (_earliest_task_65711 != 0)
    goto L11; // [380] 389

    /** execute.e:863				abort(0)*/
    UserCleanup(0);
L11: 

    /** execute.e:866			if tcb[earliest_task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32319 = (object)*(((s1_ptr)_2)->base + _earliest_task_65711);
    _2 = (object)SEQ_PTR(_32319);
    _32320 = (object)*(((s1_ptr)_2)->base + 3);
    _32319 = NOVALUE;
    if (binary_op_a(NOTEQ, _32320, 1)){
        _32320 = NOVALUE;
        goto L12; // [401] 415
    }
    _32320 = NOVALUE;

    /** execute.e:868				wait(start_time - now)*/
    if (IS_ATOM_INT(_start_time_65705) && IS_ATOM_INT(_now_65706)) {
        _32322 = _start_time_65705 - _now_65706;
        if ((object)((uintptr_t)_32322 +(uintptr_t) HIGH_BITS) >= 0){
            _32322 = NewDouble((eudouble)_32322);
        }
    }
    else {
        if (IS_ATOM_INT(_start_time_65705)) {
            _32322 = NewDouble((eudouble)_start_time_65705 - DBL_PTR(_now_65706)->dbl);
        }
        else {
            if (IS_ATOM_INT(_now_65706)) {
                _32322 = NewDouble(DBL_PTR(_start_time_65705)->dbl - (eudouble)_now_65706);
            }
            else
            _32322 = NewDouble(DBL_PTR(_start_time_65705)->dbl - DBL_PTR(_now_65706)->dbl);
        }
    }
    _67wait(_32322);
    _32322 = NOVALUE;
L12: 
LA: 

    /** execute.e:873		tcb[earliest_task][TASK_START] = time()*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_earliest_task_65711 + ((s1_ptr)_2)->base);
    DeRef(_32325);
    _32325 = NewDouble(current_time());
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32325;
    if( _1 != _32325 ){
        DeRef(_1);
    }
    _32325 = NOVALUE;
    _32323 = NOVALUE;

    /** execute.e:875		if earliest_task = current_task then*/
    if (_earliest_task_65711 != _67current_task_64819)
    goto L13; // [435] 450

    /** execute.e:876			pc += 1  -- continue with current task*/
    _67pc_64802 = _67pc_64802 + 1;
    goto L14; // [447] 663
L13: 

    /** execute.e:881			tcb[current_task][TASK_CODE] = Code*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64819 + ((s1_ptr)_2)->base);
    RefDS(_12Code_20315);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12Code_20315;
    DeRef(_1);
    _32328 = NOVALUE;

    /** execute.e:882			tcb[current_task][TASK_PC] = pc*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64819 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67pc_64802;
    DeRef(_1);
    _32330 = NOVALUE;

    /** execute.e:883			tcb[current_task][TASK_STACK] = call_stack*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64819 + ((s1_ptr)_2)->base);
    RefDS(_67call_stack_64820);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 16);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67call_stack_64820;
    DeRef(_1);
    _32332 = NOVALUE;

    /** execute.e:886			Code = tcb[earliest_task][TASK_CODE]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32334 = (object)*(((s1_ptr)_2)->base + _earliest_task_65711);
    DeRefDS(_12Code_20315);
    _2 = (object)SEQ_PTR(_32334);
    _12Code_20315 = (object)*(((s1_ptr)_2)->base + 15);
    Ref(_12Code_20315);
    _32334 = NOVALUE;

    /** execute.e:887			pc = tcb[earliest_task][TASK_PC]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32336 = (object)*(((s1_ptr)_2)->base + _earliest_task_65711);
    _2 = (object)SEQ_PTR(_32336);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + 14);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }
    _32336 = NOVALUE;

    /** execute.e:888			call_stack = tcb[earliest_task][TASK_STACK]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32338 = (object)*(((s1_ptr)_2)->base + _earliest_task_65711);
    DeRefDS(_67call_stack_64820);
    _2 = (object)SEQ_PTR(_32338);
    _67call_stack_64820 = (object)*(((s1_ptr)_2)->base + 16);
    Ref(_67call_stack_64820);
    _32338 = NOVALUE;

    /** execute.e:890			current_task = earliest_task*/
    _67current_task_64819 = _earliest_task_65711;

    /** execute.e:892			if tcb[current_task][TASK_PC] = 0 then*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32340 = (object)*(((s1_ptr)_2)->base + _67current_task_64819);
    _2 = (object)SEQ_PTR(_32340);
    _32341 = (object)*(((s1_ptr)_2)->base + 14);
    _32340 = NOVALUE;
    if (binary_op_a(NOTEQ, _32341, 0)){
        _32341 = NOVALUE;
        goto L15; // [562] 639
    }
    _32341 = NOVALUE;

    /** execute.e:895				pc = 1*/
    _67pc_64802 = 1;

    /** execute.e:896				val[t_id] = tcb[current_task][TASK_RID]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32343 = (object)*(((s1_ptr)_2)->base + _67current_task_64819);
    _2 = (object)SEQ_PTR(_32343);
    _32344 = (object)*(((s1_ptr)_2)->base + 1);
    _32343 = NOVALUE;
    Ref(_32344);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_id_64733);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32344;
    if( _1 != _32344 ){
        DeRef(_1);
    }
    _32344 = NOVALUE;

    /** execute.e:897				val[t_arglist] = tcb[current_task][TASK_ARGS]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32345 = (object)*(((s1_ptr)_2)->base + _67current_task_64819);
    _2 = (object)SEQ_PTR(_32345);
    _32346 = (object)*(((s1_ptr)_2)->base + 13);
    _32345 = NOVALUE;
    Ref(_32346);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_64734);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32346;
    if( _1 != _32346 ){
        DeRef(_1);
    }
    _32346 = NOVALUE;

    /** execute.e:898				new_arg_assign()*/
    _32347 = _67new_arg_assign();

    /** execute.e:899				Code = {CALL_PROC, t_id, t_arglist}*/
    _0 = _12Code_20315;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 136;
    ((intptr_t*)_2)[2] = _67t_id_64733;
    ((intptr_t*)_2)[3] = _67t_arglist_64734;
    _12Code_20315 = MAKE_SEQ(_1);
    DeRefDS(_0);
    goto L16; // [636] 662
L15: 

    /** execute.e:902				pc += 1*/
    _67pc_64802 = _67pc_64802 + 1;

    /** execute.e:903				restore_privates(call_stack[$])*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _32350 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _32350 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_64820);
    _32351 = (object)*(((s1_ptr)_2)->base + _32350);
    Ref(_32351);
    _67restore_privates(_32351);
    _32351 = NOVALUE;
L16: 
L14: 

    /** execute.e:906	end procedure*/
    DeRef(_earliest_time_65704);
    DeRef(_start_time_65705);
    DeRef(_now_65706);
    DeRef(_tp_65709);
    DeRef(_32291);
    _32291 = NOVALUE;
    DeRef(_32347);
    _32347 = NOVALUE;
    return;
    ;
}


object _67task_insert(object _first_65814, object _task_65815)
{
    object _32352 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:910		tcb[task][TASK_NEXT] = first*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_65815 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _first_65814;
    DeRef(_1);
    _32352 = NOVALUE;

    /** execute.e:911		return task*/
    return _task_65815;
    ;
}


object _67task_delete(object _first_65820, object _task_65821)
{
    object _p_65822 = NOVALUE;
    object _prev_p_65823 = NOVALUE;
    object _32363 = NOVALUE;
    object _32362 = NOVALUE;
    object _32361 = NOVALUE;
    object _32359 = NOVALUE;
    object _32358 = NOVALUE;
    object _32357 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:918		prev_p = -1*/
    _prev_p_65823 = -1;

    /** execute.e:919		p = first*/
    _p_65822 = _first_65820;

    /** execute.e:920		while p != 0 do*/
L1: 
    if (_p_65822 == 0)
    goto L2; // [20] 110

    /** execute.e:921			if p = task then*/
    if (_p_65822 != _task_65821)
    goto L3; // [26] 86

    /** execute.e:922				if prev_p = -1 then*/
    if (_prev_p_65823 != -1)
    goto L4; // [32] 55

    /** execute.e:924					return tcb[p][TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32357 = (object)*(((s1_ptr)_2)->base + _p_65822);
    _2 = (object)SEQ_PTR(_32357);
    _32358 = (object)*(((s1_ptr)_2)->base + 12);
    _32357 = NOVALUE;
    Ref(_32358);
    return _32358;
    goto L5; // [52] 85
L4: 

    /** execute.e:927					tcb[prev_p][TASK_NEXT] = tcb[p][TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_p_65823 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32361 = (object)*(((s1_ptr)_2)->base + _p_65822);
    _2 = (object)SEQ_PTR(_32361);
    _32362 = (object)*(((s1_ptr)_2)->base + 12);
    _32361 = NOVALUE;
    Ref(_32362);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32362;
    if( _1 != _32362 ){
        DeRef(_1);
    }
    _32362 = NOVALUE;
    _32359 = NOVALUE;

    /** execute.e:928					return first*/
    _32358 = NOVALUE;
    return _first_65820;
L5: 
L3: 

    /** execute.e:931			prev_p = p*/
    _prev_p_65823 = _p_65822;

    /** execute.e:932			p = tcb[p][TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32363 = (object)*(((s1_ptr)_2)->base + _p_65822);
    _2 = (object)SEQ_PTR(_32363);
    _p_65822 = (object)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_65822)){
        _p_65822 = (object)DBL_PTR(_p_65822)->dbl;
    }
    _32363 = NOVALUE;

    /** execute.e:933		end while*/
    goto L1; // [107] 20
L2: 

    /** execute.e:935		return first*/
    _32358 = NOVALUE;
    return _first_65820;
    ;
}


void _67opTASK_YIELD()
{
    object _now_65841 = NOVALUE;
    object _32413 = NOVALUE;
    object _32412 = NOVALUE;
    object _32411 = NOVALUE;
    object _32409 = NOVALUE;
    object _32408 = NOVALUE;
    object _32407 = NOVALUE;
    object _32406 = NOVALUE;
    object _32404 = NOVALUE;
    object _32403 = NOVALUE;
    object _32402 = NOVALUE;
    object _32401 = NOVALUE;
    object _32399 = NOVALUE;
    object _32398 = NOVALUE;
    object _32397 = NOVALUE;
    object _32396 = NOVALUE;
    object _32394 = NOVALUE;
    object _32393 = NOVALUE;
    object _32392 = NOVALUE;
    object _32390 = NOVALUE;
    object _32387 = NOVALUE;
    object _32386 = NOVALUE;
    object _32385 = NOVALUE;
    object _32384 = NOVALUE;
    object _32383 = NOVALUE;
    object _32382 = NOVALUE;
    object _32381 = NOVALUE;
    object _32380 = NOVALUE;
    object _32379 = NOVALUE;
    object _32376 = NOVALUE;
    object _32375 = NOVALUE;
    object _32374 = NOVALUE;
    object _32373 = NOVALUE;
    object _32371 = NOVALUE;
    object _32369 = NOVALUE;
    object _32368 = NOVALUE;
    object _32366 = NOVALUE;
    object _32365 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:943		if tcb[current_task][TASK_STATE] = ST_ACTIVE then*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32365 = (object)*(((s1_ptr)_2)->base + _67current_task_64819);
    _2 = (object)SEQ_PTR(_32365);
    _32366 = (object)*(((s1_ptr)_2)->base + 4);
    _32365 = NOVALUE;
    if (binary_op_a(NOTEQ, _32366, 0)){
        _32366 = NOVALUE;
        goto L1; // [15] 312
    }
    _32366 = NOVALUE;

    /** execute.e:944			if tcb[current_task][TASK_RUNS_LEFT] > 0 then*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32368 = (object)*(((s1_ptr)_2)->base + _67current_task_64819);
    _2 = (object)SEQ_PTR(_32368);
    _32369 = (object)*(((s1_ptr)_2)->base + 10);
    _32368 = NOVALUE;
    if (binary_op_a(LESSEQ, _32369, 0)){
        _32369 = NOVALUE;
        goto L2; // [33] 61
    }
    _32369 = NOVALUE;

    /** execute.e:945				tcb[current_task][TASK_RUNS_LEFT] -= 1*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64819 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _32373 = (object)*(((s1_ptr)_2)->base + 10);
    _32371 = NOVALUE;
    if (IS_ATOM_INT(_32373)) {
        _32374 = _32373 - 1;
        if ((object)((uintptr_t)_32374 +(uintptr_t) HIGH_BITS) >= 0){
            _32374 = NewDouble((eudouble)_32374);
        }
    }
    else {
        _32374 = binary_op(MINUS, _32373, 1);
    }
    _32373 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32374;
    if( _1 != _32374 ){
        DeRef(_1);
    }
    _32374 = NOVALUE;
    _32371 = NOVALUE;
L2: 

    /** execute.e:947			if tcb[current_task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32375 = (object)*(((s1_ptr)_2)->base + _67current_task_64819);
    _2 = (object)SEQ_PTR(_32375);
    _32376 = (object)*(((s1_ptr)_2)->base + 3);
    _32375 = NOVALUE;
    if (binary_op_a(NOTEQ, _32376, 1)){
        _32376 = NOVALUE;
        goto L3; // [75] 311
    }
    _32376 = NOVALUE;

    /** execute.e:948				now = time()*/
    DeRef(_now_65841);
    _now_65841 = NewDouble(current_time());

    /** execute.e:949				if tcb[current_task][TASK_RUNS_MAX] > 1 and*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32379 = (object)*(((s1_ptr)_2)->base + _67current_task_64819);
    _2 = (object)SEQ_PTR(_32379);
    _32380 = (object)*(((s1_ptr)_2)->base + 11);
    _32379 = NOVALUE;
    if (IS_ATOM_INT(_32380)) {
        _32381 = (_32380 > 1);
    }
    else {
        _32381 = binary_op(GREATER, _32380, 1);
    }
    _32380 = NOVALUE;
    if (IS_ATOM_INT(_32381)) {
        if (_32381 == 0) {
            goto L4; // [101] 247
        }
    }
    else {
        if (DBL_PTR(_32381)->dbl == 0.0) {
            goto L4; // [101] 247
        }
    }
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32383 = (object)*(((s1_ptr)_2)->base + _67current_task_64819);
    _2 = (object)SEQ_PTR(_32383);
    _32384 = (object)*(((s1_ptr)_2)->base + 5);
    _32383 = NOVALUE;
    _32385 = binary_op(EQUALS, _32384, _now_65841);
    _32384 = NOVALUE;
    if (_32385 == 0) {
        DeRef(_32385);
        _32385 = NOVALUE;
        goto L4; // [122] 247
    }
    else {
        if (!IS_ATOM_INT(_32385) && DBL_PTR(_32385)->dbl == 0.0){
            DeRef(_32385);
            _32385 = NOVALUE;
            goto L4; // [122] 247
        }
        DeRef(_32385);
        _32385 = NOVALUE;
    }
    DeRef(_32385);
    _32385 = NOVALUE;

    /** execute.e:952					if tcb[current_task][TASK_RUNS_LEFT] = 0 then*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32386 = (object)*(((s1_ptr)_2)->base + _67current_task_64819);
    _2 = (object)SEQ_PTR(_32386);
    _32387 = (object)*(((s1_ptr)_2)->base + 10);
    _32386 = NOVALUE;
    if (binary_op_a(NOTEQ, _32387, 0)){
        _32387 = NOVALUE;
        goto L5; // [139] 310
    }
    _32387 = NOVALUE;

    /** execute.e:954						now += clock_period*/
    _0 = _now_65841;
    if (IS_ATOM_INT(_now_65841)) {
        _now_65841 = NewDouble((eudouble)_now_65841 + DBL_PTR(_67clock_period_64822)->dbl);
    }
    else {
        _now_65841 = NewDouble(DBL_PTR(_now_65841)->dbl + DBL_PTR(_67clock_period_64822)->dbl);
    }
    DeRef(_0);

    /** execute.e:955						tcb[current_task][TASK_RUNS_LEFT] = tcb[current_task][TASK_RUNS_MAX]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64819 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32392 = (object)*(((s1_ptr)_2)->base + _67current_task_64819);
    _2 = (object)SEQ_PTR(_32392);
    _32393 = (object)*(((s1_ptr)_2)->base + 11);
    _32392 = NOVALUE;
    Ref(_32393);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32393;
    if( _1 != _32393 ){
        DeRef(_1);
    }
    _32393 = NOVALUE;
    _32390 = NOVALUE;

    /** execute.e:956						tcb[current_task][TASK_MIN_TIME] = now +*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64819 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32396 = (object)*(((s1_ptr)_2)->base + _67current_task_64819);
    _2 = (object)SEQ_PTR(_32396);
    _32397 = (object)*(((s1_ptr)_2)->base + 6);
    _32396 = NOVALUE;
    _32398 = binary_op(PLUS, _now_65841, _32397);
    _32397 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32398;
    if( _1 != _32398 ){
        DeRef(_1);
    }
    _32398 = NOVALUE;
    _32394 = NOVALUE;

    /** execute.e:958						tcb[current_task][TASK_MAX_TIME] = now +*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64819 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32401 = (object)*(((s1_ptr)_2)->base + _67current_task_64819);
    _2 = (object)SEQ_PTR(_32401);
    _32402 = (object)*(((s1_ptr)_2)->base + 7);
    _32401 = NOVALUE;
    _32403 = binary_op(PLUS, _now_65841, _32402);
    _32402 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32403;
    if( _1 != _32403 ){
        DeRef(_1);
    }
    _32403 = NOVALUE;
    _32399 = NOVALUE;
    goto L5; // [240] 310
    goto L5; // [244] 310
L4: 

    /** execute.e:965					tcb[current_task][TASK_MIN_TIME] = now +*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64819 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32406 = (object)*(((s1_ptr)_2)->base + _67current_task_64819);
    _2 = (object)SEQ_PTR(_32406);
    _32407 = (object)*(((s1_ptr)_2)->base + 6);
    _32406 = NOVALUE;
    if (IS_ATOM_INT(_now_65841) && IS_ATOM_INT(_32407)) {
        _32408 = _now_65841 + _32407;
        if ((object)((uintptr_t)_32408 + (uintptr_t)HIGH_BITS) >= 0){
            _32408 = NewDouble((eudouble)_32408);
        }
    }
    else {
        _32408 = binary_op(PLUS, _now_65841, _32407);
    }
    _32407 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32408;
    if( _1 != _32408 ){
        DeRef(_1);
    }
    _32408 = NOVALUE;
    _32404 = NOVALUE;

    /** execute.e:967					tcb[current_task][TASK_MAX_TIME] = now +*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64819 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32411 = (object)*(((s1_ptr)_2)->base + _67current_task_64819);
    _2 = (object)SEQ_PTR(_32411);
    _32412 = (object)*(((s1_ptr)_2)->base + 7);
    _32411 = NOVALUE;
    if (IS_ATOM_INT(_now_65841) && IS_ATOM_INT(_32412)) {
        _32413 = _now_65841 + _32412;
        if ((object)((uintptr_t)_32413 + (uintptr_t)HIGH_BITS) >= 0){
            _32413 = NewDouble((eudouble)_32413);
        }
    }
    else {
        _32413 = binary_op(PLUS, _now_65841, _32412);
    }
    _32412 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32413;
    if( _1 != _32413 ){
        DeRef(_1);
    }
    _32413 = NOVALUE;
    _32409 = NOVALUE;
L5: 
L3: 
L1: 

    /** execute.e:972		scheduler()*/
    _67scheduler();

    /** execute.e:973	end procedure*/
    DeRef(_now_65841);
    DeRef(_32381);
    _32381 = NOVALUE;
    return;
    ;
}


void _67kill_task(object _task_65900)
{
    object _32419 = NOVALUE;
    object _32415 = NOVALUE;
    object _32414 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:977		if tcb[task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32414 = (object)*(((s1_ptr)_2)->base + _task_65900);
    _2 = (object)SEQ_PTR(_32414);
    _32415 = (object)*(((s1_ptr)_2)->base + 3);
    _32414 = NOVALUE;
    if (binary_op_a(NOTEQ, _32415, 1)){
        _32415 = NOVALUE;
        goto L1; // [15] 33
    }
    _32415 = NOVALUE;

    /** execute.e:978			rt_first = task_delete(rt_first, task)*/
    _0 = _67task_delete(_67rt_first_64848, _task_65900);
    _67rt_first_64848 = _0;
    if (!IS_ATOM_INT(_67rt_first_64848)) {
        _1 = (object)(DBL_PTR(_67rt_first_64848)->dbl);
        DeRefDS(_67rt_first_64848);
        _67rt_first_64848 = _1;
    }
    goto L2; // [30] 45
L1: 

    /** execute.e:980			ts_first = task_delete(ts_first, task)*/
    _0 = _67task_delete(_67ts_first_64849, _task_65900);
    _67ts_first_64849 = _0;
    if (!IS_ATOM_INT(_67ts_first_64849)) {
        _1 = (object)(DBL_PTR(_67ts_first_64849)->dbl);
        DeRefDS(_67ts_first_64849);
        _67ts_first_64849 = _1;
    }
L2: 

    /** execute.e:982		tcb[task][TASK_STATE] = ST_DEAD*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_65900 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _32419 = NOVALUE;

    /** execute.e:984	end procedure*/
    return;
    ;
}


object _67which_task(object _tid_65912)
{
    object _32423 = NOVALUE;
    object _32422 = NOVALUE;
    object _32421 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:989		for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_64845)){
            _32421 = SEQ_PTR(_67tcb_64845)->length;
    }
    else {
        _32421 = 1;
    }
    {
        object _i_65914;
        _i_65914 = 1;
L1: 
        if (_i_65914 > _32421){
            goto L2; // [8] 45
        }

        /** execute.e:990			if tcb[i][TASK_TID] = tid then*/
        _2 = (object)SEQ_PTR(_67tcb_64845);
        _32422 = (object)*(((s1_ptr)_2)->base + _i_65914);
        _2 = (object)SEQ_PTR(_32422);
        _32423 = (object)*(((s1_ptr)_2)->base + 2);
        _32422 = NOVALUE;
        if (binary_op_a(NOTEQ, _32423, _tid_65912)){
            _32423 = NOVALUE;
            goto L3; // [27] 38
        }
        _32423 = NOVALUE;

        /** execute.e:991				return i*/
        DeRef(_tid_65912);
        return _i_65914;
L3: 

        /** execute.e:993		end for*/
        _i_65914 = _i_65914 + 1;
        goto L1; // [40] 15
L2: 
        ;
    }

    /** execute.e:994		RTFatal("invalid task id")*/
    RefDS(_32425);
    _67RTFatal(_32425);
    ;
}


void _67opTASK_STATUS()
{
    object _r_65923 = NOVALUE;
    object _tid_65924 = NOVALUE;
    object _32439 = NOVALUE;
    object _32438 = NOVALUE;
    object _32436 = NOVALUE;
    object _32435 = NOVALUE;
    object _32433 = NOVALUE;
    object _32432 = NOVALUE;
    object _32431 = NOVALUE;
    object _32428 = NOVALUE;
    object _32426 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1003		a = Code[pc+1]*/
    _32426 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _32426);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1004		target = Code[pc+2]*/
    _32428 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _32428);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:1005		tid = val[a]*/
    DeRef(_tid_65924);
    _2 = (object)SEQ_PTR(_67val_64812);
    _tid_65924 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    Ref(_tid_65924);

    /** execute.e:1006		r = -1*/
    _r_65923 = -1;

    /** execute.e:1007		for t = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_64845)){
            _32431 = SEQ_PTR(_67tcb_64845)->length;
    }
    else {
        _32431 = 1;
    }
    {
        object _t_65933;
        _t_65933 = 1;
L1: 
        if (_t_65933 > _32431){
            goto L2; // [55] 137
        }

        /** execute.e:1008			if tcb[t][TASK_TID] = tid then*/
        _2 = (object)SEQ_PTR(_67tcb_64845);
        _32432 = (object)*(((s1_ptr)_2)->base + _t_65933);
        _2 = (object)SEQ_PTR(_32432);
        _32433 = (object)*(((s1_ptr)_2)->base + 2);
        _32432 = NOVALUE;
        if (binary_op_a(NOTEQ, _32433, _tid_65924)){
            _32433 = NOVALUE;
            goto L3; // [74] 130
        }
        _32433 = NOVALUE;

        /** execute.e:1009				if tcb[t][TASK_STATE] = ST_ACTIVE then*/
        _2 = (object)SEQ_PTR(_67tcb_64845);
        _32435 = (object)*(((s1_ptr)_2)->base + _t_65933);
        _2 = (object)SEQ_PTR(_32435);
        _32436 = (object)*(((s1_ptr)_2)->base + 4);
        _32435 = NOVALUE;
        if (binary_op_a(NOTEQ, _32436, 0)){
            _32436 = NOVALUE;
            goto L4; // [90] 102
        }
        _32436 = NOVALUE;

        /** execute.e:1010					r = 1*/
        _r_65923 = 1;
        goto L2; // [99] 137
L4: 

        /** execute.e:1011				elsif tcb[t][TASK_STATE] = ST_SUSPENDED then*/
        _2 = (object)SEQ_PTR(_67tcb_64845);
        _32438 = (object)*(((s1_ptr)_2)->base + _t_65933);
        _2 = (object)SEQ_PTR(_32438);
        _32439 = (object)*(((s1_ptr)_2)->base + 4);
        _32438 = NOVALUE;
        if (binary_op_a(NOTEQ, _32439, 1)){
            _32439 = NOVALUE;
            goto L2; // [114] 137
        }
        _32439 = NOVALUE;

        /** execute.e:1012					r = 0*/
        _r_65923 = 0;

        /** execute.e:1014				exit*/
        goto L2; // [127] 137
L3: 

        /** execute.e:1016		end for*/
        _t_65933 = _t_65933 + 1;
        goto L1; // [132] 62
L2: 
        ;
    }

    /** execute.e:1017		val[target] = r*/
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_65923;
    DeRef(_1);

    /** execute.e:1018		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:1019	end procedure*/
    DeRef(_tid_65924);
    DeRef(_32426);
    _32426 = NOVALUE;
    DeRef(_32428);
    _32428 = NOVALUE;
    return;
    ;
}


void _67opTASK_LIST()
{
    object _list_65950 = NOVALUE;
    object _32449 = NOVALUE;
    object _32448 = NOVALUE;
    object _32446 = NOVALUE;
    object _32445 = NOVALUE;
    object _32444 = NOVALUE;
    object _32442 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1025		target = Code[pc+1]*/
    _32442 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _32442);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:1026		list = {}*/
    RefDS(_22015);
    DeRef(_list_65950);
    _list_65950 = _22015;

    /** execute.e:1027		for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_64845)){
            _32444 = SEQ_PTR(_67tcb_64845)->length;
    }
    else {
        _32444 = 1;
    }
    {
        object _i_65955;
        _i_65955 = 1;
L1: 
        if (_i_65955 > _32444){
            goto L2; // [31] 78
        }

        /** execute.e:1028			if tcb[i][TASK_STATE] != ST_DEAD then*/
        _2 = (object)SEQ_PTR(_67tcb_64845);
        _32445 = (object)*(((s1_ptr)_2)->base + _i_65955);
        _2 = (object)SEQ_PTR(_32445);
        _32446 = (object)*(((s1_ptr)_2)->base + 4);
        _32445 = NOVALUE;
        if (binary_op_a(EQUALS, _32446, 2)){
            _32446 = NOVALUE;
            goto L3; // [50] 71
        }
        _32446 = NOVALUE;

        /** execute.e:1029				list = append(list, tcb[i][TASK_TID])*/
        _2 = (object)SEQ_PTR(_67tcb_64845);
        _32448 = (object)*(((s1_ptr)_2)->base + _i_65955);
        _2 = (object)SEQ_PTR(_32448);
        _32449 = (object)*(((s1_ptr)_2)->base + 2);
        _32448 = NOVALUE;
        Ref(_32449);
        Append(&_list_65950, _list_65950, _32449);
        _32449 = NOVALUE;
L3: 

        /** execute.e:1031		end for*/
        _i_65955 = _i_65955 + 1;
        goto L1; // [73] 38
L2: 
        ;
    }

    /** execute.e:1032		val[target] = list*/
    RefDS(_list_65950);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _list_65950;
    DeRef(_1);

    /** execute.e:1033		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:1034	end procedure*/
    DeRefDS(_list_65950);
    DeRef(_32442);
    _32442 = NOVALUE;
    return;
    ;
}


void _67opTASK_SELF()
{
    object _32455 = NOVALUE;
    object _32454 = NOVALUE;
    object _32452 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1038		target = Code[pc+1]*/
    _32452 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _32452);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:1039		val[target] = tcb[current_task][TASK_TID]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32454 = (object)*(((s1_ptr)_2)->base + _67current_task_64819);
    _2 = (object)SEQ_PTR(_32454);
    _32455 = (object)*(((s1_ptr)_2)->base + 2);
    _32454 = NOVALUE;
    Ref(_32455);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32455;
    if( _1 != _32455 ){
        DeRef(_1);
    }
    _32455 = NOVALUE;

    /** execute.e:1040		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:1041	end procedure*/
    _32452 = NOVALUE;
    return;
    ;
}


void _67opTASK_CLOCK_STOP()
{
    object _0, _1, _2;
    

    /** execute.e:1048		if not clock_stopped then*/
    if (_67clock_stopped_65700 != 0)
    goto L1; // [5] 20

    /** execute.e:1049			save_clock = time()*/
    DeRef(_67save_clock_65973);
    _67save_clock_65973 = NewDouble(current_time());

    /** execute.e:1050			clock_stopped = TRUE*/
    _67clock_stopped_65700 = _9TRUE_446;
L1: 

    /** execute.e:1052		pc += 1*/
    _67pc_64802 = _67pc_64802 + 1;

    /** execute.e:1053	end procedure*/
    return;
    ;
}


void _67opTASK_CLOCK_START()
{
    object _shift_65983 = NOVALUE;
    object _32474 = NOVALUE;
    object _32473 = NOVALUE;
    object _32471 = NOVALUE;
    object _32470 = NOVALUE;
    object _32469 = NOVALUE;
    object _32467 = NOVALUE;
    object _32466 = NOVALUE;
    object _32464 = NOVALUE;
    object _32463 = NOVALUE;
    object _32462 = NOVALUE;
    object _32461 = NOVALUE;
    object _32460 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1059		if clock_stopped then*/
    if (_67clock_stopped_65700 == 0)
    {
        goto L1; // [5] 114
    }
    else{
    }

    /** execute.e:1060			if save_clock >= 0 and save_clock < time() then*/
    if (IS_ATOM_INT(_67save_clock_65973)) {
        _32460 = (_67save_clock_65973 >= 0);
    }
    else {
        _32460 = (DBL_PTR(_67save_clock_65973)->dbl >= (eudouble)0);
    }
    if (_32460 == 0) {
        goto L2; // [16] 106
    }
    _32462 = NewDouble(current_time());
    if (IS_ATOM_INT(_67save_clock_65973)) {
        _32463 = ((eudouble)_67save_clock_65973 < DBL_PTR(_32462)->dbl);
    }
    else {
        _32463 = (DBL_PTR(_67save_clock_65973)->dbl < DBL_PTR(_32462)->dbl);
    }
    DeRefDS(_32462);
    _32462 = NOVALUE;
    if (_32463 == 0)
    {
        DeRef(_32463);
        _32463 = NOVALUE;
        goto L2; // [29] 106
    }
    else{
        DeRef(_32463);
        _32463 = NOVALUE;
    }

    /** execute.e:1061				shift = time() - save_clock*/
    DeRef(_32464);
    _32464 = NewDouble(current_time());
    DeRef(_shift_65983);
    if (IS_ATOM_INT(_67save_clock_65973)) {
        _shift_65983 = NewDouble(DBL_PTR(_32464)->dbl - (eudouble)_67save_clock_65973);
    }
    else
    _shift_65983 = NewDouble(DBL_PTR(_32464)->dbl - DBL_PTR(_67save_clock_65973)->dbl);
    DeRefDS(_32464);
    _32464 = NOVALUE;

    /** execute.e:1062				for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_64845)){
            _32466 = SEQ_PTR(_67tcb_64845)->length;
    }
    else {
        _32466 = 1;
    }
    {
        object _i_65993;
        _i_65993 = 1;
L3: 
        if (_i_65993 > _32466){
            goto L4; // [49] 105
        }

        /** execute.e:1063					tcb[i][TASK_MIN_TIME] += shift*/
        _2 = (object)SEQ_PTR(_67tcb_64845);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67tcb_64845 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_65993 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _32469 = (object)*(((s1_ptr)_2)->base + 8);
        _32467 = NOVALUE;
        if (IS_ATOM_INT(_32469) && IS_ATOM_INT(_shift_65983)) {
            _32470 = _32469 + _shift_65983;
            if ((object)((uintptr_t)_32470 + (uintptr_t)HIGH_BITS) >= 0){
                _32470 = NewDouble((eudouble)_32470);
            }
        }
        else {
            _32470 = binary_op(PLUS, _32469, _shift_65983);
        }
        _32469 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 8);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32470;
        if( _1 != _32470 ){
            DeRef(_1);
        }
        _32470 = NOVALUE;
        _32467 = NOVALUE;

        /** execute.e:1064					tcb[i][TASK_MAX_TIME] += shift*/
        _2 = (object)SEQ_PTR(_67tcb_64845);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67tcb_64845 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_65993 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _32473 = (object)*(((s1_ptr)_2)->base + 9);
        _32471 = NOVALUE;
        if (IS_ATOM_INT(_32473) && IS_ATOM_INT(_shift_65983)) {
            _32474 = _32473 + _shift_65983;
            if ((object)((uintptr_t)_32474 + (uintptr_t)HIGH_BITS) >= 0){
                _32474 = NewDouble((eudouble)_32474);
            }
        }
        else {
            _32474 = binary_op(PLUS, _32473, _shift_65983);
        }
        _32473 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 9);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32474;
        if( _1 != _32474 ){
            DeRef(_1);
        }
        _32474 = NOVALUE;
        _32471 = NOVALUE;

        /** execute.e:1065				end for*/
        _i_65993 = _i_65993 + 1;
        goto L3; // [100] 56
L4: 
        ;
    }
L2: 

    /** execute.e:1067			clock_stopped = FALSE*/
    _67clock_stopped_65700 = _9FALSE_444;
L1: 

    /** execute.e:1069		pc += 1*/
    _67pc_64802 = _67pc_64802 + 1;

    /** execute.e:1070	end procedure*/
    DeRef(_shift_65983);
    DeRef(_32460);
    _32460 = NOVALUE;
    return;
    ;
}


void _67opTASK_SUSPEND()
{
    object _task_66007 = NOVALUE;
    object _32485 = NOVALUE;
    object _32484 = NOVALUE;
    object _32482 = NOVALUE;
    object _32480 = NOVALUE;
    object _32478 = NOVALUE;
    object _32476 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1076		a = Code[pc+1]*/
    _32476 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _32476);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1077		task = which_task(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _32478 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    Ref(_32478);
    _task_66007 = _67which_task(_32478);
    _32478 = NOVALUE;
    if (!IS_ATOM_INT(_task_66007)) {
        _1 = (object)(DBL_PTR(_task_66007)->dbl);
        DeRefDS(_task_66007);
        _task_66007 = _1;
    }

    /** execute.e:1078		tcb[task][TASK_STATE] = ST_SUSPENDED*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66007 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _32480 = NOVALUE;

    /** execute.e:1079		tcb[task][TASK_MAX_TIME] = TASK_NEVER*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66007 + ((s1_ptr)_2)->base);
    RefDS(_67TASK_NEVER_64813);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67TASK_NEVER_64813;
    DeRef(_1);
    _32482 = NOVALUE;

    /** execute.e:1080		if tcb[task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32484 = (object)*(((s1_ptr)_2)->base + _task_66007);
    _2 = (object)SEQ_PTR(_32484);
    _32485 = (object)*(((s1_ptr)_2)->base + 3);
    _32484 = NOVALUE;
    if (binary_op_a(NOTEQ, _32485, 1)){
        _32485 = NOVALUE;
        goto L1; // [71] 89
    }
    _32485 = NOVALUE;

    /** execute.e:1081			rt_first = task_delete(rt_first, task)*/
    _0 = _67task_delete(_67rt_first_64848, _task_66007);
    _67rt_first_64848 = _0;
    if (!IS_ATOM_INT(_67rt_first_64848)) {
        _1 = (object)(DBL_PTR(_67rt_first_64848)->dbl);
        DeRefDS(_67rt_first_64848);
        _67rt_first_64848 = _1;
    }
    goto L2; // [86] 101
L1: 

    /** execute.e:1083			ts_first = task_delete(ts_first, task)*/
    _0 = _67task_delete(_67ts_first_64849, _task_66007);
    _67ts_first_64849 = _0;
    if (!IS_ATOM_INT(_67ts_first_64849)) {
        _1 = (object)(DBL_PTR(_67ts_first_64849)->dbl);
        DeRefDS(_67ts_first_64849);
        _67ts_first_64849 = _1;
    }
L2: 

    /** execute.e:1085		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:1086	end procedure*/
    DeRef(_32476);
    _32476 = NOVALUE;
    return;
    ;
}


void _67opTASK_CREATE()
{
    object _sub_66028 = NOVALUE;
    object _new_entry_66029 = NOVALUE;
    object _recycle_66031 = NOVALUE;
    object _32525 = NOVALUE;
    object _32524 = NOVALUE;
    object _32523 = NOVALUE;
    object _32521 = NOVALUE;
    object _32520 = NOVALUE;
    object _32519 = NOVALUE;
    object _32517 = NOVALUE;
    object _32513 = NOVALUE;
    object _32512 = NOVALUE;
    object _32511 = NOVALUE;
    object _32509 = NOVALUE;
    object _32508 = NOVALUE;
    object _32506 = NOVALUE;
    object _32503 = NOVALUE;
    object _32502 = NOVALUE;
    object _32500 = NOVALUE;
    object _32499 = NOVALUE;
    object _32497 = NOVALUE;
    object _32496 = NOVALUE;
    object _32495 = NOVALUE;
    object _32493 = NOVALUE;
    object _32492 = NOVALUE;
    object _32490 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1091		sequence new_entry*/

    /** execute.e:1094		a = Code[pc+1] -- routine id*/
    _32490 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _32490);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1095		if val[a] < 0 or val[a] >= length(e_routine) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _32492 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_32492)) {
        _32493 = (_32492 < 0);
    }
    else {
        _32493 = binary_op(LESS, _32492, 0);
    }
    _32492 = NOVALUE;
    if (IS_ATOM_INT(_32493)) {
        if (_32493 != 0) {
            goto L1; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_32493)->dbl != 0.0) {
            goto L1; // [33] 59
        }
    }
    _2 = (object)SEQ_PTR(_67val_64812);
    _32495 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_SEQUENCE(_67e_routine_64850)){
            _32496 = SEQ_PTR(_67e_routine_64850)->length;
    }
    else {
        _32496 = 1;
    }
    if (IS_ATOM_INT(_32495)) {
        _32497 = (_32495 >= _32496);
    }
    else {
        _32497 = binary_op(GREATEREQ, _32495, _32496);
    }
    _32495 = NOVALUE;
    _32496 = NOVALUE;
    if (_32497 == 0) {
        DeRef(_32497);
        _32497 = NOVALUE;
        goto L2; // [55] 65
    }
    else {
        if (!IS_ATOM_INT(_32497) && DBL_PTR(_32497)->dbl == 0.0){
            DeRef(_32497);
            _32497 = NOVALUE;
            goto L2; // [55] 65
        }
        DeRef(_32497);
        _32497 = NOVALUE;
    }
    DeRef(_32497);
    _32497 = NOVALUE;
L1: 

    /** execute.e:1096			RTFatal("invalid routine id")*/
    RefDS(_32498);
    _67RTFatal(_32498);
L2: 

    /** execute.e:1098		sub = e_routine[val[a]+1]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _32499 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_32499)) {
        _32500 = _32499 + 1;
    }
    else
    _32500 = binary_op(PLUS, 1, _32499);
    _32499 = NOVALUE;
    _2 = (object)SEQ_PTR(_67e_routine_64850);
    if (!IS_ATOM_INT(_32500)){
        _sub_66028 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32500)->dbl));
    }
    else{
        _sub_66028 = (object)*(((s1_ptr)_2)->base + _32500);
    }

    /** execute.e:1099		if SymTab[sub][S_TOKEN] != PROC then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32502 = (object)*(((s1_ptr)_2)->base + _sub_66028);
    _2 = (object)SEQ_PTR(_32502);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _32503 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _32503 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _32502 = NOVALUE;
    if (binary_op_a(EQUALS, _32503, 27)){
        _32503 = NOVALUE;
        goto L3; // [103] 113
    }
    _32503 = NOVALUE;

    /** execute.e:1100			RTFatal("specify the routine id of a procedure, not a function or type")*/
    RefDS(_32505);
    _67RTFatal(_32505);
L3: 

    /** execute.e:1102		b = Code[pc+2] -- args*/
    _32506 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _32506);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:1105		new_entry = {val[a], next_task_id, T_REAL_TIME, ST_SUSPENDED, 0,*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _32508 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _32509 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _0 = _new_entry_66029;
    _1 = NewS1(16);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_32508);
    ((intptr_t*)_2)[1] = _32508;
    Ref(_67next_task_id_64821);
    ((intptr_t*)_2)[2] = _67next_task_id_64821;
    ((intptr_t*)_2)[3] = 1;
    ((intptr_t*)_2)[4] = 1;
    ((intptr_t*)_2)[5] = 0;
    ((intptr_t*)_2)[6] = 0;
    ((intptr_t*)_2)[7] = 0;
    ((intptr_t*)_2)[8] = 0;
    RefDS(_67TASK_NEVER_64813);
    ((intptr_t*)_2)[9] = _67TASK_NEVER_64813;
    ((intptr_t*)_2)[10] = 1;
    ((intptr_t*)_2)[11] = 1;
    ((intptr_t*)_2)[12] = 0;
    Ref(_32509);
    ((intptr_t*)_2)[13] = _32509;
    ((intptr_t*)_2)[14] = 0;
    RefDSn(_22015, 2);
    ((intptr_t*)_2)[15] = _22015;
    ((intptr_t*)_2)[16] = _22015;
    _new_entry_66029 = MAKE_SEQ(_1);
    DeRef(_0);
    _32509 = NOVALUE;
    _32508 = NOVALUE;

    /** execute.e:1108		recycle = FALSE*/
    _recycle_66031 = _9FALSE_444;

    /** execute.e:1109		for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_64845)){
            _32511 = SEQ_PTR(_67tcb_64845)->length;
    }
    else {
        _32511 = 1;
    }
    {
        object _i_66062;
        _i_66062 = 1;
L4: 
        if (_i_66062 > _32511){
            goto L5; // [182] 232
        }

        /** execute.e:1110			if tcb[i][TASK_STATE] = ST_DEAD then*/
        _2 = (object)SEQ_PTR(_67tcb_64845);
        _32512 = (object)*(((s1_ptr)_2)->base + _i_66062);
        _2 = (object)SEQ_PTR(_32512);
        _32513 = (object)*(((s1_ptr)_2)->base + 4);
        _32512 = NOVALUE;
        if (binary_op_a(NOTEQ, _32513, 2)){
            _32513 = NOVALUE;
            goto L6; // [201] 225
        }
        _32513 = NOVALUE;

        /** execute.e:1113				tcb[i] = new_entry*/
        RefDS(_new_entry_66029);
        _2 = (object)SEQ_PTR(_67tcb_64845);
        _2 = (object)(((s1_ptr)_2)->base + _i_66062);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _new_entry_66029;
        DeRefDS(_1);

        /** execute.e:1114				recycle = TRUE*/
        _recycle_66031 = _9TRUE_446;

        /** execute.e:1115				exit*/
        goto L5; // [222] 232
L6: 

        /** execute.e:1117		end for*/
        _i_66062 = _i_66062 + 1;
        goto L4; // [227] 189
L5: 
        ;
    }

    /** execute.e:1119		if not recycle then*/
    if (_recycle_66031 != 0)
    goto L7; // [234] 246

    /** execute.e:1121			tcb = append(tcb, new_entry)*/
    RefDS(_new_entry_66029);
    Append(&_67tcb_64845, _67tcb_64845, _new_entry_66029);
L7: 

    /** execute.e:1124		target = Code[pc+3]*/
    _32517 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _32517);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:1125		val[target] = next_task_id*/
    Ref(_67next_task_id_64821);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67next_task_id_64821;
    DeRef(_1);

    /** execute.e:1126		if not id_wrap and next_task_id < TASK_ID_MAX then*/
    _32519 = (_67id_wrap_64817 == 0);
    if (_32519 == 0) {
        goto L8; // [281] 306
    }
    if (IS_ATOM_INT(_67next_task_id_64821)) {
        _32521 = ((eudouble)_67next_task_id_64821 < DBL_PTR(_67TASK_ID_MAX_64814)->dbl);
    }
    else {
        _32521 = (DBL_PTR(_67next_task_id_64821)->dbl < DBL_PTR(_67TASK_ID_MAX_64814)->dbl);
    }
    if (_32521 == 0)
    {
        DeRef(_32521);
        _32521 = NOVALUE;
        goto L8; // [292] 306
    }
    else{
        DeRef(_32521);
        _32521 = NOVALUE;
    }

    /** execute.e:1127			next_task_id += 1*/
    _0 = _67next_task_id_64821;
    if (IS_ATOM_INT(_67next_task_id_64821)) {
        _67next_task_id_64821 = _67next_task_id_64821 + 1;
        if (_67next_task_id_64821 > MAXINT){
            _67next_task_id_64821 = NewDouble((eudouble)_67next_task_id_64821);
        }
    }
    else
    _67next_task_id_64821 = binary_op(PLUS, 1, _67next_task_id_64821);
    DeRef(_0);
    goto L9; // [303] 396
L8: 

    /** execute.e:1130			id_wrap = TRUE -- id's have wrapped*/
    _67id_wrap_64817 = _9TRUE_446;

    /** execute.e:1131			for i = 1 to TASK_ID_MAX do*/
    {
        object _i_66083;
        _i_66083 = 1;
LA: 
        if (binary_op_a(GREATER, _i_66083, _67TASK_ID_MAX_64814)){
            goto LB; // [315] 395
        }

        /** execute.e:1132				next_task_id = i*/
        Ref(_i_66083);
        DeRef(_67next_task_id_64821);
        _67next_task_id_64821 = _i_66083;

        /** execute.e:1133				for j = 1 to length(tcb) do*/
        if (IS_SEQUENCE(_67tcb_64845)){
                _32523 = SEQ_PTR(_67tcb_64845)->length;
        }
        else {
            _32523 = 1;
        }
        {
            object _j_66085;
            _j_66085 = 1;
LC: 
            if (_j_66085 > _32523){
                goto LD; // [334] 376
            }

            /** execute.e:1134					if next_task_id = tcb[j][TASK_TID] then*/
            _2 = (object)SEQ_PTR(_67tcb_64845);
            _32524 = (object)*(((s1_ptr)_2)->base + _j_66085);
            _2 = (object)SEQ_PTR(_32524);
            _32525 = (object)*(((s1_ptr)_2)->base + 2);
            _32524 = NOVALUE;
            if (binary_op_a(NOTEQ, _67next_task_id_64821, _32525)){
                _32525 = NOVALUE;
                goto LE; // [355] 369
            }
            _32525 = NOVALUE;

            /** execute.e:1135						next_task_id = 0*/
            DeRef(_67next_task_id_64821);
            _67next_task_id_64821 = 0;

            /** execute.e:1136						exit -- this id is still in use*/
            goto LD; // [366] 376
LE: 

            /** execute.e:1138				end for*/
            _j_66085 = _j_66085 + 1;
            goto LC; // [371] 341
LD: 
            ;
        }

        /** execute.e:1139				if next_task_id then*/
        if (_67next_task_id_64821 == 0) {
            goto LF; // [380] 388
        }
        else {
            if (!IS_ATOM_INT(_67next_task_id_64821) && DBL_PTR(_67next_task_id_64821)->dbl == 0.0){
                goto LF; // [380] 388
            }
        }

        /** execute.e:1140					exit -- found unused id for next time*/
        goto LB; // [385] 395
LF: 

        /** execute.e:1142			end for*/
        _0 = _i_66083;
        if (IS_ATOM_INT(_i_66083)) {
            _i_66083 = _i_66083 + 1;
            if ((object)((uintptr_t)_i_66083 +(uintptr_t) HIGH_BITS) >= 0){
                _i_66083 = NewDouble((eudouble)_i_66083);
            }
        }
        else {
            _i_66083 = binary_op_a(PLUS, _i_66083, 1);
        }
        DeRef(_0);
        goto LA; // [390] 322
LB: 
        ;
        DeRef(_i_66083);
    }
L9: 

    /** execute.e:1145		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:1146	end procedure*/
    DeRef(_new_entry_66029);
    DeRef(_32500);
    _32500 = NOVALUE;
    DeRef(_32490);
    _32490 = NOVALUE;
    DeRef(_32493);
    _32493 = NOVALUE;
    DeRef(_32519);
    _32519 = NOVALUE;
    DeRef(_32506);
    _32506 = NOVALUE;
    DeRef(_32517);
    _32517 = NOVALUE;
    return;
    ;
}


void _67opTASK_SCHEDULE()
{
    object _task_66095 = NOVALUE;
    object _now_66096 = NOVALUE;
    object _s_66097 = NOVALUE;
    object _32617 = NOVALUE;
    object _32615 = NOVALUE;
    object _32613 = NOVALUE;
    object _32612 = NOVALUE;
    object _32611 = NOVALUE;
    object _32609 = NOVALUE;
    object _32608 = NOVALUE;
    object _32607 = NOVALUE;
    object _32604 = NOVALUE;
    object _32603 = NOVALUE;
    object _32602 = NOVALUE;
    object _32601 = NOVALUE;
    object _32599 = NOVALUE;
    object _32598 = NOVALUE;
    object _32597 = NOVALUE;
    object _32595 = NOVALUE;
    object _32593 = NOVALUE;
    object _32591 = NOVALUE;
    object _32589 = NOVALUE;
    object _32586 = NOVALUE;
    object _32585 = NOVALUE;
    object _32584 = NOVALUE;
    object _32582 = NOVALUE;
    object _32579 = NOVALUE;
    object _32577 = NOVALUE;
    object _32576 = NOVALUE;
    object _32575 = NOVALUE;
    object _32573 = NOVALUE;
    object _32570 = NOVALUE;
    object _32569 = NOVALUE;
    object _32567 = NOVALUE;
    object _32566 = NOVALUE;
    object _32564 = NOVALUE;
    object _32563 = NOVALUE;
    object _32561 = NOVALUE;
    object _32560 = NOVALUE;
    object _32558 = NOVALUE;
    object _32557 = NOVALUE;
    object _32554 = NOVALUE;
    object _32552 = NOVALUE;
    object _32550 = NOVALUE;
    object _32549 = NOVALUE;
    object _32548 = NOVALUE;
    object _32546 = NOVALUE;
    object _32545 = NOVALUE;
    object _32544 = NOVALUE;
    object _32541 = NOVALUE;
    object _32540 = NOVALUE;
    object _32538 = NOVALUE;
    object _32535 = NOVALUE;
    object _32532 = NOVALUE;
    object _32530 = NOVALUE;
    object _32528 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1156		a = Code[pc+1]*/
    _32528 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _32528);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1157		task = which_task(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _32530 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    Ref(_32530);
    _task_66095 = _67which_task(_32530);
    _32530 = NOVALUE;
    if (!IS_ATOM_INT(_task_66095)) {
        _1 = (object)(DBL_PTR(_task_66095)->dbl);
        DeRefDS(_task_66095);
        _task_66095 = _1;
    }

    /** execute.e:1158		b = Code[pc+2]*/
    _32532 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _32532);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:1159		s = val[b]*/
    DeRef(_s_66097);
    _2 = (object)SEQ_PTR(_67val_64812);
    _s_66097 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    Ref(_s_66097);

    /** execute.e:1161		if atom(s) then*/
    _32535 = IS_ATOM(_s_66097);
    if (_32535 == 0)
    {
        _32535 = NOVALUE;
        goto L1; // [64] 187
    }
    else{
        _32535 = NOVALUE;
    }

    /** execute.e:1163			if s <= 0 then*/
    if (binary_op_a(GREATER, _s_66097, 0)){
        goto L2; // [69] 79
    }

    /** execute.e:1164				RTFatal("number of executions must be greater than 0")*/
    RefDS(_32537);
    _67RTFatal(_32537);
L2: 

    /** execute.e:1167			tcb[task][TASK_RUNS_MAX] = s   -- max execution count*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66095 + ((s1_ptr)_2)->base);
    Ref(_s_66097);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_66097;
    DeRef(_1);
    _32538 = NOVALUE;

    /** execute.e:1168			if tcb[task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32540 = (object)*(((s1_ptr)_2)->base + _task_66095);
    _2 = (object)SEQ_PTR(_32540);
    _32541 = (object)*(((s1_ptr)_2)->base + 3);
    _32540 = NOVALUE;
    if (binary_op_a(NOTEQ, _32541, 1)){
        _32541 = NOVALUE;
        goto L3; // [104] 120
    }
    _32541 = NOVALUE;

    /** execute.e:1169				rt_first = task_delete(rt_first, task)*/
    _0 = _67task_delete(_67rt_first_64848, _task_66095);
    _67rt_first_64848 = _0;
    if (!IS_ATOM_INT(_67rt_first_64848)) {
        _1 = (object)(DBL_PTR(_67rt_first_64848)->dbl);
        DeRefDS(_67rt_first_64848);
        _67rt_first_64848 = _1;
    }
L3: 

    /** execute.e:1171			if tcb[task][TASK_TYPE] = T_REAL_TIME or*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32544 = (object)*(((s1_ptr)_2)->base + _task_66095);
    _2 = (object)SEQ_PTR(_32544);
    _32545 = (object)*(((s1_ptr)_2)->base + 3);
    _32544 = NOVALUE;
    if (IS_ATOM_INT(_32545)) {
        _32546 = (_32545 == 1);
    }
    else {
        _32546 = binary_op(EQUALS, _32545, 1);
    }
    _32545 = NOVALUE;
    if (IS_ATOM_INT(_32546)) {
        if (_32546 != 0) {
            goto L4; // [136] 159
        }
    }
    else {
        if (DBL_PTR(_32546)->dbl != 0.0) {
            goto L4; // [136] 159
        }
    }
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32548 = (object)*(((s1_ptr)_2)->base + _task_66095);
    _2 = (object)SEQ_PTR(_32548);
    _32549 = (object)*(((s1_ptr)_2)->base + 4);
    _32548 = NOVALUE;
    if (IS_ATOM_INT(_32549)) {
        _32550 = (_32549 == 1);
    }
    else {
        _32550 = binary_op(EQUALS, _32549, 1);
    }
    _32549 = NOVALUE;
    if (_32550 == 0) {
        DeRef(_32550);
        _32550 = NOVALUE;
        goto L5; // [155] 171
    }
    else {
        if (!IS_ATOM_INT(_32550) && DBL_PTR(_32550)->dbl == 0.0){
            DeRef(_32550);
            _32550 = NOVALUE;
            goto L5; // [155] 171
        }
        DeRef(_32550);
        _32550 = NOVALUE;
    }
    DeRef(_32550);
    _32550 = NOVALUE;
L4: 

    /** execute.e:1173				ts_first = task_insert(ts_first, task)*/
    _0 = _67task_insert(_67ts_first_64849, _task_66095);
    _67ts_first_64849 = _0;
    if (!IS_ATOM_INT(_67ts_first_64849)) {
        _1 = (object)(DBL_PTR(_67ts_first_64849)->dbl);
        DeRefDS(_67ts_first_64849);
        _67ts_first_64849 = _1;
    }
L5: 

    /** execute.e:1175			tcb[task][TASK_TYPE] = T_TIME_SHARE*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66095 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _32552 = NOVALUE;
    goto L6; // [184] 542
L1: 

    /** execute.e:1179			if length(s) != 2 then*/
    if (IS_SEQUENCE(_s_66097)){
            _32554 = SEQ_PTR(_s_66097)->length;
    }
    else {
        _32554 = 1;
    }
    if (_32554 == 2)
    goto L7; // [192] 202

    /** execute.e:1180				RTFatal("second argument must be {min-time, max-time}")*/
    RefDS(_32556);
    _67RTFatal(_32556);
L7: 

    /** execute.e:1182			if sequence(s[1]) or sequence(s[2]) then*/
    _2 = (object)SEQ_PTR(_s_66097);
    _32557 = (object)*(((s1_ptr)_2)->base + 1);
    _32558 = IS_SEQUENCE(_32557);
    _32557 = NOVALUE;
    if (_32558 != 0) {
        goto L8; // [211] 227
    }
    _2 = (object)SEQ_PTR(_s_66097);
    _32560 = (object)*(((s1_ptr)_2)->base + 2);
    _32561 = IS_SEQUENCE(_32560);
    _32560 = NOVALUE;
    if (_32561 == 0)
    {
        _32561 = NOVALUE;
        goto L9; // [223] 233
    }
    else{
        _32561 = NOVALUE;
    }
L8: 

    /** execute.e:1183				RTFatal("min and max times must be atoms")*/
    RefDS(_32562);
    _67RTFatal(_32562);
L9: 

    /** execute.e:1185			if s[1] < 0 or s[2] < 0 then*/
    _2 = (object)SEQ_PTR(_s_66097);
    _32563 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_32563)) {
        _32564 = (_32563 < 0);
    }
    else {
        _32564 = binary_op(LESS, _32563, 0);
    }
    _32563 = NOVALUE;
    if (IS_ATOM_INT(_32564)) {
        if (_32564 != 0) {
            goto LA; // [243] 260
        }
    }
    else {
        if (DBL_PTR(_32564)->dbl != 0.0) {
            goto LA; // [243] 260
        }
    }
    _2 = (object)SEQ_PTR(_s_66097);
    _32566 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_32566)) {
        _32567 = (_32566 < 0);
    }
    else {
        _32567 = binary_op(LESS, _32566, 0);
    }
    _32566 = NOVALUE;
    if (_32567 == 0) {
        DeRef(_32567);
        _32567 = NOVALUE;
        goto LB; // [256] 266
    }
    else {
        if (!IS_ATOM_INT(_32567) && DBL_PTR(_32567)->dbl == 0.0){
            DeRef(_32567);
            _32567 = NOVALUE;
            goto LB; // [256] 266
        }
        DeRef(_32567);
        _32567 = NOVALUE;
    }
    DeRef(_32567);
    _32567 = NOVALUE;
LA: 

    /** execute.e:1186				RTFatal("min and max times must be greater than or equal to 0")*/
    RefDS(_32568);
    _67RTFatal(_32568);
LB: 

    /** execute.e:1188			if s[1] > s[2] then*/
    _2 = (object)SEQ_PTR(_s_66097);
    _32569 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_s_66097);
    _32570 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(LESSEQ, _32569, _32570)){
        _32569 = NOVALUE;
        _32570 = NOVALUE;
        goto LC; // [276] 286
    }
    _32569 = NOVALUE;
    _32570 = NOVALUE;

    /** execute.e:1189				RTFatal("task min time must be <= task max time")*/
    RefDS(_32572);
    _67RTFatal(_32572);
LC: 

    /** execute.e:1191			tcb[task][TASK_MIN_INC] = s[1]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66095 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66097);
    _32575 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_32575);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32575;
    if( _1 != _32575 ){
        DeRef(_1);
    }
    _32575 = NOVALUE;
    _32573 = NOVALUE;

    /** execute.e:1193			if s[1] < clock_period/2 then*/
    _2 = (object)SEQ_PTR(_s_66097);
    _32576 = (object)*(((s1_ptr)_2)->base + 1);
    _32577 = binary_op(DIVIDE, _67clock_period_64822, 2);
    if (binary_op_a(GREATEREQ, _32576, _32577)){
        _32576 = NOVALUE;
        DeRefDS(_32577);
        _32577 = NOVALUE;
        goto LD; // [315] 372
    }
    _32576 = NOVALUE;
    DeRef(_32577);
    _32577 = NOVALUE;

    /** execute.e:1195				if s[1] > 1.0e-9 then*/
    _2 = (object)SEQ_PTR(_s_66097);
    _32579 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(LESSEQ, _32579, _32580)){
        _32579 = NOVALUE;
        goto LE; // [325] 355
    }
    _32579 = NOVALUE;

    /** execute.e:1196					tcb[task][TASK_RUNS_MAX] =  floor(clock_period / s[1])*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66095 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66097);
    _32584 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = binary_op(DIVIDE, _67clock_period_64822, _32584);
    _32585 = unary_op(FLOOR, _2);
    DeRef(_2);
    _32584 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32585;
    if( _1 != _32585 ){
        DeRef(_1);
    }
    _32585 = NOVALUE;
    _32582 = NOVALUE;
    goto LF; // [352] 386
LE: 

    /** execute.e:1199					tcb[task][TASK_RUNS_MAX] =  1000000000 -- arbitrary, large*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66095 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1000000000;
    DeRef(_1);
    _32586 = NOVALUE;
    goto LF; // [369] 386
LD: 

    /** execute.e:1202				tcb[task][TASK_RUNS_MAX] = 1*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66095 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _32589 = NOVALUE;
LF: 

    /** execute.e:1204			tcb[task][TASK_MAX_INC] = s[2]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66095 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66097);
    _32593 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_32593);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32593;
    if( _1 != _32593 ){
        DeRef(_1);
    }
    _32593 = NOVALUE;
    _32591 = NOVALUE;

    /** execute.e:1205			now = time()*/
    DeRef(_now_66096);
    _now_66096 = NewDouble(current_time());

    /** execute.e:1206			tcb[task][TASK_MIN_TIME] = now + s[1]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66095 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66097);
    _32597 = (object)*(((s1_ptr)_2)->base + 1);
    _32598 = binary_op(PLUS, _now_66096, _32597);
    _32597 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32598;
    if( _1 != _32598 ){
        DeRef(_1);
    }
    _32598 = NOVALUE;
    _32595 = NOVALUE;

    /** execute.e:1207			tcb[task][TASK_MAX_TIME] = now + s[2]*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66095 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66097);
    _32601 = (object)*(((s1_ptr)_2)->base + 2);
    _32602 = binary_op(PLUS, _now_66096, _32601);
    _32601 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32602;
    if( _1 != _32602 ){
        DeRef(_1);
    }
    _32602 = NOVALUE;
    _32599 = NOVALUE;

    /** execute.e:1209			if tcb[task][TASK_TYPE] = T_TIME_SHARE then*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32603 = (object)*(((s1_ptr)_2)->base + _task_66095);
    _2 = (object)SEQ_PTR(_32603);
    _32604 = (object)*(((s1_ptr)_2)->base + 3);
    _32603 = NOVALUE;
    if (binary_op_a(NOTEQ, _32604, 2)){
        _32604 = NOVALUE;
        goto L10; // [461] 477
    }
    _32604 = NOVALUE;

    /** execute.e:1210				ts_first = task_delete(ts_first, task)*/
    _0 = _67task_delete(_67ts_first_64849, _task_66095);
    _67ts_first_64849 = _0;
    if (!IS_ATOM_INT(_67ts_first_64849)) {
        _1 = (object)(DBL_PTR(_67ts_first_64849)->dbl);
        DeRefDS(_67ts_first_64849);
        _67ts_first_64849 = _1;
    }
L10: 

    /** execute.e:1212			if tcb[task][TASK_TYPE] = T_TIME_SHARE or*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32607 = (object)*(((s1_ptr)_2)->base + _task_66095);
    _2 = (object)SEQ_PTR(_32607);
    _32608 = (object)*(((s1_ptr)_2)->base + 3);
    _32607 = NOVALUE;
    if (IS_ATOM_INT(_32608)) {
        _32609 = (_32608 == 2);
    }
    else {
        _32609 = binary_op(EQUALS, _32608, 2);
    }
    _32608 = NOVALUE;
    if (IS_ATOM_INT(_32609)) {
        if (_32609 != 0) {
            goto L11; // [493] 516
        }
    }
    else {
        if (DBL_PTR(_32609)->dbl != 0.0) {
            goto L11; // [493] 516
        }
    }
    _2 = (object)SEQ_PTR(_67tcb_64845);
    _32611 = (object)*(((s1_ptr)_2)->base + _task_66095);
    _2 = (object)SEQ_PTR(_32611);
    _32612 = (object)*(((s1_ptr)_2)->base + 4);
    _32611 = NOVALUE;
    if (IS_ATOM_INT(_32612)) {
        _32613 = (_32612 == 1);
    }
    else {
        _32613 = binary_op(EQUALS, _32612, 1);
    }
    _32612 = NOVALUE;
    if (_32613 == 0) {
        DeRef(_32613);
        _32613 = NOVALUE;
        goto L12; // [512] 528
    }
    else {
        if (!IS_ATOM_INT(_32613) && DBL_PTR(_32613)->dbl == 0.0){
            DeRef(_32613);
            _32613 = NOVALUE;
            goto L12; // [512] 528
        }
        DeRef(_32613);
        _32613 = NOVALUE;
    }
    DeRef(_32613);
    _32613 = NOVALUE;
L11: 

    /** execute.e:1214				rt_first = task_insert(rt_first, task)*/
    _0 = _67task_insert(_67rt_first_64848, _task_66095);
    _67rt_first_64848 = _0;
    if (!IS_ATOM_INT(_67rt_first_64848)) {
        _1 = (object)(DBL_PTR(_67rt_first_64848)->dbl);
        DeRefDS(_67rt_first_64848);
        _67rt_first_64848 = _1;
    }
L12: 

    /** execute.e:1216			tcb[task][TASK_TYPE] = T_REAL_TIME*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66095 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _32615 = NOVALUE;
L6: 

    /** execute.e:1218		tcb[task][TASK_STATE] = ST_ACTIVE*/
    _2 = (object)SEQ_PTR(_67tcb_64845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64845 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66095 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _32617 = NOVALUE;

    /** execute.e:1219		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:1220	end procedure*/
    DeRef(_now_66096);
    DeRef(_s_66097);
    DeRef(_32546);
    _32546 = NOVALUE;
    DeRef(_32609);
    _32609 = NOVALUE;
    DeRef(_32532);
    _32532 = NOVALUE;
    DeRef(_32564);
    _32564 = NOVALUE;
    DeRef(_32528);
    _32528 = NOVALUE;
    return;
    ;
}


void _67one_trace_line(object _line_66212)
{
    object _32621 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1231		ifdef UNIX then*/

    /** execute.e:1232			printf(trace_file, "%-78.78s\n", {line})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_line_66212);
    ((intptr_t*)_2)[1] = _line_66212;
    _32621 = MAKE_SEQ(_1);
    EPrintf(_67trace_file_66208, _32620, _32621);
    DeRefDS(_32621);
    _32621 = NOVALUE;

    /** execute.e:1236	end procedure*/
    DeRefDS(_line_66212);
    return;
    ;
}


void _67opCOVERAGE_LINE()
{
    object _35032 = NOVALUE;
    object _32624 = NOVALUE;
    object _32623 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1239		cover_line( Code[pc+1] )*/
    _32623 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32624 = (object)*(((s1_ptr)_2)->base + _32623);
    Ref(_32624);
    _35032 = _50cover_line(_32624);
    _32624 = NOVALUE;
    DeRef(_35032);
    _35032 = NOVALUE;

    /** execute.e:1240		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:1241	end procedure*/
    _32623 = NOVALUE;
    return;
    ;
}


void _67opCOVERAGE_ROUTINE()
{
    object _35031 = NOVALUE;
    object _32627 = NOVALUE;
    object _32626 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1244		cover_routine( Code[pc+1] )*/
    _32626 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32627 = (object)*(((s1_ptr)_2)->base + _32626);
    Ref(_32627);
    _35031 = _50cover_routine(_32627);
    _32627 = NOVALUE;
    DeRef(_35031);
    _35031 = NOVALUE;

    /** execute.e:1245		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:1246	end procedure*/
    _32626 = NOVALUE;
    return;
    ;
}


void _67opSTARTLINE()
{
    object _line_66232 = NOVALUE;
    object _w_66233 = NOVALUE;
    object _32660 = NOVALUE;
    object _32659 = NOVALUE;
    object _32658 = NOVALUE;
    object _32655 = NOVALUE;
    object _32650 = NOVALUE;
    object _32649 = NOVALUE;
    object _32648 = NOVALUE;
    object _32647 = NOVALUE;
    object _32646 = NOVALUE;
    object _32645 = NOVALUE;
    object _32644 = NOVALUE;
    object _32641 = NOVALUE;
    object _32640 = NOVALUE;
    object _32638 = NOVALUE;
    object _32637 = NOVALUE;
    object _32636 = NOVALUE;
    object _32634 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1253		if TraceOn then*/
    if (_67TraceOn_64800 == 0)
    {
        goto L1; // [5] 279
    }
    else{
    }

    /** execute.e:1254			if trace_file = -1 then*/
    if (_67trace_file_66208 != -1)
    goto L2; // [12] 40

    /** execute.e:1255				trace_file = open("ctrace.out", "wb")*/
    _67trace_file_66208 = EOpen(_32630, _23845, 0);

    /** execute.e:1256				if trace_file = -1 then*/
    if (_67trace_file_66208 != -1)
    goto L3; // [29] 39

    /** execute.e:1257					RTFatal("Couldn't open ctrace.out")*/
    RefDS(_32633);
    _67RTFatal(_32633);
L3: 
L2: 

    /** execute.e:1261			a = Code[pc+1]*/
    _32634 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _32634);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1263			if atom(slist[$]) then*/
    if (IS_SEQUENCE(_12slist_20317)){
            _32636 = SEQ_PTR(_12slist_20317)->length;
    }
    else {
        _32636 = 1;
    }
    _2 = (object)SEQ_PTR(_12slist_20317);
    _32637 = (object)*(((s1_ptr)_2)->base + _32636);
    _32638 = IS_ATOM(_32637);
    _32637 = NOVALUE;
    if (_32638 == 0)
    {
        _32638 = NOVALUE;
        goto L4; // [70] 84
    }
    else{
        _32638 = NOVALUE;
    }

    /** execute.e:1264				slist = s_expand(slist)*/
    RefDS(_12slist_20317);
    _0 = _61s_expand(_12slist_20317);
    DeRefDS(_12slist_20317);
    _12slist_20317 = _0;
L4: 

    /** execute.e:1266			line = fetch_line(slist[a][SRC])*/
    _2 = (object)SEQ_PTR(_12slist_20317);
    _32640 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_32640);
    _32641 = (object)*(((s1_ptr)_2)->base + 1);
    _32640 = NOVALUE;
    Ref(_32641);
    _0 = _line_66232;
    _line_66232 = _61fetch_line(_32641);
    DeRef(_0);
    _32641 = NOVALUE;

    /** execute.e:1267			line = sprintf("%s:%d\t%s",*/
    _2 = (object)SEQ_PTR(_12slist_20317);
    _32644 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_32644);
    _32645 = (object)*(((s1_ptr)_2)->base + 3);
    _32644 = NOVALUE;
    _2 = (object)SEQ_PTR(_13known_files_11317);
    if (!IS_ATOM_INT(_32645)){
        _32646 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32645)->dbl));
    }
    else{
        _32646 = (object)*(((s1_ptr)_2)->base + _32645);
    }
    Ref(_32646);
    _32647 = _53name_ext(_32646);
    _32646 = NOVALUE;
    _2 = (object)SEQ_PTR(_12slist_20317);
    _32648 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_32648);
    _32649 = (object)*(((s1_ptr)_2)->base + 2);
    _32648 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _32647;
    Ref(_32649);
    ((intptr_t*)_2)[2] = _32649;
    RefDS(_line_66232);
    ((intptr_t*)_2)[3] = _line_66232;
    _32650 = MAKE_SEQ(_1);
    _32649 = NOVALUE;
    _32647 = NOVALUE;
    DeRefDS(_line_66232);
    _line_66232 = EPrintf(-9999999, _32643, _32650);
    DeRefDS(_32650);
    _32650 = NOVALUE;

    /** execute.e:1271			trace_line += 1*/
    _67trace_line_66209 = _67trace_line_66209 + 1;

    /** execute.e:1272			if trace_line >= trace_lines then*/
    if (_67trace_line_66209 < _12trace_lines_64535)
    goto L5; // [170] 210

    /** execute.e:1274				trace_line = 0*/
    _67trace_line_66209 = 0;

    /** execute.e:1275				one_trace_line("")*/
    RefDS(_22015);
    _67one_trace_line(_22015);

    /** execute.e:1276				one_trace_line("               ")*/
    RefDS(_32654);
    _67one_trace_line(_32654);

    /** execute.e:1277				flush(trace_file)*/
    _17flush(_67trace_file_66208);

    /** execute.e:1278				if seek(trace_file, 0) then*/
    _32655 = _17seek(_67trace_file_66208, 0);
    if (_32655 == 0) {
        DeRef(_32655);
        _32655 = NOVALUE;
        goto L6; // [205] 209
    }
    else {
        if (!IS_ATOM_INT(_32655) && DBL_PTR(_32655)->dbl == 0.0){
            DeRef(_32655);
            _32655 = NOVALUE;
            goto L6; // [205] 209
        }
        DeRef(_32655);
        _32655 = NOVALUE;
    }
    DeRef(_32655);
    _32655 = NOVALUE;
L6: 
L5: 

    /** execute.e:1282			one_trace_line(line)*/
    RefDS(_line_66232);
    _67one_trace_line(_line_66232);

    /** execute.e:1283			one_trace_line("")*/
    RefDS(_22015);
    _67one_trace_line(_22015);

    /** execute.e:1284			one_trace_line("=== THE END ===")*/
    RefDS(_32656);
    _67one_trace_line(_32656);

    /** execute.e:1285			one_trace_line("")*/
    RefDS(_22015);
    _67one_trace_line(_22015);

    /** execute.e:1286			one_trace_line("")*/
    RefDS(_22015);
    _67one_trace_line(_22015);

    /** execute.e:1287			one_trace_line("")*/
    RefDS(_22015);
    _67one_trace_line(_22015);

    /** execute.e:1288			flush(trace_file)*/
    _17flush(_67trace_file_66208);

    /** execute.e:1289			w = where(trace_file)*/
    _w_66233 = _17where(_67trace_file_66208);
    if (!IS_ATOM_INT(_w_66233)) {
        _1 = (object)(DBL_PTR(_w_66233)->dbl);
        DeRefDS(_w_66233);
        _w_66233 = _1;
    }

    /** execute.e:1290			if seek(trace_file, w-79*5) then -- back up 5 (fixed-width) lines*/
    _32658 = 395;
    _32659 = _w_66233 - 395;
    if ((object)((uintptr_t)_32659 +(uintptr_t) HIGH_BITS) >= 0){
        _32659 = NewDouble((eudouble)_32659);
    }
    _32658 = NOVALUE;
    _32660 = _17seek(_67trace_file_66208, _32659);
    _32659 = NOVALUE;
    if (_32660 == 0) {
        DeRef(_32660);
        _32660 = NOVALUE;
        goto L7; // [274] 278
    }
    else {
        if (!IS_ATOM_INT(_32660) && DBL_PTR(_32660)->dbl == 0.0){
            DeRef(_32660);
            _32660 = NOVALUE;
            goto L7; // [274] 278
        }
        DeRef(_32660);
        _32660 = NOVALUE;
    }
    DeRef(_32660);
    _32660 = NOVALUE;
L7: 
L1: 

    /** execute.e:1293		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:1294	end procedure*/
    DeRef(_line_66232);
    _32645 = NOVALUE;
    DeRef(_32634);
    _32634 = NOVALUE;
    return;
    ;
}


void _67opPROC_TAIL()
{
    object _arg_66296 = NOVALUE;
    object _sub_66297 = NOVALUE;
    object _32678 = NOVALUE;
    object _32677 = NOVALUE;
    object _32676 = NOVALUE;
    object _32675 = NOVALUE;
    object _32674 = NOVALUE;
    object _32672 = NOVALUE;
    object _32671 = NOVALUE;
    object _32670 = NOVALUE;
    object _32669 = NOVALUE;
    object _32668 = NOVALUE;
    object _32667 = NOVALUE;
    object _32666 = NOVALUE;
    object _32664 = NOVALUE;
    object _32662 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1299		sub = Code[pc+1] -- subroutine*/
    _32662 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _sub_66297 = (object)*(((s1_ptr)_2)->base + _32662);
    if (!IS_ATOM_INT(_sub_66297)){
        _sub_66297 = (object)DBL_PTR(_sub_66297)->dbl;
    }

    /** execute.e:1300		arg = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32664 = (object)*(((s1_ptr)_2)->base + _sub_66297);
    _2 = (object)SEQ_PTR(_32664);
    _arg_66296 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_66296)){
        _arg_66296 = (object)DBL_PTR(_arg_66296)->dbl;
    }
    _32664 = NOVALUE;

    /** execute.e:1303		for i = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32666 = (object)*(((s1_ptr)_2)->base + _sub_66297);
    _2 = (object)SEQ_PTR(_32666);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _32667 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _32667 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _32666 = NOVALUE;
    {
        object _i_66306;
        _i_66306 = 1;
L1: 
        if (binary_op_a(GREATER, _i_66306, _32667)){
            goto L2; // [47] 107
        }

        /** execute.e:1304			val[arg] = val[Code[pc+1+i]]*/
        _32668 = _67pc_64802 + 1;
        if (_32668 > MAXINT){
            _32668 = NewDouble((eudouble)_32668);
        }
        if (IS_ATOM_INT(_32668) && IS_ATOM_INT(_i_66306)) {
            _32669 = _32668 + _i_66306;
        }
        else {
            if (IS_ATOM_INT(_32668)) {
                _32669 = NewDouble((eudouble)_32668 + DBL_PTR(_i_66306)->dbl);
            }
            else {
                if (IS_ATOM_INT(_i_66306)) {
                    _32669 = NewDouble(DBL_PTR(_32668)->dbl + (eudouble)_i_66306);
                }
                else
                _32669 = NewDouble(DBL_PTR(_32668)->dbl + DBL_PTR(_i_66306)->dbl);
            }
        }
        DeRef(_32668);
        _32668 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        if (!IS_ATOM_INT(_32669)){
            _32670 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32669)->dbl));
        }
        else{
            _32670 = (object)*(((s1_ptr)_2)->base + _32669);
        }
        _2 = (object)SEQ_PTR(_67val_64812);
        if (!IS_ATOM_INT(_32670)){
            _32671 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32670)->dbl));
        }
        else{
            _32671 = (object)*(((s1_ptr)_2)->base + _32670);
        }
        Ref(_32671);
        _2 = (object)SEQ_PTR(_67val_64812);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_64812 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_66296);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32671;
        if( _1 != _32671 ){
            DeRef(_1);
        }
        _32671 = NOVALUE;

        /** execute.e:1305			arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _32672 = (object)*(((s1_ptr)_2)->base + _arg_66296);
        _2 = (object)SEQ_PTR(_32672);
        _arg_66296 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_66296)){
            _arg_66296 = (object)DBL_PTR(_arg_66296)->dbl;
        }
        _32672 = NOVALUE;

        /** execute.e:1306		end for*/
        _0 = _i_66306;
        if (IS_ATOM_INT(_i_66306)) {
            _i_66306 = _i_66306 + 1;
            if ((object)((uintptr_t)_i_66306 +(uintptr_t) HIGH_BITS) >= 0){
                _i_66306 = NewDouble((eudouble)_i_66306);
            }
        }
        else {
            _i_66306 = binary_op_a(PLUS, _i_66306, 1);
        }
        DeRef(_0);
        goto L1; // [102] 54
L2: 
        ;
        DeRef(_i_66306);
    }

    /** execute.e:1309		while arg and SymTab[arg][S_SCOPE] <= SC_PRIVATE do*/
L3: 
    if (_arg_66296 == 0) {
        goto L4; // [112] 169
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32675 = (object)*(((s1_ptr)_2)->base + _arg_66296);
    _2 = (object)SEQ_PTR(_32675);
    _32676 = (object)*(((s1_ptr)_2)->base + 4);
    _32675 = NOVALUE;
    if (IS_ATOM_INT(_32676)) {
        _32677 = (_32676 <= 3);
    }
    else {
        _32677 = binary_op(LESSEQ, _32676, 3);
    }
    _32676 = NOVALUE;
    if (_32677 <= 0) {
        if (_32677 == 0) {
            DeRef(_32677);
            _32677 = NOVALUE;
            goto L4; // [135] 169
        }
        else {
            if (!IS_ATOM_INT(_32677) && DBL_PTR(_32677)->dbl == 0.0){
                DeRef(_32677);
                _32677 = NOVALUE;
                goto L4; // [135] 169
            }
            DeRef(_32677);
            _32677 = NOVALUE;
        }
    }
    DeRef(_32677);
    _32677 = NOVALUE;

    /** execute.e:1310			val[arg] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_66296);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** execute.e:1311			arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32678 = (object)*(((s1_ptr)_2)->base + _arg_66296);
    _2 = (object)SEQ_PTR(_32678);
    _arg_66296 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_66296)){
        _arg_66296 = (object)DBL_PTR(_arg_66296)->dbl;
    }
    _32678 = NOVALUE;

    /** execute.e:1312		end while*/
    goto L3; // [166] 112
L4: 

    /** execute.e:1315		pc = 1*/
    _67pc_64802 = 1;

    /** execute.e:1316	end procedure*/
    DeRef(_32662);
    _32662 = NOVALUE;
    _32670 = NOVALUE;
    _32667 = NOVALUE;
    DeRef(_32669);
    _32669 = NOVALUE;
    return;
    ;
}


void _67opPROC()
{
    object _n_66335 = NOVALUE;
    object _arg_66336 = NOVALUE;
    object _sub_66337 = NOVALUE;
    object _p_66338 = NOVALUE;
    object _private_block_66339 = NOVALUE;
    object _32745 = NOVALUE;
    object _32740 = NOVALUE;
    object _32739 = NOVALUE;
    object _32737 = NOVALUE;
    object _32735 = NOVALUE;
    object _32733 = NOVALUE;
    object _32732 = NOVALUE;
    object _32731 = NOVALUE;
    object _32730 = NOVALUE;
    object _32729 = NOVALUE;
    object _32728 = NOVALUE;
    object _32726 = NOVALUE;
    object _32724 = NOVALUE;
    object _32721 = NOVALUE;
    object _32719 = NOVALUE;
    object _32717 = NOVALUE;
    object _32715 = NOVALUE;
    object _32714 = NOVALUE;
    object _32713 = NOVALUE;
    object _32712 = NOVALUE;
    object _32711 = NOVALUE;
    object _32710 = NOVALUE;
    object _32709 = NOVALUE;
    object _32708 = NOVALUE;
    object _32707 = NOVALUE;
    object _32706 = NOVALUE;
    object _32705 = NOVALUE;
    object _32704 = NOVALUE;
    object _32703 = NOVALUE;
    object _32702 = NOVALUE;
    object _32701 = NOVALUE;
    object _32699 = NOVALUE;
    object _32698 = NOVALUE;
    object _32697 = NOVALUE;
    object _32696 = NOVALUE;
    object _32695 = NOVALUE;
    object _32693 = NOVALUE;
    object _32692 = NOVALUE;
    object _32690 = NOVALUE;
    object _32689 = NOVALUE;
    object _32687 = NOVALUE;
    object _32686 = NOVALUE;
    object _32684 = NOVALUE;
    object _32682 = NOVALUE;
    object _32680 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1324		sub = Code[pc+1] -- subroutine*/
    _32680 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _sub_66337 = (object)*(((s1_ptr)_2)->base + _32680);
    if (!IS_ATOM_INT(_sub_66337)){
        _sub_66337 = (object)DBL_PTR(_sub_66337)->dbl;
    }

    /** execute.e:1325		arg = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32682 = (object)*(((s1_ptr)_2)->base + _sub_66337);
    _2 = (object)SEQ_PTR(_32682);
    _arg_66336 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_66336)){
        _arg_66336 = (object)DBL_PTR(_arg_66336)->dbl;
    }
    _32682 = NOVALUE;

    /** execute.e:1327		n = SymTab[sub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32684 = (object)*(((s1_ptr)_2)->base + _sub_66337);
    _2 = (object)SEQ_PTR(_32684);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _n_66335 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _n_66335 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    if (!IS_ATOM_INT(_n_66335)){
        _n_66335 = (object)DBL_PTR(_n_66335)->dbl;
    }
    _32684 = NOVALUE;

    /** execute.e:1329		if SymTab[sub][S_RESIDENT_TASK] != 0 then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32686 = (object)*(((s1_ptr)_2)->base + _sub_66337);
    _2 = (object)SEQ_PTR(_32686);
    _32687 = (object)*(((s1_ptr)_2)->base + 25);
    _32686 = NOVALUE;
    if (binary_op_a(EQUALS, _32687, 0)){
        _32687 = NOVALUE;
        goto L1; // [63] 413
    }
    _32687 = NOVALUE;

    /** execute.e:1333			private_block = repeat(0, SymTab[sub][S_STACK_SPACE])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32689 = (object)*(((s1_ptr)_2)->base + _sub_66337);
    _2 = (object)SEQ_PTR(_32689);
    if (!IS_ATOM_INT(_12S_STACK_SPACE_19924)){
        _32690 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_STACK_SPACE_19924)->dbl));
    }
    else{
        _32690 = (object)*(((s1_ptr)_2)->base + _12S_STACK_SPACE_19924);
    }
    _32689 = NOVALUE;
    DeRef(_private_block_66339);
    _private_block_66339 = Repeat(0, _32690);
    _32690 = NOVALUE;

    /** execute.e:1334			p = 1*/
    _p_66338 = 1;

    /** execute.e:1335			for i = 1 to n do*/
    _32692 = _n_66335;
    {
        object _i_66363;
        _i_66363 = 1;
L2: 
        if (_i_66363 > _32692){
            goto L3; // [95] 173
        }

        /** execute.e:1336				private_block[p] = val[arg]*/
        _2 = (object)SEQ_PTR(_67val_64812);
        _32693 = (object)*(((s1_ptr)_2)->base + _arg_66336);
        Ref(_32693);
        _2 = (object)SEQ_PTR(_private_block_66339);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _private_block_66339 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _p_66338);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32693;
        if( _1 != _32693 ){
            DeRef(_1);
        }
        _32693 = NOVALUE;

        /** execute.e:1337				p += 1*/
        _p_66338 = _p_66338 + 1;

        /** execute.e:1338				val[arg] = val[Code[pc+1+i]]*/
        _32695 = _67pc_64802 + 1;
        if (_32695 > MAXINT){
            _32695 = NewDouble((eudouble)_32695);
        }
        if (IS_ATOM_INT(_32695)) {
            _32696 = _32695 + _i_66363;
        }
        else {
            _32696 = NewDouble(DBL_PTR(_32695)->dbl + (eudouble)_i_66363);
        }
        DeRef(_32695);
        _32695 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        if (!IS_ATOM_INT(_32696)){
            _32697 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32696)->dbl));
        }
        else{
            _32697 = (object)*(((s1_ptr)_2)->base + _32696);
        }
        _2 = (object)SEQ_PTR(_67val_64812);
        if (!IS_ATOM_INT(_32697)){
            _32698 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32697)->dbl));
        }
        else{
            _32698 = (object)*(((s1_ptr)_2)->base + _32697);
        }
        Ref(_32698);
        _2 = (object)SEQ_PTR(_67val_64812);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_64812 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_66336);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32698;
        if( _1 != _32698 ){
            DeRef(_1);
        }
        _32698 = NOVALUE;

        /** execute.e:1339				arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _32699 = (object)*(((s1_ptr)_2)->base + _arg_66336);
        _2 = (object)SEQ_PTR(_32699);
        _arg_66336 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_66336)){
            _arg_66336 = (object)DBL_PTR(_arg_66336)->dbl;
        }
        _32699 = NOVALUE;

        /** execute.e:1340			end for*/
        _i_66363 = _i_66363 + 1;
        goto L2; // [168] 102
L3: 
        ;
    }

    /** execute.e:1343			while arg != 0 */
L4: 
    _32701 = (_arg_66336 != 0);
    if (_32701 == 0) {
        goto L5; // [182] 330
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32703 = (object)*(((s1_ptr)_2)->base + _arg_66336);
    _2 = (object)SEQ_PTR(_32703);
    _32704 = (object)*(((s1_ptr)_2)->base + 4);
    _32703 = NOVALUE;
    if (IS_ATOM_INT(_32704)) {
        _32705 = (_32704 <= 3);
    }
    else {
        _32705 = binary_op(LESSEQ, _32704, 3);
    }
    _32704 = NOVALUE;
    if (IS_ATOM_INT(_32705)) {
        if (_32705 != 0) {
            DeRef(_32706);
            _32706 = 1;
            goto L6; // [204] 230
        }
    }
    else {
        if (DBL_PTR(_32705)->dbl != 0.0) {
            DeRef(_32706);
            _32706 = 1;
            goto L6; // [204] 230
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32707 = (object)*(((s1_ptr)_2)->base + _arg_66336);
    _2 = (object)SEQ_PTR(_32707);
    _32708 = (object)*(((s1_ptr)_2)->base + 4);
    _32707 = NOVALUE;
    if (IS_ATOM_INT(_32708)) {
        _32709 = (_32708 == 2);
    }
    else {
        _32709 = binary_op(EQUALS, _32708, 2);
    }
    _32708 = NOVALUE;
    DeRef(_32706);
    if (IS_ATOM_INT(_32709))
    _32706 = (_32709 != 0);
    else
    _32706 = DBL_PTR(_32709)->dbl != 0.0;
L6: 
    if (_32706 != 0) {
        DeRef(_32710);
        _32710 = 1;
        goto L7; // [230] 256
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32711 = (object)*(((s1_ptr)_2)->base + _arg_66336);
    _2 = (object)SEQ_PTR(_32711);
    _32712 = (object)*(((s1_ptr)_2)->base + 4);
    _32711 = NOVALUE;
    if (IS_ATOM_INT(_32712)) {
        _32713 = (_32712 == 9);
    }
    else {
        _32713 = binary_op(EQUALS, _32712, 9);
    }
    _32712 = NOVALUE;
    if (IS_ATOM_INT(_32713))
    _32710 = (_32713 != 0);
    else
    _32710 = DBL_PTR(_32713)->dbl != 0.0;
L7: 
    if (_32710 == 0)
    {
        _32710 = NOVALUE;
        goto L5; // [257] 330
    }
    else{
        _32710 = NOVALUE;
    }

    /** execute.e:1348				if SymTab[arg][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32714 = (object)*(((s1_ptr)_2)->base + _arg_66336);
    _2 = (object)SEQ_PTR(_32714);
    _32715 = (object)*(((s1_ptr)_2)->base + 4);
    _32714 = NOVALUE;
    if (binary_op_a(EQUALS, _32715, 9)){
        _32715 = NOVALUE;
        goto L8; // [276] 309
    }
    _32715 = NOVALUE;

    /** execute.e:1349					private_block[p] = val[arg]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _32717 = (object)*(((s1_ptr)_2)->base + _arg_66336);
    Ref(_32717);
    _2 = (object)SEQ_PTR(_private_block_66339);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _private_block_66339 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_66338);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32717;
    if( _1 != _32717 ){
        DeRef(_1);
    }
    _32717 = NOVALUE;

    /** execute.e:1350					p += 1*/
    _p_66338 = _p_66338 + 1;

    /** execute.e:1351					val[arg] = NOVALUE  -- necessary?*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_66336);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
L8: 

    /** execute.e:1353				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32719 = (object)*(((s1_ptr)_2)->base + _arg_66336);
    _2 = (object)SEQ_PTR(_32719);
    _arg_66336 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_66336)){
        _arg_66336 = (object)DBL_PTR(_arg_66336)->dbl;
    }
    _32719 = NOVALUE;

    /** execute.e:1354			end while*/
    goto L4; // [327] 178
L5: 

    /** execute.e:1357			arg = SymTab[sub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32721 = (object)*(((s1_ptr)_2)->base + _sub_66337);
    _2 = (object)SEQ_PTR(_32721);
    if (!IS_ATOM_INT(_12S_TEMPS_19909)){
        _arg_66336 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    }
    else{
        _arg_66336 = (object)*(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    }
    if (!IS_ATOM_INT(_arg_66336)){
        _arg_66336 = (object)DBL_PTR(_arg_66336)->dbl;
    }
    _32721 = NOVALUE;

    /** execute.e:1358			while arg != 0 do*/
L9: 
    if (_arg_66336 == 0)
    goto LA; // [351] 404

    /** execute.e:1359				private_block[p] = val[arg]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _32724 = (object)*(((s1_ptr)_2)->base + _arg_66336);
    Ref(_32724);
    _2 = (object)SEQ_PTR(_private_block_66339);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _private_block_66339 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_66338);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32724;
    if( _1 != _32724 ){
        DeRef(_1);
    }
    _32724 = NOVALUE;

    /** execute.e:1360				p += 1*/
    _p_66338 = _p_66338 + 1;

    /** execute.e:1361				val[arg] = NOVALUE -- necessary?*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_66336);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** execute.e:1362				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32726 = (object)*(((s1_ptr)_2)->base + _arg_66336);
    _2 = (object)SEQ_PTR(_32726);
    _arg_66336 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_66336)){
        _arg_66336 = (object)DBL_PTR(_arg_66336)->dbl;
    }
    _32726 = NOVALUE;

    /** execute.e:1363			end while*/
    goto L9; // [401] 351
LA: 

    /** execute.e:1366			save_private_block(sub, private_block)*/
    RefDS(_private_block_66339);
    _67save_private_block(_sub_66337, _private_block_66339);
    goto LB; // [410] 479
L1: 

    /** execute.e:1370			for i = 1 to n do*/
    _32728 = _n_66335;
    {
        object _i_66428;
        _i_66428 = 1;
LC: 
        if (_i_66428 > _32728){
            goto LD; // [418] 478
        }

        /** execute.e:1371				val[arg] = val[Code[pc+1+i]]*/
        _32729 = _67pc_64802 + 1;
        if (_32729 > MAXINT){
            _32729 = NewDouble((eudouble)_32729);
        }
        if (IS_ATOM_INT(_32729)) {
            _32730 = _32729 + _i_66428;
        }
        else {
            _32730 = NewDouble(DBL_PTR(_32729)->dbl + (eudouble)_i_66428);
        }
        DeRef(_32729);
        _32729 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        if (!IS_ATOM_INT(_32730)){
            _32731 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32730)->dbl));
        }
        else{
            _32731 = (object)*(((s1_ptr)_2)->base + _32730);
        }
        _2 = (object)SEQ_PTR(_67val_64812);
        if (!IS_ATOM_INT(_32731)){
            _32732 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32731)->dbl));
        }
        else{
            _32732 = (object)*(((s1_ptr)_2)->base + _32731);
        }
        Ref(_32732);
        _2 = (object)SEQ_PTR(_67val_64812);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_64812 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_66336);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32732;
        if( _1 != _32732 ){
            DeRef(_1);
        }
        _32732 = NOVALUE;

        /** execute.e:1372				arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _32733 = (object)*(((s1_ptr)_2)->base + _arg_66336);
        _2 = (object)SEQ_PTR(_32733);
        _arg_66336 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_66336)){
            _arg_66336 = (object)DBL_PTR(_arg_66336)->dbl;
        }
        _32733 = NOVALUE;

        /** execute.e:1373			end for*/
        _i_66428 = _i_66428 + 1;
        goto LC; // [473] 425
LD: 
        ;
    }
LB: 

    /** execute.e:1376		SymTab[sub][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_66337 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_64819;
    DeRef(_1);
    _32735 = NOVALUE;

    /** execute.e:1378		pc = pc + 2 + n*/
    _32737 = _67pc_64802 + 2;
    if ((object)((uintptr_t)_32737 + (uintptr_t)HIGH_BITS) >= 0){
        _32737 = NewDouble((eudouble)_32737);
    }
    if (IS_ATOM_INT(_32737)) {
        _67pc_64802 = _32737 + _n_66335;
    }
    else {
        _67pc_64802 = NewDouble(DBL_PTR(_32737)->dbl + (eudouble)_n_66335);
    }
    DeRef(_32737);
    _32737 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_64802)) {
        _1 = (object)(DBL_PTR(_67pc_64802)->dbl);
        DeRefDS(_67pc_64802);
        _67pc_64802 = _1;
    }

    /** execute.e:1379		if SymTab[sub][S_TOKEN] != PROC then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32739 = (object)*(((s1_ptr)_2)->base + _sub_66337);
    _2 = (object)SEQ_PTR(_32739);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _32740 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _32740 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _32739 = NOVALUE;
    if (binary_op_a(EQUALS, _32740, 27)){
        _32740 = NOVALUE;
        goto LE; // [526] 539
    }
    _32740 = NOVALUE;

    /** execute.e:1380			pc += 1*/
    _67pc_64802 = _67pc_64802 + 1;
LE: 

    /** execute.e:1383		call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_64820, _67call_stack_64820, _67pc_64802);

    /** execute.e:1384		call_stack = append(call_stack, sub)*/
    Append(&_67call_stack_64820, _67call_stack_64820, _sub_66337);

    /** execute.e:1386		Code = SymTab[sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32745 = (object)*(((s1_ptr)_2)->base + _sub_66337);
    DeRef(_12Code_20315);
    _2 = (object)SEQ_PTR(_32745);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    Ref(_12Code_20315);
    _32745 = NOVALUE;

    /** execute.e:1387		pc = 1*/
    _67pc_64802 = 1;

    /** execute.e:1388	end procedure*/
    DeRef(_private_block_66339);
    DeRef(_32680);
    _32680 = NOVALUE;
    DeRef(_32696);
    _32696 = NOVALUE;
    DeRef(_32709);
    _32709 = NOVALUE;
    DeRef(_32713);
    _32713 = NOVALUE;
    _32697 = NOVALUE;
    DeRef(_32705);
    _32705 = NOVALUE;
    DeRef(_32730);
    _32730 = NOVALUE;
    DeRef(_32701);
    _32701 = NOVALUE;
    _32731 = NOVALUE;
    return;
    ;
}


void _67exit_block(object _block_66465)
{
    object _a_66466 = NOVALUE;
    object _32750 = NOVALUE;
    object _32747 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_block_66465)) {
        _1 = (object)(DBL_PTR(_block_66465)->dbl);
        DeRefDS(_block_66465);
        _block_66465 = _1;
    }

    /** execute.e:1395		integer a = SymTab[block][S_NEXT_IN_BLOCK]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32747 = (object)*(((s1_ptr)_2)->base + _block_66465);
    _2 = (object)SEQ_PTR(_32747);
    if (!IS_ATOM_INT(_12S_NEXT_IN_BLOCK_19856)){
        _a_66466 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NEXT_IN_BLOCK_19856)->dbl));
    }
    else{
        _a_66466 = (object)*(((s1_ptr)_2)->base + _12S_NEXT_IN_BLOCK_19856);
    }
    if (!IS_ATOM_INT(_a_66466)){
        _a_66466 = (object)DBL_PTR(_a_66466)->dbl;
    }
    _32747 = NOVALUE;

    /** execute.e:1396		while a do*/
L1: 
    if (_a_66466 == 0)
    {
        goto L2; // [24] 60
    }
    else{
    }

    /** execute.e:1398			ifdef DEBUG then*/

    /** execute.e:1407			val[a] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _a_66466);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** execute.e:1409			a = SymTab[a][S_NEXT_IN_BLOCK]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32750 = (object)*(((s1_ptr)_2)->base + _a_66466);
    _2 = (object)SEQ_PTR(_32750);
    if (!IS_ATOM_INT(_12S_NEXT_IN_BLOCK_19856)){
        _a_66466 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NEXT_IN_BLOCK_19856)->dbl));
    }
    else{
        _a_66466 = (object)*(((s1_ptr)_2)->base + _12S_NEXT_IN_BLOCK_19856);
    }
    if (!IS_ATOM_INT(_a_66466)){
        _a_66466 = (object)DBL_PTR(_a_66466)->dbl;
    }
    _32750 = NOVALUE;

    /** execute.e:1410		end while*/
    goto L1; // [57] 24
L2: 

    /** execute.e:1411	end procedure*/
    return;
    ;
}


void _67opEXIT_BLOCK()
{
    object _32753 = NOVALUE;
    object _32752 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1414		exit_block( Code[pc+1] )*/
    _32752 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32753 = (object)*(((s1_ptr)_2)->base + _32752);
    Ref(_32753);
    _67exit_block(_32753);
    _32753 = NOVALUE;

    /** execute.e:1415		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:1416	end procedure*/
    _32752 = NOVALUE;
    return;
    ;
}


void _67opRETURNP()
{
    object _arg_66487 = NOVALUE;
    object _sub_66488 = NOVALUE;
    object _caller_66489 = NOVALUE;
    object _op_66490 = NOVALUE;
    object _block_66497 = NOVALUE;
    object _sub_block_66502 = NOVALUE;
    object _local_result_66507 = NOVALUE;
    object _local_result_val_66508 = NOVALUE;
    object _32778 = NOVALUE;
    object _32776 = NOVALUE;
    object _32774 = NOVALUE;
    object _32773 = NOVALUE;
    object _32771 = NOVALUE;
    object _32769 = NOVALUE;
    object _32768 = NOVALUE;
    object _32766 = NOVALUE;
    object _32765 = NOVALUE;
    object _32763 = NOVALUE;
    object _32760 = NOVALUE;
    object _32758 = NOVALUE;
    object _32756 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1421		integer op = Code[pc]*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _op_66490 = (object)*(((s1_ptr)_2)->base + _67pc_64802);
    if (!IS_ATOM_INT(_op_66490)){
        _op_66490 = (object)DBL_PTR(_op_66490)->dbl;
    }

    /** execute.e:1422		sub = Code[pc+1]*/
    _32756 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _sub_66488 = (object)*(((s1_ptr)_2)->base + _32756);
    if (!IS_ATOM_INT(_sub_66488)){
        _sub_66488 = (object)DBL_PTR(_sub_66488)->dbl;
    }

    /** execute.e:1425		symtab_index block = Code[pc+2]*/
    _32758 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _block_66497 = (object)*(((s1_ptr)_2)->base + _32758);
    if (!IS_ATOM_INT(_block_66497)){
        _block_66497 = (object)DBL_PTR(_block_66497)->dbl;
    }

    /** execute.e:1426		symtab_index sub_block = SymTab[sub][S_BLOCK]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32760 = (object)*(((s1_ptr)_2)->base + _sub_66488);
    _2 = (object)SEQ_PTR(_32760);
    if (!IS_ATOM_INT(_12S_BLOCK_19884)){
        _sub_block_66502 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_BLOCK_19884)->dbl));
    }
    else{
        _sub_block_66502 = (object)*(((s1_ptr)_2)->base + _12S_BLOCK_19884);
    }
    if (!IS_ATOM_INT(_sub_block_66502)){
        _sub_block_66502 = (object)DBL_PTR(_sub_block_66502)->dbl;
    }
    _32760 = NOVALUE;

    /** execute.e:1428		integer local_result = result*/
    _local_result_66507 = _67result_66460;

    /** execute.e:1429		object local_result_val*/

    /** execute.e:1430		if local_result then*/
    if (_local_result_66507 == 0)
    {
        goto L1; // [72] 95
    }
    else{
    }

    /** execute.e:1431			result = 0*/
    _67result_66460 = 0;

    /** execute.e:1432			local_result_val = result_val*/
    Ref(_67result_val_66461);
    DeRef(_local_result_val_66508);
    _local_result_val_66508 = _67result_val_66461;

    /** execute.e:1433			result_val = NOVALUE*/
    Ref(_12NOVALUE_20081);
    DeRef(_67result_val_66461);
    _67result_val_66461 = _12NOVALUE_20081;
L1: 

    /** execute.e:1436		while block != sub_block do*/
L2: 
    if (_block_66497 == _sub_block_66502)
    goto L3; // [100] 136

    /** execute.e:1437			if local_result then*/
    if (_local_result_66507 == 0)
    {
        goto L4; // [106] 115
    }
    else{
    }

    /** execute.e:1438				exit_block( block )*/
    _67exit_block(_block_66497);
L4: 

    /** execute.e:1440			block = SymTab[block][S_BLOCK]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32763 = (object)*(((s1_ptr)_2)->base + _block_66497);
    _2 = (object)SEQ_PTR(_32763);
    if (!IS_ATOM_INT(_12S_BLOCK_19884)){
        _block_66497 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_BLOCK_19884)->dbl));
    }
    else{
        _block_66497 = (object)*(((s1_ptr)_2)->base + _12S_BLOCK_19884);
    }
    if (!IS_ATOM_INT(_block_66497)){
        _block_66497 = (object)DBL_PTR(_block_66497)->dbl;
    }
    _32763 = NOVALUE;

    /** execute.e:1441		end while*/
    goto L2; // [133] 100
L3: 

    /** execute.e:1443		exit_block( sub_block )*/
    _67exit_block(_sub_block_66502);

    /** execute.e:1451		pc = call_stack[$-1]*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _32765 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _32765 = 1;
    }
    _32766 = _32765 - 1;
    _32765 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_64820);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _32766);
    if (!IS_ATOM_INT(_67pc_64802))
    _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;

    /** execute.e:1452		call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _32768 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _32768 = 1;
    }
    _32769 = _32768 - 2;
    _32768 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_64820;
    RHS_Slice(_67call_stack_64820, 1, _32769);

    /** execute.e:1454		SymTab[sub][S_RESIDENT_TASK] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_66488 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _32771 = NOVALUE;

    /** execute.e:1456		if length(call_stack) then*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _32773 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _32773 = 1;
    }
    if (_32773 == 0)
    {
        _32773 = NOVALUE;
        goto L5; // [194] 256
    }
    else{
        _32773 = NOVALUE;
    }

    /** execute.e:1457			caller = call_stack[$]*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _32774 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _32774 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_64820);
    _caller_66489 = (object)*(((s1_ptr)_2)->base + _32774);
    if (!IS_ATOM_INT(_caller_66489)){
        _caller_66489 = (object)DBL_PTR(_caller_66489)->dbl;
    }

    /** execute.e:1458			Code = SymTab[caller][S_CODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32776 = (object)*(((s1_ptr)_2)->base + _caller_66489);
    DeRef(_12Code_20315);
    _2 = (object)SEQ_PTR(_32776);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    Ref(_12Code_20315);
    _32776 = NOVALUE;

    /** execute.e:1459			restore_privates(caller)*/
    _67restore_privates(_caller_66489);

    /** execute.e:1460			if local_result then*/
    if (_local_result_66507 == 0)
    {
        goto L6; // [233] 268
    }
    else{
    }

    /** execute.e:1461				val[Code[local_result]] = local_result_val*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32778 = (object)*(((s1_ptr)_2)->base + _local_result_66507);
    Ref(_local_result_val_66508);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32778))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_32778)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _32778);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _local_result_val_66508;
    DeRef(_1);
    goto L6; // [253] 268
L5: 

    /** execute.e:1464			kill_task(current_task)*/
    _67kill_task(_67current_task_64819);

    /** execute.e:1465			scheduler()*/
    _67scheduler();
L6: 

    /** execute.e:1469	end procedure*/
    DeRef(_local_result_val_66508);
    DeRef(_32758);
    _32758 = NOVALUE;
    DeRef(_32756);
    _32756 = NOVALUE;
    DeRef(_32769);
    _32769 = NOVALUE;
    _32778 = NOVALUE;
    DeRef(_32766);
    _32766 = NOVALUE;
    return;
    ;
}


void _67opRETURNF()
{
    object _32784 = NOVALUE;
    object _32783 = NOVALUE;
    object _32782 = NOVALUE;
    object _32780 = NOVALUE;
    object _32779 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1473		result_val = val[Code[pc+3]]*/
    _32779 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32780 = (object)*(((s1_ptr)_2)->base + _32779);
    DeRef(_67result_val_66461);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_32780)){
        _67result_val_66461 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32780)->dbl));
    }
    else{
        _67result_val_66461 = (object)*(((s1_ptr)_2)->base + _32780);
    }
    Ref(_67result_val_66461);

    /** execute.e:1474		result = call_stack[$-1] - 1*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _32782 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _32782 = 1;
    }
    _32783 = _32782 - 1;
    _32782 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_64820);
    _32784 = (object)*(((s1_ptr)_2)->base + _32783);
    if (IS_ATOM_INT(_32784)) {
        _67result_66460 = _32784 - 1;
    }
    else {
        _67result_66460 = binary_op(MINUS, _32784, 1);
    }
    _32784 = NOVALUE;
    if (!IS_ATOM_INT(_67result_66460)) {
        _1 = (object)(DBL_PTR(_67result_66460)->dbl);
        DeRefDS(_67result_66460);
        _67result_66460 = _1;
    }

    /** execute.e:1475		opRETURNP()*/
    _67opRETURNP();

    /** execute.e:1476	end procedure*/
    _32780 = NOVALUE;
    _32783 = NOVALUE;
    _32779 = NOVALUE;
    return;
    ;
}


void _67opCALL_BACK_RETURN()
{
    object _0, _1, _2;
    

    /** execute.e:1480		keep_running = FALSE*/
    _67keep_running_64809 = _9FALSE_444;

    /** execute.e:1481	end procedure*/
    return;
    ;
}


void _67opBADRETURNF()
{
    object _0, _1, _2;
    

    /** execute.e:1485		RTFatal("attempt to exit a function without returning a value")*/
    RefDS(_32786);
    _67RTFatal(_32786);

    /** execute.e:1486	end procedure*/
    return;
    ;
}


void _67opRETURNT()
{
    object _32788 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1490		pc += 1*/
    _67pc_64802 = _67pc_64802 + 1;

    /** execute.e:1491		if pc > length(Code) then*/
    if (IS_SEQUENCE(_12Code_20315)){
            _32788 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _32788 = 1;
    }
    if (_67pc_64802 <= _32788)
    goto L1; // [18] 32

    /** execute.e:1492			keep_running = FALSE  -- we've reached the end of the code*/
    _67keep_running_64809 = _9FALSE_444;
L1: 

    /** execute.e:1494	end procedure*/
    return;
    ;
}


void _67opRHS_SUBS()
{
    object _sub_66567 = NOVALUE;
    object _x_66568 = NOVALUE;
    object _32811 = NOVALUE;
    object _32810 = NOVALUE;
    object _32809 = NOVALUE;
    object _32808 = NOVALUE;
    object _32806 = NOVALUE;
    object _32805 = NOVALUE;
    object _32803 = NOVALUE;
    object _32800 = NOVALUE;
    object _32798 = NOVALUE;
    object _32794 = NOVALUE;
    object _32792 = NOVALUE;
    object _32790 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1501		a = Code[pc+1]*/
    _32790 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _32790);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1502		b = Code[pc+2]*/
    _32792 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _32792);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:1503		target = Code[pc+3]*/
    _32794 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _32794);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:1504		x = val[a]*/
    DeRef(_x_66568);
    _2 = (object)SEQ_PTR(_67val_64812);
    _x_66568 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    Ref(_x_66568);

    /** execute.e:1505		sub = val[b]*/
    DeRef(_sub_66567);
    _2 = (object)SEQ_PTR(_67val_64812);
    _sub_66567 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    Ref(_sub_66567);

    /** execute.e:1506		if atom(x) then*/
    _32798 = IS_ATOM(_x_66568);
    if (_32798 == 0)
    {
        _32798 = NOVALUE;
        goto L1; // [74] 83
    }
    else{
        _32798 = NOVALUE;
    }

    /** execute.e:1507			RTFatal("attempt to subscript an atom\n(reading from it)")*/
    RefDS(_32799);
    _67RTFatal(_32799);
L1: 

    /** execute.e:1509		if sequence(sub) then*/
    _32800 = IS_SEQUENCE(_sub_66567);
    if (_32800 == 0)
    {
        _32800 = NOVALUE;
        goto L2; // [88] 97
    }
    else{
        _32800 = NOVALUE;
    }

    /** execute.e:1510			RTFatal("subscript must be an atom\n(reading an element of a sequence)")*/
    RefDS(_32801);
    _67RTFatal(_32801);
L2: 

    /** execute.e:1512		sub = floor(sub)*/
    _0 = _sub_66567;
    if (IS_ATOM_INT(_sub_66567))
    _sub_66567 = e_floor(_sub_66567);
    else
    _sub_66567 = unary_op(FLOOR, _sub_66567);
    DeRef(_0);

    /** execute.e:1513		if sub < 1 or sub > length(x) then*/
    if (IS_ATOM_INT(_sub_66567)) {
        _32803 = (_sub_66567 < 1);
    }
    else {
        _32803 = binary_op(LESS, _sub_66567, 1);
    }
    if (IS_ATOM_INT(_32803)) {
        if (_32803 != 0) {
            goto L3; // [108] 124
        }
    }
    else {
        if (DBL_PTR(_32803)->dbl != 0.0) {
            goto L3; // [108] 124
        }
    }
    if (IS_SEQUENCE(_x_66568)){
            _32805 = SEQ_PTR(_x_66568)->length;
    }
    else {
        _32805 = 1;
    }
    if (IS_ATOM_INT(_sub_66567)) {
        _32806 = (_sub_66567 > _32805);
    }
    else {
        _32806 = binary_op(GREATER, _sub_66567, _32805);
    }
    _32805 = NOVALUE;
    if (_32806 == 0) {
        DeRef(_32806);
        _32806 = NOVALUE;
        goto L4; // [120] 141
    }
    else {
        if (!IS_ATOM_INT(_32806) && DBL_PTR(_32806)->dbl == 0.0){
            DeRef(_32806);
            _32806 = NOVALUE;
            goto L4; // [120] 141
        }
        DeRef(_32806);
        _32806 = NOVALUE;
    }
    DeRef(_32806);
    _32806 = NOVALUE;
L3: 

    /** execute.e:1514			RTFatal(*/
    if (IS_SEQUENCE(_x_66568)){
            _32808 = SEQ_PTR(_x_66568)->length;
    }
    else {
        _32808 = 1;
    }
    Ref(_sub_66567);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _sub_66567;
    ((intptr_t *)_2)[2] = _32808;
    _32809 = MAKE_SEQ(_1);
    _32808 = NOVALUE;
    _32810 = EPrintf(-9999999, _32807, _32809);
    DeRefDS(_32809);
    _32809 = NOVALUE;
    _67RTFatal(_32810);
    _32810 = NOVALUE;
L4: 

    /** execute.e:1519		val[target] = x[sub]*/
    _2 = (object)SEQ_PTR(_x_66568);
    if (!IS_ATOM_INT(_sub_66567)){
        _32811 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_sub_66567)->dbl));
    }
    else{
        _32811 = (object)*(((s1_ptr)_2)->base + _sub_66567);
    }
    Ref(_32811);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32811;
    if( _1 != _32811 ){
        DeRef(_1);
    }
    _32811 = NOVALUE;

    /** execute.e:1520		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:1521	end procedure*/
    DeRef(_sub_66567);
    DeRef(_x_66568);
    DeRef(_32792);
    _32792 = NOVALUE;
    DeRef(_32790);
    _32790 = NOVALUE;
    DeRef(_32794);
    _32794 = NOVALUE;
    DeRef(_32803);
    _32803 = NOVALUE;
    return;
    ;
}


void _67opGOTO()
{
    object _32813 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1524		pc = Code[pc+1]*/
    _32813 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _32813);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }

    /** execute.e:1525	end procedure*/
    _32813 = NOVALUE;
    return;
    ;
}


void _67opGLABEL()
{
    object _32815 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1527		pc = Code[pc+1]*/
    _32815 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _32815);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }

    /** execute.e:1528	end procedure*/
    _32815 = NOVALUE;
    return;
    ;
}


void _67opIF()
{
    object _32821 = NOVALUE;
    object _32819 = NOVALUE;
    object _32817 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1531		a = Code[pc+1]*/
    _32817 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _32817);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1532		if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _32819 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (binary_op_a(NOTEQ, _32819, 0)){
        _32819 = NOVALUE;
        goto L1; // [27] 50
    }
    _32819 = NOVALUE;

    /** execute.e:1533			pc = Code[pc+2]*/
    _32821 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _32821);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }
    goto L2; // [47] 59
L1: 

    /** execute.e:1535			pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;
L2: 

    /** execute.e:1537	end procedure*/
    DeRef(_32821);
    _32821 = NOVALUE;
    DeRef(_32817);
    _32817 = NOVALUE;
    return;
    ;
}


void _67opINTEGER_CHECK()
{
    object _32829 = NOVALUE;
    object _32827 = NOVALUE;
    object _32826 = NOVALUE;
    object _32824 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1540		a = Code[pc+1]*/
    _32824 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _32824);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1541		if not integer(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _32826 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_32826))
    _32827 = 1;
    else if (IS_ATOM_DBL(_32826))
    _32827 = IS_ATOM_INT(DoubleToInt(_32826));
    else
    _32827 = 0;
    _32826 = NOVALUE;
    if (_32827 != 0)
    goto L1; // [30] 45
    _32827 = NOVALUE;

    /** execute.e:1542			RTFatalType(pc+1)*/
    _32829 = _67pc_64802 + 1;
    if (_32829 > MAXINT){
        _32829 = NewDouble((eudouble)_32829);
    }
    _67RTFatalType(_32829);
    _32829 = NOVALUE;
L1: 

    /** execute.e:1544		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:1545	end procedure*/
    DeRef(_32824);
    _32824 = NOVALUE;
    return;
    ;
}


void _67opATOM_CHECK()
{
    object _32836 = NOVALUE;
    object _32834 = NOVALUE;
    object _32833 = NOVALUE;
    object _32831 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1548		a = Code[pc+1]*/
    _32831 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _32831);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1549		if not atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _32833 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _32834 = IS_ATOM(_32833);
    _32833 = NOVALUE;
    if (_32834 != 0)
    goto L1; // [30] 45
    _32834 = NOVALUE;

    /** execute.e:1550			RTFatalType(pc+1)*/
    _32836 = _67pc_64802 + 1;
    if (_32836 > MAXINT){
        _32836 = NewDouble((eudouble)_32836);
    }
    _67RTFatalType(_32836);
    _32836 = NOVALUE;
L1: 

    /** execute.e:1552		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:1553	end procedure*/
    DeRef(_32831);
    _32831 = NOVALUE;
    return;
    ;
}


void _67opSEQUENCE_CHECK()
{
    object _32843 = NOVALUE;
    object _32841 = NOVALUE;
    object _32840 = NOVALUE;
    object _32838 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1556		a = Code[pc+1]*/
    _32838 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _32838);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1557		if not sequence(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _32840 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _32841 = IS_SEQUENCE(_32840);
    _32840 = NOVALUE;
    if (_32841 != 0)
    goto L1; // [30] 45
    _32841 = NOVALUE;

    /** execute.e:1558			RTFatalType(pc+1)*/
    _32843 = _67pc_64802 + 1;
    if (_32843 > MAXINT){
        _32843 = NewDouble((eudouble)_32843);
    }
    _67RTFatalType(_32843);
    _32843 = NOVALUE;
L1: 

    /** execute.e:1560		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:1561	end procedure*/
    DeRef(_32838);
    _32838 = NOVALUE;
    return;
    ;
}


void _67opASSIGN()
{
    object _a_66656 = NOVALUE;
    object _32850 = NOVALUE;
    object _32849 = NOVALUE;
    object _32847 = NOVALUE;
    object _32845 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1565		integer a = Code[pc+1]*/
    _32845 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _a_66656 = (object)*(((s1_ptr)_2)->base + _32845);
    if (!IS_ATOM_INT(_a_66656)){
        _a_66656 = (object)DBL_PTR(_a_66656)->dbl;
    }

    /** execute.e:1566		target = Code[pc+2]*/
    _32847 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _32847);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:1567		val[target] = val[a]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _32849 = (object)*(((s1_ptr)_2)->base + _a_66656);
    Ref(_32849);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32849;
    if( _1 != _32849 ){
        DeRef(_1);
    }
    _32849 = NOVALUE;

    /** execute.e:1568		if sym_mode( a ) = M_TEMP then*/
    _32850 = _53sym_mode(_a_66656);
    if (binary_op_a(NOTEQ, _32850, 3)){
        DeRef(_32850);
        _32850 = NOVALUE;
        goto L1; // [57] 72
    }
    DeRef(_32850);
    _32850 = NOVALUE;

    /** execute.e:1569			val[a] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _a_66656);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
L1: 

    /** execute.e:1571		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:1572	end procedure*/
    DeRef(_32847);
    _32847 = NOVALUE;
    DeRef(_32845);
    _32845 = NOVALUE;
    return;
    ;
}


void _67opELSE()
{
    object _32853 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1576		pc = Code[pc+1]*/
    _32853 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _32853);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }

    /** execute.e:1577	end procedure*/
    _32853 = NOVALUE;
    return;
    ;
}


void _67opRIGHT_BRACE_N()
{
    object _x_66678 = NOVALUE;
    object _32870 = NOVALUE;
    object _32868 = NOVALUE;
    object _32867 = NOVALUE;
    object _32866 = NOVALUE;
    object _32864 = NOVALUE;
    object _32863 = NOVALUE;
    object _32861 = NOVALUE;
    object _32860 = NOVALUE;
    object _32859 = NOVALUE;
    object _32858 = NOVALUE;
    object _32857 = NOVALUE;
    object _32855 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1583		len = Code[pc+1]*/
    _32855 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67len_64808 = (object)*(((s1_ptr)_2)->base + _32855);
    if (!IS_ATOM_INT(_67len_64808)){
        _67len_64808 = (object)DBL_PTR(_67len_64808)->dbl;
    }

    /** execute.e:1584		x = {}*/
    RefDS(_22015);
    DeRef(_x_66678);
    _x_66678 = _22015;

    /** execute.e:1585		for i = pc+len+1 to pc+2 by -1 do*/
    _32857 = _67pc_64802 + _67len_64808;
    if ((object)((uintptr_t)_32857 + (uintptr_t)HIGH_BITS) >= 0){
        _32857 = NewDouble((eudouble)_32857);
    }
    if (IS_ATOM_INT(_32857)) {
        _32858 = _32857 + 1;
        if (_32858 > MAXINT){
            _32858 = NewDouble((eudouble)_32858);
        }
    }
    else
    _32858 = binary_op(PLUS, 1, _32857);
    DeRef(_32857);
    _32857 = NOVALUE;
    _32859 = _67pc_64802 + 2;
    if ((object)((uintptr_t)_32859 + (uintptr_t)HIGH_BITS) >= 0){
        _32859 = NewDouble((eudouble)_32859);
    }
    {
        object _i_66683;
        Ref(_32858);
        _i_66683 = _32858;
L1: 
        if (binary_op_a(LESS, _i_66683, _32859)){
            goto L2; // [44] 111
        }

        /** execute.e:1587			x = append(x, val[Code[i]])*/
        _2 = (object)SEQ_PTR(_12Code_20315);
        if (!IS_ATOM_INT(_i_66683)){
            _32860 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_66683)->dbl));
        }
        else{
            _32860 = (object)*(((s1_ptr)_2)->base + _i_66683);
        }
        _2 = (object)SEQ_PTR(_67val_64812);
        if (!IS_ATOM_INT(_32860)){
            _32861 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32860)->dbl));
        }
        else{
            _32861 = (object)*(((s1_ptr)_2)->base + _32860);
        }
        Ref(_32861);
        Append(&_x_66678, _x_66678, _32861);
        _32861 = NOVALUE;

        /** execute.e:1588			if sym_mode( Code[i] ) = M_TEMP then*/
        _2 = (object)SEQ_PTR(_12Code_20315);
        if (!IS_ATOM_INT(_i_66683)){
            _32863 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_66683)->dbl));
        }
        else{
            _32863 = (object)*(((s1_ptr)_2)->base + _i_66683);
        }
        Ref(_32863);
        _32864 = _53sym_mode(_32863);
        _32863 = NOVALUE;
        if (binary_op_a(NOTEQ, _32864, 3)){
            DeRef(_32864);
            _32864 = NOVALUE;
            goto L3; // [83] 104
        }
        DeRef(_32864);
        _32864 = NOVALUE;

        /** execute.e:1589				val[Code[i]] = NOVALUE*/
        _2 = (object)SEQ_PTR(_12Code_20315);
        if (!IS_ATOM_INT(_i_66683)){
            _32866 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_66683)->dbl));
        }
        else{
            _32866 = (object)*(((s1_ptr)_2)->base + _i_66683);
        }
        Ref(_12NOVALUE_20081);
        _2 = (object)SEQ_PTR(_67val_64812);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_64812 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_32866))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_32866)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _32866);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _12NOVALUE_20081;
        DeRef(_1);
L3: 

        /** execute.e:1591		end for*/
        _0 = _i_66683;
        if (IS_ATOM_INT(_i_66683)) {
            _i_66683 = _i_66683 + -1;
            if ((object)((uintptr_t)_i_66683 +(uintptr_t) HIGH_BITS) >= 0){
                _i_66683 = NewDouble((eudouble)_i_66683);
            }
        }
        else {
            _i_66683 = binary_op_a(PLUS, _i_66683, -1);
        }
        DeRef(_0);
        goto L1; // [106] 51
L2: 
        ;
        DeRef(_i_66683);
    }

    /** execute.e:1592		target = Code[pc+len+2]*/
    _32867 = _67pc_64802 + _67len_64808;
    if ((object)((uintptr_t)_32867 + (uintptr_t)HIGH_BITS) >= 0){
        _32867 = NewDouble((eudouble)_32867);
    }
    if (IS_ATOM_INT(_32867)) {
        _32868 = _32867 + 2;
    }
    else {
        _32868 = NewDouble(DBL_PTR(_32867)->dbl + (eudouble)2);
    }
    DeRef(_32867);
    _32867 = NOVALUE;
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!IS_ATOM_INT(_32868)){
        _67target_64807 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32868)->dbl));
    }
    else{
        _67target_64807 = (object)*(((s1_ptr)_2)->base + _32868);
    }
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:1593		val[target] = x*/
    RefDS(_x_66678);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _x_66678;
    DeRef(_1);

    /** execute.e:1594		pc += 3 + len*/
    _32870 = 3 + _67len_64808;
    if ((object)((uintptr_t)_32870 + (uintptr_t)HIGH_BITS) >= 0){
        _32870 = NewDouble((eudouble)_32870);
    }
    if (IS_ATOM_INT(_32870)) {
        _67pc_64802 = _67pc_64802 + _32870;
    }
    else {
        _67pc_64802 = NewDouble((eudouble)_67pc_64802 + DBL_PTR(_32870)->dbl);
    }
    DeRef(_32870);
    _32870 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_64802)) {
        _1 = (object)(DBL_PTR(_67pc_64802)->dbl);
        DeRefDS(_67pc_64802);
        _67pc_64802 = _1;
    }

    /** execute.e:1595	end procedure*/
    DeRefDS(_x_66678);
    DeRef(_32855);
    _32855 = NOVALUE;
    DeRef(_32868);
    _32868 = NOVALUE;
    DeRef(_32859);
    _32859 = NOVALUE;
    DeRef(_32858);
    _32858 = NOVALUE;
    _32860 = NOVALUE;
    _32866 = NOVALUE;
    return;
    ;
}


void _67opRIGHT_BRACE_2()
{
    object _32892 = NOVALUE;
    object _32891 = NOVALUE;
    object _32889 = NOVALUE;
    object _32888 = NOVALUE;
    object _32887 = NOVALUE;
    object _32886 = NOVALUE;
    object _32885 = NOVALUE;
    object _32883 = NOVALUE;
    object _32882 = NOVALUE;
    object _32881 = NOVALUE;
    object _32880 = NOVALUE;
    object _32879 = NOVALUE;
    object _32878 = NOVALUE;
    object _32877 = NOVALUE;
    object _32876 = NOVALUE;
    object _32875 = NOVALUE;
    object _32874 = NOVALUE;
    object _32872 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1599		target = Code[pc+3]*/
    _32872 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _32872);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:1601		val[target] = {val[Code[pc+2]], val[Code[pc+1]]}*/
    _32874 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32875 = (object)*(((s1_ptr)_2)->base + _32874);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_32875)){
        _32876 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32875)->dbl));
    }
    else{
        _32876 = (object)*(((s1_ptr)_2)->base + _32875);
    }
    _32877 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32878 = (object)*(((s1_ptr)_2)->base + _32877);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_32878)){
        _32879 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32878)->dbl));
    }
    else{
        _32879 = (object)*(((s1_ptr)_2)->base + _32878);
    }
    Ref(_32879);
    Ref(_32876);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _32876;
    ((intptr_t *)_2)[2] = _32879;
    _32880 = MAKE_SEQ(_1);
    _32879 = NOVALUE;
    _32876 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32880;
    if( _1 != _32880 ){
        DeRef(_1);
    }
    _32880 = NOVALUE;

    /** execute.e:1602		if sym_mode( Code[pc+2] ) = M_TEMP then*/
    _32881 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32882 = (object)*(((s1_ptr)_2)->base + _32881);
    Ref(_32882);
    _32883 = _53sym_mode(_32882);
    _32882 = NOVALUE;
    if (binary_op_a(NOTEQ, _32883, 3)){
        DeRef(_32883);
        _32883 = NOVALUE;
        goto L1; // [87] 114
    }
    DeRef(_32883);
    _32883 = NOVALUE;

    /** execute.e:1603			val[Code[pc+2]] = NOVALUE*/
    _32885 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32886 = (object)*(((s1_ptr)_2)->base + _32885);
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32886))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_32886)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _32886);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
L1: 

    /** execute.e:1605		if sym_mode( Code[pc+1] ) = M_TEMP then*/
    _32887 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32888 = (object)*(((s1_ptr)_2)->base + _32887);
    Ref(_32888);
    _32889 = _53sym_mode(_32888);
    _32888 = NOVALUE;
    if (binary_op_a(NOTEQ, _32889, 3)){
        DeRef(_32889);
        _32889 = NOVALUE;
        goto L2; // [134] 161
    }
    DeRef(_32889);
    _32889 = NOVALUE;

    /** execute.e:1606			val[Code[pc+1]] = NOVALUE*/
    _32891 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32892 = (object)*(((s1_ptr)_2)->base + _32891);
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32892))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_32892)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _32892);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
L2: 

    /** execute.e:1608		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:1609	end procedure*/
    _32878 = NOVALUE;
    DeRef(_32874);
    _32874 = NOVALUE;
    DeRef(_32881);
    _32881 = NOVALUE;
    DeRef(_32877);
    _32877 = NOVALUE;
    _32875 = NOVALUE;
    DeRef(_32872);
    _32872 = NOVALUE;
    DeRef(_32885);
    _32885 = NOVALUE;
    DeRef(_32891);
    _32891 = NOVALUE;
    _32892 = NOVALUE;
    DeRef(_32887);
    _32887 = NOVALUE;
    _32886 = NOVALUE;
    return;
    ;
}


void _67opPLUS1()
{
    object _32899 = NOVALUE;
    object _32898 = NOVALUE;
    object _32896 = NOVALUE;
    object _32894 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1613		a = Code[pc+1]*/
    _32894 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _32894);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1615		target = Code[pc+3]*/
    _32896 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _32896);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:1616		val[target] = val[a] + 1*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _32898 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_32898)) {
        _32899 = _32898 + 1;
        if (_32899 > MAXINT){
            _32899 = NewDouble((eudouble)_32899);
        }
    }
    else
    _32899 = binary_op(PLUS, 1, _32898);
    _32898 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32899;
    if( _1 != _32899 ){
        DeRef(_1);
    }
    _32899 = NOVALUE;

    /** execute.e:1617		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:1618	end procedure*/
    _32894 = NOVALUE;
    _32896 = NOVALUE;
    return;
    ;
}


void _67opGLOBAL_INIT_CHECK()
{
    object _32909 = NOVALUE;
    object _32907 = NOVALUE;
    object _32906 = NOVALUE;
    object _32904 = NOVALUE;
    object _32903 = NOVALUE;
    object _32901 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1622		a = Code[pc+1]*/
    _32901 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _32901);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1623		if equal(val[a], NOVALUE) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _32903 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (_32903 == _12NOVALUE_20081)
    _32904 = 1;
    else if (IS_ATOM_INT(_32903) && IS_ATOM_INT(_12NOVALUE_20081))
    _32904 = 0;
    else
    _32904 = (compare(_32903, _12NOVALUE_20081) == 0);
    _32903 = NOVALUE;
    if (_32904 == 0)
    {
        _32904 = NOVALUE;
        goto L1; // [33] 62
    }
    else{
        _32904 = NOVALUE;
    }

    /** execute.e:1624			RTFatal("variable " & SymTab[a][S_NAME] & " has not been assigned a value")*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32906 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_32906);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _32907 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _32907 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _32906 = NOVALUE;
    {
        object concat_list[3];

        concat_list[0] = _32908;
        concat_list[1] = _32907;
        concat_list[2] = _32905;
        Concat_N((object_ptr)&_32909, concat_list, 3);
    }
    _32907 = NOVALUE;
    _67RTFatal(_32909);
    _32909 = NOVALUE;
L1: 

    /** execute.e:1626		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:1627	end procedure*/
    DeRef(_32901);
    _32901 = NOVALUE;
    return;
    ;
}


void _67opWHILE()
{
    object _32915 = NOVALUE;
    object _32913 = NOVALUE;
    object _32911 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1631		a = Code[pc+1]*/
    _32911 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _32911);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1632		if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _32913 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (binary_op_a(NOTEQ, _32913, 0)){
        _32913 = NOVALUE;
        goto L1; // [27] 50
    }
    _32913 = NOVALUE;

    /** execute.e:1633			pc = Code[pc+2]*/
    _32915 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _32915);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }
    goto L2; // [47] 59
L1: 

    /** execute.e:1635			pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;
L2: 

    /** execute.e:1637	end procedure*/
    DeRef(_32911);
    _32911 = NOVALUE;
    DeRef(_32915);
    _32915 = NOVALUE;
    return;
    ;
}


void _67opSWITCH_SPI()
{
    object _32940 = NOVALUE;
    object _32938 = NOVALUE;
    object _32937 = NOVALUE;
    object _32936 = NOVALUE;
    object _32935 = NOVALUE;
    object _32934 = NOVALUE;
    object _32933 = NOVALUE;
    object _32932 = NOVALUE;
    object _32931 = NOVALUE;
    object _32930 = NOVALUE;
    object _32929 = NOVALUE;
    object _32928 = NOVALUE;
    object _32926 = NOVALUE;
    object _32925 = NOVALUE;
    object _32924 = NOVALUE;
    object _32923 = NOVALUE;
    object _32922 = NOVALUE;
    object _32921 = NOVALUE;
    object _32920 = NOVALUE;
    object _32919 = NOVALUE;
    object _32918 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1645		if integer( val[Code[pc+1]] ) then*/
    _32918 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32919 = (object)*(((s1_ptr)_2)->base + _32918);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_32919)){
        _32920 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32919)->dbl));
    }
    else{
        _32920 = (object)*(((s1_ptr)_2)->base + _32919);
    }
    if (IS_ATOM_INT(_32920))
    _32921 = 1;
    else if (IS_ATOM_DBL(_32920))
    _32921 = IS_ATOM_INT(DoubleToInt(_32920));
    else
    _32921 = 0;
    _32920 = NOVALUE;
    if (_32921 == 0)
    {
        _32921 = NOVALUE;
        goto L1; // [24] 149
    }
    else{
        _32921 = NOVALUE;
    }

    /** execute.e:1646			a = val[Code[pc+1]] - Code[pc+2]*/
    _32922 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32923 = (object)*(((s1_ptr)_2)->base + _32922);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_32923)){
        _32924 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32923)->dbl));
    }
    else{
        _32924 = (object)*(((s1_ptr)_2)->base + _32923);
    }
    _32925 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32926 = (object)*(((s1_ptr)_2)->base + _32925);
    if (IS_ATOM_INT(_32924) && IS_ATOM_INT(_32926)) {
        _67a_64803 = _32924 - _32926;
    }
    else {
        _67a_64803 = binary_op(MINUS, _32924, _32926);
    }
    _32924 = NOVALUE;
    _32926 = NOVALUE;
    if (!IS_ATOM_INT(_67a_64803)) {
        _1 = (object)(DBL_PTR(_67a_64803)->dbl);
        DeRefDS(_67a_64803);
        _67a_64803 = _1;
    }

    /** execute.e:1647			if a > 0 and a <= length( val[Code[pc+3]] ) then*/
    _32928 = (_67a_64803 > 0);
    if (_32928 == 0) {
        goto L2; // [73] 148
    }
    _32930 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32931 = (object)*(((s1_ptr)_2)->base + _32930);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_32931)){
        _32932 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32931)->dbl));
    }
    else{
        _32932 = (object)*(((s1_ptr)_2)->base + _32931);
    }
    if (IS_SEQUENCE(_32932)){
            _32933 = SEQ_PTR(_32932)->length;
    }
    else {
        _32933 = 1;
    }
    _32932 = NOVALUE;
    _32934 = (_67a_64803 <= _32933);
    _32933 = NOVALUE;
    if (_32934 == 0)
    {
        DeRef(_32934);
        _32934 = NOVALUE;
        goto L2; // [105] 148
    }
    else{
        DeRef(_32934);
        _32934 = NOVALUE;
    }

    /** execute.e:1648				pc += val[Code[pc+3]][a]*/
    _32935 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32936 = (object)*(((s1_ptr)_2)->base + _32935);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_32936)){
        _32937 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32936)->dbl));
    }
    else{
        _32937 = (object)*(((s1_ptr)_2)->base + _32936);
    }
    _2 = (object)SEQ_PTR(_32937);
    _32938 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _32937 = NOVALUE;
    if (IS_ATOM_INT(_32938)) {
        _67pc_64802 = _67pc_64802 + _32938;
    }
    else {
        _67pc_64802 = binary_op(PLUS, _67pc_64802, _32938);
    }
    _32938 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_64802)) {
        _1 = (object)(DBL_PTR(_67pc_64802)->dbl);
        DeRefDS(_67pc_64802);
        _67pc_64802 = _1;
    }

    /** execute.e:1649				return*/
    DeRef(_32928);
    _32928 = NOVALUE;
    _32923 = NOVALUE;
    _32919 = NOVALUE;
    _32936 = NOVALUE;
    DeRef(_32930);
    _32930 = NOVALUE;
    DeRef(_32922);
    _32922 = NOVALUE;
    DeRef(_32925);
    _32925 = NOVALUE;
    _32932 = NOVALUE;
    _32931 = NOVALUE;
    DeRef(_32918);
    _32918 = NOVALUE;
    _32935 = NOVALUE;
    return;
L2: 
L1: 

    /** execute.e:1652		pc = Code[pc+4]*/
    _32940 = _67pc_64802 + 4;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _32940);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }

    /** execute.e:1653	end procedure*/
    DeRef(_32928);
    _32928 = NOVALUE;
    _32923 = NOVALUE;
    _32919 = NOVALUE;
    _32936 = NOVALUE;
    _32940 = NOVALUE;
    DeRef(_32930);
    _32930 = NOVALUE;
    DeRef(_32922);
    _32922 = NOVALUE;
    DeRef(_32925);
    _32925 = NOVALUE;
    _32932 = NOVALUE;
    _32931 = NOVALUE;
    DeRef(_32918);
    _32918 = NOVALUE;
    DeRef(_32935);
    _32935 = NOVALUE;
    return;
    ;
}


void _67opSWITCH()
{
    object _32954 = NOVALUE;
    object _32952 = NOVALUE;
    object _32951 = NOVALUE;
    object _32950 = NOVALUE;
    object _32949 = NOVALUE;
    object _32947 = NOVALUE;
    object _32946 = NOVALUE;
    object _32945 = NOVALUE;
    object _32944 = NOVALUE;
    object _32943 = NOVALUE;
    object _32942 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1660		a = find( val[Code[pc+1]], val[Code[pc+2]] )*/
    _32942 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32943 = (object)*(((s1_ptr)_2)->base + _32942);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_32943)){
        _32944 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32943)->dbl));
    }
    else{
        _32944 = (object)*(((s1_ptr)_2)->base + _32943);
    }
    _32945 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32946 = (object)*(((s1_ptr)_2)->base + _32945);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_32946)){
        _32947 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32946)->dbl));
    }
    else{
        _32947 = (object)*(((s1_ptr)_2)->base + _32946);
    }
    _67a_64803 = find_from(_32944, _32947, 1);
    _32944 = NOVALUE;
    _32947 = NOVALUE;

    /** execute.e:1661		if a then*/
    if (_67a_64803 == 0)
    {
        goto L1; // [48] 88
    }
    else{
    }

    /** execute.e:1662			pc += val[Code[pc+3]][a]*/
    _32949 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32950 = (object)*(((s1_ptr)_2)->base + _32949);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_32950)){
        _32951 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32950)->dbl));
    }
    else{
        _32951 = (object)*(((s1_ptr)_2)->base + _32950);
    }
    _2 = (object)SEQ_PTR(_32951);
    _32952 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _32951 = NOVALUE;
    if (IS_ATOM_INT(_32952)) {
        _67pc_64802 = _67pc_64802 + _32952;
    }
    else {
        _67pc_64802 = binary_op(PLUS, _67pc_64802, _32952);
    }
    _32952 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_64802)) {
        _1 = (object)(DBL_PTR(_67pc_64802)->dbl);
        DeRefDS(_67pc_64802);
        _67pc_64802 = _1;
    }
    goto L2; // [85] 105
L1: 

    /** execute.e:1664			pc = Code[pc + 4]*/
    _32954 = _67pc_64802 + 4;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _32954);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }
L2: 

    /** execute.e:1666	end procedure*/
    DeRef(_32945);
    _32945 = NOVALUE;
    DeRef(_32954);
    _32954 = NOVALUE;
    _32946 = NOVALUE;
    DeRef(_32942);
    _32942 = NOVALUE;
    _32943 = NOVALUE;
    DeRef(_32949);
    _32949 = NOVALUE;
    _32950 = NOVALUE;
    return;
    ;
}


void _67opSWITCH_RT()
{
    object _values_66845 = NOVALUE;
    object _all_ints_66850 = NOVALUE;
    object _max_66851 = NOVALUE;
    object _min_66853 = NOVALUE;
    object _sym_66858 = NOVALUE;
    object _sign_66860 = NOVALUE;
    object _new_value_66875 = NOVALUE;
    object _jump_66892 = NOVALUE;
    object _switch_table_66897 = NOVALUE;
    object _offset_66905 = NOVALUE;
    object _33006 = NOVALUE;
    object _33005 = NOVALUE;
    object _33004 = NOVALUE;
    object _33003 = NOVALUE;
    object _33002 = NOVALUE;
    object _32999 = NOVALUE;
    object _32998 = NOVALUE;
    object _32997 = NOVALUE;
    object _32996 = NOVALUE;
    object _32995 = NOVALUE;
    object _32993 = NOVALUE;
    object _32992 = NOVALUE;
    object _32991 = NOVALUE;
    object _32990 = NOVALUE;
    object _32989 = NOVALUE;
    object _32986 = NOVALUE;
    object _32985 = NOVALUE;
    object _32984 = NOVALUE;
    object _32983 = NOVALUE;
    object _32982 = NOVALUE;
    object _32980 = NOVALUE;
    object _32979 = NOVALUE;
    object _32978 = NOVALUE;
    object _32977 = NOVALUE;
    object _32976 = NOVALUE;
    object _32972 = NOVALUE;
    object _32970 = NOVALUE;
    object _32969 = NOVALUE;
    object _32968 = NOVALUE;
    object _32967 = NOVALUE;
    object _32966 = NOVALUE;
    object _32964 = NOVALUE;
    object _32963 = NOVALUE;
    object _32959 = NOVALUE;
    object _32957 = NOVALUE;
    object _32956 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1677		sequence values = val[Code[pc+2]]*/
    _32956 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32957 = (object)*(((s1_ptr)_2)->base + _32956);
    DeRef(_values_66845);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_32957)){
        _values_66845 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32957)->dbl));
    }
    else{
        _values_66845 = (object)*(((s1_ptr)_2)->base + _32957);
    }
    Ref(_values_66845);

    /** execute.e:1678		integer all_ints = 1*/
    _all_ints_66850 = 1;

    /** execute.e:1679		integer max = MININT*/
    _max_66851 = -1073741824;

    /** execute.e:1680		integer min = MAXINT*/
    _min_66853 = 1073741823;

    /** execute.e:1681		for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_66845)){
            _32959 = SEQ_PTR(_values_66845)->length;
    }
    else {
        _32959 = 1;
    }
    {
        object _i_66856;
        _i_66856 = 1;
L1: 
        if (_i_66856 > _32959){
            goto L2; // [51] 209
        }

        /** execute.e:1682			integer sym = values[i]*/
        _2 = (object)SEQ_PTR(_values_66845);
        _sym_66858 = (object)*(((s1_ptr)_2)->base + _i_66856);
        if (!IS_ATOM_INT(_sym_66858))
        _sym_66858 = (object)DBL_PTR(_sym_66858)->dbl;

        /** execute.e:1683			integer sign = 1*/
        _sign_66860 = 1;

        /** execute.e:1684			if sym < 0 then*/
        if (_sym_66858 >= 0)
        goto L3; // [71] 88

        /** execute.e:1685				sign = -1*/
        _sign_66860 = -1;

        /** execute.e:1686				sym = -sym*/
        _sym_66858 = - _sym_66858;
L3: 

        /** execute.e:1688			if equal(val[sym], NOVALUE) then*/
        _2 = (object)SEQ_PTR(_67val_64812);
        _32963 = (object)*(((s1_ptr)_2)->base + _sym_66858);
        if (_32963 == _12NOVALUE_20081)
        _32964 = 1;
        else if (IS_ATOM_INT(_32963) && IS_ATOM_INT(_12NOVALUE_20081))
        _32964 = 0;
        else
        _32964 = (compare(_32963, _12NOVALUE_20081) == 0);
        _32963 = NOVALUE;
        if (_32964 == 0)
        {
            _32964 = NOVALUE;
            goto L4; // [102] 131
        }
        else{
            _32964 = NOVALUE;
        }

        /** execute.e:1689				RTFatal( sprintf( "'%s' has not been assigned a value", {SymTab[sym][S_NAME]} ) )*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _32966 = (object)*(((s1_ptr)_2)->base + _sym_66858);
        _2 = (object)SEQ_PTR(_32966);
        if (!IS_ATOM_INT(_12S_NAME_19864)){
            _32967 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
        }
        else{
            _32967 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
        }
        _32966 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_32967);
        ((intptr_t*)_2)[1] = _32967;
        _32968 = MAKE_SEQ(_1);
        _32967 = NOVALUE;
        _32969 = EPrintf(-9999999, _32965, _32968);
        DeRefDS(_32968);
        _32968 = NOVALUE;
        _67RTFatal(_32969);
        _32969 = NOVALUE;
L4: 

        /** execute.e:1691			object new_value = sign * val[sym]*/
        _2 = (object)SEQ_PTR(_67val_64812);
        _32970 = (object)*(((s1_ptr)_2)->base + _sym_66858);
        DeRef(_new_value_66875);
        if (IS_ATOM_INT(_32970)) {
            if (_sign_66860 == (short)_sign_66860 && _32970 <= INT15 && _32970 >= -INT15){
                _new_value_66875 = _sign_66860 * _32970;
            }
            else{
                _new_value_66875 = NewDouble(_sign_66860 * (eudouble)_32970);
            }
        }
        else {
            _new_value_66875 = binary_op(MULTIPLY, _sign_66860, _32970);
        }
        _32970 = NOVALUE;

        /** execute.e:1692			values[i] = new_value*/
        Ref(_new_value_66875);
        _2 = (object)SEQ_PTR(_values_66845);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _values_66845 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_66856);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _new_value_66875;
        DeRef(_1);

        /** execute.e:1693			if not integer( new_value ) then*/
        if (IS_ATOM_INT(_new_value_66875))
        _32972 = 1;
        else if (IS_ATOM_DBL(_new_value_66875))
        _32972 = IS_ATOM_INT(DoubleToInt(_new_value_66875));
        else
        _32972 = 0;
        if (_32972 != 0)
        goto L5; // [154] 165
        _32972 = NOVALUE;

        /** execute.e:1694				all_ints = 0*/
        _all_ints_66850 = 0;
        goto L6; // [162] 200
L5: 

        /** execute.e:1696			elsif all_ints then*/
        if (_all_ints_66850 == 0)
        {
            goto L7; // [167] 199
        }
        else{
        }

        /** execute.e:1697				if new_value < min then*/
        if (binary_op_a(GREATEREQ, _new_value_66875, _min_66853)){
            goto L8; // [172] 184
        }

        /** execute.e:1698					min = new_value*/
        Ref(_new_value_66875);
        _min_66853 = _new_value_66875;
        if (!IS_ATOM_INT(_min_66853)) {
            _1 = (object)(DBL_PTR(_min_66853)->dbl);
            DeRefDS(_min_66853);
            _min_66853 = _1;
        }
L8: 

        /** execute.e:1701				if new_value > max then*/
        if (binary_op_a(LESSEQ, _new_value_66875, _max_66851)){
            goto L9; // [186] 198
        }

        /** execute.e:1702					max = new_value*/
        Ref(_new_value_66875);
        _max_66851 = _new_value_66875;
        if (!IS_ATOM_INT(_max_66851)) {
            _1 = (object)(DBL_PTR(_max_66851)->dbl);
            DeRefDS(_max_66851);
            _max_66851 = _1;
        }
L9: 
L7: 
L6: 
        DeRef(_new_value_66875);
        _new_value_66875 = NOVALUE;

        /** execute.e:1705		end for*/
        _i_66856 = _i_66856 + 1;
        goto L1; // [204] 58
L2: 
        ;
    }

    /** execute.e:1707		if all_ints and max - min < 1024 then*/
    if (_all_ints_66850 == 0) {
        goto LA; // [211] 412
    }
    _32977 = _max_66851 - _min_66853;
    if ((object)((uintptr_t)_32977 +(uintptr_t) HIGH_BITS) >= 0){
        _32977 = NewDouble((eudouble)_32977);
    }
    if (IS_ATOM_INT(_32977)) {
        _32978 = (_32977 < 1024);
    }
    else {
        _32978 = (DBL_PTR(_32977)->dbl < (eudouble)1024);
    }
    DeRef(_32977);
    _32977 = NOVALUE;
    if (_32978 == 0)
    {
        DeRef(_32978);
        _32978 = NOVALUE;
        goto LA; // [224] 412
    }
    else{
        DeRef(_32978);
        _32978 = NOVALUE;
    }

    /** execute.e:1708			Code[pc] = SWITCH_SPI*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67pc_64802);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 192;
    DeRef(_1);

    /** execute.e:1710			sequence jump = val[Code[pc+3]]*/
    _32979 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32980 = (object)*(((s1_ptr)_2)->base + _32979);
    DeRef(_jump_66892);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_32980)){
        _jump_66892 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32980)->dbl));
    }
    else{
        _jump_66892 = (object)*(((s1_ptr)_2)->base + _32980);
    }
    Ref(_jump_66892);

    /** execute.e:1711			sequence switch_table = repeat( Code[pc+4] - pc, max - min + 1 )*/
    _32982 = _67pc_64802 + 4;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32983 = (object)*(((s1_ptr)_2)->base + _32982);
    if (IS_ATOM_INT(_32983)) {
        _32984 = _32983 - _67pc_64802;
        if ((object)((uintptr_t)_32984 +(uintptr_t) HIGH_BITS) >= 0){
            _32984 = NewDouble((eudouble)_32984);
        }
    }
    else {
        _32984 = binary_op(MINUS, _32983, _67pc_64802);
    }
    _32983 = NOVALUE;
    _32985 = _max_66851 - _min_66853;
    if ((object)((uintptr_t)_32985 +(uintptr_t) HIGH_BITS) >= 0){
        _32985 = NewDouble((eudouble)_32985);
    }
    if (IS_ATOM_INT(_32985)) {
        _32986 = _32985 + 1;
    }
    else
    _32986 = binary_op(PLUS, 1, _32985);
    DeRef(_32985);
    _32985 = NOVALUE;
    DeRef(_switch_table_66897);
    _switch_table_66897 = Repeat(_32984, _32986);
    DeRef(_32984);
    _32984 = NOVALUE;
    DeRef(_32986);
    _32986 = NOVALUE;

    /** execute.e:1712			integer offset = min - 1*/
    _offset_66905 = _min_66853 - 1;

    /** execute.e:1713			for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_66845)){
            _32989 = SEQ_PTR(_values_66845)->length;
    }
    else {
        _32989 = 1;
    }
    {
        object _i_66908;
        _i_66908 = 1;
LB: 
        if (_i_66908 > _32989){
            goto LC; // [304] 336
        }

        /** execute.e:1714				switch_table[values[i] - offset] = jump[i]*/
        _2 = (object)SEQ_PTR(_values_66845);
        _32990 = (object)*(((s1_ptr)_2)->base + _i_66908);
        if (IS_ATOM_INT(_32990)) {
            _32991 = _32990 - _offset_66905;
            if ((object)((uintptr_t)_32991 +(uintptr_t) HIGH_BITS) >= 0){
                _32991 = NewDouble((eudouble)_32991);
            }
        }
        else {
            _32991 = binary_op(MINUS, _32990, _offset_66905);
        }
        _32990 = NOVALUE;
        _2 = (object)SEQ_PTR(_jump_66892);
        _32992 = (object)*(((s1_ptr)_2)->base + _i_66908);
        Ref(_32992);
        _2 = (object)SEQ_PTR(_switch_table_66897);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _switch_table_66897 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_32991))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_32991)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _32991);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32992;
        if( _1 != _32992 ){
            DeRef(_1);
        }
        _32992 = NOVALUE;

        /** execute.e:1715			end for*/
        _i_66908 = _i_66908 + 1;
        goto LB; // [331] 311
LC: 
        ;
    }

    /** execute.e:1716			Code[pc+2] = offset*/
    _32993 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _32993);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _offset_66905;
    DeRef(_1);

    /** execute.e:1718			val = append( val, switch_table )*/
    RefDS(_switch_table_66897);
    Append(&_67val_64812, _67val_64812, _switch_table_66897);

    /** execute.e:1719			Code[pc+3] = length(val)*/
    _32995 = _67pc_64802 + 3;
    if ((object)((uintptr_t)_32995 + (uintptr_t)HIGH_BITS) >= 0){
        _32995 = NewDouble((eudouble)_32995);
    }
    if (IS_SEQUENCE(_67val_64812)){
            _32996 = SEQ_PTR(_67val_64812)->length;
    }
    else {
        _32996 = 1;
    }
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32995))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_32995)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _32995);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32996;
    if( _1 != _32996 ){
        DeRef(_1);
    }
    _32996 = NOVALUE;

    /** execute.e:1721			SymTab[call_stack[$]][S_CODE] = Code*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _32997 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _32997 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_64820);
    _32998 = (object)*(((s1_ptr)_2)->base + _32997);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32998))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_32998)->dbl));
    else
    _3 = (object)(_32998 + ((s1_ptr)_2)->base);
    RefDS(_12Code_20315);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12Code_20315;
    DeRef(_1);
    _32999 = NOVALUE;

    /** execute.e:1722			opSWITCH_SPI()*/
    _67opSWITCH_SPI();
    DeRef(_jump_66892);
    _jump_66892 = NOVALUE;
    DeRefDS(_switch_table_66897);
    _switch_table_66897 = NOVALUE;
    goto LD; // [409] 482
LA: 

    /** execute.e:1724			Code[pc] = SWITCH*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67pc_64802);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 185;
    DeRef(_1);

    /** execute.e:1725			val = append( val, values )*/
    RefDS(_values_66845);
    Append(&_67val_64812, _67val_64812, _values_66845);

    /** execute.e:1726			Code[pc+2] = length(val)*/
    _33002 = _67pc_64802 + 2;
    if ((object)((uintptr_t)_33002 + (uintptr_t)HIGH_BITS) >= 0){
        _33002 = NewDouble((eudouble)_33002);
    }
    if (IS_SEQUENCE(_67val_64812)){
            _33003 = SEQ_PTR(_67val_64812)->length;
    }
    else {
        _33003 = 1;
    }
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33002))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33002)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33002);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33003;
    if( _1 != _33003 ){
        DeRef(_1);
    }
    _33003 = NOVALUE;

    /** execute.e:1728			SymTab[call_stack[$]][S_CODE] = Code*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _33004 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _33004 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_64820);
    _33005 = (object)*(((s1_ptr)_2)->base + _33004);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33005))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33005)->dbl));
    else
    _3 = (object)(_33005 + ((s1_ptr)_2)->base);
    RefDS(_12Code_20315);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12Code_20315;
    DeRef(_1);
    _33006 = NOVALUE;

    /** execute.e:1729			opSWITCH()*/
    _67opSWITCH();
LD: 

    /** execute.e:1732	end procedure*/
    DeRef(_values_66845);
    DeRef(_32993);
    _32993 = NOVALUE;
    DeRef(_32982);
    _32982 = NOVALUE;
    DeRef(_33002);
    _33002 = NOVALUE;
    _32998 = NOVALUE;
    DeRef(_32991);
    _32991 = NOVALUE;
    _32957 = NOVALUE;
    DeRef(_32995);
    _32995 = NOVALUE;
    DeRef(_32956);
    _32956 = NOVALUE;
    DeRef(_32979);
    _32979 = NOVALUE;
    _32980 = NOVALUE;
    _33005 = NOVALUE;
    return;
    ;
}


void _67opCASE()
{
    object _0, _1, _2;
    

    /** execute.e:1736	end procedure*/
    return;
    ;
}


void _67opNOPSWITCH()
{
    object _0, _1, _2;
    

    /** execute.e:1740	end procedure*/
    return;
    ;
}


object _67var_subs(object _x_66946, object _subs_66947)
{
    object _si_66948 = NOVALUE;
    object _33021 = NOVALUE;
    object _33020 = NOVALUE;
    object _33019 = NOVALUE;
    object _33018 = NOVALUE;
    object _33017 = NOVALUE;
    object _33015 = NOVALUE;
    object _33014 = NOVALUE;
    object _33011 = NOVALUE;
    object _33009 = NOVALUE;
    object _33008 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1746		if atom(x) then*/
    _33008 = IS_ATOM(_x_66946);
    if (_33008 == 0)
    {
        _33008 = NOVALUE;
        goto L1; // [8] 17
    }
    else{
        _33008 = NOVALUE;
    }

    /** execute.e:1747			RTFatal("attempt to subscript an atom\n(reading from it)")*/
    RefDS(_32799);
    _67RTFatal(_32799);
L1: 

    /** execute.e:1749		for i = 1 to length(subs) do*/
    if (IS_SEQUENCE(_subs_66947)){
            _33009 = SEQ_PTR(_subs_66947)->length;
    }
    else {
        _33009 = 1;
    }
    {
        object _i_66952;
        _i_66952 = 1;
L2: 
        if (_i_66952 > _33009){
            goto L3; // [22] 110
        }

        /** execute.e:1750			si = subs[i]*/
        DeRef(_si_66948);
        _2 = (object)SEQ_PTR(_subs_66947);
        _si_66948 = (object)*(((s1_ptr)_2)->base + _i_66952);
        Ref(_si_66948);

        /** execute.e:1751			if sequence(si) then*/
        _33011 = IS_SEQUENCE(_si_66948);
        if (_33011 == 0)
        {
            _33011 = NOVALUE;
            goto L4; // [40] 49
        }
        else{
            _33011 = NOVALUE;
        }

        /** execute.e:1752				RTFatal("A subscript must be an atom")*/
        RefDS(_33012);
        _67RTFatal(_33012);
L4: 

        /** execute.e:1754			si = floor(si)*/
        _0 = _si_66948;
        if (IS_ATOM_INT(_si_66948))
        _si_66948 = e_floor(_si_66948);
        else
        _si_66948 = unary_op(FLOOR, _si_66948);
        DeRef(_0);

        /** execute.e:1755			if si > length(x) or si < 1 then*/
        if (IS_SEQUENCE(_x_66946)){
                _33014 = SEQ_PTR(_x_66946)->length;
        }
        else {
            _33014 = 1;
        }
        if (IS_ATOM_INT(_si_66948)) {
            _33015 = (_si_66948 > _33014);
        }
        else {
            _33015 = binary_op(GREATER, _si_66948, _33014);
        }
        _33014 = NOVALUE;
        if (IS_ATOM_INT(_33015)) {
            if (_33015 != 0) {
                goto L5; // [63] 76
            }
        }
        else {
            if (DBL_PTR(_33015)->dbl != 0.0) {
                goto L5; // [63] 76
            }
        }
        if (IS_ATOM_INT(_si_66948)) {
            _33017 = (_si_66948 < 1);
        }
        else {
            _33017 = binary_op(LESS, _si_66948, 1);
        }
        if (_33017 == 0) {
            DeRef(_33017);
            _33017 = NOVALUE;
            goto L6; // [72] 93
        }
        else {
            if (!IS_ATOM_INT(_33017) && DBL_PTR(_33017)->dbl == 0.0){
                DeRef(_33017);
                _33017 = NOVALUE;
                goto L6; // [72] 93
            }
            DeRef(_33017);
            _33017 = NOVALUE;
        }
        DeRef(_33017);
        _33017 = NOVALUE;
L5: 

        /** execute.e:1756				RTFatal(*/
        if (IS_SEQUENCE(_x_66946)){
                _33018 = SEQ_PTR(_x_66946)->length;
        }
        else {
            _33018 = 1;
        }
        Ref(_si_66948);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _si_66948;
        ((intptr_t *)_2)[2] = _33018;
        _33019 = MAKE_SEQ(_1);
        _33018 = NOVALUE;
        _33020 = EPrintf(-9999999, _32807, _33019);
        DeRefDS(_33019);
        _33019 = NOVALUE;
        _67RTFatal(_33020);
        _33020 = NOVALUE;
L6: 

        /** execute.e:1760			x = x[subs[i]]*/
        _2 = (object)SEQ_PTR(_subs_66947);
        _33021 = (object)*(((s1_ptr)_2)->base + _i_66952);
        _0 = _x_66946;
        _2 = (object)SEQ_PTR(_x_66946);
        if (!IS_ATOM_INT(_33021)){
            _x_66946 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33021)->dbl));
        }
        else{
            _x_66946 = (object)*(((s1_ptr)_2)->base + _33021);
        }
        Ref(_x_66946);
        DeRef(_0);

        /** execute.e:1761		end for*/
        _i_66952 = _i_66952 + 1;
        goto L2; // [105] 29
L3: 
        ;
    }

    /** execute.e:1762		return x*/
    DeRefDS(_subs_66947);
    DeRef(_si_66948);
    _33021 = NOVALUE;
    DeRef(_33015);
    _33015 = NOVALUE;
    return _x_66946;
    ;
}


void _67opLENGTH()
{
    object _33028 = NOVALUE;
    object _33027 = NOVALUE;
    object _33025 = NOVALUE;
    object _33023 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1767		a = Code[pc+1]*/
    _33023 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33023);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1768		target = Code[pc+2]*/
    _33025 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33025);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:1769		val[target] = length(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33027 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_SEQUENCE(_33027)){
            _33028 = SEQ_PTR(_33027)->length;
    }
    else {
        _33028 = 1;
    }
    _33027 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33028;
    if( _1 != _33028 ){
        DeRef(_1);
    }
    _33028 = NOVALUE;

    /** execute.e:1770		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:1771	end procedure*/
    _33027 = NOVALUE;
    _33023 = NOVALUE;
    _33025 = NOVALUE;
    return;
    ;
}


void _67opPLENGTH()
{
    object _33041 = NOVALUE;
    object _33040 = NOVALUE;
    object _33039 = NOVALUE;
    object _33037 = NOVALUE;
    object _33036 = NOVALUE;
    object _33034 = NOVALUE;
    object _33032 = NOVALUE;
    object _33030 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1780		a = Code[pc+1]*/
    _33030 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33030);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1781		target = Code[pc+2]*/
    _33032 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33032);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:1782		lhs_seq_index = val[a][1]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33034 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_33034);
    _67lhs_seq_index_64810 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_64810)){
        _67lhs_seq_index_64810 = (object)DBL_PTR(_67lhs_seq_index_64810)->dbl;
    }
    _33034 = NOVALUE;

    /** execute.e:1783		lhs_subs = val[a][2..$]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33036 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_SEQUENCE(_33036)){
            _33037 = SEQ_PTR(_33036)->length;
    }
    else {
        _33037 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_64811;
    RHS_Slice(_33036, 2, _33037);
    _33036 = NOVALUE;

    /** execute.e:1784		val[target] = length(var_subs(val[lhs_seq_index], lhs_subs))*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33039 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_64810);
    Ref(_33039);
    RefDS(_67lhs_subs_64811);
    _33040 = _67var_subs(_33039, _67lhs_subs_64811);
    _33039 = NOVALUE;
    if (IS_SEQUENCE(_33040)){
            _33041 = SEQ_PTR(_33040)->length;
    }
    else {
        _33041 = 1;
    }
    DeRef(_33040);
    _33040 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33041;
    if( _1 != _33041 ){
        DeRef(_1);
    }
    _33041 = NOVALUE;

    /** execute.e:1785		lhs_subs = {}*/
    RefDS(_22015);
    DeRefDS(_67lhs_subs_64811);
    _67lhs_subs_64811 = _22015;

    /** execute.e:1786		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:1787	end procedure*/
    _33040 = NOVALUE;
    _33030 = NOVALUE;
    _33032 = NOVALUE;
    return;
    ;
}


void _67opLHS_SUBS()
{
    object _33051 = NOVALUE;
    object _33050 = NOVALUE;
    object _33049 = NOVALUE;
    object _33047 = NOVALUE;
    object _33045 = NOVALUE;
    object _33043 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1792		a = Code[pc+1] -- base var sequence, or a temp that contains*/
    _33043 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33043);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1794		b = Code[pc+2] -- subscript*/
    _33045 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33045);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:1795		target = Code[pc+3] -- temp for storing result*/
    _33047 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33047);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:1798		val[target] = append(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33049 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33050 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    Ref(_33050);
    Append(&_33051, _33049, _33050);
    _33049 = NOVALUE;
    _33050 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33051;
    if( _1 != _33051 ){
        DeRef(_1);
    }
    _33051 = NOVALUE;

    /** execute.e:1799		pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:1800	end procedure*/
    _33043 = NOVALUE;
    _33045 = NOVALUE;
    _33047 = NOVALUE;
    return;
    ;
}


void _67opLHS_SUBS1()
{
    object _33060 = NOVALUE;
    object _33059 = NOVALUE;
    object _33057 = NOVALUE;
    object _33055 = NOVALUE;
    object _33053 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1804		a = Code[pc+1] -- base var sequence, or a temp that contains*/
    _33053 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33053);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1806		b = Code[pc+2] -- subscript*/
    _33055 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33055);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:1807		target = Code[pc+3] -- temp for storing result*/
    _33057 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33057);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:1810		val[target] = {a, val[b]}*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33059 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    Ref(_33059);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _67a_64803;
    ((intptr_t *)_2)[2] = _33059;
    _33060 = MAKE_SEQ(_1);
    _33059 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33060;
    if( _1 != _33060 ){
        DeRef(_1);
    }
    _33060 = NOVALUE;

    /** execute.e:1811		pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:1812	end procedure*/
    _33053 = NOVALUE;
    _33057 = NOVALUE;
    _33055 = NOVALUE;
    return;
    ;
}


void _67opLHS_SUBS1_COPY()
{
    object _33072 = NOVALUE;
    object _33071 = NOVALUE;
    object _33070 = NOVALUE;
    object _33068 = NOVALUE;
    object _33066 = NOVALUE;
    object _33064 = NOVALUE;
    object _33062 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1819		a = Code[pc+1] -- base var sequence*/
    _33062 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33062);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1821		b = Code[pc+2] -- subscript*/
    _33064 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33064);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:1823		target = Code[pc+3] -- temp for storing result*/
    _33066 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33066);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:1825		c = Code[pc+4] -- temp to hold base sequence while it's manipulated*/
    _33068 = _67pc_64802 + 4;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64805 = (object)*(((s1_ptr)_2)->base + _33068);
    if (!IS_ATOM_INT(_67c_64805)){
        _67c_64805 = (object)DBL_PTR(_67c_64805)->dbl;
    }

    /** execute.e:1827		val[c] = val[a]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33070 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    Ref(_33070);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67c_64805);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33070;
    if( _1 != _33070 ){
        DeRef(_1);
    }
    _33070 = NOVALUE;

    /** execute.e:1830		val[target] = {c, val[b]}*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33071 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    Ref(_33071);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _67c_64805;
    ((intptr_t *)_2)[2] = _33071;
    _33072 = MAKE_SEQ(_1);
    _33071 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33072;
    if( _1 != _33072 ){
        DeRef(_1);
    }
    _33072 = NOVALUE;

    /** execute.e:1832		pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:1833	end procedure*/
    _33066 = NOVALUE;
    _33068 = NOVALUE;
    _33064 = NOVALUE;
    _33062 = NOVALUE;
    return;
    ;
}


void _67lhs_check_subs(object _seq_67046, object _subs_67047)
{
    object _33088 = NOVALUE;
    object _33087 = NOVALUE;
    object _33086 = NOVALUE;
    object _33084 = NOVALUE;
    object _33083 = NOVALUE;
    object _33081 = NOVALUE;
    object _33079 = NOVALUE;
    object _33078 = NOVALUE;
    object _33076 = NOVALUE;
    object _33074 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1837		if atom(seq) then*/
    _33074 = IS_ATOM(_seq_67046);
    if (_33074 == 0)
    {
        _33074 = NOVALUE;
        goto L1; // [6] 15
    }
    else{
        _33074 = NOVALUE;
    }

    /** execute.e:1838			RTFatal("attempt to subscript an atom\n(assigning to it)")*/
    RefDS(_33075);
    _67RTFatal(_33075);
L1: 

    /** execute.e:1840		if sequence(subs) then*/
    _33076 = IS_SEQUENCE(_subs_67047);
    if (_33076 == 0)
    {
        _33076 = NOVALUE;
        goto L2; // [20] 36
    }
    else{
        _33076 = NOVALUE;
    }

    /** execute.e:1841			RTFatal(*/
    if (IS_SEQUENCE(_seq_67046)){
            _33078 = SEQ_PTR(_seq_67046)->length;
    }
    else {
        _33078 = 1;
    }
    _33079 = EPrintf(-9999999, _33077, _33078);
    _33078 = NOVALUE;
    _67RTFatal(_33079);
    _33079 = NOVALUE;
L2: 

    /** execute.e:1846		subs = floor(subs)*/
    _0 = _subs_67047;
    if (IS_ATOM_INT(_subs_67047))
    _subs_67047 = e_floor(_subs_67047);
    else
    _subs_67047 = unary_op(FLOOR, _subs_67047);
    DeRef(_0);

    /** execute.e:1847		if subs < 1 or subs > length(seq) then*/
    if (IS_ATOM_INT(_subs_67047)) {
        _33081 = (_subs_67047 < 1);
    }
    else {
        _33081 = binary_op(LESS, _subs_67047, 1);
    }
    if (IS_ATOM_INT(_33081)) {
        if (_33081 != 0) {
            goto L3; // [47] 63
        }
    }
    else {
        if (DBL_PTR(_33081)->dbl != 0.0) {
            goto L3; // [47] 63
        }
    }
    if (IS_SEQUENCE(_seq_67046)){
            _33083 = SEQ_PTR(_seq_67046)->length;
    }
    else {
        _33083 = 1;
    }
    if (IS_ATOM_INT(_subs_67047)) {
        _33084 = (_subs_67047 > _33083);
    }
    else {
        _33084 = binary_op(GREATER, _subs_67047, _33083);
    }
    _33083 = NOVALUE;
    if (_33084 == 0) {
        DeRef(_33084);
        _33084 = NOVALUE;
        goto L4; // [59] 80
    }
    else {
        if (!IS_ATOM_INT(_33084) && DBL_PTR(_33084)->dbl == 0.0){
            DeRef(_33084);
            _33084 = NOVALUE;
            goto L4; // [59] 80
        }
        DeRef(_33084);
        _33084 = NOVALUE;
    }
    DeRef(_33084);
    _33084 = NOVALUE;
L3: 

    /** execute.e:1848			RTFatal(*/
    if (IS_SEQUENCE(_seq_67046)){
            _33086 = SEQ_PTR(_seq_67046)->length;
    }
    else {
        _33086 = 1;
    }
    Ref(_subs_67047);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _subs_67047;
    ((intptr_t *)_2)[2] = _33086;
    _33087 = MAKE_SEQ(_1);
    _33086 = NOVALUE;
    _33088 = EPrintf(-9999999, _33085, _33087);
    DeRefDS(_33087);
    _33087 = NOVALUE;
    _67RTFatal(_33088);
    _33088 = NOVALUE;
L4: 

    /** execute.e:1853	end procedure*/
    DeRef(_seq_67046);
    DeRef(_subs_67047);
    DeRef(_33081);
    _33081 = NOVALUE;
    return;
    ;
}


void _67check_slice(object _seq_67068, object _lower_67069, object _upper_67070)
{
    object _len_67071 = NOVALUE;
    object _33119 = NOVALUE;
    object _33117 = NOVALUE;
    object _33116 = NOVALUE;
    object _33115 = NOVALUE;
    object _33114 = NOVALUE;
    object _33112 = NOVALUE;
    object _33111 = NOVALUE;
    object _33110 = NOVALUE;
    object _33106 = NOVALUE;
    object _33104 = NOVALUE;
    object _33103 = NOVALUE;
    object _33094 = NOVALUE;
    object _33089 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1859		if sequence(lower) then*/
    _33089 = IS_SEQUENCE(_lower_67069);
    if (_33089 == 0)
    {
        _33089 = NOVALUE;
        goto L1; // [6] 15
    }
    else{
        _33089 = NOVALUE;
    }

    /** execute.e:1860			RTFatal("slice lower index is not an atom")*/
    RefDS(_33090);
    _67RTFatal(_33090);
L1: 

    /** execute.e:1862		lower = floor(lower)*/
    _0 = _lower_67069;
    if (IS_ATOM_INT(_lower_67069))
    _lower_67069 = e_floor(_lower_67069);
    else
    _lower_67069 = unary_op(FLOOR, _lower_67069);
    DeRef(_0);

    /** execute.e:1863		if lower < 1 then*/
    if (binary_op_a(GREATEREQ, _lower_67069, 1)){
        goto L2; // [22] 32
    }

    /** execute.e:1864			RTFatal("slice lower index is less than 1")*/
    RefDS(_33093);
    _67RTFatal(_33093);
L2: 

    /** execute.e:1867		if sequence(upper) then*/
    _33094 = IS_SEQUENCE(_upper_67070);
    if (_33094 == 0)
    {
        _33094 = NOVALUE;
        goto L3; // [37] 46
    }
    else{
        _33094 = NOVALUE;
    }

    /** execute.e:1868			RTFatal("slice upper index is not an atom")*/
    RefDS(_33095);
    _67RTFatal(_33095);
L3: 

    /** execute.e:1870		upper = floor(upper)*/
    _0 = _upper_67070;
    if (IS_ATOM_INT(_upper_67070))
    _upper_67070 = e_floor(_upper_67070);
    else
    _upper_67070 = unary_op(FLOOR, _upper_67070);
    DeRef(_0);

    /** execute.e:1871		if upper > #FFFF_FFFF then*/
    if (binary_op_a(LESSEQ, _upper_67070, _33097)){
        goto L4; // [53] 63
    }

    /** execute.e:1872			upper = -2147483645*/
    RefDS(_33100);
    DeRef(_upper_67070);
    _upper_67070 = _33100;
L4: 

    /** execute.e:1874		if upper < 0 then*/
    if (binary_op_a(GREATEREQ, _upper_67070, 0)){
        goto L5; // [65] 79
    }

    /** execute.e:1875			RTFatal(sprintf("slice upper index is less than 0 (%d)", upper ) )*/
    _33103 = EPrintf(-9999999, _33102, _upper_67070);
    _67RTFatal(_33103);
    _33103 = NOVALUE;
L5: 

    /** execute.e:1878		if atom(seq) then*/
    _33104 = IS_ATOM(_seq_67068);
    if (_33104 == 0)
    {
        _33104 = NOVALUE;
        goto L6; // [84] 93
    }
    else{
        _33104 = NOVALUE;
    }

    /** execute.e:1879			RTFatal("attempt to slice an atom")*/
    RefDS(_33105);
    _67RTFatal(_33105);
L6: 

    /** execute.e:1882		len = upper - lower + 1*/
    if (IS_ATOM_INT(_upper_67070) && IS_ATOM_INT(_lower_67069)) {
        _33106 = _upper_67070 - _lower_67069;
        if ((object)((uintptr_t)_33106 +(uintptr_t) HIGH_BITS) >= 0){
            _33106 = NewDouble((eudouble)_33106);
        }
    }
    else {
        _33106 = binary_op(MINUS, _upper_67070, _lower_67069);
    }
    DeRef(_len_67071);
    if (IS_ATOM_INT(_33106)) {
        _len_67071 = _33106 + 1;
        if (_len_67071 > MAXINT){
            _len_67071 = NewDouble((eudouble)_len_67071);
        }
    }
    else
    _len_67071 = binary_op(PLUS, 1, _33106);
    DeRef(_33106);
    _33106 = NOVALUE;

    /** execute.e:1884		if len < 0 then*/
    if (binary_op_a(GREATEREQ, _len_67071, 0)){
        goto L7; // [105] 115
    }

    /** execute.e:1885			RTFatal("slice length is less than 0")*/
    RefDS(_33109);
    _67RTFatal(_33109);
L7: 

    /** execute.e:1888		if lower > length(seq) + 1 or (len > 0 and lower > length(seq)) then*/
    if (IS_SEQUENCE(_seq_67068)){
            _33110 = SEQ_PTR(_seq_67068)->length;
    }
    else {
        _33110 = 1;
    }
    _33111 = _33110 + 1;
    _33110 = NOVALUE;
    if (IS_ATOM_INT(_lower_67069)) {
        _33112 = (_lower_67069 > _33111);
    }
    else {
        _33112 = binary_op(GREATER, _lower_67069, _33111);
    }
    _33111 = NOVALUE;
    if (IS_ATOM_INT(_33112)) {
        if (_33112 != 0) {
            goto L8; // [128] 156
        }
    }
    else {
        if (DBL_PTR(_33112)->dbl != 0.0) {
            goto L8; // [128] 156
        }
    }
    if (IS_ATOM_INT(_len_67071)) {
        _33114 = (_len_67071 > 0);
    }
    else {
        _33114 = (DBL_PTR(_len_67071)->dbl > (eudouble)0);
    }
    if (_33114 == 0) {
        DeRef(_33115);
        _33115 = 0;
        goto L9; // [136] 151
    }
    if (IS_SEQUENCE(_seq_67068)){
            _33116 = SEQ_PTR(_seq_67068)->length;
    }
    else {
        _33116 = 1;
    }
    if (IS_ATOM_INT(_lower_67069)) {
        _33117 = (_lower_67069 > _33116);
    }
    else {
        _33117 = binary_op(GREATER, _lower_67069, _33116);
    }
    _33116 = NOVALUE;
    if (IS_ATOM_INT(_33117))
    _33115 = (_33117 != 0);
    else
    _33115 = DBL_PTR(_33117)->dbl != 0.0;
L9: 
    if (_33115 == 0)
    {
        _33115 = NOVALUE;
        goto LA; // [152] 162
    }
    else{
        _33115 = NOVALUE;
    }
L8: 

    /** execute.e:1889			RTFatal("slice starts past end of sequence")*/
    RefDS(_33118);
    _67RTFatal(_33118);
LA: 

    /** execute.e:1892		if upper > length(seq) then*/
    if (IS_SEQUENCE(_seq_67068)){
            _33119 = SEQ_PTR(_seq_67068)->length;
    }
    else {
        _33119 = 1;
    }
    if (binary_op_a(LESSEQ, _upper_67070, _33119)){
        _33119 = NOVALUE;
        goto LB; // [167] 177
    }
    _33119 = NOVALUE;

    /** execute.e:1893			RTFatal("slice ends past end of sequence")*/
    RefDS(_33121);
    _67RTFatal(_33121);
LB: 

    /** execute.e:1895	end procedure*/
    DeRef(_seq_67068);
    DeRef(_lower_67069);
    DeRef(_upper_67070);
    DeRef(_len_67071);
    DeRef(_33114);
    _33114 = NOVALUE;
    DeRef(_33117);
    _33117 = NOVALUE;
    DeRef(_33112);
    _33112 = NOVALUE;
    return;
    ;
}


void _67lhs_check_slice(object _seq_67116, object _lower_67117, object _upper_67118, object _rhs_67119)
{
    object _len_67120 = NOVALUE;
    object _33129 = NOVALUE;
    object _33128 = NOVALUE;
    object _33127 = NOVALUE;
    object _33126 = NOVALUE;
    object _33124 = NOVALUE;
    object _33123 = NOVALUE;
    object _33122 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1901		check_slice(seq, lower, upper)*/
    Ref(_seq_67116);
    Ref(_lower_67117);
    Ref(_upper_67118);
    _67check_slice(_seq_67116, _lower_67117, _upper_67118);

    /** execute.e:1903		len = floor(upper) - floor(lower) + 1*/
    if (IS_ATOM_INT(_upper_67118))
    _33122 = e_floor(_upper_67118);
    else
    _33122 = unary_op(FLOOR, _upper_67118);
    if (IS_ATOM_INT(_lower_67117))
    _33123 = e_floor(_lower_67117);
    else
    _33123 = unary_op(FLOOR, _lower_67117);
    if (IS_ATOM_INT(_33122) && IS_ATOM_INT(_33123)) {
        _33124 = _33122 - _33123;
        if ((object)((uintptr_t)_33124 +(uintptr_t) HIGH_BITS) >= 0){
            _33124 = NewDouble((eudouble)_33124);
        }
    }
    else {
        _33124 = binary_op(MINUS, _33122, _33123);
    }
    DeRef(_33122);
    _33122 = NOVALUE;
    DeRef(_33123);
    _33123 = NOVALUE;
    DeRef(_len_67120);
    if (IS_ATOM_INT(_33124)) {
        _len_67120 = _33124 + 1;
        if (_len_67120 > MAXINT){
            _len_67120 = NewDouble((eudouble)_len_67120);
        }
    }
    else
    _len_67120 = binary_op(PLUS, 1, _33124);
    DeRef(_33124);
    _33124 = NOVALUE;

    /** execute.e:1905		if sequence(rhs) and length(rhs) != len then*/
    _33126 = IS_SEQUENCE(_rhs_67119);
    if (_33126 == 0) {
        goto L1; // [29] 50
    }
    if (IS_SEQUENCE(_rhs_67119)){
            _33128 = SEQ_PTR(_rhs_67119)->length;
    }
    else {
        _33128 = 1;
    }
    if (IS_ATOM_INT(_len_67120)) {
        _33129 = (_33128 != _len_67120);
    }
    else {
        _33129 = ((eudouble)_33128 != DBL_PTR(_len_67120)->dbl);
    }
    _33128 = NOVALUE;
    if (_33129 == 0)
    {
        DeRef(_33129);
        _33129 = NOVALUE;
        goto L1; // [41] 50
    }
    else{
        DeRef(_33129);
        _33129 = NOVALUE;
    }

    /** execute.e:1906			RTFatal("lengths do not match on assignment to slice")*/
    RefDS(_33130);
    _67RTFatal(_33130);
L1: 

    /** execute.e:1908	end procedure*/
    DeRef(_seq_67116);
    DeRef(_lower_67117);
    DeRef(_upper_67118);
    DeRef(_rhs_67119);
    DeRef(_len_67120);
    return;
    ;
}


object _67var_slice(object _x_67133, object _subs_67134, object _lower_67135, object _upper_67136)
{
    object _33149 = NOVALUE;
    object _33147 = NOVALUE;
    object _33146 = NOVALUE;
    object _33145 = NOVALUE;
    object _33144 = NOVALUE;
    object _33143 = NOVALUE;
    object _33142 = NOVALUE;
    object _33141 = NOVALUE;
    object _33139 = NOVALUE;
    object _33138 = NOVALUE;
    object _33137 = NOVALUE;
    object _33134 = NOVALUE;
    object _33133 = NOVALUE;
    object _33132 = NOVALUE;
    object _33131 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1912		if atom(x) then*/
    _33131 = IS_ATOM(_x_67133);
    if (_33131 == 0)
    {
        _33131 = NOVALUE;
        goto L1; // [8] 17
    }
    else{
        _33131 = NOVALUE;
    }

    /** execute.e:1913			RTFatal("attempt to subscript an atom\n(reading from it)")*/
    RefDS(_32799);
    _67RTFatal(_32799);
L1: 

    /** execute.e:1915		for i = 1 to length(subs) do*/
    if (IS_SEQUENCE(_subs_67134)){
            _33132 = SEQ_PTR(_subs_67134)->length;
    }
    else {
        _33132 = 1;
    }
    {
        object _i_67140;
        _i_67140 = 1;
L2: 
        if (_i_67140 > _33132){
            goto L3; // [22] 122
        }

        /** execute.e:1916			if sequence(subs[i]) then*/
        _2 = (object)SEQ_PTR(_subs_67134);
        _33133 = (object)*(((s1_ptr)_2)->base + _i_67140);
        _33134 = IS_SEQUENCE(_33133);
        _33133 = NOVALUE;
        if (_33134 == 0)
        {
            _33134 = NOVALUE;
            goto L4; // [38] 47
        }
        else{
            _33134 = NOVALUE;
        }

        /** execute.e:1917				RTFatal("subscript must be an atom")*/
        RefDS(_33135);
        _67RTFatal(_33135);
L4: 

        /** execute.e:1919			subs = floor(subs)*/
        _0 = _subs_67134;
        _subs_67134 = unary_op(FLOOR, _subs_67134);
        DeRefDS(_0);

        /** execute.e:1920			if subs[i] > length(x) or subs[i] < 1 then*/
        _2 = (object)SEQ_PTR(_subs_67134);
        _33137 = (object)*(((s1_ptr)_2)->base + _i_67140);
        if (IS_SEQUENCE(_x_67133)){
                _33138 = SEQ_PTR(_x_67133)->length;
        }
        else {
            _33138 = 1;
        }
        if (IS_ATOM_INT(_33137)) {
            _33139 = (_33137 > _33138);
        }
        else {
            _33139 = binary_op(GREATER, _33137, _33138);
        }
        _33137 = NOVALUE;
        _33138 = NOVALUE;
        if (IS_ATOM_INT(_33139)) {
            if (_33139 != 0) {
                goto L5; // [67] 84
            }
        }
        else {
            if (DBL_PTR(_33139)->dbl != 0.0) {
                goto L5; // [67] 84
            }
        }
        _2 = (object)SEQ_PTR(_subs_67134);
        _33141 = (object)*(((s1_ptr)_2)->base + _i_67140);
        if (IS_ATOM_INT(_33141)) {
            _33142 = (_33141 < 1);
        }
        else {
            _33142 = binary_op(LESS, _33141, 1);
        }
        _33141 = NOVALUE;
        if (_33142 == 0) {
            DeRef(_33142);
            _33142 = NOVALUE;
            goto L6; // [80] 105
        }
        else {
            if (!IS_ATOM_INT(_33142) && DBL_PTR(_33142)->dbl == 0.0){
                DeRef(_33142);
                _33142 = NOVALUE;
                goto L6; // [80] 105
            }
            DeRef(_33142);
            _33142 = NOVALUE;
        }
        DeRef(_33142);
        _33142 = NOVALUE;
L5: 

        /** execute.e:1921				RTFatal(*/
        _2 = (object)SEQ_PTR(_subs_67134);
        _33143 = (object)*(((s1_ptr)_2)->base + _i_67140);
        if (IS_SEQUENCE(_x_67133)){
                _33144 = SEQ_PTR(_x_67133)->length;
        }
        else {
            _33144 = 1;
        }
        Ref(_33143);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _33143;
        ((intptr_t *)_2)[2] = _33144;
        _33145 = MAKE_SEQ(_1);
        _33144 = NOVALUE;
        _33143 = NOVALUE;
        _33146 = EPrintf(-9999999, _32807, _33145);
        DeRefDS(_33145);
        _33145 = NOVALUE;
        _67RTFatal(_33146);
        _33146 = NOVALUE;
L6: 

        /** execute.e:1925			x = x[subs[i]]*/
        _2 = (object)SEQ_PTR(_subs_67134);
        _33147 = (object)*(((s1_ptr)_2)->base + _i_67140);
        _0 = _x_67133;
        _2 = (object)SEQ_PTR(_x_67133);
        if (!IS_ATOM_INT(_33147)){
            _x_67133 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33147)->dbl));
        }
        else{
            _x_67133 = (object)*(((s1_ptr)_2)->base + _33147);
        }
        Ref(_x_67133);
        DeRef(_0);

        /** execute.e:1926		end for*/
        _i_67140 = _i_67140 + 1;
        goto L2; // [117] 29
L3: 
        ;
    }

    /** execute.e:1927		check_slice(x, lower, upper)*/
    Ref(_x_67133);
    Ref(_lower_67135);
    Ref(_upper_67136);
    _67check_slice(_x_67133, _lower_67135, _upper_67136);

    /** execute.e:1928		return x[lower..upper]*/
    rhs_slice_target = (object_ptr)&_33149;
    RHS_Slice(_x_67133, _lower_67135, _upper_67136);
    DeRef(_x_67133);
    DeRefDS(_subs_67134);
    DeRef(_lower_67135);
    DeRef(_upper_67136);
    DeRef(_33139);
    _33139 = NOVALUE;
    _33147 = NOVALUE;
    return _33149;
    ;
}


object _67assign_subs(object _x_67163, object _subs_67164, object _rhs_val_67165)
{
    object _33160 = NOVALUE;
    object _33159 = NOVALUE;
    object _33158 = NOVALUE;
    object _33157 = NOVALUE;
    object _33156 = NOVALUE;
    object _33155 = NOVALUE;
    object _33154 = NOVALUE;
    object _33153 = NOVALUE;
    object _33151 = NOVALUE;
    object _33150 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1933		lhs_check_subs(x, subs[1])*/
    _2 = (object)SEQ_PTR(_subs_67164);
    _33150 = (object)*(((s1_ptr)_2)->base + 1);
    RefDS(_x_67163);
    Ref(_33150);
    _67lhs_check_subs(_x_67163, _33150);
    _33150 = NOVALUE;

    /** execute.e:1934		if length(subs) = 1 then*/
    if (IS_SEQUENCE(_subs_67164)){
            _33151 = SEQ_PTR(_subs_67164)->length;
    }
    else {
        _33151 = 1;
    }
    if (_33151 != 1)
    goto L1; // [20] 37

    /** execute.e:1935			x[subs[1]] = rhs_val*/
    _2 = (object)SEQ_PTR(_subs_67164);
    _33153 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_rhs_val_67165);
    _2 = (object)SEQ_PTR(_x_67163);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _x_67163 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33153))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33153)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33153);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _rhs_val_67165;
    DeRef(_1);
    goto L2; // [34] 73
L1: 

    /** execute.e:1937			x[subs[1]] = assign_subs(x[subs[1]], subs[2..$], rhs_val)*/
    _2 = (object)SEQ_PTR(_subs_67164);
    _33154 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_subs_67164);
    _33155 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_x_67163);
    if (!IS_ATOM_INT(_33155)){
        _33156 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33155)->dbl));
    }
    else{
        _33156 = (object)*(((s1_ptr)_2)->base + _33155);
    }
    if (IS_SEQUENCE(_subs_67164)){
            _33157 = SEQ_PTR(_subs_67164)->length;
    }
    else {
        _33157 = 1;
    }
    rhs_slice_target = (object_ptr)&_33158;
    RHS_Slice(_subs_67164, 2, _33157);
    Ref(_rhs_val_67165);
    DeRef(_33159);
    _33159 = _rhs_val_67165;
    Ref(_33156);
    _33160 = _67assign_subs(_33156, _33158, _33159);
    _33156 = NOVALUE;
    _33158 = NOVALUE;
    _33159 = NOVALUE;
    _2 = (object)SEQ_PTR(_x_67163);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _x_67163 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33154))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33154)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33154);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33160;
    if( _1 != _33160 ){
        DeRef(_1);
    }
    _33160 = NOVALUE;
L2: 

    /** execute.e:1939		return x*/
    DeRefDS(_subs_67164);
    DeRef(_rhs_val_67165);
    _33154 = NOVALUE;
    _33155 = NOVALUE;
    _33153 = NOVALUE;
    return _x_67163;
    ;
}


object _67assign_slice(object _x_67181, object _subs_67182, object _lower_67183, object _upper_67184, object _rhs_val_67185)
{
    object _33177 = NOVALUE;
    object _33176 = NOVALUE;
    object _33175 = NOVALUE;
    object _33174 = NOVALUE;
    object _33173 = NOVALUE;
    object _33172 = NOVALUE;
    object _33171 = NOVALUE;
    object _33170 = NOVALUE;
    object _33169 = NOVALUE;
    object _33167 = NOVALUE;
    object _33166 = NOVALUE;
    object _33165 = NOVALUE;
    object _33164 = NOVALUE;
    object _33162 = NOVALUE;
    object _33161 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1946		lhs_check_subs(x, subs[1])*/
    _2 = (object)SEQ_PTR(_subs_67182);
    _33161 = (object)*(((s1_ptr)_2)->base + 1);
    RefDS(_x_67181);
    Ref(_33161);
    _67lhs_check_subs(_x_67181, _33161);
    _33161 = NOVALUE;

    /** execute.e:1947		if length(subs) = 1 then*/
    if (IS_SEQUENCE(_subs_67182)){
            _33162 = SEQ_PTR(_subs_67182)->length;
    }
    else {
        _33162 = 1;
    }
    if (_33162 != 1)
    goto L1; // [20] 59

    /** execute.e:1948			lhs_check_slice(x[subs[1]],lower,upper,rhs_val)*/
    _2 = (object)SEQ_PTR(_subs_67182);
    _33164 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_x_67181);
    if (!IS_ATOM_INT(_33164)){
        _33165 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33164)->dbl));
    }
    else{
        _33165 = (object)*(((s1_ptr)_2)->base + _33164);
    }
    Ref(_33165);
    Ref(_lower_67183);
    Ref(_upper_67184);
    Ref(_rhs_val_67185);
    _67lhs_check_slice(_33165, _lower_67183, _upper_67184, _rhs_val_67185);
    _33165 = NOVALUE;

    /** execute.e:1949			x[subs[1]][lower..upper] = rhs_val*/
    _2 = (object)SEQ_PTR(_subs_67182);
    _33166 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_x_67181);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _x_67181 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33166))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33166)->dbl));
    else
    _3 = (object)(_33166 + ((s1_ptr)_2)->base);
    assign_slice_seq = (s1_ptr *)_3;
    AssignSlice(_lower_67183, _upper_67184, _rhs_val_67185);
    goto L2; // [56] 103
L1: 

    /** execute.e:1951			x[subs[1]] = assign_slice(x[subs[1]], subs[2..$], lower, upper, rhs_val)*/
    _2 = (object)SEQ_PTR(_subs_67182);
    _33169 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_subs_67182);
    _33170 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_x_67181);
    if (!IS_ATOM_INT(_33170)){
        _33171 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33170)->dbl));
    }
    else{
        _33171 = (object)*(((s1_ptr)_2)->base + _33170);
    }
    if (IS_SEQUENCE(_subs_67182)){
            _33172 = SEQ_PTR(_subs_67182)->length;
    }
    else {
        _33172 = 1;
    }
    rhs_slice_target = (object_ptr)&_33173;
    RHS_Slice(_subs_67182, 2, _33172);
    Ref(_lower_67183);
    DeRef(_33174);
    _33174 = _lower_67183;
    Ref(_upper_67184);
    DeRef(_33175);
    _33175 = _upper_67184;
    Ref(_rhs_val_67185);
    DeRef(_33176);
    _33176 = _rhs_val_67185;
    Ref(_33171);
    _33177 = _67assign_slice(_33171, _33173, _33174, _33175, _33176);
    _33171 = NOVALUE;
    _33173 = NOVALUE;
    _33174 = NOVALUE;
    _33175 = NOVALUE;
    _33176 = NOVALUE;
    _2 = (object)SEQ_PTR(_x_67181);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _x_67181 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33169))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33169)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33169);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33177;
    if( _1 != _33177 ){
        DeRef(_1);
    }
    _33177 = NOVALUE;
L2: 

    /** execute.e:1953		return x*/
    DeRefDS(_subs_67182);
    DeRef(_lower_67183);
    DeRef(_upper_67184);
    DeRef(_rhs_val_67185);
    _33164 = NOVALUE;
    _33169 = NOVALUE;
    _33166 = NOVALUE;
    _33170 = NOVALUE;
    DeRef(_33167);
    _33167 = NOVALUE;
    return _x_67181;
    ;
}


void _67opASSIGN_SUBS()
{
    object _x_67207 = NOVALUE;
    object _subs_67208 = NOVALUE;
    object _33191 = NOVALUE;
    object _33188 = NOVALUE;
    object _33185 = NOVALUE;
    object _33183 = NOVALUE;
    object _33182 = NOVALUE;
    object _33180 = NOVALUE;
    object _33178 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1960		a = Code[pc+1]  -- the sequence*/
    _33178 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33178);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1961		b = Code[pc+2]  -- the subscript*/
    _33180 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33180);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:1962		if sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33182 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _33183 = IS_SEQUENCE(_33182);
    _33182 = NOVALUE;
    if (_33183 == 0)
    {
        _33183 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _33183 = NOVALUE;
    }

    /** execute.e:1963			RTFatal("subscript must be an atom\n(assigning to subscript of a sequence)")*/
    RefDS(_33184);
    _67RTFatal(_33184);
L1: 

    /** execute.e:1966		c = Code[pc+3]  -- the RHS value*/
    _33185 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64805 = (object)*(((s1_ptr)_2)->base + _33185);
    if (!IS_ATOM_INT(_67c_64805)){
        _67c_64805 = (object)DBL_PTR(_67c_64805)->dbl;
    }

    /** execute.e:1967		x = val[a] -- avoid lingering ref count on val[a]*/
    DeRef(_x_67207);
    _2 = (object)SEQ_PTR(_67val_64812);
    _x_67207 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    Ref(_x_67207);

    /** execute.e:1968		lhs_check_subs(x, val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33188 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    Ref(_x_67207);
    Ref(_33188);
    _67lhs_check_subs(_x_67207, _33188);
    _33188 = NOVALUE;

    /** execute.e:1969		x = val[c]*/
    DeRef(_x_67207);
    _2 = (object)SEQ_PTR(_67val_64812);
    _x_67207 = (object)*(((s1_ptr)_2)->base + _67c_64805);
    Ref(_x_67207);

    /** execute.e:1970		subs = val[b]*/
    DeRef(_subs_67208);
    _2 = (object)SEQ_PTR(_67val_64812);
    _subs_67208 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    Ref(_subs_67208);

    /** execute.e:1971		val[a][subs] = x  -- single LHS subscript*/
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67a_64803 + ((s1_ptr)_2)->base);
    Ref(_x_67207);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_subs_67208))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_subs_67208)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _subs_67208);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _x_67207;
    DeRef(_1);
    _33191 = NOVALUE;

    /** execute.e:1972		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:1973	end procedure*/
    DeRef(_x_67207);
    DeRef(_subs_67208);
    DeRef(_33180);
    _33180 = NOVALUE;
    _33185 = NOVALUE;
    DeRef(_33178);
    _33178 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_SUBS()
{
    object _33211 = NOVALUE;
    object _33210 = NOVALUE;
    object _33209 = NOVALUE;
    object _33208 = NOVALUE;
    object _33207 = NOVALUE;
    object _33205 = NOVALUE;
    object _33204 = NOVALUE;
    object _33202 = NOVALUE;
    object _33200 = NOVALUE;
    object _33199 = NOVALUE;
    object _33198 = NOVALUE;
    object _33196 = NOVALUE;
    object _33194 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1978		a = Code[pc+1]*/
    _33194 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33194);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:1979		b = Code[pc+2]  -- subscript*/
    _33196 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33196);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:1980		if sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33198 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _33199 = IS_SEQUENCE(_33198);
    _33198 = NOVALUE;
    if (_33199 == 0)
    {
        _33199 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _33199 = NOVALUE;
    }

    /** execute.e:1981			RTFatal("subscript must be an atom\n(assigning to subscript of a sequence)")*/
    RefDS(_33184);
    _67RTFatal(_33184);
L1: 

    /** execute.e:1983		c = Code[pc+3]  -- RHS value*/
    _33200 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64805 = (object)*(((s1_ptr)_2)->base + _33200);
    if (!IS_ATOM_INT(_67c_64805)){
        _67c_64805 = (object)DBL_PTR(_67c_64805)->dbl;
    }

    /** execute.e:1986		lhs_seq_index = val[a][1]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33202 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_33202);
    _67lhs_seq_index_64810 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_64810)){
        _67lhs_seq_index_64810 = (object)DBL_PTR(_67lhs_seq_index_64810)->dbl;
    }
    _33202 = NOVALUE;

    /** execute.e:1987		lhs_subs = val[a][2..$]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33204 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_SEQUENCE(_33204)){
            _33205 = SEQ_PTR(_33204)->length;
    }
    else {
        _33205 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_64811;
    RHS_Slice(_33204, 2, _33205);
    _33204 = NOVALUE;

    /** execute.e:1988		val[lhs_seq_index] = assign_subs(val[lhs_seq_index],*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33207 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_64810);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33208 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_SEQUENCE(_67lhs_subs_64811) && IS_ATOM(_33208)) {
        Ref(_33208);
        Append(&_33209, _67lhs_subs_64811, _33208);
    }
    else if (IS_ATOM(_67lhs_subs_64811) && IS_SEQUENCE(_33208)) {
    }
    else {
        Concat((object_ptr)&_33209, _67lhs_subs_64811, _33208);
    }
    _33208 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    _33210 = (object)*(((s1_ptr)_2)->base + _67c_64805);
    Ref(_33207);
    Ref(_33210);
    _33211 = _67assign_subs(_33207, _33209, _33210);
    _33207 = NOVALUE;
    _33209 = NOVALUE;
    _33210 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67lhs_seq_index_64810);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33211;
    if( _1 != _33211 ){
        DeRef(_1);
    }
    _33211 = NOVALUE;

    /** execute.e:1991		lhs_subs = {}*/
    RefDS(_22015);
    DeRefDS(_67lhs_subs_64811);
    _67lhs_subs_64811 = _22015;

    /** execute.e:1992		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:1993	end procedure*/
    DeRef(_33196);
    _33196 = NOVALUE;
    _33200 = NOVALUE;
    DeRef(_33194);
    _33194 = NOVALUE;
    return;
    ;
}


void _67opASSIGN_OP_SUBS()
{
    object _x_67256 = NOVALUE;
    object _33222 = NOVALUE;
    object _33221 = NOVALUE;
    object _33220 = NOVALUE;
    object _33217 = NOVALUE;
    object _33215 = NOVALUE;
    object _33213 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1999		a = Code[pc+1]*/
    _33213 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33213);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2000		b = Code[pc+2]*/
    _33215 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33215);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2001		target = Code[pc+3]*/
    _33217 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33217);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2003		lhs_subs = {}*/
    RefDS(_22015);
    DeRef(_67lhs_subs_64811);
    _67lhs_subs_64811 = _22015;

    /** execute.e:2004		x = val[a]*/
    DeRef(_x_67256);
    _2 = (object)SEQ_PTR(_67val_64812);
    _x_67256 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    Ref(_x_67256);

    /** execute.e:2005		val[target] = var_subs(x, lhs_subs & val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33220 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_SEQUENCE(_67lhs_subs_64811) && IS_ATOM(_33220)) {
        Ref(_33220);
        Append(&_33221, _67lhs_subs_64811, _33220);
    }
    else if (IS_ATOM(_67lhs_subs_64811) && IS_SEQUENCE(_33220)) {
    }
    else {
        Concat((object_ptr)&_33221, _67lhs_subs_64811, _33220);
    }
    _33220 = NOVALUE;
    Ref(_x_67256);
    _33222 = _67var_subs(_x_67256, _33221);
    _33221 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33222;
    if( _1 != _33222 ){
        DeRef(_1);
    }
    _33222 = NOVALUE;

    /** execute.e:2006		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2007	end procedure*/
    DeRef(_x_67256);
    _33217 = NOVALUE;
    _33213 = NOVALUE;
    _33215 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_OP_SUBS()
{
    object _33241 = NOVALUE;
    object _33240 = NOVALUE;
    object _33239 = NOVALUE;
    object _33238 = NOVALUE;
    object _33237 = NOVALUE;
    object _33236 = NOVALUE;
    object _33235 = NOVALUE;
    object _33233 = NOVALUE;
    object _33232 = NOVALUE;
    object _33230 = NOVALUE;
    object _33228 = NOVALUE;
    object _33226 = NOVALUE;
    object _33224 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2011		a = Code[pc+1]*/
    _33224 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33224);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2012		b = Code[pc+2]*/
    _33226 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33226);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2013		target = Code[pc+3]*/
    _33228 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33228);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2015		lhs_seq_index = val[a][1]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33230 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_33230);
    _67lhs_seq_index_64810 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_64810)){
        _67lhs_seq_index_64810 = (object)DBL_PTR(_67lhs_seq_index_64810)->dbl;
    }
    _33230 = NOVALUE;

    /** execute.e:2016		lhs_subs = val[a][2..$]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33232 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_SEQUENCE(_33232)){
            _33233 = SEQ_PTR(_33232)->length;
    }
    else {
        _33233 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_64811;
    RHS_Slice(_33232, 2, _33233);
    _33232 = NOVALUE;

    /** execute.e:2017		Code[pc+9] = Code[pc+1] -- patch upcoming op*/
    _33235 = _67pc_64802 + 9;
    if ((object)((uintptr_t)_33235 + (uintptr_t)HIGH_BITS) >= 0){
        _33235 = NewDouble((eudouble)_33235);
    }
    _33236 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33237 = (object)*(((s1_ptr)_2)->base + _33236);
    Ref(_33237);
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33235))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33235)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33235);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33237;
    if( _1 != _33237 ){
        DeRef(_1);
    }
    _33237 = NOVALUE;

    /** execute.e:2018		val[target] = var_subs(val[lhs_seq_index], lhs_subs & val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33238 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_64810);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33239 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_SEQUENCE(_67lhs_subs_64811) && IS_ATOM(_33239)) {
        Ref(_33239);
        Append(&_33240, _67lhs_subs_64811, _33239);
    }
    else if (IS_ATOM(_67lhs_subs_64811) && IS_SEQUENCE(_33239)) {
    }
    else {
        Concat((object_ptr)&_33240, _67lhs_subs_64811, _33239);
    }
    _33239 = NOVALUE;
    Ref(_33238);
    _33241 = _67var_subs(_33238, _33240);
    _33238 = NOVALUE;
    _33240 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33241;
    if( _1 != _33241 ){
        DeRef(_1);
    }
    _33241 = NOVALUE;

    /** execute.e:2019		lhs_subs = {}*/
    RefDS(_22015);
    DeRefDS(_67lhs_subs_64811);
    _67lhs_subs_64811 = _22015;

    /** execute.e:2020		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2021	end procedure*/
    _33226 = NOVALUE;
    _33224 = NOVALUE;
    DeRef(_33235);
    _33235 = NOVALUE;
    _33228 = NOVALUE;
    _33236 = NOVALUE;
    return;
    ;
}


void _67opASSIGN_OP_SLICE()
{
    object _x_67299 = NOVALUE;
    object _33266 = NOVALUE;
    object _33265 = NOVALUE;
    object _33264 = NOVALUE;
    object _33262 = NOVALUE;
    object _33260 = NOVALUE;
    object _33259 = NOVALUE;
    object _33258 = NOVALUE;
    object _33257 = NOVALUE;
    object _33256 = NOVALUE;
    object _33255 = NOVALUE;
    object _33254 = NOVALUE;
    object _33253 = NOVALUE;
    object _33251 = NOVALUE;
    object _33250 = NOVALUE;
    object _33249 = NOVALUE;
    object _33248 = NOVALUE;
    object _33246 = NOVALUE;
    object _33243 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2027		a = Code[pc+1]*/
    _33243 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33243);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2028		x = val[a]*/
    DeRef(_x_67299);
    _2 = (object)SEQ_PTR(_67val_64812);
    _x_67299 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    Ref(_x_67299);

    /** execute.e:2029		b = Code[pc+2]*/
    _33246 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33246);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2030		if floor(val[b]) > length(x) or floor(val[b]) < 1 then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33248 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33248))
    _33249 = e_floor(_33248);
    else
    _33249 = unary_op(FLOOR, _33248);
    _33248 = NOVALUE;
    if (IS_SEQUENCE(_x_67299)){
            _33250 = SEQ_PTR(_x_67299)->length;
    }
    else {
        _33250 = 1;
    }
    if (IS_ATOM_INT(_33249)) {
        _33251 = (_33249 > _33250);
    }
    else {
        _33251 = binary_op(GREATER, _33249, _33250);
    }
    DeRef(_33249);
    _33249 = NOVALUE;
    _33250 = NOVALUE;
    if (IS_ATOM_INT(_33251)) {
        if (_33251 != 0) {
            goto L1; // [63] 87
        }
    }
    else {
        if (DBL_PTR(_33251)->dbl != 0.0) {
            goto L1; // [63] 87
        }
    }
    _2 = (object)SEQ_PTR(_67val_64812);
    _33253 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33253))
    _33254 = e_floor(_33253);
    else
    _33254 = unary_op(FLOOR, _33253);
    _33253 = NOVALUE;
    if (IS_ATOM_INT(_33254)) {
        _33255 = (_33254 < 1);
    }
    else {
        _33255 = binary_op(LESS, _33254, 1);
    }
    DeRef(_33254);
    _33254 = NOVALUE;
    if (_33255 == 0) {
        DeRef(_33255);
        _33255 = NOVALUE;
        goto L2; // [83] 112
    }
    else {
        if (!IS_ATOM_INT(_33255) && DBL_PTR(_33255)->dbl == 0.0){
            DeRef(_33255);
            _33255 = NOVALUE;
            goto L2; // [83] 112
        }
        DeRef(_33255);
        _33255 = NOVALUE;
    }
    DeRef(_33255);
    _33255 = NOVALUE;
L1: 

    /** execute.e:2031			RTFatal(*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33256 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_SEQUENCE(_x_67299)){
            _33257 = SEQ_PTR(_x_67299)->length;
    }
    else {
        _33257 = 1;
    }
    Ref(_33256);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _33256;
    ((intptr_t *)_2)[2] = _33257;
    _33258 = MAKE_SEQ(_1);
    _33257 = NOVALUE;
    _33256 = NOVALUE;
    _33259 = EPrintf(-9999999, _32807, _33258);
    DeRefDS(_33258);
    _33258 = NOVALUE;
    _67RTFatal(_33259);
    _33259 = NOVALUE;
L2: 

    /** execute.e:2035		c = Code[pc+3]*/
    _33260 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64805 = (object)*(((s1_ptr)_2)->base + _33260);
    if (!IS_ATOM_INT(_67c_64805)){
        _67c_64805 = (object)DBL_PTR(_67c_64805)->dbl;
    }

    /** execute.e:2036		target = Code[pc+4]*/
    _33262 = _67pc_64802 + 4;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33262);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2037		val[target] = var_slice(x, {}, val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33264 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33265 = (object)*(((s1_ptr)_2)->base + _67c_64805);
    Ref(_x_67299);
    RefDS(_22015);
    Ref(_33264);
    Ref(_33265);
    _33266 = _67var_slice(_x_67299, _22015, _33264, _33265);
    _33264 = NOVALUE;
    _33265 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33266;
    if( _1 != _33266 ){
        DeRef(_1);
    }
    _33266 = NOVALUE;

    /** execute.e:2038		pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:2039	end procedure*/
    DeRef(_x_67299);
    DeRef(_33243);
    _33243 = NOVALUE;
    DeRef(_33246);
    _33246 = NOVALUE;
    _33260 = NOVALUE;
    DeRef(_33251);
    _33251 = NOVALUE;
    _33262 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_OP_SLICE()
{
    object _x_67332 = NOVALUE;
    object _33286 = NOVALUE;
    object _33285 = NOVALUE;
    object _33284 = NOVALUE;
    object _33283 = NOVALUE;
    object _33282 = NOVALUE;
    object _33281 = NOVALUE;
    object _33280 = NOVALUE;
    object _33278 = NOVALUE;
    object _33275 = NOVALUE;
    object _33273 = NOVALUE;
    object _33271 = NOVALUE;
    object _33268 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2045		a = Code[pc+1]*/
    _33268 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33268);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2046		x = val[a]*/
    DeRef(_x_67332);
    _2 = (object)SEQ_PTR(_67val_64812);
    _x_67332 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    Ref(_x_67332);

    /** execute.e:2047		b = Code[pc+2]*/
    _33271 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33271);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2048		c = Code[pc+3]*/
    _33273 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64805 = (object)*(((s1_ptr)_2)->base + _33273);
    if (!IS_ATOM_INT(_67c_64805)){
        _67c_64805 = (object)DBL_PTR(_67c_64805)->dbl;
    }

    /** execute.e:2049		target = Code[pc+4]*/
    _33275 = _67pc_64802 + 4;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33275);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2050		lhs_seq_index = x[1]*/
    _2 = (object)SEQ_PTR(_x_67332);
    _67lhs_seq_index_64810 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_64810)){
        _67lhs_seq_index_64810 = (object)DBL_PTR(_67lhs_seq_index_64810)->dbl;
    }

    /** execute.e:2051		lhs_subs = x[2..$]*/
    if (IS_SEQUENCE(_x_67332)){
            _33278 = SEQ_PTR(_x_67332)->length;
    }
    else {
        _33278 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_64811;
    RHS_Slice(_x_67332, 2, _33278);

    /** execute.e:2052		Code[pc+10] = Code[pc+1]*/
    _33280 = _67pc_64802 + 10;
    if ((object)((uintptr_t)_33280 + (uintptr_t)HIGH_BITS) >= 0){
        _33280 = NewDouble((eudouble)_33280);
    }
    _33281 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33282 = (object)*(((s1_ptr)_2)->base + _33281);
    Ref(_33282);
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33280))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33280)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33280);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33282;
    if( _1 != _33282 ){
        DeRef(_1);
    }
    _33282 = NOVALUE;

    /** execute.e:2053		val[target] = var_slice(val[lhs_seq_index], lhs_subs, val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33283 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_64810);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33284 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33285 = (object)*(((s1_ptr)_2)->base + _67c_64805);
    Ref(_33283);
    RefDS(_67lhs_subs_64811);
    Ref(_33284);
    Ref(_33285);
    _33286 = _67var_slice(_33283, _67lhs_subs_64811, _33284, _33285);
    _33283 = NOVALUE;
    _33284 = NOVALUE;
    _33285 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33286;
    if( _1 != _33286 ){
        DeRef(_1);
    }
    _33286 = NOVALUE;

    /** execute.e:2054		lhs_subs = {}*/
    RefDS(_22015);
    DeRefDS(_67lhs_subs_64811);
    _67lhs_subs_64811 = _22015;

    /** execute.e:2055		pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:2056	end procedure*/
    DeRef(_x_67332);
    _33275 = NOVALUE;
    _33281 = NOVALUE;
    _33268 = NOVALUE;
    _33273 = NOVALUE;
    DeRef(_33280);
    _33280 = NOVALUE;
    _33271 = NOVALUE;
    return;
    ;
}


void _67opASSIGN_SLICE()
{
    object _x_67361 = NOVALUE;
    object _33304 = NOVALUE;
    object _33303 = NOVALUE;
    object _33301 = NOVALUE;
    object _33299 = NOVALUE;
    object _33298 = NOVALUE;
    object _33297 = NOVALUE;
    object _33294 = NOVALUE;
    object _33292 = NOVALUE;
    object _33290 = NOVALUE;
    object _33288 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:2062		a = Code[pc+1]  -- sequence*/
    _33288 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33288);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2063		b = Code[pc+2]  -- 1st index*/
    _33290 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33290);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2064		c = Code[pc+3]  -- 2nd index*/
    _33292 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64805 = (object)*(((s1_ptr)_2)->base + _33292);
    if (!IS_ATOM_INT(_67c_64805)){
        _67c_64805 = (object)DBL_PTR(_67c_64805)->dbl;
    }

    /** execute.e:2065		d = Code[pc+4]  -- rhs value to assign*/
    _33294 = _67pc_64802 + 4;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67d_64806 = (object)*(((s1_ptr)_2)->base + _33294);
    if (!IS_ATOM_INT(_67d_64806)){
        _67d_64806 = (object)DBL_PTR(_67d_64806)->dbl;
    }

    /** execute.e:2067		x = val[a] -- avoid lingering ref count on val[a]*/
    DeRef(_x_67361);
    _2 = (object)SEQ_PTR(_67val_64812);
    _x_67361 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    Ref(_x_67361);

    /** execute.e:2068		lhs_check_slice(x, val[b], val[c], val[d])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33297 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33298 = (object)*(((s1_ptr)_2)->base + _67c_64805);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33299 = (object)*(((s1_ptr)_2)->base + _67d_64806);
    Ref(_x_67361);
    Ref(_33297);
    Ref(_33298);
    Ref(_33299);
    _67lhs_check_slice(_x_67361, _33297, _33298, _33299);
    _33297 = NOVALUE;
    _33298 = NOVALUE;
    _33299 = NOVALUE;

    /** execute.e:2069		x = val[d]*/
    DeRef(_x_67361);
    _2 = (object)SEQ_PTR(_67val_64812);
    _x_67361 = (object)*(((s1_ptr)_2)->base + _67d_64806);
    Ref(_x_67361);

    /** execute.e:2070		val[a][val[b]..val[c]] = x*/
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67a_64803 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33303 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33304 = (object)*(((s1_ptr)_2)->base + _67c_64805);
    assign_slice_seq = (s1_ptr *)_3;
    AssignSlice(_33303, _33304, _x_67361);
    _33303 = NOVALUE;
    _33304 = NOVALUE;

    /** execute.e:2071		pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:2072	end procedure*/
    DeRef(_x_67361);
    _33301 = NOVALUE;
    _33292 = NOVALUE;
    _33288 = NOVALUE;
    _33294 = NOVALUE;
    _33290 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_SLICE()
{
    object _33323 = NOVALUE;
    object _33322 = NOVALUE;
    object _33321 = NOVALUE;
    object _33320 = NOVALUE;
    object _33319 = NOVALUE;
    object _33317 = NOVALUE;
    object _33316 = NOVALUE;
    object _33314 = NOVALUE;
    object _33312 = NOVALUE;
    object _33310 = NOVALUE;
    object _33308 = NOVALUE;
    object _33306 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2076		a = Code[pc+1]  -- sequence*/
    _33306 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33306);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2077		b = Code[pc+2]  -- 1st index*/
    _33308 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33308);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2078		c = Code[pc+3]  -- 2nd index*/
    _33310 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64805 = (object)*(((s1_ptr)_2)->base + _33310);
    if (!IS_ATOM_INT(_67c_64805)){
        _67c_64805 = (object)DBL_PTR(_67c_64805)->dbl;
    }

    /** execute.e:2079		d = Code[pc+4]  -- rhs value to assign*/
    _33312 = _67pc_64802 + 4;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67d_64806 = (object)*(((s1_ptr)_2)->base + _33312);
    if (!IS_ATOM_INT(_67d_64806)){
        _67d_64806 = (object)DBL_PTR(_67d_64806)->dbl;
    }

    /** execute.e:2081		lhs_seq_index = val[a][1]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33314 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_33314);
    _67lhs_seq_index_64810 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_64810)){
        _67lhs_seq_index_64810 = (object)DBL_PTR(_67lhs_seq_index_64810)->dbl;
    }
    _33314 = NOVALUE;

    /** execute.e:2082		lhs_subs = val[a][2..$]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33316 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_SEQUENCE(_33316)){
            _33317 = SEQ_PTR(_33316)->length;
    }
    else {
        _33317 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_64811;
    RHS_Slice(_33316, 2, _33317);
    _33316 = NOVALUE;

    /** execute.e:2083		val[lhs_seq_index] = assign_slice(val[lhs_seq_index],*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33319 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_64810);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33320 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33321 = (object)*(((s1_ptr)_2)->base + _67c_64805);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33322 = (object)*(((s1_ptr)_2)->base + _67d_64806);
    Ref(_33319);
    RefDS(_67lhs_subs_64811);
    Ref(_33320);
    Ref(_33321);
    Ref(_33322);
    _33323 = _67assign_slice(_33319, _67lhs_subs_64811, _33320, _33321, _33322);
    _33319 = NOVALUE;
    _33320 = NOVALUE;
    _33321 = NOVALUE;
    _33322 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67lhs_seq_index_64810);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33323;
    if( _1 != _33323 ){
        DeRef(_1);
    }
    _33323 = NOVALUE;

    /** execute.e:2086		lhs_subs = {}*/
    RefDS(_22015);
    DeRefDS(_67lhs_subs_64811);
    _67lhs_subs_64811 = _22015;

    /** execute.e:2087		pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:2088	end procedure*/
    _33306 = NOVALUE;
    _33310 = NOVALUE;
    _33308 = NOVALUE;
    _33312 = NOVALUE;
    return;
    ;
}


void _67opRHS_SLICE()
{
    object _x_67411 = NOVALUE;
    object _33338 = NOVALUE;
    object _33337 = NOVALUE;
    object _33336 = NOVALUE;
    object _33335 = NOVALUE;
    object _33334 = NOVALUE;
    object _33331 = NOVALUE;
    object _33329 = NOVALUE;
    object _33327 = NOVALUE;
    object _33325 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2094		a = Code[pc+1]  -- sequence*/
    _33325 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33325);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2095		b = Code[pc+2]  -- 1st index*/
    _33327 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33327);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2096		c = Code[pc+3]  -- 2nd index*/
    _33329 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64805 = (object)*(((s1_ptr)_2)->base + _33329);
    if (!IS_ATOM_INT(_67c_64805)){
        _67c_64805 = (object)DBL_PTR(_67c_64805)->dbl;
    }

    /** execute.e:2097		target = Code[pc+4]*/
    _33331 = _67pc_64802 + 4;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33331);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2098		x = val[a]*/
    DeRef(_x_67411);
    _2 = (object)SEQ_PTR(_67val_64812);
    _x_67411 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    Ref(_x_67411);

    /** execute.e:2099		check_slice(x, val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33334 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33335 = (object)*(((s1_ptr)_2)->base + _67c_64805);
    Ref(_x_67411);
    Ref(_33334);
    Ref(_33335);
    _67check_slice(_x_67411, _33334, _33335);
    _33334 = NOVALUE;
    _33335 = NOVALUE;

    /** execute.e:2100		val[target] = x[val[b]..val[c]]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33336 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33337 = (object)*(((s1_ptr)_2)->base + _67c_64805);
    rhs_slice_target = (object_ptr)&_33338;
    RHS_Slice(_x_67411, _33336, _33337);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33338;
    if( _1 != _33338 ){
        DeRef(_1);
    }
    _33338 = NOVALUE;

    /** execute.e:2101		pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:2102	end procedure*/
    DeRef(_x_67411);
    _33336 = NOVALUE;
    _33337 = NOVALUE;
    _33325 = NOVALUE;
    _33329 = NOVALUE;
    _33331 = NOVALUE;
    _33327 = NOVALUE;
    return;
    ;
}


void _67opTYPE_CHECK()
{
    object _33344 = NOVALUE;
    object _33342 = NOVALUE;
    object _33341 = NOVALUE;
    object _33340 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2107		if val[Code[pc-1]] = 0 then*/
    _33340 = _67pc_64802 - 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33341 = (object)*(((s1_ptr)_2)->base + _33340);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_33341)){
        _33342 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33341)->dbl));
    }
    else{
        _33342 = (object)*(((s1_ptr)_2)->base + _33341);
    }
    if (binary_op_a(NOTEQ, _33342, 0)){
        _33342 = NOVALUE;
        goto L1; // [21] 37
    }
    _33342 = NOVALUE;

    /** execute.e:2108			RTFatalType(pc-2)*/
    _33344 = _67pc_64802 - 2;
    if ((object)((uintptr_t)_33344 +(uintptr_t) HIGH_BITS) >= 0){
        _33344 = NewDouble((eudouble)_33344);
    }
    _67RTFatalType(_33344);
    _33344 = NOVALUE;
L1: 

    /** execute.e:2110		pc += 1*/
    _67pc_64802 = _67pc_64802 + 1;

    /** execute.e:2111	end procedure*/
    DeRef(_33340);
    _33340 = NOVALUE;
    _33341 = NOVALUE;
    return;
    ;
}


void _67kill_temp(object _sym_67444)
{
    object _33346 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2114		if sym_mode( sym ) = M_TEMP then*/
    _33346 = _53sym_mode(_sym_67444);
    if (binary_op_a(NOTEQ, _33346, 3)){
        DeRef(_33346);
        _33346 = NOVALUE;
        goto L1; // [11] 26
    }
    DeRef(_33346);
    _33346 = NOVALUE;

    /** execute.e:2115			val[sym] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sym_67444);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
L1: 

    /** execute.e:2117	end procedure*/
    return;
    ;
}


void _67opIS_AN_INTEGER()
{
    object _33353 = NOVALUE;
    object _33352 = NOVALUE;
    object _33350 = NOVALUE;
    object _33348 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2120		a = Code[pc+1]*/
    _33348 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33348);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2121		target = Code[pc+2]*/
    _33350 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33350);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2122		val[target] = integer(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33352 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_33352))
    _33353 = 1;
    else if (IS_ATOM_DBL(_33352))
    _33353 = IS_ATOM_INT(DoubleToInt(_33352));
    else
    _33353 = 0;
    _33352 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33353;
    if( _1 != _33353 ){
        DeRef(_1);
    }
    _33353 = NOVALUE;

    /** execute.e:2123		kill_temp( a )*/
    _67kill_temp(_67a_64803);

    /** execute.e:2124		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:2125	end procedure*/
    _33348 = NOVALUE;
    _33350 = NOVALUE;
    return;
    ;
}


void _67opIS_AN_ATOM()
{
    object _33360 = NOVALUE;
    object _33359 = NOVALUE;
    object _33357 = NOVALUE;
    object _33355 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2128		a = Code[pc+1]*/
    _33355 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33355);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2129		target = Code[pc+2]*/
    _33357 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33357);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2130		val[target] = atom(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33359 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _33360 = IS_ATOM(_33359);
    _33359 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33360;
    if( _1 != _33360 ){
        DeRef(_1);
    }
    _33360 = NOVALUE;

    /** execute.e:2131		kill_temp( a )*/
    _67kill_temp(_67a_64803);

    /** execute.e:2132		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:2133	end procedure*/
    _33355 = NOVALUE;
    _33357 = NOVALUE;
    return;
    ;
}


void _67opIS_A_SEQUENCE()
{
    object _33367 = NOVALUE;
    object _33366 = NOVALUE;
    object _33364 = NOVALUE;
    object _33362 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2136		a = Code[pc+1]*/
    _33362 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33362);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2137		target = Code[pc+2]*/
    _33364 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33364);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2138		val[target] = sequence(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33366 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _33367 = IS_SEQUENCE(_33366);
    _33366 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33367;
    if( _1 != _33367 ){
        DeRef(_1);
    }
    _33367 = NOVALUE;

    /** execute.e:2139		kill_temp( a )*/
    _67kill_temp(_67a_64803);

    /** execute.e:2140		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:2141	end procedure*/
    _33362 = NOVALUE;
    _33364 = NOVALUE;
    return;
    ;
}


void _67opIS_AN_OBJECT()
{
    object _33376 = NOVALUE;
    object _33375 = NOVALUE;
    object _33374 = NOVALUE;
    object _33373 = NOVALUE;
    object _33371 = NOVALUE;
    object _33369 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2144		a = Code[pc+1]*/
    _33369 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33369);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2145		target = Code[pc+2]*/
    _33371 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33371);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2146		if equal( val[a], NOVALUE ) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33373 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (_33373 == _12NOVALUE_20081)
    _33374 = 1;
    else if (IS_ATOM_INT(_33373) && IS_ATOM_INT(_12NOVALUE_20081))
    _33374 = 0;
    else
    _33374 = (compare(_33373, _12NOVALUE_20081) == 0);
    _33373 = NOVALUE;
    if (_33374 == 0)
    {
        _33374 = NOVALUE;
        goto L1; // [49] 65
    }
    else{
        _33374 = NOVALUE;
    }

    /** execute.e:2147			val[target] = 0*/
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    goto L2; // [62] 87
L1: 

    /** execute.e:2149			val[target] = object( val[a] )*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33375 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if( NOVALUE == _33375 ){
        _33376 = 0;
    }
    else{
        if (IS_ATOM_INT(_33375))
        _33376 = 1;
        else if (IS_ATOM_DBL(_33375)) {
             if (IS_ATOM_INT(DoubleToInt(_33375))) {
                 _33376 = 1;
                 } else {
                     _33376 = 2;
                } } else if (IS_SEQUENCE(_33375))
                _33376 = 3;
                else
                _33376 = 0;
            }
            _33375 = NOVALUE;
            _2 = (object)SEQ_PTR(_67val_64812);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67val_64812 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _33376;
            if( _1 != _33376 ){
                DeRef(_1);
            }
            _33376 = NOVALUE;
L2: 

            /** execute.e:2152		kill_temp( a )*/
            _67kill_temp(_67a_64803);

            /** execute.e:2153		pc += 3*/
            _67pc_64802 = _67pc_64802 + 3;

            /** execute.e:2154	end procedure*/
            DeRef(_33369);
            _33369 = NOVALUE;
            DeRef(_33371);
            _33371 = NOVALUE;
            return;
    ;
}


void _67opSQRT()
{
    object _33383 = NOVALUE;
    object _33382 = NOVALUE;
    object _33380 = NOVALUE;
    object _33378 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2160		a = Code[pc+1]*/
    _33378 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33378);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2161		target = Code[pc+2]*/
    _33380 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33380);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2162		val[target] = sqrt(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33382 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_33382))
    _33383 = e_sqrt(_33382);
    else
    _33383 = unary_op(SQRT, _33382);
    _33382 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33383;
    if( _1 != _33383 ){
        DeRef(_1);
    }
    _33383 = NOVALUE;

    /** execute.e:2163		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:2164	end procedure*/
    _33378 = NOVALUE;
    _33380 = NOVALUE;
    return;
    ;
}


void _67opSIN()
{
    object _33390 = NOVALUE;
    object _33389 = NOVALUE;
    object _33387 = NOVALUE;
    object _33385 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2167		a = Code[pc+1]*/
    _33385 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33385);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2168		target = Code[pc+2]*/
    _33387 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33387);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2169		val[target] = sin(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33389 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_33389))
    _33390 = e_sin(_33389);
    else
    _33390 = unary_op(SIN, _33389);
    _33389 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33390;
    if( _1 != _33390 ){
        DeRef(_1);
    }
    _33390 = NOVALUE;

    /** execute.e:2170		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:2171	end procedure*/
    _33385 = NOVALUE;
    _33387 = NOVALUE;
    return;
    ;
}


void _67opCOS()
{
    object _33397 = NOVALUE;
    object _33396 = NOVALUE;
    object _33394 = NOVALUE;
    object _33392 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2174		a = Code[pc+1]*/
    _33392 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33392);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2175		target = Code[pc+2]*/
    _33394 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33394);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2176		val[target] = cos(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33396 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_33396))
    _33397 = e_cos(_33396);
    else
    _33397 = unary_op(COS, _33396);
    _33396 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33397;
    if( _1 != _33397 ){
        DeRef(_1);
    }
    _33397 = NOVALUE;

    /** execute.e:2177		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:2178	end procedure*/
    _33392 = NOVALUE;
    _33394 = NOVALUE;
    return;
    ;
}


void _67opTAN()
{
    object _33404 = NOVALUE;
    object _33403 = NOVALUE;
    object _33401 = NOVALUE;
    object _33399 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2181		a = Code[pc+1]*/
    _33399 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33399);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2182		target = Code[pc+2]*/
    _33401 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33401);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2183		val[target] = tan(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33403 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_33403))
    _33404 = e_tan(_33403);
    else
    _33404 = unary_op(TAN, _33403);
    _33403 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33404;
    if( _1 != _33404 ){
        DeRef(_1);
    }
    _33404 = NOVALUE;

    /** execute.e:2184		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:2185	end procedure*/
    _33399 = NOVALUE;
    _33401 = NOVALUE;
    return;
    ;
}


void _67opARCTAN()
{
    object _33411 = NOVALUE;
    object _33410 = NOVALUE;
    object _33408 = NOVALUE;
    object _33406 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2188		a = Code[pc+1]*/
    _33406 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33406);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2189		target = Code[pc+2]*/
    _33408 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33408);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2190		val[target] = arctan(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33410 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_33410))
    _33411 = e_arctan(_33410);
    else
    _33411 = unary_op(ARCTAN, _33410);
    _33410 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33411;
    if( _1 != _33411 ){
        DeRef(_1);
    }
    _33411 = NOVALUE;

    /** execute.e:2191		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:2192	end procedure*/
    _33408 = NOVALUE;
    _33406 = NOVALUE;
    return;
    ;
}


void _67opLOG()
{
    object _33418 = NOVALUE;
    object _33417 = NOVALUE;
    object _33415 = NOVALUE;
    object _33413 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2195		a = Code[pc+1]*/
    _33413 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33413);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2196		target = Code[pc+2]*/
    _33415 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33415);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2197		val[target] = log(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33417 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_33417))
    _33418 = e_log(_33417);
    else
    _33418 = unary_op(LOG, _33417);
    _33417 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33418;
    if( _1 != _33418 ){
        DeRef(_1);
    }
    _33418 = NOVALUE;

    /** execute.e:2198		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:2199	end procedure*/
    _33415 = NOVALUE;
    _33413 = NOVALUE;
    return;
    ;
}


void _67opNOT_BITS()
{
    object _33425 = NOVALUE;
    object _33424 = NOVALUE;
    object _33422 = NOVALUE;
    object _33420 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2202		a = Code[pc+1]*/
    _33420 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33420);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2203		target = Code[pc+2]*/
    _33422 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33422);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2204		val[target] = not_bits(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33424 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_33424))
    _33425 = not_bits(_33424);
    else
    _33425 = unary_op(NOT_BITS, _33424);
    _33424 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33425;
    if( _1 != _33425 ){
        DeRef(_1);
    }
    _33425 = NOVALUE;

    /** execute.e:2205		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:2206	end procedure*/
    _33422 = NOVALUE;
    _33420 = NOVALUE;
    return;
    ;
}


void _67opFLOOR()
{
    object _33432 = NOVALUE;
    object _33431 = NOVALUE;
    object _33429 = NOVALUE;
    object _33427 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2209		a = Code[pc+1]*/
    _33427 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33427);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2210		target = Code[pc+2]*/
    _33429 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33429);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2211		val[target] = floor(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33431 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_33431))
    _33432 = e_floor(_33431);
    else
    _33432 = unary_op(FLOOR, _33431);
    _33431 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33432;
    if( _1 != _33432 ){
        DeRef(_1);
    }
    _33432 = NOVALUE;

    /** execute.e:2212		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:2213	end procedure*/
    _33427 = NOVALUE;
    _33429 = NOVALUE;
    return;
    ;
}


void _67opNOT_IFW()
{
    object _33439 = NOVALUE;
    object _33436 = NOVALUE;
    object _33434 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2216		a = Code[pc+1]*/
    _33434 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33434);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2217		if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33436 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (binary_op_a(NOTEQ, _33436, 0)){
        _33436 = NOVALUE;
        goto L1; // [27] 42
    }
    _33436 = NOVALUE;

    /** execute.e:2218			pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;
    goto L2; // [39] 59
L1: 

    /** execute.e:2220			pc = Code[pc+2]*/
    _33439 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _33439);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }
L2: 

    /** execute.e:2222	end procedure*/
    DeRef(_33439);
    _33439 = NOVALUE;
    DeRef(_33434);
    _33434 = NOVALUE;
    return;
    ;
}


void _67opNOT()
{
    object _33446 = NOVALUE;
    object _33445 = NOVALUE;
    object _33443 = NOVALUE;
    object _33441 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2225		a = Code[pc+1]*/
    _33441 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33441);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2226		target = Code[pc+2]*/
    _33443 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33443);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2227		val[target] = not val[a]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33445 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_33445)) {
        _33446 = (_33445 == 0);
    }
    else {
        _33446 = unary_op(NOT, _33445);
    }
    _33445 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33446;
    if( _1 != _33446 ){
        DeRef(_1);
    }
    _33446 = NOVALUE;

    /** execute.e:2228		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:2229	end procedure*/
    _33443 = NOVALUE;
    _33441 = NOVALUE;
    return;
    ;
}


void _67opUMINUS()
{
    object _33453 = NOVALUE;
    object _33452 = NOVALUE;
    object _33450 = NOVALUE;
    object _33448 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2232		a = Code[pc+1]*/
    _33448 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33448);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2233		target = Code[pc+2]*/
    _33450 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33450);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2234		val[target] = -val[a]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33452 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_33452)) {
        if ((uintptr_t)_33452 == (uintptr_t)HIGH_BITS){
            _33453 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _33453 = - _33452;
        }
    }
    else {
        _33453 = unary_op(UMINUS, _33452);
    }
    _33452 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33453;
    if( _1 != _33453 ){
        DeRef(_1);
    }
    _33453 = NOVALUE;

    /** execute.e:2235		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:2236	end procedure*/
    _33448 = NOVALUE;
    _33450 = NOVALUE;
    return;
    ;
}


void _67opRAND()
{
    object _33460 = NOVALUE;
    object _33459 = NOVALUE;
    object _33457 = NOVALUE;
    object _33455 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2239		a = Code[pc+1]*/
    _33455 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33455);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2240		target = Code[pc+2]*/
    _33457 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33457);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2241		val[target] = rand(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33459 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_33459)) {
        _33460 = good_rand() % ((uint32_t)_33459) + 1;
    }
    else {
        _33460 = unary_op(RAND, _33459);
    }
    _33459 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33460;
    if( _1 != _33460 ){
        DeRef(_1);
    }
    _33460 = NOVALUE;

    /** execute.e:2242		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:2243	end procedure*/
    _33455 = NOVALUE;
    _33457 = NOVALUE;
    return;
    ;
}


void _67opDIV2()
{
    object _33467 = NOVALUE;
    object _33466 = NOVALUE;
    object _33464 = NOVALUE;
    object _33462 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2247		a = Code[pc+1]*/
    _33462 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33462);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2249		target = Code[pc+3]*/
    _33464 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33464);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2250		val[target] = val[a] / 2*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33466 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_33466)) {
        if (_33466 & 1) {
            _33467 = NewDouble((_33466 >> 1) + 0.5);
        }
        else
        _33467 = _33466 >> 1;
    }
    else {
        _33467 = binary_op(DIVIDE, _33466, 2);
    }
    _33466 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33467;
    if( _1 != _33467 ){
        DeRef(_1);
    }
    _33467 = NOVALUE;

    /** execute.e:2251		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2252	end procedure*/
    _33462 = NOVALUE;
    _33464 = NOVALUE;
    return;
    ;
}


void _67opFLOOR_DIV2()
{
    object _33474 = NOVALUE;
    object _33473 = NOVALUE;
    object _33471 = NOVALUE;
    object _33469 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2255		a = Code[pc+1]*/
    _33469 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33469);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2257		target = Code[pc+3]*/
    _33471 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33471);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2258		val[target] = floor(val[a] / 2)*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33473 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_33473)) {
        _33474 = _33473 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _33473, 2);
        _33474 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    _33473 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33474;
    if( _1 != _33474 ){
        DeRef(_1);
    }
    _33474 = NOVALUE;

    /** execute.e:2259		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2260	end procedure*/
    _33471 = NOVALUE;
    _33469 = NOVALUE;
    return;
    ;
}


void _67opGREATER_IFW()
{
    object _33484 = NOVALUE;
    object _33481 = NOVALUE;
    object _33480 = NOVALUE;
    object _33478 = NOVALUE;
    object _33476 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2265		a = Code[pc+1]*/
    _33476 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33476);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2266		b = Code[pc+2]*/
    _33478 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33478);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2267		if val[a] > val[b] then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33480 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33481 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (binary_op_a(LESSEQ, _33480, _33481)){
        _33480 = NOVALUE;
        _33481 = NOVALUE;
        goto L1; // [51] 66
    }
    _33480 = NOVALUE;
    _33481 = NOVALUE;

    /** execute.e:2268			pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;
    goto L2; // [63] 83
L1: 

    /** execute.e:2270			pc = Code[pc+3]*/
    _33484 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _33484);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }
L2: 

    /** execute.e:2272	end procedure*/
    DeRef(_33484);
    _33484 = NOVALUE;
    DeRef(_33476);
    _33476 = NOVALUE;
    DeRef(_33478);
    _33478 = NOVALUE;
    return;
    ;
}


void _67opNOTEQ_IFW()
{
    object _33494 = NOVALUE;
    object _33491 = NOVALUE;
    object _33490 = NOVALUE;
    object _33488 = NOVALUE;
    object _33486 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2275		a = Code[pc+1]*/
    _33486 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33486);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2276		b = Code[pc+2]*/
    _33488 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33488);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2277		if val[a] != val[b] then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33490 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33491 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (binary_op_a(EQUALS, _33490, _33491)){
        _33490 = NOVALUE;
        _33491 = NOVALUE;
        goto L1; // [51] 66
    }
    _33490 = NOVALUE;
    _33491 = NOVALUE;

    /** execute.e:2278			pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;
    goto L2; // [63] 83
L1: 

    /** execute.e:2280			pc = Code[pc+3]*/
    _33494 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _33494);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }
L2: 

    /** execute.e:2282	end procedure*/
    DeRef(_33486);
    _33486 = NOVALUE;
    DeRef(_33494);
    _33494 = NOVALUE;
    DeRef(_33488);
    _33488 = NOVALUE;
    return;
    ;
}


void _67opLESSEQ_IFW()
{
    object _33504 = NOVALUE;
    object _33501 = NOVALUE;
    object _33500 = NOVALUE;
    object _33498 = NOVALUE;
    object _33496 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2285		a = Code[pc+1]*/
    _33496 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33496);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2286		b = Code[pc+2]*/
    _33498 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33498);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2287		if val[a] <= val[b] then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33500 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33501 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (binary_op_a(GREATER, _33500, _33501)){
        _33500 = NOVALUE;
        _33501 = NOVALUE;
        goto L1; // [51] 66
    }
    _33500 = NOVALUE;
    _33501 = NOVALUE;

    /** execute.e:2288			pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;
    goto L2; // [63] 83
L1: 

    /** execute.e:2290			pc = Code[pc+3]*/
    _33504 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _33504);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }
L2: 

    /** execute.e:2292	end procedure*/
    DeRef(_33504);
    _33504 = NOVALUE;
    DeRef(_33498);
    _33498 = NOVALUE;
    DeRef(_33496);
    _33496 = NOVALUE;
    return;
    ;
}


void _67opGREATEREQ_IFW()
{
    object _33514 = NOVALUE;
    object _33511 = NOVALUE;
    object _33510 = NOVALUE;
    object _33508 = NOVALUE;
    object _33506 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2295		a = Code[pc+1]*/
    _33506 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33506);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2296		b = Code[pc+2]*/
    _33508 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33508);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2297		if val[a] >= val[b] then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33510 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33511 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (binary_op_a(LESS, _33510, _33511)){
        _33510 = NOVALUE;
        _33511 = NOVALUE;
        goto L1; // [51] 66
    }
    _33510 = NOVALUE;
    _33511 = NOVALUE;

    /** execute.e:2298			pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;
    goto L2; // [63] 83
L1: 

    /** execute.e:2300			pc = Code[pc+3]*/
    _33514 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _33514);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }
L2: 

    /** execute.e:2302	end procedure*/
    DeRef(_33506);
    _33506 = NOVALUE;
    DeRef(_33514);
    _33514 = NOVALUE;
    DeRef(_33508);
    _33508 = NOVALUE;
    return;
    ;
}


void _67opEQUALS_IFW()
{
    object _33530 = NOVALUE;
    object _33527 = NOVALUE;
    object _33526 = NOVALUE;
    object _33524 = NOVALUE;
    object _33523 = NOVALUE;
    object _33521 = NOVALUE;
    object _33520 = NOVALUE;
    object _33518 = NOVALUE;
    object _33516 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2305		a = Code[pc+1]*/
    _33516 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33516);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2306		b = Code[pc+2]*/
    _33518 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33518);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2308		if sequence( val[a] ) or sequence( val[b] ) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33520 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _33521 = IS_SEQUENCE(_33520);
    _33520 = NOVALUE;
    if (_33521 != 0) {
        goto L1; // [46] 66
    }
    _2 = (object)SEQ_PTR(_67val_64812);
    _33523 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _33524 = IS_SEQUENCE(_33523);
    _33523 = NOVALUE;
    if (_33524 == 0)
    {
        _33524 = NOVALUE;
        goto L2; // [62] 72
    }
    else{
        _33524 = NOVALUE;
    }
L1: 

    /** execute.e:2309			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33525);
    _67RTFatal(_33525);
L2: 

    /** execute.e:2311		if val[a] = val[b] then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33526 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33527 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (binary_op_a(NOTEQ, _33526, _33527)){
        _33526 = NOVALUE;
        _33527 = NOVALUE;
        goto L3; // [90] 105
    }
    _33526 = NOVALUE;
    _33527 = NOVALUE;

    /** execute.e:2312			pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;
    goto L4; // [102] 122
L3: 

    /** execute.e:2314			pc = Code[pc+3]*/
    _33530 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _33530);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }
L4: 

    /** execute.e:2316	end procedure*/
    DeRef(_33516);
    _33516 = NOVALUE;
    DeRef(_33530);
    _33530 = NOVALUE;
    DeRef(_33518);
    _33518 = NOVALUE;
    return;
    ;
}


void _67opLESS_IFW()
{
    object _33540 = NOVALUE;
    object _33537 = NOVALUE;
    object _33536 = NOVALUE;
    object _33534 = NOVALUE;
    object _33532 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2319		a = Code[pc+1]*/
    _33532 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33532);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2320		b = Code[pc+2]*/
    _33534 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33534);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2321		if val[a] < val[b] then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33536 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33537 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (binary_op_a(GREATEREQ, _33536, _33537)){
        _33536 = NOVALUE;
        _33537 = NOVALUE;
        goto L1; // [51] 66
    }
    _33536 = NOVALUE;
    _33537 = NOVALUE;

    /** execute.e:2322			pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;
    goto L2; // [63] 83
L1: 

    /** execute.e:2324			pc = Code[pc+3]*/
    _33540 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _33540);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }
L2: 

    /** execute.e:2326	end procedure*/
    DeRef(_33534);
    _33534 = NOVALUE;
    DeRef(_33540);
    _33540 = NOVALUE;
    DeRef(_33532);
    _33532 = NOVALUE;
    return;
    ;
}


void _67opMULTIPLY()
{
    object _33550 = NOVALUE;
    object _33549 = NOVALUE;
    object _33548 = NOVALUE;
    object _33546 = NOVALUE;
    object _33544 = NOVALUE;
    object _33542 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2331		a = Code[pc+1]*/
    _33542 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33542);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2332		b = Code[pc+2]*/
    _33544 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33544);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2333		target = Code[pc+3]*/
    _33546 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33546);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2334		val[target] = val[a] * val[b]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33548 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33549 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33548) && IS_ATOM_INT(_33549)) {
        if (_33548 == (short)_33548 && _33549 <= INT15 && _33549 >= -INT15){
            _33550 = _33548 * _33549;
        }
        else{
            _33550 = NewDouble(_33548 * (eudouble)_33549);
        }
    }
    else {
        _33550 = binary_op(MULTIPLY, _33548, _33549);
    }
    _33548 = NOVALUE;
    _33549 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33550;
    if( _1 != _33550 ){
        DeRef(_1);
    }
    _33550 = NOVALUE;

    /** execute.e:2335		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2336	end procedure*/
    _33542 = NOVALUE;
    _33544 = NOVALUE;
    _33546 = NOVALUE;
    return;
    ;
}


void _67opPLUS()
{
    object _33560 = NOVALUE;
    object _33559 = NOVALUE;
    object _33558 = NOVALUE;
    object _33556 = NOVALUE;
    object _33554 = NOVALUE;
    object _33552 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2340		a = Code[pc+1]*/
    _33552 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33552);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2341		b = Code[pc+2]*/
    _33554 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33554);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2342		target = Code[pc+3]*/
    _33556 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33556);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2343		val[target] = val[a] + val[b]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33558 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33559 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33558) && IS_ATOM_INT(_33559)) {
        _33560 = _33558 + _33559;
        if ((object)((uintptr_t)_33560 + (uintptr_t)HIGH_BITS) >= 0){
            _33560 = NewDouble((eudouble)_33560);
        }
    }
    else {
        _33560 = binary_op(PLUS, _33558, _33559);
    }
    _33558 = NOVALUE;
    _33559 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33560;
    if( _1 != _33560 ){
        DeRef(_1);
    }
    _33560 = NOVALUE;

    /** execute.e:2344		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2345	end procedure*/
    _33556 = NOVALUE;
    _33554 = NOVALUE;
    _33552 = NOVALUE;
    return;
    ;
}


void _67opMINUS()
{
    object _33570 = NOVALUE;
    object _33569 = NOVALUE;
    object _33568 = NOVALUE;
    object _33566 = NOVALUE;
    object _33564 = NOVALUE;
    object _33562 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2349		a = Code[pc+1]*/
    _33562 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33562);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2350		b = Code[pc+2]*/
    _33564 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33564);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2351		target = Code[pc+3]*/
    _33566 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33566);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2352		val[target] = val[a] - val[b]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33568 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33569 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33568) && IS_ATOM_INT(_33569)) {
        _33570 = _33568 - _33569;
        if ((object)((uintptr_t)_33570 +(uintptr_t) HIGH_BITS) >= 0){
            _33570 = NewDouble((eudouble)_33570);
        }
    }
    else {
        _33570 = binary_op(MINUS, _33568, _33569);
    }
    _33568 = NOVALUE;
    _33569 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33570;
    if( _1 != _33570 ){
        DeRef(_1);
    }
    _33570 = NOVALUE;

    /** execute.e:2353		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2354	end procedure*/
    _33562 = NOVALUE;
    _33566 = NOVALUE;
    _33564 = NOVALUE;
    return;
    ;
}


void _67opOR()
{
    object _33580 = NOVALUE;
    object _33579 = NOVALUE;
    object _33578 = NOVALUE;
    object _33576 = NOVALUE;
    object _33574 = NOVALUE;
    object _33572 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2357		a = Code[pc+1]*/
    _33572 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33572);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2358		b = Code[pc+2]*/
    _33574 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33574);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2359		target = Code[pc+3]*/
    _33576 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33576);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2360		val[target] = val[a] or val[b]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33578 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33579 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33578) && IS_ATOM_INT(_33579)) {
        _33580 = (_33578 != 0 || _33579 != 0);
    }
    else {
        _33580 = binary_op(OR, _33578, _33579);
    }
    _33578 = NOVALUE;
    _33579 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33580;
    if( _1 != _33580 ){
        DeRef(_1);
    }
    _33580 = NOVALUE;

    /** execute.e:2361		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2362	end procedure*/
    _33574 = NOVALUE;
    _33572 = NOVALUE;
    _33576 = NOVALUE;
    return;
    ;
}


void _67opXOR()
{
    object _33590 = NOVALUE;
    object _33589 = NOVALUE;
    object _33588 = NOVALUE;
    object _33586 = NOVALUE;
    object _33584 = NOVALUE;
    object _33582 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2365		a = Code[pc+1]*/
    _33582 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33582);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2366		b = Code[pc+2]*/
    _33584 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33584);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2367		target = Code[pc+3]*/
    _33586 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33586);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2368		val[target] = val[a] xor val[b]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33588 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33589 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33588) && IS_ATOM_INT(_33589)) {
        _33590 = ((_33588 != 0) != (_33589 != 0));
    }
    else {
        _33590 = binary_op(XOR, _33588, _33589);
    }
    _33588 = NOVALUE;
    _33589 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33590;
    if( _1 != _33590 ){
        DeRef(_1);
    }
    _33590 = NOVALUE;

    /** execute.e:2369		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2370	end procedure*/
    _33582 = NOVALUE;
    _33584 = NOVALUE;
    _33586 = NOVALUE;
    return;
    ;
}


void _67opAND()
{
    object _33600 = NOVALUE;
    object _33599 = NOVALUE;
    object _33598 = NOVALUE;
    object _33596 = NOVALUE;
    object _33594 = NOVALUE;
    object _33592 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2373		a = Code[pc+1]*/
    _33592 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33592);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2374		b = Code[pc+2]*/
    _33594 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33594);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2375		target = Code[pc+3]*/
    _33596 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33596);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2376		val[target] = val[a] and val[b]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33598 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33599 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33598) && IS_ATOM_INT(_33599)) {
        _33600 = (_33598 != 0 && _33599 != 0);
    }
    else {
        _33600 = binary_op(AND, _33598, _33599);
    }
    _33598 = NOVALUE;
    _33599 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33600;
    if( _1 != _33600 ){
        DeRef(_1);
    }
    _33600 = NOVALUE;

    /** execute.e:2377		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2378	end procedure*/
    _33592 = NOVALUE;
    _33596 = NOVALUE;
    _33594 = NOVALUE;
    return;
    ;
}


void _67opDIVIDE()
{
    object _33613 = NOVALUE;
    object _33612 = NOVALUE;
    object _33611 = NOVALUE;
    object _33609 = NOVALUE;
    object _33608 = NOVALUE;
    object _33606 = NOVALUE;
    object _33604 = NOVALUE;
    object _33602 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2381		a = Code[pc+1]*/
    _33602 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33602);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2382		b = Code[pc+2]*/
    _33604 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33604);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2383		target = Code[pc+3]*/
    _33606 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33606);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2384		if equal(val[b], 0) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33608 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (_33608 == 0)
    _33609 = 1;
    else if (IS_ATOM_INT(_33608) && IS_ATOM_INT(0))
    _33609 = 0;
    else
    _33609 = (compare(_33608, 0) == 0);
    _33608 = NOVALUE;
    if (_33609 == 0)
    {
        _33609 = NOVALUE;
        goto L1; // [63] 72
    }
    else{
        _33609 = NOVALUE;
    }

    /** execute.e:2385			RTFatal("attempt to divide by 0")*/
    RefDS(_33610);
    _67RTFatal(_33610);
L1: 

    /** execute.e:2387		val[target] = val[a] / val[b]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33611 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33612 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33611) && IS_ATOM_INT(_33612)) {
        _33613 = (_33611 % _33612) ? NewDouble((eudouble)_33611 / _33612) : (_33611 / _33612);
    }
    else {
        _33613 = binary_op(DIVIDE, _33611, _33612);
    }
    _33611 = NOVALUE;
    _33612 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33613;
    if( _1 != _33613 ){
        DeRef(_1);
    }
    _33613 = NOVALUE;

    /** execute.e:2388		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2389	end procedure*/
    DeRef(_33606);
    _33606 = NOVALUE;
    DeRef(_33604);
    _33604 = NOVALUE;
    DeRef(_33602);
    _33602 = NOVALUE;
    return;
    ;
}


void _67opREMAINDER()
{
    object _33626 = NOVALUE;
    object _33625 = NOVALUE;
    object _33624 = NOVALUE;
    object _33622 = NOVALUE;
    object _33621 = NOVALUE;
    object _33619 = NOVALUE;
    object _33617 = NOVALUE;
    object _33615 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2392		a = Code[pc+1]*/
    _33615 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33615);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2393		b = Code[pc+2]*/
    _33617 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33617);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2394		target = Code[pc+3]*/
    _33619 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33619);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2395		if equal(val[b], 0) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33621 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (_33621 == 0)
    _33622 = 1;
    else if (IS_ATOM_INT(_33621) && IS_ATOM_INT(0))
    _33622 = 0;
    else
    _33622 = (compare(_33621, 0) == 0);
    _33621 = NOVALUE;
    if (_33622 == 0)
    {
        _33622 = NOVALUE;
        goto L1; // [63] 72
    }
    else{
        _33622 = NOVALUE;
    }

    /** execute.e:2396			RTFatal("Can't get remainder of a number divided by 0")*/
    RefDS(_33623);
    _67RTFatal(_33623);
L1: 

    /** execute.e:2398		val[target] = remainder(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33624 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33625 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33624) && IS_ATOM_INT(_33625)) {
        _33626 = (_33624 % _33625);
    }
    else {
        _33626 = binary_op(REMAINDER, _33624, _33625);
    }
    _33624 = NOVALUE;
    _33625 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33626;
    if( _1 != _33626 ){
        DeRef(_1);
    }
    _33626 = NOVALUE;

    /** execute.e:2399		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2400	end procedure*/
    DeRef(_33619);
    _33619 = NOVALUE;
    DeRef(_33615);
    _33615 = NOVALUE;
    DeRef(_33617);
    _33617 = NOVALUE;
    return;
    ;
}


void _67opFLOOR_DIV()
{
    object _33638 = NOVALUE;
    object _33637 = NOVALUE;
    object _33636 = NOVALUE;
    object _33635 = NOVALUE;
    object _33634 = NOVALUE;
    object _33632 = NOVALUE;
    object _33630 = NOVALUE;
    object _33628 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2403		a = Code[pc+1]*/
    _33628 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33628);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2404		b = Code[pc+2]*/
    _33630 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33630);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2405		target = Code[pc+3]*/
    _33632 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33632);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2406		if equal(val[b], 0) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33634 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (_33634 == 0)
    _33635 = 1;
    else if (IS_ATOM_INT(_33634) && IS_ATOM_INT(0))
    _33635 = 0;
    else
    _33635 = (compare(_33634, 0) == 0);
    _33634 = NOVALUE;
    if (_33635 == 0)
    {
        _33635 = NOVALUE;
        goto L1; // [63] 72
    }
    else{
        _33635 = NOVALUE;
    }

    /** execute.e:2407			RTFatal("attempt to divide by 0")*/
    RefDS(_33610);
    _67RTFatal(_33610);
L1: 

    /** execute.e:2409		val[target] = floor(val[a] / val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33636 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33637 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33636) && IS_ATOM_INT(_33637)) {
        if (_33637 > 0 && _33636 >= 0) {
            _33638 = _33636 / _33637;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_33636 / (eudouble)_33637);
            if (_33636 != MININT)
            _33638 = (object)temp_dbl;
            else
            _33638 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _33636, _33637);
        _33638 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _33636 = NOVALUE;
    _33637 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33638;
    if( _1 != _33638 ){
        DeRef(_1);
    }
    _33638 = NOVALUE;

    /** execute.e:2410		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2411	end procedure*/
    DeRef(_33632);
    _33632 = NOVALUE;
    DeRef(_33630);
    _33630 = NOVALUE;
    DeRef(_33628);
    _33628 = NOVALUE;
    return;
    ;
}


void _67opAND_BITS()
{
    object _33648 = NOVALUE;
    object _33647 = NOVALUE;
    object _33646 = NOVALUE;
    object _33644 = NOVALUE;
    object _33642 = NOVALUE;
    object _33640 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2414		a = Code[pc+1]*/
    _33640 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33640);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2415		b = Code[pc+2]*/
    _33642 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33642);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2416		target = Code[pc+3]*/
    _33644 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33644);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2417		val[target] = and_bits(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33646 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33647 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33646) && IS_ATOM_INT(_33647)) {
        {uintptr_t tu;
             tu = (uintptr_t)_33646 & (uintptr_t)_33647;
             _33648 = MAKE_UINT(tu);
        }
    }
    else {
        _33648 = binary_op(AND_BITS, _33646, _33647);
    }
    _33646 = NOVALUE;
    _33647 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33648;
    if( _1 != _33648 ){
        DeRef(_1);
    }
    _33648 = NOVALUE;

    /** execute.e:2418		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2419	end procedure*/
    _33644 = NOVALUE;
    _33640 = NOVALUE;
    _33642 = NOVALUE;
    return;
    ;
}


void _67opOR_BITS()
{
    object _33658 = NOVALUE;
    object _33657 = NOVALUE;
    object _33656 = NOVALUE;
    object _33654 = NOVALUE;
    object _33652 = NOVALUE;
    object _33650 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2422		a = Code[pc+1]*/
    _33650 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33650);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2423		b = Code[pc+2]*/
    _33652 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33652);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2424		target = Code[pc+3]*/
    _33654 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33654);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2425		val[target] = or_bits(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33656 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33657 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33656) && IS_ATOM_INT(_33657)) {
        {uintptr_t tu;
             tu = (uintptr_t)_33656 | (uintptr_t)_33657;
             _33658 = MAKE_UINT(tu);
        }
    }
    else {
        _33658 = binary_op(OR_BITS, _33656, _33657);
    }
    _33656 = NOVALUE;
    _33657 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33658;
    if( _1 != _33658 ){
        DeRef(_1);
    }
    _33658 = NOVALUE;

    /** execute.e:2426		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2427	end procedure*/
    _33650 = NOVALUE;
    _33652 = NOVALUE;
    _33654 = NOVALUE;
    return;
    ;
}


void _67opXOR_BITS()
{
    object _33668 = NOVALUE;
    object _33667 = NOVALUE;
    object _33666 = NOVALUE;
    object _33664 = NOVALUE;
    object _33662 = NOVALUE;
    object _33660 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2430		a = Code[pc+1]*/
    _33660 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33660);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2431		b = Code[pc+2]*/
    _33662 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33662);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2432		target = Code[pc+3]*/
    _33664 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33664);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2433		val[target] = xor_bits(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33666 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33667 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33666) && IS_ATOM_INT(_33667)) {
        {uintptr_t tu;
             tu = (uintptr_t)_33666 ^ (uintptr_t)_33667;
             _33668 = MAKE_UINT(tu);
        }
    }
    else {
        _33668 = binary_op(XOR_BITS, _33666, _33667);
    }
    _33666 = NOVALUE;
    _33667 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33668;
    if( _1 != _33668 ){
        DeRef(_1);
    }
    _33668 = NOVALUE;

    /** execute.e:2434		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2435	end procedure*/
    _33662 = NOVALUE;
    _33660 = NOVALUE;
    _33664 = NOVALUE;
    return;
    ;
}


void _67opPOWER()
{
    object _33678 = NOVALUE;
    object _33677 = NOVALUE;
    object _33676 = NOVALUE;
    object _33674 = NOVALUE;
    object _33672 = NOVALUE;
    object _33670 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2438		a = Code[pc+1]*/
    _33670 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33670);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2439		b = Code[pc+2]*/
    _33672 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33672);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2440		target = Code[pc+3]*/
    _33674 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33674);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2441		val[target] = power(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33676 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33677 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33676) && IS_ATOM_INT(_33677)) {
        _33678 = power(_33676, _33677);
    }
    else {
        _33678 = binary_op(POWER, _33676, _33677);
    }
    _33676 = NOVALUE;
    _33677 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33678;
    if( _1 != _33678 ){
        DeRef(_1);
    }
    _33678 = NOVALUE;

    /** execute.e:2442		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2443	end procedure*/
    _33672 = NOVALUE;
    _33670 = NOVALUE;
    _33674 = NOVALUE;
    return;
    ;
}


void _67opLESS()
{
    object _33688 = NOVALUE;
    object _33687 = NOVALUE;
    object _33686 = NOVALUE;
    object _33684 = NOVALUE;
    object _33682 = NOVALUE;
    object _33680 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2446		a = Code[pc+1]*/
    _33680 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33680);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2447		b = Code[pc+2]*/
    _33682 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33682);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2448		target = Code[pc+3]*/
    _33684 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33684);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2449		val[target] = val[a] < val[b]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33686 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33687 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33686) && IS_ATOM_INT(_33687)) {
        _33688 = (_33686 < _33687);
    }
    else {
        _33688 = binary_op(LESS, _33686, _33687);
    }
    _33686 = NOVALUE;
    _33687 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33688;
    if( _1 != _33688 ){
        DeRef(_1);
    }
    _33688 = NOVALUE;

    /** execute.e:2450		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2451	end procedure*/
    _33682 = NOVALUE;
    _33680 = NOVALUE;
    _33684 = NOVALUE;
    return;
    ;
}


void _67opGREATER()
{
    object _33698 = NOVALUE;
    object _33697 = NOVALUE;
    object _33696 = NOVALUE;
    object _33694 = NOVALUE;
    object _33692 = NOVALUE;
    object _33690 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2454		a = Code[pc+1]*/
    _33690 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33690);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2455		b = Code[pc+2]*/
    _33692 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33692);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2456		target = Code[pc+3]*/
    _33694 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33694);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2457		val[target] = val[a] > val[b]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33696 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33697 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33696) && IS_ATOM_INT(_33697)) {
        _33698 = (_33696 > _33697);
    }
    else {
        _33698 = binary_op(GREATER, _33696, _33697);
    }
    _33696 = NOVALUE;
    _33697 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33698;
    if( _1 != _33698 ){
        DeRef(_1);
    }
    _33698 = NOVALUE;

    /** execute.e:2458		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2459	end procedure*/
    _33692 = NOVALUE;
    _33690 = NOVALUE;
    _33694 = NOVALUE;
    return;
    ;
}


void _67opEQUALS()
{
    object _33708 = NOVALUE;
    object _33707 = NOVALUE;
    object _33706 = NOVALUE;
    object _33704 = NOVALUE;
    object _33702 = NOVALUE;
    object _33700 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2462		a = Code[pc+1]*/
    _33700 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33700);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2463		b = Code[pc+2]*/
    _33702 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33702);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2464		target = Code[pc+3]*/
    _33704 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33704);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2465		val[target] = val[a] = val[b]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33706 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33707 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33706) && IS_ATOM_INT(_33707)) {
        _33708 = (_33706 == _33707);
    }
    else {
        _33708 = binary_op(EQUALS, _33706, _33707);
    }
    _33706 = NOVALUE;
    _33707 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33708;
    if( _1 != _33708 ){
        DeRef(_1);
    }
    _33708 = NOVALUE;

    /** execute.e:2466		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2467	end procedure*/
    _33704 = NOVALUE;
    _33702 = NOVALUE;
    _33700 = NOVALUE;
    return;
    ;
}


void _67opNOTEQ()
{
    object _33718 = NOVALUE;
    object _33717 = NOVALUE;
    object _33716 = NOVALUE;
    object _33714 = NOVALUE;
    object _33712 = NOVALUE;
    object _33710 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2470		a = Code[pc+1]*/
    _33710 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33710);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2471		b = Code[pc+2]*/
    _33712 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33712);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2472		target = Code[pc+3]*/
    _33714 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33714);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2473		val[target] = val[a] != val[b]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33716 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33717 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33716) && IS_ATOM_INT(_33717)) {
        _33718 = (_33716 != _33717);
    }
    else {
        _33718 = binary_op(NOTEQ, _33716, _33717);
    }
    _33716 = NOVALUE;
    _33717 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33718;
    if( _1 != _33718 ){
        DeRef(_1);
    }
    _33718 = NOVALUE;

    /** execute.e:2474		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2475	end procedure*/
    _33712 = NOVALUE;
    _33710 = NOVALUE;
    _33714 = NOVALUE;
    return;
    ;
}


void _67opLESSEQ()
{
    object _33728 = NOVALUE;
    object _33727 = NOVALUE;
    object _33726 = NOVALUE;
    object _33724 = NOVALUE;
    object _33722 = NOVALUE;
    object _33720 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2478		a = Code[pc+1]*/
    _33720 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33720);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2479		b = Code[pc+2]*/
    _33722 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33722);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2480		target = Code[pc+3]*/
    _33724 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33724);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2481		val[target] = val[a] <= val[b]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33726 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33727 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33726) && IS_ATOM_INT(_33727)) {
        _33728 = (_33726 <= _33727);
    }
    else {
        _33728 = binary_op(LESSEQ, _33726, _33727);
    }
    _33726 = NOVALUE;
    _33727 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33728;
    if( _1 != _33728 ){
        DeRef(_1);
    }
    _33728 = NOVALUE;

    /** execute.e:2482		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2483	end procedure*/
    _33724 = NOVALUE;
    _33722 = NOVALUE;
    _33720 = NOVALUE;
    return;
    ;
}


void _67opGREATEREQ()
{
    object _33738 = NOVALUE;
    object _33737 = NOVALUE;
    object _33736 = NOVALUE;
    object _33734 = NOVALUE;
    object _33732 = NOVALUE;
    object _33730 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2486		a = Code[pc+1]*/
    _33730 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33730);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2487		b = Code[pc+2]*/
    _33732 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33732);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2488		target = Code[pc+3]*/
    _33734 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _33734);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2489		val[target] = val[a] >= val[b]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33736 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33737 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_33736) && IS_ATOM_INT(_33737)) {
        _33738 = (_33736 >= _33737);
    }
    else {
        _33738 = binary_op(GREATEREQ, _33736, _33737);
    }
    _33736 = NOVALUE;
    _33737 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33738;
    if( _1 != _33738 ){
        DeRef(_1);
    }
    _33738 = NOVALUE;

    /** execute.e:2490		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2491	end procedure*/
    _33732 = NOVALUE;
    _33730 = NOVALUE;
    _33734 = NOVALUE;
    return;
    ;
}


void _67opSC1_AND()
{
    object _33748 = NOVALUE;
    object _33746 = NOVALUE;
    object _33745 = NOVALUE;
    object _33744 = NOVALUE;
    object _33742 = NOVALUE;
    object _33740 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2496		a = Code[pc+1]*/
    _33740 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33740);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2497		b = Code[pc+2]*/
    _33742 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33742);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2498		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33744 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _33745 = IS_ATOM(_33744);
    _33744 = NOVALUE;
    if (_33745 == 0)
    {
        _33745 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        _33745 = NOVALUE;
    }

    /** execute.e:2499			if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33746 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (binary_op_a(NOTEQ, _33746, 0)){
        _33746 = NOVALUE;
        goto L2; // [59] 104
    }
    _33746 = NOVALUE;

    /** execute.e:2500				val[b] = 0*/
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_64804);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** execute.e:2501				pc = Code[pc+3]*/
    _33748 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _33748);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }

    /** execute.e:2502				return*/
    _33742 = NOVALUE;
    _33740 = NOVALUE;
    _33748 = NOVALUE;
    return;
    goto L2; // [95] 104
L1: 

    /** execute.e:2505			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33525);
    _67RTFatal(_33525);
L2: 

    /** execute.e:2507		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2508	end procedure*/
    DeRef(_33742);
    _33742 = NOVALUE;
    DeRef(_33740);
    _33740 = NOVALUE;
    DeRef(_33748);
    _33748 = NOVALUE;
    return;
    ;
}


void _67opSC1_AND_IF()
{
    object _33759 = NOVALUE;
    object _33757 = NOVALUE;
    object _33756 = NOVALUE;
    object _33755 = NOVALUE;
    object _33753 = NOVALUE;
    object _33751 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2512		a = Code[pc+1]*/
    _33751 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33751);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2513		b = Code[pc+2]*/
    _33753 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33753);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2514		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33755 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _33756 = IS_ATOM(_33755);
    _33755 = NOVALUE;
    if (_33756 == 0)
    {
        _33756 = NOVALUE;
        goto L1; // [46] 88
    }
    else{
        _33756 = NOVALUE;
    }

    /** execute.e:2515			if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33757 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (binary_op_a(NOTEQ, _33757, 0)){
        _33757 = NOVALUE;
        goto L2; // [59] 94
    }
    _33757 = NOVALUE;

    /** execute.e:2516				pc = Code[pc+3]*/
    _33759 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _33759);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }

    /** execute.e:2517				return*/
    _33753 = NOVALUE;
    _33759 = NOVALUE;
    _33751 = NOVALUE;
    return;
    goto L2; // [85] 94
L1: 

    /** execute.e:2520			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33525);
    _67RTFatal(_33525);
L2: 

    /** execute.e:2522		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2523	end procedure*/
    DeRef(_33753);
    _33753 = NOVALUE;
    DeRef(_33759);
    _33759 = NOVALUE;
    DeRef(_33751);
    _33751 = NOVALUE;
    return;
    ;
}


void _67opSC1_OR()
{
    object _33770 = NOVALUE;
    object _33768 = NOVALUE;
    object _33767 = NOVALUE;
    object _33766 = NOVALUE;
    object _33764 = NOVALUE;
    object _33762 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2526		a = Code[pc+1]*/
    _33762 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33762);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2527		b = Code[pc+2]*/
    _33764 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33764);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2528		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33766 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _33767 = IS_ATOM(_33766);
    _33766 = NOVALUE;
    if (_33767 == 0)
    {
        _33767 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        _33767 = NOVALUE;
    }

    /** execute.e:2529			if val[a] != 0 then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33768 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (binary_op_a(EQUALS, _33768, 0)){
        _33768 = NOVALUE;
        goto L2; // [59] 104
    }
    _33768 = NOVALUE;

    /** execute.e:2530				val[b] = 1*/
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_64804);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);

    /** execute.e:2531				pc = Code[pc+3]*/
    _33770 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _33770);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }

    /** execute.e:2532				return*/
    _33770 = NOVALUE;
    _33764 = NOVALUE;
    _33762 = NOVALUE;
    return;
    goto L2; // [95] 104
L1: 

    /** execute.e:2535			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33525);
    _67RTFatal(_33525);
L2: 

    /** execute.e:2537		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2538	end procedure*/
    DeRef(_33770);
    _33770 = NOVALUE;
    DeRef(_33764);
    _33764 = NOVALUE;
    DeRef(_33762);
    _33762 = NOVALUE;
    return;
    ;
}


void _67opSC1_OR_IF()
{
    object _33781 = NOVALUE;
    object _33779 = NOVALUE;
    object _33778 = NOVALUE;
    object _33777 = NOVALUE;
    object _33775 = NOVALUE;
    object _33773 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2542		a = Code[pc+1]*/
    _33773 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33773);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2543		b = Code[pc+2]*/
    _33775 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33775);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2544		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33777 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _33778 = IS_ATOM(_33777);
    _33777 = NOVALUE;
    if (_33778 == 0)
    {
        _33778 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        _33778 = NOVALUE;
    }

    /** execute.e:2545			if val[a] != 0 then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33779 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (binary_op_a(EQUALS, _33779, 0)){
        _33779 = NOVALUE;
        goto L2; // [59] 104
    }
    _33779 = NOVALUE;

    /** execute.e:2546				val[b] = 1*/
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_64804);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);

    /** execute.e:2547				pc = Code[pc+3]*/
    _33781 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _33781);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }

    /** execute.e:2548				return*/
    _33775 = NOVALUE;
    _33773 = NOVALUE;
    _33781 = NOVALUE;
    return;
    goto L2; // [95] 104
L1: 

    /** execute.e:2551			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33525);
    _67RTFatal(_33525);
L2: 

    /** execute.e:2553		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2554	end procedure*/
    DeRef(_33775);
    _33775 = NOVALUE;
    DeRef(_33773);
    _33773 = NOVALUE;
    DeRef(_33781);
    _33781 = NOVALUE;
    return;
    ;
}


void _67opSC2_OR()
{
    object _33790 = NOVALUE;
    object _33789 = NOVALUE;
    object _33788 = NOVALUE;
    object _33786 = NOVALUE;
    object _33784 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2559		a = Code[pc+1]*/
    _33784 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _33784);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2560		b = Code[pc+2]*/
    _33786 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _33786);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2561		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33788 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _33789 = IS_ATOM(_33788);
    _33788 = NOVALUE;
    if (_33789 == 0)
    {
        _33789 = NOVALUE;
        goto L1; // [46] 70
    }
    else{
        _33789 = NOVALUE;
    }

    /** execute.e:2562			val[b] = val[a]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33790 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    Ref(_33790);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_64804);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33790;
    if( _1 != _33790 ){
        DeRef(_1);
    }
    _33790 = NOVALUE;
    goto L2; // [67] 76
L1: 

    /** execute.e:2564			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33525);
    _67RTFatal(_33525);
L2: 

    /** execute.e:2566		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:2567	end procedure*/
    DeRef(_33784);
    _33784 = NOVALUE;
    DeRef(_33786);
    _33786 = NOVALUE;
    return;
    ;
}


void _67opFOR()
{
    object _increment_68153 = NOVALUE;
    object _limit_68154 = NOVALUE;
    object _initial_68155 = NOVALUE;
    object _loopvar_68156 = NOVALUE;
    object _jump_68157 = NOVALUE;
    object _33820 = NOVALUE;
    object _33818 = NOVALUE;
    object _33817 = NOVALUE;
    object _33815 = NOVALUE;
    object _33814 = NOVALUE;
    object _33812 = NOVALUE;
    object _33809 = NOVALUE;
    object _33808 = NOVALUE;
    object _33806 = NOVALUE;
    object _33805 = NOVALUE;
    object _33803 = NOVALUE;
    object _33802 = NOVALUE;
    object _33800 = NOVALUE;
    object _33798 = NOVALUE;
    object _33796 = NOVALUE;
    object _33794 = NOVALUE;
    object _33792 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2576		increment = Code[pc+1]*/
    _33792 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _increment_68153 = (object)*(((s1_ptr)_2)->base + _33792);
    if (!IS_ATOM_INT(_increment_68153)){
        _increment_68153 = (object)DBL_PTR(_increment_68153)->dbl;
    }

    /** execute.e:2577		limit = Code[pc+2]*/
    _33794 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _limit_68154 = (object)*(((s1_ptr)_2)->base + _33794);
    if (!IS_ATOM_INT(_limit_68154)){
        _limit_68154 = (object)DBL_PTR(_limit_68154)->dbl;
    }

    /** execute.e:2578		initial = Code[pc+3]*/
    _33796 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _initial_68155 = (object)*(((s1_ptr)_2)->base + _33796);
    if (!IS_ATOM_INT(_initial_68155)){
        _initial_68155 = (object)DBL_PTR(_initial_68155)->dbl;
    }

    /** execute.e:2581		loopvar = Code[pc+5]*/
    _33798 = _67pc_64802 + 5;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _loopvar_68156 = (object)*(((s1_ptr)_2)->base + _33798);
    if (!IS_ATOM_INT(_loopvar_68156)){
        _loopvar_68156 = (object)DBL_PTR(_loopvar_68156)->dbl;
    }

    /** execute.e:2582		jump = Code[pc+6]*/
    _33800 = _67pc_64802 + 6;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _jump_68157 = (object)*(((s1_ptr)_2)->base + _33800);
    if (!IS_ATOM_INT(_jump_68157)){
        _jump_68157 = (object)DBL_PTR(_jump_68157)->dbl;
    }

    /** execute.e:2584		if sequence(val[initial]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33802 = (object)*(((s1_ptr)_2)->base + _initial_68155);
    _33803 = IS_SEQUENCE(_33802);
    _33802 = NOVALUE;
    if (_33803 == 0)
    {
        _33803 = NOVALUE;
        goto L1; // [92] 101
    }
    else{
        _33803 = NOVALUE;
    }

    /** execute.e:2585			RTFatal("for-loop variable is not an atom")*/
    RefDS(_33804);
    _67RTFatal(_33804);
L1: 

    /** execute.e:2587		if sequence(val[limit]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33805 = (object)*(((s1_ptr)_2)->base + _limit_68154);
    _33806 = IS_SEQUENCE(_33805);
    _33805 = NOVALUE;
    if (_33806 == 0)
    {
        _33806 = NOVALUE;
        goto L2; // [112] 121
    }
    else{
        _33806 = NOVALUE;
    }

    /** execute.e:2588			RTFatal("for-loop limit is not an atom")*/
    RefDS(_33807);
    _67RTFatal(_33807);
L2: 

    /** execute.e:2590		if sequence(val[increment]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33808 = (object)*(((s1_ptr)_2)->base + _increment_68153);
    _33809 = IS_SEQUENCE(_33808);
    _33808 = NOVALUE;
    if (_33809 == 0)
    {
        _33809 = NOVALUE;
        goto L3; // [132] 141
    }
    else{
        _33809 = NOVALUE;
    }

    /** execute.e:2591			RTFatal("for-loop increment is not an atom")*/
    RefDS(_33810);
    _67RTFatal(_33810);
L3: 

    /** execute.e:2594		pc += 7 -- to enter into the loop*/
    _67pc_64802 = _67pc_64802 + 7;

    /** execute.e:2596		if val[increment] >= 0 then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33812 = (object)*(((s1_ptr)_2)->base + _increment_68153);
    if (binary_op_a(LESS, _33812, 0)){
        _33812 = NOVALUE;
        goto L4; // [157] 188
    }
    _33812 = NOVALUE;

    /** execute.e:2598			if val[initial] > val[limit] then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33814 = (object)*(((s1_ptr)_2)->base + _initial_68155);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33815 = (object)*(((s1_ptr)_2)->base + _limit_68154);
    if (binary_op_a(LESSEQ, _33814, _33815)){
        _33814 = NOVALUE;
        _33815 = NOVALUE;
        goto L5; // [175] 213
    }
    _33814 = NOVALUE;
    _33815 = NOVALUE;

    /** execute.e:2599				pc = jump -- quit immediately, 0 iterations*/
    _67pc_64802 = _jump_68157;
    goto L5; // [185] 213
L4: 

    /** execute.e:2603			if val[initial] < val[limit] then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33817 = (object)*(((s1_ptr)_2)->base + _initial_68155);
    _2 = (object)SEQ_PTR(_67val_64812);
    _33818 = (object)*(((s1_ptr)_2)->base + _limit_68154);
    if (binary_op_a(GREATEREQ, _33817, _33818)){
        _33817 = NOVALUE;
        _33818 = NOVALUE;
        goto L6; // [202] 212
    }
    _33817 = NOVALUE;
    _33818 = NOVALUE;

    /** execute.e:2604				pc = jump -- quit immediately, 0 iterations*/
    _67pc_64802 = _jump_68157;
L6: 
L5: 

    /** execute.e:2608		val[loopvar] = val[initial] -- initialize loop var*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33820 = (object)*(((s1_ptr)_2)->base + _initial_68155);
    Ref(_33820);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _loopvar_68156);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33820;
    if( _1 != _33820 ){
        DeRef(_1);
    }
    _33820 = NOVALUE;

    /** execute.e:2610	end procedure*/
    DeRef(_33798);
    _33798 = NOVALUE;
    DeRef(_33792);
    _33792 = NOVALUE;
    DeRef(_33800);
    _33800 = NOVALUE;
    DeRef(_33796);
    _33796 = NOVALUE;
    DeRef(_33794);
    _33794 = NOVALUE;
    return;
    ;
}


void _67opENDFOR_GENERAL()
{
    object _loopvar_68201 = NOVALUE;
    object _increment_68202 = NOVALUE;
    object _limit_68203 = NOVALUE;
    object _next_68204 = NOVALUE;
    object _33838 = NOVALUE;
    object _33834 = NOVALUE;
    object _33829 = NOVALUE;
    object _33827 = NOVALUE;
    object _33825 = NOVALUE;
    object _33824 = NOVALUE;
    object _33822 = NOVALUE;
    object _33821 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2619		limit = val[Code[pc+2]]*/
    _33821 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33822 = (object)*(((s1_ptr)_2)->base + _33821);
    DeRef(_limit_68203);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_33822)){
        _limit_68203 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33822)->dbl));
    }
    else{
        _limit_68203 = (object)*(((s1_ptr)_2)->base + _33822);
    }
    Ref(_limit_68203);

    /** execute.e:2620		increment = val[Code[pc+4]]*/
    _33824 = _67pc_64802 + 4;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33825 = (object)*(((s1_ptr)_2)->base + _33824);
    DeRef(_increment_68202);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_33825)){
        _increment_68202 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33825)->dbl));
    }
    else{
        _increment_68202 = (object)*(((s1_ptr)_2)->base + _33825);
    }
    Ref(_increment_68202);

    /** execute.e:2621		loopvar = Code[pc+3]*/
    _33827 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _loopvar_68201 = (object)*(((s1_ptr)_2)->base + _33827);
    if (!IS_ATOM_INT(_loopvar_68201)){
        _loopvar_68201 = (object)DBL_PTR(_loopvar_68201)->dbl;
    }

    /** execute.e:2622		next = val[loopvar] + increment*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33829 = (object)*(((s1_ptr)_2)->base + _loopvar_68201);
    DeRef(_next_68204);
    if (IS_ATOM_INT(_33829) && IS_ATOM_INT(_increment_68202)) {
        _next_68204 = _33829 + _increment_68202;
        if ((object)((uintptr_t)_next_68204 + (uintptr_t)HIGH_BITS) >= 0){
            _next_68204 = NewDouble((eudouble)_next_68204);
        }
    }
    else {
        _next_68204 = binary_op(PLUS, _33829, _increment_68202);
    }
    _33829 = NOVALUE;

    /** execute.e:2624		if increment >= 0 then*/
    if (binary_op_a(LESS, _increment_68202, 0)){
        goto L1; // [71] 120
    }

    /** execute.e:2626			if next > limit then*/
    if (binary_op_a(LESSEQ, _next_68204, _limit_68203)){
        goto L2; // [77] 92
    }

    /** execute.e:2627				pc += 5 -- exit loop*/
    _67pc_64802 = _67pc_64802 + 5;
    goto L3; // [89] 163
L2: 

    /** execute.e:2629				val[loopvar] = next*/
    Ref(_next_68204);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _loopvar_68201);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _next_68204;
    DeRef(_1);

    /** execute.e:2630				pc = Code[pc+1] -- loop again*/
    _33834 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _33834);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }
    goto L3; // [117] 163
L1: 

    /** execute.e:2634			if next < limit then*/
    if (binary_op_a(GREATEREQ, _next_68204, _limit_68203)){
        goto L4; // [122] 137
    }

    /** execute.e:2635				pc += 5 -- exit loop*/
    _67pc_64802 = _67pc_64802 + 5;
    goto L5; // [134] 162
L4: 

    /** execute.e:2637				val[loopvar] = next*/
    Ref(_next_68204);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _loopvar_68201);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _next_68204;
    DeRef(_1);

    /** execute.e:2638				pc = Code[pc+1] -- loop again*/
    _33838 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _33838);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }
L5: 
L3: 

    /** execute.e:2641	end procedure*/
    DeRef(_increment_68202);
    DeRef(_limit_68203);
    DeRef(_next_68204);
    _33822 = NOVALUE;
    DeRef(_33824);
    _33824 = NOVALUE;
    _33825 = NOVALUE;
    DeRef(_33827);
    _33827 = NOVALUE;
    DeRef(_33821);
    _33821 = NOVALUE;
    DeRef(_33838);
    _33838 = NOVALUE;
    DeRef(_33834);
    _33834 = NOVALUE;
    return;
    ;
}


void _67opENDFOR_INT_UP1()
{
    object _loopvar_68237 = NOVALUE;
    object _limit_68238 = NOVALUE;
    object _next_68239 = NOVALUE;
    object _33849 = NOVALUE;
    object _33845 = NOVALUE;
    object _33843 = NOVALUE;
    object _33841 = NOVALUE;
    object _33840 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2651		limit = val[Code[pc+2]]*/
    _33840 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33841 = (object)*(((s1_ptr)_2)->base + _33840);
    DeRef(_limit_68238);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_33841)){
        _limit_68238 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33841)->dbl));
    }
    else{
        _limit_68238 = (object)*(((s1_ptr)_2)->base + _33841);
    }
    Ref(_limit_68238);

    /** execute.e:2652		loopvar = Code[pc+3]*/
    _33843 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _loopvar_68237 = (object)*(((s1_ptr)_2)->base + _33843);
    if (!IS_ATOM_INT(_loopvar_68237)){
        _loopvar_68237 = (object)DBL_PTR(_loopvar_68237)->dbl;
    }

    /** execute.e:2653		next = val[loopvar] + 1*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _33845 = (object)*(((s1_ptr)_2)->base + _loopvar_68237);
    DeRef(_next_68239);
    if (IS_ATOM_INT(_33845)) {
        _next_68239 = _33845 + 1;
        if (_next_68239 > MAXINT){
            _next_68239 = NewDouble((eudouble)_next_68239);
        }
    }
    else
    _next_68239 = binary_op(PLUS, 1, _33845);
    _33845 = NOVALUE;

    /** execute.e:2656		if next > limit then*/
    if (binary_op_a(LESSEQ, _next_68239, _limit_68238)){
        goto L1; // [51] 66
    }

    /** execute.e:2657			pc += 5 -- exit loop*/
    _67pc_64802 = _67pc_64802 + 5;
    goto L2; // [63] 91
L1: 

    /** execute.e:2659			val[loopvar] = next*/
    Ref(_next_68239);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _loopvar_68237);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _next_68239;
    DeRef(_1);

    /** execute.e:2660			pc = Code[pc+1] -- loop again*/
    _33849 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _33849);
    if (!IS_ATOM_INT(_67pc_64802)){
        _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;
    }
L2: 

    /** execute.e:2662	end procedure*/
    DeRef(_limit_68238);
    DeRef(_next_68239);
    DeRef(_33843);
    _33843 = NOVALUE;
    DeRef(_33840);
    _33840 = NOVALUE;
    DeRef(_33849);
    _33849 = NOVALUE;
    _33841 = NOVALUE;
    return;
    ;
}


object _67RTLookup(object _name_68258, object _file_68259, object _proc_68261, object _stlen_68262)
{
    object _s_68264 = NOVALUE;
    object _global_found_68265 = NOVALUE;
    object _ns_68266 = NOVALUE;
    object _colon_68267 = NOVALUE;
    object _ns_file_68268 = NOVALUE;
    object _found_in_path_68269 = NOVALUE;
    object _found_outside_path_68270 = NOVALUE;
    object _s_in_include_path_68271 = NOVALUE;
    object _scope_68368 = NOVALUE;
    object _34078 = NOVALUE;
    object _34077 = NOVALUE;
    object _34076 = NOVALUE;
    object _34075 = NOVALUE;
    object _34073 = NOVALUE;
    object _34071 = NOVALUE;
    object _34070 = NOVALUE;
    object _34069 = NOVALUE;
    object _34068 = NOVALUE;
    object _34067 = NOVALUE;
    object _34066 = NOVALUE;
    object _34065 = NOVALUE;
    object _34064 = NOVALUE;
    object _34063 = NOVALUE;
    object _34062 = NOVALUE;
    object _34061 = NOVALUE;
    object _34060 = NOVALUE;
    object _34058 = NOVALUE;
    object _34057 = NOVALUE;
    object _34056 = NOVALUE;
    object _34055 = NOVALUE;
    object _34054 = NOVALUE;
    object _34053 = NOVALUE;
    object _34052 = NOVALUE;
    object _34051 = NOVALUE;
    object _34050 = NOVALUE;
    object _34049 = NOVALUE;
    object _34048 = NOVALUE;
    object _34047 = NOVALUE;
    object _34042 = NOVALUE;
    object _34041 = NOVALUE;
    object _34040 = NOVALUE;
    object _34039 = NOVALUE;
    object _34038 = NOVALUE;
    object _34037 = NOVALUE;
    object _34036 = NOVALUE;
    object _34035 = NOVALUE;
    object _34034 = NOVALUE;
    object _34033 = NOVALUE;
    object _34032 = NOVALUE;
    object _34031 = NOVALUE;
    object _34030 = NOVALUE;
    object _34029 = NOVALUE;
    object _34028 = NOVALUE;
    object _34027 = NOVALUE;
    object _34026 = NOVALUE;
    object _34025 = NOVALUE;
    object _34023 = NOVALUE;
    object _34021 = NOVALUE;
    object _34020 = NOVALUE;
    object _34019 = NOVALUE;
    object _34018 = NOVALUE;
    object _34017 = NOVALUE;
    object _34016 = NOVALUE;
    object _34015 = NOVALUE;
    object _34014 = NOVALUE;
    object _34013 = NOVALUE;
    object _34012 = NOVALUE;
    object _34011 = NOVALUE;
    object _34010 = NOVALUE;
    object _34009 = NOVALUE;
    object _34008 = NOVALUE;
    object _34007 = NOVALUE;
    object _34006 = NOVALUE;
    object _34005 = NOVALUE;
    object _34004 = NOVALUE;
    object _34003 = NOVALUE;
    object _34002 = NOVALUE;
    object _34001 = NOVALUE;
    object _34000 = NOVALUE;
    object _33999 = NOVALUE;
    object _33998 = NOVALUE;
    object _33997 = NOVALUE;
    object _33996 = NOVALUE;
    object _33995 = NOVALUE;
    object _33994 = NOVALUE;
    object _33993 = NOVALUE;
    object _33992 = NOVALUE;
    object _33991 = NOVALUE;
    object _33990 = NOVALUE;
    object _33989 = NOVALUE;
    object _33987 = NOVALUE;
    object _33985 = NOVALUE;
    object _33984 = NOVALUE;
    object _33983 = NOVALUE;
    object _33982 = NOVALUE;
    object _33981 = NOVALUE;
    object _33980 = NOVALUE;
    object _33979 = NOVALUE;
    object _33978 = NOVALUE;
    object _33977 = NOVALUE;
    object _33976 = NOVALUE;
    object _33975 = NOVALUE;
    object _33974 = NOVALUE;
    object _33972 = NOVALUE;
    object _33969 = NOVALUE;
    object _33968 = NOVALUE;
    object _33967 = NOVALUE;
    object _33966 = NOVALUE;
    object _33965 = NOVALUE;
    object _33964 = NOVALUE;
    object _33963 = NOVALUE;
    object _33962 = NOVALUE;
    object _33961 = NOVALUE;
    object _33960 = NOVALUE;
    object _33959 = NOVALUE;
    object _33958 = NOVALUE;
    object _33957 = NOVALUE;
    object _33956 = NOVALUE;
    object _33955 = NOVALUE;
    object _33954 = NOVALUE;
    object _33953 = NOVALUE;
    object _33952 = NOVALUE;
    object _33951 = NOVALUE;
    object _33950 = NOVALUE;
    object _33949 = NOVALUE;
    object _33948 = NOVALUE;
    object _33947 = NOVALUE;
    object _33946 = NOVALUE;
    object _33945 = NOVALUE;
    object _33944 = NOVALUE;
    object _33943 = NOVALUE;
    object _33942 = NOVALUE;
    object _33941 = NOVALUE;
    object _33940 = NOVALUE;
    object _33939 = NOVALUE;
    object _33938 = NOVALUE;
    object _33937 = NOVALUE;
    object _33936 = NOVALUE;
    object _33935 = NOVALUE;
    object _33934 = NOVALUE;
    object _33933 = NOVALUE;
    object _33932 = NOVALUE;
    object _33931 = NOVALUE;
    object _33930 = NOVALUE;
    object _33929 = NOVALUE;
    object _33928 = NOVALUE;
    object _33927 = NOVALUE;
    object _33926 = NOVALUE;
    object _33925 = NOVALUE;
    object _33924 = NOVALUE;
    object _33923 = NOVALUE;
    object _33922 = NOVALUE;
    object _33921 = NOVALUE;
    object _33919 = NOVALUE;
    object _33918 = NOVALUE;
    object _33917 = NOVALUE;
    object _33916 = NOVALUE;
    object _33915 = NOVALUE;
    object _33914 = NOVALUE;
    object _33913 = NOVALUE;
    object _33912 = NOVALUE;
    object _33910 = NOVALUE;
    object _33908 = NOVALUE;
    object _33907 = NOVALUE;
    object _33906 = NOVALUE;
    object _33905 = NOVALUE;
    object _33904 = NOVALUE;
    object _33903 = NOVALUE;
    object _33902 = NOVALUE;
    object _33901 = NOVALUE;
    object _33897 = NOVALUE;
    object _33896 = NOVALUE;
    object _33895 = NOVALUE;
    object _33894 = NOVALUE;
    object _33893 = NOVALUE;
    object _33892 = NOVALUE;
    object _33891 = NOVALUE;
    object _33890 = NOVALUE;
    object _33889 = NOVALUE;
    object _33888 = NOVALUE;
    object _33887 = NOVALUE;
    object _33886 = NOVALUE;
    object _33883 = NOVALUE;
    object _33882 = NOVALUE;
    object _33880 = NOVALUE;
    object _33879 = NOVALUE;
    object _33877 = NOVALUE;
    object _33876 = NOVALUE;
    object _33875 = NOVALUE;
    object _33874 = NOVALUE;
    object _33873 = NOVALUE;
    object _33872 = NOVALUE;
    object _33871 = NOVALUE;
    object _33870 = NOVALUE;
    object _33868 = NOVALUE;
    object _33867 = NOVALUE;
    object _33866 = NOVALUE;
    object _33865 = NOVALUE;
    object _33864 = NOVALUE;
    object _33863 = NOVALUE;
    object _33862 = NOVALUE;
    object _33861 = NOVALUE;
    object _33860 = NOVALUE;
    object _33859 = NOVALUE;
    object _33858 = NOVALUE;
    object _33856 = NOVALUE;
    object _33855 = NOVALUE;
    object _33853 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2673		sequence ns*/

    /** execute.e:2674		integer colon*/

    /** execute.e:2675		integer ns_file*/

    /** execute.e:2676		integer found_in_path*/

    /** execute.e:2677		integer found_outside_path*/

    /** execute.e:2678		integer s_in_include_path*/

    /** execute.e:2680		stlen = length( SymTab )*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _stlen_68262 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _stlen_68262 = 1;
    }

    /** execute.e:2681		colon = find(':', name)*/
    _colon_68267 = find_from(58, _name_68258, 1);

    /** execute.e:2683		if colon then*/
    if (_colon_68267 == 0)
    {
        goto L1; // [37] 827
    }
    else{
    }

    /** execute.e:2685			ns = name[1..colon-1]*/
    _33853 = _colon_68267 - 1;
    rhs_slice_target = (object_ptr)&_ns_68266;
    RHS_Slice(_name_68258, 1, _33853);

    /** execute.e:2686			name = name[colon+1..$]*/
    _33855 = _colon_68267 + 1;
    if (IS_SEQUENCE(_name_68258)){
            _33856 = SEQ_PTR(_name_68258)->length;
    }
    else {
        _33856 = 1;
    }
    rhs_slice_target = (object_ptr)&_name_68258;
    RHS_Slice(_name_68258, _33855, _33856);

    /** execute.e:2689			while length(ns) and (ns[$] = ' ' or ns[$] = '\t') do*/
L2: 
    if (IS_SEQUENCE(_ns_68266)){
            _33858 = SEQ_PTR(_ns_68266)->length;
    }
    else {
        _33858 = 1;
    }
    if (_33858 == 0) {
        goto L3; // [73] 130
    }
    if (IS_SEQUENCE(_ns_68266)){
            _33860 = SEQ_PTR(_ns_68266)->length;
    }
    else {
        _33860 = 1;
    }
    _2 = (object)SEQ_PTR(_ns_68266);
    _33861 = (object)*(((s1_ptr)_2)->base + _33860);
    if (IS_ATOM_INT(_33861)) {
        _33862 = (_33861 == 32);
    }
    else {
        _33862 = binary_op(EQUALS, _33861, 32);
    }
    _33861 = NOVALUE;
    if (IS_ATOM_INT(_33862)) {
        if (_33862 != 0) {
            DeRef(_33863);
            _33863 = 1;
            goto L4; // [88] 107
        }
    }
    else {
        if (DBL_PTR(_33862)->dbl != 0.0) {
            DeRef(_33863);
            _33863 = 1;
            goto L4; // [88] 107
        }
    }
    if (IS_SEQUENCE(_ns_68266)){
            _33864 = SEQ_PTR(_ns_68266)->length;
    }
    else {
        _33864 = 1;
    }
    _2 = (object)SEQ_PTR(_ns_68266);
    _33865 = (object)*(((s1_ptr)_2)->base + _33864);
    if (IS_ATOM_INT(_33865)) {
        _33866 = (_33865 == 9);
    }
    else {
        _33866 = binary_op(EQUALS, _33865, 9);
    }
    _33865 = NOVALUE;
    DeRef(_33863);
    if (IS_ATOM_INT(_33866))
    _33863 = (_33866 != 0);
    else
    _33863 = DBL_PTR(_33866)->dbl != 0.0;
L4: 
    if (_33863 == 0)
    {
        _33863 = NOVALUE;
        goto L3; // [108] 130
    }
    else{
        _33863 = NOVALUE;
    }

    /** execute.e:2690				ns = ns[1..$-1]*/
    if (IS_SEQUENCE(_ns_68266)){
            _33867 = SEQ_PTR(_ns_68266)->length;
    }
    else {
        _33867 = 1;
    }
    _33868 = _33867 - 1;
    _33867 = NOVALUE;
    rhs_slice_target = (object_ptr)&_ns_68266;
    RHS_Slice(_ns_68266, 1, _33868);

    /** execute.e:2691			end while*/
    goto L2; // [127] 70
L3: 

    /** execute.e:2694			while length(ns) and (ns[1] = ' ' or ns[1] = '\t') do*/
L5: 
    if (IS_SEQUENCE(_ns_68266)){
            _33870 = SEQ_PTR(_ns_68266)->length;
    }
    else {
        _33870 = 1;
    }
    if (_33870 == 0) {
        goto L6; // [138] 185
    }
    _2 = (object)SEQ_PTR(_ns_68266);
    _33872 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_33872)) {
        _33873 = (_33872 == 32);
    }
    else {
        _33873 = binary_op(EQUALS, _33872, 32);
    }
    _33872 = NOVALUE;
    if (IS_ATOM_INT(_33873)) {
        if (_33873 != 0) {
            DeRef(_33874);
            _33874 = 1;
            goto L7; // [150] 166
        }
    }
    else {
        if (DBL_PTR(_33873)->dbl != 0.0) {
            DeRef(_33874);
            _33874 = 1;
            goto L7; // [150] 166
        }
    }
    _2 = (object)SEQ_PTR(_ns_68266);
    _33875 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_33875)) {
        _33876 = (_33875 == 9);
    }
    else {
        _33876 = binary_op(EQUALS, _33875, 9);
    }
    _33875 = NOVALUE;
    DeRef(_33874);
    if (IS_ATOM_INT(_33876))
    _33874 = (_33876 != 0);
    else
    _33874 = DBL_PTR(_33876)->dbl != 0.0;
L7: 
    if (_33874 == 0)
    {
        _33874 = NOVALUE;
        goto L6; // [167] 185
    }
    else{
        _33874 = NOVALUE;
    }

    /** execute.e:2695				ns = ns[2..$]*/
    if (IS_SEQUENCE(_ns_68266)){
            _33877 = SEQ_PTR(_ns_68266)->length;
    }
    else {
        _33877 = 1;
    }
    rhs_slice_target = (object_ptr)&_ns_68266;
    RHS_Slice(_ns_68266, 2, _33877);

    /** execute.e:2696			end while*/
    goto L5; // [182] 135
L6: 

    /** execute.e:2698			if length(ns) = 0 or equal( ns, "eu") then*/
    if (IS_SEQUENCE(_ns_68266)){
            _33879 = SEQ_PTR(_ns_68266)->length;
    }
    else {
        _33879 = 1;
    }
    _33880 = (_33879 == 0);
    _33879 = NOVALUE;
    if (_33880 != 0) {
        goto L8; // [194] 207
    }
    if (_ns_68266 == _23674)
    _33882 = 1;
    else if (IS_ATOM_INT(_ns_68266) && IS_ATOM_INT(_23674))
    _33882 = 0;
    else
    _33882 = (compare(_ns_68266, _23674) == 0);
    if (_33882 == 0)
    {
        _33882 = NOVALUE;
        goto L9; // [203] 214
    }
    else{
        _33882 = NOVALUE;
    }
L8: 

    /** execute.e:2699				return 0 -- bad syntax*/
    DeRefDS(_name_68258);
    DeRef(_ns_68266);
    DeRef(_33868);
    _33868 = NOVALUE;
    DeRef(_33866);
    _33866 = NOVALUE;
    DeRef(_33853);
    _33853 = NOVALUE;
    DeRef(_33876);
    _33876 = NOVALUE;
    DeRef(_33880);
    _33880 = NOVALUE;
    DeRef(_33862);
    _33862 = NOVALUE;
    DeRef(_33873);
    _33873 = NOVALUE;
    DeRef(_33855);
    _33855 = NOVALUE;
    return 0;
L9: 

    /** execute.e:2703			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33883 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    _2 = (object)SEQ_PTR(_33883);
    _s_68264 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68264)){
        _s_68264 = (object)DBL_PTR(_s_68264)->dbl;
    }
    _33883 = NOVALUE;

    /** execute.e:2704			while s != 0 do*/
LA: 
    if (_s_68264 == 0)
    goto LB; // [237] 335

    /** execute.e:2705				if file = SymTab[s][S_FILE_NO] and*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33886 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_33886);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _33887 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _33887 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _33886 = NOVALUE;
    if (IS_ATOM_INT(_33887)) {
        _33888 = (_file_68259 == _33887);
    }
    else {
        _33888 = binary_op(EQUALS, _file_68259, _33887);
    }
    _33887 = NOVALUE;
    if (IS_ATOM_INT(_33888)) {
        if (_33888 == 0) {
            DeRef(_33889);
            _33889 = 0;
            goto LC; // [259] 285
        }
    }
    else {
        if (DBL_PTR(_33888)->dbl == 0.0) {
            DeRef(_33889);
            _33889 = 0;
            goto LC; // [259] 285
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33890 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_33890);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _33891 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _33891 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _33890 = NOVALUE;
    if (IS_ATOM_INT(_33891)) {
        _33892 = (_33891 == 523);
    }
    else {
        _33892 = binary_op(EQUALS, _33891, 523);
    }
    _33891 = NOVALUE;
    DeRef(_33889);
    if (IS_ATOM_INT(_33892))
    _33889 = (_33892 != 0);
    else
    _33889 = DBL_PTR(_33892)->dbl != 0.0;
LC: 
    if (_33889 == 0) {
        goto LD; // [285] 314
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33894 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_33894);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _33895 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _33895 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _33894 = NOVALUE;
    if (_ns_68266 == _33895)
    _33896 = 1;
    else if (IS_ATOM_INT(_ns_68266) && IS_ATOM_INT(_33895))
    _33896 = 0;
    else
    _33896 = (compare(_ns_68266, _33895) == 0);
    _33895 = NOVALUE;
    if (_33896 == 0)
    {
        _33896 = NOVALUE;
        goto LD; // [306] 314
    }
    else{
        _33896 = NOVALUE;
    }

    /** execute.e:2708					exit*/
    goto LB; // [311] 335
LD: 

    /** execute.e:2710				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33897 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_33897);
    _s_68264 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68264)){
        _s_68264 = (object)DBL_PTR(_s_68264)->dbl;
    }
    _33897 = NOVALUE;

    /** execute.e:2711			end while*/
    goto LA; // [332] 237
LB: 

    /** execute.e:2713			if s = 0 then*/
    if (_s_68264 != 0)
    goto LE; // [337] 348

    /** execute.e:2714				return 0 -- couldn't find ns*/
    DeRefDS(_name_68258);
    DeRef(_ns_68266);
    DeRef(_33888);
    _33888 = NOVALUE;
    DeRef(_33868);
    _33868 = NOVALUE;
    DeRef(_33866);
    _33866 = NOVALUE;
    DeRef(_33853);
    _33853 = NOVALUE;
    DeRef(_33892);
    _33892 = NOVALUE;
    DeRef(_33876);
    _33876 = NOVALUE;
    DeRef(_33880);
    _33880 = NOVALUE;
    DeRef(_33862);
    _33862 = NOVALUE;
    DeRef(_33873);
    _33873 = NOVALUE;
    DeRef(_33855);
    _33855 = NOVALUE;
    return 0;
LE: 

    /** execute.e:2717			ns_file = val[s]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _ns_file_68268 = (object)*(((s1_ptr)_2)->base + _s_68264);
    if (!IS_ATOM_INT(_ns_file_68268))
    _ns_file_68268 = (object)DBL_PTR(_ns_file_68268)->dbl;

    /** execute.e:2720			while length(name) and (name[1] = ' ' or name[1] = '\t') do*/
LF: 
    if (IS_SEQUENCE(_name_68258)){
            _33901 = SEQ_PTR(_name_68258)->length;
    }
    else {
        _33901 = 1;
    }
    if (_33901 == 0) {
        goto L10; // [364] 411
    }
    _2 = (object)SEQ_PTR(_name_68258);
    _33903 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_33903)) {
        _33904 = (_33903 == 32);
    }
    else {
        _33904 = binary_op(EQUALS, _33903, 32);
    }
    _33903 = NOVALUE;
    if (IS_ATOM_INT(_33904)) {
        if (_33904 != 0) {
            DeRef(_33905);
            _33905 = 1;
            goto L11; // [376] 392
        }
    }
    else {
        if (DBL_PTR(_33904)->dbl != 0.0) {
            DeRef(_33905);
            _33905 = 1;
            goto L11; // [376] 392
        }
    }
    _2 = (object)SEQ_PTR(_name_68258);
    _33906 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_33906)) {
        _33907 = (_33906 == 9);
    }
    else {
        _33907 = binary_op(EQUALS, _33906, 9);
    }
    _33906 = NOVALUE;
    DeRef(_33905);
    if (IS_ATOM_INT(_33907))
    _33905 = (_33907 != 0);
    else
    _33905 = DBL_PTR(_33907)->dbl != 0.0;
L11: 
    if (_33905 == 0)
    {
        _33905 = NOVALUE;
        goto L10; // [393] 411
    }
    else{
        _33905 = NOVALUE;
    }

    /** execute.e:2721				name = name[2..$]*/
    if (IS_SEQUENCE(_name_68258)){
            _33908 = SEQ_PTR(_name_68258)->length;
    }
    else {
        _33908 = 1;
    }
    rhs_slice_target = (object_ptr)&_name_68258;
    RHS_Slice(_name_68258, 2, _33908);

    /** execute.e:2722			end while*/
    goto LF; // [408] 361
L10: 

    /** execute.e:2725			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33910 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    _2 = (object)SEQ_PTR(_33910);
    _s_68264 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68264)){
        _s_68264 = (object)DBL_PTR(_s_68264)->dbl;
    }
    _33910 = NOVALUE;

    /** execute.e:2726			while s != 0 and (s <= stlen or SymTab[s][S_SCOPE] = SC_PRIVATE) do*/
L12: 
    _33912 = (_s_68264 != 0);
    if (_33912 == 0) {
        goto L13; // [438] 818
    }
    _33914 = (_s_68264 <= _stlen_68262);
    if (_33914 != 0) {
        DeRef(_33915);
        _33915 = 1;
        goto L14; // [446] 472
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33916 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_33916);
    _33917 = (object)*(((s1_ptr)_2)->base + 4);
    _33916 = NOVALUE;
    if (IS_ATOM_INT(_33917)) {
        _33918 = (_33917 == 3);
    }
    else {
        _33918 = binary_op(EQUALS, _33917, 3);
    }
    _33917 = NOVALUE;
    if (IS_ATOM_INT(_33918))
    _33915 = (_33918 != 0);
    else
    _33915 = DBL_PTR(_33918)->dbl != 0.0;
L14: 
    if (_33915 == 0)
    {
        _33915 = NOVALUE;
        goto L13; // [473] 818
    }
    else{
        _33915 = NOVALUE;
    }

    /** execute.e:2727				integer scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33919 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_33919);
    _scope_68368 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_68368)){
        _scope_68368 = (object)DBL_PTR(_scope_68368)->dbl;
    }
    _33919 = NOVALUE;

    /** execute.e:2728				if (((scope = SC_PUBLIC) and*/
    _33921 = (_scope_68368 == 13);
    if (_33921 == 0) {
        _33922 = 0;
        goto L15; // [500] 584
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33923 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_33923);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _33924 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _33924 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _33923 = NOVALUE;
    if (IS_ATOM_INT(_33924)) {
        _33925 = (_33924 == _ns_file_68268);
    }
    else {
        _33925 = binary_op(EQUALS, _33924, _ns_file_68268);
    }
    _33924 = NOVALUE;
    if (IS_ATOM_INT(_33925)) {
        if (_33925 != 0) {
            DeRef(_33926);
            _33926 = 1;
            goto L16; // [520] 580
        }
    }
    else {
        if (DBL_PTR(_33925)->dbl != 0.0) {
            DeRef(_33926);
            _33926 = 1;
            goto L16; // [520] 580
        }
    }
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _33927 = (object)*(((s1_ptr)_2)->base + _ns_file_68268);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33928 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_33928);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _33929 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _33929 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _33928 = NOVALUE;
    _2 = (object)SEQ_PTR(_33927);
    if (!IS_ATOM_INT(_33929)){
        _33930 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33929)->dbl));
    }
    else{
        _33930 = (object)*(((s1_ptr)_2)->base + _33929);
    }
    _33927 = NOVALUE;
    if (IS_ATOM_INT(_33930)) {
        {uintptr_t tu;
             tu = (uintptr_t)4 & (uintptr_t)_33930;
             _33931 = MAKE_UINT(tu);
        }
    }
    else {
        _33931 = binary_op(AND_BITS, 4, _33930);
    }
    _33930 = NOVALUE;
    if (IS_ATOM_INT(_33931)) {
        if (_33931 == 0) {
            DeRef(_33932);
            _33932 = 0;
            goto L17; // [552] 576
        }
    }
    else {
        if (DBL_PTR(_33931)->dbl == 0.0) {
            DeRef(_33932);
            _33932 = 0;
            goto L17; // [552] 576
        }
    }
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _33933 = (object)*(((s1_ptr)_2)->base + _file_68259);
    _2 = (object)SEQ_PTR(_33933);
    _33934 = (object)*(((s1_ptr)_2)->base + _ns_file_68268);
    _33933 = NOVALUE;
    if (IS_ATOM_INT(_33934)) {
        {uintptr_t tu;
             tu = (uintptr_t)6 & (uintptr_t)_33934;
             _33935 = MAKE_UINT(tu);
        }
    }
    else {
        _33935 = binary_op(AND_BITS, 6, _33934);
    }
    _33934 = NOVALUE;
    DeRef(_33932);
    if (IS_ATOM_INT(_33935))
    _33932 = (_33935 != 0);
    else
    _33932 = DBL_PTR(_33935)->dbl != 0.0;
L17: 
    DeRef(_33926);
    _33926 = (_33932 != 0);
L16: 
    _33922 = (_33926 != 0);
L15: 
    if (_33922 != 0) {
        _33936 = 1;
        goto L18; // [584] 646
    }
    _33937 = (_scope_68368 == 11);
    if (_33937 == 0) {
        _33938 = 0;
        goto L19; // [594] 618
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33939 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_33939);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _33940 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _33940 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _33939 = NOVALUE;
    if (IS_ATOM_INT(_33940)) {
        _33941 = (_33940 == _ns_file_68268);
    }
    else {
        _33941 = binary_op(EQUALS, _33940, _ns_file_68268);
    }
    _33940 = NOVALUE;
    if (IS_ATOM_INT(_33941))
    _33938 = (_33941 != 0);
    else
    _33938 = DBL_PTR(_33941)->dbl != 0.0;
L19: 
    if (_33938 == 0) {
        _33942 = 0;
        goto L1A; // [618] 642
    }
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _33943 = (object)*(((s1_ptr)_2)->base + _file_68259);
    _2 = (object)SEQ_PTR(_33943);
    _33944 = (object)*(((s1_ptr)_2)->base + _ns_file_68268);
    _33943 = NOVALUE;
    if (IS_ATOM_INT(_33944)) {
        {uintptr_t tu;
             tu = (uintptr_t)2 & (uintptr_t)_33944;
             _33945 = MAKE_UINT(tu);
        }
    }
    else {
        _33945 = binary_op(AND_BITS, 2, _33944);
    }
    _33944 = NOVALUE;
    if (IS_ATOM_INT(_33945))
    _33942 = (_33945 != 0);
    else
    _33942 = DBL_PTR(_33945)->dbl != 0.0;
L1A: 
    _33936 = (_33942 != 0);
L18: 
    if (_33936 != 0) {
        _33946 = 1;
        goto L1B; // [646] 660
    }
    _33947 = (_scope_68368 == 6);
    _33946 = (_33947 != 0);
L1B: 
    if (_33946 == 0) {
        _33948 = 0;
        goto L1C; // [660] 738
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33949 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_33949);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _33950 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _33950 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _33949 = NOVALUE;
    if (IS_ATOM_INT(_33950)) {
        _33951 = (_33950 == _ns_file_68268);
    }
    else {
        _33951 = binary_op(EQUALS, _33950, _ns_file_68268);
    }
    _33950 = NOVALUE;
    if (IS_ATOM_INT(_33951)) {
        if (_33951 != 0) {
            DeRef(_33952);
            _33952 = 1;
            goto L1D; // [680] 734
        }
    }
    else {
        if (DBL_PTR(_33951)->dbl != 0.0) {
            DeRef(_33952);
            _33952 = 1;
            goto L1D; // [680] 734
        }
    }
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _33953 = (object)*(((s1_ptr)_2)->base + _ns_file_68268);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33954 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_33954);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _33955 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _33955 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _33954 = NOVALUE;
    _2 = (object)SEQ_PTR(_33953);
    if (!IS_ATOM_INT(_33955)){
        _33956 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33955)->dbl));
    }
    else{
        _33956 = (object)*(((s1_ptr)_2)->base + _33955);
    }
    _33953 = NOVALUE;
    if (IS_ATOM_INT(_33956)) {
        if (_33956 == 0) {
            DeRef(_33957);
            _33957 = 0;
            goto L1E; // [706] 730
        }
    }
    else {
        if (DBL_PTR(_33956)->dbl == 0.0) {
            DeRef(_33957);
            _33957 = 0;
            goto L1E; // [706] 730
        }
    }
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _33958 = (object)*(((s1_ptr)_2)->base + _file_68259);
    _2 = (object)SEQ_PTR(_33958);
    _33959 = (object)*(((s1_ptr)_2)->base + _ns_file_68268);
    _33958 = NOVALUE;
    if (IS_ATOM_INT(_33959)) {
        {uintptr_t tu;
             tu = (uintptr_t)6 & (uintptr_t)_33959;
             _33960 = MAKE_UINT(tu);
        }
    }
    else {
        _33960 = binary_op(AND_BITS, 6, _33959);
    }
    _33959 = NOVALUE;
    DeRef(_33957);
    if (IS_ATOM_INT(_33960))
    _33957 = (_33960 != 0);
    else
    _33957 = DBL_PTR(_33960)->dbl != 0.0;
L1E: 
    DeRef(_33952);
    _33952 = (_33957 != 0);
L1D: 
    _33948 = (_33952 != 0);
L1C: 
    if (_33948 != 0) {
        _33961 = 1;
        goto L1F; // [738] 764
    }
    _33962 = (_scope_68368 == 5);
    if (_33962 == 0) {
        _33963 = 0;
        goto L20; // [748] 760
    }
    _33964 = (_ns_file_68268 == _file_68259);
    _33963 = (_33964 != 0);
L20: 
    _33961 = (_33963 != 0);
L1F: 
    if (_33961 == 0) {
        goto L21; // [764] 795
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33966 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_33966);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _33967 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _33967 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _33966 = NOVALUE;
    if (_33967 == _name_68258)
    _33968 = 1;
    else if (IS_ATOM_INT(_33967) && IS_ATOM_INT(_name_68258))
    _33968 = 0;
    else
    _33968 = (compare(_33967, _name_68258) == 0);
    _33967 = NOVALUE;
    if (_33968 == 0)
    {
        _33968 = NOVALUE;
        goto L21; // [785] 795
    }
    else{
        _33968 = NOVALUE;
    }

    /** execute.e:2744					return s*/
    DeRefDS(_name_68258);
    DeRef(_ns_68266);
    DeRef(_33888);
    _33888 = NOVALUE;
    DeRef(_33947);
    _33947 = NOVALUE;
    DeRef(_33868);
    _33868 = NOVALUE;
    _33956 = NOVALUE;
    DeRef(_33912);
    _33912 = NOVALUE;
    DeRef(_33921);
    _33921 = NOVALUE;
    DeRef(_33866);
    _33866 = NOVALUE;
    _33929 = NOVALUE;
    DeRef(_33853);
    _33853 = NOVALUE;
    DeRef(_33892);
    _33892 = NOVALUE;
    DeRef(_33876);
    _33876 = NOVALUE;
    DeRef(_33964);
    _33964 = NOVALUE;
    DeRef(_33880);
    _33880 = NOVALUE;
    DeRef(_33862);
    _33862 = NOVALUE;
    DeRef(_33907);
    _33907 = NOVALUE;
    DeRef(_33904);
    _33904 = NOVALUE;
    DeRef(_33873);
    _33873 = NOVALUE;
    DeRef(_33918);
    _33918 = NOVALUE;
    DeRef(_33945);
    _33945 = NOVALUE;
    DeRef(_33960);
    _33960 = NOVALUE;
    DeRef(_33931);
    _33931 = NOVALUE;
    _33955 = NOVALUE;
    DeRef(_33941);
    _33941 = NOVALUE;
    DeRef(_33935);
    _33935 = NOVALUE;
    DeRef(_33914);
    _33914 = NOVALUE;
    DeRef(_33962);
    _33962 = NOVALUE;
    DeRef(_33925);
    _33925 = NOVALUE;
    DeRef(_33951);
    _33951 = NOVALUE;
    DeRef(_33855);
    _33855 = NOVALUE;
    DeRef(_33937);
    _33937 = NOVALUE;
    return _s_68264;
L21: 

    /** execute.e:2746				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33969 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_33969);
    _s_68264 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68264)){
        _s_68264 = (object)DBL_PTR(_s_68264)->dbl;
    }
    _33969 = NOVALUE;

    /** execute.e:2747			end while*/
    goto L12; // [815] 434
L13: 

    /** execute.e:2749			return 0 -- couldn't find name in ns file*/
    DeRefDS(_name_68258);
    DeRef(_ns_68266);
    DeRef(_33888);
    _33888 = NOVALUE;
    DeRef(_33947);
    _33947 = NOVALUE;
    DeRef(_33868);
    _33868 = NOVALUE;
    _33956 = NOVALUE;
    DeRef(_33912);
    _33912 = NOVALUE;
    DeRef(_33921);
    _33921 = NOVALUE;
    DeRef(_33866);
    _33866 = NOVALUE;
    _33929 = NOVALUE;
    DeRef(_33853);
    _33853 = NOVALUE;
    DeRef(_33892);
    _33892 = NOVALUE;
    DeRef(_33876);
    _33876 = NOVALUE;
    DeRef(_33964);
    _33964 = NOVALUE;
    DeRef(_33880);
    _33880 = NOVALUE;
    DeRef(_33862);
    _33862 = NOVALUE;
    DeRef(_33907);
    _33907 = NOVALUE;
    DeRef(_33904);
    _33904 = NOVALUE;
    DeRef(_33873);
    _33873 = NOVALUE;
    DeRef(_33918);
    _33918 = NOVALUE;
    DeRef(_33945);
    _33945 = NOVALUE;
    DeRef(_33960);
    _33960 = NOVALUE;
    DeRef(_33931);
    _33931 = NOVALUE;
    _33955 = NOVALUE;
    DeRef(_33941);
    _33941 = NOVALUE;
    DeRef(_33935);
    _33935 = NOVALUE;
    DeRef(_33914);
    _33914 = NOVALUE;
    DeRef(_33962);
    _33962 = NOVALUE;
    DeRef(_33925);
    _33925 = NOVALUE;
    DeRef(_33951);
    _33951 = NOVALUE;
    DeRef(_33855);
    _33855 = NOVALUE;
    DeRef(_33937);
    _33937 = NOVALUE;
    return 0;
    goto L22; // [824] 1636
L1: 

    /** execute.e:2754			if proc != TopLevelSub then*/
    if (_proc_68261 == _12TopLevelSub_20233)
    goto L23; // [831] 958

    /** execute.e:2756				s = SymTab[proc][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33972 = (object)*(((s1_ptr)_2)->base + _proc_68261);
    _2 = (object)SEQ_PTR(_33972);
    _s_68264 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68264)){
        _s_68264 = (object)DBL_PTR(_s_68264)->dbl;
    }
    _33972 = NOVALUE;

    /** execute.e:2757				while s and (SymTab[s][S_SCOPE] = SC_PRIVATE or*/
L24: 
    if (_s_68264 == 0) {
        goto L25; // [856] 957
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33975 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_33975);
    _33976 = (object)*(((s1_ptr)_2)->base + 4);
    _33975 = NOVALUE;
    if (IS_ATOM_INT(_33976)) {
        _33977 = (_33976 == 3);
    }
    else {
        _33977 = binary_op(EQUALS, _33976, 3);
    }
    _33976 = NOVALUE;
    if (IS_ATOM_INT(_33977)) {
        if (_33977 != 0) {
            DeRef(_33978);
            _33978 = 1;
            goto L26; // [878] 904
        }
    }
    else {
        if (DBL_PTR(_33977)->dbl != 0.0) {
            DeRef(_33978);
            _33978 = 1;
            goto L26; // [878] 904
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33979 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_33979);
    _33980 = (object)*(((s1_ptr)_2)->base + 4);
    _33979 = NOVALUE;
    if (IS_ATOM_INT(_33980)) {
        _33981 = (_33980 == 2);
    }
    else {
        _33981 = binary_op(EQUALS, _33980, 2);
    }
    _33980 = NOVALUE;
    DeRef(_33978);
    if (IS_ATOM_INT(_33981))
    _33978 = (_33981 != 0);
    else
    _33978 = DBL_PTR(_33981)->dbl != 0.0;
L26: 
    if (_33978 == 0)
    {
        _33978 = NOVALUE;
        goto L25; // [905] 957
    }
    else{
        _33978 = NOVALUE;
    }

    /** execute.e:2759					if equal(name, SymTab[s][S_NAME]) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33982 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_33982);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _33983 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _33983 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _33982 = NOVALUE;
    if (_name_68258 == _33983)
    _33984 = 1;
    else if (IS_ATOM_INT(_name_68258) && IS_ATOM_INT(_33983))
    _33984 = 0;
    else
    _33984 = (compare(_name_68258, _33983) == 0);
    _33983 = NOVALUE;
    if (_33984 == 0)
    {
        _33984 = NOVALUE;
        goto L27; // [926] 936
    }
    else{
        _33984 = NOVALUE;
    }

    /** execute.e:2760						return s*/
    DeRefDS(_name_68258);
    DeRef(_ns_68266);
    DeRef(_33888);
    _33888 = NOVALUE;
    DeRef(_33947);
    _33947 = NOVALUE;
    DeRef(_33868);
    _33868 = NOVALUE;
    _33956 = NOVALUE;
    DeRef(_33912);
    _33912 = NOVALUE;
    DeRef(_33921);
    _33921 = NOVALUE;
    DeRef(_33866);
    _33866 = NOVALUE;
    _33929 = NOVALUE;
    DeRef(_33853);
    _33853 = NOVALUE;
    DeRef(_33892);
    _33892 = NOVALUE;
    DeRef(_33876);
    _33876 = NOVALUE;
    DeRef(_33964);
    _33964 = NOVALUE;
    DeRef(_33880);
    _33880 = NOVALUE;
    DeRef(_33862);
    _33862 = NOVALUE;
    DeRef(_33907);
    _33907 = NOVALUE;
    DeRef(_33904);
    _33904 = NOVALUE;
    DeRef(_33873);
    _33873 = NOVALUE;
    DeRef(_33918);
    _33918 = NOVALUE;
    DeRef(_33945);
    _33945 = NOVALUE;
    DeRef(_33960);
    _33960 = NOVALUE;
    DeRef(_33931);
    _33931 = NOVALUE;
    _33955 = NOVALUE;
    DeRef(_33981);
    _33981 = NOVALUE;
    DeRef(_33941);
    _33941 = NOVALUE;
    DeRef(_33935);
    _33935 = NOVALUE;
    DeRef(_33914);
    _33914 = NOVALUE;
    DeRef(_33962);
    _33962 = NOVALUE;
    DeRef(_33977);
    _33977 = NOVALUE;
    DeRef(_33925);
    _33925 = NOVALUE;
    DeRef(_33951);
    _33951 = NOVALUE;
    DeRef(_33855);
    _33855 = NOVALUE;
    DeRef(_33937);
    _33937 = NOVALUE;
    return _s_68264;
L27: 

    /** execute.e:2762					s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33985 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_33985);
    _s_68264 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68264)){
        _s_68264 = (object)DBL_PTR(_s_68264)->dbl;
    }
    _33985 = NOVALUE;

    /** execute.e:2763				end while*/
    goto L24; // [954] 856
L25: 
L23: 

    /** execute.e:2767			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33987 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    _2 = (object)SEQ_PTR(_33987);
    _s_68264 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68264)){
        _s_68264 = (object)DBL_PTR(_s_68264)->dbl;
    }
    _33987 = NOVALUE;

    /** execute.e:2768			found_in_path = 0*/
    _found_in_path_68269 = 0;

    /** execute.e:2769			found_outside_path = 0*/
    _found_outside_path_68270 = 0;

    /** execute.e:2771			while s != 0 and (s <= stlen or SymTab[s][S_SCOPE] = SC_PRIVATE) do*/
L28: 
    _33989 = (_s_68264 != 0);
    if (_33989 == 0) {
        goto L29; // [995] 1221
    }
    _33991 = (_s_68264 <= _stlen_68262);
    if (_33991 != 0) {
        DeRef(_33992);
        _33992 = 1;
        goto L2A; // [1003] 1029
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33993 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_33993);
    _33994 = (object)*(((s1_ptr)_2)->base + 4);
    _33993 = NOVALUE;
    if (IS_ATOM_INT(_33994)) {
        _33995 = (_33994 == 3);
    }
    else {
        _33995 = binary_op(EQUALS, _33994, 3);
    }
    _33994 = NOVALUE;
    if (IS_ATOM_INT(_33995))
    _33992 = (_33995 != 0);
    else
    _33992 = DBL_PTR(_33995)->dbl != 0.0;
L2A: 
    if (_33992 == 0)
    {
        _33992 = NOVALUE;
        goto L29; // [1030] 1221
    }
    else{
        _33992 = NOVALUE;
    }

    /** execute.e:2773				if SymTab[s][S_FILE_NO] = file and*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33996 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_33996);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _33997 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _33997 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _33996 = NOVALUE;
    if (IS_ATOM_INT(_33997)) {
        _33998 = (_33997 == _file_68259);
    }
    else {
        _33998 = binary_op(EQUALS, _33997, _file_68259);
    }
    _33997 = NOVALUE;
    if (IS_ATOM_INT(_33998)) {
        if (_33998 == 0) {
            DeRef(_33999);
            _33999 = 0;
            goto L2B; // [1051] 1169
        }
    }
    else {
        if (DBL_PTR(_33998)->dbl == 0.0) {
            DeRef(_33999);
            _33999 = 0;
            goto L2B; // [1051] 1169
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34000 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_34000);
    _34001 = (object)*(((s1_ptr)_2)->base + 4);
    _34000 = NOVALUE;
    if (IS_ATOM_INT(_34001)) {
        _34002 = (_34001 == 5);
    }
    else {
        _34002 = binary_op(EQUALS, _34001, 5);
    }
    _34001 = NOVALUE;
    if (IS_ATOM_INT(_34002)) {
        if (_34002 != 0) {
            DeRef(_34003);
            _34003 = 1;
            goto L2C; // [1073] 1099
        }
    }
    else {
        if (DBL_PTR(_34002)->dbl != 0.0) {
            DeRef(_34003);
            _34003 = 1;
            goto L2C; // [1073] 1099
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34004 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_34004);
    _34005 = (object)*(((s1_ptr)_2)->base + 4);
    _34004 = NOVALUE;
    if (IS_ATOM_INT(_34005)) {
        _34006 = (_34005 == 6);
    }
    else {
        _34006 = binary_op(EQUALS, _34005, 6);
    }
    _34005 = NOVALUE;
    DeRef(_34003);
    if (IS_ATOM_INT(_34006))
    _34003 = (_34006 != 0);
    else
    _34003 = DBL_PTR(_34006)->dbl != 0.0;
L2C: 
    if (_34003 != 0) {
        _34007 = 1;
        goto L2D; // [1099] 1125
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34008 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_34008);
    _34009 = (object)*(((s1_ptr)_2)->base + 4);
    _34008 = NOVALUE;
    if (IS_ATOM_INT(_34009)) {
        _34010 = (_34009 == 11);
    }
    else {
        _34010 = binary_op(EQUALS, _34009, 11);
    }
    _34009 = NOVALUE;
    if (IS_ATOM_INT(_34010))
    _34007 = (_34010 != 0);
    else
    _34007 = DBL_PTR(_34010)->dbl != 0.0;
L2D: 
    if (_34007 != 0) {
        _34011 = 1;
        goto L2E; // [1125] 1165
    }
    _34012 = (_proc_68261 == _12TopLevelSub_20233);
    if (_34012 == 0) {
        _34013 = 0;
        goto L2F; // [1135] 1161
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34014 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_34014);
    _34015 = (object)*(((s1_ptr)_2)->base + 4);
    _34014 = NOVALUE;
    if (IS_ATOM_INT(_34015)) {
        _34016 = (_34015 == 4);
    }
    else {
        _34016 = binary_op(EQUALS, _34015, 4);
    }
    _34015 = NOVALUE;
    if (IS_ATOM_INT(_34016))
    _34013 = (_34016 != 0);
    else
    _34013 = DBL_PTR(_34016)->dbl != 0.0;
L2F: 
    _34011 = (_34013 != 0);
L2E: 
    DeRef(_33999);
    _33999 = (_34011 != 0);
L2B: 
    if (_33999 == 0) {
        goto L30; // [1169] 1200
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34018 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_34018);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _34019 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _34019 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _34018 = NOVALUE;
    if (_name_68258 == _34019)
    _34020 = 1;
    else if (IS_ATOM_INT(_name_68258) && IS_ATOM_INT(_34019))
    _34020 = 0;
    else
    _34020 = (compare(_name_68258, _34019) == 0);
    _34019 = NOVALUE;
    if (_34020 == 0)
    {
        _34020 = NOVALUE;
        goto L30; // [1190] 1200
    }
    else{
        _34020 = NOVALUE;
    }

    /** execute.e:2782					return s*/
    DeRefDS(_name_68258);
    DeRef(_ns_68266);
    DeRef(_34012);
    _34012 = NOVALUE;
    DeRef(_33888);
    _33888 = NOVALUE;
    DeRef(_34006);
    _34006 = NOVALUE;
    DeRef(_33947);
    _33947 = NOVALUE;
    DeRef(_33868);
    _33868 = NOVALUE;
    _33956 = NOVALUE;
    DeRef(_33912);
    _33912 = NOVALUE;
    DeRef(_33991);
    _33991 = NOVALUE;
    DeRef(_33921);
    _33921 = NOVALUE;
    DeRef(_34016);
    _34016 = NOVALUE;
    DeRef(_33866);
    _33866 = NOVALUE;
    _33929 = NOVALUE;
    DeRef(_33853);
    _33853 = NOVALUE;
    DeRef(_33892);
    _33892 = NOVALUE;
    DeRef(_34010);
    _34010 = NOVALUE;
    DeRef(_33876);
    _33876 = NOVALUE;
    DeRef(_33998);
    _33998 = NOVALUE;
    DeRef(_33964);
    _33964 = NOVALUE;
    DeRef(_33880);
    _33880 = NOVALUE;
    DeRef(_33862);
    _33862 = NOVALUE;
    DeRef(_33907);
    _33907 = NOVALUE;
    DeRef(_33904);
    _33904 = NOVALUE;
    DeRef(_33873);
    _33873 = NOVALUE;
    DeRef(_33918);
    _33918 = NOVALUE;
    DeRef(_33945);
    _33945 = NOVALUE;
    DeRef(_33960);
    _33960 = NOVALUE;
    DeRef(_33931);
    _33931 = NOVALUE;
    _33955 = NOVALUE;
    DeRef(_33981);
    _33981 = NOVALUE;
    DeRef(_33941);
    _33941 = NOVALUE;
    DeRef(_33935);
    _33935 = NOVALUE;
    DeRef(_33914);
    _33914 = NOVALUE;
    DeRef(_33989);
    _33989 = NOVALUE;
    DeRef(_33962);
    _33962 = NOVALUE;
    DeRef(_33977);
    _33977 = NOVALUE;
    DeRef(_33925);
    _33925 = NOVALUE;
    DeRef(_33951);
    _33951 = NOVALUE;
    DeRef(_33855);
    _33855 = NOVALUE;
    DeRef(_33937);
    _33937 = NOVALUE;
    DeRef(_33995);
    _33995 = NOVALUE;
    DeRef(_34002);
    _34002 = NOVALUE;
    return _s_68264;
L30: 

    /** execute.e:2784				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34021 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_34021);
    _s_68264 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68264)){
        _s_68264 = (object)DBL_PTR(_s_68264)->dbl;
    }
    _34021 = NOVALUE;

    /** execute.e:2785			end while*/
    goto L28; // [1218] 991
L29: 

    /** execute.e:2787			global_found = FALSE*/
    _global_found_68265 = _9FALSE_444;

    /** execute.e:2788			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34023 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    _2 = (object)SEQ_PTR(_34023);
    _s_68264 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68264)){
        _s_68264 = (object)DBL_PTR(_s_68264)->dbl;
    }
    _34023 = NOVALUE;

    /** execute.e:2789			while s != 0 and (s <= stlen or SymTab[s][S_SCOPE] = SC_PRIVATE) do*/
L31: 
    _34025 = (_s_68264 != 0);
    if (_34025 == 0) {
        goto L32; // [1257] 1600
    }
    _34027 = (_s_68264 <= _stlen_68262);
    if (_34027 != 0) {
        DeRef(_34028);
        _34028 = 1;
        goto L33; // [1265] 1291
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34029 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_34029);
    _34030 = (object)*(((s1_ptr)_2)->base + 4);
    _34029 = NOVALUE;
    if (IS_ATOM_INT(_34030)) {
        _34031 = (_34030 == 3);
    }
    else {
        _34031 = binary_op(EQUALS, _34030, 3);
    }
    _34030 = NOVALUE;
    if (IS_ATOM_INT(_34031))
    _34028 = (_34031 != 0);
    else
    _34028 = DBL_PTR(_34031)->dbl != 0.0;
L33: 
    if (_34028 == 0)
    {
        _34028 = NOVALUE;
        goto L32; // [1292] 1600
    }
    else{
        _34028 = NOVALUE;
    }

    /** execute.e:2790				if SymTab[s][S_SCOPE] = SC_GLOBAL and*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34032 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_34032);
    _34033 = (object)*(((s1_ptr)_2)->base + 4);
    _34032 = NOVALUE;
    if (IS_ATOM_INT(_34033)) {
        _34034 = (_34033 == 6);
    }
    else {
        _34034 = binary_op(EQUALS, _34033, 6);
    }
    _34033 = NOVALUE;
    if (IS_ATOM_INT(_34034)) {
        if (_34034 == 0) {
            goto L34; // [1315] 1413
        }
    }
    else {
        if (DBL_PTR(_34034)->dbl == 0.0) {
            goto L34; // [1315] 1413
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34036 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_34036);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _34037 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _34037 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _34036 = NOVALUE;
    if (_name_68258 == _34037)
    _34038 = 1;
    else if (IS_ATOM_INT(_name_68258) && IS_ATOM_INT(_34037))
    _34038 = 0;
    else
    _34038 = (compare(_name_68258, _34037) == 0);
    _34037 = NOVALUE;
    if (_34038 == 0)
    {
        _34038 = NOVALUE;
        goto L34; // [1336] 1413
    }
    else{
        _34038 = NOVALUE;
    }

    /** execute.e:2793					s_in_include_path = include_matrix[file][SymTab[s][S_FILE_NO]] != 0*/
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _34039 = (object)*(((s1_ptr)_2)->base + _file_68259);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34040 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_34040);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _34041 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _34041 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _34040 = NOVALUE;
    _2 = (object)SEQ_PTR(_34039);
    if (!IS_ATOM_INT(_34041)){
        _34042 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34041)->dbl));
    }
    else{
        _34042 = (object)*(((s1_ptr)_2)->base + _34041);
    }
    _34039 = NOVALUE;
    if (IS_ATOM_INT(_34042)) {
        _s_in_include_path_68271 = (_34042 != 0);
    }
    else {
        _s_in_include_path_68271 = binary_op(NOTEQ, _34042, 0);
    }
    _34042 = NOVALUE;
    if (!IS_ATOM_INT(_s_in_include_path_68271)) {
        _1 = (object)(DBL_PTR(_s_in_include_path_68271)->dbl);
        DeRefDS(_s_in_include_path_68271);
        _s_in_include_path_68271 = _1;
    }

    /** execute.e:2794					if s_in_include_path then*/
    if (_s_in_include_path_68271 == 0)
    {
        goto L35; // [1371] 1390
    }
    else{
    }

    /** execute.e:2795						global_found = s*/
    _global_found_68265 = _s_68264;

    /** execute.e:2796						found_in_path += 1*/
    _found_in_path_68269 = _found_in_path_68269 + 1;
    goto L36; // [1387] 1579
L35: 

    /** execute.e:2798						if not found_in_path then*/
    if (_found_in_path_68269 != 0)
    goto L37; // [1392] 1403

    /** execute.e:2799							global_found = s*/
    _global_found_68265 = _s_68264;
L37: 

    /** execute.e:2801						found_outside_path += 1*/
    _found_outside_path_68270 = _found_outside_path_68270 + 1;
    goto L36; // [1410] 1579
L34: 

    /** execute.e:2803				elsif (sym_scope( s ) = SC_PUBLIC and equal( name, SymTab[s][S_NAME] ) and*/
    _34047 = _53sym_scope(_s_68264);
    if (IS_ATOM_INT(_34047)) {
        _34048 = (_34047 == 13);
    }
    else {
        _34048 = binary_op(EQUALS, _34047, 13);
    }
    DeRef(_34047);
    _34047 = NOVALUE;
    if (IS_ATOM_INT(_34048)) {
        if (_34048 == 0) {
            DeRef(_34049);
            _34049 = 0;
            goto L38; // [1425] 1449
        }
    }
    else {
        if (DBL_PTR(_34048)->dbl == 0.0) {
            DeRef(_34049);
            _34049 = 0;
            goto L38; // [1425] 1449
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34050 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_34050);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _34051 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _34051 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _34050 = NOVALUE;
    if (_name_68258 == _34051)
    _34052 = 1;
    else if (IS_ATOM_INT(_name_68258) && IS_ATOM_INT(_34051))
    _34052 = 0;
    else
    _34052 = (compare(_name_68258, _34051) == 0);
    _34051 = NOVALUE;
    DeRef(_34049);
    _34049 = (_34052 != 0);
L38: 
    if (_34049 == 0) {
        _34053 = 0;
        goto L39; // [1449] 1485
    }
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _34054 = (object)*(((s1_ptr)_2)->base + _file_68259);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34055 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_34055);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _34056 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _34056 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _34055 = NOVALUE;
    _2 = (object)SEQ_PTR(_34054);
    if (!IS_ATOM_INT(_34056)){
        _34057 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34056)->dbl));
    }
    else{
        _34057 = (object)*(((s1_ptr)_2)->base + _34056);
    }
    _34054 = NOVALUE;
    if (IS_ATOM_INT(_34057)) {
        {uintptr_t tu;
             tu = (uintptr_t)6 & (uintptr_t)_34057;
             _34058 = MAKE_UINT(tu);
        }
    }
    else {
        _34058 = binary_op(AND_BITS, 6, _34057);
    }
    _34057 = NOVALUE;
    if (IS_ATOM_INT(_34058))
    _34053 = (_34058 != 0);
    else
    _34053 = DBL_PTR(_34058)->dbl != 0.0;
L39: 
    if (_34053 != 0) {
        goto L3A; // [1485] 1564
    }
    _34060 = _53sym_scope(_s_68264);
    if (IS_ATOM_INT(_34060)) {
        _34061 = (_34060 == 11);
    }
    else {
        _34061 = binary_op(EQUALS, _34060, 11);
    }
    DeRef(_34060);
    _34060 = NOVALUE;
    if (IS_ATOM_INT(_34061)) {
        if (_34061 == 0) {
            DeRef(_34062);
            _34062 = 0;
            goto L3B; // [1499] 1523
        }
    }
    else {
        if (DBL_PTR(_34061)->dbl == 0.0) {
            DeRef(_34062);
            _34062 = 0;
            goto L3B; // [1499] 1523
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34063 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_34063);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _34064 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _34064 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _34063 = NOVALUE;
    if (_name_68258 == _34064)
    _34065 = 1;
    else if (IS_ATOM_INT(_name_68258) && IS_ATOM_INT(_34064))
    _34065 = 0;
    else
    _34065 = (compare(_name_68258, _34064) == 0);
    _34064 = NOVALUE;
    DeRef(_34062);
    _34062 = (_34065 != 0);
L3B: 
    if (_34062 == 0) {
        DeRef(_34066);
        _34066 = 0;
        goto L3C; // [1523] 1559
    }
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _34067 = (object)*(((s1_ptr)_2)->base + _file_68259);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34068 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_34068);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _34069 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _34069 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _34068 = NOVALUE;
    _2 = (object)SEQ_PTR(_34067);
    if (!IS_ATOM_INT(_34069)){
        _34070 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34069)->dbl));
    }
    else{
        _34070 = (object)*(((s1_ptr)_2)->base + _34069);
    }
    _34067 = NOVALUE;
    if (IS_ATOM_INT(_34070)) {
        {uintptr_t tu;
             tu = (uintptr_t)2 & (uintptr_t)_34070;
             _34071 = MAKE_UINT(tu);
        }
    }
    else {
        _34071 = binary_op(AND_BITS, 2, _34070);
    }
    _34070 = NOVALUE;
    if (IS_ATOM_INT(_34071))
    _34066 = (_34071 != 0);
    else
    _34066 = DBL_PTR(_34071)->dbl != 0.0;
L3C: 
    if (_34066 == 0)
    {
        _34066 = NOVALUE;
        goto L3D; // [1560] 1578
    }
    else{
        _34066 = NOVALUE;
    }
L3A: 

    /** execute.e:2808					global_found = s*/
    _global_found_68265 = _s_68264;

    /** execute.e:2809					found_in_path += 1*/
    _found_in_path_68269 = _found_in_path_68269 + 1;
L3D: 
L36: 

    /** execute.e:2811				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34073 = (object)*(((s1_ptr)_2)->base + _s_68264);
    _2 = (object)SEQ_PTR(_34073);
    _s_68264 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68264)){
        _s_68264 = (object)DBL_PTR(_s_68264)->dbl;
    }
    _34073 = NOVALUE;

    /** execute.e:2812			end while*/
    goto L31; // [1597] 1253
L32: 

    /** execute.e:2814			if found_in_path != 1 and (( found_in_path + found_outside_path ) != 1 ) then*/
    _34075 = (_found_in_path_68269 != 1);
    if (_34075 == 0) {
        goto L3E; // [1606] 1629
    }
    _34077 = _found_in_path_68269 + _found_outside_path_68270;
    if ((object)((uintptr_t)_34077 + (uintptr_t)HIGH_BITS) >= 0){
        _34077 = NewDouble((eudouble)_34077);
    }
    if (IS_ATOM_INT(_34077)) {
        _34078 = (_34077 != 1);
    }
    else {
        _34078 = (DBL_PTR(_34077)->dbl != (eudouble)1);
    }
    DeRef(_34077);
    _34077 = NOVALUE;
    if (_34078 == 0)
    {
        DeRef(_34078);
        _34078 = NOVALUE;
        goto L3E; // [1619] 1629
    }
    else{
        DeRef(_34078);
        _34078 = NOVALUE;
    }

    /** execute.e:2815				return 0*/
    DeRefDS(_name_68258);
    DeRef(_ns_68266);
    DeRef(_34071);
    _34071 = NOVALUE;
    DeRef(_34012);
    _34012 = NOVALUE;
    _34041 = NOVALUE;
    DeRef(_33888);
    _33888 = NOVALUE;
    DeRef(_34006);
    _34006 = NOVALUE;
    _34069 = NOVALUE;
    DeRef(_33947);
    _33947 = NOVALUE;
    DeRef(_33868);
    _33868 = NOVALUE;
    DeRef(_34031);
    _34031 = NOVALUE;
    _33956 = NOVALUE;
    DeRef(_34075);
    _34075 = NOVALUE;
    DeRef(_33912);
    _33912 = NOVALUE;
    DeRef(_33991);
    _33991 = NOVALUE;
    DeRef(_33921);
    _33921 = NOVALUE;
    DeRef(_34016);
    _34016 = NOVALUE;
    DeRef(_34048);
    _34048 = NOVALUE;
    DeRef(_33866);
    _33866 = NOVALUE;
    _33929 = NOVALUE;
    DeRef(_33853);
    _33853 = NOVALUE;
    DeRef(_33892);
    _33892 = NOVALUE;
    DeRef(_34010);
    _34010 = NOVALUE;
    DeRef(_33876);
    _33876 = NOVALUE;
    DeRef(_33998);
    _33998 = NOVALUE;
    DeRef(_33964);
    _33964 = NOVALUE;
    DeRef(_33880);
    _33880 = NOVALUE;
    DeRef(_34061);
    _34061 = NOVALUE;
    DeRef(_33862);
    _33862 = NOVALUE;
    DeRef(_33907);
    _33907 = NOVALUE;
    DeRef(_33904);
    _33904 = NOVALUE;
    DeRef(_34027);
    _34027 = NOVALUE;
    DeRef(_33873);
    _33873 = NOVALUE;
    DeRef(_33918);
    _33918 = NOVALUE;
    DeRef(_33945);
    _33945 = NOVALUE;
    DeRef(_33960);
    _33960 = NOVALUE;
    DeRef(_33931);
    _33931 = NOVALUE;
    _33955 = NOVALUE;
    DeRef(_33981);
    _33981 = NOVALUE;
    DeRef(_33941);
    _33941 = NOVALUE;
    _34056 = NOVALUE;
    DeRef(_34025);
    _34025 = NOVALUE;
    DeRef(_33935);
    _33935 = NOVALUE;
    DeRef(_33914);
    _33914 = NOVALUE;
    DeRef(_33989);
    _33989 = NOVALUE;
    DeRef(_33962);
    _33962 = NOVALUE;
    DeRef(_33977);
    _33977 = NOVALUE;
    DeRef(_33925);
    _33925 = NOVALUE;
    DeRef(_33951);
    _33951 = NOVALUE;
    DeRef(_33855);
    _33855 = NOVALUE;
    DeRef(_34058);
    _34058 = NOVALUE;
    DeRef(_34034);
    _34034 = NOVALUE;
    DeRef(_33937);
    _33937 = NOVALUE;
    DeRef(_33995);
    _33995 = NOVALUE;
    DeRef(_34002);
    _34002 = NOVALUE;
    return 0;
L3E: 

    /** execute.e:2817			return global_found*/
    DeRefDS(_name_68258);
    DeRef(_ns_68266);
    DeRef(_34071);
    _34071 = NOVALUE;
    DeRef(_34012);
    _34012 = NOVALUE;
    _34041 = NOVALUE;
    DeRef(_33888);
    _33888 = NOVALUE;
    DeRef(_34006);
    _34006 = NOVALUE;
    _34069 = NOVALUE;
    DeRef(_33947);
    _33947 = NOVALUE;
    DeRef(_33868);
    _33868 = NOVALUE;
    DeRef(_34031);
    _34031 = NOVALUE;
    _33956 = NOVALUE;
    DeRef(_34075);
    _34075 = NOVALUE;
    DeRef(_33912);
    _33912 = NOVALUE;
    DeRef(_33991);
    _33991 = NOVALUE;
    DeRef(_33921);
    _33921 = NOVALUE;
    DeRef(_34016);
    _34016 = NOVALUE;
    DeRef(_34048);
    _34048 = NOVALUE;
    DeRef(_33866);
    _33866 = NOVALUE;
    _33929 = NOVALUE;
    DeRef(_33853);
    _33853 = NOVALUE;
    DeRef(_33892);
    _33892 = NOVALUE;
    DeRef(_34010);
    _34010 = NOVALUE;
    DeRef(_33876);
    _33876 = NOVALUE;
    DeRef(_33998);
    _33998 = NOVALUE;
    DeRef(_33964);
    _33964 = NOVALUE;
    DeRef(_33880);
    _33880 = NOVALUE;
    DeRef(_34061);
    _34061 = NOVALUE;
    DeRef(_33862);
    _33862 = NOVALUE;
    DeRef(_33907);
    _33907 = NOVALUE;
    DeRef(_33904);
    _33904 = NOVALUE;
    DeRef(_34027);
    _34027 = NOVALUE;
    DeRef(_33873);
    _33873 = NOVALUE;
    DeRef(_33918);
    _33918 = NOVALUE;
    DeRef(_33945);
    _33945 = NOVALUE;
    DeRef(_33960);
    _33960 = NOVALUE;
    DeRef(_33931);
    _33931 = NOVALUE;
    _33955 = NOVALUE;
    DeRef(_33981);
    _33981 = NOVALUE;
    DeRef(_33941);
    _33941 = NOVALUE;
    _34056 = NOVALUE;
    DeRef(_34025);
    _34025 = NOVALUE;
    DeRef(_33935);
    _33935 = NOVALUE;
    DeRef(_33914);
    _33914 = NOVALUE;
    DeRef(_33989);
    _33989 = NOVALUE;
    DeRef(_33962);
    _33962 = NOVALUE;
    DeRef(_33977);
    _33977 = NOVALUE;
    DeRef(_33925);
    _33925 = NOVALUE;
    DeRef(_33951);
    _33951 = NOVALUE;
    DeRef(_33855);
    _33855 = NOVALUE;
    DeRef(_34058);
    _34058 = NOVALUE;
    DeRef(_34034);
    _34034 = NOVALUE;
    DeRef(_33937);
    _33937 = NOVALUE;
    DeRef(_33995);
    _33995 = NOVALUE;
    DeRef(_34002);
    _34002 = NOVALUE;
    return _global_found_68265;
L22: 
    ;
}


void _67do_call_proc(object _sub_68646, object _args_68647, object _advance_68648)
{
    object _n_68649 = NOVALUE;
    object _arg_68650 = NOVALUE;
    object _private_block_68665 = NOVALUE;
    object _p_68671 = NOVALUE;
    object _34120 = NOVALUE;
    object _34115 = NOVALUE;
    object _34113 = NOVALUE;
    object _34112 = NOVALUE;
    object _34111 = NOVALUE;
    object _34109 = NOVALUE;
    object _34107 = NOVALUE;
    object _34104 = NOVALUE;
    object _34102 = NOVALUE;
    object _34100 = NOVALUE;
    object _34099 = NOVALUE;
    object _34098 = NOVALUE;
    object _34097 = NOVALUE;
    object _34096 = NOVALUE;
    object _34095 = NOVALUE;
    object _34093 = NOVALUE;
    object _34092 = NOVALUE;
    object _34090 = NOVALUE;
    object _34089 = NOVALUE;
    object _34087 = NOVALUE;
    object _34086 = NOVALUE;
    object _34084 = NOVALUE;
    object _34083 = NOVALUE;
    object _34081 = NOVALUE;
    object _34079 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_advance_68648)) {
        _1 = (object)(DBL_PTR(_advance_68648)->dbl);
        DeRefDS(_advance_68648);
        _advance_68648 = _1;
    }

    /** execute.e:2825		n = SymTab[sub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34079 = (object)*(((s1_ptr)_2)->base + _sub_68646);
    _2 = (object)SEQ_PTR(_34079);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _n_68649 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _n_68649 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    if (!IS_ATOM_INT(_n_68649)){
        _n_68649 = (object)DBL_PTR(_n_68649)->dbl;
    }
    _34079 = NOVALUE;

    /** execute.e:2826		arg = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34081 = (object)*(((s1_ptr)_2)->base + _sub_68646);
    _2 = (object)SEQ_PTR(_34081);
    _arg_68650 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_68650)){
        _arg_68650 = (object)DBL_PTR(_arg_68650)->dbl;
    }
    _34081 = NOVALUE;

    /** execute.e:2827		if SymTab[sub][S_RESIDENT_TASK] != 0 then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34083 = (object)*(((s1_ptr)_2)->base + _sub_68646);
    _2 = (object)SEQ_PTR(_34083);
    _34084 = (object)*(((s1_ptr)_2)->base + 25);
    _34083 = NOVALUE;
    if (binary_op_a(EQUALS, _34084, 0)){
        _34084 = NOVALUE;
        goto L1; // [53] 314
    }
    _34084 = NOVALUE;

    /** execute.e:2831			sequence private_block = repeat(0, SymTab[sub][S_STACK_SPACE])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34086 = (object)*(((s1_ptr)_2)->base + _sub_68646);
    _2 = (object)SEQ_PTR(_34086);
    if (!IS_ATOM_INT(_12S_STACK_SPACE_19924)){
        _34087 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_STACK_SPACE_19924)->dbl));
    }
    else{
        _34087 = (object)*(((s1_ptr)_2)->base + _12S_STACK_SPACE_19924);
    }
    _34086 = NOVALUE;
    DeRef(_private_block_68665);
    _private_block_68665 = Repeat(0, _34087);
    _34087 = NOVALUE;

    /** execute.e:2832			integer p = 1*/
    _p_68671 = 1;

    /** execute.e:2833			for i = 1 to n do*/
    _34089 = _n_68649;
    {
        object _i_68673;
        _i_68673 = 1;
L2: 
        if (_i_68673 > _34089){
            goto L3; // [85] 145
        }

        /** execute.e:2834				private_block[p] = val[arg]*/
        _2 = (object)SEQ_PTR(_67val_64812);
        _34090 = (object)*(((s1_ptr)_2)->base + _arg_68650);
        Ref(_34090);
        _2 = (object)SEQ_PTR(_private_block_68665);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _private_block_68665 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _p_68671);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _34090;
        if( _1 != _34090 ){
            DeRef(_1);
        }
        _34090 = NOVALUE;

        /** execute.e:2835				p += 1*/
        _p_68671 = _p_68671 + 1;

        /** execute.e:2836				val[arg] = args[i]*/
        _2 = (object)SEQ_PTR(_args_68647);
        _34092 = (object)*(((s1_ptr)_2)->base + _i_68673);
        Ref(_34092);
        _2 = (object)SEQ_PTR(_67val_64812);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_64812 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_68650);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _34092;
        if( _1 != _34092 ){
            DeRef(_1);
        }
        _34092 = NOVALUE;

        /** execute.e:2837				arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _34093 = (object)*(((s1_ptr)_2)->base + _arg_68650);
        _2 = (object)SEQ_PTR(_34093);
        _arg_68650 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_68650)){
            _arg_68650 = (object)DBL_PTR(_arg_68650)->dbl;
        }
        _34093 = NOVALUE;

        /** execute.e:2838			end for*/
        _i_68673 = _i_68673 + 1;
        goto L2; // [140] 92
L3: 
        ;
    }

    /** execute.e:2841			while arg != 0 and SymTab[arg][S_SCOPE] <= SC_PRIVATE do*/
L4: 
    _34095 = (_arg_68650 != 0);
    if (_34095 == 0) {
        goto L5; // [154] 229
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34097 = (object)*(((s1_ptr)_2)->base + _arg_68650);
    _2 = (object)SEQ_PTR(_34097);
    _34098 = (object)*(((s1_ptr)_2)->base + 4);
    _34097 = NOVALUE;
    if (IS_ATOM_INT(_34098)) {
        _34099 = (_34098 <= 3);
    }
    else {
        _34099 = binary_op(LESSEQ, _34098, 3);
    }
    _34098 = NOVALUE;
    if (_34099 <= 0) {
        if (_34099 == 0) {
            DeRef(_34099);
            _34099 = NOVALUE;
            goto L5; // [177] 229
        }
        else {
            if (!IS_ATOM_INT(_34099) && DBL_PTR(_34099)->dbl == 0.0){
                DeRef(_34099);
                _34099 = NOVALUE;
                goto L5; // [177] 229
            }
            DeRef(_34099);
            _34099 = NOVALUE;
        }
    }
    DeRef(_34099);
    _34099 = NOVALUE;

    /** execute.e:2842				private_block[p] = val[arg]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34100 = (object)*(((s1_ptr)_2)->base + _arg_68650);
    Ref(_34100);
    _2 = (object)SEQ_PTR(_private_block_68665);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _private_block_68665 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_68671);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34100;
    if( _1 != _34100 ){
        DeRef(_1);
    }
    _34100 = NOVALUE;

    /** execute.e:2843				p += 1*/
    _p_68671 = _p_68671 + 1;

    /** execute.e:2844				val[arg] = NOVALUE -- necessary?*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_68650);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** execute.e:2845				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34102 = (object)*(((s1_ptr)_2)->base + _arg_68650);
    _2 = (object)SEQ_PTR(_34102);
    _arg_68650 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_68650)){
        _arg_68650 = (object)DBL_PTR(_arg_68650)->dbl;
    }
    _34102 = NOVALUE;

    /** execute.e:2846			end while*/
    goto L4; // [226] 150
L5: 

    /** execute.e:2849			arg = SymTab[sub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34104 = (object)*(((s1_ptr)_2)->base + _sub_68646);
    _2 = (object)SEQ_PTR(_34104);
    if (!IS_ATOM_INT(_12S_TEMPS_19909)){
        _arg_68650 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    }
    else{
        _arg_68650 = (object)*(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    }
    if (!IS_ATOM_INT(_arg_68650)){
        _arg_68650 = (object)DBL_PTR(_arg_68650)->dbl;
    }
    _34104 = NOVALUE;

    /** execute.e:2850			while arg != 0 do*/
L6: 
    if (_arg_68650 == 0)
    goto L7; // [250] 303

    /** execute.e:2851				private_block[p] = val[arg]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34107 = (object)*(((s1_ptr)_2)->base + _arg_68650);
    Ref(_34107);
    _2 = (object)SEQ_PTR(_private_block_68665);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _private_block_68665 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_68671);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34107;
    if( _1 != _34107 ){
        DeRef(_1);
    }
    _34107 = NOVALUE;

    /** execute.e:2852				p += 1*/
    _p_68671 = _p_68671 + 1;

    /** execute.e:2853				val[arg] = NOVALUE -- necessary?*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_68650);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** execute.e:2854				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34109 = (object)*(((s1_ptr)_2)->base + _arg_68650);
    _2 = (object)SEQ_PTR(_34109);
    _arg_68650 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_68650)){
        _arg_68650 = (object)DBL_PTR(_arg_68650)->dbl;
    }
    _34109 = NOVALUE;

    /** execute.e:2855			end while*/
    goto L6; // [300] 250
L7: 

    /** execute.e:2858			save_private_block(sub, private_block)*/
    RefDS(_private_block_68665);
    _67save_private_block(_sub_68646, _private_block_68665);
    DeRefDS(_private_block_68665);
    _private_block_68665 = NOVALUE;
    goto L8; // [311] 362
L1: 

    /** execute.e:2862			for i = 1 to n do*/
    _34111 = _n_68649;
    {
        object _i_68713;
        _i_68713 = 1;
L9: 
        if (_i_68713 > _34111){
            goto LA; // [319] 361
        }

        /** execute.e:2863				val[arg] = args[i]*/
        _2 = (object)SEQ_PTR(_args_68647);
        _34112 = (object)*(((s1_ptr)_2)->base + _i_68713);
        Ref(_34112);
        _2 = (object)SEQ_PTR(_67val_64812);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_64812 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_68650);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _34112;
        if( _1 != _34112 ){
            DeRef(_1);
        }
        _34112 = NOVALUE;

        /** execute.e:2864				arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _34113 = (object)*(((s1_ptr)_2)->base + _arg_68650);
        _2 = (object)SEQ_PTR(_34113);
        _arg_68650 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_68650)){
            _arg_68650 = (object)DBL_PTR(_arg_68650)->dbl;
        }
        _34113 = NOVALUE;

        /** execute.e:2865			end for*/
        _i_68713 = _i_68713 + 1;
        goto L9; // [356] 326
LA: 
        ;
    }
L8: 

    /** execute.e:2868		SymTab[sub][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_68646 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_64819;
    DeRef(_1);
    _34115 = NOVALUE;

    /** execute.e:2870		pc += advance*/
    _67pc_64802 = _67pc_64802 + _advance_68648;

    /** execute.e:2872		call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_64820, _67call_stack_64820, _67pc_64802);

    /** execute.e:2873		call_stack = append(call_stack, sub)*/
    Append(&_67call_stack_64820, _67call_stack_64820, _sub_68646);

    /** execute.e:2875		Code = SymTab[sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34120 = (object)*(((s1_ptr)_2)->base + _sub_68646);
    DeRef(_12Code_20315);
    _2 = (object)SEQ_PTR(_34120);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    Ref(_12Code_20315);
    _34120 = NOVALUE;

    /** execute.e:2876		pc = 1*/
    _67pc_64802 = 1;

    /** execute.e:2877	end procedure*/
    DeRefDS(_args_68647);
    DeRef(_34095);
    _34095 = NOVALUE;
    return;
    ;
}


void _67opCALL_PROC()
{
    object _cf_68734 = NOVALUE;
    object _sub_68736 = NOVALUE;
    object _34169 = NOVALUE;
    object _34168 = NOVALUE;
    object _34167 = NOVALUE;
    object _34166 = NOVALUE;
    object _34165 = NOVALUE;
    object _34164 = NOVALUE;
    object _34163 = NOVALUE;
    object _34162 = NOVALUE;
    object _34161 = NOVALUE;
    object _34160 = NOVALUE;
    object _34157 = NOVALUE;
    object _34156 = NOVALUE;
    object _34155 = NOVALUE;
    object _34154 = NOVALUE;
    object _34152 = NOVALUE;
    object _34151 = NOVALUE;
    object _34150 = NOVALUE;
    object _34149 = NOVALUE;
    object _34148 = NOVALUE;
    object _34145 = NOVALUE;
    object _34144 = NOVALUE;
    object _34143 = NOVALUE;
    object _34142 = NOVALUE;
    object _34141 = NOVALUE;
    object _34138 = NOVALUE;
    object _34137 = NOVALUE;
    object _34135 = NOVALUE;
    object _34133 = NOVALUE;
    object _34132 = NOVALUE;
    object _34131 = NOVALUE;
    object _34130 = NOVALUE;
    object _34129 = NOVALUE;
    object _34127 = NOVALUE;
    object _34126 = NOVALUE;
    object _34124 = NOVALUE;
    object _34122 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2884		cf = Code[pc] = CALL_FUNC*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34122 = (object)*(((s1_ptr)_2)->base + _67pc_64802);
    if (IS_ATOM_INT(_34122)) {
        _cf_68734 = (_34122 == 137);
    }
    else {
        _cf_68734 = binary_op(EQUALS, _34122, 137);
    }
    _34122 = NOVALUE;
    if (!IS_ATOM_INT(_cf_68734)) {
        _1 = (object)(DBL_PTR(_cf_68734)->dbl);
        DeRefDS(_cf_68734);
        _cf_68734 = _1;
    }

    /** execute.e:2886		a = Code[pc+1]  -- routine id*/
    _34124 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34124);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2887		if val[a] < 0 or val[a] >= length(e_routine) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34126 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_34126)) {
        _34127 = (_34126 < 0);
    }
    else {
        _34127 = binary_op(LESS, _34126, 0);
    }
    _34126 = NOVALUE;
    if (IS_ATOM_INT(_34127)) {
        if (_34127 != 0) {
            goto L1; // [49] 75
        }
    }
    else {
        if (DBL_PTR(_34127)->dbl != 0.0) {
            goto L1; // [49] 75
        }
    }
    _2 = (object)SEQ_PTR(_67val_64812);
    _34129 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_SEQUENCE(_67e_routine_64850)){
            _34130 = SEQ_PTR(_67e_routine_64850)->length;
    }
    else {
        _34130 = 1;
    }
    if (IS_ATOM_INT(_34129)) {
        _34131 = (_34129 >= _34130);
    }
    else {
        _34131 = binary_op(GREATEREQ, _34129, _34130);
    }
    _34129 = NOVALUE;
    _34130 = NOVALUE;
    if (_34131 == 0) {
        DeRef(_34131);
        _34131 = NOVALUE;
        goto L2; // [71] 81
    }
    else {
        if (!IS_ATOM_INT(_34131) && DBL_PTR(_34131)->dbl == 0.0){
            DeRef(_34131);
            _34131 = NOVALUE;
            goto L2; // [71] 81
        }
        DeRef(_34131);
        _34131 = NOVALUE;
    }
    DeRef(_34131);
    _34131 = NOVALUE;
L1: 

    /** execute.e:2888			RTFatal("invalid routine id")*/
    RefDS(_32498);
    _67RTFatal(_32498);
L2: 

    /** execute.e:2891		sub = e_routine[val[a]+1]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34132 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_34132)) {
        _34133 = _34132 + 1;
    }
    else
    _34133 = binary_op(PLUS, 1, _34132);
    _34132 = NOVALUE;
    _2 = (object)SEQ_PTR(_67e_routine_64850);
    if (!IS_ATOM_INT(_34133)){
        _sub_68736 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34133)->dbl));
    }
    else{
        _sub_68736 = (object)*(((s1_ptr)_2)->base + _34133);
    }

    /** execute.e:2892		b = Code[pc+2]  -- argument list*/
    _34135 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34135);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2894		if cf then*/
    if (_cf_68734 == 0)
    {
        goto L3; // [121] 169
    }
    else{
    }

    /** execute.e:2895			if SymTab[sub][S_TOKEN] = PROC then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34137 = (object)*(((s1_ptr)_2)->base + _sub_68736);
    _2 = (object)SEQ_PTR(_34137);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _34138 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _34138 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _34137 = NOVALUE;
    if (binary_op_a(NOTEQ, _34138, 27)){
        _34138 = NOVALUE;
        goto L4; // [140] 212
    }
    _34138 = NOVALUE;

    /** execute.e:2896				RTFatal(sprintf("%s() does not return a value", SymTab[sub][S_NAME]))*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34141 = (object)*(((s1_ptr)_2)->base + _sub_68736);
    _2 = (object)SEQ_PTR(_34141);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _34142 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _34142 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _34141 = NOVALUE;
    _34143 = EPrintf(-9999999, _34140, _34142);
    _34142 = NOVALUE;
    _67RTFatal(_34143);
    _34143 = NOVALUE;
    goto L4; // [166] 212
L3: 

    /** execute.e:2899			if SymTab[sub][S_TOKEN] != PROC then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34144 = (object)*(((s1_ptr)_2)->base + _sub_68736);
    _2 = (object)SEQ_PTR(_34144);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _34145 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _34145 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _34144 = NOVALUE;
    if (binary_op_a(EQUALS, _34145, 27)){
        _34145 = NOVALUE;
        goto L5; // [185] 211
    }
    _34145 = NOVALUE;

    /** execute.e:2900				RTFatal(sprintf("the value returned by %s() must be assigned or used",*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34148 = (object)*(((s1_ptr)_2)->base + _sub_68736);
    _2 = (object)SEQ_PTR(_34148);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _34149 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _34149 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _34148 = NOVALUE;
    _34150 = EPrintf(-9999999, _34147, _34149);
    _34149 = NOVALUE;
    _67RTFatal(_34150);
    _34150 = NOVALUE;
L5: 
L4: 

    /** execute.e:2904		if atom(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34151 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _34152 = IS_ATOM(_34151);
    _34151 = NOVALUE;
    if (_34152 == 0)
    {
        _34152 = NOVALUE;
        goto L6; // [225] 234
    }
    else{
        _34152 = NOVALUE;
    }

    /** execute.e:2905			RTFatal("argument list must be a sequence")*/
    RefDS(_34153);
    _67RTFatal(_34153);
L6: 

    /** execute.e:2908		if SymTab[sub][S_NUM_ARGS] != length(val[b]) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34154 = (object)*(((s1_ptr)_2)->base + _sub_68736);
    _2 = (object)SEQ_PTR(_34154);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _34155 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _34155 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _34154 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    _34156 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_SEQUENCE(_34156)){
            _34157 = SEQ_PTR(_34156)->length;
    }
    else {
        _34157 = 1;
    }
    _34156 = NOVALUE;
    if (binary_op_a(EQUALS, _34155, _34157)){
        _34155 = NOVALUE;
        _34157 = NOVALUE;
        goto L7; // [259] 314
    }
    _34155 = NOVALUE;
    _34157 = NOVALUE;

    /** execute.e:2909			RTFatal(sprintf("call to %s() via routine-id should pass %d arguments, not %d",*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34160 = (object)*(((s1_ptr)_2)->base + _sub_68736);
    _2 = (object)SEQ_PTR(_34160);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _34161 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _34161 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _34160 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34162 = (object)*(((s1_ptr)_2)->base + _sub_68736);
    _2 = (object)SEQ_PTR(_34162);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _34163 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _34163 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _34162 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    _34164 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_SEQUENCE(_34164)){
            _34165 = SEQ_PTR(_34164)->length;
    }
    else {
        _34165 = 1;
    }
    _34164 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_34161);
    ((intptr_t*)_2)[1] = _34161;
    Ref(_34163);
    ((intptr_t*)_2)[2] = _34163;
    ((intptr_t*)_2)[3] = _34165;
    _34166 = MAKE_SEQ(_1);
    _34165 = NOVALUE;
    _34163 = NOVALUE;
    _34161 = NOVALUE;
    _34167 = EPrintf(-9999999, _34159, _34166);
    DeRefDS(_34166);
    _34166 = NOVALUE;
    _67RTFatal(_34167);
    _34167 = NOVALUE;
L7: 

    /** execute.e:2914		do_call_proc( sub, val[b], 3 + cf )*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34168 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _34169 = 3 + _cf_68734;
    if ((object)((uintptr_t)_34169 + (uintptr_t)HIGH_BITS) >= 0){
        _34169 = NewDouble((eudouble)_34169);
    }
    Ref(_34168);
    _67do_call_proc(_sub_68736, _34168, _34169);
    _34168 = NOVALUE;
    _34169 = NOVALUE;

    /** execute.e:2915	end procedure*/
    DeRef(_34135);
    _34135 = NOVALUE;
    _34164 = NOVALUE;
    DeRef(_34124);
    _34124 = NOVALUE;
    _34156 = NOVALUE;
    DeRef(_34133);
    _34133 = NOVALUE;
    DeRef(_34127);
    _34127 = NOVALUE;
    return;
    ;
}


void _67opROUTINE_ID()
{
    object _sub_68814 = NOVALUE;
    object _fn_68815 = NOVALUE;
    object _p_68816 = NOVALUE;
    object _stlen_68817 = NOVALUE;
    object _name_68818 = NOVALUE;
    object _34196 = NOVALUE;
    object _34195 = NOVALUE;
    object _34193 = NOVALUE;
    object _34191 = NOVALUE;
    object _34190 = NOVALUE;
    object _34189 = NOVALUE;
    object _34188 = NOVALUE;
    object _34187 = NOVALUE;
    object _34186 = NOVALUE;
    object _34184 = NOVALUE;
    object _34182 = NOVALUE;
    object _34179 = NOVALUE;
    object _34177 = NOVALUE;
    object _34175 = NOVALUE;
    object _34174 = NOVALUE;
    object _34172 = NOVALUE;
    object _34170 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2923		sub = Code[pc+1]   -- CurrentSub*/
    _34170 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _sub_68814 = (object)*(((s1_ptr)_2)->base + _34170);
    if (!IS_ATOM_INT(_sub_68814)){
        _sub_68814 = (object)DBL_PTR(_sub_68814)->dbl;
    }

    /** execute.e:2924		stlen = Code[pc+2]  -- s.t. length*/
    _34172 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _stlen_68817 = (object)*(((s1_ptr)_2)->base + _34172);
    if (!IS_ATOM_INT(_stlen_68817)){
        _stlen_68817 = (object)DBL_PTR(_stlen_68817)->dbl;
    }

    /** execute.e:2925		name = val[Code[pc+3]]  -- routine name sequence*/
    _34174 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34175 = (object)*(((s1_ptr)_2)->base + _34174);
    DeRef(_name_68818);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_34175)){
        _name_68818 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34175)->dbl));
    }
    else{
        _name_68818 = (object)*(((s1_ptr)_2)->base + _34175);
    }
    Ref(_name_68818);

    /** execute.e:2926		fn = Code[pc+4]    -- file number*/
    _34177 = _67pc_64802 + 4;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _fn_68815 = (object)*(((s1_ptr)_2)->base + _34177);
    if (!IS_ATOM_INT(_fn_68815)){
        _fn_68815 = (object)DBL_PTR(_fn_68815)->dbl;
    }

    /** execute.e:2927		target = Code[pc+5]*/
    _34179 = _67pc_64802 + 5;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34179);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2928		pc += 6*/
    _67pc_64802 = _67pc_64802 + 6;

    /** execute.e:2929		if atom(name) then*/
    _34182 = IS_ATOM(_name_68818);
    if (_34182 == 0)
    {
        _34182 = NOVALUE;
        goto L1; // [98] 117
    }
    else{
        _34182 = NOVALUE;
    }

    /** execute.e:2930			val[target] = -1*/
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1;
    DeRef(_1);

    /** execute.e:2931			return*/
    DeRef(_name_68818);
    _34179 = NOVALUE;
    _34177 = NOVALUE;
    _34170 = NOVALUE;
    _34172 = NOVALUE;
    _34174 = NOVALUE;
    _34175 = NOVALUE;
    return;
L1: 

    /** execute.e:2934		p = RTLookup(name, fn, sub, stlen)*/
    Ref(_name_68818);
    _p_68816 = _67RTLookup(_name_68818, _fn_68815, _sub_68814, _stlen_68817);
    if (!IS_ATOM_INT(_p_68816)) {
        _1 = (object)(DBL_PTR(_p_68816)->dbl);
        DeRefDS(_p_68816);
        _p_68816 = _1;
    }

    /** execute.e:2935		if p = 0 or not find(SymTab[p][S_TOKEN], RTN_TOKS) then*/
    _34184 = (_p_68816 == 0);
    if (_34184 != 0) {
        goto L2; // [134] 165
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34186 = (object)*(((s1_ptr)_2)->base + _p_68816);
    _2 = (object)SEQ_PTR(_34186);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _34187 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _34187 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _34186 = NOVALUE;
    _34188 = find_from(_34187, _29RTN_TOKS_12006, 1);
    _34187 = NOVALUE;
    _34189 = (_34188 == 0);
    _34188 = NOVALUE;
    if (_34189 == 0)
    {
        DeRef(_34189);
        _34189 = NOVALUE;
        goto L3; // [161] 181
    }
    else{
        DeRef(_34189);
        _34189 = NOVALUE;
    }
L2: 

    /** execute.e:2936			val[target] = -1  -- name is not a routine*/
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1;
    DeRef(_1);

    /** execute.e:2937			return*/
    DeRef(_name_68818);
    DeRef(_34179);
    _34179 = NOVALUE;
    DeRef(_34177);
    _34177 = NOVALUE;
    DeRef(_34170);
    _34170 = NOVALUE;
    DeRef(_34172);
    _34172 = NOVALUE;
    DeRef(_34174);
    _34174 = NOVALUE;
    DeRef(_34184);
    _34184 = NOVALUE;
    _34175 = NOVALUE;
    return;
L3: 

    /** execute.e:2939		for i = 1 to length(e_routine) do*/
    if (IS_SEQUENCE(_67e_routine_64850)){
            _34190 = SEQ_PTR(_67e_routine_64850)->length;
    }
    else {
        _34190 = 1;
    }
    {
        object _i_68850;
        _i_68850 = 1;
L4: 
        if (_i_68850 > _34190){
            goto L5; // [188] 234
        }

        /** execute.e:2940			if e_routine[i] = p then*/
        _2 = (object)SEQ_PTR(_67e_routine_64850);
        _34191 = (object)*(((s1_ptr)_2)->base + _i_68850);
        if (_34191 != _p_68816)
        goto L6; // [203] 227

        /** execute.e:2941				val[target] = i - 1  -- routine was already assigned an id*/
        _34193 = _i_68850 - 1;
        _2 = (object)SEQ_PTR(_67val_64812);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_64812 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _34193;
        if( _1 != _34193 ){
            DeRef(_1);
        }
        _34193 = NOVALUE;

        /** execute.e:2942				return*/
        DeRef(_name_68818);
        DeRef(_34179);
        _34179 = NOVALUE;
        DeRef(_34177);
        _34177 = NOVALUE;
        DeRef(_34170);
        _34170 = NOVALUE;
        _34191 = NOVALUE;
        DeRef(_34172);
        _34172 = NOVALUE;
        DeRef(_34174);
        _34174 = NOVALUE;
        DeRef(_34184);
        _34184 = NOVALUE;
        _34175 = NOVALUE;
        return;
L6: 

        /** execute.e:2944		end for*/
        _i_68850 = _i_68850 + 1;
        goto L4; // [229] 195
L5: 
        ;
    }

    /** execute.e:2945		e_routine = append(e_routine, p)*/
    Append(&_67e_routine_64850, _67e_routine_64850, _p_68816);

    /** execute.e:2946		val[target] = length(e_routine) - 1*/
    if (IS_SEQUENCE(_67e_routine_64850)){
            _34195 = SEQ_PTR(_67e_routine_64850)->length;
    }
    else {
        _34195 = 1;
    }
    _34196 = _34195 - 1;
    _34195 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34196;
    if( _1 != _34196 ){
        DeRef(_1);
    }
    _34196 = NOVALUE;

    /** execute.e:2947	end procedure*/
    DeRef(_name_68818);
    DeRef(_34179);
    _34179 = NOVALUE;
    DeRef(_34177);
    _34177 = NOVALUE;
    DeRef(_34170);
    _34170 = NOVALUE;
    _34191 = NOVALUE;
    DeRef(_34172);
    _34172 = NOVALUE;
    DeRef(_34174);
    _34174 = NOVALUE;
    DeRef(_34184);
    _34184 = NOVALUE;
    _34175 = NOVALUE;
    return;
    ;
}


void _67opAPPEND()
{
    object _34205 = NOVALUE;
    object _34204 = NOVALUE;
    object _34203 = NOVALUE;
    object _34201 = NOVALUE;
    object _34199 = NOVALUE;
    object _34197 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2950		a = Code[pc+1]*/
    _34197 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34197);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2951		b = Code[pc+2]*/
    _34199 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34199);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2952		target = Code[pc+3]*/
    _34201 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34201);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2953		val[target] = append(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34203 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34204 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    Ref(_34204);
    Append(&_34205, _34203, _34204);
    _34203 = NOVALUE;
    _34204 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34205;
    if( _1 != _34205 ){
        DeRef(_1);
    }
    _34205 = NOVALUE;

    /** execute.e:2954		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2955	end procedure*/
    _34201 = NOVALUE;
    _34197 = NOVALUE;
    _34199 = NOVALUE;
    return;
    ;
}


void _67opPREPEND()
{
    object _34215 = NOVALUE;
    object _34214 = NOVALUE;
    object _34213 = NOVALUE;
    object _34211 = NOVALUE;
    object _34209 = NOVALUE;
    object _34207 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2958		a = Code[pc+1]*/
    _34207 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34207);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2959		b = Code[pc+2]*/
    _34209 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34209);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2960		target = Code[pc+3]*/
    _34211 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34211);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2961		val[target] = prepend(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34213 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34214 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    Ref(_34214);
    Prepend(&_34215, _34213, _34214);
    _34213 = NOVALUE;
    _34214 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34215;
    if( _1 != _34215 ){
        DeRef(_1);
    }
    _34215 = NOVALUE;

    /** execute.e:2962		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2963	end procedure*/
    _34207 = NOVALUE;
    _34211 = NOVALUE;
    _34209 = NOVALUE;
    return;
    ;
}


void _67opCONCAT()
{
    object _34225 = NOVALUE;
    object _34224 = NOVALUE;
    object _34223 = NOVALUE;
    object _34221 = NOVALUE;
    object _34219 = NOVALUE;
    object _34217 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2966		a = Code[pc+1]*/
    _34217 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34217);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2967		b = Code[pc+2]*/
    _34219 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34219);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2968		target = Code[pc+3]*/
    _34221 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34221);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2969		val[target] = val[a] & val[b]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34223 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34224 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_SEQUENCE(_34223) && IS_ATOM(_34224)) {
        Ref(_34224);
        Append(&_34225, _34223, _34224);
    }
    else if (IS_ATOM(_34223) && IS_SEQUENCE(_34224)) {
        Ref(_34223);
        Prepend(&_34225, _34224, _34223);
    }
    else {
        Concat((object_ptr)&_34225, _34223, _34224);
        _34223 = NOVALUE;
    }
    _34223 = NOVALUE;
    _34224 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34225;
    if( _1 != _34225 ){
        DeRef(_1);
    }
    _34225 = NOVALUE;

    /** execute.e:2970		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:2971	end procedure*/
    _34219 = NOVALUE;
    _34221 = NOVALUE;
    _34217 = NOVALUE;
    return;
    ;
}


void _67opCONCAT_N()
{
    object _n_68906 = NOVALUE;
    object _x_68907 = NOVALUE;
    object _34241 = NOVALUE;
    object _34239 = NOVALUE;
    object _34238 = NOVALUE;
    object _34236 = NOVALUE;
    object _34235 = NOVALUE;
    object _34234 = NOVALUE;
    object _34233 = NOVALUE;
    object _34232 = NOVALUE;
    object _34230 = NOVALUE;
    object _34229 = NOVALUE;
    object _34227 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2978		n = Code[pc+1] -- number of items*/
    _34227 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _n_68906 = (object)*(((s1_ptr)_2)->base + _34227);
    if (!IS_ATOM_INT(_n_68906)){
        _n_68906 = (object)DBL_PTR(_n_68906)->dbl;
    }

    /** execute.e:2980		x = val[Code[pc+2]] -- last one*/
    _34229 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34230 = (object)*(((s1_ptr)_2)->base + _34229);
    DeRef(_x_68907);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_34230)){
        _x_68907 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34230)->dbl));
    }
    else{
        _x_68907 = (object)*(((s1_ptr)_2)->base + _34230);
    }
    Ref(_x_68907);

    /** execute.e:2981		for i = pc+3 to pc+n+1 do*/
    _34232 = _67pc_64802 + 3;
    if ((object)((uintptr_t)_34232 + (uintptr_t)HIGH_BITS) >= 0){
        _34232 = NewDouble((eudouble)_34232);
    }
    _34233 = _67pc_64802 + _n_68906;
    if ((object)((uintptr_t)_34233 + (uintptr_t)HIGH_BITS) >= 0){
        _34233 = NewDouble((eudouble)_34233);
    }
    if (IS_ATOM_INT(_34233)) {
        _34234 = _34233 + 1;
        if (_34234 > MAXINT){
            _34234 = NewDouble((eudouble)_34234);
        }
    }
    else
    _34234 = binary_op(PLUS, 1, _34233);
    DeRef(_34233);
    _34233 = NOVALUE;
    {
        object _i_68916;
        Ref(_34232);
        _i_68916 = _34232;
L1: 
        if (binary_op_a(GREATER, _i_68916, _34234)){
            goto L2; // [55] 87
        }

        /** execute.e:2982			x = val[Code[i]] & x*/
        _2 = (object)SEQ_PTR(_12Code_20315);
        if (!IS_ATOM_INT(_i_68916)){
            _34235 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_68916)->dbl));
        }
        else{
            _34235 = (object)*(((s1_ptr)_2)->base + _i_68916);
        }
        _2 = (object)SEQ_PTR(_67val_64812);
        if (!IS_ATOM_INT(_34235)){
            _34236 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34235)->dbl));
        }
        else{
            _34236 = (object)*(((s1_ptr)_2)->base + _34235);
        }
        if (IS_SEQUENCE(_34236) && IS_ATOM(_x_68907)) {
            Ref(_x_68907);
            Append(&_x_68907, _34236, _x_68907);
        }
        else if (IS_ATOM(_34236) && IS_SEQUENCE(_x_68907)) {
            Ref(_34236);
            Prepend(&_x_68907, _x_68907, _34236);
        }
        else {
            Concat((object_ptr)&_x_68907, _34236, _x_68907);
            _34236 = NOVALUE;
        }
        _34236 = NOVALUE;

        /** execute.e:2983		end for*/
        _0 = _i_68916;
        if (IS_ATOM_INT(_i_68916)) {
            _i_68916 = _i_68916 + 1;
            if ((object)((uintptr_t)_i_68916 +(uintptr_t) HIGH_BITS) >= 0){
                _i_68916 = NewDouble((eudouble)_i_68916);
            }
        }
        else {
            _i_68916 = binary_op_a(PLUS, _i_68916, 1);
        }
        DeRef(_0);
        goto L1; // [82] 62
L2: 
        ;
        DeRef(_i_68916);
    }

    /** execute.e:2984		target = Code[pc+n+2]*/
    _34238 = _67pc_64802 + _n_68906;
    if ((object)((uintptr_t)_34238 + (uintptr_t)HIGH_BITS) >= 0){
        _34238 = NewDouble((eudouble)_34238);
    }
    if (IS_ATOM_INT(_34238)) {
        _34239 = _34238 + 2;
    }
    else {
        _34239 = NewDouble(DBL_PTR(_34238)->dbl + (eudouble)2);
    }
    DeRef(_34238);
    _34238 = NOVALUE;
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!IS_ATOM_INT(_34239)){
        _67target_64807 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34239)->dbl));
    }
    else{
        _67target_64807 = (object)*(((s1_ptr)_2)->base + _34239);
    }
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2985		val[target] = x*/
    Ref(_x_68907);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _x_68907;
    DeRef(_1);

    /** execute.e:2986		pc += n+3*/
    _34241 = _n_68906 + 3;
    if ((object)((uintptr_t)_34241 + (uintptr_t)HIGH_BITS) >= 0){
        _34241 = NewDouble((eudouble)_34241);
    }
    if (IS_ATOM_INT(_34241)) {
        _67pc_64802 = _67pc_64802 + _34241;
    }
    else {
        _67pc_64802 = NewDouble((eudouble)_67pc_64802 + DBL_PTR(_34241)->dbl);
    }
    DeRef(_34241);
    _34241 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_64802)) {
        _1 = (object)(DBL_PTR(_67pc_64802)->dbl);
        DeRefDS(_67pc_64802);
        _67pc_64802 = _1;
    }

    /** execute.e:2987	end procedure*/
    DeRef(_x_68907);
    DeRef(_34227);
    _34227 = NOVALUE;
    DeRef(_34229);
    _34229 = NOVALUE;
    _34235 = NOVALUE;
    _34230 = NOVALUE;
    DeRef(_34232);
    _34232 = NOVALUE;
    DeRef(_34239);
    _34239 = NOVALUE;
    DeRef(_34234);
    _34234 = NOVALUE;
    return;
    ;
}


void _67opREPEAT()
{
    object _34261 = NOVALUE;
    object _34260 = NOVALUE;
    object _34259 = NOVALUE;
    object _34256 = NOVALUE;
    object _34253 = NOVALUE;
    object _34250 = NOVALUE;
    object _34249 = NOVALUE;
    object _34247 = NOVALUE;
    object _34245 = NOVALUE;
    object _34243 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2990		a = Code[pc+1]*/
    _34243 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34243);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:2991		b = Code[pc+2]*/
    _34245 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34245);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:2992		target = Code[pc+3]*/
    _34247 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34247);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:2993		if not atom(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34249 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _34250 = IS_ATOM(_34249);
    _34249 = NOVALUE;
    if (_34250 != 0)
    goto L1; // [62] 71
    _34250 = NOVALUE;

    /** execute.e:2994			RTFatal("repetition count must be an atom")*/
    RefDS(_34252);
    _67RTFatal(_34252);
L1: 

    /** execute.e:2996		if val[b] < 0 then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34253 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (binary_op_a(GREATEREQ, _34253, 0)){
        _34253 = NOVALUE;
        goto L2; // [81] 91
    }
    _34253 = NOVALUE;

    /** execute.e:2997			RTFatal("repetition count must not be negative")*/
    RefDS(_34255);
    _67RTFatal(_34255);
L2: 

    /** execute.e:2999		if val[b] > 1073741823 then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34256 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (binary_op_a(LESSEQ, _34256, 1073741823)){
        _34256 = NOVALUE;
        goto L3; // [101] 111
    }
    _34256 = NOVALUE;

    /** execute.e:3000			RTFatal("repetition count is too large")*/
    RefDS(_34258);
    _67RTFatal(_34258);
L3: 

    /** execute.e:3002		val[target] = repeat(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34259 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34260 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _34261 = Repeat(_34259, _34260);
    _34259 = NOVALUE;
    _34260 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34261;
    if( _1 != _34261 ){
        DeRef(_1);
    }
    _34261 = NOVALUE;

    /** execute.e:3003		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:3004	end procedure*/
    DeRef(_34245);
    _34245 = NOVALUE;
    DeRef(_34247);
    _34247 = NOVALUE;
    DeRef(_34243);
    _34243 = NOVALUE;
    return;
    ;
}


void _67opDATE()
{
    object _34265 = NOVALUE;
    object _34263 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3007		target = Code[pc+1]*/
    _34263 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34263);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3008		val[target] = date()*/
    _34265 = Date();
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34265;
    if( _1 != _34265 ){
        DeRef(_1);
    }
    _34265 = NOVALUE;

    /** execute.e:3009		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:3010	end procedure*/
    _34263 = NOVALUE;
    return;
    ;
}


void _67opTIME()
{
    object _34269 = NOVALUE;
    object _34267 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3013		target = Code[pc+1]*/
    _34267 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34267);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3014		val[target] = time()*/
    _34269 = NewDouble(current_time());
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34269;
    if( _1 != _34269 ){
        DeRef(_1);
    }
    _34269 = NOVALUE;

    /** execute.e:3015		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:3016	end procedure*/
    _34267 = NOVALUE;
    return;
    ;
}


void _67opSPACE_USED()
{
    object _0, _1, _2;
    

    /** execute.e:3019		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:3020	end procedure*/
    return;
    ;
}


void _67opNOP2()
{
    object _0, _1, _2;
    

    /** execute.e:3024		pc+= 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:3025	end procedure*/
    return;
    ;
}


void _67opPOSITION()
{
    object _34278 = NOVALUE;
    object _34277 = NOVALUE;
    object _34275 = NOVALUE;
    object _34273 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3028		a = Code[pc+1]*/
    _34273 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34273);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3029		b = Code[pc+2]*/
    _34275 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34275);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3030		position(val[a], val[b])  -- error checks*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34277 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34278 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    Position(_34277, _34278);
    _34277 = NOVALUE;
    _34278 = NOVALUE;

    /** execute.e:3031		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3032	end procedure*/
    _34273 = NOVALUE;
    _34275 = NOVALUE;
    return;
    ;
}


void _67opEQUAL()
{
    object _34288 = NOVALUE;
    object _34287 = NOVALUE;
    object _34286 = NOVALUE;
    object _34284 = NOVALUE;
    object _34282 = NOVALUE;
    object _34280 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3035		a = Code[pc+1]*/
    _34280 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34280);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3036		b = Code[pc+2]*/
    _34282 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34282);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3037		target = Code[pc+3]*/
    _34284 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34284);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3038		val[target] = equal(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34286 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34287 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (_34286 == _34287)
    _34288 = 1;
    else if (IS_ATOM_INT(_34286) && IS_ATOM_INT(_34287))
    _34288 = 0;
    else
    _34288 = (compare(_34286, _34287) == 0);
    _34286 = NOVALUE;
    _34287 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34288;
    if( _1 != _34288 ){
        DeRef(_1);
    }
    _34288 = NOVALUE;

    /** execute.e:3039		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:3040	end procedure*/
    _34280 = NOVALUE;
    _34282 = NOVALUE;
    _34284 = NOVALUE;
    return;
    ;
}


void _67opHASH()
{
    object _34298 = NOVALUE;
    object _34297 = NOVALUE;
    object _34296 = NOVALUE;
    object _34294 = NOVALUE;
    object _34292 = NOVALUE;
    object _34290 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3043		a = Code[pc+1]*/
    _34290 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34290);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3044		b = Code[pc+2]*/
    _34292 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34292);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3045		target = Code[pc+3]*/
    _34294 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34294);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3046		val[target] = hash(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34296 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34297 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _34298 = calc_hash(_34296, _34297);
    _34296 = NOVALUE;
    _34297 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34298;
    if( _1 != _34298 ){
        DeRef(_1);
    }
    _34298 = NOVALUE;

    /** execute.e:3047		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:3048	end procedure*/
    _34292 = NOVALUE;
    _34294 = NOVALUE;
    _34290 = NOVALUE;
    return;
    ;
}


void _67opCOMPARE()
{
    object _34308 = NOVALUE;
    object _34307 = NOVALUE;
    object _34306 = NOVALUE;
    object _34304 = NOVALUE;
    object _34302 = NOVALUE;
    object _34300 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3051		a = Code[pc+1]*/
    _34300 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34300);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3052		b = Code[pc+2]*/
    _34302 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34302);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3053		target = Code[pc+3]*/
    _34304 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34304);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3054		val[target] = compare(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34306 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34307 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_34306) && IS_ATOM_INT(_34307)){
        _34308 = (_34306 < _34307) ? -1 : (_34306 > _34307);
    }
    else{
        _34308 = compare(_34306, _34307);
    }
    _34306 = NOVALUE;
    _34307 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34308;
    if( _1 != _34308 ){
        DeRef(_1);
    }
    _34308 = NOVALUE;

    /** execute.e:3055		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:3056	end procedure*/
    _34302 = NOVALUE;
    _34304 = NOVALUE;
    _34300 = NOVALUE;
    return;
    ;
}


void _67opFIND()
{
    object _34322 = NOVALUE;
    object _34321 = NOVALUE;
    object _34320 = NOVALUE;
    object _34317 = NOVALUE;
    object _34316 = NOVALUE;
    object _34314 = NOVALUE;
    object _34312 = NOVALUE;
    object _34310 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3059		a = Code[pc+1]*/
    _34310 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34310);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3060		b = Code[pc+2]*/
    _34312 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34312);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3061		target = Code[pc+3]*/
    _34314 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34314);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3062		if not sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34316 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _34317 = IS_SEQUENCE(_34316);
    _34316 = NOVALUE;
    if (_34317 != 0)
    goto L1; // [62] 71
    _34317 = NOVALUE;

    /** execute.e:3063			RTFatal("second argument of find() must be a sequence")*/
    RefDS(_34319);
    _67RTFatal(_34319);
L1: 

    /** execute.e:3065		val[target] = find(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34320 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34321 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _34322 = find_from(_34320, _34321, 1);
    _34320 = NOVALUE;
    _34321 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34322;
    if( _1 != _34322 ){
        DeRef(_1);
    }
    _34322 = NOVALUE;

    /** execute.e:3066		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:3067	end procedure*/
    DeRef(_34310);
    _34310 = NOVALUE;
    DeRef(_34312);
    _34312 = NOVALUE;
    DeRef(_34314);
    _34314 = NOVALUE;
    return;
    ;
}


void _67opMATCH()
{
    object _34344 = NOVALUE;
    object _34343 = NOVALUE;
    object _34342 = NOVALUE;
    object _34339 = NOVALUE;
    object _34338 = NOVALUE;
    object _34335 = NOVALUE;
    object _34334 = NOVALUE;
    object _34331 = NOVALUE;
    object _34330 = NOVALUE;
    object _34328 = NOVALUE;
    object _34326 = NOVALUE;
    object _34324 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3070		a = Code[pc+1]*/
    _34324 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34324);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3071		b = Code[pc+2]*/
    _34326 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34326);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3072		target = Code[pc+3]*/
    _34328 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34328);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3073		if not sequence(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34330 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _34331 = IS_SEQUENCE(_34330);
    _34330 = NOVALUE;
    if (_34331 != 0)
    goto L1; // [62] 71
    _34331 = NOVALUE;

    /** execute.e:3074			RTFatal("first argument of match() must be a sequence")*/
    RefDS(_34333);
    _67RTFatal(_34333);
L1: 

    /** execute.e:3076		if not sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34334 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _34335 = IS_SEQUENCE(_34334);
    _34334 = NOVALUE;
    if (_34335 != 0)
    goto L2; // [84] 93
    _34335 = NOVALUE;

    /** execute.e:3077			RTFatal("second argument of match() must be a sequence")*/
    RefDS(_34337);
    _67RTFatal(_34337);
L2: 

    /** execute.e:3079		if length(val[a]) = 0 then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34338 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_SEQUENCE(_34338)){
            _34339 = SEQ_PTR(_34338)->length;
    }
    else {
        _34339 = 1;
    }
    _34338 = NOVALUE;
    if (_34339 != 0)
    goto L3; // [106] 116

    /** execute.e:3080			 RTFatal("first argument of match() must be a non-empty sequence")*/
    RefDS(_34341);
    _67RTFatal(_34341);
L3: 

    /** execute.e:3082		val[target] = match(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34342 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34343 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _34344 = e_match_from(_34342, _34343, 1);
    _34342 = NOVALUE;
    _34343 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34344;
    if( _1 != _34344 ){
        DeRef(_1);
    }
    _34344 = NOVALUE;

    /** execute.e:3083		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:3084	end procedure*/
    DeRef(_34324);
    _34324 = NOVALUE;
    _34338 = NOVALUE;
    DeRef(_34328);
    _34328 = NOVALUE;
    DeRef(_34326);
    _34326 = NOVALUE;
    return;
    ;
}


void _67opFIND_FROM()
{
    object _s_69086 = NOVALUE;
    object _34367 = NOVALUE;
    object _34365 = NOVALUE;
    object _34364 = NOVALUE;
    object _34363 = NOVALUE;
    object _34361 = NOVALUE;
    object _34360 = NOVALUE;
    object _34359 = NOVALUE;
    object _34358 = NOVALUE;
    object _34354 = NOVALUE;
    object _34353 = NOVALUE;
    object _34352 = NOVALUE;
    object _34351 = NOVALUE;
    object _34349 = NOVALUE;
    object _34347 = NOVALUE;
    object _34346 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3089			c = val[Code[pc+3]]*/
    _34346 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34347 = (object)*(((s1_ptr)_2)->base + _34346);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_34347)){
        _67c_64805 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34347)->dbl));
    }
    else{
        _67c_64805 = (object)*(((s1_ptr)_2)->base + _34347);
    }
    if (!IS_ATOM_INT(_67c_64805))
    _67c_64805 = (object)DBL_PTR(_67c_64805)->dbl;

    /** execute.e:3090			target = Code[pc+4]*/
    _34349 = _67pc_64802 + 4;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34349);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3091			if not sequence(val[Code[pc+2]]) then*/
    _34351 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34352 = (object)*(((s1_ptr)_2)->base + _34351);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_34352)){
        _34353 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34352)->dbl));
    }
    else{
        _34353 = (object)*(((s1_ptr)_2)->base + _34352);
    }
    _34354 = IS_SEQUENCE(_34353);
    _34353 = NOVALUE;
    if (_34354 != 0)
    goto L1; // [60] 82
    _34354 = NOVALUE;

    /** execute.e:3092					RTFatal("second argument of find_from() must be a sequence")*/
    RefDS(_34356);
    _67RTFatal(_34356);

    /** execute.e:3093					pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:3094					return*/
    DeRef(_s_69086);
    _34347 = NOVALUE;
    _34349 = NOVALUE;
    _34352 = NOVALUE;
    _34351 = NOVALUE;
    _34346 = NOVALUE;
    return;
L1: 

    /** execute.e:3096			s = val[Code[pc+2]][c..$]*/
    _34358 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34359 = (object)*(((s1_ptr)_2)->base + _34358);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_34359)){
        _34360 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34359)->dbl));
    }
    else{
        _34360 = (object)*(((s1_ptr)_2)->base + _34359);
    }
    if (IS_SEQUENCE(_34360)){
            _34361 = SEQ_PTR(_34360)->length;
    }
    else {
        _34361 = 1;
    }
    rhs_slice_target = (object_ptr)&_s_69086;
    RHS_Slice(_34360, _67c_64805, _34361);
    _34360 = NOVALUE;

    /** execute.e:3097			b = find( val[Code[pc+1]], s )*/
    _34363 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34364 = (object)*(((s1_ptr)_2)->base + _34363);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_34364)){
        _34365 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34364)->dbl));
    }
    else{
        _34365 = (object)*(((s1_ptr)_2)->base + _34364);
    }
    _67b_64804 = find_from(_34365, _s_69086, 1);
    _34365 = NOVALUE;

    /** execute.e:3098			if b then*/
    if (_67b_64804 == 0)
    {
        goto L2; // [141] 161
    }
    else{
    }

    /** execute.e:3099					b += c - 1*/
    _34367 = _67c_64805 - 1;
    if ((object)((uintptr_t)_34367 +(uintptr_t) HIGH_BITS) >= 0){
        _34367 = NewDouble((eudouble)_34367);
    }
    if (IS_ATOM_INT(_34367)) {
        _67b_64804 = _67b_64804 + _34367;
    }
    else {
        _67b_64804 = NewDouble((eudouble)_67b_64804 + DBL_PTR(_34367)->dbl);
    }
    DeRef(_34367);
    _34367 = NOVALUE;
    if (!IS_ATOM_INT(_67b_64804)) {
        _1 = (object)(DBL_PTR(_67b_64804)->dbl);
        DeRefDS(_67b_64804);
        _67b_64804 = _1;
    }
L2: 

    /** execute.e:3101			val[target] = b*/
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67b_64804;
    DeRef(_1);

    /** execute.e:3102			pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:3103	end procedure*/
    DeRef(_s_69086);
    _34347 = NOVALUE;
    _34359 = NOVALUE;
    DeRef(_34349);
    _34349 = NOVALUE;
    _34364 = NOVALUE;
    _34352 = NOVALUE;
    DeRef(_34351);
    _34351 = NOVALUE;
    DeRef(_34363);
    _34363 = NOVALUE;
    DeRef(_34346);
    _34346 = NOVALUE;
    DeRef(_34358);
    _34358 = NOVALUE;
    return;
    ;
}


void _67opMATCH_FROM()
{
    object _s_69120 = NOVALUE;
    object _34410 = NOVALUE;
    object _34409 = NOVALUE;
    object _34407 = NOVALUE;
    object _34406 = NOVALUE;
    object _34405 = NOVALUE;
    object _34404 = NOVALUE;
    object _34403 = NOVALUE;
    object _34402 = NOVALUE;
    object _34401 = NOVALUE;
    object _34400 = NOVALUE;
    object _34399 = NOVALUE;
    object _34398 = NOVALUE;
    object _34396 = NOVALUE;
    object _34390 = NOVALUE;
    object _34386 = NOVALUE;
    object _34385 = NOVALUE;
    object _34381 = NOVALUE;
    object _34380 = NOVALUE;
    object _34378 = NOVALUE;
    object _34376 = NOVALUE;
    object _34375 = NOVALUE;
    object _34373 = NOVALUE;
    object _34371 = NOVALUE;
    object _34370 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3108			c = val[Code[pc+3]]*/
    _34370 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34371 = (object)*(((s1_ptr)_2)->base + _34370);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_34371)){
        _67c_64805 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34371)->dbl));
    }
    else{
        _67c_64805 = (object)*(((s1_ptr)_2)->base + _34371);
    }
    if (!IS_ATOM_INT(_67c_64805))
    _67c_64805 = (object)DBL_PTR(_67c_64805)->dbl;

    /** execute.e:3109			target = Code[pc+4]*/
    _34373 = _67pc_64802 + 4;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34373);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3110			s = val[Code[pc+2]]*/
    _34375 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34376 = (object)*(((s1_ptr)_2)->base + _34375);
    DeRef(_s_69120);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_34376)){
        _s_69120 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34376)->dbl));
    }
    else{
        _s_69120 = (object)*(((s1_ptr)_2)->base + _34376);
    }
    Ref(_s_69120);

    /** execute.e:3111			a = Code[pc+1]*/
    _34378 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34378);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3112			if not sequence(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34380 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _34381 = IS_SEQUENCE(_34380);
    _34380 = NOVALUE;
    if (_34381 != 0)
    goto L1; // [86] 108
    _34381 = NOVALUE;

    /** execute.e:3113					RTFatal("first argument of match_from() must be a sequence")*/
    RefDS(_34383);
    _67RTFatal(_34383);

    /** execute.e:3114					pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:3115					return*/
    DeRef(_s_69120);
    _34376 = NOVALUE;
    _34371 = NOVALUE;
    _34378 = NOVALUE;
    _34373 = NOVALUE;
    _34370 = NOVALUE;
    _34375 = NOVALUE;
    return;
L1: 

    /** execute.e:3117			if length(val[a]) = 0 then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34385 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_SEQUENCE(_34385)){
            _34386 = SEQ_PTR(_34385)->length;
    }
    else {
        _34386 = 1;
    }
    _34385 = NOVALUE;
    if (_34386 != 0)
    goto L2; // [121] 144

    /** execute.e:3118					RTFatal("first argument of match_from() must be a non-empty sequence")*/
    RefDS(_34388);
    _67RTFatal(_34388);

    /** execute.e:3119					pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:3120					return*/
    DeRef(_s_69120);
    _34376 = NOVALUE;
    _34371 = NOVALUE;
    _34385 = NOVALUE;
    DeRef(_34378);
    _34378 = NOVALUE;
    DeRef(_34373);
    _34373 = NOVALUE;
    DeRef(_34370);
    _34370 = NOVALUE;
    DeRef(_34375);
    _34375 = NOVALUE;
    return;
L2: 

    /** execute.e:3122			if not sequence(s) then*/
    _34390 = IS_SEQUENCE(_s_69120);
    if (_34390 != 0)
    goto L3; // [149] 171
    _34390 = NOVALUE;

    /** execute.e:3123					RTFatal("second argument of match_from() must be a sequence")*/
    RefDS(_34392);
    _67RTFatal(_34392);

    /** execute.e:3124					pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:3125					return*/
    DeRef(_s_69120);
    _34376 = NOVALUE;
    _34371 = NOVALUE;
    _34385 = NOVALUE;
    DeRef(_34378);
    _34378 = NOVALUE;
    DeRef(_34373);
    _34373 = NOVALUE;
    DeRef(_34370);
    _34370 = NOVALUE;
    DeRef(_34375);
    _34375 = NOVALUE;
    return;
L3: 

    /** execute.e:3127			if c < 1 then*/
    if (_67c_64805 >= 1)
    goto L4; // [175] 204

    /** execute.e:3128					RTFatal(sprintf("index (%d) out of bounds in match_from()", c ))*/
    _34396 = EPrintf(-9999999, _34395, _67c_64805);
    _67RTFatal(_34396);
    _34396 = NOVALUE;

    /** execute.e:3129					pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:3130					return*/
    DeRef(_s_69120);
    _34376 = NOVALUE;
    _34371 = NOVALUE;
    _34385 = NOVALUE;
    DeRef(_34378);
    _34378 = NOVALUE;
    DeRef(_34373);
    _34373 = NOVALUE;
    DeRef(_34370);
    _34370 = NOVALUE;
    DeRef(_34375);
    _34375 = NOVALUE;
    return;
L4: 

    /** execute.e:3132			if not (length(s) = 0 and c = 1) and c > length(s) + 1 then*/
    if (IS_SEQUENCE(_s_69120)){
            _34398 = SEQ_PTR(_s_69120)->length;
    }
    else {
        _34398 = 1;
    }
    _34399 = (_34398 == 0);
    _34398 = NOVALUE;
    if (_34399 == 0) {
        DeRef(_34400);
        _34400 = 0;
        goto L5; // [213] 227
    }
    _34401 = (_67c_64805 == 1);
    _34400 = (_34401 != 0);
L5: 
    _34402 = (_34400 == 0);
    _34400 = NOVALUE;
    if (_34402 == 0) {
        goto L6; // [230] 276
    }
    if (IS_SEQUENCE(_s_69120)){
            _34404 = SEQ_PTR(_s_69120)->length;
    }
    else {
        _34404 = 1;
    }
    _34405 = _34404 + 1;
    _34404 = NOVALUE;
    _34406 = (_67c_64805 > _34405);
    _34405 = NOVALUE;
    if (_34406 == 0)
    {
        DeRef(_34406);
        _34406 = NOVALUE;
        goto L6; // [248] 276
    }
    else{
        DeRef(_34406);
        _34406 = NOVALUE;
    }

    /** execute.e:3133					RTFatal(sprintf("index (%d) out of bounds in match_from()", c ))*/
    _34407 = EPrintf(-9999999, _34395, _67c_64805);
    _67RTFatal(_34407);
    _34407 = NOVALUE;

    /** execute.e:3134					pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:3135					return*/
    DeRef(_s_69120);
    _34376 = NOVALUE;
    _34371 = NOVALUE;
    DeRef(_34401);
    _34401 = NOVALUE;
    _34385 = NOVALUE;
    DeRef(_34399);
    _34399 = NOVALUE;
    DeRef(_34402);
    _34402 = NOVALUE;
    DeRef(_34378);
    _34378 = NOVALUE;
    DeRef(_34373);
    _34373 = NOVALUE;
    DeRef(_34370);
    _34370 = NOVALUE;
    DeRef(_34375);
    _34375 = NOVALUE;
    return;
L6: 

    /** execute.e:3137			val[target] = match( val[a], s, c )*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34409 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _34410 = e_match_from(_34409, _s_69120, _67c_64805);
    _34409 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34410;
    if( _1 != _34410 ){
        DeRef(_1);
    }
    _34410 = NOVALUE;

    /** execute.e:3138			pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:3139	end procedure*/
    DeRef(_s_69120);
    _34376 = NOVALUE;
    _34371 = NOVALUE;
    DeRef(_34401);
    _34401 = NOVALUE;
    _34385 = NOVALUE;
    DeRef(_34399);
    _34399 = NOVALUE;
    DeRef(_34402);
    _34402 = NOVALUE;
    DeRef(_34378);
    _34378 = NOVALUE;
    DeRef(_34373);
    _34373 = NOVALUE;
    DeRef(_34370);
    _34370 = NOVALUE;
    DeRef(_34375);
    _34375 = NOVALUE;
    return;
    ;
}


void _67opPEEK2U()
{
    object _34417 = NOVALUE;
    object _34416 = NOVALUE;
    object _34414 = NOVALUE;
    object _34412 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3142		a = Code[pc+1]*/
    _34412 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34412);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3143		target = Code[pc+2]*/
    _34414 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34414);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3144		val[target] = peek2u(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34416 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_34416)) {
        _34417 = *(uint16_t *)_34416;
    }
    else if (IS_ATOM(_34416)) {
        _34417 = *(uint16_t *)(uintptr_t)(DBL_PTR(_34416)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_34416);
        peek2_addr = (uint16_t *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34417 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek2_addr++;
        }
    }
    _34416 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34417;
    if( _1 != _34417 ){
        DeRef(_1);
    }
    _34417 = NOVALUE;

    /** execute.e:3145		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3146	end procedure*/
    _34414 = NOVALUE;
    _34412 = NOVALUE;
    return;
    ;
}


void _67opPEEK2S()
{
    object _34424 = NOVALUE;
    object _34423 = NOVALUE;
    object _34421 = NOVALUE;
    object _34419 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3149		a = Code[pc+1]*/
    _34419 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34419);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3150		target = Code[pc+2]*/
    _34421 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34421);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3151		val[target] = peek2s(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34423 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_34423)) {
        _34424 = *(int16_t *)_34423;
    }
    else if (IS_ATOM(_34423)) {
        _34424 = *(int16_t *)(uintptr_t)(DBL_PTR(_34423)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_34423);
        peek2_addr = (uint16_t *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34424 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)(int16_t)*peek2_addr++;
        }
    }
    _34423 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34424;
    if( _1 != _34424 ){
        DeRef(_1);
    }
    _34424 = NOVALUE;

    /** execute.e:3152		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3153	end procedure*/
    _34421 = NOVALUE;
    _34419 = NOVALUE;
    return;
    ;
}


void _67opPEEK4U()
{
    object _34431 = NOVALUE;
    object _34430 = NOVALUE;
    object _34428 = NOVALUE;
    object _34426 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3156		a = Code[pc+1]*/
    _34426 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34426);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3157		target = Code[pc+2]*/
    _34428 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34428);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3158		val[target] = peek4u(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34430 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_34430)) {
        _34431 = (object)*(uint32_t *)_34430;
        if ((uintptr_t)_34431 > (uintptr_t)MAXINT){
            _34431 = NewDouble((eudouble)(uintptr_t)_34431);
        }
    }
    else if (IS_ATOM(_34430)) {
        _34431 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_34430)->dbl);
        if ((uintptr_t)_34431 > (uintptr_t)MAXINT){
            _34431 = NewDouble((eudouble)(uintptr_t)_34431);
        }
    }
    else {
        _1 = (object)SEQ_PTR(_34430);
        peek4_addr = (uint32_t *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34431 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            _1 = (object)*peek4_addr++;
            if ((uintptr_t)_1 > (uintptr_t)MAXINT){
                _1 = NewDouble((eudouble)(uintptr_t)_1);
            }
            *pokeptr_addr = _1;
        }
    }
    _34430 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34431;
    if( _1 != _34431 ){
        DeRef(_1);
    }
    _34431 = NOVALUE;

    /** execute.e:3159		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3160	end procedure*/
    _34426 = NOVALUE;
    _34428 = NOVALUE;
    return;
    ;
}


void _67opPEEK4S()
{
    object _34438 = NOVALUE;
    object _34437 = NOVALUE;
    object _34435 = NOVALUE;
    object _34433 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3163		a = Code[pc+1]*/
    _34433 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34433);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3164		target = Code[pc+2]*/
    _34435 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34435);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3165		val[target] = peek4s(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34437 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_34437)) {
        _34438 = (object)*(int32_t *)_34437;
        if (_34438 < MININT || _34438 > MAXINT){
            _34438 = NewDouble((eudouble)(object)_34438);
        }
    }
    else if (IS_ATOM(_34437)) {
        _34438 = (object)*(int32_t *)(uintptr_t)(DBL_PTR(_34437)->dbl);
        if (_34438 < MININT || _34438 > MAXINT){
            _34438 = NewDouble((eudouble)(object)_34438);
        }
    }
    else {
        _1 = (object)SEQ_PTR(_34437);
        peek4_addr = (uint32_t *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34438 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            _1 = (object)(int32_t)*peek4_addr++;
            if (_1 < MININT || _1 > MAXINT){
                _1 = NewDouble((eudouble)_1);
            }
            *pokeptr_addr = _1;
        }
    }
    _34437 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34438;
    if( _1 != _34438 ){
        DeRef(_1);
    }
    _34438 = NOVALUE;

    /** execute.e:3166		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3167	end procedure*/
    _34433 = NOVALUE;
    _34435 = NOVALUE;
    return;
    ;
}


void _67opPEEK8U()
{
    object _34445 = NOVALUE;
    object _34444 = NOVALUE;
    object _34442 = NOVALUE;
    object _34440 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3170		a = Code[pc+1]*/
    _34440 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34440);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3171		target = Code[pc+2]*/
    _34442 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34442);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3172		val[target] = peek8u(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34444 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    {
        int64_t peek8_longlong;
        if (IS_ATOM_INT(_34444)) {
            peek8_longlong = *(int64_t *)_34444;
            if (peek8_longlong > (uint64_t)MAXINT){
                _34445 = NewDouble((eudouble)(uint64_t)peek8_longlong);
            }
            else{
                _34445 = (object) peek8_longlong;
            }
        }
        else if (IS_ATOM(_34444)) {
            peek8_longlong = *(int64_t *)(uintptr_t)(DBL_PTR(_34444)->dbl);
            if (peek8_longlong > (uint64_t)MAXINT){
                _34445 = NewDouble((eudouble)(uint64_t)peek8_longlong);
            }
            else{
                _34445 = (object) peek8_longlong;
            }
        }
        else {
            _1 = (object)SEQ_PTR(_34444);
            peek8_addr = (uint64_t *)get_pos_int("peek8s/peek8u", *(((s1_ptr)_1)->base+1));
            _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
            pokeptr_addr = (uintptr_t *)NewS1(_2);
            _34445 = MAKE_SEQ(pokeptr_addr);
            pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
            while (--_2 >= 0) {
                pokeptr_addr++;
                peek8_longlong = *peek8_addr++;
                if ((uint64_t)peek8_longlong > (uint64_t)MAXINT){
                    _1 = NewDouble((eudouble) (uint64_t) peek8_longlong);
                }
                else{
                    _1 = (object)peek8_longlong;
                }
                *pokeptr_addr = _1;
            }
        }
    }
    _34444 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34445;
    if( _1 != _34445 ){
        DeRef(_1);
    }
    _34445 = NOVALUE;

    /** execute.e:3173		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3174	end procedure*/
    _34440 = NOVALUE;
    _34442 = NOVALUE;
    return;
    ;
}


void _67opPEEK8S()
{
    object _34452 = NOVALUE;
    object _34451 = NOVALUE;
    object _34449 = NOVALUE;
    object _34447 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3177		a = Code[pc+1]*/
    _34447 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34447);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3178		target = Code[pc+2]*/
    _34449 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34449);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3179		val[target] = peek8s(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34451 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    {
        int64_t peek8_longlong;
        if (IS_ATOM_INT(_34451)) {
            peek8_longlong = *(int64_t *)_34451;
            if (peek8_longlong < (int64_t)MININT || peek8_longlong > (int64_t) MAXINT){
                _34452 = NewDouble((eudouble) peek8_longlong);
            }
            else{
                _34452 = (object) peek8_longlong;
            }
        }
        else if (IS_ATOM(_34451)) {
            peek8_longlong = *(int64_t *)(uintptr_t)(DBL_PTR(_34451)->dbl);
            if (peek8_longlong < (int64_t)MININT || peek8_longlong > (int64_t) MAXINT){
                _34452 = NewDouble((eudouble) peek8_longlong);
            }
            else{
                _34452 = (object) peek8_longlong;
            }
        }
        else {
            _1 = (object)SEQ_PTR(_34451);
            peek8_addr = (uint64_t *)get_pos_int("peek8s/peek8u", *(((s1_ptr)_1)->base+1));
            _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
            pokeptr_addr = (uintptr_t *)NewS1(_2);
            _34452 = MAKE_SEQ(pokeptr_addr);
            pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
            while (--_2 >= 0) {
                pokeptr_addr++;
                peek8_longlong = *peek8_addr++;
                if (peek8_longlong < (int64_t) MININT || peek8_longlong > (int64_t) MAXINT){
                    _1 = NewDouble((eudouble)peek8_longlong);
                }
                else{
                    _1 = (object)(int64_t) peek8_longlong;
                }
                *pokeptr_addr = _1;
            }
        }
    }
    _34451 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34452;
    if( _1 != _34452 ){
        DeRef(_1);
    }
    _34452 = NOVALUE;

    /** execute.e:3180		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3181	end procedure*/
    _34447 = NOVALUE;
    _34449 = NOVALUE;
    return;
    ;
}


void _67opPEEK_STRING()
{
    object _34459 = NOVALUE;
    object _34458 = NOVALUE;
    object _34456 = NOVALUE;
    object _34454 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3183		a = Code[pc+1]*/
    _34454 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34454);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3184		target = Code[pc+2]*/
    _34456 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34456);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3185		val[target] = peek_string(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34458 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_34458)) {
        _34459 =  NewString((char *)_34458);
    }
    else if (IS_ATOM(_34458)) {
        _34459 = NewString((char *)(uintptr_t)(DBL_PTR(_34458)->dbl));
    }
    else {
        _1 = (object)SEQ_PTR(_34458);
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34459 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
        }
    }
    _34458 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34459;
    if( _1 != _34459 ){
        DeRef(_1);
    }
    _34459 = NOVALUE;

    /** execute.e:3186		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3187	end procedure*/
    _34454 = NOVALUE;
    _34456 = NOVALUE;
    return;
    ;
}


void _67opPEEK()
{
    object _34466 = NOVALUE;
    object _34465 = NOVALUE;
    object _34463 = NOVALUE;
    object _34461 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3190		a = Code[pc+1]*/
    _34461 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34461);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3191		target = Code[pc+2]*/
    _34463 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34463);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3192		val[target] = peek(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34465 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_34465)) {
        _34466 = *(uint8_t *)_34465;
    }
    else if (IS_ATOM(_34465)) {
        _34466 = *(uint8_t *)(uintptr_t)(DBL_PTR(_34465)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_34465);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34466 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
    }
    _34465 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34466;
    if( _1 != _34466 ){
        DeRef(_1);
    }
    _34466 = NOVALUE;

    /** execute.e:3193		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3194	end procedure*/
    _34461 = NOVALUE;
    _34463 = NOVALUE;
    return;
    ;
}


void _67opPEEKS()
{
    object _34473 = NOVALUE;
    object _34472 = NOVALUE;
    object _34470 = NOVALUE;
    object _34468 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3197		a = Code[pc+1]*/
    _34468 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34468);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3198		target = Code[pc+2]*/
    _34470 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34470);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3199		val[target] = peeks(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34472 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_34472)) {
        _34473 = *(int8_t *)_34472;
    }
    else if (IS_ATOM(_34472)) {
        _34473 = *(int8_t *)(uintptr_t)(DBL_PTR(_34472)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_34472);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34473 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)(int8_t)*peek_addr++;
        }
    }
    _34472 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34473;
    if( _1 != _34473 ){
        DeRef(_1);
    }
    _34473 = NOVALUE;

    /** execute.e:3200		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3201	end procedure*/
    _34468 = NOVALUE;
    _34470 = NOVALUE;
    return;
    ;
}


void _67opSIZEOF()
{
    object _34480 = NOVALUE;
    object _34479 = NOVALUE;
    object _34477 = NOVALUE;
    object _34475 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3204		a = Code[pc+1]*/
    _34475 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34475);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3205		b = Code[pc+2]*/
    _34477 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34477);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3206		val[b] = sizeof( val[a] )*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34479 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _34480 = eu_sizeof( _34479 );
    _34479 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_64804);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34480;
    if( _1 != _34480 ){
        DeRef(_1);
    }
    _34480 = NOVALUE;

    /** execute.e:3207		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3208	end procedure*/
    _34475 = NOVALUE;
    _34477 = NOVALUE;
    return;
    ;
}


void _67opPOKE()
{
    object _34487 = NOVALUE;
    object _34486 = NOVALUE;
    object _34484 = NOVALUE;
    object _34482 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3211		a = Code[pc+1]*/
    _34482 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34482);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3212		b = Code[pc+2]*/
    _34484 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34484);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3213		poke(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34486 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34487 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_34486)){
        poke_addr = (uint8_t *)_34486;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_34486)->dbl);
    }
    if (IS_ATOM_INT(_34487)) {
        *poke_addr = (uint8_t)_34487;
    }
    else if (IS_ATOM(_34487)) {
        *poke_addr = (uint8_t)DBL_PTR(_34487)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34487);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke_addr++ = (uint8_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34486 = NOVALUE;
    _34487 = NOVALUE;

    /** execute.e:3214		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3215	end procedure*/
    _34482 = NOVALUE;
    _34484 = NOVALUE;
    return;
    ;
}


void _67opPOKE4()
{
    object _34494 = NOVALUE;
    object _34493 = NOVALUE;
    object _34491 = NOVALUE;
    object _34489 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3218		a = Code[pc+1]*/
    _34489 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34489);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3219		b = Code[pc+2]*/
    _34491 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34491);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3220		poke4(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34493 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34494 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_34493)){
        poke4_addr = (uint32_t *)_34493;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_34493)->dbl);
    }
    if (IS_ATOM_INT(_34494)) {
        *poke4_addr = (uint32_t)_34494;
    }
    else if (IS_ATOM(_34494)) {
        *poke4_addr = (uint32_t)DBL_PTR(_34494)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34494);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke4_addr++ = (int32_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34493 = NOVALUE;
    _34494 = NOVALUE;

    /** execute.e:3221		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3222	end procedure*/
    _34491 = NOVALUE;
    _34489 = NOVALUE;
    return;
    ;
}


void _67opPOKE8()
{
    object _34501 = NOVALUE;
    object _34500 = NOVALUE;
    object _34498 = NOVALUE;
    object _34496 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3225		a = Code[pc+1]*/
    _34496 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34496);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3226		b = Code[pc+2]*/
    _34498 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34498);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3227		poke8(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34500 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34501 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_34500)){
        poke8_addr = (uint64_t *)_34500;
    }
    else {
        poke8_addr = (uint64_t *)(uintptr_t)(DBL_PTR(_34500)->dbl);
    }
    if (IS_ATOM_INT(_34501)) {
        *poke8_addr = (uint64_t)_34501;
    }
    else if (IS_ATOM(_34501)) {
        *poke8_addr = (uint64_t)DBL_PTR(_34501)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34501);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke8_addr++ = (uint64_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke8_addr++ = (uint64_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34500 = NOVALUE;
    _34501 = NOVALUE;

    /** execute.e:3228		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3229	end procedure*/
    _34496 = NOVALUE;
    _34498 = NOVALUE;
    return;
    ;
}


void _67opPOKE2()
{
    object _34508 = NOVALUE;
    object _34507 = NOVALUE;
    object _34505 = NOVALUE;
    object _34503 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3232		a = Code[pc+1]*/
    _34503 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34503);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3233		b = Code[pc+2]*/
    _34505 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34505);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3234		poke2(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34507 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34508 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_ATOM_INT(_34507)){
        poke2_addr = (uint16_t *)_34507;
    }
    else {
        poke2_addr = (uint16_t *)(uintptr_t)(DBL_PTR(_34507)->dbl);
    }
    if (IS_ATOM_INT(_34508)) {
        *poke2_addr = (uint16_t)_34508;
    }
    else if (IS_ATOM(_34508)) {
        *poke2_addr = (uint16_t)DBL_PTR(_34508)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34508);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke2_addr++ = (uint16_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke2_addr++ = (uint16_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34507 = NOVALUE;
    _34508 = NOVALUE;

    /** execute.e:3235		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3236	end procedure*/
    _34503 = NOVALUE;
    _34505 = NOVALUE;
    return;
    ;
}


void _67opMEM_COPY()
{
    object _34518 = NOVALUE;
    object _34517 = NOVALUE;
    object _34516 = NOVALUE;
    object _34514 = NOVALUE;
    object _34512 = NOVALUE;
    object _34510 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3240		a = Code[pc+1]*/
    _34510 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34510);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3241		b = Code[pc+2]*/
    _34512 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34512);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3242		c = Code[pc+3]*/
    _34514 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64805 = (object)*(((s1_ptr)_2)->base + _34514);
    if (!IS_ATOM_INT(_67c_64805)){
        _67c_64805 = (object)DBL_PTR(_67c_64805)->dbl;
    }

    /** execute.e:3243		mem_copy(val[a], val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34516 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34517 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34518 = (object)*(((s1_ptr)_2)->base + _67c_64805);
    memory_copy(_34516, _34517, _34518);
    _34516 = NOVALUE;
    _34517 = NOVALUE;
    _34518 = NOVALUE;

    /** execute.e:3244		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:3245	end procedure*/
    _34512 = NOVALUE;
    _34514 = NOVALUE;
    _34510 = NOVALUE;
    return;
    ;
}


void _67opMEM_SET()
{
    object _34528 = NOVALUE;
    object _34527 = NOVALUE;
    object _34526 = NOVALUE;
    object _34524 = NOVALUE;
    object _34522 = NOVALUE;
    object _34520 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3248		a = Code[pc+1]*/
    _34520 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34520);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3249		b = Code[pc+2]*/
    _34522 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34522);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3250		c = Code[pc+3]*/
    _34524 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64805 = (object)*(((s1_ptr)_2)->base + _34524);
    if (!IS_ATOM_INT(_67c_64805)){
        _67c_64805 = (object)DBL_PTR(_67c_64805)->dbl;
    }

    /** execute.e:3251		mem_set(val[a], val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34526 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34527 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34528 = (object)*(((s1_ptr)_2)->base + _67c_64805);
    memory_set(_34526, _34527, _34528);
    _34526 = NOVALUE;
    _34527 = NOVALUE;
    _34528 = NOVALUE;

    /** execute.e:3252		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:3253	end procedure*/
    _34522 = NOVALUE;
    _34520 = NOVALUE;
    _34524 = NOVALUE;
    return;
    ;
}


void _67opCALL()
{
    object _34532 = NOVALUE;
    object _34530 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3256		a = Code[pc+1]*/
    _34530 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34530);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3257		call(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34532 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_34532))
    _0 = (object)_34532;
    else
    _0 = (object)(uintptr_t)(DBL_PTR(_34532)->dbl);
    (*(void(*)())_0)();
    _34532 = NOVALUE;

    /** execute.e:3258		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:3259	end procedure*/
    _34530 = NOVALUE;
    return;
    ;
}


void _67opSYSTEM()
{
    object _34545 = NOVALUE;
    object _34544 = NOVALUE;
    object _34542 = NOVALUE;
    object _34541 = NOVALUE;
    object _34539 = NOVALUE;
    object _34538 = NOVALUE;
    object _34536 = NOVALUE;
    object _34534 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3262		a = Code[pc+1]*/
    _34534 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34534);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3263		b = Code[pc+2]*/
    _34536 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34536);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3264		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34538 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _34539 = IS_ATOM(_34538);
    _34538 = NOVALUE;
    if (_34539 == 0)
    {
        _34539 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _34539 = NOVALUE;
    }

    /** execute.e:3265			RTFatal("first argument of system() must be a sequence")*/
    RefDS(_34540);
    _67RTFatal(_34540);
L1: 

    /** execute.e:3267		if sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34541 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _34542 = IS_SEQUENCE(_34541);
    _34541 = NOVALUE;
    if (_34542 == 0)
    {
        _34542 = NOVALUE;
        goto L2; // [68] 77
    }
    else{
        _34542 = NOVALUE;
    }

    /** execute.e:3268			RTFatal("second argument of system() must be an atom")*/
    RefDS(_34543);
    _67RTFatal(_34543);
L2: 

    /** execute.e:3270		system(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34544 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34545 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    system_call(_34544, _34545);
    _34544 = NOVALUE;
    _34545 = NOVALUE;

    /** execute.e:3271		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3272	end procedure*/
    DeRef(_34536);
    _34536 = NOVALUE;
    DeRef(_34534);
    _34534 = NOVALUE;
    return;
    ;
}


void _67opSYSTEM_EXEC()
{
    object _34559 = NOVALUE;
    object _34558 = NOVALUE;
    object _34557 = NOVALUE;
    object _34556 = NOVALUE;
    object _34555 = NOVALUE;
    object _34554 = NOVALUE;
    object _34553 = NOVALUE;
    object _34551 = NOVALUE;
    object _34549 = NOVALUE;
    object _34547 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3275		a = Code[pc+1]*/
    _34547 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34547);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3276		b = Code[pc+2]*/
    _34549 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34549);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3277		target = Code[pc+3]*/
    _34551 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34551);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3278		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34553 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _34554 = IS_ATOM(_34553);
    _34553 = NOVALUE;
    if (_34554 == 0)
    {
        _34554 = NOVALUE;
        goto L1; // [62] 71
    }
    else{
        _34554 = NOVALUE;
    }

    /** execute.e:3279			RTFatal("first argument of system() must be a sequence")*/
    RefDS(_34540);
    _67RTFatal(_34540);
L1: 

    /** execute.e:3281		if sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34555 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _34556 = IS_SEQUENCE(_34555);
    _34555 = NOVALUE;
    if (_34556 == 0)
    {
        _34556 = NOVALUE;
        goto L2; // [84] 93
    }
    else{
        _34556 = NOVALUE;
    }

    /** execute.e:3282			RTFatal("second argument of system() must be an atom")*/
    RefDS(_34543);
    _67RTFatal(_34543);
L2: 

    /** execute.e:3284		val[target] = system_exec(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34557 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34558 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _34559 = system_exec_call(_34557, _34558);
    _34557 = NOVALUE;
    _34558 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34559;
    if( _1 != _34559 ){
        DeRef(_1);
    }
    _34559 = NOVALUE;

    /** execute.e:3285		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:3286	end procedure*/
    DeRef(_34551);
    _34551 = NOVALUE;
    DeRef(_34547);
    _34547 = NOVALUE;
    DeRef(_34549);
    _34549 = NOVALUE;
    return;
    ;
}


void _67opOPEN()
{
    object _34586 = NOVALUE;
    object _34585 = NOVALUE;
    object _34584 = NOVALUE;
    object _34583 = NOVALUE;
    object _34580 = NOVALUE;
    object _34579 = NOVALUE;
    object _34577 = NOVALUE;
    object _34576 = NOVALUE;
    object _34574 = NOVALUE;
    object _34573 = NOVALUE;
    object _34572 = NOVALUE;
    object _34570 = NOVALUE;
    object _34569 = NOVALUE;
    object _34567 = NOVALUE;
    object _34565 = NOVALUE;
    object _34563 = NOVALUE;
    object _34561 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3291		a = Code[pc+1]*/
    _34561 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34561);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3292		b = Code[pc+2]*/
    _34563 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34563);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3293		c = Code[pc+3]*/
    _34565 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64805 = (object)*(((s1_ptr)_2)->base + _34565);
    if (!IS_ATOM_INT(_67c_64805)){
        _67c_64805 = (object)DBL_PTR(_67c_64805)->dbl;
    }

    /** execute.e:3294		target = Code[pc+4]*/
    _34567 = _67pc_64802 + 4;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34567);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3296		if atom(val[b]) or length(val[b]) > 2 then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34569 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _34570 = IS_ATOM(_34569);
    _34569 = NOVALUE;
    if (_34570 != 0) {
        goto L1; // [78] 102
    }
    _2 = (object)SEQ_PTR(_67val_64812);
    _34572 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    if (IS_SEQUENCE(_34572)){
            _34573 = SEQ_PTR(_34572)->length;
    }
    else {
        _34573 = 1;
    }
    _34572 = NOVALUE;
    _34574 = (_34573 > 2);
    _34573 = NOVALUE;
    if (_34574 == 0)
    {
        DeRef(_34574);
        _34574 = NOVALUE;
        goto L2; // [98] 108
    }
    else{
        DeRef(_34574);
        _34574 = NOVALUE;
    }
L1: 

    /** execute.e:3297		   RTFatal("invalid open mode")*/
    RefDS(_34575);
    _67RTFatal(_34575);
L2: 

    /** execute.e:3299		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34576 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _34577 = IS_ATOM(_34576);
    _34576 = NOVALUE;
    if (_34577 == 0)
    {
        _34577 = NOVALUE;
        goto L3; // [121] 130
    }
    else{
        _34577 = NOVALUE;
    }

    /** execute.e:3300		   RTFatal("device or file name must be a sequence")*/
    RefDS(_34578);
    _67RTFatal(_34578);
L3: 

    /** execute.e:3302		if not atom(val[c]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34579 = (object)*(((s1_ptr)_2)->base + _67c_64805);
    _34580 = IS_ATOM(_34579);
    _34579 = NOVALUE;
    if (_34580 != 0)
    goto L4; // [143] 152
    _34580 = NOVALUE;

    /** execute.e:3303			RTFatal("cleanup must be an atom")*/
    RefDS(_34582);
    _67RTFatal(_34582);
L4: 

    /** execute.e:3305		val[target] = open(val[a], val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34583 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34584 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34585 = (object)*(((s1_ptr)_2)->base + _67c_64805);
    _34586 = EOpen(_34583, _34584, _34585);
    _34583 = NOVALUE;
    _34584 = NOVALUE;
    _34585 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34586;
    if( _1 != _34586 ){
        DeRef(_1);
    }
    _34586 = NOVALUE;

    /** execute.e:3306		pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:3307	end procedure*/
    DeRef(_34563);
    _34563 = NOVALUE;
    DeRef(_34561);
    _34561 = NOVALUE;
    DeRef(_34565);
    _34565 = NOVALUE;
    _34572 = NOVALUE;
    DeRef(_34567);
    _34567 = NOVALUE;
    return;
    ;
}


void _67opCLOSE()
{
    object _34590 = NOVALUE;
    object _34588 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3310		a = Code[pc+1]*/
    _34588 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34588);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3311		close(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34590 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (IS_ATOM_INT(_34590))
    EClose(_34590);
    else
    EClose((object)DBL_PTR(_34590)->dbl);
    _34590 = NOVALUE;

    /** execute.e:3312		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:3313	end procedure*/
    _34588 = NOVALUE;
    return;
    ;
}


void _67opABORT()
{
    object _34594 = NOVALUE;
    object _34593 = NOVALUE;
    object _34592 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3316		Cleanup(val[Code[pc+1]])*/
    _34592 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34593 = (object)*(((s1_ptr)_2)->base + _34592);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_34593)){
        _34594 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34593)->dbl));
    }
    else{
        _34594 = (object)*(((s1_ptr)_2)->base + _34593);
    }
    Ref(_34594);
    _49Cleanup(_34594);
    _34594 = NOVALUE;

    /** execute.e:3317	end procedure*/
    _34593 = NOVALUE;
    _34592 = NOVALUE;
    return;
    ;
}


void _67opGETC()
{
    object _34600 = NOVALUE;
    object _34599 = NOVALUE;
    object _34597 = NOVALUE;
    object _34595 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3320		a = Code[pc+1]*/
    _34595 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34595);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3321		target = Code[pc+2]*/
    _34597 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34597);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3322		val[target] = getc(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34599 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (_34599 != last_r_file_no) {
        last_r_file_ptr = which_file(_34599, EF_READ);
        if (IS_ATOM_INT(_34599)){
            last_r_file_no = _34599;
        }
        else{
            last_r_file_no = NOVALUE;
        }
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _34600 = getc((FILE*)xstdin);
        }
        else{
            _34600 = getc(last_r_file_ptr);
        }
    }
    else{
        _34600 = getc(last_r_file_ptr);
    }
    _34599 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34600;
    if( _1 != _34600 ){
        DeRef(_1);
    }
    _34600 = NOVALUE;

    /** execute.e:3323		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3324	end procedure*/
    _34595 = NOVALUE;
    _34597 = NOVALUE;
    return;
    ;
}


void _67opGETS()
{
    object _34607 = NOVALUE;
    object _34606 = NOVALUE;
    object _34604 = NOVALUE;
    object _34602 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3328		a = Code[pc+1]*/
    _34602 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34602);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3329		target = Code[pc+2]*/
    _34604 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34604);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3330		val[target] = gets(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34606 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _34607 = EGets(_34606);
    _34606 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34607;
    if( _1 != _34607 ){
        DeRef(_1);
    }
    _34607 = NOVALUE;

    /** execute.e:3331		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3332	end procedure*/
    _34602 = NOVALUE;
    _34604 = NOVALUE;
    return;
    ;
}


void _67opGET_KEY()
{
    object _34611 = NOVALUE;
    object _34609 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3337		target = Code[pc+1]*/
    _34609 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34609);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3338		val[target] = get_key()*/
    _34611 = get_key(0);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34611;
    if( _1 != _34611 ){
        DeRef(_1);
    }
    _34611 = NOVALUE;

    /** execute.e:3339		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:3340	end procedure*/
    _34609 = NOVALUE;
    return;
    ;
}


void _67opCLEAR_SCREEN()
{
    object _0, _1, _2;
    

    /** execute.e:3343		clear_screen()*/
    ClearScreen();

    /** execute.e:3344		pc += 1*/
    _67pc_64802 = _67pc_64802 + 1;

    /** execute.e:3345	end procedure*/
    return;
    ;
}


void _67opPUTS()
{
    object _34619 = NOVALUE;
    object _34618 = NOVALUE;
    object _34616 = NOVALUE;
    object _34614 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3348		a = Code[pc+1]*/
    _34614 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34614);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3349		b = Code[pc+2]*/
    _34616 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34616);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3350		puts(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34618 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34619 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    EPuts(_34618, _34619); // DJP 
    _34618 = NOVALUE;
    _34619 = NOVALUE;

    /** execute.e:3351		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3352	end procedure*/
    _34616 = NOVALUE;
    _34614 = NOVALUE;
    return;
    ;
}


void _67opQPRINT()
{
    object _34623 = NOVALUE;
    object _34621 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3356		a = Code[pc+2]*/
    _34621 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34621);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3357		? val[a]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34623 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    StdPrint(1, _34623, 1);
    _34623 = NOVALUE;

    /** execute.e:3358		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3359	end procedure*/
    _34621 = NOVALUE;
    return;
    ;
}


void _67opPRINT()
{
    object _34630 = NOVALUE;
    object _34629 = NOVALUE;
    object _34627 = NOVALUE;
    object _34625 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3362		a = Code[pc+1]*/
    _34625 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34625);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3363		b = Code[pc+2]*/
    _34627 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34627);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3364		print(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34629 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34630 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    StdPrint(_34629, _34630, 0);
    _34629 = NOVALUE;
    _34630 = NOVALUE;

    /** execute.e:3365		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3366	end procedure*/
    _34627 = NOVALUE;
    _34625 = NOVALUE;
    return;
    ;
}


void _67opPRINTF()
{
    object _34640 = NOVALUE;
    object _34639 = NOVALUE;
    object _34638 = NOVALUE;
    object _34636 = NOVALUE;
    object _34634 = NOVALUE;
    object _34632 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3370		a = Code[pc+1]*/
    _34632 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34632);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3371		b = Code[pc+2]*/
    _34634 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34634);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3372		c = Code[pc+3]*/
    _34636 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64805 = (object)*(((s1_ptr)_2)->base + _34636);
    if (!IS_ATOM_INT(_67c_64805)){
        _67c_64805 = (object)DBL_PTR(_67c_64805)->dbl;
    }

    /** execute.e:3373		printf(val[a], val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34638 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34639 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34640 = (object)*(((s1_ptr)_2)->base + _67c_64805);
    EPrintf(_34638, _34639, _34640);
    _34638 = NOVALUE;
    _34639 = NOVALUE;
    _34640 = NOVALUE;

    /** execute.e:3374		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:3375	end procedure*/
    _34636 = NOVALUE;
    _34634 = NOVALUE;
    _34632 = NOVALUE;
    return;
    ;
}


void _67opSPRINTF()
{
    object _34650 = NOVALUE;
    object _34649 = NOVALUE;
    object _34648 = NOVALUE;
    object _34646 = NOVALUE;
    object _34644 = NOVALUE;
    object _34642 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3378		a = Code[pc+1]*/
    _34642 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34642);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3379		b = Code[pc+2]*/
    _34644 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34644);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3380		target = Code[pc+3]*/
    _34646 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34646);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3381		val[target] = sprintf(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34648 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34649 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _34650 = EPrintf(-9999999, _34648, _34649);
    _34648 = NOVALUE;
    _34649 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34650;
    if( _1 != _34650 ){
        DeRef(_1);
    }
    _34650 = NOVALUE;

    /** execute.e:3382		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:3383	end procedure*/
    _34644 = NOVALUE;
    _34642 = NOVALUE;
    _34646 = NOVALUE;
    return;
    ;
}


void _67opCOMMAND_LINE()
{
    object _cmd_69546 = NOVALUE;
    object _34660 = NOVALUE;
    object _34659 = NOVALUE;
    object _34658 = NOVALUE;
    object _34657 = NOVALUE;
    object _34655 = NOVALUE;
    object _34652 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3388		target = Code[pc+1]*/
    _34652 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34652);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3389		cmd = command_line()*/
    DeRef(_cmd_69546);
    _cmd_69546 = Command_Line();

    /** execute.e:3391		if length(cmd) > 2 then*/
    if (IS_SEQUENCE(_cmd_69546)){
            _34655 = SEQ_PTR(_cmd_69546)->length;
    }
    else {
        _34655 = 1;
    }
    if (_34655 <= 2)
    goto L1; // [26] 53

    /** execute.e:3392			cmd = {cmd[1]} & cmd[3..$]*/
    _2 = (object)SEQ_PTR(_cmd_69546);
    _34657 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_34657);
    ((intptr_t*)_2)[1] = _34657;
    _34658 = MAKE_SEQ(_1);
    _34657 = NOVALUE;
    if (IS_SEQUENCE(_cmd_69546)){
            _34659 = SEQ_PTR(_cmd_69546)->length;
    }
    else {
        _34659 = 1;
    }
    rhs_slice_target = (object_ptr)&_34660;
    RHS_Slice(_cmd_69546, 3, _34659);
    Concat((object_ptr)&_cmd_69546, _34658, _34660);
    DeRefDS(_34658);
    _34658 = NOVALUE;
    DeRef(_34658);
    _34658 = NOVALUE;
    DeRefDS(_34660);
    _34660 = NOVALUE;
L1: 

    /** execute.e:3394		val[target] = cmd*/
    RefDS(_cmd_69546);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _cmd_69546;
    DeRef(_1);

    /** execute.e:3395		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:3396	end procedure*/
    DeRefDS(_cmd_69546);
    DeRef(_34652);
    _34652 = NOVALUE;
    return;
    ;
}


void _67opOPTION_SWITCHES()
{
    object _cmd_69562 = NOVALUE;
    object _34663 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3401		target = Code[pc+1]*/
    _34663 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34663);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3402		cmd = option_switches()*/
    DeRef(_cmd_69562);
    RefDS(_0switches);
    _cmd_69562 = _0switches;

    /** execute.e:3403		val[target] = cmd*/
    RefDS(_cmd_69562);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _cmd_69562;
    DeRef(_1);

    /** execute.e:3404		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:3405	end procedure*/
    DeRefDS(_cmd_69562);
    _34663 = NOVALUE;
    return;
    ;
}


void _67opGETENV()
{
    object _34675 = NOVALUE;
    object _34674 = NOVALUE;
    object _34672 = NOVALUE;
    object _34671 = NOVALUE;
    object _34669 = NOVALUE;
    object _34667 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3408		a = Code[pc+1]*/
    _34667 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34667);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3409		target = Code[pc+2]*/
    _34669 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34669);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3410		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34671 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _34672 = IS_ATOM(_34671);
    _34671 = NOVALUE;
    if (_34672 == 0)
    {
        _34672 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _34672 = NOVALUE;
    }

    /** execute.e:3411			RTFatal("argument to getenv must be a sequence")*/
    RefDS(_34673);
    _67RTFatal(_34673);
L1: 

    /** execute.e:3413		val[target] = getenv(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34674 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _34675 = EGetEnv(_34674);
    _34674 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34675;
    if( _1 != _34675 ){
        DeRef(_1);
    }
    _34675 = NOVALUE;

    /** execute.e:3414		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3415	end procedure*/
    DeRef(_34667);
    _34667 = NOVALUE;
    DeRef(_34669);
    _34669 = NOVALUE;
    return;
    ;
}


void _67opC_PROC()
{
    object _sub_69586 = NOVALUE;
    object _34684 = NOVALUE;
    object _34683 = NOVALUE;
    object _34681 = NOVALUE;
    object _34679 = NOVALUE;
    object _34677 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3420		a = Code[pc+1]*/
    _34677 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34677);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3421		b = Code[pc+2]*/
    _34679 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34679);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3422		sub = Code[pc+3]*/
    _34681 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _sub_69586 = (object)*(((s1_ptr)_2)->base + _34681);
    if (!IS_ATOM_INT(_sub_69586)){
        _sub_69586 = (object)DBL_PTR(_sub_69586)->dbl;
    }

    /** execute.e:3423		c_proc(val[a], val[b])  -- callback could happen here*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34683 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34684 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    call_c(0, _34683, _34684);
    _34683 = NOVALUE;
    _34684 = NOVALUE;

    /** execute.e:3424		restore_privates(sub)*/
    _67restore_privates(_sub_69586);

    /** execute.e:3425		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:3426	end procedure*/
    _34681 = NOVALUE;
    _34677 = NOVALUE;
    _34679 = NOVALUE;
    return;
    ;
}


void _67opC_FUNC()
{
    object _target_69601 = NOVALUE;
    object _sub_69603 = NOVALUE;
    object _temp_69604 = NOVALUE;
    object _34695 = NOVALUE;
    object _34694 = NOVALUE;
    object _34692 = NOVALUE;
    object _34690 = NOVALUE;
    object _34688 = NOVALUE;
    object _34686 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3431		object temp*/

    /** execute.e:3433		a = Code[pc+1]*/
    _34686 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34686);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3434		b = Code[pc+2]*/
    _34688 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34688);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3435		sub = Code[pc+3]*/
    _34690 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _sub_69603 = (object)*(((s1_ptr)_2)->base + _34690);
    if (!IS_ATOM_INT(_sub_69603)){
        _sub_69603 = (object)DBL_PTR(_sub_69603)->dbl;
    }

    /** execute.e:3436		target = Code[pc+4]*/
    _34692 = _67pc_64802 + 4;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _target_69601 = (object)*(((s1_ptr)_2)->base + _34692);
    if (!IS_ATOM_INT(_target_69601)){
        _target_69601 = (object)DBL_PTR(_target_69601)->dbl;
    }

    /** execute.e:3437		temp = c_func(val[a], val[b])  -- callback could happen here*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34694 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34695 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    DeRef(_temp_69604);
    _temp_69604 = call_c(1, _34694, _34695);
    _34694 = NOVALUE;
    _34695 = NOVALUE;

    /** execute.e:3438		restore_privates(sub)*/
    _67restore_privates(_sub_69603);

    /** execute.e:3439		val[target] = temp*/
    Ref(_temp_69604);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _target_69601);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _temp_69604;
    DeRef(_1);

    /** execute.e:3440		pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:3441	end procedure*/
    DeRef(_temp_69604);
    _34690 = NOVALUE;
    _34686 = NOVALUE;
    _34692 = NOVALUE;
    _34688 = NOVALUE;
    return;
    ;
}


void _67opTRACE()
{
    object _34699 = NOVALUE;
    object _34698 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3444		TraceOn = val[Code[pc+1]]*/
    _34698 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34699 = (object)*(((s1_ptr)_2)->base + _34698);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_34699)){
        _67TraceOn_64800 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34699)->dbl));
    }
    else{
        _67TraceOn_64800 = (object)*(((s1_ptr)_2)->base + _34699);
    }
    if (!IS_ATOM_INT(_67TraceOn_64800))
    _67TraceOn_64800 = (object)DBL_PTR(_67TraceOn_64800)->dbl;

    /** execute.e:3445		pc += 2  -- turn on/off tracing*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:3446	end procedure*/
    _34698 = NOVALUE;
    _34699 = NOVALUE;
    return;
    ;
}


void _67opPROFILE()
{
    object _0, _1, _2;
    

    /** execute.e:3452		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:3453	end procedure*/
    return;
    ;
}


void _67opUPDATE_GLOBALS()
{
    object _0, _1, _2;
    

    /** execute.e:3458		pc += 1*/
    _67pc_64802 = _67pc_64802 + 1;

    /** execute.e:3459	end procedure*/
    return;
    ;
}


object _67general_callback(object _rtn_def_69636, object _args_69637)
{
    object _arglist_assign_69639 = NOVALUE;
    object _34721 = NOVALUE;
    object _34719 = NOVALUE;
    object _34718 = NOVALUE;
    object _34717 = NOVALUE;
    object _34714 = NOVALUE;
    object _34713 = NOVALUE;
    object _34711 = NOVALUE;
    object _34710 = NOVALUE;
    object _34706 = NOVALUE;
    object _34704 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:3493		val[t_id] = rtn_def[C_USER_ROUTINE]*/
    _2 = (object)SEQ_PTR(_rtn_def_69636);
    _34704 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_34704);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_id_64733);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34704;
    if( _1 != _34704 ){
        DeRef(_1);
    }
    _34704 = NOVALUE;

    /** execute.e:3494		val[t_arglist] = args*/
    RefDS(_args_69637);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_64734);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _args_69637;
    DeRef(_1);

    /** execute.e:3495		atom arglist_assign = new_arg_assign()*/
    _0 = _arglist_assign_69639;
    _arglist_assign_69639 = _67new_arg_assign();
    DeRef(_0);

    /** execute.e:3497		SymTab[call_back_routine][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67call_back_routine_64736 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_64819;
    DeRef(_1);
    _34706 = NOVALUE;

    /** execute.e:3500		call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_64820, _67call_stack_64820, _67pc_64802);

    /** execute.e:3501		call_stack = append(call_stack, call_back_routine)*/
    Append(&_67call_stack_64820, _67call_stack_64820, _67call_back_routine_64736);

    /** execute.e:3503		Code = call_back_code*/
    RefDS(_67call_back_code_64730);
    DeRef(_12Code_20315);
    _12Code_20315 = _67call_back_code_64730;

    /** execute.e:3504		pc = 1*/
    _67pc_64802 = 1;

    /** execute.e:3506		do_exec()*/
    _67do_exec();

    /** execute.e:3509		pc = call_stack[$-1]*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _34710 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _34710 = 1;
    }
    _34711 = _34710 - 1;
    _34710 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_64820);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _34711);
    if (!IS_ATOM_INT(_67pc_64802))
    _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;

    /** execute.e:3510		call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _34713 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _34713 = 1;
    }
    _34714 = _34713 - 2;
    _34713 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_64820;
    RHS_Slice(_67call_stack_64820, 1, _34714);

    /** execute.e:3512		if arglist_assign = arg_assign then*/
    if (binary_op_a(NOTEQ, _arglist_assign_69639, _67arg_assign_64746)){
        goto L1; // [126] 143
    }

    /** execute.e:3513			val[t_arglist] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_64734);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
L1: 

    /** execute.e:3516		Code = SymTab[call_stack[$]][S_CODE]*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _34717 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _34717 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_64820);
    _34718 = (object)*(((s1_ptr)_2)->base + _34717);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_34718)){
        _34719 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34718)->dbl));
    }
    else{
        _34719 = (object)*(((s1_ptr)_2)->base + _34718);
    }
    DeRef(_12Code_20315);
    _2 = (object)SEQ_PTR(_34719);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    Ref(_12Code_20315);
    _34719 = NOVALUE;

    /** execute.e:3518		return val[t_return_val]*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34721 = (object)*(((s1_ptr)_2)->base + _67t_return_val_64735);
    Ref(_34721);
    DeRefDS(_rtn_def_69636);
    DeRefDS(_args_69637);
    DeRef(_arglist_assign_69639);
    _34718 = NOVALUE;
    DeRef(_34714);
    _34714 = NOVALUE;
    DeRef(_34711);
    _34711 = NOVALUE;
    return _34721;
    ;
}


object _67machine_callback(object _cbx_69670, object _ptr_69671)
{
    object _rtn_def_69672 = NOVALUE;
    object _args_69673 = NOVALUE;
    object _34729 = NOVALUE;
    object _34727 = NOVALUE;
    object _34726 = NOVALUE;
    object _34725 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3528		rtn_def = call_backs[cbx]*/
    DeRef(_rtn_def_69672);
    _2 = (object)SEQ_PTR(_67call_backs_64729);
    if (!IS_ATOM_INT(_cbx_69670)){
        _rtn_def_69672 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_cbx_69670)->dbl));
    }
    else{
        _rtn_def_69672 = (object)*(((s1_ptr)_2)->base + _cbx_69670);
    }
    RefDS(_rtn_def_69672);

    /** execute.e:3529		args = peek4u(ptr & call_backs[cbx][C_NUM_ARGS])*/
    _2 = (object)SEQ_PTR(_67call_backs_64729);
    if (!IS_ATOM_INT(_cbx_69670)){
        _34725 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_cbx_69670)->dbl));
    }
    else{
        _34725 = (object)*(((s1_ptr)_2)->base + _cbx_69670);
    }
    _2 = (object)SEQ_PTR(_34725);
    _34726 = (object)*(((s1_ptr)_2)->base + 3);
    _34725 = NOVALUE;
    if (IS_SEQUENCE(_ptr_69671) && IS_ATOM(_34726)) {
    }
    else if (IS_ATOM(_ptr_69671) && IS_SEQUENCE(_34726)) {
        Ref(_ptr_69671);
        Prepend(&_34727, _34726, _ptr_69671);
    }
    else {
        Concat((object_ptr)&_34727, _ptr_69671, _34726);
    }
    _34726 = NOVALUE;
    DeRef(_args_69673);
    _1 = (object)SEQ_PTR(_34727);
    peek4_addr = (uint32_t *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _args_69673 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        _1 = (object)*peek4_addr++;
        if ((uintptr_t)_1 > (uintptr_t)MAXINT){
            _1 = NewDouble((eudouble)(uintptr_t)_1);
        }
        *pokeptr_addr = _1;
    }
    DeRefDS(_34727);
    _34727 = NOVALUE;

    /** execute.e:3531		return general_callback(rtn_def, args)*/
    RefDS(_rtn_def_69672);
    RefDS(_args_69673);
    _34729 = _67general_callback(_rtn_def_69672, _args_69673);
    DeRef(_cbx_69670);
    DeRef(_ptr_69671);
    DeRefDS(_rtn_def_69672);
    DeRefDS(_args_69673);
    return _34729;
    ;
}


object _67callback(object _a_69688)
{
    object _34733 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3626		return machine_func(M_CALL_BACK, a)*/
    _34733 = machine(52, _a_69688);
    DeRefi(_a_69688);
    return _34733;
    ;
}


void _67do_callback(object _b_69692)
{
    object _r_69694 = NOVALUE;
    object _asm_69695 = NOVALUE;
    object _id_69696 = NOVALUE;
    object _convention_69697 = NOVALUE;
    object _x_69698 = NOVALUE;
    object _34794 = NOVALUE;
    object _34793 = NOVALUE;
    object _34792 = NOVALUE;
    object _34791 = NOVALUE;
    object _34790 = NOVALUE;
    object _34789 = NOVALUE;
    object _34788 = NOVALUE;
    object _34787 = NOVALUE;
    object _34786 = NOVALUE;
    object _34785 = NOVALUE;
    object _34784 = NOVALUE;
    object _34783 = NOVALUE;
    object _34781 = NOVALUE;
    object _34762 = NOVALUE;
    object _34761 = NOVALUE;
    object _34759 = NOVALUE;
    object _34758 = NOVALUE;
    object _34757 = NOVALUE;
    object _34756 = NOVALUE;
    object _34755 = NOVALUE;
    object _34754 = NOVALUE;
    object _34753 = NOVALUE;
    object _34752 = NOVALUE;
    object _34751 = NOVALUE;
    object _34750 = NOVALUE;
    object _34748 = NOVALUE;
    object _34747 = NOVALUE;
    object _34746 = NOVALUE;
    object _34745 = NOVALUE;
    object _34743 = NOVALUE;
    object _34741 = NOVALUE;
    object _34740 = NOVALUE;
    object _34738 = NOVALUE;
    object _34735 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3631		atom asm*/

    /** execute.e:3632		integer id, convention*/

    /** execute.e:3633		object x*/

    /** execute.e:3636		x = val[b]*/
    DeRef(_x_69698);
    _2 = (object)SEQ_PTR(_67val_64812);
    _x_69698 = (object)*(((s1_ptr)_2)->base + _b_69692);
    Ref(_x_69698);

    /** execute.e:3637		if atom(x) then*/
    _34735 = IS_ATOM(_x_69698);
    if (_34735 == 0)
    {
        _34735 = NOVALUE;
        goto L1; // [22] 40
    }
    else{
        _34735 = NOVALUE;
    }

    /** execute.e:3638			id = x*/
    Ref(_x_69698);
    _id_69696 = _x_69698;
    if (!IS_ATOM_INT(_id_69696)) {
        _1 = (object)(DBL_PTR(_id_69696)->dbl);
        DeRefDS(_id_69696);
        _id_69696 = _1;
    }

    /** execute.e:3639			convention = 0*/
    _convention_69697 = 0;
    goto L2; // [37] 57
L1: 

    /** execute.e:3641			id = x[2]*/
    _2 = (object)SEQ_PTR(_x_69698);
    _id_69696 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_id_69696)){
        _id_69696 = (object)DBL_PTR(_id_69696)->dbl;
    }

    /** execute.e:3642			convention = x[1]*/
    _2 = (object)SEQ_PTR(_x_69698);
    _convention_69697 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_convention_69697)){
        _convention_69697 = (object)DBL_PTR(_convention_69697)->dbl;
    }
L2: 

    /** execute.e:3645		if id < 0 or id >= length(e_routine) then*/
    _34738 = (_id_69696 < 0);
    if (_34738 != 0) {
        goto L3; // [65] 83
    }
    if (IS_SEQUENCE(_67e_routine_64850)){
            _34740 = SEQ_PTR(_67e_routine_64850)->length;
    }
    else {
        _34740 = 1;
    }
    _34741 = (_id_69696 >= _34740);
    _34740 = NOVALUE;
    if (_34741 == 0)
    {
        DeRef(_34741);
        _34741 = NOVALUE;
        goto L4; // [79] 89
    }
    else{
        DeRef(_34741);
        _34741 = NOVALUE;
    }
L3: 

    /** execute.e:3646			RTFatal("Invalid routine id")*/
    RefDS(_34742);
    _67RTFatal(_34742);
L4: 

    /** execute.e:3649		r = e_routine[id+1]*/
    _34743 = _id_69696 + 1;
    _2 = (object)SEQ_PTR(_67e_routine_64850);
    _r_69694 = (object)*(((s1_ptr)_2)->base + _34743);

    /** execute.e:3651		if platform() = WIN32 and convention = 0 then*/
    _34745 = (3 == 2);
    if (_34745 == 0) {
        goto L5; // [111] 224
    }
    _34747 = (_convention_69697 == 0);
    if (_34747 == 0)
    {
        DeRef(_34747);
        _34747 = NOVALUE;
        goto L5; // [122] 224
    }
    else{
        DeRef(_34747);
        _34747 = NOVALUE;
    }

    /** execute.e:3653			asm = dep:allocate_protect(length(cb_std), 1, PAGE_EXECUTE_READWRITE)*/
    _34748 = 24;
    Ref(_5PAGE_EXECUTE_READWRITE_250);
    _0 = _asm_69695;
    _asm_69695 = _4allocate_protect(24, 1, _5PAGE_EXECUTE_READWRITE_250);
    DeRef(_0);
    _34748 = NOVALUE;

    /** execute.e:3654			poke( asm, cb_std )*/
    if (IS_ATOM_INT(_asm_69695)){
        poke_addr = (uint8_t *)_asm_69695;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_asm_69695)->dbl);
    }
    _1 = (object)SEQ_PTR(_67cb_std_69680);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke_addr++ = (uint8_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
        }
    }

    /** execute.e:3655			poke4( asm + 7, length(call_backs) + 1 )*/
    if (IS_ATOM_INT(_asm_69695)) {
        _34750 = _asm_69695 + 7;
        if ((object)((uintptr_t)_34750 + (uintptr_t)HIGH_BITS) >= 0){
            _34750 = NewDouble((eudouble)_34750);
        }
    }
    else {
        _34750 = NewDouble(DBL_PTR(_asm_69695)->dbl + (eudouble)7);
    }
    if (IS_SEQUENCE(_67call_backs_64729)){
            _34751 = SEQ_PTR(_67call_backs_64729)->length;
    }
    else {
        _34751 = 1;
    }
    _34752 = _34751 + 1;
    _34751 = NOVALUE;
    if (IS_ATOM_INT(_34750)){
        poke4_addr = (uint32_t *)_34750;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_34750)->dbl);
    }
    *poke4_addr = (uint32_t)_34752;
    DeRef(_34750);
    _34750 = NOVALUE;
    _34752 = NOVALUE;

    /** execute.e:3656			poke4( asm + 13, asm + 20 )*/
    if (IS_ATOM_INT(_asm_69695)) {
        _34753 = _asm_69695 + 13;
        if ((object)((uintptr_t)_34753 + (uintptr_t)HIGH_BITS) >= 0){
            _34753 = NewDouble((eudouble)_34753);
        }
    }
    else {
        _34753 = NewDouble(DBL_PTR(_asm_69695)->dbl + (eudouble)13);
    }
    if (IS_ATOM_INT(_asm_69695)) {
        _34754 = _asm_69695 + 20;
        if ((object)((uintptr_t)_34754 + (uintptr_t)HIGH_BITS) >= 0){
            _34754 = NewDouble((eudouble)_34754);
        }
    }
    else {
        _34754 = NewDouble(DBL_PTR(_asm_69695)->dbl + (eudouble)20);
    }
    if (IS_ATOM_INT(_34753)){
        poke4_addr = (uint32_t *)_34753;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_34753)->dbl);
    }
    if (IS_ATOM_INT(_34754)) {
        *poke4_addr = (uint32_t)_34754;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_34754)->dbl;
    }
    DeRef(_34753);
    _34753 = NOVALUE;
    DeRef(_34754);
    _34754 = NOVALUE;

    /** execute.e:3657			poke( asm + 18, SymTab[r][S_NUM_ARGS] * 4 )*/
    if (IS_ATOM_INT(_asm_69695)) {
        _34755 = _asm_69695 + 18;
        if ((object)((uintptr_t)_34755 + (uintptr_t)HIGH_BITS) >= 0){
            _34755 = NewDouble((eudouble)_34755);
        }
    }
    else {
        _34755 = NewDouble(DBL_PTR(_asm_69695)->dbl + (eudouble)18);
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34756 = (object)*(((s1_ptr)_2)->base + _r_69694);
    _2 = (object)SEQ_PTR(_34756);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _34757 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _34757 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _34756 = NOVALUE;
    if (IS_ATOM_INT(_34757)) {
        if (_34757 == (short)_34757){
            _34758 = _34757 * 4;
        }
        else{
            _34758 = NewDouble(_34757 * (eudouble)4);
        }
    }
    else {
        _34758 = binary_op(MULTIPLY, _34757, 4);
    }
    _34757 = NOVALUE;
    if (IS_ATOM_INT(_34755)){
        poke_addr = (uint8_t *)_34755;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_34755)->dbl);
    }
    if (IS_ATOM_INT(_34758)) {
        *poke_addr = (uint8_t)_34758;
    }
    else if (IS_ATOM(_34758)) {
        *poke_addr = (uint8_t)DBL_PTR(_34758)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34758);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke_addr++ = (uint8_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_34755);
    _34755 = NOVALUE;
    DeRef(_34758);
    _34758 = NOVALUE;

    /** execute.e:3658			poke4( asm + 20, callback( routine_id("machine_callback") ) )*/
    if (IS_ATOM_INT(_asm_69695)) {
        _34759 = _asm_69695 + 20;
        if ((object)((uintptr_t)_34759 + (uintptr_t)HIGH_BITS) >= 0){
            _34759 = NewDouble((eudouble)_34759);
        }
    }
    else {
        _34759 = NewDouble(DBL_PTR(_asm_69695)->dbl + (eudouble)20);
    }
    _34761 = CRoutineId(1597, 67, _34760);
    _34762 = _67callback(_34761);
    _34761 = NOVALUE;
    if (IS_ATOM_INT(_34759)){
        poke4_addr = (uint32_t *)_34759;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_34759)->dbl);
    }
    if (IS_ATOM_INT(_34762)) {
        *poke4_addr = (uint32_t)_34762;
    }
    else if (IS_ATOM(_34762)) {
        *poke4_addr = (uint32_t)DBL_PTR(_34762)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34762);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke4_addr++ = (int32_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_34759);
    _34759 = NOVALUE;
    DeRef(_34762);
    _34762 = NOVALUE;
    goto L6; // [221] 409
L5: 

    /** execute.e:3659		elsif platform() = OSX then*/

    /** execute.e:3675			asm = dep:allocate_protect(length(cb_cdecl), 1, PAGE_EXECUTE_READWRITE)*/
    _34781 = 27;
    Ref(_5PAGE_EXECUTE_READWRITE_250);
    _0 = _asm_69695;
    _asm_69695 = _4allocate_protect(27, 1, _5PAGE_EXECUTE_READWRITE_250);
    DeRef(_0);
    _34781 = NOVALUE;

    /** execute.e:3676			poke( asm, cb_cdecl )*/
    if (IS_ATOM_INT(_asm_69695)){
        poke_addr = (uint8_t *)_asm_69695;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_asm_69695)->dbl);
    }
    _1 = (object)SEQ_PTR(_67cb_cdecl_69682);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke_addr++ = (uint8_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
        }
    }

    /** execute.e:3677			poke4( asm + 7, length(call_backs) + 1 )*/
    if (IS_ATOM_INT(_asm_69695)) {
        _34783 = _asm_69695 + 7;
        if ((object)((uintptr_t)_34783 + (uintptr_t)HIGH_BITS) >= 0){
            _34783 = NewDouble((eudouble)_34783);
        }
    }
    else {
        _34783 = NewDouble(DBL_PTR(_asm_69695)->dbl + (eudouble)7);
    }
    if (IS_SEQUENCE(_67call_backs_64729)){
            _34784 = SEQ_PTR(_67call_backs_64729)->length;
    }
    else {
        _34784 = 1;
    }
    _34785 = _34784 + 1;
    _34784 = NOVALUE;
    if (IS_ATOM_INT(_34783)){
        poke4_addr = (uint32_t *)_34783;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_34783)->dbl);
    }
    *poke4_addr = (uint32_t)_34785;
    DeRef(_34783);
    _34783 = NOVALUE;
    _34785 = NOVALUE;

    /** execute.e:3678			poke4( asm + 13, asm + 23 )*/
    if (IS_ATOM_INT(_asm_69695)) {
        _34786 = _asm_69695 + 13;
        if ((object)((uintptr_t)_34786 + (uintptr_t)HIGH_BITS) >= 0){
            _34786 = NewDouble((eudouble)_34786);
        }
    }
    else {
        _34786 = NewDouble(DBL_PTR(_asm_69695)->dbl + (eudouble)13);
    }
    if (IS_ATOM_INT(_asm_69695)) {
        _34787 = _asm_69695 + 23;
        if ((object)((uintptr_t)_34787 + (uintptr_t)HIGH_BITS) >= 0){
            _34787 = NewDouble((eudouble)_34787);
        }
    }
    else {
        _34787 = NewDouble(DBL_PTR(_asm_69695)->dbl + (eudouble)23);
    }
    if (IS_ATOM_INT(_34786)){
        poke4_addr = (uint32_t *)_34786;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_34786)->dbl);
    }
    if (IS_ATOM_INT(_34787)) {
        *poke4_addr = (uint32_t)_34787;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_34787)->dbl;
    }
    DeRef(_34786);
    _34786 = NOVALUE;
    DeRef(_34787);
    _34787 = NOVALUE;

    /** execute.e:3679			poke4( asm + 23, callback( ( '+' & routine_id("machine_callback") ) ) )*/
    if (IS_ATOM_INT(_asm_69695)) {
        _34788 = _asm_69695 + 23;
        if ((object)((uintptr_t)_34788 + (uintptr_t)HIGH_BITS) >= 0){
            _34788 = NewDouble((eudouble)_34788);
        }
    }
    else {
        _34788 = NewDouble(DBL_PTR(_asm_69695)->dbl + (eudouble)23);
    }
    _34789 = CRoutineId(1597, 67, _34760);
    Concat((object_ptr)&_34790, 43, _34789);
    _34789 = NOVALUE;
    _34791 = _67callback(_34790);
    _34790 = NOVALUE;
    if (IS_ATOM_INT(_34788)){
        poke4_addr = (uint32_t *)_34788;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_34788)->dbl);
    }
    if (IS_ATOM_INT(_34791)) {
        *poke4_addr = (uint32_t)_34791;
    }
    else if (IS_ATOM(_34791)) {
        *poke4_addr = (uint32_t)DBL_PTR(_34791)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34791);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke4_addr++ = (int32_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_34788);
    _34788 = NOVALUE;
    DeRef(_34791);
    _34791 = NOVALUE;
L6: 

    /** execute.e:3682		val[target] = asm*/
    Ref(_asm_69695);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _asm_69695;
    DeRef(_1);

    /** execute.e:3683		call_backs = append( call_backs, { r, id, SymTab[r][S_NUM_ARGS] })*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34792 = (object)*(((s1_ptr)_2)->base + _r_69694);
    _2 = (object)SEQ_PTR(_34792);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _34793 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _34793 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _34792 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _r_69694;
    ((intptr_t*)_2)[2] = _id_69696;
    Ref(_34793);
    ((intptr_t*)_2)[3] = _34793;
    _34794 = MAKE_SEQ(_1);
    _34793 = NOVALUE;
    RefDS(_34794);
    Append(&_67call_backs_64729, _67call_backs_64729, _34794);
    DeRefDS(_34794);
    _34794 = NOVALUE;

    /** execute.e:3684	end procedure*/
    DeRef(_asm_69695);
    DeRef(_x_69698);
    DeRef(_34743);
    _34743 = NOVALUE;
    DeRef(_34738);
    _34738 = NOVALUE;
    DeRef(_34745);
    _34745 = NOVALUE;
    return;
    ;
}


void _67do_crash_routine(object _b_69780)
{
    object _x_69781 = NOVALUE;
    object _34802 = NOVALUE;
    object _34801 = NOVALUE;
    object _34800 = NOVALUE;
    object _34799 = NOVALUE;
    object _34798 = NOVALUE;
    object _34797 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3690		x = val[b]*/
    DeRef(_x_69781);
    _2 = (object)SEQ_PTR(_67val_64812);
    _x_69781 = (object)*(((s1_ptr)_2)->base + _b_69780);
    Ref(_x_69781);

    /** execute.e:3691		if atom(x) and x >= 0 and x < length(e_routine) then*/
    _34797 = IS_ATOM(_x_69781);
    if (_34797 == 0) {
        _34798 = 0;
        goto L1; // [16] 28
    }
    if (IS_ATOM_INT(_x_69781)) {
        _34799 = (_x_69781 >= 0);
    }
    else {
        _34799 = binary_op(GREATEREQ, _x_69781, 0);
    }
    if (IS_ATOM_INT(_34799))
    _34798 = (_34799 != 0);
    else
    _34798 = DBL_PTR(_34799)->dbl != 0.0;
L1: 
    if (_34798 == 0) {
        goto L2; // [28] 56
    }
    if (IS_SEQUENCE(_67e_routine_64850)){
            _34801 = SEQ_PTR(_67e_routine_64850)->length;
    }
    else {
        _34801 = 1;
    }
    if (IS_ATOM_INT(_x_69781)) {
        _34802 = (_x_69781 < _34801);
    }
    else {
        _34802 = binary_op(LESS, _x_69781, _34801);
    }
    _34801 = NOVALUE;
    if (_34802 == 0) {
        DeRef(_34802);
        _34802 = NOVALUE;
        goto L2; // [42] 56
    }
    else {
        if (!IS_ATOM_INT(_34802) && DBL_PTR(_34802)->dbl == 0.0){
            DeRef(_34802);
            _34802 = NOVALUE;
            goto L2; // [42] 56
        }
        DeRef(_34802);
        _34802 = NOVALUE;
    }
    DeRef(_34802);
    _34802 = NOVALUE;

    /** execute.e:3692			crash_list = append(crash_list, x)*/
    Ref(_x_69781);
    Append(&_67crash_list_64738, _67crash_list_64738, _x_69781);
    goto L3; // [53] 62
L2: 

    /** execute.e:3694			RTFatal("crash routine requires a valid routine id")*/
    RefDS(_34804);
    _67RTFatal(_34804);
L3: 

    /** execute.e:3696	end procedure*/
    DeRef(_x_69781);
    DeRef(_34799);
    _34799 = NOVALUE;
    return;
    ;
}


void _67opREMOVE()
{
    object _34816 = NOVALUE;
    object _34815 = NOVALUE;
    object _34814 = NOVALUE;
    object _34813 = NOVALUE;
    object _34811 = NOVALUE;
    object _34809 = NOVALUE;
    object _34807 = NOVALUE;
    object _34805 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3699	 	a = Code[pc+1]*/
    _34805 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34805);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3700	 	b = Code[pc+2]*/
    _34807 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34807);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3701	 	c = Code[pc+3]*/
    _34809 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64805 = (object)*(((s1_ptr)_2)->base + _34809);
    if (!IS_ATOM_INT(_67c_64805)){
        _67c_64805 = (object)DBL_PTR(_67c_64805)->dbl;
    }

    /** execute.e:3702	 	target = Code[pc+4]*/
    _34811 = _67pc_64802 + 4;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34811);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3703	 	val[target] = remove(val[a],val[b],val[c])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34813 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34814 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34815 = (object)*(((s1_ptr)_2)->base + _67c_64805);
    {
        s1_ptr assign_space = SEQ_PTR(_34813);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_34814)) ? _34814 : (object)(DBL_PTR(_34814)->dbl);
        int stop = (IS_ATOM_INT(_34815)) ? _34815 : (object)(DBL_PTR(_34815)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
            RefDS(_34813);
            DeRef(_34816);
            _34816 = _34813;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_34813), start, &_34816 );
            }
            else Tail(SEQ_PTR(_34813), stop+1, &_34816);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_34813), start, &_34816);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_34816);
            _34816 = _1;
        }
    }
    _34813 = NOVALUE;
    _34814 = NOVALUE;
    _34815 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34816;
    if( _1 != _34816 ){
        DeRef(_1);
    }
    _34816 = NOVALUE;

    /** execute.e:3704	 	pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:3705	end procedure*/
    _34805 = NOVALUE;
    _34809 = NOVALUE;
    _34811 = NOVALUE;
    _34807 = NOVALUE;
    return;
    ;
}


void _67opREPLACE()
{
    object _34832 = NOVALUE;
    object _34831 = NOVALUE;
    object _34830 = NOVALUE;
    object _34829 = NOVALUE;
    object _34828 = NOVALUE;
    object _34826 = NOVALUE;
    object _34824 = NOVALUE;
    object _34822 = NOVALUE;
    object _34820 = NOVALUE;
    object _34818 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3708	 	a = Code[pc+1]*/
    _34818 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34818);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3709	 	b = Code[pc+2]*/
    _34820 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34820);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3710	 	c = Code[pc+3]*/
    _34822 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64805 = (object)*(((s1_ptr)_2)->base + _34822);
    if (!IS_ATOM_INT(_67c_64805)){
        _67c_64805 = (object)DBL_PTR(_67c_64805)->dbl;
    }

    /** execute.e:3711	 	d = Code[pc+4]*/
    _34824 = _67pc_64802 + 4;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67d_64806 = (object)*(((s1_ptr)_2)->base + _34824);
    if (!IS_ATOM_INT(_67d_64806)){
        _67d_64806 = (object)DBL_PTR(_67d_64806)->dbl;
    }

    /** execute.e:3712	 	target = Code[pc+5]*/
    _34826 = _67pc_64802 + 5;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34826);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3713	 	val[target] = replace(val[a],val[b],val[c],val[d])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34828 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34829 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34830 = (object)*(((s1_ptr)_2)->base + _67c_64805);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34831 = (object)*(((s1_ptr)_2)->base + _67d_64806);
    {
        intptr_t p1 = _34828;
        intptr_t p2 = _34829;
        intptr_t p3 = _34830;
        intptr_t p4 = _34831;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_34832;
        Replace( &replace_params );
    }
    _34828 = NOVALUE;
    _34829 = NOVALUE;
    _34830 = NOVALUE;
    _34831 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34832;
    if( _1 != _34832 ){
        DeRef(_1);
    }
    _34832 = NOVALUE;

    /** execute.e:3714	 	pc += 6*/
    _67pc_64802 = _67pc_64802 + 6;

    /** execute.e:3715	end procedure*/
    _34824 = NOVALUE;
    _34822 = NOVALUE;
    _34826 = NOVALUE;
    _34818 = NOVALUE;
    _34820 = NOVALUE;
    return;
    ;
}


void _67opHEAD()
{
    object _34842 = NOVALUE;
    object _34841 = NOVALUE;
    object _34840 = NOVALUE;
    object _34838 = NOVALUE;
    object _34836 = NOVALUE;
    object _34834 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3718		a = Code[pc+1]*/
    _34834 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34834);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3719		b = Code[pc+2]*/
    _34836 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34836);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3720		target = Code[pc+3]*/
    _34838 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34838);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3721		val[target] = head(val[a],val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34840 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34841 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    {
        int len = SEQ_PTR(_34840)->length;
        int size = (IS_ATOM_INT(_34841)) ? _34841 : (object)(DBL_PTR(_34841)->dbl);
        if (size <= 0){
            DeRef( _34842 );
            _34842 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_34840);
            DeRef(_34842);
            _34842 = _34840;
        }
        else{
            Head(SEQ_PTR(_34840),size+1,&_34842);
        }
    }
    _34840 = NOVALUE;
    _34841 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34842;
    if( _1 != _34842 ){
        DeRef(_1);
    }
    _34842 = NOVALUE;

    /** execute.e:3722		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:3723	end procedure*/
    _34836 = NOVALUE;
    _34834 = NOVALUE;
    _34838 = NOVALUE;
    return;
    ;
}


void _67opTAIL()
{
    object _34852 = NOVALUE;
    object _34851 = NOVALUE;
    object _34850 = NOVALUE;
    object _34848 = NOVALUE;
    object _34846 = NOVALUE;
    object _34844 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3726		a = Code[pc+1]*/
    _34844 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34844);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3727		b = Code[pc+2]*/
    _34846 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34846);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3728		target = Code[pc+3]*/
    _34848 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34848);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3729		val[target] = tail(val[a],val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34850 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34851 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    {
        int len = SEQ_PTR(_34850)->length;
        int size = (IS_ATOM_INT(_34851)) ? _34851 : (object)(DBL_PTR(_34851)->dbl);
        if (size <= 0) {
            DeRef(_34852);
            _34852 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_34850);
            DeRef(_34852);
            _34852 = _34850;
        }
        else Tail(SEQ_PTR(_34850), len-size+1, &_34852);
    }
    _34850 = NOVALUE;
    _34851 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34852;
    if( _1 != _34852 ){
        DeRef(_1);
    }
    _34852 = NOVALUE;

    /** execute.e:3730		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:3731	end procedure*/
    _34848 = NOVALUE;
    _34846 = NOVALUE;
    _34844 = NOVALUE;
    return;
    ;
}


void _67opMACHINE_FUNC()
{
    object _34865 = NOVALUE;
    object _34864 = NOVALUE;
    object _34863 = NOVALUE;
    object _34861 = NOVALUE;
    object _34858 = NOVALUE;
    object _34856 = NOVALUE;
    object _34854 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3734		a = Code[pc+1]*/
    _34854 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34854);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3735		b = Code[pc+2]*/
    _34856 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34856);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3736		target = Code[pc+3]*/
    _34858 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34858);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3738		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:3740		if val[a] = M_CALL_BACK then*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34861 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    if (binary_op_a(NOTEQ, _34861, 52)){
        _34861 = NOVALUE;
        goto L1; // [67] 81
    }
    _34861 = NOVALUE;

    /** execute.e:3742			do_callback(b)*/
    _67do_callback(_67b_64804);
    goto L2; // [78] 112
L1: 

    /** execute.e:3744			val[target] = machine_func(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34863 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34864 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _34865 = machine(_34863, _34864);
    _34863 = NOVALUE;
    _34864 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34865;
    if( _1 != _34865 ){
        DeRef(_1);
    }
    _34865 = NOVALUE;
L2: 

    /** execute.e:3746	end procedure*/
    DeRef(_34856);
    _34856 = NOVALUE;
    DeRef(_34858);
    _34858 = NOVALUE;
    DeRef(_34854);
    _34854 = NOVALUE;
    return;
    ;
}


void _67opSPLICE()
{
    object _34877 = NOVALUE;
    object _34876 = NOVALUE;
    object _34875 = NOVALUE;
    object _34874 = NOVALUE;
    object _34872 = NOVALUE;
    object _34870 = NOVALUE;
    object _34868 = NOVALUE;
    object _34866 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3749		a = Code[pc+1]*/
    _34866 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34866);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3750		b = Code[pc+2]*/
    _34868 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34868);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3751		c = Code[pc+3]*/
    _34870 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64805 = (object)*(((s1_ptr)_2)->base + _34870);
    if (!IS_ATOM_INT(_67c_64805)){
        _67c_64805 = (object)DBL_PTR(_67c_64805)->dbl;
    }

    /** execute.e:3752		target = Code[pc+4]*/
    _34872 = _67pc_64802 + 4;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34872);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3753		val[target] = splice(val[a],val[b],val[c])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34874 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34875 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34876 = (object)*(((s1_ptr)_2)->base + _67c_64805);
    {
        s1_ptr assign_space;
        insert_pos = IS_ATOM_INT(_34876) ? _34876 : DBL_PTR(_34876)->dbl;
        if (insert_pos <= 0) {
            if (IS_SEQUENCE(_34875)) {
                Concat(&_34877,_34875,_34874);
            }
            else{
                Prepend(&_34877,_34874,_34875);
            }
        }
        else if (insert_pos > SEQ_PTR(_34874)->length){
            if (IS_SEQUENCE(_34875)) {
                Concat(&_34877,_34874,_34875);
            }
            else{
                Append(&_34877,_34874,_34875);
            }
        }
        else if (IS_SEQUENCE(_34875)) {
            if( _34877 != _34874 || SEQ_PTR( _34874 )->ref != 1 ){
                DeRef( _34877 );
                RefDS( _34874 );
            }
            assign_space = Add_internal_space( _34874, insert_pos,((s1_ptr)SEQ_PTR(_34875))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_34875), _34874 == _34877 );
            _34877 = MAKE_SEQ( assign_space );
        }
        else {
            if( _34877 == _34874 && SEQ_PTR( _34874 )->ref == 1 ){
                _34877 = Insert( _34874, _34875, insert_pos);
            }
            else {
                DeRef( _34877 );
                RefDS( _34874 );
                _34877 = Insert( _34874, _34875, insert_pos);
            }
        }
    }
    _34874 = NOVALUE;
    _34875 = NOVALUE;
    _34876 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34877;
    if( _1 != _34877 ){
        DeRef(_1);
    }
    _34877 = NOVALUE;

    /** execute.e:3754		pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:3755	end procedure*/
    _34870 = NOVALUE;
    _34872 = NOVALUE;
    _34868 = NOVALUE;
    _34866 = NOVALUE;
    return;
    ;
}


void _67opINSERT()
{
    object _34890 = NOVALUE;
    object _34889 = NOVALUE;
    object _34888 = NOVALUE;
    object _34887 = NOVALUE;
    object _34885 = NOVALUE;
    object _34883 = NOVALUE;
    object _34881 = NOVALUE;
    object _34879 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3758		a = Code[pc+1]*/
    _34879 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34879);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3759		b = Code[pc+2]*/
    _34881 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34881);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3760		c = Code[pc+3]*/
    _34883 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64805 = (object)*(((s1_ptr)_2)->base + _34883);
    if (!IS_ATOM_INT(_67c_64805)){
        _67c_64805 = (object)DBL_PTR(_67c_64805)->dbl;
    }

    /** execute.e:3761		target = Code[pc+4]*/
    _34885 = _67pc_64802 + 4;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64807 = (object)*(((s1_ptr)_2)->base + _34885);
    if (!IS_ATOM_INT(_67target_64807)){
        _67target_64807 = (object)DBL_PTR(_67target_64807)->dbl;
    }

    /** execute.e:3762		val[target] = insert(val[a],val[b],val[c])*/
    _2 = (object)SEQ_PTR(_67val_64812);
    _34887 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34888 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34889 = (object)*(((s1_ptr)_2)->base + _67c_64805);
    {
        s1_ptr assign_space;
        insert_pos = IS_ATOM_INT(_34889) ? _34889 : DBL_PTR(_34889)->dbl;
        if (insert_pos <= 0){
            Prepend(&_34890,_34887,_34888);
        }
        else if (insert_pos > SEQ_PTR(_34887)->length) {
            Ref( _34888 );
            Append(&_34890,_34887,_34888);
        }
        else {
            Ref( _34888 );
            RefDS( _34887 );
            _34890 = Insert(_34887,_34888,insert_pos);
        }
    }
    _34887 = NOVALUE;
    _34888 = NOVALUE;
    _34889 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64807);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34890;
    if( _1 != _34890 ){
        DeRef(_1);
    }
    _34890 = NOVALUE;

    /** execute.e:3763		pc += 5*/
    _67pc_64802 = _67pc_64802 + 5;

    /** execute.e:3764	end procedure*/
    _34881 = NOVALUE;
    _34885 = NOVALUE;
    _34883 = NOVALUE;
    _34879 = NOVALUE;
    return;
    ;
}


void _67opMACHINE_PROC()
{
    object _v_69925 = NOVALUE;
    object _34909 = NOVALUE;
    object _34908 = NOVALUE;
    object _34906 = NOVALUE;
    object _34904 = NOVALUE;
    object _34903 = NOVALUE;
    object _34901 = NOVALUE;
    object _34900 = NOVALUE;
    object _34894 = NOVALUE;
    object _34892 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3770		a = Code[pc+1]*/
    _34892 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34892);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3771		b = Code[pc+2]*/
    _34894 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64804 = (object)*(((s1_ptr)_2)->base + _34894);
    if (!IS_ATOM_INT(_67b_64804)){
        _67b_64804 = (object)DBL_PTR(_67b_64804)->dbl;
    }

    /** execute.e:3772		v = val[a]*/
    DeRef(_v_69925);
    _2 = (object)SEQ_PTR(_67val_64812);
    _v_69925 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    Ref(_v_69925);

    /** execute.e:3774		switch v do*/
    if (IS_SEQUENCE(_v_69925) ){
        goto L1; // [45] 201
    }
    if(!IS_ATOM_INT(_v_69925)){
        if( (DBL_PTR(_v_69925)->dbl != (eudouble) ((object) DBL_PTR(_v_69925)->dbl) ) ){
            goto L1; // [45] 201
        }
        _0 = (object) DBL_PTR(_v_69925)->dbl;
    }
    else {
        _0 = _v_69925;
    };
    switch ( _0 ){ 

        /** execute.e:3775			case M_CRASH_ROUTINE then*/
        case 66:

        /** execute.e:3777				do_crash_routine(b)*/
        _67do_crash_routine(_67b_64804);
        goto L2; // [61] 217

        /** execute.e:3779			case M_CRASH_MESSAGE then*/
        case 37:

        /** execute.e:3780				crash_msg = val[b]*/
        DeRef(_67crash_msg_64728);
        _2 = (object)SEQ_PTR(_67val_64812);
        _67crash_msg_64728 = (object)*(((s1_ptr)_2)->base + _67b_64804);
        Ref(_67crash_msg_64728);
        goto L2; // [77] 217

        /** execute.e:3782			case M_CRASH_FILE then*/
        case 57:

        /** execute.e:3783				if sequence(val[b]) then*/
        _2 = (object)SEQ_PTR(_67val_64812);
        _34900 = (object)*(((s1_ptr)_2)->base + _67b_64804);
        _34901 = IS_SEQUENCE(_34900);
        _34900 = NOVALUE;
        if (_34901 == 0)
        {
            _34901 = NOVALUE;
            goto L2; // [96] 217
        }
        else{
            _34901 = NOVALUE;
        }

        /** execute.e:3784					err_file_name = val[b]*/
        DeRef(_67err_file_name_64852);
        _2 = (object)SEQ_PTR(_67val_64812);
        _67err_file_name_64852 = (object)*(((s1_ptr)_2)->base + _67b_64804);
        Ref(_67err_file_name_64852);
        goto L2; // [112] 217

        /** execute.e:3787			case M_WARNING_FILE then*/
        case 72:

        /** execute.e:3788				display_warnings = 1*/
        _49display_warnings_49260 = 1;

        /** execute.e:3789				if sequence(val[b]) then*/
        _2 = (object)SEQ_PTR(_67val_64812);
        _34903 = (object)*(((s1_ptr)_2)->base + _67b_64804);
        _34904 = IS_SEQUENCE(_34903);
        _34903 = NOVALUE;
        if (_34904 == 0)
        {
            _34904 = NOVALUE;
            goto L3; // [138] 154
        }
        else{
            _34904 = NOVALUE;
        }

        /** execute.e:3790					TempWarningName = val[b]*/
        DeRef(_12TempWarningName_20240);
        _2 = (object)SEQ_PTR(_67val_64812);
        _12TempWarningName_20240 = (object)*(((s1_ptr)_2)->base + _67b_64804);
        Ref(_12TempWarningName_20240);
        goto L2; // [151] 217
L3: 

        /** execute.e:3792					TempWarningName = STDERR*/
        DeRef(_12TempWarningName_20240);
        _12TempWarningName_20240 = 2;

        /** execute.e:3793					display_warnings = (val[b] >= 0)*/
        _2 = (object)SEQ_PTR(_67val_64812);
        _34906 = (object)*(((s1_ptr)_2)->base + _67b_64804);
        if (IS_ATOM_INT(_34906)) {
            _49display_warnings_49260 = (_34906 >= 0);
        }
        else {
            _49display_warnings_49260 = binary_op(GREATEREQ, _34906, 0);
        }
        _34906 = NOVALUE;
        if (!IS_ATOM_INT(_49display_warnings_49260)) {
            _1 = (object)(DBL_PTR(_49display_warnings_49260)->dbl);
            DeRefDS(_49display_warnings_49260);
            _49display_warnings_49260 = _1;
        }
        goto L2; // [178] 217

        /** execute.e:3796			case M_CRASH then*/
        case 67:

        /** execute.e:3798				RTFatal( val[b] )*/
        _2 = (object)SEQ_PTR(_67val_64812);
        _34908 = (object)*(((s1_ptr)_2)->base + _67b_64804);
        Ref(_34908);
        _67RTFatal(_34908);
        _34908 = NOVALUE;
        goto L2; // [197] 217

        /** execute.e:3801			case else*/
        default:
L1: 

        /** execute.e:3802				machine_proc(v, val[b])*/
        _2 = (object)SEQ_PTR(_67val_64812);
        _34909 = (object)*(((s1_ptr)_2)->base + _67b_64804);
        machine(_v_69925, _34909);
        _34909 = NOVALUE;
    ;}L2: 

    /** execute.e:3804		pc += 3*/
    _67pc_64802 = _67pc_64802 + 3;

    /** execute.e:3805	end procedure*/
    DeRef(_v_69925);
    DeRef(_34894);
    _34894 = NOVALUE;
    DeRef(_34892);
    _34892 = NOVALUE;
    return;
    ;
}


void _67opDEREF_TEMP()
{
    object _34912 = NOVALUE;
    object _34911 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3808		val[Code[pc+1]] = NOVALUE*/
    _34911 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34912 = (object)*(((s1_ptr)_2)->base + _34911);
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_34912))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_34912)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _34912);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** execute.e:3809		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:3810	end procedure*/
    _34911 = NOVALUE;
    _34912 = NOVALUE;
    return;
    ;
}


void _67do_delete_routine(object _dx_69978, object _o_69979)
{
    object _arglist_assign_69982 = NOVALUE;
    object _34934 = NOVALUE;
    object _34933 = NOVALUE;
    object _34932 = NOVALUE;
    object _34931 = NOVALUE;
    object _34930 = NOVALUE;
    object _34928 = NOVALUE;
    object _34927 = NOVALUE;
    object _34925 = NOVALUE;
    object _34924 = NOVALUE;
    object _34919 = NOVALUE;
    object _34917 = NOVALUE;
    object _34916 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:3823		val[t_id] = user_delete_rid[dx]*/
    _2 = (object)SEQ_PTR(_67user_delete_rid_69971);
    _34916 = (object)*(((s1_ptr)_2)->base + _dx_69978);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_id_64733);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34916;
    if( _1 != _34916 ){
        DeRef(_1);
    }
    _34916 = NOVALUE;

    /** execute.e:3824		val[t_arglist] = {o}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_o_69979);
    ((intptr_t*)_2)[1] = _o_69979;
    _34917 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_64734);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34917;
    if( _1 != _34917 ){
        DeRef(_1);
    }
    _34917 = NOVALUE;

    /** execute.e:3825		atom arglist_assign = new_arg_assign()*/
    _0 = _arglist_assign_69982;
    _arglist_assign_69982 = _67new_arg_assign();
    DeRef(_0);

    /** execute.e:3827		SymTab[delete_code_routine][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67delete_code_routine_64737 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_64819;
    DeRef(_1);
    _34919 = NOVALUE;

    /** execute.e:3830		call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_64820, _67call_stack_64820, _67pc_64802);

    /** execute.e:3831		call_stack = append(call_stack, delete_code_routine)*/
    Append(&_67call_stack_64820, _67call_stack_64820, _67delete_code_routine_64737);

    /** execute.e:3833		Code = delete_code*/
    RefDS(_67delete_code_64731);
    DeRef(_12Code_20315);
    _12Code_20315 = _67delete_code_64731;

    /** execute.e:3834		pc = 1*/
    _67pc_64802 = 1;

    /** execute.e:3836		do_exec()*/
    _67do_exec();

    /** execute.e:3838		if arglist_assign = arg_assign then*/
    if (binary_op_a(NOTEQ, _arglist_assign_69982, _67arg_assign_64746)){
        goto L1; // [99] 116
    }

    /** execute.e:3840			val[t_arglist] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_64734);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
L1: 

    /** execute.e:3842		o = 0*/
    DeRef(_o_69979);
    _o_69979 = 0;

    /** execute.e:3845		pc = call_stack[$-1]*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _34924 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _34924 = 1;
    }
    _34925 = _34924 - 1;
    _34924 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_64820);
    _67pc_64802 = (object)*(((s1_ptr)_2)->base + _34925);
    if (!IS_ATOM_INT(_67pc_64802))
    _67pc_64802 = (object)DBL_PTR(_67pc_64802)->dbl;

    /** execute.e:3846		call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _34927 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _34927 = 1;
    }
    _34928 = _34927 - 2;
    _34927 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_64820;
    RHS_Slice(_67call_stack_64820, 1, _34928);

    /** execute.e:3848		restore_privates( call_stack[$] )*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _34930 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _34930 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_64820);
    _34931 = (object)*(((s1_ptr)_2)->base + _34930);
    Ref(_34931);
    _67restore_privates(_34931);
    _34931 = NOVALUE;

    /** execute.e:3851		Code = SymTab[call_stack[$]][S_CODE]*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _34932 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _34932 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_64820);
    _34933 = (object)*(((s1_ptr)_2)->base + _34932);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_34933)){
        _34934 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34933)->dbl));
    }
    else{
        _34934 = (object)*(((s1_ptr)_2)->base + _34933);
    }
    DeRef(_12Code_20315);
    _2 = (object)SEQ_PTR(_34934);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    Ref(_12Code_20315);
    _34934 = NOVALUE;

    /** execute.e:3852	end procedure*/
    DeRef(_arglist_assign_69982);
    _34928 = NOVALUE;
    _34925 = NOVALUE;
    _34933 = NOVALUE;
    return;
    ;
}


void _67user_delete_01(object _o_70012)
{
    object _0, _1, _2;
    

    /** execute.e:3855		do_delete_routine( 1, o )*/
    Ref(_o_70012);
    _67do_delete_routine(1, _o_70012);

    /** execute.e:3856	end procedure*/
    DeRef(_o_70012);
    return;
    ;
}


void _67user_delete_02(object _o_70017)
{
    object _0, _1, _2;
    

    /** execute.e:3860		do_delete_routine( 2, o )*/
    Ref(_o_70017);
    _67do_delete_routine(2, _o_70017);

    /** execute.e:3861	end procedure*/
    DeRef(_o_70017);
    return;
    ;
}


void _67user_delete_03(object _o_70022)
{
    object _0, _1, _2;
    

    /** execute.e:3865		do_delete_routine( 3, o )*/
    Ref(_o_70022);
    _67do_delete_routine(3, _o_70022);

    /** execute.e:3866	end procedure*/
    DeRef(_o_70022);
    return;
    ;
}


void _67user_delete_04(object _o_70027)
{
    object _0, _1, _2;
    

    /** execute.e:3870		do_delete_routine( 4, o )*/
    Ref(_o_70027);
    _67do_delete_routine(4, _o_70027);

    /** execute.e:3871	end procedure*/
    DeRef(_o_70027);
    return;
    ;
}


void _67user_delete_05(object _o_70032)
{
    object _0, _1, _2;
    

    /** execute.e:3875		do_delete_routine( 5, o )*/
    Ref(_o_70032);
    _67do_delete_routine(5, _o_70032);

    /** execute.e:3876	end procedure*/
    DeRef(_o_70032);
    return;
    ;
}


void _67user_delete_06(object _o_70037)
{
    object _0, _1, _2;
    

    /** execute.e:3880		do_delete_routine( 6, o )*/
    Ref(_o_70037);
    _67do_delete_routine(6, _o_70037);

    /** execute.e:3881	end procedure*/
    DeRef(_o_70037);
    return;
    ;
}


void _67user_delete_07(object _o_70042)
{
    object _0, _1, _2;
    

    /** execute.e:3885		do_delete_routine( 7, o )*/
    Ref(_o_70042);
    _67do_delete_routine(7, _o_70042);

    /** execute.e:3886	end procedure*/
    DeRef(_o_70042);
    return;
    ;
}


void _67user_delete_08(object _o_70047)
{
    object _0, _1, _2;
    

    /** execute.e:3890		do_delete_routine( 8, o )*/
    Ref(_o_70047);
    _67do_delete_routine(8, _o_70047);

    /** execute.e:3891	end procedure*/
    DeRef(_o_70047);
    return;
    ;
}


void _67user_delete_09(object _o_70052)
{
    object _0, _1, _2;
    

    /** execute.e:3895		do_delete_routine( 9, o )*/
    Ref(_o_70052);
    _67do_delete_routine(9, _o_70052);

    /** execute.e:3896	end procedure*/
    DeRef(_o_70052);
    return;
    ;
}


void _67user_delete_10(object _o_70057)
{
    object _0, _1, _2;
    

    /** execute.e:3900		do_delete_routine( 10, o )*/
    Ref(_o_70057);
    _67do_delete_routine(10, _o_70057);

    /** execute.e:3901	end procedure*/
    DeRef(_o_70057);
    return;
    ;
}


void _67user_delete_11(object _o_70062)
{
    object _0, _1, _2;
    

    /** execute.e:3905		do_delete_routine( 11, o )*/
    Ref(_o_70062);
    _67do_delete_routine(11, _o_70062);

    /** execute.e:3906	end procedure*/
    DeRef(_o_70062);
    return;
    ;
}


void _67user_delete_12(object _o_70067)
{
    object _0, _1, _2;
    

    /** execute.e:3910		do_delete_routine( 12, o )*/
    Ref(_o_70067);
    _67do_delete_routine(12, _o_70067);

    /** execute.e:3911	end procedure*/
    DeRef(_o_70067);
    return;
    ;
}


void _67user_delete_13(object _o_70072)
{
    object _0, _1, _2;
    

    /** execute.e:3915		do_delete_routine( 13, o )*/
    Ref(_o_70072);
    _67do_delete_routine(13, _o_70072);

    /** execute.e:3916	end procedure*/
    DeRef(_o_70072);
    return;
    ;
}


void _67user_delete_14(object _o_70077)
{
    object _0, _1, _2;
    

    /** execute.e:3920		do_delete_routine( 14, o )*/
    Ref(_o_70077);
    _67do_delete_routine(14, _o_70077);

    /** execute.e:3921	end procedure*/
    DeRef(_o_70077);
    return;
    ;
}


void _67user_delete_15(object _o_70082)
{
    object _0, _1, _2;
    

    /** execute.e:3925		do_delete_routine( 15, o )*/
    Ref(_o_70082);
    _67do_delete_routine(15, _o_70082);

    /** execute.e:3926	end procedure*/
    DeRef(_o_70082);
    return;
    ;
}


void _67user_delete_16(object _o_70087)
{
    object _0, _1, _2;
    

    /** execute.e:3930		do_delete_routine( 16, o )*/
    Ref(_o_70087);
    _67do_delete_routine(16, _o_70087);

    /** execute.e:3931	end procedure*/
    DeRef(_o_70087);
    return;
    ;
}


void _67user_delete_17(object _o_70092)
{
    object _0, _1, _2;
    

    /** execute.e:3935		do_delete_routine( 17, o )*/
    Ref(_o_70092);
    _67do_delete_routine(17, _o_70092);

    /** execute.e:3936	end procedure*/
    DeRef(_o_70092);
    return;
    ;
}


void _67user_delete_18(object _o_70097)
{
    object _0, _1, _2;
    

    /** execute.e:3940		do_delete_routine( 18, o )*/
    Ref(_o_70097);
    _67do_delete_routine(18, _o_70097);

    /** execute.e:3941	end procedure*/
    DeRef(_o_70097);
    return;
    ;
}


void _67user_delete_19(object _o_70102)
{
    object _0, _1, _2;
    

    /** execute.e:3945		do_delete_routine( 19, o )*/
    Ref(_o_70102);
    _67do_delete_routine(19, _o_70102);

    /** execute.e:3946	end procedure*/
    DeRef(_o_70102);
    return;
    ;
}


void _67user_delete_20(object _o_70107)
{
    object _0, _1, _2;
    

    /** execute.e:3950		do_delete_routine( 20, o )*/
    Ref(_o_70107);
    _67do_delete_routine(20, _o_70107);

    /** execute.e:3951	end procedure*/
    DeRef(_o_70107);
    return;
    ;
}


void _67opDELETE_ROUTINE()
{
    object _rid_70115 = NOVALUE;
    object _34991 = NOVALUE;
    object _34990 = NOVALUE;
    object _34989 = NOVALUE;
    object _34988 = NOVALUE;
    object _34987 = NOVALUE;
    object _34986 = NOVALUE;
    object _34979 = NOVALUE;
    object _34978 = NOVALUE;
    object _34976 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3956		a = Code[pc+1]*/
    _34976 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64803 = (object)*(((s1_ptr)_2)->base + _34976);
    if (!IS_ATOM_INT(_67a_64803)){
        _67a_64803 = (object)DBL_PTR(_67a_64803)->dbl;
    }

    /** execute.e:3958		integer rid = val[Code[pc+2]]*/
    _34978 = _67pc_64802 + 2;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34979 = (object)*(((s1_ptr)_2)->base + _34978);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_34979)){
        _rid_70115 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34979)->dbl));
    }
    else{
        _rid_70115 = (object)*(((s1_ptr)_2)->base + _34979);
    }
    if (!IS_ATOM_INT(_rid_70115))
    _rid_70115 = (object)DBL_PTR(_rid_70115)->dbl;

    /** execute.e:3959		b = find( rid, user_delete_rid )*/
    _67b_64804 = find_from(_rid_70115, _67user_delete_rid_69971, 1);

    /** execute.e:3960		if not b then*/
    if (_67b_64804 != 0)
    goto L1; // [50] 86

    /** execute.e:3961			b = find( -1, user_delete_rid )*/
    _67b_64804 = find_from(-1, _67user_delete_rid_69971, 1);

    /** execute.e:3962			if not b then*/
    if (_67b_64804 != 0)
    goto L2; // [66] 75

    /** execute.e:3963				RTFatal("Maximum of 20 user defined delete routines exceeded.")*/
    RefDS(_34985);
    _67RTFatal(_34985);
L2: 

    /** execute.e:3965			user_delete_rid[b] = rid*/
    _2 = (object)SEQ_PTR(_67user_delete_rid_69971);
    _2 = (object)(((s1_ptr)_2)->base + _67b_64804);
    *(intptr_t *)_2 = _rid_70115;
L1: 

    /** execute.e:3967		val[Code[pc+3]] = delete_routine( val[a], eu_delete_rid[b] )*/
    _34986 = _67pc_64802 + 3;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34987 = (object)*(((s1_ptr)_2)->base + _34986);
    _2 = (object)SEQ_PTR(_67val_64812);
    _34988 = (object)*(((s1_ptr)_2)->base + _67a_64803);
    _2 = (object)SEQ_PTR(_67eu_delete_rid_69969);
    _34989 = (object)*(((s1_ptr)_2)->base + _67b_64804);
    DeRef(_34990);
    if( IS_ATOM_INT(_34988) ){
        _34990 = NewDouble( (eudouble) _34988 );
    }
    else {
        if( !UNIQUE(SEQ_PTR(_34988)) ){
            if( IS_ATOM_DBL( _34988 ) ){
                _34990 = NewDouble( DBL_PTR(_34988)->dbl );
            }
            else {
                RefDS(_34988);
                _34990 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_34988) ));
            }
        }
        else {
            _34990 = _34988;
        }
    }
    _1 = (object) _00[_34989].cleanup;
    if( _1 == 0 ){
        _1 = (object) TransAlloc( sizeof(struct cleanup) );
        _00[_34989].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _34989;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_34990) ){
        if( IS_ATOM_INT(_34990) ){
            _34990 = NewDouble( (eudouble) _34988 );
        }
        if(DBL_PTR(_34990)->cleanup != 0 ){
            _1 = (object) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_34990)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_34990)) ){
            DeRefDS(_34990);
            _34990 = NewDouble( DBL_PTR(_34990)->dbl );
        }
        DBL_PTR(_34990)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_34990)->cleanup != 0 ){
            _1 = (object) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_34990)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_34990)) ){
            _34990 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_34990) ));
        }
        SEQ_PTR(_34990)->cleanup = (cleanup_ptr)_1;
    }
    _34988 = NOVALUE;
    _34989 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_34987))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_34987)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _34987);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34990;
    if( _1 != _34990 ){
        DeRef(_1);
    }
    _34990 = NOVALUE;

    /** execute.e:3968		if sym_mode( a ) = M_TEMP then*/
    _34991 = _53sym_mode(_67a_64803);
    if (binary_op_a(NOTEQ, _34991, 3)){
        DeRef(_34991);
        _34991 = NOVALUE;
        goto L3; // [136] 153
    }
    DeRef(_34991);
    _34991 = NOVALUE;

    /** execute.e:3969			val[a] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64812 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67a_64803);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
L3: 

    /** execute.e:3972		pc += 4*/
    _67pc_64802 = _67pc_64802 + 4;

    /** execute.e:3973	end procedure*/
    DeRef(_34986);
    _34986 = NOVALUE;
    _34979 = NOVALUE;
    DeRef(_34976);
    _34976 = NOVALUE;
    _34987 = NOVALUE;
    DeRef(_34978);
    _34978 = NOVALUE;
    return;
    ;
}


void _67opDELETE_OBJECT()
{
    object _34996 = NOVALUE;
    object _34995 = NOVALUE;
    object _34994 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3976		delete( val[Code[pc+1]] )*/
    _34994 = _67pc_64802 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34995 = (object)*(((s1_ptr)_2)->base + _34994);
    _2 = (object)SEQ_PTR(_67val_64812);
    if (!IS_ATOM_INT(_34995)){
        _34996 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34995)->dbl));
    }
    else{
        _34996 = (object)*(((s1_ptr)_2)->base + _34995);
    }
    if( IS_SEQUENCE(_34996) ){
        cleanup_sequence(SEQ_PTR(_34996));
    }
    if( IS_ATOM_DBL(_34996)){
        cleanup_double(DBL_PTR(_34996));
    }
    _34996 = NOVALUE;

    /** execute.e:3977		pc += 2*/
    _67pc_64802 = _67pc_64802 + 2;

    /** execute.e:3978	end procedure*/
    _34994 = NOVALUE;
    _34995 = NOVALUE;
    return;
    ;
}


void _67do_exec()
{
    object _op_70151 = NOVALUE;
    object _35005 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3982		keep_running = TRUE*/
    _67keep_running_64809 = _9TRUE_446;

    /** execute.e:3983		while keep_running do*/
L1: 
    if (_67keep_running_64809 == 0)
    {
        goto L2; // [17] 1910
    }
    else{
    }

    /** execute.e:3984			integer op = Code[pc]*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _op_70151 = (object)*(((s1_ptr)_2)->base + _67pc_64802);
    if (!IS_ATOM_INT(_op_70151)){
        _op_70151 = (object)DBL_PTR(_op_70151)->dbl;
    }

    /** execute.e:3985			ifdef DEBUG then*/

    /** execute.e:3992			switch op do*/
    _0 = _op_70151;
    switch ( _0 ){ 

        /** execute.e:3993				case ABORT then*/
        case 126:

        /** execute.e:3994					opABORT()*/
        _67opABORT();
        goto L3; // [49] 1903

        /** execute.e:3996				case AND then*/
        case 8:

        /** execute.e:3997					opAND()*/
        _67opAND();
        goto L3; // [59] 1903

        /** execute.e:3999				case AND_BITS then*/
        case 56:

        /** execute.e:4000					opAND_BITS()*/
        _67opAND_BITS();
        goto L3; // [69] 1903

        /** execute.e:4002				case APPEND then*/
        case 35:

        /** execute.e:4003					opAPPEND()*/
        _67opAPPEND();
        goto L3; // [79] 1903

        /** execute.e:4005				case ARCTAN then*/
        case 73:

        /** execute.e:4006					opARCTAN()*/
        _67opARCTAN();
        goto L3; // [89] 1903

        /** execute.e:4008				case ASSIGN, ASSIGN_I then*/
        case 18:
        case 113:

        /** execute.e:4009					opASSIGN()*/
        _67opASSIGN();
        goto L3; // [101] 1903

        /** execute.e:4011				case ASSIGN_OP_SLICE then*/
        case 150:

        /** execute.e:4012					opASSIGN_OP_SLICE()*/
        _67opASSIGN_OP_SLICE();
        goto L3; // [111] 1903

        /** execute.e:4014				case ASSIGN_OP_SUBS then*/
        case 149:

        /** execute.e:4015					opASSIGN_OP_SUBS()*/
        _67opASSIGN_OP_SUBS();
        goto L3; // [121] 1903

        /** execute.e:4017				case ASSIGN_SLICE then*/
        case 45:

        /** execute.e:4018					opASSIGN_SLICE()*/
        _67opASSIGN_SLICE();
        goto L3; // [131] 1903

        /** execute.e:4020				case ASSIGN_SUBS, ASSIGN_SUBS_CHECK, ASSIGN_SUBS_I then*/
        case 16:
        case 84:
        case 118:

        /** execute.e:4021					opASSIGN_SUBS()*/
        _67opASSIGN_SUBS();
        goto L3; // [145] 1903

        /** execute.e:4023				case ATOM_CHECK then*/
        case 101:

        /** execute.e:4024					opATOM_CHECK()*/
        _67opATOM_CHECK();
        goto L3; // [155] 1903

        /** execute.e:4026				case BADRETURNF then*/
        case 43:

        /** execute.e:4027					opBADRETURNF()*/
        _67opBADRETURNF();
        goto L3; // [165] 1903

        /** execute.e:4029				case C_FUNC then*/
        case 133:

        /** execute.e:4030					opC_FUNC()*/
        _67opC_FUNC();
        goto L3; // [175] 1903

        /** execute.e:4032				case C_PROC then*/
        case 132:

        /** execute.e:4033					opC_PROC()*/
        _67opC_PROC();
        goto L3; // [185] 1903

        /** execute.e:4035				case CALL then*/
        case 129:

        /** execute.e:4036					opCALL()*/
        _67opCALL();
        goto L3; // [195] 1903

        /** execute.e:4038				case CALL_BACK_RETURN then*/
        case 135:

        /** execute.e:4039					opCALL_BACK_RETURN()*/
        _67opCALL_BACK_RETURN();
        goto L3; // [205] 1903

        /** execute.e:4041				case CALL_PROC, CALL_FUNC then*/
        case 136:
        case 137:

        /** execute.e:4042					opCALL_PROC()*/
        _67opCALL_PROC();
        goto L3; // [217] 1903

        /** execute.e:4044				case CASE then*/
        case 186:

        /** execute.e:4045					opCASE()*/
        _67opCASE();
        goto L3; // [227] 1903

        /** execute.e:4047				case CLEAR_SCREEN then*/
        case 59:

        /** execute.e:4048					opCLEAR_SCREEN()*/
        _67opCLEAR_SCREEN();
        goto L3; // [237] 1903

        /** execute.e:4050				case CLOSE then*/
        case 86:

        /** execute.e:4051					opCLOSE()*/
        _67opCLOSE();
        goto L3; // [247] 1903

        /** execute.e:4053				case COMMAND_LINE then*/
        case 100:

        /** execute.e:4054					opCOMMAND_LINE()*/
        _67opCOMMAND_LINE();
        goto L3; // [257] 1903

        /** execute.e:4056				case COMPARE then*/
        case 76:

        /** execute.e:4057					opCOMPARE()*/
        _67opCOMPARE();
        goto L3; // [267] 1903

        /** execute.e:4059				case CONCAT then*/
        case 15:

        /** execute.e:4060					opCONCAT()*/
        _67opCONCAT();
        goto L3; // [277] 1903

        /** execute.e:4062				case CONCAT_N then*/
        case 157:

        /** execute.e:4063					opCONCAT_N()*/
        _67opCONCAT_N();
        goto L3; // [287] 1903

        /** execute.e:4065				case COS then*/
        case 81:

        /** execute.e:4066					opCOS()*/
        _67opCOS();
        goto L3; // [297] 1903

        /** execute.e:4068				case DATE then*/
        case 69:

        /** execute.e:4069					opDATE()*/
        _67opDATE();
        goto L3; // [307] 1903

        /** execute.e:4071				case DIV2 then*/
        case 98:

        /** execute.e:4072					opDIV2()*/
        _67opDIV2();
        goto L3; // [317] 1903

        /** execute.e:4074				case DIVIDE then*/
        case 14:

        /** execute.e:4075					opDIVIDE()*/
        _67opDIVIDE();
        goto L3; // [327] 1903

        /** execute.e:4077				case ELSE, EXIT, ENDWHILE, RETRY then*/
        case 23:
        case 61:
        case 22:
        case 184:

        /** execute.e:4078					opELSE()*/
        _67opELSE();
        goto L3; // [343] 1903

        /** execute.e:4080				case ENDFOR_GENERAL, ENDFOR_UP, ENDFOR_DOWN, ENDFOR_INT_UP,*/
        case 39:
        case 49:
        case 50:
        case 48:
        case 52:
        case 55:

        /** execute.e:4082					opENDFOR_GENERAL()*/
        _67opENDFOR_GENERAL();
        goto L3; // [363] 1903

        /** execute.e:4084				case ENDFOR_INT_UP1 then*/
        case 54:

        /** execute.e:4085					opENDFOR_INT_UP1()*/
        _67opENDFOR_INT_UP1();
        goto L3; // [373] 1903

        /** execute.e:4087				case EQUAL then*/
        case 153:

        /** execute.e:4088					opEQUAL()*/
        _67opEQUAL();
        goto L3; // [383] 1903

        /** execute.e:4090				case EQUALS then*/
        case 3:

        /** execute.e:4091					opEQUALS()*/
        _67opEQUALS();
        goto L3; // [393] 1903

        /** execute.e:4093				case EQUALS_IFW, EQUALS_IFW_I then*/
        case 104:
        case 121:

        /** execute.e:4094					opEQUALS_IFW()*/
        _67opEQUALS_IFW();
        goto L3; // [405] 1903

        /** execute.e:4096				case EXIT_BLOCK then*/
        case 206:

        /** execute.e:4097					opEXIT_BLOCK()*/
        _67opEXIT_BLOCK();
        goto L3; // [415] 1903

        /** execute.e:4099				case FIND then*/
        case 77:

        /** execute.e:4100					opFIND()*/
        _67opFIND();
        goto L3; // [425] 1903

        /** execute.e:4102				case FIND_FROM then*/
        case 176:

        /** execute.e:4103					opFIND_FROM()*/
        _67opFIND_FROM();
        goto L3; // [435] 1903

        /** execute.e:4105				case FLOOR then*/
        case 83:

        /** execute.e:4106					opFLOOR()*/
        _67opFLOOR();
        goto L3; // [445] 1903

        /** execute.e:4108				case FLOOR_DIV then*/
        case 63:

        /** execute.e:4109					opFLOOR_DIV()*/
        _67opFLOOR_DIV();
        goto L3; // [455] 1903

        /** execute.e:4111				case FLOOR_DIV2 then*/
        case 66:

        /** execute.e:4112					opFLOOR_DIV2()*/
        _67opFLOOR_DIV2();
        goto L3; // [465] 1903

        /** execute.e:4114				case FOR, FOR_I then*/
        case 21:
        case 125:

        /** execute.e:4115					opFOR()*/
        _67opFOR();
        goto L3; // [477] 1903

        /** execute.e:4117				case GET_KEY then*/
        case 79:

        /** execute.e:4118					opGET_KEY()*/
        _67opGET_KEY();
        goto L3; // [487] 1903

        /** execute.e:4120				case GETC then*/
        case 33:

        /** execute.e:4121					opGETC()*/
        _67opGETC();
        goto L3; // [497] 1903

        /** execute.e:4123				case GETENV then*/
        case 91:

        /** execute.e:4124					opGETENV()*/
        _67opGETENV();
        goto L3; // [507] 1903

        /** execute.e:4126				case GETS then*/
        case 17:

        /** execute.e:4127					opGETS()*/
        _67opGETS();
        goto L3; // [517] 1903

        /** execute.e:4129				case GLABEL then*/
        case 189:

        /** execute.e:4130					opGLABEL()*/
        _67opGLABEL();
        goto L3; // [527] 1903

        /** execute.e:4132				case GLOBAL_INIT_CHECK, PRIVATE_INIT_CHECK then*/
        case 109:
        case 30:

        /** execute.e:4133					opGLOBAL_INIT_CHECK()*/
        _67opGLOBAL_INIT_CHECK();
        goto L3; // [539] 1903

        /** execute.e:4135				case GOTO then*/
        case 188:

        /** execute.e:4136					opGOTO()*/
        _67opGOTO();
        goto L3; // [549] 1903

        /** execute.e:4138				case GREATER then*/
        case 6:

        /** execute.e:4139					opGREATER()*/
        _67opGREATER();
        goto L3; // [559] 1903

        /** execute.e:4141				case GREATER_IFW, GREATER_IFW_I then*/
        case 107:
        case 124:

        /** execute.e:4142					opGREATER_IFW()*/
        _67opGREATER_IFW();
        goto L3; // [571] 1903

        /** execute.e:4144				case GREATEREQ then*/
        case 2:

        /** execute.e:4145					opGREATEREQ()*/
        _67opGREATEREQ();
        goto L3; // [581] 1903

        /** execute.e:4147				case GREATEREQ_IFW, GREATEREQ_IFW_I then*/
        case 103:
        case 120:

        /** execute.e:4148					opGREATEREQ_IFW()*/
        _67opGREATEREQ_IFW();
        goto L3; // [593] 1903

        /** execute.e:4150				case HASH then*/
        case 194:

        /** execute.e:4151					opHASH()*/
        _67opHASH();
        goto L3; // [603] 1903

        /** execute.e:4153				case HEAD then*/
        case 198:

        /** execute.e:4154					opHEAD()*/
        _67opHEAD();
        goto L3; // [613] 1903

        /** execute.e:4156				case IF then*/
        case 20:

        /** execute.e:4157					opIF()*/
        _67opIF();
        goto L3; // [623] 1903

        /** execute.e:4159				case INSERT then*/
        case 191:

        /** execute.e:4160					opINSERT()*/
        _67opINSERT();
        goto L3; // [633] 1903

        /** execute.e:4162				case INTEGER_CHECK then*/
        case 96:

        /** execute.e:4163					opINTEGER_CHECK()*/
        _67opINTEGER_CHECK();
        goto L3; // [643] 1903

        /** execute.e:4165				case IS_A_SEQUENCE then*/
        case 68:

        /** execute.e:4166					opIS_A_SEQUENCE()*/
        _67opIS_A_SEQUENCE();
        goto L3; // [653] 1903

        /** execute.e:4168				case IS_AN_ATOM then*/
        case 67:

        /** execute.e:4169					opIS_AN_ATOM()*/
        _67opIS_AN_ATOM();
        goto L3; // [663] 1903

        /** execute.e:4171				case IS_AN_INTEGER then*/
        case 94:

        /** execute.e:4172					opIS_AN_INTEGER()*/
        _67opIS_AN_INTEGER();
        goto L3; // [673] 1903

        /** execute.e:4174				case IS_AN_OBJECT then*/
        case 40:

        /** execute.e:4175					opIS_AN_OBJECT()*/
        _67opIS_AN_OBJECT();
        goto L3; // [683] 1903

        /** execute.e:4177				case LENGTH then*/
        case 42:

        /** execute.e:4178					opLENGTH()*/
        _67opLENGTH();
        goto L3; // [693] 1903

        /** execute.e:4180				case LESS then*/
        case 1:

        /** execute.e:4181					opLESS()*/
        _67opLESS();
        goto L3; // [703] 1903

        /** execute.e:4183				case LESS_IFW_I, LESS_IFW then*/
        case 119:
        case 102:

        /** execute.e:4184					opLESS_IFW()*/
        _67opLESS_IFW();
        goto L3; // [715] 1903

        /** execute.e:4186				case LESSEQ then*/
        case 5:

        /** execute.e:4187					opLESSEQ()*/
        _67opLESSEQ();
        goto L3; // [725] 1903

        /** execute.e:4189				case LESSEQ_IFW, LESSEQ_IFW_I then*/
        case 106:
        case 123:

        /** execute.e:4190					opLESSEQ_IFW()*/
        _67opLESSEQ_IFW();
        goto L3; // [737] 1903

        /** execute.e:4192				case LHS_SUBS then*/
        case 95:

        /** execute.e:4193					opLHS_SUBS()*/
        _67opLHS_SUBS();
        goto L3; // [747] 1903

        /** execute.e:4195				case LHS_SUBS1 then*/
        case 161:

        /** execute.e:4196					opLHS_SUBS1()*/
        _67opLHS_SUBS1();
        goto L3; // [757] 1903

        /** execute.e:4198				case LHS_SUBS1_COPY then*/
        case 166:

        /** execute.e:4199					opLHS_SUBS1_COPY()*/
        _67opLHS_SUBS1_COPY();
        goto L3; // [767] 1903

        /** execute.e:4201				case LOG then*/
        case 74:

        /** execute.e:4202					opLOG()*/
        _67opLOG();
        goto L3; // [777] 1903

        /** execute.e:4204				case MACHINE_FUNC then*/
        case 111:

        /** execute.e:4205					opMACHINE_FUNC()*/
        _67opMACHINE_FUNC();
        goto L3; // [787] 1903

        /** execute.e:4207				case MACHINE_PROC then*/
        case 112:

        /** execute.e:4208					opMACHINE_PROC()*/
        _67opMACHINE_PROC();
        goto L3; // [797] 1903

        /** execute.e:4210				case MATCH then*/
        case 78:

        /** execute.e:4211					opMATCH()*/
        _67opMATCH();
        goto L3; // [807] 1903

        /** execute.e:4213				case MATCH_FROM then*/
        case 177:

        /** execute.e:4214					opMATCH_FROM()*/
        _67opMATCH_FROM();
        goto L3; // [817] 1903

        /** execute.e:4216				case MEM_COPY then*/
        case 130:

        /** execute.e:4217					opMEM_COPY()*/
        _67opMEM_COPY();
        goto L3; // [827] 1903

        /** execute.e:4219				case MEM_SET then*/
        case 131:

        /** execute.e:4220					opMEM_SET()*/
        _67opMEM_SET();
        goto L3; // [837] 1903

        /** execute.e:4222				case MINUS, MINUS_I then*/
        case 10:
        case 116:

        /** execute.e:4223					opMINUS()*/
        _67opMINUS();
        goto L3; // [849] 1903

        /** execute.e:4225				case MULTIPLY then*/
        case 13:

        /** execute.e:4226					opMULTIPLY()*/
        _67opMULTIPLY();
        goto L3; // [859] 1903

        /** execute.e:4228				case NOP2, SC2_NULL, ASSIGN_SUBS2, PLATFORM, END_PARAM_CHECK,*/
        case 110:
        case 145:
        case 148:
        case 155:
        case 156:
        case 158:
        case 159:

        /** execute.e:4230					opNOP2()*/
        _67opNOP2();
        goto L3; // [881] 1903

        /** execute.e:4232				case NOPSWITCH then*/
        case 187:

        /** execute.e:4233					opNOPSWITCH()*/
        _67opNOPSWITCH();
        goto L3; // [891] 1903

        /** execute.e:4235				case NOT then*/
        case 7:

        /** execute.e:4236					opNOT()*/
        _67opNOT();
        goto L3; // [901] 1903

        /** execute.e:4238				case NOT_BITS then*/
        case 51:

        /** execute.e:4239					opNOT_BITS()*/
        _67opNOT_BITS();
        goto L3; // [911] 1903

        /** execute.e:4241				case NOT_IFW then*/
        case 108:

        /** execute.e:4242					opNOT_IFW()*/
        _67opNOT_IFW();
        goto L3; // [921] 1903

        /** execute.e:4244				case NOTEQ then*/
        case 4:

        /** execute.e:4245					opNOTEQ()*/
        _67opNOTEQ();
        goto L3; // [931] 1903

        /** execute.e:4247				case NOTEQ_IFW, NOTEQ_IFW_I then*/
        case 105:
        case 122:

        /** execute.e:4248					opNOTEQ_IFW()*/
        _67opNOTEQ_IFW();
        goto L3; // [943] 1903

        /** execute.e:4250				case OPEN then*/
        case 37:

        /** execute.e:4251					opOPEN()*/
        _67opOPEN();
        goto L3; // [953] 1903

        /** execute.e:4253				case OPTION_SWITCHES then*/
        case 183:

        /** execute.e:4254					opOPTION_SWITCHES()*/
        _67opOPTION_SWITCHES();
        goto L3; // [963] 1903

        /** execute.e:4256				case OR then*/
        case 9:

        /** execute.e:4257					opOR()*/
        _67opOR();
        goto L3; // [973] 1903

        /** execute.e:4259				case OR_BITS then*/
        case 24:

        /** execute.e:4260					opOR_BITS()*/
        _67opOR_BITS();
        goto L3; // [983] 1903

        /** execute.e:4262				case PASSIGN_OP_SLICE then*/
        case 165:

        /** execute.e:4263					opPASSIGN_OP_SLICE()*/
        _67opPASSIGN_OP_SLICE();
        goto L3; // [993] 1903

        /** execute.e:4265				case PASSIGN_OP_SUBS then*/
        case 164:

        /** execute.e:4266					opPASSIGN_OP_SUBS()*/
        _67opPASSIGN_OP_SUBS();
        goto L3; // [1003] 1903

        /** execute.e:4268				case PASSIGN_SLICE then*/
        case 163:

        /** execute.e:4269					opPASSIGN_SLICE()*/
        _67opPASSIGN_SLICE();
        goto L3; // [1013] 1903

        /** execute.e:4271				case PASSIGN_SUBS then*/
        case 162:

        /** execute.e:4272					opPASSIGN_SUBS()*/
        _67opPASSIGN_SUBS();
        goto L3; // [1023] 1903

        /** execute.e:4274				case PEEK then*/
        case 127:

        /** execute.e:4275					opPEEK()*/
        _67opPEEK();
        goto L3; // [1033] 1903

        /** execute.e:4277				case PEEK_STRING then*/
        case 182:

        /** execute.e:4278					opPEEK_STRING()*/
        _67opPEEK_STRING();
        goto L3; // [1043] 1903

        /** execute.e:4280				case PEEK2S then*/
        case 179:

        /** execute.e:4281					opPEEK2S()*/
        _67opPEEK2S();
        goto L3; // [1053] 1903

        /** execute.e:4283				case PEEK2U then*/
        case 180:

        /** execute.e:4284					opPEEK2U()*/
        _67opPEEK2U();
        goto L3; // [1063] 1903

        /** execute.e:4286				case PEEK4S then*/
        case 139:

        /** execute.e:4287					opPEEK4S()*/
        _67opPEEK4S();
        goto L3; // [1073] 1903

        /** execute.e:4289				case PEEK4U then*/
        case 140:

        /** execute.e:4290					opPEEK4U()*/
        _67opPEEK4U();
        goto L3; // [1083] 1903

        /** execute.e:4292				case PEEK8S then*/
        case 213:

        /** execute.e:4293					opPEEK8S()*/
        _67opPEEK8S();
        goto L3; // [1093] 1903

        /** execute.e:4295				case PEEK8U then*/
        case 214:

        /** execute.e:4296					opPEEK8U()*/
        _67opPEEK8U();
        goto L3; // [1103] 1903

        /** execute.e:4298				case PEEKS then*/
        case 181:

        /** execute.e:4299					opPEEKS()*/
        _67opPEEKS();
        goto L3; // [1113] 1903

        /** execute.e:4301				case PLENGTH then*/
        case 160:

        /** execute.e:4302					opPLENGTH()*/
        _67opPLENGTH();
        goto L3; // [1123] 1903

        /** execute.e:4304				case PLUS, PLUS_I then*/
        case 11:
        case 115:

        /** execute.e:4305					opPLUS()*/
        _67opPLUS();
        goto L3; // [1135] 1903

        /** execute.e:4307				case PLUS1, PLUS1_I then*/
        case 93:
        case 117:

        /** execute.e:4308					opPLUS1()*/
        _67opPLUS1();
        goto L3; // [1147] 1903

        /** execute.e:4310				case POKE then*/
        case 128:

        /** execute.e:4311					opPOKE()*/
        _67opPOKE();
        goto L3; // [1157] 1903

        /** execute.e:4313				case POKE2 then*/
        case 178:

        /** execute.e:4314					opPOKE2()*/
        _67opPOKE2();
        goto L3; // [1167] 1903

        /** execute.e:4316				case POKE4 then*/
        case 138:

        /** execute.e:4317					opPOKE4()*/
        _67opPOKE4();
        goto L3; // [1177] 1903

        /** execute.e:4319				case POKE8 then*/
        case 212:

        /** execute.e:4320					opPOKE8()*/
        _67opPOKE8();
        goto L3; // [1187] 1903

        /** execute.e:4322				case POKE_POINTER then*/
        case 215:

        /** execute.e:4323					opPOKE4()*/
        _67opPOKE4();
        goto L3; // [1197] 1903

        /** execute.e:4325				case PEEK_POINTER then*/
        case 216:

        /** execute.e:4326					opPEEK4U()*/
        _67opPEEK4U();
        goto L3; // [1207] 1903

        /** execute.e:4328				case POSITION then*/
        case 60:

        /** execute.e:4329					opPOSITION()*/
        _67opPOSITION();
        goto L3; // [1217] 1903

        /** execute.e:4331				case POWER then*/
        case 72:

        /** execute.e:4332					opPOWER()*/
        _67opPOWER();
        goto L3; // [1227] 1903

        /** execute.e:4334				case PREPEND then*/
        case 57:

        /** execute.e:4335					opPREPEND()*/
        _67opPREPEND();
        goto L3; // [1237] 1903

        /** execute.e:4337				case PRINT then*/
        case 19:

        /** execute.e:4338					opPRINT()*/
        _67opPRINT();
        goto L3; // [1247] 1903

        /** execute.e:4340				case PRINTF then*/
        case 38:

        /** execute.e:4341					opPRINTF()*/
        _67opPRINTF();
        goto L3; // [1257] 1903

        /** execute.e:4343				case PROC_TAIL then*/
        case 203:

        /** execute.e:4344					opPROC_TAIL()*/
        _67opPROC_TAIL();
        goto L3; // [1267] 1903

        /** execute.e:4346				case PROC then*/
        case 27:

        /** execute.e:4347					opPROC()*/
        _67opPROC();
        goto L3; // [1277] 1903

        /** execute.e:4349				case PROFILE, DISPLAY_VAR, ERASE_PRIVATE_NAMES, ERASE_SYMBOL then*/
        case 151:
        case 87:
        case 88:
        case 90:

        /** execute.e:4350					opPROFILE()*/
        _67opPROFILE();
        goto L3; // [1293] 1903

        /** execute.e:4352				case PUTS then*/
        case 44:

        /** execute.e:4353					opPUTS()*/
        _67opPUTS();
        goto L3; // [1303] 1903

        /** execute.e:4355				case QPRINT then*/
        case 36:

        /** execute.e:4356					opQPRINT()*/
        _67opQPRINT();
        goto L3; // [1313] 1903

        /** execute.e:4358				case RAND then*/
        case 62:

        /** execute.e:4359					opRAND()*/
        _67opRAND();
        goto L3; // [1323] 1903

        /** execute.e:4361				case REMAINDER then*/
        case 71:

        /** execute.e:4362					opREMAINDER()*/
        _67opREMAINDER();
        goto L3; // [1333] 1903

        /** execute.e:4364				case REMOVE then*/
        case 200:

        /** execute.e:4365					opREMOVE()*/
        _67opREMOVE();
        goto L3; // [1343] 1903

        /** execute.e:4367				case REPEAT then*/
        case 32:

        /** execute.e:4368					opREPEAT()*/
        _67opREPEAT();
        goto L3; // [1353] 1903

        /** execute.e:4370				case REPLACE then*/
        case 201:

        /** execute.e:4371					opREPLACE()*/
        _67opREPLACE();
        goto L3; // [1363] 1903

        /** execute.e:4373				case RETURNF then*/
        case 28:

        /** execute.e:4374					opRETURNF()*/
        _67opRETURNF();
        goto L3; // [1373] 1903

        /** execute.e:4376				case RETURNP then*/
        case 29:

        /** execute.e:4377					opRETURNP()*/
        _67opRETURNP();
        goto L3; // [1383] 1903

        /** execute.e:4379				case RETURNT then*/
        case 34:

        /** execute.e:4380					opRETURNT()*/
        _67opRETURNT();
        goto L3; // [1393] 1903

        /** execute.e:4382				case RHS_SLICE then*/
        case 46:

        /** execute.e:4383					opRHS_SLICE()*/
        _67opRHS_SLICE();
        goto L3; // [1403] 1903

        /** execute.e:4385				case RHS_SUBS, RHS_SUBS_CHECK, RHS_SUBS_I then*/
        case 25:
        case 92:
        case 114:

        /** execute.e:4386					opRHS_SUBS()*/
        _67opRHS_SUBS();
        goto L3; // [1417] 1903

        /** execute.e:4388				case RIGHT_BRACE_2 then*/
        case 85:

        /** execute.e:4389					opRIGHT_BRACE_2()*/
        _67opRIGHT_BRACE_2();
        goto L3; // [1427] 1903

        /** execute.e:4391				case RIGHT_BRACE_N then*/
        case 31:

        /** execute.e:4392					opRIGHT_BRACE_N()*/
        _67opRIGHT_BRACE_N();
        goto L3; // [1437] 1903

        /** execute.e:4394				case ROUTINE_ID then*/
        case 134:

        /** execute.e:4395					opROUTINE_ID()*/
        _67opROUTINE_ID();
        goto L3; // [1447] 1903

        /** execute.e:4397				case SC1_AND then*/
        case 141:

        /** execute.e:4398					opSC1_AND()*/
        _67opSC1_AND();
        goto L3; // [1457] 1903

        /** execute.e:4400				case SC1_AND_IF then*/
        case 146:

        /** execute.e:4401					opSC1_AND_IF()*/
        _67opSC1_AND_IF();
        goto L3; // [1467] 1903

        /** execute.e:4403				case SC1_OR then*/
        case 143:

        /** execute.e:4404					opSC1_OR()*/
        _67opSC1_OR();
        goto L3; // [1477] 1903

        /** execute.e:4406				case SC1_OR_IF then*/
        case 147:

        /** execute.e:4407					opSC1_OR_IF()*/
        _67opSC1_OR_IF();
        goto L3; // [1487] 1903

        /** execute.e:4409				case SC2_OR, SC2_AND then*/
        case 144:
        case 142:

        /** execute.e:4410					opSC2_OR()*/
        _67opSC2_OR();
        goto L3; // [1499] 1903

        /** execute.e:4412				case SEQUENCE_CHECK then*/
        case 97:

        /** execute.e:4413					opSEQUENCE_CHECK()*/
        _67opSEQUENCE_CHECK();
        goto L3; // [1509] 1903

        /** execute.e:4415				case SIN then*/
        case 80:

        /** execute.e:4416					opSIN()*/
        _67opSIN();
        goto L3; // [1519] 1903

        /** execute.e:4418				case SPACE_USED then*/
        case 75:

        /** execute.e:4419					opSPACE_USED()*/
        _67opSPACE_USED();
        goto L3; // [1529] 1903

        /** execute.e:4421				case SPLICE then*/
        case 190:

        /** execute.e:4422					opSPLICE()*/
        _67opSPLICE();
        goto L3; // [1539] 1903

        /** execute.e:4424				case SPRINTF then*/
        case 53:

        /** execute.e:4425					opSPRINTF()*/
        _67opSPRINTF();
        goto L3; // [1549] 1903

        /** execute.e:4427				case SQRT then*/
        case 41:

        /** execute.e:4428					opSQRT()*/
        _67opSQRT();
        goto L3; // [1559] 1903

        /** execute.e:4430				case STARTLINE then*/
        case 58:

        /** execute.e:4431					opSTARTLINE()*/
        _67opSTARTLINE();
        goto L3; // [1569] 1903

        /** execute.e:4433				case SWITCH, SWITCH_I then*/
        case 185:
        case 193:

        /** execute.e:4434					opSWITCH()*/
        _67opSWITCH();
        goto L3; // [1581] 1903

        /** execute.e:4436				case SWITCH_SPI then*/
        case 192:

        /** execute.e:4437					opSWITCH_SPI()*/
        _67opSWITCH_SPI();
        goto L3; // [1591] 1903

        /** execute.e:4439				case SWITCH_RT then*/
        case 202:

        /** execute.e:4440					opSWITCH_RT()*/
        _67opSWITCH_RT();
        goto L3; // [1601] 1903

        /** execute.e:4442				case SYSTEM then*/
        case 99:

        /** execute.e:4443					opSYSTEM()*/
        _67opSYSTEM();
        goto L3; // [1611] 1903

        /** execute.e:4445				case SYSTEM_EXEC then*/
        case 154:

        /** execute.e:4446					opSYSTEM_EXEC()*/
        _67opSYSTEM_EXEC();
        goto L3; // [1621] 1903

        /** execute.e:4448				case TAIL then*/
        case 199:

        /** execute.e:4449					opTAIL()*/
        _67opTAIL();
        goto L3; // [1631] 1903

        /** execute.e:4451				case TAN then*/
        case 82:

        /** execute.e:4452					opTAN()*/
        _67opTAN();
        goto L3; // [1641] 1903

        /** execute.e:4454				case TASK_CLOCK_START then*/
        case 175:

        /** execute.e:4455					opTASK_CLOCK_START()*/
        _67opTASK_CLOCK_START();
        goto L3; // [1651] 1903

        /** execute.e:4457				case TASK_CLOCK_STOP then*/
        case 174:

        /** execute.e:4458					opTASK_CLOCK_STOP()*/
        _67opTASK_CLOCK_STOP();
        goto L3; // [1661] 1903

        /** execute.e:4460				case TASK_CREATE then*/
        case 167:

        /** execute.e:4461					opTASK_CREATE()*/
        _67opTASK_CREATE();
        goto L3; // [1671] 1903

        /** execute.e:4463				case TASK_LIST then*/
        case 172:

        /** execute.e:4464					opTASK_LIST()*/
        _67opTASK_LIST();
        goto L3; // [1681] 1903

        /** execute.e:4466				case TASK_SCHEDULE then*/
        case 168:

        /** execute.e:4467					opTASK_SCHEDULE()*/
        _67opTASK_SCHEDULE();
        goto L3; // [1691] 1903

        /** execute.e:4469				case TASK_SELF then*/
        case 170:

        /** execute.e:4470					opTASK_SELF()*/
        _67opTASK_SELF();
        goto L3; // [1701] 1903

        /** execute.e:4472				case TASK_STATUS then*/
        case 173:

        /** execute.e:4473					opTASK_STATUS()*/
        _67opTASK_STATUS();
        goto L3; // [1711] 1903

        /** execute.e:4475				case TASK_SUSPEND then*/
        case 171:

        /** execute.e:4476					opTASK_SUSPEND()*/
        _67opTASK_SUSPEND();
        goto L3; // [1721] 1903

        /** execute.e:4478				case TASK_YIELD then*/
        case 169:

        /** execute.e:4479					opTASK_YIELD()*/
        _67opTASK_YIELD();
        goto L3; // [1731] 1903

        /** execute.e:4481				case TIME then*/
        case 70:

        /** execute.e:4482					opTIME()*/
        _67opTIME();
        goto L3; // [1741] 1903

        /** execute.e:4484				case TRACE then*/
        case 64:

        /** execute.e:4485					opTRACE()*/
        _67opTRACE();
        goto L3; // [1751] 1903

        /** execute.e:4487				case TYPE_CHECK then*/
        case 65:

        /** execute.e:4488					opTYPE_CHECK()*/
        _67opTYPE_CHECK();
        goto L3; // [1761] 1903

        /** execute.e:4490				case UMINUS then*/
        case 12:

        /** execute.e:4491					opUMINUS()*/
        _67opUMINUS();
        goto L3; // [1771] 1903

        /** execute.e:4493				case UPDATE_GLOBALS then*/
        case 89:

        /** execute.e:4494					opUPDATE_GLOBALS()*/
        _67opUPDATE_GLOBALS();
        goto L3; // [1781] 1903

        /** execute.e:4496				case WHILE then*/
        case 47:

        /** execute.e:4497					opWHILE()*/
        _67opWHILE();
        goto L3; // [1791] 1903

        /** execute.e:4499				case XOR then*/
        case 152:

        /** execute.e:4500					opXOR()*/
        _67opXOR();
        goto L3; // [1801] 1903

        /** execute.e:4502				case XOR_BITS then*/
        case 26:

        /** execute.e:4503					opXOR_BITS()*/
        _67opXOR_BITS();
        goto L3; // [1811] 1903

        /** execute.e:4505				case DELETE_ROUTINE then*/
        case 204:

        /** execute.e:4506					opDELETE_ROUTINE()*/
        _67opDELETE_ROUTINE();
        goto L3; // [1821] 1903

        /** execute.e:4508				case DELETE_OBJECT then*/
        case 205:

        /** execute.e:4509					opDELETE_OBJECT()*/
        _67opDELETE_OBJECT();
        goto L3; // [1831] 1903

        /** execute.e:4511				case REF_TEMP then*/
        case 207:

        /** execute.e:4512					pc += 2*/
        _67pc_64802 = _67pc_64802 + 2;
        goto L3; // [1845] 1903

        /** execute.e:4513				case DEREF_TEMP, NOVALUE_TEMP then*/
        case 208:
        case 209:

        /** execute.e:4514					opDEREF_TEMP()*/
        _67opDEREF_TEMP();
        goto L3; // [1857] 1903

        /** execute.e:4516				case COVERAGE_LINE then*/
        case 210:

        /** execute.e:4517					opCOVERAGE_LINE()*/
        _67opCOVERAGE_LINE();
        goto L3; // [1867] 1903

        /** execute.e:4519				case COVERAGE_ROUTINE then*/
        case 211:

        /** execute.e:4520					opCOVERAGE_ROUTINE()*/
        _67opCOVERAGE_ROUTINE();
        goto L3; // [1877] 1903

        /** execute.e:4522				case SIZEOF then*/
        case 217:

        /** execute.e:4523					opSIZEOF()*/
        _67opSIZEOF();
        goto L3; // [1887] 1903

        /** execute.e:4525				case else*/
        default:

        /** execute.e:4526					RTFatal( sprintf("Unknown opcode: %d", op ) )*/
        _35005 = EPrintf(-9999999, _35004, _op_70151);
        _67RTFatal(_35005);
        _35005 = NOVALUE;
    ;}L3: 

    /** execute.e:4528		end while*/
    goto L1; // [1907] 15
L2: 

    /** execute.e:4529		keep_running = TRUE -- so higher-level do_exec() will keep running*/
    _67keep_running_64809 = _9TRUE_446;

    /** execute.e:4530	end procedure*/
    return;
    ;
}


void _67InitBackEnd()
{
    object _name_70556 = NOVALUE;
    object _len_70557 = NOVALUE;
    object _35016 = NOVALUE;
    object _35015 = NOVALUE;
    object _35014 = NOVALUE;
    object _35013 = NOVALUE;
    object _35012 = NOVALUE;
    object _35010 = NOVALUE;
    object _35009 = NOVALUE;
    object _35008 = NOVALUE;
    object _35007 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:4540		integer len = length(val)*/
    if (IS_SEQUENCE(_67val_64812)){
            _len_70557 = SEQ_PTR(_67val_64812)->length;
    }
    else {
        _len_70557 = 1;
    }

    /** execute.e:4541		val = val & repeat(0, length(SymTab)-length(val))*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _35007 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _35007 = 1;
    }
    if (IS_SEQUENCE(_67val_64812)){
            _35008 = SEQ_PTR(_67val_64812)->length;
    }
    else {
        _35008 = 1;
    }
    _35009 = _35007 - _35008;
    _35007 = NOVALUE;
    _35008 = NOVALUE;
    _35010 = Repeat(0, _35009);
    _35009 = NOVALUE;
    Concat((object_ptr)&_67val_64812, _67val_64812, _35010);
    DeRefDS(_35010);
    _35010 = NOVALUE;

    /** execute.e:4542		for i = len + 1 to length(SymTab) do*/
    _35012 = _len_70557 + 1;
    if (IS_SEQUENCE(_13SymTab_11316)){
            _35013 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _35013 = 1;
    }
    {
        object _i_70566;
        _i_70566 = _35012;
L1: 
        if (_i_70566 > _35013){
            goto L2; // [45] 94
        }

        /** execute.e:4543			val[i] = SymTab[i][S_OBJ] -- might be NOVALUE*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _35014 = (object)*(((s1_ptr)_2)->base + _i_70566);
        _2 = (object)SEQ_PTR(_35014);
        _35015 = (object)*(((s1_ptr)_2)->base + 1);
        _35014 = NOVALUE;
        Ref(_35015);
        _2 = (object)SEQ_PTR(_67val_64812);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_64812 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_70566);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _35015;
        if( _1 != _35015 ){
            DeRef(_1);
        }
        _35015 = NOVALUE;

        /** execute.e:4544			SymTab[i][S_OBJ] = 0*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_70566 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);
        _35016 = NOVALUE;

        /** execute.e:4545		end for*/
        _i_70566 = _i_70566 + 1;
        goto L1; // [89] 52
L2: 
        ;
    }

    /** execute.e:4546	end procedure*/
    DeRef(_35012);
    _35012 = NOVALUE;
    return;
    ;
}


void _67fake_init(object _ignore_70580)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_ignore_70580)) {
        _1 = (object)(DBL_PTR(_ignore_70580)->dbl);
        DeRefDS(_ignore_70580);
        _ignore_70580 = _1;
    }

    /** execute.e:4549		intoptions()*/
    _68intoptions();

    /** execute.e:4550	end procedure*/
    return;
    ;
}


void _67Execute(object _proc_70589, object _start_index_70590)
{
    object _35025 = NOVALUE;
    object _35021 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_proc_70589)) {
        _1 = (object)(DBL_PTR(_proc_70589)->dbl);
        DeRefDS(_proc_70589);
        _proc_70589 = _1;
    }
    if (!IS_ATOM_INT(_start_index_70590)) {
        _1 = (object)(DBL_PTR(_start_index_70590)->dbl);
        DeRefDS(_start_index_70590);
        _start_index_70590 = _1;
    }

    /** execute.e:4555		InitBackEnd()*/
    _67InitBackEnd();

    /** execute.e:4556		if current_task = -1 then*/
    if (_67current_task_64819 != -1)
    goto L1; // [13] 23

    /** execute.e:4557		current_task = 1*/
    _67current_task_64819 = 1;
L1: 

    /** execute.e:4559		if not length(call_stack) then*/
    if (IS_SEQUENCE(_67call_stack_64820)){
            _35021 = SEQ_PTR(_67call_stack_64820)->length;
    }
    else {
        _35021 = 1;
    }
    if (_35021 != 0)
    goto L2; // [30] 40
    _35021 = NOVALUE;

    /** execute.e:4560		call_stack = {proc}*/
    _0 = _67call_stack_64820;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _proc_70589;
    _67call_stack_64820 = MAKE_SEQ(_1);
    DeRefDS(_0);
L2: 

    /** execute.e:4562		if pc = -1 then*/
    if (_67pc_64802 != -1)
    goto L3; // [44] 54

    /** execute.e:4563		pc = start_index*/
    _67pc_64802 = _start_index_70590;
L3: 

    /** execute.e:4565		Code = SymTab[proc][S_CODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _35025 = (object)*(((s1_ptr)_2)->base + _proc_70589);
    DeRef(_12Code_20315);
    _2 = (object)SEQ_PTR(_35025);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    Ref(_12Code_20315);
    _35025 = NOVALUE;

    /** execute.e:4566		do_exec()*/
    _67do_exec();

    /** execute.e:4567		if repl then*/

    /** execute.e:4570	end procedure*/
    return;
    ;
}


void _67BackEnd(object _ignore_70612)
{
    object _0, _1, _2;
    

    /** execute.e:4577		Execute(TopLevelSub, 1)*/
    _67Execute(_12TopLevelSub_20233, 1);

    /** execute.e:4578	end procedure*/
    return;
    ;
}



// 0xC47C70D0
