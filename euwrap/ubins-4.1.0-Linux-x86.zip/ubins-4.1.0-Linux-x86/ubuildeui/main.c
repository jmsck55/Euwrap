// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _69GetSourceName()
{
    object _real_name_72176 = NOVALUE;
    object _fh_72177 = NOVALUE;
    object _has_extension_72179 = NOVALUE;
    object _35975 = NOVALUE;
    object _35973 = NOVALUE;
    object _35972 = NOVALUE;
    object _35969 = NOVALUE;
    object _35968 = NOVALUE;
    object _35967 = NOVALUE;
    object _35966 = NOVALUE;
    object _35965 = NOVALUE;
    object _35964 = NOVALUE;
    object _35961 = NOVALUE;
    object _35960 = NOVALUE;
    object _35958 = NOVALUE;
    object _35957 = NOVALUE;
    object _35956 = NOVALUE;
    object _35955 = NOVALUE;
    object _35954 = NOVALUE;
    object _35953 = NOVALUE;
    object _35950 = NOVALUE;
    object _35949 = NOVALUE;
    object _35947 = NOVALUE;
    object _35946 = NOVALUE;
    object _35943 = NOVALUE;
    object _35942 = NOVALUE;
    object _35939 = NOVALUE;
    object _35938 = NOVALUE;
    object _35937 = NOVALUE;
    object _35935 = NOVALUE;
    object _35934 = NOVALUE;
    object _35933 = NOVALUE;
    object _35932 = NOVALUE;
    object _35931 = NOVALUE;
    object _35930 = NOVALUE;
    object _35929 = NOVALUE;
    object _0, _1, _2;
    

    /** main.e:48		boolean has_extension = FALSE*/
    _has_extension_72179 = _9FALSE_444;

    /** main.e:50		if length(src_name) = 0 and not repl then*/
    if (IS_SEQUENCE(_47src_name_49619)){
            _35929 = SEQ_PTR(_47src_name_49619)->length;
    }
    else {
        _35929 = 1;
    }
    _35930 = (_35929 == 0);
    _35929 = NOVALUE;
    if (_35930 == 0) {
        goto L1; // [19] 45
    }
    _35932 = (0 == 0);
    if (_35932 == 0)
    {
        DeRef(_35932);
        _35932 = NOVALUE;
        goto L1; // [29] 45
    }
    else{
        DeRef(_35932);
        _35932 = NOVALUE;
    }

    /** main.e:51			show_banner()*/
    _47show_banner();

    /** main.e:52			return -2 -- No source file*/
    DeRef(_real_name_72176);
    DeRef(_35930);
    _35930 = NOVALUE;
    return -2;
    goto L2; // [42] 143
L1: 

    /** main.e:53		elsif length(src_name) = 0 and repl then*/
    if (IS_SEQUENCE(_47src_name_49619)){
            _35933 = SEQ_PTR(_47src_name_49619)->length;
    }
    else {
        _35933 = 1;
    }
    _35934 = (_35933 == 0);
    _35933 = NOVALUE;
    if (_35934 == 0) {
        goto L3; // [56] 142
    }
    goto L3; // [63] 142

    /** main.e:54			known_files = append(known_files, "")*/
    RefDS(_22015);
    Append(&_13known_files_11317, _13known_files_11317, _22015);

    /** main.e:55			known_files_hash &= hash(known_files[$], stdhash:HSIEH32)*/
    if (IS_SEQUENCE(_13known_files_11317)){
            _35937 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _35937 = 1;
    }
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _35938 = (object)*(((s1_ptr)_2)->base + _35937);
    _35939 = calc_hash(_35938, -5);
    _35938 = NOVALUE;
    Ref(_35939);
    Append(&_13known_files_hash_11318, _13known_files_hash_11318, _35939);
    DeRef(_35939);
    _35939 = NOVALUE;

    /** main.e:56			real_name = ""*/
    RefDS(_22015);
    DeRef(_real_name_72176);
    _real_name_72176 = _22015;

    /** main.e:57			finished_files &= 0*/
    Append(&_13finished_files_11319, _13finished_files_11319, 0);

    /** main.e:58			file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_13known_files_11317)){
            _35942 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _35942 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _35942;
    _35943 = MAKE_SEQ(_1);
    _35942 = NOVALUE;
    RefDS(_35943);
    Append(&_13file_include_depend_11320, _13file_include_depend_11320, _35943);
    DeRefDS(_35943);
    _35943 = NOVALUE;

    /** main.e:59			return repl_file*/
    DeRefDS(_real_name_72176);
    DeRef(_35930);
    _35930 = NOVALUE;
    DeRef(_35934);
    _35934 = NOVALUE;
    return 5555;
L3: 
L2: 

    /** main.e:62		ifdef WINDOWS then*/

    /** main.e:66		for p = length(src_name) to 1 by -1 do*/
    if (IS_SEQUENCE(_47src_name_49619)){
            _35946 = SEQ_PTR(_47src_name_49619)->length;
    }
    else {
        _35946 = 1;
    }
    {
        object _p_72215;
        _p_72215 = _35946;
L4: 
        if (_p_72215 < 1){
            goto L5; // [152] 216
        }

        /** main.e:67			if src_name[p] = '.' then*/
        _2 = (object)SEQ_PTR(_47src_name_49619);
        _35947 = (object)*(((s1_ptr)_2)->base + _p_72215);
        if (binary_op_a(NOTEQ, _35947, 46)){
            _35947 = NOVALUE;
            goto L6; // [167] 185
        }
        _35947 = NOVALUE;

        /** main.e:68			   has_extension = TRUE*/
        _has_extension_72179 = _9TRUE_446;

        /** main.e:69			   exit*/
        goto L5; // [180] 216
        goto L7; // [182] 209
L6: 

        /** main.e:70			elsif find(src_name[p], SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_47src_name_49619);
        _35949 = (object)*(((s1_ptr)_2)->base + _p_72215);
        _35950 = find_from(_35949, _44SLASH_CHARS_20390, 1);
        _35949 = NOVALUE;
        if (_35950 == 0)
        {
            _35950 = NOVALUE;
            goto L8; // [200] 208
        }
        else{
            _35950 = NOVALUE;
        }

        /** main.e:71			   exit*/
        goto L5; // [205] 216
L8: 
L7: 

        /** main.e:73		end for*/
        _p_72215 = _p_72215 + -1;
        goto L4; // [211] 159
L5: 
        ;
    }

    /** main.e:75		if not has_extension then*/
    if (_has_extension_72179 != 0)
    goto L9; // [218] 323

    /** main.e:79			known_files = append(known_files, "")*/
    RefDS(_22015);
    Append(&_13known_files_11317, _13known_files_11317, _22015);

    /** main.e:82			for i = 1 to length( DEFAULT_EXTS ) do*/
    _35953 = 4;
    {
        object _i_72234;
        _i_72234 = 1;
LA: 
        if (_i_72234 > 4){
            goto LB; // [238] 303
        }

        /** main.e:83				known_files[$] = src_name & DEFAULT_EXTS[i]*/
        if (IS_SEQUENCE(_13known_files_11317)){
                _35954 = SEQ_PTR(_13known_files_11317)->length;
        }
        else {
            _35954 = 1;
        }
        _2 = (object)SEQ_PTR(_44DEFAULT_EXTS_20365);
        _35955 = (object)*(((s1_ptr)_2)->base + _i_72234);
        Concat((object_ptr)&_35956, _47src_name_49619, _35955);
        _35955 = NOVALUE;
        _2 = (object)SEQ_PTR(_13known_files_11317);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13known_files_11317 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _35954);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _35956;
        if( _1 != _35956 ){
            DeRef(_1);
        }
        _35956 = NOVALUE;

        /** main.e:84				real_name = e_path_find(known_files[$])*/
        if (IS_SEQUENCE(_13known_files_11317)){
                _35957 = SEQ_PTR(_13known_files_11317)->length;
        }
        else {
            _35957 = 1;
        }
        _2 = (object)SEQ_PTR(_13known_files_11317);
        _35958 = (object)*(((s1_ptr)_2)->base + _35957);
        Ref(_35958);
        _0 = _real_name_72176;
        _real_name_72176 = _46e_path_find(_35958);
        DeRef(_0);
        _35958 = NOVALUE;

        /** main.e:85				if sequence(real_name) then*/
        _35960 = IS_SEQUENCE(_real_name_72176);
        if (_35960 == 0)
        {
            _35960 = NOVALUE;
            goto LC; // [288] 296
        }
        else{
            _35960 = NOVALUE;
        }

        /** main.e:86					exit*/
        goto LB; // [293] 303
LC: 

        /** main.e:88			end for*/
        _i_72234 = _i_72234 + 1;
        goto LA; // [298] 245
LB: 
        ;
    }

    /** main.e:90			if atom(real_name) then*/
    _35961 = IS_ATOM(_real_name_72176);
    if (_35961 == 0)
    {
        _35961 = NOVALUE;
        goto LD; // [310] 359
    }
    else{
        _35961 = NOVALUE;
    }

    /** main.e:91				return -1*/
    DeRef(_real_name_72176);
    DeRef(_35930);
    _35930 = NOVALUE;
    DeRef(_35934);
    _35934 = NOVALUE;
    return -1;
    goto LD; // [320] 359
L9: 

    /** main.e:94			known_files = append(known_files, src_name)*/
    RefDS(_47src_name_49619);
    Append(&_13known_files_11317, _13known_files_11317, _47src_name_49619);

    /** main.e:95			real_name = e_path_find(src_name)*/
    RefDS(_47src_name_49619);
    _0 = _real_name_72176;
    _real_name_72176 = _46e_path_find(_47src_name_49619);
    DeRef(_0);

    /** main.e:96			if atom(real_name) then*/
    _35964 = IS_ATOM(_real_name_72176);
    if (_35964 == 0)
    {
        _35964 = NOVALUE;
        goto LE; // [348] 358
    }
    else{
        _35964 = NOVALUE;
    }

    /** main.e:97				return -1*/
    DeRef(_real_name_72176);
    DeRef(_35930);
    _35930 = NOVALUE;
    DeRef(_35934);
    _35934 = NOVALUE;
    return -1;
LE: 
LD: 

    /** main.e:100		known_files[$] = canonical_path(real_name,,CORRECT)*/
    if (IS_SEQUENCE(_13known_files_11317)){
            _35965 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _35965 = 1;
    }
    Ref(_real_name_72176);
    _35966 = _14canonical_path(_real_name_72176, 0, 2);
    _2 = (object)SEQ_PTR(_13known_files_11317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13known_files_11317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _35965);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35966;
    if( _1 != _35966 ){
        DeRef(_1);
    }
    _35966 = NOVALUE;

    /** main.e:101		known_files_hash &= hash(known_files[$], stdhash:HSIEH32)*/
    if (IS_SEQUENCE(_13known_files_11317)){
            _35967 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _35967 = 1;
    }
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _35968 = (object)*(((s1_ptr)_2)->base + _35967);
    _35969 = calc_hash(_35968, -5);
    _35968 = NOVALUE;
    Ref(_35969);
    Append(&_13known_files_hash_11318, _13known_files_hash_11318, _35969);
    DeRef(_35969);
    _35969 = NOVALUE;

    /** main.e:102		finished_files &= 0*/
    Append(&_13finished_files_11319, _13finished_files_11319, 0);

    /** main.e:103		file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_13known_files_11317)){
            _35972 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _35972 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _35972;
    _35973 = MAKE_SEQ(_1);
    _35972 = NOVALUE;
    RefDS(_35973);
    Append(&_13file_include_depend_11320, _13file_include_depend_11320, _35973);
    DeRefDS(_35973);
    _35973 = NOVALUE;

    /** main.e:105		if file_exists(real_name) then*/
    Ref(_real_name_72176);
    _35975 = _14file_exists(_real_name_72176);
    if (_35975 == 0) {
        DeRef(_35975);
        _35975 = NOVALUE;
        goto LF; // [438] 462
    }
    else {
        if (!IS_ATOM_INT(_35975) && DBL_PTR(_35975)->dbl == 0.0){
            DeRef(_35975);
            _35975 = NOVALUE;
            goto LF; // [438] 462
        }
        DeRef(_35975);
        _35975 = NOVALUE;
    }
    DeRef(_35975);
    _35975 = NOVALUE;

    /** main.e:106			real_name = maybe_preprocess(real_name)*/
    Ref(_real_name_72176);
    _0 = _real_name_72176;
    _real_name_72176 = _63maybe_preprocess(_real_name_72176);
    DeRef(_0);

    /** main.e:107			fh = open_locked(real_name)*/
    Ref(_real_name_72176);
    _fh_72177 = _13open_locked(_real_name_72176);
    if (!IS_ATOM_INT(_fh_72177)) {
        _1 = (object)(DBL_PTR(_fh_72177)->dbl);
        DeRefDS(_fh_72177);
        _fh_72177 = _1;
    }

    /** main.e:108			return fh*/
    DeRef(_real_name_72176);
    DeRef(_35930);
    _35930 = NOVALUE;
    DeRef(_35934);
    _35934 = NOVALUE;
    return _fh_72177;
LF: 

    /** main.e:111		return -1*/
    DeRef(_real_name_72176);
    DeRef(_35930);
    _35930 = NOVALUE;
    DeRef(_35934);
    _35934 = NOVALUE;
    return -1;
    ;
}


void _69main()
{
    object _argc_72303 = NOVALUE;
    object _argv_72304 = NOVALUE;
    object _36005 = NOVALUE;
    object _36004 = NOVALUE;
    object _36001 = NOVALUE;
    object _35999 = NOVALUE;
    object _35997 = NOVALUE;
    object _35996 = NOVALUE;
    object _35995 = NOVALUE;
    object _35994 = NOVALUE;
    object _35993 = NOVALUE;
    object _35992 = NOVALUE;
    object _35991 = NOVALUE;
    object _35990 = NOVALUE;
    object _35986 = NOVALUE;
    object _0, _1, _2;
    

    /** main.e:131		argv = command_line()*/
    DeRef(_argv_72304);
    _argv_72304 = Command_Line();

    /** main.e:133		if BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** main.e:134			argv = extract_options(argv)*/
    RefDS(_argv_72304);
    _0 = _argv_72304;
    _argv_72304 = _2extract_options(_argv_72304);
    DeRefDS(_0);
L1: 

    /** main.e:137		argc = length(argv)*/
    if (IS_SEQUENCE(_argv_72304)){
            _argc_72303 = SEQ_PTR(_argv_72304)->length;
    }
    else {
        _argc_72303 = 1;
    }

    /** main.e:139		Argv = argv*/
    RefDS(_argv_72304);
    DeRef(_12Argv_20237);
    _12Argv_20237 = _argv_72304;

    /** main.e:140		Argc = argc*/
    _12Argc_20236 = _argc_72303;

    /** main.e:142		TempErrName = "ex.err"*/
    RefDS(_31827);
    DeRefi(_49TempErrName_49259);
    _49TempErrName_49259 = _31827;

    /** main.e:143		TempWarningName = STDERR*/
    DeRef(_12TempWarningName_20240);
    _12TempWarningName_20240 = 2;

    /** main.e:144		display_warnings = 1*/
    _49display_warnings_49260 = 1;

    /** main.e:146		InitGlobals()*/
    _43InitGlobals();

    /** main.e:148		if TRANSLATE or BIND or INTERPRET then*/
    if (_12TRANSLATE_19834 != 0) {
        _35986 = 1;
        goto L2; // [69] 79
    }
    _35986 = (_12BIND_19837 != 0);
L2: 
    if (_35986 != 0) {
        goto L3; // [79] 90
    }
    if (_12INTERPRET_19831 == 0)
    {
        goto L4; // [86] 96
    }
    else{
    }
L3: 

    /** main.e:149			InitBackEnd(0)*/
    _2InitBackEnd(0);
L4: 

    /** main.e:152		src_file = GetSourceName()*/
    _0 = _69GetSourceName();
    _12src_file_20348 = _0;
    if (!IS_ATOM_INT(_12src_file_20348)) {
        _1 = (object)(DBL_PTR(_12src_file_20348)->dbl);
        DeRefDS(_12src_file_20348);
        _12src_file_20348 = _1;
    }

    /** main.e:154		if src_file = -1 then*/
    if (_12src_file_20348 != -1)
    goto L5; // [107] 185

    /** main.e:156			screen_output(STDERR, GetMsgText(CANT_OPEN_1, 0, {known_files[$]}))*/
    if (IS_SEQUENCE(_13known_files_11317)){
            _35990 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _35990 = 1;
    }
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _35991 = (object)*(((s1_ptr)_2)->base + _35990);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_35991);
    ((intptr_t*)_2)[1] = _35991;
    _35992 = MAKE_SEQ(_1);
    _35991 = NOVALUE;
    _35993 = _30GetMsgText(51, 0, _35992);
    _35992 = NOVALUE;
    _49screen_output(2, _35993);
    _35993 = NOVALUE;

    /** main.e:157			if not batch_job and not test_only then*/
    _35994 = (_12batch_job_20239 == 0);
    if (_35994 == 0) {
        goto L6; // [147] 177
    }
    _35996 = (_12test_only_20238 == 0);
    if (_35996 == 0)
    {
        DeRef(_35996);
        _35996 = NOVALUE;
        goto L6; // [157] 177
    }
    else{
        DeRef(_35996);
        _35996 = NOVALUE;
    }

    /** main.e:158				maybe_any_key(GetMsgText(PAUSED_PRESS_ANY_KEY,0), STDERR)*/
    RefDS(_22015);
    _35997 = _30GetMsgText(277, 0, _22015);
    _38maybe_any_key(_35997, 2);
    _35997 = NOVALUE;
L6: 

    /** main.e:160			Cleanup(1)*/
    _49Cleanup(1);
    goto L7; // [182] 230
L5: 

    /** main.e:162		elsif src_file >= 0 then*/
    if (_12src_file_20348 < 0)
    goto L8; // [189] 229

    /** main.e:163			main_path = known_files[$]*/
    if (IS_SEQUENCE(_13known_files_11317)){
            _35999 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _35999 = 1;
    }
    DeRef(_12main_path_20347);
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _12main_path_20347 = (object)*(((s1_ptr)_2)->base + _35999);
    Ref(_12main_path_20347);

    /** main.e:164			if length(main_path) = 0 then*/
    if (IS_SEQUENCE(_12main_path_20347)){
            _36001 = SEQ_PTR(_12main_path_20347)->length;
    }
    else {
        _36001 = 1;
    }
    if (_36001 != 0)
    goto L9; // [213] 228

    /** main.e:165				main_path = '.' & SLASH*/
    Concat((object_ptr)&_12main_path_20347, 46, 47);
L9: 
L8: 
L7: 

    /** main.e:171		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto LA; // [234] 243
    }
    else{
    }

    /** main.e:172			InitBackEnd(1)*/
    _2InitBackEnd(1);
LA: 

    /** main.e:175		CheckPlatform()*/
    _2CheckPlatform();

    /** main.e:177		InitSymTab()*/
    _53InitSymTab();

    /** main.e:178		InitEmit()*/
    _45InitEmit();

    /** main.e:179		InitLex()*/
    _61InitLex();

    /** main.e:180		InitParser()*/
    _43InitParser();

    /** main.e:184		eu_namespace()*/
    _61eu_namespace();

    /** main.e:186		ifdef TRANSLATOR then*/

    /** main.e:197		main_file()*/
    _61main_file();

    /** main.e:199		check_coverage()*/
    _50check_coverage();

    /** main.e:201		parser()*/
    _43parser();

    /** main.e:203		init_coverage()*/
    _50init_coverage();

    /** main.e:206		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto LB; // [289] 300
    }
    else{
    }

    /** main.e:207			BackEnd(0) -- translate IL to C*/
    _2BackEnd(0);
    goto LC; // [297] 387
LB: 

    /** main.e:209		elsif BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto LD; // [304] 314
    }
    else{
    }

    /** main.e:210			OutputIL()*/
    _2OutputIL();
    goto LC; // [311] 387
LD: 

    /** main.e:212		elsif INTERPRET and not test_only then*/
    if (_12INTERPRET_19831 == 0) {
        goto LE; // [318] 386
    }
    _36005 = (_12test_only_20238 == 0);
    if (_36005 == 0)
    {
        DeRef(_36005);
        _36005 = NOVALUE;
        goto LE; // [328] 386
    }
    else{
        DeRef(_36005);
        _36005 = NOVALUE;
    }

    /** main.e:213			ifdef not STDDEBUG then*/

    /** main.e:214				BackEnd(0) -- execute IL using Euphoria-coded back-end*/
    _2BackEnd(0);

    /** main.e:216			while repl do*/
LE: 
LC: 

    /** main.e:225		Cleanup(0) -- does warnings*/
    _49Cleanup(0);

    /** main.e:226	end procedure*/
    DeRef(_argv_72304);
    DeRef(_35994);
    _35994 = NOVALUE;
    return;
    ;
}



// 0xCD8EAC78
