// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _46exe_path()
{
    object _25830 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:70		if sequence(exe_path_cache) then*/
    _25830 = IS_SEQUENCE(_46exe_path_cache_50388);
    if (_25830 == 0)
    {
        _25830 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25830 = NOVALUE;
    }

    /** pathopen.e:71			return exe_path_cache*/
    Ref(_46exe_path_cache_50388);
    return _46exe_path_cache_50388;
L1: 

    /** pathopen.e:74		exe_path_cache = command_line()*/
    DeRef(_46exe_path_cache_50388);
    _46exe_path_cache_50388 = Command_Line();

    /** pathopen.e:75		exe_path_cache = exe_path_cache[1]*/
    _0 = _46exe_path_cache_50388;
    _2 = (object)SEQ_PTR(_46exe_path_cache_50388);
    _46exe_path_cache_50388 = (object)*(((s1_ptr)_2)->base + 1);
    RefDS(_46exe_path_cache_50388);
    DeRefDS(_0);

    /** pathopen.e:77		return exe_path_cache*/
    RefDS(_46exe_path_cache_50388);
    return _46exe_path_cache_50388;
    ;
}


object _46check_cache(object _env_50400, object _inc_path_50401)
{
    object _delim_50402 = NOVALUE;
    object _pos_50403 = NOVALUE;
    object _25878 = NOVALUE;
    object _25877 = NOVALUE;
    object _25876 = NOVALUE;
    object _25875 = NOVALUE;
    object _25873 = NOVALUE;
    object _25872 = NOVALUE;
    object _25871 = NOVALUE;
    object _25870 = NOVALUE;
    object _25869 = NOVALUE;
    object _25868 = NOVALUE;
    object _25867 = NOVALUE;
    object _25866 = NOVALUE;
    object _25865 = NOVALUE;
    object _25861 = NOVALUE;
    object _25860 = NOVALUE;
    object _25859 = NOVALUE;
    object _25858 = NOVALUE;
    object _25857 = NOVALUE;
    object _25856 = NOVALUE;
    object _25855 = NOVALUE;
    object _25854 = NOVALUE;
    object _25852 = NOVALUE;
    object _25851 = NOVALUE;
    object _25850 = NOVALUE;
    object _25849 = NOVALUE;
    object _25848 = NOVALUE;
    object _25847 = NOVALUE;
    object _25845 = NOVALUE;
    object _25844 = NOVALUE;
    object _25843 = NOVALUE;
    object _25842 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:83		if not num_var then -- first time the var is accessed, add cache entry*/
    if (_46num_var_50377 != 0)
    goto L1; // [9] 86

    /** pathopen.e:84			cache_vars = append(cache_vars,env)*/
    RefDS(_env_50400);
    Append(&_46cache_vars_50378, _46cache_vars_50378, _env_50400);

    /** pathopen.e:85			cache_strings = append(cache_strings,inc_path)*/
    RefDS(_inc_path_50401);
    Append(&_46cache_strings_50379, _46cache_strings_50379, _inc_path_50401);

    /** pathopen.e:86			cache_substrings = append(cache_substrings,{})*/
    RefDS(_22015);
    Append(&_46cache_substrings_50380, _46cache_substrings_50380, _22015);

    /** pathopen.e:87			cache_starts = append(cache_starts,{})*/
    RefDS(_22015);
    Append(&_46cache_starts_50381, _46cache_starts_50381, _22015);

    /** pathopen.e:88			cache_ends = append(cache_ends,{})*/
    RefDS(_22015);
    Append(&_46cache_ends_50382, _46cache_ends_50382, _22015);

    /** pathopen.e:89			ifdef WINDOWS then*/

    /** pathopen.e:92			num_var = length(cache_vars)*/
    if (IS_SEQUENCE(_46cache_vars_50378)){
            _46num_var_50377 = SEQ_PTR(_46cache_vars_50378)->length;
    }
    else {
        _46num_var_50377 = 1;
    }

    /** pathopen.e:93			cache_complete &= 0*/
    Append(&_46cache_complete_50384, _46cache_complete_50384, 0);

    /** pathopen.e:94			cache_delims &= 0*/
    Append(&_46cache_delims_50385, _46cache_delims_50385, 0);

    /** pathopen.e:95			return 0*/
    DeRefDSi(_env_50400);
    DeRefDSi(_inc_path_50401);
    return 0;
    goto L2; // [83] 425
L1: 

    /** pathopen.e:97			if compare(inc_path,cache_strings[num_var]) then*/
    _2 = (object)SEQ_PTR(_46cache_strings_50379);
    _25842 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
    if (IS_ATOM_INT(_inc_path_50401) && IS_ATOM_INT(_25842)){
        _25843 = (_inc_path_50401 < _25842) ? -1 : (_inc_path_50401 > _25842);
    }
    else{
        _25843 = compare(_inc_path_50401, _25842);
    }
    _25842 = NOVALUE;
    if (_25843 == 0)
    {
        _25843 = NOVALUE;
        goto L3; // [100] 424
    }
    else{
        _25843 = NOVALUE;
    }

    /** pathopen.e:98				cache_strings[num_var] = inc_path*/
    RefDS(_inc_path_50401);
    _2 = (object)SEQ_PTR(_46cache_strings_50379);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _46cache_strings_50379 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _46num_var_50377);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _inc_path_50401;
    DeRefDS(_1);

    /** pathopen.e:99				cache_complete[num_var] = 0*/
    _2 = (object)SEQ_PTR(_46cache_complete_50384);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _46cache_complete_50384 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _46num_var_50377);
    *(intptr_t *)_2 = 0;

    /** pathopen.e:100				if match(cache_strings[num_var],inc_path)!=1 then -- try to salvage what we can*/
    _2 = (object)SEQ_PTR(_46cache_strings_50379);
    _25844 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
    _25845 = e_match_from(_25844, _inc_path_50401, 1);
    _25844 = NOVALUE;
    if (_25845 == 1)
    goto L4; // [138] 423

    /** pathopen.e:101					pos = -1*/
    _pos_50403 = -1;

    /** pathopen.e:102					for i=1 to length(cache_strings[num_var]) do*/
    _2 = (object)SEQ_PTR(_46cache_strings_50379);
    _25847 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
    if (IS_SEQUENCE(_25847)){
            _25848 = SEQ_PTR(_25847)->length;
    }
    else {
        _25848 = 1;
    }
    _25847 = NOVALUE;
    {
        object _i_50423;
        _i_50423 = 1;
L5: 
        if (_i_50423 > _25848){
            goto L6; // [160] 422
        }

        /** pathopen.e:103						if cache_ends[num_var][i] > length(inc_path) or */
        _2 = (object)SEQ_PTR(_46cache_ends_50382);
        _25849 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
        _2 = (object)SEQ_PTR(_25849);
        _25850 = (object)*(((s1_ptr)_2)->base + _i_50423);
        _25849 = NOVALUE;
        if (IS_SEQUENCE(_inc_path_50401)){
                _25851 = SEQ_PTR(_inc_path_50401)->length;
        }
        else {
            _25851 = 1;
        }
        if (IS_ATOM_INT(_25850)) {
            _25852 = (_25850 > _25851);
        }
        else {
            _25852 = binary_op(GREATER, _25850, _25851);
        }
        _25850 = NOVALUE;
        _25851 = NOVALUE;
        if (IS_ATOM_INT(_25852)) {
            if (_25852 != 0) {
                goto L7; // [188] 242
            }
        }
        else {
            if (DBL_PTR(_25852)->dbl != 0.0) {
                goto L7; // [188] 242
            }
        }
        _2 = (object)SEQ_PTR(_46cache_substrings_50380);
        _25854 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
        _2 = (object)SEQ_PTR(_25854);
        _25855 = (object)*(((s1_ptr)_2)->base + _i_50423);
        _25854 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_starts_50381);
        _25856 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
        _2 = (object)SEQ_PTR(_25856);
        _25857 = (object)*(((s1_ptr)_2)->base + _i_50423);
        _25856 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_ends_50382);
        _25858 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
        _2 = (object)SEQ_PTR(_25858);
        _25859 = (object)*(((s1_ptr)_2)->base + _i_50423);
        _25858 = NOVALUE;
        rhs_slice_target = (object_ptr)&_25860;
        RHS_Slice(_inc_path_50401, _25857, _25859);
        if (IS_ATOM_INT(_25855) && IS_ATOM_INT(_25860)){
            _25861 = (_25855 < _25860) ? -1 : (_25855 > _25860);
        }
        else{
            _25861 = compare(_25855, _25860);
        }
        _25855 = NOVALUE;
        DeRefDS(_25860);
        _25860 = NOVALUE;
        if (_25861 == 0)
        {
            _25861 = NOVALUE;
            goto L8; // [238] 253
        }
        else{
            _25861 = NOVALUE;
        }
L7: 

        /** pathopen.e:107							pos = i-1*/
        _pos_50403 = _i_50423 - 1;

        /** pathopen.e:108							exit*/
        goto L6; // [250] 422
L8: 

        /** pathopen.e:110						if pos = 0 then*/
        if (_pos_50403 != 0)
        goto L9; // [255] 268

        /** pathopen.e:111							return 0*/
        DeRefDSi(_env_50400);
        DeRefDSi(_inc_path_50401);
        _25857 = NOVALUE;
        _25847 = NOVALUE;
        DeRef(_25852);
        _25852 = NOVALUE;
        _25859 = NOVALUE;
        return 0;
        goto LA; // [265] 415
L9: 

        /** pathopen.e:112						elsif pos >0 then -- crop cache data*/
        if (_pos_50403 <= 0)
        goto LB; // [270] 414

        /** pathopen.e:113							cache_substrings[num_var] = cache_substrings[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_46cache_substrings_50380);
        _25865 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
        rhs_slice_target = (object_ptr)&_25866;
        RHS_Slice(_25865, 1, _pos_50403);
        _25865 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_substrings_50380);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_substrings_50380 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50377);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _25866;
        if( _1 != _25866 ){
            DeRefDS(_1);
        }
        _25866 = NOVALUE;

        /** pathopen.e:114							cache_starts[num_var] = cache_starts[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_46cache_starts_50381);
        _25867 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
        rhs_slice_target = (object_ptr)&_25868;
        RHS_Slice(_25867, 1, _pos_50403);
        _25867 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_starts_50381);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_starts_50381 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50377);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _25868;
        if( _1 != _25868 ){
            DeRef(_1);
        }
        _25868 = NOVALUE;

        /** pathopen.e:115							cache_ends[num_var] = cache_ends[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_46cache_ends_50382);
        _25869 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
        rhs_slice_target = (object_ptr)&_25870;
        RHS_Slice(_25869, 1, _pos_50403);
        _25869 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_ends_50382);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_ends_50382 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50377);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _25870;
        if( _1 != _25870 ){
            DeRef(_1);
        }
        _25870 = NOVALUE;

        /** pathopen.e:116							ifdef WINDOWS then*/

        /** pathopen.e:119							delim = cache_ends[num_var][$]+1*/
        _2 = (object)SEQ_PTR(_46cache_ends_50382);
        _25871 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
        if (IS_SEQUENCE(_25871)){
                _25872 = SEQ_PTR(_25871)->length;
        }
        else {
            _25872 = 1;
        }
        _2 = (object)SEQ_PTR(_25871);
        _25873 = (object)*(((s1_ptr)_2)->base + _25872);
        _25871 = NOVALUE;
        if (IS_ATOM_INT(_25873)) {
            _delim_50402 = _25873 + 1;
        }
        else
        { // coercing _delim_50402 to an integer 1
            _delim_50402 = 1+(object)(DBL_PTR(_25873)->dbl);
            if( !IS_ATOM_INT(_delim_50402) ){
                _delim_50402 = (object)DBL_PTR(_delim_50402)->dbl;
            }
        }
        _25873 = NOVALUE;

        /** pathopen.e:120							while delim <= length(inc_path) and delim != PATH_SEPARATOR do*/
LC: 
        if (IS_SEQUENCE(_inc_path_50401)){
                _25875 = SEQ_PTR(_inc_path_50401)->length;
        }
        else {
            _25875 = 1;
        }
        _25876 = (_delim_50402 <= _25875);
        _25875 = NOVALUE;
        if (_25876 == 0) {
            goto LD; // [378] 403
        }
        _25878 = (_delim_50402 != 58);
        if (_25878 == 0)
        {
            DeRef(_25878);
            _25878 = NOVALUE;
            goto LD; // [389] 403
        }
        else{
            DeRef(_25878);
            _25878 = NOVALUE;
        }

        /** pathopen.e:121								delim+=1*/
        _delim_50402 = _delim_50402 + 1;

        /** pathopen.e:122							end while*/
        goto LC; // [400] 371
LD: 

        /** pathopen.e:123							cache_delims[num_var] = delim*/
        _2 = (object)SEQ_PTR(_46cache_delims_50385);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_delims_50385 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50377);
        *(intptr_t *)_2 = _delim_50402;
LB: 
LA: 

        /** pathopen.e:125					end for*/
        _i_50423 = _i_50423 + 1;
        goto L5; // [417] 167
L6: 
        ;
    }
L4: 
L3: 
L2: 

    /** pathopen.e:129		return 1*/
    DeRefDSi(_env_50400);
    DeRefDSi(_inc_path_50401);
    DeRef(_25876);
    _25876 = NOVALUE;
    _25857 = NOVALUE;
    _25847 = NOVALUE;
    DeRef(_25852);
    _25852 = NOVALUE;
    _25859 = NOVALUE;
    return 1;
    ;
}


object _46get_conf_dirs()
{
    object _delimiter_50464 = NOVALUE;
    object _dirs_50465 = NOVALUE;
    object _25883 = NOVALUE;
    object _25881 = NOVALUE;
    object _25880 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:136		ifdef UNIX then*/

    /** pathopen.e:137			delimiter = ':'*/
    _delimiter_50464 = 58;

    /** pathopen.e:142		dirs = ""*/
    RefDS(_22015);
    DeRef(_dirs_50465);
    _dirs_50465 = _22015;

    /** pathopen.e:143		for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_46config_inc_paths_50386)){
            _25880 = SEQ_PTR(_46config_inc_paths_50386)->length;
    }
    else {
        _25880 = 1;
    }
    {
        object _i_50467;
        _i_50467 = 1;
L1: 
        if (_i_50467 > _25880){
            goto L2; // [22] 68
        }

        /** pathopen.e:144			dirs &= config_inc_paths[i]*/
        _2 = (object)SEQ_PTR(_46config_inc_paths_50386);
        _25881 = (object)*(((s1_ptr)_2)->base + _i_50467);
        Concat((object_ptr)&_dirs_50465, _dirs_50465, _25881);
        _25881 = NOVALUE;

        /** pathopen.e:145			if i != length(config_inc_paths) then*/
        if (IS_SEQUENCE(_46config_inc_paths_50386)){
                _25883 = SEQ_PTR(_46config_inc_paths_50386)->length;
        }
        else {
            _25883 = 1;
        }
        if (_i_50467 == _25883)
        goto L3; // [48] 61

        /** pathopen.e:146				dirs &= delimiter*/
        Append(&_dirs_50465, _dirs_50465, _delimiter_50464);
L3: 

        /** pathopen.e:148		end for*/
        _i_50467 = _i_50467 + 1;
        goto L1; // [63] 29
L2: 
        ;
    }

    /** pathopen.e:150		return dirs*/
    return _dirs_50465;
    ;
}


object _46strip_file_from_path(object _full_path_50477)
{
    object _25889 = NOVALUE;
    object _25887 = NOVALUE;
    object _25886 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:156		for i = length(full_path) to 1 by -1 do*/
    if (IS_SEQUENCE(_full_path_50477)){
            _25886 = SEQ_PTR(_full_path_50477)->length;
    }
    else {
        _25886 = 1;
    }
    {
        object _i_50479;
        _i_50479 = _25886;
L1: 
        if (_i_50479 < 1){
            goto L2; // [8] 46
        }

        /** pathopen.e:157			if full_path[i] = SLASH then*/
        _2 = (object)SEQ_PTR(_full_path_50477);
        _25887 = (object)*(((s1_ptr)_2)->base + _i_50479);
        if (binary_op_a(NOTEQ, _25887, 47)){
            _25887 = NOVALUE;
            goto L3; // [23] 39
        }
        _25887 = NOVALUE;

        /** pathopen.e:158				return full_path[1..i]*/
        rhs_slice_target = (object_ptr)&_25889;
        RHS_Slice(_full_path_50477, 1, _i_50479);
        DeRefDS(_full_path_50477);
        return _25889;
L3: 

        /** pathopen.e:160		end for*/
        _i_50479 = _i_50479 + -1;
        goto L1; // [41] 15
L2: 
        ;
    }

    /** pathopen.e:162		return ""*/
    RefDS(_22015);
    DeRefDS(_full_path_50477);
    DeRef(_25889);
    _25889 = NOVALUE;
    return _22015;
    ;
}


object _46expand_path(object _path_50488, object _prefix_50489)
{
    object _absolute_50490 = NOVALUE;
    object _home_50494 = NOVALUE;
    object _25913 = NOVALUE;
    object _25912 = NOVALUE;
    object _25911 = NOVALUE;
    object _25910 = NOVALUE;
    object _25909 = NOVALUE;
    object _25908 = NOVALUE;
    object _25904 = NOVALUE;
    object _25902 = NOVALUE;
    object _25901 = NOVALUE;
    object _25900 = NOVALUE;
    object _25899 = NOVALUE;
    object _25898 = NOVALUE;
    object _25895 = NOVALUE;
    object _25894 = NOVALUE;
    object _25893 = NOVALUE;
    object _25892 = NOVALUE;
    object _25890 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:169		if not length(path) then*/
    if (IS_SEQUENCE(_path_50488)){
            _25890 = SEQ_PTR(_path_50488)->length;
    }
    else {
        _25890 = 1;
    }
    if (_25890 != 0)
    goto L1; // [10] 22
    _25890 = NOVALUE;

    /** pathopen.e:170			return pwd*/
    RefDS(_46pwd_50389);
    DeRefDS(_path_50488);
    DeRefDS(_prefix_50489);
    DeRefi(_home_50494);
    return _46pwd_50389;
L1: 

    /** pathopen.e:174		ifdef UNIX then*/

    /** pathopen.e:175			object home*/

    /** pathopen.e:176			if length(path) and path[1] = '~' then*/
    if (IS_SEQUENCE(_path_50488)){
            _25892 = SEQ_PTR(_path_50488)->length;
    }
    else {
        _25892 = 1;
    }
    if (_25892 == 0) {
        goto L2; // [31] 84
    }
    _2 = (object)SEQ_PTR(_path_50488);
    _25894 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25894)) {
        _25895 = (_25894 == 126);
    }
    else {
        _25895 = binary_op(EQUALS, _25894, 126);
    }
    _25894 = NOVALUE;
    if (_25895 == 0) {
        DeRef(_25895);
        _25895 = NOVALUE;
        goto L2; // [44] 84
    }
    else {
        if (!IS_ATOM_INT(_25895) && DBL_PTR(_25895)->dbl == 0.0){
            DeRef(_25895);
            _25895 = NOVALUE;
            goto L2; // [44] 84
        }
        DeRef(_25895);
        _25895 = NOVALUE;
    }
    DeRef(_25895);
    _25895 = NOVALUE;

    /** pathopen.e:177				home = getenv("HOME")*/
    DeRefi(_home_50494);
    _home_50494 = EGetEnv(_25896);

    /** pathopen.e:178				if sequence(home) and length(home) then*/
    _25898 = IS_SEQUENCE(_home_50494);
    if (_25898 == 0) {
        goto L3; // [57] 83
    }
    if (IS_SEQUENCE(_home_50494)){
            _25900 = SEQ_PTR(_home_50494)->length;
    }
    else {
        _25900 = 1;
    }
    if (_25900 == 0)
    {
        _25900 = NOVALUE;
        goto L3; // [65] 83
    }
    else{
        _25900 = NOVALUE;
    }

    /** pathopen.e:179					path = home & path[2..$]*/
    if (IS_SEQUENCE(_path_50488)){
            _25901 = SEQ_PTR(_path_50488)->length;
    }
    else {
        _25901 = 1;
    }
    rhs_slice_target = (object_ptr)&_25902;
    RHS_Slice(_path_50488, 2, _25901);
    if (IS_SEQUENCE(_home_50494) && IS_ATOM(_25902)) {
    }
    else if (IS_ATOM(_home_50494) && IS_SEQUENCE(_25902)) {
        Ref(_home_50494);
        Prepend(&_path_50488, _25902, _home_50494);
    }
    else {
        Concat((object_ptr)&_path_50488, _home_50494, _25902);
    }
    DeRefDS(_25902);
    _25902 = NOVALUE;
L3: 
L2: 

    /** pathopen.e:183			absolute = find(path[1], SLASH_CHARS)*/
    _2 = (object)SEQ_PTR(_path_50488);
    _25904 = (object)*(((s1_ptr)_2)->base + 1);
    _absolute_50490 = find_from(_25904, _44SLASH_CHARS_20390, 1);
    _25904 = NOVALUE;

    /** pathopen.e:188		if not absolute then*/
    if (_absolute_50490 != 0)
    goto L4; // [101] 115

    /** pathopen.e:189			path = prefix & SLASH & path*/
    {
        object concat_list[3];

        concat_list[0] = _path_50488;
        concat_list[1] = 47;
        concat_list[2] = _prefix_50489;
        Concat_N((object_ptr)&_path_50488, concat_list, 3);
    }
L4: 

    /** pathopen.e:192		if length(path) and not find(path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_path_50488)){
            _25908 = SEQ_PTR(_path_50488)->length;
    }
    else {
        _25908 = 1;
    }
    if (_25908 == 0) {
        goto L5; // [120] 154
    }
    if (IS_SEQUENCE(_path_50488)){
            _25910 = SEQ_PTR(_path_50488)->length;
    }
    else {
        _25910 = 1;
    }
    _2 = (object)SEQ_PTR(_path_50488);
    _25911 = (object)*(((s1_ptr)_2)->base + _25910);
    _25912 = find_from(_25911, _44SLASH_CHARS_20390, 1);
    _25911 = NOVALUE;
    _25913 = (_25912 == 0);
    _25912 = NOVALUE;
    if (_25913 == 0)
    {
        DeRef(_25913);
        _25913 = NOVALUE;
        goto L5; // [142] 154
    }
    else{
        DeRef(_25913);
        _25913 = NOVALUE;
    }

    /** pathopen.e:193			path &= SLASH*/
    Append(&_path_50488, _path_50488, 47);
L5: 

    /** pathopen.e:196		return path*/
    DeRefDS(_prefix_50489);
    DeRefi(_home_50494);
    return _path_50488;
    ;
}


void _46add_include_directory(object _path_50528)
{
    object _25916 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:200		path = expand_path( path, pwd )*/
    RefDS(_path_50528);
    RefDS(_46pwd_50389);
    _0 = _path_50528;
    _path_50528 = _46expand_path(_path_50528, _46pwd_50389);
    DeRefDS(_0);

    /** pathopen.e:202		if not find( path, config_inc_paths ) then*/
    _25916 = find_from(_path_50528, _46config_inc_paths_50386, 1);
    if (_25916 != 0)
    goto L1; // [23] 35
    _25916 = NOVALUE;

    /** pathopen.e:203			config_inc_paths = append( config_inc_paths, path )*/
    RefDS(_path_50528);
    Append(&_46config_inc_paths_50386, _46config_inc_paths_50386, _path_50528);
L1: 

    /** pathopen.e:205	end procedure*/
    DeRefDS(_path_50528);
    return;
    ;
}


object _46load_euphoria_config(object _file_50537)
{
    object _fn_50538 = NOVALUE;
    object _in_50539 = NOVALUE;
    object _spos_50540 = NOVALUE;
    object _epos_50541 = NOVALUE;
    object _conf_path_50542 = NOVALUE;
    object _new_args_50543 = NOVALUE;
    object _arg_50544 = NOVALUE;
    object _parm_50545 = NOVALUE;
    object _section_50546 = NOVALUE;
    object _needed_50643 = NOVALUE;
    object _26013 = NOVALUE;
    object _26012 = NOVALUE;
    object _26009 = NOVALUE;
    object _26007 = NOVALUE;
    object _26006 = NOVALUE;
    object _25984 = NOVALUE;
    object _25981 = NOVALUE;
    object _25980 = NOVALUE;
    object _25978 = NOVALUE;
    object _25974 = NOVALUE;
    object _25972 = NOVALUE;
    object _25970 = NOVALUE;
    object _25968 = NOVALUE;
    object _25966 = NOVALUE;
    object _25964 = NOVALUE;
    object _25963 = NOVALUE;
    object _25962 = NOVALUE;
    object _25961 = NOVALUE;
    object _25960 = NOVALUE;
    object _25959 = NOVALUE;
    object _25958 = NOVALUE;
    object _25957 = NOVALUE;
    object _25955 = NOVALUE;
    object _25953 = NOVALUE;
    object _25951 = NOVALUE;
    object _25947 = NOVALUE;
    object _25946 = NOVALUE;
    object _25941 = NOVALUE;
    object _25939 = NOVALUE;
    object _25937 = NOVALUE;
    object _25936 = NOVALUE;
    object _25928 = NOVALUE;
    object _25922 = NOVALUE;
    object _25921 = NOVALUE;
    object _25919 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:213		sequence new_args = {}*/
    RefDS(_22015);
    DeRef(_new_args_50543);
    _new_args_50543 = _22015;

    /** pathopen.e:219		if file_type(file) = FILETYPE_DIRECTORY then*/
    RefDS(_file_50537);
    _25919 = _14file_type(_file_50537);
    if (binary_op_a(NOTEQ, _25919, 2)){
        DeRef(_25919);
        _25919 = NOVALUE;
        goto L1; // [18] 53
    }
    DeRef(_25919);
    _25919 = NOVALUE;

    /** pathopen.e:220			if file[$] != SLASH then*/
    if (IS_SEQUENCE(_file_50537)){
            _25921 = SEQ_PTR(_file_50537)->length;
    }
    else {
        _25921 = 1;
    }
    _2 = (object)SEQ_PTR(_file_50537);
    _25922 = (object)*(((s1_ptr)_2)->base + _25921);
    if (binary_op_a(EQUALS, _25922, 47)){
        _25922 = NOVALUE;
        goto L2; // [33] 46
    }
    _25922 = NOVALUE;

    /** pathopen.e:221				file &= SLASH*/
    Append(&_file_50537, _file_50537, 47);
L2: 

    /** pathopen.e:223			file &= "eu.cfg"*/
    Concat((object_ptr)&_file_50537, _file_50537, _25925);
L1: 

    /** pathopen.e:226		conf_path = canonical_path( file,,CORRECT )*/
    RefDS(_file_50537);
    _0 = _conf_path_50542;
    _conf_path_50542 = _14canonical_path(_file_50537, 0, 2);
    DeRef(_0);

    /** pathopen.e:229		if find(conf_path, seen_conf) != 0 then*/
    _25928 = find_from(_conf_path_50542, _46seen_conf_50534, 1);
    if (_25928 == 0)
    goto L3; // [74] 85

    /** pathopen.e:230			return {}*/
    RefDS(_22015);
    DeRefDS(_file_50537);
    DeRefi(_in_50539);
    DeRefDS(_conf_path_50542);
    DeRef(_new_args_50543);
    DeRefi(_arg_50544);
    DeRefi(_parm_50545);
    DeRef(_section_50546);
    return _22015;
L3: 

    /** pathopen.e:232		seen_conf = append(seen_conf, conf_path)*/
    RefDS(_conf_path_50542);
    Append(&_46seen_conf_50534, _46seen_conf_50534, _conf_path_50542);

    /** pathopen.e:234		section = "all"*/
    RefDS(_25931);
    DeRef(_section_50546);
    _section_50546 = _25931;

    /** pathopen.e:235		fn = open( conf_path, "r" )*/
    _fn_50538 = EOpen(_conf_path_50542, _25932, 0);

    /** pathopen.e:236		if fn = -1 then return {} end if*/
    if (_fn_50538 != -1)
    goto L4; // [109] 118
    RefDS(_22015);
    DeRefDS(_file_50537);
    DeRefi(_in_50539);
    DeRefDS(_conf_path_50542);
    DeRef(_new_args_50543);
    DeRefi(_arg_50544);
    DeRefi(_parm_50545);
    DeRefDSi(_section_50546);
    return _22015;
L4: 

    /** pathopen.e:238		in = gets( fn )*/
    DeRefi(_in_50539);
    _in_50539 = EGets(_fn_50538);

    /** pathopen.e:239		while sequence( in ) do*/
L5: 
    _25936 = IS_SEQUENCE(_in_50539);
    if (_25936 == 0)
    {
        _25936 = NOVALUE;
        goto L6; // [131] 768
    }
    else{
        _25936 = NOVALUE;
    }

    /** pathopen.e:241			spos = 1*/
    _spos_50540 = 1;

    /** pathopen.e:242			while spos <= length(in) do*/
L7: 
    if (IS_SEQUENCE(_in_50539)){
            _25937 = SEQ_PTR(_in_50539)->length;
    }
    else {
        _25937 = 1;
    }
    if (_spos_50540 > _25937)
    goto L8; // [147] 182

    /** pathopen.e:243				if find( in[spos], "\n\r \t" ) = 0 then*/
    _2 = (object)SEQ_PTR(_in_50539);
    _25939 = (object)*(((s1_ptr)_2)->base + _spos_50540);
    _25941 = find_from(_25939, _25940, 1);
    _25939 = NOVALUE;
    if (_25941 != 0)
    goto L9; // [162] 171

    /** pathopen.e:244					exit*/
    goto L8; // [168] 182
L9: 

    /** pathopen.e:246				spos += 1*/
    _spos_50540 = _spos_50540 + 1;

    /** pathopen.e:247			end while*/
    goto L7; // [179] 144
L8: 

    /** pathopen.e:249			epos = length(in)*/
    if (IS_SEQUENCE(_in_50539)){
            _epos_50541 = SEQ_PTR(_in_50539)->length;
    }
    else {
        _epos_50541 = 1;
    }

    /** pathopen.e:250			while epos >= spos do*/
LA: 
    if (_epos_50541 < _spos_50540)
    goto LB; // [192] 227

    /** pathopen.e:251				if find( in[epos], "\n\r \t" ) = 0 then*/
    _2 = (object)SEQ_PTR(_in_50539);
    _25946 = (object)*(((s1_ptr)_2)->base + _epos_50541);
    _25947 = find_from(_25946, _25940, 1);
    _25946 = NOVALUE;
    if (_25947 != 0)
    goto LC; // [207] 216

    /** pathopen.e:252					exit*/
    goto LB; // [213] 227
LC: 

    /** pathopen.e:254				epos -= 1*/
    _epos_50541 = _epos_50541 - 1;

    /** pathopen.e:255			end while*/
    goto LA; // [224] 192
LB: 

    /** pathopen.e:257			in = in[spos .. epos]		*/
    rhs_slice_target = (object_ptr)&_in_50539;
    RHS_Slice(_in_50539, _spos_50540, _epos_50541);

    /** pathopen.e:260			arg = ""*/
    RefDS(_22015);
    DeRefi(_arg_50544);
    _arg_50544 = _22015;

    /** pathopen.e:261			parm = ""*/
    RefDS(_22015);
    DeRefi(_parm_50545);
    _parm_50545 = _22015;

    /** pathopen.e:269			if length(in) > 0 then*/
    if (IS_SEQUENCE(_in_50539)){
            _25951 = SEQ_PTR(_in_50539)->length;
    }
    else {
        _25951 = 1;
    }
    if (_25951 <= 0)
    goto LD; // [253] 477

    /** pathopen.e:270				if in[1] = '[' then*/
    _2 = (object)SEQ_PTR(_in_50539);
    _25953 = (object)*(((s1_ptr)_2)->base + 1);
    if (_25953 != 91)
    goto LE; // [263] 354

    /** pathopen.e:272					section = in[2..$]*/
    if (IS_SEQUENCE(_in_50539)){
            _25955 = SEQ_PTR(_in_50539)->length;
    }
    else {
        _25955 = 1;
    }
    rhs_slice_target = (object_ptr)&_section_50546;
    RHS_Slice(_in_50539, 2, _25955);

    /** pathopen.e:273					if length(section) > 0 and section[$] = ']' then*/
    if (IS_SEQUENCE(_section_50546)){
            _25957 = SEQ_PTR(_section_50546)->length;
    }
    else {
        _25957 = 1;
    }
    _25958 = (_25957 > 0);
    _25957 = NOVALUE;
    if (_25958 == 0) {
        goto LF; // [286] 320
    }
    if (IS_SEQUENCE(_section_50546)){
            _25960 = SEQ_PTR(_section_50546)->length;
    }
    else {
        _25960 = 1;
    }
    _2 = (object)SEQ_PTR(_section_50546);
    _25961 = (object)*(((s1_ptr)_2)->base + _25960);
    _25962 = (_25961 == 93);
    _25961 = NOVALUE;
    if (_25962 == 0)
    {
        DeRef(_25962);
        _25962 = NOVALUE;
        goto LF; // [302] 320
    }
    else{
        DeRef(_25962);
        _25962 = NOVALUE;
    }

    /** pathopen.e:274						section = section[1..$-1]*/
    if (IS_SEQUENCE(_section_50546)){
            _25963 = SEQ_PTR(_section_50546)->length;
    }
    else {
        _25963 = 1;
    }
    _25964 = _25963 - 1;
    _25963 = NOVALUE;
    rhs_slice_target = (object_ptr)&_section_50546;
    RHS_Slice(_section_50546, 1, _25964);
LF: 

    /** pathopen.e:276					section = lower(trim(section))*/
    RefDS(_section_50546);
    RefDS(_3010);
    _25966 = _18trim(_section_50546, _3010, 0);
    _0 = _section_50546;
    _section_50546 = _18lower(_25966);
    DeRefDS(_0);
    _25966 = NOVALUE;

    /** pathopen.e:277					if length(section) = 0 then*/
    if (IS_SEQUENCE(_section_50546)){
            _25968 = SEQ_PTR(_section_50546)->length;
    }
    else {
        _25968 = 1;
    }
    if (_25968 != 0)
    goto L10; // [339] 476

    /** pathopen.e:278						section = "all"*/
    RefDS(_25931);
    DeRefDS(_section_50546);
    _section_50546 = _25931;
    goto L10; // [351] 476
LE: 

    /** pathopen.e:281				elsif length(in) > 2 then*/
    if (IS_SEQUENCE(_in_50539)){
            _25970 = SEQ_PTR(_in_50539)->length;
    }
    else {
        _25970 = 1;
    }
    if (_25970 <= 2)
    goto L11; // [359] 461

    /** pathopen.e:282					if in[1] = '-' then*/
    _2 = (object)SEQ_PTR(_in_50539);
    _25972 = (object)*(((s1_ptr)_2)->base + 1);
    if (_25972 != 45)
    goto L12; // [369] 443

    /** pathopen.e:283						if in[2] != '-' then*/
    _2 = (object)SEQ_PTR(_in_50539);
    _25974 = (object)*(((s1_ptr)_2)->base + 2);
    if (_25974 == 45)
    goto L10; // [379] 476

    /** pathopen.e:284							spos = find(' ', in)*/
    _spos_50540 = find_from(32, _in_50539, 1);

    /** pathopen.e:285							if spos = 0 then*/
    if (_spos_50540 != 0)
    goto L13; // [392] 413

    /** pathopen.e:286								arg = in*/
    Ref(_in_50539);
    DeRefi(_arg_50544);
    _arg_50544 = _in_50539;

    /** pathopen.e:287								parm = ""*/
    RefDS(_22015);
    DeRefi(_parm_50545);
    _parm_50545 = _22015;
    goto L10; // [410] 476
L13: 

    /** pathopen.e:289								arg = in[1..spos - 1]*/
    _25978 = _spos_50540 - 1;
    rhs_slice_target = (object_ptr)&_arg_50544;
    RHS_Slice(_in_50539, 1, _25978);

    /** pathopen.e:290								parm = in[spos + 1 .. $]*/
    _25980 = _spos_50540 + 1;
    if (_25980 > MAXINT){
        _25980 = NewDouble((eudouble)_25980);
    }
    if (IS_SEQUENCE(_in_50539)){
            _25981 = SEQ_PTR(_in_50539)->length;
    }
    else {
        _25981 = 1;
    }
    rhs_slice_target = (object_ptr)&_parm_50545;
    RHS_Slice(_in_50539, _25980, _25981);
    goto L10; // [440] 476
L12: 

    /** pathopen.e:294						arg = "-i"*/
    RefDS(_25983);
    DeRefi(_arg_50544);
    _arg_50544 = _25983;

    /** pathopen.e:295						parm = in*/
    Ref(_in_50539);
    DeRefi(_parm_50545);
    _parm_50545 = _in_50539;
    goto L10; // [458] 476
L11: 

    /** pathopen.e:298					arg = "-i"*/
    RefDS(_25983);
    DeRefi(_arg_50544);
    _arg_50544 = _25983;

    /** pathopen.e:299					parm = in*/
    Ref(_in_50539);
    DeRefi(_parm_50545);
    _parm_50545 = _in_50539;
L10: 
LD: 

    /** pathopen.e:303			if length(arg) > 0 then*/
    if (IS_SEQUENCE(_arg_50544)){
            _25984 = SEQ_PTR(_arg_50544)->length;
    }
    else {
        _25984 = 1;
    }
    if (_25984 <= 0)
    goto L14; // [482] 756

    /** pathopen.e:304				integer needed = 0*/
    _needed_50643 = 0;

    /** pathopen.e:305				switch section do*/
    _1 = find(_section_50546, _25986);
    switch ( _1 ){ 

        /** pathopen.e:306					case "all" then*/
        case 1:

        /** pathopen.e:307						needed = 1*/
        _needed_50643 = 1;
        goto L15; // [507] 691

        /** pathopen.e:309					case "windows" then*/
        case 2:

        /** pathopen.e:310						needed = TWINDOWS*/
        _needed_50643 = 0;
        goto L15; // [522] 691

        /** pathopen.e:312					case "unix" then*/
        case 3:

        /** pathopen.e:313						needed = TUNIX*/
        _needed_50643 = _44TUNIX_20374;
        goto L15; // [537] 691

        /** pathopen.e:315					case "translate" then*/
        case 4:

        /** pathopen.e:316						needed = TRANSLATE*/
        _needed_50643 = _12TRANSLATE_19834;
        goto L15; // [552] 691

        /** pathopen.e:318					case "translate:windows" then*/
        case 5:

        /** pathopen.e:319						needed = TRANSLATE and TWINDOWS*/
        _needed_50643 = (_12TRANSLATE_19834 != 0 && 0 != 0);
        goto L15; // [570] 691

        /** pathopen.e:321					case "translate:unix" then*/
        case 6:

        /** pathopen.e:322						needed = TRANSLATE and TUNIX*/
        _needed_50643 = (_12TRANSLATE_19834 != 0 && _44TUNIX_20374 != 0);
        goto L15; // [588] 691

        /** pathopen.e:324					case "interpret" then*/
        case 7:

        /** pathopen.e:325						needed = INTERPRET*/
        _needed_50643 = _12INTERPRET_19831;
        goto L15; // [603] 691

        /** pathopen.e:327					case "interpret:windows" then*/
        case 8:

        /** pathopen.e:328						needed = INTERPRET and TWINDOWS*/
        _needed_50643 = (_12INTERPRET_19831 != 0 && 0 != 0);
        goto L15; // [621] 691

        /** pathopen.e:330					case "interpret:unix" then*/
        case 9:

        /** pathopen.e:331						needed = INTERPRET and TUNIX*/
        _needed_50643 = (_12INTERPRET_19831 != 0 && _44TUNIX_20374 != 0);
        goto L15; // [639] 691

        /** pathopen.e:333					case "bind" then*/
        case 10:

        /** pathopen.e:334						needed = BIND*/
        _needed_50643 = _12BIND_19837;
        goto L15; // [654] 691

        /** pathopen.e:336					case "bind:windows" then*/
        case 11:

        /** pathopen.e:337						needed = BIND and TWINDOWS*/
        _needed_50643 = (_12BIND_19837 != 0 && 0 != 0);
        goto L15; // [672] 691

        /** pathopen.e:339					case "bind:unix" then*/
        case 12:

        /** pathopen.e:340						needed = BIND and TUNIX*/
        _needed_50643 = (_12BIND_19837 != 0 && _44TUNIX_20374 != 0);
    ;}L15: 

    /** pathopen.e:344				if needed then*/
    if (_needed_50643 == 0)
    {
        goto L16; // [693] 755
    }
    else{
    }

    /** pathopen.e:345					if equal(arg, "-c") then*/
    if (_arg_50544 == _26005)
    _26006 = 1;
    else if (IS_ATOM_INT(_arg_50544) && IS_ATOM_INT(_26005))
    _26006 = 0;
    else
    _26006 = (compare(_arg_50544, _26005) == 0);
    if (_26006 == 0)
    {
        _26006 = NOVALUE;
        goto L17; // [702] 728
    }
    else{
        _26006 = NOVALUE;
    }

    /** pathopen.e:346						if length(parm) > 0 then*/
    if (IS_SEQUENCE(_parm_50545)){
            _26007 = SEQ_PTR(_parm_50545)->length;
    }
    else {
        _26007 = 1;
    }
    if (_26007 <= 0)
    goto L18; // [710] 754

    /** pathopen.e:347							new_args &= load_euphoria_config(parm)*/
    RefDS(_parm_50545);
    _26009 = _46load_euphoria_config(_parm_50545);
    if (IS_SEQUENCE(_new_args_50543) && IS_ATOM(_26009)) {
        Ref(_26009);
        Append(&_new_args_50543, _new_args_50543, _26009);
    }
    else if (IS_ATOM(_new_args_50543) && IS_SEQUENCE(_26009)) {
    }
    else {
        Concat((object_ptr)&_new_args_50543, _new_args_50543, _26009);
    }
    DeRef(_26009);
    _26009 = NOVALUE;
    goto L18; // [725] 754
L17: 

    /** pathopen.e:350						new_args = append(new_args, arg)*/
    RefDS(_arg_50544);
    Append(&_new_args_50543, _new_args_50543, _arg_50544);

    /** pathopen.e:351						if length(parm > 0) then*/
    _26012 = binary_op(GREATER, _parm_50545, 0);
    if (IS_SEQUENCE(_26012)){
            _26013 = SEQ_PTR(_26012)->length;
    }
    else {
        _26013 = 1;
    }
    DeRefDS(_26012);
    _26012 = NOVALUE;
    if (_26013 == 0)
    {
        _26013 = NOVALUE;
        goto L19; // [743] 753
    }
    else{
        _26013 = NOVALUE;
    }

    /** pathopen.e:352							new_args = append(new_args, parm)*/
    RefDS(_parm_50545);
    Append(&_new_args_50543, _new_args_50543, _parm_50545);
L19: 
L18: 
L16: 
L14: 

    /** pathopen.e:358			in = gets( fn )*/
    DeRefi(_in_50539);
    _in_50539 = EGets(_fn_50538);

    /** pathopen.e:359		end while*/
    goto L5; // [765] 128
L6: 

    /** pathopen.e:360		close(fn)*/
    EClose(_fn_50538);

    /** pathopen.e:362		return new_args*/
    DeRefDS(_file_50537);
    DeRefi(_in_50539);
    DeRef(_conf_path_50542);
    DeRefi(_arg_50544);
    DeRefi(_parm_50545);
    DeRef(_section_50546);
    _25953 = NOVALUE;
    DeRef(_25978);
    _25978 = NOVALUE;
    DeRef(_25958);
    _25958 = NOVALUE;
    _26012 = NOVALUE;
    _25972 = NOVALUE;
    DeRef(_25980);
    _25980 = NOVALUE;
    DeRef(_25964);
    _25964 = NOVALUE;
    _25974 = NOVALUE;
    return _new_args_50543;
    ;
}


object _46GetDefaultArgs(object _user_files_50710)
{
    object _env_50711 = NOVALUE;
    object _default_args_50712 = NOVALUE;
    object _conf_file_50713 = NOVALUE;
    object _cmd_options_50715 = NOVALUE;
    object _user_config_50721 = NOVALUE;
    object _26048 = NOVALUE;
    object _26047 = NOVALUE;
    object _26046 = NOVALUE;
    object _26038 = NOVALUE;
    object _26037 = NOVALUE;
    object _26035 = NOVALUE;
    object _26032 = NOVALUE;
    object _26031 = NOVALUE;
    object _26028 = NOVALUE;
    object _26027 = NOVALUE;
    object _26025 = NOVALUE;
    object _26023 = NOVALUE;
    object _26022 = NOVALUE;
    object _26018 = NOVALUE;
    object _26017 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:367		sequence default_args = {}*/
    RefDS(_22015);
    DeRef(_default_args_50712);
    _default_args_50712 = _22015;

    /** pathopen.e:368		sequence conf_file = "eu.cfg"*/
    RefDS(_25925);
    DeRefi(_conf_file_50713);
    _conf_file_50713 = _25925;

    /** pathopen.e:370		if loaded_config_inc_paths then return "" end if*/
    if (_46loaded_config_inc_paths_50387 == 0)
    {
        goto L1; // [21] 29
    }
    else{
    }
    RefDS(_22015);
    DeRefDS(_user_files_50710);
    DeRef(_env_50711);
    DeRefDS(_default_args_50712);
    DeRefDSi(_conf_file_50713);
    DeRef(_cmd_options_50715);
    return _22015;
L1: 

    /** pathopen.e:371		loaded_config_inc_paths = 1*/
    _46loaded_config_inc_paths_50387 = 1;

    /** pathopen.e:380		sequence cmd_options = get_options()*/
    _0 = _cmd_options_50715;
    _cmd_options_50715 = _47get_options();
    DeRef(_0);

    /** pathopen.e:382		default_args = {}*/
    RefDS(_22015);
    DeRef(_default_args_50712);
    _default_args_50712 = _22015;

    /** pathopen.e:385		for i = 1 to length( user_files ) do*/
    if (IS_SEQUENCE(_user_files_50710)){
            _26017 = SEQ_PTR(_user_files_50710)->length;
    }
    else {
        _26017 = 1;
    }
    {
        object _i_50719;
        _i_50719 = 1;
L2: 
        if (_i_50719 > _26017){
            goto L3; // [53] 92
        }

        /** pathopen.e:386			sequence user_config = load_euphoria_config( user_files[i] )*/
        _2 = (object)SEQ_PTR(_user_files_50710);
        _26018 = (object)*(((s1_ptr)_2)->base + _i_50719);
        Ref(_26018);
        _0 = _user_config_50721;
        _user_config_50721 = _46load_euphoria_config(_26018);
        DeRef(_0);
        _26018 = NOVALUE;

        /** pathopen.e:387			default_args = merge_parameters( user_config, default_args, cmd_options, 1 )*/
        RefDS(_user_config_50721);
        RefDS(_default_args_50712);
        RefDS(_cmd_options_50715);
        _0 = _default_args_50712;
        _default_args_50712 = _47merge_parameters(_user_config_50721, _default_args_50712, _cmd_options_50715, 1);
        DeRefDS(_0);
        DeRefDS(_user_config_50721);
        _user_config_50721 = NOVALUE;

        /** pathopen.e:388		end for*/
        _i_50719 = _i_50719 + 1;
        goto L2; // [87] 60
L3: 
        ;
    }

    /** pathopen.e:391		default_args = merge_parameters( load_euphoria_config("./" & conf_file), default_args, cmd_options, 1 )*/
    Concat((object_ptr)&_26022, _26021, _conf_file_50713);
    _26023 = _46load_euphoria_config(_26022);
    _26022 = NOVALUE;
    RefDS(_default_args_50712);
    RefDS(_cmd_options_50715);
    _0 = _default_args_50712;
    _default_args_50712 = _47merge_parameters(_26023, _default_args_50712, _cmd_options_50715, 1);
    DeRefDS(_0);
    _26023 = NOVALUE;

    /** pathopen.e:394		env = strip_file_from_path( exe_path() )*/
    _26025 = _46exe_path();
    _0 = _env_50711;
    _env_50711 = _46strip_file_from_path(_26025);
    DeRef(_0);
    _26025 = NOVALUE;

    /** pathopen.e:395		default_args = merge_parameters( load_euphoria_config( env & conf_file ), default_args, cmd_options, 1 )*/
    if (IS_SEQUENCE(_env_50711) && IS_ATOM(_conf_file_50713)) {
    }
    else if (IS_ATOM(_env_50711) && IS_SEQUENCE(_conf_file_50713)) {
        Ref(_env_50711);
        Prepend(&_26027, _conf_file_50713, _env_50711);
    }
    else {
        Concat((object_ptr)&_26027, _env_50711, _conf_file_50713);
    }
    _26028 = _46load_euphoria_config(_26027);
    _26027 = NOVALUE;
    RefDS(_default_args_50712);
    RefDS(_cmd_options_50715);
    _0 = _default_args_50712;
    _default_args_50712 = _47merge_parameters(_26028, _default_args_50712, _cmd_options_50715, 1);
    DeRefDS(_0);
    _26028 = NOVALUE;

    /** pathopen.e:398		ifdef UNIX then*/

    /** pathopen.e:399			default_args = merge_parameters( load_euphoria_config( "/etc/euphoria/" & conf_file ), default_args, cmd_options, 1 )*/
    Concat((object_ptr)&_26031, _26030, _conf_file_50713);
    _26032 = _46load_euphoria_config(_26031);
    _26031 = NOVALUE;
    RefDS(_default_args_50712);
    RefDS(_cmd_options_50715);
    _0 = _default_args_50712;
    _default_args_50712 = _47merge_parameters(_26032, _default_args_50712, _cmd_options_50715, 1);
    DeRefDS(_0);
    _26032 = NOVALUE;

    /** pathopen.e:401			env = getenv( "HOME" )*/
    DeRef(_env_50711);
    _env_50711 = EGetEnv(_25896);

    /** pathopen.e:402			if sequence(env) then*/
    _26035 = IS_SEQUENCE(_env_50711);
    if (_26035 == 0)
    {
        _26035 = NOVALUE;
        goto L4; // [170] 195
    }
    else{
        _26035 = NOVALUE;
    }

    /** pathopen.e:403				default_args = merge_parameters( load_euphoria_config( env & "/." & conf_file ), default_args, cmd_options, 1 )*/
    {
        object concat_list[3];

        concat_list[0] = _conf_file_50713;
        concat_list[1] = _26036;
        concat_list[2] = _env_50711;
        Concat_N((object_ptr)&_26037, concat_list, 3);
    }
    _26038 = _46load_euphoria_config(_26037);
    _26037 = NOVALUE;
    RefDS(_default_args_50712);
    RefDS(_cmd_options_50715);
    _0 = _default_args_50712;
    _default_args_50712 = _47merge_parameters(_26038, _default_args_50712, _cmd_options_50715, 1);
    DeRefDS(_0);
    _26038 = NOVALUE;
L4: 

    /** pathopen.e:427		env = get_eudir()*/
    _0 = _env_50711;
    _env_50711 = _13get_eudir();
    DeRef(_0);

    /** pathopen.e:428		if sequence(env) then*/
    _26046 = IS_SEQUENCE(_env_50711);
    if (_26046 == 0)
    {
        _26046 = NOVALUE;
        goto L5; // [205] 230
    }
    else{
        _26046 = NOVALUE;
    }

    /** pathopen.e:429			default_args = merge_parameters( load_euphoria_config(env & "/" & conf_file), default_args, cmd_options, 1 )*/
    {
        object concat_list[3];

        concat_list[0] = _conf_file_50713;
        concat_list[1] = _23596;
        concat_list[2] = _env_50711;
        Concat_N((object_ptr)&_26047, concat_list, 3);
    }
    _26048 = _46load_euphoria_config(_26047);
    _26047 = NOVALUE;
    RefDS(_default_args_50712);
    RefDS(_cmd_options_50715);
    _0 = _default_args_50712;
    _default_args_50712 = _47merge_parameters(_26048, _default_args_50712, _cmd_options_50715, 1);
    DeRefDS(_0);
    _26048 = NOVALUE;
L5: 

    /** pathopen.e:432		return default_args*/
    DeRefDS(_user_files_50710);
    DeRef(_env_50711);
    DeRefi(_conf_file_50713);
    DeRef(_cmd_options_50715);
    return _default_args_50712;
    ;
}


object _46ConfPath(object _file_name_50765)
{
    object _file_path_50766 = NOVALUE;
    object _try_50767 = NOVALUE;
    object _26055 = NOVALUE;
    object _26051 = NOVALUE;
    object _26050 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:440		for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_46config_inc_paths_50386)){
            _26050 = SEQ_PTR(_46config_inc_paths_50386)->length;
    }
    else {
        _26050 = 1;
    }
    {
        object _i_50769;
        _i_50769 = 1;
L1: 
        if (_i_50769 > _26050){
            goto L2; // [10] 60
        }

        /** pathopen.e:441			file_path = config_inc_paths[i] & file_name*/
        _2 = (object)SEQ_PTR(_46config_inc_paths_50386);
        _26051 = (object)*(((s1_ptr)_2)->base + _i_50769);
        Concat((object_ptr)&_file_path_50766, _26051, _file_name_50765);
        _26051 = NOVALUE;
        _26051 = NOVALUE;

        /** pathopen.e:442			try = open( file_path, "r" )*/
        _try_50767 = EOpen(_file_path_50766, _25932, 0);

        /** pathopen.e:443			if try != -1 then*/
        if (_try_50767 == -1)
        goto L3; // [38] 53

        /** pathopen.e:444				return {file_path, try}*/
        RefDS(_file_path_50766);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_50766;
        ((intptr_t *)_2)[2] = _try_50767;
        _26055 = MAKE_SEQ(_1);
        DeRefDS(_file_name_50765);
        DeRefDS(_file_path_50766);
        return _26055;
L3: 

        /** pathopen.e:446		end for*/
        _i_50769 = _i_50769 + 1;
        goto L1; // [55] 17
L2: 
        ;
    }

    /** pathopen.e:447		return -1*/
    DeRefDS(_file_name_50765);
    DeRef(_file_path_50766);
    DeRef(_26055);
    _26055 = NOVALUE;
    return -1;
    ;
}


object _46ScanPath(object _file_name_50779, object _env_50780, object _flag_50781)
{
    object _inc_path_50782 = NOVALUE;
    object _full_path_50783 = NOVALUE;
    object _file_path_50784 = NOVALUE;
    object _strings_50785 = NOVALUE;
    object _end_path_50786 = NOVALUE;
    object _start_path_50787 = NOVALUE;
    object _try_50788 = NOVALUE;
    object _use_cache_50789 = NOVALUE;
    object _pos_50790 = NOVALUE;
    object _26103 = NOVALUE;
    object _26102 = NOVALUE;
    object _26101 = NOVALUE;
    object _26100 = NOVALUE;
    object _26099 = NOVALUE;
    object _26098 = NOVALUE;
    object _26097 = NOVALUE;
    object _26096 = NOVALUE;
    object _26092 = NOVALUE;
    object _26091 = NOVALUE;
    object _26090 = NOVALUE;
    object _26089 = NOVALUE;
    object _26088 = NOVALUE;
    object _26087 = NOVALUE;
    object _26085 = NOVALUE;
    object _26083 = NOVALUE;
    object _26082 = NOVALUE;
    object _26080 = NOVALUE;
    object _26079 = NOVALUE;
    object _26078 = NOVALUE;
    object _26075 = NOVALUE;
    object _26074 = NOVALUE;
    object _26072 = NOVALUE;
    object _26071 = NOVALUE;
    object _26070 = NOVALUE;
    object _26065 = NOVALUE;
    object _26057 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:459		inc_path = getenv(env)*/
    DeRefi(_inc_path_50782);
    _inc_path_50782 = EGetEnv(_env_50780);

    /** pathopen.e:460		if compare(inc_path,{})!=1 then -- nothing to do, just fail*/
    if (IS_ATOM_INT(_inc_path_50782) && IS_ATOM_INT(_22015)){
        _26057 = (_inc_path_50782 < _22015) ? -1 : (_inc_path_50782 > _22015);
    }
    else{
        _26057 = compare(_inc_path_50782, _22015);
    }
    if (_26057 == 1)
    goto L1; // [18] 29

    /** pathopen.e:461			return -1*/
    DeRefDS(_file_name_50779);
    DeRefDSi(_env_50780);
    DeRefi(_inc_path_50782);
    DeRef(_full_path_50783);
    DeRef(_file_path_50784);
    DeRef(_strings_50785);
    return -1;
L1: 

    /** pathopen.e:464		num_var = find(env,cache_vars)*/
    _46num_var_50377 = find_from(_env_50780, _46cache_vars_50378, 1);

    /** pathopen.e:465		use_cache = check_cache(env,inc_path)*/
    RefDS(_env_50780);
    Ref(_inc_path_50782);
    _use_cache_50789 = _46check_cache(_env_50780, _inc_path_50782);
    if (!IS_ATOM_INT(_use_cache_50789)) {
        _1 = (object)(DBL_PTR(_use_cache_50789)->dbl);
        DeRefDS(_use_cache_50789);
        _use_cache_50789 = _1;
    }

    /** pathopen.e:466		inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_50782, _inc_path_50782, 58);

    /** pathopen.e:468		file_name = SLASH & file_name*/
    Prepend(&_file_name_50779, _file_name_50779, 47);

    /** pathopen.e:469		if flag then*/
    if (_flag_50781 == 0)
    {
        goto L2; // [65] 77
    }
    else{
    }

    /** pathopen.e:470			file_name = include_subfolder & file_name*/
    Concat((object_ptr)&_file_name_50779, _46include_subfolder_50373, _file_name_50779);
L2: 

    /** pathopen.e:472		strings = cache_substrings[num_var]*/
    DeRef(_strings_50785);
    _2 = (object)SEQ_PTR(_46cache_substrings_50380);
    _strings_50785 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
    RefDS(_strings_50785);

    /** pathopen.e:474		if use_cache then*/
    if (_use_cache_50789 == 0)
    {
        goto L3; // [91] 194
    }
    else{
    }

    /** pathopen.e:475			for i=1 to length(strings) do*/
    if (IS_SEQUENCE(_strings_50785)){
            _26065 = SEQ_PTR(_strings_50785)->length;
    }
    else {
        _26065 = 1;
    }
    {
        object _i_50806;
        _i_50806 = 1;
L4: 
        if (_i_50806 > _26065){
            goto L5; // [99] 154
        }

        /** pathopen.e:476				full_path = strings[i]*/
        DeRef(_full_path_50783);
        _2 = (object)SEQ_PTR(_strings_50785);
        _full_path_50783 = (object)*(((s1_ptr)_2)->base + _i_50806);
        Ref(_full_path_50783);

        /** pathopen.e:477				file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_50784, _full_path_50783, _file_name_50779);

        /** pathopen.e:478				try = open_locked(file_path)    */
        RefDS(_file_path_50784);
        _try_50788 = _13open_locked(_file_path_50784);
        if (!IS_ATOM_INT(_try_50788)) {
            _1 = (object)(DBL_PTR(_try_50788)->dbl);
            DeRefDS(_try_50788);
            _try_50788 = _1;
        }

        /** pathopen.e:479				if try != -1 then*/
        if (_try_50788 == -1)
        goto L6; // [130] 145

        /** pathopen.e:480					return {file_path,try}*/
        RefDS(_file_path_50784);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_50784;
        ((intptr_t *)_2)[2] = _try_50788;
        _26070 = MAKE_SEQ(_1);
        DeRefDS(_file_name_50779);
        DeRefDSi(_env_50780);
        DeRefi(_inc_path_50782);
        DeRefDS(_full_path_50783);
        DeRefDS(_file_path_50784);
        DeRefDS(_strings_50785);
        return _26070;
L6: 

        /** pathopen.e:482				ifdef WINDOWS then */

        /** pathopen.e:496			end for*/
        _i_50806 = _i_50806 + 1;
        goto L4; // [149] 106
L5: 
        ;
    }

    /** pathopen.e:497			if cache_complete[num_var] then -- nothing to scan*/
    _2 = (object)SEQ_PTR(_46cache_complete_50384);
    _26071 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
    if (_26071 == 0)
    {
        _26071 = NOVALUE;
        goto L7; // [164] 176
    }
    else{
        _26071 = NOVALUE;
    }

    /** pathopen.e:498				return -1*/
    DeRefDS(_file_name_50779);
    DeRefDSi(_env_50780);
    DeRefi(_inc_path_50782);
    DeRef(_full_path_50783);
    DeRef(_file_path_50784);
    DeRef(_strings_50785);
    DeRef(_26070);
    _26070 = NOVALUE;
    return -1;
    goto L8; // [173] 200
L7: 

    /** pathopen.e:500				pos = cache_delims[num_var]+1 -- scan remainder, starting from as far sa possible*/
    _2 = (object)SEQ_PTR(_46cache_delims_50385);
    _26072 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
    _pos_50790 = _26072 + 1;
    _26072 = NOVALUE;
    goto L8; // [191] 200
L3: 

    /** pathopen.e:503			pos = 1*/
    _pos_50790 = 1;
L8: 

    /** pathopen.e:506		start_path = 0*/
    _start_path_50787 = 0;

    /** pathopen.e:507		for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_50782)){
            _26074 = SEQ_PTR(_inc_path_50782)->length;
    }
    else {
        _26074 = 1;
    }
    {
        object _p_50822;
        _p_50822 = _pos_50790;
L9: 
        if (_p_50822 > _26074){
            goto LA; // [212] 460
        }

        /** pathopen.e:508			if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (object)SEQ_PTR(_inc_path_50782);
        _26075 = (object)*(((s1_ptr)_2)->base + _p_50822);
        if (_26075 != 58)
        goto LB; // [227] 409

        /** pathopen.e:510				cache_delims[num_var] = p*/
        _2 = (object)SEQ_PTR(_46cache_delims_50385);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_delims_50385 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50377);
        *(intptr_t *)_2 = _p_50822;

        /** pathopen.e:512				end_path = p-1*/
        _end_path_50786 = _p_50822 - 1;

        /** pathopen.e:513				while end_path >= start_path and find(inc_path[end_path], " \t" & SLASH_CHARS) do*/
LC: 
        _26078 = (_end_path_50786 >= _start_path_50787);
        if (_26078 == 0) {
            goto LD; // [256] 290
        }
        _2 = (object)SEQ_PTR(_inc_path_50782);
        _26080 = (object)*(((s1_ptr)_2)->base + _end_path_50786);
        Concat((object_ptr)&_26082, _26081, _44SLASH_CHARS_20390);
        _26083 = find_from(_26080, _26082, 1);
        _26080 = NOVALUE;
        DeRefDS(_26082);
        _26082 = NOVALUE;
        if (_26083 == 0)
        {
            _26083 = NOVALUE;
            goto LD; // [276] 290
        }
        else{
            _26083 = NOVALUE;
        }

        /** pathopen.e:514					end_path-=1*/
        _end_path_50786 = _end_path_50786 - 1;

        /** pathopen.e:515				end while*/
        goto LC; // [287] 252
LD: 

        /** pathopen.e:517				if start_path and end_path then*/
        if (_start_path_50787 == 0) {
            goto LE; // [292] 453
        }
        if (_end_path_50786 == 0)
        {
            goto LE; // [297] 453
        }
        else{
        }

        /** pathopen.e:518					full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_50783;
        RHS_Slice(_inc_path_50782, _start_path_50787, _end_path_50786);

        /** pathopen.e:519					cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_46cache_substrings_50380);
        _26087 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
        RefDS(_full_path_50783);
        Append(&_26088, _26087, _full_path_50783);
        _26087 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_substrings_50380);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_substrings_50380 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50377);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26088;
        if( _1 != _26088 ){
            DeRefDS(_1);
        }
        _26088 = NOVALUE;

        /** pathopen.e:520					cache_starts[num_var] &= start_path*/
        _2 = (object)SEQ_PTR(_46cache_starts_50381);
        _26089 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
        if (IS_SEQUENCE(_26089) && IS_ATOM(_start_path_50787)) {
            Append(&_26090, _26089, _start_path_50787);
        }
        else if (IS_ATOM(_26089) && IS_SEQUENCE(_start_path_50787)) {
        }
        else {
            Concat((object_ptr)&_26090, _26089, _start_path_50787);
            _26089 = NOVALUE;
        }
        _26089 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_starts_50381);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_starts_50381 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50377);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26090;
        if( _1 != _26090 ){
            DeRef(_1);
        }
        _26090 = NOVALUE;

        /** pathopen.e:521					cache_ends[num_var] &= end_path*/
        _2 = (object)SEQ_PTR(_46cache_ends_50382);
        _26091 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
        if (IS_SEQUENCE(_26091) && IS_ATOM(_end_path_50786)) {
            Append(&_26092, _26091, _end_path_50786);
        }
        else if (IS_ATOM(_26091) && IS_SEQUENCE(_end_path_50786)) {
        }
        else {
            Concat((object_ptr)&_26092, _26091, _end_path_50786);
            _26091 = NOVALUE;
        }
        _26091 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_ends_50382);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_ends_50382 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50377);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26092;
        if( _1 != _26092 ){
            DeRef(_1);
        }
        _26092 = NOVALUE;

        /** pathopen.e:522					file_path = full_path & file_name  */
        Concat((object_ptr)&_file_path_50784, _full_path_50783, _file_name_50779);

        /** pathopen.e:523					try = open_locked(file_path)*/
        RefDS(_file_path_50784);
        _try_50788 = _13open_locked(_file_path_50784);
        if (!IS_ATOM_INT(_try_50788)) {
            _1 = (object)(DBL_PTR(_try_50788)->dbl);
            DeRefDS(_try_50788);
            _try_50788 = _1;
        }

        /** pathopen.e:524					if try != -1 then -- valid path, no point trying to convert*/
        if (_try_50788 == -1)
        goto LF; // [381] 398

        /** pathopen.e:525						ifdef WINDOWS then*/

        /** pathopen.e:528						return {file_path,try}*/
        RefDS(_file_path_50784);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_50784;
        ((intptr_t *)_2)[2] = _try_50788;
        _26096 = MAKE_SEQ(_1);
        DeRefDS(_file_name_50779);
        DeRefDSi(_env_50780);
        DeRefi(_inc_path_50782);
        DeRefDSi(_full_path_50783);
        DeRefDS(_file_path_50784);
        DeRef(_strings_50785);
        DeRef(_26078);
        _26078 = NOVALUE;
        _26075 = NOVALUE;
        DeRef(_26070);
        _26070 = NOVALUE;
        return _26096;
LF: 

        /** pathopen.e:530					ifdef WINDOWS then*/

        /** pathopen.e:547					start_path = 0*/
        _start_path_50787 = 0;
        goto LE; // [406] 453
LB: 

        /** pathopen.e:549			elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26097 = (_start_path_50787 == 0);
        if (_26097 == 0) {
            goto L10; // [414] 452
        }
        _2 = (object)SEQ_PTR(_inc_path_50782);
        _26099 = (object)*(((s1_ptr)_2)->base + _p_50822);
        _26100 = (_26099 != 32);
        _26099 = NOVALUE;
        if (_26100 == 0) {
            DeRef(_26101);
            _26101 = 0;
            goto L11; // [426] 442
        }
        _2 = (object)SEQ_PTR(_inc_path_50782);
        _26102 = (object)*(((s1_ptr)_2)->base + _p_50822);
        _26103 = (_26102 != 9);
        _26102 = NOVALUE;
        _26101 = (_26103 != 0);
L11: 
        if (_26101 == 0)
        {
            _26101 = NOVALUE;
            goto L10; // [443] 452
        }
        else{
            _26101 = NOVALUE;
        }

        /** pathopen.e:550				start_path = p*/
        _start_path_50787 = _p_50822;
L10: 
LE: 

        /** pathopen.e:552		end for*/
        _p_50822 = _p_50822 + 1;
        goto L9; // [455] 219
LA: 
        ;
    }

    /** pathopen.e:554		cache_complete[num_var] = 1*/
    _2 = (object)SEQ_PTR(_46cache_complete_50384);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _46cache_complete_50384 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _46num_var_50377);
    *(intptr_t *)_2 = 1;

    /** pathopen.e:555		return -1*/
    DeRefDS(_file_name_50779);
    DeRefDSi(_env_50780);
    DeRefi(_inc_path_50782);
    DeRef(_full_path_50783);
    DeRef(_file_path_50784);
    DeRef(_strings_50785);
    DeRef(_26096);
    _26096 = NOVALUE;
    DeRef(_26100);
    _26100 = NOVALUE;
    DeRef(_26097);
    _26097 = NOVALUE;
    DeRef(_26103);
    _26103 = NOVALUE;
    DeRef(_26078);
    _26078 = NOVALUE;
    _26075 = NOVALUE;
    DeRef(_26070);
    _26070 = NOVALUE;
    return -1;
    ;
}


object _46Include_paths(object _add_converted_50864)
{
    object _status_50865 = NOVALUE;
    object _pos_50866 = NOVALUE;
    object _inc_path_50867 = NOVALUE;
    object _full_path_50868 = NOVALUE;
    object _start_path_50869 = NOVALUE;
    object _end_path_50870 = NOVALUE;
    object _eudir_path_50886 = NOVALUE;
    object _26149 = NOVALUE;
    object _26148 = NOVALUE;
    object _26147 = NOVALUE;
    object _26146 = NOVALUE;
    object _26145 = NOVALUE;
    object _26144 = NOVALUE;
    object _26143 = NOVALUE;
    object _26142 = NOVALUE;
    object _26141 = NOVALUE;
    object _26140 = NOVALUE;
    object _26139 = NOVALUE;
    object _26138 = NOVALUE;
    object _26137 = NOVALUE;
    object _26136 = NOVALUE;
    object _26134 = NOVALUE;
    object _26132 = NOVALUE;
    object _26131 = NOVALUE;
    object _26130 = NOVALUE;
    object _26129 = NOVALUE;
    object _26128 = NOVALUE;
    object _26125 = NOVALUE;
    object _26124 = NOVALUE;
    object _26122 = NOVALUE;
    object _26120 = NOVALUE;
    object _26118 = NOVALUE;
    object _26117 = NOVALUE;
    object _26115 = NOVALUE;
    object _26112 = NOVALUE;
    object _26110 = NOVALUE;
    object _26105 = NOVALUE;
    object _26104 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_add_converted_50864)) {
        _1 = (object)(DBL_PTR(_add_converted_50864)->dbl);
        DeRefDS(_add_converted_50864);
        _add_converted_50864 = _1;
    }

    /** pathopen.e:566		if length(include_Paths) then*/
    if (IS_SEQUENCE(_46include_Paths_50861)){
            _26104 = SEQ_PTR(_46include_Paths_50861)->length;
    }
    else {
        _26104 = 1;
    }
    if (_26104 == 0)
    {
        _26104 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _26104 = NOVALUE;
    }

    /** pathopen.e:567			return include_Paths*/
    RefDS(_46include_Paths_50861);
    DeRefi(_inc_path_50867);
    DeRefi(_full_path_50868);
    DeRef(_eudir_path_50886);
    return _46include_Paths_50861;
L1: 

    /** pathopen.e:570		include_Paths = append(config_inc_paths, current_dir())*/
    _26105 = _14current_dir();
    Ref(_26105);
    Append(&_46include_Paths_50861, _46config_inc_paths_50386, _26105);
    DeRef(_26105);
    _26105 = NOVALUE;

    /** pathopen.e:571		num_var = find("EUINC", cache_vars)*/
    _46num_var_50377 = find_from(_26107, _46cache_vars_50378, 1);

    /** pathopen.e:572		inc_path = getenv("EUINC")*/
    DeRefi(_inc_path_50867);
    _inc_path_50867 = EGetEnv(_26107);

    /** pathopen.e:573		if atom(inc_path) then*/
    _26110 = IS_ATOM(_inc_path_50867);
    if (_26110 == 0)
    {
        _26110 = NOVALUE;
        goto L2; // [52] 61
    }
    else{
        _26110 = NOVALUE;
    }

    /** pathopen.e:574			inc_path = ""*/
    RefDS(_22015);
    DeRefi(_inc_path_50867);
    _inc_path_50867 = _22015;
L2: 

    /** pathopen.e:576		status = check_cache("EUINC", inc_path)*/
    RefDS(_26107);
    Ref(_inc_path_50867);
    _status_50865 = _46check_cache(_26107, _inc_path_50867);
    if (!IS_ATOM_INT(_status_50865)) {
        _1 = (object)(DBL_PTR(_status_50865)->dbl);
        DeRefDS(_status_50865);
        _status_50865 = _1;
    }

    /** pathopen.e:577		if length(inc_path) then*/
    if (IS_SEQUENCE(_inc_path_50867)){
            _26112 = SEQ_PTR(_inc_path_50867)->length;
    }
    else {
        _26112 = 1;
    }
    if (_26112 == 0)
    {
        _26112 = NOVALUE;
        goto L3; // [75] 87
    }
    else{
        _26112 = NOVALUE;
    }

    /** pathopen.e:578			inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_50867, _inc_path_50867, 58);
L3: 

    /** pathopen.e:580		object eudir_path = get_eudir()*/
    _0 = _eudir_path_50886;
    _eudir_path_50886 = _13get_eudir();
    DeRef(_0);

    /** pathopen.e:581		if sequence(eudir_path) then*/
    _26115 = IS_SEQUENCE(_eudir_path_50886);
    if (_26115 == 0)
    {
        _26115 = NOVALUE;
        goto L4; // [97] 117
    }
    else{
        _26115 = NOVALUE;
    }

    /** pathopen.e:582			include_Paths = append(include_Paths, sprintf("%s/include", { eudir_path }))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_eudir_path_50886);
    ((intptr_t*)_2)[1] = _eudir_path_50886;
    _26117 = MAKE_SEQ(_1);
    _26118 = EPrintf(-9999999, _26116, _26117);
    DeRefDS(_26117);
    _26117 = NOVALUE;
    RefDS(_26118);
    Append(&_46include_Paths_50861, _46include_Paths_50861, _26118);
    DeRefDS(_26118);
    _26118 = NOVALUE;
L4: 

    /** pathopen.e:585		if status then*/
    if (_status_50865 == 0)
    {
        goto L5; // [119] 161
    }
    else{
    }

    /** pathopen.e:587			if cache_complete[num_var] then*/
    _2 = (object)SEQ_PTR(_46cache_complete_50384);
    _26120 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
    if (_26120 == 0)
    {
        _26120 = NOVALUE;
        goto L6; // [132] 144
    }
    else{
        _26120 = NOVALUE;
    }

    /** pathopen.e:588				goto "cache done"*/
    goto G7;
L6: 

    /** pathopen.e:590			pos = cache_delims[num_var]+1*/
    _2 = (object)SEQ_PTR(_46cache_delims_50385);
    _26122 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
    _pos_50866 = _26122 + 1;
    _26122 = NOVALUE;
    goto L8; // [158] 167
L5: 

    /** pathopen.e:592	        pos = 1*/
    _pos_50866 = 1;
L8: 

    /** pathopen.e:594		start_path = 0*/
    _start_path_50869 = 0;

    /** pathopen.e:595		for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_50867)){
            _26124 = SEQ_PTR(_inc_path_50867)->length;
    }
    else {
        _26124 = 1;
    }
    {
        object _p_50903;
        _p_50903 = _pos_50866;
L9: 
        if (_p_50903 > _26124){
            goto LA; // [179] 394
        }

        /** pathopen.e:596			if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (object)SEQ_PTR(_inc_path_50867);
        _26125 = (object)*(((s1_ptr)_2)->base + _p_50903);
        if (_26125 != 58)
        goto LB; // [194] 343

        /** pathopen.e:598				cache_delims[num_var] = p*/
        _2 = (object)SEQ_PTR(_46cache_delims_50385);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_delims_50385 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50377);
        *(intptr_t *)_2 = _p_50903;

        /** pathopen.e:600				end_path = p-1*/
        _end_path_50870 = _p_50903 - 1;

        /** pathopen.e:601				while end_path >= start_path and find(inc_path[end_path]," \t" & SLASH_CHARS) do*/
LC: 
        _26128 = (_end_path_50870 >= _start_path_50869);
        if (_26128 == 0) {
            goto LD; // [223] 257
        }
        _2 = (object)SEQ_PTR(_inc_path_50867);
        _26130 = (object)*(((s1_ptr)_2)->base + _end_path_50870);
        Concat((object_ptr)&_26131, _26081, _44SLASH_CHARS_20390);
        _26132 = find_from(_26130, _26131, 1);
        _26130 = NOVALUE;
        DeRefDS(_26131);
        _26131 = NOVALUE;
        if (_26132 == 0)
        {
            _26132 = NOVALUE;
            goto LD; // [243] 257
        }
        else{
            _26132 = NOVALUE;
        }

        /** pathopen.e:602					end_path -= 1*/
        _end_path_50870 = _end_path_50870 - 1;

        /** pathopen.e:603				end while*/
        goto LC; // [254] 219
LD: 

        /** pathopen.e:605				if start_path and end_path then*/
        if (_start_path_50869 == 0) {
            goto LE; // [259] 387
        }
        if (_end_path_50870 == 0)
        {
            goto LE; // [264] 387
        }
        else{
        }

        /** pathopen.e:606					full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_50868;
        RHS_Slice(_inc_path_50867, _start_path_50869, _end_path_50870);

        /** pathopen.e:607					cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_46cache_substrings_50380);
        _26136 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
        RefDS(_full_path_50868);
        Append(&_26137, _26136, _full_path_50868);
        _26136 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_substrings_50380);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_substrings_50380 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50377);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26137;
        if( _1 != _26137 ){
            DeRefDS(_1);
        }
        _26137 = NOVALUE;

        /** pathopen.e:608					cache_starts[num_var] &= start_path*/
        _2 = (object)SEQ_PTR(_46cache_starts_50381);
        _26138 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
        if (IS_SEQUENCE(_26138) && IS_ATOM(_start_path_50869)) {
            Append(&_26139, _26138, _start_path_50869);
        }
        else if (IS_ATOM(_26138) && IS_SEQUENCE(_start_path_50869)) {
        }
        else {
            Concat((object_ptr)&_26139, _26138, _start_path_50869);
            _26138 = NOVALUE;
        }
        _26138 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_starts_50381);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_starts_50381 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50377);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26139;
        if( _1 != _26139 ){
            DeRef(_1);
        }
        _26139 = NOVALUE;

        /** pathopen.e:609					cache_ends[num_var] &= end_path*/
        _2 = (object)SEQ_PTR(_46cache_ends_50382);
        _26140 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
        if (IS_SEQUENCE(_26140) && IS_ATOM(_end_path_50870)) {
            Append(&_26141, _26140, _end_path_50870);
        }
        else if (IS_ATOM(_26140) && IS_SEQUENCE(_end_path_50870)) {
        }
        else {
            Concat((object_ptr)&_26141, _26140, _end_path_50870);
            _26140 = NOVALUE;
        }
        _26140 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_ends_50382);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_ends_50382 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50377);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26141;
        if( _1 != _26141 ){
            DeRef(_1);
        }
        _26141 = NOVALUE;

        /** pathopen.e:610					ifdef WINDOWS then*/

        /** pathopen.e:620					start_path = 0*/
        _start_path_50869 = 0;
        goto LE; // [340] 387
LB: 

        /** pathopen.e:622			elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26142 = (_start_path_50869 == 0);
        if (_26142 == 0) {
            goto LF; // [348] 386
        }
        _2 = (object)SEQ_PTR(_inc_path_50867);
        _26144 = (object)*(((s1_ptr)_2)->base + _p_50903);
        _26145 = (_26144 != 32);
        _26144 = NOVALUE;
        if (_26145 == 0) {
            DeRef(_26146);
            _26146 = 0;
            goto L10; // [360] 376
        }
        _2 = (object)SEQ_PTR(_inc_path_50867);
        _26147 = (object)*(((s1_ptr)_2)->base + _p_50903);
        _26148 = (_26147 != 9);
        _26147 = NOVALUE;
        _26146 = (_26148 != 0);
L10: 
        if (_26146 == 0)
        {
            _26146 = NOVALUE;
            goto LF; // [377] 386
        }
        else{
            _26146 = NOVALUE;
        }

        /** pathopen.e:623				start_path = p*/
        _start_path_50869 = _p_50903;
LF: 
LE: 

        /** pathopen.e:625		end for*/
        _p_50903 = _p_50903 + 1;
        goto L9; // [389] 186
LA: 
        ;
    }

    /** pathopen.e:627	label "cache done"*/
G7:

    /** pathopen.e:628		include_Paths &= cache_substrings[num_var]*/
    _2 = (object)SEQ_PTR(_46cache_substrings_50380);
    _26149 = (object)*(((s1_ptr)_2)->base + _46num_var_50377);
    Concat((object_ptr)&_46include_Paths_50861, _46include_Paths_50861, _26149);
    _26149 = NOVALUE;

    /** pathopen.e:629		cache_complete[num_var] = 1*/
    _2 = (object)SEQ_PTR(_46cache_complete_50384);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _46cache_complete_50384 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _46num_var_50377);
    *(intptr_t *)_2 = 1;

    /** pathopen.e:631		ifdef WINDOWS then*/

    /** pathopen.e:640		return include_Paths*/
    RefDS(_46include_Paths_50861);
    DeRefi(_inc_path_50867);
    DeRefi(_full_path_50868);
    DeRef(_eudir_path_50886);
    DeRef(_26128);
    _26128 = NOVALUE;
    DeRef(_26142);
    _26142 = NOVALUE;
    _26125 = NOVALUE;
    DeRef(_26145);
    _26145 = NOVALUE;
    DeRef(_26148);
    _26148 = NOVALUE;
    return _46include_Paths_50861;
    ;
}


object _46e_path_find(object _name_50939)
{
    object _scan_result_50940 = NOVALUE;
    object _26159 = NOVALUE;
    object _26158 = NOVALUE;
    object _26157 = NOVALUE;
    object _26154 = NOVALUE;
    object _26153 = NOVALUE;
    object _26152 = NOVALUE;
    object _26151 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:656		if file_exists(name) then*/
    RefDS(_name_50939);
    _26151 = _14file_exists(_name_50939);
    if (_26151 == 0) {
        DeRef(_26151);
        _26151 = NOVALUE;
        goto L1; // [9] 19
    }
    else {
        if (!IS_ATOM_INT(_26151) && DBL_PTR(_26151)->dbl == 0.0){
            DeRef(_26151);
            _26151 = NOVALUE;
            goto L1; // [9] 19
        }
        DeRef(_26151);
        _26151 = NOVALUE;
    }
    DeRef(_26151);
    _26151 = NOVALUE;

    /** pathopen.e:657			return name*/
    DeRef(_scan_result_50940);
    return _name_50939;
L1: 

    /** pathopen.e:661		for i = 1 to length(SLASH_CHARS) do*/
    if (IS_SEQUENCE(_44SLASH_CHARS_20390)){
            _26152 = SEQ_PTR(_44SLASH_CHARS_20390)->length;
    }
    else {
        _26152 = 1;
    }
    {
        object _i_50945;
        _i_50945 = 1;
L2: 
        if (_i_50945 > _26152){
            goto L3; // [26] 63
        }

        /** pathopen.e:662			if find(SLASH_CHARS[i], name) then*/
        _2 = (object)SEQ_PTR(_44SLASH_CHARS_20390);
        _26153 = (object)*(((s1_ptr)_2)->base + _i_50945);
        _26154 = find_from(_26153, _name_50939, 1);
        _26153 = NOVALUE;
        if (_26154 == 0)
        {
            _26154 = NOVALUE;
            goto L4; // [46] 56
        }
        else{
            _26154 = NOVALUE;
        }

        /** pathopen.e:663				return -1*/
        DeRefDS(_name_50939);
        DeRef(_scan_result_50940);
        return -1;
L4: 

        /** pathopen.e:665		end for*/
        _i_50945 = _i_50945 + 1;
        goto L2; // [58] 33
L3: 
        ;
    }

    /** pathopen.e:667		scan_result = ScanPath(name, "PATH", 0)*/
    RefDS(_name_50939);
    RefDS(_26155);
    _0 = _scan_result_50940;
    _scan_result_50940 = _46ScanPath(_name_50939, _26155, 0);
    DeRef(_0);

    /** pathopen.e:668		if sequence(scan_result) then*/
    _26157 = IS_SEQUENCE(_scan_result_50940);
    if (_26157 == 0)
    {
        _26157 = NOVALUE;
        goto L5; // [76] 98
    }
    else{
        _26157 = NOVALUE;
    }

    /** pathopen.e:669			close(scan_result[2])*/
    _2 = (object)SEQ_PTR(_scan_result_50940);
    _26158 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_26158))
    EClose(_26158);
    else
    EClose((object)DBL_PTR(_26158)->dbl);
    _26158 = NOVALUE;

    /** pathopen.e:670			return scan_result[1]*/
    _2 = (object)SEQ_PTR(_scan_result_50940);
    _26159 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_26159);
    DeRefDS(_name_50939);
    DeRef(_scan_result_50940);
    return _26159;
L5: 

    /** pathopen.e:673		return -1*/
    DeRefDS(_name_50939);
    DeRef(_scan_result_50940);
    _26159 = NOVALUE;
    return -1;
    ;
}



// 0x6E9EB4FE
