// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _4allocate(object _n_1041, object _cleanup_1042)
{
    object _iaddr_1043 = NOVALUE;
    object _eaddr_1044 = NOVALUE;
    object _409 = NOVALUE;
    object _408 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:541		ifdef DATA_EXECUTE then*/

    /** machine.e:545			iaddr = eu:machine_func( memconst:M_ALLOC, n + memory:BORDER_SPACE * 2)*/
    _408 = 0;
    _409 = _n_1041 + 0;
    _408 = NOVALUE;
    DeRef(_iaddr_1043);
    _iaddr_1043 = machine(16, _409);
    _409 = NOVALUE;

    /** machine.e:546			eaddr = memory:prepare_block( iaddr, n, PAGE_READ_WRITE )*/
    Ref(_iaddr_1043);
    Ref(_5PAGE_READ_WRITE_264);
    _0 = _eaddr_1044;
    _eaddr_1044 = _6prepare_block(_iaddr_1043, _n_1041, _5PAGE_READ_WRITE_264);
    DeRef(_0);

    /** machine.e:548		if cleanup then*/

    /** machine.e:551		return eaddr*/
    DeRef(_iaddr_1043);
    return _eaddr_1044;
    ;
}


void _4free_pointer_array(object _pointers_array_1083)
{
    object _saved_1084 = NOVALUE;
    object _ptr_1085 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:661		atom saved = pointers_array*/
    Ref(_pointers_array_1083);
    DeRef(_saved_1084);
    _saved_1084 = _pointers_array_1083;

    /** machine.e:664		while ptr with entry do*/
    goto L1; // [8] 41
L2: 
    if (_ptr_1085 <= 0) {
        if (_ptr_1085 == 0) {
            goto L3; // [13] 51
        }
        else {
            if (!IS_ATOM_INT(_ptr_1085) && DBL_PTR(_ptr_1085)->dbl == 0.0){
                goto L3; // [13] 51
            }
        }
    }

    /** machine.e:665			memory:deallocate( ptr )*/

    /** memory.e:71		ifdef DATA_EXECUTE then*/

    /** memory.e:82	   	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _ptr_1085);

    /** memory.e:83	end procedure*/
    goto L4; // [27] 30
L4: 

    /** machine.e:666			pointers_array += ADDRESS_LENGTH*/
    _0 = _pointers_array_1083;
    if (IS_ATOM_INT(_pointers_array_1083)) {
        _pointers_array_1083 = _pointers_array_1083 + _4ADDRESS_LENGTH_1011;
        if ((object)((uintptr_t)_pointers_array_1083 + (uintptr_t)HIGH_BITS) >= 0){
            _pointers_array_1083 = NewDouble((eudouble)_pointers_array_1083);
        }
    }
    else {
        _pointers_array_1083 = NewDouble(DBL_PTR(_pointers_array_1083)->dbl + (eudouble)_4ADDRESS_LENGTH_1011);
    }
    DeRef(_0);

    /** machine.e:668		entry*/
L1: 

    /** machine.e:669			ptr = peek_pointer(pointers_array)*/
    DeRef(_ptr_1085);
    if (IS_ATOM_INT(_pointers_array_1083)) {
        _ptr_1085 = *(intptr_t *)_pointers_array_1083;
        if ((uintptr_t)_ptr_1085 > (uintptr_t)MAXINT){
            _ptr_1085 = NewDouble((eudouble)(uintptr_t)_ptr_1085);
        }
    }
    else {
        _ptr_1085 = *(uintptr_t *)(uintptr_t)(DBL_PTR(_pointers_array_1083)->dbl);
        if ((uintptr_t)_ptr_1085 > (uintptr_t)MAXINT){
            _ptr_1085 = NewDouble((eudouble)(uintptr_t)_ptr_1085);
        }
    }

    /** machine.e:670		end while*/
    goto L2; // [48] 11
L3: 

    /** machine.e:672		free(saved)*/
    Ref(_saved_1084);
    _4free(_saved_1084);

    /** machine.e:673	end procedure*/
    DeRef(_pointers_array_1083);
    DeRef(_saved_1084);
    DeRef(_ptr_1085);
    return;
    ;
}


object _4allocate_string(object _s_1201, object _cleanup_1202)
{
    object _mem_1203 = NOVALUE;
    object _482 = NOVALUE;
    object _481 = NOVALUE;
    object _479 = NOVALUE;
    object _478 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:2096		mem = allocate( length(s) + 1) -- Thanks to Igor*/
    if (IS_SEQUENCE(_s_1201)){
            _478 = SEQ_PTR(_s_1201)->length;
    }
    else {
        _478 = 1;
    }
    _479 = _478 + 1;
    _478 = NOVALUE;
    _0 = _mem_1203;
    _mem_1203 = _4allocate(_479, 0);
    DeRef(_0);
    _479 = NOVALUE;

    /** machine.e:2098		if mem then*/
    if (_mem_1203 == 0) {
        goto L1; // [19] 54
    }
    else {
        if (!IS_ATOM_INT(_mem_1203) && DBL_PTR(_mem_1203)->dbl == 0.0){
            goto L1; // [19] 54
        }
    }

    /** machine.e:2099			poke(mem, s)*/
    if (IS_ATOM_INT(_mem_1203)){
        poke_addr = (uint8_t *)_mem_1203;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_mem_1203)->dbl);
    }
    _1 = (object)SEQ_PTR(_s_1201);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke_addr++ = (uint8_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
        }
    }

    /** machine.e:2100			poke(mem+length(s), 0)  -- Thanks to Aku*/
    if (IS_SEQUENCE(_s_1201)){
            _481 = SEQ_PTR(_s_1201)->length;
    }
    else {
        _481 = 1;
    }
    if (IS_ATOM_INT(_mem_1203)) {
        _482 = _mem_1203 + _481;
        if ((object)((uintptr_t)_482 + (uintptr_t)HIGH_BITS) >= 0){
            _482 = NewDouble((eudouble)_482);
        }
    }
    else {
        _482 = NewDouble(DBL_PTR(_mem_1203)->dbl + (eudouble)_481);
    }
    _481 = NOVALUE;
    if (IS_ATOM_INT(_482)){
        poke_addr = (uint8_t *)_482;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_482)->dbl);
    }
    *poke_addr = (uint8_t)0;
    DeRef(_482);
    _482 = NOVALUE;

    /** machine.e:2101			if cleanup then*/
L1: 

    /** machine.e:2106		return mem*/
    DeRefDS(_s_1201);
    return _mem_1203;
    ;
}


void _4local_free_protected_memory(object _p_1214, object _s_1215)
{
    object _487 = NOVALUE;
    object _486 = NOVALUE;
    object _485 = NOVALUE;
    object _484 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:2110		ifdef WINDOWS then*/

    /** machine.e:2117			c_func( MPROTECT, { p, s, PAGE_READWRITE } )*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_p_1214);
    ((intptr_t*)_2)[1] = _p_1214;
    ((intptr_t*)_2)[2] = _s_1215;
    Ref(_5PAGE_READWRITE_258);
    ((intptr_t*)_2)[3] = _5PAGE_READWRITE_258;
    _484 = MAKE_SEQ(_1);
    _485 = call_c(1, _4MPROTECT_1029, _484);
    DeRefDS(_484);
    _484 = NOVALUE;

    /** machine.e:2118			machine_func( memconst:M_FREE, {p})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_p_1214);
    ((intptr_t*)_2)[1] = _p_1214;
    _486 = MAKE_SEQ(_1);
    _487 = machine(17, _486);
    DeRefDS(_486);
    _486 = NOVALUE;

    /** machine.e:2120	end procedure*/
    DeRef(_p_1214);
    DeRef(_485);
    _485 = NOVALUE;
    DeRef(_487);
    _487 = NOVALUE;
    return;
    ;
}


object _4allocate_protect(object _data_1223, object _wordsize_1224, object _protection_1226)
{
    object _iaddr_1227 = NOVALUE;
    object _eaddr_1229 = NOVALUE;
    object _size_1230 = NOVALUE;
    object _first_protection_1232 = NOVALUE;
    object _true_protection_1234 = NOVALUE;
    object _prepare_block_inlined_prepare_block_at_104_1249 = NOVALUE;
    object _msg_inlined_crash_at_193_1263 = NOVALUE;
    object _506 = NOVALUE;
    object _505 = NOVALUE;
    object _503 = NOVALUE;
    object _502 = NOVALUE;
    object _501 = NOVALUE;
    object _497 = NOVALUE;
    object _493 = NOVALUE;
    object _492 = NOVALUE;
    object _490 = NOVALUE;
    object _488 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:2158		atom iaddr = 0*/
    DeRef(_iaddr_1227);
    _iaddr_1227 = 0;

    /** machine.e:2160		integer size*/

    /** machine.e:2163		valid_memory_protection_constant true_protection = protection*/
    Ref(_protection_1226);
    DeRef(_true_protection_1234);
    _true_protection_1234 = _protection_1226;

    /** machine.e:2169		ifdef SAFE then	*/

    /** machine.e:2179		if atom(data) then*/
    _488 = 1;
    if (_488 == 0)
    {
        _488 = NOVALUE;
        goto L1; // [20] 39
    }
    else{
        _488 = NOVALUE;
    }

    /** machine.e:2180			size = data * wordsize*/
    _size_1230 = _data_1223 * 1;

    /** machine.e:2181			first_protection = true_protection*/
    Ref(_true_protection_1234);
    DeRef(_first_protection_1232);
    _first_protection_1232 = _true_protection_1234;
    goto L2; // [36] 58
L1: 

    /** machine.e:2183			size = length(data) * wordsize*/
    _490 = 1;
    _size_1230 = 1 * _wordsize_1224;
    _490 = NOVALUE;

    /** machine.e:2184			first_protection = PAGE_READ_WRITE*/
    Ref(_5PAGE_READ_WRITE_264);
    DeRef(_first_protection_1232);
    _first_protection_1232 = _5PAGE_READ_WRITE_264;
L2: 

    /** machine.e:2187		iaddr = local_allocate_protected_memory( size + memory:BORDER_SPACE * 2, first_protection )*/
    _492 = 0;
    _493 = _size_1230 + 0;
    _492 = NOVALUE;
    Ref(_first_protection_1232);
    _0 = _iaddr_1227;
    _iaddr_1227 = _4local_allocate_protected_memory(_493, _first_protection_1232);
    DeRef(_0);
    _493 = NOVALUE;

    /** machine.e:2188		if iaddr = 0 then*/
    if (binary_op_a(NOTEQ, _iaddr_1227, 0)){
        goto L3; // [79] 90
    }

    /** machine.e:2189			return 0*/
    DeRef(_protection_1226);
    DeRef(_iaddr_1227);
    DeRef(_eaddr_1229);
    DeRef(_first_protection_1232);
    DeRef(_true_protection_1234);
    return 0;
L3: 

    /** machine.e:2193		eaddr = memory:prepare_block( iaddr, size, protection )*/
    if (!IS_ATOM_INT(_protection_1226)) {
        _1 = (object)(DBL_PTR(_protection_1226)->dbl);
        DeRefDS(_protection_1226);
        _protection_1226 = _1;
    }

    /** memory.e:134		return addr*/
    Ref(_iaddr_1227);
    DeRef(_eaddr_1229);
    _eaddr_1229 = _iaddr_1227;

    /** machine.e:2195		if eaddr = 0 then*/
    if (binary_op_a(NOTEQ, _eaddr_1229, 0)){
        goto L4; // [102] 113
    }

    /** machine.e:2196			return eaddr*/
    DeRef(_protection_1226);
    DeRef(_iaddr_1227);
    DeRef(_first_protection_1232);
    DeRef(_true_protection_1234);
    return _eaddr_1229;
L4: 

    /** machine.e:2199		if sequence( data ) then*/
    _497 = 0;
    if (_497 == 0)
    {
        _497 = NOVALUE;
        goto L5; // [118] 198
    }
    else{
        _497 = NOVALUE;
    }

    /** machine.e:2200			switch wordsize do*/
    _0 = _wordsize_1224;
    switch ( _0 ){ 

        /** machine.e:2201				case 1 then*/
        case 1:

        /** machine.e:2202					eu:poke( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_1229)){
            poke_addr = (uint8_t *)_eaddr_1229;
        }
        else {
            poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_eaddr_1229)->dbl);
        }
        *poke_addr = (uint8_t)_data_1223;
        goto L6; // [137] 197

        /** machine.e:2204				case 2 then*/
        case 2:

        /** machine.e:2205					eu:poke2( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_1229)){
            poke2_addr = (uint16_t *)_eaddr_1229;
        }
        else {
            poke2_addr = (uint16_t *)(uintptr_t)(DBL_PTR(_eaddr_1229)->dbl);
        }
        *poke2_addr = (uint16_t)_data_1223;
        goto L6; // [148] 197

        /** machine.e:2207				case 4 then*/
        case 4:

        /** machine.e:2208					eu:poke4( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_1229)){
            poke4_addr = (uint32_t *)_eaddr_1229;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_eaddr_1229)->dbl);
        }
        *poke4_addr = (uint32_t)_data_1223;
        goto L6; // [159] 197

        /** machine.e:2210				case 8 then*/
        case 8:

        /** machine.e:2211					poke8( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_1229)){
            poke8_addr = (uint64_t *)_eaddr_1229;
        }
        else {
            poke8_addr = (uint64_t *)(uintptr_t)(DBL_PTR(_eaddr_1229)->dbl);
        }
        *poke8_addr = (uint64_t)_data_1223;
        goto L6; // [170] 197

        /** machine.e:2213				case else*/
        default:

        /** machine.e:2214					error:crash("Parameter error: Wrong word size %d in allocate_protect().", wordsize)*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_193_1263);
        _msg_inlined_crash_at_193_1263 = EPrintf(-9999999, _500, _wordsize_1224);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_193_1263);

        /** error.e:53	end procedure*/
        goto L7; // [191] 194
L7: 
        DeRefi(_msg_inlined_crash_at_193_1263);
        _msg_inlined_crash_at_193_1263 = NOVALUE;
    ;}L6: 
L5: 

    /** machine.e:2218		ifdef SAFE then*/

    /** machine.e:2237		if local_change_protection_on_protected_memory( iaddr, size + memory:BORDER_SPACE * 2, true_protection ) = -1 then*/
    _501 = 0;
    _502 = _size_1230 + 0;
    _501 = NOVALUE;
    Ref(_iaddr_1227);
    Ref(_true_protection_1234);
    _503 = _4local_change_protection_on_protected_memory(_iaddr_1227, _502, _true_protection_1234);
    _502 = NOVALUE;
    if (binary_op_a(NOTEQ, _503, -1)){
        DeRef(_503);
        _503 = NOVALUE;
        goto L8; // [216] 240
    }
    DeRef(_503);
    _503 = NOVALUE;

    /** machine.e:2238			local_free_protected_memory( iaddr, size + memory:BORDER_SPACE * 2 )*/
    _505 = 0;
    _506 = _size_1230 + 0;
    _505 = NOVALUE;
    Ref(_iaddr_1227);
    _4local_free_protected_memory(_iaddr_1227, _506);
    _506 = NOVALUE;

    /** machine.e:2239			eaddr = 0*/
    DeRef(_eaddr_1229);
    _eaddr_1229 = 0;
L8: 

    /** machine.e:2242		return eaddr*/
    DeRef(_protection_1226);
    DeRef(_iaddr_1227);
    DeRef(_first_protection_1232);
    DeRef(_true_protection_1234);
    return _eaddr_1229;
    ;
}


object _4local_allocate_protected_memory(object _s_1274, object _first_protection_1275)
{
    object _ptr_1276 = NOVALUE;
    object _fail_1282 = NOVALUE;
    object _508 = NOVALUE;
    object _507 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_first_protection_1275)) {
        _1 = (object)(DBL_PTR(_first_protection_1275)->dbl);
        DeRefDS(_first_protection_1275);
        _first_protection_1275 = _1;
    }

    /** machine.e:2247		ifdef WINDOWS then     */

    /** machine.e:2255			atom ptr = c_func( MMAP, { 0, s, first_protection, or_bits( MAP_ANONYMOUS, MAP_PRIVATE ), -1, 0 })*/
    {uintptr_t tu;
         tu = (uintptr_t)32 | (uintptr_t)2;
         _507 = MAKE_UINT(tu);
    }
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    ((intptr_t*)_2)[2] = _s_1274;
    ((intptr_t*)_2)[3] = _first_protection_1275;
    ((intptr_t*)_2)[4] = _507;
    ((intptr_t*)_2)[5] = -1;
    ((intptr_t*)_2)[6] = 0;
    _508 = MAKE_SEQ(_1);
    _507 = NOVALUE;
    DeRef(_ptr_1276);
    _ptr_1276 = call_c(1, _4MMAP_1021, _508);
    DeRefDS(_508);
    _508 = NOVALUE;

    /** machine.e:2257			ifdef LINUX or FREEBSD then*/

    /** machine.e:2258				if ptr = MAP_FAILED then*/
    if (binary_op_a(NOTEQ, _ptr_1276, _4MAP_FAILED_1035)){
        goto L1; // [35] 46
    }

    /** machine.e:2259					return 0*/
    DeRef(_ptr_1276);
    return 0;
L1: 

    /** machine.e:2264			integer fail = local_change_protection_on_protected_memory( ptr, s, first_protection )*/
    Ref(_ptr_1276);
    _fail_1282 = _4local_change_protection_on_protected_memory(_ptr_1276, _s_1274, _first_protection_1275);
    if (!IS_ATOM_INT(_fail_1282)) {
        _1 = (object)(DBL_PTR(_fail_1282)->dbl);
        DeRefDS(_fail_1282);
        _fail_1282 = _1;
    }

    /** machine.e:2265			return ptr*/
    return _ptr_1276;
    ;
}


object _4local_change_protection_on_protected_memory(object _p_1287, object _s_1288, object _new_protection_1289)
{
    object _fail_1290 = NOVALUE;
    object _msg_inlined_crash_at_39_1298 = NOVALUE;
    object _data_inlined_crash_at_36_1297 = NOVALUE;
    object _515 = NOVALUE;
    object _512 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_new_protection_1289)) {
        _1 = (object)(DBL_PTR(_new_protection_1289)->dbl);
        DeRefDS(_new_protection_1289);
        _new_protection_1289 = _1;
    }

    /** machine.e:2271		ifdef WINDOWS then*/

    /** machine.e:2280			integer fail = c_func( MPROTECT, { p, s, new_protection } )*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_p_1287);
    ((intptr_t*)_2)[1] = _p_1287;
    ((intptr_t*)_2)[2] = _s_1288;
    ((intptr_t*)_2)[3] = _new_protection_1289;
    _512 = MAKE_SEQ(_1);
    _fail_1290 = call_c(1, _4MPROTECT_1029, _512);
    DeRefDS(_512);
    _512 = NOVALUE;
    if (!IS_ATOM_INT(_fail_1290)) {
        _1 = (object)(DBL_PTR(_fail_1290)->dbl);
        DeRefDS(_fail_1290);
        _fail_1290 = _1;
    }

    /** machine.e:2281			if fail then*/
    if (_fail_1290 == 0)
    {
        goto L1; // [26] 59
    }
    else{
    }

    /** machine.e:2282					error:crash( "Could not change memory protection at 0x%x (%d bytes) to %d", { p, s, new_protection } )*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_p_1287);
    ((intptr_t*)_2)[1] = _p_1287;
    ((intptr_t*)_2)[2] = _s_1288;
    ((intptr_t*)_2)[3] = _new_protection_1289;
    _515 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_36_1297);
    _data_inlined_crash_at_36_1297 = _515;
    _515 = NOVALUE;

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_39_1298);
    _msg_inlined_crash_at_39_1298 = EPrintf(-9999999, _514, _data_inlined_crash_at_36_1297);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_39_1298);

    /** error.e:53	end procedure*/
    goto L2; // [53] 56
L2: 
    DeRef(_data_inlined_crash_at_36_1297);
    _data_inlined_crash_at_36_1297 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_39_1298);
    _msg_inlined_crash_at_39_1298 = NOVALUE;
L1: 

    /** machine.e:2284			return fail*/
    DeRef(_p_1287);
    return _fail_1290;
    ;
}


void _4free(object _addr_1301)
{
    object _msg_inlined_crash_at_27_1310 = NOVALUE;
    object _data_inlined_crash_at_24_1309 = NOVALUE;
    object _addr_inlined_deallocate_at_64_1316 = NOVALUE;
    object _msg_inlined_crash_at_106_1321 = NOVALUE;
    object _522 = NOVALUE;
    object _521 = NOVALUE;
    object _520 = NOVALUE;
    object _519 = NOVALUE;
    object _517 = NOVALUE;
    object _516 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:2319		if types:number_array (addr) then*/
    Ref(_addr_1301);
    _516 = _9number_array(_addr_1301);
    if (_516 == 0) {
        DeRef(_516);
        _516 = NOVALUE;
        goto L1; // [7] 97
    }
    else {
        if (!IS_ATOM_INT(_516) && DBL_PTR(_516)->dbl == 0.0){
            DeRef(_516);
            _516 = NOVALUE;
            goto L1; // [7] 97
        }
        DeRef(_516);
        _516 = NOVALUE;
    }
    DeRef(_516);
    _516 = NOVALUE;

    /** machine.e:2320			if types:ascii_string(addr) then*/
    Ref(_addr_1301);
    _517 = _9ascii_string(_addr_1301);
    if (_517 == 0) {
        DeRef(_517);
        _517 = NOVALUE;
        goto L2; // [16] 47
    }
    else {
        if (!IS_ATOM_INT(_517) && DBL_PTR(_517)->dbl == 0.0){
            DeRef(_517);
            _517 = NOVALUE;
            goto L2; // [16] 47
        }
        DeRef(_517);
        _517 = NOVALUE;
    }
    DeRef(_517);
    _517 = NOVALUE;

    /** machine.e:2321				error:crash("free(\"%s\") is not a valid address", {addr})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_addr_1301);
    ((intptr_t*)_2)[1] = _addr_1301;
    _519 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_24_1309);
    _data_inlined_crash_at_24_1309 = _519;
    _519 = NOVALUE;

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_27_1310);
    _msg_inlined_crash_at_27_1310 = EPrintf(-9999999, _518, _data_inlined_crash_at_24_1309);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_27_1310);

    /** error.e:53	end procedure*/
    goto L3; // [41] 44
L3: 
    DeRef(_data_inlined_crash_at_24_1309);
    _data_inlined_crash_at_24_1309 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_27_1310);
    _msg_inlined_crash_at_27_1310 = NOVALUE;
L2: 

    /** machine.e:2324			for i = 1 to length(addr) do*/
    if (IS_SEQUENCE(_addr_1301)){
            _520 = SEQ_PTR(_addr_1301)->length;
    }
    else {
        _520 = 1;
    }
    {
        object _i_1312;
        _i_1312 = 1;
L4: 
        if (_i_1312 > _520){
            goto L5; // [52] 89
        }

        /** machine.e:2325				memory:deallocate( addr[i] )*/
        _2 = (object)SEQ_PTR(_addr_1301);
        _521 = (object)*(((s1_ptr)_2)->base + _i_1312);
        Ref(_521);
        DeRef(_addr_inlined_deallocate_at_64_1316);
        _addr_inlined_deallocate_at_64_1316 = _521;
        _521 = NOVALUE;

        /** memory.e:71		ifdef DATA_EXECUTE then*/

        /** memory.e:82	   	machine_proc( memconst:M_FREE, addr)*/
        machine(17, _addr_inlined_deallocate_at_64_1316);

        /** memory.e:83	end procedure*/
        goto L6; // [77] 80
L6: 
        DeRef(_addr_inlined_deallocate_at_64_1316);
        _addr_inlined_deallocate_at_64_1316 = NOVALUE;

        /** machine.e:2326			end for*/
        _i_1312 = _i_1312 + 1;
        goto L4; // [84] 59
L5: 
        ;
    }

    /** machine.e:2327			return*/
    DeRef(_addr_1301);
    return;
    goto L7; // [94] 127
L1: 

    /** machine.e:2328		elsif sequence(addr) then*/
    _522 = IS_SEQUENCE(_addr_1301);
    if (_522 == 0)
    {
        _522 = NOVALUE;
        goto L8; // [102] 126
    }
    else{
        _522 = NOVALUE;
    }

    /** machine.e:2329			error:crash("free() called with nested sequence")*/

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_106_1321);
    _msg_inlined_crash_at_106_1321 = EPrintf(-9999999, _523, _5);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_106_1321);

    /** error.e:53	end procedure*/
    goto L9; // [120] 123
L9: 
    DeRefi(_msg_inlined_crash_at_106_1321);
    _msg_inlined_crash_at_106_1321 = NOVALUE;
L8: 
L7: 

    /** machine.e:2332		if addr = 0 then*/
    if (binary_op_a(NOTEQ, _addr_1301, 0)){
        goto LA; // [129] 139
    }

    /** machine.e:2335			return*/
    DeRef(_addr_1301);
    return;
LA: 

    /** machine.e:2338		memory:deallocate( addr )*/

    /** memory.e:71		ifdef DATA_EXECUTE then*/

    /** memory.e:82	   	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _addr_1301);

    /** memory.e:83	end procedure*/
    goto LB; // [150] 153
LB: 

    /** machine.e:2339	end procedure*/
    DeRef(_addr_1301);
    return;
    ;
}



// 0xEE3BCD51
