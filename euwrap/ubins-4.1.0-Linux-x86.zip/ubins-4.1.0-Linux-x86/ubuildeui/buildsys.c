// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _55update_checksum(object _raw_data_45452)
{
    object _23633 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:213		cfile_check = xor_bits(cfile_check, hash( raw_data, stdhash:HSIEH32))*/
    _23633 = calc_hash(_raw_data_45452, -5);
    _0 = _55cfile_check_45433;
    if (IS_ATOM_INT(_55cfile_check_45433) && IS_ATOM_INT(_23633)) {
        {uintptr_t tu;
             tu = (uintptr_t)_55cfile_check_45433 ^ (uintptr_t)_23633;
             _55cfile_check_45433 = MAKE_UINT(tu);
        }
    }
    else {
        if (IS_ATOM_INT(_55cfile_check_45433)) {
            temp_d.dbl = (eudouble)_55cfile_check_45433;
            _55cfile_check_45433 = Dxor_bits(&temp_d, DBL_PTR(_23633));
        }
        else {
            if (IS_ATOM_INT(_23633)) {
                temp_d.dbl = (eudouble)_23633;
                _55cfile_check_45433 = Dxor_bits(DBL_PTR(_55cfile_check_45433), &temp_d);
            }
            else
            _55cfile_check_45433 = Dxor_bits(DBL_PTR(_55cfile_check_45433), DBL_PTR(_23633));
        }
    }
    DeRef(_0);
    DeRef(_23633);
    _23633 = NOVALUE;

    /** buildsys.e:214	end procedure*/
    DeRef(_raw_data_45452);
    return;
    ;
}


void _55write_checksum(object _file_45457)
{
    object _0, _1, _2;
    

    /** buildsys.e:219		printf( file, "\n// 0x%08x\n", cfile_check )*/
    EPrintf(_file_45457, _23635, _55cfile_check_45433);

    /** buildsys.e:220		cfile_check = 0*/
    DeRef(_55cfile_check_45433);
    _55cfile_check_45433 = 0;

    /** buildsys.e:221	end procedure*/
    return;
    ;
}


object _55adjust_for_command_line_passing(object _long_path_45505)
{
    object _slash_45506 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:310		if compiler_type = COMPILER_GCC then*/

    /** buildsys.e:312		elsif compiler_type = COMPILER_WATCOM then*/

    /** buildsys.e:315			slash = SLASH*/
    _slash_45506 = 47;

    /** buildsys.e:317		ifdef UNIX then*/

    /** buildsys.e:318			return long_path*/
    return _long_path_45505;
    ;
}


object _55adjust_for_build_file(object _long_path_45515)
{
    object _short_path_45516 = NOVALUE;
    object _23665 = NOVALUE;
    object _23664 = NOVALUE;
    object _23663 = NOVALUE;
    object _23662 = NOVALUE;
    object _23661 = NOVALUE;
    object _23660 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:355	    object short_path = adjust_for_command_line_passing(long_path)*/
    RefDS(_long_path_45515);
    _0 = _short_path_45516;
    _short_path_45516 = _55adjust_for_command_line_passing(_long_path_45515);
    DeRef(_0);

    /** buildsys.e:356	    if atom(short_path) then*/
    _23660 = IS_ATOM(_short_path_45516);
    if (_23660 == 0)
    {
        _23660 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _23660 = NOVALUE;
    }

    /** buildsys.e:357	    	return short_path*/
    DeRefDS(_long_path_45515);
    return _short_path_45516;
L1: 

    /** buildsys.e:359		if compiler_type = COMPILER_GCC and build_system_type != BUILD_DIRECT and TWINDOWS then*/
    _23661 = (0 == 1);
    if (_23661 == 0) {
        _23662 = 0;
        goto L2; // [32] 46
    }
    _23663 = (3 != 3);
    _23662 = (_23663 != 0);
L2: 
    if (_23662 == 0) {
        goto L3; // [46] 69
    }
    goto L3; // [53] 69

    /** buildsys.e:360			return windows_to_mingw_path(short_path)*/
    Ref(_short_path_45516);
    _23665 = _55windows_to_mingw_path(_short_path_45516);
    DeRefDS(_long_path_45515);
    DeRef(_short_path_45516);
    DeRef(_23661);
    _23661 = NOVALUE;
    DeRef(_23663);
    _23663 = NOVALUE;
    return _23665;
    goto L4; // [66] 76
L3: 

    /** buildsys.e:362			return short_path*/
    DeRefDS(_long_path_45515);
    DeRef(_23661);
    _23661 = NOVALUE;
    DeRef(_23663);
    _23663 = NOVALUE;
    DeRef(_23665);
    _23665 = NOVALUE;
    return _short_path_45516;
L4: 
    ;
}


object _55setup_build()
{
    object _c_exe_45531 = NOVALUE;
    object _c_flags_45532 = NOVALUE;
    object _l_exe_45533 = NOVALUE;
    object _l_flags_45534 = NOVALUE;
    object _obj_ext_45535 = NOVALUE;
    object _exe_ext_45536 = NOVALUE;
    object _l_flags_begin_45537 = NOVALUE;
    object _rc_comp_45538 = NOVALUE;
    object _l_names_45539 = NOVALUE;
    object _l_ext_45540 = NOVALUE;
    object _t_slash_45541 = NOVALUE;
    object _eudir_45583 = NOVALUE;
    object _locations_45608 = NOVALUE;
    object _compile_dir_45660 = NOVALUE;
    object _bits_45671 = NOVALUE;
    object _m_flag_45681 = NOVALUE;
    object _23834 = NOVALUE;
    object _23831 = NOVALUE;
    object _23830 = NOVALUE;
    object _23827 = NOVALUE;
    object _23826 = NOVALUE;
    object _23823 = NOVALUE;
    object _23822 = NOVALUE;
    object _23819 = NOVALUE;
    object _23818 = NOVALUE;
    object _23811 = NOVALUE;
    object _23810 = NOVALUE;
    object _23805 = NOVALUE;
    object _23804 = NOVALUE;
    object _23799 = NOVALUE;
    object _23798 = NOVALUE;
    object _23795 = NOVALUE;
    object _23794 = NOVALUE;
    object _23782 = NOVALUE;
    object _23781 = NOVALUE;
    object _23766 = NOVALUE;
    object _23765 = NOVALUE;
    object _23757 = NOVALUE;
    object _23755 = NOVALUE;
    object _23754 = NOVALUE;
    object _23753 = NOVALUE;
    object _23752 = NOVALUE;
    object _23748 = NOVALUE;
    object _23747 = NOVALUE;
    object _23733 = NOVALUE;
    object _23732 = NOVALUE;
    object _23729 = NOVALUE;
    object _23717 = NOVALUE;
    object _23715 = NOVALUE;
    object _23714 = NOVALUE;
    object _23713 = NOVALUE;
    object _23712 = NOVALUE;
    object _23711 = NOVALUE;
    object _23710 = NOVALUE;
    object _23709 = NOVALUE;
    object _23708 = NOVALUE;
    object _23707 = NOVALUE;
    object _23706 = NOVALUE;
    object _23701 = NOVALUE;
    object _23698 = NOVALUE;
    object _23697 = NOVALUE;
    object _23696 = NOVALUE;
    object _23693 = NOVALUE;
    object _23692 = NOVALUE;
    object _23691 = NOVALUE;
    object _23688 = NOVALUE;
    object _23684 = NOVALUE;
    object _23683 = NOVALUE;
    object _23681 = NOVALUE;
    object _23680 = NOVALUE;
    object _23679 = NOVALUE;
    object _23678 = NOVALUE;
    object _23671 = NOVALUE;
    object _23670 = NOVALUE;
    object _23669 = NOVALUE;
    object _23668 = NOVALUE;
    object _23667 = NOVALUE;
    object _23666 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:373			c_exe   = "",*/
    RefDS(_22015);
    DeRef(_c_exe_45531);
    _c_exe_45531 = _22015;

    /** buildsys.e:374			c_flags = "",*/
    RefDS(_22015);
    DeRef(_c_flags_45532);
    _c_flags_45532 = _22015;

    /** buildsys.e:375			l_exe   = "",*/
    RefDS(_22015);
    DeRef(_l_exe_45533);
    _l_exe_45533 = _22015;

    /** buildsys.e:376			l_flags = "",*/
    RefDS(_22015);
    DeRefi(_l_flags_45534);
    _l_flags_45534 = _22015;

    /** buildsys.e:377			obj_ext = "",*/
    RefDS(_22015);
    DeRefi(_obj_ext_45535);
    _obj_ext_45535 = _22015;

    /** buildsys.e:378			exe_ext = "",*/
    RefDS(_22015);
    DeRefi(_exe_ext_45536);
    _exe_ext_45536 = _22015;

    /** buildsys.e:379			l_flags_begin = "",*/
    RefDS(_22015);
    DeRefi(_l_flags_begin_45537);
    _l_flags_begin_45537 = _22015;

    /** buildsys.e:380			rc_comp = "",*/
    RefDS(_22015);
    DeRef(_rc_comp_45538);
    _rc_comp_45538 = _22015;

    /** buildsys.e:385		if dll_option*/
    if (_57dll_option_42590 == 0) {
        _23666 = 0;
        goto L1; // [61] 78
    }
    _23667 = 0;
    _23668 = (0 > 0);
    _23667 = NOVALUE;
    _23666 = (_23668 != 0);
L1: 
    if (_23666 == 0) {
        goto L2; // [78] 101
    }
    _23670 = (0 == 0);
    if (_23670 == 0)
    {
        DeRef(_23670);
        _23670 = NOVALUE;
        goto L2; // [88] 101
    }
    else{
        DeRef(_23670);
        _23670 = NOVALUE;
    }

    /** buildsys.e:388			user_library = user_pic_library*/
    RefDS(_57user_pic_library_42603);
    DeRef(_57user_library_42602);
    _57user_library_42602 = _57user_pic_library_42603;
L2: 

    /** buildsys.e:391		if length(user_library) = 0 then*/
    if (IS_SEQUENCE(_57user_library_42602)){
            _23671 = SEQ_PTR(_57user_library_42602)->length;
    }
    else {
        _23671 = 1;
    }
    if (_23671 != 0)
    goto L3; // [108] 456

    /** buildsys.e:392			if debug_option then*/
    if (_57debug_option_42600 == 0)
    {
        goto L4; // [116] 128
    }
    else{
    }

    /** buildsys.e:393				l_names = { "eudbg", "eu" }*/
    RefDS(_23674);
    RefDS(_23673);
    DeRef(_l_names_45539);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _23673;
    ((intptr_t *)_2)[2] = _23674;
    _l_names_45539 = MAKE_SEQ(_1);
    goto L5; // [125] 135
L4: 

    /** buildsys.e:395				l_names = { "eu", "eudbg" }*/
    RefDS(_23673);
    RefDS(_23674);
    DeRef(_l_names_45539);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _23674;
    ((intptr_t *)_2)[2] = _23673;
    _l_names_45539 = MAKE_SEQ(_1);
L5: 

    /** buildsys.e:400			if TUNIX or compiler_type = COMPILER_GCC then*/
    if (_44TUNIX_20374 != 0) {
        goto L6; // [139] 154
    }
    _23678 = (0 == 1);
    if (_23678 == 0)
    {
        DeRef(_23678);
        _23678 = NOVALUE;
        goto L7; // [150] 224
    }
    else{
        DeRef(_23678);
        _23678 = NOVALUE;
    }
L6: 

    /** buildsys.e:401				l_ext = "a"*/
    RefDS(_22296);
    DeRefi(_l_ext_45540);
    _l_ext_45540 = _22296;

    /** buildsys.e:402				t_slash = "/"*/
    RefDS(_23596);
    DeRefi(_t_slash_45541);
    _t_slash_45541 = _23596;

    /** buildsys.e:403				if dll_option and not TWINDOWS then*/
    if (_57dll_option_42590 == 0) {
        goto L8; // [172] 247
    }
    _23680 = (0 == 0);
    if (_23680 == 0)
    {
        DeRef(_23680);
        _23680 = NOVALUE;
        goto L8; // [182] 247
    }
    else{
        DeRef(_23680);
        _23680 = NOVALUE;
    }

    /** buildsys.e:404					for i = 1 to length( l_names ) do*/
    if (IS_SEQUENCE(_l_names_45539)){
            _23681 = SEQ_PTR(_l_names_45539)->length;
    }
    else {
        _23681 = 1;
    }
    {
        object _i_45574;
        _i_45574 = 1;
L9: 
        if (_i_45574 > _23681){
            goto LA; // [192] 220
        }

        /** buildsys.e:406						l_names[i] &= "so"*/
        _2 = (object)SEQ_PTR(_l_names_45539);
        _23683 = (object)*(((s1_ptr)_2)->base + _i_45574);
        if (IS_SEQUENCE(_23683) && IS_ATOM(_23682)) {
        }
        else if (IS_ATOM(_23683) && IS_SEQUENCE(_23682)) {
            Ref(_23683);
            Prepend(&_23684, _23682, _23683);
        }
        else {
            Concat((object_ptr)&_23684, _23683, _23682);
            _23683 = NOVALUE;
        }
        _23683 = NOVALUE;
        _2 = (object)SEQ_PTR(_l_names_45539);
        _2 = (object)(((s1_ptr)_2)->base + _i_45574);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _23684;
        if( _1 != _23684 ){
            DeRef(_1);
        }
        _23684 = NOVALUE;

        /** buildsys.e:407					end for*/
        _i_45574 = _i_45574 + 1;
        goto L9; // [215] 199
LA: 
        ;
    }
    goto L8; // [221] 247
L7: 

    /** buildsys.e:409			elsif TWINDOWS then*/
L8: 

    /** buildsys.e:414			object eudir = get_eucompiledir()*/
    _0 = _eudir_45583;
    _eudir_45583 = _57get_eucompiledir();
    DeRef(_0);

    /** buildsys.e:415			if not file_exists(eudir) then*/
    Ref(_eudir_45583);
    _23688 = _14file_exists(_eudir_45583);
    if (IS_ATOM_INT(_23688)) {
        if (_23688 != 0){
            DeRef(_23688);
            _23688 = NOVALUE;
            goto LB; // [258] 279
        }
    }
    else {
        if (DBL_PTR(_23688)->dbl != 0.0){
            DeRef(_23688);
            _23688 = NOVALUE;
            goto LB; // [258] 279
        }
    }
    DeRef(_23688);
    _23688 = NOVALUE;

    /** buildsys.e:416				printf(2,"Supplied directory \'%s\' is not a valid EUDIR\n",{get_eucompiledir()})*/
    _23691 = _57get_eucompiledir();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23691;
    _23692 = MAKE_SEQ(_1);
    _23691 = NOVALUE;
    EPrintf(2, _23690, _23692);
    DeRefDS(_23692);
    _23692 = NOVALUE;

    /** buildsys.e:417				abort(1)*/
    UserCleanup(1);
LB: 

    /** buildsys.e:419			for tk = 1 to length(l_names) label "translation kind" do*/
    if (IS_SEQUENCE(_l_names_45539)){
            _23693 = SEQ_PTR(_l_names_45539)->length;
    }
    else {
        _23693 = 1;
    }
    {
        object _tk_45595;
        _tk_45595 = 1;
LC: 
        if (_tk_45595 > _23693){
            goto LD; // [286] 455
        }

        /** buildsys.e:420				user_library = eudir & sprintf("%sbin%s%s.%s",{t_slash, t_slash, l_names[tk],l_ext})*/
        _2 = (object)SEQ_PTR(_l_names_45539);
        _23696 = (object)*(((s1_ptr)_2)->base + _tk_45595);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        RefDSn(_t_slash_45541, 2);
        ((intptr_t*)_2)[1] = _t_slash_45541;
        ((intptr_t*)_2)[2] = _t_slash_45541;
        Ref(_23696);
        ((intptr_t*)_2)[3] = _23696;
        RefDS(_l_ext_45540);
        ((intptr_t*)_2)[4] = _l_ext_45540;
        _23697 = MAKE_SEQ(_1);
        _23696 = NOVALUE;
        _23698 = EPrintf(-9999999, _23695, _23697);
        DeRefDS(_23697);
        _23697 = NOVALUE;
        if (IS_SEQUENCE(_eudir_45583) && IS_ATOM(_23698)) {
        }
        else if (IS_ATOM(_eudir_45583) && IS_SEQUENCE(_23698)) {
            Ref(_eudir_45583);
            Prepend(&_57user_library_42602, _23698, _eudir_45583);
        }
        else {
            Concat((object_ptr)&_57user_library_42602, _eudir_45583, _23698);
        }
        DeRefDS(_23698);
        _23698 = NOVALUE;

        /** buildsys.e:421				if TUNIX or compiler_type = COMPILER_GCC then*/
        if (_44TUNIX_20374 != 0) {
            goto LE; // [324] 339
        }
        _23701 = (0 == 1);
        if (_23701 == 0)
        {
            DeRef(_23701);
            _23701 = NOVALUE;
            goto LF; // [335] 430
        }
        else{
            DeRef(_23701);
            _23701 = NOVALUE;
        }
LE: 

        /** buildsys.e:422					ifdef UNIX then*/

        /** buildsys.e:423						sequence locations = { "/usr/local/lib/%s.a", "/usr/lib/%s.a"}*/
        RefDS(_23703);
        RefDS(_23702);
        DeRef(_locations_45608);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23702;
        ((intptr_t *)_2)[2] = _23703;
        _locations_45608 = MAKE_SEQ(_1);

        /** buildsys.e:424						if match( "/share/euphoria", eudir ) then*/
        _23706 = e_match_from(_23705, _eudir_45583, 1);
        if (_23706 == 0)
        {
            _23706 = NOVALUE;
            goto L10; // [354] 429
        }
        else{
            _23706 = NOVALUE;
        }

        /** buildsys.e:426							for i = 1 to length(locations) do*/
        _23707 = 2;
        {
            object _i_45616;
            _i_45616 = 1;
L11: 
            if (_i_45616 > 2){
                goto L12; // [362] 428
            }

            /** buildsys.e:427								if file_exists( sprintf(locations[i],{l_names[tk]}) ) then*/
            _2 = (object)SEQ_PTR(_locations_45608);
            _23708 = (object)*(((s1_ptr)_2)->base + _i_45616);
            _2 = (object)SEQ_PTR(_l_names_45539);
            _23709 = (object)*(((s1_ptr)_2)->base + _tk_45595);
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_23709);
            ((intptr_t*)_2)[1] = _23709;
            _23710 = MAKE_SEQ(_1);
            _23709 = NOVALUE;
            _23711 = EPrintf(-9999999, _23708, _23710);
            _23708 = NOVALUE;
            DeRefDS(_23710);
            _23710 = NOVALUE;
            _23712 = _14file_exists(_23711);
            _23711 = NOVALUE;
            if (_23712 == 0) {
                DeRef(_23712);
                _23712 = NOVALUE;
                goto L13; // [391] 421
            }
            else {
                if (!IS_ATOM_INT(_23712) && DBL_PTR(_23712)->dbl == 0.0){
                    DeRef(_23712);
                    _23712 = NOVALUE;
                    goto L13; // [391] 421
                }
                DeRef(_23712);
                _23712 = NOVALUE;
            }
            DeRef(_23712);
            _23712 = NOVALUE;

            /** buildsys.e:428									user_library = sprintf(locations[i],{l_names[tk]})*/
            _2 = (object)SEQ_PTR(_locations_45608);
            _23713 = (object)*(((s1_ptr)_2)->base + _i_45616);
            _2 = (object)SEQ_PTR(_l_names_45539);
            _23714 = (object)*(((s1_ptr)_2)->base + _tk_45595);
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_23714);
            ((intptr_t*)_2)[1] = _23714;
            _23715 = MAKE_SEQ(_1);
            _23714 = NOVALUE;
            DeRef(_57user_library_42602);
            _57user_library_42602 = EPrintf(-9999999, _23713, _23715);
            _23713 = NOVALUE;
            DeRefDS(_23715);
            _23715 = NOVALUE;

            /** buildsys.e:429									exit "translation kind"*/
            DeRefDS(_locations_45608);
            _locations_45608 = NOVALUE;
            goto LD; // [418] 455
L13: 

            /** buildsys.e:431							end for*/
            _i_45616 = _i_45616 + 1;
            goto L11; // [423] 369
L12: 
            ;
        }
L10: 
LF: 
        DeRef(_locations_45608);
        _locations_45608 = NOVALUE;

        /** buildsys.e:436				if file_exists(user_library) then*/
        RefDS(_57user_library_42602);
        _23717 = _14file_exists(_57user_library_42602);
        if (_23717 == 0) {
            DeRef(_23717);
            _23717 = NOVALUE;
            goto L14; // [440] 448
        }
        else {
            if (!IS_ATOM_INT(_23717) && DBL_PTR(_23717)->dbl == 0.0){
                DeRef(_23717);
                _23717 = NOVALUE;
                goto L14; // [440] 448
            }
            DeRef(_23717);
            _23717 = NOVALUE;
        }
        DeRef(_23717);
        _23717 = NOVALUE;

        /** buildsys.e:437					exit "translation kind"*/
        goto LD; // [445] 455
L14: 

        /** buildsys.e:439			end for -- tk*/
        _tk_45595 = _tk_45595 + 1;
        goto LC; // [450] 293
LD: 
        ;
    }
L3: 
    DeRef(_eudir_45583);
    _eudir_45583 = NOVALUE;

    /** buildsys.e:441		user_library = adjust_for_build_file(user_library)*/
    RefDS(_57user_library_42602);
    _0 = _55adjust_for_build_file(_57user_library_42602);
    DeRefDS(_57user_library_42602);
    _57user_library_42602 = _0;

    /** buildsys.e:443		if TWINDOWS then*/

    /** buildsys.e:455		elsif TOSX then*/

    /** buildsys.e:460			if dll_option then*/
    if (_57dll_option_42590 == 0)
    {
        goto L15; // [556] 567
    }
    else{
    }

    /** buildsys.e:461				exe_ext = ".so"*/
    RefDS(_23727);
    DeRefi(_exe_ext_45536);
    _exe_ext_45536 = _23727;
L15: 

    /** buildsys.e:465		object compile_dir = get_eucompiledir()*/
    _0 = _compile_dir_45660;
    _compile_dir_45660 = _57get_eucompiledir();
    DeRef(_0);

    /** buildsys.e:466		if not file_exists(compile_dir) then*/
    Ref(_compile_dir_45660);
    _23729 = _14file_exists(_compile_dir_45660);
    if (IS_ATOM_INT(_23729)) {
        if (_23729 != 0){
            DeRef(_23729);
            _23729 = NOVALUE;
            goto L16; // [579] 600
        }
    }
    else {
        if (DBL_PTR(_23729)->dbl != 0.0){
            DeRef(_23729);
            _23729 = NOVALUE;
            goto L16; // [579] 600
        }
    }
    DeRef(_23729);
    _23729 = NOVALUE;

    /** buildsys.e:467			printf(2,"Couldn't get include directory '%s'",{get_eucompiledir()})*/
    _23732 = _57get_eucompiledir();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23732;
    _23733 = MAKE_SEQ(_1);
    _23732 = NOVALUE;
    EPrintf(2, _23731, _23733);
    DeRefDS(_23733);
    _23733 = NOVALUE;

    /** buildsys.e:468			abort(1)*/
    UserCleanup(1);
L16: 

    /** buildsys.e:471		integer bits = 32*/
    _bits_45671 = 32;

    /** buildsys.e:472		if TX86_64 then*/

    /** buildsys.e:476		switch compiler_type do*/
    _0 = 0;
    switch ( _0 ){ 

        /** buildsys.e:477			case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:478				c_exe = compiler_prefix & "gcc"*/
        Concat((object_ptr)&_c_exe_45531, _55compiler_prefix_45417, _23736);

        /** buildsys.e:479				l_exe = compiler_prefix & "gcc"*/
        Concat((object_ptr)&_l_exe_45533, _55compiler_prefix_45417, _23736);

        /** buildsys.e:480				obj_ext = "o"*/
        RefDS(_23739);
        DeRefi(_obj_ext_45535);
        _obj_ext_45535 = _23739;

        /** buildsys.e:482				sequence m_flag = ""*/
        RefDS(_22015);
        DeRefi(_m_flag_45681);
        _m_flag_45681 = _22015;

        /** buildsys.e:483				if not TARM then*/

        /** buildsys.e:485					m_flag = sprintf( "-m%d", bits )*/
        DeRefDSi(_m_flag_45681);
        _m_flag_45681 = EPrintf(-9999999, _23741, _bits_45671);

        /** buildsys.e:488				if debug_option then*/
        if (_57debug_option_42600 == 0)
        {
            goto L17; // [679] 691
        }
        else{
        }

        /** buildsys.e:489					c_flags &= " -g3"*/
        Concat((object_ptr)&_c_flags_45532, _c_flags_45532, _23743);
        goto L18; // [688] 698
L17: 

        /** buildsys.e:491					c_flags &= " -fomit-frame-pointer"*/
        Concat((object_ptr)&_c_flags_45532, _c_flags_45532, _23745);
L18: 

        /** buildsys.e:494				if dll_option and not TWINDOWS then*/
        if (_57dll_option_42590 == 0) {
            goto L19; // [702] 722
        }
        _23748 = (0 == 0);
        if (_23748 == 0)
        {
            DeRef(_23748);
            _23748 = NOVALUE;
            goto L19; // [712] 722
        }
        else{
            DeRef(_23748);
            _23748 = NOVALUE;
        }

        /** buildsys.e:495					c_flags &= " -fPIC"*/
        Concat((object_ptr)&_c_flags_45532, _c_flags_45532, _23749);
L19: 

        /** buildsys.e:498				c_flags &= sprintf(" -c -w -fsigned-char -O2 %s -I%s -ffast-math",*/
        _23752 = _57get_eucompiledir();
        _23753 = _55adjust_for_build_file(_23752);
        _23752 = NOVALUE;
        RefDS(_m_flag_45681);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _m_flag_45681;
        ((intptr_t *)_2)[2] = _23753;
        _23754 = MAKE_SEQ(_1);
        _23753 = NOVALUE;
        _23755 = EPrintf(-9999999, _23751, _23754);
        DeRefDS(_23754);
        _23754 = NOVALUE;
        Concat((object_ptr)&_c_flags_45532, _c_flags_45532, _23755);
        DeRefDS(_23755);
        _23755 = NOVALUE;

        /** buildsys.e:501				if TWINDOWS and mno_cygwin then*/
        if (0 == 0) {
            goto L1A; // [747] 764
        }
        goto L1A; // [754] 764

        /** buildsys.e:504					c_flags &= " -mno-cygwin"*/
        Concat((object_ptr)&_c_flags_45532, _c_flags_45532, _23758);
L1A: 

        /** buildsys.e:507				if build_system_type != BUILD_DIRECT then*/

        /** buildsys.e:510					l_flags = sprintf( " %s %s",*/
        RefDS(_57user_library_42602);
        _23765 = _55adjust_for_command_line_passing(_57user_library_42602);
        RefDS(_m_flag_45681);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23765;
        ((intptr_t *)_2)[2] = _m_flag_45681;
        _23766 = MAKE_SEQ(_1);
        _23765 = NOVALUE;
        DeRefi(_l_flags_45534);
        _l_flags_45534 = EPrintf(-9999999, _23764, _23766);
        DeRefDS(_23766);
        _23766 = NOVALUE;

        /** buildsys.e:514				if dll_option then*/
        if (_57dll_option_42590 == 0)
        {
            goto L1B; // [806] 816
        }
        else{
        }

        /** buildsys.e:515					l_flags &= " -shared "*/
        Concat((object_ptr)&_l_flags_45534, _l_flags_45534, _23768);
L1B: 

        /** buildsys.e:518				if TLINUX then*/
        if (_44TLINUX_20372 == 0)
        {
            goto L1C; // [820] 832
        }
        else{
        }

        /** buildsys.e:519					l_flags &= " -ldl -lm -lpthread"*/
        Concat((object_ptr)&_l_flags_45534, _l_flags_45534, _23770);
        goto L1D; // [829] 901
L1C: 

        /** buildsys.e:520				elsif TBSD then*/

        /** buildsys.e:522				elsif TOSX then*/

        /** buildsys.e:524				elsif TWINDOWS then*/
L1D: 

        /** buildsys.e:537				rc_comp = compiler_prefix & "windres -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" [1] -O coff -o [2]"*/
        _23781 = _14current_dir();
        _23782 = _55adjust_for_build_file(_23781);
        _23781 = NOVALUE;
        {
            object concat_list[4];

            concat_list[0] = _23783;
            concat_list[1] = _23782;
            concat_list[2] = _23780;
            concat_list[3] = _55compiler_prefix_45417;
            Concat_N((object_ptr)&_rc_comp_45538, concat_list, 4);
        }
        DeRef(_23782);
        _23782 = NOVALUE;
        DeRefi(_m_flag_45681);
        _m_flag_45681 = NOVALUE;
        goto L1E; // [921] 1127

        /** buildsys.e:539			case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:540				c_exe = compiler_prefix & "wcc386"*/
        Concat((object_ptr)&_c_exe_45531, _55compiler_prefix_45417, _23785);

        /** buildsys.e:541				l_exe = compiler_prefix & "wlink"*/
        Concat((object_ptr)&_l_exe_45533, _55compiler_prefix_45417, _23787);

        /** buildsys.e:542				obj_ext = "obj"*/
        RefDS(_23789);
        DeRefi(_obj_ext_45535);
        _obj_ext_45535 = _23789;

        /** buildsys.e:544				if debug_option then*/
        if (_57debug_option_42600 == 0)
        {
            goto L1F; // [954] 971
        }
        else{
        }

        /** buildsys.e:545					c_flags = " /d3"*/
        RefDS(_23790);
        DeRef(_c_flags_45532);
        _c_flags_45532 = _23790;

        /** buildsys.e:546					l_flags_begin &= " DEBUG ALL "*/
        Concat((object_ptr)&_l_flags_begin_45537, _l_flags_begin_45537, _23791);
L1F: 

        /** buildsys.e:549				l_flags &= sprintf(" OPTION STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _57total_stack_size_42605;
        _23794 = MAKE_SEQ(_1);
        _23795 = EPrintf(-9999999, _23793, _23794);
        DeRefDS(_23794);
        _23794 = NOVALUE;
        Concat((object_ptr)&_l_flags_45534, _l_flags_45534, _23795);
        DeRefDS(_23795);
        _23795 = NOVALUE;

        /** buildsys.e:550				l_flags &= sprintf(" COMMIT STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _57total_stack_size_42605;
        _23798 = MAKE_SEQ(_1);
        _23799 = EPrintf(-9999999, _23797, _23798);
        DeRefDS(_23798);
        _23798 = NOVALUE;
        Concat((object_ptr)&_l_flags_45534, _l_flags_45534, _23799);
        DeRefDS(_23799);
        _23799 = NOVALUE;

        /** buildsys.e:551				l_flags &= " OPTION QUIET OPTION ELIMINATE OPTION CASEEXACT"*/
        Concat((object_ptr)&_l_flags_45534, _l_flags_45534, _23801);

        /** buildsys.e:553				if dll_option then*/
        if (_57dll_option_42590 == 0)
        {
            goto L20; // [1013] 1039
        }
        else{
        }

        /** buildsys.e:554					c_flags &= " /bd /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir) */
        Ref(_compile_dir_45660);
        _23804 = _55adjust_for_build_file(_compile_dir_45660);
        if (IS_SEQUENCE(_23803) && IS_ATOM(_23804)) {
            Ref(_23804);
            Append(&_23805, _23803, _23804);
        }
        else if (IS_ATOM(_23803) && IS_SEQUENCE(_23804)) {
        }
        else {
            Concat((object_ptr)&_23805, _23803, _23804);
        }
        DeRef(_23804);
        _23804 = NOVALUE;
        Concat((object_ptr)&_c_flags_45532, _c_flags_45532, _23805);
        DeRefDS(_23805);
        _23805 = NOVALUE;

        /** buildsys.e:555					l_flags &= " SYSTEM NT_DLL initinstance terminstance"*/
        Concat((object_ptr)&_l_flags_45534, _l_flags_45534, _23807);
        goto L21; // [1036] 1077
L20: 

        /** buildsys.e:557					c_flags &= " /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir)*/
        Ref(_compile_dir_45660);
        _23810 = _55adjust_for_build_file(_compile_dir_45660);
        if (IS_SEQUENCE(_23809) && IS_ATOM(_23810)) {
            Ref(_23810);
            Append(&_23811, _23809, _23810);
        }
        else if (IS_ATOM(_23809) && IS_SEQUENCE(_23810)) {
        }
        else {
            Concat((object_ptr)&_23811, _23809, _23810);
        }
        DeRef(_23810);
        _23810 = NOVALUE;
        Concat((object_ptr)&_c_flags_45532, _c_flags_45532, _23811);
        DeRefDS(_23811);
        _23811 = NOVALUE;

        /** buildsys.e:558					if con_option then*/
        if (_57con_option_42592 == 0)
        {
            goto L22; // [1057] 1069
        }
        else{
        }

        /** buildsys.e:560						l_flags = " SYSTEM NT" & l_flags*/
        Concat((object_ptr)&_l_flags_45534, _23813, _l_flags_45534);
        goto L23; // [1066] 1076
L22: 

        /** buildsys.e:562						l_flags = " SYSTEM NT_WIN RUNTIME WINDOWS=4.0" & l_flags*/
        Concat((object_ptr)&_l_flags_45534, _23815, _l_flags_45534);
L23: 
L21: 

        /** buildsys.e:566				l_flags &= sprintf(" FILE %s", { (user_library) })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_57user_library_42602);
        ((intptr_t*)_2)[1] = _57user_library_42602;
        _23818 = MAKE_SEQ(_1);
        _23819 = EPrintf(-9999999, _23817, _23818);
        DeRefDS(_23818);
        _23818 = NOVALUE;
        Concat((object_ptr)&_l_flags_45534, _l_flags_45534, _23819);
        DeRefDS(_23819);
        _23819 = NOVALUE;

        /** buildsys.e:570				rc_comp = compiler_prefix &"wrc -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" -q -fo=[2] -ad [1] [3]"*/
        _23822 = _14current_dir();
        _23823 = _55adjust_for_build_file(_23822);
        _23822 = NOVALUE;
        {
            object concat_list[4];

            concat_list[0] = _23824;
            concat_list[1] = _23823;
            concat_list[2] = _23821;
            concat_list[3] = _55compiler_prefix_45417;
            Concat_N((object_ptr)&_rc_comp_45538, concat_list, 4);
        }
        DeRef(_23823);
        _23823 = NOVALUE;
        goto L1E; // [1111] 1127

        /** buildsys.e:571			case else*/
        default:

        /** buildsys.e:572				CompileErr(COMPILER_IS_UNKNOWN)*/
        RefDS(_22015);
        _49CompileErr(43, _22015, 0);
    ;}L1E: 

    /** buildsys.e:575		if length(cflags) then*/
    _23826 = 0;

    /** buildsys.e:580		if length(extra_cflags) then*/
    _23827 = 0;

    /** buildsys.e:584		if length(lflags) then*/
    _23830 = 0;

    /** buildsys.e:589		if length(extra_lflags) then*/
    _23831 = 0;

    /** buildsys.e:593		return { */
    _1 = NewS1(9);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_c_exe_45531);
    ((intptr_t*)_2)[1] = _c_exe_45531;
    RefDS(_c_flags_45532);
    ((intptr_t*)_2)[2] = _c_flags_45532;
    RefDS(_l_exe_45533);
    ((intptr_t*)_2)[3] = _l_exe_45533;
    RefDS(_l_flags_45534);
    ((intptr_t*)_2)[4] = _l_flags_45534;
    RefDS(_obj_ext_45535);
    ((intptr_t*)_2)[5] = _obj_ext_45535;
    RefDS(_exe_ext_45536);
    ((intptr_t*)_2)[6] = _exe_ext_45536;
    RefDS(_l_flags_begin_45537);
    ((intptr_t*)_2)[7] = _l_flags_begin_45537;
    RefDS(_rc_comp_45538);
    ((intptr_t*)_2)[8] = _rc_comp_45538;
    RefDS(_57user_library_42602);
    ((intptr_t*)_2)[9] = _57user_library_42602;
    _23834 = MAKE_SEQ(_1);
    DeRefDS(_c_exe_45531);
    DeRefDS(_c_flags_45532);
    DeRefDS(_l_exe_45533);
    DeRefDSi(_l_flags_45534);
    DeRefDSi(_obj_ext_45535);
    DeRefDSi(_exe_ext_45536);
    DeRefDSi(_l_flags_begin_45537);
    DeRefDS(_rc_comp_45538);
    DeRef(_l_names_45539);
    DeRefi(_l_ext_45540);
    DeRefi(_t_slash_45541);
    DeRef(_compile_dir_45660);
    DeRef(_23668);
    _23668 = NOVALUE;
    return _23834;
    ;
}


void _55ensure_exename(object _ext_45828)
{
    object _23841 = NOVALUE;
    object _23840 = NOVALUE;
    object _23839 = NOVALUE;
    object _23838 = NOVALUE;
    object _23836 = NOVALUE;
    object _23835 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:602		if length(exe_name[D_ALTNAME]) = 0 then*/
    _2 = (object)SEQ_PTR(_55exe_name_45419);
    _23835 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23835)){
            _23836 = SEQ_PTR(_23835)->length;
    }
    else {
        _23836 = 1;
    }
    _23835 = NOVALUE;
    if (_23836 != 0)
    goto L1; // [16] 67

    /** buildsys.e:603			exe_name[D_NAME] = current_dir() & SLASH & file0 & ext*/
    _23838 = _14current_dir();
    {
        object concat_list[4];

        concat_list[0] = _ext_45828;
        concat_list[1] = _57file0_44558;
        concat_list[2] = 47;
        concat_list[3] = _23838;
        Concat_N((object_ptr)&_23839, concat_list, 4);
    }
    DeRef(_23838);
    _23838 = NOVALUE;
    _2 = (object)SEQ_PTR(_55exe_name_45419);
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23839;
    if( _1 != _23839 ){
        DeRef(_1);
    }
    _23839 = NOVALUE;

    /** buildsys.e:604			exe_name[D_ALTNAME] = adjust_for_command_line_passing(exe_name[D_NAME])*/
    _2 = (object)SEQ_PTR(_55exe_name_45419);
    _23840 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_23840);
    _23841 = _55adjust_for_command_line_passing(_23840);
    _23840 = NOVALUE;
    _2 = (object)SEQ_PTR(_55exe_name_45419);
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23841;
    if( _1 != _23841 ){
        DeRef(_1);
    }
    _23841 = NOVALUE;
L1: 

    /** buildsys.e:606	end procedure*/
    DeRefDS(_ext_45828);
    _23835 = NOVALUE;
    return;
    ;
}


void _55write_objlink_file()
{
    object _settings_45846 = NOVALUE;
    object _fh_45848 = NOVALUE;
    object _s_45896 = NOVALUE;
    object _23890 = NOVALUE;
    object _23888 = NOVALUE;
    object _23887 = NOVALUE;
    object _23886 = NOVALUE;
    object _23885 = NOVALUE;
    object _23884 = NOVALUE;
    object _23883 = NOVALUE;
    object _23882 = NOVALUE;
    object _23881 = NOVALUE;
    object _23880 = NOVALUE;
    object _23879 = NOVALUE;
    object _23878 = NOVALUE;
    object _23877 = NOVALUE;
    object _23875 = NOVALUE;
    object _23874 = NOVALUE;
    object _23873 = NOVALUE;
    object _23872 = NOVALUE;
    object _23870 = NOVALUE;
    object _23869 = NOVALUE;
    object _23868 = NOVALUE;
    object _23867 = NOVALUE;
    object _23866 = NOVALUE;
    object _23865 = NOVALUE;
    object _23859 = NOVALUE;
    object _23858 = NOVALUE;
    object _23855 = NOVALUE;
    object _23854 = NOVALUE;
    object _23853 = NOVALUE;
    object _23852 = NOVALUE;
    object _23851 = NOVALUE;
    object _23849 = NOVALUE;
    object _23848 = NOVALUE;
    object _23847 = NOVALUE;
    object _23844 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:612		sequence settings = setup_build()*/
    _0 = _settings_45846;
    _settings_45846 = _55setup_build();
    DeRef(_0);

    /** buildsys.e:613		integer fh = open(output_dir & file0 & ".lnk", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _23843;
        concat_list[1] = _57file0_44558;
        concat_list[2] = _57output_dir_42604;
        Concat_N((object_ptr)&_23844, concat_list, 3);
    }
    _fh_45848 = EOpen(_23844, _23845, 0);
    DeRefDS(_23844);
    _23844 = NOVALUE;

    /** buildsys.e:615		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_45846);
    _23847 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_23847);
    _55ensure_exename(_23847);
    _23847 = NOVALUE;

    /** buildsys.e:617		if length(settings[SETUP_LFLAGS_BEGIN]) > 0 then*/
    _2 = (object)SEQ_PTR(_settings_45846);
    _23848 = (object)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_23848)){
            _23849 = SEQ_PTR(_23848)->length;
    }
    else {
        _23849 = 1;
    }
    _23848 = NOVALUE;
    if (_23849 <= 0)
    goto L1; // [43] 63

    /** buildsys.e:618			puts(fh, settings[SETUP_LFLAGS_BEGIN] & HOSTNL)*/
    _2 = (object)SEQ_PTR(_settings_45846);
    _23851 = (object)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_23851) && IS_ATOM(_44HOSTNL_20392)) {
    }
    else if (IS_ATOM(_23851) && IS_SEQUENCE(_44HOSTNL_20392)) {
        Ref(_23851);
        Prepend(&_23852, _44HOSTNL_20392, _23851);
    }
    else {
        Concat((object_ptr)&_23852, _23851, _44HOSTNL_20392);
        _23851 = NOVALUE;
    }
    _23851 = NOVALUE;
    EPuts(_fh_45848, _23852); // DJP 
    DeRefDS(_23852);
    _23852 = NOVALUE;
L1: 

    /** buildsys.e:621		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42594)){
            _23853 = SEQ_PTR(_57generated_files_42594)->length;
    }
    else {
        _23853 = 1;
    }
    {
        object _i_45864;
        _i_45864 = 1;
L2: 
        if (_i_45864 > _23853){
            goto L3; // [70] 132
        }

        /** buildsys.e:622			if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_57generated_files_42594);
        _23854 = (object)*(((s1_ptr)_2)->base + _i_45864);
        _23855 = e_match_from(_23166, _23854, 1);
        _23854 = NOVALUE;
        if (_23855 == 0)
        {
            _23855 = NOVALUE;
            goto L4; // [90] 125
        }
        else{
            _23855 = NOVALUE;
        }

        /** buildsys.e:623				if compiler_type = COMPILER_WATCOM then*/

        /** buildsys.e:627				puts(fh, generated_files[i] & HOSTNL)*/
        _2 = (object)SEQ_PTR(_57generated_files_42594);
        _23858 = (object)*(((s1_ptr)_2)->base + _i_45864);
        Concat((object_ptr)&_23859, _23858, _44HOSTNL_20392);
        _23858 = NOVALUE;
        _23858 = NOVALUE;
        EPuts(_fh_45848, _23859); // DJP 
        DeRefDS(_23859);
        _23859 = NOVALUE;
L4: 

        /** buildsys.e:629		end for*/
        _i_45864 = _i_45864 + 1;
        goto L2; // [127] 77
L3: 
        ;
    }

    /** buildsys.e:631		if compiler_type = COMPILER_WATCOM then*/

    /** buildsys.e:635		puts(fh, trim(settings[SETUP_LFLAGS] & HOSTNL))*/
    _2 = (object)SEQ_PTR(_settings_45846);
    _23865 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_23865) && IS_ATOM(_44HOSTNL_20392)) {
    }
    else if (IS_ATOM(_23865) && IS_SEQUENCE(_44HOSTNL_20392)) {
        Ref(_23865);
        Prepend(&_23866, _44HOSTNL_20392, _23865);
    }
    else {
        Concat((object_ptr)&_23866, _23865, _44HOSTNL_20392);
        _23865 = NOVALUE;
    }
    _23865 = NOVALUE;
    RefDS(_3010);
    _23867 = _18trim(_23866, _3010, 0);
    _23866 = NOVALUE;
    EPuts(_fh_45848, _23867); // DJP 
    DeRef(_23867);
    _23867 = NOVALUE;

    /** buildsys.e:637		if compiler_type = COMPILER_WATCOM and dll_option then*/
    _23868 = (0 == 2);
    if (_23868 == 0) {
        goto L5; // [194] 361
    }
    if (_57dll_option_42590 == 0)
    {
        goto L5; // [201] 361
    }
    else{
    }

    /** buildsys.e:638			puts(fh, HOSTNL)*/
    EPuts(_fh_45848, _44HOSTNL_20392); // DJP 

    /** buildsys.e:640			object s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _23870 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    DeRef(_s_45896);
    _2 = (object)SEQ_PTR(_23870);
    _s_45896 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_s_45896);
    _23870 = NOVALUE;

    /** buildsys.e:641			while s do*/
L6: 
    if (_s_45896 <= 0) {
        if (_s_45896 == 0) {
            goto L7; // [232] 360
        }
        else {
            if (!IS_ATOM_INT(_s_45896) && DBL_PTR(_s_45896)->dbl == 0.0){
                goto L7; // [232] 360
            }
        }
    }

    /** buildsys.e:642				if eu:find(SymTab[s][S_TOKEN], RTN_TOKS) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_s_45896)){
        _23872 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45896)->dbl));
    }
    else{
        _23872 = (object)*(((s1_ptr)_2)->base + _s_45896);
    }
    _2 = (object)SEQ_PTR(_23872);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _23873 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _23873 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _23872 = NOVALUE;
    _23874 = find_from(_23873, _29RTN_TOKS_12006, 1);
    _23873 = NOVALUE;
    if (_23874 == 0)
    {
        _23874 = NOVALUE;
        goto L8; // [256] 341
    }
    else{
        _23874 = NOVALUE;
    }

    /** buildsys.e:643					if is_exported( s ) then*/
    Ref(_s_45896);
    _23875 = _57is_exported(_s_45896);
    if (_23875 == 0) {
        DeRef(_23875);
        _23875 = NOVALUE;
        goto L9; // [265] 340
    }
    else {
        if (!IS_ATOM_INT(_23875) && DBL_PTR(_23875)->dbl == 0.0){
            DeRef(_23875);
            _23875 = NOVALUE;
            goto L9; // [265] 340
        }
        DeRef(_23875);
        _23875 = NOVALUE;
    }
    DeRef(_23875);
    _23875 = NOVALUE;

    /** buildsys.e:644						printf(fh, "EXPORT %s='__%d%s@%d'" & HOSTNL,*/
    Concat((object_ptr)&_23877, _23876, _44HOSTNL_20392);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_s_45896)){
        _23878 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45896)->dbl));
    }
    else{
        _23878 = (object)*(((s1_ptr)_2)->base + _s_45896);
    }
    _2 = (object)SEQ_PTR(_23878);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _23879 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _23879 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _23878 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_s_45896)){
        _23880 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45896)->dbl));
    }
    else{
        _23880 = (object)*(((s1_ptr)_2)->base + _s_45896);
    }
    _2 = (object)SEQ_PTR(_23880);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _23881 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _23881 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _23880 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_s_45896)){
        _23882 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45896)->dbl));
    }
    else{
        _23882 = (object)*(((s1_ptr)_2)->base + _s_45896);
    }
    _2 = (object)SEQ_PTR(_23882);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _23883 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _23883 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _23882 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_s_45896)){
        _23884 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45896)->dbl));
    }
    else{
        _23884 = (object)*(((s1_ptr)_2)->base + _s_45896);
    }
    _2 = (object)SEQ_PTR(_23884);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _23885 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _23885 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _23884 = NOVALUE;
    if (IS_ATOM_INT(_23885)) {
        if (_23885 == (short)_23885){
            _23886 = _23885 * 4;
        }
        else{
            _23886 = NewDouble(_23885 * (eudouble)4);
        }
    }
    else {
        _23886 = binary_op(MULTIPLY, _23885, 4);
    }
    _23885 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23879);
    ((intptr_t*)_2)[1] = _23879;
    Ref(_23881);
    ((intptr_t*)_2)[2] = _23881;
    Ref(_23883);
    ((intptr_t*)_2)[3] = _23883;
    ((intptr_t*)_2)[4] = _23886;
    _23887 = MAKE_SEQ(_1);
    _23886 = NOVALUE;
    _23883 = NOVALUE;
    _23881 = NOVALUE;
    _23879 = NOVALUE;
    EPrintf(_fh_45848, _23877, _23887);
    DeRefDS(_23877);
    _23877 = NOVALUE;
    DeRefDS(_23887);
    _23887 = NOVALUE;
L9: 
L8: 

    /** buildsys.e:649				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_s_45896)){
        _23888 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45896)->dbl));
    }
    else{
        _23888 = (object)*(((s1_ptr)_2)->base + _s_45896);
    }
    DeRef(_s_45896);
    _2 = (object)SEQ_PTR(_23888);
    _s_45896 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_s_45896);
    _23888 = NOVALUE;

    /** buildsys.e:650			end while*/
    goto L6; // [357] 232
L7: 
L5: 
    DeRef(_s_45896);
    _s_45896 = NOVALUE;

    /** buildsys.e:653		close(fh)*/
    EClose(_fh_45848);

    /** buildsys.e:655		generated_files = append(generated_files, file0 & ".lnk")*/
    Concat((object_ptr)&_23890, _57file0_44558, _23843);
    RefDS(_23890);
    Append(&_57generated_files_42594, _57generated_files_42594, _23890);
    DeRefDS(_23890);
    _23890 = NOVALUE;

    /** buildsys.e:656	end procedure*/
    DeRef(_settings_45846);
    _23848 = NOVALUE;
    DeRef(_23868);
    _23868 = NOVALUE;
    return;
    ;
}


void _55write_makefile_srcobj_list(object _fh_45945)
{
    object _file_count_45975 = NOVALUE;
    object _23922 = NOVALUE;
    object _23921 = NOVALUE;
    object _23920 = NOVALUE;
    object _23918 = NOVALUE;
    object _23917 = NOVALUE;
    object _23916 = NOVALUE;
    object _23914 = NOVALUE;
    object _23913 = NOVALUE;
    object _23911 = NOVALUE;
    object _23910 = NOVALUE;
    object _23909 = NOVALUE;
    object _23908 = NOVALUE;
    object _23907 = NOVALUE;
    object _23906 = NOVALUE;
    object _23904 = NOVALUE;
    object _23903 = NOVALUE;
    object _23902 = NOVALUE;
    object _23898 = NOVALUE;
    object _23897 = NOVALUE;
    object _23896 = NOVALUE;
    object _23895 = NOVALUE;
    object _23894 = NOVALUE;
    object _23893 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:660		printf(fh, "%s_SOURCES =", { upper(file0) })*/
    RefDS(_57file0_44558);
    _23893 = _18upper(_57file0_44558);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23893;
    _23894 = MAKE_SEQ(_1);
    _23893 = NOVALUE;
    EPrintf(_fh_45945, _23892, _23894);
    DeRefDS(_23894);
    _23894 = NOVALUE;

    /** buildsys.e:661		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42594)){
            _23895 = SEQ_PTR(_57generated_files_42594)->length;
    }
    else {
        _23895 = 1;
    }
    {
        object _i_45952;
        _i_45952 = 1;
L1: 
        if (_i_45952 > _23895){
            goto L2; // [26] 94
        }

        /** buildsys.e:662			if generated_files[i][$] = 'c' then*/
        _2 = (object)SEQ_PTR(_57generated_files_42594);
        _23896 = (object)*(((s1_ptr)_2)->base + _i_45952);
        if (IS_SEQUENCE(_23896)){
                _23897 = SEQ_PTR(_23896)->length;
        }
        else {
            _23897 = 1;
        }
        _2 = (object)SEQ_PTR(_23896);
        _23898 = (object)*(((s1_ptr)_2)->base + _23897);
        _23896 = NOVALUE;
        if (binary_op_a(NOTEQ, _23898, 99)){
            _23898 = NOVALUE;
            goto L3; // [48] 87
        }
        _23898 = NOVALUE;

        /** buildsys.e:663				if i > 1 then*/
        if (_i_45952 <= 1)
        goto L4; // [54] 71

        /** buildsys.e:664					printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_44HOSTNL_20392);
        ((intptr_t*)_2)[1] = _44HOSTNL_20392;
        _23902 = MAKE_SEQ(_1);
        EPrintf(_fh_45945, _23901, _23902);
        DeRefDS(_23902);
        _23902 = NOVALUE;
L4: 

        /** buildsys.e:666				puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42594);
        _23903 = (object)*(((s1_ptr)_2)->base + _i_45952);
        Concat((object_ptr)&_23904, _23406, _23903);
        _23903 = NOVALUE;
        EPuts(_fh_45945, _23904); // DJP 
        DeRefDS(_23904);
        _23904 = NOVALUE;
L3: 

        /** buildsys.e:668		end for*/
        _i_45952 = _i_45952 + 1;
        goto L1; // [89] 33
L2: 
        ;
    }

    /** buildsys.e:669		puts(fh, HOSTNL)*/
    EPuts(_fh_45945, _44HOSTNL_20392); // DJP 

    /** buildsys.e:671		printf(fh, "%s_OBJECTS =", { upper(file0) })*/
    RefDS(_57file0_44558);
    _23906 = _18upper(_57file0_44558);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23906;
    _23907 = MAKE_SEQ(_1);
    _23906 = NOVALUE;
    EPrintf(_fh_45945, _23905, _23907);
    DeRefDS(_23907);
    _23907 = NOVALUE;

    /** buildsys.e:672		integer file_count = 0*/
    _file_count_45975 = 0;

    /** buildsys.e:673		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42594)){
            _23908 = SEQ_PTR(_57generated_files_42594)->length;
    }
    else {
        _23908 = 1;
    }
    {
        object _i_45977;
        _i_45977 = 1;
L5: 
        if (_i_45977 > _23908){
            goto L6; // [129] 199
        }

        /** buildsys.e:674			if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_57generated_files_42594);
        _23909 = (object)*(((s1_ptr)_2)->base + _i_45977);
        _23910 = e_match_from(_23166, _23909, 1);
        _23909 = NOVALUE;
        if (_23910 == 0)
        {
            _23910 = NOVALUE;
            goto L7; // [149] 192
        }
        else{
            _23910 = NOVALUE;
        }

        /** buildsys.e:675				if file_count then*/
        if (_file_count_45975 == 0)
        {
            goto L8; // [154] 170
        }
        else{
        }

        /** buildsys.e:676					printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_44HOSTNL_20392);
        ((intptr_t*)_2)[1] = _44HOSTNL_20392;
        _23911 = MAKE_SEQ(_1);
        EPrintf(_fh_45945, _23901, _23911);
        DeRefDS(_23911);
        _23911 = NOVALUE;
L8: 

        /** buildsys.e:678				file_count += 1*/
        _file_count_45975 = _file_count_45975 + 1;

        /** buildsys.e:679				puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42594);
        _23913 = (object)*(((s1_ptr)_2)->base + _i_45977);
        Concat((object_ptr)&_23914, _23406, _23913);
        _23913 = NOVALUE;
        EPuts(_fh_45945, _23914); // DJP 
        DeRefDS(_23914);
        _23914 = NOVALUE;
L7: 

        /** buildsys.e:681		end for*/
        _i_45977 = _i_45977 + 1;
        goto L5; // [194] 136
L6: 
        ;
    }

    /** buildsys.e:682		puts(fh, HOSTNL)*/
    EPuts(_fh_45945, _44HOSTNL_20392); // DJP 

    /** buildsys.e:684		printf(fh, "%s_GENERATED_FILES = ", { upper(file0) })*/
    RefDS(_57file0_44558);
    _23916 = _18upper(_57file0_44558);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23916;
    _23917 = MAKE_SEQ(_1);
    _23916 = NOVALUE;
    EPrintf(_fh_45945, _23915, _23917);
    DeRefDS(_23917);
    _23917 = NOVALUE;

    /** buildsys.e:685		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42594)){
            _23918 = SEQ_PTR(_57generated_files_42594)->length;
    }
    else {
        _23918 = 1;
    }
    {
        object _i_45998;
        _i_45998 = 1;
L9: 
        if (_i_45998 > _23918){
            goto LA; // [229] 277
        }

        /** buildsys.e:686			if i > 1 then*/
        if (_i_45998 <= 1)
        goto LB; // [238] 255

        /** buildsys.e:687				printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_44HOSTNL_20392);
        ((intptr_t*)_2)[1] = _44HOSTNL_20392;
        _23920 = MAKE_SEQ(_1);
        EPrintf(_fh_45945, _23901, _23920);
        DeRefDS(_23920);
        _23920 = NOVALUE;
LB: 

        /** buildsys.e:689			puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42594);
        _23921 = (object)*(((s1_ptr)_2)->base + _i_45998);
        Concat((object_ptr)&_23922, _23406, _23921);
        _23921 = NOVALUE;
        EPuts(_fh_45945, _23922); // DJP 
        DeRefDS(_23922);
        _23922 = NOVALUE;

        /** buildsys.e:690		end for*/
        _i_45998 = _i_45998 + 1;
        goto L9; // [272] 236
LA: 
        ;
    }

    /** buildsys.e:691		puts(fh, HOSTNL)*/
    EPuts(_fh_45945, _44HOSTNL_20392); // DJP 

    /** buildsys.e:692	end procedure*/
    return;
    ;
}


object _55windows_to_mingw_path(object _s_46011)
{
    object _23924 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:701		ifdef TEST_FOR_WIN9X_ON_MING then*/

    /** buildsys.e:711		return search:find_replace('\\',s,'/')*/
    RefDS(_s_46011);
    _23924 = _20find_replace(92, _s_46011, 47, 0);
    DeRefDS(_s_46011);
    return _23924;
    ;
}


void _55write_makefile_full()
{
    object _settings_46016 = NOVALUE;
    object _fh_46019 = NOVALUE;
    object _24051 = NOVALUE;
    object _24049 = NOVALUE;
    object _24047 = NOVALUE;
    object _24046 = NOVALUE;
    object _24045 = NOVALUE;
    object _24044 = NOVALUE;
    object _24043 = NOVALUE;
    object _24041 = NOVALUE;
    object _24040 = NOVALUE;
    object _24038 = NOVALUE;
    object _24037 = NOVALUE;
    object _24036 = NOVALUE;
    object _24035 = NOVALUE;
    object _24033 = NOVALUE;
    object _24032 = NOVALUE;
    object _24030 = NOVALUE;
    object _24029 = NOVALUE;
    object _24027 = NOVALUE;
    object _24026 = NOVALUE;
    object _24025 = NOVALUE;
    object _24024 = NOVALUE;
    object _24023 = NOVALUE;
    object _24022 = NOVALUE;
    object _24021 = NOVALUE;
    object _24020 = NOVALUE;
    object _24018 = NOVALUE;
    object _24017 = NOVALUE;
    object _24016 = NOVALUE;
    object _24015 = NOVALUE;
    object _24014 = NOVALUE;
    object _24013 = NOVALUE;
    object _24012 = NOVALUE;
    object _24011 = NOVALUE;
    object _24010 = NOVALUE;
    object _24009 = NOVALUE;
    object _24008 = NOVALUE;
    object _24007 = NOVALUE;
    object _24006 = NOVALUE;
    object _24004 = NOVALUE;
    object _24003 = NOVALUE;
    object _23941 = NOVALUE;
    object _23940 = NOVALUE;
    object _23939 = NOVALUE;
    object _23937 = NOVALUE;
    object _23936 = NOVALUE;
    object _23935 = NOVALUE;
    object _23933 = NOVALUE;
    object _23932 = NOVALUE;
    object _23931 = NOVALUE;
    object _23928 = NOVALUE;
    object _23926 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:718		sequence settings = setup_build()*/
    _0 = _settings_46016;
    _settings_46016 = _55setup_build();
    DeRef(_0);

    /** buildsys.e:720		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_46016);
    _23926 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_23926);
    _55ensure_exename(_23926);
    _23926 = NOVALUE;

    /** buildsys.e:722		integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _23927;
        concat_list[1] = _57file0_44558;
        concat_list[2] = _57output_dir_42604;
        Concat_N((object_ptr)&_23928, concat_list, 3);
    }
    _fh_46019 = EOpen(_23928, _23845, 0);
    DeRefDS(_23928);
    _23928 = NOVALUE;

    /** buildsys.e:724		printf(fh, "CC     = %s" & HOSTNL, { settings[SETUP_CEXE] })*/
    Concat((object_ptr)&_23931, _23930, _44HOSTNL_20392);
    _2 = (object)SEQ_PTR(_settings_46016);
    _23932 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23932);
    ((intptr_t*)_2)[1] = _23932;
    _23933 = MAKE_SEQ(_1);
    _23932 = NOVALUE;
    EPrintf(_fh_46019, _23931, _23933);
    DeRefDS(_23931);
    _23931 = NOVALUE;
    DeRefDS(_23933);
    _23933 = NOVALUE;

    /** buildsys.e:725		printf(fh, "CFLAGS = %s" & HOSTNL, { settings[SETUP_CFLAGS] })*/
    Concat((object_ptr)&_23935, _23934, _44HOSTNL_20392);
    _2 = (object)SEQ_PTR(_settings_46016);
    _23936 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23936);
    ((intptr_t*)_2)[1] = _23936;
    _23937 = MAKE_SEQ(_1);
    _23936 = NOVALUE;
    EPrintf(_fh_46019, _23935, _23937);
    DeRefDS(_23935);
    _23935 = NOVALUE;
    DeRefDS(_23937);
    _23937 = NOVALUE;

    /** buildsys.e:726		printf(fh, "LINKER = %s" & HOSTNL, { settings[SETUP_LEXE] })*/
    Concat((object_ptr)&_23939, _23938, _44HOSTNL_20392);
    _2 = (object)SEQ_PTR(_settings_46016);
    _23940 = (object)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23940);
    ((intptr_t*)_2)[1] = _23940;
    _23941 = MAKE_SEQ(_1);
    _23940 = NOVALUE;
    EPrintf(_fh_46019, _23939, _23941);
    DeRefDS(_23939);
    _23939 = NOVALUE;
    DeRefDS(_23941);
    _23941 = NOVALUE;

    /** buildsys.e:728		if compiler_type = COMPILER_GCC then*/

    /** buildsys.e:731			write_objlink_file()*/
    _55write_objlink_file();

    /** buildsys.e:734		write_makefile_srcobj_list(fh)*/
    _55write_makefile_srcobj_list(_fh_46019);

    /** buildsys.e:735		puts(fh, HOSTNL)*/
    EPuts(_fh_46019, _44HOSTNL_20392); // DJP 

    /** buildsys.e:737		if compiler_type = COMPILER_WATCOM then*/

    /** buildsys.e:770			printf(fh, "RUNTIME_LIBRARY=%s\n", { settings[SETUP_RUNTIME_LIBRARY] } )*/
    _2 = (object)SEQ_PTR(_settings_46016);
    _24003 = (object)*(((s1_ptr)_2)->base + 9);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24003);
    ((intptr_t*)_2)[1] = _24003;
    _24004 = MAKE_SEQ(_1);
    _24003 = NOVALUE;
    EPrintf(_fh_46019, _24002, _24004);
    DeRefDS(_24004);
    _24004 = NOVALUE;

    /** buildsys.e:771			printf(fh, "%s: $(%s_OBJECTS) $(RUNTIME_LIBRARY) %s " & HOSTNL, { adjust_for_build_file(exe_name[D_ALTNAME]), upper(file0), rc_file[D_ALTNAME] })*/
    Concat((object_ptr)&_24006, _24005, _44HOSTNL_20392);
    _2 = (object)SEQ_PTR(_55exe_name_45419);
    _24007 = (object)*(((s1_ptr)_2)->base + 11);
    Ref(_24007);
    _24008 = _55adjust_for_build_file(_24007);
    _24007 = NOVALUE;
    RefDS(_57file0_44558);
    _24009 = _18upper(_57file0_44558);
    _2 = (object)SEQ_PTR(_55rc_file_45425);
    _24010 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24008;
    ((intptr_t*)_2)[2] = _24009;
    RefDS(_24010);
    ((intptr_t*)_2)[3] = _24010;
    _24011 = MAKE_SEQ(_1);
    _24010 = NOVALUE;
    _24009 = NOVALUE;
    _24008 = NOVALUE;
    EPrintf(_fh_46019, _24006, _24011);
    DeRefDS(_24006);
    _24006 = NOVALUE;
    DeRefDS(_24011);
    _24011 = NOVALUE;

    /** buildsys.e:772			if length(rc_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_55rc_file_45425);
    _24012 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24012)){
            _24013 = SEQ_PTR(_24012)->length;
    }
    else {
        _24013 = 1;
    }
    _24012 = NOVALUE;
    if (_24013 == 0)
    {
        _24013 = NOVALUE;
        goto L1; // [646] 690
    }
    else{
        _24013 = NOVALUE;
    }

    /** buildsys.e:773				writef(fh, "\t" & settings[SETUP_RC_COMPILER] & HOSTNL, { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46016);
    _24014 = (object)*(((s1_ptr)_2)->base + 8);
    {
        object concat_list[3];

        concat_list[0] = _44HOSTNL_20392;
        concat_list[1] = _24014;
        concat_list[2] = _23961;
        Concat_N((object_ptr)&_24015, concat_list, 3);
    }
    _24014 = NOVALUE;
    _2 = (object)SEQ_PTR(_55rc_file_45425);
    _24016 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_55res_file_45431);
    _24017 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_24017);
    RefDS(_24016);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24016;
    ((intptr_t *)_2)[2] = _24017;
    _24018 = MAKE_SEQ(_1);
    _24017 = NOVALUE;
    _24016 = NOVALUE;
    _17writef(_fh_46019, _24015, _24018, 0);
    _24015 = NOVALUE;
    _24018 = NOVALUE;
L1: 

    /** buildsys.e:775			printf(fh, "\t$(LINKER) -o %s $(%s_OBJECTS) %s $(LFLAGS)" & HOSTNL, {*/
    Concat((object_ptr)&_24020, _24019, _44HOSTNL_20392);
    _2 = (object)SEQ_PTR(_55exe_name_45419);
    _24021 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_57file0_44558);
    _24022 = _18upper(_57file0_44558);
    _2 = (object)SEQ_PTR(_55res_file_45431);
    _24023 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24023)){
            _24024 = SEQ_PTR(_24023)->length;
    }
    else {
        _24024 = 1;
    }
    _24023 = NOVALUE;
    _2 = (object)SEQ_PTR(_55res_file_45431);
    _24025 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_24025);
    RefDS(_22015);
    _24026 = _56iif(_24024, _24025, _22015);
    _24024 = NOVALUE;
    _24025 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24021);
    ((intptr_t*)_2)[1] = _24021;
    ((intptr_t*)_2)[2] = _24022;
    ((intptr_t*)_2)[3] = _24026;
    _24027 = MAKE_SEQ(_1);
    _24026 = NOVALUE;
    _24022 = NOVALUE;
    _24021 = NOVALUE;
    EPrintf(_fh_46019, _24020, _24027);
    DeRefDS(_24020);
    _24020 = NOVALUE;
    DeRefDS(_24027);
    _24027 = NOVALUE;

    /** buildsys.e:777			puts(fh, HOSTNL)*/
    EPuts(_fh_46019, _44HOSTNL_20392); // DJP 

    /** buildsys.e:778			printf(fh, ".PHONY: %s-clean %s-clean-all" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_24029, _24028, _44HOSTNL_20392);
    RefDS(_57file0_44558);
    RefDS(_57file0_44558);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _57file0_44558;
    ((intptr_t *)_2)[2] = _57file0_44558;
    _24030 = MAKE_SEQ(_1);
    EPrintf(_fh_46019, _24029, _24030);
    DeRefDS(_24029);
    _24029 = NOVALUE;
    DeRefDS(_24030);
    _24030 = NOVALUE;

    /** buildsys.e:779			puts(fh, HOSTNL)*/
    EPuts(_fh_46019, _44HOSTNL_20392); // DJP 

    /** buildsys.e:780			printf(fh, "%s-clean:" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_24032, _24031, _44HOSTNL_20392);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_57file0_44558);
    ((intptr_t*)_2)[1] = _57file0_44558;
    _24033 = MAKE_SEQ(_1);
    EPrintf(_fh_46019, _24032, _24033);
    DeRefDS(_24032);
    _24032 = NOVALUE;
    DeRefDS(_24033);
    _24033 = NOVALUE;

    /** buildsys.e:781			printf(fh, "\trm -rf $(%s_OBJECTS) %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_24035, _24034, _44HOSTNL_20392);
    RefDS(_57file0_44558);
    _24036 = _18upper(_57file0_44558);
    _2 = (object)SEQ_PTR(_55res_file_45431);
    _24037 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_24037);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24036;
    ((intptr_t *)_2)[2] = _24037;
    _24038 = MAKE_SEQ(_1);
    _24037 = NOVALUE;
    _24036 = NOVALUE;
    EPrintf(_fh_46019, _24035, _24038);
    DeRefDS(_24035);
    _24035 = NOVALUE;
    DeRefDS(_24038);
    _24038 = NOVALUE;

    /** buildsys.e:782			puts(fh, HOSTNL)*/
    EPuts(_fh_46019, _44HOSTNL_20392); // DJP 

    /** buildsys.e:783			printf(fh, "%s-clean-all: %s-clean" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_24040, _24039, _44HOSTNL_20392);
    RefDS(_57file0_44558);
    RefDS(_57file0_44558);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _57file0_44558;
    ((intptr_t *)_2)[2] = _57file0_44558;
    _24041 = MAKE_SEQ(_1);
    EPrintf(_fh_46019, _24040, _24041);
    DeRefDS(_24040);
    _24040 = NOVALUE;
    DeRefDS(_24041);
    _24041 = NOVALUE;

    /** buildsys.e:784			printf(fh, "\trm -rf $(%s_SOURCES) %s %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_24043, _24042, _44HOSTNL_20392);
    RefDS(_57file0_44558);
    _24044 = _18upper(_57file0_44558);
    _2 = (object)SEQ_PTR(_55res_file_45431);
    _24045 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_55exe_name_45419);
    _24046 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24044;
    RefDS(_24045);
    ((intptr_t*)_2)[2] = _24045;
    Ref(_24046);
    ((intptr_t*)_2)[3] = _24046;
    _24047 = MAKE_SEQ(_1);
    _24046 = NOVALUE;
    _24045 = NOVALUE;
    _24044 = NOVALUE;
    EPrintf(_fh_46019, _24043, _24047);
    DeRefDS(_24043);
    _24043 = NOVALUE;
    DeRefDS(_24047);
    _24047 = NOVALUE;

    /** buildsys.e:785			puts(fh, HOSTNL)*/
    EPuts(_fh_46019, _44HOSTNL_20392); // DJP 

    /** buildsys.e:786			puts(fh, "%.o: %.c" & HOSTNL)*/
    Concat((object_ptr)&_24049, _24048, _44HOSTNL_20392);
    EPuts(_fh_46019, _24049); // DJP 
    DeRefDS(_24049);
    _24049 = NOVALUE;

    /** buildsys.e:787			puts(fh, "\t$(CC) $(CFLAGS) $*.c -o $*.o" & HOSTNL)*/
    Concat((object_ptr)&_24051, _24050, _44HOSTNL_20392);
    EPuts(_fh_46019, _24051); // DJP 
    DeRefDS(_24051);
    _24051 = NOVALUE;

    /** buildsys.e:788			puts(fh, HOSTNL)*/
    EPuts(_fh_46019, _44HOSTNL_20392); // DJP 

    /** buildsys.e:791		close(fh)*/
    EClose(_fh_46019);

    /** buildsys.e:792	end procedure*/
    DeRef(_settings_46016);
    _24023 = NOVALUE;
    _24012 = NOVALUE;
    return;
    ;
}


void _55write_makefile_partial()
{
    object _settings_46245 = NOVALUE;
    object _fh_46247 = NOVALUE;
    object _24053 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:798		sequence settings = setup_build()*/
    _0 = _settings_46245;
    _settings_46245 = _55setup_build();
    DeRef(_0);

    /** buildsys.e:799		integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _23927;
        concat_list[1] = _57file0_44558;
        concat_list[2] = _57output_dir_42604;
        Concat_N((object_ptr)&_24053, concat_list, 3);
    }
    _fh_46247 = EOpen(_24053, _23845, 0);
    DeRefDS(_24053);
    _24053 = NOVALUE;

    /** buildsys.e:801		write_makefile_srcobj_list(fh)*/
    _55write_makefile_srcobj_list(_fh_46247);

    /** buildsys.e:803		close(fh)*/
    EClose(_fh_46247);

    /** buildsys.e:804	end procedure*/
    DeRefDS(_settings_46245);
    return;
    ;
}


void _55build_direct(object _link_only_46254, object _the_file0_46255)
{
    object _cmd_46261 = NOVALUE;
    object _objs_46262 = NOVALUE;
    object _settings_46263 = NOVALUE;
    object _cwd_46265 = NOVALUE;
    object _status_46268 = NOVALUE;
    object _link_files_46299 = NOVALUE;
    object _pdone_46325 = NOVALUE;
    object _files_46376 = NOVALUE;
    object _31730 = NOVALUE;
    object _31729 = NOVALUE;
    object _31728 = NOVALUE;
    object _31727 = NOVALUE;
    object _31726 = NOVALUE;
    object _31724 = NOVALUE;
    object _24197 = NOVALUE;
    object _24196 = NOVALUE;
    object _24195 = NOVALUE;
    object _24194 = NOVALUE;
    object _24193 = NOVALUE;
    object _24192 = NOVALUE;
    object _24191 = NOVALUE;
    object _24189 = NOVALUE;
    object _24188 = NOVALUE;
    object _24187 = NOVALUE;
    object _24186 = NOVALUE;
    object _24182 = NOVALUE;
    object _24181 = NOVALUE;
    object _24180 = NOVALUE;
    object _24179 = NOVALUE;
    object _24178 = NOVALUE;
    object _24177 = NOVALUE;
    object _24176 = NOVALUE;
    object _24175 = NOVALUE;
    object _24174 = NOVALUE;
    object _24173 = NOVALUE;
    object _24172 = NOVALUE;
    object _24171 = NOVALUE;
    object _24170 = NOVALUE;
    object _24169 = NOVALUE;
    object _24168 = NOVALUE;
    object _24165 = NOVALUE;
    object _24164 = NOVALUE;
    object _24163 = NOVALUE;
    object _24162 = NOVALUE;
    object _24159 = NOVALUE;
    object _24157 = NOVALUE;
    object _24156 = NOVALUE;
    object _24155 = NOVALUE;
    object _24154 = NOVALUE;
    object _24153 = NOVALUE;
    object _24152 = NOVALUE;
    object _24149 = NOVALUE;
    object _24148 = NOVALUE;
    object _24144 = NOVALUE;
    object _24143 = NOVALUE;
    object _24142 = NOVALUE;
    object _24138 = NOVALUE;
    object _24137 = NOVALUE;
    object _24136 = NOVALUE;
    object _24135 = NOVALUE;
    object _24134 = NOVALUE;
    object _24133 = NOVALUE;
    object _24132 = NOVALUE;
    object _24131 = NOVALUE;
    object _24130 = NOVALUE;
    object _24129 = NOVALUE;
    object _24128 = NOVALUE;
    object _24127 = NOVALUE;
    object _24125 = NOVALUE;
    object _24124 = NOVALUE;
    object _24123 = NOVALUE;
    object _24122 = NOVALUE;
    object _24121 = NOVALUE;
    object _24119 = NOVALUE;
    object _24118 = NOVALUE;
    object _24117 = NOVALUE;
    object _24116 = NOVALUE;
    object _24115 = NOVALUE;
    object _24113 = NOVALUE;
    object _24111 = NOVALUE;
    object _24110 = NOVALUE;
    object _24109 = NOVALUE;
    object _24108 = NOVALUE;
    object _24106 = NOVALUE;
    object _24105 = NOVALUE;
    object _24104 = NOVALUE;
    object _24101 = NOVALUE;
    object _24100 = NOVALUE;
    object _24099 = NOVALUE;
    object _24098 = NOVALUE;
    object _24097 = NOVALUE;
    object _24096 = NOVALUE;
    object _24095 = NOVALUE;
    object _24094 = NOVALUE;
    object _24093 = NOVALUE;
    object _24092 = NOVALUE;
    object _24089 = NOVALUE;
    object _24088 = NOVALUE;
    object _24085 = NOVALUE;
    object _24083 = NOVALUE;
    object _24082 = NOVALUE;
    object _24081 = NOVALUE;
    object _24080 = NOVALUE;
    object _24077 = NOVALUE;
    object _24076 = NOVALUE;
    object _24075 = NOVALUE;
    object _24074 = NOVALUE;
    object _24072 = NOVALUE;
    object _24071 = NOVALUE;
    object _24070 = NOVALUE;
    object _24069 = NOVALUE;
    object _24068 = NOVALUE;
    object _24065 = NOVALUE;
    object _24059 = NOVALUE;
    object _24055 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:810		if length(the_file0) then*/
    _24055 = 0;

    /** buildsys.e:813		sequence cmd, objs = "", settings = setup_build(), cwd = current_dir()*/
    RefDS(_22015);
    DeRef(_objs_46262);
    _objs_46262 = _22015;
    _0 = _settings_46263;
    _settings_46263 = _55setup_build();
    DeRef(_0);
    _0 = _cwd_46265;
    _cwd_46265 = _14current_dir();
    DeRef(_0);

    /** buildsys.e:814		integer status*/

    /** buildsys.e:816		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_46263);
    _24059 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_24059);
    _55ensure_exename(_24059);
    _24059 = NOVALUE;

    /** buildsys.e:818		if not link_only then*/

    /** buildsys.e:819			switch compiler_type do*/
    _0 = 0;
    switch ( _0 ){ 

        /** buildsys.e:820				case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:821					if not silent then*/
        if (_12silent_20342 != 0)
        goto L1; // [72] 123

        /** buildsys.e:822						ShowMsg(1, COMPILING_WITH_1, {"GCC"})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24064);
        ((intptr_t*)_2)[1] = _24064;
        _24065 = MAKE_SEQ(_1);
        _30ShowMsg(1, 176, _24065, 1);
        _24065 = NOVALUE;
        goto L1; // [90] 123

        /** buildsys.e:825				case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:826					write_objlink_file()*/
        _55write_objlink_file();

        /** buildsys.e:828					if not silent then*/
        if (_12silent_20342 != 0)
        goto L2; // [104] 122

        /** buildsys.e:829						ShowMsg(1, COMPILING_WITH_1, {"Watcom"})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24067);
        ((intptr_t*)_2)[1] = _24067;
        _24068 = MAKE_SEQ(_1);
        _30ShowMsg(1, 176, _24068, 1);
        _24068 = NOVALUE;
L2: 
    ;}L1: 

    /** buildsys.e:834		if sequence(output_dir) and length(output_dir) > 0 then*/
    _24069 = 1;
    if (_24069 == 0) {
        goto L3; // [131] 159
    }
    _24071 = 0;
    _24072 = (0 > 0);
    _24071 = NOVALUE;
    if (_24072 == 0)
    {
        DeRef(_24072);
        _24072 = NOVALUE;
        goto L3; // [145] 159
    }
    else{
        DeRef(_24072);
        _24072 = NOVALUE;
    }

    /** buildsys.e:835			chdir(output_dir)*/
    RefDS(_57output_dir_42604);
    _31730 = _14chdir(_57output_dir_42604);
    DeRef(_31730);
    _31730 = NOVALUE;
L3: 

    /** buildsys.e:838		sequence link_files = {}*/
    RefDS(_22015);
    DeRef(_link_files_46299);
    _link_files_46299 = _22015;

    /** buildsys.e:840		if not link_only then*/
    if (_link_only_46254 != 0)
    goto L4; // [168] 482

    /** buildsys.e:841			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42594)){
            _24074 = SEQ_PTR(_57generated_files_42594)->length;
    }
    else {
        _24074 = 1;
    }
    {
        object _i_46303;
        _i_46303 = 1;
L5: 
        if (_i_46303 > _24074){
            goto L6; // [178] 479
        }

        /** buildsys.e:842				if generated_files[i][$] = 'c' then*/
        _2 = (object)SEQ_PTR(_57generated_files_42594);
        _24075 = (object)*(((s1_ptr)_2)->base + _i_46303);
        if (IS_SEQUENCE(_24075)){
                _24076 = SEQ_PTR(_24075)->length;
        }
        else {
            _24076 = 1;
        }
        _2 = (object)SEQ_PTR(_24075);
        _24077 = (object)*(((s1_ptr)_2)->base + _24076);
        _24075 = NOVALUE;
        if (binary_op_a(NOTEQ, _24077, 99)){
            _24077 = NOVALUE;
            goto L7; // [200] 438
        }
        _24077 = NOVALUE;

        /** buildsys.e:843					cmd = sprintf("%s %s %s", { settings[SETUP_CEXE], settings[SETUP_CFLAGS],*/
        _2 = (object)SEQ_PTR(_settings_46263);
        _24080 = (object)*(((s1_ptr)_2)->base + 1);
        _2 = (object)SEQ_PTR(_settings_46263);
        _24081 = (object)*(((s1_ptr)_2)->base + 2);
        _2 = (object)SEQ_PTR(_57generated_files_42594);
        _24082 = (object)*(((s1_ptr)_2)->base + _i_46303);
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_24080);
        ((intptr_t*)_2)[1] = _24080;
        Ref(_24081);
        ((intptr_t*)_2)[2] = _24081;
        RefDS(_24082);
        ((intptr_t*)_2)[3] = _24082;
        _24083 = MAKE_SEQ(_1);
        _24082 = NOVALUE;
        _24081 = NOVALUE;
        _24080 = NOVALUE;
        DeRef(_cmd_46261);
        _cmd_46261 = EPrintf(-9999999, _24079, _24083);
        DeRefDS(_24083);
        _24083 = NOVALUE;

        /** buildsys.e:846					link_files = append(link_files, generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42594);
        _24085 = (object)*(((s1_ptr)_2)->base + _i_46303);
        RefDS(_24085);
        Append(&_link_files_46299, _link_files_46299, _24085);
        _24085 = NOVALUE;

        /** buildsys.e:848					if not silent then*/
        if (_12silent_20342 != 0)
        goto L8; // [246] 374

        /** buildsys.e:849						atom pdone = 100 * (i / length(generated_files))*/
        if (IS_SEQUENCE(_57generated_files_42594)){
                _24088 = SEQ_PTR(_57generated_files_42594)->length;
        }
        else {
            _24088 = 1;
        }
        _24089 = (_i_46303 % _24088) ? NewDouble((eudouble)_i_46303 / _24088) : (_i_46303 / _24088);
        _24088 = NOVALUE;
        DeRef(_pdone_46325);
        if (IS_ATOM_INT(_24089)) {
            if (_24089 <= INT15 && _24089 >= -INT15){
                _pdone_46325 = 100 * _24089;
            }
            else{
                _pdone_46325 = NewDouble(100 * (eudouble)_24089);
            }
        }
        else {
            _pdone_46325 = NewDouble((eudouble)100 * DBL_PTR(_24089)->dbl);
        }
        DeRef(_24089);
        _24089 = NOVALUE;

        /** buildsys.e:850						if not verbose then*/
        if (_12verbose_20345 != 0)
        goto L9; // [268] 358

        /** buildsys.e:853							if 0 and outdated_files[i] = 0 and force_build = 0 then*/
        if (0 == 0) {
            _24092 = 0;
            goto LA; // [273] 291
        }
        _2 = (object)SEQ_PTR(_57outdated_files_42595);
        _24093 = (object)*(((s1_ptr)_2)->base + _i_46303);
        if (IS_ATOM_INT(_24093)) {
            _24094 = (_24093 == 0);
        }
        else {
            _24094 = binary_op(EQUALS, _24093, 0);
        }
        _24093 = NOVALUE;
        if (IS_ATOM_INT(_24094))
        _24092 = (_24094 != 0);
        else
        _24092 = DBL_PTR(_24094)->dbl != 0.0;
LA: 
        if (_24092 == 0) {
            goto LB; // [291] 334
        }
        _24096 = (0 == 0);
        if (_24096 == 0)
        {
            DeRef(_24096);
            _24096 = NOVALUE;
            goto LB; // [302] 334
        }
        else{
            DeRef(_24096);
            _24096 = NOVALUE;
        }

        /** buildsys.e:854								ShowMsg(1, SKIPPING__130_2_UPTODATE, { pdone, generated_files[i] })*/
        _2 = (object)SEQ_PTR(_57generated_files_42594);
        _24097 = (object)*(((s1_ptr)_2)->base + _i_46303);
        RefDS(_24097);
        Ref(_pdone_46325);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46325;
        ((intptr_t *)_2)[2] = _24097;
        _24098 = MAKE_SEQ(_1);
        _24097 = NOVALUE;
        _30ShowMsg(1, 325, _24098, 1);
        _24098 = NOVALUE;

        /** buildsys.e:855								continue*/
        DeRef(_pdone_46325);
        _pdone_46325 = NOVALUE;
        goto LC; // [329] 474
        goto LD; // [331] 373
LB: 

        /** buildsys.e:857								ShowMsg(1, COMPILING_130_2, { pdone, generated_files[i] })*/
        _2 = (object)SEQ_PTR(_57generated_files_42594);
        _24099 = (object)*(((s1_ptr)_2)->base + _i_46303);
        RefDS(_24099);
        Ref(_pdone_46325);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46325;
        ((intptr_t *)_2)[2] = _24099;
        _24100 = MAKE_SEQ(_1);
        _24099 = NOVALUE;
        _30ShowMsg(1, 163, _24100, 1);
        _24100 = NOVALUE;
        goto LD; // [355] 373
L9: 

        /** buildsys.e:860							ShowMsg(1, COMPILING_130_2, { pdone, cmd })*/
        RefDS(_cmd_46261);
        Ref(_pdone_46325);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46325;
        ((intptr_t *)_2)[2] = _cmd_46261;
        _24101 = MAKE_SEQ(_1);
        _30ShowMsg(1, 163, _24101, 1);
        _24101 = NOVALUE;
LD: 
L8: 
        DeRef(_pdone_46325);
        _pdone_46325 = NOVALUE;

        /** buildsys.e:865					status = system_exec(cmd, 0)*/
        _status_46268 = system_exec_call(_cmd_46261, 0);

        /** buildsys.e:866					if status != 0 then*/
        if (_status_46268 == 0)
        goto LE; // [384] 472

        /** buildsys.e:867						ShowMsg(2, COULDNT_COMPILE_FILE_1, { generated_files[i] })*/
        _2 = (object)SEQ_PTR(_57generated_files_42594);
        _24104 = (object)*(((s1_ptr)_2)->base + _i_46303);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24104);
        ((intptr_t*)_2)[1] = _24104;
        _24105 = MAKE_SEQ(_1);
        _24104 = NOVALUE;
        _30ShowMsg(2, 164, _24105, 1);
        _24105 = NOVALUE;

        /** buildsys.e:868						ShowMsg(2, STATUS_1_COMMAND_2, { status, cmd })*/
        RefDS(_cmd_46261);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _status_46268;
        ((intptr_t *)_2)[2] = _cmd_46261;
        _24106 = MAKE_SEQ(_1);
        _30ShowMsg(2, 165, _24106, 1);
        _24106 = NOVALUE;

        /** buildsys.e:869						goto "build_direct_cleanup"*/
        goto GF;
        goto LE; // [435] 472
L7: 

        /** buildsys.e:871				elsif match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_57generated_files_42594);
        _24108 = (object)*(((s1_ptr)_2)->base + _i_46303);
        _24109 = e_match_from(_23166, _24108, 1);
        _24108 = NOVALUE;
        if (_24109 == 0)
        {
            _24109 = NOVALUE;
            goto L10; // [451] 471
        }
        else{
            _24109 = NOVALUE;
        }

        /** buildsys.e:872					objs &= " " & generated_files[i]*/
        _2 = (object)SEQ_PTR(_57generated_files_42594);
        _24110 = (object)*(((s1_ptr)_2)->base + _i_46303);
        Concat((object_ptr)&_24111, _23406, _24110);
        _24110 = NOVALUE;
        Concat((object_ptr)&_objs_46262, _objs_46262, _24111);
        DeRefDS(_24111);
        _24111 = NOVALUE;
L10: 
LE: 

        /** buildsys.e:874			end for*/
LC: 
        _i_46303 = _i_46303 + 1;
        goto L5; // [474] 185
L6: 
        ;
    }
    goto L11; // [479] 541
L4: 

    /** buildsys.e:876			object files = read_lines(file0 & ".bld")*/
    Concat((object_ptr)&_24113, _57file0_44558, _23616);
    _0 = _files_46376;
    _files_46376 = _17read_lines(_24113);
    DeRef(_0);
    _24113 = NOVALUE;

    /** buildsys.e:877			for i = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_46376)){
            _24115 = SEQ_PTR(_files_46376)->length;
    }
    else {
        _24115 = 1;
    }
    {
        object _i_46382;
        _i_46382 = 1;
L12: 
        if (_i_46382 > _24115){
            goto L13; // [499] 538
        }

        /** buildsys.e:878				objs &= " " & filebase(files[i]) & "." & settings[SETUP_OBJ_EXT]*/
        _2 = (object)SEQ_PTR(_files_46376);
        _24116 = (object)*(((s1_ptr)_2)->base + _i_46382);
        Ref(_24116);
        _24117 = _14filebase(_24116);
        _24116 = NOVALUE;
        _2 = (object)SEQ_PTR(_settings_46263);
        _24118 = (object)*(((s1_ptr)_2)->base + 5);
        {
            object concat_list[4];

            concat_list[0] = _24118;
            concat_list[1] = _23205;
            concat_list[2] = _24117;
            concat_list[3] = _23406;
            Concat_N((object_ptr)&_24119, concat_list, 4);
        }
        _24118 = NOVALUE;
        DeRef(_24117);
        _24117 = NOVALUE;
        Concat((object_ptr)&_objs_46262, _objs_46262, _24119);
        DeRefDS(_24119);
        _24119 = NOVALUE;

        /** buildsys.e:879			end for*/
        _i_46382 = _i_46382 + 1;
        goto L12; // [533] 506
L13: 
        ;
    }
    DeRef(_files_46376);
    _files_46376 = NOVALUE;
L11: 

    /** buildsys.e:882		if keep and not link_only and length(link_files) then*/
    if (_57keep_42597 == 0) {
        _24121 = 0;
        goto L14; // [545] 556
    }
    _24122 = (_link_only_46254 == 0);
    _24121 = (_24122 != 0);
L14: 
    if (_24121 == 0) {
        goto L15; // [556] 585
    }
    if (IS_SEQUENCE(_link_files_46299)){
            _24124 = SEQ_PTR(_link_files_46299)->length;
    }
    else {
        _24124 = 1;
    }
    if (_24124 == 0)
    {
        _24124 = NOVALUE;
        goto L15; // [564] 585
    }
    else{
        _24124 = NOVALUE;
    }

    /** buildsys.e:883			write_lines(file0 & ".bld", link_files)*/
    Concat((object_ptr)&_24125, _57file0_44558, _23616);
    RefDS(_link_files_46299);
    _31729 = _17write_lines(_24125, _link_files_46299);
    _24125 = NOVALUE;
    DeRef(_31729);
    _31729 = NOVALUE;
    goto L16; // [582] 609
L15: 

    /** buildsys.e:884		elsif keep = 0 then*/
    if (_57keep_42597 != 0)
    goto L17; // [589] 608

    /** buildsys.e:886			delete_file(file0 & ".bld")*/
    Concat((object_ptr)&_24127, _57file0_44558, _23616);
    _31728 = _14delete_file(_24127);
    _24127 = NOVALUE;
    DeRef(_31728);
    _31728 = NOVALUE;
L17: 
L16: 

    /** buildsys.e:890		if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_GCC then*/
    _2 = (object)SEQ_PTR(_55rc_file_45425);
    _24128 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24128)){
            _24129 = SEQ_PTR(_24128)->length;
    }
    else {
        _24129 = 1;
    }
    _24128 = NOVALUE;
    if (_24129 == 0) {
        _24130 = 0;
        goto L18; // [622] 637
    }
    _2 = (object)SEQ_PTR(_settings_46263);
    _24131 = (object)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_24131)){
            _24132 = SEQ_PTR(_24131)->length;
    }
    else {
        _24132 = 1;
    }
    _24131 = NOVALUE;
    _24130 = (_24132 != 0);
L18: 
    if (_24130 == 0) {
        goto L19; // [637] 742
    }
    _24134 = (0 == 1);
    if (_24134 == 0)
    {
        DeRef(_24134);
        _24134 = NOVALUE;
        goto L19; // [648] 742
    }
    else{
        DeRef(_24134);
        _24134 = NOVALUE;
    }

    /** buildsys.e:891			cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46263);
    _24135 = (object)*(((s1_ptr)_2)->base + 8);
    _2 = (object)SEQ_PTR(_55rc_file_45425);
    _24136 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_55res_file_45431);
    _24137 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_24137);
    RefDS(_24136);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24136;
    ((intptr_t *)_2)[2] = _24137;
    _24138 = MAKE_SEQ(_1);
    _24137 = NOVALUE;
    _24136 = NOVALUE;
    Ref(_24135);
    _0 = _cmd_46261;
    _cmd_46261 = _18format(_24135, _24138);
    DeRef(_0);
    _24135 = NOVALUE;
    _24138 = NOVALUE;

    /** buildsys.e:892			status = system_exec(cmd, 0)*/
    _status_46268 = system_exec_call(_cmd_46261, 0);

    /** buildsys.e:893			if status != 0 then*/
    if (_status_46268 == 0)
    goto L1A; // [692] 741

    /** buildsys.e:894				ShowMsg(2, UNABLE_TO_COMPILE_RESOURCE_FILE_1, { rc_file[D_NAME] })*/
    _2 = (object)SEQ_PTR(_55rc_file_45425);
    _24142 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_24142);
    ((intptr_t*)_2)[1] = _24142;
    _24143 = MAKE_SEQ(_1);
    _24142 = NOVALUE;
    _30ShowMsg(2, 350, _24143, 1);
    _24143 = NOVALUE;

    /** buildsys.e:895				ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46261);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46268;
    ((intptr_t *)_2)[2] = _cmd_46261;
    _24144 = MAKE_SEQ(_1);
    _30ShowMsg(2, 169, _24144, 1);
    _24144 = NOVALUE;

    /** buildsys.e:897				goto "build_direct_cleanup"*/
    goto GF;
L1A: 
L19: 

    /** buildsys.e:901		switch compiler_type do*/
    _0 = 0;
    switch ( _0 ){ 

        /** buildsys.e:902			case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:903				cmd = sprintf("%s @%s.lnk", { settings[SETUP_LEXE], file0 })*/
        _2 = (object)SEQ_PTR(_settings_46263);
        _24148 = (object)*(((s1_ptr)_2)->base + 3);
        RefDS(_57file0_44558);
        Ref(_24148);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _24148;
        ((intptr_t *)_2)[2] = _57file0_44558;
        _24149 = MAKE_SEQ(_1);
        _24148 = NOVALUE;
        DeRef(_cmd_46261);
        _cmd_46261 = EPrintf(-9999999, _24147, _24149);
        DeRefDS(_24149);
        _24149 = NOVALUE;
        goto L1B; // [771] 848

        /** buildsys.e:905			case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:906				cmd = sprintf("%s -o %s %s %s %s", { */
        _2 = (object)SEQ_PTR(_settings_46263);
        _24152 = (object)*(((s1_ptr)_2)->base + 3);
        _2 = (object)SEQ_PTR(_55exe_name_45419);
        _24153 = (object)*(((s1_ptr)_2)->base + 11);
        Ref(_24153);
        _24154 = _55adjust_for_build_file(_24153);
        _24153 = NOVALUE;
        _2 = (object)SEQ_PTR(_55res_file_45431);
        _24155 = (object)*(((s1_ptr)_2)->base + 11);
        _2 = (object)SEQ_PTR(_settings_46263);
        _24156 = (object)*(((s1_ptr)_2)->base + 4);
        _1 = NewS1(5);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_24152);
        ((intptr_t*)_2)[1] = _24152;
        ((intptr_t*)_2)[2] = _24154;
        RefDS(_objs_46262);
        ((intptr_t*)_2)[3] = _objs_46262;
        RefDS(_24155);
        ((intptr_t*)_2)[4] = _24155;
        Ref(_24156);
        ((intptr_t*)_2)[5] = _24156;
        _24157 = MAKE_SEQ(_1);
        _24156 = NOVALUE;
        _24155 = NOVALUE;
        _24154 = NOVALUE;
        _24152 = NOVALUE;
        DeRef(_cmd_46261);
        _cmd_46261 = EPrintf(-9999999, _24151, _24157);
        DeRefDS(_24157);
        _24157 = NOVALUE;
        goto L1B; // [819] 848

        /** buildsys.e:915			case else*/
        default:

        /** buildsys.e:916				ShowMsg(2, UNKNOWN_COMPILER_TYPE_1, { compiler_type })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 0;
        _24159 = MAKE_SEQ(_1);
        _30ShowMsg(2, 167, _24159, 1);
        _24159 = NOVALUE;

        /** buildsys.e:918				goto "build_direct_cleanup"*/
        goto GF;
    ;}L1B: 

    /** buildsys.e:921		if not silent then*/
    if (_12silent_20342 != 0)
    goto L1C; // [852] 910

    /** buildsys.e:922			if not verbose then*/
    if (_12verbose_20345 != 0)
    goto L1D; // [859] 892

    /** buildsys.e:923				ShowMsg(1, LINKING_100_1, { abbreviate_path(exe_name[D_NAME]) })*/
    _2 = (object)SEQ_PTR(_55exe_name_45419);
    _24162 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_24162);
    RefDS(_22015);
    _24163 = _14abbreviate_path(_24162, _22015);
    _24162 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24163;
    _24164 = MAKE_SEQ(_1);
    _24163 = NOVALUE;
    _30ShowMsg(1, 166, _24164, 1);
    _24164 = NOVALUE;
    goto L1E; // [889] 909
L1D: 

    /** buildsys.e:925				ShowMsg(1, LINKING_100_1, { cmd })*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_cmd_46261);
    ((intptr_t*)_2)[1] = _cmd_46261;
    _24165 = MAKE_SEQ(_1);
    _30ShowMsg(1, 166, _24165, 1);
    _24165 = NOVALUE;
L1E: 
L1C: 

    /** buildsys.e:929		status = system_exec(cmd, 0)*/
    _status_46268 = system_exec_call(_cmd_46261, 0);

    /** buildsys.e:930		if status != 0 then*/
    if (_status_46268 == 0)
    goto L1F; // [920] 967

    /** buildsys.e:931			ShowMsg(2, UNABLE_TO_LINK_1, { exe_name[D_NAME] })*/
    _2 = (object)SEQ_PTR(_55exe_name_45419);
    _24168 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24168);
    ((intptr_t*)_2)[1] = _24168;
    _24169 = MAKE_SEQ(_1);
    _24168 = NOVALUE;
    _30ShowMsg(2, 168, _24169, 1);
    _24169 = NOVALUE;

    /** buildsys.e:932			ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46261);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46268;
    ((intptr_t *)_2)[2] = _cmd_46261;
    _24170 = MAKE_SEQ(_1);
    _30ShowMsg(2, 169, _24170, 1);
    _24170 = NOVALUE;

    /** buildsys.e:934			goto "build_direct_cleanup"*/
    goto GF;
L1F: 

    /** buildsys.e:938		if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_WATCOM then*/
    _2 = (object)SEQ_PTR(_55rc_file_45425);
    _24171 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24171)){
            _24172 = SEQ_PTR(_24171)->length;
    }
    else {
        _24172 = 1;
    }
    _24171 = NOVALUE;
    if (_24172 == 0) {
        _24173 = 0;
        goto L20; // [980] 995
    }
    _2 = (object)SEQ_PTR(_settings_46263);
    _24174 = (object)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_24174)){
            _24175 = SEQ_PTR(_24174)->length;
    }
    else {
        _24175 = 1;
    }
    _24174 = NOVALUE;
    _24173 = (_24175 != 0);
L20: 
    if (_24173 == 0) {
        goto L21; // [995] 1118
    }
    _24177 = (0 == 2);
    if (_24177 == 0)
    {
        DeRef(_24177);
        _24177 = NOVALUE;
        goto L21; // [1006] 1118
    }
    else{
        DeRef(_24177);
        _24177 = NOVALUE;
    }

    /** buildsys.e:939			cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46263);
    _24178 = (object)*(((s1_ptr)_2)->base + 8);
    _2 = (object)SEQ_PTR(_55rc_file_45425);
    _24179 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_55res_file_45431);
    _24180 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_55exe_name_45419);
    _24181 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_24179);
    ((intptr_t*)_2)[1] = _24179;
    RefDS(_24180);
    ((intptr_t*)_2)[2] = _24180;
    Ref(_24181);
    ((intptr_t*)_2)[3] = _24181;
    _24182 = MAKE_SEQ(_1);
    _24181 = NOVALUE;
    _24180 = NOVALUE;
    _24179 = NOVALUE;
    Ref(_24178);
    _0 = _cmd_46261;
    _cmd_46261 = _18format(_24178, _24182);
    DeRef(_0);
    _24178 = NOVALUE;
    _24182 = NOVALUE;

    /** buildsys.e:940			status = system_exec(cmd, 0)*/
    _status_46268 = system_exec_call(_cmd_46261, 0);

    /** buildsys.e:941			if status != 0 then*/
    if (_status_46268 == 0)
    goto L22; // [1060] 1117

    /** buildsys.e:942				ShowMsg(2, UNABLE_TO_LINK_RESOURCE_FILE_1_INTO_EXECUTABLE_2, { rc_file[D_NAME], exe_name[D_NAME] })*/
    _2 = (object)SEQ_PTR(_55rc_file_45425);
    _24186 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_55exe_name_45419);
    _24187 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_24187);
    RefDS(_24186);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24186;
    ((intptr_t *)_2)[2] = _24187;
    _24188 = MAKE_SEQ(_1);
    _24187 = NOVALUE;
    _24186 = NOVALUE;
    _30ShowMsg(2, 187, _24188, 1);
    _24188 = NOVALUE;

    /** buildsys.e:943				ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46261);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46268;
    ((intptr_t *)_2)[2] = _cmd_46261;
    _24189 = MAKE_SEQ(_1);
    _30ShowMsg(2, 169, _24189, 1);
    _24189 = NOVALUE;

    /** buildsys.e:945				goto "build_direct_cleanup"*/
    goto GF;
L22: 
L21: 

    /** buildsys.e:949	label "build_direct_cleanup"*/
GF:

    /** buildsys.e:950		if keep = 0 then*/
    if (_57keep_42597 != 0)
    goto L23; // [1126] 1277

    /** buildsys.e:951			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42594)){
            _24191 = SEQ_PTR(_57generated_files_42594)->length;
    }
    else {
        _24191 = 1;
    }
    {
        object _i_46518;
        _i_46518 = 1;
L24: 
        if (_i_46518 > _24191){
            goto L25; // [1137] 1193
        }

        /** buildsys.e:952				if verbose then*/
        if (_12verbose_20345 == 0)
        {
            goto L26; // [1148] 1172
        }
        else{
        }

        /** buildsys.e:953					ShowMsg(1, DELETING_1, { generated_files[i] })*/
        _2 = (object)SEQ_PTR(_57generated_files_42594);
        _24192 = (object)*(((s1_ptr)_2)->base + _i_46518);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24192);
        ((intptr_t*)_2)[1] = _24192;
        _24193 = MAKE_SEQ(_1);
        _24192 = NOVALUE;
        _30ShowMsg(1, 347, _24193, 1);
        _24193 = NOVALUE;
L26: 

        /** buildsys.e:955				delete_file(generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42594);
        _24194 = (object)*(((s1_ptr)_2)->base + _i_46518);
        RefDS(_24194);
        _31727 = _14delete_file(_24194);
        _24194 = NOVALUE;
        DeRef(_31727);
        _31727 = NOVALUE;

        /** buildsys.e:956			end for*/
        _i_46518 = _i_46518 + 1;
        goto L24; // [1188] 1144
L25: 
        ;
    }

    /** buildsys.e:958			if length(res_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_55res_file_45431);
    _24195 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24195)){
            _24196 = SEQ_PTR(_24195)->length;
    }
    else {
        _24196 = 1;
    }
    _24195 = NOVALUE;
    if (_24196 == 0)
    {
        _24196 = NOVALUE;
        goto L27; // [1206] 1226
    }
    else{
        _24196 = NOVALUE;
    }

    /** buildsys.e:959				delete_file(res_file[D_ALTNAME])*/
    _2 = (object)SEQ_PTR(_55res_file_45431);
    _24197 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_24197);
    _31726 = _14delete_file(_24197);
    _24197 = NOVALUE;
    DeRef(_31726);
    _31726 = NOVALUE;
L27: 

    /** buildsys.e:962			if remove_output_dir then*/
L23: 

    /** buildsys.e:972		chdir(cwd)*/
    RefDS(_cwd_46265);
    _31724 = _14chdir(_cwd_46265);
    DeRef(_31724);
    _31724 = NOVALUE;

    /** buildsys.e:973	end procedure*/
    DeRefDS(_the_file0_46255);
    DeRef(_cmd_46261);
    DeRef(_objs_46262);
    DeRef(_settings_46263);
    DeRefDS(_cwd_46265);
    DeRef(_link_files_46299);
    DeRef(_24122);
    _24122 = NOVALUE;
    DeRef(_24094);
    _24094 = NOVALUE;
    _24174 = NOVALUE;
    _24128 = NOVALUE;
    _24131 = NOVALUE;
    _24195 = NOVALUE;
    _24171 = NOVALUE;
    return;
    ;
}


void _55write_buildfile()
{
    object _make_command_46560 = NOVALUE;
    object _settings_46605 = NOVALUE;
    object _24224 = NOVALUE;
    object _24223 = NOVALUE;
    object _24219 = NOVALUE;
    object _24218 = NOVALUE;
    object _24217 = NOVALUE;
    object _24215 = NOVALUE;
    object _24214 = NOVALUE;
    object _24213 = NOVALUE;
    object _24212 = NOVALUE;
    object _24211 = NOVALUE;
    object _24210 = NOVALUE;
    object _24209 = NOVALUE;
    object _24208 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:982		switch build_system_type do*/
    _0 = 3;
    switch ( _0 ){ 

        /** buildsys.e:983			case BUILD_MAKEFILE_FULL then*/
        case 2:

        /** buildsys.e:984				write_makefile_full()*/
        _55write_makefile_full();

        /** buildsys.e:986				if not silent then*/
        if (_12silent_20342 != 0)
        goto L1; // [22] 142

        /** buildsys.e:987					sequence make_command*/

        /** buildsys.e:988					if compiler_type = COMPILER_WATCOM then*/

        /** buildsys.e:991						make_command = "make -f "*/
        RefDS(_24207);
        DeRefi(_make_command_46560);
        _make_command_46560 = _24207;

        /** buildsys.e:994					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24208 = _12cfile_count_20305 + 2;
        if ((object)((uintptr_t)_24208 + (uintptr_t)HIGH_BITS) >= 0){
            _24208 = NewDouble((eudouble)_24208);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24208;
        _24209 = MAKE_SEQ(_1);
        _24208 = NOVALUE;
        _30ShowMsg(1, 170, _24209, 1);
        _24209 = NOVALUE;

        /** buildsys.e:996					if sequence(output_dir) and length(output_dir) > 0 then*/
        _24210 = 1;
        if (_24210 == 0) {
            goto L2; // [80] 122
        }
        _24212 = 0;
        _24213 = (0 > 0);
        _24212 = NOVALUE;
        if (_24213 == 0)
        {
            DeRef(_24213);
            _24213 = NOVALUE;
            goto L2; // [94] 122
        }
        else{
            DeRef(_24213);
            _24213 = NOVALUE;
        }

        /** buildsys.e:997						ShowMsg(1, TO_BUILD_YOUR_PROJECT_CHANGE_DIRECTORY_TO_1_AND_TYPE_23MAK, { output_dir, make_command, file0 })*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_57output_dir_42604);
        ((intptr_t*)_2)[1] = _57output_dir_42604;
        RefDS(_make_command_46560);
        ((intptr_t*)_2)[2] = _make_command_46560;
        RefDS(_57file0_44558);
        ((intptr_t*)_2)[3] = _57file0_44558;
        _24214 = MAKE_SEQ(_1);
        _30ShowMsg(1, 174, _24214, 1);
        _24214 = NOVALUE;
        goto L3; // [119] 141
L2: 

        /** buildsys.e:999						ShowMsg(1, TO_BUILD_YOUR_PROJECT_TYPE_12MAK, { make_command, file0 })*/
        RefDS(_57file0_44558);
        RefDS(_make_command_46560);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _make_command_46560;
        ((intptr_t *)_2)[2] = _57file0_44558;
        _24215 = MAKE_SEQ(_1);
        _30ShowMsg(1, 172, _24215, 1);
        _24215 = NOVALUE;
L3: 
L1: 
        DeRefi(_make_command_46560);
        _make_command_46560 = NOVALUE;
        goto L4; // [144] 277

        /** buildsys.e:1003			case BUILD_MAKEFILE_PARTIAL then*/
        case 1:

        /** buildsys.e:1004				write_makefile_partial()*/
        _55write_makefile_partial();

        /** buildsys.e:1006				if not silent then*/
        if (_12silent_20342 != 0)
        goto L4; // [158] 277

        /** buildsys.e:1007					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24217 = _12cfile_count_20305 + 2;
        if ((object)((uintptr_t)_24217 + (uintptr_t)HIGH_BITS) >= 0){
            _24217 = NewDouble((eudouble)_24217);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24217;
        _24218 = MAKE_SEQ(_1);
        _24217 = NOVALUE;
        _30ShowMsg(1, 170, _24218, 1);
        _24218 = NOVALUE;

        /** buildsys.e:1008					ShowMsg(1, TO_BUILD_YOUR_PROJECT_INCLUDE_1MAK_INTO_A_LARGER_MAKEFILE_PROJECT, { file0 })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_57file0_44558);
        ((intptr_t*)_2)[1] = _57file0_44558;
        _24219 = MAKE_SEQ(_1);
        _30ShowMsg(1, 173, _24219, 1);
        _24219 = NOVALUE;
        goto L4; // [198] 277

        /** buildsys.e:1011			case BUILD_DIRECT then*/
        case 3:

        /** buildsys.e:1012				build_direct()*/
        RefDS(_22015);
        _55build_direct(0, _22015);

        /** buildsys.e:1014				if not silent then*/
        if (_12silent_20342 != 0)
        goto L5; // [214] 225

        /** buildsys.e:1015					sequence settings = setup_build()*/
        _0 = _settings_46605;
        _settings_46605 = _55setup_build();
        DeRef(_0);
L5: 
        DeRef(_settings_46605);
        _settings_46605 = NOVALUE;
        goto L4; // [227] 277

        /** buildsys.e:1019			case BUILD_NONE then*/
        case 0:

        /** buildsys.e:1020				if not silent then*/
        if (_12silent_20342 != 0)
        goto L4; // [237] 277

        /** buildsys.e:1021					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24223 = _12cfile_count_20305 + 2;
        if ((object)((uintptr_t)_24223 + (uintptr_t)HIGH_BITS) >= 0){
            _24223 = NewDouble((eudouble)_24223);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24223;
        _24224 = MAKE_SEQ(_1);
        _24223 = NOVALUE;
        _30ShowMsg(1, 170, _24224, 1);
        _24224 = NOVALUE;
        goto L4; // [261] 277

        /** buildsys.e:1026			case else*/
        default:

        /** buildsys.e:1027				CompileErr(UNKNOWN_BUILD_FILE_TYPE)*/
        RefDS(_22015);
        _49CompileErr(151, _22015, 0);
    ;}L4: 

    /** buildsys.e:1029	end procedure*/
    return;
    ;
}



// 0x93232C96
