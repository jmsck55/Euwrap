// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _10pretty_out(object _text_1429)
{
    object _575 = NOVALUE;
    object _573 = NOVALUE;
    object _571 = NOVALUE;
    object _570 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:19		pretty_line &= text*/
    if (IS_SEQUENCE(_10pretty_line_1426) && IS_ATOM(_text_1429)) {
        Ref(_text_1429);
        Append(&_10pretty_line_1426, _10pretty_line_1426, _text_1429);
    }
    else if (IS_ATOM(_10pretty_line_1426) && IS_SEQUENCE(_text_1429)) {
    }
    else {
        Concat((object_ptr)&_10pretty_line_1426, _10pretty_line_1426, _text_1429);
    }

    /** pretty.e:20		if equal(text, '\n') and pretty_printing then*/
    if (_text_1429 == 10)
    _570 = 1;
    else if (IS_ATOM_INT(_text_1429) && IS_ATOM_INT(10))
    _570 = 0;
    else
    _570 = (compare(_text_1429, 10) == 0);
    if (_570 == 0) {
        goto L1; // [15] 50
    }
    if (_10pretty_printing_1423 == 0)
    {
        goto L1; // [22] 50
    }
    else{
    }

    /** pretty.e:21			puts(pretty_file, pretty_line)*/
    EPuts(_10pretty_file_1414, _10pretty_line_1426); // DJP 

    /** pretty.e:22			pretty_line = ""*/
    RefDS(_5);
    DeRefDS(_10pretty_line_1426);
    _10pretty_line_1426 = _5;

    /** pretty.e:23			pretty_line_count += 1*/
    _10pretty_line_count_1419 = _10pretty_line_count_1419 + 1;
L1: 

    /** pretty.e:25		if atom(text) then*/
    _573 = IS_ATOM(_text_1429);
    if (_573 == 0)
    {
        _573 = NOVALUE;
        goto L2; // [55] 69
    }
    else{
        _573 = NOVALUE;
    }

    /** pretty.e:26			pretty_chars += 1*/
    _10pretty_chars_1411 = _10pretty_chars_1411 + 1;
    goto L3; // [66] 81
L2: 

    /** pretty.e:28			pretty_chars += length(text)*/
    if (IS_SEQUENCE(_text_1429)){
            _575 = SEQ_PTR(_text_1429)->length;
    }
    else {
        _575 = 1;
    }
    _10pretty_chars_1411 = _10pretty_chars_1411 + _575;
    _575 = NOVALUE;
L3: 

    /** pretty.e:30	end procedure*/
    DeRef(_text_1429);
    return;
    ;
}


void _10cut_line(object _n_1443)
{
    object _578 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:34		if not pretty_line_breaks then	*/
    if (_10pretty_line_breaks_1422 != 0)
    goto L1; // [7] 21

    /** pretty.e:35			pretty_chars = 0*/
    _10pretty_chars_1411 = 0;

    /** pretty.e:36			return*/
    return;
L1: 

    /** pretty.e:38		if pretty_chars + n > pretty_end_col then*/
    _578 = _10pretty_chars_1411 + _n_1443;
    if ((object)((uintptr_t)_578 + (uintptr_t)HIGH_BITS) >= 0){
        _578 = NewDouble((eudouble)_578);
    }
    if (binary_op_a(LESSEQ, _578, _10pretty_end_col_1410)){
        DeRef(_578);
        _578 = NOVALUE;
        goto L2; // [31] 46
    }
    DeRef(_578);
    _578 = NOVALUE;

    /** pretty.e:39			pretty_out('\n')*/
    _10pretty_out(10);

    /** pretty.e:40			pretty_chars = 0*/
    _10pretty_chars_1411 = 0;
L2: 

    /** pretty.e:42	end procedure*/
    return;
    ;
}


void _10indent()
{
    object _586 = NOVALUE;
    object _585 = NOVALUE;
    object _584 = NOVALUE;
    object _583 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:46		if pretty_line_breaks = 0 then	*/
    if (_10pretty_line_breaks_1422 != 0)
    goto L1; // [5] 22

    /** pretty.e:47			pretty_chars = 0*/
    _10pretty_chars_1411 = 0;

    /** pretty.e:48			return*/
    return;
    goto L2; // [19] 85
L1: 

    /** pretty.e:49		elsif pretty_line_breaks = -1 then*/
    if (_10pretty_line_breaks_1422 != -1)
    goto L3; // [26] 38

    /** pretty.e:51			cut_line( 0 )*/
    _10cut_line(0);
    goto L2; // [35] 85
L3: 

    /** pretty.e:54			if pretty_chars > 0 then*/
    if (_10pretty_chars_1411 <= 0)
    goto L4; // [42] 57

    /** pretty.e:55				pretty_out('\n')*/
    _10pretty_out(10);

    /** pretty.e:56				pretty_chars = 0*/
    _10pretty_chars_1411 = 0;
L4: 

    /** pretty.e:58			pretty_out(repeat(' ', (pretty_start_col-1) + */
    _583 = _10pretty_start_col_1412 - 1;
    if ((object)((uintptr_t)_583 +(uintptr_t) HIGH_BITS) >= 0){
        _583 = NewDouble((eudouble)_583);
    }
    if (_10pretty_level_1413 == (short)_10pretty_level_1413 && _10pretty_indent_1416 <= INT15 && _10pretty_indent_1416 >= -INT15){
        _584 = _10pretty_level_1413 * _10pretty_indent_1416;
    }
    else{
        _584 = NewDouble(_10pretty_level_1413 * (eudouble)_10pretty_indent_1416);
    }
    if (IS_ATOM_INT(_583) && IS_ATOM_INT(_584)) {
        _585 = _583 + _584;
    }
    else {
        if (IS_ATOM_INT(_583)) {
            _585 = NewDouble((eudouble)_583 + DBL_PTR(_584)->dbl);
        }
        else {
            if (IS_ATOM_INT(_584)) {
                _585 = NewDouble(DBL_PTR(_583)->dbl + (eudouble)_584);
            }
            else
            _585 = NewDouble(DBL_PTR(_583)->dbl + DBL_PTR(_584)->dbl);
        }
    }
    DeRef(_583);
    _583 = NOVALUE;
    DeRef(_584);
    _584 = NOVALUE;
    _586 = Repeat(32, _585);
    DeRef(_585);
    _585 = NOVALUE;
    _10pretty_out(_586);
    _586 = NOVALUE;
L2: 

    /** pretty.e:62	end procedure*/
    return;
    ;
}


object _10esc_char(object _a_1464)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_1464)) {
        _1 = (object)(DBL_PTR(_a_1464)->dbl);
        DeRefDS(_a_1464);
        _a_1464 = _1;
    }

    /** pretty.e:66		switch a do*/
    _0 = _a_1464;
    switch ( _0 ){ 

        /** pretty.e:67			case'\t' then*/
        case 9:

        /** pretty.e:68				return `\t`*/
        RefDS(_589);
        return _589;
        goto L1; // [20] 81

        /** pretty.e:70			case'\n' then*/
        case 10:

        /** pretty.e:71				return `\n`*/
        RefDS(_590);
        return _590;
        goto L1; // [32] 81

        /** pretty.e:73			case'\r' then*/
        case 13:

        /** pretty.e:74				return `\r`*/
        RefDS(_591);
        return _591;
        goto L1; // [44] 81

        /** pretty.e:76			case'\\' then*/
        case 92:

        /** pretty.e:77				return `\\`*/
        RefDS(_593);
        return _593;
        goto L1; // [56] 81

        /** pretty.e:79			case'"' then*/
        case 34:

        /** pretty.e:80				return `\"`*/
        RefDS(_595);
        return _595;
        goto L1; // [68] 81

        /** pretty.e:82			case else*/
        default:

        /** pretty.e:83				return a*/
        return _a_1464;
    ;}L1: 
    ;
}


void _10rPrint(object _a_1482)
{
    object _sbuff_1483 = NOVALUE;
    object _multi_line_1484 = NOVALUE;
    object _all_ascii_1485 = NOVALUE;
    object _652 = NOVALUE;
    object _651 = NOVALUE;
    object _650 = NOVALUE;
    object _649 = NOVALUE;
    object _645 = NOVALUE;
    object _644 = NOVALUE;
    object _643 = NOVALUE;
    object _642 = NOVALUE;
    object _640 = NOVALUE;
    object _639 = NOVALUE;
    object _637 = NOVALUE;
    object _636 = NOVALUE;
    object _634 = NOVALUE;
    object _633 = NOVALUE;
    object _632 = NOVALUE;
    object _631 = NOVALUE;
    object _630 = NOVALUE;
    object _629 = NOVALUE;
    object _628 = NOVALUE;
    object _627 = NOVALUE;
    object _626 = NOVALUE;
    object _625 = NOVALUE;
    object _624 = NOVALUE;
    object _623 = NOVALUE;
    object _622 = NOVALUE;
    object _621 = NOVALUE;
    object _620 = NOVALUE;
    object _619 = NOVALUE;
    object _618 = NOVALUE;
    object _614 = NOVALUE;
    object _613 = NOVALUE;
    object _612 = NOVALUE;
    object _611 = NOVALUE;
    object _610 = NOVALUE;
    object _609 = NOVALUE;
    object _607 = NOVALUE;
    object _606 = NOVALUE;
    object _602 = NOVALUE;
    object _601 = NOVALUE;
    object _600 = NOVALUE;
    object _597 = NOVALUE;
    object _596 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:92		if atom(a) then*/
    _596 = IS_ATOM(_a_1482);
    if (_596 == 0)
    {
        _596 = NOVALUE;
        goto L1; // [6] 176
    }
    else{
        _596 = NOVALUE;
    }

    /** pretty.e:93			if integer(a) then*/
    if (IS_ATOM_INT(_a_1482))
    _597 = 1;
    else if (IS_ATOM_DBL(_a_1482))
    _597 = IS_ATOM_INT(DoubleToInt(_a_1482));
    else
    _597 = 0;
    if (_597 == 0)
    {
        _597 = NOVALUE;
        goto L2; // [14] 157
    }
    else{
        _597 = NOVALUE;
    }

    /** pretty.e:94				sbuff = sprintf(pretty_int_format, a)*/
    DeRef(_sbuff_1483);
    _sbuff_1483 = EPrintf(-9999999, _10pretty_int_format_1425, _a_1482);

    /** pretty.e:95				if pretty_ascii then */
    if (_10pretty_ascii_1415 == 0)
    {
        goto L3; // [29] 166
    }
    else{
    }

    /** pretty.e:96					if pretty_ascii >= 3 then */
    if (_10pretty_ascii_1415 < 3)
    goto L4; // [36] 103

    /** pretty.e:98						if (a >= pretty_ascii_min and a <= pretty_ascii_max) then*/
    if (IS_ATOM_INT(_a_1482)) {
        _600 = (_a_1482 >= _10pretty_ascii_min_1417);
    }
    else {
        _600 = binary_op(GREATEREQ, _a_1482, _10pretty_ascii_min_1417);
    }
    if (IS_ATOM_INT(_600)) {
        if (_600 == 0) {
            _601 = 0;
            goto L5; // [48] 62
        }
    }
    else {
        if (DBL_PTR(_600)->dbl == 0.0) {
            _601 = 0;
            goto L5; // [48] 62
        }
    }
    if (IS_ATOM_INT(_a_1482)) {
        _602 = (_a_1482 <= _10pretty_ascii_max_1418);
    }
    else {
        _602 = binary_op(LESSEQ, _a_1482, _10pretty_ascii_max_1418);
    }
    DeRef(_601);
    if (IS_ATOM_INT(_602))
    _601 = (_602 != 0);
    else
    _601 = DBL_PTR(_602)->dbl != 0.0;
L5: 
    if (_601 == 0)
    {
        _601 = NOVALUE;
        goto L6; // [62] 76
    }
    else{
        _601 = NOVALUE;
    }

    /** pretty.e:99							sbuff = '\'' & a & '\''  -- display char only*/
    {
        object concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _a_1482;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_sbuff_1483, concat_list, 3);
    }
    goto L3; // [73] 166
L6: 

    /** pretty.e:101						elsif find(a, "\t\n\r\\") then*/
    _606 = find_from(_a_1482, _605, 1);
    if (_606 == 0)
    {
        _606 = NOVALUE;
        goto L3; // [83] 166
    }
    else{
        _606 = NOVALUE;
    }

    /** pretty.e:102							sbuff = '\'' & esc_char(a) & '\''  -- display char only*/
    Ref(_a_1482);
    _607 = _10esc_char(_a_1482);
    {
        object concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _607;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_sbuff_1483, concat_list, 3);
    }
    DeRef(_607);
    _607 = NOVALUE;
    goto L3; // [100] 166
L4: 

    /** pretty.e:107						if (a >= pretty_ascii_min and a <= pretty_ascii_max) and pretty_ascii < 2 then*/
    if (IS_ATOM_INT(_a_1482)) {
        _609 = (_a_1482 >= _10pretty_ascii_min_1417);
    }
    else {
        _609 = binary_op(GREATEREQ, _a_1482, _10pretty_ascii_min_1417);
    }
    if (IS_ATOM_INT(_609)) {
        if (_609 == 0) {
            DeRef(_610);
            _610 = 0;
            goto L7; // [111] 125
        }
    }
    else {
        if (DBL_PTR(_609)->dbl == 0.0) {
            DeRef(_610);
            _610 = 0;
            goto L7; // [111] 125
        }
    }
    if (IS_ATOM_INT(_a_1482)) {
        _611 = (_a_1482 <= _10pretty_ascii_max_1418);
    }
    else {
        _611 = binary_op(LESSEQ, _a_1482, _10pretty_ascii_max_1418);
    }
    DeRef(_610);
    if (IS_ATOM_INT(_611))
    _610 = (_611 != 0);
    else
    _610 = DBL_PTR(_611)->dbl != 0.0;
L7: 
    if (_610 == 0) {
        goto L3; // [125] 166
    }
    _613 = (_10pretty_ascii_1415 < 2);
    if (_613 == 0)
    {
        DeRef(_613);
        _613 = NOVALUE;
        goto L3; // [136] 166
    }
    else{
        DeRef(_613);
        _613 = NOVALUE;
    }

    /** pretty.e:108							sbuff &= '\'' & a & '\'' -- add to numeric display*/
    {
        object concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _a_1482;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_614, concat_list, 3);
    }
    Concat((object_ptr)&_sbuff_1483, _sbuff_1483, _614);
    DeRefDS(_614);
    _614 = NOVALUE;
    goto L3; // [154] 166
L2: 

    /** pretty.e:113				sbuff = sprintf(pretty_fp_format, a)*/
    DeRef(_sbuff_1483);
    _sbuff_1483 = EPrintf(-9999999, _10pretty_fp_format_1424, _a_1482);
L3: 

    /** pretty.e:115			pretty_out(sbuff)*/
    RefDS(_sbuff_1483);
    _10pretty_out(_sbuff_1483);
    goto L8; // [173] 535
L1: 

    /** pretty.e:119			cut_line(1)*/
    _10cut_line(1);

    /** pretty.e:120			multi_line = 0*/
    _multi_line_1484 = 0;

    /** pretty.e:121			all_ascii = pretty_ascii > 1*/
    _all_ascii_1485 = (_10pretty_ascii_1415 > 1);

    /** pretty.e:122			for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_1482)){
            _618 = SEQ_PTR(_a_1482)->length;
    }
    else {
        _618 = 1;
    }
    {
        object _i_1519;
        _i_1519 = 1;
L9: 
        if (_i_1519 > _618){
            goto LA; // [199] 345
        }

        /** pretty.e:123				if sequence(a[i]) and length(a[i]) > 0 then*/
        _2 = (object)SEQ_PTR(_a_1482);
        _619 = (object)*(((s1_ptr)_2)->base + _i_1519);
        _620 = IS_SEQUENCE(_619);
        _619 = NOVALUE;
        if (_620 == 0) {
            goto LB; // [215] 249
        }
        _2 = (object)SEQ_PTR(_a_1482);
        _622 = (object)*(((s1_ptr)_2)->base + _i_1519);
        if (IS_SEQUENCE(_622)){
                _623 = SEQ_PTR(_622)->length;
        }
        else {
            _623 = 1;
        }
        _622 = NOVALUE;
        _624 = (_623 > 0);
        _623 = NOVALUE;
        if (_624 == 0)
        {
            DeRef(_624);
            _624 = NOVALUE;
            goto LB; // [231] 249
        }
        else{
            DeRef(_624);
            _624 = NOVALUE;
        }

        /** pretty.e:124					multi_line = 1*/
        _multi_line_1484 = 1;

        /** pretty.e:125					all_ascii = 0*/
        _all_ascii_1485 = 0;

        /** pretty.e:126					exit*/
        goto LA; // [246] 345
LB: 

        /** pretty.e:128				if not integer(a[i]) or*/
        _2 = (object)SEQ_PTR(_a_1482);
        _625 = (object)*(((s1_ptr)_2)->base + _i_1519);
        if (IS_ATOM_INT(_625))
        _626 = 1;
        else if (IS_ATOM_DBL(_625))
        _626 = IS_ATOM_INT(DoubleToInt(_625));
        else
        _626 = 0;
        _625 = NOVALUE;
        _627 = (_626 == 0);
        _626 = NOVALUE;
        if (_627 != 0) {
            _628 = 1;
            goto LC; // [261] 313
        }
        _2 = (object)SEQ_PTR(_a_1482);
        _629 = (object)*(((s1_ptr)_2)->base + _i_1519);
        if (IS_ATOM_INT(_629)) {
            _630 = (_629 < _10pretty_ascii_min_1417);
        }
        else {
            _630 = binary_op(LESS, _629, _10pretty_ascii_min_1417);
        }
        _629 = NOVALUE;
        if (IS_ATOM_INT(_630)) {
            if (_630 == 0) {
                DeRef(_631);
                _631 = 0;
                goto LD; // [275] 309
            }
        }
        else {
            if (DBL_PTR(_630)->dbl == 0.0) {
                DeRef(_631);
                _631 = 0;
                goto LD; // [275] 309
            }
        }
        _632 = (_10pretty_ascii_1415 < 2);
        if (_632 != 0) {
            _633 = 1;
            goto LE; // [285] 305
        }
        _2 = (object)SEQ_PTR(_a_1482);
        _634 = (object)*(((s1_ptr)_2)->base + _i_1519);
        _636 = find_from(_634, _635, 1);
        _634 = NOVALUE;
        _637 = (_636 == 0);
        _636 = NOVALUE;
        _633 = (_637 != 0);
LE: 
        DeRef(_631);
        _631 = (_633 != 0);
LD: 
        _628 = (_631 != 0);
LC: 
        if (_628 != 0) {
            goto LF; // [313] 332
        }
        _2 = (object)SEQ_PTR(_a_1482);
        _639 = (object)*(((s1_ptr)_2)->base + _i_1519);
        if (IS_ATOM_INT(_639)) {
            _640 = (_639 > _10pretty_ascii_max_1418);
        }
        else {
            _640 = binary_op(GREATER, _639, _10pretty_ascii_max_1418);
        }
        _639 = NOVALUE;
        if (_640 == 0) {
            DeRef(_640);
            _640 = NOVALUE;
            goto L10; // [328] 338
        }
        else {
            if (!IS_ATOM_INT(_640) && DBL_PTR(_640)->dbl == 0.0){
                DeRef(_640);
                _640 = NOVALUE;
                goto L10; // [328] 338
            }
            DeRef(_640);
            _640 = NOVALUE;
        }
        DeRef(_640);
        _640 = NOVALUE;
LF: 

        /** pretty.e:132					all_ascii = 0*/
        _all_ascii_1485 = 0;
L10: 

        /** pretty.e:134			end for*/
        _i_1519 = _i_1519 + 1;
        goto L9; // [340] 206
LA: 
        ;
    }

    /** pretty.e:136			if all_ascii then*/
    if (_all_ascii_1485 == 0)
    {
        goto L11; // [347] 358
    }
    else{
    }

    /** pretty.e:137				pretty_out('\"')*/
    _10pretty_out(34);
    goto L12; // [355] 364
L11: 

    /** pretty.e:139				pretty_out('{')*/
    _10pretty_out(123);
L12: 

    /** pretty.e:141			pretty_level += 1*/
    _10pretty_level_1413 = _10pretty_level_1413 + 1;

    /** pretty.e:142			for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_1482)){
            _642 = SEQ_PTR(_a_1482)->length;
    }
    else {
        _642 = 1;
    }
    {
        object _i_1549;
        _i_1549 = 1;
L13: 
        if (_i_1549 > _642){
            goto L14; // [377] 497
        }

        /** pretty.e:143				if multi_line then*/
        if (_multi_line_1484 == 0)
        {
            goto L15; // [386] 394
        }
        else{
        }

        /** pretty.e:144					indent()*/
        _10indent();
L15: 

        /** pretty.e:146				if all_ascii then*/
        if (_all_ascii_1485 == 0)
        {
            goto L16; // [396] 415
        }
        else{
        }

        /** pretty.e:147					pretty_out(esc_char(a[i]))*/
        _2 = (object)SEQ_PTR(_a_1482);
        _643 = (object)*(((s1_ptr)_2)->base + _i_1549);
        Ref(_643);
        _644 = _10esc_char(_643);
        _643 = NOVALUE;
        _10pretty_out(_644);
        _644 = NOVALUE;
        goto L17; // [412] 425
L16: 

        /** pretty.e:149					rPrint(a[i])*/
        _2 = (object)SEQ_PTR(_a_1482);
        _645 = (object)*(((s1_ptr)_2)->base + _i_1549);
        Ref(_645);
        _10rPrint(_645);
        _645 = NOVALUE;
L17: 

        /** pretty.e:151				if pretty_line_count >= pretty_line_max then*/
        if (_10pretty_line_count_1419 < _10pretty_line_max_1420)
        goto L18; // [431] 459

        /** pretty.e:152					if not pretty_dots then*/
        if (_10pretty_dots_1421 != 0)
        goto L19; // [439] 448

        /** pretty.e:153						pretty_out(" ...")*/
        RefDS(_648);
        _10pretty_out(_648);
L19: 

        /** pretty.e:155					pretty_dots = 1*/
        _10pretty_dots_1421 = 1;

        /** pretty.e:156					return*/
        DeRef(_a_1482);
        DeRef(_sbuff_1483);
        DeRef(_609);
        _609 = NOVALUE;
        DeRef(_627);
        _627 = NOVALUE;
        DeRef(_600);
        _600 = NOVALUE;
        DeRef(_632);
        _632 = NOVALUE;
        DeRef(_630);
        _630 = NOVALUE;
        DeRef(_602);
        _602 = NOVALUE;
        DeRef(_637);
        _637 = NOVALUE;
        _622 = NOVALUE;
        DeRef(_611);
        _611 = NOVALUE;
        return;
L18: 

        /** pretty.e:158				if i != length(a) and not all_ascii then*/
        if (IS_SEQUENCE(_a_1482)){
                _649 = SEQ_PTR(_a_1482)->length;
        }
        else {
            _649 = 1;
        }
        _650 = (_i_1549 != _649);
        _649 = NOVALUE;
        if (_650 == 0) {
            goto L1A; // [468] 490
        }
        _652 = (_all_ascii_1485 == 0);
        if (_652 == 0)
        {
            DeRef(_652);
            _652 = NOVALUE;
            goto L1A; // [476] 490
        }
        else{
            DeRef(_652);
            _652 = NOVALUE;
        }

        /** pretty.e:159					pretty_out(',')*/
        _10pretty_out(44);

        /** pretty.e:160					cut_line(6)*/
        _10cut_line(6);
L1A: 

        /** pretty.e:162			end for*/
        _i_1549 = _i_1549 + 1;
        goto L13; // [492] 384
L14: 
        ;
    }

    /** pretty.e:163			pretty_level -= 1*/
    _10pretty_level_1413 = _10pretty_level_1413 - 1;

    /** pretty.e:164			if multi_line then*/
    if (_multi_line_1484 == 0)
    {
        goto L1B; // [507] 515
    }
    else{
    }

    /** pretty.e:165				indent()*/
    _10indent();
L1B: 

    /** pretty.e:167			if all_ascii then*/
    if (_all_ascii_1485 == 0)
    {
        goto L1C; // [517] 528
    }
    else{
    }

    /** pretty.e:168				pretty_out('\"')*/
    _10pretty_out(34);
    goto L1D; // [525] 534
L1C: 

    /** pretty.e:170				pretty_out('}')*/
    _10pretty_out(125);
L1D: 
L8: 

    /** pretty.e:173	end procedure*/
    DeRef(_a_1482);
    DeRef(_sbuff_1483);
    DeRef(_650);
    _650 = NOVALUE;
    DeRef(_609);
    _609 = NOVALUE;
    DeRef(_627);
    _627 = NOVALUE;
    DeRef(_600);
    _600 = NOVALUE;
    DeRef(_632);
    _632 = NOVALUE;
    DeRef(_630);
    _630 = NOVALUE;
    DeRef(_602);
    _602 = NOVALUE;
    DeRef(_637);
    _637 = NOVALUE;
    _622 = NOVALUE;
    DeRef(_611);
    _611 = NOVALUE;
    return;
    ;
}


void _10pretty(object _x_1591, object _options_1592)
{
    object _667 = NOVALUE;
    object _666 = NOVALUE;
    object _665 = NOVALUE;
    object _664 = NOVALUE;
    object _662 = NOVALUE;
    object _661 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:197		if length(options) < length( PRETTY_DEFAULT ) then*/
    if (IS_SEQUENCE(_options_1592)){
            _661 = SEQ_PTR(_options_1592)->length;
    }
    else {
        _661 = 1;
    }
    _662 = 10;
    if (_661 >= 10)
    goto L1; // [13] 41

    /** pretty.e:198			options &= PRETTY_DEFAULT[length(options)+1..$]*/
    if (IS_SEQUENCE(_options_1592)){
            _664 = SEQ_PTR(_options_1592)->length;
    }
    else {
        _664 = 1;
    }
    _665 = _664 + 1;
    _664 = NOVALUE;
    _666 = 10;
    rhs_slice_target = (object_ptr)&_667;
    RHS_Slice(_10PRETTY_DEFAULT_1573, _665, 10);
    Concat((object_ptr)&_options_1592, _options_1592, _667);
    DeRefDS(_667);
    _667 = NOVALUE;
L1: 

    /** pretty.e:202		pretty_ascii = options[DISPLAY_ASCII] */
    _2 = (object)SEQ_PTR(_options_1592);
    _10pretty_ascii_1415 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_10pretty_ascii_1415))
    _10pretty_ascii_1415 = (object)DBL_PTR(_10pretty_ascii_1415)->dbl;

    /** pretty.e:203		pretty_indent = options[INDENT]*/
    _2 = (object)SEQ_PTR(_options_1592);
    _10pretty_indent_1416 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_10pretty_indent_1416))
    _10pretty_indent_1416 = (object)DBL_PTR(_10pretty_indent_1416)->dbl;

    /** pretty.e:204		pretty_start_col = options[START_COLUMN]*/
    _2 = (object)SEQ_PTR(_options_1592);
    _10pretty_start_col_1412 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_10pretty_start_col_1412))
    _10pretty_start_col_1412 = (object)DBL_PTR(_10pretty_start_col_1412)->dbl;

    /** pretty.e:205		pretty_end_col = options[WRAP]*/
    _2 = (object)SEQ_PTR(_options_1592);
    _10pretty_end_col_1410 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_10pretty_end_col_1410))
    _10pretty_end_col_1410 = (object)DBL_PTR(_10pretty_end_col_1410)->dbl;

    /** pretty.e:206		pretty_int_format = options[INT_FORMAT]*/
    DeRef(_10pretty_int_format_1425);
    _2 = (object)SEQ_PTR(_options_1592);
    _10pretty_int_format_1425 = (object)*(((s1_ptr)_2)->base + 5);
    Ref(_10pretty_int_format_1425);

    /** pretty.e:207		pretty_fp_format = options[FP_FORMAT]*/
    DeRef(_10pretty_fp_format_1424);
    _2 = (object)SEQ_PTR(_options_1592);
    _10pretty_fp_format_1424 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_10pretty_fp_format_1424);

    /** pretty.e:208		pretty_ascii_min = options[MIN_ASCII]*/
    _2 = (object)SEQ_PTR(_options_1592);
    _10pretty_ascii_min_1417 = (object)*(((s1_ptr)_2)->base + 7);
    if (!IS_ATOM_INT(_10pretty_ascii_min_1417))
    _10pretty_ascii_min_1417 = (object)DBL_PTR(_10pretty_ascii_min_1417)->dbl;

    /** pretty.e:209		pretty_ascii_max = options[MAX_ASCII]*/
    _2 = (object)SEQ_PTR(_options_1592);
    _10pretty_ascii_max_1418 = (object)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_10pretty_ascii_max_1418))
    _10pretty_ascii_max_1418 = (object)DBL_PTR(_10pretty_ascii_max_1418)->dbl;

    /** pretty.e:210		pretty_line_max = options[MAX_LINES]*/
    _2 = (object)SEQ_PTR(_options_1592);
    _10pretty_line_max_1420 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_10pretty_line_max_1420))
    _10pretty_line_max_1420 = (object)DBL_PTR(_10pretty_line_max_1420)->dbl;

    /** pretty.e:211		pretty_line_breaks = options[LINE_BREAKS]*/
    _2 = (object)SEQ_PTR(_options_1592);
    _10pretty_line_breaks_1422 = (object)*(((s1_ptr)_2)->base + 10);
    if (!IS_ATOM_INT(_10pretty_line_breaks_1422))
    _10pretty_line_breaks_1422 = (object)DBL_PTR(_10pretty_line_breaks_1422)->dbl;

    /** pretty.e:213		pretty_chars = pretty_start_col*/
    _10pretty_chars_1411 = _10pretty_start_col_1412;

    /** pretty.e:215		pretty_level = 0 */
    _10pretty_level_1413 = 0;

    /** pretty.e:216		pretty_line = ""*/
    RefDS(_5);
    DeRef(_10pretty_line_1426);
    _10pretty_line_1426 = _5;

    /** pretty.e:217		pretty_line_count = 0*/
    _10pretty_line_count_1419 = 0;

    /** pretty.e:218		pretty_dots = 0*/
    _10pretty_dots_1421 = 0;

    /** pretty.e:219		rPrint(x)*/
    Ref(_x_1591);
    _10rPrint(_x_1591);

    /** pretty.e:220	end procedure*/
    DeRef(_x_1591);
    DeRefDS(_options_1592);
    DeRef(_665);
    _665 = NOVALUE;
    return;
    ;
}


void _10pretty_print(object _fn_1614, object _x_1615, object _options_1616)
{
    object _0, _1, _2;
    

    /** pretty.e:339		pretty_printing = 1*/
    _10pretty_printing_1423 = 1;

    /** pretty.e:340		pretty_file = fn*/
    _10pretty_file_1414 = _fn_1614;

    /** pretty.e:341		pretty( x, options )*/
    Ref(_x_1615);
    RefDS(_options_1616);
    _10pretty(_x_1615, _options_1616);

    /** pretty.e:342		puts(pretty_file, pretty_line)*/
    EPuts(_10pretty_file_1414, _10pretty_line_1426); // DJP 

    /** pretty.e:343	end procedure*/
    DeRef(_x_1615);
    DeRefDS(_options_1616);
    return;
    ;
}



// 0x0E72A20E
