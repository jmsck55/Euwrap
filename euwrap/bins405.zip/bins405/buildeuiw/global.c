// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _26print_sym(int _s_11748)
{
    int _s_obj_11751 = NOVALUE;
    int _6464 = NOVALUE;
    int _6463 = NOVALUE;
    int _6459 = NOVALUE;
    int _6457 = NOVALUE;
    int _6456 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_11748)) {
        _1 = (long)(DBL_PTR(_s_11748)->dbl);
        DeRefDS(_s_11748);
        _s_11748 = _1;
    }

    /** 	printf(1,"[%d]:\n", {s} )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _s_11748;
    _6456 = MAKE_SEQ(_1);
    EPrintf(1, _6455, _6456);
    DeRefDS(_6456);
    _6456 = NOVALUE;

    /** 	object s_obj = SymTab[s][S_OBJ]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _6457 = (int)*(((s1_ptr)_2)->base + _s_11748);
    DeRef(_s_obj_11751);
    _2 = (int)SEQ_PTR(_6457);
    _s_obj_11751 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_s_obj_11751);
    _6457 = NOVALUE;

    /** 	if equal(s_obj,NOVALUE) then */
    if (_s_obj_11751 == _26NOVALUE_11836)
    _6459 = 1;
    else if (IS_ATOM_INT(_s_obj_11751) && IS_ATOM_INT(_26NOVALUE_11836))
    _6459 = 0;
    else
    _6459 = (compare(_s_obj_11751, _26NOVALUE_11836) == 0);
    if (_6459 == 0)
    {
        _6459 = NOVALUE;
        goto L1; // [33] 44
    }
    else{
        _6459 = NOVALUE;
    }

    /** 		puts(1,"S_OBJ=>NOVALUE\n")*/
    EPuts(1, _6460); // DJP 
    goto L2; // [41] 55
L1: 

    /** 		puts(1,"S_OBJ=>")*/
    EPuts(1, _6461); // DJP 

    /** 		? s_obj		*/
    StdPrint(1, _s_obj_11751, 1);
L2: 

    /** 	puts(1,"S_MODE=>")*/
    EPuts(1, _6462); // DJP 

    /** 	switch SymTab[s][S_MODE] do*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _6463 = (int)*(((s1_ptr)_2)->base + _s_11748);
    _2 = (int)SEQ_PTR(_6463);
    _6464 = (int)*(((s1_ptr)_2)->base + 3);
    _6463 = NOVALUE;
    if (IS_SEQUENCE(_6464) ){
        goto L3; // [72] 120
    }
    if(!IS_ATOM_INT(_6464)){
        if( (DBL_PTR(_6464)->dbl != (double) ((int) DBL_PTR(_6464)->dbl) ) ){
            goto L3; // [72] 120
        }
        _0 = (int) DBL_PTR(_6464)->dbl;
    }
    else {
        _0 = _6464;
    };
    _6464 = NOVALUE;
    switch ( _0 ){ 

        /** 		case M_NORMAL then*/
        case 1:

        /** 			puts(1,"M_NORMAL")*/
        EPuts(1, _6467); // DJP 
        goto L3; // [86] 120

        /** 		case M_TEMP then*/
        case 3:

        /** 			puts(1,"M_TEMP")*/
        EPuts(1, _6468); // DJP 
        goto L3; // [97] 120

        /** 		case M_CONSTANT then*/
        case 2:

        /** 			puts(1,"M_CONSTANT")*/
        EPuts(1, _6469); // DJP 
        goto L3; // [108] 120

        /** 		case M_BLOCK then*/
        case 4:

        /** 			puts(1,"M_BLOCK")*/
        EPuts(1, _6470); // DJP 
    ;}L3: 

    /** 	puts(1,{10,10})*/
    EPuts(1, _152); // DJP 

    /** end procedure*/
    DeRef(_s_obj_11751);
    return;
    ;
}


int _26symtab_entry(int _x_11841)
{
    int _6490 = NOVALUE;
    int _6489 = NOVALUE;
    int _6488 = NOVALUE;
    int _6487 = NOVALUE;
    int _6486 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return length(x) = SIZEOF_ROUTINE_ENTRY or*/
    if (IS_SEQUENCE(_x_11841)){
            _6486 = SEQ_PTR(_x_11841)->length;
    }
    else {
        _6486 = 1;
    }
    _6487 = (_6486 == _26SIZEOF_ROUTINE_ENTRY_11779);
    _6486 = NOVALUE;
    if (IS_SEQUENCE(_x_11841)){
            _6488 = SEQ_PTR(_x_11841)->length;
    }
    else {
        _6488 = 1;
    }
    _6489 = (_6488 == _26SIZEOF_VAR_ENTRY_11782);
    _6488 = NOVALUE;
    _6490 = (_6487 != 0 || _6489 != 0);
    _6487 = NOVALUE;
    _6489 = NOVALUE;
    DeRefDS(_x_11841);
    return _6490;
    ;
}


int _26symtab_index(int _x_11849)
{
    int _6499 = NOVALUE;
    int _6498 = NOVALUE;
    int _6497 = NOVALUE;
    int _6496 = NOVALUE;
    int _6495 = NOVALUE;
    int _6494 = NOVALUE;
    int _6492 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_11849)) {
        _1 = (long)(DBL_PTR(_x_11849)->dbl);
        DeRefDS(_x_11849);
        _x_11849 = _1;
    }

    /** 	if x = 0 then*/
    if (_x_11849 != 0)
    goto L1; // [5] 18

    /** 		return TRUE -- NULL value*/
    return _9TRUE_430;
L1: 

    /** 	if x < 0 or x > length(SymTab) then*/
    _6492 = (_x_11849 < 0);
    if (_6492 != 0) {
        goto L2; // [24] 42
    }
    if (IS_SEQUENCE(_27SymTab_10921)){
            _6494 = SEQ_PTR(_27SymTab_10921)->length;
    }
    else {
        _6494 = 1;
    }
    _6495 = (_x_11849 > _6494);
    _6494 = NOVALUE;
    if (_6495 == 0)
    {
        DeRef(_6495);
        _6495 = NOVALUE;
        goto L3; // [38] 51
    }
    else{
        DeRef(_6495);
        _6495 = NOVALUE;
    }
L2: 

    /** 		return FALSE*/
    DeRef(_6492);
    _6492 = NOVALUE;
    return _9FALSE_428;
L3: 

    /** 	return find(length(SymTab[x]), {SIZEOF_VAR_ENTRY, SIZEOF_ROUTINE_ENTRY,*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _6496 = (int)*(((s1_ptr)_2)->base + _x_11849);
    if (IS_SEQUENCE(_6496)){
            _6497 = SEQ_PTR(_6496)->length;
    }
    else {
        _6497 = 1;
    }
    _6496 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _26SIZEOF_VAR_ENTRY_11782;
    *((int *)(_2+8)) = _26SIZEOF_ROUTINE_ENTRY_11779;
    *((int *)(_2+12)) = _26SIZEOF_TEMP_ENTRY_11788;
    *((int *)(_2+16)) = _26SIZEOF_BLOCK_ENTRY_11785;
    _6498 = MAKE_SEQ(_1);
    _6499 = find_from(_6497, _6498, 1);
    _6497 = NOVALUE;
    DeRefDS(_6498);
    _6498 = NOVALUE;
    DeRef(_6492);
    _6492 = NOVALUE;
    _6496 = NOVALUE;
    return _6499;
    ;
}


int _26temp_index(int _x_11867)
{
    int _6503 = NOVALUE;
    int _6502 = NOVALUE;
    int _6501 = NOVALUE;
    int _6500 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_11867)) {
        _1 = (long)(DBL_PTR(_x_11867)->dbl);
        DeRefDS(_x_11867);
        _x_11867 = _1;
    }

    /** 	return x >= 0 and x <= length(SymTab)*/
    _6500 = (_x_11867 >= 0);
    if (IS_SEQUENCE(_27SymTab_10921)){
            _6501 = SEQ_PTR(_27SymTab_10921)->length;
    }
    else {
        _6501 = 1;
    }
    _6502 = (_x_11867 <= _6501);
    _6501 = NOVALUE;
    _6503 = (_6500 != 0 && _6502 != 0);
    _6500 = NOVALUE;
    _6502 = NOVALUE;
    return _6503;
    ;
}


int _26token(int _t_11877)
{
    int _6547 = NOVALUE;
    int _6546 = NOVALUE;
    int _6545 = NOVALUE;
    int _6544 = NOVALUE;
    int _6543 = NOVALUE;
    int _6542 = NOVALUE;
    int _6541 = NOVALUE;
    int _6540 = NOVALUE;
    int _6539 = NOVALUE;
    int _6538 = NOVALUE;
    int _6536 = NOVALUE;
    int _6535 = NOVALUE;
    int _6534 = NOVALUE;
    int _6533 = NOVALUE;
    int _6532 = NOVALUE;
    int _6531 = NOVALUE;
    int _6530 = NOVALUE;
    int _6529 = NOVALUE;
    int _6528 = NOVALUE;
    int _6527 = NOVALUE;
    int _6526 = NOVALUE;
    int _6525 = NOVALUE;
    int _6524 = NOVALUE;
    int _6523 = NOVALUE;
    int _6522 = NOVALUE;
    int _6521 = NOVALUE;
    int _6520 = NOVALUE;
    int _6519 = NOVALUE;
    int _6518 = NOVALUE;
    int _6517 = NOVALUE;
    int _6516 = NOVALUE;
    int _6515 = NOVALUE;
    int _6514 = NOVALUE;
    int _6513 = NOVALUE;
    int _6512 = NOVALUE;
    int _6511 = NOVALUE;
    int _6510 = NOVALUE;
    int _6508 = NOVALUE;
    int _6507 = NOVALUE;
    int _6505 = NOVALUE;
    int _6504 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(t) then*/
    _6504 = IS_ATOM(_t_11877);
    if (_6504 == 0)
    {
        _6504 = NOVALUE;
        goto L1; // [6] 18
    }
    else{
        _6504 = NOVALUE;
    }

    /** 		return FALSE*/
    DeRef(_t_11877);
    return _9FALSE_428;
L1: 

    /** 	if length(t) != 2 then*/
    if (IS_SEQUENCE(_t_11877)){
            _6505 = SEQ_PTR(_t_11877)->length;
    }
    else {
        _6505 = 1;
    }
    if (_6505 == 2)
    goto L2; // [23] 36

    /** 		return FALSE*/
    DeRef(_t_11877);
    return _9FALSE_428;
L2: 

    /** 	if not integer(t[T_ID]) then*/
    _2 = (int)SEQ_PTR(_t_11877);
    _6507 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6507))
    _6508 = 1;
    else if (IS_ATOM_DBL(_6507))
    _6508 = IS_ATOM_INT(DoubleToInt(_6507));
    else
    _6508 = 0;
    _6507 = NOVALUE;
    if (_6508 != 0)
    goto L3; // [45] 57
    _6508 = NOVALUE;

    /** 		return FALSE*/
    DeRef(_t_11877);
    return _9FALSE_428;
L3: 

    /** 	if t[T_ID] = VARIABLE and (t[T_SYM] < 0 or symtab_index(t[T_SYM])) then*/
    _2 = (int)SEQ_PTR(_t_11877);
    _6510 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6510)) {
        _6511 = (_6510 == -100);
    }
    else {
        _6511 = binary_op(EQUALS, _6510, -100);
    }
    _6510 = NOVALUE;
    if (IS_ATOM_INT(_6511)) {
        if (_6511 == 0) {
            goto L4; // [69] 110
        }
    }
    else {
        if (DBL_PTR(_6511)->dbl == 0.0) {
            goto L4; // [69] 110
        }
    }
    _2 = (int)SEQ_PTR(_t_11877);
    _6513 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_6513)) {
        _6514 = (_6513 < 0);
    }
    else {
        _6514 = binary_op(LESS, _6513, 0);
    }
    _6513 = NOVALUE;
    if (IS_ATOM_INT(_6514)) {
        if (_6514 != 0) {
            DeRef(_6515);
            _6515 = 1;
            goto L5; // [81] 97
        }
    }
    else {
        if (DBL_PTR(_6514)->dbl != 0.0) {
            DeRef(_6515);
            _6515 = 1;
            goto L5; // [81] 97
        }
    }
    _2 = (int)SEQ_PTR(_t_11877);
    _6516 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_6516);
    _6517 = _26symtab_index(_6516);
    _6516 = NOVALUE;
    DeRef(_6515);
    if (IS_ATOM_INT(_6517))
    _6515 = (_6517 != 0);
    else
    _6515 = DBL_PTR(_6517)->dbl != 0.0;
L5: 
    if (_6515 == 0)
    {
        _6515 = NOVALUE;
        goto L4; // [98] 110
    }
    else{
        _6515 = NOVALUE;
    }

    /** 		return TRUE*/
    DeRef(_t_11877);
    DeRef(_6511);
    _6511 = NOVALUE;
    DeRef(_6514);
    _6514 = NOVALUE;
    DeRef(_6517);
    _6517 = NOVALUE;
    return _9TRUE_430;
L4: 

    /** 	if QUESTION_MARK <= t[T_ID] and t[T_ID] <= -1 then*/
    _2 = (int)SEQ_PTR(_t_11877);
    _6518 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6518)) {
        _6519 = (-31 <= _6518);
    }
    else {
        _6519 = binary_op(LESSEQ, -31, _6518);
    }
    _6518 = NOVALUE;
    if (IS_ATOM_INT(_6519)) {
        if (_6519 == 0) {
            goto L6; // [122] 147
        }
    }
    else {
        if (DBL_PTR(_6519)->dbl == 0.0) {
            goto L6; // [122] 147
        }
    }
    _2 = (int)SEQ_PTR(_t_11877);
    _6521 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6521)) {
        _6522 = (_6521 <= -1);
    }
    else {
        _6522 = binary_op(LESSEQ, _6521, -1);
    }
    _6521 = NOVALUE;
    if (_6522 == 0) {
        DeRef(_6522);
        _6522 = NOVALUE;
        goto L6; // [135] 147
    }
    else {
        if (!IS_ATOM_INT(_6522) && DBL_PTR(_6522)->dbl == 0.0){
            DeRef(_6522);
            _6522 = NOVALUE;
            goto L6; // [135] 147
        }
        DeRef(_6522);
        _6522 = NOVALUE;
    }
    DeRef(_6522);
    _6522 = NOVALUE;

    /** 		return TRUE*/
    DeRef(_t_11877);
    DeRef(_6511);
    _6511 = NOVALUE;
    DeRef(_6514);
    _6514 = NOVALUE;
    DeRef(_6517);
    _6517 = NOVALUE;
    DeRef(_6519);
    _6519 = NOVALUE;
    return _9TRUE_430;
L6: 

    /** 	if t[T_ID] >= 1 and t[T_ID] <= MAX_OPCODE then*/
    _2 = (int)SEQ_PTR(_t_11877);
    _6523 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6523)) {
        _6524 = (_6523 >= 1);
    }
    else {
        _6524 = binary_op(GREATEREQ, _6523, 1);
    }
    _6523 = NOVALUE;
    if (IS_ATOM_INT(_6524)) {
        if (_6524 == 0) {
            goto L7; // [157] 184
        }
    }
    else {
        if (DBL_PTR(_6524)->dbl == 0.0) {
            goto L7; // [157] 184
        }
    }
    _2 = (int)SEQ_PTR(_t_11877);
    _6526 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6526)) {
        _6527 = (_6526 <= 213);
    }
    else {
        _6527 = binary_op(LESSEQ, _6526, 213);
    }
    _6526 = NOVALUE;
    if (_6527 == 0) {
        DeRef(_6527);
        _6527 = NOVALUE;
        goto L7; // [172] 184
    }
    else {
        if (!IS_ATOM_INT(_6527) && DBL_PTR(_6527)->dbl == 0.0){
            DeRef(_6527);
            _6527 = NOVALUE;
            goto L7; // [172] 184
        }
        DeRef(_6527);
        _6527 = NOVALUE;
    }
    DeRef(_6527);
    _6527 = NOVALUE;

    /** 		return TRUE*/
    DeRef(_t_11877);
    DeRef(_6511);
    _6511 = NOVALUE;
    DeRef(_6514);
    _6514 = NOVALUE;
    DeRef(_6517);
    _6517 = NOVALUE;
    DeRef(_6519);
    _6519 = NOVALUE;
    DeRef(_6524);
    _6524 = NOVALUE;
    return _9TRUE_430;
L7: 

    /** 	if END <= t[T_ID] and t[T_ID] <=  ROUTINE then*/
    _2 = (int)SEQ_PTR(_t_11877);
    _6528 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6528)) {
        _6529 = (402 <= _6528);
    }
    else {
        _6529 = binary_op(LESSEQ, 402, _6528);
    }
    _6528 = NOVALUE;
    if (IS_ATOM_INT(_6529)) {
        if (_6529 == 0) {
            goto L8; // [196] 280
        }
    }
    else {
        if (DBL_PTR(_6529)->dbl == 0.0) {
            goto L8; // [196] 280
        }
    }
    _2 = (int)SEQ_PTR(_t_11877);
    _6531 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6531)) {
        _6532 = (_6531 <= 432);
    }
    else {
        _6532 = binary_op(LESSEQ, _6531, 432);
    }
    _6531 = NOVALUE;
    if (_6532 == 0) {
        DeRef(_6532);
        _6532 = NOVALUE;
        goto L8; // [211] 280
    }
    else {
        if (!IS_ATOM_INT(_6532) && DBL_PTR(_6532)->dbl == 0.0){
            DeRef(_6532);
            _6532 = NOVALUE;
            goto L8; // [211] 280
        }
        DeRef(_6532);
        _6532 = NOVALUE;
    }
    DeRef(_6532);
    _6532 = NOVALUE;

    /** 		if t[T_ID] != IGNORED and t[T_ID] < 500 and symtab_index(t[T_SYM]) = 0 then*/
    _2 = (int)SEQ_PTR(_t_11877);
    _6533 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6533)) {
        _6534 = (_6533 != 509);
    }
    else {
        _6534 = binary_op(NOTEQ, _6533, 509);
    }
    _6533 = NOVALUE;
    if (IS_ATOM_INT(_6534)) {
        if (_6534 == 0) {
            DeRef(_6535);
            _6535 = 0;
            goto L9; // [226] 242
        }
    }
    else {
        if (DBL_PTR(_6534)->dbl == 0.0) {
            DeRef(_6535);
            _6535 = 0;
            goto L9; // [226] 242
        }
    }
    _2 = (int)SEQ_PTR(_t_11877);
    _6536 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6536)) {
        _6538 = (_6536 < 500);
    }
    else {
        _6538 = binary_op(LESS, _6536, 500);
    }
    _6536 = NOVALUE;
    DeRef(_6535);
    if (IS_ATOM_INT(_6538))
    _6535 = (_6538 != 0);
    else
    _6535 = DBL_PTR(_6538)->dbl != 0.0;
L9: 
    if (_6535 == 0) {
        goto LA; // [242] 271
    }
    _2 = (int)SEQ_PTR(_t_11877);
    _6540 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_6540);
    _6541 = _26symtab_index(_6540);
    _6540 = NOVALUE;
    if (IS_ATOM_INT(_6541)) {
        _6542 = (_6541 == 0);
    }
    else {
        _6542 = binary_op(EQUALS, _6541, 0);
    }
    DeRef(_6541);
    _6541 = NOVALUE;
    if (_6542 == 0) {
        DeRef(_6542);
        _6542 = NOVALUE;
        goto LA; // [259] 271
    }
    else {
        if (!IS_ATOM_INT(_6542) && DBL_PTR(_6542)->dbl == 0.0){
            DeRef(_6542);
            _6542 = NOVALUE;
            goto LA; // [259] 271
        }
        DeRef(_6542);
        _6542 = NOVALUE;
    }
    DeRef(_6542);
    _6542 = NOVALUE;

    /** 			return FALSE*/
    DeRef(_t_11877);
    DeRef(_6511);
    _6511 = NOVALUE;
    DeRef(_6514);
    _6514 = NOVALUE;
    DeRef(_6517);
    _6517 = NOVALUE;
    DeRef(_6519);
    _6519 = NOVALUE;
    DeRef(_6524);
    _6524 = NOVALUE;
    DeRef(_6529);
    _6529 = NOVALUE;
    DeRef(_6534);
    _6534 = NOVALUE;
    DeRef(_6538);
    _6538 = NOVALUE;
    return _9FALSE_428;
LA: 

    /** 		return TRUE*/
    DeRef(_t_11877);
    DeRef(_6511);
    _6511 = NOVALUE;
    DeRef(_6514);
    _6514 = NOVALUE;
    DeRef(_6517);
    _6517 = NOVALUE;
    DeRef(_6519);
    _6519 = NOVALUE;
    DeRef(_6524);
    _6524 = NOVALUE;
    DeRef(_6529);
    _6529 = NOVALUE;
    DeRef(_6534);
    _6534 = NOVALUE;
    DeRef(_6538);
    _6538 = NOVALUE;
    return _9TRUE_430;
L8: 

    /** 	if FUNC <= t[T_ID] and t[T_ID] <= NAMESPACE then*/
    _2 = (int)SEQ_PTR(_t_11877);
    _6543 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6543)) {
        _6544 = (501 <= _6543);
    }
    else {
        _6544 = binary_op(LESSEQ, 501, _6543);
    }
    _6543 = NOVALUE;
    if (IS_ATOM_INT(_6544)) {
        if (_6544 == 0) {
            goto LB; // [292] 319
        }
    }
    else {
        if (DBL_PTR(_6544)->dbl == 0.0) {
            goto LB; // [292] 319
        }
    }
    _2 = (int)SEQ_PTR(_t_11877);
    _6546 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6546)) {
        _6547 = (_6546 <= 523);
    }
    else {
        _6547 = binary_op(LESSEQ, _6546, 523);
    }
    _6546 = NOVALUE;
    if (_6547 == 0) {
        DeRef(_6547);
        _6547 = NOVALUE;
        goto LB; // [307] 319
    }
    else {
        if (!IS_ATOM_INT(_6547) && DBL_PTR(_6547)->dbl == 0.0){
            DeRef(_6547);
            _6547 = NOVALUE;
            goto LB; // [307] 319
        }
        DeRef(_6547);
        _6547 = NOVALUE;
    }
    DeRef(_6547);
    _6547 = NOVALUE;

    /** 		return TRUE*/
    DeRef(_t_11877);
    DeRef(_6511);
    _6511 = NOVALUE;
    DeRef(_6514);
    _6514 = NOVALUE;
    DeRef(_6517);
    _6517 = NOVALUE;
    DeRef(_6519);
    _6519 = NOVALUE;
    DeRef(_6524);
    _6524 = NOVALUE;
    DeRef(_6529);
    _6529 = NOVALUE;
    DeRef(_6534);
    _6534 = NOVALUE;
    DeRef(_6538);
    _6538 = NOVALUE;
    DeRef(_6544);
    _6544 = NOVALUE;
    return _9TRUE_430;
LB: 

    /** 	return FALSE*/
    DeRef(_t_11877);
    DeRef(_6511);
    _6511 = NOVALUE;
    DeRef(_6514);
    _6514 = NOVALUE;
    DeRef(_6517);
    _6517 = NOVALUE;
    DeRef(_6519);
    _6519 = NOVALUE;
    DeRef(_6524);
    _6524 = NOVALUE;
    DeRef(_6529);
    _6529 = NOVALUE;
    DeRef(_6534);
    _6534 = NOVALUE;
    DeRef(_6538);
    _6538 = NOVALUE;
    DeRef(_6544);
    _6544 = NOVALUE;
    return _9FALSE_428;
    ;
}


int _26sequence_of_tokens(int _x_11951)
{
    int _t_11952 = NOVALUE;
    int _6549 = NOVALUE;
    int _6548 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(x) then*/
    _6548 = IS_ATOM(_x_11951);
    if (_6548 == 0)
    {
        _6548 = NOVALUE;
        goto L1; // [6] 18
    }
    else{
        _6548 = NOVALUE;
    }

    /** 		return FALSE*/
    DeRef(_x_11951);
    DeRef(_t_11952);
    return _9FALSE_428;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_11951)){
            _6549 = SEQ_PTR(_x_11951)->length;
    }
    else {
        _6549 = 1;
    }
    {
        int _i_11957;
        _i_11957 = 1;
L2: 
        if (_i_11957 > _6549){
            goto L3; // [23] 48
        }

        /** 		type_i = i*/
        _26type_i_11632 = _i_11957;

        /** 		t = x[i]*/
        DeRef(_t_11952);
        _2 = (int)SEQ_PTR(_x_11951);
        _t_11952 = (int)*(((s1_ptr)_2)->base + _i_11957);
        Ref(_t_11952);

        /** 	end for*/
        _i_11957 = _i_11957 + 1;
        goto L2; // [43] 30
L3: 
        ;
    }

    /** 	return TRUE*/
    DeRef(_x_11951);
    DeRef(_t_11952);
    return _9TRUE_430;
    ;
}


int _26sequence_of_opcodes(int _s_11963)
{
    int _oc_11964 = NOVALUE;
    int _6552 = NOVALUE;
    int _6551 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(s) then*/
    _6551 = IS_ATOM(_s_11963);
    if (_6551 == 0)
    {
        _6551 = NOVALUE;
        goto L1; // [6] 18
    }
    else{
        _6551 = NOVALUE;
    }

    /** 		return FALSE*/
    DeRef(_s_11963);
    return _9FALSE_428;
L1: 

    /** 	for i = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_11963)){
            _6552 = SEQ_PTR(_s_11963)->length;
    }
    else {
        _6552 = 1;
    }
    {
        int _i_11969;
        _i_11969 = 1;
L2: 
        if (_i_11969 > _6552){
            goto L3; // [23] 45
        }

        /** 		oc = s[i]*/
        _2 = (int)SEQ_PTR(_s_11963);
        _oc_11964 = (int)*(((s1_ptr)_2)->base + _i_11969);
        if (!IS_ATOM_INT(_oc_11964)){
            _oc_11964 = (long)DBL_PTR(_oc_11964)->dbl;
        }

        /** 	end for*/
        _i_11969 = _i_11969 + 1;
        goto L2; // [40] 30
L3: 
        ;
    }

    /** 	return TRUE*/
    DeRef(_s_11963);
    return _9TRUE_430;
    ;
}


int _26file(int _f_11975)
{
    int _6556 = NOVALUE;
    int _6555 = NOVALUE;
    int _6554 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_f_11975)) {
        _1 = (long)(DBL_PTR(_f_11975)->dbl);
        DeRefDS(_f_11975);
        _f_11975 = _1;
    }

    /** 	return f >= -1 and f < 100 -- rough limit*/
    _6554 = (_f_11975 >= -1);
    _6555 = (_f_11975 < 100);
    _6556 = (_6554 != 0 && _6555 != 0);
    _6554 = NOVALUE;
    _6555 = NOVALUE;
    return _6556;
    ;
}


int _26symtab_pointer(int _x_63228)
{
    int _31634 = NOVALUE;
    int _31633 = NOVALUE;
    int _31632 = NOVALUE;
    int _31631 = NOVALUE;
    int _31630 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_63228)) {
        _1 = (long)(DBL_PTR(_x_63228)->dbl);
        DeRefDS(_x_63228);
        _x_63228 = _1;
    }

    /** 	return x = -1 or symtab_index(x) or forward_reference(x)*/
    _31630 = (_x_63228 == -1);
    _31631 = _26symtab_index(_x_63228);
    if (IS_ATOM_INT(_31631)) {
        _31632 = (_31630 != 0 || _31631 != 0);
    }
    else {
        _31632 = binary_op(OR, _31630, _31631);
    }
    _31630 = NOVALUE;
    DeRef(_31631);
    _31631 = NOVALUE;
    _31633 = _29forward_reference(_x_63228);
    if (IS_ATOM_INT(_31632) && IS_ATOM_INT(_31633)) {
        _31634 = (_31632 != 0 || _31633 != 0);
    }
    else {
        _31634 = binary_op(OR, _31632, _31633);
    }
    DeRef(_31632);
    _31632 = NOVALUE;
    DeRef(_31633);
    _31633 = NOVALUE;
    return _31634;
    ;
}



// 0x0EE37FCC
