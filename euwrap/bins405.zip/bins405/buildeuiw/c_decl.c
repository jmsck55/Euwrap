// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _56get_eucompiledir()
{
    int _x_41733 = NOVALUE;
    int _22362 = NOVALUE;
    int _22358 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object x = getenv("EUCOMPILEDIR")*/
    DeRef(_x_41733);
    _x_41733 = EGetEnv(_22356);

    /** 	if is_eudir_from_cmdline() then*/
    _22358 = _27is_eudir_from_cmdline();
    if (_22358 == 0) {
        DeRef(_22358);
        _22358 = NOVALUE;
        goto L1; // [11] 20
    }
    else {
        if (!IS_ATOM_INT(_22358) && DBL_PTR(_22358)->dbl == 0.0){
            DeRef(_22358);
            _22358 = NOVALUE;
            goto L1; // [11] 20
        }
        DeRef(_22358);
        _22358 = NOVALUE;
    }
    DeRef(_22358);
    _22358 = NOVALUE;

    /** 		x = get_eudir()*/
    _0 = _x_41733;
    _x_41733 = _27get_eudir();
    DeRefi(_0);
L1: 

    /** 	ifdef UNIX then*/

    /** 	if equal(x, -1) then*/
    if (_x_41733 == -1)
    _22362 = 1;
    else if (IS_ATOM_INT(_x_41733) && IS_ATOM_INT(-1))
    _22362 = 0;
    else
    _22362 = (compare(_x_41733, -1) == 0);
    if (_22362 == 0)
    {
        _22362 = NOVALUE;
        goto L2; // [28] 37
    }
    else{
        _22362 = NOVALUE;
    }

    /** 		x = get_eudir()*/
    _0 = _x_41733;
    _x_41733 = _27get_eudir();
    DeRef(_0);
L2: 

    /** 	return x*/
    return _x_41733;
    ;
}


void _56NewBB(int _a_call_41749, int _mask_41750, int _sub_41752)
{
    int _s_41754 = NOVALUE;
    int _22395 = NOVALUE;
    int _22394 = NOVALUE;
    int _22392 = NOVALUE;
    int _22391 = NOVALUE;
    int _22389 = NOVALUE;
    int _22388 = NOVALUE;
    int _22387 = NOVALUE;
    int _22386 = NOVALUE;
    int _22385 = NOVALUE;
    int _22384 = NOVALUE;
    int _22383 = NOVALUE;
    int _22382 = NOVALUE;
    int _22381 = NOVALUE;
    int _22380 = NOVALUE;
    int _22379 = NOVALUE;
    int _22378 = NOVALUE;
    int _22377 = NOVALUE;
    int _22376 = NOVALUE;
    int _22375 = NOVALUE;
    int _22374 = NOVALUE;
    int _22373 = NOVALUE;
    int _22372 = NOVALUE;
    int _22371 = NOVALUE;
    int _22370 = NOVALUE;
    int _22369 = NOVALUE;
    int _22368 = NOVALUE;
    int _22367 = NOVALUE;
    int _22365 = NOVALUE;
    int _22364 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_a_call_41749)) {
        _1 = (long)(DBL_PTR(_a_call_41749)->dbl);
        DeRefDS(_a_call_41749);
        _a_call_41749 = _1;
    }
    if (!IS_ATOM_INT(_mask_41750)) {
        _1 = (long)(DBL_PTR(_mask_41750)->dbl);
        DeRefDS(_mask_41750);
        _mask_41750 = _1;
    }
    if (!IS_ATOM_INT(_sub_41752)) {
        _1 = (long)(DBL_PTR(_sub_41752)->dbl);
        DeRefDS(_sub_41752);
        _sub_41752 = _1;
    }

    /** 	if a_call then*/
    if (_a_call_41749 == 0)
    {
        goto L1; // [9] 252
    }
    else{
    }

    /** 		for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_56BB_info_41712)){
            _22364 = SEQ_PTR(_56BB_info_41712)->length;
    }
    else {
        _22364 = 1;
    }
    {
        int _i_41757;
        _i_41757 = 1;
L2: 
        if (_i_41757 > _22364){
            goto L3; // [19] 249
        }

        /** 			s = BB_info[i][BB_VAR]*/
        _2 = (int)SEQ_PTR(_56BB_info_41712);
        _22365 = (int)*(((s1_ptr)_2)->base + _i_41757);
        _2 = (int)SEQ_PTR(_22365);
        _s_41754 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_s_41754)){
            _s_41754 = (long)DBL_PTR(_s_41754)->dbl;
        }
        _22365 = NOVALUE;

        /** 			if SymTab[s][S_MODE] = M_NORMAL and*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _22367 = (int)*(((s1_ptr)_2)->base + _s_41754);
        _2 = (int)SEQ_PTR(_22367);
        _22368 = (int)*(((s1_ptr)_2)->base + 3);
        _22367 = NOVALUE;
        if (IS_ATOM_INT(_22368)) {
            _22369 = (_22368 == 1);
        }
        else {
            _22369 = binary_op(EQUALS, _22368, 1);
        }
        _22368 = NOVALUE;
        if (IS_ATOM_INT(_22369)) {
            if (_22369 == 0) {
                goto L4; // [60] 242
            }
        }
        else {
            if (DBL_PTR(_22369)->dbl == 0.0) {
                goto L4; // [60] 242
            }
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _22371 = (int)*(((s1_ptr)_2)->base + _s_41754);
        _2 = (int)SEQ_PTR(_22371);
        _22372 = (int)*(((s1_ptr)_2)->base + 4);
        _22371 = NOVALUE;
        if (IS_ATOM_INT(_22372)) {
            _22373 = (_22372 == 6);
        }
        else {
            _22373 = binary_op(EQUALS, _22372, 6);
        }
        _22372 = NOVALUE;
        if (IS_ATOM_INT(_22373)) {
            if (_22373 != 0) {
                DeRef(_22374);
                _22374 = 1;
                goto L5; // [82] 108
            }
        }
        else {
            if (DBL_PTR(_22373)->dbl != 0.0) {
                DeRef(_22374);
                _22374 = 1;
                goto L5; // [82] 108
            }
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _22375 = (int)*(((s1_ptr)_2)->base + _s_41754);
        _2 = (int)SEQ_PTR(_22375);
        _22376 = (int)*(((s1_ptr)_2)->base + 4);
        _22375 = NOVALUE;
        if (IS_ATOM_INT(_22376)) {
            _22377 = (_22376 == 5);
        }
        else {
            _22377 = binary_op(EQUALS, _22376, 5);
        }
        _22376 = NOVALUE;
        DeRef(_22374);
        if (IS_ATOM_INT(_22377))
        _22374 = (_22377 != 0);
        else
        _22374 = DBL_PTR(_22377)->dbl != 0.0;
L5: 
        if (_22374 != 0) {
            _22378 = 1;
            goto L6; // [108] 134
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _22379 = (int)*(((s1_ptr)_2)->base + _s_41754);
        _2 = (int)SEQ_PTR(_22379);
        _22380 = (int)*(((s1_ptr)_2)->base + 4);
        _22379 = NOVALUE;
        if (IS_ATOM_INT(_22380)) {
            _22381 = (_22380 == 11);
        }
        else {
            _22381 = binary_op(EQUALS, _22380, 11);
        }
        _22380 = NOVALUE;
        if (IS_ATOM_INT(_22381))
        _22378 = (_22381 != 0);
        else
        _22378 = DBL_PTR(_22381)->dbl != 0.0;
L6: 
        if (_22378 != 0) {
            DeRef(_22382);
            _22382 = 1;
            goto L7; // [134] 160
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _22383 = (int)*(((s1_ptr)_2)->base + _s_41754);
        _2 = (int)SEQ_PTR(_22383);
        _22384 = (int)*(((s1_ptr)_2)->base + 4);
        _22383 = NOVALUE;
        if (IS_ATOM_INT(_22384)) {
            _22385 = (_22384 == 13);
        }
        else {
            _22385 = binary_op(EQUALS, _22384, 13);
        }
        _22384 = NOVALUE;
        if (IS_ATOM_INT(_22385))
        _22382 = (_22385 != 0);
        else
        _22382 = DBL_PTR(_22385)->dbl != 0.0;
L7: 
        if (_22382 == 0)
        {
            _22382 = NOVALUE;
            goto L4; // [161] 242
        }
        else{
            _22382 = NOVALUE;
        }

        /** 				  if and_bits(mask, power(2, remainder(s, E_SIZE))) then*/
        _22386 = (_s_41754 % 29);
        _22387 = power(2, _22386);
        _22386 = NOVALUE;
        if (IS_ATOM_INT(_22387)) {
            {unsigned long tu;
                 tu = (unsigned long)_mask_41750 & (unsigned long)_22387;
                 _22388 = MAKE_UINT(tu);
            }
        }
        else {
            temp_d.dbl = (double)_mask_41750;
            _22388 = Dand_bits(&temp_d, DBL_PTR(_22387));
        }
        DeRef(_22387);
        _22387 = NOVALUE;
        if (_22388 == 0) {
            DeRef(_22388);
            _22388 = NOVALUE;
            goto L8; // [180] 241
        }
        else {
            if (!IS_ATOM_INT(_22388) && DBL_PTR(_22388)->dbl == 0.0){
                DeRef(_22388);
                _22388 = NOVALUE;
                goto L8; // [180] 241
            }
            DeRef(_22388);
            _22388 = NOVALUE;
        }
        DeRef(_22388);
        _22388 = NOVALUE;

        /** 					  if mask = E_ALL_EFFECT or s < sub then*/
        _22389 = (_mask_41750 == 1073741823);
        if (_22389 != 0) {
            goto L9; // [191] 204
        }
        _22391 = (_s_41754 < _sub_41752);
        if (_22391 == 0)
        {
            DeRef(_22391);
            _22391 = NOVALUE;
            goto LA; // [200] 240
        }
        else{
            DeRef(_22391);
            _22391 = NOVALUE;
        }
L9: 

        /** 						  BB_info[i][BB_TYPE..BB_OBJ] =*/
        _2 = (int)SEQ_PTR(_56BB_info_41712);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _56BB_info_41712 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_41757 + ((s1_ptr)_2)->base);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -1073741824;
        ((int *)_2)[2] = 1073741823;
        _22394 = MAKE_SEQ(_1);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = 0;
        *((int *)(_2+8)) = 0;
        Ref(_26NOVALUE_11836);
        *((int *)(_2+12)) = _26NOVALUE_11836;
        *((int *)(_2+16)) = _22394;
        _22395 = MAKE_SEQ(_1);
        _22394 = NOVALUE;
        assign_slice_seq = (s1_ptr *)_3;
        AssignSlice(2, 5, _22395);
        DeRefDS(_22395);
        _22395 = NOVALUE;
LA: 
L8: 
L4: 

        /** 		end for*/
        _i_41757 = _i_41757 + 1;
        goto L2; // [244] 26
L3: 
        ;
    }
    goto LB; // [249] 260
L1: 

    /** 		BB_info = {}*/
    RefDS(_22037);
    DeRef(_56BB_info_41712);
    _56BB_info_41712 = _22037;
LB: 

    /** end procedure*/
    DeRef(_22389);
    _22389 = NOVALUE;
    DeRef(_22369);
    _22369 = NOVALUE;
    DeRef(_22373);
    _22373 = NOVALUE;
    DeRef(_22377);
    _22377 = NOVALUE;
    DeRef(_22381);
    _22381 = NOVALUE;
    DeRef(_22385);
    _22385 = NOVALUE;
    DeRef(_22392);
    _22392 = NOVALUE;
    return;
    ;
}


int _56BB_var_obj(int _var_41822)
{
    int _bbi_41823 = NOVALUE;
    int _22406 = NOVALUE;
    int _22404 = NOVALUE;
    int _22402 = NOVALUE;
    int _22401 = NOVALUE;
    int _22399 = NOVALUE;
    int _22397 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_var_41822)) {
        _1 = (long)(DBL_PTR(_var_41822)->dbl);
        DeRefDS(_var_41822);
        _var_41822 = _1;
    }

    /** 	for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_56BB_info_41712)){
            _22397 = SEQ_PTR(_56BB_info_41712)->length;
    }
    else {
        _22397 = 1;
    }
    {
        int _i_41825;
        _i_41825 = _22397;
L1: 
        if (_i_41825 < 1){
            goto L2; // [10] 99
        }

        /** 		bbi = BB_info[i]*/
        DeRef(_bbi_41823);
        _2 = (int)SEQ_PTR(_56BB_info_41712);
        _bbi_41823 = (int)*(((s1_ptr)_2)->base + _i_41825);
        Ref(_bbi_41823);

        /** 		if bbi[BB_VAR] != var then*/
        _2 = (int)SEQ_PTR(_bbi_41823);
        _22399 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(EQUALS, _22399, _var_41822)){
            _22399 = NOVALUE;
            goto L3; // [31] 40
        }
        _22399 = NOVALUE;

        /** 			continue*/
        goto L4; // [37] 94
L3: 

        /** 		if SymTab[var][S_MODE] != M_NORMAL then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _22401 = (int)*(((s1_ptr)_2)->base + _var_41822);
        _2 = (int)SEQ_PTR(_22401);
        _22402 = (int)*(((s1_ptr)_2)->base + 3);
        _22401 = NOVALUE;
        if (binary_op_a(EQUALS, _22402, 1)){
            _22402 = NOVALUE;
            goto L5; // [56] 65
        }
        _22402 = NOVALUE;

        /** 			continue*/
        goto L4; // [62] 94
L5: 

        /** 		if bbi[BB_TYPE] != TYPE_INTEGER then*/
        _2 = (int)SEQ_PTR(_bbi_41823);
        _22404 = (int)*(((s1_ptr)_2)->base + 2);
        if (binary_op_a(EQUALS, _22404, 1)){
            _22404 = NOVALUE;
            goto L6; // [73] 82
        }
        _22404 = NOVALUE;

        /** 			exit*/
        goto L2; // [79] 99
L6: 

        /** 		return bbi[BB_OBJ]*/
        _2 = (int)SEQ_PTR(_bbi_41823);
        _22406 = (int)*(((s1_ptr)_2)->base + 5);
        Ref(_22406);
        DeRef(_bbi_41823);
        return _22406;

        /** 	end for*/
L4: 
        _i_41825 = _i_41825 + -1;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** 	return BB_def_values*/
    RefDS(_56BB_def_values_41816);
    DeRef(_bbi_41823);
    _22406 = NOVALUE;
    return _56BB_def_values_41816;
    ;
}


int _56BB_var_type(int _var_41845)
{
    int _22421 = NOVALUE;
    int _22420 = NOVALUE;
    int _22418 = NOVALUE;
    int _22417 = NOVALUE;
    int _22416 = NOVALUE;
    int _22415 = NOVALUE;
    int _22414 = NOVALUE;
    int _22413 = NOVALUE;
    int _22412 = NOVALUE;
    int _22411 = NOVALUE;
    int _22410 = NOVALUE;
    int _22409 = NOVALUE;
    int _22408 = NOVALUE;
    int _22407 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_var_41845)) {
        _1 = (long)(DBL_PTR(_var_41845)->dbl);
        DeRefDS(_var_41845);
        _var_41845 = _1;
    }

    /** 	for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_56BB_info_41712)){
            _22407 = SEQ_PTR(_56BB_info_41712)->length;
    }
    else {
        _22407 = 1;
    }
    {
        int _i_41847;
        _i_41847 = _22407;
L1: 
        if (_i_41847 < 1){
            goto L2; // [10] 125
        }

        /** 		if BB_info[i][BB_VAR] = var and*/
        _2 = (int)SEQ_PTR(_56BB_info_41712);
        _22408 = (int)*(((s1_ptr)_2)->base + _i_41847);
        _2 = (int)SEQ_PTR(_22408);
        _22409 = (int)*(((s1_ptr)_2)->base + 1);
        _22408 = NOVALUE;
        if (IS_ATOM_INT(_22409)) {
            _22410 = (_22409 == _var_41845);
        }
        else {
            _22410 = binary_op(EQUALS, _22409, _var_41845);
        }
        _22409 = NOVALUE;
        if (IS_ATOM_INT(_22410)) {
            if (_22410 == 0) {
                goto L3; // [33] 118
            }
        }
        else {
            if (DBL_PTR(_22410)->dbl == 0.0) {
                goto L3; // [33] 118
            }
        }
        _2 = (int)SEQ_PTR(_56BB_info_41712);
        _22412 = (int)*(((s1_ptr)_2)->base + _i_41847);
        _2 = (int)SEQ_PTR(_22412);
        _22413 = (int)*(((s1_ptr)_2)->base + 1);
        _22412 = NOVALUE;
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!IS_ATOM_INT(_22413)){
            _22414 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22413)->dbl));
        }
        else{
            _22414 = (int)*(((s1_ptr)_2)->base + _22413);
        }
        _2 = (int)SEQ_PTR(_22414);
        _22415 = (int)*(((s1_ptr)_2)->base + 3);
        _22414 = NOVALUE;
        if (IS_ATOM_INT(_22415)) {
            _22416 = (_22415 == 1);
        }
        else {
            _22416 = binary_op(EQUALS, _22415, 1);
        }
        _22415 = NOVALUE;
        if (_22416 == 0) {
            DeRef(_22416);
            _22416 = NOVALUE;
            goto L3; // [66] 118
        }
        else {
            if (!IS_ATOM_INT(_22416) && DBL_PTR(_22416)->dbl == 0.0){
                DeRef(_22416);
                _22416 = NOVALUE;
                goto L3; // [66] 118
            }
            DeRef(_22416);
            _22416 = NOVALUE;
        }
        DeRef(_22416);
        _22416 = NOVALUE;

        /** 			ifdef DEBUG then*/

        /** 			if BB_info[i][BB_TYPE] = TYPE_NULL then  -- var has only been read*/
        _2 = (int)SEQ_PTR(_56BB_info_41712);
        _22417 = (int)*(((s1_ptr)_2)->base + _i_41847);
        _2 = (int)SEQ_PTR(_22417);
        _22418 = (int)*(((s1_ptr)_2)->base + 2);
        _22417 = NOVALUE;
        if (binary_op_a(NOTEQ, _22418, 0)){
            _22418 = NOVALUE;
            goto L4; // [85] 100
        }
        _22418 = NOVALUE;

        /** 				return TYPE_OBJECT*/
        _22413 = NOVALUE;
        DeRef(_22410);
        _22410 = NOVALUE;
        return 16;
        goto L5; // [97] 117
L4: 

        /** 				return BB_info[i][BB_TYPE]*/
        _2 = (int)SEQ_PTR(_56BB_info_41712);
        _22420 = (int)*(((s1_ptr)_2)->base + _i_41847);
        _2 = (int)SEQ_PTR(_22420);
        _22421 = (int)*(((s1_ptr)_2)->base + 2);
        _22420 = NOVALUE;
        Ref(_22421);
        _22413 = NOVALUE;
        DeRef(_22410);
        _22410 = NOVALUE;
        return _22421;
L5: 
L3: 

        /** 	end for*/
        _i_41847 = _i_41847 + -1;
        goto L1; // [120] 17
L2: 
        ;
    }

    /** 	return TYPE_OBJECT*/
    _22413 = NOVALUE;
    DeRef(_22410);
    _22410 = NOVALUE;
    _22421 = NOVALUE;
    return 16;
    ;
}


int _56GType(int _s_41875)
{
    int _t_41876 = NOVALUE;
    int _local_t_41877 = NOVALUE;
    int _22425 = NOVALUE;
    int _22424 = NOVALUE;
    int _22422 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_41875)) {
        _1 = (long)(DBL_PTR(_s_41875)->dbl);
        DeRefDS(_s_41875);
        _s_41875 = _1;
    }

    /** 	t = SymTab[s][S_GTYPE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22422 = (int)*(((s1_ptr)_2)->base + _s_41875);
    _2 = (int)SEQ_PTR(_22422);
    _t_41876 = (int)*(((s1_ptr)_2)->base + 36);
    if (!IS_ATOM_INT(_t_41876)){
        _t_41876 = (long)DBL_PTR(_t_41876)->dbl;
    }
    _22422 = NOVALUE;

    /** 	ifdef DEBUG then*/

    /** 	if SymTab[s][S_MODE] != M_NORMAL then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22424 = (int)*(((s1_ptr)_2)->base + _s_41875);
    _2 = (int)SEQ_PTR(_22424);
    _22425 = (int)*(((s1_ptr)_2)->base + 3);
    _22424 = NOVALUE;
    if (binary_op_a(EQUALS, _22425, 1)){
        _22425 = NOVALUE;
        goto L1; // [37] 48
    }
    _22425 = NOVALUE;

    /** 		return t*/
    return _t_41876;
L1: 

    /** 	local_t = BB_var_type(s)*/
    _local_t_41877 = _56BB_var_type(_s_41875);
    if (!IS_ATOM_INT(_local_t_41877)) {
        _1 = (long)(DBL_PTR(_local_t_41877)->dbl);
        DeRefDS(_local_t_41877);
        _local_t_41877 = _1;
    }

    /** 	if local_t = TYPE_OBJECT then*/
    if (_local_t_41877 != 16)
    goto L2; // [60] 71

    /** 		return t*/
    return _t_41876;
L2: 

    /** 	if t = TYPE_INTEGER then*/
    if (_t_41876 != 1)
    goto L3; // [75] 88

    /** 		return TYPE_INTEGER*/
    return 1;
L3: 

    /** 	return local_t*/
    return _local_t_41877;
    ;
}


int _56GDelete()
{
    int _0, _1, _2;
    

    /** 	return g_has_delete*/
    return _56g_has_delete_41897;
    ;
}


int _56HasDelete(int _s_41904)
{
    int _22440 = NOVALUE;
    int _22439 = NOVALUE;
    int _22437 = NOVALUE;
    int _22436 = NOVALUE;
    int _22435 = NOVALUE;
    int _22434 = NOVALUE;
    int _22432 = NOVALUE;
    int _22431 = NOVALUE;
    int _22430 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_41904)) {
        _1 = (long)(DBL_PTR(_s_41904)->dbl);
        DeRefDS(_s_41904);
        _s_41904 = _1;
    }

    /** 	for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_56BB_info_41712)){
            _22430 = SEQ_PTR(_56BB_info_41712)->length;
    }
    else {
        _22430 = 1;
    }
    {
        int _i_41906;
        _i_41906 = _22430;
L1: 
        if (_i_41906 < 1){
            goto L2; // [10] 57
        }

        /** 		if BB_info[i][BB_VAR] = s then*/
        _2 = (int)SEQ_PTR(_56BB_info_41712);
        _22431 = (int)*(((s1_ptr)_2)->base + _i_41906);
        _2 = (int)SEQ_PTR(_22431);
        _22432 = (int)*(((s1_ptr)_2)->base + 1);
        _22431 = NOVALUE;
        if (binary_op_a(NOTEQ, _22432, _s_41904)){
            _22432 = NOVALUE;
            goto L3; // [29] 50
        }
        _22432 = NOVALUE;

        /** 			return BB_info[i][BB_DELETE]*/
        _2 = (int)SEQ_PTR(_56BB_info_41712);
        _22434 = (int)*(((s1_ptr)_2)->base + _i_41906);
        _2 = (int)SEQ_PTR(_22434);
        _22435 = (int)*(((s1_ptr)_2)->base + 6);
        _22434 = NOVALUE;
        Ref(_22435);
        return _22435;
L3: 

        /** 	end for*/
        _i_41906 = _i_41906 + -1;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** 	if length(SymTab[s]) < S_HAS_DELETE then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22436 = (int)*(((s1_ptr)_2)->base + _s_41904);
    if (IS_SEQUENCE(_22436)){
            _22437 = SEQ_PTR(_22436)->length;
    }
    else {
        _22437 = 1;
    }
    _22436 = NOVALUE;
    if (_22437 >= 54)
    goto L4; // [70] 81

    /** 		return 0*/
    _22435 = NOVALUE;
    _22436 = NOVALUE;
    return 0;
L4: 

    /** 	return SymTab[s][S_HAS_DELETE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22439 = (int)*(((s1_ptr)_2)->base + _s_41904);
    _2 = (int)SEQ_PTR(_22439);
    _22440 = (int)*(((s1_ptr)_2)->base + 54);
    _22439 = NOVALUE;
    Ref(_22440);
    _22435 = NOVALUE;
    _22436 = NOVALUE;
    return _22440;
    ;
}


int _56ObjValue(int _s_41927)
{
    int _local_t_41928 = NOVALUE;
    int _st_41929 = NOVALUE;
    int _tmin_41930 = NOVALUE;
    int _tmax_41931 = NOVALUE;
    int _22453 = NOVALUE;
    int _22451 = NOVALUE;
    int _22450 = NOVALUE;
    int _22448 = NOVALUE;
    int _22445 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_41927)) {
        _1 = (long)(DBL_PTR(_s_41927)->dbl);
        DeRefDS(_s_41927);
        _s_41927 = _1;
    }

    /** 	st = SymTab[s]*/
    DeRef(_st_41929);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _st_41929 = (int)*(((s1_ptr)_2)->base + _s_41927);
    Ref(_st_41929);

    /** 	tmin = st[S_OBJ_MIN]*/
    DeRef(_tmin_41930);
    _2 = (int)SEQ_PTR(_st_41929);
    _tmin_41930 = (int)*(((s1_ptr)_2)->base + 30);
    Ref(_tmin_41930);

    /** 	tmax = st[S_OBJ_MAX]*/
    DeRef(_tmax_41931);
    _2 = (int)SEQ_PTR(_st_41929);
    _tmax_41931 = (int)*(((s1_ptr)_2)->base + 31);
    Ref(_tmax_41931);

    /** 	if tmin != tmax then*/
    if (binary_op_a(EQUALS, _tmin_41930, _tmax_41931)){
        goto L1; // [29] 41
    }

    /** 		tmin = NOVALUE*/
    Ref(_26NOVALUE_11836);
    DeRef(_tmin_41930);
    _tmin_41930 = _26NOVALUE_11836;
L1: 

    /** 	if st[S_MODE] != M_NORMAL then*/
    _2 = (int)SEQ_PTR(_st_41929);
    _22445 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(EQUALS, _22445, 1)){
        _22445 = NOVALUE;
        goto L2; // [51] 62
    }
    _22445 = NOVALUE;

    /** 		return tmin*/
    DeRef(_local_t_41928);
    DeRef(_st_41929);
    DeRef(_tmax_41931);
    return _tmin_41930;
L2: 

    /** 	local_t = BB_var_obj(s)*/
    _0 = _local_t_41928;
    _local_t_41928 = _56BB_var_obj(_s_41927);
    DeRef(_0);

    /** 	if local_t[MIN] = NOVALUE then*/
    _2 = (int)SEQ_PTR(_local_t_41928);
    _22448 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _22448, _26NOVALUE_11836)){
        _22448 = NOVALUE;
        goto L3; // [80] 91
    }
    _22448 = NOVALUE;

    /** 		return tmin*/
    DeRefDS(_local_t_41928);
    DeRef(_st_41929);
    DeRef(_tmax_41931);
    return _tmin_41930;
L3: 

    /** 	if local_t[MIN] != local_t[MAX] then*/
    _2 = (int)SEQ_PTR(_local_t_41928);
    _22450 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_local_t_41928);
    _22451 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(EQUALS, _22450, _22451)){
        _22450 = NOVALUE;
        _22451 = NOVALUE;
        goto L4; // [105] 116
    }
    _22450 = NOVALUE;
    _22451 = NOVALUE;

    /** 		return tmin*/
    DeRefDS(_local_t_41928);
    DeRef(_st_41929);
    DeRef(_tmax_41931);
    return _tmin_41930;
L4: 

    /** 	return local_t[MIN]*/
    _2 = (int)SEQ_PTR(_local_t_41928);
    _22453 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22453);
    DeRefDS(_local_t_41928);
    DeRef(_st_41929);
    DeRef(_tmin_41930);
    DeRef(_tmax_41931);
    return _22453;
    ;
}


int _56TypeIs(int _x_41962, int _typei_41963)
{
    int _22455 = NOVALUE;
    int _22454 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_41962)) {
        _1 = (long)(DBL_PTR(_x_41962)->dbl);
        DeRefDS(_x_41962);
        _x_41962 = _1;
    }
    if (!IS_ATOM_INT(_typei_41963)) {
        _1 = (long)(DBL_PTR(_typei_41963)->dbl);
        DeRefDS(_typei_41963);
        _typei_41963 = _1;
    }

    /** 	return GType(x) = typei*/
    _22454 = _56GType(_x_41962);
    if (IS_ATOM_INT(_22454)) {
        _22455 = (_22454 == _typei_41963);
    }
    else {
        _22455 = binary_op(EQUALS, _22454, _typei_41963);
    }
    DeRef(_22454);
    _22454 = NOVALUE;
    return _22455;
    ;
}


int _56TypeIsIn(int _x_41968, int _types_41969)
{
    int _22457 = NOVALUE;
    int _22456 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_41968)) {
        _1 = (long)(DBL_PTR(_x_41968)->dbl);
        DeRefDS(_x_41968);
        _x_41968 = _1;
    }

    /** 	return find(GType(x), types)*/
    _22456 = _56GType(_x_41968);
    _22457 = find_from(_22456, _types_41969, 1);
    DeRef(_22456);
    _22456 = NOVALUE;
    DeRefDS(_types_41969);
    return _22457;
    ;
}


int _56TypeIsNot(int _x_41974, int _typei_41975)
{
    int _22459 = NOVALUE;
    int _22458 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_41974)) {
        _1 = (long)(DBL_PTR(_x_41974)->dbl);
        DeRefDS(_x_41974);
        _x_41974 = _1;
    }
    if (!IS_ATOM_INT(_typei_41975)) {
        _1 = (long)(DBL_PTR(_typei_41975)->dbl);
        DeRefDS(_typei_41975);
        _typei_41975 = _1;
    }

    /** 	return GType(x) != typei*/
    _22458 = _56GType(_x_41974);
    if (IS_ATOM_INT(_22458)) {
        _22459 = (_22458 != _typei_41975);
    }
    else {
        _22459 = binary_op(NOTEQ, _22458, _typei_41975);
    }
    DeRef(_22458);
    _22458 = NOVALUE;
    return _22459;
    ;
}


int _56TypeIsNotIn(int _x_41980, int _types_41981)
{
    int _22462 = NOVALUE;
    int _22461 = NOVALUE;
    int _22460 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_41980)) {
        _1 = (long)(DBL_PTR(_x_41980)->dbl);
        DeRefDS(_x_41980);
        _x_41980 = _1;
    }

    /** 	return not find(GType(x), types)*/
    _22460 = _56GType(_x_41980);
    _22461 = find_from(_22460, _types_41981, 1);
    DeRef(_22460);
    _22460 = NOVALUE;
    _22462 = (_22461 == 0);
    _22461 = NOVALUE;
    DeRefDS(_types_41981);
    return _22462;
    ;
}


int _56or_type(int _t1_41987, int _t2_41988)
{
    int _22482 = NOVALUE;
    int _22481 = NOVALUE;
    int _22480 = NOVALUE;
    int _22479 = NOVALUE;
    int _22474 = NOVALUE;
    int _22472 = NOVALUE;
    int _22467 = NOVALUE;
    int _22465 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_t1_41987)) {
        _1 = (long)(DBL_PTR(_t1_41987)->dbl);
        DeRefDS(_t1_41987);
        _t1_41987 = _1;
    }
    if (!IS_ATOM_INT(_t2_41988)) {
        _1 = (long)(DBL_PTR(_t2_41988)->dbl);
        DeRefDS(_t2_41988);
        _t2_41988 = _1;
    }

    /** 	if t1 = TYPE_NULL then*/
    if (_t1_41987 != 0)
    goto L1; // [9] 22

    /** 		return t2*/
    return _t2_41988;
    goto L2; // [19] 307
L1: 

    /** 	elsif t2 = TYPE_NULL then*/
    if (_t2_41988 != 0)
    goto L3; // [26] 39

    /** 		return t1*/
    return _t1_41987;
    goto L2; // [36] 307
L3: 

    /** 	elsif t1 = TYPE_OBJECT or t2 = TYPE_OBJECT then*/
    _22465 = (_t1_41987 == 16);
    if (_22465 != 0) {
        goto L4; // [47] 62
    }
    _22467 = (_t2_41988 == 16);
    if (_22467 == 0)
    {
        DeRef(_22467);
        _22467 = NOVALUE;
        goto L5; // [58] 73
    }
    else{
        DeRef(_22467);
        _22467 = NOVALUE;
    }
L4: 

    /** 		return TYPE_OBJECT*/
    DeRef(_22465);
    _22465 = NOVALUE;
    return 16;
    goto L2; // [70] 307
L5: 

    /** 	elsif t1 = TYPE_SEQUENCE then*/
    if (_t1_41987 != 8)
    goto L6; // [77] 112

    /** 		if t2 = TYPE_SEQUENCE then*/
    if (_t2_41988 != 8)
    goto L7; // [85] 100

    /** 			return TYPE_SEQUENCE*/
    DeRef(_22465);
    _22465 = NOVALUE;
    return 8;
    goto L2; // [97] 307
L7: 

    /** 			return TYPE_OBJECT*/
    DeRef(_22465);
    _22465 = NOVALUE;
    return 16;
    goto L2; // [109] 307
L6: 

    /** 	elsif t2 = TYPE_SEQUENCE then*/
    if (_t2_41988 != 8)
    goto L8; // [116] 151

    /** 		if t1 = TYPE_SEQUENCE then*/
    if (_t1_41987 != 8)
    goto L9; // [124] 139

    /** 			return TYPE_SEQUENCE*/
    DeRef(_22465);
    _22465 = NOVALUE;
    return 8;
    goto L2; // [136] 307
L9: 

    /** 			return TYPE_OBJECT*/
    DeRef(_22465);
    _22465 = NOVALUE;
    return 16;
    goto L2; // [148] 307
L8: 

    /** 	elsif t1 = TYPE_ATOM or t2 = TYPE_ATOM then*/
    _22472 = (_t1_41987 == 4);
    if (_22472 != 0) {
        goto LA; // [159] 174
    }
    _22474 = (_t2_41988 == 4);
    if (_22474 == 0)
    {
        DeRef(_22474);
        _22474 = NOVALUE;
        goto LB; // [170] 185
    }
    else{
        DeRef(_22474);
        _22474 = NOVALUE;
    }
LA: 

    /** 		return TYPE_ATOM*/
    DeRef(_22465);
    _22465 = NOVALUE;
    DeRef(_22472);
    _22472 = NOVALUE;
    return 4;
    goto L2; // [182] 307
LB: 

    /** 	elsif t1 = TYPE_DOUBLE then*/
    if (_t1_41987 != 2)
    goto LC; // [189] 224

    /** 		if t2 = TYPE_INTEGER then*/
    if (_t2_41988 != 1)
    goto LD; // [197] 212

    /** 			return TYPE_ATOM*/
    DeRef(_22465);
    _22465 = NOVALUE;
    DeRef(_22472);
    _22472 = NOVALUE;
    return 4;
    goto L2; // [209] 307
LD: 

    /** 			return TYPE_DOUBLE*/
    DeRef(_22465);
    _22465 = NOVALUE;
    DeRef(_22472);
    _22472 = NOVALUE;
    return 2;
    goto L2; // [221] 307
LC: 

    /** 	elsif t2 = TYPE_DOUBLE then*/
    if (_t2_41988 != 2)
    goto LE; // [228] 263

    /** 		if t1 = TYPE_INTEGER then*/
    if (_t1_41987 != 1)
    goto LF; // [236] 251

    /** 			return TYPE_ATOM*/
    DeRef(_22465);
    _22465 = NOVALUE;
    DeRef(_22472);
    _22472 = NOVALUE;
    return 4;
    goto L2; // [248] 307
LF: 

    /** 			return TYPE_DOUBLE*/
    DeRef(_22465);
    _22465 = NOVALUE;
    DeRef(_22472);
    _22472 = NOVALUE;
    return 2;
    goto L2; // [260] 307
LE: 

    /** 	elsif t1 = TYPE_INTEGER and t2 = TYPE_INTEGER then*/
    _22479 = (_t1_41987 == 1);
    if (_22479 == 0) {
        goto L10; // [271] 296
    }
    _22481 = (_t2_41988 == 1);
    if (_22481 == 0)
    {
        DeRef(_22481);
        _22481 = NOVALUE;
        goto L10; // [282] 296
    }
    else{
        DeRef(_22481);
        _22481 = NOVALUE;
    }

    /** 		return TYPE_INTEGER*/
    DeRef(_22465);
    _22465 = NOVALUE;
    DeRef(_22472);
    _22472 = NOVALUE;
    DeRef(_22479);
    _22479 = NOVALUE;
    return 1;
    goto L2; // [293] 307
L10: 

    /** 		InternalErr(258, {t1, t2})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _t1_41987;
    ((int *)_2)[2] = _t2_41988;
    _22482 = MAKE_SEQ(_1);
    _43InternalErr(258, _22482);
    _22482 = NOVALUE;
L2: 
    ;
}


void _56RemoveFromBB(int _s_42058)
{
    int _int_42059 = NOVALUE;
    int _22484 = NOVALUE;
    int _22483 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_42058)) {
        _1 = (long)(DBL_PTR(_s_42058)->dbl);
        DeRefDS(_s_42058);
        _s_42058 = _1;
    }

    /** 	for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_56BB_info_41712)){
            _22483 = SEQ_PTR(_56BB_info_41712)->length;
    }
    else {
        _22483 = 1;
    }
    {
        int _i_42061;
        _i_42061 = 1;
L1: 
        if (_i_42061 > _22483){
            goto L2; // [10] 59
        }

        /** 		int = BB_info[i][BB_VAR]*/
        _2 = (int)SEQ_PTR(_56BB_info_41712);
        _22484 = (int)*(((s1_ptr)_2)->base + _i_42061);
        _2 = (int)SEQ_PTR(_22484);
        _int_42059 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_int_42059)){
            _int_42059 = (long)DBL_PTR(_int_42059)->dbl;
        }
        _22484 = NOVALUE;

        /** 		if int = s then*/
        if (_int_42059 != _s_42058)
        goto L3; // [33] 52

        /** 			BB_info = remove( BB_info, int )*/
        {
            s1_ptr assign_space = SEQ_PTR(_56BB_info_41712);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_int_42059)) ? _int_42059 : (long)(DBL_PTR(_int_42059)->dbl);
            int stop = (IS_ATOM_INT(_int_42059)) ? _int_42059 : (long)(DBL_PTR(_int_42059)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_56BB_info_41712), start, &_56BB_info_41712 );
                }
                else Tail(SEQ_PTR(_56BB_info_41712), stop+1, &_56BB_info_41712);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_56BB_info_41712), start, &_56BB_info_41712);
            }
            else {
                assign_slice_seq = &assign_space;
                _56BB_info_41712 = Remove_elements(start, stop, (SEQ_PTR(_56BB_info_41712)->ref == 1));
            }
        }

        /** 			return*/
        return;
L3: 

        /** 	end for*/
        _i_42061 = _i_42061 + 1;
        goto L1; // [54] 17
L2: 
        ;
    }

    /** end procedure*/
    return;
    ;
}


void _56SetBBType(int _s_42079, int _t_42080, int _val_42081, int _etype_42082, int _has_delete_42083)
{
    int _found_42084 = NOVALUE;
    int _i_42085 = NOVALUE;
    int _tn_42086 = NOVALUE;
    int _int_42087 = NOVALUE;
    int _sym_42088 = NOVALUE;
    int _mode_42093 = NOVALUE;
    int _gtype_42108 = NOVALUE;
    int _new_type_42145 = NOVALUE;
    int _bbsym_42168 = NOVALUE;
    int _bbi_42304 = NOVALUE;
    int _22603 = NOVALUE;
    int _22602 = NOVALUE;
    int _22601 = NOVALUE;
    int _22599 = NOVALUE;
    int _22598 = NOVALUE;
    int _22597 = NOVALUE;
    int _22595 = NOVALUE;
    int _22594 = NOVALUE;
    int _22592 = NOVALUE;
    int _22590 = NOVALUE;
    int _22589 = NOVALUE;
    int _22587 = NOVALUE;
    int _22585 = NOVALUE;
    int _22584 = NOVALUE;
    int _22583 = NOVALUE;
    int _22582 = NOVALUE;
    int _22581 = NOVALUE;
    int _22580 = NOVALUE;
    int _22579 = NOVALUE;
    int _22578 = NOVALUE;
    int _22577 = NOVALUE;
    int _22574 = NOVALUE;
    int _22570 = NOVALUE;
    int _22565 = NOVALUE;
    int _22563 = NOVALUE;
    int _22562 = NOVALUE;
    int _22561 = NOVALUE;
    int _22559 = NOVALUE;
    int _22557 = NOVALUE;
    int _22556 = NOVALUE;
    int _22555 = NOVALUE;
    int _22553 = NOVALUE;
    int _22552 = NOVALUE;
    int _22550 = NOVALUE;
    int _22549 = NOVALUE;
    int _22548 = NOVALUE;
    int _22546 = NOVALUE;
    int _22545 = NOVALUE;
    int _22542 = NOVALUE;
    int _22541 = NOVALUE;
    int _22540 = NOVALUE;
    int _22538 = NOVALUE;
    int _22536 = NOVALUE;
    int _22535 = NOVALUE;
    int _22533 = NOVALUE;
    int _22532 = NOVALUE;
    int _22531 = NOVALUE;
    int _22529 = NOVALUE;
    int _22528 = NOVALUE;
    int _22517 = NOVALUE;
    int _22515 = NOVALUE;
    int _22512 = NOVALUE;
    int _22511 = NOVALUE;
    int _22508 = NOVALUE;
    int _22507 = NOVALUE;
    int _22506 = NOVALUE;
    int _22504 = NOVALUE;
    int _22503 = NOVALUE;
    int _22502 = NOVALUE;
    int _22500 = NOVALUE;
    int _22499 = NOVALUE;
    int _22497 = NOVALUE;
    int _22494 = NOVALUE;
    int _22492 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_42079)) {
        _1 = (long)(DBL_PTR(_s_42079)->dbl);
        DeRefDS(_s_42079);
        _s_42079 = _1;
    }
    if (!IS_ATOM_INT(_t_42080)) {
        _1 = (long)(DBL_PTR(_t_42080)->dbl);
        DeRefDS(_t_42080);
        _t_42080 = _1;
    }
    if (!IS_ATOM_INT(_etype_42082)) {
        _1 = (long)(DBL_PTR(_etype_42082)->dbl);
        DeRefDS(_etype_42082);
        _etype_42082 = _1;
    }
    if (!IS_ATOM_INT(_has_delete_42083)) {
        _1 = (long)(DBL_PTR(_has_delete_42083)->dbl);
        DeRefDS(_has_delete_42083);
        _has_delete_42083 = _1;
    }

    /** 	if has_delete then*/
    if (_has_delete_42083 == 0)
    {
        goto L1; // [13] 27
    }
    else{
    }

    /** 		p_has_delete = 1*/
    _56p_has_delete_41898 = 1;

    /** 		g_has_delete = 1*/
    _56g_has_delete_41897 = 1;
L1: 

    /** 	sym = SymTab[s]*/
    DeRef(_sym_42088);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _sym_42088 = (int)*(((s1_ptr)_2)->base + _s_42079);
    Ref(_sym_42088);

    /** 	SymTab[s] = 0*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _s_42079);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	integer mode = sym[S_MODE]*/
    _2 = (int)SEQ_PTR(_sym_42088);
    _mode_42093 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_42093))
    _mode_42093 = (long)DBL_PTR(_mode_42093)->dbl;

    /** 	if mode = M_NORMAL or mode = M_TEMP  then*/
    _22492 = (_mode_42093 == 1);
    if (_22492 != 0) {
        goto L2; // [61] 76
    }
    _22494 = (_mode_42093 == 3);
    if (_22494 == 0)
    {
        DeRef(_22494);
        _22494 = NOVALUE;
        goto L3; // [72] 1167
    }
    else{
        DeRef(_22494);
        _22494 = NOVALUE;
    }
L2: 

    /** 		found = FALSE*/
    _found_42084 = _9FALSE_428;

    /** 		if mode = M_TEMP then*/
    if (_mode_42093 != 3)
    goto L4; // [89] 465

    /** 			sym[S_GTYPE] = t*/
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _t_42080;
    DeRef(_1);

    /** 			sym[S_SEQ_ELEM] = etype*/
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _etype_42082;
    DeRef(_1);

    /** 			integer gtype = sym[S_GTYPE]*/
    _2 = (int)SEQ_PTR(_sym_42088);
    _gtype_42108 = (int)*(((s1_ptr)_2)->base + 36);
    if (!IS_ATOM_INT(_gtype_42108))
    _gtype_42108 = (long)DBL_PTR(_gtype_42108)->dbl;

    /** 			if gtype = TYPE_OBJECT*/
    _22497 = (_gtype_42108 == 16);
    if (_22497 != 0) {
        goto L5; // [125] 140
    }
    _22499 = (_gtype_42108 == 8);
    if (_22499 == 0)
    {
        DeRef(_22499);
        _22499 = NOVALUE;
        goto L6; // [136] 213
    }
    else{
        DeRef(_22499);
        _22499 = NOVALUE;
    }
L5: 

    /** 				if val[MIN] < 0 then*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22500 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22500, 0)){
        _22500 = NOVALUE;
        goto L7; // [148] 165
    }
    _22500 = NOVALUE;

    /** 					sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
    goto L8; // [162] 180
L7: 

    /** 					sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22502 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22502);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _22502;
    if( _1 != _22502 ){
        DeRef(_1);
    }
    _22502 = NOVALUE;
L8: 

    /** 				sym[S_OBJ] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);

    /** 				sym[S_OBJ_MIN] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);

    /** 				sym[S_OBJ_MAX] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
    goto L9; // [210] 252
L6: 

    /** 				sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22503 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22503);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _22503;
    if( _1 != _22503 ){
        DeRef(_1);
    }
    _22503 = NOVALUE;

    /** 				sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22504 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_22504);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _22504;
    if( _1 != _22504 ){
        DeRef(_1);
    }
    _22504 = NOVALUE;

    /** 				sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
L9: 

    /** 			if not Initializing then*/
    if (_26Initializing_12063 != 0)
    goto LA; // [256] 326

    /** 				integer new_type = or_type(temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW], t)*/
    _2 = (int)SEQ_PTR(_sym_42088);
    _22506 = (int)*(((s1_ptr)_2)->base + 34);
    _2 = (int)SEQ_PTR(_26temp_name_type_12065);
    if (!IS_ATOM_INT(_22506)){
        _22507 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22506)->dbl));
    }
    else{
        _22507 = (int)*(((s1_ptr)_2)->base + _22506);
    }
    _2 = (int)SEQ_PTR(_22507);
    _22508 = (int)*(((s1_ptr)_2)->base + 2);
    _22507 = NOVALUE;
    Ref(_22508);
    _new_type_42145 = _56or_type(_22508, _t_42080);
    _22508 = NOVALUE;
    if (!IS_ATOM_INT(_new_type_42145)) {
        _1 = (long)(DBL_PTR(_new_type_42145)->dbl);
        DeRefDS(_new_type_42145);
        _new_type_42145 = _1;
    }

    /** 				if new_type = TYPE_NULL then*/
    if (_new_type_42145 != 0)
    goto LB; // [290] 304

    /** 					new_type = TYPE_OBJECT*/
    _new_type_42145 = 16;
LB: 

    /** 				temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW] = new_type*/
    _2 = (int)SEQ_PTR(_sym_42088);
    _22511 = (int)*(((s1_ptr)_2)->base + 34);
    _2 = (int)SEQ_PTR(_26temp_name_type_12065);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26temp_name_type_12065 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_22511))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_22511)->dbl));
    else
    _3 = (int)(_22511 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _new_type_42145;
    DeRef(_1);
    _22512 = NOVALUE;
LA: 

    /** 			tn = sym[S_TEMP_NAME]*/
    _2 = (int)SEQ_PTR(_sym_42088);
    _tn_42086 = (int)*(((s1_ptr)_2)->base + 34);
    if (!IS_ATOM_INT(_tn_42086))
    _tn_42086 = (long)DBL_PTR(_tn_42086)->dbl;

    /** 			i = 1*/
    _i_42085 = 1;

    /** 			while i <= length(BB_info) do*/
LC: 
    if (IS_SEQUENCE(_56BB_info_41712)){
            _22515 = SEQ_PTR(_56BB_info_41712)->length;
    }
    else {
        _22515 = 1;
    }
    if (_i_42085 > _22515)
    goto LD; // [351] 460

    /** 				sequence bbsym*/

    /** 				int = BB_info[i][BB_VAR]*/
    _2 = (int)SEQ_PTR(_56BB_info_41712);
    _22517 = (int)*(((s1_ptr)_2)->base + _i_42085);
    _2 = (int)SEQ_PTR(_22517);
    _int_42087 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_42087)){
        _int_42087 = (long)DBL_PTR(_int_42087)->dbl;
    }
    _22517 = NOVALUE;

    /** 				if int = s then*/
    if (_int_42087 != _s_42079)
    goto LE; // [373] 387

    /** 					bbsym = sym*/
    RefDS(_sym_42088);
    DeRef(_bbsym_42168);
    _bbsym_42168 = _sym_42088;
    goto LF; // [384] 398
LE: 

    /** 					bbsym = SymTab[int]*/
    DeRef(_bbsym_42168);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _bbsym_42168 = (int)*(((s1_ptr)_2)->base + _int_42087);
    Ref(_bbsym_42168);
LF: 

    /** 				int = bbsym[S_MODE]*/
    _2 = (int)SEQ_PTR(_bbsym_42168);
    _int_42087 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_int_42087))
    _int_42087 = (long)DBL_PTR(_int_42087)->dbl;

    /** 				if int = M_TEMP then*/
    if (_int_42087 != 3)
    goto L10; // [412] 447

    /** 					int = bbsym[S_TEMP_NAME]*/
    _2 = (int)SEQ_PTR(_bbsym_42168);
    _int_42087 = (int)*(((s1_ptr)_2)->base + 34);
    if (!IS_ATOM_INT(_int_42087))
    _int_42087 = (long)DBL_PTR(_int_42087)->dbl;

    /** 					if int = tn then*/
    if (_int_42087 != _tn_42086)
    goto L11; // [426] 446

    /** 						found = TRUE*/
    _found_42084 = _9TRUE_430;

    /** 						exit*/
    DeRefDS(_bbsym_42168);
    _bbsym_42168 = NOVALUE;
    goto LD; // [443] 460
L11: 
L10: 

    /** 				i += 1*/
    _i_42085 = _i_42085 + 1;
    DeRef(_bbsym_42168);
    _bbsym_42168 = NOVALUE;

    /** 			end while*/
    goto LC; // [457] 346
LD: 
    goto L12; // [462] 889
L4: 

    /** 			if t != TYPE_NULL then*/
    if (_t_42080 == 0)
    goto L13; // [469] 824

    /** 				if not Initializing then*/
    if (_26Initializing_12063 != 0)
    goto L14; // [477] 500

    /** 					sym[S_GTYPE_NEW] = or_type(sym[S_GTYPE_NEW], t)*/
    _2 = (int)SEQ_PTR(_sym_42088);
    _22528 = (int)*(((s1_ptr)_2)->base + 38);
    Ref(_22528);
    _22529 = _56or_type(_22528, _t_42080);
    _22528 = NOVALUE;
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 38);
    _1 = *(int *)_2;
    *(int *)_2 = _22529;
    if( _1 != _22529 ){
        DeRef(_1);
    }
    _22529 = NOVALUE;
L14: 

    /** 				if t = TYPE_SEQUENCE then*/
    if (_t_42080 != 8)
    goto L15; // [504] 633

    /** 					sym[S_SEQ_ELEM_NEW] =*/
    _2 = (int)SEQ_PTR(_sym_42088);
    _22531 = (int)*(((s1_ptr)_2)->base + 40);
    Ref(_22531);
    _22532 = _56or_type(_22531, _etype_42082);
    _22531 = NOVALUE;
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = _22532;
    if( _1 != _22532 ){
        DeRef(_1);
    }
    _22532 = NOVALUE;

    /** 					if val[MIN] != -1 then*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22533 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _22533, -1)){
        _22533 = NOVALUE;
        goto L16; // [535] 823
    }
    _22533 = NOVALUE;

    /** 						if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_42088);
    _22535 = (int)*(((s1_ptr)_2)->base + 39);
    if (IS_ATOM_INT(_26NOVALUE_11836)) {
        if ((unsigned long)_26NOVALUE_11836 == 0xC0000000)
        _22536 = (int)NewDouble((double)-0xC0000000);
        else
        _22536 = - _26NOVALUE_11836;
    }
    else {
        _22536 = unary_op(UMINUS, _26NOVALUE_11836);
    }
    if (binary_op_a(NOTEQ, _22535, _22536)){
        _22535 = NOVALUE;
        DeRef(_22536);
        _22536 = NOVALUE;
        goto L17; // [552] 599
    }
    _22535 = NOVALUE;
    DeRef(_22536);
    _22536 = NOVALUE;

    /** 							if val[MIN] < 0 then*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22538 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22538, 0)){
        _22538 = NOVALUE;
        goto L18; // [564] 581
    }
    _22538 = NOVALUE;

    /** 								sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
    goto L16; // [578] 823
L18: 

    /** 								sym[S_SEQ_LEN_NEW] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22540 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22540);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _22540;
    if( _1 != _22540 ){
        DeRef(_1);
    }
    _22540 = NOVALUE;
    goto L16; // [596] 823
L17: 

    /** 						elsif val[MIN] != sym[S_SEQ_LEN_NEW] then*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22541 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_sym_42088);
    _22542 = (int)*(((s1_ptr)_2)->base + 39);
    if (binary_op_a(EQUALS, _22541, _22542)){
        _22541 = NOVALUE;
        _22542 = NOVALUE;
        goto L16; // [613] 823
    }
    _22541 = NOVALUE;
    _22542 = NOVALUE;

    /** 							sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
    goto L16; // [630] 823
L15: 

    /** 				elsif t = TYPE_INTEGER then*/
    if (_t_42080 != 1)
    goto L19; // [637] 774

    /** 					if sym[S_OBJ_MIN_NEW] = -NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_42088);
    _22545 = (int)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_26NOVALUE_11836)) {
        if ((unsigned long)_26NOVALUE_11836 == 0xC0000000)
        _22546 = (int)NewDouble((double)-0xC0000000);
        else
        _22546 = - _26NOVALUE_11836;
    }
    else {
        _22546 = unary_op(UMINUS, _26NOVALUE_11836);
    }
    if (binary_op_a(NOTEQ, _22545, _22546)){
        _22545 = NOVALUE;
        DeRef(_22546);
        _22546 = NOVALUE;
        goto L1A; // [654] 689
    }
    _22545 = NOVALUE;
    DeRef(_22546);
    _22546 = NOVALUE;

    /** 						sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22548 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22548);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _22548;
    if( _1 != _22548 ){
        DeRef(_1);
    }
    _22548 = NOVALUE;

    /** 						sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22549 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_22549);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 42);
    _1 = *(int *)_2;
    *(int *)_2 = _22549;
    if( _1 != _22549 ){
        DeRef(_1);
    }
    _22549 = NOVALUE;
    goto L16; // [686] 823
L1A: 

    /** 					elsif sym[S_OBJ_MIN_NEW] != NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_42088);
    _22550 = (int)*(((s1_ptr)_2)->base + 41);
    if (binary_op_a(EQUALS, _22550, _26NOVALUE_11836)){
        _22550 = NOVALUE;
        goto L16; // [699] 823
    }
    _22550 = NOVALUE;

    /** 						if val[MIN] < sym[S_OBJ_MIN_NEW] then*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22552 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_sym_42088);
    _22553 = (int)*(((s1_ptr)_2)->base + 41);
    if (binary_op_a(GREATEREQ, _22552, _22553)){
        _22552 = NOVALUE;
        _22553 = NOVALUE;
        goto L1B; // [717] 736
    }
    _22552 = NOVALUE;
    _22553 = NOVALUE;

    /** 							sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22555 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22555);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _22555;
    if( _1 != _22555 ){
        DeRef(_1);
    }
    _22555 = NOVALUE;
L1B: 

    /** 						if val[MAX] > sym[S_OBJ_MAX_NEW] then*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22556 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_sym_42088);
    _22557 = (int)*(((s1_ptr)_2)->base + 42);
    if (binary_op_a(LESSEQ, _22556, _22557)){
        _22556 = NOVALUE;
        _22557 = NOVALUE;
        goto L16; // [750] 823
    }
    _22556 = NOVALUE;
    _22557 = NOVALUE;

    /** 							sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22559 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_22559);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 42);
    _1 = *(int *)_2;
    *(int *)_2 = _22559;
    if( _1 != _22559 ){
        DeRef(_1);
    }
    _22559 = NOVALUE;
    goto L16; // [771] 823
L19: 

    /** 					sym[S_OBJ_MIN_NEW] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);

    /** 					if t = TYPE_OBJECT then*/
    if (_t_42080 != 16)
    goto L1C; // [788] 822

    /** 						sym[S_SEQ_ELEM_NEW] =*/
    _2 = (int)SEQ_PTR(_sym_42088);
    _22561 = (int)*(((s1_ptr)_2)->base + 40);
    Ref(_22561);
    _22562 = _56or_type(_22561, _etype_42082);
    _22561 = NOVALUE;
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = _22562;
    if( _1 != _22562 ){
        DeRef(_1);
    }
    _22562 = NOVALUE;

    /** 						sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
L1C: 
L16: 
L13: 

    /** 			i = 1*/
    _i_42085 = 1;

    /** 			while i <= length(BB_info) do*/
L1D: 
    if (IS_SEQUENCE(_56BB_info_41712)){
            _22563 = SEQ_PTR(_56BB_info_41712)->length;
    }
    else {
        _22563 = 1;
    }
    if (_i_42085 > _22563)
    goto L1E; // [839] 888

    /** 				int = BB_info[i][BB_VAR]*/
    _2 = (int)SEQ_PTR(_56BB_info_41712);
    _22565 = (int)*(((s1_ptr)_2)->base + _i_42085);
    _2 = (int)SEQ_PTR(_22565);
    _int_42087 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_42087)){
        _int_42087 = (long)DBL_PTR(_int_42087)->dbl;
    }
    _22565 = NOVALUE;

    /** 				if int = s then*/
    if (_int_42087 != _s_42079)
    goto L1F; // [859] 877

    /** 					found = TRUE*/
    _found_42084 = _9TRUE_430;

    /** 					exit*/
    goto L1E; // [874] 888
L1F: 

    /** 				i += 1*/
    _i_42085 = _i_42085 + 1;

    /** 			end while*/
    goto L1D; // [885] 834
L1E: 
L12: 

    /** 		if not found then*/
    if (_found_42084 != 0)
    goto L20; // [891] 907

    /** 			BB_info = append(BB_info, repeat(0, 6))*/
    _22570 = Repeat(0, 6);
    RefDS(_22570);
    Append(&_56BB_info_41712, _56BB_info_41712, _22570);
    DeRefDS(_22570);
    _22570 = NOVALUE;
L20: 

    /** 		if t = TYPE_NULL then*/
    if (_t_42080 != 0)
    goto L21; // [911] 949

    /** 			if not found then*/
    if (_found_42084 != 0)
    goto L22; // [917] 1308

    /** 				BB_info[i] = dummy_bb*/
    RefDS(_56dummy_bb_42068);
    _2 = (int)SEQ_PTR(_56BB_info_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _56BB_info_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _i_42085);
    _1 = *(int *)_2;
    *(int *)_2 = _56dummy_bb_42068;
    DeRef(_1);

    /** 				BB_info[i][BB_VAR] = s*/
    _2 = (int)SEQ_PTR(_56BB_info_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _56BB_info_41712 = MAKE_SEQ(_2);
    }
    _3 = (int)(_i_42085 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _s_42079;
    DeRef(_1);
    _22574 = NOVALUE;
    goto L22; // [946] 1308
L21: 

    /** 			sequence bbi = BB_info[i]*/
    DeRef(_bbi_42304);
    _2 = (int)SEQ_PTR(_56BB_info_41712);
    _bbi_42304 = (int)*(((s1_ptr)_2)->base + _i_42085);
    Ref(_bbi_42304);

    /** 			BB_info[i] = 0*/
    _2 = (int)SEQ_PTR(_56BB_info_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _56BB_info_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _i_42085);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			bbi[BB_VAR] = s*/
    _2 = (int)SEQ_PTR(_bbi_42304);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42304 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _s_42079;
    DeRef(_1);

    /** 			bbi[BB_TYPE] = t*/
    _2 = (int)SEQ_PTR(_bbi_42304);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42304 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _t_42080;
    DeRef(_1);

    /** 			bbi[BB_DELETE] = has_delete*/
    _2 = (int)SEQ_PTR(_bbi_42304);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42304 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _has_delete_42083;
    DeRef(_1);

    /** 			if t = TYPE_SEQUENCE and val[MIN] = -1 then*/
    _22577 = (_t_42080 == 8);
    if (_22577 == 0) {
        goto L23; // [995] 1077
    }
    _2 = (int)SEQ_PTR(_val_42081);
    _22579 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_22579)) {
        _22580 = (_22579 == -1);
    }
    else {
        _22580 = binary_op(EQUALS, _22579, -1);
    }
    _22579 = NOVALUE;
    if (_22580 == 0) {
        DeRef(_22580);
        _22580 = NOVALUE;
        goto L23; // [1010] 1077
    }
    else {
        if (!IS_ATOM_INT(_22580) && DBL_PTR(_22580)->dbl == 0.0){
            DeRef(_22580);
            _22580 = NOVALUE;
            goto L23; // [1010] 1077
        }
        DeRef(_22580);
        _22580 = NOVALUE;
    }
    DeRef(_22580);
    _22580 = NOVALUE;

    /** 				if found and bbi[BB_ELEM] != TYPE_NULL then*/
    if (_found_42084 == 0) {
        goto L24; // [1015] 1051
    }
    _2 = (int)SEQ_PTR(_bbi_42304);
    _22582 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_22582)) {
        _22583 = (_22582 != 0);
    }
    else {
        _22583 = binary_op(NOTEQ, _22582, 0);
    }
    _22582 = NOVALUE;
    if (_22583 == 0) {
        DeRef(_22583);
        _22583 = NOVALUE;
        goto L24; // [1030] 1051
    }
    else {
        if (!IS_ATOM_INT(_22583) && DBL_PTR(_22583)->dbl == 0.0){
            DeRef(_22583);
            _22583 = NOVALUE;
            goto L24; // [1030] 1051
        }
        DeRef(_22583);
        _22583 = NOVALUE;
    }
    DeRef(_22583);
    _22583 = NOVALUE;

    /** 					bbi[BB_ELEM] = or_type(bbi[BB_ELEM], etype)*/
    _2 = (int)SEQ_PTR(_bbi_42304);
    _22584 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_22584);
    _22585 = _56or_type(_22584, _etype_42082);
    _22584 = NOVALUE;
    _2 = (int)SEQ_PTR(_bbi_42304);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42304 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _22585;
    if( _1 != _22585 ){
        DeRef(_1);
    }
    _22585 = NOVALUE;
    goto L25; // [1048] 1060
L24: 

    /** 					bbi[BB_ELEM] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_bbi_42304);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42304 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
L25: 

    /** 				if not found then*/
    if (_found_42084 != 0)
    goto L26; // [1062] 1153

    /** 					bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_bbi_42304);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42304 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
    goto L26; // [1074] 1153
L23: 

    /** 				bbi[BB_ELEM] = etype*/
    _2 = (int)SEQ_PTR(_bbi_42304);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42304 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _etype_42082;
    DeRef(_1);

    /** 				if t = TYPE_SEQUENCE or t = TYPE_OBJECT then*/
    _22587 = (_t_42080 == 8);
    if (_22587 != 0) {
        goto L27; // [1091] 1106
    }
    _22589 = (_t_42080 == 16);
    if (_22589 == 0)
    {
        DeRef(_22589);
        _22589 = NOVALUE;
        goto L28; // [1102] 1145
    }
    else{
        DeRef(_22589);
        _22589 = NOVALUE;
    }
L27: 

    /** 					if val[MIN] < 0 then*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22590 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22590, 0)){
        _22590 = NOVALUE;
        goto L29; // [1114] 1129
    }
    _22590 = NOVALUE;

    /** 						bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_bbi_42304);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42304 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
    goto L2A; // [1126] 1152
L29: 

    /** 						bbi[BB_SEQLEN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22592 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22592);
    _2 = (int)SEQ_PTR(_bbi_42304);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42304 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _22592;
    if( _1 != _22592 ){
        DeRef(_1);
    }
    _22592 = NOVALUE;
    goto L2A; // [1142] 1152
L28: 

    /** 					bbi[BB_OBJ] = val*/
    RefDS(_val_42081);
    _2 = (int)SEQ_PTR(_bbi_42304);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_42304 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _val_42081;
    DeRef(_1);
L2A: 
L26: 

    /** 			BB_info[i] = bbi*/
    RefDS(_bbi_42304);
    _2 = (int)SEQ_PTR(_56BB_info_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _56BB_info_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _i_42085);
    _1 = *(int *)_2;
    *(int *)_2 = _bbi_42304;
    DeRef(_1);
    DeRefDS(_bbi_42304);
    _bbi_42304 = NOVALUE;
    goto L22; // [1164] 1308
L3: 

    /** 	elsif mode = M_CONSTANT then*/
    if (_mode_42093 != 2)
    goto L2B; // [1171] 1307

    /** 		sym[S_GTYPE] = t*/
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _t_42080;
    DeRef(_1);

    /** 		sym[S_SEQ_ELEM] = etype*/
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _etype_42082;
    DeRef(_1);

    /** 		if sym[S_GTYPE] = TYPE_SEQUENCE or*/
    _2 = (int)SEQ_PTR(_sym_42088);
    _22594 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22594)) {
        _22595 = (_22594 == 8);
    }
    else {
        _22595 = binary_op(EQUALS, _22594, 8);
    }
    _22594 = NOVALUE;
    if (IS_ATOM_INT(_22595)) {
        if (_22595 != 0) {
            goto L2C; // [1205] 1226
        }
    }
    else {
        if (DBL_PTR(_22595)->dbl != 0.0) {
            goto L2C; // [1205] 1226
        }
    }
    _2 = (int)SEQ_PTR(_sym_42088);
    _22597 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22597)) {
        _22598 = (_22597 == 16);
    }
    else {
        _22598 = binary_op(EQUALS, _22597, 16);
    }
    _22597 = NOVALUE;
    if (_22598 == 0) {
        DeRef(_22598);
        _22598 = NOVALUE;
        goto L2D; // [1222] 1269
    }
    else {
        if (!IS_ATOM_INT(_22598) && DBL_PTR(_22598)->dbl == 0.0){
            DeRef(_22598);
            _22598 = NOVALUE;
            goto L2D; // [1222] 1269
        }
        DeRef(_22598);
        _22598 = NOVALUE;
    }
    DeRef(_22598);
    _22598 = NOVALUE;
L2C: 

    /** 			if val[MIN] < 0 then*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22599 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22599, 0)){
        _22599 = NOVALUE;
        goto L2E; // [1234] 1251
    }
    _22599 = NOVALUE;

    /** 				sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
    goto L2F; // [1248] 1298
L2E: 

    /** 				sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22601 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22601);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _22601;
    if( _1 != _22601 ){
        DeRef(_1);
    }
    _22601 = NOVALUE;
    goto L2F; // [1266] 1298
L2D: 

    /** 			sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22602 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22602);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _22602;
    if( _1 != _22602 ){
        DeRef(_1);
    }
    _22602 = NOVALUE;

    /** 			sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (int)SEQ_PTR(_val_42081);
    _22603 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_22603);
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _22603;
    if( _1 != _22603 ){
        DeRef(_1);
    }
    _22603 = NOVALUE;
L2F: 

    /** 		sym[S_HAS_DELETE] = has_delete*/
    _2 = (int)SEQ_PTR(_sym_42088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 54);
    _1 = *(int *)_2;
    *(int *)_2 = _has_delete_42083;
    DeRef(_1);
L2B: 
L22: 

    /** 	SymTab[s] = sym*/
    RefDS(_sym_42088);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _s_42079);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_42088;
    DeRef(_1);

    /** end procedure*/
    DeRefDS(_val_42081);
    DeRefDS(_sym_42088);
    DeRef(_22492);
    _22492 = NOVALUE;
    DeRef(_22497);
    _22497 = NOVALUE;
    _22506 = NOVALUE;
    _22511 = NOVALUE;
    DeRef(_22577);
    _22577 = NOVALUE;
    DeRef(_22587);
    _22587 = NOVALUE;
    DeRef(_22595);
    _22595 = NOVALUE;
    return;
    ;
}


void _56CName(int _s_42378)
{
    int _v_42379 = NOVALUE;
    int _mode_42381 = NOVALUE;
    int _22664 = NOVALUE;
    int _22663 = NOVALUE;
    int _22662 = NOVALUE;
    int _22661 = NOVALUE;
    int _22660 = NOVALUE;
    int _22659 = NOVALUE;
    int _22658 = NOVALUE;
    int _22657 = NOVALUE;
    int _22656 = NOVALUE;
    int _22655 = NOVALUE;
    int _22653 = NOVALUE;
    int _22651 = NOVALUE;
    int _22650 = NOVALUE;
    int _22649 = NOVALUE;
    int _22648 = NOVALUE;
    int _22647 = NOVALUE;
    int _22646 = NOVALUE;
    int _22645 = NOVALUE;
    int _22644 = NOVALUE;
    int _22643 = NOVALUE;
    int _22642 = NOVALUE;
    int _22641 = NOVALUE;
    int _22639 = NOVALUE;
    int _22638 = NOVALUE;
    int _22637 = NOVALUE;
    int _22636 = NOVALUE;
    int _22635 = NOVALUE;
    int _22634 = NOVALUE;
    int _22632 = NOVALUE;
    int _22631 = NOVALUE;
    int _22629 = NOVALUE;
    int _22628 = NOVALUE;
    int _22627 = NOVALUE;
    int _22626 = NOVALUE;
    int _22625 = NOVALUE;
    int _22624 = NOVALUE;
    int _22623 = NOVALUE;
    int _22622 = NOVALUE;
    int _22621 = NOVALUE;
    int _22620 = NOVALUE;
    int _22619 = NOVALUE;
    int _22618 = NOVALUE;
    int _22616 = NOVALUE;
    int _22615 = NOVALUE;
    int _22613 = NOVALUE;
    int _22612 = NOVALUE;
    int _22611 = NOVALUE;
    int _22610 = NOVALUE;
    int _22609 = NOVALUE;
    int _22608 = NOVALUE;
    int _22605 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_42378)) {
        _1 = (long)(DBL_PTR(_s_42378)->dbl);
        DeRefDS(_s_42378);
        _s_42378 = _1;
    }

    /** 	v = ObjValue(s)*/
    _0 = _v_42379;
    _v_42379 = _56ObjValue(_s_42378);
    DeRef(_0);

    /** 	integer mode = SymTab[s][S_MODE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22605 = (int)*(((s1_ptr)_2)->base + _s_42378);
    _2 = (int)SEQ_PTR(_22605);
    _mode_42381 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_42381)){
        _mode_42381 = (long)DBL_PTR(_mode_42381)->dbl;
    }
    _22605 = NOVALUE;

    /**  	if mode = M_NORMAL then*/
    if (_mode_42381 != 1)
    goto L1; // [29] 240

    /** 		if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22608 = (_56LeftSym_41713 == _9FALSE_428);
    if (_22608 == 0) {
        _22609 = 0;
        goto L2; // [43] 61
    }
    _22610 = _56GType(_s_42378);
    if (IS_ATOM_INT(_22610)) {
        _22611 = (_22610 == 1);
    }
    else {
        _22611 = binary_op(EQUALS, _22610, 1);
    }
    DeRef(_22610);
    _22610 = NOVALUE;
    if (IS_ATOM_INT(_22611))
    _22609 = (_22611 != 0);
    else
    _22609 = DBL_PTR(_22611)->dbl != 0.0;
L2: 
    if (_22609 == 0) {
        goto L3; // [61] 84
    }
    if (IS_ATOM_INT(_v_42379) && IS_ATOM_INT(_26NOVALUE_11836)) {
        _22613 = (_v_42379 != _26NOVALUE_11836);
    }
    else {
        _22613 = binary_op(NOTEQ, _v_42379, _26NOVALUE_11836);
    }
    if (_22613 == 0) {
        DeRef(_22613);
        _22613 = NOVALUE;
        goto L3; // [72] 84
    }
    else {
        if (!IS_ATOM_INT(_22613) && DBL_PTR(_22613)->dbl == 0.0){
            DeRef(_22613);
            _22613 = NOVALUE;
            goto L3; // [72] 84
        }
        DeRef(_22613);
        _22613 = NOVALUE;
    }
    DeRef(_22613);
    _22613 = NOVALUE;

    /** 			c_printf("%d", v)*/
    RefDS(_22614);
    Ref(_v_42379);
    _53c_printf(_22614, _v_42379);
    goto L4; // [81] 166
L3: 

    /** 			if SymTab[s][S_SCOPE] > SC_PRIVATE then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22615 = (int)*(((s1_ptr)_2)->base + _s_42378);
    _2 = (int)SEQ_PTR(_22615);
    _22616 = (int)*(((s1_ptr)_2)->base + 4);
    _22615 = NOVALUE;
    if (binary_op_a(LESSEQ, _22616, 3)){
        _22616 = NOVALUE;
        goto L5; // [100] 142
    }
    _22616 = NOVALUE;

    /** 				c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22618 = (int)*(((s1_ptr)_2)->base + _s_42378);
    _2 = (int)SEQ_PTR(_22618);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _22619 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _22619 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _22618 = NOVALUE;
    RefDS(_22130);
    Ref(_22619);
    _53c_printf(_22130, _22619);
    _22619 = NOVALUE;

    /** 				c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22620 = (int)*(((s1_ptr)_2)->base + _s_42378);
    _2 = (int)SEQ_PTR(_22620);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _22621 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _22621 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _22620 = NOVALUE;
    Ref(_22621);
    _53c_puts(_22621);
    _22621 = NOVALUE;
    goto L6; // [139] 165
L5: 

    /** 				c_puts("_")*/
    RefDS(_22109);
    _53c_puts(_22109);

    /** 				c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22622 = (int)*(((s1_ptr)_2)->base + _s_42378);
    _2 = (int)SEQ_PTR(_22622);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _22623 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _22623 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _22622 = NOVALUE;
    Ref(_22623);
    _53c_puts(_22623);
    _22623 = NOVALUE;
L6: 
L4: 

    /** 		if s != CurrentSub and SymTab[s][S_NREFS] < 2 then*/
    _22624 = (_s_42378 != _26CurrentSub_11990);
    if (_22624 == 0) {
        goto L7; // [174] 222
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22626 = (int)*(((s1_ptr)_2)->base + _s_42378);
    _2 = (int)SEQ_PTR(_22626);
    _22627 = (int)*(((s1_ptr)_2)->base + 12);
    _22626 = NOVALUE;
    if (IS_ATOM_INT(_22627)) {
        _22628 = (_22627 < 2);
    }
    else {
        _22628 = binary_op(LESS, _22627, 2);
    }
    _22627 = NOVALUE;
    if (_22628 == 0) {
        DeRef(_22628);
        _22628 = NOVALUE;
        goto L7; // [195] 222
    }
    else {
        if (!IS_ATOM_INT(_22628) && DBL_PTR(_22628)->dbl == 0.0){
            DeRef(_22628);
            _22628 = NOVALUE;
            goto L7; // [195] 222
        }
        DeRef(_22628);
        _22628 = NOVALUE;
    }
    DeRef(_22628);
    _22628 = NOVALUE;

    /** 			SymTab[s][S_NREFS] += 1*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_42378 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _22631 = (int)*(((s1_ptr)_2)->base + 12);
    _22629 = NOVALUE;
    if (IS_ATOM_INT(_22631)) {
        _22632 = _22631 + 1;
        if (_22632 > MAXINT){
            _22632 = NewDouble((double)_22632);
        }
    }
    else
    _22632 = binary_op(PLUS, 1, _22631);
    _22631 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _22632;
    if( _1 != _22632 ){
        DeRef(_1);
    }
    _22632 = NOVALUE;
    _22629 = NOVALUE;
L7: 

    /** 		SetBBType(s, TYPE_NULL, novalue, TYPE_OBJECT, 0) -- record that this var was referenced in this BB*/
    RefDS(_53novalue_45534);
    _56SetBBType(_s_42378, 0, _53novalue_45534, 16, 0);
    goto L8; // [237] 490
L1: 

    /**  	elsif mode = M_CONSTANT then*/
    if (_mode_42381 != 2)
    goto L9; // [244] 419

    /** 		if (integer( sym_obj( s ) ) and SymTab[s][S_GTYPE] != TYPE_DOUBLE ) or (LeftSym = FALSE and TypeIs(s, TYPE_INTEGER) and v != NOVALUE) then*/
    _22634 = _52sym_obj(_s_42378);
    if (IS_ATOM_INT(_22634))
    _22635 = 1;
    else if (IS_ATOM_DBL(_22634))
    _22635 = IS_ATOM_INT(DoubleToInt(_22634));
    else
    _22635 = 0;
    DeRef(_22634);
    _22634 = NOVALUE;
    if (_22635 == 0) {
        _22636 = 0;
        goto LA; // [257] 283
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22637 = (int)*(((s1_ptr)_2)->base + _s_42378);
    _2 = (int)SEQ_PTR(_22637);
    _22638 = (int)*(((s1_ptr)_2)->base + 36);
    _22637 = NOVALUE;
    if (IS_ATOM_INT(_22638)) {
        _22639 = (_22638 != 2);
    }
    else {
        _22639 = binary_op(NOTEQ, _22638, 2);
    }
    _22638 = NOVALUE;
    if (IS_ATOM_INT(_22639))
    _22636 = (_22639 != 0);
    else
    _22636 = DBL_PTR(_22639)->dbl != 0.0;
LA: 
    if (_22636 != 0) {
        goto LB; // [283] 329
    }
    _22641 = (_56LeftSym_41713 == _9FALSE_428);
    if (_22641 == 0) {
        _22642 = 0;
        goto LC; // [295] 310
    }
    _22643 = _56TypeIs(_s_42378, 1);
    if (IS_ATOM_INT(_22643))
    _22642 = (_22643 != 0);
    else
    _22642 = DBL_PTR(_22643)->dbl != 0.0;
LC: 
    if (_22642 == 0) {
        DeRef(_22644);
        _22644 = 0;
        goto LD; // [310] 324
    }
    if (IS_ATOM_INT(_v_42379) && IS_ATOM_INT(_26NOVALUE_11836)) {
        _22645 = (_v_42379 != _26NOVALUE_11836);
    }
    else {
        _22645 = binary_op(NOTEQ, _v_42379, _26NOVALUE_11836);
    }
    if (IS_ATOM_INT(_22645))
    _22644 = (_22645 != 0);
    else
    _22644 = DBL_PTR(_22645)->dbl != 0.0;
LD: 
    if (_22644 == 0)
    {
        _22644 = NOVALUE;
        goto LE; // [325] 338
    }
    else{
        _22644 = NOVALUE;
    }
LB: 

    /** 			c_printf("%d", v)*/
    RefDS(_22614);
    Ref(_v_42379);
    _53c_printf(_22614, _v_42379);
    goto L8; // [335] 490
LE: 

    /** 			c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22646 = (int)*(((s1_ptr)_2)->base + _s_42378);
    _2 = (int)SEQ_PTR(_22646);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _22647 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _22647 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _22646 = NOVALUE;
    RefDS(_22130);
    Ref(_22647);
    _53c_printf(_22130, _22647);
    _22647 = NOVALUE;

    /** 			c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22648 = (int)*(((s1_ptr)_2)->base + _s_42378);
    _2 = (int)SEQ_PTR(_22648);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _22649 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _22649 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _22648 = NOVALUE;
    Ref(_22649);
    _53c_puts(_22649);
    _22649 = NOVALUE;

    /** 			if SymTab[s][S_NREFS] < 2 then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22650 = (int)*(((s1_ptr)_2)->base + _s_42378);
    _2 = (int)SEQ_PTR(_22650);
    _22651 = (int)*(((s1_ptr)_2)->base + 12);
    _22650 = NOVALUE;
    if (binary_op_a(GREATEREQ, _22651, 2)){
        _22651 = NOVALUE;
        goto L8; // [387] 490
    }
    _22651 = NOVALUE;

    /** 				SymTab[s][S_NREFS] += 1*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_42378 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _22655 = (int)*(((s1_ptr)_2)->base + 12);
    _22653 = NOVALUE;
    if (IS_ATOM_INT(_22655)) {
        _22656 = _22655 + 1;
        if (_22656 > MAXINT){
            _22656 = NewDouble((double)_22656);
        }
    }
    else
    _22656 = binary_op(PLUS, 1, _22655);
    _22655 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _22656;
    if( _1 != _22656 ){
        DeRef(_1);
    }
    _22656 = NOVALUE;
    _22653 = NOVALUE;
    goto L8; // [416] 490
L9: 

    /** 		if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22657 = (_56LeftSym_41713 == _9FALSE_428);
    if (_22657 == 0) {
        _22658 = 0;
        goto LF; // [429] 447
    }
    _22659 = _56GType(_s_42378);
    if (IS_ATOM_INT(_22659)) {
        _22660 = (_22659 == 1);
    }
    else {
        _22660 = binary_op(EQUALS, _22659, 1);
    }
    DeRef(_22659);
    _22659 = NOVALUE;
    if (IS_ATOM_INT(_22660))
    _22658 = (_22660 != 0);
    else
    _22658 = DBL_PTR(_22660)->dbl != 0.0;
LF: 
    if (_22658 == 0) {
        goto L10; // [447] 470
    }
    if (IS_ATOM_INT(_v_42379) && IS_ATOM_INT(_26NOVALUE_11836)) {
        _22662 = (_v_42379 != _26NOVALUE_11836);
    }
    else {
        _22662 = binary_op(NOTEQ, _v_42379, _26NOVALUE_11836);
    }
    if (_22662 == 0) {
        DeRef(_22662);
        _22662 = NOVALUE;
        goto L10; // [458] 470
    }
    else {
        if (!IS_ATOM_INT(_22662) && DBL_PTR(_22662)->dbl == 0.0){
            DeRef(_22662);
            _22662 = NOVALUE;
            goto L10; // [458] 470
        }
        DeRef(_22662);
        _22662 = NOVALUE;
    }
    DeRef(_22662);
    _22662 = NOVALUE;

    /** 			c_printf("%d", v)*/
    RefDS(_22614);
    Ref(_v_42379);
    _53c_printf(_22614, _v_42379);
    goto L11; // [467] 489
L10: 

    /** 			c_printf("_%d", SymTab[s][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22663 = (int)*(((s1_ptr)_2)->base + _s_42378);
    _2 = (int)SEQ_PTR(_22663);
    _22664 = (int)*(((s1_ptr)_2)->base + 34);
    _22663 = NOVALUE;
    RefDS(_22130);
    Ref(_22664);
    _53c_printf(_22130, _22664);
    _22664 = NOVALUE;
L11: 
L8: 

    /** 	LeftSym = FALSE*/
    _56LeftSym_41713 = _9FALSE_428;

    /** end procedure*/
    DeRef(_v_42379);
    DeRef(_22608);
    _22608 = NOVALUE;
    DeRef(_22624);
    _22624 = NOVALUE;
    DeRef(_22611);
    _22611 = NOVALUE;
    DeRef(_22641);
    _22641 = NOVALUE;
    DeRef(_22639);
    _22639 = NOVALUE;
    DeRef(_22643);
    _22643 = NOVALUE;
    DeRef(_22645);
    _22645 = NOVALUE;
    DeRef(_22657);
    _22657 = NOVALUE;
    DeRef(_22660);
    _22660 = NOVALUE;
    return;
    ;
}


void _56c_stmt(int _stmt_42512, int _arg_42513, int _lhs_arg_42515)
{
    int _argcount_42516 = NOVALUE;
    int _i_42517 = NOVALUE;
    int _22719 = NOVALUE;
    int _22718 = NOVALUE;
    int _22717 = NOVALUE;
    int _22716 = NOVALUE;
    int _22715 = NOVALUE;
    int _22714 = NOVALUE;
    int _22713 = NOVALUE;
    int _22712 = NOVALUE;
    int _22711 = NOVALUE;
    int _22710 = NOVALUE;
    int _22709 = NOVALUE;
    int _22708 = NOVALUE;
    int _22707 = NOVALUE;
    int _22706 = NOVALUE;
    int _22705 = NOVALUE;
    int _22704 = NOVALUE;
    int _22703 = NOVALUE;
    int _22701 = NOVALUE;
    int _22699 = NOVALUE;
    int _22697 = NOVALUE;
    int _22696 = NOVALUE;
    int _22695 = NOVALUE;
    int _22694 = NOVALUE;
    int _22692 = NOVALUE;
    int _22691 = NOVALUE;
    int _22690 = NOVALUE;
    int _22689 = NOVALUE;
    int _22688 = NOVALUE;
    int _22687 = NOVALUE;
    int _22686 = NOVALUE;
    int _22685 = NOVALUE;
    int _22684 = NOVALUE;
    int _22683 = NOVALUE;
    int _22682 = NOVALUE;
    int _22681 = NOVALUE;
    int _22680 = NOVALUE;
    int _22679 = NOVALUE;
    int _22676 = NOVALUE;
    int _22675 = NOVALUE;
    int _22674 = NOVALUE;
    int _22673 = NOVALUE;
    int _22672 = NOVALUE;
    int _22671 = NOVALUE;
    int _22669 = NOVALUE;
    int _22667 = NOVALUE;
    int _22666 = NOVALUE;
    int _22665 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_lhs_arg_42515)) {
        _1 = (long)(DBL_PTR(_lhs_arg_42515)->dbl);
        DeRefDS(_lhs_arg_42515);
        _lhs_arg_42515 = _1;
    }

    /** 	if LAST_PASS = TRUE and Initializing = FALSE then*/
    _22665 = (_56LAST_PASS_41703 == _9TRUE_430);
    if (_22665 == 0) {
        goto L1; // [15] 47
    }
    _22667 = (_26Initializing_12063 == _9FALSE_428);
    if (_22667 == 0)
    {
        DeRef(_22667);
        _22667 = NOVALUE;
        goto L1; // [28] 47
    }
    else{
        DeRef(_22667);
        _22667 = NOVALUE;
    }

    /** 		cfile_size += 1*/
    _26cfile_size_12062 = _26cfile_size_12062 + 1;

    /** 		update_checksum( stmt )*/
    RefDS(_stmt_42512);
    _54update_checksum(_stmt_42512);
L1: 

    /** 	if emit_c_output then*/
    if (_53emit_c_output_45527 == 0)
    {
        goto L2; // [51] 60
    }
    else{
    }

    /** 		adjust_indent_before(stmt)*/
    RefDS(_stmt_42512);
    _53adjust_indent_before(_stmt_42512);
L2: 

    /** 	if atom(arg) then*/
    _22669 = IS_ATOM(_arg_42513);
    if (_22669 == 0)
    {
        _22669 = NOVALUE;
        goto L3; // [65] 75
    }
    else{
        _22669 = NOVALUE;
    }

    /** 		arg = {arg}*/
    _0 = _arg_42513;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_arg_42513);
    *((int *)(_2+4)) = _arg_42513;
    _arg_42513 = MAKE_SEQ(_1);
    DeRef(_0);
L3: 

    /** 	argcount = 1*/
    _argcount_42516 = 1;

    /** 	i = 1*/
    _i_42517 = 1;

    /** 	while i <= length(stmt) and length(stmt) > 0 do*/
L4: 
    if (IS_SEQUENCE(_stmt_42512)){
            _22671 = SEQ_PTR(_stmt_42512)->length;
    }
    else {
        _22671 = 1;
    }
    _22672 = (_i_42517 <= _22671);
    _22671 = NOVALUE;
    if (_22672 == 0) {
        goto L5; // [97] 435
    }
    if (IS_SEQUENCE(_stmt_42512)){
            _22674 = SEQ_PTR(_stmt_42512)->length;
    }
    else {
        _22674 = 1;
    }
    _22675 = (_22674 > 0);
    _22674 = NOVALUE;
    if (_22675 == 0)
    {
        DeRef(_22675);
        _22675 = NOVALUE;
        goto L5; // [109] 435
    }
    else{
        DeRef(_22675);
        _22675 = NOVALUE;
    }

    /** 		if stmt[i] = '@' then*/
    _2 = (int)SEQ_PTR(_stmt_42512);
    _22676 = (int)*(((s1_ptr)_2)->base + _i_42517);
    if (binary_op_a(NOTEQ, _22676, 64)){
        _22676 = NOVALUE;
        goto L6; // [118] 288
    }
    _22676 = NOVALUE;

    /** 			if i = 1 then*/
    if (_i_42517 != 1)
    goto L7; // [124] 138

    /** 				LeftSym = TRUE*/
    _56LeftSym_41713 = _9TRUE_430;
L7: 

    /** 			if i < length(stmt) and stmt[i+1] > '0' and stmt[i+1] <= '9' then*/
    if (IS_SEQUENCE(_stmt_42512)){
            _22679 = SEQ_PTR(_stmt_42512)->length;
    }
    else {
        _22679 = 1;
    }
    _22680 = (_i_42517 < _22679);
    _22679 = NOVALUE;
    if (_22680 == 0) {
        _22681 = 0;
        goto L8; // [147] 167
    }
    _22682 = _i_42517 + 1;
    _2 = (int)SEQ_PTR(_stmt_42512);
    _22683 = (int)*(((s1_ptr)_2)->base + _22682);
    if (IS_ATOM_INT(_22683)) {
        _22684 = (_22683 > 48);
    }
    else {
        _22684 = binary_op(GREATER, _22683, 48);
    }
    _22683 = NOVALUE;
    if (IS_ATOM_INT(_22684))
    _22681 = (_22684 != 0);
    else
    _22681 = DBL_PTR(_22684)->dbl != 0.0;
L8: 
    if (_22681 == 0) {
        goto L9; // [167] 249
    }
    _22686 = _i_42517 + 1;
    _2 = (int)SEQ_PTR(_stmt_42512);
    _22687 = (int)*(((s1_ptr)_2)->base + _22686);
    if (IS_ATOM_INT(_22687)) {
        _22688 = (_22687 <= 57);
    }
    else {
        _22688 = binary_op(LESSEQ, _22687, 57);
    }
    _22687 = NOVALUE;
    if (_22688 == 0) {
        DeRef(_22688);
        _22688 = NOVALUE;
        goto L9; // [184] 249
    }
    else {
        if (!IS_ATOM_INT(_22688) && DBL_PTR(_22688)->dbl == 0.0){
            DeRef(_22688);
            _22688 = NOVALUE;
            goto L9; // [184] 249
        }
        DeRef(_22688);
        _22688 = NOVALUE;
    }
    DeRef(_22688);
    _22688 = NOVALUE;

    /** 				if arg[stmt[i+1]-'0'] = lhs_arg then*/
    _22689 = _i_42517 + 1;
    _2 = (int)SEQ_PTR(_stmt_42512);
    _22690 = (int)*(((s1_ptr)_2)->base + _22689);
    if (IS_ATOM_INT(_22690)) {
        _22691 = _22690 - 48;
    }
    else {
        _22691 = binary_op(MINUS, _22690, 48);
    }
    _22690 = NOVALUE;
    _2 = (int)SEQ_PTR(_arg_42513);
    if (!IS_ATOM_INT(_22691)){
        _22692 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22691)->dbl));
    }
    else{
        _22692 = (int)*(((s1_ptr)_2)->base + _22691);
    }
    if (binary_op_a(NOTEQ, _22692, _lhs_arg_42515)){
        _22692 = NOVALUE;
        goto LA; // [205] 219
    }
    _22692 = NOVALUE;

    /** 					LeftSym = TRUE*/
    _56LeftSym_41713 = _9TRUE_430;
LA: 

    /** 				CName(arg[stmt[i+1]-'0'])*/
    _22694 = _i_42517 + 1;
    _2 = (int)SEQ_PTR(_stmt_42512);
    _22695 = (int)*(((s1_ptr)_2)->base + _22694);
    if (IS_ATOM_INT(_22695)) {
        _22696 = _22695 - 48;
    }
    else {
        _22696 = binary_op(MINUS, _22695, 48);
    }
    _22695 = NOVALUE;
    _2 = (int)SEQ_PTR(_arg_42513);
    if (!IS_ATOM_INT(_22696)){
        _22697 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22696)->dbl));
    }
    else{
        _22697 = (int)*(((s1_ptr)_2)->base + _22696);
    }
    Ref(_22697);
    _56CName(_22697);
    _22697 = NOVALUE;

    /** 				i += 1*/
    _i_42517 = _i_42517 + 1;
    goto LB; // [246] 279
L9: 

    /** 				if arg[argcount] = lhs_arg then*/
    _2 = (int)SEQ_PTR(_arg_42513);
    _22699 = (int)*(((s1_ptr)_2)->base + _argcount_42516);
    if (binary_op_a(NOTEQ, _22699, _lhs_arg_42515)){
        _22699 = NOVALUE;
        goto LC; // [255] 269
    }
    _22699 = NOVALUE;

    /** 					LeftSym = TRUE*/
    _56LeftSym_41713 = _9TRUE_430;
LC: 

    /** 				CName(arg[argcount])*/
    _2 = (int)SEQ_PTR(_arg_42513);
    _22701 = (int)*(((s1_ptr)_2)->base + _argcount_42516);
    Ref(_22701);
    _56CName(_22701);
    _22701 = NOVALUE;
LB: 

    /** 			argcount += 1*/
    _argcount_42516 = _argcount_42516 + 1;
    goto LD; // [285] 353
L6: 

    /** 			c_putc(stmt[i])*/
    _2 = (int)SEQ_PTR(_stmt_42512);
    _22703 = (int)*(((s1_ptr)_2)->base + _i_42517);
    Ref(_22703);
    _53c_putc(_22703);
    _22703 = NOVALUE;

    /** 			if stmt[i] = '&' and i < length(stmt) and stmt[i+1] = '@' then*/
    _2 = (int)SEQ_PTR(_stmt_42512);
    _22704 = (int)*(((s1_ptr)_2)->base + _i_42517);
    if (IS_ATOM_INT(_22704)) {
        _22705 = (_22704 == 38);
    }
    else {
        _22705 = binary_op(EQUALS, _22704, 38);
    }
    _22704 = NOVALUE;
    if (IS_ATOM_INT(_22705)) {
        if (_22705 == 0) {
            DeRef(_22706);
            _22706 = 0;
            goto LE; // [307] 322
        }
    }
    else {
        if (DBL_PTR(_22705)->dbl == 0.0) {
            DeRef(_22706);
            _22706 = 0;
            goto LE; // [307] 322
        }
    }
    if (IS_SEQUENCE(_stmt_42512)){
            _22707 = SEQ_PTR(_stmt_42512)->length;
    }
    else {
        _22707 = 1;
    }
    _22708 = (_i_42517 < _22707);
    _22707 = NOVALUE;
    DeRef(_22706);
    _22706 = (_22708 != 0);
LE: 
    if (_22706 == 0) {
        goto LF; // [322] 352
    }
    _22710 = _i_42517 + 1;
    _2 = (int)SEQ_PTR(_stmt_42512);
    _22711 = (int)*(((s1_ptr)_2)->base + _22710);
    if (IS_ATOM_INT(_22711)) {
        _22712 = (_22711 == 64);
    }
    else {
        _22712 = binary_op(EQUALS, _22711, 64);
    }
    _22711 = NOVALUE;
    if (_22712 == 0) {
        DeRef(_22712);
        _22712 = NOVALUE;
        goto LF; // [339] 352
    }
    else {
        if (!IS_ATOM_INT(_22712) && DBL_PTR(_22712)->dbl == 0.0){
            DeRef(_22712);
            _22712 = NOVALUE;
            goto LF; // [339] 352
        }
        DeRef(_22712);
        _22712 = NOVALUE;
    }
    DeRef(_22712);
    _22712 = NOVALUE;

    /** 				LeftSym = TRUE -- never say: x = x &y or andy - always leave space*/
    _56LeftSym_41713 = _9TRUE_430;
LF: 
LD: 

    /** 		if stmt[i] = '\n' and i < length(stmt) then*/
    _2 = (int)SEQ_PTR(_stmt_42512);
    _22713 = (int)*(((s1_ptr)_2)->base + _i_42517);
    if (IS_ATOM_INT(_22713)) {
        _22714 = (_22713 == 10);
    }
    else {
        _22714 = binary_op(EQUALS, _22713, 10);
    }
    _22713 = NOVALUE;
    if (IS_ATOM_INT(_22714)) {
        if (_22714 == 0) {
            goto L10; // [363] 424
        }
    }
    else {
        if (DBL_PTR(_22714)->dbl == 0.0) {
            goto L10; // [363] 424
        }
    }
    if (IS_SEQUENCE(_stmt_42512)){
            _22716 = SEQ_PTR(_stmt_42512)->length;
    }
    else {
        _22716 = 1;
    }
    _22717 = (_i_42517 < _22716);
    _22716 = NOVALUE;
    if (_22717 == 0)
    {
        DeRef(_22717);
        _22717 = NOVALUE;
        goto L10; // [375] 424
    }
    else{
        DeRef(_22717);
        _22717 = NOVALUE;
    }

    /** 			if emit_c_output then*/
    if (_53emit_c_output_45527 == 0)
    {
        goto L11; // [382] 391
    }
    else{
    }

    /** 				adjust_indent_after(stmt)*/
    RefDS(_stmt_42512);
    _53adjust_indent_after(_stmt_42512);
L11: 

    /** 			stmt = stmt[i+1..$]*/
    _22718 = _i_42517 + 1;
    if (_22718 > MAXINT){
        _22718 = NewDouble((double)_22718);
    }
    if (IS_SEQUENCE(_stmt_42512)){
            _22719 = SEQ_PTR(_stmt_42512)->length;
    }
    else {
        _22719 = 1;
    }
    rhs_slice_target = (object_ptr)&_stmt_42512;
    RHS_Slice(_stmt_42512, _22718, _22719);

    /** 			i = 0*/
    _i_42517 = 0;

    /** 			if emit_c_output then*/
    if (_53emit_c_output_45527 == 0)
    {
        goto L12; // [414] 423
    }
    else{
    }

    /** 				adjust_indent_before(stmt)*/
    RefDS(_stmt_42512);
    _53adjust_indent_before(_stmt_42512);
L12: 
L10: 

    /** 		i += 1*/
    _i_42517 = _i_42517 + 1;

    /** 	end while*/
    goto L4; // [432] 90
L5: 

    /** 	if emit_c_output then*/
    if (_53emit_c_output_45527 == 0)
    {
        goto L13; // [439] 448
    }
    else{
    }

    /** 		adjust_indent_after(stmt)*/
    RefDS(_stmt_42512);
    _53adjust_indent_after(_stmt_42512);
L13: 

    /** end procedure*/
    DeRefDS(_stmt_42512);
    DeRef(_arg_42513);
    DeRef(_22665);
    _22665 = NOVALUE;
    DeRef(_22672);
    _22672 = NOVALUE;
    DeRef(_22680);
    _22680 = NOVALUE;
    DeRef(_22682);
    _22682 = NOVALUE;
    DeRef(_22686);
    _22686 = NOVALUE;
    DeRef(_22684);
    _22684 = NOVALUE;
    DeRef(_22689);
    _22689 = NOVALUE;
    DeRef(_22694);
    _22694 = NOVALUE;
    DeRef(_22691);
    _22691 = NOVALUE;
    DeRef(_22708);
    _22708 = NOVALUE;
    DeRef(_22696);
    _22696 = NOVALUE;
    DeRef(_22705);
    _22705 = NOVALUE;
    DeRef(_22710);
    _22710 = NOVALUE;
    DeRef(_22718);
    _22718 = NOVALUE;
    DeRef(_22714);
    _22714 = NOVALUE;
    return;
    ;
}


void _56c_stmt0(int _stmt_42611)
{
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_53emit_c_output_45527 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** 		c_stmt(stmt, {})*/
    RefDS(_stmt_42611);
    RefDS(_22037);
    _56c_stmt(_stmt_42611, _22037, 0);
L1: 

    /** end procedure*/
    DeRefDS(_stmt_42611);
    return;
    ;
}


void _56DeclareFileVars()
{
    int _s_42617 = NOVALUE;
    int _eentry_42619 = NOVALUE;
    int _22761 = NOVALUE;
    int _22760 = NOVALUE;
    int _22759 = NOVALUE;
    int _22756 = NOVALUE;
    int _22754 = NOVALUE;
    int _22753 = NOVALUE;
    int _22752 = NOVALUE;
    int _22751 = NOVALUE;
    int _22747 = NOVALUE;
    int _22746 = NOVALUE;
    int _22745 = NOVALUE;
    int _22744 = NOVALUE;
    int _22743 = NOVALUE;
    int _22742 = NOVALUE;
    int _22741 = NOVALUE;
    int _22740 = NOVALUE;
    int _22739 = NOVALUE;
    int _22738 = NOVALUE;
    int _22737 = NOVALUE;
    int _22736 = NOVALUE;
    int _22735 = NOVALUE;
    int _22734 = NOVALUE;
    int _22733 = NOVALUE;
    int _22732 = NOVALUE;
    int _22731 = NOVALUE;
    int _22730 = NOVALUE;
    int _22729 = NOVALUE;
    int _22728 = NOVALUE;
    int _22727 = NOVALUE;
    int _22726 = NOVALUE;
    int _22723 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c_puts("// Declaring file vars\n")*/
    RefDS(_22722);
    _53c_puts(_22722);

    /** 	s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22723 = (int)*(((s1_ptr)_2)->base + _26TopLevelSub_11989);
    _2 = (int)SEQ_PTR(_22723);
    _s_42617 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42617)){
        _s_42617 = (long)DBL_PTR(_s_42617)->dbl;
    }
    _22723 = NOVALUE;

    /** 	while s do*/
L1: 
    if (_s_42617 == 0)
    {
        goto L2; // [29] 321
    }
    else{
    }

    /** 		eentry = SymTab[s]*/
    DeRef(_eentry_42619);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _eentry_42619 = (int)*(((s1_ptr)_2)->base + _s_42617);
    Ref(_eentry_42619);

    /** 		if eentry[S_SCOPE] >= SC_LOCAL*/
    _2 = (int)SEQ_PTR(_eentry_42619);
    _22726 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22726)) {
        _22727 = (_22726 >= 5);
    }
    else {
        _22727 = binary_op(GREATEREQ, _22726, 5);
    }
    _22726 = NOVALUE;
    if (IS_ATOM_INT(_22727)) {
        if (_22727 == 0) {
            DeRef(_22728);
            _22728 = 0;
            goto L3; // [56] 116
        }
    }
    else {
        if (DBL_PTR(_22727)->dbl == 0.0) {
            DeRef(_22728);
            _22728 = 0;
            goto L3; // [56] 116
        }
    }
    _2 = (int)SEQ_PTR(_eentry_42619);
    _22729 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22729)) {
        _22730 = (_22729 <= 6);
    }
    else {
        _22730 = binary_op(LESSEQ, _22729, 6);
    }
    _22729 = NOVALUE;
    if (IS_ATOM_INT(_22730)) {
        if (_22730 != 0) {
            DeRef(_22731);
            _22731 = 1;
            goto L4; // [72] 92
        }
    }
    else {
        if (DBL_PTR(_22730)->dbl != 0.0) {
            DeRef(_22731);
            _22731 = 1;
            goto L4; // [72] 92
        }
    }
    _2 = (int)SEQ_PTR(_eentry_42619);
    _22732 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22732)) {
        _22733 = (_22732 == 11);
    }
    else {
        _22733 = binary_op(EQUALS, _22732, 11);
    }
    _22732 = NOVALUE;
    DeRef(_22731);
    if (IS_ATOM_INT(_22733))
    _22731 = (_22733 != 0);
    else
    _22731 = DBL_PTR(_22733)->dbl != 0.0;
L4: 
    if (_22731 != 0) {
        _22734 = 1;
        goto L5; // [92] 112
    }
    _2 = (int)SEQ_PTR(_eentry_42619);
    _22735 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22735)) {
        _22736 = (_22735 == 13);
    }
    else {
        _22736 = binary_op(EQUALS, _22735, 13);
    }
    _22735 = NOVALUE;
    if (IS_ATOM_INT(_22736))
    _22734 = (_22736 != 0);
    else
    _22734 = DBL_PTR(_22736)->dbl != 0.0;
L5: 
    DeRef(_22728);
    _22728 = (_22734 != 0);
L3: 
    if (_22728 == 0) {
        _22737 = 0;
        goto L6; // [116] 136
    }
    _2 = (int)SEQ_PTR(_eentry_42619);
    _22738 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22738)) {
        _22739 = (_22738 != 0);
    }
    else {
        _22739 = binary_op(NOTEQ, _22738, 0);
    }
    _22738 = NOVALUE;
    if (IS_ATOM_INT(_22739))
    _22737 = (_22739 != 0);
    else
    _22737 = DBL_PTR(_22739)->dbl != 0.0;
L6: 
    if (_22737 == 0) {
        _22740 = 0;
        goto L7; // [136] 156
    }
    _2 = (int)SEQ_PTR(_eentry_42619);
    _22741 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22741)) {
        _22742 = (_22741 != 99);
    }
    else {
        _22742 = binary_op(NOTEQ, _22741, 99);
    }
    _22741 = NOVALUE;
    if (IS_ATOM_INT(_22742))
    _22740 = (_22742 != 0);
    else
    _22740 = DBL_PTR(_22742)->dbl != 0.0;
L7: 
    if (_22740 == 0) {
        goto L8; // [156] 300
    }
    _2 = (int)SEQ_PTR(_eentry_42619);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _22744 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _22744 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _22745 = find_from(_22744, _28RTN_TOKS_11602, 1);
    _22744 = NOVALUE;
    _22746 = (_22745 == 0);
    _22745 = NOVALUE;
    if (_22746 == 0)
    {
        DeRef(_22746);
        _22746 = NOVALUE;
        goto L8; // [177] 300
    }
    else{
        DeRef(_22746);
        _22746 = NOVALUE;
    }

    /** 			if eentry[S_TOKEN] = PROC then*/
    _2 = (int)SEQ_PTR(_eentry_42619);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _22747 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _22747 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    if (binary_op_a(NOTEQ, _22747, 27)){
        _22747 = NOVALUE;
        goto L9; // [190] 202
    }
    _22747 = NOVALUE;

    /** 				c_puts( "void ")*/
    RefDS(_22749);
    _53c_puts(_22749);
    goto LA; // [199] 208
L9: 

    /** 				c_puts("int ")*/
    RefDS(_22750);
    _53c_puts(_22750);
LA: 

    /** 			c_printf("_%d", eentry[S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_eentry_42619);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _22751 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _22751 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    RefDS(_22130);
    Ref(_22751);
    _53c_printf(_22130, _22751);
    _22751 = NOVALUE;

    /** 			c_puts(eentry[S_NAME])*/
    _2 = (int)SEQ_PTR(_eentry_42619);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _22752 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _22752 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    Ref(_22752);
    _53c_puts(_22752);
    _22752 = NOVALUE;

    /** 			if integer( eentry[S_OBJ] ) then*/
    _2 = (int)SEQ_PTR(_eentry_42619);
    _22753 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_22753))
    _22754 = 1;
    else if (IS_ATOM_DBL(_22753))
    _22754 = IS_ATOM_INT(DoubleToInt(_22753));
    else
    _22754 = 0;
    _22753 = NOVALUE;
    if (_22754 == 0)
    {
        _22754 = NOVALUE;
        goto LB; // [242] 260
    }
    else{
        _22754 = NOVALUE;
    }

    /** 					c_printf(" = %d;\n", eentry[S_OBJ] )*/
    _2 = (int)SEQ_PTR(_eentry_42619);
    _22756 = (int)*(((s1_ptr)_2)->base + 1);
    RefDS(_22755);
    Ref(_22756);
    _53c_printf(_22755, _22756);
    _22756 = NOVALUE;
    goto LC; // [257] 266
LB: 

    /** 				c_puts(" = NOVALUE;\n")*/
    RefDS(_22757);
    _53c_puts(_22757);
LC: 

    /** 			c_hputs("extern int ")*/
    RefDS(_22758);
    _53c_hputs(_22758);

    /** 			c_hprintf("_%d", eentry[S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_eentry_42619);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _22759 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _22759 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    RefDS(_22130);
    Ref(_22759);
    _53c_hprintf(_22130, _22759);
    _22759 = NOVALUE;

    /** 			c_hputs(eentry[S_NAME])*/
    _2 = (int)SEQ_PTR(_eentry_42619);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _22760 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _22760 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    Ref(_22760);
    _53c_hputs(_22760);
    _22760 = NOVALUE;

    /** 			c_hputs(";\n")*/
    RefDS(_22267);
    _53c_hputs(_22267);
L8: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22761 = (int)*(((s1_ptr)_2)->base + _s_42617);
    _2 = (int)SEQ_PTR(_22761);
    _s_42617 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42617)){
        _s_42617 = (long)DBL_PTR(_s_42617)->dbl;
    }
    _22761 = NOVALUE;

    /** 	end while*/
    goto L1; // [318] 29
L2: 

    /** 	c_puts("\n")*/
    RefDS(_22189);
    _53c_puts(_22189);

    /** 	c_hputs("\n")*/
    RefDS(_22189);
    _53c_hputs(_22189);

    /** end procedure*/
    DeRef(_eentry_42619);
    DeRef(_22727);
    _22727 = NOVALUE;
    DeRef(_22730);
    _22730 = NOVALUE;
    DeRef(_22733);
    _22733 = NOVALUE;
    DeRef(_22736);
    _22736 = NOVALUE;
    DeRef(_22739);
    _22739 = NOVALUE;
    DeRef(_22742);
    _22742 = NOVALUE;
    return;
    ;
}


int _56PromoteTypeInfo()
{
    int _updsym_42711 = NOVALUE;
    int _s_42713 = NOVALUE;
    int _sym_42714 = NOVALUE;
    int _symo_42715 = NOVALUE;
    int _upd_42944 = NOVALUE;
    int _22861 = NOVALUE;
    int _22859 = NOVALUE;
    int _22858 = NOVALUE;
    int _22857 = NOVALUE;
    int _22856 = NOVALUE;
    int _22854 = NOVALUE;
    int _22852 = NOVALUE;
    int _22851 = NOVALUE;
    int _22850 = NOVALUE;
    int _22849 = NOVALUE;
    int _22848 = NOVALUE;
    int _22844 = NOVALUE;
    int _22841 = NOVALUE;
    int _22840 = NOVALUE;
    int _22839 = NOVALUE;
    int _22838 = NOVALUE;
    int _22837 = NOVALUE;
    int _22836 = NOVALUE;
    int _22835 = NOVALUE;
    int _22834 = NOVALUE;
    int _22833 = NOVALUE;
    int _22832 = NOVALUE;
    int _22831 = NOVALUE;
    int _22829 = NOVALUE;
    int _22828 = NOVALUE;
    int _22827 = NOVALUE;
    int _22826 = NOVALUE;
    int _22825 = NOVALUE;
    int _22824 = NOVALUE;
    int _22823 = NOVALUE;
    int _22822 = NOVALUE;
    int _22821 = NOVALUE;
    int _22820 = NOVALUE;
    int _22818 = NOVALUE;
    int _22817 = NOVALUE;
    int _22816 = NOVALUE;
    int _22814 = NOVALUE;
    int _22813 = NOVALUE;
    int _22812 = NOVALUE;
    int _22810 = NOVALUE;
    int _22809 = NOVALUE;
    int _22808 = NOVALUE;
    int _22807 = NOVALUE;
    int _22806 = NOVALUE;
    int _22805 = NOVALUE;
    int _22804 = NOVALUE;
    int _22802 = NOVALUE;
    int _22801 = NOVALUE;
    int _22800 = NOVALUE;
    int _22799 = NOVALUE;
    int _22797 = NOVALUE;
    int _22796 = NOVALUE;
    int _22794 = NOVALUE;
    int _22793 = NOVALUE;
    int _22792 = NOVALUE;
    int _22791 = NOVALUE;
    int _22790 = NOVALUE;
    int _22789 = NOVALUE;
    int _22788 = NOVALUE;
    int _22786 = NOVALUE;
    int _22785 = NOVALUE;
    int _22784 = NOVALUE;
    int _22783 = NOVALUE;
    int _22782 = NOVALUE;
    int _22781 = NOVALUE;
    int _22780 = NOVALUE;
    int _22779 = NOVALUE;
    int _22778 = NOVALUE;
    int _22777 = NOVALUE;
    int _22776 = NOVALUE;
    int _22775 = NOVALUE;
    int _22774 = NOVALUE;
    int _22773 = NOVALUE;
    int _22771 = NOVALUE;
    int _22770 = NOVALUE;
    int _22769 = NOVALUE;
    int _22767 = NOVALUE;
    int _22766 = NOVALUE;
    int _22763 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence sym, symo*/

    /** 	updsym = 0*/
    _updsym_42711 = 0;

    /** 	g_has_delete = p_has_delete*/
    _56g_has_delete_41897 = _56p_has_delete_41898;

    /** 	s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22763 = (int)*(((s1_ptr)_2)->base + _26TopLevelSub_11989);
    _2 = (int)SEQ_PTR(_22763);
    _s_42713 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42713)){
        _s_42713 = (long)DBL_PTR(_s_42713)->dbl;
    }
    _22763 = NOVALUE;

    /** 	while s do*/
L1: 
    if (_s_42713 == 0)
    {
        goto L2; // [38] 921
    }
    else{
    }

    /** 		sym = SymTab[s]*/
    DeRef(_sym_42714);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _sym_42714 = (int)*(((s1_ptr)_2)->base + _s_42713);
    Ref(_sym_42714);

    /** 		symo = sym*/
    RefDS(_sym_42714);
    DeRef(_symo_42715);
    _symo_42715 = _sym_42714;

    /** 		if sym[S_TOKEN] = FUNC or sym[S_TOKEN] = TYPE then*/
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _22766 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _22766 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    if (IS_ATOM_INT(_22766)) {
        _22767 = (_22766 == 501);
    }
    else {
        _22767 = binary_op(EQUALS, _22766, 501);
    }
    _22766 = NOVALUE;
    if (IS_ATOM_INT(_22767)) {
        if (_22767 != 0) {
            goto L3; // [72] 93
        }
    }
    else {
        if (DBL_PTR(_22767)->dbl != 0.0) {
            goto L3; // [72] 93
        }
    }
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _22769 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _22769 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    if (IS_ATOM_INT(_22769)) {
        _22770 = (_22769 == 504);
    }
    else {
        _22770 = binary_op(EQUALS, _22769, 504);
    }
    _22769 = NOVALUE;
    if (_22770 == 0) {
        DeRef(_22770);
        _22770 = NOVALUE;
        goto L4; // [89] 138
    }
    else {
        if (!IS_ATOM_INT(_22770) && DBL_PTR(_22770)->dbl == 0.0){
            DeRef(_22770);
            _22770 = NOVALUE;
            goto L4; // [89] 138
        }
        DeRef(_22770);
        _22770 = NOVALUE;
    }
    DeRef(_22770);
    _22770 = NOVALUE;
L3: 

    /** 			if sym[S_GTYPE_NEW] = TYPE_NULL then*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22771 = (int)*(((s1_ptr)_2)->base + 38);
    if (binary_op_a(NOTEQ, _22771, 0)){
        _22771 = NOVALUE;
        goto L5; // [103] 120
    }
    _22771 = NOVALUE;

    /** 				sym[S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    goto L6; // [117] 549
L5: 

    /** 				sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22773 = (int)*(((s1_ptr)_2)->base + 38);
    Ref(_22773);
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _22773;
    if( _1 != _22773 ){
        DeRef(_1);
    }
    _22773 = NOVALUE;
    goto L6; // [135] 549
L4: 

    /** 			if sym[S_GTYPE] != TYPE_INTEGER and*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22774 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22774)) {
        _22775 = (_22774 != 1);
    }
    else {
        _22775 = binary_op(NOTEQ, _22774, 1);
    }
    _22774 = NOVALUE;
    if (IS_ATOM_INT(_22775)) {
        if (_22775 == 0) {
            DeRef(_22776);
            _22776 = 0;
            goto L7; // [152] 172
        }
    }
    else {
        if (DBL_PTR(_22775)->dbl == 0.0) {
            DeRef(_22776);
            _22776 = 0;
            goto L7; // [152] 172
        }
    }
    _2 = (int)SEQ_PTR(_sym_42714);
    _22777 = (int)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22777)) {
        _22778 = (_22777 != 16);
    }
    else {
        _22778 = binary_op(NOTEQ, _22777, 16);
    }
    _22777 = NOVALUE;
    DeRef(_22776);
    if (IS_ATOM_INT(_22778))
    _22776 = (_22778 != 0);
    else
    _22776 = DBL_PTR(_22778)->dbl != 0.0;
L7: 
    if (_22776 == 0) {
        goto L8; // [172] 283
    }
    _2 = (int)SEQ_PTR(_sym_42714);
    _22780 = (int)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22780)) {
        _22781 = (_22780 != 0);
    }
    else {
        _22781 = binary_op(NOTEQ, _22780, 0);
    }
    _22780 = NOVALUE;
    if (_22781 == 0) {
        DeRef(_22781);
        _22781 = NOVALUE;
        goto L8; // [189] 283
    }
    else {
        if (!IS_ATOM_INT(_22781) && DBL_PTR(_22781)->dbl == 0.0){
            DeRef(_22781);
            _22781 = NOVALUE;
            goto L8; // [189] 283
        }
        DeRef(_22781);
        _22781 = NOVALUE;
    }
    DeRef(_22781);
    _22781 = NOVALUE;

    /** 				if sym[S_GTYPE_NEW] = TYPE_INTEGER or*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22782 = (int)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22782)) {
        _22783 = (_22782 == 1);
    }
    else {
        _22783 = binary_op(EQUALS, _22782, 1);
    }
    _22782 = NOVALUE;
    if (IS_ATOM_INT(_22783)) {
        if (_22783 != 0) {
            DeRef(_22784);
            _22784 = 1;
            goto L9; // [206] 226
        }
    }
    else {
        if (DBL_PTR(_22783)->dbl != 0.0) {
            DeRef(_22784);
            _22784 = 1;
            goto L9; // [206] 226
        }
    }
    _2 = (int)SEQ_PTR(_sym_42714);
    _22785 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22785)) {
        _22786 = (_22785 == 16);
    }
    else {
        _22786 = binary_op(EQUALS, _22785, 16);
    }
    _22785 = NOVALUE;
    DeRef(_22784);
    if (IS_ATOM_INT(_22786))
    _22784 = (_22786 != 0);
    else
    _22784 = DBL_PTR(_22786)->dbl != 0.0;
L9: 
    if (_22784 != 0) {
        goto LA; // [226] 267
    }
    _2 = (int)SEQ_PTR(_sym_42714);
    _22788 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22788)) {
        _22789 = (_22788 == 4);
    }
    else {
        _22789 = binary_op(EQUALS, _22788, 4);
    }
    _22788 = NOVALUE;
    if (IS_ATOM_INT(_22789)) {
        if (_22789 == 0) {
            DeRef(_22790);
            _22790 = 0;
            goto LB; // [242] 262
        }
    }
    else {
        if (DBL_PTR(_22789)->dbl == 0.0) {
            DeRef(_22790);
            _22790 = 0;
            goto LB; // [242] 262
        }
    }
    _2 = (int)SEQ_PTR(_sym_42714);
    _22791 = (int)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22791)) {
        _22792 = (_22791 == 2);
    }
    else {
        _22792 = binary_op(EQUALS, _22791, 2);
    }
    _22791 = NOVALUE;
    DeRef(_22790);
    if (IS_ATOM_INT(_22792))
    _22790 = (_22792 != 0);
    else
    _22790 = DBL_PTR(_22792)->dbl != 0.0;
LB: 
    if (_22790 == 0)
    {
        _22790 = NOVALUE;
        goto LC; // [263] 282
    }
    else{
        _22790 = NOVALUE;
    }
LA: 

    /** 						sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22793 = (int)*(((s1_ptr)_2)->base + 38);
    Ref(_22793);
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _22793;
    if( _1 != _22793 ){
        DeRef(_1);
    }
    _22793 = NOVALUE;
LC: 
L8: 

    /** 			if sym[S_ARG_TYPE_NEW] = TYPE_NULL then*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22794 = (int)*(((s1_ptr)_2)->base + 44);
    if (binary_op_a(NOTEQ, _22794, 0)){
        _22794 = NOVALUE;
        goto LD; // [293] 310
    }
    _22794 = NOVALUE;

    /** 				sym[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 43);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    goto LE; // [307] 325
LD: 

    /** 				sym[S_ARG_TYPE] = sym[S_ARG_TYPE_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22796 = (int)*(((s1_ptr)_2)->base + 44);
    Ref(_22796);
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 43);
    _1 = *(int *)_2;
    *(int *)_2 = _22796;
    if( _1 != _22796 ){
        DeRef(_1);
    }
    _22796 = NOVALUE;
LE: 

    /** 			sym[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 44);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			if sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22797 = (int)*(((s1_ptr)_2)->base + 46);
    if (binary_op_a(NOTEQ, _22797, 0)){
        _22797 = NOVALUE;
        goto LF; // [345] 362
    }
    _22797 = NOVALUE;

    /** 				sym[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 45);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    goto L10; // [359] 377
LF: 

    /** 				sym[S_ARG_SEQ_ELEM] = sym[S_ARG_SEQ_ELEM_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22799 = (int)*(((s1_ptr)_2)->base + 46);
    Ref(_22799);
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 45);
    _1 = *(int *)_2;
    *(int *)_2 = _22799;
    if( _1 != _22799 ){
        DeRef(_1);
    }
    _22799 = NOVALUE;
L10: 

    /** 			sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 46);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			if sym[S_ARG_MIN_NEW] = -NOVALUE or*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22800 = (int)*(((s1_ptr)_2)->base + 49);
    if (IS_ATOM_INT(_26NOVALUE_11836)) {
        if ((unsigned long)_26NOVALUE_11836 == 0xC0000000)
        _22801 = (int)NewDouble((double)-0xC0000000);
        else
        _22801 = - _26NOVALUE_11836;
    }
    else {
        _22801 = unary_op(UMINUS, _26NOVALUE_11836);
    }
    if (IS_ATOM_INT(_22800) && IS_ATOM_INT(_22801)) {
        _22802 = (_22800 == _22801);
    }
    else {
        _22802 = binary_op(EQUALS, _22800, _22801);
    }
    _22800 = NOVALUE;
    DeRef(_22801);
    _22801 = NOVALUE;
    if (IS_ATOM_INT(_22802)) {
        if (_22802 != 0) {
            goto L11; // [404] 425
        }
    }
    else {
        if (DBL_PTR(_22802)->dbl != 0.0) {
            goto L11; // [404] 425
        }
    }
    _2 = (int)SEQ_PTR(_sym_42714);
    _22804 = (int)*(((s1_ptr)_2)->base + 49);
    if (IS_ATOM_INT(_22804) && IS_ATOM_INT(_26NOVALUE_11836)) {
        _22805 = (_22804 == _26NOVALUE_11836);
    }
    else {
        _22805 = binary_op(EQUALS, _22804, _26NOVALUE_11836);
    }
    _22804 = NOVALUE;
    if (_22805 == 0) {
        DeRef(_22805);
        _22805 = NOVALUE;
        goto L12; // [421] 448
    }
    else {
        if (!IS_ATOM_INT(_22805) && DBL_PTR(_22805)->dbl == 0.0){
            DeRef(_22805);
            _22805 = NOVALUE;
            goto L12; // [421] 448
        }
        DeRef(_22805);
        _22805 = NOVALUE;
    }
    DeRef(_22805);
    _22805 = NOVALUE;
L11: 

    /** 				sym[S_ARG_MIN] = MININT*/
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 47);
    _1 = *(int *)_2;
    *(int *)_2 = -1073741824;
    DeRef(_1);

    /** 				sym[S_ARG_MAX] = MAXINT*/
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 48);
    _1 = *(int *)_2;
    *(int *)_2 = 1073741823;
    DeRef(_1);
    goto L13; // [445] 477
L12: 

    /** 				sym[S_ARG_MIN] = sym[S_ARG_MIN_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22806 = (int)*(((s1_ptr)_2)->base + 49);
    Ref(_22806);
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 47);
    _1 = *(int *)_2;
    *(int *)_2 = _22806;
    if( _1 != _22806 ){
        DeRef(_1);
    }
    _22806 = NOVALUE;

    /** 				sym[S_ARG_MAX] = sym[S_ARG_MAX_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22807 = (int)*(((s1_ptr)_2)->base + 50);
    Ref(_22807);
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 48);
    _1 = *(int *)_2;
    *(int *)_2 = _22807;
    if( _1 != _22807 ){
        DeRef(_1);
    }
    _22807 = NOVALUE;
L13: 

    /** 			sym[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_26NOVALUE_11836)) {
        if ((unsigned long)_26NOVALUE_11836 == 0xC0000000)
        _22808 = (int)NewDouble((double)-0xC0000000);
        else
        _22808 = - _26NOVALUE_11836;
    }
    else {
        _22808 = unary_op(UMINUS, _26NOVALUE_11836);
    }
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 49);
    _1 = *(int *)_2;
    *(int *)_2 = _22808;
    if( _1 != _22808 ){
        DeRef(_1);
    }
    _22808 = NOVALUE;

    /** 			if sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22809 = (int)*(((s1_ptr)_2)->base + 52);
    if (IS_ATOM_INT(_26NOVALUE_11836)) {
        if ((unsigned long)_26NOVALUE_11836 == 0xC0000000)
        _22810 = (int)NewDouble((double)-0xC0000000);
        else
        _22810 = - _26NOVALUE_11836;
    }
    else {
        _22810 = unary_op(UMINUS, _26NOVALUE_11836);
    }
    if (binary_op_a(NOTEQ, _22809, _22810)){
        _22809 = NOVALUE;
        DeRef(_22810);
        _22810 = NOVALUE;
        goto L14; // [503] 520
    }
    _22809 = NOVALUE;
    DeRef(_22810);
    _22810 = NOVALUE;

    /** 				sym[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 51);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
    goto L15; // [517] 535
L14: 

    /** 				sym[S_ARG_SEQ_LEN] = sym[S_ARG_SEQ_LEN_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22812 = (int)*(((s1_ptr)_2)->base + 52);
    Ref(_22812);
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 51);
    _1 = *(int *)_2;
    *(int *)_2 = _22812;
    if( _1 != _22812 ){
        DeRef(_1);
    }
    _22812 = NOVALUE;
L15: 

    /** 			sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_26NOVALUE_11836)) {
        if ((unsigned long)_26NOVALUE_11836 == 0xC0000000)
        _22813 = (int)NewDouble((double)-0xC0000000);
        else
        _22813 = - _26NOVALUE_11836;
    }
    else {
        _22813 = unary_op(UMINUS, _26NOVALUE_11836);
    }
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 52);
    _1 = *(int *)_2;
    *(int *)_2 = _22813;
    if( _1 != _22813 ){
        DeRef(_1);
    }
    _22813 = NOVALUE;
L6: 

    /** 		sym[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 38);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		if sym[S_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22814 = (int)*(((s1_ptr)_2)->base + 40);
    if (binary_op_a(NOTEQ, _22814, 0)){
        _22814 = NOVALUE;
        goto L16; // [569] 586
    }
    _22814 = NOVALUE;

    /** 		   sym[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    goto L17; // [583] 601
L16: 

    /** 			sym[S_SEQ_ELEM] = sym[S_SEQ_ELEM_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22816 = (int)*(((s1_ptr)_2)->base + 40);
    Ref(_22816);
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _22816;
    if( _1 != _22816 ){
        DeRef(_1);
    }
    _22816 = NOVALUE;
L17: 

    /** 		sym[S_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22817 = (int)*(((s1_ptr)_2)->base + 39);
    if (IS_ATOM_INT(_26NOVALUE_11836)) {
        if ((unsigned long)_26NOVALUE_11836 == 0xC0000000)
        _22818 = (int)NewDouble((double)-0xC0000000);
        else
        _22818 = - _26NOVALUE_11836;
    }
    else {
        _22818 = unary_op(UMINUS, _26NOVALUE_11836);
    }
    if (binary_op_a(NOTEQ, _22817, _22818)){
        _22817 = NOVALUE;
        DeRef(_22818);
        _22818 = NOVALUE;
        goto L18; // [624] 641
    }
    _22817 = NOVALUE;
    DeRef(_22818);
    _22818 = NOVALUE;

    /** 			sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
    goto L19; // [638] 656
L18: 

    /** 			sym[S_SEQ_LEN] = sym[S_SEQ_LEN_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22820 = (int)*(((s1_ptr)_2)->base + 39);
    Ref(_22820);
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _22820;
    if( _1 != _22820 ){
        DeRef(_1);
    }
    _22820 = NOVALUE;
L19: 

    /** 		sym[S_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_26NOVALUE_11836)) {
        if ((unsigned long)_26NOVALUE_11836 == 0xC0000000)
        _22821 = (int)NewDouble((double)-0xC0000000);
        else
        _22821 = - _26NOVALUE_11836;
    }
    else {
        _22821 = unary_op(UMINUS, _26NOVALUE_11836);
    }
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _22821;
    if( _1 != _22821 ){
        DeRef(_1);
    }
    _22821 = NOVALUE;

    /** 		if sym[S_TOKEN] != NAMESPACE*/
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _22822 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _22822 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    if (IS_ATOM_INT(_22822)) {
        _22823 = (_22822 != 523);
    }
    else {
        _22823 = binary_op(NOTEQ, _22822, 523);
    }
    _22822 = NOVALUE;
    if (IS_ATOM_INT(_22823)) {
        if (_22823 == 0) {
            goto L1A; // [683] 794
        }
    }
    else {
        if (DBL_PTR(_22823)->dbl == 0.0) {
            goto L1A; // [683] 794
        }
    }
    _2 = (int)SEQ_PTR(_sym_42714);
    _22825 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_22825)) {
        _22826 = (_22825 != 2);
    }
    else {
        _22826 = binary_op(NOTEQ, _22825, 2);
    }
    _22825 = NOVALUE;
    if (_22826 == 0) {
        DeRef(_22826);
        _22826 = NOVALUE;
        goto L1A; // [700] 794
    }
    else {
        if (!IS_ATOM_INT(_22826) && DBL_PTR(_22826)->dbl == 0.0){
            DeRef(_22826);
            _22826 = NOVALUE;
            goto L1A; // [700] 794
        }
        DeRef(_22826);
        _22826 = NOVALUE;
    }
    DeRef(_22826);
    _22826 = NOVALUE;

    /** 			if sym[S_OBJ_MIN_NEW] = -NOVALUE or*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22827 = (int)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_26NOVALUE_11836)) {
        if ((unsigned long)_26NOVALUE_11836 == 0xC0000000)
        _22828 = (int)NewDouble((double)-0xC0000000);
        else
        _22828 = - _26NOVALUE_11836;
    }
    else {
        _22828 = unary_op(UMINUS, _26NOVALUE_11836);
    }
    if (IS_ATOM_INT(_22827) && IS_ATOM_INT(_22828)) {
        _22829 = (_22827 == _22828);
    }
    else {
        _22829 = binary_op(EQUALS, _22827, _22828);
    }
    _22827 = NOVALUE;
    DeRef(_22828);
    _22828 = NOVALUE;
    if (IS_ATOM_INT(_22829)) {
        if (_22829 != 0) {
            goto L1B; // [720] 741
        }
    }
    else {
        if (DBL_PTR(_22829)->dbl != 0.0) {
            goto L1B; // [720] 741
        }
    }
    _2 = (int)SEQ_PTR(_sym_42714);
    _22831 = (int)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_22831) && IS_ATOM_INT(_26NOVALUE_11836)) {
        _22832 = (_22831 == _26NOVALUE_11836);
    }
    else {
        _22832 = binary_op(EQUALS, _22831, _26NOVALUE_11836);
    }
    _22831 = NOVALUE;
    if (_22832 == 0) {
        DeRef(_22832);
        _22832 = NOVALUE;
        goto L1C; // [737] 764
    }
    else {
        if (!IS_ATOM_INT(_22832) && DBL_PTR(_22832)->dbl == 0.0){
            DeRef(_22832);
            _22832 = NOVALUE;
            goto L1C; // [737] 764
        }
        DeRef(_22832);
        _22832 = NOVALUE;
    }
    DeRef(_22832);
    _22832 = NOVALUE;
L1B: 

    /** 				sym[S_OBJ_MIN] = MININT*/
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = -1073741824;
    DeRef(_1);

    /** 				sym[S_OBJ_MAX] = MAXINT*/
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = 1073741823;
    DeRef(_1);
    goto L1D; // [761] 793
L1C: 

    /** 				sym[S_OBJ_MIN] = sym[S_OBJ_MIN_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22833 = (int)*(((s1_ptr)_2)->base + 41);
    Ref(_22833);
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _22833;
    if( _1 != _22833 ){
        DeRef(_1);
    }
    _22833 = NOVALUE;

    /** 				sym[S_OBJ_MAX] = sym[S_OBJ_MAX_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22834 = (int)*(((s1_ptr)_2)->base + 42);
    Ref(_22834);
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _22834;
    if( _1 != _22834 ){
        DeRef(_1);
    }
    _22834 = NOVALUE;
L1D: 
L1A: 

    /** 		sym[S_OBJ_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_26NOVALUE_11836)) {
        if ((unsigned long)_26NOVALUE_11836 == 0xC0000000)
        _22835 = (int)NewDouble((double)-0xC0000000);
        else
        _22835 = - _26NOVALUE_11836;
    }
    else {
        _22835 = unary_op(UMINUS, _26NOVALUE_11836);
    }
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _22835;
    if( _1 != _22835 ){
        DeRef(_1);
    }
    _22835 = NOVALUE;

    /** 		if sym[S_NREFS] = 1 and*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22836 = (int)*(((s1_ptr)_2)->base + 12);
    if (IS_ATOM_INT(_22836)) {
        _22837 = (_22836 == 1);
    }
    else {
        _22837 = binary_op(EQUALS, _22836, 1);
    }
    _22836 = NOVALUE;
    if (IS_ATOM_INT(_22837)) {
        if (_22837 == 0) {
            goto L1E; // [819] 874
        }
    }
    else {
        if (DBL_PTR(_22837)->dbl == 0.0) {
            goto L1E; // [819] 874
        }
    }
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _22839 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _22839 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _22840 = find_from(_22839, _28RTN_TOKS_11602, 1);
    _22839 = NOVALUE;
    if (_22840 == 0)
    {
        _22840 = NOVALUE;
        goto L1E; // [837] 874
    }
    else{
        _22840 = NOVALUE;
    }

    /** 			if sym[S_USAGE] != U_DELETED then*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _22841 = (int)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(EQUALS, _22841, 99)){
        _22841 = NOVALUE;
        goto L1F; // [850] 873
    }
    _22841 = NOVALUE;

    /** 				sym[S_USAGE] = U_DELETED*/
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 99;
    DeRef(_1);

    /** 				deleted_routines += 1*/
    _56deleted_routines_42708 = _56deleted_routines_42708 + 1;
L1F: 
L1E: 

    /** 		sym[S_NREFS] = 0*/
    _2 = (int)SEQ_PTR(_sym_42714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		if not equal(symo, sym) then*/
    if (_symo_42715 == _sym_42714)
    _22844 = 1;
    else if (IS_ATOM_INT(_symo_42715) && IS_ATOM_INT(_sym_42714))
    _22844 = 0;
    else
    _22844 = (compare(_symo_42715, _sym_42714) == 0);
    if (_22844 != 0)
    goto L20; // [888] 906
    _22844 = NOVALUE;

    /** 			SymTab[s] = sym*/
    RefDS(_sym_42714);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _s_42713);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_42714;
    DeRef(_1);

    /** 			updsym += 1*/
    _updsym_42711 = _updsym_42711 + 1;
L20: 

    /** 		s = sym[S_NEXT]*/
    _2 = (int)SEQ_PTR(_sym_42714);
    _s_42713 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42713)){
        _s_42713 = (long)DBL_PTR(_s_42713)->dbl;
    }

    /** 	end while*/
    goto L1; // [918] 38
L2: 

    /** 	for i = 1 to length(temp_name_type) do*/
    if (IS_SEQUENCE(_26temp_name_type_12065)){
            _22848 = SEQ_PTR(_26temp_name_type_12065)->length;
    }
    else {
        _22848 = 1;
    }
    {
        int _i_42941;
        _i_42941 = 1;
L21: 
        if (_i_42941 > _22848){
            goto L22; // [928] 1061
        }

        /** 		integer upd = 0*/
        _upd_42944 = 0;

        /** 		if temp_name_type[i][T_GTYPE] != temp_name_type[i][T_GTYPE_NEW] then*/
        _2 = (int)SEQ_PTR(_26temp_name_type_12065);
        _22849 = (int)*(((s1_ptr)_2)->base + _i_42941);
        _2 = (int)SEQ_PTR(_22849);
        _22850 = (int)*(((s1_ptr)_2)->base + 1);
        _22849 = NOVALUE;
        _2 = (int)SEQ_PTR(_26temp_name_type_12065);
        _22851 = (int)*(((s1_ptr)_2)->base + _i_42941);
        _2 = (int)SEQ_PTR(_22851);
        _22852 = (int)*(((s1_ptr)_2)->base + 2);
        _22851 = NOVALUE;
        if (binary_op_a(EQUALS, _22850, _22852)){
            _22850 = NOVALUE;
            _22852 = NOVALUE;
            goto L23; // [966] 1003
        }
        _22850 = NOVALUE;
        _22852 = NOVALUE;

        /** 			temp_name_type[i][T_GTYPE] = temp_name_type[i][T_GTYPE_NEW]*/
        _2 = (int)SEQ_PTR(_26temp_name_type_12065);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _26temp_name_type_12065 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_42941 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_26temp_name_type_12065);
        _22856 = (int)*(((s1_ptr)_2)->base + _i_42941);
        _2 = (int)SEQ_PTR(_22856);
        _22857 = (int)*(((s1_ptr)_2)->base + 2);
        _22856 = NOVALUE;
        Ref(_22857);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _22857;
        if( _1 != _22857 ){
            DeRef(_1);
        }
        _22857 = NOVALUE;
        _22854 = NOVALUE;

        /** 			upd = 1*/
        _upd_42944 = 1;
L23: 

        /** 		if temp_name_type[i][T_GTYPE_NEW] != TYPE_NULL then*/
        _2 = (int)SEQ_PTR(_26temp_name_type_12065);
        _22858 = (int)*(((s1_ptr)_2)->base + _i_42941);
        _2 = (int)SEQ_PTR(_22858);
        _22859 = (int)*(((s1_ptr)_2)->base + 2);
        _22858 = NOVALUE;
        if (binary_op_a(EQUALS, _22859, 0)){
            _22859 = NOVALUE;
            goto L24; // [1019] 1046
        }
        _22859 = NOVALUE;

        /** 			temp_name_type[i][T_GTYPE_NEW] = TYPE_NULL*/
        _2 = (int)SEQ_PTR(_26temp_name_type_12065);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _26temp_name_type_12065 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_42941 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);
        _22861 = NOVALUE;

        /** 			upd = 1*/
        _upd_42944 = 1;
L24: 

        /** 		updsym += upd*/
        _updsym_42711 = _updsym_42711 + _upd_42944;

        /** 	end for*/
        _i_42941 = _i_42941 + 1;
        goto L21; // [1056] 935
L22: 
        ;
    }

    /** 	return updsym*/
    DeRef(_sym_42714);
    DeRef(_symo_42715);
    DeRef(_22767);
    _22767 = NOVALUE;
    DeRef(_22775);
    _22775 = NOVALUE;
    DeRef(_22778);
    _22778 = NOVALUE;
    DeRef(_22783);
    _22783 = NOVALUE;
    DeRef(_22786);
    _22786 = NOVALUE;
    DeRef(_22789);
    _22789 = NOVALUE;
    DeRef(_22792);
    _22792 = NOVALUE;
    DeRef(_22823);
    _22823 = NOVALUE;
    DeRef(_22802);
    _22802 = NOVALUE;
    DeRef(_22837);
    _22837 = NOVALUE;
    DeRef(_22829);
    _22829 = NOVALUE;
    return _updsym_42711;
    ;
}


void _56declare_prototype(int _s_42979)
{
    int _ret_type_42980 = NOVALUE;
    int _scope_42991 = NOVALUE;
    int _22881 = NOVALUE;
    int _22880 = NOVALUE;
    int _22878 = NOVALUE;
    int _22877 = NOVALUE;
    int _22876 = NOVALUE;
    int _22875 = NOVALUE;
    int _22873 = NOVALUE;
    int _22872 = NOVALUE;
    int _22871 = NOVALUE;
    int _22870 = NOVALUE;
    int _22869 = NOVALUE;
    int _22867 = NOVALUE;
    int _22866 = NOVALUE;
    int _22864 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sym_token( s ) = PROC then*/
    _22864 = _52sym_token(_s_42979);
    if (binary_op_a(NOTEQ, _22864, 27)){
        DeRef(_22864);
        _22864 = NOVALUE;
        goto L1; // [11] 25
    }
    DeRef(_22864);
    _22864 = NOVALUE;

    /** 		ret_type = "void "*/
    RefDS(_22749);
    DeRefi(_ret_type_42980);
    _ret_type_42980 = _22749;
    goto L2; // [22] 33
L1: 

    /** 		ret_type ="int "*/
    RefDS(_22750);
    DeRefi(_ret_type_42980);
    _ret_type_42980 = _22750;
L2: 

    /** 	c_hputs(ret_type)*/
    RefDS(_ret_type_42980);
    _53c_hputs(_ret_type_42980);

    /** 	if dll_option and TWINDOWS  then*/
    if (_56dll_option_41716 == 0) {
        goto L3; // [44] 116
    }
    if (_36TWINDOWS_14305 == 0)
    {
        goto L3; // [51] 116
    }
    else{
    }

    /** 		integer scope = SymTab[s][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22867 = (int)*(((s1_ptr)_2)->base + _s_42979);
    _2 = (int)SEQ_PTR(_22867);
    _scope_42991 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_42991)){
        _scope_42991 = (long)DBL_PTR(_scope_42991)->dbl;
    }
    _22867 = NOVALUE;

    /** 		if (scope = SC_PUBLIC*/
    _22869 = (_scope_42991 == 13);
    if (_22869 != 0) {
        _22870 = 1;
        goto L4; // [78] 92
    }
    _22871 = (_scope_42991 == 11);
    _22870 = (_22871 != 0);
L4: 
    if (_22870 != 0) {
        DeRef(_22872);
        _22872 = 1;
        goto L5; // [92] 106
    }
    _22873 = (_scope_42991 == 6);
    _22872 = (_22873 != 0);
L5: 
    if (_22872 == 0)
    {
        _22872 = NOVALUE;
        goto L6; // [106] 115
    }
    else{
        _22872 = NOVALUE;
    }

    /** 			c_hputs("__stdcall ")*/
    RefDS(_22874);
    _53c_hputs(_22874);
L6: 
L3: 

    /** 	c_hprintf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22875 = (int)*(((s1_ptr)_2)->base + _s_42979);
    _2 = (int)SEQ_PTR(_22875);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _22876 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _22876 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _22875 = NOVALUE;
    RefDS(_22130);
    Ref(_22876);
    _53c_hprintf(_22130, _22876);
    _22876 = NOVALUE;

    /** 	c_hputs(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22877 = (int)*(((s1_ptr)_2)->base + _s_42979);
    _2 = (int)SEQ_PTR(_22877);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _22878 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _22878 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _22877 = NOVALUE;
    Ref(_22878);
    _53c_hputs(_22878);
    _22878 = NOVALUE;

    /** 	c_hputs("(")*/
    RefDS(_22879);
    _53c_hputs(_22879);

    /** 	for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22880 = (int)*(((s1_ptr)_2)->base + _s_42979);
    _2 = (int)SEQ_PTR(_22880);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _22881 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _22881 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _22880 = NOVALUE;
    {
        int _i_43020;
        _i_43020 = 1;
L7: 
        if (binary_op_a(GREATER, _i_43020, _22881)){
            goto L8; // [172] 206
        }

        /** 		if i = 1 then*/
        if (binary_op_a(NOTEQ, _i_43020, 1)){
            goto L9; // [181] 193
        }

        /** 			c_hputs("int")*/
        RefDS(_22883);
        _53c_hputs(_22883);
        goto LA; // [190] 199
L9: 

        /** 			c_hputs(", int")*/
        RefDS(_22884);
        _53c_hputs(_22884);
LA: 

        /** 	end for*/
        _0 = _i_43020;
        if (IS_ATOM_INT(_i_43020)) {
            _i_43020 = _i_43020 + 1;
            if ((long)((unsigned long)_i_43020 +(unsigned long) HIGH_BITS) >= 0){
                _i_43020 = NewDouble((double)_i_43020);
            }
        }
        else {
            _i_43020 = binary_op_a(PLUS, _i_43020, 1);
        }
        DeRef(_0);
        goto L7; // [201] 179
L8: 
        ;
        DeRef(_i_43020);
    }

    /** 	c_hputs(");\n")*/
    RefDS(_22299);
    _53c_hputs(_22299);

    /** end procedure*/
    DeRefi(_ret_type_42980);
    DeRef(_22869);
    _22869 = NOVALUE;
    DeRef(_22871);
    _22871 = NOVALUE;
    DeRef(_22873);
    _22873 = NOVALUE;
    _22881 = NOVALUE;
    return;
    ;
}


void _56add_to_routine_list(int _s_43036, int _seq_num_43037, int _first_43038)
{
    int _p_43113 = NOVALUE;
    int _22930 = NOVALUE;
    int _22928 = NOVALUE;
    int _22926 = NOVALUE;
    int _22924 = NOVALUE;
    int _22922 = NOVALUE;
    int _22921 = NOVALUE;
    int _22920 = NOVALUE;
    int _22918 = NOVALUE;
    int _22916 = NOVALUE;
    int _22914 = NOVALUE;
    int _22913 = NOVALUE;
    int _22911 = NOVALUE;
    int _22910 = NOVALUE;
    int _22906 = NOVALUE;
    int _22905 = NOVALUE;
    int _22904 = NOVALUE;
    int _22903 = NOVALUE;
    int _22902 = NOVALUE;
    int _22901 = NOVALUE;
    int _22900 = NOVALUE;
    int _22899 = NOVALUE;
    int _22898 = NOVALUE;
    int _22897 = NOVALUE;
    int _22895 = NOVALUE;
    int _22894 = NOVALUE;
    int _22893 = NOVALUE;
    int _22892 = NOVALUE;
    int _22889 = NOVALUE;
    int _22888 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if not first then*/
    if (_first_43038 != 0)
    goto L1; // [9] 18

    /** 		c_puts(",\n")*/
    RefDS(_22886);
    _53c_puts(_22886);
L1: 

    /** 	c_puts("  {\"")*/
    RefDS(_22887);
    _53c_puts(_22887);

    /** 	c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22888 = (int)*(((s1_ptr)_2)->base + _s_43036);
    _2 = (int)SEQ_PTR(_22888);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _22889 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _22889 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _22888 = NOVALUE;
    Ref(_22889);
    _53c_puts(_22889);
    _22889 = NOVALUE;

    /** 	c_puts("\", ")*/
    RefDS(_22890);
    _53c_puts(_22890);

    /** 	c_puts("(int (*)())")*/
    RefDS(_22891);
    _53c_puts(_22891);

    /** 	c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22892 = (int)*(((s1_ptr)_2)->base + _s_43036);
    _2 = (int)SEQ_PTR(_22892);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _22893 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _22893 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _22892 = NOVALUE;
    RefDS(_22130);
    Ref(_22893);
    _53c_printf(_22130, _22893);
    _22893 = NOVALUE;

    /** 	c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22894 = (int)*(((s1_ptr)_2)->base + _s_43036);
    _2 = (int)SEQ_PTR(_22894);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _22895 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _22895 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _22894 = NOVALUE;
    Ref(_22895);
    _53c_puts(_22895);
    _22895 = NOVALUE;

    /** 	c_printf(", %d", seq_num)*/
    RefDS(_22896);
    _53c_printf(_22896, _seq_num_43037);

    /** 	c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22897 = (int)*(((s1_ptr)_2)->base + _s_43036);
    _2 = (int)SEQ_PTR(_22897);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _22898 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _22898 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _22897 = NOVALUE;
    RefDS(_22896);
    Ref(_22898);
    _53c_printf(_22896, _22898);
    _22898 = NOVALUE;

    /** 	c_printf(", %d", SymTab[s][S_NUM_ARGS])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22899 = (int)*(((s1_ptr)_2)->base + _s_43036);
    _2 = (int)SEQ_PTR(_22899);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _22900 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _22900 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _22899 = NOVALUE;
    RefDS(_22896);
    Ref(_22900);
    _53c_printf(_22896, _22900);
    _22900 = NOVALUE;

    /** 	if TWINDOWS and dll_option and find( SymTab[s][S_SCOPE], { SC_GLOBAL, SC_EXPORT, SC_PUBLIC} ) then*/
    if (_36TWINDOWS_14305 == 0) {
        _22901 = 0;
        goto L2; // [131] 141
    }
    _22901 = (_56dll_option_41716 != 0);
L2: 
    if (_22901 == 0) {
        goto L3; // [141] 186
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22903 = (int)*(((s1_ptr)_2)->base + _s_43036);
    _2 = (int)SEQ_PTR(_22903);
    _22904 = (int)*(((s1_ptr)_2)->base + 4);
    _22903 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 6;
    *((int *)(_2+8)) = 11;
    *((int *)(_2+12)) = 13;
    _22905 = MAKE_SEQ(_1);
    _22906 = find_from(_22904, _22905, 1);
    _22904 = NOVALUE;
    DeRefDS(_22905);
    _22905 = NOVALUE;
    if (_22906 == 0)
    {
        _22906 = NOVALUE;
        goto L3; // [175] 186
    }
    else{
        _22906 = NOVALUE;
    }

    /** 		c_puts(", 1")  -- must call with __stdcall convention*/
    RefDS(_22907);
    _53c_puts(_22907);
    goto L4; // [183] 192
L3: 

    /** 		c_puts(", 0")  -- default: call with normal or __cdecl convention*/
    RefDS(_22908);
    _53c_puts(_22908);
L4: 

    /** 	c_printf(", %d, 0", SymTab[s][S_SCOPE] )*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22910 = (int)*(((s1_ptr)_2)->base + _s_43036);
    _2 = (int)SEQ_PTR(_22910);
    _22911 = (int)*(((s1_ptr)_2)->base + 4);
    _22910 = NOVALUE;
    RefDS(_22909);
    Ref(_22911);
    _53c_printf(_22909, _22911);
    _22911 = NOVALUE;

    /** 	c_puts("}")*/
    RefDS(_22912);
    _53c_puts(_22912);

    /** 	if SymTab[s][S_NREFS] < 2 then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22913 = (int)*(((s1_ptr)_2)->base + _s_43036);
    _2 = (int)SEQ_PTR(_22913);
    _22914 = (int)*(((s1_ptr)_2)->base + 12);
    _22913 = NOVALUE;
    if (binary_op_a(GREATEREQ, _22914, 2)){
        _22914 = NOVALUE;
        goto L5; // [229] 249
    }
    _22914 = NOVALUE;

    /** 		SymTab[s][S_NREFS] = 2 --s->nrefs++*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_43036 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _22916 = NOVALUE;
L5: 

    /** 	symtab_index p = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22918 = (int)*(((s1_ptr)_2)->base + _s_43036);
    _2 = (int)SEQ_PTR(_22918);
    _p_43113 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_43113)){
        _p_43113 = (long)DBL_PTR(_p_43113)->dbl;
    }
    _22918 = NOVALUE;

    /** 	for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22920 = (int)*(((s1_ptr)_2)->base + _s_43036);
    _2 = (int)SEQ_PTR(_22920);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _22921 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _22921 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _22920 = NOVALUE;
    {
        int _i_43119;
        _i_43119 = 1;
L6: 
        if (binary_op_a(GREATER, _i_43119, _22921)){
            goto L7; // [279] 377
        }

        /** 		SymTab[p][S_ARG_SEQ_ELEM_NEW] = TYPE_OBJECT*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_43113 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 46);
        _1 = *(int *)_2;
        *(int *)_2 = 16;
        DeRef(_1);
        _22922 = NOVALUE;

        /** 		SymTab[p][S_ARG_TYPE_NEW] = TYPE_OBJECT*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_43113 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 44);
        _1 = *(int *)_2;
        *(int *)_2 = 16;
        DeRef(_1);
        _22924 = NOVALUE;

        /** 		SymTab[p][S_ARG_MIN_NEW] = NOVALUE*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_43113 + ((s1_ptr)_2)->base);
        Ref(_26NOVALUE_11836);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 49);
        _1 = *(int *)_2;
        *(int *)_2 = _26NOVALUE_11836;
        DeRef(_1);
        _22926 = NOVALUE;

        /** 		SymTab[p][S_ARG_SEQ_LEN_NEW] = NOVALUE*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_43113 + ((s1_ptr)_2)->base);
        Ref(_26NOVALUE_11836);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 52);
        _1 = *(int *)_2;
        *(int *)_2 = _26NOVALUE_11836;
        DeRef(_1);
        _22928 = NOVALUE;

        /** 		p = SymTab[p][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _22930 = (int)*(((s1_ptr)_2)->base + _p_43113);
        _2 = (int)SEQ_PTR(_22930);
        _p_43113 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_p_43113)){
            _p_43113 = (long)DBL_PTR(_p_43113)->dbl;
        }
        _22930 = NOVALUE;

        /** 	end for*/
        _0 = _i_43119;
        if (IS_ATOM_INT(_i_43119)) {
            _i_43119 = _i_43119 + 1;
            if ((long)((unsigned long)_i_43119 +(unsigned long) HIGH_BITS) >= 0){
                _i_43119 = NewDouble((double)_i_43119);
            }
        }
        else {
            _i_43119 = binary_op_a(PLUS, _i_43119, 1);
        }
        DeRef(_0);
        goto L6; // [372] 286
L7: 
        ;
        DeRef(_i_43119);
    }

    /** end procedure*/
    _22921 = NOVALUE;
    return;
    ;
}


void _56DeclareRoutineList()
{
    int _s_43151 = NOVALUE;
    int _first_43152 = NOVALUE;
    int _seq_num_43153 = NOVALUE;
    int _these_routines_43161 = NOVALUE;
    int _these_routines_43183 = NOVALUE;
    int _22946 = NOVALUE;
    int _22945 = NOVALUE;
    int _22943 = NOVALUE;
    int _22941 = NOVALUE;
    int _22938 = NOVALUE;
    int _22937 = NOVALUE;
    int _22935 = NOVALUE;
    int _22933 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer first, seq_num*/

    /** 	c_hputs("extern struct routine_list _00[];\n")*/
    RefDS(_22932);
    _53c_hputs(_22932);

    /** 	check_file_routines()*/
    _56check_file_routines();

    /** 	for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_56file_routines_43737)){
            _22933 = SEQ_PTR(_56file_routines_43737)->length;
    }
    else {
        _22933 = 1;
    }
    {
        int _f_43158;
        _f_43158 = 1;
L1: 
        if (_f_43158 > _22933){
            goto L2; // [19] 98
        }

        /** 		sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_43161);
        _2 = (int)SEQ_PTR(_56file_routines_43737);
        _these_routines_43161 = (int)*(((s1_ptr)_2)->base + _f_43158);
        Ref(_these_routines_43161);

        /** 		for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_43161)){
                _22935 = SEQ_PTR(_these_routines_43161)->length;
        }
        else {
            _22935 = 1;
        }
        {
            int _r_43165;
            _r_43165 = 1;
L3: 
            if (_r_43165 > _22935){
                goto L4; // [41] 89
            }

            /** 			s = these_routines[r]*/
            _2 = (int)SEQ_PTR(_these_routines_43161);
            _s_43151 = (int)*(((s1_ptr)_2)->base + _r_43165);
            if (!IS_ATOM_INT(_s_43151)){
                _s_43151 = (long)DBL_PTR(_s_43151)->dbl;
            }

            /** 			if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _22937 = (int)*(((s1_ptr)_2)->base + _s_43151);
            _2 = (int)SEQ_PTR(_22937);
            _22938 = (int)*(((s1_ptr)_2)->base + 5);
            _22937 = NOVALUE;
            if (binary_op_a(EQUALS, _22938, 99)){
                _22938 = NOVALUE;
                goto L5; // [72] 82
            }
            _22938 = NOVALUE;

            /** 				declare_prototype( s )*/
            _56declare_prototype(_s_43151);
L5: 

            /** 		end for*/
            _r_43165 = _r_43165 + 1;
            goto L3; // [84] 48
L4: 
            ;
        }
        DeRef(_these_routines_43161);
        _these_routines_43161 = NOVALUE;

        /** 	end for*/
        _f_43158 = _f_43158 + 1;
        goto L1; // [93] 26
L2: 
        ;
    }

    /** 	c_puts("\n")*/
    RefDS(_22189);
    _53c_puts(_22189);

    /** 	seq_num = 0*/
    _seq_num_43153 = 0;

    /** 	first = TRUE*/
    _first_43152 = _9TRUE_430;

    /** 	c_puts("struct routine_list _00[] = {\n")*/
    RefDS(_22940);
    _53c_puts(_22940);

    /** 	for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_56file_routines_43737)){
            _22941 = SEQ_PTR(_56file_routines_43737)->length;
    }
    else {
        _22941 = 1;
    }
    {
        int _f_43180;
        _f_43180 = 1;
L6: 
        if (_f_43180 > _22941){
            goto L7; // [129] 222
        }

        /** 		sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_43183);
        _2 = (int)SEQ_PTR(_56file_routines_43737);
        _these_routines_43183 = (int)*(((s1_ptr)_2)->base + _f_43180);
        Ref(_these_routines_43183);

        /** 		for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_43183)){
                _22943 = SEQ_PTR(_these_routines_43183)->length;
        }
        else {
            _22943 = 1;
        }
        {
            int _r_43187;
            _r_43187 = 1;
L8: 
            if (_r_43187 > _22943){
                goto L9; // [151] 213
            }

            /** 			s = these_routines[r]*/
            _2 = (int)SEQ_PTR(_these_routines_43183);
            _s_43151 = (int)*(((s1_ptr)_2)->base + _r_43187);
            if (!IS_ATOM_INT(_s_43151)){
                _s_43151 = (long)DBL_PTR(_s_43151)->dbl;
            }

            /** 			if SymTab[s][S_RI_TARGET] then*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _22945 = (int)*(((s1_ptr)_2)->base + _s_43151);
            _2 = (int)SEQ_PTR(_22945);
            _22946 = (int)*(((s1_ptr)_2)->base + 53);
            _22945 = NOVALUE;
            if (_22946 == 0) {
                _22946 = NOVALUE;
                goto LA; // [180] 200
            }
            else {
                if (!IS_ATOM_INT(_22946) && DBL_PTR(_22946)->dbl == 0.0){
                    _22946 = NOVALUE;
                    goto LA; // [180] 200
                }
                _22946 = NOVALUE;
            }
            _22946 = NOVALUE;

            /** 				add_to_routine_list( s, seq_num, first )*/
            _56add_to_routine_list(_s_43151, _seq_num_43153, _first_43152);

            /** 				first = FALSE*/
            _first_43152 = _9FALSE_428;
LA: 

            /** 			seq_num += 1*/
            _seq_num_43153 = _seq_num_43153 + 1;

            /** 		end for*/
            _r_43187 = _r_43187 + 1;
            goto L8; // [208] 158
L9: 
            ;
        }
        DeRef(_these_routines_43183);
        _these_routines_43183 = NOVALUE;

        /** 	end for*/
        _f_43180 = _f_43180 + 1;
        goto L6; // [217] 136
L7: 
        ;
    }

    /** 	if not first then*/
    if (_first_43152 != 0)
    goto LB; // [224] 233

    /** 		c_puts(",\n")*/
    RefDS(_22886);
    _53c_puts(_22886);
LB: 

    /** 	c_puts("  {\"\", 0, 999999999, 0, 0, 0, 0}\n};\n\n")  -- end marker*/
    RefDS(_22949);
    _53c_puts(_22949);

    /** 	c_hputs("extern unsigned char ** _02;\n")*/
    RefDS(_22950);
    _53c_hputs(_22950);

    /** 	c_puts("unsigned char ** _02;\n")*/
    RefDS(_22951);
    _53c_puts(_22951);

    /** 	c_hputs("extern object _0switches;\n")*/
    RefDS(_22952);
    _53c_hputs(_22952);

    /** 	c_puts("object _0switches;\n")*/
    RefDS(_22953);
    _53c_puts(_22953);

    /** end procedure*/
    return;
    ;
}


void _56DeclareNameSpaceList()
{
    int _s_43213 = NOVALUE;
    int _first_43214 = NOVALUE;
    int _seq_num_43215 = NOVALUE;
    int _22973 = NOVALUE;
    int _22971 = NOVALUE;
    int _22970 = NOVALUE;
    int _22969 = NOVALUE;
    int _22968 = NOVALUE;
    int _22966 = NOVALUE;
    int _22965 = NOVALUE;
    int _22962 = NOVALUE;
    int _22961 = NOVALUE;
    int _22960 = NOVALUE;
    int _22959 = NOVALUE;
    int _22958 = NOVALUE;
    int _22956 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer first, seq_num*/

    /** 	c_hputs("extern struct ns_list _01[];\n")*/
    RefDS(_22954);
    _53c_hputs(_22954);

    /** 	c_puts("struct ns_list _01[] = {\n")*/
    RefDS(_22955);
    _53c_puts(_22955);

    /** 	seq_num = 0*/
    _seq_num_43215 = 0;

    /** 	first = TRUE*/
    _first_43214 = _9TRUE_430;

    /** 	s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22956 = (int)*(((s1_ptr)_2)->base + _26TopLevelSub_11989);
    _2 = (int)SEQ_PTR(_22956);
    _s_43213 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43213)){
        _s_43213 = (long)DBL_PTR(_s_43213)->dbl;
    }
    _22956 = NOVALUE;

    /** 	while s do*/
L1: 
    if (_s_43213 == 0)
    {
        goto L2; // [50] 215
    }
    else{
    }

    /** 		if find(SymTab[s][S_TOKEN], NAMED_TOKS) then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22958 = (int)*(((s1_ptr)_2)->base + _s_43213);
    _2 = (int)SEQ_PTR(_22958);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _22959 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _22959 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _22958 = NOVALUE;
    _22960 = find_from(_22959, _28NAMED_TOKS_11604, 1);
    _22959 = NOVALUE;
    if (_22960 == 0)
    {
        _22960 = NOVALUE;
        goto L3; // [74] 194
    }
    else{
        _22960 = NOVALUE;
    }

    /** 			if SymTab[s][S_TOKEN] = NAMESPACE then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22961 = (int)*(((s1_ptr)_2)->base + _s_43213);
    _2 = (int)SEQ_PTR(_22961);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _22962 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _22962 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _22961 = NOVALUE;
    if (binary_op_a(NOTEQ, _22962, 523)){
        _22962 = NOVALUE;
        goto L4; // [93] 187
    }
    _22962 = NOVALUE;

    /** 				if not first then*/
    if (_first_43214 != 0)
    goto L5; // [99] 108

    /** 					c_puts(",\n")*/
    RefDS(_22886);
    _53c_puts(_22886);
L5: 

    /** 				first = FALSE*/
    _first_43214 = _9FALSE_428;

    /** 				c_puts("  {\"")*/
    RefDS(_22887);
    _53c_puts(_22887);

    /** 				c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22965 = (int)*(((s1_ptr)_2)->base + _s_43213);
    _2 = (int)SEQ_PTR(_22965);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _22966 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _22966 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _22965 = NOVALUE;
    Ref(_22966);
    _53c_puts(_22966);
    _22966 = NOVALUE;

    /** 				c_printf("\", %d", SymTab[s][S_OBJ])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22968 = (int)*(((s1_ptr)_2)->base + _s_43213);
    _2 = (int)SEQ_PTR(_22968);
    _22969 = (int)*(((s1_ptr)_2)->base + 1);
    _22968 = NOVALUE;
    RefDS(_22967);
    Ref(_22969);
    _53c_printf(_22967, _22969);
    _22969 = NOVALUE;

    /** 				c_printf(", %d", seq_num)*/
    RefDS(_22896);
    _53c_printf(_22896, _seq_num_43215);

    /** 				c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22970 = (int)*(((s1_ptr)_2)->base + _s_43213);
    _2 = (int)SEQ_PTR(_22970);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _22971 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _22971 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _22970 = NOVALUE;
    RefDS(_22896);
    Ref(_22971);
    _53c_printf(_22896, _22971);
    _22971 = NOVALUE;

    /** 				c_puts("}")*/
    RefDS(_22912);
    _53c_puts(_22912);
L4: 

    /** 			seq_num += 1*/
    _seq_num_43215 = _seq_num_43215 + 1;
L3: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _22973 = (int)*(((s1_ptr)_2)->base + _s_43213);
    _2 = (int)SEQ_PTR(_22973);
    _s_43213 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43213)){
        _s_43213 = (long)DBL_PTR(_s_43213)->dbl;
    }
    _22973 = NOVALUE;

    /** 	end while*/
    goto L1; // [212] 50
L2: 

    /** 	if not first then*/
    if (_first_43214 != 0)
    goto L6; // [217] 226

    /** 		c_puts(",\n")*/
    RefDS(_22886);
    _53c_puts(_22886);
L6: 

    /** 	c_puts("  {\"\", 0, 999999999, 0}\n};\n\n")  -- end marker*/
    RefDS(_22976);
    _53c_puts(_22976);

    /** end procedure*/
    return;
    ;
}


int _56is_exported(int _s_43277)
{
    int _eentry_43278 = NOVALUE;
    int _scope_43281 = NOVALUE;
    int _22991 = NOVALUE;
    int _22990 = NOVALUE;
    int _22989 = NOVALUE;
    int _22988 = NOVALUE;
    int _22987 = NOVALUE;
    int _22986 = NOVALUE;
    int _22985 = NOVALUE;
    int _22984 = NOVALUE;
    int _22983 = NOVALUE;
    int _22982 = NOVALUE;
    int _22981 = NOVALUE;
    int _22979 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_43277)) {
        _1 = (long)(DBL_PTR(_s_43277)->dbl);
        DeRefDS(_s_43277);
        _s_43277 = _1;
    }

    /** 	sequence eentry = SymTab[s]*/
    DeRef(_eentry_43278);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _eentry_43278 = (int)*(((s1_ptr)_2)->base + _s_43277);
    Ref(_eentry_43278);

    /** 	integer scope = eentry[S_SCOPE]*/
    _2 = (int)SEQ_PTR(_eentry_43278);
    _scope_43281 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_43281))
    _scope_43281 = (long)DBL_PTR(_scope_43281)->dbl;

    /** 	if eentry[S_MODE] = M_NORMAL then*/
    _2 = (int)SEQ_PTR(_eentry_43278);
    _22979 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _22979, 1)){
        _22979 = NOVALUE;
        goto L1; // [31] 125
    }
    _22979 = NOVALUE;

    /** 		if eentry[S_FILE_NO] = 1 and find(scope, { SC_EXPORT, SC_PUBLIC, SC_GLOBAL }) then*/
    _2 = (int)SEQ_PTR(_eentry_43278);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _22981 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _22981 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    if (IS_ATOM_INT(_22981)) {
        _22982 = (_22981 == 1);
    }
    else {
        _22982 = binary_op(EQUALS, _22981, 1);
    }
    _22981 = NOVALUE;
    if (IS_ATOM_INT(_22982)) {
        if (_22982 == 0) {
            goto L2; // [47] 79
        }
    }
    else {
        if (DBL_PTR(_22982)->dbl == 0.0) {
            goto L2; // [47] 79
        }
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 11;
    *((int *)(_2+8)) = 13;
    *((int *)(_2+12)) = 6;
    _22984 = MAKE_SEQ(_1);
    _22985 = find_from(_scope_43281, _22984, 1);
    DeRefDS(_22984);
    _22984 = NOVALUE;
    if (_22985 == 0)
    {
        _22985 = NOVALUE;
        goto L2; // [69] 79
    }
    else{
        _22985 = NOVALUE;
    }

    /** 			return 1*/
    DeRef(_eentry_43278);
    DeRef(_22982);
    _22982 = NOVALUE;
    return 1;
L2: 

    /** 		if scope = SC_PUBLIC and*/
    _22986 = (_scope_43281 == 13);
    if (_22986 == 0) {
        goto L3; // [87] 124
    }
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _22988 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_eentry_43278);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _22989 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _22989 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _2 = (int)SEQ_PTR(_22988);
    if (!IS_ATOM_INT(_22989)){
        _22990 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22989)->dbl));
    }
    else{
        _22990 = (int)*(((s1_ptr)_2)->base + _22989);
    }
    _22988 = NOVALUE;
    if (IS_ATOM_INT(_22990)) {
        {unsigned long tu;
             tu = (unsigned long)_22990 & (unsigned long)4;
             _22991 = MAKE_UINT(tu);
        }
    }
    else {
        _22991 = binary_op(AND_BITS, _22990, 4);
    }
    _22990 = NOVALUE;
    if (_22991 == 0) {
        DeRef(_22991);
        _22991 = NOVALUE;
        goto L3; // [114] 124
    }
    else {
        if (!IS_ATOM_INT(_22991) && DBL_PTR(_22991)->dbl == 0.0){
            DeRef(_22991);
            _22991 = NOVALUE;
            goto L3; // [114] 124
        }
        DeRef(_22991);
        _22991 = NOVALUE;
    }
    DeRef(_22991);
    _22991 = NOVALUE;

    /** 			return 1*/
    DeRef(_eentry_43278);
    DeRef(_22986);
    _22986 = NOVALUE;
    DeRef(_22982);
    _22982 = NOVALUE;
    _22989 = NOVALUE;
    return 1;
L3: 
L1: 

    /** 	return 0*/
    DeRef(_eentry_43278);
    DeRef(_22986);
    _22986 = NOVALUE;
    DeRef(_22982);
    _22982 = NOVALUE;
    _22989 = NOVALUE;
    return 0;
    ;
}


void _56version()
{
    int _23025 = NOVALUE;
    int _23024 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c_puts("// Euphoria To C version " & version_string() & "\n")*/
    _23024 = _31version_string(0);
    {
        int concat_list[3];

        concat_list[0] = _22189;
        concat_list[1] = _23024;
        concat_list[2] = _23023;
        Concat_N((object_ptr)&_23025, concat_list, 3);
    }
    DeRef(_23024);
    _23024 = NOVALUE;
    _53c_puts(_23025);
    _23025 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _56new_c_file(int _name_43385)
{
    int _23028 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cfile_size = 0*/
    _26cfile_size_12062 = 0;

    /** 	if LAST_PASS = FALSE then*/
    if (_56LAST_PASS_41703 != _9FALSE_428)
    goto L1; // [16] 26

    /** 		return*/
    DeRefDS(_name_43385);
    return;
L1: 

    /** 	write_checksum( c_code )*/
    _54write_checksum(_53c_code_45530);

    /** 	close(c_code)*/
    EClose(_53c_code_45530);

    /** 	c_code = open(output_dir & name & ".c", "w")*/
    {
        int concat_list[3];

        concat_list[0] = _23027;
        concat_list[1] = _name_43385;
        concat_list[2] = _56output_dir_41729;
        Concat_N((object_ptr)&_23028, concat_list, 3);
    }
    _53c_code_45530 = EOpen(_23028, _22143, 0);
    DeRefDS(_23028);
    _23028 = NOVALUE;

    /** 	if c_code = -1 then*/
    if (_53c_code_45530 != -1)
    goto L2; // [60] 72

    /** 		CompileErr(57)*/
    RefDS(_22037);
    _43CompileErr(57, _22037, 0);
L2: 

    /** 	cfile_count += 1*/
    _26cfile_count_12061 = _26cfile_count_12061 + 1;

    /** 	version()*/
    _56version();

    /** 	c_puts("#include \"include/euphoria.h\"\n")*/
    RefDS(_22147);
    _53c_puts(_22147);

    /** 	c_puts("#include \"main-.h\"\n\n")*/
    RefDS(_22148);
    _53c_puts(_22148);

    /** 	if not TUNIX then*/

    /** 		name = lower(name)  -- for faster compare later*/
    RefDS(_name_43385);
    _0 = _name_43385;
    _name_43385 = _12lower(_name_43385);
    DeRefDS(_0);

    /** end procedure*/
    DeRefDS(_name_43385);
    return;
    ;
}


int _56unique_c_name(int _name_43414)
{
    int _i_43415 = NOVALUE;
    int _compare_name_43416 = NOVALUE;
    int _next_fc_43417 = NOVALUE;
    int _23044 = NOVALUE;
    int _23042 = NOVALUE;
    int _23041 = NOVALUE;
    int _23040 = NOVALUE;
    int _23038 = NOVALUE;
    int _0, _1, _2;
    

    /** 	compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_43416, _name_43414, _23027);

    /** 	if not TUNIX then*/

    /** 		compare_name = lower(compare_name)*/
    RefDS(_compare_name_43416);
    _0 = _compare_name_43416;
    _compare_name_43416 = _12lower(_compare_name_43416);
    DeRefDS(_0);

    /** 	next_fc = 1*/
    _next_fc_43417 = 1;

    /** 	i = 1*/
    _i_43415 = 1;

    /** 	while i <= length(generated_files) do*/
L1: 
    if (IS_SEQUENCE(_56generated_files_41720)){
            _23038 = SEQ_PTR(_56generated_files_41720)->length;
    }
    else {
        _23038 = 1;
    }
    if (_i_43415 > _23038)
    goto L2; // [45] 139

    /** 		if equal(generated_files[i], compare_name) then*/
    _2 = (int)SEQ_PTR(_56generated_files_41720);
    _23040 = (int)*(((s1_ptr)_2)->base + _i_43415);
    if (_23040 == _compare_name_43416)
    _23041 = 1;
    else if (IS_ATOM_INT(_23040) && IS_ATOM_INT(_compare_name_43416))
    _23041 = 0;
    else
    _23041 = (compare(_23040, _compare_name_43416) == 0);
    _23040 = NOVALUE;
    if (_23041 == 0)
    {
        _23041 = NOVALUE;
        goto L3; // [61] 127
    }
    else{
        _23041 = NOVALUE;
    }

    /** 			if next_fc > length(file_chars) then*/
    if (IS_SEQUENCE(_56file_chars_43410)){
            _23042 = SEQ_PTR(_56file_chars_43410)->length;
    }
    else {
        _23042 = 1;
    }
    if (_next_fc_43417 <= _23042)
    goto L4; // [69] 81

    /** 				CompileErr(140)*/
    RefDS(_22037);
    _43CompileErr(140, _22037, 0);
L4: 

    /** 			name[1] = file_chars[next_fc]*/
    _2 = (int)SEQ_PTR(_56file_chars_43410);
    _23044 = (int)*(((s1_ptr)_2)->base + _next_fc_43417);
    Ref(_23044);
    _2 = (int)SEQ_PTR(_name_43414);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _name_43414 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _23044;
    if( _1 != _23044 ){
        DeRef(_1);
    }
    _23044 = NOVALUE;

    /** 			compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_43416, _name_43414, _23027);

    /** 			if not TUNIX then*/

    /** 				compare_name = lower(compare_name)*/
    RefDS(_compare_name_43416);
    _0 = _compare_name_43416;
    _compare_name_43416 = _12lower(_compare_name_43416);
    DeRefDS(_0);

    /** 			next_fc += 1*/
    _next_fc_43417 = _next_fc_43417 + 1;

    /** 			i = 1 -- start over and compare again*/
    _i_43415 = 1;
    goto L1; // [124] 40
L3: 

    /** 			i += 1*/
    _i_43415 = _i_43415 + 1;

    /** 	end while*/
    goto L1; // [136] 40
L2: 

    /** 	return name*/
    DeRef(_compare_name_43416);
    return _name_43414;
    ;
}


int _56is_file_newer(int _f1_43446, int _f2_43447)
{
    int _d1_43448 = NOVALUE;
    int _d2_43451 = NOVALUE;
    int _diff_2__tmp_at42_43462 = NOVALUE;
    int _diff_1__tmp_at42_43461 = NOVALUE;
    int _diff_inlined_diff_at_42_43460 = NOVALUE;
    int _23054 = NOVALUE;
    int _23052 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object d1 = file_timestamp(f1)*/
    RefDS(_f1_43446);
    _0 = _d1_43448;
    _d1_43448 = _15file_timestamp(_f1_43446);
    DeRef(_0);

    /** 	object d2 = file_timestamp(f2)*/
    RefDS(_f2_43447);
    _0 = _d2_43451;
    _d2_43451 = _15file_timestamp(_f2_43447);
    DeRef(_0);

    /** 	if atom(d1) or atom(d2) then return 1 end if*/
    _23052 = IS_ATOM(_d1_43448);
    if (_23052 != 0) {
        goto L1; // [22] 34
    }
    _23054 = IS_ATOM(_d2_43451);
    if (_23054 == 0)
    {
        _23054 = NOVALUE;
        goto L2; // [30] 39
    }
    else{
        _23054 = NOVALUE;
    }
L1: 
    DeRefDS(_f1_43446);
    DeRefDS(_f2_43447);
    DeRef(_d1_43448);
    DeRef(_d2_43451);
    return 1;
L2: 

    /** 	if datetime:diff(d1, d2) < 0 then*/

    /** 	return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_43451);
    _0 = _diff_1__tmp_at42_43461;
    _diff_1__tmp_at42_43461 = _16datetimeToSeconds(_d2_43451);
    DeRef(_0);
    Ref(_d1_43448);
    _0 = _diff_2__tmp_at42_43462;
    _diff_2__tmp_at42_43462 = _16datetimeToSeconds(_d1_43448);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_42_43460);
    if (IS_ATOM_INT(_diff_1__tmp_at42_43461) && IS_ATOM_INT(_diff_2__tmp_at42_43462)) {
        _diff_inlined_diff_at_42_43460 = _diff_1__tmp_at42_43461 - _diff_2__tmp_at42_43462;
        if ((long)((unsigned long)_diff_inlined_diff_at_42_43460 +(unsigned long) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_42_43460 = NewDouble((double)_diff_inlined_diff_at_42_43460);
        }
    }
    else {
        _diff_inlined_diff_at_42_43460 = binary_op(MINUS, _diff_1__tmp_at42_43461, _diff_2__tmp_at42_43462);
    }
    DeRef(_diff_1__tmp_at42_43461);
    _diff_1__tmp_at42_43461 = NOVALUE;
    DeRef(_diff_2__tmp_at42_43462);
    _diff_2__tmp_at42_43462 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_42_43460, 0)){
        goto L3; // [58] 69
    }

    /** 		return 1*/
    DeRefDS(_f1_43446);
    DeRefDS(_f2_43447);
    DeRef(_d1_43448);
    DeRef(_d2_43451);
    return 1;
L3: 

    /** 	return 0*/
    DeRefDS(_f1_43446);
    DeRefDS(_f2_43447);
    DeRef(_d1_43448);
    DeRef(_d2_43451);
    return 0;
    ;
}


void _56add_file(int _filename_43466, int _eu_filename_43467)
{
    int _obj_fname_43487 = NOVALUE;
    int _src_fname_43488 = NOVALUE;
    int _23078 = NOVALUE;
    int _23077 = NOVALUE;
    int _23064 = NOVALUE;
    int _23063 = NOVALUE;
    int _23060 = NOVALUE;
    int _23059 = NOVALUE;
    int _23058 = NOVALUE;
    int _23057 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if equal("c", fileext(filename)) then*/
    RefDS(_filename_43466);
    _23057 = _15fileext(_filename_43466);
    if (_23056 == _23057)
    _23058 = 1;
    else if (IS_ATOM_INT(_23056) && IS_ATOM_INT(_23057))
    _23058 = 0;
    else
    _23058 = (compare(_23056, _23057) == 0);
    DeRef(_23057);
    _23057 = NOVALUE;
    if (_23058 == 0)
    {
        _23058 = NOVALUE;
        goto L1; // [15] 35
    }
    else{
        _23058 = NOVALUE;
    }

    /** 		filename = filename[1..$-2]*/
    if (IS_SEQUENCE(_filename_43466)){
            _23059 = SEQ_PTR(_filename_43466)->length;
    }
    else {
        _23059 = 1;
    }
    _23060 = _23059 - 2;
    _23059 = NOVALUE;
    rhs_slice_target = (object_ptr)&_filename_43466;
    RHS_Slice(_filename_43466, 1, _23060);
    goto L2; // [32] 82
L1: 

    /** 	elsif equal("h", fileext(filename)) then*/
    RefDS(_filename_43466);
    _23063 = _15fileext(_filename_43466);
    if (_23062 == _23063)
    _23064 = 1;
    else if (IS_ATOM_INT(_23062) && IS_ATOM_INT(_23063))
    _23064 = 0;
    else
    _23064 = (compare(_23062, _23063) == 0);
    DeRef(_23063);
    _23063 = NOVALUE;
    if (_23064 == 0)
    {
        _23064 = NOVALUE;
        goto L3; // [45] 81
    }
    else{
        _23064 = NOVALUE;
    }

    /** 		generated_files = append(generated_files, filename)*/
    RefDS(_filename_43466);
    Append(&_56generated_files_41720, _56generated_files_41720, _filename_43466);

    /** 		if build_system_type = BUILD_DIRECT then*/

    /** 			outdated_files  = append(outdated_files, 0)*/
    Append(&_56outdated_files_41721, _56outdated_files_41721, 0);

    /** 		return*/
    DeRefDS(_filename_43466);
    DeRefDS(_eu_filename_43467);
    DeRef(_obj_fname_43487);
    DeRef(_src_fname_43488);
    DeRef(_23060);
    _23060 = NOVALUE;
    return;
L3: 
L2: 

    /** 	sequence obj_fname = filename, src_fname = filename & ".c"*/
    RefDS(_filename_43466);
    DeRef(_obj_fname_43487);
    _obj_fname_43487 = _filename_43466;
    Concat((object_ptr)&_src_fname_43488, _filename_43466, _23027);

    /** 	if compiler_type = COMPILER_WATCOM then*/

    /** 		obj_fname &= ".o"*/
    Concat((object_ptr)&_obj_fname_43487, _obj_fname_43487, _23072);

    /** 	generated_files = append(generated_files, src_fname)*/
    RefDS(_src_fname_43488);
    Append(&_56generated_files_41720, _56generated_files_41720, _src_fname_43488);

    /** 	generated_files = append(generated_files, obj_fname)*/
    RefDS(_obj_fname_43487);
    Append(&_56generated_files_41720, _56generated_files_41720, _obj_fname_43487);

    /** 	if build_system_type = BUILD_DIRECT then*/

    /** 		outdated_files  = append(outdated_files, is_file_newer(eu_filename, output_dir & src_fname))*/
    Concat((object_ptr)&_23077, _56output_dir_41729, _src_fname_43488);
    RefDS(_eu_filename_43467);
    _23078 = _56is_file_newer(_eu_filename_43467, _23077);
    _23077 = NOVALUE;
    Ref(_23078);
    Append(&_56outdated_files_41721, _56outdated_files_41721, _23078);
    DeRef(_23078);
    _23078 = NOVALUE;

    /** 		outdated_files  = append(outdated_files, 0)*/
    Append(&_56outdated_files_41721, _56outdated_files_41721, 0);

    /** end procedure*/
    DeRefDS(_filename_43466);
    DeRefDS(_eu_filename_43467);
    DeRef(_obj_fname_43487);
    DeRef(_src_fname_43488);
    DeRef(_23060);
    _23060 = NOVALUE;
    return;
    ;
}


int _56any_code(int _file_no_43511)
{
    int _these_routines_43513 = NOVALUE;
    int _s_43520 = NOVALUE;
    int _23094 = NOVALUE;
    int _23093 = NOVALUE;
    int _23092 = NOVALUE;
    int _23091 = NOVALUE;
    int _23090 = NOVALUE;
    int _23089 = NOVALUE;
    int _23088 = NOVALUE;
    int _23087 = NOVALUE;
    int _23086 = NOVALUE;
    int _23085 = NOVALUE;
    int _23084 = NOVALUE;
    int _23082 = NOVALUE;
    int _0, _1, _2;
    

    /** 	check_file_routines()*/
    _56check_file_routines();

    /** 	sequence these_routines = file_routines[file_no]*/
    DeRef(_these_routines_43513);
    _2 = (int)SEQ_PTR(_56file_routines_43737);
    _these_routines_43513 = (int)*(((s1_ptr)_2)->base + _file_no_43511);
    Ref(_these_routines_43513);

    /** 	for i = 1 to length( these_routines ) do*/
    if (IS_SEQUENCE(_these_routines_43513)){
            _23082 = SEQ_PTR(_these_routines_43513)->length;
    }
    else {
        _23082 = 1;
    }
    {
        int _i_43517;
        _i_43517 = 1;
L1: 
        if (_i_43517 > _23082){
            goto L2; // [22] 126
        }

        /** 		symtab_index s = these_routines[i]*/
        _2 = (int)SEQ_PTR(_these_routines_43513);
        _s_43520 = (int)*(((s1_ptr)_2)->base + _i_43517);
        if (!IS_ATOM_INT(_s_43520)){
            _s_43520 = (long)DBL_PTR(_s_43520)->dbl;
        }

        /** 		if SymTab[s][S_FILE_NO] = file_no and*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _23084 = (int)*(((s1_ptr)_2)->base + _s_43520);
        _2 = (int)SEQ_PTR(_23084);
        if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
            _23085 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
        }
        else{
            _23085 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
        }
        _23084 = NOVALUE;
        if (IS_ATOM_INT(_23085)) {
            _23086 = (_23085 == _file_no_43511);
        }
        else {
            _23086 = binary_op(EQUALS, _23085, _file_no_43511);
        }
        _23085 = NOVALUE;
        if (IS_ATOM_INT(_23086)) {
            if (_23086 == 0) {
                DeRef(_23087);
                _23087 = 0;
                goto L3; // [55] 81
            }
        }
        else {
            if (DBL_PTR(_23086)->dbl == 0.0) {
                DeRef(_23087);
                _23087 = 0;
                goto L3; // [55] 81
            }
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _23088 = (int)*(((s1_ptr)_2)->base + _s_43520);
        _2 = (int)SEQ_PTR(_23088);
        _23089 = (int)*(((s1_ptr)_2)->base + 5);
        _23088 = NOVALUE;
        if (IS_ATOM_INT(_23089)) {
            _23090 = (_23089 != 99);
        }
        else {
            _23090 = binary_op(NOTEQ, _23089, 99);
        }
        _23089 = NOVALUE;
        DeRef(_23087);
        if (IS_ATOM_INT(_23090))
        _23087 = (_23090 != 0);
        else
        _23087 = DBL_PTR(_23090)->dbl != 0.0;
L3: 
        if (_23087 == 0) {
            goto L4; // [81] 117
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _23092 = (int)*(((s1_ptr)_2)->base + _s_43520);
        _2 = (int)SEQ_PTR(_23092);
        if (!IS_ATOM_INT(_26S_TOKEN_11659)){
            _23093 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
        }
        else{
            _23093 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
        }
        _23092 = NOVALUE;
        _23094 = find_from(_23093, _28RTN_TOKS_11602, 1);
        _23093 = NOVALUE;
        if (_23094 == 0)
        {
            _23094 = NOVALUE;
            goto L4; // [105] 117
        }
        else{
            _23094 = NOVALUE;
        }

        /** 			return TRUE -- found a non-deleted routine in this file*/
        DeRef(_these_routines_43513);
        DeRef(_23086);
        _23086 = NOVALUE;
        DeRef(_23090);
        _23090 = NOVALUE;
        return _9TRUE_430;
L4: 

        /** 	end for*/
        _i_43517 = _i_43517 + 1;
        goto L1; // [121] 29
L2: 
        ;
    }

    /** 	return FALSE*/
    DeRef(_these_routines_43513);
    DeRef(_23086);
    _23086 = NOVALUE;
    DeRef(_23090);
    _23090 = NOVALUE;
    return _9FALSE_428;
    ;
}


int _56legaldos_filename_char(int _i_43547)
{
    int _23109 = NOVALUE;
    int _23108 = NOVALUE;
    int _23105 = NOVALUE;
    int _23104 = NOVALUE;
    int _23103 = NOVALUE;
    int _23102 = NOVALUE;
    int _23101 = NOVALUE;
    int _23100 = NOVALUE;
    int _23099 = NOVALUE;
    int _23098 = NOVALUE;
    int _23097 = NOVALUE;
    int _23096 = NOVALUE;
    int _23095 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_i_43547)) {
        _1 = (long)(DBL_PTR(_i_43547)->dbl);
        DeRefDS(_i_43547);
        _i_43547 = _1;
    }

    /** 	if ('A' <= i and i <= 'Z') or*/
    _23095 = (65 <= _i_43547);
    if (_23095 == 0) {
        _23096 = 0;
        goto L1; // [9] 21
    }
    _23097 = (_i_43547 <= 90);
    _23096 = (_23097 != 0);
L1: 
    if (_23096 != 0) {
        _23098 = 1;
        goto L2; // [21] 45
    }
    _23099 = (48 <= _i_43547);
    if (_23099 == 0) {
        _23100 = 0;
        goto L3; // [29] 41
    }
    _23101 = (_i_43547 <= 57);
    _23100 = (_23101 != 0);
L3: 
    _23098 = (_23100 != 0);
L2: 
    if (_23098 != 0) {
        _23102 = 1;
        goto L4; // [45] 69
    }
    _23103 = (128 <= _i_43547);
    if (_23103 == 0) {
        _23104 = 0;
        goto L5; // [53] 65
    }
    _23105 = (_i_43547 <= 255);
    _23104 = (_23105 != 0);
L5: 
    _23102 = (_23104 != 0);
L4: 
    if (_23102 != 0) {
        goto L6; // [69] 87
    }
    _23108 = find_from(_i_43547, _23107, 1);
    _23109 = (_23108 != 0);
    _23108 = NOVALUE;
    if (_23109 == 0)
    {
        DeRef(_23109);
        _23109 = NOVALUE;
        goto L7; // [83] 96
    }
    else{
        DeRef(_23109);
        _23109 = NOVALUE;
    }
L6: 

    /** 		return 1*/
    DeRef(_23095);
    _23095 = NOVALUE;
    DeRef(_23097);
    _23097 = NOVALUE;
    DeRef(_23099);
    _23099 = NOVALUE;
    DeRef(_23101);
    _23101 = NOVALUE;
    DeRef(_23103);
    _23103 = NOVALUE;
    DeRef(_23105);
    _23105 = NOVALUE;
    return 1;
    goto L8; // [93] 103
L7: 

    /** 		return 0*/
    DeRef(_23095);
    _23095 = NOVALUE;
    DeRef(_23097);
    _23097 = NOVALUE;
    DeRef(_23099);
    _23099 = NOVALUE;
    DeRef(_23101);
    _23101 = NOVALUE;
    DeRef(_23103);
    _23103 = NOVALUE;
    DeRef(_23105);
    _23105 = NOVALUE;
    return 0;
L8: 
    ;
}


int _56legaldos_filename(int _s_43567)
{
    int _dloc_43568 = NOVALUE;
    int _23136 = NOVALUE;
    int _23135 = NOVALUE;
    int _23133 = NOVALUE;
    int _23132 = NOVALUE;
    int _23131 = NOVALUE;
    int _23130 = NOVALUE;
    int _23128 = NOVALUE;
    int _23127 = NOVALUE;
    int _23126 = NOVALUE;
    int _23125 = NOVALUE;
    int _23124 = NOVALUE;
    int _23123 = NOVALUE;
    int _23121 = NOVALUE;
    int _23120 = NOVALUE;
    int _23119 = NOVALUE;
    int _23118 = NOVALUE;
    int _23117 = NOVALUE;
    int _23116 = NOVALUE;
    int _23115 = NOVALUE;
    int _23113 = NOVALUE;
    int _23112 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if find( s, { "..", "." } ) then*/
    RefDS(_23111);
    RefDS(_23110);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23110;
    ((int *)_2)[2] = _23111;
    _23112 = MAKE_SEQ(_1);
    _23113 = find_from(_s_43567, _23112, 1);
    DeRefDS(_23112);
    _23112 = NOVALUE;
    if (_23113 == 0)
    {
        _23113 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _23113 = NOVALUE;
    }

    /** 		return 1*/
    DeRefDS(_s_43567);
    return 1;
L1: 

    /** 	dloc = find('.',s)*/
    _dloc_43568 = find_from(46, _s_43567, 1);

    /** 	if dloc > 8 or ( dloc > 0 and dloc + 3 < length(s) ) or ( dloc = 0 and length(s) > 8 ) then*/
    _23115 = (_dloc_43568 > 8);
    if (_23115 != 0) {
        _23116 = 1;
        goto L2; // [37] 68
    }
    _23117 = (_dloc_43568 > 0);
    if (_23117 == 0) {
        _23118 = 0;
        goto L3; // [45] 64
    }
    _23119 = _dloc_43568 + 3;
    if (IS_SEQUENCE(_s_43567)){
            _23120 = SEQ_PTR(_s_43567)->length;
    }
    else {
        _23120 = 1;
    }
    _23121 = (_23119 < _23120);
    _23119 = NOVALUE;
    _23120 = NOVALUE;
    _23118 = (_23121 != 0);
L3: 
    _23116 = (_23118 != 0);
L2: 
    if (_23116 != 0) {
        goto L4; // [68] 96
    }
    _23123 = (_dloc_43568 == 0);
    if (_23123 == 0) {
        DeRef(_23124);
        _23124 = 0;
        goto L5; // [76] 91
    }
    if (IS_SEQUENCE(_s_43567)){
            _23125 = SEQ_PTR(_s_43567)->length;
    }
    else {
        _23125 = 1;
    }
    _23126 = (_23125 > 8);
    _23125 = NOVALUE;
    _23124 = (_23126 != 0);
L5: 
    if (_23124 == 0)
    {
        _23124 = NOVALUE;
        goto L6; // [92] 103
    }
    else{
        _23124 = NOVALUE;
    }
L4: 

    /** 		return 0*/
    DeRefDS(_s_43567);
    DeRef(_23115);
    _23115 = NOVALUE;
    DeRef(_23117);
    _23117 = NOVALUE;
    DeRef(_23123);
    _23123 = NOVALUE;
    DeRef(_23121);
    _23121 = NOVALUE;
    DeRef(_23126);
    _23126 = NOVALUE;
    return 0;
L6: 

    /** 	for i = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_43567)){
            _23127 = SEQ_PTR(_s_43567)->length;
    }
    else {
        _23127 = 1;
    }
    {
        int _i_43589;
        _i_43589 = 1;
L7: 
        if (_i_43589 > _23127){
            goto L8; // [108] 200
        }

        /** 		if s[i] = '.' then*/
        _2 = (int)SEQ_PTR(_s_43567);
        _23128 = (int)*(((s1_ptr)_2)->base + _i_43589);
        if (binary_op_a(NOTEQ, _23128, 46)){
            _23128 = NOVALUE;
            goto L9; // [121] 173
        }
        _23128 = NOVALUE;

        /** 			for j = i+1 to length(s) do*/
        _23130 = _i_43589 + 1;
        if (IS_SEQUENCE(_s_43567)){
                _23131 = SEQ_PTR(_s_43567)->length;
        }
        else {
            _23131 = 1;
        }
        {
            int _j_43595;
            _j_43595 = _23130;
LA: 
            if (_j_43595 > _23131){
                goto LB; // [134] 168
            }

            /** 				if not legaldos_filename_char(s[j]) then*/
            _2 = (int)SEQ_PTR(_s_43567);
            _23132 = (int)*(((s1_ptr)_2)->base + _j_43595);
            Ref(_23132);
            _23133 = _56legaldos_filename_char(_23132);
            _23132 = NOVALUE;
            if (IS_ATOM_INT(_23133)) {
                if (_23133 != 0){
                    DeRef(_23133);
                    _23133 = NOVALUE;
                    goto LC; // [151] 161
                }
            }
            else {
                if (DBL_PTR(_23133)->dbl != 0.0){
                    DeRef(_23133);
                    _23133 = NOVALUE;
                    goto LC; // [151] 161
                }
            }
            DeRef(_23133);
            _23133 = NOVALUE;

            /** 					return 0*/
            DeRefDS(_s_43567);
            DeRef(_23115);
            _23115 = NOVALUE;
            DeRef(_23117);
            _23117 = NOVALUE;
            DeRef(_23123);
            _23123 = NOVALUE;
            DeRef(_23121);
            _23121 = NOVALUE;
            DeRef(_23126);
            _23126 = NOVALUE;
            DeRef(_23130);
            _23130 = NOVALUE;
            return 0;
LC: 

            /** 			end for*/
            _j_43595 = _j_43595 + 1;
            goto LA; // [163] 141
LB: 
            ;
        }

        /** 			exit*/
        goto L8; // [170] 200
L9: 

        /** 		if not legaldos_filename_char(s[i]) then*/
        _2 = (int)SEQ_PTR(_s_43567);
        _23135 = (int)*(((s1_ptr)_2)->base + _i_43589);
        Ref(_23135);
        _23136 = _56legaldos_filename_char(_23135);
        _23135 = NOVALUE;
        if (IS_ATOM_INT(_23136)) {
            if (_23136 != 0){
                DeRef(_23136);
                _23136 = NOVALUE;
                goto LD; // [183] 193
            }
        }
        else {
            if (DBL_PTR(_23136)->dbl != 0.0){
                DeRef(_23136);
                _23136 = NOVALUE;
                goto LD; // [183] 193
            }
        }
        DeRef(_23136);
        _23136 = NOVALUE;

        /** 			return 0*/
        DeRefDS(_s_43567);
        DeRef(_23115);
        _23115 = NOVALUE;
        DeRef(_23117);
        _23117 = NOVALUE;
        DeRef(_23123);
        _23123 = NOVALUE;
        DeRef(_23121);
        _23121 = NOVALUE;
        DeRef(_23126);
        _23126 = NOVALUE;
        DeRef(_23130);
        _23130 = NOVALUE;
        return 0;
LD: 

        /** 	end for*/
        _i_43589 = _i_43589 + 1;
        goto L7; // [195] 115
L8: 
        ;
    }

    /** 	return 1*/
    DeRefDS(_s_43567);
    DeRef(_23115);
    _23115 = NOVALUE;
    DeRef(_23117);
    _23117 = NOVALUE;
    DeRef(_23123);
    _23123 = NOVALUE;
    DeRef(_23121);
    _23121 = NOVALUE;
    DeRef(_23126);
    _23126 = NOVALUE;
    DeRef(_23130);
    _23130 = NOVALUE;
    return 1;
    ;
}


int _56shrink_to_83(int _s_43608)
{
    int _dl_43609 = NOVALUE;
    int _sl_43610 = NOVALUE;
    int _osl_43611 = NOVALUE;
    int _se_43612 = NOVALUE;
    int _23217 = NOVALUE;
    int _23216 = NOVALUE;
    int _23215 = NOVALUE;
    int _23214 = NOVALUE;
    int _23213 = NOVALUE;
    int _23212 = NOVALUE;
    int _23211 = NOVALUE;
    int _23210 = NOVALUE;
    int _23209 = NOVALUE;
    int _23208 = NOVALUE;
    int _23206 = NOVALUE;
    int _23205 = NOVALUE;
    int _23204 = NOVALUE;
    int _23203 = NOVALUE;
    int _23201 = NOVALUE;
    int _23200 = NOVALUE;
    int _23199 = NOVALUE;
    int _23198 = NOVALUE;
    int _23195 = NOVALUE;
    int _23194 = NOVALUE;
    int _23193 = NOVALUE;
    int _23190 = NOVALUE;
    int _23189 = NOVALUE;
    int _23188 = NOVALUE;
    int _23186 = NOVALUE;
    int _23185 = NOVALUE;
    int _23184 = NOVALUE;
    int _23183 = NOVALUE;
    int _23181 = NOVALUE;
    int _23180 = NOVALUE;
    int _23178 = NOVALUE;
    int _23177 = NOVALUE;
    int _23175 = NOVALUE;
    int _23174 = NOVALUE;
    int _23173 = NOVALUE;
    int _23172 = NOVALUE;
    int _23171 = NOVALUE;
    int _23170 = NOVALUE;
    int _23169 = NOVALUE;
    int _23168 = NOVALUE;
    int _23167 = NOVALUE;
    int _23166 = NOVALUE;
    int _23164 = NOVALUE;
    int _23163 = NOVALUE;
    int _23162 = NOVALUE;
    int _23159 = NOVALUE;
    int _23158 = NOVALUE;
    int _23157 = NOVALUE;
    int _23156 = NOVALUE;
    int _23153 = NOVALUE;
    int _23152 = NOVALUE;
    int _23151 = NOVALUE;
    int _23149 = NOVALUE;
    int _23148 = NOVALUE;
    int _23147 = NOVALUE;
    int _23146 = NOVALUE;
    int _23144 = NOVALUE;
    int _23142 = NOVALUE;
    int _23141 = NOVALUE;
    int _23140 = NOVALUE;
    int _23139 = NOVALUE;
    int _0, _1, _2;
    

    /** 	osl = find( ':', s )*/
    _osl_43611 = find_from(58, _s_43608, 1);

    /** 	sl = osl + find( '\\', s[osl+1..$] ) -- find_from osl*/
    _23139 = _osl_43611 + 1;
    if (IS_SEQUENCE(_s_43608)){
            _23140 = SEQ_PTR(_s_43608)->length;
    }
    else {
        _23140 = 1;
    }
    rhs_slice_target = (object_ptr)&_23141;
    RHS_Slice(_s_43608, _23139, _23140);
    _23142 = find_from(92, _23141, 1);
    DeRefDS(_23141);
    _23141 = NOVALUE;
    _sl_43610 = _osl_43611 + _23142;
    _23142 = NOVALUE;

    /** 	if sl=osl+1 then*/
    _23144 = _osl_43611 + 1;
    if (_sl_43610 != _23144)
    goto L1; // [39] 49

    /** 		osl = sl*/
    _osl_43611 = _sl_43610;
L1: 

    /** 	sl = osl + find( '\\', s[osl+1..$] )*/
    _23146 = _osl_43611 + 1;
    if (_23146 > MAXINT){
        _23146 = NewDouble((double)_23146);
    }
    if (IS_SEQUENCE(_s_43608)){
            _23147 = SEQ_PTR(_s_43608)->length;
    }
    else {
        _23147 = 1;
    }
    rhs_slice_target = (object_ptr)&_23148;
    RHS_Slice(_s_43608, _23146, _23147);
    _23149 = find_from(92, _23148, 1);
    DeRefDS(_23148);
    _23148 = NOVALUE;
    _sl_43610 = _osl_43611 + _23149;
    _23149 = NOVALUE;

    /** 	dl = osl + find( '.', s[osl+1..sl] )*/
    _23151 = _osl_43611 + 1;
    rhs_slice_target = (object_ptr)&_23152;
    RHS_Slice(_s_43608, _23151, _sl_43610);
    _23153 = find_from(46, _23152, 1);
    DeRefDS(_23152);
    _23152 = NOVALUE;
    _dl_43609 = _osl_43611 + _23153;
    _23153 = NOVALUE;

    /** 	if dl > osl then*/
    if (_dl_43609 <= _osl_43611)
    goto L2; // [94] 124

    /** 		se = s[dl..min({dl+3,sl-1})]*/
    _23156 = _dl_43609 + 3;
    if ((long)((unsigned long)_23156 + (unsigned long)HIGH_BITS) >= 0) 
    _23156 = NewDouble((double)_23156);
    _23157 = _sl_43610 - 1;
    if ((long)((unsigned long)_23157 +(unsigned long) HIGH_BITS) >= 0){
        _23157 = NewDouble((double)_23157);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23156;
    ((int *)_2)[2] = _23157;
    _23158 = MAKE_SEQ(_1);
    _23157 = NOVALUE;
    _23156 = NOVALUE;
    _23159 = _20min(_23158);
    _23158 = NOVALUE;
    rhs_slice_target = (object_ptr)&_se_43612;
    RHS_Slice(_s_43608, _dl_43609, _23159);
    goto L3; // [121] 132
L2: 

    /** 		se = ""*/
    RefDS(_22037);
    DeRef(_se_43612);
    _se_43612 = _22037;
L3: 

    /** 	while sl != osl do*/
L4: 
    if (_sl_43610 == _osl_43611)
    goto L5; // [137] 333

    /** 		if find( ' ', s[osl+1..sl] ) or not legaldos_filename(upper(s[osl+1..sl-1])) then*/
    _23162 = _osl_43611 + 1;
    rhs_slice_target = (object_ptr)&_23163;
    RHS_Slice(_s_43608, _23162, _sl_43610);
    _23164 = find_from(32, _23163, 1);
    DeRefDS(_23163);
    _23163 = NOVALUE;
    if (_23164 != 0) {
        goto L6; // [157] 190
    }
    _23166 = _osl_43611 + 1;
    if (_23166 > MAXINT){
        _23166 = NewDouble((double)_23166);
    }
    _23167 = _sl_43610 - 1;
    rhs_slice_target = (object_ptr)&_23168;
    RHS_Slice(_s_43608, _23166, _23167);
    _23169 = _12upper(_23168);
    _23168 = NOVALUE;
    _23170 = _56legaldos_filename(_23169);
    _23169 = NOVALUE;
    if (IS_ATOM_INT(_23170)) {
        _23171 = (_23170 == 0);
    }
    else {
        _23171 = unary_op(NOT, _23170);
    }
    DeRef(_23170);
    _23170 = NOVALUE;
    if (_23171 == 0) {
        DeRef(_23171);
        _23171 = NOVALUE;
        goto L7; // [186] 244
    }
    else {
        if (!IS_ATOM_INT(_23171) && DBL_PTR(_23171)->dbl == 0.0){
            DeRef(_23171);
            _23171 = NOVALUE;
            goto L7; // [186] 244
        }
        DeRef(_23171);
        _23171 = NOVALUE;
    }
    DeRef(_23171);
    _23171 = NOVALUE;
L6: 

    /** 			s = s[1..osl] & s[osl+1..osl+6] & "~1" & se & s[sl..$]*/
    rhs_slice_target = (object_ptr)&_23172;
    RHS_Slice(_s_43608, 1, _osl_43611);
    _23173 = _osl_43611 + 1;
    if (_23173 > MAXINT){
        _23173 = NewDouble((double)_23173);
    }
    _23174 = _osl_43611 + 6;
    rhs_slice_target = (object_ptr)&_23175;
    RHS_Slice(_s_43608, _23173, _23174);
    if (IS_SEQUENCE(_s_43608)){
            _23177 = SEQ_PTR(_s_43608)->length;
    }
    else {
        _23177 = 1;
    }
    rhs_slice_target = (object_ptr)&_23178;
    RHS_Slice(_s_43608, _sl_43610, _23177);
    {
        int concat_list[5];

        concat_list[0] = _23178;
        concat_list[1] = _se_43612;
        concat_list[2] = _23176;
        concat_list[3] = _23175;
        concat_list[4] = _23172;
        Concat_N((object_ptr)&_s_43608, concat_list, 5);
    }
    DeRefDS(_23178);
    _23178 = NOVALUE;
    DeRefDS(_23175);
    _23175 = NOVALUE;
    DeRefDS(_23172);
    _23172 = NOVALUE;

    /** 			sl = osl+8+length(se)*/
    _23180 = _osl_43611 + 8;
    if ((long)((unsigned long)_23180 + (unsigned long)HIGH_BITS) >= 0) 
    _23180 = NewDouble((double)_23180);
    if (IS_SEQUENCE(_se_43612)){
            _23181 = SEQ_PTR(_se_43612)->length;
    }
    else {
        _23181 = 1;
    }
    if (IS_ATOM_INT(_23180)) {
        _sl_43610 = _23180 + _23181;
    }
    else {
        _sl_43610 = NewDouble(DBL_PTR(_23180)->dbl + (double)_23181);
    }
    DeRef(_23180);
    _23180 = NOVALUE;
    _23181 = NOVALUE;
    if (!IS_ATOM_INT(_sl_43610)) {
        _1 = (long)(DBL_PTR(_sl_43610)->dbl);
        DeRefDS(_sl_43610);
        _sl_43610 = _1;
    }
L7: 

    /** 		osl = sl*/
    _osl_43611 = _sl_43610;

    /** 		sl += find( '\\', s[sl+1..$] )*/
    _23183 = _sl_43610 + 1;
    if (_23183 > MAXINT){
        _23183 = NewDouble((double)_23183);
    }
    if (IS_SEQUENCE(_s_43608)){
            _23184 = SEQ_PTR(_s_43608)->length;
    }
    else {
        _23184 = 1;
    }
    rhs_slice_target = (object_ptr)&_23185;
    RHS_Slice(_s_43608, _23183, _23184);
    _23186 = find_from(92, _23185, 1);
    DeRefDS(_23185);
    _23185 = NOVALUE;
    _sl_43610 = _sl_43610 + _23186;
    _23186 = NOVALUE;

    /** 		dl = osl + find( '.', s[osl+1..sl] )*/
    _23188 = _osl_43611 + 1;
    rhs_slice_target = (object_ptr)&_23189;
    RHS_Slice(_s_43608, _23188, _sl_43610);
    _23190 = find_from(46, _23189, 1);
    DeRefDS(_23189);
    _23189 = NOVALUE;
    _dl_43609 = _osl_43611 + _23190;
    _23190 = NOVALUE;

    /** 		if dl > osl then*/
    if (_dl_43609 <= _osl_43611)
    goto L8; // [294] 320

    /** 			se = s[dl..min({dl+3,sl})]*/
    _23193 = _dl_43609 + 3;
    if ((long)((unsigned long)_23193 + (unsigned long)HIGH_BITS) >= 0) 
    _23193 = NewDouble((double)_23193);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23193;
    ((int *)_2)[2] = _sl_43610;
    _23194 = MAKE_SEQ(_1);
    _23193 = NOVALUE;
    _23195 = _20min(_23194);
    _23194 = NOVALUE;
    rhs_slice_target = (object_ptr)&_se_43612;
    RHS_Slice(_s_43608, _dl_43609, _23195);
    goto L4; // [317] 137
L8: 

    /** 			se = ""*/
    RefDS(_22037);
    DeRef(_se_43612);
    _se_43612 = _22037;

    /** 	end while*/
    goto L4; // [330] 137
L5: 

    /** 	if dl > osl then*/
    if (_dl_43609 <= _osl_43611)
    goto L9; // [335] 362

    /** 		se = s[dl..min({dl+3,length(s)})]*/
    _23198 = _dl_43609 + 3;
    if ((long)((unsigned long)_23198 + (unsigned long)HIGH_BITS) >= 0) 
    _23198 = NewDouble((double)_23198);
    if (IS_SEQUENCE(_s_43608)){
            _23199 = SEQ_PTR(_s_43608)->length;
    }
    else {
        _23199 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23198;
    ((int *)_2)[2] = _23199;
    _23200 = MAKE_SEQ(_1);
    _23199 = NOVALUE;
    _23198 = NOVALUE;
    _23201 = _20min(_23200);
    _23200 = NOVALUE;
    rhs_slice_target = (object_ptr)&_se_43612;
    RHS_Slice(_s_43608, _dl_43609, _23201);
L9: 

    /** 	if find( ' ', s[osl+1..$] ) or not legaldos_filename(upper(s[osl+1..$])) then*/
    _23203 = _osl_43611 + 1;
    if (_23203 > MAXINT){
        _23203 = NewDouble((double)_23203);
    }
    if (IS_SEQUENCE(_s_43608)){
            _23204 = SEQ_PTR(_s_43608)->length;
    }
    else {
        _23204 = 1;
    }
    rhs_slice_target = (object_ptr)&_23205;
    RHS_Slice(_s_43608, _23203, _23204);
    _23206 = find_from(32, _23205, 1);
    DeRefDS(_23205);
    _23205 = NOVALUE;
    if (_23206 != 0) {
        goto LA; // [381] 413
    }
    _23208 = _osl_43611 + 1;
    if (_23208 > MAXINT){
        _23208 = NewDouble((double)_23208);
    }
    if (IS_SEQUENCE(_s_43608)){
            _23209 = SEQ_PTR(_s_43608)->length;
    }
    else {
        _23209 = 1;
    }
    rhs_slice_target = (object_ptr)&_23210;
    RHS_Slice(_s_43608, _23208, _23209);
    _23211 = _12upper(_23210);
    _23210 = NOVALUE;
    _23212 = _56legaldos_filename(_23211);
    _23211 = NOVALUE;
    if (IS_ATOM_INT(_23212)) {
        _23213 = (_23212 == 0);
    }
    else {
        _23213 = unary_op(NOT, _23212);
    }
    DeRef(_23212);
    _23212 = NOVALUE;
    if (_23213 == 0) {
        DeRef(_23213);
        _23213 = NOVALUE;
        goto LB; // [409] 443
    }
    else {
        if (!IS_ATOM_INT(_23213) && DBL_PTR(_23213)->dbl == 0.0){
            DeRef(_23213);
            _23213 = NOVALUE;
            goto LB; // [409] 443
        }
        DeRef(_23213);
        _23213 = NOVALUE;
    }
    DeRef(_23213);
    _23213 = NOVALUE;
LA: 

    /** 		s = s[1..osl] & s[osl+1..osl+6] & "~1" & se*/
    rhs_slice_target = (object_ptr)&_23214;
    RHS_Slice(_s_43608, 1, _osl_43611);
    _23215 = _osl_43611 + 1;
    if (_23215 > MAXINT){
        _23215 = NewDouble((double)_23215);
    }
    _23216 = _osl_43611 + 6;
    rhs_slice_target = (object_ptr)&_23217;
    RHS_Slice(_s_43608, _23215, _23216);
    {
        int concat_list[4];

        concat_list[0] = _se_43612;
        concat_list[1] = _23176;
        concat_list[2] = _23217;
        concat_list[3] = _23214;
        Concat_N((object_ptr)&_s_43608, concat_list, 4);
    }
    DeRefDS(_23217);
    _23217 = NOVALUE;
    DeRefDS(_23214);
    _23214 = NOVALUE;
LB: 

    /** 	return s*/
    DeRef(_se_43612);
    DeRef(_23139);
    _23139 = NOVALUE;
    DeRef(_23144);
    _23144 = NOVALUE;
    DeRef(_23146);
    _23146 = NOVALUE;
    DeRef(_23151);
    _23151 = NOVALUE;
    DeRef(_23162);
    _23162 = NOVALUE;
    DeRef(_23159);
    _23159 = NOVALUE;
    DeRef(_23166);
    _23166 = NOVALUE;
    DeRef(_23167);
    _23167 = NOVALUE;
    DeRef(_23183);
    _23183 = NOVALUE;
    DeRef(_23173);
    _23173 = NOVALUE;
    DeRef(_23174);
    _23174 = NOVALUE;
    DeRef(_23188);
    _23188 = NOVALUE;
    DeRef(_23203);
    _23203 = NOVALUE;
    DeRef(_23195);
    _23195 = NOVALUE;
    DeRef(_23201);
    _23201 = NOVALUE;
    DeRef(_23208);
    _23208 = NOVALUE;
    DeRef(_23215);
    _23215 = NOVALUE;
    DeRef(_23216);
    _23216 = NOVALUE;
    return _s_43608;
    ;
}


int _56truncate_to_83(int _lfn_43710)
{
    int _dl_43711 = NOVALUE;
    int _23238 = NOVALUE;
    int _23237 = NOVALUE;
    int _23236 = NOVALUE;
    int _23235 = NOVALUE;
    int _23234 = NOVALUE;
    int _23233 = NOVALUE;
    int _23232 = NOVALUE;
    int _23231 = NOVALUE;
    int _23230 = NOVALUE;
    int _23229 = NOVALUE;
    int _23228 = NOVALUE;
    int _23227 = NOVALUE;
    int _23226 = NOVALUE;
    int _23225 = NOVALUE;
    int _23224 = NOVALUE;
    int _23223 = NOVALUE;
    int _23222 = NOVALUE;
    int _23221 = NOVALUE;
    int _23220 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer dl = find( '.', lfn )*/
    _dl_43711 = find_from(46, _lfn_43710, 1);

    /** 	if dl = 0 and length(lfn) > 8 then*/
    _23220 = (_dl_43711 == 0);
    if (_23220 == 0) {
        goto L1; // [16] 45
    }
    if (IS_SEQUENCE(_lfn_43710)){
            _23222 = SEQ_PTR(_lfn_43710)->length;
    }
    else {
        _23222 = 1;
    }
    _23223 = (_23222 > 8);
    _23222 = NOVALUE;
    if (_23223 == 0)
    {
        DeRef(_23223);
        _23223 = NOVALUE;
        goto L1; // [28] 45
    }
    else{
        DeRef(_23223);
        _23223 = NOVALUE;
    }

    /** 		return lfn[1..8]*/
    rhs_slice_target = (object_ptr)&_23224;
    RHS_Slice(_lfn_43710, 1, 8);
    DeRefDS(_lfn_43710);
    DeRef(_23220);
    _23220 = NOVALUE;
    return _23224;
    goto L2; // [42] 138
L1: 

    /** 	elsif dl = 0 and length(lfn) <= 8 then*/
    _23225 = (_dl_43711 == 0);
    if (_23225 == 0) {
        goto L3; // [51] 75
    }
    if (IS_SEQUENCE(_lfn_43710)){
            _23227 = SEQ_PTR(_lfn_43710)->length;
    }
    else {
        _23227 = 1;
    }
    _23228 = (_23227 <= 8);
    _23227 = NOVALUE;
    if (_23228 == 0)
    {
        DeRef(_23228);
        _23228 = NOVALUE;
        goto L3; // [63] 75
    }
    else{
        DeRef(_23228);
        _23228 = NOVALUE;
    }

    /** 		return lfn*/
    DeRef(_23220);
    _23220 = NOVALUE;
    DeRef(_23224);
    _23224 = NOVALUE;
    DeRef(_23225);
    _23225 = NOVALUE;
    return _lfn_43710;
    goto L2; // [72] 138
L3: 

    /** 	elsif dl > 9 and dl + 3 <= length(lfn) then*/
    _23229 = (_dl_43711 > 9);
    if (_23229 == 0) {
        goto L4; // [81] 126
    }
    _23231 = _dl_43711 + 3;
    if ((long)((unsigned long)_23231 + (unsigned long)HIGH_BITS) >= 0) 
    _23231 = NewDouble((double)_23231);
    if (IS_SEQUENCE(_lfn_43710)){
            _23232 = SEQ_PTR(_lfn_43710)->length;
    }
    else {
        _23232 = 1;
    }
    if (IS_ATOM_INT(_23231)) {
        _23233 = (_23231 <= _23232);
    }
    else {
        _23233 = (DBL_PTR(_23231)->dbl <= (double)_23232);
    }
    DeRef(_23231);
    _23231 = NOVALUE;
    _23232 = NOVALUE;
    if (_23233 == 0)
    {
        DeRef(_23233);
        _23233 = NOVALUE;
        goto L4; // [97] 126
    }
    else{
        DeRef(_23233);
        _23233 = NOVALUE;
    }

    /** 		return lfn[1..8] & lfn[dl..$]*/
    rhs_slice_target = (object_ptr)&_23234;
    RHS_Slice(_lfn_43710, 1, 8);
    if (IS_SEQUENCE(_lfn_43710)){
            _23235 = SEQ_PTR(_lfn_43710)->length;
    }
    else {
        _23235 = 1;
    }
    rhs_slice_target = (object_ptr)&_23236;
    RHS_Slice(_lfn_43710, _dl_43711, _23235);
    Concat((object_ptr)&_23237, _23234, _23236);
    DeRefDS(_23234);
    _23234 = NOVALUE;
    DeRef(_23234);
    _23234 = NOVALUE;
    DeRefDS(_23236);
    _23236 = NOVALUE;
    DeRefDS(_lfn_43710);
    DeRef(_23220);
    _23220 = NOVALUE;
    DeRef(_23224);
    _23224 = NOVALUE;
    DeRef(_23225);
    _23225 = NOVALUE;
    DeRef(_23229);
    _23229 = NOVALUE;
    return _23237;
    goto L2; // [123] 138
L4: 

    /** 		CompileErr( 48, {lfn})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_lfn_43710);
    *((int *)(_2+4)) = _lfn_43710;
    _23238 = MAKE_SEQ(_1);
    _43CompileErr(48, _23238, 0);
    _23238 = NOVALUE;
L2: 
    ;
}


void _56check_file_routines()
{
    int _s_43746 = NOVALUE;
    int _23256 = NOVALUE;
    int _23255 = NOVALUE;
    int _23254 = NOVALUE;
    int _23253 = NOVALUE;
    int _23252 = NOVALUE;
    int _23251 = NOVALUE;
    int _23250 = NOVALUE;
    int _23249 = NOVALUE;
    int _23248 = NOVALUE;
    int _23247 = NOVALUE;
    int _23246 = NOVALUE;
    int _23245 = NOVALUE;
    int _23243 = NOVALUE;
    int _23241 = NOVALUE;
    int _23239 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length( file_routines ) then*/
    if (IS_SEQUENCE(_56file_routines_43737)){
            _23239 = SEQ_PTR(_56file_routines_43737)->length;
    }
    else {
        _23239 = 1;
    }
    if (_23239 != 0)
    goto L1; // [8] 146
    _23239 = NOVALUE;

    /** 		file_routines = repeat( {}, length( known_files ) )*/
    if (IS_SEQUENCE(_27known_files_10922)){
            _23241 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _23241 = 1;
    }
    DeRefDS(_56file_routines_43737);
    _56file_routines_43737 = Repeat(_22037, _23241);
    _23241 = NOVALUE;

    /** 		integer s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _23243 = (int)*(((s1_ptr)_2)->base + _26TopLevelSub_11989);
    _2 = (int)SEQ_PTR(_23243);
    _s_43746 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43746)){
        _s_43746 = (long)DBL_PTR(_s_43746)->dbl;
    }
    _23243 = NOVALUE;

    /** 		while s do*/
L2: 
    if (_s_43746 == 0)
    {
        goto L3; // [45] 145
    }
    else{
    }

    /** 			if SymTab[s][S_USAGE] != U_DELETED and*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _23245 = (int)*(((s1_ptr)_2)->base + _s_43746);
    _2 = (int)SEQ_PTR(_23245);
    _23246 = (int)*(((s1_ptr)_2)->base + 5);
    _23245 = NOVALUE;
    if (IS_ATOM_INT(_23246)) {
        _23247 = (_23246 != 99);
    }
    else {
        _23247 = binary_op(NOTEQ, _23246, 99);
    }
    _23246 = NOVALUE;
    if (IS_ATOM_INT(_23247)) {
        if (_23247 == 0) {
            goto L4; // [68] 124
        }
    }
    else {
        if (DBL_PTR(_23247)->dbl == 0.0) {
            goto L4; // [68] 124
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _23249 = (int)*(((s1_ptr)_2)->base + _s_43746);
    _2 = (int)SEQ_PTR(_23249);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _23250 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _23250 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _23249 = NOVALUE;
    _23251 = find_from(_23250, _28RTN_TOKS_11602, 1);
    _23250 = NOVALUE;
    if (_23251 == 0)
    {
        _23251 = NOVALUE;
        goto L4; // [92] 124
    }
    else{
        _23251 = NOVALUE;
    }

    /** 				file_routines[SymTab[s][S_FILE_NO]] &= s*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _23252 = (int)*(((s1_ptr)_2)->base + _s_43746);
    _2 = (int)SEQ_PTR(_23252);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _23253 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _23253 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _23252 = NOVALUE;
    _2 = (int)SEQ_PTR(_56file_routines_43737);
    if (!IS_ATOM_INT(_23253)){
        _23254 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_23253)->dbl));
    }
    else{
        _23254 = (int)*(((s1_ptr)_2)->base + _23253);
    }
    if (IS_SEQUENCE(_23254) && IS_ATOM(_s_43746)) {
        Append(&_23255, _23254, _s_43746);
    }
    else if (IS_ATOM(_23254) && IS_SEQUENCE(_s_43746)) {
    }
    else {
        Concat((object_ptr)&_23255, _23254, _s_43746);
        _23254 = NOVALUE;
    }
    _23254 = NOVALUE;
    _2 = (int)SEQ_PTR(_56file_routines_43737);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _56file_routines_43737 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_23253))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_23253)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _23253);
    _1 = *(int *)_2;
    *(int *)_2 = _23255;
    if( _1 != _23255 ){
        DeRef(_1);
    }
    _23255 = NOVALUE;
L4: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _23256 = (int)*(((s1_ptr)_2)->base + _s_43746);
    _2 = (int)SEQ_PTR(_23256);
    _s_43746 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43746)){
        _s_43746 = (long)DBL_PTR(_s_43746)->dbl;
    }
    _23256 = NOVALUE;

    /** 		end while*/
    goto L2; // [142] 45
L3: 
L1: 

    /** end procedure*/
    _23253 = NOVALUE;
    DeRef(_23247);
    _23247 = NOVALUE;
    return;
    ;
}


void _56GenerateUserRoutines()
{
    int _s_43780 = NOVALUE;
    int _sp_43781 = NOVALUE;
    int _next_c_char_43782 = NOVALUE;
    int _q_43783 = NOVALUE;
    int _temps_43784 = NOVALUE;
    int _buff_43785 = NOVALUE;
    int _base_name_43786 = NOVALUE;
    int _long_c_file_43787 = NOVALUE;
    int _c_file_43788 = NOVALUE;
    int _these_routines_43855 = NOVALUE;
    int _ret_type_43913 = NOVALUE;
    int _scope_43984 = NOVALUE;
    int _names_44018 = NOVALUE;
    int _name_44028 = NOVALUE;
    int _23469 = NOVALUE;
    int _23467 = NOVALUE;
    int _23466 = NOVALUE;
    int _23436 = NOVALUE;
    int _23435 = NOVALUE;
    int _23434 = NOVALUE;
    int _23432 = NOVALUE;
    int _23430 = NOVALUE;
    int _23429 = NOVALUE;
    int _23428 = NOVALUE;
    int _23427 = NOVALUE;
    int _23426 = NOVALUE;
    int _23425 = NOVALUE;
    int _23424 = NOVALUE;
    int _23422 = NOVALUE;
    int _23421 = NOVALUE;
    int _23420 = NOVALUE;
    int _23419 = NOVALUE;
    int _23418 = NOVALUE;
    int _23417 = NOVALUE;
    int _23416 = NOVALUE;
    int _23415 = NOVALUE;
    int _23413 = NOVALUE;
    int _23412 = NOVALUE;
    int _23410 = NOVALUE;
    int _23409 = NOVALUE;
    int _23408 = NOVALUE;
    int _23407 = NOVALUE;
    int _23406 = NOVALUE;
    int _23405 = NOVALUE;
    int _23404 = NOVALUE;
    int _23403 = NOVALUE;
    int _23401 = NOVALUE;
    int _23400 = NOVALUE;
    int _23398 = NOVALUE;
    int _23397 = NOVALUE;
    int _23396 = NOVALUE;
    int _23394 = NOVALUE;
    int _23391 = NOVALUE;
    int _23390 = NOVALUE;
    int _23388 = NOVALUE;
    int _23386 = NOVALUE;
    int _23380 = NOVALUE;
    int _23379 = NOVALUE;
    int _23378 = NOVALUE;
    int _23377 = NOVALUE;
    int _23376 = NOVALUE;
    int _23375 = NOVALUE;
    int _23374 = NOVALUE;
    int _23373 = NOVALUE;
    int _23371 = NOVALUE;
    int _23370 = NOVALUE;
    int _23368 = NOVALUE;
    int _23367 = NOVALUE;
    int _23364 = NOVALUE;
    int _23362 = NOVALUE;
    int _23361 = NOVALUE;
    int _23360 = NOVALUE;
    int _23356 = NOVALUE;
    int _23353 = NOVALUE;
    int _23350 = NOVALUE;
    int _23349 = NOVALUE;
    int _23348 = NOVALUE;
    int _23347 = NOVALUE;
    int _23345 = NOVALUE;
    int _23344 = NOVALUE;
    int _23342 = NOVALUE;
    int _23341 = NOVALUE;
    int _23340 = NOVALUE;
    int _23338 = NOVALUE;
    int _23335 = NOVALUE;
    int _23334 = NOVALUE;
    int _23333 = NOVALUE;
    int _23332 = NOVALUE;
    int _23331 = NOVALUE;
    int _23330 = NOVALUE;
    int _23328 = NOVALUE;
    int _23327 = NOVALUE;
    int _23325 = NOVALUE;
    int _23322 = NOVALUE;
    int _23321 = NOVALUE;
    int _23317 = NOVALUE;
    int _23316 = NOVALUE;
    int _23314 = NOVALUE;
    int _23310 = NOVALUE;
    int _23309 = NOVALUE;
    int _23308 = NOVALUE;
    int _23307 = NOVALUE;
    int _23306 = NOVALUE;
    int _23305 = NOVALUE;
    int _23304 = NOVALUE;
    int _23303 = NOVALUE;
    int _23302 = NOVALUE;
    int _23301 = NOVALUE;
    int _23300 = NOVALUE;
    int _23299 = NOVALUE;
    int _23298 = NOVALUE;
    int _23297 = NOVALUE;
    int _23295 = NOVALUE;
    int _23294 = NOVALUE;
    int _23292 = NOVALUE;
    int _23289 = NOVALUE;
    int _23286 = NOVALUE;
    int _23283 = NOVALUE;
    int _23280 = NOVALUE;
    int _23279 = NOVALUE;
    int _23278 = NOVALUE;
    int _23275 = NOVALUE;
    int _23272 = NOVALUE;
    int _23270 = NOVALUE;
    int _23266 = NOVALUE;
    int _23265 = NOVALUE;
    int _23263 = NOVALUE;
    int _23262 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer next_c_char, q, temps*/

    /** 	sequence buff, base_name, long_c_file, c_file*/

    /** 	if not silent then*/
    if (_26silent_12098 != 0)
    goto L1; // [9] 62

    /** 		if Pass = 1 then*/
    if (_56Pass_41705 != 1)
    goto L2; // [16] 29

    /** 			ShowMsg(1, 239,,0)*/
    RefDS(_22037);
    _44ShowMsg(1, 239, _22037, 0);
L2: 

    /** 		if LAST_PASS = TRUE then*/
    if (_56LAST_PASS_41703 != _9TRUE_430)
    goto L3; // [35] 50

    /** 			ShowMsg(1, 240)*/
    RefDS(_22037);
    _44ShowMsg(1, 240, _22037, 1);
    goto L4; // [47] 61
L3: 

    /** 			ShowMsg(1, 241, Pass, 0)*/
    _44ShowMsg(1, 241, _56Pass_41705, 0);
L4: 
L1: 

    /** 	check_file_routines()*/
    _56check_file_routines();

    /** 	c_puts("// GenerateUserRoutines\n")*/
    RefDS(_23261);
    _53c_puts(_23261);

    /** 	for file_no = 1 to length(known_files) do*/
    if (IS_SEQUENCE(_27known_files_10922)){
            _23262 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _23262 = 1;
    }
    {
        int _file_no_43804;
        _file_no_43804 = 1;
L5: 
        if (_file_no_43804 > _23262){
            goto L6; // [78] 2060
        }

        /** 		if file_no = 1 or any_code(file_no) then*/
        _23263 = (_file_no_43804 == 1);
        if (_23263 != 0) {
            goto L7; // [91] 104
        }
        _23265 = _56any_code(_file_no_43804);
        if (_23265 == 0) {
            DeRef(_23265);
            _23265 = NOVALUE;
            goto L8; // [100] 2051
        }
        else {
            if (!IS_ATOM_INT(_23265) && DBL_PTR(_23265)->dbl == 0.0){
                DeRef(_23265);
                _23265 = NOVALUE;
                goto L8; // [100] 2051
            }
            DeRef(_23265);
            _23265 = NOVALUE;
        }
        DeRef(_23265);
        _23265 = NOVALUE;
L7: 

        /** 			next_c_char = 1*/
        _next_c_char_43782 = 1;

        /** 			base_name = name_ext(known_files[file_no])*/
        _2 = (int)SEQ_PTR(_27known_files_10922);
        _23266 = (int)*(((s1_ptr)_2)->base + _file_no_43804);
        Ref(_23266);
        _0 = _base_name_43786;
        _base_name_43786 = _52name_ext(_23266);
        DeRef(_0);
        _23266 = NOVALUE;

        /** 			c_file = base_name*/
        RefDS(_base_name_43786);
        DeRef(_c_file_43788);
        _c_file_43788 = _base_name_43786;

        /** 			q = length(c_file)*/
        if (IS_SEQUENCE(_c_file_43788)){
                _q_43783 = SEQ_PTR(_c_file_43788)->length;
        }
        else {
            _q_43783 = 1;
        }

        /** 			while q >= 1 do*/
L9: 
        if (_q_43783 < 1)
        goto LA; // [140] 181

        /** 				if c_file[q] = '.' then*/
        _2 = (int)SEQ_PTR(_c_file_43788);
        _23270 = (int)*(((s1_ptr)_2)->base + _q_43783);
        if (binary_op_a(NOTEQ, _23270, 46)){
            _23270 = NOVALUE;
            goto LB; // [150] 170
        }
        _23270 = NOVALUE;

        /** 					c_file = c_file[1..q-1]*/
        _23272 = _q_43783 - 1;
        rhs_slice_target = (object_ptr)&_c_file_43788;
        RHS_Slice(_c_file_43788, 1, _23272);

        /** 					exit*/
        goto LA; // [167] 181
LB: 

        /** 				q -= 1*/
        _q_43783 = _q_43783 - 1;

        /** 			end while*/
        goto L9; // [178] 140
LA: 

        /** 			if find(lower(c_file), {"main-", "init-"})  then*/
        RefDS(_c_file_43788);
        _23275 = _12lower(_c_file_43788);
        RefDS(_23277);
        RefDS(_23276);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _23276;
        ((int *)_2)[2] = _23277;
        _23278 = MAKE_SEQ(_1);
        _23279 = find_from(_23275, _23278, 1);
        DeRef(_23275);
        _23275 = NOVALUE;
        DeRefDS(_23278);
        _23278 = NOVALUE;
        if (_23279 == 0)
        {
            _23279 = NOVALUE;
            goto LC; // [196] 211
        }
        else{
            _23279 = NOVALUE;
        }

        /** 				CompileErr(12, {base_name})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_base_name_43786);
        *((int *)(_2+4)) = _base_name_43786;
        _23280 = MAKE_SEQ(_1);
        _43CompileErr(12, _23280, 0);
        _23280 = NOVALUE;
LC: 

        /** 			long_c_file = c_file*/
        RefDS(_c_file_43788);
        DeRef(_long_c_file_43787);
        _long_c_file_43787 = _c_file_43788;

        /** 			if LAST_PASS = TRUE then*/
        if (_56LAST_PASS_41703 != _9TRUE_430)
        goto LD; // [224] 249

        /** 				c_file = unique_c_name(c_file)*/
        RefDS(_c_file_43788);
        _0 = _c_file_43788;
        _c_file_43788 = _56unique_c_name(_c_file_43788);
        DeRefDS(_0);

        /** 				add_file(c_file, known_files[file_no])*/
        _2 = (int)SEQ_PTR(_27known_files_10922);
        _23283 = (int)*(((s1_ptr)_2)->base + _file_no_43804);
        RefDS(_c_file_43788);
        Ref(_23283);
        _56add_file(_c_file_43788, _23283);
        _23283 = NOVALUE;
LD: 

        /** 			if file_no = 1 then*/
        if (_file_no_43804 != 1)
        goto LE; // [251] 314

        /** 				if LAST_PASS = TRUE then*/
        if (_56LAST_PASS_41703 != _9TRUE_430)
        goto LF; // [261] 306

        /** 					add_file("main-")*/
        RefDS(_23276);
        RefDS(_22037);
        _56add_file(_23276, _22037);

        /** 					for i = 0 to main_name_num-1 do*/
        _23286 = _53main_name_num_45532 - 1;
        if ((long)((unsigned long)_23286 +(unsigned long) HIGH_BITS) >= 0){
            _23286 = NewDouble((double)_23286);
        }
        {
            int _i_43845;
            _i_43845 = 0;
L10: 
            if (binary_op_a(GREATER, _i_43845, _23286)){
                goto L11; // [279] 305
            }

            /** 						buff = sprintf("main-%d", i)*/
            DeRefi(_buff_43785);
            _buff_43785 = EPrintf(-9999999, _23287, _i_43845);

            /** 						add_file(buff)*/
            RefDS(_buff_43785);
            RefDS(_22037);
            _56add_file(_buff_43785, _22037);

            /** 					end for*/
            _0 = _i_43845;
            if (IS_ATOM_INT(_i_43845)) {
                _i_43845 = _i_43845 + 1;
                if ((long)((unsigned long)_i_43845 +(unsigned long) HIGH_BITS) >= 0){
                    _i_43845 = NewDouble((double)_i_43845);
                }
            }
            else {
                _i_43845 = binary_op_a(PLUS, _i_43845, 1);
            }
            DeRef(_0);
            goto L10; // [300] 286
L11: 
            ;
            DeRef(_i_43845);
        }
LF: 

        /** 				file0 = long_c_file*/
        RefDS(_long_c_file_43787);
        DeRef(_56file0_43544);
        _56file0_43544 = _long_c_file_43787;
LE: 

        /** 			new_c_file(c_file)*/
        RefDS(_c_file_43788);
        _56new_c_file(_c_file_43788);

        /** 			s = SymTab[TopLevelSub][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _23289 = (int)*(((s1_ptr)_2)->base + _26TopLevelSub_11989);
        _2 = (int)SEQ_PTR(_23289);
        _s_43780 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_43780)){
            _s_43780 = (long)DBL_PTR(_s_43780)->dbl;
        }
        _23289 = NOVALUE;

        /** 			sequence these_routines = file_routines[file_no]*/
        DeRef(_these_routines_43855);
        _2 = (int)SEQ_PTR(_56file_routines_43737);
        _these_routines_43855 = (int)*(((s1_ptr)_2)->base + _file_no_43804);
        Ref(_these_routines_43855);

        /** 			for routine_no = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_43855)){
                _23292 = SEQ_PTR(_these_routines_43855)->length;
        }
        else {
            _23292 = 1;
        }
        {
            int _routine_no_43858;
            _routine_no_43858 = 1;
L12: 
            if (_routine_no_43858 > _23292){
                goto L13; // [352] 2050
            }

            /** 				s = these_routines[routine_no]*/
            _2 = (int)SEQ_PTR(_these_routines_43855);
            _s_43780 = (int)*(((s1_ptr)_2)->base + _routine_no_43858);
            if (!IS_ATOM_INT(_s_43780)){
                _s_43780 = (long)DBL_PTR(_s_43780)->dbl;
            }

            /** 				if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _23294 = (int)*(((s1_ptr)_2)->base + _s_43780);
            _2 = (int)SEQ_PTR(_23294);
            _23295 = (int)*(((s1_ptr)_2)->base + 5);
            _23294 = NOVALUE;
            if (binary_op_a(EQUALS, _23295, 99)){
                _23295 = NOVALUE;
                goto L14; // [383] 2041
            }
            _23295 = NOVALUE;

            /** 					if LAST_PASS = TRUE and*/
            _23297 = (_56LAST_PASS_41703 == _9TRUE_430);
            if (_23297 == 0) {
                goto L15; // [397] 593
            }
            _23299 = (_26cfile_size_12062 > 100000);
            if (_23299 != 0) {
                DeRef(_23300);
                _23300 = 1;
                goto L16; // [409] 472
            }
            _23301 = (_s_43780 != _26TopLevelSub_11989);
            if (_23301 == 0) {
                _23302 = 0;
                goto L17; // [419] 439
            }
            _23303 = (100000 % 4) ? NewDouble((double)100000 / 4) : (100000 / 4);
            if (IS_ATOM_INT(_23303)) {
                _23304 = (_26cfile_size_12062 > _23303);
            }
            else {
                _23304 = ((double)_26cfile_size_12062 > DBL_PTR(_23303)->dbl);
            }
            DeRef(_23303);
            _23303 = NOVALUE;
            _23302 = (_23304 != 0);
L17: 
            if (_23302 == 0) {
                _23305 = 0;
                goto L18; // [439] 468
            }
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _23306 = (int)*(((s1_ptr)_2)->base + _s_43780);
            _2 = (int)SEQ_PTR(_23306);
            if (!IS_ATOM_INT(_26S_CODE_11666)){
                _23307 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
            }
            else{
                _23307 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
            }
            _23306 = NOVALUE;
            if (IS_SEQUENCE(_23307)){
                    _23308 = SEQ_PTR(_23307)->length;
            }
            else {
                _23308 = 1;
            }
            _23307 = NOVALUE;
            _23309 = (_23308 > 100000);
            _23308 = NOVALUE;
            _23305 = (_23309 != 0);
L18: 
            DeRef(_23300);
            _23300 = (_23305 != 0);
L16: 
            if (_23300 == 0)
            {
                _23300 = NOVALUE;
                goto L15; // [473] 593
            }
            else{
                _23300 = NOVALUE;
            }

            /** 						if length(c_file) = 7 then*/
            if (IS_SEQUENCE(_c_file_43788)){
                    _23310 = SEQ_PTR(_c_file_43788)->length;
            }
            else {
                _23310 = 1;
            }
            if (_23310 != 7)
            goto L19; // [481] 492

            /** 							c_file &= " "*/
            Concat((object_ptr)&_c_file_43788, _c_file_43788, _23312);
L19: 

            /** 						if length(c_file) >= 8 then*/
            if (IS_SEQUENCE(_c_file_43788)){
                    _23314 = SEQ_PTR(_c_file_43788)->length;
            }
            else {
                _23314 = 1;
            }
            if (_23314 < 8)
            goto L1A; // [497] 520

            /** 							c_file[7] = '_'*/
            _2 = (int)SEQ_PTR(_c_file_43788);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _c_file_43788 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 7);
            _1 = *(int *)_2;
            *(int *)_2 = 95;
            DeRef(_1);

            /** 							c_file[8] = file_chars[next_c_char]*/
            _2 = (int)SEQ_PTR(_56file_chars_43410);
            _23316 = (int)*(((s1_ptr)_2)->base + _next_c_char_43782);
            Ref(_23316);
            _2 = (int)SEQ_PTR(_c_file_43788);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _c_file_43788 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 8);
            _1 = *(int *)_2;
            *(int *)_2 = _23316;
            if( _1 != _23316 ){
                DeRef(_1);
            }
            _23316 = NOVALUE;
            goto L1B; // [517] 552
L1A: 

            /** 							if find('_', c_file) = 0 then*/
            _23317 = find_from(95, _c_file_43788, 1);
            if (_23317 != 0)
            goto L1C; // [527] 538

            /** 								c_file &= "_ "*/
            Concat((object_ptr)&_c_file_43788, _c_file_43788, _23319);
L1C: 

            /** 							c_file[$] = file_chars[next_c_char]*/
            if (IS_SEQUENCE(_c_file_43788)){
                    _23321 = SEQ_PTR(_c_file_43788)->length;
            }
            else {
                _23321 = 1;
            }
            _2 = (int)SEQ_PTR(_56file_chars_43410);
            _23322 = (int)*(((s1_ptr)_2)->base + _next_c_char_43782);
            Ref(_23322);
            _2 = (int)SEQ_PTR(_c_file_43788);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _c_file_43788 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _23321);
            _1 = *(int *)_2;
            *(int *)_2 = _23322;
            if( _1 != _23322 ){
                DeRef(_1);
            }
            _23322 = NOVALUE;
L1B: 

            /** 						c_file = unique_c_name(c_file)*/
            RefDS(_c_file_43788);
            _0 = _c_file_43788;
            _c_file_43788 = _56unique_c_name(_c_file_43788);
            DeRefDS(_0);

            /** 						new_c_file(c_file)*/
            RefDS(_c_file_43788);
            _56new_c_file(_c_file_43788);

            /** 						next_c_char += 1*/
            _next_c_char_43782 = _next_c_char_43782 + 1;

            /** 						if next_c_char > length(file_chars) then*/
            if (IS_SEQUENCE(_56file_chars_43410)){
                    _23325 = SEQ_PTR(_56file_chars_43410)->length;
            }
            else {
                _23325 = 1;
            }
            if (_next_c_char_43782 <= _23325)
            goto L1D; // [576] 586

            /** 							next_c_char = 1  -- (unique_c_name will resolve)*/
            _next_c_char_43782 = 1;
L1D: 

            /** 						add_file(c_file)*/
            RefDS(_c_file_43788);
            RefDS(_22037);
            _56add_file(_c_file_43788, _22037);
L15: 

            /** 					sequence ret_type*/

            /** 					if SymTab[s][S_TOKEN] = PROC then*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _23327 = (int)*(((s1_ptr)_2)->base + _s_43780);
            _2 = (int)SEQ_PTR(_23327);
            if (!IS_ATOM_INT(_26S_TOKEN_11659)){
                _23328 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
            }
            else{
                _23328 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
            }
            _23327 = NOVALUE;
            if (binary_op_a(NOTEQ, _23328, 27)){
                _23328 = NOVALUE;
                goto L1E; // [611] 625
            }
            _23328 = NOVALUE;

            /** 						ret_type = "void "*/
            RefDS(_22749);
            DeRefi(_ret_type_43913);
            _ret_type_43913 = _22749;
            goto L1F; // [622] 633
L1E: 

            /** 						ret_type = "int "*/
            RefDS(_22750);
            DeRefi(_ret_type_43913);
            _ret_type_43913 = _22750;
L1F: 

            /** 					if find( SymTab[s][S_SCOPE], {SC_GLOBAL, SC_EXPORT, SC_PUBLIC} ) and dll_option then*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _23330 = (int)*(((s1_ptr)_2)->base + _s_43780);
            _2 = (int)SEQ_PTR(_23330);
            _23331 = (int)*(((s1_ptr)_2)->base + 4);
            _23330 = NOVALUE;
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            *((int *)(_2+4)) = 6;
            *((int *)(_2+8)) = 11;
            *((int *)(_2+12)) = 13;
            _23332 = MAKE_SEQ(_1);
            _23333 = find_from(_23331, _23332, 1);
            _23331 = NOVALUE;
            DeRefDS(_23332);
            _23332 = NOVALUE;
            if (_23333 == 0) {
                goto L20; // [664] 740
            }
            if (_56dll_option_41716 == 0)
            {
                goto L20; // [671] 740
            }
            else{
            }

            /** 						SymTab[s][S_RI_TARGET] = TRUE*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _27SymTab_10921 = MAKE_SEQ(_2);
            }
            _3 = (int)(_s_43780 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 53);
            _1 = *(int *)_2;
            *(int *)_2 = _9TRUE_430;
            DeRef(_1);
            _23335 = NOVALUE;

            /** 						LeftSym = TRUE*/
            _56LeftSym_41713 = _9TRUE_430;

            /** 						if TWINDOWS then*/
            if (_36TWINDOWS_14305 == 0)
            {
                goto L21; // [704] 723
            }
            else{
            }

            /** 							c_stmt(ret_type & " __stdcall @(", s)*/
            Concat((object_ptr)&_23338, _ret_type_43913, _23337);
            _56c_stmt(_23338, _s_43780, 0);
            _23338 = NOVALUE;
            goto L22; // [720] 763
L21: 

            /** 							c_stmt(ret_type & "@(", s)*/
            Concat((object_ptr)&_23340, _ret_type_43913, _23339);
            _56c_stmt(_23340, _s_43780, 0);
            _23340 = NOVALUE;
            goto L22; // [737] 763
L20: 

            /** 						LeftSym = TRUE*/
            _56LeftSym_41713 = _9TRUE_430;

            /** 						c_stmt( ret_type & "@(", s)*/
            Concat((object_ptr)&_23341, _ret_type_43913, _23339);
            _56c_stmt(_23341, _s_43780, 0);
            _23341 = NOVALUE;
L22: 

            /** 					sp = SymTab[s][S_NEXT]*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _23342 = (int)*(((s1_ptr)_2)->base + _s_43780);
            _2 = (int)SEQ_PTR(_23342);
            _sp_43781 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_43781)){
                _sp_43781 = (long)DBL_PTR(_sp_43781)->dbl;
            }
            _23342 = NOVALUE;

            /** 					for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _23344 = (int)*(((s1_ptr)_2)->base + _s_43780);
            _2 = (int)SEQ_PTR(_23344);
            if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
                _23345 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
            }
            else{
                _23345 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
            }
            _23344 = NOVALUE;
            {
                int _p_43954;
                _p_43954 = 1;
L23: 
                if (binary_op_a(GREATER, _p_43954, _23345)){
                    goto L24; // [793] 869
                }

                /** 						c_puts("int _")*/
                RefDS(_23346);
                _53c_puts(_23346);

                /** 						c_puts(SymTab[sp][S_NAME])*/
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                _23347 = (int)*(((s1_ptr)_2)->base + _sp_43781);
                _2 = (int)SEQ_PTR(_23347);
                if (!IS_ATOM_INT(_26S_NAME_11654)){
                    _23348 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
                }
                else{
                    _23348 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
                }
                _23347 = NOVALUE;
                Ref(_23348);
                _53c_puts(_23348);
                _23348 = NOVALUE;

                /** 						if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                _23349 = (int)*(((s1_ptr)_2)->base + _s_43780);
                _2 = (int)SEQ_PTR(_23349);
                if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
                    _23350 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
                }
                else{
                    _23350 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
                }
                _23349 = NOVALUE;
                if (binary_op_a(EQUALS, _p_43954, _23350)){
                    _23350 = NOVALUE;
                    goto L25; // [836] 846
                }
                _23350 = NOVALUE;

                /** 							c_puts(", ")*/
                RefDS(_23352);
                _53c_puts(_23352);
L25: 

                /** 						sp = SymTab[sp][S_NEXT]*/
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                _23353 = (int)*(((s1_ptr)_2)->base + _sp_43781);
                _2 = (int)SEQ_PTR(_23353);
                _sp_43781 = (int)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_43781)){
                    _sp_43781 = (long)DBL_PTR(_sp_43781)->dbl;
                }
                _23353 = NOVALUE;

                /** 					end for*/
                _0 = _p_43954;
                if (IS_ATOM_INT(_p_43954)) {
                    _p_43954 = _p_43954 + 1;
                    if ((long)((unsigned long)_p_43954 +(unsigned long) HIGH_BITS) >= 0){
                        _p_43954 = NewDouble((double)_p_43954);
                    }
                }
                else {
                    _p_43954 = binary_op_a(PLUS, _p_43954, 1);
                }
                DeRef(_0);
                goto L23; // [864] 800
L24: 
                ;
                DeRef(_p_43954);
            }

            /** 					c_puts(")\n")*/
            RefDS(_23355);
            _53c_puts(_23355);

            /** 					c_stmt0("{\n")*/
            RefDS(_22194);
            _56c_stmt0(_22194);

            /** 					NewBB(0, E_ALL_EFFECT, 0)*/
            _56NewBB(0, 1073741823, 0);

            /** 					Initializing = TRUE*/
            _26Initializing_12063 = _9TRUE_430;

            /** 					while sp do*/
L26: 
            if (_sp_43781 == 0)
            {
                goto L27; // [902] 1041
            }
            else{
            }

            /** 						integer scope = SymTab[sp][S_SCOPE]*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _23356 = (int)*(((s1_ptr)_2)->base + _sp_43781);
            _2 = (int)SEQ_PTR(_23356);
            _scope_43984 = (int)*(((s1_ptr)_2)->base + 4);
            if (!IS_ATOM_INT(_scope_43984)){
                _scope_43984 = (long)DBL_PTR(_scope_43984)->dbl;
            }
            _23356 = NOVALUE;

            /** 						switch scope with fallthru do*/
            _0 = _scope_43984;
            switch ( _0 ){ 

                /** 							case SC_LOOP_VAR, SC_UNDEFINED then*/
                case 2:
                case 9:

                /** 								break*/
                goto L28; // [936] 1018

                /** 							case SC_PRIVATE then*/
                case 3:

                /** 								c_stmt0("int ")*/
                RefDS(_22750);
                _56c_stmt0(_22750);

                /** 								c_puts("_")*/
                RefDS(_22109);
                _53c_puts(_22109);

                /** 								c_puts(SymTab[sp][S_NAME])*/
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                _23360 = (int)*(((s1_ptr)_2)->base + _sp_43781);
                _2 = (int)SEQ_PTR(_23360);
                if (!IS_ATOM_INT(_26S_NAME_11654)){
                    _23361 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
                }
                else{
                    _23361 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
                }
                _23360 = NOVALUE;
                Ref(_23361);
                _53c_puts(_23361);
                _23361 = NOVALUE;

                /** 								c_puts(" = NOVALUE;\n")*/
                RefDS(_22757);
                _53c_puts(_22757);

                /** 								target[MIN] = NOVALUE*/
                Ref(_26NOVALUE_11836);
                _2 = (int)SEQ_PTR(_57target_27494);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _57target_27494 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 1);
                _1 = *(int *)_2;
                *(int *)_2 = _26NOVALUE_11836;
                DeRef(_1);

                /** 								target[MAX] = NOVALUE*/
                Ref(_26NOVALUE_11836);
                _2 = (int)SEQ_PTR(_57target_27494);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _57target_27494 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 2);
                _1 = *(int *)_2;
                *(int *)_2 = _26NOVALUE_11836;
                DeRef(_1);

                /** 								RemoveFromBB( sp )*/
                _56RemoveFromBB(_sp_43781);

                /** 								break*/
                goto L28; // [1005] 1018

                /** 							case else*/
                default:

                /** 								exit*/
                goto L27; // [1015] 1041
            ;}L28: 

            /** 						sp = SymTab[sp][S_NEXT]*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _23362 = (int)*(((s1_ptr)_2)->base + _sp_43781);
            _2 = (int)SEQ_PTR(_23362);
            _sp_43781 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_43781)){
                _sp_43781 = (long)DBL_PTR(_sp_43781)->dbl;
            }
            _23362 = NOVALUE;

            /** 					end while*/
            goto L26; // [1038] 902
L27: 

            /** 					temps = SymTab[s][S_TEMPS]*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _23364 = (int)*(((s1_ptr)_2)->base + _s_43780);
            _2 = (int)SEQ_PTR(_23364);
            if (!IS_ATOM_INT(_26S_TEMPS_11699)){
                _temps_43784 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TEMPS_11699)->dbl));
            }
            else{
                _temps_43784 = (int)*(((s1_ptr)_2)->base + _26S_TEMPS_11699);
            }
            if (!IS_ATOM_INT(_temps_43784)){
                _temps_43784 = (long)DBL_PTR(_temps_43784)->dbl;
            }
            _23364 = NOVALUE;

            /** 					sequence names = {}*/
            RefDS(_22037);
            DeRef(_names_44018);
            _names_44018 = _22037;

            /** 					while temps != 0 do*/
L29: 
            if (_temps_43784 == 0)
            goto L2A; // [1069] 1261

            /** 						if SymTab[temps][S_SCOPE] != DELETED then*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _23367 = (int)*(((s1_ptr)_2)->base + _temps_43784);
            _2 = (int)SEQ_PTR(_23367);
            _23368 = (int)*(((s1_ptr)_2)->base + 4);
            _23367 = NOVALUE;
            if (binary_op_a(EQUALS, _23368, 2)){
                _23368 = NOVALUE;
                goto L2B; // [1089] 1221
            }
            _23368 = NOVALUE;

            /** 							sequence name = sprintf("_%d", SymTab[temps][S_TEMP_NAME] )*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _23370 = (int)*(((s1_ptr)_2)->base + _temps_43784);
            _2 = (int)SEQ_PTR(_23370);
            _23371 = (int)*(((s1_ptr)_2)->base + 34);
            _23370 = NOVALUE;
            DeRefi(_name_44028);
            _name_44028 = EPrintf(-9999999, _22130, _23371);
            _23371 = NOVALUE;

            /** 							if temp_name_type[SymTab[temps][S_TEMP_NAME]][T_GTYPE]*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _23373 = (int)*(((s1_ptr)_2)->base + _temps_43784);
            _2 = (int)SEQ_PTR(_23373);
            _23374 = (int)*(((s1_ptr)_2)->base + 34);
            _23373 = NOVALUE;
            _2 = (int)SEQ_PTR(_26temp_name_type_12065);
            if (!IS_ATOM_INT(_23374)){
                _23375 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_23374)->dbl));
            }
            else{
                _23375 = (int)*(((s1_ptr)_2)->base + _23374);
            }
            _2 = (int)SEQ_PTR(_23375);
            _23376 = (int)*(((s1_ptr)_2)->base + 1);
            _23375 = NOVALUE;
            if (IS_ATOM_INT(_23376)) {
                _23377 = (_23376 != 0);
            }
            else {
                _23377 = binary_op(NOTEQ, _23376, 0);
            }
            _23376 = NOVALUE;
            if (IS_ATOM_INT(_23377)) {
                if (_23377 == 0) {
                    goto L2C; // [1143] 1217
                }
            }
            else {
                if (DBL_PTR(_23377)->dbl == 0.0) {
                    goto L2C; // [1143] 1217
                }
            }
            _23379 = find_from(_name_44028, _names_44018, 1);
            _23380 = (_23379 == 0);
            _23379 = NOVALUE;
            if (_23380 == 0)
            {
                DeRef(_23380);
                _23380 = NOVALUE;
                goto L2C; // [1156] 1217
            }
            else{
                DeRef(_23380);
                _23380 = NOVALUE;
            }

            /** 								c_stmt0("int ")*/
            RefDS(_22750);
            _56c_stmt0(_22750);

            /** 								c_puts( name )*/
            RefDS(_name_44028);
            _53c_puts(_name_44028);

            /** 								c_puts(" = NOVALUE")*/
            RefDS(_23381);
            _53c_puts(_23381);

            /** 								target = {NOVALUE, NOVALUE}*/
            Ref(_26NOVALUE_11836);
            Ref(_26NOVALUE_11836);
            DeRef(_57target_27494);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _26NOVALUE_11836;
            ((int *)_2)[2] = _26NOVALUE_11836;
            _57target_27494 = MAKE_SEQ(_1);

            /** 								SetBBType(temps, TYPE_INTEGER, target, TYPE_OBJECT, 0)*/
            RefDS(_57target_27494);
            _56SetBBType(_temps_43784, 1, _57target_27494, 16, 0);

            /** 								ifdef DEBUG then*/

            /** 									c_puts(";\n")*/
            RefDS(_22267);
            _53c_puts(_22267);

            /** 								names = prepend( names, name )*/
            RefDS(_name_44028);
            Prepend(&_names_44018, _names_44018, _name_44028);
            goto L2D; // [1214] 1220
L2C: 

            /** 								ifdef DEBUG then*/
L2D: 
L2B: 
            DeRefi(_name_44028);
            _name_44028 = NOVALUE;

            /** 						SymTab[temps][S_GTYPE] = TYPE_OBJECT*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _27SymTab_10921 = MAKE_SEQ(_2);
            }
            _3 = (int)(_temps_43784 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 36);
            _1 = *(int *)_2;
            *(int *)_2 = 16;
            DeRef(_1);
            _23386 = NOVALUE;

            /** 						temps = SymTab[temps][S_NEXT]*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _23388 = (int)*(((s1_ptr)_2)->base + _temps_43784);
            _2 = (int)SEQ_PTR(_23388);
            _temps_43784 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_temps_43784)){
                _temps_43784 = (long)DBL_PTR(_temps_43784)->dbl;
            }
            _23388 = NOVALUE;

            /** 					end while*/
            goto L29; // [1258] 1069
L2A: 

            /** 					Initializing = FALSE*/
            _26Initializing_12063 = _9FALSE_428;

            /** 					if SymTab[s][S_LHS_SUBS2] then*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _23390 = (int)*(((s1_ptr)_2)->base + _s_43780);
            _2 = (int)SEQ_PTR(_23390);
            _23391 = (int)*(((s1_ptr)_2)->base + 37);
            _23390 = NOVALUE;
            if (_23391 == 0) {
                _23391 = NOVALUE;
                goto L2E; // [1284] 1295
            }
            else {
                if (!IS_ATOM_INT(_23391) && DBL_PTR(_23391)->dbl == 0.0){
                    _23391 = NOVALUE;
                    goto L2E; // [1284] 1295
                }
                _23391 = NOVALUE;
            }
            _23391 = NOVALUE;

            /** 						c_stmt0("int _0, _1, _2, _3;\n\n")*/
            RefDS(_23392);
            _56c_stmt0(_23392);
            goto L2F; // [1292] 1301
L2E: 

            /** 						c_stmt0("int _0, _1, _2;\n\n")*/
            RefDS(_23393);
            _56c_stmt0(_23393);
L2F: 

            /** 					sp = SymTab[s][S_NEXT]*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _23394 = (int)*(((s1_ptr)_2)->base + _s_43780);
            _2 = (int)SEQ_PTR(_23394);
            _sp_43781 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_43781)){
                _sp_43781 = (long)DBL_PTR(_sp_43781)->dbl;
            }
            _23394 = NOVALUE;

            /** 					for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _23396 = (int)*(((s1_ptr)_2)->base + _s_43780);
            _2 = (int)SEQ_PTR(_23396);
            if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
                _23397 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
            }
            else{
                _23397 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
            }
            _23396 = NOVALUE;
            {
                int _p_44087;
                _p_44087 = 1;
L30: 
                if (binary_op_a(GREATER, _p_44087, _23397)){
                    goto L31; // [1331] 1682
                }

                /** 						SymTab[sp][S_ONE_REF] = FALSE*/
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _27SymTab_10921 = MAKE_SEQ(_2);
                }
                _3 = (int)(_sp_43781 + ((s1_ptr)_2)->base);
                _2 = (int)SEQ_PTR(*(int *)_3);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    *(int *)_3 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 35);
                _1 = *(int *)_2;
                *(int *)_2 = _9FALSE_428;
                DeRef(_1);
                _23398 = NOVALUE;

                /** 						if SymTab[sp][S_ARG_TYPE] = TYPE_SEQUENCE then*/
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                _23400 = (int)*(((s1_ptr)_2)->base + _sp_43781);
                _2 = (int)SEQ_PTR(_23400);
                _23401 = (int)*(((s1_ptr)_2)->base + 43);
                _23400 = NOVALUE;
                if (binary_op_a(NOTEQ, _23401, 8)){
                    _23401 = NOVALUE;
                    goto L32; // [1371] 1435
                }
                _23401 = NOVALUE;

                /** 							target[MIN] = SymTab[sp][S_ARG_SEQ_LEN]*/
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                _23403 = (int)*(((s1_ptr)_2)->base + _sp_43781);
                _2 = (int)SEQ_PTR(_23403);
                _23404 = (int)*(((s1_ptr)_2)->base + 51);
                _23403 = NOVALUE;
                Ref(_23404);
                _2 = (int)SEQ_PTR(_57target_27494);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _57target_27494 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 1);
                _1 = *(int *)_2;
                *(int *)_2 = _23404;
                if( _1 != _23404 ){
                    DeRef(_1);
                }
                _23404 = NOVALUE;

                /** 							SetBBType(sp, SymTab[sp][S_ARG_TYPE], target,*/
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                _23405 = (int)*(((s1_ptr)_2)->base + _sp_43781);
                _2 = (int)SEQ_PTR(_23405);
                _23406 = (int)*(((s1_ptr)_2)->base + 43);
                _23405 = NOVALUE;
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                _23407 = (int)*(((s1_ptr)_2)->base + _sp_43781);
                _2 = (int)SEQ_PTR(_23407);
                _23408 = (int)*(((s1_ptr)_2)->base + 45);
                _23407 = NOVALUE;
                Ref(_23406);
                RefDS(_57target_27494);
                Ref(_23408);
                _56SetBBType(_sp_43781, _23406, _57target_27494, _23408, 0);
                _23406 = NOVALUE;
                _23408 = NOVALUE;
                goto L33; // [1432] 1659
L32: 

                /** 						elsif SymTab[sp][S_ARG_TYPE] = TYPE_INTEGER then*/
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                _23409 = (int)*(((s1_ptr)_2)->base + _sp_43781);
                _2 = (int)SEQ_PTR(_23409);
                _23410 = (int)*(((s1_ptr)_2)->base + 43);
                _23409 = NOVALUE;
                if (binary_op_a(NOTEQ, _23410, 1)){
                    _23410 = NOVALUE;
                    goto L34; // [1451] 1575
                }
                _23410 = NOVALUE;

                /** 							if SymTab[sp][S_ARG_MIN] = NOVALUE then*/
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                _23412 = (int)*(((s1_ptr)_2)->base + _sp_43781);
                _2 = (int)SEQ_PTR(_23412);
                _23413 = (int)*(((s1_ptr)_2)->base + 47);
                _23412 = NOVALUE;
                if (binary_op_a(NOTEQ, _23413, _26NOVALUE_11836)){
                    _23413 = NOVALUE;
                    goto L35; // [1471] 1502
                }
                _23413 = NOVALUE;

                /** 								target[MIN] = MININT*/
                _2 = (int)SEQ_PTR(_57target_27494);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _57target_27494 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 1);
                _1 = *(int *)_2;
                *(int *)_2 = -1073741824;
                DeRef(_1);

                /** 								target[MAX] = MAXINT*/
                _2 = (int)SEQ_PTR(_57target_27494);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _57target_27494 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 2);
                _1 = *(int *)_2;
                *(int *)_2 = 1073741823;
                DeRef(_1);
                goto L36; // [1499] 1547
L35: 

                /** 								target[MIN] = SymTab[sp][S_ARG_MIN]*/
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                _23415 = (int)*(((s1_ptr)_2)->base + _sp_43781);
                _2 = (int)SEQ_PTR(_23415);
                _23416 = (int)*(((s1_ptr)_2)->base + 47);
                _23415 = NOVALUE;
                Ref(_23416);
                _2 = (int)SEQ_PTR(_57target_27494);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _57target_27494 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 1);
                _1 = *(int *)_2;
                *(int *)_2 = _23416;
                if( _1 != _23416 ){
                    DeRef(_1);
                }
                _23416 = NOVALUE;

                /** 								target[MAX] = SymTab[sp][S_ARG_MAX]*/
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                _23417 = (int)*(((s1_ptr)_2)->base + _sp_43781);
                _2 = (int)SEQ_PTR(_23417);
                _23418 = (int)*(((s1_ptr)_2)->base + 48);
                _23417 = NOVALUE;
                Ref(_23418);
                _2 = (int)SEQ_PTR(_57target_27494);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _57target_27494 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 2);
                _1 = *(int *)_2;
                *(int *)_2 = _23418;
                if( _1 != _23418 ){
                    DeRef(_1);
                }
                _23418 = NOVALUE;
L36: 

                /** 							SetBBType(sp, SymTab[sp][S_ARG_TYPE], target, TYPE_OBJECT, 0)*/
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                _23419 = (int)*(((s1_ptr)_2)->base + _sp_43781);
                _2 = (int)SEQ_PTR(_23419);
                _23420 = (int)*(((s1_ptr)_2)->base + 43);
                _23419 = NOVALUE;
                Ref(_23420);
                RefDS(_57target_27494);
                _56SetBBType(_sp_43781, _23420, _57target_27494, 16, 0);
                _23420 = NOVALUE;
                goto L33; // [1572] 1659
L34: 

                /** 						elsif SymTab[sp][S_ARG_TYPE] = TYPE_OBJECT then*/
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                _23421 = (int)*(((s1_ptr)_2)->base + _sp_43781);
                _2 = (int)SEQ_PTR(_23421);
                _23422 = (int)*(((s1_ptr)_2)->base + 43);
                _23421 = NOVALUE;
                if (binary_op_a(NOTEQ, _23422, 16)){
                    _23422 = NOVALUE;
                    goto L37; // [1591] 1633
                }
                _23422 = NOVALUE;

                /** 							SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue,*/
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                _23424 = (int)*(((s1_ptr)_2)->base + _sp_43781);
                _2 = (int)SEQ_PTR(_23424);
                _23425 = (int)*(((s1_ptr)_2)->base + 43);
                _23424 = NOVALUE;
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                _23426 = (int)*(((s1_ptr)_2)->base + _sp_43781);
                _2 = (int)SEQ_PTR(_23426);
                _23427 = (int)*(((s1_ptr)_2)->base + 45);
                _23426 = NOVALUE;
                Ref(_23425);
                RefDS(_53novalue_45534);
                Ref(_23427);
                _56SetBBType(_sp_43781, _23425, _53novalue_45534, _23427, 0);
                _23425 = NOVALUE;
                _23427 = NOVALUE;
                goto L33; // [1630] 1659
L37: 

                /** 							SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue, TYPE_OBJECT, 0)*/
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                _23428 = (int)*(((s1_ptr)_2)->base + _sp_43781);
                _2 = (int)SEQ_PTR(_23428);
                _23429 = (int)*(((s1_ptr)_2)->base + 43);
                _23428 = NOVALUE;
                Ref(_23429);
                RefDS(_53novalue_45534);
                _56SetBBType(_sp_43781, _23429, _53novalue_45534, 16, 0);
                _23429 = NOVALUE;
L33: 

                /** 						sp = SymTab[sp][S_NEXT]*/
                _2 = (int)SEQ_PTR(_27SymTab_10921);
                _23430 = (int)*(((s1_ptr)_2)->base + _sp_43781);
                _2 = (int)SEQ_PTR(_23430);
                _sp_43781 = (int)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_43781)){
                    _sp_43781 = (long)DBL_PTR(_sp_43781)->dbl;
                }
                _23430 = NOVALUE;

                /** 					end for*/
                _0 = _p_44087;
                if (IS_ATOM_INT(_p_44087)) {
                    _p_44087 = _p_44087 + 1;
                    if ((long)((unsigned long)_p_44087 +(unsigned long) HIGH_BITS) >= 0){
                        _p_44087 = NewDouble((double)_p_44087);
                    }
                }
                else {
                    _p_44087 = binary_op_a(PLUS, _p_44087, 1);
                }
                DeRef(_0);
                goto L30; // [1677] 1338
L31: 
                ;
                DeRef(_p_44087);
            }

            /** 					call_proc(Execute_id, {s})*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            *((int *)(_2+4)) = _s_43780;
            _23432 = MAKE_SEQ(_1);
            _1 = (int)SEQ_PTR(_23432);
            _2 = (int)((s1_ptr)_1)->base;
            _0 = (int)_00[_26Execute_id_12070].addr;
            Ref(*(int *)(_2+4));
            (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            DeRefDS(_23432);
            _23432 = NOVALUE;

            /** 					c_puts("    ;\n}\n")*/
            RefDS(_23433);
            _53c_puts(_23433);

            /** 					if TUNIX and dll_option and is_exported( s ) then*/
            if (0 == 0) {
                _23434 = 0;
                goto L38; // [1702] 1712
            }
            _23434 = (_56dll_option_41716 != 0);
L38: 
            if (_23434 == 0) {
                goto L39; // [1712] 2035
            }
            _23436 = _56is_exported(_s_43780);
            if (_23436 == 0) {
                DeRef(_23436);
                _23436 = NOVALUE;
                goto L39; // [1721] 2035
            }
            else {
                if (!IS_ATOM_INT(_23436) && DBL_PTR(_23436)->dbl == 0.0){
                    DeRef(_23436);
                    _23436 = NOVALUE;
                    goto L39; // [1721] 2035
                }
                DeRef(_23436);
                _23436 = NOVALUE;
            }
            DeRef(_23436);
            _23436 = NOVALUE;

            /** 						LeftSym = TRUE*/
            _56LeftSym_41713 = _9TRUE_430;

            /** 						if TOSX then*/

            /** 							c_stmt( ret_type & SymTab[s][S_NAME] & "() __attribute__ ((alias (\"@\")));\n", s )*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _23466 = (int)*(((s1_ptr)_2)->base + _s_43780);
            _2 = (int)SEQ_PTR(_23466);
            if (!IS_ATOM_INT(_26S_NAME_11654)){
                _23467 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
            }
            else{
                _23467 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
            }
            _23466 = NOVALUE;
            {
                int concat_list[3];

                concat_list[0] = _23468;
                concat_list[1] = _23467;
                concat_list[2] = _ret_type_43913;
                Concat_N((object_ptr)&_23469, concat_list, 3);
            }
            _23467 = NOVALUE;
            _56c_stmt(_23469, _s_43780, 0);
            _23469 = NOVALUE;

            /** 						LeftSym = FALSE*/
            _56LeftSym_41713 = _9FALSE_428;
L39: 

            /** 					c_puts("\n\n" )*/
            RefDS(_22151);
            _53c_puts(_22151);
L14: 
            DeRefi(_ret_type_43913);
            _ret_type_43913 = NOVALUE;
            DeRef(_names_44018);
            _names_44018 = NOVALUE;

            /** 			end for*/
            _routine_no_43858 = _routine_no_43858 + 1;
            goto L12; // [2045] 359
L13: 
            ;
        }
L8: 
        DeRef(_these_routines_43855);
        _these_routines_43855 = NOVALUE;

        /** 	end for*/
        _file_no_43804 = _file_no_43804 + 1;
        goto L5; // [2055] 85
L6: 
        ;
    }

    /** end procedure*/
    DeRefi(_buff_43785);
    DeRef(_base_name_43786);
    DeRef(_long_c_file_43787);
    DeRef(_c_file_43788);
    DeRef(_23263);
    _23263 = NOVALUE;
    DeRef(_23272);
    _23272 = NOVALUE;
    DeRef(_23286);
    _23286 = NOVALUE;
    DeRef(_23297);
    _23297 = NOVALUE;
    DeRef(_23299);
    _23299 = NOVALUE;
    DeRef(_23301);
    _23301 = NOVALUE;
    _23307 = NOVALUE;
    DeRef(_23304);
    _23304 = NOVALUE;
    DeRef(_23309);
    _23309 = NOVALUE;
    _23345 = NOVALUE;
    _23374 = NOVALUE;
    _23397 = NOVALUE;
    DeRef(_23377);
    _23377 = NOVALUE;
    return;
    ;
}



// 0xD65CCDC1
