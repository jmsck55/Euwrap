// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _61reverse(int _s_22453)
{
    int _lower_22454 = NOVALUE;
    int _n_22455 = NOVALUE;
    int _n2_22456 = NOVALUE;
    int _t_22457 = NOVALUE;
    int _13056 = NOVALUE;
    int _13055 = NOVALUE;
    int _13054 = NOVALUE;
    int _13051 = NOVALUE;
    int _0, _1, _2;
    

    /** 	n = length(s)*/
    if (IS_SEQUENCE(_s_22453)){
            _n_22455 = SEQ_PTR(_s_22453)->length;
    }
    else {
        _n_22455 = 1;
    }

    /** 	n2 = floor(n/2)+1*/
    _13051 = _n_22455 >> 1;
    _n2_22456 = _13051 + 1;
    _13051 = NOVALUE;

    /** 	t = repeat(0, n)*/
    DeRef(_t_22457);
    _t_22457 = Repeat(0, _n_22455);

    /** 	lower = 1*/
    _lower_22454 = 1;

    /** 	for upper = n to n2 by -1 do*/
    _13054 = _n2_22456;
    {
        int _upper_22463;
        _upper_22463 = _n_22455;
L1: 
        if (_upper_22463 < _13054){
            goto L2; // [34] 74
        }

        /** 		t[upper] = s[lower]*/
        _2 = (int)SEQ_PTR(_s_22453);
        _13055 = (int)*(((s1_ptr)_2)->base + _lower_22454);
        Ref(_13055);
        _2 = (int)SEQ_PTR(_t_22457);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_22457 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _upper_22463);
        _1 = *(int *)_2;
        *(int *)_2 = _13055;
        if( _1 != _13055 ){
            DeRef(_1);
        }
        _13055 = NOVALUE;

        /** 		t[lower] = s[upper]*/
        _2 = (int)SEQ_PTR(_s_22453);
        _13056 = (int)*(((s1_ptr)_2)->base + _upper_22463);
        Ref(_13056);
        _2 = (int)SEQ_PTR(_t_22457);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_22457 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _lower_22454);
        _1 = *(int *)_2;
        *(int *)_2 = _13056;
        if( _1 != _13056 ){
            DeRef(_1);
        }
        _13056 = NOVALUE;

        /** 		lower += 1*/
        _lower_22454 = _lower_22454 + 1;

        /** 	end for*/
        _upper_22463 = _upper_22463 + -1;
        goto L1; // [69] 41
L2: 
        ;
    }

    /** 	return t*/
    DeRefDS(_s_22453);
    return _t_22457;
    ;
}


int _61carry(int _a_22470, int _radix_22471)
{
    int _q_22472 = NOVALUE;
    int _r_22473 = NOVALUE;
    int _b_22474 = NOVALUE;
    int _rmax_22475 = NOVALUE;
    int _i_22476 = NOVALUE;
    int _13070 = NOVALUE;
    int _13069 = NOVALUE;
    int _13068 = NOVALUE;
    int _13065 = NOVALUE;
    int _13059 = NOVALUE;
    int _0, _1, _2;
    

    /** 		rmax = radix - 1*/
    DeRef(_rmax_22475);
    _rmax_22475 = _radix_22471 - 1;
    if ((long)((unsigned long)_rmax_22475 +(unsigned long) HIGH_BITS) >= 0){
        _rmax_22475 = NewDouble((double)_rmax_22475);
    }

    /** 		i = 1*/
    DeRef(_i_22476);
    _i_22476 = 1;

    /** 		while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_22470)){
            _13059 = SEQ_PTR(_a_22470)->length;
    }
    else {
        _13059 = 1;
    }
    if (binary_op_a(GREATER, _i_22476, _13059)){
        _13059 = NOVALUE;
        goto L2; // [24] 104
    }
    _13059 = NOVALUE;

    /** 				b = a[i]*/
    DeRef(_b_22474);
    _2 = (int)SEQ_PTR(_a_22470);
    if (!IS_ATOM_INT(_i_22476)){
        _b_22474 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_22476)->dbl));
    }
    else{
        _b_22474 = (int)*(((s1_ptr)_2)->base + _i_22476);
    }
    Ref(_b_22474);

    /** 				if b > rmax then*/
    if (binary_op_a(LESSEQ, _b_22474, _rmax_22475)){
        goto L3; // [36] 93
    }

    /** 						q = floor( b / radix )*/
    DeRef(_q_22472);
    if (IS_ATOM_INT(_b_22474)) {
        if (_radix_22471 > 0 && _b_22474 >= 0) {
            _q_22472 = _b_22474 / _radix_22471;
        }
        else {
            temp_dbl = floor((double)_b_22474 / (double)_radix_22471);
            if (_b_22474 != MININT)
            _q_22472 = (long)temp_dbl;
            else
            _q_22472 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _b_22474, _radix_22471);
        _q_22472 = unary_op(FLOOR, _2);
        DeRef(_2);
    }

    /** 						r = remainder( b, radix )*/
    DeRef(_r_22473);
    if (IS_ATOM_INT(_b_22474)) {
        _r_22473 = (_b_22474 % _radix_22471);
    }
    else {
        temp_d.dbl = (double)_radix_22471;
        _r_22473 = Dremainder(DBL_PTR(_b_22474), &temp_d);
    }

    /** 						a[i] = r*/
    Ref(_r_22473);
    _2 = (int)SEQ_PTR(_a_22470);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _a_22470 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_i_22476))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_22476)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _i_22476);
    _1 = *(int *)_2;
    *(int *)_2 = _r_22473;
    DeRef(_1);

    /** 						if i = length(a) then*/
    if (IS_SEQUENCE(_a_22470)){
            _13065 = SEQ_PTR(_a_22470)->length;
    }
    else {
        _13065 = 1;
    }
    if (binary_op_a(NOTEQ, _i_22476, _13065)){
        _13065 = NOVALUE;
        goto L4; // [63] 74
    }
    _13065 = NOVALUE;

    /** 								a &= 0*/
    Append(&_a_22470, _a_22470, 0);
L4: 

    /** 						a[i+1] += q*/
    if (IS_ATOM_INT(_i_22476)) {
        _13068 = _i_22476 + 1;
    }
    else
    _13068 = binary_op(PLUS, 1, _i_22476);
    _2 = (int)SEQ_PTR(_a_22470);
    if (!IS_ATOM_INT(_13068)){
        _13069 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13068)->dbl));
    }
    else{
        _13069 = (int)*(((s1_ptr)_2)->base + _13068);
    }
    if (IS_ATOM_INT(_13069) && IS_ATOM_INT(_q_22472)) {
        _13070 = _13069 + _q_22472;
        if ((long)((unsigned long)_13070 + (unsigned long)HIGH_BITS) >= 0) 
        _13070 = NewDouble((double)_13070);
    }
    else {
        _13070 = binary_op(PLUS, _13069, _q_22472);
    }
    _13069 = NOVALUE;
    _2 = (int)SEQ_PTR(_a_22470);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _a_22470 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_13068))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_13068)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _13068);
    _1 = *(int *)_2;
    *(int *)_2 = _13070;
    if( _1 != _13070 ){
        DeRef(_1);
    }
    _13070 = NOVALUE;
L3: 

    /** 				i += 1*/
    _0 = _i_22476;
    if (IS_ATOM_INT(_i_22476)) {
        _i_22476 = _i_22476 + 1;
        if (_i_22476 > MAXINT){
            _i_22476 = NewDouble((double)_i_22476);
        }
    }
    else
    _i_22476 = binary_op(PLUS, 1, _i_22476);
    DeRef(_0);

    /** 		end while*/
    goto L1; // [101] 21
L2: 

    /** 		return a*/
    DeRef(_q_22472);
    DeRef(_r_22473);
    DeRef(_b_22474);
    DeRef(_rmax_22475);
    DeRef(_i_22476);
    DeRef(_13068);
    _13068 = NOVALUE;
    return _a_22470;
    ;
}


int _61add(int _a_22496, int _b_22497)
{
    int _13088 = NOVALUE;
    int _13086 = NOVALUE;
    int _13085 = NOVALUE;
    int _13084 = NOVALUE;
    int _13083 = NOVALUE;
    int _13081 = NOVALUE;
    int _13080 = NOVALUE;
    int _13078 = NOVALUE;
    int _13077 = NOVALUE;
    int _13076 = NOVALUE;
    int _13075 = NOVALUE;
    int _13073 = NOVALUE;
    int _13072 = NOVALUE;
    int _0, _1, _2;
    

    /** 		if length(a) < length(b) then*/
    if (IS_SEQUENCE(_a_22496)){
            _13072 = SEQ_PTR(_a_22496)->length;
    }
    else {
        _13072 = 1;
    }
    if (IS_SEQUENCE(_b_22497)){
            _13073 = SEQ_PTR(_b_22497)->length;
    }
    else {
        _13073 = 1;
    }
    if (_13072 >= _13073)
    goto L1; // [13] 40

    /** 				a &= repeat( 0, length(b) - length(a) )*/
    if (IS_SEQUENCE(_b_22497)){
            _13075 = SEQ_PTR(_b_22497)->length;
    }
    else {
        _13075 = 1;
    }
    if (IS_SEQUENCE(_a_22496)){
            _13076 = SEQ_PTR(_a_22496)->length;
    }
    else {
        _13076 = 1;
    }
    _13077 = _13075 - _13076;
    _13075 = NOVALUE;
    _13076 = NOVALUE;
    _13078 = Repeat(0, _13077);
    _13077 = NOVALUE;
    Concat((object_ptr)&_a_22496, _a_22496, _13078);
    DeRefDS(_13078);
    _13078 = NOVALUE;
    goto L2; // [37] 74
L1: 

    /** 		elsif length(b) < length(a) then*/
    if (IS_SEQUENCE(_b_22497)){
            _13080 = SEQ_PTR(_b_22497)->length;
    }
    else {
        _13080 = 1;
    }
    if (IS_SEQUENCE(_a_22496)){
            _13081 = SEQ_PTR(_a_22496)->length;
    }
    else {
        _13081 = 1;
    }
    if (_13080 >= _13081)
    goto L3; // [48] 73

    /** 				b &= repeat( 0, length(a) - length(b) )*/
    if (IS_SEQUENCE(_a_22496)){
            _13083 = SEQ_PTR(_a_22496)->length;
    }
    else {
        _13083 = 1;
    }
    if (IS_SEQUENCE(_b_22497)){
            _13084 = SEQ_PTR(_b_22497)->length;
    }
    else {
        _13084 = 1;
    }
    _13085 = _13083 - _13084;
    _13083 = NOVALUE;
    _13084 = NOVALUE;
    _13086 = Repeat(0, _13085);
    _13085 = NOVALUE;
    Concat((object_ptr)&_b_22497, _b_22497, _13086);
    DeRefDS(_13086);
    _13086 = NOVALUE;
L3: 
L2: 

    /** 		return a + b*/
    _13088 = binary_op(PLUS, _a_22496, _b_22497);
    DeRefDS(_a_22496);
    DeRefDS(_b_22497);
    return _13088;
    ;
}


int _61borrow(int _a_22519, int _radix_22520)
{
    int _13096 = NOVALUE;
    int _13095 = NOVALUE;
    int _13094 = NOVALUE;
    int _13093 = NOVALUE;
    int _13092 = NOVALUE;
    int _13090 = NOVALUE;
    int _13089 = NOVALUE;
    int _0, _1, _2;
    

    /** 		for i = length(a) to 2 by -1 do*/
    if (IS_SEQUENCE(_a_22519)){
            _13089 = SEQ_PTR(_a_22519)->length;
    }
    else {
        _13089 = 1;
    }
    {
        int _i_22522;
        _i_22522 = _13089;
L1: 
        if (_i_22522 < 2){
            goto L2; // [10] 67
        }

        /** 				if a[i] < 0 then*/
        _2 = (int)SEQ_PTR(_a_22519);
        _13090 = (int)*(((s1_ptr)_2)->base + _i_22522);
        if (binary_op_a(GREATEREQ, _13090, 0)){
            _13090 = NOVALUE;
            goto L3; // [23] 60
        }
        _13090 = NOVALUE;

        /** 						a[i] += radix*/
        _2 = (int)SEQ_PTR(_a_22519);
        _13092 = (int)*(((s1_ptr)_2)->base + _i_22522);
        if (IS_ATOM_INT(_13092)) {
            _13093 = _13092 + _radix_22520;
            if ((long)((unsigned long)_13093 + (unsigned long)HIGH_BITS) >= 0) 
            _13093 = NewDouble((double)_13093);
        }
        else {
            _13093 = binary_op(PLUS, _13092, _radix_22520);
        }
        _13092 = NOVALUE;
        _2 = (int)SEQ_PTR(_a_22519);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_22519 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_22522);
        _1 = *(int *)_2;
        *(int *)_2 = _13093;
        if( _1 != _13093 ){
            DeRef(_1);
        }
        _13093 = NOVALUE;

        /** 						a[i-1] -= 1*/
        _13094 = _i_22522 - 1;
        _2 = (int)SEQ_PTR(_a_22519);
        _13095 = (int)*(((s1_ptr)_2)->base + _13094);
        if (IS_ATOM_INT(_13095)) {
            _13096 = _13095 - 1;
            if ((long)((unsigned long)_13096 +(unsigned long) HIGH_BITS) >= 0){
                _13096 = NewDouble((double)_13096);
            }
        }
        else {
            _13096 = binary_op(MINUS, _13095, 1);
        }
        _13095 = NOVALUE;
        _2 = (int)SEQ_PTR(_a_22519);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_22519 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _13094);
        _1 = *(int *)_2;
        *(int *)_2 = _13096;
        if( _1 != _13096 ){
            DeRef(_1);
        }
        _13096 = NOVALUE;
L3: 

        /** 		end for*/
        _i_22522 = _i_22522 + -1;
        goto L1; // [62] 17
L2: 
        ;
    }

    /** 		return a*/
    DeRef(_13094);
    _13094 = NOVALUE;
    return _a_22519;
    ;
}


int _61bits_to_bytes(int _bits_22534)
{
    int _bytes_22535 = NOVALUE;
    int _r_22536 = NOVALUE;
    int _13105 = NOVALUE;
    int _13104 = NOVALUE;
    int _13103 = NOVALUE;
    int _13102 = NOVALUE;
    int _13100 = NOVALUE;
    int _13099 = NOVALUE;
    int _13097 = NOVALUE;
    int _0, _1, _2;
    

    /** 		r = remainder( length(bits), 8 )*/
    if (IS_SEQUENCE(_bits_22534)){
            _13097 = SEQ_PTR(_bits_22534)->length;
    }
    else {
        _13097 = 1;
    }
    _r_22536 = (_13097 % 8);
    _13097 = NOVALUE;

    /** 		if r  then*/
    if (_r_22536 == 0)
    {
        goto L1; // [14] 32
    }
    else{
    }

    /** 				bits &= repeat( 0, 8 - r )*/
    _13099 = 8 - _r_22536;
    _13100 = Repeat(0, _13099);
    _13099 = NOVALUE;
    Concat((object_ptr)&_bits_22534, _bits_22534, _13100);
    DeRefDS(_13100);
    _13100 = NOVALUE;
L1: 

    /** 		bytes = {}*/
    RefDS(_5);
    DeRef(_bytes_22535);
    _bytes_22535 = _5;

    /** 		for i = 1 to length(bits) by 8 do*/
    if (IS_SEQUENCE(_bits_22534)){
            _13102 = SEQ_PTR(_bits_22534)->length;
    }
    else {
        _13102 = 1;
    }
    {
        int _i_22544;
        _i_22544 = 1;
L2: 
        if (_i_22544 > _13102){
            goto L3; // [44] 77
        }

        /** 				bytes &= bits_to_int( bits[i..i+7] )*/
        _13103 = _i_22544 + 7;
        rhs_slice_target = (object_ptr)&_13104;
        RHS_Slice(_bits_22534, _i_22544, _13103);
        _13105 = _13bits_to_int(_13104);
        _13104 = NOVALUE;
        if (IS_SEQUENCE(_bytes_22535) && IS_ATOM(_13105)) {
            Ref(_13105);
            Append(&_bytes_22535, _bytes_22535, _13105);
        }
        else if (IS_ATOM(_bytes_22535) && IS_SEQUENCE(_13105)) {
        }
        else {
            Concat((object_ptr)&_bytes_22535, _bytes_22535, _13105);
        }
        DeRef(_13105);
        _13105 = NOVALUE;

        /** 		end for*/
        _i_22544 = _i_22544 + 8;
        goto L2; // [72] 51
L3: 
        ;
    }

    /** 		return bytes*/
    DeRefDS(_bits_22534);
    DeRef(_13103);
    _13103 = NOVALUE;
    return _bytes_22535;
    ;
}


int _61bytes_to_bits(int _bytes_22553)
{
    int _bits_22554 = NOVALUE;
    int _13109 = NOVALUE;
    int _13108 = NOVALUE;
    int _13107 = NOVALUE;
    int _0, _1, _2;
    

    /** 		bits = {}*/
    RefDS(_5);
    DeRef(_bits_22554);
    _bits_22554 = _5;

    /** 		for i = 1 to length(bytes) do*/
    if (IS_SEQUENCE(_bytes_22553)){
            _13107 = SEQ_PTR(_bytes_22553)->length;
    }
    else {
        _13107 = 1;
    }
    {
        int _i_22556;
        _i_22556 = 1;
L1: 
        if (_i_22556 > _13107){
            goto L2; // [15] 44
        }

        /** 				bits &= int_to_bits( bytes[i], 8 )*/
        _2 = (int)SEQ_PTR(_bytes_22553);
        _13108 = (int)*(((s1_ptr)_2)->base + _i_22556);
        Ref(_13108);
        _13109 = _13int_to_bits(_13108, 8);
        _13108 = NOVALUE;
        if (IS_SEQUENCE(_bits_22554) && IS_ATOM(_13109)) {
            Ref(_13109);
            Append(&_bits_22554, _bits_22554, _13109);
        }
        else if (IS_ATOM(_bits_22554) && IS_SEQUENCE(_13109)) {
        }
        else {
            Concat((object_ptr)&_bits_22554, _bits_22554, _13109);
        }
        DeRef(_13109);
        _13109 = NOVALUE;

        /** 		end for*/
        _i_22556 = _i_22556 + 1;
        goto L1; // [39] 22
L2: 
        ;
    }

    /** 		return bits*/
    DeRefDS(_bytes_22553);
    return _bits_22554;
    ;
}


int _61convert_radix(int _number_22564, int _from_radix_22565, int _to_radix_22566)
{
    int _target_22567 = NOVALUE;
    int _base_22568 = NOVALUE;
    int _13116 = NOVALUE;
    int _13115 = NOVALUE;
    int _13114 = NOVALUE;
    int _13113 = NOVALUE;
    int _0, _1, _2;
    

    /** 		base = {1}*/
    RefDS(_13111);
    DeRef(_base_22568);
    _base_22568 = _13111;

    /** 		target = {0}*/
    _0 = _target_22567;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    _target_22567 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 		for i = 1 to length(number) do*/
    if (IS_SEQUENCE(_number_22564)){
            _13113 = SEQ_PTR(_number_22564)->length;
    }
    else {
        _13113 = 1;
    }
    {
        int _i_22572;
        _i_22572 = 1;
L1: 
        if (_i_22572 > _13113){
            goto L2; // [25] 78
        }

        /** 				target = carry( add( base * number[i], target ), to_radix )*/
        _2 = (int)SEQ_PTR(_number_22564);
        _13114 = (int)*(((s1_ptr)_2)->base + _i_22572);
        _13115 = binary_op(MULTIPLY, _base_22568, _13114);
        _13114 = NOVALUE;
        RefDS(_target_22567);
        _13116 = _61add(_13115, _target_22567);
        _13115 = NOVALUE;
        _0 = _target_22567;
        _target_22567 = _61carry(_13116, _to_radix_22566);
        DeRefDS(_0);
        _13116 = NOVALUE;

        /** 				base *= from_radix*/
        _0 = _base_22568;
        _base_22568 = binary_op(MULTIPLY, _base_22568, _from_radix_22565);
        DeRefDS(_0);

        /** 				base = carry( base, to_radix )*/
        RefDS(_base_22568);
        _0 = _base_22568;
        _base_22568 = _61carry(_base_22568, _to_radix_22566);
        DeRefDS(_0);

        /** 		end for*/
        _i_22572 = _i_22572 + 1;
        goto L1; // [73] 32
L2: 
        ;
    }

    /** 		return target*/
    DeRefDS(_number_22564);
    DeRef(_base_22568);
    return _target_22567;
    ;
}


int _61half(int _decimal_22582)
{
    int _quotient_22583 = NOVALUE;
    int _q_22584 = NOVALUE;
    int _Q_22585 = NOVALUE;
    int _13137 = NOVALUE;
    int _13136 = NOVALUE;
    int _13135 = NOVALUE;
    int _13134 = NOVALUE;
    int _13133 = NOVALUE;
    int _13132 = NOVALUE;
    int _13129 = NOVALUE;
    int _13127 = NOVALUE;
    int _13126 = NOVALUE;
    int _13123 = NOVALUE;
    int _13122 = NOVALUE;
    int _13120 = NOVALUE;
    int _0, _1, _2;
    

    /** 		quotient = repeat( 0, length(decimal) )*/
    if (IS_SEQUENCE(_decimal_22582)){
            _13120 = SEQ_PTR(_decimal_22582)->length;
    }
    else {
        _13120 = 1;
    }
    DeRef(_quotient_22583);
    _quotient_22583 = Repeat(0, _13120);
    _13120 = NOVALUE;

    /** 		for i = 1 to length( decimal ) do*/
    if (IS_SEQUENCE(_decimal_22582)){
            _13122 = SEQ_PTR(_decimal_22582)->length;
    }
    else {
        _13122 = 1;
    }
    {
        int _i_22589;
        _i_22589 = 1;
L1: 
        if (_i_22589 > _13122){
            goto L2; // [17] 101
        }

        /** 				q = decimal[i] / 2*/
        _2 = (int)SEQ_PTR(_decimal_22582);
        _13123 = (int)*(((s1_ptr)_2)->base + _i_22589);
        DeRef(_q_22584);
        if (IS_ATOM_INT(_13123)) {
            if (_13123 & 1) {
                _q_22584 = NewDouble((_13123 >> 1) + 0.5);
            }
            else
            _q_22584 = _13123 >> 1;
        }
        else {
            _q_22584 = binary_op(DIVIDE, _13123, 2);
        }
        _13123 = NOVALUE;

        /** 				Q = floor( q )*/
        DeRef(_Q_22585);
        if (IS_ATOM_INT(_q_22584))
        _Q_22585 = e_floor(_q_22584);
        else
        _Q_22585 = unary_op(FLOOR, _q_22584);

        /** 				quotient[i] +=  Q*/
        _2 = (int)SEQ_PTR(_quotient_22583);
        _13126 = (int)*(((s1_ptr)_2)->base + _i_22589);
        if (IS_ATOM_INT(_13126) && IS_ATOM_INT(_Q_22585)) {
            _13127 = _13126 + _Q_22585;
            if ((long)((unsigned long)_13127 + (unsigned long)HIGH_BITS) >= 0) 
            _13127 = NewDouble((double)_13127);
        }
        else {
            _13127 = binary_op(PLUS, _13126, _Q_22585);
        }
        _13126 = NOVALUE;
        _2 = (int)SEQ_PTR(_quotient_22583);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _quotient_22583 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_22589);
        _1 = *(int *)_2;
        *(int *)_2 = _13127;
        if( _1 != _13127 ){
            DeRef(_1);
        }
        _13127 = NOVALUE;

        /** 				if q != Q then*/
        if (binary_op_a(EQUALS, _q_22584, _Q_22585)){
            goto L3; // [55] 94
        }

        /** 						if length(quotient) = i then*/
        if (IS_SEQUENCE(_quotient_22583)){
                _13129 = SEQ_PTR(_quotient_22583)->length;
        }
        else {
            _13129 = 1;
        }
        if (_13129 != _i_22589)
        goto L4; // [64] 75

        /** 								quotient &= 0*/
        Append(&_quotient_22583, _quotient_22583, 0);
L4: 

        /** 						quotient[i+1] += 5*/
        _13132 = _i_22589 + 1;
        _2 = (int)SEQ_PTR(_quotient_22583);
        _13133 = (int)*(((s1_ptr)_2)->base + _13132);
        if (IS_ATOM_INT(_13133)) {
            _13134 = _13133 + 5;
            if ((long)((unsigned long)_13134 + (unsigned long)HIGH_BITS) >= 0) 
            _13134 = NewDouble((double)_13134);
        }
        else {
            _13134 = binary_op(PLUS, _13133, 5);
        }
        _13133 = NOVALUE;
        _2 = (int)SEQ_PTR(_quotient_22583);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _quotient_22583 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _13132);
        _1 = *(int *)_2;
        *(int *)_2 = _13134;
        if( _1 != _13134 ){
            DeRef(_1);
        }
        _13134 = NOVALUE;
L3: 

        /** 		end for*/
        _i_22589 = _i_22589 + 1;
        goto L1; // [96] 24
L2: 
        ;
    }

    /** 		return reverse( carry( reverse( quotient ), 10 ) )*/
    RefDS(_quotient_22583);
    _13135 = _61reverse(_quotient_22583);
    _13136 = _61carry(_13135, 10);
    _13135 = NOVALUE;
    _13137 = _61reverse(_13136);
    _13136 = NOVALUE;
    DeRefDS(_decimal_22582);
    DeRefDS(_quotient_22583);
    DeRef(_q_22584);
    DeRef(_Q_22585);
    DeRef(_13132);
    _13132 = NOVALUE;
    return _13137;
    ;
}


int _61decimals_to_bits(int _decimals_22618)
{
    int _sub_22619 = NOVALUE;
    int _bits_22620 = NOVALUE;
    int _bit_22621 = NOVALUE;
    int _assigned_22622 = NOVALUE;
    int _13164 = NOVALUE;
    int _13160 = NOVALUE;
    int _13159 = NOVALUE;
    int _13158 = NOVALUE;
    int _13157 = NOVALUE;
    int _13155 = NOVALUE;
    int _13154 = NOVALUE;
    int _13153 = NOVALUE;
    int _13151 = NOVALUE;
    int _13149 = NOVALUE;
    int _13148 = NOVALUE;
    int _13147 = NOVALUE;
    int _13146 = NOVALUE;
    int _13144 = NOVALUE;
    int _13142 = NOVALUE;
    int _0, _1, _2;
    

    /** 		sub = {5}*/
    RefDS(_13140);
    DeRef(_sub_22619);
    _sub_22619 = _13140;

    /** 		bits = repeat( 0, 53 )*/
    DeRef(_bits_22620);
    _bits_22620 = Repeat(0, 53);

    /** 		bit = 1*/
    _bit_22621 = 1;

    /** 		assigned = 0*/
    _assigned_22622 = 0;

    /** 		if compare(decimals, bits) > 0 then */
    if (IS_ATOM_INT(_decimals_22618) && IS_ATOM_INT(_bits_22620)){
        _13142 = (_decimals_22618 < _bits_22620) ? -1 : (_decimals_22618 > _bits_22620);
    }
    else{
        _13142 = compare(_decimals_22618, _bits_22620);
    }
    if (_13142 <= 0)
    goto L1; // [32] 160

    /** 			while (not assigned) or (bit < find( 1, bits ) + 54)  do*/
L2: 
    _13144 = (_assigned_22622 == 0);
    if (_13144 != 0) {
        goto L3; // [44] 66
    }
    _13146 = find_from(1, _bits_22620, 1);
    _13147 = _13146 + 54;
    _13146 = NOVALUE;
    _13148 = (_bit_22621 < _13147);
    _13147 = NOVALUE;
    if (_13148 == 0)
    {
        DeRef(_13148);
        _13148 = NOVALUE;
        goto L4; // [62] 159
    }
    else{
        DeRef(_13148);
        _13148 = NOVALUE;
    }
L3: 

    /** 				if compare( sub, decimals ) <= 0 then*/
    if (IS_ATOM_INT(_sub_22619) && IS_ATOM_INT(_decimals_22618)){
        _13149 = (_sub_22619 < _decimals_22618) ? -1 : (_sub_22619 > _decimals_22618);
    }
    else{
        _13149 = compare(_sub_22619, _decimals_22618);
    }
    if (_13149 > 0)
    goto L5; // [72] 140

    /** 						assigned = 1*/
    _assigned_22622 = 1;

    /** 						if length( bits ) < bit then*/
    if (IS_SEQUENCE(_bits_22620)){
            _13151 = SEQ_PTR(_bits_22620)->length;
    }
    else {
        _13151 = 1;
    }
    if (_13151 >= _bit_22621)
    goto L6; // [86] 108

    /** 								bits &= repeat( 0, bit - length(bits)) */
    if (IS_SEQUENCE(_bits_22620)){
            _13153 = SEQ_PTR(_bits_22620)->length;
    }
    else {
        _13153 = 1;
    }
    _13154 = _bit_22621 - _13153;
    _13153 = NOVALUE;
    _13155 = Repeat(0, _13154);
    _13154 = NOVALUE;
    Concat((object_ptr)&_bits_22620, _bits_22620, _13155);
    DeRefDS(_13155);
    _13155 = NOVALUE;
L6: 

    /** 						bits[bit] += 1*/
    _2 = (int)SEQ_PTR(_bits_22620);
    _13157 = (int)*(((s1_ptr)_2)->base + _bit_22621);
    if (IS_ATOM_INT(_13157)) {
        _13158 = _13157 + 1;
        if (_13158 > MAXINT){
            _13158 = NewDouble((double)_13158);
        }
    }
    else
    _13158 = binary_op(PLUS, 1, _13157);
    _13157 = NOVALUE;
    _2 = (int)SEQ_PTR(_bits_22620);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bits_22620 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bit_22621);
    _1 = *(int *)_2;
    *(int *)_2 = _13158;
    if( _1 != _13158 ){
        DeRef(_1);
    }
    _13158 = NOVALUE;

    /** 						decimals = borrow( add( decimals, -sub ), 10 )*/
    _13159 = unary_op(UMINUS, _sub_22619);
    RefDS(_decimals_22618);
    _13160 = _61add(_decimals_22618, _13159);
    _13159 = NOVALUE;
    _0 = _decimals_22618;
    _decimals_22618 = _61borrow(_13160, 10);
    DeRefDS(_0);
    _13160 = NOVALUE;
L5: 

    /** 				sub = half( sub )*/
    RefDS(_sub_22619);
    _0 = _sub_22619;
    _sub_22619 = _61half(_sub_22619);
    DeRefDS(_0);

    /** 				bit += 1*/
    _bit_22621 = _bit_22621 + 1;

    /** 			end while*/
    goto L2; // [156] 41
L4: 
L1: 

    /** 		return reverse(bits)*/
    RefDS(_bits_22620);
    _13164 = _61reverse(_bits_22620);
    DeRefDS(_decimals_22618);
    DeRef(_sub_22619);
    DeRefDS(_bits_22620);
    DeRef(_13144);
    _13144 = NOVALUE;
    return _13164;
    ;
}


int _61string_to_int(int _s_22654)
{
    int _int_22655 = NOVALUE;
    int _13168 = NOVALUE;
    int _13167 = NOVALUE;
    int _13165 = NOVALUE;
    int _0, _1, _2;
    

    /** 		int = 0*/
    _int_22655 = 0;

    /** 		for i = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_22654)){
            _13165 = SEQ_PTR(_s_22654)->length;
    }
    else {
        _13165 = 1;
    }
    {
        int _i_22657;
        _i_22657 = 1;
L1: 
        if (_i_22657 > _13165){
            goto L2; // [13] 51
        }

        /** 				int *= 10*/
        _int_22655 = _int_22655 * 10;

        /** 				int += s[i] - '0'*/
        _2 = (int)SEQ_PTR(_s_22654);
        _13167 = (int)*(((s1_ptr)_2)->base + _i_22657);
        if (IS_ATOM_INT(_13167)) {
            _13168 = _13167 - 48;
            if ((long)((unsigned long)_13168 +(unsigned long) HIGH_BITS) >= 0){
                _13168 = NewDouble((double)_13168);
            }
        }
        else {
            _13168 = binary_op(MINUS, _13167, 48);
        }
        _13167 = NOVALUE;
        if (IS_ATOM_INT(_13168)) {
            _int_22655 = _int_22655 + _13168;
        }
        else {
            _int_22655 = binary_op(PLUS, _int_22655, _13168);
        }
        DeRef(_13168);
        _13168 = NOVALUE;
        if (!IS_ATOM_INT(_int_22655)) {
            _1 = (long)(DBL_PTR(_int_22655)->dbl);
            DeRefDS(_int_22655);
            _int_22655 = _1;
        }

        /** 		end for*/
        _i_22657 = _i_22657 + 1;
        goto L1; // [46] 20
L2: 
        ;
    }

    /** 		return int*/
    DeRefDS(_s_22654);
    return _int_22655;
    ;
}


int _61trim_bits(int _bits_22665)
{
    int _13176 = NOVALUE;
    int _13175 = NOVALUE;
    int _13174 = NOVALUE;
    int _13173 = NOVALUE;
    int _13172 = NOVALUE;
    int _13171 = NOVALUE;
    int _13170 = NOVALUE;
    int _0, _1, _2;
    

    /** 		while length(bits) and not bits[$] do*/
L1: 
    if (IS_SEQUENCE(_bits_22665)){
            _13170 = SEQ_PTR(_bits_22665)->length;
    }
    else {
        _13170 = 1;
    }
    if (_13170 == 0) {
        goto L2; // [11] 48
    }
    if (IS_SEQUENCE(_bits_22665)){
            _13172 = SEQ_PTR(_bits_22665)->length;
    }
    else {
        _13172 = 1;
    }
    _2 = (int)SEQ_PTR(_bits_22665);
    _13173 = (int)*(((s1_ptr)_2)->base + _13172);
    if (IS_ATOM_INT(_13173)) {
        _13174 = (_13173 == 0);
    }
    else {
        _13174 = unary_op(NOT, _13173);
    }
    _13173 = NOVALUE;
    if (_13174 <= 0) {
        if (_13174 == 0) {
            DeRef(_13174);
            _13174 = NOVALUE;
            goto L2; // [26] 48
        }
        else {
            if (!IS_ATOM_INT(_13174) && DBL_PTR(_13174)->dbl == 0.0){
                DeRef(_13174);
                _13174 = NOVALUE;
                goto L2; // [26] 48
            }
            DeRef(_13174);
            _13174 = NOVALUE;
        }
    }
    DeRef(_13174);
    _13174 = NOVALUE;

    /** 				bits = bits[1..$-1]*/
    if (IS_SEQUENCE(_bits_22665)){
            _13175 = SEQ_PTR(_bits_22665)->length;
    }
    else {
        _13175 = 1;
    }
    _13176 = _13175 - 1;
    _13175 = NOVALUE;
    rhs_slice_target = (object_ptr)&_bits_22665;
    RHS_Slice(_bits_22665, 1, _13176);

    /** 		end while*/
    goto L1; // [45] 8
L2: 

    /** 		return bits*/
    DeRef(_13176);
    _13176 = NOVALUE;
    return _bits_22665;
    ;
}


int _61scientific_to_float64(int _s_22677)
{
    int _dp_22678 = NOVALUE;
    int _e_22679 = NOVALUE;
    int _exp_22680 = NOVALUE;
    int _int_bits_22681 = NOVALUE;
    int _frac_bits_22682 = NOVALUE;
    int _mbits_22683 = NOVALUE;
    int _ebits_22684 = NOVALUE;
    int _sbits_22685 = NOVALUE;
    int _13320 = NOVALUE;
    int _13319 = NOVALUE;
    int _13317 = NOVALUE;
    int _13315 = NOVALUE;
    int _13314 = NOVALUE;
    int _13313 = NOVALUE;
    int _13311 = NOVALUE;
    int _13310 = NOVALUE;
    int _13309 = NOVALUE;
    int _13308 = NOVALUE;
    int _13307 = NOVALUE;
    int _13306 = NOVALUE;
    int _13305 = NOVALUE;
    int _13303 = NOVALUE;
    int _13302 = NOVALUE;
    int _13301 = NOVALUE;
    int _13300 = NOVALUE;
    int _13298 = NOVALUE;
    int _13297 = NOVALUE;
    int _13296 = NOVALUE;
    int _13295 = NOVALUE;
    int _13294 = NOVALUE;
    int _13293 = NOVALUE;
    int _13292 = NOVALUE;
    int _13289 = NOVALUE;
    int _13286 = NOVALUE;
    int _13285 = NOVALUE;
    int _13284 = NOVALUE;
    int _13279 = NOVALUE;
    int _13278 = NOVALUE;
    int _13276 = NOVALUE;
    int _13275 = NOVALUE;
    int _13273 = NOVALUE;
    int _13271 = NOVALUE;
    int _13270 = NOVALUE;
    int _13269 = NOVALUE;
    int _13268 = NOVALUE;
    int _13267 = NOVALUE;
    int _13266 = NOVALUE;
    int _13265 = NOVALUE;
    int _13264 = NOVALUE;
    int _13262 = NOVALUE;
    int _13261 = NOVALUE;
    int _13260 = NOVALUE;
    int _13259 = NOVALUE;
    int _13257 = NOVALUE;
    int _13255 = NOVALUE;
    int _13254 = NOVALUE;
    int _13253 = NOVALUE;
    int _13252 = NOVALUE;
    int _13251 = NOVALUE;
    int _13249 = NOVALUE;
    int _13248 = NOVALUE;
    int _13247 = NOVALUE;
    int _13246 = NOVALUE;
    int _13245 = NOVALUE;
    int _13244 = NOVALUE;
    int _13242 = NOVALUE;
    int _13241 = NOVALUE;
    int _13240 = NOVALUE;
    int _13239 = NOVALUE;
    int _13238 = NOVALUE;
    int _13236 = NOVALUE;
    int _13235 = NOVALUE;
    int _13233 = NOVALUE;
    int _13232 = NOVALUE;
    int _13231 = NOVALUE;
    int _13230 = NOVALUE;
    int _13229 = NOVALUE;
    int _13227 = NOVALUE;
    int _13225 = NOVALUE;
    int _13224 = NOVALUE;
    int _13222 = NOVALUE;
    int _13221 = NOVALUE;
    int _13219 = NOVALUE;
    int _13216 = NOVALUE;
    int _13215 = NOVALUE;
    int _13214 = NOVALUE;
    int _13213 = NOVALUE;
    int _13212 = NOVALUE;
    int _13210 = NOVALUE;
    int _13209 = NOVALUE;
    int _13208 = NOVALUE;
    int _13207 = NOVALUE;
    int _13205 = NOVALUE;
    int _13204 = NOVALUE;
    int _13203 = NOVALUE;
    int _13202 = NOVALUE;
    int _13200 = NOVALUE;
    int _13199 = NOVALUE;
    int _13197 = NOVALUE;
    int _13196 = NOVALUE;
    int _13195 = NOVALUE;
    int _13194 = NOVALUE;
    int _13192 = NOVALUE;
    int _13191 = NOVALUE;
    int _13185 = NOVALUE;
    int _13183 = NOVALUE;
    int _13180 = NOVALUE;
    int _13178 = NOVALUE;
    int _0, _1, _2;
    

    /** 		if s[1] = '-' then*/
    _2 = (int)SEQ_PTR(_s_22677);
    _13178 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _13178, 45)){
        _13178 = NOVALUE;
        goto L1; // [9] 33
    }
    _13178 = NOVALUE;

    /** 				sbits = {1}*/
    RefDS(_13111);
    DeRefi(_sbits_22685);
    _sbits_22685 = _13111;

    /** 				s = s[2..$]*/
    if (IS_SEQUENCE(_s_22677)){
            _13180 = SEQ_PTR(_s_22677)->length;
    }
    else {
        _13180 = 1;
    }
    rhs_slice_target = (object_ptr)&_s_22677;
    RHS_Slice(_s_22677, 2, _13180);
    goto L2; // [30] 61
L1: 

    /** 				sbits = {0}*/
    _0 = _sbits_22685;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    _sbits_22685 = MAKE_SEQ(_1);
    DeRefi(_0);

    /** 				if s[1] = '+' then*/
    _2 = (int)SEQ_PTR(_s_22677);
    _13183 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _13183, 43)){
        _13183 = NOVALUE;
        goto L3; // [45] 60
    }
    _13183 = NOVALUE;

    /** 						s = s[2..$]*/
    if (IS_SEQUENCE(_s_22677)){
            _13185 = SEQ_PTR(_s_22677)->length;
    }
    else {
        _13185 = 1;
    }
    rhs_slice_target = (object_ptr)&_s_22677;
    RHS_Slice(_s_22677, 2, _13185);
L3: 
L2: 

    /** 		dp = find('.', s)*/
    _dp_22678 = find_from(46, _s_22677, 1);

    /** 		e = find( 'e', s )*/
    _e_22679 = find_from(101, _s_22677, 1);

    /** 		if not e then*/
    if (_e_22679 != 0)
    goto L4; // [77] 88

    /** 				e = find('E', s )*/
    _e_22679 = find_from(69, _s_22677, 1);
L4: 

    /** 		exp = 0*/
    _exp_22680 = 0;

    /** 		if s[e+1] = '-' then*/
    _13191 = _e_22679 + 1;
    _2 = (int)SEQ_PTR(_s_22677);
    _13192 = (int)*(((s1_ptr)_2)->base + _13191);
    if (binary_op_a(NOTEQ, _13192, 45)){
        _13192 = NOVALUE;
        goto L5; // [103] 134
    }
    _13192 = NOVALUE;

    /** 				exp -= string_to_int( s[e+2..$] )*/
    _13194 = _e_22679 + 2;
    if ((long)((unsigned long)_13194 + (unsigned long)HIGH_BITS) >= 0) 
    _13194 = NewDouble((double)_13194);
    if (IS_SEQUENCE(_s_22677)){
            _13195 = SEQ_PTR(_s_22677)->length;
    }
    else {
        _13195 = 1;
    }
    rhs_slice_target = (object_ptr)&_13196;
    RHS_Slice(_s_22677, _13194, _13195);
    _13197 = _61string_to_int(_13196);
    _13196 = NOVALUE;
    if (IS_ATOM_INT(_13197)) {
        _exp_22680 = _exp_22680 - _13197;
    }
    else {
        _exp_22680 = binary_op(MINUS, _exp_22680, _13197);
    }
    DeRef(_13197);
    _13197 = NOVALUE;
    if (!IS_ATOM_INT(_exp_22680)) {
        _1 = (long)(DBL_PTR(_exp_22680)->dbl);
        DeRefDS(_exp_22680);
        _exp_22680 = _1;
    }
    goto L6; // [131] 201
L5: 

    /** 				if s[e+1] = '+' then*/
    _13199 = _e_22679 + 1;
    _2 = (int)SEQ_PTR(_s_22677);
    _13200 = (int)*(((s1_ptr)_2)->base + _13199);
    if (binary_op_a(NOTEQ, _13200, 43)){
        _13200 = NOVALUE;
        goto L7; // [144] 175
    }
    _13200 = NOVALUE;

    /** 						exp += string_to_int( s[e+2..$] )*/
    _13202 = _e_22679 + 2;
    if ((long)((unsigned long)_13202 + (unsigned long)HIGH_BITS) >= 0) 
    _13202 = NewDouble((double)_13202);
    if (IS_SEQUENCE(_s_22677)){
            _13203 = SEQ_PTR(_s_22677)->length;
    }
    else {
        _13203 = 1;
    }
    rhs_slice_target = (object_ptr)&_13204;
    RHS_Slice(_s_22677, _13202, _13203);
    _13205 = _61string_to_int(_13204);
    _13204 = NOVALUE;
    if (IS_ATOM_INT(_13205)) {
        _exp_22680 = _exp_22680 + _13205;
    }
    else {
        _exp_22680 = binary_op(PLUS, _exp_22680, _13205);
    }
    DeRef(_13205);
    _13205 = NOVALUE;
    if (!IS_ATOM_INT(_exp_22680)) {
        _1 = (long)(DBL_PTR(_exp_22680)->dbl);
        DeRefDS(_exp_22680);
        _exp_22680 = _1;
    }
    goto L8; // [172] 200
L7: 

    /** 						exp += string_to_int( s[e+1..$] )*/
    _13207 = _e_22679 + 1;
    if (_13207 > MAXINT){
        _13207 = NewDouble((double)_13207);
    }
    if (IS_SEQUENCE(_s_22677)){
            _13208 = SEQ_PTR(_s_22677)->length;
    }
    else {
        _13208 = 1;
    }
    rhs_slice_target = (object_ptr)&_13209;
    RHS_Slice(_s_22677, _13207, _13208);
    _13210 = _61string_to_int(_13209);
    _13209 = NOVALUE;
    if (IS_ATOM_INT(_13210)) {
        _exp_22680 = _exp_22680 + _13210;
    }
    else {
        _exp_22680 = binary_op(PLUS, _exp_22680, _13210);
    }
    DeRef(_13210);
    _13210 = NOVALUE;
    if (!IS_ATOM_INT(_exp_22680)) {
        _1 = (long)(DBL_PTR(_exp_22680)->dbl);
        DeRefDS(_exp_22680);
        _exp_22680 = _1;
    }
L8: 
L6: 

    /** 		if dp then*/
    if (_dp_22678 == 0)
    {
        goto L9; // [203] 252
    }
    else{
    }

    /** 				s = s[1..dp-1] & s[dp+1..$]*/
    _13212 = _dp_22678 - 1;
    rhs_slice_target = (object_ptr)&_13213;
    RHS_Slice(_s_22677, 1, _13212);
    _13214 = _dp_22678 + 1;
    if (_13214 > MAXINT){
        _13214 = NewDouble((double)_13214);
    }
    if (IS_SEQUENCE(_s_22677)){
            _13215 = SEQ_PTR(_s_22677)->length;
    }
    else {
        _13215 = 1;
    }
    rhs_slice_target = (object_ptr)&_13216;
    RHS_Slice(_s_22677, _13214, _13215);
    Concat((object_ptr)&_s_22677, _13213, _13216);
    DeRefDS(_13213);
    _13213 = NOVALUE;
    DeRef(_13213);
    _13213 = NOVALUE;
    DeRefDS(_13216);
    _13216 = NOVALUE;

    /** 				e -= 1*/
    _e_22679 = _e_22679 - 1;

    /** 				exp -= e - dp*/
    _13219 = _e_22679 - _dp_22678;
    if ((long)((unsigned long)_13219 +(unsigned long) HIGH_BITS) >= 0){
        _13219 = NewDouble((double)_13219);
    }
    if (IS_ATOM_INT(_13219)) {
        _exp_22680 = _exp_22680 - _13219;
    }
    else {
        _exp_22680 = NewDouble((double)_exp_22680 - DBL_PTR(_13219)->dbl);
    }
    DeRef(_13219);
    _13219 = NOVALUE;
    if (!IS_ATOM_INT(_exp_22680)) {
        _1 = (long)(DBL_PTR(_exp_22680)->dbl);
        DeRefDS(_exp_22680);
        _exp_22680 = _1;
    }
L9: 

    /** 		s = s[1..e-1] - '0'*/
    _13221 = _e_22679 - 1;
    rhs_slice_target = (object_ptr)&_13222;
    RHS_Slice(_s_22677, 1, _13221);
    DeRefDS(_s_22677);
    _s_22677 = binary_op(MINUS, _13222, 48);
    DeRefDS(_13222);
    _13222 = NOVALUE;

    /** 		if not find(0, s = 0) then*/
    _13224 = binary_op(EQUALS, _s_22677, 0);
    _13225 = find_from(0, _13224, 1);
    DeRefDS(_13224);
    _13224 = NOVALUE;
    if (_13225 != 0)
    goto LA; // [280] 294
    _13225 = NOVALUE;

    /** 			return atom_to_float64(0)*/
    _13227 = _13atom_to_float64(0);
    DeRefDS(_s_22677);
    DeRef(_int_bits_22681);
    DeRef(_frac_bits_22682);
    DeRef(_mbits_22683);
    DeRef(_ebits_22684);
    DeRefi(_sbits_22685);
    DeRef(_13191);
    _13191 = NOVALUE;
    DeRef(_13194);
    _13194 = NOVALUE;
    DeRef(_13199);
    _13199 = NOVALUE;
    DeRef(_13202);
    _13202 = NOVALUE;
    DeRef(_13207);
    _13207 = NOVALUE;
    DeRef(_13212);
    _13212 = NOVALUE;
    _13221 = NOVALUE;
    DeRef(_13214);
    _13214 = NOVALUE;
    return _13227;
LA: 

    /** 		if exp >= 0 then*/
    if (_exp_22680 < 0)
    goto LB; // [296] 340

    /** 				int_bits = trim_bits( bytes_to_bits( convert_radix( repeat( 0, exp ) & reverse( s ), 10, #100 ) ) )*/
    _13229 = Repeat(0, _exp_22680);
    RefDS(_s_22677);
    _13230 = _61reverse(_s_22677);
    if (IS_SEQUENCE(_13229) && IS_ATOM(_13230)) {
        Ref(_13230);
        Append(&_13231, _13229, _13230);
    }
    else if (IS_ATOM(_13229) && IS_SEQUENCE(_13230)) {
    }
    else {
        Concat((object_ptr)&_13231, _13229, _13230);
        DeRefDS(_13229);
        _13229 = NOVALUE;
    }
    DeRef(_13229);
    _13229 = NOVALUE;
    DeRef(_13230);
    _13230 = NOVALUE;
    _13232 = _61convert_radix(_13231, 10, 256);
    _13231 = NOVALUE;
    _13233 = _61bytes_to_bits(_13232);
    _13232 = NOVALUE;
    _0 = _int_bits_22681;
    _int_bits_22681 = _61trim_bits(_13233);
    DeRef(_0);
    _13233 = NOVALUE;

    /** 				frac_bits = {}*/
    RefDS(_5);
    DeRef(_frac_bits_22682);
    _frac_bits_22682 = _5;
    goto LC; // [337] 451
LB: 

    /** 				if -exp > length(s) then*/
    if ((unsigned long)_exp_22680 == 0xC0000000)
    _13235 = (int)NewDouble((double)-0xC0000000);
    else
    _13235 = - _exp_22680;
    if (IS_SEQUENCE(_s_22677)){
            _13236 = SEQ_PTR(_s_22677)->length;
    }
    else {
        _13236 = 1;
    }
    if (binary_op_a(LESSEQ, _13235, _13236)){
        DeRef(_13235);
        _13235 = NOVALUE;
        _13236 = NOVALUE;
        goto LD; // [348] 388
    }
    DeRef(_13235);
    _13235 = NOVALUE;
    _13236 = NOVALUE;

    /** 						int_bits = {}*/
    RefDS(_5);
    DeRef(_int_bits_22681);
    _int_bits_22681 = _5;

    /** 						frac_bits = decimals_to_bits( repeat( 0, -exp-length(s) ) & s ) */
    if ((unsigned long)_exp_22680 == 0xC0000000)
    _13238 = (int)NewDouble((double)-0xC0000000);
    else
    _13238 = - _exp_22680;
    if (IS_SEQUENCE(_s_22677)){
            _13239 = SEQ_PTR(_s_22677)->length;
    }
    else {
        _13239 = 1;
    }
    if (IS_ATOM_INT(_13238)) {
        _13240 = _13238 - _13239;
    }
    else {
        _13240 = NewDouble(DBL_PTR(_13238)->dbl - (double)_13239);
    }
    DeRef(_13238);
    _13238 = NOVALUE;
    _13239 = NOVALUE;
    _13241 = Repeat(0, _13240);
    DeRef(_13240);
    _13240 = NOVALUE;
    Concat((object_ptr)&_13242, _13241, _s_22677);
    DeRefDS(_13241);
    _13241 = NOVALUE;
    DeRef(_13241);
    _13241 = NOVALUE;
    _0 = _frac_bits_22682;
    _frac_bits_22682 = _61decimals_to_bits(_13242);
    DeRef(_0);
    _13242 = NOVALUE;
    goto LE; // [385] 450
LD: 

    /** 						int_bits = trim_bits( bytes_to_bits( convert_radix( reverse( s[1..$+exp] ), 10, #100 ) ) )*/
    if (IS_SEQUENCE(_s_22677)){
            _13244 = SEQ_PTR(_s_22677)->length;
    }
    else {
        _13244 = 1;
    }
    _13245 = _13244 + _exp_22680;
    _13244 = NOVALUE;
    rhs_slice_target = (object_ptr)&_13246;
    RHS_Slice(_s_22677, 1, _13245);
    _13247 = _61reverse(_13246);
    _13246 = NOVALUE;
    _13248 = _61convert_radix(_13247, 10, 256);
    _13247 = NOVALUE;
    _13249 = _61bytes_to_bits(_13248);
    _13248 = NOVALUE;
    _0 = _int_bits_22681;
    _int_bits_22681 = _61trim_bits(_13249);
    DeRef(_0);
    _13249 = NOVALUE;

    /** 						frac_bits =  decimals_to_bits( s[$+exp+1..$] )*/
    if (IS_SEQUENCE(_s_22677)){
            _13251 = SEQ_PTR(_s_22677)->length;
    }
    else {
        _13251 = 1;
    }
    _13252 = _13251 + _exp_22680;
    if ((long)((unsigned long)_13252 + (unsigned long)HIGH_BITS) >= 0) 
    _13252 = NewDouble((double)_13252);
    _13251 = NOVALUE;
    if (IS_ATOM_INT(_13252)) {
        _13253 = _13252 + 1;
        if (_13253 > MAXINT){
            _13253 = NewDouble((double)_13253);
        }
    }
    else
    _13253 = binary_op(PLUS, 1, _13252);
    DeRef(_13252);
    _13252 = NOVALUE;
    if (IS_SEQUENCE(_s_22677)){
            _13254 = SEQ_PTR(_s_22677)->length;
    }
    else {
        _13254 = 1;
    }
    rhs_slice_target = (object_ptr)&_13255;
    RHS_Slice(_s_22677, _13253, _13254);
    _0 = _frac_bits_22682;
    _frac_bits_22682 = _61decimals_to_bits(_13255);
    DeRef(_0);
    _13255 = NOVALUE;
LE: 
LC: 

    /** 		if length(int_bits) >= 53 then*/
    if (IS_SEQUENCE(_int_bits_22681)){
            _13257 = SEQ_PTR(_int_bits_22681)->length;
    }
    else {
        _13257 = 1;
    }
    if (_13257 < 53)
    goto LF; // [458] 547

    /** 				mbits = int_bits[$-52..$-1]*/
    if (IS_SEQUENCE(_int_bits_22681)){
            _13259 = SEQ_PTR(_int_bits_22681)->length;
    }
    else {
        _13259 = 1;
    }
    _13260 = _13259 - 52;
    _13259 = NOVALUE;
    if (IS_SEQUENCE(_int_bits_22681)){
            _13261 = SEQ_PTR(_int_bits_22681)->length;
    }
    else {
        _13261 = 1;
    }
    _13262 = _13261 - 1;
    _13261 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mbits_22683;
    RHS_Slice(_int_bits_22681, _13260, _13262);

    /** 				if length(int_bits) > 53 and int_bits[$-53] then*/
    if (IS_SEQUENCE(_int_bits_22681)){
            _13264 = SEQ_PTR(_int_bits_22681)->length;
    }
    else {
        _13264 = 1;
    }
    _13265 = (_13264 > 53);
    _13264 = NOVALUE;
    if (_13265 == 0) {
        goto L10; // [492] 535
    }
    if (IS_SEQUENCE(_int_bits_22681)){
            _13267 = SEQ_PTR(_int_bits_22681)->length;
    }
    else {
        _13267 = 1;
    }
    _13268 = _13267 - 53;
    _13267 = NOVALUE;
    _2 = (int)SEQ_PTR(_int_bits_22681);
    _13269 = (int)*(((s1_ptr)_2)->base + _13268);
    if (_13269 == 0) {
        _13269 = NOVALUE;
        goto L10; // [508] 535
    }
    else {
        if (!IS_ATOM_INT(_13269) && DBL_PTR(_13269)->dbl == 0.0){
            _13269 = NOVALUE;
            goto L10; // [508] 535
        }
        _13269 = NOVALUE;
    }
    _13269 = NOVALUE;

    /** 						mbits[1] += 1*/
    _2 = (int)SEQ_PTR(_mbits_22683);
    _13270 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_13270)) {
        _13271 = _13270 + 1;
        if (_13271 > MAXINT){
            _13271 = NewDouble((double)_13271);
        }
    }
    else
    _13271 = binary_op(PLUS, 1, _13270);
    _13270 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22683);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _mbits_22683 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _13271;
    if( _1 != _13271 ){
        DeRef(_1);
    }
    _13271 = NOVALUE;

    /** 						mbits = carry( mbits, 2 )*/
    RefDS(_mbits_22683);
    _0 = _mbits_22683;
    _mbits_22683 = _61carry(_mbits_22683, 2);
    DeRefDS(_0);
L10: 

    /** 				exp = length(int_bits)-1*/
    if (IS_SEQUENCE(_int_bits_22681)){
            _13273 = SEQ_PTR(_int_bits_22681)->length;
    }
    else {
        _13273 = 1;
    }
    _exp_22680 = _13273 - 1;
    _13273 = NOVALUE;
    goto L11; // [544] 783
LF: 

    /** 				if length(int_bits) then*/
    if (IS_SEQUENCE(_int_bits_22681)){
            _13275 = SEQ_PTR(_int_bits_22681)->length;
    }
    else {
        _13275 = 1;
    }
    if (_13275 == 0)
    {
        _13275 = NOVALUE;
        goto L12; // [552] 567
    }
    else{
        _13275 = NOVALUE;
    }

    /** 						exp = length(int_bits)-1*/
    if (IS_SEQUENCE(_int_bits_22681)){
            _13276 = SEQ_PTR(_int_bits_22681)->length;
    }
    else {
        _13276 = 1;
    }
    _exp_22680 = _13276 - 1;
    _13276 = NOVALUE;
    goto L13; // [564] 622
L12: 

    /** 						exp = - find( 1, reverse( frac_bits ) )*/
    RefDS(_frac_bits_22682);
    _13278 = _61reverse(_frac_bits_22682);
    _13279 = find_from(1, _13278, 1);
    DeRef(_13278);
    _13278 = NOVALUE;
    _exp_22680 = - _13279;

    /** 						if exp < -1023 then*/
    if (_exp_22680 >= -1023)
    goto L14; // [587] 597

    /** 								exp = -1023*/
    _exp_22680 = -1023;
L14: 

    /** 						if exp then*/
    if (_exp_22680 == 0)
    {
        goto L15; // [599] 621
    }
    else{
    }

    /** 								frac_bits = frac_bits[1..$+exp+1]*/
    if (IS_SEQUENCE(_frac_bits_22682)){
            _13284 = SEQ_PTR(_frac_bits_22682)->length;
    }
    else {
        _13284 = 1;
    }
    _13285 = _13284 + _exp_22680;
    if ((long)((unsigned long)_13285 + (unsigned long)HIGH_BITS) >= 0) 
    _13285 = NewDouble((double)_13285);
    _13284 = NOVALUE;
    if (IS_ATOM_INT(_13285)) {
        _13286 = _13285 + 1;
    }
    else
    _13286 = binary_op(PLUS, 1, _13285);
    DeRef(_13285);
    _13285 = NOVALUE;
    rhs_slice_target = (object_ptr)&_frac_bits_22682;
    RHS_Slice(_frac_bits_22682, 1, _13286);
L15: 
L13: 

    /** 				mbits = frac_bits & int_bits*/
    Concat((object_ptr)&_mbits_22683, _frac_bits_22682, _int_bits_22681);

    /** 				mbits = repeat( 0, 53 ) & mbits*/
    _13289 = Repeat(0, 53);
    Concat((object_ptr)&_mbits_22683, _13289, _mbits_22683);
    DeRefDS(_13289);
    _13289 = NOVALUE;
    DeRef(_13289);
    _13289 = NOVALUE;

    /** 				if exp > -1023 then*/
    if (_exp_22680 <= -1023)
    goto L16; // [642] 717

    /** 						if mbits[$-53] then*/
    if (IS_SEQUENCE(_mbits_22683)){
            _13292 = SEQ_PTR(_mbits_22683)->length;
    }
    else {
        _13292 = 1;
    }
    _13293 = _13292 - 53;
    _13292 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22683);
    _13294 = (int)*(((s1_ptr)_2)->base + _13293);
    if (_13294 == 0) {
        _13294 = NOVALUE;
        goto L17; // [659] 693
    }
    else {
        if (!IS_ATOM_INT(_13294) && DBL_PTR(_13294)->dbl == 0.0){
            _13294 = NOVALUE;
            goto L17; // [659] 693
        }
        _13294 = NOVALUE;
    }
    _13294 = NOVALUE;

    /** 								mbits[$-52] += 1*/
    if (IS_SEQUENCE(_mbits_22683)){
            _13295 = SEQ_PTR(_mbits_22683)->length;
    }
    else {
        _13295 = 1;
    }
    _13296 = _13295 - 52;
    _13295 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22683);
    _13297 = (int)*(((s1_ptr)_2)->base + _13296);
    if (IS_ATOM_INT(_13297)) {
        _13298 = _13297 + 1;
        if (_13298 > MAXINT){
            _13298 = NewDouble((double)_13298);
        }
    }
    else
    _13298 = binary_op(PLUS, 1, _13297);
    _13297 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22683);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _mbits_22683 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13296);
    _1 = *(int *)_2;
    *(int *)_2 = _13298;
    if( _1 != _13298 ){
        DeRef(_1);
    }
    _13298 = NOVALUE;

    /** 								mbits = carry( mbits, 2 )*/
    RefDS(_mbits_22683);
    _0 = _mbits_22683;
    _mbits_22683 = _61carry(_mbits_22683, 2);
    DeRefDS(_0);
L17: 

    /** 						mbits = mbits[$-52..$-1]*/
    if (IS_SEQUENCE(_mbits_22683)){
            _13300 = SEQ_PTR(_mbits_22683)->length;
    }
    else {
        _13300 = 1;
    }
    _13301 = _13300 - 52;
    _13300 = NOVALUE;
    if (IS_SEQUENCE(_mbits_22683)){
            _13302 = SEQ_PTR(_mbits_22683)->length;
    }
    else {
        _13302 = 1;
    }
    _13303 = _13302 - 1;
    _13302 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mbits_22683;
    RHS_Slice(_mbits_22683, _13301, _13303);
    goto L18; // [714] 782
L16: 

    /** 						if mbits[$-52] then*/
    if (IS_SEQUENCE(_mbits_22683)){
            _13305 = SEQ_PTR(_mbits_22683)->length;
    }
    else {
        _13305 = 1;
    }
    _13306 = _13305 - 52;
    _13305 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22683);
    _13307 = (int)*(((s1_ptr)_2)->base + _13306);
    if (_13307 == 0) {
        _13307 = NOVALUE;
        goto L19; // [730] 764
    }
    else {
        if (!IS_ATOM_INT(_13307) && DBL_PTR(_13307)->dbl == 0.0){
            _13307 = NOVALUE;
            goto L19; // [730] 764
        }
        _13307 = NOVALUE;
    }
    _13307 = NOVALUE;

    /** 								mbits[$-52] += 1*/
    if (IS_SEQUENCE(_mbits_22683)){
            _13308 = SEQ_PTR(_mbits_22683)->length;
    }
    else {
        _13308 = 1;
    }
    _13309 = _13308 - 52;
    _13308 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22683);
    _13310 = (int)*(((s1_ptr)_2)->base + _13309);
    if (IS_ATOM_INT(_13310)) {
        _13311 = _13310 + 1;
        if (_13311 > MAXINT){
            _13311 = NewDouble((double)_13311);
        }
    }
    else
    _13311 = binary_op(PLUS, 1, _13310);
    _13310 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22683);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _mbits_22683 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13309);
    _1 = *(int *)_2;
    *(int *)_2 = _13311;
    if( _1 != _13311 ){
        DeRef(_1);
    }
    _13311 = NOVALUE;

    /** 								mbits = carry( mbits, 2 )*/
    RefDS(_mbits_22683);
    _0 = _mbits_22683;
    _mbits_22683 = _61carry(_mbits_22683, 2);
    DeRefDS(_0);
L19: 

    /** 						mbits = mbits[$-51..$]*/
    if (IS_SEQUENCE(_mbits_22683)){
            _13313 = SEQ_PTR(_mbits_22683)->length;
    }
    else {
        _13313 = 1;
    }
    _13314 = _13313 - 51;
    _13313 = NOVALUE;
    if (IS_SEQUENCE(_mbits_22683)){
            _13315 = SEQ_PTR(_mbits_22683)->length;
    }
    else {
        _13315 = 1;
    }
    rhs_slice_target = (object_ptr)&_mbits_22683;
    RHS_Slice(_mbits_22683, _13314, _13315);
L18: 
L11: 

    /** 		ebits = int_to_bits( exp + 1023, 11 )*/
    _13317 = _exp_22680 + 1023;
    if ((long)((unsigned long)_13317 + (unsigned long)HIGH_BITS) >= 0) 
    _13317 = NewDouble((double)_13317);
    _0 = _ebits_22684;
    _ebits_22684 = _13int_to_bits(_13317, 11);
    DeRef(_0);
    _13317 = NOVALUE;

    /** 		return bits_to_bytes( mbits & ebits & sbits )*/
    {
        int concat_list[3];

        concat_list[0] = _sbits_22685;
        concat_list[1] = _ebits_22684;
        concat_list[2] = _mbits_22683;
        Concat_N((object_ptr)&_13319, concat_list, 3);
    }
    _13320 = _61bits_to_bytes(_13319);
    _13319 = NOVALUE;
    DeRefDS(_s_22677);
    DeRef(_int_bits_22681);
    DeRef(_frac_bits_22682);
    DeRefDS(_mbits_22683);
    DeRefDS(_ebits_22684);
    DeRefDSi(_sbits_22685);
    DeRef(_13214);
    _13214 = NOVALUE;
    DeRef(_13227);
    _13227 = NOVALUE;
    DeRef(_13245);
    _13245 = NOVALUE;
    DeRef(_13207);
    _13207 = NOVALUE;
    DeRef(_13309);
    _13309 = NOVALUE;
    DeRef(_13221);
    _13221 = NOVALUE;
    DeRef(_13303);
    _13303 = NOVALUE;
    DeRef(_13260);
    _13260 = NOVALUE;
    DeRef(_13286);
    _13286 = NOVALUE;
    DeRef(_13262);
    _13262 = NOVALUE;
    DeRef(_13265);
    _13265 = NOVALUE;
    DeRef(_13253);
    _13253 = NOVALUE;
    DeRef(_13268);
    _13268 = NOVALUE;
    DeRef(_13301);
    _13301 = NOVALUE;
    DeRef(_13314);
    _13314 = NOVALUE;
    DeRef(_13191);
    _13191 = NOVALUE;
    DeRef(_13199);
    _13199 = NOVALUE;
    DeRef(_13306);
    _13306 = NOVALUE;
    DeRef(_13202);
    _13202 = NOVALUE;
    DeRef(_13194);
    _13194 = NOVALUE;
    DeRef(_13296);
    _13296 = NOVALUE;
    DeRef(_13293);
    _13293 = NOVALUE;
    DeRef(_13212);
    _13212 = NOVALUE;
    return _13320;
    ;
}


int _61scientific_to_atom(int _s_22858)
{
    int _13322 = NOVALUE;
    int _13321 = NOVALUE;
    int _0, _1, _2;
    

    /** 		return float64_to_atom( scientific_to_float64( s ) )*/
    RefDS(_s_22858);
    _13321 = _61scientific_to_float64(_s_22858);
    _13322 = _13float64_to_atom(_13321);
    _13321 = NOVALUE;
    DeRefDS(_s_22858);
    return _13322;
    ;
}



// 0x28648308
