// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _32map(int _obj_p_12999)
{
    int _m__13003 = NOVALUE;
    int _7102 = NOVALUE;
    int _7101 = NOVALUE;
    int _7100 = NOVALUE;
    int _7099 = NOVALUE;
    int _7098 = NOVALUE;
    int _7097 = NOVALUE;
    int _7096 = NOVALUE;
    int _7095 = NOVALUE;
    int _7094 = NOVALUE;
    int _7093 = NOVALUE;
    int _7091 = NOVALUE;
    int _7090 = NOVALUE;
    int _7089 = NOVALUE;
    int _7088 = NOVALUE;
    int _7086 = NOVALUE;
    int _7085 = NOVALUE;
    int _7084 = NOVALUE;
    int _7083 = NOVALUE;
    int _7081 = NOVALUE;
    int _7080 = NOVALUE;
    int _7079 = NOVALUE;
    int _7078 = NOVALUE;
    int _7077 = NOVALUE;
    int _7076 = NOVALUE;
    int _7075 = NOVALUE;
    int _7074 = NOVALUE;
    int _7073 = NOVALUE;
    int _7072 = NOVALUE;
    int _7070 = NOVALUE;
    int _7068 = NOVALUE;
    int _7067 = NOVALUE;
    int _7065 = NOVALUE;
    int _7063 = NOVALUE;
    int _7062 = NOVALUE;
    int _7060 = NOVALUE;
    int _7059 = NOVALUE;
    int _7057 = NOVALUE;
    int _7055 = NOVALUE;
    int _7053 = NOVALUE;
    int _7050 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not eumem:valid(obj_p, "") then return 0 end if*/
    Ref(_obj_p_12999);
    RefDS(_5);
    _7050 = _33valid(_obj_p_12999, _5);
    if (IS_ATOM_INT(_7050)) {
        if (_7050 != 0){
            DeRef(_7050);
            _7050 = NOVALUE;
            goto L1; // [8] 16
        }
    }
    else {
        if (DBL_PTR(_7050)->dbl != 0.0){
            DeRef(_7050);
            _7050 = NOVALUE;
            goto L1; // [8] 16
        }
    }
    DeRef(_7050);
    _7050 = NOVALUE;
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    return 0;
L1: 

    /** 	object m_*/

    /** 	m_ = eumem:ram_space[obj_p]*/
    DeRef(_m__13003);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!IS_ATOM_INT(_obj_p_12999)){
        _m__13003 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_obj_p_12999)->dbl));
    }
    else{
        _m__13003 = (int)*(((s1_ptr)_2)->base + _obj_p_12999);
    }
    Ref(_m__13003);

    /** 	if not sequence(m_) then return 0 end if*/
    _7053 = IS_SEQUENCE(_m__13003);
    if (_7053 != 0)
    goto L2; // [31] 39
    _7053 = NOVALUE;
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    return 0;
L2: 

    /** 	if length(m_) < 6 then return 0 end if*/
    if (IS_SEQUENCE(_m__13003)){
            _7055 = SEQ_PTR(_m__13003)->length;
    }
    else {
        _7055 = 1;
    }
    if (_7055 >= 6)
    goto L3; // [44] 53
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    return 0;
L3: 

    /** 	if length(m_) > 7 then return 0 end if*/
    if (IS_SEQUENCE(_m__13003)){
            _7057 = SEQ_PTR(_m__13003)->length;
    }
    else {
        _7057 = 1;
    }
    if (_7057 <= 7)
    goto L4; // [58] 67
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    return 0;
L4: 

    /** 	if not equal(m_[TYPE_TAG], type_is_map) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__13003);
    _7059 = (int)*(((s1_ptr)_2)->base + 1);
    if (_7059 == _32type_is_map_12979)
    _7060 = 1;
    else if (IS_ATOM_INT(_7059) && IS_ATOM_INT(_32type_is_map_12979))
    _7060 = 0;
    else
    _7060 = (compare(_7059, _32type_is_map_12979) == 0);
    _7059 = NOVALUE;
    if (_7060 != 0)
    goto L5; // [77] 85
    _7060 = NOVALUE;
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    return 0;
L5: 

    /** 	if not integer(m_[ELEMENT_COUNT]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__13003);
    _7062 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7062))
    _7063 = 1;
    else if (IS_ATOM_DBL(_7062))
    _7063 = IS_ATOM_INT(DoubleToInt(_7062));
    else
    _7063 = 0;
    _7062 = NOVALUE;
    if (_7063 != 0)
    goto L6; // [94] 102
    _7063 = NOVALUE;
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    return 0;
L6: 

    /** 	if m_[ELEMENT_COUNT] < 0 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__13003);
    _7065 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(GREATEREQ, _7065, 0)){
        _7065 = NOVALUE;
        goto L7; // [108] 117
    }
    _7065 = NOVALUE;
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    return 0;
L7: 

    /** 	if not integer(m_[IN_USE]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__13003);
    _7067 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7067))
    _7068 = 1;
    else if (IS_ATOM_DBL(_7067))
    _7068 = IS_ATOM_INT(DoubleToInt(_7067));
    else
    _7068 = 0;
    _7067 = NOVALUE;
    if (_7068 != 0)
    goto L8; // [126] 134
    _7068 = NOVALUE;
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    return 0;
L8: 

    /** 	if m_[IN_USE] < 0		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__13003);
    _7070 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(GREATEREQ, _7070, 0)){
        _7070 = NOVALUE;
        goto L9; // [140] 149
    }
    _7070 = NOVALUE;
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    return 0;
L9: 

    /** 	if equal(m_[MAP_TYPE],SMALLMAP) then*/
    _2 = (int)SEQ_PTR(_m__13003);
    _7072 = (int)*(((s1_ptr)_2)->base + 4);
    if (_7072 == 115)
    _7073 = 1;
    else if (IS_ATOM_INT(_7072) && IS_ATOM_INT(115))
    _7073 = 0;
    else
    _7073 = (compare(_7072, 115) == 0);
    _7072 = NOVALUE;
    if (_7073 == 0)
    {
        _7073 = NOVALUE;
        goto LA; // [159] 284
    }
    else{
        _7073 = NOVALUE;
    }

    /** 		if atom(m_[KEY_LIST]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__13003);
    _7074 = (int)*(((s1_ptr)_2)->base + 5);
    _7075 = IS_ATOM(_7074);
    _7074 = NOVALUE;
    if (_7075 == 0)
    {
        _7075 = NOVALUE;
        goto LB; // [171] 179
    }
    else{
        _7075 = NOVALUE;
    }
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    return 0;
LB: 

    /** 		if atom(m_[VALUE_LIST]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__13003);
    _7076 = (int)*(((s1_ptr)_2)->base + 6);
    _7077 = IS_ATOM(_7076);
    _7076 = NOVALUE;
    if (_7077 == 0)
    {
        _7077 = NOVALUE;
        goto LC; // [188] 196
    }
    else{
        _7077 = NOVALUE;
    }
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    return 0;
LC: 

    /** 		if atom(m_[FREE_LIST]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__13003);
    _7078 = (int)*(((s1_ptr)_2)->base + 7);
    _7079 = IS_ATOM(_7078);
    _7078 = NOVALUE;
    if (_7079 == 0)
    {
        _7079 = NOVALUE;
        goto LD; // [205] 213
    }
    else{
        _7079 = NOVALUE;
    }
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    return 0;
LD: 

    /** 		if length(m_[KEY_LIST]) = 0  then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__13003);
    _7080 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7080)){
            _7081 = SEQ_PTR(_7080)->length;
    }
    else {
        _7081 = 1;
    }
    _7080 = NOVALUE;
    if (_7081 != 0)
    goto LE; // [222] 231
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    _7080 = NOVALUE;
    return 0;
LE: 

    /** 		if length(m_[KEY_LIST]) != length(m_[VALUE_LIST]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__13003);
    _7083 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7083)){
            _7084 = SEQ_PTR(_7083)->length;
    }
    else {
        _7084 = 1;
    }
    _7083 = NOVALUE;
    _2 = (int)SEQ_PTR(_m__13003);
    _7085 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_7085)){
            _7086 = SEQ_PTR(_7085)->length;
    }
    else {
        _7086 = 1;
    }
    _7085 = NOVALUE;
    if (_7084 == _7086)
    goto LF; // [247] 256
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    _7080 = NOVALUE;
    _7083 = NOVALUE;
    _7085 = NOVALUE;
    return 0;
LF: 

    /** 		if length(m_[KEY_LIST]) != length(m_[FREE_LIST]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__13003);
    _7088 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7088)){
            _7089 = SEQ_PTR(_7088)->length;
    }
    else {
        _7089 = 1;
    }
    _7088 = NOVALUE;
    _2 = (int)SEQ_PTR(_m__13003);
    _7090 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7090)){
            _7091 = SEQ_PTR(_7090)->length;
    }
    else {
        _7091 = 1;
    }
    _7090 = NOVALUE;
    if (_7089 == _7091)
    goto L10; // [272] 366
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    _7080 = NOVALUE;
    _7083 = NOVALUE;
    _7085 = NOVALUE;
    _7088 = NOVALUE;
    _7090 = NOVALUE;
    return 0;
    goto L10; // [281] 366
LA: 

    /** 	elsif  equal(m_[MAP_TYPE],LARGEMAP) then*/
    _2 = (int)SEQ_PTR(_m__13003);
    _7093 = (int)*(((s1_ptr)_2)->base + 4);
    if (_7093 == 76)
    _7094 = 1;
    else if (IS_ATOM_INT(_7093) && IS_ATOM_INT(76))
    _7094 = 0;
    else
    _7094 = (compare(_7093, 76) == 0);
    _7093 = NOVALUE;
    if (_7094 == 0)
    {
        _7094 = NOVALUE;
        goto L11; // [294] 359
    }
    else{
        _7094 = NOVALUE;
    }

    /** 		if atom(m_[KEY_BUCKETS]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__13003);
    _7095 = (int)*(((s1_ptr)_2)->base + 5);
    _7096 = IS_ATOM(_7095);
    _7095 = NOVALUE;
    if (_7096 == 0)
    {
        _7096 = NOVALUE;
        goto L12; // [306] 314
    }
    else{
        _7096 = NOVALUE;
    }
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    _7080 = NOVALUE;
    _7083 = NOVALUE;
    _7085 = NOVALUE;
    _7088 = NOVALUE;
    _7090 = NOVALUE;
    return 0;
L12: 

    /** 		if atom(m_[VALUE_BUCKETS]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__13003);
    _7097 = (int)*(((s1_ptr)_2)->base + 6);
    _7098 = IS_ATOM(_7097);
    _7097 = NOVALUE;
    if (_7098 == 0)
    {
        _7098 = NOVALUE;
        goto L13; // [323] 331
    }
    else{
        _7098 = NOVALUE;
    }
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    _7080 = NOVALUE;
    _7083 = NOVALUE;
    _7085 = NOVALUE;
    _7088 = NOVALUE;
    _7090 = NOVALUE;
    return 0;
L13: 

    /** 		if length(m_[KEY_BUCKETS]) != length(m_[VALUE_BUCKETS])	then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__13003);
    _7099 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7099)){
            _7100 = SEQ_PTR(_7099)->length;
    }
    else {
        _7100 = 1;
    }
    _7099 = NOVALUE;
    _2 = (int)SEQ_PTR(_m__13003);
    _7101 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_7101)){
            _7102 = SEQ_PTR(_7101)->length;
    }
    else {
        _7102 = 1;
    }
    _7101 = NOVALUE;
    if (_7100 == _7102)
    goto L10; // [347] 366
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    _7080 = NOVALUE;
    _7083 = NOVALUE;
    _7085 = NOVALUE;
    _7088 = NOVALUE;
    _7090 = NOVALUE;
    _7099 = NOVALUE;
    _7101 = NOVALUE;
    return 0;
    goto L10; // [356] 366
L11: 

    /** 		return 0*/
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    _7080 = NOVALUE;
    _7083 = NOVALUE;
    _7085 = NOVALUE;
    _7088 = NOVALUE;
    _7090 = NOVALUE;
    _7099 = NOVALUE;
    _7101 = NOVALUE;
    return 0;
L10: 

    /** 	return 1*/
    DeRef(_obj_p_12999);
    DeRef(_m__13003);
    _7080 = NOVALUE;
    _7083 = NOVALUE;
    _7085 = NOVALUE;
    _7088 = NOVALUE;
    _7090 = NOVALUE;
    _7099 = NOVALUE;
    _7101 = NOVALUE;
    return 1;
    ;
}


void _32rehash(int _the_map_p_13098, int _requested_bucket_size_p_13099)
{
    int _size__13100 = NOVALUE;
    int _index_2__13101 = NOVALUE;
    int _old_key_buckets__13102 = NOVALUE;
    int _old_val_buckets__13103 = NOVALUE;
    int _new_key_buckets__13104 = NOVALUE;
    int _new_val_buckets__13105 = NOVALUE;
    int _key__13106 = NOVALUE;
    int _value__13107 = NOVALUE;
    int _pos_13108 = NOVALUE;
    int _new_keys_13109 = NOVALUE;
    int _in_use_13110 = NOVALUE;
    int _elem_count_13111 = NOVALUE;
    int _calc_hash_1__tmp_at227_13154 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_227_13153 = NOVALUE;
    int _ret__inlined_calc_hash_at_227_13152 = NOVALUE;
    int _7169 = NOVALUE;
    int _7168 = NOVALUE;
    int _7167 = NOVALUE;
    int _7166 = NOVALUE;
    int _7165 = NOVALUE;
    int _7164 = NOVALUE;
    int _7163 = NOVALUE;
    int _7162 = NOVALUE;
    int _7161 = NOVALUE;
    int _7159 = NOVALUE;
    int _7158 = NOVALUE;
    int _7157 = NOVALUE;
    int _7154 = NOVALUE;
    int _7153 = NOVALUE;
    int _7151 = NOVALUE;
    int _7150 = NOVALUE;
    int _7149 = NOVALUE;
    int _7148 = NOVALUE;
    int _7146 = NOVALUE;
    int _7144 = NOVALUE;
    int _7142 = NOVALUE;
    int _7139 = NOVALUE;
    int _7137 = NOVALUE;
    int _7136 = NOVALUE;
    int _7135 = NOVALUE;
    int _7134 = NOVALUE;
    int _7132 = NOVALUE;
    int _7130 = NOVALUE;
    int _7128 = NOVALUE;
    int _7127 = NOVALUE;
    int _7125 = NOVALUE;
    int _7123 = NOVALUE;
    int _7120 = NOVALUE;
    int _7118 = NOVALUE;
    int _7117 = NOVALUE;
    int _7116 = NOVALUE;
    int _7115 = NOVALUE;
    int _7114 = NOVALUE;
    int _7111 = NOVALUE;
    int _7110 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if eumem:ram_space[the_map_p][MAP_TYPE] = SMALLMAP then*/
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    _7110 = (int)*(((s1_ptr)_2)->base + _the_map_p_13098);
    _2 = (int)SEQ_PTR(_7110);
    _7111 = (int)*(((s1_ptr)_2)->base + 4);
    _7110 = NOVALUE;
    if (binary_op_a(NOTEQ, _7111, 115)){
        _7111 = NOVALUE;
        goto L1; // [17] 27
    }
    _7111 = NOVALUE;

    /** 		return -- small maps are not hashed.*/
    DeRef(_old_key_buckets__13102);
    DeRef(_old_val_buckets__13103);
    DeRef(_new_key_buckets__13104);
    DeRef(_new_val_buckets__13105);
    DeRef(_key__13106);
    DeRef(_value__13107);
    DeRef(_new_keys_13109);
    return;
L1: 

    /** 	if requested_bucket_size_p <= 0 then*/
    if (_requested_bucket_size_p_13099 > 0)
    goto L2; // [29] 62

    /** 		size_ = floor(length(eumem:ram_space[the_map_p][KEY_BUCKETS]) * 3.5) + 1*/
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    _7114 = (int)*(((s1_ptr)_2)->base + _the_map_p_13098);
    _2 = (int)SEQ_PTR(_7114);
    _7115 = (int)*(((s1_ptr)_2)->base + 5);
    _7114 = NOVALUE;
    if (IS_SEQUENCE(_7115)){
            _7116 = SEQ_PTR(_7115)->length;
    }
    else {
        _7116 = 1;
    }
    _7115 = NOVALUE;
    _7117 = NewDouble((double)_7116 * DBL_PTR(_6705)->dbl);
    _7116 = NOVALUE;
    _7118 = unary_op(FLOOR, _7117);
    DeRefDS(_7117);
    _7117 = NOVALUE;
    if (IS_ATOM_INT(_7118)) {
        _size__13100 = _7118 + 1;
    }
    else
    { // coercing _size__13100 to an integer 1
        _size__13100 = 1+(long)(DBL_PTR(_7118)->dbl);
        if( !IS_ATOM_INT(_size__13100) ){
            _size__13100 = (object)DBL_PTR(_size__13100)->dbl;
        }
    }
    DeRef(_7118);
    _7118 = NOVALUE;
    goto L3; // [59] 68
L2: 

    /** 		size_ = requested_bucket_size_p*/
    _size__13100 = _requested_bucket_size_p_13099;
L3: 

    /** 	size_ = primes:next_prime(size_, -size_, 2)	-- Allow up to 2 seconds to calc next prime.*/
    if ((unsigned long)_size__13100 == 0xC0000000)
    _7120 = (int)NewDouble((double)-0xC0000000);
    else
    _7120 = - _size__13100;
    _size__13100 = _34next_prime(_size__13100, _7120, 2);
    _7120 = NOVALUE;
    if (!IS_ATOM_INT(_size__13100)) {
        _1 = (long)(DBL_PTR(_size__13100)->dbl);
        DeRefDS(_size__13100);
        _size__13100 = _1;
    }

    /** 	if size_ < 0 then*/
    if (_size__13100 >= 0)
    goto L4; // [85] 95

    /** 		return  -- don't do anything. New size would take too long.*/
    DeRef(_old_key_buckets__13102);
    DeRef(_old_val_buckets__13103);
    DeRef(_new_key_buckets__13104);
    DeRef(_new_val_buckets__13105);
    DeRef(_key__13106);
    DeRef(_value__13107);
    DeRef(_new_keys_13109);
    _7115 = NOVALUE;
    return;
L4: 

    /** 	old_key_buckets_ = eumem:ram_space[the_map_p][KEY_BUCKETS]*/
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    _7123 = (int)*(((s1_ptr)_2)->base + _the_map_p_13098);
    DeRef(_old_key_buckets__13102);
    _2 = (int)SEQ_PTR(_7123);
    _old_key_buckets__13102 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_old_key_buckets__13102);
    _7123 = NOVALUE;

    /** 	old_val_buckets_ = eumem:ram_space[the_map_p][VALUE_BUCKETS]*/
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    _7125 = (int)*(((s1_ptr)_2)->base + _the_map_p_13098);
    DeRef(_old_val_buckets__13103);
    _2 = (int)SEQ_PTR(_7125);
    _old_val_buckets__13103 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_old_val_buckets__13103);
    _7125 = NOVALUE;

    /** 	new_key_buckets_ = repeat(repeat(1, threshold_size + 1), size_)*/
    _7127 = 24;
    _7128 = Repeat(1, 24);
    _7127 = NOVALUE;
    DeRef(_new_key_buckets__13104);
    _new_key_buckets__13104 = Repeat(_7128, _size__13100);
    DeRefDS(_7128);
    _7128 = NOVALUE;

    /** 	new_val_buckets_ = repeat(repeat(0, threshold_size), size_)*/
    _7130 = Repeat(0, 23);
    DeRef(_new_val_buckets__13105);
    _new_val_buckets__13105 = Repeat(_7130, _size__13100);
    DeRefDS(_7130);
    _7130 = NOVALUE;

    /** 	elem_count = eumem:ram_space[the_map_p][ELEMENT_COUNT]*/
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    _7132 = (int)*(((s1_ptr)_2)->base + _the_map_p_13098);
    _2 = (int)SEQ_PTR(_7132);
    _elem_count_13111 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_elem_count_13111)){
        _elem_count_13111 = (long)DBL_PTR(_elem_count_13111)->dbl;
    }
    _7132 = NOVALUE;

    /** 	in_use = 0*/
    _in_use_13110 = 0;

    /** 	eumem:ram_space[the_map_p] = 0*/
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_12249 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13098);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	for index = 1 to length(old_key_buckets_) do*/
    if (IS_SEQUENCE(_old_key_buckets__13102)){
            _7134 = SEQ_PTR(_old_key_buckets__13102)->length;
    }
    else {
        _7134 = 1;
    }
    {
        int _index_13141;
        _index_13141 = 1;
L5: 
        if (_index_13141 > _7134){
            goto L6; // [183] 373
        }

        /** 		for entry_idx = 1 to length(old_key_buckets_[index]) do*/
        _2 = (int)SEQ_PTR(_old_key_buckets__13102);
        _7135 = (int)*(((s1_ptr)_2)->base + _index_13141);
        if (IS_SEQUENCE(_7135)){
                _7136 = SEQ_PTR(_7135)->length;
        }
        else {
            _7136 = 1;
        }
        _7135 = NOVALUE;
        {
            int _entry_idx_13144;
            _entry_idx_13144 = 1;
L7: 
            if (_entry_idx_13144 > _7136){
                goto L8; // [199] 366
            }

            /** 			key_ = old_key_buckets_[index][entry_idx]*/
            _2 = (int)SEQ_PTR(_old_key_buckets__13102);
            _7137 = (int)*(((s1_ptr)_2)->base + _index_13141);
            DeRef(_key__13106);
            _2 = (int)SEQ_PTR(_7137);
            _key__13106 = (int)*(((s1_ptr)_2)->base + _entry_idx_13144);
            Ref(_key__13106);
            _7137 = NOVALUE;

            /** 			value_ = old_val_buckets_[index][entry_idx]*/
            _2 = (int)SEQ_PTR(_old_val_buckets__13103);
            _7139 = (int)*(((s1_ptr)_2)->base + _index_13141);
            DeRef(_value__13107);
            _2 = (int)SEQ_PTR(_7139);
            _value__13107 = (int)*(((s1_ptr)_2)->base + _entry_idx_13144);
            Ref(_value__13107);
            _7139 = NOVALUE;

            /** 			index_2_ = calc_hash(key_, size_)*/

            /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
            DeRef(_ret__inlined_calc_hash_at_227_13152);
            _ret__inlined_calc_hash_at_227_13152 = calc_hash(_key__13106, -6);
            if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_227_13152)) {
                _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_227_13152)->dbl);
                DeRefDS(_ret__inlined_calc_hash_at_227_13152);
                _ret__inlined_calc_hash_at_227_13152 = _1;
            }

            /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
            _calc_hash_1__tmp_at227_13154 = (_ret__inlined_calc_hash_at_227_13152 % _size__13100);
            _index_2__13101 = _calc_hash_1__tmp_at227_13154 + 1;
            DeRef(_ret__inlined_calc_hash_at_227_13152);
            _ret__inlined_calc_hash_at_227_13152 = NOVALUE;
            if (!IS_ATOM_INT(_index_2__13101)) {
                _1 = (long)(DBL_PTR(_index_2__13101)->dbl);
                DeRefDS(_index_2__13101);
                _index_2__13101 = _1;
            }

            /** 			new_keys = new_key_buckets_[index_2_]*/
            DeRef(_new_keys_13109);
            _2 = (int)SEQ_PTR(_new_key_buckets__13104);
            _new_keys_13109 = (int)*(((s1_ptr)_2)->base + _index_2__13101);
            RefDS(_new_keys_13109);

            /** 			pos = new_keys[$]*/
            if (IS_SEQUENCE(_new_keys_13109)){
                    _7142 = SEQ_PTR(_new_keys_13109)->length;
            }
            else {
                _7142 = 1;
            }
            _2 = (int)SEQ_PTR(_new_keys_13109);
            _pos_13108 = (int)*(((s1_ptr)_2)->base + _7142);
            if (!IS_ATOM_INT(_pos_13108))
            _pos_13108 = (long)DBL_PTR(_pos_13108)->dbl;

            /** 			if length(new_keys) = pos then*/
            if (IS_SEQUENCE(_new_keys_13109)){
                    _7144 = SEQ_PTR(_new_keys_13109)->length;
            }
            else {
                _7144 = 1;
            }
            if (_7144 != _pos_13108)
            goto L9; // [273] 310

            /** 				new_keys &= repeat(pos, threshold_size)*/
            _7146 = Repeat(_pos_13108, 23);
            Concat((object_ptr)&_new_keys_13109, _new_keys_13109, _7146);
            DeRefDS(_7146);
            _7146 = NOVALUE;

            /** 				new_val_buckets_[index_2_] &= repeat(0, threshold_size)*/
            _7148 = Repeat(0, 23);
            _2 = (int)SEQ_PTR(_new_val_buckets__13105);
            _7149 = (int)*(((s1_ptr)_2)->base + _index_2__13101);
            if (IS_SEQUENCE(_7149) && IS_ATOM(_7148)) {
            }
            else if (IS_ATOM(_7149) && IS_SEQUENCE(_7148)) {
                Ref(_7149);
                Prepend(&_7150, _7148, _7149);
            }
            else {
                Concat((object_ptr)&_7150, _7149, _7148);
                _7149 = NOVALUE;
            }
            _7149 = NOVALUE;
            DeRefDS(_7148);
            _7148 = NOVALUE;
            _2 = (int)SEQ_PTR(_new_val_buckets__13105);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_val_buckets__13105 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _index_2__13101);
            _1 = *(int *)_2;
            *(int *)_2 = _7150;
            if( _1 != _7150 ){
                DeRef(_1);
            }
            _7150 = NOVALUE;
L9: 

            /** 			new_keys[pos] = key_*/
            Ref(_key__13106);
            _2 = (int)SEQ_PTR(_new_keys_13109);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_keys_13109 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pos_13108);
            _1 = *(int *)_2;
            *(int *)_2 = _key__13106;
            DeRef(_1);

            /** 			new_val_buckets_[index_2_][pos] = value_*/
            _2 = (int)SEQ_PTR(_new_val_buckets__13105);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_val_buckets__13105 = MAKE_SEQ(_2);
            }
            _3 = (int)(_index_2__13101 + ((s1_ptr)_2)->base);
            Ref(_value__13107);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pos_13108);
            _1 = *(int *)_2;
            *(int *)_2 = _value__13107;
            DeRef(_1);
            _7151 = NOVALUE;

            /** 			new_keys[$] = pos + 1*/
            if (IS_SEQUENCE(_new_keys_13109)){
                    _7153 = SEQ_PTR(_new_keys_13109)->length;
            }
            else {
                _7153 = 1;
            }
            _7154 = _pos_13108 + 1;
            if (_7154 > MAXINT){
                _7154 = NewDouble((double)_7154);
            }
            _2 = (int)SEQ_PTR(_new_keys_13109);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_keys_13109 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _7153);
            _1 = *(int *)_2;
            *(int *)_2 = _7154;
            if( _1 != _7154 ){
                DeRef(_1);
            }
            _7154 = NOVALUE;

            /** 			new_key_buckets_[index_2_] = new_keys*/
            RefDS(_new_keys_13109);
            _2 = (int)SEQ_PTR(_new_key_buckets__13104);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_key_buckets__13104 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _index_2__13101);
            _1 = *(int *)_2;
            *(int *)_2 = _new_keys_13109;
            DeRefDS(_1);

            /** 			if pos = 1 then*/
            if (_pos_13108 != 1)
            goto LA; // [348] 359

            /** 				in_use += 1*/
            _in_use_13110 = _in_use_13110 + 1;
LA: 

            /** 		end for*/
            _entry_idx_13144 = _entry_idx_13144 + 1;
            goto L7; // [361] 206
L8: 
            ;
        }

        /** 	end for*/
        _index_13141 = _index_13141 + 1;
        goto L5; // [368] 190
L6: 
        ;
    }

    /** 	for index = 1 to length(new_key_buckets_) do*/
    if (IS_SEQUENCE(_new_key_buckets__13104)){
            _7157 = SEQ_PTR(_new_key_buckets__13104)->length;
    }
    else {
        _7157 = 1;
    }
    {
        int _index_13174;
        _index_13174 = 1;
LB: 
        if (_index_13174 > _7157){
            goto LC; // [378] 451
        }

        /** 		pos = new_key_buckets_[index][$]*/
        _2 = (int)SEQ_PTR(_new_key_buckets__13104);
        _7158 = (int)*(((s1_ptr)_2)->base + _index_13174);
        if (IS_SEQUENCE(_7158)){
                _7159 = SEQ_PTR(_7158)->length;
        }
        else {
            _7159 = 1;
        }
        _2 = (int)SEQ_PTR(_7158);
        _pos_13108 = (int)*(((s1_ptr)_2)->base + _7159);
        if (!IS_ATOM_INT(_pos_13108)){
            _pos_13108 = (long)DBL_PTR(_pos_13108)->dbl;
        }
        _7158 = NOVALUE;

        /** 		new_key_buckets_[index] = remove(new_key_buckets_[index], pos, */
        _2 = (int)SEQ_PTR(_new_key_buckets__13104);
        _7161 = (int)*(((s1_ptr)_2)->base + _index_13174);
        _2 = (int)SEQ_PTR(_new_key_buckets__13104);
        _7162 = (int)*(((s1_ptr)_2)->base + _index_13174);
        if (IS_SEQUENCE(_7162)){
                _7163 = SEQ_PTR(_7162)->length;
        }
        else {
            _7163 = 1;
        }
        _7162 = NOVALUE;
        {
            s1_ptr assign_space = SEQ_PTR(_7161);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_pos_13108)) ? _pos_13108 : (long)(DBL_PTR(_pos_13108)->dbl);
            int stop = (IS_ATOM_INT(_7163)) ? _7163 : (long)(DBL_PTR(_7163)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
                RefDS(_7161);
                DeRef(_7164);
                _7164 = _7161;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_7161), start, &_7164 );
                }
                else Tail(SEQ_PTR(_7161), stop+1, &_7164);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_7161), start, &_7164);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_7164);
                _7164 = _1;
            }
        }
        _7161 = NOVALUE;
        _7163 = NOVALUE;
        _2 = (int)SEQ_PTR(_new_key_buckets__13104);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _new_key_buckets__13104 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index_13174);
        _1 = *(int *)_2;
        *(int *)_2 = _7164;
        if( _1 != _7164 ){
            DeRefDS(_1);
        }
        _7164 = NOVALUE;

        /** 		new_val_buckets_[index] = remove(new_val_buckets_[index], pos, */
        _2 = (int)SEQ_PTR(_new_val_buckets__13105);
        _7165 = (int)*(((s1_ptr)_2)->base + _index_13174);
        _2 = (int)SEQ_PTR(_new_val_buckets__13105);
        _7166 = (int)*(((s1_ptr)_2)->base + _index_13174);
        if (IS_SEQUENCE(_7166)){
                _7167 = SEQ_PTR(_7166)->length;
        }
        else {
            _7167 = 1;
        }
        _7166 = NOVALUE;
        {
            s1_ptr assign_space = SEQ_PTR(_7165);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_pos_13108)) ? _pos_13108 : (long)(DBL_PTR(_pos_13108)->dbl);
            int stop = (IS_ATOM_INT(_7167)) ? _7167 : (long)(DBL_PTR(_7167)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
                RefDS(_7165);
                DeRef(_7168);
                _7168 = _7165;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_7165), start, &_7168 );
                }
                else Tail(SEQ_PTR(_7165), stop+1, &_7168);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_7165), start, &_7168);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_7168);
                _7168 = _1;
            }
        }
        _7165 = NOVALUE;
        _7167 = NOVALUE;
        _2 = (int)SEQ_PTR(_new_val_buckets__13105);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _new_val_buckets__13105 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index_13174);
        _1 = *(int *)_2;
        *(int *)_2 = _7168;
        if( _1 != _7168 ){
            DeRef(_1);
        }
        _7168 = NOVALUE;

        /** 	end for*/
        _index_13174 = _index_13174 + 1;
        goto LB; // [446] 385
LC: 
        ;
    }

    /** 	eumem:ram_space[the_map_p] = { */
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_32type_is_map_12979);
    *((int *)(_2+4)) = _32type_is_map_12979;
    *((int *)(_2+8)) = _elem_count_13111;
    *((int *)(_2+12)) = _in_use_13110;
    *((int *)(_2+16)) = 76;
    RefDS(_new_key_buckets__13104);
    *((int *)(_2+20)) = _new_key_buckets__13104;
    RefDS(_new_val_buckets__13105);
    *((int *)(_2+24)) = _new_val_buckets__13105;
    _7169 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_12249 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13098);
    _1 = *(int *)_2;
    *(int *)_2 = _7169;
    if( _1 != _7169 ){
        DeRef(_1);
    }
    _7169 = NOVALUE;

    /** end procedure*/
    DeRef(_old_key_buckets__13102);
    DeRef(_old_val_buckets__13103);
    DeRefDS(_new_key_buckets__13104);
    DeRefDS(_new_val_buckets__13105);
    DeRef(_key__13106);
    DeRef(_value__13107);
    DeRef(_new_keys_13109);
    _7115 = NOVALUE;
    _7135 = NOVALUE;
    _7162 = NOVALUE;
    _7166 = NOVALUE;
    return;
    ;
}


int _32new(int _initial_size_p_13190)
{
    int _buckets__13192 = NOVALUE;
    int _new_map__13193 = NOVALUE;
    int _temp_map__13194 = NOVALUE;
    int _7182 = NOVALUE;
    int _7181 = NOVALUE;
    int _7180 = NOVALUE;
    int _7178 = NOVALUE;
    int _7177 = NOVALUE;
    int _7174 = NOVALUE;
    int _7173 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if initial_size_p < 3 then*/
    if (_initial_size_p_13190 >= 3)
    goto L1; // [5] 15

    /** 		initial_size_p = 3*/
    _initial_size_p_13190 = 3;
L1: 

    /** 	if initial_size_p > threshold_size then*/
    if (_initial_size_p_13190 <= 23)
    goto L2; // [19] 75

    /** 		buckets_ = floor((initial_size_p + threshold_size - 1) / threshold_size)*/
    _7173 = _initial_size_p_13190 + 23;
    if ((long)((unsigned long)_7173 + (unsigned long)HIGH_BITS) >= 0) 
    _7173 = NewDouble((double)_7173);
    if (IS_ATOM_INT(_7173)) {
        _7174 = _7173 - 1;
        if ((long)((unsigned long)_7174 +(unsigned long) HIGH_BITS) >= 0){
            _7174 = NewDouble((double)_7174);
        }
    }
    else {
        _7174 = NewDouble(DBL_PTR(_7173)->dbl - (double)1);
    }
    DeRef(_7173);
    _7173 = NOVALUE;
    if (IS_ATOM_INT(_7174)) {
        if (23 > 0 && _7174 >= 0) {
            _buckets__13192 = _7174 / 23;
        }
        else {
            temp_dbl = floor((double)_7174 / (double)23);
            _buckets__13192 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _7174, 23);
        _buckets__13192 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_7174);
    _7174 = NOVALUE;
    if (!IS_ATOM_INT(_buckets__13192)) {
        _1 = (long)(DBL_PTR(_buckets__13192)->dbl);
        DeRefDS(_buckets__13192);
        _buckets__13192 = _1;
    }

    /** 		buckets_ = primes:next_prime(buckets_)*/
    _buckets__13192 = _34next_prime(_buckets__13192, -1, 1);
    if (!IS_ATOM_INT(_buckets__13192)) {
        _1 = (long)(DBL_PTR(_buckets__13192)->dbl);
        DeRefDS(_buckets__13192);
        _buckets__13192 = _1;
    }

    /** 		new_map_ = { type_is_map, 0, 0, LARGEMAP, repeat({}, buckets_), repeat({}, buckets_) }*/
    _7177 = Repeat(_5, _buckets__13192);
    _7178 = Repeat(_5, _buckets__13192);
    _0 = _new_map__13193;
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_32type_is_map_12979);
    *((int *)(_2+4)) = _32type_is_map_12979;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 76;
    *((int *)(_2+20)) = _7177;
    *((int *)(_2+24)) = _7178;
    _new_map__13193 = MAKE_SEQ(_1);
    DeRef(_0);
    _7178 = NOVALUE;
    _7177 = NOVALUE;
    goto L3; // [72] 100
L2: 

    /** 		new_map_ = {*/
    _7180 = Repeat(_32init_small_map_key_12994, _initial_size_p_13190);
    _7181 = Repeat(0, _initial_size_p_13190);
    _7182 = Repeat(0, _initial_size_p_13190);
    _0 = _new_map__13193;
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_32type_is_map_12979);
    *((int *)(_2+4)) = _32type_is_map_12979;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 115;
    *((int *)(_2+20)) = _7180;
    *((int *)(_2+24)) = _7181;
    *((int *)(_2+28)) = _7182;
    _new_map__13193 = MAKE_SEQ(_1);
    DeRef(_0);
    _7182 = NOVALUE;
    _7181 = NOVALUE;
    _7180 = NOVALUE;
L3: 

    /** 	temp_map_ = eumem:malloc()*/
    _0 = _temp_map__13194;
    _temp_map__13194 = _33malloc(1, 1);
    DeRef(_0);

    /** 	eumem:ram_space[temp_map_] = new_map_*/
    RefDS(_new_map__13193);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_12249 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_temp_map__13194))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_temp_map__13194)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _temp_map__13194);
    _1 = *(int *)_2;
    *(int *)_2 = _new_map__13193;
    DeRef(_1);

    /** 	return temp_map_*/
    DeRefDS(_new_map__13193);
    return _temp_map__13194;
    ;
}


int _32new_extra(int _the_map_p_13214, int _initial_size_p_13215)
{
    int _7186 = NOVALUE;
    int _7185 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if map(the_map_p) then*/
    Ref(_the_map_p_13214);
    _7185 = _32map(_the_map_p_13214);
    if (_7185 == 0) {
        DeRef(_7185);
        _7185 = NOVALUE;
        goto L1; // [9] 21
    }
    else {
        if (!IS_ATOM_INT(_7185) && DBL_PTR(_7185)->dbl == 0.0){
            DeRef(_7185);
            _7185 = NOVALUE;
            goto L1; // [9] 21
        }
        DeRef(_7185);
        _7185 = NOVALUE;
    }
    DeRef(_7185);
    _7185 = NOVALUE;

    /** 		return the_map_p*/
    return _the_map_p_13214;
    goto L2; // [18] 32
L1: 

    /** 		return new(initial_size_p)*/
    _7186 = _32new(_initial_size_p_13215);
    DeRef(_the_map_p_13214);
    return _7186;
L2: 
    ;
}


int _32has(int _the_map_p_13252, int _the_key_p_13253)
{
    int _index__13254 = NOVALUE;
    int _pos__13255 = NOVALUE;
    int _from__13256 = NOVALUE;
    int _calc_hash_1__tmp_at36_13268 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_36_13267 = NOVALUE;
    int _ret__inlined_calc_hash_at_36_13266 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_33_13265 = NOVALUE;
    int _7222 = NOVALUE;
    int _7220 = NOVALUE;
    int _7219 = NOVALUE;
    int _7216 = NOVALUE;
    int _7215 = NOVALUE;
    int _7214 = NOVALUE;
    int _7212 = NOVALUE;
    int _7211 = NOVALUE;
    int _7209 = NOVALUE;
    int _7207 = NOVALUE;
    int _7206 = NOVALUE;
    int _7205 = NOVALUE;
    int _7204 = NOVALUE;
    int _7203 = NOVALUE;
    int _7202 = NOVALUE;
    int _7200 = NOVALUE;
    int _7199 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_the_map_p_13252)) {
        _1 = (long)(DBL_PTR(_the_map_p_13252)->dbl);
        DeRefDS(_the_map_p_13252);
        _the_map_p_13252 = _1;
    }

    /** 	if eumem:ram_space[the_map_p][MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    _7199 = (int)*(((s1_ptr)_2)->base + _the_map_p_13252);
    _2 = (int)SEQ_PTR(_7199);
    _7200 = (int)*(((s1_ptr)_2)->base + 4);
    _7199 = NOVALUE;
    if (binary_op_a(NOTEQ, _7200, 76)){
        _7200 = NOVALUE;
        goto L1; // [15] 86
    }
    _7200 = NOVALUE;

    /** 		index_ = calc_hash(the_key_p, length(eumem:ram_space[the_map_p][KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    _7202 = (int)*(((s1_ptr)_2)->base + _the_map_p_13252);
    _2 = (int)SEQ_PTR(_7202);
    _7203 = (int)*(((s1_ptr)_2)->base + 5);
    _7202 = NOVALUE;
    if (IS_SEQUENCE(_7203)){
            _7204 = SEQ_PTR(_7203)->length;
    }
    else {
        _7204 = 1;
    }
    _7203 = NOVALUE;
    _max_hash_p_inlined_calc_hash_at_33_13265 = _7204;
    _7204 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_36_13266);
    _ret__inlined_calc_hash_at_36_13266 = calc_hash(_the_key_p_13253, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_36_13266)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_36_13266)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_36_13266);
        _ret__inlined_calc_hash_at_36_13266 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at36_13268 = (_ret__inlined_calc_hash_at_36_13266 % _max_hash_p_inlined_calc_hash_at_33_13265);
    _index__13254 = _calc_hash_1__tmp_at36_13268 + 1;
    DeRef(_ret__inlined_calc_hash_at_36_13266);
    _ret__inlined_calc_hash_at_36_13266 = NOVALUE;
    if (!IS_ATOM_INT(_index__13254)) {
        _1 = (long)(DBL_PTR(_index__13254)->dbl);
        DeRefDS(_index__13254);
        _index__13254 = _1;
    }

    /** 		pos_ = find(the_key_p, eumem:ram_space[the_map_p][KEY_BUCKETS][index_])*/
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    _7205 = (int)*(((s1_ptr)_2)->base + _the_map_p_13252);
    _2 = (int)SEQ_PTR(_7205);
    _7206 = (int)*(((s1_ptr)_2)->base + 5);
    _7205 = NOVALUE;
    _2 = (int)SEQ_PTR(_7206);
    _7207 = (int)*(((s1_ptr)_2)->base + _index__13254);
    _7206 = NOVALUE;
    _pos__13255 = find_from(_the_key_p_13253, _7207, 1);
    _7207 = NOVALUE;
    goto L2; // [83] 201
L1: 

    /** 		if equal(the_key_p, init_small_map_key) then*/
    if (_the_key_p_13253 == _32init_small_map_key_12994)
    _7209 = 1;
    else if (IS_ATOM_INT(_the_key_p_13253) && IS_ATOM_INT(_32init_small_map_key_12994))
    _7209 = 0;
    else
    _7209 = (compare(_the_key_p_13253, _32init_small_map_key_12994) == 0);
    if (_7209 == 0)
    {
        _7209 = NOVALUE;
        goto L3; // [92] 182
    }
    else{
        _7209 = NOVALUE;
    }

    /** 			from_ = 1*/
    _from__13256 = 1;

    /** 			while from_ > 0 do*/
L4: 
    if (_from__13256 <= 0)
    goto L5; // [105] 200

    /** 				pos_ = find(the_key_p, eumem:ram_space[the_map_p][KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    _7211 = (int)*(((s1_ptr)_2)->base + _the_map_p_13252);
    _2 = (int)SEQ_PTR(_7211);
    _7212 = (int)*(((s1_ptr)_2)->base + 5);
    _7211 = NOVALUE;
    _pos__13255 = find_from(_the_key_p_13253, _7212, _from__13256);
    _7212 = NOVALUE;

    /** 				if pos_ then*/
    if (_pos__13255 == 0)
    {
        goto L6; // [128] 161
    }
    else{
    }

    /** 					if eumem:ram_space[the_map_p][FREE_LIST][pos_] = 1 then*/
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    _7214 = (int)*(((s1_ptr)_2)->base + _the_map_p_13252);
    _2 = (int)SEQ_PTR(_7214);
    _7215 = (int)*(((s1_ptr)_2)->base + 7);
    _7214 = NOVALUE;
    _2 = (int)SEQ_PTR(_7215);
    _7216 = (int)*(((s1_ptr)_2)->base + _pos__13255);
    _7215 = NOVALUE;
    if (binary_op_a(NOTEQ, _7216, 1)){
        _7216 = NOVALUE;
        goto L7; // [147] 168
    }
    _7216 = NOVALUE;

    /** 						return 1*/
    DeRef(_the_key_p_13253);
    _7203 = NOVALUE;
    return 1;
    goto L7; // [158] 168
L6: 

    /** 					return 0*/
    DeRef(_the_key_p_13253);
    _7203 = NOVALUE;
    return 0;
L7: 

    /** 				from_ = pos_ + 1*/
    _from__13256 = _pos__13255 + 1;

    /** 			end while*/
    goto L4; // [176] 105
    goto L5; // [179] 200
L3: 

    /** 			pos_ = find(the_key_p, eumem:ram_space[the_map_p][KEY_LIST])*/
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    _7219 = (int)*(((s1_ptr)_2)->base + _the_map_p_13252);
    _2 = (int)SEQ_PTR(_7219);
    _7220 = (int)*(((s1_ptr)_2)->base + 5);
    _7219 = NOVALUE;
    _pos__13255 = find_from(_the_key_p_13253, _7220, 1);
    _7220 = NOVALUE;
L5: 
L2: 

    /** 	return (pos_  != 0)	*/
    _7222 = (_pos__13255 != 0);
    DeRef(_the_key_p_13253);
    _7203 = NOVALUE;
    return _7222;
    ;
}


int _32get(int _the_map_p_13296, int _the_key_p_13297, int _default_value_p_13298)
{
    int _bucket__13299 = NOVALUE;
    int _pos__13300 = NOVALUE;
    int _from__13301 = NOVALUE;
    int _themap_13302 = NOVALUE;
    int _thekeys_13307 = NOVALUE;
    int _calc_hash_1__tmp_at40_13314 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_40_13313 = NOVALUE;
    int _ret__inlined_calc_hash_at_40_13312 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_37_13311 = NOVALUE;
    int _7247 = NOVALUE;
    int _7246 = NOVALUE;
    int _7244 = NOVALUE;
    int _7242 = NOVALUE;
    int _7241 = NOVALUE;
    int _7239 = NOVALUE;
    int _7238 = NOVALUE;
    int _7236 = NOVALUE;
    int _7234 = NOVALUE;
    int _7233 = NOVALUE;
    int _7232 = NOVALUE;
    int _7231 = NOVALUE;
    int _7228 = NOVALUE;
    int _7227 = NOVALUE;
    int _7224 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_the_map_p_13296)) {
        _1 = (long)(DBL_PTR(_the_map_p_13296)->dbl);
        DeRefDS(_the_map_p_13296);
        _the_map_p_13296 = _1;
    }

    /** 	themap = eumem:ram_space[the_map_p]*/
    DeRef(_themap_13302);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    _themap_13302 = (int)*(((s1_ptr)_2)->base + _the_map_p_13296);
    Ref(_themap_13302);

    /** 	if themap[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_themap_13302);
    _7224 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7224, 76)){
        _7224 = NOVALUE;
        goto L1; // [19] 113
    }
    _7224 = NOVALUE;

    /** 		sequence thekeys*/

    /** 		thekeys = themap[KEY_BUCKETS]*/
    DeRef(_thekeys_13307);
    _2 = (int)SEQ_PTR(_themap_13302);
    _thekeys_13307 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_thekeys_13307);

    /** 		bucket_ = calc_hash(the_key_p, length(thekeys))*/
    if (IS_SEQUENCE(_thekeys_13307)){
            _7227 = SEQ_PTR(_thekeys_13307)->length;
    }
    else {
        _7227 = 1;
    }
    _max_hash_p_inlined_calc_hash_at_37_13311 = _7227;
    _7227 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_40_13312);
    _ret__inlined_calc_hash_at_40_13312 = calc_hash(_the_key_p_13297, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_40_13312)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_40_13312)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_40_13312);
        _ret__inlined_calc_hash_at_40_13312 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at40_13314 = (_ret__inlined_calc_hash_at_40_13312 % _max_hash_p_inlined_calc_hash_at_37_13311);
    _bucket__13299 = _calc_hash_1__tmp_at40_13314 + 1;
    DeRef(_ret__inlined_calc_hash_at_40_13312);
    _ret__inlined_calc_hash_at_40_13312 = NOVALUE;
    if (!IS_ATOM_INT(_bucket__13299)) {
        _1 = (long)(DBL_PTR(_bucket__13299)->dbl);
        DeRefDS(_bucket__13299);
        _bucket__13299 = _1;
    }

    /** 		pos_ = find(the_key_p, thekeys[bucket_])*/
    _2 = (int)SEQ_PTR(_thekeys_13307);
    _7228 = (int)*(((s1_ptr)_2)->base + _bucket__13299);
    _pos__13300 = find_from(_the_key_p_13297, _7228, 1);
    _7228 = NOVALUE;

    /** 		if pos_ > 0 then*/
    if (_pos__13300 <= 0)
    goto L2; // [79] 102

    /** 			return themap[VALUE_BUCKETS][bucket_][pos_]*/
    _2 = (int)SEQ_PTR(_themap_13302);
    _7231 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7231);
    _7232 = (int)*(((s1_ptr)_2)->base + _bucket__13299);
    _7231 = NOVALUE;
    _2 = (int)SEQ_PTR(_7232);
    _7233 = (int)*(((s1_ptr)_2)->base + _pos__13300);
    _7232 = NOVALUE;
    Ref(_7233);
    DeRefDS(_thekeys_13307);
    DeRef(_the_key_p_13297);
    DeRef(_default_value_p_13298);
    DeRefDS(_themap_13302);
    return _7233;
L2: 

    /** 		return default_value_p*/
    DeRef(_thekeys_13307);
    DeRef(_the_key_p_13297);
    DeRef(_themap_13302);
    _7233 = NOVALUE;
    return _default_value_p_13298;
    goto L3; // [110] 238
L1: 

    /** 		if equal(the_key_p, init_small_map_key) then*/
    if (_the_key_p_13297 == _32init_small_map_key_12994)
    _7234 = 1;
    else if (IS_ATOM_INT(_the_key_p_13297) && IS_ATOM_INT(_32init_small_map_key_12994))
    _7234 = 0;
    else
    _7234 = (compare(_the_key_p_13297, _32init_small_map_key_12994) == 0);
    if (_7234 == 0)
    {
        _7234 = NOVALUE;
        goto L4; // [119] 205
    }
    else{
        _7234 = NOVALUE;
    }

    /** 			from_ = 1*/
    _from__13301 = 1;

    /** 			while from_ > 0 do*/
L5: 
    if (_from__13301 <= 0)
    goto L6; // [132] 237

    /** 				pos_ = find(the_key_p, themap[KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_themap_13302);
    _7236 = (int)*(((s1_ptr)_2)->base + 5);
    _pos__13300 = find_from(_the_key_p_13297, _7236, _from__13301);
    _7236 = NOVALUE;

    /** 				if pos_ then*/
    if (_pos__13300 == 0)
    {
        goto L7; // [149] 184
    }
    else{
    }

    /** 					if themap[FREE_LIST][pos_] = 1 then*/
    _2 = (int)SEQ_PTR(_themap_13302);
    _7238 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_7238);
    _7239 = (int)*(((s1_ptr)_2)->base + _pos__13300);
    _7238 = NOVALUE;
    if (binary_op_a(NOTEQ, _7239, 1)){
        _7239 = NOVALUE;
        goto L8; // [162] 191
    }
    _7239 = NOVALUE;

    /** 						return themap[VALUE_LIST][pos_]*/
    _2 = (int)SEQ_PTR(_themap_13302);
    _7241 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7241);
    _7242 = (int)*(((s1_ptr)_2)->base + _pos__13300);
    _7241 = NOVALUE;
    Ref(_7242);
    DeRef(_the_key_p_13297);
    DeRef(_default_value_p_13298);
    DeRefDS(_themap_13302);
    _7233 = NOVALUE;
    return _7242;
    goto L8; // [181] 191
L7: 

    /** 					return default_value_p*/
    DeRef(_the_key_p_13297);
    DeRef(_themap_13302);
    _7233 = NOVALUE;
    _7242 = NOVALUE;
    return _default_value_p_13298;
L8: 

    /** 				from_ = pos_ + 1*/
    _from__13301 = _pos__13300 + 1;

    /** 			end while*/
    goto L5; // [199] 132
    goto L6; // [202] 237
L4: 

    /** 			pos_ = find(the_key_p, themap[KEY_LIST])*/
    _2 = (int)SEQ_PTR(_themap_13302);
    _7244 = (int)*(((s1_ptr)_2)->base + 5);
    _pos__13300 = find_from(_the_key_p_13297, _7244, 1);
    _7244 = NOVALUE;

    /** 			if pos_  then*/
    if (_pos__13300 == 0)
    {
        goto L9; // [218] 236
    }
    else{
    }

    /** 				return themap[VALUE_LIST][pos_]*/
    _2 = (int)SEQ_PTR(_themap_13302);
    _7246 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7246);
    _7247 = (int)*(((s1_ptr)_2)->base + _pos__13300);
    _7246 = NOVALUE;
    Ref(_7247);
    DeRef(_the_key_p_13297);
    DeRef(_default_value_p_13298);
    DeRefDS(_themap_13302);
    _7233 = NOVALUE;
    _7242 = NOVALUE;
    return _7247;
L9: 
L6: 
L3: 

    /** 	return default_value_p*/
    DeRef(_the_key_p_13297);
    DeRef(_themap_13302);
    _7233 = NOVALUE;
    _7242 = NOVALUE;
    _7247 = NOVALUE;
    return _default_value_p_13298;
    ;
}


void _32put(int _the_map_p_13366, int _the_key_p_13367, int _the_value_p_13368, int _operation_p_13369, int _trigger_p_13370)
{
    int _index__13371 = NOVALUE;
    int _bucket__13372 = NOVALUE;
    int _average_length__13373 = NOVALUE;
    int _from__13374 = NOVALUE;
    int _map_data_13375 = NOVALUE;
    int _calc_hash_1__tmp_at46_13386 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_46_13385 = NOVALUE;
    int _ret__inlined_calc_hash_at_46_13384 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_43_13383 = NOVALUE;
    int _data_13418 = NOVALUE;
    int _msg_inlined_crash_at_334_13434 = NOVALUE;
    int _msg_inlined_crash_at_379_13440 = NOVALUE;
    int _tmp_seqk_13454 = NOVALUE;
    int _tmp_seqv_13462 = NOVALUE;
    int _msg_inlined_crash_at_721_13498 = NOVALUE;
    int _msg_inlined_crash_at_1079_13561 = NOVALUE;
    int _7391 = NOVALUE;
    int _7390 = NOVALUE;
    int _7388 = NOVALUE;
    int _7387 = NOVALUE;
    int _7386 = NOVALUE;
    int _7385 = NOVALUE;
    int _7383 = NOVALUE;
    int _7382 = NOVALUE;
    int _7381 = NOVALUE;
    int _7379 = NOVALUE;
    int _7378 = NOVALUE;
    int _7377 = NOVALUE;
    int _7375 = NOVALUE;
    int _7374 = NOVALUE;
    int _7373 = NOVALUE;
    int _7371 = NOVALUE;
    int _7370 = NOVALUE;
    int _7369 = NOVALUE;
    int _7367 = NOVALUE;
    int _7365 = NOVALUE;
    int _7359 = NOVALUE;
    int _7358 = NOVALUE;
    int _7357 = NOVALUE;
    int _7356 = NOVALUE;
    int _7354 = NOVALUE;
    int _7352 = NOVALUE;
    int _7351 = NOVALUE;
    int _7350 = NOVALUE;
    int _7349 = NOVALUE;
    int _7348 = NOVALUE;
    int _7347 = NOVALUE;
    int _7344 = NOVALUE;
    int _7342 = NOVALUE;
    int _7339 = NOVALUE;
    int _7337 = NOVALUE;
    int _7334 = NOVALUE;
    int _7333 = NOVALUE;
    int _7331 = NOVALUE;
    int _7328 = NOVALUE;
    int _7327 = NOVALUE;
    int _7324 = NOVALUE;
    int _7321 = NOVALUE;
    int _7319 = NOVALUE;
    int _7317 = NOVALUE;
    int _7314 = NOVALUE;
    int _7312 = NOVALUE;
    int _7311 = NOVALUE;
    int _7310 = NOVALUE;
    int _7309 = NOVALUE;
    int _7308 = NOVALUE;
    int _7307 = NOVALUE;
    int _7306 = NOVALUE;
    int _7305 = NOVALUE;
    int _7304 = NOVALUE;
    int _7298 = NOVALUE;
    int _7296 = NOVALUE;
    int _7295 = NOVALUE;
    int _7293 = NOVALUE;
    int _7291 = NOVALUE;
    int _7288 = NOVALUE;
    int _7287 = NOVALUE;
    int _7286 = NOVALUE;
    int _7285 = NOVALUE;
    int _7283 = NOVALUE;
    int _7282 = NOVALUE;
    int _7281 = NOVALUE;
    int _7279 = NOVALUE;
    int _7278 = NOVALUE;
    int _7277 = NOVALUE;
    int _7275 = NOVALUE;
    int _7274 = NOVALUE;
    int _7273 = NOVALUE;
    int _7271 = NOVALUE;
    int _7269 = NOVALUE;
    int _7264 = NOVALUE;
    int _7263 = NOVALUE;
    int _7262 = NOVALUE;
    int _7261 = NOVALUE;
    int _7259 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_the_map_p_13366)) {
        _1 = (long)(DBL_PTR(_the_map_p_13366)->dbl);
        DeRefDS(_the_map_p_13366);
        _the_map_p_13366 = _1;
    }

    /** 	sequence map_data = eumem:ram_space[the_map_p]*/
    DeRef(_map_data_13375);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    _map_data_13375 = (int)*(((s1_ptr)_2)->base + _the_map_p_13366);
    Ref(_map_data_13375);

    /** 	eumem:ram_space[the_map_p] = 0*/
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_12249 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13366);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	if map_data[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    _7259 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7259, 76)){
        _7259 = NOVALUE;
        goto L1; // [31] 618
    }
    _7259 = NOVALUE;

    /** 		bucket_ = calc_hash(the_key_p,  length(map_data[KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    _7261 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7261)){
            _7262 = SEQ_PTR(_7261)->length;
    }
    else {
        _7262 = 1;
    }
    _7261 = NOVALUE;
    _max_hash_p_inlined_calc_hash_at_43_13383 = _7262;
    _7262 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_46_13384);
    _ret__inlined_calc_hash_at_46_13384 = calc_hash(_the_key_p_13367, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_46_13384)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_46_13384)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_46_13384);
        _ret__inlined_calc_hash_at_46_13384 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at46_13386 = (_ret__inlined_calc_hash_at_46_13384 % _max_hash_p_inlined_calc_hash_at_43_13383);
    _bucket__13372 = _calc_hash_1__tmp_at46_13386 + 1;
    DeRef(_ret__inlined_calc_hash_at_46_13384);
    _ret__inlined_calc_hash_at_46_13384 = NOVALUE;
    if (!IS_ATOM_INT(_bucket__13372)) {
        _1 = (long)(DBL_PTR(_bucket__13372)->dbl);
        DeRefDS(_bucket__13372);
        _bucket__13372 = _1;
    }

    /** 		index_ = find(the_key_p, map_data[KEY_BUCKETS][bucket_])*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    _7263 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7263);
    _7264 = (int)*(((s1_ptr)_2)->base + _bucket__13372);
    _7263 = NOVALUE;
    _index__13371 = find_from(_the_key_p_13367, _7264, 1);
    _7264 = NOVALUE;

    /** 		if index_ > 0 then*/
    if (_index__13371 <= 0)
    goto L2; // [89] 368

    /** 			switch operation_p do*/
    _0 = _operation_p_13369;
    switch ( _0 ){ 

        /** 				case PUT then*/
        case 1:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] = the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13375);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13375 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13372 + ((s1_ptr)_2)->base);
        _7269 = NOVALUE;
        Ref(_the_value_p_13368);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13371);
        _1 = *(int *)_2;
        *(int *)_2 = _the_value_p_13368;
        DeRef(_1);
        _7269 = NOVALUE;
        goto L3; // [120] 354

        /** 				case ADD then*/
        case 2:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] += the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13375);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13375 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13372 + ((s1_ptr)_2)->base);
        _7271 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7273 = (int)*(((s1_ptr)_2)->base + _index__13371);
        _7271 = NOVALUE;
        if (IS_ATOM_INT(_7273) && IS_ATOM_INT(_the_value_p_13368)) {
            _7274 = _7273 + _the_value_p_13368;
            if ((long)((unsigned long)_7274 + (unsigned long)HIGH_BITS) >= 0) 
            _7274 = NewDouble((double)_7274);
        }
        else {
            _7274 = binary_op(PLUS, _7273, _the_value_p_13368);
        }
        _7273 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13371);
        _1 = *(int *)_2;
        *(int *)_2 = _7274;
        if( _1 != _7274 ){
            DeRef(_1);
        }
        _7274 = NOVALUE;
        _7271 = NOVALUE;
        goto L3; // [150] 354

        /** 				case SUBTRACT then*/
        case 3:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] -= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13375);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13375 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13372 + ((s1_ptr)_2)->base);
        _7275 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7277 = (int)*(((s1_ptr)_2)->base + _index__13371);
        _7275 = NOVALUE;
        if (IS_ATOM_INT(_7277) && IS_ATOM_INT(_the_value_p_13368)) {
            _7278 = _7277 - _the_value_p_13368;
            if ((long)((unsigned long)_7278 +(unsigned long) HIGH_BITS) >= 0){
                _7278 = NewDouble((double)_7278);
            }
        }
        else {
            _7278 = binary_op(MINUS, _7277, _the_value_p_13368);
        }
        _7277 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13371);
        _1 = *(int *)_2;
        *(int *)_2 = _7278;
        if( _1 != _7278 ){
            DeRef(_1);
        }
        _7278 = NOVALUE;
        _7275 = NOVALUE;
        goto L3; // [180] 354

        /** 				case MULTIPLY then*/
        case 4:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] *= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13375);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13375 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13372 + ((s1_ptr)_2)->base);
        _7279 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7281 = (int)*(((s1_ptr)_2)->base + _index__13371);
        _7279 = NOVALUE;
        if (IS_ATOM_INT(_7281) && IS_ATOM_INT(_the_value_p_13368)) {
            if (_7281 == (short)_7281 && _the_value_p_13368 <= INT15 && _the_value_p_13368 >= -INT15)
            _7282 = _7281 * _the_value_p_13368;
            else
            _7282 = NewDouble(_7281 * (double)_the_value_p_13368);
        }
        else {
            _7282 = binary_op(MULTIPLY, _7281, _the_value_p_13368);
        }
        _7281 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13371);
        _1 = *(int *)_2;
        *(int *)_2 = _7282;
        if( _1 != _7282 ){
            DeRef(_1);
        }
        _7282 = NOVALUE;
        _7279 = NOVALUE;
        goto L3; // [210] 354

        /** 				case DIVIDE then*/
        case 5:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] /= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13375);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13375 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13372 + ((s1_ptr)_2)->base);
        _7283 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7285 = (int)*(((s1_ptr)_2)->base + _index__13371);
        _7283 = NOVALUE;
        if (IS_ATOM_INT(_7285) && IS_ATOM_INT(_the_value_p_13368)) {
            _7286 = (_7285 % _the_value_p_13368) ? NewDouble((double)_7285 / _the_value_p_13368) : (_7285 / _the_value_p_13368);
        }
        else {
            _7286 = binary_op(DIVIDE, _7285, _the_value_p_13368);
        }
        _7285 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13371);
        _1 = *(int *)_2;
        *(int *)_2 = _7286;
        if( _1 != _7286 ){
            DeRef(_1);
        }
        _7286 = NOVALUE;
        _7283 = NOVALUE;
        goto L3; // [240] 354

        /** 				case APPEND then*/
        case 6:

        /** 					sequence data = map_data[VALUE_BUCKETS][bucket_][index_]*/
        _2 = (int)SEQ_PTR(_map_data_13375);
        _7287 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7287);
        _7288 = (int)*(((s1_ptr)_2)->base + _bucket__13372);
        _7287 = NOVALUE;
        DeRef(_data_13418);
        _2 = (int)SEQ_PTR(_7288);
        _data_13418 = (int)*(((s1_ptr)_2)->base + _index__13371);
        Ref(_data_13418);
        _7288 = NOVALUE;

        /** 					data = append( data, the_value_p )*/
        Ref(_the_value_p_13368);
        Append(&_data_13418, _data_13418, _the_value_p_13368);

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] = data*/
        _2 = (int)SEQ_PTR(_map_data_13375);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13375 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13372 + ((s1_ptr)_2)->base);
        _7291 = NOVALUE;
        RefDS(_data_13418);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13371);
        _1 = *(int *)_2;
        *(int *)_2 = _data_13418;
        DeRef(_1);
        _7291 = NOVALUE;
        DeRefDS(_data_13418);
        _data_13418 = NOVALUE;
        goto L3; // [286] 354

        /** 				case CONCAT then*/
        case 7:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] &= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13375);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13375 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13372 + ((s1_ptr)_2)->base);
        _7293 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7295 = (int)*(((s1_ptr)_2)->base + _index__13371);
        _7293 = NOVALUE;
        if (IS_SEQUENCE(_7295) && IS_ATOM(_the_value_p_13368)) {
            Ref(_the_value_p_13368);
            Append(&_7296, _7295, _the_value_p_13368);
        }
        else if (IS_ATOM(_7295) && IS_SEQUENCE(_the_value_p_13368)) {
            Ref(_7295);
            Prepend(&_7296, _the_value_p_13368, _7295);
        }
        else {
            Concat((object_ptr)&_7296, _7295, _the_value_p_13368);
            _7295 = NOVALUE;
        }
        _7295 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13371);
        _1 = *(int *)_2;
        *(int *)_2 = _7296;
        if( _1 != _7296 ){
            DeRef(_1);
        }
        _7296 = NOVALUE;
        _7293 = NOVALUE;
        goto L3; // [316] 354

        /** 				case LEAVE then*/
        case 8:

        /** 					operation_p = operation_p*/
        _operation_p_13369 = _operation_p_13369;
        goto L3; // [327] 354

        /** 				case else*/
        default:

        /** 					error:crash("Unknown operation given to map.e:put()")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_334_13434);
        _msg_inlined_crash_at_334_13434 = EPrintf(-9999999, _7297, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_334_13434);

        /** end procedure*/
        goto L4; // [348] 351
L4: 
        DeRefi(_msg_inlined_crash_at_334_13434);
        _msg_inlined_crash_at_334_13434 = NOVALUE;
    ;}L3: 

    /** 			eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13375);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_12249 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13366);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13375;
    DeRef(_1);

    /** 			return*/
    DeRef(_tmp_seqk_13454);
    DeRef(_tmp_seqv_13462);
    DeRef(_the_key_p_13367);
    DeRef(_the_value_p_13368);
    DeRef(_average_length__13373);
    DeRefDS(_map_data_13375);
    _7261 = NOVALUE;
    return;
L2: 

    /** 		if not eu:find(operation_p, INIT_OPERATIONS) then*/
    _7298 = find_from(_operation_p_13369, _32INIT_OPERATIONS_12989, 1);
    if (_7298 != 0)
    goto L5; // [375] 399
    _7298 = NOVALUE;

    /** 				error:crash("Inappropriate initial operation given to map.e:put()")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_379_13440);
    _msg_inlined_crash_at_379_13440 = EPrintf(-9999999, _7300, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_379_13440);

    /** end procedure*/
    goto L6; // [393] 396
L6: 
    DeRefi(_msg_inlined_crash_at_379_13440);
    _msg_inlined_crash_at_379_13440 = NOVALUE;
L5: 

    /** 		if operation_p = LEAVE then*/
    if (_operation_p_13369 != 8)
    goto L7; // [401] 419

    /** 			eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13375);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_12249 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13366);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13375;
    DeRef(_1);

    /** 			return*/
    DeRef(_tmp_seqk_13454);
    DeRef(_tmp_seqv_13462);
    DeRef(_the_key_p_13367);
    DeRef(_the_value_p_13368);
    DeRef(_average_length__13373);
    DeRefDS(_map_data_13375);
    _7261 = NOVALUE;
    return;
L7: 

    /** 		if operation_p = APPEND then*/
    if (_operation_p_13369 != 6)
    goto L8; // [421] 432

    /** 			the_value_p = { the_value_p }*/
    _0 = _the_value_p_13368;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_the_value_p_13368);
    *((int *)(_2+4)) = _the_value_p_13368;
    _the_value_p_13368 = MAKE_SEQ(_1);
    DeRef(_0);
L8: 

    /** 		map_data[IN_USE] += (length(map_data[KEY_BUCKETS][bucket_]) = 0)*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    _7304 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7304);
    _7305 = (int)*(((s1_ptr)_2)->base + _bucket__13372);
    _7304 = NOVALUE;
    if (IS_SEQUENCE(_7305)){
            _7306 = SEQ_PTR(_7305)->length;
    }
    else {
        _7306 = 1;
    }
    _7305 = NOVALUE;
    _7307 = (_7306 == 0);
    _7306 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13375);
    _7308 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7308)) {
        _7309 = _7308 + _7307;
        if ((long)((unsigned long)_7309 + (unsigned long)HIGH_BITS) >= 0) 
        _7309 = NewDouble((double)_7309);
    }
    else {
        _7309 = binary_op(PLUS, _7308, _7307);
    }
    _7308 = NOVALUE;
    _7307 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13375);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13375 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _7309;
    if( _1 != _7309 ){
        DeRef(_1);
    }
    _7309 = NOVALUE;

    /** 		map_data[ELEMENT_COUNT] += 1 -- elementCount		*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    _7310 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7310)) {
        _7311 = _7310 + 1;
        if (_7311 > MAXINT){
            _7311 = NewDouble((double)_7311);
        }
    }
    else
    _7311 = binary_op(PLUS, 1, _7310);
    _7310 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13375);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13375 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _7311;
    if( _1 != _7311 ){
        DeRef(_1);
    }
    _7311 = NOVALUE;

    /** 		sequence tmp_seqk*/

    /** 		tmp_seqk = map_data[KEY_BUCKETS][bucket_]*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    _7312 = (int)*(((s1_ptr)_2)->base + 5);
    DeRef(_tmp_seqk_13454);
    _2 = (int)SEQ_PTR(_7312);
    _tmp_seqk_13454 = (int)*(((s1_ptr)_2)->base + _bucket__13372);
    Ref(_tmp_seqk_13454);
    _7312 = NOVALUE;

    /** 		map_data[KEY_BUCKETS][bucket_] = 0*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13375 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13372);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _7314 = NOVALUE;

    /** 		tmp_seqk = append( tmp_seqk, the_key_p)*/
    Ref(_the_key_p_13367);
    Append(&_tmp_seqk_13454, _tmp_seqk_13454, _the_key_p_13367);

    /** 		map_data[KEY_BUCKETS][bucket_] = tmp_seqk*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13375 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    RefDS(_tmp_seqk_13454);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13372);
    _1 = *(int *)_2;
    *(int *)_2 = _tmp_seqk_13454;
    DeRef(_1);
    _7317 = NOVALUE;

    /** 		sequence tmp_seqv*/

    /** 		tmp_seqv = map_data[VALUE_BUCKETS][bucket_]*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    _7319 = (int)*(((s1_ptr)_2)->base + 6);
    DeRef(_tmp_seqv_13462);
    _2 = (int)SEQ_PTR(_7319);
    _tmp_seqv_13462 = (int)*(((s1_ptr)_2)->base + _bucket__13372);
    Ref(_tmp_seqv_13462);
    _7319 = NOVALUE;

    /** 		map_data[VALUE_BUCKETS][bucket_] = 0*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13375 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13372);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _7321 = NOVALUE;

    /** 		tmp_seqv = append( tmp_seqv, the_value_p)*/
    Ref(_the_value_p_13368);
    Append(&_tmp_seqv_13462, _tmp_seqv_13462, _the_value_p_13368);

    /** 		map_data[VALUE_BUCKETS][bucket_] = tmp_seqv*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13375 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    RefDS(_tmp_seqv_13462);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13372);
    _1 = *(int *)_2;
    *(int *)_2 = _tmp_seqv_13462;
    DeRef(_1);
    _7324 = NOVALUE;

    /** 		eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13375);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_12249 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13366);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13375;
    DeRef(_1);

    /** 		if trigger_p > 0 then*/
    if (_trigger_p_13370 <= 0)
    goto L9; // [569] 608

    /** 			average_length_ = map_data[ELEMENT_COUNT] / map_data[IN_USE]*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    _7327 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_map_data_13375);
    _7328 = (int)*(((s1_ptr)_2)->base + 3);
    DeRef(_average_length__13373);
    if (IS_ATOM_INT(_7327) && IS_ATOM_INT(_7328)) {
        _average_length__13373 = (_7327 % _7328) ? NewDouble((double)_7327 / _7328) : (_7327 / _7328);
    }
    else {
        _average_length__13373 = binary_op(DIVIDE, _7327, _7328);
    }
    _7327 = NOVALUE;
    _7328 = NOVALUE;

    /** 			if (average_length_ >= trigger_p) then*/
    if (binary_op_a(LESS, _average_length__13373, _trigger_p_13370)){
        goto LA; // [589] 607
    }

    /** 				map_data = {}*/
    RefDS(_5);
    DeRefDS(_map_data_13375);
    _map_data_13375 = _5;

    /** 				rehash(the_map_p)*/
    _32rehash(_the_map_p_13366, 0);
LA: 
L9: 

    /** 		return*/
    DeRef(_tmp_seqk_13454);
    DeRef(_tmp_seqv_13462);
    DeRef(_the_key_p_13367);
    DeRef(_the_value_p_13368);
    DeRef(_average_length__13373);
    DeRef(_map_data_13375);
    _7261 = NOVALUE;
    _7305 = NOVALUE;
    return;
    goto LB; // [615] 1112
L1: 

    /** 		if equal(the_key_p, init_small_map_key) then*/
    if (_the_key_p_13367 == _32init_small_map_key_12994)
    _7331 = 1;
    else if (IS_ATOM_INT(_the_key_p_13367) && IS_ATOM_INT(_32init_small_map_key_12994))
    _7331 = 0;
    else
    _7331 = (compare(_the_key_p_13367, _32init_small_map_key_12994) == 0);
    if (_7331 == 0)
    {
        _7331 = NOVALUE;
        goto LC; // [624] 690
    }
    else{
        _7331 = NOVALUE;
    }

    /** 			from_ = 1*/
    _from__13374 = 1;

    /** 			while index_ > 0 with entry do*/
    goto LD; // [634] 671
LE: 
    if (_index__13371 <= 0)
    goto LF; // [639] 702

    /** 				if map_data[FREE_LIST][index_] = 1 then*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    _7333 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_7333);
    _7334 = (int)*(((s1_ptr)_2)->base + _index__13371);
    _7333 = NOVALUE;
    if (binary_op_a(NOTEQ, _7334, 1)){
        _7334 = NOVALUE;
        goto L10; // [653] 662
    }
    _7334 = NOVALUE;

    /** 					exit*/
    goto LF; // [659] 702
L10: 

    /** 				from_ = index_ + 1*/
    _from__13374 = _index__13371 + 1;

    /** 			  entry*/
LD: 

    /** 				index_ = find(the_key_p, map_data[KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    _7337 = (int)*(((s1_ptr)_2)->base + 5);
    _index__13371 = find_from(_the_key_p_13367, _7337, _from__13374);
    _7337 = NOVALUE;

    /** 			end while*/
    goto LE; // [684] 637
    goto LF; // [687] 702
LC: 

    /** 			index_ = find(the_key_p, map_data[KEY_LIST])*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    _7339 = (int)*(((s1_ptr)_2)->base + 5);
    _index__13371 = find_from(_the_key_p_13367, _7339, 1);
    _7339 = NOVALUE;
LF: 

    /** 		if index_ = 0 then*/
    if (_index__13371 != 0)
    goto L11; // [706] 884

    /** 			if not eu:find(operation_p, INIT_OPERATIONS) then*/
    _7342 = find_from(_operation_p_13369, _32INIT_OPERATIONS_12989, 1);
    if (_7342 != 0)
    goto L12; // [717] 741
    _7342 = NOVALUE;

    /** 					error:crash("Inappropriate initial operation given to map.e:put()")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_721_13498);
    _msg_inlined_crash_at_721_13498 = EPrintf(-9999999, _7300, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_721_13498);

    /** end procedure*/
    goto L13; // [735] 738
L13: 
    DeRefi(_msg_inlined_crash_at_721_13498);
    _msg_inlined_crash_at_721_13498 = NOVALUE;
L12: 

    /** 			index_ = find(0, map_data[FREE_LIST])*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    _7344 = (int)*(((s1_ptr)_2)->base + 7);
    _index__13371 = find_from(0, _7344, 1);
    _7344 = NOVALUE;

    /** 			if index_ = 0 then*/
    if (_index__13371 != 0)
    goto L14; // [754] 808

    /** 				eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13375);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_12249 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13366);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13375;
    DeRef(_1);

    /** 				map_data = {}*/
    RefDS(_5);
    DeRefDS(_map_data_13375);
    _map_data_13375 = _5;

    /** 				convert_to_large_map(the_map_p)*/
    _32convert_to_large_map(_the_map_p_13366);

    /** 				put(the_map_p, the_key_p, the_value_p, operation_p, trigger_p)*/
    DeRef(_7347);
    _7347 = _the_map_p_13366;
    Ref(_the_key_p_13367);
    DeRef(_7348);
    _7348 = _the_key_p_13367;
    Ref(_the_value_p_13368);
    DeRef(_7349);
    _7349 = _the_value_p_13368;
    DeRef(_7350);
    _7350 = _operation_p_13369;
    DeRef(_7351);
    _7351 = _trigger_p_13370;
    _32put(_7347, _7348, _7349, _7350, _7351);
    _7347 = NOVALUE;
    _7348 = NOVALUE;
    _7349 = NOVALUE;
    _7350 = NOVALUE;
    _7351 = NOVALUE;

    /** 				return*/
    DeRef(_the_key_p_13367);
    DeRef(_the_value_p_13368);
    DeRef(_average_length__13373);
    DeRefDS(_map_data_13375);
    _7261 = NOVALUE;
    _7305 = NOVALUE;
    return;
L14: 

    /** 			map_data[KEY_LIST][index_] = the_key_p*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13375 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    Ref(_the_key_p_13367);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13371);
    _1 = *(int *)_2;
    *(int *)_2 = _the_key_p_13367;
    DeRef(_1);
    _7352 = NOVALUE;

    /** 			map_data[FREE_LIST][index_] = 1*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13375 = MAKE_SEQ(_2);
    }
    _3 = (int)(7 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13371);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _7354 = NOVALUE;

    /** 			map_data[IN_USE] += 1*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    _7356 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7356)) {
        _7357 = _7356 + 1;
        if (_7357 > MAXINT){
            _7357 = NewDouble((double)_7357);
        }
    }
    else
    _7357 = binary_op(PLUS, 1, _7356);
    _7356 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13375);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13375 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _7357;
    if( _1 != _7357 ){
        DeRef(_1);
    }
    _7357 = NOVALUE;

    /** 			map_data[ELEMENT_COUNT] += 1*/
    _2 = (int)SEQ_PTR(_map_data_13375);
    _7358 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7358)) {
        _7359 = _7358 + 1;
        if (_7359 > MAXINT){
            _7359 = NewDouble((double)_7359);
        }
    }
    else
    _7359 = binary_op(PLUS, 1, _7358);
    _7358 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13375);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13375 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _7359;
    if( _1 != _7359 ){
        DeRef(_1);
    }
    _7359 = NOVALUE;

    /** 			if operation_p = APPEND then*/
    if (_operation_p_13369 != 6)
    goto L15; // [860] 871

    /** 				the_value_p = { the_value_p }*/
    _0 = _the_value_p_13368;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_the_value_p_13368);
    *((int *)(_2+4)) = _the_value_p_13368;
    _the_value_p_13368 = MAKE_SEQ(_1);
    DeRef(_0);
L15: 

    /** 			if operation_p != LEAVE then*/
    if (_operation_p_13369 == 8)
    goto L16; // [873] 883

    /** 				operation_p = PUT	-- Initially, nearly everything is a PUT.*/
    _operation_p_13369 = 1;
L16: 
L11: 

    /** 		switch operation_p do*/
    _0 = _operation_p_13369;
    switch ( _0 ){ 

        /** 			case PUT then*/
        case 1:

        /** 				map_data[VALUE_LIST][index_] = the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13375);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13375 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        Ref(_the_value_p_13368);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13371);
        _1 = *(int *)_2;
        *(int *)_2 = _the_value_p_13368;
        DeRef(_1);
        _7365 = NOVALUE;
        goto L17; // [906] 1098

        /** 			case ADD then*/
        case 2:

        /** 				map_data[VALUE_LIST][index_] += the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13375);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13375 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7369 = (int)*(((s1_ptr)_2)->base + _index__13371);
        _7367 = NOVALUE;
        if (IS_ATOM_INT(_7369) && IS_ATOM_INT(_the_value_p_13368)) {
            _7370 = _7369 + _the_value_p_13368;
            if ((long)((unsigned long)_7370 + (unsigned long)HIGH_BITS) >= 0) 
            _7370 = NewDouble((double)_7370);
        }
        else {
            _7370 = binary_op(PLUS, _7369, _the_value_p_13368);
        }
        _7369 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13371);
        _1 = *(int *)_2;
        *(int *)_2 = _7370;
        if( _1 != _7370 ){
            DeRef(_1);
        }
        _7370 = NOVALUE;
        _7367 = NOVALUE;
        goto L17; // [931] 1098

        /** 			case SUBTRACT then*/
        case 3:

        /** 				map_data[VALUE_LIST][index_] -= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13375);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13375 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7373 = (int)*(((s1_ptr)_2)->base + _index__13371);
        _7371 = NOVALUE;
        if (IS_ATOM_INT(_7373) && IS_ATOM_INT(_the_value_p_13368)) {
            _7374 = _7373 - _the_value_p_13368;
            if ((long)((unsigned long)_7374 +(unsigned long) HIGH_BITS) >= 0){
                _7374 = NewDouble((double)_7374);
            }
        }
        else {
            _7374 = binary_op(MINUS, _7373, _the_value_p_13368);
        }
        _7373 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13371);
        _1 = *(int *)_2;
        *(int *)_2 = _7374;
        if( _1 != _7374 ){
            DeRef(_1);
        }
        _7374 = NOVALUE;
        _7371 = NOVALUE;
        goto L17; // [956] 1098

        /** 			case MULTIPLY then*/
        case 4:

        /** 				map_data[VALUE_LIST][index_] *= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13375);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13375 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7377 = (int)*(((s1_ptr)_2)->base + _index__13371);
        _7375 = NOVALUE;
        if (IS_ATOM_INT(_7377) && IS_ATOM_INT(_the_value_p_13368)) {
            if (_7377 == (short)_7377 && _the_value_p_13368 <= INT15 && _the_value_p_13368 >= -INT15)
            _7378 = _7377 * _the_value_p_13368;
            else
            _7378 = NewDouble(_7377 * (double)_the_value_p_13368);
        }
        else {
            _7378 = binary_op(MULTIPLY, _7377, _the_value_p_13368);
        }
        _7377 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13371);
        _1 = *(int *)_2;
        *(int *)_2 = _7378;
        if( _1 != _7378 ){
            DeRef(_1);
        }
        _7378 = NOVALUE;
        _7375 = NOVALUE;
        goto L17; // [981] 1098

        /** 			case DIVIDE then*/
        case 5:

        /** 				map_data[VALUE_LIST][index_] /= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13375);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13375 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7381 = (int)*(((s1_ptr)_2)->base + _index__13371);
        _7379 = NOVALUE;
        if (IS_ATOM_INT(_7381) && IS_ATOM_INT(_the_value_p_13368)) {
            _7382 = (_7381 % _the_value_p_13368) ? NewDouble((double)_7381 / _the_value_p_13368) : (_7381 / _the_value_p_13368);
        }
        else {
            _7382 = binary_op(DIVIDE, _7381, _the_value_p_13368);
        }
        _7381 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13371);
        _1 = *(int *)_2;
        *(int *)_2 = _7382;
        if( _1 != _7382 ){
            DeRef(_1);
        }
        _7382 = NOVALUE;
        _7379 = NOVALUE;
        goto L17; // [1006] 1098

        /** 			case APPEND then*/
        case 6:

        /** 				map_data[VALUE_LIST][index_] = append( map_data[VALUE_LIST][index_], the_value_p )*/
        _2 = (int)SEQ_PTR(_map_data_13375);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13375 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_map_data_13375);
        _7385 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7385);
        _7386 = (int)*(((s1_ptr)_2)->base + _index__13371);
        _7385 = NOVALUE;
        Ref(_the_value_p_13368);
        Append(&_7387, _7386, _the_value_p_13368);
        _7386 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13371);
        _1 = *(int *)_2;
        *(int *)_2 = _7387;
        if( _1 != _7387 ){
            DeRef(_1);
        }
        _7387 = NOVALUE;
        _7383 = NOVALUE;
        goto L17; // [1035] 1098

        /** 			case CONCAT then*/
        case 7:

        /** 				map_data[VALUE_LIST][index_] &= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13375);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13375 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7390 = (int)*(((s1_ptr)_2)->base + _index__13371);
        _7388 = NOVALUE;
        if (IS_SEQUENCE(_7390) && IS_ATOM(_the_value_p_13368)) {
            Ref(_the_value_p_13368);
            Append(&_7391, _7390, _the_value_p_13368);
        }
        else if (IS_ATOM(_7390) && IS_SEQUENCE(_the_value_p_13368)) {
            Ref(_7390);
            Prepend(&_7391, _the_value_p_13368, _7390);
        }
        else {
            Concat((object_ptr)&_7391, _7390, _the_value_p_13368);
            _7390 = NOVALUE;
        }
        _7390 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13371);
        _1 = *(int *)_2;
        *(int *)_2 = _7391;
        if( _1 != _7391 ){
            DeRef(_1);
        }
        _7391 = NOVALUE;
        _7388 = NOVALUE;
        goto L17; // [1060] 1098

        /** 			case LEAVE then*/
        case 8:

        /** 				operation_p = operation_p*/
        _operation_p_13369 = _operation_p_13369;
        goto L17; // [1071] 1098

        /** 			case else*/
        default:

        /** 				error:crash("Unknown operation given to map.e:put()")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_1079_13561);
        _msg_inlined_crash_at_1079_13561 = EPrintf(-9999999, _7297, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_1079_13561);

        /** end procedure*/
        goto L18; // [1092] 1095
L18: 
        DeRefi(_msg_inlined_crash_at_1079_13561);
        _msg_inlined_crash_at_1079_13561 = NOVALUE;
    ;}L17: 

    /** 		eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13375);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_12249 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13366);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13375;
    DeRef(_1);

    /** 		return*/
    DeRef(_the_key_p_13367);
    DeRef(_the_value_p_13368);
    DeRef(_average_length__13373);
    DeRefDS(_map_data_13375);
    _7261 = NOVALUE;
    _7305 = NOVALUE;
    return;
LB: 

    /** end procedure*/
    DeRef(_the_key_p_13367);
    DeRef(_the_value_p_13368);
    DeRef(_average_length__13373);
    DeRef(_map_data_13375);
    _7261 = NOVALUE;
    _7305 = NOVALUE;
    return;
    ;
}


void _32nested_put(int _the_map_p_13564, int _the_keys_p_13565, int _the_value_p_13566, int _operation_p_13567, int _trigger_p_13568)
{
    int _temp_map__13569 = NOVALUE;
    int _7403 = NOVALUE;
    int _7402 = NOVALUE;
    int _7401 = NOVALUE;
    int _7400 = NOVALUE;
    int _7399 = NOVALUE;
    int _7398 = NOVALUE;
    int _7396 = NOVALUE;
    int _7395 = NOVALUE;
    int _7394 = NOVALUE;
    int _7392 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length( the_keys_p ) = 1 then*/
    if (IS_SEQUENCE(_the_keys_p_13565)){
            _7392 = SEQ_PTR(_the_keys_p_13565)->length;
    }
    else {
        _7392 = 1;
    }
    if (_7392 != 1)
    goto L1; // [12] 32

    /** 		put( the_map_p, the_keys_p[1], the_value_p, operation_p, trigger_p )*/
    _2 = (int)SEQ_PTR(_the_keys_p_13565);
    _7394 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_13564);
    Ref(_7394);
    Ref(_the_value_p_13566);
    _32put(_the_map_p_13564, _7394, _the_value_p_13566, _operation_p_13567, _trigger_p_13568);
    _7394 = NOVALUE;
    goto L2; // [29] 89
L1: 

    /** 		temp_map_ = new_extra( get( the_map_p, the_keys_p[1] ) )*/
    _2 = (int)SEQ_PTR(_the_keys_p_13565);
    _7395 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_13564);
    Ref(_7395);
    _7396 = _32get(_the_map_p_13564, _7395, 0);
    _7395 = NOVALUE;
    _0 = _temp_map__13569;
    _temp_map__13569 = _32new_extra(_7396, 690);
    DeRef(_0);
    _7396 = NOVALUE;

    /** 		nested_put( temp_map_, the_keys_p[2..$], the_value_p, operation_p, trigger_p )*/
    if (IS_SEQUENCE(_the_keys_p_13565)){
            _7398 = SEQ_PTR(_the_keys_p_13565)->length;
    }
    else {
        _7398 = 1;
    }
    rhs_slice_target = (object_ptr)&_7399;
    RHS_Slice(_the_keys_p_13565, 2, _7398);
    Ref(_the_value_p_13566);
    DeRef(_7400);
    _7400 = _the_value_p_13566;
    DeRef(_7401);
    _7401 = _operation_p_13567;
    DeRef(_7402);
    _7402 = _trigger_p_13568;
    Ref(_temp_map__13569);
    _32nested_put(_temp_map__13569, _7399, _7400, _7401, _7402);
    _7399 = NOVALUE;
    _7400 = NOVALUE;
    _7401 = NOVALUE;
    _7402 = NOVALUE;

    /** 		put( the_map_p, the_keys_p[1], temp_map_, PUT, trigger_p )*/
    _2 = (int)SEQ_PTR(_the_keys_p_13565);
    _7403 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_13564);
    Ref(_7403);
    Ref(_temp_map__13569);
    _32put(_the_map_p_13564, _7403, _temp_map__13569, 1, _trigger_p_13568);
    _7403 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_the_map_p_13564);
    DeRefDS(_the_keys_p_13565);
    DeRef(_the_value_p_13566);
    DeRef(_temp_map__13569);
    return;
    ;
}


void _32remove(int _the_map_p_13586, int _the_key_p_13587)
{
    int _index__13588 = NOVALUE;
    int _bucket__13589 = NOVALUE;
    int _temp_map__13590 = NOVALUE;
    int _from__13591 = NOVALUE;
    int _calc_hash_1__tmp_at40_13602 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_40_13601 = NOVALUE;
    int _ret__inlined_calc_hash_at_40_13600 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_37_13599 = NOVALUE;
    int _7468 = NOVALUE;
    int _7467 = NOVALUE;
    int _7466 = NOVALUE;
    int _7465 = NOVALUE;
    int _7463 = NOVALUE;
    int _7461 = NOVALUE;
    int _7459 = NOVALUE;
    int _7457 = NOVALUE;
    int _7456 = NOVALUE;
    int _7454 = NOVALUE;
    int _7451 = NOVALUE;
    int _7450 = NOVALUE;
    int _7449 = NOVALUE;
    int _7448 = NOVALUE;
    int _7447 = NOVALUE;
    int _7446 = NOVALUE;
    int _7445 = NOVALUE;
    int _7444 = NOVALUE;
    int _7443 = NOVALUE;
    int _7442 = NOVALUE;
    int _7441 = NOVALUE;
    int _7440 = NOVALUE;
    int _7439 = NOVALUE;
    int _7437 = NOVALUE;
    int _7436 = NOVALUE;
    int _7435 = NOVALUE;
    int _7434 = NOVALUE;
    int _7433 = NOVALUE;
    int _7432 = NOVALUE;
    int _7431 = NOVALUE;
    int _7430 = NOVALUE;
    int _7429 = NOVALUE;
    int _7428 = NOVALUE;
    int _7427 = NOVALUE;
    int _7425 = NOVALUE;
    int _7423 = NOVALUE;
    int _7421 = NOVALUE;
    int _7420 = NOVALUE;
    int _7419 = NOVALUE;
    int _7417 = NOVALUE;
    int _7416 = NOVALUE;
    int _7415 = NOVALUE;
    int _7414 = NOVALUE;
    int _7413 = NOVALUE;
    int _7410 = NOVALUE;
    int _7409 = NOVALUE;
    int _7408 = NOVALUE;
    int _7407 = NOVALUE;
    int _7405 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__13590);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!IS_ATOM_INT(_the_map_p_13586)){
        _temp_map__13590 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13586)->dbl));
    }
    else{
        _temp_map__13590 = (int)*(((s1_ptr)_2)->base + _the_map_p_13586);
    }
    Ref(_temp_map__13590);

    /** 	eumem:ram_space[the_map_p] = 0*/
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_12249 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_13586))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13586)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13586);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13590);
    _7405 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7405, 76)){
        _7405 = NOVALUE;
        goto L1; // [25] 305
    }
    _7405 = NOVALUE;

    /** 		bucket_ = calc_hash(the_key_p, length(temp_map_[KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_temp_map__13590);
    _7407 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7407)){
            _7408 = SEQ_PTR(_7407)->length;
    }
    else {
        _7408 = 1;
    }
    _7407 = NOVALUE;
    _max_hash_p_inlined_calc_hash_at_37_13599 = _7408;
    _7408 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_40_13600);
    _ret__inlined_calc_hash_at_40_13600 = calc_hash(_the_key_p_13587, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_40_13600)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_40_13600)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_40_13600);
        _ret__inlined_calc_hash_at_40_13600 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at40_13602 = (_ret__inlined_calc_hash_at_40_13600 % _max_hash_p_inlined_calc_hash_at_37_13599);
    _bucket__13589 = _calc_hash_1__tmp_at40_13602 + 1;
    DeRef(_ret__inlined_calc_hash_at_40_13600);
    _ret__inlined_calc_hash_at_40_13600 = NOVALUE;
    if (!IS_ATOM_INT(_bucket__13589)) {
        _1 = (long)(DBL_PTR(_bucket__13589)->dbl);
        DeRefDS(_bucket__13589);
        _bucket__13589 = _1;
    }

    /** 		index_ = find(the_key_p, temp_map_[KEY_BUCKETS][bucket_])*/
    _2 = (int)SEQ_PTR(_temp_map__13590);
    _7409 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7409);
    _7410 = (int)*(((s1_ptr)_2)->base + _bucket__13589);
    _7409 = NOVALUE;
    _index__13588 = find_from(_the_key_p_13587, _7410, 1);
    _7410 = NOVALUE;

    /** 		if index_ != 0 then*/
    if (_index__13588 == 0)
    goto L2; // [83] 431

    /** 			temp_map_[ELEMENT_COUNT] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__13590);
    _7413 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7413)) {
        _7414 = _7413 - 1;
        if ((long)((unsigned long)_7414 +(unsigned long) HIGH_BITS) >= 0){
            _7414 = NewDouble((double)_7414);
        }
    }
    else {
        _7414 = binary_op(MINUS, _7413, 1);
    }
    _7413 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13590);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13590 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _7414;
    if( _1 != _7414 ){
        DeRef(_1);
    }
    _7414 = NOVALUE;

    /** 			if length(temp_map_[KEY_BUCKETS][bucket_]) = 1 then*/
    _2 = (int)SEQ_PTR(_temp_map__13590);
    _7415 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7415);
    _7416 = (int)*(((s1_ptr)_2)->base + _bucket__13589);
    _7415 = NOVALUE;
    if (IS_SEQUENCE(_7416)){
            _7417 = SEQ_PTR(_7416)->length;
    }
    else {
        _7417 = 1;
    }
    _7416 = NOVALUE;
    if (_7417 != 1)
    goto L3; // [114] 157

    /** 				temp_map_[IN_USE] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__13590);
    _7419 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7419)) {
        _7420 = _7419 - 1;
        if ((long)((unsigned long)_7420 +(unsigned long) HIGH_BITS) >= 0){
            _7420 = NewDouble((double)_7420);
        }
    }
    else {
        _7420 = binary_op(MINUS, _7419, 1);
    }
    _7419 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13590);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13590 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _7420;
    if( _1 != _7420 ){
        DeRef(_1);
    }
    _7420 = NOVALUE;

    /** 				temp_map_[KEY_BUCKETS][bucket_] = {}*/
    _2 = (int)SEQ_PTR(_temp_map__13590);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13590 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    RefDS(_5);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13589);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);
    _7421 = NOVALUE;

    /** 				temp_map_[VALUE_BUCKETS][bucket_] = {}*/
    _2 = (int)SEQ_PTR(_temp_map__13590);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13590 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    RefDS(_5);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13589);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);
    _7423 = NOVALUE;
    goto L4; // [154] 262
L3: 

    /** 				temp_map_[VALUE_BUCKETS][bucket_] = temp_map_[VALUE_BUCKETS][bucket_][1 .. index_-1] & */
    _2 = (int)SEQ_PTR(_temp_map__13590);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13590 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_temp_map__13590);
    _7427 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7427);
    _7428 = (int)*(((s1_ptr)_2)->base + _bucket__13589);
    _7427 = NOVALUE;
    _7429 = _index__13588 - 1;
    rhs_slice_target = (object_ptr)&_7430;
    RHS_Slice(_7428, 1, _7429);
    _7428 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13590);
    _7431 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7431);
    _7432 = (int)*(((s1_ptr)_2)->base + _bucket__13589);
    _7431 = NOVALUE;
    _7433 = _index__13588 + 1;
    if (_7433 > MAXINT){
        _7433 = NewDouble((double)_7433);
    }
    if (IS_SEQUENCE(_7432)){
            _7434 = SEQ_PTR(_7432)->length;
    }
    else {
        _7434 = 1;
    }
    rhs_slice_target = (object_ptr)&_7435;
    RHS_Slice(_7432, _7433, _7434);
    _7432 = NOVALUE;
    Concat((object_ptr)&_7436, _7430, _7435);
    DeRefDS(_7430);
    _7430 = NOVALUE;
    DeRef(_7430);
    _7430 = NOVALUE;
    DeRefDS(_7435);
    _7435 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13589);
    _1 = *(int *)_2;
    *(int *)_2 = _7436;
    if( _1 != _7436 ){
        DeRef(_1);
    }
    _7436 = NOVALUE;
    _7425 = NOVALUE;

    /** 				temp_map_[KEY_BUCKETS][bucket_] = temp_map_[KEY_BUCKETS][bucket_][1 .. index_-1] & */
    _2 = (int)SEQ_PTR(_temp_map__13590);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13590 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_temp_map__13590);
    _7439 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7439);
    _7440 = (int)*(((s1_ptr)_2)->base + _bucket__13589);
    _7439 = NOVALUE;
    _7441 = _index__13588 - 1;
    rhs_slice_target = (object_ptr)&_7442;
    RHS_Slice(_7440, 1, _7441);
    _7440 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13590);
    _7443 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7443);
    _7444 = (int)*(((s1_ptr)_2)->base + _bucket__13589);
    _7443 = NOVALUE;
    _7445 = _index__13588 + 1;
    if (_7445 > MAXINT){
        _7445 = NewDouble((double)_7445);
    }
    if (IS_SEQUENCE(_7444)){
            _7446 = SEQ_PTR(_7444)->length;
    }
    else {
        _7446 = 1;
    }
    rhs_slice_target = (object_ptr)&_7447;
    RHS_Slice(_7444, _7445, _7446);
    _7444 = NOVALUE;
    Concat((object_ptr)&_7448, _7442, _7447);
    DeRefDS(_7442);
    _7442 = NOVALUE;
    DeRef(_7442);
    _7442 = NOVALUE;
    DeRefDS(_7447);
    _7447 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13589);
    _1 = *(int *)_2;
    *(int *)_2 = _7448;
    if( _1 != _7448 ){
        DeRef(_1);
    }
    _7448 = NOVALUE;
    _7437 = NOVALUE;
L4: 

    /** 			if temp_map_[ELEMENT_COUNT] < floor(51 * threshold_size / 100) then*/
    _2 = (int)SEQ_PTR(_temp_map__13590);
    _7449 = (int)*(((s1_ptr)_2)->base + 2);
    _7450 = 1173;
    _7451 = 11;
    _7450 = NOVALUE;
    if (binary_op_a(GREATEREQ, _7449, 11)){
        _7449 = NOVALUE;
        _7451 = NOVALUE;
        goto L2; // [278] 431
    }
    _7449 = NOVALUE;
    DeRef(_7451);
    _7451 = NOVALUE;

    /** 				eumem:ram_space[the_map_p] = temp_map_*/
    RefDS(_temp_map__13590);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_12249 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_13586))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13586)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13586);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_map__13590;
    DeRef(_1);

    /** 				convert_to_small_map(the_map_p)*/
    Ref(_the_map_p_13586);
    _32convert_to_small_map(_the_map_p_13586);

    /** 				return*/
    DeRef(_the_map_p_13586);
    DeRef(_the_key_p_13587);
    DeRefDS(_temp_map__13590);
    _7407 = NOVALUE;
    _7416 = NOVALUE;
    DeRef(_7429);
    _7429 = NOVALUE;
    DeRef(_7441);
    _7441 = NOVALUE;
    DeRef(_7433);
    _7433 = NOVALUE;
    DeRef(_7445);
    _7445 = NOVALUE;
    return;
    goto L2; // [302] 431
L1: 

    /** 		from_ = 1*/
    _from__13591 = 1;

    /** 		while from_ > 0 do*/
L5: 
    if (_from__13591 <= 0)
    goto L6; // [315] 430

    /** 			index_ = find(the_key_p, temp_map_[KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_temp_map__13590);
    _7454 = (int)*(((s1_ptr)_2)->base + 5);
    _index__13588 = find_from(_the_key_p_13587, _7454, _from__13591);
    _7454 = NOVALUE;

    /** 			if index_ then*/
    if (_index__13588 == 0)
    {
        goto L6; // [332] 430
    }
    else{
    }

    /** 				if temp_map_[FREE_LIST][index_] = 1 then*/
    _2 = (int)SEQ_PTR(_temp_map__13590);
    _7456 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_7456);
    _7457 = (int)*(((s1_ptr)_2)->base + _index__13588);
    _7456 = NOVALUE;
    if (binary_op_a(NOTEQ, _7457, 1)){
        _7457 = NOVALUE;
        goto L7; // [345] 419
    }
    _7457 = NOVALUE;

    /** 					temp_map_[FREE_LIST][index_] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13590);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13590 = MAKE_SEQ(_2);
    }
    _3 = (int)(7 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13588);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _7459 = NOVALUE;

    /** 					temp_map_[KEY_LIST][index_] = init_small_map_key*/
    _2 = (int)SEQ_PTR(_temp_map__13590);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13590 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    RefDS(_32init_small_map_key_12994);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13588);
    _1 = *(int *)_2;
    *(int *)_2 = _32init_small_map_key_12994;
    DeRef(_1);
    _7461 = NOVALUE;

    /** 					temp_map_[VALUE_LIST][index_] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13590);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13590 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13588);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _7463 = NOVALUE;

    /** 					temp_map_[IN_USE] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__13590);
    _7465 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7465)) {
        _7466 = _7465 - 1;
        if ((long)((unsigned long)_7466 +(unsigned long) HIGH_BITS) >= 0){
            _7466 = NewDouble((double)_7466);
        }
    }
    else {
        _7466 = binary_op(MINUS, _7465, 1);
    }
    _7465 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13590);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13590 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _7466;
    if( _1 != _7466 ){
        DeRef(_1);
    }
    _7466 = NOVALUE;

    /** 					temp_map_[ELEMENT_COUNT] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__13590);
    _7467 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7467)) {
        _7468 = _7467 - 1;
        if ((long)((unsigned long)_7468 +(unsigned long) HIGH_BITS) >= 0){
            _7468 = NewDouble((double)_7468);
        }
    }
    else {
        _7468 = binary_op(MINUS, _7467, 1);
    }
    _7467 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13590);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13590 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _7468;
    if( _1 != _7468 ){
        DeRef(_1);
    }
    _7468 = NOVALUE;
    goto L7; // [411] 419

    /** 				exit*/
    goto L6; // [416] 430
L7: 

    /** 			from_ = index_ + 1*/
    _from__13591 = _index__13588 + 1;

    /** 		end while*/
    goto L5; // [427] 315
L6: 
L2: 

    /** 	eumem:ram_space[the_map_p] = temp_map_*/
    RefDS(_temp_map__13590);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_12249 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_13586))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13586)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13586);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_map__13590;
    DeRef(_1);

    /** end procedure*/
    DeRef(_the_map_p_13586);
    DeRef(_the_key_p_13587);
    DeRefDS(_temp_map__13590);
    _7407 = NOVALUE;
    _7416 = NOVALUE;
    DeRef(_7429);
    _7429 = NOVALUE;
    DeRef(_7441);
    _7441 = NOVALUE;
    DeRef(_7433);
    _7433 = NOVALUE;
    DeRef(_7445);
    _7445 = NOVALUE;
    return;
    ;
}


void _32clear(int _the_map_p_13676)
{
    int _temp_map__13677 = NOVALUE;
    int _7487 = NOVALUE;
    int _7486 = NOVALUE;
    int _7485 = NOVALUE;
    int _7484 = NOVALUE;
    int _7483 = NOVALUE;
    int _7482 = NOVALUE;
    int _7481 = NOVALUE;
    int _7480 = NOVALUE;
    int _7479 = NOVALUE;
    int _7478 = NOVALUE;
    int _7477 = NOVALUE;
    int _7476 = NOVALUE;
    int _7475 = NOVALUE;
    int _7474 = NOVALUE;
    int _7473 = NOVALUE;
    int _7471 = NOVALUE;
    int _0, _1, _2;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__13677);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!IS_ATOM_INT(_the_map_p_13676)){
        _temp_map__13677 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13676)->dbl));
    }
    else{
        _temp_map__13677 = (int)*(((s1_ptr)_2)->base + _the_map_p_13676);
    }
    Ref(_temp_map__13677);

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13677);
    _7471 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7471, 76)){
        _7471 = NOVALUE;
        goto L1; // [17] 70
    }
    _7471 = NOVALUE;

    /** 		temp_map_[ELEMENT_COUNT] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13677);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13677 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[IN_USE] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13677);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13677 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[KEY_BUCKETS] = repeat({}, length(temp_map_[KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_temp_map__13677);
    _7473 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7473)){
            _7474 = SEQ_PTR(_7473)->length;
    }
    else {
        _7474 = 1;
    }
    _7473 = NOVALUE;
    _7475 = Repeat(_5, _7474);
    _7474 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13677);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13677 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _7475;
    if( _1 != _7475 ){
        DeRef(_1);
    }
    _7475 = NOVALUE;

    /** 		temp_map_[VALUE_BUCKETS] = repeat({}, length(temp_map_[VALUE_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_temp_map__13677);
    _7476 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_7476)){
            _7477 = SEQ_PTR(_7476)->length;
    }
    else {
        _7477 = 1;
    }
    _7476 = NOVALUE;
    _7478 = Repeat(_5, _7477);
    _7477 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13677);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13677 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _7478;
    if( _1 != _7478 ){
        DeRef(_1);
    }
    _7478 = NOVALUE;
    goto L2; // [67] 134
L1: 

    /** 		temp_map_[ELEMENT_COUNT] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13677);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13677 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[IN_USE] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13677);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13677 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[KEY_LIST] = repeat(init_small_map_key, length(temp_map_[KEY_LIST]))*/
    _2 = (int)SEQ_PTR(_temp_map__13677);
    _7479 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7479)){
            _7480 = SEQ_PTR(_7479)->length;
    }
    else {
        _7480 = 1;
    }
    _7479 = NOVALUE;
    _7481 = Repeat(_32init_small_map_key_12994, _7480);
    _7480 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13677);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13677 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _7481;
    if( _1 != _7481 ){
        DeRef(_1);
    }
    _7481 = NOVALUE;

    /** 		temp_map_[VALUE_LIST] = repeat(0, length(temp_map_[VALUE_LIST]))*/
    _2 = (int)SEQ_PTR(_temp_map__13677);
    _7482 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_7482)){
            _7483 = SEQ_PTR(_7482)->length;
    }
    else {
        _7483 = 1;
    }
    _7482 = NOVALUE;
    _7484 = Repeat(0, _7483);
    _7483 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13677);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13677 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _7484;
    if( _1 != _7484 ){
        DeRef(_1);
    }
    _7484 = NOVALUE;

    /** 		temp_map_[FREE_LIST] = repeat(0, length(temp_map_[FREE_LIST]))*/
    _2 = (int)SEQ_PTR(_temp_map__13677);
    _7485 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7485)){
            _7486 = SEQ_PTR(_7485)->length;
    }
    else {
        _7486 = 1;
    }
    _7485 = NOVALUE;
    _7487 = Repeat(0, _7486);
    _7486 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13677);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13677 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _7487;
    if( _1 != _7487 ){
        DeRef(_1);
    }
    _7487 = NOVALUE;
L2: 

    /** 	eumem:ram_space[the_map_p] = temp_map_*/
    RefDS(_temp_map__13677);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_12249 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_13676))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13676)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13676);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_map__13677;
    DeRef(_1);

    /** end procedure*/
    DeRef(_the_map_p_13676);
    DeRefDS(_temp_map__13677);
    _7473 = NOVALUE;
    _7476 = NOVALUE;
    _7479 = NOVALUE;
    _7482 = NOVALUE;
    _7485 = NOVALUE;
    return;
    ;
}


int _32keys(int _the_map_p_13758, int _sorted_result_13759)
{
    int _buckets__13760 = NOVALUE;
    int _current_bucket__13761 = NOVALUE;
    int _results__13762 = NOVALUE;
    int _pos__13763 = NOVALUE;
    int _temp_map__13764 = NOVALUE;
    int _7545 = NOVALUE;
    int _7543 = NOVALUE;
    int _7542 = NOVALUE;
    int _7540 = NOVALUE;
    int _7539 = NOVALUE;
    int _7538 = NOVALUE;
    int _7537 = NOVALUE;
    int _7535 = NOVALUE;
    int _7534 = NOVALUE;
    int _7533 = NOVALUE;
    int _7532 = NOVALUE;
    int _7530 = NOVALUE;
    int _7528 = NOVALUE;
    int _7525 = NOVALUE;
    int _7523 = NOVALUE;
    int _0, _1, _2;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__13764);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!IS_ATOM_INT(_the_map_p_13758)){
        _temp_map__13764 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13758)->dbl));
    }
    else{
        _temp_map__13764 = (int)*(((s1_ptr)_2)->base + _the_map_p_13758);
    }
    Ref(_temp_map__13764);

    /** 	results_ = repeat(0, temp_map_[ELEMENT_COUNT])*/
    _2 = (int)SEQ_PTR(_temp_map__13764);
    _7523 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_results__13762);
    _results__13762 = Repeat(0, _7523);
    _7523 = NOVALUE;

    /** 	pos_ = 1*/
    _pos__13763 = 1;

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13764);
    _7525 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7525, 76)){
        _7525 = NOVALUE;
        goto L1; // [34] 113
    }
    _7525 = NOVALUE;

    /** 		buckets_ = temp_map_[KEY_BUCKETS]*/
    DeRef(_buckets__13760);
    _2 = (int)SEQ_PTR(_temp_map__13764);
    _buckets__13760 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_buckets__13760);

    /** 		for index = 1 to length(buckets_) do*/
    if (IS_SEQUENCE(_buckets__13760)){
            _7528 = SEQ_PTR(_buckets__13760)->length;
    }
    else {
        _7528 = 1;
    }
    {
        int _index_13773;
        _index_13773 = 1;
L2: 
        if (_index_13773 > _7528){
            goto L3; // [51] 110
        }

        /** 			current_bucket_ = buckets_[index]*/
        DeRef(_current_bucket__13761);
        _2 = (int)SEQ_PTR(_buckets__13760);
        _current_bucket__13761 = (int)*(((s1_ptr)_2)->base + _index_13773);
        Ref(_current_bucket__13761);

        /** 			if length(current_bucket_) > 0 then*/
        if (IS_SEQUENCE(_current_bucket__13761)){
                _7530 = SEQ_PTR(_current_bucket__13761)->length;
        }
        else {
            _7530 = 1;
        }
        if (_7530 <= 0)
        goto L4; // [71] 103

        /** 				results_[pos_ .. pos_ + length(current_bucket_) - 1] = current_bucket_*/
        if (IS_SEQUENCE(_current_bucket__13761)){
                _7532 = SEQ_PTR(_current_bucket__13761)->length;
        }
        else {
            _7532 = 1;
        }
        _7533 = _pos__13763 + _7532;
        if ((long)((unsigned long)_7533 + (unsigned long)HIGH_BITS) >= 0) 
        _7533 = NewDouble((double)_7533);
        _7532 = NOVALUE;
        if (IS_ATOM_INT(_7533)) {
            _7534 = _7533 - 1;
        }
        else {
            _7534 = NewDouble(DBL_PTR(_7533)->dbl - (double)1);
        }
        DeRef(_7533);
        _7533 = NOVALUE;
        assign_slice_seq = (s1_ptr *)&_results__13762;
        AssignSlice(_pos__13763, _7534, _current_bucket__13761);
        DeRef(_7534);
        _7534 = NOVALUE;

        /** 				pos_ += length(current_bucket_)*/
        if (IS_SEQUENCE(_current_bucket__13761)){
                _7535 = SEQ_PTR(_current_bucket__13761)->length;
        }
        else {
            _7535 = 1;
        }
        _pos__13763 = _pos__13763 + _7535;
        _7535 = NOVALUE;
L4: 

        /** 		end for*/
        _index_13773 = _index_13773 + 1;
        goto L2; // [105] 58
L3: 
        ;
    }
    goto L5; // [110] 172
L1: 

    /** 		for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__13764);
    _7537 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7537)){
            _7538 = SEQ_PTR(_7537)->length;
    }
    else {
        _7538 = 1;
    }
    _7537 = NOVALUE;
    {
        int _index_13786;
        _index_13786 = 1;
L6: 
        if (_index_13786 > _7538){
            goto L7; // [122] 171
        }

        /** 			if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__13764);
        _7539 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_7539);
        _7540 = (int)*(((s1_ptr)_2)->base + _index_13786);
        _7539 = NOVALUE;
        if (binary_op_a(EQUALS, _7540, 0)){
            _7540 = NOVALUE;
            goto L8; // [139] 164
        }
        _7540 = NOVALUE;

        /** 				results_[pos_] = temp_map_[KEY_LIST][index]*/
        _2 = (int)SEQ_PTR(_temp_map__13764);
        _7542 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_7542);
        _7543 = (int)*(((s1_ptr)_2)->base + _index_13786);
        _7542 = NOVALUE;
        Ref(_7543);
        _2 = (int)SEQ_PTR(_results__13762);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__13762 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _pos__13763);
        _1 = *(int *)_2;
        *(int *)_2 = _7543;
        if( _1 != _7543 ){
            DeRef(_1);
        }
        _7543 = NOVALUE;

        /** 				pos_ += 1*/
        _pos__13763 = _pos__13763 + 1;
L8: 

        /** 		end for*/
        _index_13786 = _index_13786 + 1;
        goto L6; // [166] 129
L7: 
        ;
    }
L5: 

    /** 	if sorted_result then*/
    if (_sorted_result_13759 == 0)
    {
        goto L9; // [174] 191
    }
    else{
    }

    /** 		return stdsort:sort(results_)*/
    RefDS(_results__13762);
    _7545 = _24sort(_results__13762, 1);
    DeRef(_the_map_p_13758);
    DeRef(_buckets__13760);
    DeRef(_current_bucket__13761);
    DeRefDS(_results__13762);
    DeRef(_temp_map__13764);
    _7537 = NOVALUE;
    return _7545;
    goto LA; // [188] 198
L9: 

    /** 		return results_*/
    DeRef(_the_map_p_13758);
    DeRef(_buckets__13760);
    DeRef(_current_bucket__13761);
    DeRef(_temp_map__13764);
    _7537 = NOVALUE;
    DeRef(_7545);
    _7545 = NOVALUE;
    return _results__13762;
LA: 
    ;
}


int _32values(int _the_map_13801, int _keys_13802, int _default_values_13803)
{
    int _buckets__13827 = NOVALUE;
    int _bucket__13828 = NOVALUE;
    int _results__13829 = NOVALUE;
    int _pos__13830 = NOVALUE;
    int _temp_map__13831 = NOVALUE;
    int _7585 = NOVALUE;
    int _7584 = NOVALUE;
    int _7582 = NOVALUE;
    int _7581 = NOVALUE;
    int _7580 = NOVALUE;
    int _7579 = NOVALUE;
    int _7577 = NOVALUE;
    int _7576 = NOVALUE;
    int _7575 = NOVALUE;
    int _7574 = NOVALUE;
    int _7572 = NOVALUE;
    int _7570 = NOVALUE;
    int _7567 = NOVALUE;
    int _7565 = NOVALUE;
    int _7563 = NOVALUE;
    int _7562 = NOVALUE;
    int _7561 = NOVALUE;
    int _7560 = NOVALUE;
    int _7558 = NOVALUE;
    int _7557 = NOVALUE;
    int _7556 = NOVALUE;
    int _7555 = NOVALUE;
    int _7554 = NOVALUE;
    int _7553 = NOVALUE;
    int _7551 = NOVALUE;
    int _7550 = NOVALUE;
    int _7548 = NOVALUE;
    int _7547 = NOVALUE;
    int _7546 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(keys) then*/
    _7546 = 0;
    if (_7546 == 0)
    {
        _7546 = NOVALUE;
        goto L1; // [6] 116
    }
    else{
        _7546 = NOVALUE;
    }

    /** 		if atom(default_values) then*/
    _7547 = 1;
    if (_7547 == 0)
    {
        _7547 = NOVALUE;
        goto L2; // [14] 29
    }
    else{
        _7547 = NOVALUE;
    }

    /** 			default_values = repeat(default_values, length(keys))*/
    _7548 = 1;
    _default_values_13803 = Repeat(0, 1);
    _7548 = NOVALUE;
    goto L3; // [26] 70
L2: 

    /** 		elsif length(default_values) < length(keys) then*/
    if (IS_SEQUENCE(_default_values_13803)){
            _7550 = SEQ_PTR(_default_values_13803)->length;
    }
    else {
        _7550 = 1;
    }
    if (IS_SEQUENCE(_keys_13802)){
            _7551 = SEQ_PTR(_keys_13802)->length;
    }
    else {
        _7551 = 1;
    }
    if (_7550 >= _7551)
    goto L4; // [37] 69

    /** 			default_values &= repeat(default_values[$], length(keys) - length(default_values))*/
    if (IS_SEQUENCE(_default_values_13803)){
            _7553 = SEQ_PTR(_default_values_13803)->length;
    }
    else {
        _7553 = 1;
    }
    _2 = (int)SEQ_PTR(_default_values_13803);
    _7554 = (int)*(((s1_ptr)_2)->base + _7553);
    if (IS_SEQUENCE(_keys_13802)){
            _7555 = SEQ_PTR(_keys_13802)->length;
    }
    else {
        _7555 = 1;
    }
    if (IS_SEQUENCE(_default_values_13803)){
            _7556 = SEQ_PTR(_default_values_13803)->length;
    }
    else {
        _7556 = 1;
    }
    _7557 = _7555 - _7556;
    _7555 = NOVALUE;
    _7556 = NOVALUE;
    _7558 = Repeat(_7554, _7557);
    _7554 = NOVALUE;
    _7557 = NOVALUE;
    if (IS_SEQUENCE(_default_values_13803) && IS_ATOM(_7558)) {
    }
    else if (IS_ATOM(_default_values_13803) && IS_SEQUENCE(_7558)) {
        Ref(_default_values_13803);
        Prepend(&_default_values_13803, _7558, _default_values_13803);
    }
    else {
        Concat((object_ptr)&_default_values_13803, _default_values_13803, _7558);
    }
    DeRefDS(_7558);
    _7558 = NOVALUE;
L4: 
L3: 

    /** 		for i = 1 to length(keys) do*/
    if (IS_SEQUENCE(_keys_13802)){
            _7560 = SEQ_PTR(_keys_13802)->length;
    }
    else {
        _7560 = 1;
    }
    {
        int _i_13822;
        _i_13822 = 1;
L5: 
        if (_i_13822 > _7560){
            goto L6; // [75] 109
        }

        /** 			keys[i] = get(the_map, keys[i], default_values[i])*/
        _2 = (int)SEQ_PTR(_keys_13802);
        _7561 = (int)*(((s1_ptr)_2)->base + _i_13822);
        _2 = (int)SEQ_PTR(_default_values_13803);
        _7562 = (int)*(((s1_ptr)_2)->base + _i_13822);
        Ref(_7561);
        Ref(_7562);
        _7563 = _32get(_the_map_13801, _7561, _7562);
        _7561 = NOVALUE;
        _7562 = NOVALUE;
        _2 = (int)SEQ_PTR(_keys_13802);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _keys_13802 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_13822);
        _1 = *(int *)_2;
        *(int *)_2 = _7563;
        if( _1 != _7563 ){
            DeRef(_1);
        }
        _7563 = NOVALUE;

        /** 		end for*/
        _i_13822 = _i_13822 + 1;
        goto L5; // [104] 82
L6: 
        ;
    }

    /** 		return keys*/
    DeRef(_default_values_13803);
    DeRef(_buckets__13827);
    DeRef(_bucket__13828);
    DeRef(_results__13829);
    DeRef(_temp_map__13831);
    return _keys_13802;
L1: 

    /** 	sequence buckets_*/

    /** 	sequence bucket_*/

    /** 	sequence results_*/

    /** 	integer pos_*/

    /** 	sequence temp_map_*/

    /** 	temp_map_ = eumem:ram_space[the_map]*/
    DeRef(_temp_map__13831);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    _temp_map__13831 = (int)*(((s1_ptr)_2)->base + _the_map_13801);
    Ref(_temp_map__13831);

    /** 	results_ = repeat(0, temp_map_[ELEMENT_COUNT])*/
    _2 = (int)SEQ_PTR(_temp_map__13831);
    _7565 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_results__13829);
    _results__13829 = Repeat(0, _7565);
    _7565 = NOVALUE;

    /** 	pos_ = 1*/
    _pos__13830 = 1;

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13831);
    _7567 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7567, 76)){
        _7567 = NOVALUE;
        goto L7; // [157] 236
    }
    _7567 = NOVALUE;

    /** 		buckets_ = temp_map_[VALUE_BUCKETS]*/
    DeRef(_buckets__13827);
    _2 = (int)SEQ_PTR(_temp_map__13831);
    _buckets__13827 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_buckets__13827);

    /** 		for index = 1 to length(buckets_) do*/
    if (IS_SEQUENCE(_buckets__13827)){
            _7570 = SEQ_PTR(_buckets__13827)->length;
    }
    else {
        _7570 = 1;
    }
    {
        int _index_13840;
        _index_13840 = 1;
L8: 
        if (_index_13840 > _7570){
            goto L9; // [174] 233
        }

        /** 			bucket_ = buckets_[index]*/
        DeRef(_bucket__13828);
        _2 = (int)SEQ_PTR(_buckets__13827);
        _bucket__13828 = (int)*(((s1_ptr)_2)->base + _index_13840);
        Ref(_bucket__13828);

        /** 			if length(bucket_) > 0 then*/
        if (IS_SEQUENCE(_bucket__13828)){
                _7572 = SEQ_PTR(_bucket__13828)->length;
        }
        else {
            _7572 = 1;
        }
        if (_7572 <= 0)
        goto LA; // [194] 226

        /** 				results_[pos_ .. pos_ + length(bucket_) - 1] = bucket_*/
        if (IS_SEQUENCE(_bucket__13828)){
                _7574 = SEQ_PTR(_bucket__13828)->length;
        }
        else {
            _7574 = 1;
        }
        _7575 = _pos__13830 + _7574;
        if ((long)((unsigned long)_7575 + (unsigned long)HIGH_BITS) >= 0) 
        _7575 = NewDouble((double)_7575);
        _7574 = NOVALUE;
        if (IS_ATOM_INT(_7575)) {
            _7576 = _7575 - 1;
        }
        else {
            _7576 = NewDouble(DBL_PTR(_7575)->dbl - (double)1);
        }
        DeRef(_7575);
        _7575 = NOVALUE;
        assign_slice_seq = (s1_ptr *)&_results__13829;
        AssignSlice(_pos__13830, _7576, _bucket__13828);
        DeRef(_7576);
        _7576 = NOVALUE;

        /** 				pos_ += length(bucket_)*/
        if (IS_SEQUENCE(_bucket__13828)){
                _7577 = SEQ_PTR(_bucket__13828)->length;
        }
        else {
            _7577 = 1;
        }
        _pos__13830 = _pos__13830 + _7577;
        _7577 = NOVALUE;
LA: 

        /** 		end for*/
        _index_13840 = _index_13840 + 1;
        goto L8; // [228] 181
L9: 
        ;
    }
    goto LB; // [233] 295
L7: 

    /** 		for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__13831);
    _7579 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7579)){
            _7580 = SEQ_PTR(_7579)->length;
    }
    else {
        _7580 = 1;
    }
    _7579 = NOVALUE;
    {
        int _index_13853;
        _index_13853 = 1;
LC: 
        if (_index_13853 > _7580){
            goto LD; // [245] 294
        }

        /** 			if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__13831);
        _7581 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_7581);
        _7582 = (int)*(((s1_ptr)_2)->base + _index_13853);
        _7581 = NOVALUE;
        if (binary_op_a(EQUALS, _7582, 0)){
            _7582 = NOVALUE;
            goto LE; // [262] 287
        }
        _7582 = NOVALUE;

        /** 				results_[pos_] = temp_map_[VALUE_LIST][index]*/
        _2 = (int)SEQ_PTR(_temp_map__13831);
        _7584 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7584);
        _7585 = (int)*(((s1_ptr)_2)->base + _index_13853);
        _7584 = NOVALUE;
        Ref(_7585);
        _2 = (int)SEQ_PTR(_results__13829);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__13829 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _pos__13830);
        _1 = *(int *)_2;
        *(int *)_2 = _7585;
        if( _1 != _7585 ){
            DeRef(_1);
        }
        _7585 = NOVALUE;

        /** 				pos_ += 1*/
        _pos__13830 = _pos__13830 + 1;
LE: 

        /** 		end for*/
        _index_13853 = _index_13853 + 1;
        goto LC; // [289] 252
LD: 
        ;
    }
LB: 

    /** 	return results_*/
    DeRef(_keys_13802);
    DeRef(_default_values_13803);
    DeRef(_buckets__13827);
    DeRef(_bucket__13828);
    DeRef(_temp_map__13831);
    _7579 = NOVALUE;
    return _results__13829;
    ;
}


int _32pairs(int _the_map_p_13865, int _sorted_result_13866)
{
    int _key_bucket__13867 = NOVALUE;
    int _value_bucket__13868 = NOVALUE;
    int _results__13869 = NOVALUE;
    int _pos__13870 = NOVALUE;
    int _temp_map__13871 = NOVALUE;
    int _7621 = NOVALUE;
    int _7619 = NOVALUE;
    int _7618 = NOVALUE;
    int _7616 = NOVALUE;
    int _7615 = NOVALUE;
    int _7614 = NOVALUE;
    int _7612 = NOVALUE;
    int _7610 = NOVALUE;
    int _7609 = NOVALUE;
    int _7608 = NOVALUE;
    int _7607 = NOVALUE;
    int _7605 = NOVALUE;
    int _7603 = NOVALUE;
    int _7602 = NOVALUE;
    int _7600 = NOVALUE;
    int _7599 = NOVALUE;
    int _7597 = NOVALUE;
    int _7595 = NOVALUE;
    int _7594 = NOVALUE;
    int _7593 = NOVALUE;
    int _7591 = NOVALUE;
    int _7589 = NOVALUE;
    int _7588 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__13871);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!IS_ATOM_INT(_the_map_p_13865)){
        _temp_map__13871 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13865)->dbl));
    }
    else{
        _temp_map__13871 = (int)*(((s1_ptr)_2)->base + _the_map_p_13865);
    }
    Ref(_temp_map__13871);

    /** 	results_ = repeat({ 0, 0 }, temp_map_[ELEMENT_COUNT])*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _7588 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_temp_map__13871);
    _7589 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_results__13869);
    _results__13869 = Repeat(_7588, _7589);
    DeRefDS(_7588);
    _7588 = NOVALUE;
    _7589 = NOVALUE;

    /** 	pos_ = 1*/
    _pos__13870 = 1;

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13871);
    _7591 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7591, 76)){
        _7591 = NOVALUE;
        goto L1; // [38] 147
    }
    _7591 = NOVALUE;

    /** 		for index = 1 to length(temp_map_[KEY_BUCKETS]) do*/
    _2 = (int)SEQ_PTR(_temp_map__13871);
    _7593 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7593)){
            _7594 = SEQ_PTR(_7593)->length;
    }
    else {
        _7594 = 1;
    }
    _7593 = NOVALUE;
    {
        int _index_13880;
        _index_13880 = 1;
L2: 
        if (_index_13880 > _7594){
            goto L3; // [51] 144
        }

        /** 			key_bucket_ = temp_map_[KEY_BUCKETS][index]*/
        _2 = (int)SEQ_PTR(_temp_map__13871);
        _7595 = (int)*(((s1_ptr)_2)->base + 5);
        DeRef(_key_bucket__13867);
        _2 = (int)SEQ_PTR(_7595);
        _key_bucket__13867 = (int)*(((s1_ptr)_2)->base + _index_13880);
        Ref(_key_bucket__13867);
        _7595 = NOVALUE;

        /** 			value_bucket_ = temp_map_[VALUE_BUCKETS][index]*/
        _2 = (int)SEQ_PTR(_temp_map__13871);
        _7597 = (int)*(((s1_ptr)_2)->base + 6);
        DeRef(_value_bucket__13868);
        _2 = (int)SEQ_PTR(_7597);
        _value_bucket__13868 = (int)*(((s1_ptr)_2)->base + _index_13880);
        Ref(_value_bucket__13868);
        _7597 = NOVALUE;

        /** 			for j = 1 to length(key_bucket_) do*/
        if (IS_SEQUENCE(_key_bucket__13867)){
                _7599 = SEQ_PTR(_key_bucket__13867)->length;
        }
        else {
            _7599 = 1;
        }
        {
            int _j_13888;
            _j_13888 = 1;
L4: 
            if (_j_13888 > _7599){
                goto L5; // [87] 137
            }

            /** 				results_[pos_][1] = key_bucket_[j]*/
            _2 = (int)SEQ_PTR(_results__13869);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _results__13869 = MAKE_SEQ(_2);
            }
            _3 = (int)(_pos__13870 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(_key_bucket__13867);
            _7602 = (int)*(((s1_ptr)_2)->base + _j_13888);
            Ref(_7602);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 1);
            _1 = *(int *)_2;
            *(int *)_2 = _7602;
            if( _1 != _7602 ){
                DeRef(_1);
            }
            _7602 = NOVALUE;
            _7600 = NOVALUE;

            /** 				results_[pos_][2] = value_bucket_[j]*/
            _2 = (int)SEQ_PTR(_results__13869);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _results__13869 = MAKE_SEQ(_2);
            }
            _3 = (int)(_pos__13870 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(_value_bucket__13868);
            _7605 = (int)*(((s1_ptr)_2)->base + _j_13888);
            Ref(_7605);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 2);
            _1 = *(int *)_2;
            *(int *)_2 = _7605;
            if( _1 != _7605 ){
                DeRef(_1);
            }
            _7605 = NOVALUE;
            _7603 = NOVALUE;

            /** 				pos_ += 1*/
            _pos__13870 = _pos__13870 + 1;

            /** 			end for*/
            _j_13888 = _j_13888 + 1;
            goto L4; // [132] 94
L5: 
            ;
        }

        /** 		end for*/
        _index_13880 = _index_13880 + 1;
        goto L2; // [139] 58
L3: 
        ;
    }
    goto L6; // [144] 230
L1: 

    /** 		for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__13871);
    _7607 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7607)){
            _7608 = SEQ_PTR(_7607)->length;
    }
    else {
        _7608 = 1;
    }
    _7607 = NOVALUE;
    {
        int _index_13899;
        _index_13899 = 1;
L7: 
        if (_index_13899 > _7608){
            goto L8; // [156] 229
        }

        /** 			if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__13871);
        _7609 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_7609);
        _7610 = (int)*(((s1_ptr)_2)->base + _index_13899);
        _7609 = NOVALUE;
        if (binary_op_a(EQUALS, _7610, 0)){
            _7610 = NOVALUE;
            goto L9; // [173] 222
        }
        _7610 = NOVALUE;

        /** 				results_[pos_][1] = temp_map_[KEY_LIST][index]*/
        _2 = (int)SEQ_PTR(_results__13869);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__13869 = MAKE_SEQ(_2);
        }
        _3 = (int)(_pos__13870 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_temp_map__13871);
        _7614 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_7614);
        _7615 = (int)*(((s1_ptr)_2)->base + _index_13899);
        _7614 = NOVALUE;
        Ref(_7615);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _7615;
        if( _1 != _7615 ){
            DeRef(_1);
        }
        _7615 = NOVALUE;
        _7612 = NOVALUE;

        /** 				results_[pos_][2] = temp_map_[VALUE_LIST][index]*/
        _2 = (int)SEQ_PTR(_results__13869);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__13869 = MAKE_SEQ(_2);
        }
        _3 = (int)(_pos__13870 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_temp_map__13871);
        _7618 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7618);
        _7619 = (int)*(((s1_ptr)_2)->base + _index_13899);
        _7618 = NOVALUE;
        Ref(_7619);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _7619;
        if( _1 != _7619 ){
            DeRef(_1);
        }
        _7619 = NOVALUE;
        _7616 = NOVALUE;

        /** 				pos_ += 1*/
        _pos__13870 = _pos__13870 + 1;
L9: 

        /** 		end for	*/
        _index_13899 = _index_13899 + 1;
        goto L7; // [224] 163
L8: 
        ;
    }
L6: 

    /** 	if sorted_result then*/
    if (_sorted_result_13866 == 0)
    {
        goto LA; // [232] 249
    }
    else{
    }

    /** 		return stdsort:sort(results_)*/
    RefDS(_results__13869);
    _7621 = _24sort(_results__13869, 1);
    DeRef(_the_map_p_13865);
    DeRef(_key_bucket__13867);
    DeRef(_value_bucket__13868);
    DeRefDS(_results__13869);
    DeRef(_temp_map__13871);
    _7593 = NOVALUE;
    _7607 = NOVALUE;
    return _7621;
    goto LB; // [246] 256
LA: 

    /** 		return results_*/
    DeRef(_the_map_p_13865);
    DeRef(_key_bucket__13867);
    DeRef(_value_bucket__13868);
    DeRef(_temp_map__13871);
    _7593 = NOVALUE;
    _7607 = NOVALUE;
    DeRef(_7621);
    _7621 = NOVALUE;
    return _results__13869;
LB: 
    ;
}


void _32convert_to_large_map(int _the_map__14256)
{
    int _temp_map__14257 = NOVALUE;
    int _map_handle__14258 = NOVALUE;
    int _7824 = NOVALUE;
    int _7823 = NOVALUE;
    int _7822 = NOVALUE;
    int _7821 = NOVALUE;
    int _7820 = NOVALUE;
    int _7818 = NOVALUE;
    int _7817 = NOVALUE;
    int _7816 = NOVALUE;
    int _7815 = NOVALUE;
    int _0, _1, _2;
    

    /** 	temp_map_ = eumem:ram_space[the_map_]*/
    DeRef(_temp_map__14257);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    _temp_map__14257 = (int)*(((s1_ptr)_2)->base + _the_map__14256);
    Ref(_temp_map__14257);

    /** 	map_handle_ = new()*/
    _0 = _map_handle__14258;
    _map_handle__14258 = _32new(690);
    DeRef(_0);

    /** 	for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__14257);
    _7815 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7815)){
            _7816 = SEQ_PTR(_7815)->length;
    }
    else {
        _7816 = 1;
    }
    _7815 = NOVALUE;
    {
        int _index_14262;
        _index_14262 = 1;
L1: 
        if (_index_14262 > _7816){
            goto L2; // [28] 84
        }

        /** 		if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__14257);
        _7817 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_7817);
        _7818 = (int)*(((s1_ptr)_2)->base + _index_14262);
        _7817 = NOVALUE;
        if (binary_op_a(EQUALS, _7818, 0)){
            _7818 = NOVALUE;
            goto L3; // [45] 77
        }
        _7818 = NOVALUE;

        /** 			put(map_handle_, temp_map_[KEY_LIST][index], temp_map_[VALUE_LIST][index])*/
        _2 = (int)SEQ_PTR(_temp_map__14257);
        _7820 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_7820);
        _7821 = (int)*(((s1_ptr)_2)->base + _index_14262);
        _7820 = NOVALUE;
        _2 = (int)SEQ_PTR(_temp_map__14257);
        _7822 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7822);
        _7823 = (int)*(((s1_ptr)_2)->base + _index_14262);
        _7822 = NOVALUE;
        Ref(_map_handle__14258);
        Ref(_7821);
        Ref(_7823);
        _32put(_map_handle__14258, _7821, _7823, 1, 23);
        _7821 = NOVALUE;
        _7823 = NOVALUE;
L3: 

        /** 	end for*/
        _index_14262 = _index_14262 + 1;
        goto L1; // [79] 35
L2: 
        ;
    }

    /** 	eumem:ram_space[the_map_] = eumem:ram_space[map_handle_]*/
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!IS_ATOM_INT(_map_handle__14258)){
        _7824 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_map_handle__14258)->dbl));
    }
    else{
        _7824 = (int)*(((s1_ptr)_2)->base + _map_handle__14258);
    }
    Ref(_7824);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_12249 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map__14256);
    _1 = *(int *)_2;
    *(int *)_2 = _7824;
    if( _1 != _7824 ){
        DeRef(_1);
    }
    _7824 = NOVALUE;

    /** end procedure*/
    DeRef(_temp_map__14257);
    DeRef(_map_handle__14258);
    _7815 = NOVALUE;
    return;
    ;
}


void _32convert_to_small_map(int _the_map__14276)
{
    int _keys__14277 = NOVALUE;
    int _values__14278 = NOVALUE;
    int _7833 = NOVALUE;
    int _7832 = NOVALUE;
    int _7831 = NOVALUE;
    int _7830 = NOVALUE;
    int _7829 = NOVALUE;
    int _7828 = NOVALUE;
    int _7827 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_the_map__14276)) {
        _1 = (long)(DBL_PTR(_the_map__14276)->dbl);
        DeRefDS(_the_map__14276);
        _the_map__14276 = _1;
    }

    /** 	keys_ = keys(the_map_)*/
    _0 = _keys__14277;
    _keys__14277 = _32keys(_the_map__14276, 0);
    DeRef(_0);

    /** 	values_ = values(the_map_)*/
    _0 = _values__14278;
    _values__14278 = _32values(_the_map__14276, 0, 0);
    DeRef(_0);

    /** 	eumem:ram_space[the_map_] = {*/
    _7827 = Repeat(_32init_small_map_key_12994, 23);
    _7828 = Repeat(0, 23);
    _7829 = Repeat(0, 23);
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_32type_is_map_12979);
    *((int *)(_2+4)) = _32type_is_map_12979;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 115;
    *((int *)(_2+20)) = _7827;
    *((int *)(_2+24)) = _7828;
    *((int *)(_2+28)) = _7829;
    _7830 = MAKE_SEQ(_1);
    _7829 = NOVALUE;
    _7828 = NOVALUE;
    _7827 = NOVALUE;
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_12249 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map__14276);
    _1 = *(int *)_2;
    *(int *)_2 = _7830;
    if( _1 != _7830 ){
        DeRef(_1);
    }
    _7830 = NOVALUE;

    /** 	for i = 1 to length(keys_) do*/
    if (IS_SEQUENCE(_keys__14277)){
            _7831 = SEQ_PTR(_keys__14277)->length;
    }
    else {
        _7831 = 1;
    }
    {
        int _i_14286;
        _i_14286 = 1;
L1: 
        if (_i_14286 > _7831){
            goto L2; // [63] 94
        }

        /** 		put(the_map_, keys_[i], values_[i], PUT, 0)*/
        _2 = (int)SEQ_PTR(_keys__14277);
        _7832 = (int)*(((s1_ptr)_2)->base + _i_14286);
        _2 = (int)SEQ_PTR(_values__14278);
        _7833 = (int)*(((s1_ptr)_2)->base + _i_14286);
        Ref(_7832);
        Ref(_7833);
        _32put(_the_map__14276, _7832, _7833, 1, 0);
        _7832 = NOVALUE;
        _7833 = NOVALUE;

        /** 	end for*/
        _i_14286 = _i_14286 + 1;
        goto L1; // [89] 70
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_keys__14277);
    DeRef(_values__14278);
    return;
    ;
}



// 0x25A30254
