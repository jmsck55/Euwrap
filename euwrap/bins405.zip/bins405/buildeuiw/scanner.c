// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _60set_qualified_fwd(int _fwd_23972)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fwd_23972)) {
        _1 = (long)(DBL_PTR(_fwd_23972)->dbl);
        DeRefDS(_fwd_23972);
        _fwd_23972 = _1;
    }

    /** 	qualified_fwd = fwd*/
    _60qualified_fwd_23969 = _fwd_23972;

    /** end procedure*/
    return;
    ;
}


int _60get_qualified_fwd()
{
    int _fwd_23975 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer fwd = qualified_fwd*/
    _fwd_23975 = _60qualified_fwd_23969;

    /** 	set_qualified_fwd( -1 )*/

    /** 	qualified_fwd = fwd*/
    _60qualified_fwd_23969 = -1;

    /** end procedure*/
    goto L1; // [17] 20
L1: 

    /** 	return fwd*/
    return _fwd_23975;
    ;
}


void _60InitLex()
{
    int _13791 = NOVALUE;
    int _13790 = NOVALUE;
    int _13789 = NOVALUE;
    int _13787 = NOVALUE;
    int _13786 = NOVALUE;
    int _13785 = NOVALUE;
    int _13784 = NOVALUE;
    int _0, _1, _2;
    

    /** 	gline_number = 0*/
    _26gline_number_11987 = 0;

    /** 	line_number = 0*/
    _26line_number_11983 = 0;

    /** 	IncludeStk = {}*/
    RefDS(_5);
    DeRef(_60IncludeStk_23946);
    _60IncludeStk_23946 = _5;

    /** 	char_class = repeat(ILLEGAL_CHAR, 255)  -- we screen out the 0 character*/
    DeRefi(_60char_class_23944);
    _60char_class_23944 = Repeat(-20, 255);

    /** 	char_class['0'..'9'] = DIGIT*/
    assign_slice_seq = (s1_ptr *)&_60char_class_23944;
    AssignSlice(48, 57, -7);

    /** 	char_class['_']      = DIGIT*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 95);
    *(int *)_2 = -7;

    /** 	char_class['a'..'z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_60char_class_23944;
    AssignSlice(97, 122, -2);

    /** 	char_class['A'..'Z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_60char_class_23944;
    AssignSlice(65, 90, -2);

    /** 	char_class[KEYWORD_BASE+1..KEYWORD_BASE+NUM_KEYWORDS] = KEYWORD*/
    _13784 = 129;
    _13785 = 152;
    assign_slice_seq = (s1_ptr *)&_60char_class_23944;
    AssignSlice(129, 152, -10);
    _13784 = NOVALUE;
    _13785 = NOVALUE;

    /** 	char_class[BUILTIN_BASE+1..BUILTIN_BASE+NUM_BUILTINS] = BUILTIN*/
    _13786 = 171;
    _13787 = 234;
    assign_slice_seq = (s1_ptr *)&_60char_class_23944;
    AssignSlice(171, 234, -9);
    _13786 = NOVALUE;
    _13787 = NOVALUE;

    /** 	char_class[' '] = BLANK*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 32);
    *(int *)_2 = -8;

    /** 	char_class['\t'] = BLANK*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 9);
    *(int *)_2 = -8;

    /** 	char_class['+'] = PLUS*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 43);
    *(int *)_2 = 11;

    /** 	char_class['-'] = MINUS*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 45);
    *(int *)_2 = 10;

    /** 	char_class['*'] = res:MULTIPLY*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 42);
    *(int *)_2 = 13;

    /** 	char_class['/'] = res:DIVIDE*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 47);
    *(int *)_2 = 14;

    /** 	char_class['='] = EQUALS*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 61);
    *(int *)_2 = 3;

    /** 	char_class['<'] = LESS*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 60);
    *(int *)_2 = 1;

    /** 	char_class['>'] = GREATER*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 62);
    *(int *)_2 = 6;

    /** 	char_class['\''] = SINGLE_QUOTE*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 39);
    *(int *)_2 = -5;

    /** 	char_class['"'] = DOUBLE_QUOTE*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 34);
    *(int *)_2 = -4;

    /** 	char_class['`'] = BACK_QUOTE*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 96);
    *(int *)_2 = -12;

    /** 	char_class['.'] = DOT*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 46);
    *(int *)_2 = -3;

    /** 	char_class[':'] = COLON*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 58);
    *(int *)_2 = -23;

    /** 	char_class['\r'] = NEWLINE*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 13);
    *(int *)_2 = -6;

    /** 	char_class['\n'] = NEWLINE*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 10);
    *(int *)_2 = -6;

    /** 	char_class['!'] = BANG*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 33);
    *(int *)_2 = -1;

    /** 	char_class['{'] = LEFT_BRACE*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 123);
    *(int *)_2 = -24;

    /** 	char_class['}'] = RIGHT_BRACE*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 125);
    *(int *)_2 = -25;

    /** 	char_class['('] = LEFT_ROUND*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 40);
    *(int *)_2 = -26;

    /** 	char_class[')'] = RIGHT_ROUND*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 41);
    *(int *)_2 = -27;

    /** 	char_class['['] = LEFT_SQUARE*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 91);
    *(int *)_2 = -28;

    /** 	char_class[']'] = RIGHT_SQUARE*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 93);
    *(int *)_2 = -29;

    /** 	char_class['$'] = DOLLAR*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 36);
    *(int *)_2 = -22;

    /** 	char_class[','] = COMMA*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 44);
    *(int *)_2 = -30;

    /** 	char_class['&'] = res:CONCAT*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 38);
    *(int *)_2 = 15;

    /** 	char_class['?'] = QUESTION_MARK*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 63);
    *(int *)_2 = -31;

    /** 	char_class['#'] = NUMBER_SIGN*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 35);
    *(int *)_2 = -11;

    /** 	char_class[END_OF_FILE_CHAR] = END_OF_FILE*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _2 = (int)(((s1_ptr)_2)->base + 26);
    *(int *)_2 = -21;

    /** 	id_char = repeat(FALSE, 255)*/
    DeRefi(_60id_char_23945);
    _60id_char_23945 = Repeat(_9FALSE_428, 255);

    /** 	for i = 1 to 255 do*/
    {
        int _i_24023;
        _i_24023 = 1;
L1: 
        if (_i_24023 > 255){
            goto L2; // [407] 456
        }

        /** 		if find(char_class[i], {LETTER, DIGIT}) then*/
        _2 = (int)SEQ_PTR(_60char_class_23944);
        _13789 = (int)*(((s1_ptr)_2)->base + _i_24023);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -2;
        ((int *)_2)[2] = -7;
        _13790 = MAKE_SEQ(_1);
        _13791 = find_from(_13789, _13790, 1);
        _13789 = NOVALUE;
        DeRefDS(_13790);
        _13790 = NOVALUE;
        if (_13791 == 0)
        {
            _13791 = NOVALUE;
            goto L3; // [435] 449
        }
        else{
            _13791 = NOVALUE;
        }

        /** 			id_char[i] = TRUE*/
        _2 = (int)SEQ_PTR(_60id_char_23945);
        _2 = (int)(((s1_ptr)_2)->base + _i_24023);
        *(int *)_2 = _9TRUE_430;
L3: 

        /** 	end for*/
        _i_24023 = _i_24023 + 1;
        goto L1; // [451] 414
L2: 
        ;
    }

    /** 	default_namespaces = {0}*/
    _0 = _60default_namespaces_23943;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    _60default_namespaces_23943 = MAKE_SEQ(_1);
    DeRef(_0);

    /** end procedure*/
    return;
    ;
}


void _60ResetTP()
{
    int _0, _1, _2;
    

    /** 	OpTrace = FALSE*/
    _26OpTrace_12052 = _9FALSE_428;

    /** 	OpProfileStatement = FALSE*/
    _26OpProfileStatement_12054 = _9FALSE_428;

    /** 	OpProfileTime = FALSE*/
    _26OpProfileTime_12055 = _9FALSE_428;

    /** 	AnyStatementProfile = FALSE*/
    _27AnyStatementProfile_10946 = _9FALSE_428;

    /** 	AnyTimeProfile = FALSE*/
    _27AnyTimeProfile_10945 = _9FALSE_428;

    /** end procedure*/
    return;
    ;
}


int _60pack_source(int _src_24053)
{
    int _start_24054 = NOVALUE;
    int _13815 = NOVALUE;
    int _13814 = NOVALUE;
    int _13813 = NOVALUE;
    int _13812 = NOVALUE;
    int _13810 = NOVALUE;
    int _13808 = NOVALUE;
    int _13807 = NOVALUE;
    int _13806 = NOVALUE;
    int _13802 = NOVALUE;
    int _13800 = NOVALUE;
    int _13799 = NOVALUE;
    int _13796 = NOVALUE;
    int _13795 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if equal(src, 0) then*/
    if (_src_24053 == 0)
    _13795 = 1;
    else if (IS_ATOM_INT(_src_24053) && IS_ATOM_INT(0))
    _13795 = 0;
    else
    _13795 = (compare(_src_24053, 0) == 0);
    if (_13795 == 0)
    {
        _13795 = NOVALUE;
        goto L1; // [7] 17
    }
    else{
        _13795 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_src_24053);
    return 0;
L1: 

    /** 	if length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_24053)){
            _13796 = SEQ_PTR(_src_24053)->length;
    }
    else {
        _13796 = 1;
    }
    if (_13796 < 10000)
    goto L2; // [22] 34

    /** 		src = src[1..100] -- enough for trace or profile display*/
    rhs_slice_target = (object_ptr)&_src_24053;
    RHS_Slice(_src_24053, 1, 100);
L2: 

    /** 	if current_source_next + length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_24053)){
            _13799 = SEQ_PTR(_src_24053)->length;
    }
    else {
        _13799 = 1;
    }
    _13800 = _60current_source_next_24049 + _13799;
    if ((long)((unsigned long)_13800 + (unsigned long)HIGH_BITS) >= 0) 
    _13800 = NewDouble((double)_13800);
    _13799 = NOVALUE;
    if (binary_op_a(LESS, _13800, 10000)){
        DeRef(_13800);
        _13800 = NOVALUE;
        goto L3; // [45] 94
    }
    DeRef(_13800);
    _13800 = NOVALUE;

    /** 		current_source = allocate(SOURCE_CHUNK + LINE_BUFLEN)*/
    _13802 = 10400;
    _0 = _6allocate(10400, 0);
    DeRef(_60current_source_24048);
    _60current_source_24048 = _0;
    _13802 = NOVALUE;

    /** 		if current_source = 0 then*/
    if (binary_op_a(NOTEQ, _60current_source_24048, 0)){
        goto L4; // [64] 76
    }

    /** 			CompileErr(123)*/
    RefDS(_22037);
    _43CompileErr(123, _22037, 0);
L4: 

    /** 		all_source = append(all_source, current_source)*/
    Ref(_60current_source_24048);
    Append(&_27all_source_10947, _27all_source_10947, _60current_source_24048);

    /** 		current_source_next = 1*/
    _60current_source_next_24049 = 1;
L3: 

    /** 	start = current_source_next*/
    _start_24054 = _60current_source_next_24049;

    /** 	poke(current_source+current_source_next, src)*/
    if (IS_ATOM_INT(_60current_source_24048)) {
        _13806 = _60current_source_24048 + _60current_source_next_24049;
        if ((long)((unsigned long)_13806 + (unsigned long)HIGH_BITS) >= 0) 
        _13806 = NewDouble((double)_13806);
    }
    else {
        _13806 = NewDouble(DBL_PTR(_60current_source_24048)->dbl + (double)_60current_source_next_24049);
    }
    if (IS_ATOM_INT(_13806)){
        poke_addr = (unsigned char *)_13806;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_13806)->dbl);
    }
    if (IS_ATOM_INT(_src_24053)) {
        *poke_addr = (unsigned char)_src_24053;
    }
    else if (IS_ATOM(_src_24053)) {
        *poke_addr = (signed char)DBL_PTR(_src_24053)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_src_24053);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_13806);
    _13806 = NOVALUE;

    /** 	current_source_next += length(src)-1*/
    if (IS_SEQUENCE(_src_24053)){
            _13807 = SEQ_PTR(_src_24053)->length;
    }
    else {
        _13807 = 1;
    }
    _13808 = _13807 - 1;
    _13807 = NOVALUE;
    _60current_source_next_24049 = _60current_source_next_24049 + _13808;
    _13808 = NOVALUE;

    /** 	poke(current_source+current_source_next, 0) -- overwrite \n*/
    if (IS_ATOM_INT(_60current_source_24048)) {
        _13810 = _60current_source_24048 + _60current_source_next_24049;
        if ((long)((unsigned long)_13810 + (unsigned long)HIGH_BITS) >= 0) 
        _13810 = NewDouble((double)_13810);
    }
    else {
        _13810 = NewDouble(DBL_PTR(_60current_source_24048)->dbl + (double)_60current_source_next_24049);
    }
    if (IS_ATOM_INT(_13810)){
        poke_addr = (unsigned char *)_13810;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_13810)->dbl);
    }
    *poke_addr = (unsigned char)0;
    DeRef(_13810);
    _13810 = NOVALUE;

    /** 	current_source_next += 1*/
    _60current_source_next_24049 = _60current_source_next_24049 + 1;

    /** 	return start + SOURCE_CHUNK * (length(all_source)-1)*/
    if (IS_SEQUENCE(_27all_source_10947)){
            _13812 = SEQ_PTR(_27all_source_10947)->length;
    }
    else {
        _13812 = 1;
    }
    _13813 = _13812 - 1;
    _13812 = NOVALUE;
    if (_13813 <= INT15)
    _13814 = 10000 * _13813;
    else
    _13814 = NewDouble(10000 * (double)_13813);
    _13813 = NOVALUE;
    if (IS_ATOM_INT(_13814)) {
        _13815 = _start_24054 + _13814;
        if ((long)((unsigned long)_13815 + (unsigned long)HIGH_BITS) >= 0) 
        _13815 = NewDouble((double)_13815);
    }
    else {
        _13815 = NewDouble((double)_start_24054 + DBL_PTR(_13814)->dbl);
    }
    DeRef(_13814);
    _13814 = NOVALUE;
    DeRef(_src_24053);
    return _13815;
    ;
}


int _60fetch_line(int _start_24087)
{
    int _line_24088 = NOVALUE;
    int _memdata_24089 = NOVALUE;
    int _c_24090 = NOVALUE;
    int _chunk_24091 = NOVALUE;
    int _p_24092 = NOVALUE;
    int _n_24093 = NOVALUE;
    int _m_24094 = NOVALUE;
    int _13840 = NOVALUE;
    int _13839 = NOVALUE;
    int _13837 = NOVALUE;
    int _13835 = NOVALUE;
    int _13829 = NOVALUE;
    int _13827 = NOVALUE;
    int _13823 = NOVALUE;
    int _13821 = NOVALUE;
    int _13818 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_24087)) {
        _1 = (long)(DBL_PTR(_start_24087)->dbl);
        DeRefDS(_start_24087);
        _start_24087 = _1;
    }

    /** 	if start = 0 then*/
    if (_start_24087 != 0)
    goto L1; // [5] 16

    /** 		return ""*/
    RefDS(_5);
    DeRef(_line_24088);
    DeRefi(_memdata_24089);
    DeRef(_p_24092);
    return _5;
L1: 

    /** 	line = repeat(0, LINE_BUFLEN)*/
    DeRef(_line_24088);
    _line_24088 = Repeat(0, 400);

    /** 	n = 0*/
    _n_24093 = 0;

    /** 	chunk = 1+floor(start / SOURCE_CHUNK)*/
    if (10000 > 0 && _start_24087 >= 0) {
        _13818 = _start_24087 / 10000;
    }
    else {
        temp_dbl = floor((double)_start_24087 / (double)10000);
        _13818 = (long)temp_dbl;
    }
    _chunk_24091 = _13818 + 1;
    _13818 = NOVALUE;

    /** 	start = remainder(start, SOURCE_CHUNK)*/
    _start_24087 = (_start_24087 % 10000);

    /** 	p = all_source[chunk] + start*/
    _2 = (int)SEQ_PTR(_27all_source_10947);
    _13821 = (int)*(((s1_ptr)_2)->base + _chunk_24091);
    DeRef(_p_24092);
    if (IS_ATOM_INT(_13821)) {
        _p_24092 = _13821 + _start_24087;
        if ((long)((unsigned long)_p_24092 + (unsigned long)HIGH_BITS) >= 0) 
        _p_24092 = NewDouble((double)_p_24092);
    }
    else {
        _p_24092 = NewDouble(DBL_PTR(_13821)->dbl + (double)_start_24087);
    }
    _13821 = NOVALUE;

    /** 	memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_24092);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _p_24092;
    ((int *)_2)[2] = 400;
    _13823 = MAKE_SEQ(_1);
    DeRefi(_memdata_24089);
    _1 = (int)SEQ_PTR(_13823);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _memdata_24089 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13823);
    _13823 = NOVALUE;

    /** 	p += LINE_BUFLEN*/
    _0 = _p_24092;
    if (IS_ATOM_INT(_p_24092)) {
        _p_24092 = _p_24092 + 400;
        if ((long)((unsigned long)_p_24092 + (unsigned long)HIGH_BITS) >= 0) 
        _p_24092 = NewDouble((double)_p_24092);
    }
    else {
        _p_24092 = NewDouble(DBL_PTR(_p_24092)->dbl + (double)400);
    }
    DeRef(_0);

    /** 	m = 0*/
    _m_24094 = 0;

    /** 	while TRUE do*/
L2: 
    if (_9TRUE_430 == 0)
    {
        goto L3; // [84] 179
    }
    else{
    }

    /** 		m += 1*/
    _m_24094 = _m_24094 + 1;

    /** 		if m > length(memdata) then*/
    if (IS_SEQUENCE(_memdata_24089)){
            _13827 = SEQ_PTR(_memdata_24089)->length;
    }
    else {
        _13827 = 1;
    }
    if (_m_24094 <= _13827)
    goto L4; // [98] 125

    /** 			memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_24092);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _p_24092;
    ((int *)_2)[2] = 400;
    _13829 = MAKE_SEQ(_1);
    DeRefDSi(_memdata_24089);
    _1 = (int)SEQ_PTR(_13829);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _memdata_24089 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13829);
    _13829 = NOVALUE;

    /** 			p += LINE_BUFLEN*/
    _0 = _p_24092;
    if (IS_ATOM_INT(_p_24092)) {
        _p_24092 = _p_24092 + 400;
        if ((long)((unsigned long)_p_24092 + (unsigned long)HIGH_BITS) >= 0) 
        _p_24092 = NewDouble((double)_p_24092);
    }
    else {
        _p_24092 = NewDouble(DBL_PTR(_p_24092)->dbl + (double)400);
    }
    DeRef(_0);

    /** 			m = 1*/
    _m_24094 = 1;
L4: 

    /** 		c = memdata[m]*/
    _2 = (int)SEQ_PTR(_memdata_24089);
    _c_24090 = (int)*(((s1_ptr)_2)->base + _m_24094);

    /** 		if c = 0 then*/
    if (_c_24090 != 0)
    goto L5; // [133] 142

    /** 			exit*/
    goto L3; // [139] 179
L5: 

    /** 		n += 1*/
    _n_24093 = _n_24093 + 1;

    /** 		if n > length(line) then*/
    if (IS_SEQUENCE(_line_24088)){
            _13835 = SEQ_PTR(_line_24088)->length;
    }
    else {
        _13835 = 1;
    }
    if (_n_24093 <= _13835)
    goto L6; // [153] 168

    /** 			line &= repeat(0, LINE_BUFLEN)*/
    _13837 = Repeat(0, 400);
    Concat((object_ptr)&_line_24088, _line_24088, _13837);
    DeRefDS(_13837);
    _13837 = NOVALUE;
L6: 

    /** 		line[n] = c*/
    _2 = (int)SEQ_PTR(_line_24088);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _line_24088 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_24093);
    _1 = *(int *)_2;
    *(int *)_2 = _c_24090;
    DeRef(_1);

    /** 	end while*/
    goto L2; // [176] 82
L3: 

    /** 	line = remove( line, n+1, length( line ) )*/
    _13839 = _n_24093 + 1;
    if (_13839 > MAXINT){
        _13839 = NewDouble((double)_13839);
    }
    if (IS_SEQUENCE(_line_24088)){
            _13840 = SEQ_PTR(_line_24088)->length;
    }
    else {
        _13840 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_line_24088);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_13839)) ? _13839 : (long)(DBL_PTR(_13839)->dbl);
        int stop = (IS_ATOM_INT(_13840)) ? _13840 : (long)(DBL_PTR(_13840)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_line_24088), start, &_line_24088 );
            }
            else Tail(SEQ_PTR(_line_24088), stop+1, &_line_24088);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_line_24088), start, &_line_24088);
        }
        else {
            assign_slice_seq = &assign_space;
            _line_24088 = Remove_elements(start, stop, (SEQ_PTR(_line_24088)->ref == 1));
        }
    }
    DeRef(_13839);
    _13839 = NOVALUE;
    _13840 = NOVALUE;

    /** 	return line*/
    DeRefi(_memdata_24089);
    DeRef(_p_24092);
    return _line_24088;
    ;
}


void _60AppendSourceLine()
{
    int _new_24130 = NOVALUE;
    int _old_24131 = NOVALUE;
    int _options_24132 = NOVALUE;
    int _src_24133 = NOVALUE;
    int _13881 = NOVALUE;
    int _13877 = NOVALUE;
    int _13875 = NOVALUE;
    int _13874 = NOVALUE;
    int _13871 = NOVALUE;
    int _13870 = NOVALUE;
    int _13869 = NOVALUE;
    int _13868 = NOVALUE;
    int _13867 = NOVALUE;
    int _13866 = NOVALUE;
    int _13865 = NOVALUE;
    int _13864 = NOVALUE;
    int _13863 = NOVALUE;
    int _13862 = NOVALUE;
    int _13861 = NOVALUE;
    int _13860 = NOVALUE;
    int _13859 = NOVALUE;
    int _13858 = NOVALUE;
    int _13857 = NOVALUE;
    int _13856 = NOVALUE;
    int _13855 = NOVALUE;
    int _13854 = NOVALUE;
    int _13852 = NOVALUE;
    int _13851 = NOVALUE;
    int _13850 = NOVALUE;
    int _13848 = NOVALUE;
    int _13843 = NOVALUE;
    int _13842 = NOVALUE;
    int _0, _1, _2;
    

    /** 	src = 0*/
    DeRef(_src_24133);
    _src_24133 = 0;

    /** 	options = 0*/
    _options_24132 = 0;

    /** 	if TRANSLATE or OpTrace or OpProfileStatement or OpProfileTime then*/
    if (_26TRANSLATE_11619 != 0) {
        _13842 = 1;
        goto L1; // [15] 25
    }
    _13842 = (_26OpTrace_12052 != 0);
L1: 
    if (_13842 != 0) {
        _13843 = 1;
        goto L2; // [25] 35
    }
    _13843 = (_26OpProfileStatement_12054 != 0);
L2: 
    if (_13843 != 0) {
        goto L3; // [35] 46
    }
    if (_26OpProfileTime_12055 == 0)
    {
        goto L4; // [42] 136
    }
    else{
    }
L3: 

    /** 		src = ThisLine*/
    Ref(_43ThisLine_48557);
    DeRef(_src_24133);
    _src_24133 = _43ThisLine_48557;

    /** 		if OpTrace then*/
    if (_26OpTrace_12052 == 0)
    {
        goto L5; // [57] 70
    }
    else{
    }

    /** 			options = SOP_TRACE*/
    _options_24132 = 1;
L5: 

    /** 		if OpProfileTime then*/
    if (_26OpProfileTime_12055 == 0)
    {
        goto L6; // [74] 88
    }
    else{
    }

    /** 			options = or_bits(options, SOP_PROFILE_TIME)*/
    {unsigned long tu;
         tu = (unsigned long)_options_24132 | (unsigned long)2;
         _options_24132 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_24132)) {
        _1 = (long)(DBL_PTR(_options_24132)->dbl);
        DeRefDS(_options_24132);
        _options_24132 = _1;
    }
L6: 

    /** 		if OpProfileStatement then*/
    if (_26OpProfileStatement_12054 == 0)
    {
        goto L7; // [92] 106
    }
    else{
    }

    /** 			options = or_bits(options, SOP_PROFILE_STATEMENT)*/
    {unsigned long tu;
         tu = (unsigned long)_options_24132 | (unsigned long)4;
         _options_24132 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_24132)) {
        _1 = (long)(DBL_PTR(_options_24132)->dbl);
        DeRefDS(_options_24132);
        _options_24132 = _1;
    }
L7: 

    /** 		if OpProfileStatement or OpProfileTime then*/
    if (_26OpProfileStatement_12054 != 0) {
        goto L8; // [110] 121
    }
    if (_26OpProfileTime_12055 == 0)
    {
        goto L9; // [117] 135
    }
    else{
    }
L8: 

    /** 			src = {0,0,0,0} & src*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _13848 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_13848) && IS_ATOM(_src_24133)) {
        Ref(_src_24133);
        Append(&_src_24133, _13848, _src_24133);
    }
    else if (IS_ATOM(_13848) && IS_SEQUENCE(_src_24133)) {
    }
    else {
        Concat((object_ptr)&_src_24133, _13848, _src_24133);
        DeRefDS(_13848);
        _13848 = NOVALUE;
    }
    DeRef(_13848);
    _13848 = NOVALUE;
L9: 
L4: 

    /** 	if length(slist) then*/
    if (IS_SEQUENCE(_26slist_12073)){
            _13850 = SEQ_PTR(_26slist_12073)->length;
    }
    else {
        _13850 = 1;
    }
    if (_13850 == 0)
    {
        _13850 = NOVALUE;
        goto LA; // [143] 345
    }
    else{
        _13850 = NOVALUE;
    }

    /** 		old = slist[$-1]*/
    if (IS_SEQUENCE(_26slist_12073)){
            _13851 = SEQ_PTR(_26slist_12073)->length;
    }
    else {
        _13851 = 1;
    }
    _13852 = _13851 - 1;
    _13851 = NOVALUE;
    DeRef(_old_24131);
    _2 = (int)SEQ_PTR(_26slist_12073);
    _old_24131 = (int)*(((s1_ptr)_2)->base + _13852);
    Ref(_old_24131);

    /** 		if equal(src, old[SRC]) and*/
    _2 = (int)SEQ_PTR(_old_24131);
    _13854 = (int)*(((s1_ptr)_2)->base + 1);
    if (_src_24133 == _13854)
    _13855 = 1;
    else if (IS_ATOM_INT(_src_24133) && IS_ATOM_INT(_13854))
    _13855 = 0;
    else
    _13855 = (compare(_src_24133, _13854) == 0);
    _13854 = NOVALUE;
    if (_13855 == 0) {
        _13856 = 0;
        goto LB; // [175] 195
    }
    _2 = (int)SEQ_PTR(_old_24131);
    _13857 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_13857)) {
        _13858 = (_26current_file_no_11982 == _13857);
    }
    else {
        _13858 = binary_op(EQUALS, _26current_file_no_11982, _13857);
    }
    _13857 = NOVALUE;
    if (IS_ATOM_INT(_13858))
    _13856 = (_13858 != 0);
    else
    _13856 = DBL_PTR(_13858)->dbl != 0.0;
LB: 
    if (_13856 == 0) {
        _13859 = 0;
        goto LC; // [195] 232
    }
    _2 = (int)SEQ_PTR(_old_24131);
    _13860 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_13860)) {
        _13861 = _13860 + 1;
        if (_13861 > MAXINT){
            _13861 = NewDouble((double)_13861);
        }
    }
    else
    _13861 = binary_op(PLUS, 1, _13860);
    _13860 = NOVALUE;
    if (IS_SEQUENCE(_26slist_12073)){
            _13862 = SEQ_PTR(_26slist_12073)->length;
    }
    else {
        _13862 = 1;
    }
    _2 = (int)SEQ_PTR(_26slist_12073);
    _13863 = (int)*(((s1_ptr)_2)->base + _13862);
    if (IS_ATOM_INT(_13861) && IS_ATOM_INT(_13863)) {
        _13864 = _13861 + _13863;
        if ((long)((unsigned long)_13864 + (unsigned long)HIGH_BITS) >= 0) 
        _13864 = NewDouble((double)_13864);
    }
    else {
        _13864 = binary_op(PLUS, _13861, _13863);
    }
    DeRef(_13861);
    _13861 = NOVALUE;
    _13863 = NOVALUE;
    if (IS_ATOM_INT(_13864)) {
        _13865 = (_26line_number_11983 == _13864);
    }
    else {
        _13865 = binary_op(EQUALS, _26line_number_11983, _13864);
    }
    DeRef(_13864);
    _13864 = NOVALUE;
    if (IS_ATOM_INT(_13865))
    _13859 = (_13865 != 0);
    else
    _13859 = DBL_PTR(_13865)->dbl != 0.0;
LC: 
    if (_13859 == 0) {
        goto LD; // [232] 272
    }
    _2 = (int)SEQ_PTR(_old_24131);
    _13867 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_13867)) {
        _13868 = (_options_24132 == _13867);
    }
    else {
        _13868 = binary_op(EQUALS, _options_24132, _13867);
    }
    _13867 = NOVALUE;
    if (_13868 == 0) {
        DeRef(_13868);
        _13868 = NOVALUE;
        goto LD; // [247] 272
    }
    else {
        if (!IS_ATOM_INT(_13868) && DBL_PTR(_13868)->dbl == 0.0){
            DeRef(_13868);
            _13868 = NOVALUE;
            goto LD; // [247] 272
        }
        DeRef(_13868);
        _13868 = NOVALUE;
    }
    DeRef(_13868);
    _13868 = NOVALUE;

    /** 			slist[$] += 1*/
    if (IS_SEQUENCE(_26slist_12073)){
            _13869 = SEQ_PTR(_26slist_12073)->length;
    }
    else {
        _13869 = 1;
    }
    _2 = (int)SEQ_PTR(_26slist_12073);
    _13870 = (int)*(((s1_ptr)_2)->base + _13869);
    if (IS_ATOM_INT(_13870)) {
        _13871 = _13870 + 1;
        if (_13871 > MAXINT){
            _13871 = NewDouble((double)_13871);
        }
    }
    else
    _13871 = binary_op(PLUS, 1, _13870);
    _13870 = NOVALUE;
    _2 = (int)SEQ_PTR(_26slist_12073);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26slist_12073 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13869);
    _1 = *(int *)_2;
    *(int *)_2 = _13871;
    if( _1 != _13871 ){
        DeRef(_1);
    }
    _13871 = NOVALUE;
    goto LE; // [269] 371
LD: 

    /** 			src = pack_source(src)*/
    Ref(_src_24133);
    _0 = _src_24133;
    _src_24133 = _60pack_source(_src_24133);
    DeRef(_0);

    /** 			new = {src, line_number, current_file_no, options}*/
    _0 = _new_24130;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_src_24133);
    *((int *)(_2+4)) = _src_24133;
    *((int *)(_2+8)) = _26line_number_11983;
    *((int *)(_2+12)) = _26current_file_no_11982;
    *((int *)(_2+16)) = _options_24132;
    _new_24130 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 			if slist[$] = 0 then*/
    if (IS_SEQUENCE(_26slist_12073)){
            _13874 = SEQ_PTR(_26slist_12073)->length;
    }
    else {
        _13874 = 1;
    }
    _2 = (int)SEQ_PTR(_26slist_12073);
    _13875 = (int)*(((s1_ptr)_2)->base + _13874);
    if (binary_op_a(NOTEQ, _13875, 0)){
        _13875 = NOVALUE;
        goto LF; // [302] 320
    }
    _13875 = NOVALUE;

    /** 				slist[$] = new*/
    if (IS_SEQUENCE(_26slist_12073)){
            _13877 = SEQ_PTR(_26slist_12073)->length;
    }
    else {
        _13877 = 1;
    }
    RefDS(_new_24130);
    _2 = (int)SEQ_PTR(_26slist_12073);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26slist_12073 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13877);
    _1 = *(int *)_2;
    *(int *)_2 = _new_24130;
    DeRef(_1);
    goto L10; // [317] 331
LF: 

    /** 				slist = append(slist, new)*/
    RefDS(_new_24130);
    Append(&_26slist_12073, _26slist_12073, _new_24130);
L10: 

    /** 			slist = append(slist, 0)*/
    Append(&_26slist_12073, _26slist_12073, 0);
    goto LE; // [342] 371
LA: 

    /** 		src = pack_source(src)*/
    Ref(_src_24133);
    _0 = _src_24133;
    _src_24133 = _60pack_source(_src_24133);
    DeRef(_0);

    /** 		slist = {{src, line_number, current_file_no, options}, 0}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_src_24133);
    *((int *)(_2+4)) = _src_24133;
    *((int *)(_2+8)) = _26line_number_11983;
    *((int *)(_2+12)) = _26current_file_no_11982;
    *((int *)(_2+16)) = _options_24132;
    _13881 = MAKE_SEQ(_1);
    DeRef(_26slist_12073);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _13881;
    ((int *)_2)[2] = 0;
    _26slist_12073 = MAKE_SEQ(_1);
    _13881 = NOVALUE;
LE: 

    /** end procedure*/
    DeRef(_new_24130);
    DeRef(_old_24131);
    DeRef(_src_24133);
    DeRef(_13852);
    _13852 = NOVALUE;
    DeRef(_13865);
    _13865 = NOVALUE;
    DeRef(_13858);
    _13858 = NOVALUE;
    return;
    ;
}


int _60s_expand(int _slist_24222)
{
    int _new_slist_24223 = NOVALUE;
    int _13895 = NOVALUE;
    int _13894 = NOVALUE;
    int _13893 = NOVALUE;
    int _13892 = NOVALUE;
    int _13890 = NOVALUE;
    int _13889 = NOVALUE;
    int _13888 = NOVALUE;
    int _13886 = NOVALUE;
    int _13885 = NOVALUE;
    int _13884 = NOVALUE;
    int _13883 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	new_slist = {}*/
    RefDS(_5);
    DeRef(_new_slist_24223);
    _new_slist_24223 = _5;

    /** 	for i = 1 to length(slist) do*/
    if (IS_SEQUENCE(_slist_24222)){
            _13883 = SEQ_PTR(_slist_24222)->length;
    }
    else {
        _13883 = 1;
    }
    {
        int _i_24225;
        _i_24225 = 1;
L1: 
        if (_i_24225 > _13883){
            goto L2; // [15] 114
        }

        /** 		if sequence(slist[i]) then*/
        _2 = (int)SEQ_PTR(_slist_24222);
        _13884 = (int)*(((s1_ptr)_2)->base + _i_24225);
        _13885 = IS_SEQUENCE(_13884);
        _13884 = NOVALUE;
        if (_13885 == 0)
        {
            _13885 = NOVALUE;
            goto L3; // [31] 47
        }
        else{
            _13885 = NOVALUE;
        }

        /** 			new_slist = append(new_slist, slist[i])*/
        _2 = (int)SEQ_PTR(_slist_24222);
        _13886 = (int)*(((s1_ptr)_2)->base + _i_24225);
        Ref(_13886);
        Append(&_new_slist_24223, _new_slist_24223, _13886);
        _13886 = NOVALUE;
        goto L4; // [44] 107
L3: 

        /** 			for j = 1 to slist[i] do*/
        _2 = (int)SEQ_PTR(_slist_24222);
        _13888 = (int)*(((s1_ptr)_2)->base + _i_24225);
        {
            int _j_24234;
            _j_24234 = 1;
L5: 
            if (binary_op_a(GREATER, _j_24234, _13888)){
                goto L6; // [53] 106
            }

            /** 				slist[i-1][LINE] += 1*/
            _13889 = _i_24225 - 1;
            _2 = (int)SEQ_PTR(_slist_24222);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _slist_24222 = MAKE_SEQ(_2);
            }
            _3 = (int)(_13889 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(*(int *)_3);
            _13892 = (int)*(((s1_ptr)_2)->base + 2);
            _13890 = NOVALUE;
            if (IS_ATOM_INT(_13892)) {
                _13893 = _13892 + 1;
                if (_13893 > MAXINT){
                    _13893 = NewDouble((double)_13893);
                }
            }
            else
            _13893 = binary_op(PLUS, 1, _13892);
            _13892 = NOVALUE;
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 2);
            _1 = *(int *)_2;
            *(int *)_2 = _13893;
            if( _1 != _13893 ){
                DeRef(_1);
            }
            _13893 = NOVALUE;
            _13890 = NOVALUE;

            /** 				new_slist = append(new_slist, slist[i-1])*/
            _13894 = _i_24225 - 1;
            _2 = (int)SEQ_PTR(_slist_24222);
            _13895 = (int)*(((s1_ptr)_2)->base + _13894);
            Ref(_13895);
            Append(&_new_slist_24223, _new_slist_24223, _13895);
            _13895 = NOVALUE;

            /** 			end for*/
            _0 = _j_24234;
            if (IS_ATOM_INT(_j_24234)) {
                _j_24234 = _j_24234 + 1;
                if ((long)((unsigned long)_j_24234 +(unsigned long) HIGH_BITS) >= 0){
                    _j_24234 = NewDouble((double)_j_24234);
                }
            }
            else {
                _j_24234 = binary_op_a(PLUS, _j_24234, 1);
            }
            DeRef(_0);
            goto L5; // [101] 60
L6: 
            ;
            DeRef(_j_24234);
        }
L4: 

        /** 	end for*/
        _i_24225 = _i_24225 + 1;
        goto L1; // [109] 22
L2: 
        ;
    }

    /** 	return new_slist*/
    DeRefDS(_slist_24222);
    _13888 = NOVALUE;
    DeRef(_13889);
    _13889 = NOVALUE;
    DeRef(_13894);
    _13894 = NOVALUE;
    return _new_slist_24223;
    ;
}


void _60set_dont_read(int _read_24249)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_read_24249)) {
        _1 = (long)(DBL_PTR(_read_24249)->dbl);
        DeRefDS(_read_24249);
        _read_24249 = _1;
    }

    /** 	dont_read = read*/
    _60dont_read_24246 = _read_24249;

    /** end procedure*/
    return;
    ;
}


void _60read_line()
{
    int _n_24252 = NOVALUE;
    int _13909 = NOVALUE;
    int _13908 = NOVALUE;
    int _13906 = NOVALUE;
    int _13905 = NOVALUE;
    int _13903 = NOVALUE;
    int _13902 = NOVALUE;
    int _0, _1, _2;
    

    /** 	line_number += 1*/
    _26line_number_11983 = _26line_number_11983 + 1;

    /** 	gline_number += 1*/
    _26gline_number_11987 = _26gline_number_11987 + 1;

    /** 	if dont_read then*/
    if (_60dont_read_24246 == 0)
    {
        goto L1; // [25] 36
    }
    else{
    }

    /** 		ThisLine = -1*/
    DeRef(_43ThisLine_48557);
    _43ThisLine_48557 = -1;
    goto L2; // [33] 108
L1: 

    /** 	elsif src_file < 0 then*/
    if (_26src_file_12104 >= 0)
    goto L3; // [40] 52

    /** 		ThisLine = -1*/
    DeRef(_43ThisLine_48557);
    _43ThisLine_48557 = -1;
    goto L2; // [49] 108
L3: 

    /** 		ThisLine = gets(src_file)*/
    DeRef(_43ThisLine_48557);
    _43ThisLine_48557 = EGets(_26src_file_12104);

    /** 		if sequence(ThisLine) and ends( {13,10}, ThisLine ) then*/
    _13902 = IS_SEQUENCE(_43ThisLine_48557);
    if (_13902 == 0) {
        goto L4; // [66] 107
    }
    RefDS(_13904);
    Ref(_43ThisLine_48557);
    _13905 = _14ends(_13904, _43ThisLine_48557);
    if (_13905 == 0) {
        DeRef(_13905);
        _13905 = NOVALUE;
        goto L4; // [78] 107
    }
    else {
        if (!IS_ATOM_INT(_13905) && DBL_PTR(_13905)->dbl == 0.0){
            DeRef(_13905);
            _13905 = NOVALUE;
            goto L4; // [78] 107
        }
        DeRef(_13905);
        _13905 = NOVALUE;
    }
    DeRef(_13905);
    _13905 = NOVALUE;

    /** 			ThisLine = remove(ThisLine, length(ThisLine))*/
    if (IS_SEQUENCE(_43ThisLine_48557)){
            _13906 = SEQ_PTR(_43ThisLine_48557)->length;
    }
    else {
        _13906 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_43ThisLine_48557);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_13906)) ? _13906 : (long)(DBL_PTR(_13906)->dbl);
        int stop = (IS_ATOM_INT(_13906)) ? _13906 : (long)(DBL_PTR(_13906)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43ThisLine_48557), start, &_43ThisLine_48557 );
            }
            else Tail(SEQ_PTR(_43ThisLine_48557), stop+1, &_43ThisLine_48557);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43ThisLine_48557), start, &_43ThisLine_48557);
        }
        else {
            assign_slice_seq = &assign_space;
            _43ThisLine_48557 = Remove_elements(start, stop, (SEQ_PTR(_43ThisLine_48557)->ref == 1));
        }
    }
    _13906 = NOVALUE;
    _13906 = NOVALUE;

    /** 			ThisLine[$] = 10*/
    if (IS_SEQUENCE(_43ThisLine_48557)){
            _13908 = SEQ_PTR(_43ThisLine_48557)->length;
    }
    else {
        _13908 = 1;
    }
    _2 = (int)SEQ_PTR(_43ThisLine_48557);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _43ThisLine_48557 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13908);
    _1 = *(int *)_2;
    *(int *)_2 = 10;
    DeRef(_1);
L4: 
L2: 

    /** 	if atom(ThisLine) then*/
    _13909 = IS_ATOM(_43ThisLine_48557);
    if (_13909 == 0)
    {
        _13909 = NOVALUE;
        goto L5; // [115] 149
    }
    else{
        _13909 = NOVALUE;
    }

    /** 		ThisLine = {END_OF_FILE_CHAR}*/
    _0 = _43ThisLine_48557;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 26;
    _43ThisLine_48557 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 		if src_file >= 0 then*/
    if (_26src_file_12104 < 0)
    goto L6; // [130] 141

    /** 			close(src_file)*/
    EClose(_26src_file_12104);
L6: 

    /** 		src_file = -1*/
    _26src_file_12104 = -1;
L5: 

    /** 	bp = 1*/
    _43bp_48561 = 1;

    /** 	AppendSourceLine()*/
    _60AppendSourceLine();

    /** end procedure*/
    return;
    ;
}


int _60getch()
{
    int _c_24296 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c = ThisLine[bp]*/
    _2 = (int)SEQ_PTR(_43ThisLine_48557);
    _c_24296 = (int)*(((s1_ptr)_2)->base + _43bp_48561);
    if (!IS_ATOM_INT(_c_24296)){
        _c_24296 = (long)DBL_PTR(_c_24296)->dbl;
    }

    /** 	bp += 1*/
    _43bp_48561 = _43bp_48561 + 1;

    /** 	return c*/
    return _c_24296;
    ;
}


void _60ungetch()
{
    int _0, _1, _2;
    

    /** 	bp -= 1*/
    _43bp_48561 = _43bp_48561 - 1;

    /** end procedure*/
    return;
    ;
}


int _60get_file_path(int _s_24308)
{
    int _13920 = NOVALUE;
    int _13918 = NOVALUE;
    int _13917 = NOVALUE;
    int _13916 = NOVALUE;
    int _13915 = NOVALUE;
    int _0, _1, _2;
    

    /** 		for t=length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_24308)){
            _13915 = SEQ_PTR(_s_24308)->length;
    }
    else {
        _13915 = 1;
    }
    {
        int _t_24310;
        _t_24310 = _13915;
L1: 
        if (_t_24310 < 1){
            goto L2; // [8] 50
        }

        /** 				if find(s[t],SLASH_CHARS) then*/
        _2 = (int)SEQ_PTR(_s_24308);
        _13916 = (int)*(((s1_ptr)_2)->base + _t_24310);
        _13917 = find_from(_13916, _36SLASH_CHARS_14319, 1);
        _13916 = NOVALUE;
        if (_13917 == 0)
        {
            _13917 = NOVALUE;
            goto L3; // [28] 43
        }
        else{
            _13917 = NOVALUE;
        }

        /** 						return s[1..t]*/
        rhs_slice_target = (object_ptr)&_13918;
        RHS_Slice(_s_24308, 1, _t_24310);
        DeRefDS(_s_24308);
        return _13918;
L3: 

        /** 		end for*/
        _t_24310 = _t_24310 + -1;
        goto L1; // [45] 15
L2: 
        ;
    }

    /** 		return "." & SLASH*/
    Append(&_13920, _13919, 92);
    DeRefDS(_s_24308);
    DeRef(_13918);
    _13918 = NOVALUE;
    return _13920;
    ;
}


int _60find_file(int _fname_24322)
{
    int _try_24323 = NOVALUE;
    int _full_path_24324 = NOVALUE;
    int _errbuff_24325 = NOVALUE;
    int _currdir_24326 = NOVALUE;
    int _conf_path_24327 = NOVALUE;
    int _scan_result_24328 = NOVALUE;
    int _inc_path_24329 = NOVALUE;
    int _mainpath_24348 = NOVALUE;
    int _31685 = NOVALUE;
    int _31684 = NOVALUE;
    int _14017 = NOVALUE;
    int _14015 = NOVALUE;
    int _14014 = NOVALUE;
    int _14013 = NOVALUE;
    int _14011 = NOVALUE;
    int _14009 = NOVALUE;
    int _14007 = NOVALUE;
    int _14006 = NOVALUE;
    int _14004 = NOVALUE;
    int _14003 = NOVALUE;
    int _14000 = NOVALUE;
    int _13997 = NOVALUE;
    int _13996 = NOVALUE;
    int _13995 = NOVALUE;
    int _13994 = NOVALUE;
    int _13993 = NOVALUE;
    int _13992 = NOVALUE;
    int _13991 = NOVALUE;
    int _13990 = NOVALUE;
    int _13987 = NOVALUE;
    int _13986 = NOVALUE;
    int _13982 = NOVALUE;
    int _13979 = NOVALUE;
    int _13978 = NOVALUE;
    int _13977 = NOVALUE;
    int _13976 = NOVALUE;
    int _13975 = NOVALUE;
    int _13974 = NOVALUE;
    int _13973 = NOVALUE;
    int _13972 = NOVALUE;
    int _13969 = NOVALUE;
    int _13965 = NOVALUE;
    int _13963 = NOVALUE;
    int _13962 = NOVALUE;
    int _13961 = NOVALUE;
    int _13960 = NOVALUE;
    int _13959 = NOVALUE;
    int _13956 = NOVALUE;
    int _13955 = NOVALUE;
    int _13954 = NOVALUE;
    int _13953 = NOVALUE;
    int _13952 = NOVALUE;
    int _13951 = NOVALUE;
    int _13949 = NOVALUE;
    int _13948 = NOVALUE;
    int _13947 = NOVALUE;
    int _13946 = NOVALUE;
    int _13945 = NOVALUE;
    int _13943 = NOVALUE;
    int _13942 = NOVALUE;
    int _13939 = NOVALUE;
    int _13936 = NOVALUE;
    int _13934 = NOVALUE;
    int _13931 = NOVALUE;
    int _13929 = NOVALUE;
    int _13928 = NOVALUE;
    int _13925 = NOVALUE;
    int _13924 = NOVALUE;
    int _13922 = NOVALUE;
    int _13921 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if absolute_path(fname) then*/
    RefDS(_fname_24322);
    _13921 = _15absolute_path(_fname_24322);
    if (_13921 == 0) {
        DeRef(_13921);
        _13921 = NOVALUE;
        goto L1; // [9] 42
    }
    else {
        if (!IS_ATOM_INT(_13921) && DBL_PTR(_13921)->dbl == 0.0){
            DeRef(_13921);
            _13921 = NOVALUE;
            goto L1; // [9] 42
        }
        DeRef(_13921);
        _13921 = NOVALUE;
    }
    DeRef(_13921);
    _13921 = NOVALUE;

    /** 		if not file_exists(fname) then*/
    RefDS(_fname_24322);
    _13922 = _15file_exists(_fname_24322);
    if (IS_ATOM_INT(_13922)) {
        if (_13922 != 0){
            DeRef(_13922);
            _13922 = NOVALUE;
            goto L2; // [18] 35
        }
    }
    else {
        if (DBL_PTR(_13922)->dbl != 0.0){
            DeRef(_13922);
            _13922 = NOVALUE;
            goto L2; // [18] 35
        }
    }
    DeRef(_13922);
    _13922 = NOVALUE;

    /** 			CompileErr(51, {new_include_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_26new_include_name_12105);
    *((int *)(_2+4)) = _26new_include_name_12105;
    _13924 = MAKE_SEQ(_1);
    _43CompileErr(51, _13924, 0);
    _13924 = NOVALUE;
L2: 

    /** 		return fname*/
    DeRef(_full_path_24324);
    DeRef(_errbuff_24325);
    DeRef(_currdir_24326);
    DeRef(_conf_path_24327);
    DeRef(_scan_result_24328);
    DeRef(_inc_path_24329);
    DeRef(_mainpath_24348);
    return _fname_24322;
L1: 

    /** 	currdir = get_file_path( known_files[current_file_no] )*/
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _13925 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    Ref(_13925);
    _0 = _currdir_24326;
    _currdir_24326 = _60get_file_path(_13925);
    DeRef(_0);
    _13925 = NOVALUE;

    /** 	full_path = currdir & fname*/
    Concat((object_ptr)&_full_path_24324, _currdir_24326, _fname_24322);

    /** 	if file_exists(full_path) then*/
    RefDS(_full_path_24324);
    _13928 = _15file_exists(_full_path_24324);
    if (_13928 == 0) {
        DeRef(_13928);
        _13928 = NOVALUE;
        goto L3; // [70] 80
    }
    else {
        if (!IS_ATOM_INT(_13928) && DBL_PTR(_13928)->dbl == 0.0){
            DeRef(_13928);
            _13928 = NOVALUE;
            goto L3; // [70] 80
        }
        DeRef(_13928);
        _13928 = NOVALUE;
    }
    DeRef(_13928);
    _13928 = NOVALUE;

    /** 		return full_path*/
    DeRefDS(_fname_24322);
    DeRef(_errbuff_24325);
    DeRefDS(_currdir_24326);
    DeRef(_conf_path_24327);
    DeRef(_scan_result_24328);
    DeRef(_inc_path_24329);
    DeRef(_mainpath_24348);
    return _full_path_24324;
L3: 

    /** 	sequence mainpath = main_path[1..rfind(SLASH, main_path)]*/
    RefDS(_26main_path_12103);
    DeRef(_31684);
    _31684 = _26main_path_12103;
    if (IS_SEQUENCE(_31684)){
            _31685 = SEQ_PTR(_31684)->length;
    }
    else {
        _31685 = 1;
    }
    _31684 = NOVALUE;
    RefDS(_26main_path_12103);
    _13929 = _14rfind(92, _26main_path_12103, _31685);
    _31685 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mainpath_24348;
    RHS_Slice(_26main_path_12103, 1, _13929);

    /** 	if not equal(mainpath, currdir) then*/
    if (_mainpath_24348 == _currdir_24326)
    _13931 = 1;
    else if (IS_ATOM_INT(_mainpath_24348) && IS_ATOM_INT(_currdir_24326))
    _13931 = 0;
    else
    _13931 = (compare(_mainpath_24348, _currdir_24326) == 0);
    if (_13931 != 0)
    goto L4; // [111] 139
    _13931 = NOVALUE;

    /** 		full_path = mainpath & new_include_name*/
    Concat((object_ptr)&_full_path_24324, _mainpath_24348, _26new_include_name_12105);

    /** 		if file_exists(full_path) then*/
    RefDS(_full_path_24324);
    _13934 = _15file_exists(_full_path_24324);
    if (_13934 == 0) {
        DeRef(_13934);
        _13934 = NOVALUE;
        goto L5; // [128] 138
    }
    else {
        if (!IS_ATOM_INT(_13934) && DBL_PTR(_13934)->dbl == 0.0){
            DeRef(_13934);
            _13934 = NOVALUE;
            goto L5; // [128] 138
        }
        DeRef(_13934);
        _13934 = NOVALUE;
    }
    DeRef(_13934);
    _13934 = NOVALUE;

    /** 			return full_path*/
    DeRefDS(_fname_24322);
    DeRef(_errbuff_24325);
    DeRefDS(_currdir_24326);
    DeRef(_conf_path_24327);
    DeRef(_scan_result_24328);
    DeRef(_inc_path_24329);
    DeRefDS(_mainpath_24348);
    _31684 = NOVALUE;
    DeRef(_13929);
    _13929 = NOVALUE;
    return _full_path_24324;
L5: 
L4: 

    /** 	scan_result = ConfPath(new_include_name)*/
    RefDS(_26new_include_name_12105);
    _0 = _scan_result_24328;
    _scan_result_24328 = _38ConfPath(_26new_include_name_12105);
    DeRef(_0);

    /** 	if atom(scan_result) then*/
    _13936 = IS_ATOM(_scan_result_24328);
    if (_13936 == 0)
    {
        _13936 = NOVALUE;
        goto L6; // [152] 164
    }
    else{
        _13936 = NOVALUE;
    }

    /** 		scan_result = ScanPath(fname,"EUINC",0)*/
    RefDS(_fname_24322);
    RefDS(_13937);
    _0 = _scan_result_24328;
    _scan_result_24328 = _38ScanPath(_fname_24322, _13937, 0);
    DeRef(_0);
L6: 

    /** 	if atom(scan_result) then*/
    _13939 = IS_ATOM(_scan_result_24328);
    if (_13939 == 0)
    {
        _13939 = NOVALUE;
        goto L7; // [169] 181
    }
    else{
        _13939 = NOVALUE;
    }

    /** 		scan_result = ScanPath(fname, "EUDIR",1)*/
    RefDS(_fname_24322);
    RefDS(_13940);
    _0 = _scan_result_24328;
    _scan_result_24328 = _38ScanPath(_fname_24322, _13940, 1);
    DeRef(_0);
L7: 

    /** 	if atom(scan_result) then*/
    _13942 = IS_ATOM(_scan_result_24328);
    if (_13942 == 0)
    {
        _13942 = NOVALUE;
        goto L8; // [186] 223
    }
    else{
        _13942 = NOVALUE;
    }

    /** 		full_path = get_eudir() & SLASH & "include" & SLASH & fname*/
    _13943 = _27get_eudir();
    {
        int concat_list[5];

        concat_list[0] = _fname_24322;
        concat_list[1] = 92;
        concat_list[2] = _13363;
        concat_list[3] = 92;
        concat_list[4] = _13943;
        Concat_N((object_ptr)&_full_path_24324, concat_list, 5);
    }
    DeRef(_13943);
    _13943 = NOVALUE;

    /** 		if file_exists(full_path) then*/
    RefDS(_full_path_24324);
    _13945 = _15file_exists(_full_path_24324);
    if (_13945 == 0) {
        DeRef(_13945);
        _13945 = NOVALUE;
        goto L9; // [212] 222
    }
    else {
        if (!IS_ATOM_INT(_13945) && DBL_PTR(_13945)->dbl == 0.0){
            DeRef(_13945);
            _13945 = NOVALUE;
            goto L9; // [212] 222
        }
        DeRef(_13945);
        _13945 = NOVALUE;
    }
    DeRef(_13945);
    _13945 = NOVALUE;

    /** 			return full_path*/
    DeRefDS(_fname_24322);
    DeRef(_errbuff_24325);
    DeRef(_currdir_24326);
    DeRef(_conf_path_24327);
    DeRef(_scan_result_24328);
    DeRef(_inc_path_24329);
    DeRef(_mainpath_24348);
    _31684 = NOVALUE;
    DeRef(_13929);
    _13929 = NOVALUE;
    return _full_path_24324;
L9: 
L8: 

    /** 	if sequence(scan_result) then*/
    _13946 = IS_SEQUENCE(_scan_result_24328);
    if (_13946 == 0)
    {
        _13946 = NOVALUE;
        goto LA; // [228] 250
    }
    else{
        _13946 = NOVALUE;
    }

    /** 		close(scan_result[2])*/
    _2 = (int)SEQ_PTR(_scan_result_24328);
    _13947 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_13947))
    EClose(_13947);
    else
    EClose((int)DBL_PTR(_13947)->dbl);
    _13947 = NOVALUE;

    /** 		return scan_result[1]*/
    _2 = (int)SEQ_PTR(_scan_result_24328);
    _13948 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_13948);
    DeRefDS(_fname_24322);
    DeRef(_full_path_24324);
    DeRef(_errbuff_24325);
    DeRef(_currdir_24326);
    DeRef(_conf_path_24327);
    DeRef(_scan_result_24328);
    DeRef(_inc_path_24329);
    DeRef(_mainpath_24348);
    _31684 = NOVALUE;
    DeRef(_13929);
    _13929 = NOVALUE;
    return _13948;
LA: 

    /** 	errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_24325);
    _errbuff_24325 = _5;

    /** 	full_path = {}*/
    RefDS(_5);
    DeRef(_full_path_24324);
    _full_path_24324 = _5;

    /** 	if length(currdir) > 0 then*/
    if (IS_SEQUENCE(_currdir_24326)){
            _13949 = SEQ_PTR(_currdir_24326)->length;
    }
    else {
        _13949 = 1;
    }
    if (_13949 <= 0)
    goto LB; // [269] 321

    /** 		if find(currdir[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_currdir_24326)){
            _13951 = SEQ_PTR(_currdir_24326)->length;
    }
    else {
        _13951 = 1;
    }
    _2 = (int)SEQ_PTR(_currdir_24326);
    _13952 = (int)*(((s1_ptr)_2)->base + _13951);
    _13953 = find_from(_13952, _36SLASH_CHARS_14319, 1);
    _13952 = NOVALUE;
    if (_13953 == 0)
    {
        _13953 = NOVALUE;
        goto LC; // [289] 313
    }
    else{
        _13953 = NOVALUE;
    }

    /** 			full_path = append(full_path, currdir[1..$-1])*/
    if (IS_SEQUENCE(_currdir_24326)){
            _13954 = SEQ_PTR(_currdir_24326)->length;
    }
    else {
        _13954 = 1;
    }
    _13955 = _13954 - 1;
    _13954 = NOVALUE;
    rhs_slice_target = (object_ptr)&_13956;
    RHS_Slice(_currdir_24326, 1, _13955);
    RefDS(_13956);
    Append(&_full_path_24324, _full_path_24324, _13956);
    DeRefDS(_13956);
    _13956 = NOVALUE;
    goto LD; // [310] 320
LC: 

    /** 			full_path = append(full_path, currdir)*/
    RefDS(_currdir_24326);
    Append(&_full_path_24324, _full_path_24324, _currdir_24326);
LD: 
LB: 

    /** 	if find(main_path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_26main_path_12103)){
            _13959 = SEQ_PTR(_26main_path_12103)->length;
    }
    else {
        _13959 = 1;
    }
    _2 = (int)SEQ_PTR(_26main_path_12103);
    _13960 = (int)*(((s1_ptr)_2)->base + _13959);
    _13961 = find_from(_13960, _36SLASH_CHARS_14319, 1);
    _13960 = NOVALUE;
    if (_13961 == 0)
    {
        _13961 = NOVALUE;
        goto LE; // [339] 361
    }
    else{
        _13961 = NOVALUE;
    }

    /** 		errbuff = main_path[1..$-1]  -- looks better*/
    if (IS_SEQUENCE(_26main_path_12103)){
            _13962 = SEQ_PTR(_26main_path_12103)->length;
    }
    else {
        _13962 = 1;
    }
    _13963 = _13962 - 1;
    _13962 = NOVALUE;
    rhs_slice_target = (object_ptr)&_errbuff_24325;
    RHS_Slice(_26main_path_12103, 1, _13963);
    goto LF; // [358] 371
LE: 

    /** 		errbuff = main_path*/
    RefDS(_26main_path_12103);
    DeRef(_errbuff_24325);
    _errbuff_24325 = _26main_path_12103;
LF: 

    /** 	if not find(errbuff, full_path) then*/
    _13965 = find_from(_errbuff_24325, _full_path_24324, 1);
    if (_13965 != 0)
    goto L10; // [378] 388
    _13965 = NOVALUE;

    /** 		full_path = append(full_path, errbuff)*/
    RefDS(_errbuff_24325);
    Append(&_full_path_24324, _full_path_24324, _errbuff_24325);
L10: 

    /** 	conf_path = get_conf_dirs()*/
    _0 = _conf_path_24327;
    _conf_path_24327 = _38get_conf_dirs();
    DeRef(_0);

    /** 	if length(conf_path) > 0 then*/
    if (IS_SEQUENCE(_conf_path_24327)){
            _13969 = SEQ_PTR(_conf_path_24327)->length;
    }
    else {
        _13969 = 1;
    }
    if (_13969 <= 0)
    goto L11; // [400] 507

    /** 		conf_path = split(conf_path, PATHSEP)*/
    RefDS(_conf_path_24327);
    _0 = _conf_path_24327;
    _conf_path_24327 = _23split(_conf_path_24327, 59, 0, 0);
    DeRefDS(_0);

    /** 		for i = 1 to length(conf_path) do*/
    if (IS_SEQUENCE(_conf_path_24327)){
            _13972 = SEQ_PTR(_conf_path_24327)->length;
    }
    else {
        _13972 = 1;
    }
    {
        int _i_24429;
        _i_24429 = 1;
L12: 
        if (_i_24429 > _13972){
            goto L13; // [422] 506
        }

        /** 			if find(conf_path[i][$], SLASH_CHARS) then*/
        _2 = (int)SEQ_PTR(_conf_path_24327);
        _13973 = (int)*(((s1_ptr)_2)->base + _i_24429);
        if (IS_SEQUENCE(_13973)){
                _13974 = SEQ_PTR(_13973)->length;
        }
        else {
            _13974 = 1;
        }
        _2 = (int)SEQ_PTR(_13973);
        _13975 = (int)*(((s1_ptr)_2)->base + _13974);
        _13973 = NOVALUE;
        _13976 = find_from(_13975, _36SLASH_CHARS_14319, 1);
        _13975 = NOVALUE;
        if (_13976 == 0)
        {
            _13976 = NOVALUE;
            goto L14; // [449] 473
        }
        else{
            _13976 = NOVALUE;
        }

        /** 				errbuff = conf_path[i][1..$-1]  -- looks better*/
        _2 = (int)SEQ_PTR(_conf_path_24327);
        _13977 = (int)*(((s1_ptr)_2)->base + _i_24429);
        if (IS_SEQUENCE(_13977)){
                _13978 = SEQ_PTR(_13977)->length;
        }
        else {
            _13978 = 1;
        }
        _13979 = _13978 - 1;
        _13978 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_24325;
        RHS_Slice(_13977, 1, _13979);
        _13977 = NOVALUE;
        goto L15; // [470] 482
L14: 

        /** 				errbuff = conf_path[i]*/
        DeRef(_errbuff_24325);
        _2 = (int)SEQ_PTR(_conf_path_24327);
        _errbuff_24325 = (int)*(((s1_ptr)_2)->base + _i_24429);
        Ref(_errbuff_24325);
L15: 

        /** 			if not find(errbuff, full_path) then*/
        _13982 = find_from(_errbuff_24325, _full_path_24324, 1);
        if (_13982 != 0)
        goto L16; // [489] 499
        _13982 = NOVALUE;

        /** 				full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_24325);
        Append(&_full_path_24324, _full_path_24324, _errbuff_24325);
L16: 

        /** 		end for*/
        _i_24429 = _i_24429 + 1;
        goto L12; // [501] 429
L13: 
        ;
    }
L11: 

    /** 	inc_path = getenv("EUINC")*/
    DeRef(_inc_path_24329);
    _inc_path_24329 = EGetEnv(_13937);

    /** 	if sequence(inc_path) then*/
    _13986 = IS_SEQUENCE(_inc_path_24329);
    if (_13986 == 0)
    {
        _13986 = NOVALUE;
        goto L17; // [517] 631
    }
    else{
        _13986 = NOVALUE;
    }

    /** 		if length(inc_path) > 0 then*/
    if (IS_SEQUENCE(_inc_path_24329)){
            _13987 = SEQ_PTR(_inc_path_24329)->length;
    }
    else {
        _13987 = 1;
    }
    if (_13987 <= 0)
    goto L18; // [525] 630

    /** 			inc_path = split(inc_path, PATHSEP)*/
    Ref(_inc_path_24329);
    _0 = _inc_path_24329;
    _inc_path_24329 = _23split(_inc_path_24329, 59, 0, 0);
    DeRefi(_0);

    /** 			for i = 1 to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_24329)){
            _13990 = SEQ_PTR(_inc_path_24329)->length;
    }
    else {
        _13990 = 1;
    }
    {
        int _i_24457;
        _i_24457 = 1;
L19: 
        if (_i_24457 > _13990){
            goto L1A; // [545] 629
        }

        /** 				if find(inc_path[i][$], SLASH_CHARS) then*/
        _2 = (int)SEQ_PTR(_inc_path_24329);
        _13991 = (int)*(((s1_ptr)_2)->base + _i_24457);
        if (IS_SEQUENCE(_13991)){
                _13992 = SEQ_PTR(_13991)->length;
        }
        else {
            _13992 = 1;
        }
        _2 = (int)SEQ_PTR(_13991);
        _13993 = (int)*(((s1_ptr)_2)->base + _13992);
        _13991 = NOVALUE;
        _13994 = find_from(_13993, _36SLASH_CHARS_14319, 1);
        _13993 = NOVALUE;
        if (_13994 == 0)
        {
            _13994 = NOVALUE;
            goto L1B; // [572] 596
        }
        else{
            _13994 = NOVALUE;
        }

        /** 					errbuff = inc_path[i][1..$-1]  -- looks better*/
        _2 = (int)SEQ_PTR(_inc_path_24329);
        _13995 = (int)*(((s1_ptr)_2)->base + _i_24457);
        if (IS_SEQUENCE(_13995)){
                _13996 = SEQ_PTR(_13995)->length;
        }
        else {
            _13996 = 1;
        }
        _13997 = _13996 - 1;
        _13996 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_24325;
        RHS_Slice(_13995, 1, _13997);
        _13995 = NOVALUE;
        goto L1C; // [593] 605
L1B: 

        /** 					errbuff = inc_path[i]*/
        DeRef(_errbuff_24325);
        _2 = (int)SEQ_PTR(_inc_path_24329);
        _errbuff_24325 = (int)*(((s1_ptr)_2)->base + _i_24457);
        Ref(_errbuff_24325);
L1C: 

        /** 				if not find(errbuff, full_path) then*/
        _14000 = find_from(_errbuff_24325, _full_path_24324, 1);
        if (_14000 != 0)
        goto L1D; // [612] 622
        _14000 = NOVALUE;

        /** 					full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_24325);
        Append(&_full_path_24324, _full_path_24324, _errbuff_24325);
L1D: 

        /** 			end for*/
        _i_24457 = _i_24457 + 1;
        goto L19; // [624] 552
L1A: 
        ;
    }
L18: 
L17: 

    /** 	if length(get_eudir()) > 0 then*/
    _14003 = _27get_eudir();
    if (IS_SEQUENCE(_14003)){
            _14004 = SEQ_PTR(_14003)->length;
    }
    else {
        _14004 = 1;
    }
    DeRef(_14003);
    _14003 = NOVALUE;
    if (_14004 <= 0)
    goto L1E; // [639] 667

    /** 		if not find(get_eudir(), full_path) then*/
    _14006 = _27get_eudir();
    _14007 = find_from(_14006, _full_path_24324, 1);
    DeRef(_14006);
    _14006 = NOVALUE;
    if (_14007 != 0)
    goto L1F; // [653] 666
    _14007 = NOVALUE;

    /** 			full_path = append(full_path, get_eudir())*/
    _14009 = _27get_eudir();
    Ref(_14009);
    Append(&_full_path_24324, _full_path_24324, _14009);
    DeRef(_14009);
    _14009 = NOVALUE;
L1F: 
L1E: 

    /** 	errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_24325);
    _errbuff_24325 = _5;

    /** 	for i = 1 to length(full_path) do*/
    if (IS_SEQUENCE(_full_path_24324)){
            _14011 = SEQ_PTR(_full_path_24324)->length;
    }
    else {
        _14011 = 1;
    }
    {
        int _i_24489;
        _i_24489 = 1;
L20: 
        if (_i_24489 > _14011){
            goto L21; // [679] 711
        }

        /** 		errbuff &= sprintf("\t%s\n", {full_path[i]})*/
        _2 = (int)SEQ_PTR(_full_path_24324);
        _14013 = (int)*(((s1_ptr)_2)->base + _i_24489);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_14013);
        *((int *)(_2+4)) = _14013;
        _14014 = MAKE_SEQ(_1);
        _14013 = NOVALUE;
        _14015 = EPrintf(-9999999, _14012, _14014);
        DeRefDS(_14014);
        _14014 = NOVALUE;
        Concat((object_ptr)&_errbuff_24325, _errbuff_24325, _14015);
        DeRefDS(_14015);
        _14015 = NOVALUE;

        /** 	end for*/
        _i_24489 = _i_24489 + 1;
        goto L20; // [706] 686
L21: 
        ;
    }

    /** 	CompileErr(52, {new_include_name, errbuff})*/
    RefDS(_errbuff_24325);
    RefDS(_26new_include_name_12105);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _26new_include_name_12105;
    ((int *)_2)[2] = _errbuff_24325;
    _14017 = MAKE_SEQ(_1);
    _43CompileErr(52, _14017, 0);
    _14017 = NOVALUE;
    ;
}


int _60path_open()
{
    int _fh_24501 = NOVALUE;
    int _0, _1, _2;
    

    /** 	new_include_name = find_file(new_include_name)*/
    RefDS(_26new_include_name_12105);
    _0 = _60find_file(_26new_include_name_12105);
    DeRefDS(_26new_include_name_12105);
    _26new_include_name_12105 = _0;

    /** 	new_include_name = maybe_preprocess(new_include_name)*/
    RefDS(_26new_include_name_12105);
    _0 = _63maybe_preprocess(_26new_include_name_12105);
    DeRefDS(_26new_include_name_12105);
    _26new_include_name_12105 = _0;

    /** 	fh = open_locked(new_include_name)*/
    RefDS(_26new_include_name_12105);
    _fh_24501 = _27open_locked(_26new_include_name_12105);
    if (!IS_ATOM_INT(_fh_24501)) {
        _1 = (long)(DBL_PTR(_fh_24501)->dbl);
        DeRefDS(_fh_24501);
        _fh_24501 = _1;
    }

    /** 	return fh*/
    return _fh_24501;
    ;
}


int _60NameSpace_declaration(int _sym_24529)
{
    int _h_24530 = NOVALUE;
    int _14041 = NOVALUE;
    int _14039 = NOVALUE;
    int _14037 = NOVALUE;
    int _14035 = NOVALUE;
    int _14034 = NOVALUE;
    int _14033 = NOVALUE;
    int _14031 = NOVALUE;
    int _14030 = NOVALUE;
    int _14029 = NOVALUE;
    int _14028 = NOVALUE;
    int _14027 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_24529)) {
        _1 = (long)(DBL_PTR(_sym_24529)->dbl);
        DeRefDS(_sym_24529);
        _sym_24529 = _1;
    }

    /** 	DefinedYet(sym)*/
    _52DefinedYet(_sym_24529);

    /** 	if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_PREDEF}) then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _14027 = (int)*(((s1_ptr)_2)->base + _sym_24529);
    _2 = (int)SEQ_PTR(_14027);
    _14028 = (int)*(((s1_ptr)_2)->base + 4);
    _14027 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 6;
    *((int *)(_2+8)) = 13;
    *((int *)(_2+12)) = 11;
    *((int *)(_2+16)) = 7;
    _14029 = MAKE_SEQ(_1);
    _14030 = find_from(_14028, _14029, 1);
    _14028 = NOVALUE;
    DeRefDS(_14029);
    _14029 = NOVALUE;
    if (_14030 == 0)
    {
        _14030 = NOVALUE;
        goto L1; // [42] 104
    }
    else{
        _14030 = NOVALUE;
    }

    /** 		h = SymTab[sym][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _14031 = (int)*(((s1_ptr)_2)->base + _sym_24529);
    _2 = (int)SEQ_PTR(_14031);
    _h_24530 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_24530)){
        _h_24530 = (long)DBL_PTR(_h_24530)->dbl;
    }
    _14031 = NOVALUE;

    /** 		sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _14033 = (int)*(((s1_ptr)_2)->base + _sym_24529);
    _2 = (int)SEQ_PTR(_14033);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _14034 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _14034 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _14033 = NOVALUE;
    _2 = (int)SEQ_PTR(_52buckets_46126);
    _14035 = (int)*(((s1_ptr)_2)->base + _h_24530);
    Ref(_14034);
    Ref(_14035);
    _sym_24529 = _52NewEntry(_14034, 0, 0, -100, _h_24530, _14035, 0);
    _14034 = NOVALUE;
    _14035 = NOVALUE;
    if (!IS_ATOM_INT(_sym_24529)) {
        _1 = (long)(DBL_PTR(_sym_24529)->dbl);
        DeRefDS(_sym_24529);
        _sym_24529 = _1;
    }

    /** 		buckets[h] = sym*/
    _2 = (int)SEQ_PTR(_52buckets_46126);
    _2 = (int)(((s1_ptr)_2)->base + _h_24530);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_24529;
    DeRef(_1);
L1: 

    /** 	SymTab[sym][S_SCOPE] = SC_LOCAL*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24529 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 5;
    DeRef(_1);
    _14037 = NOVALUE;

    /** 	SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24529 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _14039 = NOVALUE;

    /** 	SymTab[sym][S_TOKEN] = NAMESPACE -- [S_OBJ] will get the file number referred-to*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24529 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_TOKEN_11659))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    _1 = *(int *)_2;
    *(int *)_2 = 523;
    DeRef(_1);
    _14041 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L2; // [159] 173
    }
    else{
    }

    /** 		num_routines += 1 -- order of ns declaration relative to routines*/
    _26num_routines_11991 = _26num_routines_11991 + 1;
L2: 

    /** 	return sym*/
    return _sym_24529;
    ;
}


void _60default_namespace()
{
    int _tok_24580 = NOVALUE;
    int _sym_24582 = NOVALUE;
    int _14065 = NOVALUE;
    int _14064 = NOVALUE;
    int _14062 = NOVALUE;
    int _14060 = NOVALUE;
    int _14057 = NOVALUE;
    int _14054 = NOVALUE;
    int _14052 = NOVALUE;
    int _14050 = NOVALUE;
    int _14049 = NOVALUE;
    int _14048 = NOVALUE;
    int _14047 = NOVALUE;
    int _14046 = NOVALUE;
    int _14045 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	tok = call_func( scanner_rid, {} )*/
    _0 = (int)_00[_60scanner_rid_24576].addr;
    _1 = (*(int (*)())_0)(
                         );
    DeRef(_tok_24580);
    _tok_24580 = _1;

    /** 	if tok[T_ID] = VARIABLE and equal( SymTab[tok[T_SYM]][S_NAME], "namespace" ) then*/
    _2 = (int)SEQ_PTR(_tok_24580);
    _14045 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_14045)) {
        _14046 = (_14045 == -100);
    }
    else {
        _14046 = binary_op(EQUALS, _14045, -100);
    }
    _14045 = NOVALUE;
    if (IS_ATOM_INT(_14046)) {
        if (_14046 == 0) {
            goto L1; // [23] 177
        }
    }
    else {
        if (DBL_PTR(_14046)->dbl == 0.0) {
            goto L1; // [23] 177
        }
    }
    _2 = (int)SEQ_PTR(_tok_24580);
    _14048 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_14048)){
        _14049 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14048)->dbl));
    }
    else{
        _14049 = (int)*(((s1_ptr)_2)->base + _14048);
    }
    _2 = (int)SEQ_PTR(_14049);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _14050 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _14050 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _14049 = NOVALUE;
    if (_14050 == _14051)
    _14052 = 1;
    else if (IS_ATOM_INT(_14050) && IS_ATOM_INT(_14051))
    _14052 = 0;
    else
    _14052 = (compare(_14050, _14051) == 0);
    _14050 = NOVALUE;
    if (_14052 == 0)
    {
        _14052 = NOVALUE;
        goto L1; // [50] 177
    }
    else{
        _14052 = NOVALUE;
    }

    /** 		tok = call_func( scanner_rid, {} )*/
    _0 = (int)_00[_60scanner_rid_24576].addr;
    _1 = (*(int (*)())_0)(
                         );
    DeRef(_tok_24580);
    _tok_24580 = _1;

    /** 		if tok[T_ID] != VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_24580);
    _14054 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _14054, -100)){
        _14054 = NOVALUE;
        goto L2; // [71] 83
    }
    _14054 = NOVALUE;

    /** 			CompileErr(114)*/
    RefDS(_22037);
    _43CompileErr(114, _22037, 0);
L2: 

    /** 		sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_24580);
    _sym_24582 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_24582)){
        _sym_24582 = (long)DBL_PTR(_sym_24582)->dbl;
    }

    /** 		SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24582 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_FILE_NO_11650))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    _1 = *(int *)_2;
    *(int *)_2 = _26current_file_no_11982;
    DeRef(_1);
    _14057 = NOVALUE;

    /** 		sym  = NameSpace_declaration( sym )*/
    _sym_24582 = _60NameSpace_declaration(_sym_24582);
    if (!IS_ATOM_INT(_sym_24582)) {
        _1 = (long)(DBL_PTR(_sym_24582)->dbl);
        DeRefDS(_sym_24582);
        _sym_24582 = _1;
    }

    /** 		SymTab[sym][S_OBJ] = current_file_no*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24582 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _26current_file_no_11982;
    DeRef(_1);
    _14060 = NOVALUE;

    /** 		SymTab[sym][S_SCOPE] = SC_PUBLIC*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24582 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 13;
    DeRef(_1);
    _14062 = NOVALUE;

    /** 		default_namespaces[current_file_no] = SymTab[sym][S_NAME]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _14064 = (int)*(((s1_ptr)_2)->base + _sym_24582);
    _2 = (int)SEQ_PTR(_14064);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _14065 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _14065 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _14064 = NOVALUE;
    Ref(_14065);
    _2 = (int)SEQ_PTR(_60default_namespaces_23943);
    _2 = (int)(((s1_ptr)_2)->base + _26current_file_no_11982);
    _1 = *(int *)_2;
    *(int *)_2 = _14065;
    if( _1 != _14065 ){
        DeRef(_1);
    }
    _14065 = NOVALUE;
    goto L3; // [174] 185
L1: 

    /** 		bp = 1*/
    _43bp_48561 = 1;
L3: 

    /** end procedure*/
    DeRef(_tok_24580);
    _14048 = NOVALUE;
    DeRef(_14046);
    _14046 = NOVALUE;
    return;
    ;
}


void _60add_exports(int _from_file_24632, int _to_file_24633)
{
    int _exports_24634 = NOVALUE;
    int _direct_24635 = NOVALUE;
    int _14085 = NOVALUE;
    int _14084 = NOVALUE;
    int _14083 = NOVALUE;
    int _14082 = NOVALUE;
    int _14081 = NOVALUE;
    int _14079 = NOVALUE;
    int _14077 = NOVALUE;
    int _14076 = NOVALUE;
    int _14074 = NOVALUE;
    int _14073 = NOVALUE;
    int _14072 = NOVALUE;
    int _14070 = NOVALUE;
    int _14069 = NOVALUE;
    int _14068 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	direct = file_include[to_file]*/
    DeRef(_direct_24635);
    _2 = (int)SEQ_PTR(_27file_include_10926);
    _direct_24635 = (int)*(((s1_ptr)_2)->base + _to_file_24633);
    Ref(_direct_24635);

    /** 	exports = file_public[from_file]*/
    DeRef(_exports_24634);
    _2 = (int)SEQ_PTR(_27file_public_10934);
    _exports_24634 = (int)*(((s1_ptr)_2)->base + _from_file_24632);
    Ref(_exports_24634);

    /** 	for i = 1 to length(exports) do*/
    if (IS_SEQUENCE(_exports_24634)){
            _14068 = SEQ_PTR(_exports_24634)->length;
    }
    else {
        _14068 = 1;
    }
    {
        int _i_24641;
        _i_24641 = 1;
L1: 
        if (_i_24641 > _14068){
            goto L2; // [30] 127
        }

        /** 		if not find( exports[i], direct ) then*/
        _2 = (int)SEQ_PTR(_exports_24634);
        _14069 = (int)*(((s1_ptr)_2)->base + _i_24641);
        _14070 = find_from(_14069, _direct_24635, 1);
        _14069 = NOVALUE;
        if (_14070 != 0)
        goto L3; // [48] 120
        _14070 = NOVALUE;

        /** 			if not find( -exports[i], direct ) then*/
        _2 = (int)SEQ_PTR(_exports_24634);
        _14072 = (int)*(((s1_ptr)_2)->base + _i_24641);
        if (IS_ATOM_INT(_14072)) {
            if ((unsigned long)_14072 == 0xC0000000)
            _14073 = (int)NewDouble((double)-0xC0000000);
            else
            _14073 = - _14072;
        }
        else {
            _14073 = unary_op(UMINUS, _14072);
        }
        _14072 = NOVALUE;
        _14074 = find_from(_14073, _direct_24635, 1);
        DeRef(_14073);
        _14073 = NOVALUE;
        if (_14074 != 0)
        goto L4; // [65] 82
        _14074 = NOVALUE;

        /** 				direct &= -exports[i]*/
        _2 = (int)SEQ_PTR(_exports_24634);
        _14076 = (int)*(((s1_ptr)_2)->base + _i_24641);
        if (IS_ATOM_INT(_14076)) {
            if ((unsigned long)_14076 == 0xC0000000)
            _14077 = (int)NewDouble((double)-0xC0000000);
            else
            _14077 = - _14076;
        }
        else {
            _14077 = unary_op(UMINUS, _14076);
        }
        _14076 = NOVALUE;
        if (IS_SEQUENCE(_direct_24635) && IS_ATOM(_14077)) {
            Ref(_14077);
            Append(&_direct_24635, _direct_24635, _14077);
        }
        else if (IS_ATOM(_direct_24635) && IS_SEQUENCE(_14077)) {
        }
        else {
            Concat((object_ptr)&_direct_24635, _direct_24635, _14077);
        }
        DeRef(_14077);
        _14077 = NOVALUE;
L4: 

        /** 			include_matrix[to_file][exports[i]] = or_bits( PUBLIC_INCLUDE, include_matrix[to_file][exports[i]] )*/
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27include_matrix_10928 = MAKE_SEQ(_2);
        }
        _3 = (int)(_to_file_24633 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_exports_24634);
        _14081 = (int)*(((s1_ptr)_2)->base + _i_24641);
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        _14082 = (int)*(((s1_ptr)_2)->base + _to_file_24633);
        _2 = (int)SEQ_PTR(_exports_24634);
        _14083 = (int)*(((s1_ptr)_2)->base + _i_24641);
        _2 = (int)SEQ_PTR(_14082);
        if (!IS_ATOM_INT(_14083)){
            _14084 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14083)->dbl));
        }
        else{
            _14084 = (int)*(((s1_ptr)_2)->base + _14083);
        }
        _14082 = NOVALUE;
        if (IS_ATOM_INT(_14084)) {
            {unsigned long tu;
                 tu = (unsigned long)4 | (unsigned long)_14084;
                 _14085 = MAKE_UINT(tu);
            }
        }
        else {
            _14085 = binary_op(OR_BITS, 4, _14084);
        }
        _14084 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14081))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_14081)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _14081);
        _1 = *(int *)_2;
        *(int *)_2 = _14085;
        if( _1 != _14085 ){
            DeRef(_1);
        }
        _14085 = NOVALUE;
        _14079 = NOVALUE;
L3: 

        /** 	end for*/
        _i_24641 = _i_24641 + 1;
        goto L1; // [122] 37
L2: 
        ;
    }

    /** 	file_include[to_file] = direct*/
    RefDS(_direct_24635);
    _2 = (int)SEQ_PTR(_27file_include_10926);
    _2 = (int)(((s1_ptr)_2)->base + _to_file_24633);
    _1 = *(int *)_2;
    *(int *)_2 = _direct_24635;
    DeRef(_1);

    /** end procedure*/
    DeRef(_exports_24634);
    DeRefDS(_direct_24635);
    _14081 = NOVALUE;
    _14083 = NOVALUE;
    return;
    ;
}


void _60patch_exports(int _for_file_24668)
{
    int _export_len_24669 = NOVALUE;
    int _14096 = NOVALUE;
    int _14095 = NOVALUE;
    int _14093 = NOVALUE;
    int _14092 = NOVALUE;
    int _14091 = NOVALUE;
    int _14090 = NOVALUE;
    int _14088 = NOVALUE;
    int _14087 = NOVALUE;
    int _14086 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(file_include) do*/
    if (IS_SEQUENCE(_27file_include_10926)){
            _14086 = SEQ_PTR(_27file_include_10926)->length;
    }
    else {
        _14086 = 1;
    }
    {
        int _i_24671;
        _i_24671 = 1;
L1: 
        if (_i_24671 > _14086){
            goto L2; // [10] 99
        }

        /** 		if find( for_file, file_include[i] ) or find( -for_file, file_include[i] ) then*/
        _2 = (int)SEQ_PTR(_27file_include_10926);
        _14087 = (int)*(((s1_ptr)_2)->base + _i_24671);
        _14088 = find_from(_for_file_24668, _14087, 1);
        _14087 = NOVALUE;
        if (_14088 != 0) {
            goto L3; // [30] 53
        }
        if ((unsigned long)_for_file_24668 == 0xC0000000)
        _14090 = (int)NewDouble((double)-0xC0000000);
        else
        _14090 = - _for_file_24668;
        _2 = (int)SEQ_PTR(_27file_include_10926);
        _14091 = (int)*(((s1_ptr)_2)->base + _i_24671);
        _14092 = find_from(_14090, _14091, 1);
        DeRef(_14090);
        _14090 = NOVALUE;
        _14091 = NOVALUE;
        if (_14092 == 0)
        {
            _14092 = NOVALUE;
            goto L4; // [49] 92
        }
        else{
            _14092 = NOVALUE;
        }
L3: 

        /** 			export_len = length( file_include[i] )*/
        _2 = (int)SEQ_PTR(_27file_include_10926);
        _14093 = (int)*(((s1_ptr)_2)->base + _i_24671);
        if (IS_SEQUENCE(_14093)){
                _export_len_24669 = SEQ_PTR(_14093)->length;
        }
        else {
            _export_len_24669 = 1;
        }
        _14093 = NOVALUE;

        /** 			add_exports( for_file, i )*/
        _60add_exports(_for_file_24668, _i_24671);

        /** 			if length( file_include[i] ) != export_len then*/
        _2 = (int)SEQ_PTR(_27file_include_10926);
        _14095 = (int)*(((s1_ptr)_2)->base + _i_24671);
        if (IS_SEQUENCE(_14095)){
                _14096 = SEQ_PTR(_14095)->length;
        }
        else {
            _14096 = 1;
        }
        _14095 = NOVALUE;
        if (_14096 == _export_len_24669)
        goto L5; // [81] 91

        /** 				patch_exports( i )*/
        _60patch_exports(_i_24671);
L5: 
L4: 

        /** 	end for*/
        _i_24671 = _i_24671 + 1;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** end procedure*/
    _14093 = NOVALUE;
    _14095 = NOVALUE;
    return;
    ;
}


void _60update_include_matrix(int _included_file_24693, int _from_file_24694)
{
    int _add_public_24704 = NOVALUE;
    int _px_24722 = NOVALUE;
    int _indirect_24781 = NOVALUE;
    int _mask_24784 = NOVALUE;
    int _ix_24795 = NOVALUE;
    int _indirect_file_24799 = NOVALUE;
    int _14172 = NOVALUE;
    int _14171 = NOVALUE;
    int _14169 = NOVALUE;
    int _14168 = NOVALUE;
    int _14167 = NOVALUE;
    int _14166 = NOVALUE;
    int _14165 = NOVALUE;
    int _14164 = NOVALUE;
    int _14163 = NOVALUE;
    int _14162 = NOVALUE;
    int _14161 = NOVALUE;
    int _14158 = NOVALUE;
    int _14156 = NOVALUE;
    int _14155 = NOVALUE;
    int _14154 = NOVALUE;
    int _14152 = NOVALUE;
    int _14150 = NOVALUE;
    int _14149 = NOVALUE;
    int _14147 = NOVALUE;
    int _14146 = NOVALUE;
    int _14145 = NOVALUE;
    int _14144 = NOVALUE;
    int _14143 = NOVALUE;
    int _14141 = NOVALUE;
    int _14140 = NOVALUE;
    int _14139 = NOVALUE;
    int _14138 = NOVALUE;
    int _14137 = NOVALUE;
    int _14136 = NOVALUE;
    int _14134 = NOVALUE;
    int _14133 = NOVALUE;
    int _14132 = NOVALUE;
    int _14130 = NOVALUE;
    int _14129 = NOVALUE;
    int _14128 = NOVALUE;
    int _14127 = NOVALUE;
    int _14126 = NOVALUE;
    int _14125 = NOVALUE;
    int _14124 = NOVALUE;
    int _14123 = NOVALUE;
    int _14122 = NOVALUE;
    int _14121 = NOVALUE;
    int _14120 = NOVALUE;
    int _14118 = NOVALUE;
    int _14117 = NOVALUE;
    int _14115 = NOVALUE;
    int _14113 = NOVALUE;
    int _14111 = NOVALUE;
    int _14110 = NOVALUE;
    int _14109 = NOVALUE;
    int _14108 = NOVALUE;
    int _14106 = NOVALUE;
    int _14105 = NOVALUE;
    int _14104 = NOVALUE;
    int _14102 = NOVALUE;
    int _14101 = NOVALUE;
    int _14100 = NOVALUE;
    int _14098 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	include_matrix[from_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[from_file][included_file] )*/
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27include_matrix_10928 = MAKE_SEQ(_2);
    }
    _3 = (int)(_from_file_24694 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _14100 = (int)*(((s1_ptr)_2)->base + _from_file_24694);
    _2 = (int)SEQ_PTR(_14100);
    _14101 = (int)*(((s1_ptr)_2)->base + _included_file_24693);
    _14100 = NOVALUE;
    if (IS_ATOM_INT(_14101)) {
        {unsigned long tu;
             tu = (unsigned long)2 | (unsigned long)_14101;
             _14102 = MAKE_UINT(tu);
        }
    }
    else {
        _14102 = binary_op(OR_BITS, 2, _14101);
    }
    _14101 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24693);
    _1 = *(int *)_2;
    *(int *)_2 = _14102;
    if( _1 != _14102 ){
        DeRef(_1);
    }
    _14102 = NOVALUE;
    _14098 = NOVALUE;

    /** 	if public_include then*/
    if (_60public_include_23940 == 0)
    {
        goto L1; // [38] 339
    }
    else{
    }

    /** 		sequence add_public = file_include_by[from_file]*/
    DeRef(_add_public_24704);
    _2 = (int)SEQ_PTR(_27file_include_by_10936);
    _add_public_24704 = (int)*(((s1_ptr)_2)->base + _from_file_24694);
    Ref(_add_public_24704);

    /** 		for i = 1 to length( add_public ) do*/
    if (IS_SEQUENCE(_add_public_24704)){
            _14104 = SEQ_PTR(_add_public_24704)->length;
    }
    else {
        _14104 = 1;
    }
    {
        int _i_24708;
        _i_24708 = 1;
L2: 
        if (_i_24708 > _14104){
            goto L3; // [56] 107
        }

        /** 			include_matrix[add_public[i]][included_file] =*/
        _2 = (int)SEQ_PTR(_add_public_24704);
        _14105 = (int)*(((s1_ptr)_2)->base + _i_24708);
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27include_matrix_10928 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14105))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_14105)->dbl));
        else
        _3 = (int)(_14105 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_add_public_24704);
        _14108 = (int)*(((s1_ptr)_2)->base + _i_24708);
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        if (!IS_ATOM_INT(_14108)){
            _14109 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14108)->dbl));
        }
        else{
            _14109 = (int)*(((s1_ptr)_2)->base + _14108);
        }
        _2 = (int)SEQ_PTR(_14109);
        _14110 = (int)*(((s1_ptr)_2)->base + _included_file_24693);
        _14109 = NOVALUE;
        if (IS_ATOM_INT(_14110)) {
            {unsigned long tu;
                 tu = (unsigned long)4 | (unsigned long)_14110;
                 _14111 = MAKE_UINT(tu);
            }
        }
        else {
            _14111 = binary_op(OR_BITS, 4, _14110);
        }
        _14110 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _included_file_24693);
        _1 = *(int *)_2;
        *(int *)_2 = _14111;
        if( _1 != _14111 ){
            DeRef(_1);
        }
        _14111 = NOVALUE;
        _14106 = NOVALUE;

        /** 		end for*/
        _i_24708 = _i_24708 + 1;
        goto L2; // [102] 63
L3: 
        ;
    }

    /** 		add_public = file_public_by[from_file]*/
    DeRef(_add_public_24704);
    _2 = (int)SEQ_PTR(_27file_public_by_10938);
    _add_public_24704 = (int)*(((s1_ptr)_2)->base + _from_file_24694);
    Ref(_add_public_24704);

    /** 		integer px = length( add_public ) + 1*/
    if (IS_SEQUENCE(_add_public_24704)){
            _14113 = SEQ_PTR(_add_public_24704)->length;
    }
    else {
        _14113 = 1;
    }
    _px_24722 = _14113 + 1;
    _14113 = NOVALUE;

    /** 		while px <= length( add_public ) do*/
L4: 
    if (IS_SEQUENCE(_add_public_24704)){
            _14115 = SEQ_PTR(_add_public_24704)->length;
    }
    else {
        _14115 = 1;
    }
    if (_px_24722 > _14115)
    goto L5; // [134] 338

    /** 			include_matrix[add_public[px]][included_file] =*/
    _2 = (int)SEQ_PTR(_add_public_24704);
    _14117 = (int)*(((s1_ptr)_2)->base + _px_24722);
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27include_matrix_10928 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14117))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_14117)->dbl));
    else
    _3 = (int)(_14117 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_add_public_24704);
    _14120 = (int)*(((s1_ptr)_2)->base + _px_24722);
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    if (!IS_ATOM_INT(_14120)){
        _14121 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14120)->dbl));
    }
    else{
        _14121 = (int)*(((s1_ptr)_2)->base + _14120);
    }
    _2 = (int)SEQ_PTR(_14121);
    _14122 = (int)*(((s1_ptr)_2)->base + _included_file_24693);
    _14121 = NOVALUE;
    if (IS_ATOM_INT(_14122)) {
        {unsigned long tu;
             tu = (unsigned long)4 | (unsigned long)_14122;
             _14123 = MAKE_UINT(tu);
        }
    }
    else {
        _14123 = binary_op(OR_BITS, 4, _14122);
    }
    _14122 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24693);
    _1 = *(int *)_2;
    *(int *)_2 = _14123;
    if( _1 != _14123 ){
        DeRef(_1);
    }
    _14123 = NOVALUE;
    _14118 = NOVALUE;

    /** 			for i = 1 to length( file_public_by[add_public[px]] ) do*/
    _2 = (int)SEQ_PTR(_add_public_24704);
    _14124 = (int)*(((s1_ptr)_2)->base + _px_24722);
    _2 = (int)SEQ_PTR(_27file_public_by_10938);
    if (!IS_ATOM_INT(_14124)){
        _14125 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14124)->dbl));
    }
    else{
        _14125 = (int)*(((s1_ptr)_2)->base + _14124);
    }
    if (IS_SEQUENCE(_14125)){
            _14126 = SEQ_PTR(_14125)->length;
    }
    else {
        _14126 = 1;
    }
    _14125 = NOVALUE;
    {
        int _i_24739;
        _i_24739 = 1;
L6: 
        if (_i_24739 > _14126){
            goto L7; // [190] 249
        }

        /** 				if not find( file_public[add_public[px]][i], add_public ) then*/
        _2 = (int)SEQ_PTR(_add_public_24704);
        _14127 = (int)*(((s1_ptr)_2)->base + _px_24722);
        _2 = (int)SEQ_PTR(_27file_public_10934);
        if (!IS_ATOM_INT(_14127)){
            _14128 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14127)->dbl));
        }
        else{
            _14128 = (int)*(((s1_ptr)_2)->base + _14127);
        }
        _2 = (int)SEQ_PTR(_14128);
        _14129 = (int)*(((s1_ptr)_2)->base + _i_24739);
        _14128 = NOVALUE;
        _14130 = find_from(_14129, _add_public_24704, 1);
        _14129 = NOVALUE;
        if (_14130 != 0)
        goto L8; // [218] 242
        _14130 = NOVALUE;

        /** 					add_public &= file_public[add_public[px]][i]*/
        _2 = (int)SEQ_PTR(_add_public_24704);
        _14132 = (int)*(((s1_ptr)_2)->base + _px_24722);
        _2 = (int)SEQ_PTR(_27file_public_10934);
        if (!IS_ATOM_INT(_14132)){
            _14133 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14132)->dbl));
        }
        else{
            _14133 = (int)*(((s1_ptr)_2)->base + _14132);
        }
        _2 = (int)SEQ_PTR(_14133);
        _14134 = (int)*(((s1_ptr)_2)->base + _i_24739);
        _14133 = NOVALUE;
        if (IS_SEQUENCE(_add_public_24704) && IS_ATOM(_14134)) {
            Ref(_14134);
            Append(&_add_public_24704, _add_public_24704, _14134);
        }
        else if (IS_ATOM(_add_public_24704) && IS_SEQUENCE(_14134)) {
        }
        else {
            Concat((object_ptr)&_add_public_24704, _add_public_24704, _14134);
        }
        _14134 = NOVALUE;
L8: 

        /** 			end for*/
        _i_24739 = _i_24739 + 1;
        goto L6; // [244] 197
L7: 
        ;
    }

    /** 			for i = 1 to length( file_include_by[add_public[px]] ) do*/
    _2 = (int)SEQ_PTR(_add_public_24704);
    _14136 = (int)*(((s1_ptr)_2)->base + _px_24722);
    _2 = (int)SEQ_PTR(_27file_include_by_10936);
    if (!IS_ATOM_INT(_14136)){
        _14137 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14136)->dbl));
    }
    else{
        _14137 = (int)*(((s1_ptr)_2)->base + _14136);
    }
    if (IS_SEQUENCE(_14137)){
            _14138 = SEQ_PTR(_14137)->length;
    }
    else {
        _14138 = 1;
    }
    _14137 = NOVALUE;
    {
        int _i_24757;
        _i_24757 = 1;
L9: 
        if (_i_24757 > _14138){
            goto LA; // [264] 327
        }

        /** 				include_matrix[file_include_by[add_public[px]]][included_file] =*/
        _2 = (int)SEQ_PTR(_add_public_24704);
        _14139 = (int)*(((s1_ptr)_2)->base + _px_24722);
        _2 = (int)SEQ_PTR(_27file_include_by_10936);
        if (!IS_ATOM_INT(_14139)){
            _14140 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14139)->dbl));
        }
        else{
            _14140 = (int)*(((s1_ptr)_2)->base + _14139);
        }
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27include_matrix_10928 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14140))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_14140)->dbl));
        else
        _3 = (int)(_14140 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_add_public_24704);
        _14143 = (int)*(((s1_ptr)_2)->base + _px_24722);
        _2 = (int)SEQ_PTR(_27file_include_by_10936);
        if (!IS_ATOM_INT(_14143)){
            _14144 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14143)->dbl));
        }
        else{
            _14144 = (int)*(((s1_ptr)_2)->base + _14143);
        }
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        if (!IS_ATOM_INT(_14144)){
            _14145 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14144)->dbl));
        }
        else{
            _14145 = (int)*(((s1_ptr)_2)->base + _14144);
        }
        _2 = (int)SEQ_PTR(_14145);
        _14146 = (int)*(((s1_ptr)_2)->base + _included_file_24693);
        _14145 = NOVALUE;
        if (IS_ATOM_INT(_14146)) {
            {unsigned long tu;
                 tu = (unsigned long)4 | (unsigned long)_14146;
                 _14147 = MAKE_UINT(tu);
            }
        }
        else {
            _14147 = binary_op(OR_BITS, 4, _14146);
        }
        _14146 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _included_file_24693);
        _1 = *(int *)_2;
        *(int *)_2 = _14147;
        if( _1 != _14147 ){
            DeRef(_1);
        }
        _14147 = NOVALUE;
        _14141 = NOVALUE;

        /** 			end for*/
        _i_24757 = _i_24757 + 1;
        goto L9; // [322] 271
LA: 
        ;
    }

    /** 			px += 1*/
    _px_24722 = _px_24722 + 1;

    /** 		end while*/
    goto L4; // [335] 131
L5: 
L1: 
    DeRef(_add_public_24704);
    _add_public_24704 = NOVALUE;

    /** 	if indirect_include[from_file][included_file] then*/
    _2 = (int)SEQ_PTR(_27indirect_include_10931);
    _14149 = (int)*(((s1_ptr)_2)->base + _from_file_24694);
    _2 = (int)SEQ_PTR(_14149);
    _14150 = (int)*(((s1_ptr)_2)->base + _included_file_24693);
    _14149 = NOVALUE;
    if (_14150 == 0) {
        _14150 = NOVALUE;
        goto LB; // [353] 545
    }
    else {
        if (!IS_ATOM_INT(_14150) && DBL_PTR(_14150)->dbl == 0.0){
            _14150 = NOVALUE;
            goto LB; // [353] 545
        }
        _14150 = NOVALUE;
    }
    _14150 = NOVALUE;

    /** 		sequence indirect = file_include_by[from_file]*/
    DeRef(_indirect_24781);
    _2 = (int)SEQ_PTR(_27file_include_by_10936);
    _indirect_24781 = (int)*(((s1_ptr)_2)->base + _from_file_24694);
    Ref(_indirect_24781);

    /** 		sequence mask = include_matrix[included_file] != 0*/
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _14152 = (int)*(((s1_ptr)_2)->base + _included_file_24693);
    DeRef(_mask_24784);
    if (IS_ATOM_INT(_14152)) {
        _mask_24784 = (_14152 != 0);
    }
    else {
        _mask_24784 = binary_op(NOTEQ, _14152, 0);
    }
    _14152 = NOVALUE;

    /** 		include_matrix[from_file] = or_bits( include_matrix[from_file], mask )*/
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _14154 = (int)*(((s1_ptr)_2)->base + _from_file_24694);
    _14155 = binary_op(OR_BITS, _14154, _mask_24784);
    _14154 = NOVALUE;
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _2 = (int)(((s1_ptr)_2)->base + _from_file_24694);
    _1 = *(int *)_2;
    *(int *)_2 = _14155;
    if( _1 != _14155 ){
        DeRef(_1);
    }
    _14155 = NOVALUE;

    /** 		mask = include_matrix[from_file] != 0*/
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _14156 = (int)*(((s1_ptr)_2)->base + _from_file_24694);
    DeRefDS(_mask_24784);
    if (IS_ATOM_INT(_14156)) {
        _mask_24784 = (_14156 != 0);
    }
    else {
        _mask_24784 = binary_op(NOTEQ, _14156, 0);
    }
    _14156 = NOVALUE;

    /** 		integer ix = 1*/
    _ix_24795 = 1;

    /** 		while ix <= length(indirect) do*/
LC: 
    if (IS_SEQUENCE(_indirect_24781)){
            _14158 = SEQ_PTR(_indirect_24781)->length;
    }
    else {
        _14158 = 1;
    }
    if (_ix_24795 > _14158)
    goto LD; // [425] 544

    /** 			integer indirect_file = indirect[ix]*/
    _2 = (int)SEQ_PTR(_indirect_24781);
    _indirect_file_24799 = (int)*(((s1_ptr)_2)->base + _ix_24795);
    if (!IS_ATOM_INT(_indirect_file_24799))
    _indirect_file_24799 = (long)DBL_PTR(_indirect_file_24799)->dbl;

    /** 			if indirect_include[indirect_file][included_file] then*/
    _2 = (int)SEQ_PTR(_27indirect_include_10931);
    _14161 = (int)*(((s1_ptr)_2)->base + _indirect_file_24799);
    _2 = (int)SEQ_PTR(_14161);
    _14162 = (int)*(((s1_ptr)_2)->base + _included_file_24693);
    _14161 = NOVALUE;
    if (_14162 == 0) {
        _14162 = NOVALUE;
        goto LE; // [447] 531
    }
    else {
        if (!IS_ATOM_INT(_14162) && DBL_PTR(_14162)->dbl == 0.0){
            _14162 = NOVALUE;
            goto LE; // [447] 531
        }
        _14162 = NOVALUE;
    }
    _14162 = NOVALUE;

    /** 				include_matrix[indirect_file] =*/
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _14163 = (int)*(((s1_ptr)_2)->base + _indirect_file_24799);
    _14164 = binary_op(OR_BITS, _mask_24784, _14163);
    _14163 = NOVALUE;
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _2 = (int)(((s1_ptr)_2)->base + _indirect_file_24799);
    _1 = *(int *)_2;
    *(int *)_2 = _14164;
    if( _1 != _14164 ){
        DeRef(_1);
    }
    _14164 = NOVALUE;

    /** 				for i = 1 to length( file_include_by[indirect_file] ) do*/
    _2 = (int)SEQ_PTR(_27file_include_by_10936);
    _14165 = (int)*(((s1_ptr)_2)->base + _indirect_file_24799);
    if (IS_SEQUENCE(_14165)){
            _14166 = SEQ_PTR(_14165)->length;
    }
    else {
        _14166 = 1;
    }
    _14165 = NOVALUE;
    {
        int _i_24810;
        _i_24810 = 1;
LF: 
        if (_i_24810 > _14166){
            goto L10; // [479] 530
        }

        /** 					if not find( file_include_by[indirect_file][i], indirect ) then*/
        _2 = (int)SEQ_PTR(_27file_include_by_10936);
        _14167 = (int)*(((s1_ptr)_2)->base + _indirect_file_24799);
        _2 = (int)SEQ_PTR(_14167);
        _14168 = (int)*(((s1_ptr)_2)->base + _i_24810);
        _14167 = NOVALUE;
        _14169 = find_from(_14168, _indirect_24781, 1);
        _14168 = NOVALUE;
        if (_14169 != 0)
        goto L11; // [503] 523
        _14169 = NOVALUE;

        /** 						indirect &= file_include_by[indirect_file][i]*/
        _2 = (int)SEQ_PTR(_27file_include_by_10936);
        _14171 = (int)*(((s1_ptr)_2)->base + _indirect_file_24799);
        _2 = (int)SEQ_PTR(_14171);
        _14172 = (int)*(((s1_ptr)_2)->base + _i_24810);
        _14171 = NOVALUE;
        if (IS_SEQUENCE(_indirect_24781) && IS_ATOM(_14172)) {
            Ref(_14172);
            Append(&_indirect_24781, _indirect_24781, _14172);
        }
        else if (IS_ATOM(_indirect_24781) && IS_SEQUENCE(_14172)) {
        }
        else {
            Concat((object_ptr)&_indirect_24781, _indirect_24781, _14172);
        }
        _14172 = NOVALUE;
L11: 

        /** 				end for*/
        _i_24810 = _i_24810 + 1;
        goto LF; // [525] 486
L10: 
        ;
    }
LE: 

    /** 			ix += 1*/
    _ix_24795 = _ix_24795 + 1;

    /** 		end while*/
    goto LC; // [541] 422
LD: 
LB: 
    DeRef(_indirect_24781);
    _indirect_24781 = NOVALUE;
    DeRef(_mask_24784);
    _mask_24784 = NOVALUE;

    /** 	public_include = FALSE*/
    _60public_include_23940 = _9FALSE_428;

    /** end procedure*/
    _14105 = NOVALUE;
    _14117 = NOVALUE;
    _14108 = NOVALUE;
    _14124 = NOVALUE;
    _14120 = NOVALUE;
    _14125 = NOVALUE;
    _14127 = NOVALUE;
    _14132 = NOVALUE;
    _14136 = NOVALUE;
    _14137 = NOVALUE;
    _14139 = NOVALUE;
    _14140 = NOVALUE;
    _14165 = NOVALUE;
    _14143 = NOVALUE;
    _14144 = NOVALUE;
    return;
    ;
}


void _60add_include_by(int _by_file_24828, int _included_file_24829, int _is_public_24830)
{
    int _14219 = NOVALUE;
    int _14218 = NOVALUE;
    int _14217 = NOVALUE;
    int _14215 = NOVALUE;
    int _14214 = NOVALUE;
    int _14213 = NOVALUE;
    int _14212 = NOVALUE;
    int _14210 = NOVALUE;
    int _14209 = NOVALUE;
    int _14208 = NOVALUE;
    int _14207 = NOVALUE;
    int _14206 = NOVALUE;
    int _14205 = NOVALUE;
    int _14204 = NOVALUE;
    int _14203 = NOVALUE;
    int _14201 = NOVALUE;
    int _14200 = NOVALUE;
    int _14199 = NOVALUE;
    int _14198 = NOVALUE;
    int _14196 = NOVALUE;
    int _14195 = NOVALUE;
    int _14194 = NOVALUE;
    int _14193 = NOVALUE;
    int _14191 = NOVALUE;
    int _14190 = NOVALUE;
    int _14189 = NOVALUE;
    int _14188 = NOVALUE;
    int _14186 = NOVALUE;
    int _14185 = NOVALUE;
    int _14184 = NOVALUE;
    int _14183 = NOVALUE;
    int _14182 = NOVALUE;
    int _14180 = NOVALUE;
    int _14179 = NOVALUE;
    int _14178 = NOVALUE;
    int _14177 = NOVALUE;
    int _14175 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	include_matrix[by_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27include_matrix_10928 = MAKE_SEQ(_2);
    }
    _3 = (int)(_by_file_24828 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _14177 = (int)*(((s1_ptr)_2)->base + _by_file_24828);
    _2 = (int)SEQ_PTR(_14177);
    _14178 = (int)*(((s1_ptr)_2)->base + _included_file_24829);
    _14177 = NOVALUE;
    if (IS_ATOM_INT(_14178)) {
        {unsigned long tu;
             tu = (unsigned long)2 | (unsigned long)_14178;
             _14179 = MAKE_UINT(tu);
        }
    }
    else {
        _14179 = binary_op(OR_BITS, 2, _14178);
    }
    _14178 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24829);
    _1 = *(int *)_2;
    *(int *)_2 = _14179;
    if( _1 != _14179 ){
        DeRef(_1);
    }
    _14179 = NOVALUE;
    _14175 = NOVALUE;

    /** 	if is_public then*/
    if (_is_public_24830 == 0)
    {
        goto L1; // [38] 71
    }
    else{
    }

    /** 		include_matrix[by_file][included_file] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27include_matrix_10928 = MAKE_SEQ(_2);
    }
    _3 = (int)(_by_file_24828 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _14182 = (int)*(((s1_ptr)_2)->base + _by_file_24828);
    _2 = (int)SEQ_PTR(_14182);
    _14183 = (int)*(((s1_ptr)_2)->base + _included_file_24829);
    _14182 = NOVALUE;
    if (IS_ATOM_INT(_14183)) {
        {unsigned long tu;
             tu = (unsigned long)4 | (unsigned long)_14183;
             _14184 = MAKE_UINT(tu);
        }
    }
    else {
        _14184 = binary_op(OR_BITS, 4, _14183);
    }
    _14183 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24829);
    _1 = *(int *)_2;
    *(int *)_2 = _14184;
    if( _1 != _14184 ){
        DeRef(_1);
    }
    _14184 = NOVALUE;
    _14180 = NOVALUE;
L1: 

    /** 	if not find( by_file, file_include_by[included_file] ) then*/
    _2 = (int)SEQ_PTR(_27file_include_by_10936);
    _14185 = (int)*(((s1_ptr)_2)->base + _included_file_24829);
    _14186 = find_from(_by_file_24828, _14185, 1);
    _14185 = NOVALUE;
    if (_14186 != 0)
    goto L2; // [84] 104
    _14186 = NOVALUE;

    /** 		file_include_by[included_file] &= by_file*/
    _2 = (int)SEQ_PTR(_27file_include_by_10936);
    _14188 = (int)*(((s1_ptr)_2)->base + _included_file_24829);
    if (IS_SEQUENCE(_14188) && IS_ATOM(_by_file_24828)) {
        Append(&_14189, _14188, _by_file_24828);
    }
    else if (IS_ATOM(_14188) && IS_SEQUENCE(_by_file_24828)) {
    }
    else {
        Concat((object_ptr)&_14189, _14188, _by_file_24828);
        _14188 = NOVALUE;
    }
    _14188 = NOVALUE;
    _2 = (int)SEQ_PTR(_27file_include_by_10936);
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24829);
    _1 = *(int *)_2;
    *(int *)_2 = _14189;
    if( _1 != _14189 ){
        DeRef(_1);
    }
    _14189 = NOVALUE;
L2: 

    /** 	if not find( included_file, file_include[by_file] ) then*/
    _2 = (int)SEQ_PTR(_27file_include_10926);
    _14190 = (int)*(((s1_ptr)_2)->base + _by_file_24828);
    _14191 = find_from(_included_file_24829, _14190, 1);
    _14190 = NOVALUE;
    if (_14191 != 0)
    goto L3; // [117] 137
    _14191 = NOVALUE;

    /** 		file_include[by_file] &= included_file*/
    _2 = (int)SEQ_PTR(_27file_include_10926);
    _14193 = (int)*(((s1_ptr)_2)->base + _by_file_24828);
    if (IS_SEQUENCE(_14193) && IS_ATOM(_included_file_24829)) {
        Append(&_14194, _14193, _included_file_24829);
    }
    else if (IS_ATOM(_14193) && IS_SEQUENCE(_included_file_24829)) {
    }
    else {
        Concat((object_ptr)&_14194, _14193, _included_file_24829);
        _14193 = NOVALUE;
    }
    _14193 = NOVALUE;
    _2 = (int)SEQ_PTR(_27file_include_10926);
    _2 = (int)(((s1_ptr)_2)->base + _by_file_24828);
    _1 = *(int *)_2;
    *(int *)_2 = _14194;
    if( _1 != _14194 ){
        DeRef(_1);
    }
    _14194 = NOVALUE;
L3: 

    /** 	if is_public then*/
    if (_is_public_24830 == 0)
    {
        goto L4; // [139] 209
    }
    else{
    }

    /** 		if not find( by_file, file_public_by[included_file] ) then*/
    _2 = (int)SEQ_PTR(_27file_public_by_10938);
    _14195 = (int)*(((s1_ptr)_2)->base + _included_file_24829);
    _14196 = find_from(_by_file_24828, _14195, 1);
    _14195 = NOVALUE;
    if (_14196 != 0)
    goto L5; // [155] 175
    _14196 = NOVALUE;

    /** 			file_public_by[included_file] &= by_file*/
    _2 = (int)SEQ_PTR(_27file_public_by_10938);
    _14198 = (int)*(((s1_ptr)_2)->base + _included_file_24829);
    if (IS_SEQUENCE(_14198) && IS_ATOM(_by_file_24828)) {
        Append(&_14199, _14198, _by_file_24828);
    }
    else if (IS_ATOM(_14198) && IS_SEQUENCE(_by_file_24828)) {
    }
    else {
        Concat((object_ptr)&_14199, _14198, _by_file_24828);
        _14198 = NOVALUE;
    }
    _14198 = NOVALUE;
    _2 = (int)SEQ_PTR(_27file_public_by_10938);
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24829);
    _1 = *(int *)_2;
    *(int *)_2 = _14199;
    if( _1 != _14199 ){
        DeRef(_1);
    }
    _14199 = NOVALUE;
L5: 

    /** 		if not find( included_file, file_public[by_file] ) then*/
    _2 = (int)SEQ_PTR(_27file_public_10934);
    _14200 = (int)*(((s1_ptr)_2)->base + _by_file_24828);
    _14201 = find_from(_included_file_24829, _14200, 1);
    _14200 = NOVALUE;
    if (_14201 != 0)
    goto L6; // [188] 208
    _14201 = NOVALUE;

    /** 			file_public[by_file] &= included_file*/
    _2 = (int)SEQ_PTR(_27file_public_10934);
    _14203 = (int)*(((s1_ptr)_2)->base + _by_file_24828);
    if (IS_SEQUENCE(_14203) && IS_ATOM(_included_file_24829)) {
        Append(&_14204, _14203, _included_file_24829);
    }
    else if (IS_ATOM(_14203) && IS_SEQUENCE(_included_file_24829)) {
    }
    else {
        Concat((object_ptr)&_14204, _14203, _included_file_24829);
        _14203 = NOVALUE;
    }
    _14203 = NOVALUE;
    _2 = (int)SEQ_PTR(_27file_public_10934);
    _2 = (int)(((s1_ptr)_2)->base + _by_file_24828);
    _1 = *(int *)_2;
    *(int *)_2 = _14204;
    if( _1 != _14204 ){
        DeRef(_1);
    }
    _14204 = NOVALUE;
L6: 
L4: 

    /** 	for propagate = 1 to length( include_matrix[included_file] ) do*/
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _14205 = (int)*(((s1_ptr)_2)->base + _included_file_24829);
    if (IS_SEQUENCE(_14205)){
            _14206 = SEQ_PTR(_14205)->length;
    }
    else {
        _14206 = 1;
    }
    _14205 = NOVALUE;
    {
        int _propagate_24882;
        _propagate_24882 = 1;
L7: 
        if (_propagate_24882 > _14206){
            goto L8; // [220] 320
        }

        /** 		if and_bits( PUBLIC_INCLUDE, include_matrix[included_file][propagate] ) then*/
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        _14207 = (int)*(((s1_ptr)_2)->base + _included_file_24829);
        _2 = (int)SEQ_PTR(_14207);
        _14208 = (int)*(((s1_ptr)_2)->base + _propagate_24882);
        _14207 = NOVALUE;
        if (IS_ATOM_INT(_14208)) {
            {unsigned long tu;
                 tu = (unsigned long)4 & (unsigned long)_14208;
                 _14209 = MAKE_UINT(tu);
            }
        }
        else {
            _14209 = binary_op(AND_BITS, 4, _14208);
        }
        _14208 = NOVALUE;
        if (_14209 == 0) {
            DeRef(_14209);
            _14209 = NOVALUE;
            goto L9; // [245] 313
        }
        else {
            if (!IS_ATOM_INT(_14209) && DBL_PTR(_14209)->dbl == 0.0){
                DeRef(_14209);
                _14209 = NOVALUE;
                goto L9; // [245] 313
            }
            DeRef(_14209);
            _14209 = NOVALUE;
        }
        DeRef(_14209);
        _14209 = NOVALUE;

        /** 			include_matrix[by_file][propagate] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27include_matrix_10928 = MAKE_SEQ(_2);
        }
        _3 = (int)(_by_file_24828 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        _14212 = (int)*(((s1_ptr)_2)->base + _by_file_24828);
        _2 = (int)SEQ_PTR(_14212);
        _14213 = (int)*(((s1_ptr)_2)->base + _propagate_24882);
        _14212 = NOVALUE;
        if (IS_ATOM_INT(_14213)) {
            {unsigned long tu;
                 tu = (unsigned long)2 | (unsigned long)_14213;
                 _14214 = MAKE_UINT(tu);
            }
        }
        else {
            _14214 = binary_op(OR_BITS, 2, _14213);
        }
        _14213 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _propagate_24882);
        _1 = *(int *)_2;
        *(int *)_2 = _14214;
        if( _1 != _14214 ){
            DeRef(_1);
        }
        _14214 = NOVALUE;
        _14210 = NOVALUE;

        /** 			if is_public then*/
        if (_is_public_24830 == 0)
        {
            goto LA; // [279] 312
        }
        else{
        }

        /** 				include_matrix[by_file][propagate] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27include_matrix_10928 = MAKE_SEQ(_2);
        }
        _3 = (int)(_by_file_24828 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        _14217 = (int)*(((s1_ptr)_2)->base + _by_file_24828);
        _2 = (int)SEQ_PTR(_14217);
        _14218 = (int)*(((s1_ptr)_2)->base + _propagate_24882);
        _14217 = NOVALUE;
        if (IS_ATOM_INT(_14218)) {
            {unsigned long tu;
                 tu = (unsigned long)4 | (unsigned long)_14218;
                 _14219 = MAKE_UINT(tu);
            }
        }
        else {
            _14219 = binary_op(OR_BITS, 4, _14218);
        }
        _14218 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _propagate_24882);
        _1 = *(int *)_2;
        *(int *)_2 = _14219;
        if( _1 != _14219 ){
            DeRef(_1);
        }
        _14219 = NOVALUE;
        _14215 = NOVALUE;
LA: 
L9: 

        /** 	end for*/
        _propagate_24882 = _propagate_24882 + 1;
        goto L7; // [315] 227
L8: 
        ;
    }

    /** end procedure*/
    _14205 = NOVALUE;
    return;
    ;
}


void _60IncludePush()
{
    int _new_file_handle_24911 = NOVALUE;
    int _old_file_no_24912 = NOVALUE;
    int _new_hash_24913 = NOVALUE;
    int _idx_24914 = NOVALUE;
    int _14306 = NOVALUE;
    int _14303 = NOVALUE;
    int _14301 = NOVALUE;
    int _14300 = NOVALUE;
    int _14299 = NOVALUE;
    int _14297 = NOVALUE;
    int _14296 = NOVALUE;
    int _14290 = NOVALUE;
    int _14289 = NOVALUE;
    int _14288 = NOVALUE;
    int _14287 = NOVALUE;
    int _14286 = NOVALUE;
    int _14285 = NOVALUE;
    int _14284 = NOVALUE;
    int _14281 = NOVALUE;
    int _14279 = NOVALUE;
    int _14277 = NOVALUE;
    int _14276 = NOVALUE;
    int _14275 = NOVALUE;
    int _14273 = NOVALUE;
    int _14272 = NOVALUE;
    int _14270 = NOVALUE;
    int _14269 = NOVALUE;
    int _14267 = NOVALUE;
    int _14266 = NOVALUE;
    int _14265 = NOVALUE;
    int _14264 = NOVALUE;
    int _14263 = NOVALUE;
    int _14262 = NOVALUE;
    int _14261 = NOVALUE;
    int _14257 = NOVALUE;
    int _14255 = NOVALUE;
    int _14254 = NOVALUE;
    int _14253 = NOVALUE;
    int _14252 = NOVALUE;
    int _14251 = NOVALUE;
    int _14250 = NOVALUE;
    int _14249 = NOVALUE;
    int _14248 = NOVALUE;
    int _14247 = NOVALUE;
    int _14245 = NOVALUE;
    int _14244 = NOVALUE;
    int _14243 = NOVALUE;
    int _14241 = NOVALUE;
    int _14240 = NOVALUE;
    int _14239 = NOVALUE;
    int _14238 = NOVALUE;
    int _14236 = NOVALUE;
    int _14235 = NOVALUE;
    int _14234 = NOVALUE;
    int _14233 = NOVALUE;
    int _14232 = NOVALUE;
    int _14230 = NOVALUE;
    int _14229 = NOVALUE;
    int _14228 = NOVALUE;
    int _14227 = NOVALUE;
    int _14225 = NOVALUE;
    int _14221 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	start_include = FALSE*/
    _60start_include_23937 = _9FALSE_428;

    /** 	new_file_handle = path_open() -- sets new_include_name to full path*/
    _new_file_handle_24911 = _60path_open();
    if (!IS_ATOM_INT(_new_file_handle_24911)) {
        _1 = (long)(DBL_PTR(_new_file_handle_24911)->dbl);
        DeRefDS(_new_file_handle_24911);
        _new_file_handle_24911 = _1;
    }

    /** 	new_hash = hash(canonical_path(new_include_name,,CORRECT), stdhash:HSIEH32)*/
    RefDS(_26new_include_name_12105);
    _14221 = _15canonical_path(_26new_include_name_12105, 0, 2);
    DeRef(_new_hash_24913);
    _new_hash_24913 = calc_hash(_14221, -5);
    DeRef(_14221);
    _14221 = NOVALUE;

    /** 	idx = find(new_hash, known_files_hash)*/
    _idx_24914 = find_from(_new_hash_24913, _27known_files_hash_10923, 1);

    /** 	if idx then*/
    if (_idx_24914 == 0)
    {
        goto L1; // [42] 335
    }
    else{
    }

    /** 		if new_include_space != 0 then*/
    if (_60new_include_space_23935 == 0)
    goto L2; // [49] 71

    /** 			SymTab[new_include_space][S_OBJ] = idx -- but note any namespace*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_60new_include_space_23935 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _idx_24914;
    DeRef(_1);
    _14225 = NOVALUE;
L2: 

    /** 		close(new_file_handle)*/
    EClose(_new_file_handle_24911);

    /** 		if find( -idx, file_include[current_file_no] ) then*/
    if ((unsigned long)_idx_24914 == 0xC0000000)
    _14227 = (int)NewDouble((double)-0xC0000000);
    else
    _14227 = - _idx_24914;
    _2 = (int)SEQ_PTR(_27file_include_10926);
    _14228 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    _14229 = find_from(_14227, _14228, 1);
    DeRef(_14227);
    _14227 = NOVALUE;
    _14228 = NOVALUE;
    if (_14229 == 0)
    {
        _14229 = NOVALUE;
        goto L3; // [93] 130
    }
    else{
        _14229 = NOVALUE;
    }

    /** 			file_include[current_file_no][ find( -idx, file_include[current_file_no] ) ] = idx*/
    _2 = (int)SEQ_PTR(_27file_include_10926);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27file_include_10926 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26current_file_no_11982 + ((s1_ptr)_2)->base);
    if ((unsigned long)_idx_24914 == 0xC0000000)
    _14232 = (int)NewDouble((double)-0xC0000000);
    else
    _14232 = - _idx_24914;
    _2 = (int)SEQ_PTR(_27file_include_10926);
    _14233 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    _14234 = find_from(_14232, _14233, 1);
    DeRef(_14232);
    _14232 = NOVALUE;
    _14233 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _14234);
    _1 = *(int *)_2;
    *(int *)_2 = _idx_24914;
    DeRef(_1);
    _14230 = NOVALUE;
    goto L4; // [127] 228
L3: 

    /** 		elsif not find( idx, file_include[current_file_no] ) then*/
    _2 = (int)SEQ_PTR(_27file_include_10926);
    _14235 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    _14236 = find_from(_idx_24914, _14235, 1);
    _14235 = NOVALUE;
    if (_14236 != 0)
    goto L5; // [145] 227
    _14236 = NOVALUE;

    /** 			file_include[current_file_no] &= idx*/
    _2 = (int)SEQ_PTR(_27file_include_10926);
    _14238 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    if (IS_SEQUENCE(_14238) && IS_ATOM(_idx_24914)) {
        Append(&_14239, _14238, _idx_24914);
    }
    else if (IS_ATOM(_14238) && IS_SEQUENCE(_idx_24914)) {
    }
    else {
        Concat((object_ptr)&_14239, _14238, _idx_24914);
        _14238 = NOVALUE;
    }
    _14238 = NOVALUE;
    _2 = (int)SEQ_PTR(_27file_include_10926);
    _2 = (int)(((s1_ptr)_2)->base + _26current_file_no_11982);
    _1 = *(int *)_2;
    *(int *)_2 = _14239;
    if( _1 != _14239 ){
        DeRef(_1);
    }
    _14239 = NOVALUE;

    /** 			add_exports( idx, current_file_no )*/
    _60add_exports(_idx_24914, _26current_file_no_11982);

    /** 			if public_include then*/
    if (_60public_include_23940 == 0)
    {
        goto L6; // [178] 226
    }
    else{
    }

    /** 				if not find( idx, file_public[current_file_no] ) then*/
    _2 = (int)SEQ_PTR(_27file_public_10934);
    _14240 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    _14241 = find_from(_idx_24914, _14240, 1);
    _14240 = NOVALUE;
    if (_14241 != 0)
    goto L7; // [196] 225
    _14241 = NOVALUE;

    /** 					file_public[current_file_no] &= idx*/
    _2 = (int)SEQ_PTR(_27file_public_10934);
    _14243 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    if (IS_SEQUENCE(_14243) && IS_ATOM(_idx_24914)) {
        Append(&_14244, _14243, _idx_24914);
    }
    else if (IS_ATOM(_14243) && IS_SEQUENCE(_idx_24914)) {
    }
    else {
        Concat((object_ptr)&_14244, _14243, _idx_24914);
        _14243 = NOVALUE;
    }
    _14243 = NOVALUE;
    _2 = (int)SEQ_PTR(_27file_public_10934);
    _2 = (int)(((s1_ptr)_2)->base + _26current_file_no_11982);
    _1 = *(int *)_2;
    *(int *)_2 = _14244;
    if( _1 != _14244 ){
        DeRef(_1);
    }
    _14244 = NOVALUE;

    /** 					patch_exports( current_file_no )*/
    _60patch_exports(_26current_file_no_11982);
L7: 
L6: 
L5: 
L4: 

    /** 		indirect_include[current_file_no][idx] = OpIndirectInclude*/
    _2 = (int)SEQ_PTR(_27indirect_include_10931);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27indirect_include_10931 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26current_file_no_11982 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _idx_24914);
    _1 = *(int *)_2;
    *(int *)_2 = _26OpIndirectInclude_12058;
    DeRef(_1);
    _14245 = NOVALUE;

    /** 		add_include_by( current_file_no, idx, public_include )*/
    _60add_include_by(_26current_file_no_11982, _idx_24914, _60public_include_23940);

    /** 		update_include_matrix( idx, current_file_no )*/
    _60update_include_matrix(_idx_24914, _26current_file_no_11982);

    /** 		public_include = FALSE*/
    _60public_include_23940 = _9FALSE_428;

    /** 		read_line() -- we can't return without reading a line first*/
    _60read_line();

    /** 		if not find( idx, file_include_depend[current_file_no] ) and not finished_files[idx] then*/
    _2 = (int)SEQ_PTR(_27file_include_depend_10925);
    _14247 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    _14248 = find_from(_idx_24914, _14247, 1);
    _14247 = NOVALUE;
    _14249 = (_14248 == 0);
    _14248 = NOVALUE;
    if (_14249 == 0) {
        goto L8; // [293] 329
    }
    _2 = (int)SEQ_PTR(_27finished_files_10924);
    _14251 = (int)*(((s1_ptr)_2)->base + _idx_24914);
    _14252 = (_14251 == 0);
    _14251 = NOVALUE;
    if (_14252 == 0)
    {
        DeRef(_14252);
        _14252 = NOVALUE;
        goto L8; // [307] 329
    }
    else{
        DeRef(_14252);
        _14252 = NOVALUE;
    }

    /** 			file_include_depend[current_file_no] &= idx*/
    _2 = (int)SEQ_PTR(_27file_include_depend_10925);
    _14253 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    if (IS_SEQUENCE(_14253) && IS_ATOM(_idx_24914)) {
        Append(&_14254, _14253, _idx_24914);
    }
    else if (IS_ATOM(_14253) && IS_SEQUENCE(_idx_24914)) {
    }
    else {
        Concat((object_ptr)&_14254, _14253, _idx_24914);
        _14253 = NOVALUE;
    }
    _14253 = NOVALUE;
    _2 = (int)SEQ_PTR(_27file_include_depend_10925);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27file_include_depend_10925 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _26current_file_no_11982);
    _1 = *(int *)_2;
    *(int *)_2 = _14254;
    if( _1 != _14254 ){
        DeRef(_1);
    }
    _14254 = NOVALUE;
L8: 

    /** 		return -- ignore it*/
    DeRef(_new_hash_24913);
    DeRef(_14249);
    _14249 = NOVALUE;
    return;
L1: 

    /** 	if length(IncludeStk) >= INCLUDE_LIMIT then*/
    if (IS_SEQUENCE(_60IncludeStk_23946)){
            _14255 = SEQ_PTR(_60IncludeStk_23946)->length;
    }
    else {
        _14255 = 1;
    }
    if (_14255 < 30)
    goto L9; // [342] 354

    /** 		CompileErr(104)*/
    RefDS(_22037);
    _43CompileErr(104, _22037, 0);
L9: 

    /** 	IncludeStk = append(IncludeStk,*/
    _1 = NewS1(22);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _26current_file_no_11982;
    *((int *)(_2+8)) = _26line_number_11983;
    *((int *)(_2+12)) = _26src_file_12104;
    *((int *)(_2+16)) = _26file_start_sym_11988;
    *((int *)(_2+20)) = _26OpWarning_12050;
    *((int *)(_2+24)) = _26OpTrace_12052;
    *((int *)(_2+28)) = _26OpTypeCheck_12053;
    *((int *)(_2+32)) = _26OpProfileTime_12055;
    *((int *)(_2+36)) = _26OpProfileStatement_12054;
    RefDS(_26OpDefines_12056);
    *((int *)(_2+40)) = _26OpDefines_12056;
    *((int *)(_2+44)) = _26prev_OpWarning_12051;
    *((int *)(_2+48)) = _26OpInline_12057;
    *((int *)(_2+52)) = _26OpIndirectInclude_12058;
    *((int *)(_2+56)) = _26putback_fwd_line_number_11985;
    Ref(_43putback_ForwardLine_48559);
    *((int *)(_2+60)) = _43putback_ForwardLine_48559;
    *((int *)(_2+64)) = _43putback_forward_bp_48563;
    *((int *)(_2+68)) = _26last_fwd_line_number_11986;
    Ref(_43last_ForwardLine_48560);
    *((int *)(_2+72)) = _43last_ForwardLine_48560;
    *((int *)(_2+76)) = _43last_forward_bp_48564;
    Ref(_43ThisLine_48557);
    *((int *)(_2+80)) = _43ThisLine_48557;
    *((int *)(_2+84)) = _26fwd_line_number_11984;
    *((int *)(_2+88)) = _43forward_bp_48562;
    _14257 = MAKE_SEQ(_1);
    RefDS(_14257);
    Append(&_60IncludeStk_23946, _60IncludeStk_23946, _14257);
    DeRefDS(_14257);
    _14257 = NOVALUE;

    /** 	file_include = append( file_include, {} )*/
    RefDS(_5);
    Append(&_27file_include_10926, _27file_include_10926, _5);

    /** 	file_include_by = append( file_include_by, {} )*/
    RefDS(_5);
    Append(&_27file_include_by_10936, _27file_include_by_10936, _5);

    /** 	for i = 1 to length( include_matrix) do*/
    if (IS_SEQUENCE(_27include_matrix_10928)){
            _14261 = SEQ_PTR(_27include_matrix_10928)->length;
    }
    else {
        _14261 = 1;
    }
    {
        int _i_25026;
        _i_25026 = 1;
LA: 
        if (_i_25026 > _14261){
            goto LB; // [458] 504
        }

        /** 		include_matrix[i]   &= 0*/
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        _14262 = (int)*(((s1_ptr)_2)->base + _i_25026);
        if (IS_SEQUENCE(_14262) && IS_ATOM(0)) {
            Append(&_14263, _14262, 0);
        }
        else if (IS_ATOM(_14262) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_14263, _14262, 0);
            _14262 = NOVALUE;
        }
        _14262 = NOVALUE;
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        _2 = (int)(((s1_ptr)_2)->base + _i_25026);
        _1 = *(int *)_2;
        *(int *)_2 = _14263;
        if( _1 != _14263 ){
            DeRef(_1);
        }
        _14263 = NOVALUE;

        /** 		indirect_include[i] &= 0*/
        _2 = (int)SEQ_PTR(_27indirect_include_10931);
        _14264 = (int)*(((s1_ptr)_2)->base + _i_25026);
        if (IS_SEQUENCE(_14264) && IS_ATOM(0)) {
            Append(&_14265, _14264, 0);
        }
        else if (IS_ATOM(_14264) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_14265, _14264, 0);
            _14264 = NOVALUE;
        }
        _14264 = NOVALUE;
        _2 = (int)SEQ_PTR(_27indirect_include_10931);
        _2 = (int)(((s1_ptr)_2)->base + _i_25026);
        _1 = *(int *)_2;
        *(int *)_2 = _14265;
        if( _1 != _14265 ){
            DeRef(_1);
        }
        _14265 = NOVALUE;

        /** 	end for*/
        _i_25026 = _i_25026 + 1;
        goto LA; // [499] 465
LB: 
        ;
    }

    /** 	include_matrix = append( include_matrix, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_27file_include_10926)){
            _14266 = SEQ_PTR(_27file_include_10926)->length;
    }
    else {
        _14266 = 1;
    }
    _14267 = Repeat(0, _14266);
    _14266 = NOVALUE;
    RefDS(_14267);
    Append(&_27include_matrix_10928, _27include_matrix_10928, _14267);
    DeRefDS(_14267);
    _14267 = NOVALUE;

    /** 	include_matrix[$][$] = DIRECT_INCLUDE*/
    if (IS_SEQUENCE(_27include_matrix_10928)){
            _14269 = SEQ_PTR(_27include_matrix_10928)->length;
    }
    else {
        _14269 = 1;
    }
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27include_matrix_10928 = MAKE_SEQ(_2);
    }
    _3 = (int)(_14269 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14272 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14272 = 1;
    }
    _14270 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _14272);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _14270 = NOVALUE;

    /** 	include_matrix[current_file_no][$] = DIRECT_INCLUDE*/
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27include_matrix_10928 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26current_file_no_11982 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14275 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14275 = 1;
    }
    _14273 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _14275);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _14273 = NOVALUE;

    /** 	indirect_include = append( indirect_include, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_27file_include_10926)){
            _14276 = SEQ_PTR(_27file_include_10926)->length;
    }
    else {
        _14276 = 1;
    }
    _14277 = Repeat(0, _14276);
    _14276 = NOVALUE;
    RefDS(_14277);
    Append(&_27indirect_include_10931, _27indirect_include_10931, _14277);
    DeRefDS(_14277);
    _14277 = NOVALUE;

    /** 	indirect_include[current_file_no][$] = OpIndirectInclude*/
    _2 = (int)SEQ_PTR(_27indirect_include_10931);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27indirect_include_10931 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26current_file_no_11982 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14281 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14281 = 1;
    }
    _14279 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _14281);
    _1 = *(int *)_2;
    *(int *)_2 = _26OpIndirectInclude_12058;
    DeRef(_1);
    _14279 = NOVALUE;

    /** 	OpIndirectInclude = 1*/
    _26OpIndirectInclude_12058 = 1;

    /** 	file_public  = append( file_public, {} )*/
    RefDS(_5);
    Append(&_27file_public_10934, _27file_public_10934, _5);

    /** 	file_public_by = append( file_public_by, {} )*/
    RefDS(_5);
    Append(&_27file_public_by_10938, _27file_public_by_10938, _5);

    /** 	file_include[current_file_no] &= length( file_include )*/
    if (IS_SEQUENCE(_27file_include_10926)){
            _14284 = SEQ_PTR(_27file_include_10926)->length;
    }
    else {
        _14284 = 1;
    }
    _2 = (int)SEQ_PTR(_27file_include_10926);
    _14285 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    if (IS_SEQUENCE(_14285) && IS_ATOM(_14284)) {
        Append(&_14286, _14285, _14284);
    }
    else if (IS_ATOM(_14285) && IS_SEQUENCE(_14284)) {
    }
    else {
        Concat((object_ptr)&_14286, _14285, _14284);
        _14285 = NOVALUE;
    }
    _14285 = NOVALUE;
    _14284 = NOVALUE;
    _2 = (int)SEQ_PTR(_27file_include_10926);
    _2 = (int)(((s1_ptr)_2)->base + _26current_file_no_11982);
    _1 = *(int *)_2;
    *(int *)_2 = _14286;
    if( _1 != _14286 ){
        DeRef(_1);
    }
    _14286 = NOVALUE;

    /** 	add_include_by( current_file_no, length(file_include), public_include )*/
    if (IS_SEQUENCE(_27file_include_10926)){
            _14287 = SEQ_PTR(_27file_include_10926)->length;
    }
    else {
        _14287 = 1;
    }
    _60add_include_by(_26current_file_no_11982, _14287, _60public_include_23940);
    _14287 = NOVALUE;

    /** 	if public_include then*/
    if (_60public_include_23940 == 0)
    {
        goto LC; // [673] 707
    }
    else{
    }

    /** 		file_public[current_file_no] &= length( file_public )*/
    if (IS_SEQUENCE(_27file_public_10934)){
            _14288 = SEQ_PTR(_27file_public_10934)->length;
    }
    else {
        _14288 = 1;
    }
    _2 = (int)SEQ_PTR(_27file_public_10934);
    _14289 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    if (IS_SEQUENCE(_14289) && IS_ATOM(_14288)) {
        Append(&_14290, _14289, _14288);
    }
    else if (IS_ATOM(_14289) && IS_SEQUENCE(_14288)) {
    }
    else {
        Concat((object_ptr)&_14290, _14289, _14288);
        _14289 = NOVALUE;
    }
    _14289 = NOVALUE;
    _14288 = NOVALUE;
    _2 = (int)SEQ_PTR(_27file_public_10934);
    _2 = (int)(((s1_ptr)_2)->base + _26current_file_no_11982);
    _1 = *(int *)_2;
    *(int *)_2 = _14290;
    if( _1 != _14290 ){
        DeRef(_1);
    }
    _14290 = NOVALUE;

    /** 		patch_exports( current_file_no )*/
    _60patch_exports(_26current_file_no_11982);
LC: 

    /** ifdef STDDEBUG then*/

    /** 	src_file = new_file_handle*/
    _26src_file_12104 = _new_file_handle_24911;

    /** 	file_start_sym = last_sym*/
    _26file_start_sym_11988 = _52last_sym_46139;

    /** 	if current_file_no >= MAX_FILE then*/
    if (_26current_file_no_11982 < 256)
    goto LD; // [729] 741

    /** 		CompileErr(126)*/
    RefDS(_22037);
    _43CompileErr(126, _22037, 0);
LD: 

    /** 	known_files = append(known_files, new_include_name)*/
    RefDS(_26new_include_name_12105);
    Append(&_27known_files_10922, _27known_files_10922, _26new_include_name_12105);

    /** 	known_files_hash &= new_hash*/
    Ref(_new_hash_24913);
    Append(&_27known_files_hash_10923, _27known_files_hash_10923, _new_hash_24913);

    /** 	finished_files &= 0*/
    Append(&_27finished_files_10924, _27finished_files_10924, 0);

    /** 	file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_27known_files_10922)){
            _14296 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _14296 = 1;
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _14296;
    _14297 = MAKE_SEQ(_1);
    _14296 = NOVALUE;
    RefDS(_14297);
    Append(&_27file_include_depend_10925, _27file_include_depend_10925, _14297);
    DeRefDS(_14297);
    _14297 = NOVALUE;

    /** 	file_include_depend[current_file_no] &= length( known_files )*/
    if (IS_SEQUENCE(_27known_files_10922)){
            _14299 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _14299 = 1;
    }
    _2 = (int)SEQ_PTR(_27file_include_depend_10925);
    _14300 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    if (IS_SEQUENCE(_14300) && IS_ATOM(_14299)) {
        Append(&_14301, _14300, _14299);
    }
    else if (IS_ATOM(_14300) && IS_SEQUENCE(_14299)) {
    }
    else {
        Concat((object_ptr)&_14301, _14300, _14299);
        _14300 = NOVALUE;
    }
    _14300 = NOVALUE;
    _14299 = NOVALUE;
    _2 = (int)SEQ_PTR(_27file_include_depend_10925);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27file_include_depend_10925 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _26current_file_no_11982);
    _1 = *(int *)_2;
    *(int *)_2 = _14301;
    if( _1 != _14301 ){
        DeRef(_1);
    }
    _14301 = NOVALUE;

    /** 	check_coverage()*/
    _49check_coverage();

    /** 	default_namespaces &= 0*/
    Append(&_60default_namespaces_23943, _60default_namespaces_23943, 0);

    /** 	update_include_matrix( length( file_include ), current_file_no )*/
    if (IS_SEQUENCE(_27file_include_10926)){
            _14303 = SEQ_PTR(_27file_include_10926)->length;
    }
    else {
        _14303 = 1;
    }
    _60update_include_matrix(_14303, _26current_file_no_11982);
    _14303 = NOVALUE;

    /** 	old_file_no = current_file_no*/
    _old_file_no_24912 = _26current_file_no_11982;

    /** 	current_file_no = length(known_files)*/
    if (IS_SEQUENCE(_27known_files_10922)){
            _26current_file_no_11982 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _26current_file_no_11982 = 1;
    }

    /** 	line_number = 0*/
    _26line_number_11983 = 0;

    /** 	read_line()*/
    _60read_line();

    /** 	if new_include_space != 0 then*/
    if (_60new_include_space_23935 == 0)
    goto LE; // [873] 897

    /** 		SymTab[new_include_space][S_OBJ] = current_file_no*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_60new_include_space_23935 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _26current_file_no_11982;
    DeRef(_1);
    _14306 = NOVALUE;
LE: 

    /** 	default_namespace( )*/
    _60default_namespace();

    /** end procedure*/
    DeRef(_new_hash_24913);
    DeRef(_14249);
    _14249 = NOVALUE;
    return;
    ;
}


void _60update_include_completion(int _file_no_25136)
{
    int _fx_25145 = NOVALUE;
    int _14316 = NOVALUE;
    int _14315 = NOVALUE;
    int _14314 = NOVALUE;
    int _14313 = NOVALUE;
    int _14311 = NOVALUE;
    int _14310 = NOVALUE;
    int _14309 = NOVALUE;
    int _14308 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length( file_include_depend ) do*/
    if (IS_SEQUENCE(_27file_include_depend_10925)){
            _14308 = SEQ_PTR(_27file_include_depend_10925)->length;
    }
    else {
        _14308 = 1;
    }
    {
        int _i_25138;
        _i_25138 = 1;
L1: 
        if (_i_25138 > _14308){
            goto L2; // [10] 114
        }

        /** 		if length( file_include_depend[i] ) then*/
        _2 = (int)SEQ_PTR(_27file_include_depend_10925);
        _14309 = (int)*(((s1_ptr)_2)->base + _i_25138);
        if (IS_SEQUENCE(_14309)){
                _14310 = SEQ_PTR(_14309)->length;
        }
        else {
            _14310 = 1;
        }
        _14309 = NOVALUE;
        if (_14310 == 0)
        {
            _14310 = NOVALUE;
            goto L3; // [28] 105
        }
        else{
            _14310 = NOVALUE;
        }

        /** 			integer fx = find( file_no, file_include_depend[i] )*/
        _2 = (int)SEQ_PTR(_27file_include_depend_10925);
        _14311 = (int)*(((s1_ptr)_2)->base + _i_25138);
        _fx_25145 = find_from(_file_no_25136, _14311, 1);
        _14311 = NOVALUE;

        /** 			if fx then*/
        if (_fx_25145 == 0)
        {
            goto L4; // [46] 104
        }
        else{
        }

        /** 				file_include_depend[i] = remove( file_include_depend[i], fx )*/
        _2 = (int)SEQ_PTR(_27file_include_depend_10925);
        _14313 = (int)*(((s1_ptr)_2)->base + _i_25138);
        {
            s1_ptr assign_space = SEQ_PTR(_14313);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_25145)) ? _fx_25145 : (long)(DBL_PTR(_fx_25145)->dbl);
            int stop = (IS_ATOM_INT(_fx_25145)) ? _fx_25145 : (long)(DBL_PTR(_fx_25145)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
                RefDS(_14313);
                DeRef(_14314);
                _14314 = _14313;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_14313), start, &_14314 );
                }
                else Tail(SEQ_PTR(_14313), stop+1, &_14314);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_14313), start, &_14314);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_14314);
                _14314 = _1;
            }
        }
        _14313 = NOVALUE;
        _2 = (int)SEQ_PTR(_27file_include_depend_10925);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27file_include_depend_10925 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_25138);
        _1 = *(int *)_2;
        *(int *)_2 = _14314;
        if( _1 != _14314 ){
            DeRef(_1);
        }
        _14314 = NOVALUE;

        /** 				if not length( file_include_depend[i] ) then*/
        _2 = (int)SEQ_PTR(_27file_include_depend_10925);
        _14315 = (int)*(((s1_ptr)_2)->base + _i_25138);
        if (IS_SEQUENCE(_14315)){
                _14316 = SEQ_PTR(_14315)->length;
        }
        else {
            _14316 = 1;
        }
        _14315 = NOVALUE;
        if (_14316 != 0)
        goto L5; // [79] 103
        _14316 = NOVALUE;

        /** 					finished_files[i] = 1*/
        _2 = (int)SEQ_PTR(_27finished_files_10924);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27finished_files_10924 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_25138);
        *(int *)_2 = 1;

        /** 					if i != file_no then*/
        if (_i_25138 == _file_no_25136)
        goto L6; // [92] 102

        /** 						update_include_completion( i )*/
        _60update_include_completion(_i_25138);
L6: 
L5: 
L4: 
L3: 

        /** 	end for*/
        _i_25138 = _i_25138 + 1;
        goto L1; // [109] 17
L2: 
        ;
    }

    /** end procedure*/
    _14309 = NOVALUE;
    _14315 = NOVALUE;
    return;
    ;
}


int _60IncludePop()
{
    int _top_25176 = NOVALUE;
    int _14347 = NOVALUE;
    int _14345 = NOVALUE;
    int _14344 = NOVALUE;
    int _14322 = NOVALUE;
    int _14320 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	update_include_completion( current_file_no )*/
    _60update_include_completion(_26current_file_no_11982);

    /** 	Resolve_forward_references()*/
    _29Resolve_forward_references(0);

    /** 	HideLocals()*/
    _52HideLocals();

    /** 	if src_file >= 0 then*/
    if (_26src_file_12104 < 0)
    goto L1; // [21] 39

    /** 		close(src_file)*/
    EClose(_26src_file_12104);

    /** 		src_file = -1*/
    _26src_file_12104 = -1;
L1: 

    /** 	if length(IncludeStk) = 0 then*/
    if (IS_SEQUENCE(_60IncludeStk_23946)){
            _14320 = SEQ_PTR(_60IncludeStk_23946)->length;
    }
    else {
        _14320 = 1;
    }
    if (_14320 != 0)
    goto L2; // [46] 59

    /** 		return FALSE  -- the end*/
    DeRef(_top_25176);
    return _9FALSE_428;
L2: 

    /** 	sequence top = IncludeStk[$]*/
    if (IS_SEQUENCE(_60IncludeStk_23946)){
            _14322 = SEQ_PTR(_60IncludeStk_23946)->length;
    }
    else {
        _14322 = 1;
    }
    DeRef(_top_25176);
    _2 = (int)SEQ_PTR(_60IncludeStk_23946);
    _top_25176 = (int)*(((s1_ptr)_2)->base + _14322);
    RefDS(_top_25176);

    /** 	current_file_no    = top[FILE_NO]*/
    _2 = (int)SEQ_PTR(_top_25176);
    _26current_file_no_11982 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_26current_file_no_11982)){
        _26current_file_no_11982 = (long)DBL_PTR(_26current_file_no_11982)->dbl;
    }

    /** 	line_number        = top[LINE_NO]*/
    _2 = (int)SEQ_PTR(_top_25176);
    _26line_number_11983 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_26line_number_11983)){
        _26line_number_11983 = (long)DBL_PTR(_26line_number_11983)->dbl;
    }

    /** 	src_file           = top[FILE_PTR]*/
    _2 = (int)SEQ_PTR(_top_25176);
    _26src_file_12104 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_26src_file_12104)){
        _26src_file_12104 = (long)DBL_PTR(_26src_file_12104)->dbl;
    }

    /** 	file_start_sym     = top[FILE_START_SYM]*/
    _2 = (int)SEQ_PTR(_top_25176);
    _26file_start_sym_11988 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_26file_start_sym_11988)){
        _26file_start_sym_11988 = (long)DBL_PTR(_26file_start_sym_11988)->dbl;
    }

    /** 	OpWarning          = top[OP_WARNING]*/
    _2 = (int)SEQ_PTR(_top_25176);
    _26OpWarning_12050 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_26OpWarning_12050)){
        _26OpWarning_12050 = (long)DBL_PTR(_26OpWarning_12050)->dbl;
    }

    /** 	OpTrace            = top[OP_TRACE]*/
    _2 = (int)SEQ_PTR(_top_25176);
    _26OpTrace_12052 = (int)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_26OpTrace_12052)){
        _26OpTrace_12052 = (long)DBL_PTR(_26OpTrace_12052)->dbl;
    }

    /** 	OpTypeCheck        = top[OP_TYPE_CHECK]*/
    _2 = (int)SEQ_PTR(_top_25176);
    _26OpTypeCheck_12053 = (int)*(((s1_ptr)_2)->base + 7);
    if (!IS_ATOM_INT(_26OpTypeCheck_12053)){
        _26OpTypeCheck_12053 = (long)DBL_PTR(_26OpTypeCheck_12053)->dbl;
    }

    /** 	OpProfileTime      = top[OP_PROFILE_TIME]*/
    _2 = (int)SEQ_PTR(_top_25176);
    _26OpProfileTime_12055 = (int)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_26OpProfileTime_12055)){
        _26OpProfileTime_12055 = (long)DBL_PTR(_26OpProfileTime_12055)->dbl;
    }

    /** 	OpProfileStatement = top[OP_PROFILE_STATEMENT]*/
    _2 = (int)SEQ_PTR(_top_25176);
    _26OpProfileStatement_12054 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_26OpProfileStatement_12054)){
        _26OpProfileStatement_12054 = (long)DBL_PTR(_26OpProfileStatement_12054)->dbl;
    }

    /** 	OpDefines          = top[OP_DEFINES]*/
    DeRef(_26OpDefines_12056);
    _2 = (int)SEQ_PTR(_top_25176);
    _26OpDefines_12056 = (int)*(((s1_ptr)_2)->base + 10);
    Ref(_26OpDefines_12056);

    /** 	prev_OpWarning     = top[PREV_OP_WARNING]*/
    _2 = (int)SEQ_PTR(_top_25176);
    _26prev_OpWarning_12051 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_26prev_OpWarning_12051)){
        _26prev_OpWarning_12051 = (long)DBL_PTR(_26prev_OpWarning_12051)->dbl;
    }

    /** 	OpInline           = top[OP_INLINE]*/
    _2 = (int)SEQ_PTR(_top_25176);
    _26OpInline_12057 = (int)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_26OpInline_12057)){
        _26OpInline_12057 = (long)DBL_PTR(_26OpInline_12057)->dbl;
    }

    /** 	OpIndirectInclude  = top[OP_INDIRECT_INCLUDE]*/
    _2 = (int)SEQ_PTR(_top_25176);
    _26OpIndirectInclude_12058 = (int)*(((s1_ptr)_2)->base + 13);
    if (!IS_ATOM_INT(_26OpIndirectInclude_12058)){
        _26OpIndirectInclude_12058 = (long)DBL_PTR(_26OpIndirectInclude_12058)->dbl;
    }

    /** 	putback_fwd_line_number = line_number -- top[PUTBACK_FWD_LINE_NUMBER]*/
    _26putback_fwd_line_number_11985 = _26line_number_11983;

    /** 	putback_ForwardLine = top[PUTBACK_FORWARDLINE]*/
    DeRef(_43putback_ForwardLine_48559);
    _2 = (int)SEQ_PTR(_top_25176);
    _43putback_ForwardLine_48559 = (int)*(((s1_ptr)_2)->base + 15);
    Ref(_43putback_ForwardLine_48559);

    /** 	putback_forward_bp = top[PUTBACK_FORWARD_BP]*/
    _2 = (int)SEQ_PTR(_top_25176);
    _43putback_forward_bp_48563 = (int)*(((s1_ptr)_2)->base + 16);
    if (!IS_ATOM_INT(_43putback_forward_bp_48563)){
        _43putback_forward_bp_48563 = (long)DBL_PTR(_43putback_forward_bp_48563)->dbl;
    }

    /** 	last_fwd_line_number = top[LAST_FWD_LINE_NUMBER]*/
    _2 = (int)SEQ_PTR(_top_25176);
    _26last_fwd_line_number_11986 = (int)*(((s1_ptr)_2)->base + 17);
    if (!IS_ATOM_INT(_26last_fwd_line_number_11986)){
        _26last_fwd_line_number_11986 = (long)DBL_PTR(_26last_fwd_line_number_11986)->dbl;
    }

    /** 	last_ForwardLine = top[LAST_FORWARDLINE]*/
    DeRef(_43last_ForwardLine_48560);
    _2 = (int)SEQ_PTR(_top_25176);
    _43last_ForwardLine_48560 = (int)*(((s1_ptr)_2)->base + 18);
    Ref(_43last_ForwardLine_48560);

    /** 	last_forward_bp = top[LAST_FORWARD_BP]*/
    _2 = (int)SEQ_PTR(_top_25176);
    _43last_forward_bp_48564 = (int)*(((s1_ptr)_2)->base + 19);
    if (!IS_ATOM_INT(_43last_forward_bp_48564)){
        _43last_forward_bp_48564 = (long)DBL_PTR(_43last_forward_bp_48564)->dbl;
    }

    /** 	ThisLine = top[THISLINE]*/
    DeRef(_43ThisLine_48557);
    _2 = (int)SEQ_PTR(_top_25176);
    _43ThisLine_48557 = (int)*(((s1_ptr)_2)->base + 20);
    Ref(_43ThisLine_48557);

    /** 	fwd_line_number = line_number --top[FWD_LINE_NUMBER]*/
    _26fwd_line_number_11984 = _26line_number_11983;

    /** 	forward_bp = top[FORWARD_BP]*/
    _2 = (int)SEQ_PTR(_top_25176);
    _43forward_bp_48562 = (int)*(((s1_ptr)_2)->base + 22);
    if (!IS_ATOM_INT(_43forward_bp_48562)){
        _43forward_bp_48562 = (long)DBL_PTR(_43forward_bp_48562)->dbl;
    }

    /** 	ForwardLine = ThisLine*/
    Ref(_43ThisLine_48557);
    DeRef(_43ForwardLine_48558);
    _43ForwardLine_48558 = _43ThisLine_48557;

    /** 	putback_ForwardLine = ThisLine*/
    Ref(_43ThisLine_48557);
    DeRef(_43putback_ForwardLine_48559);
    _43putback_ForwardLine_48559 = _43ThisLine_48557;

    /** 	last_ForwardLine = ThisLine*/
    Ref(_43ThisLine_48557);
    DeRef(_43last_ForwardLine_48560);
    _43last_ForwardLine_48560 = _43ThisLine_48557;

    /** 	IncludeStk = IncludeStk[1..$-1]*/
    if (IS_SEQUENCE(_60IncludeStk_23946)){
            _14344 = SEQ_PTR(_60IncludeStk_23946)->length;
    }
    else {
        _14344 = 1;
    }
    _14345 = _14344 - 1;
    _14344 = NOVALUE;
    rhs_slice_target = (object_ptr)&_60IncludeStk_23946;
    RHS_Slice(_60IncludeStk_23946, 1, _14345);

    /** 	SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26TopLevelSub_11989 + ((s1_ptr)_2)->base);
    RefDS(_26Code_12071);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_CODE_11666))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_CODE_11666);
    _1 = *(int *)_2;
    *(int *)_2 = _26Code_12071;
    DeRef(_1);
    _14347 = NOVALUE;

    /** 	return TRUE*/
    DeRefDS(_top_25176);
    _14345 = NOVALUE;
    return _9TRUE_430;
    ;
}


int _60MakeInt(int _text_25264, int _nBase_25265)
{
    int _num_25266 = NOVALUE;
    int _fnum_25267 = NOVALUE;
    int _digit_25268 = NOVALUE;
    int _maxchk_25269 = NOVALUE;
    int _14392 = NOVALUE;
    int _14390 = NOVALUE;
    int _14388 = NOVALUE;
    int _14385 = NOVALUE;
    int _14384 = NOVALUE;
    int _14383 = NOVALUE;
    int _14381 = NOVALUE;
    int _14379 = NOVALUE;
    int _14378 = NOVALUE;
    int _14375 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_nBase_25265)) {
        _1 = (long)(DBL_PTR(_nBase_25265)->dbl);
        DeRefDS(_nBase_25265);
        _nBase_25265 = _1;
    }

    /** 	switch nBase do*/
    _0 = _nBase_25265;
    switch ( _0 ){ 

        /** 		case 2 then*/
        case 2:

        /** 			maxchk = 536870911*/
        _maxchk_25269 = 536870911;
        goto L1; // [21] 82

        /** 		case 8 then*/
        case 8:

        /** 			maxchk = 134217727*/
        _maxchk_25269 = 134217727;
        goto L1; // [32] 82

        /** 		case 10 then*/
        case 10:

        /** 			num = find(text, common_int_text)*/
        _num_25266 = find_from(_text_25264, _60common_int_text_25239, 1);

        /** 			if num then*/
        if (_num_25266 == 0)
        {
            goto L2; // [49] 65
        }
        else{
        }

        /** 				return common_ints[num]*/
        _2 = (int)SEQ_PTR(_60common_ints_25259);
        _14375 = (int)*(((s1_ptr)_2)->base + _num_25266);
        DeRefDS(_text_25264);
        DeRef(_fnum_25267);
        return _14375;
L2: 

        /** 			maxchk = 107374181*/
        _maxchk_25269 = 107374181;
        goto L1; // [70] 82

        /** 		case 16 then*/
        case 16:

        /** 			maxchk = 67108863*/
        _maxchk_25269 = 67108863;
    ;}L1: 

    /** 	num = 0*/
    _num_25266 = 0;

    /** 	fnum = 0*/
    DeRef(_fnum_25267);
    _fnum_25267 = 0;

    /** 	for i = 1 to length(text) do*/
    if (IS_SEQUENCE(_text_25264)){
            _14378 = SEQ_PTR(_text_25264)->length;
    }
    else {
        _14378 = 1;
    }
    {
        int _i_25284;
        _i_25284 = 1;
L3: 
        if (_i_25284 > _14378){
            goto L4; // [97] 212
        }

        /** 		digit = (text[i] - '0')*/
        _2 = (int)SEQ_PTR(_text_25264);
        _14379 = (int)*(((s1_ptr)_2)->base + _i_25284);
        if (IS_ATOM_INT(_14379)) {
            _digit_25268 = _14379 - 48;
        }
        else {
            _digit_25268 = binary_op(MINUS, _14379, 48);
        }
        _14379 = NOVALUE;
        if (!IS_ATOM_INT(_digit_25268)) {
            _1 = (long)(DBL_PTR(_digit_25268)->dbl);
            DeRefDS(_digit_25268);
            _digit_25268 = _1;
        }

        /** 		if digit >= nBase or digit < 0 then*/
        _14381 = (_digit_25268 >= _nBase_25265);
        if (_14381 != 0) {
            goto L5; // [122] 135
        }
        _14383 = (_digit_25268 < 0);
        if (_14383 == 0)
        {
            DeRef(_14383);
            _14383 = NOVALUE;
            goto L6; // [131] 151
        }
        else{
            DeRef(_14383);
            _14383 = NOVALUE;
        }
L5: 

        /** 			CompileErr(62, {text[i],i})*/
        _2 = (int)SEQ_PTR(_text_25264);
        _14384 = (int)*(((s1_ptr)_2)->base + _i_25284);
        Ref(_14384);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _14384;
        ((int *)_2)[2] = _i_25284;
        _14385 = MAKE_SEQ(_1);
        _14384 = NOVALUE;
        _43CompileErr(62, _14385, 0);
        _14385 = NOVALUE;
L6: 

        /** 		if fnum = 0 then*/
        if (binary_op_a(NOTEQ, _fnum_25267, 0)){
            goto L7; // [153] 194
        }

        /** 			if num <= maxchk then*/
        if (_num_25266 > _maxchk_25269)
        goto L8; // [161] 180

        /** 				num = num * nBase + digit*/
        if (_num_25266 == (short)_num_25266 && _nBase_25265 <= INT15 && _nBase_25265 >= -INT15)
        _14388 = _num_25266 * _nBase_25265;
        else
        _14388 = NewDouble(_num_25266 * (double)_nBase_25265);
        if (IS_ATOM_INT(_14388)) {
            _num_25266 = _14388 + _digit_25268;
        }
        else {
            _num_25266 = NewDouble(DBL_PTR(_14388)->dbl + (double)_digit_25268);
        }
        DeRef(_14388);
        _14388 = NOVALUE;
        if (!IS_ATOM_INT(_num_25266)) {
            _1 = (long)(DBL_PTR(_num_25266)->dbl);
            DeRefDS(_num_25266);
            _num_25266 = _1;
        }
        goto L9; // [177] 205
L8: 

        /** 				fnum = num * nBase + digit*/
        if (_num_25266 == (short)_num_25266 && _nBase_25265 <= INT15 && _nBase_25265 >= -INT15)
        _14390 = _num_25266 * _nBase_25265;
        else
        _14390 = NewDouble(_num_25266 * (double)_nBase_25265);
        DeRef(_fnum_25267);
        if (IS_ATOM_INT(_14390)) {
            _fnum_25267 = _14390 + _digit_25268;
            if ((long)((unsigned long)_fnum_25267 + (unsigned long)HIGH_BITS) >= 0) 
            _fnum_25267 = NewDouble((double)_fnum_25267);
        }
        else {
            _fnum_25267 = NewDouble(DBL_PTR(_14390)->dbl + (double)_digit_25268);
        }
        DeRef(_14390);
        _14390 = NOVALUE;
        goto L9; // [191] 205
L7: 

        /** 			fnum = fnum * nBase + digit*/
        if (IS_ATOM_INT(_fnum_25267)) {
            if (_fnum_25267 == (short)_fnum_25267 && _nBase_25265 <= INT15 && _nBase_25265 >= -INT15)
            _14392 = _fnum_25267 * _nBase_25265;
            else
            _14392 = NewDouble(_fnum_25267 * (double)_nBase_25265);
        }
        else {
            _14392 = NewDouble(DBL_PTR(_fnum_25267)->dbl * (double)_nBase_25265);
        }
        DeRef(_fnum_25267);
        if (IS_ATOM_INT(_14392)) {
            _fnum_25267 = _14392 + _digit_25268;
            if ((long)((unsigned long)_fnum_25267 + (unsigned long)HIGH_BITS) >= 0) 
            _fnum_25267 = NewDouble((double)_fnum_25267);
        }
        else {
            _fnum_25267 = NewDouble(DBL_PTR(_14392)->dbl + (double)_digit_25268);
        }
        DeRef(_14392);
        _14392 = NOVALUE;
L9: 

        /** 	end for*/
        _i_25284 = _i_25284 + 1;
        goto L3; // [207] 104
L4: 
        ;
    }

    /** 	if fnum = 0 then*/
    if (binary_op_a(NOTEQ, _fnum_25267, 0)){
        goto LA; // [214] 227
    }

    /** 		return num*/
    DeRefDS(_text_25264);
    DeRef(_fnum_25267);
    _14375 = NOVALUE;
    DeRef(_14381);
    _14381 = NOVALUE;
    return _num_25266;
    goto LB; // [224] 234
LA: 

    /** 		return fnum*/
    DeRefDS(_text_25264);
    _14375 = NOVALUE;
    DeRef(_14381);
    _14381 = NOVALUE;
    return _fnum_25267;
LB: 
    ;
}


int _60GetHexChar(int _cnt_25312, int _errno_25313)
{
    int _val_25314 = NOVALUE;
    int _d_25315 = NOVALUE;
    int _14402 = NOVALUE;
    int _14401 = NOVALUE;
    int _14396 = NOVALUE;
    int _0, _1, _2;
    

    /** 	val = 0*/
    DeRef(_val_25314);
    _val_25314 = 0;

    /** 	while cnt > 0 do*/
L1: 
    if (_cnt_25312 <= 0)
    goto L2; // [15] 88

    /** 		d = find(getch(), "0123456789ABCDEFabcdef_")*/
    _14396 = _60getch();
    _d_25315 = find_from(_14396, _14397, 1);
    DeRef(_14396);
    _14396 = NOVALUE;

    /** 		if d = 0 then*/
    if (_d_25315 != 0)
    goto L3; // [31] 43

    /** 			CompileErr( errno )*/
    RefDS(_22037);
    _43CompileErr(_errno_25313, _22037, 0);
L3: 

    /** 		if d != 23 then*/
    if (_d_25315 == 23)
    goto L1; // [45] 15

    /** 			val = val * 16 + d - 1*/
    if (IS_ATOM_INT(_val_25314)) {
        if (_val_25314 == (short)_val_25314)
        _14401 = _val_25314 * 16;
        else
        _14401 = NewDouble(_val_25314 * (double)16);
    }
    else {
        _14401 = NewDouble(DBL_PTR(_val_25314)->dbl * (double)16);
    }
    if (IS_ATOM_INT(_14401)) {
        _14402 = _14401 + _d_25315;
        if ((long)((unsigned long)_14402 + (unsigned long)HIGH_BITS) >= 0) 
        _14402 = NewDouble((double)_14402);
    }
    else {
        _14402 = NewDouble(DBL_PTR(_14401)->dbl + (double)_d_25315);
    }
    DeRef(_14401);
    _14401 = NOVALUE;
    DeRef(_val_25314);
    if (IS_ATOM_INT(_14402)) {
        _val_25314 = _14402 - 1;
        if ((long)((unsigned long)_val_25314 +(unsigned long) HIGH_BITS) >= 0){
            _val_25314 = NewDouble((double)_val_25314);
        }
    }
    else {
        _val_25314 = NewDouble(DBL_PTR(_14402)->dbl - (double)1);
    }
    DeRef(_14402);
    _14402 = NOVALUE;

    /** 			if d > 16 then*/
    if (_d_25315 <= 16)
    goto L4; // [65] 76

    /** 				val -= 6*/
    _0 = _val_25314;
    if (IS_ATOM_INT(_val_25314)) {
        _val_25314 = _val_25314 - 6;
        if ((long)((unsigned long)_val_25314 +(unsigned long) HIGH_BITS) >= 0){
            _val_25314 = NewDouble((double)_val_25314);
        }
    }
    else {
        _val_25314 = NewDouble(DBL_PTR(_val_25314)->dbl - (double)6);
    }
    DeRef(_0);
L4: 

    /** 			cnt -= 1*/
    _cnt_25312 = _cnt_25312 - 1;

    /** 	end while*/
    goto L1; // [85] 15
L2: 

    /** 	return val*/
    return _val_25314;
    ;
}


int _60GetBinaryChar(int _delim_25335)
{
    int _val_25336 = NOVALUE;
    int _d_25337 = NOVALUE;
    int _vchars_25338 = NOVALUE;
    int _cnt_25341 = NOVALUE;
    int _14416 = NOVALUE;
    int _14415 = NOVALUE;
    int _14409 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence vchars = "01_ " & delim*/
    Append(&_vchars_25338, _14407, _delim_25335);

    /** 	integer cnt = 0*/
    _cnt_25341 = 0;

    /** 	val = 0*/
    DeRef(_val_25336);
    _val_25336 = 0;

    /** 	while 1 do*/
L1: 

    /** 		d = find(getch(), vchars)*/
    _14409 = _60getch();
    _d_25337 = find_from(_14409, _vchars_25338, 1);
    DeRef(_14409);
    _14409 = NOVALUE;

    /** 		if d = 0 then*/
    if (_d_25337 != 0)
    goto L2; // [36] 48

    /** 			CompileErr( 343 )*/
    RefDS(_22037);
    _43CompileErr(343, _22037, 0);
L2: 

    /** 		if d = 5 then*/
    if (_d_25337 != 5)
    goto L3; // [50] 63

    /** 			ungetch()*/
    _60ungetch();

    /** 			exit*/
    goto L4; // [60] 106
L3: 

    /** 		if d = 4 then*/
    if (_d_25337 != 4)
    goto L5; // [65] 74

    /** 			exit*/
    goto L4; // [71] 106
L5: 

    /** 		if d != 3 then*/
    if (_d_25337 == 3)
    goto L1; // [76] 24

    /** 			val = val * 2 + d - 1*/
    if (IS_ATOM_INT(_val_25336) && IS_ATOM_INT(_val_25336)) {
        _14415 = _val_25336 + _val_25336;
        if ((long)((unsigned long)_14415 + (unsigned long)HIGH_BITS) >= 0) 
        _14415 = NewDouble((double)_14415);
    }
    else {
        if (IS_ATOM_INT(_val_25336)) {
            _14415 = NewDouble((double)_val_25336 + DBL_PTR(_val_25336)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_25336)) {
                _14415 = NewDouble(DBL_PTR(_val_25336)->dbl + (double)_val_25336);
            }
            else
            _14415 = NewDouble(DBL_PTR(_val_25336)->dbl + DBL_PTR(_val_25336)->dbl);
        }
    }
    if (IS_ATOM_INT(_14415)) {
        _14416 = _14415 + _d_25337;
        if ((long)((unsigned long)_14416 + (unsigned long)HIGH_BITS) >= 0) 
        _14416 = NewDouble((double)_14416);
    }
    else {
        _14416 = NewDouble(DBL_PTR(_14415)->dbl + (double)_d_25337);
    }
    DeRef(_14415);
    _14415 = NOVALUE;
    DeRef(_val_25336);
    if (IS_ATOM_INT(_14416)) {
        _val_25336 = _14416 - 1;
        if ((long)((unsigned long)_val_25336 +(unsigned long) HIGH_BITS) >= 0){
            _val_25336 = NewDouble((double)_val_25336);
        }
    }
    else {
        _val_25336 = NewDouble(DBL_PTR(_14416)->dbl - (double)1);
    }
    DeRef(_14416);
    _14416 = NOVALUE;

    /** 			cnt += 1*/
    _cnt_25341 = _cnt_25341 + 1;

    /** 	end while*/
    goto L1; // [103] 24
L4: 

    /** 	if cnt = 0 then*/
    if (_cnt_25341 != 0)
    goto L6; // [108] 120

    /** 		CompileErr(343)*/
    RefDS(_22037);
    _43CompileErr(343, _22037, 0);
L6: 

    /** 	return val*/
    DeRefi(_vchars_25338);
    return _val_25336;
    ;
}


int _60EscapeChar(int _delim_25363)
{
    int _c_25364 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c = getch()*/
    _0 = _c_25364;
    _c_25364 = _60getch();
    DeRef(_0);

    /** 	switch c do*/
    if (IS_SEQUENCE(_c_25364) ){
        goto L1; // [10] 135
    }
    if(!IS_ATOM_INT(_c_25364)){
        if( (DBL_PTR(_c_25364)->dbl != (double) ((int) DBL_PTR(_c_25364)->dbl) ) ){
            goto L1; // [10] 135
        }
        _0 = (int) DBL_PTR(_c_25364)->dbl;
    }
    else {
        _0 = _c_25364;
    };
    switch ( _0 ){ 

        /** 		case 'n' then*/
        case 110:

        /** 			c = 10 -- Newline*/
        DeRef(_c_25364);
        _c_25364 = 10;
        goto L2; // [24] 145

        /** 		case 't' then*/
        case 116:

        /** 			c = 9 -- Tabulator*/
        DeRef(_c_25364);
        _c_25364 = 9;
        goto L2; // [35] 145

        /** 		case '"', '\\', '\'' then*/
        case 34:
        case 92:
        case 39:

        /** 		case 'r' then*/
        goto L2; // [47] 145
        case 114:

        /** 			c = 13 -- Carriage Return*/
        DeRef(_c_25364);
        _c_25364 = 13;
        goto L2; // [56] 145

        /** 		case '0' then*/
        case 48:

        /** 			c = 0 -- Null*/
        DeRef(_c_25364);
        _c_25364 = 0;
        goto L2; // [67] 145

        /** 		case 'e', 'E' then*/
        case 101:
        case 69:

        /** 			c = 27 -- escape char.*/
        DeRef(_c_25364);
        _c_25364 = 27;
        goto L2; // [80] 145

        /** 		case 'x' then*/
        case 120:

        /** 			c = GetHexChar(2, 340)*/
        _0 = _c_25364;
        _c_25364 = _60GetHexChar(2, 340);
        DeRef(_0);
        goto L2; // [93] 145

        /** 		case 'u' then*/
        case 117:

        /** 			c = GetHexChar(4, 341)*/
        _0 = _c_25364;
        _c_25364 = _60GetHexChar(4, 341);
        DeRef(_0);
        goto L2; // [106] 145

        /** 		case 'U' then*/
        case 85:

        /** 			c = GetHexChar(8, 342)*/
        _0 = _c_25364;
        _c_25364 = _60GetHexChar(8, 342);
        DeRef(_0);
        goto L2; // [119] 145

        /** 		case 'b' then*/
        case 98:

        /** 			c = GetBinaryChar(delim)*/
        _0 = _c_25364;
        _c_25364 = _60GetBinaryChar(_delim_25363);
        DeRef(_0);
        goto L2; // [131] 145

        /** 		case else*/
        default:
L1: 

        /** 			CompileErr(155)*/
        RefDS(_22037);
        _43CompileErr(155, _22037, 0);
    ;}L2: 

    /** 	return c*/
    return _c_25364;
    ;
}


int _60my_sscanf(int _yytext_25386)
{
    int _e_sign_25387 = NOVALUE;
    int _ndigits_25388 = NOVALUE;
    int _e_mag_25389 = NOVALUE;
    int _mantissa_25390 = NOVALUE;
    int _c_25391 = NOVALUE;
    int _i_25392 = NOVALUE;
    int _dec_25393 = NOVALUE;
    int _frac_25423 = NOVALUE;
    int _14460 = NOVALUE;
    int _14455 = NOVALUE;
    int _14454 = NOVALUE;
    int _14452 = NOVALUE;
    int _14451 = NOVALUE;
    int _14450 = NOVALUE;
    int _14442 = NOVALUE;
    int _14441 = NOVALUE;
    int _14438 = NOVALUE;
    int _14437 = NOVALUE;
    int _14436 = NOVALUE;
    int _14432 = NOVALUE;
    int _14431 = NOVALUE;
    int _14429 = NOVALUE;
    int _14427 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(yytext) < 2 then*/
    if (IS_SEQUENCE(_yytext_25386)){
            _14427 = SEQ_PTR(_yytext_25386)->length;
    }
    else {
        _14427 = 1;
    }
    if (_14427 >= 2)
    goto L1; // [8] 20

    /** 		CompileErr(121)*/
    RefDS(_22037);
    _43CompileErr(121, _22037, 0);
L1: 

    /** 	if find( 'e', yytext ) or find( 'E', yytext ) then*/
    _14429 = find_from(101, _yytext_25386, 1);
    if (_14429 != 0) {
        goto L2; // [27] 41
    }
    _14431 = find_from(69, _yytext_25386, 1);
    if (_14431 == 0)
    {
        _14431 = NOVALUE;
        goto L3; // [37] 52
    }
    else{
        _14431 = NOVALUE;
    }
L2: 

    /** 		return scientific_to_atom( yytext )*/
    RefDS(_yytext_25386);
    _14432 = _61scientific_to_atom(_yytext_25386);
    DeRefDS(_yytext_25386);
    DeRef(_mantissa_25390);
    DeRef(_dec_25393);
    return _14432;
L3: 

    /** 	mantissa = 0.0*/
    RefDS(_14433);
    DeRef(_mantissa_25390);
    _mantissa_25390 = _14433;

    /** 	ndigits = 0*/
    _ndigits_25388 = 0;

    /** 	yytext &= 0 -- end marker*/
    Append(&_yytext_25386, _yytext_25386, 0);

    /** 	c = yytext[1]*/
    _2 = (int)SEQ_PTR(_yytext_25386);
    _c_25391 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_c_25391))
    _c_25391 = (long)DBL_PTR(_c_25391)->dbl;

    /** 	i = 2*/
    _i_25392 = 2;

    /** 	while c >= '0' and c <= '9' do*/
L4: 
    _14436 = (_c_25391 >= 48);
    if (_14436 == 0) {
        goto L5; // [88] 137
    }
    _14438 = (_c_25391 <= 57);
    if (_14438 == 0)
    {
        DeRef(_14438);
        _14438 = NOVALUE;
        goto L5; // [97] 137
    }
    else{
        DeRef(_14438);
        _14438 = NOVALUE;
    }

    /** 		ndigits += 1*/
    _ndigits_25388 = _ndigits_25388 + 1;

    /** 		mantissa = mantissa * 10.0 + (c - '0')*/
    if (IS_ATOM_INT(_mantissa_25390)) {
        _14441 = NewDouble((double)_mantissa_25390 * DBL_PTR(_14440)->dbl);
    }
    else {
        _14441 = NewDouble(DBL_PTR(_mantissa_25390)->dbl * DBL_PTR(_14440)->dbl);
    }
    _14442 = _c_25391 - 48;
    if ((long)((unsigned long)_14442 +(unsigned long) HIGH_BITS) >= 0){
        _14442 = NewDouble((double)_14442);
    }
    DeRef(_mantissa_25390);
    if (IS_ATOM_INT(_14442)) {
        _mantissa_25390 = NewDouble(DBL_PTR(_14441)->dbl + (double)_14442);
    }
    else
    _mantissa_25390 = NewDouble(DBL_PTR(_14441)->dbl + DBL_PTR(_14442)->dbl);
    DeRefDS(_14441);
    _14441 = NOVALUE;
    DeRef(_14442);
    _14442 = NOVALUE;

    /** 		c = yytext[i]*/
    _2 = (int)SEQ_PTR(_yytext_25386);
    _c_25391 = (int)*(((s1_ptr)_2)->base + _i_25392);
    if (!IS_ATOM_INT(_c_25391))
    _c_25391 = (long)DBL_PTR(_c_25391)->dbl;

    /** 		i += 1*/
    _i_25392 = _i_25392 + 1;

    /** 	end while*/
    goto L4; // [134] 84
L5: 

    /** 	if c = '.' then*/
    if (_c_25391 != 46)
    goto L6; // [139] 240

    /** 		c = yytext[i]*/
    _2 = (int)SEQ_PTR(_yytext_25386);
    _c_25391 = (int)*(((s1_ptr)_2)->base + _i_25392);
    if (!IS_ATOM_INT(_c_25391))
    _c_25391 = (long)DBL_PTR(_c_25391)->dbl;

    /** 		i += 1*/
    _i_25392 = _i_25392 + 1;

    /** 		dec = 1.0*/
    RefDS(_14449);
    DeRef(_dec_25393);
    _dec_25393 = _14449;

    /** 		atom frac = 0*/
    DeRef(_frac_25423);
    _frac_25423 = 0;

    /** 		while c >= '0' and c <= '9' do*/
L7: 
    _14450 = (_c_25391 >= 48);
    if (_14450 == 0) {
        goto L8; // [174] 229
    }
    _14452 = (_c_25391 <= 57);
    if (_14452 == 0)
    {
        DeRef(_14452);
        _14452 = NOVALUE;
        goto L8; // [183] 229
    }
    else{
        DeRef(_14452);
        _14452 = NOVALUE;
    }

    /** 			ndigits += 1*/
    _ndigits_25388 = _ndigits_25388 + 1;

    /** 			frac = frac * 10 + (c - '0')*/
    if (IS_ATOM_INT(_frac_25423)) {
        if (_frac_25423 == (short)_frac_25423)
        _14454 = _frac_25423 * 10;
        else
        _14454 = NewDouble(_frac_25423 * (double)10);
    }
    else {
        _14454 = NewDouble(DBL_PTR(_frac_25423)->dbl * (double)10);
    }
    _14455 = _c_25391 - 48;
    if ((long)((unsigned long)_14455 +(unsigned long) HIGH_BITS) >= 0){
        _14455 = NewDouble((double)_14455);
    }
    DeRef(_frac_25423);
    if (IS_ATOM_INT(_14454) && IS_ATOM_INT(_14455)) {
        _frac_25423 = _14454 + _14455;
        if ((long)((unsigned long)_frac_25423 + (unsigned long)HIGH_BITS) >= 0) 
        _frac_25423 = NewDouble((double)_frac_25423);
    }
    else {
        if (IS_ATOM_INT(_14454)) {
            _frac_25423 = NewDouble((double)_14454 + DBL_PTR(_14455)->dbl);
        }
        else {
            if (IS_ATOM_INT(_14455)) {
                _frac_25423 = NewDouble(DBL_PTR(_14454)->dbl + (double)_14455);
            }
            else
            _frac_25423 = NewDouble(DBL_PTR(_14454)->dbl + DBL_PTR(_14455)->dbl);
        }
    }
    DeRef(_14454);
    _14454 = NOVALUE;
    DeRef(_14455);
    _14455 = NOVALUE;

    /** 			dec *= 10.0*/
    _0 = _dec_25393;
    if (IS_ATOM_INT(_dec_25393)) {
        _dec_25393 = NewDouble((double)_dec_25393 * DBL_PTR(_14440)->dbl);
    }
    else {
        _dec_25393 = NewDouble(DBL_PTR(_dec_25393)->dbl * DBL_PTR(_14440)->dbl);
    }
    DeRef(_0);

    /** 			c = yytext[i]*/
    _2 = (int)SEQ_PTR(_yytext_25386);
    _c_25391 = (int)*(((s1_ptr)_2)->base + _i_25392);
    if (!IS_ATOM_INT(_c_25391))
    _c_25391 = (long)DBL_PTR(_c_25391)->dbl;

    /** 			i += 1*/
    _i_25392 = _i_25392 + 1;

    /** 		end while*/
    goto L7; // [226] 170
L8: 

    /** 		mantissa += frac / dec*/
    if (IS_ATOM_INT(_frac_25423) && IS_ATOM_INT(_dec_25393)) {
        _14460 = (_frac_25423 % _dec_25393) ? NewDouble((double)_frac_25423 / _dec_25393) : (_frac_25423 / _dec_25393);
    }
    else {
        if (IS_ATOM_INT(_frac_25423)) {
            _14460 = NewDouble((double)_frac_25423 / DBL_PTR(_dec_25393)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec_25393)) {
                _14460 = NewDouble(DBL_PTR(_frac_25423)->dbl / (double)_dec_25393);
            }
            else
            _14460 = NewDouble(DBL_PTR(_frac_25423)->dbl / DBL_PTR(_dec_25393)->dbl);
        }
    }
    _0 = _mantissa_25390;
    if (IS_ATOM_INT(_mantissa_25390) && IS_ATOM_INT(_14460)) {
        _mantissa_25390 = _mantissa_25390 + _14460;
        if ((long)((unsigned long)_mantissa_25390 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_25390 = NewDouble((double)_mantissa_25390);
    }
    else {
        if (IS_ATOM_INT(_mantissa_25390)) {
            _mantissa_25390 = NewDouble((double)_mantissa_25390 + DBL_PTR(_14460)->dbl);
        }
        else {
            if (IS_ATOM_INT(_14460)) {
                _mantissa_25390 = NewDouble(DBL_PTR(_mantissa_25390)->dbl + (double)_14460);
            }
            else
            _mantissa_25390 = NewDouble(DBL_PTR(_mantissa_25390)->dbl + DBL_PTR(_14460)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_14460);
    _14460 = NOVALUE;
L6: 
    DeRef(_frac_25423);
    _frac_25423 = NOVALUE;

    /** 	if ndigits = 0 then*/
    if (_ndigits_25388 != 0)
    goto L9; // [244] 256

    /** 		CompileErr(121)  -- no digits*/
    RefDS(_22037);
    _43CompileErr(121, _22037, 0);
L9: 

    /** 	return mantissa*/
    DeRefDS(_yytext_25386);
    DeRef(_dec_25393);
    DeRef(_14432);
    _14432 = NOVALUE;
    DeRef(_14436);
    _14436 = NOVALUE;
    DeRef(_14450);
    _14450 = NOVALUE;
    return _mantissa_25390;
    ;
}


void _60maybe_namespace()
{
    int _0, _1, _2;
    

    /** 	might_be_namespace = 1*/
    _60might_be_namespace_25440 = 1;

    /** end procedure*/
    return;
    ;
}


int _60ExtendedString(int _ech_25450)
{
    int _ch_25451 = NOVALUE;
    int _fch_25452 = NOVALUE;
    int _cline_25453 = NOVALUE;
    int _string_text_25454 = NOVALUE;
    int _trimming_25455 = NOVALUE;
    int _14513 = NOVALUE;
    int _14512 = NOVALUE;
    int _14510 = NOVALUE;
    int _14509 = NOVALUE;
    int _14508 = NOVALUE;
    int _14507 = NOVALUE;
    int _14506 = NOVALUE;
    int _14505 = NOVALUE;
    int _14504 = NOVALUE;
    int _14503 = NOVALUE;
    int _14501 = NOVALUE;
    int _14500 = NOVALUE;
    int _14499 = NOVALUE;
    int _14498 = NOVALUE;
    int _14497 = NOVALUE;
    int _14496 = NOVALUE;
    int _14493 = NOVALUE;
    int _14492 = NOVALUE;
    int _14491 = NOVALUE;
    int _14489 = NOVALUE;
    int _14488 = NOVALUE;
    int _14487 = NOVALUE;
    int _14486 = NOVALUE;
    int _14483 = NOVALUE;
    int _14468 = NOVALUE;
    int _14466 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cline = line_number*/
    _cline_25453 = _26line_number_11983;

    /** 	string_text = ""*/
    RefDS(_5);
    DeRefi(_string_text_25454);
    _string_text_25454 = _5;

    /** 	trimming = 0*/
    _trimming_25455 = 0;

    /** 	ch = getch()*/
    _ch_25451 = _60getch();
    if (!IS_ATOM_INT(_ch_25451)) {
        _1 = (long)(DBL_PTR(_ch_25451)->dbl);
        DeRefDS(_ch_25451);
        _ch_25451 = _1;
    }

    /** 	if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_43ThisLine_48557)){
            _14466 = SEQ_PTR(_43ThisLine_48557)->length;
    }
    else {
        _14466 = 1;
    }
    if (_43bp_48561 <= _14466)
    goto L1; // [40] 101

    /** 		read_line()*/
    _60read_line();

    /** 		while ThisLine[bp] = '_' do*/
L2: 
    _2 = (int)SEQ_PTR(_43ThisLine_48557);
    _14468 = (int)*(((s1_ptr)_2)->base + _43bp_48561);
    if (binary_op_a(NOTEQ, _14468, 95)){
        _14468 = NOVALUE;
        goto L3; // [61] 86
    }
    _14468 = NOVALUE;

    /** 			trimming += 1*/
    _trimming_25455 = _trimming_25455 + 1;

    /** 			bp += 1*/
    _43bp_48561 = _43bp_48561 + 1;

    /** 		end while*/
    goto L2; // [83] 53
L3: 

    /** 		if trimming > 0 then*/
    if (_trimming_25455 <= 0)
    goto L4; // [88] 100

    /** 			ch = getch()*/
    _ch_25451 = _60getch();
    if (!IS_ATOM_INT(_ch_25451)) {
        _1 = (long)(DBL_PTR(_ch_25451)->dbl);
        DeRefDS(_ch_25451);
        _ch_25451 = _1;
    }
L4: 
L1: 

    /** 	while 1 do*/
L5: 

    /** 		if ch = END_OF_FILE_CHAR then*/
    if (_ch_25451 != 26)
    goto L6; // [110] 122

    /** 			CompileErr(129, cline)*/
    _43CompileErr(129, _cline_25453, 0);
L6: 

    /** 		if ch = ech then*/
    if (_ch_25451 != _ech_25450)
    goto L7; // [124] 180

    /** 			if ech != '"' then*/
    if (_ech_25450 == 34)
    goto L8; // [130] 139

    /** 				exit*/
    goto L9; // [136] 310
L8: 

    /** 			fch = getch()*/
    _fch_25452 = _60getch();
    if (!IS_ATOM_INT(_fch_25452)) {
        _1 = (long)(DBL_PTR(_fch_25452)->dbl);
        DeRefDS(_fch_25452);
        _fch_25452 = _1;
    }

    /** 			if fch = '"' then*/
    if (_fch_25452 != 34)
    goto LA; // [148] 175

    /** 				fch = getch()*/
    _fch_25452 = _60getch();
    if (!IS_ATOM_INT(_fch_25452)) {
        _1 = (long)(DBL_PTR(_fch_25452)->dbl);
        DeRefDS(_fch_25452);
        _fch_25452 = _1;
    }

    /** 				if fch = '"' then*/
    if (_fch_25452 != 34)
    goto LB; // [161] 170

    /** 					exit*/
    goto L9; // [167] 310
LB: 

    /** 				ungetch()*/
    _60ungetch();
LA: 

    /** 			ungetch()*/
    _60ungetch();
L7: 

    /** 		if ch != '\r' then*/
    if (_ch_25451 == 13)
    goto LC; // [182] 193

    /** 			string_text &= ch*/
    Append(&_string_text_25454, _string_text_25454, _ch_25451);
LC: 

    /** 		if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_43ThisLine_48557)){
            _14483 = SEQ_PTR(_43ThisLine_48557)->length;
    }
    else {
        _14483 = 1;
    }
    if (_43bp_48561 <= _14483)
    goto LD; // [202] 298

    /** 			read_line() -- sets bp to 1, btw.*/
    _60read_line();

    /** 			if trimming > 0 then*/
    if (_trimming_25455 <= 0)
    goto LE; // [212] 297

    /** 				while bp <= trimming and bp <= length(ThisLine) do*/
LF: 
    _14486 = (_43bp_48561 <= _trimming_25455);
    if (_14486 == 0) {
        goto L10; // [227] 296
    }
    if (IS_SEQUENCE(_43ThisLine_48557)){
            _14488 = SEQ_PTR(_43ThisLine_48557)->length;
    }
    else {
        _14488 = 1;
    }
    _14489 = (_43bp_48561 <= _14488);
    _14488 = NOVALUE;
    if (_14489 == 0)
    {
        DeRef(_14489);
        _14489 = NOVALUE;
        goto L10; // [243] 296
    }
    else{
        DeRef(_14489);
        _14489 = NOVALUE;
    }

    /** 					ch = ThisLine[bp]*/
    _2 = (int)SEQ_PTR(_43ThisLine_48557);
    _ch_25451 = (int)*(((s1_ptr)_2)->base + _43bp_48561);
    if (!IS_ATOM_INT(_ch_25451)){
        _ch_25451 = (long)DBL_PTR(_ch_25451)->dbl;
    }

    /** 					if ch != ' ' and ch != '\t' then*/
    _14491 = (_ch_25451 != 32);
    if (_14491 == 0) {
        goto L11; // [264] 281
    }
    _14493 = (_ch_25451 != 9);
    if (_14493 == 0)
    {
        DeRef(_14493);
        _14493 = NOVALUE;
        goto L11; // [273] 281
    }
    else{
        DeRef(_14493);
        _14493 = NOVALUE;
    }

    /** 						exit*/
    goto L10; // [278] 296
L11: 

    /** 					bp += 1*/
    _43bp_48561 = _43bp_48561 + 1;

    /** 				end while*/
    goto LF; // [293] 221
L10: 
LE: 
LD: 

    /** 		ch = getch()*/
    _ch_25451 = _60getch();
    if (!IS_ATOM_INT(_ch_25451)) {
        _1 = (long)(DBL_PTR(_ch_25451)->dbl);
        DeRefDS(_ch_25451);
        _ch_25451 = _1;
    }

    /** 	end while*/
    goto L5; // [307] 106
L9: 

    /** 	if length(string_text) > 0 and string_text[1] = '\n' then*/
    if (IS_SEQUENCE(_string_text_25454)){
            _14496 = SEQ_PTR(_string_text_25454)->length;
    }
    else {
        _14496 = 1;
    }
    _14497 = (_14496 > 0);
    _14496 = NOVALUE;
    if (_14497 == 0) {
        goto L12; // [319] 389
    }
    _2 = (int)SEQ_PTR(_string_text_25454);
    _14499 = (int)*(((s1_ptr)_2)->base + 1);
    _14500 = (_14499 == 10);
    _14499 = NOVALUE;
    if (_14500 == 0)
    {
        DeRef(_14500);
        _14500 = NOVALUE;
        goto L12; // [332] 389
    }
    else{
        DeRef(_14500);
        _14500 = NOVALUE;
    }

    /** 		string_text = string_text[2 .. $]*/
    if (IS_SEQUENCE(_string_text_25454)){
            _14501 = SEQ_PTR(_string_text_25454)->length;
    }
    else {
        _14501 = 1;
    }
    rhs_slice_target = (object_ptr)&_string_text_25454;
    RHS_Slice(_string_text_25454, 2, _14501);

    /** 		if length(string_text) > 0 and string_text[$] = '\n' then*/
    if (IS_SEQUENCE(_string_text_25454)){
            _14503 = SEQ_PTR(_string_text_25454)->length;
    }
    else {
        _14503 = 1;
    }
    _14504 = (_14503 > 0);
    _14503 = NOVALUE;
    if (_14504 == 0) {
        goto L13; // [354] 388
    }
    if (IS_SEQUENCE(_string_text_25454)){
            _14506 = SEQ_PTR(_string_text_25454)->length;
    }
    else {
        _14506 = 1;
    }
    _2 = (int)SEQ_PTR(_string_text_25454);
    _14507 = (int)*(((s1_ptr)_2)->base + _14506);
    _14508 = (_14507 == 10);
    _14507 = NOVALUE;
    if (_14508 == 0)
    {
        DeRef(_14508);
        _14508 = NOVALUE;
        goto L13; // [370] 388
    }
    else{
        DeRef(_14508);
        _14508 = NOVALUE;
    }

    /** 			string_text = string_text[1 .. $-1]*/
    if (IS_SEQUENCE(_string_text_25454)){
            _14509 = SEQ_PTR(_string_text_25454)->length;
    }
    else {
        _14509 = 1;
    }
    _14510 = _14509 - 1;
    _14509 = NOVALUE;
    rhs_slice_target = (object_ptr)&_string_text_25454;
    RHS_Slice(_string_text_25454, 1, _14510);
L13: 
L12: 

    /** 	return {STRING, NewStringSym(string_text)}*/
    RefDS(_string_text_25454);
    _14512 = _52NewStringSym(_string_text_25454);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 503;
    ((int *)_2)[2] = _14512;
    _14513 = MAKE_SEQ(_1);
    _14512 = NOVALUE;
    DeRefDSi(_string_text_25454);
    DeRef(_14486);
    _14486 = NOVALUE;
    DeRef(_14491);
    _14491 = NOVALUE;
    DeRef(_14497);
    _14497 = NOVALUE;
    DeRef(_14504);
    _14504 = NOVALUE;
    DeRef(_14510);
    _14510 = NOVALUE;
    return _14513;
    ;
}


int _60GetHexString(int _maxnibbles_25541)
{
    int _ch_25542 = NOVALUE;
    int _digit_25543 = NOVALUE;
    int _val_25544 = NOVALUE;
    int _cline_25545 = NOVALUE;
    int _nibble_25546 = NOVALUE;
    int _string_text_25547 = NOVALUE;
    int _14527 = NOVALUE;
    int _14526 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cline = line_number*/
    _cline_25545 = _26line_number_11983;

    /** 	string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_25547);
    _string_text_25547 = _5;

    /** 	nibble = 1*/
    _nibble_25546 = 1;

    /** 	val = -1*/
    DeRef(_val_25544);
    _val_25544 = -1;

    /** 	ch = getch()*/
    _ch_25542 = _60getch();
    if (!IS_ATOM_INT(_ch_25542)) {
        _1 = (long)(DBL_PTR(_ch_25542)->dbl);
        DeRefDS(_ch_25542);
        _ch_25542 = _1;
    }

    /** 	while 1 do*/
L1: 

    /** 		if ch = END_OF_FILE_CHAR then*/
    if (_ch_25542 != 26)
    goto L2; // [45] 57

    /** 			CompileErr(129, cline)*/
    _43CompileErr(129, _cline_25545, 0);
L2: 

    /** 		if ch = '"' then*/
    if (_ch_25542 != 34)
    goto L3; // [59] 68

    /** 			exit*/
    goto L4; // [65] 224
L3: 

    /** 		digit = find(ch, "0123456789ABCDEFabcdef_ \t\n\r")*/
    _digit_25543 = find_from(_ch_25542, _14517, 1);

    /** 		if digit = 0 then*/
    if (_digit_25543 != 0)
    goto L5; // [77] 89

    /** 			CompileErr(329)*/
    RefDS(_22037);
    _43CompileErr(329, _22037, 0);
L5: 

    /** 		if digit <= 23 then*/
    if (_digit_25543 > 23)
    goto L6; // [91] 177

    /** 			if digit != 23 then*/
    if (_digit_25543 == 23)
    goto L7; // [97] 212

    /** 				if digit > 16 then*/
    if (_digit_25543 <= 16)
    goto L8; // [103] 114

    /** 					digit -= 6*/
    _digit_25543 = _digit_25543 - 6;
L8: 

    /** 				if nibble = 1 then*/
    if (_nibble_25546 != 1)
    goto L9; // [116] 129

    /** 					val = digit - 1*/
    DeRef(_val_25544);
    _val_25544 = _digit_25543 - 1;
    if ((long)((unsigned long)_val_25544 +(unsigned long) HIGH_BITS) >= 0){
        _val_25544 = NewDouble((double)_val_25544);
    }
    goto LA; // [126] 167
L9: 

    /** 					val = val * 16 + digit - 1*/
    if (IS_ATOM_INT(_val_25544)) {
        if (_val_25544 == (short)_val_25544)
        _14526 = _val_25544 * 16;
        else
        _14526 = NewDouble(_val_25544 * (double)16);
    }
    else {
        _14526 = NewDouble(DBL_PTR(_val_25544)->dbl * (double)16);
    }
    if (IS_ATOM_INT(_14526)) {
        _14527 = _14526 + _digit_25543;
        if ((long)((unsigned long)_14527 + (unsigned long)HIGH_BITS) >= 0) 
        _14527 = NewDouble((double)_14527);
    }
    else {
        _14527 = NewDouble(DBL_PTR(_14526)->dbl + (double)_digit_25543);
    }
    DeRef(_14526);
    _14526 = NOVALUE;
    DeRef(_val_25544);
    if (IS_ATOM_INT(_14527)) {
        _val_25544 = _14527 - 1;
        if ((long)((unsigned long)_val_25544 +(unsigned long) HIGH_BITS) >= 0){
            _val_25544 = NewDouble((double)_val_25544);
        }
    }
    else {
        _val_25544 = NewDouble(DBL_PTR(_14527)->dbl - (double)1);
    }
    DeRef(_14527);
    _14527 = NOVALUE;

    /** 					if nibble = maxnibbles then*/
    if (_nibble_25546 != _maxnibbles_25541)
    goto LB; // [145] 166

    /** 						string_text &= val*/
    Ref(_val_25544);
    Append(&_string_text_25547, _string_text_25547, _val_25544);

    /** 						val = -1*/
    DeRef(_val_25544);
    _val_25544 = -1;

    /** 						nibble = 0*/
    _nibble_25546 = 0;
LB: 
LA: 

    /** 				nibble += 1*/
    _nibble_25546 = _nibble_25546 + 1;
    goto L7; // [174] 212
L6: 

    /** 			if val >= 0 then*/
    if (binary_op_a(LESS, _val_25544, 0)){
        goto LC; // [179] 195
    }

    /** 				string_text &= val*/
    Ref(_val_25544);
    Append(&_string_text_25547, _string_text_25547, _val_25544);

    /** 				val = -1*/
    DeRef(_val_25544);
    _val_25544 = -1;
LC: 

    /** 			nibble = 1*/
    _nibble_25546 = 1;

    /** 			if ch = '\n' then*/
    if (_ch_25542 != 10)
    goto LD; // [202] 211

    /** 				read_line()*/
    _60read_line();
LD: 
L7: 

    /** 		ch = getch()*/
    _ch_25542 = _60getch();
    if (!IS_ATOM_INT(_ch_25542)) {
        _1 = (long)(DBL_PTR(_ch_25542)->dbl);
        DeRefDS(_ch_25542);
        _ch_25542 = _1;
    }

    /** 	end while*/
    goto L1; // [221] 41
L4: 

    /** 	if val >= 0 then	*/
    if (binary_op_a(LESS, _val_25544, 0)){
        goto LE; // [226] 237
    }

    /** 		string_text &= val*/
    Ref(_val_25544);
    Append(&_string_text_25547, _string_text_25547, _val_25544);
LE: 

    /** 	return string_text*/
    DeRef(_val_25544);
    return _string_text_25547;
    ;
}


int _60GetBitString()
{
    int _ch_25592 = NOVALUE;
    int _digit_25593 = NOVALUE;
    int _val_25594 = NOVALUE;
    int _cline_25595 = NOVALUE;
    int _bitcnt_25596 = NOVALUE;
    int _string_text_25597 = NOVALUE;
    int _14549 = NOVALUE;
    int _14548 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cline = line_number*/
    _cline_25595 = _26line_number_11983;

    /** 	string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_25597);
    _string_text_25597 = _5;

    /** 	bitcnt = 1*/
    _bitcnt_25596 = 1;

    /** 	val = -1*/
    DeRef(_val_25594);
    _val_25594 = -1;

    /** 	ch = getch()*/
    _ch_25592 = _60getch();
    if (!IS_ATOM_INT(_ch_25592)) {
        _1 = (long)(DBL_PTR(_ch_25592)->dbl);
        DeRefDS(_ch_25592);
        _ch_25592 = _1;
    }

    /** 	while 1 do*/
L1: 

    /** 		if ch = END_OF_FILE_CHAR then*/
    if (_ch_25592 != 26)
    goto L2; // [43] 55

    /** 			CompileErr(129, cline)*/
    _43CompileErr(129, _cline_25595, 0);
L2: 

    /** 		if ch = '"' then*/
    if (_ch_25592 != 34)
    goto L3; // [57] 66

    /** 			exit*/
    goto L4; // [63] 186
L3: 

    /** 		digit = find(ch, "01_ \t\n\r")*/
    _digit_25593 = find_from(_ch_25592, _14541, 1);

    /** 		if digit = 0 then*/
    if (_digit_25593 != 0)
    goto L5; // [75] 87

    /** 			CompileErr(329)*/
    RefDS(_22037);
    _43CompileErr(329, _22037, 0);
L5: 

    /** 		if digit <= 3 then*/
    if (_digit_25593 > 3)
    goto L6; // [89] 139

    /** 			if digit != 3 then*/
    if (_digit_25593 == 3)
    goto L7; // [95] 174

    /** 				if bitcnt = 1 then*/
    if (_bitcnt_25596 != 1)
    goto L8; // [101] 114

    /** 					val = digit - 1*/
    DeRef(_val_25594);
    _val_25594 = _digit_25593 - 1;
    if ((long)((unsigned long)_val_25594 +(unsigned long) HIGH_BITS) >= 0){
        _val_25594 = NewDouble((double)_val_25594);
    }
    goto L9; // [111] 129
L8: 

    /** 					val = val * 2 + digit - 1*/
    if (IS_ATOM_INT(_val_25594) && IS_ATOM_INT(_val_25594)) {
        _14548 = _val_25594 + _val_25594;
        if ((long)((unsigned long)_14548 + (unsigned long)HIGH_BITS) >= 0) 
        _14548 = NewDouble((double)_14548);
    }
    else {
        if (IS_ATOM_INT(_val_25594)) {
            _14548 = NewDouble((double)_val_25594 + DBL_PTR(_val_25594)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_25594)) {
                _14548 = NewDouble(DBL_PTR(_val_25594)->dbl + (double)_val_25594);
            }
            else
            _14548 = NewDouble(DBL_PTR(_val_25594)->dbl + DBL_PTR(_val_25594)->dbl);
        }
    }
    if (IS_ATOM_INT(_14548)) {
        _14549 = _14548 + _digit_25593;
        if ((long)((unsigned long)_14549 + (unsigned long)HIGH_BITS) >= 0) 
        _14549 = NewDouble((double)_14549);
    }
    else {
        _14549 = NewDouble(DBL_PTR(_14548)->dbl + (double)_digit_25593);
    }
    DeRef(_14548);
    _14548 = NOVALUE;
    DeRef(_val_25594);
    if (IS_ATOM_INT(_14549)) {
        _val_25594 = _14549 - 1;
        if ((long)((unsigned long)_val_25594 +(unsigned long) HIGH_BITS) >= 0){
            _val_25594 = NewDouble((double)_val_25594);
        }
    }
    else {
        _val_25594 = NewDouble(DBL_PTR(_14549)->dbl - (double)1);
    }
    DeRef(_14549);
    _14549 = NOVALUE;
L9: 

    /** 				bitcnt += 1*/
    _bitcnt_25596 = _bitcnt_25596 + 1;
    goto L7; // [136] 174
L6: 

    /** 			if val >= 0 then*/
    if (binary_op_a(LESS, _val_25594, 0)){
        goto LA; // [141] 157
    }

    /** 				string_text &= val*/
    Ref(_val_25594);
    Append(&_string_text_25597, _string_text_25597, _val_25594);

    /** 				val = -1*/
    DeRef(_val_25594);
    _val_25594 = -1;
LA: 

    /** 			bitcnt = 1*/
    _bitcnt_25596 = 1;

    /** 			if ch = '\n' then*/
    if (_ch_25592 != 10)
    goto LB; // [164] 173

    /** 				read_line()*/
    _60read_line();
LB: 
L7: 

    /** 		ch = getch()*/
    _ch_25592 = _60getch();
    if (!IS_ATOM_INT(_ch_25592)) {
        _1 = (long)(DBL_PTR(_ch_25592)->dbl);
        DeRefDS(_ch_25592);
        _ch_25592 = _1;
    }

    /** 	end while*/
    goto L1; // [183] 39
L4: 

    /** 	if val >= 0 then	*/
    if (binary_op_a(LESS, _val_25594, 0)){
        goto LC; // [188] 199
    }

    /** 		string_text &= val*/
    Ref(_val_25594);
    Append(&_string_text_25597, _string_text_25597, _val_25594);
LC: 

    /** 	return string_text*/
    DeRef(_val_25594);
    return _string_text_25597;
    ;
}


int _60Scanner()
{
    int _fwd_inlined_set_qualified_fwd_at_441_25735 = NOVALUE;
    int _ch_25636 = NOVALUE;
    int _i_25637 = NOVALUE;
    int _sp_25638 = NOVALUE;
    int _prev_Nne_25639 = NOVALUE;
    int _pch_25640 = NOVALUE;
    int _cline_25641 = NOVALUE;
    int _yytext_25642 = NOVALUE;
    int _namespaces_25643 = NOVALUE;
    int _d_25644 = NOVALUE;
    int _tok_25646 = NOVALUE;
    int _is_int_25647 = NOVALUE;
    int _class_25648 = NOVALUE;
    int _name_25649 = NOVALUE;
    int _is_namespace_25708 = NOVALUE;
    int _basetype_25942 = NOVALUE;
    int _hdigit_25982 = NOVALUE;
    int _fch_26120 = NOVALUE;
    int _cnest_26297 = NOVALUE;
    int _ach_26326 = NOVALUE;
    int _31683 = NOVALUE;
    int _31682 = NOVALUE;
    int _31681 = NOVALUE;
    int _31680 = NOVALUE;
    int _31679 = NOVALUE;
    int _31678 = NOVALUE;
    int _31677 = NOVALUE;
    int _14945 = NOVALUE;
    int _14944 = NOVALUE;
    int _14942 = NOVALUE;
    int _14940 = NOVALUE;
    int _14939 = NOVALUE;
    int _14938 = NOVALUE;
    int _14936 = NOVALUE;
    int _14935 = NOVALUE;
    int _14934 = NOVALUE;
    int _14933 = NOVALUE;
    int _14931 = NOVALUE;
    int _14930 = NOVALUE;
    int _14928 = NOVALUE;
    int _14926 = NOVALUE;
    int _14925 = NOVALUE;
    int _14923 = NOVALUE;
    int _14921 = NOVALUE;
    int _14920 = NOVALUE;
    int _14918 = NOVALUE;
    int _14916 = NOVALUE;
    int _14915 = NOVALUE;
    int _14914 = NOVALUE;
    int _14913 = NOVALUE;
    int _14912 = NOVALUE;
    int _14910 = NOVALUE;
    int _14909 = NOVALUE;
    int _14899 = NOVALUE;
    int _14886 = NOVALUE;
    int _14882 = NOVALUE;
    int _14881 = NOVALUE;
    int _14877 = NOVALUE;
    int _14876 = NOVALUE;
    int _14875 = NOVALUE;
    int _14874 = NOVALUE;
    int _14872 = NOVALUE;
    int _14871 = NOVALUE;
    int _14868 = NOVALUE;
    int _14867 = NOVALUE;
    int _14866 = NOVALUE;
    int _14865 = NOVALUE;
    int _14864 = NOVALUE;
    int _14863 = NOVALUE;
    int _14861 = NOVALUE;
    int _14860 = NOVALUE;
    int _14859 = NOVALUE;
    int _14858 = NOVALUE;
    int _14857 = NOVALUE;
    int _14856 = NOVALUE;
    int _14854 = NOVALUE;
    int _14853 = NOVALUE;
    int _14850 = NOVALUE;
    int _14847 = NOVALUE;
    int _14842 = NOVALUE;
    int _14841 = NOVALUE;
    int _14840 = NOVALUE;
    int _14839 = NOVALUE;
    int _14838 = NOVALUE;
    int _14837 = NOVALUE;
    int _14835 = NOVALUE;
    int _14834 = NOVALUE;
    int _14833 = NOVALUE;
    int _14832 = NOVALUE;
    int _14831 = NOVALUE;
    int _14830 = NOVALUE;
    int _14828 = NOVALUE;
    int _14827 = NOVALUE;
    int _14824 = NOVALUE;
    int _14821 = NOVALUE;
    int _14819 = NOVALUE;
    int _14818 = NOVALUE;
    int _14814 = NOVALUE;
    int _14813 = NOVALUE;
    int _14809 = NOVALUE;
    int _14808 = NOVALUE;
    int _14807 = NOVALUE;
    int _14805 = NOVALUE;
    int _14800 = NOVALUE;
    int _14797 = NOVALUE;
    int _14796 = NOVALUE;
    int _14795 = NOVALUE;
    int _14794 = NOVALUE;
    int _14788 = NOVALUE;
    int _14786 = NOVALUE;
    int _14781 = NOVALUE;
    int _14780 = NOVALUE;
    int _14779 = NOVALUE;
    int _14778 = NOVALUE;
    int _14777 = NOVALUE;
    int _14776 = NOVALUE;
    int _14775 = NOVALUE;
    int _14773 = NOVALUE;
    int _14771 = NOVALUE;
    int _14770 = NOVALUE;
    int _14769 = NOVALUE;
    int _14768 = NOVALUE;
    int _14767 = NOVALUE;
    int _14765 = NOVALUE;
    int _14761 = NOVALUE;
    int _14760 = NOVALUE;
    int _14759 = NOVALUE;
    int _14758 = NOVALUE;
    int _14757 = NOVALUE;
    int _14755 = NOVALUE;
    int _14754 = NOVALUE;
    int _14752 = NOVALUE;
    int _14748 = NOVALUE;
    int _14745 = NOVALUE;
    int _14744 = NOVALUE;
    int _14742 = NOVALUE;
    int _14741 = NOVALUE;
    int _14740 = NOVALUE;
    int _14737 = NOVALUE;
    int _14735 = NOVALUE;
    int _14734 = NOVALUE;
    int _14730 = NOVALUE;
    int _14726 = NOVALUE;
    int _14723 = NOVALUE;
    int _14717 = NOVALUE;
    int _14709 = NOVALUE;
    int _14708 = NOVALUE;
    int _14707 = NOVALUE;
    int _14705 = NOVALUE;
    int _14702 = NOVALUE;
    int _14700 = NOVALUE;
    int _14698 = NOVALUE;
    int _14695 = NOVALUE;
    int _14692 = NOVALUE;
    int _14690 = NOVALUE;
    int _14688 = NOVALUE;
    int _14686 = NOVALUE;
    int _14685 = NOVALUE;
    int _14681 = NOVALUE;
    int _14678 = NOVALUE;
    int _14676 = NOVALUE;
    int _14673 = NOVALUE;
    int _14666 = NOVALUE;
    int _14664 = NOVALUE;
    int _14661 = NOVALUE;
    int _14655 = NOVALUE;
    int _14654 = NOVALUE;
    int _14653 = NOVALUE;
    int _14652 = NOVALUE;
    int _14651 = NOVALUE;
    int _14650 = NOVALUE;
    int _14649 = NOVALUE;
    int _14647 = NOVALUE;
    int _14645 = NOVALUE;
    int _14643 = NOVALUE;
    int _14641 = NOVALUE;
    int _14639 = NOVALUE;
    int _14638 = NOVALUE;
    int _14637 = NOVALUE;
    int _14636 = NOVALUE;
    int _14635 = NOVALUE;
    int _14633 = NOVALUE;
    int _14630 = NOVALUE;
    int _14628 = NOVALUE;
    int _14627 = NOVALUE;
    int _14626 = NOVALUE;
    int _14624 = NOVALUE;
    int _14619 = NOVALUE;
    int _14615 = NOVALUE;
    int _14612 = NOVALUE;
    int _14610 = NOVALUE;
    int _14609 = NOVALUE;
    int _14607 = NOVALUE;
    int _14605 = NOVALUE;
    int _14603 = NOVALUE;
    int _14602 = NOVALUE;
    int _14601 = NOVALUE;
    int _14599 = NOVALUE;
    int _14594 = NOVALUE;
    int _14591 = NOVALUE;
    int _14589 = NOVALUE;
    int _14586 = NOVALUE;
    int _14585 = NOVALUE;
    int _14583 = NOVALUE;
    int _14582 = NOVALUE;
    int _14581 = NOVALUE;
    int _14580 = NOVALUE;
    int _14579 = NOVALUE;
    int _14578 = NOVALUE;
    int _14577 = NOVALUE;
    int _14576 = NOVALUE;
    int _14575 = NOVALUE;
    int _14574 = NOVALUE;
    int _14573 = NOVALUE;
    int _14572 = NOVALUE;
    int _14571 = NOVALUE;
    int _14566 = NOVALUE;
    int _14564 = NOVALUE;
    int _14561 = NOVALUE;
    int _14559 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer is_int, class*/

    /** 	sequence name*/

    /** 	while TRUE do*/
L1: 
    if (_9TRUE_430 == 0)
    {
        goto L2; // [12] 3802
    }
    else{
    }

    /** 		ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 		while ch = ' ' or ch = '\t' do*/
L3: 
    _14559 = (_ch_25636 == 32);
    if (_14559 != 0) {
        goto L4; // [31] 44
    }
    _14561 = (_ch_25636 == 9);
    if (_14561 == 0)
    {
        DeRef(_14561);
        _14561 = NOVALUE;
        goto L5; // [40] 56
    }
    else{
        DeRef(_14561);
        _14561 = NOVALUE;
    }
L4: 

    /** 			ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 		end while*/
    goto L3; // [53] 27
L5: 

    /** 		class = char_class[ch]*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _class_25648 = (int)*(((s1_ptr)_2)->base + _ch_25636);

    /** 		if class = LETTER or ch = '_' then*/
    _14564 = (_class_25648 == -2);
    if (_14564 != 0) {
        goto L6; // [72] 85
    }
    _14566 = (_ch_25636 == 95);
    if (_14566 == 0)
    {
        DeRef(_14566);
        _14566 = NOVALUE;
        goto L7; // [81] 1282
    }
    else{
        DeRef(_14566);
        _14566 = NOVALUE;
    }
L6: 

    /** 			sp = bp*/
    _sp_25638 = _43bp_48561;

    /** 			pch = ch*/
    _pch_25640 = _ch_25636;

    /** 			ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 			if ch = '"' then*/
    if (_ch_25636 != 34)
    goto L8; // [108] 222

    /** 				switch pch do*/
    _0 = _pch_25640;
    switch ( _0 ){ 

        /** 					case 'x' then*/
        case 120:

        /** 						return {STRING, NewStringSym(GetHexString(2))}*/
        _14571 = _60GetHexString(2);
        _14572 = _52NewStringSym(_14571);
        _14571 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 503;
        ((int *)_2)[2] = _14572;
        _14573 = MAKE_SEQ(_1);
        _14572 = NOVALUE;
        DeRef(_yytext_25642);
        DeRef(_namespaces_25643);
        DeRef(_d_25644);
        DeRef(_tok_25646);
        DeRef(_name_25649);
        DeRef(_14559);
        _14559 = NOVALUE;
        DeRef(_14564);
        _14564 = NOVALUE;
        return _14573;
        goto L9; // [143] 221

        /** 					case 'u' then*/
        case 117:

        /** 						return {STRING, NewStringSym(GetHexString(4))}*/
        _14574 = _60GetHexString(4);
        _14575 = _52NewStringSym(_14574);
        _14574 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 503;
        ((int *)_2)[2] = _14575;
        _14576 = MAKE_SEQ(_1);
        _14575 = NOVALUE;
        DeRef(_yytext_25642);
        DeRef(_namespaces_25643);
        DeRef(_d_25644);
        DeRef(_tok_25646);
        DeRef(_name_25649);
        DeRef(_14559);
        _14559 = NOVALUE;
        DeRef(_14564);
        _14564 = NOVALUE;
        DeRef(_14573);
        _14573 = NOVALUE;
        return _14576;
        goto L9; // [169] 221

        /** 					case 'U' then*/
        case 85:

        /** 						return {STRING, NewStringSym(GetHexString(8))}*/
        _14577 = _60GetHexString(8);
        _14578 = _52NewStringSym(_14577);
        _14577 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 503;
        ((int *)_2)[2] = _14578;
        _14579 = MAKE_SEQ(_1);
        _14578 = NOVALUE;
        DeRef(_yytext_25642);
        DeRef(_namespaces_25643);
        DeRef(_d_25644);
        DeRef(_tok_25646);
        DeRef(_name_25649);
        DeRef(_14559);
        _14559 = NOVALUE;
        DeRef(_14564);
        _14564 = NOVALUE;
        DeRef(_14573);
        _14573 = NOVALUE;
        DeRef(_14576);
        _14576 = NOVALUE;
        return _14579;
        goto L9; // [195] 221

        /** 					case 'b' then*/
        case 98:

        /** 						return {STRING, NewStringSym(GetBitString())}*/
        _14580 = _60GetBitString();
        _14581 = _52NewStringSym(_14580);
        _14580 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 503;
        ((int *)_2)[2] = _14581;
        _14582 = MAKE_SEQ(_1);
        _14581 = NOVALUE;
        DeRef(_yytext_25642);
        DeRef(_namespaces_25643);
        DeRef(_d_25644);
        DeRef(_tok_25646);
        DeRef(_name_25649);
        DeRef(_14559);
        _14559 = NOVALUE;
        DeRef(_14564);
        _14564 = NOVALUE;
        DeRef(_14573);
        _14573 = NOVALUE;
        DeRef(_14576);
        _14576 = NOVALUE;
        DeRef(_14579);
        _14579 = NOVALUE;
        return _14582;
    ;}L9: 
L8: 

    /** 			while id_char[ch] do*/
LA: 
    _2 = (int)SEQ_PTR(_60id_char_23945);
    _14583 = (int)*(((s1_ptr)_2)->base + _ch_25636);
    if (_14583 == 0)
    {
        _14583 = NOVALUE;
        goto LB; // [233] 248
    }
    else{
        _14583 = NOVALUE;
    }

    /** 				ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 			end while*/
    goto LA; // [245] 227
LB: 

    /** 			yytext = ThisLine[sp-1..bp-2]*/
    _14585 = _sp_25638 - 1;
    if ((long)((unsigned long)_14585 +(unsigned long) HIGH_BITS) >= 0){
        _14585 = NewDouble((double)_14585);
    }
    _14586 = _43bp_48561 - 2;
    rhs_slice_target = (object_ptr)&_yytext_25642;
    RHS_Slice(_43ThisLine_48557, _14585, _14586);

    /** 			ungetch()*/
    _60ungetch();

    /** 			ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 			while ch = ' ' or ch = '\t' do*/
LC: 
    _14589 = (_ch_25636 == 32);
    if (_14589 != 0) {
        goto LD; // [287] 300
    }
    _14591 = (_ch_25636 == 9);
    if (_14591 == 0)
    {
        DeRef(_14591);
        _14591 = NOVALUE;
        goto LE; // [296] 312
    }
    else{
        DeRef(_14591);
        _14591 = NOVALUE;
    }
LD: 

    /** 				ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 			end while*/
    goto LC; // [309] 283
LE: 

    /** 			integer is_namespace*/

    /** 			if might_be_namespace then*/
    if (_60might_be_namespace_25440 == 0)
    {
        goto LF; // [318] 361
    }
    else{
    }

    /** 				tok = keyfind(yytext, -1, , -1 )*/
    RefDS(_yytext_25642);
    _31683 = _52hashfn(_yytext_25642);
    RefDS(_yytext_25642);
    _0 = _tok_25646;
    _tok_25646 = _52keyfind(_yytext_25642, -1, _26current_file_no_11982, -1, _31683);
    DeRef(_0);
    _31683 = NOVALUE;

    /** 				is_namespace = tok[T_ID] = NAMESPACE*/
    _2 = (int)SEQ_PTR(_tok_25646);
    _14594 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_14594)) {
        _is_namespace_25708 = (_14594 == 523);
    }
    else {
        _is_namespace_25708 = binary_op(EQUALS, _14594, 523);
    }
    _14594 = NOVALUE;
    if (!IS_ATOM_INT(_is_namespace_25708)) {
        _1 = (long)(DBL_PTR(_is_namespace_25708)->dbl);
        DeRefDS(_is_namespace_25708);
        _is_namespace_25708 = _1;
    }

    /** 				might_be_namespace = 0*/
    _60might_be_namespace_25440 = 0;
    goto L10; // [358] 384
LF: 

    /** 				is_namespace = ch = ':'*/
    _is_namespace_25708 = (_ch_25636 == 58);

    /** 				tok = keyfind(yytext, -1, , is_namespace )*/
    RefDS(_yytext_25642);
    _31682 = _52hashfn(_yytext_25642);
    RefDS(_yytext_25642);
    _0 = _tok_25646;
    _tok_25646 = _52keyfind(_yytext_25642, -1, _26current_file_no_11982, _is_namespace_25708, _31682);
    DeRef(_0);
    _31682 = NOVALUE;
L10: 

    /** 			if not is_namespace then*/
    if (_is_namespace_25708 != 0)
    goto L11; // [388] 396

    /** 				ungetch()*/
    _60ungetch();
L11: 

    /** 			if is_namespace then*/
    if (_is_namespace_25708 == 0)
    {
        goto L12; // [398] 1119
    }
    else{
    }

    /** 				namespaces = yytext*/
    RefDS(_yytext_25642);
    DeRef(_namespaces_25643);
    _namespaces_25643 = _yytext_25642;

    /** 				if tok[T_ID] = NAMESPACE then -- known namespace*/
    _2 = (int)SEQ_PTR(_tok_25646);
    _14599 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14599, 523)){
        _14599 = NOVALUE;
        goto L13; // [420] 974
    }
    _14599 = NOVALUE;

    /** 					set_qualified_fwd( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (int)SEQ_PTR(_tok_25646);
    _14601 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_14601)){
        _14602 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14601)->dbl));
    }
    else{
        _14602 = (int)*(((s1_ptr)_2)->base + _14601);
    }
    _2 = (int)SEQ_PTR(_14602);
    _14603 = (int)*(((s1_ptr)_2)->base + 1);
    _14602 = NOVALUE;
    Ref(_14603);
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_25735);
    _fwd_inlined_set_qualified_fwd_at_441_25735 = _14603;
    _14603 = NOVALUE;
    if (!IS_ATOM_INT(_fwd_inlined_set_qualified_fwd_at_441_25735)) {
        _1 = (long)(DBL_PTR(_fwd_inlined_set_qualified_fwd_at_441_25735)->dbl);
        DeRefDS(_fwd_inlined_set_qualified_fwd_at_441_25735);
        _fwd_inlined_set_qualified_fwd_at_441_25735 = _1;
    }

    /** 	qualified_fwd = fwd*/
    _60qualified_fwd_23969 = _fwd_inlined_set_qualified_fwd_at_441_25735;

    /** end procedure*/
    goto L14; // [456] 459
L14: 
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_25735);
    _fwd_inlined_set_qualified_fwd_at_441_25735 = NOVALUE;

    /** 					ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 					while ch = ' ' or ch = '\t' do*/
L15: 
    _14605 = (_ch_25636 == 32);
    if (_14605 != 0) {
        goto L16; // [477] 490
    }
    _14607 = (_ch_25636 == 9);
    if (_14607 == 0)
    {
        DeRef(_14607);
        _14607 = NOVALUE;
        goto L17; // [486] 502
    }
    else{
        DeRef(_14607);
        _14607 = NOVALUE;
    }
L16: 

    /** 						ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 					end while*/
    goto L15; // [499] 473
L17: 

    /** 					yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_25642);
    _yytext_25642 = _5;

    /** 					if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _14609 = (int)*(((s1_ptr)_2)->base + _ch_25636);
    _14610 = (_14609 == -2);
    _14609 = NOVALUE;
    if (_14610 != 0) {
        goto L18; // [523] 536
    }
    _14612 = (_ch_25636 == 95);
    if (_14612 == 0)
    {
        DeRef(_14612);
        _14612 = NOVALUE;
        goto L19; // [532] 589
    }
    else{
        DeRef(_14612);
        _14612 = NOVALUE;
    }
L18: 

    /** 						yytext &= ch*/
    Append(&_yytext_25642, _yytext_25642, _ch_25636);

    /** 						ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 						while id_char[ch] = TRUE do*/
L1A: 
    _2 = (int)SEQ_PTR(_60id_char_23945);
    _14615 = (int)*(((s1_ptr)_2)->base + _ch_25636);
    if (_14615 != _9TRUE_430)
    goto L1B; // [562] 584

    /** 							yytext &= ch*/
    Append(&_yytext_25642, _yytext_25642, _ch_25636);

    /** 							ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 						end while*/
    goto L1A; // [581] 554
L1B: 

    /** 						ungetch()*/
    _60ungetch();
L19: 

    /** 					if length(yytext) = 0 then*/
    if (IS_SEQUENCE(_yytext_25642)){
            _14619 = SEQ_PTR(_yytext_25642)->length;
    }
    else {
        _14619 = 1;
    }
    if (_14619 != 0)
    goto L1C; // [594] 606

    /** 						CompileErr(32)*/
    RefDS(_22037);
    _43CompileErr(32, _22037, 0);
L1C: 

    /** 				    if Parser_mode = PAM_RECORD then*/
    if (_26Parser_mode_12088 != 1)
    goto L1D; // [612] 773

    /** 		                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_25642);
    Append(&_26Recorded_12089, _26Recorded_12089, _yytext_25642);

    /** 		                Ns_recorded = append(Ns_recorded,namespaces)*/
    RefDS(_namespaces_25643);
    Append(&_26Ns_recorded_12090, _26Ns_recorded_12090, _namespaces_25643);

    /** 		                Ns_recorded_sym &= tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_25646);
    _14624 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_26Ns_recorded_sym_12092) && IS_ATOM(_14624)) {
        Ref(_14624);
        Append(&_26Ns_recorded_sym_12092, _26Ns_recorded_sym_12092, _14624);
    }
    else if (IS_ATOM(_26Ns_recorded_sym_12092) && IS_SEQUENCE(_14624)) {
    }
    else {
        Concat((object_ptr)&_26Ns_recorded_sym_12092, _26Ns_recorded_sym_12092, _14624);
    }
    _14624 = NOVALUE;

    /** 		                prev_Nne = No_new_entry*/
    _prev_Nne_25639 = _52No_new_entry_47302;

    /** 						No_new_entry = 1*/
    _52No_new_entry_47302 = 1;

    /** 						tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (int)SEQ_PTR(_tok_25646);
    _14626 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_14626)){
        _14627 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14626)->dbl));
    }
    else{
        _14627 = (int)*(((s1_ptr)_2)->base + _14626);
    }
    _2 = (int)SEQ_PTR(_14627);
    _14628 = (int)*(((s1_ptr)_2)->base + 1);
    _14627 = NOVALUE;
    RefDS(_yytext_25642);
    _31681 = _52hashfn(_yytext_25642);
    RefDS(_yytext_25642);
    Ref(_14628);
    _0 = _tok_25646;
    _tok_25646 = _52keyfind(_yytext_25642, _14628, _26current_file_no_11982, 0, _31681);
    DeRef(_0);
    _14628 = NOVALUE;
    _31681 = NOVALUE;

    /** 						if tok[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_tok_25646);
    _14630 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14630, 509)){
        _14630 = NOVALUE;
        goto L1E; // [712] 729
    }
    _14630 = NOVALUE;

    /** 							Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_26Recorded_sym_12091, _26Recorded_sym_12091, 0);
    goto L1F; // [726] 746
L1E: 

    /** 							Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (int)SEQ_PTR(_tok_25646);
    _14633 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_26Recorded_sym_12091) && IS_ATOM(_14633)) {
        Ref(_14633);
        Append(&_26Recorded_sym_12091, _26Recorded_sym_12091, _14633);
    }
    else if (IS_ATOM(_26Recorded_sym_12091) && IS_SEQUENCE(_14633)) {
    }
    else {
        Concat((object_ptr)&_26Recorded_sym_12091, _26Recorded_sym_12091, _14633);
    }
    _14633 = NOVALUE;
L1F: 

    /** 		                No_new_entry = prev_Nne*/
    _52No_new_entry_47302 = _prev_Nne_25639;

    /** 		                return {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_26Recorded_12089)){
            _14635 = SEQ_PTR(_26Recorded_12089)->length;
    }
    else {
        _14635 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 508;
    ((int *)_2)[2] = _14635;
    _14636 = MAKE_SEQ(_1);
    _14635 = NOVALUE;
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    _14626 = NOVALUE;
    return _14636;
    goto L20; // [770] 915
L1D: 

    /** 						tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (int)SEQ_PTR(_tok_25646);
    _14637 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_14637)){
        _14638 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14637)->dbl));
    }
    else{
        _14638 = (int)*(((s1_ptr)_2)->base + _14637);
    }
    _2 = (int)SEQ_PTR(_14638);
    _14639 = (int)*(((s1_ptr)_2)->base + 1);
    _14638 = NOVALUE;
    RefDS(_yytext_25642);
    _31680 = _52hashfn(_yytext_25642);
    RefDS(_yytext_25642);
    Ref(_14639);
    _0 = _tok_25646;
    _tok_25646 = _52keyfind(_yytext_25642, _14639, _26current_file_no_11982, 0, _31680);
    DeRef(_0);
    _14639 = NOVALUE;
    _31680 = NOVALUE;

    /** 						if tok[T_ID] = VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_25646);
    _14641 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14641, -100)){
        _14641 = NOVALUE;
        goto L21; // [817] 834
    }
    _14641 = NOVALUE;

    /** 							tok[T_ID] = QUALIFIED_VARIABLE*/
    _2 = (int)SEQ_PTR(_tok_25646);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_25646 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 512;
    DeRef(_1);
    goto L22; // [831] 914
L21: 

    /** 						elsif tok[T_ID] = FUNC then*/
    _2 = (int)SEQ_PTR(_tok_25646);
    _14643 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14643, 501)){
        _14643 = NOVALUE;
        goto L23; // [844] 861
    }
    _14643 = NOVALUE;

    /** 							tok[T_ID] = QUALIFIED_FUNC*/
    _2 = (int)SEQ_PTR(_tok_25646);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_25646 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 520;
    DeRef(_1);
    goto L22; // [858] 914
L23: 

    /** 						elsif tok[T_ID] = PROC then*/
    _2 = (int)SEQ_PTR(_tok_25646);
    _14645 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14645, 27)){
        _14645 = NOVALUE;
        goto L24; // [871] 888
    }
    _14645 = NOVALUE;

    /** 							tok[T_ID] = QUALIFIED_PROC*/
    _2 = (int)SEQ_PTR(_tok_25646);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_25646 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 521;
    DeRef(_1);
    goto L22; // [885] 914
L24: 

    /** 						elsif tok[T_ID] = TYPE then*/
    _2 = (int)SEQ_PTR(_tok_25646);
    _14647 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14647, 504)){
        _14647 = NOVALUE;
        goto L25; // [898] 913
    }
    _14647 = NOVALUE;

    /** 							tok[T_ID] = QUALIFIED_TYPE*/
    _2 = (int)SEQ_PTR(_tok_25646);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_25646 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 522;
    DeRef(_1);
L25: 
L22: 
L20: 

    /** 					if atom( tok[T_SYM] ) and  SymTab[tok[T_SYM]][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_tok_25646);
    _14649 = (int)*(((s1_ptr)_2)->base + 2);
    _14650 = IS_ATOM(_14649);
    _14649 = NOVALUE;
    if (_14650 == 0) {
        goto L26; // [926] 1269
    }
    _2 = (int)SEQ_PTR(_tok_25646);
    _14652 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_14652)){
        _14653 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14652)->dbl));
    }
    else{
        _14653 = (int)*(((s1_ptr)_2)->base + _14652);
    }
    _2 = (int)SEQ_PTR(_14653);
    _14654 = (int)*(((s1_ptr)_2)->base + 4);
    _14653 = NOVALUE;
    if (IS_ATOM_INT(_14654)) {
        _14655 = (_14654 != 9);
    }
    else {
        _14655 = binary_op(NOTEQ, _14654, 9);
    }
    _14654 = NOVALUE;
    if (_14655 == 0) {
        DeRef(_14655);
        _14655 = NOVALUE;
        goto L26; // [955] 1269
    }
    else {
        if (!IS_ATOM_INT(_14655) && DBL_PTR(_14655)->dbl == 0.0){
            DeRef(_14655);
            _14655 = NOVALUE;
            goto L26; // [955] 1269
        }
        DeRef(_14655);
        _14655 = NOVALUE;
    }
    DeRef(_14655);
    _14655 = NOVALUE;

    /** 						set_qualified_fwd( -1 )*/

    /** 	qualified_fwd = fwd*/
    _60qualified_fwd_23969 = -1;

    /** end procedure*/
    goto L26; // [967] 1269
    goto L26; // [971] 1269
L13: 

    /** 					ungetch()*/
    _60ungetch();

    /** 				    if Parser_mode = PAM_RECORD then*/
    if (_26Parser_mode_12088 != 1)
    goto L26; // [984] 1269

    /** 		                Ns_recorded &= 0*/
    Append(&_26Ns_recorded_12090, _26Ns_recorded_12090, 0);

    /** 		                Ns_recorded_sym &= 0*/
    Append(&_26Ns_recorded_sym_12092, _26Ns_recorded_sym_12092, 0);

    /** 		                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_25642);
    Append(&_26Recorded_12089, _26Recorded_12089, _yytext_25642);

    /** 		                prev_Nne = No_new_entry*/
    _prev_Nne_25639 = _52No_new_entry_47302;

    /** 						No_new_entry = 1*/
    _52No_new_entry_47302 = 1;

    /** 						tok = keyfind(yytext, -1)*/
    RefDS(_yytext_25642);
    _31679 = _52hashfn(_yytext_25642);
    RefDS(_yytext_25642);
    _0 = _tok_25646;
    _tok_25646 = _52keyfind(_yytext_25642, -1, _26current_file_no_11982, 0, _31679);
    DeRef(_0);
    _31679 = NOVALUE;

    /** 						if tok[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_tok_25646);
    _14661 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14661, 509)){
        _14661 = NOVALUE;
        goto L27; // [1060] 1077
    }
    _14661 = NOVALUE;

    /** 							Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_26Recorded_sym_12091, _26Recorded_sym_12091, 0);
    goto L28; // [1074] 1094
L27: 

    /** 							Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (int)SEQ_PTR(_tok_25646);
    _14664 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_26Recorded_sym_12091) && IS_ATOM(_14664)) {
        Ref(_14664);
        Append(&_26Recorded_sym_12091, _26Recorded_sym_12091, _14664);
    }
    else if (IS_ATOM(_26Recorded_sym_12091) && IS_SEQUENCE(_14664)) {
    }
    else {
        Concat((object_ptr)&_26Recorded_sym_12091, _26Recorded_sym_12091, _14664);
    }
    _14664 = NOVALUE;
L28: 

    /** 		                No_new_entry = prev_Nne*/
    _52No_new_entry_47302 = _prev_Nne_25639;

    /** 		                tok = {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_26Recorded_12089)){
            _14666 = SEQ_PTR(_26Recorded_12089)->length;
    }
    else {
        _14666 = 1;
    }
    DeRef(_tok_25646);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 508;
    ((int *)_2)[2] = _14666;
    _tok_25646 = MAKE_SEQ(_1);
    _14666 = NOVALUE;
    goto L26; // [1116] 1269
L12: 

    /** 				set_qualified_fwd( -1 )*/

    /** 	qualified_fwd = fwd*/
    _60qualified_fwd_23969 = -1;

    /** end procedure*/
    goto L29; // [1128] 1131
L29: 

    /** 			    if Parser_mode = PAM_RECORD then*/
    if (_26Parser_mode_12088 != 1)
    goto L2A; // [1137] 1268

    /** 	                Ns_recorded_sym &= 0*/
    Append(&_26Ns_recorded_sym_12092, _26Ns_recorded_sym_12092, 0);

    /** 						Recorded = append(Recorded, yytext)*/
    RefDS(_yytext_25642);
    Append(&_26Recorded_12089, _26Recorded_12089, _yytext_25642);

    /** 		                Ns_recorded &= 0*/
    Append(&_26Ns_recorded_12090, _26Ns_recorded_12090, 0);

    /** 		                prev_Nne = No_new_entry*/
    _prev_Nne_25639 = _52No_new_entry_47302;

    /** 						No_new_entry = 1*/
    _52No_new_entry_47302 = 1;

    /** 						tok = keyfind(yytext, -1)*/
    RefDS(_yytext_25642);
    _31678 = _52hashfn(_yytext_25642);
    RefDS(_yytext_25642);
    _0 = _tok_25646;
    _tok_25646 = _52keyfind(_yytext_25642, -1, _26current_file_no_11982, 0, _31678);
    DeRef(_0);
    _31678 = NOVALUE;

    /** 						if tok[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_tok_25646);
    _14673 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14673, 509)){
        _14673 = NOVALUE;
        goto L2B; // [1213] 1230
    }
    _14673 = NOVALUE;

    /** 							Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_26Recorded_sym_12091, _26Recorded_sym_12091, 0);
    goto L2C; // [1227] 1247
L2B: 

    /** 							Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (int)SEQ_PTR(_tok_25646);
    _14676 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_26Recorded_sym_12091) && IS_ATOM(_14676)) {
        Ref(_14676);
        Append(&_26Recorded_sym_12091, _26Recorded_sym_12091, _14676);
    }
    else if (IS_ATOM(_26Recorded_sym_12091) && IS_SEQUENCE(_14676)) {
    }
    else {
        Concat((object_ptr)&_26Recorded_sym_12091, _26Recorded_sym_12091, _14676);
    }
    _14676 = NOVALUE;
L2C: 

    /** 		                No_new_entry = prev_Nne*/
    _52No_new_entry_47302 = _prev_Nne_25639;

    /** 	                tok = {RECORDED, length(Recorded)}*/
    if (IS_SEQUENCE(_26Recorded_12089)){
            _14678 = SEQ_PTR(_26Recorded_12089)->length;
    }
    else {
        _14678 = 1;
    }
    DeRef(_tok_25646);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 508;
    ((int *)_2)[2] = _14678;
    _tok_25646 = MAKE_SEQ(_1);
    _14678 = NOVALUE;
L2A: 
L26: 

    /** 			return tok*/
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_name_25649);
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    _14626 = NOVALUE;
    DeRef(_14636);
    _14636 = NOVALUE;
    _14637 = NOVALUE;
    _14652 = NOVALUE;
    return _tok_25646;
    goto L1; // [1279] 10
L7: 

    /** 		elsif class < ILLEGAL_CHAR then*/
    if (_class_25648 >= -20)
    goto L2D; // [1286] 1303

    /** 			return {class, 0}  -- brackets, punctuation, eof, illegal char etc.*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _class_25648;
    ((int *)_2)[2] = 0;
    _14681 = MAKE_SEQ(_1);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    _14626 = NOVALUE;
    DeRef(_14636);
    _14636 = NOVALUE;
    _14637 = NOVALUE;
    _14652 = NOVALUE;
    return _14681;
    goto L1; // [1300] 10
L2D: 

    /** 		elsif class = ILLEGAL_CHAR then*/
    if (_class_25648 != -20)
    goto L2E; // [1307] 1321

    /** 			CompileErr(101)*/
    RefDS(_22037);
    _43CompileErr(101, _22037, 0);
    goto L1; // [1318] 10
L2E: 

    /** 		elsif class = NEWLINE then*/
    if (_class_25648 != -6)
    goto L2F; // [1325] 1351

    /** 			if start_include then*/
    if (_60start_include_23937 == 0)
    {
        goto L30; // [1333] 1343
    }
    else{
    }

    /** 				IncludePush()*/
    _60IncludePush();
    goto L1; // [1340] 10
L30: 

    /** 				read_line()*/
    _60read_line();
    goto L1; // [1348] 10
L2F: 

    /** 		elsif class = EQUALS then*/
    if (_class_25648 != 3)
    goto L31; // [1355] 1372

    /** 			return {class, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _class_25648;
    ((int *)_2)[2] = 0;
    _14685 = MAKE_SEQ(_1);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    _14626 = NOVALUE;
    DeRef(_14636);
    _14636 = NOVALUE;
    _14637 = NOVALUE;
    _14652 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    return _14685;
    goto L1; // [1369] 10
L31: 

    /** 		elsif class = DOT or class = DIGIT then*/
    _14686 = (_class_25648 == -3);
    if (_14686 != 0) {
        goto L32; // [1380] 1395
    }
    _14688 = (_class_25648 == -7);
    if (_14688 == 0)
    {
        DeRef(_14688);
        _14688 = NOVALUE;
        goto L33; // [1391] 2196
    }
    else{
        DeRef(_14688);
        _14688 = NOVALUE;
    }
L32: 

    /** 			integer basetype*/

    /** 			if class = DOT then*/
    if (_class_25648 != -3)
    goto L34; // [1401] 1435

    /** 				if getch() = '.' then*/
    _14690 = _60getch();
    if (binary_op_a(NOTEQ, _14690, 46)){
        DeRef(_14690);
        _14690 = NOVALUE;
        goto L35; // [1410] 1429
    }
    DeRef(_14690);
    _14690 = NOVALUE;

    /** 					return {SLICE, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 513;
    ((int *)_2)[2] = 0;
    _14692 = MAKE_SEQ(_1);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    _14626 = NOVALUE;
    DeRef(_14636);
    _14636 = NOVALUE;
    _14637 = NOVALUE;
    _14652 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    return _14692;
    goto L36; // [1426] 1434
L35: 

    /** 					ungetch()*/
    _60ungetch();
L36: 
L34: 

    /** 			yytext = {ch}*/
    _0 = _yytext_25642;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _ch_25636;
    _yytext_25642 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 			is_int = (ch != '.')*/
    _is_int_25647 = (_ch_25636 != 46);

    /** 			basetype = -1 -- default is decimal*/
    _basetype_25942 = -1;

    /** 			while 1 with entry do*/
    goto L37; // [1454] 1645
L38: 

    /** 				if char_class[ch] = DIGIT then*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _14695 = (int)*(((s1_ptr)_2)->base + _ch_25636);
    if (_14695 != -7)
    goto L39; // [1467] 1480

    /** 					yytext &= ch*/
    Append(&_yytext_25642, _yytext_25642, _ch_25636);
    goto L3A; // [1477] 1642
L39: 

    /** 				elsif equal(yytext, "0") then*/
    if (_yytext_25642 == _14349)
    _14698 = 1;
    else if (IS_ATOM_INT(_yytext_25642) && IS_ATOM_INT(_14349))
    _14698 = 0;
    else
    _14698 = (compare(_yytext_25642, _14349) == 0);
    if (_14698 == 0)
    {
        _14698 = NOVALUE;
        goto L3B; // [1486] 1581
    }
    else{
        _14698 = NOVALUE;
    }

    /** 					basetype = find(ch, nbasecode)*/
    _basetype_25942 = find_from(_ch_25636, _60nbasecode_25444, 1);

    /** 					if basetype > length(nbase) then*/
    if (IS_SEQUENCE(_60nbase_25443)){
            _14700 = SEQ_PTR(_60nbase_25443)->length;
    }
    else {
        _14700 = 1;
    }
    if (_basetype_25942 <= _14700)
    goto L3C; // [1501] 1515

    /** 						basetype -= length(nbase)*/
    if (IS_SEQUENCE(_60nbase_25443)){
            _14702 = SEQ_PTR(_60nbase_25443)->length;
    }
    else {
        _14702 = 1;
    }
    _basetype_25942 = _basetype_25942 - _14702;
    _14702 = NOVALUE;
L3C: 

    /** 					if basetype = 0 then*/
    if (_basetype_25942 != 0)
    goto L3D; // [1517] 1572

    /** 						if char_class[ch] = LETTER then*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _14705 = (int)*(((s1_ptr)_2)->base + _ch_25636);
    if (_14705 != -2)
    goto L3E; // [1531] 1562

    /** 							if ch != 'e' and ch != 'E' then*/
    _14707 = (_ch_25636 != 101);
    if (_14707 == 0) {
        goto L3F; // [1541] 1561
    }
    _14709 = (_ch_25636 != 69);
    if (_14709 == 0)
    {
        DeRef(_14709);
        _14709 = NOVALUE;
        goto L3F; // [1550] 1561
    }
    else{
        DeRef(_14709);
        _14709 = NOVALUE;
    }

    /** 								CompileErr(105, ch)*/
    _43CompileErr(105, _ch_25636, 0);
L3F: 
L3E: 

    /** 						basetype = -1 -- decimal*/
    _basetype_25942 = -1;

    /** 						exit*/
    goto L40; // [1569] 1657
L3D: 

    /** 					yytext &= '0'*/
    Append(&_yytext_25642, _yytext_25642, 48);
    goto L3A; // [1578] 1642
L3B: 

    /** 				elsif basetype = 4 then -- hexadecimal*/
    if (_basetype_25942 != 4)
    goto L40; // [1583] 1657

    /** 					integer hdigit*/

    /** 					hdigit = find(ch, "ABCDEFabcdef")*/
    _hdigit_25982 = find_from(_ch_25636, _14712, 1);

    /** 					if hdigit = 0 then*/
    if (_hdigit_25982 != 0)
    goto L41; // [1598] 1609

    /** 						exit*/
    goto L40; // [1606] 1657
L41: 

    /** 					if hdigit > 6 then*/
    if (_hdigit_25982 <= 6)
    goto L42; // [1611] 1622

    /** 						hdigit -= 6*/
    _hdigit_25982 = _hdigit_25982 - 6;
L42: 

    /** 					yytext &= hexasc[hdigit]*/
    _2 = (int)SEQ_PTR(_60hexasc_25446);
    _14717 = (int)*(((s1_ptr)_2)->base + _hdigit_25982);
    if (IS_SEQUENCE(_yytext_25642) && IS_ATOM(_14717)) {
        Ref(_14717);
        Append(&_yytext_25642, _yytext_25642, _14717);
    }
    else if (IS_ATOM(_yytext_25642) && IS_SEQUENCE(_14717)) {
    }
    else {
        Concat((object_ptr)&_yytext_25642, _yytext_25642, _14717);
    }
    _14717 = NOVALUE;
    goto L3A; // [1634] 1642

    /** 					exit*/
    goto L40; // [1639] 1657
L3A: 

    /** 			entry*/
L37: 

    /** 				ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 			end while*/
    goto L38; // [1654] 1457
L40: 

    /** 			if ch = '.' then*/
    if (_ch_25636 != 46)
    goto L43; // [1659] 1794

    /** 				ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 				if ch = '.' then*/
    if (_ch_25636 != 46)
    goto L44; // [1672] 1683

    /** 					ungetch()*/
    _60ungetch();
    goto L45; // [1680] 1793
L44: 

    /** 					is_int = FALSE*/
    _is_int_25647 = _9FALSE_428;

    /** 					if yytext[1] = '.' then*/
    _2 = (int)SEQ_PTR(_yytext_25642);
    _14723 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14723, 46)){
        _14723 = NOVALUE;
        goto L46; // [1698] 1712
    }
    _14723 = NOVALUE;

    /** 						CompileErr(124)*/
    RefDS(_22037);
    _43CompileErr(124, _22037, 0);
    goto L47; // [1709] 1719
L46: 

    /** 						yytext &= '.'*/
    Append(&_yytext_25642, _yytext_25642, 46);
L47: 

    /** 					if char_class[ch] = DIGIT then*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _14726 = (int)*(((s1_ptr)_2)->base + _ch_25636);
    if (_14726 != -7)
    goto L48; // [1729] 1784

    /** 						yytext &= ch*/
    Append(&_yytext_25642, _yytext_25642, _ch_25636);

    /** 						ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 						while char_class[ch] = DIGIT do*/
L49: 
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _14730 = (int)*(((s1_ptr)_2)->base + _ch_25636);
    if (_14730 != -7)
    goto L4A; // [1759] 1792

    /** 							yytext &= ch*/
    Append(&_yytext_25642, _yytext_25642, _ch_25636);

    /** 							ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 						end while*/
    goto L49; // [1778] 1751
    goto L4A; // [1781] 1792
L48: 

    /** 						CompileErr(94)*/
    RefDS(_22037);
    _43CompileErr(94, _22037, 0);
L4A: 
L45: 
L43: 

    /** 			if basetype = -1 and find(ch, "eE") then*/
    _14734 = (_basetype_25942 == -1);
    if (_14734 == 0) {
        goto L4B; // [1800] 1936
    }
    _14737 = find_from(_ch_25636, _14736, 1);
    if (_14737 == 0)
    {
        _14737 = NOVALUE;
        goto L4B; // [1810] 1936
    }
    else{
        _14737 = NOVALUE;
    }

    /** 				is_int = FALSE*/
    _is_int_25647 = _9FALSE_428;

    /** 				yytext &= ch*/
    Append(&_yytext_25642, _yytext_25642, _ch_25636);

    /** 				ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 				if ch = '-' or ch = '+' or char_class[ch] = DIGIT then*/
    _14740 = (_ch_25636 == 45);
    if (_14740 != 0) {
        _14741 = 1;
        goto L4C; // [1841] 1853
    }
    _14742 = (_ch_25636 == 43);
    _14741 = (_14742 != 0);
L4C: 
    if (_14741 != 0) {
        goto L4D; // [1853] 1874
    }
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _14744 = (int)*(((s1_ptr)_2)->base + _ch_25636);
    _14745 = (_14744 == -7);
    _14744 = NOVALUE;
    if (_14745 == 0)
    {
        DeRef(_14745);
        _14745 = NOVALUE;
        goto L4E; // [1870] 1883
    }
    else{
        DeRef(_14745);
        _14745 = NOVALUE;
    }
L4D: 

    /** 					yytext &= ch*/
    Append(&_yytext_25642, _yytext_25642, _ch_25636);
    goto L4F; // [1880] 1891
L4E: 

    /** 					CompileErr(86)*/
    RefDS(_22037);
    _43CompileErr(86, _22037, 0);
L4F: 

    /** 				ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 				while char_class[ch] = DIGIT do*/
L50: 
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _14748 = (int)*(((s1_ptr)_2)->base + _ch_25636);
    if (_14748 != -7)
    goto L51; // [1911] 1967

    /** 					yytext &= ch*/
    Append(&_yytext_25642, _yytext_25642, _ch_25636);

    /** 					ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 				end while*/
    goto L50; // [1930] 1903
    goto L51; // [1933] 1967
L4B: 

    /** 			elsif char_class[ch] = LETTER then*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _14752 = (int)*(((s1_ptr)_2)->base + _ch_25636);
    if (_14752 != -2)
    goto L52; // [1946] 1966

    /** 				CompileErr(127, {{ch}})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _ch_25636;
    _14754 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _14754;
    _14755 = MAKE_SEQ(_1);
    _14754 = NOVALUE;
    _43CompileErr(127, _14755, 0);
    _14755 = NOVALUE;
L52: 
L51: 

    /** 			ungetch()*/
    _60ungetch();

    /** 			while i != 0 with entry do*/
    goto L53; // [1973] 2012
L54: 
    if (_i_25637 == 0)
    goto L55; // [1978] 2024

    /** 			    yytext = yytext[1 .. i-1] & yytext[i+1 .. $]*/
    _14757 = _i_25637 - 1;
    rhs_slice_target = (object_ptr)&_14758;
    RHS_Slice(_yytext_25642, 1, _14757);
    _14759 = _i_25637 + 1;
    if (_14759 > MAXINT){
        _14759 = NewDouble((double)_14759);
    }
    if (IS_SEQUENCE(_yytext_25642)){
            _14760 = SEQ_PTR(_yytext_25642)->length;
    }
    else {
        _14760 = 1;
    }
    rhs_slice_target = (object_ptr)&_14761;
    RHS_Slice(_yytext_25642, _14759, _14760);
    Concat((object_ptr)&_yytext_25642, _14758, _14761);
    DeRefDS(_14758);
    _14758 = NOVALUE;
    DeRef(_14758);
    _14758 = NOVALUE;
    DeRefDS(_14761);
    _14761 = NOVALUE;

    /** 			  entry*/
L53: 

    /** 			    i = find('_', yytext)*/
    _i_25637 = find_from(95, _yytext_25642, 1);

    /** 			end while*/
    goto L54; // [2021] 1976
L55: 

    /** 			if is_int then*/
    if (_is_int_25647 == 0)
    {
        goto L56; // [2026] 2097
    }
    else{
    }

    /** 				if basetype = -1 then*/
    if (_basetype_25942 != -1)
    goto L57; // [2031] 2041

    /** 					basetype = 3 -- decimal*/
    _basetype_25942 = 3;
L57: 

    /** 				d = MakeInt(yytext, nbase[basetype])*/
    _2 = (int)SEQ_PTR(_60nbase_25443);
    _14765 = (int)*(((s1_ptr)_2)->base + _basetype_25942);
    RefDS(_yytext_25642);
    Ref(_14765);
    _0 = _d_25644;
    _d_25644 = _60MakeInt(_yytext_25642, _14765);
    DeRef(_0);
    _14765 = NOVALUE;

    /** 				if integer(d) then*/
    if (IS_ATOM_INT(_d_25644))
    _14767 = 1;
    else if (IS_ATOM_DBL(_d_25644))
    _14767 = IS_ATOM_INT(DoubleToInt(_d_25644));
    else
    _14767 = 0;
    if (_14767 == 0)
    {
        _14767 = NOVALUE;
        goto L58; // [2057] 2079
    }
    else{
        _14767 = NOVALUE;
    }

    /** 					return {ATOM, NewIntSym(d)}*/
    Ref(_d_25644);
    _14768 = _52NewIntSym(_d_25644);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14768;
    _14769 = MAKE_SEQ(_1);
    _14768 = NOVALUE;
    DeRefDS(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    return _14769;
    goto L59; // [2076] 2096
L58: 

    /** 					return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_25644);
    _14770 = _52NewDoubleSym(_d_25644);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14770;
    _14771 = MAKE_SEQ(_1);
    _14770 = NOVALUE;
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    return _14771;
L59: 
L56: 

    /** 			if basetype != -1 then*/
    if (_basetype_25942 == -1)
    goto L5A; // [2099] 2115

    /** 				CompileErr(125, nbasecode[basetype])*/
    _2 = (int)SEQ_PTR(_60nbasecode_25444);
    _14773 = (int)*(((s1_ptr)_2)->base + _basetype_25942);
    Ref(_14773);
    _43CompileErr(125, _14773, 0);
    _14773 = NOVALUE;
L5A: 

    /** 			d = my_sscanf(yytext)*/
    RefDS(_yytext_25642);
    _0 = _d_25644;
    _d_25644 = _60my_sscanf(_yytext_25642);
    DeRef(_0);

    /** 			if sequence(d) then*/
    _14775 = IS_SEQUENCE(_d_25644);
    if (_14775 == 0)
    {
        _14775 = NOVALUE;
        goto L5B; // [2126] 2139
    }
    else{
        _14775 = NOVALUE;
    }

    /** 				CompileErr(121)*/
    RefDS(_22037);
    _43CompileErr(121, _22037, 0);
    goto L5C; // [2136] 2191
L5B: 

    /** 			elsif is_int and d <= MAXINT_DBL then*/
    if (_is_int_25647 == 0) {
        goto L5D; // [2141] 2174
    }
    if (IS_ATOM_INT(_d_25644)) {
        _14777 = (_d_25644 <= 1073741823);
    }
    else {
        _14777 = binary_op(LESSEQ, _d_25644, 1073741823);
    }
    if (_14777 == 0) {
        DeRef(_14777);
        _14777 = NOVALUE;
        goto L5D; // [2152] 2174
    }
    else {
        if (!IS_ATOM_INT(_14777) && DBL_PTR(_14777)->dbl == 0.0){
            DeRef(_14777);
            _14777 = NOVALUE;
            goto L5D; // [2152] 2174
        }
        DeRef(_14777);
        _14777 = NOVALUE;
    }
    DeRef(_14777);
    _14777 = NOVALUE;

    /** 				return {ATOM, NewIntSym(d)}  -- 1 to 1.07 billion*/
    Ref(_d_25644);
    _14778 = _52NewIntSym(_d_25644);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14778;
    _14779 = MAKE_SEQ(_1);
    _14778 = NOVALUE;
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    return _14779;
    goto L5C; // [2171] 2191
L5D: 

    /** 				return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_25644);
    _14780 = _52NewDoubleSym(_d_25644);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14780;
    _14781 = MAKE_SEQ(_1);
    _14780 = NOVALUE;
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    return _14781;
L5C: 
    goto L1; // [2193] 10
L33: 

    /** 		elsif class = MINUS then*/
    if (_class_25648 != 10)
    goto L5E; // [2200] 2286

    /** 			ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 			if ch = '-' then*/
    if (_ch_25636 != 45)
    goto L5F; // [2213] 2239

    /** 				if start_include then*/
    if (_60start_include_23937 == 0)
    {
        goto L60; // [2221] 2231
    }
    else{
    }

    /** 					IncludePush()*/
    _60IncludePush();
    goto L1; // [2228] 10
L60: 

    /** 					read_line()*/
    _60read_line();
    goto L1; // [2236] 10
L5F: 

    /** 			elsif ch = '=' then*/
    if (_ch_25636 != 61)
    goto L61; // [2241] 2260

    /** 				return {MINUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 516;
    ((int *)_2)[2] = 0;
    _14786 = MAKE_SEQ(_1);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    return _14786;
    goto L1; // [2257] 10
L61: 

    /** 				bp -= 1*/
    _43bp_48561 = _43bp_48561 - 1;

    /** 				return {MINUS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 10;
    ((int *)_2)[2] = 0;
    _14788 = MAKE_SEQ(_1);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    return _14788;
    goto L1; // [2283] 10
L5E: 

    /** 		elsif class = DOUBLE_QUOTE then*/
    if (_class_25648 != -4)
    goto L62; // [2290] 2484

    /** 			integer fch*/

    /** 			ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 			if ch = '"' then*/
    if (_ch_25636 != 34)
    goto L63; // [2305] 2341

    /** 				fch = getch()*/
    _fch_26120 = _60getch();
    if (!IS_ATOM_INT(_fch_26120)) {
        _1 = (long)(DBL_PTR(_fch_26120)->dbl);
        DeRefDS(_fch_26120);
        _fch_26120 = _1;
    }

    /** 				if fch = '"' then*/
    if (_fch_26120 != 34)
    goto L64; // [2318] 2335

    /** 					return ExtendedString( fch )*/
    _14794 = _60ExtendedString(_fch_26120);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    return _14794;
    goto L65; // [2332] 2340
L64: 

    /** 					ungetch()*/
    _60ungetch();
L65: 
L63: 

    /** 			yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_25642);
    _yytext_25642 = _5;

    /** 			while ch != '\n' and ch != '\r' do -- can't be EOF*/
L66: 
    _14795 = (_ch_25636 != 10);
    if (_14795 == 0) {
        goto L67; // [2357] 2436
    }
    _14797 = (_ch_25636 != 13);
    if (_14797 == 0)
    {
        DeRef(_14797);
        _14797 = NOVALUE;
        goto L67; // [2366] 2436
    }
    else{
        DeRef(_14797);
        _14797 = NOVALUE;
    }

    /** 				if ch = '"' then*/
    if (_ch_25636 != 34)
    goto L68; // [2371] 2382

    /** 					exit*/
    goto L67; // [2377] 2436
    goto L69; // [2379] 2424
L68: 

    /** 				elsif ch = '\\' then*/
    if (_ch_25636 != 92)
    goto L6A; // [2384] 2401

    /** 					yytext &= EscapeChar('"')*/
    _14800 = _60EscapeChar(34);
    if (IS_SEQUENCE(_yytext_25642) && IS_ATOM(_14800)) {
        Ref(_14800);
        Append(&_yytext_25642, _yytext_25642, _14800);
    }
    else if (IS_ATOM(_yytext_25642) && IS_SEQUENCE(_14800)) {
    }
    else {
        Concat((object_ptr)&_yytext_25642, _yytext_25642, _14800);
    }
    DeRef(_14800);
    _14800 = NOVALUE;
    goto L69; // [2398] 2424
L6A: 

    /** 				elsif ch = '\t' then*/
    if (_ch_25636 != 9)
    goto L6B; // [2403] 2417

    /** 					CompileErr(145)*/
    RefDS(_22037);
    _43CompileErr(145, _22037, 0);
    goto L69; // [2414] 2424
L6B: 

    /** 					yytext &= ch*/
    Append(&_yytext_25642, _yytext_25642, _ch_25636);
L69: 

    /** 				ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 			end while*/
    goto L66; // [2433] 2353
L67: 

    /** 			if ch = '\n' or ch = '\r' then*/
    _14805 = (_ch_25636 == 10);
    if (_14805 != 0) {
        goto L6C; // [2442] 2455
    }
    _14807 = (_ch_25636 == 13);
    if (_14807 == 0)
    {
        DeRef(_14807);
        _14807 = NOVALUE;
        goto L6D; // [2451] 2463
    }
    else{
        DeRef(_14807);
        _14807 = NOVALUE;
    }
L6C: 

    /** 				CompileErr(67)*/
    RefDS(_22037);
    _43CompileErr(67, _22037, 0);
L6D: 

    /** 			return {STRING, NewStringSym(yytext)}*/
    RefDS(_yytext_25642);
    _14808 = _52NewStringSym(_yytext_25642);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 503;
    ((int *)_2)[2] = _14808;
    _14809 = MAKE_SEQ(_1);
    _14808 = NOVALUE;
    DeRefDS(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14809;
    goto L1; // [2481] 10
L62: 

    /** 		elsif class = PLUS then*/
    if (_class_25648 != 11)
    goto L6E; // [2488] 2540

    /** 			ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 			if ch = '=' then*/
    if (_ch_25636 != 61)
    goto L6F; // [2501] 2520

    /** 				return {PLUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 515;
    ((int *)_2)[2] = 0;
    _14813 = MAKE_SEQ(_1);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14813;
    goto L1; // [2517] 10
L6F: 

    /** 				ungetch()*/
    _60ungetch();

    /** 				return {PLUS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 11;
    ((int *)_2)[2] = 0;
    _14814 = MAKE_SEQ(_1);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14814;
    goto L1; // [2537] 10
L6E: 

    /** 		elsif class = res:CONCAT then*/
    if (_class_25648 != 15)
    goto L70; // [2542] 2592

    /** 			ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 			if ch = '=' then*/
    if (_ch_25636 != 61)
    goto L71; // [2555] 2574

    /** 				return {CONCAT_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 519;
    ((int *)_2)[2] = 0;
    _14818 = MAKE_SEQ(_1);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14818;
    goto L1; // [2571] 10
L71: 

    /** 				ungetch()*/
    _60ungetch();

    /** 				return {res:CONCAT, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 15;
    ((int *)_2)[2] = 0;
    _14819 = MAKE_SEQ(_1);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    DeRef(_14818);
    _14818 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14819;
    goto L1; // [2589] 10
L70: 

    /** 		elsif class = NUMBER_SIGN then*/
    if (_class_25648 != -11)
    goto L72; // [2596] 3114

    /** 			i = 0*/
    _i_25637 = 0;

    /** 			is_int = -1*/
    _is_int_25647 = -1;

    /** 			while i < MAXINT/32 do*/
L73: 
    _14821 = (1073741823 % 32) ? NewDouble((double)1073741823 / 32) : (1073741823 / 32);
    if (binary_op_a(GREATEREQ, _i_25637, _14821)){
        DeRef(_14821);
        _14821 = NOVALUE;
        goto L74; // [2621] 2791
    }
    DeRef(_14821);
    _14821 = NOVALUE;

    /** 				ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 				if char_class[ch] = DIGIT then*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _14824 = (int)*(((s1_ptr)_2)->base + _ch_25636);
    if (_14824 != -7)
    goto L75; // [2642] 2681

    /** 					if ch != '_' then*/
    if (_ch_25636 == 95)
    goto L73; // [2648] 2615

    /** 						i = i * 16 + ch - '0'*/
    if (_i_25637 == (short)_i_25637)
    _14827 = _i_25637 * 16;
    else
    _14827 = NewDouble(_i_25637 * (double)16);
    if (IS_ATOM_INT(_14827)) {
        _14828 = _14827 + _ch_25636;
        if ((long)((unsigned long)_14828 + (unsigned long)HIGH_BITS) >= 0) 
        _14828 = NewDouble((double)_14828);
    }
    else {
        _14828 = NewDouble(DBL_PTR(_14827)->dbl + (double)_ch_25636);
    }
    DeRef(_14827);
    _14827 = NOVALUE;
    if (IS_ATOM_INT(_14828)) {
        _i_25637 = _14828 - 48;
    }
    else {
        _i_25637 = NewDouble(DBL_PTR(_14828)->dbl - (double)48);
    }
    DeRef(_14828);
    _14828 = NOVALUE;
    if (!IS_ATOM_INT(_i_25637)) {
        _1 = (long)(DBL_PTR(_i_25637)->dbl);
        DeRefDS(_i_25637);
        _i_25637 = _1;
    }

    /** 						is_int = TRUE*/
    _is_int_25647 = _9TRUE_430;
    goto L73; // [2678] 2615
L75: 

    /** 				elsif ch >= 'A' and ch <= 'F' then*/
    _14830 = (_ch_25636 >= 65);
    if (_14830 == 0) {
        goto L76; // [2687] 2731
    }
    _14832 = (_ch_25636 <= 70);
    if (_14832 == 0)
    {
        DeRef(_14832);
        _14832 = NOVALUE;
        goto L76; // [2696] 2731
    }
    else{
        DeRef(_14832);
        _14832 = NOVALUE;
    }

    /** 					i = (i * 16) + ch - ('A'-10)*/
    if (_i_25637 == (short)_i_25637)
    _14833 = _i_25637 * 16;
    else
    _14833 = NewDouble(_i_25637 * (double)16);
    if (IS_ATOM_INT(_14833)) {
        _14834 = _14833 + _ch_25636;
        if ((long)((unsigned long)_14834 + (unsigned long)HIGH_BITS) >= 0) 
        _14834 = NewDouble((double)_14834);
    }
    else {
        _14834 = NewDouble(DBL_PTR(_14833)->dbl + (double)_ch_25636);
    }
    DeRef(_14833);
    _14833 = NOVALUE;
    _14835 = 55;
    if (IS_ATOM_INT(_14834)) {
        _i_25637 = _14834 - 55;
    }
    else {
        _i_25637 = NewDouble(DBL_PTR(_14834)->dbl - (double)55);
    }
    DeRef(_14834);
    _14834 = NOVALUE;
    _14835 = NOVALUE;
    if (!IS_ATOM_INT(_i_25637)) {
        _1 = (long)(DBL_PTR(_i_25637)->dbl);
        DeRefDS(_i_25637);
        _i_25637 = _1;
    }

    /** 					is_int = TRUE*/
    _is_int_25647 = _9TRUE_430;
    goto L73; // [2728] 2615
L76: 

    /** 				elsif ch >= 'a' and ch <= 'f' then*/
    _14837 = (_ch_25636 >= 97);
    if (_14837 == 0) {
        goto L74; // [2737] 2791
    }
    _14839 = (_ch_25636 <= 102);
    if (_14839 == 0)
    {
        DeRef(_14839);
        _14839 = NOVALUE;
        goto L74; // [2746] 2791
    }
    else{
        DeRef(_14839);
        _14839 = NOVALUE;
    }

    /** 					i = (i * 16) + ch - ('a'-10)*/
    if (_i_25637 == (short)_i_25637)
    _14840 = _i_25637 * 16;
    else
    _14840 = NewDouble(_i_25637 * (double)16);
    if (IS_ATOM_INT(_14840)) {
        _14841 = _14840 + _ch_25636;
        if ((long)((unsigned long)_14841 + (unsigned long)HIGH_BITS) >= 0) 
        _14841 = NewDouble((double)_14841);
    }
    else {
        _14841 = NewDouble(DBL_PTR(_14840)->dbl + (double)_ch_25636);
    }
    DeRef(_14840);
    _14840 = NOVALUE;
    _14842 = 87;
    if (IS_ATOM_INT(_14841)) {
        _i_25637 = _14841 - 87;
    }
    else {
        _i_25637 = NewDouble(DBL_PTR(_14841)->dbl - (double)87);
    }
    DeRef(_14841);
    _14841 = NOVALUE;
    _14842 = NOVALUE;
    if (!IS_ATOM_INT(_i_25637)) {
        _1 = (long)(DBL_PTR(_i_25637)->dbl);
        DeRefDS(_i_25637);
        _i_25637 = _1;
    }

    /** 					is_int = TRUE*/
    _is_int_25647 = _9TRUE_430;
    goto L73; // [2778] 2615

    /** 					exit*/
    goto L74; // [2783] 2791

    /** 			end while*/
    goto L73; // [2788] 2615
L74: 

    /** 			if is_int = -1 then*/
    if (_is_int_25647 != -1)
    goto L77; // [2793] 2856

    /** 				if ch = '!' then*/
    if (_ch_25636 != 33)
    goto L78; // [2799] 2845

    /** 					if line_number > 1 then*/
    if (_26line_number_11983 <= 1)
    goto L79; // [2807] 2819

    /** 						CompileErr(161)*/
    RefDS(_22037);
    _43CompileErr(161, _22037, 0);
L79: 

    /** 					shebang = ThisLine*/
    Ref(_43ThisLine_48557);
    DeRef(_60shebang_23942);
    _60shebang_23942 = _43ThisLine_48557;

    /** 					if start_include then*/
    if (_60start_include_23937 == 0)
    {
        goto L7A; // [2830] 2838
    }
    else{
    }

    /** 						IncludePush()*/
    _60IncludePush();
L7A: 

    /** 					read_line()*/
    _60read_line();
    goto L1; // [2842] 10
L78: 

    /** 					CompileErr(97)*/
    RefDS(_22037);
    _43CompileErr(97, _22037, 0);
    goto L1; // [2853] 10
L77: 

    /** 				if i >= MAXINT/32 then*/
    _14847 = (1073741823 % 32) ? NewDouble((double)1073741823 / 32) : (1073741823 / 32);
    if (binary_op_a(LESS, _i_25637, _14847)){
        DeRef(_14847);
        _14847 = NOVALUE;
        goto L7B; // [2864] 3035
    }
    DeRef(_14847);
    _14847 = NOVALUE;

    /** 					d = i*/
    DeRef(_d_25644);
    _d_25644 = _i_25637;

    /** 					is_int = FALSE*/
    _is_int_25647 = _9FALSE_428;

    /** 					while TRUE do*/
L7C: 
    if (_9TRUE_430 == 0)
    {
        goto L7D; // [2889] 3034
    }
    else{
    }

    /** 						ch = getch()  -- eventually END_OF_FILE_CHAR or new-line*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 						if char_class[ch] = DIGIT then*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _14850 = (int)*(((s1_ptr)_2)->base + _ch_25636);
    if (_14850 != -7)
    goto L7E; // [2909] 2937

    /** 							if ch != '_' then*/
    if (_ch_25636 == 95)
    goto L7C; // [2915] 2887

    /** 								d = (d * 16) + ch - '0'*/
    if (IS_ATOM_INT(_d_25644)) {
        if (_d_25644 == (short)_d_25644)
        _14853 = _d_25644 * 16;
        else
        _14853 = NewDouble(_d_25644 * (double)16);
    }
    else {
        _14853 = binary_op(MULTIPLY, _d_25644, 16);
    }
    if (IS_ATOM_INT(_14853)) {
        _14854 = _14853 + _ch_25636;
        if ((long)((unsigned long)_14854 + (unsigned long)HIGH_BITS) >= 0) 
        _14854 = NewDouble((double)_14854);
    }
    else {
        _14854 = binary_op(PLUS, _14853, _ch_25636);
    }
    DeRef(_14853);
    _14853 = NOVALUE;
    DeRef(_d_25644);
    if (IS_ATOM_INT(_14854)) {
        _d_25644 = _14854 - 48;
        if ((long)((unsigned long)_d_25644 +(unsigned long) HIGH_BITS) >= 0){
            _d_25644 = NewDouble((double)_d_25644);
        }
    }
    else {
        _d_25644 = binary_op(MINUS, _14854, 48);
    }
    DeRef(_14854);
    _14854 = NOVALUE;
    goto L7C; // [2934] 2887
L7E: 

    /** 						elsif ch >= 'A' and ch <= 'F' then*/
    _14856 = (_ch_25636 >= 65);
    if (_14856 == 0) {
        goto L7F; // [2943] 2976
    }
    _14858 = (_ch_25636 <= 70);
    if (_14858 == 0)
    {
        DeRef(_14858);
        _14858 = NOVALUE;
        goto L7F; // [2952] 2976
    }
    else{
        DeRef(_14858);
        _14858 = NOVALUE;
    }

    /** 							d = (d * 16) + ch - ('A'- 10)*/
    if (IS_ATOM_INT(_d_25644)) {
        if (_d_25644 == (short)_d_25644)
        _14859 = _d_25644 * 16;
        else
        _14859 = NewDouble(_d_25644 * (double)16);
    }
    else {
        _14859 = binary_op(MULTIPLY, _d_25644, 16);
    }
    if (IS_ATOM_INT(_14859)) {
        _14860 = _14859 + _ch_25636;
        if ((long)((unsigned long)_14860 + (unsigned long)HIGH_BITS) >= 0) 
        _14860 = NewDouble((double)_14860);
    }
    else {
        _14860 = binary_op(PLUS, _14859, _ch_25636);
    }
    DeRef(_14859);
    _14859 = NOVALUE;
    _14861 = 55;
    DeRef(_d_25644);
    if (IS_ATOM_INT(_14860)) {
        _d_25644 = _14860 - 55;
        if ((long)((unsigned long)_d_25644 +(unsigned long) HIGH_BITS) >= 0){
            _d_25644 = NewDouble((double)_d_25644);
        }
    }
    else {
        _d_25644 = binary_op(MINUS, _14860, 55);
    }
    DeRef(_14860);
    _14860 = NOVALUE;
    _14861 = NOVALUE;
    goto L7C; // [2973] 2887
L7F: 

    /** 						elsif ch >= 'a' and ch <= 'f' then*/
    _14863 = (_ch_25636 >= 97);
    if (_14863 == 0) {
        goto L80; // [2982] 3015
    }
    _14865 = (_ch_25636 <= 102);
    if (_14865 == 0)
    {
        DeRef(_14865);
        _14865 = NOVALUE;
        goto L80; // [2991] 3015
    }
    else{
        DeRef(_14865);
        _14865 = NOVALUE;
    }

    /** 							d = (d * 16) + ch - ('a'-10)*/
    if (IS_ATOM_INT(_d_25644)) {
        if (_d_25644 == (short)_d_25644)
        _14866 = _d_25644 * 16;
        else
        _14866 = NewDouble(_d_25644 * (double)16);
    }
    else {
        _14866 = binary_op(MULTIPLY, _d_25644, 16);
    }
    if (IS_ATOM_INT(_14866)) {
        _14867 = _14866 + _ch_25636;
        if ((long)((unsigned long)_14867 + (unsigned long)HIGH_BITS) >= 0) 
        _14867 = NewDouble((double)_14867);
    }
    else {
        _14867 = binary_op(PLUS, _14866, _ch_25636);
    }
    DeRef(_14866);
    _14866 = NOVALUE;
    _14868 = 87;
    DeRef(_d_25644);
    if (IS_ATOM_INT(_14867)) {
        _d_25644 = _14867 - 87;
        if ((long)((unsigned long)_d_25644 +(unsigned long) HIGH_BITS) >= 0){
            _d_25644 = NewDouble((double)_d_25644);
        }
    }
    else {
        _d_25644 = binary_op(MINUS, _14867, 87);
    }
    DeRef(_14867);
    _14867 = NOVALUE;
    _14868 = NOVALUE;
    goto L7C; // [3012] 2887
L80: 

    /** 						elsif ch = '_' then*/
    if (_ch_25636 != 95)
    goto L7D; // [3017] 3034
    goto L7C; // [3021] 2887

    /** 							exit*/
    goto L7D; // [3026] 3034

    /** 					end while*/
    goto L7C; // [3031] 2887
L7D: 
L7B: 

    /** 				ungetch()*/
    _60ungetch();

    /** 				if is_int then*/
    if (_is_int_25647 == 0)
    {
        goto L81; // [3041] 3063
    }
    else{
    }

    /** 					return {ATOM, NewIntSym(i)}*/
    _14871 = _52NewIntSym(_i_25637);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14871;
    _14872 = MAKE_SEQ(_1);
    _14871 = NOVALUE;
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    DeRef(_14818);
    _14818 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    _14824 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14819);
    _14819 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    DeRef(_14830);
    _14830 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14850 = NOVALUE;
    DeRef(_14856);
    _14856 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14837);
    _14837 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14872;
    goto L1; // [3060] 10
L81: 

    /** 					if d <= MAXINT_DBL then            -- d is always >= 0*/
    if (binary_op_a(GREATER, _d_25644, 1073741823)){
        goto L82; // [3069] 3092
    }

    /** 						return {ATOM, NewIntSym(d)}*/
    Ref(_d_25644);
    _14874 = _52NewIntSym(_d_25644);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14874;
    _14875 = MAKE_SEQ(_1);
    _14874 = NOVALUE;
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14872);
    _14872 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    DeRef(_14818);
    _14818 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    _14824 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14819);
    _14819 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    DeRef(_14830);
    _14830 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14850 = NOVALUE;
    DeRef(_14856);
    _14856 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14837);
    _14837 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14875;
    goto L1; // [3089] 10
L82: 

    /** 						return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_25644);
    _14876 = _52NewDoubleSym(_d_25644);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14876;
    _14877 = MAKE_SEQ(_1);
    _14876 = NOVALUE;
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14872);
    _14872 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    DeRef(_14818);
    _14818 = NOVALUE;
    DeRef(_14875);
    _14875 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    _14824 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14819);
    _14819 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    DeRef(_14830);
    _14830 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14850 = NOVALUE;
    DeRef(_14856);
    _14856 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14837);
    _14837 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14877;
    goto L1; // [3111] 10
L72: 

    /** 		elsif class = res:MULTIPLY then*/
    if (_class_25648 != 13)
    goto L83; // [3116] 3166

    /** 			ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 			if ch = '=' then*/
    if (_ch_25636 != 61)
    goto L84; // [3129] 3148

    /** 				return {MULTIPLY_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 517;
    ((int *)_2)[2] = 0;
    _14881 = MAKE_SEQ(_1);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14872);
    _14872 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    DeRef(_14818);
    _14818 = NOVALUE;
    DeRef(_14875);
    _14875 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    _14824 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14877);
    _14877 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14819);
    _14819 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    DeRef(_14830);
    _14830 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14850 = NOVALUE;
    DeRef(_14856);
    _14856 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14837);
    _14837 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14881;
    goto L1; // [3145] 10
L84: 

    /** 				ungetch()*/
    _60ungetch();

    /** 				return {res:MULTIPLY, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 13;
    ((int *)_2)[2] = 0;
    _14882 = MAKE_SEQ(_1);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14872);
    _14872 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    DeRef(_14818);
    _14818 = NOVALUE;
    DeRef(_14875);
    _14875 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    _14824 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14877);
    _14877 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14819);
    _14819 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    DeRef(_14830);
    _14830 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14881);
    _14881 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14850 = NOVALUE;
    DeRef(_14856);
    _14856 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14837);
    _14837 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14882;
    goto L1; // [3163] 10
L83: 

    /** 		elsif class = res:DIVIDE then*/
    if (_class_25648 != 14)
    goto L85; // [3168] 3370

    /** 			ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 			if ch = '=' then*/
    if (_ch_25636 != 61)
    goto L86; // [3181] 3200

    /** 				return {DIVIDE_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 518;
    ((int *)_2)[2] = 0;
    _14886 = MAKE_SEQ(_1);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14872);
    _14872 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    DeRef(_14818);
    _14818 = NOVALUE;
    DeRef(_14875);
    _14875 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    _14824 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14877);
    _14877 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14819);
    _14819 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14882);
    _14882 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    DeRef(_14830);
    _14830 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14881);
    _14881 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14850 = NOVALUE;
    DeRef(_14856);
    _14856 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14837);
    _14837 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14886;
    goto L1; // [3197] 10
L86: 

    /** 			elsif ch = '*' then*/
    if (_ch_25636 != 42)
    goto L87; // [3202] 3352

    /** 				cline = line_number*/
    _cline_25641 = _26line_number_11983;

    /** 				integer cnest = 1*/
    _cnest_26297 = 1;

    /** 				while cnest > 0 do*/
L88: 
    if (_cnest_26297 <= 0)
    goto L89; // [3225] 3333

    /** 					ch = getch()*/
    _ch_25636 = _60getch();
    if (!IS_ATOM_INT(_ch_25636)) {
        _1 = (long)(DBL_PTR(_ch_25636)->dbl);
        DeRefDS(_ch_25636);
        _ch_25636 = _1;
    }

    /** 					switch ch do*/
    _0 = _ch_25636;
    switch ( _0 ){ 

        /** 						case  END_OF_FILE_CHAR then*/
        case 26:

        /** 							exit*/
        goto L89; // [3249] 3333
        goto L88; // [3251] 3225

        /** 						case '\n' then*/
        case 10:

        /** 							read_line()*/
        _60read_line();
        goto L88; // [3261] 3225

        /** 						case '*' then*/
        case 42:

        /** 							ch = getch()*/
        _ch_25636 = _60getch();
        if (!IS_ATOM_INT(_ch_25636)) {
            _1 = (long)(DBL_PTR(_ch_25636)->dbl);
            DeRefDS(_ch_25636);
            _ch_25636 = _1;
        }

        /** 							if ch = '/' then*/
        if (_ch_25636 != 47)
        goto L8A; // [3276] 3289

        /** 								cnest -= 1*/
        _cnest_26297 = _cnest_26297 - 1;
        goto L88; // [3286] 3225
L8A: 

        /** 								ungetch()*/
        _60ungetch();
        goto L88; // [3294] 3225

        /** 						case '/' then*/
        case 47:

        /** 							ch = getch()*/
        _ch_25636 = _60getch();
        if (!IS_ATOM_INT(_ch_25636)) {
            _1 = (long)(DBL_PTR(_ch_25636)->dbl);
            DeRefDS(_ch_25636);
            _ch_25636 = _1;
        }

        /** 							if ch = '*' then*/
        if (_ch_25636 != 42)
        goto L8B; // [3309] 3322

        /** 								cnest += 1*/
        _cnest_26297 = _cnest_26297 + 1;
        goto L8C; // [3319] 3327
L8B: 

        /** 								ungetch()*/
        _60ungetch();
L8C: 
    ;}
    /** 				end while*/
    goto L88; // [3330] 3225
L89: 

    /** 				if cnest > 0 then*/
    if (_cnest_26297 <= 0)
    goto L8D; // [3335] 3347

    /** 					CompileErr(42, cline)*/
    _43CompileErr(42, _cline_25641, 0);
L8D: 
    goto L1; // [3349] 10
L87: 

    /** 				ungetch()*/
    _60ungetch();

    /** 				return {res:DIVIDE, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 14;
    ((int *)_2)[2] = 0;
    _14899 = MAKE_SEQ(_1);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14872);
    _14872 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    DeRef(_14818);
    _14818 = NOVALUE;
    DeRef(_14875);
    _14875 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    _14824 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14877);
    _14877 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14819);
    _14819 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14882);
    _14882 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    DeRef(_14830);
    _14830 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14881);
    _14881 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14886);
    _14886 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14850 = NOVALUE;
    DeRef(_14856);
    _14856 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14837);
    _14837 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14899;
    goto L1; // [3367] 10
L85: 

    /** 		elsif class = SINGLE_QUOTE then*/
    if (_class_25648 != -5)
    goto L8E; // [3374] 3515

    /** 			atom ach = getch()*/
    _0 = _ach_26326;
    _ach_26326 = _60getch();
    DeRef(_0);

    /** 			if ach = '\\' then*/
    if (binary_op_a(NOTEQ, _ach_26326, 92)){
        goto L8F; // [3385] 3398
    }

    /** 				ach = EscapeChar('\'')*/
    _0 = _ach_26326;
    _ach_26326 = _60EscapeChar(39);
    DeRef(_0);
    goto L90; // [3395] 3449
L8F: 

    /** 			elsif ach = '\t' then*/
    if (binary_op_a(NOTEQ, _ach_26326, 9)){
        goto L91; // [3400] 3414
    }

    /** 				CompileErr(145)*/
    RefDS(_22037);
    _43CompileErr(145, _22037, 0);
    goto L90; // [3411] 3449
L91: 

    /** 			elsif ach = '\'' then*/
    if (binary_op_a(NOTEQ, _ach_26326, 39)){
        goto L92; // [3416] 3430
    }

    /** 				CompileErr(137)*/
    RefDS(_22037);
    _43CompileErr(137, _22037, 0);
    goto L90; // [3427] 3449
L92: 

    /** 			elsif ach = '\n' then*/
    if (binary_op_a(NOTEQ, _ach_26326, 10)){
        goto L93; // [3432] 3448
    }

    /** 				CompileErr(68, {"character", "end of line"})*/
    RefDS(_14908);
    RefDS(_14907);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _14907;
    ((int *)_2)[2] = _14908;
    _14909 = MAKE_SEQ(_1);
    _43CompileErr(68, _14909, 0);
    _14909 = NOVALUE;
L93: 
L90: 

    /** 			if getch() != '\'' then*/
    _14910 = _60getch();
    if (binary_op_a(EQUALS, _14910, 39)){
        DeRef(_14910);
        _14910 = NOVALUE;
        goto L94; // [3454] 3466
    }
    DeRef(_14910);
    _14910 = NOVALUE;

    /** 				CompileErr(56)*/
    RefDS(_22037);
    _43CompileErr(56, _22037, 0);
L94: 

    /** 			if integer(ach) then*/
    if (IS_ATOM_INT(_ach_26326))
    _14912 = 1;
    else if (IS_ATOM_DBL(_ach_26326))
    _14912 = IS_ATOM_INT(DoubleToInt(_ach_26326));
    else
    _14912 = 0;
    if (_14912 == 0)
    {
        _14912 = NOVALUE;
        goto L95; // [3471] 3493
    }
    else{
        _14912 = NOVALUE;
    }

    /** 				return {ATOM, NewIntSym(ach)}*/
    Ref(_ach_26326);
    _14913 = _52NewIntSym(_ach_26326);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14913;
    _14914 = MAKE_SEQ(_1);
    _14913 = NOVALUE;
    DeRef(_ach_26326);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14872);
    _14872 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    DeRef(_14818);
    _14818 = NOVALUE;
    DeRef(_14875);
    _14875 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    _14824 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14877);
    _14877 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14819);
    _14819 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14882);
    _14882 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    DeRef(_14830);
    _14830 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14881);
    _14881 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14899);
    _14899 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14886);
    _14886 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14850 = NOVALUE;
    DeRef(_14856);
    _14856 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14837);
    _14837 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14914;
    goto L96; // [3490] 3510
L95: 

    /** 				return {ATOM, NewDoubleSym(ach)}*/
    Ref(_ach_26326);
    _14915 = _52NewDoubleSym(_ach_26326);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14915;
    _14916 = MAKE_SEQ(_1);
    _14915 = NOVALUE;
    DeRef(_ach_26326);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14872);
    _14872 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    DeRef(_14818);
    _14818 = NOVALUE;
    DeRef(_14875);
    _14875 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    _14824 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14877);
    _14877 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14819);
    _14819 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14914);
    _14914 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14882);
    _14882 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    DeRef(_14830);
    _14830 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14881);
    _14881 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14899);
    _14899 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14886);
    _14886 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14850 = NOVALUE;
    DeRef(_14856);
    _14856 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14837);
    _14837 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14916;
L96: 
    DeRef(_ach_26326);
    _ach_26326 = NOVALUE;
    goto L1; // [3512] 10
L8E: 

    /** 		elsif class = LESS then*/
    if (_class_25648 != 1)
    goto L97; // [3519] 3567

    /** 			if getch() = '=' then*/
    _14918 = _60getch();
    if (binary_op_a(NOTEQ, _14918, 61)){
        DeRef(_14918);
        _14918 = NOVALUE;
        goto L98; // [3528] 3547
    }
    DeRef(_14918);
    _14918 = NOVALUE;

    /** 				return {LESSEQ, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 5;
    ((int *)_2)[2] = 0;
    _14920 = MAKE_SEQ(_1);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14872);
    _14872 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    DeRef(_14818);
    _14818 = NOVALUE;
    DeRef(_14875);
    _14875 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    _14824 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14877);
    _14877 = NOVALUE;
    DeRef(_14916);
    _14916 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14819);
    _14819 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14914);
    _14914 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14882);
    _14882 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    DeRef(_14830);
    _14830 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14881);
    _14881 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14899);
    _14899 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14886);
    _14886 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14850 = NOVALUE;
    DeRef(_14856);
    _14856 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14837);
    _14837 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14920;
    goto L1; // [3544] 10
L98: 

    /** 				ungetch()*/
    _60ungetch();

    /** 				return {LESS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _14921 = MAKE_SEQ(_1);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14872);
    _14872 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    DeRef(_14818);
    _14818 = NOVALUE;
    DeRef(_14875);
    _14875 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    _14824 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14877);
    _14877 = NOVALUE;
    DeRef(_14916);
    _14916 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14819);
    _14819 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14914);
    _14914 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14882);
    _14882 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    DeRef(_14830);
    _14830 = NOVALUE;
    DeRef(_14920);
    _14920 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14881);
    _14881 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14899);
    _14899 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14886);
    _14886 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14850 = NOVALUE;
    DeRef(_14856);
    _14856 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14837);
    _14837 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14921;
    goto L1; // [3564] 10
L97: 

    /** 		elsif class = GREATER then*/
    if (_class_25648 != 6)
    goto L99; // [3571] 3619

    /** 			if getch() = '=' then*/
    _14923 = _60getch();
    if (binary_op_a(NOTEQ, _14923, 61)){
        DeRef(_14923);
        _14923 = NOVALUE;
        goto L9A; // [3580] 3599
    }
    DeRef(_14923);
    _14923 = NOVALUE;

    /** 				return {GREATEREQ, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 2;
    ((int *)_2)[2] = 0;
    _14925 = MAKE_SEQ(_1);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14872);
    _14872 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    DeRef(_14818);
    _14818 = NOVALUE;
    DeRef(_14875);
    _14875 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    _14824 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14877);
    _14877 = NOVALUE;
    DeRef(_14916);
    _14916 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14819);
    _14819 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14921);
    _14921 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14914);
    _14914 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14882);
    _14882 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    DeRef(_14830);
    _14830 = NOVALUE;
    DeRef(_14920);
    _14920 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14881);
    _14881 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14899);
    _14899 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14886);
    _14886 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14850 = NOVALUE;
    DeRef(_14856);
    _14856 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14837);
    _14837 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14925;
    goto L1; // [3596] 10
L9A: 

    /** 				ungetch()*/
    _60ungetch();

    /** 				return {GREATER, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 6;
    ((int *)_2)[2] = 0;
    _14926 = MAKE_SEQ(_1);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14872);
    _14872 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    DeRef(_14818);
    _14818 = NOVALUE;
    DeRef(_14875);
    _14875 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    _14824 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14877);
    _14877 = NOVALUE;
    DeRef(_14916);
    _14916 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14819);
    _14819 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14921);
    _14921 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14914);
    _14914 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14882);
    _14882 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    DeRef(_14830);
    _14830 = NOVALUE;
    DeRef(_14920);
    _14920 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14881);
    _14881 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14899);
    _14899 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14886);
    _14886 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14850 = NOVALUE;
    DeRef(_14856);
    _14856 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14925);
    _14925 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14837);
    _14837 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14926;
    goto L1; // [3616] 10
L99: 

    /** 		elsif class = BANG then*/
    if (_class_25648 != -1)
    goto L9B; // [3623] 3671

    /** 			if getch() = '=' then*/
    _14928 = _60getch();
    if (binary_op_a(NOTEQ, _14928, 61)){
        DeRef(_14928);
        _14928 = NOVALUE;
        goto L9C; // [3632] 3651
    }
    DeRef(_14928);
    _14928 = NOVALUE;

    /** 				return {NOTEQ, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = 0;
    _14930 = MAKE_SEQ(_1);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14926);
    _14926 = NOVALUE;
    DeRef(_14872);
    _14872 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    DeRef(_14818);
    _14818 = NOVALUE;
    DeRef(_14875);
    _14875 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    _14824 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14877);
    _14877 = NOVALUE;
    DeRef(_14916);
    _14916 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14819);
    _14819 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14921);
    _14921 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14914);
    _14914 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14882);
    _14882 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    DeRef(_14830);
    _14830 = NOVALUE;
    DeRef(_14920);
    _14920 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14881);
    _14881 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14899);
    _14899 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14886);
    _14886 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14850 = NOVALUE;
    DeRef(_14856);
    _14856 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14925);
    _14925 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14837);
    _14837 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14930;
    goto L1; // [3648] 10
L9C: 

    /** 				ungetch()*/
    _60ungetch();

    /** 				return {BANG, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _14931 = MAKE_SEQ(_1);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14926);
    _14926 = NOVALUE;
    DeRef(_14872);
    _14872 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    DeRef(_14818);
    _14818 = NOVALUE;
    DeRef(_14875);
    _14875 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    _14824 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14877);
    _14877 = NOVALUE;
    DeRef(_14916);
    _14916 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14819);
    _14819 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14921);
    _14921 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14914);
    _14914 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14882);
    _14882 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    DeRef(_14830);
    _14830 = NOVALUE;
    DeRef(_14920);
    _14920 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14881);
    _14881 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14899);
    _14899 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14886);
    _14886 = NOVALUE;
    DeRef(_14930);
    _14930 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14850 = NOVALUE;
    DeRef(_14856);
    _14856 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14925);
    _14925 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14837);
    _14837 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14931;
    goto L1; // [3668] 10
L9B: 

    /** 		elsif class = KEYWORD then*/
    if (_class_25648 != -10)
    goto L9D; // [3675] 3708

    /** 			return {keylist[ch - KEYWORD_BASE][K_TOKEN], 0}*/
    _14933 = _ch_25636 - 128;
    _2 = (int)SEQ_PTR(_62keylist_22870);
    _14934 = (int)*(((s1_ptr)_2)->base + _14933);
    _2 = (int)SEQ_PTR(_14934);
    _14935 = (int)*(((s1_ptr)_2)->base + 3);
    _14934 = NOVALUE;
    Ref(_14935);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _14935;
    ((int *)_2)[2] = 0;
    _14936 = MAKE_SEQ(_1);
    _14935 = NOVALUE;
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14926);
    _14926 = NOVALUE;
    DeRef(_14872);
    _14872 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    DeRef(_14818);
    _14818 = NOVALUE;
    DeRef(_14875);
    _14875 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    _14824 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14877);
    _14877 = NOVALUE;
    DeRef(_14916);
    _14916 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14819);
    _14819 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14921);
    _14921 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    _14933 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14914);
    _14914 = NOVALUE;
    DeRef(_14931);
    _14931 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14882);
    _14882 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    DeRef(_14830);
    _14830 = NOVALUE;
    DeRef(_14920);
    _14920 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14881);
    _14881 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14899);
    _14899 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14886);
    _14886 = NOVALUE;
    DeRef(_14930);
    _14930 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14850 = NOVALUE;
    DeRef(_14856);
    _14856 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14925);
    _14925 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14837);
    _14837 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14936;
    goto L1; // [3705] 10
L9D: 

    /** 		elsif class = BUILTIN then*/
    if (_class_25648 != -9)
    goto L9E; // [3712] 3765

    /** 			name = keylist[ch - BUILTIN_BASE + NUM_KEYWORDS][K_NAME]*/
    _14938 = _ch_25636 - 170;
    if ((long)((unsigned long)_14938 +(unsigned long) HIGH_BITS) >= 0){
        _14938 = NewDouble((double)_14938);
    }
    if (IS_ATOM_INT(_14938)) {
        _14939 = _14938 + 24;
    }
    else {
        _14939 = NewDouble(DBL_PTR(_14938)->dbl + (double)24);
    }
    DeRef(_14938);
    _14938 = NOVALUE;
    _2 = (int)SEQ_PTR(_62keylist_22870);
    if (!IS_ATOM_INT(_14939)){
        _14940 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14939)->dbl));
    }
    else{
        _14940 = (int)*(((s1_ptr)_2)->base + _14939);
    }
    DeRef(_name_25649);
    _2 = (int)SEQ_PTR(_14940);
    _name_25649 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_name_25649);
    _14940 = NOVALUE;

    /** 			return keyfind(name, -1)*/
    RefDS(_name_25649);
    _31677 = _52hashfn(_name_25649);
    RefDS(_name_25649);
    _14942 = _52keyfind(_name_25649, -1, _26current_file_no_11982, 0, _31677);
    _31677 = NOVALUE;
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRefDS(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14926);
    _14926 = NOVALUE;
    DeRef(_14939);
    _14939 = NOVALUE;
    DeRef(_14872);
    _14872 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    DeRef(_14818);
    _14818 = NOVALUE;
    DeRef(_14875);
    _14875 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    _14824 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14877);
    _14877 = NOVALUE;
    DeRef(_14916);
    _14916 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14819);
    _14819 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14921);
    _14921 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    DeRef(_14933);
    _14933 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14914);
    _14914 = NOVALUE;
    DeRef(_14931);
    _14931 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14882);
    _14882 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    DeRef(_14830);
    _14830 = NOVALUE;
    DeRef(_14920);
    _14920 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14881);
    _14881 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14899);
    _14899 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14886);
    _14886 = NOVALUE;
    DeRef(_14930);
    _14930 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14850 = NOVALUE;
    DeRef(_14856);
    _14856 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14925);
    _14925 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14837);
    _14837 = NOVALUE;
    DeRef(_14936);
    _14936 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14942;
    goto L1; // [3762] 10
L9E: 

    /** 		elsif class = BACK_QUOTE then*/
    if (_class_25648 != -12)
    goto L9F; // [3769] 3786

    /** 			return ExtendedString( '`' )*/
    _14944 = _60ExtendedString(96);
    DeRef(_yytext_25642);
    DeRef(_namespaces_25643);
    DeRef(_d_25644);
    DeRef(_tok_25646);
    DeRef(_name_25649);
    DeRef(_14636);
    _14636 = NOVALUE;
    _14752 = NOVALUE;
    DeRef(_14863);
    _14863 = NOVALUE;
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14926);
    _14926 = NOVALUE;
    DeRef(_14939);
    _14939 = NOVALUE;
    DeRef(_14872);
    _14872 = NOVALUE;
    DeRef(_14771);
    _14771 = NOVALUE;
    DeRef(_14818);
    _14818 = NOVALUE;
    DeRef(_14875);
    _14875 = NOVALUE;
    _14748 = NOVALUE;
    DeRef(_14805);
    _14805 = NOVALUE;
    _14824 = NOVALUE;
    DeRef(_14786);
    _14786 = NOVALUE;
    DeRef(_14877);
    _14877 = NOVALUE;
    DeRef(_14916);
    _14916 = NOVALUE;
    DeRef(_14686);
    _14686 = NOVALUE;
    DeRef(_14740);
    _14740 = NOVALUE;
    DeRef(_14681);
    _14681 = NOVALUE;
    DeRef(_14692);
    _14692 = NOVALUE;
    DeRef(_14586);
    _14586 = NOVALUE;
    DeRef(_14819);
    _14819 = NOVALUE;
    DeRef(_14564);
    _14564 = NOVALUE;
    _14615 = NOVALUE;
    DeRef(_14781);
    _14781 = NOVALUE;
    DeRef(_14788);
    _14788 = NOVALUE;
    DeRef(_14921);
    _14921 = NOVALUE;
    DeRef(_14585);
    _14585 = NOVALUE;
    _14652 = NOVALUE;
    _14626 = NOVALUE;
    _14726 = NOVALUE;
    _14637 = NOVALUE;
    DeRef(_14707);
    _14707 = NOVALUE;
    DeRef(_14933);
    _14933 = NOVALUE;
    _14601 = NOVALUE;
    DeRef(_14795);
    _14795 = NOVALUE;
    DeRef(_14914);
    _14914 = NOVALUE;
    DeRef(_14931);
    _14931 = NOVALUE;
    DeRef(_14582);
    _14582 = NOVALUE;
    DeRef(_14757);
    _14757 = NOVALUE;
    DeRef(_14759);
    _14759 = NOVALUE;
    DeRef(_14882);
    _14882 = NOVALUE;
    DeRef(_14809);
    _14809 = NOVALUE;
    DeRef(_14813);
    _14813 = NOVALUE;
    DeRef(_14830);
    _14830 = NOVALUE;
    DeRef(_14920);
    _14920 = NOVALUE;
    _14730 = NOVALUE;
    DeRef(_14881);
    _14881 = NOVALUE;
    DeRef(_14579);
    _14579 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    _14695 = NOVALUE;
    DeRef(_14769);
    _14769 = NOVALUE;
    DeRef(_14899);
    _14899 = NOVALUE;
    DeRef(_14559);
    _14559 = NOVALUE;
    DeRef(_14886);
    _14886 = NOVALUE;
    DeRef(_14930);
    _14930 = NOVALUE;
    DeRef(_14610);
    _14610 = NOVALUE;
    DeRef(_14814);
    _14814 = NOVALUE;
    _14850 = NOVALUE;
    DeRef(_14856);
    _14856 = NOVALUE;
    _14705 = NOVALUE;
    DeRef(_14925);
    _14925 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    DeRef(_14734);
    _14734 = NOVALUE;
    DeRef(_14837);
    _14837 = NOVALUE;
    DeRef(_14936);
    _14936 = NOVALUE;
    DeRef(_14576);
    _14576 = NOVALUE;
    DeRef(_14779);
    _14779 = NOVALUE;
    DeRef(_14942);
    _14942 = NOVALUE;
    DeRef(_14685);
    _14685 = NOVALUE;
    DeRef(_14742);
    _14742 = NOVALUE;
    DeRef(_14794);
    _14794 = NOVALUE;
    return _14944;
    goto L1; // [3783] 10
L9F: 

    /** 			InternalErr(268, {class})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _class_25648;
    _14945 = MAKE_SEQ(_1);
    _43InternalErr(268, _14945);
    _14945 = NOVALUE;

    /**    end while*/
    goto L1; // [3799] 10
L2: 
    ;
}


void _60eu_namespace()
{
    int _eu_tok_26423 = NOVALUE;
    int _eu_ns_26425 = NOVALUE;
    int _31676 = NOVALUE;
    int _31675 = NOVALUE;
    int _14954 = NOVALUE;
    int _14952 = NOVALUE;
    int _14950 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	eu_tok = keyfind("eu", -1, , 1)*/
    RefDS(_14948);
    _31675 = _14948;
    _31676 = _52hashfn(_31675);
    _31675 = NOVALUE;
    RefDS(_14948);
    _0 = _eu_tok_26423;
    _eu_tok_26423 = _52keyfind(_14948, -1, _26current_file_no_11982, 1, _31676);
    DeRef(_0);
    _31676 = NOVALUE;

    /** 	eu_ns  = NameSpace_declaration(eu_tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_eu_tok_26423);
    _14950 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_14950);
    _eu_ns_26425 = _60NameSpace_declaration(_14950);
    _14950 = NOVALUE;
    if (!IS_ATOM_INT(_eu_ns_26425)) {
        _1 = (long)(DBL_PTR(_eu_ns_26425)->dbl);
        DeRefDS(_eu_ns_26425);
        _eu_ns_26425 = _1;
    }

    /** 	SymTab[eu_ns][S_OBJ] = 0*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_eu_ns_26425 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _14952 = NOVALUE;

    /** 	SymTab[eu_ns][S_SCOPE] = SC_GLOBAL*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_eu_ns_26425 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 6;
    DeRef(_1);
    _14954 = NOVALUE;

    /** end procedure*/
    DeRef(_eu_tok_26423);
    return;
    ;
}


int _60StringToken(int _pDelims_26443)
{
    int _ch_26444 = NOVALUE;
    int _m_26445 = NOVALUE;
    int _gtext_26446 = NOVALUE;
    int _level_26477 = NOVALUE;
    int _14993 = NOVALUE;
    int _14991 = NOVALUE;
    int _14989 = NOVALUE;
    int _14970 = NOVALUE;
    int _14969 = NOVALUE;
    int _14963 = NOVALUE;
    int _14961 = NOVALUE;
    int _14959 = NOVALUE;
    int _14957 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ch = getch()*/
    _ch_26444 = _60getch();
    if (!IS_ATOM_INT(_ch_26444)) {
        _1 = (long)(DBL_PTR(_ch_26444)->dbl);
        DeRefDS(_ch_26444);
        _ch_26444 = _1;
    }

    /** 	while ch = ' ' or ch = '\t' do*/
L1: 
    _14957 = (_ch_26444 == 32);
    if (_14957 != 0) {
        goto L2; // [19] 32
    }
    _14959 = (_ch_26444 == 9);
    if (_14959 == 0)
    {
        DeRef(_14959);
        _14959 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_14959);
        _14959 = NOVALUE;
    }
L2: 

    /** 		ch = getch()*/
    _ch_26444 = _60getch();
    if (!IS_ATOM_INT(_ch_26444)) {
        _1 = (long)(DBL_PTR(_ch_26444)->dbl);
        DeRefDS(_ch_26444);
        _ch_26444 = _1;
    }

    /** 	end while*/
    goto L1; // [41] 15
L3: 

    /** 	pDelims &= {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 32;
    *((int *)(_2+8)) = 9;
    *((int *)(_2+12)) = 10;
    *((int *)(_2+16)) = 13;
    *((int *)(_2+20)) = 26;
    _14961 = MAKE_SEQ(_1);
    Concat((object_ptr)&_pDelims_26443, _pDelims_26443, _14961);
    DeRefDS(_14961);
    _14961 = NOVALUE;

    /** 	gtext = ""*/
    RefDS(_5);
    DeRefi(_gtext_26446);
    _gtext_26446 = _5;

    /** 	while not find(ch,  pDelims) label "top" do*/
L4: 
    _14963 = find_from(_ch_26444, _pDelims_26443, 1);
    if (_14963 != 0)
    goto L5; // [77] 391
    _14963 = NOVALUE;

    /** 		if ch = '-' then*/
    if (_ch_26444 != 45)
    goto L6; // [82] 145

    /** 			ch = getch()*/
    _ch_26444 = _60getch();
    if (!IS_ATOM_INT(_ch_26444)) {
        _1 = (long)(DBL_PTR(_ch_26444)->dbl);
        DeRefDS(_ch_26444);
        _ch_26444 = _1;
    }

    /** 			if ch = '-' then*/
    if (_ch_26444 != 45)
    goto L7; // [95] 137

    /** 				while not find(ch, {'\n', END_OF_FILE_CHAR}) do*/
L8: 
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 10;
    ((int *)_2)[2] = 26;
    _14969 = MAKE_SEQ(_1);
    _14970 = find_from(_ch_26444, _14969, 1);
    DeRefDS(_14969);
    _14969 = NOVALUE;
    if (_14970 != 0)
    goto L5; // [115] 391
    _14970 = NOVALUE;

    /** 					ch = getch()*/
    _ch_26444 = _60getch();
    if (!IS_ATOM_INT(_ch_26444)) {
        _1 = (long)(DBL_PTR(_ch_26444)->dbl);
        DeRefDS(_ch_26444);
        _ch_26444 = _1;
    }

    /** 				end while*/
    goto L8; // [127] 104

    /** 				exit*/
    goto L5; // [132] 391
    goto L9; // [134] 373
L7: 

    /** 				ungetch()*/
    _60ungetch();
    goto L9; // [142] 373
L6: 

    /** 		elsif ch = '/' then*/
    if (_ch_26444 != 47)
    goto LA; // [147] 372

    /** 			ch = getch()*/
    _ch_26444 = _60getch();
    if (!IS_ATOM_INT(_ch_26444)) {
        _1 = (long)(DBL_PTR(_ch_26444)->dbl);
        DeRefDS(_ch_26444);
        _ch_26444 = _1;
    }

    /** 			if ch = '*' then*/
    if (_ch_26444 != 42)
    goto LB; // [160] 361

    /** 				integer level = 1*/
    _level_26477 = 1;

    /** 				while level > 0 do*/
LC: 
    if (_level_26477 <= 0)
    goto LD; // [174] 293

    /** 					ch = getch()*/
    _ch_26444 = _60getch();
    if (!IS_ATOM_INT(_ch_26444)) {
        _1 = (long)(DBL_PTR(_ch_26444)->dbl);
        DeRefDS(_ch_26444);
        _ch_26444 = _1;
    }

    /** 					if ch = '/' then*/
    if (_ch_26444 != 47)
    goto LE; // [187] 221

    /** 						ch = getch()*/
    _ch_26444 = _60getch();
    if (!IS_ATOM_INT(_ch_26444)) {
        _1 = (long)(DBL_PTR(_ch_26444)->dbl);
        DeRefDS(_ch_26444);
        _ch_26444 = _1;
    }

    /** 						if ch = '*' then*/
    if (_ch_26444 != 42)
    goto LF; // [200] 213

    /** 							level += 1*/
    _level_26477 = _level_26477 + 1;
    goto LC; // [210] 174
LF: 

    /** 							ungetch()*/
    _60ungetch();
    goto LC; // [218] 174
LE: 

    /** 					elsif ch = '*' then*/
    if (_ch_26444 != 42)
    goto L10; // [223] 257

    /** 						ch = getch()*/
    _ch_26444 = _60getch();
    if (!IS_ATOM_INT(_ch_26444)) {
        _1 = (long)(DBL_PTR(_ch_26444)->dbl);
        DeRefDS(_ch_26444);
        _ch_26444 = _1;
    }

    /** 						if ch = '/' then*/
    if (_ch_26444 != 47)
    goto L11; // [236] 249

    /** 							level -= 1*/
    _level_26477 = _level_26477 - 1;
    goto LC; // [246] 174
L11: 

    /** 							ungetch()*/
    _60ungetch();
    goto LC; // [254] 174
L10: 

    /** 					elsif ch = '\n' then*/
    if (_ch_26444 != 10)
    goto L12; // [259] 270

    /** 						read_line()*/
    _60read_line();
    goto LC; // [267] 174
L12: 

    /** 					elsif ch = END_OF_FILE_CHAR then*/
    if (_ch_26444 != 26)
    goto LC; // [274] 174

    /** 						ungetch()*/
    _60ungetch();

    /** 						exit*/
    goto LD; // [284] 293

    /** 				end while*/
    goto LC; // [290] 174
LD: 

    /** 				ch = getch()*/
    _ch_26444 = _60getch();
    if (!IS_ATOM_INT(_ch_26444)) {
        _1 = (long)(DBL_PTR(_ch_26444)->dbl);
        DeRefDS(_ch_26444);
        _ch_26444 = _1;
    }

    /** 				if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_26446)){
            _14989 = SEQ_PTR(_gtext_26446)->length;
    }
    else {
        _14989 = 1;
    }
    if (_14989 != 0)
    goto L13; // [305] 350

    /** 					while ch = ' ' or ch = '\t' do*/
L14: 
    _14991 = (_ch_26444 == 32);
    if (_14991 != 0) {
        goto L15; // [318] 331
    }
    _14993 = (_ch_26444 == 9);
    if (_14993 == 0)
    {
        DeRef(_14993);
        _14993 = NOVALUE;
        goto L16; // [327] 343
    }
    else{
        DeRef(_14993);
        _14993 = NOVALUE;
    }
L15: 

    /** 						ch = getch()*/
    _ch_26444 = _60getch();
    if (!IS_ATOM_INT(_ch_26444)) {
        _1 = (long)(DBL_PTR(_ch_26444)->dbl);
        DeRefDS(_ch_26444);
        _ch_26444 = _1;
    }

    /** 					end while*/
    goto L14; // [340] 314
L16: 

    /** 					continue "top"*/
    goto L4; // [347] 72
L13: 

    /** 				exit*/
    goto L5; // [354] 391
    goto L17; // [358] 371
LB: 

    /** 				ungetch()*/
    _60ungetch();

    /** 				ch = '/'*/
    _ch_26444 = 47;
L17: 
LA: 
L9: 

    /** 		gtext &= ch*/
    Append(&_gtext_26446, _gtext_26446, _ch_26444);

    /** 		ch = getch()*/
    _ch_26444 = _60getch();
    if (!IS_ATOM_INT(_ch_26444)) {
        _1 = (long)(DBL_PTR(_ch_26444)->dbl);
        DeRefDS(_ch_26444);
        _ch_26444 = _1;
    }

    /** 	end while*/
    goto L4; // [388] 72
L5: 

    /** 	ungetch() -- put back end-word token.*/
    _60ungetch();

    /** 	return gtext*/
    DeRefDS(_pDelims_26443);
    DeRef(_14957);
    _14957 = NOVALUE;
    DeRef(_14991);
    _14991 = NOVALUE;
    return _gtext_26446;
    ;
}


void _60IncludeScan(int _is_public_26514)
{
    int _ch_26515 = NOVALUE;
    int _gtext_26516 = NOVALUE;
    int _s_26518 = NOVALUE;
    int _31674 = NOVALUE;
    int _15057 = NOVALUE;
    int _15056 = NOVALUE;
    int _15054 = NOVALUE;
    int _15052 = NOVALUE;
    int _15051 = NOVALUE;
    int _15046 = NOVALUE;
    int _15043 = NOVALUE;
    int _15041 = NOVALUE;
    int _15040 = NOVALUE;
    int _15038 = NOVALUE;
    int _15036 = NOVALUE;
    int _15034 = NOVALUE;
    int _15032 = NOVALUE;
    int _15026 = NOVALUE;
    int _15024 = NOVALUE;
    int _15018 = NOVALUE;
    int _15014 = NOVALUE;
    int _15013 = NOVALUE;
    int _15008 = NOVALUE;
    int _15005 = NOVALUE;
    int _15004 = NOVALUE;
    int _15000 = NOVALUE;
    int _14998 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_is_public_26514)) {
        _1 = (long)(DBL_PTR(_is_public_26514)->dbl);
        DeRefDS(_is_public_26514);
        _is_public_26514 = _1;
    }

    /** 	ch = getch()*/
    _ch_26515 = _60getch();
    if (!IS_ATOM_INT(_ch_26515)) {
        _1 = (long)(DBL_PTR(_ch_26515)->dbl);
        DeRefDS(_ch_26515);
        _ch_26515 = _1;
    }

    /** 	while ch = ' ' or ch = '\t' do*/
L1: 
    _14998 = (_ch_26515 == 32);
    if (_14998 != 0) {
        goto L2; // [19] 32
    }
    _15000 = (_ch_26515 == 9);
    if (_15000 == 0)
    {
        DeRef(_15000);
        _15000 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_15000);
        _15000 = NOVALUE;
    }
L2: 

    /** 		ch = getch()*/
    _ch_26515 = _60getch();
    if (!IS_ATOM_INT(_ch_26515)) {
        _1 = (long)(DBL_PTR(_ch_26515)->dbl);
        DeRefDS(_ch_26515);
        _ch_26515 = _1;
    }

    /** 	end while*/
    goto L1; // [41] 15
L3: 

    /** 	gtext = ""*/
    RefDS(_5);
    DeRef(_gtext_26516);
    _gtext_26516 = _5;

    /** 	if ch = '"' then*/
    if (_ch_26515 != 34)
    goto L4; // [53] 141

    /** 		ch = getch()*/
    _ch_26515 = _60getch();
    if (!IS_ATOM_INT(_ch_26515)) {
        _1 = (long)(DBL_PTR(_ch_26515)->dbl);
        DeRefDS(_ch_26515);
        _ch_26515 = _1;
    }

    /** 		while not find(ch, {'\n', '\r', '"', END_OF_FILE_CHAR}) do*/
L5: 
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 10;
    *((int *)(_2+8)) = 13;
    *((int *)(_2+12)) = 34;
    *((int *)(_2+16)) = 26;
    _15004 = MAKE_SEQ(_1);
    _15005 = find_from(_ch_26515, _15004, 1);
    DeRefDS(_15004);
    _15004 = NOVALUE;
    if (_15005 != 0)
    goto L6; // [83] 124
    _15005 = NOVALUE;

    /** 			if ch = '\\' then*/
    if (_ch_26515 != 92)
    goto L7; // [88] 105

    /** 				gtext &= EscapeChar('"')*/
    _15008 = _60EscapeChar(34);
    if (IS_SEQUENCE(_gtext_26516) && IS_ATOM(_15008)) {
        Ref(_15008);
        Append(&_gtext_26516, _gtext_26516, _15008);
    }
    else if (IS_ATOM(_gtext_26516) && IS_SEQUENCE(_15008)) {
    }
    else {
        Concat((object_ptr)&_gtext_26516, _gtext_26516, _15008);
    }
    DeRef(_15008);
    _15008 = NOVALUE;
    goto L8; // [102] 112
L7: 

    /** 				gtext &= ch*/
    Append(&_gtext_26516, _gtext_26516, _ch_26515);
L8: 

    /** 			ch = getch()*/
    _ch_26515 = _60getch();
    if (!IS_ATOM_INT(_ch_26515)) {
        _1 = (long)(DBL_PTR(_ch_26515)->dbl);
        DeRefDS(_ch_26515);
        _ch_26515 = _1;
    }

    /** 		end while*/
    goto L5; // [121] 69
L6: 

    /** 		if ch != '"' then*/
    if (_ch_26515 == 34)
    goto L9; // [126] 187

    /** 			CompileErr(115)*/
    RefDS(_22037);
    _43CompileErr(115, _22037, 0);
    goto L9; // [138] 187
L4: 

    /** 		while not find(ch, {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}) do*/
LA: 
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 32;
    *((int *)(_2+8)) = 9;
    *((int *)(_2+12)) = 10;
    *((int *)(_2+16)) = 13;
    *((int *)(_2+20)) = 26;
    _15013 = MAKE_SEQ(_1);
    _15014 = find_from(_ch_26515, _15013, 1);
    DeRefDS(_15013);
    _15013 = NOVALUE;
    if (_15014 != 0)
    goto LB; // [161] 182
    _15014 = NOVALUE;

    /** 			gtext &= ch*/
    Append(&_gtext_26516, _gtext_26516, _ch_26515);

    /** 			ch = getch()*/
    _ch_26515 = _60getch();
    if (!IS_ATOM_INT(_ch_26515)) {
        _1 = (long)(DBL_PTR(_ch_26515)->dbl);
        DeRefDS(_ch_26515);
        _ch_26515 = _1;
    }

    /** 		end while*/
    goto LA; // [179] 146
LB: 

    /** 		ungetch()*/
    _60ungetch();
L9: 

    /** 	if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_26516)){
            _15018 = SEQ_PTR(_gtext_26516)->length;
    }
    else {
        _15018 = 1;
    }
    if (_15018 != 0)
    goto LC; // [192] 204

    /** 		CompileErr(95)*/
    RefDS(_22037);
    _43CompileErr(95, _22037, 0);
LC: 

    /** 	ifdef WINDOWS then*/

    /** 		new_include_name = match_replace(`/`, gtext, `\`)*/
    RefDS(_15020);
    RefDS(_gtext_26516);
    RefDS(_15021);
    _0 = _14match_replace(_15020, _gtext_26516, _15021, 0);
    DeRef(_26new_include_name_12105);
    _26new_include_name_12105 = _0;

    /** 	ch = getch()*/
    _ch_26515 = _60getch();
    if (!IS_ATOM_INT(_ch_26515)) {
        _1 = (long)(DBL_PTR(_ch_26515)->dbl);
        DeRefDS(_ch_26515);
        _ch_26515 = _1;
    }

    /** 	while ch = ' ' or ch = '\t' do*/
LD: 
    _15024 = (_ch_26515 == 32);
    if (_15024 != 0) {
        goto LE; // [233] 246
    }
    _15026 = (_ch_26515 == 9);
    if (_15026 == 0)
    {
        DeRef(_15026);
        _15026 = NOVALUE;
        goto LF; // [242] 258
    }
    else{
        DeRef(_15026);
        _15026 = NOVALUE;
    }
LE: 

    /** 		ch = getch()*/
    _ch_26515 = _60getch();
    if (!IS_ATOM_INT(_ch_26515)) {
        _1 = (long)(DBL_PTR(_ch_26515)->dbl);
        DeRefDS(_ch_26515);
        _ch_26515 = _1;
    }

    /** 	end while*/
    goto LD; // [255] 229
LF: 

    /** 	new_include_space = 0*/
    _60new_include_space_23935 = 0;

    /** 	if ch = 'a' then*/
    if (_ch_26515 != 97)
    goto L10; // [267] 524

    /** 		ch = getch()*/
    _ch_26515 = _60getch();
    if (!IS_ATOM_INT(_ch_26515)) {
        _1 = (long)(DBL_PTR(_ch_26515)->dbl);
        DeRefDS(_ch_26515);
        _ch_26515 = _1;
    }

    /** 		if ch = 's' then*/
    if (_ch_26515 != 115)
    goto L11; // [280] 513

    /** 			ch = getch()*/
    _ch_26515 = _60getch();
    if (!IS_ATOM_INT(_ch_26515)) {
        _1 = (long)(DBL_PTR(_ch_26515)->dbl);
        DeRefDS(_ch_26515);
        _ch_26515 = _1;
    }

    /** 			if ch = ' ' or ch = '\t' then*/
    _15032 = (_ch_26515 == 32);
    if (_15032 != 0) {
        goto L12; // [297] 310
    }
    _15034 = (_ch_26515 == 9);
    if (_15034 == 0)
    {
        DeRef(_15034);
        _15034 = NOVALUE;
        goto L13; // [306] 502
    }
    else{
        DeRef(_15034);
        _15034 = NOVALUE;
    }
L12: 

    /** 				ch = getch()*/
    _ch_26515 = _60getch();
    if (!IS_ATOM_INT(_ch_26515)) {
        _1 = (long)(DBL_PTR(_ch_26515)->dbl);
        DeRefDS(_ch_26515);
        _ch_26515 = _1;
    }

    /** 				while ch = ' ' or ch = '\t' do*/
L14: 
    _15036 = (_ch_26515 == 32);
    if (_15036 != 0) {
        goto L15; // [326] 339
    }
    _15038 = (_ch_26515 == 9);
    if (_15038 == 0)
    {
        DeRef(_15038);
        _15038 = NOVALUE;
        goto L16; // [335] 351
    }
    else{
        DeRef(_15038);
        _15038 = NOVALUE;
    }
L15: 

    /** 					ch = getch()*/
    _ch_26515 = _60getch();
    if (!IS_ATOM_INT(_ch_26515)) {
        _1 = (long)(DBL_PTR(_ch_26515)->dbl);
        DeRefDS(_ch_26515);
        _ch_26515 = _1;
    }

    /** 				end while*/
    goto L14; // [348] 322
L16: 

    /** 				if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (int)SEQ_PTR(_60char_class_23944);
    _15040 = (int)*(((s1_ptr)_2)->base + _ch_26515);
    _15041 = (_15040 == -2);
    _15040 = NOVALUE;
    if (_15041 != 0) {
        goto L17; // [365] 378
    }
    _15043 = (_ch_26515 == 95);
    if (_15043 == 0)
    {
        DeRef(_15043);
        _15043 = NOVALUE;
        goto L18; // [374] 491
    }
    else{
        DeRef(_15043);
        _15043 = NOVALUE;
    }
L17: 

    /** 					gtext = {ch}*/
    _0 = _gtext_26516;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _ch_26515;
    _gtext_26516 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 					ch = getch()*/
    _ch_26515 = _60getch();
    if (!IS_ATOM_INT(_ch_26515)) {
        _1 = (long)(DBL_PTR(_ch_26515)->dbl);
        DeRefDS(_ch_26515);
        _ch_26515 = _1;
    }

    /** 					while id_char[ch] = TRUE do*/
L19: 
    _2 = (int)SEQ_PTR(_60id_char_23945);
    _15046 = (int)*(((s1_ptr)_2)->base + _ch_26515);
    if (_15046 != _9TRUE_430)
    goto L1A; // [404] 426

    /** 						gtext &= ch*/
    Append(&_gtext_26516, _gtext_26516, _ch_26515);

    /** 						ch = getch()*/
    _ch_26515 = _60getch();
    if (!IS_ATOM_INT(_ch_26515)) {
        _1 = (long)(DBL_PTR(_ch_26515)->dbl);
        DeRefDS(_ch_26515);
        _ch_26515 = _1;
    }

    /** 					end while*/
    goto L19; // [423] 396
L1A: 

    /** 					ungetch()*/
    _60ungetch();

    /** 					s = keyfind(gtext, -1, , 1)*/
    RefDS(_gtext_26516);
    _31674 = _52hashfn(_gtext_26516);
    RefDS(_gtext_26516);
    _0 = _s_26518;
    _s_26518 = _52keyfind(_gtext_26516, -1, _26current_file_no_11982, 1, _31674);
    DeRef(_0);
    _31674 = NOVALUE;

    /** 					if not find(s[T_ID], ID_TOKS) then*/
    _2 = (int)SEQ_PTR(_s_26518);
    _15051 = (int)*(((s1_ptr)_2)->base + 1);
    _15052 = find_from(_15051, _28ID_TOKS_11608, 1);
    _15051 = NOVALUE;
    if (_15052 != 0)
    goto L1B; // [463] 474
    _15052 = NOVALUE;

    /** 						CompileErr(36)*/
    RefDS(_22037);
    _43CompileErr(36, _22037, 0);
L1B: 

    /** 					new_include_space = NameSpace_declaration(s[T_SYM])*/
    _2 = (int)SEQ_PTR(_s_26518);
    _15054 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_15054);
    _0 = _60NameSpace_declaration(_15054);
    _60new_include_space_23935 = _0;
    _15054 = NOVALUE;
    if (!IS_ATOM_INT(_60new_include_space_23935)) {
        _1 = (long)(DBL_PTR(_60new_include_space_23935)->dbl);
        DeRefDS(_60new_include_space_23935);
        _60new_include_space_23935 = _1;
    }
    goto L1C; // [488] 633
L18: 

    /** 					CompileErr(113)*/
    RefDS(_22037);
    _43CompileErr(113, _22037, 0);
    goto L1C; // [499] 633
L13: 

    /** 				CompileErr(100)*/
    RefDS(_22037);
    _43CompileErr(100, _22037, 0);
    goto L1C; // [510] 633
L11: 

    /** 			CompileErr(100)*/
    RefDS(_22037);
    _43CompileErr(100, _22037, 0);
    goto L1C; // [521] 633
L10: 

    /** 	elsif find(ch, {'\n', '\r', END_OF_FILE_CHAR}) then*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 10;
    *((int *)(_2+8)) = 13;
    *((int *)(_2+12)) = 26;
    _15056 = MAKE_SEQ(_1);
    _15057 = find_from(_ch_26515, _15056, 1);
    DeRefDS(_15056);
    _15056 = NOVALUE;
    if (_15057 == 0)
    {
        _15057 = NOVALUE;
        goto L1D; // [539] 549
    }
    else{
        _15057 = NOVALUE;
    }

    /** 		ungetch()*/
    _60ungetch();
    goto L1C; // [546] 633
L1D: 

    /** 	elsif ch = '-' then*/
    if (_ch_26515 != 45)
    goto L1E; // [551] 587

    /** 		ch = getch()*/
    _ch_26515 = _60getch();
    if (!IS_ATOM_INT(_ch_26515)) {
        _1 = (long)(DBL_PTR(_ch_26515)->dbl);
        DeRefDS(_ch_26515);
        _ch_26515 = _1;
    }

    /** 		if ch != '-' then*/
    if (_ch_26515 == 45)
    goto L1F; // [564] 576

    /** 			CompileErr(100)*/
    RefDS(_22037);
    _43CompileErr(100, _22037, 0);
L1F: 

    /** 		ungetch()*/
    _60ungetch();

    /** 		ungetch()*/
    _60ungetch();
    goto L1C; // [584] 633
L1E: 

    /** 	elsif ch = '/' then*/
    if (_ch_26515 != 47)
    goto L20; // [589] 625

    /** 		ch = getch()*/
    _ch_26515 = _60getch();
    if (!IS_ATOM_INT(_ch_26515)) {
        _1 = (long)(DBL_PTR(_ch_26515)->dbl);
        DeRefDS(_ch_26515);
        _ch_26515 = _1;
    }

    /** 		if ch != '*' then*/
    if (_ch_26515 == 42)
    goto L21; // [602] 614

    /** 			CompileErr(100)*/
    RefDS(_22037);
    _43CompileErr(100, _22037, 0);
L21: 

    /** 		ungetch()*/
    _60ungetch();

    /** 		ungetch()*/
    _60ungetch();
    goto L1C; // [622] 633
L20: 

    /** 		CompileErr(100)*/
    RefDS(_22037);
    _43CompileErr(100, _22037, 0);
L1C: 

    /** 	start_include = TRUE -- let scanner know*/
    _60start_include_23937 = _9TRUE_430;

    /** 	public_include = is_public*/
    _60public_include_23940 = _is_public_26514;

    /** end procedure*/
    DeRef(_gtext_26516);
    DeRef(_s_26518);
    DeRef(_14998);
    _14998 = NOVALUE;
    DeRef(_15024);
    _15024 = NOVALUE;
    DeRef(_15032);
    _15032 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    _15046 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return;
    ;
}


void _60main_file()
{
    int _0, _1, _2;
    

    /** 	ifdef STDDEBUG then*/

    /** 		read_line()*/
    _60read_line();

    /** 		default_namespace( )*/
    _60default_namespace();

    /** end procedure*/
    return;
    ;
}


void _60cleanup_open_includes()
{
    int _15067 = NOVALUE;
    int _15066 = NOVALUE;
    int _15065 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length( IncludeStk ) do*/
    if (IS_SEQUENCE(_60IncludeStk_23946)){
            _15065 = SEQ_PTR(_60IncludeStk_23946)->length;
    }
    else {
        _15065 = 1;
    }
    {
        int _i_26639;
        _i_26639 = 1;
L1: 
        if (_i_26639 > _15065){
            goto L2; // [8] 36
        }

        /** 		close( IncludeStk[i][FILE_PTR] )*/
        _2 = (int)SEQ_PTR(_60IncludeStk_23946);
        _15066 = (int)*(((s1_ptr)_2)->base + _i_26639);
        _2 = (int)SEQ_PTR(_15066);
        _15067 = (int)*(((s1_ptr)_2)->base + 3);
        _15066 = NOVALUE;
        if (IS_ATOM_INT(_15067))
        EClose(_15067);
        else
        EClose((int)DBL_PTR(_15067)->dbl);
        _15067 = NOVALUE;

        /** 	end for*/
        _i_26639 = _i_26639 + 1;
        goto L1; // [31] 15
L2: 
        ;
    }

    /** end procedure*/
    return;
    ;
}



// 0xD10A241D
