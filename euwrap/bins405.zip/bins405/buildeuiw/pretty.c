// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _10pretty_out(int _text_1566)
{
    int _655 = NOVALUE;
    int _653 = NOVALUE;
    int _651 = NOVALUE;
    int _650 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pretty_line &= text*/
    if (IS_SEQUENCE(_10pretty_line_1563) && IS_ATOM(_text_1566)) {
        Ref(_text_1566);
        Append(&_10pretty_line_1563, _10pretty_line_1563, _text_1566);
    }
    else if (IS_ATOM(_10pretty_line_1563) && IS_SEQUENCE(_text_1566)) {
    }
    else {
        Concat((object_ptr)&_10pretty_line_1563, _10pretty_line_1563, _text_1566);
    }

    /** 	if equal(text, '\n') and pretty_printing then*/
    if (_text_1566 == 10)
    _650 = 1;
    else if (IS_ATOM_INT(_text_1566) && IS_ATOM_INT(10))
    _650 = 0;
    else
    _650 = (compare(_text_1566, 10) == 0);
    if (_650 == 0) {
        goto L1; // [15] 50
    }
    if (_10pretty_printing_1560 == 0)
    {
        goto L1; // [22] 50
    }
    else{
    }

    /** 		puts(pretty_file, pretty_line)*/
    EPuts(_10pretty_file_1551, _10pretty_line_1563); // DJP 

    /** 		pretty_line = ""*/
    RefDS(_5);
    DeRefDS(_10pretty_line_1563);
    _10pretty_line_1563 = _5;

    /** 		pretty_line_count += 1*/
    _10pretty_line_count_1556 = _10pretty_line_count_1556 + 1;
L1: 

    /** 	if atom(text) then*/
    _653 = IS_ATOM(_text_1566);
    if (_653 == 0)
    {
        _653 = NOVALUE;
        goto L2; // [55] 69
    }
    else{
        _653 = NOVALUE;
    }

    /** 		pretty_chars += 1*/
    _10pretty_chars_1548 = _10pretty_chars_1548 + 1;
    goto L3; // [66] 81
L2: 

    /** 		pretty_chars += length(text)*/
    if (IS_SEQUENCE(_text_1566)){
            _655 = SEQ_PTR(_text_1566)->length;
    }
    else {
        _655 = 1;
    }
    _10pretty_chars_1548 = _10pretty_chars_1548 + _655;
    _655 = NOVALUE;
L3: 

    /** end procedure*/
    DeRef(_text_1566);
    return;
    ;
}


void _10cut_line(int _n_1580)
{
    int _658 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not pretty_line_breaks then	*/
    if (_10pretty_line_breaks_1559 != 0)
    goto L1; // [7] 21

    /** 		pretty_chars = 0*/
    _10pretty_chars_1548 = 0;

    /** 		return*/
    return;
L1: 

    /** 	if pretty_chars + n > pretty_end_col then*/
    _658 = _10pretty_chars_1548 + _n_1580;
    if ((long)((unsigned long)_658 + (unsigned long)HIGH_BITS) >= 0) 
    _658 = NewDouble((double)_658);
    if (binary_op_a(LESSEQ, _658, _10pretty_end_col_1547)){
        DeRef(_658);
        _658 = NOVALUE;
        goto L2; // [31] 46
    }
    DeRef(_658);
    _658 = NOVALUE;

    /** 		pretty_out('\n')*/
    _10pretty_out(10);

    /** 		pretty_chars = 0*/
    _10pretty_chars_1548 = 0;
L2: 

    /** end procedure*/
    return;
    ;
}


void _10indent()
{
    int _666 = NOVALUE;
    int _665 = NOVALUE;
    int _664 = NOVALUE;
    int _663 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if pretty_line_breaks = 0 then	*/
    if (_10pretty_line_breaks_1559 != 0)
    goto L1; // [5] 22

    /** 		pretty_chars = 0*/
    _10pretty_chars_1548 = 0;

    /** 		return*/
    return;
    goto L2; // [19] 85
L1: 

    /** 	elsif pretty_line_breaks = -1 then*/
    if (_10pretty_line_breaks_1559 != -1)
    goto L3; // [26] 38

    /** 		cut_line( 0 )*/
    _10cut_line(0);
    goto L2; // [35] 85
L3: 

    /** 		if pretty_chars > 0 then*/
    if (_10pretty_chars_1548 <= 0)
    goto L4; // [42] 57

    /** 			pretty_out('\n')*/
    _10pretty_out(10);

    /** 			pretty_chars = 0*/
    _10pretty_chars_1548 = 0;
L4: 

    /** 		pretty_out(repeat(' ', (pretty_start_col-1) + */
    _663 = _10pretty_start_col_1549 - 1;
    if ((long)((unsigned long)_663 +(unsigned long) HIGH_BITS) >= 0){
        _663 = NewDouble((double)_663);
    }
    if (_10pretty_level_1550 == (short)_10pretty_level_1550 && _10pretty_indent_1553 <= INT15 && _10pretty_indent_1553 >= -INT15)
    _664 = _10pretty_level_1550 * _10pretty_indent_1553;
    else
    _664 = NewDouble(_10pretty_level_1550 * (double)_10pretty_indent_1553);
    if (IS_ATOM_INT(_663) && IS_ATOM_INT(_664)) {
        _665 = _663 + _664;
    }
    else {
        if (IS_ATOM_INT(_663)) {
            _665 = NewDouble((double)_663 + DBL_PTR(_664)->dbl);
        }
        else {
            if (IS_ATOM_INT(_664)) {
                _665 = NewDouble(DBL_PTR(_663)->dbl + (double)_664);
            }
            else
            _665 = NewDouble(DBL_PTR(_663)->dbl + DBL_PTR(_664)->dbl);
        }
    }
    DeRef(_663);
    _663 = NOVALUE;
    DeRef(_664);
    _664 = NOVALUE;
    _666 = Repeat(32, _665);
    DeRef(_665);
    _665 = NOVALUE;
    _10pretty_out(_666);
    _666 = NOVALUE;
L2: 

    /** end procedure*/
    return;
    ;
}


int _10esc_char(int _a_1601)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_1601)) {
        _1 = (long)(DBL_PTR(_a_1601)->dbl);
        DeRefDS(_a_1601);
        _a_1601 = _1;
    }

    /** 	switch a do*/
    _0 = _a_1601;
    switch ( _0 ){ 

        /** 		case'\t' then*/
        case 9:

        /** 			return `\t`*/
        RefDS(_669);
        return _669;
        goto L1; // [20] 81

        /** 		case'\n' then*/
        case 10:

        /** 			return `\n`*/
        RefDS(_670);
        return _670;
        goto L1; // [32] 81

        /** 		case'\r' then*/
        case 13:

        /** 			return `\r`*/
        RefDS(_671);
        return _671;
        goto L1; // [44] 81

        /** 		case'\\' then*/
        case 92:

        /** 			return `\\`*/
        RefDS(_673);
        return _673;
        goto L1; // [56] 81

        /** 		case'"' then*/
        case 34:

        /** 			return `\"`*/
        RefDS(_675);
        return _675;
        goto L1; // [68] 81

        /** 		case else*/
        default:

        /** 			return a*/
        return _a_1601;
    ;}L1: 
    ;
}


void _10rPrint(int _a_1619)
{
    int _sbuff_1620 = NOVALUE;
    int _multi_line_1621 = NOVALUE;
    int _all_ascii_1622 = NOVALUE;
    int _732 = NOVALUE;
    int _731 = NOVALUE;
    int _730 = NOVALUE;
    int _729 = NOVALUE;
    int _725 = NOVALUE;
    int _724 = NOVALUE;
    int _723 = NOVALUE;
    int _722 = NOVALUE;
    int _720 = NOVALUE;
    int _719 = NOVALUE;
    int _717 = NOVALUE;
    int _716 = NOVALUE;
    int _714 = NOVALUE;
    int _713 = NOVALUE;
    int _712 = NOVALUE;
    int _711 = NOVALUE;
    int _710 = NOVALUE;
    int _709 = NOVALUE;
    int _708 = NOVALUE;
    int _707 = NOVALUE;
    int _706 = NOVALUE;
    int _705 = NOVALUE;
    int _704 = NOVALUE;
    int _703 = NOVALUE;
    int _702 = NOVALUE;
    int _701 = NOVALUE;
    int _700 = NOVALUE;
    int _699 = NOVALUE;
    int _698 = NOVALUE;
    int _694 = NOVALUE;
    int _693 = NOVALUE;
    int _692 = NOVALUE;
    int _691 = NOVALUE;
    int _690 = NOVALUE;
    int _689 = NOVALUE;
    int _687 = NOVALUE;
    int _686 = NOVALUE;
    int _682 = NOVALUE;
    int _681 = NOVALUE;
    int _680 = NOVALUE;
    int _677 = NOVALUE;
    int _676 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _676 = IS_ATOM(_a_1619);
    if (_676 == 0)
    {
        _676 = NOVALUE;
        goto L1; // [6] 176
    }
    else{
        _676 = NOVALUE;
    }

    /** 		if integer(a) then*/
    if (IS_ATOM_INT(_a_1619))
    _677 = 1;
    else if (IS_ATOM_DBL(_a_1619))
    _677 = IS_ATOM_INT(DoubleToInt(_a_1619));
    else
    _677 = 0;
    if (_677 == 0)
    {
        _677 = NOVALUE;
        goto L2; // [14] 157
    }
    else{
        _677 = NOVALUE;
    }

    /** 			sbuff = sprintf(pretty_int_format, a)*/
    DeRef(_sbuff_1620);
    _sbuff_1620 = EPrintf(-9999999, _10pretty_int_format_1562, _a_1619);

    /** 			if pretty_ascii then */
    if (_10pretty_ascii_1552 == 0)
    {
        goto L3; // [29] 166
    }
    else{
    }

    /** 				if pretty_ascii >= 3 then */
    if (_10pretty_ascii_1552 < 3)
    goto L4; // [36] 103

    /** 					if (a >= pretty_ascii_min and a <= pretty_ascii_max) then*/
    if (IS_ATOM_INT(_a_1619)) {
        _680 = (_a_1619 >= _10pretty_ascii_min_1554);
    }
    else {
        _680 = binary_op(GREATEREQ, _a_1619, _10pretty_ascii_min_1554);
    }
    if (IS_ATOM_INT(_680)) {
        if (_680 == 0) {
            _681 = 0;
            goto L5; // [48] 62
        }
    }
    else {
        if (DBL_PTR(_680)->dbl == 0.0) {
            _681 = 0;
            goto L5; // [48] 62
        }
    }
    if (IS_ATOM_INT(_a_1619)) {
        _682 = (_a_1619 <= _10pretty_ascii_max_1555);
    }
    else {
        _682 = binary_op(LESSEQ, _a_1619, _10pretty_ascii_max_1555);
    }
    DeRef(_681);
    if (IS_ATOM_INT(_682))
    _681 = (_682 != 0);
    else
    _681 = DBL_PTR(_682)->dbl != 0.0;
L5: 
    if (_681 == 0)
    {
        _681 = NOVALUE;
        goto L6; // [62] 76
    }
    else{
        _681 = NOVALUE;
    }

    /** 						sbuff = '\'' & a & '\''  -- display char only*/
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _a_1619;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_sbuff_1620, concat_list, 3);
    }
    goto L3; // [73] 166
L6: 

    /** 					elsif find(a, "\t\n\r\\") then*/
    _686 = find_from(_a_1619, _685, 1);
    if (_686 == 0)
    {
        _686 = NOVALUE;
        goto L3; // [83] 166
    }
    else{
        _686 = NOVALUE;
    }

    /** 						sbuff = '\'' & esc_char(a) & '\''  -- display char only*/
    Ref(_a_1619);
    _687 = _10esc_char(_a_1619);
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _687;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_sbuff_1620, concat_list, 3);
    }
    DeRef(_687);
    _687 = NOVALUE;
    goto L3; // [100] 166
L4: 

    /** 					if (a >= pretty_ascii_min and a <= pretty_ascii_max) and pretty_ascii < 2 then*/
    if (IS_ATOM_INT(_a_1619)) {
        _689 = (_a_1619 >= _10pretty_ascii_min_1554);
    }
    else {
        _689 = binary_op(GREATEREQ, _a_1619, _10pretty_ascii_min_1554);
    }
    if (IS_ATOM_INT(_689)) {
        if (_689 == 0) {
            DeRef(_690);
            _690 = 0;
            goto L7; // [111] 125
        }
    }
    else {
        if (DBL_PTR(_689)->dbl == 0.0) {
            DeRef(_690);
            _690 = 0;
            goto L7; // [111] 125
        }
    }
    if (IS_ATOM_INT(_a_1619)) {
        _691 = (_a_1619 <= _10pretty_ascii_max_1555);
    }
    else {
        _691 = binary_op(LESSEQ, _a_1619, _10pretty_ascii_max_1555);
    }
    DeRef(_690);
    if (IS_ATOM_INT(_691))
    _690 = (_691 != 0);
    else
    _690 = DBL_PTR(_691)->dbl != 0.0;
L7: 
    if (_690 == 0) {
        goto L3; // [125] 166
    }
    _693 = (_10pretty_ascii_1552 < 2);
    if (_693 == 0)
    {
        DeRef(_693);
        _693 = NOVALUE;
        goto L3; // [136] 166
    }
    else{
        DeRef(_693);
        _693 = NOVALUE;
    }

    /** 						sbuff &= '\'' & a & '\'' -- add to numeric display*/
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _a_1619;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_694, concat_list, 3);
    }
    Concat((object_ptr)&_sbuff_1620, _sbuff_1620, _694);
    DeRefDS(_694);
    _694 = NOVALUE;
    goto L3; // [154] 166
L2: 

    /** 			sbuff = sprintf(pretty_fp_format, a)*/
    DeRef(_sbuff_1620);
    _sbuff_1620 = EPrintf(-9999999, _10pretty_fp_format_1561, _a_1619);
L3: 

    /** 		pretty_out(sbuff)*/
    RefDS(_sbuff_1620);
    _10pretty_out(_sbuff_1620);
    goto L8; // [173] 535
L1: 

    /** 		cut_line(1)*/
    _10cut_line(1);

    /** 		multi_line = 0*/
    _multi_line_1621 = 0;

    /** 		all_ascii = pretty_ascii > 1*/
    _all_ascii_1622 = (_10pretty_ascii_1552 > 1);

    /** 		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_1619)){
            _698 = SEQ_PTR(_a_1619)->length;
    }
    else {
        _698 = 1;
    }
    {
        int _i_1656;
        _i_1656 = 1;
L9: 
        if (_i_1656 > _698){
            goto LA; // [199] 345
        }

        /** 			if sequence(a[i]) and length(a[i]) > 0 then*/
        _2 = (int)SEQ_PTR(_a_1619);
        _699 = (int)*(((s1_ptr)_2)->base + _i_1656);
        _700 = IS_SEQUENCE(_699);
        _699 = NOVALUE;
        if (_700 == 0) {
            goto LB; // [215] 249
        }
        _2 = (int)SEQ_PTR(_a_1619);
        _702 = (int)*(((s1_ptr)_2)->base + _i_1656);
        if (IS_SEQUENCE(_702)){
                _703 = SEQ_PTR(_702)->length;
        }
        else {
            _703 = 1;
        }
        _702 = NOVALUE;
        _704 = (_703 > 0);
        _703 = NOVALUE;
        if (_704 == 0)
        {
            DeRef(_704);
            _704 = NOVALUE;
            goto LB; // [231] 249
        }
        else{
            DeRef(_704);
            _704 = NOVALUE;
        }

        /** 				multi_line = 1*/
        _multi_line_1621 = 1;

        /** 				all_ascii = 0*/
        _all_ascii_1622 = 0;

        /** 				exit*/
        goto LA; // [246] 345
LB: 

        /** 			if not integer(a[i]) or*/
        _2 = (int)SEQ_PTR(_a_1619);
        _705 = (int)*(((s1_ptr)_2)->base + _i_1656);
        if (IS_ATOM_INT(_705))
        _706 = 1;
        else if (IS_ATOM_DBL(_705))
        _706 = IS_ATOM_INT(DoubleToInt(_705));
        else
        _706 = 0;
        _705 = NOVALUE;
        _707 = (_706 == 0);
        _706 = NOVALUE;
        if (_707 != 0) {
            _708 = 1;
            goto LC; // [261] 313
        }
        _2 = (int)SEQ_PTR(_a_1619);
        _709 = (int)*(((s1_ptr)_2)->base + _i_1656);
        if (IS_ATOM_INT(_709)) {
            _710 = (_709 < _10pretty_ascii_min_1554);
        }
        else {
            _710 = binary_op(LESS, _709, _10pretty_ascii_min_1554);
        }
        _709 = NOVALUE;
        if (IS_ATOM_INT(_710)) {
            if (_710 == 0) {
                DeRef(_711);
                _711 = 0;
                goto LD; // [275] 309
            }
        }
        else {
            if (DBL_PTR(_710)->dbl == 0.0) {
                DeRef(_711);
                _711 = 0;
                goto LD; // [275] 309
            }
        }
        _712 = (_10pretty_ascii_1552 < 2);
        if (_712 != 0) {
            _713 = 1;
            goto LE; // [285] 305
        }
        _2 = (int)SEQ_PTR(_a_1619);
        _714 = (int)*(((s1_ptr)_2)->base + _i_1656);
        _716 = find_from(_714, _715, 1);
        _714 = NOVALUE;
        _717 = (_716 == 0);
        _716 = NOVALUE;
        _713 = (_717 != 0);
LE: 
        DeRef(_711);
        _711 = (_713 != 0);
LD: 
        _708 = (_711 != 0);
LC: 
        if (_708 != 0) {
            goto LF; // [313] 332
        }
        _2 = (int)SEQ_PTR(_a_1619);
        _719 = (int)*(((s1_ptr)_2)->base + _i_1656);
        if (IS_ATOM_INT(_719)) {
            _720 = (_719 > _10pretty_ascii_max_1555);
        }
        else {
            _720 = binary_op(GREATER, _719, _10pretty_ascii_max_1555);
        }
        _719 = NOVALUE;
        if (_720 == 0) {
            DeRef(_720);
            _720 = NOVALUE;
            goto L10; // [328] 338
        }
        else {
            if (!IS_ATOM_INT(_720) && DBL_PTR(_720)->dbl == 0.0){
                DeRef(_720);
                _720 = NOVALUE;
                goto L10; // [328] 338
            }
            DeRef(_720);
            _720 = NOVALUE;
        }
        DeRef(_720);
        _720 = NOVALUE;
LF: 

        /** 				all_ascii = 0*/
        _all_ascii_1622 = 0;
L10: 

        /** 		end for*/
        _i_1656 = _i_1656 + 1;
        goto L9; // [340] 206
LA: 
        ;
    }

    /** 		if all_ascii then*/
    if (_all_ascii_1622 == 0)
    {
        goto L11; // [347] 358
    }
    else{
    }

    /** 			pretty_out('\"')*/
    _10pretty_out(34);
    goto L12; // [355] 364
L11: 

    /** 			pretty_out('{')*/
    _10pretty_out(123);
L12: 

    /** 		pretty_level += 1*/
    _10pretty_level_1550 = _10pretty_level_1550 + 1;

    /** 		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_1619)){
            _722 = SEQ_PTR(_a_1619)->length;
    }
    else {
        _722 = 1;
    }
    {
        int _i_1686;
        _i_1686 = 1;
L13: 
        if (_i_1686 > _722){
            goto L14; // [377] 497
        }

        /** 			if multi_line then*/
        if (_multi_line_1621 == 0)
        {
            goto L15; // [386] 394
        }
        else{
        }

        /** 				indent()*/
        _10indent();
L15: 

        /** 			if all_ascii then*/
        if (_all_ascii_1622 == 0)
        {
            goto L16; // [396] 415
        }
        else{
        }

        /** 				pretty_out(esc_char(a[i]))*/
        _2 = (int)SEQ_PTR(_a_1619);
        _723 = (int)*(((s1_ptr)_2)->base + _i_1686);
        Ref(_723);
        _724 = _10esc_char(_723);
        _723 = NOVALUE;
        _10pretty_out(_724);
        _724 = NOVALUE;
        goto L17; // [412] 425
L16: 

        /** 				rPrint(a[i])*/
        _2 = (int)SEQ_PTR(_a_1619);
        _725 = (int)*(((s1_ptr)_2)->base + _i_1686);
        Ref(_725);
        _10rPrint(_725);
        _725 = NOVALUE;
L17: 

        /** 			if pretty_line_count >= pretty_line_max then*/
        if (_10pretty_line_count_1556 < _10pretty_line_max_1557)
        goto L18; // [431] 459

        /** 				if not pretty_dots then*/
        if (_10pretty_dots_1558 != 0)
        goto L19; // [439] 448

        /** 					pretty_out(" ...")*/
        RefDS(_728);
        _10pretty_out(_728);
L19: 

        /** 				pretty_dots = 1*/
        _10pretty_dots_1558 = 1;

        /** 				return*/
        DeRef(_a_1619);
        DeRef(_sbuff_1620);
        DeRef(_680);
        _680 = NOVALUE;
        DeRef(_682);
        _682 = NOVALUE;
        DeRef(_689);
        _689 = NOVALUE;
        DeRef(_691);
        _691 = NOVALUE;
        _702 = NOVALUE;
        DeRef(_707);
        _707 = NOVALUE;
        DeRef(_712);
        _712 = NOVALUE;
        DeRef(_710);
        _710 = NOVALUE;
        DeRef(_717);
        _717 = NOVALUE;
        return;
L18: 

        /** 			if i != length(a) and not all_ascii then*/
        if (IS_SEQUENCE(_a_1619)){
                _729 = SEQ_PTR(_a_1619)->length;
        }
        else {
            _729 = 1;
        }
        _730 = (_i_1686 != _729);
        _729 = NOVALUE;
        if (_730 == 0) {
            goto L1A; // [468] 490
        }
        _732 = (_all_ascii_1622 == 0);
        if (_732 == 0)
        {
            DeRef(_732);
            _732 = NOVALUE;
            goto L1A; // [476] 490
        }
        else{
            DeRef(_732);
            _732 = NOVALUE;
        }

        /** 				pretty_out(',')*/
        _10pretty_out(44);

        /** 				cut_line(6)*/
        _10cut_line(6);
L1A: 

        /** 		end for*/
        _i_1686 = _i_1686 + 1;
        goto L13; // [492] 384
L14: 
        ;
    }

    /** 		pretty_level -= 1*/
    _10pretty_level_1550 = _10pretty_level_1550 - 1;

    /** 		if multi_line then*/
    if (_multi_line_1621 == 0)
    {
        goto L1B; // [507] 515
    }
    else{
    }

    /** 			indent()*/
    _10indent();
L1B: 

    /** 		if all_ascii then*/
    if (_all_ascii_1622 == 0)
    {
        goto L1C; // [517] 528
    }
    else{
    }

    /** 			pretty_out('\"')*/
    _10pretty_out(34);
    goto L1D; // [525] 534
L1C: 

    /** 			pretty_out('}')*/
    _10pretty_out(125);
L1D: 
L8: 

    /** end procedure*/
    DeRef(_a_1619);
    DeRef(_sbuff_1620);
    DeRef(_680);
    _680 = NOVALUE;
    DeRef(_682);
    _682 = NOVALUE;
    DeRef(_689);
    _689 = NOVALUE;
    DeRef(_691);
    _691 = NOVALUE;
    _702 = NOVALUE;
    DeRef(_707);
    _707 = NOVALUE;
    DeRef(_712);
    _712 = NOVALUE;
    DeRef(_710);
    _710 = NOVALUE;
    DeRef(_717);
    _717 = NOVALUE;
    DeRef(_730);
    _730 = NOVALUE;
    return;
    ;
}


void _10pretty(int _x_1728, int _options_1729)
{
    int _747 = NOVALUE;
    int _746 = NOVALUE;
    int _745 = NOVALUE;
    int _744 = NOVALUE;
    int _742 = NOVALUE;
    int _741 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(options) < length( PRETTY_DEFAULT ) then*/
    if (IS_SEQUENCE(_options_1729)){
            _741 = SEQ_PTR(_options_1729)->length;
    }
    else {
        _741 = 1;
    }
    _742 = 10;
    if (_741 >= 10)
    goto L1; // [13] 41

    /** 		options &= PRETTY_DEFAULT[length(options)+1..$]*/
    if (IS_SEQUENCE(_options_1729)){
            _744 = SEQ_PTR(_options_1729)->length;
    }
    else {
        _744 = 1;
    }
    _745 = _744 + 1;
    _744 = NOVALUE;
    _746 = 10;
    rhs_slice_target = (object_ptr)&_747;
    RHS_Slice(_10PRETTY_DEFAULT_1714, _745, 10);
    Concat((object_ptr)&_options_1729, _options_1729, _747);
    DeRefDS(_747);
    _747 = NOVALUE;
L1: 

    /** 	pretty_ascii = options[DISPLAY_ASCII] */
    _2 = (int)SEQ_PTR(_options_1729);
    _10pretty_ascii_1552 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_10pretty_ascii_1552))
    _10pretty_ascii_1552 = (long)DBL_PTR(_10pretty_ascii_1552)->dbl;

    /** 	pretty_indent = options[INDENT]*/
    _2 = (int)SEQ_PTR(_options_1729);
    _10pretty_indent_1553 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_10pretty_indent_1553))
    _10pretty_indent_1553 = (long)DBL_PTR(_10pretty_indent_1553)->dbl;

    /** 	pretty_start_col = options[START_COLUMN]*/
    _2 = (int)SEQ_PTR(_options_1729);
    _10pretty_start_col_1549 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_10pretty_start_col_1549))
    _10pretty_start_col_1549 = (long)DBL_PTR(_10pretty_start_col_1549)->dbl;

    /** 	pretty_end_col = options[WRAP]*/
    _2 = (int)SEQ_PTR(_options_1729);
    _10pretty_end_col_1547 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_10pretty_end_col_1547))
    _10pretty_end_col_1547 = (long)DBL_PTR(_10pretty_end_col_1547)->dbl;

    /** 	pretty_int_format = options[INT_FORMAT]*/
    DeRef(_10pretty_int_format_1562);
    _2 = (int)SEQ_PTR(_options_1729);
    _10pretty_int_format_1562 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_10pretty_int_format_1562);

    /** 	pretty_fp_format = options[FP_FORMAT]*/
    DeRef(_10pretty_fp_format_1561);
    _2 = (int)SEQ_PTR(_options_1729);
    _10pretty_fp_format_1561 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_10pretty_fp_format_1561);

    /** 	pretty_ascii_min = options[MIN_ASCII]*/
    _2 = (int)SEQ_PTR(_options_1729);
    _10pretty_ascii_min_1554 = (int)*(((s1_ptr)_2)->base + 7);
    if (!IS_ATOM_INT(_10pretty_ascii_min_1554))
    _10pretty_ascii_min_1554 = (long)DBL_PTR(_10pretty_ascii_min_1554)->dbl;

    /** 	pretty_ascii_max = options[MAX_ASCII]*/
    _2 = (int)SEQ_PTR(_options_1729);
    _10pretty_ascii_max_1555 = (int)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_10pretty_ascii_max_1555))
    _10pretty_ascii_max_1555 = (long)DBL_PTR(_10pretty_ascii_max_1555)->dbl;

    /** 	pretty_line_max = options[MAX_LINES]*/
    _2 = (int)SEQ_PTR(_options_1729);
    _10pretty_line_max_1557 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_10pretty_line_max_1557))
    _10pretty_line_max_1557 = (long)DBL_PTR(_10pretty_line_max_1557)->dbl;

    /** 	pretty_line_breaks = options[LINE_BREAKS]*/
    _2 = (int)SEQ_PTR(_options_1729);
    _10pretty_line_breaks_1559 = (int)*(((s1_ptr)_2)->base + 10);
    if (!IS_ATOM_INT(_10pretty_line_breaks_1559))
    _10pretty_line_breaks_1559 = (long)DBL_PTR(_10pretty_line_breaks_1559)->dbl;

    /** 	pretty_chars = pretty_start_col*/
    _10pretty_chars_1548 = _10pretty_start_col_1549;

    /** 	pretty_level = 0 */
    _10pretty_level_1550 = 0;

    /** 	pretty_line = ""*/
    RefDS(_5);
    DeRef(_10pretty_line_1563);
    _10pretty_line_1563 = _5;

    /** 	pretty_line_count = 0*/
    _10pretty_line_count_1556 = 0;

    /** 	pretty_dots = 0*/
    _10pretty_dots_1558 = 0;

    /** 	rPrint(x)*/
    Ref(_x_1728);
    _10rPrint(_x_1728);

    /** end procedure*/
    DeRef(_x_1728);
    DeRefDS(_options_1729);
    DeRef(_745);
    _745 = NOVALUE;
    return;
    ;
}


void _10pretty_print(int _fn_1751, int _x_1752, int _options_1753)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_1751)) {
        _1 = (long)(DBL_PTR(_fn_1751)->dbl);
        DeRefDS(_fn_1751);
        _fn_1751 = _1;
    }

    /** 	pretty_printing = 1*/
    _10pretty_printing_1560 = 1;

    /** 	pretty_file = fn*/
    _10pretty_file_1551 = _fn_1751;

    /** 	pretty( x, options )*/
    Ref(_x_1752);
    RefDS(_options_1753);
    _10pretty(_x_1752, _options_1753);

    /** 	puts(pretty_file, pretty_line)*/
    EPuts(_10pretty_file_1551, _10pretty_line_1563); // DJP 

    /** end procedure*/
    DeRef(_x_1752);
    DeRefDS(_options_1753);
    return;
    ;
}


int _10pretty_sprint(int _x_1756, int _options_1757)
{
    int _0, _1, _2;
    

    /** 	pretty_printing = 0*/
    _10pretty_printing_1560 = 0;

    /** 	pretty( x, options )*/
    Ref(_x_1756);
    RefDS(_options_1757);
    _10pretty(_x_1756, _options_1757);

    /** 	return pretty_line*/
    RefDS(_10pretty_line_1563);
    DeRef(_x_1756);
    DeRefDS(_options_1757);
    return _10pretty_line_1563;
    ;
}



// 0x29F8DAC5
