// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _55iif(int _test_21933, int _ifTrue_21934, int _ifFalse_21935)
{
    int _0, _1, _2;
    

    /** 	if test then*/
    if (_test_21933 == 0)
    {
        goto L1; // [3] 13
    }
    else{
    }

    /** 		return ifTrue*/
    DeRefDS(_ifFalse_21935);
    return _ifTrue_21934;
L1: 

    /** 	return ifFalse*/
    DeRef(_ifTrue_21934);
    return _ifFalse_21935;
    ;
}



// 0x5DBBF858
