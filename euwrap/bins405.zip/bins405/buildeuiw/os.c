// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _3instance()
{
    int _529 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_INSTANCE, 0)*/
    _529 = machine(55, 0);
    return _529;
    ;
}


int _3get_pid()
{
    int _531 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		if cur_pid = -1 then*/
    if (binary_op_a(NOTEQ, _3cur_pid_1377, -1)){
        goto L1; // [7] 43
    }

    /** 			cur_pid = dll:define_c_func( dll:open_dll("kernel32.dll"), "GetCurrentProcessId", {}, dll:C_DWORD)*/
    RefDS(_380);
    _531 = _4open_dll(_380);
    RefDS(_532);
    RefDS(_5);
    _0 = _4define_c_func(_531, _532, _5, 33554436);
    DeRef(_3cur_pid_1377);
    _3cur_pid_1377 = _0;
    _531 = NOVALUE;

    /** 			if cur_pid >= 0 then*/
    if (binary_op_a(LESS, _3cur_pid_1377, 0)){
        goto L2; // [28] 42
    }

    /** 				cur_pid = c_func(cur_pid, {})*/
    _0 = _3cur_pid_1377;
    _3cur_pid_1377 = call_c(1, _3cur_pid_1377, _5);
    DeRef(_0);
L2: 
L1: 

    /** 		return cur_pid*/
    Ref(_3cur_pid_1377);
    return _3cur_pid_1377;
    ;
}


int _3uname()
{
    int _buf_1396 = NOVALUE;
    int _sbuf_1397 = NOVALUE;
    int _maj_1398 = NOVALUE;
    int _mine_1399 = NOVALUE;
    int _build_1400 = NOVALUE;
    int _plat_1401 = NOVALUE;
    int _638 = NOVALUE;
    int _636 = NOVALUE;
    int _635 = NOVALUE;
    int _633 = NOVALUE;
    int _632 = NOVALUE;
    int _627 = NOVALUE;
    int _626 = NOVALUE;
    int _620 = NOVALUE;
    int _619 = NOVALUE;
    int _615 = NOVALUE;
    int _614 = NOVALUE;
    int _613 = NOVALUE;
    int _610 = NOVALUE;
    int _609 = NOVALUE;
    int _608 = NOVALUE;
    int _605 = NOVALUE;
    int _604 = NOVALUE;
    int _603 = NOVALUE;
    int _600 = NOVALUE;
    int _599 = NOVALUE;
    int _598 = NOVALUE;
    int _595 = NOVALUE;
    int _594 = NOVALUE;
    int _593 = NOVALUE;
    int _589 = NOVALUE;
    int _588 = NOVALUE;
    int _587 = NOVALUE;
    int _584 = NOVALUE;
    int _583 = NOVALUE;
    int _582 = NOVALUE;
    int _579 = NOVALUE;
    int _578 = NOVALUE;
    int _577 = NOVALUE;
    int _558 = NOVALUE;
    int _557 = NOVALUE;
    int _551 = NOVALUE;
    int _549 = NOVALUE;
    int _547 = NOVALUE;
    int _545 = NOVALUE;
    int _544 = NOVALUE;
    int _543 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		atom buf*/

    /** 		sequence sbuf*/

    /** 		integer maj, mine, build, plat*/

    /** 		buf = machine:allocate(148)*/
    _0 = _buf_1396;
    _buf_1396 = _6allocate(148, 0);
    DeRef(_0);

    /** 		poke4(buf, 148)*/
    if (IS_ATOM_INT(_buf_1396)){
        poke4_addr = (unsigned long *)_buf_1396;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_buf_1396)->dbl);
    }
    *poke4_addr = (unsigned long)148;

    /** 		if c_func(M_UNAME, {buf}) then*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_buf_1396);
    *((int *)(_2+4)) = _buf_1396;
    _543 = MAKE_SEQ(_1);
    _544 = call_c(1, _3M_UNAME_1388, _543);
    DeRefDS(_543);
    _543 = NOVALUE;
    if (_544 == 0) {
        DeRef(_544);
        _544 = NOVALUE;
        goto L1; // [34] 529
    }
    else {
        if (!IS_ATOM_INT(_544) && DBL_PTR(_544)->dbl == 0.0){
            DeRef(_544);
            _544 = NOVALUE;
            goto L1; // [34] 529
        }
        DeRef(_544);
        _544 = NOVALUE;
    }
    DeRef(_544);
    _544 = NOVALUE;

    /** 			maj = peek4u(buf+4)*/
    if (IS_ATOM_INT(_buf_1396)) {
        _545 = _buf_1396 + 4;
        if ((long)((unsigned long)_545 + (unsigned long)HIGH_BITS) >= 0) 
        _545 = NewDouble((double)_545);
    }
    else {
        _545 = NewDouble(DBL_PTR(_buf_1396)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_545)) {
        _maj_1398 = *(unsigned long *)_545;
        if ((unsigned)_maj_1398 > (unsigned)MAXINT)
        _maj_1398 = NewDouble((double)(unsigned long)_maj_1398);
    }
    else {
        _maj_1398 = *(unsigned long *)(unsigned long)(DBL_PTR(_545)->dbl);
        if ((unsigned)_maj_1398 > (unsigned)MAXINT)
        _maj_1398 = NewDouble((double)(unsigned long)_maj_1398);
    }
    DeRef(_545);
    _545 = NOVALUE;
    if (!IS_ATOM_INT(_maj_1398)) {
        _1 = (long)(DBL_PTR(_maj_1398)->dbl);
        DeRefDS(_maj_1398);
        _maj_1398 = _1;
    }

    /** 			mine = peek4u(buf+8)*/
    if (IS_ATOM_INT(_buf_1396)) {
        _547 = _buf_1396 + 8;
        if ((long)((unsigned long)_547 + (unsigned long)HIGH_BITS) >= 0) 
        _547 = NewDouble((double)_547);
    }
    else {
        _547 = NewDouble(DBL_PTR(_buf_1396)->dbl + (double)8);
    }
    if (IS_ATOM_INT(_547)) {
        _mine_1399 = *(unsigned long *)_547;
        if ((unsigned)_mine_1399 > (unsigned)MAXINT)
        _mine_1399 = NewDouble((double)(unsigned long)_mine_1399);
    }
    else {
        _mine_1399 = *(unsigned long *)(unsigned long)(DBL_PTR(_547)->dbl);
        if ((unsigned)_mine_1399 > (unsigned)MAXINT)
        _mine_1399 = NewDouble((double)(unsigned long)_mine_1399);
    }
    DeRef(_547);
    _547 = NOVALUE;
    if (!IS_ATOM_INT(_mine_1399)) {
        _1 = (long)(DBL_PTR(_mine_1399)->dbl);
        DeRefDS(_mine_1399);
        _mine_1399 = _1;
    }

    /** 			build = peek4u(buf+12)*/
    if (IS_ATOM_INT(_buf_1396)) {
        _549 = _buf_1396 + 12;
        if ((long)((unsigned long)_549 + (unsigned long)HIGH_BITS) >= 0) 
        _549 = NewDouble((double)_549);
    }
    else {
        _549 = NewDouble(DBL_PTR(_buf_1396)->dbl + (double)12);
    }
    if (IS_ATOM_INT(_549)) {
        _build_1400 = *(unsigned long *)_549;
        if ((unsigned)_build_1400 > (unsigned)MAXINT)
        _build_1400 = NewDouble((double)(unsigned long)_build_1400);
    }
    else {
        _build_1400 = *(unsigned long *)(unsigned long)(DBL_PTR(_549)->dbl);
        if ((unsigned)_build_1400 > (unsigned)MAXINT)
        _build_1400 = NewDouble((double)(unsigned long)_build_1400);
    }
    DeRef(_549);
    _549 = NOVALUE;
    if (!IS_ATOM_INT(_build_1400)) {
        _1 = (long)(DBL_PTR(_build_1400)->dbl);
        DeRefDS(_build_1400);
        _build_1400 = _1;
    }

    /** 			plat = peek4u(buf+16)*/
    if (IS_ATOM_INT(_buf_1396)) {
        _551 = _buf_1396 + 16;
        if ((long)((unsigned long)_551 + (unsigned long)HIGH_BITS) >= 0) 
        _551 = NewDouble((double)_551);
    }
    else {
        _551 = NewDouble(DBL_PTR(_buf_1396)->dbl + (double)16);
    }
    if (IS_ATOM_INT(_551)) {
        _plat_1401 = *(unsigned long *)_551;
        if ((unsigned)_plat_1401 > (unsigned)MAXINT)
        _plat_1401 = NewDouble((double)(unsigned long)_plat_1401);
    }
    else {
        _plat_1401 = *(unsigned long *)(unsigned long)(DBL_PTR(_551)->dbl);
        if ((unsigned)_plat_1401 > (unsigned)MAXINT)
        _plat_1401 = NewDouble((double)(unsigned long)_plat_1401);
    }
    DeRef(_551);
    _551 = NOVALUE;
    if (!IS_ATOM_INT(_plat_1401)) {
        _1 = (long)(DBL_PTR(_plat_1401)->dbl);
        DeRefDS(_plat_1401);
        _plat_1401 = _1;
    }

    /** 			sbuf = {}*/
    RefDS(_5);
    DeRef(_sbuf_1397);
    _sbuf_1397 = _5;

    /** 			if plat = 0 then*/
    if (_plat_1401 != 0)
    goto L2; // [90] 117

    /** 				sbuf = append(sbuf, "Win32s")*/
    RefDS(_554);
    Append(&_sbuf_1397, _sbuf_1397, _554);

    /** 				sbuf = append(sbuf, sprintf("Windows %d.%d", {maj,mine}))*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _maj_1398;
    ((int *)_2)[2] = _mine_1399;
    _557 = MAKE_SEQ(_1);
    _558 = EPrintf(-9999999, _556, _557);
    DeRefDS(_557);
    _557 = NOVALUE;
    RefDS(_558);
    Append(&_sbuf_1397, _sbuf_1397, _558);
    DeRefDS(_558);
    _558 = NOVALUE;
    goto L3; // [114] 489
L2: 

    /** 			elsif plat = 1 then*/
    if (_plat_1401 != 1)
    goto L4; // [119] 184

    /** 				sbuf = append(sbuf, "Win9x")*/
    RefDS(_561);
    Append(&_sbuf_1397, _sbuf_1397, _561);

    /** 				if mine = 0 then*/
    if (_mine_1399 != 0)
    goto L5; // [131] 144

    /** 					sbuf = append(sbuf, "Win95")*/
    RefDS(_564);
    Append(&_sbuf_1397, _sbuf_1397, _564);
    goto L3; // [141] 489
L5: 

    /** 				elsif mine = 10 then*/
    if (_mine_1399 != 10)
    goto L6; // [146] 159

    /** 					sbuf = append(sbuf, "Win98")*/
    RefDS(_567);
    Append(&_sbuf_1397, _sbuf_1397, _567);
    goto L3; // [156] 489
L6: 

    /** 				elsif mine = 90 then*/
    if (_mine_1399 != 90)
    goto L7; // [161] 174

    /** 					sbuf = append(sbuf, "WinME")*/
    RefDS(_570);
    Append(&_sbuf_1397, _sbuf_1397, _570);
    goto L3; // [171] 489
L7: 

    /** 					sbuf = append(sbuf, "Unknown")*/
    RefDS(_572);
    Append(&_sbuf_1397, _sbuf_1397, _572);
    goto L3; // [181] 489
L4: 

    /** 			elsif plat = 2 then*/
    if (_plat_1401 != 2)
    goto L8; // [186] 439

    /** 				sbuf = append(sbuf, "WinNT")*/
    RefDS(_575);
    Append(&_sbuf_1397, _sbuf_1397, _575);

    /** 				if maj = 6 and mine = 1 then*/
    _577 = (_maj_1398 == 6);
    if (_577 == 0) {
        goto L9; // [202] 223
    }
    _579 = (_mine_1399 == 1);
    if (_579 == 0)
    {
        DeRef(_579);
        _579 = NOVALUE;
        goto L9; // [211] 223
    }
    else{
        DeRef(_579);
        _579 = NOVALUE;
    }

    /** 					sbuf = append(sbuf, "Windows7")*/
    RefDS(_580);
    Append(&_sbuf_1397, _sbuf_1397, _580);
    goto L3; // [220] 489
L9: 

    /** 				elsif maj = 6 and mine = 0 then*/
    _582 = (_maj_1398 == 6);
    if (_582 == 0) {
        goto LA; // [229] 250
    }
    _584 = (_mine_1399 == 0);
    if (_584 == 0)
    {
        DeRef(_584);
        _584 = NOVALUE;
        goto LA; // [238] 250
    }
    else{
        DeRef(_584);
        _584 = NOVALUE;
    }

    /** 					sbuf = append(sbuf, "Vista")*/
    RefDS(_585);
    Append(&_sbuf_1397, _sbuf_1397, _585);
    goto L3; // [247] 489
LA: 

    /** 				elsif maj = 5 and mine = 1 or 2 then*/
    _587 = (_maj_1398 == 5);
    if (_587 == 0) {
        _588 = 0;
        goto LB; // [256] 268
    }
    _589 = (_mine_1399 == 1);
    _588 = (_589 != 0);
LB: 
    if (_588 != 0) {
        goto LC; // [268] 277
    }
LC: 

    /** 					sbuf = append(sbuf, "WinXP")*/
    RefDS(_591);
    Append(&_sbuf_1397, _sbuf_1397, _591);
    goto L3; // [283] 489

    /** 				elsif maj = 5 and mine = 0 then*/
    _593 = (_maj_1398 == 5);
    if (_593 == 0) {
        goto LD; // [292] 313
    }
    _595 = (_mine_1399 == 0);
    if (_595 == 0)
    {
        DeRef(_595);
        _595 = NOVALUE;
        goto LD; // [301] 313
    }
    else{
        DeRef(_595);
        _595 = NOVALUE;
    }

    /** 					sbuf = append(sbuf, "Win2K")*/
    RefDS(_596);
    Append(&_sbuf_1397, _sbuf_1397, _596);
    goto L3; // [310] 489
LD: 

    /** 				elsif maj = 4 and mine = 0 then*/
    _598 = (_maj_1398 == 4);
    if (_598 == 0) {
        goto LE; // [319] 340
    }
    _600 = (_mine_1399 == 0);
    if (_600 == 0)
    {
        DeRef(_600);
        _600 = NOVALUE;
        goto LE; // [328] 340
    }
    else{
        DeRef(_600);
        _600 = NOVALUE;
    }

    /** 					sbuf = append(sbuf, "WinNT 4.0")*/
    RefDS(_601);
    Append(&_sbuf_1397, _sbuf_1397, _601);
    goto L3; // [337] 489
LE: 

    /** 				elsif maj = 3 and mine = 51 then*/
    _603 = (_maj_1398 == 3);
    if (_603 == 0) {
        goto LF; // [346] 367
    }
    _605 = (_mine_1399 == 51);
    if (_605 == 0)
    {
        DeRef(_605);
        _605 = NOVALUE;
        goto LF; // [355] 367
    }
    else{
        DeRef(_605);
        _605 = NOVALUE;
    }

    /** 					sbuf = append(sbuf, "WinNT 3.51")*/
    RefDS(_606);
    Append(&_sbuf_1397, _sbuf_1397, _606);
    goto L3; // [364] 489
LF: 

    /** 				elsif maj = 3 and mine = 50 then --is it 50 or 5?*/
    _608 = (_maj_1398 == 3);
    if (_608 == 0) {
        goto L10; // [373] 394
    }
    _610 = (_mine_1399 == 50);
    if (_610 == 0)
    {
        DeRef(_610);
        _610 = NOVALUE;
        goto L10; // [382] 394
    }
    else{
        DeRef(_610);
        _610 = NOVALUE;
    }

    /** 					sbuf = append(sbuf, "WinNT 3.5")*/
    RefDS(_611);
    Append(&_sbuf_1397, _sbuf_1397, _611);
    goto L3; // [391] 489
L10: 

    /** 				elsif maj = 3 and mine = 1 then*/
    _613 = (_maj_1398 == 3);
    if (_613 == 0) {
        goto L11; // [400] 421
    }
    _615 = (_mine_1399 == 1);
    if (_615 == 0)
    {
        DeRef(_615);
        _615 = NOVALUE;
        goto L11; // [409] 421
    }
    else{
        DeRef(_615);
        _615 = NOVALUE;
    }

    /** 					sbuf = append(sbuf, "WinNT 3.1")*/
    RefDS(_616);
    Append(&_sbuf_1397, _sbuf_1397, _616);
    goto L3; // [418] 489
L11: 

    /** 					sbuf = append(sbuf, sprintf("WinNT %d.%d", {maj,mine}))*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _maj_1398;
    ((int *)_2)[2] = _mine_1399;
    _619 = MAKE_SEQ(_1);
    _620 = EPrintf(-9999999, _618, _619);
    DeRefDS(_619);
    _619 = NOVALUE;
    RefDS(_620);
    Append(&_sbuf_1397, _sbuf_1397, _620);
    DeRefDS(_620);
    _620 = NOVALUE;
    goto L3; // [436] 489
L8: 

    /** 			elsif plat = 3 then*/
    if (_plat_1401 != 3)
    goto L12; // [441] 468

    /** 				sbuf = append(sbuf, "WinCE")*/
    RefDS(_623);
    Append(&_sbuf_1397, _sbuf_1397, _623);

    /** 				sbuf = append(sbuf, sprintf("WinCE %d.%d", {maj,mine}))*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _maj_1398;
    ((int *)_2)[2] = _mine_1399;
    _626 = MAKE_SEQ(_1);
    _627 = EPrintf(-9999999, _625, _626);
    DeRefDS(_626);
    _626 = NOVALUE;
    RefDS(_627);
    Append(&_sbuf_1397, _sbuf_1397, _627);
    DeRefDS(_627);
    _627 = NOVALUE;
    goto L3; // [465] 489
L12: 

    /** 				sbuf = append(sbuf, "Unknown Windows")*/
    RefDS(_629);
    Append(&_sbuf_1397, _sbuf_1397, _629);

    /** 				sbuf = append(sbuf, sprintf("Version %d.%d", {maj,mine}))*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _maj_1398;
    ((int *)_2)[2] = _mine_1399;
    _632 = MAKE_SEQ(_1);
    _633 = EPrintf(-9999999, _631, _632);
    DeRefDS(_632);
    _632 = NOVALUE;
    RefDS(_633);
    Append(&_sbuf_1397, _sbuf_1397, _633);
    DeRefDS(_633);
    _633 = NOVALUE;
L3: 

    /** 			sbuf = append(sbuf, peek_string(buf+20))*/
    if (IS_ATOM_INT(_buf_1396)) {
        _635 = _buf_1396 + 20;
        if ((long)((unsigned long)_635 + (unsigned long)HIGH_BITS) >= 0) 
        _635 = NewDouble((double)_635);
    }
    else {
        _635 = NewDouble(DBL_PTR(_buf_1396)->dbl + (double)20);
    }
    if (IS_ATOM_INT(_635)) {
        _636 =  NewString((char *)_635);
    }
    else {
        _636 = NewString((char *)(unsigned long)(DBL_PTR(_635)->dbl));
    }
    DeRef(_635);
    _635 = NOVALUE;
    RefDS(_636);
    Append(&_sbuf_1397, _sbuf_1397, _636);
    DeRefDS(_636);
    _636 = NOVALUE;

    /** 			sbuf &= {plat, build, mine, maj}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _plat_1401;
    *((int *)(_2+8)) = _build_1400;
    *((int *)(_2+12)) = _mine_1399;
    *((int *)(_2+16)) = _maj_1398;
    _638 = MAKE_SEQ(_1);
    Concat((object_ptr)&_sbuf_1397, _sbuf_1397, _638);
    DeRefDS(_638);
    _638 = NOVALUE;

    /** 			machine:free( buf )*/
    Ref(_buf_1396);
    _6free(_buf_1396);

    /** 			return sbuf*/
    DeRef(_buf_1396);
    DeRef(_577);
    _577 = NOVALUE;
    DeRef(_582);
    _582 = NOVALUE;
    DeRef(_587);
    _587 = NOVALUE;
    DeRef(_589);
    _589 = NOVALUE;
    DeRef(_593);
    _593 = NOVALUE;
    DeRef(_598);
    _598 = NOVALUE;
    DeRef(_603);
    _603 = NOVALUE;
    DeRef(_608);
    _608 = NOVALUE;
    DeRef(_613);
    _613 = NOVALUE;
    return _sbuf_1397;
    goto L13; // [526] 541
L1: 

    /** 			machine:free( buf )*/
    Ref(_buf_1396);
    _6free(_buf_1396);

    /** 			return {}*/
    RefDS(_5);
    DeRef(_buf_1396);
    DeRef(_sbuf_1397);
    DeRef(_577);
    _577 = NOVALUE;
    DeRef(_582);
    _582 = NOVALUE;
    DeRef(_587);
    _587 = NOVALUE;
    DeRef(_589);
    _589 = NOVALUE;
    DeRef(_593);
    _593 = NOVALUE;
    DeRef(_598);
    _598 = NOVALUE;
    DeRef(_603);
    _603 = NOVALUE;
    DeRef(_608);
    _608 = NOVALUE;
    DeRef(_613);
    _613 = NOVALUE;
    return _5;
L13: 
    ;
}


int _3is_win_nt()
{
    int _s_1524 = NOVALUE;
    int _643 = NOVALUE;
    int _642 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		sequence s*/

    /** 		s = uname()*/
    _0 = _s_1524;
    _s_1524 = _3uname();
    DeRef(_0);

    /** 		return equal(s[1], "WinNT")*/
    _2 = (int)SEQ_PTR(_s_1524);
    _642 = (int)*(((s1_ptr)_2)->base + 1);
    if (_642 == _575)
    _643 = 1;
    else if (IS_ATOM_INT(_642) && IS_ATOM_INT(_575))
    _643 = 0;
    else
    _643 = (compare(_642, _575) == 0);
    _642 = NOVALUE;
    DeRefDS(_s_1524);
    return _643;
    ;
}


int _3setenv(int _name_1530, int _val_1531, int _overwrite_1532)
{
    int _645 = NOVALUE;
    int _644 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_overwrite_1532)) {
        _1 = (long)(DBL_PTR(_overwrite_1532)->dbl);
        DeRefDS(_overwrite_1532);
        _overwrite_1532 = _1;
    }

    /** 	return machine_func(M_SET_ENV, {name, val, overwrite})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_name_1530);
    *((int *)(_2+4)) = _name_1530;
    RefDS(_val_1531);
    *((int *)(_2+8)) = _val_1531;
    *((int *)(_2+12)) = _overwrite_1532;
    _644 = MAKE_SEQ(_1);
    _645 = machine(73, _644);
    DeRefDS(_644);
    _644 = NOVALUE;
    DeRefDS(_name_1530);
    DeRefDS(_val_1531);
    return _645;
    ;
}


int _3unsetenv(int _env_1537)
{
    int _647 = NOVALUE;
    int _646 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_UNSET_ENV, {env})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_env_1537);
    *((int *)(_2+4)) = _env_1537;
    _646 = MAKE_SEQ(_1);
    _647 = machine(74, _646);
    DeRefDS(_646);
    _646 = NOVALUE;
    DeRefDS(_env_1537);
    return _647;
    ;
}


void _3sleep(int _t_1542)
{
    int _0, _1, _2;
    

    /** 	if t >= 0 then*/
    if (binary_op_a(LESS, _t_1542, 0)){
        goto L1; // [3] 13
    }

    /** 		machine_proc(M_SLEEP, t)*/
    machine(64, _t_1542);
L1: 

    /** end procedure*/
    DeRef(_t_1542);
    return;
    ;
}



// 0x31274DFF
