// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _6allocate(int _n_868, int _cleanup_869)
{
    int _iaddr_870 = NOVALUE;
    int _eaddr_871 = NOVALUE;
    int _331 = NOVALUE;
    int _330 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef DATA_EXECUTE then*/

    /** 		iaddr = eu:machine_func( memconst:M_ALLOC, n + memory:BORDER_SPACE * 2)*/
    _330 = 0;
    _331 = _n_868 + 0;
    _330 = NOVALUE;
    DeRef(_iaddr_870);
    _iaddr_870 = machine(16, _331);
    _331 = NOVALUE;

    /** 		eaddr = memory:prepare_block( iaddr, n, PAGE_READ_WRITE )*/
    Ref(_iaddr_870);
    _0 = _eaddr_871;
    _eaddr_871 = _8prepare_block(_iaddr_870, _n_868, 4);
    DeRef(_0);

    /** 	if cleanup then*/

    /** 	return eaddr*/
    DeRef(_iaddr_870);
    return _eaddr_871;
    ;
}


int _6allocate_data(int _n_881, int _cleanup_882)
{
    int _a_883 = NOVALUE;
    int _sla_885 = NOVALUE;
    int _336 = NOVALUE;
    int _335 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = eu:machine_func( memconst:M_ALLOC, n+BORDER_SPACE*2)*/
    _335 = 0;
    _336 = 4;
    _335 = NOVALUE;
    DeRef(_a_883);
    _a_883 = machine(16, 4);
    _336 = NOVALUE;

    /** 	sla = memory:prepare_block(a, n, PAGE_READ_WRITE )*/
    Ref(_a_883);
    _0 = _sla_885;
    _sla_885 = _8prepare_block(_a_883, 4, 4);
    DeRef(_0);

    /** 	if cleanup then*/

    /** 		return sla*/
    DeRef(_a_883);
    return _sla_885;
    ;
}


int _6VirtualAlloc(int _addr_1064, int _size_1065, int _allocation_type_1066, int _protect__1067)
{
    int _r1_1068 = NOVALUE;
    int _419 = NOVALUE;
    int _0, _1, _2;
    

    /** 		r1 = c_func( VirtualAlloc_rid, {addr, size, allocation_type, protect_ } )*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 1;
    Ref(_allocation_type_1066);
    *((int *)(_2+12)) = _allocation_type_1066;
    *((int *)(_2+16)) = 64;
    _419 = MAKE_SEQ(_1);
    DeRef(_r1_1068);
    _r1_1068 = call_c(1, _6VirtualAlloc_rid_981, _419);
    DeRefDS(_419);
    _419 = NOVALUE;

    /** 		return r1*/
    DeRef(_allocation_type_1066);
    return _r1_1068;
    ;
}


int _6allocate_string(int _s_1087, int _cleanup_1088)
{
    int _mem_1089 = NOVALUE;
    int _426 = NOVALUE;
    int _425 = NOVALUE;
    int _423 = NOVALUE;
    int _422 = NOVALUE;
    int _0, _1, _2;
    

    /** 	mem = allocate( length(s) + 1) -- Thanks to Igor*/
    if (IS_SEQUENCE(_s_1087)){
            _422 = SEQ_PTR(_s_1087)->length;
    }
    else {
        _422 = 1;
    }
    _423 = _422 + 1;
    _422 = NOVALUE;
    _0 = _mem_1089;
    _mem_1089 = _6allocate(_423, 0);
    DeRef(_0);
    _423 = NOVALUE;

    /** 	if mem then*/
    if (_mem_1089 == 0) {
        goto L1; // [19] 54
    }
    else {
        if (!IS_ATOM_INT(_mem_1089) && DBL_PTR(_mem_1089)->dbl == 0.0){
            goto L1; // [19] 54
        }
    }

    /** 		poke(mem, s)*/
    if (IS_ATOM_INT(_mem_1089)){
        poke_addr = (unsigned char *)_mem_1089;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_mem_1089)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_1087);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 		poke(mem+length(s), 0)  -- Thanks to Aku*/
    if (IS_SEQUENCE(_s_1087)){
            _425 = SEQ_PTR(_s_1087)->length;
    }
    else {
        _425 = 1;
    }
    if (IS_ATOM_INT(_mem_1089)) {
        _426 = _mem_1089 + _425;
        if ((long)((unsigned long)_426 + (unsigned long)HIGH_BITS) >= 0) 
        _426 = NewDouble((double)_426);
    }
    else {
        _426 = NewDouble(DBL_PTR(_mem_1089)->dbl + (double)_425);
    }
    _425 = NOVALUE;
    if (IS_ATOM_INT(_426)){
        poke_addr = (unsigned char *)_426;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_426)->dbl);
    }
    *poke_addr = (unsigned char)0;
    DeRef(_426);
    _426 = NOVALUE;

    /** 		if cleanup then*/
L1: 

    /** 	return mem*/
    DeRefDS(_s_1087);
    return _mem_1089;
    ;
}


int _6allocate_protect(int _data_1100, int _wordsize_1101, int _protection_1103)
{
    int _iaddr_1104 = NOVALUE;
    int _eaddr_1106 = NOVALUE;
    int _size_1107 = NOVALUE;
    int _first_protection_1109 = NOVALUE;
    int _true_protection_1111 = NOVALUE;
    int _prepare_block_inlined_prepare_block_at_104_1126 = NOVALUE;
    int _msg_inlined_crash_at_186_1139 = NOVALUE;
    int _447 = NOVALUE;
    int _446 = NOVALUE;
    int _444 = NOVALUE;
    int _443 = NOVALUE;
    int _442 = NOVALUE;
    int _438 = NOVALUE;
    int _436 = NOVALUE;
    int _433 = NOVALUE;
    int _432 = NOVALUE;
    int _430 = NOVALUE;
    int _428 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom iaddr = 0*/
    DeRef(_iaddr_1104);
    _iaddr_1104 = 0;

    /** 	integer size*/

    /** 	valid_memory_protection_constant true_protection = protection*/
    _true_protection_1111 = 64;

    /** 	ifdef SAFE then	*/

    /** 	if atom(data) then*/
    _428 = 1;
    if (_428 == 0)
    {
        _428 = NOVALUE;
        goto L1; // [20] 39
    }
    else{
        _428 = NOVALUE;
    }

    /** 		size = data * wordsize*/
    _size_1107 = _data_1100 * 1;

    /** 		first_protection = true_protection*/
    _first_protection_1109 = 64;
    goto L2; // [36] 58
L1: 

    /** 		size = length(data) * wordsize*/
    _430 = 1;
    _size_1107 = 1 * _wordsize_1101;
    _430 = NOVALUE;

    /** 		first_protection = PAGE_READ_WRITE*/
    _first_protection_1109 = 4;
L2: 

    /** 	iaddr = local_allocate_protected_memory( size + memory:BORDER_SPACE * 2, first_protection )*/
    _432 = 0;
    _433 = _size_1107 + 0;
    _432 = NOVALUE;
    _0 = _iaddr_1104;
    _iaddr_1104 = _6local_allocate_protected_memory(_433, _first_protection_1109);
    DeRef(_0);
    _433 = NOVALUE;

    /** 	if iaddr = 0 then*/
    if (binary_op_a(NOTEQ, _iaddr_1104, 0)){
        goto L3; // [79] 90
    }

    /** 		return 0*/
    DeRef(_iaddr_1104);
    DeRef(_eaddr_1106);
    return 0;
L3: 

    /** 	eaddr = memory:prepare_block( iaddr, size, protection )*/
    if (!IS_ATOM_INT(_protection_1103)) {
        _1 = (long)(DBL_PTR(_protection_1103)->dbl);
        DeRefDS(_protection_1103);
        _protection_1103 = _1;
    }

    /** 	return addr*/
    Ref(_iaddr_1104);
    DeRef(_eaddr_1106);
    _eaddr_1106 = _iaddr_1104;

    /** 	if eaddr = 0 or atom( data ) then*/
    if (IS_ATOM_INT(_eaddr_1106)) {
        _436 = (_eaddr_1106 == 0);
    }
    else {
        _436 = (DBL_PTR(_eaddr_1106)->dbl == (double)0);
    }
    if (_436 != 0) {
        goto L4; // [106] 118
    }
    _438 = 1;
    if (_438 == 0)
    {
        _438 = NOVALUE;
        goto L5; // [114] 125
    }
    else{
        _438 = NOVALUE;
    }
L4: 

    /** 		return eaddr*/
    DeRef(_iaddr_1104);
    DeRef(_436);
    _436 = NOVALUE;
    return _eaddr_1106;
L5: 

    /** 	switch wordsize do*/
    _0 = _wordsize_1101;
    switch ( _0 ){ 

        /** 		case 1 then*/
        case 1:

        /** 			eu:poke( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_1106)){
            poke_addr = (unsigned char *)_eaddr_1106;
        }
        else {
            poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_eaddr_1106)->dbl);
        }
        *poke_addr = (unsigned char)_data_1100;
        goto L6; // [141] 190

        /** 		case 2 then*/
        case 2:

        /** 			eu:poke2( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_1106)){
            poke2_addr = (unsigned short *)_eaddr_1106;
        }
        else {
            poke2_addr = (unsigned short *)(unsigned long)(DBL_PTR(_eaddr_1106)->dbl);
        }
        *poke2_addr = (unsigned short)_data_1100;
        goto L6; // [152] 190

        /** 		case 4 then*/
        case 4:

        /** 			eu:poke4( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_1106)){
            poke4_addr = (unsigned long *)_eaddr_1106;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_eaddr_1106)->dbl);
        }
        *poke4_addr = (unsigned long)_data_1100;
        goto L6; // [163] 190

        /** 		case else*/
        default:

        /** 			error:crash("Parameter error: Wrong word size %d in allocate_protect().", wordsize)*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_186_1139);
        _msg_inlined_crash_at_186_1139 = EPrintf(-9999999, _441, _wordsize_1101);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_186_1139);

        /** end procedure*/
        goto L7; // [184] 187
L7: 
        DeRefi(_msg_inlined_crash_at_186_1139);
        _msg_inlined_crash_at_186_1139 = NOVALUE;
    ;}L6: 

    /** 	ifdef SAFE then*/

    /** 	if local_change_protection_on_protected_memory( iaddr, size + memory:BORDER_SPACE * 2, true_protection ) = -1 then*/
    _442 = 0;
    _443 = _size_1107 + 0;
    _442 = NOVALUE;
    Ref(_iaddr_1104);
    _444 = _6local_change_protection_on_protected_memory(_iaddr_1104, _443, _true_protection_1111);
    _443 = NOVALUE;
    if (binary_op_a(NOTEQ, _444, -1)){
        DeRef(_444);
        _444 = NOVALUE;
        goto L8; // [208] 232
    }
    DeRef(_444);
    _444 = NOVALUE;

    /** 		local_free_protected_memory( iaddr, size + memory:BORDER_SPACE * 2 )*/
    _446 = 0;
    _447 = _size_1107 + 0;
    _446 = NOVALUE;
    Ref(_iaddr_1104);
    _6local_free_protected_memory(_iaddr_1104, _447);
    _447 = NOVALUE;

    /** 		eaddr = 0*/
    DeRef(_eaddr_1106);
    _eaddr_1106 = 0;
L8: 

    /** 	return eaddr*/
    DeRef(_iaddr_1104);
    DeRef(_436);
    _436 = NOVALUE;
    return _eaddr_1106;
    ;
}


int _6local_allocate_protected_memory(int _s_1154, int _first_protection_1155)
{
    int _453 = NOVALUE;
    int _452 = NOVALUE;
    int _451 = NOVALUE;
    int _450 = NOVALUE;
    int _449 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		if dep_works() then*/
    _449 = _8dep_works();
    if (_449 == 0) {
        DeRef(_449);
        _449 = NOVALUE;
        goto L1; // [12] 46
    }
    else {
        if (!IS_ATOM_INT(_449) && DBL_PTR(_449)->dbl == 0.0){
            DeRef(_449);
            _449 = NOVALUE;
            goto L1; // [12] 46
        }
        DeRef(_449);
        _449 = NOVALUE;
    }
    DeRef(_449);
    _449 = NOVALUE;

    /** 			return eu:c_func(VirtualAlloc_rid, */
    {unsigned long tu;
         tu = (unsigned long)8192 | (unsigned long)4096;
         _450 = MAKE_UINT(tu);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = _s_1154;
    *((int *)(_2+12)) = _450;
    *((int *)(_2+16)) = _first_protection_1155;
    _451 = MAKE_SEQ(_1);
    _450 = NOVALUE;
    _452 = call_c(1, _6VirtualAlloc_rid_981, _451);
    DeRefDS(_451);
    _451 = NOVALUE;
    return _452;
    goto L2; // [43] 61
L1: 

    /** 			return machine_func(M_ALLOC, PAGE_SIZE)*/
    _453 = machine(16, _6PAGE_SIZE_1061);
    DeRef(_452);
    _452 = NOVALUE;
    return _453;
L2: 
    ;
}


int _6local_change_protection_on_protected_memory(int _p_1169, int _s_1170, int _new_protection_1171)
{
    int _456 = NOVALUE;
    int _455 = NOVALUE;
    int _454 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		if dep_works() then*/
    _454 = _8dep_works();
    if (_454 == 0) {
        DeRef(_454);
        _454 = NOVALUE;
        goto L1; // [12] 45
    }
    else {
        if (!IS_ATOM_INT(_454) && DBL_PTR(_454)->dbl == 0.0){
            DeRef(_454);
            _454 = NOVALUE;
            goto L1; // [12] 45
        }
        DeRef(_454);
        _454 = NOVALUE;
    }
    DeRef(_454);
    _454 = NOVALUE;

    /** 			if eu:c_func( VirtualProtect_rid, { p, s, new_protection , oldprotptr } ) = 0 then*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_p_1169);
    *((int *)(_2+4)) = _p_1169;
    *((int *)(_2+8)) = _s_1170;
    *((int *)(_2+12)) = _new_protection_1171;
    Ref(_6oldprotptr_1150);
    *((int *)(_2+16)) = _6oldprotptr_1150;
    _455 = MAKE_SEQ(_1);
    _456 = call_c(1, _6VirtualProtect_rid_982, _455);
    DeRefDS(_455);
    _455 = NOVALUE;
    if (binary_op_a(NOTEQ, _456, 0)){
        DeRef(_456);
        _456 = NOVALUE;
        goto L2; // [33] 44
    }
    DeRef(_456);
    _456 = NOVALUE;

    /** 				return -1*/
    DeRef(_p_1169);
    return -1;
L2: 
L1: 

    /** 		return 0*/
    DeRef(_p_1169);
    return 0;
    ;
}


void _6local_free_protected_memory(int _p_1181, int _s_1182)
{
    int _462 = NOVALUE;
    int _461 = NOVALUE;
    int _460 = NOVALUE;
    int _459 = NOVALUE;
    int _458 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		if dep_works() then*/
    _458 = _8dep_works();
    if (_458 == 0) {
        DeRef(_458);
        _458 = NOVALUE;
        goto L1; // [10] 33
    }
    else {
        if (!IS_ATOM_INT(_458) && DBL_PTR(_458)->dbl == 0.0){
            DeRef(_458);
            _458 = NOVALUE;
            goto L1; // [10] 33
        }
        DeRef(_458);
        _458 = NOVALUE;
    }
    DeRef(_458);
    _458 = NOVALUE;

    /** 			c_func(VirtualFree_rid, { p, s, MEM_RELEASE })*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_p_1181);
    *((int *)(_2+4)) = _p_1181;
    *((int *)(_2+8)) = _s_1182;
    *((int *)(_2+12)) = 32768;
    _459 = MAKE_SEQ(_1);
    _460 = call_c(1, _8VirtualFree_rid_408, _459);
    DeRefDS(_459);
    _459 = NOVALUE;
    goto L2; // [30] 46
L1: 

    /** 			machine_func(M_FREE, {p})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_p_1181);
    *((int *)(_2+4)) = _p_1181;
    _461 = MAKE_SEQ(_1);
    _462 = machine(17, _461);
    DeRefDS(_461);
    _461 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_p_1181);
    DeRef(_460);
    _460 = NOVALUE;
    DeRef(_462);
    _462 = NOVALUE;
    return;
    ;
}


void _6free(int _addr_1196)
{
    int _msg_inlined_crash_at_27_1205 = NOVALUE;
    int _data_inlined_crash_at_24_1204 = NOVALUE;
    int _addr_inlined_deallocate_at_64_1211 = NOVALUE;
    int _msg_inlined_crash_at_106_1216 = NOVALUE;
    int _469 = NOVALUE;
    int _468 = NOVALUE;
    int _467 = NOVALUE;
    int _466 = NOVALUE;
    int _464 = NOVALUE;
    int _463 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if types:number_array (addr) then*/
    Ref(_addr_1196);
    _463 = _9number_array(_addr_1196);
    if (_463 == 0) {
        DeRef(_463);
        _463 = NOVALUE;
        goto L1; // [7] 97
    }
    else {
        if (!IS_ATOM_INT(_463) && DBL_PTR(_463)->dbl == 0.0){
            DeRef(_463);
            _463 = NOVALUE;
            goto L1; // [7] 97
        }
        DeRef(_463);
        _463 = NOVALUE;
    }
    DeRef(_463);
    _463 = NOVALUE;

    /** 		if types:ascii_string(addr) then*/
    Ref(_addr_1196);
    _464 = _9ascii_string(_addr_1196);
    if (_464 == 0) {
        DeRef(_464);
        _464 = NOVALUE;
        goto L2; // [16] 47
    }
    else {
        if (!IS_ATOM_INT(_464) && DBL_PTR(_464)->dbl == 0.0){
            DeRef(_464);
            _464 = NOVALUE;
            goto L2; // [16] 47
        }
        DeRef(_464);
        _464 = NOVALUE;
    }
    DeRef(_464);
    _464 = NOVALUE;

    /** 			error:crash("free(\"%s\") is not a valid address", {addr})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_addr_1196);
    *((int *)(_2+4)) = _addr_1196;
    _466 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_24_1204);
    _data_inlined_crash_at_24_1204 = _466;
    _466 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_27_1205);
    _msg_inlined_crash_at_27_1205 = EPrintf(-9999999, _465, _data_inlined_crash_at_24_1204);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_27_1205);

    /** end procedure*/
    goto L3; // [41] 44
L3: 
    DeRef(_data_inlined_crash_at_24_1204);
    _data_inlined_crash_at_24_1204 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_27_1205);
    _msg_inlined_crash_at_27_1205 = NOVALUE;
L2: 

    /** 		for i = 1 to length(addr) do*/
    if (IS_SEQUENCE(_addr_1196)){
            _467 = SEQ_PTR(_addr_1196)->length;
    }
    else {
        _467 = 1;
    }
    {
        int _i_1207;
        _i_1207 = 1;
L4: 
        if (_i_1207 > _467){
            goto L5; // [52] 89
        }

        /** 			memory:deallocate( addr[i] )*/
        _2 = (int)SEQ_PTR(_addr_1196);
        _468 = (int)*(((s1_ptr)_2)->base + _i_1207);
        Ref(_468);
        DeRef(_addr_inlined_deallocate_at_64_1211);
        _addr_inlined_deallocate_at_64_1211 = _468;
        _468 = NOVALUE;

        /** 	ifdef DATA_EXECUTE and WINDOWS then*/

        /**    	machine_proc( memconst:M_FREE, addr)*/
        machine(17, _addr_inlined_deallocate_at_64_1211);

        /** end procedure*/
        goto L6; // [77] 80
L6: 
        DeRef(_addr_inlined_deallocate_at_64_1211);
        _addr_inlined_deallocate_at_64_1211 = NOVALUE;

        /** 		end for*/
        _i_1207 = _i_1207 + 1;
        goto L4; // [84] 59
L5: 
        ;
    }

    /** 		return*/
    DeRef(_addr_1196);
    return;
    goto L7; // [94] 127
L1: 

    /** 	elsif sequence(addr) then*/
    _469 = IS_SEQUENCE(_addr_1196);
    if (_469 == 0)
    {
        _469 = NOVALUE;
        goto L8; // [102] 126
    }
    else{
        _469 = NOVALUE;
    }

    /** 		error:crash("free() called with nested sequence")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_106_1216);
    _msg_inlined_crash_at_106_1216 = EPrintf(-9999999, _470, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_106_1216);

    /** end procedure*/
    goto L9; // [120] 123
L9: 
    DeRefi(_msg_inlined_crash_at_106_1216);
    _msg_inlined_crash_at_106_1216 = NOVALUE;
L8: 
L7: 

    /** 	if addr = 0 then*/
    if (binary_op_a(NOTEQ, _addr_1196, 0)){
        goto LA; // [129] 139
    }

    /** 		return*/
    DeRef(_addr_1196);
    return;
LA: 

    /** 	memory:deallocate( addr )*/

    /** 	ifdef DATA_EXECUTE and WINDOWS then*/

    /**    	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _addr_1196);

    /** end procedure*/
    goto LB; // [150] 153
LB: 

    /** end procedure*/
    DeRef(_addr_1196);
    return;
    ;
}


void _6free_pointer_array(int _pointers_array_1224)
{
    int _saved_1225 = NOVALUE;
    int _ptr_1226 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom saved = pointers_array*/
    Ref(_pointers_array_1224);
    DeRef(_saved_1225);
    _saved_1225 = _pointers_array_1224;

    /** 	while ptr with entry do*/
    goto L1; // [8] 39
L2: 
    if (_ptr_1226 <= 0) {
        if (_ptr_1226 == 0) {
            goto L3; // [13] 49
        }
        else {
            if (!IS_ATOM_INT(_ptr_1226) && DBL_PTR(_ptr_1226)->dbl == 0.0){
                goto L3; // [13] 49
            }
        }
    }

    /** 		memory:deallocate( ptr )*/

    /** 	ifdef DATA_EXECUTE and WINDOWS then*/

    /**    	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _ptr_1226);

    /** end procedure*/
    goto L4; // [27] 30
L4: 

    /** 		pointers_array += ADDRESS_LENGTH*/
    _0 = _pointers_array_1224;
    if (IS_ATOM_INT(_pointers_array_1224)) {
        _pointers_array_1224 = _pointers_array_1224 + 4;
        if ((long)((unsigned long)_pointers_array_1224 + (unsigned long)HIGH_BITS) >= 0) 
        _pointers_array_1224 = NewDouble((double)_pointers_array_1224);
    }
    else {
        _pointers_array_1224 = NewDouble(DBL_PTR(_pointers_array_1224)->dbl + (double)4);
    }
    DeRef(_0);

    /** 	entry*/
L1: 

    /** 		ptr = peek4u(pointers_array)*/
    DeRef(_ptr_1226);
    if (IS_ATOM_INT(_pointers_array_1224)) {
        _ptr_1226 = *(unsigned long *)_pointers_array_1224;
        if ((unsigned)_ptr_1226 > (unsigned)MAXINT)
        _ptr_1226 = NewDouble((double)(unsigned long)_ptr_1226);
    }
    else {
        _ptr_1226 = *(unsigned long *)(unsigned long)(DBL_PTR(_pointers_array_1224)->dbl);
        if ((unsigned)_ptr_1226 > (unsigned)MAXINT)
        _ptr_1226 = NewDouble((double)(unsigned long)_ptr_1226);
    }

    /** 	end while*/
    goto L2; // [46] 11
L3: 

    /** 	free(saved)*/
    Ref(_saved_1225);
    _6free(_saved_1225);

    /** end procedure*/
    DeRef(_pointers_array_1224);
    DeRef(_saved_1225);
    DeRef(_ptr_1226);
    return;
    ;
}



// 0x3A84F3A8
