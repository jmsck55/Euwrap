// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _12sprint(int _x_9256)
{
    int _s_9257 = NOVALUE;
    int _5036 = NOVALUE;
    int _5034 = NOVALUE;
    int _5033 = NOVALUE;
    int _5030 = NOVALUE;
    int _5029 = NOVALUE;
    int _5027 = NOVALUE;
    int _5026 = NOVALUE;
    int _5025 = NOVALUE;
    int _5024 = NOVALUE;
    int _5023 = NOVALUE;
    int _5022 = NOVALUE;
    int _5021 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(x) then*/
    _5021 = IS_ATOM(_x_9256);
    if (_5021 == 0)
    {
        _5021 = NOVALUE;
        goto L1; // [6] 22
    }
    else{
        _5021 = NOVALUE;
    }

    /** 		return sprintf("%.10g", x)*/
    _5022 = EPrintf(-9999999, _738, _x_9256);
    DeRef(_x_9256);
    DeRef(_s_9257);
    return _5022;
    goto L2; // [19] 137
L1: 

    /** 		s = "{"*/
    RefDS(_1194);
    DeRef(_s_9257);
    _s_9257 = _1194;

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_9256)){
            _5023 = SEQ_PTR(_x_9256)->length;
    }
    else {
        _5023 = 1;
    }
    {
        int _i_9263;
        _i_9263 = 1;
L3: 
        if (_i_9263 > _5023){
            goto L4; // [34] 98
        }

        /** 			if atom(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_9256);
        _5024 = (int)*(((s1_ptr)_2)->base + _i_9263);
        _5025 = IS_ATOM(_5024);
        _5024 = NOVALUE;
        if (_5025 == 0)
        {
            _5025 = NOVALUE;
            goto L5; // [50] 70
        }
        else{
            _5025 = NOVALUE;
        }

        /** 				s &= sprintf("%.10g", x[i])*/
        _2 = (int)SEQ_PTR(_x_9256);
        _5026 = (int)*(((s1_ptr)_2)->base + _i_9263);
        _5027 = EPrintf(-9999999, _738, _5026);
        _5026 = NOVALUE;
        Concat((object_ptr)&_s_9257, _s_9257, _5027);
        DeRefDS(_5027);
        _5027 = NOVALUE;
        goto L6; // [67] 85
L5: 

        /** 				s &= sprint(x[i])*/
        _2 = (int)SEQ_PTR(_x_9256);
        _5029 = (int)*(((s1_ptr)_2)->base + _i_9263);
        Ref(_5029);
        _5030 = _12sprint(_5029);
        _5029 = NOVALUE;
        if (IS_SEQUENCE(_s_9257) && IS_ATOM(_5030)) {
            Ref(_5030);
            Append(&_s_9257, _s_9257, _5030);
        }
        else if (IS_ATOM(_s_9257) && IS_SEQUENCE(_5030)) {
        }
        else {
            Concat((object_ptr)&_s_9257, _s_9257, _5030);
        }
        DeRef(_5030);
        _5030 = NOVALUE;
L6: 

        /** 			s &= ','*/
        Append(&_s_9257, _s_9257, 44);

        /** 		end for*/
        _i_9263 = _i_9263 + 1;
        goto L3; // [93] 41
L4: 
        ;
    }

    /** 		if s[$] = ',' then*/
    if (IS_SEQUENCE(_s_9257)){
            _5033 = SEQ_PTR(_s_9257)->length;
    }
    else {
        _5033 = 1;
    }
    _2 = (int)SEQ_PTR(_s_9257);
    _5034 = (int)*(((s1_ptr)_2)->base + _5033);
    if (binary_op_a(NOTEQ, _5034, 44)){
        _5034 = NOVALUE;
        goto L7; // [107] 123
    }
    _5034 = NOVALUE;

    /** 			s[$] = '}'*/
    if (IS_SEQUENCE(_s_9257)){
            _5036 = SEQ_PTR(_s_9257)->length;
    }
    else {
        _5036 = 1;
    }
    _2 = (int)SEQ_PTR(_s_9257);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _s_9257 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _5036);
    _1 = *(int *)_2;
    *(int *)_2 = 125;
    DeRef(_1);
    goto L8; // [120] 130
L7: 

    /** 			s &= '}'*/
    Append(&_s_9257, _s_9257, 125);
L8: 

    /** 		return s*/
    DeRef(_x_9256);
    DeRef(_5022);
    _5022 = NOVALUE;
    return _s_9257;
L2: 
    ;
}


int _12trim(int _source_9326, int _what_9327, int _ret_index_9328)
{
    int _rpos_9329 = NOVALUE;
    int _lpos_9330 = NOVALUE;
    int _5077 = NOVALUE;
    int _5075 = NOVALUE;
    int _5073 = NOVALUE;
    int _5071 = NOVALUE;
    int _5068 = NOVALUE;
    int _5067 = NOVALUE;
    int _5062 = NOVALUE;
    int _5061 = NOVALUE;
    int _5059 = NOVALUE;
    int _5057 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(what) then*/
    _5057 = 0;
    if (_5057 == 0)
    {
        _5057 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _5057 = NOVALUE;
    }

    /** 		what = {what}*/
    _0 = _what_9327;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_what_9327);
    *((int *)(_2+4)) = _what_9327;
    _what_9327 = MAKE_SEQ(_1);
    DeRefDSi(_0);
L1: 

    /** 	lpos = 1*/
    _lpos_9330 = 1;

    /** 	while lpos <= length(source) do*/
L2: 
    if (IS_SEQUENCE(_source_9326)){
            _5059 = SEQ_PTR(_source_9326)->length;
    }
    else {
        _5059 = 1;
    }
    if (_lpos_9330 > _5059)
    goto L3; // [33] 67

    /** 		if not find(source[lpos], what) then*/
    _2 = (int)SEQ_PTR(_source_9326);
    _5061 = (int)*(((s1_ptr)_2)->base + _lpos_9330);
    _5062 = find_from(_5061, _what_9327, 1);
    _5061 = NOVALUE;
    if (_5062 != 0)
    goto L4; // [48] 56
    _5062 = NOVALUE;

    /** 			exit*/
    goto L3; // [53] 67
L4: 

    /** 		lpos += 1*/
    _lpos_9330 = _lpos_9330 + 1;

    /** 	end while*/
    goto L2; // [64] 30
L3: 

    /** 	rpos = length(source)*/
    if (IS_SEQUENCE(_source_9326)){
            _rpos_9329 = SEQ_PTR(_source_9326)->length;
    }
    else {
        _rpos_9329 = 1;
    }

    /** 	while rpos > lpos do*/
L5: 
    if (_rpos_9329 <= _lpos_9330)
    goto L6; // [77] 111

    /** 		if not find(source[rpos], what) then*/
    _2 = (int)SEQ_PTR(_source_9326);
    _5067 = (int)*(((s1_ptr)_2)->base + _rpos_9329);
    _5068 = find_from(_5067, _what_9327, 1);
    _5067 = NOVALUE;
    if (_5068 != 0)
    goto L7; // [92] 100
    _5068 = NOVALUE;

    /** 			exit*/
    goto L6; // [97] 111
L7: 

    /** 		rpos -= 1*/
    _rpos_9329 = _rpos_9329 - 1;

    /** 	end while*/
    goto L5; // [108] 77
L6: 

    /** 	if ret_index then*/
    if (_ret_index_9328 == 0)
    {
        goto L8; // [113] 129
    }
    else{
    }

    /** 		return {lpos, rpos}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _lpos_9330;
    ((int *)_2)[2] = _rpos_9329;
    _5071 = MAKE_SEQ(_1);
    DeRefDS(_source_9326);
    DeRef(_what_9327);
    return _5071;
    goto L9; // [126] 180
L8: 

    /** 		if lpos = 1 then*/
    if (_lpos_9330 != 1)
    goto LA; // [131] 152

    /** 			if rpos = length(source) then*/
    if (IS_SEQUENCE(_source_9326)){
            _5073 = SEQ_PTR(_source_9326)->length;
    }
    else {
        _5073 = 1;
    }
    if (_rpos_9329 != _5073)
    goto LB; // [140] 151

    /** 				return source*/
    DeRef(_what_9327);
    DeRef(_5071);
    _5071 = NOVALUE;
    return _source_9326;
LB: 
LA: 

    /** 		if lpos > length(source) then*/
    if (IS_SEQUENCE(_source_9326)){
            _5075 = SEQ_PTR(_source_9326)->length;
    }
    else {
        _5075 = 1;
    }
    if (_lpos_9330 <= _5075)
    goto LC; // [157] 168

    /** 			return {}*/
    RefDS(_5);
    DeRefDS(_source_9326);
    DeRef(_what_9327);
    DeRef(_5071);
    _5071 = NOVALUE;
    return _5;
LC: 

    /** 		return source[lpos..rpos]*/
    rhs_slice_target = (object_ptr)&_5077;
    RHS_Slice(_source_9326, _lpos_9330, _rpos_9329);
    DeRefDS(_source_9326);
    DeRef(_what_9327);
    DeRef(_5071);
    _5071 = NOVALUE;
    return _5077;
L9: 
    ;
}


int _12change_case(int _x_9539, int _api_9540)
{
    int _changed_text_9541 = NOVALUE;
    int _single_char_9542 = NOVALUE;
    int _len_9543 = NOVALUE;
    int _5206 = NOVALUE;
    int _5204 = NOVALUE;
    int _5202 = NOVALUE;
    int _5201 = NOVALUE;
    int _5198 = NOVALUE;
    int _5196 = NOVALUE;
    int _5194 = NOVALUE;
    int _5193 = NOVALUE;
    int _5192 = NOVALUE;
    int _5191 = NOVALUE;
    int _5190 = NOVALUE;
    int _5187 = NOVALUE;
    int _5185 = NOVALUE;
    int _0, _1, _2;
    

    /** 		integer single_char = 0*/
    _single_char_9542 = 0;

    /** 		if not string(x) then*/
    Ref(_x_9539);
    _5185 = _9string(_x_9539);
    if (IS_ATOM_INT(_5185)) {
        if (_5185 != 0){
            DeRef(_5185);
            _5185 = NOVALUE;
            goto L1; // [12] 95
        }
    }
    else {
        if (DBL_PTR(_5185)->dbl != 0.0){
            DeRef(_5185);
            _5185 = NOVALUE;
            goto L1; // [12] 95
        }
    }
    DeRef(_5185);
    _5185 = NOVALUE;

    /** 			if atom(x) then*/
    _5187 = IS_ATOM(_x_9539);
    if (_5187 == 0)
    {
        _5187 = NOVALUE;
        goto L2; // [20] 50
    }
    else{
        _5187 = NOVALUE;
    }

    /** 				if x = 0 then*/
    if (binary_op_a(NOTEQ, _x_9539, 0)){
        goto L3; // [25] 36
    }

    /** 					return 0*/
    DeRef(_x_9539);
    DeRef(_api_9540);
    DeRefi(_changed_text_9541);
    return 0;
L3: 

    /** 				x = {x}*/
    _0 = _x_9539;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_x_9539);
    *((int *)(_2+4)) = _x_9539;
    _x_9539 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 				single_char = 1*/
    _single_char_9542 = 1;
    goto L4; // [47] 94
L2: 

    /** 				for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_9539)){
            _5190 = SEQ_PTR(_x_9539)->length;
    }
    else {
        _5190 = 1;
    }
    {
        int _i_9555;
        _i_9555 = 1;
L5: 
        if (_i_9555 > _5190){
            goto L6; // [55] 87
        }

        /** 					x[i] = change_case(x[i], api)*/
        _2 = (int)SEQ_PTR(_x_9539);
        _5191 = (int)*(((s1_ptr)_2)->base + _i_9555);
        Ref(_api_9540);
        DeRef(_5192);
        _5192 = _api_9540;
        Ref(_5191);
        _5193 = _12change_case(_5191, _5192);
        _5191 = NOVALUE;
        _5192 = NOVALUE;
        _2 = (int)SEQ_PTR(_x_9539);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_9539 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_9555);
        _1 = *(int *)_2;
        *(int *)_2 = _5193;
        if( _1 != _5193 ){
            DeRef(_1);
        }
        _5193 = NOVALUE;

        /** 				end for*/
        _i_9555 = _i_9555 + 1;
        goto L5; // [82] 62
L6: 
        ;
    }

    /** 				return x*/
    DeRef(_api_9540);
    DeRefi(_changed_text_9541);
    return _x_9539;
L4: 
L1: 

    /** 		if length(x) = 0 then*/
    if (IS_SEQUENCE(_x_9539)){
            _5194 = SEQ_PTR(_x_9539)->length;
    }
    else {
        _5194 = 1;
    }
    if (_5194 != 0)
    goto L7; // [100] 111

    /** 			return x*/
    DeRef(_api_9540);
    DeRefi(_changed_text_9541);
    return _x_9539;
L7: 

    /** 		if length(x) >= tm_size then*/
    if (IS_SEQUENCE(_x_9539)){
            _5196 = SEQ_PTR(_x_9539)->length;
    }
    else {
        _5196 = 1;
    }
    if (_5196 < _12tm_size_9533)
    goto L8; // [118] 148

    /** 			tm_size = length(x) + 1*/
    if (IS_SEQUENCE(_x_9539)){
            _5198 = SEQ_PTR(_x_9539)->length;
    }
    else {
        _5198 = 1;
    }
    _12tm_size_9533 = _5198 + 1;
    _5198 = NOVALUE;

    /** 			free(temp_mem)*/
    Ref(_12temp_mem_9534);
    _6free(_12temp_mem_9534);

    /** 			temp_mem = allocate(tm_size)*/
    _0 = _6allocate(_12tm_size_9533, 0);
    DeRef(_12temp_mem_9534);
    _12temp_mem_9534 = _0;
L8: 

    /** 		poke(temp_mem, x)*/
    if (IS_ATOM_INT(_12temp_mem_9534)){
        poke_addr = (unsigned char *)_12temp_mem_9534;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_12temp_mem_9534)->dbl);
    }
    if (IS_ATOM_INT(_x_9539)) {
        *poke_addr = (unsigned char)_x_9539;
    }
    else if (IS_ATOM(_x_9539)) {
        *poke_addr = (signed char)DBL_PTR(_x_9539)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_x_9539);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }

    /** 		len = c_func(api, {temp_mem, length(x)} )*/
    if (IS_SEQUENCE(_x_9539)){
            _5201 = SEQ_PTR(_x_9539)->length;
    }
    else {
        _5201 = 1;
    }
    Ref(_12temp_mem_9534);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _12temp_mem_9534;
    ((int *)_2)[2] = _5201;
    _5202 = MAKE_SEQ(_1);
    _5201 = NOVALUE;
    _len_9543 = call_c(1, _api_9540, _5202);
    DeRefDS(_5202);
    _5202 = NOVALUE;
    if (!IS_ATOM_INT(_len_9543)) {
        _1 = (long)(DBL_PTR(_len_9543)->dbl);
        DeRefDS(_len_9543);
        _len_9543 = _1;
    }

    /** 		changed_text = peek({temp_mem, len})*/
    Ref(_12temp_mem_9534);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _12temp_mem_9534;
    ((int *)_2)[2] = _len_9543;
    _5204 = MAKE_SEQ(_1);
    DeRefi(_changed_text_9541);
    _1 = (int)SEQ_PTR(_5204);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _changed_text_9541 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_5204);
    _5204 = NOVALUE;

    /** 		if single_char then*/
    if (_single_char_9542 == 0)
    {
        goto L9; // [188] 204
    }
    else{
    }

    /** 			return changed_text[1]*/
    _2 = (int)SEQ_PTR(_changed_text_9541);
    _5206 = (int)*(((s1_ptr)_2)->base + 1);
    DeRef(_x_9539);
    DeRef(_api_9540);
    DeRefDSi(_changed_text_9541);
    return _5206;
    goto LA; // [201] 211
L9: 

    /** 			return changed_text*/
    DeRef(_x_9539);
    DeRef(_api_9540);
    _5206 = NOVALUE;
    return _changed_text_9541;
LA: 
    ;
}


int _12lower(int _x_9581)
{
    int _5210 = NOVALUE;
    int _5207 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(lower_case_SET) != 0 then*/
    _5207 = 0;

    /** 	ifdef WINDOWS then*/

    /** 		return change_case(x, api_CharLowerBuff)*/
    Ref(_x_9581);
    Ref(_12api_CharLowerBuff_9517);
    _5210 = _12change_case(_x_9581, _12api_CharLowerBuff_9517);
    DeRef(_x_9581);
    return _5210;
    ;
}


int _12upper(int _x_9589)
{
    int _5214 = NOVALUE;
    int _5211 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(upper_case_SET) != 0 then*/
    _5211 = 0;

    /** 	ifdef WINDOWS then*/

    /** 		return change_case(x, api_CharUpperBuff)*/
    Ref(_x_9589);
    Ref(_12api_CharUpperBuff_9525);
    _5214 = _12change_case(_x_9589, _12api_CharUpperBuff_9525);
    DeRef(_x_9589);
    return _5214;
    ;
}


int _12proper(int _x_9597)
{
    int _pos_9598 = NOVALUE;
    int _inword_9599 = NOVALUE;
    int _convert_9600 = NOVALUE;
    int _res_9601 = NOVALUE;
    int _5243 = NOVALUE;
    int _5242 = NOVALUE;
    int _5241 = NOVALUE;
    int _5240 = NOVALUE;
    int _5239 = NOVALUE;
    int _5238 = NOVALUE;
    int _5237 = NOVALUE;
    int _5236 = NOVALUE;
    int _5235 = NOVALUE;
    int _5234 = NOVALUE;
    int _5232 = NOVALUE;
    int _5231 = NOVALUE;
    int _5227 = NOVALUE;
    int _5224 = NOVALUE;
    int _5221 = NOVALUE;
    int _5218 = NOVALUE;
    int _5217 = NOVALUE;
    int _5216 = NOVALUE;
    int _5215 = NOVALUE;
    int _0, _1, _2;
    

    /** 	inword = 0	-- Initially not in a word*/
    _inword_9599 = 0;

    /** 	convert = 1	-- Initially convert text*/
    _convert_9600 = 1;

    /** 	res = x		-- Work on a copy of the original, in case we need to restore.*/
    RefDS(_x_9597);
    DeRef(_res_9601);
    _res_9601 = _x_9597;

    /** 	for i = 1 to length(res) do*/
    if (IS_SEQUENCE(_res_9601)){
            _5215 = SEQ_PTR(_res_9601)->length;
    }
    else {
        _5215 = 1;
    }
    {
        int _i_9603;
        _i_9603 = 1;
L1: 
        if (_i_9603 > _5215){
            goto L2; // [25] 298
        }

        /** 		if integer(res[i]) then*/
        _2 = (int)SEQ_PTR(_res_9601);
        _5216 = (int)*(((s1_ptr)_2)->base + _i_9603);
        if (IS_ATOM_INT(_5216))
        _5217 = 1;
        else if (IS_ATOM_DBL(_5216))
        _5217 = IS_ATOM_INT(DoubleToInt(_5216));
        else
        _5217 = 0;
        _5216 = NOVALUE;
        if (_5217 == 0)
        {
            _5217 = NOVALUE;
            goto L3; // [41] 209
        }
        else{
            _5217 = NOVALUE;
        }

        /** 			if convert then*/
        if (_convert_9600 == 0)
        {
            goto L4; // [46] 291
        }
        else{
        }

        /** 				pos = types:t_upper(res[i])*/
        _2 = (int)SEQ_PTR(_res_9601);
        _5218 = (int)*(((s1_ptr)_2)->base + _i_9603);
        Ref(_5218);
        _pos_9598 = _9t_upper(_5218);
        _5218 = NOVALUE;
        if (!IS_ATOM_INT(_pos_9598)) {
            _1 = (long)(DBL_PTR(_pos_9598)->dbl);
            DeRefDS(_pos_9598);
            _pos_9598 = _1;
        }

        /** 				if pos = 0 then*/
        if (_pos_9598 != 0)
        goto L5; // [63] 175

        /** 					pos = types:t_lower(res[i])*/
        _2 = (int)SEQ_PTR(_res_9601);
        _5221 = (int)*(((s1_ptr)_2)->base + _i_9603);
        Ref(_5221);
        _pos_9598 = _9t_lower(_5221);
        _5221 = NOVALUE;
        if (!IS_ATOM_INT(_pos_9598)) {
            _1 = (long)(DBL_PTR(_pos_9598)->dbl);
            DeRefDS(_pos_9598);
            _pos_9598 = _1;
        }

        /** 					if pos = 0 then*/
        if (_pos_9598 != 0)
        goto L6; // [81] 138

        /** 						pos = t_digit(res[i])*/
        _2 = (int)SEQ_PTR(_res_9601);
        _5224 = (int)*(((s1_ptr)_2)->base + _i_9603);
        Ref(_5224);
        _pos_9598 = _9t_digit(_5224);
        _5224 = NOVALUE;
        if (!IS_ATOM_INT(_pos_9598)) {
            _1 = (long)(DBL_PTR(_pos_9598)->dbl);
            DeRefDS(_pos_9598);
            _pos_9598 = _1;
        }

        /** 						if pos = 0 then*/
        if (_pos_9598 != 0)
        goto L4; // [99] 291

        /** 							pos = t_specword(res[i])*/
        _2 = (int)SEQ_PTR(_res_9601);
        _5227 = (int)*(((s1_ptr)_2)->base + _i_9603);
        Ref(_5227);
        _pos_9598 = _9t_specword(_5227);
        _5227 = NOVALUE;
        if (!IS_ATOM_INT(_pos_9598)) {
            _1 = (long)(DBL_PTR(_pos_9598)->dbl);
            DeRefDS(_pos_9598);
            _pos_9598 = _1;
        }

        /** 							if pos then*/
        if (_pos_9598 == 0)
        {
            goto L7; // [117] 128
        }
        else{
        }

        /** 								inword = 1*/
        _inword_9599 = 1;
        goto L4; // [125] 291
L7: 

        /** 								inword = 0*/
        _inword_9599 = 0;
        goto L4; // [135] 291
L6: 

        /** 						if inword = 0 then*/
        if (_inword_9599 != 0)
        goto L4; // [140] 291

        /** 							if pos <= 26 then*/
        if (_pos_9598 > 26)
        goto L8; // [146] 165

        /** 								res[i] = upper(res[i]) -- Convert to uppercase*/
        _2 = (int)SEQ_PTR(_res_9601);
        _5231 = (int)*(((s1_ptr)_2)->base + _i_9603);
        Ref(_5231);
        _5232 = _12upper(_5231);
        _5231 = NOVALUE;
        _2 = (int)SEQ_PTR(_res_9601);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _res_9601 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_9603);
        _1 = *(int *)_2;
        *(int *)_2 = _5232;
        if( _1 != _5232 ){
            DeRef(_1);
        }
        _5232 = NOVALUE;
L8: 

        /** 							inword = 1	-- now we are in a word*/
        _inword_9599 = 1;
        goto L4; // [172] 291
L5: 

        /** 					if inword = 1 then*/
        if (_inword_9599 != 1)
        goto L9; // [177] 198

        /** 						res[i] = lower(res[i]) -- Convert to lowercase*/
        _2 = (int)SEQ_PTR(_res_9601);
        _5234 = (int)*(((s1_ptr)_2)->base + _i_9603);
        Ref(_5234);
        _5235 = _12lower(_5234);
        _5234 = NOVALUE;
        _2 = (int)SEQ_PTR(_res_9601);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _res_9601 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_9603);
        _1 = *(int *)_2;
        *(int *)_2 = _5235;
        if( _1 != _5235 ){
            DeRef(_1);
        }
        _5235 = NOVALUE;
        goto L4; // [195] 291
L9: 

        /** 						inword = 1	-- now we are in a word*/
        _inword_9599 = 1;
        goto L4; // [206] 291
L3: 

        /** 			if convert then*/
        if (_convert_9600 == 0)
        {
            goto LA; // [211] 263
        }
        else{
        }

        /** 				for j = 1 to i-1 do*/
        _5236 = _i_9603 - 1;
        {
            int _j_9643;
            _j_9643 = 1;
LB: 
            if (_j_9643 > _5236){
                goto LC; // [220] 257
            }

            /** 					if atom(x[j]) then*/
            _2 = (int)SEQ_PTR(_x_9597);
            _5237 = (int)*(((s1_ptr)_2)->base + _j_9643);
            _5238 = IS_ATOM(_5237);
            _5237 = NOVALUE;
            if (_5238 == 0)
            {
                _5238 = NOVALUE;
                goto LD; // [236] 250
            }
            else{
                _5238 = NOVALUE;
            }

            /** 						res[j] = x[j]*/
            _2 = (int)SEQ_PTR(_x_9597);
            _5239 = (int)*(((s1_ptr)_2)->base + _j_9643);
            Ref(_5239);
            _2 = (int)SEQ_PTR(_res_9601);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _res_9601 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_9643);
            _1 = *(int *)_2;
            *(int *)_2 = _5239;
            if( _1 != _5239 ){
                DeRef(_1);
            }
            _5239 = NOVALUE;
LD: 

            /** 				end for*/
            _j_9643 = _j_9643 + 1;
            goto LB; // [252] 227
LC: 
            ;
        }

        /** 				convert = 0*/
        _convert_9600 = 0;
LA: 

        /** 			if sequence(res[i]) then*/
        _2 = (int)SEQ_PTR(_res_9601);
        _5240 = (int)*(((s1_ptr)_2)->base + _i_9603);
        _5241 = IS_SEQUENCE(_5240);
        _5240 = NOVALUE;
        if (_5241 == 0)
        {
            _5241 = NOVALUE;
            goto LE; // [272] 290
        }
        else{
            _5241 = NOVALUE;
        }

        /** 				res[i] = proper(res[i])	-- recursive conversion*/
        _2 = (int)SEQ_PTR(_res_9601);
        _5242 = (int)*(((s1_ptr)_2)->base + _i_9603);
        Ref(_5242);
        _5243 = _12proper(_5242);
        _5242 = NOVALUE;
        _2 = (int)SEQ_PTR(_res_9601);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _res_9601 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_9603);
        _1 = *(int *)_2;
        *(int *)_2 = _5243;
        if( _1 != _5243 ){
            DeRef(_1);
        }
        _5243 = NOVALUE;
LE: 
L4: 

        /** 	end for*/
        _i_9603 = _i_9603 + 1;
        goto L1; // [293] 32
L2: 
        ;
    }

    /** 	return res*/
    DeRefDS(_x_9597);
    DeRef(_5236);
    _5236 = NOVALUE;
    return _res_9601;
    ;
}


int _12quote(int _text_in_9919, int _quote_pair_9920, int _esc_9922, int _sp_9924)
{
    int _5514 = NOVALUE;
    int _5513 = NOVALUE;
    int _5512 = NOVALUE;
    int _5510 = NOVALUE;
    int _5509 = NOVALUE;
    int _5508 = NOVALUE;
    int _5506 = NOVALUE;
    int _5505 = NOVALUE;
    int _5504 = NOVALUE;
    int _5503 = NOVALUE;
    int _5502 = NOVALUE;
    int _5501 = NOVALUE;
    int _5500 = NOVALUE;
    int _5499 = NOVALUE;
    int _5498 = NOVALUE;
    int _5496 = NOVALUE;
    int _5495 = NOVALUE;
    int _5494 = NOVALUE;
    int _5492 = NOVALUE;
    int _5491 = NOVALUE;
    int _5490 = NOVALUE;
    int _5489 = NOVALUE;
    int _5488 = NOVALUE;
    int _5487 = NOVALUE;
    int _5486 = NOVALUE;
    int _5485 = NOVALUE;
    int _5484 = NOVALUE;
    int _5482 = NOVALUE;
    int _5481 = NOVALUE;
    int _5479 = NOVALUE;
    int _5478 = NOVALUE;
    int _5477 = NOVALUE;
    int _5475 = NOVALUE;
    int _5474 = NOVALUE;
    int _5473 = NOVALUE;
    int _5472 = NOVALUE;
    int _5471 = NOVALUE;
    int _5470 = NOVALUE;
    int _5469 = NOVALUE;
    int _5468 = NOVALUE;
    int _5467 = NOVALUE;
    int _5466 = NOVALUE;
    int _5465 = NOVALUE;
    int _5464 = NOVALUE;
    int _5463 = NOVALUE;
    int _5462 = NOVALUE;
    int _5461 = NOVALUE;
    int _5460 = NOVALUE;
    int _5459 = NOVALUE;
    int _5456 = NOVALUE;
    int _5455 = NOVALUE;
    int _5454 = NOVALUE;
    int _5453 = NOVALUE;
    int _5452 = NOVALUE;
    int _5451 = NOVALUE;
    int _5450 = NOVALUE;
    int _5449 = NOVALUE;
    int _5448 = NOVALUE;
    int _5447 = NOVALUE;
    int _5446 = NOVALUE;
    int _5445 = NOVALUE;
    int _5444 = NOVALUE;
    int _5443 = NOVALUE;
    int _5440 = NOVALUE;
    int _5438 = NOVALUE;
    int _5437 = NOVALUE;
    int _5435 = NOVALUE;
    int _5433 = NOVALUE;
    int _5432 = NOVALUE;
    int _5431 = NOVALUE;
    int _5429 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(text_in) = 0 then*/
    if (IS_SEQUENCE(_text_in_9919)){
            _5429 = SEQ_PTR(_text_in_9919)->length;
    }
    else {
        _5429 = 1;
    }
    if (_5429 != 0)
    goto L1; // [10] 21

    /** 		return text_in*/
    DeRef(_quote_pair_9920);
    DeRef(_sp_9924);
    return _text_in_9919;
L1: 

    /** 	if atom(quote_pair) then*/
    _5431 = IS_ATOM(_quote_pair_9920);
    if (_5431 == 0)
    {
        _5431 = NOVALUE;
        goto L2; // [26] 46
    }
    else{
        _5431 = NOVALUE;
    }

    /** 		quote_pair = {{quote_pair}, {quote_pair}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_quote_pair_9920);
    *((int *)(_2+4)) = _quote_pair_9920;
    _5432 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_quote_pair_9920);
    *((int *)(_2+4)) = _quote_pair_9920;
    _5433 = MAKE_SEQ(_1);
    DeRef(_quote_pair_9920);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5432;
    ((int *)_2)[2] = _5433;
    _quote_pair_9920 = MAKE_SEQ(_1);
    _5433 = NOVALUE;
    _5432 = NOVALUE;
    goto L3; // [43] 89
L2: 

    /** 	elsif length(quote_pair) = 1 then*/
    if (IS_SEQUENCE(_quote_pair_9920)){
            _5435 = SEQ_PTR(_quote_pair_9920)->length;
    }
    else {
        _5435 = 1;
    }
    if (_5435 != 1)
    goto L4; // [51] 72

    /** 		quote_pair = {quote_pair[1], quote_pair[1]}*/
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5437 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5438 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_5438);
    Ref(_5437);
    DeRef(_quote_pair_9920);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5437;
    ((int *)_2)[2] = _5438;
    _quote_pair_9920 = MAKE_SEQ(_1);
    _5438 = NOVALUE;
    _5437 = NOVALUE;
    goto L3; // [69] 89
L4: 

    /** 	elsif length(quote_pair) = 0 then*/
    if (IS_SEQUENCE(_quote_pair_9920)){
            _5440 = SEQ_PTR(_quote_pair_9920)->length;
    }
    else {
        _5440 = 1;
    }
    if (_5440 != 0)
    goto L5; // [77] 88

    /** 		quote_pair = {"\"", "\""}*/
    RefDS(_5421);
    RefDS(_5421);
    DeRef(_quote_pair_9920);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5421;
    ((int *)_2)[2] = _5421;
    _quote_pair_9920 = MAKE_SEQ(_1);
L5: 
L3: 

    /** 	if sequence(text_in[1]) then*/
    _2 = (int)SEQ_PTR(_text_in_9919);
    _5443 = (int)*(((s1_ptr)_2)->base + 1);
    _5444 = IS_SEQUENCE(_5443);
    _5443 = NOVALUE;
    if (_5444 == 0)
    {
        _5444 = NOVALUE;
        goto L6; // [98] 166
    }
    else{
        _5444 = NOVALUE;
    }

    /** 		for i = 1 to length(text_in) do*/
    if (IS_SEQUENCE(_text_in_9919)){
            _5445 = SEQ_PTR(_text_in_9919)->length;
    }
    else {
        _5445 = 1;
    }
    {
        int _i_9947;
        _i_9947 = 1;
L7: 
        if (_i_9947 > _5445){
            goto L8; // [106] 159
        }

        /** 			if sequence(text_in[i]) then*/
        _2 = (int)SEQ_PTR(_text_in_9919);
        _5446 = (int)*(((s1_ptr)_2)->base + _i_9947);
        _5447 = IS_SEQUENCE(_5446);
        _5446 = NOVALUE;
        if (_5447 == 0)
        {
            _5447 = NOVALUE;
            goto L9; // [122] 152
        }
        else{
            _5447 = NOVALUE;
        }

        /** 				text_in[i] = quote(text_in[i], quote_pair, esc, sp)*/
        _2 = (int)SEQ_PTR(_text_in_9919);
        _5448 = (int)*(((s1_ptr)_2)->base + _i_9947);
        Ref(_quote_pair_9920);
        DeRef(_5449);
        _5449 = _quote_pair_9920;
        DeRef(_5450);
        _5450 = _esc_9922;
        Ref(_sp_9924);
        DeRef(_5451);
        _5451 = _sp_9924;
        Ref(_5448);
        _5452 = _12quote(_5448, _5449, _5450, _5451);
        _5448 = NOVALUE;
        _5449 = NOVALUE;
        _5450 = NOVALUE;
        _5451 = NOVALUE;
        _2 = (int)SEQ_PTR(_text_in_9919);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _text_in_9919 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_9947);
        _1 = *(int *)_2;
        *(int *)_2 = _5452;
        if( _1 != _5452 ){
            DeRef(_1);
        }
        _5452 = NOVALUE;
L9: 

        /** 		end for*/
        _i_9947 = _i_9947 + 1;
        goto L7; // [154] 113
L8: 
        ;
    }

    /** 		return text_in*/
    DeRef(_quote_pair_9920);
    DeRef(_sp_9924);
    return _text_in_9919;
L6: 

    /** 	for i = 1 to length(sp) do*/
    if (IS_SEQUENCE(_sp_9924)){
            _5453 = SEQ_PTR(_sp_9924)->length;
    }
    else {
        _5453 = 1;
    }
    {
        int _i_9958;
        _i_9958 = 1;
LA: 
        if (_i_9958 > _5453){
            goto LB; // [171] 220
        }

        /** 		if find(sp[i], text_in) then*/
        _2 = (int)SEQ_PTR(_sp_9924);
        _5454 = (int)*(((s1_ptr)_2)->base + _i_9958);
        _5455 = find_from(_5454, _text_in_9919, 1);
        _5454 = NOVALUE;
        if (_5455 == 0)
        {
            _5455 = NOVALUE;
            goto LC; // [189] 197
        }
        else{
            _5455 = NOVALUE;
        }

        /** 			exit*/
        goto LB; // [194] 220
LC: 

        /** 		if i = length(sp) then*/
        if (IS_SEQUENCE(_sp_9924)){
                _5456 = SEQ_PTR(_sp_9924)->length;
        }
        else {
            _5456 = 1;
        }
        if (_i_9958 != _5456)
        goto LD; // [202] 213

        /** 			return text_in*/
        DeRef(_quote_pair_9920);
        DeRef(_sp_9924);
        return _text_in_9919;
LD: 

        /** 	end for*/
        _i_9958 = _i_9958 + 1;
        goto LA; // [215] 178
LB: 
        ;
    }

    /** 	if esc >= 0  then*/
    if (_esc_9922 < 0)
    goto LE; // [222] 561

    /** 		if atom(quote_pair[1]) then*/
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5459 = (int)*(((s1_ptr)_2)->base + 1);
    _5460 = IS_ATOM(_5459);
    _5459 = NOVALUE;
    if (_5460 == 0)
    {
        _5460 = NOVALUE;
        goto LF; // [235] 253
    }
    else{
        _5460 = NOVALUE;
    }

    /** 			quote_pair[1] = {quote_pair[1]}*/
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5461 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_5461);
    *((int *)(_2+4)) = _5461;
    _5462 = MAKE_SEQ(_1);
    _5461 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _quote_pair_9920 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _5462;
    if( _1 != _5462 ){
        DeRef(_1);
    }
    _5462 = NOVALUE;
LF: 

    /** 		if atom(quote_pair[2]) then*/
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5463 = (int)*(((s1_ptr)_2)->base + 2);
    _5464 = IS_ATOM(_5463);
    _5463 = NOVALUE;
    if (_5464 == 0)
    {
        _5464 = NOVALUE;
        goto L10; // [262] 280
    }
    else{
        _5464 = NOVALUE;
    }

    /** 			quote_pair[2] = {quote_pair[2]}*/
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5465 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_5465);
    *((int *)(_2+4)) = _5465;
    _5466 = MAKE_SEQ(_1);
    _5465 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _quote_pair_9920 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5466;
    if( _1 != _5466 ){
        DeRef(_1);
    }
    _5466 = NOVALUE;
L10: 

    /** 		if equal(quote_pair[1], quote_pair[2]) then*/
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5467 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5468 = (int)*(((s1_ptr)_2)->base + 2);
    if (_5467 == _5468)
    _5469 = 1;
    else if (IS_ATOM_INT(_5467) && IS_ATOM_INT(_5468))
    _5469 = 0;
    else
    _5469 = (compare(_5467, _5468) == 0);
    _5467 = NOVALUE;
    _5468 = NOVALUE;
    if (_5469 == 0)
    {
        _5469 = NOVALUE;
        goto L11; // [294] 372
    }
    else{
        _5469 = NOVALUE;
    }

    /** 			if match(quote_pair[1], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5470 = (int)*(((s1_ptr)_2)->base + 1);
    _5471 = e_match_from(_5470, _text_in_9919, 1);
    _5470 = NOVALUE;
    if (_5471 == 0)
    {
        _5471 = NOVALUE;
        goto L12; // [308] 560
    }
    else{
        _5471 = NOVALUE;
    }

    /** 				if match(esc & quote_pair[1], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5472 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_9922) && IS_ATOM(_5472)) {
    }
    else if (IS_ATOM(_esc_9922) && IS_SEQUENCE(_5472)) {
        Prepend(&_5473, _5472, _esc_9922);
    }
    else {
        Concat((object_ptr)&_5473, _esc_9922, _5472);
    }
    _5472 = NOVALUE;
    _5474 = e_match_from(_5473, _text_in_9919, 1);
    DeRefDS(_5473);
    _5473 = NOVALUE;
    if (_5474 == 0)
    {
        _5474 = NOVALUE;
        goto L13; // [326] 345
    }
    else{
        _5474 = NOVALUE;
    }

    /** 					text_in = search:match_replace(esc, text_in, esc & esc)*/
    Concat((object_ptr)&_5475, _esc_9922, _esc_9922);
    RefDS(_text_in_9919);
    _0 = _text_in_9919;
    _text_in_9919 = _14match_replace(_esc_9922, _text_in_9919, _5475, 0);
    DeRefDS(_0);
    _5475 = NOVALUE;
L13: 

    /** 				text_in = search:match_replace(quote_pair[1], text_in, esc & quote_pair[1])*/
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5477 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5478 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_9922) && IS_ATOM(_5478)) {
    }
    else if (IS_ATOM(_esc_9922) && IS_SEQUENCE(_5478)) {
        Prepend(&_5479, _5478, _esc_9922);
    }
    else {
        Concat((object_ptr)&_5479, _esc_9922, _5478);
    }
    _5478 = NOVALUE;
    Ref(_5477);
    RefDS(_text_in_9919);
    _0 = _text_in_9919;
    _text_in_9919 = _14match_replace(_5477, _text_in_9919, _5479, 0);
    DeRefDS(_0);
    _5477 = NOVALUE;
    _5479 = NOVALUE;
    goto L12; // [369] 560
L11: 

    /** 			if match(quote_pair[1], text_in) or*/
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5481 = (int)*(((s1_ptr)_2)->base + 1);
    _5482 = e_match_from(_5481, _text_in_9919, 1);
    _5481 = NOVALUE;
    if (_5482 != 0) {
        goto L14; // [383] 401
    }
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5484 = (int)*(((s1_ptr)_2)->base + 2);
    _5485 = e_match_from(_5484, _text_in_9919, 1);
    _5484 = NOVALUE;
    if (_5485 == 0)
    {
        _5485 = NOVALUE;
        goto L15; // [397] 473
    }
    else{
        _5485 = NOVALUE;
    }
L14: 

    /** 				if match(esc & quote_pair[1], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5486 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_9922) && IS_ATOM(_5486)) {
    }
    else if (IS_ATOM(_esc_9922) && IS_SEQUENCE(_5486)) {
        Prepend(&_5487, _5486, _esc_9922);
    }
    else {
        Concat((object_ptr)&_5487, _esc_9922, _5486);
    }
    _5486 = NOVALUE;
    _5488 = e_match_from(_5487, _text_in_9919, 1);
    DeRefDS(_5487);
    _5487 = NOVALUE;
    if (_5488 == 0)
    {
        _5488 = NOVALUE;
        goto L16; // [416] 449
    }
    else{
        _5488 = NOVALUE;
    }

    /** 					text_in = search:match_replace(esc & quote_pair[1], text_in, esc & esc & quote_pair[1])*/
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5489 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_9922) && IS_ATOM(_5489)) {
    }
    else if (IS_ATOM(_esc_9922) && IS_SEQUENCE(_5489)) {
        Prepend(&_5490, _5489, _esc_9922);
    }
    else {
        Concat((object_ptr)&_5490, _esc_9922, _5489);
    }
    _5489 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5491 = (int)*(((s1_ptr)_2)->base + 1);
    {
        int concat_list[3];

        concat_list[0] = _5491;
        concat_list[1] = _esc_9922;
        concat_list[2] = _esc_9922;
        Concat_N((object_ptr)&_5492, concat_list, 3);
    }
    _5491 = NOVALUE;
    RefDS(_text_in_9919);
    _0 = _text_in_9919;
    _text_in_9919 = _14match_replace(_5490, _text_in_9919, _5492, 0);
    DeRefDS(_0);
    _5490 = NOVALUE;
    _5492 = NOVALUE;
L16: 

    /** 				text_in = match_replace(quote_pair[1], text_in, esc & quote_pair[1])*/
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5494 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5495 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_9922) && IS_ATOM(_5495)) {
    }
    else if (IS_ATOM(_esc_9922) && IS_SEQUENCE(_5495)) {
        Prepend(&_5496, _5495, _esc_9922);
    }
    else {
        Concat((object_ptr)&_5496, _esc_9922, _5495);
    }
    _5495 = NOVALUE;
    Ref(_5494);
    RefDS(_text_in_9919);
    _0 = _text_in_9919;
    _text_in_9919 = _14match_replace(_5494, _text_in_9919, _5496, 0);
    DeRefDS(_0);
    _5494 = NOVALUE;
    _5496 = NOVALUE;
L15: 

    /** 			if match(quote_pair[2], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5498 = (int)*(((s1_ptr)_2)->base + 2);
    _5499 = e_match_from(_5498, _text_in_9919, 1);
    _5498 = NOVALUE;
    if (_5499 == 0)
    {
        _5499 = NOVALUE;
        goto L17; // [484] 559
    }
    else{
        _5499 = NOVALUE;
    }

    /** 				if match(esc & quote_pair[2], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5500 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_9922) && IS_ATOM(_5500)) {
    }
    else if (IS_ATOM(_esc_9922) && IS_SEQUENCE(_5500)) {
        Prepend(&_5501, _5500, _esc_9922);
    }
    else {
        Concat((object_ptr)&_5501, _esc_9922, _5500);
    }
    _5500 = NOVALUE;
    _5502 = e_match_from(_5501, _text_in_9919, 1);
    DeRefDS(_5501);
    _5501 = NOVALUE;
    if (_5502 == 0)
    {
        _5502 = NOVALUE;
        goto L18; // [502] 535
    }
    else{
        _5502 = NOVALUE;
    }

    /** 					text_in = search:match_replace(esc & quote_pair[2], text_in, esc & esc & quote_pair[2])*/
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5503 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_9922) && IS_ATOM(_5503)) {
    }
    else if (IS_ATOM(_esc_9922) && IS_SEQUENCE(_5503)) {
        Prepend(&_5504, _5503, _esc_9922);
    }
    else {
        Concat((object_ptr)&_5504, _esc_9922, _5503);
    }
    _5503 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5505 = (int)*(((s1_ptr)_2)->base + 2);
    {
        int concat_list[3];

        concat_list[0] = _5505;
        concat_list[1] = _esc_9922;
        concat_list[2] = _esc_9922;
        Concat_N((object_ptr)&_5506, concat_list, 3);
    }
    _5505 = NOVALUE;
    RefDS(_text_in_9919);
    _0 = _text_in_9919;
    _text_in_9919 = _14match_replace(_5504, _text_in_9919, _5506, 0);
    DeRefDS(_0);
    _5504 = NOVALUE;
    _5506 = NOVALUE;
L18: 

    /** 				text_in = search:match_replace(quote_pair[2], text_in, esc & quote_pair[2])*/
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5508 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5509 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_9922) && IS_ATOM(_5509)) {
    }
    else if (IS_ATOM(_esc_9922) && IS_SEQUENCE(_5509)) {
        Prepend(&_5510, _5509, _esc_9922);
    }
    else {
        Concat((object_ptr)&_5510, _esc_9922, _5509);
    }
    _5509 = NOVALUE;
    Ref(_5508);
    RefDS(_text_in_9919);
    _0 = _text_in_9919;
    _text_in_9919 = _14match_replace(_5508, _text_in_9919, _5510, 0);
    DeRefDS(_0);
    _5508 = NOVALUE;
    _5510 = NOVALUE;
L17: 
L12: 
LE: 

    /** 	return quote_pair[1] & text_in & quote_pair[2]*/
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5512 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_9920);
    _5513 = (int)*(((s1_ptr)_2)->base + 2);
    {
        int concat_list[3];

        concat_list[0] = _5513;
        concat_list[1] = _text_in_9919;
        concat_list[2] = _5512;
        Concat_N((object_ptr)&_5514, concat_list, 3);
    }
    _5513 = NOVALUE;
    _5512 = NOVALUE;
    DeRefDS(_text_in_9919);
    DeRef(_quote_pair_9920);
    DeRef(_sp_9924);
    return _5514;
    ;
}


int _12format(int _format_pattern_10140, int _arg_list_10141)
{
    int _result_10142 = NOVALUE;
    int _in_token_10143 = NOVALUE;
    int _tch_10144 = NOVALUE;
    int _i_10145 = NOVALUE;
    int _tend_10146 = NOVALUE;
    int _cap_10147 = NOVALUE;
    int _align_10148 = NOVALUE;
    int _psign_10149 = NOVALUE;
    int _msign_10150 = NOVALUE;
    int _zfill_10151 = NOVALUE;
    int _bwz_10152 = NOVALUE;
    int _spacer_10153 = NOVALUE;
    int _alt_10154 = NOVALUE;
    int _width_10155 = NOVALUE;
    int _decs_10156 = NOVALUE;
    int _pos_10157 = NOVALUE;
    int _argn_10158 = NOVALUE;
    int _argl_10159 = NOVALUE;
    int _trimming_10160 = NOVALUE;
    int _hexout_10161 = NOVALUE;
    int _binout_10162 = NOVALUE;
    int _tsep_10163 = NOVALUE;
    int _istext_10164 = NOVALUE;
    int _prevargv_10165 = NOVALUE;
    int _currargv_10166 = NOVALUE;
    int _idname_10167 = NOVALUE;
    int _envsym_10168 = NOVALUE;
    int _envvar_10169 = NOVALUE;
    int _ep_10170 = NOVALUE;
    int _sp_10241 = NOVALUE;
    int _sp_10276 = NOVALUE;
    int _argtext_10323 = NOVALUE;
    int _tempv_10546 = NOVALUE;
    int _pretty_sprint_inlined_pretty_sprint_at_2427_10601 = NOVALUE;
    int _options_inlined_pretty_sprint_at_2424_10600 = NOVALUE;
    int _pretty_sprint_inlined_pretty_sprint_at_2483_10608 = NOVALUE;
    int _options_inlined_pretty_sprint_at_2480_10607 = NOVALUE;
    int _x_inlined_pretty_sprint_at_2477_10606 = NOVALUE;
    int _msg_inlined_crash_at_2631_10630 = NOVALUE;
    int _dpos_10673 = NOVALUE;
    int _dist_10674 = NOVALUE;
    int _bracketed_10675 = NOVALUE;
    int _6003 = NOVALUE;
    int _6002 = NOVALUE;
    int _6001 = NOVALUE;
    int _5999 = NOVALUE;
    int _5998 = NOVALUE;
    int _5997 = NOVALUE;
    int _5994 = NOVALUE;
    int _5993 = NOVALUE;
    int _5990 = NOVALUE;
    int _5988 = NOVALUE;
    int _5985 = NOVALUE;
    int _5984 = NOVALUE;
    int _5983 = NOVALUE;
    int _5980 = NOVALUE;
    int _5977 = NOVALUE;
    int _5976 = NOVALUE;
    int _5975 = NOVALUE;
    int _5974 = NOVALUE;
    int _5971 = NOVALUE;
    int _5970 = NOVALUE;
    int _5969 = NOVALUE;
    int _5966 = NOVALUE;
    int _5964 = NOVALUE;
    int _5961 = NOVALUE;
    int _5960 = NOVALUE;
    int _5959 = NOVALUE;
    int _5958 = NOVALUE;
    int _5955 = NOVALUE;
    int _5950 = NOVALUE;
    int _5949 = NOVALUE;
    int _5948 = NOVALUE;
    int _5947 = NOVALUE;
    int _5941 = NOVALUE;
    int _5937 = NOVALUE;
    int _5936 = NOVALUE;
    int _5934 = NOVALUE;
    int _5932 = NOVALUE;
    int _5931 = NOVALUE;
    int _5930 = NOVALUE;
    int _5929 = NOVALUE;
    int _5928 = NOVALUE;
    int _5925 = NOVALUE;
    int _5922 = NOVALUE;
    int _5921 = NOVALUE;
    int _5918 = NOVALUE;
    int _5917 = NOVALUE;
    int _5916 = NOVALUE;
    int _5913 = NOVALUE;
    int _5911 = NOVALUE;
    int _5906 = NOVALUE;
    int _5905 = NOVALUE;
    int _5897 = NOVALUE;
    int _5893 = NOVALUE;
    int _5891 = NOVALUE;
    int _5890 = NOVALUE;
    int _5889 = NOVALUE;
    int _5886 = NOVALUE;
    int _5884 = NOVALUE;
    int _5883 = NOVALUE;
    int _5882 = NOVALUE;
    int _5880 = NOVALUE;
    int _5879 = NOVALUE;
    int _5878 = NOVALUE;
    int _5877 = NOVALUE;
    int _5874 = NOVALUE;
    int _5873 = NOVALUE;
    int _5872 = NOVALUE;
    int _5870 = NOVALUE;
    int _5869 = NOVALUE;
    int _5868 = NOVALUE;
    int _5867 = NOVALUE;
    int _5865 = NOVALUE;
    int _5863 = NOVALUE;
    int _5861 = NOVALUE;
    int _5859 = NOVALUE;
    int _5857 = NOVALUE;
    int _5855 = NOVALUE;
    int _5854 = NOVALUE;
    int _5853 = NOVALUE;
    int _5852 = NOVALUE;
    int _5851 = NOVALUE;
    int _5850 = NOVALUE;
    int _5848 = NOVALUE;
    int _5847 = NOVALUE;
    int _5845 = NOVALUE;
    int _5844 = NOVALUE;
    int _5842 = NOVALUE;
    int _5840 = NOVALUE;
    int _5839 = NOVALUE;
    int _5836 = NOVALUE;
    int _5834 = NOVALUE;
    int _5830 = NOVALUE;
    int _5828 = NOVALUE;
    int _5827 = NOVALUE;
    int _5826 = NOVALUE;
    int _5824 = NOVALUE;
    int _5823 = NOVALUE;
    int _5822 = NOVALUE;
    int _5821 = NOVALUE;
    int _5820 = NOVALUE;
    int _5818 = NOVALUE;
    int _5816 = NOVALUE;
    int _5815 = NOVALUE;
    int _5814 = NOVALUE;
    int _5813 = NOVALUE;
    int _5809 = NOVALUE;
    int _5806 = NOVALUE;
    int _5805 = NOVALUE;
    int _5802 = NOVALUE;
    int _5801 = NOVALUE;
    int _5800 = NOVALUE;
    int _5798 = NOVALUE;
    int _5797 = NOVALUE;
    int _5796 = NOVALUE;
    int _5795 = NOVALUE;
    int _5793 = NOVALUE;
    int _5791 = NOVALUE;
    int _5790 = NOVALUE;
    int _5789 = NOVALUE;
    int _5788 = NOVALUE;
    int _5787 = NOVALUE;
    int _5786 = NOVALUE;
    int _5784 = NOVALUE;
    int _5783 = NOVALUE;
    int _5782 = NOVALUE;
    int _5780 = NOVALUE;
    int _5779 = NOVALUE;
    int _5778 = NOVALUE;
    int _5777 = NOVALUE;
    int _5775 = NOVALUE;
    int _5772 = NOVALUE;
    int _5771 = NOVALUE;
    int _5769 = NOVALUE;
    int _5768 = NOVALUE;
    int _5766 = NOVALUE;
    int _5763 = NOVALUE;
    int _5762 = NOVALUE;
    int _5759 = NOVALUE;
    int _5757 = NOVALUE;
    int _5753 = NOVALUE;
    int _5751 = NOVALUE;
    int _5750 = NOVALUE;
    int _5749 = NOVALUE;
    int _5747 = NOVALUE;
    int _5745 = NOVALUE;
    int _5744 = NOVALUE;
    int _5743 = NOVALUE;
    int _5742 = NOVALUE;
    int _5741 = NOVALUE;
    int _5739 = NOVALUE;
    int _5737 = NOVALUE;
    int _5736 = NOVALUE;
    int _5735 = NOVALUE;
    int _5734 = NOVALUE;
    int _5732 = NOVALUE;
    int _5729 = NOVALUE;
    int _5727 = NOVALUE;
    int _5726 = NOVALUE;
    int _5724 = NOVALUE;
    int _5723 = NOVALUE;
    int _5722 = NOVALUE;
    int _5719 = NOVALUE;
    int _5718 = NOVALUE;
    int _5717 = NOVALUE;
    int _5716 = NOVALUE;
    int _5714 = NOVALUE;
    int _5713 = NOVALUE;
    int _5712 = NOVALUE;
    int _5711 = NOVALUE;
    int _5710 = NOVALUE;
    int _5707 = NOVALUE;
    int _5706 = NOVALUE;
    int _5705 = NOVALUE;
    int _5704 = NOVALUE;
    int _5702 = NOVALUE;
    int _5701 = NOVALUE;
    int _5700 = NOVALUE;
    int _5698 = NOVALUE;
    int _5697 = NOVALUE;
    int _5696 = NOVALUE;
    int _5694 = NOVALUE;
    int _5687 = NOVALUE;
    int _5685 = NOVALUE;
    int _5684 = NOVALUE;
    int _5677 = NOVALUE;
    int _5674 = NOVALUE;
    int _5670 = NOVALUE;
    int _5668 = NOVALUE;
    int _5667 = NOVALUE;
    int _5664 = NOVALUE;
    int _5662 = NOVALUE;
    int _5660 = NOVALUE;
    int _5657 = NOVALUE;
    int _5655 = NOVALUE;
    int _5654 = NOVALUE;
    int _5653 = NOVALUE;
    int _5652 = NOVALUE;
    int _5651 = NOVALUE;
    int _5648 = NOVALUE;
    int _5646 = NOVALUE;
    int _5645 = NOVALUE;
    int _5644 = NOVALUE;
    int _5641 = NOVALUE;
    int _5639 = NOVALUE;
    int _5637 = NOVALUE;
    int _5634 = NOVALUE;
    int _5633 = NOVALUE;
    int _5626 = NOVALUE;
    int _5623 = NOVALUE;
    int _5622 = NOVALUE;
    int _5615 = NOVALUE;
    int _5611 = NOVALUE;
    int _5608 = NOVALUE;
    int _5598 = NOVALUE;
    int _5596 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(arg_list) then*/
    _5596 = IS_ATOM(_arg_list_10141);
    if (_5596 == 0)
    {
        _5596 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _5596 = NOVALUE;
    }

    /** 		arg_list = {arg_list}*/
    _0 = _arg_list_10141;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_arg_list_10141);
    *((int *)(_2+4)) = _arg_list_10141;
    _arg_list_10141 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	result = ""*/
    RefDS(_5);
    DeRef(_result_10142);
    _result_10142 = _5;

    /** 	in_token = 0*/
    _in_token_10143 = 0;

    /** 	i = 0*/
    _i_10145 = 0;

    /** 	tend = 0*/
    _tend_10146 = 0;

    /** 	argl = 0*/
    _argl_10159 = 0;

    /** 	spacer = 0*/
    _spacer_10153 = 0;

    /** 	prevargv = 0*/
    DeRef(_prevargv_10165);
    _prevargv_10165 = 0;

    /**     while i < length(format_pattern) do*/
L2: 
    if (IS_SEQUENCE(_format_pattern_10140)){
            _5598 = SEQ_PTR(_format_pattern_10140)->length;
    }
    else {
        _5598 = 1;
    }
    if (_i_10145 >= _5598)
    goto L3; // [63] 3380

    /**     	i += 1*/
    _i_10145 = _i_10145 + 1;

    /**     	tch = format_pattern[i]*/
    _2 = (int)SEQ_PTR(_format_pattern_10140);
    _tch_10144 = (int)*(((s1_ptr)_2)->base + _i_10145);
    if (!IS_ATOM_INT(_tch_10144))
    _tch_10144 = (long)DBL_PTR(_tch_10144)->dbl;

    /**     	if not in_token then*/
    if (_in_token_10143 != 0)
    goto L4; // [81] 210

    /**     		if tch = '[' then*/
    if (_tch_10144 != 91)
    goto L5; // [86] 200

    /**     			in_token = 1*/
    _in_token_10143 = 1;

    /**     			tend = 0*/
    _tend_10146 = 0;

    /** 				cap = 0*/
    _cap_10147 = 0;

    /** 				align = 0*/
    _align_10148 = 0;

    /** 				psign = 0*/
    _psign_10149 = 0;

    /** 				msign = 0*/
    _msign_10150 = 0;

    /** 				zfill = 0*/
    _zfill_10151 = 0;

    /** 				bwz = 0*/
    _bwz_10152 = 0;

    /** 				spacer = 0*/
    _spacer_10153 = 0;

    /** 				alt = 0*/
    _alt_10154 = 0;

    /**     			width = 0*/
    _width_10155 = 0;

    /**     			decs = -1*/
    _decs_10156 = -1;

    /**     			argn = 0*/
    _argn_10158 = 0;

    /**     			hexout = 0*/
    _hexout_10161 = 0;

    /**     			binout = 0*/
    _binout_10162 = 0;

    /**     			trimming = 0*/
    _trimming_10160 = 0;

    /**     			tsep = 0*/
    _tsep_10163 = 0;

    /**     			istext = 0*/
    _istext_10164 = 0;

    /**     			idname = ""*/
    RefDS(_5);
    DeRef(_idname_10167);
    _idname_10167 = _5;

    /**     			envvar = ""*/
    RefDS(_5);
    DeRefi(_envvar_10169);
    _envvar_10169 = _5;

    /**     			envsym = ""*/
    RefDS(_5);
    DeRef(_envsym_10168);
    _envsym_10168 = _5;
    goto L2; // [197] 60
L5: 

    /**     			result &= tch*/
    Append(&_result_10142, _result_10142, _tch_10144);
    goto L2; // [207] 60
L4: 

    /** 			switch tch do*/
    _0 = _tch_10144;
    switch ( _0 ){ 

        /**     			case ']' then*/
        case 93:

        /**     				in_token = 0*/
        _in_token_10143 = 0;

        /**     				tend = i*/
        _tend_10146 = _i_10145;
        goto L6; // [231] 1072

        /**     			case '[' then*/
        case 91:

        /** 	    			result &= tch*/
        Append(&_result_10142, _result_10142, _tch_10144);

        /** 	    			while i < length(format_pattern) do*/
L7: 
        if (IS_SEQUENCE(_format_pattern_10140)){
                _5608 = SEQ_PTR(_format_pattern_10140)->length;
        }
        else {
            _5608 = 1;
        }
        if (_i_10145 >= _5608)
        goto L6; // [251] 1072

        /** 	    				i += 1*/
        _i_10145 = _i_10145 + 1;

        /** 	    				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10140);
        _5611 = (int)*(((s1_ptr)_2)->base + _i_10145);
        if (binary_op_a(NOTEQ, _5611, 93)){
            _5611 = NOVALUE;
            goto L7; // [267] 248
        }
        _5611 = NOVALUE;

        /** 	    					in_token = 0*/
        _in_token_10143 = 0;

        /** 	    					tend = 0*/
        _tend_10146 = 0;

        /** 	    					exit*/
        goto L6; // [283] 1072

        /** 	    			end while*/
        goto L7; // [288] 248
        goto L6; // [291] 1072

        /** 	    		case 'w', 'u', 'l' then*/
        case 119:
        case 117:
        case 108:

        /** 	    			cap = tch*/
        _cap_10147 = _tch_10144;
        goto L6; // [306] 1072

        /** 	    		case 'b' then*/
        case 98:

        /** 	    			bwz = 1*/
        _bwz_10152 = 1;
        goto L6; // [317] 1072

        /** 	    		case 's' then*/
        case 115:

        /** 	    			spacer = 1*/
        _spacer_10153 = 1;
        goto L6; // [328] 1072

        /** 	    		case 't' then*/
        case 116:

        /** 	    			trimming = 1*/
        _trimming_10160 = 1;
        goto L6; // [339] 1072

        /** 	    		case 'z' then*/
        case 122:

        /** 	    			zfill = 1*/
        _zfill_10151 = 1;
        goto L6; // [350] 1072

        /** 	    		case 'X' then*/
        case 88:

        /** 	    			hexout = 1*/
        _hexout_10161 = 1;
        goto L6; // [361] 1072

        /** 	    		case 'B' then*/
        case 66:

        /** 	    			binout = 1*/
        _binout_10162 = 1;
        goto L6; // [372] 1072

        /** 	    		case 'c', '<', '>' then*/
        case 99:
        case 60:
        case 62:

        /** 	    			align = tch*/
        _align_10148 = _tch_10144;
        goto L6; // [387] 1072

        /** 	    		case '+' then*/
        case 43:

        /** 	    			psign = 1*/
        _psign_10149 = 1;
        goto L6; // [398] 1072

        /** 	    		case '(' then*/
        case 40:

        /** 	    			msign = 1*/
        _msign_10150 = 1;
        goto L6; // [409] 1072

        /** 	    		case '?' then*/
        case 63:

        /** 	    			alt = 1*/
        _alt_10154 = 1;
        goto L6; // [420] 1072

        /** 	    		case 'T' then*/
        case 84:

        /** 	    			istext = 1*/
        _istext_10164 = 1;
        goto L6; // [431] 1072

        /** 	    		case ':' then*/
        case 58:

        /** 	    			while i < length(format_pattern) do*/
L8: 
        if (IS_SEQUENCE(_format_pattern_10140)){
                _5615 = SEQ_PTR(_format_pattern_10140)->length;
        }
        else {
            _5615 = 1;
        }
        if (_i_10145 >= _5615)
        goto L6; // [445] 1072

        /** 	    				i += 1*/
        _i_10145 = _i_10145 + 1;

        /** 	    				tch = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_10140);
        _tch_10144 = (int)*(((s1_ptr)_2)->base + _i_10145);
        if (!IS_ATOM_INT(_tch_10144))
        _tch_10144 = (long)DBL_PTR(_tch_10144)->dbl;

        /** 	    				pos = find(tch, "0123456789")*/
        _pos_10157 = find_from(_tch_10144, _1415, 1);

        /** 	    				if pos = 0 then*/
        if (_pos_10157 != 0)
        goto L9; // [470] 485

        /** 	    					i -= 1*/
        _i_10145 = _i_10145 - 1;

        /** 	    					exit*/
        goto L6; // [482] 1072
L9: 

        /** 	    				width = width * 10 + pos - 1*/
        if (_width_10155 == (short)_width_10155)
        _5622 = _width_10155 * 10;
        else
        _5622 = NewDouble(_width_10155 * (double)10);
        if (IS_ATOM_INT(_5622)) {
            _5623 = _5622 + _pos_10157;
            if ((long)((unsigned long)_5623 + (unsigned long)HIGH_BITS) >= 0) 
            _5623 = NewDouble((double)_5623);
        }
        else {
            _5623 = NewDouble(DBL_PTR(_5622)->dbl + (double)_pos_10157);
        }
        DeRef(_5622);
        _5622 = NOVALUE;
        if (IS_ATOM_INT(_5623)) {
            _width_10155 = _5623 - 1;
        }
        else {
            _width_10155 = NewDouble(DBL_PTR(_5623)->dbl - (double)1);
        }
        DeRef(_5623);
        _5623 = NOVALUE;
        if (!IS_ATOM_INT(_width_10155)) {
            _1 = (long)(DBL_PTR(_width_10155)->dbl);
            DeRefDS(_width_10155);
            _width_10155 = _1;
        }

        /** 	    				if width = 0 then*/
        if (_width_10155 != 0)
        goto L8; // [505] 442

        /** 	    					zfill = '0'*/
        _zfill_10151 = 48;

        /** 	    			end while*/
        goto L8; // [517] 442
        goto L6; // [520] 1072

        /** 	    		case '.' then*/
        case 46:

        /** 	    			decs = 0*/
        _decs_10156 = 0;

        /** 	    			while i < length(format_pattern) do*/
LA: 
        if (IS_SEQUENCE(_format_pattern_10140)){
                _5626 = SEQ_PTR(_format_pattern_10140)->length;
        }
        else {
            _5626 = 1;
        }
        if (_i_10145 >= _5626)
        goto L6; // [539] 1072

        /** 	    				i += 1*/
        _i_10145 = _i_10145 + 1;

        /** 	    				tch = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_10140);
        _tch_10144 = (int)*(((s1_ptr)_2)->base + _i_10145);
        if (!IS_ATOM_INT(_tch_10144))
        _tch_10144 = (long)DBL_PTR(_tch_10144)->dbl;

        /** 	    				pos = find(tch, "0123456789")*/
        _pos_10157 = find_from(_tch_10144, _1415, 1);

        /** 	    				if pos = 0 then*/
        if (_pos_10157 != 0)
        goto LB; // [564] 579

        /** 	    					i -= 1*/
        _i_10145 = _i_10145 - 1;

        /** 	    					exit*/
        goto L6; // [576] 1072
LB: 

        /** 	    				decs = decs * 10 + pos - 1*/
        if (_decs_10156 == (short)_decs_10156)
        _5633 = _decs_10156 * 10;
        else
        _5633 = NewDouble(_decs_10156 * (double)10);
        if (IS_ATOM_INT(_5633)) {
            _5634 = _5633 + _pos_10157;
            if ((long)((unsigned long)_5634 + (unsigned long)HIGH_BITS) >= 0) 
            _5634 = NewDouble((double)_5634);
        }
        else {
            _5634 = NewDouble(DBL_PTR(_5633)->dbl + (double)_pos_10157);
        }
        DeRef(_5633);
        _5633 = NOVALUE;
        if (IS_ATOM_INT(_5634)) {
            _decs_10156 = _5634 - 1;
        }
        else {
            _decs_10156 = NewDouble(DBL_PTR(_5634)->dbl - (double)1);
        }
        DeRef(_5634);
        _5634 = NOVALUE;
        if (!IS_ATOM_INT(_decs_10156)) {
            _1 = (long)(DBL_PTR(_decs_10156)->dbl);
            DeRefDS(_decs_10156);
            _decs_10156 = _1;
        }

        /** 	    			end while*/
        goto LA; // [597] 536
        goto L6; // [600] 1072

        /** 	    		case '{' then*/
        case 123:

        /** 	    			integer sp*/

        /** 	    			sp = i + 1*/
        _sp_10241 = _i_10145 + 1;

        /** 	    			i = sp*/
        _i_10145 = _sp_10241;

        /** 	    			while i < length(format_pattern) do*/
LC: 
        if (IS_SEQUENCE(_format_pattern_10140)){
                _5637 = SEQ_PTR(_format_pattern_10140)->length;
        }
        else {
            _5637 = 1;
        }
        if (_i_10145 >= _5637)
        goto LD; // [627] 672

        /** 	    				if format_pattern[i] = '}' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10140);
        _5639 = (int)*(((s1_ptr)_2)->base + _i_10145);
        if (binary_op_a(NOTEQ, _5639, 125)){
            _5639 = NOVALUE;
            goto LE; // [637] 646
        }
        _5639 = NOVALUE;

        /** 	    					exit*/
        goto LD; // [643] 672
LE: 

        /** 	    				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10140);
        _5641 = (int)*(((s1_ptr)_2)->base + _i_10145);
        if (binary_op_a(NOTEQ, _5641, 93)){
            _5641 = NOVALUE;
            goto LF; // [652] 661
        }
        _5641 = NOVALUE;

        /** 	    					exit*/
        goto LD; // [658] 672
LF: 

        /** 	    				i += 1*/
        _i_10145 = _i_10145 + 1;

        /** 	    			end while*/
        goto LC; // [669] 624
LD: 

        /** 	    			idname = trim(format_pattern[sp .. i-1]) & '='*/
        _5644 = _i_10145 - 1;
        rhs_slice_target = (object_ptr)&_5645;
        RHS_Slice(_format_pattern_10140, _sp_10241, _5644);
        RefDS(_4538);
        _5646 = _12trim(_5645, _4538, 0);
        _5645 = NOVALUE;
        if (IS_SEQUENCE(_5646) && IS_ATOM(61)) {
            Append(&_idname_10167, _5646, 61);
        }
        else if (IS_ATOM(_5646) && IS_SEQUENCE(61)) {
        }
        else {
            Concat((object_ptr)&_idname_10167, _5646, 61);
            DeRef(_5646);
            _5646 = NOVALUE;
        }
        DeRef(_5646);
        _5646 = NOVALUE;

        /**     				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10140);
        _5648 = (int)*(((s1_ptr)_2)->base + _i_10145);
        if (binary_op_a(NOTEQ, _5648, 93)){
            _5648 = NOVALUE;
            goto L10; // [699] 710
        }
        _5648 = NOVALUE;

        /**     					i -= 1*/
        _i_10145 = _i_10145 - 1;
L10: 

        /**     				for j = 1 to length(arg_list) do*/
        if (IS_SEQUENCE(_arg_list_10141)){
                _5651 = SEQ_PTR(_arg_list_10141)->length;
        }
        else {
            _5651 = 1;
        }
        {
            int _j_10262;
            _j_10262 = 1;
L11: 
            if (_j_10262 > _5651){
                goto L12; // [715] 797
            }

            /**     					if sequence(arg_list[j]) then*/
            _2 = (int)SEQ_PTR(_arg_list_10141);
            _5652 = (int)*(((s1_ptr)_2)->base + _j_10262);
            _5653 = IS_SEQUENCE(_5652);
            _5652 = NOVALUE;
            if (_5653 == 0)
            {
                _5653 = NOVALUE;
                goto L13; // [731] 768
            }
            else{
                _5653 = NOVALUE;
            }

            /**     						if search:begins(idname, arg_list[j]) then*/
            _2 = (int)SEQ_PTR(_arg_list_10141);
            _5654 = (int)*(((s1_ptr)_2)->base + _j_10262);
            RefDS(_idname_10167);
            Ref(_5654);
            _5655 = _14begins(_idname_10167, _5654);
            _5654 = NOVALUE;
            if (_5655 == 0) {
                DeRef(_5655);
                _5655 = NOVALUE;
                goto L14; // [745] 767
            }
            else {
                if (!IS_ATOM_INT(_5655) && DBL_PTR(_5655)->dbl == 0.0){
                    DeRef(_5655);
                    _5655 = NOVALUE;
                    goto L14; // [745] 767
                }
                DeRef(_5655);
                _5655 = NOVALUE;
            }
            DeRef(_5655);
            _5655 = NOVALUE;

            /**     							if argn = 0 then*/
            if (_argn_10158 != 0)
            goto L15; // [752] 766

            /**     								argn = j*/
            _argn_10158 = _j_10262;

            /**     								exit*/
            goto L12; // [763] 797
L15: 
L14: 
L13: 

            /**     					if j = length(arg_list) then*/
            if (IS_SEQUENCE(_arg_list_10141)){
                    _5657 = SEQ_PTR(_arg_list_10141)->length;
            }
            else {
                _5657 = 1;
            }
            if (_j_10262 != _5657)
            goto L16; // [773] 790

            /**     						idname = ""*/
            RefDS(_5);
            DeRef(_idname_10167);
            _idname_10167 = _5;

            /**     						argn = -1*/
            _argn_10158 = -1;
L16: 

            /**     				end for*/
            _j_10262 = _j_10262 + 1;
            goto L11; // [792] 722
L12: 
            ;
        }
        goto L6; // [799] 1072

        /** 	    		case '%' then*/
        case 37:

        /** 	    			integer sp*/

        /** 	    			sp = i + 1*/
        _sp_10276 = _i_10145 + 1;

        /** 	    			i = sp*/
        _i_10145 = _sp_10276;

        /** 	    			while i < length(format_pattern) do*/
L17: 
        if (IS_SEQUENCE(_format_pattern_10140)){
                _5660 = SEQ_PTR(_format_pattern_10140)->length;
        }
        else {
            _5660 = 1;
        }
        if (_i_10145 >= _5660)
        goto L18; // [826] 871

        /** 	    				if format_pattern[i] = '%' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10140);
        _5662 = (int)*(((s1_ptr)_2)->base + _i_10145);
        if (binary_op_a(NOTEQ, _5662, 37)){
            _5662 = NOVALUE;
            goto L19; // [836] 845
        }
        _5662 = NOVALUE;

        /** 	    					exit*/
        goto L18; // [842] 871
L19: 

        /** 	    				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10140);
        _5664 = (int)*(((s1_ptr)_2)->base + _i_10145);
        if (binary_op_a(NOTEQ, _5664, 93)){
            _5664 = NOVALUE;
            goto L1A; // [851] 860
        }
        _5664 = NOVALUE;

        /** 	    					exit*/
        goto L18; // [857] 871
L1A: 

        /** 	    				i += 1*/
        _i_10145 = _i_10145 + 1;

        /** 	    			end while*/
        goto L17; // [868] 823
L18: 

        /** 	    			envsym = trim(format_pattern[sp .. i-1])*/
        _5667 = _i_10145 - 1;
        rhs_slice_target = (object_ptr)&_5668;
        RHS_Slice(_format_pattern_10140, _sp_10276, _5667);
        RefDS(_4538);
        _0 = _envsym_10168;
        _envsym_10168 = _12trim(_5668, _4538, 0);
        DeRef(_0);
        _5668 = NOVALUE;

        /**     				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_10140);
        _5670 = (int)*(((s1_ptr)_2)->base + _i_10145);
        if (binary_op_a(NOTEQ, _5670, 93)){
            _5670 = NOVALUE;
            goto L1B; // [894] 905
        }
        _5670 = NOVALUE;

        /**     					i -= 1*/
        _i_10145 = _i_10145 - 1;
L1B: 

        /**     				envvar = getenv(envsym)*/
        DeRefi(_envvar_10169);
        _envvar_10169 = EGetEnv(_envsym_10168);

        /**     				argn = -1*/
        _argn_10158 = -1;

        /**     				if atom(envvar) then*/
        _5674 = IS_ATOM(_envvar_10169);
        if (_5674 == 0)
        {
            _5674 = NOVALUE;
            goto L1C; // [920] 929
        }
        else{
            _5674 = NOVALUE;
        }

        /**     					envvar = ""*/
        RefDS(_5);
        DeRefi(_envvar_10169);
        _envvar_10169 = _5;
L1C: 
        goto L6; // [931] 1072

        /** 	    		case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' then*/
        case 48:
        case 49:
        case 50:
        case 51:
        case 52:
        case 53:
        case 54:
        case 55:
        case 56:
        case 57:

        /** 	    			if argn = 0 then*/
        if (_argn_10158 != 0)
        goto L6; // [957] 1072

        /** 		    			i -= 1*/
        _i_10145 = _i_10145 - 1;

        /** 		    			while i < length(format_pattern) do*/
L1D: 
        if (IS_SEQUENCE(_format_pattern_10140)){
                _5677 = SEQ_PTR(_format_pattern_10140)->length;
        }
        else {
            _5677 = 1;
        }
        if (_i_10145 >= _5677)
        goto L6; // [975] 1072

        /** 		    				i += 1*/
        _i_10145 = _i_10145 + 1;

        /** 		    				tch = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_10140);
        _tch_10144 = (int)*(((s1_ptr)_2)->base + _i_10145);
        if (!IS_ATOM_INT(_tch_10144))
        _tch_10144 = (long)DBL_PTR(_tch_10144)->dbl;

        /** 		    				pos = find(tch, "0123456789")*/
        _pos_10157 = find_from(_tch_10144, _1415, 1);

        /** 		    				if pos = 0 then*/
        if (_pos_10157 != 0)
        goto L1E; // [1000] 1015

        /** 		    					i -= 1*/
        _i_10145 = _i_10145 - 1;

        /** 		    					exit*/
        goto L6; // [1012] 1072
L1E: 

        /** 		    				argn = argn * 10 + pos - 1*/
        if (_argn_10158 == (short)_argn_10158)
        _5684 = _argn_10158 * 10;
        else
        _5684 = NewDouble(_argn_10158 * (double)10);
        if (IS_ATOM_INT(_5684)) {
            _5685 = _5684 + _pos_10157;
            if ((long)((unsigned long)_5685 + (unsigned long)HIGH_BITS) >= 0) 
            _5685 = NewDouble((double)_5685);
        }
        else {
            _5685 = NewDouble(DBL_PTR(_5684)->dbl + (double)_pos_10157);
        }
        DeRef(_5684);
        _5684 = NOVALUE;
        if (IS_ATOM_INT(_5685)) {
            _argn_10158 = _5685 - 1;
        }
        else {
            _argn_10158 = NewDouble(DBL_PTR(_5685)->dbl - (double)1);
        }
        DeRef(_5685);
        _5685 = NOVALUE;
        if (!IS_ATOM_INT(_argn_10158)) {
            _1 = (long)(DBL_PTR(_argn_10158)->dbl);
            DeRefDS(_argn_10158);
            _argn_10158 = _1;
        }

        /** 		    			end while*/
        goto L1D; // [1033] 972
        goto L6; // [1037] 1072

        /** 	    		case ',' then*/
        case 44:

        /** 	    			if i < length(format_pattern) then*/
        if (IS_SEQUENCE(_format_pattern_10140)){
                _5687 = SEQ_PTR(_format_pattern_10140)->length;
        }
        else {
            _5687 = 1;
        }
        if (_i_10145 >= _5687)
        goto L6; // [1048] 1072

        /** 	    				i +=1*/
        _i_10145 = _i_10145 + 1;

        /** 	    				tsep = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_10140);
        _tsep_10163 = (int)*(((s1_ptr)_2)->base + _i_10145);
        if (!IS_ATOM_INT(_tsep_10163))
        _tsep_10163 = (long)DBL_PTR(_tsep_10163)->dbl;
        goto L6; // [1065] 1072

        /** 	    		case else*/
        default:
    ;}L6: 

    /**     		if tend > 0 then*/
    if (_tend_10146 <= 0)
    goto L1F; // [1074] 3372

    /**     			sequence argtext = ""*/
    RefDS(_5);
    DeRef(_argtext_10323);
    _argtext_10323 = _5;

    /**     			if argn = 0 then*/
    if (_argn_10158 != 0)
    goto L20; // [1089] 1100

    /**     				argn = argl + 1*/
    _argn_10158 = _argl_10159 + 1;
L20: 

    /**     			argl = argn*/
    _argl_10159 = _argn_10158;

    /**     			if argn < 1 or argn > length(arg_list) then*/
    _5694 = (_argn_10158 < 1);
    if (_5694 != 0) {
        goto L21; // [1111] 1127
    }
    if (IS_SEQUENCE(_arg_list_10141)){
            _5696 = SEQ_PTR(_arg_list_10141)->length;
    }
    else {
        _5696 = 1;
    }
    _5697 = (_argn_10158 > _5696);
    _5696 = NOVALUE;
    if (_5697 == 0)
    {
        DeRef(_5697);
        _5697 = NOVALUE;
        goto L22; // [1123] 1169
    }
    else{
        DeRef(_5697);
        _5697 = NOVALUE;
    }
L21: 

    /**     				if length(envvar) > 0 then*/
    if (IS_SEQUENCE(_envvar_10169)){
            _5698 = SEQ_PTR(_envvar_10169)->length;
    }
    else {
        _5698 = 1;
    }
    if (_5698 <= 0)
    goto L23; // [1134] 1153

    /**     					argtext = envvar*/
    Ref(_envvar_10169);
    DeRef(_argtext_10323);
    _argtext_10323 = _envvar_10169;

    /** 	    				currargv = envvar*/
    Ref(_envvar_10169);
    DeRef(_currargv_10166);
    _currargv_10166 = _envvar_10169;
    goto L24; // [1150] 2553
L23: 

    /**     					argtext = ""*/
    RefDS(_5);
    DeRef(_argtext_10323);
    _argtext_10323 = _5;

    /** 	    				currargv =""*/
    RefDS(_5);
    DeRef(_currargv_10166);
    _currargv_10166 = _5;
    goto L24; // [1166] 2553
L22: 

    /** 					if string(arg_list[argn]) then*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5700 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    Ref(_5700);
    _5701 = _9string(_5700);
    _5700 = NOVALUE;
    if (_5701 == 0) {
        DeRef(_5701);
        _5701 = NOVALUE;
        goto L25; // [1179] 1229
    }
    else {
        if (!IS_ATOM_INT(_5701) && DBL_PTR(_5701)->dbl == 0.0){
            DeRef(_5701);
            _5701 = NOVALUE;
            goto L25; // [1179] 1229
        }
        DeRef(_5701);
        _5701 = NOVALUE;
    }
    DeRef(_5701);
    _5701 = NOVALUE;

    /** 						if length(idname) > 0 then*/
    if (IS_SEQUENCE(_idname_10167)){
            _5702 = SEQ_PTR(_idname_10167)->length;
    }
    else {
        _5702 = 1;
    }
    if (_5702 <= 0)
    goto L26; // [1189] 1217

    /** 							argtext = arg_list[argn][length(idname) + 1 .. $]*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5704 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    if (IS_SEQUENCE(_idname_10167)){
            _5705 = SEQ_PTR(_idname_10167)->length;
    }
    else {
        _5705 = 1;
    }
    _5706 = _5705 + 1;
    _5705 = NOVALUE;
    if (IS_SEQUENCE(_5704)){
            _5707 = SEQ_PTR(_5704)->length;
    }
    else {
        _5707 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_10323;
    RHS_Slice(_5704, _5706, _5707);
    _5704 = NOVALUE;
    goto L27; // [1214] 2546
L26: 

    /** 							argtext = arg_list[argn]*/
    DeRef(_argtext_10323);
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _argtext_10323 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    Ref(_argtext_10323);
    goto L27; // [1226] 2546
L25: 

    /** 					elsif integer(arg_list[argn]) then*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5710 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    if (IS_ATOM_INT(_5710))
    _5711 = 1;
    else if (IS_ATOM_DBL(_5710))
    _5711 = IS_ATOM_INT(DoubleToInt(_5710));
    else
    _5711 = 0;
    _5710 = NOVALUE;
    if (_5711 == 0)
    {
        _5711 = NOVALUE;
        goto L28; // [1238] 1718
    }
    else{
        _5711 = NOVALUE;
    }

    /** 						if istext then*/
    if (_istext_10164 == 0)
    {
        goto L29; // [1245] 1269
    }
    else{
    }

    /** 							argtext = {and_bits(0xFFFF_FFFF, math:abs(arg_list[argn]))}*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5712 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    Ref(_5712);
    _5713 = _20abs(_5712);
    _5712 = NOVALUE;
    _5714 = binary_op(AND_BITS, _2259, _5713);
    DeRef(_5713);
    _5713 = NOVALUE;
    _0 = _argtext_10323;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5714;
    _argtext_10323 = MAKE_SEQ(_1);
    DeRef(_0);
    _5714 = NOVALUE;
    goto L27; // [1266] 2546
L29: 

    /** 						elsif bwz != 0 and arg_list[argn] = 0 then*/
    _5716 = (_bwz_10152 != 0);
    if (_5716 == 0) {
        goto L2A; // [1277] 1304
    }
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5718 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    if (IS_ATOM_INT(_5718)) {
        _5719 = (_5718 == 0);
    }
    else {
        _5719 = binary_op(EQUALS, _5718, 0);
    }
    _5718 = NOVALUE;
    if (_5719 == 0) {
        DeRef(_5719);
        _5719 = NOVALUE;
        goto L2A; // [1290] 1304
    }
    else {
        if (!IS_ATOM_INT(_5719) && DBL_PTR(_5719)->dbl == 0.0){
            DeRef(_5719);
            _5719 = NOVALUE;
            goto L2A; // [1290] 1304
        }
        DeRef(_5719);
        _5719 = NOVALUE;
    }
    DeRef(_5719);
    _5719 = NOVALUE;

    /** 							argtext = repeat(' ', width)*/
    DeRef(_argtext_10323);
    _argtext_10323 = Repeat(32, _width_10155);
    goto L27; // [1301] 2546
L2A: 

    /** 						elsif binout = 1 then*/
    if (_binout_10162 != 1)
    goto L2B; // [1308] 1382

    /** 							argtext = stdseq:reverse( convert:int_to_bits(arg_list[argn], 32)) + '0'*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5722 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    Ref(_5722);
    _5723 = _13int_to_bits(_5722, 32);
    _5722 = NOVALUE;
    _5724 = _23reverse(_5723, 1, 0);
    _5723 = NOVALUE;
    DeRef(_argtext_10323);
    if (IS_ATOM_INT(_5724)) {
        _argtext_10323 = _5724 + 48;
        if ((long)((unsigned long)_argtext_10323 + (unsigned long)HIGH_BITS) >= 0) 
        _argtext_10323 = NewDouble((double)_argtext_10323);
    }
    else {
        _argtext_10323 = binary_op(PLUS, _5724, 48);
    }
    DeRef(_5724);
    _5724 = NOVALUE;

    /** 							for ib = 1 to length(argtext) do*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5726 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5726 = 1;
    }
    {
        int _ib_10372;
        _ib_10372 = 1;
L2C: 
        if (_ib_10372 > _5726){
            goto L2D; // [1340] 1379
        }

        /** 								if argtext[ib] = '1' then*/
        _2 = (int)SEQ_PTR(_argtext_10323);
        _5727 = (int)*(((s1_ptr)_2)->base + _ib_10372);
        if (binary_op_a(NOTEQ, _5727, 49)){
            _5727 = NOVALUE;
            goto L2E; // [1353] 1372
        }
        _5727 = NOVALUE;

        /** 									argtext = argtext[ib .. $]*/
        if (IS_SEQUENCE(_argtext_10323)){
                _5729 = SEQ_PTR(_argtext_10323)->length;
        }
        else {
            _5729 = 1;
        }
        rhs_slice_target = (object_ptr)&_argtext_10323;
        RHS_Slice(_argtext_10323, _ib_10372, _5729);

        /** 									exit*/
        goto L2D; // [1369] 1379
L2E: 

        /** 							end for*/
        _ib_10372 = _ib_10372 + 1;
        goto L2C; // [1374] 1347
L2D: 
        ;
    }
    goto L27; // [1379] 2546
L2B: 

    /** 						elsif hexout = 0 then*/
    if (_hexout_10161 != 0)
    goto L2F; // [1386] 1652

    /** 							argtext = sprintf("%d", arg_list[argn])*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5732 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    DeRef(_argtext_10323);
    _argtext_10323 = EPrintf(-9999999, _737, _5732);
    _5732 = NOVALUE;

    /** 							if zfill != 0 and width > 0 then*/
    _5734 = (_zfill_10151 != 0);
    if (_5734 == 0) {
        goto L30; // [1408] 1505
    }
    _5736 = (_width_10155 > 0);
    if (_5736 == 0)
    {
        DeRef(_5736);
        _5736 = NOVALUE;
        goto L30; // [1419] 1505
    }
    else{
        DeRef(_5736);
        _5736 = NOVALUE;
    }

    /** 								if argtext[1] = '-' then*/
    _2 = (int)SEQ_PTR(_argtext_10323);
    _5737 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5737, 45)){
        _5737 = NOVALUE;
        goto L31; // [1428] 1474
    }
    _5737 = NOVALUE;

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5739 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5739 = 1;
    }
    if (_width_10155 <= _5739)
    goto L32; // [1439] 1504

    /** 										argtext = '-' & repeat('0', width - length(argtext)) & argtext[2..$]*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5741 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5741 = 1;
    }
    _5742 = _width_10155 - _5741;
    _5741 = NOVALUE;
    _5743 = Repeat(48, _5742);
    _5742 = NOVALUE;
    if (IS_SEQUENCE(_argtext_10323)){
            _5744 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5744 = 1;
    }
    rhs_slice_target = (object_ptr)&_5745;
    RHS_Slice(_argtext_10323, 2, _5744);
    {
        int concat_list[3];

        concat_list[0] = _5745;
        concat_list[1] = _5743;
        concat_list[2] = 45;
        Concat_N((object_ptr)&_argtext_10323, concat_list, 3);
    }
    DeRefDS(_5745);
    _5745 = NOVALUE;
    DeRefDS(_5743);
    _5743 = NOVALUE;
    goto L32; // [1471] 1504
L31: 

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5747 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5747 = 1;
    }
    if (_width_10155 <= _5747)
    goto L33; // [1481] 1503

    /** 										argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5749 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5749 = 1;
    }
    _5750 = _width_10155 - _5749;
    _5749 = NOVALUE;
    _5751 = Repeat(48, _5750);
    _5750 = NOVALUE;
    Concat((object_ptr)&_argtext_10323, _5751, _argtext_10323);
    DeRefDS(_5751);
    _5751 = NOVALUE;
    DeRef(_5751);
    _5751 = NOVALUE;
L33: 
L32: 
L30: 

    /** 							if arg_list[argn] > 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5753 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    if (binary_op_a(LESSEQ, _5753, 0)){
        _5753 = NOVALUE;
        goto L34; // [1511] 1559
    }
    _5753 = NOVALUE;

    /** 								if psign then*/
    if (_psign_10149 == 0)
    {
        goto L27; // [1519] 2546
    }
    else{
    }

    /** 									if zfill = 0 then*/
    if (_zfill_10151 != 0)
    goto L35; // [1524] 1537

    /** 										argtext = '+' & argtext*/
    Prepend(&_argtext_10323, _argtext_10323, 43);
    goto L27; // [1534] 2546
L35: 

    /** 									elsif argtext[1] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_10323);
    _5757 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5757, 48)){
        _5757 = NOVALUE;
        goto L27; // [1543] 2546
    }
    _5757 = NOVALUE;

    /** 										argtext[1] = '+'*/
    _2 = (int)SEQ_PTR(_argtext_10323);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _argtext_10323 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 43;
    DeRef(_1);
    goto L27; // [1556] 2546
L34: 

    /** 							elsif arg_list[argn] < 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5759 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    if (binary_op_a(GREATEREQ, _5759, 0)){
        _5759 = NOVALUE;
        goto L27; // [1565] 2546
    }
    _5759 = NOVALUE;

    /** 								if msign then*/
    if (_msign_10150 == 0)
    {
        goto L27; // [1573] 2546
    }
    else{
    }

    /** 									if zfill = 0 then*/
    if (_zfill_10151 != 0)
    goto L36; // [1578] 1601

    /** 										argtext = '(' & argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5762 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5762 = 1;
    }
    rhs_slice_target = (object_ptr)&_5763;
    RHS_Slice(_argtext_10323, 2, _5762);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5763;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10323, concat_list, 3);
    }
    DeRefDS(_5763);
    _5763 = NOVALUE;
    goto L27; // [1598] 2546
L36: 

    /** 										if argtext[2] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_10323);
    _5766 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _5766, 48)){
        _5766 = NOVALUE;
        goto L37; // [1607] 1630
    }
    _5766 = NOVALUE;

    /** 											argtext = '(' & argtext[3..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5768 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5768 = 1;
    }
    rhs_slice_target = (object_ptr)&_5769;
    RHS_Slice(_argtext_10323, 3, _5768);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5769;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10323, concat_list, 3);
    }
    DeRefDS(_5769);
    _5769 = NOVALUE;
    goto L27; // [1627] 2546
L37: 

    /** 											argtext = argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5771 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5771 = 1;
    }
    rhs_slice_target = (object_ptr)&_5772;
    RHS_Slice(_argtext_10323, 2, _5771);
    Append(&_argtext_10323, _5772, 41);
    DeRefDS(_5772);
    _5772 = NOVALUE;
    goto L27; // [1649] 2546
L2F: 

    /** 							argtext = sprintf("%x", arg_list[argn])*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5775 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    DeRef(_argtext_10323);
    _argtext_10323 = EPrintf(-9999999, _5774, _5775);
    _5775 = NOVALUE;

    /** 							if zfill != 0 and width > 0 then*/
    _5777 = (_zfill_10151 != 0);
    if (_5777 == 0) {
        goto L27; // [1670] 2546
    }
    _5779 = (_width_10155 > 0);
    if (_5779 == 0)
    {
        DeRef(_5779);
        _5779 = NOVALUE;
        goto L27; // [1681] 2546
    }
    else{
        DeRef(_5779);
        _5779 = NOVALUE;
    }

    /** 								if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5780 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5780 = 1;
    }
    if (_width_10155 <= _5780)
    goto L27; // [1691] 2546

    /** 									argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5782 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5782 = 1;
    }
    _5783 = _width_10155 - _5782;
    _5782 = NOVALUE;
    _5784 = Repeat(48, _5783);
    _5783 = NOVALUE;
    Concat((object_ptr)&_argtext_10323, _5784, _argtext_10323);
    DeRefDS(_5784);
    _5784 = NOVALUE;
    DeRef(_5784);
    _5784 = NOVALUE;
    goto L27; // [1715] 2546
L28: 

    /** 					elsif atom(arg_list[argn]) then*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5786 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    _5787 = IS_ATOM(_5786);
    _5786 = NOVALUE;
    if (_5787 == 0)
    {
        _5787 = NOVALUE;
        goto L38; // [1727] 2130
    }
    else{
        _5787 = NOVALUE;
    }

    /** 						if istext then*/
    if (_istext_10164 == 0)
    {
        goto L39; // [1734] 1761
    }
    else{
    }

    /** 							argtext = {and_bits(0xFFFF_FFFF, math:abs(floor(arg_list[argn])))}*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5788 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    if (IS_ATOM_INT(_5788))
    _5789 = e_floor(_5788);
    else
    _5789 = unary_op(FLOOR, _5788);
    _5788 = NOVALUE;
    _5790 = _20abs(_5789);
    _5789 = NOVALUE;
    _5791 = binary_op(AND_BITS, _2259, _5790);
    DeRef(_5790);
    _5790 = NOVALUE;
    _0 = _argtext_10323;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5791;
    _argtext_10323 = MAKE_SEQ(_1);
    DeRef(_0);
    _5791 = NOVALUE;
    goto L27; // [1758] 2546
L39: 

    /** 							if hexout then*/
    if (_hexout_10161 == 0)
    {
        goto L3A; // [1765] 1833
    }
    else{
    }

    /** 								argtext = sprintf("%x", arg_list[argn])*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5793 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    DeRef(_argtext_10323);
    _argtext_10323 = EPrintf(-9999999, _5774, _5793);
    _5793 = NOVALUE;

    /** 								if zfill != 0 and width > 0 then*/
    _5795 = (_zfill_10151 != 0);
    if (_5795 == 0) {
        goto L27; // [1786] 2546
    }
    _5797 = (_width_10155 > 0);
    if (_5797 == 0)
    {
        DeRef(_5797);
        _5797 = NOVALUE;
        goto L27; // [1797] 2546
    }
    else{
        DeRef(_5797);
        _5797 = NOVALUE;
    }

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5798 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5798 = 1;
    }
    if (_width_10155 <= _5798)
    goto L27; // [1807] 2546

    /** 										argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5800 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5800 = 1;
    }
    _5801 = _width_10155 - _5800;
    _5800 = NOVALUE;
    _5802 = Repeat(48, _5801);
    _5801 = NOVALUE;
    Concat((object_ptr)&_argtext_10323, _5802, _argtext_10323);
    DeRefDS(_5802);
    _5802 = NOVALUE;
    DeRef(_5802);
    _5802 = NOVALUE;
    goto L27; // [1830] 2546
L3A: 

    /** 								argtext = trim(sprintf("%15.15g", arg_list[argn]))*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5805 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    _5806 = EPrintf(-9999999, _5804, _5805);
    _5805 = NOVALUE;
    RefDS(_4538);
    _0 = _argtext_10323;
    _argtext_10323 = _12trim(_5806, _4538, 0);
    DeRef(_0);
    _5806 = NOVALUE;

    /** 								while ep != 0 with entry do*/
    goto L3B; // [1853] 1876
L3C: 
    if (_ep_10170 == 0)
    goto L3D; // [1858] 1888

    /** 									argtext = remove(argtext, ep+2)*/
    _5809 = _ep_10170 + 2;
    if ((long)((unsigned long)_5809 + (unsigned long)HIGH_BITS) >= 0) 
    _5809 = NewDouble((double)_5809);
    {
        s1_ptr assign_space = SEQ_PTR(_argtext_10323);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_5809)) ? _5809 : (long)(DBL_PTR(_5809)->dbl);
        int stop = (IS_ATOM_INT(_5809)) ? _5809 : (long)(DBL_PTR(_5809)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_argtext_10323), start, &_argtext_10323 );
            }
            else Tail(SEQ_PTR(_argtext_10323), stop+1, &_argtext_10323);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_argtext_10323), start, &_argtext_10323);
        }
        else {
            assign_slice_seq = &assign_space;
            _argtext_10323 = Remove_elements(start, stop, (SEQ_PTR(_argtext_10323)->ref == 1));
        }
    }
    DeRef(_5809);
    _5809 = NOVALUE;
    _5809 = NOVALUE;

    /** 								entry*/
L3B: 

    /** 									ep = match("e+0", argtext)*/
    _ep_10170 = e_match_from(_5811, _argtext_10323, 1);

    /** 								end while*/
    goto L3C; // [1885] 1856
L3D: 

    /** 								if zfill != 0 and width > 0 then*/
    _5813 = (_zfill_10151 != 0);
    if (_5813 == 0) {
        goto L3E; // [1896] 1981
    }
    _5815 = (_width_10155 > 0);
    if (_5815 == 0)
    {
        DeRef(_5815);
        _5815 = NOVALUE;
        goto L3E; // [1907] 1981
    }
    else{
        DeRef(_5815);
        _5815 = NOVALUE;
    }

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5816 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5816 = 1;
    }
    if (_width_10155 <= _5816)
    goto L3F; // [1917] 1980

    /** 										if argtext[1] = '-' then*/
    _2 = (int)SEQ_PTR(_argtext_10323);
    _5818 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5818, 45)){
        _5818 = NOVALUE;
        goto L40; // [1927] 1961
    }
    _5818 = NOVALUE;

    /** 											argtext = '-' & repeat('0', width - length(argtext)) & argtext[2..$]*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5820 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5820 = 1;
    }
    _5821 = _width_10155 - _5820;
    _5820 = NOVALUE;
    _5822 = Repeat(48, _5821);
    _5821 = NOVALUE;
    if (IS_SEQUENCE(_argtext_10323)){
            _5823 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5823 = 1;
    }
    rhs_slice_target = (object_ptr)&_5824;
    RHS_Slice(_argtext_10323, 2, _5823);
    {
        int concat_list[3];

        concat_list[0] = _5824;
        concat_list[1] = _5822;
        concat_list[2] = 45;
        Concat_N((object_ptr)&_argtext_10323, concat_list, 3);
    }
    DeRefDS(_5824);
    _5824 = NOVALUE;
    DeRefDS(_5822);
    _5822 = NOVALUE;
    goto L41; // [1958] 1979
L40: 

    /** 											argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5826 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5826 = 1;
    }
    _5827 = _width_10155 - _5826;
    _5826 = NOVALUE;
    _5828 = Repeat(48, _5827);
    _5827 = NOVALUE;
    Concat((object_ptr)&_argtext_10323, _5828, _argtext_10323);
    DeRefDS(_5828);
    _5828 = NOVALUE;
    DeRef(_5828);
    _5828 = NOVALUE;
L41: 
L3F: 
L3E: 

    /** 								if arg_list[argn] > 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5830 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    if (binary_op_a(LESSEQ, _5830, 0)){
        _5830 = NOVALUE;
        goto L42; // [1987] 2035
    }
    _5830 = NOVALUE;

    /** 									if psign  then*/
    if (_psign_10149 == 0)
    {
        goto L27; // [1995] 2546
    }
    else{
    }

    /** 										if zfill = 0 then*/
    if (_zfill_10151 != 0)
    goto L43; // [2000] 2013

    /** 											argtext = '+' & argtext*/
    Prepend(&_argtext_10323, _argtext_10323, 43);
    goto L27; // [2010] 2546
L43: 

    /** 										elsif argtext[1] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_10323);
    _5834 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5834, 48)){
        _5834 = NOVALUE;
        goto L27; // [2019] 2546
    }
    _5834 = NOVALUE;

    /** 											argtext[1] = '+'*/
    _2 = (int)SEQ_PTR(_argtext_10323);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _argtext_10323 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 43;
    DeRef(_1);
    goto L27; // [2032] 2546
L42: 

    /** 								elsif arg_list[argn] < 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5836 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    if (binary_op_a(GREATEREQ, _5836, 0)){
        _5836 = NOVALUE;
        goto L27; // [2041] 2546
    }
    _5836 = NOVALUE;

    /** 									if msign then*/
    if (_msign_10150 == 0)
    {
        goto L27; // [2049] 2546
    }
    else{
    }

    /** 										if zfill = 0 then*/
    if (_zfill_10151 != 0)
    goto L44; // [2054] 2077

    /** 											argtext = '(' & argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5839 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5839 = 1;
    }
    rhs_slice_target = (object_ptr)&_5840;
    RHS_Slice(_argtext_10323, 2, _5839);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5840;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10323, concat_list, 3);
    }
    DeRefDS(_5840);
    _5840 = NOVALUE;
    goto L27; // [2074] 2546
L44: 

    /** 											if argtext[2] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_10323);
    _5842 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _5842, 48)){
        _5842 = NOVALUE;
        goto L45; // [2083] 2106
    }
    _5842 = NOVALUE;

    /** 												argtext = '(' & argtext[3..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5844 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5844 = 1;
    }
    rhs_slice_target = (object_ptr)&_5845;
    RHS_Slice(_argtext_10323, 3, _5844);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5845;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10323, concat_list, 3);
    }
    DeRefDS(_5845);
    _5845 = NOVALUE;
    goto L27; // [2103] 2546
L45: 

    /** 												argtext = argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5847 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5847 = 1;
    }
    rhs_slice_target = (object_ptr)&_5848;
    RHS_Slice(_argtext_10323, 2, _5847);
    Append(&_argtext_10323, _5848, 41);
    DeRefDS(_5848);
    _5848 = NOVALUE;
    goto L27; // [2127] 2546
L38: 

    /** 						if alt != 0 and length(arg_list[argn]) = 2 then*/
    _5850 = (_alt_10154 != 0);
    if (_5850 == 0) {
        goto L46; // [2138] 2457
    }
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5852 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    if (IS_SEQUENCE(_5852)){
            _5853 = SEQ_PTR(_5852)->length;
    }
    else {
        _5853 = 1;
    }
    _5852 = NOVALUE;
    _5854 = (_5853 == 2);
    _5853 = NOVALUE;
    if (_5854 == 0)
    {
        DeRef(_5854);
        _5854 = NOVALUE;
        goto L46; // [2154] 2457
    }
    else{
        DeRef(_5854);
        _5854 = NOVALUE;
    }

    /** 							object tempv*/

    /** 							if atom(prevargv) then*/
    _5855 = IS_ATOM(_prevargv_10165);
    if (_5855 == 0)
    {
        _5855 = NOVALUE;
        goto L47; // [2164] 2200
    }
    else{
        _5855 = NOVALUE;
    }

    /** 								if prevargv != 1 then*/
    if (binary_op_a(EQUALS, _prevargv_10165, 1)){
        goto L48; // [2169] 2186
    }

    /** 									tempv = arg_list[argn][1]*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5857 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    DeRef(_tempv_10546);
    _2 = (int)SEQ_PTR(_5857);
    _tempv_10546 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tempv_10546);
    _5857 = NOVALUE;
    goto L49; // [2183] 2234
L48: 

    /** 									tempv = arg_list[argn][2]*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5859 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    DeRef(_tempv_10546);
    _2 = (int)SEQ_PTR(_5859);
    _tempv_10546 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tempv_10546);
    _5859 = NOVALUE;
    goto L49; // [2197] 2234
L47: 

    /** 								if length(prevargv) = 0 then*/
    if (IS_SEQUENCE(_prevargv_10165)){
            _5861 = SEQ_PTR(_prevargv_10165)->length;
    }
    else {
        _5861 = 1;
    }
    if (_5861 != 0)
    goto L4A; // [2205] 2222

    /** 									tempv = arg_list[argn][1]*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5863 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    DeRef(_tempv_10546);
    _2 = (int)SEQ_PTR(_5863);
    _tempv_10546 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tempv_10546);
    _5863 = NOVALUE;
    goto L4B; // [2219] 2233
L4A: 

    /** 									tempv = arg_list[argn][2]*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5865 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    DeRef(_tempv_10546);
    _2 = (int)SEQ_PTR(_5865);
    _tempv_10546 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tempv_10546);
    _5865 = NOVALUE;
L4B: 
L49: 

    /** 							if string(tempv) then*/
    Ref(_tempv_10546);
    _5867 = _9string(_tempv_10546);
    if (_5867 == 0) {
        DeRef(_5867);
        _5867 = NOVALUE;
        goto L4C; // [2242] 2255
    }
    else {
        if (!IS_ATOM_INT(_5867) && DBL_PTR(_5867)->dbl == 0.0){
            DeRef(_5867);
            _5867 = NOVALUE;
            goto L4C; // [2242] 2255
        }
        DeRef(_5867);
        _5867 = NOVALUE;
    }
    DeRef(_5867);
    _5867 = NOVALUE;

    /** 								argtext = tempv*/
    Ref(_tempv_10546);
    DeRef(_argtext_10323);
    _argtext_10323 = _tempv_10546;
    goto L4D; // [2252] 2452
L4C: 

    /** 							elsif integer(tempv) then*/
    if (IS_ATOM_INT(_tempv_10546))
    _5868 = 1;
    else if (IS_ATOM_DBL(_tempv_10546))
    _5868 = IS_ATOM_INT(DoubleToInt(_tempv_10546));
    else
    _5868 = 0;
    if (_5868 == 0)
    {
        _5868 = NOVALUE;
        goto L4E; // [2260] 2326
    }
    else{
        _5868 = NOVALUE;
    }

    /** 								if istext then*/
    if (_istext_10164 == 0)
    {
        goto L4F; // [2265] 2285
    }
    else{
    }

    /** 									argtext = {and_bits(0xFFFF_FFFF, math:abs(tempv))}*/
    Ref(_tempv_10546);
    _5869 = _20abs(_tempv_10546);
    _5870 = binary_op(AND_BITS, _2259, _5869);
    DeRef(_5869);
    _5869 = NOVALUE;
    _0 = _argtext_10323;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5870;
    _argtext_10323 = MAKE_SEQ(_1);
    DeRef(_0);
    _5870 = NOVALUE;
    goto L4D; // [2282] 2452
L4F: 

    /** 								elsif bwz != 0 and tempv = 0 then*/
    _5872 = (_bwz_10152 != 0);
    if (_5872 == 0) {
        goto L50; // [2293] 2316
    }
    if (IS_ATOM_INT(_tempv_10546)) {
        _5874 = (_tempv_10546 == 0);
    }
    else {
        _5874 = binary_op(EQUALS, _tempv_10546, 0);
    }
    if (_5874 == 0) {
        DeRef(_5874);
        _5874 = NOVALUE;
        goto L50; // [2302] 2316
    }
    else {
        if (!IS_ATOM_INT(_5874) && DBL_PTR(_5874)->dbl == 0.0){
            DeRef(_5874);
            _5874 = NOVALUE;
            goto L50; // [2302] 2316
        }
        DeRef(_5874);
        _5874 = NOVALUE;
    }
    DeRef(_5874);
    _5874 = NOVALUE;

    /** 									argtext = repeat(' ', width)*/
    DeRef(_argtext_10323);
    _argtext_10323 = Repeat(32, _width_10155);
    goto L4D; // [2313] 2452
L50: 

    /** 									argtext = sprintf("%d", tempv)*/
    DeRef(_argtext_10323);
    _argtext_10323 = EPrintf(-9999999, _737, _tempv_10546);
    goto L4D; // [2323] 2452
L4E: 

    /** 							elsif atom(tempv) then*/
    _5877 = IS_ATOM(_tempv_10546);
    if (_5877 == 0)
    {
        _5877 = NOVALUE;
        goto L51; // [2331] 2408
    }
    else{
        _5877 = NOVALUE;
    }

    /** 								if istext then*/
    if (_istext_10164 == 0)
    {
        goto L52; // [2336] 2359
    }
    else{
    }

    /** 									argtext = {and_bits(0xFFFF_FFFF, math:abs(floor(tempv)))}*/
    if (IS_ATOM_INT(_tempv_10546))
    _5878 = e_floor(_tempv_10546);
    else
    _5878 = unary_op(FLOOR, _tempv_10546);
    _5879 = _20abs(_5878);
    _5878 = NOVALUE;
    _5880 = binary_op(AND_BITS, _2259, _5879);
    DeRef(_5879);
    _5879 = NOVALUE;
    _0 = _argtext_10323;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5880;
    _argtext_10323 = MAKE_SEQ(_1);
    DeRef(_0);
    _5880 = NOVALUE;
    goto L4D; // [2356] 2452
L52: 

    /** 								elsif bwz != 0 and tempv = 0 then*/
    _5882 = (_bwz_10152 != 0);
    if (_5882 == 0) {
        goto L53; // [2367] 2390
    }
    if (IS_ATOM_INT(_tempv_10546)) {
        _5884 = (_tempv_10546 == 0);
    }
    else {
        _5884 = binary_op(EQUALS, _tempv_10546, 0);
    }
    if (_5884 == 0) {
        DeRef(_5884);
        _5884 = NOVALUE;
        goto L53; // [2376] 2390
    }
    else {
        if (!IS_ATOM_INT(_5884) && DBL_PTR(_5884)->dbl == 0.0){
            DeRef(_5884);
            _5884 = NOVALUE;
            goto L53; // [2376] 2390
        }
        DeRef(_5884);
        _5884 = NOVALUE;
    }
    DeRef(_5884);
    _5884 = NOVALUE;

    /** 									argtext = repeat(' ', width)*/
    DeRef(_argtext_10323);
    _argtext_10323 = Repeat(32, _width_10155);
    goto L4D; // [2387] 2452
L53: 

    /** 									argtext = trim(sprintf("%15.15g", tempv))*/
    _5886 = EPrintf(-9999999, _5804, _tempv_10546);
    RefDS(_4538);
    _0 = _argtext_10323;
    _argtext_10323 = _12trim(_5886, _4538, 0);
    DeRef(_0);
    _5886 = NOVALUE;
    goto L4D; // [2405] 2452
L51: 

    /** 								argtext = pretty:pretty_sprint( tempv,*/
    _1 = NewS1(10);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 1;
    *((int *)(_2+16)) = 1000;
    RefDS(_737);
    *((int *)(_2+20)) = _737;
    RefDS(_5888);
    *((int *)(_2+24)) = _5888;
    *((int *)(_2+28)) = 32;
    *((int *)(_2+32)) = 127;
    *((int *)(_2+36)) = 1;
    *((int *)(_2+40)) = 0;
    _5889 = MAKE_SEQ(_1);
    DeRef(_options_inlined_pretty_sprint_at_2424_10600);
    _options_inlined_pretty_sprint_at_2424_10600 = _5889;
    _5889 = NOVALUE;

    /** 	pretty_printing = 0*/
    _10pretty_printing_1560 = 0;

    /** 	pretty( x, options )*/
    Ref(_tempv_10546);
    RefDS(_options_inlined_pretty_sprint_at_2424_10600);
    _10pretty(_tempv_10546, _options_inlined_pretty_sprint_at_2424_10600);

    /** 	return pretty_line*/
    RefDS(_10pretty_line_1563);
    DeRef(_argtext_10323);
    _argtext_10323 = _10pretty_line_1563;
    DeRef(_options_inlined_pretty_sprint_at_2424_10600);
    _options_inlined_pretty_sprint_at_2424_10600 = NOVALUE;
L4D: 
    DeRef(_tempv_10546);
    _tempv_10546 = NOVALUE;
    goto L54; // [2454] 2533
L46: 

    /** 							argtext = pretty:pretty_sprint( arg_list[argn],*/
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _5890 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    _1 = NewS1(10);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 1;
    *((int *)(_2+16)) = 1000;
    RefDS(_737);
    *((int *)(_2+20)) = _737;
    RefDS(_5888);
    *((int *)(_2+24)) = _5888;
    *((int *)(_2+28)) = 32;
    *((int *)(_2+32)) = 127;
    *((int *)(_2+36)) = 1;
    *((int *)(_2+40)) = 0;
    _5891 = MAKE_SEQ(_1);
    Ref(_5890);
    DeRef(_x_inlined_pretty_sprint_at_2477_10606);
    _x_inlined_pretty_sprint_at_2477_10606 = _5890;
    _5890 = NOVALUE;
    DeRef(_options_inlined_pretty_sprint_at_2480_10607);
    _options_inlined_pretty_sprint_at_2480_10607 = _5891;
    _5891 = NOVALUE;

    /** 	pretty_printing = 0*/
    _10pretty_printing_1560 = 0;

    /** 	pretty( x, options )*/
    Ref(_x_inlined_pretty_sprint_at_2477_10606);
    RefDS(_options_inlined_pretty_sprint_at_2480_10607);
    _10pretty(_x_inlined_pretty_sprint_at_2477_10606, _options_inlined_pretty_sprint_at_2480_10607);

    /** 	return pretty_line*/
    RefDS(_10pretty_line_1563);
    DeRef(_argtext_10323);
    _argtext_10323 = _10pretty_line_1563;
    DeRef(_x_inlined_pretty_sprint_at_2477_10606);
    _x_inlined_pretty_sprint_at_2477_10606 = NOVALUE;
    DeRef(_options_inlined_pretty_sprint_at_2480_10607);
    _options_inlined_pretty_sprint_at_2480_10607 = NOVALUE;

    /** 						while ep != 0 with entry do*/
    goto L54; // [2510] 2533
L55: 
    if (_ep_10170 == 0)
    goto L56; // [2515] 2545

    /** 							argtext = remove(argtext, ep+2)*/
    _5893 = _ep_10170 + 2;
    if ((long)((unsigned long)_5893 + (unsigned long)HIGH_BITS) >= 0) 
    _5893 = NewDouble((double)_5893);
    {
        s1_ptr assign_space = SEQ_PTR(_argtext_10323);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_5893)) ? _5893 : (long)(DBL_PTR(_5893)->dbl);
        int stop = (IS_ATOM_INT(_5893)) ? _5893 : (long)(DBL_PTR(_5893)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_argtext_10323), start, &_argtext_10323 );
            }
            else Tail(SEQ_PTR(_argtext_10323), stop+1, &_argtext_10323);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_argtext_10323), start, &_argtext_10323);
        }
        else {
            assign_slice_seq = &assign_space;
            _argtext_10323 = Remove_elements(start, stop, (SEQ_PTR(_argtext_10323)->ref == 1));
        }
    }
    DeRef(_5893);
    _5893 = NOVALUE;
    _5893 = NOVALUE;

    /** 						entry*/
L54: 

    /** 							ep = match("e+0", argtext)*/
    _ep_10170 = e_match_from(_5811, _argtext_10323, 1);

    /** 						end while*/
    goto L55; // [2542] 2513
L56: 
L27: 

    /** 	    			currargv = arg_list[argn]*/
    DeRef(_currargv_10166);
    _2 = (int)SEQ_PTR(_arg_list_10141);
    _currargv_10166 = (int)*(((s1_ptr)_2)->base + _argn_10158);
    Ref(_currargv_10166);
L24: 

    /**     			if length(argtext) > 0 then*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5897 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5897 = 1;
    }
    if (_5897 <= 0)
    goto L57; // [2558] 3328

    /**     				switch cap do*/
    _0 = _cap_10147;
    switch ( _0 ){ 

        /**     					case 'u' then*/
        case 117:

        /**     						argtext = upper(argtext)*/
        RefDS(_argtext_10323);
        _0 = _argtext_10323;
        _argtext_10323 = _12upper(_argtext_10323);
        DeRefDS(_0);
        goto L58; // [2583] 2649

        /**     					case 'l' then*/
        case 108:

        /**     						argtext = lower(argtext)*/
        RefDS(_argtext_10323);
        _0 = _argtext_10323;
        _argtext_10323 = _12lower(_argtext_10323);
        DeRefDS(_0);
        goto L58; // [2597] 2649

        /**     					case 'w' then*/
        case 119:

        /**     						argtext = proper(argtext)*/
        RefDS(_argtext_10323);
        _0 = _argtext_10323;
        _argtext_10323 = _12proper(_argtext_10323);
        DeRefDS(_0);
        goto L58; // [2611] 2649

        /**     					case 0 then*/
        case 0:

        /** 							cap = cap*/
        _cap_10147 = _cap_10147;
        goto L58; // [2622] 2649

        /**     					case else*/
        default:

        /**     						error:crash("logic error: 'cap' mode in format.")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_2631_10630);
        _msg_inlined_crash_at_2631_10630 = EPrintf(-9999999, _5904, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_2631_10630);

        /** end procedure*/
        goto L59; // [2643] 2646
L59: 
        DeRefi(_msg_inlined_crash_at_2631_10630);
        _msg_inlined_crash_at_2631_10630 = NOVALUE;
    ;}L58: 

    /** 					if atom(currargv) then*/
    _5905 = IS_ATOM(_currargv_10166);
    if (_5905 == 0)
    {
        _5905 = NOVALUE;
        goto L5A; // [2656] 2795
    }
    else{
        _5905 = NOVALUE;
    }

    /** 						if find('e', argtext) = 0 then*/
    _5906 = find_from(101, _argtext_10323, 1);
    if (_5906 != 0)
    goto L5B; // [2666] 2794

    /** 							if decs != -1 then*/
    if (_decs_10156 == -1)
    goto L5C; // [2674] 2793

    /** 								pos = find('.', argtext)*/
    _pos_10157 = find_from(46, _argtext_10323, 1);

    /** 								if pos then*/
    if (_pos_10157 == 0)
    {
        goto L5D; // [2687] 2772
    }
    else{
    }

    /** 									if decs = 0 then*/
    if (_decs_10156 != 0)
    goto L5E; // [2692] 2710

    /** 										argtext = argtext [1 .. pos-1 ]*/
    _5911 = _pos_10157 - 1;
    rhs_slice_target = (object_ptr)&_argtext_10323;
    RHS_Slice(_argtext_10323, 1, _5911);
    goto L5F; // [2707] 2792
L5E: 

    /** 										pos = length(argtext) - pos*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5913 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5913 = 1;
    }
    _pos_10157 = _5913 - _pos_10157;
    _5913 = NOVALUE;

    /** 										if pos > decs then*/
    if (_pos_10157 <= _decs_10156)
    goto L60; // [2721] 2746

    /** 											argtext = argtext[ 1 .. $ - pos + decs ]*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5916 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5916 = 1;
    }
    _5917 = _5916 - _pos_10157;
    if ((long)((unsigned long)_5917 +(unsigned long) HIGH_BITS) >= 0){
        _5917 = NewDouble((double)_5917);
    }
    _5916 = NOVALUE;
    if (IS_ATOM_INT(_5917)) {
        _5918 = _5917 + _decs_10156;
    }
    else {
        _5918 = NewDouble(DBL_PTR(_5917)->dbl + (double)_decs_10156);
    }
    DeRef(_5917);
    _5917 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_10323;
    RHS_Slice(_argtext_10323, 1, _5918);
    goto L5F; // [2743] 2792
L60: 

    /** 										elsif pos < decs then*/
    if (_pos_10157 >= _decs_10156)
    goto L5F; // [2748] 2792

    /** 											argtext = argtext & repeat('0', decs - pos)*/
    _5921 = _decs_10156 - _pos_10157;
    _5922 = Repeat(48, _5921);
    _5921 = NOVALUE;
    Concat((object_ptr)&_argtext_10323, _argtext_10323, _5922);
    DeRefDS(_5922);
    _5922 = NOVALUE;
    goto L5F; // [2769] 2792
L5D: 

    /** 								elsif decs > 0 then*/
    if (_decs_10156 <= 0)
    goto L61; // [2774] 2791

    /** 									argtext = argtext & '.' & repeat('0', decs)*/
    _5925 = Repeat(48, _decs_10156);
    {
        int concat_list[3];

        concat_list[0] = _5925;
        concat_list[1] = 46;
        concat_list[2] = _argtext_10323;
        Concat_N((object_ptr)&_argtext_10323, concat_list, 3);
    }
    DeRefDS(_5925);
    _5925 = NOVALUE;
L61: 
L5F: 
L5C: 
L5B: 
L5A: 

    /**     				if align = 0 then*/
    if (_align_10148 != 0)
    goto L62; // [2799] 2826

    /**     					if atom(currargv) then*/
    _5928 = IS_ATOM(_currargv_10166);
    if (_5928 == 0)
    {
        _5928 = NOVALUE;
        goto L63; // [2808] 2819
    }
    else{
        _5928 = NOVALUE;
    }

    /**     						align = '>'*/
    _align_10148 = 62;
    goto L64; // [2816] 2825
L63: 

    /**     						align = '<'*/
    _align_10148 = 60;
L64: 
L62: 

    /**     				if atom(currargv) then*/
    _5929 = IS_ATOM(_currargv_10166);
    if (_5929 == 0)
    {
        _5929 = NOVALUE;
        goto L65; // [2831] 3032
    }
    else{
        _5929 = NOVALUE;
    }

    /** 	    				if tsep != 0 and zfill = 0 then*/
    _5930 = (_tsep_10163 != 0);
    if (_5930 == 0) {
        goto L66; // [2842] 3029
    }
    _5932 = (_zfill_10151 == 0);
    if (_5932 == 0)
    {
        DeRef(_5932);
        _5932 = NOVALUE;
        goto L66; // [2853] 3029
    }
    else{
        DeRef(_5932);
        _5932 = NOVALUE;
    }

    /** 	    					integer dpos*/

    /** 	    					integer dist*/

    /** 	    					integer bracketed*/

    /** 	    					if binout or hexout then*/
    if (_binout_10162 != 0) {
        goto L67; // [2866] 2875
    }
    if (_hexout_10161 == 0)
    {
        goto L68; // [2871] 2883
    }
    else{
    }
L67: 

    /** 	    						dist = 4*/
    _dist_10674 = 4;
    goto L69; // [2880] 2889
L68: 

    /** 	    						dist = 3*/
    _dist_10674 = 3;
L69: 

    /** 	    					bracketed = (argtext[1] = '(')*/
    _2 = (int)SEQ_PTR(_argtext_10323);
    _5934 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_5934)) {
        _bracketed_10675 = (_5934 == 40);
    }
    else {
        _bracketed_10675 = binary_op(EQUALS, _5934, 40);
    }
    _5934 = NOVALUE;
    if (!IS_ATOM_INT(_bracketed_10675)) {
        _1 = (long)(DBL_PTR(_bracketed_10675)->dbl);
        DeRefDS(_bracketed_10675);
        _bracketed_10675 = _1;
    }

    /** 	    					if bracketed then*/
    if (_bracketed_10675 == 0)
    {
        goto L6A; // [2903] 2921
    }
    else{
    }

    /** 	    						argtext = argtext[2 .. $-1]*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5936 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5936 = 1;
    }
    _5937 = _5936 - 1;
    _5936 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_10323;
    RHS_Slice(_argtext_10323, 2, _5937);
L6A: 

    /** 	    					dpos = find('.', argtext)*/
    _dpos_10673 = find_from(46, _argtext_10323, 1);

    /** 	    					if dpos = 0 then*/
    if (_dpos_10673 != 0)
    goto L6B; // [2930] 2946

    /** 	    						dpos = length(argtext) + 1*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5941 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5941 = 1;
    }
    _dpos_10673 = _5941 + 1;
    _5941 = NOVALUE;
    goto L6C; // [2943] 2960
L6B: 

    /** 	    						if tsep = '.' then*/
    if (_tsep_10163 != 46)
    goto L6D; // [2948] 2959

    /** 	    							argtext[dpos] = ','*/
    _2 = (int)SEQ_PTR(_argtext_10323);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _argtext_10323 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _dpos_10673);
    _1 = *(int *)_2;
    *(int *)_2 = 44;
    DeRef(_1);
L6D: 
L6C: 

    /** 	    					while dpos > dist do*/
L6E: 
    if (_dpos_10673 <= _dist_10674)
    goto L6F; // [2967] 3014

    /** 	    						dpos -= dist*/
    _dpos_10673 = _dpos_10673 - _dist_10674;

    /** 	    						if dpos > 1 then*/
    if (_dpos_10673 <= 1)
    goto L6E; // [2979] 2965

    /** 	    							argtext = argtext[1.. dpos - 1] & tsep & argtext[dpos .. $]*/
    _5947 = _dpos_10673 - 1;
    rhs_slice_target = (object_ptr)&_5948;
    RHS_Slice(_argtext_10323, 1, _5947);
    if (IS_SEQUENCE(_argtext_10323)){
            _5949 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5949 = 1;
    }
    rhs_slice_target = (object_ptr)&_5950;
    RHS_Slice(_argtext_10323, _dpos_10673, _5949);
    {
        int concat_list[3];

        concat_list[0] = _5950;
        concat_list[1] = _tsep_10163;
        concat_list[2] = _5948;
        Concat_N((object_ptr)&_argtext_10323, concat_list, 3);
    }
    DeRefDS(_5950);
    _5950 = NOVALUE;
    DeRefDS(_5948);
    _5948 = NOVALUE;

    /** 	    					end while*/
    goto L6E; // [3011] 2965
L6F: 

    /** 	    					if bracketed then*/
    if (_bracketed_10675 == 0)
    {
        goto L70; // [3016] 3028
    }
    else{
    }

    /** 	    						argtext = '(' & argtext & ')'*/
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _argtext_10323;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10323, concat_list, 3);
    }
L70: 
L66: 
L65: 

    /**     				if width <= 0 then*/
    if (_width_10155 > 0)
    goto L71; // [3036] 3046

    /**     					width = length(argtext)*/
    if (IS_SEQUENCE(_argtext_10323)){
            _width_10155 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _width_10155 = 1;
    }
L71: 

    /**     				if width < length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5955 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5955 = 1;
    }
    if (_width_10155 >= _5955)
    goto L72; // [3051] 3182

    /**     					if align = '>' then*/
    if (_align_10148 != 62)
    goto L73; // [3057] 3085

    /**     						argtext = argtext[ $ - width + 1 .. $]*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5958 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5958 = 1;
    }
    _5959 = _5958 - _width_10155;
    if ((long)((unsigned long)_5959 +(unsigned long) HIGH_BITS) >= 0){
        _5959 = NewDouble((double)_5959);
    }
    _5958 = NOVALUE;
    if (IS_ATOM_INT(_5959)) {
        _5960 = _5959 + 1;
        if (_5960 > MAXINT){
            _5960 = NewDouble((double)_5960);
        }
    }
    else
    _5960 = binary_op(PLUS, 1, _5959);
    DeRef(_5959);
    _5959 = NOVALUE;
    if (IS_SEQUENCE(_argtext_10323)){
            _5961 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5961 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_10323;
    RHS_Slice(_argtext_10323, _5960, _5961);
    goto L74; // [3082] 3319
L73: 

    /**     					elsif align = 'c' then*/
    if (_align_10148 != 99)
    goto L75; // [3087] 3171

    /**     						pos = length(argtext) - width*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5964 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5964 = 1;
    }
    _pos_10157 = _5964 - _width_10155;
    _5964 = NOVALUE;

    /**     						if remainder(pos, 2) = 0 then*/
    _5966 = (_pos_10157 % 2);
    if (_5966 != 0)
    goto L76; // [3106] 3139

    /**     							pos = pos / 2*/
    if (_pos_10157 & 1) {
        _pos_10157 = NewDouble((_pos_10157 >> 1) + 0.5);
    }
    else
    _pos_10157 = _pos_10157 >> 1;
    if (!IS_ATOM_INT(_pos_10157)) {
        _1 = (long)(DBL_PTR(_pos_10157)->dbl);
        DeRefDS(_pos_10157);
        _pos_10157 = _1;
    }

    /**     							argtext = argtext[ pos + 1 .. $ - pos ]*/
    _5969 = _pos_10157 + 1;
    if (_5969 > MAXINT){
        _5969 = NewDouble((double)_5969);
    }
    if (IS_SEQUENCE(_argtext_10323)){
            _5970 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5970 = 1;
    }
    _5971 = _5970 - _pos_10157;
    _5970 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_10323;
    RHS_Slice(_argtext_10323, _5969, _5971);
    goto L74; // [3136] 3319
L76: 

    /**     							pos = floor(pos / 2)*/
    _pos_10157 = _pos_10157 >> 1;

    /**     							argtext = argtext[ pos + 1 .. $ - pos - 1]*/
    _5974 = _pos_10157 + 1;
    if (_5974 > MAXINT){
        _5974 = NewDouble((double)_5974);
    }
    if (IS_SEQUENCE(_argtext_10323)){
            _5975 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5975 = 1;
    }
    _5976 = _5975 - _pos_10157;
    if ((long)((unsigned long)_5976 +(unsigned long) HIGH_BITS) >= 0){
        _5976 = NewDouble((double)_5976);
    }
    _5975 = NOVALUE;
    if (IS_ATOM_INT(_5976)) {
        _5977 = _5976 - 1;
    }
    else {
        _5977 = NewDouble(DBL_PTR(_5976)->dbl - (double)1);
    }
    DeRef(_5976);
    _5976 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_10323;
    RHS_Slice(_argtext_10323, _5974, _5977);
    goto L74; // [3168] 3319
L75: 

    /**     						argtext = argtext[ 1 .. width]*/
    rhs_slice_target = (object_ptr)&_argtext_10323;
    RHS_Slice(_argtext_10323, 1, _width_10155);
    goto L74; // [3179] 3319
L72: 

    /**     				elsif width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5980 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5980 = 1;
    }
    if (_width_10155 <= _5980)
    goto L77; // [3187] 3318

    /** 						if align = '>' then*/
    if (_align_10148 != 62)
    goto L78; // [3193] 3217

    /** 							argtext = repeat(' ', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5983 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5983 = 1;
    }
    _5984 = _width_10155 - _5983;
    _5983 = NOVALUE;
    _5985 = Repeat(32, _5984);
    _5984 = NOVALUE;
    Concat((object_ptr)&_argtext_10323, _5985, _argtext_10323);
    DeRefDS(_5985);
    _5985 = NOVALUE;
    DeRef(_5985);
    _5985 = NOVALUE;
    goto L79; // [3214] 3317
L78: 

    /**     					elsif align = 'c' then*/
    if (_align_10148 != 99)
    goto L7A; // [3219] 3299

    /**     						pos = width - length(argtext)*/
    if (IS_SEQUENCE(_argtext_10323)){
            _5988 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _5988 = 1;
    }
    _pos_10157 = _width_10155 - _5988;
    _5988 = NOVALUE;

    /**     						if remainder(pos, 2) = 0 then*/
    _5990 = (_pos_10157 % 2);
    if (_5990 != 0)
    goto L7B; // [3238] 3269

    /**     							pos = pos / 2*/
    if (_pos_10157 & 1) {
        _pos_10157 = NewDouble((_pos_10157 >> 1) + 0.5);
    }
    else
    _pos_10157 = _pos_10157 >> 1;
    if (!IS_ATOM_INT(_pos_10157)) {
        _1 = (long)(DBL_PTR(_pos_10157)->dbl);
        DeRefDS(_pos_10157);
        _pos_10157 = _1;
    }

    /**     							argtext = repeat(' ', pos) & argtext & repeat(' ', pos)*/
    _5993 = Repeat(32, _pos_10157);
    _5994 = Repeat(32, _pos_10157);
    {
        int concat_list[3];

        concat_list[0] = _5994;
        concat_list[1] = _argtext_10323;
        concat_list[2] = _5993;
        Concat_N((object_ptr)&_argtext_10323, concat_list, 3);
    }
    DeRefDS(_5994);
    _5994 = NOVALUE;
    DeRefDS(_5993);
    _5993 = NOVALUE;
    goto L79; // [3266] 3317
L7B: 

    /**     							pos = floor(pos / 2)*/
    _pos_10157 = _pos_10157 >> 1;

    /**     							argtext = repeat(' ', pos) & argtext & repeat(' ', pos + 1)*/
    _5997 = Repeat(32, _pos_10157);
    _5998 = _pos_10157 + 1;
    _5999 = Repeat(32, _5998);
    _5998 = NOVALUE;
    {
        int concat_list[3];

        concat_list[0] = _5999;
        concat_list[1] = _argtext_10323;
        concat_list[2] = _5997;
        Concat_N((object_ptr)&_argtext_10323, concat_list, 3);
    }
    DeRefDS(_5999);
    _5999 = NOVALUE;
    DeRefDS(_5997);
    _5997 = NOVALUE;
    goto L79; // [3296] 3317
L7A: 

    /** 							argtext = argtext & repeat(' ', width - length(argtext))*/
    if (IS_SEQUENCE(_argtext_10323)){
            _6001 = SEQ_PTR(_argtext_10323)->length;
    }
    else {
        _6001 = 1;
    }
    _6002 = _width_10155 - _6001;
    _6001 = NOVALUE;
    _6003 = Repeat(32, _6002);
    _6002 = NOVALUE;
    Concat((object_ptr)&_argtext_10323, _argtext_10323, _6003);
    DeRefDS(_6003);
    _6003 = NOVALUE;
L79: 
L77: 
L74: 

    /**     				result &= argtext*/
    Concat((object_ptr)&_result_10142, _result_10142, _argtext_10323);
    goto L7C; // [3325] 3341
L57: 

    /**     				if spacer then*/
    if (_spacer_10153 == 0)
    {
        goto L7D; // [3330] 3340
    }
    else{
    }

    /**     					result &= ' '*/
    Append(&_result_10142, _result_10142, 32);
L7D: 
L7C: 

    /**    				if trimming then*/
    if (_trimming_10160 == 0)
    {
        goto L7E; // [3345] 3359
    }
    else{
    }

    /**    					result = trim(result)*/
    RefDS(_result_10142);
    RefDS(_4538);
    _0 = _result_10142;
    _result_10142 = _12trim(_result_10142, _4538, 0);
    DeRefDS(_0);
L7E: 

    /**     			tend = 0*/
    _tend_10146 = 0;

    /** 		    	prevargv = currargv*/
    Ref(_currargv_10166);
    DeRef(_prevargv_10165);
    _prevargv_10165 = _currargv_10166;
L1F: 
    DeRef(_argtext_10323);
    _argtext_10323 = NOVALUE;

    /**     end while*/
    goto L2; // [3377] 60
L3: 

    /** 	return result*/
    DeRefDS(_format_pattern_10140);
    DeRef(_arg_list_10141);
    DeRef(_prevargv_10165);
    DeRef(_currargv_10166);
    DeRef(_idname_10167);
    DeRef(_envsym_10168);
    DeRefi(_envvar_10169);
    DeRef(_5694);
    _5694 = NOVALUE;
    DeRef(_5960);
    _5960 = NOVALUE;
    DeRef(_5977);
    _5977 = NOVALUE;
    DeRef(_5706);
    _5706 = NOVALUE;
    DeRef(_5777);
    _5777 = NOVALUE;
    DeRef(_5850);
    _5850 = NOVALUE;
    DeRef(_5911);
    _5911 = NOVALUE;
    DeRef(_5974);
    _5974 = NOVALUE;
    DeRef(_5734);
    _5734 = NOVALUE;
    DeRef(_5930);
    _5930 = NOVALUE;
    DeRef(_5937);
    _5937 = NOVALUE;
    DeRef(_5947);
    _5947 = NOVALUE;
    DeRef(_5966);
    _5966 = NOVALUE;
    DeRef(_5716);
    _5716 = NOVALUE;
    DeRef(_5795);
    _5795 = NOVALUE;
    DeRef(_5918);
    _5918 = NOVALUE;
    DeRef(_5971);
    _5971 = NOVALUE;
    DeRef(_5644);
    _5644 = NOVALUE;
    DeRef(_5872);
    _5872 = NOVALUE;
    DeRef(_5882);
    _5882 = NOVALUE;
    DeRef(_5990);
    _5990 = NOVALUE;
    DeRef(_5813);
    _5813 = NOVALUE;
    _5852 = NOVALUE;
    DeRef(_5969);
    _5969 = NOVALUE;
    DeRef(_5667);
    _5667 = NOVALUE;
    return _result_10142;
    ;
}



// 0x43FF2CD6
