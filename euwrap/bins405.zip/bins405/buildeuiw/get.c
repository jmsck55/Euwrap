// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _17get_ch()
{
    int _1425 = NOVALUE;
    int _1424 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(input_string) then*/
    _1424 = IS_SEQUENCE(_17input_string_3127);
    if (_1424 == 0)
    {
        _1424 = NOVALUE;
        goto L1; // [8] 56
    }
    else{
        _1424 = NOVALUE;
    }

    /** 		if string_next <= length(input_string) then*/
    if (IS_SEQUENCE(_17input_string_3127)){
            _1425 = SEQ_PTR(_17input_string_3127)->length;
    }
    else {
        _1425 = 1;
    }
    if (_17string_next_3128 > _1425)
    goto L2; // [20] 47

    /** 			ch = input_string[string_next]*/
    _2 = (int)SEQ_PTR(_17input_string_3127);
    _17ch_3129 = (int)*(((s1_ptr)_2)->base + _17string_next_3128);
    if (!IS_ATOM_INT(_17ch_3129)){
        _17ch_3129 = (long)DBL_PTR(_17ch_3129)->dbl;
    }

    /** 			string_next += 1*/
    _17string_next_3128 = _17string_next_3128 + 1;
    goto L3; // [44] 81
L2: 

    /** 			ch = GET_EOF*/
    _17ch_3129 = -1;
    goto L3; // [53] 81
L1: 

    /** 		ch = getc(input_file)*/
    if (_17input_file_3126 != last_r_file_no) {
        last_r_file_ptr = which_file(_17input_file_3126, EF_READ);
        last_r_file_no = _17input_file_3126;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _17ch_3129 = getKBchar();
        }
        else
        _17ch_3129 = getc(last_r_file_ptr);
    }
    else
    _17ch_3129 = getc(last_r_file_ptr);

    /** 		if ch = GET_EOF then*/
    if (_17ch_3129 != -1)
    goto L4; // [67] 80

    /** 			string_next += 1*/
    _17string_next_3128 = _17string_next_3128 + 1;
L4: 
L3: 

    /** end procedure*/
    return;
    ;
}


int _17escape_char(int _c_3156)
{
    int _i_3157 = NOVALUE;
    int _1437 = NOVALUE;
    int _0, _1, _2;
    

    /** 	i = find(c, ESCAPE_CHARS)*/
    _i_3157 = find_from(_c_3156, _17ESCAPE_CHARS_3150, 1);

    /** 	if i = 0 then*/
    if (_i_3157 != 0)
    goto L1; // [12] 25

    /** 		return GET_FAIL*/
    return 1;
    goto L2; // [22] 36
L1: 

    /** 		return ESCAPED_CHARS[i]*/
    _2 = (int)SEQ_PTR(_17ESCAPED_CHARS_3152);
    _1437 = (int)*(((s1_ptr)_2)->base + _i_3157);
    Ref(_1437);
    return _1437;
L2: 
    ;
}


int _17get_qchar()
{
    int _c_3165 = NOVALUE;
    int _1446 = NOVALUE;
    int _1445 = NOVALUE;
    int _1443 = NOVALUE;
    int _1441 = NOVALUE;
    int _0, _1, _2;
    

    /** 	get_ch()*/
    _17get_ch();

    /** 	c = ch*/
    _c_3165 = _17ch_3129;

    /** 	if ch = '\\' then*/
    if (_17ch_3129 != 92)
    goto L1; // [16] 54

    /** 		get_ch()*/
    _17get_ch();

    /** 		c = escape_char(ch)*/
    _c_3165 = _17escape_char(_17ch_3129);
    if (!IS_ATOM_INT(_c_3165)) {
        _1 = (long)(DBL_PTR(_c_3165)->dbl);
        DeRefDS(_c_3165);
        _c_3165 = _1;
    }

    /** 		if c = GET_FAIL then*/
    if (_c_3165 != 1)
    goto L2; // [36] 74

    /** 			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1441 = MAKE_SEQ(_1);
    return _1441;
    goto L2; // [51] 74
L1: 

    /** 	elsif ch = '\'' then*/
    if (_17ch_3129 != 39)
    goto L3; // [58] 73

    /** 		return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1443 = MAKE_SEQ(_1);
    DeRef(_1441);
    _1441 = NOVALUE;
    return _1443;
L3: 
L2: 

    /** 	get_ch()*/
    _17get_ch();

    /** 	if ch != '\'' then*/
    if (_17ch_3129 == 39)
    goto L4; // [82] 99

    /** 		return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1445 = MAKE_SEQ(_1);
    DeRef(_1441);
    _1441 = NOVALUE;
    DeRef(_1443);
    _1443 = NOVALUE;
    return _1445;
    goto L5; // [96] 114
L4: 

    /** 		get_ch()*/
    _17get_ch();

    /** 		return {GET_SUCCESS, c}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _c_3165;
    _1446 = MAKE_SEQ(_1);
    DeRef(_1441);
    _1441 = NOVALUE;
    DeRef(_1443);
    _1443 = NOVALUE;
    DeRef(_1445);
    _1445 = NOVALUE;
    return _1446;
L5: 
    ;
}


int _17get_string()
{
    int _text_3182 = NOVALUE;
    int _1456 = NOVALUE;
    int _1452 = NOVALUE;
    int _1450 = NOVALUE;
    int _1449 = NOVALUE;
    int _1447 = NOVALUE;
    int _0, _1, _2;
    

    /** 	text = ""*/
    RefDS(_5);
    DeRefi(_text_3182);
    _text_3182 = _5;

    /** 	while TRUE do*/
L1: 

    /** 		get_ch()*/
    _17get_ch();

    /** 		if ch = GET_EOF or ch = '\n' then*/
    _1447 = (_17ch_3129 == -1);
    if (_1447 != 0) {
        goto L2; // [25] 40
    }
    _1449 = (_17ch_3129 == 10);
    if (_1449 == 0)
    {
        DeRef(_1449);
        _1449 = NOVALUE;
        goto L3; // [36] 53
    }
    else{
        DeRef(_1449);
        _1449 = NOVALUE;
    }
L2: 

    /** 			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1450 = MAKE_SEQ(_1);
    DeRefi(_text_3182);
    DeRef(_1447);
    _1447 = NOVALUE;
    return _1450;
    goto L4; // [50] 121
L3: 

    /** 		elsif ch = '"' then*/
    if (_17ch_3129 != 34)
    goto L5; // [57] 78

    /** 			get_ch()*/
    _17get_ch();

    /** 			return {GET_SUCCESS, text}*/
    RefDS(_text_3182);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _text_3182;
    _1452 = MAKE_SEQ(_1);
    DeRefDSi(_text_3182);
    DeRef(_1447);
    _1447 = NOVALUE;
    DeRef(_1450);
    _1450 = NOVALUE;
    return _1452;
    goto L4; // [75] 121
L5: 

    /** 		elsif ch = '\\' then*/
    if (_17ch_3129 != 92)
    goto L6; // [82] 120

    /** 			get_ch()*/
    _17get_ch();

    /** 			ch = escape_char(ch)*/
    _0 = _17escape_char(_17ch_3129);
    _17ch_3129 = _0;
    if (!IS_ATOM_INT(_17ch_3129)) {
        _1 = (long)(DBL_PTR(_17ch_3129)->dbl);
        DeRefDS(_17ch_3129);
        _17ch_3129 = _1;
    }

    /** 			if ch = GET_FAIL then*/
    if (_17ch_3129 != 1)
    goto L7; // [104] 119

    /** 				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1456 = MAKE_SEQ(_1);
    DeRefi(_text_3182);
    DeRef(_1447);
    _1447 = NOVALUE;
    DeRef(_1450);
    _1450 = NOVALUE;
    DeRef(_1452);
    _1452 = NOVALUE;
    return _1456;
L7: 
L6: 
L4: 

    /** 		text = text & ch*/
    Append(&_text_3182, _text_3182, _17ch_3129);

    /** 	end while*/
    goto L1; // [131] 13
    ;
}


int _17read_comment()
{
    int _1477 = NOVALUE;
    int _1476 = NOVALUE;
    int _1474 = NOVALUE;
    int _1472 = NOVALUE;
    int _1470 = NOVALUE;
    int _1469 = NOVALUE;
    int _1468 = NOVALUE;
    int _1466 = NOVALUE;
    int _1465 = NOVALUE;
    int _1464 = NOVALUE;
    int _1463 = NOVALUE;
    int _1462 = NOVALUE;
    int _1461 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(input_string) then*/
    _1461 = IS_ATOM(_17input_string_3127);
    if (_1461 == 0)
    {
        _1461 = NOVALUE;
        goto L1; // [8] 98
    }
    else{
        _1461 = NOVALUE;
    }

    /** 		while ch!='\n' and ch!='\r' and ch!=-1 do*/
L2: 
    _1462 = (_17ch_3129 != 10);
    if (_1462 == 0) {
        _1463 = 0;
        goto L3; // [22] 36
    }
    _1464 = (_17ch_3129 != 13);
    _1463 = (_1464 != 0);
L3: 
    if (_1463 == 0) {
        goto L4; // [36] 59
    }
    _1466 = (_17ch_3129 != -1);
    if (_1466 == 0)
    {
        DeRef(_1466);
        _1466 = NOVALUE;
        goto L4; // [47] 59
    }
    else{
        DeRef(_1466);
        _1466 = NOVALUE;
    }

    /** 			get_ch()*/
    _17get_ch();

    /** 		end while*/
    goto L2; // [56] 16
L4: 

    /** 		get_ch()*/
    _17get_ch();

    /** 		if ch=-1 then*/
    if (_17ch_3129 != -1)
    goto L5; // [67] 84

    /** 			return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _1468 = MAKE_SEQ(_1);
    DeRef(_1462);
    _1462 = NOVALUE;
    DeRef(_1464);
    _1464 = NOVALUE;
    return _1468;
    goto L6; // [81] 182
L5: 

    /** 			return {GET_IGNORE, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -2;
    ((int *)_2)[2] = 0;
    _1469 = MAKE_SEQ(_1);
    DeRef(_1462);
    _1462 = NOVALUE;
    DeRef(_1464);
    _1464 = NOVALUE;
    DeRef(_1468);
    _1468 = NOVALUE;
    return _1469;
    goto L6; // [95] 182
L1: 

    /** 		for i=string_next to length(input_string) do*/
    if (IS_SEQUENCE(_17input_string_3127)){
            _1470 = SEQ_PTR(_17input_string_3127)->length;
    }
    else {
        _1470 = 1;
    }
    {
        int _i_3223;
        _i_3223 = _17string_next_3128;
L7: 
        if (_i_3223 > _1470){
            goto L8; // [107] 171
        }

        /** 			ch=input_string[i]*/
        _2 = (int)SEQ_PTR(_17input_string_3127);
        _17ch_3129 = (int)*(((s1_ptr)_2)->base + _i_3223);
        if (!IS_ATOM_INT(_17ch_3129)){
            _17ch_3129 = (long)DBL_PTR(_17ch_3129)->dbl;
        }

        /** 			if ch='\n' or ch='\r' then*/
        _1472 = (_17ch_3129 == 10);
        if (_1472 != 0) {
            goto L9; // [132] 147
        }
        _1474 = (_17ch_3129 == 13);
        if (_1474 == 0)
        {
            DeRef(_1474);
            _1474 = NOVALUE;
            goto LA; // [143] 164
        }
        else{
            DeRef(_1474);
            _1474 = NOVALUE;
        }
L9: 

        /** 				string_next=i+1*/
        _17string_next_3128 = _i_3223 + 1;

        /** 				return {GET_IGNORE, 0}*/
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -2;
        ((int *)_2)[2] = 0;
        _1476 = MAKE_SEQ(_1);
        DeRef(_1462);
        _1462 = NOVALUE;
        DeRef(_1464);
        _1464 = NOVALUE;
        DeRef(_1468);
        _1468 = NOVALUE;
        DeRef(_1469);
        _1469 = NOVALUE;
        DeRef(_1472);
        _1472 = NOVALUE;
        return _1476;
LA: 

        /** 		end for*/
        _i_3223 = _i_3223 + 1;
        goto L7; // [166] 114
L8: 
        ;
    }

    /** 		return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _1477 = MAKE_SEQ(_1);
    DeRef(_1462);
    _1462 = NOVALUE;
    DeRef(_1464);
    _1464 = NOVALUE;
    DeRef(_1468);
    _1468 = NOVALUE;
    DeRef(_1469);
    _1469 = NOVALUE;
    DeRef(_1472);
    _1472 = NOVALUE;
    DeRef(_1476);
    _1476 = NOVALUE;
    return _1477;
L6: 
    ;
}


int _17get_number()
{
    int _sign_3235 = NOVALUE;
    int _e_sign_3236 = NOVALUE;
    int _ndigits_3237 = NOVALUE;
    int _hex_digit_3238 = NOVALUE;
    int _mantissa_3239 = NOVALUE;
    int _dec_3240 = NOVALUE;
    int _e_mag_3241 = NOVALUE;
    int _1539 = NOVALUE;
    int _1537 = NOVALUE;
    int _1535 = NOVALUE;
    int _1531 = NOVALUE;
    int _1527 = NOVALUE;
    int _1525 = NOVALUE;
    int _1524 = NOVALUE;
    int _1523 = NOVALUE;
    int _1522 = NOVALUE;
    int _1521 = NOVALUE;
    int _1519 = NOVALUE;
    int _1518 = NOVALUE;
    int _1517 = NOVALUE;
    int _1514 = NOVALUE;
    int _1512 = NOVALUE;
    int _1510 = NOVALUE;
    int _1506 = NOVALUE;
    int _1505 = NOVALUE;
    int _1503 = NOVALUE;
    int _1502 = NOVALUE;
    int _1501 = NOVALUE;
    int _1498 = NOVALUE;
    int _1497 = NOVALUE;
    int _1495 = NOVALUE;
    int _1494 = NOVALUE;
    int _1493 = NOVALUE;
    int _1492 = NOVALUE;
    int _1491 = NOVALUE;
    int _1490 = NOVALUE;
    int _1487 = NOVALUE;
    int _1483 = NOVALUE;
    int _1480 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sign = +1*/
    _sign_3235 = 1;

    /** 	mantissa = 0*/
    DeRef(_mantissa_3239);
    _mantissa_3239 = 0;

    /** 	ndigits = 0*/
    _ndigits_3237 = 0;

    /** 	if ch = '-' then*/
    if (_17ch_3129 != 45)
    goto L1; // [20] 54

    /** 		sign = -1*/
    _sign_3235 = -1;

    /** 		get_ch()*/
    _17get_ch();

    /** 		if ch='-' then*/
    if (_17ch_3129 != 45)
    goto L2; // [37] 68

    /** 			return read_comment()*/
    _1480 = _17read_comment();
    DeRef(_dec_3240);
    DeRef(_e_mag_3241);
    return _1480;
    goto L2; // [51] 68
L1: 

    /** 	elsif ch = '+' then*/
    if (_17ch_3129 != 43)
    goto L3; // [58] 67

    /** 		get_ch()*/
    _17get_ch();
L3: 
L2: 

    /** 	if ch = '#' then*/
    if (_17ch_3129 != 35)
    goto L4; // [72] 170

    /** 		get_ch()*/
    _17get_ch();

    /** 		while TRUE do*/
L5: 

    /** 			hex_digit = find(ch, HEX_DIGITS)-1*/
    _1483 = find_from(_17ch_3129, _17HEX_DIGITS_3109, 1);
    _hex_digit_3238 = _1483 - 1;
    _1483 = NOVALUE;

    /** 			if hex_digit >= 0 then*/
    if (_hex_digit_3238 < 0)
    goto L6; // [102] 129

    /** 				ndigits += 1*/
    _ndigits_3237 = _ndigits_3237 + 1;

    /** 				mantissa = mantissa * 16 + hex_digit*/
    if (IS_ATOM_INT(_mantissa_3239)) {
        if (_mantissa_3239 == (short)_mantissa_3239)
        _1487 = _mantissa_3239 * 16;
        else
        _1487 = NewDouble(_mantissa_3239 * (double)16);
    }
    else {
        _1487 = NewDouble(DBL_PTR(_mantissa_3239)->dbl * (double)16);
    }
    DeRef(_mantissa_3239);
    if (IS_ATOM_INT(_1487)) {
        _mantissa_3239 = _1487 + _hex_digit_3238;
        if ((long)((unsigned long)_mantissa_3239 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_3239 = NewDouble((double)_mantissa_3239);
    }
    else {
        _mantissa_3239 = NewDouble(DBL_PTR(_1487)->dbl + (double)_hex_digit_3238);
    }
    DeRef(_1487);
    _1487 = NOVALUE;

    /** 				get_ch()*/
    _17get_ch();
    goto L5; // [126] 85
L6: 

    /** 				if ndigits > 0 then*/
    if (_ndigits_3237 <= 0)
    goto L7; // [131] 152

    /** 					return {GET_SUCCESS, sign * mantissa}*/
    if (IS_ATOM_INT(_mantissa_3239)) {
        if (_sign_3235 == (short)_sign_3235 && _mantissa_3239 <= INT15 && _mantissa_3239 >= -INT15)
        _1490 = _sign_3235 * _mantissa_3239;
        else
        _1490 = NewDouble(_sign_3235 * (double)_mantissa_3239);
    }
    else {
        _1490 = NewDouble((double)_sign_3235 * DBL_PTR(_mantissa_3239)->dbl);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _1490;
    _1491 = MAKE_SEQ(_1);
    _1490 = NOVALUE;
    DeRef(_mantissa_3239);
    DeRef(_dec_3240);
    DeRef(_e_mag_3241);
    DeRef(_1480);
    _1480 = NOVALUE;
    return _1491;
    goto L5; // [149] 85
L7: 

    /** 					return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1492 = MAKE_SEQ(_1);
    DeRef(_mantissa_3239);
    DeRef(_dec_3240);
    DeRef(_e_mag_3241);
    DeRef(_1480);
    _1480 = NOVALUE;
    DeRef(_1491);
    _1491 = NOVALUE;
    return _1492;

    /** 		end while*/
    goto L5; // [166] 85
L4: 

    /** 	while ch >= '0' and ch <= '9' do*/
L8: 
    _1493 = (_17ch_3129 >= 48);
    if (_1493 == 0) {
        goto L9; // [181] 226
    }
    _1495 = (_17ch_3129 <= 57);
    if (_1495 == 0)
    {
        DeRef(_1495);
        _1495 = NOVALUE;
        goto L9; // [192] 226
    }
    else{
        DeRef(_1495);
        _1495 = NOVALUE;
    }

    /** 		ndigits += 1*/
    _ndigits_3237 = _ndigits_3237 + 1;

    /** 		mantissa = mantissa * 10 + (ch - '0')*/
    if (IS_ATOM_INT(_mantissa_3239)) {
        if (_mantissa_3239 == (short)_mantissa_3239)
        _1497 = _mantissa_3239 * 10;
        else
        _1497 = NewDouble(_mantissa_3239 * (double)10);
    }
    else {
        _1497 = NewDouble(DBL_PTR(_mantissa_3239)->dbl * (double)10);
    }
    _1498 = _17ch_3129 - 48;
    if ((long)((unsigned long)_1498 +(unsigned long) HIGH_BITS) >= 0){
        _1498 = NewDouble((double)_1498);
    }
    DeRef(_mantissa_3239);
    if (IS_ATOM_INT(_1497) && IS_ATOM_INT(_1498)) {
        _mantissa_3239 = _1497 + _1498;
        if ((long)((unsigned long)_mantissa_3239 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_3239 = NewDouble((double)_mantissa_3239);
    }
    else {
        if (IS_ATOM_INT(_1497)) {
            _mantissa_3239 = NewDouble((double)_1497 + DBL_PTR(_1498)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1498)) {
                _mantissa_3239 = NewDouble(DBL_PTR(_1497)->dbl + (double)_1498);
            }
            else
            _mantissa_3239 = NewDouble(DBL_PTR(_1497)->dbl + DBL_PTR(_1498)->dbl);
        }
    }
    DeRef(_1497);
    _1497 = NOVALUE;
    DeRef(_1498);
    _1498 = NOVALUE;

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L8; // [223] 175
L9: 

    /** 	if ch = '.' then*/
    if (_17ch_3129 != 46)
    goto LA; // [230] 306

    /** 		get_ch()*/
    _17get_ch();

    /** 		dec = 10*/
    DeRef(_dec_3240);
    _dec_3240 = 10;

    /** 		while ch >= '0' and ch <= '9' do*/
LB: 
    _1501 = (_17ch_3129 >= 48);
    if (_1501 == 0) {
        goto LC; // [254] 305
    }
    _1503 = (_17ch_3129 <= 57);
    if (_1503 == 0)
    {
        DeRef(_1503);
        _1503 = NOVALUE;
        goto LC; // [265] 305
    }
    else{
        DeRef(_1503);
        _1503 = NOVALUE;
    }

    /** 			ndigits += 1*/
    _ndigits_3237 = _ndigits_3237 + 1;

    /** 			mantissa += (ch - '0') / dec*/
    _1505 = _17ch_3129 - 48;
    if ((long)((unsigned long)_1505 +(unsigned long) HIGH_BITS) >= 0){
        _1505 = NewDouble((double)_1505);
    }
    if (IS_ATOM_INT(_1505) && IS_ATOM_INT(_dec_3240)) {
        _1506 = (_1505 % _dec_3240) ? NewDouble((double)_1505 / _dec_3240) : (_1505 / _dec_3240);
    }
    else {
        if (IS_ATOM_INT(_1505)) {
            _1506 = NewDouble((double)_1505 / DBL_PTR(_dec_3240)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec_3240)) {
                _1506 = NewDouble(DBL_PTR(_1505)->dbl / (double)_dec_3240);
            }
            else
            _1506 = NewDouble(DBL_PTR(_1505)->dbl / DBL_PTR(_dec_3240)->dbl);
        }
    }
    DeRef(_1505);
    _1505 = NOVALUE;
    _0 = _mantissa_3239;
    if (IS_ATOM_INT(_mantissa_3239) && IS_ATOM_INT(_1506)) {
        _mantissa_3239 = _mantissa_3239 + _1506;
        if ((long)((unsigned long)_mantissa_3239 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_3239 = NewDouble((double)_mantissa_3239);
    }
    else {
        if (IS_ATOM_INT(_mantissa_3239)) {
            _mantissa_3239 = NewDouble((double)_mantissa_3239 + DBL_PTR(_1506)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1506)) {
                _mantissa_3239 = NewDouble(DBL_PTR(_mantissa_3239)->dbl + (double)_1506);
            }
            else
            _mantissa_3239 = NewDouble(DBL_PTR(_mantissa_3239)->dbl + DBL_PTR(_1506)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1506);
    _1506 = NOVALUE;

    /** 			dec *= 10*/
    _0 = _dec_3240;
    if (IS_ATOM_INT(_dec_3240)) {
        if (_dec_3240 == (short)_dec_3240)
        _dec_3240 = _dec_3240 * 10;
        else
        _dec_3240 = NewDouble(_dec_3240 * (double)10);
    }
    else {
        _dec_3240 = NewDouble(DBL_PTR(_dec_3240)->dbl * (double)10);
    }
    DeRef(_0);

    /** 			get_ch()*/
    _17get_ch();

    /** 		end while*/
    goto LB; // [302] 248
LC: 
LA: 

    /** 	if ndigits = 0 then*/
    if (_ndigits_3237 != 0)
    goto LD; // [308] 323

    /** 		return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1510 = MAKE_SEQ(_1);
    DeRef(_mantissa_3239);
    DeRef(_dec_3240);
    DeRef(_e_mag_3241);
    DeRef(_1480);
    _1480 = NOVALUE;
    DeRef(_1491);
    _1491 = NOVALUE;
    DeRef(_1492);
    _1492 = NOVALUE;
    DeRef(_1493);
    _1493 = NOVALUE;
    DeRef(_1501);
    _1501 = NOVALUE;
    return _1510;
LD: 

    /** 	mantissa = sign * mantissa*/
    _0 = _mantissa_3239;
    if (IS_ATOM_INT(_mantissa_3239)) {
        if (_sign_3235 == (short)_sign_3235 && _mantissa_3239 <= INT15 && _mantissa_3239 >= -INT15)
        _mantissa_3239 = _sign_3235 * _mantissa_3239;
        else
        _mantissa_3239 = NewDouble(_sign_3235 * (double)_mantissa_3239);
    }
    else {
        _mantissa_3239 = NewDouble((double)_sign_3235 * DBL_PTR(_mantissa_3239)->dbl);
    }
    DeRef(_0);

    /** 	if ch = 'e' or ch = 'E' then*/
    _1512 = (_17ch_3129 == 101);
    if (_1512 != 0) {
        goto LE; // [337] 352
    }
    _1514 = (_17ch_3129 == 69);
    if (_1514 == 0)
    {
        DeRef(_1514);
        _1514 = NOVALUE;
        goto LF; // [348] 573
    }
    else{
        DeRef(_1514);
        _1514 = NOVALUE;
    }
LE: 

    /** 		e_sign = +1*/
    _e_sign_3236 = 1;

    /** 		e_mag = 0*/
    DeRef(_e_mag_3241);
    _e_mag_3241 = 0;

    /** 		get_ch()*/
    _17get_ch();

    /** 		if ch = '-' then*/
    if (_17ch_3129 != 45)
    goto L10; // [370] 386

    /** 			e_sign = -1*/
    _e_sign_3236 = -1;

    /** 			get_ch()*/
    _17get_ch();
    goto L11; // [383] 400
L10: 

    /** 		elsif ch = '+' then*/
    if (_17ch_3129 != 43)
    goto L12; // [390] 399

    /** 			get_ch()*/
    _17get_ch();
L12: 
L11: 

    /** 		if ch >= '0' and ch <= '9' then*/
    _1517 = (_17ch_3129 >= 48);
    if (_1517 == 0) {
        goto L13; // [408] 487
    }
    _1519 = (_17ch_3129 <= 57);
    if (_1519 == 0)
    {
        DeRef(_1519);
        _1519 = NOVALUE;
        goto L13; // [419] 487
    }
    else{
        DeRef(_1519);
        _1519 = NOVALUE;
    }

    /** 			e_mag = ch - '0'*/
    DeRef(_e_mag_3241);
    _e_mag_3241 = _17ch_3129 - 48;
    if ((long)((unsigned long)_e_mag_3241 +(unsigned long) HIGH_BITS) >= 0){
        _e_mag_3241 = NewDouble((double)_e_mag_3241);
    }

    /** 			get_ch()*/
    _17get_ch();

    /** 			while ch >= '0' and ch <= '9' do*/
L14: 
    _1521 = (_17ch_3129 >= 48);
    if (_1521 == 0) {
        goto L15; // [445] 498
    }
    _1523 = (_17ch_3129 <= 57);
    if (_1523 == 0)
    {
        DeRef(_1523);
        _1523 = NOVALUE;
        goto L15; // [456] 498
    }
    else{
        DeRef(_1523);
        _1523 = NOVALUE;
    }

    /** 				e_mag = e_mag * 10 + ch - '0'*/
    if (IS_ATOM_INT(_e_mag_3241)) {
        if (_e_mag_3241 == (short)_e_mag_3241)
        _1524 = _e_mag_3241 * 10;
        else
        _1524 = NewDouble(_e_mag_3241 * (double)10);
    }
    else {
        _1524 = NewDouble(DBL_PTR(_e_mag_3241)->dbl * (double)10);
    }
    if (IS_ATOM_INT(_1524)) {
        _1525 = _1524 + _17ch_3129;
        if ((long)((unsigned long)_1525 + (unsigned long)HIGH_BITS) >= 0) 
        _1525 = NewDouble((double)_1525);
    }
    else {
        _1525 = NewDouble(DBL_PTR(_1524)->dbl + (double)_17ch_3129);
    }
    DeRef(_1524);
    _1524 = NOVALUE;
    DeRef(_e_mag_3241);
    if (IS_ATOM_INT(_1525)) {
        _e_mag_3241 = _1525 - 48;
        if ((long)((unsigned long)_e_mag_3241 +(unsigned long) HIGH_BITS) >= 0){
            _e_mag_3241 = NewDouble((double)_e_mag_3241);
        }
    }
    else {
        _e_mag_3241 = NewDouble(DBL_PTR(_1525)->dbl - (double)48);
    }
    DeRef(_1525);
    _1525 = NOVALUE;

    /** 				get_ch()*/
    _17get_ch();

    /** 			end while*/
    goto L14; // [481] 439
    goto L15; // [484] 498
L13: 

    /** 			return {GET_FAIL, 0} -- no exponent*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1527 = MAKE_SEQ(_1);
    DeRef(_mantissa_3239);
    DeRef(_dec_3240);
    DeRef(_e_mag_3241);
    DeRef(_1480);
    _1480 = NOVALUE;
    DeRef(_1491);
    _1491 = NOVALUE;
    DeRef(_1492);
    _1492 = NOVALUE;
    DeRef(_1493);
    _1493 = NOVALUE;
    DeRef(_1501);
    _1501 = NOVALUE;
    DeRef(_1510);
    _1510 = NOVALUE;
    DeRef(_1512);
    _1512 = NOVALUE;
    DeRef(_1517);
    _1517 = NOVALUE;
    DeRef(_1521);
    _1521 = NOVALUE;
    return _1527;
L15: 

    /** 		e_mag *= e_sign*/
    _0 = _e_mag_3241;
    if (IS_ATOM_INT(_e_mag_3241)) {
        if (_e_mag_3241 == (short)_e_mag_3241 && _e_sign_3236 <= INT15 && _e_sign_3236 >= -INT15)
        _e_mag_3241 = _e_mag_3241 * _e_sign_3236;
        else
        _e_mag_3241 = NewDouble(_e_mag_3241 * (double)_e_sign_3236);
    }
    else {
        _e_mag_3241 = NewDouble(DBL_PTR(_e_mag_3241)->dbl * (double)_e_sign_3236);
    }
    DeRef(_0);

    /** 		if e_mag > 308 then*/
    if (binary_op_a(LESSEQ, _e_mag_3241, 308)){
        goto L16; // [506] 561
    }

    /** 			mantissa *= power(10, 308)*/
    _1531 = power(10, 308);
    _0 = _mantissa_3239;
    if (IS_ATOM_INT(_mantissa_3239) && IS_ATOM_INT(_1531)) {
        if (_mantissa_3239 == (short)_mantissa_3239 && _1531 <= INT15 && _1531 >= -INT15)
        _mantissa_3239 = _mantissa_3239 * _1531;
        else
        _mantissa_3239 = NewDouble(_mantissa_3239 * (double)_1531);
    }
    else {
        if (IS_ATOM_INT(_mantissa_3239)) {
            _mantissa_3239 = NewDouble((double)_mantissa_3239 * DBL_PTR(_1531)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1531)) {
                _mantissa_3239 = NewDouble(DBL_PTR(_mantissa_3239)->dbl * (double)_1531);
            }
            else
            _mantissa_3239 = NewDouble(DBL_PTR(_mantissa_3239)->dbl * DBL_PTR(_1531)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1531);
    _1531 = NOVALUE;

    /** 			if e_mag > 1000 then*/
    if (binary_op_a(LESSEQ, _e_mag_3241, 1000)){
        goto L17; // [522] 532
    }

    /** 				e_mag = 1000*/
    DeRef(_e_mag_3241);
    _e_mag_3241 = 1000;
L17: 

    /** 			for i = 1 to e_mag - 308 do*/
    if (IS_ATOM_INT(_e_mag_3241)) {
        _1535 = _e_mag_3241 - 308;
        if ((long)((unsigned long)_1535 +(unsigned long) HIGH_BITS) >= 0){
            _1535 = NewDouble((double)_1535);
        }
    }
    else {
        _1535 = NewDouble(DBL_PTR(_e_mag_3241)->dbl - (double)308);
    }
    {
        int _i_3321;
        _i_3321 = 1;
L18: 
        if (binary_op_a(GREATER, _i_3321, _1535)){
            goto L19; // [538] 558
        }

        /** 				mantissa *= 10*/
        _0 = _mantissa_3239;
        if (IS_ATOM_INT(_mantissa_3239)) {
            if (_mantissa_3239 == (short)_mantissa_3239)
            _mantissa_3239 = _mantissa_3239 * 10;
            else
            _mantissa_3239 = NewDouble(_mantissa_3239 * (double)10);
        }
        else {
            _mantissa_3239 = NewDouble(DBL_PTR(_mantissa_3239)->dbl * (double)10);
        }
        DeRef(_0);

        /** 			end for*/
        _0 = _i_3321;
        if (IS_ATOM_INT(_i_3321)) {
            _i_3321 = _i_3321 + 1;
            if ((long)((unsigned long)_i_3321 +(unsigned long) HIGH_BITS) >= 0){
                _i_3321 = NewDouble((double)_i_3321);
            }
        }
        else {
            _i_3321 = binary_op_a(PLUS, _i_3321, 1);
        }
        DeRef(_0);
        goto L18; // [553] 545
L19: 
        ;
        DeRef(_i_3321);
    }
    goto L1A; // [558] 572
L16: 

    /** 			mantissa *= power(10, e_mag)*/
    if (IS_ATOM_INT(_e_mag_3241)) {
        _1537 = power(10, _e_mag_3241);
    }
    else {
        temp_d.dbl = (double)10;
        _1537 = Dpower(&temp_d, DBL_PTR(_e_mag_3241));
    }
    _0 = _mantissa_3239;
    if (IS_ATOM_INT(_mantissa_3239) && IS_ATOM_INT(_1537)) {
        if (_mantissa_3239 == (short)_mantissa_3239 && _1537 <= INT15 && _1537 >= -INT15)
        _mantissa_3239 = _mantissa_3239 * _1537;
        else
        _mantissa_3239 = NewDouble(_mantissa_3239 * (double)_1537);
    }
    else {
        if (IS_ATOM_INT(_mantissa_3239)) {
            _mantissa_3239 = NewDouble((double)_mantissa_3239 * DBL_PTR(_1537)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1537)) {
                _mantissa_3239 = NewDouble(DBL_PTR(_mantissa_3239)->dbl * (double)_1537);
            }
            else
            _mantissa_3239 = NewDouble(DBL_PTR(_mantissa_3239)->dbl * DBL_PTR(_1537)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1537);
    _1537 = NOVALUE;
L1A: 
LF: 

    /** 	return {GET_SUCCESS, mantissa}*/
    Ref(_mantissa_3239);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _mantissa_3239;
    _1539 = MAKE_SEQ(_1);
    DeRef(_mantissa_3239);
    DeRef(_dec_3240);
    DeRef(_e_mag_3241);
    DeRef(_1480);
    _1480 = NOVALUE;
    DeRef(_1491);
    _1491 = NOVALUE;
    DeRef(_1492);
    _1492 = NOVALUE;
    DeRef(_1493);
    _1493 = NOVALUE;
    DeRef(_1501);
    _1501 = NOVALUE;
    DeRef(_1510);
    _1510 = NOVALUE;
    DeRef(_1512);
    _1512 = NOVALUE;
    DeRef(_1517);
    _1517 = NOVALUE;
    DeRef(_1521);
    _1521 = NOVALUE;
    DeRef(_1527);
    _1527 = NOVALUE;
    DeRef(_1535);
    _1535 = NOVALUE;
    return _1539;
    ;
}


int _17Get()
{
    int _skip_blanks_1__tmp_at328_3374 = NOVALUE;
    int _skip_blanks_1__tmp_at177_3355 = NOVALUE;
    int _skip_blanks_1__tmp_at88_3346 = NOVALUE;
    int _s_3330 = NOVALUE;
    int _e_3331 = NOVALUE;
    int _e1_3332 = NOVALUE;
    int _1575 = NOVALUE;
    int _1574 = NOVALUE;
    int _1572 = NOVALUE;
    int _1570 = NOVALUE;
    int _1568 = NOVALUE;
    int _1566 = NOVALUE;
    int _1563 = NOVALUE;
    int _1561 = NOVALUE;
    int _1557 = NOVALUE;
    int _1553 = NOVALUE;
    int _1550 = NOVALUE;
    int _1549 = NOVALUE;
    int _1547 = NOVALUE;
    int _1545 = NOVALUE;
    int _1543 = NOVALUE;
    int _1542 = NOVALUE;
    int _1540 = NOVALUE;
    int _0, _1, _2;
    

    /** 	while find(ch, white_space) do*/
L1: 
    _1540 = find_from(_17ch_3129, _17white_space_3145, 1);
    if (_1540 == 0)
    {
        _1540 = NOVALUE;
        goto L2; // [13] 25
    }
    else{
        _1540 = NOVALUE;
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L1; // [22] 6
L2: 

    /** 	if ch = -1 then -- string is made of whitespace only*/
    if (_17ch_3129 != -1)
    goto L3; // [29] 44

    /** 		return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _1542 = MAKE_SEQ(_1);
    DeRef(_s_3330);
    DeRef(_e_3331);
    return _1542;
L3: 

    /** 	while 1 do*/
L4: 

    /** 		if find(ch, START_NUMERIC) then*/
    _1543 = find_from(_17ch_3129, _17START_NUMERIC_3112, 1);
    if (_1543 == 0)
    {
        _1543 = NOVALUE;
        goto L5; // [60] 157
    }
    else{
        _1543 = NOVALUE;
    }

    /** 			e = get_number()*/
    _0 = _e_3331;
    _e_3331 = _17get_number();
    DeRef(_0);

    /** 			if e[1] != GET_IGNORE then -- either a number or something illegal was read, so exit: the other goto*/
    _2 = (int)SEQ_PTR(_e_3331);
    _1545 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _1545, -2)){
        _1545 = NOVALUE;
        goto L6; // [76] 87
    }
    _1545 = NOVALUE;

    /** 				return e*/
    DeRef(_s_3330);
    DeRef(_1542);
    _1542 = NOVALUE;
    return _e_3331;
L6: 

    /** 			skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L7: 
    _skip_blanks_1__tmp_at88_3346 = find_from(_17ch_3129, _17white_space_3145, 1);
    if (_skip_blanks_1__tmp_at88_3346 == 0)
    {
        goto L8; // [101] 118
    }
    else{
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L7; // [110] 94

    /** end procedure*/
    goto L8; // [115] 118
L8: 

    /** 			if ch=-1 or ch='}' then -- '}' is expected only in the "{--\n}" case*/
    _1547 = (_17ch_3129 == -1);
    if (_1547 != 0) {
        goto L9; // [128] 143
    }
    _1549 = (_17ch_3129 == 125);
    if (_1549 == 0)
    {
        DeRef(_1549);
        _1549 = NOVALUE;
        goto L4; // [139] 49
    }
    else{
        DeRef(_1549);
        _1549 = NOVALUE;
    }
L9: 

    /** 				return {GET_NOTHING, 0} -- just a comment*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -2;
    ((int *)_2)[2] = 0;
    _1550 = MAKE_SEQ(_1);
    DeRef(_s_3330);
    DeRef(_e_3331);
    DeRef(_1542);
    _1542 = NOVALUE;
    DeRef(_1547);
    _1547 = NOVALUE;
    return _1550;
    goto L4; // [154] 49
L5: 

    /** 		elsif ch = '{' then*/
    if (_17ch_3129 != 123)
    goto LA; // [161] 465

    /** 			s = {}*/
    RefDS(_5);
    DeRef(_s_3330);
    _s_3330 = _5;

    /** 			get_ch()*/
    _17get_ch();

    /** 			skip_blanks()*/

    /** 	while find(ch, white_space) do*/
LB: 
    _skip_blanks_1__tmp_at177_3355 = find_from(_17ch_3129, _17white_space_3145, 1);
    if (_skip_blanks_1__tmp_at177_3355 == 0)
    {
        goto LC; // [190] 207
    }
    else{
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto LB; // [199] 183

    /** end procedure*/
    goto LC; // [204] 207
LC: 

    /** 			if ch = '}' then -- empty sequence*/
    if (_17ch_3129 != 125)
    goto LD; // [213] 232

    /** 				get_ch()*/
    _17get_ch();

    /** 				return {GET_SUCCESS, s} -- empty sequence*/
    RefDS(_s_3330);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s_3330;
    _1553 = MAKE_SEQ(_1);
    DeRefDS(_s_3330);
    DeRef(_e_3331);
    DeRef(_1542);
    _1542 = NOVALUE;
    DeRef(_1547);
    _1547 = NOVALUE;
    DeRef(_1550);
    _1550 = NOVALUE;
    return _1553;
LD: 

    /** 			while TRUE do -- read: comment(s), element, comment(s), comma and so on till it terminates or errors out*/
LE: 

    /** 				while 1 do -- read zero or more comments and an element*/
LF: 

    /** 					e = Get() -- read next element, using standard function*/
    _0 = _e_3331;
    _e_3331 = _17Get();
    DeRef(_0);

    /** 					e1 = e[1]*/
    _2 = (int)SEQ_PTR(_e_3331);
    _e1_3332 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_e1_3332))
    _e1_3332 = (long)DBL_PTR(_e1_3332)->dbl;

    /** 					if e1 = GET_SUCCESS then*/
    if (_e1_3332 != 0)
    goto L10; // [257] 278

    /** 						s = append(s, e[2])*/
    _2 = (int)SEQ_PTR(_e_3331);
    _1557 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1557);
    Append(&_s_3330, _s_3330, _1557);
    _1557 = NOVALUE;

    /** 						exit  -- element read and added to result*/
    goto L11; // [273] 322
    goto LF; // [275] 242
L10: 

    /** 					elsif e1 != GET_IGNORE then*/
    if (_e1_3332 == -2)
    goto L12; // [280] 293

    /** 						return e*/
    DeRef(_s_3330);
    DeRef(_1542);
    _1542 = NOVALUE;
    DeRef(_1547);
    _1547 = NOVALUE;
    DeRef(_1550);
    _1550 = NOVALUE;
    DeRef(_1553);
    _1553 = NOVALUE;
    return _e_3331;
    goto LF; // [290] 242
L12: 

    /** 					elsif ch='}' then*/
    if (_17ch_3129 != 125)
    goto LF; // [297] 242

    /** 						get_ch()*/
    _17get_ch();

    /** 						return {GET_SUCCESS, s} -- empty sequence*/
    RefDS(_s_3330);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s_3330;
    _1561 = MAKE_SEQ(_1);
    DeRefDS(_s_3330);
    DeRef(_e_3331);
    DeRef(_1542);
    _1542 = NOVALUE;
    DeRef(_1547);
    _1547 = NOVALUE;
    DeRef(_1550);
    _1550 = NOVALUE;
    DeRef(_1553);
    _1553 = NOVALUE;
    return _1561;

    /** 				end while*/
    goto LF; // [319] 242
L11: 

    /** 				while 1 do -- now read zero or more post element comments*/
L13: 

    /** 					skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L14: 
    _skip_blanks_1__tmp_at328_3374 = find_from(_17ch_3129, _17white_space_3145, 1);
    if (_skip_blanks_1__tmp_at328_3374 == 0)
    {
        goto L15; // [341] 358
    }
    else{
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L14; // [350] 334

    /** end procedure*/
    goto L15; // [355] 358
L15: 

    /** 					if ch = '}' then*/
    if (_17ch_3129 != 125)
    goto L16; // [364] 385

    /** 						get_ch()*/
    _17get_ch();

    /** 					return {GET_SUCCESS, s}*/
    RefDS(_s_3330);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s_3330;
    _1563 = MAKE_SEQ(_1);
    DeRefDS(_s_3330);
    DeRef(_e_3331);
    DeRef(_1542);
    _1542 = NOVALUE;
    DeRef(_1547);
    _1547 = NOVALUE;
    DeRef(_1550);
    _1550 = NOVALUE;
    DeRef(_1553);
    _1553 = NOVALUE;
    DeRef(_1561);
    _1561 = NOVALUE;
    return _1563;
    goto L13; // [382] 327
L16: 

    /** 					elsif ch!='-' then*/
    if (_17ch_3129 == 45)
    goto L17; // [389] 400

    /** 						exit*/
    goto L18; // [395] 434
    goto L13; // [397] 327
L17: 

    /** 						e = get_number() -- reads anything starting with '-'*/
    _0 = _e_3331;
    _e_3331 = _17get_number();
    DeRef(_0);

    /** 						if e[1] != GET_IGNORE then  -- it wasn't a comment, this is illegal*/
    _2 = (int)SEQ_PTR(_e_3331);
    _1566 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _1566, -2)){
        _1566 = NOVALUE;
        goto L13; // [413] 327
    }
    _1566 = NOVALUE;

    /** 							return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1568 = MAKE_SEQ(_1);
    DeRef(_s_3330);
    DeRefDS(_e_3331);
    DeRef(_1542);
    _1542 = NOVALUE;
    DeRef(_1547);
    _1547 = NOVALUE;
    DeRef(_1550);
    _1550 = NOVALUE;
    DeRef(_1553);
    _1553 = NOVALUE;
    DeRef(_1561);
    _1561 = NOVALUE;
    DeRef(_1563);
    _1563 = NOVALUE;
    return _1568;

    /** 			end while*/
    goto L13; // [431] 327
L18: 

    /** 				if ch != ',' then*/
    if (_17ch_3129 == 44)
    goto L19; // [438] 453

    /** 				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1570 = MAKE_SEQ(_1);
    DeRef(_s_3330);
    DeRef(_e_3331);
    DeRef(_1542);
    _1542 = NOVALUE;
    DeRef(_1547);
    _1547 = NOVALUE;
    DeRef(_1550);
    _1550 = NOVALUE;
    DeRef(_1553);
    _1553 = NOVALUE;
    DeRef(_1561);
    _1561 = NOVALUE;
    DeRef(_1563);
    _1563 = NOVALUE;
    DeRef(_1568);
    _1568 = NOVALUE;
    return _1570;
L19: 

    /** 			get_ch() -- skip comma*/
    _17get_ch();

    /** 			end while*/
    goto LE; // [459] 237
    goto L4; // [462] 49
LA: 

    /** 		elsif ch = '\"' then*/
    if (_17ch_3129 != 34)
    goto L1A; // [469] 485

    /** 			return get_string()*/
    _1572 = _17get_string();
    DeRef(_s_3330);
    DeRef(_e_3331);
    DeRef(_1542);
    _1542 = NOVALUE;
    DeRef(_1547);
    _1547 = NOVALUE;
    DeRef(_1550);
    _1550 = NOVALUE;
    DeRef(_1553);
    _1553 = NOVALUE;
    DeRef(_1561);
    _1561 = NOVALUE;
    DeRef(_1563);
    _1563 = NOVALUE;
    DeRef(_1568);
    _1568 = NOVALUE;
    DeRef(_1570);
    _1570 = NOVALUE;
    return _1572;
    goto L4; // [482] 49
L1A: 

    /** 		elsif ch = '\'' then*/
    if (_17ch_3129 != 39)
    goto L1B; // [489] 505

    /** 			return get_qchar()*/
    _1574 = _17get_qchar();
    DeRef(_s_3330);
    DeRef(_e_3331);
    DeRef(_1542);
    _1542 = NOVALUE;
    DeRef(_1547);
    _1547 = NOVALUE;
    DeRef(_1550);
    _1550 = NOVALUE;
    DeRef(_1553);
    _1553 = NOVALUE;
    DeRef(_1561);
    _1561 = NOVALUE;
    DeRef(_1563);
    _1563 = NOVALUE;
    DeRef(_1568);
    _1568 = NOVALUE;
    DeRef(_1570);
    _1570 = NOVALUE;
    DeRef(_1572);
    _1572 = NOVALUE;
    return _1574;
    goto L4; // [502] 49
L1B: 

    /** 			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _1575 = MAKE_SEQ(_1);
    DeRef(_s_3330);
    DeRef(_e_3331);
    DeRef(_1542);
    _1542 = NOVALUE;
    DeRef(_1547);
    _1547 = NOVALUE;
    DeRef(_1550);
    _1550 = NOVALUE;
    DeRef(_1553);
    _1553 = NOVALUE;
    DeRef(_1561);
    _1561 = NOVALUE;
    DeRef(_1563);
    _1563 = NOVALUE;
    DeRef(_1568);
    _1568 = NOVALUE;
    DeRef(_1570);
    _1570 = NOVALUE;
    DeRef(_1572);
    _1572 = NOVALUE;
    DeRef(_1574);
    _1574 = NOVALUE;
    return _1575;

    /** 	end while*/
    goto L4; // [518] 49
    ;
}


int _17Get2()
{
    int _skip_blanks_1__tmp_at464_3471 = NOVALUE;
    int _skip_blanks_1__tmp_at233_3438 = NOVALUE;
    int _s_3400 = NOVALUE;
    int _e_3401 = NOVALUE;
    int _e1_3402 = NOVALUE;
    int _offset_3403 = NOVALUE;
    int _1667 = NOVALUE;
    int _1666 = NOVALUE;
    int _1665 = NOVALUE;
    int _1664 = NOVALUE;
    int _1663 = NOVALUE;
    int _1662 = NOVALUE;
    int _1661 = NOVALUE;
    int _1660 = NOVALUE;
    int _1659 = NOVALUE;
    int _1658 = NOVALUE;
    int _1657 = NOVALUE;
    int _1654 = NOVALUE;
    int _1653 = NOVALUE;
    int _1652 = NOVALUE;
    int _1651 = NOVALUE;
    int _1650 = NOVALUE;
    int _1649 = NOVALUE;
    int _1646 = NOVALUE;
    int _1645 = NOVALUE;
    int _1644 = NOVALUE;
    int _1643 = NOVALUE;
    int _1642 = NOVALUE;
    int _1640 = NOVALUE;
    int _1639 = NOVALUE;
    int _1638 = NOVALUE;
    int _1637 = NOVALUE;
    int _1636 = NOVALUE;
    int _1634 = NOVALUE;
    int _1631 = NOVALUE;
    int _1630 = NOVALUE;
    int _1629 = NOVALUE;
    int _1628 = NOVALUE;
    int _1627 = NOVALUE;
    int _1625 = NOVALUE;
    int _1624 = NOVALUE;
    int _1623 = NOVALUE;
    int _1622 = NOVALUE;
    int _1621 = NOVALUE;
    int _1619 = NOVALUE;
    int _1618 = NOVALUE;
    int _1617 = NOVALUE;
    int _1616 = NOVALUE;
    int _1615 = NOVALUE;
    int _1614 = NOVALUE;
    int _1611 = NOVALUE;
    int _1607 = NOVALUE;
    int _1606 = NOVALUE;
    int _1605 = NOVALUE;
    int _1604 = NOVALUE;
    int _1603 = NOVALUE;
    int _1600 = NOVALUE;
    int _1599 = NOVALUE;
    int _1598 = NOVALUE;
    int _1597 = NOVALUE;
    int _1596 = NOVALUE;
    int _1594 = NOVALUE;
    int _1593 = NOVALUE;
    int _1592 = NOVALUE;
    int _1591 = NOVALUE;
    int _1590 = NOVALUE;
    int _1589 = NOVALUE;
    int _1587 = NOVALUE;
    int _1585 = NOVALUE;
    int _1583 = NOVALUE;
    int _1582 = NOVALUE;
    int _1581 = NOVALUE;
    int _1580 = NOVALUE;
    int _1579 = NOVALUE;
    int _1577 = NOVALUE;
    int _0, _1, _2;
    

    /** 	offset = string_next-1*/
    _offset_3403 = _17string_next_3128 - 1;

    /** 	get_ch()*/
    _17get_ch();

    /** 	while find(ch, white_space) do*/
L1: 
    _1577 = find_from(_17ch_3129, _17white_space_3145, 1);
    if (_1577 == 0)
    {
        _1577 = NOVALUE;
        goto L2; // [25] 37
    }
    else{
        _1577 = NOVALUE;
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L1; // [34] 18
L2: 

    /** 	if ch = -1 then -- string is made of whitespace only*/
    if (_17ch_3129 != -1)
    goto L3; // [41] 75

    /** 		return {GET_EOF, 0, string_next-1-offset ,string_next-1}*/
    _1579 = _17string_next_3128 - 1;
    if ((long)((unsigned long)_1579 +(unsigned long) HIGH_BITS) >= 0){
        _1579 = NewDouble((double)_1579);
    }
    if (IS_ATOM_INT(_1579)) {
        _1580 = _1579 - _offset_3403;
        if ((long)((unsigned long)_1580 +(unsigned long) HIGH_BITS) >= 0){
            _1580 = NewDouble((double)_1580);
        }
    }
    else {
        _1580 = NewDouble(DBL_PTR(_1579)->dbl - (double)_offset_3403);
    }
    DeRef(_1579);
    _1579 = NOVALUE;
    _1581 = _17string_next_3128 - 1;
    if ((long)((unsigned long)_1581 +(unsigned long) HIGH_BITS) >= 0){
        _1581 = NewDouble((double)_1581);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = -1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _1580;
    *((int *)(_2+16)) = _1581;
    _1582 = MAKE_SEQ(_1);
    _1581 = NOVALUE;
    _1580 = NOVALUE;
    DeRef(_s_3400);
    DeRef(_e_3401);
    return _1582;
L3: 

    /** 	leading_whitespace = string_next-2-offset -- index of the last whitespace: string_next points past the first non whitespace*/
    _1583 = _17string_next_3128 - 2;
    if ((long)((unsigned long)_1583 +(unsigned long) HIGH_BITS) >= 0){
        _1583 = NewDouble((double)_1583);
    }
    if (IS_ATOM_INT(_1583)) {
        _17leading_whitespace_3397 = _1583 - _offset_3403;
    }
    else {
        _17leading_whitespace_3397 = NewDouble(DBL_PTR(_1583)->dbl - (double)_offset_3403);
    }
    DeRef(_1583);
    _1583 = NOVALUE;
    if (!IS_ATOM_INT(_17leading_whitespace_3397)) {
        _1 = (long)(DBL_PTR(_17leading_whitespace_3397)->dbl);
        DeRefDS(_17leading_whitespace_3397);
        _17leading_whitespace_3397 = _1;
    }

    /** 	while 1 do*/
L4: 

    /** 		if find(ch, START_NUMERIC) then*/
    _1585 = find_from(_17ch_3129, _17START_NUMERIC_3112, 1);
    if (_1585 == 0)
    {
        _1585 = NOVALUE;
        goto L5; // [105] 213
    }
    else{
        _1585 = NOVALUE;
    }

    /** 			e = get_number()*/
    _0 = _e_3401;
    _e_3401 = _17get_number();
    DeRef(_0);

    /** 			if e[1] != GET_IGNORE then -- either a number or something illegal was read, so exit: the other goto*/
    _2 = (int)SEQ_PTR(_e_3401);
    _1587 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _1587, -2)){
        _1587 = NOVALUE;
        goto L6; // [121] 162
    }
    _1587 = NOVALUE;

    /** 				return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1589 = _17string_next_3128 - 1;
    if ((long)((unsigned long)_1589 +(unsigned long) HIGH_BITS) >= 0){
        _1589 = NewDouble((double)_1589);
    }
    if (IS_ATOM_INT(_1589)) {
        _1590 = _1589 - _offset_3403;
        if ((long)((unsigned long)_1590 +(unsigned long) HIGH_BITS) >= 0){
            _1590 = NewDouble((double)_1590);
        }
    }
    else {
        _1590 = NewDouble(DBL_PTR(_1589)->dbl - (double)_offset_3403);
    }
    DeRef(_1589);
    _1589 = NOVALUE;
    _1591 = (_17ch_3129 != -1);
    if (IS_ATOM_INT(_1590)) {
        _1592 = _1590 - _1591;
        if ((long)((unsigned long)_1592 +(unsigned long) HIGH_BITS) >= 0){
            _1592 = NewDouble((double)_1592);
        }
    }
    else {
        _1592 = NewDouble(DBL_PTR(_1590)->dbl - (double)_1591);
    }
    DeRef(_1590);
    _1590 = NOVALUE;
    _1591 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1592;
    ((int *)_2)[2] = _17leading_whitespace_3397;
    _1593 = MAKE_SEQ(_1);
    _1592 = NOVALUE;
    Concat((object_ptr)&_1594, _e_3401, _1593);
    DeRefDS(_1593);
    _1593 = NOVALUE;
    DeRef(_s_3400);
    DeRefDS(_e_3401);
    DeRef(_1582);
    _1582 = NOVALUE;
    return _1594;
L6: 

    /** 			get_ch()*/
    _17get_ch();

    /** 			if ch=-1 then*/
    if (_17ch_3129 != -1)
    goto L4; // [170] 94

    /** 				return {GET_NOTHING, 0, string_next-1-offset-(ch!=-1), leading_whitespace} -- empty sequence*/
    _1596 = _17string_next_3128 - 1;
    if ((long)((unsigned long)_1596 +(unsigned long) HIGH_BITS) >= 0){
        _1596 = NewDouble((double)_1596);
    }
    if (IS_ATOM_INT(_1596)) {
        _1597 = _1596 - _offset_3403;
        if ((long)((unsigned long)_1597 +(unsigned long) HIGH_BITS) >= 0){
            _1597 = NewDouble((double)_1597);
        }
    }
    else {
        _1597 = NewDouble(DBL_PTR(_1596)->dbl - (double)_offset_3403);
    }
    DeRef(_1596);
    _1596 = NOVALUE;
    _1598 = (_17ch_3129 != -1);
    if (IS_ATOM_INT(_1597)) {
        _1599 = _1597 - _1598;
        if ((long)((unsigned long)_1599 +(unsigned long) HIGH_BITS) >= 0){
            _1599 = NewDouble((double)_1599);
        }
    }
    else {
        _1599 = NewDouble(DBL_PTR(_1597)->dbl - (double)_1598);
    }
    DeRef(_1597);
    _1597 = NOVALUE;
    _1598 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = -2;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _1599;
    *((int *)(_2+16)) = _17leading_whitespace_3397;
    _1600 = MAKE_SEQ(_1);
    _1599 = NOVALUE;
    DeRef(_s_3400);
    DeRef(_e_3401);
    DeRef(_1582);
    _1582 = NOVALUE;
    DeRef(_1594);
    _1594 = NOVALUE;
    return _1600;
    goto L4; // [210] 94
L5: 

    /** 		elsif ch = '{' then*/
    if (_17ch_3129 != 123)
    goto L7; // [217] 676

    /** 			s = {}*/
    RefDS(_5);
    DeRef(_s_3400);
    _s_3400 = _5;

    /** 			get_ch()*/
    _17get_ch();

    /** 			skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L8: 
    _skip_blanks_1__tmp_at233_3438 = find_from(_17ch_3129, _17white_space_3145, 1);
    if (_skip_blanks_1__tmp_at233_3438 == 0)
    {
        goto L9; // [246] 263
    }
    else{
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L8; // [255] 239

    /** end procedure*/
    goto L9; // [260] 263
L9: 

    /** 			if ch = '}' then -- empty sequence*/
    if (_17ch_3129 != 125)
    goto LA; // [269] 313

    /** 				get_ch()*/
    _17get_ch();

    /** 				return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1), leading_whitespace} -- empty sequence*/
    _1603 = _17string_next_3128 - 1;
    if ((long)((unsigned long)_1603 +(unsigned long) HIGH_BITS) >= 0){
        _1603 = NewDouble((double)_1603);
    }
    if (IS_ATOM_INT(_1603)) {
        _1604 = _1603 - _offset_3403;
        if ((long)((unsigned long)_1604 +(unsigned long) HIGH_BITS) >= 0){
            _1604 = NewDouble((double)_1604);
        }
    }
    else {
        _1604 = NewDouble(DBL_PTR(_1603)->dbl - (double)_offset_3403);
    }
    DeRef(_1603);
    _1603 = NOVALUE;
    _1605 = (_17ch_3129 != -1);
    if (IS_ATOM_INT(_1604)) {
        _1606 = _1604 - _1605;
        if ((long)((unsigned long)_1606 +(unsigned long) HIGH_BITS) >= 0){
            _1606 = NewDouble((double)_1606);
        }
    }
    else {
        _1606 = NewDouble(DBL_PTR(_1604)->dbl - (double)_1605);
    }
    DeRef(_1604);
    _1604 = NOVALUE;
    _1605 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_s_3400);
    *((int *)(_2+8)) = _s_3400;
    *((int *)(_2+12)) = _1606;
    *((int *)(_2+16)) = _17leading_whitespace_3397;
    _1607 = MAKE_SEQ(_1);
    _1606 = NOVALUE;
    DeRefDS(_s_3400);
    DeRef(_e_3401);
    DeRef(_1582);
    _1582 = NOVALUE;
    DeRef(_1594);
    _1594 = NOVALUE;
    DeRef(_1600);
    _1600 = NOVALUE;
    return _1607;
LA: 

    /** 			while TRUE do -- read: comment(s), element, comment(s), comma and so on till it terminates or errors out*/
LB: 

    /** 				while 1 do -- read zero or more comments and an element*/
LC: 

    /** 					e = Get() -- read next element, using standard function*/
    _0 = _e_3401;
    _e_3401 = _17Get();
    DeRef(_0);

    /** 					e1 = e[1]*/
    _2 = (int)SEQ_PTR(_e_3401);
    _e1_3402 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_e1_3402))
    _e1_3402 = (long)DBL_PTR(_e1_3402)->dbl;

    /** 					if e1 = GET_SUCCESS then*/
    if (_e1_3402 != 0)
    goto LD; // [338] 359

    /** 						s = append(s, e[2])*/
    _2 = (int)SEQ_PTR(_e_3401);
    _1611 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1611);
    Append(&_s_3400, _s_3400, _1611);
    _1611 = NOVALUE;

    /** 						exit  -- element read and added to result*/
    goto LE; // [354] 458
    goto LC; // [356] 323
LD: 

    /** 					elsif e1 != GET_IGNORE then*/
    if (_e1_3402 == -2)
    goto LF; // [361] 404

    /** 						return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1614 = _17string_next_3128 - 1;
    if ((long)((unsigned long)_1614 +(unsigned long) HIGH_BITS) >= 0){
        _1614 = NewDouble((double)_1614);
    }
    if (IS_ATOM_INT(_1614)) {
        _1615 = _1614 - _offset_3403;
        if ((long)((unsigned long)_1615 +(unsigned long) HIGH_BITS) >= 0){
            _1615 = NewDouble((double)_1615);
        }
    }
    else {
        _1615 = NewDouble(DBL_PTR(_1614)->dbl - (double)_offset_3403);
    }
    DeRef(_1614);
    _1614 = NOVALUE;
    _1616 = (_17ch_3129 != -1);
    if (IS_ATOM_INT(_1615)) {
        _1617 = _1615 - _1616;
        if ((long)((unsigned long)_1617 +(unsigned long) HIGH_BITS) >= 0){
            _1617 = NewDouble((double)_1617);
        }
    }
    else {
        _1617 = NewDouble(DBL_PTR(_1615)->dbl - (double)_1616);
    }
    DeRef(_1615);
    _1615 = NOVALUE;
    _1616 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1617;
    ((int *)_2)[2] = _17leading_whitespace_3397;
    _1618 = MAKE_SEQ(_1);
    _1617 = NOVALUE;
    Concat((object_ptr)&_1619, _e_3401, _1618);
    DeRefDS(_1618);
    _1618 = NOVALUE;
    DeRef(_s_3400);
    DeRefDS(_e_3401);
    DeRef(_1582);
    _1582 = NOVALUE;
    DeRef(_1594);
    _1594 = NOVALUE;
    DeRef(_1600);
    _1600 = NOVALUE;
    DeRef(_1607);
    _1607 = NOVALUE;
    return _1619;
    goto LC; // [401] 323
LF: 

    /** 					elsif ch='}' then*/
    if (_17ch_3129 != 125)
    goto LC; // [408] 323

    /** 						get_ch()*/
    _17get_ch();

    /** 						return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1),leading_whitespace} -- empty sequence*/
    _1621 = _17string_next_3128 - 1;
    if ((long)((unsigned long)_1621 +(unsigned long) HIGH_BITS) >= 0){
        _1621 = NewDouble((double)_1621);
    }
    if (IS_ATOM_INT(_1621)) {
        _1622 = _1621 - _offset_3403;
        if ((long)((unsigned long)_1622 +(unsigned long) HIGH_BITS) >= 0){
            _1622 = NewDouble((double)_1622);
        }
    }
    else {
        _1622 = NewDouble(DBL_PTR(_1621)->dbl - (double)_offset_3403);
    }
    DeRef(_1621);
    _1621 = NOVALUE;
    _1623 = (_17ch_3129 != -1);
    if (IS_ATOM_INT(_1622)) {
        _1624 = _1622 - _1623;
        if ((long)((unsigned long)_1624 +(unsigned long) HIGH_BITS) >= 0){
            _1624 = NewDouble((double)_1624);
        }
    }
    else {
        _1624 = NewDouble(DBL_PTR(_1622)->dbl - (double)_1623);
    }
    DeRef(_1622);
    _1622 = NOVALUE;
    _1623 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_s_3400);
    *((int *)(_2+8)) = _s_3400;
    *((int *)(_2+12)) = _1624;
    *((int *)(_2+16)) = _17leading_whitespace_3397;
    _1625 = MAKE_SEQ(_1);
    _1624 = NOVALUE;
    DeRefDS(_s_3400);
    DeRef(_e_3401);
    DeRef(_1582);
    _1582 = NOVALUE;
    DeRef(_1594);
    _1594 = NOVALUE;
    DeRef(_1600);
    _1600 = NOVALUE;
    DeRef(_1607);
    _1607 = NOVALUE;
    DeRef(_1619);
    _1619 = NOVALUE;
    return _1625;

    /** 				end while*/
    goto LC; // [455] 323
LE: 

    /** 				while 1 do -- now read zero or more post element comments*/
L10: 

    /** 					skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L11: 
    _skip_blanks_1__tmp_at464_3471 = find_from(_17ch_3129, _17white_space_3145, 1);
    if (_skip_blanks_1__tmp_at464_3471 == 0)
    {
        goto L12; // [477] 494
    }
    else{
    }

    /** 		get_ch()*/
    _17get_ch();

    /** 	end while*/
    goto L11; // [486] 470

    /** end procedure*/
    goto L12; // [491] 494
L12: 

    /** 					if ch = '}' then*/
    if (_17ch_3129 != 125)
    goto L13; // [500] 546

    /** 						get_ch()*/
    _17get_ch();

    /** 					return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1627 = _17string_next_3128 - 1;
    if ((long)((unsigned long)_1627 +(unsigned long) HIGH_BITS) >= 0){
        _1627 = NewDouble((double)_1627);
    }
    if (IS_ATOM_INT(_1627)) {
        _1628 = _1627 - _offset_3403;
        if ((long)((unsigned long)_1628 +(unsigned long) HIGH_BITS) >= 0){
            _1628 = NewDouble((double)_1628);
        }
    }
    else {
        _1628 = NewDouble(DBL_PTR(_1627)->dbl - (double)_offset_3403);
    }
    DeRef(_1627);
    _1627 = NOVALUE;
    _1629 = (_17ch_3129 != -1);
    if (IS_ATOM_INT(_1628)) {
        _1630 = _1628 - _1629;
        if ((long)((unsigned long)_1630 +(unsigned long) HIGH_BITS) >= 0){
            _1630 = NewDouble((double)_1630);
        }
    }
    else {
        _1630 = NewDouble(DBL_PTR(_1628)->dbl - (double)_1629);
    }
    DeRef(_1628);
    _1628 = NOVALUE;
    _1629 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_s_3400);
    *((int *)(_2+8)) = _s_3400;
    *((int *)(_2+12)) = _1630;
    *((int *)(_2+16)) = _17leading_whitespace_3397;
    _1631 = MAKE_SEQ(_1);
    _1630 = NOVALUE;
    DeRefDS(_s_3400);
    DeRef(_e_3401);
    DeRef(_1582);
    _1582 = NOVALUE;
    DeRef(_1594);
    _1594 = NOVALUE;
    DeRef(_1600);
    _1600 = NOVALUE;
    DeRef(_1607);
    _1607 = NOVALUE;
    DeRef(_1619);
    _1619 = NOVALUE;
    DeRef(_1625);
    _1625 = NOVALUE;
    return _1631;
    goto L10; // [543] 463
L13: 

    /** 					elsif ch!='-' then*/
    if (_17ch_3129 == 45)
    goto L14; // [550] 561

    /** 						exit*/
    goto L15; // [556] 620
    goto L10; // [558] 463
L14: 

    /** 						e = get_number() -- reads anything starting with '-'*/
    _0 = _e_3401;
    _e_3401 = _17get_number();
    DeRef(_0);

    /** 						if e[1] != GET_IGNORE then  -- it was not a comment, this is illegal*/
    _2 = (int)SEQ_PTR(_e_3401);
    _1634 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _1634, -2)){
        _1634 = NOVALUE;
        goto L10; // [574] 463
    }
    _1634 = NOVALUE;

    /** 							return {GET_FAIL, 0, string_next-1-offset-(ch!=-1),leading_whitespace}*/
    _1636 = _17string_next_3128 - 1;
    if ((long)((unsigned long)_1636 +(unsigned long) HIGH_BITS) >= 0){
        _1636 = NewDouble((double)_1636);
    }
    if (IS_ATOM_INT(_1636)) {
        _1637 = _1636 - _offset_3403;
        if ((long)((unsigned long)_1637 +(unsigned long) HIGH_BITS) >= 0){
            _1637 = NewDouble((double)_1637);
        }
    }
    else {
        _1637 = NewDouble(DBL_PTR(_1636)->dbl - (double)_offset_3403);
    }
    DeRef(_1636);
    _1636 = NOVALUE;
    _1638 = (_17ch_3129 != -1);
    if (IS_ATOM_INT(_1637)) {
        _1639 = _1637 - _1638;
        if ((long)((unsigned long)_1639 +(unsigned long) HIGH_BITS) >= 0){
            _1639 = NewDouble((double)_1639);
        }
    }
    else {
        _1639 = NewDouble(DBL_PTR(_1637)->dbl - (double)_1638);
    }
    DeRef(_1637);
    _1637 = NOVALUE;
    _1638 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _1639;
    *((int *)(_2+16)) = _17leading_whitespace_3397;
    _1640 = MAKE_SEQ(_1);
    _1639 = NOVALUE;
    DeRef(_s_3400);
    DeRefDS(_e_3401);
    DeRef(_1582);
    _1582 = NOVALUE;
    DeRef(_1594);
    _1594 = NOVALUE;
    DeRef(_1600);
    _1600 = NOVALUE;
    DeRef(_1607);
    _1607 = NOVALUE;
    DeRef(_1619);
    _1619 = NOVALUE;
    DeRef(_1625);
    _1625 = NOVALUE;
    DeRef(_1631);
    _1631 = NOVALUE;
    return _1640;

    /** 			end while*/
    goto L10; // [617] 463
L15: 

    /** 				if ch != ',' then*/
    if (_17ch_3129 == 44)
    goto L16; // [624] 664

    /** 				return {GET_FAIL, 0, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1642 = _17string_next_3128 - 1;
    if ((long)((unsigned long)_1642 +(unsigned long) HIGH_BITS) >= 0){
        _1642 = NewDouble((double)_1642);
    }
    if (IS_ATOM_INT(_1642)) {
        _1643 = _1642 - _offset_3403;
        if ((long)((unsigned long)_1643 +(unsigned long) HIGH_BITS) >= 0){
            _1643 = NewDouble((double)_1643);
        }
    }
    else {
        _1643 = NewDouble(DBL_PTR(_1642)->dbl - (double)_offset_3403);
    }
    DeRef(_1642);
    _1642 = NOVALUE;
    _1644 = (_17ch_3129 != -1);
    if (IS_ATOM_INT(_1643)) {
        _1645 = _1643 - _1644;
        if ((long)((unsigned long)_1645 +(unsigned long) HIGH_BITS) >= 0){
            _1645 = NewDouble((double)_1645);
        }
    }
    else {
        _1645 = NewDouble(DBL_PTR(_1643)->dbl - (double)_1644);
    }
    DeRef(_1643);
    _1643 = NOVALUE;
    _1644 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _1645;
    *((int *)(_2+16)) = _17leading_whitespace_3397;
    _1646 = MAKE_SEQ(_1);
    _1645 = NOVALUE;
    DeRef(_s_3400);
    DeRef(_e_3401);
    DeRef(_1582);
    _1582 = NOVALUE;
    DeRef(_1594);
    _1594 = NOVALUE;
    DeRef(_1600);
    _1600 = NOVALUE;
    DeRef(_1607);
    _1607 = NOVALUE;
    DeRef(_1619);
    _1619 = NOVALUE;
    DeRef(_1625);
    _1625 = NOVALUE;
    DeRef(_1631);
    _1631 = NOVALUE;
    DeRef(_1640);
    _1640 = NOVALUE;
    return _1646;
L16: 

    /** 			get_ch() -- skip comma*/
    _17get_ch();

    /** 			end while*/
    goto LB; // [670] 318
    goto L4; // [673] 94
L7: 

    /** 		elsif ch = '\"' then*/
    if (_17ch_3129 != 34)
    goto L17; // [680] 730

    /** 			e = get_string()*/
    _0 = _e_3401;
    _e_3401 = _17get_string();
    DeRef(_0);

    /** 			return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1649 = _17string_next_3128 - 1;
    if ((long)((unsigned long)_1649 +(unsigned long) HIGH_BITS) >= 0){
        _1649 = NewDouble((double)_1649);
    }
    if (IS_ATOM_INT(_1649)) {
        _1650 = _1649 - _offset_3403;
        if ((long)((unsigned long)_1650 +(unsigned long) HIGH_BITS) >= 0){
            _1650 = NewDouble((double)_1650);
        }
    }
    else {
        _1650 = NewDouble(DBL_PTR(_1649)->dbl - (double)_offset_3403);
    }
    DeRef(_1649);
    _1649 = NOVALUE;
    _1651 = (_17ch_3129 != -1);
    if (IS_ATOM_INT(_1650)) {
        _1652 = _1650 - _1651;
        if ((long)((unsigned long)_1652 +(unsigned long) HIGH_BITS) >= 0){
            _1652 = NewDouble((double)_1652);
        }
    }
    else {
        _1652 = NewDouble(DBL_PTR(_1650)->dbl - (double)_1651);
    }
    DeRef(_1650);
    _1650 = NOVALUE;
    _1651 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1652;
    ((int *)_2)[2] = _17leading_whitespace_3397;
    _1653 = MAKE_SEQ(_1);
    _1652 = NOVALUE;
    Concat((object_ptr)&_1654, _e_3401, _1653);
    DeRefDS(_1653);
    _1653 = NOVALUE;
    DeRef(_s_3400);
    DeRefDS(_e_3401);
    DeRef(_1582);
    _1582 = NOVALUE;
    DeRef(_1594);
    _1594 = NOVALUE;
    DeRef(_1600);
    _1600 = NOVALUE;
    DeRef(_1607);
    _1607 = NOVALUE;
    DeRef(_1619);
    _1619 = NOVALUE;
    DeRef(_1625);
    _1625 = NOVALUE;
    DeRef(_1631);
    _1631 = NOVALUE;
    DeRef(_1640);
    _1640 = NOVALUE;
    DeRef(_1646);
    _1646 = NOVALUE;
    return _1654;
    goto L4; // [727] 94
L17: 

    /** 		elsif ch = '\'' then*/
    if (_17ch_3129 != 39)
    goto L18; // [734] 784

    /** 			e = get_qchar()*/
    _0 = _e_3401;
    _e_3401 = _17get_qchar();
    DeRef(_0);

    /** 			return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1657 = _17string_next_3128 - 1;
    if ((long)((unsigned long)_1657 +(unsigned long) HIGH_BITS) >= 0){
        _1657 = NewDouble((double)_1657);
    }
    if (IS_ATOM_INT(_1657)) {
        _1658 = _1657 - _offset_3403;
        if ((long)((unsigned long)_1658 +(unsigned long) HIGH_BITS) >= 0){
            _1658 = NewDouble((double)_1658);
        }
    }
    else {
        _1658 = NewDouble(DBL_PTR(_1657)->dbl - (double)_offset_3403);
    }
    DeRef(_1657);
    _1657 = NOVALUE;
    _1659 = (_17ch_3129 != -1);
    if (IS_ATOM_INT(_1658)) {
        _1660 = _1658 - _1659;
        if ((long)((unsigned long)_1660 +(unsigned long) HIGH_BITS) >= 0){
            _1660 = NewDouble((double)_1660);
        }
    }
    else {
        _1660 = NewDouble(DBL_PTR(_1658)->dbl - (double)_1659);
    }
    DeRef(_1658);
    _1658 = NOVALUE;
    _1659 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1660;
    ((int *)_2)[2] = _17leading_whitespace_3397;
    _1661 = MAKE_SEQ(_1);
    _1660 = NOVALUE;
    Concat((object_ptr)&_1662, _e_3401, _1661);
    DeRefDS(_1661);
    _1661 = NOVALUE;
    DeRef(_s_3400);
    DeRefDS(_e_3401);
    DeRef(_1582);
    _1582 = NOVALUE;
    DeRef(_1594);
    _1594 = NOVALUE;
    DeRef(_1600);
    _1600 = NOVALUE;
    DeRef(_1607);
    _1607 = NOVALUE;
    DeRef(_1619);
    _1619 = NOVALUE;
    DeRef(_1625);
    _1625 = NOVALUE;
    DeRef(_1631);
    _1631 = NOVALUE;
    DeRef(_1640);
    _1640 = NOVALUE;
    DeRef(_1646);
    _1646 = NOVALUE;
    DeRef(_1654);
    _1654 = NOVALUE;
    return _1662;
    goto L4; // [781] 94
L18: 

    /** 			return {GET_FAIL, 0, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _1663 = _17string_next_3128 - 1;
    if ((long)((unsigned long)_1663 +(unsigned long) HIGH_BITS) >= 0){
        _1663 = NewDouble((double)_1663);
    }
    if (IS_ATOM_INT(_1663)) {
        _1664 = _1663 - _offset_3403;
        if ((long)((unsigned long)_1664 +(unsigned long) HIGH_BITS) >= 0){
            _1664 = NewDouble((double)_1664);
        }
    }
    else {
        _1664 = NewDouble(DBL_PTR(_1663)->dbl - (double)_offset_3403);
    }
    DeRef(_1663);
    _1663 = NOVALUE;
    _1665 = (_17ch_3129 != -1);
    if (IS_ATOM_INT(_1664)) {
        _1666 = _1664 - _1665;
        if ((long)((unsigned long)_1666 +(unsigned long) HIGH_BITS) >= 0){
            _1666 = NewDouble((double)_1666);
        }
    }
    else {
        _1666 = NewDouble(DBL_PTR(_1664)->dbl - (double)_1665);
    }
    DeRef(_1664);
    _1664 = NOVALUE;
    _1665 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _1666;
    *((int *)(_2+16)) = _17leading_whitespace_3397;
    _1667 = MAKE_SEQ(_1);
    _1666 = NOVALUE;
    DeRef(_s_3400);
    DeRef(_e_3401);
    DeRef(_1582);
    _1582 = NOVALUE;
    DeRef(_1594);
    _1594 = NOVALUE;
    DeRef(_1600);
    _1600 = NOVALUE;
    DeRef(_1607);
    _1607 = NOVALUE;
    DeRef(_1619);
    _1619 = NOVALUE;
    DeRef(_1625);
    _1625 = NOVALUE;
    DeRef(_1631);
    _1631 = NOVALUE;
    DeRef(_1640);
    _1640 = NOVALUE;
    DeRef(_1646);
    _1646 = NOVALUE;
    DeRef(_1654);
    _1654 = NOVALUE;
    DeRef(_1662);
    _1662 = NOVALUE;
    return _1667;

    /** 	end while*/
    goto L4; // [822] 94
    ;
}



// 0xEB8FAA53
