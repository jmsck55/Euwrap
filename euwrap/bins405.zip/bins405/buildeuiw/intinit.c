// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _68intoptions()
{
    int _pause_msg_63331 = NOVALUE;
    int _opts_array_63341 = NOVALUE;
    int _opts_63344 = NOVALUE;
    int _opt_keys_63353 = NOVALUE;
    int _option_w_63355 = NOVALUE;
    int _key_63359 = NOVALUE;
    int _val_63361 = NOVALUE;
    int _31727 = NOVALUE;
    int _31725 = NOVALUE;
    int _31724 = NOVALUE;
    int _31723 = NOVALUE;
    int _31721 = NOVALUE;
    int _31720 = NOVALUE;
    int _31719 = NOVALUE;
    int _31718 = NOVALUE;
    int _31713 = NOVALUE;
    int _31710 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence pause_msg = GetMsgText(278, 0)*/
    RefDS(_22037);
    _0 = _pause_msg_63331;
    _pause_msg_63331 = _44GetMsgText(278, 0, _22037);
    DeRef(_0);

    /** 	Argv = expand_config_options(Argv)*/
    RefDS(_26Argv_11993);
    _0 = _39expand_config_options(_26Argv_11993);
    DeRefDS(_26Argv_11993);
    _26Argv_11993 = _0;

    /** 	Argc = length(Argv)*/
    if (IS_SEQUENCE(_26Argv_11993)){
            _26Argc_11992 = SEQ_PTR(_26Argv_11993)->length;
    }
    else {
        _26Argc_11992 = 1;
    }

    /** 	sequence opts_array = get_options()*/
    _0 = _opts_array_63341;
    _opts_array_63341 = _39get_options();
    DeRef(_0);

    /** 	m:map opts = cmd_parse( opts_array, */
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 10;
    *((int *)(_2+8)) = 4;
    *((int *)(_2+12)) = 8;
    RefDS(_pause_msg_63331);
    *((int *)(_2+16)) = _pause_msg_63331;
    _31710 = MAKE_SEQ(_1);
    RefDS(_opts_array_63341);
    RefDS(_26Argv_11993);
    _0 = _opts_63344;
    _opts_63344 = _40cmd_parse(_opts_array_63341, _31710, _26Argv_11993);
    DeRef(_0);
    _31710 = NOVALUE;

    /** 	handle_common_options(opts)*/
    Ref(_opts_63344);
    _39handle_common_options(_opts_63344);

    /** 	sequence opt_keys = map:keys(opts)*/
    Ref(_opts_63344);
    _0 = _opt_keys_63353;
    _opt_keys_63353 = _32keys(_opts_63344, 0);
    DeRef(_0);

    /** 	integer option_w = 0*/
    _option_w_63355 = 0;

    /** 	for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_63353)){
            _31713 = SEQ_PTR(_opt_keys_63353)->length;
    }
    else {
        _31713 = 1;
    }
    {
        int _idx_63357;
        _idx_63357 = 1;
L1: 
        if (_idx_63357 > _31713){
            goto L2; // [84] 188
        }

        /** 		sequence key = opt_keys[idx]*/
        DeRef(_key_63359);
        _2 = (int)SEQ_PTR(_opt_keys_63353);
        _key_63359 = (int)*(((s1_ptr)_2)->base + _idx_63357);
        Ref(_key_63359);

        /** 		object val = map:get(opts, key)*/
        Ref(_opts_63344);
        RefDS(_key_63359);
        _0 = _val_63361;
        _val_63361 = _32get(_opts_63344, _key_63359, 0);
        DeRef(_0);

        /** 		switch key do*/
        _1 = find(_key_63359, _31716);
        switch ( _1 ){ 

            /** 			case "coverage" then*/
            case 1:

            /** 				for i = 1 to length( val ) do*/
            if (IS_SEQUENCE(_val_63361)){
                    _31718 = SEQ_PTR(_val_63361)->length;
            }
            else {
                _31718 = 1;
            }
            {
                int _i_63367;
                _i_63367 = 1;
L3: 
                if (_i_63367 > _31718){
                    goto L4; // [123] 146
                }

                /** 					add_coverage( val[i] )*/
                _2 = (int)SEQ_PTR(_val_63361);
                _31719 = (int)*(((s1_ptr)_2)->base + _i_63367);
                Ref(_31719);
                _49add_coverage(_31719);
                _31719 = NOVALUE;

                /** 				end for*/
                _i_63367 = _i_63367 + 1;
                goto L3; // [141] 130
L4: 
                ;
            }
            goto L5; // [146] 179

            /** 			case "coverage-db" then*/
            case 2:

            /** 				coverage_db( val )*/
            Ref(_val_63361);
            _49coverage_db(_val_63361);
            goto L5; // [157] 179

            /** 			case "coverage-erase" then*/
            case 3:

            /** 				new_coverage_db()*/
            _49new_coverage_db();
            goto L5; // [167] 179

            /** 			case "coverage-exclude" then*/
            case 4:

            /** 				coverage_exclude( val )*/
            Ref(_val_63361);
            _49coverage_exclude(_val_63361);
        ;}L5: 
        DeRef(_key_63359);
        _key_63359 = NOVALUE;
        DeRef(_val_63361);
        _val_63361 = NOVALUE;

        /** 	end for*/
        _idx_63357 = _idx_63357 + 1;
        goto L1; // [183] 91
L2: 
        ;
    }

    /** 	if length(m:get(opts, cmdline:EXTRAS)) = 0 then*/
    Ref(_opts_63344);
    RefDS(_40EXTRAS_15467);
    _31720 = _32get(_opts_63344, _40EXTRAS_15467, 0);
    if (IS_SEQUENCE(_31720)){
            _31721 = SEQ_PTR(_31720)->length;
    }
    else {
        _31721 = 1;
    }
    DeRef(_31720);
    _31720 = NOVALUE;
    if (_31721 != 0)
    goto L6; // [201] 249

    /** 		show_banner()*/
    _39show_banner();

    /** 		ShowMsg(2, 249)*/
    RefDS(_22037);
    _44ShowMsg(2, 249, _22037, 1);

    /** 		if not batch_job and not test_only then*/
    _31723 = (_26batch_job_11995 == 0);
    if (_31723 == 0) {
        goto L7; // [224] 244
    }
    _31725 = (_26test_only_11994 == 0);
    if (_31725 == 0)
    {
        DeRef(_31725);
        _31725 = NOVALUE;
        goto L7; // [234] 244
    }
    else{
        DeRef(_31725);
        _31725 = NOVALUE;
    }

    /** 			maybe_any_key(pause_msg)*/
    RefDS(_pause_msg_63331);
    _41maybe_any_key(_pause_msg_63331, 1);
L7: 

    /** 		abort(1)*/
    UserCleanup(1);
L6: 

    /** 	OpDefines &= { "EUI" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_31726);
    *((int *)(_2+4)) = _31726;
    _31727 = MAKE_SEQ(_1);
    Concat((object_ptr)&_26OpDefines_12056, _26OpDefines_12056, _31727);
    DeRefDS(_31727);
    _31727 = NOVALUE;

    /** 	finalize_command_line(opts)*/
    Ref(_opts_63344);
    _39finalize_command_line(_opts_63344);

    /** end procedure*/
    DeRef(_pause_msg_63331);
    DeRef(_opts_array_63341);
    DeRef(_opts_63344);
    DeRef(_opt_keys_63353);
    _31720 = NOVALUE;
    DeRef(_31723);
    _31723 = NOVALUE;
    return;
    ;
}



// 0x8F0EF20F
