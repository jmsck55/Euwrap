// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _24sort(int _x_5302, int _order_5303)
{
    int _gap_5304 = NOVALUE;
    int _j_5305 = NOVALUE;
    int _first_5306 = NOVALUE;
    int _last_5307 = NOVALUE;
    int _tempi_5308 = NOVALUE;
    int _tempj_5309 = NOVALUE;
    int _2659 = NOVALUE;
    int _2655 = NOVALUE;
    int _2652 = NOVALUE;
    int _2648 = NOVALUE;
    int _2645 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if order >= 0 then*/

    /** 		order = -1*/
    _order_5303 = -1;
    goto L1; // [16] 25

    /** 		order = 1*/
    _order_5303 = 1;
L1: 

    /** 	last = length(x)*/
    if (IS_SEQUENCE(_x_5302)){
            _last_5307 = SEQ_PTR(_x_5302)->length;
    }
    else {
        _last_5307 = 1;
    }

    /** 	gap = floor(last / 10) + 1*/
    if (10 > 0 && _last_5307 >= 0) {
        _2645 = _last_5307 / 10;
    }
    else {
        temp_dbl = floor((double)_last_5307 / (double)10);
        _2645 = (long)temp_dbl;
    }
    _gap_5304 = _2645 + 1;
    _2645 = NOVALUE;

    /** 	while 1 do*/
L2: 

    /** 		first = gap + 1*/
    _first_5306 = _gap_5304 + 1;

    /** 		for i = first to last do*/
    _2648 = _last_5307;
    {
        int _i_5319;
        _i_5319 = _first_5306;
L3: 
        if (_i_5319 > _2648){
            goto L4; // [56] 152
        }

        /** 			tempi = x[i]*/
        DeRef(_tempi_5308);
        _2 = (int)SEQ_PTR(_x_5302);
        _tempi_5308 = (int)*(((s1_ptr)_2)->base + _i_5319);
        Ref(_tempi_5308);

        /** 			j = i - gap*/
        _j_5305 = _i_5319 - _gap_5304;

        /** 			while 1 do*/
L5: 

        /** 				tempj = x[j]*/
        DeRef(_tempj_5309);
        _2 = (int)SEQ_PTR(_x_5302);
        _tempj_5309 = (int)*(((s1_ptr)_2)->base + _j_5305);
        Ref(_tempj_5309);

        /** 				if eu:compare(tempi, tempj) != order then*/
        if (IS_ATOM_INT(_tempi_5308) && IS_ATOM_INT(_tempj_5309)){
            _2652 = (_tempi_5308 < _tempj_5309) ? -1 : (_tempi_5308 > _tempj_5309);
        }
        else{
            _2652 = compare(_tempi_5308, _tempj_5309);
        }
        if (_2652 == _order_5303)
        goto L6; // [92] 107

        /** 					j += gap*/
        _j_5305 = _j_5305 + _gap_5304;

        /** 					exit*/
        goto L7; // [104] 139
L6: 

        /** 				x[j+gap] = tempj*/
        _2655 = _j_5305 + _gap_5304;
        Ref(_tempj_5309);
        _2 = (int)SEQ_PTR(_x_5302);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_5302 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _2655);
        _1 = *(int *)_2;
        *(int *)_2 = _tempj_5309;
        DeRef(_1);

        /** 				if j <= gap then*/
        if (_j_5305 > _gap_5304)
        goto L8; // [119] 128

        /** 					exit*/
        goto L7; // [125] 139
L8: 

        /** 				j -= gap*/
        _j_5305 = _j_5305 - _gap_5304;

        /** 			end while*/
        goto L5; // [136] 80
L7: 

        /** 			x[j] = tempi*/
        Ref(_tempi_5308);
        _2 = (int)SEQ_PTR(_x_5302);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_5302 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _j_5305);
        _1 = *(int *)_2;
        *(int *)_2 = _tempi_5308;
        DeRef(_1);

        /** 		end for*/
        _i_5319 = _i_5319 + 1;
        goto L3; // [147] 63
L4: 
        ;
    }

    /** 		if gap = 1 then*/
    if (_gap_5304 != 1)
    goto L9; // [154] 167

    /** 			return x*/
    DeRef(_tempi_5308);
    DeRef(_tempj_5309);
    DeRef(_2655);
    _2655 = NOVALUE;
    return _x_5302;
    goto L2; // [164] 45
L9: 

    /** 			gap = floor(gap / 7) + 1*/
    if (7 > 0 && _gap_5304 >= 0) {
        _2659 = _gap_5304 / 7;
    }
    else {
        temp_dbl = floor((double)_gap_5304 / (double)7);
        _2659 = (long)temp_dbl;
    }
    _gap_5304 = _2659 + 1;
    _2659 = NOVALUE;

    /** 	end while*/
    goto L2; // [180] 45
    ;
}


int _24custom_sort(int _custom_compare_5340, int _x_5341, int _data_5342, int _order_5343)
{
    int _gap_5344 = NOVALUE;
    int _j_5345 = NOVALUE;
    int _first_5346 = NOVALUE;
    int _last_5347 = NOVALUE;
    int _tempi_5348 = NOVALUE;
    int _tempj_5349 = NOVALUE;
    int _result_5350 = NOVALUE;
    int _args_5351 = NOVALUE;
    int _2687 = NOVALUE;
    int _2683 = NOVALUE;
    int _2680 = NOVALUE;
    int _2678 = NOVALUE;
    int _2677 = NOVALUE;
    int _2672 = NOVALUE;
    int _2669 = NOVALUE;
    int _2665 = NOVALUE;
    int _2663 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence args = {0, 0}*/
    DeRef(_args_5351);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _args_5351 = MAKE_SEQ(_1);

    /** 	if order >= 0 then*/

    /** 		order = -1*/
    _order_5343 = -1;
    goto L1; // [24] 33

    /** 		order = 1*/
    _order_5343 = 1;
L1: 

    /** 	if atom(data) then*/
    _2663 = IS_ATOM(_data_5342);
    if (_2663 == 0)
    {
        _2663 = NOVALUE;
        goto L2; // [38] 50
    }
    else{
        _2663 = NOVALUE;
    }

    /** 		args &= data*/
    if (IS_SEQUENCE(_args_5351) && IS_ATOM(_data_5342)) {
        Ref(_data_5342);
        Append(&_args_5351, _args_5351, _data_5342);
    }
    else if (IS_ATOM(_args_5351) && IS_SEQUENCE(_data_5342)) {
    }
    else {
        Concat((object_ptr)&_args_5351, _args_5351, _data_5342);
    }
    goto L3; // [47] 70
L2: 

    /** 	elsif length(data) then*/
    _2665 = 0;
L3: 

    /** 	last = length(x)*/
    if (IS_SEQUENCE(_x_5341)){
            _last_5347 = SEQ_PTR(_x_5341)->length;
    }
    else {
        _last_5347 = 1;
    }

    /** 	gap = floor(last / 10) + 1*/
    if (10 > 0 && _last_5347 >= 0) {
        _2669 = _last_5347 / 10;
    }
    else {
        temp_dbl = floor((double)_last_5347 / (double)10);
        _2669 = (long)temp_dbl;
    }
    _gap_5344 = _2669 + 1;
    _2669 = NOVALUE;

    /** 	while 1 do*/
L4: 

    /** 		first = gap + 1*/
    _first_5346 = _gap_5344 + 1;

    /** 		for i = first to last do*/
    _2672 = _last_5347;
    {
        int _i_5369;
        _i_5369 = _first_5346;
L5: 
        if (_i_5369 > _2672){
            goto L6; // [101] 240
        }

        /** 			tempi = x[i]*/
        DeRef(_tempi_5348);
        _2 = (int)SEQ_PTR(_x_5341);
        _tempi_5348 = (int)*(((s1_ptr)_2)->base + _i_5369);
        Ref(_tempi_5348);

        /** 			args[1] = tempi*/
        Ref(_tempi_5348);
        _2 = (int)SEQ_PTR(_args_5351);
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _tempi_5348;
        DeRef(_1);

        /** 			j = i - gap*/
        _j_5345 = _i_5369 - _gap_5344;

        /** 			while 1 do*/
L7: 

        /** 				tempj = x[j]*/
        DeRef(_tempj_5349);
        _2 = (int)SEQ_PTR(_x_5341);
        _tempj_5349 = (int)*(((s1_ptr)_2)->base + _j_5345);
        Ref(_tempj_5349);

        /** 				args[2] = tempj*/
        Ref(_tempj_5349);
        _2 = (int)SEQ_PTR(_args_5351);
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _tempj_5349;
        DeRef(_1);

        /** 				result = call_func(custom_compare, args)*/
        _1 = (int)SEQ_PTR(_args_5351);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_custom_compare_5340].addr;
        switch(((s1_ptr)_1)->length) {
            case 0:
                _1 = (*(int (*)())_0)(
                                     );
                break;
            case 1:
                Ref(*(int *)(_2+4));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4)
                                     );
                break;
            case 2:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
                break;
            case 3:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
                break;
            case 4:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
                break;
            case 5:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
                break;
            case 6:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24)
                                     );
                break;
            case 7:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                Ref(*(int *)(_2+28));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24), 
                                    *(int *)(_2+28)
                                     );
                break;
            case 8:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                Ref(*(int *)(_2+28));
                Ref(*(int *)(_2+32));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24), 
                                    *(int *)(_2+28), 
                                    *(int *)(_2+32)
                                     );
                break;
            case 9:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                Ref(*(int *)(_2+28));
                Ref(*(int *)(_2+32));
                Ref(*(int *)(_2+36));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24), 
                                    *(int *)(_2+28), 
                                    *(int *)(_2+32), 
                                    *(int *)(_2+36)
                                     );
                break;
        }
        DeRef(_result_5350);
        _result_5350 = _1;

        /** 				if sequence(result) then*/
        _2677 = IS_SEQUENCE(_result_5350);
        if (_2677 == 0)
        {
            _2677 = NOVALUE;
            goto L8; // [154] 174
        }
        else{
            _2677 = NOVALUE;
        }

        /** 					args[3] = result[2]*/
        _2 = (int)SEQ_PTR(_result_5350);
        _2678 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_2678);
        _2 = (int)SEQ_PTR(_args_5351);
        _2 = (int)(((s1_ptr)_2)->base + 3);
        _1 = *(int *)_2;
        *(int *)_2 = _2678;
        if( _1 != _2678 ){
            DeRef(_1);
        }
        _2678 = NOVALUE;

        /** 					result = result[1]*/
        _0 = _result_5350;
        _2 = (int)SEQ_PTR(_result_5350);
        _result_5350 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_result_5350);
        DeRef(_0);
L8: 

        /** 				if eu:compare(result, 0) != order then*/
        if (IS_ATOM_INT(_result_5350) && IS_ATOM_INT(0)){
            _2680 = (_result_5350 < 0) ? -1 : (_result_5350 > 0);
        }
        else{
            _2680 = compare(_result_5350, 0);
        }
        if (_2680 == _order_5343)
        goto L9; // [180] 195

        /** 					j += gap*/
        _j_5345 = _j_5345 + _gap_5344;

        /** 					exit*/
        goto LA; // [192] 227
L9: 

        /** 				x[j+gap] = tempj*/
        _2683 = _j_5345 + _gap_5344;
        Ref(_tempj_5349);
        _2 = (int)SEQ_PTR(_x_5341);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_5341 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _2683);
        _1 = *(int *)_2;
        *(int *)_2 = _tempj_5349;
        DeRef(_1);

        /** 				if j <= gap then*/
        if (_j_5345 > _gap_5344)
        goto LB; // [207] 216

        /** 					exit*/
        goto LA; // [213] 227
LB: 

        /** 				j -= gap*/
        _j_5345 = _j_5345 - _gap_5344;

        /** 			end while*/
        goto L7; // [224] 131
LA: 

        /** 			x[j] = tempi*/
        Ref(_tempi_5348);
        _2 = (int)SEQ_PTR(_x_5341);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_5341 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _j_5345);
        _1 = *(int *)_2;
        *(int *)_2 = _tempi_5348;
        DeRef(_1);

        /** 		end for*/
        _i_5369 = _i_5369 + 1;
        goto L5; // [235] 108
L6: 
        ;
    }

    /** 		if gap = 1 then*/
    if (_gap_5344 != 1)
    goto LC; // [242] 255

    /** 			return x*/
    DeRef(_data_5342);
    DeRef(_tempi_5348);
    DeRef(_tempj_5349);
    DeRef(_result_5350);
    DeRef(_args_5351);
    DeRef(_2683);
    _2683 = NOVALUE;
    return _x_5341;
    goto L4; // [252] 90
LC: 

    /** 			gap = floor(gap / 7) + 1*/
    if (7 > 0 && _gap_5344 >= 0) {
        _2687 = _gap_5344 / 7;
    }
    else {
        temp_dbl = floor((double)_gap_5344 / (double)7);
        _2687 = (long)temp_dbl;
    }
    _gap_5344 = _2687 + 1;
    _2687 = NOVALUE;

    /** 	end while*/
    goto L4; // [268] 90
    ;
}


int _24column_compare(int _a_5395, int _b_5396, int _cols_5397)
{
    int _sign_5398 = NOVALUE;
    int _column_5399 = NOVALUE;
    int _2710 = NOVALUE;
    int _2708 = NOVALUE;
    int _2707 = NOVALUE;
    int _2706 = NOVALUE;
    int _2705 = NOVALUE;
    int _2704 = NOVALUE;
    int _2703 = NOVALUE;
    int _2701 = NOVALUE;
    int _2700 = NOVALUE;
    int _2699 = NOVALUE;
    int _2697 = NOVALUE;
    int _2695 = NOVALUE;
    int _2692 = NOVALUE;
    int _2690 = NOVALUE;
    int _2689 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(cols) do*/
    if (IS_SEQUENCE(_cols_5397)){
            _2689 = SEQ_PTR(_cols_5397)->length;
    }
    else {
        _2689 = 1;
    }
    {
        int _i_5401;
        _i_5401 = 1;
L1: 
        if (_i_5401 > _2689){
            goto L2; // [6] 176
        }

        /** 		if cols[i] < 0 then*/
        _2 = (int)SEQ_PTR(_cols_5397);
        _2690 = (int)*(((s1_ptr)_2)->base + _i_5401);
        if (binary_op_a(GREATEREQ, _2690, 0)){
            _2690 = NOVALUE;
            goto L3; // [19] 42
        }
        _2690 = NOVALUE;

        /** 			sign = -1*/
        _sign_5398 = -1;

        /** 			column = -cols[i]*/
        _2 = (int)SEQ_PTR(_cols_5397);
        _2692 = (int)*(((s1_ptr)_2)->base + _i_5401);
        if (IS_ATOM_INT(_2692)) {
            if ((unsigned long)_2692 == 0xC0000000)
            _column_5399 = (int)NewDouble((double)-0xC0000000);
            else
            _column_5399 = - _2692;
        }
        else {
            _column_5399 = unary_op(UMINUS, _2692);
        }
        _2692 = NOVALUE;
        if (!IS_ATOM_INT(_column_5399)) {
            _1 = (long)(DBL_PTR(_column_5399)->dbl);
            DeRefDS(_column_5399);
            _column_5399 = _1;
        }
        goto L4; // [39] 56
L3: 

        /** 			sign = 1*/
        _sign_5398 = 1;

        /** 			column = cols[i]*/
        _2 = (int)SEQ_PTR(_cols_5397);
        _column_5399 = (int)*(((s1_ptr)_2)->base + _i_5401);
        if (!IS_ATOM_INT(_column_5399)){
            _column_5399 = (long)DBL_PTR(_column_5399)->dbl;
        }
L4: 

        /** 		if column <= length(a) then*/
        if (IS_SEQUENCE(_a_5395)){
                _2695 = SEQ_PTR(_a_5395)->length;
        }
        else {
            _2695 = 1;
        }
        if (_column_5399 > _2695)
        goto L5; // [63] 137

        /** 			if column <= length(b) then*/
        if (IS_SEQUENCE(_b_5396)){
                _2697 = SEQ_PTR(_b_5396)->length;
        }
        else {
            _2697 = 1;
        }
        if (_column_5399 > _2697)
        goto L6; // [72] 121

        /** 				if not equal(a[column], b[column]) then*/
        _2 = (int)SEQ_PTR(_a_5395);
        _2699 = (int)*(((s1_ptr)_2)->base + _column_5399);
        _2 = (int)SEQ_PTR(_b_5396);
        _2700 = (int)*(((s1_ptr)_2)->base + _column_5399);
        if (_2699 == _2700)
        _2701 = 1;
        else if (IS_ATOM_INT(_2699) && IS_ATOM_INT(_2700))
        _2701 = 0;
        else
        _2701 = (compare(_2699, _2700) == 0);
        _2699 = NOVALUE;
        _2700 = NOVALUE;
        if (_2701 != 0)
        goto L7; // [90] 169
        _2701 = NOVALUE;

        /** 					return sign * eu:compare(a[column], b[column])*/
        _2 = (int)SEQ_PTR(_a_5395);
        _2703 = (int)*(((s1_ptr)_2)->base + _column_5399);
        _2 = (int)SEQ_PTR(_b_5396);
        _2704 = (int)*(((s1_ptr)_2)->base + _column_5399);
        if (IS_ATOM_INT(_2703) && IS_ATOM_INT(_2704)){
            _2705 = (_2703 < _2704) ? -1 : (_2703 > _2704);
        }
        else{
            _2705 = compare(_2703, _2704);
        }
        _2703 = NOVALUE;
        _2704 = NOVALUE;
        if (_sign_5398 == (short)_sign_5398)
        _2706 = _sign_5398 * _2705;
        else
        _2706 = NewDouble(_sign_5398 * (double)_2705);
        _2705 = NOVALUE;
        DeRef(_a_5395);
        DeRef(_b_5396);
        DeRef(_cols_5397);
        return _2706;
        goto L7; // [118] 169
L6: 

        /** 				return sign * -1*/
        if (_sign_5398 == (short)_sign_5398)
        _2707 = _sign_5398 * -1;
        else
        _2707 = NewDouble(_sign_5398 * (double)-1);
        DeRef(_a_5395);
        DeRef(_b_5396);
        DeRef(_cols_5397);
        DeRef(_2706);
        _2706 = NOVALUE;
        return _2707;
        goto L7; // [134] 169
L5: 

        /** 			if column <= length(b) then*/
        if (IS_SEQUENCE(_b_5396)){
                _2708 = SEQ_PTR(_b_5396)->length;
        }
        else {
            _2708 = 1;
        }
        if (_column_5399 > _2708)
        goto L8; // [142] 161

        /** 				return sign * 1*/
        _2710 = _sign_5398 * 1;
        DeRef(_a_5395);
        DeRef(_b_5396);
        DeRef(_cols_5397);
        DeRef(_2706);
        _2706 = NOVALUE;
        DeRef(_2707);
        _2707 = NOVALUE;
        return _2710;
        goto L9; // [158] 168
L8: 

        /** 				return 0*/
        DeRef(_a_5395);
        DeRef(_b_5396);
        DeRef(_cols_5397);
        DeRef(_2706);
        _2706 = NOVALUE;
        DeRef(_2707);
        _2707 = NOVALUE;
        DeRef(_2710);
        _2710 = NOVALUE;
        return 0;
L9: 
L7: 

        /** 	end for*/
        _i_5401 = _i_5401 + 1;
        goto L1; // [171] 13
L2: 
        ;
    }

    /** 	return 0*/
    DeRef(_a_5395);
    DeRef(_b_5396);
    DeRef(_cols_5397);
    DeRef(_2706);
    _2706 = NOVALUE;
    DeRef(_2707);
    _2707 = NOVALUE;
    DeRef(_2710);
    _2710 = NOVALUE;
    return 0;
    ;
}



// 0x3E28C65E
