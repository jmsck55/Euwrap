// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _31version_major()
{
    int _6604 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return version_info[MAJ_VER]*/
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _6604 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_6604);
    return _6604;
    ;
}


int _31version_minor()
{
    int _6605 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return version_info[MIN_VER]*/
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _6605 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_6605);
    return _6605;
    ;
}


int _31version_patch()
{
    int _6606 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return version_info[PAT_VER]*/
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _6606 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_6606);
    return _6606;
    ;
}


int _31version_node(int _full_12155)
{
    int _6613 = NOVALUE;
    int _6612 = NOVALUE;
    int _6611 = NOVALUE;
    int _6610 = NOVALUE;
    int _6609 = NOVALUE;
    int _6608 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if full or length(version_info[NODE]) < 12 then*/
    if (0 != 0) {
        goto L1; // [5] 27
    }
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _6608 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6608)){
            _6609 = SEQ_PTR(_6608)->length;
    }
    else {
        _6609 = 1;
    }
    _6608 = NOVALUE;
    _6610 = (_6609 < 12);
    _6609 = NOVALUE;
    if (_6610 == 0)
    {
        DeRef(_6610);
        _6610 = NOVALUE;
        goto L2; // [23] 40
    }
    else{
        DeRef(_6610);
        _6610 = NOVALUE;
    }
L1: 

    /** 		return version_info[NODE]*/
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _6611 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_6611);
    _6608 = NOVALUE;
    return _6611;
L2: 

    /** 	return version_info[NODE][1..12]*/
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _6612 = (int)*(((s1_ptr)_2)->base + 5);
    rhs_slice_target = (object_ptr)&_6613;
    RHS_Slice(_6612, 1, 12);
    _6612 = NOVALUE;
    _6608 = NOVALUE;
    _6611 = NOVALUE;
    return _6613;
    ;
}


int _31version_date(int _full_12169)
{
    int _6622 = NOVALUE;
    int _6621 = NOVALUE;
    int _6620 = NOVALUE;
    int _6619 = NOVALUE;
    int _6618 = NOVALUE;
    int _6617 = NOVALUE;
    int _6615 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if full or is_developmental or length(version_info[REVISION_DATE]) < 10 then*/
    if (_full_12169 != 0) {
        _6615 = 1;
        goto L1; // [5] 15
    }
    _6615 = (_31is_developmental_12125 != 0);
L1: 
    if (_6615 != 0) {
        goto L2; // [15] 37
    }
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _6617 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_6617)){
            _6618 = SEQ_PTR(_6617)->length;
    }
    else {
        _6618 = 1;
    }
    _6617 = NOVALUE;
    _6619 = (_6618 < 10);
    _6618 = NOVALUE;
    if (_6619 == 0)
    {
        DeRef(_6619);
        _6619 = NOVALUE;
        goto L3; // [33] 50
    }
    else{
        DeRef(_6619);
        _6619 = NOVALUE;
    }
L2: 

    /** 		return version_info[REVISION_DATE]*/
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _6620 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_6620);
    _6617 = NOVALUE;
    return _6620;
L3: 

    /** 	return version_info[REVISION_DATE][1..10]*/
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _6621 = (int)*(((s1_ptr)_2)->base + 7);
    rhs_slice_target = (object_ptr)&_6622;
    RHS_Slice(_6621, 1, 10);
    _6621 = NOVALUE;
    _6617 = NOVALUE;
    _6620 = NOVALUE;
    return _6622;
    ;
}


int _31version_string(int _full_12184)
{
    int _version_revision_inlined_version_revision_at_41_12193 = NOVALUE;
    int _6642 = NOVALUE;
    int _6641 = NOVALUE;
    int _6640 = NOVALUE;
    int _6639 = NOVALUE;
    int _6638 = NOVALUE;
    int _6637 = NOVALUE;
    int _6636 = NOVALUE;
    int _6635 = NOVALUE;
    int _6633 = NOVALUE;
    int _6632 = NOVALUE;
    int _6631 = NOVALUE;
    int _6630 = NOVALUE;
    int _6629 = NOVALUE;
    int _6628 = NOVALUE;
    int _6627 = NOVALUE;
    int _6626 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if full or is_developmental then*/
    if (0 != 0) {
        goto L1; // [5] 16
    }
    if (_31is_developmental_12125 == 0)
    {
        goto L2; // [12] 80
    }
    else{
    }
L1: 

    /** 		return sprintf("%d.%d.%d %s (%d:%s, %s)", {*/
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _6626 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _6627 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _6628 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _6629 = (int)*(((s1_ptr)_2)->base + 4);

    /** 	return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_41_12193);
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _version_revision_inlined_version_revision_at_41_12193 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_version_revision_inlined_version_revision_at_41_12193);
    _6630 = _31version_node(0);
    _6631 = _31version_date(_full_12184);
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_6626);
    *((int *)(_2+4)) = _6626;
    Ref(_6627);
    *((int *)(_2+8)) = _6627;
    Ref(_6628);
    *((int *)(_2+12)) = _6628;
    Ref(_6629);
    *((int *)(_2+16)) = _6629;
    Ref(_version_revision_inlined_version_revision_at_41_12193);
    *((int *)(_2+20)) = _version_revision_inlined_version_revision_at_41_12193;
    *((int *)(_2+24)) = _6630;
    *((int *)(_2+28)) = _6631;
    _6632 = MAKE_SEQ(_1);
    _6631 = NOVALUE;
    _6630 = NOVALUE;
    _6629 = NOVALUE;
    _6628 = NOVALUE;
    _6627 = NOVALUE;
    _6626 = NOVALUE;
    _6633 = EPrintf(-9999999, _6625, _6632);
    DeRefDS(_6632);
    _6632 = NOVALUE;
    return _6633;
    goto L3; // [77] 132
L2: 

    /** 		return sprintf("%d.%d.%d %s (%s, %s)", {*/
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _6635 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _6636 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _6637 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _6638 = (int)*(((s1_ptr)_2)->base + 4);
    _6639 = _31version_node(0);
    _6640 = _31version_date(_full_12184);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_6635);
    *((int *)(_2+4)) = _6635;
    Ref(_6636);
    *((int *)(_2+8)) = _6636;
    Ref(_6637);
    *((int *)(_2+12)) = _6637;
    Ref(_6638);
    *((int *)(_2+16)) = _6638;
    *((int *)(_2+20)) = _6639;
    *((int *)(_2+24)) = _6640;
    _6641 = MAKE_SEQ(_1);
    _6640 = NOVALUE;
    _6639 = NOVALUE;
    _6638 = NOVALUE;
    _6637 = NOVALUE;
    _6636 = NOVALUE;
    _6635 = NOVALUE;
    _6642 = EPrintf(-9999999, _6634, _6641);
    DeRefDS(_6641);
    _6641 = NOVALUE;
    DeRef(_6633);
    _6633 = NOVALUE;
    return _6642;
L3: 
    ;
}


int _31euphoria_copyright()
{
    int _version_string_long_1__tmp_at2_12227 = NOVALUE;
    int _version_string_long_inlined_version_string_long_at_2_12226 = NOVALUE;
    int _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_12225 = NOVALUE;
    int _6652 = NOVALUE;
    int _6650 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {*/

    /** 	return version_string(full) & " for " & platform_name()*/
    _0 = _version_string_long_1__tmp_at2_12227;
    _version_string_long_1__tmp_at2_12227 = _31version_string(0);
    DeRef(_0);

    /** 	ifdef WINDOWS then*/

    /** 		return "Windows"*/
    RefDS(_6412);
    DeRefi(_platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_12225);
    _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_12225 = _6412;
    {
        int concat_list[3];

        concat_list[0] = _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_12225;
        concat_list[1] = _6647;
        concat_list[2] = _version_string_long_1__tmp_at2_12227;
        Concat_N((object_ptr)&_version_string_long_inlined_version_string_long_at_2_12226, concat_list, 3);
    }
    DeRefi(_platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_12225);
    _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_12225 = NOVALUE;
    DeRef(_version_string_long_1__tmp_at2_12227);
    _version_string_long_1__tmp_at2_12227 = NOVALUE;
    Concat((object_ptr)&_6650, _6649, _version_string_long_inlined_version_string_long_at_2_12226);
    RefDS(_6651);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _6650;
    ((int *)_2)[2] = _6651;
    _6652 = MAKE_SEQ(_1);
    _6650 = NOVALUE;
    return _6652;
    ;
}


int _31all_copyrights()
{
    int _pcre_copyright_inlined_pcre_copyright_at_5_12240 = NOVALUE;
    int _6657 = NOVALUE;
    int _6656 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {*/
    _6656 = _31euphoria_copyright();

    /** 	return {*/
    RefDS(_6654);
    RefDS(_6653);
    DeRef(_pcre_copyright_inlined_pcre_copyright_at_5_12240);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _6653;
    ((int *)_2)[2] = _6654;
    _pcre_copyright_inlined_pcre_copyright_at_5_12240 = MAKE_SEQ(_1);
    RefDS(_pcre_copyright_inlined_pcre_copyright_at_5_12240);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _6656;
    ((int *)_2)[2] = _pcre_copyright_inlined_pcre_copyright_at_5_12240;
    _6657 = MAKE_SEQ(_1);
    _6656 = NOVALUE;
    return _6657;
    ;
}



// 0xCFB1666F
