// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _44GetMsgText(int _MsgNum_21208, int _WithNum_21209, int _Args_21210)
{
    int _idx_21211 = NOVALUE;
    int _msgtext_21212 = NOVALUE;
    int _12273 = NOVALUE;
    int _12272 = NOVALUE;
    int _12268 = NOVALUE;
    int _12267 = NOVALUE;
    int _12265 = NOVALUE;
    int _12263 = NOVALUE;
    int _12261 = NOVALUE;
    int _12260 = NOVALUE;
    int _12259 = NOVALUE;
    int _12258 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_MsgNum_21208)) {
        _1 = (long)(DBL_PTR(_MsgNum_21208)->dbl);
        DeRefDS(_MsgNum_21208);
        _MsgNum_21208 = _1;
    }

    /** 	integer idx = 1*/
    _idx_21211 = 1;

    /** 	msgtext = get_text( MsgNum, LocalizeQual, LocalDB )*/
    RefDS(_27LocalizeQual_10942);
    RefDS(_27LocalDB_10943);
    _0 = _msgtext_21212;
    _msgtext_21212 = _45get_text(_MsgNum_21208, _27LocalizeQual_10942, _27LocalDB_10943);
    DeRef(_0);

    /** 	if atom(msgtext) then*/
    _12258 = IS_ATOM(_msgtext_21212);
    if (_12258 == 0)
    {
        _12258 = NOVALUE;
        goto L1; // [27] 90
    }
    else{
        _12258 = NOVALUE;
    }

    /** 		for i = 1 to length(StdErrMsgs) do*/
    _12259 = 354;
    {
        int _i_21220;
        _i_21220 = 1;
L2: 
        if (_i_21220 > 354){
            goto L3; // [37] 77
        }

        /** 			if StdErrMsgs[i][1] = MsgNum then*/
        _2 = (int)SEQ_PTR(_44StdErrMsgs_20199);
        _12260 = (int)*(((s1_ptr)_2)->base + _i_21220);
        _2 = (int)SEQ_PTR(_12260);
        _12261 = (int)*(((s1_ptr)_2)->base + 1);
        _12260 = NOVALUE;
        if (binary_op_a(NOTEQ, _12261, _MsgNum_21208)){
            _12261 = NOVALUE;
            goto L4; // [56] 70
        }
        _12261 = NOVALUE;

        /** 				idx = i*/
        _idx_21211 = _i_21220;

        /** 				exit*/
        goto L3; // [67] 77
L4: 

        /** 		end for*/
        _i_21220 = _i_21220 + 1;
        goto L2; // [72] 44
L3: 
        ;
    }

    /** 		msgtext = StdErrMsgs[idx][2]*/
    _2 = (int)SEQ_PTR(_44StdErrMsgs_20199);
    _12263 = (int)*(((s1_ptr)_2)->base + _idx_21211);
    DeRef(_msgtext_21212);
    _2 = (int)SEQ_PTR(_12263);
    _msgtext_21212 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_msgtext_21212);
    _12263 = NOVALUE;
L1: 

    /** 	if atom(Args) or length(Args) != 0 then*/
    _12265 = IS_ATOM(_Args_21210);
    if (_12265 != 0) {
        goto L5; // [95] 111
    }
    if (IS_SEQUENCE(_Args_21210)){
            _12267 = SEQ_PTR(_Args_21210)->length;
    }
    else {
        _12267 = 1;
    }
    _12268 = (_12267 != 0);
    _12267 = NOVALUE;
    if (_12268 == 0)
    {
        DeRef(_12268);
        _12268 = NOVALUE;
        goto L6; // [107] 119
    }
    else{
        DeRef(_12268);
        _12268 = NOVALUE;
    }
L5: 

    /** 		msgtext = format(msgtext, Args)*/
    Ref(_msgtext_21212);
    Ref(_Args_21210);
    _0 = _msgtext_21212;
    _msgtext_21212 = _12format(_msgtext_21212, _Args_21210);
    DeRef(_0);
L6: 

    /** 	if WithNum != 0 then*/
    if (_WithNum_21209 == 0)
    goto L7; // [121] 142

    /** 		return sprintf("<%04d>:: %s", {MsgNum, msgtext})*/
    Ref(_msgtext_21212);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _MsgNum_21208;
    ((int *)_2)[2] = _msgtext_21212;
    _12272 = MAKE_SEQ(_1);
    _12273 = EPrintf(-9999999, _12271, _12272);
    DeRefDS(_12272);
    _12272 = NOVALUE;
    DeRef(_Args_21210);
    DeRef(_msgtext_21212);
    return _12273;
    goto L8; // [139] 149
L7: 

    /** 		return msgtext*/
    DeRef(_Args_21210);
    DeRef(_12273);
    _12273 = NOVALUE;
    return _msgtext_21212;
L8: 
    ;
}


void _44ShowMsg(int _Cons_21243, int _Msg_21244, int _Args_21245, int _NL_21246)
{
    int _12280 = NOVALUE;
    int _12279 = NOVALUE;
    int _12277 = NOVALUE;
    int _12275 = NOVALUE;
    int _12274 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(Msg) then*/
    _12274 = 1;
    if (_12274 == 0)
    {
        _12274 = NOVALUE;
        goto L1; // [10] 25
    }
    else{
        _12274 = NOVALUE;
    }

    /** 		Msg = GetMsgText(floor(Msg), 0)*/
    _12275 = e_floor(_Msg_21244);
    RefDS(_5);
    _Msg_21244 = _44GetMsgText(_12275, 0, _5);
    _12275 = NOVALUE;
L1: 

    /** 	if atom(Args) or length(Args) != 0 then*/
    _12277 = IS_ATOM(_Args_21245);
    if (_12277 != 0) {
        goto L2; // [30] 46
    }
    if (IS_SEQUENCE(_Args_21245)){
            _12279 = SEQ_PTR(_Args_21245)->length;
    }
    else {
        _12279 = 1;
    }
    _12280 = (_12279 != 0);
    _12279 = NOVALUE;
    if (_12280 == 0)
    {
        DeRef(_12280);
        _12280 = NOVALUE;
        goto L3; // [42] 54
    }
    else{
        DeRef(_12280);
        _12280 = NOVALUE;
    }
L2: 

    /** 		Msg = format(Msg, Args)*/
    Ref(_Msg_21244);
    Ref(_Args_21245);
    _0 = _Msg_21244;
    _Msg_21244 = _12format(_Msg_21244, _Args_21245);
    DeRef(_0);
L3: 

    /** 	puts(Cons, Msg)*/
    EPuts(_Cons_21243, _Msg_21244); // DJP 

    /** 	if NL then*/
    if (_NL_21246 == 0)
    {
        goto L4; // [61] 70
    }
    else{
    }

    /** 		puts(Cons, '\n')*/
    EPuts(_Cons_21243, 10); // DJP 
L4: 

    /** end procedure*/
    DeRef(_Msg_21244);
    DeRef(_Args_21245);
    return;
    ;
}



// 0x60231645
