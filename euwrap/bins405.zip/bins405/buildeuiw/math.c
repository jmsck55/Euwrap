// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _20abs(int _a_4677)
{
    int _t_4678 = NOVALUE;
    int _2337 = NOVALUE;
    int _2336 = NOVALUE;
    int _2335 = NOVALUE;
    int _2333 = NOVALUE;
    int _2331 = NOVALUE;
    int _2330 = NOVALUE;
    int _2328 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _2328 = IS_ATOM(_a_4677);
    if (_2328 == 0)
    {
        _2328 = NOVALUE;
        goto L1; // [6] 35
    }
    else{
        _2328 = NOVALUE;
    }

    /** 		if a >= 0 then*/
    if (binary_op_a(LESS, _a_4677, 0)){
        goto L2; // [11] 24
    }

    /** 			return a*/
    DeRef(_t_4678);
    return _a_4677;
    goto L3; // [21] 34
L2: 

    /** 			return - a*/
    if (IS_ATOM_INT(_a_4677)) {
        if ((unsigned long)_a_4677 == 0xC0000000)
        _2330 = (int)NewDouble((double)-0xC0000000);
        else
        _2330 = - _a_4677;
    }
    else {
        _2330 = unary_op(UMINUS, _a_4677);
    }
    DeRef(_a_4677);
    DeRef(_t_4678);
    return _2330;
L3: 
L1: 

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_4677)){
            _2331 = SEQ_PTR(_a_4677)->length;
    }
    else {
        _2331 = 1;
    }
    {
        int _i_4686;
        _i_4686 = 1;
L4: 
        if (_i_4686 > _2331){
            goto L5; // [40] 101
        }

        /** 		t = a[i]*/
        DeRef(_t_4678);
        _2 = (int)SEQ_PTR(_a_4677);
        _t_4678 = (int)*(((s1_ptr)_2)->base + _i_4686);
        Ref(_t_4678);

        /** 		if atom(t) then*/
        _2333 = IS_ATOM(_t_4678);
        if (_2333 == 0)
        {
            _2333 = NOVALUE;
            goto L6; // [58] 80
        }
        else{
            _2333 = NOVALUE;
        }

        /** 			if t < 0 then*/
        if (binary_op_a(GREATEREQ, _t_4678, 0)){
            goto L7; // [63] 94
        }

        /** 				a[i] = - t*/
        if (IS_ATOM_INT(_t_4678)) {
            if ((unsigned long)_t_4678 == 0xC0000000)
            _2335 = (int)NewDouble((double)-0xC0000000);
            else
            _2335 = - _t_4678;
        }
        else {
            _2335 = unary_op(UMINUS, _t_4678);
        }
        _2 = (int)SEQ_PTR(_a_4677);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_4677 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4686);
        _1 = *(int *)_2;
        *(int *)_2 = _2335;
        if( _1 != _2335 ){
            DeRef(_1);
        }
        _2335 = NOVALUE;
        goto L7; // [77] 94
L6: 

        /** 			a[i] = abs(t)*/
        Ref(_t_4678);
        DeRef(_2336);
        _2336 = _t_4678;
        _2337 = _20abs(_2336);
        _2336 = NOVALUE;
        _2 = (int)SEQ_PTR(_a_4677);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_4677 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4686);
        _1 = *(int *)_2;
        *(int *)_2 = _2337;
        if( _1 != _2337 ){
            DeRef(_1);
        }
        _2337 = NOVALUE;
L7: 

        /** 	end for*/
        _i_4686 = _i_4686 + 1;
        goto L4; // [96] 47
L5: 
        ;
    }

    /** 	return a*/
    DeRef(_t_4678);
    DeRef(_2330);
    _2330 = NOVALUE;
    return _a_4677;
    ;
}


int _20max(int _a_4721)
{
    int _b_4722 = NOVALUE;
    int _c_4723 = NOVALUE;
    int _2347 = NOVALUE;
    int _2346 = NOVALUE;
    int _2345 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _2345 = IS_ATOM(_a_4721);
    if (_2345 == 0)
    {
        _2345 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _2345 = NOVALUE;
    }

    /** 		return a*/
    DeRef(_b_4722);
    DeRef(_c_4723);
    return _a_4721;
L1: 

    /** 	b = mathcons:MINF*/
    RefDS(_22MINF_4655);
    DeRef(_b_4722);
    _b_4722 = _22MINF_4655;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_4721)){
            _2346 = SEQ_PTR(_a_4721)->length;
    }
    else {
        _2346 = 1;
    }
    {
        int _i_4727;
        _i_4727 = 1;
L2: 
        if (_i_4727 > _2346){
            goto L3; // [28] 64
        }

        /** 		c = max(a[i])*/
        _2 = (int)SEQ_PTR(_a_4721);
        _2347 = (int)*(((s1_ptr)_2)->base + _i_4727);
        Ref(_2347);
        _0 = _c_4723;
        _c_4723 = _20max(_2347);
        DeRef(_0);
        _2347 = NOVALUE;

        /** 		if c > b then*/
        if (binary_op_a(LESSEQ, _c_4723, _b_4722)){
            goto L4; // [47] 57
        }

        /** 			b = c*/
        Ref(_c_4723);
        DeRef(_b_4722);
        _b_4722 = _c_4723;
L4: 

        /** 	end for*/
        _i_4727 = _i_4727 + 1;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_4721);
    DeRef(_c_4723);
    return _b_4722;
    ;
}


int _20min(int _a_4735)
{
    int _b_4736 = NOVALUE;
    int _c_4737 = NOVALUE;
    int _2352 = NOVALUE;
    int _2351 = NOVALUE;
    int _2350 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _2350 = IS_ATOM(_a_4735);
    if (_2350 == 0)
    {
        _2350 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _2350 = NOVALUE;
    }

    /** 			return a*/
    DeRef(_b_4736);
    DeRef(_c_4737);
    return _a_4735;
L1: 

    /** 	b = mathcons:PINF*/
    RefDS(_22PINF_4652);
    DeRef(_b_4736);
    _b_4736 = _22PINF_4652;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_4735)){
            _2351 = SEQ_PTR(_a_4735)->length;
    }
    else {
        _2351 = 1;
    }
    {
        int _i_4741;
        _i_4741 = 1;
L2: 
        if (_i_4741 > _2351){
            goto L3; // [28] 64
        }

        /** 		c = min(a[i])*/
        _2 = (int)SEQ_PTR(_a_4735);
        _2352 = (int)*(((s1_ptr)_2)->base + _i_4741);
        Ref(_2352);
        _0 = _c_4737;
        _c_4737 = _20min(_2352);
        DeRef(_0);
        _2352 = NOVALUE;

        /** 			if c < b then*/
        if (binary_op_a(GREATEREQ, _c_4737, _b_4736)){
            goto L4; // [47] 57
        }

        /** 				b = c*/
        Ref(_c_4737);
        DeRef(_b_4736);
        _b_4736 = _c_4737;
L4: 

        /** 	end for*/
        _i_4741 = _i_4741 + 1;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_4735);
    DeRef(_c_4737);
    return _b_4736;
    ;
}


int _20or_all(int _a_5114)
{
    int _b_5115 = NOVALUE;
    int _2551 = NOVALUE;
    int _2550 = NOVALUE;
    int _2548 = NOVALUE;
    int _2547 = NOVALUE;
    int _2546 = NOVALUE;
    int _2545 = NOVALUE;
    int _2544 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _2544 = IS_ATOM(_a_5114);
    if (_2544 == 0)
    {
        _2544 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _2544 = NOVALUE;
    }

    /** 		return a*/
    DeRef(_b_5115);
    return _a_5114;
L1: 

    /** 	b = 0*/
    DeRef(_b_5115);
    _b_5115 = 0;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_5114)){
            _2545 = SEQ_PTR(_a_5114)->length;
    }
    else {
        _2545 = 1;
    }
    {
        int _i_5119;
        _i_5119 = 1;
L2: 
        if (_i_5119 > _2545){
            goto L3; // [26] 80
        }

        /** 		if atom(a[i]) then*/
        _2 = (int)SEQ_PTR(_a_5114);
        _2546 = (int)*(((s1_ptr)_2)->base + _i_5119);
        _2547 = IS_ATOM(_2546);
        _2546 = NOVALUE;
        if (_2547 == 0)
        {
            _2547 = NOVALUE;
            goto L4; // [42] 58
        }
        else{
            _2547 = NOVALUE;
        }

        /** 			b = or_bits(b, a[i])*/
        _2 = (int)SEQ_PTR(_a_5114);
        _2548 = (int)*(((s1_ptr)_2)->base + _i_5119);
        _0 = _b_5115;
        if (IS_ATOM_INT(_b_5115) && IS_ATOM_INT(_2548)) {
            {unsigned long tu;
                 tu = (unsigned long)_b_5115 | (unsigned long)_2548;
                 _b_5115 = MAKE_UINT(tu);
            }
        }
        else {
            _b_5115 = binary_op(OR_BITS, _b_5115, _2548);
        }
        DeRef(_0);
        _2548 = NOVALUE;
        goto L5; // [55] 73
L4: 

        /** 			b = or_bits(b, or_all(a[i]))*/
        _2 = (int)SEQ_PTR(_a_5114);
        _2550 = (int)*(((s1_ptr)_2)->base + _i_5119);
        Ref(_2550);
        _2551 = _20or_all(_2550);
        _2550 = NOVALUE;
        _0 = _b_5115;
        if (IS_ATOM_INT(_b_5115) && IS_ATOM_INT(_2551)) {
            {unsigned long tu;
                 tu = (unsigned long)_b_5115 | (unsigned long)_2551;
                 _b_5115 = MAKE_UINT(tu);
            }
        }
        else {
            _b_5115 = binary_op(OR_BITS, _b_5115, _2551);
        }
        DeRef(_0);
        DeRef(_2551);
        _2551 = NOVALUE;
L5: 

        /** 	end for*/
        _i_5119 = _i_5119 + 1;
        goto L2; // [75] 33
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_5114);
    return _b_5115;
    ;
}



// 0xC3D4A50E
