// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _40local_abort(int _lvl_15481)
{
    int _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15486 = NOVALUE;
    int _8406 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(pause_msg) != 0 then*/
    if (IS_SEQUENCE(_40pause_msg_15478)){
            _8406 = SEQ_PTR(_40pause_msg_15478)->length;
    }
    else {
        _8406 = 1;
    }
    if (_8406 == 0)
    goto L1; // [10] 45

    /** 		console:maybe_any_key(pause_msg, 1)*/

    /** 	if not has_console() then*/

    /** 	return machine_func(M_HAS_CONSOLE, 0)*/
    DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15486);
    _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15486 = machine(99, 0);
    if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15486)) {
        if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15486 != 0){
            goto L2; // [27] 42
        }
    }
    else {
        if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15486)->dbl != 0.0){
            goto L2; // [27] 42
        }
    }

    /** 		any_key(prompt, con)*/
    RefDS(_40pause_msg_15478);
    _41any_key(_40pause_msg_15478, 1);

    /** end procedure*/
    goto L2; // [39] 42
L2: 
    DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15486);
    _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15486 = NOVALUE;
L1: 

    /** 	abort(lvl)*/
    UserCleanup(_lvl_15481);

    /** end procedure*/
    return;
    ;
}


int _40standardize_opts(int _opts_15489, int _auto_help_switches_15490)
{
    int _lExtras_15491 = NOVALUE;
    int _opt_15495 = NOVALUE;
    int _updated_15497 = NOVALUE;
    int _msg_inlined_crash_at_178_15529 = NOVALUE;
    int _msg_inlined_crash_at_354_15560 = NOVALUE;
    int _msg_inlined_crash_at_410_15569 = NOVALUE;
    int _msg_inlined_crash_at_460_15578 = NOVALUE;
    int _msg_inlined_crash_at_510_15587 = NOVALUE;
    int _msg_inlined_crash_at_560_15596 = NOVALUE;
    int _opt_15630 = NOVALUE;
    int _msg_inlined_crash_at_878_15649 = NOVALUE;
    int _data_inlined_crash_at_875_15648 = NOVALUE;
    int _msg_inlined_crash_at_967_15667 = NOVALUE;
    int _data_inlined_crash_at_964_15666 = NOVALUE;
    int _has_h_15668 = NOVALUE;
    int _has_help_15669 = NOVALUE;
    int _has_question_15670 = NOVALUE;
    int _appended_opts_15690 = NOVALUE;
    int _8583 = NOVALUE;
    int _8582 = NOVALUE;
    int _8580 = NOVALUE;
    int _8579 = NOVALUE;
    int _8578 = NOVALUE;
    int _8577 = NOVALUE;
    int _8576 = NOVALUE;
    int _8575 = NOVALUE;
    int _8574 = NOVALUE;
    int _8573 = NOVALUE;
    int _8572 = NOVALUE;
    int _8571 = NOVALUE;
    int _8570 = NOVALUE;
    int _8569 = NOVALUE;
    int _8567 = NOVALUE;
    int _8566 = NOVALUE;
    int _8565 = NOVALUE;
    int _8564 = NOVALUE;
    int _8563 = NOVALUE;
    int _8562 = NOVALUE;
    int _8561 = NOVALUE;
    int _8560 = NOVALUE;
    int _8559 = NOVALUE;
    int _8558 = NOVALUE;
    int _8557 = NOVALUE;
    int _8556 = NOVALUE;
    int _8554 = NOVALUE;
    int _8552 = NOVALUE;
    int _8551 = NOVALUE;
    int _8550 = NOVALUE;
    int _8549 = NOVALUE;
    int _8547 = NOVALUE;
    int _8545 = NOVALUE;
    int _8542 = NOVALUE;
    int _8539 = NOVALUE;
    int _8536 = NOVALUE;
    int _8534 = NOVALUE;
    int _8533 = NOVALUE;
    int _8532 = NOVALUE;
    int _8531 = NOVALUE;
    int _8529 = NOVALUE;
    int _8528 = NOVALUE;
    int _8527 = NOVALUE;
    int _8525 = NOVALUE;
    int _8524 = NOVALUE;
    int _8523 = NOVALUE;
    int _8521 = NOVALUE;
    int _8520 = NOVALUE;
    int _8519 = NOVALUE;
    int _8518 = NOVALUE;
    int _8517 = NOVALUE;
    int _8515 = NOVALUE;
    int _8514 = NOVALUE;
    int _8513 = NOVALUE;
    int _8512 = NOVALUE;
    int _8511 = NOVALUE;
    int _8510 = NOVALUE;
    int _8509 = NOVALUE;
    int _8508 = NOVALUE;
    int _8507 = NOVALUE;
    int _8506 = NOVALUE;
    int _8504 = NOVALUE;
    int _8503 = NOVALUE;
    int _8502 = NOVALUE;
    int _8501 = NOVALUE;
    int _8500 = NOVALUE;
    int _8499 = NOVALUE;
    int _8498 = NOVALUE;
    int _8497 = NOVALUE;
    int _8495 = NOVALUE;
    int _8494 = NOVALUE;
    int _8493 = NOVALUE;
    int _8492 = NOVALUE;
    int _8491 = NOVALUE;
    int _8490 = NOVALUE;
    int _8489 = NOVALUE;
    int _8488 = NOVALUE;
    int _8487 = NOVALUE;
    int _8486 = NOVALUE;
    int _8485 = NOVALUE;
    int _8484 = NOVALUE;
    int _8483 = NOVALUE;
    int _8482 = NOVALUE;
    int _8481 = NOVALUE;
    int _8479 = NOVALUE;
    int _8477 = NOVALUE;
    int _8476 = NOVALUE;
    int _8475 = NOVALUE;
    int _8474 = NOVALUE;
    int _8472 = NOVALUE;
    int _8471 = NOVALUE;
    int _8470 = NOVALUE;
    int _8469 = NOVALUE;
    int _8467 = NOVALUE;
    int _8466 = NOVALUE;
    int _8465 = NOVALUE;
    int _8464 = NOVALUE;
    int _8462 = NOVALUE;
    int _8461 = NOVALUE;
    int _8460 = NOVALUE;
    int _8459 = NOVALUE;
    int _8457 = NOVALUE;
    int _8456 = NOVALUE;
    int _8455 = NOVALUE;
    int _8454 = NOVALUE;
    int _8451 = NOVALUE;
    int _8450 = NOVALUE;
    int _8449 = NOVALUE;
    int _8448 = NOVALUE;
    int _8447 = NOVALUE;
    int _8446 = NOVALUE;
    int _8445 = NOVALUE;
    int _8444 = NOVALUE;
    int _8442 = NOVALUE;
    int _8441 = NOVALUE;
    int _8440 = NOVALUE;
    int _8439 = NOVALUE;
    int _8438 = NOVALUE;
    int _8437 = NOVALUE;
    int _8436 = NOVALUE;
    int _8435 = NOVALUE;
    int _8432 = NOVALUE;
    int _8431 = NOVALUE;
    int _8430 = NOVALUE;
    int _8429 = NOVALUE;
    int _8428 = NOVALUE;
    int _8427 = NOVALUE;
    int _8426 = NOVALUE;
    int _8425 = NOVALUE;
    int _8424 = NOVALUE;
    int _8423 = NOVALUE;
    int _8422 = NOVALUE;
    int _8421 = NOVALUE;
    int _8420 = NOVALUE;
    int _8419 = NOVALUE;
    int _8418 = NOVALUE;
    int _8417 = NOVALUE;
    int _8416 = NOVALUE;
    int _8414 = NOVALUE;
    int _8413 = NOVALUE;
    int _8412 = NOVALUE;
    int _8410 = NOVALUE;
    int _8408 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer lExtras = 0 -- Ensure that there is zero or one 'extras' record only.*/
    _lExtras_15491 = 0;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15489)){
            _8408 = SEQ_PTR(_opts_15489)->length;
    }
    else {
        _8408 = 1;
    }
    {
        int _i_15493;
        _i_15493 = 1;
L1: 
        if (_i_15493 > _8408){
            goto L2; // [15] 795
        }

        /** 		sequence opt = opts[i]*/
        DeRef(_opt_15495);
        _2 = (int)SEQ_PTR(_opts_15489);
        _opt_15495 = (int)*(((s1_ptr)_2)->base + _i_15493);
        Ref(_opt_15495);

        /** 		integer updated = 0*/
        _updated_15497 = 0;

        /** 		if length(opt) < MAPNAME then*/
        if (IS_SEQUENCE(_opt_15495)){
                _8410 = SEQ_PTR(_opt_15495)->length;
        }
        else {
            _8410 = 1;
        }
        if (_8410 >= 6)
        goto L3; // [40] 67

        /** 			opt &= repeat(-1, MAPNAME - length(opt))*/
        if (IS_SEQUENCE(_opt_15495)){
                _8412 = SEQ_PTR(_opt_15495)->length;
        }
        else {
            _8412 = 1;
        }
        _8413 = 6 - _8412;
        _8412 = NOVALUE;
        _8414 = Repeat(-1, _8413);
        _8413 = NOVALUE;
        Concat((object_ptr)&_opt_15495, _opt_15495, _8414);
        DeRefDS(_8414);
        _8414 = NOVALUE;

        /** 			updated = 1*/
        _updated_15497 = 1;
L3: 

        /** 		if sequence(opt[SHORTNAME]) and length(opt[SHORTNAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8416 = (int)*(((s1_ptr)_2)->base + 1);
        _8417 = IS_SEQUENCE(_8416);
        _8416 = NOVALUE;
        if (_8417 == 0) {
            goto L4; // [76] 107
        }
        _2 = (int)SEQ_PTR(_opt_15495);
        _8419 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_SEQUENCE(_8419)){
                _8420 = SEQ_PTR(_8419)->length;
        }
        else {
            _8420 = 1;
        }
        _8419 = NOVALUE;
        _8421 = (_8420 == 0);
        _8420 = NOVALUE;
        if (_8421 == 0)
        {
            DeRef(_8421);
            _8421 = NOVALUE;
            goto L4; // [92] 107
        }
        else{
            DeRef(_8421);
            _8421 = NOVALUE;
        }

        /** 			opt[SHORTNAME] = 0*/
        _2 = (int)SEQ_PTR(_opt_15495);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15495 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15497 = 1;
L4: 

        /** 		if sequence(opt[LONGNAME]) and length(opt[LONGNAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8422 = (int)*(((s1_ptr)_2)->base + 2);
        _8423 = IS_SEQUENCE(_8422);
        _8422 = NOVALUE;
        if (_8423 == 0) {
            goto L5; // [116] 147
        }
        _2 = (int)SEQ_PTR(_opt_15495);
        _8425 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_8425)){
                _8426 = SEQ_PTR(_8425)->length;
        }
        else {
            _8426 = 1;
        }
        _8425 = NOVALUE;
        _8427 = (_8426 == 0);
        _8426 = NOVALUE;
        if (_8427 == 0)
        {
            DeRef(_8427);
            _8427 = NOVALUE;
            goto L5; // [132] 147
        }
        else{
            DeRef(_8427);
            _8427 = NOVALUE;
        }

        /** 			opt[LONGNAME] = 0*/
        _2 = (int)SEQ_PTR(_opt_15495);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15495 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15497 = 1;
L5: 

        /** 		if atom(opt[LONGNAME]) and atom(opt[SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8428 = (int)*(((s1_ptr)_2)->base + 2);
        _8429 = IS_ATOM(_8428);
        _8428 = NOVALUE;
        if (_8429 == 0) {
            goto L6; // [156] 233
        }
        _2 = (int)SEQ_PTR(_opt_15495);
        _8431 = (int)*(((s1_ptr)_2)->base + 1);
        _8432 = IS_ATOM(_8431);
        _8431 = NOVALUE;
        if (_8432 == 0)
        {
            _8432 = NOVALUE;
            goto L6; // [168] 233
        }
        else{
            _8432 = NOVALUE;
        }

        /** 			if lExtras != 0 then*/
        if (_lExtras_15491 == 0)
        goto L7; // [173] 200

        /** 				error:crash("cmd_opts: There must be less than two 'extras' option records.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_178_15529);
        _msg_inlined_crash_at_178_15529 = EPrintf(-9999999, _8434, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_178_15529);

        /** end procedure*/
        goto L8; // [192] 195
L8: 
        DeRefi(_msg_inlined_crash_at_178_15529);
        _msg_inlined_crash_at_178_15529 = NOVALUE;
        goto L9; // [197] 232
L7: 

        /** 				lExtras = i*/
        _lExtras_15491 = _i_15493;

        /** 				if atom(opt[MAPNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8435 = (int)*(((s1_ptr)_2)->base + 6);
        _8436 = IS_ATOM(_8435);
        _8435 = NOVALUE;
        if (_8436 == 0)
        {
            _8436 = NOVALUE;
            goto LA; // [214] 231
        }
        else{
            _8436 = NOVALUE;
        }

        /** 					opt[MAPNAME] = EXTRAS*/
        RefDS(_40EXTRAS_15467);
        _2 = (int)SEQ_PTR(_opt_15495);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15495 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _40EXTRAS_15467;
        DeRef(_1);

        /** 					updated = 1*/
        _updated_15497 = 1;
LA: 
L9: 
L6: 

        /** 		if atom(opt[DESCRIPTION]) then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8437 = (int)*(((s1_ptr)_2)->base + 3);
        _8438 = IS_ATOM(_8437);
        _8437 = NOVALUE;
        if (_8438 == 0)
        {
            _8438 = NOVALUE;
            goto LB; // [242] 257
        }
        else{
            _8438 = NOVALUE;
        }

        /** 			opt[DESCRIPTION] = ""*/
        RefDS(_5);
        _2 = (int)SEQ_PTR(_opt_15495);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15495 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 3);
        _1 = *(int *)_2;
        *(int *)_2 = _5;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15497 = 1;
LB: 

        /** 		if atom(opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8439 = (int)*(((s1_ptr)_2)->base + 4);
        _8440 = IS_ATOM(_8439);
        _8439 = NOVALUE;
        if (_8440 == 0)
        {
            _8440 = NOVALUE;
            goto LC; // [266] 310
        }
        else{
            _8440 = NOVALUE;
        }

        /** 			if equal(opt[OPTIONS], HAS_PARAMETER) then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8441 = (int)*(((s1_ptr)_2)->base + 4);
        if (_8441 == 112)
        _8442 = 1;
        else if (IS_ATOM_INT(_8441) && IS_ATOM_INT(112))
        _8442 = 0;
        else
        _8442 = (compare(_8441, 112) == 0);
        _8441 = NOVALUE;
        if (_8442 == 0)
        {
            _8442 = NOVALUE;
            goto LD; // [279] 295
        }
        else{
            _8442 = NOVALUE;
        }

        /** 				opt[OPTIONS] = {HAS_PARAMETER,"x"}*/
        RefDS(_8443);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 112;
        ((int *)_2)[2] = _8443;
        _8444 = MAKE_SEQ(_1);
        _2 = (int)SEQ_PTR(_opt_15495);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15495 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _8444;
        if( _1 != _8444 ){
            DeRef(_1);
        }
        _8444 = NOVALUE;
        goto LE; // [292] 302
LD: 

        /** 				opt[OPTIONS] = {}*/
        RefDS(_5);
        _2 = (int)SEQ_PTR(_opt_15495);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15495 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _5;
        DeRef(_1);
LE: 

        /** 			updated = 1*/
        _updated_15497 = 1;
        goto LF; // [307] 582
LC: 

        /** 			for j = 1 to length(opt[OPTIONS]) do*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8445 = (int)*(((s1_ptr)_2)->base + 4);
        if (IS_SEQUENCE(_8445)){
                _8446 = SEQ_PTR(_8445)->length;
        }
        else {
            _8446 = 1;
        }
        _8445 = NOVALUE;
        {
            int _j_15548;
            _j_15548 = 1;
L10: 
            if (_j_15548 > _8446){
                goto L11; // [319] 381
            }

            /** 				if find(opt[OPTIONS][j], opt[OPTIONS], j + 1) != 0 then*/
            _2 = (int)SEQ_PTR(_opt_15495);
            _8447 = (int)*(((s1_ptr)_2)->base + 4);
            _2 = (int)SEQ_PTR(_8447);
            _8448 = (int)*(((s1_ptr)_2)->base + _j_15548);
            _8447 = NOVALUE;
            _2 = (int)SEQ_PTR(_opt_15495);
            _8449 = (int)*(((s1_ptr)_2)->base + 4);
            _8450 = _j_15548 + 1;
            _8451 = find_from(_8448, _8449, _8450);
            _8448 = NOVALUE;
            _8449 = NOVALUE;
            _8450 = NOVALUE;
            if (_8451 == 0)
            goto L12; // [349] 374

            /** 					error:crash("cmd_opts: Duplicate processing options are not allowed in an option record.\n")*/

            /** 	msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_354_15560);
            _msg_inlined_crash_at_354_15560 = EPrintf(-9999999, _8453, _5);

            /** 	machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_354_15560);

            /** end procedure*/
            goto L13; // [368] 371
L13: 
            DeRefi(_msg_inlined_crash_at_354_15560);
            _msg_inlined_crash_at_354_15560 = NOVALUE;
L12: 

            /** 			end for*/
            _j_15548 = _j_15548 + 1;
            goto L10; // [376] 326
L11: 
            ;
        }

        /** 			if find(HAS_PARAMETER, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8454 = (int)*(((s1_ptr)_2)->base + 4);
        _8455 = find_from(112, _8454, 1);
        _8454 = NOVALUE;
        if (_8455 == 0)
        {
            _8455 = NOVALUE;
            goto L14; // [392] 431
        }
        else{
            _8455 = NOVALUE;
        }

        /** 				if find(NO_PARAMETER, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8456 = (int)*(((s1_ptr)_2)->base + 4);
        _8457 = find_from(110, _8456, 1);
        _8456 = NOVALUE;
        if (_8457 == 0)
        {
            _8457 = NOVALUE;
            goto L15; // [406] 430
        }
        else{
            _8457 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both HAS_PARAMETER and NO_PARAMETER in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_410_15569);
        _msg_inlined_crash_at_410_15569 = EPrintf(-9999999, _8458, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_410_15569);

        /** end procedure*/
        goto L16; // [424] 427
L16: 
        DeRefi(_msg_inlined_crash_at_410_15569);
        _msg_inlined_crash_at_410_15569 = NOVALUE;
L15: 
L14: 

        /** 			if find(HAS_CASE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8459 = (int)*(((s1_ptr)_2)->base + 4);
        _8460 = find_from(99, _8459, 1);
        _8459 = NOVALUE;
        if (_8460 == 0)
        {
            _8460 = NOVALUE;
            goto L17; // [442] 481
        }
        else{
            _8460 = NOVALUE;
        }

        /** 				if find(NO_CASE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8461 = (int)*(((s1_ptr)_2)->base + 4);
        _8462 = find_from(105, _8461, 1);
        _8461 = NOVALUE;
        if (_8462 == 0)
        {
            _8462 = NOVALUE;
            goto L18; // [456] 480
        }
        else{
            _8462 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both HAS_CASE and NO_CASE in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_460_15578);
        _msg_inlined_crash_at_460_15578 = EPrintf(-9999999, _8463, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_460_15578);

        /** end procedure*/
        goto L19; // [474] 477
L19: 
        DeRefi(_msg_inlined_crash_at_460_15578);
        _msg_inlined_crash_at_460_15578 = NOVALUE;
L18: 
L17: 

        /** 			if find(MANDATORY, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8464 = (int)*(((s1_ptr)_2)->base + 4);
        _8465 = find_from(109, _8464, 1);
        _8464 = NOVALUE;
        if (_8465 == 0)
        {
            _8465 = NOVALUE;
            goto L1A; // [492] 531
        }
        else{
            _8465 = NOVALUE;
        }

        /** 				if find(OPTIONAL, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8466 = (int)*(((s1_ptr)_2)->base + 4);
        _8467 = find_from(111, _8466, 1);
        _8466 = NOVALUE;
        if (_8467 == 0)
        {
            _8467 = NOVALUE;
            goto L1B; // [506] 530
        }
        else{
            _8467 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both MANDATORY and OPTIONAL in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_510_15587);
        _msg_inlined_crash_at_510_15587 = EPrintf(-9999999, _8468, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_510_15587);

        /** end procedure*/
        goto L1C; // [524] 527
L1C: 
        DeRefi(_msg_inlined_crash_at_510_15587);
        _msg_inlined_crash_at_510_15587 = NOVALUE;
L1B: 
L1A: 

        /** 			if find(ONCE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8469 = (int)*(((s1_ptr)_2)->base + 4);
        _8470 = find_from(49, _8469, 1);
        _8469 = NOVALUE;
        if (_8470 == 0)
        {
            _8470 = NOVALUE;
            goto L1D; // [542] 581
        }
        else{
            _8470 = NOVALUE;
        }

        /** 				if find(MULTIPLE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8471 = (int)*(((s1_ptr)_2)->base + 4);
        _8472 = find_from(42, _8471, 1);
        _8471 = NOVALUE;
        if (_8472 == 0)
        {
            _8472 = NOVALUE;
            goto L1E; // [556] 580
        }
        else{
            _8472 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both ONCE and MULTIPLE in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_560_15596);
        _msg_inlined_crash_at_560_15596 = EPrintf(-9999999, _8473, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_560_15596);

        /** end procedure*/
        goto L1F; // [574] 577
L1F: 
        DeRefi(_msg_inlined_crash_at_560_15596);
        _msg_inlined_crash_at_560_15596 = NOVALUE;
L1E: 
L1D: 
LF: 

        /** 		if sequence(opt[CALLBACK]) then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8474 = (int)*(((s1_ptr)_2)->base + 5);
        _8475 = IS_SEQUENCE(_8474);
        _8474 = NOVALUE;
        if (_8475 == 0)
        {
            _8475 = NOVALUE;
            goto L20; // [591] 608
        }
        else{
            _8475 = NOVALUE;
        }

        /** 			opt[CALLBACK] = -1*/
        _2 = (int)SEQ_PTR(_opt_15495);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15495 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15497 = 1;
        goto L21; // [605] 657
L20: 

        /** 		elsif not integer(opt[CALLBACK]) then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8476 = (int)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_8476))
        _8477 = 1;
        else if (IS_ATOM_DBL(_8476))
        _8477 = IS_ATOM_INT(DoubleToInt(_8476));
        else
        _8477 = 0;
        _8476 = NOVALUE;
        if (_8477 != 0)
        goto L22; // [617] 634
        _8477 = NOVALUE;

        /** 			opt[CALLBACK] = -1*/
        _2 = (int)SEQ_PTR(_opt_15495);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15495 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15497 = 1;
        goto L21; // [631] 657
L22: 

        /** 		elsif opt[CALLBACK] < 0 then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8479 = (int)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(GREATEREQ, _8479, 0)){
            _8479 = NOVALUE;
            goto L23; // [640] 656
        }
        _8479 = NOVALUE;

        /** 			opt[CALLBACK] = -1*/
        _2 = (int)SEQ_PTR(_opt_15495);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15495 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15497 = 1;
L23: 
L21: 

        /** 		if sequence(opt[MAPNAME]) and length(opt[MAPNAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8481 = (int)*(((s1_ptr)_2)->base + 6);
        _8482 = IS_SEQUENCE(_8481);
        _8481 = NOVALUE;
        if (_8482 == 0) {
            goto L24; // [666] 697
        }
        _2 = (int)SEQ_PTR(_opt_15495);
        _8484 = (int)*(((s1_ptr)_2)->base + 6);
        if (IS_SEQUENCE(_8484)){
                _8485 = SEQ_PTR(_8484)->length;
        }
        else {
            _8485 = 1;
        }
        _8484 = NOVALUE;
        _8486 = (_8485 == 0);
        _8485 = NOVALUE;
        if (_8486 == 0)
        {
            DeRef(_8486);
            _8486 = NOVALUE;
            goto L24; // [682] 697
        }
        else{
            DeRef(_8486);
            _8486 = NOVALUE;
        }

        /** 			opt[MAPNAME] = 0*/
        _2 = (int)SEQ_PTR(_opt_15495);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15495 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15497 = 1;
L24: 

        /** 		if atom(opt[MAPNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8487 = (int)*(((s1_ptr)_2)->base + 6);
        _8488 = IS_ATOM(_8487);
        _8487 = NOVALUE;
        if (_8488 == 0)
        {
            _8488 = NOVALUE;
            goto L25; // [706] 774
        }
        else{
            _8488 = NOVALUE;
        }

        /** 			if sequence(opt[LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8489 = (int)*(((s1_ptr)_2)->base + 2);
        _8490 = IS_SEQUENCE(_8489);
        _8489 = NOVALUE;
        if (_8490 == 0)
        {
            _8490 = NOVALUE;
            goto L26; // [718] 734
        }
        else{
            _8490 = NOVALUE;
        }

        /** 				opt[MAPNAME] = opt[LONGNAME]*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8491 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_8491);
        _2 = (int)SEQ_PTR(_opt_15495);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15495 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _8491;
        if( _1 != _8491 ){
            DeRef(_1);
        }
        _8491 = NOVALUE;
        goto L27; // [731] 768
L26: 

        /** 			elsif sequence(opt[SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8492 = (int)*(((s1_ptr)_2)->base + 1);
        _8493 = IS_SEQUENCE(_8492);
        _8492 = NOVALUE;
        if (_8493 == 0)
        {
            _8493 = NOVALUE;
            goto L28; // [743] 759
        }
        else{
            _8493 = NOVALUE;
        }

        /** 				opt[MAPNAME] = opt[SHORTNAME]*/
        _2 = (int)SEQ_PTR(_opt_15495);
        _8494 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_8494);
        _2 = (int)SEQ_PTR(_opt_15495);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15495 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _8494;
        if( _1 != _8494 ){
            DeRef(_1);
        }
        _8494 = NOVALUE;
        goto L27; // [756] 768
L28: 

        /** 				opt[MAPNAME] = EXTRAS*/
        RefDS(_40EXTRAS_15467);
        _2 = (int)SEQ_PTR(_opt_15495);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15495 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _40EXTRAS_15467;
        DeRef(_1);
L27: 

        /** 			updated = 1*/
        _updated_15497 = 1;
L25: 

        /** 		if updated then*/
        if (_updated_15497 == 0)
        {
            goto L29; // [776] 786
        }
        else{
        }

        /** 			opts[i] = opt*/
        RefDS(_opt_15495);
        _2 = (int)SEQ_PTR(_opts_15489);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_15489 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_15493);
        _1 = *(int *)_2;
        *(int *)_2 = _opt_15495;
        DeRef(_1);
L29: 
        DeRef(_opt_15495);
        _opt_15495 = NOVALUE;

        /** 	end for*/
        _i_15493 = _i_15493 + 1;
        goto L1; // [790] 22
L2: 
        ;
    }

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15489)){
            _8495 = SEQ_PTR(_opts_15489)->length;
    }
    else {
        _8495 = 1;
    }
    {
        int _i_15628;
        _i_15628 = 1;
L2A: 
        if (_i_15628 > _8495){
            goto L2B; // [800] 1004
        }

        /** 		sequence opt*/

        /** 		opt = opts[i]*/
        DeRef(_opt_15630);
        _2 = (int)SEQ_PTR(_opts_15489);
        _opt_15630 = (int)*(((s1_ptr)_2)->base + _i_15628);
        Ref(_opt_15630);

        /** 		if sequence(opt[SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15630);
        _8497 = (int)*(((s1_ptr)_2)->base + 1);
        _8498 = IS_SEQUENCE(_8497);
        _8497 = NOVALUE;
        if (_8498 == 0)
        {
            _8498 = NOVALUE;
            goto L2C; // [826] 906
        }
        else{
            _8498 = NOVALUE;
        }

        /** 			for j = i + 1 to length(opts) do*/
        _8499 = _i_15628 + 1;
        if (IS_SEQUENCE(_opts_15489)){
                _8500 = SEQ_PTR(_opts_15489)->length;
        }
        else {
            _8500 = 1;
        }
        {
            int _j_15636;
            _j_15636 = _8499;
L2D: 
            if (_j_15636 > _8500){
                goto L2E; // [838] 905
            }

            /** 				if equal(opt[SHORTNAME], opts[j][SHORTNAME]) then*/
            _2 = (int)SEQ_PTR(_opt_15630);
            _8501 = (int)*(((s1_ptr)_2)->base + 1);
            _2 = (int)SEQ_PTR(_opts_15489);
            _8502 = (int)*(((s1_ptr)_2)->base + _j_15636);
            _2 = (int)SEQ_PTR(_8502);
            _8503 = (int)*(((s1_ptr)_2)->base + 1);
            _8502 = NOVALUE;
            if (_8501 == _8503)
            _8504 = 1;
            else if (IS_ATOM_INT(_8501) && IS_ATOM_INT(_8503))
            _8504 = 0;
            else
            _8504 = (compare(_8501, _8503) == 0);
            _8501 = NOVALUE;
            _8503 = NOVALUE;
            if (_8504 == 0)
            {
                _8504 = NOVALUE;
                goto L2F; // [863] 898
            }
            else{
                _8504 = NOVALUE;
            }

            /** 					error:crash("cmd_opts: Duplicate Short Names (%s) are not allowed in an option record.\n",*/
            _2 = (int)SEQ_PTR(_opt_15630);
            _8506 = (int)*(((s1_ptr)_2)->base + 1);
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_8506);
            *((int *)(_2+4)) = _8506;
            _8507 = MAKE_SEQ(_1);
            _8506 = NOVALUE;
            DeRef(_data_inlined_crash_at_875_15648);
            _data_inlined_crash_at_875_15648 = _8507;
            _8507 = NOVALUE;

            /** 	msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_878_15649);
            _msg_inlined_crash_at_878_15649 = EPrintf(-9999999, _8505, _data_inlined_crash_at_875_15648);

            /** 	machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_878_15649);

            /** end procedure*/
            goto L30; // [892] 895
L30: 
            DeRef(_data_inlined_crash_at_875_15648);
            _data_inlined_crash_at_875_15648 = NOVALUE;
            DeRefi(_msg_inlined_crash_at_878_15649);
            _msg_inlined_crash_at_878_15649 = NOVALUE;
L2F: 

            /** 			end for*/
            _j_15636 = _j_15636 + 1;
            goto L2D; // [900] 845
L2E: 
            ;
        }
L2C: 

        /** 		if sequence(opt[LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15630);
        _8508 = (int)*(((s1_ptr)_2)->base + 2);
        _8509 = IS_SEQUENCE(_8508);
        _8508 = NOVALUE;
        if (_8509 == 0)
        {
            _8509 = NOVALUE;
            goto L31; // [915] 995
        }
        else{
            _8509 = NOVALUE;
        }

        /** 			for j = i + 1 to length(opts) do*/
        _8510 = _i_15628 + 1;
        if (IS_SEQUENCE(_opts_15489)){
                _8511 = SEQ_PTR(_opts_15489)->length;
        }
        else {
            _8511 = 1;
        }
        {
            int _j_15654;
            _j_15654 = _8510;
L32: 
            if (_j_15654 > _8511){
                goto L33; // [927] 994
            }

            /** 				if equal(opt[LONGNAME], opts[j][LONGNAME]) then*/
            _2 = (int)SEQ_PTR(_opt_15630);
            _8512 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_opts_15489);
            _8513 = (int)*(((s1_ptr)_2)->base + _j_15654);
            _2 = (int)SEQ_PTR(_8513);
            _8514 = (int)*(((s1_ptr)_2)->base + 2);
            _8513 = NOVALUE;
            if (_8512 == _8514)
            _8515 = 1;
            else if (IS_ATOM_INT(_8512) && IS_ATOM_INT(_8514))
            _8515 = 0;
            else
            _8515 = (compare(_8512, _8514) == 0);
            _8512 = NOVALUE;
            _8514 = NOVALUE;
            if (_8515 == 0)
            {
                _8515 = NOVALUE;
                goto L34; // [952] 987
            }
            else{
                _8515 = NOVALUE;
            }

            /** 					error:crash("cmd_opts: Duplicate Long Names (%s) are not allowed in an option record.\n",*/
            _2 = (int)SEQ_PTR(_opt_15630);
            _8517 = (int)*(((s1_ptr)_2)->base + 2);
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_8517);
            *((int *)(_2+4)) = _8517;
            _8518 = MAKE_SEQ(_1);
            _8517 = NOVALUE;
            DeRef(_data_inlined_crash_at_964_15666);
            _data_inlined_crash_at_964_15666 = _8518;
            _8518 = NOVALUE;

            /** 	msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_967_15667);
            _msg_inlined_crash_at_967_15667 = EPrintf(-9999999, _8516, _data_inlined_crash_at_964_15666);

            /** 	machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_967_15667);

            /** end procedure*/
            goto L35; // [981] 984
L35: 
            DeRef(_data_inlined_crash_at_964_15666);
            _data_inlined_crash_at_964_15666 = NOVALUE;
            DeRefi(_msg_inlined_crash_at_967_15667);
            _msg_inlined_crash_at_967_15667 = NOVALUE;
L34: 

            /** 			end for*/
            _j_15654 = _j_15654 + 1;
            goto L32; // [989] 934
L33: 
            ;
        }
L31: 
        DeRef(_opt_15630);
        _opt_15630 = NOVALUE;

        /** 	end for*/
        _i_15628 = _i_15628 + 1;
        goto L2A; // [999] 807
L2B: 
        ;
    }

    /** 	integer has_h = 0, has_help = 0, has_question = 0*/
    _has_h_15668 = 0;
    _has_help_15669 = 0;
    _has_question_15670 = 0;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15489)){
            _8519 = SEQ_PTR(_opts_15489)->length;
    }
    else {
        _8519 = 1;
    }
    {
        int _i_15672;
        _i_15672 = 1;
L36: 
        if (_i_15672 > _8519){
            goto L37; // [1020] 1106
        }

        /** 		if equal(opts[i][SHORTNAME], "h") then*/
        _2 = (int)SEQ_PTR(_opts_15489);
        _8520 = (int)*(((s1_ptr)_2)->base + _i_15672);
        _2 = (int)SEQ_PTR(_8520);
        _8521 = (int)*(((s1_ptr)_2)->base + 1);
        _8520 = NOVALUE;
        if (_8521 == _8522)
        _8523 = 1;
        else if (IS_ATOM_INT(_8521) && IS_ATOM_INT(_8522))
        _8523 = 0;
        else
        _8523 = (compare(_8521, _8522) == 0);
        _8521 = NOVALUE;
        if (_8523 == 0)
        {
            _8523 = NOVALUE;
            goto L38; // [1041] 1052
        }
        else{
            _8523 = NOVALUE;
        }

        /** 			has_h = 1*/
        _has_h_15668 = 1;
        goto L39; // [1049] 1076
L38: 

        /** 		elsif equal(opts[i][SHORTNAME], "?") then*/
        _2 = (int)SEQ_PTR(_opts_15489);
        _8524 = (int)*(((s1_ptr)_2)->base + _i_15672);
        _2 = (int)SEQ_PTR(_8524);
        _8525 = (int)*(((s1_ptr)_2)->base + 1);
        _8524 = NOVALUE;
        if (_8525 == _8526)
        _8527 = 1;
        else if (IS_ATOM_INT(_8525) && IS_ATOM_INT(_8526))
        _8527 = 0;
        else
        _8527 = (compare(_8525, _8526) == 0);
        _8525 = NOVALUE;
        if (_8527 == 0)
        {
            _8527 = NOVALUE;
            goto L3A; // [1066] 1075
        }
        else{
            _8527 = NOVALUE;
        }

        /** 			has_question = 1*/
        _has_question_15670 = 1;
L3A: 
L39: 

        /** 		if equal(opts[i][LONGNAME], "help") then*/
        _2 = (int)SEQ_PTR(_opts_15489);
        _8528 = (int)*(((s1_ptr)_2)->base + _i_15672);
        _2 = (int)SEQ_PTR(_8528);
        _8529 = (int)*(((s1_ptr)_2)->base + 2);
        _8528 = NOVALUE;
        if (_8529 == _8530)
        _8531 = 1;
        else if (IS_ATOM_INT(_8529) && IS_ATOM_INT(_8530))
        _8531 = 0;
        else
        _8531 = (compare(_8529, _8530) == 0);
        _8529 = NOVALUE;
        if (_8531 == 0)
        {
            _8531 = NOVALUE;
            goto L3B; // [1090] 1099
        }
        else{
            _8531 = NOVALUE;
        }

        /** 			has_help = 1*/
        _has_help_15669 = 1;
L3B: 

        /** 	end for*/
        _i_15672 = _i_15672 + 1;
        goto L36; // [1101] 1027
L37: 
        ;
    }

    /** 	if auto_help_switches then*/
    if (_auto_help_switches_15490 == 0)
    {
        goto L3C; // [1108] 1251
    }
    else{
    }

    /** 		integer appended_opts = 0*/
    _appended_opts_15690 = 0;

    /** 		if not has_h and not has_help then*/
    _8532 = (_has_h_15668 == 0);
    if (_8532 == 0) {
        goto L3D; // [1121] 1154
    }
    _8534 = (_has_help_15669 == 0);
    if (_8534 == 0)
    {
        DeRef(_8534);
        _8534 = NOVALUE;
        goto L3D; // [1129] 1154
    }
    else{
        DeRef(_8534);
        _8534 = NOVALUE;
    }

    /** 			opts = append(opts, {"h", "help", "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8522);
    *((int *)(_2+4)) = _8522;
    RefDS(_8530);
    *((int *)(_2+8)) = _8530;
    RefDS(_8535);
    *((int *)(_2+12)) = _8535;
    RefDS(_8522);
    *((int *)(_2+16)) = _8522;
    *((int *)(_2+20)) = -1;
    _8536 = MAKE_SEQ(_1);
    RefDS(_8536);
    Append(&_opts_15489, _opts_15489, _8536);
    DeRefDS(_8536);
    _8536 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_15690 = 1;
    goto L3E; // [1151] 1207
L3D: 

    /** 		elsif not has_h then*/
    if (_has_h_15668 != 0)
    goto L3F; // [1156] 1181

    /** 			opts = append(opts, {"h", 0, "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8522);
    *((int *)(_2+4)) = _8522;
    *((int *)(_2+8)) = 0;
    RefDS(_8535);
    *((int *)(_2+12)) = _8535;
    RefDS(_8522);
    *((int *)(_2+16)) = _8522;
    *((int *)(_2+20)) = -1;
    _8539 = MAKE_SEQ(_1);
    RefDS(_8539);
    Append(&_opts_15489, _opts_15489, _8539);
    DeRefDS(_8539);
    _8539 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_15690 = 1;
    goto L3E; // [1178] 1207
L3F: 

    /** 		elsif not has_help then*/
    if (_has_help_15669 != 0)
    goto L40; // [1183] 1206

    /** 			opts = append(opts, {0, "help", "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_8530);
    *((int *)(_2+8)) = _8530;
    RefDS(_8535);
    *((int *)(_2+12)) = _8535;
    RefDS(_8522);
    *((int *)(_2+16)) = _8522;
    *((int *)(_2+20)) = -1;
    _8542 = MAKE_SEQ(_1);
    RefDS(_8542);
    Append(&_opts_15489, _opts_15489, _8542);
    DeRefDS(_8542);
    _8542 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_15690 = 1;
L40: 
L3E: 

    /** 		if not has_question then			*/
    if (_has_question_15670 != 0)
    goto L41; // [1209] 1232

    /** 			opts = append(opts, {"?", 0, "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8526);
    *((int *)(_2+4)) = _8526;
    *((int *)(_2+8)) = 0;
    RefDS(_8535);
    *((int *)(_2+12)) = _8535;
    RefDS(_8522);
    *((int *)(_2+16)) = _8522;
    *((int *)(_2+20)) = -1;
    _8545 = MAKE_SEQ(_1);
    RefDS(_8545);
    Append(&_opts_15489, _opts_15489, _8545);
    DeRefDS(_8545);
    _8545 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_15690 = 1;
L41: 

    /** 		if appended_opts then*/
    if (_appended_opts_15690 == 0)
    {
        goto L42; // [1234] 1250
    }
    else{
    }

    /** 			opts = standardize_opts(opts, 0)*/
    RefDS(_opts_15489);
    DeRef(_8547);
    _8547 = _opts_15489;
    _0 = _opts_15489;
    _opts_15489 = _40standardize_opts(_8547, 0);
    DeRefDS(_0);
    _8547 = NOVALUE;
L42: 
L3C: 

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15489)){
            _8549 = SEQ_PTR(_opts_15489)->length;
    }
    else {
        _8549 = 1;
    }
    {
        int _i_15714;
        _i_15714 = 1;
L43: 
        if (_i_15714 > _8549){
            goto L44; // [1258] 1434
        }

        /** 		if not find(HAS_PARAMETER, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15489);
        _8550 = (int)*(((s1_ptr)_2)->base + _i_15714);
        _2 = (int)SEQ_PTR(_8550);
        _8551 = (int)*(((s1_ptr)_2)->base + 4);
        _8550 = NOVALUE;
        _8552 = find_from(112, _8551, 1);
        _8551 = NOVALUE;
        if (_8552 != 0)
        goto L45; // [1280] 1303
        _8552 = NOVALUE;

        /** 			opts[i][OPTIONS] &= NO_PARAMETER*/
        _2 = (int)SEQ_PTR(_opts_15489);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_15489 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_15714 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _8556 = (int)*(((s1_ptr)_2)->base + 4);
        _8554 = NOVALUE;
        if (IS_SEQUENCE(_8556) && IS_ATOM(110)) {
            Append(&_8557, _8556, 110);
        }
        else if (IS_ATOM(_8556) && IS_SEQUENCE(110)) {
        }
        else {
            Concat((object_ptr)&_8557, _8556, 110);
            _8556 = NOVALUE;
        }
        _8556 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _8557;
        if( _1 != _8557 ){
            DeRef(_1);
        }
        _8557 = NOVALUE;
        _8554 = NOVALUE;
L45: 

        /** 		if not find(MULTIPLE, opts[i][OPTIONS]) and not find(ONCE, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15489);
        _8558 = (int)*(((s1_ptr)_2)->base + _i_15714);
        _2 = (int)SEQ_PTR(_8558);
        _8559 = (int)*(((s1_ptr)_2)->base + 4);
        _8558 = NOVALUE;
        _8560 = find_from(42, _8559, 1);
        _8559 = NOVALUE;
        _8561 = (_8560 == 0);
        _8560 = NOVALUE;
        if (_8561 == 0) {
            goto L46; // [1321] 1365
        }
        _2 = (int)SEQ_PTR(_opts_15489);
        _8563 = (int)*(((s1_ptr)_2)->base + _i_15714);
        _2 = (int)SEQ_PTR(_8563);
        _8564 = (int)*(((s1_ptr)_2)->base + 4);
        _8563 = NOVALUE;
        _8565 = find_from(49, _8564, 1);
        _8564 = NOVALUE;
        _8566 = (_8565 == 0);
        _8565 = NOVALUE;
        if (_8566 == 0)
        {
            DeRef(_8566);
            _8566 = NOVALUE;
            goto L46; // [1342] 1365
        }
        else{
            DeRef(_8566);
            _8566 = NOVALUE;
        }

        /** 			opts[i][OPTIONS] &= ONCE*/
        _2 = (int)SEQ_PTR(_opts_15489);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_15489 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_15714 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _8569 = (int)*(((s1_ptr)_2)->base + 4);
        _8567 = NOVALUE;
        if (IS_SEQUENCE(_8569) && IS_ATOM(49)) {
            Append(&_8570, _8569, 49);
        }
        else if (IS_ATOM(_8569) && IS_SEQUENCE(49)) {
        }
        else {
            Concat((object_ptr)&_8570, _8569, 49);
            _8569 = NOVALUE;
        }
        _8569 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _8570;
        if( _1 != _8570 ){
            DeRef(_1);
        }
        _8570 = NOVALUE;
        _8567 = NOVALUE;
L46: 

        /** 		if not find(HAS_CASE, opts[i][OPTIONS]) and not find(NO_CASE, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15489);
        _8571 = (int)*(((s1_ptr)_2)->base + _i_15714);
        _2 = (int)SEQ_PTR(_8571);
        _8572 = (int)*(((s1_ptr)_2)->base + 4);
        _8571 = NOVALUE;
        _8573 = find_from(99, _8572, 1);
        _8572 = NOVALUE;
        _8574 = (_8573 == 0);
        _8573 = NOVALUE;
        if (_8574 == 0) {
            goto L47; // [1383] 1427
        }
        _2 = (int)SEQ_PTR(_opts_15489);
        _8576 = (int)*(((s1_ptr)_2)->base + _i_15714);
        _2 = (int)SEQ_PTR(_8576);
        _8577 = (int)*(((s1_ptr)_2)->base + 4);
        _8576 = NOVALUE;
        _8578 = find_from(105, _8577, 1);
        _8577 = NOVALUE;
        _8579 = (_8578 == 0);
        _8578 = NOVALUE;
        if (_8579 == 0)
        {
            DeRef(_8579);
            _8579 = NOVALUE;
            goto L47; // [1404] 1427
        }
        else{
            DeRef(_8579);
            _8579 = NOVALUE;
        }

        /** 			opts[i][OPTIONS] &= NO_CASE*/
        _2 = (int)SEQ_PTR(_opts_15489);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_15489 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_15714 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _8582 = (int)*(((s1_ptr)_2)->base + 4);
        _8580 = NOVALUE;
        if (IS_SEQUENCE(_8582) && IS_ATOM(105)) {
            Append(&_8583, _8582, 105);
        }
        else if (IS_ATOM(_8582) && IS_SEQUENCE(105)) {
        }
        else {
            Concat((object_ptr)&_8583, _8582, 105);
            _8582 = NOVALUE;
        }
        _8582 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _8583;
        if( _1 != _8583 ){
            DeRef(_1);
        }
        _8583 = NOVALUE;
        _8580 = NOVALUE;
L47: 

        /** 	end for*/
        _i_15714 = _i_15714 + 1;
        goto L43; // [1429] 1265
L44: 
        ;
    }

    /** 	return opts*/
    _8419 = NOVALUE;
    _8425 = NOVALUE;
    _8445 = NOVALUE;
    _8484 = NOVALUE;
    DeRef(_8499);
    _8499 = NOVALUE;
    DeRef(_8510);
    _8510 = NOVALUE;
    DeRef(_8532);
    _8532 = NOVALUE;
    DeRef(_8561);
    _8561 = NOVALUE;
    DeRef(_8574);
    _8574 = NOVALUE;
    return _opts_15489;
    ;
}


void _40local_help(int _opts_15755, int _add_help_rid_15756, int _cmds_15757, int _std_15759, int _parse_options_15760)
{
    int _pad_size_15761 = NOVALUE;
    int _this_size_15762 = NOVALUE;
    int _cmd_15763 = NOVALUE;
    int _param_name_15764 = NOVALUE;
    int _has_param_15765 = NOVALUE;
    int _is_mandatory_15766 = NOVALUE;
    int _extras_mandatory_15767 = NOVALUE;
    int _extras_opt_15768 = NOVALUE;
    int _auto_help_15769 = NOVALUE;
    int _po_15770 = NOVALUE;
    int _msg_inlined_crash_at_94_15789 = NOVALUE;
    int _8773 = NOVALUE;
    int _8772 = NOVALUE;
    int _8771 = NOVALUE;
    int _8770 = NOVALUE;
    int _8768 = NOVALUE;
    int _8767 = NOVALUE;
    int _8766 = NOVALUE;
    int _8765 = NOVALUE;
    int _8764 = NOVALUE;
    int _8762 = NOVALUE;
    int _8760 = NOVALUE;
    int _8758 = NOVALUE;
    int _8756 = NOVALUE;
    int _8755 = NOVALUE;
    int _8754 = NOVALUE;
    int _8752 = NOVALUE;
    int _8751 = NOVALUE;
    int _8750 = NOVALUE;
    int _8747 = NOVALUE;
    int _8746 = NOVALUE;
    int _8745 = NOVALUE;
    int _8743 = NOVALUE;
    int _8742 = NOVALUE;
    int _8741 = NOVALUE;
    int _8739 = NOVALUE;
    int _8738 = NOVALUE;
    int _8737 = NOVALUE;
    int _8736 = NOVALUE;
    int _8735 = NOVALUE;
    int _8734 = NOVALUE;
    int _8733 = NOVALUE;
    int _8732 = NOVALUE;
    int _8729 = NOVALUE;
    int _8725 = NOVALUE;
    int _8722 = NOVALUE;
    int _8721 = NOVALUE;
    int _8720 = NOVALUE;
    int _8714 = NOVALUE;
    int _8713 = NOVALUE;
    int _8712 = NOVALUE;
    int _8711 = NOVALUE;
    int _8707 = NOVALUE;
    int _8704 = NOVALUE;
    int _8703 = NOVALUE;
    int _8702 = NOVALUE;
    int _8699 = NOVALUE;
    int _8698 = NOVALUE;
    int _8697 = NOVALUE;
    int _8695 = NOVALUE;
    int _8694 = NOVALUE;
    int _8693 = NOVALUE;
    int _8691 = NOVALUE;
    int _8690 = NOVALUE;
    int _8689 = NOVALUE;
    int _8688 = NOVALUE;
    int _8687 = NOVALUE;
    int _8686 = NOVALUE;
    int _8683 = NOVALUE;
    int _8682 = NOVALUE;
    int _8681 = NOVALUE;
    int _8678 = NOVALUE;
    int _8677 = NOVALUE;
    int _8676 = NOVALUE;
    int _8675 = NOVALUE;
    int _8674 = NOVALUE;
    int _8673 = NOVALUE;
    int _8672 = NOVALUE;
    int _8671 = NOVALUE;
    int _8670 = NOVALUE;
    int _8669 = NOVALUE;
    int _8668 = NOVALUE;
    int _8667 = NOVALUE;
    int _8662 = NOVALUE;
    int _8661 = NOVALUE;
    int _8659 = NOVALUE;
    int _8658 = NOVALUE;
    int _8657 = NOVALUE;
    int _8656 = NOVALUE;
    int _8655 = NOVALUE;
    int _8654 = NOVALUE;
    int _8652 = NOVALUE;
    int _8651 = NOVALUE;
    int _8650 = NOVALUE;
    int _8646 = NOVALUE;
    int _8645 = NOVALUE;
    int _8643 = NOVALUE;
    int _8642 = NOVALUE;
    int _8641 = NOVALUE;
    int _8640 = NOVALUE;
    int _8639 = NOVALUE;
    int _8638 = NOVALUE;
    int _8637 = NOVALUE;
    int _8634 = NOVALUE;
    int _8633 = NOVALUE;
    int _8632 = NOVALUE;
    int _8630 = NOVALUE;
    int _8629 = NOVALUE;
    int _8628 = NOVALUE;
    int _8627 = NOVALUE;
    int _8626 = NOVALUE;
    int _8625 = NOVALUE;
    int _8624 = NOVALUE;
    int _8621 = NOVALUE;
    int _8620 = NOVALUE;
    int _8619 = NOVALUE;
    int _8617 = NOVALUE;
    int _8616 = NOVALUE;
    int _8615 = NOVALUE;
    int _8614 = NOVALUE;
    int _8613 = NOVALUE;
    int _8612 = NOVALUE;
    int _8611 = NOVALUE;
    int _8610 = NOVALUE;
    int _8609 = NOVALUE;
    int _8608 = NOVALUE;
    int _8607 = NOVALUE;
    int _8606 = NOVALUE;
    int _8605 = NOVALUE;
    int _8604 = NOVALUE;
    int _8603 = NOVALUE;
    int _8602 = NOVALUE;
    int _8601 = NOVALUE;
    int _8600 = NOVALUE;
    int _8592 = NOVALUE;
    int _8589 = NOVALUE;
    int _8587 = NOVALUE;
    int _8585 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer extras_mandatory = 0*/
    _extras_mandatory_15767 = 0;

    /** 	integer extras_opt = 0*/
    _extras_opt_15768 = 0;

    /** 	integer auto_help = 1*/
    _auto_help_15769 = 1;

    /** 	integer po = 1*/
    _po_15770 = 1;

    /** 	if atom(parse_options) then*/
    _8585 = IS_ATOM(_parse_options_15760);
    if (_8585 == 0)
    {
        _8585 = NOVALUE;
        goto L1; // [32] 42
    }
    else{
        _8585 = NOVALUE;
    }

    /** 		parse_options = {parse_options}*/
    _0 = _parse_options_15760;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_parse_options_15760);
    *((int *)(_2+4)) = _parse_options_15760;
    _parse_options_15760 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	while po <= length(parse_options) do*/
L2: 
    if (IS_SEQUENCE(_parse_options_15760)){
            _8587 = SEQ_PTR(_parse_options_15760)->length;
    }
    else {
        _8587 = 1;
    }
    if (_po_15770 > _8587)
    goto L3; // [50] 143

    /** 		switch parse_options[po] do*/
    _2 = (int)SEQ_PTR(_parse_options_15760);
    _8589 = (int)*(((s1_ptr)_2)->base + _po_15770);
    if (IS_SEQUENCE(_8589) ){
        goto L4; // [60] 129
    }
    if(!IS_ATOM_INT(_8589)){
        if( (DBL_PTR(_8589)->dbl != (double) ((int) DBL_PTR(_8589)->dbl) ) ){
            goto L4; // [60] 129
        }
        _0 = (int) DBL_PTR(_8589)->dbl;
    }
    else {
        _0 = _8589;
    };
    _8589 = NOVALUE;
    switch ( _0 ){ 

        /** 			case HELP_RID then*/
        case 1:

        /** 				if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_15760)){
                _8592 = SEQ_PTR(_parse_options_15760)->length;
        }
        else {
            _8592 = 1;
        }
        if (_po_15770 >= _8592)
        goto L5; // [74] 93

        /** 					po += 1*/
        _po_15770 = _po_15770 + 1;

        /** 					add_help_rid = parse_options[po]*/
        DeRef(_add_help_rid_15756);
        _2 = (int)SEQ_PTR(_parse_options_15760);
        _add_help_rid_15756 = (int)*(((s1_ptr)_2)->base + _po_15770);
        Ref(_add_help_rid_15756);
        goto L6; // [90] 132
L5: 

        /** 					error:crash("HELP_RID was given to cmd_parse with no routine_id")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_94_15789);
        _msg_inlined_crash_at_94_15789 = EPrintf(-9999999, _8596, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_94_15789);

        /** end procedure*/
        goto L7; // [108] 111
L7: 
        DeRefi(_msg_inlined_crash_at_94_15789);
        _msg_inlined_crash_at_94_15789 = NOVALUE;
        goto L6; // [114] 132

        /** 			case NO_HELP then*/
        case 9:

        /** 				auto_help = 0*/
        _auto_help_15769 = 0;
        goto L6; // [125] 132

        /** 			case else*/
        default:
L4: 
    ;}L6: 

    /** 		po += 1*/
    _po_15770 = _po_15770 + 1;

    /** 	end while*/
    goto L2; // [140] 47
L3: 

    /** 	if std = 0 then*/
    if (_std_15759 != 0)
    goto L8; // [145] 159

    /** 		opts = standardize_opts(opts, auto_help)*/
    RefDS(_opts_15755);
    _0 = _opts_15755;
    _opts_15755 = _40standardize_opts(_opts_15755, _auto_help_15769);
    DeRefDS(_0);
L8: 

    /** 	pad_size = 0*/
    _pad_size_15761 = 0;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15755)){
            _8600 = SEQ_PTR(_opts_15755)->length;
    }
    else {
        _8600 = 1;
    }
    {
        int _i_15797;
        _i_15797 = 1;
L9: 
        if (_i_15797 > _8600){
            goto LA; // [169] 562
        }

        /** 		this_size = 0*/
        _this_size_15762 = 0;

        /** 		param_name = ""*/
        RefDS(_5);
        DeRef(_param_name_15764);
        _param_name_15764 = _5;

        /** 		if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8601 = (int)*(((s1_ptr)_2)->base + _i_15797);
        _2 = (int)SEQ_PTR(_8601);
        _8602 = (int)*(((s1_ptr)_2)->base + 1);
        _8601 = NOVALUE;
        _8603 = IS_ATOM(_8602);
        _8602 = NOVALUE;
        if (_8603 == 0) {
            goto LB; // [201] 254
        }
        _2 = (int)SEQ_PTR(_opts_15755);
        _8605 = (int)*(((s1_ptr)_2)->base + _i_15797);
        _2 = (int)SEQ_PTR(_8605);
        _8606 = (int)*(((s1_ptr)_2)->base + 2);
        _8605 = NOVALUE;
        _8607 = IS_ATOM(_8606);
        _8606 = NOVALUE;
        if (_8607 == 0)
        {
            _8607 = NOVALUE;
            goto LB; // [217] 254
        }
        else{
            _8607 = NOVALUE;
        }

        /** 			extras_opt = i*/
        _extras_opt_15768 = _i_15797;

        /** 			if find(MANDATORY, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8608 = (int)*(((s1_ptr)_2)->base + _i_15797);
        _2 = (int)SEQ_PTR(_8608);
        _8609 = (int)*(((s1_ptr)_2)->base + 4);
        _8608 = NOVALUE;
        _8610 = find_from(109, _8609, 1);
        _8609 = NOVALUE;
        if (_8610 == 0)
        {
            _8610 = NOVALUE;
            goto LC; // [240] 557
        }
        else{
            _8610 = NOVALUE;
        }

        /** 				extras_mandatory = 1*/
        _extras_mandatory_15767 = 1;

        /** 			continue*/
        goto LC; // [251] 557
LB: 

        /** 		if sequence(opts[i][SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8611 = (int)*(((s1_ptr)_2)->base + _i_15797);
        _2 = (int)SEQ_PTR(_8611);
        _8612 = (int)*(((s1_ptr)_2)->base + 1);
        _8611 = NOVALUE;
        _8613 = IS_SEQUENCE(_8612);
        _8612 = NOVALUE;
        if (_8613 == 0)
        {
            _8613 = NOVALUE;
            goto LD; // [267] 320
        }
        else{
            _8613 = NOVALUE;
        }

        /** 			this_size += length(opts[i][SHORTNAME]) + 1 -- Allow for "-"*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8614 = (int)*(((s1_ptr)_2)->base + _i_15797);
        _2 = (int)SEQ_PTR(_8614);
        _8615 = (int)*(((s1_ptr)_2)->base + 1);
        _8614 = NOVALUE;
        if (IS_SEQUENCE(_8615)){
                _8616 = SEQ_PTR(_8615)->length;
        }
        else {
            _8616 = 1;
        }
        _8615 = NOVALUE;
        _8617 = _8616 + 1;
        _8616 = NOVALUE;
        _this_size_15762 = _this_size_15762 + _8617;
        _8617 = NOVALUE;

        /** 			if find(MANDATORY, opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8619 = (int)*(((s1_ptr)_2)->base + _i_15797);
        _2 = (int)SEQ_PTR(_8619);
        _8620 = (int)*(((s1_ptr)_2)->base + 4);
        _8619 = NOVALUE;
        _8621 = find_from(109, _8620, 1);
        _8620 = NOVALUE;
        if (_8621 != 0)
        goto LE; // [308] 319

        /** 				this_size += 2 -- Allow for '[' ']'*/
        _this_size_15762 = _this_size_15762 + 2;
LE: 
LD: 

        /** 		if sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8624 = (int)*(((s1_ptr)_2)->base + _i_15797);
        _2 = (int)SEQ_PTR(_8624);
        _8625 = (int)*(((s1_ptr)_2)->base + 2);
        _8624 = NOVALUE;
        _8626 = IS_SEQUENCE(_8625);
        _8625 = NOVALUE;
        if (_8626 == 0)
        {
            _8626 = NOVALUE;
            goto LF; // [333] 386
        }
        else{
            _8626 = NOVALUE;
        }

        /** 			this_size += length(opts[i][LONGNAME]) + 2 -- Allow for "--"*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8627 = (int)*(((s1_ptr)_2)->base + _i_15797);
        _2 = (int)SEQ_PTR(_8627);
        _8628 = (int)*(((s1_ptr)_2)->base + 2);
        _8627 = NOVALUE;
        if (IS_SEQUENCE(_8628)){
                _8629 = SEQ_PTR(_8628)->length;
        }
        else {
            _8629 = 1;
        }
        _8628 = NOVALUE;
        _8630 = _8629 + 2;
        _8629 = NOVALUE;
        _this_size_15762 = _this_size_15762 + _8630;
        _8630 = NOVALUE;

        /** 			if find(MANDATORY, opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8632 = (int)*(((s1_ptr)_2)->base + _i_15797);
        _2 = (int)SEQ_PTR(_8632);
        _8633 = (int)*(((s1_ptr)_2)->base + 4);
        _8632 = NOVALUE;
        _8634 = find_from(109, _8633, 1);
        _8633 = NOVALUE;
        if (_8634 != 0)
        goto L10; // [374] 385

        /** 				this_size += 2 -- Allow for '[' ']'*/
        _this_size_15762 = _this_size_15762 + 2;
L10: 
LF: 

        /** 		if sequence(opts[i][SHORTNAME]) and sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8637 = (int)*(((s1_ptr)_2)->base + _i_15797);
        _2 = (int)SEQ_PTR(_8637);
        _8638 = (int)*(((s1_ptr)_2)->base + 1);
        _8637 = NOVALUE;
        _8639 = IS_SEQUENCE(_8638);
        _8638 = NOVALUE;
        if (_8639 == 0) {
            goto L11; // [399] 425
        }
        _2 = (int)SEQ_PTR(_opts_15755);
        _8641 = (int)*(((s1_ptr)_2)->base + _i_15797);
        _2 = (int)SEQ_PTR(_8641);
        _8642 = (int)*(((s1_ptr)_2)->base + 2);
        _8641 = NOVALUE;
        _8643 = IS_SEQUENCE(_8642);
        _8642 = NOVALUE;
        if (_8643 == 0)
        {
            _8643 = NOVALUE;
            goto L11; // [415] 425
        }
        else{
            _8643 = NOVALUE;
        }

        /** 			this_size += 2 -- Allow for ", " between short and long names*/
        _this_size_15762 = _this_size_15762 + 2;
L11: 

        /** 		has_param = find(HAS_PARAMETER, opts[i][OPTIONS])*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8645 = (int)*(((s1_ptr)_2)->base + _i_15797);
        _2 = (int)SEQ_PTR(_8645);
        _8646 = (int)*(((s1_ptr)_2)->base + 4);
        _8645 = NOVALUE;
        _has_param_15765 = find_from(112, _8646, 1);
        _8646 = NOVALUE;

        /** 		if has_param != 0 then*/
        if (_has_param_15765 == 0)
        goto L12; // [442] 543

        /** 			this_size += 1 -- Allow for " "*/
        _this_size_15762 = _this_size_15762 + 1;

        /** 			if has_param < length(opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8650 = (int)*(((s1_ptr)_2)->base + _i_15797);
        _2 = (int)SEQ_PTR(_8650);
        _8651 = (int)*(((s1_ptr)_2)->base + 4);
        _8650 = NOVALUE;
        if (IS_SEQUENCE(_8651)){
                _8652 = SEQ_PTR(_8651)->length;
        }
        else {
            _8652 = 1;
        }
        _8651 = NOVALUE;
        if (_has_param_15765 >= _8652)
        goto L13; // [465] 519

        /** 				if sequence(opts[i][OPTIONS][has_param]) then*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8654 = (int)*(((s1_ptr)_2)->base + _i_15797);
        _2 = (int)SEQ_PTR(_8654);
        _8655 = (int)*(((s1_ptr)_2)->base + 4);
        _8654 = NOVALUE;
        _2 = (int)SEQ_PTR(_8655);
        _8656 = (int)*(((s1_ptr)_2)->base + _has_param_15765);
        _8655 = NOVALUE;
        _8657 = IS_SEQUENCE(_8656);
        _8656 = NOVALUE;
        if (_8657 == 0)
        {
            _8657 = NOVALUE;
            goto L14; // [486] 508
        }
        else{
            _8657 = NOVALUE;
        }

        /** 					param_name = opts[i][OPTIONS][has_param]*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8658 = (int)*(((s1_ptr)_2)->base + _i_15797);
        _2 = (int)SEQ_PTR(_8658);
        _8659 = (int)*(((s1_ptr)_2)->base + 4);
        _8658 = NOVALUE;
        DeRef(_param_name_15764);
        _2 = (int)SEQ_PTR(_8659);
        _param_name_15764 = (int)*(((s1_ptr)_2)->base + _has_param_15765);
        Ref(_param_name_15764);
        _8659 = NOVALUE;
        goto L15; // [505] 527
L14: 

        /** 					param_name = "x"*/
        RefDS(_8443);
        DeRef(_param_name_15764);
        _param_name_15764 = _8443;
        goto L15; // [516] 527
L13: 

        /** 				param_name = "x"*/
        RefDS(_8443);
        DeRef(_param_name_15764);
        _param_name_15764 = _8443;
L15: 

        /** 			this_size += 2 + length(param_name)*/
        if (IS_SEQUENCE(_param_name_15764)){
                _8661 = SEQ_PTR(_param_name_15764)->length;
        }
        else {
            _8661 = 1;
        }
        _8662 = 2 + _8661;
        _8661 = NOVALUE;
        _this_size_15762 = _this_size_15762 + _8662;
        _8662 = NOVALUE;
L12: 

        /** 		if pad_size < this_size then*/
        if (_pad_size_15761 >= _this_size_15762)
        goto L16; // [545] 555

        /** 			pad_size = this_size*/
        _pad_size_15761 = _this_size_15762;
L16: 

        /** 	end for*/
LC: 
        _i_15797 = _i_15797 + 1;
        goto L9; // [557] 176
LA: 
        ;
    }

    /** 	pad_size += 3 -- Allow for minimum gap between cmd and its description*/
    _pad_size_15761 = _pad_size_15761 + 3;

    /** 	printf(1, "%s options:\n", {cmds[2]})*/
    _2 = (int)SEQ_PTR(_cmds_15757);
    _8667 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_8667);
    *((int *)(_2+4)) = _8667;
    _8668 = MAKE_SEQ(_1);
    _8667 = NOVALUE;
    EPrintf(1, _8666, _8668);
    DeRefDS(_8668);
    _8668 = NOVALUE;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15755)){
            _8669 = SEQ_PTR(_opts_15755)->length;
    }
    else {
        _8669 = 1;
    }
    {
        int _i_15881;
        _i_15881 = 1;
L17: 
        if (_i_15881 > _8669){
            goto L18; // [587] 1006
        }

        /** 		if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8670 = (int)*(((s1_ptr)_2)->base + _i_15881);
        _2 = (int)SEQ_PTR(_8670);
        _8671 = (int)*(((s1_ptr)_2)->base + 1);
        _8670 = NOVALUE;
        _8672 = IS_ATOM(_8671);
        _8671 = NOVALUE;
        if (_8672 == 0) {
            goto L19; // [607] 631
        }
        _2 = (int)SEQ_PTR(_opts_15755);
        _8674 = (int)*(((s1_ptr)_2)->base + _i_15881);
        _2 = (int)SEQ_PTR(_8674);
        _8675 = (int)*(((s1_ptr)_2)->base + 2);
        _8674 = NOVALUE;
        _8676 = IS_ATOM(_8675);
        _8675 = NOVALUE;
        if (_8676 == 0)
        {
            _8676 = NOVALUE;
            goto L19; // [623] 631
        }
        else{
            _8676 = NOVALUE;
        }

        /** 			continue*/
        goto L1A; // [628] 1001
L19: 

        /** 		has_param    = find(HAS_PARAMETER, opts[i][OPTIONS])*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8677 = (int)*(((s1_ptr)_2)->base + _i_15881);
        _2 = (int)SEQ_PTR(_8677);
        _8678 = (int)*(((s1_ptr)_2)->base + 4);
        _8677 = NOVALUE;
        _has_param_15765 = find_from(112, _8678, 1);
        _8678 = NOVALUE;

        /** 		if has_param != 0 then*/
        if (_has_param_15765 == 0)
        goto L1B; // [648] 734

        /** 			if has_param < length(opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8681 = (int)*(((s1_ptr)_2)->base + _i_15881);
        _2 = (int)SEQ_PTR(_8681);
        _8682 = (int)*(((s1_ptr)_2)->base + 4);
        _8681 = NOVALUE;
        if (IS_SEQUENCE(_8682)){
                _8683 = SEQ_PTR(_8682)->length;
        }
        else {
            _8683 = 1;
        }
        _8682 = NOVALUE;
        if (_has_param_15765 >= _8683)
        goto L1C; // [665] 725

        /** 				has_param += 1*/
        _has_param_15765 = _has_param_15765 + 1;

        /** 				if sequence(opts[i][OPTIONS][has_param]) then*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8686 = (int)*(((s1_ptr)_2)->base + _i_15881);
        _2 = (int)SEQ_PTR(_8686);
        _8687 = (int)*(((s1_ptr)_2)->base + 4);
        _8686 = NOVALUE;
        _2 = (int)SEQ_PTR(_8687);
        _8688 = (int)*(((s1_ptr)_2)->base + _has_param_15765);
        _8687 = NOVALUE;
        _8689 = IS_SEQUENCE(_8688);
        _8688 = NOVALUE;
        if (_8689 == 0)
        {
            _8689 = NOVALUE;
            goto L1D; // [692] 714
        }
        else{
            _8689 = NOVALUE;
        }

        /** 					param_name = opts[i][OPTIONS][has_param]*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8690 = (int)*(((s1_ptr)_2)->base + _i_15881);
        _2 = (int)SEQ_PTR(_8690);
        _8691 = (int)*(((s1_ptr)_2)->base + 4);
        _8690 = NOVALUE;
        DeRef(_param_name_15764);
        _2 = (int)SEQ_PTR(_8691);
        _param_name_15764 = (int)*(((s1_ptr)_2)->base + _has_param_15765);
        Ref(_param_name_15764);
        _8691 = NOVALUE;
        goto L1E; // [711] 733
L1D: 

        /** 					param_name = "x"*/
        RefDS(_8443);
        DeRef(_param_name_15764);
        _param_name_15764 = _8443;
        goto L1E; // [722] 733
L1C: 

        /** 				param_name = "x"*/
        RefDS(_8443);
        DeRef(_param_name_15764);
        _param_name_15764 = _8443;
L1E: 
L1B: 

        /** 		is_mandatory = (find(MANDATORY,     opts[i][OPTIONS]) != 0)*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8693 = (int)*(((s1_ptr)_2)->base + _i_15881);
        _2 = (int)SEQ_PTR(_8693);
        _8694 = (int)*(((s1_ptr)_2)->base + 4);
        _8693 = NOVALUE;
        _8695 = find_from(109, _8694, 1);
        _8694 = NOVALUE;
        _is_mandatory_15766 = (_8695 != 0);
        _8695 = NOVALUE;

        /** 		cmd = ""*/
        RefDS(_5);
        DeRef(_cmd_15763);
        _cmd_15763 = _5;

        /** 		if sequence(opts[i][SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8697 = (int)*(((s1_ptr)_2)->base + _i_15881);
        _2 = (int)SEQ_PTR(_8697);
        _8698 = (int)*(((s1_ptr)_2)->base + 1);
        _8697 = NOVALUE;
        _8699 = IS_SEQUENCE(_8698);
        _8698 = NOVALUE;
        if (_8699 == 0)
        {
            _8699 = NOVALUE;
            goto L1F; // [773] 838
        }
        else{
            _8699 = NOVALUE;
        }

        /** 			if not is_mandatory then*/
        if (_is_mandatory_15766 != 0)
        goto L20; // [778] 788

        /** 				cmd &= '['*/
        Append(&_cmd_15763, _cmd_15763, 91);
L20: 

        /** 			cmd &= '-' & opts[i][SHORTNAME]*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8702 = (int)*(((s1_ptr)_2)->base + _i_15881);
        _2 = (int)SEQ_PTR(_8702);
        _8703 = (int)*(((s1_ptr)_2)->base + 1);
        _8702 = NOVALUE;
        if (IS_SEQUENCE(45) && IS_ATOM(_8703)) {
        }
        else if (IS_ATOM(45) && IS_SEQUENCE(_8703)) {
            Prepend(&_8704, _8703, 45);
        }
        else {
            Concat((object_ptr)&_8704, 45, _8703);
        }
        _8703 = NOVALUE;
        Concat((object_ptr)&_cmd_15763, _cmd_15763, _8704);
        DeRefDS(_8704);
        _8704 = NOVALUE;

        /** 			if has_param != 0 then*/
        if (_has_param_15765 == 0)
        goto L21; // [808] 825

        /** 				cmd &= ' ' & param_name*/
        Prepend(&_8707, _param_name_15764, 32);
        Concat((object_ptr)&_cmd_15763, _cmd_15763, _8707);
        DeRefDS(_8707);
        _8707 = NOVALUE;
L21: 

        /** 			if not is_mandatory then*/
        if (_is_mandatory_15766 != 0)
        goto L22; // [827] 837

        /** 				cmd &= ']'*/
        Append(&_cmd_15763, _cmd_15763, 93);
L22: 
L1F: 

        /** 		if sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8711 = (int)*(((s1_ptr)_2)->base + _i_15881);
        _2 = (int)SEQ_PTR(_8711);
        _8712 = (int)*(((s1_ptr)_2)->base + 2);
        _8711 = NOVALUE;
        _8713 = IS_SEQUENCE(_8712);
        _8712 = NOVALUE;
        if (_8713 == 0)
        {
            _8713 = NOVALUE;
            goto L23; // [851] 930
        }
        else{
            _8713 = NOVALUE;
        }

        /** 			if length(cmd) > 0 then cmd &= ", " end if*/
        if (IS_SEQUENCE(_cmd_15763)){
                _8714 = SEQ_PTR(_cmd_15763)->length;
        }
        else {
            _8714 = 1;
        }
        if (_8714 <= 0)
        goto L24; // [859] 868
        Concat((object_ptr)&_cmd_15763, _cmd_15763, _8716);
L24: 

        /** 			if not is_mandatory then*/
        if (_is_mandatory_15766 != 0)
        goto L25; // [870] 880

        /** 				cmd &= '['*/
        Append(&_cmd_15763, _cmd_15763, 91);
L25: 

        /** 			cmd &= "--" & opts[i][LONGNAME]*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8720 = (int)*(((s1_ptr)_2)->base + _i_15881);
        _2 = (int)SEQ_PTR(_8720);
        _8721 = (int)*(((s1_ptr)_2)->base + 2);
        _8720 = NOVALUE;
        if (IS_SEQUENCE(_7692) && IS_ATOM(_8721)) {
            Ref(_8721);
            Append(&_8722, _7692, _8721);
        }
        else if (IS_ATOM(_7692) && IS_SEQUENCE(_8721)) {
        }
        else {
            Concat((object_ptr)&_8722, _7692, _8721);
        }
        _8721 = NOVALUE;
        Concat((object_ptr)&_cmd_15763, _cmd_15763, _8722);
        DeRefDS(_8722);
        _8722 = NOVALUE;

        /** 			if has_param != 0 then*/
        if (_has_param_15765 == 0)
        goto L26; // [900] 917

        /** 				cmd &= '=' & param_name*/
        Prepend(&_8725, _param_name_15764, 61);
        Concat((object_ptr)&_cmd_15763, _cmd_15763, _8725);
        DeRefDS(_8725);
        _8725 = NOVALUE;
L26: 

        /** 			if not is_mandatory then*/
        if (_is_mandatory_15766 != 0)
        goto L27; // [919] 929

        /** 				cmd &= ']'*/
        Append(&_cmd_15763, _cmd_15763, 93);
L27: 
L23: 

        /** 		if length(cmd) > pad_size then*/
        if (IS_SEQUENCE(_cmd_15763)){
                _8729 = SEQ_PTR(_cmd_15763)->length;
        }
        else {
            _8729 = 1;
        }
        if (_8729 <= _pad_size_15761)
        goto L28; // [935] 966

        /** 			puts(1, "   " & cmd & '\n')*/
        {
            int concat_list[3];

            concat_list[0] = 10;
            concat_list[1] = _cmd_15763;
            concat_list[2] = _8731;
            Concat_N((object_ptr)&_8732, concat_list, 3);
        }
        EPuts(1, _8732); // DJP 
        DeRefDS(_8732);
        _8732 = NOVALUE;

        /** 			puts(1, repeat(' ', pad_size + 3))*/
        _8733 = _pad_size_15761 + 3;
        _8734 = Repeat(32, _8733);
        _8733 = NOVALUE;
        EPuts(1, _8734); // DJP 
        DeRefDS(_8734);
        _8734 = NOVALUE;
        goto L29; // [963] 982
L28: 

        /** 			puts(1, "   " & stdseq:pad_tail(cmd, pad_size))*/
        RefDS(_cmd_15763);
        _8735 = _23pad_tail(_cmd_15763, _pad_size_15761, 32);
        if (IS_SEQUENCE(_8731) && IS_ATOM(_8735)) {
            Ref(_8735);
            Append(&_8736, _8731, _8735);
        }
        else if (IS_ATOM(_8731) && IS_SEQUENCE(_8735)) {
        }
        else {
            Concat((object_ptr)&_8736, _8731, _8735);
        }
        DeRef(_8735);
        _8735 = NOVALUE;
        EPuts(1, _8736); // DJP 
        DeRefDS(_8736);
        _8736 = NOVALUE;
L29: 

        /** 		puts(1, opts[i][DESCRIPTION] & '\n')*/
        _2 = (int)SEQ_PTR(_opts_15755);
        _8737 = (int)*(((s1_ptr)_2)->base + _i_15881);
        _2 = (int)SEQ_PTR(_8737);
        _8738 = (int)*(((s1_ptr)_2)->base + 3);
        _8737 = NOVALUE;
        if (IS_SEQUENCE(_8738) && IS_ATOM(10)) {
            Append(&_8739, _8738, 10);
        }
        else if (IS_ATOM(_8738) && IS_SEQUENCE(10)) {
        }
        else {
            Concat((object_ptr)&_8739, _8738, 10);
            _8738 = NOVALUE;
        }
        _8738 = NOVALUE;
        EPuts(1, _8739); // DJP 
        DeRefDS(_8739);
        _8739 = NOVALUE;

        /** 	end for*/
L1A: 
        _i_15881 = _i_15881 + 1;
        goto L17; // [1001] 594
L18: 
        ;
    }

    /** 	if extras_mandatory != 0 then*/
    if (_extras_mandatory_15767 == 0)
    goto L2A; // [1008] 1063

    /** 		if length(opts[extras_opt][DESCRIPTION]) > 0 then*/
    _2 = (int)SEQ_PTR(_opts_15755);
    _8741 = (int)*(((s1_ptr)_2)->base + _extras_opt_15768);
    _2 = (int)SEQ_PTR(_8741);
    _8742 = (int)*(((s1_ptr)_2)->base + 3);
    _8741 = NOVALUE;
    if (IS_SEQUENCE(_8742)){
            _8743 = SEQ_PTR(_8742)->length;
    }
    else {
        _8743 = 1;
    }
    _8742 = NOVALUE;
    if (_8743 <= 0)
    goto L2B; // [1025] 1054

    /** 			puts(1, "\n" & opts[extras_opt][DESCRIPTION])*/
    _2 = (int)SEQ_PTR(_opts_15755);
    _8745 = (int)*(((s1_ptr)_2)->base + _extras_opt_15768);
    _2 = (int)SEQ_PTR(_8745);
    _8746 = (int)*(((s1_ptr)_2)->base + 3);
    _8745 = NOVALUE;
    if (IS_SEQUENCE(_1359) && IS_ATOM(_8746)) {
        Ref(_8746);
        Append(&_8747, _1359, _8746);
    }
    else if (IS_ATOM(_1359) && IS_SEQUENCE(_8746)) {
    }
    else {
        Concat((object_ptr)&_8747, _1359, _8746);
    }
    _8746 = NOVALUE;
    EPuts(1, _8747); // DJP 
    DeRefDS(_8747);
    _8747 = NOVALUE;

    /** 			puts(1, '\n')*/
    EPuts(1, 10); // DJP 
    goto L2C; // [1051] 1119
L2B: 

    /** 			puts(1, "One or more additional arguments are also required\n")*/
    EPuts(1, _8748); // DJP 
    goto L2C; // [1060] 1119
L2A: 

    /** 	elsif extras_opt > 0 then*/
    if (_extras_opt_15768 <= 0)
    goto L2D; // [1065] 1118

    /** 		if length(opts[extras_opt][DESCRIPTION]) > 0 then*/
    _2 = (int)SEQ_PTR(_opts_15755);
    _8750 = (int)*(((s1_ptr)_2)->base + _extras_opt_15768);
    _2 = (int)SEQ_PTR(_8750);
    _8751 = (int)*(((s1_ptr)_2)->base + 3);
    _8750 = NOVALUE;
    if (IS_SEQUENCE(_8751)){
            _8752 = SEQ_PTR(_8751)->length;
    }
    else {
        _8752 = 1;
    }
    _8751 = NOVALUE;
    if (_8752 <= 0)
    goto L2E; // [1082] 1111

    /** 			puts(1, "\n" & opts[extras_opt][DESCRIPTION])*/
    _2 = (int)SEQ_PTR(_opts_15755);
    _8754 = (int)*(((s1_ptr)_2)->base + _extras_opt_15768);
    _2 = (int)SEQ_PTR(_8754);
    _8755 = (int)*(((s1_ptr)_2)->base + 3);
    _8754 = NOVALUE;
    if (IS_SEQUENCE(_1359) && IS_ATOM(_8755)) {
        Ref(_8755);
        Append(&_8756, _1359, _8755);
    }
    else if (IS_ATOM(_1359) && IS_SEQUENCE(_8755)) {
    }
    else {
        Concat((object_ptr)&_8756, _1359, _8755);
    }
    _8755 = NOVALUE;
    EPuts(1, _8756); // DJP 
    DeRefDS(_8756);
    _8756 = NOVALUE;

    /** 			puts(1, '\n')*/
    EPuts(1, 10); // DJP 
    goto L2F; // [1108] 1117
L2E: 

    /** 			puts(1, "One or more additional arguments can be supplied.\n")*/
    EPuts(1, _8757); // DJP 
L2F: 
L2D: 
L2C: 

    /** 	if atom(add_help_rid) then*/
    _8758 = IS_ATOM(_add_help_rid_15756);
    if (_8758 == 0)
    {
        _8758 = NOVALUE;
        goto L30; // [1124] 1152
    }
    else{
        _8758 = NOVALUE;
    }

    /** 		if add_help_rid >= 0 then*/
    if (binary_op_a(LESS, _add_help_rid_15756, 0)){
        goto L31; // [1129] 1260
    }

    /** 			puts(1, "\n")*/
    EPuts(1, _1359); // DJP 

    /** 			call_proc(add_help_rid, {})*/
    _0 = (int)_00[_add_help_rid_15756].addr;
    (*(int (*)())_0)(
                         );

    /** 			puts(1, "\n")*/
    EPuts(1, _1359); // DJP 
    goto L31; // [1149] 1260
L30: 

    /** 		if length(add_help_rid) > 0 then*/
    if (IS_SEQUENCE(_add_help_rid_15756)){
            _8760 = SEQ_PTR(_add_help_rid_15756)->length;
    }
    else {
        _8760 = 1;
    }
    if (_8760 <= 0)
    goto L32; // [1157] 1259

    /** 			puts(1, "\n")*/
    EPuts(1, _1359); // DJP 

    /** 			if types:t_display(add_help_rid) then*/
    Ref(_add_help_rid_15756);
    _8762 = _9t_display(_add_help_rid_15756);
    if (_8762 == 0) {
        DeRef(_8762);
        _8762 = NOVALUE;
        goto L33; // [1172] 1182
    }
    else {
        if (!IS_ATOM_INT(_8762) && DBL_PTR(_8762)->dbl == 0.0){
            DeRef(_8762);
            _8762 = NOVALUE;
            goto L33; // [1172] 1182
        }
        DeRef(_8762);
        _8762 = NOVALUE;
    }
    DeRef(_8762);
    _8762 = NOVALUE;

    /** 				add_help_rid = {add_help_rid}*/
    _0 = _add_help_rid_15756;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_add_help_rid_15756);
    *((int *)(_2+4)) = _add_help_rid_15756;
    _add_help_rid_15756 = MAKE_SEQ(_1);
    DeRef(_0);
L33: 

    /** 			for i = 1 to length(add_help_rid) do*/
    if (IS_SEQUENCE(_add_help_rid_15756)){
            _8764 = SEQ_PTR(_add_help_rid_15756)->length;
    }
    else {
        _8764 = 1;
    }
    {
        int _i_16006;
        _i_16006 = 1;
L34: 
        if (_i_16006 > _8764){
            goto L35; // [1187] 1253
        }

        /** 				puts(1, add_help_rid[i])*/
        _2 = (int)SEQ_PTR(_add_help_rid_15756);
        _8765 = (int)*(((s1_ptr)_2)->base + _i_16006);
        EPuts(1, _8765); // DJP 
        _8765 = NOVALUE;

        /** 				if length(add_help_rid[i]) = 0 or add_help_rid[i][$] != '\n' then*/
        _2 = (int)SEQ_PTR(_add_help_rid_15756);
        _8766 = (int)*(((s1_ptr)_2)->base + _i_16006);
        if (IS_SEQUENCE(_8766)){
                _8767 = SEQ_PTR(_8766)->length;
        }
        else {
            _8767 = 1;
        }
        _8766 = NOVALUE;
        _8768 = (_8767 == 0);
        _8767 = NOVALUE;
        if (_8768 != 0) {
            goto L36; // [1216] 1240
        }
        _2 = (int)SEQ_PTR(_add_help_rid_15756);
        _8770 = (int)*(((s1_ptr)_2)->base + _i_16006);
        if (IS_SEQUENCE(_8770)){
                _8771 = SEQ_PTR(_8770)->length;
        }
        else {
            _8771 = 1;
        }
        _2 = (int)SEQ_PTR(_8770);
        _8772 = (int)*(((s1_ptr)_2)->base + _8771);
        _8770 = NOVALUE;
        if (IS_ATOM_INT(_8772)) {
            _8773 = (_8772 != 10);
        }
        else {
            _8773 = binary_op(NOTEQ, _8772, 10);
        }
        _8772 = NOVALUE;
        if (_8773 == 0) {
            DeRef(_8773);
            _8773 = NOVALUE;
            goto L37; // [1236] 1246
        }
        else {
            if (!IS_ATOM_INT(_8773) && DBL_PTR(_8773)->dbl == 0.0){
                DeRef(_8773);
                _8773 = NOVALUE;
                goto L37; // [1236] 1246
            }
            DeRef(_8773);
            _8773 = NOVALUE;
        }
        DeRef(_8773);
        _8773 = NOVALUE;
L36: 

        /** 					puts(1, '\n')*/
        EPuts(1, 10); // DJP 
L37: 

        /** 			end for*/
        _i_16006 = _i_16006 + 1;
        goto L34; // [1248] 1194
L35: 
        ;
    }

    /** 			puts(1, "\n")*/
    EPuts(1, _1359); // DJP 
L32: 
L31: 

    /** end procedure*/
    DeRefDS(_opts_15755);
    DeRef(_add_help_rid_15756);
    DeRefDS(_cmds_15757);
    DeRef(_parse_options_15760);
    DeRef(_cmd_15763);
    DeRef(_param_name_15764);
    _8615 = NOVALUE;
    _8628 = NOVALUE;
    _8651 = NOVALUE;
    _8682 = NOVALUE;
    _8742 = NOVALUE;
    _8751 = NOVALUE;
    _8766 = NOVALUE;
    DeRef(_8768);
    _8768 = NOVALUE;
    return;
    ;
}


int _40find_opt(int _opts_16027, int _opt_style_16028, int _cmd_text_16029)
{
    int _opt_name_16030 = NOVALUE;
    int _opt_param_16031 = NOVALUE;
    int _param_found_16032 = NOVALUE;
    int _reversed_16033 = NOVALUE;
    int _8875 = NOVALUE;
    int _8873 = NOVALUE;
    int _8872 = NOVALUE;
    int _8870 = NOVALUE;
    int _8869 = NOVALUE;
    int _8868 = NOVALUE;
    int _8867 = NOVALUE;
    int _8866 = NOVALUE;
    int _8863 = NOVALUE;
    int _8862 = NOVALUE;
    int _8861 = NOVALUE;
    int _8859 = NOVALUE;
    int _8858 = NOVALUE;
    int _8857 = NOVALUE;
    int _8856 = NOVALUE;
    int _8854 = NOVALUE;
    int _8853 = NOVALUE;
    int _8852 = NOVALUE;
    int _8851 = NOVALUE;
    int _8850 = NOVALUE;
    int _8849 = NOVALUE;
    int _8848 = NOVALUE;
    int _8847 = NOVALUE;
    int _8846 = NOVALUE;
    int _8845 = NOVALUE;
    int _8844 = NOVALUE;
    int _8843 = NOVALUE;
    int _8837 = NOVALUE;
    int _8836 = NOVALUE;
    int _8835 = NOVALUE;
    int _8827 = NOVALUE;
    int _8826 = NOVALUE;
    int _8824 = NOVALUE;
    int _8822 = NOVALUE;
    int _8821 = NOVALUE;
    int _8819 = NOVALUE;
    int _8818 = NOVALUE;
    int _8817 = NOVALUE;
    int _8816 = NOVALUE;
    int _8815 = NOVALUE;
    int _8813 = NOVALUE;
    int _8812 = NOVALUE;
    int _8810 = NOVALUE;
    int _8808 = NOVALUE;
    int _8807 = NOVALUE;
    int _8805 = NOVALUE;
    int _8804 = NOVALUE;
    int _8803 = NOVALUE;
    int _8802 = NOVALUE;
    int _8800 = NOVALUE;
    int _8799 = NOVALUE;
    int _8796 = NOVALUE;
    int _8794 = NOVALUE;
    int _8793 = NOVALUE;
    int _8791 = NOVALUE;
    int _8789 = NOVALUE;
    int _8787 = NOVALUE;
    int _8786 = NOVALUE;
    int _8784 = NOVALUE;
    int _8783 = NOVALUE;
    int _8782 = NOVALUE;
    int _8781 = NOVALUE;
    int _8780 = NOVALUE;
    int _8778 = NOVALUE;
    int _8777 = NOVALUE;
    int _8775 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer param_found = 0*/
    _param_found_16032 = 0;

    /** 	integer reversed = 0*/
    _reversed_16033 = 0;

    /** 	if length(cmd_text) >= 2 then*/
    if (IS_SEQUENCE(_cmd_text_16029)){
            _8775 = SEQ_PTR(_cmd_text_16029)->length;
    }
    else {
        _8775 = 1;
    }
    if (_8775 < 2)
    goto L1; // [20] 85

    /** 		if cmd_text[1] = '\'' or cmd_text[1] = '"' then*/
    _2 = (int)SEQ_PTR(_cmd_text_16029);
    _8777 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8777)) {
        _8778 = (_8777 == 39);
    }
    else {
        _8778 = binary_op(EQUALS, _8777, 39);
    }
    _8777 = NOVALUE;
    if (IS_ATOM_INT(_8778)) {
        if (_8778 != 0) {
            goto L2; // [34] 51
        }
    }
    else {
        if (DBL_PTR(_8778)->dbl != 0.0) {
            goto L2; // [34] 51
        }
    }
    _2 = (int)SEQ_PTR(_cmd_text_16029);
    _8780 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8780)) {
        _8781 = (_8780 == 34);
    }
    else {
        _8781 = binary_op(EQUALS, _8780, 34);
    }
    _8780 = NOVALUE;
    if (_8781 == 0) {
        DeRef(_8781);
        _8781 = NOVALUE;
        goto L3; // [47] 84
    }
    else {
        if (!IS_ATOM_INT(_8781) && DBL_PTR(_8781)->dbl == 0.0){
            DeRef(_8781);
            _8781 = NOVALUE;
            goto L3; // [47] 84
        }
        DeRef(_8781);
        _8781 = NOVALUE;
    }
    DeRef(_8781);
    _8781 = NOVALUE;
L2: 

    /** 			if cmd_text[$] = cmd_text[1] then*/
    if (IS_SEQUENCE(_cmd_text_16029)){
            _8782 = SEQ_PTR(_cmd_text_16029)->length;
    }
    else {
        _8782 = 1;
    }
    _2 = (int)SEQ_PTR(_cmd_text_16029);
    _8783 = (int)*(((s1_ptr)_2)->base + _8782);
    _2 = (int)SEQ_PTR(_cmd_text_16029);
    _8784 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _8783, _8784)){
        _8783 = NOVALUE;
        _8784 = NOVALUE;
        goto L4; // [64] 83
    }
    _8783 = NOVALUE;
    _8784 = NOVALUE;

    /** 				cmd_text = cmd_text[2 .. $-1]*/
    if (IS_SEQUENCE(_cmd_text_16029)){
            _8786 = SEQ_PTR(_cmd_text_16029)->length;
    }
    else {
        _8786 = 1;
    }
    _8787 = _8786 - 1;
    _8786 = NOVALUE;
    rhs_slice_target = (object_ptr)&_cmd_text_16029;
    RHS_Slice(_cmd_text_16029, 2, _8787);
L4: 
L3: 
L1: 

    /** 	if length(cmd_text) > 0 then*/
    if (IS_SEQUENCE(_cmd_text_16029)){
            _8789 = SEQ_PTR(_cmd_text_16029)->length;
    }
    else {
        _8789 = 1;
    }
    if (_8789 <= 0)
    goto L5; // [90] 125

    /** 		if find(cmd_text[1], "!-") then*/
    _2 = (int)SEQ_PTR(_cmd_text_16029);
    _8791 = (int)*(((s1_ptr)_2)->base + 1);
    _8793 = find_from(_8791, _8792, 1);
    _8791 = NOVALUE;
    if (_8793 == 0)
    {
        _8793 = NOVALUE;
        goto L6; // [105] 124
    }
    else{
        _8793 = NOVALUE;
    }

    /** 			reversed = 1*/
    _reversed_16033 = 1;

    /** 			cmd_text = cmd_text[2 .. $]*/
    if (IS_SEQUENCE(_cmd_text_16029)){
            _8794 = SEQ_PTR(_cmd_text_16029)->length;
    }
    else {
        _8794 = 1;
    }
    rhs_slice_target = (object_ptr)&_cmd_text_16029;
    RHS_Slice(_cmd_text_16029, 2, _8794);
L6: 
L5: 

    /** 	if length(cmd_text) < 1 then*/
    if (IS_SEQUENCE(_cmd_text_16029)){
            _8796 = SEQ_PTR(_cmd_text_16029)->length;
    }
    else {
        _8796 = 1;
    }
    if (_8796 >= 1)
    goto L7; // [130] 145

    /** 		return {-1, "Empty command text"}*/
    RefDS(_8798);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _8798;
    _8799 = MAKE_SEQ(_1);
    DeRefDS(_opts_16027);
    DeRefDS(_opt_style_16028);
    DeRef(_cmd_text_16029);
    DeRef(_opt_name_16030);
    DeRef(_opt_param_16031);
    DeRef(_8787);
    _8787 = NOVALUE;
    DeRef(_8778);
    _8778 = NOVALUE;
    return _8799;
L7: 

    /** 	opt_name = repeat(' ', length(cmd_text))*/
    if (IS_SEQUENCE(_cmd_text_16029)){
            _8800 = SEQ_PTR(_cmd_text_16029)->length;
    }
    else {
        _8800 = 1;
    }
    DeRef(_opt_name_16030);
    _opt_name_16030 = Repeat(32, _8800);
    _8800 = NOVALUE;

    /** 	opt_param = 0*/
    DeRef(_opt_param_16031);
    _opt_param_16031 = 0;

    /** 	for i = 1 to length(cmd_text) do*/
    if (IS_SEQUENCE(_cmd_text_16029)){
            _8802 = SEQ_PTR(_cmd_text_16029)->length;
    }
    else {
        _8802 = 1;
    }
    {
        int _i_16068;
        _i_16068 = 1;
L8: 
        if (_i_16068 > _8802){
            goto L9; // [164] 320
        }

        /** 		if find(cmd_text[i], ":=") then*/
        _2 = (int)SEQ_PTR(_cmd_text_16029);
        _8803 = (int)*(((s1_ptr)_2)->base + _i_16068);
        _8804 = find_from(_8803, _5245, 1);
        _8803 = NOVALUE;
        if (_8804 == 0)
        {
            _8804 = NOVALUE;
            goto LA; // [182] 302
        }
        else{
            _8804 = NOVALUE;
        }

        /** 			opt_name = opt_name[1 .. i - 1]*/
        _8805 = _i_16068 - 1;
        rhs_slice_target = (object_ptr)&_opt_name_16030;
        RHS_Slice(_opt_name_16030, 1, _8805);

        /** 			opt_param = cmd_text[i + 1 .. $]*/
        _8807 = _i_16068 + 1;
        if (IS_SEQUENCE(_cmd_text_16029)){
                _8808 = SEQ_PTR(_cmd_text_16029)->length;
        }
        else {
            _8808 = 1;
        }
        rhs_slice_target = (object_ptr)&_opt_param_16031;
        RHS_Slice(_cmd_text_16029, _8807, _8808);

        /** 			if length(opt_param) >= 2 then*/
        if (IS_SEQUENCE(_opt_param_16031)){
                _8810 = SEQ_PTR(_opt_param_16031)->length;
        }
        else {
            _8810 = 1;
        }
        if (_8810 < 2)
        goto LB; // [215] 280

        /** 				if opt_param[1] = '\'' or opt_param[1] = '"' then*/
        _2 = (int)SEQ_PTR(_opt_param_16031);
        _8812 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_8812)) {
            _8813 = (_8812 == 39);
        }
        else {
            _8813 = binary_op(EQUALS, _8812, 39);
        }
        _8812 = NOVALUE;
        if (IS_ATOM_INT(_8813)) {
            if (_8813 != 0) {
                goto LC; // [229] 246
            }
        }
        else {
            if (DBL_PTR(_8813)->dbl != 0.0) {
                goto LC; // [229] 246
            }
        }
        _2 = (int)SEQ_PTR(_opt_param_16031);
        _8815 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_8815)) {
            _8816 = (_8815 == 34);
        }
        else {
            _8816 = binary_op(EQUALS, _8815, 34);
        }
        _8815 = NOVALUE;
        if (_8816 == 0) {
            DeRef(_8816);
            _8816 = NOVALUE;
            goto LD; // [242] 279
        }
        else {
            if (!IS_ATOM_INT(_8816) && DBL_PTR(_8816)->dbl == 0.0){
                DeRef(_8816);
                _8816 = NOVALUE;
                goto LD; // [242] 279
            }
            DeRef(_8816);
            _8816 = NOVALUE;
        }
        DeRef(_8816);
        _8816 = NOVALUE;
LC: 

        /** 					if opt_param[$] = opt_param[1] then*/
        if (IS_SEQUENCE(_opt_param_16031)){
                _8817 = SEQ_PTR(_opt_param_16031)->length;
        }
        else {
            _8817 = 1;
        }
        _2 = (int)SEQ_PTR(_opt_param_16031);
        _8818 = (int)*(((s1_ptr)_2)->base + _8817);
        _2 = (int)SEQ_PTR(_opt_param_16031);
        _8819 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _8818, _8819)){
            _8818 = NOVALUE;
            _8819 = NOVALUE;
            goto LE; // [259] 278
        }
        _8818 = NOVALUE;
        _8819 = NOVALUE;

        /** 						opt_param = opt_param[2 .. $-1]*/
        if (IS_SEQUENCE(_opt_param_16031)){
                _8821 = SEQ_PTR(_opt_param_16031)->length;
        }
        else {
            _8821 = 1;
        }
        _8822 = _8821 - 1;
        _8821 = NOVALUE;
        rhs_slice_target = (object_ptr)&_opt_param_16031;
        RHS_Slice(_opt_param_16031, 2, _8822);
LE: 
LD: 
LB: 

        /** 			if length(opt_param) > 0 then*/
        if (IS_SEQUENCE(_opt_param_16031)){
                _8824 = SEQ_PTR(_opt_param_16031)->length;
        }
        else {
            _8824 = 1;
        }
        if (_8824 <= 0)
        goto L9; // [285] 320

        /** 				param_found = 1*/
        _param_found_16032 = 1;

        /** 			exit*/
        goto L9; // [297] 320
        goto LF; // [299] 313
LA: 

        /** 			opt_name[i] = cmd_text[i]*/
        _2 = (int)SEQ_PTR(_cmd_text_16029);
        _8826 = (int)*(((s1_ptr)_2)->base + _i_16068);
        Ref(_8826);
        _2 = (int)SEQ_PTR(_opt_name_16030);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_name_16030 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_16068);
        _1 = *(int *)_2;
        *(int *)_2 = _8826;
        if( _1 != _8826 ){
            DeRef(_1);
        }
        _8826 = NOVALUE;
LF: 

        /** 	end for*/
        _i_16068 = _i_16068 + 1;
        goto L8; // [315] 171
L9: 
        ;
    }

    /** 	if param_found then*/
    if (_param_found_16032 == 0)
    {
        goto L10; // [322] 388
    }
    else{
    }

    /** 		if find( text:lower(opt_param), {"1", "on", "yes", "y", "true", "ok", "+"}) then*/
    Ref(_opt_param_16031);
    _8827 = _12lower(_opt_param_16031);
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8828);
    *((int *)(_2+4)) = _8828;
    RefDS(_8829);
    *((int *)(_2+8)) = _8829;
    RefDS(_8830);
    *((int *)(_2+12)) = _8830;
    RefDS(_8831);
    *((int *)(_2+16)) = _8831;
    RefDS(_8832);
    *((int *)(_2+20)) = _8832;
    RefDS(_8833);
    *((int *)(_2+24)) = _8833;
    RefDS(_8834);
    *((int *)(_2+28)) = _8834;
    _8835 = MAKE_SEQ(_1);
    _8836 = find_from(_8827, _8835, 1);
    DeRef(_8827);
    _8827 = NOVALUE;
    DeRefDS(_8835);
    _8835 = NOVALUE;
    if (_8836 == 0)
    {
        _8836 = NOVALUE;
        goto L11; // [346] 357
    }
    else{
        _8836 = NOVALUE;
    }

    /** 			opt_param = 1*/
    DeRef(_opt_param_16031);
    _opt_param_16031 = 1;
    goto L12; // [354] 387
L11: 

    /** 		elsif find( text:lower(opt_param), {"0", "off", "no", "n", "false", "-"}) then*/
    Ref(_opt_param_16031);
    _8837 = _12lower(_opt_param_16031);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8838);
    *((int *)(_2+4)) = _8838;
    RefDS(_8839);
    *((int *)(_2+8)) = _8839;
    RefDS(_8840);
    *((int *)(_2+12)) = _8840;
    RefDS(_8841);
    *((int *)(_2+16)) = _8841;
    RefDS(_8842);
    *((int *)(_2+20)) = _8842;
    RefDS(_524);
    *((int *)(_2+24)) = _524;
    _8843 = MAKE_SEQ(_1);
    _8844 = find_from(_8837, _8843, 1);
    DeRef(_8837);
    _8837 = NOVALUE;
    DeRefDS(_8843);
    _8843 = NOVALUE;
    if (_8844 == 0)
    {
        _8844 = NOVALUE;
        goto L13; // [377] 386
    }
    else{
        _8844 = NOVALUE;
    }

    /** 			opt_param = 0*/
    DeRef(_opt_param_16031);
    _opt_param_16031 = 0;
L13: 
L12: 
L10: 

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_16027)){
            _8845 = SEQ_PTR(_opts_16027)->length;
    }
    else {
        _8845 = 1;
    }
    {
        int _i_16122;
        _i_16122 = 1;
L14: 
        if (_i_16122 > _8845){
            goto L15; // [393] 592
        }

        /** 		if find(NO_CASE,  opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_16027);
        _8846 = (int)*(((s1_ptr)_2)->base + _i_16122);
        _2 = (int)SEQ_PTR(_8846);
        _8847 = (int)*(((s1_ptr)_2)->base + 4);
        _8846 = NOVALUE;
        _8848 = find_from(105, _8847, 1);
        _8847 = NOVALUE;
        if (_8848 == 0)
        {
            _8848 = NOVALUE;
            goto L16; // [415] 455
        }
        else{
            _8848 = NOVALUE;
        }

        /** 			if not equal( text:lower(opt_name), text:lower(opts[i][opt_style[1]])) then*/
        RefDS(_opt_name_16030);
        _8849 = _12lower(_opt_name_16030);
        _2 = (int)SEQ_PTR(_opts_16027);
        _8850 = (int)*(((s1_ptr)_2)->base + _i_16122);
        _2 = (int)SEQ_PTR(_opt_style_16028);
        _8851 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_8850);
        if (!IS_ATOM_INT(_8851)){
            _8852 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_8851)->dbl));
        }
        else{
            _8852 = (int)*(((s1_ptr)_2)->base + _8851);
        }
        _8850 = NOVALUE;
        Ref(_8852);
        _8853 = _12lower(_8852);
        _8852 = NOVALUE;
        if (_8849 == _8853)
        _8854 = 1;
        else if (IS_ATOM_INT(_8849) && IS_ATOM_INT(_8853))
        _8854 = 0;
        else
        _8854 = (compare(_8849, _8853) == 0);
        DeRef(_8849);
        _8849 = NOVALUE;
        DeRef(_8853);
        _8853 = NOVALUE;
        if (_8854 != 0)
        goto L17; // [444] 482
        _8854 = NOVALUE;

        /** 				continue*/
        goto L18; // [449] 587
        goto L17; // [452] 482
L16: 

        /** 			if not equal(opt_name, opts[i][opt_style[1]]) then*/
        _2 = (int)SEQ_PTR(_opts_16027);
        _8856 = (int)*(((s1_ptr)_2)->base + _i_16122);
        _2 = (int)SEQ_PTR(_opt_style_16028);
        _8857 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_8856);
        if (!IS_ATOM_INT(_8857)){
            _8858 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_8857)->dbl));
        }
        else{
            _8858 = (int)*(((s1_ptr)_2)->base + _8857);
        }
        _8856 = NOVALUE;
        if (_opt_name_16030 == _8858)
        _8859 = 1;
        else if (IS_ATOM_INT(_opt_name_16030) && IS_ATOM_INT(_8858))
        _8859 = 0;
        else
        _8859 = (compare(_opt_name_16030, _8858) == 0);
        _8858 = NOVALUE;
        if (_8859 != 0)
        goto L19; // [473] 481
        _8859 = NOVALUE;

        /** 				continue*/
        goto L18; // [478] 587
L19: 
L17: 

        /** 		if find(HAS_PARAMETER,  opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_16027);
        _8861 = (int)*(((s1_ptr)_2)->base + _i_16122);
        _2 = (int)SEQ_PTR(_8861);
        _8862 = (int)*(((s1_ptr)_2)->base + 4);
        _8861 = NOVALUE;
        _8863 = find_from(112, _8862, 1);
        _8862 = NOVALUE;
        if (_8863 != 0)
        goto L1A; // [497] 518

        /** 			if param_found then*/
        if (_param_found_16032 == 0)
        {
            goto L1B; // [503] 517
        }
        else{
        }

        /** 				return {0, "Option should not have a parameter"}*/
        RefDS(_8865);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 0;
        ((int *)_2)[2] = _8865;
        _8866 = MAKE_SEQ(_1);
        DeRefDS(_opts_16027);
        DeRefDS(_opt_style_16028);
        DeRef(_cmd_text_16029);
        DeRef(_opt_name_16030);
        DeRef(_opt_param_16031);
        DeRef(_8787);
        _8787 = NOVALUE;
        DeRef(_8778);
        _8778 = NOVALUE;
        DeRef(_8799);
        _8799 = NOVALUE;
        DeRef(_8805);
        _8805 = NOVALUE;
        DeRef(_8807);
        _8807 = NOVALUE;
        DeRef(_8822);
        _8822 = NOVALUE;
        DeRef(_8813);
        _8813 = NOVALUE;
        _8857 = NOVALUE;
        _8851 = NOVALUE;
        return _8866;
L1B: 
L1A: 

        /** 		if param_found then*/
        if (_param_found_16032 == 0)
        {
            goto L1C; // [520] 539
        }
        else{
        }

        /** 			return {i, opt_name, reversed, opt_param}*/
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _i_16122;
        RefDS(_opt_name_16030);
        *((int *)(_2+8)) = _opt_name_16030;
        *((int *)(_2+12)) = _reversed_16033;
        Ref(_opt_param_16031);
        *((int *)(_2+16)) = _opt_param_16031;
        _8867 = MAKE_SEQ(_1);
        DeRefDS(_opts_16027);
        DeRefDS(_opt_style_16028);
        DeRef(_cmd_text_16029);
        DeRefDS(_opt_name_16030);
        DeRef(_opt_param_16031);
        DeRef(_8787);
        _8787 = NOVALUE;
        DeRef(_8778);
        _8778 = NOVALUE;
        DeRef(_8799);
        _8799 = NOVALUE;
        DeRef(_8805);
        _8805 = NOVALUE;
        DeRef(_8807);
        _8807 = NOVALUE;
        DeRef(_8822);
        _8822 = NOVALUE;
        DeRef(_8813);
        _8813 = NOVALUE;
        DeRef(_8866);
        _8866 = NOVALUE;
        _8857 = NOVALUE;
        _8851 = NOVALUE;
        return _8867;
        goto L1D; // [536] 585
L1C: 

        /** 			if find(HAS_PARAMETER, opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_16027);
        _8868 = (int)*(((s1_ptr)_2)->base + _i_16122);
        _2 = (int)SEQ_PTR(_8868);
        _8869 = (int)*(((s1_ptr)_2)->base + 4);
        _8868 = NOVALUE;
        _8870 = find_from(112, _8869, 1);
        _8869 = NOVALUE;
        if (_8870 != 0)
        goto L1E; // [554] 572

        /** 				return {i, opt_name, reversed, 1 }*/
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _i_16122;
        RefDS(_opt_name_16030);
        *((int *)(_2+8)) = _opt_name_16030;
        *((int *)(_2+12)) = _reversed_16033;
        *((int *)(_2+16)) = 1;
        _8872 = MAKE_SEQ(_1);
        DeRefDS(_opts_16027);
        DeRefDS(_opt_style_16028);
        DeRef(_cmd_text_16029);
        DeRefDS(_opt_name_16030);
        DeRef(_opt_param_16031);
        DeRef(_8787);
        _8787 = NOVALUE;
        DeRef(_8778);
        _8778 = NOVALUE;
        DeRef(_8799);
        _8799 = NOVALUE;
        DeRef(_8805);
        _8805 = NOVALUE;
        DeRef(_8807);
        _8807 = NOVALUE;
        DeRef(_8822);
        _8822 = NOVALUE;
        DeRef(_8813);
        _8813 = NOVALUE;
        DeRef(_8866);
        _8866 = NOVALUE;
        _8857 = NOVALUE;
        _8851 = NOVALUE;
        DeRef(_8867);
        _8867 = NOVALUE;
        return _8872;
L1E: 

        /** 			return {i, opt_name, reversed}*/
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _i_16122;
        RefDS(_opt_name_16030);
        *((int *)(_2+8)) = _opt_name_16030;
        *((int *)(_2+12)) = _reversed_16033;
        _8873 = MAKE_SEQ(_1);
        DeRefDS(_opts_16027);
        DeRefDS(_opt_style_16028);
        DeRef(_cmd_text_16029);
        DeRefDS(_opt_name_16030);
        DeRef(_opt_param_16031);
        DeRef(_8787);
        _8787 = NOVALUE;
        DeRef(_8778);
        _8778 = NOVALUE;
        DeRef(_8799);
        _8799 = NOVALUE;
        DeRef(_8805);
        _8805 = NOVALUE;
        DeRef(_8807);
        _8807 = NOVALUE;
        DeRef(_8822);
        _8822 = NOVALUE;
        DeRef(_8813);
        _8813 = NOVALUE;
        DeRef(_8866);
        _8866 = NOVALUE;
        _8857 = NOVALUE;
        _8851 = NOVALUE;
        DeRef(_8867);
        _8867 = NOVALUE;
        DeRef(_8872);
        _8872 = NOVALUE;
        return _8873;
L1D: 

        /** 	end for*/
L18: 
        _i_16122 = _i_16122 + 1;
        goto L14; // [587] 400
L15: 
        ;
    }

    /** 	return {0, "Unrecognised"}*/
    RefDS(_8874);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _8874;
    _8875 = MAKE_SEQ(_1);
    DeRefDS(_opts_16027);
    DeRefDS(_opt_style_16028);
    DeRef(_cmd_text_16029);
    DeRef(_opt_name_16030);
    DeRef(_opt_param_16031);
    DeRef(_8787);
    _8787 = NOVALUE;
    DeRef(_8778);
    _8778 = NOVALUE;
    DeRef(_8799);
    _8799 = NOVALUE;
    DeRef(_8805);
    _8805 = NOVALUE;
    DeRef(_8807);
    _8807 = NOVALUE;
    DeRef(_8822);
    _8822 = NOVALUE;
    DeRef(_8813);
    _8813 = NOVALUE;
    DeRef(_8866);
    _8866 = NOVALUE;
    _8857 = NOVALUE;
    _8851 = NOVALUE;
    DeRef(_8867);
    _8867 = NOVALUE;
    DeRef(_8872);
    _8872 = NOVALUE;
    DeRef(_8873);
    _8873 = NOVALUE;
    return _8875;
    ;
}


int _40cmd_parse(int _opts_16165, int _parse_options_16166, int _cmds_16167)
{
    int _arg_idx_16169 = NOVALUE;
    int _opts_done_16170 = NOVALUE;
    int _cmd_16171 = NOVALUE;
    int _param_16172 = NOVALUE;
    int _find_result_16173 = NOVALUE;
    int _type__16174 = NOVALUE;
    int _from__16175 = NOVALUE;
    int _help_opts_16176 = NOVALUE;
    int _call_count_16177 = NOVALUE;
    int _add_help_rid_16178 = NOVALUE;
    int _validation_16179 = NOVALUE;
    int _has_extra_16180 = NOVALUE;
    int _use_at_16181 = NOVALUE;
    int _auto_help_16182 = NOVALUE;
    int _help_on_error_16183 = NOVALUE;
    int _po_16184 = NOVALUE;
    int _msg_inlined_crash_at_107_16202 = NOVALUE;
    int _msg_inlined_crash_at_237_16219 = NOVALUE;
    int _msg_inlined_crash_at_275_16226 = NOVALUE;
    int _fmt_inlined_crash_at_272_16225 = NOVALUE;
    int _parsed_opts_16231 = NOVALUE;
    int _at_cmds_16278 = NOVALUE;
    int _j_16279 = NOVALUE;
    int _cmdex_16364 = NOVALUE;
    int _opt_16428 = NOVALUE;
    int _map_add_operation_16431 = NOVALUE;
    int _pos_16471 = NOVALUE;
    int _ver_pos_16518 = NOVALUE;
    int _msg_inlined_crash_at_2040_16536 = NOVALUE;
    int _fmt_inlined_crash_at_2037_16535 = NOVALUE;
    int _9158 = NOVALUE;
    int _9157 = NOVALUE;
    int _9156 = NOVALUE;
    int _9153 = NOVALUE;
    int _9152 = NOVALUE;
    int _9151 = NOVALUE;
    int _9148 = NOVALUE;
    int _9147 = NOVALUE;
    int _9146 = NOVALUE;
    int _9145 = NOVALUE;
    int _9144 = NOVALUE;
    int _9143 = NOVALUE;
    int _9142 = NOVALUE;
    int _9141 = NOVALUE;
    int _9140 = NOVALUE;
    int _9139 = NOVALUE;
    int _9138 = NOVALUE;
    int _9137 = NOVALUE;
    int _9136 = NOVALUE;
    int _9135 = NOVALUE;
    int _9134 = NOVALUE;
    int _9133 = NOVALUE;
    int _9130 = NOVALUE;
    int _9129 = NOVALUE;
    int _9128 = NOVALUE;
    int _9125 = NOVALUE;
    int _9124 = NOVALUE;
    int _9122 = NOVALUE;
    int _9121 = NOVALUE;
    int _9120 = NOVALUE;
    int _9119 = NOVALUE;
    int _9118 = NOVALUE;
    int _9117 = NOVALUE;
    int _9116 = NOVALUE;
    int _9115 = NOVALUE;
    int _9113 = NOVALUE;
    int _9112 = NOVALUE;
    int _9110 = NOVALUE;
    int _9109 = NOVALUE;
    int _9108 = NOVALUE;
    int _9107 = NOVALUE;
    int _9106 = NOVALUE;
    int _9105 = NOVALUE;
    int _9104 = NOVALUE;
    int _9103 = NOVALUE;
    int _9101 = NOVALUE;
    int _9100 = NOVALUE;
    int _9099 = NOVALUE;
    int _9097 = NOVALUE;
    int _9095 = NOVALUE;
    int _9094 = NOVALUE;
    int _9093 = NOVALUE;
    int _9092 = NOVALUE;
    int _9091 = NOVALUE;
    int _9090 = NOVALUE;
    int _9089 = NOVALUE;
    int _9088 = NOVALUE;
    int _9087 = NOVALUE;
    int _9084 = NOVALUE;
    int _9081 = NOVALUE;
    int _9080 = NOVALUE;
    int _9078 = NOVALUE;
    int _9077 = NOVALUE;
    int _9076 = NOVALUE;
    int _9075 = NOVALUE;
    int _9074 = NOVALUE;
    int _9073 = NOVALUE;
    int _9072 = NOVALUE;
    int _9070 = NOVALUE;
    int _9069 = NOVALUE;
    int _9068 = NOVALUE;
    int _9067 = NOVALUE;
    int _9064 = NOVALUE;
    int _9061 = NOVALUE;
    int _9059 = NOVALUE;
    int _9058 = NOVALUE;
    int _9056 = NOVALUE;
    int _9055 = NOVALUE;
    int _9054 = NOVALUE;
    int _9052 = NOVALUE;
    int _9051 = NOVALUE;
    int _9050 = NOVALUE;
    int _9048 = NOVALUE;
    int _9046 = NOVALUE;
    int _9044 = NOVALUE;
    int _9042 = NOVALUE;
    int _9041 = NOVALUE;
    int _9040 = NOVALUE;
    int _9039 = NOVALUE;
    int _9038 = NOVALUE;
    int _9034 = NOVALUE;
    int _9032 = NOVALUE;
    int _9031 = NOVALUE;
    int _9030 = NOVALUE;
    int _9029 = NOVALUE;
    int _9028 = NOVALUE;
    int _9027 = NOVALUE;
    int _9025 = NOVALUE;
    int _9024 = NOVALUE;
    int _9023 = NOVALUE;
    int _9022 = NOVALUE;
    int _9021 = NOVALUE;
    int _9020 = NOVALUE;
    int _9019 = NOVALUE;
    int _9015 = NOVALUE;
    int _9014 = NOVALUE;
    int _9011 = NOVALUE;
    int _9010 = NOVALUE;
    int _9009 = NOVALUE;
    int _9008 = NOVALUE;
    int _9007 = NOVALUE;
    int _9006 = NOVALUE;
    int _9005 = NOVALUE;
    int _9004 = NOVALUE;
    int _9003 = NOVALUE;
    int _9002 = NOVALUE;
    int _9001 = NOVALUE;
    int _9000 = NOVALUE;
    int _8999 = NOVALUE;
    int _8998 = NOVALUE;
    int _8997 = NOVALUE;
    int _8996 = NOVALUE;
    int _8995 = NOVALUE;
    int _8994 = NOVALUE;
    int _8993 = NOVALUE;
    int _8992 = NOVALUE;
    int _8991 = NOVALUE;
    int _8990 = NOVALUE;
    int _8989 = NOVALUE;
    int _8988 = NOVALUE;
    int _8987 = NOVALUE;
    int _8986 = NOVALUE;
    int _8985 = NOVALUE;
    int _8984 = NOVALUE;
    int _8983 = NOVALUE;
    int _8982 = NOVALUE;
    int _8981 = NOVALUE;
    int _8980 = NOVALUE;
    int _8977 = NOVALUE;
    int _8976 = NOVALUE;
    int _8975 = NOVALUE;
    int _8974 = NOVALUE;
    int _8973 = NOVALUE;
    int _8971 = NOVALUE;
    int _8970 = NOVALUE;
    int _8967 = NOVALUE;
    int _8966 = NOVALUE;
    int _8965 = NOVALUE;
    int _8964 = NOVALUE;
    int _8963 = NOVALUE;
    int _8961 = NOVALUE;
    int _8960 = NOVALUE;
    int _8959 = NOVALUE;
    int _8958 = NOVALUE;
    int _8955 = NOVALUE;
    int _8953 = NOVALUE;
    int _8952 = NOVALUE;
    int _8951 = NOVALUE;
    int _8949 = NOVALUE;
    int _8947 = NOVALUE;
    int _8946 = NOVALUE;
    int _8943 = NOVALUE;
    int _8941 = NOVALUE;
    int _8940 = NOVALUE;
    int _8939 = NOVALUE;
    int _8938 = NOVALUE;
    int _8937 = NOVALUE;
    int _8936 = NOVALUE;
    int _8935 = NOVALUE;
    int _8934 = NOVALUE;
    int _8933 = NOVALUE;
    int _8932 = NOVALUE;
    int _8930 = NOVALUE;
    int _8926 = NOVALUE;
    int _8924 = NOVALUE;
    int _8923 = NOVALUE;
    int _8922 = NOVALUE;
    int _8919 = NOVALUE;
    int _8918 = NOVALUE;
    int _8917 = NOVALUE;
    int _8915 = NOVALUE;
    int _8914 = NOVALUE;
    int _8913 = NOVALUE;
    int _8912 = NOVALUE;
    int _8911 = NOVALUE;
    int _8909 = NOVALUE;
    int _8908 = NOVALUE;
    int _8907 = NOVALUE;
    int _8906 = NOVALUE;
    int _8905 = NOVALUE;
    int _8904 = NOVALUE;
    int _8903 = NOVALUE;
    int _8902 = NOVALUE;
    int _8901 = NOVALUE;
    int _8898 = NOVALUE;
    int _8895 = NOVALUE;
    int _8894 = NOVALUE;
    int _8888 = NOVALUE;
    int _8884 = NOVALUE;
    int _8881 = NOVALUE;
    int _8879 = NOVALUE;
    int _8877 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object add_help_rid = -1*/
    DeRef(_add_help_rid_16178);
    _add_help_rid_16178 = -1;

    /** 	integer validation = VALIDATE_ALL*/
    _validation_16179 = 2;

    /** 	integer has_extra = 0*/
    _has_extra_16180 = 0;

    /** 	integer use_at = 1*/
    _use_at_16181 = 1;

    /** 	integer auto_help = 1*/
    _auto_help_16182 = 1;

    /** 	integer help_on_error = 1*/
    _help_on_error_16183 = 1;

    /** 	integer po = 1*/
    _po_16184 = 1;

    /** 	if atom(parse_options) then*/
    _8877 = 0;
    if (_8877 == 0)
    {
        _8877 = NOVALUE;
        goto L1; // [45] 55
    }
    else{
        _8877 = NOVALUE;
    }

    /** 		parse_options = {parse_options}*/
    _0 = _parse_options_16166;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_parse_options_16166);
    *((int *)(_2+4)) = _parse_options_16166;
    _parse_options_16166 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** 	while po <= length(parse_options) do*/
L2: 
    if (IS_SEQUENCE(_parse_options_16166)){
            _8879 = SEQ_PTR(_parse_options_16166)->length;
    }
    else {
        _8879 = 1;
    }
    if (_po_16184 > _8879)
    goto L3; // [63] 308

    /** 		switch parse_options[po] do*/
    _2 = (int)SEQ_PTR(_parse_options_16166);
    _8881 = (int)*(((s1_ptr)_2)->base + _po_16184);
    if (IS_SEQUENCE(_8881) ){
        goto L4; // [73] 261
    }
    if(!IS_ATOM_INT(_8881)){
        if( (DBL_PTR(_8881)->dbl != (double) ((int) DBL_PTR(_8881)->dbl) ) ){
            goto L4; // [73] 261
        }
        _0 = (int) DBL_PTR(_8881)->dbl;
    }
    else {
        _0 = _8881;
    };
    _8881 = NOVALUE;
    switch ( _0 ){ 

        /** 			case HELP_RID then*/
        case 1:

        /** 				if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_16166)){
                _8884 = SEQ_PTR(_parse_options_16166)->length;
        }
        else {
            _8884 = 1;
        }
        if (_po_16184 >= _8884)
        goto L5; // [87] 106

        /** 					po += 1*/
        _po_16184 = _po_16184 + 1;

        /** 					add_help_rid = parse_options[po]*/
        DeRef(_add_help_rid_16178);
        _2 = (int)SEQ_PTR(_parse_options_16166);
        _add_help_rid_16178 = (int)*(((s1_ptr)_2)->base + _po_16184);
        Ref(_add_help_rid_16178);
        goto L6; // [103] 297
L5: 

        /** 					error:crash("HELP_RID was given to cmd_parse with no routine_id")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_107_16202);
        _msg_inlined_crash_at_107_16202 = EPrintf(-9999999, _8596, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_107_16202);

        /** end procedure*/
        goto L7; // [121] 124
L7: 
        DeRefi(_msg_inlined_crash_at_107_16202);
        _msg_inlined_crash_at_107_16202 = NOVALUE;
        goto L6; // [127] 297

        /** 			case NO_HELP then*/
        case 9:

        /** 				auto_help = 0*/
        _auto_help_16182 = 0;
        goto L6; // [138] 297

        /** 			case NO_HELP_ON_ERROR then*/
        case 10:

        /** 				help_on_error = 0*/
        _help_on_error_16183 = 0;
        goto L6; // [149] 297

        /** 			case VALIDATE_ALL then*/
        case 2:

        /** 				validation = VALIDATE_ALL*/
        _validation_16179 = 2;
        goto L6; // [160] 297

        /** 			case NO_VALIDATION then*/
        case 3:

        /** 				validation = NO_VALIDATION*/
        _validation_16179 = 3;
        goto L6; // [171] 297

        /** 			case NO_VALIDATION_AFTER_FIRST_EXTRA then*/
        case 4:

        /** 				validation = NO_VALIDATION_AFTER_FIRST_EXTRA*/
        _validation_16179 = 4;
        goto L6; // [182] 297

        /** 			case NO_AT_EXPANSION then*/
        case 7:

        /** 				use_at = 0*/
        _use_at_16181 = 0;
        goto L6; // [193] 297

        /** 			case AT_EXPANSION then*/
        case 6:

        /** 				use_at = 1*/
        _use_at_16181 = 1;
        goto L6; // [204] 297

        /** 			case PAUSE_MSG then*/
        case 8:

        /** 				if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_16166)){
                _8888 = SEQ_PTR(_parse_options_16166)->length;
        }
        else {
            _8888 = 1;
        }
        if (_po_16184 >= _8888)
        goto L8; // [215] 236

        /** 					po += 1*/
        _po_16184 = _po_16184 + 1;

        /** 					pause_msg = parse_options[po]*/
        DeRef(_40pause_msg_15478);
        _2 = (int)SEQ_PTR(_parse_options_16166);
        _40pause_msg_15478 = (int)*(((s1_ptr)_2)->base + _po_16184);
        Ref(_40pause_msg_15478);
        goto L6; // [233] 297
L8: 

        /** 					error:crash("PAUSE_MSG was given to cmd_parse with no actually message text")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_237_16219);
        _msg_inlined_crash_at_237_16219 = EPrintf(-9999999, _8892, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_237_16219);

        /** end procedure*/
        goto L9; // [251] 254
L9: 
        DeRefi(_msg_inlined_crash_at_237_16219);
        _msg_inlined_crash_at_237_16219 = NOVALUE;
        goto L6; // [257] 297

        /** 			case else*/
        default:
L4: 

        /** 				error:crash(sprintf("Unrecognised cmdline PARSE OPTION - %d", parse_options[po]) )*/
        _2 = (int)SEQ_PTR(_parse_options_16166);
        _8894 = (int)*(((s1_ptr)_2)->base + _po_16184);
        _8895 = EPrintf(-9999999, _8893, _8894);
        _8894 = NOVALUE;
        DeRefi(_fmt_inlined_crash_at_272_16225);
        _fmt_inlined_crash_at_272_16225 = _8895;
        _8895 = NOVALUE;

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_275_16226);
        _msg_inlined_crash_at_275_16226 = EPrintf(-9999999, _fmt_inlined_crash_at_272_16225, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_275_16226);

        /** end procedure*/
        goto LA; // [291] 294
LA: 
        DeRefi(_fmt_inlined_crash_at_272_16225);
        _fmt_inlined_crash_at_272_16225 = NOVALUE;
        DeRefi(_msg_inlined_crash_at_275_16226);
        _msg_inlined_crash_at_275_16226 = NOVALUE;
    ;}L6: 

    /** 		po += 1*/
    _po_16184 = _po_16184 + 1;

    /** 	end while*/
    goto L2; // [305] 60
L3: 

    /** 	opts = standardize_opts(opts, auto_help)*/
    RefDS(_opts_16165);
    _0 = _opts_16165;
    _opts_16165 = _40standardize_opts(_opts_16165, _auto_help_16182);
    DeRefDS(_0);

    /** 	call_count = repeat(0, length(opts))*/
    if (IS_SEQUENCE(_opts_16165)){
            _8898 = SEQ_PTR(_opts_16165)->length;
    }
    else {
        _8898 = 1;
    }
    DeRef(_call_count_16177);
    _call_count_16177 = Repeat(0, _8898);
    _8898 = NOVALUE;

    /** 	map:map parsed_opts = map:new()*/
    _0 = _parsed_opts_16231;
    _parsed_opts_16231 = _32new(690);
    DeRef(_0);

    /** 	map:put(parsed_opts, EXTRAS, {})*/
    Ref(_parsed_opts_16231);
    RefDS(_40EXTRAS_15467);
    RefDS(_5);
    _32put(_parsed_opts_16231, _40EXTRAS_15467, _5, 1, 23);

    /** 	help_opts = {}*/
    RefDS(_5);
    DeRef(_help_opts_16176);
    _help_opts_16176 = _5;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_16165)){
            _8901 = SEQ_PTR(_opts_16165)->length;
    }
    else {
        _8901 = 1;
    }
    {
        int _i_16234;
        _i_16234 = 1;
LB: 
        if (_i_16234 > _8901){
            goto LC; // [357] 517
        }

        /** 		if find(HELP, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_16165);
        _8902 = (int)*(((s1_ptr)_2)->base + _i_16234);
        _2 = (int)SEQ_PTR(_8902);
        _8903 = (int)*(((s1_ptr)_2)->base + 4);
        _8902 = NOVALUE;
        _8904 = find_from(104, _8903, 1);
        _8903 = NOVALUE;
        if (_8904 == 0)
        {
            _8904 = NOVALUE;
            goto LD; // [379] 510
        }
        else{
            _8904 = NOVALUE;
        }

        /** 			if sequence(opts[i][SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_16165);
        _8905 = (int)*(((s1_ptr)_2)->base + _i_16234);
        _2 = (int)SEQ_PTR(_8905);
        _8906 = (int)*(((s1_ptr)_2)->base + 1);
        _8905 = NOVALUE;
        _8907 = IS_SEQUENCE(_8906);
        _8906 = NOVALUE;
        if (_8907 == 0)
        {
            _8907 = NOVALUE;
            goto LE; // [395] 413
        }
        else{
            _8907 = NOVALUE;
        }

        /** 				help_opts = append(help_opts, opts[i][SHORTNAME])*/
        _2 = (int)SEQ_PTR(_opts_16165);
        _8908 = (int)*(((s1_ptr)_2)->base + _i_16234);
        _2 = (int)SEQ_PTR(_8908);
        _8909 = (int)*(((s1_ptr)_2)->base + 1);
        _8908 = NOVALUE;
        Ref(_8909);
        Append(&_help_opts_16176, _help_opts_16176, _8909);
        _8909 = NOVALUE;
LE: 

        /** 			if sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_16165);
        _8911 = (int)*(((s1_ptr)_2)->base + _i_16234);
        _2 = (int)SEQ_PTR(_8911);
        _8912 = (int)*(((s1_ptr)_2)->base + 2);
        _8911 = NOVALUE;
        _8913 = IS_SEQUENCE(_8912);
        _8912 = NOVALUE;
        if (_8913 == 0)
        {
            _8913 = NOVALUE;
            goto LF; // [426] 444
        }
        else{
            _8913 = NOVALUE;
        }

        /** 				help_opts = append(help_opts, opts[i][LONGNAME])*/
        _2 = (int)SEQ_PTR(_opts_16165);
        _8914 = (int)*(((s1_ptr)_2)->base + _i_16234);
        _2 = (int)SEQ_PTR(_8914);
        _8915 = (int)*(((s1_ptr)_2)->base + 2);
        _8914 = NOVALUE;
        Ref(_8915);
        Append(&_help_opts_16176, _help_opts_16176, _8915);
        _8915 = NOVALUE;
LF: 

        /** 			if find(NO_CASE, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_16165);
        _8917 = (int)*(((s1_ptr)_2)->base + _i_16234);
        _2 = (int)SEQ_PTR(_8917);
        _8918 = (int)*(((s1_ptr)_2)->base + 4);
        _8917 = NOVALUE;
        _8919 = find_from(105, _8918, 1);
        _8918 = NOVALUE;
        if (_8919 == 0)
        {
            _8919 = NOVALUE;
            goto L10; // [459] 509
        }
        else{
            _8919 = NOVALUE;
        }

        /** 				help_opts = text:lower(help_opts)*/
        RefDS(_help_opts_16176);
        _0 = _help_opts_16176;
        _help_opts_16176 = _12lower(_help_opts_16176);
        DeRefDS(_0);

        /** 				arg_idx = length(help_opts)*/
        if (IS_SEQUENCE(_help_opts_16176)){
                _arg_idx_16169 = SEQ_PTR(_help_opts_16176)->length;
        }
        else {
            _arg_idx_16169 = 1;
        }

        /** 				for j = 1 to arg_idx do*/
        _8922 = _arg_idx_16169;
        {
            int _j_16261;
            _j_16261 = 1;
L11: 
            if (_j_16261 > _8922){
                goto L12; // [480] 508
            }

            /** 					help_opts = append( help_opts, text:upper(help_opts[j]) )*/
            _2 = (int)SEQ_PTR(_help_opts_16176);
            _8923 = (int)*(((s1_ptr)_2)->base + _j_16261);
            Ref(_8923);
            _8924 = _12upper(_8923);
            _8923 = NOVALUE;
            Ref(_8924);
            Append(&_help_opts_16176, _help_opts_16176, _8924);
            DeRef(_8924);
            _8924 = NOVALUE;

            /** 				end for*/
            _j_16261 = _j_16261 + 1;
            goto L11; // [503] 487
L12: 
            ;
        }
L10: 
LD: 

        /** 	end for*/
        _i_16234 = _i_16234 + 1;
        goto LB; // [512] 364
LC: 
        ;
    }

    /** 	arg_idx = 2*/
    _arg_idx_16169 = 2;

    /** 	opts_done = 0*/
    _opts_done_16170 = 0;

    /** 	while arg_idx < length(cmds) do*/
L13: 
    if (IS_SEQUENCE(_cmds_16167)){
            _8926 = SEQ_PTR(_cmds_16167)->length;
    }
    else {
        _8926 = 1;
    }
    if (_arg_idx_16169 >= _8926)
    goto L14; // [535] 2072

    /** 		arg_idx += 1*/
    _arg_idx_16169 = _arg_idx_16169 + 1;

    /** 		cmd = cmds[arg_idx]*/
    DeRef(_cmd_16171);
    _2 = (int)SEQ_PTR(_cmds_16167);
    _cmd_16171 = (int)*(((s1_ptr)_2)->base + _arg_idx_16169);
    Ref(_cmd_16171);

    /** 		if length(cmd) = 0 then*/
    if (IS_SEQUENCE(_cmd_16171)){
            _8930 = SEQ_PTR(_cmd_16171)->length;
    }
    else {
        _8930 = 1;
    }
    if (_8930 != 0)
    goto L15; // [558] 567

    /** 			continue*/
    goto L13; // [564] 532
L15: 

    /** 		if cmd[1] = '@' and use_at then*/
    _2 = (int)SEQ_PTR(_cmd_16171);
    _8932 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8932)) {
        _8933 = (_8932 == 64);
    }
    else {
        _8933 = binary_op(EQUALS, _8932, 64);
    }
    _8932 = NOVALUE;
    if (IS_ATOM_INT(_8933)) {
        if (_8933 == 0) {
            goto L16; // [577] 1095
        }
    }
    else {
        if (DBL_PTR(_8933)->dbl == 0.0) {
            goto L16; // [577] 1095
        }
    }
    if (_use_at_16181 == 0)
    {
        goto L16; // [582] 1095
    }
    else{
    }

    /** 			object at_cmds*/

    /** 			integer j*/

    /** 			if length(cmd) > 2 and cmd[2] = '@' then*/
    if (IS_SEQUENCE(_cmd_16171)){
            _8935 = SEQ_PTR(_cmd_16171)->length;
    }
    else {
        _8935 = 1;
    }
    _8936 = (_8935 > 2);
    _8935 = NOVALUE;
    if (_8936 == 0) {
        goto L17; // [598] 660
    }
    _2 = (int)SEQ_PTR(_cmd_16171);
    _8938 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_8938)) {
        _8939 = (_8938 == 64);
    }
    else {
        _8939 = binary_op(EQUALS, _8938, 64);
    }
    _8938 = NOVALUE;
    if (_8939 == 0) {
        DeRef(_8939);
        _8939 = NOVALUE;
        goto L17; // [611] 660
    }
    else {
        if (!IS_ATOM_INT(_8939) && DBL_PTR(_8939)->dbl == 0.0){
            DeRef(_8939);
            _8939 = NOVALUE;
            goto L17; // [611] 660
        }
        DeRef(_8939);
        _8939 = NOVALUE;
    }
    DeRef(_8939);
    _8939 = NOVALUE;

    /** 				at_cmds = io:read_lines(cmd[3..$])*/
    if (IS_SEQUENCE(_cmd_16171)){
            _8940 = SEQ_PTR(_cmd_16171)->length;
    }
    else {
        _8940 = 1;
    }
    rhs_slice_target = (object_ptr)&_8941;
    RHS_Slice(_cmd_16171, 3, _8940);
    _0 = _at_cmds_16278;
    _at_cmds_16278 = _18read_lines(_8941);
    DeRef(_0);
    _8941 = NOVALUE;

    /** 				if equal(at_cmds, -1) then*/
    if (_at_cmds_16278 == -1)
    _8943 = 1;
    else if (IS_ATOM_INT(_at_cmds_16278) && IS_ATOM_INT(-1))
    _8943 = 0;
    else
    _8943 = (compare(_at_cmds_16278, -1) == 0);
    if (_8943 == 0)
    {
        _8943 = NOVALUE;
        goto L18; // [634] 738
    }
    else{
        _8943 = NOVALUE;
    }

    /** 					cmds = eu:remove(cmds, arg_idx)*/
    {
        s1_ptr assign_space = SEQ_PTR(_cmds_16167);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_arg_idx_16169)) ? _arg_idx_16169 : (long)(DBL_PTR(_arg_idx_16169)->dbl);
        int stop = (IS_ATOM_INT(_arg_idx_16169)) ? _arg_idx_16169 : (long)(DBL_PTR(_arg_idx_16169)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_cmds_16167), start, &_cmds_16167 );
            }
            else Tail(SEQ_PTR(_cmds_16167), stop+1, &_cmds_16167);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_cmds_16167), start, &_cmds_16167);
        }
        else {
            assign_slice_seq = &assign_space;
            _cmds_16167 = Remove_elements(start, stop, (SEQ_PTR(_cmds_16167)->ref == 1));
        }
    }

    /** 					arg_idx -= 1*/
    _arg_idx_16169 = _arg_idx_16169 - 1;

    /** 					continue*/
    DeRef(_at_cmds_16278);
    _at_cmds_16278 = NOVALUE;
    goto L13; // [654] 532
    goto L18; // [657] 738
L17: 

    /** 				at_cmds = io:read_lines(cmd[2..$])*/
    if (IS_SEQUENCE(_cmd_16171)){
            _8946 = SEQ_PTR(_cmd_16171)->length;
    }
    else {
        _8946 = 1;
    }
    rhs_slice_target = (object_ptr)&_8947;
    RHS_Slice(_cmd_16171, 2, _8946);
    _0 = _at_cmds_16278;
    _at_cmds_16278 = _18read_lines(_8947);
    DeRef(_0);
    _8947 = NOVALUE;

    /** 				if equal(at_cmds, -1) then*/
    if (_at_cmds_16278 == -1)
    _8949 = 1;
    else if (IS_ATOM_INT(_at_cmds_16278) && IS_ATOM_INT(-1))
    _8949 = 0;
    else
    _8949 = (compare(_at_cmds_16278, -1) == 0);
    if (_8949 == 0)
    {
        _8949 = NOVALUE;
        goto L19; // [680] 737
    }
    else{
        _8949 = NOVALUE;
    }

    /** 					printf(2, "Cannot access '@' argument file '%s'\n", {cmd[2..$]})*/
    if (IS_SEQUENCE(_cmd_16171)){
            _8951 = SEQ_PTR(_cmd_16171)->length;
    }
    else {
        _8951 = 1;
    }
    rhs_slice_target = (object_ptr)&_8952;
    RHS_Slice(_cmd_16171, 2, _8951);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _8952;
    _8953 = MAKE_SEQ(_1);
    _8952 = NOVALUE;
    EPrintf(2, _8950, _8953);
    DeRefDS(_8953);
    _8953 = NOVALUE;

    /** 					if help_on_error then*/
    if (_help_on_error_16183 == 0)
    {
        goto L1A; // [703] 718
    }
    else{
    }

    /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_16165);
    Ref(_add_help_rid_16178);
    RefDS(_cmds_16167);
    Ref(_parse_options_16166);
    _40local_help(_opts_16165, _add_help_rid_16178, _cmds_16167, 1, _parse_options_16166);
    goto L1B; // [715] 731
L1A: 

    /** 					elsif auto_help then*/
    if (_auto_help_16182 == 0)
    {
        goto L1C; // [720] 730
    }
    else{
    }

    /** 						printf(2,"Try '--help' for more information.\n",{})*/
    EPrintf(2, _8954, _5);
L1C: 
L1B: 

    /** 					local_abort(1)*/
    _40local_abort(1);
L19: 
L18: 

    /** 			j = 0*/
    _j_16279 = 0;

    /** 			while j < length(at_cmds) do*/
L1D: 
    if (IS_SEQUENCE(_at_cmds_16278)){
            _8955 = SEQ_PTR(_at_cmds_16278)->length;
    }
    else {
        _8955 = 1;
    }
    if (_j_16279 >= _8955)
    goto L1E; // [753] 1074

    /** 				j += 1*/
    _j_16279 = _j_16279 + 1;

    /** 				at_cmds[j] = text:trim(at_cmds[j])*/
    _2 = (int)SEQ_PTR(_at_cmds_16278);
    _8958 = (int)*(((s1_ptr)_2)->base + _j_16279);
    Ref(_8958);
    RefDS(_4538);
    _8959 = _12trim(_8958, _4538, 0);
    _8958 = NOVALUE;
    _2 = (int)SEQ_PTR(_at_cmds_16278);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _at_cmds_16278 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _j_16279);
    _1 = *(int *)_2;
    *(int *)_2 = _8959;
    if( _1 != _8959 ){
        DeRef(_1);
    }
    _8959 = NOVALUE;

    /** 				if length(at_cmds[j]) = 0 then*/
    _2 = (int)SEQ_PTR(_at_cmds_16278);
    _8960 = (int)*(((s1_ptr)_2)->base + _j_16279);
    if (IS_SEQUENCE(_8960)){
            _8961 = SEQ_PTR(_8960)->length;
    }
    else {
        _8961 = 1;
    }
    _8960 = NOVALUE;
    if (_8961 != 0)
    goto L1F; // [788] 828

    /** 					at_cmds = at_cmds[1 .. j-1] & at_cmds[j+1 ..$]*/
    _8963 = _j_16279 - 1;
    rhs_slice_target = (object_ptr)&_8964;
    RHS_Slice(_at_cmds_16278, 1, _8963);
    _8965 = _j_16279 + 1;
    if (_8965 > MAXINT){
        _8965 = NewDouble((double)_8965);
    }
    if (IS_SEQUENCE(_at_cmds_16278)){
            _8966 = SEQ_PTR(_at_cmds_16278)->length;
    }
    else {
        _8966 = 1;
    }
    rhs_slice_target = (object_ptr)&_8967;
    RHS_Slice(_at_cmds_16278, _8965, _8966);
    Concat((object_ptr)&_at_cmds_16278, _8964, _8967);
    DeRefDS(_8964);
    _8964 = NOVALUE;
    DeRef(_8964);
    _8964 = NOVALUE;
    DeRefDS(_8967);
    _8967 = NOVALUE;

    /** 					j -= 1*/
    _j_16279 = _j_16279 - 1;
    goto L1D; // [825] 748
L1F: 

    /** 				elsif at_cmds[j][1] = '#' then*/
    _2 = (int)SEQ_PTR(_at_cmds_16278);
    _8970 = (int)*(((s1_ptr)_2)->base + _j_16279);
    _2 = (int)SEQ_PTR(_8970);
    _8971 = (int)*(((s1_ptr)_2)->base + 1);
    _8970 = NOVALUE;
    if (binary_op_a(NOTEQ, _8971, 35)){
        _8971 = NOVALUE;
        goto L20; // [838] 878
    }
    _8971 = NOVALUE;

    /** 					at_cmds = at_cmds[1 .. j-1] & at_cmds[j+1 ..$]*/
    _8973 = _j_16279 - 1;
    rhs_slice_target = (object_ptr)&_8974;
    RHS_Slice(_at_cmds_16278, 1, _8973);
    _8975 = _j_16279 + 1;
    if (_8975 > MAXINT){
        _8975 = NewDouble((double)_8975);
    }
    if (IS_SEQUENCE(_at_cmds_16278)){
            _8976 = SEQ_PTR(_at_cmds_16278)->length;
    }
    else {
        _8976 = 1;
    }
    rhs_slice_target = (object_ptr)&_8977;
    RHS_Slice(_at_cmds_16278, _8975, _8976);
    Concat((object_ptr)&_at_cmds_16278, _8974, _8977);
    DeRefDS(_8974);
    _8974 = NOVALUE;
    DeRef(_8974);
    _8974 = NOVALUE;
    DeRefDS(_8977);
    _8977 = NOVALUE;

    /** 					j -= 1*/
    _j_16279 = _j_16279 - 1;
    goto L1D; // [875] 748
L20: 

    /** 				elsif at_cmds[j][1] = '"' and at_cmds[j][$] = '"' and length(at_cmds[j]) >= 2 then*/
    _2 = (int)SEQ_PTR(_at_cmds_16278);
    _8980 = (int)*(((s1_ptr)_2)->base + _j_16279);
    _2 = (int)SEQ_PTR(_8980);
    _8981 = (int)*(((s1_ptr)_2)->base + 1);
    _8980 = NOVALUE;
    if (IS_ATOM_INT(_8981)) {
        _8982 = (_8981 == 34);
    }
    else {
        _8982 = binary_op(EQUALS, _8981, 34);
    }
    _8981 = NOVALUE;
    if (IS_ATOM_INT(_8982)) {
        if (_8982 == 0) {
            DeRef(_8983);
            _8983 = 0;
            goto L21; // [892] 915
        }
    }
    else {
        if (DBL_PTR(_8982)->dbl == 0.0) {
            DeRef(_8983);
            _8983 = 0;
            goto L21; // [892] 915
        }
    }
    _2 = (int)SEQ_PTR(_at_cmds_16278);
    _8984 = (int)*(((s1_ptr)_2)->base + _j_16279);
    if (IS_SEQUENCE(_8984)){
            _8985 = SEQ_PTR(_8984)->length;
    }
    else {
        _8985 = 1;
    }
    _2 = (int)SEQ_PTR(_8984);
    _8986 = (int)*(((s1_ptr)_2)->base + _8985);
    _8984 = NOVALUE;
    if (IS_ATOM_INT(_8986)) {
        _8987 = (_8986 == 34);
    }
    else {
        _8987 = binary_op(EQUALS, _8986, 34);
    }
    _8986 = NOVALUE;
    DeRef(_8983);
    if (IS_ATOM_INT(_8987))
    _8983 = (_8987 != 0);
    else
    _8983 = DBL_PTR(_8987)->dbl != 0.0;
L21: 
    if (_8983 == 0) {
        goto L22; // [915] 959
    }
    _2 = (int)SEQ_PTR(_at_cmds_16278);
    _8989 = (int)*(((s1_ptr)_2)->base + _j_16279);
    if (IS_SEQUENCE(_8989)){
            _8990 = SEQ_PTR(_8989)->length;
    }
    else {
        _8990 = 1;
    }
    _8989 = NOVALUE;
    _8991 = (_8990 >= 2);
    _8990 = NOVALUE;
    if (_8991 == 0)
    {
        DeRef(_8991);
        _8991 = NOVALUE;
        goto L22; // [931] 959
    }
    else{
        DeRef(_8991);
        _8991 = NOVALUE;
    }

    /** 					at_cmds[j] = at_cmds[j][2 .. $-1]*/
    _2 = (int)SEQ_PTR(_at_cmds_16278);
    _8992 = (int)*(((s1_ptr)_2)->base + _j_16279);
    if (IS_SEQUENCE(_8992)){
            _8993 = SEQ_PTR(_8992)->length;
    }
    else {
        _8993 = 1;
    }
    _8994 = _8993 - 1;
    _8993 = NOVALUE;
    rhs_slice_target = (object_ptr)&_8995;
    RHS_Slice(_8992, 2, _8994);
    _8992 = NOVALUE;
    _2 = (int)SEQ_PTR(_at_cmds_16278);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _at_cmds_16278 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _j_16279);
    _1 = *(int *)_2;
    *(int *)_2 = _8995;
    if( _1 != _8995 ){
        DeRef(_1);
    }
    _8995 = NOVALUE;
    goto L1D; // [956] 748
L22: 

    /** 				elsif at_cmds[j][1] = '\'' and at_cmds[j][$] = '\'' and length(at_cmds[j]) >= 2 then*/
    _2 = (int)SEQ_PTR(_at_cmds_16278);
    _8996 = (int)*(((s1_ptr)_2)->base + _j_16279);
    _2 = (int)SEQ_PTR(_8996);
    _8997 = (int)*(((s1_ptr)_2)->base + 1);
    _8996 = NOVALUE;
    if (IS_ATOM_INT(_8997)) {
        _8998 = (_8997 == 39);
    }
    else {
        _8998 = binary_op(EQUALS, _8997, 39);
    }
    _8997 = NOVALUE;
    if (IS_ATOM_INT(_8998)) {
        if (_8998 == 0) {
            DeRef(_8999);
            _8999 = 0;
            goto L23; // [973] 996
        }
    }
    else {
        if (DBL_PTR(_8998)->dbl == 0.0) {
            DeRef(_8999);
            _8999 = 0;
            goto L23; // [973] 996
        }
    }
    _2 = (int)SEQ_PTR(_at_cmds_16278);
    _9000 = (int)*(((s1_ptr)_2)->base + _j_16279);
    if (IS_SEQUENCE(_9000)){
            _9001 = SEQ_PTR(_9000)->length;
    }
    else {
        _9001 = 1;
    }
    _2 = (int)SEQ_PTR(_9000);
    _9002 = (int)*(((s1_ptr)_2)->base + _9001);
    _9000 = NOVALUE;
    if (IS_ATOM_INT(_9002)) {
        _9003 = (_9002 == 39);
    }
    else {
        _9003 = binary_op(EQUALS, _9002, 39);
    }
    _9002 = NOVALUE;
    DeRef(_8999);
    if (IS_ATOM_INT(_9003))
    _8999 = (_9003 != 0);
    else
    _8999 = DBL_PTR(_9003)->dbl != 0.0;
L23: 
    if (_8999 == 0) {
        goto L24; // [996] 1066
    }
    _2 = (int)SEQ_PTR(_at_cmds_16278);
    _9005 = (int)*(((s1_ptr)_2)->base + _j_16279);
    if (IS_SEQUENCE(_9005)){
            _9006 = SEQ_PTR(_9005)->length;
    }
    else {
        _9006 = 1;
    }
    _9005 = NOVALUE;
    _9007 = (_9006 >= 2);
    _9006 = NOVALUE;
    if (_9007 == 0)
    {
        DeRef(_9007);
        _9007 = NOVALUE;
        goto L24; // [1012] 1066
    }
    else{
        DeRef(_9007);
        _9007 = NOVALUE;
    }

    /** 					sequence cmdex = stdseq:split(at_cmds[j][2 .. $-1],' ', 1) -- Empty words removed.*/
    _2 = (int)SEQ_PTR(_at_cmds_16278);
    _9008 = (int)*(((s1_ptr)_2)->base + _j_16279);
    if (IS_SEQUENCE(_9008)){
            _9009 = SEQ_PTR(_9008)->length;
    }
    else {
        _9009 = 1;
    }
    _9010 = _9009 - 1;
    _9009 = NOVALUE;
    rhs_slice_target = (object_ptr)&_9011;
    RHS_Slice(_9008, 2, _9010);
    _9008 = NOVALUE;
    _0 = _cmdex_16364;
    _cmdex_16364 = _23split(_9011, 32, 1, 0);
    DeRef(_0);
    _9011 = NOVALUE;

    /** 					at_cmds = replace(at_cmds, cmdex, j)*/
    {
        int p1 = _at_cmds_16278;
        int p2 = _cmdex_16364;
        int p3 = _j_16279;
        int p4 = _j_16279;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_at_cmds_16278;
        Replace( &replace_params );
    }

    /** 					j = j + length(cmdex) - 1*/
    if (IS_SEQUENCE(_cmdex_16364)){
            _9014 = SEQ_PTR(_cmdex_16364)->length;
    }
    else {
        _9014 = 1;
    }
    _9015 = _j_16279 + _9014;
    if ((long)((unsigned long)_9015 + (unsigned long)HIGH_BITS) >= 0) 
    _9015 = NewDouble((double)_9015);
    _9014 = NOVALUE;
    if (IS_ATOM_INT(_9015)) {
        _j_16279 = _9015 - 1;
    }
    else {
        _j_16279 = NewDouble(DBL_PTR(_9015)->dbl - (double)1);
    }
    DeRef(_9015);
    _9015 = NOVALUE;
    if (!IS_ATOM_INT(_j_16279)) {
        _1 = (long)(DBL_PTR(_j_16279)->dbl);
        DeRefDS(_j_16279);
        _j_16279 = _1;
    }
L24: 
    DeRef(_cmdex_16364);
    _cmdex_16364 = NOVALUE;

    /** 			end while*/
    goto L1D; // [1071] 748
L1E: 

    /** 			cmds = replace(cmds, at_cmds, arg_idx)*/
    {
        int p1 = _cmds_16167;
        int p2 = _at_cmds_16278;
        int p3 = _arg_idx_16169;
        int p4 = _arg_idx_16169;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_cmds_16167;
        Replace( &replace_params );
    }

    /** 			arg_idx -= 1*/
    _arg_idx_16169 = _arg_idx_16169 - 1;

    /** 			continue*/
    DeRef(_at_cmds_16278);
    _at_cmds_16278 = NOVALUE;
    goto L13; // [1092] 532
L16: 
    DeRef(_at_cmds_16278);
    _at_cmds_16278 = NOVALUE;

    /** 		if (opts_done or find(cmd[1], os:CMD_SWITCHES) = 0 or length(cmd) = 1)*/
    if (_opts_done_16170 != 0) {
        _9019 = 1;
        goto L25; // [1099] 1120
    }
    _2 = (int)SEQ_PTR(_cmd_16171);
    _9020 = (int)*(((s1_ptr)_2)->base + 1);
    _9021 = find_from(_9020, _3CMD_SWITCHES_1358, 1);
    _9020 = NOVALUE;
    _9022 = (_9021 == 0);
    _9021 = NOVALUE;
    _9019 = (_9022 != 0);
L25: 
    if (_9019 != 0) {
        DeRef(_9023);
        _9023 = 1;
        goto L26; // [1120] 1135
    }
    if (IS_SEQUENCE(_cmd_16171)){
            _9024 = SEQ_PTR(_cmd_16171)->length;
    }
    else {
        _9024 = 1;
    }
    _9025 = (_9024 == 1);
    _9024 = NOVALUE;
    _9023 = (_9025 != 0);
L26: 
    if (_9023 == 0)
    {
        _9023 = NOVALUE;
        goto L27; // [1135] 1215
    }
    else{
        _9023 = NOVALUE;
    }

    /** 			map:put(parsed_opts, EXTRAS, cmd, map:APPEND)*/
    Ref(_parsed_opts_16231);
    RefDS(_40EXTRAS_15467);
    RefDS(_cmd_16171);
    _32put(_parsed_opts_16231, _40EXTRAS_15467, _cmd_16171, 6, 23);

    /** 			has_extra = 1*/
    _has_extra_16180 = 1;

    /** 			if validation = NO_VALIDATION_AFTER_FIRST_EXTRA then*/
    if (_validation_16179 != 4)
    goto L13; // [1158] 532

    /** 				for i = arg_idx + 1 to length(cmds) do*/
    _9027 = _arg_idx_16169 + 1;
    if (_9027 > MAXINT){
        _9027 = NewDouble((double)_9027);
    }
    if (IS_SEQUENCE(_cmds_16167)){
            _9028 = SEQ_PTR(_cmds_16167)->length;
    }
    else {
        _9028 = 1;
    }
    {
        int _i_16387;
        Ref(_9027);
        _i_16387 = _9027;
L28: 
        if (binary_op_a(GREATER, _i_16387, _9028)){
            goto L29; // [1171] 1202
        }

        /** 					map:put(parsed_opts, EXTRAS, cmds[i], map:APPEND)*/
        _2 = (int)SEQ_PTR(_cmds_16167);
        if (!IS_ATOM_INT(_i_16387)){
            _9029 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_16387)->dbl));
        }
        else{
            _9029 = (int)*(((s1_ptr)_2)->base + _i_16387);
        }
        Ref(_parsed_opts_16231);
        RefDS(_40EXTRAS_15467);
        Ref(_9029);
        _32put(_parsed_opts_16231, _40EXTRAS_15467, _9029, 6, 23);
        _9029 = NOVALUE;

        /** 				end for*/
        _0 = _i_16387;
        if (IS_ATOM_INT(_i_16387)) {
            _i_16387 = _i_16387 + 1;
            if ((long)((unsigned long)_i_16387 +(unsigned long) HIGH_BITS) >= 0){
                _i_16387 = NewDouble((double)_i_16387);
            }
        }
        else {
            _i_16387 = binary_op_a(PLUS, _i_16387, 1);
        }
        DeRef(_0);
        goto L28; // [1197] 1178
L29: 
        ;
        DeRef(_i_16387);
    }

    /** 				exit*/
    goto L14; // [1204] 2072
    goto L2A; // [1206] 1214

    /** 				continue*/
    goto L13; // [1211] 532
L2A: 
L27: 

    /** 		if equal(cmd, "--") then*/
    if (_cmd_16171 == _7692)
    _9030 = 1;
    else if (IS_ATOM_INT(_cmd_16171) && IS_ATOM_INT(_7692))
    _9030 = 0;
    else
    _9030 = (compare(_cmd_16171, _7692) == 0);
    if (_9030 == 0)
    {
        _9030 = NOVALUE;
        goto L2B; // [1221] 1234
    }
    else{
        _9030 = NOVALUE;
    }

    /** 			opts_done = 1*/
    _opts_done_16170 = 1;

    /** 			continue*/
    goto L13; // [1231] 532
L2B: 

    /** 		if equal(cmd[1..2], "--") then	  -- found --opt-name*/
    rhs_slice_target = (object_ptr)&_9031;
    RHS_Slice(_cmd_16171, 1, 2);
    if (_9031 == _7692)
    _9032 = 1;
    else if (IS_ATOM_INT(_9031) && IS_ATOM_INT(_7692))
    _9032 = 0;
    else
    _9032 = (compare(_9031, _7692) == 0);
    DeRefDS(_9031);
    _9031 = NOVALUE;
    if (_9032 == 0)
    {
        _9032 = NOVALUE;
        goto L2C; // [1245] 1262
    }
    else{
        _9032 = NOVALUE;
    }

    /** 			type_ = {LONGNAME, "--"}*/
    RefDS(_7692);
    DeRef(_type__16174);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 2;
    ((int *)_2)[2] = _7692;
    _type__16174 = MAKE_SEQ(_1);

    /** 			from_ = 3*/
    _from__16175 = 3;
    goto L2D; // [1259] 1298
L2C: 

    /** 		elsif cmd[1] = '-' then -- found -opt*/
    _2 = (int)SEQ_PTR(_cmd_16171);
    _9034 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _9034, 45)){
        _9034 = NOVALUE;
        goto L2E; // [1268] 1286
    }
    _9034 = NOVALUE;

    /** 			type_ = {SHORTNAME, "-"}*/
    RefDS(_524);
    DeRef(_type__16174);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _524;
    _type__16174 = MAKE_SEQ(_1);

    /** 			from_ = 2*/
    _from__16175 = 2;
    goto L2D; // [1283] 1298
L2E: 

    /** 			type_ = {SHORTNAME, "/"}*/
    RefDS(_3781);
    DeRef(_type__16174);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _3781;
    _type__16174 = MAKE_SEQ(_1);

    /** 			from_ = 2*/
    _from__16175 = 2;
L2D: 

    /** 		if find(cmd[from_..$], help_opts) then*/
    if (IS_SEQUENCE(_cmd_16171)){
            _9038 = SEQ_PTR(_cmd_16171)->length;
    }
    else {
        _9038 = 1;
    }
    rhs_slice_target = (object_ptr)&_9039;
    RHS_Slice(_cmd_16171, _from__16175, _9038);
    _9040 = find_from(_9039, _help_opts_16176, 1);
    DeRefDS(_9039);
    _9039 = NOVALUE;
    if (_9040 == 0)
    {
        _9040 = NOVALUE;
        goto L2F; // [1315] 1335
    }
    else{
        _9040 = NOVALUE;
    }

    /** 				local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_16165);
    Ref(_add_help_rid_16178);
    RefDS(_cmds_16167);
    Ref(_parse_options_16166);
    _40local_help(_opts_16165, _add_help_rid_16178, _cmds_16167, 1, _parse_options_16166);

    /** 			ifdef UNITTEST then*/

    /** 			local_abort(0)*/
    _40local_abort(0);
L2F: 

    /** 		find_result = find_opt(opts, type_, cmd[from_..$])*/
    if (IS_SEQUENCE(_cmd_16171)){
            _9041 = SEQ_PTR(_cmd_16171)->length;
    }
    else {
        _9041 = 1;
    }
    rhs_slice_target = (object_ptr)&_9042;
    RHS_Slice(_cmd_16171, _from__16175, _9041);
    RefDS(_opts_16165);
    RefDS(_type__16174);
    _0 = _find_result_16173;
    _find_result_16173 = _40find_opt(_opts_16165, _type__16174, _9042);
    DeRef(_0);
    _9042 = NOVALUE;

    /** 		if find_result[1] < 0 then*/
    _2 = (int)SEQ_PTR(_find_result_16173);
    _9044 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _9044, 0)){
        _9044 = NOVALUE;
        goto L30; // [1361] 1370
    }
    _9044 = NOVALUE;

    /** 			continue -- Couldn't use this command argument for anything.*/
    goto L13; // [1367] 532
L30: 

    /** 		if find_result[1] = 0 then*/
    _2 = (int)SEQ_PTR(_find_result_16173);
    _9046 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _9046, 0)){
        _9046 = NOVALUE;
        goto L31; // [1376] 1471
    }
    _9046 = NOVALUE;

    /** 			if validation = VALIDATE_ALL or*/
    _9048 = (_validation_16179 == 2);
    if (_9048 != 0) {
        goto L32; // [1386] 1411
    }
    _9050 = (_validation_16179 == 4);
    if (_9050 == 0) {
        DeRef(_9051);
        _9051 = 0;
        goto L33; // [1394] 1406
    }
    _9052 = (_has_extra_16180 == 0);
    _9051 = (_9052 != 0);
L33: 
    if (_9051 == 0)
    {
        _9051 = NOVALUE;
        goto L13; // [1407] 532
    }
    else{
        _9051 = NOVALUE;
    }
L32: 

    /** 				printf(1, "option '%s': %s\n", {cmd, find_result[2]})*/
    _2 = (int)SEQ_PTR(_find_result_16173);
    _9054 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_9054);
    RefDS(_cmd_16171);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _cmd_16171;
    ((int *)_2)[2] = _9054;
    _9055 = MAKE_SEQ(_1);
    _9054 = NOVALUE;
    EPrintf(1, _9053, _9055);
    DeRefDS(_9055);
    _9055 = NOVALUE;

    /** 				if help_on_error then*/
    if (_help_on_error_16183 == 0)
    {
        goto L34; // [1427] 1447
    }
    else{
    }

    /** 					puts(2,10)*/
    EPuts(2, 10); // DJP 

    /** 					local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_16165);
    Ref(_add_help_rid_16178);
    RefDS(_cmds_16167);
    Ref(_parse_options_16166);
    _40local_help(_opts_16165, _add_help_rid_16178, _cmds_16167, 1, _parse_options_16166);
    goto L35; // [1444] 1460
L34: 

    /** 				elsif auto_help then*/
    if (_auto_help_16182 == 0)
    {
        goto L36; // [1449] 1459
    }
    else{
    }

    /** 					printf(2,"Try '--help' for more information.\n",{})               */
    EPrintf(2, _8954, _5);
L36: 
L35: 

    /** 				local_abort(1)*/
    _40local_abort(1);

    /** 			continue*/
    goto L13; // [1468] 532
L31: 

    /** 		sequence opt = opts[find_result[1]]*/
    _2 = (int)SEQ_PTR(_find_result_16173);
    _9056 = (int)*(((s1_ptr)_2)->base + 1);
    DeRef(_opt_16428);
    _2 = (int)SEQ_PTR(_opts_16165);
    if (!IS_ATOM_INT(_9056)){
        _opt_16428 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_9056)->dbl));
    }
    else{
        _opt_16428 = (int)*(((s1_ptr)_2)->base + _9056);
    }
    Ref(_opt_16428);

    /** 		integer map_add_operation = map:ADD*/
    _map_add_operation_16431 = 2;

    /** 		if find(HAS_PARAMETER, opt[OPTIONS]) != 0 then*/
    _2 = (int)SEQ_PTR(_opt_16428);
    _9058 = (int)*(((s1_ptr)_2)->base + 4);
    _9059 = find_from(112, _9058, 1);
    _9058 = NOVALUE;
    if (_9059 == 0)
    goto L37; // [1499] 1677

    /** 			map_add_operation = map:APPEND*/
    _map_add_operation_16431 = 6;

    /** 			if length(find_result) < 4 then*/
    if (IS_SEQUENCE(_find_result_16173)){
            _9061 = SEQ_PTR(_find_result_16173)->length;
    }
    else {
        _9061 = 1;
    }
    if (_9061 >= 4)
    goto L38; // [1513] 1667

    /** 				arg_idx += 1*/
    _arg_idx_16169 = _arg_idx_16169 + 1;

    /** 				if arg_idx <= length(cmds) then*/
    if (IS_SEQUENCE(_cmds_16167)){
            _9064 = SEQ_PTR(_cmds_16167)->length;
    }
    else {
        _9064 = 1;
    }
    if (_arg_idx_16169 > _9064)
    goto L39; // [1528] 1573

    /** 					param = cmds[arg_idx]*/
    DeRef(_param_16172);
    _2 = (int)SEQ_PTR(_cmds_16167);
    _param_16172 = (int)*(((s1_ptr)_2)->base + _arg_idx_16169);
    Ref(_param_16172);

    /** 					if length(param) = 2 and find(param[1], "-/") then*/
    if (IS_SEQUENCE(_param_16172)){
            _9067 = SEQ_PTR(_param_16172)->length;
    }
    else {
        _9067 = 1;
    }
    _9068 = (_9067 == 2);
    _9067 = NOVALUE;
    if (_9068 == 0) {
        goto L3A; // [1547] 1579
    }
    _2 = (int)SEQ_PTR(_param_16172);
    _9070 = (int)*(((s1_ptr)_2)->base + 1);
    _9072 = find_from(_9070, _9071, 1);
    _9070 = NOVALUE;
    if (_9072 == 0)
    {
        _9072 = NOVALUE;
        goto L3A; // [1561] 1579
    }
    else{
        _9072 = NOVALUE;
    }

    /** 						param = ""*/
    RefDS(_5);
    DeRef(_param_16172);
    _param_16172 = _5;
    goto L3A; // [1570] 1579
L39: 

    /** 					param = ""*/
    RefDS(_5);
    DeRef(_param_16172);
    _param_16172 = _5;
L3A: 

    /** 				if length(param) = 0 and (validation = VALIDATE_ALL or (*/
    if (IS_SEQUENCE(_param_16172)){
            _9073 = SEQ_PTR(_param_16172)->length;
    }
    else {
        _9073 = 1;
    }
    _9074 = (_9073 == 0);
    _9073 = NOVALUE;
    if (_9074 == 0) {
        goto L3B; // [1590] 1684
    }
    _9076 = (_validation_16179 == 2);
    if (_9076 != 0) {
        DeRef(_9077);
        _9077 = 1;
        goto L3C; // [1598] 1610
    }
    _9078 = (_validation_16179 == 4);
    _9077 = (_9078 != 0);
L3C: 
    if (_9077 == 0)
    {
        _9077 = NOVALUE;
        goto L3B; // [1611] 1684
    }
    else{
        _9077 = NOVALUE;
    }

    /** 					printf(1, "option '%s' must have a parameter\n", {find_result[2]})*/
    _2 = (int)SEQ_PTR(_find_result_16173);
    _9080 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_9080);
    *((int *)(_2+4)) = _9080;
    _9081 = MAKE_SEQ(_1);
    _9080 = NOVALUE;
    EPrintf(1, _9079, _9081);
    DeRefDS(_9081);
    _9081 = NOVALUE;

    /** 					if help_on_error then*/
    if (_help_on_error_16183 == 0)
    {
        goto L3D; // [1630] 1645
    }
    else{
    }

    /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_16165);
    Ref(_add_help_rid_16178);
    RefDS(_cmds_16167);
    Ref(_parse_options_16166);
    _40local_help(_opts_16165, _add_help_rid_16178, _cmds_16167, 1, _parse_options_16166);
    goto L3E; // [1642] 1658
L3D: 

    /** 					elsif auto_help then*/
    if (_auto_help_16182 == 0)
    {
        goto L3F; // [1647] 1657
    }
    else{
    }

    /** 						printf(2,"Try '--help' for more information.\n",{})          */
    EPrintf(2, _8954, _5);
L3F: 
L3E: 

    /** 					local_abort(1)*/
    _40local_abort(1);
    goto L3B; // [1664] 1684
L38: 

    /** 				param = find_result[4]*/
    DeRef(_param_16172);
    _2 = (int)SEQ_PTR(_find_result_16173);
    _param_16172 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_param_16172);
    goto L3B; // [1674] 1684
L37: 

    /** 			param = find_result[4]*/
    DeRef(_param_16172);
    _2 = (int)SEQ_PTR(_find_result_16173);
    _param_16172 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_param_16172);
L3B: 

    /** 		if opt[CALLBACK] >= 0 then*/
    _2 = (int)SEQ_PTR(_opt_16428);
    _9084 = (int)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(LESS, _9084, 0)){
        _9084 = NOVALUE;
        goto L40; // [1690] 1763
    }
    _9084 = NOVALUE;

    /** 			integer pos = find_result[1]*/
    _2 = (int)SEQ_PTR(_find_result_16173);
    _pos_16471 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_pos_16471))
    _pos_16471 = (long)DBL_PTR(_pos_16471)->dbl;

    /** 			call_count[pos] += 1*/
    _2 = (int)SEQ_PTR(_call_count_16177);
    _9087 = (int)*(((s1_ptr)_2)->base + _pos_16471);
    if (IS_ATOM_INT(_9087)) {
        _9088 = _9087 + 1;
        if (_9088 > MAXINT){
            _9088 = NewDouble((double)_9088);
        }
    }
    else
    _9088 = binary_op(PLUS, 1, _9087);
    _9087 = NOVALUE;
    _2 = (int)SEQ_PTR(_call_count_16177);
    _2 = (int)(((s1_ptr)_2)->base + _pos_16471);
    _1 = *(int *)_2;
    *(int *)_2 = _9088;
    if( _1 != _9088 ){
        DeRef(_1);
    }
    _9088 = NOVALUE;

    /** 			if call_func(opt[CALLBACK], {{find_result[1], call_count[pos], param,  find_result[3]}}) = 0 then*/
    _2 = (int)SEQ_PTR(_opt_16428);
    _9089 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_find_result_16173);
    _9090 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_call_count_16177);
    _9091 = (int)*(((s1_ptr)_2)->base + _pos_16471);
    _2 = (int)SEQ_PTR(_find_result_16173);
    _9092 = (int)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_9090);
    *((int *)(_2+4)) = _9090;
    Ref(_9091);
    *((int *)(_2+8)) = _9091;
    Ref(_param_16172);
    *((int *)(_2+12)) = _param_16172;
    Ref(_9092);
    *((int *)(_2+16)) = _9092;
    _9093 = MAKE_SEQ(_1);
    _9092 = NOVALUE;
    _9091 = NOVALUE;
    _9090 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _9093;
    _9094 = MAKE_SEQ(_1);
    _9093 = NOVALUE;
    _1 = (int)SEQ_PTR(_9094);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_9089].addr;
    Ref(*(int *)(_2+4));
    _1 = (*(int (*)())_0)(
                        *(int *)(_2+4)
                         );
    DeRef(_9095);
    _9095 = _1;
    DeRefDS(_9094);
    _9094 = NOVALUE;
    if (binary_op_a(NOTEQ, _9095, 0)){
        DeRef(_9095);
        _9095 = NOVALUE;
        goto L41; // [1749] 1762
    }
    DeRef(_9095);
    _9095 = NOVALUE;

    /** 				continue*/
    DeRefDS(_opt_16428);
    _opt_16428 = NOVALUE;
    goto L13; // [1759] 532
L41: 
L40: 

    /** 		if find_result[3] = 1 then*/
    _2 = (int)SEQ_PTR(_find_result_16173);
    _9097 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _9097, 1)){
        _9097 = NOVALUE;
        goto L42; // [1771] 1788
    }
    _9097 = NOVALUE;

    /** 			map:remove(parsed_opts, opt[MAPNAME])*/
    _2 = (int)SEQ_PTR(_opt_16428);
    _9099 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_16231);
    Ref(_9099);
    _32remove(_parsed_opts_16231, _9099);
    _9099 = NOVALUE;
    goto L43; // [1785] 1965
L42: 

    /** 			if find(MULTIPLE, opt[OPTIONS]) = 0 then*/
    _2 = (int)SEQ_PTR(_opt_16428);
    _9100 = (int)*(((s1_ptr)_2)->base + 4);
    _9101 = find_from(42, _9100, 1);
    _9100 = NOVALUE;
    if (_9101 != 0)
    goto L44; // [1799] 1946

    /** 				if map:has(parsed_opts, opt[MAPNAME]) and (validation = VALIDATE_ALL or*/
    _2 = (int)SEQ_PTR(_opt_16428);
    _9103 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_16231);
    Ref(_9103);
    _9104 = _32has(_parsed_opts_16231, _9103);
    _9103 = NOVALUE;
    if (IS_ATOM_INT(_9104)) {
        if (_9104 == 0) {
            goto L45; // [1814] 1925
        }
    }
    else {
        if (DBL_PTR(_9104)->dbl == 0.0) {
            goto L45; // [1814] 1925
        }
    }
    _9106 = (_validation_16179 == 2);
    if (_9106 != 0) {
        DeRef(_9107);
        _9107 = 1;
        goto L46; // [1822] 1834
    }
    _9108 = (_validation_16179 == 4);
    _9107 = (_9108 != 0);
L46: 
    if (_9107 == 0)
    {
        _9107 = NOVALUE;
        goto L45; // [1835] 1925
    }
    else{
        _9107 = NOVALUE;
    }

    /** 					if find(HAS_PARAMETER, opt[OPTIONS]) or find(ONCE, opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_opt_16428);
    _9109 = (int)*(((s1_ptr)_2)->base + 4);
    _9110 = find_from(112, _9109, 1);
    _9109 = NOVALUE;
    if (_9110 != 0) {
        goto L47; // [1849] 1867
    }
    _2 = (int)SEQ_PTR(_opt_16428);
    _9112 = (int)*(((s1_ptr)_2)->base + 4);
    _9113 = find_from(49, _9112, 1);
    _9112 = NOVALUE;
    if (_9113 == 0)
    {
        _9113 = NOVALUE;
        goto L48; // [1863] 1964
    }
    else{
        _9113 = NOVALUE;
    }
L47: 

    /** 						printf(1, "option '%s' must not occur more than once in the command line.\n", {find_result[2]})*/
    _2 = (int)SEQ_PTR(_find_result_16173);
    _9115 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_9115);
    *((int *)(_2+4)) = _9115;
    _9116 = MAKE_SEQ(_1);
    _9115 = NOVALUE;
    EPrintf(1, _9114, _9116);
    DeRefDS(_9116);
    _9116 = NOVALUE;

    /** 						if help_on_error then*/
    if (_help_on_error_16183 == 0)
    {
        goto L49; // [1883] 1903
    }
    else{
    }

    /** 							puts(2,10)*/
    EPuts(2, 10); // DJP 

    /** 							local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_16165);
    Ref(_add_help_rid_16178);
    RefDS(_cmds_16167);
    Ref(_parse_options_16166);
    _40local_help(_opts_16165, _add_help_rid_16178, _cmds_16167, 1, _parse_options_16166);
    goto L4A; // [1900] 1916
L49: 

    /** 						elsif auto_help then*/
    if (_auto_help_16182 == 0)
    {
        goto L4B; // [1905] 1915
    }
    else{
    }

    /** 							printf(2,"Try '--help' for more information.\n",{})          */
    EPrintf(2, _8954, _5);
L4B: 
L4A: 

    /** 						local_abort(1)*/
    _40local_abort(1);
    goto L48; // [1922] 1964
L45: 

    /** 					map:put(parsed_opts, opt[MAPNAME], param)*/
    _2 = (int)SEQ_PTR(_opt_16428);
    _9117 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_16231);
    Ref(_9117);
    Ref(_param_16172);
    _32put(_parsed_opts_16231, _9117, _param_16172, 1, 23);
    _9117 = NOVALUE;
    goto L48; // [1943] 1964
L44: 

    /** 				map:put(parsed_opts, opt[MAPNAME], param, map_add_operation)*/
    _2 = (int)SEQ_PTR(_opt_16428);
    _9118 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_16231);
    Ref(_9118);
    Ref(_param_16172);
    _32put(_parsed_opts_16231, _9118, _param_16172, _map_add_operation_16431, 23);
    _9118 = NOVALUE;
L48: 
L43: 

    /**         if find(VERSIONING, opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_opt_16428);
    _9119 = (int)*(((s1_ptr)_2)->base + 4);
    _9120 = find_from(118, _9119, 1);
    _9119 = NOVALUE;
    if (_9120 == 0)
    {
        _9120 = NOVALUE;
        goto L4C; // [1976] 2063
    }
    else{
        _9120 = NOVALUE;
    }

    /**             integer ver_pos = find(VERSIONING, opt[OPTIONS]) + 1*/
    _2 = (int)SEQ_PTR(_opt_16428);
    _9121 = (int)*(((s1_ptr)_2)->base + 4);
    _9122 = find_from(118, _9121, 1);
    _9121 = NOVALUE;
    _ver_pos_16518 = _9122 + 1;
    _9122 = NOVALUE;

    /**             if length(opt[OPTIONS]) >= ver_pos then*/
    _2 = (int)SEQ_PTR(_opt_16428);
    _9124 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_9124)){
            _9125 = SEQ_PTR(_9124)->length;
    }
    else {
        _9125 = 1;
    }
    _9124 = NOVALUE;
    if (_9125 < _ver_pos_16518)
    goto L4D; // [2003] 2032

    /**                 printf(1, "%s\n", { opt[OPTIONS][ver_pos] })*/
    _2 = (int)SEQ_PTR(_opt_16428);
    _9128 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_9128);
    _9129 = (int)*(((s1_ptr)_2)->base + _ver_pos_16518);
    _9128 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_9129);
    *((int *)(_2+4)) = _9129;
    _9130 = MAKE_SEQ(_1);
    _9129 = NOVALUE;
    EPrintf(1, _9127, _9130);
    DeRefDS(_9130);
    _9130 = NOVALUE;

    /**                 abort(0)*/
    UserCleanup(0);
    goto L4E; // [2029] 2062
L4D: 

    /**                 error:crash("help options are incorrect,\n" &*/
    Concat((object_ptr)&_9133, _9131, _9132);
    DeRefi(_fmt_inlined_crash_at_2037_16535);
    _fmt_inlined_crash_at_2037_16535 = _9133;
    _9133 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_2040_16536);
    _msg_inlined_crash_at_2040_16536 = EPrintf(-9999999, _fmt_inlined_crash_at_2037_16535, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_2040_16536);

    /** end procedure*/
    goto L4F; // [2056] 2059
L4F: 
    DeRefi(_fmt_inlined_crash_at_2037_16535);
    _fmt_inlined_crash_at_2037_16535 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_2040_16536);
    _msg_inlined_crash_at_2040_16536 = NOVALUE;
L4E: 
L4C: 
    DeRef(_opt_16428);
    _opt_16428 = NOVALUE;

    /** 	end while*/
    goto L13; // [2069] 532
L14: 

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_16165)){
            _9134 = SEQ_PTR(_opts_16165)->length;
    }
    else {
        _9134 = 1;
    }
    {
        int _i_16538;
        _i_16538 = 1;
L50: 
        if (_i_16538 > _9134){
            goto L51; // [2077] 2292
        }

        /** 		if find(MANDATORY, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_16165);
        _9135 = (int)*(((s1_ptr)_2)->base + _i_16538);
        _2 = (int)SEQ_PTR(_9135);
        _9136 = (int)*(((s1_ptr)_2)->base + 4);
        _9135 = NOVALUE;
        _9137 = find_from(109, _9136, 1);
        _9136 = NOVALUE;
        if (_9137 == 0)
        {
            _9137 = NOVALUE;
            goto L52; // [2099] 2285
        }
        else{
            _9137 = NOVALUE;
        }

        /** 			if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_16165);
        _9138 = (int)*(((s1_ptr)_2)->base + _i_16538);
        _2 = (int)SEQ_PTR(_9138);
        _9139 = (int)*(((s1_ptr)_2)->base + 1);
        _9138 = NOVALUE;
        _9140 = IS_ATOM(_9139);
        _9139 = NOVALUE;
        if (_9140 == 0) {
            goto L53; // [2115] 2206
        }
        _2 = (int)SEQ_PTR(_opts_16165);
        _9142 = (int)*(((s1_ptr)_2)->base + _i_16538);
        _2 = (int)SEQ_PTR(_9142);
        _9143 = (int)*(((s1_ptr)_2)->base + 2);
        _9142 = NOVALUE;
        _9144 = IS_ATOM(_9143);
        _9143 = NOVALUE;
        if (_9144 == 0)
        {
            _9144 = NOVALUE;
            goto L53; // [2131] 2206
        }
        else{
            _9144 = NOVALUE;
        }

        /** 				if length(map:get(parsed_opts, opts[i][MAPNAME])) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_16165);
        _9145 = (int)*(((s1_ptr)_2)->base + _i_16538);
        _2 = (int)SEQ_PTR(_9145);
        _9146 = (int)*(((s1_ptr)_2)->base + 6);
        _9145 = NOVALUE;
        Ref(_parsed_opts_16231);
        Ref(_9146);
        _9147 = _32get(_parsed_opts_16231, _9146, 0);
        _9146 = NOVALUE;
        if (IS_SEQUENCE(_9147)){
                _9148 = SEQ_PTR(_9147)->length;
        }
        else {
            _9148 = 1;
        }
        DeRef(_9147);
        _9147 = NOVALUE;
        if (_9148 != 0)
        goto L54; // [2153] 2284

        /** 					puts(1, "Additional arguments were expected.\n")*/
        EPuts(1, _9150); // DJP 

        /** 					if help_on_error then*/
        if (_help_on_error_16183 == 0)
        {
            goto L55; // [2164] 2184
        }
        else{
        }

        /** 						puts(2,10)*/
        EPuts(2, 10); // DJP 

        /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
        RefDS(_opts_16165);
        Ref(_add_help_rid_16178);
        RefDS(_cmds_16167);
        Ref(_parse_options_16166);
        _40local_help(_opts_16165, _add_help_rid_16178, _cmds_16167, 1, _parse_options_16166);
        goto L56; // [2181] 2197
L55: 

        /** 					elsif auto_help then*/
        if (_auto_help_16182 == 0)
        {
            goto L57; // [2186] 2196
        }
        else{
        }

        /** 						printf(2,"Try '--help' for more information.\n",{})          */
        EPrintf(2, _8954, _5);
L57: 
L56: 

        /** 					local_abort(1)*/
        _40local_abort(1);
        goto L54; // [2203] 2284
L53: 

        /** 				if not map:has(parsed_opts, opts[i][MAPNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_16165);
        _9151 = (int)*(((s1_ptr)_2)->base + _i_16538);
        _2 = (int)SEQ_PTR(_9151);
        _9152 = (int)*(((s1_ptr)_2)->base + 6);
        _9151 = NOVALUE;
        Ref(_parsed_opts_16231);
        Ref(_9152);
        _9153 = _32has(_parsed_opts_16231, _9152);
        _9152 = NOVALUE;
        if (IS_ATOM_INT(_9153)) {
            if (_9153 != 0){
                DeRef(_9153);
                _9153 = NOVALUE;
                goto L58; // [2221] 2283
            }
        }
        else {
            if (DBL_PTR(_9153)->dbl != 0.0){
                DeRef(_9153);
                _9153 = NOVALUE;
                goto L58; // [2221] 2283
            }
        }
        DeRef(_9153);
        _9153 = NOVALUE;

        /** 					printf(1, "option '%s' is mandatory but was not supplied.\n", {opts[i][MAPNAME]})*/
        _2 = (int)SEQ_PTR(_opts_16165);
        _9156 = (int)*(((s1_ptr)_2)->base + _i_16538);
        _2 = (int)SEQ_PTR(_9156);
        _9157 = (int)*(((s1_ptr)_2)->base + 6);
        _9156 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_9157);
        *((int *)(_2+4)) = _9157;
        _9158 = MAKE_SEQ(_1);
        _9157 = NOVALUE;
        EPrintf(1, _9155, _9158);
        DeRefDS(_9158);
        _9158 = NOVALUE;

        /** 					if help_on_error then*/
        if (_help_on_error_16183 == 0)
        {
            goto L59; // [2244] 2264
        }
        else{
        }

        /** 						puts(2,10)*/
        EPuts(2, 10); // DJP 

        /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
        RefDS(_opts_16165);
        Ref(_add_help_rid_16178);
        RefDS(_cmds_16167);
        Ref(_parse_options_16166);
        _40local_help(_opts_16165, _add_help_rid_16178, _cmds_16167, 1, _parse_options_16166);
        goto L5A; // [2261] 2277
L59: 

        /** 					elsif auto_help then*/
        if (_auto_help_16182 == 0)
        {
            goto L5B; // [2266] 2276
        }
        else{
        }

        /** 						printf(2,"Try '--help' for more information.\n",{})          */
        EPrintf(2, _8954, _5);
L5B: 
L5A: 

        /** 					local_abort(1)*/
        _40local_abort(1);
L58: 
L54: 
L52: 

        /** 	end for*/
        _i_16538 = _i_16538 + 1;
        goto L50; // [2287] 2084
L51: 
        ;
    }

    /** 	return parsed_opts*/
    DeRefDS(_opts_16165);
    DeRef(_parse_options_16166);
    DeRefDS(_cmds_16167);
    DeRef(_cmd_16171);
    DeRef(_param_16172);
    DeRef(_find_result_16173);
    DeRef(_type__16174);
    DeRef(_help_opts_16176);
    DeRef(_call_count_16177);
    DeRef(_add_help_rid_16178);
    DeRef(_9050);
    _9050 = NOVALUE;
    _8960 = NOVALUE;
    DeRef(_9052);
    _9052 = NOVALUE;
    _9124 = NOVALUE;
    DeRef(_8982);
    _8982 = NOVALUE;
    DeRef(_9108);
    _9108 = NOVALUE;
    _9005 = NOVALUE;
    DeRef(_9022);
    _9022 = NOVALUE;
    DeRef(_9010);
    _9010 = NOVALUE;
    DeRef(_9074);
    _9074 = NOVALUE;
    DeRef(_8973);
    _8973 = NOVALUE;
    DeRef(_9003);
    _9003 = NOVALUE;
    DeRef(_9068);
    _9068 = NOVALUE;
    DeRef(_8994);
    _8994 = NOVALUE;
    _9147 = NOVALUE;
    DeRef(_8936);
    _8936 = NOVALUE;
    DeRef(_8975);
    _8975 = NOVALUE;
    DeRef(_8998);
    _8998 = NOVALUE;
    DeRef(_9104);
    _9104 = NOVALUE;
    _9056 = NOVALUE;
    DeRef(_9078);
    _9078 = NOVALUE;
    DeRef(_8933);
    _8933 = NOVALUE;
    DeRef(_8963);
    _8963 = NOVALUE;
    DeRef(_8987);
    _8987 = NOVALUE;
    _8989 = NOVALUE;
    DeRef(_9025);
    _9025 = NOVALUE;
    DeRef(_9076);
    _9076 = NOVALUE;
    DeRef(_8965);
    _8965 = NOVALUE;
    DeRef(_9027);
    _9027 = NOVALUE;
    _9089 = NOVALUE;
    DeRef(_9048);
    _9048 = NOVALUE;
    DeRef(_9106);
    _9106 = NOVALUE;
    return _parsed_opts_16231;
    ;
}


int _40build_commandline(int _cmds_16575)
{
    int _9161 = NOVALUE;
    int _9160 = NOVALUE;
    int _9159 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return stdseq:flatten( text:quote( cmds,,'\\'," " ), " ")*/
    RefDS(_5421);
    RefDS(_5421);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5421;
    ((int *)_2)[2] = _5421;
    _9159 = MAKE_SEQ(_1);
    RefDS(_cmds_16575);
    RefDS(_3393);
    _9160 = _12quote(_cmds_16575, _9159, 92, _3393);
    _9159 = NOVALUE;
    RefDS(_3393);
    _9161 = _23flatten(_9160, _3393);
    _9160 = NOVALUE;
    DeRefDS(_cmds_16575);
    return _9161;
    ;
}



// 0x01C5E6B4
