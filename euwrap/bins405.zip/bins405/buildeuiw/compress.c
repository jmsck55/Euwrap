// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _58compress(int _x_21976)
{
    int _x4_21977 = NOVALUE;
    int _s_21978 = NOVALUE;
    int _12708 = NOVALUE;
    int _12707 = NOVALUE;
    int _12706 = NOVALUE;
    int _12704 = NOVALUE;
    int _12703 = NOVALUE;
    int _12701 = NOVALUE;
    int _12699 = NOVALUE;
    int _12698 = NOVALUE;
    int _12697 = NOVALUE;
    int _12696 = NOVALUE;
    int _12694 = NOVALUE;
    int _12692 = NOVALUE;
    int _12691 = NOVALUE;
    int _12690 = NOVALUE;
    int _12689 = NOVALUE;
    int _12688 = NOVALUE;
    int _12687 = NOVALUE;
    int _12686 = NOVALUE;
    int _12685 = NOVALUE;
    int _12684 = NOVALUE;
    int _12682 = NOVALUE;
    int _12681 = NOVALUE;
    int _12680 = NOVALUE;
    int _12679 = NOVALUE;
    int _12678 = NOVALUE;
    int _12677 = NOVALUE;
    int _12675 = NOVALUE;
    int _12674 = NOVALUE;
    int _12673 = NOVALUE;
    int _12672 = NOVALUE;
    int _12671 = NOVALUE;
    int _12670 = NOVALUE;
    int _12669 = NOVALUE;
    int _12668 = NOVALUE;
    int _12667 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(x) then*/
    if (IS_ATOM_INT(_x_21976))
    _12667 = 1;
    else if (IS_ATOM_DBL(_x_21976))
    _12667 = IS_ATOM_INT(DoubleToInt(_x_21976));
    else
    _12667 = 0;
    if (_12667 == 0)
    {
        _12667 = NOVALUE;
        goto L1; // [6] 183
    }
    else{
        _12667 = NOVALUE;
    }

    /** 		if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_21976)) {
        _12668 = (_x_21976 >= -2);
    }
    else {
        _12668 = binary_op(GREATEREQ, _x_21976, -2);
    }
    if (IS_ATOM_INT(_12668)) {
        if (_12668 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_12668)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_21976)) {
        _12670 = (_x_21976 <= 246);
    }
    else {
        _12670 = binary_op(LESSEQ, _x_21976, 246);
    }
    if (_12670 == 0) {
        DeRef(_12670);
        _12670 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_12670) && DBL_PTR(_12670)->dbl == 0.0){
            DeRef(_12670);
            _12670 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_12670);
        _12670 = NOVALUE;
    }
    DeRef(_12670);
    _12670 = NOVALUE;

    /** 			return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_21976)) {
        _12671 = _x_21976 - -2;
        if ((long)((unsigned long)_12671 +(unsigned long) HIGH_BITS) >= 0){
            _12671 = NewDouble((double)_12671);
        }
    }
    else {
        _12671 = binary_op(MINUS, _x_21976, -2);
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12671;
    _12672 = MAKE_SEQ(_1);
    _12671 = NOVALUE;
    DeRef(_x_21976);
    DeRef(_x4_21977);
    DeRef(_s_21978);
    DeRef(_12668);
    _12668 = NOVALUE;
    return _12672;
    goto L3; // [41] 319
L2: 

    /** 		elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_21976)) {
        _12673 = (_x_21976 >= _58MIN2B_21959);
    }
    else {
        _12673 = binary_op(GREATEREQ, _x_21976, _58MIN2B_21959);
    }
    if (IS_ATOM_INT(_12673)) {
        if (_12673 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_12673)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_21976)) {
        _12675 = (_x_21976 <= 32767);
    }
    else {
        _12675 = binary_op(LESSEQ, _x_21976, 32767);
    }
    if (_12675 == 0) {
        DeRef(_12675);
        _12675 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_12675) && DBL_PTR(_12675)->dbl == 0.0){
            DeRef(_12675);
            _12675 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_12675);
        _12675 = NOVALUE;
    }
    DeRef(_12675);
    _12675 = NOVALUE;

    /** 			x -= MIN2B*/
    _0 = _x_21976;
    if (IS_ATOM_INT(_x_21976)) {
        _x_21976 = _x_21976 - _58MIN2B_21959;
        if ((long)((unsigned long)_x_21976 +(unsigned long) HIGH_BITS) >= 0){
            _x_21976 = NewDouble((double)_x_21976);
        }
    }
    else {
        _x_21976 = binary_op(MINUS, _x_21976, _58MIN2B_21959);
    }
    DeRef(_0);

    /** 			return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_21976)) {
        {unsigned long tu;
             tu = (unsigned long)_x_21976 & (unsigned long)255;
             _12677 = MAKE_UINT(tu);
        }
    }
    else {
        _12677 = binary_op(AND_BITS, _x_21976, 255);
    }
    if (IS_ATOM_INT(_x_21976)) {
        if (256 > 0 && _x_21976 >= 0) {
            _12678 = _x_21976 / 256;
        }
        else {
            temp_dbl = floor((double)_x_21976 / (double)256);
            if (_x_21976 != MININT)
            _12678 = (long)temp_dbl;
            else
            _12678 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_21976, 256);
        _12678 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 249;
    *((int *)(_2+8)) = _12677;
    *((int *)(_2+12)) = _12678;
    _12679 = MAKE_SEQ(_1);
    _12678 = NOVALUE;
    _12677 = NOVALUE;
    DeRef(_x_21976);
    DeRef(_x4_21977);
    DeRef(_s_21978);
    DeRef(_12668);
    _12668 = NOVALUE;
    DeRef(_12672);
    _12672 = NOVALUE;
    DeRef(_12673);
    _12673 = NOVALUE;
    return _12679;
    goto L3; // [94] 319
L4: 

    /** 		elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_21976)) {
        _12680 = (_x_21976 >= _58MIN3B_21965);
    }
    else {
        _12680 = binary_op(GREATEREQ, _x_21976, _58MIN3B_21965);
    }
    if (IS_ATOM_INT(_12680)) {
        if (_12680 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_12680)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_21976)) {
        _12682 = (_x_21976 <= 8388607);
    }
    else {
        _12682 = binary_op(LESSEQ, _x_21976, 8388607);
    }
    if (_12682 == 0) {
        DeRef(_12682);
        _12682 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_12682) && DBL_PTR(_12682)->dbl == 0.0){
            DeRef(_12682);
            _12682 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_12682);
        _12682 = NOVALUE;
    }
    DeRef(_12682);
    _12682 = NOVALUE;

    /** 			x -= MIN3B*/
    _0 = _x_21976;
    if (IS_ATOM_INT(_x_21976)) {
        _x_21976 = _x_21976 - _58MIN3B_21965;
        if ((long)((unsigned long)_x_21976 +(unsigned long) HIGH_BITS) >= 0){
            _x_21976 = NewDouble((double)_x_21976);
        }
    }
    else {
        _x_21976 = binary_op(MINUS, _x_21976, _58MIN3B_21965);
    }
    DeRef(_0);

    /** 			return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_21976)) {
        {unsigned long tu;
             tu = (unsigned long)_x_21976 & (unsigned long)255;
             _12684 = MAKE_UINT(tu);
        }
    }
    else {
        _12684 = binary_op(AND_BITS, _x_21976, 255);
    }
    if (IS_ATOM_INT(_x_21976)) {
        if (256 > 0 && _x_21976 >= 0) {
            _12685 = _x_21976 / 256;
        }
        else {
            temp_dbl = floor((double)_x_21976 / (double)256);
            if (_x_21976 != MININT)
            _12685 = (long)temp_dbl;
            else
            _12685 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_21976, 256);
        _12685 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_12685)) {
        {unsigned long tu;
             tu = (unsigned long)_12685 & (unsigned long)255;
             _12686 = MAKE_UINT(tu);
        }
    }
    else {
        _12686 = binary_op(AND_BITS, _12685, 255);
    }
    DeRef(_12685);
    _12685 = NOVALUE;
    if (IS_ATOM_INT(_x_21976)) {
        if (65536 > 0 && _x_21976 >= 0) {
            _12687 = _x_21976 / 65536;
        }
        else {
            temp_dbl = floor((double)_x_21976 / (double)65536);
            if (_x_21976 != MININT)
            _12687 = (long)temp_dbl;
            else
            _12687 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_21976, 65536);
        _12687 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 250;
    *((int *)(_2+8)) = _12684;
    *((int *)(_2+12)) = _12686;
    *((int *)(_2+16)) = _12687;
    _12688 = MAKE_SEQ(_1);
    _12687 = NOVALUE;
    _12686 = NOVALUE;
    _12684 = NOVALUE;
    DeRef(_x_21976);
    DeRef(_x4_21977);
    DeRef(_s_21978);
    DeRef(_12668);
    _12668 = NOVALUE;
    DeRef(_12672);
    _12672 = NOVALUE;
    DeRef(_12673);
    _12673 = NOVALUE;
    DeRef(_12679);
    _12679 = NOVALUE;
    DeRef(_12680);
    _12680 = NOVALUE;
    return _12688;
    goto L3; // [156] 319
L5: 

    /** 			return I4B & int_to_bytes(x-MIN4B)*/
    if (IS_ATOM_INT(_x_21976) && IS_ATOM_INT(_58MIN4B_21971)) {
        _12689 = _x_21976 - _58MIN4B_21971;
        if ((long)((unsigned long)_12689 +(unsigned long) HIGH_BITS) >= 0){
            _12689 = NewDouble((double)_12689);
        }
    }
    else {
        _12689 = binary_op(MINUS, _x_21976, _58MIN4B_21971);
    }
    _12690 = _13int_to_bytes(_12689);
    _12689 = NOVALUE;
    if (IS_SEQUENCE(251) && IS_ATOM(_12690)) {
    }
    else if (IS_ATOM(251) && IS_SEQUENCE(_12690)) {
        Prepend(&_12691, _12690, 251);
    }
    else {
        Concat((object_ptr)&_12691, 251, _12690);
    }
    DeRef(_12690);
    _12690 = NOVALUE;
    DeRef(_x_21976);
    DeRef(_x4_21977);
    DeRef(_s_21978);
    DeRef(_12668);
    _12668 = NOVALUE;
    DeRef(_12672);
    _12672 = NOVALUE;
    DeRef(_12673);
    _12673 = NOVALUE;
    DeRef(_12679);
    _12679 = NOVALUE;
    DeRef(_12680);
    _12680 = NOVALUE;
    DeRef(_12688);
    _12688 = NOVALUE;
    return _12691;
    goto L3; // [180] 319
L1: 

    /** 	elsif atom(x) then*/
    _12692 = IS_ATOM(_x_21976);
    if (_12692 == 0)
    {
        _12692 = NOVALUE;
        goto L6; // [188] 240
    }
    else{
        _12692 = NOVALUE;
    }

    /** 		x4 = atom_to_float32(x)*/
    Ref(_x_21976);
    _0 = _x4_21977;
    _x4_21977 = _13atom_to_float32(_x_21976);
    DeRef(_0);

    /** 		if x = float32_to_atom(x4) then*/
    RefDS(_x4_21977);
    _12694 = _13float32_to_atom(_x4_21977);
    if (binary_op_a(NOTEQ, _x_21976, _12694)){
        DeRef(_12694);
        _12694 = NOVALUE;
        goto L7; // [205] 222
    }
    DeRef(_12694);
    _12694 = NOVALUE;

    /** 			return F4B & x4*/
    Prepend(&_12696, _x4_21977, 252);
    DeRef(_x_21976);
    DeRefDS(_x4_21977);
    DeRef(_s_21978);
    DeRef(_12668);
    _12668 = NOVALUE;
    DeRef(_12672);
    _12672 = NOVALUE;
    DeRef(_12673);
    _12673 = NOVALUE;
    DeRef(_12679);
    _12679 = NOVALUE;
    DeRef(_12680);
    _12680 = NOVALUE;
    DeRef(_12688);
    _12688 = NOVALUE;
    DeRef(_12691);
    _12691 = NOVALUE;
    return _12696;
    goto L3; // [219] 319
L7: 

    /** 			return F8B & atom_to_float64(x)*/
    Ref(_x_21976);
    _12697 = _13atom_to_float64(_x_21976);
    if (IS_SEQUENCE(253) && IS_ATOM(_12697)) {
    }
    else if (IS_ATOM(253) && IS_SEQUENCE(_12697)) {
        Prepend(&_12698, _12697, 253);
    }
    else {
        Concat((object_ptr)&_12698, 253, _12697);
    }
    DeRef(_12697);
    _12697 = NOVALUE;
    DeRef(_x_21976);
    DeRef(_x4_21977);
    DeRef(_s_21978);
    DeRef(_12668);
    _12668 = NOVALUE;
    DeRef(_12672);
    _12672 = NOVALUE;
    DeRef(_12673);
    _12673 = NOVALUE;
    DeRef(_12679);
    _12679 = NOVALUE;
    DeRef(_12680);
    _12680 = NOVALUE;
    DeRef(_12688);
    _12688 = NOVALUE;
    DeRef(_12691);
    _12691 = NOVALUE;
    DeRef(_12696);
    _12696 = NOVALUE;
    return _12698;
    goto L3; // [237] 319
L6: 

    /** 		if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_21976)){
            _12699 = SEQ_PTR(_x_21976)->length;
    }
    else {
        _12699 = 1;
    }
    if (_12699 > 255)
    goto L8; // [245] 261

    /** 			s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_21976)){
            _12701 = SEQ_PTR(_x_21976)->length;
    }
    else {
        _12701 = 1;
    }
    DeRef(_s_21978);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 254;
    ((int *)_2)[2] = _12701;
    _s_21978 = MAKE_SEQ(_1);
    _12701 = NOVALUE;
    goto L9; // [258] 275
L8: 

    /** 			s = S4B & int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_21976)){
            _12703 = SEQ_PTR(_x_21976)->length;
    }
    else {
        _12703 = 1;
    }
    _12704 = _13int_to_bytes(_12703);
    _12703 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_12704)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_12704)) {
        Prepend(&_s_21978, _12704, 255);
    }
    else {
        Concat((object_ptr)&_s_21978, 255, _12704);
    }
    DeRef(_12704);
    _12704 = NOVALUE;
L9: 

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_21976)){
            _12706 = SEQ_PTR(_x_21976)->length;
    }
    else {
        _12706 = 1;
    }
    {
        int _i_22035;
        _i_22035 = 1;
LA: 
        if (_i_22035 > _12706){
            goto LB; // [280] 310
        }

        /** 			s &= compress(x[i])*/
        _2 = (int)SEQ_PTR(_x_21976);
        _12707 = (int)*(((s1_ptr)_2)->base + _i_22035);
        Ref(_12707);
        _12708 = _58compress(_12707);
        _12707 = NOVALUE;
        if (IS_SEQUENCE(_s_21978) && IS_ATOM(_12708)) {
            Ref(_12708);
            Append(&_s_21978, _s_21978, _12708);
        }
        else if (IS_ATOM(_s_21978) && IS_SEQUENCE(_12708)) {
        }
        else {
            Concat((object_ptr)&_s_21978, _s_21978, _12708);
        }
        DeRef(_12708);
        _12708 = NOVALUE;

        /** 		end for*/
        _i_22035 = _i_22035 + 1;
        goto LA; // [305] 287
LB: 
        ;
    }

    /** 		return s*/
    DeRef(_x_21976);
    DeRef(_x4_21977);
    DeRef(_12668);
    _12668 = NOVALUE;
    DeRef(_12672);
    _12672 = NOVALUE;
    DeRef(_12673);
    _12673 = NOVALUE;
    DeRef(_12679);
    _12679 = NOVALUE;
    DeRef(_12680);
    _12680 = NOVALUE;
    DeRef(_12688);
    _12688 = NOVALUE;
    DeRef(_12691);
    _12691 = NOVALUE;
    DeRef(_12696);
    _12696 = NOVALUE;
    DeRef(_12698);
    _12698 = NOVALUE;
    return _s_21978;
L3: 
    ;
}


void _58init_compress()
{
    int _0, _1, _2;
    

    /** 	comp_cache = repeat({}, COMP_CACHE_SIZE)*/
    DeRef(_58comp_cache_22046);
    _58comp_cache_22046 = Repeat(_5, 64);

    /** end procedure*/
    return;
    ;
}


void _58fcompress(int _f_22052, int _x_22053)
{
    int _x4_22054 = NOVALUE;
    int _s_22055 = NOVALUE;
    int _p_22056 = NOVALUE;
    int _12760 = NOVALUE;
    int _12759 = NOVALUE;
    int _12758 = NOVALUE;
    int _12756 = NOVALUE;
    int _12755 = NOVALUE;
    int _12753 = NOVALUE;
    int _12751 = NOVALUE;
    int _12750 = NOVALUE;
    int _12749 = NOVALUE;
    int _12748 = NOVALUE;
    int _12746 = NOVALUE;
    int _12744 = NOVALUE;
    int _12743 = NOVALUE;
    int _12742 = NOVALUE;
    int _12741 = NOVALUE;
    int _12740 = NOVALUE;
    int _12739 = NOVALUE;
    int _12738 = NOVALUE;
    int _12737 = NOVALUE;
    int _12736 = NOVALUE;
    int _12734 = NOVALUE;
    int _12733 = NOVALUE;
    int _12732 = NOVALUE;
    int _12731 = NOVALUE;
    int _12730 = NOVALUE;
    int _12729 = NOVALUE;
    int _12727 = NOVALUE;
    int _12726 = NOVALUE;
    int _12725 = NOVALUE;
    int _12724 = NOVALUE;
    int _12723 = NOVALUE;
    int _12722 = NOVALUE;
    int _12720 = NOVALUE;
    int _12719 = NOVALUE;
    int _12718 = NOVALUE;
    int _12717 = NOVALUE;
    int _12716 = NOVALUE;
    int _12715 = NOVALUE;
    int _12714 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_f_22052)) {
        _1 = (long)(DBL_PTR(_f_22052)->dbl);
        DeRefDS(_f_22052);
        _f_22052 = _1;
    }

    /** 	if integer(x) then*/
    if (IS_ATOM_INT(_x_22053))
    _12714 = 1;
    else if (IS_ATOM_DBL(_x_22053))
    _12714 = IS_ATOM_INT(DoubleToInt(_x_22053));
    else
    _12714 = 0;
    if (_12714 == 0)
    {
        _12714 = NOVALUE;
        goto L1; // [8] 232
    }
    else{
        _12714 = NOVALUE;
    }

    /** 		if x >= MIN1B and x <= max1b then*/
    if (IS_ATOM_INT(_x_22053)) {
        _12715 = (_x_22053 >= -2);
    }
    else {
        _12715 = binary_op(GREATEREQ, _x_22053, -2);
    }
    if (IS_ATOM_INT(_12715)) {
        if (_12715 == 0) {
            goto L2; // [17] 43
        }
    }
    else {
        if (DBL_PTR(_12715)->dbl == 0.0) {
            goto L2; // [17] 43
        }
    }
    if (IS_ATOM_INT(_x_22053)) {
        _12717 = (_x_22053 <= 182);
    }
    else {
        _12717 = binary_op(LESSEQ, _x_22053, 182);
    }
    if (_12717 == 0) {
        DeRef(_12717);
        _12717 = NOVALUE;
        goto L2; // [28] 43
    }
    else {
        if (!IS_ATOM_INT(_12717) && DBL_PTR(_12717)->dbl == 0.0){
            DeRef(_12717);
            _12717 = NOVALUE;
            goto L2; // [28] 43
        }
        DeRef(_12717);
        _12717 = NOVALUE;
    }
    DeRef(_12717);
    _12717 = NOVALUE;

    /** 			puts(f, x - MIN1B) -- normal, quite small integer*/
    if (IS_ATOM_INT(_x_22053)) {
        _12718 = _x_22053 - -2;
        if ((long)((unsigned long)_12718 +(unsigned long) HIGH_BITS) >= 0){
            _12718 = NewDouble((double)_12718);
        }
    }
    else {
        _12718 = binary_op(MINUS, _x_22053, -2);
    }
    EPuts(_f_22052, _12718); // DJP 
    DeRef(_12718);
    _12718 = NOVALUE;
    goto L3; // [40] 362
L2: 

    /** 			p = 1 + and_bits(x, COMP_CACHE_SIZE-1)*/
    _12719 = 63;
    if (IS_ATOM_INT(_x_22053)) {
        {unsigned long tu;
             tu = (unsigned long)_x_22053 & (unsigned long)63;
             _12720 = MAKE_UINT(tu);
        }
    }
    else {
        _12720 = binary_op(AND_BITS, _x_22053, 63);
    }
    _12719 = NOVALUE;
    if (IS_ATOM_INT(_12720)) {
        _p_22056 = _12720 + 1;
    }
    else
    { // coercing _p_22056 to an integer 1
        _p_22056 = 1+(long)(DBL_PTR(_12720)->dbl);
        if( !IS_ATOM_INT(_p_22056) ){
            _p_22056 = (object)DBL_PTR(_p_22056)->dbl;
        }
    }
    DeRef(_12720);
    _12720 = NOVALUE;

    /** 			if equal(comp_cache[p], x) then*/
    _2 = (int)SEQ_PTR(_58comp_cache_22046);
    _12722 = (int)*(((s1_ptr)_2)->base + _p_22056);
    if (_12722 == _x_22053)
    _12723 = 1;
    else if (IS_ATOM_INT(_12722) && IS_ATOM_INT(_x_22053))
    _12723 = 0;
    else
    _12723 = (compare(_12722, _x_22053) == 0);
    _12722 = NOVALUE;
    if (_12723 == 0)
    {
        _12723 = NOVALUE;
        goto L4; // [69] 86
    }
    else{
        _12723 = NOVALUE;
    }

    /** 				puts(f, CACHE0 + p) -- output the cache slot number*/
    _12724 = 184 + _p_22056;
    if ((long)((unsigned long)_12724 + (unsigned long)HIGH_BITS) >= 0) 
    _12724 = NewDouble((double)_12724);
    EPuts(_f_22052, _12724); // DJP 
    DeRef(_12724);
    _12724 = NOVALUE;
    goto L3; // [83] 362
L4: 

    /** 				comp_cache[p] = x -- store it in cache slot p*/
    Ref(_x_22053);
    _2 = (int)SEQ_PTR(_58comp_cache_22046);
    _2 = (int)(((s1_ptr)_2)->base + _p_22056);
    _1 = *(int *)_2;
    *(int *)_2 = _x_22053;
    DeRef(_1);

    /** 				if x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_22053)) {
        _12725 = (_x_22053 >= _58MIN2B_21959);
    }
    else {
        _12725 = binary_op(GREATEREQ, _x_22053, _58MIN2B_21959);
    }
    if (IS_ATOM_INT(_12725)) {
        if (_12725 == 0) {
            goto L5; // [102] 146
        }
    }
    else {
        if (DBL_PTR(_12725)->dbl == 0.0) {
            goto L5; // [102] 146
        }
    }
    if (IS_ATOM_INT(_x_22053)) {
        _12727 = (_x_22053 <= 32767);
    }
    else {
        _12727 = binary_op(LESSEQ, _x_22053, 32767);
    }
    if (_12727 == 0) {
        DeRef(_12727);
        _12727 = NOVALUE;
        goto L5; // [113] 146
    }
    else {
        if (!IS_ATOM_INT(_12727) && DBL_PTR(_12727)->dbl == 0.0){
            DeRef(_12727);
            _12727 = NOVALUE;
            goto L5; // [113] 146
        }
        DeRef(_12727);
        _12727 = NOVALUE;
    }
    DeRef(_12727);
    _12727 = NOVALUE;

    /** 					x -= MIN2B*/
    _0 = _x_22053;
    if (IS_ATOM_INT(_x_22053)) {
        _x_22053 = _x_22053 - _58MIN2B_21959;
        if ((long)((unsigned long)_x_22053 +(unsigned long) HIGH_BITS) >= 0){
            _x_22053 = NewDouble((double)_x_22053);
        }
    }
    else {
        _x_22053 = binary_op(MINUS, _x_22053, _58MIN2B_21959);
    }
    DeRef(_0);

    /** 					puts(f, {I2B, and_bits(x, #FF), floor(x / #100)})*/
    if (IS_ATOM_INT(_x_22053)) {
        {unsigned long tu;
             tu = (unsigned long)_x_22053 & (unsigned long)255;
             _12729 = MAKE_UINT(tu);
        }
    }
    else {
        _12729 = binary_op(AND_BITS, _x_22053, 255);
    }
    if (IS_ATOM_INT(_x_22053)) {
        if (256 > 0 && _x_22053 >= 0) {
            _12730 = _x_22053 / 256;
        }
        else {
            temp_dbl = floor((double)_x_22053 / (double)256);
            if (_x_22053 != MININT)
            _12730 = (long)temp_dbl;
            else
            _12730 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22053, 256);
        _12730 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 249;
    *((int *)(_2+8)) = _12729;
    *((int *)(_2+12)) = _12730;
    _12731 = MAKE_SEQ(_1);
    _12730 = NOVALUE;
    _12729 = NOVALUE;
    EPuts(_f_22052, _12731); // DJP 
    DeRefDS(_12731);
    _12731 = NOVALUE;
    goto L3; // [143] 362
L5: 

    /** 				elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_22053)) {
        _12732 = (_x_22053 >= _58MIN3B_21965);
    }
    else {
        _12732 = binary_op(GREATEREQ, _x_22053, _58MIN3B_21965);
    }
    if (IS_ATOM_INT(_12732)) {
        if (_12732 == 0) {
            goto L6; // [154] 207
        }
    }
    else {
        if (DBL_PTR(_12732)->dbl == 0.0) {
            goto L6; // [154] 207
        }
    }
    if (IS_ATOM_INT(_x_22053)) {
        _12734 = (_x_22053 <= 8388607);
    }
    else {
        _12734 = binary_op(LESSEQ, _x_22053, 8388607);
    }
    if (_12734 == 0) {
        DeRef(_12734);
        _12734 = NOVALUE;
        goto L6; // [165] 207
    }
    else {
        if (!IS_ATOM_INT(_12734) && DBL_PTR(_12734)->dbl == 0.0){
            DeRef(_12734);
            _12734 = NOVALUE;
            goto L6; // [165] 207
        }
        DeRef(_12734);
        _12734 = NOVALUE;
    }
    DeRef(_12734);
    _12734 = NOVALUE;

    /** 					x -= MIN3B*/
    _0 = _x_22053;
    if (IS_ATOM_INT(_x_22053)) {
        _x_22053 = _x_22053 - _58MIN3B_21965;
        if ((long)((unsigned long)_x_22053 +(unsigned long) HIGH_BITS) >= 0){
            _x_22053 = NewDouble((double)_x_22053);
        }
    }
    else {
        _x_22053 = binary_op(MINUS, _x_22053, _58MIN3B_21965);
    }
    DeRef(_0);

    /** 					puts(f, {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)})*/
    if (IS_ATOM_INT(_x_22053)) {
        {unsigned long tu;
             tu = (unsigned long)_x_22053 & (unsigned long)255;
             _12736 = MAKE_UINT(tu);
        }
    }
    else {
        _12736 = binary_op(AND_BITS, _x_22053, 255);
    }
    if (IS_ATOM_INT(_x_22053)) {
        if (256 > 0 && _x_22053 >= 0) {
            _12737 = _x_22053 / 256;
        }
        else {
            temp_dbl = floor((double)_x_22053 / (double)256);
            if (_x_22053 != MININT)
            _12737 = (long)temp_dbl;
            else
            _12737 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22053, 256);
        _12737 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_12737)) {
        {unsigned long tu;
             tu = (unsigned long)_12737 & (unsigned long)255;
             _12738 = MAKE_UINT(tu);
        }
    }
    else {
        _12738 = binary_op(AND_BITS, _12737, 255);
    }
    DeRef(_12737);
    _12737 = NOVALUE;
    if (IS_ATOM_INT(_x_22053)) {
        if (65536 > 0 && _x_22053 >= 0) {
            _12739 = _x_22053 / 65536;
        }
        else {
            temp_dbl = floor((double)_x_22053 / (double)65536);
            if (_x_22053 != MININT)
            _12739 = (long)temp_dbl;
            else
            _12739 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22053, 65536);
        _12739 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 250;
    *((int *)(_2+8)) = _12736;
    *((int *)(_2+12)) = _12738;
    *((int *)(_2+16)) = _12739;
    _12740 = MAKE_SEQ(_1);
    _12739 = NOVALUE;
    _12738 = NOVALUE;
    _12736 = NOVALUE;
    EPuts(_f_22052, _12740); // DJP 
    DeRefDS(_12740);
    _12740 = NOVALUE;
    goto L3; // [204] 362
L6: 

    /** 					puts(f, I4B & int_to_bytes(x-MIN4B))*/
    if (IS_ATOM_INT(_x_22053) && IS_ATOM_INT(_58MIN4B_21971)) {
        _12741 = _x_22053 - _58MIN4B_21971;
        if ((long)((unsigned long)_12741 +(unsigned long) HIGH_BITS) >= 0){
            _12741 = NewDouble((double)_12741);
        }
    }
    else {
        _12741 = binary_op(MINUS, _x_22053, _58MIN4B_21971);
    }
    _12742 = _13int_to_bytes(_12741);
    _12741 = NOVALUE;
    if (IS_SEQUENCE(251) && IS_ATOM(_12742)) {
    }
    else if (IS_ATOM(251) && IS_SEQUENCE(_12742)) {
        Prepend(&_12743, _12742, 251);
    }
    else {
        Concat((object_ptr)&_12743, 251, _12742);
    }
    DeRef(_12742);
    _12742 = NOVALUE;
    EPuts(_f_22052, _12743); // DJP 
    DeRefDS(_12743);
    _12743 = NOVALUE;
    goto L3; // [229] 362
L1: 

    /** 	elsif atom(x) then*/
    _12744 = IS_ATOM(_x_22053);
    if (_12744 == 0)
    {
        _12744 = NOVALUE;
        goto L7; // [237] 287
    }
    else{
        _12744 = NOVALUE;
    }

    /** 		x4 = atom_to_float32(x)*/
    Ref(_x_22053);
    _0 = _x4_22054;
    _x4_22054 = _13atom_to_float32(_x_22053);
    DeRef(_0);

    /** 		if x = float32_to_atom(x4) then*/
    RefDS(_x4_22054);
    _12746 = _13float32_to_atom(_x4_22054);
    if (binary_op_a(NOTEQ, _x_22053, _12746)){
        DeRef(_12746);
        _12746 = NOVALUE;
        goto L8; // [254] 270
    }
    DeRef(_12746);
    _12746 = NOVALUE;

    /** 			puts(f, F4B & x4)*/
    Prepend(&_12748, _x4_22054, 252);
    EPuts(_f_22052, _12748); // DJP 
    DeRefDS(_12748);
    _12748 = NOVALUE;
    goto L3; // [267] 362
L8: 

    /** 			puts(f, F8B & atom_to_float64(x))*/
    Ref(_x_22053);
    _12749 = _13atom_to_float64(_x_22053);
    if (IS_SEQUENCE(253) && IS_ATOM(_12749)) {
    }
    else if (IS_ATOM(253) && IS_SEQUENCE(_12749)) {
        Prepend(&_12750, _12749, 253);
    }
    else {
        Concat((object_ptr)&_12750, 253, _12749);
    }
    DeRef(_12749);
    _12749 = NOVALUE;
    EPuts(_f_22052, _12750); // DJP 
    DeRefDS(_12750);
    _12750 = NOVALUE;
    goto L3; // [284] 362
L7: 

    /** 		if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_22053)){
            _12751 = SEQ_PTR(_x_22053)->length;
    }
    else {
        _12751 = 1;
    }
    if (_12751 > 255)
    goto L9; // [292] 308

    /** 			s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_22053)){
            _12753 = SEQ_PTR(_x_22053)->length;
    }
    else {
        _12753 = 1;
    }
    DeRef(_s_22055);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 254;
    ((int *)_2)[2] = _12753;
    _s_22055 = MAKE_SEQ(_1);
    _12753 = NOVALUE;
    goto LA; // [305] 322
L9: 

    /** 			s = S4B & int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_22053)){
            _12755 = SEQ_PTR(_x_22053)->length;
    }
    else {
        _12755 = 1;
    }
    _12756 = _13int_to_bytes(_12755);
    _12755 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_12756)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_12756)) {
        Prepend(&_s_22055, _12756, 255);
    }
    else {
        Concat((object_ptr)&_s_22055, 255, _12756);
    }
    DeRef(_12756);
    _12756 = NOVALUE;
LA: 

    /** 		puts(f, s)*/
    EPuts(_f_22052, _s_22055); // DJP 

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_22053)){
            _12758 = SEQ_PTR(_x_22053)->length;
    }
    else {
        _12758 = 1;
    }
    {
        int _i_22121;
        _i_22121 = 1;
LB: 
        if (_i_22121 > _12758){
            goto LC; // [334] 361
        }

        /** 			fcompress(f, x[i])*/
        _2 = (int)SEQ_PTR(_x_22053);
        _12759 = (int)*(((s1_ptr)_2)->base + _i_22121);
        DeRef(_12760);
        _12760 = _f_22052;
        Ref(_12759);
        _58fcompress(_12760, _12759);
        _12760 = NOVALUE;
        _12759 = NOVALUE;

        /** 		end for*/
        _i_22121 = _i_22121 + 1;
        goto LB; // [356] 341
LC: 
        ;
    }
L3: 

    /** end procedure*/
    DeRef(_x_22053);
    DeRef(_x4_22054);
    DeRef(_s_22055);
    DeRef(_12715);
    _12715 = NOVALUE;
    DeRef(_12725);
    _12725 = NOVALUE;
    DeRef(_12732);
    _12732 = NOVALUE;
    return;
    ;
}


int _58get4()
{
    int _12769 = NOVALUE;
    int _12768 = NOVALUE;
    int _12767 = NOVALUE;
    int _12766 = NOVALUE;
    int _12765 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(current_db))*/
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12765 = getKBchar();
        }
        else
        _12765 = getc(last_r_file_ptr);
    }
    else
    _12765 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_58mem0_22126)){
        poke_addr = (unsigned char *)_58mem0_22126;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_58mem0_22126)->dbl);
    }
    *poke_addr = (unsigned char)_12765;
    _12765 = NOVALUE;

    /** 	poke(mem1, getc(current_db))*/
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12766 = getKBchar();
        }
        else
        _12766 = getc(last_r_file_ptr);
    }
    else
    _12766 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_58mem1_22127)){
        poke_addr = (unsigned char *)_58mem1_22127;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_58mem1_22127)->dbl);
    }
    *poke_addr = (unsigned char)_12766;
    _12766 = NOVALUE;

    /** 	poke(mem2, getc(current_db))*/
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12767 = getKBchar();
        }
        else
        _12767 = getc(last_r_file_ptr);
    }
    else
    _12767 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_58mem2_22128)){
        poke_addr = (unsigned char *)_58mem2_22128;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_58mem2_22128)->dbl);
    }
    *poke_addr = (unsigned char)_12767;
    _12767 = NOVALUE;

    /** 	poke(mem3, getc(current_db))*/
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12768 = getKBchar();
        }
        else
        _12768 = getc(last_r_file_ptr);
    }
    else
    _12768 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_58mem3_22129)){
        poke_addr = (unsigned char *)_58mem3_22129;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_58mem3_22129)->dbl);
    }
    *poke_addr = (unsigned char)_12768;
    _12768 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_58mem0_22126)) {
        _12769 = *(unsigned long *)_58mem0_22126;
        if ((unsigned)_12769 > (unsigned)MAXINT)
        _12769 = NewDouble((double)(unsigned long)_12769);
    }
    else {
        _12769 = *(unsigned long *)(unsigned long)(DBL_PTR(_58mem0_22126)->dbl);
        if ((unsigned)_12769 > (unsigned)MAXINT)
        _12769 = NewDouble((double)(unsigned long)_12769);
    }
    return _12769;
    ;
}


int _58fdecompress(int _c_22144)
{
    int _s_22145 = NOVALUE;
    int _len_22146 = NOVALUE;
    int _ival_22147 = NOVALUE;
    int _12837 = NOVALUE;
    int _12836 = NOVALUE;
    int _12835 = NOVALUE;
    int _12834 = NOVALUE;
    int _12832 = NOVALUE;
    int _12831 = NOVALUE;
    int _12827 = NOVALUE;
    int _12822 = NOVALUE;
    int _12821 = NOVALUE;
    int _12820 = NOVALUE;
    int _12819 = NOVALUE;
    int _12818 = NOVALUE;
    int _12817 = NOVALUE;
    int _12816 = NOVALUE;
    int _12815 = NOVALUE;
    int _12814 = NOVALUE;
    int _12813 = NOVALUE;
    int _12811 = NOVALUE;
    int _12810 = NOVALUE;
    int _12809 = NOVALUE;
    int _12808 = NOVALUE;
    int _12807 = NOVALUE;
    int _12806 = NOVALUE;
    int _12804 = NOVALUE;
    int _12803 = NOVALUE;
    int _12802 = NOVALUE;
    int _12800 = NOVALUE;
    int _12798 = NOVALUE;
    int _12797 = NOVALUE;
    int _12796 = NOVALUE;
    int _12794 = NOVALUE;
    int _12793 = NOVALUE;
    int _12792 = NOVALUE;
    int _12791 = NOVALUE;
    int _12790 = NOVALUE;
    int _12789 = NOVALUE;
    int _12788 = NOVALUE;
    int _12786 = NOVALUE;
    int _12785 = NOVALUE;
    int _12784 = NOVALUE;
    int _12782 = NOVALUE;
    int _12781 = NOVALUE;
    int _12780 = NOVALUE;
    int _12779 = NOVALUE;
    int _12777 = NOVALUE;
    int _12776 = NOVALUE;
    int _12774 = NOVALUE;
    int _12773 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_22144)) {
        _1 = (long)(DBL_PTR(_c_22144)->dbl);
        DeRefDS(_c_22144);
        _c_22144 = _1;
    }

    /** 	if c = 0 then*/
    if (_c_22144 != 0)
    goto L1; // [5] 70

    /** 		c = getc(current_db)*/
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_22144 = getKBchar();
        }
        else
        _c_22144 = getc(last_r_file_ptr);
    }
    else
    _c_22144 = getc(last_r_file_ptr);

    /** 		if c <= CACHE0 then*/
    if (_c_22144 > 184)
    goto L2; // [20] 37

    /** 			return c + MIN1B  -- a normal, quite small integer*/
    _12773 = _c_22144 + -2;
    DeRef(_s_22145);
    return _12773;
    goto L3; // [34] 69
L2: 

    /** 		elsif c <= CACHE0 + COMP_CACHE_SIZE then*/
    _12774 = 248;
    if (_c_22144 > 248)
    goto L4; // [45] 68

    /** 			return comp_cache[c-CACHE0]*/
    _12776 = _c_22144 - 184;
    _2 = (int)SEQ_PTR(_58comp_cache_22046);
    _12777 = (int)*(((s1_ptr)_2)->base + _12776);
    Ref(_12777);
    DeRef(_s_22145);
    DeRef(_12773);
    _12773 = NOVALUE;
    _12774 = NOVALUE;
    _12776 = NOVALUE;
    return _12777;
L4: 
L3: 
L1: 

    /** 	if c = I2B then*/
    if (_c_22144 != 249)
    goto L5; // [72] 133

    /** 		ival = getc(current_db) +*/
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12779 = getKBchar();
        }
        else
        _12779 = getc(last_r_file_ptr);
    }
    else
    _12779 = getc(last_r_file_ptr);
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12780 = getKBchar();
        }
        else
        _12780 = getc(last_r_file_ptr);
    }
    else
    _12780 = getc(last_r_file_ptr);
    _12781 = 256 * _12780;
    _12780 = NOVALUE;
    _12782 = _12779 + _12781;
    _12779 = NOVALUE;
    _12781 = NOVALUE;
    _ival_22147 = _12782 + _58MIN2B_21959;
    _12782 = NOVALUE;

    /** 		comp_cache[1 + and_bits(ival, COMP_CACHE_SIZE-1)] = ival*/
    _12784 = 63;
    {unsigned long tu;
         tu = (unsigned long)_ival_22147 & (unsigned long)63;
         _12785 = MAKE_UINT(tu);
    }
    _12784 = NOVALUE;
    if (IS_ATOM_INT(_12785)) {
        _12786 = _12785 + 1;
    }
    else
    _12786 = binary_op(PLUS, 1, _12785);
    DeRef(_12785);
    _12785 = NOVALUE;
    _2 = (int)SEQ_PTR(_58comp_cache_22046);
    if (!IS_ATOM_INT(_12786))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12786)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12786);
    _1 = *(int *)_2;
    *(int *)_2 = _ival_22147;
    DeRef(_1);

    /** 		return ival*/
    DeRef(_s_22145);
    DeRef(_12773);
    _12773 = NOVALUE;
    DeRef(_12774);
    _12774 = NOVALUE;
    DeRef(_12776);
    _12776 = NOVALUE;
    _12777 = NOVALUE;
    DeRef(_12786);
    _12786 = NOVALUE;
    return _ival_22147;
    goto L6; // [130] 514
L5: 

    /** 	elsif c = I3B then*/
    if (_c_22144 != 250)
    goto L7; // [135] 209

    /** 		ival = getc(current_db) +*/
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12788 = getKBchar();
        }
        else
        _12788 = getc(last_r_file_ptr);
    }
    else
    _12788 = getc(last_r_file_ptr);
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12789 = getKBchar();
        }
        else
        _12789 = getc(last_r_file_ptr);
    }
    else
    _12789 = getc(last_r_file_ptr);
    _12790 = 256 * _12789;
    _12789 = NOVALUE;
    _12791 = _12788 + _12790;
    _12788 = NOVALUE;
    _12790 = NOVALUE;
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12792 = getKBchar();
        }
        else
        _12792 = getc(last_r_file_ptr);
    }
    else
    _12792 = getc(last_r_file_ptr);
    _12793 = 65536 * _12792;
    _12792 = NOVALUE;
    _12794 = _12791 + _12793;
    _12791 = NOVALUE;
    _12793 = NOVALUE;
    _ival_22147 = _12794 + _58MIN3B_21965;
    _12794 = NOVALUE;

    /** 		comp_cache[1 + and_bits(ival, COMP_CACHE_SIZE-1)] = ival*/
    _12796 = 63;
    {unsigned long tu;
         tu = (unsigned long)_ival_22147 & (unsigned long)63;
         _12797 = MAKE_UINT(tu);
    }
    _12796 = NOVALUE;
    if (IS_ATOM_INT(_12797)) {
        _12798 = _12797 + 1;
    }
    else
    _12798 = binary_op(PLUS, 1, _12797);
    DeRef(_12797);
    _12797 = NOVALUE;
    _2 = (int)SEQ_PTR(_58comp_cache_22046);
    if (!IS_ATOM_INT(_12798))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12798)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12798);
    _1 = *(int *)_2;
    *(int *)_2 = _ival_22147;
    DeRef(_1);

    /** 		return ival*/
    DeRef(_s_22145);
    DeRef(_12773);
    _12773 = NOVALUE;
    DeRef(_12774);
    _12774 = NOVALUE;
    DeRef(_12776);
    _12776 = NOVALUE;
    _12777 = NOVALUE;
    DeRef(_12786);
    _12786 = NOVALUE;
    DeRef(_12798);
    _12798 = NOVALUE;
    return _ival_22147;
    goto L6; // [206] 514
L7: 

    /** 	elsif c = I4B  then*/
    if (_c_22144 != 251)
    goto L8; // [211] 257

    /** 		ival = get4() + MIN4B*/
    _12800 = _58get4();
    if (IS_ATOM_INT(_12800) && IS_ATOM_INT(_58MIN4B_21971)) {
        _ival_22147 = _12800 + _58MIN4B_21971;
    }
    else {
        _ival_22147 = binary_op(PLUS, _12800, _58MIN4B_21971);
    }
    DeRef(_12800);
    _12800 = NOVALUE;
    if (!IS_ATOM_INT(_ival_22147)) {
        _1 = (long)(DBL_PTR(_ival_22147)->dbl);
        DeRefDS(_ival_22147);
        _ival_22147 = _1;
    }

    /** 		comp_cache[1 + and_bits(ival, COMP_CACHE_SIZE-1)] = ival*/
    _12802 = 63;
    {unsigned long tu;
         tu = (unsigned long)_ival_22147 & (unsigned long)63;
         _12803 = MAKE_UINT(tu);
    }
    _12802 = NOVALUE;
    if (IS_ATOM_INT(_12803)) {
        _12804 = _12803 + 1;
    }
    else
    _12804 = binary_op(PLUS, 1, _12803);
    DeRef(_12803);
    _12803 = NOVALUE;
    _2 = (int)SEQ_PTR(_58comp_cache_22046);
    if (!IS_ATOM_INT(_12804))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12804)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12804);
    _1 = *(int *)_2;
    *(int *)_2 = _ival_22147;
    DeRef(_1);

    /** 		return ival*/
    DeRef(_s_22145);
    DeRef(_12773);
    _12773 = NOVALUE;
    DeRef(_12774);
    _12774 = NOVALUE;
    DeRef(_12776);
    _12776 = NOVALUE;
    _12777 = NOVALUE;
    DeRef(_12786);
    _12786 = NOVALUE;
    DeRef(_12798);
    _12798 = NOVALUE;
    DeRef(_12804);
    _12804 = NOVALUE;
    return _ival_22147;
    goto L6; // [254] 514
L8: 

    /** 	elsif c = F4B then*/
    if (_c_22144 != 252)
    goto L9; // [259] 303

    /** 		return float32_to_atom({getc(current_db), getc(current_db),*/
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12806 = getKBchar();
        }
        else
        _12806 = getc(last_r_file_ptr);
    }
    else
    _12806 = getc(last_r_file_ptr);
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12807 = getKBchar();
        }
        else
        _12807 = getc(last_r_file_ptr);
    }
    else
    _12807 = getc(last_r_file_ptr);
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12808 = getKBchar();
        }
        else
        _12808 = getc(last_r_file_ptr);
    }
    else
    _12808 = getc(last_r_file_ptr);
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12809 = getKBchar();
        }
        else
        _12809 = getc(last_r_file_ptr);
    }
    else
    _12809 = getc(last_r_file_ptr);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12806;
    *((int *)(_2+8)) = _12807;
    *((int *)(_2+12)) = _12808;
    *((int *)(_2+16)) = _12809;
    _12810 = MAKE_SEQ(_1);
    _12809 = NOVALUE;
    _12808 = NOVALUE;
    _12807 = NOVALUE;
    _12806 = NOVALUE;
    _12811 = _13float32_to_atom(_12810);
    _12810 = NOVALUE;
    DeRef(_s_22145);
    DeRef(_12773);
    _12773 = NOVALUE;
    DeRef(_12774);
    _12774 = NOVALUE;
    DeRef(_12776);
    _12776 = NOVALUE;
    _12777 = NOVALUE;
    DeRef(_12786);
    _12786 = NOVALUE;
    DeRef(_12798);
    _12798 = NOVALUE;
    DeRef(_12804);
    _12804 = NOVALUE;
    return _12811;
    goto L6; // [300] 514
L9: 

    /** 	elsif c = F8B then*/
    if (_c_22144 != 253)
    goto LA; // [305] 373

    /** 		return float64_to_atom({getc(current_db), getc(current_db),*/
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12813 = getKBchar();
        }
        else
        _12813 = getc(last_r_file_ptr);
    }
    else
    _12813 = getc(last_r_file_ptr);
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12814 = getKBchar();
        }
        else
        _12814 = getc(last_r_file_ptr);
    }
    else
    _12814 = getc(last_r_file_ptr);
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12815 = getKBchar();
        }
        else
        _12815 = getc(last_r_file_ptr);
    }
    else
    _12815 = getc(last_r_file_ptr);
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12816 = getKBchar();
        }
        else
        _12816 = getc(last_r_file_ptr);
    }
    else
    _12816 = getc(last_r_file_ptr);
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12817 = getKBchar();
        }
        else
        _12817 = getc(last_r_file_ptr);
    }
    else
    _12817 = getc(last_r_file_ptr);
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12818 = getKBchar();
        }
        else
        _12818 = getc(last_r_file_ptr);
    }
    else
    _12818 = getc(last_r_file_ptr);
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12819 = getKBchar();
        }
        else
        _12819 = getc(last_r_file_ptr);
    }
    else
    _12819 = getc(last_r_file_ptr);
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _12820 = getKBchar();
        }
        else
        _12820 = getc(last_r_file_ptr);
    }
    else
    _12820 = getc(last_r_file_ptr);
    _1 = NewS1(8);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12813;
    *((int *)(_2+8)) = _12814;
    *((int *)(_2+12)) = _12815;
    *((int *)(_2+16)) = _12816;
    *((int *)(_2+20)) = _12817;
    *((int *)(_2+24)) = _12818;
    *((int *)(_2+28)) = _12819;
    *((int *)(_2+32)) = _12820;
    _12821 = MAKE_SEQ(_1);
    _12820 = NOVALUE;
    _12819 = NOVALUE;
    _12818 = NOVALUE;
    _12817 = NOVALUE;
    _12816 = NOVALUE;
    _12815 = NOVALUE;
    _12814 = NOVALUE;
    _12813 = NOVALUE;
    _12822 = _13float64_to_atom(_12821);
    _12821 = NOVALUE;
    DeRef(_s_22145);
    DeRef(_12773);
    _12773 = NOVALUE;
    DeRef(_12774);
    _12774 = NOVALUE;
    DeRef(_12776);
    _12776 = NOVALUE;
    _12777 = NOVALUE;
    DeRef(_12786);
    _12786 = NOVALUE;
    DeRef(_12798);
    _12798 = NOVALUE;
    DeRef(_12804);
    _12804 = NOVALUE;
    DeRef(_12811);
    _12811 = NOVALUE;
    return _12822;
    goto L6; // [370] 514
LA: 

    /** 		if c = S1B then*/
    if (_c_22144 != 254)
    goto LB; // [375] 389

    /** 			len = getc(current_db)*/
    if (_58current_db_22134 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
        last_r_file_no = _58current_db_22134;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _len_22146 = getKBchar();
        }
        else
        _len_22146 = getc(last_r_file_ptr);
    }
    else
    _len_22146 = getc(last_r_file_ptr);
    goto LC; // [386] 397
LB: 

    /** 			len = get4()*/
    _len_22146 = _58get4();
    if (!IS_ATOM_INT(_len_22146)) {
        _1 = (long)(DBL_PTR(_len_22146)->dbl);
        DeRefDS(_len_22146);
        _len_22146 = _1;
    }
LC: 

    /** 		s = repeat(0, len)*/
    DeRef(_s_22145);
    _s_22145 = Repeat(0, _len_22146);

    /** 		for i = 1 to len do*/
    _12827 = _len_22146;
    {
        int _i_22219;
        _i_22219 = 1;
LD: 
        if (_i_22219 > _12827){
            goto LE; // [410] 507
        }

        /** 			c = getc(current_db)*/
        if (_58current_db_22134 != last_r_file_no) {
            last_r_file_ptr = which_file(_58current_db_22134, EF_READ);
            last_r_file_no = _58current_db_22134;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _c_22144 = getKBchar();
            }
            else
            _c_22144 = getc(last_r_file_ptr);
        }
        else
        _c_22144 = getc(last_r_file_ptr);

        /** 			if c < I2B then*/
        if (_c_22144 >= 249)
        goto LF; // [426] 486

        /** 				if c <= CACHE0 then*/
        if (_c_22144 > 184)
        goto L10; // [434] 451

        /** 					s[i] = c + MIN1B*/
        _12831 = _c_22144 + -2;
        _2 = (int)SEQ_PTR(_s_22145);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_22145 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_22219);
        _1 = *(int *)_2;
        *(int *)_2 = _12831;
        if( _1 != _12831 ){
            DeRef(_1);
        }
        _12831 = NOVALUE;
        goto L11; // [448] 500
L10: 

        /** 				elsif c <= CACHE0 + COMP_CACHE_SIZE then*/
        _12832 = 248;
        if (_c_22144 > 248)
        goto L11; // [459] 500

        /** 					s[i] = comp_cache[c - CACHE0]*/
        _12834 = _c_22144 - 184;
        _2 = (int)SEQ_PTR(_58comp_cache_22046);
        _12835 = (int)*(((s1_ptr)_2)->base + _12834);
        Ref(_12835);
        _2 = (int)SEQ_PTR(_s_22145);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_22145 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_22219);
        _1 = *(int *)_2;
        *(int *)_2 = _12835;
        if( _1 != _12835 ){
            DeRef(_1);
        }
        _12835 = NOVALUE;
        goto L11; // [483] 500
LF: 

        /** 				s[i] = fdecompress(c)*/
        DeRef(_12836);
        _12836 = _c_22144;
        _12837 = _58fdecompress(_12836);
        _12836 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_22145);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_22145 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_22219);
        _1 = *(int *)_2;
        *(int *)_2 = _12837;
        if( _1 != _12837 ){
            DeRef(_1);
        }
        _12837 = NOVALUE;
L11: 

        /** 		end for*/
        _i_22219 = _i_22219 + 1;
        goto LD; // [502] 417
LE: 
        ;
    }

    /** 		return s*/
    DeRef(_12773);
    _12773 = NOVALUE;
    DeRef(_12774);
    _12774 = NOVALUE;
    DeRef(_12776);
    _12776 = NOVALUE;
    _12777 = NOVALUE;
    DeRef(_12786);
    _12786 = NOVALUE;
    DeRef(_12798);
    _12798 = NOVALUE;
    DeRef(_12804);
    _12804 = NOVALUE;
    DeRef(_12832);
    _12832 = NOVALUE;
    DeRef(_12811);
    _12811 = NOVALUE;
    DeRef(_12822);
    _12822 = NOVALUE;
    DeRef(_12834);
    _12834 = NOVALUE;
    return _s_22145;
L6: 
    ;
}



// 0xECA21BB4
