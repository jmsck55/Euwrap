// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _5crash(int _fmt_238, int _data_239)
{
    int _msg_240 = NOVALUE;
    int _0, _1, _2;
    

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_240);
    _msg_240 = EPrintf(-9999999, _fmt_238, _data_239);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_240);

    /** end procedure*/
    DeRefDS(_fmt_238);
    DeRef(_data_239);
    DeRefDSi(_msg_240);
    return;
    ;
}


void _5crash_message(int _msg_244)
{
    int _0, _1, _2;
    

    /** 	machine_proc(M_CRASH_MESSAGE, msg)*/
    machine(37, _msg_244);

    /** end procedure*/
    DeRefDS(_msg_244);
    return;
    ;
}


void _5crash_file(int _file_path_247)
{
    int _0, _1, _2;
    

    /** 	machine_proc(M_CRASH_FILE, file_path)*/
    machine(57, _file_path_247);

    /** end procedure*/
    DeRefDS(_file_path_247);
    return;
    ;
}


void _5warning_file(int _file_path_250)
{
    int _0, _1, _2;
    

    /** 	machine_proc(M_WARNING_FILE, file_path)*/
    machine(72, _file_path_250);

    /** end procedure*/
    DeRef(_file_path_250);
    return;
    ;
}


void _5crash_routine(int _func_253)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_func_253)) {
        _1 = (long)(DBL_PTR(_func_253)->dbl);
        DeRefDS(_func_253);
        _func_253 = _1;
    }

    /** 	machine_proc(M_CRASH_ROUTINE, func)*/
    machine(66, _func_253);

    /** end procedure*/
    return;
    ;
}



// 0x20FB1F11
