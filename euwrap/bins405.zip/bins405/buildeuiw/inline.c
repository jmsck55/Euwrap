// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _66advance(int _pc_52727, int _code_52728)
{
    int _27235 = NOVALUE;
    int _27233 = NOVALUE;
    int _0, _1, _2;
    

    /** 	prev_pc = pc*/
    _66prev_pc_52712 = _pc_52727;

    /** 	if pc > length( code ) then*/
    if (IS_SEQUENCE(_code_52728)){
            _27233 = SEQ_PTR(_code_52728)->length;
    }
    else {
        _27233 = 1;
    }
    if (_pc_52727 <= _27233)
    goto L1; // [15] 26

    /** 		return pc*/
    DeRefDS(_code_52728);
    return _pc_52727;
L1: 

    /** 	return shift:advance( pc, code )*/
    RefDS(_code_52728);
    _27235 = _64advance(_pc_52727, _code_52728);
    DeRefDS(_code_52728);
    return _27235;
    ;
}


void _66shift(int _start_52735, int _amount_52736, int _bound_52737)
{
    int _temp_LineTable_52738 = NOVALUE;
    int _temp_Code_52740 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_amount_52736)) {
        _1 = (long)(DBL_PTR(_amount_52736)->dbl);
        DeRefDS(_amount_52736);
        _amount_52736 = _1;
    }

    /** 		temp_LineTable = LineTable,*/
    RefDS(_26LineTable_12072);
    DeRef(_temp_LineTable_52738);
    _temp_LineTable_52738 = _26LineTable_12072;

    /** 		temp_Code = Code*/
    RefDS(_26Code_12071);
    DeRef(_temp_Code_52740);
    _temp_Code_52740 = _26Code_12071;

    /** 	LineTable = {}*/
    RefDS(_22037);
    DeRefDS(_26LineTable_12072);
    _26LineTable_12072 = _22037;

    /** 	Code = inline_code*/
    RefDS(_66inline_code_52704);
    DeRefDS(_26Code_12071);
    _26Code_12071 = _66inline_code_52704;

    /** 	inline_code = {}*/
    RefDS(_22037);
    DeRefDS(_66inline_code_52704);
    _66inline_code_52704 = _22037;

    /** 	shift:shift( start, amount, bound )*/
    _64shift(_start_52735, _amount_52736, _bound_52737);

    /** 	LineTable = temp_LineTable*/
    RefDS(_temp_LineTable_52738);
    DeRefDS(_26LineTable_12072);
    _26LineTable_12072 = _temp_LineTable_52738;

    /** 	inline_code = Code*/
    RefDS(_26Code_12071);
    DeRefDS(_66inline_code_52704);
    _66inline_code_52704 = _26Code_12071;

    /** 	Code = temp_Code*/
    RefDS(_temp_Code_52740);
    DeRefDS(_26Code_12071);
    _26Code_12071 = _temp_Code_52740;

    /** end procedure*/
    DeRefDS(_temp_LineTable_52738);
    DeRefDS(_temp_Code_52740);
    return;
    ;
}


void _66insert_code(int _code_52749, int _index_52750)
{
    int _27237 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_index_52750)) {
        _1 = (long)(DBL_PTR(_index_52750)->dbl);
        DeRefDS(_index_52750);
        _index_52750 = _1;
    }

    /** 	inline_code = splice( inline_code, code, index )*/
    {
        s1_ptr assign_space;
        insert_pos = _index_52750;
        if (insert_pos <= 0) {
            Concat(&_66inline_code_52704,_code_52749,_66inline_code_52704);
        }
        else if (insert_pos > SEQ_PTR(_66inline_code_52704)->length){
            Concat(&_66inline_code_52704,_66inline_code_52704,_code_52749);
        }
        else if (IS_SEQUENCE(_code_52749)) {
            if( _66inline_code_52704 != _66inline_code_52704 || SEQ_PTR( _66inline_code_52704 )->ref != 1 ){
                DeRef( _66inline_code_52704 );
                RefDS( _66inline_code_52704 );
            }
            assign_space = Add_internal_space( _66inline_code_52704, insert_pos,((s1_ptr)SEQ_PTR(_code_52749))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_code_52749), _66inline_code_52704 == _66inline_code_52704 );
            _66inline_code_52704 = MAKE_SEQ( assign_space );
        }
        else {
            if( _66inline_code_52704 != _66inline_code_52704 && SEQ_PTR( _66inline_code_52704 )->ref != 1 ){
                _66inline_code_52704 = Insert( _66inline_code_52704, _code_52749, insert_pos);
            }
            else {
                DeRef( _66inline_code_52704 );
                RefDS( _66inline_code_52704 );
                _66inline_code_52704 = Insert( _66inline_code_52704, _code_52749, insert_pos);
            }
        }
    }

    /** 	shift( index, length( code ) )*/
    if (IS_SEQUENCE(_code_52749)){
            _27237 = SEQ_PTR(_code_52749)->length;
    }
    else {
        _27237 = 1;
    }
    _66shift(_index_52750, _27237, _index_52750);
    _27237 = NOVALUE;

    /** end procedure*/
    DeRefDS(_code_52749);
    return;
    ;
}


void _66replace_code(int _code_52755, int _start_52756, int _finish_52757)
{
    int _27242 = NOVALUE;
    int _27241 = NOVALUE;
    int _27240 = NOVALUE;
    int _27239 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_52756)) {
        _1 = (long)(DBL_PTR(_start_52756)->dbl);
        DeRefDS(_start_52756);
        _start_52756 = _1;
    }
    if (!IS_ATOM_INT(_finish_52757)) {
        _1 = (long)(DBL_PTR(_finish_52757)->dbl);
        DeRefDS(_finish_52757);
        _finish_52757 = _1;
    }

    /** 	inline_code = replace( inline_code, code, start, finish )*/
    {
        int p1 = _66inline_code_52704;
        int p2 = _code_52755;
        int p3 = _start_52756;
        int p4 = _finish_52757;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_66inline_code_52704;
        Replace( &replace_params );
    }

    /** 	shift( start , length( code ) - (finish - start + 1), finish )*/
    if (IS_SEQUENCE(_code_52755)){
            _27239 = SEQ_PTR(_code_52755)->length;
    }
    else {
        _27239 = 1;
    }
    _27240 = _finish_52757 - _start_52756;
    if ((long)((unsigned long)_27240 +(unsigned long) HIGH_BITS) >= 0){
        _27240 = NewDouble((double)_27240);
    }
    if (IS_ATOM_INT(_27240)) {
        _27241 = _27240 + 1;
        if (_27241 > MAXINT){
            _27241 = NewDouble((double)_27241);
        }
    }
    else
    _27241 = binary_op(PLUS, 1, _27240);
    DeRef(_27240);
    _27240 = NOVALUE;
    if (IS_ATOM_INT(_27241)) {
        _27242 = _27239 - _27241;
        if ((long)((unsigned long)_27242 +(unsigned long) HIGH_BITS) >= 0){
            _27242 = NewDouble((double)_27242);
        }
    }
    else {
        _27242 = NewDouble((double)_27239 - DBL_PTR(_27241)->dbl);
    }
    _27239 = NOVALUE;
    DeRef(_27241);
    _27241 = NOVALUE;
    _66shift(_start_52756, _27242, _finish_52757);
    _27242 = NOVALUE;

    /** end procedure*/
    DeRefDS(_code_52755);
    return;
    ;
}


void _66defer()
{
    int _dx_52765 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer dx = find( inline_sub, deferred_inline_decisions )*/
    _dx_52765 = find_from(_66inline_sub_52718, _66deferred_inline_decisions_52720, 1);

    /** 	if not dx then*/
    if (_dx_52765 != 0)
    goto L1; // [14] 36

    /** 		deferred_inline_decisions &= inline_sub*/
    Append(&_66deferred_inline_decisions_52720, _66deferred_inline_decisions_52720, _66inline_sub_52718);

    /** 		deferred_inline_calls = append( deferred_inline_calls, {} )*/
    RefDS(_22037);
    Append(&_66deferred_inline_calls_52721, _66deferred_inline_calls_52721, _22037);
L1: 

    /** end procedure*/
    return;
    ;
}


int _66new_inline_temp(int _sym_52774)
{
    int _27248 = NOVALUE;
    int _0, _1, _2;
    

    /** 	inline_temps &= sym*/
    Append(&_66inline_temps_52706, _66inline_temps_52706, _sym_52774);

    /** 	return length( inline_temps )*/
    if (IS_SEQUENCE(_66inline_temps_52706)){
            _27248 = SEQ_PTR(_66inline_temps_52706)->length;
    }
    else {
        _27248 = 1;
    }
    return _27248;
    ;
}


int _66get_inline_temp(int _sym_52780)
{
    int _temp_num_52781 = NOVALUE;
    int _27252 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer temp_num = find( sym, inline_params )*/
    _temp_num_52781 = find_from(_sym_52780, _66inline_params_52709, 1);

    /** 	if temp_num then*/
    if (_temp_num_52781 == 0)
    {
        goto L1; // [14] 24
    }
    else{
    }

    /** 		return temp_num*/
    return _temp_num_52781;
L1: 

    /** 	temp_num = find( sym, proc_vars )*/
    _temp_num_52781 = find_from(_sym_52780, _66proc_vars_52705, 1);

    /** 	if temp_num then*/
    if (_temp_num_52781 == 0)
    {
        goto L2; // [35] 45
    }
    else{
    }

    /** 		return temp_num*/
    return _temp_num_52781;
L2: 

    /** 	temp_num = find( sym, inline_temps )*/
    _temp_num_52781 = find_from(_sym_52780, _66inline_temps_52706, 1);

    /** 	if temp_num then*/
    if (_temp_num_52781 == 0)
    {
        goto L3; // [56] 66
    }
    else{
    }

    /** 		return temp_num*/
    return _temp_num_52781;
L3: 

    /** 	return new_inline_temp( sym )*/
    _27252 = _66new_inline_temp(_sym_52780);
    return _27252;
    ;
}


int _66generic_symbol(int _sym_52792)
{
    int _inline_type_52793 = NOVALUE;
    int _px_52794 = NOVALUE;
    int _eentry_52801 = NOVALUE;
    int _27261 = NOVALUE;
    int _27260 = NOVALUE;
    int _27259 = NOVALUE;
    int _27258 = NOVALUE;
    int _27256 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer px = find( sym, inline_params )*/
    _px_52794 = find_from(_sym_52792, _66inline_params_52709, 1);

    /** 	if px then*/
    if (_px_52794 == 0)
    {
        goto L1; // [14] 25
    }
    else{
    }

    /** 		inline_type = INLINE_PARAM*/
    _inline_type_52793 = 1;
    goto L2; // [22] 100
L1: 

    /** 		px = find( sym, proc_vars )*/
    _px_52794 = find_from(_sym_52792, _66proc_vars_52705, 1);

    /** 		if px then*/
    if (_px_52794 == 0)
    {
        goto L3; // [36] 47
    }
    else{
    }

    /** 			inline_type = INLINE_VAR*/
    _inline_type_52793 = 6;
    goto L4; // [44] 99
L3: 

    /** 			sequence eentry = SymTab[sym]*/
    DeRef(_eentry_52801);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _eentry_52801 = (int)*(((s1_ptr)_2)->base + _sym_52792);
    Ref(_eentry_52801);

    /** 			if is_literal( sym ) or eentry[S_SCOPE] > SC_PRIVATE then*/
    _27256 = _66is_literal(_sym_52792);
    if (IS_ATOM_INT(_27256)) {
        if (_27256 != 0) {
            goto L5; // [63] 84
        }
    }
    else {
        if (DBL_PTR(_27256)->dbl != 0.0) {
            goto L5; // [63] 84
        }
    }
    _2 = (int)SEQ_PTR(_eentry_52801);
    _27258 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_27258)) {
        _27259 = (_27258 > 3);
    }
    else {
        _27259 = binary_op(GREATER, _27258, 3);
    }
    _27258 = NOVALUE;
    if (_27259 == 0) {
        DeRef(_27259);
        _27259 = NOVALUE;
        goto L6; // [80] 91
    }
    else {
        if (!IS_ATOM_INT(_27259) && DBL_PTR(_27259)->dbl == 0.0){
            DeRef(_27259);
            _27259 = NOVALUE;
            goto L6; // [80] 91
        }
        DeRef(_27259);
        _27259 = NOVALUE;
    }
    DeRef(_27259);
    _27259 = NOVALUE;
L5: 

    /** 				return sym*/
    DeRef(_eentry_52801);
    DeRef(_27256);
    _27256 = NOVALUE;
    return _sym_52792;
L6: 

    /** 			inline_type = INLINE_TEMP*/
    _inline_type_52793 = 2;
    DeRef(_eentry_52801);
    _eentry_52801 = NOVALUE;
L4: 
L2: 

    /** 	return { inline_type, get_inline_temp( sym ) }*/
    _27260 = _66get_inline_temp(_sym_52792);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _inline_type_52793;
    ((int *)_2)[2] = _27260;
    _27261 = MAKE_SEQ(_1);
    _27260 = NOVALUE;
    DeRef(_27256);
    _27256 = NOVALUE;
    return _27261;
    ;
}


int _66adjust_symbol(int _pc_52816)
{
    int _sym_52818 = NOVALUE;
    int _eentry_52824 = NOVALUE;
    int _27269 = NOVALUE;
    int _27267 = NOVALUE;
    int _27266 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_52816)) {
        _1 = (long)(DBL_PTR(_pc_52816)->dbl);
        DeRefDS(_pc_52816);
        _pc_52816 = _1;
    }

    /** 	symtab_index sym = inline_code[pc]*/
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    _sym_52818 = (int)*(((s1_ptr)_2)->base + _pc_52816);
    if (!IS_ATOM_INT(_sym_52818)){
        _sym_52818 = (long)DBL_PTR(_sym_52818)->dbl;
    }

    /** 	if sym < 0 then*/
    if (_sym_52818 >= 0)
    goto L1; // [15] 28

    /** 		return 0*/
    DeRef(_eentry_52824);
    return 0;
    goto L2; // [25] 41
L1: 

    /** 	elsif not sym then*/
    if (_sym_52818 != 0)
    goto L3; // [30] 40

    /** 		return 1*/
    DeRef(_eentry_52824);
    return 1;
L3: 
L2: 

    /** 	sequence eentry = SymTab[sym]*/
    DeRef(_eentry_52824);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _eentry_52824 = (int)*(((s1_ptr)_2)->base + _sym_52818);
    Ref(_eentry_52824);

    /** 	if is_literal( sym ) then*/
    _27266 = _66is_literal(_sym_52818);
    if (_27266 == 0) {
        DeRef(_27266);
        _27266 = NOVALUE;
        goto L4; // [57] 69
    }
    else {
        if (!IS_ATOM_INT(_27266) && DBL_PTR(_27266)->dbl == 0.0){
            DeRef(_27266);
            _27266 = NOVALUE;
            goto L4; // [57] 69
        }
        DeRef(_27266);
        _27266 = NOVALUE;
    }
    DeRef(_27266);
    _27266 = NOVALUE;

    /** 		return 1*/
    DeRefDS(_eentry_52824);
    return 1;
    goto L5; // [66] 95
L4: 

    /** 	elsif eentry[S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_eentry_52824);
    _27267 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _27267, 9)){
        _27267 = NOVALUE;
        goto L6; // [79] 94
    }
    _27267 = NOVALUE;

    /** 		defer()*/
    _66defer();

    /** 		return 0*/
    DeRefDS(_eentry_52824);
    return 0;
L6: 
L5: 

    /** 	inline_code[pc] = generic_symbol( sym )*/
    _27269 = _66generic_symbol(_sym_52818);
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52704 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_52816);
    _1 = *(int *)_2;
    *(int *)_2 = _27269;
    if( _1 != _27269 ){
        DeRef(_1);
    }
    _27269 = NOVALUE;

    /** 	return 1*/
    DeRef(_eentry_52824);
    return 1;
    ;
}


int _66check_for_param(int _pc_52838)
{
    int _px_52839 = NOVALUE;
    int _27272 = NOVALUE;
    int _27270 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_52838)) {
        _1 = (long)(DBL_PTR(_pc_52838)->dbl);
        DeRefDS(_pc_52838);
        _pc_52838 = _1;
    }

    /** 	integer px = find( inline_code[pc], inline_params )*/
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    _27270 = (int)*(((s1_ptr)_2)->base + _pc_52838);
    _px_52839 = find_from(_27270, _66inline_params_52709, 1);
    _27270 = NOVALUE;

    /** 	if px then*/
    if (_px_52839 == 0)
    {
        goto L1; // [20] 51
    }
    else{
    }

    /** 		if not find( px, assigned_params ) then*/
    _27272 = find_from(_px_52839, _66assigned_params_52710, 1);
    if (_27272 != 0)
    goto L2; // [32] 44
    _27272 = NOVALUE;

    /** 			assigned_params &= px*/
    Append(&_66assigned_params_52710, _66assigned_params_52710, _px_52839);
L2: 

    /** 		return 1*/
    return 1;
L1: 

    /** 	return 0*/
    return 0;
    ;
}


void _66check_target(int _pc_52849, int _op_52850)
{
    int _targets_52851 = NOVALUE;
    int _27281 = NOVALUE;
    int _27280 = NOVALUE;
    int _27279 = NOVALUE;
    int _27278 = NOVALUE;
    int _27277 = NOVALUE;
    int _27275 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence targets = op_info[op][OP_TARGET]*/
    _2 = (int)SEQ_PTR(_64op_info_26647);
    _27275 = (int)*(((s1_ptr)_2)->base + _op_52850);
    DeRef(_targets_52851);
    _2 = (int)SEQ_PTR(_27275);
    _targets_52851 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_targets_52851);
    _27275 = NOVALUE;

    /** 	if length( targets ) then*/
    if (IS_SEQUENCE(_targets_52851)){
            _27277 = SEQ_PTR(_targets_52851)->length;
    }
    else {
        _27277 = 1;
    }
    if (_27277 == 0)
    {
        _27277 = NOVALUE;
        goto L1; // [26] 72
    }
    else{
        _27277 = NOVALUE;
    }

    /** 	for i = 1 to length( targets ) do*/
    if (IS_SEQUENCE(_targets_52851)){
            _27278 = SEQ_PTR(_targets_52851)->length;
    }
    else {
        _27278 = 1;
    }
    {
        int _i_52859;
        _i_52859 = 1;
L2: 
        if (_i_52859 > _27278){
            goto L3; // [34] 71
        }

        /** 			if check_for_param( pc + targets[i] ) then*/
        _2 = (int)SEQ_PTR(_targets_52851);
        _27279 = (int)*(((s1_ptr)_2)->base + _i_52859);
        if (IS_ATOM_INT(_27279)) {
            _27280 = _pc_52849 + _27279;
            if ((long)((unsigned long)_27280 + (unsigned long)HIGH_BITS) >= 0) 
            _27280 = NewDouble((double)_27280);
        }
        else {
            _27280 = binary_op(PLUS, _pc_52849, _27279);
        }
        _27279 = NOVALUE;
        _27281 = _66check_for_param(_27280);
        _27280 = NOVALUE;
        if (_27281 == 0) {
            DeRef(_27281);
            _27281 = NOVALUE;
            goto L4; // [55] 64
        }
        else {
            if (!IS_ATOM_INT(_27281) && DBL_PTR(_27281)->dbl == 0.0){
                DeRef(_27281);
                _27281 = NOVALUE;
                goto L4; // [55] 64
            }
            DeRef(_27281);
            _27281 = NOVALUE;
        }
        DeRef(_27281);
        _27281 = NOVALUE;

        /** 				return*/
        DeRefDS(_targets_52851);
        return;
L4: 

        /** 		end for*/
        _i_52859 = _i_52859 + 1;
        goto L2; // [66] 41
L3: 
        ;
    }
L1: 

    /** end procedure*/
    DeRef(_targets_52851);
    return;
    ;
}


int _66adjust_il(int _pc_52867, int _op_52868)
{
    int _addr_52876 = NOVALUE;
    int _sub_52882 = NOVALUE;
    int _27306 = NOVALUE;
    int _27305 = NOVALUE;
    int _27304 = NOVALUE;
    int _27303 = NOVALUE;
    int _27302 = NOVALUE;
    int _27301 = NOVALUE;
    int _27300 = NOVALUE;
    int _27298 = NOVALUE;
    int _27297 = NOVALUE;
    int _27296 = NOVALUE;
    int _27295 = NOVALUE;
    int _27294 = NOVALUE;
    int _27293 = NOVALUE;
    int _27292 = NOVALUE;
    int _27291 = NOVALUE;
    int _27289 = NOVALUE;
    int _27288 = NOVALUE;
    int _27286 = NOVALUE;
    int _27285 = NOVALUE;
    int _27284 = NOVALUE;
    int _27283 = NOVALUE;
    int _27282 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to op_info[op][OP_SIZE] - 1 do*/
    _2 = (int)SEQ_PTR(_64op_info_26647);
    _27282 = (int)*(((s1_ptr)_2)->base + _op_52868);
    _2 = (int)SEQ_PTR(_27282);
    _27283 = (int)*(((s1_ptr)_2)->base + 2);
    _27282 = NOVALUE;
    if (IS_ATOM_INT(_27283)) {
        _27284 = _27283 - 1;
        if ((long)((unsigned long)_27284 +(unsigned long) HIGH_BITS) >= 0){
            _27284 = NewDouble((double)_27284);
        }
    }
    else {
        _27284 = binary_op(MINUS, _27283, 1);
    }
    _27283 = NOVALUE;
    {
        int _i_52870;
        _i_52870 = 1;
L1: 
        if (binary_op_a(GREATER, _i_52870, _27284)){
            goto L2; // [23] 214
        }

        /** 		integer addr = find( i, op_info[op][OP_ADDR] )*/
        _2 = (int)SEQ_PTR(_64op_info_26647);
        _27285 = (int)*(((s1_ptr)_2)->base + _op_52868);
        _2 = (int)SEQ_PTR(_27285);
        _27286 = (int)*(((s1_ptr)_2)->base + 3);
        _27285 = NOVALUE;
        _addr_52876 = find_from(_i_52870, _27286, 1);
        _27286 = NOVALUE;

        /** 		integer sub  = find( i, op_info[op][OP_SUB] )*/
        _2 = (int)SEQ_PTR(_64op_info_26647);
        _27288 = (int)*(((s1_ptr)_2)->base + _op_52868);
        _2 = (int)SEQ_PTR(_27288);
        _27289 = (int)*(((s1_ptr)_2)->base + 5);
        _27288 = NOVALUE;
        _sub_52882 = find_from(_i_52870, _27289, 1);
        _27289 = NOVALUE;

        /** 		if addr then*/
        if (_addr_52876 == 0)
        {
            goto L3; // [70] 121
        }
        else{
        }

        /** 			if integer( inline_code[pc+i] ) then*/
        if (IS_ATOM_INT(_i_52870)) {
            _27291 = _pc_52867 + _i_52870;
        }
        else {
            _27291 = NewDouble((double)_pc_52867 + DBL_PTR(_i_52870)->dbl);
        }
        _2 = (int)SEQ_PTR(_66inline_code_52704);
        if (!IS_ATOM_INT(_27291)){
            _27292 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27291)->dbl));
        }
        else{
            _27292 = (int)*(((s1_ptr)_2)->base + _27291);
        }
        if (IS_ATOM_INT(_27292))
        _27293 = 1;
        else if (IS_ATOM_DBL(_27292))
        _27293 = IS_ATOM_INT(DoubleToInt(_27292));
        else
        _27293 = 0;
        _27292 = NOVALUE;
        if (_27293 == 0)
        {
            _27293 = NOVALUE;
            goto L4; // [88] 205
        }
        else{
            _27293 = NOVALUE;
        }

        /** 				inline_code[pc + i] = { INLINE_ADDR, inline_code[pc + i] }*/
        if (IS_ATOM_INT(_i_52870)) {
            _27294 = _pc_52867 + _i_52870;
            if ((long)((unsigned long)_27294 + (unsigned long)HIGH_BITS) >= 0) 
            _27294 = NewDouble((double)_27294);
        }
        else {
            _27294 = NewDouble((double)_pc_52867 + DBL_PTR(_i_52870)->dbl);
        }
        if (IS_ATOM_INT(_i_52870)) {
            _27295 = _pc_52867 + _i_52870;
        }
        else {
            _27295 = NewDouble((double)_pc_52867 + DBL_PTR(_i_52870)->dbl);
        }
        _2 = (int)SEQ_PTR(_66inline_code_52704);
        if (!IS_ATOM_INT(_27295)){
            _27296 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27295)->dbl));
        }
        else{
            _27296 = (int)*(((s1_ptr)_2)->base + _27295);
        }
        Ref(_27296);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 4;
        ((int *)_2)[2] = _27296;
        _27297 = MAKE_SEQ(_1);
        _27296 = NOVALUE;
        _2 = (int)SEQ_PTR(_66inline_code_52704);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _66inline_code_52704 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27294))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_27294)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _27294);
        _1 = *(int *)_2;
        *(int *)_2 = _27297;
        if( _1 != _27297 ){
            DeRef(_1);
        }
        _27297 = NOVALUE;
        goto L4; // [118] 205
L3: 

        /** 		elsif sub then*/
        if (_sub_52882 == 0)
        {
            goto L5; // [123] 141
        }
        else{
        }

        /** 			inline_code[pc+i] = {INLINE_SUB}*/
        if (IS_ATOM_INT(_i_52870)) {
            _27298 = _pc_52867 + _i_52870;
        }
        else {
            _27298 = NewDouble((double)_pc_52867 + DBL_PTR(_i_52870)->dbl);
        }
        RefDS(_27299);
        _2 = (int)SEQ_PTR(_66inline_code_52704);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _66inline_code_52704 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27298))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_27298)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _27298);
        _1 = *(int *)_2;
        *(int *)_2 = _27299;
        DeRef(_1);
        goto L4; // [138] 205
L5: 

        /** 			if op != STARTLINE and op != COVERAGE_LINE and op != COVERAGE_ROUTINE then*/
        _27300 = (_op_52868 != 58);
        if (_27300 == 0) {
            _27301 = 0;
            goto L6; // [149] 163
        }
        _27302 = (_op_52868 != 210);
        _27301 = (_27302 != 0);
L6: 
        if (_27301 == 0) {
            goto L7; // [163] 204
        }
        _27304 = (_op_52868 != 211);
        if (_27304 == 0)
        {
            DeRef(_27304);
            _27304 = NOVALUE;
            goto L7; // [174] 204
        }
        else{
            DeRef(_27304);
            _27304 = NOVALUE;
        }

        /** 				check_target( pc, op )*/
        _66check_target(_pc_52867, _op_52868);

        /** 				if not adjust_symbol( pc + i ) then*/
        if (IS_ATOM_INT(_i_52870)) {
            _27305 = _pc_52867 + _i_52870;
            if ((long)((unsigned long)_27305 + (unsigned long)HIGH_BITS) >= 0) 
            _27305 = NewDouble((double)_27305);
        }
        else {
            _27305 = NewDouble((double)_pc_52867 + DBL_PTR(_i_52870)->dbl);
        }
        _27306 = _66adjust_symbol(_27305);
        _27305 = NOVALUE;
        if (IS_ATOM_INT(_27306)) {
            if (_27306 != 0){
                DeRef(_27306);
                _27306 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        else {
            if (DBL_PTR(_27306)->dbl != 0.0){
                DeRef(_27306);
                _27306 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        DeRef(_27306);
        _27306 = NOVALUE;

        /** 					return 0*/
        DeRef(_i_52870);
        DeRef(_27291);
        _27291 = NOVALUE;
        DeRef(_27284);
        _27284 = NOVALUE;
        DeRef(_27294);
        _27294 = NOVALUE;
        DeRef(_27295);
        _27295 = NOVALUE;
        DeRef(_27298);
        _27298 = NOVALUE;
        DeRef(_27300);
        _27300 = NOVALUE;
        DeRef(_27302);
        _27302 = NOVALUE;
        return 0;
L8: 
L7: 
L4: 

        /** 	end for*/
        _0 = _i_52870;
        if (IS_ATOM_INT(_i_52870)) {
            _i_52870 = _i_52870 + 1;
            if ((long)((unsigned long)_i_52870 +(unsigned long) HIGH_BITS) >= 0){
                _i_52870 = NewDouble((double)_i_52870);
            }
        }
        else {
            _i_52870 = binary_op_a(PLUS, _i_52870, 1);
        }
        DeRef(_0);
        goto L1; // [209] 30
L2: 
        ;
        DeRef(_i_52870);
    }

    /** 	return 1*/
    DeRef(_27291);
    _27291 = NOVALUE;
    DeRef(_27284);
    _27284 = NOVALUE;
    DeRef(_27294);
    _27294 = NOVALUE;
    DeRef(_27295);
    _27295 = NOVALUE;
    DeRef(_27298);
    _27298 = NOVALUE;
    DeRef(_27300);
    _27300 = NOVALUE;
    DeRef(_27302);
    _27302 = NOVALUE;
    return 1;
    ;
}


int _66is_temp(int _sym_52917)
{
    int _27317 = NOVALUE;
    int _27316 = NOVALUE;
    int _27315 = NOVALUE;
    int _27314 = NOVALUE;
    int _27313 = NOVALUE;
    int _27312 = NOVALUE;
    int _27311 = NOVALUE;
    int _27310 = NOVALUE;
    int _27309 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sym <= 0 then*/
    if (_sym_52917 > 0)
    goto L1; // [5] 16

    /** 		return 0*/
    return 0;
L1: 

    /** 	return (SymTab[sym][S_MODE] = M_TEMP) and (not TRANSLATE or equal( NOVALUE, SymTab[sym][S_OBJ]) )*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27309 = (int)*(((s1_ptr)_2)->base + _sym_52917);
    _2 = (int)SEQ_PTR(_27309);
    _27310 = (int)*(((s1_ptr)_2)->base + 3);
    _27309 = NOVALUE;
    if (IS_ATOM_INT(_27310)) {
        _27311 = (_27310 == 3);
    }
    else {
        _27311 = binary_op(EQUALS, _27310, 3);
    }
    _27310 = NOVALUE;
    _27312 = (_26TRANSLATE_11619 == 0);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27313 = (int)*(((s1_ptr)_2)->base + _sym_52917);
    _2 = (int)SEQ_PTR(_27313);
    _27314 = (int)*(((s1_ptr)_2)->base + 1);
    _27313 = NOVALUE;
    if (_26NOVALUE_11836 == _27314)
    _27315 = 1;
    else if (IS_ATOM_INT(_26NOVALUE_11836) && IS_ATOM_INT(_27314))
    _27315 = 0;
    else
    _27315 = (compare(_26NOVALUE_11836, _27314) == 0);
    _27314 = NOVALUE;
    _27316 = (_27312 != 0 || _27315 != 0);
    _27312 = NOVALUE;
    _27315 = NOVALUE;
    if (IS_ATOM_INT(_27311)) {
        _27317 = (_27311 != 0 && _27316 != 0);
    }
    else {
        _27317 = binary_op(AND, _27311, _27316);
    }
    DeRef(_27311);
    _27311 = NOVALUE;
    _27316 = NOVALUE;
    return _27317;
    ;
}


int _66is_literal(int _sym_52939)
{
    int _mode_52942 = NOVALUE;
    int _27332 = NOVALUE;
    int _27331 = NOVALUE;
    int _27330 = NOVALUE;
    int _27329 = NOVALUE;
    int _27328 = NOVALUE;
    int _27327 = NOVALUE;
    int _27325 = NOVALUE;
    int _27324 = NOVALUE;
    int _27323 = NOVALUE;
    int _27322 = NOVALUE;
    int _27321 = NOVALUE;
    int _27319 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sym <= 0 then*/
    if (_sym_52939 > 0)
    goto L1; // [5] 16

    /** 		return 0*/
    return 0;
L1: 

    /** 	integer mode = SymTab[sym][S_MODE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27319 = (int)*(((s1_ptr)_2)->base + _sym_52939);
    _2 = (int)SEQ_PTR(_27319);
    _mode_52942 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_52942)){
        _mode_52942 = (long)DBL_PTR(_mode_52942)->dbl;
    }
    _27319 = NOVALUE;

    /** 	if (mode = M_CONSTANT and eu:compare( NOVALUE, SymTab[sym][S_OBJ]) ) */
    _27321 = (_mode_52942 == 2);
    if (_27321 == 0) {
        _27322 = 0;
        goto L2; // [40] 66
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27323 = (int)*(((s1_ptr)_2)->base + _sym_52939);
    _2 = (int)SEQ_PTR(_27323);
    _27324 = (int)*(((s1_ptr)_2)->base + 1);
    _27323 = NOVALUE;
    if (IS_ATOM_INT(_26NOVALUE_11836) && IS_ATOM_INT(_27324)){
        _27325 = (_26NOVALUE_11836 < _27324) ? -1 : (_26NOVALUE_11836 > _27324);
    }
    else{
        _27325 = compare(_26NOVALUE_11836, _27324);
    }
    _27324 = NOVALUE;
    _27322 = (_27325 != 0);
L2: 
    if (_27322 != 0) {
        goto L3; // [66] 117
    }
    if (_26TRANSLATE_11619 == 0) {
        _27327 = 0;
        goto L4; // [72] 86
    }
    _27328 = (_mode_52942 == 3);
    _27327 = (_27328 != 0);
L4: 
    if (_27327 == 0) {
        DeRef(_27329);
        _27329 = 0;
        goto L5; // [86] 112
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27330 = (int)*(((s1_ptr)_2)->base + _sym_52939);
    _2 = (int)SEQ_PTR(_27330);
    _27331 = (int)*(((s1_ptr)_2)->base + 1);
    _27330 = NOVALUE;
    if (IS_ATOM_INT(_27331) && IS_ATOM_INT(_26NOVALUE_11836)){
        _27332 = (_27331 < _26NOVALUE_11836) ? -1 : (_27331 > _26NOVALUE_11836);
    }
    else{
        _27332 = compare(_27331, _26NOVALUE_11836);
    }
    _27331 = NOVALUE;
    _27329 = (_27332 != 0);
L5: 
    if (_27329 == 0)
    {
        _27329 = NOVALUE;
        goto L6; // [113] 126
    }
    else{
        _27329 = NOVALUE;
    }
L3: 

    /** 		return 1*/
    DeRef(_27321);
    _27321 = NOVALUE;
    DeRef(_27328);
    _27328 = NOVALUE;
    return 1;
    goto L7; // [123] 133
L6: 

    /** 		return 0*/
    DeRef(_27321);
    _27321 = NOVALUE;
    DeRef(_27328);
    _27328 = NOVALUE;
    return 0;
L7: 
    ;
}


int _66returnf(int _pc_52989)
{
    int _retsym_52991 = NOVALUE;
    int _code_53024 = NOVALUE;
    int _ret_pc_53025 = NOVALUE;
    int _code_53070 = NOVALUE;
    int _ret_pc_53084 = NOVALUE;
    int _27405 = NOVALUE;
    int _27404 = NOVALUE;
    int _27402 = NOVALUE;
    int _27400 = NOVALUE;
    int _27399 = NOVALUE;
    int _27397 = NOVALUE;
    int _27396 = NOVALUE;
    int _27394 = NOVALUE;
    int _27393 = NOVALUE;
    int _27392 = NOVALUE;
    int _27390 = NOVALUE;
    int _27389 = NOVALUE;
    int _27387 = NOVALUE;
    int _27385 = NOVALUE;
    int _27384 = NOVALUE;
    int _27382 = NOVALUE;
    int _27381 = NOVALUE;
    int _27379 = NOVALUE;
    int _27378 = NOVALUE;
    int _27377 = NOVALUE;
    int _27375 = NOVALUE;
    int _27374 = NOVALUE;
    int _27373 = NOVALUE;
    int _27372 = NOVALUE;
    int _27371 = NOVALUE;
    int _27369 = NOVALUE;
    int _27368 = NOVALUE;
    int _27367 = NOVALUE;
    int _27366 = NOVALUE;
    int _27364 = NOVALUE;
    int _27362 = NOVALUE;
    int _27361 = NOVALUE;
    int _27360 = NOVALUE;
    int _27359 = NOVALUE;
    int _27358 = NOVALUE;
    int _27357 = NOVALUE;
    int _27356 = NOVALUE;
    int _27355 = NOVALUE;
    int _27354 = NOVALUE;
    int _27352 = NOVALUE;
    int _27351 = NOVALUE;
    int _27350 = NOVALUE;
    int _27348 = NOVALUE;
    int _27347 = NOVALUE;
    int _27346 = NOVALUE;
    int _27345 = NOVALUE;
    int _27344 = NOVALUE;
    int _27343 = NOVALUE;
    int _27341 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	symtab_index retsym = inline_code[pc+3]*/
    _27341 = _pc_52989 + 3;
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    _retsym_52991 = (int)*(((s1_ptr)_2)->base + _27341);
    if (!IS_ATOM_INT(_retsym_52991)){
        _retsym_52991 = (long)DBL_PTR(_retsym_52991)->dbl;
    }

    /** 	if equal( inline_code[$], BADRETURNF ) then*/
    if (IS_SEQUENCE(_66inline_code_52704)){
            _27343 = SEQ_PTR(_66inline_code_52704)->length;
    }
    else {
        _27343 = 1;
    }
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    _27344 = (int)*(((s1_ptr)_2)->base + _27343);
    if (_27344 == 43)
    _27345 = 1;
    else if (IS_ATOM_INT(_27344) && IS_ATOM_INT(43))
    _27345 = 0;
    else
    _27345 = (compare(_27344, 43) == 0);
    _27344 = NOVALUE;
    if (_27345 == 0)
    {
        _27345 = NOVALUE;
        goto L1; // [34] 102
    }
    else{
        _27345 = NOVALUE;
    }

    /** 		if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L2; // [41] 60
    }
    else{
    }

    /** 			inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_66inline_code_52704)){
            _27346 = SEQ_PTR(_66inline_code_52704)->length;
    }
    else {
        _27346 = 1;
    }
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52704 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27346);
    _1 = *(int *)_2;
    *(int *)_2 = 159;
    DeRef(_1);
    goto L3; // [57] 101
L2: 

    /** 		elsif SymTab[inline_sub][S_TOKEN] = PROC then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27347 = (int)*(((s1_ptr)_2)->base + _66inline_sub_52718);
    _2 = (int)SEQ_PTR(_27347);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _27348 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _27348 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _27347 = NOVALUE;
    if (binary_op_a(NOTEQ, _27348, 27)){
        _27348 = NOVALUE;
        goto L4; // [78] 100
    }
    _27348 = NOVALUE;

    /** 			replace_code( {}, length(inline_code), length(inline_code) )*/
    if (IS_SEQUENCE(_66inline_code_52704)){
            _27350 = SEQ_PTR(_66inline_code_52704)->length;
    }
    else {
        _27350 = 1;
    }
    if (IS_SEQUENCE(_66inline_code_52704)){
            _27351 = SEQ_PTR(_66inline_code_52704)->length;
    }
    else {
        _27351 = 1;
    }
    RefDS(_22037);
    _66replace_code(_22037, _27350, _27351);
    _27350 = NOVALUE;
    _27351 = NOVALUE;
L4: 
L3: 
L1: 

    /** 	if is_temp( retsym ) */
    _27352 = _66is_temp(_retsym_52991);
    if (IS_ATOM_INT(_27352)) {
        if (_27352 != 0) {
            goto L5; // [108] 150
        }
    }
    else {
        if (DBL_PTR(_27352)->dbl != 0.0) {
            goto L5; // [108] 150
        }
    }
    _27354 = _66is_literal(_retsym_52991);
    if (IS_ATOM_INT(_27354)) {
        _27355 = (_27354 == 0);
    }
    else {
        _27355 = unary_op(NOT, _27354);
    }
    DeRef(_27354);
    _27354 = NOVALUE;
    if (IS_ATOM_INT(_27355)) {
        if (_27355 == 0) {
            DeRef(_27356);
            _27356 = 0;
            goto L6; // [119] 145
        }
    }
    else {
        if (DBL_PTR(_27355)->dbl == 0.0) {
            DeRef(_27356);
            _27356 = 0;
            goto L6; // [119] 145
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27357 = (int)*(((s1_ptr)_2)->base + _retsym_52991);
    _2 = (int)SEQ_PTR(_27357);
    _27358 = (int)*(((s1_ptr)_2)->base + 4);
    _27357 = NOVALUE;
    if (IS_ATOM_INT(_27358)) {
        _27359 = (_27358 <= 3);
    }
    else {
        _27359 = binary_op(LESSEQ, _27358, 3);
    }
    _27358 = NOVALUE;
    DeRef(_27356);
    if (IS_ATOM_INT(_27359))
    _27356 = (_27359 != 0);
    else
    _27356 = DBL_PTR(_27359)->dbl != 0.0;
L6: 
    if (_27356 == 0)
    {
        _27356 = NOVALUE;
        goto L7; // [146] 393
    }
    else{
        _27356 = NOVALUE;
    }
L5: 

    /** 		sequence code = {}*/
    RefDS(_22037);
    DeRef(_code_53024);
    _code_53024 = _22037;

    /** 		integer ret_pc = 0*/
    _ret_pc_53025 = 0;

    /** 		if not (find( retsym, inline_params ) or find( retsym, proc_vars )) then*/
    _27360 = find_from(_retsym_52991, _66inline_params_52709, 1);
    if (_27360 != 0) {
        DeRef(_27361);
        _27361 = 1;
        goto L8; // [171] 186
    }
    _27362 = find_from(_retsym_52991, _66proc_vars_52705, 1);
    _27361 = (_27362 != 0);
L8: 
    if (_27361 != 0)
    goto L9; // [186] 206
    _27361 = NOVALUE;

    /** 			ret_pc = rfind( generic_symbol( retsym ), inline_code, pc )*/
    _27364 = _66generic_symbol(_retsym_52991);
    RefDS(_66inline_code_52704);
    _ret_pc_53025 = _14rfind(_27364, _66inline_code_52704, _pc_52989);
    _27364 = NOVALUE;
    if (!IS_ATOM_INT(_ret_pc_53025)) {
        _1 = (long)(DBL_PTR(_ret_pc_53025)->dbl);
        DeRefDS(_ret_pc_53025);
        _ret_pc_53025 = _1;
    }
L9: 

    /** 		if ret_pc and eu:compare( inline_code[ret_pc-1], PRIVATE_INIT_CHECK ) then*/
    if (_ret_pc_53025 == 0) {
        goto LA; // [208] 277
    }
    _27367 = _ret_pc_53025 - 1;
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    _27368 = (int)*(((s1_ptr)_2)->base + _27367);
    if (IS_ATOM_INT(_27368) && IS_ATOM_INT(30)){
        _27369 = (_27368 < 30) ? -1 : (_27368 > 30);
    }
    else{
        _27369 = compare(_27368, 30);
    }
    _27368 = NOVALUE;
    if (_27369 == 0)
    {
        _27369 = NOVALUE;
        goto LA; // [229] 277
    }
    else{
        _27369 = NOVALUE;
    }

    /** 			inline_code[ret_pc] = {INLINE_TARGET}*/
    RefDS(_27370);
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52704 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ret_pc_53025);
    _1 = *(int *)_2;
    *(int *)_2 = _27370;
    DeRef(_1);

    /** 			if equal( inline_code[ret_pc-1], REF_TEMP ) then*/
    _27371 = _ret_pc_53025 - 1;
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    _27372 = (int)*(((s1_ptr)_2)->base + _27371);
    if (_27372 == 207)
    _27373 = 1;
    else if (IS_ATOM_INT(_27372) && IS_ATOM_INT(207))
    _27373 = 0;
    else
    _27373 = (compare(_27372, 207) == 0);
    _27372 = NOVALUE;
    if (_27373 == 0)
    {
        _27373 = NOVALUE;
        goto LB; // [258] 292
    }
    else{
        _27373 = NOVALUE;
    }

    /** 				inline_code[ret_pc-2] = {INLINE_TARGET}*/
    _27374 = _ret_pc_53025 - 2;
    RefDS(_27370);
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52704 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27374);
    _1 = *(int *)_2;
    *(int *)_2 = _27370;
    DeRef(_1);
    goto LB; // [274] 292
LA: 

    /** 			code = {ASSIGN, generic_symbol( retsym ), {INLINE_TARGET}}*/
    _27375 = _66generic_symbol(_retsym_52991);
    _0 = _code_53024;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 18;
    *((int *)(_2+8)) = _27375;
    RefDS(_27370);
    *((int *)(_2+12)) = _27370;
    _code_53024 = MAKE_SEQ(_1);
    DeRef(_0);
    _27375 = NOVALUE;
LB: 

    /** 		if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_66inline_code_52704)){
            _27377 = SEQ_PTR(_66inline_code_52704)->length;
    }
    else {
        _27377 = 1;
    }
    _27378 = 3 + _26TRANSLATE_11619;
    _27379 = _27377 - _27378;
    _27377 = NOVALUE;
    _27378 = NOVALUE;
    if (_pc_52989 == _27379)
    goto LC; // [309] 330

    /** 			code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = -1;
    _27381 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 23;
    ((int *)_2)[2] = _27381;
    _27382 = MAKE_SEQ(_1);
    _27381 = NOVALUE;
    Concat((object_ptr)&_code_53024, _code_53024, _27382);
    DeRefDS(_27382);
    _27382 = NOVALUE;
LC: 

    /** 		replace_code( code, pc, pc + 3 )*/
    _27384 = _pc_52989 + 3;
    if ((long)((unsigned long)_27384 + (unsigned long)HIGH_BITS) >= 0) 
    _27384 = NewDouble((double)_27384);
    RefDS(_code_53024);
    _66replace_code(_code_53024, _pc_52989, _27384);
    _27384 = NOVALUE;

    /** 		ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = -1;
    _27385 = MAKE_SEQ(_1);
    _ret_pc_53025 = find_from(_27385, _66inline_code_52704, _pc_52989);
    DeRefDS(_27385);
    _27385 = NOVALUE;

    /** 		if ret_pc then*/
    if (_ret_pc_53025 == 0)
    {
        goto LD; // [356] 382
    }
    else{
    }

    /** 			inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52704 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ret_pc_53025 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_66inline_code_52704)){
            _27389 = SEQ_PTR(_66inline_code_52704)->length;
    }
    else {
        _27389 = 1;
    }
    _27390 = _27389 + 1;
    _27389 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _27390;
    if( _1 != _27390 ){
        DeRef(_1);
    }
    _27390 = NOVALUE;
    _27387 = NOVALUE;
LD: 

    /** 		return 1*/
    DeRef(_code_53024);
    DeRef(_27341);
    _27341 = NOVALUE;
    DeRef(_27352);
    _27352 = NOVALUE;
    DeRef(_27355);
    _27355 = NOVALUE;
    DeRef(_27367);
    _27367 = NOVALUE;
    DeRef(_27359);
    _27359 = NOVALUE;
    DeRef(_27371);
    _27371 = NOVALUE;
    DeRef(_27374);
    _27374 = NOVALUE;
    DeRef(_27379);
    _27379 = NOVALUE;
    return 1;
    goto LE; // [390] 502
L7: 

    /** 		sequence code = {ASSIGN, retsym, {INLINE_TARGET}}*/
    _0 = _code_53070;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 18;
    *((int *)(_2+8)) = _retsym_52991;
    RefDS(_27370);
    *((int *)(_2+12)) = _27370;
    _code_53070 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 		if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_66inline_code_52704)){
            _27392 = SEQ_PTR(_66inline_code_52704)->length;
    }
    else {
        _27392 = 1;
    }
    _27393 = 3 + _26TRANSLATE_11619;
    _27394 = _27392 - _27393;
    _27392 = NOVALUE;
    _27393 = NOVALUE;
    if (_pc_52989 == _27394)
    goto LF; // [420] 441

    /** 			code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = -1;
    _27396 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 23;
    ((int *)_2)[2] = _27396;
    _27397 = MAKE_SEQ(_1);
    _27396 = NOVALUE;
    Concat((object_ptr)&_code_53070, _code_53070, _27397);
    DeRefDS(_27397);
    _27397 = NOVALUE;
LF: 

    /** 		replace_code( code, pc, pc + 3 )*/
    _27399 = _pc_52989 + 3;
    if ((long)((unsigned long)_27399 + (unsigned long)HIGH_BITS) >= 0) 
    _27399 = NewDouble((double)_27399);
    RefDS(_code_53070);
    _66replace_code(_code_53070, _pc_52989, _27399);
    _27399 = NOVALUE;

    /** 		integer ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = -1;
    _27400 = MAKE_SEQ(_1);
    _ret_pc_53084 = find_from(_27400, _66inline_code_52704, _pc_52989);
    DeRefDS(_27400);
    _27400 = NOVALUE;

    /** 		if ret_pc then*/
    if (_ret_pc_53084 == 0)
    {
        goto L10; // [467] 493
    }
    else{
    }

    /** 			inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52704 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ret_pc_53084 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_66inline_code_52704)){
            _27404 = SEQ_PTR(_66inline_code_52704)->length;
    }
    else {
        _27404 = 1;
    }
    _27405 = _27404 + 1;
    _27404 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _27405;
    if( _1 != _27405 ){
        DeRef(_1);
    }
    _27405 = NOVALUE;
    _27402 = NOVALUE;
L10: 

    /** 		return 1*/
    DeRef(_code_53070);
    DeRef(_27341);
    _27341 = NOVALUE;
    DeRef(_27352);
    _27352 = NOVALUE;
    DeRef(_27355);
    _27355 = NOVALUE;
    DeRef(_27367);
    _27367 = NOVALUE;
    DeRef(_27359);
    _27359 = NOVALUE;
    DeRef(_27371);
    _27371 = NOVALUE;
    DeRef(_27374);
    _27374 = NOVALUE;
    DeRef(_27379);
    _27379 = NOVALUE;
    DeRef(_27394);
    _27394 = NOVALUE;
    return 1;
LE: 

    /** 	return 0*/
    DeRef(_27341);
    _27341 = NOVALUE;
    DeRef(_27352);
    _27352 = NOVALUE;
    DeRef(_27355);
    _27355 = NOVALUE;
    DeRef(_27367);
    _27367 = NOVALUE;
    DeRef(_27359);
    _27359 = NOVALUE;
    DeRef(_27371);
    _27371 = NOVALUE;
    DeRef(_27374);
    _27374 = NOVALUE;
    DeRef(_27379);
    _27379 = NOVALUE;
    DeRef(_27394);
    _27394 = NOVALUE;
    return 0;
    ;
}


int _66inline_op(int _pc_53094)
{
    int _op_53095 = NOVALUE;
    int _code_53100 = NOVALUE;
    int _stlen_53133 = NOVALUE;
    int _file_53138 = NOVALUE;
    int _ok_53143 = NOVALUE;
    int _original_table_53166 = NOVALUE;
    int _jump_table_53170 = NOVALUE;
    int _27466 = NOVALUE;
    int _27465 = NOVALUE;
    int _27464 = NOVALUE;
    int _27463 = NOVALUE;
    int _27462 = NOVALUE;
    int _27461 = NOVALUE;
    int _27460 = NOVALUE;
    int _27459 = NOVALUE;
    int _27458 = NOVALUE;
    int _27457 = NOVALUE;
    int _27456 = NOVALUE;
    int _27455 = NOVALUE;
    int _27452 = NOVALUE;
    int _27451 = NOVALUE;
    int _27450 = NOVALUE;
    int _27449 = NOVALUE;
    int _27447 = NOVALUE;
    int _27445 = NOVALUE;
    int _27444 = NOVALUE;
    int _27442 = NOVALUE;
    int _27438 = NOVALUE;
    int _27437 = NOVALUE;
    int _27436 = NOVALUE;
    int _27435 = NOVALUE;
    int _27434 = NOVALUE;
    int _27433 = NOVALUE;
    int _27430 = NOVALUE;
    int _27429 = NOVALUE;
    int _27427 = NOVALUE;
    int _27426 = NOVALUE;
    int _27424 = NOVALUE;
    int _27422 = NOVALUE;
    int _27421 = NOVALUE;
    int _27420 = NOVALUE;
    int _27419 = NOVALUE;
    int _27418 = NOVALUE;
    int _27417 = NOVALUE;
    int _27416 = NOVALUE;
    int _27414 = NOVALUE;
    int _27413 = NOVALUE;
    int _27412 = NOVALUE;
    int _27410 = NOVALUE;
    int _27409 = NOVALUE;
    int _27408 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer op = inline_code[pc]*/
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    _op_53095 = (int)*(((s1_ptr)_2)->base + _pc_53094);
    if (!IS_ATOM_INT(_op_53095))
    _op_53095 = (long)DBL_PTR(_op_53095)->dbl;

    /** 	if op = RETURNP then*/
    if (_op_53095 != 29)
    goto L1; // [15] 150

    /** 		sequence code = ""*/
    RefDS(_22037);
    DeRef(_code_53100);
    _code_53100 = _22037;

    /** 		if pc != length( inline_code ) - 1 - TRANSLATE then*/
    if (IS_SEQUENCE(_66inline_code_52704)){
            _27408 = SEQ_PTR(_66inline_code_52704)->length;
    }
    else {
        _27408 = 1;
    }
    _27409 = _27408 - 1;
    _27408 = NOVALUE;
    _27410 = _27409 - _26TRANSLATE_11619;
    _27409 = NOVALUE;
    if (_pc_53094 == _27410)
    goto L2; // [43] 92

    /** 			code = { ELSE, {INLINE_ADDR, length( inline_code ) + 1 }}*/
    if (IS_SEQUENCE(_66inline_code_52704)){
            _27412 = SEQ_PTR(_66inline_code_52704)->length;
    }
    else {
        _27412 = 1;
    }
    _27413 = _27412 + 1;
    _27412 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = _27413;
    _27414 = MAKE_SEQ(_1);
    _27413 = NOVALUE;
    DeRefDS(_code_53100);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 23;
    ((int *)_2)[2] = _27414;
    _code_53100 = MAKE_SEQ(_1);
    _27414 = NOVALUE;

    /** 			if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L3; // [72] 134
    }
    else{
    }

    /** 				inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_66inline_code_52704)){
            _27416 = SEQ_PTR(_66inline_code_52704)->length;
    }
    else {
        _27416 = 1;
    }
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52704 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27416);
    _1 = *(int *)_2;
    *(int *)_2 = 159;
    DeRef(_1);
    goto L3; // [89] 134
L2: 

    /** 		elsif TRANSLATE and inline_code[$] = BADRETURNF then*/
    if (_26TRANSLATE_11619 == 0) {
        goto L4; // [96] 133
    }
    if (IS_SEQUENCE(_66inline_code_52704)){
            _27418 = SEQ_PTR(_66inline_code_52704)->length;
    }
    else {
        _27418 = 1;
    }
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    _27419 = (int)*(((s1_ptr)_2)->base + _27418);
    if (IS_ATOM_INT(_27419)) {
        _27420 = (_27419 == 43);
    }
    else {
        _27420 = binary_op(EQUALS, _27419, 43);
    }
    _27419 = NOVALUE;
    if (_27420 == 0) {
        DeRef(_27420);
        _27420 = NOVALUE;
        goto L4; // [116] 133
    }
    else {
        if (!IS_ATOM_INT(_27420) && DBL_PTR(_27420)->dbl == 0.0){
            DeRef(_27420);
            _27420 = NOVALUE;
            goto L4; // [116] 133
        }
        DeRef(_27420);
        _27420 = NOVALUE;
    }
    DeRef(_27420);
    _27420 = NOVALUE;

    /** 			inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_66inline_code_52704)){
            _27421 = SEQ_PTR(_66inline_code_52704)->length;
    }
    else {
        _27421 = 1;
    }
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52704 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27421);
    _1 = *(int *)_2;
    *(int *)_2 = 159;
    DeRef(_1);
L4: 
L3: 

    /** 		replace_code( code, pc, pc + 2 )*/
    _27422 = _pc_53094 + 2;
    if ((long)((unsigned long)_27422 + (unsigned long)HIGH_BITS) >= 0) 
    _27422 = NewDouble((double)_27422);
    RefDS(_code_53100);
    _66replace_code(_code_53100, _pc_53094, _27422);
    _27422 = NOVALUE;
    DeRefDS(_code_53100);
    _code_53100 = NOVALUE;
    goto L5; // [147] 526
L1: 

    /** 	elsif op = RETURNF then*/
    if (_op_53095 != 28)
    goto L6; // [154] 171

    /** 		return returnf( pc )*/
    _27424 = _66returnf(_pc_53094);
    DeRef(_27410);
    _27410 = NOVALUE;
    return _27424;
    goto L5; // [168] 526
L6: 

    /** 	elsif op = ROUTINE_ID then*/
    if (_op_53095 != 134)
    goto L7; // [175] 273

    /** 		integer*/

    /** 			stlen = inline_code[pc+2+TRANSLATE],*/
    _27426 = _pc_53094 + 2;
    if ((long)((unsigned long)_27426 + (unsigned long)HIGH_BITS) >= 0) 
    _27426 = NewDouble((double)_27426);
    if (IS_ATOM_INT(_27426)) {
        _27427 = _27426 + _26TRANSLATE_11619;
    }
    else {
        _27427 = NewDouble(DBL_PTR(_27426)->dbl + (double)_26TRANSLATE_11619);
    }
    DeRef(_27426);
    _27426 = NOVALUE;
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    if (!IS_ATOM_INT(_27427)){
        _stlen_53133 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27427)->dbl));
    }
    else{
        _stlen_53133 = (int)*(((s1_ptr)_2)->base + _27427);
    }
    if (!IS_ATOM_INT(_stlen_53133))
    _stlen_53133 = (long)DBL_PTR(_stlen_53133)->dbl;

    /** 			file  = inline_code[pc+4+TRANSLATE],*/
    _27429 = _pc_53094 + 4;
    if ((long)((unsigned long)_27429 + (unsigned long)HIGH_BITS) >= 0) 
    _27429 = NewDouble((double)_27429);
    if (IS_ATOM_INT(_27429)) {
        _27430 = _27429 + _26TRANSLATE_11619;
    }
    else {
        _27430 = NewDouble(DBL_PTR(_27429)->dbl + (double)_26TRANSLATE_11619);
    }
    DeRef(_27429);
    _27429 = NOVALUE;
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    if (!IS_ATOM_INT(_27430)){
        _file_53138 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27430)->dbl));
    }
    else{
        _file_53138 = (int)*(((s1_ptr)_2)->base + _27430);
    }
    if (!IS_ATOM_INT(_file_53138))
    _file_53138 = (long)DBL_PTR(_file_53138)->dbl;

    /** 			ok    = adjust_il( pc, op )*/
    _ok_53143 = _66adjust_il(_pc_53094, _op_53095);
    if (!IS_ATOM_INT(_ok_53143)) {
        _1 = (long)(DBL_PTR(_ok_53143)->dbl);
        DeRefDS(_ok_53143);
        _ok_53143 = _1;
    }

    /** 		inline_code[pc+2+TRANSLATE] = stlen*/
    _27433 = _pc_53094 + 2;
    if ((long)((unsigned long)_27433 + (unsigned long)HIGH_BITS) >= 0) 
    _27433 = NewDouble((double)_27433);
    if (IS_ATOM_INT(_27433)) {
        _27434 = _27433 + _26TRANSLATE_11619;
    }
    else {
        _27434 = NewDouble(DBL_PTR(_27433)->dbl + (double)_26TRANSLATE_11619);
    }
    DeRef(_27433);
    _27433 = NOVALUE;
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52704 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27434))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_27434)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _27434);
    _1 = *(int *)_2;
    *(int *)_2 = _stlen_53133;
    DeRef(_1);

    /** 		inline_code[pc+4+TRANSLATE] = file*/
    _27435 = _pc_53094 + 4;
    if ((long)((unsigned long)_27435 + (unsigned long)HIGH_BITS) >= 0) 
    _27435 = NewDouble((double)_27435);
    if (IS_ATOM_INT(_27435)) {
        _27436 = _27435 + _26TRANSLATE_11619;
    }
    else {
        _27436 = NewDouble(DBL_PTR(_27435)->dbl + (double)_26TRANSLATE_11619);
    }
    DeRef(_27435);
    _27435 = NOVALUE;
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52704 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27436))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_27436)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _27436);
    _1 = *(int *)_2;
    *(int *)_2 = _file_53138;
    DeRef(_1);

    /** 		return ok*/
    DeRef(_27424);
    _27424 = NOVALUE;
    DeRef(_27410);
    _27410 = NOVALUE;
    DeRef(_27427);
    _27427 = NOVALUE;
    DeRef(_27430);
    _27430 = NOVALUE;
    DeRef(_27434);
    _27434 = NOVALUE;
    DeRef(_27436);
    _27436 = NOVALUE;
    return _ok_53143;
    goto L5; // [270] 526
L7: 

    /** 	elsif op_info[op][OP_SIZE_TYPE] = FIXED_SIZE then*/
    _2 = (int)SEQ_PTR(_64op_info_26647);
    _27437 = (int)*(((s1_ptr)_2)->base + _op_53095);
    _2 = (int)SEQ_PTR(_27437);
    _27438 = (int)*(((s1_ptr)_2)->base + 1);
    _27437 = NOVALUE;
    if (binary_op_a(NOTEQ, _27438, 1)){
        _27438 = NOVALUE;
        goto L8; // [289] 397
    }
    _27438 = NOVALUE;

    /** 		switch op do*/
    _0 = _op_53095;
    switch ( _0 ){ 

        /** 			case SWITCH, SWITCH_RT, SWITCH_I, SWITCH_SPI then*/
        case 185:
        case 202:
        case 193:
        case 192:

        /** 				symtab_index original_table = inline_code[pc + 3]*/
        _27442 = _pc_53094 + 3;
        _2 = (int)SEQ_PTR(_66inline_code_52704);
        _original_table_53166 = (int)*(((s1_ptr)_2)->base + _27442);
        if (!IS_ATOM_INT(_original_table_53166)){
            _original_table_53166 = (long)DBL_PTR(_original_table_53166)->dbl;
        }

        /** 				symtab_index jump_table = NewStringSym( {-2, length(SymTab) } )*/
        if (IS_SEQUENCE(_27SymTab_10921)){
                _27444 = SEQ_PTR(_27SymTab_10921)->length;
        }
        else {
            _27444 = 1;
        }
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -2;
        ((int *)_2)[2] = _27444;
        _27445 = MAKE_SEQ(_1);
        _27444 = NOVALUE;
        _jump_table_53170 = _52NewStringSym(_27445);
        _27445 = NOVALUE;
        if (!IS_ATOM_INT(_jump_table_53170)) {
            _1 = (long)(DBL_PTR(_jump_table_53170)->dbl);
            DeRefDS(_jump_table_53170);
            _jump_table_53170 = _1;
        }

        /** 				SymTab[jump_table][S_OBJ] = SymTab[original_table][S_OBJ]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_jump_table_53170 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27449 = (int)*(((s1_ptr)_2)->base + _original_table_53166);
        _2 = (int)SEQ_PTR(_27449);
        _27450 = (int)*(((s1_ptr)_2)->base + 1);
        _27449 = NOVALUE;
        Ref(_27450);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _27450;
        if( _1 != _27450 ){
            DeRef(_1);
        }
        _27450 = NOVALUE;
        _27447 = NOVALUE;

        /** 				inline_code[pc+3] = jump_table*/
        _27451 = _pc_53094 + 3;
        _2 = (int)SEQ_PTR(_66inline_code_52704);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _66inline_code_52704 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _27451);
        _1 = *(int *)_2;
        *(int *)_2 = _jump_table_53170;
        DeRef(_1);
    ;}
    /** 		return adjust_il( pc, op )*/
    _27452 = _66adjust_il(_pc_53094, _op_53095);
    DeRef(_27424);
    _27424 = NOVALUE;
    DeRef(_27410);
    _27410 = NOVALUE;
    DeRef(_27442);
    _27442 = NOVALUE;
    DeRef(_27427);
    _27427 = NOVALUE;
    DeRef(_27430);
    _27430 = NOVALUE;
    DeRef(_27434);
    _27434 = NOVALUE;
    DeRef(_27436);
    _27436 = NOVALUE;
    DeRef(_27451);
    _27451 = NOVALUE;
    return _27452;
    goto L5; // [394] 526
L8: 

    /** 		switch op with fallthru do*/
    _0 = _op_53095;
    switch ( _0 ){ 

        /** 			case REF_TEMP then*/
        case 207:

        /** 				inline_code[pc+1] = {INLINE_TARGET}*/
        _27455 = _pc_53094 + 1;
        RefDS(_27370);
        _2 = (int)SEQ_PTR(_66inline_code_52704);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _66inline_code_52704 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _27455);
        _1 = *(int *)_2;
        *(int *)_2 = _27370;
        DeRef(_1);

        /** 			case CONCAT_N then*/
        case 157:
        case 31:

        /** 				if check_for_param( pc + 2 + inline_code[pc+1] ) then*/
        _27456 = _pc_53094 + 2;
        if ((long)((unsigned long)_27456 + (unsigned long)HIGH_BITS) >= 0) 
        _27456 = NewDouble((double)_27456);
        _27457 = _pc_53094 + 1;
        _2 = (int)SEQ_PTR(_66inline_code_52704);
        _27458 = (int)*(((s1_ptr)_2)->base + _27457);
        if (IS_ATOM_INT(_27456) && IS_ATOM_INT(_27458)) {
            _27459 = _27456 + _27458;
            if ((long)((unsigned long)_27459 + (unsigned long)HIGH_BITS) >= 0) 
            _27459 = NewDouble((double)_27459);
        }
        else {
            _27459 = binary_op(PLUS, _27456, _27458);
        }
        DeRef(_27456);
        _27456 = NOVALUE;
        _27458 = NOVALUE;
        _27460 = _66check_for_param(_27459);
        _27459 = NOVALUE;
        if (_27460 == 0) {
            DeRef(_27460);
            _27460 = NOVALUE;
            goto L9; // [450] 454
        }
        else {
            if (!IS_ATOM_INT(_27460) && DBL_PTR(_27460)->dbl == 0.0){
                DeRef(_27460);
                _27460 = NOVALUE;
                goto L9; // [450] 454
            }
            DeRef(_27460);
            _27460 = NOVALUE;
        }
        DeRef(_27460);
        _27460 = NOVALUE;
L9: 

        /** 				for i = pc + 2 to pc + 2 + inline_code[pc+1] do*/
        _27461 = _pc_53094 + 2;
        if ((long)((unsigned long)_27461 + (unsigned long)HIGH_BITS) >= 0) 
        _27461 = NewDouble((double)_27461);
        _27462 = _pc_53094 + 2;
        if ((long)((unsigned long)_27462 + (unsigned long)HIGH_BITS) >= 0) 
        _27462 = NewDouble((double)_27462);
        _27463 = _pc_53094 + 1;
        _2 = (int)SEQ_PTR(_66inline_code_52704);
        _27464 = (int)*(((s1_ptr)_2)->base + _27463);
        if (IS_ATOM_INT(_27462) && IS_ATOM_INT(_27464)) {
            _27465 = _27462 + _27464;
            if ((long)((unsigned long)_27465 + (unsigned long)HIGH_BITS) >= 0) 
            _27465 = NewDouble((double)_27465);
        }
        else {
            _27465 = binary_op(PLUS, _27462, _27464);
        }
        DeRef(_27462);
        _27462 = NOVALUE;
        _27464 = NOVALUE;
        {
            int _i_53202;
            Ref(_27461);
            _i_53202 = _27461;
LA: 
            if (binary_op_a(GREATER, _i_53202, _27465)){
                goto LB; // [478] 508
            }

            /** 					if not adjust_symbol( i ) then*/
            Ref(_i_53202);
            _27466 = _66adjust_symbol(_i_53202);
            if (IS_ATOM_INT(_27466)) {
                if (_27466 != 0){
                    DeRef(_27466);
                    _27466 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            else {
                if (DBL_PTR(_27466)->dbl != 0.0){
                    DeRef(_27466);
                    _27466 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            DeRef(_27466);
            _27466 = NOVALUE;

            /** 						return 0*/
            DeRef(_i_53202);
            DeRef(_27424);
            _27424 = NOVALUE;
            DeRef(_27410);
            _27410 = NOVALUE;
            DeRef(_27442);
            _27442 = NOVALUE;
            DeRef(_27427);
            _27427 = NOVALUE;
            DeRef(_27430);
            _27430 = NOVALUE;
            DeRef(_27434);
            _27434 = NOVALUE;
            DeRef(_27436);
            _27436 = NOVALUE;
            DeRef(_27451);
            _27451 = NOVALUE;
            DeRef(_27452);
            _27452 = NOVALUE;
            DeRef(_27455);
            _27455 = NOVALUE;
            DeRef(_27461);
            _27461 = NOVALUE;
            DeRef(_27457);
            _27457 = NOVALUE;
            DeRef(_27463);
            _27463 = NOVALUE;
            DeRef(_27465);
            _27465 = NOVALUE;
            return 0;
LC: 

            /** 				end for*/
            _0 = _i_53202;
            if (IS_ATOM_INT(_i_53202)) {
                _i_53202 = _i_53202 + 1;
                if ((long)((unsigned long)_i_53202 +(unsigned long) HIGH_BITS) >= 0){
                    _i_53202 = NewDouble((double)_i_53202);
                }
            }
            else {
                _i_53202 = binary_op_a(PLUS, _i_53202, 1);
            }
            DeRef(_0);
            goto LA; // [503] 485
LB: 
            ;
            DeRef(_i_53202);
        }

        /** 				return 1*/
        DeRef(_27424);
        _27424 = NOVALUE;
        DeRef(_27410);
        _27410 = NOVALUE;
        DeRef(_27442);
        _27442 = NOVALUE;
        DeRef(_27427);
        _27427 = NOVALUE;
        DeRef(_27430);
        _27430 = NOVALUE;
        DeRef(_27434);
        _27434 = NOVALUE;
        DeRef(_27436);
        _27436 = NOVALUE;
        DeRef(_27451);
        _27451 = NOVALUE;
        DeRef(_27452);
        _27452 = NOVALUE;
        DeRef(_27455);
        _27455 = NOVALUE;
        DeRef(_27461);
        _27461 = NOVALUE;
        DeRef(_27457);
        _27457 = NOVALUE;
        DeRef(_27463);
        _27463 = NOVALUE;
        DeRef(_27465);
        _27465 = NOVALUE;
        return 1;

        /** 			case else*/
        default:

        /** 				return 0*/
        DeRef(_27424);
        _27424 = NOVALUE;
        DeRef(_27410);
        _27410 = NOVALUE;
        DeRef(_27442);
        _27442 = NOVALUE;
        DeRef(_27427);
        _27427 = NOVALUE;
        DeRef(_27430);
        _27430 = NOVALUE;
        DeRef(_27434);
        _27434 = NOVALUE;
        DeRef(_27436);
        _27436 = NOVALUE;
        DeRef(_27451);
        _27451 = NOVALUE;
        DeRef(_27452);
        _27452 = NOVALUE;
        DeRef(_27455);
        _27455 = NOVALUE;
        DeRef(_27461);
        _27461 = NOVALUE;
        DeRef(_27457);
        _27457 = NOVALUE;
        DeRef(_27463);
        _27463 = NOVALUE;
        DeRef(_27465);
        _27465 = NOVALUE;
        return 0;
    ;}L5: 

    /** 	return 1*/
    DeRef(_27424);
    _27424 = NOVALUE;
    DeRef(_27410);
    _27410 = NOVALUE;
    DeRef(_27442);
    _27442 = NOVALUE;
    DeRef(_27427);
    _27427 = NOVALUE;
    DeRef(_27430);
    _27430 = NOVALUE;
    DeRef(_27434);
    _27434 = NOVALUE;
    DeRef(_27436);
    _27436 = NOVALUE;
    DeRef(_27451);
    _27451 = NOVALUE;
    DeRef(_27452);
    _27452 = NOVALUE;
    DeRef(_27455);
    _27455 = NOVALUE;
    DeRef(_27461);
    _27461 = NOVALUE;
    DeRef(_27457);
    _27457 = NOVALUE;
    DeRef(_27463);
    _27463 = NOVALUE;
    DeRef(_27465);
    _27465 = NOVALUE;
    return 1;
    ;
}


void _66restore_code()
{
    int _27468 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length( temp_code ) then*/
    if (IS_SEQUENCE(_66temp_code_53212)){
            _27468 = SEQ_PTR(_66temp_code_53212)->length;
    }
    else {
        _27468 = 1;
    }
    if (_27468 == 0)
    {
        _27468 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _27468 = NOVALUE;
    }

    /** 		Code = temp_code*/
    RefDS(_66temp_code_53212);
    DeRef(_26Code_12071);
    _26Code_12071 = _66temp_code_53212;
L1: 

    /** end procedure*/
    return;
    ;
}


void _66check_inline(int _sub_53221)
{
    int _pc_53250 = NOVALUE;
    int _s_53252 = NOVALUE;
    int _backpatch_op_53290 = NOVALUE;
    int _op_53294 = NOVALUE;
    int _rtn_idx_53305 = NOVALUE;
    int _args_53310 = NOVALUE;
    int _args_53342 = NOVALUE;
    int _values_53371 = NOVALUE;
    int _27555 = NOVALUE;
    int _27554 = NOVALUE;
    int _27552 = NOVALUE;
    int _27549 = NOVALUE;
    int _27547 = NOVALUE;
    int _27546 = NOVALUE;
    int _27545 = NOVALUE;
    int _27543 = NOVALUE;
    int _27542 = NOVALUE;
    int _27541 = NOVALUE;
    int _27540 = NOVALUE;
    int _27539 = NOVALUE;
    int _27538 = NOVALUE;
    int _27537 = NOVALUE;
    int _27536 = NOVALUE;
    int _27535 = NOVALUE;
    int _27533 = NOVALUE;
    int _27532 = NOVALUE;
    int _27531 = NOVALUE;
    int _27530 = NOVALUE;
    int _27529 = NOVALUE;
    int _27527 = NOVALUE;
    int _27526 = NOVALUE;
    int _27525 = NOVALUE;
    int _27524 = NOVALUE;
    int _27523 = NOVALUE;
    int _27521 = NOVALUE;
    int _27520 = NOVALUE;
    int _27519 = NOVALUE;
    int _27518 = NOVALUE;
    int _27517 = NOVALUE;
    int _27516 = NOVALUE;
    int _27515 = NOVALUE;
    int _27514 = NOVALUE;
    int _27513 = NOVALUE;
    int _27512 = NOVALUE;
    int _27511 = NOVALUE;
    int _27510 = NOVALUE;
    int _27509 = NOVALUE;
    int _27508 = NOVALUE;
    int _27506 = NOVALUE;
    int _27503 = NOVALUE;
    int _27498 = NOVALUE;
    int _27496 = NOVALUE;
    int _27493 = NOVALUE;
    int _27492 = NOVALUE;
    int _27491 = NOVALUE;
    int _27490 = NOVALUE;
    int _27489 = NOVALUE;
    int _27488 = NOVALUE;
    int _27487 = NOVALUE;
    int _27486 = NOVALUE;
    int _27484 = NOVALUE;
    int _27482 = NOVALUE;
    int _27481 = NOVALUE;
    int _27479 = NOVALUE;
    int _27477 = NOVALUE;
    int _27475 = NOVALUE;
    int _27473 = NOVALUE;
    int _27472 = NOVALUE;
    int _27471 = NOVALUE;
    int _27470 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sub_53221)) {
        _1 = (long)(DBL_PTR(_sub_53221)->dbl);
        DeRefDS(_sub_53221);
        _sub_53221 = _1;
    }

    /** 	if OpTrace or SymTab[sub][S_TOKEN] = TYPE then*/
    if (_26OpTrace_12052 != 0) {
        goto L1; // [7] 34
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27470 = (int)*(((s1_ptr)_2)->base + _sub_53221);
    _2 = (int)SEQ_PTR(_27470);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _27471 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _27471 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _27470 = NOVALUE;
    if (IS_ATOM_INT(_27471)) {
        _27472 = (_27471 == 504);
    }
    else {
        _27472 = binary_op(EQUALS, _27471, 504);
    }
    _27471 = NOVALUE;
    if (_27472 == 0) {
        DeRef(_27472);
        _27472 = NOVALUE;
        goto L2; // [30] 40
    }
    else {
        if (!IS_ATOM_INT(_27472) && DBL_PTR(_27472)->dbl == 0.0){
            DeRef(_27472);
            _27472 = NOVALUE;
            goto L2; // [30] 40
        }
        DeRef(_27472);
        _27472 = NOVALUE;
    }
    DeRef(_27472);
    _27472 = NOVALUE;
L1: 

    /** 		return*/
    DeRefi(_backpatch_op_53290);
    return;
L2: 

    /** 	inline_sub      = sub*/
    _66inline_sub_52718 = _sub_53221;

    /** 	if get_fwdref_count() then*/
    _27473 = _29get_fwdref_count();
    if (_27473 == 0) {
        DeRef(_27473);
        _27473 = NOVALUE;
        goto L3; // [52] 65
    }
    else {
        if (!IS_ATOM_INT(_27473) && DBL_PTR(_27473)->dbl == 0.0){
            DeRef(_27473);
            _27473 = NOVALUE;
            goto L3; // [52] 65
        }
        DeRef(_27473);
        _27473 = NOVALUE;
    }
    DeRef(_27473);
    _27473 = NOVALUE;

    /** 		defer()*/
    _66defer();

    /** 		return*/
    DeRefi(_backpatch_op_53290);
    return;
L3: 

    /** 	temp_code = ""*/
    RefDS(_22037);
    DeRef(_66temp_code_53212);
    _66temp_code_53212 = _22037;

    /** 	if sub != CurrentSub then*/
    if (_sub_53221 == _26CurrentSub_11990)
    goto L4; // [76] 99

    /** 		Code = SymTab[sub][S_CODE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27475 = (int)*(((s1_ptr)_2)->base + _sub_53221);
    DeRef(_26Code_12071);
    _2 = (int)SEQ_PTR(_27475);
    if (!IS_ATOM_INT(_26S_CODE_11666)){
        _26Code_12071 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
    }
    else{
        _26Code_12071 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
    }
    Ref(_26Code_12071);
    _27475 = NOVALUE;
    goto L5; // [96] 109
L4: 

    /** 		temp_code = Code*/
    RefDS(_26Code_12071);
    DeRef(_66temp_code_53212);
    _66temp_code_53212 = _26Code_12071;
L5: 

    /** 	if length(Code) > OpInline then*/
    if (IS_SEQUENCE(_26Code_12071)){
            _27477 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _27477 = 1;
    }
    if (_27477 <= _26OpInline_12057)
    goto L6; // [118] 128

    /** 		return*/
    DeRefi(_backpatch_op_53290);
    return;
L6: 

    /** 	inline_code     = Code*/
    RefDS(_26Code_12071);
    DeRef(_66inline_code_52704);
    _66inline_code_52704 = _26Code_12071;

    /** 	return_gotos    = 0*/
    _66return_gotos_52713 = 0;

    /** 	prev_pc         = 1*/
    _66prev_pc_52712 = 1;

    /** 	proc_vars       = {}*/
    RefDS(_22037);
    DeRefi(_66proc_vars_52705);
    _66proc_vars_52705 = _22037;

    /** 	inline_temps    = {}*/
    RefDS(_22037);
    DeRef(_66inline_temps_52706);
    _66inline_temps_52706 = _22037;

    /** 	inline_params   = {}*/
    RefDS(_22037);
    DeRefi(_66inline_params_52709);
    _66inline_params_52709 = _22037;

    /** 	assigned_params = {}*/
    RefDS(_22037);
    DeRef(_66assigned_params_52710);
    _66assigned_params_52710 = _22037;

    /** 	integer pc = 1*/
    _pc_53250 = 1;

    /** 	symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27479 = (int)*(((s1_ptr)_2)->base + _sub_53221);
    _2 = (int)SEQ_PTR(_27479);
    _s_53252 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_53252)){
        _s_53252 = (long)DBL_PTR(_s_53252)->dbl;
    }
    _27479 = NOVALUE;

    /** 	for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27481 = (int)*(((s1_ptr)_2)->base + _sub_53221);
    _2 = (int)SEQ_PTR(_27481);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _27482 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _27482 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _27481 = NOVALUE;
    {
        int _p_53258;
        _p_53258 = 1;
L7: 
        if (binary_op_a(GREATER, _p_53258, _27482)){
            goto L8; // [210] 248
        }

        /** 		inline_params &= s*/
        Append(&_66inline_params_52709, _66inline_params_52709, _s_53252);

        /** 		s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27484 = (int)*(((s1_ptr)_2)->base + _s_53252);
        _2 = (int)SEQ_PTR(_27484);
        _s_53252 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_53252)){
            _s_53252 = (long)DBL_PTR(_s_53252)->dbl;
        }
        _27484 = NOVALUE;

        /** 	end for*/
        _0 = _p_53258;
        if (IS_ATOM_INT(_p_53258)) {
            _p_53258 = _p_53258 + 1;
            if ((long)((unsigned long)_p_53258 +(unsigned long) HIGH_BITS) >= 0){
                _p_53258 = NewDouble((double)_p_53258);
            }
        }
        else {
            _p_53258 = binary_op_a(PLUS, _p_53258, 1);
        }
        DeRef(_0);
        goto L7; // [243] 217
L8: 
        ;
        DeRef(_p_53258);
    }

    /** 	while s != 0 and */
L9: 
    _27486 = (_s_53252 != 0);
    if (_27486 == 0) {
        goto LA; // [257] 335
    }
    _27488 = _52sym_scope(_s_53252);
    if (IS_ATOM_INT(_27488)) {
        _27489 = (_27488 <= 3);
    }
    else {
        _27489 = binary_op(LESSEQ, _27488, 3);
    }
    DeRef(_27488);
    _27488 = NOVALUE;
    if (IS_ATOM_INT(_27489)) {
        if (_27489 != 0) {
            DeRef(_27490);
            _27490 = 1;
            goto LB; // [271] 289
        }
    }
    else {
        if (DBL_PTR(_27489)->dbl != 0.0) {
            DeRef(_27490);
            _27490 = 1;
            goto LB; // [271] 289
        }
    }
    _27491 = _52sym_scope(_s_53252);
    if (IS_ATOM_INT(_27491)) {
        _27492 = (_27491 == 9);
    }
    else {
        _27492 = binary_op(EQUALS, _27491, 9);
    }
    DeRef(_27491);
    _27491 = NOVALUE;
    DeRef(_27490);
    if (IS_ATOM_INT(_27492))
    _27490 = (_27492 != 0);
    else
    _27490 = DBL_PTR(_27492)->dbl != 0.0;
LB: 
    if (_27490 == 0)
    {
        _27490 = NOVALUE;
        goto LA; // [290] 335
    }
    else{
        _27490 = NOVALUE;
    }

    /** 		if sym_scope( s ) != SC_UNDEFINED then*/
    _27493 = _52sym_scope(_s_53252);
    if (binary_op_a(EQUALS, _27493, 9)){
        DeRef(_27493);
        _27493 = NOVALUE;
        goto LC; // [301] 314
    }
    DeRef(_27493);
    _27493 = NOVALUE;

    /** 			proc_vars &= s*/
    Append(&_66proc_vars_52705, _66proc_vars_52705, _s_53252);
LC: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27496 = (int)*(((s1_ptr)_2)->base + _s_53252);
    _2 = (int)SEQ_PTR(_27496);
    _s_53252 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_53252)){
        _s_53252 = (long)DBL_PTR(_s_53252)->dbl;
    }
    _27496 = NOVALUE;

    /** 	end while*/
    goto L9; // [332] 253
LA: 

    /** 	sequence backpatch_op = {}*/
    RefDS(_22037);
    DeRefi(_backpatch_op_53290);
    _backpatch_op_53290 = _22037;

    /** 	while pc < length( inline_code ) do*/
LD: 
    if (IS_SEQUENCE(_66inline_code_52704)){
            _27498 = SEQ_PTR(_66inline_code_52704)->length;
    }
    else {
        _27498 = 1;
    }
    if (_pc_53250 >= _27498)
    goto LE; // [352] 869

    /** 		integer op = inline_code[pc]*/
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    _op_53294 = (int)*(((s1_ptr)_2)->base + _pc_53250);
    if (!IS_ATOM_INT(_op_53294))
    _op_53294 = (long)DBL_PTR(_op_53294)->dbl;

    /** 		switch op do*/
    _0 = _op_53294;
    switch ( _0 ){ 

        /** 			case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** 				defer()*/
        _66defer();

        /** 				restore_code()*/
        _66restore_code();

        /** 				return*/
        DeRefi(_backpatch_op_53290);
        _27482 = NOVALUE;
        DeRef(_27486);
        _27486 = NOVALUE;
        DeRef(_27489);
        _27489 = NOVALUE;
        DeRef(_27492);
        _27492 = NOVALUE;
        return;
        goto LF; // [390] 851

        /** 			case PROC, FUNC then*/
        case 27:
        case 501:

        /** 				symtab_index rtn_idx = inline_code[pc+1]*/
        _27503 = _pc_53250 + 1;
        _2 = (int)SEQ_PTR(_66inline_code_52704);
        _rtn_idx_53305 = (int)*(((s1_ptr)_2)->base + _27503);
        if (!IS_ATOM_INT(_rtn_idx_53305)){
            _rtn_idx_53305 = (long)DBL_PTR(_rtn_idx_53305)->dbl;
        }

        /** 				if rtn_idx = sub then*/
        if (_rtn_idx_53305 != _sub_53221)
        goto L10; // [414] 428

        /** 					restore_code()*/
        _66restore_code();

        /** 					return*/
        DeRefi(_backpatch_op_53290);
        _27482 = NOVALUE;
        DeRef(_27486);
        _27486 = NOVALUE;
        _27503 = NOVALUE;
        DeRef(_27489);
        _27489 = NOVALUE;
        DeRef(_27492);
        _27492 = NOVALUE;
        return;
L10: 

        /** 				integer args = SymTab[rtn_idx][S_NUM_ARGS]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27506 = (int)*(((s1_ptr)_2)->base + _rtn_idx_53305);
        _2 = (int)SEQ_PTR(_27506);
        if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
            _args_53310 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
        }
        else{
            _args_53310 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
        }
        if (!IS_ATOM_INT(_args_53310)){
            _args_53310 = (long)DBL_PTR(_args_53310)->dbl;
        }
        _27506 = NOVALUE;

        /** 				if SymTab[rtn_idx][S_TOKEN] != PROC and check_for_param( pc + args + 2 ) then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27508 = (int)*(((s1_ptr)_2)->base + _rtn_idx_53305);
        _2 = (int)SEQ_PTR(_27508);
        if (!IS_ATOM_INT(_26S_TOKEN_11659)){
            _27509 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
        }
        else{
            _27509 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
        }
        _27508 = NOVALUE;
        if (IS_ATOM_INT(_27509)) {
            _27510 = (_27509 != 27);
        }
        else {
            _27510 = binary_op(NOTEQ, _27509, 27);
        }
        _27509 = NOVALUE;
        if (IS_ATOM_INT(_27510)) {
            if (_27510 == 0) {
                goto L11; // [464] 485
            }
        }
        else {
            if (DBL_PTR(_27510)->dbl == 0.0) {
                goto L11; // [464] 485
            }
        }
        _27512 = _pc_53250 + _args_53310;
        if ((long)((unsigned long)_27512 + (unsigned long)HIGH_BITS) >= 0) 
        _27512 = NewDouble((double)_27512);
        if (IS_ATOM_INT(_27512)) {
            _27513 = _27512 + 2;
            if ((long)((unsigned long)_27513 + (unsigned long)HIGH_BITS) >= 0) 
            _27513 = NewDouble((double)_27513);
        }
        else {
            _27513 = NewDouble(DBL_PTR(_27512)->dbl + (double)2);
        }
        DeRef(_27512);
        _27512 = NOVALUE;
        _27514 = _66check_for_param(_27513);
        _27513 = NOVALUE;
        if (_27514 == 0) {
            DeRef(_27514);
            _27514 = NOVALUE;
            goto L11; // [481] 485
        }
        else {
            if (!IS_ATOM_INT(_27514) && DBL_PTR(_27514)->dbl == 0.0){
                DeRef(_27514);
                _27514 = NOVALUE;
                goto L11; // [481] 485
            }
            DeRef(_27514);
            _27514 = NOVALUE;
        }
        DeRef(_27514);
        _27514 = NOVALUE;
L11: 

        /** 				for i = 2 to args + 1 + (SymTab[rtn_idx][S_TOKEN] != PROC) do*/
        _27515 = _args_53310 + 1;
        if (_27515 > MAXINT){
            _27515 = NewDouble((double)_27515);
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27516 = (int)*(((s1_ptr)_2)->base + _rtn_idx_53305);
        _2 = (int)SEQ_PTR(_27516);
        if (!IS_ATOM_INT(_26S_TOKEN_11659)){
            _27517 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
        }
        else{
            _27517 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
        }
        _27516 = NOVALUE;
        if (IS_ATOM_INT(_27517)) {
            _27518 = (_27517 != 27);
        }
        else {
            _27518 = binary_op(NOTEQ, _27517, 27);
        }
        _27517 = NOVALUE;
        if (IS_ATOM_INT(_27515) && IS_ATOM_INT(_27518)) {
            _27519 = _27515 + _27518;
            if ((long)((unsigned long)_27519 + (unsigned long)HIGH_BITS) >= 0) 
            _27519 = NewDouble((double)_27519);
        }
        else {
            _27519 = binary_op(PLUS, _27515, _27518);
        }
        DeRef(_27515);
        _27515 = NOVALUE;
        DeRef(_27518);
        _27518 = NOVALUE;
        {
            int _i_53327;
            _i_53327 = 2;
L12: 
            if (binary_op_a(GREATER, _i_53327, _27519)){
                goto L13; // [513] 550
            }

            /** 					if not adjust_symbol( pc + i ) then */
            if (IS_ATOM_INT(_i_53327)) {
                _27520 = _pc_53250 + _i_53327;
                if ((long)((unsigned long)_27520 + (unsigned long)HIGH_BITS) >= 0) 
                _27520 = NewDouble((double)_27520);
            }
            else {
                _27520 = NewDouble((double)_pc_53250 + DBL_PTR(_i_53327)->dbl);
            }
            _27521 = _66adjust_symbol(_27520);
            _27520 = NOVALUE;
            if (IS_ATOM_INT(_27521)) {
                if (_27521 != 0){
                    DeRef(_27521);
                    _27521 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            else {
                if (DBL_PTR(_27521)->dbl != 0.0){
                    DeRef(_27521);
                    _27521 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            DeRef(_27521);
            _27521 = NOVALUE;

            /** 						defer()*/
            _66defer();

            /** 						return*/
            DeRef(_i_53327);
            DeRefi(_backpatch_op_53290);
            _27482 = NOVALUE;
            DeRef(_27486);
            _27486 = NOVALUE;
            DeRef(_27503);
            _27503 = NOVALUE;
            DeRef(_27489);
            _27489 = NOVALUE;
            DeRef(_27492);
            _27492 = NOVALUE;
            DeRef(_27510);
            _27510 = NOVALUE;
            DeRef(_27519);
            _27519 = NOVALUE;
            return;
L14: 

            /** 				end for*/
            _0 = _i_53327;
            if (IS_ATOM_INT(_i_53327)) {
                _i_53327 = _i_53327 + 1;
                if ((long)((unsigned long)_i_53327 +(unsigned long) HIGH_BITS) >= 0){
                    _i_53327 = NewDouble((double)_i_53327);
                }
            }
            else {
                _i_53327 = binary_op_a(PLUS, _i_53327, 1);
            }
            DeRef(_0);
            goto L12; // [545] 520
L13: 
            ;
            DeRef(_i_53327);
        }
        goto LF; // [552] 851

        /** 			case RIGHT_BRACE_N then*/
        case 31:

        /** 				sequence args = inline_code[pc+2..inline_code[pc+1] + pc + 1]*/
        _27523 = _pc_53250 + 2;
        if ((long)((unsigned long)_27523 + (unsigned long)HIGH_BITS) >= 0) 
        _27523 = NewDouble((double)_27523);
        _27524 = _pc_53250 + 1;
        _2 = (int)SEQ_PTR(_66inline_code_52704);
        _27525 = (int)*(((s1_ptr)_2)->base + _27524);
        if (IS_ATOM_INT(_27525)) {
            _27526 = _27525 + _pc_53250;
            if ((long)((unsigned long)_27526 + (unsigned long)HIGH_BITS) >= 0) 
            _27526 = NewDouble((double)_27526);
        }
        else {
            _27526 = binary_op(PLUS, _27525, _pc_53250);
        }
        _27525 = NOVALUE;
        if (IS_ATOM_INT(_27526)) {
            _27527 = _27526 + 1;
        }
        else
        _27527 = binary_op(PLUS, 1, _27526);
        DeRef(_27526);
        _27526 = NOVALUE;
        rhs_slice_target = (object_ptr)&_args_53342;
        RHS_Slice(_66inline_code_52704, _27523, _27527);

        /** 				for i = 1 to length(args) - 1 do*/
        if (IS_SEQUENCE(_args_53342)){
                _27529 = SEQ_PTR(_args_53342)->length;
        }
        else {
            _27529 = 1;
        }
        _27530 = _27529 - 1;
        _27529 = NOVALUE;
        {
            int _i_53350;
            _i_53350 = 1;
L15: 
            if (_i_53350 > _27530){
                goto L16; // [598] 644
            }

            /** 					if find( args[i], args, i + 1 ) then*/
            _2 = (int)SEQ_PTR(_args_53342);
            _27531 = (int)*(((s1_ptr)_2)->base + _i_53350);
            _27532 = _i_53350 + 1;
            _27533 = find_from(_27531, _args_53342, _27532);
            _27531 = NOVALUE;
            _27532 = NOVALUE;
            if (_27533 == 0)
            {
                _27533 = NOVALUE;
                goto L17; // [620] 637
            }
            else{
                _27533 = NOVALUE;
            }

            /** 						defer()*/
            _66defer();

            /** 						restore_code()*/
            _66restore_code();

            /** 						return*/
            DeRefDS(_args_53342);
            DeRefi(_backpatch_op_53290);
            _27482 = NOVALUE;
            DeRef(_27486);
            _27486 = NOVALUE;
            DeRef(_27503);
            _27503 = NOVALUE;
            DeRef(_27489);
            _27489 = NOVALUE;
            DeRef(_27492);
            _27492 = NOVALUE;
            DeRef(_27523);
            _27523 = NOVALUE;
            DeRef(_27510);
            _27510 = NOVALUE;
            DeRef(_27519);
            _27519 = NOVALUE;
            DeRef(_27524);
            _27524 = NOVALUE;
            DeRef(_27527);
            _27527 = NOVALUE;
            DeRef(_27530);
            _27530 = NOVALUE;
            return;
L17: 

            /** 				end for*/
            _i_53350 = _i_53350 + 1;
            goto L15; // [639] 605
L16: 
            ;
        }

        /** 				goto "inline op"*/
        DeRef(_args_53342);
        _args_53342 = NOVALUE;
        goto G18;
        goto LF; // [654] 851

        /** 			case RIGHT_BRACE_2 then*/
        case 85:

        /** 				if equal( inline_code[pc+1], inline_code[pc+2] ) then*/
        _27535 = _pc_53250 + 1;
        _2 = (int)SEQ_PTR(_66inline_code_52704);
        _27536 = (int)*(((s1_ptr)_2)->base + _27535);
        _27537 = _pc_53250 + 2;
        _2 = (int)SEQ_PTR(_66inline_code_52704);
        _27538 = (int)*(((s1_ptr)_2)->base + _27537);
        if (_27536 == _27538)
        _27539 = 1;
        else if (IS_ATOM_INT(_27536) && IS_ATOM_INT(_27538))
        _27539 = 0;
        else
        _27539 = (compare(_27536, _27538) == 0);
        _27536 = NOVALUE;
        _27538 = NOVALUE;
        if (_27539 == 0)
        {
            _27539 = NOVALUE;
            goto L19; // [686] 703
        }
        else{
            _27539 = NOVALUE;
        }

        /** 					defer()*/
        _66defer();

        /** 					restore_code()*/
        _66restore_code();

        /** 					return*/
        DeRefi(_backpatch_op_53290);
        _27482 = NOVALUE;
        DeRef(_27486);
        _27486 = NOVALUE;
        DeRef(_27503);
        _27503 = NOVALUE;
        DeRef(_27489);
        _27489 = NOVALUE;
        DeRef(_27492);
        _27492 = NOVALUE;
        DeRef(_27523);
        _27523 = NOVALUE;
        DeRef(_27510);
        _27510 = NOVALUE;
        DeRef(_27519);
        _27519 = NOVALUE;
        DeRef(_27524);
        _27524 = NOVALUE;
        DeRef(_27527);
        _27527 = NOVALUE;
        DeRef(_27530);
        _27530 = NOVALUE;
        _27535 = NOVALUE;
        _27537 = NOVALUE;
        return;
L19: 

        /** 				goto "inline op"*/
        goto G18;
        goto LF; // [711] 851

        /** 			case EXIT_BLOCK then*/
        case 206:

        /** 				replace_code( "", pc, pc + 1 )*/
        _27540 = _pc_53250 + 1;
        if (_27540 > MAXINT){
            _27540 = NewDouble((double)_27540);
        }
        RefDS(_22037);
        _66replace_code(_22037, _pc_53250, _27540);
        _27540 = NOVALUE;

        /** 				continue*/
        goto LD; // [732] 347
        goto LF; // [734] 851

        /** 			case SWITCH_RT then*/
        case 202:

        /** 				sequence values = SymTab[inline_code[pc+2]][S_OBJ]*/
        _27541 = _pc_53250 + 2;
        _2 = (int)SEQ_PTR(_66inline_code_52704);
        _27542 = (int)*(((s1_ptr)_2)->base + _27541);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!IS_ATOM_INT(_27542)){
            _27543 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27542)->dbl));
        }
        else{
            _27543 = (int)*(((s1_ptr)_2)->base + _27542);
        }
        DeRef(_values_53371);
        _2 = (int)SEQ_PTR(_27543);
        _values_53371 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_values_53371);
        _27543 = NOVALUE;

        /** 				for i = 1 to length( values ) do*/
        if (IS_SEQUENCE(_values_53371)){
                _27545 = SEQ_PTR(_values_53371)->length;
        }
        else {
            _27545 = 1;
        }
        {
            int _i_53379;
            _i_53379 = 1;
L1A: 
            if (_i_53379 > _27545){
                goto L1B; // [771] 811
            }

            /** 					if sequence( values[i] ) then*/
            _2 = (int)SEQ_PTR(_values_53371);
            _27546 = (int)*(((s1_ptr)_2)->base + _i_53379);
            _27547 = IS_SEQUENCE(_27546);
            _27546 = NOVALUE;
            if (_27547 == 0)
            {
                _27547 = NOVALUE;
                goto L1C; // [787] 804
            }
            else{
                _27547 = NOVALUE;
            }

            /** 						defer()*/
            _66defer();

            /** 						restore_code()*/
            _66restore_code();

            /** 						return*/
            DeRefDS(_values_53371);
            DeRefi(_backpatch_op_53290);
            _27482 = NOVALUE;
            DeRef(_27486);
            _27486 = NOVALUE;
            DeRef(_27503);
            _27503 = NOVALUE;
            DeRef(_27489);
            _27489 = NOVALUE;
            DeRef(_27492);
            _27492 = NOVALUE;
            DeRef(_27523);
            _27523 = NOVALUE;
            DeRef(_27510);
            _27510 = NOVALUE;
            DeRef(_27519);
            _27519 = NOVALUE;
            DeRef(_27524);
            _27524 = NOVALUE;
            DeRef(_27527);
            _27527 = NOVALUE;
            DeRef(_27530);
            _27530 = NOVALUE;
            DeRef(_27535);
            _27535 = NOVALUE;
            DeRef(_27541);
            _27541 = NOVALUE;
            DeRef(_27537);
            _27537 = NOVALUE;
            _27542 = NOVALUE;
            return;
L1C: 

            /** 				end for*/
            _i_53379 = _i_53379 + 1;
            goto L1A; // [806] 778
L1B: 
            ;
        }

        /** 				backpatch_op = append( backpatch_op, pc )*/
        Append(&_backpatch_op_53290, _backpatch_op_53290, _pc_53250);
        DeRef(_values_53371);
        _values_53371 = NOVALUE;

        /** 			case else*/
        default:

        /** 			label "inline op"*/
G18:

        /** 				if not inline_op( pc ) then*/
        _27549 = _66inline_op(_pc_53250);
        if (IS_ATOM_INT(_27549)) {
            if (_27549 != 0){
                DeRef(_27549);
                _27549 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        else {
            if (DBL_PTR(_27549)->dbl != 0.0){
                DeRef(_27549);
                _27549 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        DeRef(_27549);
        _27549 = NOVALUE;

        /** 					defer()*/
        _66defer();

        /** 					restore_code()*/
        _66restore_code();

        /** 					return*/
        DeRefi(_backpatch_op_53290);
        _27482 = NOVALUE;
        DeRef(_27486);
        _27486 = NOVALUE;
        DeRef(_27503);
        _27503 = NOVALUE;
        DeRef(_27489);
        _27489 = NOVALUE;
        DeRef(_27492);
        _27492 = NOVALUE;
        DeRef(_27523);
        _27523 = NOVALUE;
        DeRef(_27510);
        _27510 = NOVALUE;
        DeRef(_27519);
        _27519 = NOVALUE;
        DeRef(_27524);
        _27524 = NOVALUE;
        DeRef(_27527);
        _27527 = NOVALUE;
        DeRef(_27530);
        _27530 = NOVALUE;
        DeRef(_27535);
        _27535 = NOVALUE;
        DeRef(_27541);
        _27541 = NOVALUE;
        DeRef(_27537);
        _27537 = NOVALUE;
        _27542 = NOVALUE;
        return;
L1D: 
    ;}LF: 

    /** 		pc = advance( pc, inline_code )*/
    RefDS(_66inline_code_52704);
    _pc_53250 = _66advance(_pc_53250, _66inline_code_52704);
    if (!IS_ATOM_INT(_pc_53250)) {
        _1 = (long)(DBL_PTR(_pc_53250)->dbl);
        DeRefDS(_pc_53250);
        _pc_53250 = _1;
    }

    /** 	end while*/
    goto LD; // [866] 347
LE: 

    /** 	SymTab[sub][S_INLINE] = { sort( assigned_params ), inline_code, backpatch_op }*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sub_53221 + ((s1_ptr)_2)->base);
    RefDS(_66assigned_params_52710);
    _27554 = _24sort(_66assigned_params_52710, 1);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _27554;
    RefDS(_66inline_code_52704);
    *((int *)(_2+8)) = _66inline_code_52704;
    RefDS(_backpatch_op_53290);
    *((int *)(_2+12)) = _backpatch_op_53290;
    _27555 = MAKE_SEQ(_1);
    _27554 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 29);
    _1 = *(int *)_2;
    *(int *)_2 = _27555;
    if( _1 != _27555 ){
        DeRef(_1);
    }
    _27555 = NOVALUE;
    _27552 = NOVALUE;

    /** 	restore_code()*/
    _66restore_code();

    /** end procedure*/
    DeRefDSi(_backpatch_op_53290);
    _27482 = NOVALUE;
    DeRef(_27486);
    _27486 = NOVALUE;
    DeRef(_27503);
    _27503 = NOVALUE;
    DeRef(_27489);
    _27489 = NOVALUE;
    DeRef(_27492);
    _27492 = NOVALUE;
    DeRef(_27523);
    _27523 = NOVALUE;
    DeRef(_27510);
    _27510 = NOVALUE;
    DeRef(_27519);
    _27519 = NOVALUE;
    DeRef(_27524);
    _27524 = NOVALUE;
    DeRef(_27527);
    _27527 = NOVALUE;
    DeRef(_27530);
    _27530 = NOVALUE;
    DeRef(_27535);
    _27535 = NOVALUE;
    DeRef(_27541);
    _27541 = NOVALUE;
    DeRef(_27537);
    _27537 = NOVALUE;
    _27542 = NOVALUE;
    return;
    ;
}


void _66replace_temp(int _pc_53399)
{
    int _temp_num_53400 = NOVALUE;
    int _needed_53403 = NOVALUE;
    int _27568 = NOVALUE;
    int _27567 = NOVALUE;
    int _27566 = NOVALUE;
    int _27565 = NOVALUE;
    int _27563 = NOVALUE;
    int _27561 = NOVALUE;
    int _27558 = NOVALUE;
    int _27556 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer temp_num = inline_code[pc][2]*/
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    _27556 = (int)*(((s1_ptr)_2)->base + _pc_53399);
    _2 = (int)SEQ_PTR(_27556);
    _temp_num_53400 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_temp_num_53400)){
        _temp_num_53400 = (long)DBL_PTR(_temp_num_53400)->dbl;
    }
    _27556 = NOVALUE;

    /** 	integer needed = temp_num - length( inline_temps )*/
    if (IS_SEQUENCE(_66inline_temps_52706)){
            _27558 = SEQ_PTR(_66inline_temps_52706)->length;
    }
    else {
        _27558 = 1;
    }
    _needed_53403 = _temp_num_53400 - _27558;
    _27558 = NOVALUE;

    /** 	if needed > 0 then*/
    if (_needed_53403 <= 0)
    goto L1; // [30] 47

    /** 		inline_temps &= repeat( 0, needed )*/
    _27561 = Repeat(0, _needed_53403);
    Concat((object_ptr)&_66inline_temps_52706, _66inline_temps_52706, _27561);
    DeRefDS(_27561);
    _27561 = NOVALUE;
L1: 

    /** 	if not inline_temps[temp_num] then*/
    _2 = (int)SEQ_PTR(_66inline_temps_52706);
    _27563 = (int)*(((s1_ptr)_2)->base + _temp_num_53400);
    if (IS_ATOM_INT(_27563)) {
        if (_27563 != 0){
            _27563 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    else {
        if (DBL_PTR(_27563)->dbl != 0.0){
            _27563 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    _27563 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L3; // [62] 84
    }
    else{
    }

    /** 			inline_temps[temp_num] = new_inline_var( -temp_num, 0 )*/
    if ((unsigned long)_temp_num_53400 == 0xC0000000)
    _27565 = (int)NewDouble((double)-0xC0000000);
    else
    _27565 = - _temp_num_53400;
    _27566 = _66new_inline_var(_27565, 0);
    _27565 = NOVALUE;
    _2 = (int)SEQ_PTR(_66inline_temps_52706);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_temps_52706 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _temp_num_53400);
    _1 = *(int *)_2;
    *(int *)_2 = _27566;
    if( _1 != _27566 ){
        DeRef(_1);
    }
    _27566 = NOVALUE;
    goto L4; // [81] 99
L3: 

    /** 			inline_temps[temp_num] = NewTempSym( TRUE )*/
    _27567 = _52NewTempSym(_9TRUE_430);
    _2 = (int)SEQ_PTR(_66inline_temps_52706);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_temps_52706 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _temp_num_53400);
    _1 = *(int *)_2;
    *(int *)_2 = _27567;
    if( _1 != _27567 ){
        DeRef(_1);
    }
    _27567 = NOVALUE;
L4: 
L2: 

    /** 	inline_code[pc] = inline_temps[temp_num]*/
    _2 = (int)SEQ_PTR(_66inline_temps_52706);
    _27568 = (int)*(((s1_ptr)_2)->base + _temp_num_53400);
    Ref(_27568);
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52704 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_53399);
    _1 = *(int *)_2;
    *(int *)_2 = _27568;
    if( _1 != _27568 ){
        DeRef(_1);
    }
    _27568 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int _66get_param_sym(int _pc_53425)
{
    int _il_53426 = NOVALUE;
    int _px_53434 = NOVALUE;
    int _27575 = NOVALUE;
    int _27572 = NOVALUE;
    int _27571 = NOVALUE;
    int _27570 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object il = inline_code[pc]*/
    DeRef(_il_53426);
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    _il_53426 = (int)*(((s1_ptr)_2)->base + _pc_53425);
    Ref(_il_53426);

    /** 	if integer( il ) then*/
    if (IS_ATOM_INT(_il_53426))
    _27570 = 1;
    else if (IS_ATOM_DBL(_il_53426))
    _27570 = IS_ATOM_INT(DoubleToInt(_il_53426));
    else
    _27570 = 0;
    if (_27570 == 0)
    {
        _27570 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27570 = NOVALUE;
    }

    /** 		return inline_code[pc]*/
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    _27571 = (int)*(((s1_ptr)_2)->base + _pc_53425);
    Ref(_27571);
    DeRef(_il_53426);
    return _27571;
    goto L2; // [31] 53
L1: 

    /** 	elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_53426)){
            _27572 = SEQ_PTR(_il_53426)->length;
    }
    else {
        _27572 = 1;
    }
    if (_27572 != 1)
    goto L3; // [39] 52

    /** 		return inline_target*/
    DeRef(_il_53426);
    _27571 = NOVALUE;
    return _66inline_target_52711;
L3: 
L2: 

    /** 	integer px = il[2]*/
    _2 = (int)SEQ_PTR(_il_53426);
    _px_53434 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_px_53434)){
        _px_53434 = (long)DBL_PTR(_px_53434)->dbl;
    }

    /** 	return passed_params[px]*/
    _2 = (int)SEQ_PTR(_66passed_params_52707);
    _27575 = (int)*(((s1_ptr)_2)->base + _px_53434);
    Ref(_27575);
    DeRef(_il_53426);
    _27571 = NOVALUE;
    return _27575;
    ;
}


int _66get_original_sym(int _pc_53439)
{
    int _il_53440 = NOVALUE;
    int _px_53448 = NOVALUE;
    int _27582 = NOVALUE;
    int _27579 = NOVALUE;
    int _27578 = NOVALUE;
    int _27577 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_53439)) {
        _1 = (long)(DBL_PTR(_pc_53439)->dbl);
        DeRefDS(_pc_53439);
        _pc_53439 = _1;
    }

    /** 	object il = inline_code[pc]*/
    DeRef(_il_53440);
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    _il_53440 = (int)*(((s1_ptr)_2)->base + _pc_53439);
    Ref(_il_53440);

    /** 	if integer( il ) then*/
    if (IS_ATOM_INT(_il_53440))
    _27577 = 1;
    else if (IS_ATOM_DBL(_il_53440))
    _27577 = IS_ATOM_INT(DoubleToInt(_il_53440));
    else
    _27577 = 0;
    if (_27577 == 0)
    {
        _27577 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27577 = NOVALUE;
    }

    /** 		return inline_code[pc]*/
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    _27578 = (int)*(((s1_ptr)_2)->base + _pc_53439);
    Ref(_27578);
    DeRef(_il_53440);
    return _27578;
    goto L2; // [31] 53
L1: 

    /** 	elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_53440)){
            _27579 = SEQ_PTR(_il_53440)->length;
    }
    else {
        _27579 = 1;
    }
    if (_27579 != 1)
    goto L3; // [39] 52

    /** 		return inline_target*/
    DeRef(_il_53440);
    _27578 = NOVALUE;
    return _66inline_target_52711;
L3: 
L2: 

    /** 	integer px = il[2]*/
    _2 = (int)SEQ_PTR(_il_53440);
    _px_53448 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_px_53448)){
        _px_53448 = (long)DBL_PTR(_px_53448)->dbl;
    }

    /** 	return original_params[px]*/
    _2 = (int)SEQ_PTR(_66original_params_52708);
    _27582 = (int)*(((s1_ptr)_2)->base + _px_53448);
    Ref(_27582);
    DeRef(_il_53440);
    _27578 = NOVALUE;
    return _27582;
    ;
}


void _66replace_var(int _pc_53457)
{
    int _27586 = NOVALUE;
    int _27585 = NOVALUE;
    int _27584 = NOVALUE;
    int _0, _1, _2;
    

    /** 	inline_code[pc] = proc_vars[inline_code[pc][2]]*/
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    _27584 = (int)*(((s1_ptr)_2)->base + _pc_53457);
    _2 = (int)SEQ_PTR(_27584);
    _27585 = (int)*(((s1_ptr)_2)->base + 2);
    _27584 = NOVALUE;
    _2 = (int)SEQ_PTR(_66proc_vars_52705);
    if (!IS_ATOM_INT(_27585)){
        _27586 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27585)->dbl));
    }
    else{
        _27586 = (int)*(((s1_ptr)_2)->base + _27585);
    }
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52704 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_53457);
    _1 = *(int *)_2;
    *(int *)_2 = _27586;
    if( _1 != _27586 ){
        DeRef(_1);
    }
    _27586 = NOVALUE;

    /** end procedure*/
    _27585 = NOVALUE;
    return;
    ;
}


void _66fix_switch_rt(int _pc_53463)
{
    int _value_table_53465 = NOVALUE;
    int _jump_table_53472 = NOVALUE;
    int _27606 = NOVALUE;
    int _27605 = NOVALUE;
    int _27604 = NOVALUE;
    int _27603 = NOVALUE;
    int _27602 = NOVALUE;
    int _27601 = NOVALUE;
    int _27599 = NOVALUE;
    int _27598 = NOVALUE;
    int _27597 = NOVALUE;
    int _27596 = NOVALUE;
    int _27595 = NOVALUE;
    int _27593 = NOVALUE;
    int _27591 = NOVALUE;
    int _27590 = NOVALUE;
    int _27588 = NOVALUE;
    int _27587 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	symtab_index value_table = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_27SymTab_10921)){
            _27587 = SEQ_PTR(_27SymTab_10921)->length;
    }
    else {
        _27587 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _27587;
    _27588 = MAKE_SEQ(_1);
    _27587 = NOVALUE;
    _value_table_53465 = _52NewStringSym(_27588);
    _27588 = NOVALUE;
    if (!IS_ATOM_INT(_value_table_53465)) {
        _1 = (long)(DBL_PTR(_value_table_53465)->dbl);
        DeRefDS(_value_table_53465);
        _value_table_53465 = _1;
    }

    /** 	symtab_index jump_table  = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_27SymTab_10921)){
            _27590 = SEQ_PTR(_27SymTab_10921)->length;
    }
    else {
        _27590 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _27590;
    _27591 = MAKE_SEQ(_1);
    _27590 = NOVALUE;
    _jump_table_53472 = _52NewStringSym(_27591);
    _27591 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_53472)) {
        _1 = (long)(DBL_PTR(_jump_table_53472)->dbl);
        DeRefDS(_jump_table_53472);
        _jump_table_53472 = _1;
    }

    /** 	SymTab[value_table][S_OBJ] = SymTab[inline_code[pc+2]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_value_table_53465 + ((s1_ptr)_2)->base);
    _27595 = _pc_53463 + 2;
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    _27596 = (int)*(((s1_ptr)_2)->base + _27595);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_27596)){
        _27597 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27596)->dbl));
    }
    else{
        _27597 = (int)*(((s1_ptr)_2)->base + _27596);
    }
    _2 = (int)SEQ_PTR(_27597);
    _27598 = (int)*(((s1_ptr)_2)->base + 1);
    _27597 = NOVALUE;
    Ref(_27598);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _27598;
    if( _1 != _27598 ){
        DeRef(_1);
    }
    _27598 = NOVALUE;
    _27593 = NOVALUE;

    /** 	SymTab[jump_table][S_OBJ]  = SymTab[inline_code[pc+3]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_jump_table_53472 + ((s1_ptr)_2)->base);
    _27601 = _pc_53463 + 3;
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    _27602 = (int)*(((s1_ptr)_2)->base + _27601);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_27602)){
        _27603 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27602)->dbl));
    }
    else{
        _27603 = (int)*(((s1_ptr)_2)->base + _27602);
    }
    _2 = (int)SEQ_PTR(_27603);
    _27604 = (int)*(((s1_ptr)_2)->base + 1);
    _27603 = NOVALUE;
    Ref(_27604);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _27604;
    if( _1 != _27604 ){
        DeRef(_1);
    }
    _27604 = NOVALUE;
    _27599 = NOVALUE;

    /** 	inline_code[pc+2] = value_table*/
    _27605 = _pc_53463 + 2;
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52704 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27605);
    _1 = *(int *)_2;
    *(int *)_2 = _value_table_53465;
    DeRef(_1);

    /** 	inline_code[pc+3] = jump_table*/
    _27606 = _pc_53463 + 3;
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66inline_code_52704 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27606);
    _1 = *(int *)_2;
    *(int *)_2 = _jump_table_53472;
    DeRef(_1);

    /** end procedure*/
    _27605 = NOVALUE;
    _27595 = NOVALUE;
    _27596 = NOVALUE;
    _27601 = NOVALUE;
    _27602 = NOVALUE;
    _27606 = NOVALUE;
    return;
    ;
}


void _66fixup_special_op(int _pc_53502)
{
    int _op_53503 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_53502)) {
        _1 = (long)(DBL_PTR(_pc_53502)->dbl);
        DeRefDS(_pc_53502);
        _pc_53502 = _1;
    }

    /** 	integer op = inline_code[pc]*/
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    _op_53503 = (int)*(((s1_ptr)_2)->base + _pc_53502);
    if (!IS_ATOM_INT(_op_53503))
    _op_53503 = (long)DBL_PTR(_op_53503)->dbl;

    /** 	switch op with fallthru do*/
    _0 = _op_53503;
    switch ( _0 ){ 

        /** 		case SWITCH_RT then*/
        case 202:

        /** 			fix_switch_rt( pc )*/
        _66fix_switch_rt(_pc_53502);

        /** 			break*/
        goto L1; // [29] 32
    ;}L1: 

    /** end procedure*/
    return;
    ;
}


int _66new_inline_var(int _ps_53514, int _reuse_53515)
{
    int _var_53517 = NOVALUE;
    int _vtype_53518 = NOVALUE;
    int _name_53519 = NOVALUE;
    int _s_53521 = NOVALUE;
    int _27669 = NOVALUE;
    int _27668 = NOVALUE;
    int _27666 = NOVALUE;
    int _27663 = NOVALUE;
    int _27662 = NOVALUE;
    int _27660 = NOVALUE;
    int _27657 = NOVALUE;
    int _27656 = NOVALUE;
    int _27655 = NOVALUE;
    int _27653 = NOVALUE;
    int _27648 = NOVALUE;
    int _27643 = NOVALUE;
    int _27642 = NOVALUE;
    int _27641 = NOVALUE;
    int _27640 = NOVALUE;
    int _27637 = NOVALUE;
    int _27635 = NOVALUE;
    int _27632 = NOVALUE;
    int _27627 = NOVALUE;
    int _27626 = NOVALUE;
    int _27625 = NOVALUE;
    int _27624 = NOVALUE;
    int _27623 = NOVALUE;
    int _27620 = NOVALUE;
    int _27619 = NOVALUE;
    int _27618 = NOVALUE;
    int _27617 = NOVALUE;
    int _27616 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ps_53514)) {
        _1 = (long)(DBL_PTR(_ps_53514)->dbl);
        DeRefDS(_ps_53514);
        _ps_53514 = _1;
    }

    /** 		var = 0, */
    _var_53517 = 0;

    /** 	sequence name*/

    /** 	if reuse then*/

    /** 	if not var then*/

    /** 		if ps > 0 then*/
    if (_ps_53514 <= 0)
    goto L1; // [45] 222

    /** 			s = ps*/
    _s_53521 = _ps_53514;

    /** 			if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L2; // [60] 102
    }
    else{
    }

    /** 				name = sprintf( "%s_inlined_%s", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27616 = (int)*(((s1_ptr)_2)->base + _s_53521);
    _2 = (int)SEQ_PTR(_27616);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _27617 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _27617 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _27616 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27618 = (int)*(((s1_ptr)_2)->base + _66inline_sub_52718);
    _2 = (int)SEQ_PTR(_27618);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _27619 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _27619 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _27618 = NOVALUE;
    Ref(_27619);
    Ref(_27617);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27617;
    ((int *)_2)[2] = _27619;
    _27620 = MAKE_SEQ(_1);
    _27619 = NOVALUE;
    _27617 = NOVALUE;
    DeRefi(_name_53519);
    _name_53519 = EPrintf(-9999999, _27615, _27620);
    DeRefDS(_27620);
    _27620 = NOVALUE;
    goto L3; // [99] 139
L2: 

    /** 				name = sprintf( "%s (from inlined routine '%s'", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27623 = (int)*(((s1_ptr)_2)->base + _s_53521);
    _2 = (int)SEQ_PTR(_27623);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _27624 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _27624 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _27623 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27625 = (int)*(((s1_ptr)_2)->base + _66inline_sub_52718);
    _2 = (int)SEQ_PTR(_27625);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _27626 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _27626 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _27625 = NOVALUE;
    Ref(_27626);
    Ref(_27624);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27624;
    ((int *)_2)[2] = _27626;
    _27627 = MAKE_SEQ(_1);
    _27626 = NOVALUE;
    _27624 = NOVALUE;
    DeRefi(_name_53519);
    _name_53519 = EPrintf(-9999999, _27622, _27627);
    DeRefDS(_27627);
    _27627 = NOVALUE;
L3: 

    /** 			if reuse then*/
    if (_reuse_53515 == 0)
    {
        goto L4; // [141] 163
    }
    else{
    }

    /** 				if not TRANSLATE then*/
    if (_26TRANSLATE_11619 != 0)
    goto L5; // [148] 203

    /** 					name &= ")"*/
    Concat((object_ptr)&_name_53519, _name_53519, _26410);
    goto L5; // [160] 203
L4: 

    /** 				if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L6; // [167] 187
    }
    else{
    }

    /** 					name &= sprintf( "_at_%d", inline_start)*/
    _27632 = EPrintf(-9999999, _27631, _66inline_start_52716);
    Concat((object_ptr)&_name_53519, _name_53519, _27632);
    DeRefDS(_27632);
    _27632 = NOVALUE;
    goto L7; // [184] 202
L6: 

    /** 					name &= sprintf( " at %d)", inline_start)*/
    _27635 = EPrintf(-9999999, _27634, _66inline_start_52716);
    Concat((object_ptr)&_name_53519, _name_53519, _27635);
    DeRefDS(_27635);
    _27635 = NOVALUE;
L7: 
L5: 

    /** 			vtype = SymTab[s][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27637 = (int)*(((s1_ptr)_2)->base + _s_53521);
    _2 = (int)SEQ_PTR(_27637);
    _vtype_53518 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_vtype_53518)){
        _vtype_53518 = (long)DBL_PTR(_vtype_53518)->dbl;
    }
    _27637 = NOVALUE;
    goto L8; // [219] 286
L1: 

    /** 			name = sprintf( "%s_%d", {SymTab[inline_sub][S_NAME], -ps})*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27640 = (int)*(((s1_ptr)_2)->base + _66inline_sub_52718);
    _2 = (int)SEQ_PTR(_27640);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _27641 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _27641 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _27640 = NOVALUE;
    if ((unsigned long)_ps_53514 == 0xC0000000)
    _27642 = (int)NewDouble((double)-0xC0000000);
    else
    _27642 = - _ps_53514;
    Ref(_27641);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27641;
    ((int *)_2)[2] = _27642;
    _27643 = MAKE_SEQ(_1);
    _27642 = NOVALUE;
    _27641 = NOVALUE;
    DeRefi(_name_53519);
    _name_53519 = EPrintf(-9999999, _27639, _27643);
    DeRefDS(_27643);
    _27643 = NOVALUE;

    /** 			if reuse then*/
    if (_reuse_53515 == 0)
    {
        goto L9; // [251] 263
    }
    else{
    }

    /** 				name &= "__tmp"*/
    Concat((object_ptr)&_name_53519, _name_53519, _27645);
    goto LA; // [260] 276
L9: 

    /** 				name &= sprintf( "__tmp_at%d", inline_start)*/
    _27648 = EPrintf(-9999999, _27647, _66inline_start_52716);
    Concat((object_ptr)&_name_53519, _name_53519, _27648);
    DeRefDS(_27648);
    _27648 = NOVALUE;
LA: 

    /** 			vtype = object_type*/
    _vtype_53518 = _52object_type_46130;
L8: 

    /** 		if CurrentSub = TopLevelSub then*/
    if (_26CurrentSub_11990 != _26TopLevelSub_11989)
    goto LB; // [292] 325

    /** 			var = NewEntry( name, varnum, SC_LOCAL, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_53519);
    _var_53517 = _52NewEntry(_name_53519, _66varnum_52715, 5, -100, 2004, 0, _vtype_53518);
    if (!IS_ATOM_INT(_var_53517)) {
        _1 = (long)(DBL_PTR(_var_53517)->dbl);
        DeRefDS(_var_53517);
        _var_53517 = _1;
    }
    goto LC; // [322] 416
LB: 

    /** 			var = NewBasicEntry( name, varnum, SC_PRIVATE, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_53519);
    _var_53517 = _52NewBasicEntry(_name_53519, _66varnum_52715, 3, -100, 2004, 0, _vtype_53518);
    if (!IS_ATOM_INT(_var_53517)) {
        _1 = (long)(DBL_PTR(_var_53517)->dbl);
        DeRefDS(_var_53517);
        _var_53517 = _1;
    }

    /** 			SymTab[var][S_NEXT] = SymTab[last_param][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_var_53517 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27655 = (int)*(((s1_ptr)_2)->base + _66last_param_52719);
    _2 = (int)SEQ_PTR(_27655);
    _27656 = (int)*(((s1_ptr)_2)->base + 2);
    _27655 = NOVALUE;
    Ref(_27656);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _27656;
    if( _1 != _27656 ){
        DeRef(_1);
    }
    _27656 = NOVALUE;
    _27653 = NOVALUE;

    /** 			SymTab[last_param][S_NEXT] = var*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_66last_param_52719 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _var_53517;
    DeRef(_1);
    _27657 = NOVALUE;

    /** 			if last_param = last_sym then*/
    if (_66last_param_52719 != _52last_sym_46139)
    goto LD; // [403] 415

    /** 				last_sym = var*/
    _52last_sym_46139 = _var_53517;
LD: 
LC: 

    /** 		if deferred_inlining then*/
    if (_66deferred_inlining_52714 == 0)
    {
        goto LE; // [420] 451
    }
    else{
    }

    /** 			SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26CurrentSub_11990 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_26S_STACK_SPACE_11714)){
        _27662 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_STACK_SPACE_11714)->dbl));
    }
    else{
        _27662 = (int)*(((s1_ptr)_2)->base + _26S_STACK_SPACE_11714);
    }
    _27660 = NOVALUE;
    if (IS_ATOM_INT(_27662)) {
        _27663 = _27662 + 1;
        if (_27663 > MAXINT){
            _27663 = NewDouble((double)_27663);
        }
    }
    else
    _27663 = binary_op(PLUS, 1, _27662);
    _27662 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_STACK_SPACE_11714))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_STACK_SPACE_11714)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_STACK_SPACE_11714);
    _1 = *(int *)_2;
    *(int *)_2 = _27663;
    if( _1 != _27663 ){
        DeRef(_1);
    }
    _27663 = NOVALUE;
    _27660 = NOVALUE;
    goto LF; // [448] 471
LE: 

    /** 			if param_num != -1 then*/
    if (_30param_num_54165 == -1)
    goto L10; // [455] 470

    /** 				param_num += 1*/
    _30param_num_54165 = _30param_num_54165 + 1;
L10: 
LF: 

    /** 		SymTab[var][S_USAGE] = U_USED*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_var_53517 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _27666 = NOVALUE;

    /** 		if reuse then*/
    if (_reuse_53515 == 0)
    {
        goto L11; // [490] 513
    }
    else{
    }

    /** 			map:nested_put( inline_var_map, {CurrentSub, ps }, var )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _26CurrentSub_11990;
    ((int *)_2)[2] = _ps_53514;
    _27668 = MAKE_SEQ(_1);
    Ref(_66inline_var_map_52723);
    _32nested_put(_66inline_var_map_52723, _27668, _var_53517, 1, 23);
    _27668 = NOVALUE;
L11: 

    /** 	Block_var( var )*/
    _65Block_var(_var_53517);

    /** 	if BIND then*/
    if (_26BIND_11622 == 0)
    {
        goto L12; // [523] 538
    }
    else{
    }

    /** 		add_ref( {VARIABLE, var} )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _var_53517;
    _27669 = MAKE_SEQ(_1);
    _52add_ref(_27669);
    _27669 = NOVALUE;
L12: 

    /** 	return var*/
    DeRefi(_name_53519);
    return _var_53517;
    ;
}


int _66get_inlined_code(int _sub_53651, int _start_53652, int _deferred_53653)
{
    int _is_proc_53654 = NOVALUE;
    int _backpatches_53672 = NOVALUE;
    int _prolog_53678 = NOVALUE;
    int _epilog_53679 = NOVALUE;
    int _s_53695 = NOVALUE;
    int _last_sym_53718 = NOVALUE;
    int _int_sym_53745 = NOVALUE;
    int _param_53753 = NOVALUE;
    int _ax_53756 = NOVALUE;
    int _var_53763 = NOVALUE;
    int _final_target_53778 = NOVALUE;
    int _var_53797 = NOVALUE;
    int _create_target_var_53810 = NOVALUE;
    int _check_pc_53833 = NOVALUE;
    int _op_53837 = NOVALUE;
    int _sym_53846 = NOVALUE;
    int _check_result_53851 = NOVALUE;
    int _inline_type_53928 = NOVALUE;
    int _replace_param_1__tmp_at1341_53939 = NOVALUE;
    int _27823 = NOVALUE;
    int _27822 = NOVALUE;
    int _27821 = NOVALUE;
    int _27820 = NOVALUE;
    int _27819 = NOVALUE;
    int _27818 = NOVALUE;
    int _27817 = NOVALUE;
    int _27816 = NOVALUE;
    int _27814 = NOVALUE;
    int _27811 = NOVALUE;
    int _27808 = NOVALUE;
    int _27807 = NOVALUE;
    int _27806 = NOVALUE;
    int _27805 = NOVALUE;
    int _27804 = NOVALUE;
    int _27803 = NOVALUE;
    int _27802 = NOVALUE;
    int _27801 = NOVALUE;
    int _27797 = NOVALUE;
    int _27796 = NOVALUE;
    int _27795 = NOVALUE;
    int _27794 = NOVALUE;
    int _27790 = NOVALUE;
    int _27789 = NOVALUE;
    int _27788 = NOVALUE;
    int _27787 = NOVALUE;
    int _27786 = NOVALUE;
    int _27785 = NOVALUE;
    int _27784 = NOVALUE;
    int _27782 = NOVALUE;
    int _27781 = NOVALUE;
    int _27780 = NOVALUE;
    int _27779 = NOVALUE;
    int _27778 = NOVALUE;
    int _27777 = NOVALUE;
    int _27776 = NOVALUE;
    int _27775 = NOVALUE;
    int _27774 = NOVALUE;
    int _27773 = NOVALUE;
    int _27772 = NOVALUE;
    int _27770 = NOVALUE;
    int _27769 = NOVALUE;
    int _27767 = NOVALUE;
    int _27766 = NOVALUE;
    int _27764 = NOVALUE;
    int _27763 = NOVALUE;
    int _27760 = NOVALUE;
    int _27759 = NOVALUE;
    int _27757 = NOVALUE;
    int _27755 = NOVALUE;
    int _27750 = NOVALUE;
    int _27746 = NOVALUE;
    int _27743 = NOVALUE;
    int _27739 = NOVALUE;
    int _27732 = NOVALUE;
    int _27731 = NOVALUE;
    int _27730 = NOVALUE;
    int _27729 = NOVALUE;
    int _27728 = NOVALUE;
    int _27727 = NOVALUE;
    int _27726 = NOVALUE;
    int _27724 = NOVALUE;
    int _27719 = NOVALUE;
    int _27716 = NOVALUE;
    int _27711 = NOVALUE;
    int _27710 = NOVALUE;
    int _27708 = NOVALUE;
    int _27707 = NOVALUE;
    int _27706 = NOVALUE;
    int _27703 = NOVALUE;
    int _27702 = NOVALUE;
    int _27701 = NOVALUE;
    int _27700 = NOVALUE;
    int _27699 = NOVALUE;
    int _27698 = NOVALUE;
    int _27697 = NOVALUE;
    int _27695 = NOVALUE;
    int _27694 = NOVALUE;
    int _27693 = NOVALUE;
    int _27691 = NOVALUE;
    int _27689 = NOVALUE;
    int _27688 = NOVALUE;
    int _27687 = NOVALUE;
    int _27686 = NOVALUE;
    int _27685 = NOVALUE;
    int _27684 = NOVALUE;
    int _27683 = NOVALUE;
    int _27680 = NOVALUE;
    int _27679 = NOVALUE;
    int _27677 = NOVALUE;
    int _27676 = NOVALUE;
    int _27674 = NOVALUE;
    int _27673 = NOVALUE;
    int _27671 = NOVALUE;
    int _27670 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sub_53651)) {
        _1 = (long)(DBL_PTR(_sub_53651)->dbl);
        DeRefDS(_sub_53651);
        _sub_53651 = _1;
    }
    if (!IS_ATOM_INT(_start_53652)) {
        _1 = (long)(DBL_PTR(_start_53652)->dbl);
        DeRefDS(_start_53652);
        _start_53652 = _1;
    }
    if (!IS_ATOM_INT(_deferred_53653)) {
        _1 = (long)(DBL_PTR(_deferred_53653)->dbl);
        DeRefDS(_deferred_53653);
        _deferred_53653 = _1;
    }

    /** 	integer is_proc = SymTab[sub][S_TOKEN] = PROC*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27670 = (int)*(((s1_ptr)_2)->base + _sub_53651);
    _2 = (int)SEQ_PTR(_27670);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _27671 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _27671 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _27670 = NOVALUE;
    if (IS_ATOM_INT(_27671)) {
        _is_proc_53654 = (_27671 == 27);
    }
    else {
        _is_proc_53654 = binary_op(EQUALS, _27671, 27);
    }
    _27671 = NOVALUE;
    if (!IS_ATOM_INT(_is_proc_53654)) {
        _1 = (long)(DBL_PTR(_is_proc_53654)->dbl);
        DeRefDS(_is_proc_53654);
        _is_proc_53654 = _1;
    }

    /** 	clear_inline_targets()*/
    _37clear_inline_targets();

    /** 	inline_temps = {}*/
    RefDS(_22037);
    DeRef(_66inline_temps_52706);
    _66inline_temps_52706 = _22037;

    /** 	inline_params = {}*/
    RefDS(_22037);
    DeRefi(_66inline_params_52709);
    _66inline_params_52709 = _22037;

    /** 	assigned_params      = SymTab[sub][S_INLINE][1]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27673 = (int)*(((s1_ptr)_2)->base + _sub_53651);
    _2 = (int)SEQ_PTR(_27673);
    _27674 = (int)*(((s1_ptr)_2)->base + 29);
    _27673 = NOVALUE;
    DeRef(_66assigned_params_52710);
    _2 = (int)SEQ_PTR(_27674);
    _66assigned_params_52710 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_66assigned_params_52710);
    _27674 = NOVALUE;

    /** 	inline_code          = SymTab[sub][S_INLINE][2]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27676 = (int)*(((s1_ptr)_2)->base + _sub_53651);
    _2 = (int)SEQ_PTR(_27676);
    _27677 = (int)*(((s1_ptr)_2)->base + 29);
    _27676 = NOVALUE;
    DeRef(_66inline_code_52704);
    _2 = (int)SEQ_PTR(_27677);
    _66inline_code_52704 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_66inline_code_52704);
    _27677 = NOVALUE;

    /** 	sequence backpatches = SymTab[sub][S_INLINE][3]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27679 = (int)*(((s1_ptr)_2)->base + _sub_53651);
    _2 = (int)SEQ_PTR(_27679);
    _27680 = (int)*(((s1_ptr)_2)->base + 29);
    _27679 = NOVALUE;
    DeRef(_backpatches_53672);
    _2 = (int)SEQ_PTR(_27680);
    _backpatches_53672 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_backpatches_53672);
    _27680 = NOVALUE;

    /** 	passed_params = {}*/
    RefDS(_22037);
    DeRef(_66passed_params_52707);
    _66passed_params_52707 = _22037;

    /** 	original_params = {}*/
    RefDS(_22037);
    DeRef(_66original_params_52708);
    _66original_params_52708 = _22037;

    /** 	proc_vars = {}*/
    RefDS(_22037);
    DeRefi(_66proc_vars_52705);
    _66proc_vars_52705 = _22037;

    /** 	sequence prolog = {}*/
    RefDS(_22037);
    DeRefi(_prolog_53678);
    _prolog_53678 = _22037;

    /** 	sequence epilog = {}*/
    RefDS(_22037);
    DeRef(_epilog_53679);
    _epilog_53679 = _22037;

    /** 	Start_block( EXIT_BLOCK, sprintf("Inline-%s from %s @ %d", */
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27683 = (int)*(((s1_ptr)_2)->base + _sub_53651);
    _2 = (int)SEQ_PTR(_27683);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _27684 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _27684 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _27683 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27685 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_27685);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _27686 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _27686 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _27685 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_27684);
    *((int *)(_2+4)) = _27684;
    Ref(_27686);
    *((int *)(_2+8)) = _27686;
    *((int *)(_2+12)) = _start_53652;
    _27687 = MAKE_SEQ(_1);
    _27686 = NOVALUE;
    _27684 = NOVALUE;
    _27688 = EPrintf(-9999999, _27682, _27687);
    DeRefDS(_27687);
    _27687 = NOVALUE;
    _65Start_block(206, _27688);
    _27688 = NOVALUE;

    /** 	symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27689 = (int)*(((s1_ptr)_2)->base + _sub_53651);
    _2 = (int)SEQ_PTR(_27689);
    _s_53695 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_53695)){
        _s_53695 = (long)DBL_PTR(_s_53695)->dbl;
    }
    _27689 = NOVALUE;

    /** 	varnum = SymTab[CurrentSub][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27691 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_27691);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _66varnum_52715 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _66varnum_52715 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    if (!IS_ATOM_INT(_66varnum_52715)){
        _66varnum_52715 = (long)DBL_PTR(_66varnum_52715)->dbl;
    }
    _27691 = NOVALUE;

    /** 	inline_start = start*/
    _66inline_start_52716 = _start_53652;

    /** 	last_param = CurrentSub*/
    _66last_param_52719 = _26CurrentSub_11990;

    /** 	for p = 1 to SymTab[CurrentSub][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27693 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_27693);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _27694 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _27694 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _27693 = NOVALUE;
    {
        int _p_53707;
        _p_53707 = 1;
L1: 
        if (binary_op_a(GREATER, _p_53707, _27694)){
            goto L2; // [250] 282
        }

        /** 		last_param = SymTab[last_param][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27695 = (int)*(((s1_ptr)_2)->base + _66last_param_52719);
        _2 = (int)SEQ_PTR(_27695);
        _66last_param_52719 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_66last_param_52719)){
            _66last_param_52719 = (long)DBL_PTR(_66last_param_52719)->dbl;
        }
        _27695 = NOVALUE;

        /** 	end for*/
        _0 = _p_53707;
        if (IS_ATOM_INT(_p_53707)) {
            _p_53707 = _p_53707 + 1;
            if ((long)((unsigned long)_p_53707 +(unsigned long) HIGH_BITS) >= 0){
                _p_53707 = NewDouble((double)_p_53707);
            }
        }
        else {
            _p_53707 = binary_op_a(PLUS, _p_53707, 1);
        }
        DeRef(_0);
        goto L1; // [277] 257
L2: 
        ;
        DeRef(_p_53707);
    }

    /** 	symtab_index last_sym = last_param*/
    _last_sym_53718 = _66last_param_52719;

    /** 	while last_sym and */
L3: 
    if (_last_sym_53718 == 0) {
        goto L4; // [296] 368
    }
    _27698 = _52sym_scope(_last_sym_53718);
    if (IS_ATOM_INT(_27698)) {
        _27699 = (_27698 <= 3);
    }
    else {
        _27699 = binary_op(LESSEQ, _27698, 3);
    }
    DeRef(_27698);
    _27698 = NOVALUE;
    if (IS_ATOM_INT(_27699)) {
        if (_27699 != 0) {
            DeRef(_27700);
            _27700 = 1;
            goto L5; // [310] 328
        }
    }
    else {
        if (DBL_PTR(_27699)->dbl != 0.0) {
            DeRef(_27700);
            _27700 = 1;
            goto L5; // [310] 328
        }
    }
    _27701 = _52sym_scope(_last_sym_53718);
    if (IS_ATOM_INT(_27701)) {
        _27702 = (_27701 == 9);
    }
    else {
        _27702 = binary_op(EQUALS, _27701, 9);
    }
    DeRef(_27701);
    _27701 = NOVALUE;
    DeRef(_27700);
    if (IS_ATOM_INT(_27702))
    _27700 = (_27702 != 0);
    else
    _27700 = DBL_PTR(_27702)->dbl != 0.0;
L5: 
    if (_27700 == 0)
    {
        _27700 = NOVALUE;
        goto L4; // [329] 368
    }
    else{
        _27700 = NOVALUE;
    }

    /** 		last_param = last_sym*/
    _66last_param_52719 = _last_sym_53718;

    /** 		last_sym = SymTab[last_sym][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27703 = (int)*(((s1_ptr)_2)->base + _last_sym_53718);
    _2 = (int)SEQ_PTR(_27703);
    _last_sym_53718 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_last_sym_53718)){
        _last_sym_53718 = (long)DBL_PTR(_last_sym_53718)->dbl;
    }
    _27703 = NOVALUE;

    /** 		varnum += 1*/
    _66varnum_52715 = _66varnum_52715 + 1;

    /** 	end while*/
    goto L3; // [365] 296
L4: 

    /** 	for p = SymTab[sub][S_NUM_ARGS] to 1 by -1 do*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27706 = (int)*(((s1_ptr)_2)->base + _sub_53651);
    _2 = (int)SEQ_PTR(_27706);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _27707 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _27707 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _27706 = NOVALUE;
    {
        int _p_53736;
        Ref(_27707);
        _p_53736 = _27707;
L6: 
        if (binary_op_a(LESS, _p_53736, 1)){
            goto L7; // [382] 407
        }

        /** 		passed_params = prepend( passed_params, Pop() )*/
        _27708 = _37Pop();
        Ref(_27708);
        Prepend(&_66passed_params_52707, _66passed_params_52707, _27708);
        DeRef(_27708);
        _27708 = NOVALUE;

        /** 	end for*/
        _0 = _p_53736;
        if (IS_ATOM_INT(_p_53736)) {
            _p_53736 = _p_53736 + -1;
            if ((long)((unsigned long)_p_53736 +(unsigned long) HIGH_BITS) >= 0){
                _p_53736 = NewDouble((double)_p_53736);
            }
        }
        else {
            _p_53736 = binary_op_a(PLUS, _p_53736, -1);
        }
        DeRef(_0);
        goto L6; // [402] 389
L7: 
        ;
        DeRef(_p_53736);
    }

    /** 	original_params = passed_params*/
    RefDS(_66passed_params_52707);
    DeRef(_66original_params_52708);
    _66original_params_52708 = _66passed_params_52707;

    /** 	symtab_index int_sym = 0*/
    _int_sym_53745 = 0;

    /** 	for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27710 = (int)*(((s1_ptr)_2)->base + _sub_53651);
    _2 = (int)SEQ_PTR(_27710);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _27711 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _27711 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _27710 = NOVALUE;
    {
        int _p_53747;
        _p_53747 = 1;
L8: 
        if (binary_op_a(GREATER, _p_53747, _27711)){
            goto L9; // [437] 575
        }

        /** 		symtab_index param = passed_params[p]*/
        _2 = (int)SEQ_PTR(_66passed_params_52707);
        if (!IS_ATOM_INT(_p_53747)){
            _param_53753 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_p_53747)->dbl));
        }
        else{
            _param_53753 = (int)*(((s1_ptr)_2)->base + _p_53747);
        }
        if (!IS_ATOM_INT(_param_53753)){
            _param_53753 = (long)DBL_PTR(_param_53753)->dbl;
        }

        /** 		inline_params &= s*/
        Append(&_66inline_params_52709, _66inline_params_52709, _s_53695);

        /** 		integer ax = find( p, assigned_params )*/
        _ax_53756 = find_from(_p_53747, _66assigned_params_52710, 1);

        /** 		if ax or is_temp( param ) then*/
        if (_ax_53756 != 0) {
            goto LA; // [473] 486
        }
        _27716 = _66is_temp(_param_53753);
        if (_27716 == 0) {
            DeRef(_27716);
            _27716 = NOVALUE;
            goto LB; // [482] 548
        }
        else {
            if (!IS_ATOM_INT(_27716) && DBL_PTR(_27716)->dbl == 0.0){
                DeRef(_27716);
                _27716 = NOVALUE;
                goto LB; // [482] 548
            }
            DeRef(_27716);
            _27716 = NOVALUE;
        }
        DeRef(_27716);
        _27716 = NOVALUE;
LA: 

        /** 			varnum += 1*/
        _66varnum_52715 = _66varnum_52715 + 1;

        /** 			symtab_index var = new_inline_var( s, 0 )*/
        _var_53763 = _66new_inline_var(_s_53695, 0);
        if (!IS_ATOM_INT(_var_53763)) {
            _1 = (long)(DBL_PTR(_var_53763)->dbl);
            DeRefDS(_var_53763);
            _var_53763 = _1;
        }

        /** 			prolog &= {ASSIGN, param, var}*/
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = 18;
        *((int *)(_2+8)) = _param_53753;
        *((int *)(_2+12)) = _var_53763;
        _27719 = MAKE_SEQ(_1);
        Concat((object_ptr)&_prolog_53678, _prolog_53678, _27719);
        DeRefDS(_27719);
        _27719 = NOVALUE;

        /** 			if not int_sym then*/
        if (_int_sym_53745 != 0)
        goto LC; // [519] 531

        /** 				int_sym = NewIntSym( 0 )*/
        _int_sym_53745 = _52NewIntSym(0);
        if (!IS_ATOM_INT(_int_sym_53745)) {
            _1 = (long)(DBL_PTR(_int_sym_53745)->dbl);
            DeRefDS(_int_sym_53745);
            _int_sym_53745 = _1;
        }
LC: 

        /** 			inline_start += 3*/
        _66inline_start_52716 = _66inline_start_52716 + 3;

        /** 			passed_params[p] = var*/
        _2 = (int)SEQ_PTR(_66passed_params_52707);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _66passed_params_52707 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_p_53747))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_p_53747)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _p_53747);
        _1 = *(int *)_2;
        *(int *)_2 = _var_53763;
        DeRef(_1);
LB: 

        /** 		s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27724 = (int)*(((s1_ptr)_2)->base + _s_53695);
        _2 = (int)SEQ_PTR(_27724);
        _s_53695 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_53695)){
            _s_53695 = (long)DBL_PTR(_s_53695)->dbl;
        }
        _27724 = NOVALUE;

        /** 	end for*/
        _0 = _p_53747;
        if (IS_ATOM_INT(_p_53747)) {
            _p_53747 = _p_53747 + 1;
            if ((long)((unsigned long)_p_53747 +(unsigned long) HIGH_BITS) >= 0){
                _p_53747 = NewDouble((double)_p_53747);
            }
        }
        else {
            _p_53747 = binary_op_a(PLUS, _p_53747, 1);
        }
        DeRef(_0);
        goto L8; // [570] 444
L9: 
        ;
        DeRef(_p_53747);
    }

    /** 	symtab_index final_target = 0*/
    _final_target_53778 = 0;

    /** 	while s and */
LD: 
    if (_s_53695 == 0) {
        goto LE; // [587] 699
    }
    _27727 = _52sym_scope(_s_53695);
    if (IS_ATOM_INT(_27727)) {
        _27728 = (_27727 <= 3);
    }
    else {
        _27728 = binary_op(LESSEQ, _27727, 3);
    }
    DeRef(_27727);
    _27727 = NOVALUE;
    if (IS_ATOM_INT(_27728)) {
        if (_27728 != 0) {
            DeRef(_27729);
            _27729 = 1;
            goto LF; // [601] 619
        }
    }
    else {
        if (DBL_PTR(_27728)->dbl != 0.0) {
            DeRef(_27729);
            _27729 = 1;
            goto LF; // [601] 619
        }
    }
    _27730 = _52sym_scope(_s_53695);
    if (IS_ATOM_INT(_27730)) {
        _27731 = (_27730 == 9);
    }
    else {
        _27731 = binary_op(EQUALS, _27730, 9);
    }
    DeRef(_27730);
    _27730 = NOVALUE;
    DeRef(_27729);
    if (IS_ATOM_INT(_27731))
    _27729 = (_27731 != 0);
    else
    _27729 = DBL_PTR(_27731)->dbl != 0.0;
LF: 
    if (_27729 == 0)
    {
        _27729 = NOVALUE;
        goto LE; // [620] 699
    }
    else{
        _27729 = NOVALUE;
    }

    /** 		if sym_scope( s ) != SC_UNDEFINED then*/
    _27732 = _52sym_scope(_s_53695);
    if (binary_op_a(EQUALS, _27732, 9)){
        DeRef(_27732);
        _27732 = NOVALUE;
        goto L10; // [631] 676
    }
    DeRef(_27732);
    _27732 = NOVALUE;

    /** 			varnum += 1*/
    _66varnum_52715 = _66varnum_52715 + 1;

    /** 			symtab_index var = new_inline_var( s, 0 )*/
    _var_53797 = _66new_inline_var(_s_53695, 0);
    if (!IS_ATOM_INT(_var_53797)) {
        _1 = (long)(DBL_PTR(_var_53797)->dbl);
        DeRefDS(_var_53797);
        _var_53797 = _1;
    }

    /** 			proc_vars &= var*/
    Append(&_66proc_vars_52705, _66proc_vars_52705, _var_53797);

    /** 			if int_sym = 0 then*/
    if (_int_sym_53745 != 0)
    goto L11; // [662] 675

    /** 				int_sym = NewIntSym( 0 )*/
    _int_sym_53745 = _52NewIntSym(0);
    if (!IS_ATOM_INT(_int_sym_53745)) {
        _1 = (long)(DBL_PTR(_int_sym_53745)->dbl);
        DeRefDS(_int_sym_53745);
        _int_sym_53745 = _1;
    }
L11: 
L10: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27739 = (int)*(((s1_ptr)_2)->base + _s_53695);
    _2 = (int)SEQ_PTR(_27739);
    _s_53695 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_53695)){
        _s_53695 = (long)DBL_PTR(_s_53695)->dbl;
    }
    _27739 = NOVALUE;

    /** 	end while*/
    goto LD; // [696] 587
LE: 

    /** 	if not is_proc then*/
    if (_is_proc_53654 != 0)
    goto L12; // [701] 831

    /** 		integer create_target_var = 1*/
    _create_target_var_53810 = 1;

    /** 		if deferred then*/
    if (_deferred_53653 == 0)
    {
        goto L13; // [711] 751
    }
    else{
    }

    /** 			inline_target = Pop()*/
    _0 = _37Pop();
    _66inline_target_52711 = _0;
    if (!IS_ATOM_INT(_66inline_target_52711)) {
        _1 = (long)(DBL_PTR(_66inline_target_52711)->dbl);
        DeRefDS(_66inline_target_52711);
        _66inline_target_52711 = _1;
    }

    /** 			if is_temp( inline_target ) then*/
    _27743 = _66is_temp(_66inline_target_52711);
    if (_27743 == 0) {
        DeRef(_27743);
        _27743 = NOVALUE;
        goto L14; // [729] 744
    }
    else {
        if (!IS_ATOM_INT(_27743) && DBL_PTR(_27743)->dbl == 0.0){
            DeRef(_27743);
            _27743 = NOVALUE;
            goto L14; // [729] 744
        }
        DeRef(_27743);
        _27743 = NOVALUE;
    }
    DeRef(_27743);
    _27743 = NOVALUE;

    /** 				final_target = inline_target*/
    _final_target_53778 = _66inline_target_52711;
    goto L15; // [741] 750
L14: 

    /** 				create_target_var = 0*/
    _create_target_var_53810 = 0;
L15: 
L13: 

    /** 		if create_target_var then*/
    if (_create_target_var_53810 == 0)
    {
        goto L16; // [753] 816
    }
    else{
    }

    /** 			varnum += 1*/
    _66varnum_52715 = _66varnum_52715 + 1;

    /** 			if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L17; // [768] 806
    }
    else{
    }

    /** 				inline_target = new_inline_var( sub, 0 )*/
    _0 = _66new_inline_var(_sub_53651, 0);
    _66inline_target_52711 = _0;
    if (!IS_ATOM_INT(_66inline_target_52711)) {
        _1 = (long)(DBL_PTR(_66inline_target_52711)->dbl);
        DeRefDS(_66inline_target_52711);
        _66inline_target_52711 = _1;
    }

    /** 				SymTab[inline_target][S_VTYPE] = object_type*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_66inline_target_52711 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _52object_type_46130;
    DeRef(_1);
    _27746 = NOVALUE;

    /** 				Pop_block_var()*/
    _65Pop_block_var();
    goto L18; // [803] 815
L17: 

    /** 				inline_target = NewTempSym()*/
    _0 = _52NewTempSym(0);
    _66inline_target_52711 = _0;
    if (!IS_ATOM_INT(_66inline_target_52711)) {
        _1 = (long)(DBL_PTR(_66inline_target_52711)->dbl);
        DeRefDS(_66inline_target_52711);
        _66inline_target_52711 = _1;
    }
L18: 
L16: 

    /** 		proc_vars &= inline_target*/
    Append(&_66proc_vars_52705, _66proc_vars_52705, _66inline_target_52711);
    goto L19; // [828] 837
L12: 

    /** 		inline_target = 0*/
    _66inline_target_52711 = 0;
L19: 

    /** 	integer check_pc = 1*/
    _check_pc_53833 = 1;

    /** 	while length(inline_code) > check_pc do*/
L1A: 
    if (IS_SEQUENCE(_66inline_code_52704)){
            _27750 = SEQ_PTR(_66inline_code_52704)->length;
    }
    else {
        _27750 = 1;
    }
    if (_27750 <= _check_pc_53833)
    goto L1B; // [852] 1216

    /** 		integer op = inline_code[check_pc]*/
    _2 = (int)SEQ_PTR(_66inline_code_52704);
    _op_53837 = (int)*(((s1_ptr)_2)->base + _check_pc_53833);
    if (!IS_ATOM_INT(_op_53837))
    _op_53837 = (long)DBL_PTR(_op_53837)->dbl;

    /** 		switch op with fallthru do*/
    _0 = _op_53837;
    switch ( _0 ){ 

        /** 			case ATOM_CHECK then*/
        case 101:
        case 97:
        case 96:

        /** 				symtab_index sym = get_original_sym( check_pc + 1 )*/
        _27755 = _check_pc_53833 + 1;
        if (_27755 > MAXINT){
            _27755 = NewDouble((double)_27755);
        }
        _sym_53846 = _66get_original_sym(_27755);
        _27755 = NOVALUE;
        if (!IS_ATOM_INT(_sym_53846)) {
            _1 = (long)(DBL_PTR(_sym_53846)->dbl);
            DeRefDS(_sym_53846);
            _sym_53846 = _1;
        }

        /** 				if is_literal( sym ) then*/
        _27757 = _66is_literal(_sym_53846);
        if (_27757 == 0) {
            DeRef(_27757);
            _27757 = NOVALUE;
            goto L1C; // [897] 1010
        }
        else {
            if (!IS_ATOM_INT(_27757) && DBL_PTR(_27757)->dbl == 0.0){
                DeRef(_27757);
                _27757 = NOVALUE;
                goto L1C; // [897] 1010
            }
            DeRef(_27757);
            _27757 = NOVALUE;
        }
        DeRef(_27757);
        _27757 = NOVALUE;

        /** 					integer check_result*/

        /** 					if op = INTEGER_CHECK then*/
        if (_op_53837 != 96)
        goto L1D; // [906] 930

        /** 						check_result = integer( SymTab[sym][S_OBJ] )*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27759 = (int)*(((s1_ptr)_2)->base + _sym_53846);
        _2 = (int)SEQ_PTR(_27759);
        _27760 = (int)*(((s1_ptr)_2)->base + 1);
        _27759 = NOVALUE;
        if (IS_ATOM_INT(_27760))
        _check_result_53851 = 1;
        else if (IS_ATOM_DBL(_27760))
        _check_result_53851 = IS_ATOM_INT(DoubleToInt(_27760));
        else
        _check_result_53851 = 0;
        _27760 = NOVALUE;
        goto L1E; // [927] 976
L1D: 

        /** 					elsif op = SEQUENCE_CHECK then*/
        if (_op_53837 != 97)
        goto L1F; // [934] 958

        /** 						check_result = sequence( SymTab[sym][S_OBJ] )*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27763 = (int)*(((s1_ptr)_2)->base + _sym_53846);
        _2 = (int)SEQ_PTR(_27763);
        _27764 = (int)*(((s1_ptr)_2)->base + 1);
        _27763 = NOVALUE;
        _check_result_53851 = IS_SEQUENCE(_27764);
        _27764 = NOVALUE;
        goto L1E; // [955] 976
L1F: 

        /** 						check_result = atom( SymTab[sym][S_OBJ] )*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27766 = (int)*(((s1_ptr)_2)->base + _sym_53846);
        _2 = (int)SEQ_PTR(_27766);
        _27767 = (int)*(((s1_ptr)_2)->base + 1);
        _27766 = NOVALUE;
        _check_result_53851 = IS_ATOM(_27767);
        _27767 = NOVALUE;
L1E: 

        /** 					if check_result then*/
        if (_check_result_53851 == 0)
        {
            goto L20; // [980] 997
        }
        else{
        }

        /** 						replace_code( {}, check_pc, check_pc+1 )*/
        _27769 = _check_pc_53833 + 1;
        if (_27769 > MAXINT){
            _27769 = NewDouble((double)_27769);
        }
        RefDS(_22037);
        _66replace_code(_22037, _check_pc_53833, _27769);
        _27769 = NOVALUE;
        goto L21; // [994] 1005
L20: 

        /** 						CompileErr(146)*/
        RefDS(_22037);
        _43CompileErr(146, _22037, 0);
L21: 
        goto L22; // [1007] 1172
L1C: 

        /** 				elsif not is_temp( sym ) then*/
        _27770 = _66is_temp(_sym_53846);
        if (IS_ATOM_INT(_27770)) {
            if (_27770 != 0){
                DeRef(_27770);
                _27770 = NOVALUE;
                goto L23; // [1016] 1165
            }
        }
        else {
            if (DBL_PTR(_27770)->dbl != 0.0){
                DeRef(_27770);
                _27770 = NOVALUE;
                goto L23; // [1016] 1165
            }
        }
        DeRef(_27770);
        _27770 = NOVALUE;

        /** 					if (op = INTEGER_CHECK and SymTab[sym][S_VTYPE] = integer_type )*/
        _27772 = (_op_53837 == 96);
        if (_27772 == 0) {
            _27773 = 0;
            goto L24; // [1027] 1053
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27774 = (int)*(((s1_ptr)_2)->base + _sym_53846);
        _2 = (int)SEQ_PTR(_27774);
        _27775 = (int)*(((s1_ptr)_2)->base + 15);
        _27774 = NOVALUE;
        if (IS_ATOM_INT(_27775)) {
            _27776 = (_27775 == _52integer_type_46136);
        }
        else {
            _27776 = binary_op(EQUALS, _27775, _52integer_type_46136);
        }
        _27775 = NOVALUE;
        if (IS_ATOM_INT(_27776))
        _27773 = (_27776 != 0);
        else
        _27773 = DBL_PTR(_27776)->dbl != 0.0;
L24: 
        if (_27773 != 0) {
            _27777 = 1;
            goto L25; // [1053] 1093
        }
        _27778 = (_op_53837 == 97);
        if (_27778 == 0) {
            _27779 = 0;
            goto L26; // [1063] 1089
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27780 = (int)*(((s1_ptr)_2)->base + _sym_53846);
        _2 = (int)SEQ_PTR(_27780);
        _27781 = (int)*(((s1_ptr)_2)->base + 15);
        _27780 = NOVALUE;
        if (IS_ATOM_INT(_27781)) {
            _27782 = (_27781 == _52sequence_type_46134);
        }
        else {
            _27782 = binary_op(EQUALS, _27781, _52sequence_type_46134);
        }
        _27781 = NOVALUE;
        if (IS_ATOM_INT(_27782))
        _27779 = (_27782 != 0);
        else
        _27779 = DBL_PTR(_27782)->dbl != 0.0;
L26: 
        _27777 = (_27779 != 0);
L25: 
        if (_27777 != 0) {
            goto L27; // [1093] 1141
        }
        _27784 = (_op_53837 == 101);
        if (_27784 == 0) {
            DeRef(_27785);
            _27785 = 0;
            goto L28; // [1103] 1136
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27786 = (int)*(((s1_ptr)_2)->base + _sym_53846);
        _2 = (int)SEQ_PTR(_27786);
        _27787 = (int)*(((s1_ptr)_2)->base + 15);
        _27786 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _52integer_type_46136;
        ((int *)_2)[2] = _52atom_type_46132;
        _27788 = MAKE_SEQ(_1);
        _27789 = find_from(_27787, _27788, 1);
        _27787 = NOVALUE;
        DeRefDS(_27788);
        _27788 = NOVALUE;
        _27785 = (_27789 != 0);
L28: 
        if (_27785 == 0)
        {
            _27785 = NOVALUE;
            goto L29; // [1137] 1155
        }
        else{
            _27785 = NOVALUE;
        }
L27: 

        /** 						replace_code( {}, check_pc, check_pc+1 )*/
        _27790 = _check_pc_53833 + 1;
        if (_27790 > MAXINT){
            _27790 = NewDouble((double)_27790);
        }
        RefDS(_22037);
        _66replace_code(_22037, _check_pc_53833, _27790);
        _27790 = NOVALUE;
        goto L22; // [1152] 1172
L29: 

        /** 						check_pc += 2*/
        _check_pc_53833 = _check_pc_53833 + 2;
        goto L22; // [1162] 1172
L23: 

        /** 					check_pc += 2*/
        _check_pc_53833 = _check_pc_53833 + 2;
L22: 

        /** 				continue*/
        goto L1A; // [1178] 847

        /** 			case STARTLINE then*/
        case 58:

        /** 				check_pc += 2*/
        _check_pc_53833 = _check_pc_53833 + 2;

        /** 				continue*/
        goto L1A; // [1196] 847

        /** 			case else*/
        default:

        /** 				exit*/
        goto L1B; // [1206] 1216
    ;}
    /** 	end while*/
    goto L1A; // [1213] 847
L1B: 

    /** 	for pc = 1 to length( inline_code ) do*/
    if (IS_SEQUENCE(_66inline_code_52704)){
            _27794 = SEQ_PTR(_66inline_code_52704)->length;
    }
    else {
        _27794 = 1;
    }
    {
        int _pc_53923;
        _pc_53923 = 1;
L2A: 
        if (_pc_53923 > _27794){
            goto L2B; // [1223] 1420
        }

        /** 		if sequence( inline_code[pc] ) then*/
        _2 = (int)SEQ_PTR(_66inline_code_52704);
        _27795 = (int)*(((s1_ptr)_2)->base + _pc_53923);
        _27796 = IS_SEQUENCE(_27795);
        _27795 = NOVALUE;
        if (_27796 == 0)
        {
            _27796 = NOVALUE;
            goto L2C; // [1241] 1411
        }
        else{
            _27796 = NOVALUE;
        }

        /** 			integer inline_type = inline_code[pc][1]*/
        _2 = (int)SEQ_PTR(_66inline_code_52704);
        _27797 = (int)*(((s1_ptr)_2)->base + _pc_53923);
        _2 = (int)SEQ_PTR(_27797);
        _inline_type_53928 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_inline_type_53928)){
            _inline_type_53928 = (long)DBL_PTR(_inline_type_53928)->dbl;
        }
        _27797 = NOVALUE;

        /** 			switch inline_type do*/
        _0 = _inline_type_53928;
        switch ( _0 ){ 

            /** 				case INLINE_SUB then*/
            case 5:

            /** 					inline_code[pc] = CurrentSub*/
            _2 = (int)SEQ_PTR(_66inline_code_52704);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _66inline_code_52704 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pc_53923);
            _1 = *(int *)_2;
            *(int *)_2 = _26CurrentSub_11990;
            DeRef(_1);
            goto L2D; // [1279] 1410

            /** 				case INLINE_VAR then*/
            case 6:

            /** 					replace_var( pc )*/
            _66replace_var(_pc_53923);

            /** 					break*/
            goto L2D; // [1292] 1410
            goto L2D; // [1294] 1410

            /** 				case INLINE_TEMP then*/
            case 2:

            /** 					replace_temp( pc )*/
            _66replace_temp(_pc_53923);
            goto L2D; // [1305] 1410

            /** 				case INLINE_PARAM then*/
            case 1:

            /** 					replace_param( pc )*/

            /** 	inline_code[pc] = get_param_sym( pc )*/
            _0 = _replace_param_1__tmp_at1341_53939;
            _replace_param_1__tmp_at1341_53939 = _66get_param_sym(_pc_53923);
            DeRef(_0);
            Ref(_replace_param_1__tmp_at1341_53939);
            _2 = (int)SEQ_PTR(_66inline_code_52704);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _66inline_code_52704 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pc_53923);
            _1 = *(int *)_2;
            *(int *)_2 = _replace_param_1__tmp_at1341_53939;
            DeRef(_1);

            /** end procedure*/
            goto L2E; // [1327] 1330
L2E: 
            DeRef(_replace_param_1__tmp_at1341_53939);
            _replace_param_1__tmp_at1341_53939 = NOVALUE;
            goto L2D; // [1332] 1410

            /** 				case INLINE_ADDR then*/
            case 4:

            /** 					inline_code[pc] = inline_start + inline_code[pc][2]*/
            _2 = (int)SEQ_PTR(_66inline_code_52704);
            _27801 = (int)*(((s1_ptr)_2)->base + _pc_53923);
            _2 = (int)SEQ_PTR(_27801);
            _27802 = (int)*(((s1_ptr)_2)->base + 2);
            _27801 = NOVALUE;
            if (IS_ATOM_INT(_27802)) {
                _27803 = _66inline_start_52716 + _27802;
                if ((long)((unsigned long)_27803 + (unsigned long)HIGH_BITS) >= 0) 
                _27803 = NewDouble((double)_27803);
            }
            else {
                _27803 = binary_op(PLUS, _66inline_start_52716, _27802);
            }
            _27802 = NOVALUE;
            _2 = (int)SEQ_PTR(_66inline_code_52704);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _66inline_code_52704 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pc_53923);
            _1 = *(int *)_2;
            *(int *)_2 = _27803;
            if( _1 != _27803 ){
                DeRef(_1);
            }
            _27803 = NOVALUE;
            goto L2D; // [1362] 1410

            /** 				case INLINE_TARGET then*/
            case 3:

            /** 					inline_code[pc] = inline_target*/
            _2 = (int)SEQ_PTR(_66inline_code_52704);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _66inline_code_52704 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pc_53923);
            _1 = *(int *)_2;
            *(int *)_2 = _66inline_target_52711;
            DeRef(_1);

            /** 					add_inline_target( pc + inline_start )*/
            _27804 = _pc_53923 + _66inline_start_52716;
            if ((long)((unsigned long)_27804 + (unsigned long)HIGH_BITS) >= 0) 
            _27804 = NewDouble((double)_27804);
            _37add_inline_target(_27804);
            _27804 = NOVALUE;

            /** 					break*/
            goto L2D; // [1391] 1410
            goto L2D; // [1393] 1410

            /** 				case else*/
            default:

            /** 					InternalErr( 265, {inline_type} )*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            *((int *)(_2+4)) = _inline_type_53928;
            _27805 = MAKE_SEQ(_1);
            _43InternalErr(265, _27805);
            _27805 = NOVALUE;
        ;}L2D: 
L2C: 

        /** 	end for*/
        _pc_53923 = _pc_53923 + 1;
        goto L2A; // [1415] 1230
L2B: 
        ;
    }

    /** 	for i = 1 to length(backpatches) do*/
    if (IS_SEQUENCE(_backpatches_53672)){
            _27806 = SEQ_PTR(_backpatches_53672)->length;
    }
    else {
        _27806 = 1;
    }
    {
        int _i_53951;
        _i_53951 = 1;
L2F: 
        if (_i_53951 > _27806){
            goto L30; // [1425] 1448
        }

        /** 		fixup_special_op( backpatches[i] )*/
        _2 = (int)SEQ_PTR(_backpatches_53672);
        _27807 = (int)*(((s1_ptr)_2)->base + _i_53951);
        Ref(_27807);
        _66fixup_special_op(_27807);
        _27807 = NOVALUE;

        /** 	end for*/
        _i_53951 = _i_53951 + 1;
        goto L2F; // [1443] 1432
L30: 
        ;
    }

    /** 	epilog &= End_inline_block( EXIT_BLOCK )*/
    _27808 = _65End_inline_block(206);
    if (IS_SEQUENCE(_epilog_53679) && IS_ATOM(_27808)) {
        Ref(_27808);
        Append(&_epilog_53679, _epilog_53679, _27808);
    }
    else if (IS_ATOM(_epilog_53679) && IS_SEQUENCE(_27808)) {
    }
    else {
        Concat((object_ptr)&_epilog_53679, _epilog_53679, _27808);
    }
    DeRef(_27808);
    _27808 = NOVALUE;

    /** 	if is_proc then*/
    if (_is_proc_53654 == 0)
    {
        goto L31; // [1462] 1472
    }
    else{
    }

    /** 		clear_op()*/
    _37clear_op();
    goto L32; // [1469] 1595
L31: 

    /** 		if not deferred then*/
    if (_deferred_53653 != 0)
    goto L33; // [1474] 1489

    /** 			Push( inline_target )*/
    _37Push(_66inline_target_52711);

    /** 			inlined_function()*/
    _37inlined_function();
L33: 

    /** 		if final_target then*/
    if (_final_target_53778 == 0)
    {
        goto L34; // [1491] 1521
    }
    else{
    }

    /** 			epilog &= { ASSIGN, inline_target, final_target }*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 18;
    *((int *)(_2+8)) = _66inline_target_52711;
    *((int *)(_2+12)) = _final_target_53778;
    _27811 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_53679, _epilog_53679, _27811);
    DeRefDS(_27811);
    _27811 = NOVALUE;

    /** 			emit_temp( final_target, NEW_REFERENCE )*/
    _37emit_temp(_final_target_53778, 1);
    goto L35; // [1518] 1594
L34: 

    /** 			emit_temp( inline_target, NEW_REFERENCE )*/
    _37emit_temp(_66inline_target_52711, 1);

    /** 			if not TRANSLATE then*/
    if (_26TRANSLATE_11619 != 0)
    goto L36; // [1535] 1593

    /** 				epilog &= { ELSE, 0, PRIVATE_INIT_CHECK, inline_target }*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 23;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 30;
    *((int *)(_2+16)) = _66inline_target_52711;
    _27814 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_53679, _epilog_53679, _27814);
    DeRefDS(_27814);
    _27814 = NOVALUE;

    /** 				epilog[$-2] = length(inline_code) + length(epilog) + inline_start + 1*/
    if (IS_SEQUENCE(_epilog_53679)){
            _27816 = SEQ_PTR(_epilog_53679)->length;
    }
    else {
        _27816 = 1;
    }
    _27817 = _27816 - 2;
    _27816 = NOVALUE;
    if (IS_SEQUENCE(_66inline_code_52704)){
            _27818 = SEQ_PTR(_66inline_code_52704)->length;
    }
    else {
        _27818 = 1;
    }
    if (IS_SEQUENCE(_epilog_53679)){
            _27819 = SEQ_PTR(_epilog_53679)->length;
    }
    else {
        _27819 = 1;
    }
    _27820 = _27818 + _27819;
    if ((long)((unsigned long)_27820 + (unsigned long)HIGH_BITS) >= 0) 
    _27820 = NewDouble((double)_27820);
    _27818 = NOVALUE;
    _27819 = NOVALUE;
    if (IS_ATOM_INT(_27820)) {
        _27821 = _27820 + _66inline_start_52716;
        if ((long)((unsigned long)_27821 + (unsigned long)HIGH_BITS) >= 0) 
        _27821 = NewDouble((double)_27821);
    }
    else {
        _27821 = NewDouble(DBL_PTR(_27820)->dbl + (double)_66inline_start_52716);
    }
    DeRef(_27820);
    _27820 = NOVALUE;
    if (IS_ATOM_INT(_27821)) {
        _27822 = _27821 + 1;
        if (_27822 > MAXINT){
            _27822 = NewDouble((double)_27822);
        }
    }
    else
    _27822 = binary_op(PLUS, 1, _27821);
    DeRef(_27821);
    _27821 = NOVALUE;
    _2 = (int)SEQ_PTR(_epilog_53679);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _epilog_53679 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27817);
    _1 = *(int *)_2;
    *(int *)_2 = _27822;
    if( _1 != _27822 ){
        DeRef(_1);
    }
    _27822 = NOVALUE;
L36: 
L35: 
L32: 

    /** 	return prolog & inline_code & epilog*/
    {
        int concat_list[3];

        concat_list[0] = _epilog_53679;
        concat_list[1] = _66inline_code_52704;
        concat_list[2] = _prolog_53678;
        Concat_N((object_ptr)&_27823, concat_list, 3);
    }
    DeRef(_backpatches_53672);
    DeRefDSi(_prolog_53678);
    DeRefDS(_epilog_53679);
    _27694 = NOVALUE;
    _27707 = NOVALUE;
    DeRef(_27699);
    _27699 = NOVALUE;
    DeRef(_27702);
    _27702 = NOVALUE;
    _27711 = NOVALUE;
    DeRef(_27772);
    _27772 = NOVALUE;
    DeRef(_27728);
    _27728 = NOVALUE;
    DeRef(_27731);
    _27731 = NOVALUE;
    DeRef(_27778);
    _27778 = NOVALUE;
    DeRef(_27776);
    _27776 = NOVALUE;
    DeRef(_27784);
    _27784 = NOVALUE;
    DeRef(_27782);
    _27782 = NOVALUE;
    DeRef(_27817);
    _27817 = NOVALUE;
    return _27823;
    ;
}


void _66defer_call()
{
    int _defer_53991 = NOVALUE;
    int _27826 = NOVALUE;
    int _27825 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer defer = find( inline_sub, deferred_inline_decisions )*/
    _defer_53991 = find_from(_66inline_sub_52718, _66deferred_inline_decisions_52720, 1);

    /** 	if defer then*/
    if (_defer_53991 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** 		deferred_inline_calls[defer] &= CurrentSub*/
    _2 = (int)SEQ_PTR(_66deferred_inline_calls_52721);
    _27825 = (int)*(((s1_ptr)_2)->base + _defer_53991);
    if (IS_SEQUENCE(_27825) && IS_ATOM(_26CurrentSub_11990)) {
        Append(&_27826, _27825, _26CurrentSub_11990);
    }
    else if (IS_ATOM(_27825) && IS_SEQUENCE(_26CurrentSub_11990)) {
    }
    else {
        Concat((object_ptr)&_27826, _27825, _26CurrentSub_11990);
        _27825 = NOVALUE;
    }
    _27825 = NOVALUE;
    _2 = (int)SEQ_PTR(_66deferred_inline_calls_52721);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66deferred_inline_calls_52721 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _defer_53991);
    _1 = *(int *)_2;
    *(int *)_2 = _27826;
    if( _1 != _27826 ){
        DeRef(_1);
    }
    _27826 = NOVALUE;
L1: 

    /** end procedure*/
    return;
    ;
}


void _66emit_or_inline()
{
    int _sub_54000 = NOVALUE;
    int _code_54019 = NOVALUE;
    int _27833 = NOVALUE;
    int _27832 = NOVALUE;
    int _27830 = NOVALUE;
    int _27829 = NOVALUE;
    int _27828 = NOVALUE;
    int _0, _1, _2;
    

    /** 	symtab_index sub = op_info1*/
    _sub_54000 = _37op_info1_50262;

    /** 	inline_sub = sub*/
    _66inline_sub_52718 = _sub_54000;

    /** 	if Parser_mode != PAM_NORMAL then*/
    if (_26Parser_mode_12088 == 0)
    goto L1; // [23] 42

    /** 		emit_op( PROC )*/
    _37emit_op(27);

    /** 		return*/
    DeRef(_code_54019);
    return;
    goto L2; // [39] 90
L1: 

    /** 	elsif atom( SymTab[sub][S_INLINE] ) or has_forward_params(sub) then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27828 = (int)*(((s1_ptr)_2)->base + _sub_54000);
    _2 = (int)SEQ_PTR(_27828);
    _27829 = (int)*(((s1_ptr)_2)->base + 29);
    _27828 = NOVALUE;
    _27830 = IS_ATOM(_27829);
    _27829 = NOVALUE;
    if (_27830 != 0) {
        goto L3; // [59] 72
    }
    _27832 = _37has_forward_params(_sub_54000);
    if (_27832 == 0) {
        DeRef(_27832);
        _27832 = NOVALUE;
        goto L4; // [68] 89
    }
    else {
        if (!IS_ATOM_INT(_27832) && DBL_PTR(_27832)->dbl == 0.0){
            DeRef(_27832);
            _27832 = NOVALUE;
            goto L4; // [68] 89
        }
        DeRef(_27832);
        _27832 = NOVALUE;
    }
    DeRef(_27832);
    _27832 = NOVALUE;
L3: 

    /** 		defer_call()*/
    _66defer_call();

    /** 		emit_op( PROC )*/
    _37emit_op(27);

    /** 		return*/
    DeRef(_code_54019);
    return;
L4: 
L2: 

    /** 	sequence code = get_inlined_code( sub, length(Code) )*/
    if (IS_SEQUENCE(_26Code_12071)){
            _27833 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _27833 = 1;
    }
    _0 = _code_54019;
    _code_54019 = _66get_inlined_code(_sub_54000, _27833, 0);
    DeRef(_0);
    _27833 = NOVALUE;

    /** 	emit_inline( code )*/
    RefDS(_code_54019);
    _37emit_inline(_code_54019);

    /** 	clear_last()*/
    _37clear_last();

    /** end procedure*/
    DeRefDS(_code_54019);
    return;
    ;
}


void _66inline_deferred_calls()
{
    int _sub_54033 = NOVALUE;
    int _ix_54045 = NOVALUE;
    int _calling_sub_54047 = NOVALUE;
    int _code_54061 = NOVALUE;
    int _calls_54062 = NOVALUE;
    int _is_func_54066 = NOVALUE;
    int _offset_54073 = NOVALUE;
    int _op_54084 = NOVALUE;
    int _size_54087 = NOVALUE;
    int _27891 = NOVALUE;
    int _27889 = NOVALUE;
    int _27887 = NOVALUE;
    int _27886 = NOVALUE;
    int _27885 = NOVALUE;
    int _27883 = NOVALUE;
    int _27882 = NOVALUE;
    int _27881 = NOVALUE;
    int _27880 = NOVALUE;
    int _27879 = NOVALUE;
    int _27878 = NOVALUE;
    int _27877 = NOVALUE;
    int _27876 = NOVALUE;
    int _27875 = NOVALUE;
    int _27874 = NOVALUE;
    int _27872 = NOVALUE;
    int _27871 = NOVALUE;
    int _27870 = NOVALUE;
    int _27869 = NOVALUE;
    int _27867 = NOVALUE;
    int _27866 = NOVALUE;
    int _27865 = NOVALUE;
    int _27863 = NOVALUE;
    int _27861 = NOVALUE;
    int _27859 = NOVALUE;
    int _27857 = NOVALUE;
    int _27856 = NOVALUE;
    int _27855 = NOVALUE;
    int _27854 = NOVALUE;
    int _27852 = NOVALUE;
    int _27851 = NOVALUE;
    int _27848 = NOVALUE;
    int _27846 = NOVALUE;
    int _27844 = NOVALUE;
    int _27843 = NOVALUE;
    int _27842 = NOVALUE;
    int _27841 = NOVALUE;
    int _27840 = NOVALUE;
    int _27839 = NOVALUE;
    int _27837 = NOVALUE;
    int _27836 = NOVALUE;
    int _27835 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	deferred_inlining = 1*/
    _66deferred_inlining_52714 = 1;

    /** 	for i = 1 to length( deferred_inline_decisions ) do*/
    if (IS_SEQUENCE(_66deferred_inline_decisions_52720)){
            _27835 = SEQ_PTR(_66deferred_inline_decisions_52720)->length;
    }
    else {
        _27835 = 1;
    }
    {
        int _i_54028;
        _i_54028 = 1;
L1: 
        if (_i_54028 > _27835){
            goto L2; // [13] 476
        }

        /** 		if length( deferred_inline_calls[i] ) then*/
        _2 = (int)SEQ_PTR(_66deferred_inline_calls_52721);
        _27836 = (int)*(((s1_ptr)_2)->base + _i_54028);
        if (IS_SEQUENCE(_27836)){
                _27837 = SEQ_PTR(_27836)->length;
        }
        else {
            _27837 = 1;
        }
        _27836 = NOVALUE;
        if (_27837 == 0)
        {
            _27837 = NOVALUE;
            goto L3; // [31] 467
        }
        else{
            _27837 = NOVALUE;
        }

        /** 			integer sub = deferred_inline_decisions[i]*/
        _2 = (int)SEQ_PTR(_66deferred_inline_decisions_52720);
        _sub_54033 = (int)*(((s1_ptr)_2)->base + _i_54028);

        /** 			check_inline( sub )*/
        _66check_inline(_sub_54033);

        /** 			if atom( SymTab[sub][S_INLINE] ) then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27839 = (int)*(((s1_ptr)_2)->base + _sub_54033);
        _2 = (int)SEQ_PTR(_27839);
        _27840 = (int)*(((s1_ptr)_2)->base + 29);
        _27839 = NOVALUE;
        _27841 = IS_ATOM(_27840);
        _27840 = NOVALUE;
        if (_27841 == 0)
        {
            _27841 = NOVALUE;
            goto L4; // [64] 74
        }
        else{
            _27841 = NOVALUE;
        }

        /** 				continue*/
        goto L5; // [71] 471
L4: 

        /** 			for cx = 1 to length( deferred_inline_calls[i] ) do*/
        _2 = (int)SEQ_PTR(_66deferred_inline_calls_52721);
        _27842 = (int)*(((s1_ptr)_2)->base + _i_54028);
        if (IS_SEQUENCE(_27842)){
                _27843 = SEQ_PTR(_27842)->length;
        }
        else {
            _27843 = 1;
        }
        _27842 = NOVALUE;
        {
            int _cx_54042;
            _cx_54042 = 1;
L6: 
            if (_cx_54042 > _27843){
                goto L7; // [85] 466
            }

            /** 				integer ix = 1*/
            _ix_54045 = 1;

            /** 				symtab_index calling_sub = deferred_inline_calls[i][cx]*/
            _2 = (int)SEQ_PTR(_66deferred_inline_calls_52721);
            _27844 = (int)*(((s1_ptr)_2)->base + _i_54028);
            _2 = (int)SEQ_PTR(_27844);
            _calling_sub_54047 = (int)*(((s1_ptr)_2)->base + _cx_54042);
            if (!IS_ATOM_INT(_calling_sub_54047)){
                _calling_sub_54047 = (long)DBL_PTR(_calling_sub_54047)->dbl;
            }
            _27844 = NOVALUE;

            /** 				CurrentSub = calling_sub*/
            _26CurrentSub_11990 = _calling_sub_54047;

            /** 				Code = SymTab[calling_sub][S_CODE]*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _27846 = (int)*(((s1_ptr)_2)->base + _calling_sub_54047);
            DeRef(_26Code_12071);
            _2 = (int)SEQ_PTR(_27846);
            if (!IS_ATOM_INT(_26S_CODE_11666)){
                _26Code_12071 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
            }
            else{
                _26Code_12071 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
            }
            Ref(_26Code_12071);
            _27846 = NOVALUE;

            /** 				LineTable = SymTab[calling_sub][S_LINETAB]*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _27848 = (int)*(((s1_ptr)_2)->base + _calling_sub_54047);
            DeRef(_26LineTable_12072);
            _2 = (int)SEQ_PTR(_27848);
            if (!IS_ATOM_INT(_26S_LINETAB_11689)){
                _26LineTable_12072 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_LINETAB_11689)->dbl));
            }
            else{
                _26LineTable_12072 = (int)*(((s1_ptr)_2)->base + _26S_LINETAB_11689);
            }
            Ref(_26LineTable_12072);
            _27848 = NOVALUE;

            /** 				sequence code = {}*/
            RefDS(_22037);
            DeRef(_code_54061);
            _code_54061 = _22037;

            /** 				sequence calls = find_ops( 1, PROC )*/
            RefDS(_26Code_12071);
            _0 = _calls_54062;
            _calls_54062 = _64find_ops(1, 27, _26Code_12071);
            DeRef(_0);

            /** 				integer is_func = SymTab[sub][S_TOKEN] != PROC */
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            _27851 = (int)*(((s1_ptr)_2)->base + _sub_54033);
            _2 = (int)SEQ_PTR(_27851);
            if (!IS_ATOM_INT(_26S_TOKEN_11659)){
                _27852 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
            }
            else{
                _27852 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
            }
            _27851 = NOVALUE;
            if (IS_ATOM_INT(_27852)) {
                _is_func_54066 = (_27852 != 27);
            }
            else {
                _is_func_54066 = binary_op(NOTEQ, _27852, 27);
            }
            _27852 = NOVALUE;
            if (!IS_ATOM_INT(_is_func_54066)) {
                _1 = (long)(DBL_PTR(_is_func_54066)->dbl);
                DeRefDS(_is_func_54066);
                _is_func_54066 = _1;
            }

            /** 				integer offset = 0*/
            _offset_54073 = 0;

            /** 				for o = 1 to length( calls ) do*/
            if (IS_SEQUENCE(_calls_54062)){
                    _27854 = SEQ_PTR(_calls_54062)->length;
            }
            else {
                _27854 = 1;
            }
            {
                int _o_54075;
                _o_54075 = 1;
L8: 
                if (_o_54075 > _27854){
                    goto L9; // [203] 423
                }

                /** 					if calls[o][2][2] = sub then*/
                _2 = (int)SEQ_PTR(_calls_54062);
                _27855 = (int)*(((s1_ptr)_2)->base + _o_54075);
                _2 = (int)SEQ_PTR(_27855);
                _27856 = (int)*(((s1_ptr)_2)->base + 2);
                _27855 = NOVALUE;
                _2 = (int)SEQ_PTR(_27856);
                _27857 = (int)*(((s1_ptr)_2)->base + 2);
                _27856 = NOVALUE;
                if (binary_op_a(NOTEQ, _27857, _sub_54033)){
                    _27857 = NOVALUE;
                    goto LA; // [224] 414
                }
                _27857 = NOVALUE;

                /** 						ix = calls[o][1]*/
                _2 = (int)SEQ_PTR(_calls_54062);
                _27859 = (int)*(((s1_ptr)_2)->base + _o_54075);
                _2 = (int)SEQ_PTR(_27859);
                _ix_54045 = (int)*(((s1_ptr)_2)->base + 1);
                if (!IS_ATOM_INT(_ix_54045)){
                    _ix_54045 = (long)DBL_PTR(_ix_54045)->dbl;
                }
                _27859 = NOVALUE;

                /** 						sequence op = calls[o][2]*/
                _2 = (int)SEQ_PTR(_calls_54062);
                _27861 = (int)*(((s1_ptr)_2)->base + _o_54075);
                DeRef(_op_54084);
                _2 = (int)SEQ_PTR(_27861);
                _op_54084 = (int)*(((s1_ptr)_2)->base + 2);
                Ref(_op_54084);
                _27861 = NOVALUE;

                /** 						integer size = length( op ) - 1*/
                if (IS_SEQUENCE(_op_54084)){
                        _27863 = SEQ_PTR(_op_54084)->length;
                }
                else {
                    _27863 = 1;
                }
                _size_54087 = _27863 - 1;
                _27863 = NOVALUE;

                /** 						if is_func then*/
                if (_is_func_54066 == 0)
                {
                    goto LB; // [263] 289
                }
                else{
                }

                /** 							Push( op[$] )*/
                if (IS_SEQUENCE(_op_54084)){
                        _27865 = SEQ_PTR(_op_54084)->length;
                }
                else {
                    _27865 = 1;
                }
                _2 = (int)SEQ_PTR(_op_54084);
                _27866 = (int)*(((s1_ptr)_2)->base + _27865);
                Ref(_27866);
                _37Push(_27866);
                _27866 = NOVALUE;

                /** 							op = remove( op, length(op) )*/
                if (IS_SEQUENCE(_op_54084)){
                        _27867 = SEQ_PTR(_op_54084)->length;
                }
                else {
                    _27867 = 1;
                }
                {
                    s1_ptr assign_space = SEQ_PTR(_op_54084);
                    int len = assign_space->length;
                    int start = (IS_ATOM_INT(_27867)) ? _27867 : (long)(DBL_PTR(_27867)->dbl);
                    int stop = (IS_ATOM_INT(_27867)) ? _27867 : (long)(DBL_PTR(_27867)->dbl);
                    if (stop > len){
                        stop = len;
                    }
                    if (start > len || start > stop || stop<0) {
                    }
                    else if (start < 2) {
                        if (stop >= len) {
                            Head( SEQ_PTR(_op_54084), start, &_op_54084 );
                        }
                        else Tail(SEQ_PTR(_op_54084), stop+1, &_op_54084);
                    }
                    else if (stop >= len){
                        Head(SEQ_PTR(_op_54084), start, &_op_54084);
                    }
                    else {
                        assign_slice_seq = &assign_space;
                        _op_54084 = Remove_elements(start, stop, (SEQ_PTR(_op_54084)->ref == 1));
                    }
                }
                _27867 = NOVALUE;
                _27867 = NOVALUE;
LB: 

                /** 						for p = 3 to length( op ) do*/
                if (IS_SEQUENCE(_op_54084)){
                        _27869 = SEQ_PTR(_op_54084)->length;
                }
                else {
                    _27869 = 1;
                }
                {
                    int _p_54097;
                    _p_54097 = 3;
LC: 
                    if (_p_54097 > _27869){
                        goto LD; // [294] 317
                    }

                    /** 							Push( op[p] )*/
                    _2 = (int)SEQ_PTR(_op_54084);
                    _27870 = (int)*(((s1_ptr)_2)->base + _p_54097);
                    Ref(_27870);
                    _37Push(_27870);
                    _27870 = NOVALUE;

                    /** 						end for*/
                    _p_54097 = _p_54097 + 1;
                    goto LC; // [312] 301
LD: 
                    ;
                }

                /** 						code = get_inlined_code( sub, ix + offset - 1, 1 )*/
                _27871 = _ix_54045 + _offset_54073;
                if ((long)((unsigned long)_27871 + (unsigned long)HIGH_BITS) >= 0) 
                _27871 = NewDouble((double)_27871);
                if (IS_ATOM_INT(_27871)) {
                    _27872 = _27871 - 1;
                    if ((long)((unsigned long)_27872 +(unsigned long) HIGH_BITS) >= 0){
                        _27872 = NewDouble((double)_27872);
                    }
                }
                else {
                    _27872 = NewDouble(DBL_PTR(_27871)->dbl - (double)1);
                }
                DeRef(_27871);
                _27871 = NOVALUE;
                _0 = _code_54061;
                _code_54061 = _66get_inlined_code(_sub_54033, _27872, 1);
                DeRef(_0);
                _27872 = NOVALUE;

                /** 						shift:replace_code( repeat( NOP1, length(code) ), ix + offset, ix + offset + size )*/
                if (IS_SEQUENCE(_code_54061)){
                        _27874 = SEQ_PTR(_code_54061)->length;
                }
                else {
                    _27874 = 1;
                }
                _27875 = Repeat(159, _27874);
                _27874 = NOVALUE;
                _27876 = _ix_54045 + _offset_54073;
                if ((long)((unsigned long)_27876 + (unsigned long)HIGH_BITS) >= 0) 
                _27876 = NewDouble((double)_27876);
                _27877 = _ix_54045 + _offset_54073;
                if ((long)((unsigned long)_27877 + (unsigned long)HIGH_BITS) >= 0) 
                _27877 = NewDouble((double)_27877);
                if (IS_ATOM_INT(_27877)) {
                    _27878 = _27877 + _size_54087;
                    if ((long)((unsigned long)_27878 + (unsigned long)HIGH_BITS) >= 0) 
                    _27878 = NewDouble((double)_27878);
                }
                else {
                    _27878 = NewDouble(DBL_PTR(_27877)->dbl + (double)_size_54087);
                }
                DeRef(_27877);
                _27877 = NOVALUE;
                _64replace_code(_27875, _27876, _27878);
                _27875 = NOVALUE;
                _27876 = NOVALUE;
                _27878 = NOVALUE;

                /** 						Code = eu:replace( Code, code, ix + offset, ix + offset + length( code ) -1 )*/
                _27879 = _ix_54045 + _offset_54073;
                if ((long)((unsigned long)_27879 + (unsigned long)HIGH_BITS) >= 0) 
                _27879 = NewDouble((double)_27879);
                _27880 = _ix_54045 + _offset_54073;
                if ((long)((unsigned long)_27880 + (unsigned long)HIGH_BITS) >= 0) 
                _27880 = NewDouble((double)_27880);
                if (IS_SEQUENCE(_code_54061)){
                        _27881 = SEQ_PTR(_code_54061)->length;
                }
                else {
                    _27881 = 1;
                }
                if (IS_ATOM_INT(_27880)) {
                    _27882 = _27880 + _27881;
                    if ((long)((unsigned long)_27882 + (unsigned long)HIGH_BITS) >= 0) 
                    _27882 = NewDouble((double)_27882);
                }
                else {
                    _27882 = NewDouble(DBL_PTR(_27880)->dbl + (double)_27881);
                }
                DeRef(_27880);
                _27880 = NOVALUE;
                _27881 = NOVALUE;
                if (IS_ATOM_INT(_27882)) {
                    _27883 = _27882 - 1;
                    if ((long)((unsigned long)_27883 +(unsigned long) HIGH_BITS) >= 0){
                        _27883 = NewDouble((double)_27883);
                    }
                }
                else {
                    _27883 = NewDouble(DBL_PTR(_27882)->dbl - (double)1);
                }
                DeRef(_27882);
                _27882 = NOVALUE;
                {
                    int p1 = _26Code_12071;
                    int p2 = _code_54061;
                    int p3 = _27879;
                    int p4 = _27883;
                    struct replace_block replace_params;
                    replace_params.copy_to   = &p1;
                    replace_params.copy_from = &p2;
                    replace_params.start     = &p3;
                    replace_params.stop      = &p4;
                    replace_params.target    = &_26Code_12071;
                    Replace( &replace_params );
                }
                DeRef(_27879);
                _27879 = NOVALUE;
                DeRef(_27883);
                _27883 = NOVALUE;

                /** 						offset += length(code) - size - 1*/
                if (IS_SEQUENCE(_code_54061)){
                        _27885 = SEQ_PTR(_code_54061)->length;
                }
                else {
                    _27885 = 1;
                }
                _27886 = _27885 - _size_54087;
                if ((long)((unsigned long)_27886 +(unsigned long) HIGH_BITS) >= 0){
                    _27886 = NewDouble((double)_27886);
                }
                _27885 = NOVALUE;
                if (IS_ATOM_INT(_27886)) {
                    _27887 = _27886 - 1;
                    if ((long)((unsigned long)_27887 +(unsigned long) HIGH_BITS) >= 0){
                        _27887 = NewDouble((double)_27887);
                    }
                }
                else {
                    _27887 = NewDouble(DBL_PTR(_27886)->dbl - (double)1);
                }
                DeRef(_27886);
                _27886 = NOVALUE;
                if (IS_ATOM_INT(_27887)) {
                    _offset_54073 = _offset_54073 + _27887;
                }
                else {
                    _offset_54073 = NewDouble((double)_offset_54073 + DBL_PTR(_27887)->dbl);
                }
                DeRef(_27887);
                _27887 = NOVALUE;
                if (!IS_ATOM_INT(_offset_54073)) {
                    _1 = (long)(DBL_PTR(_offset_54073)->dbl);
                    DeRefDS(_offset_54073);
                    _offset_54073 = _1;
                }
LA: 
                DeRef(_op_54084);
                _op_54084 = NOVALUE;

                /** 				end for*/
                _o_54075 = _o_54075 + 1;
                goto L8; // [418] 210
L9: 
                ;
            }

            /** 				SymTab[calling_sub][S_CODE] = Code*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _27SymTab_10921 = MAKE_SEQ(_2);
            }
            _3 = (int)(_calling_sub_54047 + ((s1_ptr)_2)->base);
            RefDS(_26Code_12071);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_26S_CODE_11666))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _26S_CODE_11666);
            _1 = *(int *)_2;
            *(int *)_2 = _26Code_12071;
            DeRef(_1);
            _27889 = NOVALUE;

            /** 				SymTab[calling_sub][S_LINETAB] = LineTable*/
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _27SymTab_10921 = MAKE_SEQ(_2);
            }
            _3 = (int)(_calling_sub_54047 + ((s1_ptr)_2)->base);
            RefDS(_26LineTable_12072);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_26S_LINETAB_11689))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_LINETAB_11689)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _26S_LINETAB_11689);
            _1 = *(int *)_2;
            *(int *)_2 = _26LineTable_12072;
            DeRef(_1);
            _27891 = NOVALUE;
            DeRef(_code_54061);
            _code_54061 = NOVALUE;
            DeRef(_calls_54062);
            _calls_54062 = NOVALUE;

            /** 			end for*/
            _cx_54042 = _cx_54042 + 1;
            goto L6; // [461] 92
L7: 
            ;
        }
L3: 

        /** 	end for*/
L5: 
        _i_54028 = _i_54028 + 1;
        goto L1; // [471] 20
L2: 
        ;
    }

    /** end procedure*/
    _27836 = NOVALUE;
    _27842 = NOVALUE;
    return;
    ;
}



// 0x4EBB75CB
