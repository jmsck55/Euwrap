// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _53c_putc(int _c_45540)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_45540)) {
        _1 = (long)(DBL_PTR(_c_45540)->dbl);
        DeRefDS(_c_45540);
        _c_45540 = _1;
    }

    /** 	if emit_c_output then*/
    if (_53emit_c_output_45527 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** 		puts(c_code, c)*/
    EPuts(_53c_code_45530, _c_45540); // DJP 

    /** 		update_checksum( c )*/
    _54update_checksum(_c_45540);
L1: 

    /** end procedure*/
    return;
    ;
}


void _53c_hputs(int _c_source_45545)
{
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_53emit_c_output_45527 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** 		puts(c_h, c_source)    */
    EPuts(_53c_h_45531, _c_source_45545); // DJP 
L1: 

    /** end procedure*/
    DeRefDS(_c_source_45545);
    return;
    ;
}


void _53c_puts(int _c_source_45549)
{
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_53emit_c_output_45527 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** 		puts(c_code, c_source)*/
    EPuts(_53c_code_45530, _c_source_45549); // DJP 

    /** 		update_checksum( c_source )*/
    RefDS(_c_source_45549);
    _54update_checksum(_c_source_45549);
L1: 

    /** end procedure*/
    DeRefDS(_c_source_45549);
    return;
    ;
}


void _53c_hprintf(int _format_45554, int _value_45555)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_value_45555)) {
        _1 = (long)(DBL_PTR(_value_45555)->dbl);
        DeRefDS(_value_45555);
        _value_45555 = _1;
    }

    /** 	if emit_c_output then*/
    if (_53emit_c_output_45527 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** 		printf(c_h, format, value)*/
    EPrintf(_53c_h_45531, _format_45554, _value_45555);
L1: 

    /** end procedure*/
    DeRefDS(_format_45554);
    return;
    ;
}


void _53c_printf(int _format_45559, int _value_45560)
{
    int _text_45562 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_53emit_c_output_45527 == 0)
    {
        goto L1; // [7] 29
    }
    else{
    }

    /** 		sequence text = sprintf( format, value )*/
    DeRefi(_text_45562);
    _text_45562 = EPrintf(-9999999, _format_45559, _value_45560);

    /** 		puts(c_code, text)*/
    EPuts(_53c_code_45530, _text_45562); // DJP 

    /** 		update_checksum( text )*/
    RefDS(_text_45562);
    _54update_checksum(_text_45562);
L1: 
    DeRefi(_text_45562);
    _text_45562 = NOVALUE;

    /** end procedure*/
    DeRefDS(_format_45559);
    DeRef(_value_45560);
    return;
    ;
}


void _53c_printf8(int _value_45573)
{
    int _buff_45574 = NOVALUE;
    int _neg_45575 = NOVALUE;
    int _p_45576 = NOVALUE;
    int _24122 = NOVALUE;
    int _24121 = NOVALUE;
    int _24120 = NOVALUE;
    int _24118 = NOVALUE;
    int _24117 = NOVALUE;
    int _24115 = NOVALUE;
    int _24114 = NOVALUE;
    int _24112 = NOVALUE;
    int _24111 = NOVALUE;
    int _24109 = NOVALUE;
    int _24107 = NOVALUE;
    int _24105 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_53emit_c_output_45527 == 0)
    {
        goto L1; // [5] 217
    }
    else{
    }

    /** 		neg = 0*/
    _neg_45575 = 0;

    /** 		buff = sprintf("%.16e", value)*/
    DeRef(_buff_45574);
    _buff_45574 = EPrintf(-9999999, _24103, _value_45573);

    /** 		if length(buff) < 10 then*/
    if (IS_SEQUENCE(_buff_45574)){
            _24105 = SEQ_PTR(_buff_45574)->length;
    }
    else {
        _24105 = 1;
    }
    if (_24105 >= 10)
    goto L2; // [24] 209

    /** 			p = 1*/
    _p_45576 = 1;

    /** 			while p <= length(buff) do*/
L3: 
    if (IS_SEQUENCE(_buff_45574)){
            _24107 = SEQ_PTR(_buff_45574)->length;
    }
    else {
        _24107 = 1;
    }
    if (_p_45576 > _24107)
    goto L4; // [41] 208

    /** 				if buff[p] = '-' then*/
    _2 = (int)SEQ_PTR(_buff_45574);
    _24109 = (int)*(((s1_ptr)_2)->base + _p_45576);
    if (binary_op_a(NOTEQ, _24109, 45)){
        _24109 = NOVALUE;
        goto L5; // [51] 63
    }
    _24109 = NOVALUE;

    /** 					neg = 1*/
    _neg_45575 = 1;
    goto L6; // [60] 197
L5: 

    /** 				elsif buff[p] = 'i' or buff[p] = 'I' then*/
    _2 = (int)SEQ_PTR(_buff_45574);
    _24111 = (int)*(((s1_ptr)_2)->base + _p_45576);
    if (IS_ATOM_INT(_24111)) {
        _24112 = (_24111 == 105);
    }
    else {
        _24112 = binary_op(EQUALS, _24111, 105);
    }
    _24111 = NOVALUE;
    if (IS_ATOM_INT(_24112)) {
        if (_24112 != 0) {
            goto L7; // [73] 90
        }
    }
    else {
        if (DBL_PTR(_24112)->dbl != 0.0) {
            goto L7; // [73] 90
        }
    }
    _2 = (int)SEQ_PTR(_buff_45574);
    _24114 = (int)*(((s1_ptr)_2)->base + _p_45576);
    if (IS_ATOM_INT(_24114)) {
        _24115 = (_24114 == 73);
    }
    else {
        _24115 = binary_op(EQUALS, _24114, 73);
    }
    _24114 = NOVALUE;
    if (_24115 == 0) {
        DeRef(_24115);
        _24115 = NOVALUE;
        goto L8; // [86] 114
    }
    else {
        if (!IS_ATOM_INT(_24115) && DBL_PTR(_24115)->dbl == 0.0){
            DeRef(_24115);
            _24115 = NOVALUE;
            goto L8; // [86] 114
        }
        DeRef(_24115);
        _24115 = NOVALUE;
    }
    DeRef(_24115);
    _24115 = NOVALUE;
L7: 

    /** 					buff = CREATE_INF*/
    RefDS(_53CREATE_INF_45565);
    DeRef(_buff_45574);
    _buff_45574 = _53CREATE_INF_45565;

    /** 					if neg then*/
    if (_neg_45575 == 0)
    {
        goto L4; // [97] 208
    }
    else{
    }

    /** 						buff = prepend(buff, '-')*/
    Prepend(&_buff_45574, _buff_45574, 45);

    /** 					exit*/
    goto L4; // [109] 208
    goto L6; // [111] 197
L8: 

    /** 				elsif buff[p] = 'n' or buff[p] = 'N' then*/
    _2 = (int)SEQ_PTR(_buff_45574);
    _24117 = (int)*(((s1_ptr)_2)->base + _p_45576);
    if (IS_ATOM_INT(_24117)) {
        _24118 = (_24117 == 110);
    }
    else {
        _24118 = binary_op(EQUALS, _24117, 110);
    }
    _24117 = NOVALUE;
    if (IS_ATOM_INT(_24118)) {
        if (_24118 != 0) {
            goto L9; // [124] 141
        }
    }
    else {
        if (DBL_PTR(_24118)->dbl != 0.0) {
            goto L9; // [124] 141
        }
    }
    _2 = (int)SEQ_PTR(_buff_45574);
    _24120 = (int)*(((s1_ptr)_2)->base + _p_45576);
    if (IS_ATOM_INT(_24120)) {
        _24121 = (_24120 == 78);
    }
    else {
        _24121 = binary_op(EQUALS, _24120, 78);
    }
    _24120 = NOVALUE;
    if (_24121 == 0) {
        DeRef(_24121);
        _24121 = NOVALUE;
        goto LA; // [137] 196
    }
    else {
        if (!IS_ATOM_INT(_24121) && DBL_PTR(_24121)->dbl == 0.0){
            DeRef(_24121);
            _24121 = NOVALUE;
            goto LA; // [137] 196
        }
        DeRef(_24121);
        _24121 = NOVALUE;
    }
    DeRef(_24121);
    _24121 = NOVALUE;
L9: 

    /** 					ifdef UNIX then*/

    /** 						if sequence(wat_path) then*/
    _24122 = 0;
    if (_24122 == 0)
    {
        _24122 = NOVALUE;
        goto LB; // [150] 173
    }
    else{
        _24122 = NOVALUE;
    }

    /** 							buff = CREATE_NAN2*/
    RefDS(_53CREATE_NAN2_45569);
    DeRef(_buff_45574);
    _buff_45574 = _53CREATE_NAN2_45569;

    /** 							if not neg then*/
    if (_neg_45575 != 0)
    goto L4; // [160] 208

    /** 								buff = prepend(buff, '-')*/
    Prepend(&_buff_45574, _buff_45574, 45);
    goto L4; // [170] 208
LB: 

    /** 							buff = CREATE_NAN1*/
    RefDS(_53CREATE_NAN1_45567);
    DeRef(_buff_45574);
    _buff_45574 = _53CREATE_NAN1_45567;

    /** 							if neg then*/
    if (_neg_45575 == 0)
    {
        goto L4; // [180] 208
    }
    else{
    }

    /** 								buff = prepend(buff, '-')*/
    Prepend(&_buff_45574, _buff_45574, 45);

    /** 						exit*/
    goto L4; // [193] 208
LA: 
L6: 

    /** 				p += 1*/
    _p_45576 = _p_45576 + 1;

    /** 			end while*/
    goto L3; // [205] 38
L4: 
L2: 

    /** 		puts(c_code, buff)*/
    EPuts(_53c_code_45530, _buff_45574); // DJP 
L1: 

    /** end procedure*/
    DeRef(_value_45573);
    DeRef(_buff_45574);
    DeRef(_24112);
    _24112 = NOVALUE;
    DeRef(_24118);
    _24118 = NOVALUE;
    return;
    ;
}


void _53adjust_indent_before(int _stmt_45619)
{
    int _i_45620 = NOVALUE;
    int _lb_45622 = NOVALUE;
    int _rb_45623 = NOVALUE;
    int _24139 = NOVALUE;
    int _24137 = NOVALUE;
    int _24135 = NOVALUE;
    int _24129 = NOVALUE;
    int _24128 = NOVALUE;
    int _0, _1, _2;
    

    /** 	lb = FALSE*/
    _lb_45622 = _9FALSE_428;

    /** 	rb = FALSE*/
    _rb_45623 = _9FALSE_428;

    /** 	for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_45619)){
            _24128 = SEQ_PTR(_stmt_45619)->length;
    }
    else {
        _24128 = 1;
    }
    {
        int _p_45627;
        _p_45627 = 1;
L1: 
        if (_p_45627 > _24128){
            goto L2; // [22] 102
        }

        /** 		switch stmt[p] do*/
        _2 = (int)SEQ_PTR(_stmt_45619);
        _24129 = (int)*(((s1_ptr)_2)->base + _p_45627);
        if (IS_SEQUENCE(_24129) ){
            goto L3; // [35] 95
        }
        if(!IS_ATOM_INT(_24129)){
            if( (DBL_PTR(_24129)->dbl != (double) ((int) DBL_PTR(_24129)->dbl) ) ){
                goto L3; // [35] 95
            }
            _0 = (int) DBL_PTR(_24129)->dbl;
        }
        else {
            _0 = _24129;
        };
        _24129 = NOVALUE;
        switch ( _0 ){ 

            /** 			case '\n' then*/
            case 10:

            /** 				exit*/
            goto L2; // [46] 102
            goto L3; // [48] 95

            /** 			case  '}' then*/
            case 125:

            /** 				rb = TRUE*/
            _rb_45623 = _9TRUE_430;

            /** 				if lb then*/
            if (_lb_45622 == 0)
            {
                goto L3; // [63] 95
            }
            else{
            }

            /** 					exit*/
            goto L2; // [68] 102
            goto L3; // [71] 95

            /** 			case '{' then*/
            case 123:

            /** 				lb = TRUE*/
            _lb_45622 = _9TRUE_430;

            /** 				if rb then */
            if (_rb_45623 == 0)
            {
                goto L4; // [86] 94
            }
            else{
            }

            /** 					exit*/
            goto L2; // [91] 102
L4: 
        ;}L3: 

        /** 	end for*/
        _p_45627 = _p_45627 + 1;
        goto L1; // [97] 29
L2: 
        ;
    }

    /** 	if rb then*/
    if (_rb_45623 == 0)
    {
        goto L5; // [104] 122
    }
    else{
    }

    /** 		if not lb then*/
    if (_lb_45622 != 0)
    goto L6; // [109] 121

    /** 			indent -= 4*/
    _53indent_45613 = _53indent_45613 - 4;
L6: 
L5: 

    /** 	i = indent + temp_indent*/
    _i_45620 = _53indent_45613 + _53temp_indent_45614;

    /** 	while i >= length(big_blanks) do*/
L7: 
    if (IS_SEQUENCE(_53big_blanks_45615)){
            _24135 = SEQ_PTR(_53big_blanks_45615)->length;
    }
    else {
        _24135 = 1;
    }
    if (_i_45620 < _24135)
    goto L8; // [140] 163

    /** 		c_puts(big_blanks)*/
    RefDS(_53big_blanks_45615);
    _53c_puts(_53big_blanks_45615);

    /** 		i -= length(big_blanks)*/
    if (IS_SEQUENCE(_53big_blanks_45615)){
            _24137 = SEQ_PTR(_53big_blanks_45615)->length;
    }
    else {
        _24137 = 1;
    }
    _i_45620 = _i_45620 - _24137;
    _24137 = NOVALUE;

    /** 	end while*/
    goto L7; // [160] 137
L8: 

    /** 	c_puts(big_blanks[1..i])*/
    rhs_slice_target = (object_ptr)&_24139;
    RHS_Slice(_53big_blanks_45615, 1, _i_45620);
    _53c_puts(_24139);
    _24139 = NOVALUE;

    /** 	temp_indent = 0    */
    _53temp_indent_45614 = 0;

    /** end procedure*/
    DeRefDS(_stmt_45619);
    return;
    ;
}


void _53adjust_indent_after(int _stmt_45652)
{
    int _24160 = NOVALUE;
    int _24159 = NOVALUE;
    int _24157 = NOVALUE;
    int _24155 = NOVALUE;
    int _24154 = NOVALUE;
    int _24151 = NOVALUE;
    int _24149 = NOVALUE;
    int _24148 = NOVALUE;
    int _24145 = NOVALUE;
    int _24141 = NOVALUE;
    int _24140 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_45652)){
            _24140 = SEQ_PTR(_stmt_45652)->length;
    }
    else {
        _24140 = 1;
    }
    {
        int _p_45654;
        _p_45654 = 1;
L1: 
        if (_p_45654 > _24140){
            goto L2; // [8] 61
        }

        /** 		switch stmt[p] do*/
        _2 = (int)SEQ_PTR(_stmt_45652);
        _24141 = (int)*(((s1_ptr)_2)->base + _p_45654);
        if (IS_SEQUENCE(_24141) ){
            goto L3; // [21] 54
        }
        if(!IS_ATOM_INT(_24141)){
            if( (DBL_PTR(_24141)->dbl != (double) ((int) DBL_PTR(_24141)->dbl) ) ){
                goto L3; // [21] 54
            }
            _0 = (int) DBL_PTR(_24141)->dbl;
        }
        else {
            _0 = _24141;
        };
        _24141 = NOVALUE;
        switch ( _0 ){ 

            /** 			case '\n' then*/
            case 10:

            /** 				exit*/
            goto L2; // [32] 61
            goto L3; // [34] 54

            /** 			case '{' then*/
            case 123:

            /** 				indent += 4*/
            _53indent_45613 = _53indent_45613 + 4;

            /** 				return*/
            DeRefDS(_stmt_45652);
            return;
        ;}L3: 

        /** 	end for*/
        _p_45654 = _p_45654 + 1;
        goto L1; // [56] 15
L2: 
        ;
    }

    /** 	if length(stmt) < 3 then*/
    if (IS_SEQUENCE(_stmt_45652)){
            _24145 = SEQ_PTR(_stmt_45652)->length;
    }
    else {
        _24145 = 1;
    }
    if (_24145 >= 3)
    goto L4; // [66] 76

    /** 		return*/
    DeRefDS(_stmt_45652);
    return;
L4: 

    /** 	if not equal("if ", stmt[1..3]) then*/
    rhs_slice_target = (object_ptr)&_24148;
    RHS_Slice(_stmt_45652, 1, 3);
    if (_24147 == _24148)
    _24149 = 1;
    else if (IS_ATOM_INT(_24147) && IS_ATOM_INT(_24148))
    _24149 = 0;
    else
    _24149 = (compare(_24147, _24148) == 0);
    DeRefDS(_24148);
    _24148 = NOVALUE;
    if (_24149 != 0)
    goto L5; // [87] 96
    _24149 = NOVALUE;

    /** 		return*/
    DeRefDS(_stmt_45652);
    return;
L5: 

    /** 	if length(stmt) < 5 then*/
    if (IS_SEQUENCE(_stmt_45652)){
            _24151 = SEQ_PTR(_stmt_45652)->length;
    }
    else {
        _24151 = 1;
    }
    if (_24151 >= 5)
    goto L6; // [101] 111

    /** 		return*/
    DeRefDS(_stmt_45652);
    return;
L6: 

    /** 	if not equal("else", stmt[1..4]) then*/
    rhs_slice_target = (object_ptr)&_24154;
    RHS_Slice(_stmt_45652, 1, 4);
    if (_24153 == _24154)
    _24155 = 1;
    else if (IS_ATOM_INT(_24153) && IS_ATOM_INT(_24154))
    _24155 = 0;
    else
    _24155 = (compare(_24153, _24154) == 0);
    DeRefDS(_24154);
    _24154 = NOVALUE;
    if (_24155 != 0)
    goto L7; // [122] 131
    _24155 = NOVALUE;

    /** 		return*/
    DeRefDS(_stmt_45652);
    return;
L7: 

    /** 	if not find(stmt[5], {" \n"}) then*/
    _2 = (int)SEQ_PTR(_stmt_45652);
    _24157 = (int)*(((s1_ptr)_2)->base + 5);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_24158);
    *((int *)(_2+4)) = _24158;
    _24159 = MAKE_SEQ(_1);
    _24160 = find_from(_24157, _24159, 1);
    _24157 = NOVALUE;
    DeRefDS(_24159);
    _24159 = NOVALUE;
    if (_24160 != 0)
    goto L8; // [146] 155
    _24160 = NOVALUE;

    /** 		return*/
    DeRefDS(_stmt_45652);
    return;
L8: 

    /** 	temp_indent = 4*/
    _53temp_indent_45614 = 4;

    /** end procedure*/
    DeRefDS(_stmt_45652);
    return;
    ;
}



// 0x3C6AEC21
