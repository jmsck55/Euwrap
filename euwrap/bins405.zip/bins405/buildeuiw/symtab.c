// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _52hashfn(int _name_46145)
{
    int _len_46146 = NOVALUE;
    int _val_46147 = NOVALUE;
    int _int_46148 = NOVALUE;
    int _24400 = NOVALUE;
    int _24399 = NOVALUE;
    int _24396 = NOVALUE;
    int _24395 = NOVALUE;
    int _24384 = NOVALUE;
    int _24380 = NOVALUE;
    int _0, _1, _2;
    

    /** 	len = length(name)*/
    if (IS_SEQUENCE(_name_46145)){
            _len_46146 = SEQ_PTR(_name_46145)->length;
    }
    else {
        _len_46146 = 1;
    }

    /** 	val = name[1]*/
    _2 = (int)SEQ_PTR(_name_46145);
    _val_46147 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_val_46147))
    _val_46147 = (long)DBL_PTR(_val_46147)->dbl;

    /** 	int = name[$]*/
    if (IS_SEQUENCE(_name_46145)){
            _24380 = SEQ_PTR(_name_46145)->length;
    }
    else {
        _24380 = 1;
    }
    _2 = (int)SEQ_PTR(_name_46145);
    _int_46148 = (int)*(((s1_ptr)_2)->base + _24380);
    if (!IS_ATOM_INT(_int_46148))
    _int_46148 = (long)DBL_PTR(_int_46148)->dbl;

    /** 	int *= 256*/
    _int_46148 = _int_46148 * 256;

    /** 	val *= 2*/
    _val_46147 = _val_46147 + _val_46147;

    /** 	val += int + len*/
    _24384 = _int_46148 + _len_46146;
    if ((long)((unsigned long)_24384 + (unsigned long)HIGH_BITS) >= 0) 
    _24384 = NewDouble((double)_24384);
    if (IS_ATOM_INT(_24384)) {
        _val_46147 = _val_46147 + _24384;
    }
    else {
        _val_46147 = NewDouble((double)_val_46147 + DBL_PTR(_24384)->dbl);
    }
    DeRef(_24384);
    _24384 = NOVALUE;
    if (!IS_ATOM_INT(_val_46147)) {
        _1 = (long)(DBL_PTR(_val_46147)->dbl);
        DeRefDS(_val_46147);
        _val_46147 = _1;
    }

    /** 	if len = 3 then*/
    if (_len_46146 != 3)
    goto L1; // [51] 78

    /** 		val *= 32*/
    _val_46147 = _val_46147 * 32;

    /** 		int = name[2]*/
    _2 = (int)SEQ_PTR(_name_46145);
    _int_46148 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_46148))
    _int_46148 = (long)DBL_PTR(_int_46148)->dbl;

    /** 		val += int*/
    _val_46147 = _val_46147 + _int_46148;
    goto L2; // [75] 133
L1: 

    /** 	elsif len > 3 then*/
    if (_len_46146 <= 3)
    goto L3; // [80] 132

    /** 		val *= 32*/
    _val_46147 = _val_46147 * 32;

    /** 		int = name[2]*/
    _2 = (int)SEQ_PTR(_name_46145);
    _int_46148 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_46148))
    _int_46148 = (long)DBL_PTR(_int_46148)->dbl;

    /** 		val += int*/
    _val_46147 = _val_46147 + _int_46148;

    /** 		val *= 32*/
    _val_46147 = _val_46147 * 32;

    /** 		int = name[$-1]*/
    if (IS_SEQUENCE(_name_46145)){
            _24395 = SEQ_PTR(_name_46145)->length;
    }
    else {
        _24395 = 1;
    }
    _24396 = _24395 - 1;
    _24395 = NOVALUE;
    _2 = (int)SEQ_PTR(_name_46145);
    _int_46148 = (int)*(((s1_ptr)_2)->base + _24396);
    if (!IS_ATOM_INT(_int_46148))
    _int_46148 = (long)DBL_PTR(_int_46148)->dbl;

    /** 		val += int*/
    _val_46147 = _val_46147 + _int_46148;
L3: 
L2: 

    /** 	return remainder(val, NBUCKETS) + 1*/
    _24399 = (_val_46147 % 2003);
    _24400 = _24399 + 1;
    _24399 = NOVALUE;
    DeRefDS(_name_46145);
    DeRef(_24396);
    _24396 = NOVALUE;
    return _24400;
    ;
}


void _52remove_symbol(int _sym_46177)
{
    int _hash_46178 = NOVALUE;
    int _st_ptr_46179 = NOVALUE;
    int _24415 = NOVALUE;
    int _24414 = NOVALUE;
    int _24412 = NOVALUE;
    int _24411 = NOVALUE;
    int _24410 = NOVALUE;
    int _24408 = NOVALUE;
    int _24406 = NOVALUE;
    int _24405 = NOVALUE;
    int _24404 = NOVALUE;
    int _24401 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_46177)) {
        _1 = (long)(DBL_PTR(_sym_46177)->dbl);
        DeRefDS(_sym_46177);
        _sym_46177 = _1;
    }

    /** 	hash = SymTab[sym][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24401 = (int)*(((s1_ptr)_2)->base + _sym_46177);
    _2 = (int)SEQ_PTR(_24401);
    _hash_46178 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_hash_46178)){
        _hash_46178 = (long)DBL_PTR(_hash_46178)->dbl;
    }
    _24401 = NOVALUE;

    /** 	st_ptr = buckets[hash]*/
    _2 = (int)SEQ_PTR(_52buckets_46126);
    _st_ptr_46179 = (int)*(((s1_ptr)_2)->base + _hash_46178);
    if (!IS_ATOM_INT(_st_ptr_46179))
    _st_ptr_46179 = (long)DBL_PTR(_st_ptr_46179)->dbl;

    /** 	while st_ptr and st_ptr != sym do*/
L1: 
    if (_st_ptr_46179 == 0) {
        goto L2; // [32] 65
    }
    _24405 = (_st_ptr_46179 != _sym_46177);
    if (_24405 == 0)
    {
        DeRef(_24405);
        _24405 = NOVALUE;
        goto L2; // [41] 65
    }
    else{
        DeRef(_24405);
        _24405 = NOVALUE;
    }

    /** 		st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24406 = (int)*(((s1_ptr)_2)->base + _st_ptr_46179);
    _2 = (int)SEQ_PTR(_24406);
    _st_ptr_46179 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_st_ptr_46179)){
        _st_ptr_46179 = (long)DBL_PTR(_st_ptr_46179)->dbl;
    }
    _24406 = NOVALUE;

    /** 	end while*/
    goto L1; // [62] 32
L2: 

    /** 	if st_ptr then*/
    if (_st_ptr_46179 == 0)
    {
        goto L3; // [67] 134
    }
    else{
    }

    /** 		if st_ptr = buckets[hash] then*/
    _2 = (int)SEQ_PTR(_52buckets_46126);
    _24408 = (int)*(((s1_ptr)_2)->base + _hash_46178);
    if (binary_op_a(NOTEQ, _st_ptr_46179, _24408)){
        _24408 = NOVALUE;
        goto L4; // [78] 105
    }
    _24408 = NOVALUE;

    /** 			buckets[hash] = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24410 = (int)*(((s1_ptr)_2)->base + _st_ptr_46179);
    _2 = (int)SEQ_PTR(_24410);
    _24411 = (int)*(((s1_ptr)_2)->base + 9);
    _24410 = NOVALUE;
    Ref(_24411);
    _2 = (int)SEQ_PTR(_52buckets_46126);
    _2 = (int)(((s1_ptr)_2)->base + _hash_46178);
    _1 = *(int *)_2;
    *(int *)_2 = _24411;
    if( _1 != _24411 ){
        DeRef(_1);
    }
    _24411 = NOVALUE;
    goto L5; // [102] 133
L4: 

    /** 			SymTab[st_ptr][S_SAMEHASH] = SymTab[sym][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_st_ptr_46179 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24414 = (int)*(((s1_ptr)_2)->base + _sym_46177);
    _2 = (int)SEQ_PTR(_24414);
    _24415 = (int)*(((s1_ptr)_2)->base + 9);
    _24414 = NOVALUE;
    Ref(_24415);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _24415;
    if( _1 != _24415 ){
        DeRef(_1);
    }
    _24415 = NOVALUE;
    _24412 = NOVALUE;
L5: 
L3: 

    /** end procedure*/
    return;
    ;
}


int _52NewBasicEntry(int _name_46211, int _varnum_46212, int _scope_46213, int _token_46214, int _hashval_46215, int _samehash_46217, int _type_sym_46219)
{
    int _new_46220 = NOVALUE;
    int _24424 = NOVALUE;
    int _24422 = NOVALUE;
    int _24421 = NOVALUE;
    int _24420 = NOVALUE;
    int _24419 = NOVALUE;
    int _24418 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_varnum_46212)) {
        _1 = (long)(DBL_PTR(_varnum_46212)->dbl);
        DeRefDS(_varnum_46212);
        _varnum_46212 = _1;
    }
    if (!IS_ATOM_INT(_scope_46213)) {
        _1 = (long)(DBL_PTR(_scope_46213)->dbl);
        DeRefDS(_scope_46213);
        _scope_46213 = _1;
    }
    if (!IS_ATOM_INT(_token_46214)) {
        _1 = (long)(DBL_PTR(_token_46214)->dbl);
        DeRefDS(_token_46214);
        _token_46214 = _1;
    }
    if (!IS_ATOM_INT(_hashval_46215)) {
        _1 = (long)(DBL_PTR(_hashval_46215)->dbl);
        DeRefDS(_hashval_46215);
        _hashval_46215 = _1;
    }
    if (!IS_ATOM_INT(_samehash_46217)) {
        _1 = (long)(DBL_PTR(_samehash_46217)->dbl);
        DeRefDS(_samehash_46217);
        _samehash_46217 = _1;
    }
    if (!IS_ATOM_INT(_type_sym_46219)) {
        _1 = (long)(DBL_PTR(_type_sym_46219)->dbl);
        DeRefDS(_type_sym_46219);
        _type_sym_46219 = _1;
    }

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L1; // [19] 33
    }
    else{
    }

    /** 		new = repeat(0, SIZEOF_ROUTINE_ENTRY)*/
    DeRef(_new_46220);
    _new_46220 = Repeat(0, _26SIZEOF_ROUTINE_ENTRY_11779);
    goto L2; // [30] 42
L1: 

    /** 		new = repeat(0, SIZEOF_VAR_ENTRY)*/
    DeRef(_new_46220);
    _new_46220 = Repeat(0, _26SIZEOF_VAR_ENTRY_11782);
L2: 

    /** 	new[S_NEXT] = 0*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	new[S_NAME] = name*/
    RefDS(_name_46211);
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_NAME_11654))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_NAME_11654);
    _1 = *(int *)_2;
    *(int *)_2 = _name_46211;
    DeRef(_1);

    /** 	new[S_SCOPE] = scope*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _scope_46213;
    DeRef(_1);

    /** 	new[S_MODE] = M_NORMAL*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);

    /** 	new[S_USAGE] = U_UNUSED*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	new[S_FILE_NO] = current_file_no*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_FILE_NO_11650))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    _1 = *(int *)_2;
    *(int *)_2 = _26current_file_no_11982;
    DeRef(_1);

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L3; // [102] 327
    }
    else{
    }

    /** 		new[S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		new[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 38);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		new[S_SEQ_ELEM_NEW] = TYPE_NULL -- starting point for ORing*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 43);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		new[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 44);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 45);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		new[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 46);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_ARG_MIN] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 47);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);

    /** 		new[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_26NOVALUE_11836)) {
        if ((unsigned long)_26NOVALUE_11836 == 0xC0000000)
        _24418 = (int)NewDouble((double)-0xC0000000);
        else
        _24418 = - _26NOVALUE_11836;
    }
    else {
        _24418 = unary_op(UMINUS, _26NOVALUE_11836);
    }
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 49);
    _1 = *(int *)_2;
    *(int *)_2 = _24418;
    if( _1 != _24418 ){
        DeRef(_1);
    }
    _24418 = NOVALUE;

    /** 		new[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 51);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);

    /** 		new[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_26NOVALUE_11836)) {
        if ((unsigned long)_26NOVALUE_11836 == 0xC0000000)
        _24419 = (int)NewDouble((double)-0xC0000000);
        else
        _24419 = - _26NOVALUE_11836;
    }
    else {
        _24419 = unary_op(UMINUS, _26NOVALUE_11836);
    }
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 52);
    _1 = *(int *)_2;
    *(int *)_2 = _24419;
    if( _1 != _24419 ){
        DeRef(_1);
    }
    _24419 = NOVALUE;

    /** 		new[S_SEQ_LEN] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);

    /** 		new[S_SEQ_LEN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_26NOVALUE_11836)) {
        if ((unsigned long)_26NOVALUE_11836 == 0xC0000000)
        _24420 = (int)NewDouble((double)-0xC0000000);
        else
        _24420 = - _26NOVALUE_11836;
    }
    else {
        _24420 = unary_op(UMINUS, _26NOVALUE_11836);
    }
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _24420;
    if( _1 != _24420 ){
        DeRef(_1);
    }
    _24420 = NOVALUE;

    /** 		new[S_NREFS] = 0*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_ONE_REF] = TRUE          -- assume TRUE until we find otherwise*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 35);
    _1 = *(int *)_2;
    *(int *)_2 = _9TRUE_430;
    DeRef(_1);

    /** 		new[S_RI_TARGET] = 0*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 53);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_OBJ_MIN] = MININT*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = -1073741824;
    DeRef(_1);

    /** 		new[S_OBJ_MIN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_26NOVALUE_11836)) {
        if ((unsigned long)_26NOVALUE_11836 == 0xC0000000)
        _24421 = (int)NewDouble((double)-0xC0000000);
        else
        _24421 = - _26NOVALUE_11836;
    }
    else {
        _24421 = unary_op(UMINUS, _26NOVALUE_11836);
    }
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _24421;
    if( _1 != _24421 ){
        DeRef(_1);
    }
    _24421 = NOVALUE;

    /** 		new[S_OBJ_MAX] = MAXINT*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = 1073741823;
    DeRef(_1);

    /** 		new[S_OBJ_MAX_NEW] = -NOVALUE -- missing from C code? (not needed)*/
    if (IS_ATOM_INT(_26NOVALUE_11836)) {
        if ((unsigned long)_26NOVALUE_11836 == 0xC0000000)
        _24422 = (int)NewDouble((double)-0xC0000000);
        else
        _24422 = - _26NOVALUE_11836;
    }
    else {
        _24422 = unary_op(UMINUS, _26NOVALUE_11836);
    }
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 42);
    _1 = *(int *)_2;
    *(int *)_2 = _24422;
    if( _1 != _24422 ){
        DeRef(_1);
    }
    _24422 = NOVALUE;
L3: 

    /** 	new[S_TOKEN] = token*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_TOKEN_11659))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    _1 = *(int *)_2;
    *(int *)_2 = _token_46214;
    DeRef(_1);

    /** 	new[S_VARNUM] = varnum*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 16);
    _1 = *(int *)_2;
    *(int *)_2 = _varnum_46212;
    DeRef(_1);

    /** 	new[S_INITLEVEL] = -1*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = -1;
    DeRef(_1);

    /** 	new[S_VTYPE] = type_sym*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _type_sym_46219;
    DeRef(_1);

    /** 	new[S_HASHVAL] = hashval*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _hashval_46215;
    DeRef(_1);

    /** 	new[S_SAMEHASH] = samehash*/
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _samehash_46217;
    DeRef(_1);

    /** 	new[S_OBJ] = NOVALUE -- important*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_new_46220);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_46220 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);

    /** 	SymTab = append(SymTab, new)*/
    RefDS(_new_46220);
    Append(&_27SymTab_10921, _27SymTab_10921, _new_46220);

    /** 	return length(SymTab)*/
    if (IS_SEQUENCE(_27SymTab_10921)){
            _24424 = SEQ_PTR(_27SymTab_10921)->length;
    }
    else {
        _24424 = 1;
    }
    DeRefDS(_name_46211);
    DeRefDS(_new_46220);
    return _24424;
    ;
}


int _52NewEntry(int _name_46299, int _varnum_46300, int _scope_46301, int _token_46302, int _hashval_46303, int _samehash_46305, int _type_sym_46307)
{
    int _new_46309 = NOVALUE;
    int _24426 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_varnum_46300)) {
        _1 = (long)(DBL_PTR(_varnum_46300)->dbl);
        DeRefDS(_varnum_46300);
        _varnum_46300 = _1;
    }
    if (!IS_ATOM_INT(_scope_46301)) {
        _1 = (long)(DBL_PTR(_scope_46301)->dbl);
        DeRefDS(_scope_46301);
        _scope_46301 = _1;
    }
    if (!IS_ATOM_INT(_token_46302)) {
        _1 = (long)(DBL_PTR(_token_46302)->dbl);
        DeRefDS(_token_46302);
        _token_46302 = _1;
    }
    if (!IS_ATOM_INT(_hashval_46303)) {
        _1 = (long)(DBL_PTR(_hashval_46303)->dbl);
        DeRefDS(_hashval_46303);
        _hashval_46303 = _1;
    }
    if (!IS_ATOM_INT(_samehash_46305)) {
        _1 = (long)(DBL_PTR(_samehash_46305)->dbl);
        DeRefDS(_samehash_46305);
        _samehash_46305 = _1;
    }
    if (!IS_ATOM_INT(_type_sym_46307)) {
        _1 = (long)(DBL_PTR(_type_sym_46307)->dbl);
        DeRefDS(_type_sym_46307);
        _type_sym_46307 = _1;
    }

    /** 	symtab_index new = NewBasicEntry( name, varnum, scope, token, hashval, samehash, type_sym )*/
    RefDS(_name_46299);
    _new_46309 = _52NewBasicEntry(_name_46299, _varnum_46300, _scope_46301, _token_46302, _hashval_46303, _samehash_46305, _type_sym_46307);
    if (!IS_ATOM_INT(_new_46309)) {
        _1 = (long)(DBL_PTR(_new_46309)->dbl);
        DeRefDS(_new_46309);
        _new_46309 = _1;
    }

    /** 	if last_sym then*/
    if (_52last_sym_46139 == 0)
    {
        goto L1; // [33] 54
    }
    else{
    }

    /** 		SymTab[last_sym][S_NEXT] = new*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_52last_sym_46139 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _new_46309;
    DeRef(_1);
    _24426 = NOVALUE;
L1: 

    /** 	last_sym = new*/
    _52last_sym_46139 = _new_46309;

    /** 	if type_sym < 0 then*/
    if (_type_sym_46307 >= 0)
    goto L2; // [63] 76

    /** 		register_forward_type( last_sym, type_sym )*/
    _29register_forward_type(_52last_sym_46139, _type_sym_46307);
L2: 

    /** 	return last_sym*/
    DeRefDS(_name_46299);
    return _52last_sym_46139;
    ;
}


int _52tmp_alloc()
{
    int _new_entry_46324 = NOVALUE;
    int _24440 = NOVALUE;
    int _24438 = NOVALUE;
    int _24435 = NOVALUE;
    int _24432 = NOVALUE;
    int _24431 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence new_entry = repeat( 0, SIZEOF_TEMP_ENTRY )*/
    DeRef(_new_entry_46324);
    _new_entry_46324 = Repeat(0, _26SIZEOF_TEMP_ENTRY_11788);

    /** 	new_entry[S_USAGE] = T_UNKNOWN*/
    _2 = (int)SEQ_PTR(_new_entry_46324);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_46324 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    *(int *)_2 = 4;

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L1; // [23] 132
    }
    else{
    }

    /** 		new_entry[S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_entry_46324);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_46324 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    *(int *)_2 = 16;

    /** 		new_entry[S_OBJ_MIN] = MININT*/
    _2 = (int)SEQ_PTR(_new_entry_46324);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_46324 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    *(int *)_2 = -1073741824;

    /** 		new_entry[S_OBJ_MAX] = MAXINT*/
    _2 = (int)SEQ_PTR(_new_entry_46324);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_46324 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    *(int *)_2 = 1073741823;

    /** 		new_entry[S_SEQ_LEN] = NOVALUE*/
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(_new_entry_46324);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_46324 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    *(int *)_2 = _26NOVALUE_11836;

    /** 		new_entry[S_SEQ_ELEM] = TYPE_OBJECT  -- other fields set later*/
    _2 = (int)SEQ_PTR(_new_entry_46324);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_46324 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		if length(temp_name_type)+1 = 8087 then*/
    if (IS_SEQUENCE(_26temp_name_type_12065)){
            _24431 = SEQ_PTR(_26temp_name_type_12065)->length;
    }
    else {
        _24431 = 1;
    }
    _24432 = _24431 + 1;
    _24431 = NOVALUE;
    if (_24432 != 8087)
    goto L2; // [87] 106

    /** 			temp_name_type = append(temp_name_type, {0, 0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _24435 = MAKE_SEQ(_1);
    RefDS(_24435);
    Append(&_26temp_name_type_12065, _26temp_name_type_12065, _24435);
    DeRefDS(_24435);
    _24435 = NOVALUE;
L2: 

    /** 		temp_name_type = append(temp_name_type, TYPES_OBNL)*/
    RefDS(_53TYPES_OBNL_45524);
    Append(&_26temp_name_type_12065, _26temp_name_type_12065, _53TYPES_OBNL_45524);

    /** 		new_entry[S_TEMP_NAME] = length(temp_name_type)*/
    if (IS_SEQUENCE(_26temp_name_type_12065)){
            _24438 = SEQ_PTR(_26temp_name_type_12065)->length;
    }
    else {
        _24438 = 1;
    }
    _2 = (int)SEQ_PTR(_new_entry_46324);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_46324 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 34);
    _1 = *(int *)_2;
    *(int *)_2 = _24438;
    if( _1 != _24438 ){
        DeRef(_1);
    }
    _24438 = NOVALUE;
L1: 

    /** 	SymTab = append(SymTab, new_entry )*/
    RefDS(_new_entry_46324);
    Append(&_27SymTab_10921, _27SymTab_10921, _new_entry_46324);

    /** 	return length( SymTab )*/
    if (IS_SEQUENCE(_27SymTab_10921)){
            _24440 = SEQ_PTR(_27SymTab_10921)->length;
    }
    else {
        _24440 = 1;
    }
    DeRefDS(_new_entry_46324);
    DeRef(_24432);
    _24432 = NOVALUE;
    return _24440;
    ;
}


void _52DefinedYet(int _sym_46393)
{
    int _24460 = NOVALUE;
    int _24459 = NOVALUE;
    int _24458 = NOVALUE;
    int _24456 = NOVALUE;
    int _24455 = NOVALUE;
    int _24453 = NOVALUE;
    int _24452 = NOVALUE;
    int _24451 = NOVALUE;
    int _24450 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_46393)) {
        _1 = (long)(DBL_PTR(_sym_46393)->dbl);
        DeRefDS(_sym_46393);
        _sym_46393 = _1;
    }

    /** 	if not find(SymTab[sym][S_SCOPE],*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24450 = (int)*(((s1_ptr)_2)->base + _sym_46393);
    _2 = (int)SEQ_PTR(_24450);
    _24451 = (int)*(((s1_ptr)_2)->base + 4);
    _24450 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 9;
    *((int *)(_2+8)) = 10;
    *((int *)(_2+12)) = 7;
    _24452 = MAKE_SEQ(_1);
    _24453 = find_from(_24451, _24452, 1);
    _24451 = NOVALUE;
    DeRefDS(_24452);
    _24452 = NOVALUE;
    if (_24453 != 0)
    goto L1; // [34] 82
    _24453 = NOVALUE;

    /** 		if SymTab[sym][S_FILE_NO] = current_file_no then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24455 = (int)*(((s1_ptr)_2)->base + _sym_46393);
    _2 = (int)SEQ_PTR(_24455);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _24456 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _24456 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _24455 = NOVALUE;
    if (binary_op_a(NOTEQ, _24456, _26current_file_no_11982)){
        _24456 = NOVALUE;
        goto L2; // [53] 81
    }
    _24456 = NOVALUE;

    /** 			CompileErr(31, {SymTab[sym][S_NAME]})*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24458 = (int)*(((s1_ptr)_2)->base + _sym_46393);
    _2 = (int)SEQ_PTR(_24458);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _24459 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _24459 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _24458 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_24459);
    *((int *)(_2+4)) = _24459;
    _24460 = MAKE_SEQ(_1);
    _24459 = NOVALUE;
    _43CompileErr(31, _24460, 0);
    _24460 = NOVALUE;
L2: 
L1: 

    /** end procedure*/
    return;
    ;
}


int _52name_ext(int _s_46420)
{
    int _24467 = NOVALUE;
    int _24466 = NOVALUE;
    int _24465 = NOVALUE;
    int _24464 = NOVALUE;
    int _24462 = NOVALUE;
    int _24461 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_46420)){
            _24461 = SEQ_PTR(_s_46420)->length;
    }
    else {
        _24461 = 1;
    }
    {
        int _i_46422;
        _i_46422 = _24461;
L1: 
        if (_i_46422 < 1){
            goto L2; // [8] 55
        }

        /** 		if find(s[i], "/\\:") then*/
        _2 = (int)SEQ_PTR(_s_46420);
        _24462 = (int)*(((s1_ptr)_2)->base + _i_46422);
        _24464 = find_from(_24462, _24463, 1);
        _24462 = NOVALUE;
        if (_24464 == 0)
        {
            _24464 = NOVALUE;
            goto L3; // [26] 48
        }
        else{
            _24464 = NOVALUE;
        }

        /** 			return s[i+1 .. $]*/
        _24465 = _i_46422 + 1;
        if (IS_SEQUENCE(_s_46420)){
                _24466 = SEQ_PTR(_s_46420)->length;
        }
        else {
            _24466 = 1;
        }
        rhs_slice_target = (object_ptr)&_24467;
        RHS_Slice(_s_46420, _24465, _24466);
        DeRefDS(_s_46420);
        _24465 = NOVALUE;
        return _24467;
L3: 

        /** 	end for*/
        _i_46422 = _i_46422 + -1;
        goto L1; // [50] 15
L2: 
        ;
    }

    /** 	return s*/
    DeRef(_24465);
    _24465 = NOVALUE;
    DeRef(_24467);
    _24467 = NOVALUE;
    return _s_46420;
    ;
}


int _52NewStringSym(int _s_46439)
{
    int _p_46441 = NOVALUE;
    int _tp_46442 = NOVALUE;
    int _prev_46443 = NOVALUE;
    int _search_count_46444 = NOVALUE;
    int _24511 = NOVALUE;
    int _24509 = NOVALUE;
    int _24508 = NOVALUE;
    int _24507 = NOVALUE;
    int _24505 = NOVALUE;
    int _24504 = NOVALUE;
    int _24501 = NOVALUE;
    int _24499 = NOVALUE;
    int _24497 = NOVALUE;
    int _24496 = NOVALUE;
    int _24495 = NOVALUE;
    int _24493 = NOVALUE;
    int _24491 = NOVALUE;
    int _24489 = NOVALUE;
    int _24487 = NOVALUE;
    int _24484 = NOVALUE;
    int _24482 = NOVALUE;
    int _24481 = NOVALUE;
    int _24480 = NOVALUE;
    int _24478 = NOVALUE;
    int _24476 = NOVALUE;
    int _24475 = NOVALUE;
    int _24474 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer search_count*/

    /** 	tp = literal_init*/
    _tp_46442 = _52literal_init_46138;

    /** 	prev = 0*/
    _prev_46443 = 0;

    /** 	search_count = 0*/
    _search_count_46444 = 0;

    /** 	while tp != 0 do*/
L1: 
    if (_tp_46442 == 0)
    goto L2; // [31] 170

    /** 		search_count += 1*/
    _search_count_46444 = _search_count_46444 + 1;

    /** 		if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_46444, _52SEARCH_LIMIT_46431)){
        goto L3; // [45] 54
    }

    /** 			exit*/
    goto L2; // [51] 170
L3: 

    /** 		if equal(s, SymTab[tp][S_OBJ]) then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24474 = (int)*(((s1_ptr)_2)->base + _tp_46442);
    _2 = (int)SEQ_PTR(_24474);
    _24475 = (int)*(((s1_ptr)_2)->base + 1);
    _24474 = NOVALUE;
    if (_s_46439 == _24475)
    _24476 = 1;
    else if (IS_ATOM_INT(_s_46439) && IS_ATOM_INT(_24475))
    _24476 = 0;
    else
    _24476 = (compare(_s_46439, _24475) == 0);
    _24475 = NOVALUE;
    if (_24476 == 0)
    {
        _24476 = NOVALUE;
        goto L4; // [72] 142
    }
    else{
        _24476 = NOVALUE;
    }

    /** 			if tp != literal_init then*/
    if (_tp_46442 == _52literal_init_46138)
    goto L5; // [79] 135

    /** 				SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_prev_46443 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24480 = (int)*(((s1_ptr)_2)->base + _tp_46442);
    _2 = (int)SEQ_PTR(_24480);
    _24481 = (int)*(((s1_ptr)_2)->base + 2);
    _24480 = NOVALUE;
    Ref(_24481);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _24481;
    if( _1 != _24481 ){
        DeRef(_1);
    }
    _24481 = NOVALUE;
    _24478 = NOVALUE;

    /** 				SymTab[tp][S_NEXT] = literal_init*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_tp_46442 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _52literal_init_46138;
    DeRef(_1);
    _24482 = NOVALUE;

    /** 				literal_init = tp*/
    _52literal_init_46138 = _tp_46442;
L5: 

    /** 			return tp*/
    DeRefDS(_s_46439);
    return _tp_46442;
L4: 

    /** 		prev = tp*/
    _prev_46443 = _tp_46442;

    /** 		tp = SymTab[tp][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24484 = (int)*(((s1_ptr)_2)->base + _tp_46442);
    _2 = (int)SEQ_PTR(_24484);
    _tp_46442 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_tp_46442)){
        _tp_46442 = (long)DBL_PTR(_tp_46442)->dbl;
    }
    _24484 = NOVALUE;

    /** 	end while*/
    goto L1; // [167] 31
L2: 

    /** 	p = tmp_alloc()*/
    _p_46441 = _52tmp_alloc();
    if (!IS_ATOM_INT(_p_46441)) {
        _1 = (long)(DBL_PTR(_p_46441)->dbl);
        DeRefDS(_p_46441);
        _p_46441 = _1;
    }

    /** 	SymTab[p][S_OBJ] = s*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46441 + ((s1_ptr)_2)->base);
    RefDS(_s_46439);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _s_46439;
    DeRef(_1);
    _24487 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L6; // [196] 346
    }
    else{
    }

    /** 		SymTab[p][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46441 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _24489 = NOVALUE;

    /** 		SymTab[p][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46441 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);
    _24491 = NOVALUE;

    /** 		SymTab[p][S_SEQ_LEN] = length(s)*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46441 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_s_46439)){
            _24495 = SEQ_PTR(_s_46439)->length;
    }
    else {
        _24495 = 1;
    }
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _24495;
    if( _1 != _24495 ){
        DeRef(_1);
    }
    _24495 = NOVALUE;
    _24493 = NOVALUE;

    /** 		if SymTab[p][S_SEQ_LEN] > 0 then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24496 = (int)*(((s1_ptr)_2)->base + _p_46441);
    _2 = (int)SEQ_PTR(_24496);
    _24497 = (int)*(((s1_ptr)_2)->base + 32);
    _24496 = NOVALUE;
    if (binary_op_a(LESSEQ, _24497, 0)){
        _24497 = NOVALUE;
        goto L7; // [265] 289
    }
    _24497 = NOVALUE;

    /** 			SymTab[p][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46441 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _24499 = NOVALUE;
    goto L8; // [286] 307
L7: 

    /** 			SymTab[p][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46441 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _24501 = NOVALUE;
L8: 

    /** 		c_printf("int _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24504 = (int)*(((s1_ptr)_2)->base + _p_46441);
    _2 = (int)SEQ_PTR(_24504);
    _24505 = (int)*(((s1_ptr)_2)->base + 34);
    _24504 = NOVALUE;
    RefDS(_24503);
    Ref(_24505);
    _53c_printf(_24503, _24505);
    _24505 = NOVALUE;

    /** 		c_hprintf("extern int _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24507 = (int)*(((s1_ptr)_2)->base + _p_46441);
    _2 = (int)SEQ_PTR(_24507);
    _24508 = (int)*(((s1_ptr)_2)->base + 34);
    _24507 = NOVALUE;
    RefDS(_24506);
    Ref(_24508);
    _53c_hprintf(_24506, _24508);
    _24508 = NOVALUE;
    goto L9; // [343] 364
L6: 

    /** 		SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46441 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24509 = NOVALUE;
L9: 

    /** 	SymTab[p][S_NEXT] = literal_init*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46441 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _52literal_init_46138;
    DeRef(_1);
    _24511 = NOVALUE;

    /** 	literal_init = p*/
    _52literal_init_46138 = _p_46441;

    /** 	return p*/
    DeRefDS(_s_46439);
    return _p_46441;
    ;
}


int _52NewIntSym(int _int_val_46537)
{
    int _p_46539 = NOVALUE;
    int _x_46540 = NOVALUE;
    int _24530 = NOVALUE;
    int _24528 = NOVALUE;
    int _24524 = NOVALUE;
    int _24522 = NOVALUE;
    int _24520 = NOVALUE;
    int _24518 = NOVALUE;
    int _24516 = NOVALUE;
    int _24514 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_int_val_46537)) {
        _1 = (long)(DBL_PTR(_int_val_46537)->dbl);
        DeRefDS(_int_val_46537);
        _int_val_46537 = _1;
    }

    /** 	integer x*/

    /** 	x = find(int_val, lastintval)*/
    _x_46540 = find_from(_int_val_46537, _52lastintval_46140, 1);

    /** 	if x then*/
    if (_x_46540 == 0)
    {
        goto L1; // [16] 34
    }
    else{
    }

    /** 		return lastintsym[x]  -- saves space, helps Translator reduce code size*/
    _2 = (int)SEQ_PTR(_52lastintsym_46141);
    _24514 = (int)*(((s1_ptr)_2)->base + _x_46540);
    return _24514;
    goto L2; // [31] 180
L1: 

    /** 		p = tmp_alloc()*/
    _p_46539 = _52tmp_alloc();
    if (!IS_ATOM_INT(_p_46539)) {
        _1 = (long)(DBL_PTR(_p_46539)->dbl);
        DeRefDS(_p_46539);
        _p_46539 = _1;
    }

    /** 		SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46539 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24516 = NOVALUE;

    /** 		SymTab[p][S_OBJ] = int_val*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46539 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _int_val_46537;
    DeRef(_1);
    _24518 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L3; // [77] 128
    }
    else{
    }

    /** 			SymTab[p][S_OBJ_MIN] = int_val*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46539 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _int_val_46537;
    DeRef(_1);
    _24520 = NOVALUE;

    /** 			SymTab[p][S_OBJ_MAX] = int_val*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46539 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _int_val_46537;
    DeRef(_1);
    _24522 = NOVALUE;

    /** 			SymTab[p][S_GTYPE] = TYPE_INTEGER*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46539 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _24524 = NOVALUE;
L3: 

    /** 		lastintval = prepend(lastintval, int_val)*/
    Prepend(&_52lastintval_46140, _52lastintval_46140, _int_val_46537);

    /** 		lastintsym = prepend(lastintsym, p)*/
    Prepend(&_52lastintsym_46141, _52lastintsym_46141, _p_46539);

    /** 		if length(lastintval) > SEARCH_LIMIT then*/
    if (IS_SEQUENCE(_52lastintval_46140)){
            _24528 = SEQ_PTR(_52lastintval_46140)->length;
    }
    else {
        _24528 = 1;
    }
    if (binary_op_a(LESSEQ, _24528, _52SEARCH_LIMIT_46431)){
        _24528 = NOVALUE;
        goto L4; // [153] 173
    }
    _24528 = NOVALUE;

    /** 			lastintval = lastintval[1..floor(SEARCH_LIMIT/2)]*/
    if (IS_ATOM_INT(_52SEARCH_LIMIT_46431)) {
        _24530 = _52SEARCH_LIMIT_46431 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _52SEARCH_LIMIT_46431, 2);
        _24530 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    rhs_slice_target = (object_ptr)&_52lastintval_46140;
    RHS_Slice(_52lastintval_46140, 1, _24530);
L4: 

    /** 		return p*/
    _24514 = NOVALUE;
    DeRef(_24530);
    _24530 = NOVALUE;
    return _p_46539;
L2: 
    ;
}


int _52NewDoubleSym(int _d_46579)
{
    int _p_46581 = NOVALUE;
    int _tp_46582 = NOVALUE;
    int _prev_46583 = NOVALUE;
    int _search_count_46584 = NOVALUE;
    int _24560 = NOVALUE;
    int _24559 = NOVALUE;
    int _24558 = NOVALUE;
    int _24557 = NOVALUE;
    int _24556 = NOVALUE;
    int _24554 = NOVALUE;
    int _24552 = NOVALUE;
    int _24550 = NOVALUE;
    int _24548 = NOVALUE;
    int _24545 = NOVALUE;
    int _24543 = NOVALUE;
    int _24542 = NOVALUE;
    int _24541 = NOVALUE;
    int _24539 = NOVALUE;
    int _24537 = NOVALUE;
    int _24536 = NOVALUE;
    int _24535 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer search_count*/

    /** 	tp = literal_init*/
    _tp_46582 = _52literal_init_46138;

    /** 	prev = 0*/
    _prev_46583 = 0;

    /** 	search_count = 0*/
    _search_count_46584 = 0;

    /** 	while tp != 0 do*/
L1: 
    if (_tp_46582 == 0)
    goto L2; // [29] 168

    /** 		search_count += 1*/
    _search_count_46584 = _search_count_46584 + 1;

    /** 		if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_46584, _52SEARCH_LIMIT_46431)){
        goto L3; // [43] 52
    }

    /** 			exit*/
    goto L2; // [49] 168
L3: 

    /** 		if equal(d, SymTab[tp][S_OBJ]) then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24535 = (int)*(((s1_ptr)_2)->base + _tp_46582);
    _2 = (int)SEQ_PTR(_24535);
    _24536 = (int)*(((s1_ptr)_2)->base + 1);
    _24535 = NOVALUE;
    if (_d_46579 == _24536)
    _24537 = 1;
    else if (IS_ATOM_INT(_d_46579) && IS_ATOM_INT(_24536))
    _24537 = 0;
    else
    _24537 = (compare(_d_46579, _24536) == 0);
    _24536 = NOVALUE;
    if (_24537 == 0)
    {
        _24537 = NOVALUE;
        goto L4; // [70] 140
    }
    else{
        _24537 = NOVALUE;
    }

    /** 			if tp != literal_init then*/
    if (_tp_46582 == _52literal_init_46138)
    goto L5; // [77] 133

    /** 				SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_prev_46583 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24541 = (int)*(((s1_ptr)_2)->base + _tp_46582);
    _2 = (int)SEQ_PTR(_24541);
    _24542 = (int)*(((s1_ptr)_2)->base + 2);
    _24541 = NOVALUE;
    Ref(_24542);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _24542;
    if( _1 != _24542 ){
        DeRef(_1);
    }
    _24542 = NOVALUE;
    _24539 = NOVALUE;

    /** 				SymTab[tp][S_NEXT] = literal_init*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_tp_46582 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _52literal_init_46138;
    DeRef(_1);
    _24543 = NOVALUE;

    /** 				literal_init = tp*/
    _52literal_init_46138 = _tp_46582;
L5: 

    /** 			return tp*/
    DeRef(_d_46579);
    return _tp_46582;
L4: 

    /** 		prev = tp*/
    _prev_46583 = _tp_46582;

    /** 		tp = SymTab[tp][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24545 = (int)*(((s1_ptr)_2)->base + _tp_46582);
    _2 = (int)SEQ_PTR(_24545);
    _tp_46582 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_tp_46582)){
        _tp_46582 = (long)DBL_PTR(_tp_46582)->dbl;
    }
    _24545 = NOVALUE;

    /** 	end while*/
    goto L1; // [165] 29
L2: 

    /** 	p = tmp_alloc()*/
    _p_46581 = _52tmp_alloc();
    if (!IS_ATOM_INT(_p_46581)) {
        _1 = (long)(DBL_PTR(_p_46581)->dbl);
        DeRefDS(_p_46581);
        _p_46581 = _1;
    }

    /** 	SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46581 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24548 = NOVALUE;

    /** 	SymTab[p][S_OBJ] = d*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46581 + ((s1_ptr)_2)->base);
    Ref(_d_46579);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _d_46579;
    DeRef(_1);
    _24550 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L6; // [211] 285
    }
    else{
    }

    /** 		SymTab[p][S_MODE] = M_TEMP  -- override CONSTANT for compile*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46581 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _24552 = NOVALUE;

    /** 		SymTab[p][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46581 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24554 = NOVALUE;

    /** 		c_printf("int _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24556 = (int)*(((s1_ptr)_2)->base + _p_46581);
    _2 = (int)SEQ_PTR(_24556);
    _24557 = (int)*(((s1_ptr)_2)->base + 34);
    _24556 = NOVALUE;
    RefDS(_24503);
    Ref(_24557);
    _53c_printf(_24503, _24557);
    _24557 = NOVALUE;

    /** 		c_hprintf("extern int _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24558 = (int)*(((s1_ptr)_2)->base + _p_46581);
    _2 = (int)SEQ_PTR(_24558);
    _24559 = (int)*(((s1_ptr)_2)->base + 34);
    _24558 = NOVALUE;
    RefDS(_24506);
    Ref(_24559);
    _53c_hprintf(_24506, _24559);
    _24559 = NOVALUE;
L6: 

    /** 	SymTab[p][S_NEXT] = literal_init*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46581 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _52literal_init_46138;
    DeRef(_1);
    _24560 = NOVALUE;

    /** 	literal_init = p*/
    _52literal_init_46138 = _p_46581;

    /** 	return p*/
    DeRef(_d_46579);
    return _p_46581;
    ;
}


int _52NewTempSym(int _inlining_46653)
{
    int _p_46655 = NOVALUE;
    int _q_46656 = NOVALUE;
    int _24609 = NOVALUE;
    int _24607 = NOVALUE;
    int _24605 = NOVALUE;
    int _24603 = NOVALUE;
    int _24601 = NOVALUE;
    int _24599 = NOVALUE;
    int _24598 = NOVALUE;
    int _24597 = NOVALUE;
    int _24595 = NOVALUE;
    int _24594 = NOVALUE;
    int _24593 = NOVALUE;
    int _24591 = NOVALUE;
    int _24589 = NOVALUE;
    int _24586 = NOVALUE;
    int _24585 = NOVALUE;
    int _24584 = NOVALUE;
    int _24582 = NOVALUE;
    int _24580 = NOVALUE;
    int _24579 = NOVALUE;
    int _24578 = NOVALUE;
    int _24576 = NOVALUE;
    int _24574 = NOVALUE;
    int _24569 = NOVALUE;
    int _24568 = NOVALUE;
    int _24567 = NOVALUE;
    int _24566 = NOVALUE;
    int _24565 = NOVALUE;
    int _24564 = NOVALUE;
    int _24562 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_inlining_46653)) {
        _1 = (long)(DBL_PTR(_inlining_46653)->dbl);
        DeRefDS(_inlining_46653);
        _inlining_46653 = _1;
    }

    /** 	if inlining then*/
    if (_inlining_46653 == 0)
    {
        goto L1; // [5] 85
    }
    else{
    }

    /** 		p = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24562 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_24562);
    if (!IS_ATOM_INT(_26S_TEMPS_11699)){
        _p_46655 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TEMPS_11699)->dbl));
    }
    else{
        _p_46655 = (int)*(((s1_ptr)_2)->base + _26S_TEMPS_11699);
    }
    if (!IS_ATOM_INT(_p_46655)){
        _p_46655 = (long)DBL_PTR(_p_46655)->dbl;
    }
    _24562 = NOVALUE;

    /** 		while p != 0 and SymTab[p][S_SCOPE] != FREE do*/
L2: 
    _24564 = (_p_46655 != 0);
    if (_24564 == 0) {
        goto L3; // [35] 93
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24566 = (int)*(((s1_ptr)_2)->base + _p_46655);
    _2 = (int)SEQ_PTR(_24566);
    _24567 = (int)*(((s1_ptr)_2)->base + 4);
    _24566 = NOVALUE;
    if (IS_ATOM_INT(_24567)) {
        _24568 = (_24567 != 0);
    }
    else {
        _24568 = binary_op(NOTEQ, _24567, 0);
    }
    _24567 = NOVALUE;
    if (_24568 <= 0) {
        if (_24568 == 0) {
            DeRef(_24568);
            _24568 = NOVALUE;
            goto L3; // [58] 93
        }
        else {
            if (!IS_ATOM_INT(_24568) && DBL_PTR(_24568)->dbl == 0.0){
                DeRef(_24568);
                _24568 = NOVALUE;
                goto L3; // [58] 93
            }
            DeRef(_24568);
            _24568 = NOVALUE;
        }
    }
    DeRef(_24568);
    _24568 = NOVALUE;

    /** 			p = SymTab[p][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24569 = (int)*(((s1_ptr)_2)->base + _p_46655);
    _2 = (int)SEQ_PTR(_24569);
    _p_46655 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_46655)){
        _p_46655 = (long)DBL_PTR(_p_46655)->dbl;
    }
    _24569 = NOVALUE;

    /** 		end while*/
    goto L2; // [79] 31
    goto L3; // [82] 93
L1: 

    /** 		p = 0*/
    _p_46655 = 0;
L3: 

    /** 	if p = 0 then*/
    if (_p_46655 != 0)
    goto L4; // [97] 213

    /** 		temps_allocated += 1*/
    _52temps_allocated_46650 = _52temps_allocated_46650 + 1;

    /** 		p = tmp_alloc()*/
    _p_46655 = _52tmp_alloc();
    if (!IS_ATOM_INT(_p_46655)) {
        _1 = (long)(DBL_PTR(_p_46655)->dbl);
        DeRefDS(_p_46655);
        _p_46655 = _1;
    }

    /** 		SymTab[p][S_MODE] = M_TEMP*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46655 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _24574 = NOVALUE;

    /** 		SymTab[p][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46655 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24578 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_24578);
    if (!IS_ATOM_INT(_26S_TEMPS_11699)){
        _24579 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TEMPS_11699)->dbl));
    }
    else{
        _24579 = (int)*(((s1_ptr)_2)->base + _26S_TEMPS_11699);
    }
    _24578 = NOVALUE;
    Ref(_24579);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _24579;
    if( _1 != _24579 ){
        DeRef(_1);
    }
    _24579 = NOVALUE;
    _24576 = NOVALUE;

    /** 		SymTab[CurrentSub][S_TEMPS] = p*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26CurrentSub_11990 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_TEMPS_11699))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TEMPS_11699)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_TEMPS_11699);
    _1 = *(int *)_2;
    *(int *)_2 = _p_46655;
    DeRef(_1);
    _24580 = NOVALUE;

    /** 		if inlining then*/
    if (_inlining_46653 == 0)
    {
        goto L5; // [181] 343
    }
    else{
    }

    /** 			SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26CurrentSub_11990 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_26S_STACK_SPACE_11714)){
        _24584 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_STACK_SPACE_11714)->dbl));
    }
    else{
        _24584 = (int)*(((s1_ptr)_2)->base + _26S_STACK_SPACE_11714);
    }
    _24582 = NOVALUE;
    if (IS_ATOM_INT(_24584)) {
        _24585 = _24584 + 1;
        if (_24585 > MAXINT){
            _24585 = NewDouble((double)_24585);
        }
    }
    else
    _24585 = binary_op(PLUS, 1, _24584);
    _24584 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_STACK_SPACE_11714))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_STACK_SPACE_11714)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_STACK_SPACE_11714);
    _1 = *(int *)_2;
    *(int *)_2 = _24585;
    if( _1 != _24585 ){
        DeRef(_1);
    }
    _24585 = NOVALUE;
    _24582 = NOVALUE;
    goto L5; // [210] 343
L4: 

    /** 	elsif TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L6; // [217] 342
    }
    else{
    }

    /** 		SymTab[p][S_SCOPE] = DELETED*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46655 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24586 = NOVALUE;

    /** 		q = tmp_alloc()*/
    _q_46656 = _52tmp_alloc();
    if (!IS_ATOM_INT(_q_46656)) {
        _1 = (long)(DBL_PTR(_q_46656)->dbl);
        DeRefDS(_q_46656);
        _q_46656 = _1;
    }

    /** 		SymTab[q][S_MODE] = M_TEMP*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_q_46656 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _24589 = NOVALUE;

    /** 		SymTab[q][S_TEMP_NAME] = SymTab[p][S_TEMP_NAME]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_q_46656 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24593 = (int)*(((s1_ptr)_2)->base + _p_46655);
    _2 = (int)SEQ_PTR(_24593);
    _24594 = (int)*(((s1_ptr)_2)->base + 34);
    _24593 = NOVALUE;
    Ref(_24594);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 34);
    _1 = *(int *)_2;
    *(int *)_2 = _24594;
    if( _1 != _24594 ){
        DeRef(_1);
    }
    _24594 = NOVALUE;
    _24591 = NOVALUE;

    /** 		SymTab[q][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_q_46656 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24597 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_24597);
    if (!IS_ATOM_INT(_26S_TEMPS_11699)){
        _24598 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TEMPS_11699)->dbl));
    }
    else{
        _24598 = (int)*(((s1_ptr)_2)->base + _26S_TEMPS_11699);
    }
    _24597 = NOVALUE;
    Ref(_24598);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _24598;
    if( _1 != _24598 ){
        DeRef(_1);
    }
    _24598 = NOVALUE;
    _24595 = NOVALUE;

    /** 		SymTab[CurrentSub][S_TEMPS] = q*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26CurrentSub_11990 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_TEMPS_11699))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TEMPS_11699)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_TEMPS_11699);
    _1 = *(int *)_2;
    *(int *)_2 = _q_46656;
    DeRef(_1);
    _24599 = NOVALUE;

    /** 		p = q*/
    _p_46655 = _q_46656;
L6: 
L5: 

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L7; // [347] 385
    }
    else{
    }

    /** 		SymTab[p][S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46655 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _24601 = NOVALUE;

    /** 		SymTab[p][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46655 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _24603 = NOVALUE;
L7: 

    /** 	SymTab[p][S_OBJ] = NOVALUE*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46655 + ((s1_ptr)_2)->base);
    Ref(_26NOVALUE_11836);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _26NOVALUE_11836;
    DeRef(_1);
    _24605 = NOVALUE;

    /** 	SymTab[p][S_USAGE] = T_UNKNOWN*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46655 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);
    _24607 = NOVALUE;

    /** 	SymTab[p][S_SCOPE] = IN_USE*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46655 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _24609 = NOVALUE;

    /** 	return p*/
    DeRef(_24564);
    _24564 = NOVALUE;
    return _p_46655;
    ;
}


void _52InitSymTab()
{
    int _hashval_46772 = NOVALUE;
    int _len_46773 = NOVALUE;
    int _s_46775 = NOVALUE;
    int _st_index_46776 = NOVALUE;
    int _kname_46777 = NOVALUE;
    int _fixups_46778 = NOVALUE;
    int _si_46918 = NOVALUE;
    int _sj_46919 = NOVALUE;
    int _25193 = NOVALUE;
    int _25192 = NOVALUE;
    int _24725 = NOVALUE;
    int _24724 = NOVALUE;
    int _24723 = NOVALUE;
    int _24722 = NOVALUE;
    int _24721 = NOVALUE;
    int _24719 = NOVALUE;
    int _24718 = NOVALUE;
    int _24717 = NOVALUE;
    int _24716 = NOVALUE;
    int _24714 = NOVALUE;
    int _24712 = NOVALUE;
    int _24710 = NOVALUE;
    int _24709 = NOVALUE;
    int _24707 = NOVALUE;
    int _24705 = NOVALUE;
    int _24703 = NOVALUE;
    int _24702 = NOVALUE;
    int _24700 = NOVALUE;
    int _24699 = NOVALUE;
    int _24698 = NOVALUE;
    int _24697 = NOVALUE;
    int _24696 = NOVALUE;
    int _24693 = NOVALUE;
    int _24692 = NOVALUE;
    int _24691 = NOVALUE;
    int _24689 = NOVALUE;
    int _24688 = NOVALUE;
    int _24687 = NOVALUE;
    int _24685 = NOVALUE;
    int _24684 = NOVALUE;
    int _24683 = NOVALUE;
    int _24680 = NOVALUE;
    int _24678 = NOVALUE;
    int _24676 = NOVALUE;
    int _24675 = NOVALUE;
    int _24672 = NOVALUE;
    int _24671 = NOVALUE;
    int _24669 = NOVALUE;
    int _24667 = NOVALUE;
    int _24665 = NOVALUE;
    int _24662 = NOVALUE;
    int _24661 = NOVALUE;
    int _24660 = NOVALUE;
    int _24657 = NOVALUE;
    int _24656 = NOVALUE;
    int _24654 = NOVALUE;
    int _24653 = NOVALUE;
    int _24651 = NOVALUE;
    int _24650 = NOVALUE;
    int _24649 = NOVALUE;
    int _24647 = NOVALUE;
    int _24645 = NOVALUE;
    int _24644 = NOVALUE;
    int _24642 = NOVALUE;
    int _24641 = NOVALUE;
    int _24640 = NOVALUE;
    int _24638 = NOVALUE;
    int _24637 = NOVALUE;
    int _24636 = NOVALUE;
    int _24634 = NOVALUE;
    int _24633 = NOVALUE;
    int _24632 = NOVALUE;
    int _24630 = NOVALUE;
    int _24629 = NOVALUE;
    int _24628 = NOVALUE;
    int _24627 = NOVALUE;
    int _24626 = NOVALUE;
    int _24625 = NOVALUE;
    int _24624 = NOVALUE;
    int _24623 = NOVALUE;
    int _24622 = NOVALUE;
    int _24621 = NOVALUE;
    int _24619 = NOVALUE;
    int _24618 = NOVALUE;
    int _24617 = NOVALUE;
    int _24616 = NOVALUE;
    int _24612 = NOVALUE;
    int _24611 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence kname, fixups = {}*/
    RefDS(_22037);
    DeRefi(_fixups_46778);
    _fixups_46778 = _22037;

    /** 	for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_62keylist_22870)){
            _24611 = SEQ_PTR(_62keylist_22870)->length;
    }
    else {
        _24611 = 1;
    }
    {
        int _k_46780;
        _k_46780 = 1;
L1: 
        if (_k_46780 > _24611){
            goto L2; // [15] 560
        }

        /** 		kname = keylist[k][K_NAME]*/
        _2 = (int)SEQ_PTR(_62keylist_22870);
        _24612 = (int)*(((s1_ptr)_2)->base + _k_46780);
        DeRef(_kname_46777);
        _2 = (int)SEQ_PTR(_24612);
        _kname_46777 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_kname_46777);
        _24612 = NOVALUE;

        /** 		len = length(kname)*/
        if (IS_SEQUENCE(_kname_46777)){
                _len_46773 = SEQ_PTR(_kname_46777)->length;
        }
        else {
            _len_46773 = 1;
        }

        /** 		hashval = hashfn(kname)*/
        RefDS(_kname_46777);
        _hashval_46772 = _52hashfn(_kname_46777);
        if (!IS_ATOM_INT(_hashval_46772)) {
            _1 = (long)(DBL_PTR(_hashval_46772)->dbl);
            DeRefDS(_hashval_46772);
            _hashval_46772 = _1;
        }

        /** 		st_index = NewEntry(kname,*/
        _2 = (int)SEQ_PTR(_62keylist_22870);
        _24616 = (int)*(((s1_ptr)_2)->base + _k_46780);
        _2 = (int)SEQ_PTR(_24616);
        _24617 = (int)*(((s1_ptr)_2)->base + 2);
        _24616 = NOVALUE;
        _2 = (int)SEQ_PTR(_62keylist_22870);
        _24618 = (int)*(((s1_ptr)_2)->base + _k_46780);
        _2 = (int)SEQ_PTR(_24618);
        _24619 = (int)*(((s1_ptr)_2)->base + 3);
        _24618 = NOVALUE;
        RefDS(_kname_46777);
        Ref(_24617);
        Ref(_24619);
        _st_index_46776 = _52NewEntry(_kname_46777, 0, _24617, _24619, _hashval_46772, 0, 0);
        _24617 = NOVALUE;
        _24619 = NOVALUE;
        if (!IS_ATOM_INT(_st_index_46776)) {
            _1 = (long)(DBL_PTR(_st_index_46776)->dbl);
            DeRefDS(_st_index_46776);
            _st_index_46776 = _1;
        }

        /** 		if find(keylist[k][K_TOKEN], RTN_TOKS) then*/
        _2 = (int)SEQ_PTR(_62keylist_22870);
        _24621 = (int)*(((s1_ptr)_2)->base + _k_46780);
        _2 = (int)SEQ_PTR(_24621);
        _24622 = (int)*(((s1_ptr)_2)->base + 3);
        _24621 = NOVALUE;
        _24623 = find_from(_24622, _28RTN_TOKS_11602, 1);
        _24622 = NOVALUE;
        if (_24623 == 0)
        {
            _24623 = NOVALUE;
            goto L3; // [110] 325
        }
        else{
            _24623 = NOVALUE;
        }

        /** 			SymTab[st_index] = SymTab[st_index] &*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _24624 = (int)*(((s1_ptr)_2)->base + _st_index_46776);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _24625 = (int)*(((s1_ptr)_2)->base + _st_index_46776);
        if (IS_SEQUENCE(_24625)){
                _24626 = SEQ_PTR(_24625)->length;
        }
        else {
            _24626 = 1;
        }
        _24625 = NOVALUE;
        _24627 = _26SIZEOF_ROUTINE_ENTRY_11779 - _24626;
        _24626 = NOVALUE;
        _24628 = Repeat(0, _24627);
        _24627 = NOVALUE;
        if (IS_SEQUENCE(_24624) && IS_ATOM(_24628)) {
        }
        else if (IS_ATOM(_24624) && IS_SEQUENCE(_24628)) {
            Ref(_24624);
            Prepend(&_24629, _24628, _24624);
        }
        else {
            Concat((object_ptr)&_24629, _24624, _24628);
            _24624 = NOVALUE;
        }
        _24624 = NOVALUE;
        DeRefDS(_24628);
        _24628 = NOVALUE;
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _st_index_46776);
        _1 = *(int *)_2;
        *(int *)_2 = _24629;
        if( _1 != _24629 ){
            DeRef(_1);
        }
        _24629 = NOVALUE;

        /** 			SymTab[st_index][S_NUM_ARGS] = keylist[k][K_NUM_ARGS]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46776 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_62keylist_22870);
        _24632 = (int)*(((s1_ptr)_2)->base + _k_46780);
        _2 = (int)SEQ_PTR(_24632);
        _24633 = (int)*(((s1_ptr)_2)->base + 5);
        _24632 = NOVALUE;
        Ref(_24633);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_26S_NUM_ARGS_11705))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
        _1 = *(int *)_2;
        *(int *)_2 = _24633;
        if( _1 != _24633 ){
            DeRef(_1);
        }
        _24633 = NOVALUE;
        _24630 = NOVALUE;

        /** 			SymTab[st_index][S_OPCODE] = keylist[k][K_OPCODE]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46776 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_62keylist_22870);
        _24636 = (int)*(((s1_ptr)_2)->base + _k_46780);
        _2 = (int)SEQ_PTR(_24636);
        _24637 = (int)*(((s1_ptr)_2)->base + 4);
        _24636 = NOVALUE;
        Ref(_24637);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 21);
        _1 = *(int *)_2;
        *(int *)_2 = _24637;
        if( _1 != _24637 ){
            DeRef(_1);
        }
        _24637 = NOVALUE;
        _24634 = NOVALUE;

        /** 			SymTab[st_index][S_EFFECT] = keylist[k][K_EFFECT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46776 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_62keylist_22870);
        _24640 = (int)*(((s1_ptr)_2)->base + _k_46780);
        _2 = (int)SEQ_PTR(_24640);
        _24641 = (int)*(((s1_ptr)_2)->base + 6);
        _24640 = NOVALUE;
        Ref(_24641);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 23);
        _1 = *(int *)_2;
        *(int *)_2 = _24641;
        if( _1 != _24641 ){
            DeRef(_1);
        }
        _24641 = NOVALUE;
        _24638 = NOVALUE;

        /** 			SymTab[st_index][S_REFLIST] = {}*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46776 + ((s1_ptr)_2)->base);
        RefDS(_22037);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 24);
        _1 = *(int *)_2;
        *(int *)_2 = _22037;
        DeRef(_1);
        _24642 = NOVALUE;

        /** 			if length(keylist[k]) > K_EFFECT then*/
        _2 = (int)SEQ_PTR(_62keylist_22870);
        _24644 = (int)*(((s1_ptr)_2)->base + _k_46780);
        if (IS_SEQUENCE(_24644)){
                _24645 = SEQ_PTR(_24644)->length;
        }
        else {
            _24645 = 1;
        }
        _24644 = NOVALUE;
        if (_24645 <= 6)
        goto L4; // [259] 324

        /** 			    SymTab[st_index][S_CODE] = keylist[k][K_CODE]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46776 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_62keylist_22870);
        _24649 = (int)*(((s1_ptr)_2)->base + _k_46780);
        _2 = (int)SEQ_PTR(_24649);
        _24650 = (int)*(((s1_ptr)_2)->base + 7);
        _24649 = NOVALUE;
        Ref(_24650);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_26S_CODE_11666))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _26S_CODE_11666);
        _1 = *(int *)_2;
        *(int *)_2 = _24650;
        if( _1 != _24650 ){
            DeRef(_1);
        }
        _24650 = NOVALUE;
        _24647 = NOVALUE;

        /** 			    SymTab[st_index][S_DEF_ARGS] = keylist[k][K_DEF_ARGS]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46776 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_62keylist_22870);
        _24653 = (int)*(((s1_ptr)_2)->base + _k_46780);
        _2 = (int)SEQ_PTR(_24653);
        _24654 = (int)*(((s1_ptr)_2)->base + 8);
        _24653 = NOVALUE;
        Ref(_24654);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 28);
        _1 = *(int *)_2;
        *(int *)_2 = _24654;
        if( _1 != _24654 ){
            DeRef(_1);
        }
        _24654 = NOVALUE;
        _24651 = NOVALUE;

        /** 			    fixups &= st_index*/
        Append(&_fixups_46778, _fixups_46778, _st_index_46776);
L4: 
L3: 

        /** 		if keylist[k][K_TOKEN] = PROC then*/
        _2 = (int)SEQ_PTR(_62keylist_22870);
        _24656 = (int)*(((s1_ptr)_2)->base + _k_46780);
        _2 = (int)SEQ_PTR(_24656);
        _24657 = (int)*(((s1_ptr)_2)->base + 3);
        _24656 = NOVALUE;
        if (binary_op_a(NOTEQ, _24657, 27)){
            _24657 = NOVALUE;
            goto L5; // [341] 365
        }
        _24657 = NOVALUE;

        /** 			if equal(kname, "<TopLevel>") then*/
        if (_kname_46777 == _24659)
        _24660 = 1;
        else if (IS_ATOM_INT(_kname_46777) && IS_ATOM_INT(_24659))
        _24660 = 0;
        else
        _24660 = (compare(_kname_46777, _24659) == 0);
        if (_24660 == 0)
        {
            _24660 = NOVALUE;
            goto L6; // [351] 462
        }
        else{
            _24660 = NOVALUE;
        }

        /** 				TopLevelSub = st_index*/
        _26TopLevelSub_11989 = _st_index_46776;
        goto L6; // [362] 462
L5: 

        /** 		elsif keylist[k][K_TOKEN] = TYPE then*/
        _2 = (int)SEQ_PTR(_62keylist_22870);
        _24661 = (int)*(((s1_ptr)_2)->base + _k_46780);
        _2 = (int)SEQ_PTR(_24661);
        _24662 = (int)*(((s1_ptr)_2)->base + 3);
        _24661 = NOVALUE;
        if (binary_op_a(NOTEQ, _24662, 504)){
            _24662 = NOVALUE;
            goto L7; // [381] 461
        }
        _24662 = NOVALUE;

        /** 			if equal(kname, "object") then*/
        if (_kname_46777 == _24664)
        _24665 = 1;
        else if (IS_ATOM_INT(_kname_46777) && IS_ATOM_INT(_24664))
        _24665 = 0;
        else
        _24665 = (compare(_kname_46777, _24664) == 0);
        if (_24665 == 0)
        {
            _24665 = NOVALUE;
            goto L8; // [391] 404
        }
        else{
            _24665 = NOVALUE;
        }

        /** 				object_type = st_index*/
        _52object_type_46130 = _st_index_46776;
        goto L9; // [401] 460
L8: 

        /** 			elsif equal(kname, "atom") then*/
        if (_kname_46777 == _24666)
        _24667 = 1;
        else if (IS_ATOM_INT(_kname_46777) && IS_ATOM_INT(_24666))
        _24667 = 0;
        else
        _24667 = (compare(_kname_46777, _24666) == 0);
        if (_24667 == 0)
        {
            _24667 = NOVALUE;
            goto LA; // [410] 423
        }
        else{
            _24667 = NOVALUE;
        }

        /** 				atom_type = st_index*/
        _52atom_type_46132 = _st_index_46776;
        goto L9; // [420] 460
LA: 

        /** 			elsif equal(kname, "integer") then*/
        if (_kname_46777 == _24668)
        _24669 = 1;
        else if (IS_ATOM_INT(_kname_46777) && IS_ATOM_INT(_24668))
        _24669 = 0;
        else
        _24669 = (compare(_kname_46777, _24668) == 0);
        if (_24669 == 0)
        {
            _24669 = NOVALUE;
            goto LB; // [429] 442
        }
        else{
            _24669 = NOVALUE;
        }

        /** 				integer_type = st_index*/
        _52integer_type_46136 = _st_index_46776;
        goto L9; // [439] 460
LB: 

        /** 			elsif equal(kname, "sequence") then*/
        if (_kname_46777 == _24670)
        _24671 = 1;
        else if (IS_ATOM_INT(_kname_46777) && IS_ATOM_INT(_24670))
        _24671 = 0;
        else
        _24671 = (compare(_kname_46777, _24670) == 0);
        if (_24671 == 0)
        {
            _24671 = NOVALUE;
            goto LC; // [448] 459
        }
        else{
            _24671 = NOVALUE;
        }

        /** 				sequence_type = st_index*/
        _52sequence_type_46134 = _st_index_46776;
LC: 
L9: 
L7: 
L6: 

        /** 		if buckets[hashval] = 0 then*/
        _2 = (int)SEQ_PTR(_52buckets_46126);
        _24672 = (int)*(((s1_ptr)_2)->base + _hashval_46772);
        if (binary_op_a(NOTEQ, _24672, 0)){
            _24672 = NOVALUE;
            goto LD; // [470] 485
        }
        _24672 = NOVALUE;

        /** 			buckets[hashval] = st_index*/
        _2 = (int)SEQ_PTR(_52buckets_46126);
        _2 = (int)(((s1_ptr)_2)->base + _hashval_46772);
        _1 = *(int *)_2;
        *(int *)_2 = _st_index_46776;
        DeRef(_1);
        goto LE; // [482] 553
LD: 

        /** 			s = buckets[hashval]*/
        _2 = (int)SEQ_PTR(_52buckets_46126);
        _s_46775 = (int)*(((s1_ptr)_2)->base + _hashval_46772);
        if (!IS_ATOM_INT(_s_46775)){
            _s_46775 = (long)DBL_PTR(_s_46775)->dbl;
        }

        /** 			while SymTab[s][S_SAMEHASH] != 0 do*/
LF: 
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _24675 = (int)*(((s1_ptr)_2)->base + _s_46775);
        _2 = (int)SEQ_PTR(_24675);
        _24676 = (int)*(((s1_ptr)_2)->base + 9);
        _24675 = NOVALUE;
        if (binary_op_a(EQUALS, _24676, 0)){
            _24676 = NOVALUE;
            goto L10; // [512] 537
        }
        _24676 = NOVALUE;

        /** 				s = SymTab[s][S_SAMEHASH]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _24678 = (int)*(((s1_ptr)_2)->base + _s_46775);
        _2 = (int)SEQ_PTR(_24678);
        _s_46775 = (int)*(((s1_ptr)_2)->base + 9);
        if (!IS_ATOM_INT(_s_46775)){
            _s_46775 = (long)DBL_PTR(_s_46775)->dbl;
        }
        _24678 = NOVALUE;

        /** 			end while*/
        goto LF; // [534] 500
L10: 

        /** 			SymTab[s][S_SAMEHASH] = st_index*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_s_46775 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 9);
        _1 = *(int *)_2;
        *(int *)_2 = _st_index_46776;
        DeRef(_1);
        _24680 = NOVALUE;
LE: 

        /** 	end for*/
        _k_46780 = _k_46780 + 1;
        goto L1; // [555] 22
L2: 
        ;
    }

    /** 	file_start_sym = length(SymTab)*/
    if (IS_SEQUENCE(_27SymTab_10921)){
            _26file_start_sym_11988 = SEQ_PTR(_27SymTab_10921)->length;
    }
    else {
        _26file_start_sym_11988 = 1;
    }

    /** 	sequence si, sj*/

    /** 	CurrentSub = TopLevelSub*/
    _26CurrentSub_11990 = _26TopLevelSub_11989;

    /** 	for i=1 to length(fixups) do*/
    if (IS_SEQUENCE(_fixups_46778)){
            _24683 = SEQ_PTR(_fixups_46778)->length;
    }
    else {
        _24683 = 1;
    }
    {
        int _i_46923;
        _i_46923 = 1;
L11: 
        if (_i_46923 > _24683){
            goto L12; // [585] 945
        }

        /** 	    si = SymTab[fixups[i]][S_CODE] -- seq of either 0's or sequences of tokens*/
        _2 = (int)SEQ_PTR(_fixups_46778);
        _24684 = (int)*(((s1_ptr)_2)->base + _i_46923);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _24685 = (int)*(((s1_ptr)_2)->base + _24684);
        DeRef(_si_46918);
        _2 = (int)SEQ_PTR(_24685);
        if (!IS_ATOM_INT(_26S_CODE_11666)){
            _si_46918 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
        }
        else{
            _si_46918 = (int)*(((s1_ptr)_2)->base + _26S_CODE_11666);
        }
        Ref(_si_46918);
        _24685 = NOVALUE;

        /** 	    for j=1 to length(si) do*/
        if (IS_SEQUENCE(_si_46918)){
                _24687 = SEQ_PTR(_si_46918)->length;
        }
        else {
            _24687 = 1;
        }
        {
            int _j_46931;
            _j_46931 = 1;
L13: 
            if (_j_46931 > _24687){
                goto L14; // [617] 919
            }

            /** 	        if sequence(si[j]) then*/
            _2 = (int)SEQ_PTR(_si_46918);
            _24688 = (int)*(((s1_ptr)_2)->base + _j_46931);
            _24689 = IS_SEQUENCE(_24688);
            _24688 = NOVALUE;
            if (_24689 == 0)
            {
                _24689 = NOVALUE;
                goto L15; // [633] 912
            }
            else{
                _24689 = NOVALUE;
            }

            /** 	            sj = si[j] -- a sequence of tokens*/
            DeRef(_sj_46919);
            _2 = (int)SEQ_PTR(_si_46918);
            _sj_46919 = (int)*(((s1_ptr)_2)->base + _j_46931);
            Ref(_sj_46919);

            /** 				for ij=1 to length(sj) do*/
            if (IS_SEQUENCE(_sj_46919)){
                    _24691 = SEQ_PTR(_sj_46919)->length;
            }
            else {
                _24691 = 1;
            }
            {
                int _ij_46938;
                _ij_46938 = 1;
L16: 
                if (_ij_46938 > _24691){
                    goto L17; // [649] 905
                }

                /** 	                switch sj[ij][T_ID] with fallthru do*/
                _2 = (int)SEQ_PTR(_sj_46919);
                _24692 = (int)*(((s1_ptr)_2)->base + _ij_46938);
                _2 = (int)SEQ_PTR(_24692);
                _24693 = (int)*(((s1_ptr)_2)->base + 1);
                _24692 = NOVALUE;
                if (IS_SEQUENCE(_24693) ){
                    goto L18; // [668] 898
                }
                if(!IS_ATOM_INT(_24693)){
                    if( (DBL_PTR(_24693)->dbl != (double) ((int) DBL_PTR(_24693)->dbl) ) ){
                        goto L18; // [668] 898
                    }
                    _0 = (int) DBL_PTR(_24693)->dbl;
                }
                else {
                    _0 = _24693;
                };
                _24693 = NOVALUE;
                switch ( _0 ){ 

                    /** 	                    case ATOM then -- must create a lasting temp*/
                    case 502:

                    /** 	                    	if integer(sj[ij][T_SYM]) then*/
                    _2 = (int)SEQ_PTR(_sj_46919);
                    _24696 = (int)*(((s1_ptr)_2)->base + _ij_46938);
                    _2 = (int)SEQ_PTR(_24696);
                    _24697 = (int)*(((s1_ptr)_2)->base + 2);
                    _24696 = NOVALUE;
                    if (IS_ATOM_INT(_24697))
                    _24698 = 1;
                    else if (IS_ATOM_DBL(_24697))
                    _24698 = IS_ATOM_INT(DoubleToInt(_24697));
                    else
                    _24698 = 0;
                    _24697 = NOVALUE;
                    if (_24698 == 0)
                    {
                        _24698 = NOVALUE;
                        goto L19; // [692] 716
                    }
                    else{
                        _24698 = NOVALUE;
                    }

                    /** 								st_index = NewIntSym(sj[ij][T_SYM])*/
                    _2 = (int)SEQ_PTR(_sj_46919);
                    _24699 = (int)*(((s1_ptr)_2)->base + _ij_46938);
                    _2 = (int)SEQ_PTR(_24699);
                    _24700 = (int)*(((s1_ptr)_2)->base + 2);
                    _24699 = NOVALUE;
                    Ref(_24700);
                    _st_index_46776 = _52NewIntSym(_24700);
                    _24700 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_46776)) {
                        _1 = (long)(DBL_PTR(_st_index_46776)->dbl);
                        DeRefDS(_st_index_46776);
                        _st_index_46776 = _1;
                    }
                    goto L1A; // [713] 735
L19: 

                    /** 								st_index = NewDoubleSym(sj[ij][T_SYM])*/
                    _2 = (int)SEQ_PTR(_sj_46919);
                    _24702 = (int)*(((s1_ptr)_2)->base + _ij_46938);
                    _2 = (int)SEQ_PTR(_24702);
                    _24703 = (int)*(((s1_ptr)_2)->base + 2);
                    _24702 = NOVALUE;
                    Ref(_24703);
                    _st_index_46776 = _52NewDoubleSym(_24703);
                    _24703 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_46776)) {
                        _1 = (long)(DBL_PTR(_st_index_46776)->dbl);
                        DeRefDS(_st_index_46776);
                        _st_index_46776 = _1;
                    }
L1A: 

                    /** 							SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (int)SEQ_PTR(_27SymTab_10921);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _27SymTab_10921 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_st_index_46776 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 4);
                    _1 = *(int *)_2;
                    *(int *)_2 = 1;
                    DeRef(_1);
                    _24705 = NOVALUE;

                    /** 							sj[ij][T_SYM] = st_index*/
                    _2 = (int)SEQ_PTR(_sj_46919);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _sj_46919 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_ij_46938 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 2);
                    _1 = *(int *)_2;
                    *(int *)_2 = _st_index_46776;
                    DeRef(_1);
                    _24707 = NOVALUE;

                    /** 							break*/
                    goto L18; // [769] 898

                    /** 						case STRING then -- same*/
                    case 503:

                    /** 	                    	st_index = NewStringSym(sj[ij][T_SYM])*/
                    _2 = (int)SEQ_PTR(_sj_46919);
                    _24709 = (int)*(((s1_ptr)_2)->base + _ij_46938);
                    _2 = (int)SEQ_PTR(_24709);
                    _24710 = (int)*(((s1_ptr)_2)->base + 2);
                    _24709 = NOVALUE;
                    Ref(_24710);
                    _st_index_46776 = _52NewStringSym(_24710);
                    _24710 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_46776)) {
                        _1 = (long)(DBL_PTR(_st_index_46776)->dbl);
                        DeRefDS(_st_index_46776);
                        _st_index_46776 = _1;
                    }

                    /** 							SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (int)SEQ_PTR(_27SymTab_10921);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _27SymTab_10921 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_st_index_46776 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 4);
                    _1 = *(int *)_2;
                    *(int *)_2 = 1;
                    DeRef(_1);
                    _24712 = NOVALUE;

                    /** 							sj[ij][T_SYM] = st_index*/
                    _2 = (int)SEQ_PTR(_sj_46919);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _sj_46919 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_ij_46938 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 2);
                    _1 = *(int *)_2;
                    *(int *)_2 = _st_index_46776;
                    DeRef(_1);
                    _24714 = NOVALUE;

                    /** 							break*/
                    goto L18; // [825] 898

                    /** 						case BUILT_IN then -- name of a builtin in econd field*/
                    case 511:

                    /**                             sj[ij] = keyfind(sj[ij][T_SYM],-1)*/
                    _2 = (int)SEQ_PTR(_sj_46919);
                    _24716 = (int)*(((s1_ptr)_2)->base + _ij_46938);
                    _2 = (int)SEQ_PTR(_24716);
                    _24717 = (int)*(((s1_ptr)_2)->base + 2);
                    _24716 = NOVALUE;
                    Ref(_24717);
                    DeRef(_25192);
                    _25192 = _24717;
                    _25193 = _52hashfn(_25192);
                    _25192 = NOVALUE;
                    Ref(_24717);
                    _24718 = _52keyfind(_24717, -1, _26current_file_no_11982, 0, _25193);
                    _24717 = NOVALUE;
                    _25193 = NOVALUE;
                    _2 = (int)SEQ_PTR(_sj_46919);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _sj_46919 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + _ij_46938);
                    _1 = *(int *)_2;
                    *(int *)_2 = _24718;
                    if( _1 != _24718 ){
                        DeRef(_1);
                    }
                    _24718 = NOVALUE;

                    /** 							break*/
                    goto L18; // [866] 898

                    /** 						case DEF_PARAM then*/
                    case 510:

                    /** 							sj[ij][T_SYM] &= fixups[i]*/
                    _2 = (int)SEQ_PTR(_sj_46919);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _sj_46919 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_ij_46938 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(_fixups_46778);
                    _24721 = (int)*(((s1_ptr)_2)->base + _i_46923);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    _24722 = (int)*(((s1_ptr)_2)->base + 2);
                    _24719 = NOVALUE;
                    if (IS_SEQUENCE(_24722) && IS_ATOM(_24721)) {
                        Append(&_24723, _24722, _24721);
                    }
                    else if (IS_ATOM(_24722) && IS_SEQUENCE(_24721)) {
                    }
                    else {
                        Concat((object_ptr)&_24723, _24722, _24721);
                        _24722 = NOVALUE;
                    }
                    _24722 = NOVALUE;
                    _24721 = NOVALUE;
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 2);
                    _1 = *(int *)_2;
                    *(int *)_2 = _24723;
                    if( _1 != _24723 ){
                        DeRef(_1);
                    }
                    _24723 = NOVALUE;
                    _24719 = NOVALUE;
                ;}L18: 

                /** 				end for*/
                _ij_46938 = _ij_46938 + 1;
                goto L16; // [900] 656
L17: 
                ;
            }

            /** 				si[j] = sj*/
            RefDS(_sj_46919);
            _2 = (int)SEQ_PTR(_si_46918);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _si_46918 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_46931);
            _1 = *(int *)_2;
            *(int *)_2 = _sj_46919;
            DeRef(_1);
L15: 

            /** 		end for*/
            _j_46931 = _j_46931 + 1;
            goto L13; // [914] 624
L14: 
            ;
        }

        /** 		SymTab[fixups[i]][S_CODE] = si*/
        _2 = (int)SEQ_PTR(_fixups_46778);
        _24724 = (int)*(((s1_ptr)_2)->base + _i_46923);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_24724 + ((s1_ptr)_2)->base);
        RefDS(_si_46918);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_26S_CODE_11666))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_CODE_11666)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _26S_CODE_11666);
        _1 = *(int *)_2;
        *(int *)_2 = _si_46918;
        DeRef(_1);
        _24725 = NOVALUE;

        /** 	end for*/
        _i_46923 = _i_46923 + 1;
        goto L11; // [940] 592
L12: 
        ;
    }

    /** end procedure*/
    DeRef(_kname_46777);
    DeRefi(_fixups_46778);
    DeRef(_si_46918);
    DeRef(_sj_46919);
    _24644 = NOVALUE;
    _24625 = NOVALUE;
    _24684 = NOVALUE;
    _24724 = NOVALUE;
    return;
    ;
}


void _52add_ref(int _tok_47006)
{
    int _s_47008 = NOVALUE;
    int _24741 = NOVALUE;
    int _24740 = NOVALUE;
    int _24738 = NOVALUE;
    int _24737 = NOVALUE;
    int _24736 = NOVALUE;
    int _24734 = NOVALUE;
    int _24733 = NOVALUE;
    int _24732 = NOVALUE;
    int _24731 = NOVALUE;
    int _24730 = NOVALUE;
    int _24729 = NOVALUE;
    int _24728 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	s = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_47006);
    _s_47008 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_47008)){
        _s_47008 = (long)DBL_PTR(_s_47008)->dbl;
    }

    /** 	if s != CurrentSub and -- ignore self-ref's*/
    _24728 = (_s_47008 != _26CurrentSub_11990);
    if (_24728 == 0) {
        goto L1; // [19] 98
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24730 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_24730);
    _24731 = (int)*(((s1_ptr)_2)->base + 24);
    _24730 = NOVALUE;
    _24732 = find_from(_s_47008, _24731, 1);
    _24731 = NOVALUE;
    _24733 = (_24732 == 0);
    _24732 = NOVALUE;
    if (_24733 == 0)
    {
        DeRef(_24733);
        _24733 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        DeRef(_24733);
        _24733 = NOVALUE;
    }

    /** 		SymTab[s][S_NREFS] += 1*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_47008 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _24736 = (int)*(((s1_ptr)_2)->base + 12);
    _24734 = NOVALUE;
    if (IS_ATOM_INT(_24736)) {
        _24737 = _24736 + 1;
        if (_24737 > MAXINT){
            _24737 = NewDouble((double)_24737);
        }
    }
    else
    _24737 = binary_op(PLUS, 1, _24736);
    _24736 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _24737;
    if( _1 != _24737 ){
        DeRef(_1);
    }
    _24737 = NOVALUE;
    _24734 = NOVALUE;

    /** 		SymTab[CurrentSub][S_REFLIST] &= s*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_26CurrentSub_11990 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _24740 = (int)*(((s1_ptr)_2)->base + 24);
    _24738 = NOVALUE;
    if (IS_SEQUENCE(_24740) && IS_ATOM(_s_47008)) {
        Append(&_24741, _24740, _s_47008);
    }
    else if (IS_ATOM(_24740) && IS_SEQUENCE(_s_47008)) {
    }
    else {
        Concat((object_ptr)&_24741, _24740, _s_47008);
        _24740 = NOVALUE;
    }
    _24740 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 24);
    _1 = *(int *)_2;
    *(int *)_2 = _24741;
    if( _1 != _24741 ){
        DeRef(_1);
    }
    _24741 = NOVALUE;
    _24738 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_tok_47006);
    DeRef(_24728);
    _24728 = NOVALUE;
    return;
    ;
}


void _52mark_all(int _attribute_47038)
{
    int _p_47041 = NOVALUE;
    int _sym_file_47048 = NOVALUE;
    int _scope_47065 = NOVALUE;
    int _24773 = NOVALUE;
    int _24772 = NOVALUE;
    int _24771 = NOVALUE;
    int _24769 = NOVALUE;
    int _24767 = NOVALUE;
    int _24766 = NOVALUE;
    int _24765 = NOVALUE;
    int _24764 = NOVALUE;
    int _24763 = NOVALUE;
    int _24761 = NOVALUE;
    int _24760 = NOVALUE;
    int _24759 = NOVALUE;
    int _24758 = NOVALUE;
    int _24754 = NOVALUE;
    int _24753 = NOVALUE;
    int _24752 = NOVALUE;
    int _24750 = NOVALUE;
    int _24749 = NOVALUE;
    int _24747 = NOVALUE;
    int _24745 = NOVALUE;
    int _24742 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if just_mark_everything_from then*/
    if (_52just_mark_everything_from_47035 == 0)
    {
        goto L1; // [7] 270
    }
    else{
    }

    /** 		symtab_pointer p = SymTab[just_mark_everything_from][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24742 = (int)*(((s1_ptr)_2)->base + _52just_mark_everything_from_47035);
    _2 = (int)SEQ_PTR(_24742);
    _p_47041 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_47041)){
        _p_47041 = (long)DBL_PTR(_p_47041)->dbl;
    }
    _24742 = NOVALUE;

    /** 		while p != 0 do*/
L2: 
    if (_p_47041 == 0)
    goto L3; // [33] 269

    /** 			integer sym_file = SymTab[p][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24745 = (int)*(((s1_ptr)_2)->base + _p_47041);
    _2 = (int)SEQ_PTR(_24745);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _sym_file_47048 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _sym_file_47048 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    if (!IS_ATOM_INT(_sym_file_47048)){
        _sym_file_47048 = (long)DBL_PTR(_sym_file_47048)->dbl;
    }
    _24745 = NOVALUE;

    /** 			just_mark_everything_from = p*/
    _52just_mark_everything_from_47035 = _p_47041;

    /** 			if sym_file = current_file_no or find( sym_file, recheck_files ) then*/
    _24747 = (_sym_file_47048 == _26current_file_no_11982);
    if (_24747 != 0) {
        goto L4; // [68] 84
    }
    _24749 = find_from(_sym_file_47048, _52recheck_files_47108, 1);
    if (_24749 == 0)
    {
        _24749 = NOVALUE;
        goto L5; // [80] 108
    }
    else{
        _24749 = NOVALUE;
    }
L4: 

    /** 				SymTab[p][attribute] += 1*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_47041 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _24752 = (int)*(((s1_ptr)_2)->base + _attribute_47038);
    _24750 = NOVALUE;
    if (IS_ATOM_INT(_24752)) {
        _24753 = _24752 + 1;
        if (_24753 > MAXINT){
            _24753 = NewDouble((double)_24753);
        }
    }
    else
    _24753 = binary_op(PLUS, 1, _24752);
    _24752 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _attribute_47038);
    _1 = *(int *)_2;
    *(int *)_2 = _24753;
    if( _1 != _24753 ){
        DeRef(_1);
    }
    _24753 = NOVALUE;
    _24750 = NOVALUE;
    goto L6; // [105] 246
L5: 

    /** 				integer scope = SymTab[p][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24754 = (int)*(((s1_ptr)_2)->base + _p_47041);
    _2 = (int)SEQ_PTR(_24754);
    _scope_47065 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_47065)){
        _scope_47065 = (long)DBL_PTR(_scope_47065)->dbl;
    }
    _24754 = NOVALUE;

    /** 				switch scope with fallthru do*/
    _0 = _scope_47065;
    switch ( _0 ){ 

        /** 					case SC_PUBLIC then*/
        case 13:

        /** 						if and_bits( DIRECT_OR_PUBLIC_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        _24758 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
        _2 = (int)SEQ_PTR(_24758);
        _24759 = (int)*(((s1_ptr)_2)->base + _sym_file_47048);
        _24758 = NOVALUE;
        if (IS_ATOM_INT(_24759)) {
            {unsigned long tu;
                 tu = (unsigned long)6 & (unsigned long)_24759;
                 _24760 = MAKE_UINT(tu);
            }
        }
        else {
            _24760 = binary_op(AND_BITS, 6, _24759);
        }
        _24759 = NOVALUE;
        if (_24760 == 0) {
            DeRef(_24760);
            _24760 = NOVALUE;
            goto L7; // [155] 243
        }
        else {
            if (!IS_ATOM_INT(_24760) && DBL_PTR(_24760)->dbl == 0.0){
                DeRef(_24760);
                _24760 = NOVALUE;
                goto L7; // [155] 243
            }
            DeRef(_24760);
            _24760 = NOVALUE;
        }
        DeRef(_24760);
        _24760 = NOVALUE;

        /** 							SymTab[p][attribute] += 1*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_47041 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _24763 = (int)*(((s1_ptr)_2)->base + _attribute_47038);
        _24761 = NOVALUE;
        if (IS_ATOM_INT(_24763)) {
            _24764 = _24763 + 1;
            if (_24764 > MAXINT){
                _24764 = NewDouble((double)_24764);
            }
        }
        else
        _24764 = binary_op(PLUS, 1, _24763);
        _24763 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _attribute_47038);
        _1 = *(int *)_2;
        *(int *)_2 = _24764;
        if( _1 != _24764 ){
            DeRef(_1);
        }
        _24764 = NOVALUE;
        _24761 = NOVALUE;

        /** 						break*/
        goto L7; // [182] 243

        /** 					case SC_EXPORT then*/
        case 11:

        /** 						if not and_bits( DIRECT_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        _24765 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
        _2 = (int)SEQ_PTR(_24765);
        _24766 = (int)*(((s1_ptr)_2)->base + _sym_file_47048);
        _24765 = NOVALUE;
        if (IS_ATOM_INT(_24766)) {
            {unsigned long tu;
                 tu = (unsigned long)2 & (unsigned long)_24766;
                 _24767 = MAKE_UINT(tu);
            }
        }
        else {
            _24767 = binary_op(AND_BITS, 2, _24766);
        }
        _24766 = NOVALUE;
        if (IS_ATOM_INT(_24767)) {
            if (_24767 != 0){
                DeRef(_24767);
                _24767 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        else {
            if (DBL_PTR(_24767)->dbl != 0.0){
                DeRef(_24767);
                _24767 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        DeRef(_24767);
        _24767 = NOVALUE;

        /** 							break*/
        goto L9; // [213] 217
L8: 
L9: 

        /** 					case SC_GLOBAL then*/
        case 6:

        /** 						SymTab[p][attribute] += 1*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_47041 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _24771 = (int)*(((s1_ptr)_2)->base + _attribute_47038);
        _24769 = NOVALUE;
        if (IS_ATOM_INT(_24771)) {
            _24772 = _24771 + 1;
            if (_24772 > MAXINT){
                _24772 = NewDouble((double)_24772);
            }
        }
        else
        _24772 = binary_op(PLUS, 1, _24771);
        _24771 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _attribute_47038);
        _1 = *(int *)_2;
        *(int *)_2 = _24772;
        if( _1 != _24772 ){
            DeRef(_1);
        }
        _24772 = NOVALUE;
        _24769 = NOVALUE;
    ;}L7: 
L6: 

    /** 			p = SymTab[p][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24773 = (int)*(((s1_ptr)_2)->base + _p_47041);
    _2 = (int)SEQ_PTR(_24773);
    _p_47041 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_47041)){
        _p_47041 = (long)DBL_PTR(_p_47041)->dbl;
    }
    _24773 = NOVALUE;

    /** 		end while*/
    goto L2; // [266] 33
L3: 
L1: 

    /** end procedure*/
    DeRef(_24747);
    _24747 = NOVALUE;
    return;
    ;
}


void _52mark_final_targets()
{
    int _marked_47123 = NOVALUE;
    int _24779 = NOVALUE;
    int _24777 = NOVALUE;
    int _24776 = NOVALUE;
    int _24775 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if just_mark_everything_from then*/
    if (_52just_mark_everything_from_47035 == 0)
    {
        goto L1; // [5] 44
    }
    else{
    }

    /** 		if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L2; // [12] 25
    }
    else{
    }

    /** 			mark_all( S_RI_TARGET )*/
    _52mark_all(53);
    goto L3; // [22] 152
L2: 

    /** 		elsif BIND then*/
    if (_26BIND_11622 == 0)
    {
        goto L3; // [29] 152
    }
    else{
    }

    /** 			mark_all( S_NREFS )*/
    _52mark_all(12);
    goto L3; // [41] 152
L1: 

    /** 	elsif length( recheck_targets ) then*/
    if (IS_SEQUENCE(_52recheck_targets_47107)){
            _24775 = SEQ_PTR(_52recheck_targets_47107)->length;
    }
    else {
        _24775 = 1;
    }
    if (_24775 == 0)
    {
        _24775 = NOVALUE;
        goto L4; // [51] 151
    }
    else{
        _24775 = NOVALUE;
    }

    /** 		for i = length( recheck_targets ) to 1 by -1 do*/
    if (IS_SEQUENCE(_52recheck_targets_47107)){
            _24776 = SEQ_PTR(_52recheck_targets_47107)->length;
    }
    else {
        _24776 = 1;
    }
    {
        int _i_47121;
        _i_47121 = _24776;
L5: 
        if (_i_47121 < 1){
            goto L6; // [61] 150
        }

        /** 			integer marked = 0*/
        _marked_47123 = 0;

        /** 			if TRANSLATE then*/
        if (_26TRANSLATE_11619 == 0)
        {
            goto L7; // [77] 100
        }
        else{
        }

        /** 				marked = MarkTargets( recheck_targets[i], S_RI_TARGET )*/
        _2 = (int)SEQ_PTR(_52recheck_targets_47107);
        _24777 = (int)*(((s1_ptr)_2)->base + _i_47121);
        Ref(_24777);
        _marked_47123 = _52MarkTargets(_24777, 53);
        _24777 = NOVALUE;
        if (!IS_ATOM_INT(_marked_47123)) {
            _1 = (long)(DBL_PTR(_marked_47123)->dbl);
            DeRefDS(_marked_47123);
            _marked_47123 = _1;
        }
        goto L8; // [97] 126
L7: 

        /** 			elsif BIND then*/
        if (_26BIND_11622 == 0)
        {
            goto L9; // [104] 125
        }
        else{
        }

        /** 				marked = MarkTargets( recheck_targets[i], S_NREFS )*/
        _2 = (int)SEQ_PTR(_52recheck_targets_47107);
        _24779 = (int)*(((s1_ptr)_2)->base + _i_47121);
        Ref(_24779);
        _marked_47123 = _52MarkTargets(_24779, 12);
        _24779 = NOVALUE;
        if (!IS_ATOM_INT(_marked_47123)) {
            _1 = (long)(DBL_PTR(_marked_47123)->dbl);
            DeRefDS(_marked_47123);
            _marked_47123 = _1;
        }
L9: 
L8: 

        /** 			if marked then*/
        if (_marked_47123 == 0)
        {
            goto LA; // [128] 141
        }
        else{
        }

        /** 				recheck_targets = remove( recheck_targets, i )*/
        {
            s1_ptr assign_space = SEQ_PTR(_52recheck_targets_47107);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_47121)) ? _i_47121 : (long)(DBL_PTR(_i_47121)->dbl);
            int stop = (IS_ATOM_INT(_i_47121)) ? _i_47121 : (long)(DBL_PTR(_i_47121)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_52recheck_targets_47107), start, &_52recheck_targets_47107 );
                }
                else Tail(SEQ_PTR(_52recheck_targets_47107), stop+1, &_52recheck_targets_47107);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_52recheck_targets_47107), start, &_52recheck_targets_47107);
            }
            else {
                assign_slice_seq = &assign_space;
                _52recheck_targets_47107 = Remove_elements(start, stop, (SEQ_PTR(_52recheck_targets_47107)->ref == 1));
            }
        }
LA: 

        /** 		end for*/
        _i_47121 = _i_47121 + -1;
        goto L5; // [145] 68
L6: 
        ;
    }
L4: 
L3: 

    /** end procedure*/
    return;
    ;
}


int _52is_routine(int _sym_47141)
{
    int _tok_47142 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer tok = sym_token( sym )*/
    _tok_47142 = _52sym_token(_sym_47141);
    if (!IS_ATOM_INT(_tok_47142)) {
        _1 = (long)(DBL_PTR(_tok_47142)->dbl);
        DeRefDS(_tok_47142);
        _tok_47142 = _1;
    }

    /** 	switch tok do*/
    _0 = _tok_47142;
    switch ( _0 ){ 

        /** 		case FUNC, PROC, TYPE then*/
        case 501:
        case 27:
        case 504:

        /** 			return 1*/
        return 1;
        goto L1; // [32] 45

        /** 		case else*/
        default:

        /** 			return 0*/
        return 0;
    ;}L1: 
    ;
}


int _52is_visible(int _sym_47155, int _from_file_47156)
{
    int _scope_47157 = NOVALUE;
    int _sym_file_47160 = NOVALUE;
    int _visible_mask_47165 = NOVALUE;
    int _24793 = NOVALUE;
    int _24792 = NOVALUE;
    int _24791 = NOVALUE;
    int _24790 = NOVALUE;
    int _24786 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer scope = sym_scope( sym )*/
    _scope_47157 = _52sym_scope(_sym_47155);
    if (!IS_ATOM_INT(_scope_47157)) {
        _1 = (long)(DBL_PTR(_scope_47157)->dbl);
        DeRefDS(_scope_47157);
        _scope_47157 = _1;
    }

    /** 	integer sym_file = SymTab[sym][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24786 = (int)*(((s1_ptr)_2)->base + _sym_47155);
    _2 = (int)SEQ_PTR(_24786);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _sym_file_47160 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _sym_file_47160 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    if (!IS_ATOM_INT(_sym_file_47160)){
        _sym_file_47160 = (long)DBL_PTR(_sym_file_47160)->dbl;
    }
    _24786 = NOVALUE;

    /** 	switch scope do*/
    _0 = _scope_47157;
    switch ( _0 ){ 

        /** 		case SC_PUBLIC then*/
        case 13:

        /** 			visible_mask = DIRECT_OR_PUBLIC_INCLUDE*/
        _visible_mask_47165 = 6;
        goto L1; // [49] 93

        /** 		case SC_EXPORT then*/
        case 11:

        /** 			visible_mask = DIRECT_INCLUDE*/
        _visible_mask_47165 = 2;
        goto L1; // [64] 93

        /** 		case SC_GLOBAL then*/
        case 6:

        /** 			return 1*/
        return 1;
        goto L1; // [76] 93

        /** 		case else*/
        default:

        /** 			return from_file = sym_file*/
        _24790 = (_from_file_47156 == _sym_file_47160);
        return _24790;
    ;}L1: 

    /** 	return and_bits( visible_mask, include_matrix[from_file][sym_file] )*/
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _24791 = (int)*(((s1_ptr)_2)->base + _from_file_47156);
    _2 = (int)SEQ_PTR(_24791);
    _24792 = (int)*(((s1_ptr)_2)->base + _sym_file_47160);
    _24791 = NOVALUE;
    if (IS_ATOM_INT(_24792)) {
        {unsigned long tu;
             tu = (unsigned long)_visible_mask_47165 & (unsigned long)_24792;
             _24793 = MAKE_UINT(tu);
        }
    }
    else {
        _24793 = binary_op(AND_BITS, _visible_mask_47165, _24792);
    }
    _24792 = NOVALUE;
    DeRef(_24790);
    _24790 = NOVALUE;
    return _24793;
    ;
}


int _52MarkTargets(int _s_47185, int _attribute_47186)
{
    int _p_47188 = NOVALUE;
    int _sname_47189 = NOVALUE;
    int _string_47190 = NOVALUE;
    int _colon_47191 = NOVALUE;
    int _h_47192 = NOVALUE;
    int _scope_47193 = NOVALUE;
    int _found_47214 = NOVALUE;
    int _24845 = NOVALUE;
    int _24841 = NOVALUE;
    int _24839 = NOVALUE;
    int _24838 = NOVALUE;
    int _24837 = NOVALUE;
    int _24836 = NOVALUE;
    int _24834 = NOVALUE;
    int _24833 = NOVALUE;
    int _24832 = NOVALUE;
    int _24831 = NOVALUE;
    int _24830 = NOVALUE;
    int _24828 = NOVALUE;
    int _24827 = NOVALUE;
    int _24826 = NOVALUE;
    int _24824 = NOVALUE;
    int _24822 = NOVALUE;
    int _24820 = NOVALUE;
    int _24819 = NOVALUE;
    int _24818 = NOVALUE;
    int _24817 = NOVALUE;
    int _24815 = NOVALUE;
    int _24814 = NOVALUE;
    int _24813 = NOVALUE;
    int _24812 = NOVALUE;
    int _24810 = NOVALUE;
    int _24809 = NOVALUE;
    int _24805 = NOVALUE;
    int _24804 = NOVALUE;
    int _24803 = NOVALUE;
    int _24802 = NOVALUE;
    int _24801 = NOVALUE;
    int _24800 = NOVALUE;
    int _24799 = NOVALUE;
    int _24798 = NOVALUE;
    int _24797 = NOVALUE;
    int _24796 = NOVALUE;
    int _24795 = NOVALUE;
    int _24794 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_47185)) {
        _1 = (long)(DBL_PTR(_s_47185)->dbl);
        DeRefDS(_s_47185);
        _s_47185 = _1;
    }
    if (!IS_ATOM_INT(_attribute_47186)) {
        _1 = (long)(DBL_PTR(_attribute_47186)->dbl);
        DeRefDS(_attribute_47186);
        _attribute_47186 = _1;
    }

    /** 	sequence sname*/

    /** 	sequence string*/

    /** 	integer colon, h*/

    /** 	integer scope*/

    /** 	if (SymTab[s][S_MODE] = M_TEMP or*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24794 = (int)*(((s1_ptr)_2)->base + _s_47185);
    _2 = (int)SEQ_PTR(_24794);
    _24795 = (int)*(((s1_ptr)_2)->base + 3);
    _24794 = NOVALUE;
    if (IS_ATOM_INT(_24795)) {
        _24796 = (_24795 == 3);
    }
    else {
        _24796 = binary_op(EQUALS, _24795, 3);
    }
    _24795 = NOVALUE;
    if (IS_ATOM_INT(_24796)) {
        if (_24796 != 0) {
            _24797 = 1;
            goto L1; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_24796)->dbl != 0.0) {
            _24797 = 1;
            goto L1; // [33] 59
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24798 = (int)*(((s1_ptr)_2)->base + _s_47185);
    _2 = (int)SEQ_PTR(_24798);
    _24799 = (int)*(((s1_ptr)_2)->base + 3);
    _24798 = NOVALUE;
    if (IS_ATOM_INT(_24799)) {
        _24800 = (_24799 == 2);
    }
    else {
        _24800 = binary_op(EQUALS, _24799, 2);
    }
    _24799 = NOVALUE;
    DeRef(_24797);
    if (IS_ATOM_INT(_24800))
    _24797 = (_24800 != 0);
    else
    _24797 = DBL_PTR(_24800)->dbl != 0.0;
L1: 
    if (_24797 == 0) {
        goto L2; // [59] 440
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24802 = (int)*(((s1_ptr)_2)->base + _s_47185);
    _2 = (int)SEQ_PTR(_24802);
    _24803 = (int)*(((s1_ptr)_2)->base + 1);
    _24802 = NOVALUE;
    _24804 = IS_SEQUENCE(_24803);
    _24803 = NOVALUE;
    if (_24804 == 0)
    {
        _24804 = NOVALUE;
        goto L2; // [79] 440
    }
    else{
        _24804 = NOVALUE;
    }

    /** 		integer found = 0*/
    _found_47214 = 0;

    /** 		string = SymTab[s][S_OBJ]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24805 = (int)*(((s1_ptr)_2)->base + _s_47185);
    DeRef(_string_47190);
    _2 = (int)SEQ_PTR(_24805);
    _string_47190 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_string_47190);
    _24805 = NOVALUE;

    /** 		colon = find(':', string)*/
    _colon_47191 = find_from(58, _string_47190, 1);

    /** 		if colon = 0 then*/
    if (_colon_47191 != 0)
    goto L3; // [112] 126

    /** 			sname = string*/
    RefDS(_string_47190);
    DeRef(_sname_47189);
    _sname_47189 = _string_47190;
    goto L4; // [123] 200
L3: 

    /** 			sname = string[colon+1..$]  -- ignore namespace part*/
    _24809 = _colon_47191 + 1;
    if (_24809 > MAXINT){
        _24809 = NewDouble((double)_24809);
    }
    if (IS_SEQUENCE(_string_47190)){
            _24810 = SEQ_PTR(_string_47190)->length;
    }
    else {
        _24810 = 1;
    }
    rhs_slice_target = (object_ptr)&_sname_47189;
    RHS_Slice(_string_47190, _24809, _24810);

    /** 			while length(sname) and sname[1] = ' ' or sname[1] = '\t' do*/
L5: 
    if (IS_SEQUENCE(_sname_47189)){
            _24812 = SEQ_PTR(_sname_47189)->length;
    }
    else {
        _24812 = 1;
    }
    if (_24812 == 0) {
        _24813 = 0;
        goto L6; // [148] 164
    }
    _2 = (int)SEQ_PTR(_sname_47189);
    _24814 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24814)) {
        _24815 = (_24814 == 32);
    }
    else {
        _24815 = binary_op(EQUALS, _24814, 32);
    }
    _24814 = NOVALUE;
    if (IS_ATOM_INT(_24815))
    _24813 = (_24815 != 0);
    else
    _24813 = DBL_PTR(_24815)->dbl != 0.0;
L6: 
    if (_24813 != 0) {
        goto L7; // [164] 181
    }
    _2 = (int)SEQ_PTR(_sname_47189);
    _24817 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24817)) {
        _24818 = (_24817 == 9);
    }
    else {
        _24818 = binary_op(EQUALS, _24817, 9);
    }
    _24817 = NOVALUE;
    if (_24818 <= 0) {
        if (_24818 == 0) {
            DeRef(_24818);
            _24818 = NOVALUE;
            goto L8; // [177] 199
        }
        else {
            if (!IS_ATOM_INT(_24818) && DBL_PTR(_24818)->dbl == 0.0){
                DeRef(_24818);
                _24818 = NOVALUE;
                goto L8; // [177] 199
            }
            DeRef(_24818);
            _24818 = NOVALUE;
        }
    }
    DeRef(_24818);
    _24818 = NOVALUE;
L7: 

    /** 				sname = tail( sname, length( sname ) -1 )*/
    if (IS_SEQUENCE(_sname_47189)){
            _24819 = SEQ_PTR(_sname_47189)->length;
    }
    else {
        _24819 = 1;
    }
    _24820 = _24819 - 1;
    _24819 = NOVALUE;
    {
        int len = SEQ_PTR(_sname_47189)->length;
        int size = (IS_ATOM_INT(_24820)) ? _24820 : (long)(DBL_PTR(_24820)->dbl);
        if (size <= 0) {
            DeRef(_sname_47189);
            _sname_47189 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_sname_47189);
            DeRef(_sname_47189);
            _sname_47189 = _sname_47189;
        }
        else Tail(SEQ_PTR(_sname_47189), len-size+1, &_sname_47189);
    }
    _24820 = NOVALUE;

    /** 			end while*/
    goto L5; // [196] 145
L8: 
L4: 

    /** 		if length(sname) = 0 then*/
    if (IS_SEQUENCE(_sname_47189)){
            _24822 = SEQ_PTR(_sname_47189)->length;
    }
    else {
        _24822 = 1;
    }
    if (_24822 != 0)
    goto L9; // [207] 218

    /** 			return 1*/
    DeRefDS(_sname_47189);
    DeRef(_string_47190);
    DeRef(_24809);
    _24809 = NOVALUE;
    DeRef(_24796);
    _24796 = NOVALUE;
    DeRef(_24800);
    _24800 = NOVALUE;
    DeRef(_24815);
    _24815 = NOVALUE;
    return 1;
L9: 

    /** 		h = buckets[hashfn(sname)]*/
    RefDS(_sname_47189);
    _24824 = _52hashfn(_sname_47189);
    _2 = (int)SEQ_PTR(_52buckets_46126);
    if (!IS_ATOM_INT(_24824)){
        _h_47192 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24824)->dbl));
    }
    else{
        _h_47192 = (int)*(((s1_ptr)_2)->base + _24824);
    }
    if (!IS_ATOM_INT(_h_47192))
    _h_47192 = (long)DBL_PTR(_h_47192)->dbl;

    /** 		while h do*/
LA: 
    if (_h_47192 == 0)
    {
        goto LB; // [235] 381
    }
    else{
    }

    /** 			if equal(sname, SymTab[h][S_NAME]) then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24826 = (int)*(((s1_ptr)_2)->base + _h_47192);
    _2 = (int)SEQ_PTR(_24826);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _24827 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _24827 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _24826 = NOVALUE;
    if (_sname_47189 == _24827)
    _24828 = 1;
    else if (IS_ATOM_INT(_sname_47189) && IS_ATOM_INT(_24827))
    _24828 = 0;
    else
    _24828 = (compare(_sname_47189, _24827) == 0);
    _24827 = NOVALUE;
    if (_24828 == 0)
    {
        _24828 = NOVALUE;
        goto LC; // [256] 360
    }
    else{
        _24828 = NOVALUE;
    }

    /** 				if attribute = S_NREFS then*/
    if (_attribute_47186 != 12)
    goto LD; // [263] 289

    /** 					if BIND then*/
    if (_26BIND_11622 == 0)
    {
        goto LE; // [271] 359
    }
    else{
    }

    /** 						add_ref({PROC, h})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 27;
    ((int *)_2)[2] = _h_47192;
    _24830 = MAKE_SEQ(_1);
    _52add_ref(_24830);
    _24830 = NOVALUE;
    goto LE; // [286] 359
LD: 

    /** 				elsif is_routine( h ) and is_visible( h, current_file_no ) then*/
    _24831 = _52is_routine(_h_47192);
    if (IS_ATOM_INT(_24831)) {
        if (_24831 == 0) {
            goto LF; // [295] 358
        }
    }
    else {
        if (DBL_PTR(_24831)->dbl == 0.0) {
            goto LF; // [295] 358
        }
    }
    _24833 = _52is_visible(_h_47192, _26current_file_no_11982);
    if (_24833 == 0) {
        DeRef(_24833);
        _24833 = NOVALUE;
        goto LF; // [307] 358
    }
    else {
        if (!IS_ATOM_INT(_24833) && DBL_PTR(_24833)->dbl == 0.0){
            DeRef(_24833);
            _24833 = NOVALUE;
            goto LF; // [307] 358
        }
        DeRef(_24833);
        _24833 = NOVALUE;
    }
    DeRef(_24833);
    _24833 = NOVALUE;

    /** 					SymTab[h][attribute] += 1*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_h_47192 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _24836 = (int)*(((s1_ptr)_2)->base + _attribute_47186);
    _24834 = NOVALUE;
    if (IS_ATOM_INT(_24836)) {
        _24837 = _24836 + 1;
        if (_24837 > MAXINT){
            _24837 = NewDouble((double)_24837);
        }
    }
    else
    _24837 = binary_op(PLUS, 1, _24836);
    _24836 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _attribute_47186);
    _1 = *(int *)_2;
    *(int *)_2 = _24837;
    if( _1 != _24837 ){
        DeRef(_1);
    }
    _24837 = NOVALUE;
    _24834 = NOVALUE;

    /** 					if current_file_no = SymTab[h][S_FILE_NO] then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24838 = (int)*(((s1_ptr)_2)->base + _h_47192);
    _2 = (int)SEQ_PTR(_24838);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _24839 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _24839 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _24838 = NOVALUE;
    if (binary_op_a(NOTEQ, _26current_file_no_11982, _24839)){
        _24839 = NOVALUE;
        goto L10; // [347] 357
    }
    _24839 = NOVALUE;

    /** 						found = 1*/
    _found_47214 = 1;
L10: 
LF: 
LE: 
LC: 

    /** 			h = SymTab[h][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24841 = (int)*(((s1_ptr)_2)->base + _h_47192);
    _2 = (int)SEQ_PTR(_24841);
    _h_47192 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_h_47192)){
        _h_47192 = (long)DBL_PTR(_h_47192)->dbl;
    }
    _24841 = NOVALUE;

    /** 		end while*/
    goto LA; // [378] 235
LB: 

    /** 		if not found then*/
    if (_found_47214 != 0)
    goto L11; // [383] 429

    /** 			just_mark_everything_from = TopLevelSub*/
    _52just_mark_everything_from_47035 = _26TopLevelSub_11989;

    /** 			recheck_targets &= s*/
    Append(&_52recheck_targets_47107, _52recheck_targets_47107, _s_47185);

    /** 			if not find( current_file_no, recheck_files ) then*/
    _24845 = find_from(_26current_file_no_11982, _52recheck_files_47108, 1);
    if (_24845 != 0)
    goto L12; // [414] 428
    _24845 = NOVALUE;

    /** 				recheck_files &= current_file_no*/
    Append(&_52recheck_files_47108, _52recheck_files_47108, _26current_file_no_11982);
L12: 
L11: 

    /** 		return found*/
    DeRef(_sname_47189);
    DeRef(_string_47190);
    DeRef(_24809);
    _24809 = NOVALUE;
    DeRef(_24796);
    _24796 = NOVALUE;
    DeRef(_24800);
    _24800 = NOVALUE;
    DeRef(_24824);
    _24824 = NOVALUE;
    DeRef(_24815);
    _24815 = NOVALUE;
    DeRef(_24831);
    _24831 = NOVALUE;
    return _found_47214;
    goto L13; // [437] 469
L2: 

    /** 		if not just_mark_everything_from then*/
    if (_52just_mark_everything_from_47035 != 0)
    goto L14; // [444] 457

    /** 			just_mark_everything_from = TopLevelSub*/
    _52just_mark_everything_from_47035 = _26TopLevelSub_11989;
L14: 

    /** 		mark_all( attribute )*/
    _52mark_all(_attribute_47186);

    /** 		return 1*/
    DeRef(_sname_47189);
    DeRef(_string_47190);
    DeRef(_24809);
    _24809 = NOVALUE;
    DeRef(_24796);
    _24796 = NOVALUE;
    DeRef(_24800);
    _24800 = NOVALUE;
    DeRef(_24824);
    _24824 = NOVALUE;
    DeRef(_24815);
    _24815 = NOVALUE;
    DeRef(_24831);
    _24831 = NOVALUE;
    return 1;
L13: 
    ;
}


void _52resolve_unincluded_globals(int _ok_47299)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ok_47299)) {
        _1 = (long)(DBL_PTR(_ok_47299)->dbl);
        DeRefDS(_ok_47299);
        _ok_47299 = _1;
    }

    /** 	Resolve_unincluded_globals = ok*/
    _52Resolve_unincluded_globals_47296 = _ok_47299;

    /** end procedure*/
    return;
    ;
}


int _52get_resolve_unincluded_globals()
{
    int _0, _1, _2;
    

    /** 	return Resolve_unincluded_globals*/
    return _52Resolve_unincluded_globals_47296;
    ;
}


int _52keyfind(int _word_47305, int _file_no_47306, int _scanning_file_47307, int _namespace_ok_47310, int _hashval_47311)
{
    int _msg_47313 = NOVALUE;
    int _b_name_47314 = NOVALUE;
    int _scope_47315 = NOVALUE;
    int _defined_47316 = NOVALUE;
    int _ix_47317 = NOVALUE;
    int _st_ptr_47319 = NOVALUE;
    int _st_builtin_47320 = NOVALUE;
    int _tok_47322 = NOVALUE;
    int _gtok_47323 = NOVALUE;
    int _any_symbol_47326 = NOVALUE;
    int _tok_file_47494 = NOVALUE;
    int _good_47501 = NOVALUE;
    int _include_type_47511 = NOVALUE;
    int _msg_file_47567 = NOVALUE;
    int _25040 = NOVALUE;
    int _25039 = NOVALUE;
    int _25037 = NOVALUE;
    int _25035 = NOVALUE;
    int _25034 = NOVALUE;
    int _25033 = NOVALUE;
    int _25032 = NOVALUE;
    int _25031 = NOVALUE;
    int _25029 = NOVALUE;
    int _25027 = NOVALUE;
    int _25026 = NOVALUE;
    int _25025 = NOVALUE;
    int _25024 = NOVALUE;
    int _25023 = NOVALUE;
    int _25022 = NOVALUE;
    int _25021 = NOVALUE;
    int _25020 = NOVALUE;
    int _25018 = NOVALUE;
    int _25017 = NOVALUE;
    int _25016 = NOVALUE;
    int _25015 = NOVALUE;
    int _25014 = NOVALUE;
    int _25013 = NOVALUE;
    int _25012 = NOVALUE;
    int _25011 = NOVALUE;
    int _25010 = NOVALUE;
    int _25009 = NOVALUE;
    int _25008 = NOVALUE;
    int _25007 = NOVALUE;
    int _25006 = NOVALUE;
    int _25005 = NOVALUE;
    int _25004 = NOVALUE;
    int _25003 = NOVALUE;
    int _25002 = NOVALUE;
    int _25000 = NOVALUE;
    int _24999 = NOVALUE;
    int _24996 = NOVALUE;
    int _24992 = NOVALUE;
    int _24990 = NOVALUE;
    int _24989 = NOVALUE;
    int _24988 = NOVALUE;
    int _24987 = NOVALUE;
    int _24986 = NOVALUE;
    int _24984 = NOVALUE;
    int _24983 = NOVALUE;
    int _24982 = NOVALUE;
    int _24981 = NOVALUE;
    int _24979 = NOVALUE;
    int _24976 = NOVALUE;
    int _24975 = NOVALUE;
    int _24974 = NOVALUE;
    int _24973 = NOVALUE;
    int _24971 = NOVALUE;
    int _24968 = NOVALUE;
    int _24967 = NOVALUE;
    int _24966 = NOVALUE;
    int _24965 = NOVALUE;
    int _24964 = NOVALUE;
    int _24963 = NOVALUE;
    int _24962 = NOVALUE;
    int _24959 = NOVALUE;
    int _24958 = NOVALUE;
    int _24956 = NOVALUE;
    int _24954 = NOVALUE;
    int _24952 = NOVALUE;
    int _24951 = NOVALUE;
    int _24950 = NOVALUE;
    int _24946 = NOVALUE;
    int _24945 = NOVALUE;
    int _24940 = NOVALUE;
    int _24938 = NOVALUE;
    int _24936 = NOVALUE;
    int _24935 = NOVALUE;
    int _24931 = NOVALUE;
    int _24930 = NOVALUE;
    int _24928 = NOVALUE;
    int _24927 = NOVALUE;
    int _24925 = NOVALUE;
    int _24924 = NOVALUE;
    int _24923 = NOVALUE;
    int _24922 = NOVALUE;
    int _24921 = NOVALUE;
    int _24919 = NOVALUE;
    int _24918 = NOVALUE;
    int _24917 = NOVALUE;
    int _24916 = NOVALUE;
    int _24915 = NOVALUE;
    int _24914 = NOVALUE;
    int _24913 = NOVALUE;
    int _24912 = NOVALUE;
    int _24911 = NOVALUE;
    int _24910 = NOVALUE;
    int _24909 = NOVALUE;
    int _24908 = NOVALUE;
    int _24907 = NOVALUE;
    int _24906 = NOVALUE;
    int _24905 = NOVALUE;
    int _24904 = NOVALUE;
    int _24903 = NOVALUE;
    int _24902 = NOVALUE;
    int _24901 = NOVALUE;
    int _24900 = NOVALUE;
    int _24899 = NOVALUE;
    int _24898 = NOVALUE;
    int _24896 = NOVALUE;
    int _24895 = NOVALUE;
    int _24893 = NOVALUE;
    int _24892 = NOVALUE;
    int _24891 = NOVALUE;
    int _24890 = NOVALUE;
    int _24889 = NOVALUE;
    int _24887 = NOVALUE;
    int _24886 = NOVALUE;
    int _24885 = NOVALUE;
    int _24883 = NOVALUE;
    int _24882 = NOVALUE;
    int _24881 = NOVALUE;
    int _24880 = NOVALUE;
    int _24879 = NOVALUE;
    int _24878 = NOVALUE;
    int _24877 = NOVALUE;
    int _24875 = NOVALUE;
    int _24874 = NOVALUE;
    int _24869 = NOVALUE;
    int _24866 = NOVALUE;
    int _24865 = NOVALUE;
    int _24864 = NOVALUE;
    int _24863 = NOVALUE;
    int _24862 = NOVALUE;
    int _24861 = NOVALUE;
    int _24860 = NOVALUE;
    int _24859 = NOVALUE;
    int _24858 = NOVALUE;
    int _24857 = NOVALUE;
    int _24856 = NOVALUE;
    int _24855 = NOVALUE;
    int _24854 = NOVALUE;
    int _24853 = NOVALUE;
    int _24852 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_file_no_47306)) {
        _1 = (long)(DBL_PTR(_file_no_47306)->dbl);
        DeRefDS(_file_no_47306);
        _file_no_47306 = _1;
    }
    if (!IS_ATOM_INT(_scanning_file_47307)) {
        _1 = (long)(DBL_PTR(_scanning_file_47307)->dbl);
        DeRefDS(_scanning_file_47307);
        _scanning_file_47307 = _1;
    }
    if (!IS_ATOM_INT(_namespace_ok_47310)) {
        _1 = (long)(DBL_PTR(_namespace_ok_47310)->dbl);
        DeRefDS(_namespace_ok_47310);
        _namespace_ok_47310 = _1;
    }
    if (!IS_ATOM_INT(_hashval_47311)) {
        _1 = (long)(DBL_PTR(_hashval_47311)->dbl);
        DeRefDS(_hashval_47311);
        _hashval_47311 = _1;
    }

    /** 	dup_globals = {}*/
    RefDS(_22037);
    DeRef(_52dup_globals_47291);
    _52dup_globals_47291 = _22037;

    /** 	dup_overrides = {}*/
    RefDS(_22037);
    DeRefi(_52dup_overrides_47292);
    _52dup_overrides_47292 = _22037;

    /** 	in_include_path = {}*/
    RefDS(_22037);
    DeRef(_52in_include_path_47293);
    _52in_include_path_47293 = _22037;

    /** 	symbol_resolution_warning = ""*/
    RefDS(_22037);
    DeRef(_26symbol_resolution_warning_12084);
    _26symbol_resolution_warning_12084 = _22037;

    /** 	st_builtin = 0*/
    _st_builtin_47320 = 0;

    /** 	ifdef EUDIS then*/

    /** 	st_ptr = buckets[hashval]*/
    _2 = (int)SEQ_PTR(_52buckets_46126);
    _st_ptr_47319 = (int)*(((s1_ptr)_2)->base + _hashval_47311);
    if (!IS_ATOM_INT(_st_ptr_47319)){
        _st_ptr_47319 = (long)DBL_PTR(_st_ptr_47319)->dbl;
    }

    /** 	integer any_symbol = namespace_ok = -1*/
    _any_symbol_47326 = (_namespace_ok_47310 == -1);

    /** 	while st_ptr do*/
L1: 
    if (_st_ptr_47319 == 0)
    {
        goto L2; // [69] 1033
    }
    else{
    }

    /** 		if SymTab[st_ptr][S_SCOPE] != SC_UNDEFINED */
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24852 = (int)*(((s1_ptr)_2)->base + _st_ptr_47319);
    _2 = (int)SEQ_PTR(_24852);
    _24853 = (int)*(((s1_ptr)_2)->base + 4);
    _24852 = NOVALUE;
    if (IS_ATOM_INT(_24853)) {
        _24854 = (_24853 != 9);
    }
    else {
        _24854 = binary_op(NOTEQ, _24853, 9);
    }
    _24853 = NOVALUE;
    if (IS_ATOM_INT(_24854)) {
        if (_24854 == 0) {
            DeRef(_24855);
            _24855 = 0;
            goto L3; // [92] 116
        }
    }
    else {
        if (DBL_PTR(_24854)->dbl == 0.0) {
            DeRef(_24855);
            _24855 = 0;
            goto L3; // [92] 116
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24856 = (int)*(((s1_ptr)_2)->base + _st_ptr_47319);
    _2 = (int)SEQ_PTR(_24856);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _24857 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _24857 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _24856 = NOVALUE;
    if (_word_47305 == _24857)
    _24858 = 1;
    else if (IS_ATOM_INT(_word_47305) && IS_ATOM_INT(_24857))
    _24858 = 0;
    else
    _24858 = (compare(_word_47305, _24857) == 0);
    _24857 = NOVALUE;
    DeRef(_24855);
    _24855 = (_24858 != 0);
L3: 
    if (_24855 == 0) {
        goto L4; // [116] 1012
    }
    if (_any_symbol_47326 != 0) {
        DeRef(_24860);
        _24860 = 1;
        goto L5; // [120] 150
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24861 = (int)*(((s1_ptr)_2)->base + _st_ptr_47319);
    _2 = (int)SEQ_PTR(_24861);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _24862 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _24862 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _24861 = NOVALUE;
    if (IS_ATOM_INT(_24862)) {
        _24863 = (_24862 == 523);
    }
    else {
        _24863 = binary_op(EQUALS, _24862, 523);
    }
    _24862 = NOVALUE;
    if (IS_ATOM_INT(_24863)) {
        _24864 = (_namespace_ok_47310 == _24863);
    }
    else {
        _24864 = binary_op(EQUALS, _namespace_ok_47310, _24863);
    }
    DeRef(_24863);
    _24863 = NOVALUE;
    if (IS_ATOM_INT(_24864))
    _24860 = (_24864 != 0);
    else
    _24860 = DBL_PTR(_24864)->dbl != 0.0;
L5: 
    if (_24860 == 0)
    {
        _24860 = NOVALUE;
        goto L4; // [151] 1012
    }
    else{
        _24860 = NOVALUE;
    }

    /** 			tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24865 = (int)*(((s1_ptr)_2)->base + _st_ptr_47319);
    _2 = (int)SEQ_PTR(_24865);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _24866 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _24866 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _24865 = NOVALUE;
    Ref(_24866);
    DeRef(_tok_47322);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24866;
    ((int *)_2)[2] = _st_ptr_47319;
    _tok_47322 = MAKE_SEQ(_1);
    _24866 = NOVALUE;

    /** 			if file_no = -1 then*/
    if (_file_no_47306 != -1)
    goto L6; // [174] 714

    /** 				scope = SymTab[st_ptr][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24869 = (int)*(((s1_ptr)_2)->base + _st_ptr_47319);
    _2 = (int)SEQ_PTR(_24869);
    _scope_47315 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_47315)){
        _scope_47315 = (long)DBL_PTR(_scope_47315)->dbl;
    }
    _24869 = NOVALUE;

    /** 				switch scope with fallthru do*/
    _0 = _scope_47315;
    switch ( _0 ){ 

        /** 				case SC_OVERRIDE then*/
        case 12:

        /** 					dup_overrides &= st_ptr*/
        Append(&_52dup_overrides_47292, _52dup_overrides_47292, _st_ptr_47319);

        /** 					break*/
        goto L7; // [215] 1011

        /** 				case SC_PREDEF then*/
        case 7:

        /** 					st_builtin = st_ptr*/
        _st_builtin_47320 = _st_ptr_47319;

        /** 					break*/
        goto L7; // [230] 1011

        /** 				case SC_GLOBAL then*/
        case 6:

        /** 					if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _24874 = (int)*(((s1_ptr)_2)->base + _st_ptr_47319);
        _2 = (int)SEQ_PTR(_24874);
        if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
            _24875 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
        }
        else{
            _24875 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
        }
        _24874 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_47307, _24875)){
            _24875 = NOVALUE;
            goto L8; // [250] 274
        }
        _24875 = NOVALUE;

        /** 						if BIND then*/
        if (_26BIND_11622 == 0)
        {
            goto L9; // [258] 267
        }
        else{
        }

        /** 							add_ref(tok)*/
        Ref(_tok_47322);
        _52add_ref(_tok_47322);
L9: 

        /** 						return tok*/
        DeRefDS(_word_47305);
        DeRef(_msg_47313);
        DeRef(_b_name_47314);
        DeRef(_gtok_47323);
        DeRef(_24864);
        _24864 = NOVALUE;
        DeRef(_24854);
        _24854 = NOVALUE;
        return _tok_47322;
L8: 

        /** 					if Resolve_unincluded_globals */
        if (_52Resolve_unincluded_globals_47296 != 0) {
            _24877 = 1;
            goto LA; // [278] 322
        }
        _2 = (int)SEQ_PTR(_27finished_files_10924);
        _24878 = (int)*(((s1_ptr)_2)->base + _scanning_file_47307);
        if (_24878 == 0) {
            _24879 = 0;
            goto LB; // [288] 318
        }
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        _24880 = (int)*(((s1_ptr)_2)->base + _scanning_file_47307);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _24881 = (int)*(((s1_ptr)_2)->base + _st_ptr_47319);
        _2 = (int)SEQ_PTR(_24881);
        if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
            _24882 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
        }
        else{
            _24882 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
        }
        _24881 = NOVALUE;
        _2 = (int)SEQ_PTR(_24880);
        if (!IS_ATOM_INT(_24882)){
            _24883 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24882)->dbl));
        }
        else{
            _24883 = (int)*(((s1_ptr)_2)->base + _24882);
        }
        _24880 = NOVALUE;
        if (IS_ATOM_INT(_24883))
        _24879 = (_24883 != 0);
        else
        _24879 = DBL_PTR(_24883)->dbl != 0.0;
LB: 
        _24877 = (_24879 != 0);
LA: 
        if (_24877 != 0) {
            goto LC; // [322] 349
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _24885 = (int)*(((s1_ptr)_2)->base + _st_ptr_47319);
        _2 = (int)SEQ_PTR(_24885);
        if (!IS_ATOM_INT(_26S_TOKEN_11659)){
            _24886 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
        }
        else{
            _24886 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
        }
        _24885 = NOVALUE;
        if (IS_ATOM_INT(_24886)) {
            _24887 = (_24886 == 523);
        }
        else {
            _24887 = binary_op(EQUALS, _24886, 523);
        }
        _24886 = NOVALUE;
        if (_24887 == 0) {
            DeRef(_24887);
            _24887 = NOVALUE;
            goto L7; // [345] 1011
        }
        else {
            if (!IS_ATOM_INT(_24887) && DBL_PTR(_24887)->dbl == 0.0){
                DeRef(_24887);
                _24887 = NOVALUE;
                goto L7; // [345] 1011
            }
            DeRef(_24887);
            _24887 = NOVALUE;
        }
        DeRef(_24887);
        _24887 = NOVALUE;
LC: 

        /** 						gtok = tok*/
        Ref(_tok_47322);
        DeRef(_gtok_47323);
        _gtok_47323 = _tok_47322;

        /** 						dup_globals &= st_ptr*/
        Append(&_52dup_globals_47291, _52dup_globals_47291, _st_ptr_47319);

        /** 						in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0*/
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        _24889 = (int)*(((s1_ptr)_2)->base + _scanning_file_47307);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _24890 = (int)*(((s1_ptr)_2)->base + _st_ptr_47319);
        _2 = (int)SEQ_PTR(_24890);
        if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
            _24891 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
        }
        else{
            _24891 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
        }
        _24890 = NOVALUE;
        _2 = (int)SEQ_PTR(_24889);
        if (!IS_ATOM_INT(_24891)){
            _24892 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24891)->dbl));
        }
        else{
            _24892 = (int)*(((s1_ptr)_2)->base + _24891);
        }
        _24889 = NOVALUE;
        if (IS_ATOM_INT(_24892)) {
            _24893 = (_24892 != 0);
        }
        else {
            _24893 = binary_op(NOTEQ, _24892, 0);
        }
        _24892 = NOVALUE;
        if (IS_SEQUENCE(_52in_include_path_47293) && IS_ATOM(_24893)) {
            Ref(_24893);
            Append(&_52in_include_path_47293, _52in_include_path_47293, _24893);
        }
        else if (IS_ATOM(_52in_include_path_47293) && IS_SEQUENCE(_24893)) {
        }
        else {
            Concat((object_ptr)&_52in_include_path_47293, _52in_include_path_47293, _24893);
        }
        DeRef(_24893);
        _24893 = NOVALUE;

        /** 					break*/
        goto L7; // [399] 1011

        /** 				case SC_PUBLIC, SC_EXPORT then*/
        case 13:
        case 11:

        /** 					if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _24895 = (int)*(((s1_ptr)_2)->base + _st_ptr_47319);
        _2 = (int)SEQ_PTR(_24895);
        if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
            _24896 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
        }
        else{
            _24896 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
        }
        _24895 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_47307, _24896)){
            _24896 = NOVALUE;
            goto LD; // [421] 445
        }
        _24896 = NOVALUE;

        /** 						if BIND then*/
        if (_26BIND_11622 == 0)
        {
            goto LE; // [429] 438
        }
        else{
        }

        /** 							add_ref(tok)*/
        Ref(_tok_47322);
        _52add_ref(_tok_47322);
LE: 

        /** 						return tok*/
        DeRefDS(_word_47305);
        DeRef(_msg_47313);
        DeRef(_b_name_47314);
        DeRef(_gtok_47323);
        DeRef(_24864);
        _24864 = NOVALUE;
        DeRef(_24854);
        _24854 = NOVALUE;
        _24878 = NOVALUE;
        _24883 = NOVALUE;
        _24882 = NOVALUE;
        _24891 = NOVALUE;
        return _tok_47322;
LD: 

        /** 					if (finished_files[scanning_file] -- everything this file needs has been read in*/
        _2 = (int)SEQ_PTR(_27finished_files_10924);
        _24898 = (int)*(((s1_ptr)_2)->base + _scanning_file_47307);
        if (_24898 != 0) {
            _24899 = 1;
            goto LF; // [453] 487
        }
        if (_namespace_ok_47310 == 0) {
            _24900 = 0;
            goto L10; // [457] 483
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _24901 = (int)*(((s1_ptr)_2)->base + _st_ptr_47319);
        _2 = (int)SEQ_PTR(_24901);
        if (!IS_ATOM_INT(_26S_TOKEN_11659)){
            _24902 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
        }
        else{
            _24902 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
        }
        _24901 = NOVALUE;
        if (IS_ATOM_INT(_24902)) {
            _24903 = (_24902 == 523);
        }
        else {
            _24903 = binary_op(EQUALS, _24902, 523);
        }
        _24902 = NOVALUE;
        if (IS_ATOM_INT(_24903))
        _24900 = (_24903 != 0);
        else
        _24900 = DBL_PTR(_24903)->dbl != 0.0;
L10: 
        _24899 = (_24900 != 0);
LF: 
        if (_24899 == 0) {
            goto L7; // [487] 1011
        }
        _24905 = (_scope_47315 == 13);
        if (_24905 == 0) {
            _24906 = 0;
            goto L11; // [497] 533
        }
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        _24907 = (int)*(((s1_ptr)_2)->base + _scanning_file_47307);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _24908 = (int)*(((s1_ptr)_2)->base + _st_ptr_47319);
        _2 = (int)SEQ_PTR(_24908);
        if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
            _24909 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
        }
        else{
            _24909 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
        }
        _24908 = NOVALUE;
        _2 = (int)SEQ_PTR(_24907);
        if (!IS_ATOM_INT(_24909)){
            _24910 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24909)->dbl));
        }
        else{
            _24910 = (int)*(((s1_ptr)_2)->base + _24909);
        }
        _24907 = NOVALUE;
        if (IS_ATOM_INT(_24910)) {
            {unsigned long tu;
                 tu = (unsigned long)6 & (unsigned long)_24910;
                 _24911 = MAKE_UINT(tu);
            }
        }
        else {
            _24911 = binary_op(AND_BITS, 6, _24910);
        }
        _24910 = NOVALUE;
        if (IS_ATOM_INT(_24911))
        _24906 = (_24911 != 0);
        else
        _24906 = DBL_PTR(_24911)->dbl != 0.0;
L11: 
        if (_24906 != 0) {
            DeRef(_24912);
            _24912 = 1;
            goto L12; // [533] 583
        }
        _24913 = (_scope_47315 == 11);
        if (_24913 == 0) {
            _24914 = 0;
            goto L13; // [543] 579
        }
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        _24915 = (int)*(((s1_ptr)_2)->base + _scanning_file_47307);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _24916 = (int)*(((s1_ptr)_2)->base + _st_ptr_47319);
        _2 = (int)SEQ_PTR(_24916);
        if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
            _24917 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
        }
        else{
            _24917 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
        }
        _24916 = NOVALUE;
        _2 = (int)SEQ_PTR(_24915);
        if (!IS_ATOM_INT(_24917)){
            _24918 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24917)->dbl));
        }
        else{
            _24918 = (int)*(((s1_ptr)_2)->base + _24917);
        }
        _24915 = NOVALUE;
        if (IS_ATOM_INT(_24918)) {
            {unsigned long tu;
                 tu = (unsigned long)2 & (unsigned long)_24918;
                 _24919 = MAKE_UINT(tu);
            }
        }
        else {
            _24919 = binary_op(AND_BITS, 2, _24918);
        }
        _24918 = NOVALUE;
        if (IS_ATOM_INT(_24919))
        _24914 = (_24919 != 0);
        else
        _24914 = DBL_PTR(_24919)->dbl != 0.0;
L13: 
        DeRef(_24912);
        _24912 = (_24914 != 0);
L12: 
        if (_24912 == 0)
        {
            _24912 = NOVALUE;
            goto L7; // [584] 1011
        }
        else{
            _24912 = NOVALUE;
        }

        /** 						gtok = tok*/
        Ref(_tok_47322);
        DeRef(_gtok_47323);
        _gtok_47323 = _tok_47322;

        /** 						dup_globals &= st_ptr*/
        Append(&_52dup_globals_47291, _52dup_globals_47291, _st_ptr_47319);

        /** 						in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0 --symbol_in_include_path( st_ptr, scanning_file, {} )*/
        _2 = (int)SEQ_PTR(_27include_matrix_10928);
        _24921 = (int)*(((s1_ptr)_2)->base + _scanning_file_47307);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _24922 = (int)*(((s1_ptr)_2)->base + _st_ptr_47319);
        _2 = (int)SEQ_PTR(_24922);
        if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
            _24923 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
        }
        else{
            _24923 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
        }
        _24922 = NOVALUE;
        _2 = (int)SEQ_PTR(_24921);
        if (!IS_ATOM_INT(_24923)){
            _24924 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24923)->dbl));
        }
        else{
            _24924 = (int)*(((s1_ptr)_2)->base + _24923);
        }
        _24921 = NOVALUE;
        if (IS_ATOM_INT(_24924)) {
            _24925 = (_24924 != 0);
        }
        else {
            _24925 = binary_op(NOTEQ, _24924, 0);
        }
        _24924 = NOVALUE;
        if (IS_SEQUENCE(_52in_include_path_47293) && IS_ATOM(_24925)) {
            Ref(_24925);
            Append(&_52in_include_path_47293, _52in_include_path_47293, _24925);
        }
        else if (IS_ATOM(_52in_include_path_47293) && IS_SEQUENCE(_24925)) {
        }
        else {
            Concat((object_ptr)&_52in_include_path_47293, _52in_include_path_47293, _24925);
        }
        DeRef(_24925);
        _24925 = NOVALUE;

        /** ifdef STDDEBUG then*/

        /** 					break*/
        goto L7; // [639] 1011

        /** 				case SC_LOCAL then*/
        case 5:

        /** 					if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _24927 = (int)*(((s1_ptr)_2)->base + _st_ptr_47319);
        _2 = (int)SEQ_PTR(_24927);
        if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
            _24928 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
        }
        else{
            _24928 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
        }
        _24927 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_47307, _24928)){
            _24928 = NOVALUE;
            goto L7; // [659] 1011
        }
        _24928 = NOVALUE;

        /** 						if BIND then*/
        if (_26BIND_11622 == 0)
        {
            goto L14; // [667] 676
        }
        else{
        }

        /** 							add_ref(tok)*/
        Ref(_tok_47322);
        _52add_ref(_tok_47322);
L14: 

        /** 						return tok*/
        DeRefDS(_word_47305);
        DeRef(_msg_47313);
        DeRef(_b_name_47314);
        DeRef(_gtok_47323);
        DeRef(_24864);
        _24864 = NOVALUE;
        DeRef(_24854);
        _24854 = NOVALUE;
        _24878 = NOVALUE;
        _24883 = NOVALUE;
        _24882 = NOVALUE;
        _24898 = NOVALUE;
        _24891 = NOVALUE;
        DeRef(_24905);
        _24905 = NOVALUE;
        DeRef(_24903);
        _24903 = NOVALUE;
        DeRef(_24913);
        _24913 = NOVALUE;
        _24909 = NOVALUE;
        DeRef(_24911);
        _24911 = NOVALUE;
        _24917 = NOVALUE;
        DeRef(_24919);
        _24919 = NOVALUE;
        _24923 = NOVALUE;
        return _tok_47322;

        /** 					break*/
        goto L7; // [685] 1011

        /** 				case else*/
        default:

        /** 					if BIND then*/
        if (_26BIND_11622 == 0)
        {
            goto L15; // [695] 704
        }
        else{
        }

        /** 						add_ref(tok)*/
        Ref(_tok_47322);
        _52add_ref(_tok_47322);
L15: 

        /** 					return tok -- keyword, private*/
        DeRefDS(_word_47305);
        DeRef(_msg_47313);
        DeRef(_b_name_47314);
        DeRef(_gtok_47323);
        DeRef(_24864);
        _24864 = NOVALUE;
        DeRef(_24854);
        _24854 = NOVALUE;
        _24878 = NOVALUE;
        _24883 = NOVALUE;
        _24882 = NOVALUE;
        _24898 = NOVALUE;
        _24891 = NOVALUE;
        DeRef(_24905);
        _24905 = NOVALUE;
        DeRef(_24903);
        _24903 = NOVALUE;
        DeRef(_24913);
        _24913 = NOVALUE;
        _24909 = NOVALUE;
        DeRef(_24911);
        _24911 = NOVALUE;
        _24917 = NOVALUE;
        DeRef(_24919);
        _24919 = NOVALUE;
        _24923 = NOVALUE;
        return _tok_47322;
    ;}    goto L7; // [711] 1011
L6: 

    /** 				scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_tok_47322);
    _24930 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_24930)){
        _24931 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24930)->dbl));
    }
    else{
        _24931 = (int)*(((s1_ptr)_2)->base + _24930);
    }
    _2 = (int)SEQ_PTR(_24931);
    _scope_47315 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_47315)){
        _scope_47315 = (long)DBL_PTR(_scope_47315)->dbl;
    }
    _24931 = NOVALUE;

    /** 				if not file_no then*/
    if (_file_no_47306 != 0)
    goto L16; // [738] 772

    /** 					if scope = SC_PREDEF then*/
    if (_scope_47315 != 7)
    goto L17; // [745] 1010

    /** 						if BIND then*/
    if (_26BIND_11622 == 0)
    {
        goto L18; // [753] 762
    }
    else{
    }

    /** 							add_ref( tok )*/
    Ref(_tok_47322);
    _52add_ref(_tok_47322);
L18: 

    /** 						return tok*/
    DeRefDS(_word_47305);
    DeRef(_msg_47313);
    DeRef(_b_name_47314);
    DeRef(_gtok_47323);
    DeRef(_24864);
    _24864 = NOVALUE;
    DeRef(_24854);
    _24854 = NOVALUE;
    _24878 = NOVALUE;
    _24883 = NOVALUE;
    _24882 = NOVALUE;
    _24898 = NOVALUE;
    _24891 = NOVALUE;
    DeRef(_24905);
    _24905 = NOVALUE;
    DeRef(_24903);
    _24903 = NOVALUE;
    DeRef(_24913);
    _24913 = NOVALUE;
    _24909 = NOVALUE;
    DeRef(_24911);
    _24911 = NOVALUE;
    _24930 = NOVALUE;
    _24917 = NOVALUE;
    DeRef(_24919);
    _24919 = NOVALUE;
    _24923 = NOVALUE;
    return _tok_47322;
    goto L17; // [769] 1010
L16: 

    /** 					integer tok_file = SymTab[tok[T_SYM]][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_tok_47322);
    _24935 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_24935)){
        _24936 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24935)->dbl));
    }
    else{
        _24936 = (int)*(((s1_ptr)_2)->base + _24935);
    }
    _2 = (int)SEQ_PTR(_24936);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _tok_file_47494 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _tok_file_47494 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    if (!IS_ATOM_INT(_tok_file_47494)){
        _tok_file_47494 = (long)DBL_PTR(_tok_file_47494)->dbl;
    }
    _24936 = NOVALUE;

    /** 					integer good = 0*/
    _good_47501 = 0;

    /** 					if scope = SC_PRIVATE or scope = SC_PREDEF then*/
    _24938 = (_scope_47315 == 3);
    if (_24938 != 0) {
        goto L19; // [807] 940
    }
    _24940 = (_scope_47315 == 7);
    if (_24940 == 0)
    {
        DeRef(_24940);
        _24940 = NOVALUE;
        goto L1A; // [818] 825
    }
    else{
        DeRef(_24940);
        _24940 = NOVALUE;
    }
    goto L19; // [822] 940
L1A: 

    /** 					elsif file_no = tok_file then*/
    if (_file_no_47306 != _tok_file_47494)
    goto L1B; // [827] 839

    /** 						good = 1*/
    _good_47501 = 1;
    goto L19; // [836] 940
L1B: 

    /** 						integer include_type = 0*/
    _include_type_47511 = 0;

    /** 						switch scope do*/
    _0 = _scope_47315;
    switch ( _0 ){ 

        /** 							case SC_GLOBAL then*/
        case 6:

        /** 								if Resolve_unincluded_globals then*/
        if (_52Resolve_unincluded_globals_47296 == 0)
        {
            goto L1C; // [859] 874
        }
        else{
        }

        /** 									include_type = ANY_INCLUDE*/
        _include_type_47511 = 7;
        goto L1D; // [871] 919
L1C: 

        /** 									include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_47511 = 6;
        goto L1D; // [884] 919

        /** 							case SC_PUBLIC then*/
        case 13:

        /** 								if tok_file != file_no then*/
        if (_tok_file_47494 == _file_no_47306)
        goto L1E; // [892] 908

        /** 									include_type = PUBLIC_INCLUDE*/
        _include_type_47511 = 4;
        goto L1F; // [905] 918
L1E: 

        /** 									include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_47511 = 6;
L1F: 
    ;}L1D: 

    /** 						good = and_bits( include_type, include_matrix[file_no][tok_file] )*/
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _24945 = (int)*(((s1_ptr)_2)->base + _file_no_47306);
    _2 = (int)SEQ_PTR(_24945);
    _24946 = (int)*(((s1_ptr)_2)->base + _tok_file_47494);
    _24945 = NOVALUE;
    if (IS_ATOM_INT(_24946)) {
        {unsigned long tu;
             tu = (unsigned long)_include_type_47511 & (unsigned long)_24946;
             _good_47501 = MAKE_UINT(tu);
        }
    }
    else {
        _good_47501 = binary_op(AND_BITS, _include_type_47511, _24946);
    }
    _24946 = NOVALUE;
    if (!IS_ATOM_INT(_good_47501)) {
        _1 = (long)(DBL_PTR(_good_47501)->dbl);
        DeRefDS(_good_47501);
        _good_47501 = _1;
    }
L19: 

    /** 					if good then*/
    if (_good_47501 == 0)
    {
        goto L20; // [942] 1007
    }
    else{
    }

    /** 						if file_no = tok_file then*/
    if (_file_no_47306 != _tok_file_47494)
    goto L21; // [947] 971

    /** 							if BIND then*/
    if (_26BIND_11622 == 0)
    {
        goto L22; // [955] 964
    }
    else{
    }

    /** 								add_ref(tok)*/
    Ref(_tok_47322);
    _52add_ref(_tok_47322);
L22: 

    /** 							return tok*/
    DeRefDS(_word_47305);
    DeRef(_msg_47313);
    DeRef(_b_name_47314);
    DeRef(_gtok_47323);
    DeRef(_24864);
    _24864 = NOVALUE;
    DeRef(_24854);
    _24854 = NOVALUE;
    _24878 = NOVALUE;
    _24883 = NOVALUE;
    _24882 = NOVALUE;
    _24898 = NOVALUE;
    _24891 = NOVALUE;
    DeRef(_24905);
    _24905 = NOVALUE;
    DeRef(_24903);
    _24903 = NOVALUE;
    DeRef(_24913);
    _24913 = NOVALUE;
    _24909 = NOVALUE;
    DeRef(_24911);
    _24911 = NOVALUE;
    _24930 = NOVALUE;
    _24917 = NOVALUE;
    DeRef(_24919);
    _24919 = NOVALUE;
    _24923 = NOVALUE;
    _24935 = NOVALUE;
    DeRef(_24938);
    _24938 = NOVALUE;
    return _tok_47322;
L21: 

    /** 						gtok = tok*/
    Ref(_tok_47322);
    DeRef(_gtok_47323);
    _gtok_47323 = _tok_47322;

    /** 						dup_globals &= st_ptr*/
    Append(&_52dup_globals_47291, _52dup_globals_47291, _st_ptr_47319);

    /** 						in_include_path &= include_matrix[scanning_file][tok_file] != 0*/
    _2 = (int)SEQ_PTR(_27include_matrix_10928);
    _24950 = (int)*(((s1_ptr)_2)->base + _scanning_file_47307);
    _2 = (int)SEQ_PTR(_24950);
    _24951 = (int)*(((s1_ptr)_2)->base + _tok_file_47494);
    _24950 = NOVALUE;
    if (IS_ATOM_INT(_24951)) {
        _24952 = (_24951 != 0);
    }
    else {
        _24952 = binary_op(NOTEQ, _24951, 0);
    }
    _24951 = NOVALUE;
    if (IS_SEQUENCE(_52in_include_path_47293) && IS_ATOM(_24952)) {
        Ref(_24952);
        Append(&_52in_include_path_47293, _52in_include_path_47293, _24952);
    }
    else if (IS_ATOM(_52in_include_path_47293) && IS_SEQUENCE(_24952)) {
    }
    else {
        Concat((object_ptr)&_52in_include_path_47293, _52in_include_path_47293, _24952);
    }
    DeRef(_24952);
    _24952 = NOVALUE;
L20: 
L17: 
L7: 
L4: 

    /** 		st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24954 = (int)*(((s1_ptr)_2)->base + _st_ptr_47319);
    _2 = (int)SEQ_PTR(_24954);
    _st_ptr_47319 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_st_ptr_47319)){
        _st_ptr_47319 = (long)DBL_PTR(_st_ptr_47319)->dbl;
    }
    _24954 = NOVALUE;

    /** 	end while*/
    goto L1; // [1030] 69
L2: 

    /** 	if length(dup_overrides) then*/
    if (IS_SEQUENCE(_52dup_overrides_47292)){
            _24956 = SEQ_PTR(_52dup_overrides_47292)->length;
    }
    else {
        _24956 = 1;
    }
    if (_24956 == 0)
    {
        _24956 = NOVALUE;
        goto L23; // [1040] 1093
    }
    else{
        _24956 = NOVALUE;
    }

    /** 		st_ptr = dup_overrides[1]*/
    _2 = (int)SEQ_PTR(_52dup_overrides_47292);
    _st_ptr_47319 = (int)*(((s1_ptr)_2)->base + 1);

    /** 		tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24958 = (int)*(((s1_ptr)_2)->base + _st_ptr_47319);
    _2 = (int)SEQ_PTR(_24958);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _24959 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _24959 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _24958 = NOVALUE;
    Ref(_24959);
    DeRef(_tok_47322);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24959;
    ((int *)_2)[2] = _st_ptr_47319;
    _tok_47322 = MAKE_SEQ(_1);
    _24959 = NOVALUE;

    /** 			if BIND then*/
    if (_26BIND_11622 == 0)
    {
        goto L24; // [1075] 1084
    }
    else{
    }

    /** 				add_ref(tok)*/
    RefDS(_tok_47322);
    _52add_ref(_tok_47322);
L24: 

    /** 			return tok*/
    DeRefDS(_word_47305);
    DeRef(_msg_47313);
    DeRef(_b_name_47314);
    DeRef(_gtok_47323);
    DeRef(_24864);
    _24864 = NOVALUE;
    DeRef(_24854);
    _24854 = NOVALUE;
    _24878 = NOVALUE;
    _24883 = NOVALUE;
    _24882 = NOVALUE;
    _24898 = NOVALUE;
    _24891 = NOVALUE;
    DeRef(_24905);
    _24905 = NOVALUE;
    DeRef(_24903);
    _24903 = NOVALUE;
    DeRef(_24913);
    _24913 = NOVALUE;
    _24909 = NOVALUE;
    DeRef(_24911);
    _24911 = NOVALUE;
    _24930 = NOVALUE;
    _24917 = NOVALUE;
    DeRef(_24919);
    _24919 = NOVALUE;
    _24923 = NOVALUE;
    _24935 = NOVALUE;
    DeRef(_24938);
    _24938 = NOVALUE;
    return _tok_47322;
    goto L25; // [1090] 1320
L23: 

    /** 	elsif st_builtin != 0 then*/
    if (_st_builtin_47320 == 0)
    goto L26; // [1095] 1319

    /** 		if length(dup_globals) and find(SymTab[st_builtin][S_NAME], builtin_warnings) = 0 then*/
    if (IS_SEQUENCE(_52dup_globals_47291)){
            _24962 = SEQ_PTR(_52dup_globals_47291)->length;
    }
    else {
        _24962 = 1;
    }
    if (_24962 == 0) {
        goto L27; // [1106] 1279
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24964 = (int)*(((s1_ptr)_2)->base + _st_builtin_47320);
    _2 = (int)SEQ_PTR(_24964);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _24965 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _24965 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _24964 = NOVALUE;
    _24966 = find_from(_24965, _52builtin_warnings_47295, 1);
    _24965 = NOVALUE;
    _24967 = (_24966 == 0);
    _24966 = NOVALUE;
    if (_24967 == 0)
    {
        DeRef(_24967);
        _24967 = NOVALUE;
        goto L27; // [1134] 1279
    }
    else{
        DeRef(_24967);
        _24967 = NOVALUE;
    }

    /** 			sequence msg_file */

    /** 			b_name = SymTab[st_builtin][S_NAME]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24968 = (int)*(((s1_ptr)_2)->base + _st_builtin_47320);
    DeRef(_b_name_47314);
    _2 = (int)SEQ_PTR(_24968);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _b_name_47314 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _b_name_47314 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    Ref(_b_name_47314);
    _24968 = NOVALUE;

    /** 			builtin_warnings = append(builtin_warnings, b_name)*/
    RefDS(_b_name_47314);
    Append(&_52builtin_warnings_47295, _52builtin_warnings_47295, _b_name_47314);

    /** 			if length(dup_globals) > 1 then*/
    if (IS_SEQUENCE(_52dup_globals_47291)){
            _24971 = SEQ_PTR(_52dup_globals_47291)->length;
    }
    else {
        _24971 = 1;
    }
    if (_24971 <= 1)
    goto L28; // [1170] 1184

    /** 				msg = "\n"*/
    RefDS(_22189);
    DeRef(_msg_47313);
    _msg_47313 = _22189;
    goto L29; // [1181] 1192
L28: 

    /** 				msg = ""*/
    RefDS(_22037);
    DeRef(_msg_47313);
    _msg_47313 = _22037;
L29: 

    /** 			for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_52dup_globals_47291)){
            _24973 = SEQ_PTR(_52dup_globals_47291)->length;
    }
    else {
        _24973 = 1;
    }
    {
        int _i_47578;
        _i_47578 = 1;
L2A: 
        if (_i_47578 > _24973){
            goto L2B; // [1199] 1255
        }

        /** 				msg_file = known_files[SymTab[dup_globals[i]][S_FILE_NO]]*/
        _2 = (int)SEQ_PTR(_52dup_globals_47291);
        _24974 = (int)*(((s1_ptr)_2)->base + _i_47578);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!IS_ATOM_INT(_24974)){
            _24975 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24974)->dbl));
        }
        else{
            _24975 = (int)*(((s1_ptr)_2)->base + _24974);
        }
        _2 = (int)SEQ_PTR(_24975);
        if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
            _24976 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
        }
        else{
            _24976 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
        }
        _24975 = NOVALUE;
        DeRef(_msg_file_47567);
        _2 = (int)SEQ_PTR(_27known_files_10922);
        if (!IS_ATOM_INT(_24976)){
            _msg_file_47567 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24976)->dbl));
        }
        else{
            _msg_file_47567 = (int)*(((s1_ptr)_2)->base + _24976);
        }
        Ref(_msg_file_47567);

        /** 				msg &= "    " & msg_file & "\n"*/
        {
            int concat_list[3];

            concat_list[0] = _22189;
            concat_list[1] = _msg_file_47567;
            concat_list[2] = _24978;
            Concat_N((object_ptr)&_24979, concat_list, 3);
        }
        Concat((object_ptr)&_msg_47313, _msg_47313, _24979);
        DeRefDS(_24979);
        _24979 = NOVALUE;

        /** 			end for*/
        _i_47578 = _i_47578 + 1;
        goto L2A; // [1250] 1206
L2B: 
        ;
    }

    /** 			Warning(234, builtin_chosen_warning_flag, {b_name, known_files[scanning_file], msg})*/
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _24981 = (int)*(((s1_ptr)_2)->base + _scanning_file_47307);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_b_name_47314);
    *((int *)(_2+4)) = _b_name_47314;
    Ref(_24981);
    *((int *)(_2+8)) = _24981;
    RefDS(_msg_47313);
    *((int *)(_2+12)) = _msg_47313;
    _24982 = MAKE_SEQ(_1);
    _24981 = NOVALUE;
    _43Warning(234, 8, _24982);
    _24982 = NOVALUE;
L27: 
    DeRef(_msg_file_47567);
    _msg_file_47567 = NOVALUE;

    /** 		tok = {SymTab[st_builtin][S_TOKEN], st_builtin}*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24983 = (int)*(((s1_ptr)_2)->base + _st_builtin_47320);
    _2 = (int)SEQ_PTR(_24983);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _24984 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _24984 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _24983 = NOVALUE;
    Ref(_24984);
    DeRef(_tok_47322);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24984;
    ((int *)_2)[2] = _st_builtin_47320;
    _tok_47322 = MAKE_SEQ(_1);
    _24984 = NOVALUE;

    /** 		if BIND then*/
    if (_26BIND_11622 == 0)
    {
        goto L2C; // [1303] 1312
    }
    else{
    }

    /** 			add_ref(tok)*/
    RefDS(_tok_47322);
    _52add_ref(_tok_47322);
L2C: 

    /** 		return tok*/
    DeRefDS(_word_47305);
    DeRef(_msg_47313);
    DeRef(_b_name_47314);
    DeRef(_gtok_47323);
    DeRef(_24864);
    _24864 = NOVALUE;
    DeRef(_24854);
    _24854 = NOVALUE;
    _24878 = NOVALUE;
    _24883 = NOVALUE;
    _24882 = NOVALUE;
    _24898 = NOVALUE;
    _24891 = NOVALUE;
    DeRef(_24905);
    _24905 = NOVALUE;
    DeRef(_24903);
    _24903 = NOVALUE;
    DeRef(_24913);
    _24913 = NOVALUE;
    _24909 = NOVALUE;
    DeRef(_24911);
    _24911 = NOVALUE;
    _24930 = NOVALUE;
    _24917 = NOVALUE;
    DeRef(_24919);
    _24919 = NOVALUE;
    _24923 = NOVALUE;
    _24935 = NOVALUE;
    DeRef(_24938);
    _24938 = NOVALUE;
    _24974 = NOVALUE;
    _24976 = NOVALUE;
    return _tok_47322;
L26: 
L25: 

    /** ifdef STDDEBUG then*/

    /** 	if length(dup_globals) > 1 and find( 1, in_include_path ) then*/
    if (IS_SEQUENCE(_52dup_globals_47291)){
            _24986 = SEQ_PTR(_52dup_globals_47291)->length;
    }
    else {
        _24986 = 1;
    }
    _24987 = (_24986 > 1);
    _24986 = NOVALUE;
    if (_24987 == 0) {
        goto L2D; // [1333] 1452
    }
    _24989 = find_from(1, _52in_include_path_47293, 1);
    if (_24989 == 0)
    {
        _24989 = NOVALUE;
        goto L2D; // [1345] 1452
    }
    else{
        _24989 = NOVALUE;
    }

    /** 		ix = 1*/
    _ix_47317 = 1;

    /** 		while ix <= length(dup_globals) do*/
L2E: 
    if (IS_SEQUENCE(_52dup_globals_47291)){
            _24990 = SEQ_PTR(_52dup_globals_47291)->length;
    }
    else {
        _24990 = 1;
    }
    if (_ix_47317 > _24990)
    goto L2F; // [1363] 1411

    /** 			if in_include_path[ix] then*/
    _2 = (int)SEQ_PTR(_52in_include_path_47293);
    _24992 = (int)*(((s1_ptr)_2)->base + _ix_47317);
    if (_24992 == 0) {
        _24992 = NOVALUE;
        goto L30; // [1375] 1387
    }
    else {
        if (!IS_ATOM_INT(_24992) && DBL_PTR(_24992)->dbl == 0.0){
            _24992 = NOVALUE;
            goto L30; // [1375] 1387
        }
        _24992 = NOVALUE;
    }
    _24992 = NOVALUE;

    /** 				ix += 1*/
    _ix_47317 = _ix_47317 + 1;
    goto L2E; // [1384] 1358
L30: 

    /** 				dup_globals     = remove( dup_globals, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_52dup_globals_47291);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_47317)) ? _ix_47317 : (long)(DBL_PTR(_ix_47317)->dbl);
        int stop = (IS_ATOM_INT(_ix_47317)) ? _ix_47317 : (long)(DBL_PTR(_ix_47317)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_52dup_globals_47291), start, &_52dup_globals_47291 );
            }
            else Tail(SEQ_PTR(_52dup_globals_47291), stop+1, &_52dup_globals_47291);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_52dup_globals_47291), start, &_52dup_globals_47291);
        }
        else {
            assign_slice_seq = &assign_space;
            _52dup_globals_47291 = Remove_elements(start, stop, (SEQ_PTR(_52dup_globals_47291)->ref == 1));
        }
    }

    /** 				in_include_path = remove( in_include_path, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_52in_include_path_47293);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_47317)) ? _ix_47317 : (long)(DBL_PTR(_ix_47317)->dbl);
        int stop = (IS_ATOM_INT(_ix_47317)) ? _ix_47317 : (long)(DBL_PTR(_ix_47317)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_52in_include_path_47293), start, &_52in_include_path_47293 );
            }
            else Tail(SEQ_PTR(_52in_include_path_47293), stop+1, &_52in_include_path_47293);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_52in_include_path_47293), start, &_52in_include_path_47293);
        }
        else {
            assign_slice_seq = &assign_space;
            _52in_include_path_47293 = Remove_elements(start, stop, (SEQ_PTR(_52in_include_path_47293)->ref == 1));
        }
    }

    /** 		end while*/
    goto L2E; // [1408] 1358
L2F: 

    /** 		if length(dup_globals) = 1 then*/
    if (IS_SEQUENCE(_52dup_globals_47291)){
            _24996 = SEQ_PTR(_52dup_globals_47291)->length;
    }
    else {
        _24996 = 1;
    }
    if (_24996 != 1)
    goto L31; // [1418] 1451

    /** 				st_ptr = dup_globals[1]*/
    _2 = (int)SEQ_PTR(_52dup_globals_47291);
    _st_ptr_47319 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_st_ptr_47319)){
        _st_ptr_47319 = (long)DBL_PTR(_st_ptr_47319)->dbl;
    }

    /** 				gtok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _24999 = (int)*(((s1_ptr)_2)->base + _st_ptr_47319);
    _2 = (int)SEQ_PTR(_24999);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _25000 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _25000 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _24999 = NOVALUE;
    Ref(_25000);
    DeRef(_gtok_47323);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _25000;
    ((int *)_2)[2] = _st_ptr_47319;
    _gtok_47323 = MAKE_SEQ(_1);
    _25000 = NOVALUE;
L31: 
L2D: 

    /** ifdef STDDEBUG then*/

    /** 	if length(dup_globals) = 1 and st_builtin = 0 then*/
    if (IS_SEQUENCE(_52dup_globals_47291)){
            _25002 = SEQ_PTR(_52dup_globals_47291)->length;
    }
    else {
        _25002 = 1;
    }
    _25003 = (_25002 == 1);
    _25002 = NOVALUE;
    if (_25003 == 0) {
        goto L32; // [1465] 1642
    }
    _25005 = (_st_builtin_47320 == 0);
    if (_25005 == 0)
    {
        DeRef(_25005);
        _25005 = NOVALUE;
        goto L32; // [1474] 1642
    }
    else{
        DeRef(_25005);
        _25005 = NOVALUE;
    }

    /** 		if BIND then*/
    if (_26BIND_11622 == 0)
    {
        goto L33; // [1481] 1492
    }
    else{
    }

    /** 			add_ref(gtok)*/
    Ref(_gtok_47323);
    _52add_ref(_gtok_47323);
L33: 

    /** 		if not in_include_path[1] and*/
    _2 = (int)SEQ_PTR(_52in_include_path_47293);
    _25006 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25006)) {
        _25007 = (_25006 == 0);
    }
    else {
        _25007 = unary_op(NOT, _25006);
    }
    _25006 = NOVALUE;
    if (IS_ATOM_INT(_25007)) {
        if (_25007 == 0) {
            goto L34; // [1503] 1635
        }
    }
    else {
        if (DBL_PTR(_25007)->dbl == 0.0) {
            goto L34; // [1503] 1635
        }
    }
    _2 = (int)SEQ_PTR(_gtok_47323);
    _25009 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_25009)){
        _25010 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_25009)->dbl));
    }
    else{
        _25010 = (int)*(((s1_ptr)_2)->base + _25009);
    }
    _2 = (int)SEQ_PTR(_25010);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _25011 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _25011 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _25010 = NOVALUE;
    Ref(_25011);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _scanning_file_47307;
    ((int *)_2)[2] = _25011;
    _25012 = MAKE_SEQ(_1);
    _25011 = NOVALUE;
    _25013 = find_from(_25012, _52include_warnings_47294, 1);
    DeRefDS(_25012);
    _25012 = NOVALUE;
    _25014 = (_25013 == 0);
    _25013 = NOVALUE;
    if (_25014 == 0)
    {
        DeRef(_25014);
        _25014 = NOVALUE;
        goto L34; // [1542] 1635
    }
    else{
        DeRef(_25014);
        _25014 = NOVALUE;
    }

    /** 			include_warnings = prepend( include_warnings,*/
    _2 = (int)SEQ_PTR(_gtok_47323);
    _25015 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_25015)){
        _25016 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_25015)->dbl));
    }
    else{
        _25016 = (int)*(((s1_ptr)_2)->base + _25015);
    }
    _2 = (int)SEQ_PTR(_25016);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _25017 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _25017 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _25016 = NOVALUE;
    Ref(_25017);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _scanning_file_47307;
    ((int *)_2)[2] = _25017;
    _25018 = MAKE_SEQ(_1);
    _25017 = NOVALUE;
    RefDS(_25018);
    Prepend(&_52include_warnings_47294, _52include_warnings_47294, _25018);
    DeRefDS(_25018);
    _25018 = NOVALUE;

    /** ifdef STDDEBUG then*/

    /** 				symbol_resolution_warning = GetMsgText(233,0,*/
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _25020 = (int)*(((s1_ptr)_2)->base + _scanning_file_47307);
    Ref(_25020);
    _25021 = _52name_ext(_25020);
    _25020 = NOVALUE;
    _2 = (int)SEQ_PTR(_gtok_47323);
    _25022 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_25022)){
        _25023 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_25022)->dbl));
    }
    else{
        _25023 = (int)*(((s1_ptr)_2)->base + _25022);
    }
    _2 = (int)SEQ_PTR(_25023);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _25024 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _25024 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _25023 = NOVALUE;
    _2 = (int)SEQ_PTR(_27known_files_10922);
    if (!IS_ATOM_INT(_25024)){
        _25025 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_25024)->dbl));
    }
    else{
        _25025 = (int)*(((s1_ptr)_2)->base + _25024);
    }
    Ref(_25025);
    _25026 = _52name_ext(_25025);
    _25025 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _25021;
    *((int *)(_2+8)) = _26line_number_11983;
    RefDS(_word_47305);
    *((int *)(_2+12)) = _word_47305;
    *((int *)(_2+16)) = _25026;
    _25027 = MAKE_SEQ(_1);
    _25026 = NOVALUE;
    _25021 = NOVALUE;
    _0 = _44GetMsgText(233, 0, _25027);
    DeRef(_26symbol_resolution_warning_12084);
    _26symbol_resolution_warning_12084 = _0;
    _25027 = NOVALUE;
L34: 

    /** 		return gtok*/
    DeRefDS(_word_47305);
    DeRef(_msg_47313);
    DeRef(_b_name_47314);
    DeRef(_tok_47322);
    DeRef(_24911);
    _24911 = NOVALUE;
    _24882 = NOVALUE;
    DeRef(_24913);
    _24913 = NOVALUE;
    _24891 = NOVALUE;
    DeRef(_24864);
    _24864 = NOVALUE;
    _25022 = NOVALUE;
    _24883 = NOVALUE;
    _24935 = NOVALUE;
    _24923 = NOVALUE;
    _24898 = NOVALUE;
    DeRef(_25007);
    _25007 = NOVALUE;
    DeRef(_24938);
    _24938 = NOVALUE;
    _25024 = NOVALUE;
    _24917 = NOVALUE;
    _24976 = NOVALUE;
    _25015 = NOVALUE;
    DeRef(_24854);
    _24854 = NOVALUE;
    _24878 = NOVALUE;
    DeRef(_24905);
    _24905 = NOVALUE;
    _24909 = NOVALUE;
    DeRef(_24903);
    _24903 = NOVALUE;
    _24974 = NOVALUE;
    DeRef(_24987);
    _24987 = NOVALUE;
    _24930 = NOVALUE;
    DeRef(_25003);
    _25003 = NOVALUE;
    _25009 = NOVALUE;
    DeRef(_24919);
    _24919 = NOVALUE;
    return _gtok_47323;
L32: 

    /** 	if length(dup_globals) = 0 then*/
    if (IS_SEQUENCE(_52dup_globals_47291)){
            _25029 = SEQ_PTR(_52dup_globals_47291)->length;
    }
    else {
        _25029 = 1;
    }
    if (_25029 != 0)
    goto L35; // [1649] 1723

    /** 		defined = SC_UNDEFINED*/
    _defined_47316 = 9;

    /** 		if fwd_line_number then*/
    if (_26fwd_line_number_11984 == 0)
    {
        goto L36; // [1666] 1695
    }
    else{
    }

    /** 			last_ForwardLine     = ForwardLine*/
    Ref(_43ForwardLine_48558);
    DeRef(_43last_ForwardLine_48560);
    _43last_ForwardLine_48560 = _43ForwardLine_48558;

    /** 			last_forward_bp      = forward_bp*/
    _43last_forward_bp_48564 = _43forward_bp_48562;

    /** 			last_fwd_line_number = fwd_line_number*/
    _26last_fwd_line_number_11986 = _26fwd_line_number_11984;
L36: 

    /** 		ForwardLine = ThisLine*/
    Ref(_43ThisLine_48557);
    DeRef(_43ForwardLine_48558);
    _43ForwardLine_48558 = _43ThisLine_48557;

    /** 		forward_bp = bp*/
    _43forward_bp_48562 = _43bp_48561;

    /** 		fwd_line_number = line_number*/
    _26fwd_line_number_11984 = _26line_number_11983;
    goto L37; // [1720] 1766
L35: 

    /** 	elsif length(dup_globals) then*/
    if (IS_SEQUENCE(_52dup_globals_47291)){
            _25031 = SEQ_PTR(_52dup_globals_47291)->length;
    }
    else {
        _25031 = 1;
    }
    if (_25031 == 0)
    {
        _25031 = NOVALUE;
        goto L38; // [1730] 1745
    }
    else{
        _25031 = NOVALUE;
    }

    /** 		defined = SC_MULTIPLY_DEFINED*/
    _defined_47316 = 10;
    goto L37; // [1742] 1766
L38: 

    /** 	elsif length(dup_overrides) then*/
    if (IS_SEQUENCE(_52dup_overrides_47292)){
            _25032 = SEQ_PTR(_52dup_overrides_47292)->length;
    }
    else {
        _25032 = 1;
    }
    if (_25032 == 0)
    {
        _25032 = NOVALUE;
        goto L39; // [1752] 1765
    }
    else{
        _25032 = NOVALUE;
    }

    /** 		defined = SC_OVERRIDE*/
    _defined_47316 = 12;
L39: 
L37: 

    /** 	if No_new_entry then*/
    if (_52No_new_entry_47302 == 0)
    {
        goto L3A; // [1770] 1793
    }
    else{
    }

    /** 		return {IGNORED,word,defined,dup_globals}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 509;
    RefDS(_word_47305);
    *((int *)(_2+8)) = _word_47305;
    *((int *)(_2+12)) = _defined_47316;
    RefDS(_52dup_globals_47291);
    *((int *)(_2+16)) = _52dup_globals_47291;
    _25033 = MAKE_SEQ(_1);
    DeRefDS(_word_47305);
    DeRef(_msg_47313);
    DeRef(_b_name_47314);
    DeRef(_tok_47322);
    DeRef(_gtok_47323);
    DeRef(_24911);
    _24911 = NOVALUE;
    _24882 = NOVALUE;
    DeRef(_24913);
    _24913 = NOVALUE;
    _24891 = NOVALUE;
    DeRef(_24864);
    _24864 = NOVALUE;
    _25022 = NOVALUE;
    _24883 = NOVALUE;
    _24935 = NOVALUE;
    _24923 = NOVALUE;
    _24898 = NOVALUE;
    DeRef(_25007);
    _25007 = NOVALUE;
    DeRef(_24938);
    _24938 = NOVALUE;
    _25024 = NOVALUE;
    _24917 = NOVALUE;
    _24976 = NOVALUE;
    _25015 = NOVALUE;
    DeRef(_24854);
    _24854 = NOVALUE;
    _24878 = NOVALUE;
    DeRef(_24905);
    _24905 = NOVALUE;
    _24909 = NOVALUE;
    DeRef(_24903);
    _24903 = NOVALUE;
    _24974 = NOVALUE;
    DeRef(_24987);
    _24987 = NOVALUE;
    _24930 = NOVALUE;
    DeRef(_25003);
    _25003 = NOVALUE;
    _25009 = NOVALUE;
    DeRef(_24919);
    _24919 = NOVALUE;
    return _25033;
L3A: 

    /** 	tok = {VARIABLE, NewEntry(word, 0, defined,*/
    _2 = (int)SEQ_PTR(_52buckets_46126);
    _25034 = (int)*(((s1_ptr)_2)->base + _hashval_47311);
    RefDS(_word_47305);
    Ref(_25034);
    _25035 = _52NewEntry(_word_47305, 0, _defined_47316, -100, _hashval_47311, _25034, 0);
    _25034 = NOVALUE;
    DeRef(_tok_47322);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _25035;
    _tok_47322 = MAKE_SEQ(_1);
    _25035 = NOVALUE;

    /** 	buckets[hashval] = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_47322);
    _25037 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_25037);
    _2 = (int)SEQ_PTR(_52buckets_46126);
    _2 = (int)(((s1_ptr)_2)->base + _hashval_47311);
    _1 = *(int *)_2;
    *(int *)_2 = _25037;
    if( _1 != _25037 ){
        DeRef(_1);
    }
    _25037 = NOVALUE;

    /** 	if file_no != -1 then*/
    if (_file_no_47306 == -1)
    goto L3B; // [1837] 1863

    /** 		SymTab[tok[T_SYM]][S_FILE_NO] = file_no*/
    _2 = (int)SEQ_PTR(_tok_47322);
    _25039 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_25039))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_25039)->dbl));
    else
    _3 = (int)(_25039 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_FILE_NO_11650))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    _1 = *(int *)_2;
    *(int *)_2 = _file_no_47306;
    DeRef(_1);
    _25040 = NOVALUE;
L3B: 

    /** 	return tok  -- no ref on newly declared symbol*/
    DeRefDS(_word_47305);
    DeRef(_msg_47313);
    DeRef(_b_name_47314);
    DeRef(_gtok_47323);
    DeRef(_24911);
    _24911 = NOVALUE;
    _24882 = NOVALUE;
    DeRef(_24913);
    _24913 = NOVALUE;
    _24891 = NOVALUE;
    DeRef(_24864);
    _24864 = NOVALUE;
    _25022 = NOVALUE;
    _24883 = NOVALUE;
    _24935 = NOVALUE;
    _24923 = NOVALUE;
    DeRef(_25033);
    _25033 = NOVALUE;
    _24898 = NOVALUE;
    _25039 = NOVALUE;
    DeRef(_25007);
    _25007 = NOVALUE;
    DeRef(_24938);
    _24938 = NOVALUE;
    _25024 = NOVALUE;
    _24917 = NOVALUE;
    _24976 = NOVALUE;
    _25015 = NOVALUE;
    DeRef(_24854);
    _24854 = NOVALUE;
    _24878 = NOVALUE;
    DeRef(_24905);
    _24905 = NOVALUE;
    _24909 = NOVALUE;
    DeRef(_24903);
    _24903 = NOVALUE;
    _24974 = NOVALUE;
    DeRef(_24987);
    _24987 = NOVALUE;
    _24930 = NOVALUE;
    DeRef(_25003);
    _25003 = NOVALUE;
    _25009 = NOVALUE;
    DeRef(_24919);
    _24919 = NOVALUE;
    return _tok_47322;
    ;
}


void _52Hide(int _s_47715)
{
    int _prev_47717 = NOVALUE;
    int _p_47718 = NOVALUE;
    int _25060 = NOVALUE;
    int _25059 = NOVALUE;
    int _25058 = NOVALUE;
    int _25056 = NOVALUE;
    int _25055 = NOVALUE;
    int _25054 = NOVALUE;
    int _25053 = NOVALUE;
    int _25052 = NOVALUE;
    int _25048 = NOVALUE;
    int _25047 = NOVALUE;
    int _25046 = NOVALUE;
    int _25045 = NOVALUE;
    int _25043 = NOVALUE;
    int _25042 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_47715)) {
        _1 = (long)(DBL_PTR(_s_47715)->dbl);
        DeRefDS(_s_47715);
        _s_47715 = _1;
    }

    /** 	p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25042 = (int)*(((s1_ptr)_2)->base + _s_47715);
    _2 = (int)SEQ_PTR(_25042);
    _25043 = (int)*(((s1_ptr)_2)->base + 11);
    _25042 = NOVALUE;
    _2 = (int)SEQ_PTR(_52buckets_46126);
    if (!IS_ATOM_INT(_25043)){
        _p_47718 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_25043)->dbl));
    }
    else{
        _p_47718 = (int)*(((s1_ptr)_2)->base + _25043);
    }
    if (!IS_ATOM_INT(_p_47718)){
        _p_47718 = (long)DBL_PTR(_p_47718)->dbl;
    }

    /** 	prev = 0*/
    _prev_47717 = 0;

    /** 	while p != s and p != 0 do*/
L1: 
    _25045 = (_p_47718 != _s_47715);
    if (_25045 == 0) {
        goto L2; // [41] 81
    }
    _25047 = (_p_47718 != 0);
    if (_25047 == 0)
    {
        DeRef(_25047);
        _25047 = NOVALUE;
        goto L2; // [50] 81
    }
    else{
        DeRef(_25047);
        _25047 = NOVALUE;
    }

    /** 		prev = p*/
    _prev_47717 = _p_47718;

    /** 		p = SymTab[p][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25048 = (int)*(((s1_ptr)_2)->base + _p_47718);
    _2 = (int)SEQ_PTR(_25048);
    _p_47718 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_p_47718)){
        _p_47718 = (long)DBL_PTR(_p_47718)->dbl;
    }
    _25048 = NOVALUE;

    /** 	end while*/
    goto L1; // [78] 37
L2: 

    /** 	if p = 0 then*/
    if (_p_47718 != 0)
    goto L3; // [83] 93

    /** 		return -- already hidden*/
    _25043 = NOVALUE;
    DeRef(_25045);
    _25045 = NOVALUE;
    return;
L3: 

    /** 	if prev = 0 then*/
    if (_prev_47717 != 0)
    goto L4; // [95] 134

    /** 		buckets[SymTab[s][S_HASHVAL]] = SymTab[s][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25052 = (int)*(((s1_ptr)_2)->base + _s_47715);
    _2 = (int)SEQ_PTR(_25052);
    _25053 = (int)*(((s1_ptr)_2)->base + 11);
    _25052 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25054 = (int)*(((s1_ptr)_2)->base + _s_47715);
    _2 = (int)SEQ_PTR(_25054);
    _25055 = (int)*(((s1_ptr)_2)->base + 9);
    _25054 = NOVALUE;
    Ref(_25055);
    _2 = (int)SEQ_PTR(_52buckets_46126);
    if (!IS_ATOM_INT(_25053))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_25053)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _25053);
    _1 = *(int *)_2;
    *(int *)_2 = _25055;
    if( _1 != _25055 ){
        DeRef(_1);
    }
    _25055 = NOVALUE;
    goto L5; // [131] 162
L4: 

    /** 		SymTab[prev][S_SAMEHASH] = SymTab[s][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_prev_47717 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25058 = (int)*(((s1_ptr)_2)->base + _s_47715);
    _2 = (int)SEQ_PTR(_25058);
    _25059 = (int)*(((s1_ptr)_2)->base + 9);
    _25058 = NOVALUE;
    Ref(_25059);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _25059;
    if( _1 != _25059 ){
        DeRef(_1);
    }
    _25059 = NOVALUE;
    _25056 = NOVALUE;
L5: 

    /** 	SymTab[s][S_SAMEHASH] = 0*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_47715 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _25060 = NOVALUE;

    /** end procedure*/
    _25043 = NOVALUE;
    DeRef(_25045);
    _25045 = NOVALUE;
    _25053 = NOVALUE;
    return;
    ;
}


void _52Show(int _s_47760)
{
    int _p_47762 = NOVALUE;
    int _25072 = NOVALUE;
    int _25071 = NOVALUE;
    int _25069 = NOVALUE;
    int _25068 = NOVALUE;
    int _25066 = NOVALUE;
    int _25065 = NOVALUE;
    int _25063 = NOVALUE;
    int _25062 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_47760)) {
        _1 = (long)(DBL_PTR(_s_47760)->dbl);
        DeRefDS(_s_47760);
        _s_47760 = _1;
    }

    /** 	p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25062 = (int)*(((s1_ptr)_2)->base + _s_47760);
    _2 = (int)SEQ_PTR(_25062);
    _25063 = (int)*(((s1_ptr)_2)->base + 11);
    _25062 = NOVALUE;
    _2 = (int)SEQ_PTR(_52buckets_46126);
    if (!IS_ATOM_INT(_25063)){
        _p_47762 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_25063)->dbl));
    }
    else{
        _p_47762 = (int)*(((s1_ptr)_2)->base + _25063);
    }
    if (!IS_ATOM_INT(_p_47762)){
        _p_47762 = (long)DBL_PTR(_p_47762)->dbl;
    }

    /** 	if SymTab[s][S_SAMEHASH] or p = s then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25065 = (int)*(((s1_ptr)_2)->base + _s_47760);
    _2 = (int)SEQ_PTR(_25065);
    _25066 = (int)*(((s1_ptr)_2)->base + 9);
    _25065 = NOVALUE;
    if (IS_ATOM_INT(_25066)) {
        if (_25066 != 0) {
            goto L1; // [39] 52
        }
    }
    else {
        if (DBL_PTR(_25066)->dbl != 0.0) {
            goto L1; // [39] 52
        }
    }
    _25068 = (_p_47762 == _s_47760);
    if (_25068 == 0)
    {
        DeRef(_25068);
        _25068 = NOVALUE;
        goto L2; // [48] 58
    }
    else{
        DeRef(_25068);
        _25068 = NOVALUE;
    }
L1: 

    /** 		return*/
    _25063 = NOVALUE;
    _25066 = NOVALUE;
    return;
L2: 

    /** 	SymTab[s][S_SAMEHASH] = p*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_47760 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _p_47762;
    DeRef(_1);
    _25069 = NOVALUE;

    /** 	buckets[SymTab[s][S_HASHVAL]] = s*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25071 = (int)*(((s1_ptr)_2)->base + _s_47760);
    _2 = (int)SEQ_PTR(_25071);
    _25072 = (int)*(((s1_ptr)_2)->base + 11);
    _25071 = NOVALUE;
    _2 = (int)SEQ_PTR(_52buckets_46126);
    if (!IS_ATOM_INT(_25072))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_25072)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _25072);
    _1 = *(int *)_2;
    *(int *)_2 = _s_47760;
    DeRef(_1);

    /** end procedure*/
    _25063 = NOVALUE;
    _25066 = NOVALUE;
    _25072 = NOVALUE;
    return;
    ;
}


void _52hide_params(int _s_47786)
{
    int _param_47788 = NOVALUE;
    int _25075 = NOVALUE;
    int _25074 = NOVALUE;
    int _25073 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_47786)) {
        _1 = (long)(DBL_PTR(_s_47786)->dbl);
        DeRefDS(_s_47786);
        _s_47786 = _1;
    }

    /** 	symtab_index param = s*/
    _param_47788 = _s_47786;

    /** 	for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25073 = (int)*(((s1_ptr)_2)->base + _s_47786);
    _2 = (int)SEQ_PTR(_25073);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _25074 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _25074 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _25073 = NOVALUE;
    {
        int _i_47790;
        _i_47790 = 1;
L1: 
        if (binary_op_a(GREATER, _i_47790, _25074)){
            goto L2; // [24] 59
        }

        /** 		param = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _25075 = (int)*(((s1_ptr)_2)->base + _s_47786);
        _2 = (int)SEQ_PTR(_25075);
        _param_47788 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_47788)){
            _param_47788 = (long)DBL_PTR(_param_47788)->dbl;
        }
        _25075 = NOVALUE;

        /** 		Hide( param )*/
        _52Hide(_param_47788);

        /** 	end for*/
        _0 = _i_47790;
        if (IS_ATOM_INT(_i_47790)) {
            _i_47790 = _i_47790 + 1;
            if ((long)((unsigned long)_i_47790 +(unsigned long) HIGH_BITS) >= 0){
                _i_47790 = NewDouble((double)_i_47790);
            }
        }
        else {
            _i_47790 = binary_op_a(PLUS, _i_47790, 1);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_47790);
    }

    /** end procedure*/
    _25074 = NOVALUE;
    return;
    ;
}


void _52show_params(int _s_47802)
{
    int _param_47804 = NOVALUE;
    int _25079 = NOVALUE;
    int _25078 = NOVALUE;
    int _25077 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_47802)) {
        _1 = (long)(DBL_PTR(_s_47802)->dbl);
        DeRefDS(_s_47802);
        _s_47802 = _1;
    }

    /** 	symtab_index param = s*/
    _param_47804 = _s_47802;

    /** 	for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25077 = (int)*(((s1_ptr)_2)->base + _s_47802);
    _2 = (int)SEQ_PTR(_25077);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _25078 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _25078 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _25077 = NOVALUE;
    {
        int _i_47806;
        _i_47806 = 1;
L1: 
        if (binary_op_a(GREATER, _i_47806, _25078)){
            goto L2; // [24] 59
        }

        /** 		param = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _25079 = (int)*(((s1_ptr)_2)->base + _s_47802);
        _2 = (int)SEQ_PTR(_25079);
        _param_47804 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_47804)){
            _param_47804 = (long)DBL_PTR(_param_47804)->dbl;
        }
        _25079 = NOVALUE;

        /** 		Show( param )*/
        _52Show(_param_47804);

        /** 	end for*/
        _0 = _i_47806;
        if (IS_ATOM_INT(_i_47806)) {
            _i_47806 = _i_47806 + 1;
            if ((long)((unsigned long)_i_47806 +(unsigned long) HIGH_BITS) >= 0){
                _i_47806 = NewDouble((double)_i_47806);
            }
        }
        else {
            _i_47806 = binary_op_a(PLUS, _i_47806, 1);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_47806);
    }

    /** end procedure*/
    _25078 = NOVALUE;
    return;
    ;
}


void _52LintCheck(int _s_47818)
{
    int _warn_level_47819 = NOVALUE;
    int _file_47820 = NOVALUE;
    int _vscope_47821 = NOVALUE;
    int _vname_47822 = NOVALUE;
    int _vusage_47823 = NOVALUE;
    int _25140 = NOVALUE;
    int _25139 = NOVALUE;
    int _25138 = NOVALUE;
    int _25137 = NOVALUE;
    int _25136 = NOVALUE;
    int _25135 = NOVALUE;
    int _25133 = NOVALUE;
    int _25132 = NOVALUE;
    int _25131 = NOVALUE;
    int _25130 = NOVALUE;
    int _25129 = NOVALUE;
    int _25128 = NOVALUE;
    int _25125 = NOVALUE;
    int _25124 = NOVALUE;
    int _25123 = NOVALUE;
    int _25122 = NOVALUE;
    int _25121 = NOVALUE;
    int _25120 = NOVALUE;
    int _25118 = NOVALUE;
    int _25116 = NOVALUE;
    int _25115 = NOVALUE;
    int _25113 = NOVALUE;
    int _25112 = NOVALUE;
    int _25110 = NOVALUE;
    int _25109 = NOVALUE;
    int _25108 = NOVALUE;
    int _25107 = NOVALUE;
    int _25105 = NOVALUE;
    int _25104 = NOVALUE;
    int _25100 = NOVALUE;
    int _25097 = NOVALUE;
    int _25096 = NOVALUE;
    int _25095 = NOVALUE;
    int _25094 = NOVALUE;
    int _25091 = NOVALUE;
    int _25090 = NOVALUE;
    int _25085 = NOVALUE;
    int _25083 = NOVALUE;
    int _25081 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_47818)) {
        _1 = (long)(DBL_PTR(_s_47818)->dbl);
        DeRefDS(_s_47818);
        _s_47818 = _1;
    }

    /** 	vusage = SymTab[s][S_USAGE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25081 = (int)*(((s1_ptr)_2)->base + _s_47818);
    _2 = (int)SEQ_PTR(_25081);
    _vusage_47823 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_vusage_47823)){
        _vusage_47823 = (long)DBL_PTR(_vusage_47823)->dbl;
    }
    _25081 = NOVALUE;

    /** 	vscope = SymTab[s][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25083 = (int)*(((s1_ptr)_2)->base + _s_47818);
    _2 = (int)SEQ_PTR(_25083);
    _vscope_47821 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_vscope_47821)){
        _vscope_47821 = (long)DBL_PTR(_vscope_47821)->dbl;
    }
    _25083 = NOVALUE;

    /** 	vname = SymTab[s][S_NAME]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25085 = (int)*(((s1_ptr)_2)->base + _s_47818);
    DeRef(_vname_47822);
    _2 = (int)SEQ_PTR(_25085);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _vname_47822 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _vname_47822 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    Ref(_vname_47822);
    _25085 = NOVALUE;

    /** 	switch vusage do*/
    _0 = _vusage_47823;
    switch ( _0 ){ 

        /** 		case U_UNUSED then*/
        case 0:

        /** 			warn_level = 1*/
        _warn_level_47819 = 1;
        goto L1; // [67] 193

        /** 		case U_WRITTEN then -- Set but never read*/
        case 2:

        /** 			warn_level = 2*/
        _warn_level_47819 = 2;

        /** 			if vscope > SC_LOCAL then*/
        if (_vscope_47821 <= 5)
        goto L2; // [82] 94

        /** 				warn_level = 0 */
        _warn_level_47819 = 0;
        goto L1; // [91] 193
L2: 

        /** 			elsif SymTab[s][S_MODE] = M_CONSTANT then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _25090 = (int)*(((s1_ptr)_2)->base + _s_47818);
        _2 = (int)SEQ_PTR(_25090);
        _25091 = (int)*(((s1_ptr)_2)->base + 3);
        _25090 = NOVALUE;
        if (binary_op_a(NOTEQ, _25091, 2)){
            _25091 = NOVALUE;
            goto L1; // [110] 193
        }
        _25091 = NOVALUE;

        /** 				if not Strict_is_on then*/
        if (_26Strict_is_on_12048 != 0)
        goto L1; // [118] 193

        /** 					warn_level = 0 */
        _warn_level_47819 = 0;
        goto L1; // [129] 193

        /** 		case U_READ then -- Read but never set*/
        case 1:

        /** 			if SymTab[s][S_VARNUM] >= SymTab[CurrentSub][S_NUM_ARGS] then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _25094 = (int)*(((s1_ptr)_2)->base + _s_47818);
        _2 = (int)SEQ_PTR(_25094);
        _25095 = (int)*(((s1_ptr)_2)->base + 16);
        _25094 = NOVALUE;
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _25096 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
        _2 = (int)SEQ_PTR(_25096);
        if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
            _25097 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
        }
        else{
            _25097 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
        }
        _25096 = NOVALUE;
        if (binary_op_a(LESS, _25095, _25097)){
            _25095 = NOVALUE;
            _25097 = NOVALUE;
            goto L3; // [163] 175
        }
        _25095 = NOVALUE;
        _25097 = NOVALUE;

        /** 		    	warn_level = 3*/
        _warn_level_47819 = 3;
        goto L1; // [172] 193
L3: 

        /** 		    	warn_level = 0*/
        _warn_level_47819 = 0;
        goto L1; // [181] 193

        /** 	    case else*/
        default:

        /** 	    	warn_level = 0*/
        _warn_level_47819 = 0;
    ;}L1: 

    /** 	if warn_level = 0 then*/
    if (_warn_level_47819 != 0)
    goto L4; // [197] 207

    /** 		return*/
    DeRef(_file_47820);
    DeRef(_vname_47822);
    return;
L4: 

    /** 	file = abbreviate_path(known_files[current_file_no])*/
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _25100 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    Ref(_25100);
    RefDS(_22037);
    _0 = _file_47820;
    _file_47820 = _15abbreviate_path(_25100, _22037);
    DeRef(_0);
    _25100 = NOVALUE;

    /** 	if warn_level = 3 then*/
    if (_warn_level_47819 != 3)
    goto L5; // [226] 308

    /** 		if vscope = SC_LOCAL then*/
    if (_vscope_47821 != 5)
    goto L6; // [234] 275

    /** 			if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25104 = (int)*(((s1_ptr)_2)->base + _s_47818);
    _2 = (int)SEQ_PTR(_25104);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _25105 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _25105 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _25104 = NOVALUE;
    if (binary_op_a(NOTEQ, _26current_file_no_11982, _25105)){
        _25105 = NOVALUE;
        goto L7; // [254] 602
    }
    _25105 = NOVALUE;

    /** 				Warning(226, no_value_warning_flag, {file,  vname})*/
    RefDS(_vname_47822);
    RefDS(_file_47820);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_47820;
    ((int *)_2)[2] = _vname_47822;
    _25107 = MAKE_SEQ(_1);
    _43Warning(226, 32, _25107);
    _25107 = NOVALUE;
    goto L7; // [272] 602
L6: 

    /** 			Warning(227, no_value_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25108 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_25108);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _25109 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _25109 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _25108 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47820);
    *((int *)(_2+4)) = _file_47820;
    RefDS(_vname_47822);
    *((int *)(_2+8)) = _vname_47822;
    Ref(_25109);
    *((int *)(_2+12)) = _25109;
    _25110 = MAKE_SEQ(_1);
    _25109 = NOVALUE;
    _43Warning(227, 32, _25110);
    _25110 = NOVALUE;
    goto L7; // [305] 602
L5: 

    /** 		if vscope = SC_LOCAL then*/
    if (_vscope_47821 != 5)
    goto L8; // [312] 412

    /** 			if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25112 = (int)*(((s1_ptr)_2)->base + _s_47818);
    _2 = (int)SEQ_PTR(_25112);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _25113 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _25113 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _25112 = NOVALUE;
    if (binary_op_a(NOTEQ, _26current_file_no_11982, _25113)){
        _25113 = NOVALUE;
        goto L9; // [332] 601
    }
    _25113 = NOVALUE;

    /** 				if SymTab[s][S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25115 = (int)*(((s1_ptr)_2)->base + _s_47818);
    _2 = (int)SEQ_PTR(_25115);
    _25116 = (int)*(((s1_ptr)_2)->base + 3);
    _25115 = NOVALUE;
    if (binary_op_a(NOTEQ, _25116, 2)){
        _25116 = NOVALUE;
        goto LA; // [352] 372
    }
    _25116 = NOVALUE;

    /** 					Warning(228, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_47822);
    RefDS(_file_47820);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_47820;
    ((int *)_2)[2] = _vname_47822;
    _25118 = MAKE_SEQ(_1);
    _43Warning(228, 16, _25118);
    _25118 = NOVALUE;
    goto L9; // [369] 601
LA: 

    /** 				elsif warn_level = 1 then*/
    if (_warn_level_47819 != 1)
    goto LB; // [374] 394

    /** 					Warning(229, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_47822);
    RefDS(_file_47820);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_47820;
    ((int *)_2)[2] = _vname_47822;
    _25120 = MAKE_SEQ(_1);
    _43Warning(229, 16, _25120);
    _25120 = NOVALUE;
    goto L9; // [391] 601
LB: 

    /** 					Warning(320, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_47822);
    RefDS(_file_47820);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_47820;
    ((int *)_2)[2] = _vname_47822;
    _25121 = MAKE_SEQ(_1);
    _43Warning(320, 16, _25121);
    _25121 = NOVALUE;
    goto L9; // [409] 601
L8: 

    /** 			if SymTab[s][S_VARNUM] < SymTab[CurrentSub][S_NUM_ARGS] then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25122 = (int)*(((s1_ptr)_2)->base + _s_47818);
    _2 = (int)SEQ_PTR(_25122);
    _25123 = (int)*(((s1_ptr)_2)->base + 16);
    _25122 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25124 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_25124);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _25125 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _25125 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _25124 = NOVALUE;
    if (binary_op_a(GREATEREQ, _25123, _25125)){
        _25123 = NOVALUE;
        _25125 = NOVALUE;
        goto LC; // [440] 523
    }
    _25123 = NOVALUE;
    _25125 = NOVALUE;

    /** 				if warn_level = 1 then*/
    if (_warn_level_47819 != 1)
    goto LD; // [446] 490

    /** 					if Strict_is_on then*/
    if (_26Strict_is_on_12048 == 0)
    {
        goto LE; // [454] 600
    }
    else{
    }

    /** 						Warning(230, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25128 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_25128);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _25129 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _25129 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _25128 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47820);
    *((int *)(_2+4)) = _file_47820;
    RefDS(_vname_47822);
    *((int *)(_2+8)) = _vname_47822;
    Ref(_25129);
    *((int *)(_2+12)) = _25129;
    _25130 = MAKE_SEQ(_1);
    _25129 = NOVALUE;
    _43Warning(230, 16, _25130);
    _25130 = NOVALUE;
    goto LE; // [487] 600
LD: 

    /** 					Warning(321, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25131 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_25131);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _25132 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _25132 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _25131 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47820);
    *((int *)(_2+4)) = _file_47820;
    RefDS(_vname_47822);
    *((int *)(_2+8)) = _vname_47822;
    Ref(_25132);
    *((int *)(_2+12)) = _25132;
    _25133 = MAKE_SEQ(_1);
    _25132 = NOVALUE;
    _43Warning(321, 16, _25133);
    _25133 = NOVALUE;
    goto LE; // [520] 600
LC: 

    /** 				if warn_level = 1 then*/
    if (_warn_level_47819 != 1)
    goto LF; // [525] 569

    /** 					if Strict_is_on then*/
    if (_26Strict_is_on_12048 == 0)
    {
        goto L10; // [533] 599
    }
    else{
    }

    /** 						Warning(231, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25135 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_25135);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _25136 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _25136 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _25135 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47820);
    *((int *)(_2+4)) = _file_47820;
    RefDS(_vname_47822);
    *((int *)(_2+8)) = _vname_47822;
    Ref(_25136);
    *((int *)(_2+12)) = _25136;
    _25137 = MAKE_SEQ(_1);
    _25136 = NOVALUE;
    _43Warning(231, 16, _25137);
    _25137 = NOVALUE;
    goto L10; // [566] 599
LF: 

    /** 					Warning(322, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25138 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_25138);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _25139 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _25139 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _25138 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47820);
    *((int *)(_2+4)) = _file_47820;
    RefDS(_vname_47822);
    *((int *)(_2+8)) = _vname_47822;
    Ref(_25139);
    *((int *)(_2+12)) = _25139;
    _25140 = MAKE_SEQ(_1);
    _25139 = NOVALUE;
    _43Warning(322, 16, _25140);
    _25140 = NOVALUE;
L10: 
LE: 
L9: 
L7: 

    /** end procedure*/
    DeRef(_file_47820);
    DeRef(_vname_47822);
    return;
    ;
}


void _52HideLocals()
{
    int _s_47989 = NOVALUE;
    int _25151 = NOVALUE;
    int _25149 = NOVALUE;
    int _25148 = NOVALUE;
    int _25147 = NOVALUE;
    int _25146 = NOVALUE;
    int _25145 = NOVALUE;
    int _25144 = NOVALUE;
    int _25143 = NOVALUE;
    int _25142 = NOVALUE;
    int _25141 = NOVALUE;
    int _0, _1, _2;
    

    /** 	s = file_start_sym*/
    _s_47989 = _26file_start_sym_11988;

    /** 	while s do*/
L1: 
    if (_s_47989 == 0)
    {
        goto L2; // [15] 117
    }
    else{
    }

    /** 		if SymTab[s][S_SCOPE] = SC_LOCAL and*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25141 = (int)*(((s1_ptr)_2)->base + _s_47989);
    _2 = (int)SEQ_PTR(_25141);
    _25142 = (int)*(((s1_ptr)_2)->base + 4);
    _25141 = NOVALUE;
    if (IS_ATOM_INT(_25142)) {
        _25143 = (_25142 == 5);
    }
    else {
        _25143 = binary_op(EQUALS, _25142, 5);
    }
    _25142 = NOVALUE;
    if (IS_ATOM_INT(_25143)) {
        if (_25143 == 0) {
            goto L3; // [38] 96
        }
    }
    else {
        if (DBL_PTR(_25143)->dbl == 0.0) {
            goto L3; // [38] 96
        }
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25145 = (int)*(((s1_ptr)_2)->base + _s_47989);
    _2 = (int)SEQ_PTR(_25145);
    if (!IS_ATOM_INT(_26S_FILE_NO_11650)){
        _25146 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FILE_NO_11650)->dbl));
    }
    else{
        _25146 = (int)*(((s1_ptr)_2)->base + _26S_FILE_NO_11650);
    }
    _25145 = NOVALUE;
    if (IS_ATOM_INT(_25146)) {
        _25147 = (_25146 == _26current_file_no_11982);
    }
    else {
        _25147 = binary_op(EQUALS, _25146, _26current_file_no_11982);
    }
    _25146 = NOVALUE;
    if (_25147 == 0) {
        DeRef(_25147);
        _25147 = NOVALUE;
        goto L3; // [61] 96
    }
    else {
        if (!IS_ATOM_INT(_25147) && DBL_PTR(_25147)->dbl == 0.0){
            DeRef(_25147);
            _25147 = NOVALUE;
            goto L3; // [61] 96
        }
        DeRef(_25147);
        _25147 = NOVALUE;
    }
    DeRef(_25147);
    _25147 = NOVALUE;

    /** 			Hide(s)*/
    _52Hide(_s_47989);

    /** 			if SymTab[s][S_TOKEN] = VARIABLE then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25148 = (int)*(((s1_ptr)_2)->base + _s_47989);
    _2 = (int)SEQ_PTR(_25148);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _25149 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _25149 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _25148 = NOVALUE;
    if (binary_op_a(NOTEQ, _25149, -100)){
        _25149 = NOVALUE;
        goto L4; // [85] 95
    }
    _25149 = NOVALUE;

    /** 				LintCheck(s)*/
    _52LintCheck(_s_47989);
L4: 
L3: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25151 = (int)*(((s1_ptr)_2)->base + _s_47989);
    _2 = (int)SEQ_PTR(_25151);
    _s_47989 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_47989)){
        _s_47989 = (long)DBL_PTR(_s_47989)->dbl;
    }
    _25151 = NOVALUE;

    /** 	end while*/
    goto L1; // [114] 15
L2: 

    /** end procedure*/
    DeRef(_25143);
    _25143 = NOVALUE;
    return;
    ;
}


int _52sym_name(int _sym_48020)
{
    int _25154 = NOVALUE;
    int _25153 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48020)) {
        _1 = (long)(DBL_PTR(_sym_48020)->dbl);
        DeRefDS(_sym_48020);
        _sym_48020 = _1;
    }

    /** 	return SymTab[sym][S_NAME]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25153 = (int)*(((s1_ptr)_2)->base + _sym_48020);
    _2 = (int)SEQ_PTR(_25153);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _25154 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _25154 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _25153 = NOVALUE;
    Ref(_25154);
    return _25154;
    ;
}


int _52sym_token(int _sym_48028)
{
    int _25156 = NOVALUE;
    int _25155 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48028)) {
        _1 = (long)(DBL_PTR(_sym_48028)->dbl);
        DeRefDS(_sym_48028);
        _sym_48028 = _1;
    }

    /** 	return SymTab[sym][S_TOKEN]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25155 = (int)*(((s1_ptr)_2)->base + _sym_48028);
    _2 = (int)SEQ_PTR(_25155);
    if (!IS_ATOM_INT(_26S_TOKEN_11659)){
        _25156 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
    }
    else{
        _25156 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
    }
    _25155 = NOVALUE;
    Ref(_25156);
    return _25156;
    ;
}


int _52sym_scope(int _sym_48036)
{
    int _25158 = NOVALUE;
    int _25157 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48036)) {
        _1 = (long)(DBL_PTR(_sym_48036)->dbl);
        DeRefDS(_sym_48036);
        _sym_48036 = _1;
    }

    /** 	return SymTab[sym][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25157 = (int)*(((s1_ptr)_2)->base + _sym_48036);
    _2 = (int)SEQ_PTR(_25157);
    _25158 = (int)*(((s1_ptr)_2)->base + 4);
    _25157 = NOVALUE;
    Ref(_25158);
    return _25158;
    ;
}


int _52sym_mode(int _sym_48044)
{
    int _25160 = NOVALUE;
    int _25159 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48044)) {
        _1 = (long)(DBL_PTR(_sym_48044)->dbl);
        DeRefDS(_sym_48044);
        _sym_48044 = _1;
    }

    /** 	return SymTab[sym][S_MODE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25159 = (int)*(((s1_ptr)_2)->base + _sym_48044);
    _2 = (int)SEQ_PTR(_25159);
    _25160 = (int)*(((s1_ptr)_2)->base + 3);
    _25159 = NOVALUE;
    Ref(_25160);
    return _25160;
    ;
}


int _52sym_obj(int _sym_48052)
{
    int _25162 = NOVALUE;
    int _25161 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48052)) {
        _1 = (long)(DBL_PTR(_sym_48052)->dbl);
        DeRefDS(_sym_48052);
        _sym_48052 = _1;
    }

    /** 	return SymTab[sym][S_OBJ]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25161 = (int)*(((s1_ptr)_2)->base + _sym_48052);
    _2 = (int)SEQ_PTR(_25161);
    _25162 = (int)*(((s1_ptr)_2)->base + 1);
    _25161 = NOVALUE;
    Ref(_25162);
    return _25162;
    ;
}


int _52sym_next(int _sym_48060)
{
    int _25164 = NOVALUE;
    int _25163 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48060)) {
        _1 = (long)(DBL_PTR(_sym_48060)->dbl);
        DeRefDS(_sym_48060);
        _sym_48060 = _1;
    }

    /** 	return SymTab[sym][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25163 = (int)*(((s1_ptr)_2)->base + _sym_48060);
    _2 = (int)SEQ_PTR(_25163);
    _25164 = (int)*(((s1_ptr)_2)->base + 2);
    _25163 = NOVALUE;
    Ref(_25164);
    return _25164;
    ;
}


int _52sym_block(int _sym_48068)
{
    int _25166 = NOVALUE;
    int _25165 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48068)) {
        _1 = (long)(DBL_PTR(_sym_48068)->dbl);
        DeRefDS(_sym_48068);
        _sym_48068 = _1;
    }

    /** 	return SymTab[sym][S_BLOCK]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25165 = (int)*(((s1_ptr)_2)->base + _sym_48068);
    _2 = (int)SEQ_PTR(_25165);
    if (!IS_ATOM_INT(_26S_BLOCK_11674)){
        _25166 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_BLOCK_11674)->dbl));
    }
    else{
        _25166 = (int)*(((s1_ptr)_2)->base + _26S_BLOCK_11674);
    }
    _25165 = NOVALUE;
    Ref(_25166);
    return _25166;
    ;
}


int _52sym_next_in_block(int _sym_48076)
{
    int _25168 = NOVALUE;
    int _25167 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48076)) {
        _1 = (long)(DBL_PTR(_sym_48076)->dbl);
        DeRefDS(_sym_48076);
        _sym_48076 = _1;
    }

    /** 	return SymTab[sym][S_NEXT_IN_BLOCK]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25167 = (int)*(((s1_ptr)_2)->base + _sym_48076);
    _2 = (int)SEQ_PTR(_25167);
    if (!IS_ATOM_INT(_26S_NEXT_IN_BLOCK_11646)){
        _25168 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NEXT_IN_BLOCK_11646)->dbl));
    }
    else{
        _25168 = (int)*(((s1_ptr)_2)->base + _26S_NEXT_IN_BLOCK_11646);
    }
    _25167 = NOVALUE;
    Ref(_25168);
    return _25168;
    ;
}


int _52sym_usage(int _sym_48084)
{
    int _25170 = NOVALUE;
    int _25169 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48084)) {
        _1 = (long)(DBL_PTR(_sym_48084)->dbl);
        DeRefDS(_sym_48084);
        _sym_48084 = _1;
    }

    /** 	return SymTab[sym][S_USAGE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25169 = (int)*(((s1_ptr)_2)->base + _sym_48084);
    _2 = (int)SEQ_PTR(_25169);
    _25170 = (int)*(((s1_ptr)_2)->base + 5);
    _25169 = NOVALUE;
    Ref(_25170);
    return _25170;
    ;
}


int _52calc_stack_required(int _sub_48092)
{
    int _required_48093 = NOVALUE;
    int _arg_48098 = NOVALUE;
    int _25190 = NOVALUE;
    int _25186 = NOVALUE;
    int _25184 = NOVALUE;
    int _25182 = NOVALUE;
    int _25181 = NOVALUE;
    int _25180 = NOVALUE;
    int _25179 = NOVALUE;
    int _25178 = NOVALUE;
    int _25176 = NOVALUE;
    int _25175 = NOVALUE;
    int _25173 = NOVALUE;
    int _25171 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sub_48092)) {
        _1 = (long)(DBL_PTR(_sub_48092)->dbl);
        DeRefDS(_sub_48092);
        _sub_48092 = _1;
    }

    /** 	integer required = SymTab[sub][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25171 = (int)*(((s1_ptr)_2)->base + _sub_48092);
    _2 = (int)SEQ_PTR(_25171);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _required_48093 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _required_48093 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    if (!IS_ATOM_INT(_required_48093)){
        _required_48093 = (long)DBL_PTR(_required_48093)->dbl;
    }
    _25171 = NOVALUE;

    /** 	integer arg = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25173 = (int)*(((s1_ptr)_2)->base + _sub_48092);
    _2 = (int)SEQ_PTR(_25173);
    _arg_48098 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_48098)){
        _arg_48098 = (long)DBL_PTR(_arg_48098)->dbl;
    }
    _25173 = NOVALUE;

    /** 	for i = 1 to required do*/
    _25175 = _required_48093;
    {
        int _i_48104;
        _i_48104 = 1;
L1: 
        if (_i_48104 > _25175){
            goto L2; // [40] 70
        }

        /** 		arg = SymTab[arg][S_NEXT]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _25176 = (int)*(((s1_ptr)_2)->base + _arg_48098);
        _2 = (int)SEQ_PTR(_25176);
        _arg_48098 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_48098)){
            _arg_48098 = (long)DBL_PTR(_arg_48098)->dbl;
        }
        _25176 = NOVALUE;

        /** 	end for*/
        _i_48104 = _i_48104 + 1;
        goto L1; // [65] 47
L2: 
        ;
    }

    /** 	while arg != 0 and SymTab[arg][S_SCOPE] <= SC_PRIVATE do*/
L3: 
    _25178 = (_arg_48098 != 0);
    if (_25178 == 0) {
        goto L4; // [79] 132
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25180 = (int)*(((s1_ptr)_2)->base + _arg_48098);
    _2 = (int)SEQ_PTR(_25180);
    _25181 = (int)*(((s1_ptr)_2)->base + 4);
    _25180 = NOVALUE;
    if (IS_ATOM_INT(_25181)) {
        _25182 = (_25181 <= 3);
    }
    else {
        _25182 = binary_op(LESSEQ, _25181, 3);
    }
    _25181 = NOVALUE;
    if (_25182 <= 0) {
        if (_25182 == 0) {
            DeRef(_25182);
            _25182 = NOVALUE;
            goto L4; // [102] 132
        }
        else {
            if (!IS_ATOM_INT(_25182) && DBL_PTR(_25182)->dbl == 0.0){
                DeRef(_25182);
                _25182 = NOVALUE;
                goto L4; // [102] 132
            }
            DeRef(_25182);
            _25182 = NOVALUE;
        }
    }
    DeRef(_25182);
    _25182 = NOVALUE;

    /** 		required += 1*/
    _required_48093 = _required_48093 + 1;

    /** 		arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25184 = (int)*(((s1_ptr)_2)->base + _arg_48098);
    _2 = (int)SEQ_PTR(_25184);
    _arg_48098 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_48098)){
        _arg_48098 = (long)DBL_PTR(_arg_48098)->dbl;
    }
    _25184 = NOVALUE;

    /** 	end while*/
    goto L3; // [129] 75
L4: 

    /** 	arg = SymTab[sub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25186 = (int)*(((s1_ptr)_2)->base + _sub_48092);
    _2 = (int)SEQ_PTR(_25186);
    if (!IS_ATOM_INT(_26S_TEMPS_11699)){
        _arg_48098 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TEMPS_11699)->dbl));
    }
    else{
        _arg_48098 = (int)*(((s1_ptr)_2)->base + _26S_TEMPS_11699);
    }
    if (!IS_ATOM_INT(_arg_48098)){
        _arg_48098 = (long)DBL_PTR(_arg_48098)->dbl;
    }
    _25186 = NOVALUE;

    /** 	while arg != 0 do*/
L5: 
    if (_arg_48098 == 0)
    goto L6; // [153] 184

    /** 		required += 1*/
    _required_48093 = _required_48093 + 1;

    /** 		arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _25190 = (int)*(((s1_ptr)_2)->base + _arg_48098);
    _2 = (int)SEQ_PTR(_25190);
    _arg_48098 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_48098)){
        _arg_48098 = (long)DBL_PTR(_arg_48098)->dbl;
    }
    _25190 = NOVALUE;

    /** 	end while*/
    goto L5; // [181] 153
L6: 

    /** 	return required*/
    DeRef(_25178);
    _25178 = NOVALUE;
    return _required_48093;
    ;
}



// 0x8C521C7F
