// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _39add_options(int _new_options_49003)
{
    int _0, _1, _2;
    

    /** 	options = splice(options, new_options, COMMON_OPTIONS_SPLICE_IDX)*/
    {
        s1_ptr assign_space;
        insert_pos = 15;
        if (insert_pos <= 0) {
            Concat(&_39options_48999,_new_options_49003,_39options_48999);
        }
        else if (insert_pos > SEQ_PTR(_39options_48999)->length){
            Concat(&_39options_48999,_39options_48999,_new_options_49003);
        }
        else if (IS_SEQUENCE(_new_options_49003)) {
            if( _39options_48999 != _39options_48999 || SEQ_PTR( _39options_48999 )->ref != 1 ){
                DeRef( _39options_48999 );
                RefDS( _39options_48999 );
            }
            assign_space = Add_internal_space( _39options_48999, insert_pos,((s1_ptr)SEQ_PTR(_new_options_49003))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_new_options_49003), _39options_48999 == _39options_48999 );
            _39options_48999 = MAKE_SEQ( assign_space );
        }
        else {
            if( _39options_48999 != _39options_48999 && SEQ_PTR( _39options_48999 )->ref != 1 ){
                _39options_48999 = Insert( _39options_48999, _new_options_49003, insert_pos);
            }
            else {
                DeRef( _39options_48999 );
                RefDS( _39options_48999 );
                _39options_48999 = Insert( _39options_48999, _new_options_49003, insert_pos);
            }
        }
    }

    /** end procedure*/
    DeRefDS(_new_options_49003);
    return;
    ;
}


int _39get_options()
{
    int _0, _1, _2;
    

    /** 	return options*/
    RefDS(_39options_48999);
    return _39options_48999;
    ;
}


int _39get_common_options()
{
    int _0, _1, _2;
    

    /** 	return COMMON_OPTIONS*/
    RefDS(_39COMMON_OPTIONS_48897);
    return _39COMMON_OPTIONS_48897;
    ;
}


int _39get_switches()
{
    int _0, _1, _2;
    

    /** 	return switches*/
    RefDS(_39switches_48896);
    return _39switches_48896;
    ;
}


void _39show_copyrights()
{
    int _notices_49013 = NOVALUE;
    int _25600 = NOVALUE;
    int _25599 = NOVALUE;
    int _25597 = NOVALUE;
    int _25596 = NOVALUE;
    int _25595 = NOVALUE;
    int _25594 = NOVALUE;
    int _25592 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence notices = all_copyrights()*/
    _0 = _notices_49013;
    _notices_49013 = _31all_copyrights();
    DeRef(_0);

    /** 	for i = 1 to length(notices) do*/
    if (IS_SEQUENCE(_notices_49013)){
            _25592 = SEQ_PTR(_notices_49013)->length;
    }
    else {
        _25592 = 1;
    }
    {
        int _i_49017;
        _i_49017 = 1;
L1: 
        if (_i_49017 > _25592){
            goto L2; // [13] 60
        }

        /** 		printf(2, "%s\n  %s\n\n", { notices[i][1], match_replace("\n", notices[i][2], "\n  ") })*/
        _2 = (int)SEQ_PTR(_notices_49013);
        _25594 = (int)*(((s1_ptr)_2)->base + _i_49017);
        _2 = (int)SEQ_PTR(_25594);
        _25595 = (int)*(((s1_ptr)_2)->base + 1);
        _25594 = NOVALUE;
        _2 = (int)SEQ_PTR(_notices_49013);
        _25596 = (int)*(((s1_ptr)_2)->base + _i_49017);
        _2 = (int)SEQ_PTR(_25596);
        _25597 = (int)*(((s1_ptr)_2)->base + 2);
        _25596 = NOVALUE;
        RefDS(_22189);
        Ref(_25597);
        RefDS(_25598);
        _25599 = _14match_replace(_22189, _25597, _25598, 0);
        _25597 = NOVALUE;
        Ref(_25595);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _25595;
        ((int *)_2)[2] = _25599;
        _25600 = MAKE_SEQ(_1);
        _25599 = NOVALUE;
        _25595 = NOVALUE;
        EPrintf(2, _25593, _25600);
        DeRefDS(_25600);
        _25600 = NOVALUE;

        /** 	end for*/
        _i_49017 = _i_49017 + 1;
        goto L1; // [55] 20
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_notices_49013);
    return;
    ;
}


void _39show_banner()
{
    int _version_type_inlined_version_type_at_206_49080 = NOVALUE;
    int _version_string_short_1__tmp_at190_49078 = NOVALUE;
    int _version_string_short_inlined_version_string_short_at_190_49077 = NOVALUE;
    int _version_revision_inlined_version_revision_at_121_49059 = NOVALUE;
    int _platform_name_inlined_platform_name_at_83_49051 = NOVALUE;
    int _prod_name_49030 = NOVALUE;
    int _memory_type_49031 = NOVALUE;
    int _misc_info_49049 = NOVALUE;
    int _EuConsole_49063 = NOVALUE;
    int _25624 = NOVALUE;
    int _25623 = NOVALUE;
    int _25622 = NOVALUE;
    int _25619 = NOVALUE;
    int _25618 = NOVALUE;
    int _25614 = NOVALUE;
    int _25613 = NOVALUE;
    int _25612 = NOVALUE;
    int _25610 = NOVALUE;
    int _25608 = NOVALUE;
    int _25607 = NOVALUE;
    int _25602 = NOVALUE;
    int _25601 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if INTERPRET and not BIND then*/
    if (_26INTERPRET_11616 == 0) {
        goto L1; // [5] 31
    }
    _25602 = (_26BIND_11622 == 0);
    if (_25602 == 0)
    {
        DeRef(_25602);
        _25602 = NOVALUE;
        goto L1; // [15] 31
    }
    else{
        DeRef(_25602);
        _25602 = NOVALUE;
    }

    /** 		prod_name = GetMsgText(270,0)*/
    RefDS(_22037);
    _0 = _prod_name_49030;
    _prod_name_49030 = _44GetMsgText(270, 0, _22037);
    DeRef(_0);
    goto L2; // [28] 70
L1: 

    /** 	elsif TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L3; // [35] 51
    }
    else{
    }

    /** 		prod_name = GetMsgText(271,0)*/
    RefDS(_22037);
    _0 = _prod_name_49030;
    _prod_name_49030 = _44GetMsgText(271, 0, _22037);
    DeRef(_0);
    goto L2; // [48] 70
L3: 

    /** 	elsif BIND then*/
    if (_26BIND_11622 == 0)
    {
        goto L4; // [55] 69
    }
    else{
    }

    /** 		prod_name = GetMsgText(272,0)*/
    RefDS(_22037);
    _0 = _prod_name_49030;
    _prod_name_49030 = _44GetMsgText(272, 0, _22037);
    DeRef(_0);
L4: 
L2: 

    /** 	ifdef EU_MANAGED_MEM then*/

    /** 		memory_type = GetMsgText(274,0)*/
    RefDS(_22037);
    _0 = _memory_type_49031;
    _memory_type_49031 = _44GetMsgText(274, 0, _22037);
    DeRef(_0);

    /** 	sequence misc_info = {*/

    /** 	ifdef WINDOWS then*/

    /** 		return "Windows"*/
    RefDS(_6412);
    DeRefi(_platform_name_inlined_platform_name_at_83_49051);
    _platform_name_inlined_platform_name_at_83_49051 = _6412;
    _25607 = _31version_date(0);
    _25608 = _31version_node(0);
    _0 = _misc_info_49049;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_platform_name_inlined_platform_name_at_83_49051);
    *((int *)(_2+4)) = _platform_name_inlined_platform_name_at_83_49051;
    RefDS(_memory_type_49031);
    *((int *)(_2+8)) = _memory_type_49031;
    RefDS(_22037);
    *((int *)(_2+12)) = _22037;
    *((int *)(_2+16)) = _25607;
    *((int *)(_2+20)) = _25608;
    _misc_info_49049 = MAKE_SEQ(_1);
    DeRef(_0);
    _25608 = NOVALUE;
    _25607 = NOVALUE;

    /** 	if info:is_developmental then*/
    if (_31is_developmental_12125 == 0)
    {
        goto L5; // [114] 148
    }
    else{
    }

    /** 		misc_info[$] = sprintf("%d:%s", { info:version_revision(), info:version_node() })*/
    _25610 = 5;

    /** 	return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_121_49059);
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _version_revision_inlined_version_revision_at_121_49059 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_version_revision_inlined_version_revision_at_121_49059);
    _25612 = _31version_node(0);
    Ref(_version_revision_inlined_version_revision_at_121_49059);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _version_revision_inlined_version_revision_at_121_49059;
    ((int *)_2)[2] = _25612;
    _25613 = MAKE_SEQ(_1);
    _25612 = NOVALUE;
    _25614 = EPrintf(-9999999, _25611, _25613);
    DeRefDS(_25613);
    _25613 = NOVALUE;
    _2 = (int)SEQ_PTR(_misc_info_49049);
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _25614;
    if( _1 != _25614 ){
        DeRef(_1);
    }
    _25614 = NOVALUE;
L5: 

    /** 	object EuConsole = getenv("EUCONS")*/
    DeRefi(_EuConsole_49063);
    _EuConsole_49063 = EGetEnv(_25615);

    /** 	if equal(EuConsole, "1") then*/
    if (_EuConsole_49063 == _25617)
    _25618 = 1;
    else if (IS_ATOM_INT(_EuConsole_49063) && IS_ATOM_INT(_25617))
    _25618 = 0;
    else
    _25618 = (compare(_EuConsole_49063, _25617) == 0);
    if (_25618 == 0)
    {
        _25618 = NOVALUE;
        goto L6; // [159] 177
    }
    else{
        _25618 = NOVALUE;
    }

    /** 		misc_info[3] = GetMsgText(275,0)*/
    RefDS(_22037);
    _25619 = _44GetMsgText(275, 0, _22037);
    _2 = (int)SEQ_PTR(_misc_info_49049);
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _25619;
    if( _1 != _25619 ){
        DeRef(_1);
    }
    _25619 = NOVALUE;
    goto L7; // [174] 185
L6: 

    /** 		misc_info = remove(misc_info, 3)*/
    {
        s1_ptr assign_space = SEQ_PTR(_misc_info_49049);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(3)) ? 3 : (long)(DBL_PTR(3)->dbl);
        int stop = (IS_ATOM_INT(3)) ? 3 : (long)(DBL_PTR(3)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_misc_info_49049), start, &_misc_info_49049 );
            }
            else Tail(SEQ_PTR(_misc_info_49049), stop+1, &_misc_info_49049);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_misc_info_49049), start, &_misc_info_49049);
        }
        else {
            assign_slice_seq = &assign_space;
            _misc_info_49049 = Remove_elements(start, stop, (SEQ_PTR(_misc_info_49049)->ref == 1));
        }
    }
L7: 

    /** 	screen_output(STDERR, sprintf("%s v%s %s\n   %s, %s\n   Revision Date: %s, Id: %s\n", {*/

    /** 	return sprintf("%d.%d.%d", version_info[MAJ_VER..PAT_VER])*/
    rhs_slice_target = (object_ptr)&_version_string_short_1__tmp_at190_49078;
    RHS_Slice(_31version_info_12123, 1, 3);
    DeRefi(_version_string_short_inlined_version_string_short_at_190_49077);
    _version_string_short_inlined_version_string_short_at_190_49077 = EPrintf(-9999999, _6643, _version_string_short_1__tmp_at190_49078);
    DeRef(_version_string_short_1__tmp_at190_49078);
    _version_string_short_1__tmp_at190_49078 = NOVALUE;

    /** 	return version_info[VER_TYPE]*/
    DeRef(_version_type_inlined_version_type_at_206_49080);
    _2 = (int)SEQ_PTR(_31version_info_12123);
    _version_type_inlined_version_type_at_206_49080 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_version_type_inlined_version_type_at_206_49080);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_prod_name_49030);
    *((int *)(_2+4)) = _prod_name_49030;
    RefDS(_version_string_short_inlined_version_string_short_at_190_49077);
    *((int *)(_2+8)) = _version_string_short_inlined_version_string_short_at_190_49077;
    Ref(_version_type_inlined_version_type_at_206_49080);
    *((int *)(_2+12)) = _version_type_inlined_version_type_at_206_49080;
    _25622 = MAKE_SEQ(_1);
    Concat((object_ptr)&_25623, _25622, _misc_info_49049);
    DeRefDS(_25622);
    _25622 = NOVALUE;
    DeRef(_25622);
    _25622 = NOVALUE;
    _25624 = EPrintf(-9999999, _25621, _25623);
    DeRefDS(_25623);
    _25623 = NOVALUE;
    _43screen_output(2, _25624);
    _25624 = NOVALUE;

    /** end procedure*/
    DeRefDS(_prod_name_49030);
    DeRef(_memory_type_49031);
    DeRefDS(_misc_info_49049);
    DeRefi(_EuConsole_49063);
    return;
    ;
}


int _39find_opt(int _name_type_49092, int _opt_49093, int _opts_49094)
{
    int _o_49098 = NOVALUE;
    int _has_case_49100 = NOVALUE;
    int _25637 = NOVALUE;
    int _25636 = NOVALUE;
    int _25635 = NOVALUE;
    int _25634 = NOVALUE;
    int _25633 = NOVALUE;
    int _25632 = NOVALUE;
    int _25631 = NOVALUE;
    int _25630 = NOVALUE;
    int _25629 = NOVALUE;
    int _25627 = NOVALUE;
    int _25625 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_49094)){
            _25625 = SEQ_PTR(_opts_49094)->length;
    }
    else {
        _25625 = 1;
    }
    {
        int _i_49096;
        _i_49096 = 1;
L1: 
        if (_i_49096 > _25625){
            goto L2; // [12] 113
        }

        /** 		sequence o = opts[i]		*/
        DeRef(_o_49098);
        _2 = (int)SEQ_PTR(_opts_49094);
        _o_49098 = (int)*(((s1_ptr)_2)->base + _i_49096);
        Ref(_o_49098);

        /** 		integer has_case = find(HAS_CASE, o[OPTIONS])*/
        _2 = (int)SEQ_PTR(_o_49098);
        _25627 = (int)*(((s1_ptr)_2)->base + 4);
        _has_case_49100 = find_from(99, _25627, 1);
        _25627 = NOVALUE;

        /** 		if has_case and equal(o[name_type], opt) then*/
        if (_has_case_49100 == 0) {
            goto L3; // [42] 67
        }
        _2 = (int)SEQ_PTR(_o_49098);
        _25630 = (int)*(((s1_ptr)_2)->base + _name_type_49092);
        if (_25630 == _opt_49093)
        _25631 = 1;
        else if (IS_ATOM_INT(_25630) && IS_ATOM_INT(_opt_49093))
        _25631 = 0;
        else
        _25631 = (compare(_25630, _opt_49093) == 0);
        _25630 = NOVALUE;
        if (_25631 == 0)
        {
            _25631 = NOVALUE;
            goto L3; // [55] 67
        }
        else{
            _25631 = NOVALUE;
        }

        /** 			return o*/
        DeRefDS(_opt_49093);
        DeRefDS(_opts_49094);
        return _o_49098;
        goto L4; // [64] 104
L3: 

        /** 		elsif not has_case and equal(text:lower(o[name_type]), text:lower(opt)) then*/
        _25632 = (_has_case_49100 == 0);
        if (_25632 == 0) {
            goto L5; // [72] 103
        }
        _2 = (int)SEQ_PTR(_o_49098);
        _25634 = (int)*(((s1_ptr)_2)->base + _name_type_49092);
        Ref(_25634);
        _25635 = _12lower(_25634);
        _25634 = NOVALUE;
        RefDS(_opt_49093);
        _25636 = _12lower(_opt_49093);
        if (_25635 == _25636)
        _25637 = 1;
        else if (IS_ATOM_INT(_25635) && IS_ATOM_INT(_25636))
        _25637 = 0;
        else
        _25637 = (compare(_25635, _25636) == 0);
        DeRef(_25635);
        _25635 = NOVALUE;
        DeRef(_25636);
        _25636 = NOVALUE;
        if (_25637 == 0)
        {
            _25637 = NOVALUE;
            goto L5; // [93] 103
        }
        else{
            _25637 = NOVALUE;
        }

        /** 			return o*/
        DeRefDS(_opt_49093);
        DeRefDS(_opts_49094);
        DeRef(_25632);
        _25632 = NOVALUE;
        return _o_49098;
L5: 
L4: 
        DeRef(_o_49098);
        _o_49098 = NOVALUE;

        /** 	end for*/
        _i_49096 = _i_49096 + 1;
        goto L1; // [108] 19
L2: 
        ;
    }

    /** 	return {}*/
    RefDS(_22037);
    DeRefDS(_opt_49093);
    DeRefDS(_opts_49094);
    DeRef(_25632);
    _25632 = NOVALUE;
    return _22037;
    ;
}


int _39merge_parameters(int _a_49117, int _b_49118, int _opts_49119, int _dedupe_49120)
{
    int _i_49121 = NOVALUE;
    int _opt_49125 = NOVALUE;
    int _this_opt_49131 = NOVALUE;
    int _bi_49132 = NOVALUE;
    int _beginLen_49192 = NOVALUE;
    int _first_extra_49214 = NOVALUE;
    int _opt_49218 = NOVALUE;
    int _this_opt_49223 = NOVALUE;
    int _25731 = NOVALUE;
    int _25730 = NOVALUE;
    int _25727 = NOVALUE;
    int _25726 = NOVALUE;
    int _25725 = NOVALUE;
    int _25723 = NOVALUE;
    int _25722 = NOVALUE;
    int _25721 = NOVALUE;
    int _25720 = NOVALUE;
    int _25718 = NOVALUE;
    int _25717 = NOVALUE;
    int _25715 = NOVALUE;
    int _25714 = NOVALUE;
    int _25713 = NOVALUE;
    int _25712 = NOVALUE;
    int _25711 = NOVALUE;
    int _25710 = NOVALUE;
    int _25709 = NOVALUE;
    int _25707 = NOVALUE;
    int _25704 = NOVALUE;
    int _25703 = NOVALUE;
    int _25698 = NOVALUE;
    int _25696 = NOVALUE;
    int _25695 = NOVALUE;
    int _25694 = NOVALUE;
    int _25693 = NOVALUE;
    int _25692 = NOVALUE;
    int _25691 = NOVALUE;
    int _25690 = NOVALUE;
    int _25689 = NOVALUE;
    int _25685 = NOVALUE;
    int _25684 = NOVALUE;
    int _25683 = NOVALUE;
    int _25682 = NOVALUE;
    int _25681 = NOVALUE;
    int _25680 = NOVALUE;
    int _25679 = NOVALUE;
    int _25678 = NOVALUE;
    int _25677 = NOVALUE;
    int _25676 = NOVALUE;
    int _25675 = NOVALUE;
    int _25674 = NOVALUE;
    int _25673 = NOVALUE;
    int _25672 = NOVALUE;
    int _25671 = NOVALUE;
    int _25669 = NOVALUE;
    int _25668 = NOVALUE;
    int _25667 = NOVALUE;
    int _25666 = NOVALUE;
    int _25665 = NOVALUE;
    int _25664 = NOVALUE;
    int _25663 = NOVALUE;
    int _25662 = NOVALUE;
    int _25660 = NOVALUE;
    int _25659 = NOVALUE;
    int _25658 = NOVALUE;
    int _25657 = NOVALUE;
    int _25655 = NOVALUE;
    int _25654 = NOVALUE;
    int _25653 = NOVALUE;
    int _25652 = NOVALUE;
    int _25651 = NOVALUE;
    int _25650 = NOVALUE;
    int _25649 = NOVALUE;
    int _25647 = NOVALUE;
    int _25646 = NOVALUE;
    int _25644 = NOVALUE;
    int _25641 = NOVALUE;
    int _25638 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_dedupe_49120)) {
        _1 = (long)(DBL_PTR(_dedupe_49120)->dbl);
        DeRefDS(_dedupe_49120);
        _dedupe_49120 = _1;
    }

    /** 	integer i = 1*/
    _i_49121 = 1;

    /** 	while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_49117)){
            _25638 = SEQ_PTR(_a_49117)->length;
    }
    else {
        _25638 = 1;
    }
    if (_i_49121 > _25638)
    goto L2; // [22] 465

    /** 		sequence opt = a[i]*/
    DeRef(_opt_49125);
    _2 = (int)SEQ_PTR(_a_49117);
    _opt_49125 = (int)*(((s1_ptr)_2)->base + _i_49121);
    Ref(_opt_49125);

    /** 		if length(opt) < 2 then*/
    if (IS_SEQUENCE(_opt_49125)){
            _25641 = SEQ_PTR(_opt_49125)->length;
    }
    else {
        _25641 = 1;
    }
    if (_25641 >= 2)
    goto L3; // [39] 56

    /** 			i += 1*/
    _i_49121 = _i_49121 + 1;

    /** 			continue*/
    DeRefDS(_opt_49125);
    _opt_49125 = NOVALUE;
    DeRef(_this_opt_49131);
    _this_opt_49131 = NOVALUE;
    goto L1; // [53] 19
L3: 

    /** 		sequence this_opt = {}*/
    RefDS(_22037);
    DeRef(_this_opt_49131);
    _this_opt_49131 = _22037;

    /** 		integer bi = 0*/
    _bi_49132 = 0;

    /** 		if opt[2] = '-' then*/
    _2 = (int)SEQ_PTR(_opt_49125);
    _25644 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _25644, 45)){
        _25644 = NOVALUE;
        goto L4; // [74] 149
    }
    _25644 = NOVALUE;

    /** 			this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_49125)){
            _25646 = SEQ_PTR(_opt_49125)->length;
    }
    else {
        _25646 = 1;
    }
    rhs_slice_target = (object_ptr)&_25647;
    RHS_Slice(_opt_49125, 3, _25646);
    RefDS(_opts_49119);
    _0 = _this_opt_49131;
    _this_opt_49131 = _39find_opt(2, _25647, _opts_49119);
    DeRefDS(_0);
    _25647 = NOVALUE;

    /** 			for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_49118)){
            _25649 = SEQ_PTR(_b_49118)->length;
    }
    else {
        _25649 = 1;
    }
    {
        int _j_49140;
        _j_49140 = 1;
L5: 
        if (_j_49140 > _25649){
            goto L6; // [101] 146
        }

        /** 				if equal(text:lower(b[j]), text:lower(opt)) then*/
        _2 = (int)SEQ_PTR(_b_49118);
        _25650 = (int)*(((s1_ptr)_2)->base + _j_49140);
        Ref(_25650);
        _25651 = _12lower(_25650);
        _25650 = NOVALUE;
        RefDS(_opt_49125);
        _25652 = _12lower(_opt_49125);
        if (_25651 == _25652)
        _25653 = 1;
        else if (IS_ATOM_INT(_25651) && IS_ATOM_INT(_25652))
        _25653 = 0;
        else
        _25653 = (compare(_25651, _25652) == 0);
        DeRef(_25651);
        _25651 = NOVALUE;
        DeRef(_25652);
        _25652 = NOVALUE;
        if (_25653 == 0)
        {
            _25653 = NOVALUE;
            goto L7; // [126] 139
        }
        else{
            _25653 = NOVALUE;
        }

        /** 					bi = j*/
        _bi_49132 = _j_49140;

        /** 					exit*/
        goto L6; // [136] 146
L7: 

        /** 			end for*/
        _j_49140 = _j_49140 + 1;
        goto L5; // [141] 108
L6: 
        ;
    }
    goto L8; // [146] 292
L4: 

    /** 		elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (int)SEQ_PTR(_opt_49125);
    _25654 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25654)) {
        _25655 = (_25654 == 45);
    }
    else {
        _25655 = binary_op(EQUALS, _25654, 45);
    }
    _25654 = NOVALUE;
    if (IS_ATOM_INT(_25655)) {
        if (_25655 != 0) {
            goto L9; // [159] 176
        }
    }
    else {
        if (DBL_PTR(_25655)->dbl != 0.0) {
            goto L9; // [159] 176
        }
    }
    _2 = (int)SEQ_PTR(_opt_49125);
    _25657 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25657)) {
        _25658 = (_25657 == 47);
    }
    else {
        _25658 = binary_op(EQUALS, _25657, 47);
    }
    _25657 = NOVALUE;
    if (_25658 == 0) {
        DeRef(_25658);
        _25658 = NOVALUE;
        goto LA; // [172] 291
    }
    else {
        if (!IS_ATOM_INT(_25658) && DBL_PTR(_25658)->dbl == 0.0){
            DeRef(_25658);
            _25658 = NOVALUE;
            goto LA; // [172] 291
        }
        DeRef(_25658);
        _25658 = NOVALUE;
    }
    DeRef(_25658);
    _25658 = NOVALUE;
L9: 

    /** 			this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_49125)){
            _25659 = SEQ_PTR(_opt_49125)->length;
    }
    else {
        _25659 = 1;
    }
    rhs_slice_target = (object_ptr)&_25660;
    RHS_Slice(_opt_49125, 2, _25659);
    RefDS(_opts_49119);
    _0 = _this_opt_49131;
    _this_opt_49131 = _39find_opt(1, _25660, _opts_49119);
    DeRef(_0);
    _25660 = NOVALUE;

    /** 			for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_49118)){
            _25662 = SEQ_PTR(_b_49118)->length;
    }
    else {
        _25662 = 1;
    }
    {
        int _j_49157;
        _j_49157 = 1;
LB: 
        if (_j_49157 > _25662){
            goto LC; // [199] 290
        }

        /** 				if equal(text:lower(b[j]), '-' & text:lower(opt[2..$])) or */
        _2 = (int)SEQ_PTR(_b_49118);
        _25663 = (int)*(((s1_ptr)_2)->base + _j_49157);
        Ref(_25663);
        _25664 = _12lower(_25663);
        _25663 = NOVALUE;
        if (IS_SEQUENCE(_opt_49125)){
                _25665 = SEQ_PTR(_opt_49125)->length;
        }
        else {
            _25665 = 1;
        }
        rhs_slice_target = (object_ptr)&_25666;
        RHS_Slice(_opt_49125, 2, _25665);
        _25667 = _12lower(_25666);
        _25666 = NOVALUE;
        if (IS_SEQUENCE(45) && IS_ATOM(_25667)) {
        }
        else if (IS_ATOM(45) && IS_SEQUENCE(_25667)) {
            Prepend(&_25668, _25667, 45);
        }
        else {
            Concat((object_ptr)&_25668, 45, _25667);
        }
        DeRef(_25667);
        _25667 = NOVALUE;
        if (_25664 == _25668)
        _25669 = 1;
        else if (IS_ATOM_INT(_25664) && IS_ATOM_INT(_25668))
        _25669 = 0;
        else
        _25669 = (compare(_25664, _25668) == 0);
        DeRef(_25664);
        _25664 = NOVALUE;
        DeRefDS(_25668);
        _25668 = NOVALUE;
        if (_25669 != 0) {
            goto LD; // [236] 273
        }
        _2 = (int)SEQ_PTR(_b_49118);
        _25671 = (int)*(((s1_ptr)_2)->base + _j_49157);
        Ref(_25671);
        _25672 = _12lower(_25671);
        _25671 = NOVALUE;
        if (IS_SEQUENCE(_opt_49125)){
                _25673 = SEQ_PTR(_opt_49125)->length;
        }
        else {
            _25673 = 1;
        }
        rhs_slice_target = (object_ptr)&_25674;
        RHS_Slice(_opt_49125, 2, _25673);
        _25675 = _12lower(_25674);
        _25674 = NOVALUE;
        if (IS_SEQUENCE(47) && IS_ATOM(_25675)) {
        }
        else if (IS_ATOM(47) && IS_SEQUENCE(_25675)) {
            Prepend(&_25676, _25675, 47);
        }
        else {
            Concat((object_ptr)&_25676, 47, _25675);
        }
        DeRef(_25675);
        _25675 = NOVALUE;
        if (_25672 == _25676)
        _25677 = 1;
        else if (IS_ATOM_INT(_25672) && IS_ATOM_INT(_25676))
        _25677 = 0;
        else
        _25677 = (compare(_25672, _25676) == 0);
        DeRef(_25672);
        _25672 = NOVALUE;
        DeRefDS(_25676);
        _25676 = NOVALUE;
        if (_25677 == 0)
        {
            _25677 = NOVALUE;
            goto LE; // [269] 283
        }
        else{
            _25677 = NOVALUE;
        }
LD: 

        /** 					bi = j*/
        _bi_49132 = _j_49157;

        /** 					exit*/
        goto LC; // [280] 290
LE: 

        /** 			end for*/
        _j_49157 = _j_49157 + 1;
        goto LB; // [285] 206
LC: 
        ;
    }
LA: 
L8: 

    /** 		if length(this_opt) and not find(MULTIPLE, this_opt[OPTIONS]) then*/
    if (IS_SEQUENCE(_this_opt_49131)){
            _25678 = SEQ_PTR(_this_opt_49131)->length;
    }
    else {
        _25678 = 1;
    }
    if (_25678 == 0) {
        goto LF; // [297] 451
    }
    _2 = (int)SEQ_PTR(_this_opt_49131);
    _25680 = (int)*(((s1_ptr)_2)->base + 4);
    _25681 = find_from(42, _25680, 1);
    _25680 = NOVALUE;
    _25682 = (_25681 == 0);
    _25681 = NOVALUE;
    if (_25682 == 0)
    {
        DeRef(_25682);
        _25682 = NOVALUE;
        goto LF; // [316] 451
    }
    else{
        DeRef(_25682);
        _25682 = NOVALUE;
    }

    /** 			if bi then*/
    if (_bi_49132 == 0)
    {
        goto L10; // [321] 365
    }
    else{
    }

    /** 				if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_this_opt_49131);
    _25683 = (int)*(((s1_ptr)_2)->base + 4);
    _25684 = find_from(112, _25683, 1);
    _25683 = NOVALUE;
    if (_25684 == 0)
    {
        _25684 = NOVALUE;
        goto L11; // [337] 354
    }
    else{
        _25684 = NOVALUE;
    }

    /** 					a = remove(a, i, i + 1)*/
    _25685 = _i_49121 + 1;
    if (_25685 > MAXINT){
        _25685 = NewDouble((double)_25685);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_a_49117);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_49121)) ? _i_49121 : (long)(DBL_PTR(_i_49121)->dbl);
        int stop = (IS_ATOM_INT(_25685)) ? _25685 : (long)(DBL_PTR(_25685)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_49117), start, &_a_49117 );
            }
            else Tail(SEQ_PTR(_a_49117), stop+1, &_a_49117);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_49117), start, &_a_49117);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_49117 = Remove_elements(start, stop, (SEQ_PTR(_a_49117)->ref == 1));
        }
    }
    DeRef(_25685);
    _25685 = NOVALUE;
    goto L12; // [351] 458
L11: 

    /** 					a = remove(a, i)*/
    {
        s1_ptr assign_space = SEQ_PTR(_a_49117);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_49121)) ? _i_49121 : (long)(DBL_PTR(_i_49121)->dbl);
        int stop = (IS_ATOM_INT(_i_49121)) ? _i_49121 : (long)(DBL_PTR(_i_49121)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_49117), start, &_a_49117 );
            }
            else Tail(SEQ_PTR(_a_49117), stop+1, &_a_49117);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_49117), start, &_a_49117);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_49117 = Remove_elements(start, stop, (SEQ_PTR(_a_49117)->ref == 1));
        }
    }
    goto L12; // [362] 458
L10: 

    /** 				integer beginLen = length(a)*/
    if (IS_SEQUENCE(_a_49117)){
            _beginLen_49192 = SEQ_PTR(_a_49117)->length;
    }
    else {
        _beginLen_49192 = 1;
    }

    /** 				if dedupe = 0 and i < beginLen then*/
    _25689 = (_dedupe_49120 == 0);
    if (_25689 == 0) {
        goto L13; // [376] 438
    }
    _25691 = (_i_49121 < _beginLen_49192);
    if (_25691 == 0)
    {
        DeRef(_25691);
        _25691 = NOVALUE;
        goto L13; // [385] 438
    }
    else{
        DeRef(_25691);
        _25691 = NOVALUE;
    }

    /** 					a = merge_parameters( a[i + 1..$], a[1..i], opts, 1)*/
    _25692 = _i_49121 + 1;
    if (_25692 > MAXINT){
        _25692 = NewDouble((double)_25692);
    }
    if (IS_SEQUENCE(_a_49117)){
            _25693 = SEQ_PTR(_a_49117)->length;
    }
    else {
        _25693 = 1;
    }
    rhs_slice_target = (object_ptr)&_25694;
    RHS_Slice(_a_49117, _25692, _25693);
    rhs_slice_target = (object_ptr)&_25695;
    RHS_Slice(_a_49117, 1, _i_49121);
    RefDS(_opts_49119);
    DeRef(_25696);
    _25696 = _opts_49119;
    _0 = _a_49117;
    _a_49117 = _39merge_parameters(_25694, _25695, _25696, 1);
    DeRefDS(_0);
    _25694 = NOVALUE;
    _25695 = NOVALUE;
    _25696 = NOVALUE;

    /** 					if beginLen = length(a) then*/
    if (IS_SEQUENCE(_a_49117)){
            _25698 = SEQ_PTR(_a_49117)->length;
    }
    else {
        _25698 = 1;
    }
    if (_beginLen_49192 != _25698)
    goto L14; // [424] 445

    /** 						i += 1*/
    _i_49121 = _i_49121 + 1;
    goto L14; // [435] 445
L13: 

    /** 					i += 1*/
    _i_49121 = _i_49121 + 1;
L14: 
    goto L12; // [448] 458
LF: 

    /** 			i += 1*/
    _i_49121 = _i_49121 + 1;
L12: 
    DeRef(_opt_49125);
    _opt_49125 = NOVALUE;
    DeRef(_this_opt_49131);
    _this_opt_49131 = NOVALUE;

    /** 	end while*/
    goto L1; // [462] 19
L2: 

    /** 	if dedupe then*/
    if (_dedupe_49120 == 0)
    {
        goto L15; // [467] 481
    }
    else{
    }

    /** 		return b & a*/
    Concat((object_ptr)&_25703, _b_49118, _a_49117);
    DeRefDS(_a_49117);
    DeRefDS(_b_49118);
    DeRefDS(_opts_49119);
    DeRef(_25689);
    _25689 = NOVALUE;
    DeRef(_25655);
    _25655 = NOVALUE;
    DeRef(_25692);
    _25692 = NOVALUE;
    return _25703;
L15: 

    /** 	integer first_extra = 0*/
    _first_extra_49214 = 0;

    /** 	i = 1*/
    _i_49121 = 1;

    /** 	while i <= length(b) do*/
L16: 
    if (IS_SEQUENCE(_b_49118)){
            _25704 = SEQ_PTR(_b_49118)->length;
    }
    else {
        _25704 = 1;
    }
    if (_i_49121 > _25704)
    goto L17; // [499] 692

    /** 		sequence opt = b[i]*/
    DeRef(_opt_49218);
    _2 = (int)SEQ_PTR(_b_49118);
    _opt_49218 = (int)*(((s1_ptr)_2)->base + _i_49121);
    Ref(_opt_49218);

    /** 		if length(opt) <= 1 then*/
    if (IS_SEQUENCE(_opt_49218)){
            _25707 = SEQ_PTR(_opt_49218)->length;
    }
    else {
        _25707 = 1;
    }
    if (_25707 > 1)
    goto L18; // [516] 532

    /** 			first_extra = i*/
    _first_extra_49214 = _i_49121;

    /** 			exit*/
    DeRefDS(_opt_49218);
    _opt_49218 = NOVALUE;
    DeRef(_this_opt_49223);
    _this_opt_49223 = NOVALUE;
    goto L17; // [529] 692
L18: 

    /** 		sequence this_opt = {}*/
    RefDS(_22037);
    DeRef(_this_opt_49223);
    _this_opt_49223 = _22037;

    /** 		if opt[2] = '-' and opt[1] = '-' then*/
    _2 = (int)SEQ_PTR(_opt_49218);
    _25709 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_25709)) {
        _25710 = (_25709 == 45);
    }
    else {
        _25710 = binary_op(EQUALS, _25709, 45);
    }
    _25709 = NOVALUE;
    if (IS_ATOM_INT(_25710)) {
        if (_25710 == 0) {
            goto L19; // [549] 586
        }
    }
    else {
        if (DBL_PTR(_25710)->dbl == 0.0) {
            goto L19; // [549] 586
        }
    }
    _2 = (int)SEQ_PTR(_opt_49218);
    _25712 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25712)) {
        _25713 = (_25712 == 45);
    }
    else {
        _25713 = binary_op(EQUALS, _25712, 45);
    }
    _25712 = NOVALUE;
    if (_25713 == 0) {
        DeRef(_25713);
        _25713 = NOVALUE;
        goto L19; // [562] 586
    }
    else {
        if (!IS_ATOM_INT(_25713) && DBL_PTR(_25713)->dbl == 0.0){
            DeRef(_25713);
            _25713 = NOVALUE;
            goto L19; // [562] 586
        }
        DeRef(_25713);
        _25713 = NOVALUE;
    }
    DeRef(_25713);
    _25713 = NOVALUE;

    /** 			this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_49218)){
            _25714 = SEQ_PTR(_opt_49218)->length;
    }
    else {
        _25714 = 1;
    }
    rhs_slice_target = (object_ptr)&_25715;
    RHS_Slice(_opt_49218, 3, _25714);
    RefDS(_opts_49119);
    _0 = _this_opt_49223;
    _this_opt_49223 = _39find_opt(2, _25715, _opts_49119);
    DeRef(_0);
    _25715 = NOVALUE;
    goto L1A; // [583] 633
L19: 

    /** 		elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (int)SEQ_PTR(_opt_49218);
    _25717 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25717)) {
        _25718 = (_25717 == 45);
    }
    else {
        _25718 = binary_op(EQUALS, _25717, 45);
    }
    _25717 = NOVALUE;
    if (IS_ATOM_INT(_25718)) {
        if (_25718 != 0) {
            goto L1B; // [596] 613
        }
    }
    else {
        if (DBL_PTR(_25718)->dbl != 0.0) {
            goto L1B; // [596] 613
        }
    }
    _2 = (int)SEQ_PTR(_opt_49218);
    _25720 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25720)) {
        _25721 = (_25720 == 47);
    }
    else {
        _25721 = binary_op(EQUALS, _25720, 47);
    }
    _25720 = NOVALUE;
    if (_25721 == 0) {
        DeRef(_25721);
        _25721 = NOVALUE;
        goto L1C; // [609] 632
    }
    else {
        if (!IS_ATOM_INT(_25721) && DBL_PTR(_25721)->dbl == 0.0){
            DeRef(_25721);
            _25721 = NOVALUE;
            goto L1C; // [609] 632
        }
        DeRef(_25721);
        _25721 = NOVALUE;
    }
    DeRef(_25721);
    _25721 = NOVALUE;
L1B: 

    /** 			this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_49218)){
            _25722 = SEQ_PTR(_opt_49218)->length;
    }
    else {
        _25722 = 1;
    }
    rhs_slice_target = (object_ptr)&_25723;
    RHS_Slice(_opt_49218, 2, _25722);
    RefDS(_opts_49119);
    _0 = _this_opt_49223;
    _this_opt_49223 = _39find_opt(1, _25723, _opts_49119);
    DeRef(_0);
    _25723 = NOVALUE;
L1C: 
L1A: 

    /** 		if length(this_opt) then*/
    if (IS_SEQUENCE(_this_opt_49223)){
            _25725 = SEQ_PTR(_this_opt_49223)->length;
    }
    else {
        _25725 = 1;
    }
    if (_25725 == 0)
    {
        _25725 = NOVALUE;
        goto L1D; // [638] 667
    }
    else{
        _25725 = NOVALUE;
    }

    /** 			if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_this_opt_49223);
    _25726 = (int)*(((s1_ptr)_2)->base + 4);
    _25727 = find_from(112, _25726, 1);
    _25726 = NOVALUE;
    if (_25727 == 0)
    {
        _25727 = NOVALUE;
        goto L1E; // [654] 679
    }
    else{
        _25727 = NOVALUE;
    }

    /** 				i += 1*/
    _i_49121 = _i_49121 + 1;
    goto L1E; // [664] 679
L1D: 

    /** 			first_extra = i*/
    _first_extra_49214 = _i_49121;

    /** 			exit*/
    DeRef(_opt_49218);
    _opt_49218 = NOVALUE;
    DeRef(_this_opt_49223);
    _this_opt_49223 = NOVALUE;
    goto L17; // [676] 692
L1E: 

    /** 		i += 1*/
    _i_49121 = _i_49121 + 1;
    DeRef(_opt_49218);
    _opt_49218 = NOVALUE;
    DeRef(_this_opt_49223);
    _this_opt_49223 = NOVALUE;

    /** 	end while*/
    goto L16; // [689] 496
L17: 

    /** 	if first_extra then*/
    if (_first_extra_49214 == 0)
    {
        goto L1F; // [694] 709
    }
    else{
    }

    /** 		return splice(b, a, first_extra)*/
    {
        s1_ptr assign_space;
        insert_pos = _first_extra_49214;
        if (insert_pos <= 0) {
            Concat(&_25730,_a_49117,_b_49118);
        }
        else if (insert_pos > SEQ_PTR(_b_49118)->length){
            Concat(&_25730,_b_49118,_a_49117);
        }
        else if (IS_SEQUENCE(_a_49117)) {
            if( _25730 != _b_49118 || SEQ_PTR( _b_49118 )->ref != 1 ){
                DeRef( _25730 );
                RefDS( _b_49118 );
            }
            assign_space = Add_internal_space( _b_49118, insert_pos,((s1_ptr)SEQ_PTR(_a_49117))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_a_49117), _b_49118 == _25730 );
            _25730 = MAKE_SEQ( assign_space );
        }
        else {
            if( _25730 != _b_49118 && SEQ_PTR( _b_49118 )->ref != 1 ){
                _25730 = Insert( _b_49118, _a_49117, insert_pos);
            }
            else {
                DeRef( _25730 );
                RefDS( _b_49118 );
                _25730 = Insert( _b_49118, _a_49117, insert_pos);
            }
        }
    }
    DeRefDS(_a_49117);
    DeRefDS(_b_49118);
    DeRefDS(_opts_49119);
    DeRef(_25689);
    _25689 = NOVALUE;
    DeRef(_25655);
    _25655 = NOVALUE;
    DeRef(_25692);
    _25692 = NOVALUE;
    DeRef(_25703);
    _25703 = NOVALUE;
    DeRef(_25710);
    _25710 = NOVALUE;
    DeRef(_25718);
    _25718 = NOVALUE;
    return _25730;
L1F: 

    /** 	return b & a*/
    Concat((object_ptr)&_25731, _b_49118, _a_49117);
    DeRefDS(_a_49117);
    DeRefDS(_b_49118);
    DeRefDS(_opts_49119);
    DeRef(_25689);
    _25689 = NOVALUE;
    DeRef(_25655);
    _25655 = NOVALUE;
    DeRef(_25692);
    _25692 = NOVALUE;
    DeRef(_25703);
    _25703 = NOVALUE;
    DeRef(_25730);
    _25730 = NOVALUE;
    DeRef(_25710);
    _25710 = NOVALUE;
    DeRef(_25718);
    _25718 = NOVALUE;
    return _25731;
    ;
}


int _39validate_opt(int _opt_type_49256, int _arg_49257, int _args_49258, int _ix_49259)
{
    int _opt_49260 = NOVALUE;
    int _this_opt_49268 = NOVALUE;
    int _25750 = NOVALUE;
    int _25749 = NOVALUE;
    int _25748 = NOVALUE;
    int _25747 = NOVALUE;
    int _25746 = NOVALUE;
    int _25744 = NOVALUE;
    int _25743 = NOVALUE;
    int _25742 = NOVALUE;
    int _25741 = NOVALUE;
    int _25740 = NOVALUE;
    int _25738 = NOVALUE;
    int _25735 = NOVALUE;
    int _25733 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if opt_type = SHORTNAME then*/
    if (_opt_type_49256 != 1)
    goto L1; // [11] 28

    /** 		opt = arg[2..$]*/
    if (IS_SEQUENCE(_arg_49257)){
            _25733 = SEQ_PTR(_arg_49257)->length;
    }
    else {
        _25733 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_49260;
    RHS_Slice(_arg_49257, 2, _25733);
    goto L2; // [25] 39
L1: 

    /** 		opt = arg[3..$]*/
    if (IS_SEQUENCE(_arg_49257)){
            _25735 = SEQ_PTR(_arg_49257)->length;
    }
    else {
        _25735 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_49260;
    RHS_Slice(_arg_49257, 3, _25735);
L2: 

    /** 	sequence this_opt = find_opt( opt_type, opt, options )*/
    RefDS(_opt_49260);
    RefDS(_39options_48999);
    _0 = _this_opt_49268;
    _this_opt_49268 = _39find_opt(_opt_type_49256, _opt_49260, _39options_48999);
    DeRef(_0);

    /** 	if not length( this_opt ) then*/
    if (IS_SEQUENCE(_this_opt_49268)){
            _25738 = SEQ_PTR(_this_opt_49268)->length;
    }
    else {
        _25738 = 1;
    }
    if (_25738 != 0)
    goto L3; // [58] 72
    _25738 = NOVALUE;

    /** 		return { 0, 0 }*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _25740 = MAKE_SEQ(_1);
    DeRefDS(_arg_49257);
    DeRefDS(_args_49258);
    DeRefDS(_opt_49260);
    DeRefDS(_this_opt_49268);
    return _25740;
L3: 

    /** 	if find( HAS_PARAMETER, this_opt[OPTIONS] ) then*/
    _2 = (int)SEQ_PTR(_this_opt_49268);
    _25741 = (int)*(((s1_ptr)_2)->base + 4);
    _25742 = find_from(112, _25741, 1);
    _25741 = NOVALUE;
    if (_25742 == 0)
    {
        _25742 = NOVALUE;
        goto L4; // [85] 135
    }
    else{
        _25742 = NOVALUE;
    }

    /** 		if ix = length( args ) - 1 then*/
    if (IS_SEQUENCE(_args_49258)){
            _25743 = SEQ_PTR(_args_49258)->length;
    }
    else {
        _25743 = 1;
    }
    _25744 = _25743 - 1;
    _25743 = NOVALUE;
    if (_ix_49259 != _25744)
    goto L5; // [97] 117

    /** 			CompileErr( MISSING_CMD_PARAMETER, { arg } )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_arg_49257);
    *((int *)(_2+4)) = _arg_49257;
    _25746 = MAKE_SEQ(_1);
    _43CompileErr(353, _25746, 0);
    _25746 = NOVALUE;
    goto L6; // [114] 150
L5: 

    /** 			return { ix, ix + 2 }*/
    _25747 = _ix_49259 + 2;
    if ((long)((unsigned long)_25747 + (unsigned long)HIGH_BITS) >= 0) 
    _25747 = NewDouble((double)_25747);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _ix_49259;
    ((int *)_2)[2] = _25747;
    _25748 = MAKE_SEQ(_1);
    _25747 = NOVALUE;
    DeRefDS(_arg_49257);
    DeRefDS(_args_49258);
    DeRef(_opt_49260);
    DeRef(_this_opt_49268);
    DeRef(_25740);
    _25740 = NOVALUE;
    DeRef(_25744);
    _25744 = NOVALUE;
    return _25748;
    goto L6; // [132] 150
L4: 

    /** 		return { ix, ix + 1 }*/
    _25749 = _ix_49259 + 1;
    if (_25749 > MAXINT){
        _25749 = NewDouble((double)_25749);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _ix_49259;
    ((int *)_2)[2] = _25749;
    _25750 = MAKE_SEQ(_1);
    _25749 = NOVALUE;
    DeRefDS(_arg_49257);
    DeRefDS(_args_49258);
    DeRef(_opt_49260);
    DeRef(_this_opt_49268);
    DeRef(_25740);
    _25740 = NOVALUE;
    DeRef(_25744);
    _25744 = NOVALUE;
    DeRef(_25748);
    _25748 = NOVALUE;
    return _25750;
L6: 
    ;
}


int _39find_next_opt(int _ix_49293, int _args_49294)
{
    int _arg_49298 = NOVALUE;
    int _25772 = NOVALUE;
    int _25771 = NOVALUE;
    int _25769 = NOVALUE;
    int _25768 = NOVALUE;
    int _25767 = NOVALUE;
    int _25766 = NOVALUE;
    int _25765 = NOVALUE;
    int _25764 = NOVALUE;
    int _25763 = NOVALUE;
    int _25762 = NOVALUE;
    int _25760 = NOVALUE;
    int _25758 = NOVALUE;
    int _25756 = NOVALUE;
    int _25754 = NOVALUE;
    int _25751 = NOVALUE;
    int _0, _1, _2;
    

    /** 	while ix < length( args ) do*/
L1: 
    if (IS_SEQUENCE(_args_49294)){
            _25751 = SEQ_PTR(_args_49294)->length;
    }
    else {
        _25751 = 1;
    }
    if (_ix_49293 >= _25751)
    goto L2; // [13] 157

    /** 		sequence arg = args[ix]*/
    DeRef(_arg_49298);
    _2 = (int)SEQ_PTR(_args_49294);
    _arg_49298 = (int)*(((s1_ptr)_2)->base + _ix_49293);
    Ref(_arg_49298);

    /** 		if length( arg ) > 1 then*/
    if (IS_SEQUENCE(_arg_49298)){
            _25754 = SEQ_PTR(_arg_49298)->length;
    }
    else {
        _25754 = 1;
    }
    if (_25754 <= 1)
    goto L3; // [30] 129

    /** 			if arg[1] = '-' then*/
    _2 = (int)SEQ_PTR(_arg_49298);
    _25756 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _25756, 45)){
        _25756 = NOVALUE;
        goto L4; // [40] 111
    }
    _25756 = NOVALUE;

    /** 				if arg[2] = '-' then*/
    _2 = (int)SEQ_PTR(_arg_49298);
    _25758 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _25758, 45)){
        _25758 = NOVALUE;
        goto L5; // [50] 94
    }
    _25758 = NOVALUE;

    /** 					if length( arg ) = 2 then*/
    if (IS_SEQUENCE(_arg_49298)){
            _25760 = SEQ_PTR(_arg_49298)->length;
    }
    else {
        _25760 = 1;
    }
    if (_25760 != 2)
    goto L6; // [59] 78

    /** 						return { 0, ix - 1 }*/
    _25762 = _ix_49293 - 1;
    if ((long)((unsigned long)_25762 +(unsigned long) HIGH_BITS) >= 0){
        _25762 = NewDouble((double)_25762);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _25762;
    _25763 = MAKE_SEQ(_1);
    _25762 = NOVALUE;
    DeRefDS(_arg_49298);
    DeRefDS(_args_49294);
    return _25763;
L6: 

    /** 					return validate_opt( LONGNAME, arg, args, ix )*/
    RefDS(_arg_49298);
    RefDS(_args_49294);
    _25764 = _39validate_opt(2, _arg_49298, _args_49294, _ix_49293);
    DeRefDS(_arg_49298);
    DeRefDS(_args_49294);
    DeRef(_25763);
    _25763 = NOVALUE;
    return _25764;
    goto L7; // [91] 144
L5: 

    /** 					return validate_opt( SHORTNAME, arg, args, ix )*/
    RefDS(_arg_49298);
    RefDS(_args_49294);
    _25765 = _39validate_opt(1, _arg_49298, _args_49294, _ix_49293);
    DeRefDS(_arg_49298);
    DeRefDS(_args_49294);
    DeRef(_25763);
    _25763 = NOVALUE;
    DeRef(_25764);
    _25764 = NOVALUE;
    return _25765;
    goto L7; // [108] 144
L4: 

    /** 				return {0, ix-1}*/
    _25766 = _ix_49293 - 1;
    if ((long)((unsigned long)_25766 +(unsigned long) HIGH_BITS) >= 0){
        _25766 = NewDouble((double)_25766);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _25766;
    _25767 = MAKE_SEQ(_1);
    _25766 = NOVALUE;
    DeRef(_arg_49298);
    DeRefDS(_args_49294);
    DeRef(_25763);
    _25763 = NOVALUE;
    DeRef(_25764);
    _25764 = NOVALUE;
    DeRef(_25765);
    _25765 = NOVALUE;
    return _25767;
    goto L7; // [126] 144
L3: 

    /** 			return { 0, ix-1 }*/
    _25768 = _ix_49293 - 1;
    if ((long)((unsigned long)_25768 +(unsigned long) HIGH_BITS) >= 0){
        _25768 = NewDouble((double)_25768);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _25768;
    _25769 = MAKE_SEQ(_1);
    _25768 = NOVALUE;
    DeRef(_arg_49298);
    DeRefDS(_args_49294);
    DeRef(_25763);
    _25763 = NOVALUE;
    DeRef(_25764);
    _25764 = NOVALUE;
    DeRef(_25765);
    _25765 = NOVALUE;
    DeRef(_25767);
    _25767 = NOVALUE;
    return _25769;
L7: 

    /** 		ix += 1*/
    _ix_49293 = _ix_49293 + 1;
    DeRef(_arg_49298);
    _arg_49298 = NOVALUE;

    /** 	end while*/
    goto L1; // [154] 10
L2: 

    /** 	return {0, ix-1}*/
    _25771 = _ix_49293 - 1;
    if ((long)((unsigned long)_25771 +(unsigned long) HIGH_BITS) >= 0){
        _25771 = NewDouble((double)_25771);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _25771;
    _25772 = MAKE_SEQ(_1);
    _25771 = NOVALUE;
    DeRefDS(_args_49294);
    DeRef(_25763);
    _25763 = NOVALUE;
    DeRef(_25764);
    _25764 = NOVALUE;
    DeRef(_25765);
    _25765 = NOVALUE;
    DeRef(_25767);
    _25767 = NOVALUE;
    DeRef(_25769);
    _25769 = NOVALUE;
    return _25772;
    ;
}


int _39expand_config_options(int _args_49328)
{
    int _idx_49329 = NOVALUE;
    int _next_idx_49330 = NOVALUE;
    int _files_49331 = NOVALUE;
    int _cmd_1_2_49332 = NOVALUE;
    int _25795 = NOVALUE;
    int _25794 = NOVALUE;
    int _25793 = NOVALUE;
    int _25792 = NOVALUE;
    int _25791 = NOVALUE;
    int _25790 = NOVALUE;
    int _25789 = NOVALUE;
    int _25788 = NOVALUE;
    int _25787 = NOVALUE;
    int _25782 = NOVALUE;
    int _25780 = NOVALUE;
    int _25779 = NOVALUE;
    int _25778 = NOVALUE;
    int _25776 = NOVALUE;
    int _25775 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer idx = 1*/
    _idx_49329 = 1;

    /** 	sequence files = {}*/
    RefDS(_22037);
    DeRef(_files_49331);
    _files_49331 = _22037;

    /** 	sequence cmd_1_2 = args[1..2]*/
    rhs_slice_target = (object_ptr)&_cmd_1_2_49332;
    RHS_Slice(_args_49328, 1, 2);

    /** 	args = remove( args, 1, 2 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_args_49328);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1)) ? 1 : (long)(DBL_PTR(1)->dbl);
        int stop = (IS_ATOM_INT(2)) ? 2 : (long)(DBL_PTR(2)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_49328), start, &_args_49328 );
            }
            else Tail(SEQ_PTR(_args_49328), stop+1, &_args_49328);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_49328), start, &_args_49328);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_49328 = Remove_elements(start, stop, (SEQ_PTR(_args_49328)->ref == 1));
        }
    }

    /** 	while idx with entry do*/
    goto L1; // [31] 94
L2: 
    if (_idx_49329 == 0)
    {
        goto L3; // [34] 114
    }
    else{
    }

    /** 		if equal(upper(args[idx]), "-C") then*/
    _2 = (int)SEQ_PTR(_args_49328);
    _25775 = (int)*(((s1_ptr)_2)->base + _idx_49329);
    Ref(_25775);
    _25776 = _12upper(_25775);
    _25775 = NOVALUE;
    if (_25776 == _25777)
    _25778 = 1;
    else if (IS_ATOM_INT(_25776) && IS_ATOM_INT(_25777))
    _25778 = 0;
    else
    _25778 = (compare(_25776, _25777) == 0);
    DeRef(_25776);
    _25776 = NOVALUE;
    if (_25778 == 0)
    {
        _25778 = NOVALUE;
        goto L4; // [51] 82
    }
    else{
        _25778 = NOVALUE;
    }

    /** 			files = append( files, args[idx+1] )*/
    _25779 = _idx_49329 + 1;
    _2 = (int)SEQ_PTR(_args_49328);
    _25780 = (int)*(((s1_ptr)_2)->base + _25779);
    Ref(_25780);
    Append(&_files_49331, _files_49331, _25780);
    _25780 = NOVALUE;

    /** 			args = remove( args, idx, idx + 1 )*/
    _25782 = _idx_49329 + 1;
    if (_25782 > MAXINT){
        _25782 = NewDouble((double)_25782);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_args_49328);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_idx_49329)) ? _idx_49329 : (long)(DBL_PTR(_idx_49329)->dbl);
        int stop = (IS_ATOM_INT(_25782)) ? _25782 : (long)(DBL_PTR(_25782)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_49328), start, &_args_49328 );
            }
            else Tail(SEQ_PTR(_args_49328), stop+1, &_args_49328);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_49328), start, &_args_49328);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_49328 = Remove_elements(start, stop, (SEQ_PTR(_args_49328)->ref == 1));
        }
    }
    DeRef(_25782);
    _25782 = NOVALUE;
    goto L5; // [79] 91
L4: 

    /** 			idx = next_idx[2]*/
    _2 = (int)SEQ_PTR(_next_idx_49330);
    _idx_49329 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_idx_49329))
    _idx_49329 = (long)DBL_PTR(_idx_49329)->dbl;
L5: 

    /** 	entry*/
L1: 

    /** 		next_idx = find_next_opt( idx, args )*/
    RefDS(_args_49328);
    _0 = _next_idx_49330;
    _next_idx_49330 = _39find_next_opt(_idx_49329, _args_49328);
    DeRef(_0);

    /** 		idx = next_idx[1]*/
    _2 = (int)SEQ_PTR(_next_idx_49330);
    _idx_49329 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_idx_49329))
    _idx_49329 = (long)DBL_PTR(_idx_49329)->dbl;

    /** 	end while*/
    goto L2; // [111] 34
L3: 

    /** 	return cmd_1_2 & merge_parameters( GetDefaultArgs( files ), args[1..next_idx[2]], options, 1 ) & args[next_idx[2]+1..$]*/
    RefDS(_files_49331);
    _25787 = _38GetDefaultArgs(_files_49331);
    _2 = (int)SEQ_PTR(_next_idx_49330);
    _25788 = (int)*(((s1_ptr)_2)->base + 2);
    rhs_slice_target = (object_ptr)&_25789;
    RHS_Slice(_args_49328, 1, _25788);
    RefDS(_39options_48999);
    _25790 = _39merge_parameters(_25787, _25789, _39options_48999, 1);
    _25787 = NOVALUE;
    _25789 = NOVALUE;
    _2 = (int)SEQ_PTR(_next_idx_49330);
    _25791 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_25791)) {
        _25792 = _25791 + 1;
        if (_25792 > MAXINT){
            _25792 = NewDouble((double)_25792);
        }
    }
    else
    _25792 = binary_op(PLUS, 1, _25791);
    _25791 = NOVALUE;
    if (IS_SEQUENCE(_args_49328)){
            _25793 = SEQ_PTR(_args_49328)->length;
    }
    else {
        _25793 = 1;
    }
    rhs_slice_target = (object_ptr)&_25794;
    RHS_Slice(_args_49328, _25792, _25793);
    {
        int concat_list[3];

        concat_list[0] = _25794;
        concat_list[1] = _25790;
        concat_list[2] = _cmd_1_2_49332;
        Concat_N((object_ptr)&_25795, concat_list, 3);
    }
    DeRefDS(_25794);
    _25794 = NOVALUE;
    DeRef(_25790);
    _25790 = NOVALUE;
    DeRefDS(_args_49328);
    DeRefDS(_next_idx_49330);
    DeRefDS(_files_49331);
    DeRefDS(_cmd_1_2_49332);
    DeRef(_25779);
    _25779 = NOVALUE;
    _25788 = NOVALUE;
    DeRef(_25792);
    _25792 = NOVALUE;
    return _25795;
    ;
}


void _39handle_common_options(int _opts_49363)
{
    int _opt_keys_49364 = NOVALUE;
    int _option_w_49366 = NOVALUE;
    int _key_49370 = NOVALUE;
    int _val_49372 = NOVALUE;
    int _this_warn_49418 = NOVALUE;
    int _auto_add_warn_49420 = NOVALUE;
    int _n_49426 = NOVALUE;
    int _this_warn_49449 = NOVALUE;
    int _auto_add_warn_49451 = NOVALUE;
    int _n_49457 = NOVALUE;
    int _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49493 = NOVALUE;
    int _prompt_inlined_maybe_any_key_at_615_49492 = NOVALUE;
    int _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49505 = NOVALUE;
    int _prompt_inlined_maybe_any_key_at_689_49504 = NOVALUE;
    int _25848 = NOVALUE;
    int _25847 = NOVALUE;
    int _25846 = NOVALUE;
    int _25845 = NOVALUE;
    int _25844 = NOVALUE;
    int _25843 = NOVALUE;
    int _25842 = NOVALUE;
    int _25841 = NOVALUE;
    int _25840 = NOVALUE;
    int _25838 = NOVALUE;
    int _25836 = NOVALUE;
    int _25835 = NOVALUE;
    int _25834 = NOVALUE;
    int _25829 = NOVALUE;
    int _25827 = NOVALUE;
    int _25825 = NOVALUE;
    int _25822 = NOVALUE;
    int _25821 = NOVALUE;
    int _25816 = NOVALUE;
    int _25814 = NOVALUE;
    int _25812 = NOVALUE;
    int _25810 = NOVALUE;
    int _25809 = NOVALUE;
    int _25808 = NOVALUE;
    int _25807 = NOVALUE;
    int _25806 = NOVALUE;
    int _25805 = NOVALUE;
    int _25803 = NOVALUE;
    int _25802 = NOVALUE;
    int _25797 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence opt_keys = m:keys(opts)*/
    Ref(_opts_49363);
    _0 = _opt_keys_49364;
    _opt_keys_49364 = _32keys(_opts_49363, 0);
    DeRef(_0);

    /** 	integer option_w = 0*/
    _option_w_49366 = 0;

    /** 	for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_49364)){
            _25797 = SEQ_PTR(_opt_keys_49364)->length;
    }
    else {
        _25797 = 1;
    }
    {
        int _idx_49368;
        _idx_49368 = 1;
L1: 
        if (_idx_49368 > _25797){
            goto L2; // [20] 731
        }

        /** 		sequence key = opt_keys[idx]*/
        DeRef(_key_49370);
        _2 = (int)SEQ_PTR(_opt_keys_49364);
        _key_49370 = (int)*(((s1_ptr)_2)->base + _idx_49368);
        Ref(_key_49370);

        /** 		object val = m:get(opts, key)*/
        Ref(_opts_49363);
        RefDS(_key_49370);
        _0 = _val_49372;
        _val_49372 = _32get(_opts_49363, _key_49370, 0);
        DeRef(_0);

        /** 		switch key do*/
        _1 = find(_key_49370, _25800);
        switch ( _1 ){ 

            /** 			case "i" then*/
            case 1:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_49372)){
                    _25802 = SEQ_PTR(_val_49372)->length;
            }
            else {
                _25802 = 1;
            }
            {
                int _i_49378;
                _i_49378 = 1;
L3: 
                if (_i_49378 > _25802){
                    goto L4; // [59] 82
                }

                /** 					add_include_directory(val[i])*/
                _2 = (int)SEQ_PTR(_val_49372);
                _25803 = (int)*(((s1_ptr)_2)->base + _i_49378);
                Ref(_25803);
                _38add_include_directory(_25803);
                _25803 = NOVALUE;

                /** 				end for*/
                _i_49378 = _i_49378 + 1;
                goto L3; // [77] 66
L4: 
                ;
            }
            goto L5; // [82] 722

            /** 			case "d" then*/
            case 2:

            /** 				OpDefines &= val*/
            if (IS_SEQUENCE(_26OpDefines_12056) && IS_ATOM(_val_49372)) {
                Ref(_val_49372);
                Append(&_26OpDefines_12056, _26OpDefines_12056, _val_49372);
            }
            else if (IS_ATOM(_26OpDefines_12056) && IS_SEQUENCE(_val_49372)) {
            }
            else {
                Concat((object_ptr)&_26OpDefines_12056, _26OpDefines_12056, _val_49372);
            }
            goto L5; // [98] 722

            /** 			case "batch" then*/
            case 3:

            /** 				batch_job = 1*/
            _26batch_job_11995 = 1;
            goto L5; // [111] 722

            /** 			case "test" then*/
            case 4:

            /** 				test_only = 1*/
            _26test_only_11994 = 1;
            goto L5; // [124] 722

            /** 			case "strict" then*/
            case 5:

            /** 				Strict_is_on = 1*/
            _26Strict_is_on_12048 = 1;
            goto L5; // [137] 722

            /** 			case "p" then*/
            case 6:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_49372)){
                    _25805 = SEQ_PTR(_val_49372)->length;
            }
            else {
                _25805 = 1;
            }
            {
                int _i_49393;
                _i_49393 = 1;
L6: 
                if (_i_49393 > _25805){
                    goto L7; // [148] 173
                }

                /** 					add_preprocessor(val[i])*/
                _2 = (int)SEQ_PTR(_val_49372);
                _25806 = (int)*(((s1_ptr)_2)->base + _i_49393);
                Ref(_25806);
                _63add_preprocessor(_25806, 0, 0);
                _25806 = NOVALUE;

                /** 				end for*/
                _i_49393 = _i_49393 + 1;
                goto L6; // [168] 155
L7: 
                ;
            }
            goto L5; // [173] 722

            /** 			case "pf" then*/
            case 7:

            /** 				force_preprocessor = 1*/
            _27force_preprocessor_10941 = 1;
            goto L5; // [186] 722

            /** 			case "l" then*/
            case 8:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_49372)){
                    _25807 = SEQ_PTR(_val_49372)->length;
            }
            else {
                _25807 = 1;
            }
            {
                int _i_49401;
                _i_49401 = 1;
L8: 
                if (_i_49401 > _25807){
                    goto L9; // [197] 238
                }

                /** 					LocalizeQual = append(LocalizeQual, (filter(lower(val[i]), STDFLTR_ALPHA)))*/
                _2 = (int)SEQ_PTR(_val_49372);
                _25808 = (int)*(((s1_ptr)_2)->base + _i_49401);
                Ref(_25808);
                _25809 = _12lower(_25808);
                _25808 = NOVALUE;
                RefDS(_22037);
                RefDS(_5);
                _25810 = _23filter(_25809, _23STDFLTR_ALPHA_6440, _22037, _5);
                _25809 = NOVALUE;
                Ref(_25810);
                Append(&_27LocalizeQual_10942, _27LocalizeQual_10942, _25810);
                DeRef(_25810);
                _25810 = NOVALUE;

                /** 				end for*/
                _i_49401 = _i_49401 + 1;
                goto L8; // [233] 204
L9: 
                ;
            }
            goto L5; // [238] 722

            /** 			case "ldb" then*/
            case 9:

            /** 				LocalDB = val*/
            Ref(_val_49372);
            DeRef(_27LocalDB_10943);
            _27LocalDB_10943 = _val_49372;
            goto L5; // [251] 722

            /** 			case "w" then*/
            case 10:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_49372)){
                    _25812 = SEQ_PTR(_val_49372)->length;
            }
            else {
                _25812 = 1;
            }
            {
                int _i_49416;
                _i_49416 = 1;
LA: 
                if (_i_49416 > _25812){
                    goto LB; // [262] 392
                }

                /** 					sequence this_warn = val[i]*/
                DeRef(_this_warn_49418);
                _2 = (int)SEQ_PTR(_val_49372);
                _this_warn_49418 = (int)*(((s1_ptr)_2)->base + _i_49416);
                Ref(_this_warn_49418);

                /** 					integer auto_add_warn = 0*/
                _auto_add_warn_49420 = 0;

                /** 					if this_warn[1] = '+' then*/
                _2 = (int)SEQ_PTR(_this_warn_49418);
                _25814 = (int)*(((s1_ptr)_2)->base + 1);
                if (binary_op_a(NOTEQ, _25814, 43)){
                    _25814 = NOVALUE;
                    goto LC; // [288] 308
                }
                _25814 = NOVALUE;

                /** 						auto_add_warn = 1*/
                _auto_add_warn_49420 = 1;

                /** 						this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_49418)){
                        _25816 = SEQ_PTR(_this_warn_49418)->length;
                }
                else {
                    _25816 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_49418;
                RHS_Slice(_this_warn_49418, 2, _25816);
LC: 

                /** 					integer n = find(this_warn, warning_names)*/
                _n_49426 = find_from(_this_warn_49418, _26warning_names_12027, 1);

                /** 					if n != 0 then*/
                if (_n_49426 == 0)
                goto LD; // [319] 383

                /** 						if auto_add_warn or option_w = 1 then*/
                if (_auto_add_warn_49420 != 0) {
                    goto LE; // [325] 338
                }
                _25821 = (_option_w_49366 == 1);
                if (_25821 == 0)
                {
                    DeRef(_25821);
                    _25821 = NOVALUE;
                    goto LF; // [334] 357
                }
                else{
                    DeRef(_25821);
                    _25821 = NOVALUE;
                }
LE: 

                /** 							OpWarning = or_bits(OpWarning, warning_flags[n])*/
                _2 = (int)SEQ_PTR(_26warning_flags_12025);
                _25822 = (int)*(((s1_ptr)_2)->base + _n_49426);
                {unsigned long tu;
                     tu = (unsigned long)_26OpWarning_12050 | (unsigned long)_25822;
                     _26OpWarning_12050 = MAKE_UINT(tu);
                }
                _25822 = NOVALUE;
                if (!IS_ATOM_INT(_26OpWarning_12050)) {
                    _1 = (long)(DBL_PTR(_26OpWarning_12050)->dbl);
                    DeRefDS(_26OpWarning_12050);
                    _26OpWarning_12050 = _1;
                }
                goto L10; // [354] 373
LF: 

                /** 							option_w = 1*/
                _option_w_49366 = 1;

                /** 							OpWarning = warning_flags[n]*/
                _2 = (int)SEQ_PTR(_26warning_flags_12025);
                _26OpWarning_12050 = (int)*(((s1_ptr)_2)->base + _n_49426);
L10: 

                /** 						prev_OpWarning = OpWarning*/
                _26prev_OpWarning_12051 = _26OpWarning_12050;
LD: 
                DeRef(_this_warn_49418);
                _this_warn_49418 = NOVALUE;

                /** 				end for*/
                _i_49416 = _i_49416 + 1;
                goto LA; // [387] 269
LB: 
                ;
            }
            goto L5; // [392] 722

            /** 			case "x" then*/
            case 11:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_49372)){
                    _25825 = SEQ_PTR(_val_49372)->length;
            }
            else {
                _25825 = 1;
            }
            {
                int _i_49447;
                _i_49447 = 1;
L11: 
                if (_i_49447 > _25825){
                    goto L12; // [403] 542
                }

                /** 					sequence this_warn = val[i]*/
                DeRef(_this_warn_49449);
                _2 = (int)SEQ_PTR(_val_49372);
                _this_warn_49449 = (int)*(((s1_ptr)_2)->base + _i_49447);
                Ref(_this_warn_49449);

                /** 					integer auto_add_warn = 0*/
                _auto_add_warn_49451 = 0;

                /** 					if this_warn[1] = '+' then*/
                _2 = (int)SEQ_PTR(_this_warn_49449);
                _25827 = (int)*(((s1_ptr)_2)->base + 1);
                if (binary_op_a(NOTEQ, _25827, 43)){
                    _25827 = NOVALUE;
                    goto L13; // [429] 449
                }
                _25827 = NOVALUE;

                /** 						auto_add_warn = 1*/
                _auto_add_warn_49451 = 1;

                /** 						this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_49449)){
                        _25829 = SEQ_PTR(_this_warn_49449)->length;
                }
                else {
                    _25829 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_49449;
                RHS_Slice(_this_warn_49449, 2, _25829);
L13: 

                /** 					integer n = find(this_warn, warning_names)*/
                _n_49457 = find_from(_this_warn_49449, _26warning_names_12027, 1);

                /** 					if n != 0 then*/
                if (_n_49457 == 0)
                goto L14; // [460] 533

                /** 						if auto_add_warn or option_w = -1 then*/
                if (_auto_add_warn_49451 != 0) {
                    goto L15; // [466] 479
                }
                _25834 = (_option_w_49366 == -1);
                if (_25834 == 0)
                {
                    DeRef(_25834);
                    _25834 = NOVALUE;
                    goto L16; // [475] 501
                }
                else{
                    DeRef(_25834);
                    _25834 = NOVALUE;
                }
L15: 

                /** 							OpWarning = and_bits(OpWarning, not_bits(warning_flags[n]))*/
                _2 = (int)SEQ_PTR(_26warning_flags_12025);
                _25835 = (int)*(((s1_ptr)_2)->base + _n_49457);
                _25836 = not_bits(_25835);
                _25835 = NOVALUE;
                if (IS_ATOM_INT(_25836)) {
                    {unsigned long tu;
                         tu = (unsigned long)_26OpWarning_12050 & (unsigned long)_25836;
                         _26OpWarning_12050 = MAKE_UINT(tu);
                    }
                }
                else {
                    temp_d.dbl = (double)_26OpWarning_12050;
                    _26OpWarning_12050 = Dand_bits(&temp_d, DBL_PTR(_25836));
                }
                DeRef(_25836);
                _25836 = NOVALUE;
                if (!IS_ATOM_INT(_26OpWarning_12050)) {
                    _1 = (long)(DBL_PTR(_26OpWarning_12050)->dbl);
                    DeRefDS(_26OpWarning_12050);
                    _26OpWarning_12050 = _1;
                }
                goto L17; // [498] 523
L16: 

                /** 							option_w = -1*/
                _option_w_49366 = -1;

                /** 							OpWarning = all_warning_flag - warning_flags[n]*/
                _2 = (int)SEQ_PTR(_26warning_flags_12025);
                _25838 = (int)*(((s1_ptr)_2)->base + _n_49457);
                _26OpWarning_12050 = 32767 - _25838;
                _25838 = NOVALUE;
L17: 

                /** 						prev_OpWarning = OpWarning*/
                _26prev_OpWarning_12051 = _26OpWarning_12050;
L14: 
                DeRef(_this_warn_49449);
                _this_warn_49449 = NOVALUE;

                /** 				end for*/
                _i_49447 = _i_49447 + 1;
                goto L11; // [537] 410
L12: 
                ;
            }
            goto L5; // [542] 722

            /** 			case "wf" then*/
            case 12:

            /** 				TempWarningName = val*/
            Ref(_val_49372);
            DeRef(_26TempWarningName_11996);
            _26TempWarningName_11996 = _val_49372;

            /** 			  	error:warning_file(TempWarningName)*/
            Ref(_26TempWarningName_11996);
            _5warning_file(_26TempWarningName_11996);
            goto L5; // [560] 722

            /** 			case "v", "version" then*/
            case 13:
            case 14:

            /** 				show_banner()*/
            _39show_banner();

            /** 				if not batch_job and not test_only then*/
            _25840 = (_26batch_job_11995 == 0);
            if (_25840 == 0) {
                goto L18; // [579] 632
            }
            _25842 = (_26test_only_11994 == 0);
            if (_25842 == 0)
            {
                DeRef(_25842);
                _25842 = NOVALUE;
                goto L18; // [589] 632
            }
            else{
                DeRef(_25842);
                _25842 = NOVALUE;
            }

            /** 					console:maybe_any_key(GetMsgText(278,0), 2)*/
            RefDS(_22037);
            _25843 = _44GetMsgText(278, 0, _22037);
            DeRef(_prompt_inlined_maybe_any_key_at_615_49492);
            _prompt_inlined_maybe_any_key_at_615_49492 = _25843;
            _25843 = NOVALUE;

            /** 	if not has_console() then*/

            /** 	return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49493);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49493 = machine(99, 0);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49493)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49493 != 0){
                    goto L19; // [614] 629
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49493)->dbl != 0.0){
                    goto L19; // [614] 629
                }
            }

            /** 		any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_615_49492);
            _41any_key(_prompt_inlined_maybe_any_key_at_615_49492, 2);

            /** end procedure*/
            goto L19; // [626] 629
L19: 
            DeRef(_prompt_inlined_maybe_any_key_at_615_49492);
            _prompt_inlined_maybe_any_key_at_615_49492 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49493);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49493 = NOVALUE;
L18: 

            /** 				abort(0)*/
            UserCleanup(0);
            goto L5; // [636] 722

            /** 			case "copyright" then*/
            case 15:

            /** 				show_copyrights()*/
            _39show_copyrights();

            /** 				if not batch_job and not test_only then*/
            _25844 = (_26batch_job_11995 == 0);
            if (_25844 == 0) {
                goto L1A; // [653] 706
            }
            _25846 = (_26test_only_11994 == 0);
            if (_25846 == 0)
            {
                DeRef(_25846);
                _25846 = NOVALUE;
                goto L1A; // [663] 706
            }
            else{
                DeRef(_25846);
                _25846 = NOVALUE;
            }

            /** 					console:maybe_any_key(GetMsgText(278,0), 2)*/
            RefDS(_22037);
            _25847 = _44GetMsgText(278, 0, _22037);
            DeRef(_prompt_inlined_maybe_any_key_at_689_49504);
            _prompt_inlined_maybe_any_key_at_689_49504 = _25847;
            _25847 = NOVALUE;

            /** 	if not has_console() then*/

            /** 	return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49505);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49505 = machine(99, 0);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49505)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49505 != 0){
                    goto L1B; // [688] 703
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49505)->dbl != 0.0){
                    goto L1B; // [688] 703
                }
            }

            /** 		any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_689_49504);
            _41any_key(_prompt_inlined_maybe_any_key_at_689_49504, 2);

            /** end procedure*/
            goto L1B; // [700] 703
L1B: 
            DeRef(_prompt_inlined_maybe_any_key_at_689_49504);
            _prompt_inlined_maybe_any_key_at_689_49504 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49505);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49505 = NOVALUE;
L1A: 

            /** 				abort(0)*/
            UserCleanup(0);
            goto L5; // [710] 722

            /** 			case "eudir" then*/
            case 16:

            /** 				set_eudir( val )*/
            Ref(_val_49372);
            _27set_eudir(_val_49372);
        ;}L5: 
        DeRef(_key_49370);
        _key_49370 = NOVALUE;
        DeRef(_val_49372);
        _val_49372 = NOVALUE;

        /** 	end for*/
        _idx_49368 = _idx_49368 + 1;
        goto L1; // [726] 27
L2: 
        ;
    }

    /** 	if length(LocalizeQual) = 0 then*/
    if (IS_SEQUENCE(_27LocalizeQual_10942)){
            _25848 = SEQ_PTR(_27LocalizeQual_10942)->length;
    }
    else {
        _25848 = 1;
    }
    if (_25848 != 0)
    goto L1C; // [738] 751

    /** 		LocalizeQual = {"en"}*/
    _0 = _27LocalizeQual_10942;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_25850);
    *((int *)(_2+4)) = _25850;
    _27LocalizeQual_10942 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1C: 

    /** end procedure*/
    DeRef(_opts_49363);
    DeRef(_opt_keys_49364);
    DeRef(_25840);
    _25840 = NOVALUE;
    DeRef(_25844);
    _25844 = NOVALUE;
    return;
    ;
}


void _39finalize_command_line(int _opts_49517)
{
    int _extras_49524 = NOVALUE;
    int _pairs_49529 = NOVALUE;
    int _pair_49534 = NOVALUE;
    int _25880 = NOVALUE;
    int _25878 = NOVALUE;
    int _25875 = NOVALUE;
    int _25874 = NOVALUE;
    int _25873 = NOVALUE;
    int _25872 = NOVALUE;
    int _25871 = NOVALUE;
    int _25870 = NOVALUE;
    int _25869 = NOVALUE;
    int _25868 = NOVALUE;
    int _25867 = NOVALUE;
    int _25866 = NOVALUE;
    int _25865 = NOVALUE;
    int _25864 = NOVALUE;
    int _25863 = NOVALUE;
    int _25862 = NOVALUE;
    int _25861 = NOVALUE;
    int _25860 = NOVALUE;
    int _25859 = NOVALUE;
    int _25858 = NOVALUE;
    int _25856 = NOVALUE;
    int _25853 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if Strict_is_on then -- overrides any -W/-X switches*/
    if (_26Strict_is_on_12048 == 0)
    {
        goto L1; // [5] 27
    }
    else{
    }

    /** 		OpWarning = all_warning_flag*/
    _26OpWarning_12050 = 32767;

    /** 		prev_OpWarning = OpWarning*/
    _26prev_OpWarning_12051 = 32767;
L1: 

    /** 	sequence extras = m:get(opts, cmdline:EXTRAS)*/
    Ref(_opts_49517);
    RefDS(_40EXTRAS_15467);
    _0 = _extras_49524;
    _extras_49524 = _32get(_opts_49517, _40EXTRAS_15467, 0);
    DeRef(_0);

    /** 	if length(extras) > 0 then*/
    if (IS_SEQUENCE(_extras_49524)){
            _25853 = SEQ_PTR(_extras_49524)->length;
    }
    else {
        _25853 = 1;
    }
    if (_25853 <= 0)
    goto L2; // [44] 270

    /** 		sequence pairs = m:pairs( opts )*/
    Ref(_opts_49517);
    _0 = _pairs_49529;
    _pairs_49529 = _32pairs(_opts_49517, 0);
    DeRef(_0);

    /** 		for i = 1 to length( pairs ) do*/
    if (IS_SEQUENCE(_pairs_49529)){
            _25856 = SEQ_PTR(_pairs_49529)->length;
    }
    else {
        _25856 = 1;
    }
    {
        int _i_49532;
        _i_49532 = 1;
L3: 
        if (_i_49532 > _25856){
            goto L4; // [62] 237
        }

        /** 			sequence pair = pairs[i]*/
        DeRef(_pair_49534);
        _2 = (int)SEQ_PTR(_pairs_49529);
        _pair_49534 = (int)*(((s1_ptr)_2)->base + _i_49532);
        Ref(_pair_49534);

        /** 			if equal( pair[1], cmdline:EXTRAS ) then*/
        _2 = (int)SEQ_PTR(_pair_49534);
        _25858 = (int)*(((s1_ptr)_2)->base + 1);
        if (_25858 == _40EXTRAS_15467)
        _25859 = 1;
        else if (IS_ATOM_INT(_25858) && IS_ATOM_INT(_40EXTRAS_15467))
        _25859 = 0;
        else
        _25859 = (compare(_25858, _40EXTRAS_15467) == 0);
        _25858 = NOVALUE;
        if (_25859 == 0)
        {
            _25859 = NOVALUE;
            goto L5; // [89] 99
        }
        else{
            _25859 = NOVALUE;
        }

        /** 				continue*/
        DeRefDS(_pair_49534);
        _pair_49534 = NOVALUE;
        goto L6; // [96] 232
L5: 

        /** 			pair[1] = prepend( pair[1], '-' )*/
        _2 = (int)SEQ_PTR(_pair_49534);
        _25860 = (int)*(((s1_ptr)_2)->base + 1);
        Prepend(&_25861, _25860, 45);
        _25860 = NOVALUE;
        _2 = (int)SEQ_PTR(_pair_49534);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _pair_49534 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _25861;
        if( _1 != _25861 ){
            DeRef(_1);
        }
        _25861 = NOVALUE;

        /** 			if sequence( pair[2] ) then*/
        _2 = (int)SEQ_PTR(_pair_49534);
        _25862 = (int)*(((s1_ptr)_2)->base + 2);
        _25863 = IS_SEQUENCE(_25862);
        _25862 = NOVALUE;
        if (_25863 == 0)
        {
            _25863 = NOVALUE;
            goto L7; // [122] 215
        }
        else{
            _25863 = NOVALUE;
        }

        /** 				if length( pair[2] ) and sequence( pair[2][1] ) then*/
        _2 = (int)SEQ_PTR(_pair_49534);
        _25864 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_25864)){
                _25865 = SEQ_PTR(_25864)->length;
        }
        else {
            _25865 = 1;
        }
        _25864 = NOVALUE;
        if (_25865 == 0) {
            goto L8; // [134] 203
        }
        _2 = (int)SEQ_PTR(_pair_49534);
        _25867 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_25867);
        _25868 = (int)*(((s1_ptr)_2)->base + 1);
        _25867 = NOVALUE;
        _25869 = IS_SEQUENCE(_25868);
        _25868 = NOVALUE;
        if (_25869 == 0)
        {
            _25869 = NOVALUE;
            goto L8; // [150] 203
        }
        else{
            _25869 = NOVALUE;
        }

        /** 					for j = 1 to length( pair[2] ) do*/
        _2 = (int)SEQ_PTR(_pair_49534);
        _25870 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_25870)){
                _25871 = SEQ_PTR(_25870)->length;
        }
        else {
            _25871 = 1;
        }
        _25870 = NOVALUE;
        {
            int _j_49552;
            _j_49552 = 1;
L9: 
            if (_j_49552 > _25871){
                goto LA; // [162] 200
            }

            /** 						switches &= { pair[1], pair[2][j] }*/
            _2 = (int)SEQ_PTR(_pair_49534);
            _25872 = (int)*(((s1_ptr)_2)->base + 1);
            _2 = (int)SEQ_PTR(_pair_49534);
            _25873 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_25873);
            _25874 = (int)*(((s1_ptr)_2)->base + _j_49552);
            _25873 = NOVALUE;
            Ref(_25874);
            Ref(_25872);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _25872;
            ((int *)_2)[2] = _25874;
            _25875 = MAKE_SEQ(_1);
            _25874 = NOVALUE;
            _25872 = NOVALUE;
            Concat((object_ptr)&_39switches_48896, _39switches_48896, _25875);
            DeRefDS(_25875);
            _25875 = NOVALUE;

            /** 					end for*/
            _j_49552 = _j_49552 + 1;
            goto L9; // [195] 169
LA: 
            ;
        }
        goto LB; // [200] 228
L8: 

        /** 					switches &= pair*/
        Concat((object_ptr)&_39switches_48896, _39switches_48896, _pair_49534);
        goto LB; // [212] 228
L7: 

        /** 				switches = append( switches, pair[1] )*/
        _2 = (int)SEQ_PTR(_pair_49534);
        _25878 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_25878);
        Append(&_39switches_48896, _39switches_48896, _25878);
        _25878 = NOVALUE;
LB: 
        DeRef(_pair_49534);
        _pair_49534 = NOVALUE;

        /** 		end for*/
L6: 
        _i_49532 = _i_49532 + 1;
        goto L3; // [232] 69
L4: 
        ;
    }

    /** 		Argv = Argv[2..3] & extras*/
    rhs_slice_target = (object_ptr)&_25880;
    RHS_Slice(_26Argv_11993, 2, 3);
    Concat((object_ptr)&_26Argv_11993, _25880, _extras_49524);
    DeRefDS(_25880);
    _25880 = NOVALUE;
    DeRef(_25880);
    _25880 = NOVALUE;

    /** 		Argc = length(Argv)*/
    if (IS_SEQUENCE(_26Argv_11993)){
            _26Argc_11992 = SEQ_PTR(_26Argv_11993)->length;
    }
    else {
        _26Argc_11992 = 1;
    }

    /** 		src_name = extras[1]*/
    DeRef(_39src_name_48895);
    _2 = (int)SEQ_PTR(_extras_49524);
    _39src_name_48895 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_39src_name_48895);
L2: 
    DeRef(_pairs_49529);
    _pairs_49529 = NOVALUE;

    /** end procedure*/
    DeRef(_opts_49517);
    DeRef(_extras_49524);
    _25864 = NOVALUE;
    _25870 = NOVALUE;
    return;
    ;
}



// 0x8D3558D3
