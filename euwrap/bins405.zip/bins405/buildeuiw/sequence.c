// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _23reverse(int _target_5816, int _pFrom_5817, int _pTo_5818)
{
    int _uppr_5819 = NOVALUE;
    int _n_5820 = NOVALUE;
    int _lLimit_5821 = NOVALUE;
    int _t_5822 = NOVALUE;
    int _2947 = NOVALUE;
    int _2946 = NOVALUE;
    int _2945 = NOVALUE;
    int _2943 = NOVALUE;
    int _2942 = NOVALUE;
    int _2940 = NOVALUE;
    int _2938 = NOVALUE;
    int _0, _1, _2;
    

    /** 	n = length(target)*/
    if (IS_SEQUENCE(_target_5816)){
            _n_5820 = SEQ_PTR(_target_5816)->length;
    }
    else {
        _n_5820 = 1;
    }

    /** 	if n < 2 then*/
    if (_n_5820 >= 2)
    goto L1; // [12] 23

    /** 		return target*/
    DeRef(_t_5822);
    return _target_5816;
L1: 

    /** 	if pFrom < 1 then*/
    if (_pFrom_5817 >= 1)
    goto L2; // [25] 35

    /** 		pFrom = 1*/
    _pFrom_5817 = 1;
L2: 

    /** 	if pTo < 1 then*/
    if (_pTo_5818 >= 1)
    goto L3; // [37] 48

    /** 		pTo = n + pTo*/
    _pTo_5818 = _n_5820 + _pTo_5818;
L3: 

    /** 	if pTo < pFrom or pFrom >= n then*/
    _2938 = (_pTo_5818 < _pFrom_5817);
    if (_2938 != 0) {
        goto L4; // [54] 67
    }
    _2940 = (_pFrom_5817 >= _n_5820);
    if (_2940 == 0)
    {
        DeRef(_2940);
        _2940 = NOVALUE;
        goto L5; // [63] 74
    }
    else{
        DeRef(_2940);
        _2940 = NOVALUE;
    }
L4: 

    /** 		return target*/
    DeRef(_t_5822);
    DeRef(_2938);
    _2938 = NOVALUE;
    return _target_5816;
L5: 

    /** 	if pTo > n then*/
    if (_pTo_5818 <= _n_5820)
    goto L6; // [76] 86

    /** 		pTo = n*/
    _pTo_5818 = _n_5820;
L6: 

    /** 	lLimit = floor((pFrom+pTo-1)/2)*/
    _2942 = _pFrom_5817 + _pTo_5818;
    if ((long)((unsigned long)_2942 + (unsigned long)HIGH_BITS) >= 0) 
    _2942 = NewDouble((double)_2942);
    if (IS_ATOM_INT(_2942)) {
        _2943 = _2942 - 1;
        if ((long)((unsigned long)_2943 +(unsigned long) HIGH_BITS) >= 0){
            _2943 = NewDouble((double)_2943);
        }
    }
    else {
        _2943 = NewDouble(DBL_PTR(_2942)->dbl - (double)1);
    }
    DeRef(_2942);
    _2942 = NOVALUE;
    if (IS_ATOM_INT(_2943)) {
        _lLimit_5821 = _2943 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _2943, 2);
        _lLimit_5821 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_2943);
    _2943 = NOVALUE;
    if (!IS_ATOM_INT(_lLimit_5821)) {
        _1 = (long)(DBL_PTR(_lLimit_5821)->dbl);
        DeRefDS(_lLimit_5821);
        _lLimit_5821 = _1;
    }

    /** 	t = target*/
    Ref(_target_5816);
    DeRef(_t_5822);
    _t_5822 = _target_5816;

    /** 	uppr = pTo*/
    _uppr_5819 = _pTo_5818;

    /** 	for lowr = pFrom to lLimit do*/
    _2945 = _lLimit_5821;
    {
        int _lowr_5841;
        _lowr_5841 = _pFrom_5817;
L7: 
        if (_lowr_5841 > _2945){
            goto L8; // [119] 159
        }

        /** 		t[uppr] = target[lowr]*/
        _2 = (int)SEQ_PTR(_target_5816);
        _2946 = (int)*(((s1_ptr)_2)->base + _lowr_5841);
        Ref(_2946);
        _2 = (int)SEQ_PTR(_t_5822);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_5822 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _uppr_5819);
        _1 = *(int *)_2;
        *(int *)_2 = _2946;
        if( _1 != _2946 ){
            DeRef(_1);
        }
        _2946 = NOVALUE;

        /** 		t[lowr] = target[uppr]*/
        _2 = (int)SEQ_PTR(_target_5816);
        _2947 = (int)*(((s1_ptr)_2)->base + _uppr_5819);
        Ref(_2947);
        _2 = (int)SEQ_PTR(_t_5822);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_5822 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _lowr_5841);
        _1 = *(int *)_2;
        *(int *)_2 = _2947;
        if( _1 != _2947 ){
            DeRef(_1);
        }
        _2947 = NOVALUE;

        /** 		uppr -= 1*/
        _uppr_5819 = _uppr_5819 - 1;

        /** 	end for*/
        _lowr_5841 = _lowr_5841 + 1;
        goto L7; // [154] 126
L8: 
        ;
    }

    /** 	return t*/
    DeRef(_target_5816);
    DeRef(_2938);
    _2938 = NOVALUE;
    return _t_5822;
    ;
}


int _23pad_tail(int _target_5917, int _size_5918, int _ch_5919)
{
    int _2984 = NOVALUE;
    int _2983 = NOVALUE;
    int _2982 = NOVALUE;
    int _2981 = NOVALUE;
    int _2979 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if size <= length(target) then*/
    if (IS_SEQUENCE(_target_5917)){
            _2979 = SEQ_PTR(_target_5917)->length;
    }
    else {
        _2979 = 1;
    }
    if (_size_5918 > _2979)
    goto L1; // [8] 19

    /** 		return target*/
    return _target_5917;
L1: 

    /** 	return target & repeat(ch, size - length(target))*/
    if (IS_SEQUENCE(_target_5917)){
            _2981 = SEQ_PTR(_target_5917)->length;
    }
    else {
        _2981 = 1;
    }
    _2982 = _size_5918 - _2981;
    _2981 = NOVALUE;
    _2983 = Repeat(_ch_5919, _2982);
    _2982 = NOVALUE;
    if (IS_SEQUENCE(_target_5917) && IS_ATOM(_2983)) {
    }
    else if (IS_ATOM(_target_5917) && IS_SEQUENCE(_2983)) {
        Ref(_target_5917);
        Prepend(&_2984, _2983, _target_5917);
    }
    else {
        Concat((object_ptr)&_2984, _target_5917, _2983);
    }
    DeRefDS(_2983);
    _2983 = NOVALUE;
    DeRef(_target_5917);
    return _2984;
    ;
}


int _23filter(int _source_6171, int _rid_6172, int _userdata_6173, int _rangetype_6174)
{
    int _dest_6175 = NOVALUE;
    int _idx_6176 = NOVALUE;
    int _3298 = NOVALUE;
    int _3297 = NOVALUE;
    int _3295 = NOVALUE;
    int _3294 = NOVALUE;
    int _3293 = NOVALUE;
    int _3292 = NOVALUE;
    int _3291 = NOVALUE;
    int _3288 = NOVALUE;
    int _3287 = NOVALUE;
    int _3286 = NOVALUE;
    int _3285 = NOVALUE;
    int _3282 = NOVALUE;
    int _3281 = NOVALUE;
    int _3280 = NOVALUE;
    int _3279 = NOVALUE;
    int _3278 = NOVALUE;
    int _3275 = NOVALUE;
    int _3274 = NOVALUE;
    int _3273 = NOVALUE;
    int _3272 = NOVALUE;
    int _3269 = NOVALUE;
    int _3268 = NOVALUE;
    int _3267 = NOVALUE;
    int _3266 = NOVALUE;
    int _3265 = NOVALUE;
    int _3262 = NOVALUE;
    int _3261 = NOVALUE;
    int _3260 = NOVALUE;
    int _3259 = NOVALUE;
    int _3256 = NOVALUE;
    int _3255 = NOVALUE;
    int _3254 = NOVALUE;
    int _3253 = NOVALUE;
    int _3252 = NOVALUE;
    int _3249 = NOVALUE;
    int _3248 = NOVALUE;
    int _3247 = NOVALUE;
    int _3246 = NOVALUE;
    int _3243 = NOVALUE;
    int _3242 = NOVALUE;
    int _3241 = NOVALUE;
    int _3240 = NOVALUE;
    int _3239 = NOVALUE;
    int _3236 = NOVALUE;
    int _3235 = NOVALUE;
    int _3234 = NOVALUE;
    int _3230 = NOVALUE;
    int _3227 = NOVALUE;
    int _3226 = NOVALUE;
    int _3225 = NOVALUE;
    int _3223 = NOVALUE;
    int _3222 = NOVALUE;
    int _3221 = NOVALUE;
    int _3220 = NOVALUE;
    int _3219 = NOVALUE;
    int _3216 = NOVALUE;
    int _3215 = NOVALUE;
    int _3214 = NOVALUE;
    int _3212 = NOVALUE;
    int _3211 = NOVALUE;
    int _3210 = NOVALUE;
    int _3209 = NOVALUE;
    int _3208 = NOVALUE;
    int _3205 = NOVALUE;
    int _3204 = NOVALUE;
    int _3203 = NOVALUE;
    int _3201 = NOVALUE;
    int _3200 = NOVALUE;
    int _3199 = NOVALUE;
    int _3198 = NOVALUE;
    int _3197 = NOVALUE;
    int _3194 = NOVALUE;
    int _3193 = NOVALUE;
    int _3192 = NOVALUE;
    int _3190 = NOVALUE;
    int _3189 = NOVALUE;
    int _3188 = NOVALUE;
    int _3187 = NOVALUE;
    int _3186 = NOVALUE;
    int _3184 = NOVALUE;
    int _3183 = NOVALUE;
    int _3182 = NOVALUE;
    int _3178 = NOVALUE;
    int _3175 = NOVALUE;
    int _3174 = NOVALUE;
    int _3173 = NOVALUE;
    int _3170 = NOVALUE;
    int _3167 = NOVALUE;
    int _3166 = NOVALUE;
    int _3165 = NOVALUE;
    int _3162 = NOVALUE;
    int _3159 = NOVALUE;
    int _3158 = NOVALUE;
    int _3157 = NOVALUE;
    int _3154 = NOVALUE;
    int _3151 = NOVALUE;
    int _3150 = NOVALUE;
    int _3149 = NOVALUE;
    int _3145 = NOVALUE;
    int _3142 = NOVALUE;
    int _3141 = NOVALUE;
    int _3140 = NOVALUE;
    int _3137 = NOVALUE;
    int _3134 = NOVALUE;
    int _3133 = NOVALUE;
    int _3132 = NOVALUE;
    int _3126 = NOVALUE;
    int _3124 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(source) = 0 then*/
    if (IS_SEQUENCE(_source_6171)){
            _3124 = SEQ_PTR(_source_6171)->length;
    }
    else {
        _3124 = 1;
    }
    if (_3124 != 0)
    goto L1; // [8] 19

    /** 		return source*/
    DeRefDS(_userdata_6173);
    DeRefDS(_rangetype_6174);
    DeRef(_dest_6175);
    return _source_6171;
L1: 

    /** 	dest = repeat(0, length(source))*/
    if (IS_SEQUENCE(_source_6171)){
            _3126 = SEQ_PTR(_source_6171)->length;
    }
    else {
        _3126 = 1;
    }
    DeRef(_dest_6175);
    _dest_6175 = Repeat(0, _3126);
    _3126 = NOVALUE;

    /** 	idx = 0*/
    _idx_6176 = 0;

    /** 	switch rid do*/
    _1 = find(_rid_6172, _3128);
    switch ( _1 ){ 

        /** 		case "<", "lt" then*/
        case 1:
        case 2:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_6171)){
                _3132 = SEQ_PTR(_source_6171)->length;
        }
        else {
            _3132 = 1;
        }
        {
            int _a_6188;
            _a_6188 = 1;
L2: 
            if (_a_6188 > _3132){
                goto L3; // [51] 96
            }

            /** 				if compare(source[a], userdata) < 0 then*/
            _2 = (int)SEQ_PTR(_source_6171);
            _3133 = (int)*(((s1_ptr)_2)->base + _a_6188);
            if (IS_ATOM_INT(_3133) && IS_ATOM_INT(_userdata_6173)){
                _3134 = (_3133 < _userdata_6173) ? -1 : (_3133 > _userdata_6173);
            }
            else{
                _3134 = compare(_3133, _userdata_6173);
            }
            _3133 = NOVALUE;
            if (_3134 >= 0)
            goto L4; // [68] 89

            /** 					idx += 1*/
            _idx_6176 = _idx_6176 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_6171);
            _3137 = (int)*(((s1_ptr)_2)->base + _a_6188);
            Ref(_3137);
            _2 = (int)SEQ_PTR(_dest_6175);
            _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
            _1 = *(int *)_2;
            *(int *)_2 = _3137;
            if( _1 != _3137 ){
                DeRef(_1);
            }
            _3137 = NOVALUE;
L4: 

            /** 			end for*/
            _a_6188 = _a_6188 + 1;
            goto L2; // [91] 58
L3: 
            ;
        }
        goto L5; // [96] 1304

        /** 		case "<=", "le" then*/
        case 3:
        case 4:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_6171)){
                _3140 = SEQ_PTR(_source_6171)->length;
        }
        else {
            _3140 = 1;
        }
        {
            int _a_6200;
            _a_6200 = 1;
L6: 
            if (_a_6200 > _3140){
                goto L7; // [109] 154
            }

            /** 				if compare(source[a], userdata) <= 0 then*/
            _2 = (int)SEQ_PTR(_source_6171);
            _3141 = (int)*(((s1_ptr)_2)->base + _a_6200);
            if (IS_ATOM_INT(_3141) && IS_ATOM_INT(_userdata_6173)){
                _3142 = (_3141 < _userdata_6173) ? -1 : (_3141 > _userdata_6173);
            }
            else{
                _3142 = compare(_3141, _userdata_6173);
            }
            _3141 = NOVALUE;
            if (_3142 > 0)
            goto L8; // [126] 147

            /** 					idx += 1*/
            _idx_6176 = _idx_6176 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_6171);
            _3145 = (int)*(((s1_ptr)_2)->base + _a_6200);
            Ref(_3145);
            _2 = (int)SEQ_PTR(_dest_6175);
            _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
            _1 = *(int *)_2;
            *(int *)_2 = _3145;
            if( _1 != _3145 ){
                DeRef(_1);
            }
            _3145 = NOVALUE;
L8: 

            /** 			end for*/
            _a_6200 = _a_6200 + 1;
            goto L6; // [149] 116
L7: 
            ;
        }
        goto L5; // [154] 1304

        /** 		case "=", "==", "eq" then*/
        case 5:
        case 6:
        case 7:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_6171)){
                _3149 = SEQ_PTR(_source_6171)->length;
        }
        else {
            _3149 = 1;
        }
        {
            int _a_6213;
            _a_6213 = 1;
L9: 
            if (_a_6213 > _3149){
                goto LA; // [169] 214
            }

            /** 				if compare(source[a], userdata) = 0 then*/
            _2 = (int)SEQ_PTR(_source_6171);
            _3150 = (int)*(((s1_ptr)_2)->base + _a_6213);
            if (IS_ATOM_INT(_3150) && IS_ATOM_INT(_userdata_6173)){
                _3151 = (_3150 < _userdata_6173) ? -1 : (_3150 > _userdata_6173);
            }
            else{
                _3151 = compare(_3150, _userdata_6173);
            }
            _3150 = NOVALUE;
            if (_3151 != 0)
            goto LB; // [186] 207

            /** 					idx += 1*/
            _idx_6176 = _idx_6176 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_6171);
            _3154 = (int)*(((s1_ptr)_2)->base + _a_6213);
            Ref(_3154);
            _2 = (int)SEQ_PTR(_dest_6175);
            _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
            _1 = *(int *)_2;
            *(int *)_2 = _3154;
            if( _1 != _3154 ){
                DeRef(_1);
            }
            _3154 = NOVALUE;
LB: 

            /** 			end for*/
            _a_6213 = _a_6213 + 1;
            goto L9; // [209] 176
LA: 
            ;
        }
        goto L5; // [214] 1304

        /** 		case "!=", "ne" then*/
        case 8:
        case 9:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_6171)){
                _3157 = SEQ_PTR(_source_6171)->length;
        }
        else {
            _3157 = 1;
        }
        {
            int _a_6225;
            _a_6225 = 1;
LC: 
            if (_a_6225 > _3157){
                goto LD; // [227] 272
            }

            /** 				if compare(source[a], userdata) != 0 then*/
            _2 = (int)SEQ_PTR(_source_6171);
            _3158 = (int)*(((s1_ptr)_2)->base + _a_6225);
            if (IS_ATOM_INT(_3158) && IS_ATOM_INT(_userdata_6173)){
                _3159 = (_3158 < _userdata_6173) ? -1 : (_3158 > _userdata_6173);
            }
            else{
                _3159 = compare(_3158, _userdata_6173);
            }
            _3158 = NOVALUE;
            if (_3159 == 0)
            goto LE; // [244] 265

            /** 					idx += 1*/
            _idx_6176 = _idx_6176 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_6171);
            _3162 = (int)*(((s1_ptr)_2)->base + _a_6225);
            Ref(_3162);
            _2 = (int)SEQ_PTR(_dest_6175);
            _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
            _1 = *(int *)_2;
            *(int *)_2 = _3162;
            if( _1 != _3162 ){
                DeRef(_1);
            }
            _3162 = NOVALUE;
LE: 

            /** 			end for*/
            _a_6225 = _a_6225 + 1;
            goto LC; // [267] 234
LD: 
            ;
        }
        goto L5; // [272] 1304

        /** 		case ">", "gt" then*/
        case 10:
        case 11:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_6171)){
                _3165 = SEQ_PTR(_source_6171)->length;
        }
        else {
            _3165 = 1;
        }
        {
            int _a_6237;
            _a_6237 = 1;
LF: 
            if (_a_6237 > _3165){
                goto L10; // [285] 330
            }

            /** 				if compare(source[a], userdata) > 0 then*/
            _2 = (int)SEQ_PTR(_source_6171);
            _3166 = (int)*(((s1_ptr)_2)->base + _a_6237);
            if (IS_ATOM_INT(_3166) && IS_ATOM_INT(_userdata_6173)){
                _3167 = (_3166 < _userdata_6173) ? -1 : (_3166 > _userdata_6173);
            }
            else{
                _3167 = compare(_3166, _userdata_6173);
            }
            _3166 = NOVALUE;
            if (_3167 <= 0)
            goto L11; // [302] 323

            /** 					idx += 1*/
            _idx_6176 = _idx_6176 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_6171);
            _3170 = (int)*(((s1_ptr)_2)->base + _a_6237);
            Ref(_3170);
            _2 = (int)SEQ_PTR(_dest_6175);
            _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
            _1 = *(int *)_2;
            *(int *)_2 = _3170;
            if( _1 != _3170 ){
                DeRef(_1);
            }
            _3170 = NOVALUE;
L11: 

            /** 			end for*/
            _a_6237 = _a_6237 + 1;
            goto LF; // [325] 292
L10: 
            ;
        }
        goto L5; // [330] 1304

        /** 		case ">=", "ge" then*/
        case 12:
        case 13:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_6171)){
                _3173 = SEQ_PTR(_source_6171)->length;
        }
        else {
            _3173 = 1;
        }
        {
            int _a_6249;
            _a_6249 = 1;
L12: 
            if (_a_6249 > _3173){
                goto L13; // [343] 388
            }

            /** 				if compare(source[a], userdata) >= 0 then*/
            _2 = (int)SEQ_PTR(_source_6171);
            _3174 = (int)*(((s1_ptr)_2)->base + _a_6249);
            if (IS_ATOM_INT(_3174) && IS_ATOM_INT(_userdata_6173)){
                _3175 = (_3174 < _userdata_6173) ? -1 : (_3174 > _userdata_6173);
            }
            else{
                _3175 = compare(_3174, _userdata_6173);
            }
            _3174 = NOVALUE;
            if (_3175 < 0)
            goto L14; // [360] 381

            /** 					idx += 1*/
            _idx_6176 = _idx_6176 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_6171);
            _3178 = (int)*(((s1_ptr)_2)->base + _a_6249);
            Ref(_3178);
            _2 = (int)SEQ_PTR(_dest_6175);
            _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
            _1 = *(int *)_2;
            *(int *)_2 = _3178;
            if( _1 != _3178 ){
                DeRef(_1);
            }
            _3178 = NOVALUE;
L14: 

            /** 			end for*/
            _a_6249 = _a_6249 + 1;
            goto L12; // [383] 350
L13: 
            ;
        }
        goto L5; // [388] 1304

        /** 		case "in" then*/
        case 14:

        /** 			switch rangetype do*/
        _1 = find(_rangetype_6174, _3180);
        switch ( _1 ){ 

            /** 				case "" then*/
            case 1:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6171)){
                    _3182 = SEQ_PTR(_source_6171)->length;
            }
            else {
                _3182 = 1;
            }
            {
                int _a_6263;
                _a_6263 = 1;
L15: 
                if (_a_6263 > _3182){
                    goto L16; // [410] 455
                }

                /** 						if find(source[a], userdata)  then*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3183 = (int)*(((s1_ptr)_2)->base + _a_6263);
                _3184 = find_from(_3183, _userdata_6173, 1);
                _3183 = NOVALUE;
                if (_3184 == 0)
                {
                    _3184 = NOVALUE;
                    goto L17; // [428] 448
                }
                else{
                    _3184 = NOVALUE;
                }

                /** 							idx += 1*/
                _idx_6176 = _idx_6176 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3186 = (int)*(((s1_ptr)_2)->base + _a_6263);
                Ref(_3186);
                _2 = (int)SEQ_PTR(_dest_6175);
                _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
                _1 = *(int *)_2;
                *(int *)_2 = _3186;
                if( _1 != _3186 ){
                    DeRef(_1);
                }
                _3186 = NOVALUE;
L17: 

                /** 					end for*/
                _a_6263 = _a_6263 + 1;
                goto L15; // [450] 417
L16: 
                ;
            }
            goto L5; // [455] 1304

            /** 				case "[]" then*/
            case 2:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6171)){
                    _3187 = SEQ_PTR(_source_6171)->length;
            }
            else {
                _3187 = 1;
            }
            {
                int _a_6272;
                _a_6272 = 1;
L18: 
                if (_a_6272 > _3187){
                    goto L19; // [466] 534
                }

                /** 						if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3188 = (int)*(((s1_ptr)_2)->base + _a_6272);
                _2 = (int)SEQ_PTR(_userdata_6173);
                _3189 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3188) && IS_ATOM_INT(_3189)){
                    _3190 = (_3188 < _3189) ? -1 : (_3188 > _3189);
                }
                else{
                    _3190 = compare(_3188, _3189);
                }
                _3188 = NOVALUE;
                _3189 = NOVALUE;
                if (_3190 < 0)
                goto L1A; // [487] 527

                /** 							if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3192 = (int)*(((s1_ptr)_2)->base + _a_6272);
                _2 = (int)SEQ_PTR(_userdata_6173);
                _3193 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3192) && IS_ATOM_INT(_3193)){
                    _3194 = (_3192 < _3193) ? -1 : (_3192 > _3193);
                }
                else{
                    _3194 = compare(_3192, _3193);
                }
                _3192 = NOVALUE;
                _3193 = NOVALUE;
                if (_3194 > 0)
                goto L1B; // [505] 526

                /** 								idx += 1*/
                _idx_6176 = _idx_6176 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3197 = (int)*(((s1_ptr)_2)->base + _a_6272);
                Ref(_3197);
                _2 = (int)SEQ_PTR(_dest_6175);
                _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
                _1 = *(int *)_2;
                *(int *)_2 = _3197;
                if( _1 != _3197 ){
                    DeRef(_1);
                }
                _3197 = NOVALUE;
L1B: 
L1A: 

                /** 					end for*/
                _a_6272 = _a_6272 + 1;
                goto L18; // [529] 473
L19: 
                ;
            }
            goto L5; // [534] 1304

            /** 				case "[)" then*/
            case 3:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6171)){
                    _3198 = SEQ_PTR(_source_6171)->length;
            }
            else {
                _3198 = 1;
            }
            {
                int _a_6288;
                _a_6288 = 1;
L1C: 
                if (_a_6288 > _3198){
                    goto L1D; // [545] 613
                }

                /** 						if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3199 = (int)*(((s1_ptr)_2)->base + _a_6288);
                _2 = (int)SEQ_PTR(_userdata_6173);
                _3200 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3199) && IS_ATOM_INT(_3200)){
                    _3201 = (_3199 < _3200) ? -1 : (_3199 > _3200);
                }
                else{
                    _3201 = compare(_3199, _3200);
                }
                _3199 = NOVALUE;
                _3200 = NOVALUE;
                if (_3201 < 0)
                goto L1E; // [566] 606

                /** 							if compare(source[a], userdata[2]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3203 = (int)*(((s1_ptr)_2)->base + _a_6288);
                _2 = (int)SEQ_PTR(_userdata_6173);
                _3204 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3203) && IS_ATOM_INT(_3204)){
                    _3205 = (_3203 < _3204) ? -1 : (_3203 > _3204);
                }
                else{
                    _3205 = compare(_3203, _3204);
                }
                _3203 = NOVALUE;
                _3204 = NOVALUE;
                if (_3205 >= 0)
                goto L1F; // [584] 605

                /** 								idx += 1*/
                _idx_6176 = _idx_6176 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3208 = (int)*(((s1_ptr)_2)->base + _a_6288);
                Ref(_3208);
                _2 = (int)SEQ_PTR(_dest_6175);
                _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
                _1 = *(int *)_2;
                *(int *)_2 = _3208;
                if( _1 != _3208 ){
                    DeRef(_1);
                }
                _3208 = NOVALUE;
L1F: 
L1E: 

                /** 					end for*/
                _a_6288 = _a_6288 + 1;
                goto L1C; // [608] 552
L1D: 
                ;
            }
            goto L5; // [613] 1304

            /** 				case "(]" then*/
            case 4:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6171)){
                    _3209 = SEQ_PTR(_source_6171)->length;
            }
            else {
                _3209 = 1;
            }
            {
                int _a_6304;
                _a_6304 = 1;
L20: 
                if (_a_6304 > _3209){
                    goto L21; // [624] 692
                }

                /** 						if compare(source[a], userdata[1]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3210 = (int)*(((s1_ptr)_2)->base + _a_6304);
                _2 = (int)SEQ_PTR(_userdata_6173);
                _3211 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3210) && IS_ATOM_INT(_3211)){
                    _3212 = (_3210 < _3211) ? -1 : (_3210 > _3211);
                }
                else{
                    _3212 = compare(_3210, _3211);
                }
                _3210 = NOVALUE;
                _3211 = NOVALUE;
                if (_3212 <= 0)
                goto L22; // [645] 685

                /** 							if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3214 = (int)*(((s1_ptr)_2)->base + _a_6304);
                _2 = (int)SEQ_PTR(_userdata_6173);
                _3215 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3214) && IS_ATOM_INT(_3215)){
                    _3216 = (_3214 < _3215) ? -1 : (_3214 > _3215);
                }
                else{
                    _3216 = compare(_3214, _3215);
                }
                _3214 = NOVALUE;
                _3215 = NOVALUE;
                if (_3216 > 0)
                goto L23; // [663] 684

                /** 								idx += 1*/
                _idx_6176 = _idx_6176 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3219 = (int)*(((s1_ptr)_2)->base + _a_6304);
                Ref(_3219);
                _2 = (int)SEQ_PTR(_dest_6175);
                _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
                _1 = *(int *)_2;
                *(int *)_2 = _3219;
                if( _1 != _3219 ){
                    DeRef(_1);
                }
                _3219 = NOVALUE;
L23: 
L22: 

                /** 					end for*/
                _a_6304 = _a_6304 + 1;
                goto L20; // [687] 631
L21: 
                ;
            }
            goto L5; // [692] 1304

            /** 				case "()" then*/
            case 5:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6171)){
                    _3220 = SEQ_PTR(_source_6171)->length;
            }
            else {
                _3220 = 1;
            }
            {
                int _a_6320;
                _a_6320 = 1;
L24: 
                if (_a_6320 > _3220){
                    goto L25; // [703] 771
                }

                /** 						if compare(source[a], userdata[1]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3221 = (int)*(((s1_ptr)_2)->base + _a_6320);
                _2 = (int)SEQ_PTR(_userdata_6173);
                _3222 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3221) && IS_ATOM_INT(_3222)){
                    _3223 = (_3221 < _3222) ? -1 : (_3221 > _3222);
                }
                else{
                    _3223 = compare(_3221, _3222);
                }
                _3221 = NOVALUE;
                _3222 = NOVALUE;
                if (_3223 <= 0)
                goto L26; // [724] 764

                /** 							if compare(source[a], userdata[2]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3225 = (int)*(((s1_ptr)_2)->base + _a_6320);
                _2 = (int)SEQ_PTR(_userdata_6173);
                _3226 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3225) && IS_ATOM_INT(_3226)){
                    _3227 = (_3225 < _3226) ? -1 : (_3225 > _3226);
                }
                else{
                    _3227 = compare(_3225, _3226);
                }
                _3225 = NOVALUE;
                _3226 = NOVALUE;
                if (_3227 >= 0)
                goto L27; // [742] 763

                /** 								idx += 1*/
                _idx_6176 = _idx_6176 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3230 = (int)*(((s1_ptr)_2)->base + _a_6320);
                Ref(_3230);
                _2 = (int)SEQ_PTR(_dest_6175);
                _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
                _1 = *(int *)_2;
                *(int *)_2 = _3230;
                if( _1 != _3230 ){
                    DeRef(_1);
                }
                _3230 = NOVALUE;
L27: 
L26: 

                /** 					end for*/
                _a_6320 = _a_6320 + 1;
                goto L24; // [766] 710
L25: 
                ;
            }
            goto L5; // [771] 1304

            /** 				case else*/
            case 0:
        ;}        goto L5; // [778] 1304

        /** 		case "out" then*/
        case 15:

        /** 			switch rangetype do*/
        _1 = find(_rangetype_6174, _3232);
        switch ( _1 ){ 

            /** 				case "" then*/
            case 1:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6171)){
                    _3234 = SEQ_PTR(_source_6171)->length;
            }
            else {
                _3234 = 1;
            }
            {
                int _a_6341;
                _a_6341 = 1;
L28: 
                if (_a_6341 > _3234){
                    goto L29; // [800] 845
                }

                /** 						if not find(source[a], userdata)  then*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3235 = (int)*(((s1_ptr)_2)->base + _a_6341);
                _3236 = find_from(_3235, _userdata_6173, 1);
                _3235 = NOVALUE;
                if (_3236 != 0)
                goto L2A; // [818] 838
                _3236 = NOVALUE;

                /** 							idx += 1*/
                _idx_6176 = _idx_6176 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3239 = (int)*(((s1_ptr)_2)->base + _a_6341);
                Ref(_3239);
                _2 = (int)SEQ_PTR(_dest_6175);
                _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
                _1 = *(int *)_2;
                *(int *)_2 = _3239;
                if( _1 != _3239 ){
                    DeRef(_1);
                }
                _3239 = NOVALUE;
L2A: 

                /** 					end for*/
                _a_6341 = _a_6341 + 1;
                goto L28; // [840] 807
L29: 
                ;
            }
            goto L5; // [845] 1304

            /** 				case "[]" then*/
            case 2:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6171)){
                    _3240 = SEQ_PTR(_source_6171)->length;
            }
            else {
                _3240 = 1;
            }
            {
                int _a_6351;
                _a_6351 = 1;
L2B: 
                if (_a_6351 > _3240){
                    goto L2C; // [856] 943
                }

                /** 						if compare(source[a], userdata[1]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3241 = (int)*(((s1_ptr)_2)->base + _a_6351);
                _2 = (int)SEQ_PTR(_userdata_6173);
                _3242 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3241) && IS_ATOM_INT(_3242)){
                    _3243 = (_3241 < _3242) ? -1 : (_3241 > _3242);
                }
                else{
                    _3243 = compare(_3241, _3242);
                }
                _3241 = NOVALUE;
                _3242 = NOVALUE;
                if (_3243 >= 0)
                goto L2D; // [877] 900

                /** 							idx += 1*/
                _idx_6176 = _idx_6176 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3246 = (int)*(((s1_ptr)_2)->base + _a_6351);
                Ref(_3246);
                _2 = (int)SEQ_PTR(_dest_6175);
                _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
                _1 = *(int *)_2;
                *(int *)_2 = _3246;
                if( _1 != _3246 ){
                    DeRef(_1);
                }
                _3246 = NOVALUE;
                goto L2E; // [897] 936
L2D: 

                /** 						elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3247 = (int)*(((s1_ptr)_2)->base + _a_6351);
                _2 = (int)SEQ_PTR(_userdata_6173);
                _3248 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3247) && IS_ATOM_INT(_3248)){
                    _3249 = (_3247 < _3248) ? -1 : (_3247 > _3248);
                }
                else{
                    _3249 = compare(_3247, _3248);
                }
                _3247 = NOVALUE;
                _3248 = NOVALUE;
                if (_3249 <= 0)
                goto L2F; // [914] 935

                /** 							idx += 1*/
                _idx_6176 = _idx_6176 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3252 = (int)*(((s1_ptr)_2)->base + _a_6351);
                Ref(_3252);
                _2 = (int)SEQ_PTR(_dest_6175);
                _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
                _1 = *(int *)_2;
                *(int *)_2 = _3252;
                if( _1 != _3252 ){
                    DeRef(_1);
                }
                _3252 = NOVALUE;
L2F: 
L2E: 

                /** 					end for*/
                _a_6351 = _a_6351 + 1;
                goto L2B; // [938] 863
L2C: 
                ;
            }
            goto L5; // [943] 1304

            /** 				case "[)" then*/
            case 3:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6171)){
                    _3253 = SEQ_PTR(_source_6171)->length;
            }
            else {
                _3253 = 1;
            }
            {
                int _a_6369;
                _a_6369 = 1;
L30: 
                if (_a_6369 > _3253){
                    goto L31; // [954] 1041
                }

                /** 						if compare(source[a], userdata[1]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3254 = (int)*(((s1_ptr)_2)->base + _a_6369);
                _2 = (int)SEQ_PTR(_userdata_6173);
                _3255 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3254) && IS_ATOM_INT(_3255)){
                    _3256 = (_3254 < _3255) ? -1 : (_3254 > _3255);
                }
                else{
                    _3256 = compare(_3254, _3255);
                }
                _3254 = NOVALUE;
                _3255 = NOVALUE;
                if (_3256 >= 0)
                goto L32; // [975] 998

                /** 							idx += 1*/
                _idx_6176 = _idx_6176 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3259 = (int)*(((s1_ptr)_2)->base + _a_6369);
                Ref(_3259);
                _2 = (int)SEQ_PTR(_dest_6175);
                _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
                _1 = *(int *)_2;
                *(int *)_2 = _3259;
                if( _1 != _3259 ){
                    DeRef(_1);
                }
                _3259 = NOVALUE;
                goto L33; // [995] 1034
L32: 

                /** 						elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3260 = (int)*(((s1_ptr)_2)->base + _a_6369);
                _2 = (int)SEQ_PTR(_userdata_6173);
                _3261 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3260) && IS_ATOM_INT(_3261)){
                    _3262 = (_3260 < _3261) ? -1 : (_3260 > _3261);
                }
                else{
                    _3262 = compare(_3260, _3261);
                }
                _3260 = NOVALUE;
                _3261 = NOVALUE;
                if (_3262 < 0)
                goto L34; // [1012] 1033

                /** 							idx += 1*/
                _idx_6176 = _idx_6176 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3265 = (int)*(((s1_ptr)_2)->base + _a_6369);
                Ref(_3265);
                _2 = (int)SEQ_PTR(_dest_6175);
                _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
                _1 = *(int *)_2;
                *(int *)_2 = _3265;
                if( _1 != _3265 ){
                    DeRef(_1);
                }
                _3265 = NOVALUE;
L34: 
L33: 

                /** 					end for*/
                _a_6369 = _a_6369 + 1;
                goto L30; // [1036] 961
L31: 
                ;
            }
            goto L5; // [1041] 1304

            /** 				case "(]" then*/
            case 4:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6171)){
                    _3266 = SEQ_PTR(_source_6171)->length;
            }
            else {
                _3266 = 1;
            }
            {
                int _a_6387;
                _a_6387 = 1;
L35: 
                if (_a_6387 > _3266){
                    goto L36; // [1052] 1139
                }

                /** 						if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3267 = (int)*(((s1_ptr)_2)->base + _a_6387);
                _2 = (int)SEQ_PTR(_userdata_6173);
                _3268 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3267) && IS_ATOM_INT(_3268)){
                    _3269 = (_3267 < _3268) ? -1 : (_3267 > _3268);
                }
                else{
                    _3269 = compare(_3267, _3268);
                }
                _3267 = NOVALUE;
                _3268 = NOVALUE;
                if (_3269 > 0)
                goto L37; // [1073] 1096

                /** 							idx += 1*/
                _idx_6176 = _idx_6176 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3272 = (int)*(((s1_ptr)_2)->base + _a_6387);
                Ref(_3272);
                _2 = (int)SEQ_PTR(_dest_6175);
                _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
                _1 = *(int *)_2;
                *(int *)_2 = _3272;
                if( _1 != _3272 ){
                    DeRef(_1);
                }
                _3272 = NOVALUE;
                goto L38; // [1093] 1132
L37: 

                /** 						elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3273 = (int)*(((s1_ptr)_2)->base + _a_6387);
                _2 = (int)SEQ_PTR(_userdata_6173);
                _3274 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3273) && IS_ATOM_INT(_3274)){
                    _3275 = (_3273 < _3274) ? -1 : (_3273 > _3274);
                }
                else{
                    _3275 = compare(_3273, _3274);
                }
                _3273 = NOVALUE;
                _3274 = NOVALUE;
                if (_3275 <= 0)
                goto L39; // [1110] 1131

                /** 							idx += 1*/
                _idx_6176 = _idx_6176 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3278 = (int)*(((s1_ptr)_2)->base + _a_6387);
                Ref(_3278);
                _2 = (int)SEQ_PTR(_dest_6175);
                _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
                _1 = *(int *)_2;
                *(int *)_2 = _3278;
                if( _1 != _3278 ){
                    DeRef(_1);
                }
                _3278 = NOVALUE;
L39: 
L38: 

                /** 					end for*/
                _a_6387 = _a_6387 + 1;
                goto L35; // [1134] 1059
L36: 
                ;
            }
            goto L5; // [1139] 1304

            /** 				case "()" then*/
            case 5:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6171)){
                    _3279 = SEQ_PTR(_source_6171)->length;
            }
            else {
                _3279 = 1;
            }
            {
                int _a_6405;
                _a_6405 = 1;
L3A: 
                if (_a_6405 > _3279){
                    goto L3B; // [1150] 1237
                }

                /** 						if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3280 = (int)*(((s1_ptr)_2)->base + _a_6405);
                _2 = (int)SEQ_PTR(_userdata_6173);
                _3281 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3280) && IS_ATOM_INT(_3281)){
                    _3282 = (_3280 < _3281) ? -1 : (_3280 > _3281);
                }
                else{
                    _3282 = compare(_3280, _3281);
                }
                _3280 = NOVALUE;
                _3281 = NOVALUE;
                if (_3282 > 0)
                goto L3C; // [1171] 1194

                /** 							idx += 1*/
                _idx_6176 = _idx_6176 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3285 = (int)*(((s1_ptr)_2)->base + _a_6405);
                Ref(_3285);
                _2 = (int)SEQ_PTR(_dest_6175);
                _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
                _1 = *(int *)_2;
                *(int *)_2 = _3285;
                if( _1 != _3285 ){
                    DeRef(_1);
                }
                _3285 = NOVALUE;
                goto L3D; // [1191] 1230
L3C: 

                /** 						elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3286 = (int)*(((s1_ptr)_2)->base + _a_6405);
                _2 = (int)SEQ_PTR(_userdata_6173);
                _3287 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3286) && IS_ATOM_INT(_3287)){
                    _3288 = (_3286 < _3287) ? -1 : (_3286 > _3287);
                }
                else{
                    _3288 = compare(_3286, _3287);
                }
                _3286 = NOVALUE;
                _3287 = NOVALUE;
                if (_3288 < 0)
                goto L3E; // [1208] 1229

                /** 							idx += 1*/
                _idx_6176 = _idx_6176 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_6171);
                _3291 = (int)*(((s1_ptr)_2)->base + _a_6405);
                Ref(_3291);
                _2 = (int)SEQ_PTR(_dest_6175);
                _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
                _1 = *(int *)_2;
                *(int *)_2 = _3291;
                if( _1 != _3291 ){
                    DeRef(_1);
                }
                _3291 = NOVALUE;
L3E: 
L3D: 

                /** 					end for*/
                _a_6405 = _a_6405 + 1;
                goto L3A; // [1232] 1157
L3B: 
                ;
            }
            goto L5; // [1237] 1304

            /** 				case else*/
            case 0:
        ;}        goto L5; // [1244] 1304

        /** 		case else*/
        case 0:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_6171)){
                _3292 = SEQ_PTR(_source_6171)->length;
        }
        else {
            _3292 = 1;
        }
        {
            int _a_6424;
            _a_6424 = 1;
L3F: 
            if (_a_6424 > _3292){
                goto L40; // [1255] 1303
            }

            /** 				if call_func(rid, {source[a], userdata}) then*/
            _2 = (int)SEQ_PTR(_source_6171);
            _3293 = (int)*(((s1_ptr)_2)->base + _a_6424);
            Ref(_userdata_6173);
            Ref(_3293);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _3293;
            ((int *)_2)[2] = _userdata_6173;
            _3294 = MAKE_SEQ(_1);
            _3293 = NOVALUE;
            _1 = (int)SEQ_PTR(_3294);
            _2 = (int)((s1_ptr)_1)->base;
            _0 = (int)_00[_rid_6172].addr;
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            DeRef(_3295);
            _3295 = _1;
            DeRefDS(_3294);
            _3294 = NOVALUE;
            if (_3295 == 0) {
                DeRef(_3295);
                _3295 = NOVALUE;
                goto L41; // [1276] 1296
            }
            else {
                if (!IS_ATOM_INT(_3295) && DBL_PTR(_3295)->dbl == 0.0){
                    DeRef(_3295);
                    _3295 = NOVALUE;
                    goto L41; // [1276] 1296
                }
                DeRef(_3295);
                _3295 = NOVALUE;
            }
            DeRef(_3295);
            _3295 = NOVALUE;

            /** 					idx += 1*/
            _idx_6176 = _idx_6176 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_6171);
            _3297 = (int)*(((s1_ptr)_2)->base + _a_6424);
            Ref(_3297);
            _2 = (int)SEQ_PTR(_dest_6175);
            _2 = (int)(((s1_ptr)_2)->base + _idx_6176);
            _1 = *(int *)_2;
            *(int *)_2 = _3297;
            if( _1 != _3297 ){
                DeRef(_1);
            }
            _3297 = NOVALUE;
L41: 

            /** 			end for*/
            _a_6424 = _a_6424 + 1;
            goto L3F; // [1298] 1262
L40: 
            ;
        }
    ;}L5: 

    /** 	return dest[1..idx]*/
    rhs_slice_target = (object_ptr)&_3298;
    RHS_Slice(_dest_6175, 1, _idx_6176);
    DeRefDS(_source_6171);
    DeRef(_userdata_6173);
    DeRef(_rangetype_6174);
    DeRefDS(_dest_6175);
    return _3298;
    ;
}


int _23filter_alpha(int _elem_6436, int _ud_6437)
{
    int _3299 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return t_alpha(elem)*/
    Ref(_elem_6436);
    _3299 = _9t_alpha(_elem_6436);
    DeRef(_elem_6436);
    return _3299;
    ;
}


int _23split(int _st_6481, int _delim_6482, int _no_empty_6483, int _limit_6484)
{
    int _ret_6485 = NOVALUE;
    int _start_6486 = NOVALUE;
    int _pos_6487 = NOVALUE;
    int _k_6539 = NOVALUE;
    int _3367 = NOVALUE;
    int _3365 = NOVALUE;
    int _3364 = NOVALUE;
    int _3360 = NOVALUE;
    int _3359 = NOVALUE;
    int _3358 = NOVALUE;
    int _3355 = NOVALUE;
    int _3354 = NOVALUE;
    int _3349 = NOVALUE;
    int _3348 = NOVALUE;
    int _3344 = NOVALUE;
    int _3340 = NOVALUE;
    int _3338 = NOVALUE;
    int _3337 = NOVALUE;
    int _3333 = NOVALUE;
    int _3331 = NOVALUE;
    int _3330 = NOVALUE;
    int _3329 = NOVALUE;
    int _3328 = NOVALUE;
    int _3325 = NOVALUE;
    int _3324 = NOVALUE;
    int _3323 = NOVALUE;
    int _3322 = NOVALUE;
    int _3321 = NOVALUE;
    int _3319 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence ret = {}*/
    RefDS(_5);
    DeRef(_ret_6485);
    _ret_6485 = _5;

    /** 	if length(st) = 0 then*/
    if (IS_SEQUENCE(_st_6481)){
            _3319 = SEQ_PTR(_st_6481)->length;
    }
    else {
        _3319 = 1;
    }
    if (_3319 != 0)
    goto L1; // [19] 30

    /** 		return ret*/
    DeRefDS(_st_6481);
    DeRefi(_delim_6482);
    return _ret_6485;
L1: 

    /** 	if sequence(delim) then*/
    _3321 = IS_SEQUENCE(_delim_6482);
    if (_3321 == 0)
    {
        _3321 = NOVALUE;
        goto L2; // [35] 211
    }
    else{
        _3321 = NOVALUE;
    }

    /** 		if equal(delim, "") then*/
    if (_delim_6482 == _5)
    _3322 = 1;
    else if (IS_ATOM_INT(_delim_6482) && IS_ATOM_INT(_5))
    _3322 = 0;
    else
    _3322 = (compare(_delim_6482, _5) == 0);
    if (_3322 == 0)
    {
        _3322 = NOVALUE;
        goto L3; // [44] 127
    }
    else{
        _3322 = NOVALUE;
    }

    /** 			for i = 1 to length(st) do*/
    if (IS_SEQUENCE(_st_6481)){
            _3323 = SEQ_PTR(_st_6481)->length;
    }
    else {
        _3323 = 1;
    }
    {
        int _i_6496;
        _i_6496 = 1;
L4: 
        if (_i_6496 > _3323){
            goto L5; // [52] 120
        }

        /** 				st[i] = {st[i]}*/
        _2 = (int)SEQ_PTR(_st_6481);
        _3324 = (int)*(((s1_ptr)_2)->base + _i_6496);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_3324);
        *((int *)(_2+4)) = _3324;
        _3325 = MAKE_SEQ(_1);
        _3324 = NOVALUE;
        _2 = (int)SEQ_PTR(_st_6481);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _st_6481 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_6496);
        _1 = *(int *)_2;
        *(int *)_2 = _3325;
        if( _1 != _3325 ){
            DeRef(_1);
        }
        _3325 = NOVALUE;

        /** 				limit -= 1*/
        _limit_6484 = _limit_6484 - 1;

        /** 				if limit = 0 then*/
        if (_limit_6484 != 0)
        goto L6; // [81] 113

        /** 					st = append(st[1 .. i],st[i+1 .. $])*/
        rhs_slice_target = (object_ptr)&_3328;
        RHS_Slice(_st_6481, 1, _i_6496);
        _3329 = _i_6496 + 1;
        if (IS_SEQUENCE(_st_6481)){
                _3330 = SEQ_PTR(_st_6481)->length;
        }
        else {
            _3330 = 1;
        }
        rhs_slice_target = (object_ptr)&_3331;
        RHS_Slice(_st_6481, _3329, _3330);
        RefDS(_3331);
        Append(&_st_6481, _3328, _3331);
        DeRefDS(_3328);
        _3328 = NOVALUE;
        DeRefDS(_3331);
        _3331 = NOVALUE;

        /** 					exit*/
        goto L5; // [110] 120
L6: 

        /** 			end for*/
        _i_6496 = _i_6496 + 1;
        goto L4; // [115] 59
L5: 
        ;
    }

    /** 			return st*/
    DeRefi(_delim_6482);
    DeRef(_ret_6485);
    DeRef(_3329);
    _3329 = NOVALUE;
    return _st_6481;
L3: 

    /** 		start = 1*/
    _start_6486 = 1;

    /** 		while start <= length(st) do*/
L7: 
    if (IS_SEQUENCE(_st_6481)){
            _3333 = SEQ_PTR(_st_6481)->length;
    }
    else {
        _3333 = 1;
    }
    if (_start_6486 > _3333)
    goto L8; // [140] 290

    /** 			pos = match(delim, st, start)*/
    _pos_6487 = e_match_from(_delim_6482, _st_6481, _start_6486);

    /** 			if pos = 0 then*/
    if (_pos_6487 != 0)
    goto L9; // [153] 162

    /** 				exit*/
    goto L8; // [159] 290
L9: 

    /** 			ret = append(ret, st[start..pos-1])*/
    _3337 = _pos_6487 - 1;
    rhs_slice_target = (object_ptr)&_3338;
    RHS_Slice(_st_6481, _start_6486, _3337);
    RefDS(_3338);
    Append(&_ret_6485, _ret_6485, _3338);
    DeRefDS(_3338);
    _3338 = NOVALUE;

    /** 			start = pos+length(delim)*/
    if (IS_SEQUENCE(_delim_6482)){
            _3340 = SEQ_PTR(_delim_6482)->length;
    }
    else {
        _3340 = 1;
    }
    _start_6486 = _pos_6487 + _3340;
    _3340 = NOVALUE;

    /** 			limit -= 1*/
    _limit_6484 = _limit_6484 - 1;

    /** 			if limit = 0 then*/
    if (_limit_6484 != 0)
    goto L7; // [194] 137

    /** 				exit*/
    goto L8; // [200] 290

    /** 		end while*/
    goto L7; // [205] 137
    goto L8; // [208] 290
L2: 

    /** 		start = 1*/
    _start_6486 = 1;

    /** 		while start <= length(st) do*/
LA: 
    if (IS_SEQUENCE(_st_6481)){
            _3344 = SEQ_PTR(_st_6481)->length;
    }
    else {
        _3344 = 1;
    }
    if (_start_6486 > _3344)
    goto LB; // [224] 289

    /** 			pos = find(delim, st, start)*/
    _pos_6487 = find_from(_delim_6482, _st_6481, _start_6486);

    /** 			if pos = 0 then*/
    if (_pos_6487 != 0)
    goto LC; // [237] 246

    /** 				exit*/
    goto LB; // [243] 289
LC: 

    /** 			ret = append(ret, st[start..pos-1])*/
    _3348 = _pos_6487 - 1;
    rhs_slice_target = (object_ptr)&_3349;
    RHS_Slice(_st_6481, _start_6486, _3348);
    RefDS(_3349);
    Append(&_ret_6485, _ret_6485, _3349);
    DeRefDS(_3349);
    _3349 = NOVALUE;

    /** 			start = pos + 1*/
    _start_6486 = _pos_6487 + 1;

    /** 			limit -= 1*/
    _limit_6484 = _limit_6484 - 1;

    /** 			if limit = 0 then*/
    if (_limit_6484 != 0)
    goto LA; // [275] 221

    /** 				exit*/
    goto LB; // [281] 289

    /** 		end while*/
    goto LA; // [286] 221
LB: 
L8: 

    /** 	ret = append(ret, st[start..$])*/
    if (IS_SEQUENCE(_st_6481)){
            _3354 = SEQ_PTR(_st_6481)->length;
    }
    else {
        _3354 = 1;
    }
    rhs_slice_target = (object_ptr)&_3355;
    RHS_Slice(_st_6481, _start_6486, _3354);
    RefDS(_3355);
    Append(&_ret_6485, _ret_6485, _3355);
    DeRefDS(_3355);
    _3355 = NOVALUE;

    /** 	integer k = length(ret)*/
    if (IS_SEQUENCE(_ret_6485)){
            _k_6539 = SEQ_PTR(_ret_6485)->length;
    }
    else {
        _k_6539 = 1;
    }

    /** 	if no_empty then*/
    if (_no_empty_6483 == 0)
    {
        goto LD; // [313] 378
    }
    else{
    }

    /** 		k = 0*/
    _k_6539 = 0;

    /** 		for i = 1 to length(ret) do*/
    if (IS_SEQUENCE(_ret_6485)){
            _3358 = SEQ_PTR(_ret_6485)->length;
    }
    else {
        _3358 = 1;
    }
    {
        int _i_6543;
        _i_6543 = 1;
LE: 
        if (_i_6543 > _3358){
            goto LF; // [326] 377
        }

        /** 			if length(ret[i]) != 0 then*/
        _2 = (int)SEQ_PTR(_ret_6485);
        _3359 = (int)*(((s1_ptr)_2)->base + _i_6543);
        if (IS_SEQUENCE(_3359)){
                _3360 = SEQ_PTR(_3359)->length;
        }
        else {
            _3360 = 1;
        }
        _3359 = NOVALUE;
        if (_3360 == 0)
        goto L10; // [342] 370

        /** 				k += 1*/
        _k_6539 = _k_6539 + 1;

        /** 				if k != i then*/
        if (_k_6539 == _i_6543)
        goto L11; // [354] 369

        /** 					ret[k] = ret[i]*/
        _2 = (int)SEQ_PTR(_ret_6485);
        _3364 = (int)*(((s1_ptr)_2)->base + _i_6543);
        Ref(_3364);
        _2 = (int)SEQ_PTR(_ret_6485);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _ret_6485 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _k_6539);
        _1 = *(int *)_2;
        *(int *)_2 = _3364;
        if( _1 != _3364 ){
            DeRef(_1);
        }
        _3364 = NOVALUE;
L11: 
L10: 

        /** 		end for*/
        _i_6543 = _i_6543 + 1;
        goto LE; // [372] 333
LF: 
        ;
    }
LD: 

    /** 	if k < length(ret) then*/
    if (IS_SEQUENCE(_ret_6485)){
            _3365 = SEQ_PTR(_ret_6485)->length;
    }
    else {
        _3365 = 1;
    }
    if (_k_6539 >= _3365)
    goto L12; // [383] 401

    /** 		return ret[1 .. k]*/
    rhs_slice_target = (object_ptr)&_3367;
    RHS_Slice(_ret_6485, 1, _k_6539);
    DeRefDS(_st_6481);
    DeRefi(_delim_6482);
    DeRefDS(_ret_6485);
    DeRef(_3337);
    _3337 = NOVALUE;
    DeRef(_3329);
    _3329 = NOVALUE;
    DeRef(_3348);
    _3348 = NOVALUE;
    _3359 = NOVALUE;
    return _3367;
    goto L13; // [398] 408
L12: 

    /** 		return ret*/
    DeRefDS(_st_6481);
    DeRefi(_delim_6482);
    DeRef(_3337);
    _3337 = NOVALUE;
    DeRef(_3329);
    _3329 = NOVALUE;
    DeRef(_3348);
    _3348 = NOVALUE;
    _3359 = NOVALUE;
    DeRef(_3367);
    _3367 = NOVALUE;
    return _ret_6485;
L13: 
    ;
}


int _23join(int _items_6608, int _delim_6609)
{
    int _ret_6611 = NOVALUE;
    int _3402 = NOVALUE;
    int _3401 = NOVALUE;
    int _3399 = NOVALUE;
    int _3398 = NOVALUE;
    int _3397 = NOVALUE;
    int _3396 = NOVALUE;
    int _3394 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(items) then return {} end if*/
    if (IS_SEQUENCE(_items_6608)){
            _3394 = SEQ_PTR(_items_6608)->length;
    }
    else {
        _3394 = 1;
    }
    if (_3394 != 0)
    goto L1; // [8] 16
    _3394 = NOVALUE;
    RefDS(_5);
    DeRefDS(_items_6608);
    DeRef(_ret_6611);
    return _5;
L1: 

    /** 	ret = {}*/
    RefDS(_5);
    DeRef(_ret_6611);
    _ret_6611 = _5;

    /** 	for i=1 to length(items)-1 do*/
    if (IS_SEQUENCE(_items_6608)){
            _3396 = SEQ_PTR(_items_6608)->length;
    }
    else {
        _3396 = 1;
    }
    _3397 = _3396 - 1;
    _3396 = NOVALUE;
    {
        int _i_6616;
        _i_6616 = 1;
L2: 
        if (_i_6616 > _3397){
            goto L3; // [30] 58
        }

        /** 		ret &= items[i] & delim*/
        _2 = (int)SEQ_PTR(_items_6608);
        _3398 = (int)*(((s1_ptr)_2)->base + _i_6616);
        if (IS_SEQUENCE(_3398) && IS_ATOM(_delim_6609)) {
            Append(&_3399, _3398, _delim_6609);
        }
        else if (IS_ATOM(_3398) && IS_SEQUENCE(_delim_6609)) {
        }
        else {
            Concat((object_ptr)&_3399, _3398, _delim_6609);
            _3398 = NOVALUE;
        }
        _3398 = NOVALUE;
        if (IS_SEQUENCE(_ret_6611) && IS_ATOM(_3399)) {
        }
        else if (IS_ATOM(_ret_6611) && IS_SEQUENCE(_3399)) {
            Ref(_ret_6611);
            Prepend(&_ret_6611, _3399, _ret_6611);
        }
        else {
            Concat((object_ptr)&_ret_6611, _ret_6611, _3399);
        }
        DeRefDS(_3399);
        _3399 = NOVALUE;

        /** 	end for*/
        _i_6616 = _i_6616 + 1;
        goto L2; // [53] 37
L3: 
        ;
    }

    /** 	ret &= items[$]*/
    if (IS_SEQUENCE(_items_6608)){
            _3401 = SEQ_PTR(_items_6608)->length;
    }
    else {
        _3401 = 1;
    }
    _2 = (int)SEQ_PTR(_items_6608);
    _3402 = (int)*(((s1_ptr)_2)->base + _3401);
    if (IS_SEQUENCE(_ret_6611) && IS_ATOM(_3402)) {
        Ref(_3402);
        Append(&_ret_6611, _ret_6611, _3402);
    }
    else if (IS_ATOM(_ret_6611) && IS_SEQUENCE(_3402)) {
        Ref(_ret_6611);
        Prepend(&_ret_6611, _3402, _ret_6611);
    }
    else {
        Concat((object_ptr)&_ret_6611, _ret_6611, _3402);
    }
    _3402 = NOVALUE;

    /** 	return ret*/
    DeRefDS(_items_6608);
    DeRef(_3397);
    _3397 = NOVALUE;
    return _ret_6611;
    ;
}


int _23flatten(int _s_6718, int _delim_6719)
{
    int _ret_6720 = NOVALUE;
    int _x_6721 = NOVALUE;
    int _len_6722 = NOVALUE;
    int _pos_6723 = NOVALUE;
    int _temp_6741 = NOVALUE;
    int _3488 = NOVALUE;
    int _3487 = NOVALUE;
    int _3486 = NOVALUE;
    int _3484 = NOVALUE;
    int _3483 = NOVALUE;
    int _3482 = NOVALUE;
    int _3480 = NOVALUE;
    int _3478 = NOVALUE;
    int _3477 = NOVALUE;
    int _3476 = NOVALUE;
    int _3474 = NOVALUE;
    int _3473 = NOVALUE;
    int _3472 = NOVALUE;
    int _3471 = NOVALUE;
    int _3470 = NOVALUE;
    int _3469 = NOVALUE;
    int _3467 = NOVALUE;
    int _3466 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ret = s*/
    RefDS(_s_6718);
    DeRef(_ret_6720);
    _ret_6720 = _s_6718;

    /** 	pos = 1*/
    _pos_6723 = 1;

    /** 	len = length(ret)*/
    if (IS_SEQUENCE(_ret_6720)){
            _len_6722 = SEQ_PTR(_ret_6720)->length;
    }
    else {
        _len_6722 = 1;
    }

    /** 	while pos <= len do*/
L1: 
    if (_pos_6723 > _len_6722)
    goto L2; // [25] 183

    /** 		x = ret[pos]*/
    DeRef(_x_6721);
    _2 = (int)SEQ_PTR(_ret_6720);
    _x_6721 = (int)*(((s1_ptr)_2)->base + _pos_6723);
    Ref(_x_6721);

    /** 		if sequence(x) then*/
    _3466 = IS_SEQUENCE(_x_6721);
    if (_3466 == 0)
    {
        _3466 = NOVALUE;
        goto L3; // [40] 171
    }
    else{
        _3466 = NOVALUE;
    }

    /** 			if length(delim) = 0 then*/
    if (IS_SEQUENCE(_delim_6719)){
            _3467 = SEQ_PTR(_delim_6719)->length;
    }
    else {
        _3467 = 1;
    }
    if (_3467 != 0)
    goto L4; // [48] 89

    /** 				ret = ret[1..pos-1] & flatten(x) & ret[pos+1 .. $]*/
    _3469 = _pos_6723 - 1;
    rhs_slice_target = (object_ptr)&_3470;
    RHS_Slice(_ret_6720, 1, _3469);
    Ref(_x_6721);
    RefDS(_5);
    _3471 = _23flatten(_x_6721, _5);
    _3472 = _pos_6723 + 1;
    if (_3472 > MAXINT){
        _3472 = NewDouble((double)_3472);
    }
    if (IS_SEQUENCE(_ret_6720)){
            _3473 = SEQ_PTR(_ret_6720)->length;
    }
    else {
        _3473 = 1;
    }
    rhs_slice_target = (object_ptr)&_3474;
    RHS_Slice(_ret_6720, _3472, _3473);
    {
        int concat_list[3];

        concat_list[0] = _3474;
        concat_list[1] = _3471;
        concat_list[2] = _3470;
        Concat_N((object_ptr)&_ret_6720, concat_list, 3);
    }
    DeRefDS(_3474);
    _3474 = NOVALUE;
    DeRef(_3471);
    _3471 = NOVALUE;
    DeRefDS(_3470);
    _3470 = NOVALUE;
    goto L5; // [86] 163
L4: 

    /** 				sequence temp = ret[1..pos-1] & flatten(x)*/
    _3476 = _pos_6723 - 1;
    rhs_slice_target = (object_ptr)&_3477;
    RHS_Slice(_ret_6720, 1, _3476);
    Ref(_x_6721);
    RefDS(_5);
    _3478 = _23flatten(_x_6721, _5);
    if (IS_SEQUENCE(_3477) && IS_ATOM(_3478)) {
        Ref(_3478);
        Append(&_temp_6741, _3477, _3478);
    }
    else if (IS_ATOM(_3477) && IS_SEQUENCE(_3478)) {
    }
    else {
        Concat((object_ptr)&_temp_6741, _3477, _3478);
        DeRefDS(_3477);
        _3477 = NOVALUE;
    }
    DeRef(_3477);
    _3477 = NOVALUE;
    DeRef(_3478);
    _3478 = NOVALUE;

    /** 				if pos != length(ret) then*/
    if (IS_SEQUENCE(_ret_6720)){
            _3480 = SEQ_PTR(_ret_6720)->length;
    }
    else {
        _3480 = 1;
    }
    if (_pos_6723 == _3480)
    goto L6; // [114] 141

    /** 					ret = temp &  delim & ret[pos+1 .. $]*/
    _3482 = _pos_6723 + 1;
    if (_3482 > MAXINT){
        _3482 = NewDouble((double)_3482);
    }
    if (IS_SEQUENCE(_ret_6720)){
            _3483 = SEQ_PTR(_ret_6720)->length;
    }
    else {
        _3483 = 1;
    }
    rhs_slice_target = (object_ptr)&_3484;
    RHS_Slice(_ret_6720, _3482, _3483);
    {
        int concat_list[3];

        concat_list[0] = _3484;
        concat_list[1] = _delim_6719;
        concat_list[2] = _temp_6741;
        Concat_N((object_ptr)&_ret_6720, concat_list, 3);
    }
    DeRefDS(_3484);
    _3484 = NOVALUE;
    goto L7; // [138] 160
L6: 

    /** 					ret = temp & ret[pos+1 .. $]*/
    _3486 = _pos_6723 + 1;
    if (_3486 > MAXINT){
        _3486 = NewDouble((double)_3486);
    }
    if (IS_SEQUENCE(_ret_6720)){
            _3487 = SEQ_PTR(_ret_6720)->length;
    }
    else {
        _3487 = 1;
    }
    rhs_slice_target = (object_ptr)&_3488;
    RHS_Slice(_ret_6720, _3486, _3487);
    Concat((object_ptr)&_ret_6720, _temp_6741, _3488);
    DeRefDS(_3488);
    _3488 = NOVALUE;
L7: 
    DeRef(_temp_6741);
    _temp_6741 = NOVALUE;
L5: 

    /** 			len = length(ret)*/
    if (IS_SEQUENCE(_ret_6720)){
            _len_6722 = SEQ_PTR(_ret_6720)->length;
    }
    else {
        _len_6722 = 1;
    }
    goto L1; // [168] 25
L3: 

    /** 			pos += 1*/
    _pos_6723 = _pos_6723 + 1;

    /** 	end while*/
    goto L1; // [180] 25
L2: 

    /** 	return ret*/
    DeRefDS(_s_6718);
    DeRefi(_delim_6719);
    DeRef(_x_6721);
    DeRef(_3469);
    _3469 = NOVALUE;
    DeRef(_3476);
    _3476 = NOVALUE;
    DeRef(_3482);
    _3482 = NOVALUE;
    DeRef(_3472);
    _3472 = NOVALUE;
    DeRef(_3486);
    _3486 = NOVALUE;
    return _ret_6720;
    ;
}



// 0x3752F0C0
