// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _16isLeap(int _year_3670)
{
    int _ly_3671 = NOVALUE;
    int _1756 = NOVALUE;
    int _1755 = NOVALUE;
    int _1754 = NOVALUE;
    int _1753 = NOVALUE;
    int _1752 = NOVALUE;
    int _1751 = NOVALUE;
    int _1750 = NOVALUE;
    int _1749 = NOVALUE;
    int _1748 = NOVALUE;
    int _1745 = NOVALUE;
    int _1743 = NOVALUE;
    int _1742 = NOVALUE;
    int _0, _1, _2;
    

    /** 		ly = (remainder(year, {4, 100, 400, 3200, 80000})=0)*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 4;
    *((int *)(_2+8)) = 100;
    *((int *)(_2+12)) = 400;
    *((int *)(_2+16)) = 3200;
    *((int *)(_2+20)) = 80000;
    _1742 = MAKE_SEQ(_1);
    _1743 = binary_op(REMAINDER, _year_3670, _1742);
    DeRefDS(_1742);
    _1742 = NOVALUE;
    DeRefi(_ly_3671);
    _ly_3671 = binary_op(EQUALS, _1743, 0);
    DeRefDS(_1743);
    _1743 = NOVALUE;

    /** 		if not ly[1] then return 0 end if*/
    _2 = (int)SEQ_PTR(_ly_3671);
    _1745 = (int)*(((s1_ptr)_2)->base + 1);
    if (_1745 != 0)
    goto L1; // [29] 37
    _1745 = NOVALUE;
    DeRefDSi(_ly_3671);
    return 0;
L1: 

    /** 		if year <= Gregorian_Reformation then*/
    if (_year_3670 > 1752)
    goto L2; // [39] 52

    /** 				return 1 -- ly[1] can't possibly be 0 here so set shortcut as '1'.*/
    DeRefi(_ly_3671);
    return 1;
    goto L3; // [49] 95
L2: 

    /** 				return ly[1] - ly[2] + ly[3] - ly[4] + ly[5]*/
    _2 = (int)SEQ_PTR(_ly_3671);
    _1748 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_ly_3671);
    _1749 = (int)*(((s1_ptr)_2)->base + 2);
    _1750 = _1748 - _1749;
    if ((long)((unsigned long)_1750 +(unsigned long) HIGH_BITS) >= 0){
        _1750 = NewDouble((double)_1750);
    }
    _1748 = NOVALUE;
    _1749 = NOVALUE;
    _2 = (int)SEQ_PTR(_ly_3671);
    _1751 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_1750)) {
        _1752 = _1750 + _1751;
        if ((long)((unsigned long)_1752 + (unsigned long)HIGH_BITS) >= 0) 
        _1752 = NewDouble((double)_1752);
    }
    else {
        _1752 = NewDouble(DBL_PTR(_1750)->dbl + (double)_1751);
    }
    DeRef(_1750);
    _1750 = NOVALUE;
    _1751 = NOVALUE;
    _2 = (int)SEQ_PTR(_ly_3671);
    _1753 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_1752)) {
        _1754 = _1752 - _1753;
        if ((long)((unsigned long)_1754 +(unsigned long) HIGH_BITS) >= 0){
            _1754 = NewDouble((double)_1754);
        }
    }
    else {
        _1754 = NewDouble(DBL_PTR(_1752)->dbl - (double)_1753);
    }
    DeRef(_1752);
    _1752 = NOVALUE;
    _1753 = NOVALUE;
    _2 = (int)SEQ_PTR(_ly_3671);
    _1755 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_1754)) {
        _1756 = _1754 + _1755;
        if ((long)((unsigned long)_1756 + (unsigned long)HIGH_BITS) >= 0) 
        _1756 = NewDouble((double)_1756);
    }
    else {
        _1756 = NewDouble(DBL_PTR(_1754)->dbl + (double)_1755);
    }
    DeRef(_1754);
    _1754 = NOVALUE;
    _1755 = NOVALUE;
    DeRefDSi(_ly_3671);
    return _1756;
L3: 
    ;
}


int _16daysInMonth(int _year_3695, int _month_3696)
{
    int _1764 = NOVALUE;
    int _1763 = NOVALUE;
    int _1762 = NOVALUE;
    int _1761 = NOVALUE;
    int _1759 = NOVALUE;
    int _1758 = NOVALUE;
    int _1757 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_month_3696)) {
        _1 = (long)(DBL_PTR(_month_3696)->dbl);
        DeRefDS(_month_3696);
        _month_3696 = _1;
    }

    /** 	if year = Gregorian_Reformation and month = 9 then*/
    _1757 = (_year_3695 == 1752);
    if (_1757 == 0) {
        goto L1; // [11] 32
    }
    _1759 = (_month_3696 == 9);
    if (_1759 == 0)
    {
        DeRef(_1759);
        _1759 = NOVALUE;
        goto L1; // [20] 32
    }
    else{
        DeRef(_1759);
        _1759 = NOVALUE;
    }

    /** 		return 19*/
    DeRef(_1757);
    _1757 = NOVALUE;
    return 19;
    goto L2; // [29] 70
L1: 

    /** 	elsif month != 2 then*/
    if (_month_3696 == 2)
    goto L3; // [34] 51

    /** 		return DaysPerMonth[month]*/
    _2 = (int)SEQ_PTR(_16DaysPerMonth_3652);
    _1761 = (int)*(((s1_ptr)_2)->base + _month_3696);
    Ref(_1761);
    DeRef(_1757);
    _1757 = NOVALUE;
    return _1761;
    goto L2; // [48] 70
L3: 

    /** 		return DaysPerMonth[month] + isLeap(year)*/
    _2 = (int)SEQ_PTR(_16DaysPerMonth_3652);
    _1762 = (int)*(((s1_ptr)_2)->base + _month_3696);
    _1763 = _16isLeap(_year_3695);
    if (IS_ATOM_INT(_1762) && IS_ATOM_INT(_1763)) {
        _1764 = _1762 + _1763;
        if ((long)((unsigned long)_1764 + (unsigned long)HIGH_BITS) >= 0) 
        _1764 = NewDouble((double)_1764);
    }
    else {
        _1764 = binary_op(PLUS, _1762, _1763);
    }
    _1762 = NOVALUE;
    DeRef(_1763);
    _1763 = NOVALUE;
    DeRef(_1757);
    _1757 = NOVALUE;
    _1761 = NOVALUE;
    return _1764;
L2: 
    ;
}


int _16julianDayOfYear(int _ymd_3719)
{
    int _year_3720 = NOVALUE;
    int _month_3721 = NOVALUE;
    int _day_3722 = NOVALUE;
    int _d_3723 = NOVALUE;
    int _1780 = NOVALUE;
    int _1779 = NOVALUE;
    int _1778 = NOVALUE;
    int _1775 = NOVALUE;
    int _1774 = NOVALUE;
    int _0, _1, _2;
    

    /** 	year = ymd[1]*/
    _2 = (int)SEQ_PTR(_ymd_3719);
    _year_3720 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_year_3720)){
        _year_3720 = (long)DBL_PTR(_year_3720)->dbl;
    }

    /** 	month = ymd[2]*/
    _2 = (int)SEQ_PTR(_ymd_3719);
    _month_3721 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_month_3721)){
        _month_3721 = (long)DBL_PTR(_month_3721)->dbl;
    }

    /** 	day = ymd[3]*/
    _2 = (int)SEQ_PTR(_ymd_3719);
    _day_3722 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_day_3722)){
        _day_3722 = (long)DBL_PTR(_day_3722)->dbl;
    }

    /** 	if month = 1 then return day end if*/
    if (_month_3721 != 1)
    goto L1; // [27] 36
    DeRef(_ymd_3719);
    return _day_3722;
L1: 

    /** 	d = 0*/
    _d_3723 = 0;

    /** 	for i = 1 to month - 1 do*/
    _1774 = _month_3721 - 1;
    if ((long)((unsigned long)_1774 +(unsigned long) HIGH_BITS) >= 0){
        _1774 = NewDouble((double)_1774);
    }
    {
        int _i_3730;
        _i_3730 = 1;
L2: 
        if (binary_op_a(GREATER, _i_3730, _1774)){
            goto L3; // [47] 74
        }

        /** 		d += daysInMonth(year, i)*/
        Ref(_i_3730);
        _1775 = _16daysInMonth(_year_3720, _i_3730);
        if (IS_ATOM_INT(_1775)) {
            _d_3723 = _d_3723 + _1775;
        }
        else {
            _d_3723 = binary_op(PLUS, _d_3723, _1775);
        }
        DeRef(_1775);
        _1775 = NOVALUE;
        if (!IS_ATOM_INT(_d_3723)) {
            _1 = (long)(DBL_PTR(_d_3723)->dbl);
            DeRefDS(_d_3723);
            _d_3723 = _1;
        }

        /** 	end for*/
        _0 = _i_3730;
        if (IS_ATOM_INT(_i_3730)) {
            _i_3730 = _i_3730 + 1;
            if ((long)((unsigned long)_i_3730 +(unsigned long) HIGH_BITS) >= 0){
                _i_3730 = NewDouble((double)_i_3730);
            }
        }
        else {
            _i_3730 = binary_op_a(PLUS, _i_3730, 1);
        }
        DeRef(_0);
        goto L2; // [69] 54
L3: 
        ;
        DeRef(_i_3730);
    }

    /** 	d += day*/
    _d_3723 = _d_3723 + _day_3722;

    /** 	if year = Gregorian_Reformation and month = 9 then*/
    _1778 = (_year_3720 == 1752);
    if (_1778 == 0) {
        goto L4; // [86] 128
    }
    _1780 = (_month_3721 == 9);
    if (_1780 == 0)
    {
        DeRef(_1780);
        _1780 = NOVALUE;
        goto L4; // [95] 128
    }
    else{
        DeRef(_1780);
        _1780 = NOVALUE;
    }

    /** 		if day > 13 then*/
    if (_day_3722 <= 13)
    goto L5; // [100] 113

    /** 			d -= 11*/
    _d_3723 = _d_3723 - 11;
    goto L6; // [110] 127
L5: 

    /** 		elsif day > 2 then*/
    if (_day_3722 <= 2)
    goto L7; // [115] 126

    /** 			return 0*/
    DeRef(_ymd_3719);
    DeRef(_1774);
    _1774 = NOVALUE;
    DeRef(_1778);
    _1778 = NOVALUE;
    return 0;
L7: 
L6: 
L4: 

    /** 	return d*/
    DeRef(_ymd_3719);
    DeRef(_1774);
    _1774 = NOVALUE;
    DeRef(_1778);
    _1778 = NOVALUE;
    return _d_3723;
    ;
}


int _16julianDay(int _ymd_3746)
{
    int _year_3747 = NOVALUE;
    int _j_3748 = NOVALUE;
    int _greg00_3749 = NOVALUE;
    int _1809 = NOVALUE;
    int _1806 = NOVALUE;
    int _1803 = NOVALUE;
    int _1802 = NOVALUE;
    int _1801 = NOVALUE;
    int _1800 = NOVALUE;
    int _1799 = NOVALUE;
    int _1798 = NOVALUE;
    int _1797 = NOVALUE;
    int _1796 = NOVALUE;
    int _1794 = NOVALUE;
    int _1793 = NOVALUE;
    int _1792 = NOVALUE;
    int _1791 = NOVALUE;
    int _1790 = NOVALUE;
    int _1789 = NOVALUE;
    int _1788 = NOVALUE;
    int _0, _1, _2;
    

    /** 	year = ymd[1]*/
    _2 = (int)SEQ_PTR(_ymd_3746);
    _year_3747 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_year_3747)){
        _year_3747 = (long)DBL_PTR(_year_3747)->dbl;
    }

    /** 	j = julianDayOfYear(ymd)*/
    Ref(_ymd_3746);
    _j_3748 = _16julianDayOfYear(_ymd_3746);
    if (!IS_ATOM_INT(_j_3748)) {
        _1 = (long)(DBL_PTR(_j_3748)->dbl);
        DeRefDS(_j_3748);
        _j_3748 = _1;
    }

    /** 	year  -= 1*/
    _year_3747 = _year_3747 - 1;

    /** 	greg00 = year - Gregorian_Reformation00*/
    _greg00_3749 = _year_3747 - 1700;

    /** 	j += (*/
    if (_year_3747 <= INT15 && _year_3747 >= -INT15)
    _1788 = 365 * _year_3747;
    else
    _1788 = NewDouble(365 * (double)_year_3747);
    if (4 > 0 && _year_3747 >= 0) {
        _1789 = _year_3747 / 4;
    }
    else {
        temp_dbl = floor((double)_year_3747 / (double)4);
        _1789 = (long)temp_dbl;
    }
    if (IS_ATOM_INT(_1788)) {
        _1790 = _1788 + _1789;
        if ((long)((unsigned long)_1790 + (unsigned long)HIGH_BITS) >= 0) 
        _1790 = NewDouble((double)_1790);
    }
    else {
        _1790 = NewDouble(DBL_PTR(_1788)->dbl + (double)_1789);
    }
    DeRef(_1788);
    _1788 = NOVALUE;
    _1789 = NOVALUE;
    _1791 = (_greg00_3749 > 0);
    if (100 > 0 && _greg00_3749 >= 0) {
        _1792 = _greg00_3749 / 100;
    }
    else {
        temp_dbl = floor((double)_greg00_3749 / (double)100);
        _1792 = (long)temp_dbl;
    }
    _1793 = - _1792;
    _1794 = (_greg00_3749 % 400) ? NewDouble((double)_greg00_3749 / 400) : (_greg00_3749 / 400);
    if (IS_ATOM_INT(_1794)) {
        _1796 = NewDouble((double)_1794 + DBL_PTR(_1795)->dbl);
    }
    else {
        _1796 = NewDouble(DBL_PTR(_1794)->dbl + DBL_PTR(_1795)->dbl);
    }
    DeRef(_1794);
    _1794 = NOVALUE;
    _1797 = unary_op(FLOOR, _1796);
    DeRefDS(_1796);
    _1796 = NOVALUE;
    if (IS_ATOM_INT(_1797)) {
        _1798 = _1793 + _1797;
        if ((long)((unsigned long)_1798 + (unsigned long)HIGH_BITS) >= 0) 
        _1798 = NewDouble((double)_1798);
    }
    else {
        _1798 = NewDouble((double)_1793 + DBL_PTR(_1797)->dbl);
    }
    _1793 = NOVALUE;
    DeRef(_1797);
    _1797 = NOVALUE;
    if (IS_ATOM_INT(_1798)) {
        if (_1798 <= INT15 && _1798 >= -INT15)
        _1799 = _1791 * _1798;
        else
        _1799 = NewDouble(_1791 * (double)_1798);
    }
    else {
        _1799 = NewDouble((double)_1791 * DBL_PTR(_1798)->dbl);
    }
    _1791 = NOVALUE;
    DeRef(_1798);
    _1798 = NOVALUE;
    if (IS_ATOM_INT(_1790) && IS_ATOM_INT(_1799)) {
        _1800 = _1790 + _1799;
        if ((long)((unsigned long)_1800 + (unsigned long)HIGH_BITS) >= 0) 
        _1800 = NewDouble((double)_1800);
    }
    else {
        if (IS_ATOM_INT(_1790)) {
            _1800 = NewDouble((double)_1790 + DBL_PTR(_1799)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1799)) {
                _1800 = NewDouble(DBL_PTR(_1790)->dbl + (double)_1799);
            }
            else
            _1800 = NewDouble(DBL_PTR(_1790)->dbl + DBL_PTR(_1799)->dbl);
        }
    }
    DeRef(_1790);
    _1790 = NOVALUE;
    DeRef(_1799);
    _1799 = NOVALUE;
    _1801 = (_year_3747 >= 1752);
    _1802 = 11 * _1801;
    _1801 = NOVALUE;
    if (IS_ATOM_INT(_1800)) {
        _1803 = _1800 - _1802;
        if ((long)((unsigned long)_1803 +(unsigned long) HIGH_BITS) >= 0){
            _1803 = NewDouble((double)_1803);
        }
    }
    else {
        _1803 = NewDouble(DBL_PTR(_1800)->dbl - (double)_1802);
    }
    DeRef(_1800);
    _1800 = NOVALUE;
    _1802 = NOVALUE;
    if (IS_ATOM_INT(_1803)) {
        _j_3748 = _j_3748 + _1803;
    }
    else {
        _j_3748 = NewDouble((double)_j_3748 + DBL_PTR(_1803)->dbl);
    }
    DeRef(_1803);
    _1803 = NOVALUE;
    if (!IS_ATOM_INT(_j_3748)) {
        _1 = (long)(DBL_PTR(_j_3748)->dbl);
        DeRefDS(_j_3748);
        _j_3748 = _1;
    }

    /** 	if year >= 3200 then*/
    if (_year_3747 < 3200)
    goto L1; // [97] 133

    /** 		j -= floor(year/ 3200)*/
    if (3200 > 0 && _year_3747 >= 0) {
        _1806 = _year_3747 / 3200;
    }
    else {
        temp_dbl = floor((double)_year_3747 / (double)3200);
        _1806 = (long)temp_dbl;
    }
    _j_3748 = _j_3748 - _1806;
    _1806 = NOVALUE;

    /** 		if year >= 80000 then*/
    if (_year_3747 < 80000)
    goto L2; // [115] 132

    /** 			j += floor(year/80000)*/
    if (80000 > 0 && _year_3747 >= 0) {
        _1809 = _year_3747 / 80000;
    }
    else {
        temp_dbl = floor((double)_year_3747 / (double)80000);
        _1809 = (long)temp_dbl;
    }
    _j_3748 = _j_3748 + _1809;
    _1809 = NOVALUE;
L2: 
L1: 

    /** 	return j*/
    DeRef(_ymd_3746);
    DeRef(_1792);
    _1792 = NOVALUE;
    return _j_3748;
    ;
}


int _16datetimeToSeconds(int _dt_3835)
{
    int _1852 = NOVALUE;
    int _1851 = NOVALUE;
    int _1850 = NOVALUE;
    int _1849 = NOVALUE;
    int _1848 = NOVALUE;
    int _1847 = NOVALUE;
    int _1846 = NOVALUE;
    int _1845 = NOVALUE;
    int _1844 = NOVALUE;
    int _1843 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return julianDay(dt) * DayLengthInSeconds + (dt[4] * 60 + dt[5]) * 60 + dt[6]*/
    Ref(_dt_3835);
    _1843 = _16julianDay(_dt_3835);
    if (IS_ATOM_INT(_1843)) {
        _1844 = NewDouble(_1843 * (double)86400);
    }
    else {
        _1844 = binary_op(MULTIPLY, _1843, 86400);
    }
    DeRef(_1843);
    _1843 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_3835);
    _1845 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_1845)) {
        if (_1845 == (short)_1845)
        _1846 = _1845 * 60;
        else
        _1846 = NewDouble(_1845 * (double)60);
    }
    else {
        _1846 = binary_op(MULTIPLY, _1845, 60);
    }
    _1845 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_3835);
    _1847 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_1846) && IS_ATOM_INT(_1847)) {
        _1848 = _1846 + _1847;
        if ((long)((unsigned long)_1848 + (unsigned long)HIGH_BITS) >= 0) 
        _1848 = NewDouble((double)_1848);
    }
    else {
        _1848 = binary_op(PLUS, _1846, _1847);
    }
    DeRef(_1846);
    _1846 = NOVALUE;
    _1847 = NOVALUE;
    if (IS_ATOM_INT(_1848)) {
        if (_1848 == (short)_1848)
        _1849 = _1848 * 60;
        else
        _1849 = NewDouble(_1848 * (double)60);
    }
    else {
        _1849 = binary_op(MULTIPLY, _1848, 60);
    }
    DeRef(_1848);
    _1848 = NOVALUE;
    if (IS_ATOM_INT(_1844) && IS_ATOM_INT(_1849)) {
        _1850 = _1844 + _1849;
        if ((long)((unsigned long)_1850 + (unsigned long)HIGH_BITS) >= 0) 
        _1850 = NewDouble((double)_1850);
    }
    else {
        _1850 = binary_op(PLUS, _1844, _1849);
    }
    DeRef(_1844);
    _1844 = NOVALUE;
    DeRef(_1849);
    _1849 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_3835);
    _1851 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_ATOM_INT(_1850) && IS_ATOM_INT(_1851)) {
        _1852 = _1850 + _1851;
        if ((long)((unsigned long)_1852 + (unsigned long)HIGH_BITS) >= 0) 
        _1852 = NewDouble((double)_1852);
    }
    else {
        _1852 = binary_op(PLUS, _1850, _1851);
    }
    DeRef(_1850);
    _1850 = NOVALUE;
    _1851 = NOVALUE;
    DeRef(_dt_3835);
    return _1852;
    ;
}


int _16from_date(int _src_4001)
{
    int _1967 = NOVALUE;
    int _1966 = NOVALUE;
    int _1965 = NOVALUE;
    int _1964 = NOVALUE;
    int _1963 = NOVALUE;
    int _1962 = NOVALUE;
    int _1961 = NOVALUE;
    int _1959 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {src[YEAR]+1900, src[MONTH], src[DAY], src[HOUR], src[MINUTE], src[SECOND]}*/
    _2 = (int)SEQ_PTR(_src_4001);
    _1959 = (int)*(((s1_ptr)_2)->base + 1);
    _1961 = _1959 + 1900;
    if ((long)((unsigned long)_1961 + (unsigned long)HIGH_BITS) >= 0) 
    _1961 = NewDouble((double)_1961);
    _1959 = NOVALUE;
    _2 = (int)SEQ_PTR(_src_4001);
    _1962 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_src_4001);
    _1963 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_src_4001);
    _1964 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_src_4001);
    _1965 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_src_4001);
    _1966 = (int)*(((s1_ptr)_2)->base + 6);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _1961;
    *((int *)(_2+8)) = _1962;
    *((int *)(_2+12)) = _1963;
    *((int *)(_2+16)) = _1964;
    *((int *)(_2+20)) = _1965;
    *((int *)(_2+24)) = _1966;
    _1967 = MAKE_SEQ(_1);
    _1966 = NOVALUE;
    _1965 = NOVALUE;
    _1964 = NOVALUE;
    _1963 = NOVALUE;
    _1962 = NOVALUE;
    _1961 = NOVALUE;
    DeRefDSi(_src_4001);
    return _1967;
    ;
}


int _16new(int _year_4031, int _month_4032, int _day_4033, int _hour_4034, int _minute_4035, int _second_4036)
{
    int _d_4037 = NOVALUE;
    int _now_1__tmp_at41_4044 = NOVALUE;
    int _now_inlined_now_at_41_4043 = NOVALUE;
    int _1983 = NOVALUE;
    int _1982 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_year_4031)) {
        _1 = (long)(DBL_PTR(_year_4031)->dbl);
        DeRefDS(_year_4031);
        _year_4031 = _1;
    }
    if (!IS_ATOM_INT(_month_4032)) {
        _1 = (long)(DBL_PTR(_month_4032)->dbl);
        DeRefDS(_month_4032);
        _month_4032 = _1;
    }
    if (!IS_ATOM_INT(_day_4033)) {
        _1 = (long)(DBL_PTR(_day_4033)->dbl);
        DeRefDS(_day_4033);
        _day_4033 = _1;
    }
    if (!IS_ATOM_INT(_hour_4034)) {
        _1 = (long)(DBL_PTR(_hour_4034)->dbl);
        DeRefDS(_hour_4034);
        _hour_4034 = _1;
    }
    if (!IS_ATOM_INT(_minute_4035)) {
        _1 = (long)(DBL_PTR(_minute_4035)->dbl);
        DeRefDS(_minute_4035);
        _minute_4035 = _1;
    }

    /** 	d = {year, month, day, hour, minute, second}*/
    _0 = _d_4037;
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _year_4031;
    *((int *)(_2+8)) = _month_4032;
    *((int *)(_2+12)) = _day_4033;
    *((int *)(_2+16)) = _hour_4034;
    *((int *)(_2+20)) = _minute_4035;
    Ref(_second_4036);
    *((int *)(_2+24)) = _second_4036;
    _d_4037 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	if equal(d, {0,0,0,0,0,0}) then*/
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    *((int *)(_2+20)) = 0;
    *((int *)(_2+24)) = 0;
    _1982 = MAKE_SEQ(_1);
    if (_d_4037 == _1982)
    _1983 = 1;
    else if (IS_ATOM_INT(_d_4037) && IS_ATOM_INT(_1982))
    _1983 = 0;
    else
    _1983 = (compare(_d_4037, _1982) == 0);
    DeRefDS(_1982);
    _1982 = NOVALUE;
    if (_1983 == 0)
    {
        _1983 = NOVALUE;
        goto L1; // [37] 60
    }
    else{
        _1983 = NOVALUE;
    }

    /** 		return now()*/

    /** 	return from_date(date())*/
    DeRefi(_now_1__tmp_at41_4044);
    _now_1__tmp_at41_4044 = Date();
    RefDS(_now_1__tmp_at41_4044);
    _0 = _now_inlined_now_at_41_4043;
    _now_inlined_now_at_41_4043 = _16from_date(_now_1__tmp_at41_4044);
    DeRef(_0);
    DeRefi(_now_1__tmp_at41_4044);
    _now_1__tmp_at41_4044 = NOVALUE;
    DeRef(_second_4036);
    DeRef(_d_4037);
    return _now_inlined_now_at_41_4043;
    goto L2; // [57] 67
L1: 

    /** 		return d*/
    DeRef(_second_4036);
    return _d_4037;
L2: 
    ;
}



// 0xE2AA04FE
