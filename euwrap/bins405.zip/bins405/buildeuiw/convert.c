// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _13int_to_bytes(int _x_2251)
{
    int _a_2252 = NOVALUE;
    int _b_2253 = NOVALUE;
    int _c_2254 = NOVALUE;
    int _d_2255 = NOVALUE;
    int _1008 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_2251)) {
        _a_2252 = (_x_2251 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _a_2252 = Dremainder(DBL_PTR(_x_2251), &temp_d);
    }
    if (!IS_ATOM_INT(_a_2252)) {
        _1 = (long)(DBL_PTR(_a_2252)->dbl);
        DeRefDS(_a_2252);
        _a_2252 = _1;
    }

    /** 	x = floor(x / #100)*/
    _0 = _x_2251;
    if (IS_ATOM_INT(_x_2251)) {
        if (256 > 0 && _x_2251 >= 0) {
            _x_2251 = _x_2251 / 256;
        }
        else {
            temp_dbl = floor((double)_x_2251 / (double)256);
            if (_x_2251 != MININT)
            _x_2251 = (long)temp_dbl;
            else
            _x_2251 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_2251, 256);
        _x_2251 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /** 	b = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_2251)) {
        _b_2253 = (_x_2251 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _b_2253 = Dremainder(DBL_PTR(_x_2251), &temp_d);
    }
    if (!IS_ATOM_INT(_b_2253)) {
        _1 = (long)(DBL_PTR(_b_2253)->dbl);
        DeRefDS(_b_2253);
        _b_2253 = _1;
    }

    /** 	x = floor(x / #100)*/
    _0 = _x_2251;
    if (IS_ATOM_INT(_x_2251)) {
        if (256 > 0 && _x_2251 >= 0) {
            _x_2251 = _x_2251 / 256;
        }
        else {
            temp_dbl = floor((double)_x_2251 / (double)256);
            if (_x_2251 != MININT)
            _x_2251 = (long)temp_dbl;
            else
            _x_2251 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_2251, 256);
        _x_2251 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /** 	c = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_2251)) {
        _c_2254 = (_x_2251 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _c_2254 = Dremainder(DBL_PTR(_x_2251), &temp_d);
    }
    if (!IS_ATOM_INT(_c_2254)) {
        _1 = (long)(DBL_PTR(_c_2254)->dbl);
        DeRefDS(_c_2254);
        _c_2254 = _1;
    }

    /** 	x = floor(x / #100)*/
    _0 = _x_2251;
    if (IS_ATOM_INT(_x_2251)) {
        if (256 > 0 && _x_2251 >= 0) {
            _x_2251 = _x_2251 / 256;
        }
        else {
            temp_dbl = floor((double)_x_2251 / (double)256);
            if (_x_2251 != MININT)
            _x_2251 = (long)temp_dbl;
            else
            _x_2251 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_2251, 256);
        _x_2251 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /** 	d = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_2251)) {
        _d_2255 = (_x_2251 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _d_2255 = Dremainder(DBL_PTR(_x_2251), &temp_d);
    }
    if (!IS_ATOM_INT(_d_2255)) {
        _1 = (long)(DBL_PTR(_d_2255)->dbl);
        DeRefDS(_d_2255);
        _d_2255 = _1;
    }

    /** 	return {a,b,c,d}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _a_2252;
    *((int *)(_2+8)) = _b_2253;
    *((int *)(_2+12)) = _c_2254;
    *((int *)(_2+16)) = _d_2255;
    _1008 = MAKE_SEQ(_1);
    DeRef(_x_2251);
    return _1008;
    ;
}


int _13int_to_bits(int _x_2293, int _nbits_2294)
{
    int _bits_2295 = NOVALUE;
    int _mask_2296 = NOVALUE;
    int _1034 = NOVALUE;
    int _1033 = NOVALUE;
    int _1031 = NOVALUE;
    int _1028 = NOVALUE;
    int _1027 = NOVALUE;
    int _1026 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if nbits < 1 then*/

    /** 	bits = repeat(0, nbits)*/
    DeRef(_bits_2295);
    _bits_2295 = Repeat(0, _nbits_2294);

    /** 	if nbits <= 32 then*/

    /** 		mask = 1*/
    DeRef(_mask_2296);
    _mask_2296 = 1;

    /** 		for i = 1 to nbits do*/
    _1026 = _nbits_2294;
    {
        int _i_2303;
        _i_2303 = 1;
L1: 
        if (_i_2303 > _1026){
            goto L2; // [38] 72
        }

        /** 			bits[i] = and_bits(x, mask) and 1*/
        if (IS_ATOM_INT(_x_2293) && IS_ATOM_INT(_mask_2296)) {
            {unsigned long tu;
                 tu = (unsigned long)_x_2293 & (unsigned long)_mask_2296;
                 _1027 = MAKE_UINT(tu);
            }
        }
        else {
            if (IS_ATOM_INT(_x_2293)) {
                temp_d.dbl = (double)_x_2293;
                _1027 = Dand_bits(&temp_d, DBL_PTR(_mask_2296));
            }
            else {
                if (IS_ATOM_INT(_mask_2296)) {
                    temp_d.dbl = (double)_mask_2296;
                    _1027 = Dand_bits(DBL_PTR(_x_2293), &temp_d);
                }
                else
                _1027 = Dand_bits(DBL_PTR(_x_2293), DBL_PTR(_mask_2296));
            }
        }
        if (IS_ATOM_INT(_1027)) {
            _1028 = (_1027 != 0 && 1 != 0);
        }
        else {
            temp_d.dbl = (double)1;
            _1028 = Dand(DBL_PTR(_1027), &temp_d);
        }
        DeRef(_1027);
        _1027 = NOVALUE;
        _2 = (int)SEQ_PTR(_bits_2295);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _bits_2295 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_2303);
        _1 = *(int *)_2;
        *(int *)_2 = _1028;
        if( _1 != _1028 ){
            DeRef(_1);
        }
        _1028 = NOVALUE;

        /** 			mask *= 2*/
        _0 = _mask_2296;
        if (IS_ATOM_INT(_mask_2296) && IS_ATOM_INT(_mask_2296)) {
            _mask_2296 = _mask_2296 + _mask_2296;
            if ((long)((unsigned long)_mask_2296 + (unsigned long)HIGH_BITS) >= 0) 
            _mask_2296 = NewDouble((double)_mask_2296);
        }
        else {
            if (IS_ATOM_INT(_mask_2296)) {
                _mask_2296 = NewDouble((double)_mask_2296 + DBL_PTR(_mask_2296)->dbl);
            }
            else {
                if (IS_ATOM_INT(_mask_2296)) {
                    _mask_2296 = NewDouble(DBL_PTR(_mask_2296)->dbl + (double)_mask_2296);
                }
                else
                _mask_2296 = NewDouble(DBL_PTR(_mask_2296)->dbl + DBL_PTR(_mask_2296)->dbl);
            }
        }
        DeRef(_0);

        /** 		end for*/
        _i_2303 = _i_2303 + 1;
        goto L1; // [67] 45
L2: 
        ;
    }
    goto L3; // [72] 128

    /** 		if x < 0 then*/
    if (binary_op_a(GREATEREQ, _x_2293, 0)){
        goto L4; // [77] 92
    }

    /** 			x += power(2, nbits) -- for 2's complement bit pattern*/
    _1031 = power(2, _nbits_2294);
    _0 = _x_2293;
    if (IS_ATOM_INT(_x_2293) && IS_ATOM_INT(_1031)) {
        _x_2293 = _x_2293 + _1031;
        if ((long)((unsigned long)_x_2293 + (unsigned long)HIGH_BITS) >= 0) 
        _x_2293 = NewDouble((double)_x_2293);
    }
    else {
        if (IS_ATOM_INT(_x_2293)) {
            _x_2293 = NewDouble((double)_x_2293 + DBL_PTR(_1031)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1031)) {
                _x_2293 = NewDouble(DBL_PTR(_x_2293)->dbl + (double)_1031);
            }
            else
            _x_2293 = NewDouble(DBL_PTR(_x_2293)->dbl + DBL_PTR(_1031)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1031);
    _1031 = NOVALUE;
L4: 

    /** 		for i = 1 to nbits do*/
    _1033 = _nbits_2294;
    {
        int _i_2314;
        _i_2314 = 1;
L5: 
        if (_i_2314 > _1033){
            goto L6; // [97] 127
        }

        /** 			bits[i] = remainder(x, 2)*/
        if (IS_ATOM_INT(_x_2293)) {
            _1034 = (_x_2293 % 2);
        }
        else {
            temp_d.dbl = (double)2;
            _1034 = Dremainder(DBL_PTR(_x_2293), &temp_d);
        }
        _2 = (int)SEQ_PTR(_bits_2295);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _bits_2295 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_2314);
        _1 = *(int *)_2;
        *(int *)_2 = _1034;
        if( _1 != _1034 ){
            DeRef(_1);
        }
        _1034 = NOVALUE;

        /** 			x = floor(x / 2)*/
        _0 = _x_2293;
        if (IS_ATOM_INT(_x_2293)) {
            _x_2293 = _x_2293 >> 1;
        }
        else {
            _1 = binary_op(DIVIDE, _x_2293, 2);
            _x_2293 = unary_op(FLOOR, _1);
            DeRef(_1);
        }
        DeRef(_0);

        /** 		end for*/
        _i_2314 = _i_2314 + 1;
        goto L5; // [122] 104
L6: 
        ;
    }
L3: 

    /** 	return bits*/
    DeRef(_x_2293);
    DeRef(_mask_2296);
    return _bits_2295;
    ;
}


int _13bits_to_int(int _bits_2320)
{
    int _value_2321 = NOVALUE;
    int _p_2322 = NOVALUE;
    int _1037 = NOVALUE;
    int _1036 = NOVALUE;
    int _0, _1, _2;
    

    /** 	value = 0*/
    DeRef(_value_2321);
    _value_2321 = 0;

    /** 	p = 1*/
    DeRef(_p_2322);
    _p_2322 = 1;

    /** 	for i = 1 to length(bits) do*/
    if (IS_SEQUENCE(_bits_2320)){
            _1036 = SEQ_PTR(_bits_2320)->length;
    }
    else {
        _1036 = 1;
    }
    {
        int _i_2324;
        _i_2324 = 1;
L1: 
        if (_i_2324 > _1036){
            goto L2; // [18] 54
        }

        /** 		if bits[i] then*/
        _2 = (int)SEQ_PTR(_bits_2320);
        _1037 = (int)*(((s1_ptr)_2)->base + _i_2324);
        if (_1037 == 0) {
            _1037 = NOVALUE;
            goto L3; // [31] 41
        }
        else {
            if (!IS_ATOM_INT(_1037) && DBL_PTR(_1037)->dbl == 0.0){
                _1037 = NOVALUE;
                goto L3; // [31] 41
            }
            _1037 = NOVALUE;
        }
        _1037 = NOVALUE;

        /** 			value += p*/
        _0 = _value_2321;
        if (IS_ATOM_INT(_value_2321) && IS_ATOM_INT(_p_2322)) {
            _value_2321 = _value_2321 + _p_2322;
            if ((long)((unsigned long)_value_2321 + (unsigned long)HIGH_BITS) >= 0) 
            _value_2321 = NewDouble((double)_value_2321);
        }
        else {
            if (IS_ATOM_INT(_value_2321)) {
                _value_2321 = NewDouble((double)_value_2321 + DBL_PTR(_p_2322)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_2322)) {
                    _value_2321 = NewDouble(DBL_PTR(_value_2321)->dbl + (double)_p_2322);
                }
                else
                _value_2321 = NewDouble(DBL_PTR(_value_2321)->dbl + DBL_PTR(_p_2322)->dbl);
            }
        }
        DeRef(_0);
L3: 

        /** 		p += p*/
        _0 = _p_2322;
        if (IS_ATOM_INT(_p_2322) && IS_ATOM_INT(_p_2322)) {
            _p_2322 = _p_2322 + _p_2322;
            if ((long)((unsigned long)_p_2322 + (unsigned long)HIGH_BITS) >= 0) 
            _p_2322 = NewDouble((double)_p_2322);
        }
        else {
            if (IS_ATOM_INT(_p_2322)) {
                _p_2322 = NewDouble((double)_p_2322 + DBL_PTR(_p_2322)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_2322)) {
                    _p_2322 = NewDouble(DBL_PTR(_p_2322)->dbl + (double)_p_2322);
                }
                else
                _p_2322 = NewDouble(DBL_PTR(_p_2322)->dbl + DBL_PTR(_p_2322)->dbl);
            }
        }
        DeRef(_0);

        /** 	end for*/
        _i_2324 = _i_2324 + 1;
        goto L1; // [49] 25
L2: 
        ;
    }

    /** 	return value*/
    DeRefDS(_bits_2320);
    DeRef(_p_2322);
    return _value_2321;
    ;
}


int _13atom_to_float64(int _a_2332)
{
    int _1040 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_A_TO_F64, a)*/
    _1040 = machine(46, _a_2332);
    DeRef(_a_2332);
    return _1040;
    ;
}


int _13atom_to_float32(int _a_2336)
{
    int _1041 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_A_TO_F32, a)*/
    _1041 = machine(48, _a_2336);
    DeRef(_a_2336);
    return _1041;
    ;
}


int _13float64_to_atom(int _ieee64_2340)
{
    int _1042 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_F64_TO_A, ieee64)*/
    _1042 = machine(47, _ieee64_2340);
    DeRefDS(_ieee64_2340);
    return _1042;
    ;
}


int _13float32_to_atom(int _ieee32_2344)
{
    int _1043 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_F32_TO_A, ieee32)*/
    _1043 = machine(49, _ieee32_2344);
    DeRefDS(_ieee32_2344);
    return _1043;
    ;
}


int _13to_number(int _text_in_2422, int _return_bad_pos_2423)
{
    int _lDotFound_2424 = NOVALUE;
    int _lSignFound_2425 = NOVALUE;
    int _lCharValue_2426 = NOVALUE;
    int _lBadPos_2427 = NOVALUE;
    int _lLeftSize_2428 = NOVALUE;
    int _lRightSize_2429 = NOVALUE;
    int _lLeftValue_2430 = NOVALUE;
    int _lRightValue_2431 = NOVALUE;
    int _lBase_2432 = NOVALUE;
    int _lPercent_2433 = NOVALUE;
    int _lResult_2434 = NOVALUE;
    int _lDigitCount_2435 = NOVALUE;
    int _lCurrencyFound_2436 = NOVALUE;
    int _lLastDigit_2437 = NOVALUE;
    int _lChar_2438 = NOVALUE;
    int _1164 = NOVALUE;
    int _1163 = NOVALUE;
    int _1156 = NOVALUE;
    int _1154 = NOVALUE;
    int _1153 = NOVALUE;
    int _1148 = NOVALUE;
    int _1147 = NOVALUE;
    int _1146 = NOVALUE;
    int _1145 = NOVALUE;
    int _1144 = NOVALUE;
    int _1143 = NOVALUE;
    int _1139 = NOVALUE;
    int _1135 = NOVALUE;
    int _1127 = NOVALUE;
    int _1116 = NOVALUE;
    int _1115 = NOVALUE;
    int _1109 = NOVALUE;
    int _1107 = NOVALUE;
    int _1101 = NOVALUE;
    int _1100 = NOVALUE;
    int _1099 = NOVALUE;
    int _1098 = NOVALUE;
    int _1097 = NOVALUE;
    int _1096 = NOVALUE;
    int _1095 = NOVALUE;
    int _1094 = NOVALUE;
    int _1093 = NOVALUE;
    int _1085 = NOVALUE;
    int _1084 = NOVALUE;
    int _1083 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer lDotFound = 0*/
    _lDotFound_2424 = 0;

    /** 	integer lSignFound = 2*/
    _lSignFound_2425 = 2;

    /** 	integer lBadPos = 0*/
    _lBadPos_2427 = 0;

    /** 	atom    lLeftSize = 0*/
    DeRef(_lLeftSize_2428);
    _lLeftSize_2428 = 0;

    /** 	atom    lRightSize = 1*/
    DeRef(_lRightSize_2429);
    _lRightSize_2429 = 1;

    /** 	atom    lLeftValue = 0*/
    DeRef(_lLeftValue_2430);
    _lLeftValue_2430 = 0;

    /** 	atom    lRightValue = 0*/
    DeRef(_lRightValue_2431);
    _lRightValue_2431 = 0;

    /** 	integer lBase = 10*/
    _lBase_2432 = 10;

    /** 	integer lPercent = 1*/
    _lPercent_2433 = 1;

    /** 	integer lDigitCount = 0*/
    _lDigitCount_2435 = 0;

    /** 	integer lCurrencyFound = 0*/
    _lCurrencyFound_2436 = 0;

    /** 	integer lLastDigit = 0*/
    _lLastDigit_2437 = 0;

    /** 	for i = 1 to length(text_in) do*/
    if (IS_SEQUENCE(_text_in_2422)){
            _1083 = SEQ_PTR(_text_in_2422)->length;
    }
    else {
        _1083 = 1;
    }
    {
        int _i_2440;
        _i_2440 = 1;
L1: 
        if (_i_2440 > _1083){
            goto L2; // [70] 672
        }

        /** 		if not integer(text_in[i]) then*/
        _2 = (int)SEQ_PTR(_text_in_2422);
        _1084 = (int)*(((s1_ptr)_2)->base + _i_2440);
        if (IS_ATOM_INT(_1084))
        _1085 = 1;
        else if (IS_ATOM_DBL(_1084))
        _1085 = IS_ATOM_INT(DoubleToInt(_1084));
        else
        _1085 = 0;
        _1084 = NOVALUE;
        if (_1085 != 0)
        goto L3; // [86] 94
        _1085 = NOVALUE;

        /** 			exit*/
        goto L2; // [91] 672
L3: 

        /** 		lChar = text_in[i]*/
        _2 = (int)SEQ_PTR(_text_in_2422);
        _lChar_2438 = (int)*(((s1_ptr)_2)->base + _i_2440);
        if (!IS_ATOM_INT(_lChar_2438))
        _lChar_2438 = (long)DBL_PTR(_lChar_2438)->dbl;

        /** 		switch lChar do*/
        _0 = _lChar_2438;
        switch ( _0 ){ 

            /** 			case '-' then*/
            case 45:

            /** 				if lSignFound = 2 then*/
            if (_lSignFound_2425 != 2)
            goto L4; // [113] 130

            /** 					lSignFound = -1*/
            _lSignFound_2425 = -1;

            /** 					lLastDigit = lDigitCount*/
            _lLastDigit_2437 = _lDigitCount_2435;
            goto L5; // [127] 654
L4: 

            /** 					lBadPos = i*/
            _lBadPos_2427 = _i_2440;
            goto L5; // [136] 654

            /** 			case '+' then*/
            case 43:

            /** 				if lSignFound = 2 then*/
            if (_lSignFound_2425 != 2)
            goto L6; // [144] 161

            /** 					lSignFound = 1*/
            _lSignFound_2425 = 1;

            /** 					lLastDigit = lDigitCount*/
            _lLastDigit_2437 = _lDigitCount_2435;
            goto L5; // [158] 654
L6: 

            /** 					lBadPos = i*/
            _lBadPos_2427 = _i_2440;
            goto L5; // [167] 654

            /** 			case '#' then*/
            case 35:

            /** 				if lDigitCount = 0 and lBase = 10 then*/
            _1093 = (_lDigitCount_2435 == 0);
            if (_1093 == 0) {
                goto L7; // [179] 199
            }
            _1095 = (_lBase_2432 == 10);
            if (_1095 == 0)
            {
                DeRef(_1095);
                _1095 = NOVALUE;
                goto L7; // [188] 199
            }
            else{
                DeRef(_1095);
                _1095 = NOVALUE;
            }

            /** 					lBase = 16*/
            _lBase_2432 = 16;
            goto L5; // [196] 654
L7: 

            /** 					lBadPos = i*/
            _lBadPos_2427 = _i_2440;
            goto L5; // [205] 654

            /** 			case '@' then*/
            case 64:

            /** 				if lDigitCount = 0  and lBase = 10 then*/
            _1096 = (_lDigitCount_2435 == 0);
            if (_1096 == 0) {
                goto L8; // [217] 237
            }
            _1098 = (_lBase_2432 == 10);
            if (_1098 == 0)
            {
                DeRef(_1098);
                _1098 = NOVALUE;
                goto L8; // [226] 237
            }
            else{
                DeRef(_1098);
                _1098 = NOVALUE;
            }

            /** 					lBase = 8*/
            _lBase_2432 = 8;
            goto L5; // [234] 654
L8: 

            /** 					lBadPos = i*/
            _lBadPos_2427 = _i_2440;
            goto L5; // [243] 654

            /** 			case '!' then*/
            case 33:

            /** 				if lDigitCount = 0  and lBase = 10 then*/
            _1099 = (_lDigitCount_2435 == 0);
            if (_1099 == 0) {
                goto L9; // [255] 275
            }
            _1101 = (_lBase_2432 == 10);
            if (_1101 == 0)
            {
                DeRef(_1101);
                _1101 = NOVALUE;
                goto L9; // [264] 275
            }
            else{
                DeRef(_1101);
                _1101 = NOVALUE;
            }

            /** 					lBase = 2*/
            _lBase_2432 = 2;
            goto L5; // [272] 654
L9: 

            /** 					lBadPos = i*/
            _lBadPos_2427 = _i_2440;
            goto L5; // [281] 654

            /** 			case '$', '�', '�', '�', '�' then*/
            case 36:
            case 163:
            case 164:
            case 165:
            case 128:

            /** 				if lCurrencyFound = 0 then*/
            if (_lCurrencyFound_2436 != 0)
            goto LA; // [297] 314

            /** 					lCurrencyFound = 1*/
            _lCurrencyFound_2436 = 1;

            /** 					lLastDigit = lDigitCount*/
            _lLastDigit_2437 = _lDigitCount_2435;
            goto L5; // [311] 654
LA: 

            /** 					lBadPos = i*/
            _lBadPos_2427 = _i_2440;
            goto L5; // [320] 654

            /** 			case '_' then -- grouping character*/
            case 95:

            /** 				if lDigitCount = 0 or lLastDigit != 0 then*/
            _1107 = (_lDigitCount_2435 == 0);
            if (_1107 != 0) {
                goto LB; // [332] 345
            }
            _1109 = (_lLastDigit_2437 != 0);
            if (_1109 == 0)
            {
                DeRef(_1109);
                _1109 = NOVALUE;
                goto L5; // [341] 654
            }
            else{
                DeRef(_1109);
                _1109 = NOVALUE;
            }
LB: 

            /** 					lBadPos = i*/
            _lBadPos_2427 = _i_2440;
            goto L5; // [351] 654

            /** 			case '.', ',' then*/
            case 46:
            case 44:

            /** 				if lLastDigit = 0 then*/
            if (_lLastDigit_2437 != 0)
            goto LC; // [361] 400

            /** 					if decimal_mark = lChar then*/
            if (46 != _lChar_2438)
            goto L5; // [369] 654

            /** 						if lDotFound = 0 then*/
            if (_lDotFound_2424 != 0)
            goto LD; // [375] 387

            /** 							lDotFound = 1*/
            _lDotFound_2424 = 1;
            goto L5; // [384] 654
LD: 

            /** 							lBadPos = i*/
            _lBadPos_2427 = _i_2440;
            goto L5; // [393] 654
            goto L5; // [397] 654
LC: 

            /** 					lBadPos = i*/
            _lBadPos_2427 = _i_2440;
            goto L5; // [406] 654

            /** 			case '%' then*/
            case 37:

            /** 				lLastDigit = lDigitCount*/
            _lLastDigit_2437 = _lDigitCount_2435;

            /** 				if lPercent = 1 then*/
            if (_lPercent_2433 != 1)
            goto LE; // [419] 431

            /** 					lPercent = 100*/
            _lPercent_2433 = 100;
            goto L5; // [428] 654
LE: 

            /** 					if text_in[i-1] = '%' then*/
            _1115 = _i_2440 - 1;
            _2 = (int)SEQ_PTR(_text_in_2422);
            _1116 = (int)*(((s1_ptr)_2)->base + _1115);
            if (binary_op_a(NOTEQ, _1116, 37)){
                _1116 = NOVALUE;
                goto LF; // [441] 456
            }
            _1116 = NOVALUE;

            /** 						lPercent *= 10 -- Yes ten not one hundred.*/
            _lPercent_2433 = _lPercent_2433 * 10;
            goto L5; // [453] 654
LF: 

            /** 						lBadPos = i*/
            _lBadPos_2427 = _i_2440;
            goto L5; // [463] 654

            /** 			case '\t', ' ', #A0 then*/
            case 9:
            case 32:
            case 160:

            /** 				if lDigitCount = 0 then*/
            if (_lDigitCount_2435 != 0)
            goto L10; // [475] 482
            goto L5; // [479] 654
L10: 

            /** 					lLastDigit = i*/
            _lLastDigit_2437 = _i_2440;
            goto L5; // [488] 654

            /** 			case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',*/
            case 48:
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
            case 65:
            case 66:
            case 67:
            case 68:
            case 69:
            case 70:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 102:

            /** 	            lCharValue = find(lChar, vDigits) - 1*/
            _1127 = find_from(_lChar_2438, _13vDigits_2409, 1);
            _lCharValue_2426 = _1127 - 1;
            _1127 = NOVALUE;

            /** 	            if lCharValue > 15 then*/
            if (_lCharValue_2426 <= 15)
            goto L11; // [549] 560

            /** 	            	lCharValue -= 6*/
            _lCharValue_2426 = _lCharValue_2426 - 6;
L11: 

            /** 	            if lCharValue >= lBase then*/
            if (_lCharValue_2426 < _lBase_2432)
            goto L12; // [562] 574

            /** 	                lBadPos = i*/
            _lBadPos_2427 = _i_2440;
            goto L5; // [571] 654
L12: 

            /** 	            elsif lLastDigit != 0 then  -- shouldn't be any more digits*/
            if (_lLastDigit_2437 == 0)
            goto L13; // [576] 588

            /** 					lBadPos = i*/
            _lBadPos_2427 = _i_2440;
            goto L5; // [585] 654
L13: 

            /** 				elsif lDotFound = 1 then*/
            if (_lDotFound_2424 != 1)
            goto L14; // [590] 619

            /** 					lRightSize *= lBase*/
            _0 = _lRightSize_2429;
            if (IS_ATOM_INT(_lRightSize_2429)) {
                if (_lRightSize_2429 == (short)_lRightSize_2429 && _lBase_2432 <= INT15 && _lBase_2432 >= -INT15)
                _lRightSize_2429 = _lRightSize_2429 * _lBase_2432;
                else
                _lRightSize_2429 = NewDouble(_lRightSize_2429 * (double)_lBase_2432);
            }
            else {
                _lRightSize_2429 = NewDouble(DBL_PTR(_lRightSize_2429)->dbl * (double)_lBase_2432);
            }
            DeRef(_0);

            /** 					lRightValue = (lRightValue * lBase) + lCharValue*/
            if (IS_ATOM_INT(_lRightValue_2431)) {
                if (_lRightValue_2431 == (short)_lRightValue_2431 && _lBase_2432 <= INT15 && _lBase_2432 >= -INT15)
                _1135 = _lRightValue_2431 * _lBase_2432;
                else
                _1135 = NewDouble(_lRightValue_2431 * (double)_lBase_2432);
            }
            else {
                _1135 = NewDouble(DBL_PTR(_lRightValue_2431)->dbl * (double)_lBase_2432);
            }
            DeRef(_lRightValue_2431);
            if (IS_ATOM_INT(_1135)) {
                _lRightValue_2431 = _1135 + _lCharValue_2426;
                if ((long)((unsigned long)_lRightValue_2431 + (unsigned long)HIGH_BITS) >= 0) 
                _lRightValue_2431 = NewDouble((double)_lRightValue_2431);
            }
            else {
                _lRightValue_2431 = NewDouble(DBL_PTR(_1135)->dbl + (double)_lCharValue_2426);
            }
            DeRef(_1135);
            _1135 = NOVALUE;

            /** 					lDigitCount += 1*/
            _lDigitCount_2435 = _lDigitCount_2435 + 1;
            goto L5; // [616] 654
L14: 

            /** 					lLeftSize += 1*/
            _0 = _lLeftSize_2428;
            if (IS_ATOM_INT(_lLeftSize_2428)) {
                _lLeftSize_2428 = _lLeftSize_2428 + 1;
                if (_lLeftSize_2428 > MAXINT){
                    _lLeftSize_2428 = NewDouble((double)_lLeftSize_2428);
                }
            }
            else
            _lLeftSize_2428 = binary_op(PLUS, 1, _lLeftSize_2428);
            DeRef(_0);

            /** 					lLeftValue = (lLeftValue * lBase) + lCharValue*/
            if (IS_ATOM_INT(_lLeftValue_2430)) {
                if (_lLeftValue_2430 == (short)_lLeftValue_2430 && _lBase_2432 <= INT15 && _lBase_2432 >= -INT15)
                _1139 = _lLeftValue_2430 * _lBase_2432;
                else
                _1139 = NewDouble(_lLeftValue_2430 * (double)_lBase_2432);
            }
            else {
                _1139 = NewDouble(DBL_PTR(_lLeftValue_2430)->dbl * (double)_lBase_2432);
            }
            DeRef(_lLeftValue_2430);
            if (IS_ATOM_INT(_1139)) {
                _lLeftValue_2430 = _1139 + _lCharValue_2426;
                if ((long)((unsigned long)_lLeftValue_2430 + (unsigned long)HIGH_BITS) >= 0) 
                _lLeftValue_2430 = NewDouble((double)_lLeftValue_2430);
            }
            else {
                _lLeftValue_2430 = NewDouble(DBL_PTR(_1139)->dbl + (double)_lCharValue_2426);
            }
            DeRef(_1139);
            _1139 = NOVALUE;

            /** 					lDigitCount += 1*/
            _lDigitCount_2435 = _lDigitCount_2435 + 1;
            goto L5; // [642] 654

            /** 			case else*/
            default:

            /** 				lBadPos = i*/
            _lBadPos_2427 = _i_2440;
        ;}L5: 

        /** 		if lBadPos != 0 then*/
        if (_lBadPos_2427 == 0)
        goto L15; // [656] 665

        /** 			exit*/
        goto L2; // [662] 672
L15: 

        /** 	end for*/
        _i_2440 = _i_2440 + 1;
        goto L1; // [667] 77
L2: 
        ;
    }

    /** 	if lBadPos = 0 and lDigitCount = 0 then*/
    _1143 = (_lBadPos_2427 == 0);
    if (_1143 == 0) {
        goto L16; // [678] 696
    }
    _1145 = (_lDigitCount_2435 == 0);
    if (_1145 == 0)
    {
        DeRef(_1145);
        _1145 = NOVALUE;
        goto L16; // [687] 696
    }
    else{
        DeRef(_1145);
        _1145 = NOVALUE;
    }

    /** 		lBadPos = 1*/
    _lBadPos_2427 = 1;
L16: 

    /** 	if return_bad_pos = 0 and lBadPos != 0 then*/
    _1146 = (_return_bad_pos_2423 == 0);
    if (_1146 == 0) {
        goto L17; // [702] 721
    }
    _1148 = (_lBadPos_2427 != 0);
    if (_1148 == 0)
    {
        DeRef(_1148);
        _1148 = NOVALUE;
        goto L17; // [711] 721
    }
    else{
        DeRef(_1148);
        _1148 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_text_in_2422);
    DeRef(_lLeftSize_2428);
    DeRef(_lRightSize_2429);
    DeRef(_lLeftValue_2430);
    DeRef(_lRightValue_2431);
    DeRef(_lResult_2434);
    DeRef(_1093);
    _1093 = NOVALUE;
    DeRef(_1096);
    _1096 = NOVALUE;
    DeRef(_1099);
    _1099 = NOVALUE;
    DeRef(_1107);
    _1107 = NOVALUE;
    DeRef(_1115);
    _1115 = NOVALUE;
    DeRef(_1143);
    _1143 = NOVALUE;
    DeRef(_1146);
    _1146 = NOVALUE;
    return 0;
L17: 

    /** 	if lRightValue = 0 then*/
    if (binary_op_a(NOTEQ, _lRightValue_2431, 0)){
        goto L18; // [723] 751
    }

    /** 	    if lPercent != 1 then*/
    if (_lPercent_2433 == 1)
    goto L19; // [729] 742

    /** 			lResult = (lLeftValue / lPercent)*/
    DeRef(_lResult_2434);
    if (IS_ATOM_INT(_lLeftValue_2430)) {
        _lResult_2434 = (_lLeftValue_2430 % _lPercent_2433) ? NewDouble((double)_lLeftValue_2430 / _lPercent_2433) : (_lLeftValue_2430 / _lPercent_2433);
    }
    else {
        _lResult_2434 = NewDouble(DBL_PTR(_lLeftValue_2430)->dbl / (double)_lPercent_2433);
    }
    goto L1A; // [739] 786
L19: 

    /** 	        lResult = lLeftValue*/
    Ref(_lLeftValue_2430);
    DeRef(_lResult_2434);
    _lResult_2434 = _lLeftValue_2430;
    goto L1A; // [748] 786
L18: 

    /** 	    if lPercent != 1 then*/
    if (_lPercent_2433 == 1)
    goto L1B; // [753] 774

    /** 	        lResult = (lLeftValue  + (lRightValue / (lRightSize))) / lPercent*/
    if (IS_ATOM_INT(_lRightValue_2431) && IS_ATOM_INT(_lRightSize_2429)) {
        _1153 = (_lRightValue_2431 % _lRightSize_2429) ? NewDouble((double)_lRightValue_2431 / _lRightSize_2429) : (_lRightValue_2431 / _lRightSize_2429);
    }
    else {
        if (IS_ATOM_INT(_lRightValue_2431)) {
            _1153 = NewDouble((double)_lRightValue_2431 / DBL_PTR(_lRightSize_2429)->dbl);
        }
        else {
            if (IS_ATOM_INT(_lRightSize_2429)) {
                _1153 = NewDouble(DBL_PTR(_lRightValue_2431)->dbl / (double)_lRightSize_2429);
            }
            else
            _1153 = NewDouble(DBL_PTR(_lRightValue_2431)->dbl / DBL_PTR(_lRightSize_2429)->dbl);
        }
    }
    if (IS_ATOM_INT(_lLeftValue_2430) && IS_ATOM_INT(_1153)) {
        _1154 = _lLeftValue_2430 + _1153;
        if ((long)((unsigned long)_1154 + (unsigned long)HIGH_BITS) >= 0) 
        _1154 = NewDouble((double)_1154);
    }
    else {
        if (IS_ATOM_INT(_lLeftValue_2430)) {
            _1154 = NewDouble((double)_lLeftValue_2430 + DBL_PTR(_1153)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1153)) {
                _1154 = NewDouble(DBL_PTR(_lLeftValue_2430)->dbl + (double)_1153);
            }
            else
            _1154 = NewDouble(DBL_PTR(_lLeftValue_2430)->dbl + DBL_PTR(_1153)->dbl);
        }
    }
    DeRef(_1153);
    _1153 = NOVALUE;
    DeRef(_lResult_2434);
    if (IS_ATOM_INT(_1154)) {
        _lResult_2434 = (_1154 % _lPercent_2433) ? NewDouble((double)_1154 / _lPercent_2433) : (_1154 / _lPercent_2433);
    }
    else {
        _lResult_2434 = NewDouble(DBL_PTR(_1154)->dbl / (double)_lPercent_2433);
    }
    DeRef(_1154);
    _1154 = NOVALUE;
    goto L1C; // [771] 785
L1B: 

    /** 	        lResult = lLeftValue + (lRightValue / lRightSize)*/
    if (IS_ATOM_INT(_lRightValue_2431) && IS_ATOM_INT(_lRightSize_2429)) {
        _1156 = (_lRightValue_2431 % _lRightSize_2429) ? NewDouble((double)_lRightValue_2431 / _lRightSize_2429) : (_lRightValue_2431 / _lRightSize_2429);
    }
    else {
        if (IS_ATOM_INT(_lRightValue_2431)) {
            _1156 = NewDouble((double)_lRightValue_2431 / DBL_PTR(_lRightSize_2429)->dbl);
        }
        else {
            if (IS_ATOM_INT(_lRightSize_2429)) {
                _1156 = NewDouble(DBL_PTR(_lRightValue_2431)->dbl / (double)_lRightSize_2429);
            }
            else
            _1156 = NewDouble(DBL_PTR(_lRightValue_2431)->dbl / DBL_PTR(_lRightSize_2429)->dbl);
        }
    }
    DeRef(_lResult_2434);
    if (IS_ATOM_INT(_lLeftValue_2430) && IS_ATOM_INT(_1156)) {
        _lResult_2434 = _lLeftValue_2430 + _1156;
        if ((long)((unsigned long)_lResult_2434 + (unsigned long)HIGH_BITS) >= 0) 
        _lResult_2434 = NewDouble((double)_lResult_2434);
    }
    else {
        if (IS_ATOM_INT(_lLeftValue_2430)) {
            _lResult_2434 = NewDouble((double)_lLeftValue_2430 + DBL_PTR(_1156)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1156)) {
                _lResult_2434 = NewDouble(DBL_PTR(_lLeftValue_2430)->dbl + (double)_1156);
            }
            else
            _lResult_2434 = NewDouble(DBL_PTR(_lLeftValue_2430)->dbl + DBL_PTR(_1156)->dbl);
        }
    }
    DeRef(_1156);
    _1156 = NOVALUE;
L1C: 
L1A: 

    /** 	if lSignFound < 0 then*/
    if (_lSignFound_2425 >= 0)
    goto L1D; // [788] 800

    /** 		lResult = -lResult*/
    _0 = _lResult_2434;
    if (IS_ATOM_INT(_lResult_2434)) {
        if ((unsigned long)_lResult_2434 == 0xC0000000)
        _lResult_2434 = (int)NewDouble((double)-0xC0000000);
        else
        _lResult_2434 = - _lResult_2434;
    }
    else {
        _lResult_2434 = unary_op(UMINUS, _lResult_2434);
    }
    DeRef(_0);
L1D: 

    /** 	if return_bad_pos = 0 then*/
    if (_return_bad_pos_2423 != 0)
    goto L1E; // [802] 815

    /** 		return lResult*/
    DeRefDS(_text_in_2422);
    DeRef(_lLeftSize_2428);
    DeRef(_lRightSize_2429);
    DeRef(_lLeftValue_2430);
    DeRef(_lRightValue_2431);
    DeRef(_1093);
    _1093 = NOVALUE;
    DeRef(_1096);
    _1096 = NOVALUE;
    DeRef(_1099);
    _1099 = NOVALUE;
    DeRef(_1107);
    _1107 = NOVALUE;
    DeRef(_1115);
    _1115 = NOVALUE;
    DeRef(_1143);
    _1143 = NOVALUE;
    DeRef(_1146);
    _1146 = NOVALUE;
    return _lResult_2434;
L1E: 

    /** 	if return_bad_pos = -1 then*/
    if (_return_bad_pos_2423 != -1)
    goto L1F; // [817] 850

    /** 		if lBadPos = 0 then*/
    if (_lBadPos_2427 != 0)
    goto L20; // [823] 838

    /** 			return lResult*/
    DeRefDS(_text_in_2422);
    DeRef(_lLeftSize_2428);
    DeRef(_lRightSize_2429);
    DeRef(_lLeftValue_2430);
    DeRef(_lRightValue_2431);
    DeRef(_1093);
    _1093 = NOVALUE;
    DeRef(_1096);
    _1096 = NOVALUE;
    DeRef(_1099);
    _1099 = NOVALUE;
    DeRef(_1107);
    _1107 = NOVALUE;
    DeRef(_1115);
    _1115 = NOVALUE;
    DeRef(_1143);
    _1143 = NOVALUE;
    DeRef(_1146);
    _1146 = NOVALUE;
    return _lResult_2434;
    goto L21; // [835] 849
L20: 

    /** 			return {lBadPos}	*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _lBadPos_2427;
    _1163 = MAKE_SEQ(_1);
    DeRefDS(_text_in_2422);
    DeRef(_lLeftSize_2428);
    DeRef(_lRightSize_2429);
    DeRef(_lLeftValue_2430);
    DeRef(_lRightValue_2431);
    DeRef(_lResult_2434);
    DeRef(_1093);
    _1093 = NOVALUE;
    DeRef(_1096);
    _1096 = NOVALUE;
    DeRef(_1099);
    _1099 = NOVALUE;
    DeRef(_1107);
    _1107 = NOVALUE;
    DeRef(_1115);
    _1115 = NOVALUE;
    DeRef(_1143);
    _1143 = NOVALUE;
    DeRef(_1146);
    _1146 = NOVALUE;
    return _1163;
L21: 
L1F: 

    /** 	return {lResult, lBadPos}*/
    Ref(_lResult_2434);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _lResult_2434;
    ((int *)_2)[2] = _lBadPos_2427;
    _1164 = MAKE_SEQ(_1);
    DeRefDS(_text_in_2422);
    DeRef(_lLeftSize_2428);
    DeRef(_lRightSize_2429);
    DeRef(_lLeftValue_2430);
    DeRef(_lRightValue_2431);
    DeRef(_lResult_2434);
    DeRef(_1093);
    _1093 = NOVALUE;
    DeRef(_1096);
    _1096 = NOVALUE;
    DeRef(_1099);
    _1099 = NOVALUE;
    DeRef(_1107);
    _1107 = NOVALUE;
    DeRef(_1115);
    _1115 = NOVALUE;
    DeRef(_1143);
    _1143 = NOVALUE;
    DeRef(_1146);
    _1146 = NOVALUE;
    DeRef(_1163);
    _1163 = NOVALUE;
    return _1164;
    ;
}



// 0x06231A03
