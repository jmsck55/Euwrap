// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _65block_type_name(int _opcode_45706)
{
    int _24171 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_45706)) {
        _1 = (long)(DBL_PTR(_opcode_45706)->dbl);
        DeRefDS(_opcode_45706);
        _opcode_45706 = _1;
    }

    /** 	switch opcode do*/
    _0 = _opcode_45706;
    switch ( _0 ){ 

        /** 		case LOOP then*/
        case 422:

        /** 			return "LOOP"*/
        RefDS(_24169);
        return _24169;
        goto L1; // [20] 63

        /** 		case PROC then*/
        case 27:

        /** 			return "PROC"*/
        RefDS(_21795);
        return _21795;
        goto L1; // [32] 63

        /** 		case FUNC then*/
        case 501:

        /** 			return "FUNC"*/
        RefDS(_24170);
        return _24170;
        goto L1; // [44] 63

        /** 		case else*/
        default:

        /** 			return opnames[opcode]*/
        _2 = (int)SEQ_PTR(_59opnames_22236);
        _24171 = (int)*(((s1_ptr)_2)->base + _opcode_45706);
        RefDS(_24171);
        return _24171;
    ;}L1: 
    ;
}


void _65check_block(int _got_45722)
{
    int _expected_45723 = NOVALUE;
    int _24179 = NOVALUE;
    int _24178 = NOVALUE;
    int _24177 = NOVALUE;
    int _24173 = NOVALUE;
    int _24172 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer expected = block_stack[$][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24172 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24172 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    _24173 = (int)*(((s1_ptr)_2)->base + _24172);
    _2 = (int)SEQ_PTR(_24173);
    _expected_45723 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_expected_45723)){
        _expected_45723 = (long)DBL_PTR(_expected_45723)->dbl;
    }
    _24173 = NOVALUE;

    /** 	if got = FUNC then*/
    if (_got_45722 != 501)
    goto L1; // [24] 38

    /** 		got = PROC*/
    _got_45722 = 27;
L1: 

    /** 	if got != expected then*/
    if (_got_45722 == _expected_45723)
    goto L2; // [40] 64

    /** 		CompileErr( 79, {block_type_name( expected ), block_type_name( got)} )*/
    _24177 = _65block_type_name(_expected_45723);
    _24178 = _65block_type_name(_got_45722);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24177;
    ((int *)_2)[2] = _24178;
    _24179 = MAKE_SEQ(_1);
    _24178 = NOVALUE;
    _24177 = NOVALUE;
    _43CompileErr(79, _24179, 0);
    _24179 = NOVALUE;
L2: 

    /** end procedure*/
    return;
    ;
}


void _65Block_var(int _sym_45740)
{
    int _block_45741 = NOVALUE;
    int _24200 = NOVALUE;
    int _24199 = NOVALUE;
    int _24198 = NOVALUE;
    int _24196 = NOVALUE;
    int _24195 = NOVALUE;
    int _24193 = NOVALUE;
    int _24192 = NOVALUE;
    int _24191 = NOVALUE;
    int _24190 = NOVALUE;
    int _24189 = NOVALUE;
    int _24188 = NOVALUE;
    int _24187 = NOVALUE;
    int _24185 = NOVALUE;
    int _24183 = NOVALUE;
    int _24182 = NOVALUE;
    int _24180 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_45740)) {
        _1 = (long)(DBL_PTR(_sym_45740)->dbl);
        DeRefDS(_sym_45740);
        _sym_45740 = _1;
    }

    /** 	sequence block = block_stack[$]*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24180 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24180 = 1;
    }
    DeRef(_block_45741);
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    _block_45741 = (int)*(((s1_ptr)_2)->base + _24180);
    Ref(_block_45741);

    /** 	block_stack[$] = 0*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24182 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24182 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    _2 = (int)(((s1_ptr)_2)->base + _24182);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	if length(block_stack) > 1 then*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24183 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24183 = 1;
    }
    if (_24183 <= 1)
    goto L1; // [34] 58

    /** 		SymTab[sym][S_BLOCK] = block[BLOCK_SYM]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_45740 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_block_45741);
    _24187 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_24187);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_BLOCK_11674))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_BLOCK_11674)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_BLOCK_11674);
    _1 = *(int *)_2;
    *(int *)_2 = _24187;
    if( _1 != _24187 ){
        DeRef(_1);
    }
    _24187 = NOVALUE;
    _24185 = NOVALUE;
L1: 

    /** 	if length(block[BLOCK_VARS]) then*/
    _2 = (int)SEQ_PTR(_block_45741);
    _24188 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_24188)){
            _24189 = SEQ_PTR(_24188)->length;
    }
    else {
        _24189 = 1;
    }
    _24188 = NOVALUE;
    if (_24189 == 0)
    {
        _24189 = NOVALUE;
        goto L2; // [67] 99
    }
    else{
        _24189 = NOVALUE;
    }

    /** 		SymTab[block[BLOCK_VARS][$]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (int)SEQ_PTR(_block_45741);
    _24190 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_24190)){
            _24191 = SEQ_PTR(_24190)->length;
    }
    else {
        _24191 = 1;
    }
    _2 = (int)SEQ_PTR(_24190);
    _24192 = (int)*(((s1_ptr)_2)->base + _24191);
    _24190 = NOVALUE;
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_24192))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_24192)->dbl));
    else
    _3 = (int)(_24192 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_NEXT_IN_BLOCK_11646))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NEXT_IN_BLOCK_11646)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_NEXT_IN_BLOCK_11646);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_45740;
    DeRef(_1);
    _24193 = NOVALUE;
    goto L3; // [96] 119
L2: 

    /** 		SymTab[block[BLOCK_SYM]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (int)SEQ_PTR(_block_45741);
    _24195 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_24195))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_24195)->dbl));
    else
    _3 = (int)(_24195 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_NEXT_IN_BLOCK_11646))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NEXT_IN_BLOCK_11646)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_NEXT_IN_BLOCK_11646);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_45740;
    DeRef(_1);
    _24196 = NOVALUE;
L3: 

    /** 	block[BLOCK_VARS] &= sym*/
    _2 = (int)SEQ_PTR(_block_45741);
    _24198 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_24198) && IS_ATOM(_sym_45740)) {
        Append(&_24199, _24198, _sym_45740);
    }
    else if (IS_ATOM(_24198) && IS_SEQUENCE(_sym_45740)) {
    }
    else {
        Concat((object_ptr)&_24199, _24198, _sym_45740);
        _24198 = NOVALUE;
    }
    _24198 = NOVALUE;
    _2 = (int)SEQ_PTR(_block_45741);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45741 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _24199;
    if( _1 != _24199 ){
        DeRef(_1);
    }
    _24199 = NOVALUE;

    /** 	block_stack[$] = block*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24200 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24200 = 1;
    }
    RefDS(_block_45741);
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    _2 = (int)(((s1_ptr)_2)->base + _24200);
    _1 = *(int *)_2;
    *(int *)_2 = _block_45741;
    DeRef(_1);

    /** 	ifdef BDEBUG then*/

    /** end procedure*/
    DeRefDS(_block_45741);
    _24188 = NOVALUE;
    _24192 = NOVALUE;
    _24195 = NOVALUE;
    return;
    ;
}


void _65NewBlock(int _opcode_45775, int _block_label_45776)
{
    int _block_45794 = NOVALUE;
    int _24214 = NOVALUE;
    int _24213 = NOVALUE;
    int _24212 = NOVALUE;
    int _24210 = NOVALUE;
    int _24208 = NOVALUE;
    int _24207 = NOVALUE;
    int _24205 = NOVALUE;
    int _24204 = NOVALUE;
    int _24202 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	SymTab = append( SymTab, repeat( 0, SIZEOF_BLOCK_ENTRY ) )*/
    _24202 = Repeat(0, _26SIZEOF_BLOCK_ENTRY_11785);
    RefDS(_24202);
    Append(&_27SymTab_10921, _27SymTab_10921, _24202);
    DeRefDS(_24202);
    _24202 = NOVALUE;

    /** 	SymTab[$][S_MODE] = M_BLOCK*/
    if (IS_SEQUENCE(_27SymTab_10921)){
            _24204 = SEQ_PTR(_27SymTab_10921)->length;
    }
    else {
        _24204 = 1;
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_24204 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);
    _24205 = NOVALUE;

    /** 	SymTab[$][S_FIRST_LINE] = gline_number*/
    if (IS_SEQUENCE(_27SymTab_10921)){
            _24207 = SEQ_PTR(_27SymTab_10921)->length;
    }
    else {
        _24207 = 1;
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_24207 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_FIRST_LINE_11679))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FIRST_LINE_11679)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_FIRST_LINE_11679);
    _1 = *(int *)_2;
    *(int *)_2 = _26gline_number_11987;
    DeRef(_1);
    _24208 = NOVALUE;

    /** 	sequence block = repeat( 0, BLOCK_SIZE-1 )*/
    _24210 = 6;
    DeRef(_block_45794);
    _block_45794 = Repeat(0, 6);
    _24210 = NOVALUE;

    /** 	block[BLOCK_SYM]    = length(SymTab)*/
    if (IS_SEQUENCE(_27SymTab_10921)){
            _24212 = SEQ_PTR(_27SymTab_10921)->length;
    }
    else {
        _24212 = 1;
    }
    _2 = (int)SEQ_PTR(_block_45794);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45794 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    *(int *)_2 = _24212;
    if( _1 != _24212 ){
    }
    _24212 = NOVALUE;

    /** 	block[BLOCK_OPCODE] = opcode*/
    _2 = (int)SEQ_PTR(_block_45794);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45794 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    *(int *)_2 = _opcode_45775;

    /** 	block[BLOCK_LABEL]  = block_label*/
    Ref(_block_label_45776);
    _2 = (int)SEQ_PTR(_block_45794);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45794 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    *(int *)_2 = _block_label_45776;

    /** 	block[BLOCK_START]  = length(Code) + 1*/
    if (IS_SEQUENCE(_26Code_12071)){
            _24213 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _24213 = 1;
    }
    _24214 = _24213 + 1;
    _24213 = NOVALUE;
    _2 = (int)SEQ_PTR(_block_45794);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45794 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _24214;
    if( _1 != _24214 ){
        DeRef(_1);
    }
    _24214 = NOVALUE;

    /** 	block[BLOCK_VARS]   = {}*/
    RefDS(_22037);
    _2 = (int)SEQ_PTR(_block_45794);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45794 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _22037;
    DeRef(_1);

    /** 	block_stack = append( block_stack, block )*/
    RefDS(_block_45794);
    Append(&_65block_stack_45696, _65block_stack_45696, _block_45794);

    /** 	current_block = length(SymTab)*/
    if (IS_SEQUENCE(_27SymTab_10921)){
            _65current_block_45703 = SEQ_PTR(_27SymTab_10921)->length;
    }
    else {
        _65current_block_45703 = 1;
    }

    /** end procedure*/
    DeRef(_block_label_45776);
    DeRefDS(_block_45794);
    return;
    ;
}


void _65Start_block(int _opcode_45807, int _block_label_45808)
{
    int _last_block_45810 = NOVALUE;
    int _label_name_45838 = NOVALUE;
    int _24236 = NOVALUE;
    int _24235 = NOVALUE;
    int _24234 = NOVALUE;
    int _24231 = NOVALUE;
    int _24230 = NOVALUE;
    int _24228 = NOVALUE;
    int _24227 = NOVALUE;
    int _24226 = NOVALUE;
    int _24225 = NOVALUE;
    int _24224 = NOVALUE;
    int _24221 = NOVALUE;
    int _24219 = NOVALUE;
    int _24218 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_opcode_45807)) {
        _1 = (long)(DBL_PTR(_opcode_45807)->dbl);
        DeRefDS(_opcode_45807);
        _opcode_45807 = _1;
    }

    /** 	symtab_index last_block = current_block*/
    _last_block_45810 = _65current_block_45703;

    /** 	if opcode = FUNC then*/
    if (_opcode_45807 != 501)
    goto L1; // [16] 30

    /** 		opcode = PROC*/
    _opcode_45807 = 27;
L1: 

    /** 	NewBlock( opcode, block_label )*/
    Ref(_block_label_45808);
    _65NewBlock(_opcode_45807, _block_label_45808);

    /** 	if find(opcode, RTN_TOKS) then*/
    _24218 = find_from(_opcode_45807, _28RTN_TOKS_11602, 1);
    if (_24218 == 0)
    {
        _24218 = NOVALUE;
        goto L2; // [45] 105
    }
    else{
        _24218 = NOVALUE;
    }

    /** 		SymTab[block_label][S_BLOCK] = current_block*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_block_label_45808))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_block_label_45808)->dbl));
    else
    _3 = (int)(_block_label_45808 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_BLOCK_11674))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_BLOCK_11674)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_BLOCK_11674);
    _1 = *(int *)_2;
    *(int *)_2 = _65current_block_45703;
    DeRef(_1);
    _24219 = NOVALUE;

    /** 		SymTab[current_block][S_NAME] = sprintf("BLOCK: %s", {SymTab[block_label][S_NAME]})*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_65current_block_45703 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!IS_ATOM_INT(_block_label_45808)){
        _24224 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_block_label_45808)->dbl));
    }
    else{
        _24224 = (int)*(((s1_ptr)_2)->base + _block_label_45808);
    }
    _2 = (int)SEQ_PTR(_24224);
    if (!IS_ATOM_INT(_26S_NAME_11654)){
        _24225 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    }
    else{
        _24225 = (int)*(((s1_ptr)_2)->base + _26S_NAME_11654);
    }
    _24224 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_24225);
    *((int *)(_2+4)) = _24225;
    _24226 = MAKE_SEQ(_1);
    _24225 = NOVALUE;
    _24227 = EPrintf(-9999999, _24223, _24226);
    DeRefDS(_24226);
    _24226 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_NAME_11654))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_NAME_11654);
    _1 = *(int *)_2;
    *(int *)_2 = _24227;
    if( _1 != _24227 ){
        DeRef(_1);
    }
    _24227 = NOVALUE;
    _24221 = NOVALUE;
    goto L3; // [102] 185
L2: 

    /** 	elsif current_block then*/
    if (_65current_block_45703 == 0)
    {
        goto L4; // [109] 182
    }
    else{
    }

    /** 		SymTab[current_block][S_BLOCK] = last_block*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_65current_block_45703 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_BLOCK_11674))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_BLOCK_11674)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_BLOCK_11674);
    _1 = *(int *)_2;
    *(int *)_2 = _last_block_45810;
    DeRef(_1);
    _24228 = NOVALUE;

    /** 		sequence label_name = ""*/
    RefDS(_22037);
    DeRef(_label_name_45838);
    _label_name_45838 = _22037;

    /** 		if sequence(block_label) then*/
    _24230 = IS_SEQUENCE(_block_label_45808);
    if (_24230 == 0)
    {
        _24230 = NOVALUE;
        goto L5; // [141] 152
    }
    else{
        _24230 = NOVALUE;
    }

    /** 			label_name = block_label*/
    Ref(_block_label_45808);
    DeRefDS(_label_name_45838);
    _label_name_45838 = _block_label_45808;
L5: 

    /** 		SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", {block_type_name(opcode), label_name})*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_65current_block_45703 + ((s1_ptr)_2)->base);
    _24234 = _65block_type_name(_opcode_45807);
    RefDS(_label_name_45838);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24234;
    ((int *)_2)[2] = _label_name_45838;
    _24235 = MAKE_SEQ(_1);
    _24234 = NOVALUE;
    _24236 = EPrintf(-9999999, _24233, _24235);
    DeRefDS(_24235);
    _24235 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_NAME_11654))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_NAME_11654);
    _1 = *(int *)_2;
    *(int *)_2 = _24236;
    if( _1 != _24236 ){
        DeRef(_1);
    }
    _24236 = NOVALUE;
    _24231 = NOVALUE;
L4: 
    DeRef(_label_name_45838);
    _label_name_45838 = NOVALUE;
L3: 

    /** 	ifdef BDEBUG then*/

    /** end procedure*/
    DeRef(_block_label_45808);
    return;
    ;
}


void _65block_label(int _label_name_45854)
{
    int _24250 = NOVALUE;
    int _24249 = NOVALUE;
    int _24248 = NOVALUE;
    int _24247 = NOVALUE;
    int _24246 = NOVALUE;
    int _24245 = NOVALUE;
    int _24243 = NOVALUE;
    int _24241 = NOVALUE;
    int _24240 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	block_stack[$][BLOCK_LABEL] = label_name*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24240 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24240 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65block_stack_45696 = MAKE_SEQ(_2);
    }
    _3 = (int)(_24240 + ((s1_ptr)_2)->base);
    RefDS(_label_name_45854);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _label_name_45854;
    DeRef(_1);
    _24241 = NOVALUE;

    /** 	SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", */
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_65current_block_45703 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24245 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24245 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    _24246 = (int)*(((s1_ptr)_2)->base + _24245);
    _2 = (int)SEQ_PTR(_24246);
    _24247 = (int)*(((s1_ptr)_2)->base + 2);
    _24246 = NOVALUE;
    Ref(_24247);
    _24248 = _65block_type_name(_24247);
    _24247 = NOVALUE;
    RefDS(_label_name_45854);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24248;
    ((int *)_2)[2] = _label_name_45854;
    _24249 = MAKE_SEQ(_1);
    _24248 = NOVALUE;
    _24250 = EPrintf(-9999999, _24233, _24249);
    DeRefDS(_24249);
    _24249 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_NAME_11654))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NAME_11654)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_NAME_11654);
    _1 = *(int *)_2;
    *(int *)_2 = _24250;
    if( _1 != _24250 ){
        DeRef(_1);
    }
    _24250 = NOVALUE;
    _24243 = NOVALUE;

    /** end procedure*/
    DeRefDS(_label_name_45854);
    return;
    ;
}


int _65pop_block()
{
    int _block_45873 = NOVALUE;
    int _block_vars_45886 = NOVALUE;
    int _24279 = NOVALUE;
    int _24277 = NOVALUE;
    int _24276 = NOVALUE;
    int _24275 = NOVALUE;
    int _24274 = NOVALUE;
    int _24272 = NOVALUE;
    int _24271 = NOVALUE;
    int _24270 = NOVALUE;
    int _24269 = NOVALUE;
    int _24268 = NOVALUE;
    int _24267 = NOVALUE;
    int _24266 = NOVALUE;
    int _24265 = NOVALUE;
    int _24264 = NOVALUE;
    int _24263 = NOVALUE;
    int _24259 = NOVALUE;
    int _24258 = NOVALUE;
    int _24256 = NOVALUE;
    int _24255 = NOVALUE;
    int _24253 = NOVALUE;
    int _24251 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if not length(block_stack) then*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24251 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24251 = 1;
    }
    if (_24251 != 0)
    goto L1; // [8] 18
    _24251 = NOVALUE;

    /** 		return 0*/
    DeRef(_block_45873);
    DeRef(_block_vars_45886);
    return 0;
L1: 

    /** 	sequence  block = block_stack[$]*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24253 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24253 = 1;
    }
    DeRef(_block_45873);
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    _block_45873 = (int)*(((s1_ptr)_2)->base + _24253);
    Ref(_block_45873);

    /** 	block_stack = block_stack[1..$-1]*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24255 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24255 = 1;
    }
    _24256 = _24255 - 1;
    _24255 = NOVALUE;
    rhs_slice_target = (object_ptr)&_65block_stack_45696;
    RHS_Slice(_65block_stack_45696, 1, _24256);

    /** 	SymTab[block[BLOCK_SYM]][S_LAST_LINE] = gline_number*/
    _2 = (int)SEQ_PTR(_block_45873);
    _24258 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_24258))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_24258)->dbl));
    else
    _3 = (int)(_24258 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_LAST_LINE_11684))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_LAST_LINE_11684)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_LAST_LINE_11684);
    _1 = *(int *)_2;
    *(int *)_2 = _26gline_number_11987;
    DeRef(_1);
    _24259 = NOVALUE;

    /** 	ifdef BDEBUG then*/

    /** 	sequence block_vars = block[BLOCK_VARS]*/
    DeRef(_block_vars_45886);
    _2 = (int)SEQ_PTR(_block_45873);
    _block_vars_45886 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_block_vars_45886);

    /** 	for sx = 1 to length( block_vars ) do*/
    if (IS_SEQUENCE(_block_vars_45886)){
            _24263 = SEQ_PTR(_block_vars_45886)->length;
    }
    else {
        _24263 = 1;
    }
    {
        int _sx_45889;
        _sx_45889 = 1;
L2: 
        if (_sx_45889 > _24263){
            goto L3; // [83] 172
        }

        /** 		if SymTab[block_vars[sx]][S_MODE] = M_NORMAL */
        _2 = (int)SEQ_PTR(_block_vars_45886);
        _24264 = (int)*(((s1_ptr)_2)->base + _sx_45889);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!IS_ATOM_INT(_24264)){
            _24265 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24264)->dbl));
        }
        else{
            _24265 = (int)*(((s1_ptr)_2)->base + _24264);
        }
        _2 = (int)SEQ_PTR(_24265);
        _24266 = (int)*(((s1_ptr)_2)->base + 3);
        _24265 = NOVALUE;
        if (IS_ATOM_INT(_24266)) {
            _24267 = (_24266 == 1);
        }
        else {
            _24267 = binary_op(EQUALS, _24266, 1);
        }
        _24266 = NOVALUE;
        if (IS_ATOM_INT(_24267)) {
            if (_24267 == 0) {
                goto L4; // [114] 165
            }
        }
        else {
            if (DBL_PTR(_24267)->dbl == 0.0) {
                goto L4; // [114] 165
            }
        }
        _2 = (int)SEQ_PTR(_block_vars_45886);
        _24269 = (int)*(((s1_ptr)_2)->base + _sx_45889);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!IS_ATOM_INT(_24269)){
            _24270 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24269)->dbl));
        }
        else{
            _24270 = (int)*(((s1_ptr)_2)->base + _24269);
        }
        _2 = (int)SEQ_PTR(_24270);
        _24271 = (int)*(((s1_ptr)_2)->base + 4);
        _24270 = NOVALUE;
        if (IS_ATOM_INT(_24271)) {
            _24272 = (_24271 <= 5);
        }
        else {
            _24272 = binary_op(LESSEQ, _24271, 5);
        }
        _24271 = NOVALUE;
        if (_24272 == 0) {
            DeRef(_24272);
            _24272 = NOVALUE;
            goto L4; // [141] 165
        }
        else {
            if (!IS_ATOM_INT(_24272) && DBL_PTR(_24272)->dbl == 0.0){
                DeRef(_24272);
                _24272 = NOVALUE;
                goto L4; // [141] 165
            }
            DeRef(_24272);
            _24272 = NOVALUE;
        }
        DeRef(_24272);
        _24272 = NOVALUE;

        /** 			ifdef BDEBUG then*/

        /** 			Hide( block_vars[sx] )*/
        _2 = (int)SEQ_PTR(_block_vars_45886);
        _24274 = (int)*(((s1_ptr)_2)->base + _sx_45889);
        Ref(_24274);
        _52Hide(_24274);
        _24274 = NOVALUE;

        /** 			LintCheck( block_vars[sx] )*/
        _2 = (int)SEQ_PTR(_block_vars_45886);
        _24275 = (int)*(((s1_ptr)_2)->base + _sx_45889);
        Ref(_24275);
        _52LintCheck(_24275);
        _24275 = NOVALUE;
L4: 

        /** 	end for*/
        _sx_45889 = _sx_45889 + 1;
        goto L2; // [167] 90
L3: 
        ;
    }

    /** 	current_block = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24276 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24276 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    _24277 = (int)*(((s1_ptr)_2)->base + _24276);
    _2 = (int)SEQ_PTR(_24277);
    _65current_block_45703 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_65current_block_45703)){
        _65current_block_45703 = (long)DBL_PTR(_65current_block_45703)->dbl;
    }
    _24277 = NOVALUE;

    /** 	return block[BLOCK_SYM]*/
    _2 = (int)SEQ_PTR(_block_45873);
    _24279 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_24279);
    DeRefDS(_block_45873);
    DeRef(_block_vars_45886);
    DeRef(_24256);
    _24256 = NOVALUE;
    _24258 = NOVALUE;
    _24264 = NOVALUE;
    _24269 = NOVALUE;
    DeRef(_24267);
    _24267 = NOVALUE;
    return _24279;
    ;
}


int _65top_block(int _offset_45918)
{
    int _24287 = NOVALUE;
    int _24286 = NOVALUE;
    int _24285 = NOVALUE;
    int _24284 = NOVALUE;
    int _24283 = NOVALUE;
    int _24282 = NOVALUE;
    int _24280 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_offset_45918)) {
        _1 = (long)(DBL_PTR(_offset_45918)->dbl);
        DeRefDS(_offset_45918);
        _offset_45918 = _1;
    }

    /** 	if offset >= length(block_stack) then*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24280 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24280 = 1;
    }
    if (_offset_45918 < _24280)
    goto L1; // [10] 33

    /** 		CompileErr(107, {offset,length(block_stack)})*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24282 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24282 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _offset_45918;
    ((int *)_2)[2] = _24282;
    _24283 = MAKE_SEQ(_1);
    _24282 = NOVALUE;
    _43CompileErr(107, _24283, 0);
    _24283 = NOVALUE;
    goto L2; // [30] 57
L1: 

    /** 		return block_stack[$-offset][BLOCK_SYM]*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24284 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24284 = 1;
    }
    _24285 = _24284 - _offset_45918;
    _24284 = NOVALUE;
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    _24286 = (int)*(((s1_ptr)_2)->base + _24285);
    _2 = (int)SEQ_PTR(_24286);
    _24287 = (int)*(((s1_ptr)_2)->base + 1);
    _24286 = NOVALUE;
    Ref(_24287);
    _24285 = NOVALUE;
    return _24287;
L2: 
    ;
}


void _65End_block(int _opcode_45932)
{
    int _ix_45943 = NOVALUE;
    int _24295 = NOVALUE;
    int _24292 = NOVALUE;
    int _24291 = NOVALUE;
    int _24290 = NOVALUE;
    int _24289 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_45932)) {
        _1 = (long)(DBL_PTR(_opcode_45932)->dbl);
        DeRefDS(_opcode_45932);
        _opcode_45932 = _1;
    }

    /** 	if opcode = FUNC then*/
    if (_opcode_45932 != 501)
    goto L1; // [7] 21

    /** 		opcode = PROC*/
    _opcode_45932 = 27;
L1: 

    /** 	check_block( opcode )*/
    _65check_block(_opcode_45932);

    /** 	if not length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24289 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24289 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    _24290 = (int)*(((s1_ptr)_2)->base + _24289);
    _2 = (int)SEQ_PTR(_24290);
    _24291 = (int)*(((s1_ptr)_2)->base + 6);
    _24290 = NOVALUE;
    if (IS_SEQUENCE(_24291)){
            _24292 = SEQ_PTR(_24291)->length;
    }
    else {
        _24292 = 1;
    }
    _24291 = NOVALUE;
    if (_24292 != 0)
    goto L2; // [44] 64
    _24292 = NOVALUE;

    /** 		integer ix = 1*/
    _ix_45943 = 1;

    /** 		ix = pop_block()*/
    _ix_45943 = _65pop_block();
    if (!IS_ATOM_INT(_ix_45943)) {
        _1 = (long)(DBL_PTR(_ix_45943)->dbl);
        DeRefDS(_ix_45943);
        _ix_45943 = _1;
    }
    goto L3; // [61] 80
L2: 

    /** 		Push( pop_block() )*/
    _24295 = _65pop_block();
    _37Push(_24295);
    _24295 = NOVALUE;

    /** 		emit_op( EXIT_BLOCK )*/
    _37emit_op(206);
L3: 

    /** end procedure*/
    _24291 = NOVALUE;
    return;
    ;
}


int _65End_inline_block(int _opcode_45952)
{
    int _24302 = NOVALUE;
    int _24301 = NOVALUE;
    int _24300 = NOVALUE;
    int _24299 = NOVALUE;
    int _24298 = NOVALUE;
    int _24297 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_45952)) {
        _1 = (long)(DBL_PTR(_opcode_45952)->dbl);
        DeRefDS(_opcode_45952);
        _opcode_45952 = _1;
    }

    /** 	if opcode = FUNC then*/
    if (_opcode_45952 != 501)
    goto L1; // [7] 21

    /** 		opcode = PROC*/
    _opcode_45952 = 27;
L1: 

    /** 	if length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24297 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24297 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    _24298 = (int)*(((s1_ptr)_2)->base + _24297);
    _2 = (int)SEQ_PTR(_24298);
    _24299 = (int)*(((s1_ptr)_2)->base + 6);
    _24298 = NOVALUE;
    if (IS_SEQUENCE(_24299)){
            _24300 = SEQ_PTR(_24299)->length;
    }
    else {
        _24300 = 1;
    }
    _24299 = NOVALUE;
    if (_24300 == 0)
    {
        _24300 = NOVALUE;
        goto L2; // [39] 60
    }
    else{
        _24300 = NOVALUE;
    }

    /** 		return { EXIT_BLOCK, pop_block() }*/
    _24301 = _65pop_block();
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 206;
    ((int *)_2)[2] = _24301;
    _24302 = MAKE_SEQ(_1);
    _24301 = NOVALUE;
    _24299 = NOVALUE;
    return _24302;
    goto L3; // [57] 72
L2: 

    /** 		Drop_block( opcode )*/
    _65Drop_block(_opcode_45952);

    /** 		return {}*/
    RefDS(_22037);
    _24299 = NOVALUE;
    DeRef(_24302);
    _24302 = NOVALUE;
    return _22037;
L3: 
    ;
}


void _65Sibling_block(int _opcode_45969)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_45969)) {
        _1 = (long)(DBL_PTR(_opcode_45969)->dbl);
        DeRefDS(_opcode_45969);
        _opcode_45969 = _1;
    }

    /** 	End_block( opcode )*/
    _65End_block(_opcode_45969);

    /** 	Start_block( opcode )*/
    _65Start_block(_opcode_45969, 0);

    /** end procedure*/
    return;
    ;
}


void _65Leave_block(int _offset_45972)
{
    int _24308 = NOVALUE;
    int _24307 = NOVALUE;
    int _24306 = NOVALUE;
    int _24305 = NOVALUE;
    int _24304 = NOVALUE;
    int _24303 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_offset_45972)) {
        _1 = (long)(DBL_PTR(_offset_45972)->dbl);
        DeRefDS(_offset_45972);
        _offset_45972 = _1;
    }

    /** 	if length( block_stack[$-offset][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24303 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24303 = 1;
    }
    _24304 = _24303 - _offset_45972;
    _24303 = NOVALUE;
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    _24305 = (int)*(((s1_ptr)_2)->base + _24304);
    _2 = (int)SEQ_PTR(_24305);
    _24306 = (int)*(((s1_ptr)_2)->base + 6);
    _24305 = NOVALUE;
    if (IS_SEQUENCE(_24306)){
            _24307 = SEQ_PTR(_24306)->length;
    }
    else {
        _24307 = 1;
    }
    _24306 = NOVALUE;
    if (_24307 == 0)
    {
        _24307 = NOVALUE;
        goto L1; // [25] 45
    }
    else{
        _24307 = NOVALUE;
    }

    /** 		Push( top_block( offset ) )*/
    _24308 = _65top_block(_offset_45972);
    _37Push(_24308);
    _24308 = NOVALUE;

    /** 		emit_op( EXIT_BLOCK )*/
    _37emit_op(206);
L1: 

    /** end procedure*/
    DeRef(_24304);
    _24304 = NOVALUE;
    _24306 = NOVALUE;
    return;
    ;
}


void _65Leave_blocks(int _blocks_45992, int _block_type_45993)
{
    int _bx_45994 = NOVALUE;
    int _Block_opcode_3__tmp_at29_46001 = NOVALUE;
    int _Block_opcode_2__tmp_at29_46000 = NOVALUE;
    int _Block_opcode_1__tmp_at29_45999 = NOVALUE;
    int _Block_opcode_inlined_Block_opcode_at_29_45998 = NOVALUE;
    int _24321 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_blocks_45992)) {
        _1 = (long)(DBL_PTR(_blocks_45992)->dbl);
        DeRefDS(_blocks_45992);
        _blocks_45992 = _1;
    }
    if (!IS_ATOM_INT(_block_type_45993)) {
        _1 = (long)(DBL_PTR(_block_type_45993)->dbl);
        DeRefDS(_block_type_45993);
        _block_type_45993 = _1;
    }

    /** 	integer bx = 0*/
    _bx_45994 = 0;

    /** 	while blocks do*/
L1: 
    if (_blocks_45992 == 0)
    {
        goto L2; // [15] 119
    }
    else{
    }

    /** 		Leave_block( bx )*/
    _65Leave_block(_bx_45994);

    /** 		if block_type then*/
    if (_block_type_45993 == 0)
    {
        goto L3; // [25] 101
    }
    else{
    }

    /** 			switch Block_opcode( bx ) do*/

    /** 	return block_stack[$-bx][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _Block_opcode_1__tmp_at29_45999 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _Block_opcode_1__tmp_at29_45999 = 1;
    }
    _Block_opcode_2__tmp_at29_46000 = _Block_opcode_1__tmp_at29_45999 - _bx_45994;
    DeRef(_Block_opcode_3__tmp_at29_46001);
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    _Block_opcode_3__tmp_at29_46001 = (int)*(((s1_ptr)_2)->base + _Block_opcode_2__tmp_at29_46000);
    Ref(_Block_opcode_3__tmp_at29_46001);
    DeRef(_Block_opcode_inlined_Block_opcode_at_29_45998);
    _2 = (int)SEQ_PTR(_Block_opcode_3__tmp_at29_46001);
    _Block_opcode_inlined_Block_opcode_at_29_45998 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_Block_opcode_inlined_Block_opcode_at_29_45998);
    DeRef(_Block_opcode_3__tmp_at29_46001);
    _Block_opcode_3__tmp_at29_46001 = NOVALUE;
    if (IS_SEQUENCE(_Block_opcode_inlined_Block_opcode_at_29_45998) ){
        goto L4; // [52] 82
    }
    if(!IS_ATOM_INT(_Block_opcode_inlined_Block_opcode_at_29_45998)){
        if( (DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_45998)->dbl != (double) ((int) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_45998)->dbl) ) ){
            goto L4; // [52] 82
        }
        _0 = (int) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_45998)->dbl;
    }
    else {
        _0 = _Block_opcode_inlined_Block_opcode_at_29_45998;
    };
    switch ( _0 ){ 

        /** 				case FOR, WHILE, LOOP then*/
        case 21:
        case 47:
        case 422:

        /** 					if block_type = LOOP_BLOCK then*/
        if (_block_type_45993 != 1)
        goto L5; // [67] 108

        /** 						blocks -= 1*/
        _blocks_45992 = _blocks_45992 - 1;
        goto L5; // [78] 108

        /** 				case else*/
        default:
L4: 

        /** 					if block_type = CONDITIONAL_BLOCK then*/
        if (_block_type_45993 != 2)
        goto L6; // [86] 97

        /** 						blocks -= 1*/
        _blocks_45992 = _blocks_45992 - 1;
L6: 
    ;}    goto L5; // [98] 108
L3: 

    /** 			blocks -= 1*/
    _blocks_45992 = _blocks_45992 - 1;
L5: 

    /** 		bx += 1*/
    _bx_45994 = _bx_45994 + 1;

    /** 	end while*/
    goto L1; // [116] 15
L2: 

    /** 	for i = 0 to blocks - 1 do*/
    _24321 = _blocks_45992 - 1;
    if ((long)((unsigned long)_24321 +(unsigned long) HIGH_BITS) >= 0){
        _24321 = NewDouble((double)_24321);
    }
    {
        int _i_46019;
        _i_46019 = 0;
L7: 
        if (binary_op_a(GREATER, _i_46019, _24321)){
            goto L8; // [125] 144
        }

        /** 		Leave_block( i )*/
        Ref(_i_46019);
        _65Leave_block(_i_46019);

        /** 	end for*/
        _0 = _i_46019;
        if (IS_ATOM_INT(_i_46019)) {
            _i_46019 = _i_46019 + 1;
            if ((long)((unsigned long)_i_46019 +(unsigned long) HIGH_BITS) >= 0){
                _i_46019 = NewDouble((double)_i_46019);
            }
        }
        else {
            _i_46019 = binary_op_a(PLUS, _i_46019, 1);
        }
        DeRef(_0);
        goto L7; // [139] 132
L8: 
        ;
        DeRef(_i_46019);
    }

    /** end procedure*/
    DeRef(_24321);
    _24321 = NOVALUE;
    return;
    ;
}


void _65Drop_block(int _opcode_46023)
{
    int _x_46025 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_46023)) {
        _1 = (long)(DBL_PTR(_opcode_46023)->dbl);
        DeRefDS(_opcode_46023);
        _opcode_46023 = _1;
    }

    /** 	check_block( opcode )*/
    _65check_block(_opcode_46023);

    /** 	symtab_index x = pop_block()*/
    _x_46025 = _65pop_block();
    if (!IS_ATOM_INT(_x_46025)) {
        _1 = (long)(DBL_PTR(_x_46025)->dbl);
        DeRefDS(_x_46025);
        _x_46025 = _1;
    }

    /** end procedure*/
    return;
    ;
}


void _65Pop_block_var()
{
    int _sym_46030 = NOVALUE;
    int _block_sym_46037 = NOVALUE;
    int _24349 = NOVALUE;
    int _24348 = NOVALUE;
    int _24347 = NOVALUE;
    int _24346 = NOVALUE;
    int _24345 = NOVALUE;
    int _24344 = NOVALUE;
    int _24343 = NOVALUE;
    int _24342 = NOVALUE;
    int _24340 = NOVALUE;
    int _24339 = NOVALUE;
    int _24337 = NOVALUE;
    int _24336 = NOVALUE;
    int _24334 = NOVALUE;
    int _24331 = NOVALUE;
    int _24329 = NOVALUE;
    int _24328 = NOVALUE;
    int _24326 = NOVALUE;
    int _24325 = NOVALUE;
    int _24324 = NOVALUE;
    int _24323 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	symtab_index sym = block_stack[$][BLOCK_VARS][$]*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24323 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24323 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    _24324 = (int)*(((s1_ptr)_2)->base + _24323);
    _2 = (int)SEQ_PTR(_24324);
    _24325 = (int)*(((s1_ptr)_2)->base + 6);
    _24324 = NOVALUE;
    if (IS_SEQUENCE(_24325)){
            _24326 = SEQ_PTR(_24325)->length;
    }
    else {
        _24326 = 1;
    }
    _2 = (int)SEQ_PTR(_24325);
    _sym_46030 = (int)*(((s1_ptr)_2)->base + _24326);
    if (!IS_ATOM_INT(_sym_46030)){
        _sym_46030 = (long)DBL_PTR(_sym_46030)->dbl;
    }
    _24325 = NOVALUE;

    /** 	symtab_index block_sym = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24328 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24328 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    _24329 = (int)*(((s1_ptr)_2)->base + _24328);
    _2 = (int)SEQ_PTR(_24329);
    _block_sym_46037 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_block_sym_46037)){
        _block_sym_46037 = (long)DBL_PTR(_block_sym_46037)->dbl;
    }
    _24329 = NOVALUE;

    /** 	while sym_next_in_block( block_sym ) != sym do*/
L1: 
    _24331 = _52sym_next_in_block(_block_sym_46037);
    if (binary_op_a(EQUALS, _24331, _sym_46030)){
        DeRef(_24331);
        _24331 = NOVALUE;
        goto L2; // [51] 68
    }
    DeRef(_24331);
    _24331 = NOVALUE;

    /** 		block_sym = sym_next_in_block( block_sym )*/
    _block_sym_46037 = _52sym_next_in_block(_block_sym_46037);
    if (!IS_ATOM_INT(_block_sym_46037)) {
        _1 = (long)(DBL_PTR(_block_sym_46037)->dbl);
        DeRefDS(_block_sym_46037);
        _block_sym_46037 = _1;
    }

    /** 	end while*/
    goto L1; // [65] 47
L2: 

    /** 	SymTab[block_sym][S_NEXT_IN_BLOCK] = sym_next_in_block( sym )*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_block_sym_46037 + ((s1_ptr)_2)->base);
    _24336 = _52sym_next_in_block(_sym_46030);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_NEXT_IN_BLOCK_11646))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NEXT_IN_BLOCK_11646)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_NEXT_IN_BLOCK_11646);
    _1 = *(int *)_2;
    *(int *)_2 = _24336;
    if( _1 != _24336 ){
        DeRef(_1);
    }
    _24336 = NOVALUE;
    _24334 = NOVALUE;

    /** 	SymTab[sym][S_NEXT_IN_BLOCK] = 0*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_46030 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_26S_NEXT_IN_BLOCK_11646))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NEXT_IN_BLOCK_11646)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _26S_NEXT_IN_BLOCK_11646);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _24337 = NOVALUE;

    /** 	block_stack[$][BLOCK_VARS] = eu:remove( block_stack[$][BLOCK_VARS], */
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24339 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24339 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65block_stack_45696 = MAKE_SEQ(_2);
    }
    _3 = (int)(_24339 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24342 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24342 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    _24343 = (int)*(((s1_ptr)_2)->base + _24342);
    _2 = (int)SEQ_PTR(_24343);
    _24344 = (int)*(((s1_ptr)_2)->base + 6);
    _24343 = NOVALUE;
    if (IS_SEQUENCE(_65block_stack_45696)){
            _24345 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _24345 = 1;
    }
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    _24346 = (int)*(((s1_ptr)_2)->base + _24345);
    _2 = (int)SEQ_PTR(_24346);
    _24347 = (int)*(((s1_ptr)_2)->base + 6);
    _24346 = NOVALUE;
    if (IS_SEQUENCE(_24347)){
            _24348 = SEQ_PTR(_24347)->length;
    }
    else {
        _24348 = 1;
    }
    _24347 = NOVALUE;
    {
        s1_ptr assign_space = SEQ_PTR(_24344);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_24348)) ? _24348 : (long)(DBL_PTR(_24348)->dbl);
        int stop = (IS_ATOM_INT(_24348)) ? _24348 : (long)(DBL_PTR(_24348)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
            RefDS(_24344);
            DeRef(_24349);
            _24349 = _24344;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_24344), start, &_24349 );
            }
            else Tail(SEQ_PTR(_24344), stop+1, &_24349);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_24344), start, &_24349);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_24349);
            _24349 = _1;
        }
    }
    _24344 = NOVALUE;
    _24348 = NOVALUE;
    _24348 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _24349;
    if( _1 != _24349 ){
        DeRef(_1);
    }
    _24349 = NOVALUE;
    _24340 = NOVALUE;

    /** end procedure*/
    _24347 = NOVALUE;
    return;
    ;
}


void _65Goto_block(int _from_block_46071, int _to_block_46073, int _pc_46074)
{
    int _code_46075 = NOVALUE;
    int _next_block_46077 = NOVALUE;
    int _24360 = NOVALUE;
    int _24357 = NOVALUE;
    int _24356 = NOVALUE;
    int _24355 = NOVALUE;
    int _24354 = NOVALUE;
    int _24353 = NOVALUE;
    int _24352 = NOVALUE;
    int _24351 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_block_46071)) {
        _1 = (long)(DBL_PTR(_from_block_46071)->dbl);
        DeRefDS(_from_block_46071);
        _from_block_46071 = _1;
    }
    if (!IS_ATOM_INT(_to_block_46073)) {
        _1 = (long)(DBL_PTR(_to_block_46073)->dbl);
        DeRefDS(_to_block_46073);
        _to_block_46073 = _1;
    }
    if (!IS_ATOM_INT(_pc_46074)) {
        _1 = (long)(DBL_PTR(_pc_46074)->dbl);
        DeRefDS(_pc_46074);
        _pc_46074 = _1;
    }

    /** 	sequence code = {}*/
    RefDS(_22037);
    DeRefi(_code_46075);
    _code_46075 = _22037;

    /** 	symtab_index next_block = sym_block( from_block )*/
    _next_block_46077 = _52sym_block(_from_block_46071);
    if (!IS_ATOM_INT(_next_block_46077)) {
        _1 = (long)(DBL_PTR(_next_block_46077)->dbl);
        DeRefDS(_next_block_46077);
        _next_block_46077 = _1;
    }

    /** 	while next_block */
L1: 
    if (_next_block_46077 == 0) {
        _24351 = 0;
        goto L2; // [27] 39
    }
    _24352 = (_from_block_46071 != _to_block_46073);
    _24351 = (_24352 != 0);
L2: 
    if (_24351 == 0) {
        goto L3; // [39] 93
    }
    _24354 = _52sym_token(_next_block_46077);
    _24355 = find_from(_24354, _28RTN_TOKS_11602, 1);
    DeRef(_24354);
    _24354 = NOVALUE;
    _24356 = (_24355 == 0);
    _24355 = NOVALUE;
    if (_24356 == 0)
    {
        DeRef(_24356);
        _24356 = NOVALUE;
        goto L3; // [58] 93
    }
    else{
        DeRef(_24356);
        _24356 = NOVALUE;
    }

    /** 		code &= { EXIT_BLOCK, from_block }*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 206;
    ((int *)_2)[2] = _from_block_46071;
    _24357 = MAKE_SEQ(_1);
    Concat((object_ptr)&_code_46075, _code_46075, _24357);
    DeRefDS(_24357);
    _24357 = NOVALUE;

    /** 		from_block = next_block*/
    _from_block_46071 = _next_block_46077;

    /** 		next_block = sym_block( next_block )*/
    _next_block_46077 = _52sym_block(_next_block_46077);
    if (!IS_ATOM_INT(_next_block_46077)) {
        _1 = (long)(DBL_PTR(_next_block_46077)->dbl);
        DeRefDS(_next_block_46077);
        _next_block_46077 = _1;
    }

    /** 	end while*/
    goto L1; // [90] 27
L3: 

    /** 	if length(code) then*/
    if (IS_SEQUENCE(_code_46075)){
            _24360 = SEQ_PTR(_code_46075)->length;
    }
    else {
        _24360 = 1;
    }
    if (_24360 == 0)
    {
        _24360 = NOVALUE;
        goto L4; // [98] 127
    }
    else{
        _24360 = NOVALUE;
    }

    /** 		if pc then*/
    if (_pc_46074 == 0)
    {
        goto L5; // [103] 115
    }
    else{
    }

    /** 			insert_code( code, pc )*/
    RefDS(_code_46075);
    _64insert_code(_code_46075, _pc_46074);
    goto L6; // [112] 126
L5: 

    /** 			Code &= code*/
    Concat((object_ptr)&_26Code_12071, _26Code_12071, _code_46075);
L6: 
L4: 

    /** end procedure*/
    DeRefi(_code_46075);
    DeRef(_24352);
    _24352 = NOVALUE;
    return;
    ;
}


void _65blocks_info()
{
    int _0, _1, _2;
    

    /** 	? block_stack*/
    StdPrint(1, _65block_stack_45696, 1);

    /** end procedure*/
    return;
    ;
}


int _65Least_block()
{
    int _ix_46105 = NOVALUE;
    int _sub_block_46108 = NOVALUE;
    int _24374 = NOVALUE;
    int _24373 = NOVALUE;
    int _24371 = NOVALUE;
    int _24370 = NOVALUE;
    int _24369 = NOVALUE;
    int _24368 = NOVALUE;
    int _24367 = NOVALUE;
    int _24366 = NOVALUE;
    int _24365 = NOVALUE;
    int _24364 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer ix = length( block_stack )*/
    if (IS_SEQUENCE(_65block_stack_45696)){
            _ix_46105 = SEQ_PTR(_65block_stack_45696)->length;
    }
    else {
        _ix_46105 = 1;
    }

    /** 	symtab_index sub_block = sym_block( CurrentSub )*/
    _sub_block_46108 = _52sym_block(_26CurrentSub_11990);
    if (!IS_ATOM_INT(_sub_block_46108)) {
        _1 = (long)(DBL_PTR(_sub_block_46108)->dbl);
        DeRefDS(_sub_block_46108);
        _sub_block_46108 = _1;
    }

    /** 	while not length( block_stack[ix][BLOCK_VARS] ) */
L1: 
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    _24364 = (int)*(((s1_ptr)_2)->base + _ix_46105);
    _2 = (int)SEQ_PTR(_24364);
    _24365 = (int)*(((s1_ptr)_2)->base + 6);
    _24364 = NOVALUE;
    if (IS_SEQUENCE(_24365)){
            _24366 = SEQ_PTR(_24365)->length;
    }
    else {
        _24366 = 1;
    }
    _24365 = NOVALUE;
    _24367 = (_24366 == 0);
    _24366 = NOVALUE;
    if (_24367 == 0) {
        goto L2; // [39] 72
    }
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    _24369 = (int)*(((s1_ptr)_2)->base + _ix_46105);
    _2 = (int)SEQ_PTR(_24369);
    _24370 = (int)*(((s1_ptr)_2)->base + 1);
    _24369 = NOVALUE;
    if (IS_ATOM_INT(_24370)) {
        _24371 = (_24370 != _sub_block_46108);
    }
    else {
        _24371 = binary_op(NOTEQ, _24370, _sub_block_46108);
    }
    _24370 = NOVALUE;
    if (_24371 <= 0) {
        if (_24371 == 0) {
            DeRef(_24371);
            _24371 = NOVALUE;
            goto L2; // [58] 72
        }
        else {
            if (!IS_ATOM_INT(_24371) && DBL_PTR(_24371)->dbl == 0.0){
                DeRef(_24371);
                _24371 = NOVALUE;
                goto L2; // [58] 72
            }
            DeRef(_24371);
            _24371 = NOVALUE;
        }
    }
    DeRef(_24371);
    _24371 = NOVALUE;

    /** 		ix -= 1	*/
    _ix_46105 = _ix_46105 - 1;

    /** 	end while*/
    goto L1; // [69] 23
L2: 

    /** 	return block_stack[ix][BLOCK_SYM]*/
    _2 = (int)SEQ_PTR(_65block_stack_45696);
    _24373 = (int)*(((s1_ptr)_2)->base + _ix_46105);
    _2 = (int)SEQ_PTR(_24373);
    _24374 = (int)*(((s1_ptr)_2)->base + 1);
    _24373 = NOVALUE;
    Ref(_24374);
    _24365 = NOVALUE;
    DeRef(_24367);
    _24367 = NOVALUE;
    return _24374;
    ;
}



// 0x00027128
