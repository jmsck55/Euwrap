// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _27open_locked(int _file_path_10953)
{
    int _fh_10954 = NOVALUE;
    int _0, _1, _2;
    

    /** 	fh = open(file_path, "u")*/
    _fh_10954 = EOpen(_file_path_10953, _6102, 0);

    /** 	if fh = -1 then*/
    if (_fh_10954 != -1)
    goto L1; // [12] 24

    /** 		fh = open(file_path, "r")*/
    _fh_10954 = EOpen(_file_path_10953, _1289, 0);
L1: 

    /** 	return fh*/
    DeRefDS(_file_path_10953);
    return _fh_10954;
    ;
}


int _27get_eudir()
{
    int _possible_paths_10971 = NOVALUE;
    int _homepath_10976 = NOVALUE;
    int _homedrive_10978 = NOVALUE;
    int _possible_path_11001 = NOVALUE;
    int _possible_path_11015 = NOVALUE;
    int _file_check_11029 = NOVALUE;
    int _6153 = NOVALUE;
    int _6152 = NOVALUE;
    int _6151 = NOVALUE;
    int _6149 = NOVALUE;
    int _6147 = NOVALUE;
    int _6145 = NOVALUE;
    int _6144 = NOVALUE;
    int _6143 = NOVALUE;
    int _6142 = NOVALUE;
    int _6141 = NOVALUE;
    int _6139 = NOVALUE;
    int _6137 = NOVALUE;
    int _6136 = NOVALUE;
    int _6132 = NOVALUE;
    int _6130 = NOVALUE;
    int _6127 = NOVALUE;
    int _6126 = NOVALUE;
    int _6125 = NOVALUE;
    int _6124 = NOVALUE;
    int _6123 = NOVALUE;
    int _6122 = NOVALUE;
    int _6121 = NOVALUE;
    int _6120 = NOVALUE;
    int _6119 = NOVALUE;
    int _6108 = NOVALUE;
    int _6106 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(eudir) then*/
    _6106 = IS_SEQUENCE(_27eudir_10949);
    if (_6106 == 0)
    {
        _6106 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _6106 = NOVALUE;
    }

    /** 		return eudir*/
    Ref(_27eudir_10949);
    DeRef(_possible_paths_10971);
    DeRefi(_homepath_10976);
    DeRefi(_homedrive_10978);
    return _27eudir_10949;
L1: 

    /** 	eudir = getenv("EUDIR")*/
    DeRef(_27eudir_10949);
    _27eudir_10949 = EGetEnv(_4444);

    /** 	if sequence(eudir) then*/
    _6108 = IS_SEQUENCE(_27eudir_10949);
    if (_6108 == 0)
    {
        _6108 = NOVALUE;
        goto L2; // [32] 44
    }
    else{
        _6108 = NOVALUE;
    }

    /** 		return eudir*/
    Ref(_27eudir_10949);
    DeRef(_possible_paths_10971);
    DeRefi(_homepath_10976);
    DeRefi(_homedrive_10978);
    return _27eudir_10949;
L2: 

    /** 	ifdef UNIX then*/

    /** 		sequence possible_paths = {*/
    _0 = _possible_paths_10971;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_6113);
    *((int *)(_2+4)) = _6113;
    RefDS(_6114);
    *((int *)(_2+8)) = _6114;
    RefDS(_6115);
    *((int *)(_2+12)) = _6115;
    _possible_paths_10971 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 		object homepath = getenv("HOMEPATH")*/
    DeRefi(_homepath_10976);
    _homepath_10976 = EGetEnv(_4078);

    /** 		object homedrive = getenv("HOMEDRIVE")*/
    DeRefi(_homedrive_10978);
    _homedrive_10978 = EGetEnv(_4076);

    /** 		if sequence(homepath) and sequence(homedrive) then*/
    _6119 = IS_SEQUENCE(_homepath_10976);
    if (_6119 == 0) {
        goto L3; // [69] 134
    }
    _6121 = IS_SEQUENCE(_homedrive_10978);
    if (_6121 == 0)
    {
        _6121 = NOVALUE;
        goto L3; // [77] 134
    }
    else{
        _6121 = NOVALUE;
    }

    /** 			if length(homepath) and not equal(homepath[$], SLASH) then*/
    if (IS_SEQUENCE(_homepath_10976)){
            _6122 = SEQ_PTR(_homepath_10976)->length;
    }
    else {
        _6122 = 1;
    }
    if (_6122 == 0) {
        goto L4; // [85] 118
    }
    if (IS_SEQUENCE(_homepath_10976)){
            _6124 = SEQ_PTR(_homepath_10976)->length;
    }
    else {
        _6124 = 1;
    }
    _2 = (int)SEQ_PTR(_homepath_10976);
    _6125 = (int)*(((s1_ptr)_2)->base + _6124);
    if (_6125 == 92)
    _6126 = 1;
    else if (IS_ATOM_INT(_6125) && IS_ATOM_INT(92))
    _6126 = 0;
    else
    _6126 = (compare(_6125, 92) == 0);
    _6125 = NOVALUE;
    _6127 = (_6126 == 0);
    _6126 = NOVALUE;
    if (_6127 == 0)
    {
        DeRef(_6127);
        _6127 = NOVALUE;
        goto L4; // [106] 118
    }
    else{
        DeRef(_6127);
        _6127 = NOVALUE;
    }

    /** 				homepath &= SLASH*/
    if (IS_SEQUENCE(_homepath_10976) && IS_ATOM(92)) {
        Append(&_homepath_10976, _homepath_10976, 92);
    }
    else if (IS_ATOM(_homepath_10976) && IS_SEQUENCE(92)) {
    }
    else {
        Concat((object_ptr)&_homepath_10976, _homepath_10976, 92);
    }
L4: 

    /** 			possible_paths = append(possible_paths, homedrive & SLASH & homepath & "euphoria")*/
    {
        int concat_list[4];

        concat_list[0] = _6129;
        concat_list[1] = _homepath_10976;
        concat_list[2] = 92;
        concat_list[3] = _homedrive_10978;
        Concat_N((object_ptr)&_6130, concat_list, 4);
    }
    RefDS(_6130);
    Append(&_possible_paths_10971, _possible_paths_10971, _6130);
    DeRefDS(_6130);
    _6130 = NOVALUE;
L3: 

    /** 	for i = 1 to length(possible_paths) do*/
    if (IS_SEQUENCE(_possible_paths_10971)){
            _6132 = SEQ_PTR(_possible_paths_10971)->length;
    }
    else {
        _6132 = 1;
    }
    {
        int _i_10999;
        _i_10999 = 1;
L5: 
        if (_i_10999 > _6132){
            goto L6; // [141] 200
        }

        /** 		sequence possible_path = possible_paths[i]*/
        DeRef(_possible_path_11001);
        _2 = (int)SEQ_PTR(_possible_paths_10971);
        _possible_path_11001 = (int)*(((s1_ptr)_2)->base + _i_10999);
        RefDS(_possible_path_11001);

        /** 		if file_exists(possible_path & SLASH & "include" & SLASH & "euphoria.h") then*/
        {
            int concat_list[5];

            concat_list[0] = _6135;
            concat_list[1] = 92;
            concat_list[2] = _6134;
            concat_list[3] = 92;
            concat_list[4] = _possible_path_11001;
            Concat_N((object_ptr)&_6136, concat_list, 5);
        }
        _6137 = _15file_exists(_6136);
        _6136 = NOVALUE;
        if (_6137 == 0) {
            DeRef(_6137);
            _6137 = NOVALUE;
            goto L7; // [174] 191
        }
        else {
            if (!IS_ATOM_INT(_6137) && DBL_PTR(_6137)->dbl == 0.0){
                DeRef(_6137);
                _6137 = NOVALUE;
                goto L7; // [174] 191
            }
            DeRef(_6137);
            _6137 = NOVALUE;
        }
        DeRef(_6137);
        _6137 = NOVALUE;

        /** 			eudir = possible_path*/
        RefDS(_possible_path_11001);
        DeRef(_27eudir_10949);
        _27eudir_10949 = _possible_path_11001;

        /** 			return eudir*/
        RefDS(_27eudir_10949);
        DeRefDS(_possible_path_11001);
        DeRefDS(_possible_paths_10971);
        DeRefi(_homepath_10976);
        DeRefi(_homedrive_10978);
        return _27eudir_10949;
L7: 
        DeRef(_possible_path_11001);
        _possible_path_11001 = NOVALUE;

        /** 	end for*/
        _i_10999 = _i_10999 + 1;
        goto L5; // [195] 148
L6: 
        ;
    }

    /** 	possible_paths = include_paths(0)*/
    _0 = _possible_paths_10971;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_4468);
    *((int *)(_2+4)) = _4468;
    RefDS(_4467);
    *((int *)(_2+8)) = _4467;
    RefDS(_4466);
    *((int *)(_2+12)) = _4466;
    _possible_paths_10971 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	for i = 1 to length(possible_paths) do*/
    _6139 = 3;
    {
        int _i_11013;
        _i_11013 = 1;
L8: 
        if (_i_11013 > 3){
            goto L9; // [213] 338
        }

        /** 		sequence possible_path = possible_paths[i]*/
        DeRef(_possible_path_11015);
        _2 = (int)SEQ_PTR(_possible_paths_10971);
        _possible_path_11015 = (int)*(((s1_ptr)_2)->base + _i_11013);
        RefDS(_possible_path_11015);

        /** 		if equal(possible_path[$], SLASH) then*/
        if (IS_SEQUENCE(_possible_path_11015)){
                _6141 = SEQ_PTR(_possible_path_11015)->length;
        }
        else {
            _6141 = 1;
        }
        _2 = (int)SEQ_PTR(_possible_path_11015);
        _6142 = (int)*(((s1_ptr)_2)->base + _6141);
        if (_6142 == 92)
        _6143 = 1;
        else if (IS_ATOM_INT(_6142) && IS_ATOM_INT(92))
        _6143 = 0;
        else
        _6143 = (compare(_6142, 92) == 0);
        _6142 = NOVALUE;
        if (_6143 == 0)
        {
            _6143 = NOVALUE;
            goto LA; // [243] 261
        }
        else{
            _6143 = NOVALUE;
        }

        /** 			possible_path = possible_path[1..$-1]*/
        if (IS_SEQUENCE(_possible_path_11015)){
                _6144 = SEQ_PTR(_possible_path_11015)->length;
        }
        else {
            _6144 = 1;
        }
        _6145 = _6144 - 1;
        _6144 = NOVALUE;
        rhs_slice_target = (object_ptr)&_possible_path_11015;
        RHS_Slice(_possible_path_11015, 1, _6145);
LA: 

        /** 		if not ends("include", possible_path) then*/
        RefDS(_6134);
        RefDS(_possible_path_11015);
        _6147 = _14ends(_6134, _possible_path_11015);
        if (IS_ATOM_INT(_6147)) {
            if (_6147 != 0){
                DeRef(_6147);
                _6147 = NOVALUE;
                goto LB; // [268] 278
            }
        }
        else {
            if (DBL_PTR(_6147)->dbl != 0.0){
                DeRef(_6147);
                _6147 = NOVALUE;
                goto LB; // [268] 278
            }
        }
        DeRef(_6147);
        _6147 = NOVALUE;

        /** 			continue*/
        DeRefDS(_possible_path_11015);
        _possible_path_11015 = NOVALUE;
        DeRef(_file_check_11029);
        _file_check_11029 = NOVALUE;
        goto LC; // [275] 333
LB: 

        /** 		sequence file_check = possible_path*/
        RefDS(_possible_path_11015);
        DeRef(_file_check_11029);
        _file_check_11029 = _possible_path_11015;

        /** 		file_check &= SLASH & "euphoria.h"*/
        Prepend(&_6149, _6135, 92);
        Concat((object_ptr)&_file_check_11029, _file_check_11029, _6149);
        DeRefDS(_6149);
        _6149 = NOVALUE;

        /** 		if file_exists(file_check) then*/
        RefDS(_file_check_11029);
        _6151 = _15file_exists(_file_check_11029);
        if (_6151 == 0) {
            DeRef(_6151);
            _6151 = NOVALUE;
            goto LD; // [303] 329
        }
        else {
            if (!IS_ATOM_INT(_6151) && DBL_PTR(_6151)->dbl == 0.0){
                DeRef(_6151);
                _6151 = NOVALUE;
                goto LD; // [303] 329
            }
            DeRef(_6151);
            _6151 = NOVALUE;
        }
        DeRef(_6151);
        _6151 = NOVALUE;

        /** 			eudir = possible_path[1..$-8] -- strip SLASH & "include"*/
        if (IS_SEQUENCE(_possible_path_11015)){
                _6152 = SEQ_PTR(_possible_path_11015)->length;
        }
        else {
            _6152 = 1;
        }
        _6153 = _6152 - 8;
        _6152 = NOVALUE;
        rhs_slice_target = (object_ptr)&_27eudir_10949;
        RHS_Slice(_possible_path_11015, 1, _6153);

        /** 			return eudir*/
        RefDS(_27eudir_10949);
        DeRefDS(_possible_path_11015);
        DeRefDS(_file_check_11029);
        DeRef(_possible_paths_10971);
        DeRefi(_homepath_10976);
        DeRefi(_homedrive_10978);
        DeRef(_6145);
        _6145 = NOVALUE;
        _6153 = NOVALUE;
        return _27eudir_10949;
LD: 
        DeRef(_possible_path_11015);
        _possible_path_11015 = NOVALUE;
        DeRef(_file_check_11029);
        _file_check_11029 = NOVALUE;

        /** 	end for*/
LC: 
        _i_11013 = _i_11013 + 1;
        goto L8; // [333] 220
L9: 
        ;
    }

    /** 	return ""*/
    RefDS(_5);
    DeRef(_possible_paths_10971);
    DeRefi(_homepath_10976);
    DeRefi(_homedrive_10978);
    DeRef(_6145);
    _6145 = NOVALUE;
    DeRef(_6153);
    _6153 = NOVALUE;
    return _5;
    ;
}


void _27set_eudir(int _new_eudir_11041)
{
    int _0, _1, _2;
    

    /** 	eudir = new_eudir*/
    RefDS(_new_eudir_11041);
    DeRef(_27eudir_10949);
    _27eudir_10949 = _new_eudir_11041;

    /** 	cmdline_eudir = 1*/
    _27cmdline_eudir_10950 = 1;

    /** end procedure*/
    DeRefDS(_new_eudir_11041);
    return;
    ;
}


int _27is_eudir_from_cmdline()
{
    int _0, _1, _2;
    

    /** 	return cmdline_eudir*/
    return _27cmdline_eudir_10950;
    ;
}



// 0x167B7B11
