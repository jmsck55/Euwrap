// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _7valid_memory_protection_constant(int _x_283)
{
    int _38 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return find( x, MEMORY_PROTECTION )*/
    _38 = find_from(_x_283, _7MEMORY_PROTECTION_279, 1);
    DeRef(_x_283);
    return _38;
    ;
}


int _7test_read(int _protection_287)
{
    int _40 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return find( protection, { PAGE_EXECUTE_READ, PAGE_EXECUTE_READWRITE,  */
    _40 = find_from(_protection_287, _39, 1);
    DeRef(_protection_287);
    return _40;
    ;
}


int _7test_write(int _protection_292)
{
    int _42 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return find( protection, { PAGE_EXECUTE_READWRITE,*/
    _42 = find_from(_protection_292, _41, 1);
    DeRef(_protection_292);
    return _42;
    ;
}


int _7test_exec(int _protection_297)
{
    int _44 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return find(protection,{PAGE_EXECUTE,*/
    _44 = find_from(_protection_297, _43, 1);
    DeRef(_protection_297);
    return _44;
    ;
}


int _7valid_wordsize(int _i_302)
{
    int _46 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return find(i, {1,2,4})*/
    _46 = find_from(_i_302, _45, 1);
    DeRef(_i_302);
    return _46;
    ;
}



// 0xB4E050B4
