// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _43screen_output(int _f_48568, int _msg_48569)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_f_48568)) {
        _1 = (long)(DBL_PTR(_f_48568)->dbl);
        DeRefDS(_f_48568);
        _f_48568 = _1;
    }

    /** 	puts(f, msg)*/
    EPuts(_f_48568, _msg_48569); // DJP 

    /** end procedure*/
    DeRefDS(_msg_48569);
    return;
    ;
}


void _43Warning(int _msg_48572, int _mask_48573, int _args_48574)
{
    int _orig_mask_48575 = NOVALUE;
    int _text_48576 = NOVALUE;
    int _w_name_48577 = NOVALUE;
    int _25402 = NOVALUE;
    int _25400 = NOVALUE;
    int _25398 = NOVALUE;
    int _25395 = NOVALUE;
    int _25390 = NOVALUE;
    int _25388 = NOVALUE;
    int _25387 = NOVALUE;
    int _25386 = NOVALUE;
    int _25385 = NOVALUE;
    int _25383 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_mask_48573)) {
        _1 = (long)(DBL_PTR(_mask_48573)->dbl);
        DeRefDS(_mask_48573);
        _mask_48573 = _1;
    }

    /** 	if display_warnings = 0 then*/
    if (_43display_warnings_48556 != 0)
    goto L1; // [9] 19

    /** 		return*/
    DeRef(_msg_48572);
    DeRefDS(_args_48574);
    DeRef(_text_48576);
    DeRef(_w_name_48577);
    return;
L1: 

    /** 	if not Strict_is_on or Strict_Override then*/
    _25383 = (_26Strict_is_on_12048 == 0);
    if (_25383 != 0) {
        goto L2; // [26] 37
    }
    if (_26Strict_Override_12049 == 0)
    {
        goto L3; // [33] 56
    }
    else{
    }
L2: 

    /** 		if find(mask, strict_only_warnings) then*/
    _25385 = find_from(_mask_48573, _26strict_only_warnings_12046, 1);
    if (_25385 == 0)
    {
        _25385 = NOVALUE;
        goto L4; // [46] 55
    }
    else{
        _25385 = NOVALUE;
    }

    /** 			return*/
    DeRef(_msg_48572);
    DeRefDS(_args_48574);
    DeRef(_text_48576);
    DeRef(_w_name_48577);
    DeRef(_25383);
    _25383 = NOVALUE;
    return;
L4: 
L3: 

    /** 	orig_mask = mask -- =0 for non maskable warnings - none implemented so far*/
    _orig_mask_48575 = _mask_48573;

    /** 	if Strict_is_on and Strict_Override = 0 then*/
    if (_26Strict_is_on_12048 == 0) {
        goto L5; // [65] 85
    }
    _25387 = (_26Strict_Override_12049 == 0);
    if (_25387 == 0)
    {
        DeRef(_25387);
        _25387 = NOVALUE;
        goto L5; // [76] 85
    }
    else{
        DeRef(_25387);
        _25387 = NOVALUE;
    }

    /** 		mask = 0*/
    _mask_48573 = 0;
L5: 

    /** 	if mask = 0 or and_bits(OpWarning, mask) then*/
    _25388 = (_mask_48573 == 0);
    if (_25388 != 0) {
        goto L6; // [91] 106
    }
    {unsigned long tu;
         tu = (unsigned long)_26OpWarning_12050 & (unsigned long)_mask_48573;
         _25390 = MAKE_UINT(tu);
    }
    if (_25390 == 0) {
        DeRef(_25390);
        _25390 = NOVALUE;
        goto L7; // [102] 213
    }
    else {
        if (!IS_ATOM_INT(_25390) && DBL_PTR(_25390)->dbl == 0.0){
            DeRef(_25390);
            _25390 = NOVALUE;
            goto L7; // [102] 213
        }
        DeRef(_25390);
        _25390 = NOVALUE;
    }
    DeRef(_25390);
    _25390 = NOVALUE;
L6: 

    /** 		if orig_mask != 0 then*/
    if (_orig_mask_48575 == 0)
    goto L8; // [108] 122

    /** 			orig_mask = find(orig_mask,warning_flags)*/
    _orig_mask_48575 = find_from(_orig_mask_48575, _26warning_flags_12025, 1);
L8: 

    /** 		if orig_mask != 0 then*/
    if (_orig_mask_48575 == 0)
    goto L9; // [124] 145

    /** 			w_name = "{ " & warning_names[orig_mask] & " }"*/
    _2 = (int)SEQ_PTR(_26warning_names_12027);
    _25395 = (int)*(((s1_ptr)_2)->base + _orig_mask_48575);
    {
        int concat_list[3];

        concat_list[0] = _25396;
        concat_list[1] = _25395;
        concat_list[2] = _25394;
        Concat_N((object_ptr)&_w_name_48577, concat_list, 3);
    }
    _25395 = NOVALUE;
    goto LA; // [142] 153
L9: 

    /** 			w_name = "" -- not maskable*/
    RefDS(_22037);
    DeRef(_w_name_48577);
    _w_name_48577 = _22037;
LA: 

    /** 		if atom(msg) then*/
    _25398 = IS_ATOM(_msg_48572);
    if (_25398 == 0)
    {
        _25398 = NOVALUE;
        goto LB; // [158] 170
    }
    else{
        _25398 = NOVALUE;
    }

    /** 			msg = GetMsgText(msg, 1, args)*/
    Ref(_msg_48572);
    RefDS(_args_48574);
    _0 = _msg_48572;
    _msg_48572 = _44GetMsgText(_msg_48572, 1, _args_48574);
    DeRef(_0);
LB: 

    /** 		text = GetMsgText(204, 0, {w_name, msg})*/
    Ref(_msg_48572);
    RefDS(_w_name_48577);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _w_name_48577;
    ((int *)_2)[2] = _msg_48572;
    _25400 = MAKE_SEQ(_1);
    _0 = _text_48576;
    _text_48576 = _44GetMsgText(204, 0, _25400);
    DeRef(_0);
    _25400 = NOVALUE;

    /** 		if find(text, warning_list) then*/
    _25402 = find_from(_text_48576, _43warning_list_48565, 1);
    if (_25402 == 0)
    {
        _25402 = NOVALUE;
        goto LC; // [195] 204
    }
    else{
        _25402 = NOVALUE;
    }

    /** 			return -- duplicate*/
    DeRef(_msg_48572);
    DeRefDS(_args_48574);
    DeRefDS(_text_48576);
    DeRefDS(_w_name_48577);
    DeRef(_25383);
    _25383 = NOVALUE;
    DeRef(_25388);
    _25388 = NOVALUE;
    return;
LC: 

    /** 		warning_list = append(warning_list, text)*/
    RefDS(_text_48576);
    Append(&_43warning_list_48565, _43warning_list_48565, _text_48576);
L7: 

    /** end procedure*/
    DeRef(_msg_48572);
    DeRefDS(_args_48574);
    DeRef(_text_48576);
    DeRef(_w_name_48577);
    DeRef(_25383);
    _25383 = NOVALUE;
    DeRef(_25388);
    _25388 = NOVALUE;
    return;
    ;
}


void _43Log_warnings(int _policy_48622)
{
    int _25410 = NOVALUE;
    int _25409 = NOVALUE;
    int _25408 = NOVALUE;
    int _25407 = NOVALUE;
    int _25405 = NOVALUE;
    int _25404 = NOVALUE;
    int _0, _1, _2;
    

    /** 	display_warnings = 1*/
    _43display_warnings_48556 = 1;

    /** 	if sequence(policy) then*/
    _25404 = IS_SEQUENCE(_policy_48622);
    if (_25404 == 0)
    {
        _25404 = NOVALUE;
        goto L1; // [11] 34
    }
    else{
        _25404 = NOVALUE;
    }

    /** 		if length(policy)=0 then*/
    if (IS_SEQUENCE(_policy_48622)){
            _25405 = SEQ_PTR(_policy_48622)->length;
    }
    else {
        _25405 = 1;
    }
    if (_25405 != 0)
    goto L2; // [19] 82

    /** 			policy = STDERR*/
    DeRef(_policy_48622);
    _policy_48622 = 2;
    goto L2; // [31] 82
L1: 

    /** 		if policy >= 0 and policy < STDERR+1 then*/
    if (IS_ATOM_INT(_policy_48622)) {
        _25407 = (_policy_48622 >= 0);
    }
    else {
        _25407 = binary_op(GREATEREQ, _policy_48622, 0);
    }
    if (IS_ATOM_INT(_25407)) {
        if (_25407 == 0) {
            goto L3; // [40] 68
        }
    }
    else {
        if (DBL_PTR(_25407)->dbl == 0.0) {
            goto L3; // [40] 68
        }
    }
    _25409 = 3;
    if (IS_ATOM_INT(_policy_48622)) {
        _25410 = (_policy_48622 < 3);
    }
    else {
        _25410 = binary_op(LESS, _policy_48622, 3);
    }
    _25409 = NOVALUE;
    if (_25410 == 0) {
        DeRef(_25410);
        _25410 = NOVALUE;
        goto L3; // [55] 68
    }
    else {
        if (!IS_ATOM_INT(_25410) && DBL_PTR(_25410)->dbl == 0.0){
            DeRef(_25410);
            _25410 = NOVALUE;
            goto L3; // [55] 68
        }
        DeRef(_25410);
        _25410 = NOVALUE;
    }
    DeRef(_25410);
    _25410 = NOVALUE;

    /** 			policy  = STDERR*/
    DeRef(_policy_48622);
    _policy_48622 = 2;
    goto L4; // [65] 81
L3: 

    /** 		elsif policy < 0 then*/
    if (binary_op_a(GREATEREQ, _policy_48622, 0)){
        goto L5; // [70] 80
    }

    /** 			display_warnings = 0*/
    _43display_warnings_48556 = 0;
L5: 
L4: 
L2: 

    /** end procedure*/
    DeRef(_policy_48622);
    DeRef(_25407);
    _25407 = NOVALUE;
    return;
    ;
}


int _43ShowWarnings()
{
    int _c_48641 = NOVALUE;
    int _errfile_48642 = NOVALUE;
    int _twf_48643 = NOVALUE;
    int _25441 = NOVALUE;
    int _25438 = NOVALUE;
    int _25437 = NOVALUE;
    int _25436 = NOVALUE;
    int _25435 = NOVALUE;
    int _25434 = NOVALUE;
    int _25433 = NOVALUE;
    int _25431 = NOVALUE;
    int _25430 = NOVALUE;
    int _25429 = NOVALUE;
    int _25427 = NOVALUE;
    int _25426 = NOVALUE;
    int _25425 = NOVALUE;
    int _25424 = NOVALUE;
    int _25422 = NOVALUE;
    int _25418 = NOVALUE;
    int _25416 = NOVALUE;
    int _25415 = NOVALUE;
    int _25414 = NOVALUE;
    int _25412 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if display_warnings = 0 or length(warning_list) = 0 then*/
    _25412 = (_43display_warnings_48556 == 0);
    if (_25412 != 0) {
        goto L1; // [9] 27
    }
    if (IS_SEQUENCE(_43warning_list_48565)){
            _25414 = SEQ_PTR(_43warning_list_48565)->length;
    }
    else {
        _25414 = 1;
    }
    _25415 = (_25414 == 0);
    _25414 = NOVALUE;
    if (_25415 == 0)
    {
        DeRef(_25415);
        _25415 = NOVALUE;
        goto L2; // [23] 39
    }
    else{
        DeRef(_25415);
        _25415 = NOVALUE;
    }
L1: 

    /** 		return length(warning_list)*/
    if (IS_SEQUENCE(_43warning_list_48565)){
            _25416 = SEQ_PTR(_43warning_list_48565)->length;
    }
    else {
        _25416 = 1;
    }
    DeRef(_25412);
    _25412 = NOVALUE;
    return _25416;
L2: 

    /** 	if TempErrFile > 0 then*/
    if (_43TempErrFile_48554 <= 0)
    goto L3; // [43] 57

    /** 		errfile = TempErrFile*/
    _errfile_48642 = _43TempErrFile_48554;
    goto L4; // [54] 67
L3: 

    /** 		errfile = STDERR*/
    _errfile_48642 = 2;
L4: 

    /** 	if not integer(TempWarningName) then*/
    if (IS_ATOM_INT(_26TempWarningName_11996))
    _25418 = 1;
    else if (IS_ATOM_DBL(_26TempWarningName_11996))
    _25418 = IS_ATOM_INT(DoubleToInt(_26TempWarningName_11996));
    else
    _25418 = 0;
    if (_25418 != 0)
    goto L5; // [74] 179
    _25418 = NOVALUE;

    /** 		twf = open(TempWarningName,"w")*/
    _twf_48643 = EOpen(_26TempWarningName_11996, _22143, 0);

    /** 		if twf = -1 then*/
    if (_twf_48643 != -1)
    goto L6; // [88] 136

    /** 			ShowMsg(errfile, 205, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_26TempWarningName_11996);
    *((int *)(_2+4)) = _26TempWarningName_11996;
    _25422 = MAKE_SEQ(_1);
    _44ShowMsg(_errfile_48642, 205, _25422, 1);
    _25422 = NOVALUE;

    /** 			if errfile != STDERR then*/
    if (_errfile_48642 == 2)
    goto L7; // [112] 173

    /** 				ShowMsg(STDERR, 205, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_26TempWarningName_11996);
    *((int *)(_2+4)) = _26TempWarningName_11996;
    _25424 = MAKE_SEQ(_1);
    _44ShowMsg(2, 205, _25424, 1);
    _25424 = NOVALUE;
    goto L7; // [133] 173
L6: 

    /** 			for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_43warning_list_48565)){
            _25425 = SEQ_PTR(_43warning_list_48565)->length;
    }
    else {
        _25425 = 1;
    }
    {
        int _i_48674;
        _i_48674 = 1;
L8: 
        if (_i_48674 > _25425){
            goto L9; // [143] 168
        }

        /** 				puts(twf, warning_list[i])*/
        _2 = (int)SEQ_PTR(_43warning_list_48565);
        _25426 = (int)*(((s1_ptr)_2)->base + _i_48674);
        EPuts(_twf_48643, _25426); // DJP 
        _25426 = NOVALUE;

        /** 			end for*/
        _i_48674 = _i_48674 + 1;
        goto L8; // [163] 150
L9: 
        ;
    }

    /** 		    close(twf)*/
    EClose(_twf_48643);
L7: 

    /** 		TempWarningName = 99 -- Flag that we have done this already.*/
    DeRef(_26TempWarningName_11996);
    _26TempWarningName_11996 = 99;
L5: 

    /** 	if batch_job = 0 or errfile != STDERR then*/
    _25427 = (_26batch_job_11995 == 0);
    if (_25427 != 0) {
        goto LA; // [187] 204
    }
    _25429 = (_errfile_48642 != 2);
    if (_25429 == 0)
    {
        DeRef(_25429);
        _25429 = NOVALUE;
        goto LB; // [200] 311
    }
    else{
        DeRef(_25429);
        _25429 = NOVALUE;
    }
LA: 

    /** 		for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_43warning_list_48565)){
            _25430 = SEQ_PTR(_43warning_list_48565)->length;
    }
    else {
        _25430 = 1;
    }
    {
        int _i_48685;
        _i_48685 = 1;
LC: 
        if (_i_48685 > _25430){
            goto LD; // [211] 310
        }

        /** 			puts(errfile, warning_list[i])*/
        _2 = (int)SEQ_PTR(_43warning_list_48565);
        _25431 = (int)*(((s1_ptr)_2)->base + _i_48685);
        EPuts(_errfile_48642, _25431); // DJP 
        _25431 = NOVALUE;

        /** 			if errfile = STDERR then*/
        if (_errfile_48642 != 2)
        goto LE; // [235] 303

        /** 				if remainder(i, 20) = 0 and batch_job = 0 and test_only = 0 then*/
        _25433 = (_i_48685 % 20);
        _25434 = (_25433 == 0);
        _25433 = NOVALUE;
        if (_25434 == 0) {
            _25435 = 0;
            goto LF; // [249] 263
        }
        _25436 = (_26batch_job_11995 == 0);
        _25435 = (_25436 != 0);
LF: 
        if (_25435 == 0) {
            goto L10; // [263] 302
        }
        _25438 = (_26test_only_11994 == 0);
        if (_25438 == 0)
        {
            DeRef(_25438);
            _25438 = NOVALUE;
            goto L10; // [274] 302
        }
        else{
            DeRef(_25438);
            _25438 = NOVALUE;
        }

        /** 					ShowMsg(errfile, 206)*/
        RefDS(_22037);
        _44ShowMsg(_errfile_48642, 206, _22037, 1);

        /** 					c = getc(0)*/
        if (0 != last_r_file_no) {
            last_r_file_ptr = which_file(0, EF_READ);
            last_r_file_no = 0;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _c_48641 = getKBchar();
            }
            else
            _c_48641 = getc(last_r_file_ptr);
        }
        else
        _c_48641 = getc(last_r_file_ptr);

        /** 					if c = 'q' then*/
        if (_c_48641 != 113)
        goto L11; // [292] 301

        /** 						exit*/
        goto LD; // [298] 310
L11: 
L10: 
LE: 

        /** 		end for*/
        _i_48685 = _i_48685 + 1;
        goto LC; // [305] 218
LD: 
        ;
    }
LB: 

    /** 	return length(warning_list)*/
    if (IS_SEQUENCE(_43warning_list_48565)){
            _25441 = SEQ_PTR(_43warning_list_48565)->length;
    }
    else {
        _25441 = 1;
    }
    DeRef(_25412);
    _25412 = NOVALUE;
    DeRef(_25427);
    _25427 = NOVALUE;
    DeRef(_25436);
    _25436 = NOVALUE;
    DeRef(_25434);
    _25434 = NOVALUE;
    return _25441;
    ;
}


void _43ShowDefines(int _errfile_48707)
{
    int _c_48708 = NOVALUE;
    int _25455 = NOVALUE;
    int _25454 = NOVALUE;
    int _25452 = NOVALUE;
    int _25451 = NOVALUE;
    int _25448 = NOVALUE;
    int _25447 = NOVALUE;
    int _25446 = NOVALUE;
    int _25445 = NOVALUE;
    int _25444 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_errfile_48707)) {
        _1 = (long)(DBL_PTR(_errfile_48707)->dbl);
        DeRefDS(_errfile_48707);
        _errfile_48707 = _1;
    }

    /** 	if errfile=0 then*/
    if (_errfile_48707 != 0)
    goto L1; // [5] 19

    /** 		errfile = STDERR*/
    _errfile_48707 = 2;
L1: 

    /** 	puts(errfile, format("\n--- [1] ---\n", {GetMsgText(207,0)}))*/
    RefDS(_22037);
    _25444 = _44GetMsgText(207, 0, _22037);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _25444;
    _25445 = MAKE_SEQ(_1);
    _25444 = NOVALUE;
    RefDS(_25443);
    _25446 = _12format(_25443, _25445);
    _25445 = NOVALUE;
    EPuts(_errfile_48707, _25446); // DJP 
    DeRef(_25446);
    _25446 = NOVALUE;

    /** 	for i = 1 to length(OpDefines) do*/
    if (IS_SEQUENCE(_26OpDefines_12056)){
            _25447 = SEQ_PTR(_26OpDefines_12056)->length;
    }
    else {
        _25447 = 1;
    }
    {
        int _i_48719;
        _i_48719 = 1;
L2: 
        if (_i_48719 > _25447){
            goto L3; // [46] 98
        }

        /** 		if find(OpDefines[i], {"_PLAT_START", "_PLAT_STOP"}) = 0 then*/
        _2 = (int)SEQ_PTR(_26OpDefines_12056);
        _25448 = (int)*(((s1_ptr)_2)->base + _i_48719);
        RefDS(_25450);
        RefDS(_25449);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _25449;
        ((int *)_2)[2] = _25450;
        _25451 = MAKE_SEQ(_1);
        _25452 = find_from(_25448, _25451, 1);
        _25448 = NOVALUE;
        DeRefDS(_25451);
        _25451 = NOVALUE;
        if (_25452 != 0)
        goto L4; // [70] 91

        /** 			printf(errfile, "%s\n", {OpDefines[i]})*/
        _2 = (int)SEQ_PTR(_26OpDefines_12056);
        _25454 = (int)*(((s1_ptr)_2)->base + _i_48719);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_25454);
        *((int *)(_2+4)) = _25454;
        _25455 = MAKE_SEQ(_1);
        _25454 = NOVALUE;
        EPrintf(_errfile_48707, _25324, _25455);
        DeRefDS(_25455);
        _25455 = NOVALUE;
L4: 

        /** 	end for*/
        _i_48719 = _i_48719 + 1;
        goto L2; // [93] 53
L3: 
        ;
    }

    /** 	puts(errfile, "-------------------\n")*/
    EPuts(_errfile_48707, _25456); // DJP 

    /** end procedure*/
    return;
    ;
}


void _43Cleanup(int _status_48736)
{
    int _w_48737 = NOVALUE;
    int _show_error_48738 = NOVALUE;
    int _31664 = NOVALUE;
    int _25470 = NOVALUE;
    int _25469 = NOVALUE;
    int _25468 = NOVALUE;
    int _25467 = NOVALUE;
    int _25466 = NOVALUE;
    int _25465 = NOVALUE;
    int _25464 = NOVALUE;
    int _25463 = NOVALUE;
    int _25462 = NOVALUE;
    int _25461 = NOVALUE;
    int _25457 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_status_48736)) {
        _1 = (long)(DBL_PTR(_status_48736)->dbl);
        DeRefDS(_status_48736);
        _status_48736 = _1;
    }

    /** 	integer w, show_error = 0*/
    _show_error_48738 = 0;

    /** 	ifdef EU_EX then*/

    /** 		write_coverage_db()*/
    _31664 = _49write_coverage_db();
    DeRef(_31664);
    _31664 = NOVALUE;

    /** 	show_error = 1*/
    _show_error_48738 = 1;

    /** 	if object(src_file) = 0 then*/
    if( NOVALUE == _26src_file_12104 ){
        _25457 = 0;
    }
    else{
        _25457 = 1;
    }
    if (_25457 != 0)
    goto L1; // [27] 41

    /** 		src_file = -1*/
    _26src_file_12104 = -1;
    goto L2; // [38] 64
L1: 

    /** 	elsif src_file >= 0 then*/
    if (_26src_file_12104 < 0)
    goto L3; // [45] 63

    /** 		close(src_file)*/
    EClose(_26src_file_12104);

    /** 		src_file = -1*/
    _26src_file_12104 = -1;
L3: 
L2: 

    /** 	w = ShowWarnings()*/
    _w_48737 = _43ShowWarnings();
    if (!IS_ATOM_INT(_w_48737)) {
        _1 = (long)(DBL_PTR(_w_48737)->dbl);
        DeRefDS(_w_48737);
        _w_48737 = _1;
    }

    /** 	if not TRANSLATE and (BIND or show_error) and (w or Errors) then*/
    _25461 = (_26TRANSLATE_11619 == 0);
    if (_25461 == 0) {
        _25462 = 0;
        goto L4; // [78] 96
    }
    if (_26BIND_11622 != 0) {
        _25463 = 1;
        goto L5; // [84] 92
    }
    _25463 = (_show_error_48738 != 0);
L5: 
    _25462 = (_25463 != 0);
L4: 
    if (_25462 == 0) {
        goto L6; // [96] 155
    }
    if (_w_48737 != 0) {
        DeRef(_25465);
        _25465 = 1;
        goto L7; // [100] 110
    }
    _25465 = (_43Errors_48553 != 0);
L7: 
    if (_25465 == 0)
    {
        _25465 = NOVALUE;
        goto L6; // [111] 155
    }
    else{
        _25465 = NOVALUE;
    }

    /** 		if not batch_job and not test_only then*/
    _25466 = (_26batch_job_11995 == 0);
    if (_25466 == 0) {
        goto L8; // [121] 154
    }
    _25468 = (_26test_only_11994 == 0);
    if (_25468 == 0)
    {
        DeRef(_25468);
        _25468 = NOVALUE;
        goto L8; // [131] 154
    }
    else{
        DeRef(_25468);
        _25468 = NOVALUE;
    }

    /** 			screen_output(STDERR, GetMsgText(208,0))*/
    RefDS(_22037);
    _25469 = _44GetMsgText(208, 0, _22037);
    _43screen_output(2, _25469);
    _25469 = NOVALUE;

    /** 			getc(0) -- wait*/
    if (0 != last_r_file_no) {
        last_r_file_ptr = which_file(0, EF_READ);
        last_r_file_no = 0;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _25470 = getKBchar();
        }
        else
        _25470 = getc(last_r_file_ptr);
    }
    else
    _25470 = getc(last_r_file_ptr);
L8: 
L6: 

    /** 	cleanup_open_includes()*/
    _60cleanup_open_includes();

    /** 	abort(status)*/
    UserCleanup(_status_48736);

    /** end procedure*/
    DeRef(_25461);
    _25461 = NOVALUE;
    DeRef(_25466);
    _25466 = NOVALUE;
    return;
    ;
}


void _43OpenErrFile()
{
    int _25477 = NOVALUE;
    int _25476 = NOVALUE;
    int _25474 = NOVALUE;
    int _0, _1, _2;
    

    /**     if TempErrFile != -1 then*/
    if (_43TempErrFile_48554 == -1)
    goto L1; // [5] 19

    /** 		TempErrFile = open(TempErrName, "w")*/
    _43TempErrFile_48554 = EOpen(_43TempErrName_48555, _22143, 0);
L1: 

    /** 	if TempErrFile = -1 then*/
    if (_43TempErrFile_48554 != -1)
    goto L2; // [23] 64

    /** 		if length(TempErrName) > 0 then*/
    _25474 = 6;

    /** 			screen_output(STDERR, GetMsgText(209, 0, {TempErrName}))*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_43TempErrName_48555);
    *((int *)(_2+4)) = _43TempErrName_48555;
    _25476 = MAKE_SEQ(_1);
    _25477 = _44GetMsgText(209, 0, _25476);
    _25476 = NOVALUE;
    _43screen_output(2, _25477);
    _25477 = NOVALUE;

    /** 		abort(1) -- with no clean up*/
    UserCleanup(1);
L2: 

    /** end procedure*/
    return;
    ;
}


void _43ShowErr(int _f_48786)
{
    int _msg_inlined_screen_output_at_41_48798 = NOVALUE;
    int _25484 = NOVALUE;
    int _25483 = NOVALUE;
    int _25482 = NOVALUE;
    int _25480 = NOVALUE;
    int _25478 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(known_files) = 0 then*/
    if (IS_SEQUENCE(_27known_files_10922)){
            _25478 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _25478 = 1;
    }
    if (_25478 != 0)
    goto L1; // [10] 20

    /** 		return*/
    return;
L1: 

    /** 	if ThisLine[1] = END_OF_FILE_CHAR then*/
    _2 = (int)SEQ_PTR(_43ThisLine_48557);
    _25480 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _25480, 26)){
        _25480 = NOVALUE;
        goto L2; // [30] 62
    }
    _25480 = NOVALUE;

    /** 		screen_output(f, GetMsgText(210,0))*/
    RefDS(_22037);
    _25482 = _44GetMsgText(210, 0, _22037);
    DeRef(_msg_inlined_screen_output_at_41_48798);
    _msg_inlined_screen_output_at_41_48798 = _25482;
    _25482 = NOVALUE;

    /** 	puts(f, msg)*/
    EPuts(_f_48786, _msg_inlined_screen_output_at_41_48798); // DJP 

    /** end procedure*/
    goto L3; // [54] 57
L3: 
    DeRef(_msg_inlined_screen_output_at_41_48798);
    _msg_inlined_screen_output_at_41_48798 = NOVALUE;
    goto L4; // [59] 79
L2: 

    /** 		screen_output(f, ThisLine)*/

    /** 	puts(f, msg)*/
    EPuts(_f_48786, _43ThisLine_48557); // DJP 

    /** end procedure*/
    goto L5; // [75] 78
L5: 
L4: 

    /** 	for i = 1 to bp-2 do -- bp-1 points to last character read*/
    _25483 = _43bp_48561 - 2;
    if ((long)((unsigned long)_25483 +(unsigned long) HIGH_BITS) >= 0){
        _25483 = NewDouble((double)_25483);
    }
    {
        int _i_48802;
        _i_48802 = 1;
L6: 
        if (binary_op_a(GREATER, _i_48802, _25483)){
            goto L7; // [87] 141
        }

        /** 		if ThisLine[i] = '\t' then*/
        _2 = (int)SEQ_PTR(_43ThisLine_48557);
        if (!IS_ATOM_INT(_i_48802)){
            _25484 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_48802)->dbl));
        }
        else{
            _25484 = (int)*(((s1_ptr)_2)->base + _i_48802);
        }
        if (binary_op_a(NOTEQ, _25484, 9)){
            _25484 = NOVALUE;
            goto L8; // [102] 121
        }
        _25484 = NOVALUE;

        /** 			screen_output(f, "\t")*/

        /** 	puts(f, msg)*/
        EPuts(_f_48786, _23829); // DJP 

        /** end procedure*/
        goto L9; // [115] 134
        goto L9; // [118] 134
L8: 

        /** 			screen_output(f, " ")*/

        /** 	puts(f, msg)*/
        EPuts(_f_48786, _23312); // DJP 

        /** end procedure*/
        goto LA; // [130] 133
LA: 
L9: 

        /** 	end for*/
        _0 = _i_48802;
        if (IS_ATOM_INT(_i_48802)) {
            _i_48802 = _i_48802 + 1;
            if ((long)((unsigned long)_i_48802 +(unsigned long) HIGH_BITS) >= 0){
                _i_48802 = NewDouble((double)_i_48802);
            }
        }
        else {
            _i_48802 = binary_op_a(PLUS, _i_48802, 1);
        }
        DeRef(_0);
        goto L6; // [136] 94
L7: 
        ;
        DeRef(_i_48802);
    }

    /** 	screen_output(f, "^\n\n")*/

    /** 	puts(f, msg)*/
    EPuts(_f_48786, _25486); // DJP 

    /** end procedure*/
    goto LB; // [150] 153
LB: 

    /** end procedure*/
    DeRef(_25483);
    _25483 = NOVALUE;
    return;
    ;
}


void _43CompileErr(int _msg_48814, int _args_48815, int _preproc_48816)
{
    int _errmsg_48817 = NOVALUE;
    int _25507 = NOVALUE;
    int _25503 = NOVALUE;
    int _25502 = NOVALUE;
    int _25501 = NOVALUE;
    int _25500 = NOVALUE;
    int _25499 = NOVALUE;
    int _25498 = NOVALUE;
    int _25496 = NOVALUE;
    int _25495 = NOVALUE;
    int _25493 = NOVALUE;
    int _25492 = NOVALUE;
    int _25491 = NOVALUE;
    int _25487 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_preproc_48816)) {
        _1 = (long)(DBL_PTR(_preproc_48816)->dbl);
        DeRefDS(_preproc_48816);
        _preproc_48816 = _1;
    }

    /** 	if integer(msg) then*/
    if (IS_ATOM_INT(_msg_48814))
    _25487 = 1;
    else if (IS_ATOM_DBL(_msg_48814))
    _25487 = IS_ATOM_INT(DoubleToInt(_msg_48814));
    else
    _25487 = 0;
    if (_25487 == 0)
    {
        _25487 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25487 = NOVALUE;
    }

    /** 		msg = GetMsgText(msg)*/
    Ref(_msg_48814);
    RefDS(_22037);
    _0 = _msg_48814;
    _msg_48814 = _44GetMsgText(_msg_48814, 1, _22037);
    DeRef(_0);
L1: 

    /** 	msg = format(msg, args)*/
    Ref(_msg_48814);
    Ref(_args_48815);
    _0 = _msg_48814;
    _msg_48814 = _12format(_msg_48814, _args_48815);
    DeRef(_0);

    /** 	Errors += 1*/
    _43Errors_48553 = _43Errors_48553 + 1;

    /** 	if not preproc and length(known_files) then*/
    _25491 = (_preproc_48816 == 0);
    if (_25491 == 0) {
        goto L2; // [40] 78
    }
    if (IS_SEQUENCE(_27known_files_10922)){
            _25493 = SEQ_PTR(_27known_files_10922)->length;
    }
    else {
        _25493 = 1;
    }
    if (_25493 == 0)
    {
        _25493 = NOVALUE;
        goto L2; // [50] 78
    }
    else{
        _25493 = NOVALUE;
    }

    /** 		errmsg = sprintf("%s:%d\n%s\n", {known_files[current_file_no],*/
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _25495 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_25495);
    *((int *)(_2+4)) = _25495;
    *((int *)(_2+8)) = _26line_number_11983;
    Ref(_msg_48814);
    *((int *)(_2+12)) = _msg_48814;
    _25496 = MAKE_SEQ(_1);
    _25495 = NOVALUE;
    DeRef(_errmsg_48817);
    _errmsg_48817 = EPrintf(-9999999, _25494, _25496);
    DeRefDS(_25496);
    _25496 = NOVALUE;
    goto L3; // [75] 121
L2: 

    /** 		errmsg = msg*/
    Ref(_msg_48814);
    DeRef(_errmsg_48817);
    _errmsg_48817 = _msg_48814;

    /** 		if length(msg) > 0 and msg[$] != '\n' then*/
    if (IS_SEQUENCE(_msg_48814)){
            _25498 = SEQ_PTR(_msg_48814)->length;
    }
    else {
        _25498 = 1;
    }
    _25499 = (_25498 > 0);
    _25498 = NOVALUE;
    if (_25499 == 0) {
        goto L4; // [94] 120
    }
    if (IS_SEQUENCE(_msg_48814)){
            _25501 = SEQ_PTR(_msg_48814)->length;
    }
    else {
        _25501 = 1;
    }
    _2 = (int)SEQ_PTR(_msg_48814);
    _25502 = (int)*(((s1_ptr)_2)->base + _25501);
    if (IS_ATOM_INT(_25502)) {
        _25503 = (_25502 != 10);
    }
    else {
        _25503 = binary_op(NOTEQ, _25502, 10);
    }
    _25502 = NOVALUE;
    if (_25503 == 0) {
        DeRef(_25503);
        _25503 = NOVALUE;
        goto L4; // [110] 120
    }
    else {
        if (!IS_ATOM_INT(_25503) && DBL_PTR(_25503)->dbl == 0.0){
            DeRef(_25503);
            _25503 = NOVALUE;
            goto L4; // [110] 120
        }
        DeRef(_25503);
        _25503 = NOVALUE;
    }
    DeRef(_25503);
    _25503 = NOVALUE;

    /** 			errmsg &= '\n'*/
    Append(&_errmsg_48817, _errmsg_48817, 10);
L4: 
L3: 

    /** 	if not preproc then*/
    if (_preproc_48816 != 0)
    goto L5; // [123] 131

    /** 		OpenErrFile() -- exits if error filename is ""*/
    _43OpenErrFile();
L5: 

    /** 	screen_output(STDERR, errmsg)*/
    RefDS(_errmsg_48817);
    _43screen_output(2, _errmsg_48817);

    /** 	if not preproc then*/
    if (_preproc_48816 != 0)
    goto L6; // [143] 196

    /** 		ShowErr(STDERR)*/
    _43ShowErr(2);

    /** 		puts(TempErrFile, errmsg)*/
    EPuts(_43TempErrFile_48554, _errmsg_48817); // DJP 

    /** 		ShowErr(TempErrFile)*/
    _43ShowErr(_43TempErrFile_48554);

    /** 		ShowWarnings()*/
    _25507 = _43ShowWarnings();

    /** 		ShowDefines(TempErrFile)*/
    _43ShowDefines(_43TempErrFile_48554);

    /** 		close(TempErrFile)*/
    EClose(_43TempErrFile_48554);

    /** 		TempErrFile = -2*/
    _43TempErrFile_48554 = -2;

    /** 		Cleanup(1)*/
    _43Cleanup(1);
L6: 

    /** end procedure*/
    DeRef(_msg_48814);
    DeRef(_args_48815);
    DeRef(_errmsg_48817);
    DeRef(_25491);
    _25491 = NOVALUE;
    DeRef(_25499);
    _25499 = NOVALUE;
    DeRef(_25507);
    _25507 = NOVALUE;
    return;
    ;
}


void _43InternalErr(int _msgno_48860, int _args_48861)
{
    int _msg_48862 = NOVALUE;
    int _25522 = NOVALUE;
    int _25521 = NOVALUE;
    int _25520 = NOVALUE;
    int _25519 = NOVALUE;
    int _25518 = NOVALUE;
    int _25517 = NOVALUE;
    int _25516 = NOVALUE;
    int _25515 = NOVALUE;
    int _25514 = NOVALUE;
    int _25513 = NOVALUE;
    int _25512 = NOVALUE;
    int _25509 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_msgno_48860)) {
        _1 = (long)(DBL_PTR(_msgno_48860)->dbl);
        DeRefDS(_msgno_48860);
        _msgno_48860 = _1;
    }

    /** 	if atom(args) then*/
    _25509 = IS_ATOM(_args_48861);
    if (_25509 == 0)
    {
        _25509 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _25509 = NOVALUE;
    }

    /** 		args = {args}*/
    _0 = _args_48861;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_args_48861);
    *((int *)(_2+4)) = _args_48861;
    _args_48861 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	msg = GetMsgText(msgno, 1, args)*/
    Ref(_args_48861);
    _0 = _msg_48862;
    _msg_48862 = _44GetMsgText(_msgno_48860, 1, _args_48861);
    DeRef(_0);

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L2; // [32] 56
    }
    else{
    }

    /** 		screen_output(STDERR, GetMsgText(211, 1, {msg}))*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_msg_48862);
    *((int *)(_2+4)) = _msg_48862;
    _25512 = MAKE_SEQ(_1);
    _25513 = _44GetMsgText(211, 1, _25512);
    _25512 = NOVALUE;
    _43screen_output(2, _25513);
    _25513 = NOVALUE;
    goto L3; // [53] 87
L2: 

    /** 		screen_output(STDERR, GetMsgText(212, 1, {known_files[current_file_no], line_number, msg}))*/
    _2 = (int)SEQ_PTR(_27known_files_10922);
    _25514 = (int)*(((s1_ptr)_2)->base + _26current_file_no_11982);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_25514);
    *((int *)(_2+4)) = _25514;
    *((int *)(_2+8)) = _26line_number_11983;
    RefDS(_msg_48862);
    *((int *)(_2+12)) = _msg_48862;
    _25515 = MAKE_SEQ(_1);
    _25514 = NOVALUE;
    _25516 = _44GetMsgText(212, 1, _25515);
    _25515 = NOVALUE;
    _43screen_output(2, _25516);
    _25516 = NOVALUE;
L3: 

    /** 	if not batch_job and not test_only then*/
    _25517 = (_26batch_job_11995 == 0);
    if (_25517 == 0) {
        goto L4; // [94] 127
    }
    _25519 = (_26test_only_11994 == 0);
    if (_25519 == 0)
    {
        DeRef(_25519);
        _25519 = NOVALUE;
        goto L4; // [104] 127
    }
    else{
        DeRef(_25519);
        _25519 = NOVALUE;
    }

    /** 		screen_output(STDERR, GetMsgText(208, 0))*/
    RefDS(_22037);
    _25520 = _44GetMsgText(208, 0, _22037);
    _43screen_output(2, _25520);
    _25520 = NOVALUE;

    /** 		getc(0)*/
    if (0 != last_r_file_no) {
        last_r_file_ptr = which_file(0, EF_READ);
        last_r_file_no = 0;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _25521 = getKBchar();
        }
        else
        _25521 = getc(last_r_file_ptr);
    }
    else
    _25521 = getc(last_r_file_ptr);
L4: 

    /** 	machine_proc(67, GetMsgText(213))*/
    RefDS(_22037);
    _25522 = _44GetMsgText(213, 1, _22037);
    machine(67, _25522);
    DeRef(_25522);
    _25522 = NOVALUE;

    /** end procedure*/
    DeRef(_args_48861);
    DeRef(_msg_48862);
    DeRef(_25517);
    _25517 = NOVALUE;
    return;
    ;
}



// 0x3597FCEF
