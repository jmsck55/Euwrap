// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _4open_dll(int _file_name_1297)
{
    int _fh_1307 = NOVALUE;
    int _507 = NOVALUE;
    int _505 = NOVALUE;
    int _504 = NOVALUE;
    int _503 = NOVALUE;
    int _502 = NOVALUE;
    int _501 = NOVALUE;
    int _500 = NOVALUE;
    int _499 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(file_name) > 0 and types:string(file_name) then*/
    if (IS_SEQUENCE(_file_name_1297)){
            _499 = SEQ_PTR(_file_name_1297)->length;
    }
    else {
        _499 = 1;
    }
    _500 = (_499 > 0);
    _499 = NOVALUE;
    if (_500 == 0) {
        goto L1; // [12] 35
    }
    RefDS(_file_name_1297);
    _502 = _9string(_file_name_1297);
    if (_502 == 0) {
        DeRef(_502);
        _502 = NOVALUE;
        goto L1; // [21] 35
    }
    else {
        if (!IS_ATOM_INT(_502) && DBL_PTR(_502)->dbl == 0.0){
            DeRef(_502);
            _502 = NOVALUE;
            goto L1; // [21] 35
        }
        DeRef(_502);
        _502 = NOVALUE;
    }
    DeRef(_502);
    _502 = NOVALUE;

    /** 		return machine_func(M_OPEN_DLL, file_name)*/
    _503 = machine(50, _file_name_1297);
    DeRefDS(_file_name_1297);
    DeRef(_500);
    _500 = NOVALUE;
    return _503;
L1: 

    /** 	for idx = 1 to length(file_name) do*/
    if (IS_SEQUENCE(_file_name_1297)){
            _504 = SEQ_PTR(_file_name_1297)->length;
    }
    else {
        _504 = 1;
    }
    {
        int _idx_1305;
        _idx_1305 = 1;
L2: 
        if (_idx_1305 > _504){
            goto L3; // [40] 82
        }

        /** 		atom fh = machine_func(M_OPEN_DLL, file_name[idx])*/
        _2 = (int)SEQ_PTR(_file_name_1297);
        _505 = (int)*(((s1_ptr)_2)->base + _idx_1305);
        DeRef(_fh_1307);
        _fh_1307 = machine(50, _505);
        _505 = NOVALUE;

        /** 		if not fh = 0 then*/
        if (IS_ATOM_INT(_fh_1307)) {
            _507 = (_fh_1307 == 0);
        }
        else {
            _507 = unary_op(NOT, _fh_1307);
        }
        if (_507 != 0)
        goto L4; // [62] 73

        /** 			return fh*/
        DeRefDS(_file_name_1297);
        DeRef(_500);
        _500 = NOVALUE;
        DeRef(_503);
        _503 = NOVALUE;
        _507 = NOVALUE;
        return _fh_1307;
L4: 
        DeRef(_fh_1307);
        _fh_1307 = NOVALUE;

        /** 	end for*/
        _idx_1305 = _idx_1305 + 1;
        goto L2; // [77] 47
L3: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_file_name_1297);
    DeRef(_500);
    _500 = NOVALUE;
    DeRef(_503);
    _503 = NOVALUE;
    DeRef(_507);
    _507 = NOVALUE;
    return 0;
    ;
}


int _4define_c_proc(int _lib_1321, int _routine_name_1322, int _arg_types_1323)
{
    int _safe_address_inlined_safe_address_at_11_1328 = NOVALUE;
    int _msg_inlined_crash_at_26_1332 = NOVALUE;
    int _516 = NOVALUE;
    int _515 = NOVALUE;
    int _513 = NOVALUE;
    int _512 = NOVALUE;
    int _511 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(routine_name) and not machine:safe_address(routine_name, 1, machine:A_EXECUTE) then*/
    _511 = 0;
    if (_511 == 0) {
        goto L1; // [8] 46
    }

    /** 	return 1*/
    _safe_address_inlined_safe_address_at_11_1328 = 1;
    _513 = (1 == 0);
    if (_513 == 0)
    {
        DeRef(_513);
        _513 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        DeRef(_513);
        _513 = NOVALUE;
    }

    /**         error:crash("A C function is being defined from Non-executable memory.")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_26_1332);
    _msg_inlined_crash_at_26_1332 = EPrintf(-9999999, _514, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_26_1332);

    /** end procedure*/
    goto L2; // [40] 43
L2: 
    DeRefi(_msg_inlined_crash_at_26_1332);
    _msg_inlined_crash_at_26_1332 = NOVALUE;
L1: 

    /** 	return machine_func(M_DEFINE_C, {lib, routine_name, arg_types, 0})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_lib_1321);
    *((int *)(_2+4)) = _lib_1321;
    Ref(_routine_name_1322);
    *((int *)(_2+8)) = _routine_name_1322;
    RefDS(_arg_types_1323);
    *((int *)(_2+12)) = _arg_types_1323;
    *((int *)(_2+16)) = 0;
    _515 = MAKE_SEQ(_1);
    _516 = machine(51, _515);
    DeRefDS(_515);
    _515 = NOVALUE;
    DeRef(_lib_1321);
    DeRefi(_routine_name_1322);
    DeRefDSi(_arg_types_1323);
    return _516;
    ;
}


int _4define_c_func(int _lib_1337, int _routine_name_1338, int _arg_types_1339, int _return_type_1340)
{
    int _safe_address_inlined_safe_address_at_11_1345 = NOVALUE;
    int _msg_inlined_crash_at_26_1348 = NOVALUE;
    int _521 = NOVALUE;
    int _520 = NOVALUE;
    int _519 = NOVALUE;
    int _518 = NOVALUE;
    int _517 = NOVALUE;
    int _0, _1, _2;
    

    /** 	  if atom(routine_name) and not machine:safe_address(routine_name, 1, machine:A_EXECUTE) then*/
    _517 = 0;
    if (_517 == 0) {
        goto L1; // [8] 46
    }

    /** 	return 1*/
    _safe_address_inlined_safe_address_at_11_1345 = 1;
    _519 = (1 == 0);
    if (_519 == 0)
    {
        DeRef(_519);
        _519 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        DeRef(_519);
        _519 = NOVALUE;
    }

    /** 	      error:crash("A C function is being defined from Non-executable memory.")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_26_1348);
    _msg_inlined_crash_at_26_1348 = EPrintf(-9999999, _514, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_26_1348);

    /** end procedure*/
    goto L2; // [40] 43
L2: 
    DeRefi(_msg_inlined_crash_at_26_1348);
    _msg_inlined_crash_at_26_1348 = NOVALUE;
L1: 

    /** 	  return machine_func(M_DEFINE_C, {lib, routine_name, arg_types, return_type})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_lib_1337);
    *((int *)(_2+4)) = _lib_1337;
    Ref(_routine_name_1338);
    *((int *)(_2+8)) = _routine_name_1338;
    RefDS(_arg_types_1339);
    *((int *)(_2+12)) = _arg_types_1339;
    *((int *)(_2+16)) = _return_type_1340;
    _520 = MAKE_SEQ(_1);
    _521 = machine(51, _520);
    DeRefDS(_520);
    _520 = NOVALUE;
    DeRef(_lib_1337);
    DeRefi(_routine_name_1338);
    DeRefDSi(_arg_types_1339);
    return _521;
    ;
}



// 0x2A0283A3
