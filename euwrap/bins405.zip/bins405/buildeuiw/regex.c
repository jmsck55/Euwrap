// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _50regex(int _o_21553)
{
    int _12471 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return sequence(o)*/
    _12471 = IS_SEQUENCE(_o_21553);
    DeRef(_o_21553);
    return _12471;
    ;
}


int _50new(int _pattern_21593, int _options_21594)
{
    int _12491 = NOVALUE;
    int _12490 = NOVALUE;
    int _12488 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(options) then */
    _12488 = 0;
    if (_12488 == 0)
    {
        _12488 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _12488 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    _options_21594 = _20or_all(_options_21594);
L1: 

    /** 	return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_options_21594);
    Ref(_pattern_21593);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pattern_21593;
    ((int *)_2)[2] = _options_21594;
    _12490 = MAKE_SEQ(_1);
    _12491 = machine(68, _12490);
    DeRefDS(_12490);
    _12490 = NOVALUE;
    DeRef(_pattern_21593);
    DeRef(_options_21594);
    return _12491;
    ;
}


int _50get_ovector_size(int _ex_21613, int _maxsize_21614)
{
    int _m_21615 = NOVALUE;
    int _12499 = NOVALUE;
    int _12496 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer m = machine_func(M_PCRE_GET_OVECTOR_SIZE, {ex})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_ex_21613);
    *((int *)(_2+4)) = _ex_21613;
    _12496 = MAKE_SEQ(_1);
    _m_21615 = machine(97, _12496);
    DeRefDS(_12496);
    _12496 = NOVALUE;
    if (!IS_ATOM_INT(_m_21615)) {
        _1 = (long)(DBL_PTR(_m_21615)->dbl);
        DeRefDS(_m_21615);
        _m_21615 = _1;
    }

    /** 	if (m > maxsize) then*/
    if (_m_21615 <= 30)
    goto L1; // [17] 28

    /** 		return maxsize*/
    DeRef(_ex_21613);
    return 30;
L1: 

    /** 	return m+1*/
    _12499 = _m_21615 + 1;
    if (_12499 > MAXINT){
        _12499 = NewDouble((double)_12499);
    }
    DeRef(_ex_21613);
    return _12499;
    ;
}


int _50find(int _re_21623, int _haystack_21625, int _from_21626, int _options_21627, int _size_21628)
{
    int _12506 = NOVALUE;
    int _12505 = NOVALUE;
    int _12504 = NOVALUE;
    int _12501 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_21628)) {
        _1 = (long)(DBL_PTR(_size_21628)->dbl);
        DeRefDS(_size_21628);
        _size_21628 = _1;
    }

    /** 	if sequence(options) then */
    _12501 = IS_SEQUENCE(_options_21627);
    if (_12501 == 0)
    {
        _12501 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12501 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21627);
    _0 = _options_21627;
    _options_21627 = _20or_all(_options_21627);
    DeRef(_0);
L1: 

    /** 	if size < 0 then*/
    if (_size_21628 >= 0)
    goto L2; // [22] 32

    /** 		size = 0*/
    _size_21628 = 0;
L2: 

    /** 	return machine_func(M_PCRE_EXEC, { re, haystack, length(haystack), options, from, size })*/
    if (IS_SEQUENCE(_haystack_21625)){
            _12504 = SEQ_PTR(_haystack_21625)->length;
    }
    else {
        _12504 = 1;
    }
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_re_21623);
    *((int *)(_2+4)) = _re_21623;
    Ref(_haystack_21625);
    *((int *)(_2+8)) = _haystack_21625;
    *((int *)(_2+12)) = _12504;
    Ref(_options_21627);
    *((int *)(_2+16)) = _options_21627;
    *((int *)(_2+20)) = _from_21626;
    *((int *)(_2+24)) = _size_21628;
    _12505 = MAKE_SEQ(_1);
    _12504 = NOVALUE;
    _12506 = machine(70, _12505);
    DeRefDS(_12505);
    _12505 = NOVALUE;
    DeRef(_re_21623);
    DeRef(_haystack_21625);
    DeRef(_options_21627);
    return _12506;
    ;
}


int _50find_all(int _re_21640, int _haystack_21642, int _from_21643, int _options_21644, int _size_21645)
{
    int _result_21652 = NOVALUE;
    int _results_21653 = NOVALUE;
    int _pHaystack_21654 = NOVALUE;
    int _12519 = NOVALUE;
    int _12518 = NOVALUE;
    int _12516 = NOVALUE;
    int _12514 = NOVALUE;
    int _12512 = NOVALUE;
    int _12508 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_21645)) {
        _1 = (long)(DBL_PTR(_size_21645)->dbl);
        DeRefDS(_size_21645);
        _size_21645 = _1;
    }

    /** 	if sequence(options) then */
    _12508 = IS_SEQUENCE(_options_21644);
    if (_12508 == 0)
    {
        _12508 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12508 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21644);
    _0 = _options_21644;
    _options_21644 = _20or_all(_options_21644);
    DeRef(_0);
L1: 

    /** 	if size < 0 then*/
    if (_size_21645 >= 0)
    goto L2; // [22] 32

    /** 		size = 0*/
    _size_21645 = 0;
L2: 

    /** 	object result*/

    /** 	sequence results = {}*/
    RefDS(_5);
    DeRef(_results_21653);
    _results_21653 = _5;

    /** 	atom pHaystack = machine:allocate_string(haystack)*/
    Ref(_haystack_21642);
    _0 = _pHaystack_21654;
    _pHaystack_21654 = _6allocate_string(_haystack_21642, 0);
    DeRef(_0);

    /** 	while sequence(result) with entry do*/
    goto L3; // [50] 94
L4: 
    _12512 = IS_SEQUENCE(_result_21652);
    if (_12512 == 0)
    {
        _12512 = NOVALUE;
        goto L5; // [58] 117
    }
    else{
        _12512 = NOVALUE;
    }

    /** 		results = append(results, result)*/
    Ref(_result_21652);
    Append(&_results_21653, _results_21653, _result_21652);

    /** 		from = math:max(result) + 1*/
    Ref(_result_21652);
    _12514 = _20max(_result_21652);
    if (IS_ATOM_INT(_12514)) {
        _from_21643 = _12514 + 1;
    }
    else
    { // coercing _from_21643 to an integer 1
        _from_21643 = 1+(long)(DBL_PTR(_12514)->dbl);
        if( !IS_ATOM_INT(_from_21643) ){
            _from_21643 = (object)DBL_PTR(_from_21643)->dbl;
        }
    }
    DeRef(_12514);
    _12514 = NOVALUE;

    /** 		if from > length(haystack) then*/
    if (IS_SEQUENCE(_haystack_21642)){
            _12516 = SEQ_PTR(_haystack_21642)->length;
    }
    else {
        _12516 = 1;
    }
    if (_from_21643 <= _12516)
    goto L6; // [82] 91

    /** 			exit*/
    goto L5; // [88] 117
L6: 

    /** 	entry*/
L3: 

    /** 		result = machine_func(M_PCRE_EXEC, { re, pHaystack, length(haystack), options, from, size })*/
    if (IS_SEQUENCE(_haystack_21642)){
            _12518 = SEQ_PTR(_haystack_21642)->length;
    }
    else {
        _12518 = 1;
    }
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_re_21640);
    *((int *)(_2+4)) = _re_21640;
    Ref(_pHaystack_21654);
    *((int *)(_2+8)) = _pHaystack_21654;
    *((int *)(_2+12)) = _12518;
    Ref(_options_21644);
    *((int *)(_2+16)) = _options_21644;
    *((int *)(_2+20)) = _from_21643;
    *((int *)(_2+24)) = _size_21645;
    _12519 = MAKE_SEQ(_1);
    _12518 = NOVALUE;
    DeRef(_result_21652);
    _result_21652 = machine(70, _12519);
    DeRefDS(_12519);
    _12519 = NOVALUE;

    /** 	end while*/
    goto L4; // [114] 53
L5: 

    /** 	machine:free(pHaystack)*/
    Ref(_pHaystack_21654);
    _6free(_pHaystack_21654);

    /** 	return results*/
    DeRef(_re_21640);
    DeRef(_haystack_21642);
    DeRef(_options_21644);
    DeRef(_result_21652);
    DeRef(_pHaystack_21654);
    return _results_21653;
    ;
}


int _50has_match(int _re_21669, int _haystack_21671, int _from_21672, int _options_21673)
{
    int _12523 = NOVALUE;
    int _12522 = NOVALUE;
    int _12521 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return sequence(find(re, haystack, from, options))*/
    Ref(_re_21669);
    _12521 = _50get_ovector_size(_re_21669, 30);
    Ref(_re_21669);
    Ref(_haystack_21671);
    _12522 = _50find(_re_21669, _haystack_21671, 1, 0, _12521);
    _12521 = NOVALUE;
    _12523 = IS_SEQUENCE(_12522);
    DeRef(_12522);
    _12522 = NOVALUE;
    DeRef(_re_21669);
    DeRef(_haystack_21671);
    return _12523;
    ;
}


int _50matches(int _re_21703, int _haystack_21705, int _from_21706, int _options_21707)
{
    int _str_offsets_21711 = NOVALUE;
    int _match_data_21713 = NOVALUE;
    int _tmp_21723 = NOVALUE;
    int _12560 = NOVALUE;
    int _12559 = NOVALUE;
    int _12558 = NOVALUE;
    int _12557 = NOVALUE;
    int _12556 = NOVALUE;
    int _12554 = NOVALUE;
    int _12553 = NOVALUE;
    int _12552 = NOVALUE;
    int _12551 = NOVALUE;
    int _12549 = NOVALUE;
    int _12548 = NOVALUE;
    int _12547 = NOVALUE;
    int _12546 = NOVALUE;
    int _12544 = NOVALUE;
    int _12543 = NOVALUE;
    int _12542 = NOVALUE;
    int _12539 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(options) then */
    _12539 = 0;
    if (_12539 == 0)
    {
        _12539 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _12539 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    _options_21707 = _20or_all(0);
L1: 

    /** 	integer str_offsets = and_bits(STRING_OFFSETS, options)*/
    if (IS_ATOM_INT(_options_21707)) {
        {unsigned long tu;
             tu = (unsigned long)201326592 & (unsigned long)_options_21707;
             _str_offsets_21711 = MAKE_UINT(tu);
        }
    }
    else {
        _str_offsets_21711 = binary_op(AND_BITS, 201326592, _options_21707);
    }
    if (!IS_ATOM_INT(_str_offsets_21711)) {
        _1 = (long)(DBL_PTR(_str_offsets_21711)->dbl);
        DeRefDS(_str_offsets_21711);
        _str_offsets_21711 = _1;
    }

    /** 	object match_data = find(re, haystack, from, and_bits(options, not_bits(STRING_OFFSETS)))*/
    _12542 = not_bits(201326592);
    if (IS_ATOM_INT(_options_21707) && IS_ATOM_INT(_12542)) {
        {unsigned long tu;
             tu = (unsigned long)_options_21707 & (unsigned long)_12542;
             _12543 = MAKE_UINT(tu);
        }
    }
    else {
        _12543 = binary_op(AND_BITS, _options_21707, _12542);
    }
    DeRef(_12542);
    _12542 = NOVALUE;
    Ref(_re_21703);
    _12544 = _50get_ovector_size(_re_21703, 30);
    Ref(_re_21703);
    Ref(_haystack_21705);
    _0 = _match_data_21713;
    _match_data_21713 = _50find(_re_21703, _haystack_21705, _from_21706, _12543, _12544);
    DeRef(_0);
    _12543 = NOVALUE;
    _12544 = NOVALUE;

    /** 	if atom(match_data) then */
    _12546 = IS_ATOM(_match_data_21713);
    if (_12546 == 0)
    {
        _12546 = NOVALUE;
        goto L2; // [53] 63
    }
    else{
        _12546 = NOVALUE;
    }

    /** 		return ERROR_NOMATCH */
    DeRef(_re_21703);
    DeRef(_haystack_21705);
    DeRef(_options_21707);
    DeRef(_match_data_21713);
    return -1;
L2: 

    /** 	for i = 1 to length(match_data) do*/
    if (IS_SEQUENCE(_match_data_21713)){
            _12547 = SEQ_PTR(_match_data_21713)->length;
    }
    else {
        _12547 = 1;
    }
    {
        int _i_21721;
        _i_21721 = 1;
L3: 
        if (_i_21721 > _12547){
            goto L4; // [68] 181
        }

        /** 		sequence tmp*/

        /** 		if match_data[i][1] = 0 then*/
        _2 = (int)SEQ_PTR(_match_data_21713);
        _12548 = (int)*(((s1_ptr)_2)->base + _i_21721);
        _2 = (int)SEQ_PTR(_12548);
        _12549 = (int)*(((s1_ptr)_2)->base + 1);
        _12548 = NOVALUE;
        if (binary_op_a(NOTEQ, _12549, 0)){
            _12549 = NOVALUE;
            goto L5; // [87] 101
        }
        _12549 = NOVALUE;

        /** 			tmp = ""*/
        RefDS(_5);
        DeRef(_tmp_21723);
        _tmp_21723 = _5;
        goto L6; // [98] 125
L5: 

        /** 			tmp = haystack[match_data[i][1]..match_data[i][2]]*/
        _2 = (int)SEQ_PTR(_match_data_21713);
        _12551 = (int)*(((s1_ptr)_2)->base + _i_21721);
        _2 = (int)SEQ_PTR(_12551);
        _12552 = (int)*(((s1_ptr)_2)->base + 1);
        _12551 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21713);
        _12553 = (int)*(((s1_ptr)_2)->base + _i_21721);
        _2 = (int)SEQ_PTR(_12553);
        _12554 = (int)*(((s1_ptr)_2)->base + 2);
        _12553 = NOVALUE;
        rhs_slice_target = (object_ptr)&_tmp_21723;
        RHS_Slice(_haystack_21705, _12552, _12554);
L6: 

        /** 		if str_offsets then*/
        if (_str_offsets_21711 == 0)
        {
            goto L7; // [127] 163
        }
        else{
        }

        /** 			match_data[i] = { tmp, match_data[i][1], match_data[i][2] }*/
        _2 = (int)SEQ_PTR(_match_data_21713);
        _12556 = (int)*(((s1_ptr)_2)->base + _i_21721);
        _2 = (int)SEQ_PTR(_12556);
        _12557 = (int)*(((s1_ptr)_2)->base + 1);
        _12556 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21713);
        _12558 = (int)*(((s1_ptr)_2)->base + _i_21721);
        _2 = (int)SEQ_PTR(_12558);
        _12559 = (int)*(((s1_ptr)_2)->base + 2);
        _12558 = NOVALUE;
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_tmp_21723);
        *((int *)(_2+4)) = _tmp_21723;
        Ref(_12557);
        *((int *)(_2+8)) = _12557;
        Ref(_12559);
        *((int *)(_2+12)) = _12559;
        _12560 = MAKE_SEQ(_1);
        _12559 = NOVALUE;
        _12557 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21713);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _match_data_21713 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21721);
        _1 = *(int *)_2;
        *(int *)_2 = _12560;
        if( _1 != _12560 ){
            DeRef(_1);
        }
        _12560 = NOVALUE;
        goto L8; // [160] 172
L7: 

        /** 			match_data[i] = tmp*/
        RefDS(_tmp_21723);
        _2 = (int)SEQ_PTR(_match_data_21713);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _match_data_21713 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21721);
        _1 = *(int *)_2;
        *(int *)_2 = _tmp_21723;
        DeRef(_1);
L8: 
        DeRef(_tmp_21723);
        _tmp_21723 = NOVALUE;

        /** 	end for*/
        _i_21721 = _i_21721 + 1;
        goto L3; // [176] 75
L4: 
        ;
    }

    /** 	return match_data*/
    DeRef(_re_21703);
    DeRef(_haystack_21705);
    DeRef(_options_21707);
    _12552 = NOVALUE;
    _12554 = NOVALUE;
    return _match_data_21713;
    ;
}


int _50split(int _re_21790, int _text_21792, int _from_21793, int _options_21794)
{
    int _12586 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return split_limit(re, text, 0, from, options)*/
    Ref(_re_21790);
    RefDS(_text_21792);
    _12586 = _50split_limit(_re_21790, _text_21792, 0, 1, 0);
    DeRef(_re_21790);
    DeRefDS(_text_21792);
    return _12586;
    ;
}


int _50split_limit(int _re_21799, int _text_21801, int _limit_21802, int _from_21803, int _options_21804)
{
    int _match_data_21808 = NOVALUE;
    int _result_21811 = NOVALUE;
    int _last_21812 = NOVALUE;
    int _a_21823 = NOVALUE;
    int _12612 = NOVALUE;
    int _12611 = NOVALUE;
    int _12610 = NOVALUE;
    int _12608 = NOVALUE;
    int _12606 = NOVALUE;
    int _12605 = NOVALUE;
    int _12604 = NOVALUE;
    int _12603 = NOVALUE;
    int _12602 = NOVALUE;
    int _12599 = NOVALUE;
    int _12598 = NOVALUE;
    int _12597 = NOVALUE;
    int _12594 = NOVALUE;
    int _12593 = NOVALUE;
    int _12591 = NOVALUE;
    int _12589 = NOVALUE;
    int _12587 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(options) then */
    _12587 = 0;
    if (_12587 == 0)
    {
        _12587 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12587 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    _options_21804 = _20or_all(0);
L1: 

    /** 	sequence match_data = find_all(re, text, from, options), result*/
    Ref(_re_21799);
    _12589 = _50get_ovector_size(_re_21799, 30);
    Ref(_re_21799);
    Ref(_text_21801);
    Ref(_options_21804);
    _0 = _match_data_21808;
    _match_data_21808 = _50find_all(_re_21799, _text_21801, _from_21803, _options_21804, _12589);
    DeRef(_0);
    _12589 = NOVALUE;

    /** 	integer last = 1*/
    _last_21812 = 1;

    /** 	if limit = 0 or limit > length(match_data) then*/
    _12591 = (_limit_21802 == 0);
    if (_12591 != 0) {
        goto L2; // [48] 64
    }
    if (IS_SEQUENCE(_match_data_21808)){
            _12593 = SEQ_PTR(_match_data_21808)->length;
    }
    else {
        _12593 = 1;
    }
    _12594 = (_limit_21802 > _12593);
    _12593 = NOVALUE;
    if (_12594 == 0)
    {
        DeRef(_12594);
        _12594 = NOVALUE;
        goto L3; // [60] 70
    }
    else{
        DeRef(_12594);
        _12594 = NOVALUE;
    }
L2: 

    /** 		limit = length(match_data)*/
    if (IS_SEQUENCE(_match_data_21808)){
            _limit_21802 = SEQ_PTR(_match_data_21808)->length;
    }
    else {
        _limit_21802 = 1;
    }
L3: 

    /** 	result = repeat(0, limit)*/
    DeRef(_result_21811);
    _result_21811 = Repeat(0, _limit_21802);

    /** 	for i = 1 to limit do*/
    _12597 = _limit_21802;
    {
        int _i_21821;
        _i_21821 = 1;
L4: 
        if (_i_21821 > _12597){
            goto L5; // [81] 164
        }

        /** 		integer a*/

        /** 		a = match_data[i][1][1]*/
        _2 = (int)SEQ_PTR(_match_data_21808);
        _12598 = (int)*(((s1_ptr)_2)->base + _i_21821);
        _2 = (int)SEQ_PTR(_12598);
        _12599 = (int)*(((s1_ptr)_2)->base + 1);
        _12598 = NOVALUE;
        _2 = (int)SEQ_PTR(_12599);
        _a_21823 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_a_21823)){
            _a_21823 = (long)DBL_PTR(_a_21823)->dbl;
        }
        _12599 = NOVALUE;

        /** 		if a = 0 then*/
        if (_a_21823 != 0)
        goto L6; // [108] 121

        /** 			result[i] = ""*/
        RefDS(_5);
        _2 = (int)SEQ_PTR(_result_21811);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result_21811 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21821);
        _1 = *(int *)_2;
        *(int *)_2 = _5;
        DeRef(_1);
        goto L7; // [118] 155
L6: 

        /** 			result[i] = text[last..a - 1]*/
        _12602 = _a_21823 - 1;
        rhs_slice_target = (object_ptr)&_12603;
        RHS_Slice(_text_21801, _last_21812, _12602);
        _2 = (int)SEQ_PTR(_result_21811);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result_21811 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21821);
        _1 = *(int *)_2;
        *(int *)_2 = _12603;
        if( _1 != _12603 ){
            DeRef(_1);
        }
        _12603 = NOVALUE;

        /** 			last = match_data[i][1][2] + 1*/
        _2 = (int)SEQ_PTR(_match_data_21808);
        _12604 = (int)*(((s1_ptr)_2)->base + _i_21821);
        _2 = (int)SEQ_PTR(_12604);
        _12605 = (int)*(((s1_ptr)_2)->base + 1);
        _12604 = NOVALUE;
        _2 = (int)SEQ_PTR(_12605);
        _12606 = (int)*(((s1_ptr)_2)->base + 2);
        _12605 = NOVALUE;
        if (IS_ATOM_INT(_12606)) {
            _last_21812 = _12606 + 1;
        }
        else
        { // coercing _last_21812 to an integer 1
            _last_21812 = 1+(long)(DBL_PTR(_12606)->dbl);
            if( !IS_ATOM_INT(_last_21812) ){
                _last_21812 = (object)DBL_PTR(_last_21812)->dbl;
            }
        }
        _12606 = NOVALUE;
L7: 

        /** 	end for*/
        _i_21821 = _i_21821 + 1;
        goto L4; // [159] 88
L5: 
        ;
    }

    /** 	if last < length(text) then*/
    if (IS_SEQUENCE(_text_21801)){
            _12608 = SEQ_PTR(_text_21801)->length;
    }
    else {
        _12608 = 1;
    }
    if (_last_21812 >= _12608)
    goto L8; // [169] 192

    /** 		result &= { text[last..$] }*/
    if (IS_SEQUENCE(_text_21801)){
            _12610 = SEQ_PTR(_text_21801)->length;
    }
    else {
        _12610 = 1;
    }
    rhs_slice_target = (object_ptr)&_12611;
    RHS_Slice(_text_21801, _last_21812, _12610);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12611;
    _12612 = MAKE_SEQ(_1);
    _12611 = NOVALUE;
    Concat((object_ptr)&_result_21811, _result_21811, _12612);
    DeRefDS(_12612);
    _12612 = NOVALUE;
L8: 

    /** 	return result*/
    DeRef(_re_21799);
    DeRef(_text_21801);
    DeRef(_options_21804);
    DeRef(_match_data_21808);
    DeRef(_12591);
    _12591 = NOVALUE;
    DeRef(_12602);
    _12602 = NOVALUE;
    return _result_21811;
    ;
}


int _50find_replace(int _ex_21845, int _text_21847, int _replacement_21848, int _from_21849, int _options_21850)
{
    int _12614 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return find_replace_limit(ex, text, replacement, -1, from, options)*/
    Ref(_ex_21845);
    RefDS(_text_21847);
    RefDS(_replacement_21848);
    _12614 = _50find_replace_limit(_ex_21845, _text_21847, _replacement_21848, -1, 1, 0);
    DeRef(_ex_21845);
    DeRefDS(_text_21847);
    DeRefDS(_replacement_21848);
    return _12614;
    ;
}


int _50find_replace_limit(int _ex_21855, int _text_21857, int _replacement_21858, int _limit_21859, int _from_21860, int _options_21861)
{
    int _12618 = NOVALUE;
    int _12617 = NOVALUE;
    int _12615 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(options) then */
    _12615 = 0;
    if (_12615 == 0)
    {
        _12615 = NOVALUE;
        goto L1; // [12] 22
    }
    else{
        _12615 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    _options_21861 = _20or_all(0);
L1: 

    /**     return machine_func(M_PCRE_REPLACE, { ex, text, replacement, options, */
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_ex_21855);
    *((int *)(_2+4)) = _ex_21855;
    Ref(_text_21857);
    *((int *)(_2+8)) = _text_21857;
    RefDS(_replacement_21858);
    *((int *)(_2+12)) = _replacement_21858;
    Ref(_options_21861);
    *((int *)(_2+16)) = _options_21861;
    *((int *)(_2+20)) = _from_21860;
    *((int *)(_2+24)) = _limit_21859;
    _12617 = MAKE_SEQ(_1);
    _12618 = machine(71, _12617);
    DeRefDS(_12617);
    _12617 = NOVALUE;
    DeRef(_ex_21855);
    DeRef(_text_21857);
    DeRefDS(_replacement_21858);
    DeRef(_options_21861);
    return _12618;
    ;
}



// 0x5FC332B1
