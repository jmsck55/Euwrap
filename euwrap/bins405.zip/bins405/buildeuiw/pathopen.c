// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _38convert_from_OEM(int _s_49595)
{
    int _ls_49596 = NOVALUE;
    int _rc_49597 = NOVALUE;
    int _25906 = NOVALUE;
    int _25905 = NOVALUE;
    int _25903 = NOVALUE;
    int _25902 = NOVALUE;
    int _25899 = NOVALUE;
    int _25898 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ls=length(s)*/
    if (IS_SEQUENCE(_s_49595)){
            _ls_49596 = SEQ_PTR(_s_49595)->length;
    }
    else {
        _ls_49596 = 1;
    }

    /** 	if ls>convert_length then*/
    if (_ls_49596 <= _38convert_length_49575)
    goto L1; // [12] 47

    /** 		free(convert_buffer)*/
    Ref(_38convert_buffer_49574);
    _6free(_38convert_buffer_49574);

    /** 		convert_length=and_bits(ls+15,-16)+1*/
    _25898 = _ls_49596 + 15;
    {unsigned long tu;
         tu = (unsigned long)_25898 & (unsigned long)-16;
         _25899 = MAKE_UINT(tu);
    }
    _25898 = NOVALUE;
    if (IS_ATOM_INT(_25899)) {
        _38convert_length_49575 = _25899 + 1;
    }
    else
    { // coercing _38convert_length_49575 to an integer 1
        _38convert_length_49575 = 1+(long)(DBL_PTR(_25899)->dbl);
        if( !IS_ATOM_INT(_38convert_length_49575) ){
            _38convert_length_49575 = (object)DBL_PTR(_38convert_length_49575)->dbl;
        }
    }
    DeRef(_25899);
    _25899 = NOVALUE;

    /** 		convert_buffer=allocate(convert_length)*/
    _0 = _6allocate(_38convert_length_49575, 0);
    DeRef(_38convert_buffer_49574);
    _38convert_buffer_49574 = _0;
L1: 

    /** 	poke(convert_buffer,s)*/
    if (IS_ATOM_INT(_38convert_buffer_49574)){
        poke_addr = (unsigned char *)_38convert_buffer_49574;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_38convert_buffer_49574)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_49595);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 	poke(convert_buffer+ls,0)*/
    if (IS_ATOM_INT(_38convert_buffer_49574)) {
        _25902 = _38convert_buffer_49574 + _ls_49596;
        if ((long)((unsigned long)_25902 + (unsigned long)HIGH_BITS) >= 0) 
        _25902 = NewDouble((double)_25902);
    }
    else {
        _25902 = NewDouble(DBL_PTR(_38convert_buffer_49574)->dbl + (double)_ls_49596);
    }
    if (IS_ATOM_INT(_25902)){
        poke_addr = (unsigned char *)_25902;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_25902)->dbl);
    }
    *poke_addr = (unsigned char)0;
    DeRef(_25902);
    _25902 = NOVALUE;

    /** 	rc=c_func(oem2char,{convert_buffer,convert_buffer}) -- always nonzero*/
    Ref(_38convert_buffer_49574);
    Ref(_38convert_buffer_49574);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38convert_buffer_49574;
    ((int *)_2)[2] = _38convert_buffer_49574;
    _25903 = MAKE_SEQ(_1);
    _rc_49597 = call_c(1, _38oem2char_49573, _25903);
    DeRefDS(_25903);
    _25903 = NOVALUE;
    if (!IS_ATOM_INT(_rc_49597)) {
        _1 = (long)(DBL_PTR(_rc_49597)->dbl);
        DeRefDS(_rc_49597);
        _rc_49597 = _1;
    }

    /** 	return peek({convert_buffer,ls}) */
    Ref(_38convert_buffer_49574);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38convert_buffer_49574;
    ((int *)_2)[2] = _ls_49596;
    _25905 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_25905);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _25906 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_25905);
    _25905 = NOVALUE;
    DeRefDS(_s_49595);
    return _25906;
    ;
}


int _38exe_path()
{
    int _25910 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(exe_path_cache) then*/
    _25910 = IS_SEQUENCE(_38exe_path_cache_49627);
    if (_25910 == 0)
    {
        _25910 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25910 = NOVALUE;
    }

    /** 		return exe_path_cache*/
    Ref(_38exe_path_cache_49627);
    return _38exe_path_cache_49627;
L1: 

    /** 	exe_path_cache = command_line()*/
    DeRef(_38exe_path_cache_49627);
    _38exe_path_cache_49627 = Command_Line();

    /** 	exe_path_cache = exe_path_cache[1]*/
    _0 = _38exe_path_cache_49627;
    _2 = (int)SEQ_PTR(_38exe_path_cache_49627);
    _38exe_path_cache_49627 = (int)*(((s1_ptr)_2)->base + 1);
    RefDS(_38exe_path_cache_49627);
    DeRefDS(_0);

    /** 	return exe_path_cache*/
    RefDS(_38exe_path_cache_49627);
    return _38exe_path_cache_49627;
    ;
}


int _38check_cache(int _env_49639, int _inc_path_49640)
{
    int _delim_49641 = NOVALUE;
    int _pos_49642 = NOVALUE;
    int _25961 = NOVALUE;
    int _25960 = NOVALUE;
    int _25959 = NOVALUE;
    int _25958 = NOVALUE;
    int _25956 = NOVALUE;
    int _25955 = NOVALUE;
    int _25954 = NOVALUE;
    int _25953 = NOVALUE;
    int _25952 = NOVALUE;
    int _25951 = NOVALUE;
    int _25950 = NOVALUE;
    int _25949 = NOVALUE;
    int _25948 = NOVALUE;
    int _25947 = NOVALUE;
    int _25946 = NOVALUE;
    int _25942 = NOVALUE;
    int _25941 = NOVALUE;
    int _25940 = NOVALUE;
    int _25939 = NOVALUE;
    int _25938 = NOVALUE;
    int _25937 = NOVALUE;
    int _25936 = NOVALUE;
    int _25935 = NOVALUE;
    int _25933 = NOVALUE;
    int _25932 = NOVALUE;
    int _25931 = NOVALUE;
    int _25930 = NOVALUE;
    int _25929 = NOVALUE;
    int _25928 = NOVALUE;
    int _25926 = NOVALUE;
    int _25925 = NOVALUE;
    int _25924 = NOVALUE;
    int _25923 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not num_var then -- first time the var is accessed, add cache entry*/
    if (_38num_var_49616 != 0)
    goto L1; // [9] 94

    /** 		cache_vars = append(cache_vars,env)*/
    RefDS(_env_49639);
    Append(&_38cache_vars_49617, _38cache_vars_49617, _env_49639);

    /** 		cache_strings = append(cache_strings,inc_path)*/
    RefDS(_inc_path_49640);
    Append(&_38cache_strings_49618, _38cache_strings_49618, _inc_path_49640);

    /** 		cache_substrings = append(cache_substrings,{})*/
    RefDS(_22037);
    Append(&_38cache_substrings_49619, _38cache_substrings_49619, _22037);

    /** 		cache_starts = append(cache_starts,{})*/
    RefDS(_22037);
    Append(&_38cache_starts_49620, _38cache_starts_49620, _22037);

    /** 		cache_ends = append(cache_ends,{})*/
    RefDS(_22037);
    Append(&_38cache_ends_49621, _38cache_ends_49621, _22037);

    /** 		ifdef WINDOWS then*/

    /** 			cache_converted = append(cache_converted,{})*/
    RefDS(_22037);
    Append(&_38cache_converted_49622, _38cache_converted_49622, _22037);

    /** 		num_var = length(cache_vars)*/
    if (IS_SEQUENCE(_38cache_vars_49617)){
            _38num_var_49616 = SEQ_PTR(_38cache_vars_49617)->length;
    }
    else {
        _38num_var_49616 = 1;
    }

    /** 		cache_complete &= 0*/
    Append(&_38cache_complete_49623, _38cache_complete_49623, 0);

    /** 		cache_delims &= 0*/
    Append(&_38cache_delims_49624, _38cache_delims_49624, 0);

    /** 		return 0*/
    DeRefDS(_env_49639);
    DeRefDSi(_inc_path_49640);
    return 0;
    goto L2; // [91] 456
L1: 

    /** 		if compare(inc_path,cache_strings[num_var]) then*/
    _2 = (int)SEQ_PTR(_38cache_strings_49618);
    _25923 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
    if (IS_ATOM_INT(_inc_path_49640) && IS_ATOM_INT(_25923)){
        _25924 = (_inc_path_49640 < _25923) ? -1 : (_inc_path_49640 > _25923);
    }
    else{
        _25924 = compare(_inc_path_49640, _25923);
    }
    _25923 = NOVALUE;
    if (_25924 == 0)
    {
        _25924 = NOVALUE;
        goto L3; // [108] 455
    }
    else{
        _25924 = NOVALUE;
    }

    /** 			cache_strings[num_var] = inc_path*/
    RefDS(_inc_path_49640);
    _2 = (int)SEQ_PTR(_38cache_strings_49618);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38cache_strings_49618 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
    _1 = *(int *)_2;
    *(int *)_2 = _inc_path_49640;
    DeRefDS(_1);

    /** 			cache_complete[num_var] = 0*/
    _2 = (int)SEQ_PTR(_38cache_complete_49623);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38cache_complete_49623 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
    *(int *)_2 = 0;

    /** 			if match(cache_strings[num_var],inc_path)!=1 then -- try to salvage what we can*/
    _2 = (int)SEQ_PTR(_38cache_strings_49618);
    _25925 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
    _25926 = e_match_from(_25925, _inc_path_49640, 1);
    _25925 = NOVALUE;
    if (_25926 == 1)
    goto L4; // [146] 454

    /** 				pos = -1*/
    _pos_49642 = -1;

    /** 				for i=1 to length(cache_strings[num_var]) do*/
    _2 = (int)SEQ_PTR(_38cache_strings_49618);
    _25928 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
    if (IS_SEQUENCE(_25928)){
            _25929 = SEQ_PTR(_25928)->length;
    }
    else {
        _25929 = 1;
    }
    _25928 = NOVALUE;
    {
        int _i_49663;
        _i_49663 = 1;
L5: 
        if (_i_49663 > _25929){
            goto L6; // [168] 453
        }

        /** 					if cache_ends[num_var][i] > length(inc_path) or */
        _2 = (int)SEQ_PTR(_38cache_ends_49621);
        _25930 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        _2 = (int)SEQ_PTR(_25930);
        _25931 = (int)*(((s1_ptr)_2)->base + _i_49663);
        _25930 = NOVALUE;
        if (IS_SEQUENCE(_inc_path_49640)){
                _25932 = SEQ_PTR(_inc_path_49640)->length;
        }
        else {
            _25932 = 1;
        }
        if (IS_ATOM_INT(_25931)) {
            _25933 = (_25931 > _25932);
        }
        else {
            _25933 = binary_op(GREATER, _25931, _25932);
        }
        _25931 = NOVALUE;
        _25932 = NOVALUE;
        if (IS_ATOM_INT(_25933)) {
            if (_25933 != 0) {
                goto L7; // [196] 250
            }
        }
        else {
            if (DBL_PTR(_25933)->dbl != 0.0) {
                goto L7; // [196] 250
            }
        }
        _2 = (int)SEQ_PTR(_38cache_substrings_49619);
        _25935 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        _2 = (int)SEQ_PTR(_25935);
        _25936 = (int)*(((s1_ptr)_2)->base + _i_49663);
        _25935 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_starts_49620);
        _25937 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        _2 = (int)SEQ_PTR(_25937);
        _25938 = (int)*(((s1_ptr)_2)->base + _i_49663);
        _25937 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_ends_49621);
        _25939 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        _2 = (int)SEQ_PTR(_25939);
        _25940 = (int)*(((s1_ptr)_2)->base + _i_49663);
        _25939 = NOVALUE;
        rhs_slice_target = (object_ptr)&_25941;
        RHS_Slice(_inc_path_49640, _25938, _25940);
        if (IS_ATOM_INT(_25936) && IS_ATOM_INT(_25941)){
            _25942 = (_25936 < _25941) ? -1 : (_25936 > _25941);
        }
        else{
            _25942 = compare(_25936, _25941);
        }
        _25936 = NOVALUE;
        DeRefDS(_25941);
        _25941 = NOVALUE;
        if (_25942 == 0)
        {
            _25942 = NOVALUE;
            goto L8; // [246] 261
        }
        else{
            _25942 = NOVALUE;
        }
L7: 

        /** 						pos = i-1*/
        _pos_49642 = _i_49663 - 1;

        /** 						exit*/
        goto L6; // [258] 453
L8: 

        /** 					if pos = 0 then*/
        if (_pos_49642 != 0)
        goto L9; // [263] 276

        /** 						return 0*/
        DeRefDS(_env_49639);
        DeRefDSi(_inc_path_49640);
        _25928 = NOVALUE;
        DeRef(_25933);
        _25933 = NOVALUE;
        _25938 = NOVALUE;
        _25940 = NOVALUE;
        return 0;
        goto LA; // [273] 446
L9: 

        /** 					elsif pos >0 then -- crop cache data*/
        if (_pos_49642 <= 0)
        goto LB; // [278] 445

        /** 						cache_substrings[num_var] = cache_substrings[num_var][1..pos]*/
        _2 = (int)SEQ_PTR(_38cache_substrings_49619);
        _25946 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        rhs_slice_target = (object_ptr)&_25947;
        RHS_Slice(_25946, 1, _pos_49642);
        _25946 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_substrings_49619);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_substrings_49619 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        _1 = *(int *)_2;
        *(int *)_2 = _25947;
        if( _1 != _25947 ){
            DeRefDS(_1);
        }
        _25947 = NOVALUE;

        /** 						cache_starts[num_var] = cache_starts[num_var][1..pos]*/
        _2 = (int)SEQ_PTR(_38cache_starts_49620);
        _25948 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        rhs_slice_target = (object_ptr)&_25949;
        RHS_Slice(_25948, 1, _pos_49642);
        _25948 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_starts_49620);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_starts_49620 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        _1 = *(int *)_2;
        *(int *)_2 = _25949;
        if( _1 != _25949 ){
            DeRef(_1);
        }
        _25949 = NOVALUE;

        /** 						cache_ends[num_var] = cache_ends[num_var][1..pos]*/
        _2 = (int)SEQ_PTR(_38cache_ends_49621);
        _25950 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        rhs_slice_target = (object_ptr)&_25951;
        RHS_Slice(_25950, 1, _pos_49642);
        _25950 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_ends_49621);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_ends_49621 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        _1 = *(int *)_2;
        *(int *)_2 = _25951;
        if( _1 != _25951 ){
            DeRef(_1);
        }
        _25951 = NOVALUE;

        /** 						ifdef WINDOWS then*/

        /** 							cache_converted[num_var] = cache_converted[num_var][1..pos]*/
        _2 = (int)SEQ_PTR(_38cache_converted_49622);
        _25952 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        rhs_slice_target = (object_ptr)&_25953;
        RHS_Slice(_25952, 1, _pos_49642);
        _25952 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_converted_49622);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_converted_49622 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        _1 = *(int *)_2;
        *(int *)_2 = _25953;
        if( _1 != _25953 ){
            DeRef(_1);
        }
        _25953 = NOVALUE;

        /** 						delim = cache_ends[num_var][$]+1*/
        _2 = (int)SEQ_PTR(_38cache_ends_49621);
        _25954 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        if (IS_SEQUENCE(_25954)){
                _25955 = SEQ_PTR(_25954)->length;
        }
        else {
            _25955 = 1;
        }
        _2 = (int)SEQ_PTR(_25954);
        _25956 = (int)*(((s1_ptr)_2)->base + _25955);
        _25954 = NOVALUE;
        if (IS_ATOM_INT(_25956)) {
            _delim_49641 = _25956 + 1;
        }
        else
        { // coercing _delim_49641 to an integer 1
            _delim_49641 = 1+(long)(DBL_PTR(_25956)->dbl);
            if( !IS_ATOM_INT(_delim_49641) ){
                _delim_49641 = (object)DBL_PTR(_delim_49641)->dbl;
            }
        }
        _25956 = NOVALUE;

        /** 						while delim <= length(inc_path) and delim != PATH_SEPARATOR do*/
LC: 
        if (IS_SEQUENCE(_inc_path_49640)){
                _25958 = SEQ_PTR(_inc_path_49640)->length;
        }
        else {
            _25958 = 1;
        }
        _25959 = (_delim_49641 <= _25958);
        _25958 = NOVALUE;
        if (_25959 == 0) {
            goto LD; // [409] 434
        }
        _25961 = (_delim_49641 != 59);
        if (_25961 == 0)
        {
            DeRef(_25961);
            _25961 = NOVALUE;
            goto LD; // [420] 434
        }
        else{
            DeRef(_25961);
            _25961 = NOVALUE;
        }

        /** 							delim+=1*/
        _delim_49641 = _delim_49641 + 1;

        /** 						end while*/
        goto LC; // [431] 402
LD: 

        /** 						cache_delims[num_var] = delim*/
        _2 = (int)SEQ_PTR(_38cache_delims_49624);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_delims_49624 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        *(int *)_2 = _delim_49641;
LB: 
LA: 

        /** 				end for*/
        _i_49663 = _i_49663 + 1;
        goto L5; // [448] 175
L6: 
        ;
    }
L4: 
L3: 
L2: 

    /** 	return 1*/
    DeRefDS(_env_49639);
    DeRefDSi(_inc_path_49640);
    _25928 = NOVALUE;
    DeRef(_25959);
    _25959 = NOVALUE;
    DeRef(_25933);
    _25933 = NOVALUE;
    _25938 = NOVALUE;
    _25940 = NOVALUE;
    return 1;
    ;
}


int _38get_conf_dirs()
{
    int _delimiter_49706 = NOVALUE;
    int _dirs_49707 = NOVALUE;
    int _25966 = NOVALUE;
    int _25964 = NOVALUE;
    int _25963 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		delimiter = ';'*/
    _delimiter_49706 = 59;

    /** 	dirs = ""*/
    RefDS(_22037);
    DeRef(_dirs_49707);
    _dirs_49707 = _22037;

    /** 	for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_38config_inc_paths_49625)){
            _25963 = SEQ_PTR(_38config_inc_paths_49625)->length;
    }
    else {
        _25963 = 1;
    }
    {
        int _i_49709;
        _i_49709 = 1;
L1: 
        if (_i_49709 > _25963){
            goto L2; // [22] 68
        }

        /** 		dirs &= config_inc_paths[i]*/
        _2 = (int)SEQ_PTR(_38config_inc_paths_49625);
        _25964 = (int)*(((s1_ptr)_2)->base + _i_49709);
        Concat((object_ptr)&_dirs_49707, _dirs_49707, _25964);
        _25964 = NOVALUE;

        /** 		if i != length(config_inc_paths) then*/
        if (IS_SEQUENCE(_38config_inc_paths_49625)){
                _25966 = SEQ_PTR(_38config_inc_paths_49625)->length;
        }
        else {
            _25966 = 1;
        }
        if (_i_49709 == _25966)
        goto L3; // [48] 61

        /** 			dirs &= delimiter*/
        Append(&_dirs_49707, _dirs_49707, _delimiter_49706);
L3: 

        /** 	end for*/
        _i_49709 = _i_49709 + 1;
        goto L1; // [63] 29
L2: 
        ;
    }

    /** 	return dirs*/
    return _dirs_49707;
    ;
}


int _38strip_file_from_path(int _full_path_49719)
{
    int _25972 = NOVALUE;
    int _25970 = NOVALUE;
    int _25969 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length(full_path) to 1 by -1 do*/
    if (IS_SEQUENCE(_full_path_49719)){
            _25969 = SEQ_PTR(_full_path_49719)->length;
    }
    else {
        _25969 = 1;
    }
    {
        int _i_49721;
        _i_49721 = _25969;
L1: 
        if (_i_49721 < 1){
            goto L2; // [8] 46
        }

        /** 		if full_path[i] = SLASH then*/
        _2 = (int)SEQ_PTR(_full_path_49719);
        _25970 = (int)*(((s1_ptr)_2)->base + _i_49721);
        if (binary_op_a(NOTEQ, _25970, 92)){
            _25970 = NOVALUE;
            goto L3; // [23] 39
        }
        _25970 = NOVALUE;

        /** 			return full_path[1..i]*/
        rhs_slice_target = (object_ptr)&_25972;
        RHS_Slice(_full_path_49719, 1, _i_49721);
        DeRefDS(_full_path_49719);
        return _25972;
L3: 

        /** 	end for*/
        _i_49721 = _i_49721 + -1;
        goto L1; // [41] 15
L2: 
        ;
    }

    /** 	return ""*/
    RefDS(_22037);
    DeRefDS(_full_path_49719);
    DeRef(_25972);
    _25972 = NOVALUE;
    return _22037;
    ;
}


int _38expand_path(int _path_49730, int _prefix_49731)
{
    int _absolute_49732 = NOVALUE;
    int _25987 = NOVALUE;
    int _25986 = NOVALUE;
    int _25985 = NOVALUE;
    int _25984 = NOVALUE;
    int _25983 = NOVALUE;
    int _25982 = NOVALUE;
    int _25978 = NOVALUE;
    int _25977 = NOVALUE;
    int _25976 = NOVALUE;
    int _25973 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(path) then*/
    if (IS_SEQUENCE(_path_49730)){
            _25973 = SEQ_PTR(_path_49730)->length;
    }
    else {
        _25973 = 1;
    }
    if (_25973 != 0)
    goto L1; // [10] 22
    _25973 = NOVALUE;

    /** 		return pwd*/
    RefDS(_38pwd_49628);
    DeRefDS(_path_49730);
    DeRefDS(_prefix_49731);
    return _38pwd_49628;
L1: 

    /** 	ifdef UNIX then*/

    /** 		absolute = find(path[1], SLASH_CHARS) or find(':', path)*/
    _2 = (int)SEQ_PTR(_path_49730);
    _25976 = (int)*(((s1_ptr)_2)->base + 1);
    _25977 = find_from(_25976, _36SLASH_CHARS_14319, 1);
    _25976 = NOVALUE;
    _25978 = find_from(58, _path_49730, 1);
    _absolute_49732 = (_25977 != 0 || _25978 != 0);
    _25977 = NOVALUE;
    _25978 = NOVALUE;

    /** 	if not absolute then*/
    if (_absolute_49732 != 0)
    goto L2; // [50] 64

    /** 		path = prefix & SLASH & path*/
    {
        int concat_list[3];

        concat_list[0] = _path_49730;
        concat_list[1] = 92;
        concat_list[2] = _prefix_49731;
        Concat_N((object_ptr)&_path_49730, concat_list, 3);
    }
L2: 

    /** 	if length(path) and not find(path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_path_49730)){
            _25982 = SEQ_PTR(_path_49730)->length;
    }
    else {
        _25982 = 1;
    }
    if (_25982 == 0) {
        goto L3; // [69] 103
    }
    if (IS_SEQUENCE(_path_49730)){
            _25984 = SEQ_PTR(_path_49730)->length;
    }
    else {
        _25984 = 1;
    }
    _2 = (int)SEQ_PTR(_path_49730);
    _25985 = (int)*(((s1_ptr)_2)->base + _25984);
    _25986 = find_from(_25985, _36SLASH_CHARS_14319, 1);
    _25985 = NOVALUE;
    _25987 = (_25986 == 0);
    _25986 = NOVALUE;
    if (_25987 == 0)
    {
        DeRef(_25987);
        _25987 = NOVALUE;
        goto L3; // [91] 103
    }
    else{
        DeRef(_25987);
        _25987 = NOVALUE;
    }

    /** 		path &= SLASH*/
    Append(&_path_49730, _path_49730, 92);
L3: 

    /** 	return path*/
    DeRefDS(_prefix_49731);
    return _path_49730;
    ;
}


void _38add_include_directory(int _path_49758)
{
    int _25990 = NOVALUE;
    int _0, _1, _2;
    

    /** 	path = expand_path( path, pwd )*/
    RefDS(_path_49758);
    RefDS(_38pwd_49628);
    _0 = _path_49758;
    _path_49758 = _38expand_path(_path_49758, _38pwd_49628);
    DeRefDS(_0);

    /** 	if not find( path, config_inc_paths ) then*/
    _25990 = find_from(_path_49758, _38config_inc_paths_49625, 1);
    if (_25990 != 0)
    goto L1; // [23] 35
    _25990 = NOVALUE;

    /** 		config_inc_paths = append( config_inc_paths, path )*/
    RefDS(_path_49758);
    Append(&_38config_inc_paths_49625, _38config_inc_paths_49625, _path_49758);
L1: 

    /** end procedure*/
    DeRefDS(_path_49758);
    return;
    ;
}


int _38load_euphoria_config(int _file_49767)
{
    int _fn_49768 = NOVALUE;
    int _in_49769 = NOVALUE;
    int _spos_49770 = NOVALUE;
    int _epos_49771 = NOVALUE;
    int _conf_path_49772 = NOVALUE;
    int _new_args_49773 = NOVALUE;
    int _arg_49774 = NOVALUE;
    int _parm_49775 = NOVALUE;
    int _section_49776 = NOVALUE;
    int _needed_49873 = NOVALUE;
    int _26087 = NOVALUE;
    int _26086 = NOVALUE;
    int _26083 = NOVALUE;
    int _26081 = NOVALUE;
    int _26080 = NOVALUE;
    int _26058 = NOVALUE;
    int _26055 = NOVALUE;
    int _26054 = NOVALUE;
    int _26052 = NOVALUE;
    int _26048 = NOVALUE;
    int _26046 = NOVALUE;
    int _26044 = NOVALUE;
    int _26042 = NOVALUE;
    int _26040 = NOVALUE;
    int _26038 = NOVALUE;
    int _26037 = NOVALUE;
    int _26036 = NOVALUE;
    int _26035 = NOVALUE;
    int _26034 = NOVALUE;
    int _26033 = NOVALUE;
    int _26032 = NOVALUE;
    int _26031 = NOVALUE;
    int _26029 = NOVALUE;
    int _26027 = NOVALUE;
    int _26025 = NOVALUE;
    int _26021 = NOVALUE;
    int _26020 = NOVALUE;
    int _26015 = NOVALUE;
    int _26013 = NOVALUE;
    int _26011 = NOVALUE;
    int _26010 = NOVALUE;
    int _26002 = NOVALUE;
    int _25996 = NOVALUE;
    int _25995 = NOVALUE;
    int _25993 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence new_args = {}*/
    RefDS(_22037);
    DeRef(_new_args_49773);
    _new_args_49773 = _22037;

    /** 	if file_type(file) = FILETYPE_DIRECTORY then*/
    RefDS(_file_49767);
    _25993 = _15file_type(_file_49767);
    if (binary_op_a(NOTEQ, _25993, 2)){
        DeRef(_25993);
        _25993 = NOVALUE;
        goto L1; // [18] 53
    }
    DeRef(_25993);
    _25993 = NOVALUE;

    /** 		if file[$] != SLASH then*/
    if (IS_SEQUENCE(_file_49767)){
            _25995 = SEQ_PTR(_file_49767)->length;
    }
    else {
        _25995 = 1;
    }
    _2 = (int)SEQ_PTR(_file_49767);
    _25996 = (int)*(((s1_ptr)_2)->base + _25995);
    if (binary_op_a(EQUALS, _25996, 92)){
        _25996 = NOVALUE;
        goto L2; // [33] 46
    }
    _25996 = NOVALUE;

    /** 			file &= SLASH*/
    Append(&_file_49767, _file_49767, 92);
L2: 

    /** 		file &= "eu.cfg"*/
    Concat((object_ptr)&_file_49767, _file_49767, _25999);
L1: 

    /** 	conf_path = canonical_path( file,,CORRECT )*/
    RefDS(_file_49767);
    _0 = _conf_path_49772;
    _conf_path_49772 = _15canonical_path(_file_49767, 0, 2);
    DeRef(_0);

    /** 	if find(conf_path, seen_conf) != 0 then*/
    _26002 = find_from(_conf_path_49772, _38seen_conf_49764, 1);
    if (_26002 == 0)
    goto L3; // [74] 85

    /** 		return {}*/
    RefDS(_22037);
    DeRefDS(_file_49767);
    DeRefi(_in_49769);
    DeRefDS(_conf_path_49772);
    DeRef(_new_args_49773);
    DeRefi(_arg_49774);
    DeRefi(_parm_49775);
    DeRef(_section_49776);
    return _22037;
L3: 

    /** 	seen_conf = append(seen_conf, conf_path)*/
    RefDS(_conf_path_49772);
    Append(&_38seen_conf_49764, _38seen_conf_49764, _conf_path_49772);

    /** 	section = "all"*/
    RefDS(_26005);
    DeRef(_section_49776);
    _section_49776 = _26005;

    /** 	fn = open( conf_path, "r" )*/
    _fn_49768 = EOpen(_conf_path_49772, _26006, 0);

    /** 	if fn = -1 then return {} end if*/
    if (_fn_49768 != -1)
    goto L4; // [109] 118
    RefDS(_22037);
    DeRefDS(_file_49767);
    DeRefi(_in_49769);
    DeRefDS(_conf_path_49772);
    DeRef(_new_args_49773);
    DeRefi(_arg_49774);
    DeRefi(_parm_49775);
    DeRefDSi(_section_49776);
    return _22037;
L4: 

    /** 	in = gets( fn )*/
    DeRefi(_in_49769);
    _in_49769 = EGets(_fn_49768);

    /** 	while sequence( in ) do*/
L5: 
    _26010 = IS_SEQUENCE(_in_49769);
    if (_26010 == 0)
    {
        _26010 = NOVALUE;
        goto L6; // [131] 768
    }
    else{
        _26010 = NOVALUE;
    }

    /** 		spos = 1*/
    _spos_49770 = 1;

    /** 		while spos <= length(in) do*/
L7: 
    if (IS_SEQUENCE(_in_49769)){
            _26011 = SEQ_PTR(_in_49769)->length;
    }
    else {
        _26011 = 1;
    }
    if (_spos_49770 > _26011)
    goto L8; // [147] 182

    /** 			if find( in[spos], "\n\r \t" ) = 0 then*/
    _2 = (int)SEQ_PTR(_in_49769);
    _26013 = (int)*(((s1_ptr)_2)->base + _spos_49770);
    _26015 = find_from(_26013, _26014, 1);
    _26013 = NOVALUE;
    if (_26015 != 0)
    goto L9; // [162] 171

    /** 				exit*/
    goto L8; // [168] 182
L9: 

    /** 			spos += 1*/
    _spos_49770 = _spos_49770 + 1;

    /** 		end while*/
    goto L7; // [179] 144
L8: 

    /** 		epos = length(in)*/
    if (IS_SEQUENCE(_in_49769)){
            _epos_49771 = SEQ_PTR(_in_49769)->length;
    }
    else {
        _epos_49771 = 1;
    }

    /** 		while epos >= spos do*/
LA: 
    if (_epos_49771 < _spos_49770)
    goto LB; // [192] 227

    /** 			if find( in[epos], "\n\r \t" ) = 0 then*/
    _2 = (int)SEQ_PTR(_in_49769);
    _26020 = (int)*(((s1_ptr)_2)->base + _epos_49771);
    _26021 = find_from(_26020, _26014, 1);
    _26020 = NOVALUE;
    if (_26021 != 0)
    goto LC; // [207] 216

    /** 				exit*/
    goto LB; // [213] 227
LC: 

    /** 			epos -= 1*/
    _epos_49771 = _epos_49771 - 1;

    /** 		end while*/
    goto LA; // [224] 192
LB: 

    /** 		in = in[spos .. epos]		*/
    rhs_slice_target = (object_ptr)&_in_49769;
    RHS_Slice(_in_49769, _spos_49770, _epos_49771);

    /** 		arg = ""*/
    RefDS(_22037);
    DeRefi(_arg_49774);
    _arg_49774 = _22037;

    /** 		parm = ""*/
    RefDS(_22037);
    DeRefi(_parm_49775);
    _parm_49775 = _22037;

    /** 		if length(in) > 0 then*/
    if (IS_SEQUENCE(_in_49769)){
            _26025 = SEQ_PTR(_in_49769)->length;
    }
    else {
        _26025 = 1;
    }
    if (_26025 <= 0)
    goto LD; // [253] 477

    /** 			if in[1] = '[' then*/
    _2 = (int)SEQ_PTR(_in_49769);
    _26027 = (int)*(((s1_ptr)_2)->base + 1);
    if (_26027 != 91)
    goto LE; // [263] 354

    /** 				section = in[2..$]*/
    if (IS_SEQUENCE(_in_49769)){
            _26029 = SEQ_PTR(_in_49769)->length;
    }
    else {
        _26029 = 1;
    }
    rhs_slice_target = (object_ptr)&_section_49776;
    RHS_Slice(_in_49769, 2, _26029);

    /** 				if length(section) > 0 and section[$] = ']' then*/
    if (IS_SEQUENCE(_section_49776)){
            _26031 = SEQ_PTR(_section_49776)->length;
    }
    else {
        _26031 = 1;
    }
    _26032 = (_26031 > 0);
    _26031 = NOVALUE;
    if (_26032 == 0) {
        goto LF; // [286] 320
    }
    if (IS_SEQUENCE(_section_49776)){
            _26034 = SEQ_PTR(_section_49776)->length;
    }
    else {
        _26034 = 1;
    }
    _2 = (int)SEQ_PTR(_section_49776);
    _26035 = (int)*(((s1_ptr)_2)->base + _26034);
    _26036 = (_26035 == 93);
    _26035 = NOVALUE;
    if (_26036 == 0)
    {
        DeRef(_26036);
        _26036 = NOVALUE;
        goto LF; // [302] 320
    }
    else{
        DeRef(_26036);
        _26036 = NOVALUE;
    }

    /** 					section = section[1..$-1]*/
    if (IS_SEQUENCE(_section_49776)){
            _26037 = SEQ_PTR(_section_49776)->length;
    }
    else {
        _26037 = 1;
    }
    _26038 = _26037 - 1;
    _26037 = NOVALUE;
    rhs_slice_target = (object_ptr)&_section_49776;
    RHS_Slice(_section_49776, 1, _26038);
LF: 

    /** 				section = lower(trim(section))*/
    RefDS(_section_49776);
    RefDS(_4538);
    _26040 = _12trim(_section_49776, _4538, 0);
    _0 = _section_49776;
    _section_49776 = _12lower(_26040);
    DeRefDS(_0);
    _26040 = NOVALUE;

    /** 				if length(section) = 0 then*/
    if (IS_SEQUENCE(_section_49776)){
            _26042 = SEQ_PTR(_section_49776)->length;
    }
    else {
        _26042 = 1;
    }
    if (_26042 != 0)
    goto L10; // [339] 476

    /** 					section = "all"*/
    RefDS(_26005);
    DeRefDS(_section_49776);
    _section_49776 = _26005;
    goto L10; // [351] 476
LE: 

    /** 			elsif length(in) > 2 then*/
    if (IS_SEQUENCE(_in_49769)){
            _26044 = SEQ_PTR(_in_49769)->length;
    }
    else {
        _26044 = 1;
    }
    if (_26044 <= 2)
    goto L11; // [359] 461

    /** 				if in[1] = '-' then*/
    _2 = (int)SEQ_PTR(_in_49769);
    _26046 = (int)*(((s1_ptr)_2)->base + 1);
    if (_26046 != 45)
    goto L12; // [369] 443

    /** 					if in[2] != '-' then*/
    _2 = (int)SEQ_PTR(_in_49769);
    _26048 = (int)*(((s1_ptr)_2)->base + 2);
    if (_26048 == 45)
    goto L10; // [379] 476

    /** 						spos = find(' ', in)*/
    _spos_49770 = find_from(32, _in_49769, 1);

    /** 						if spos = 0 then*/
    if (_spos_49770 != 0)
    goto L13; // [392] 413

    /** 							arg = in*/
    Ref(_in_49769);
    DeRefi(_arg_49774);
    _arg_49774 = _in_49769;

    /** 							parm = ""*/
    RefDS(_22037);
    DeRefi(_parm_49775);
    _parm_49775 = _22037;
    goto L10; // [410] 476
L13: 

    /** 							arg = in[1..spos - 1]*/
    _26052 = _spos_49770 - 1;
    rhs_slice_target = (object_ptr)&_arg_49774;
    RHS_Slice(_in_49769, 1, _26052);

    /** 							parm = in[spos + 1 .. $]*/
    _26054 = _spos_49770 + 1;
    if (_26054 > MAXINT){
        _26054 = NewDouble((double)_26054);
    }
    if (IS_SEQUENCE(_in_49769)){
            _26055 = SEQ_PTR(_in_49769)->length;
    }
    else {
        _26055 = 1;
    }
    rhs_slice_target = (object_ptr)&_parm_49775;
    RHS_Slice(_in_49769, _26054, _26055);
    goto L10; // [440] 476
L12: 

    /** 					arg = "-i"*/
    RefDS(_26057);
    DeRefi(_arg_49774);
    _arg_49774 = _26057;

    /** 					parm = in*/
    Ref(_in_49769);
    DeRefi(_parm_49775);
    _parm_49775 = _in_49769;
    goto L10; // [458] 476
L11: 

    /** 				arg = "-i"*/
    RefDS(_26057);
    DeRefi(_arg_49774);
    _arg_49774 = _26057;

    /** 				parm = in*/
    Ref(_in_49769);
    DeRefi(_parm_49775);
    _parm_49775 = _in_49769;
L10: 
LD: 

    /** 		if length(arg) > 0 then*/
    if (IS_SEQUENCE(_arg_49774)){
            _26058 = SEQ_PTR(_arg_49774)->length;
    }
    else {
        _26058 = 1;
    }
    if (_26058 <= 0)
    goto L14; // [482] 756

    /** 			integer needed = 0*/
    _needed_49873 = 0;

    /** 			switch section do*/
    _1 = find(_section_49776, _26060);
    switch ( _1 ){ 

        /** 				case "all" then*/
        case 1:

        /** 					needed = 1*/
        _needed_49873 = 1;
        goto L15; // [507] 691

        /** 				case "windows" then*/
        case 2:

        /** 					needed = TWINDOWS*/
        _needed_49873 = _36TWINDOWS_14305;
        goto L15; // [522] 691

        /** 				case "unix" then*/
        case 3:

        /** 					needed = TUNIX*/
        _needed_49873 = 0;
        goto L15; // [537] 691

        /** 				case "translate" then*/
        case 4:

        /** 					needed = TRANSLATE*/
        _needed_49873 = _26TRANSLATE_11619;
        goto L15; // [552] 691

        /** 				case "translate:windows" then*/
        case 5:

        /** 					needed = TRANSLATE and TWINDOWS*/
        _needed_49873 = (_26TRANSLATE_11619 != 0 && _36TWINDOWS_14305 != 0);
        goto L15; // [570] 691

        /** 				case "translate:unix" then*/
        case 6:

        /** 					needed = TRANSLATE and TUNIX*/
        _needed_49873 = (_26TRANSLATE_11619 != 0 && 0 != 0);
        goto L15; // [588] 691

        /** 				case "interpret" then*/
        case 7:

        /** 					needed = INTERPRET*/
        _needed_49873 = _26INTERPRET_11616;
        goto L15; // [603] 691

        /** 				case "interpret:windows" then*/
        case 8:

        /** 					needed = INTERPRET and TWINDOWS*/
        _needed_49873 = (_26INTERPRET_11616 != 0 && _36TWINDOWS_14305 != 0);
        goto L15; // [621] 691

        /** 				case "interpret:unix" then*/
        case 9:

        /** 					needed = INTERPRET and TUNIX*/
        _needed_49873 = (_26INTERPRET_11616 != 0 && 0 != 0);
        goto L15; // [639] 691

        /** 				case "bind" then*/
        case 10:

        /** 					needed = BIND*/
        _needed_49873 = _26BIND_11622;
        goto L15; // [654] 691

        /** 				case "bind:windows" then*/
        case 11:

        /** 					needed = BIND and TWINDOWS*/
        _needed_49873 = (_26BIND_11622 != 0 && _36TWINDOWS_14305 != 0);
        goto L15; // [672] 691

        /** 				case "bind:unix" then*/
        case 12:

        /** 					needed = BIND and TUNIX*/
        _needed_49873 = (_26BIND_11622 != 0 && 0 != 0);
    ;}L15: 

    /** 			if needed then*/
    if (_needed_49873 == 0)
    {
        goto L16; // [693] 755
    }
    else{
    }

    /** 				if equal(arg, "-c") then*/
    if (_arg_49774 == _26079)
    _26080 = 1;
    else if (IS_ATOM_INT(_arg_49774) && IS_ATOM_INT(_26079))
    _26080 = 0;
    else
    _26080 = (compare(_arg_49774, _26079) == 0);
    if (_26080 == 0)
    {
        _26080 = NOVALUE;
        goto L17; // [702] 728
    }
    else{
        _26080 = NOVALUE;
    }

    /** 					if length(parm) > 0 then*/
    if (IS_SEQUENCE(_parm_49775)){
            _26081 = SEQ_PTR(_parm_49775)->length;
    }
    else {
        _26081 = 1;
    }
    if (_26081 <= 0)
    goto L18; // [710] 754

    /** 						new_args &= load_euphoria_config(parm)*/
    RefDS(_parm_49775);
    _26083 = _38load_euphoria_config(_parm_49775);
    if (IS_SEQUENCE(_new_args_49773) && IS_ATOM(_26083)) {
        Ref(_26083);
        Append(&_new_args_49773, _new_args_49773, _26083);
    }
    else if (IS_ATOM(_new_args_49773) && IS_SEQUENCE(_26083)) {
    }
    else {
        Concat((object_ptr)&_new_args_49773, _new_args_49773, _26083);
    }
    DeRef(_26083);
    _26083 = NOVALUE;
    goto L18; // [725] 754
L17: 

    /** 					new_args = append(new_args, arg)*/
    RefDS(_arg_49774);
    Append(&_new_args_49773, _new_args_49773, _arg_49774);

    /** 					if length(parm > 0) then*/
    _26086 = binary_op(GREATER, _parm_49775, 0);
    if (IS_SEQUENCE(_26086)){
            _26087 = SEQ_PTR(_26086)->length;
    }
    else {
        _26087 = 1;
    }
    DeRefDS(_26086);
    _26086 = NOVALUE;
    if (_26087 == 0)
    {
        _26087 = NOVALUE;
        goto L19; // [743] 753
    }
    else{
        _26087 = NOVALUE;
    }

    /** 						new_args = append(new_args, parm)*/
    RefDS(_parm_49775);
    Append(&_new_args_49773, _new_args_49773, _parm_49775);
L19: 
L18: 
L16: 
L14: 

    /** 		in = gets( fn )*/
    DeRefi(_in_49769);
    _in_49769 = EGets(_fn_49768);

    /** 	end while*/
    goto L5; // [765] 128
L6: 

    /** 	close(fn)*/
    EClose(_fn_49768);

    /** 	return new_args*/
    DeRefDS(_file_49767);
    DeRefi(_in_49769);
    DeRef(_conf_path_49772);
    DeRefi(_arg_49774);
    DeRefi(_parm_49775);
    DeRef(_section_49776);
    _26027 = NOVALUE;
    DeRef(_26032);
    _26032 = NOVALUE;
    DeRef(_26038);
    _26038 = NOVALUE;
    _26046 = NOVALUE;
    _26048 = NOVALUE;
    DeRef(_26052);
    _26052 = NOVALUE;
    DeRef(_26054);
    _26054 = NOVALUE;
    _26086 = NOVALUE;
    return _new_args_49773;
    ;
}


int _38GetDefaultArgs(int _user_files_49940)
{
    int _env_49941 = NOVALUE;
    int _default_args_49942 = NOVALUE;
    int _conf_file_49943 = NOVALUE;
    int _cmd_options_49945 = NOVALUE;
    int _user_config_49951 = NOVALUE;
    int _26132 = NOVALUE;
    int _26131 = NOVALUE;
    int _26130 = NOVALUE;
    int _26127 = NOVALUE;
    int _26126 = NOVALUE;
    int _26125 = NOVALUE;
    int _26123 = NOVALUE;
    int _26119 = NOVALUE;
    int _26118 = NOVALUE;
    int _26117 = NOVALUE;
    int _26116 = NOVALUE;
    int _26112 = NOVALUE;
    int _26111 = NOVALUE;
    int _26110 = NOVALUE;
    int _26108 = NOVALUE;
    int _26102 = NOVALUE;
    int _26101 = NOVALUE;
    int _26099 = NOVALUE;
    int _26097 = NOVALUE;
    int _26096 = NOVALUE;
    int _26092 = NOVALUE;
    int _26091 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence default_args = {}*/
    RefDS(_22037);
    DeRef(_default_args_49942);
    _default_args_49942 = _22037;

    /** 	sequence conf_file = "eu.cfg"*/
    RefDS(_25999);
    DeRefi(_conf_file_49943);
    _conf_file_49943 = _25999;

    /** 	if loaded_config_inc_paths then return "" end if*/
    if (_38loaded_config_inc_paths_49626 == 0)
    {
        goto L1; // [21] 29
    }
    else{
    }
    RefDS(_22037);
    DeRefDS(_user_files_49940);
    DeRef(_env_49941);
    DeRefDS(_default_args_49942);
    DeRefDSi(_conf_file_49943);
    DeRef(_cmd_options_49945);
    return _22037;
L1: 

    /** 	loaded_config_inc_paths = 1*/
    _38loaded_config_inc_paths_49626 = 1;

    /** 	sequence cmd_options = get_options()*/
    _0 = _cmd_options_49945;
    _cmd_options_49945 = _39get_options();
    DeRef(_0);

    /** 	default_args = {}*/
    RefDS(_22037);
    DeRef(_default_args_49942);
    _default_args_49942 = _22037;

    /** 	for i = 1 to length( user_files ) do*/
    if (IS_SEQUENCE(_user_files_49940)){
            _26091 = SEQ_PTR(_user_files_49940)->length;
    }
    else {
        _26091 = 1;
    }
    {
        int _i_49949;
        _i_49949 = 1;
L2: 
        if (_i_49949 > _26091){
            goto L3; // [53] 92
        }

        /** 		sequence user_config = load_euphoria_config( user_files[i] )*/
        _2 = (int)SEQ_PTR(_user_files_49940);
        _26092 = (int)*(((s1_ptr)_2)->base + _i_49949);
        Ref(_26092);
        _0 = _user_config_49951;
        _user_config_49951 = _38load_euphoria_config(_26092);
        DeRef(_0);
        _26092 = NOVALUE;

        /** 		default_args = merge_parameters( user_config, default_args, cmd_options, 1 )*/
        RefDS(_user_config_49951);
        RefDS(_default_args_49942);
        RefDS(_cmd_options_49945);
        _0 = _default_args_49942;
        _default_args_49942 = _39merge_parameters(_user_config_49951, _default_args_49942, _cmd_options_49945, 1);
        DeRefDS(_0);
        DeRefDS(_user_config_49951);
        _user_config_49951 = NOVALUE;

        /** 	end for*/
        _i_49949 = _i_49949 + 1;
        goto L2; // [87] 60
L3: 
        ;
    }

    /** 	default_args = merge_parameters( load_euphoria_config("./" & conf_file), default_args, cmd_options, 1 )*/
    Concat((object_ptr)&_26096, _26095, _conf_file_49943);
    _26097 = _38load_euphoria_config(_26096);
    _26096 = NOVALUE;
    RefDS(_default_args_49942);
    RefDS(_cmd_options_49945);
    _0 = _default_args_49942;
    _default_args_49942 = _39merge_parameters(_26097, _default_args_49942, _cmd_options_49945, 1);
    DeRefDS(_0);
    _26097 = NOVALUE;

    /** 	env = strip_file_from_path( exe_path() )*/
    _26099 = _38exe_path();
    _0 = _env_49941;
    _env_49941 = _38strip_file_from_path(_26099);
    DeRef(_0);
    _26099 = NOVALUE;

    /** 	default_args = merge_parameters( load_euphoria_config( env & conf_file ), default_args, cmd_options, 1 )*/
    if (IS_SEQUENCE(_env_49941) && IS_ATOM(_conf_file_49943)) {
    }
    else if (IS_ATOM(_env_49941) && IS_SEQUENCE(_conf_file_49943)) {
        Ref(_env_49941);
        Prepend(&_26101, _conf_file_49943, _env_49941);
    }
    else {
        Concat((object_ptr)&_26101, _env_49941, _conf_file_49943);
    }
    _26102 = _38load_euphoria_config(_26101);
    _26101 = NOVALUE;
    RefDS(_default_args_49942);
    RefDS(_cmd_options_49945);
    _0 = _default_args_49942;
    _default_args_49942 = _39merge_parameters(_26102, _default_args_49942, _cmd_options_49945, 1);
    DeRefDS(_0);
    _26102 = NOVALUE;

    /** 	ifdef UNIX then*/

    /** 		env = getenv( "ALLUSERSPROFILE" )*/
    DeRef(_env_49941);
    _env_49941 = EGetEnv(_26106);

    /** 		if sequence(env) then*/
    _26108 = IS_SEQUENCE(_env_49941);
    if (_26108 == 0)
    {
        _26108 = NOVALUE;
        goto L4; // [151] 179
    }
    else{
        _26108 = NOVALUE;
    }

    /** 			default_args = merge_parameters( load_euphoria_config( expand_path( "euphoria", env ) & conf_file ), default_args, cmd_options, 1 )*/
    RefDS(_26109);
    Ref(_env_49941);
    _26110 = _38expand_path(_26109, _env_49941);
    if (IS_SEQUENCE(_26110) && IS_ATOM(_conf_file_49943)) {
    }
    else if (IS_ATOM(_26110) && IS_SEQUENCE(_conf_file_49943)) {
        Ref(_26110);
        Prepend(&_26111, _conf_file_49943, _26110);
    }
    else {
        Concat((object_ptr)&_26111, _26110, _conf_file_49943);
        DeRef(_26110);
        _26110 = NOVALUE;
    }
    DeRef(_26110);
    _26110 = NOVALUE;
    _26112 = _38load_euphoria_config(_26111);
    _26111 = NOVALUE;
    RefDS(_default_args_49942);
    RefDS(_cmd_options_49945);
    _0 = _default_args_49942;
    _default_args_49942 = _39merge_parameters(_26112, _default_args_49942, _cmd_options_49945, 1);
    DeRefDS(_0);
    _26112 = NOVALUE;
L4: 

    /** 		env = getenv( "APPDATA" )*/
    DeRef(_env_49941);
    _env_49941 = EGetEnv(_26114);

    /** 		if sequence(env) then*/
    _26116 = IS_SEQUENCE(_env_49941);
    if (_26116 == 0)
    {
        _26116 = NOVALUE;
        goto L5; // [189] 217
    }
    else{
        _26116 = NOVALUE;
    }

    /** 			default_args = merge_parameters( load_euphoria_config( expand_path( "euphoria", env ) & conf_file ), default_args, cmd_options, 1 )*/
    RefDS(_26109);
    Ref(_env_49941);
    _26117 = _38expand_path(_26109, _env_49941);
    if (IS_SEQUENCE(_26117) && IS_ATOM(_conf_file_49943)) {
    }
    else if (IS_ATOM(_26117) && IS_SEQUENCE(_conf_file_49943)) {
        Ref(_26117);
        Prepend(&_26118, _conf_file_49943, _26117);
    }
    else {
        Concat((object_ptr)&_26118, _26117, _conf_file_49943);
        DeRef(_26117);
        _26117 = NOVALUE;
    }
    DeRef(_26117);
    _26117 = NOVALUE;
    _26119 = _38load_euphoria_config(_26118);
    _26118 = NOVALUE;
    RefDS(_default_args_49942);
    RefDS(_cmd_options_49945);
    _0 = _default_args_49942;
    _default_args_49942 = _39merge_parameters(_26119, _default_args_49942, _cmd_options_49945, 1);
    DeRefDS(_0);
    _26119 = NOVALUE;
L5: 

    /** 		env = getenv( "HOMEPATH" )*/
    DeRef(_env_49941);
    _env_49941 = EGetEnv(_26121);

    /** 		if sequence(env) then*/
    _26123 = IS_SEQUENCE(_env_49941);
    if (_26123 == 0)
    {
        _26123 = NOVALUE;
        goto L6; // [227] 256
    }
    else{
        _26123 = NOVALUE;
    }

    /** 			default_args = merge_parameters( load_euphoria_config( getenv( "HOMEDRIVE" ) & env & "\\" & conf_file ), default_args, cmd_options, 1 )*/
    _26125 = EGetEnv(_26124);
    {
        int concat_list[4];

        concat_list[0] = _conf_file_49943;
        concat_list[1] = _23592;
        concat_list[2] = _env_49941;
        concat_list[3] = _26125;
        Concat_N((object_ptr)&_26126, concat_list, 4);
    }
    DeRef(_26125);
    _26125 = NOVALUE;
    _26127 = _38load_euphoria_config(_26126);
    _26126 = NOVALUE;
    RefDS(_default_args_49942);
    RefDS(_cmd_options_49945);
    _0 = _default_args_49942;
    _default_args_49942 = _39merge_parameters(_26127, _default_args_49942, _cmd_options_49945, 1);
    DeRefDS(_0);
    _26127 = NOVALUE;
L6: 

    /** 	env = get_eudir()*/
    _0 = _env_49941;
    _env_49941 = _27get_eudir();
    DeRef(_0);

    /** 	if sequence(env) then*/
    _26130 = IS_SEQUENCE(_env_49941);
    if (_26130 == 0)
    {
        _26130 = NOVALUE;
        goto L7; // [266] 291
    }
    else{
        _26130 = NOVALUE;
    }

    /** 		default_args = merge_parameters( load_euphoria_config(env & "/" & conf_file), default_args, cmd_options, 1 )*/
    {
        int concat_list[3];

        concat_list[0] = _conf_file_49943;
        concat_list[1] = _23480;
        concat_list[2] = _env_49941;
        Concat_N((object_ptr)&_26131, concat_list, 3);
    }
    _26132 = _38load_euphoria_config(_26131);
    _26131 = NOVALUE;
    RefDS(_default_args_49942);
    RefDS(_cmd_options_49945);
    _0 = _default_args_49942;
    _default_args_49942 = _39merge_parameters(_26132, _default_args_49942, _cmd_options_49945, 1);
    DeRefDS(_0);
    _26132 = NOVALUE;
L7: 

    /** 	return default_args*/
    DeRefDS(_user_files_49940);
    DeRef(_env_49941);
    DeRefi(_conf_file_49943);
    DeRef(_cmd_options_49945);
    return _default_args_49942;
    ;
}


int _38ConfPath(int _file_name_50008)
{
    int _file_path_50009 = NOVALUE;
    int _try_50010 = NOVALUE;
    int _26139 = NOVALUE;
    int _26135 = NOVALUE;
    int _26134 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_38config_inc_paths_49625)){
            _26134 = SEQ_PTR(_38config_inc_paths_49625)->length;
    }
    else {
        _26134 = 1;
    }
    {
        int _i_50012;
        _i_50012 = 1;
L1: 
        if (_i_50012 > _26134){
            goto L2; // [10] 60
        }

        /** 		file_path = config_inc_paths[i] & file_name*/
        _2 = (int)SEQ_PTR(_38config_inc_paths_49625);
        _26135 = (int)*(((s1_ptr)_2)->base + _i_50012);
        Concat((object_ptr)&_file_path_50009, _26135, _file_name_50008);
        _26135 = NOVALUE;
        _26135 = NOVALUE;

        /** 		try = open( file_path, "r" )*/
        _try_50010 = EOpen(_file_path_50009, _26006, 0);

        /** 		if try != -1 then*/
        if (_try_50010 == -1)
        goto L3; // [38] 53

        /** 			return {file_path, try}*/
        RefDS(_file_path_50009);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _file_path_50009;
        ((int *)_2)[2] = _try_50010;
        _26139 = MAKE_SEQ(_1);
        DeRefDS(_file_name_50008);
        DeRefDS(_file_path_50009);
        return _26139;
L3: 

        /** 	end for*/
        _i_50012 = _i_50012 + 1;
        goto L1; // [55] 17
L2: 
        ;
    }

    /** 	return -1*/
    DeRefDS(_file_name_50008);
    DeRef(_file_path_50009);
    DeRef(_26139);
    _26139 = NOVALUE;
    return -1;
    ;
}


int _38ScanPath(int _file_name_50022, int _env_50023, int _flag_50024)
{
    int _inc_path_50025 = NOVALUE;
    int _full_path_50026 = NOVALUE;
    int _file_path_50027 = NOVALUE;
    int _strings_50028 = NOVALUE;
    int _end_path_50029 = NOVALUE;
    int _start_path_50030 = NOVALUE;
    int _try_50031 = NOVALUE;
    int _use_cache_50032 = NOVALUE;
    int _pos_50033 = NOVALUE;
    int _26217 = NOVALUE;
    int _26216 = NOVALUE;
    int _26215 = NOVALUE;
    int _26214 = NOVALUE;
    int _26213 = NOVALUE;
    int _26212 = NOVALUE;
    int _26211 = NOVALUE;
    int _26210 = NOVALUE;
    int _26209 = NOVALUE;
    int _26208 = NOVALUE;
    int _26207 = NOVALUE;
    int _26206 = NOVALUE;
    int _26205 = NOVALUE;
    int _26204 = NOVALUE;
    int _26203 = NOVALUE;
    int _26202 = NOVALUE;
    int _26197 = NOVALUE;
    int _26196 = NOVALUE;
    int _26195 = NOVALUE;
    int _26194 = NOVALUE;
    int _26193 = NOVALUE;
    int _26189 = NOVALUE;
    int _26188 = NOVALUE;
    int _26187 = NOVALUE;
    int _26186 = NOVALUE;
    int _26185 = NOVALUE;
    int _26184 = NOVALUE;
    int _26182 = NOVALUE;
    int _26180 = NOVALUE;
    int _26179 = NOVALUE;
    int _26177 = NOVALUE;
    int _26176 = NOVALUE;
    int _26175 = NOVALUE;
    int _26172 = NOVALUE;
    int _26171 = NOVALUE;
    int _26169 = NOVALUE;
    int _26168 = NOVALUE;
    int _26167 = NOVALUE;
    int _26165 = NOVALUE;
    int _26163 = NOVALUE;
    int _26158 = NOVALUE;
    int _26157 = NOVALUE;
    int _26156 = NOVALUE;
    int _26155 = NOVALUE;
    int _26154 = NOVALUE;
    int _26149 = NOVALUE;
    int _26141 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_flag_50024)) {
        _1 = (long)(DBL_PTR(_flag_50024)->dbl);
        DeRefDS(_flag_50024);
        _flag_50024 = _1;
    }

    /** 	inc_path = getenv(env)*/
    DeRefi(_inc_path_50025);
    _inc_path_50025 = EGetEnv(_env_50023);

    /** 	if compare(inc_path,{})!=1 then -- nothing to do, just fail*/
    if (IS_ATOM_INT(_inc_path_50025) && IS_ATOM_INT(_22037)){
        _26141 = (_inc_path_50025 < _22037) ? -1 : (_inc_path_50025 > _22037);
    }
    else{
        _26141 = compare(_inc_path_50025, _22037);
    }
    if (_26141 == 1)
    goto L1; // [18] 29

    /** 		return -1*/
    DeRefDS(_file_name_50022);
    DeRefDS(_env_50023);
    DeRefi(_inc_path_50025);
    DeRef(_full_path_50026);
    DeRef(_file_path_50027);
    DeRef(_strings_50028);
    return -1;
L1: 

    /** 	num_var = find(env,cache_vars)*/
    _38num_var_49616 = find_from(_env_50023, _38cache_vars_49617, 1);

    /** 	use_cache = check_cache(env,inc_path)*/
    RefDS(_env_50023);
    Ref(_inc_path_50025);
    _use_cache_50032 = _38check_cache(_env_50023, _inc_path_50025);
    if (!IS_ATOM_INT(_use_cache_50032)) {
        _1 = (long)(DBL_PTR(_use_cache_50032)->dbl);
        DeRefDS(_use_cache_50032);
        _use_cache_50032 = _1;
    }

    /** 	inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_50025, _inc_path_50025, 59);

    /** 	file_name = SLASH & file_name*/
    Prepend(&_file_name_50022, _file_name_50022, 92);

    /** 	if flag then*/
    if (_flag_50024 == 0)
    {
        goto L2; // [65] 77
    }
    else{
    }

    /** 		file_name = include_subfolder & file_name*/
    Concat((object_ptr)&_file_name_50022, _38include_subfolder_49612, _file_name_50022);
L2: 

    /** 	strings = cache_substrings[num_var]*/
    DeRef(_strings_50028);
    _2 = (int)SEQ_PTR(_38cache_substrings_49619);
    _strings_50028 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
    RefDS(_strings_50028);

    /** 	if use_cache then*/
    if (_use_cache_50032 == 0)
    {
        goto L3; // [91] 292
    }
    else{
    }

    /** 		for i=1 to length(strings) do*/
    if (IS_SEQUENCE(_strings_50028)){
            _26149 = SEQ_PTR(_strings_50028)->length;
    }
    else {
        _26149 = 1;
    }
    {
        int _i_50049;
        _i_50049 = 1;
L4: 
        if (_i_50049 > _26149){
            goto L5; // [99] 252
        }

        /** 			full_path = strings[i]*/
        DeRef(_full_path_50026);
        _2 = (int)SEQ_PTR(_strings_50028);
        _full_path_50026 = (int)*(((s1_ptr)_2)->base + _i_50049);
        Ref(_full_path_50026);

        /** 			file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_50027, _full_path_50026, _file_name_50022);

        /** 			try = open_locked(file_path)    */
        RefDS(_file_path_50027);
        _try_50031 = _27open_locked(_file_path_50027);
        if (!IS_ATOM_INT(_try_50031)) {
            _1 = (long)(DBL_PTR(_try_50031)->dbl);
            DeRefDS(_try_50031);
            _try_50031 = _1;
        }

        /** 			if try != -1 then*/
        if (_try_50031 == -1)
        goto L6; // [130] 145

        /** 				return {file_path,try}*/
        RefDS(_file_path_50027);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _file_path_50027;
        ((int *)_2)[2] = _try_50031;
        _26154 = MAKE_SEQ(_1);
        DeRefDS(_file_name_50022);
        DeRefDS(_env_50023);
        DeRefi(_inc_path_50025);
        DeRefDS(_full_path_50026);
        DeRefDS(_file_path_50027);
        DeRefDS(_strings_50028);
        return _26154;
L6: 

        /** 			ifdef WINDOWS then */

        /** 				if sequence(cache_converted[num_var][i]) then*/
        _2 = (int)SEQ_PTR(_38cache_converted_49622);
        _26155 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        _2 = (int)SEQ_PTR(_26155);
        _26156 = (int)*(((s1_ptr)_2)->base + _i_50049);
        _26155 = NOVALUE;
        _26157 = IS_SEQUENCE(_26156);
        _26156 = NOVALUE;
        if (_26157 == 0)
        {
            _26157 = NOVALUE;
            goto L7; // [164] 245
        }
        else{
            _26157 = NOVALUE;
        }

        /** 					full_path = cache_converted[num_var][i]*/
        _2 = (int)SEQ_PTR(_38cache_converted_49622);
        _26158 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        DeRef(_full_path_50026);
        _2 = (int)SEQ_PTR(_26158);
        _full_path_50026 = (int)*(((s1_ptr)_2)->base + _i_50049);
        Ref(_full_path_50026);
        _26158 = NOVALUE;

        /** 					file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_50027, _full_path_50026, _file_name_50022);

        /** 					try = open_locked(file_path)*/
        RefDS(_file_path_50027);
        _try_50031 = _27open_locked(_file_path_50027);
        if (!IS_ATOM_INT(_try_50031)) {
            _1 = (long)(DBL_PTR(_try_50031)->dbl);
            DeRefDS(_try_50031);
            _try_50031 = _1;
        }

        /** 					if try != -1 then*/
        if (_try_50031 == -1)
        goto L8; // [199] 244

        /** 						cache_converted[num_var][i] = 0*/
        _2 = (int)SEQ_PTR(_38cache_converted_49622);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_converted_49622 = MAKE_SEQ(_2);
        }
        _3 = (int)(_38num_var_49616 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_50049);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);
        _26163 = NOVALUE;

        /** 						cache_substrings[num_var][i] = full_path*/
        _2 = (int)SEQ_PTR(_38cache_substrings_49619);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_substrings_49619 = MAKE_SEQ(_2);
        }
        _3 = (int)(_38num_var_49616 + ((s1_ptr)_2)->base);
        RefDS(_full_path_50026);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_50049);
        _1 = *(int *)_2;
        *(int *)_2 = _full_path_50026;
        DeRef(_1);
        _26165 = NOVALUE;

        /** 						return {file_path,try}*/
        RefDS(_file_path_50027);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _file_path_50027;
        ((int *)_2)[2] = _try_50031;
        _26167 = MAKE_SEQ(_1);
        DeRefDS(_file_name_50022);
        DeRefDS(_env_50023);
        DeRefi(_inc_path_50025);
        DeRefDS(_full_path_50026);
        DeRefDS(_file_path_50027);
        DeRef(_strings_50028);
        DeRef(_26154);
        _26154 = NOVALUE;
        return _26167;
L8: 
L7: 

        /** 		end for*/
        _i_50049 = _i_50049 + 1;
        goto L4; // [247] 106
L5: 
        ;
    }

    /** 		if cache_complete[num_var] then -- nothing to scan*/
    _2 = (int)SEQ_PTR(_38cache_complete_49623);
    _26168 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
    if (_26168 == 0)
    {
        _26168 = NOVALUE;
        goto L9; // [262] 274
    }
    else{
        _26168 = NOVALUE;
    }

    /** 			return -1*/
    DeRefDS(_file_name_50022);
    DeRefDS(_env_50023);
    DeRefi(_inc_path_50025);
    DeRef(_full_path_50026);
    DeRef(_file_path_50027);
    DeRef(_strings_50028);
    DeRef(_26154);
    _26154 = NOVALUE;
    DeRef(_26167);
    _26167 = NOVALUE;
    return -1;
    goto LA; // [271] 298
L9: 

    /** 			pos = cache_delims[num_var]+1 -- scan remainder, starting from as far sa possible*/
    _2 = (int)SEQ_PTR(_38cache_delims_49624);
    _26169 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
    _pos_50033 = _26169 + 1;
    _26169 = NOVALUE;
    goto LA; // [289] 298
L3: 

    /** 		pos = 1*/
    _pos_50033 = 1;
LA: 

    /** 	start_path = 0*/
    _start_path_50030 = 0;

    /** 	for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_50025)){
            _26171 = SEQ_PTR(_inc_path_50025)->length;
    }
    else {
        _26171 = 1;
    }
    {
        int _p_50081;
        _p_50081 = _pos_50033;
LB: 
        if (_p_50081 > _26171){
            goto LC; // [310] 716
        }

        /** 		if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (int)SEQ_PTR(_inc_path_50025);
        _26172 = (int)*(((s1_ptr)_2)->base + _p_50081);
        if (_26172 != 59)
        goto LD; // [325] 665

        /** 			cache_delims[num_var] = p*/
        _2 = (int)SEQ_PTR(_38cache_delims_49624);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_delims_49624 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        *(int *)_2 = _p_50081;

        /** 			end_path = p-1*/
        _end_path_50029 = _p_50081 - 1;

        /** 			while end_path >= start_path and find(inc_path[end_path], " \t" & SLASH_CHARS) do*/
LE: 
        _26175 = (_end_path_50029 >= _start_path_50030);
        if (_26175 == 0) {
            goto LF; // [354] 388
        }
        _2 = (int)SEQ_PTR(_inc_path_50025);
        _26177 = (int)*(((s1_ptr)_2)->base + _end_path_50029);
        Concat((object_ptr)&_26179, _26178, _36SLASH_CHARS_14319);
        _26180 = find_from(_26177, _26179, 1);
        _26177 = NOVALUE;
        DeRefDS(_26179);
        _26179 = NOVALUE;
        if (_26180 == 0)
        {
            _26180 = NOVALUE;
            goto LF; // [374] 388
        }
        else{
            _26180 = NOVALUE;
        }

        /** 				end_path-=1*/
        _end_path_50029 = _end_path_50029 - 1;

        /** 			end while*/
        goto LE; // [385] 350
LF: 

        /** 			if start_path and end_path then*/
        if (_start_path_50030 == 0) {
            goto L10; // [390] 709
        }
        if (_end_path_50029 == 0)
        {
            goto L10; // [395] 709
        }
        else{
        }

        /** 				full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_50026;
        RHS_Slice(_inc_path_50025, _start_path_50030, _end_path_50029);

        /** 				cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (int)SEQ_PTR(_38cache_substrings_49619);
        _26184 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        RefDS(_full_path_50026);
        Append(&_26185, _26184, _full_path_50026);
        _26184 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_substrings_49619);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_substrings_49619 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        _1 = *(int *)_2;
        *(int *)_2 = _26185;
        if( _1 != _26185 ){
            DeRefDS(_1);
        }
        _26185 = NOVALUE;

        /** 				cache_starts[num_var] &= start_path*/
        _2 = (int)SEQ_PTR(_38cache_starts_49620);
        _26186 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        if (IS_SEQUENCE(_26186) && IS_ATOM(_start_path_50030)) {
            Append(&_26187, _26186, _start_path_50030);
        }
        else if (IS_ATOM(_26186) && IS_SEQUENCE(_start_path_50030)) {
        }
        else {
            Concat((object_ptr)&_26187, _26186, _start_path_50030);
            _26186 = NOVALUE;
        }
        _26186 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_starts_49620);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_starts_49620 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        _1 = *(int *)_2;
        *(int *)_2 = _26187;
        if( _1 != _26187 ){
            DeRef(_1);
        }
        _26187 = NOVALUE;

        /** 				cache_ends[num_var] &= end_path*/
        _2 = (int)SEQ_PTR(_38cache_ends_49621);
        _26188 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        if (IS_SEQUENCE(_26188) && IS_ATOM(_end_path_50029)) {
            Append(&_26189, _26188, _end_path_50029);
        }
        else if (IS_ATOM(_26188) && IS_SEQUENCE(_end_path_50029)) {
        }
        else {
            Concat((object_ptr)&_26189, _26188, _end_path_50029);
            _26188 = NOVALUE;
        }
        _26188 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_ends_49621);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_ends_49621 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        _1 = *(int *)_2;
        *(int *)_2 = _26189;
        if( _1 != _26189 ){
            DeRef(_1);
        }
        _26189 = NOVALUE;

        /** 				file_path = full_path & file_name  */
        Concat((object_ptr)&_file_path_50027, _full_path_50026, _file_name_50022);

        /** 				try = open_locked(file_path)*/
        RefDS(_file_path_50027);
        _try_50031 = _27open_locked(_file_path_50027);
        if (!IS_ATOM_INT(_try_50031)) {
            _1 = (long)(DBL_PTR(_try_50031)->dbl);
            DeRefDS(_try_50031);
            _try_50031 = _1;
        }

        /** 				if try != -1 then -- valid path, no point trying to convert*/
        if (_try_50031 == -1)
        goto L11; // [479] 514

        /** 					ifdef WINDOWS then*/

        /** 						cache_converted[num_var] &= 0*/
        _2 = (int)SEQ_PTR(_38cache_converted_49622);
        _26193 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        if (IS_SEQUENCE(_26193) && IS_ATOM(0)) {
            Append(&_26194, _26193, 0);
        }
        else if (IS_ATOM(_26193) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_26194, _26193, 0);
            _26193 = NOVALUE;
        }
        _26193 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_converted_49622);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_converted_49622 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        _1 = *(int *)_2;
        *(int *)_2 = _26194;
        if( _1 != _26194 ){
            DeRef(_1);
        }
        _26194 = NOVALUE;

        /** 					return {file_path,try}*/
        RefDS(_file_path_50027);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _file_path_50027;
        ((int *)_2)[2] = _try_50031;
        _26195 = MAKE_SEQ(_1);
        DeRefDS(_file_name_50022);
        DeRefDS(_env_50023);
        DeRefi(_inc_path_50025);
        DeRefDSi(_full_path_50026);
        DeRefDS(_file_path_50027);
        DeRef(_strings_50028);
        DeRef(_26154);
        _26154 = NOVALUE;
        DeRef(_26167);
        _26167 = NOVALUE;
        _26172 = NOVALUE;
        DeRef(_26175);
        _26175 = NOVALUE;
        return _26195;
L11: 

        /** 				ifdef WINDOWS then*/

        /** 					if find(1, full_path>=128) then*/
        _26196 = binary_op(GREATEREQ, _full_path_50026, 128);
        _26197 = find_from(1, _26196, 1);
        DeRefDS(_26196);
        _26196 = NOVALUE;
        if (_26197 == 0)
        {
            _26197 = NOVALUE;
            goto L12; // [527] 637
        }
        else{
            _26197 = NOVALUE;
        }

        /** 						full_path = convert_from_OEM(full_path)*/
        RefDS(_full_path_50026);
        _0 = _full_path_50026;
        _full_path_50026 = _38convert_from_OEM(_full_path_50026);
        DeRefDS(_0);

        /** 						file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_50027, _full_path_50026, _file_name_50022);

        /** 						try = open_locked(file_path)*/
        RefDS(_file_path_50027);
        _try_50031 = _27open_locked(_file_path_50027);
        if (!IS_ATOM_INT(_try_50031)) {
            _1 = (long)(DBL_PTR(_try_50031)->dbl);
            DeRefDS(_try_50031);
            _try_50031 = _1;
        }

        /** 						if try != -1 then -- that was it; record translation as the valid path*/
        if (_try_50031 == -1)
        goto L13; // [554] 611

        /** 							cache_converted[num_var] &= 0*/
        _2 = (int)SEQ_PTR(_38cache_converted_49622);
        _26202 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        if (IS_SEQUENCE(_26202) && IS_ATOM(0)) {
            Append(&_26203, _26202, 0);
        }
        else if (IS_ATOM(_26202) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_26203, _26202, 0);
            _26202 = NOVALUE;
        }
        _26202 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_converted_49622);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_converted_49622 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        _1 = *(int *)_2;
        *(int *)_2 = _26203;
        if( _1 != _26203 ){
            DeRef(_1);
        }
        _26203 = NOVALUE;

        /** 							cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (int)SEQ_PTR(_38cache_substrings_49619);
        _26204 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        RefDS(_full_path_50026);
        Append(&_26205, _26204, _full_path_50026);
        _26204 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_substrings_49619);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_substrings_49619 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        _1 = *(int *)_2;
        *(int *)_2 = _26205;
        if( _1 != _26205 ){
            DeRefDS(_1);
        }
        _26205 = NOVALUE;

        /** 							return {file_path,try}*/
        RefDS(_file_path_50027);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _file_path_50027;
        ((int *)_2)[2] = _try_50031;
        _26206 = MAKE_SEQ(_1);
        DeRefDS(_file_name_50022);
        DeRefDS(_env_50023);
        DeRefi(_inc_path_50025);
        DeRefDS(_full_path_50026);
        DeRefDS(_file_path_50027);
        DeRef(_strings_50028);
        DeRef(_26154);
        _26154 = NOVALUE;
        DeRef(_26167);
        _26167 = NOVALUE;
        _26172 = NOVALUE;
        DeRef(_26175);
        _26175 = NOVALUE;
        DeRef(_26195);
        _26195 = NOVALUE;
        return _26206;
        goto L14; // [608] 656
L13: 

        /** 							cache_converted[num_var] = append(cache_converted[num_var],full_path)*/
        _2 = (int)SEQ_PTR(_38cache_converted_49622);
        _26207 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        RefDS(_full_path_50026);
        Append(&_26208, _26207, _full_path_50026);
        _26207 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_converted_49622);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_converted_49622 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        _1 = *(int *)_2;
        *(int *)_2 = _26208;
        if( _1 != _26208 ){
            DeRef(_1);
        }
        _26208 = NOVALUE;
        goto L14; // [634] 656
L12: 

        /** 						cache_converted[num_var] &= 0*/
        _2 = (int)SEQ_PTR(_38cache_converted_49622);
        _26209 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        if (IS_SEQUENCE(_26209) && IS_ATOM(0)) {
            Append(&_26210, _26209, 0);
        }
        else if (IS_ATOM(_26209) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_26210, _26209, 0);
            _26209 = NOVALUE;
        }
        _26209 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_converted_49622);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_converted_49622 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        _1 = *(int *)_2;
        *(int *)_2 = _26210;
        if( _1 != _26210 ){
            DeRef(_1);
        }
        _26210 = NOVALUE;
L14: 

        /** 				start_path = 0*/
        _start_path_50030 = 0;
        goto L10; // [662] 709
LD: 

        /** 		elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26211 = (_start_path_50030 == 0);
        if (_26211 == 0) {
            goto L15; // [670] 708
        }
        _2 = (int)SEQ_PTR(_inc_path_50025);
        _26213 = (int)*(((s1_ptr)_2)->base + _p_50081);
        _26214 = (_26213 != 32);
        _26213 = NOVALUE;
        if (_26214 == 0) {
            DeRef(_26215);
            _26215 = 0;
            goto L16; // [682] 698
        }
        _2 = (int)SEQ_PTR(_inc_path_50025);
        _26216 = (int)*(((s1_ptr)_2)->base + _p_50081);
        _26217 = (_26216 != 9);
        _26216 = NOVALUE;
        _26215 = (_26217 != 0);
L16: 
        if (_26215 == 0)
        {
            _26215 = NOVALUE;
            goto L15; // [699] 708
        }
        else{
            _26215 = NOVALUE;
        }

        /** 			start_path = p*/
        _start_path_50030 = _p_50081;
L15: 
L10: 

        /** 	end for*/
        _p_50081 = _p_50081 + 1;
        goto LB; // [711] 317
LC: 
        ;
    }

    /** 	cache_complete[num_var] = 1*/
    _2 = (int)SEQ_PTR(_38cache_complete_49623);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38cache_complete_49623 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
    *(int *)_2 = 1;

    /** 	return -1*/
    DeRefDS(_file_name_50022);
    DeRefDS(_env_50023);
    DeRefi(_inc_path_50025);
    DeRef(_full_path_50026);
    DeRef(_file_path_50027);
    DeRef(_strings_50028);
    DeRef(_26154);
    _26154 = NOVALUE;
    DeRef(_26167);
    _26167 = NOVALUE;
    _26172 = NOVALUE;
    DeRef(_26175);
    _26175 = NOVALUE;
    DeRef(_26195);
    _26195 = NOVALUE;
    DeRef(_26206);
    _26206 = NOVALUE;
    DeRef(_26211);
    _26211 = NOVALUE;
    DeRef(_26214);
    _26214 = NOVALUE;
    DeRef(_26217);
    _26217 = NOVALUE;
    return -1;
    ;
}


int _38Include_paths(int _add_converted_50145)
{
    int _status_50146 = NOVALUE;
    int _pos_50147 = NOVALUE;
    int _inc_path_50148 = NOVALUE;
    int _full_path_50149 = NOVALUE;
    int _start_path_50150 = NOVALUE;
    int _end_path_50151 = NOVALUE;
    int _eudir_path_50167 = NOVALUE;
    int _26278 = NOVALUE;
    int _26277 = NOVALUE;
    int _26276 = NOVALUE;
    int _26275 = NOVALUE;
    int _26274 = NOVALUE;
    int _26273 = NOVALUE;
    int _26272 = NOVALUE;
    int _26270 = NOVALUE;
    int _26269 = NOVALUE;
    int _26268 = NOVALUE;
    int _26267 = NOVALUE;
    int _26266 = NOVALUE;
    int _26265 = NOVALUE;
    int _26264 = NOVALUE;
    int _26263 = NOVALUE;
    int _26262 = NOVALUE;
    int _26261 = NOVALUE;
    int _26260 = NOVALUE;
    int _26259 = NOVALUE;
    int _26258 = NOVALUE;
    int _26257 = NOVALUE;
    int _26256 = NOVALUE;
    int _26255 = NOVALUE;
    int _26254 = NOVALUE;
    int _26253 = NOVALUE;
    int _26252 = NOVALUE;
    int _26251 = NOVALUE;
    int _26250 = NOVALUE;
    int _26248 = NOVALUE;
    int _26246 = NOVALUE;
    int _26245 = NOVALUE;
    int _26244 = NOVALUE;
    int _26243 = NOVALUE;
    int _26242 = NOVALUE;
    int _26239 = NOVALUE;
    int _26238 = NOVALUE;
    int _26236 = NOVALUE;
    int _26234 = NOVALUE;
    int _26232 = NOVALUE;
    int _26231 = NOVALUE;
    int _26229 = NOVALUE;
    int _26226 = NOVALUE;
    int _26224 = NOVALUE;
    int _26219 = NOVALUE;
    int _26218 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_add_converted_50145)) {
        _1 = (long)(DBL_PTR(_add_converted_50145)->dbl);
        DeRefDS(_add_converted_50145);
        _add_converted_50145 = _1;
    }

    /** 	if length(include_Paths) then*/
    if (IS_SEQUENCE(_38include_Paths_50142)){
            _26218 = SEQ_PTR(_38include_Paths_50142)->length;
    }
    else {
        _26218 = 1;
    }
    if (_26218 == 0)
    {
        _26218 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _26218 = NOVALUE;
    }

    /** 		return include_Paths*/
    RefDS(_38include_Paths_50142);
    DeRefi(_inc_path_50148);
    DeRefi(_full_path_50149);
    DeRef(_eudir_path_50167);
    return _38include_Paths_50142;
L1: 

    /** 	include_Paths = append(config_inc_paths, current_dir())*/
    _26219 = _15current_dir();
    Ref(_26219);
    Append(&_38include_Paths_50142, _38config_inc_paths_49625, _26219);
    DeRef(_26219);
    _26219 = NOVALUE;

    /** 	num_var = find("EUINC", cache_vars)*/
    _38num_var_49616 = find_from(_26221, _38cache_vars_49617, 1);

    /** 	inc_path = getenv("EUINC")*/
    DeRefi(_inc_path_50148);
    _inc_path_50148 = EGetEnv(_26221);

    /** 	if atom(inc_path) then*/
    _26224 = IS_ATOM(_inc_path_50148);
    if (_26224 == 0)
    {
        _26224 = NOVALUE;
        goto L2; // [52] 61
    }
    else{
        _26224 = NOVALUE;
    }

    /** 		inc_path = ""*/
    RefDS(_22037);
    DeRefi(_inc_path_50148);
    _inc_path_50148 = _22037;
L2: 

    /** 	status = check_cache("EUINC", inc_path)*/
    RefDS(_26221);
    Ref(_inc_path_50148);
    _status_50146 = _38check_cache(_26221, _inc_path_50148);
    if (!IS_ATOM_INT(_status_50146)) {
        _1 = (long)(DBL_PTR(_status_50146)->dbl);
        DeRefDS(_status_50146);
        _status_50146 = _1;
    }

    /** 	if length(inc_path) then*/
    if (IS_SEQUENCE(_inc_path_50148)){
            _26226 = SEQ_PTR(_inc_path_50148)->length;
    }
    else {
        _26226 = 1;
    }
    if (_26226 == 0)
    {
        _26226 = NOVALUE;
        goto L3; // [75] 87
    }
    else{
        _26226 = NOVALUE;
    }

    /** 		inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_50148, _inc_path_50148, 59);
L3: 

    /** 	object eudir_path = get_eudir()*/
    _0 = _eudir_path_50167;
    _eudir_path_50167 = _27get_eudir();
    DeRef(_0);

    /** 	if sequence(eudir_path) then*/
    _26229 = IS_SEQUENCE(_eudir_path_50167);
    if (_26229 == 0)
    {
        _26229 = NOVALUE;
        goto L4; // [97] 117
    }
    else{
        _26229 = NOVALUE;
    }

    /** 		include_Paths = append(include_Paths, sprintf("%s/include", { eudir_path }))*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_eudir_path_50167);
    *((int *)(_2+4)) = _eudir_path_50167;
    _26231 = MAKE_SEQ(_1);
    _26232 = EPrintf(-9999999, _26230, _26231);
    DeRefDS(_26231);
    _26231 = NOVALUE;
    RefDS(_26232);
    Append(&_38include_Paths_50142, _38include_Paths_50142, _26232);
    DeRefDS(_26232);
    _26232 = NOVALUE;
L4: 

    /** 	if status then*/
    if (_status_50146 == 0)
    {
        goto L5; // [119] 161
    }
    else{
    }

    /** 		if cache_complete[num_var] then*/
    _2 = (int)SEQ_PTR(_38cache_complete_49623);
    _26234 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
    if (_26234 == 0)
    {
        _26234 = NOVALUE;
        goto L6; // [132] 144
    }
    else{
        _26234 = NOVALUE;
    }

    /** 			goto "cache done"*/
    goto G7;
L6: 

    /** 		pos = cache_delims[num_var]+1*/
    _2 = (int)SEQ_PTR(_38cache_delims_49624);
    _26236 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
    _pos_50147 = _26236 + 1;
    _26236 = NOVALUE;
    goto L8; // [158] 167
L5: 

    /**         pos = 1*/
    _pos_50147 = 1;
L8: 

    /** 	start_path = 0*/
    _start_path_50150 = 0;

    /** 	for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_50148)){
            _26238 = SEQ_PTR(_inc_path_50148)->length;
    }
    else {
        _26238 = 1;
    }
    {
        int _p_50184;
        _p_50184 = _pos_50147;
L9: 
        if (_p_50184 > _26238){
            goto LA; // [179] 456
        }

        /** 		if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (int)SEQ_PTR(_inc_path_50148);
        _26239 = (int)*(((s1_ptr)_2)->base + _p_50184);
        if (_26239 != 59)
        goto LB; // [194] 405

        /** 			cache_delims[num_var] = p*/
        _2 = (int)SEQ_PTR(_38cache_delims_49624);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_delims_49624 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        *(int *)_2 = _p_50184;

        /** 			end_path = p-1*/
        _end_path_50151 = _p_50184 - 1;

        /** 			while end_path >= start_path and find(inc_path[end_path]," \t" & SLASH_CHARS) do*/
LC: 
        _26242 = (_end_path_50151 >= _start_path_50150);
        if (_26242 == 0) {
            goto LD; // [223] 257
        }
        _2 = (int)SEQ_PTR(_inc_path_50148);
        _26244 = (int)*(((s1_ptr)_2)->base + _end_path_50151);
        Concat((object_ptr)&_26245, _26178, _36SLASH_CHARS_14319);
        _26246 = find_from(_26244, _26245, 1);
        _26244 = NOVALUE;
        DeRefDS(_26245);
        _26245 = NOVALUE;
        if (_26246 == 0)
        {
            _26246 = NOVALUE;
            goto LD; // [243] 257
        }
        else{
            _26246 = NOVALUE;
        }

        /** 				end_path -= 1*/
        _end_path_50151 = _end_path_50151 - 1;

        /** 			end while*/
        goto LC; // [254] 219
LD: 

        /** 			if start_path and end_path then*/
        if (_start_path_50150 == 0) {
            goto LE; // [259] 449
        }
        if (_end_path_50151 == 0)
        {
            goto LE; // [264] 449
        }
        else{
        }

        /** 				full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_50149;
        RHS_Slice(_inc_path_50148, _start_path_50150, _end_path_50151);

        /** 				cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (int)SEQ_PTR(_38cache_substrings_49619);
        _26250 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        RefDS(_full_path_50149);
        Append(&_26251, _26250, _full_path_50149);
        _26250 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_substrings_49619);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_substrings_49619 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        _1 = *(int *)_2;
        *(int *)_2 = _26251;
        if( _1 != _26251 ){
            DeRefDS(_1);
        }
        _26251 = NOVALUE;

        /** 				cache_starts[num_var] &= start_path*/
        _2 = (int)SEQ_PTR(_38cache_starts_49620);
        _26252 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        if (IS_SEQUENCE(_26252) && IS_ATOM(_start_path_50150)) {
            Append(&_26253, _26252, _start_path_50150);
        }
        else if (IS_ATOM(_26252) && IS_SEQUENCE(_start_path_50150)) {
        }
        else {
            Concat((object_ptr)&_26253, _26252, _start_path_50150);
            _26252 = NOVALUE;
        }
        _26252 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_starts_49620);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_starts_49620 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        _1 = *(int *)_2;
        *(int *)_2 = _26253;
        if( _1 != _26253 ){
            DeRef(_1);
        }
        _26253 = NOVALUE;

        /** 				cache_ends[num_var] &= end_path*/
        _2 = (int)SEQ_PTR(_38cache_ends_49621);
        _26254 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        if (IS_SEQUENCE(_26254) && IS_ATOM(_end_path_50151)) {
            Append(&_26255, _26254, _end_path_50151);
        }
        else if (IS_ATOM(_26254) && IS_SEQUENCE(_end_path_50151)) {
        }
        else {
            Concat((object_ptr)&_26255, _26254, _end_path_50151);
            _26254 = NOVALUE;
        }
        _26254 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_ends_49621);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_ends_49621 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        _1 = *(int *)_2;
        *(int *)_2 = _26255;
        if( _1 != _26255 ){
            DeRef(_1);
        }
        _26255 = NOVALUE;

        /** 				ifdef WINDOWS then*/

        /** 					if find(1, full_path>=128) then*/
        _26256 = binary_op(GREATEREQ, _full_path_50149, 128);
        _26257 = find_from(1, _26256, 1);
        DeRefDS(_26256);
        _26256 = NOVALUE;
        if (_26257 == 0)
        {
            _26257 = NOVALUE;
            goto LF; // [345] 377
        }
        else{
            _26257 = NOVALUE;
        }

        /** 						cache_converted[num_var] = append(cache_converted[num_var], */
        _2 = (int)SEQ_PTR(_38cache_converted_49622);
        _26258 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        RefDS(_full_path_50149);
        _26259 = _38convert_from_OEM(_full_path_50149);
        Ref(_26259);
        Append(&_26260, _26258, _26259);
        _26258 = NOVALUE;
        DeRef(_26259);
        _26259 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_converted_49622);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_converted_49622 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        _1 = *(int *)_2;
        *(int *)_2 = _26260;
        if( _1 != _26260 ){
            DeRef(_1);
        }
        _26260 = NOVALUE;
        goto L10; // [374] 396
LF: 

        /** 						cache_converted[num_var] &= 0*/
        _2 = (int)SEQ_PTR(_38cache_converted_49622);
        _26261 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        if (IS_SEQUENCE(_26261) && IS_ATOM(0)) {
            Append(&_26262, _26261, 0);
        }
        else if (IS_ATOM(_26261) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_26262, _26261, 0);
            _26261 = NOVALUE;
        }
        _26261 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_converted_49622);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_converted_49622 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
        _1 = *(int *)_2;
        *(int *)_2 = _26262;
        if( _1 != _26262 ){
            DeRef(_1);
        }
        _26262 = NOVALUE;
L10: 

        /** 				start_path = 0*/
        _start_path_50150 = 0;
        goto LE; // [402] 449
LB: 

        /** 		elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26263 = (_start_path_50150 == 0);
        if (_26263 == 0) {
            goto L11; // [410] 448
        }
        _2 = (int)SEQ_PTR(_inc_path_50148);
        _26265 = (int)*(((s1_ptr)_2)->base + _p_50184);
        _26266 = (_26265 != 32);
        _26265 = NOVALUE;
        if (_26266 == 0) {
            DeRef(_26267);
            _26267 = 0;
            goto L12; // [422] 438
        }
        _2 = (int)SEQ_PTR(_inc_path_50148);
        _26268 = (int)*(((s1_ptr)_2)->base + _p_50184);
        _26269 = (_26268 != 9);
        _26268 = NOVALUE;
        _26267 = (_26269 != 0);
L12: 
        if (_26267 == 0)
        {
            _26267 = NOVALUE;
            goto L11; // [439] 448
        }
        else{
            _26267 = NOVALUE;
        }

        /** 			start_path = p*/
        _start_path_50150 = _p_50184;
L11: 
LE: 

        /** 	end for*/
        _p_50184 = _p_50184 + 1;
        goto L9; // [451] 186
LA: 
        ;
    }

    /** label "cache done"*/
G7:

    /** 	include_Paths &= cache_substrings[num_var]*/
    _2 = (int)SEQ_PTR(_38cache_substrings_49619);
    _26270 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
    Concat((object_ptr)&_38include_Paths_50142, _38include_Paths_50142, _26270);
    _26270 = NOVALUE;

    /** 	cache_complete[num_var] = 1*/
    _2 = (int)SEQ_PTR(_38cache_complete_49623);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38cache_complete_49623 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _38num_var_49616);
    *(int *)_2 = 1;

    /** 	ifdef WINDOWS then*/

    /** 		if add_converted then*/
    if (_add_converted_50145 == 0)
    {
        goto L13; // [490] 562
    }
    else{
    }

    /** 	    	for i=1 to length(cache_converted[num_var]) do*/
    _2 = (int)SEQ_PTR(_38cache_converted_49622);
    _26272 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
    if (IS_SEQUENCE(_26272)){
            _26273 = SEQ_PTR(_26272)->length;
    }
    else {
        _26273 = 1;
    }
    _26272 = NOVALUE;
    {
        int _i_50229;
        _i_50229 = 1;
L14: 
        if (_i_50229 > _26273){
            goto L15; // [506] 561
        }

        /** 	        	if sequence(cache_converted[num_var][i]) then*/
        _2 = (int)SEQ_PTR(_38cache_converted_49622);
        _26274 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        _2 = (int)SEQ_PTR(_26274);
        _26275 = (int)*(((s1_ptr)_2)->base + _i_50229);
        _26274 = NOVALUE;
        _26276 = IS_SEQUENCE(_26275);
        _26275 = NOVALUE;
        if (_26276 == 0)
        {
            _26276 = NOVALUE;
            goto L16; // [530] 554
        }
        else{
            _26276 = NOVALUE;
        }

        /** 		        	include_Paths = append(include_Paths, cache_converted[num_var][i])*/
        _2 = (int)SEQ_PTR(_38cache_converted_49622);
        _26277 = (int)*(((s1_ptr)_2)->base + _38num_var_49616);
        _2 = (int)SEQ_PTR(_26277);
        _26278 = (int)*(((s1_ptr)_2)->base + _i_50229);
        _26277 = NOVALUE;
        Ref(_26278);
        Append(&_38include_Paths_50142, _38include_Paths_50142, _26278);
        _26278 = NOVALUE;
L16: 

        /** 			end for*/
        _i_50229 = _i_50229 + 1;
        goto L14; // [556] 513
L15: 
        ;
    }
L13: 

    /** 	return include_Paths*/
    RefDS(_38include_Paths_50142);
    DeRefi(_inc_path_50148);
    DeRefi(_full_path_50149);
    DeRef(_eudir_path_50167);
    _26239 = NOVALUE;
    DeRef(_26242);
    _26242 = NOVALUE;
    DeRef(_26263);
    _26263 = NOVALUE;
    _26272 = NOVALUE;
    DeRef(_26266);
    _26266 = NOVALUE;
    DeRef(_26269);
    _26269 = NOVALUE;
    return _38include_Paths_50142;
    ;
}


int _38e_path_find(int _name_50241)
{
    int _scan_result_50242 = NOVALUE;
    int _26288 = NOVALUE;
    int _26287 = NOVALUE;
    int _26286 = NOVALUE;
    int _26283 = NOVALUE;
    int _26282 = NOVALUE;
    int _26281 = NOVALUE;
    int _26280 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if file_exists(name) then*/
    RefDS(_name_50241);
    _26280 = _15file_exists(_name_50241);
    if (_26280 == 0) {
        DeRef(_26280);
        _26280 = NOVALUE;
        goto L1; // [9] 19
    }
    else {
        if (!IS_ATOM_INT(_26280) && DBL_PTR(_26280)->dbl == 0.0){
            DeRef(_26280);
            _26280 = NOVALUE;
            goto L1; // [9] 19
        }
        DeRef(_26280);
        _26280 = NOVALUE;
    }
    DeRef(_26280);
    _26280 = NOVALUE;

    /** 		return name*/
    DeRef(_scan_result_50242);
    return _name_50241;
L1: 

    /** 	for i = 1 to length(SLASH_CHARS) do*/
    if (IS_SEQUENCE(_36SLASH_CHARS_14319)){
            _26281 = SEQ_PTR(_36SLASH_CHARS_14319)->length;
    }
    else {
        _26281 = 1;
    }
    {
        int _i_50247;
        _i_50247 = 1;
L2: 
        if (_i_50247 > _26281){
            goto L3; // [26] 63
        }

        /** 		if find(SLASH_CHARS[i], name) then*/
        _2 = (int)SEQ_PTR(_36SLASH_CHARS_14319);
        _26282 = (int)*(((s1_ptr)_2)->base + _i_50247);
        _26283 = find_from(_26282, _name_50241, 1);
        _26282 = NOVALUE;
        if (_26283 == 0)
        {
            _26283 = NOVALUE;
            goto L4; // [46] 56
        }
        else{
            _26283 = NOVALUE;
        }

        /** 			return -1*/
        DeRefDS(_name_50241);
        DeRef(_scan_result_50242);
        return -1;
L4: 

        /** 	end for*/
        _i_50247 = _i_50247 + 1;
        goto L2; // [58] 33
L3: 
        ;
    }

    /** 	scan_result = ScanPath(name, "PATH", 0)*/
    RefDS(_name_50241);
    RefDS(_26284);
    _0 = _scan_result_50242;
    _scan_result_50242 = _38ScanPath(_name_50241, _26284, 0);
    DeRef(_0);

    /** 	if sequence(scan_result) then*/
    _26286 = IS_SEQUENCE(_scan_result_50242);
    if (_26286 == 0)
    {
        _26286 = NOVALUE;
        goto L5; // [76] 98
    }
    else{
        _26286 = NOVALUE;
    }

    /** 		close(scan_result[2])*/
    _2 = (int)SEQ_PTR(_scan_result_50242);
    _26287 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_26287))
    EClose(_26287);
    else
    EClose((int)DBL_PTR(_26287)->dbl);
    _26287 = NOVALUE;

    /** 		return scan_result[1]*/
    _2 = (int)SEQ_PTR(_scan_result_50242);
    _26288 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_26288);
    DeRefDS(_name_50241);
    DeRef(_scan_result_50242);
    return _26288;
L5: 

    /** 	return -1*/
    DeRefDS(_name_50241);
    DeRef(_scan_result_50242);
    _26288 = NOVALUE;
    return -1;
    ;
}



// 0x03456046
