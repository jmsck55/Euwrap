// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _62find_category(int _tokid_23694)
{
    int _catname_23695 = NOVALUE;
    int _13674 = NOVALUE;
    int _13673 = NOVALUE;
    int _13671 = NOVALUE;
    int _13670 = NOVALUE;
    int _13669 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_23694)) {
        _1 = (long)(DBL_PTR(_tokid_23694)->dbl);
        DeRefDS(_tokid_23694);
        _tokid_23694 = _1;
    }

    /** 	sequence catname = "reserved word"*/
    RefDS(_13668);
    DeRef(_catname_23695);
    _catname_23695 = _13668;

    /** 	for i = 1 to length(token_category) do*/
    _13669 = 73;
    {
        int _i_23698;
        _i_23698 = 1;
L1: 
        if (_i_23698 > 73){
            goto L2; // [17] 72
        }

        /** 		if token_category[i][1] = tokid then*/
        _2 = (int)SEQ_PTR(_28token_category_11529);
        _13670 = (int)*(((s1_ptr)_2)->base + _i_23698);
        _2 = (int)SEQ_PTR(_13670);
        _13671 = (int)*(((s1_ptr)_2)->base + 1);
        _13670 = NOVALUE;
        if (binary_op_a(NOTEQ, _13671, _tokid_23694)){
            _13671 = NOVALUE;
            goto L3; // [36] 65
        }
        _13671 = NOVALUE;

        /** 			catname = token_catname[token_category[i][2]]*/
        _2 = (int)SEQ_PTR(_28token_category_11529);
        _13673 = (int)*(((s1_ptr)_2)->base + _i_23698);
        _2 = (int)SEQ_PTR(_13673);
        _13674 = (int)*(((s1_ptr)_2)->base + 2);
        _13673 = NOVALUE;
        DeRef(_catname_23695);
        _2 = (int)SEQ_PTR(_28token_catname_11516);
        if (!IS_ATOM_INT(_13674)){
            _catname_23695 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13674)->dbl));
        }
        else{
            _catname_23695 = (int)*(((s1_ptr)_2)->base + _13674);
        }
        RefDS(_catname_23695);

        /** 			exit*/
        goto L2; // [62] 72
L3: 

        /** 	end for*/
        _i_23698 = _i_23698 + 1;
        goto L1; // [67] 24
L2: 
        ;
    }

    /** 	return catname*/
    _13674 = NOVALUE;
    return _catname_23695;
    ;
}


int _62find_token_text(int _tokid_23713)
{
    int _13683 = NOVALUE;
    int _13681 = NOVALUE;
    int _13680 = NOVALUE;
    int _13678 = NOVALUE;
    int _13677 = NOVALUE;
    int _13676 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_23713)) {
        _1 = (long)(DBL_PTR(_tokid_23713)->dbl);
        DeRefDS(_tokid_23713);
        _tokid_23713 = _1;
    }

    /** 	for i = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_62keylist_22870)){
            _13676 = SEQ_PTR(_62keylist_22870)->length;
    }
    else {
        _13676 = 1;
    }
    {
        int _i_23715;
        _i_23715 = 1;
L1: 
        if (_i_23715 > _13676){
            goto L2; // [10] 57
        }

        /** 		if keylist[i][3] = tokid then*/
        _2 = (int)SEQ_PTR(_62keylist_22870);
        _13677 = (int)*(((s1_ptr)_2)->base + _i_23715);
        _2 = (int)SEQ_PTR(_13677);
        _13678 = (int)*(((s1_ptr)_2)->base + 3);
        _13677 = NOVALUE;
        if (binary_op_a(NOTEQ, _13678, _tokid_23713)){
            _13678 = NOVALUE;
            goto L3; // [29] 50
        }
        _13678 = NOVALUE;

        /** 			return keylist[i][1]*/
        _2 = (int)SEQ_PTR(_62keylist_22870);
        _13680 = (int)*(((s1_ptr)_2)->base + _i_23715);
        _2 = (int)SEQ_PTR(_13680);
        _13681 = (int)*(((s1_ptr)_2)->base + 1);
        _13680 = NOVALUE;
        Ref(_13681);
        return _13681;
L3: 

        /** 	end for*/
        _i_23715 = _i_23715 + 1;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** 	return LexName(tokid, "unknown word")*/
    RefDS(_13682);
    _13683 = _37LexName(_tokid_23713, _13682);
    _13681 = NOVALUE;
    return _13683;
    ;
}



// 0x796E6E8A
