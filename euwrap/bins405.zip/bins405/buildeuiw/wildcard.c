// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _11qmatch(int _p_10826, int _s_10827)
{
    int _k_10828 = NOVALUE;
    int _6048 = NOVALUE;
    int _6047 = NOVALUE;
    int _6046 = NOVALUE;
    int _6045 = NOVALUE;
    int _6044 = NOVALUE;
    int _6043 = NOVALUE;
    int _6042 = NOVALUE;
    int _6041 = NOVALUE;
    int _6040 = NOVALUE;
    int _6039 = NOVALUE;
    int _6038 = NOVALUE;
    int _6037 = NOVALUE;
    int _6035 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not find('?', p) then*/
    _6035 = find_from(63, _p_10826, 1);
    if (_6035 != 0)
    goto L1; // [12] 27
    _6035 = NOVALUE;

    /** 		return match(p, s) -- fast*/
    _6037 = e_match_from(_p_10826, _s_10827, 1);
    DeRefDS(_p_10826);
    DeRefDS(_s_10827);
    return _6037;
L1: 

    /** 	for i = 1 to length(s) - length(p) + 1 do*/
    if (IS_SEQUENCE(_s_10827)){
            _6038 = SEQ_PTR(_s_10827)->length;
    }
    else {
        _6038 = 1;
    }
    if (IS_SEQUENCE(_p_10826)){
            _6039 = SEQ_PTR(_p_10826)->length;
    }
    else {
        _6039 = 1;
    }
    _6040 = _6038 - _6039;
    _6038 = NOVALUE;
    _6039 = NOVALUE;
    _6041 = _6040 + 1;
    _6040 = NOVALUE;
    {
        int _i_10834;
        _i_10834 = 1;
L2: 
        if (_i_10834 > _6041){
            goto L3; // [43] 142
        }

        /** 		k = i*/
        _k_10828 = _i_10834;

        /** 		for j = 1 to length(p) do*/
        if (IS_SEQUENCE(_p_10826)){
                _6042 = SEQ_PTR(_p_10826)->length;
        }
        else {
            _6042 = 1;
        }
        {
            int _j_10840;
            _j_10840 = 1;
L4: 
            if (_j_10840 > _6042){
                goto L5; // [62] 122
            }

            /** 			if p[j] != s[k] and p[j] != '?' then*/
            _2 = (int)SEQ_PTR(_p_10826);
            _6043 = (int)*(((s1_ptr)_2)->base + _j_10840);
            _2 = (int)SEQ_PTR(_s_10827);
            _6044 = (int)*(((s1_ptr)_2)->base + _k_10828);
            if (IS_ATOM_INT(_6043) && IS_ATOM_INT(_6044)) {
                _6045 = (_6043 != _6044);
            }
            else {
                _6045 = binary_op(NOTEQ, _6043, _6044);
            }
            _6043 = NOVALUE;
            _6044 = NOVALUE;
            if (IS_ATOM_INT(_6045)) {
                if (_6045 == 0) {
                    goto L6; // [83] 109
                }
            }
            else {
                if (DBL_PTR(_6045)->dbl == 0.0) {
                    goto L6; // [83] 109
                }
            }
            _2 = (int)SEQ_PTR(_p_10826);
            _6047 = (int)*(((s1_ptr)_2)->base + _j_10840);
            if (IS_ATOM_INT(_6047)) {
                _6048 = (_6047 != 63);
            }
            else {
                _6048 = binary_op(NOTEQ, _6047, 63);
            }
            _6047 = NOVALUE;
            if (_6048 == 0) {
                DeRef(_6048);
                _6048 = NOVALUE;
                goto L6; // [96] 109
            }
            else {
                if (!IS_ATOM_INT(_6048) && DBL_PTR(_6048)->dbl == 0.0){
                    DeRef(_6048);
                    _6048 = NOVALUE;
                    goto L6; // [96] 109
                }
                DeRef(_6048);
                _6048 = NOVALUE;
            }
            DeRef(_6048);
            _6048 = NOVALUE;

            /** 				k = 0*/
            _k_10828 = 0;

            /** 				exit*/
            goto L5; // [106] 122
L6: 

            /** 			k += 1*/
            _k_10828 = _k_10828 + 1;

            /** 		end for*/
            _j_10840 = _j_10840 + 1;
            goto L4; // [117] 69
L5: 
            ;
        }

        /** 		if k != 0 then*/
        if (_k_10828 == 0)
        goto L7; // [124] 135

        /** 			return i*/
        DeRefDS(_p_10826);
        DeRefDS(_s_10827);
        DeRef(_6041);
        _6041 = NOVALUE;
        DeRef(_6045);
        _6045 = NOVALUE;
        return _i_10834;
L7: 

        /** 	end for*/
        _i_10834 = _i_10834 + 1;
        goto L2; // [137] 50
L3: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_p_10826);
    DeRefDS(_s_10827);
    DeRef(_6041);
    _6041 = NOVALUE;
    DeRef(_6045);
    _6045 = NOVALUE;
    return 0;
    ;
}


int _11is_match(int _pattern_10855, int _string_10856)
{
    int _p_10857 = NOVALUE;
    int _f_10858 = NOVALUE;
    int _t_10859 = NOVALUE;
    int _match_string_10860 = NOVALUE;
    int _6090 = NOVALUE;
    int _6089 = NOVALUE;
    int _6087 = NOVALUE;
    int _6083 = NOVALUE;
    int _6082 = NOVALUE;
    int _6081 = NOVALUE;
    int _6078 = NOVALUE;
    int _6077 = NOVALUE;
    int _6074 = NOVALUE;
    int _6071 = NOVALUE;
    int _6069 = NOVALUE;
    int _6067 = NOVALUE;
    int _6065 = NOVALUE;
    int _6062 = NOVALUE;
    int _6060 = NOVALUE;
    int _6058 = NOVALUE;
    int _6057 = NOVALUE;
    int _6056 = NOVALUE;
    int _6055 = NOVALUE;
    int _6053 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pattern = pattern & END_MARKER*/
    Append(&_pattern_10855, _pattern_10855, -1);

    /** 	string = string & END_MARKER*/
    Append(&_string_10856, _string_10856, -1);

    /** 	p = 1*/
    _p_10857 = 1;

    /** 	f = 1*/
    _f_10858 = 1;

    /** 	while f <= length(string) do*/
L1: 
    if (IS_SEQUENCE(_string_10856)){
            _6053 = SEQ_PTR(_string_10856)->length;
    }
    else {
        _6053 = 1;
    }
    if (_f_10858 > _6053)
    goto L2; // [35] 288

    /** 		if not find(pattern[p], {string[f], '?'}) then*/
    _2 = (int)SEQ_PTR(_pattern_10855);
    _6055 = (int)*(((s1_ptr)_2)->base + _p_10857);
    _2 = (int)SEQ_PTR(_string_10856);
    _6056 = (int)*(((s1_ptr)_2)->base + _f_10858);
    Ref(_6056);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _6056;
    ((int *)_2)[2] = 63;
    _6057 = MAKE_SEQ(_1);
    _6056 = NOVALUE;
    _6058 = find_from(_6055, _6057, 1);
    _6055 = NOVALUE;
    DeRefDS(_6057);
    _6057 = NOVALUE;
    if (_6058 != 0)
    goto L3; // [58] 248
    _6058 = NOVALUE;

    /** 			if pattern[p] = '*' then*/
    _2 = (int)SEQ_PTR(_pattern_10855);
    _6060 = (int)*(((s1_ptr)_2)->base + _p_10857);
    if (binary_op_a(NOTEQ, _6060, 42)){
        _6060 = NOVALUE;
        goto L4; // [67] 240
    }
    _6060 = NOVALUE;

    /** 				while pattern[p] = '*' do*/
L5: 
    _2 = (int)SEQ_PTR(_pattern_10855);
    _6062 = (int)*(((s1_ptr)_2)->base + _p_10857);
    if (binary_op_a(NOTEQ, _6062, 42)){
        _6062 = NOVALUE;
        goto L6; // [80] 95
    }
    _6062 = NOVALUE;

    /** 					p += 1*/
    _p_10857 = _p_10857 + 1;

    /** 				end while*/
    goto L5; // [92] 76
L6: 

    /** 				if pattern[p] = END_MARKER then*/
    _2 = (int)SEQ_PTR(_pattern_10855);
    _6065 = (int)*(((s1_ptr)_2)->base + _p_10857);
    if (binary_op_a(NOTEQ, _6065, -1)){
        _6065 = NOVALUE;
        goto L7; // [101] 112
    }
    _6065 = NOVALUE;

    /** 					return 1*/
    DeRefDS(_pattern_10855);
    DeRefDS(_string_10856);
    DeRef(_match_string_10860);
    return 1;
L7: 

    /** 				match_string = ""*/
    RefDS(_5);
    DeRef(_match_string_10860);
    _match_string_10860 = _5;

    /** 				while pattern[p] != '*' do*/
L8: 
    _2 = (int)SEQ_PTR(_pattern_10855);
    _6067 = (int)*(((s1_ptr)_2)->base + _p_10857);
    if (binary_op_a(EQUALS, _6067, 42)){
        _6067 = NOVALUE;
        goto L9; // [128] 168
    }
    _6067 = NOVALUE;

    /** 					match_string = match_string & pattern[p]*/
    _2 = (int)SEQ_PTR(_pattern_10855);
    _6069 = (int)*(((s1_ptr)_2)->base + _p_10857);
    if (IS_SEQUENCE(_match_string_10860) && IS_ATOM(_6069)) {
        Ref(_6069);
        Append(&_match_string_10860, _match_string_10860, _6069);
    }
    else if (IS_ATOM(_match_string_10860) && IS_SEQUENCE(_6069)) {
    }
    else {
        Concat((object_ptr)&_match_string_10860, _match_string_10860, _6069);
    }
    _6069 = NOVALUE;

    /** 					if pattern[p] = END_MARKER then*/
    _2 = (int)SEQ_PTR(_pattern_10855);
    _6071 = (int)*(((s1_ptr)_2)->base + _p_10857);
    if (binary_op_a(NOTEQ, _6071, -1)){
        _6071 = NOVALUE;
        goto LA; // [148] 157
    }
    _6071 = NOVALUE;

    /** 						exit*/
    goto L9; // [154] 168
LA: 

    /** 					p += 1*/
    _p_10857 = _p_10857 + 1;

    /** 				end while*/
    goto L8; // [165] 124
L9: 

    /** 				if pattern[p] = '*' then*/
    _2 = (int)SEQ_PTR(_pattern_10855);
    _6074 = (int)*(((s1_ptr)_2)->base + _p_10857);
    if (binary_op_a(NOTEQ, _6074, 42)){
        _6074 = NOVALUE;
        goto LB; // [174] 185
    }
    _6074 = NOVALUE;

    /** 					p -= 1*/
    _p_10857 = _p_10857 - 1;
LB: 

    /** 				t = qmatch(match_string, string[f..$])*/
    if (IS_SEQUENCE(_string_10856)){
            _6077 = SEQ_PTR(_string_10856)->length;
    }
    else {
        _6077 = 1;
    }
    rhs_slice_target = (object_ptr)&_6078;
    RHS_Slice(_string_10856, _f_10858, _6077);
    RefDS(_match_string_10860);
    _t_10859 = _11qmatch(_match_string_10860, _6078);
    _6078 = NOVALUE;
    if (!IS_ATOM_INT(_t_10859)) {
        _1 = (long)(DBL_PTR(_t_10859)->dbl);
        DeRefDS(_t_10859);
        _t_10859 = _1;
    }

    /** 				if t = 0 then*/
    if (_t_10859 != 0)
    goto LC; // [204] 217

    /** 					return 0*/
    DeRefDS(_pattern_10855);
    DeRefDS(_string_10856);
    DeRefDS(_match_string_10860);
    return 0;
    goto LD; // [214] 247
LC: 

    /** 					f += t + length(match_string) - 2*/
    if (IS_SEQUENCE(_match_string_10860)){
            _6081 = SEQ_PTR(_match_string_10860)->length;
    }
    else {
        _6081 = 1;
    }
    _6082 = _t_10859 + _6081;
    if ((long)((unsigned long)_6082 + (unsigned long)HIGH_BITS) >= 0) 
    _6082 = NewDouble((double)_6082);
    _6081 = NOVALUE;
    if (IS_ATOM_INT(_6082)) {
        _6083 = _6082 - 2;
        if ((long)((unsigned long)_6083 +(unsigned long) HIGH_BITS) >= 0){
            _6083 = NewDouble((double)_6083);
        }
    }
    else {
        _6083 = NewDouble(DBL_PTR(_6082)->dbl - (double)2);
    }
    DeRef(_6082);
    _6082 = NOVALUE;
    if (IS_ATOM_INT(_6083)) {
        _f_10858 = _f_10858 + _6083;
    }
    else {
        _f_10858 = NewDouble((double)_f_10858 + DBL_PTR(_6083)->dbl);
    }
    DeRef(_6083);
    _6083 = NOVALUE;
    if (!IS_ATOM_INT(_f_10858)) {
        _1 = (long)(DBL_PTR(_f_10858)->dbl);
        DeRefDS(_f_10858);
        _f_10858 = _1;
    }
    goto LD; // [237] 247
L4: 

    /** 				return 0*/
    DeRefDS(_pattern_10855);
    DeRefDS(_string_10856);
    DeRef(_match_string_10860);
    return 0;
LD: 
L3: 

    /** 		p += 1*/
    _p_10857 = _p_10857 + 1;

    /** 		f += 1*/
    _f_10858 = _f_10858 + 1;

    /** 		if p > length(pattern) then*/
    if (IS_SEQUENCE(_pattern_10855)){
            _6087 = SEQ_PTR(_pattern_10855)->length;
    }
    else {
        _6087 = 1;
    }
    if (_p_10857 <= _6087)
    goto L1; // [265] 32

    /** 			return f > length(string) */
    if (IS_SEQUENCE(_string_10856)){
            _6089 = SEQ_PTR(_string_10856)->length;
    }
    else {
        _6089 = 1;
    }
    _6090 = (_f_10858 > _6089);
    _6089 = NOVALUE;
    DeRefDS(_pattern_10855);
    DeRefDS(_string_10856);
    DeRef(_match_string_10860);
    return _6090;

    /** 	end while*/
    goto L1; // [285] 32
L2: 

    /** 	return 0*/
    DeRefDS(_pattern_10855);
    DeRefDS(_string_10856);
    DeRef(_match_string_10860);
    DeRef(_6090);
    _6090 = NOVALUE;
    return 0;
    ;
}



// 0x530C531A
