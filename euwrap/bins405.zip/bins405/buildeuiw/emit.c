// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

void _37Push(int _x_50517)
{
    int _26444 = NOVALUE;
    int _26442 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_50517)) {
        _1 = (long)(DBL_PTR(_x_50517)->dbl);
        DeRefDS(_x_50517);
        _x_50517 = _1;
    }

    /** 	cgi += 1*/
    _37cgi_50278 = _37cgi_50278 + 1;

    /** 	if cgi > length(cg_stack) then*/
    if (IS_SEQUENCE(_37cg_stack_50277)){
            _26442 = SEQ_PTR(_37cg_stack_50277)->length;
    }
    else {
        _26442 = 1;
    }
    if (_37cgi_50278 <= _26442)
    goto L1; // [20] 37

    /** 		cg_stack &= repeat(0, 400)*/
    _26444 = Repeat(0, 400);
    Concat((object_ptr)&_37cg_stack_50277, _37cg_stack_50277, _26444);
    DeRefDS(_26444);
    _26444 = NOVALUE;
L1: 

    /** 	cg_stack[cgi] = x*/
    _2 = (int)SEQ_PTR(_37cg_stack_50277);
    _2 = (int)(((s1_ptr)_2)->base + _37cgi_50278);
    _1 = *(int *)_2;
    *(int *)_2 = _x_50517;
    DeRef(_1);

    /** end procedure*/
    return;
    ;
}


int _37Top()
{
    int _26446 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return cg_stack[cgi]*/
    _2 = (int)SEQ_PTR(_37cg_stack_50277);
    _26446 = (int)*(((s1_ptr)_2)->base + _37cgi_50278);
    Ref(_26446);
    return _26446;
    ;
}


int _37Pop()
{
    int _t_50530 = NOVALUE;
    int _s_50536 = NOVALUE;
    int _26458 = NOVALUE;
    int _26456 = NOVALUE;
    int _26454 = NOVALUE;
    int _26451 = NOVALUE;
    int _26450 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	t = cg_stack[cgi]*/
    _2 = (int)SEQ_PTR(_37cg_stack_50277);
    _t_50530 = (int)*(((s1_ptr)_2)->base + _37cgi_50278);
    if (!IS_ATOM_INT(_t_50530)){
        _t_50530 = (long)DBL_PTR(_t_50530)->dbl;
    }

    /** 	cgi -= 1*/
    _37cgi_50278 = _37cgi_50278 - 1;

    /** 	if t > 0 then*/
    if (_t_50530 <= 0)
    goto L1; // [23] 116

    /** 		symtab_index s = t -- for type checking*/
    _s_50536 = _t_50530;

    /** 		if SymTab[t][S_MODE] = M_TEMP then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _26450 = (int)*(((s1_ptr)_2)->base + _t_50530);
    _2 = (int)SEQ_PTR(_26450);
    _26451 = (int)*(((s1_ptr)_2)->base + 3);
    _26450 = NOVALUE;
    if (binary_op_a(NOTEQ, _26451, 3)){
        _26451 = NOVALUE;
        goto L2; // [50] 115
    }
    _26451 = NOVALUE;

    /** 			if use_private_list = 0 then  -- no problem with reusing the temp*/
    if (_26use_private_list_12096 != 0)
    goto L3; // [58] 82

    /** 				SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_t_50530 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _26454 = NOVALUE;
    goto L4; // [79] 114
L3: 

    /** 			elsif find(t, private_sym) = 0 then*/
    _26456 = find_from(_t_50530, _26private_sym_12095, 1);
    if (_26456 != 0)
    goto L5; // [91] 113

    /** 				SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_t_50530 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _26458 = NOVALUE;
L5: 
L4: 
L2: 
L1: 

    /** 	return t*/
    return _t_50530;
    ;
}


void _37TempKeep(int _x_50564)
{
    int _26465 = NOVALUE;
    int _26464 = NOVALUE;
    int _26463 = NOVALUE;
    int _26462 = NOVALUE;
    int _26461 = NOVALUE;
    int _26460 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_x_50564)) {
        _1 = (long)(DBL_PTR(_x_50564)->dbl);
        DeRefDS(_x_50564);
        _x_50564 = _1;
    }

    /** 	if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26460 = (_x_50564 > 0);
    if (_26460 == 0) {
        goto L1; // [9] 53
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _26462 = (int)*(((s1_ptr)_2)->base + _x_50564);
    _2 = (int)SEQ_PTR(_26462);
    _26463 = (int)*(((s1_ptr)_2)->base + 3);
    _26462 = NOVALUE;
    if (IS_ATOM_INT(_26463)) {
        _26464 = (_26463 == 3);
    }
    else {
        _26464 = binary_op(EQUALS, _26463, 3);
    }
    _26463 = NOVALUE;
    if (_26464 == 0) {
        DeRef(_26464);
        _26464 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26464) && DBL_PTR(_26464)->dbl == 0.0){
            DeRef(_26464);
            _26464 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26464);
        _26464 = NOVALUE;
    }
    DeRef(_26464);
    _26464 = NOVALUE;

    /** 		SymTab[x][S_SCOPE] = IN_USE*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_x_50564 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _26465 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_26460);
    _26460 = NOVALUE;
    return;
    ;
}


void _37TempFree(int _x_50582)
{
    int _26471 = NOVALUE;
    int _26469 = NOVALUE;
    int _26468 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_x_50582)) {
        _1 = (long)(DBL_PTR(_x_50582)->dbl);
        DeRefDS(_x_50582);
        _x_50582 = _1;
    }

    /** 	if x > 0 then*/
    if (_x_50582 <= 0)
    goto L1; // [5] 53

    /** 		if SymTab[x][S_MODE] = M_TEMP then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _26468 = (int)*(((s1_ptr)_2)->base + _x_50582);
    _2 = (int)SEQ_PTR(_26468);
    _26469 = (int)*(((s1_ptr)_2)->base + 3);
    _26468 = NOVALUE;
    if (binary_op_a(NOTEQ, _26469, 3)){
        _26469 = NOVALUE;
        goto L2; // [25] 52
    }
    _26469 = NOVALUE;

    /** 			SymTab[x][S_SCOPE] = FREE*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_x_50582 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _26471 = NOVALUE;

    /** 			clear_temp( x )*/
    _37clear_temp(_x_50582);
L2: 
L1: 

    /** end procedure*/
    return;
    ;
}


void _37TempInteger(int _x_50601)
{
    int _26478 = NOVALUE;
    int _26477 = NOVALUE;
    int _26476 = NOVALUE;
    int _26475 = NOVALUE;
    int _26474 = NOVALUE;
    int _26473 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_x_50601)) {
        _1 = (long)(DBL_PTR(_x_50601)->dbl);
        DeRefDS(_x_50601);
        _x_50601 = _1;
    }

    /** 	if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26473 = (_x_50601 > 0);
    if (_26473 == 0) {
        goto L1; // [9] 53
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _26475 = (int)*(((s1_ptr)_2)->base + _x_50601);
    _2 = (int)SEQ_PTR(_26475);
    _26476 = (int)*(((s1_ptr)_2)->base + 3);
    _26475 = NOVALUE;
    if (IS_ATOM_INT(_26476)) {
        _26477 = (_26476 == 3);
    }
    else {
        _26477 = binary_op(EQUALS, _26476, 3);
    }
    _26476 = NOVALUE;
    if (_26477 == 0) {
        DeRef(_26477);
        _26477 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26477) && DBL_PTR(_26477)->dbl == 0.0){
            DeRef(_26477);
            _26477 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26477);
        _26477 = NOVALUE;
    }
    DeRef(_26477);
    _26477 = NOVALUE;

    /** 		SymTab[x][S_USAGE] = T_INTEGER*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _27SymTab_10921 = MAKE_SEQ(_2);
    }
    _3 = (int)(_x_50601 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _26478 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_26473);
    _26473 = NOVALUE;
    return;
    ;
}


int _37LexName(int _t_50618, int _defname_50619)
{
    int _name_50621 = NOVALUE;
    int _26487 = NOVALUE;
    int _26485 = NOVALUE;
    int _26483 = NOVALUE;
    int _26482 = NOVALUE;
    int _26481 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_t_50618)) {
        _1 = (long)(DBL_PTR(_t_50618)->dbl);
        DeRefDS(_t_50618);
        _t_50618 = _1;
    }

    /** 	for i = 1 to length(token_name) do*/
    _26481 = 80;
    {
        int _i_50623;
        _i_50623 = 1;
L1: 
        if (_i_50623 > 80){
            goto L2; // [12] 82
        }

        /** 		if t = token_name[i][LEX_NUMBER] then*/
        _2 = (int)SEQ_PTR(_37token_name_50285);
        _26482 = (int)*(((s1_ptr)_2)->base + _i_50623);
        _2 = (int)SEQ_PTR(_26482);
        _26483 = (int)*(((s1_ptr)_2)->base + 1);
        _26482 = NOVALUE;
        if (binary_op_a(NOTEQ, _t_50618, _26483)){
            _26483 = NOVALUE;
            goto L3; // [31] 75
        }
        _26483 = NOVALUE;

        /** 			name = token_name[i][LEX_NAME]*/
        _2 = (int)SEQ_PTR(_37token_name_50285);
        _26485 = (int)*(((s1_ptr)_2)->base + _i_50623);
        DeRef(_name_50621);
        _2 = (int)SEQ_PTR(_26485);
        _name_50621 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_name_50621);
        _26485 = NOVALUE;

        /** 			if not find(' ', name) then*/
        _26487 = find_from(32, _name_50621, 1);
        if (_26487 != 0)
        goto L4; // [56] 68
        _26487 = NOVALUE;

        /** 				name = "'" & name & "'"*/
        {
            int concat_list[3];

            concat_list[0] = _26489;
            concat_list[1] = _name_50621;
            concat_list[2] = _26489;
            Concat_N((object_ptr)&_name_50621, concat_list, 3);
        }
L4: 

        /** 			return name*/
        DeRefDS(_defname_50619);
        return _name_50621;
L3: 

        /** 	end for*/
        _i_50623 = _i_50623 + 1;
        goto L1; // [77] 19
L2: 
        ;
    }

    /** 	return defname -- try to avoid this case*/
    DeRef(_name_50621);
    return _defname_50619;
    ;
}


void _37InitEmit()
{
    int _0, _1, _2;
    

    /** 	cg_stack = repeat(0, 400)*/
    DeRef(_37cg_stack_50277);
    _37cg_stack_50277 = Repeat(0, 400);

    /** 	cgi = 0*/
    _37cgi_50278 = 0;

    /** end procedure*/
    return;
    ;
}


int _37IsInteger(int _sym_50642)
{
    int _mode_50643 = NOVALUE;
    int _t_50645 = NOVALUE;
    int _pt_50646 = NOVALUE;
    int _26512 = NOVALUE;
    int _26511 = NOVALUE;
    int _26509 = NOVALUE;
    int _26508 = NOVALUE;
    int _26507 = NOVALUE;
    int _26505 = NOVALUE;
    int _26504 = NOVALUE;
    int _26503 = NOVALUE;
    int _26502 = NOVALUE;
    int _26500 = NOVALUE;
    int _26496 = NOVALUE;
    int _26493 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_50642)) {
        _1 = (long)(DBL_PTR(_sym_50642)->dbl);
        DeRefDS(_sym_50642);
        _sym_50642 = _1;
    }

    /** 	if sym < 1 then*/
    if (_sym_50642 >= 1)
    goto L1; // [5] 16

    /** 		return 0*/
    return 0;
L1: 

    /** 	mode = SymTab[sym][S_MODE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _26493 = (int)*(((s1_ptr)_2)->base + _sym_50642);
    _2 = (int)SEQ_PTR(_26493);
    _mode_50643 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_50643)){
        _mode_50643 = (long)DBL_PTR(_mode_50643)->dbl;
    }
    _26493 = NOVALUE;

    /** 	if mode = M_NORMAL then*/
    if (_mode_50643 != 1)
    goto L2; // [36] 136

    /** 		t = SymTab[sym][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _26496 = (int)*(((s1_ptr)_2)->base + _sym_50642);
    _2 = (int)SEQ_PTR(_26496);
    _t_50645 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_t_50645)){
        _t_50645 = (long)DBL_PTR(_t_50645)->dbl;
    }
    _26496 = NOVALUE;

    /** 		if t = integer_type then*/
    if (_t_50645 != _52integer_type_46136)
    goto L3; // [60] 73

    /** 			return TRUE*/
    return _9TRUE_430;
L3: 

    /** 		if t > 0 then*/
    if (_t_50645 <= 0)
    goto L4; // [75] 215

    /** 			pt = SymTab[t][S_NEXT]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _26500 = (int)*(((s1_ptr)_2)->base + _t_50645);
    _2 = (int)SEQ_PTR(_26500);
    _pt_50646 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_pt_50646)){
        _pt_50646 = (long)DBL_PTR(_pt_50646)->dbl;
    }
    _26500 = NOVALUE;

    /** 			if pt and SymTab[pt][S_VTYPE] = integer_type then*/
    if (_pt_50646 == 0) {
        goto L4; // [97] 215
    }
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _26503 = (int)*(((s1_ptr)_2)->base + _pt_50646);
    _2 = (int)SEQ_PTR(_26503);
    _26504 = (int)*(((s1_ptr)_2)->base + 15);
    _26503 = NOVALUE;
    if (IS_ATOM_INT(_26504)) {
        _26505 = (_26504 == _52integer_type_46136);
    }
    else {
        _26505 = binary_op(EQUALS, _26504, _52integer_type_46136);
    }
    _26504 = NOVALUE;
    if (_26505 == 0) {
        DeRef(_26505);
        _26505 = NOVALUE;
        goto L4; // [120] 215
    }
    else {
        if (!IS_ATOM_INT(_26505) && DBL_PTR(_26505)->dbl == 0.0){
            DeRef(_26505);
            _26505 = NOVALUE;
            goto L4; // [120] 215
        }
        DeRef(_26505);
        _26505 = NOVALUE;
    }
    DeRef(_26505);
    _26505 = NOVALUE;

    /** 				return TRUE   -- usertype(integer x)*/
    return _9TRUE_430;
    goto L4; // [133] 215
L2: 

    /** 	elsif mode = M_CONSTANT then*/
    if (_mode_50643 != 2)
    goto L5; // [140] 176

    /** 		if integer(SymTab[sym][S_OBJ]) then  -- bug fixed: can't allow PLUS1_I op*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _26507 = (int)*(((s1_ptr)_2)->base + _sym_50642);
    _2 = (int)SEQ_PTR(_26507);
    _26508 = (int)*(((s1_ptr)_2)->base + 1);
    _26507 = NOVALUE;
    if (IS_ATOM_INT(_26508))
    _26509 = 1;
    else if (IS_ATOM_DBL(_26508))
    _26509 = IS_ATOM_INT(DoubleToInt(_26508));
    else
    _26509 = 0;
    _26508 = NOVALUE;
    if (_26509 == 0)
    {
        _26509 = NOVALUE;
        goto L4; // [161] 215
    }
    else{
        _26509 = NOVALUE;
    }

    /** 			return TRUE*/
    return _9TRUE_430;
    goto L4; // [173] 215
L5: 

    /** 	elsif mode = M_TEMP then*/
    if (_mode_50643 != 3)
    goto L6; // [180] 214

    /** 		if SymTab[sym][S_USAGE] = T_INTEGER then*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _26511 = (int)*(((s1_ptr)_2)->base + _sym_50642);
    _2 = (int)SEQ_PTR(_26511);
    _26512 = (int)*(((s1_ptr)_2)->base + 5);
    _26511 = NOVALUE;
    if (binary_op_a(NOTEQ, _26512, 1)){
        _26512 = NOVALUE;
        goto L7; // [200] 213
    }
    _26512 = NOVALUE;

    /** 			return TRUE*/
    return _9TRUE_430;
L7: 
L6: 
L4: 

    /** 	return FALSE*/
    return _9FALSE_428;
    ;
}


void _37emit(int _val_50703)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_val_50703)) {
        _1 = (long)(DBL_PTR(_val_50703)->dbl);
        DeRefDS(_val_50703);
        _val_50703 = _1;
    }

    /** 	Code = append(Code, val)*/
    Append(&_26Code_12071, _26Code_12071, _val_50703);

    /** end procedure*/
    return;
    ;
}


void _37emit_opnd(int _opnd_50710)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opnd_50710)) {
        _1 = (long)(DBL_PTR(_opnd_50710)->dbl);
        DeRefDS(_opnd_50710);
        _opnd_50710 = _1;
    }

    /** 		Push(opnd)*/
    _37Push(_opnd_50710);

    /** 		previous_op = -1  -- N.B.*/
    _26previous_op_12081 = -1;

    /** end procedure*/
    return;
    ;
}


void _37emit_addr(int _x_50714)
{
    int _0, _1, _2;
    

    /** 		Code = append(Code, x)*/
    Ref(_x_50714);
    Append(&_26Code_12071, _26Code_12071, _x_50714);

    /** end procedure*/
    DeRef(_x_50714);
    return;
    ;
}


void _37emit_opcode(int _op_50720)
{
    int _0, _1, _2;
    

    /** 	Code = append(Code, op)*/
    Append(&_26Code_12071, _26Code_12071, _op_50720);

    /** end procedure*/
    return;
    ;
}


void _37emit_temp(int _tempsym_50754, int _referenced_50755)
{
    int _26543 = NOVALUE;
    int _26542 = NOVALUE;
    int _26541 = NOVALUE;
    int _26540 = NOVALUE;
    int _26539 = NOVALUE;
    int _26538 = NOVALUE;
    int _26537 = NOVALUE;
    int _26536 = NOVALUE;
    int _26535 = NOVALUE;
    int _26534 = NOVALUE;
    int _26533 = NOVALUE;
    int _26532 = NOVALUE;
    int _26531 = NOVALUE;
    int _26530 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_referenced_50755)) {
        _1 = (long)(DBL_PTR(_referenced_50755)->dbl);
        DeRefDS(_referenced_50755);
        _referenced_50755 = _1;
    }

    /** 	if not TRANSLATE  then -- translator has its own way of handling temps*/
    if (_26TRANSLATE_11619 != 0)
    goto L1; // [7] 129

    /** 		if sequence(tempsym) then*/
    _26530 = IS_SEQUENCE(_tempsym_50754);
    if (_26530 == 0)
    {
        _26530 = NOVALUE;
        goto L2; // [15] 53
    }
    else{
        _26530 = NOVALUE;
    }

    /** 			for i = 1 to length(tempsym) do*/
    if (IS_SEQUENCE(_tempsym_50754)){
            _26531 = SEQ_PTR(_tempsym_50754)->length;
    }
    else {
        _26531 = 1;
    }
    {
        int _i_50762;
        _i_50762 = 1;
L3: 
        if (_i_50762 > _26531){
            goto L4; // [23] 50
        }

        /** 				emit_temp( tempsym[i], referenced )*/
        _2 = (int)SEQ_PTR(_tempsym_50754);
        _26532 = (int)*(((s1_ptr)_2)->base + _i_50762);
        DeRef(_26533);
        _26533 = _referenced_50755;
        Ref(_26532);
        _37emit_temp(_26532, _26533);
        _26532 = NOVALUE;
        _26533 = NOVALUE;

        /** 			end for*/
        _i_50762 = _i_50762 + 1;
        goto L3; // [45] 30
L4: 
        ;
    }
    goto L5; // [50] 128
L2: 

    /** 		elsif tempsym > 0*/
    if (IS_ATOM_INT(_tempsym_50754)) {
        _26534 = (_tempsym_50754 > 0);
    }
    else {
        _26534 = binary_op(GREATER, _tempsym_50754, 0);
    }
    if (IS_ATOM_INT(_26534)) {
        if (_26534 == 0) {
            DeRef(_26535);
            _26535 = 0;
            goto L6; // [59] 77
        }
    }
    else {
        if (DBL_PTR(_26534)->dbl == 0.0) {
            DeRef(_26535);
            _26535 = 0;
            goto L6; // [59] 77
        }
    }
    Ref(_tempsym_50754);
    _26536 = _52sym_mode(_tempsym_50754);
    if (IS_ATOM_INT(_26536)) {
        _26537 = (_26536 == 3);
    }
    else {
        _26537 = binary_op(EQUALS, _26536, 3);
    }
    DeRef(_26536);
    _26536 = NOVALUE;
    DeRef(_26535);
    if (IS_ATOM_INT(_26537))
    _26535 = (_26537 != 0);
    else
    _26535 = DBL_PTR(_26537)->dbl != 0.0;
L6: 
    if (_26535 == 0) {
        _26538 = 0;
        goto L7; // [77] 92
    }
    Ref(_tempsym_50754);
    _26539 = _37IsInteger(_tempsym_50754);
    if (IS_ATOM_INT(_26539)) {
        _26540 = (_26539 == 0);
    }
    else {
        _26540 = unary_op(NOT, _26539);
    }
    DeRef(_26539);
    _26539 = NOVALUE;
    if (IS_ATOM_INT(_26540))
    _26538 = (_26540 != 0);
    else
    _26538 = DBL_PTR(_26540)->dbl != 0.0;
L7: 
    if (_26538 == 0) {
        goto L8; // [92] 127
    }
    _26542 = find_from(_tempsym_50754, _37emitted_temps_50750, 1);
    _26543 = (_26542 == 0);
    _26542 = NOVALUE;
    if (_26543 == 0)
    {
        DeRef(_26543);
        _26543 = NOVALUE;
        goto L8; // [107] 127
    }
    else{
        DeRef(_26543);
        _26543 = NOVALUE;
    }

    /** 			emitted_temps &= tempsym*/
    if (IS_SEQUENCE(_37emitted_temps_50750) && IS_ATOM(_tempsym_50754)) {
        Ref(_tempsym_50754);
        Append(&_37emitted_temps_50750, _37emitted_temps_50750, _tempsym_50754);
    }
    else if (IS_ATOM(_37emitted_temps_50750) && IS_SEQUENCE(_tempsym_50754)) {
    }
    else {
        Concat((object_ptr)&_37emitted_temps_50750, _37emitted_temps_50750, _tempsym_50754);
    }

    /** 			emitted_temp_referenced &= referenced*/
    Append(&_37emitted_temp_referenced_50751, _37emitted_temp_referenced_50751, _referenced_50755);
L8: 
L5: 
L1: 

    /** end procedure*/
    DeRef(_tempsym_50754);
    DeRef(_26534);
    _26534 = NOVALUE;
    DeRef(_26540);
    _26540 = NOVALUE;
    DeRef(_26537);
    _26537 = NOVALUE;
    return;
    ;
}


void _37flush_temps(int _except_for_50784)
{
    int _refs_50787 = NOVALUE;
    int _novalues_50788 = NOVALUE;
    int _sym_50793 = NOVALUE;
    int _26558 = NOVALUE;
    int _26557 = NOVALUE;
    int _26556 = NOVALUE;
    int _26555 = NOVALUE;
    int _26553 = NOVALUE;
    int _26549 = NOVALUE;
    int _26548 = NOVALUE;
    int _26546 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if TRANSLATE then*/
    if (_26TRANSLATE_11619 == 0)
    {
        goto L1; // [7] 16
    }
    else{
    }

    /** 		return*/
    DeRefDS(_except_for_50784);
    DeRef(_refs_50787);
    DeRefi(_novalues_50788);
    return;
L1: 

    /** 	sequence*/

    /** 		refs = {},*/
    RefDS(_22037);
    DeRef(_refs_50787);
    _refs_50787 = _22037;

    /** 		novalues = {}*/
    RefDS(_22037);
    DeRefi(_novalues_50788);
    _novalues_50788 = _22037;

    /** 	derefs = {}*/
    RefDS(_22037);
    DeRefi(_37derefs_50781);
    _37derefs_50781 = _22037;

    /** 	for i = 1 to length( emitted_temps ) do*/
    if (IS_SEQUENCE(_37emitted_temps_50750)){
            _26546 = SEQ_PTR(_37emitted_temps_50750)->length;
    }
    else {
        _26546 = 1;
    }
    {
        int _i_50790;
        _i_50790 = 1;
L2: 
        if (_i_50790 > _26546){
            goto L3; // [46] 119
        }

        /** 		symtab_index sym = emitted_temps[i]*/
        _2 = (int)SEQ_PTR(_37emitted_temps_50750);
        _sym_50793 = (int)*(((s1_ptr)_2)->base + _i_50790);
        if (!IS_ATOM_INT(_sym_50793)){
            _sym_50793 = (long)DBL_PTR(_sym_50793)->dbl;
        }

        /** 		if find( sym, except_for ) then*/
        _26548 = find_from(_sym_50793, _except_for_50784, 1);
        if (_26548 == 0)
        {
            _26548 = NOVALUE;
            goto L4; // [70] 80
        }
        else{
            _26548 = NOVALUE;
        }

        /** 			continue*/
        goto L5; // [77] 114
L4: 

        /** 		if emitted_temp_referenced[i] = NEW_REFERENCE then*/
        _2 = (int)SEQ_PTR(_37emitted_temp_referenced_50751);
        _26549 = (int)*(((s1_ptr)_2)->base + _i_50790);
        if (binary_op_a(NOTEQ, _26549, 1)){
            _26549 = NOVALUE;
            goto L6; // [88] 103
        }
        _26549 = NOVALUE;

        /** 			derefs &= sym*/
        Append(&_37derefs_50781, _37derefs_50781, _sym_50793);
        goto L7; // [100] 110
L6: 

        /** 			novalues &= sym*/
        Append(&_novalues_50788, _novalues_50788, _sym_50793);
L7: 

        /** 	end for*/
L5: 
        _i_50790 = _i_50790 + 1;
        goto L2; // [114] 53
L3: 
        ;
    }

    /** 	if not length( except_for ) then*/
    if (IS_SEQUENCE(_except_for_50784)){
            _26553 = SEQ_PTR(_except_for_50784)->length;
    }
    else {
        _26553 = 1;
    }
    if (_26553 != 0)
    goto L8; // [124] 132
    _26553 = NOVALUE;

    /** 		clear_last()*/
    _37clear_last();
L8: 

    /** 	for i = 1 to length( derefs ) do*/
    if (IS_SEQUENCE(_37derefs_50781)){
            _26555 = SEQ_PTR(_37derefs_50781)->length;
    }
    else {
        _26555 = 1;
    }
    {
        int _i_50808;
        _i_50808 = 1;
L9: 
        if (_i_50808 > _26555){
            goto LA; // [139] 171
        }

        /** 		emit( DEREF_TEMP )*/
        _37emit(208);

        /** 		emit( derefs[i] )*/
        _2 = (int)SEQ_PTR(_37derefs_50781);
        _26556 = (int)*(((s1_ptr)_2)->base + _i_50808);
        _37emit(_26556);
        _26556 = NOVALUE;

        /** 	end for*/
        _i_50808 = _i_50808 + 1;
        goto L9; // [166] 146
LA: 
        ;
    }

    /** 	for i = 1 to length( novalues ) do*/
    if (IS_SEQUENCE(_novalues_50788)){
            _26557 = SEQ_PTR(_novalues_50788)->length;
    }
    else {
        _26557 = 1;
    }
    {
        int _i_50813;
        _i_50813 = 1;
LB: 
        if (_i_50813 > _26557){
            goto LC; // [176] 206
        }

        /** 		emit( NOVALUE_TEMP )*/
        _37emit(209);

        /** 		emit( novalues[i] )*/
        _2 = (int)SEQ_PTR(_novalues_50788);
        _26558 = (int)*(((s1_ptr)_2)->base + _i_50813);
        _37emit(_26558);
        _26558 = NOVALUE;

        /** 	end for*/
        _i_50813 = _i_50813 + 1;
        goto LB; // [201] 183
LC: 
        ;
    }

    /** 	emitted_temps = {}*/
    RefDS(_22037);
    DeRef(_37emitted_temps_50750);
    _37emitted_temps_50750 = _22037;

    /** 	emitted_temp_referenced = {}*/
    RefDS(_22037);
    DeRef(_37emitted_temp_referenced_50751);
    _37emitted_temp_referenced_50751 = _22037;

    /** end procedure*/
    DeRefDS(_except_for_50784);
    DeRef(_refs_50787);
    DeRefi(_novalues_50788);
    return;
    ;
}


void _37flush_temp(int _temp_50820)
{
    int _except_for_50821 = NOVALUE;
    int _ix_50822 = NOVALUE;
    int _26560 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_temp_50820)) {
        _1 = (long)(DBL_PTR(_temp_50820)->dbl);
        DeRefDS(_temp_50820);
        _temp_50820 = _1;
    }

    /** 	sequence except_for = emitted_temps*/
    RefDS(_37emitted_temps_50750);
    DeRef(_except_for_50821);
    _except_for_50821 = _37emitted_temps_50750;

    /** 	integer ix = find( temp, emitted_temps )*/
    _ix_50822 = find_from(_temp_50820, _37emitted_temps_50750, 1);

    /** 	if ix then*/
    if (_ix_50822 == 0)
    {
        goto L1; // [23] 37
    }
    else{
    }

    /** 		flush_temps( remove( except_for, ix ) )*/
    {
        s1_ptr assign_space = SEQ_PTR(_except_for_50821);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_50822)) ? _ix_50822 : (long)(DBL_PTR(_ix_50822)->dbl);
        int stop = (IS_ATOM_INT(_ix_50822)) ? _ix_50822 : (long)(DBL_PTR(_ix_50822)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
            RefDS(_except_for_50821);
            DeRef(_26560);
            _26560 = _except_for_50821;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_except_for_50821), start, &_26560 );
            }
            else Tail(SEQ_PTR(_except_for_50821), stop+1, &_26560);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_except_for_50821), start, &_26560);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_26560);
            _26560 = _1;
        }
    }
    _37flush_temps(_26560);
    _26560 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_except_for_50821);
    return;
    ;
}


void _37check_for_temps()
{
    int _26567 = NOVALUE;
    int _26566 = NOVALUE;
    int _26565 = NOVALUE;
    int _26564 = NOVALUE;
    int _26562 = NOVALUE;
    int _26561 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if TRANSLATE or last_op < 1 or last_pc < 1 then*/
    if (_26TRANSLATE_11619 != 0) {
        _26561 = 1;
        goto L1; // [5] 19
    }
    _26562 = (_37last_op_51156 < 1);
    _26561 = (_26562 != 0);
L1: 
    if (_26561 != 0) {
        goto L2; // [19] 34
    }
    _26564 = (_37last_pc_51157 < 1);
    if (_26564 == 0)
    {
        DeRef(_26564);
        _26564 = NOVALUE;
        goto L3; // [30] 40
    }
    else{
        DeRef(_26564);
        _26564 = NOVALUE;
    }
L2: 

    /** 		return*/
    DeRef(_26562);
    _26562 = NOVALUE;
    return;
L3: 

    /** 	emit_temp( get_target_sym( current_op( last_pc ) ), op_temp_ref[last_op] )*/
    RefDS(_26Code_12071);
    _26565 = _64current_op(_37last_pc_51157, _26Code_12071);
    _26566 = _64get_target_sym(_26565);
    _26565 = NOVALUE;
    _2 = (int)SEQ_PTR(_37op_temp_ref_50972);
    _26567 = (int)*(((s1_ptr)_2)->base + _37last_op_51156);
    _37emit_temp(_26566, _26567);
    _26566 = NOVALUE;
    _26567 = NOVALUE;

    /** end procedure*/
    DeRef(_26562);
    _26562 = NOVALUE;
    return;
    ;
}


void _37clear_temp(int _tempsym_50847)
{
    int _ix_50848 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_tempsym_50847)) {
        _1 = (long)(DBL_PTR(_tempsym_50847)->dbl);
        DeRefDS(_tempsym_50847);
        _tempsym_50847 = _1;
    }

    /** 	integer ix = find( tempsym, emitted_temps )*/
    _ix_50848 = find_from(_tempsym_50847, _37emitted_temps_50750, 1);

    /** 	if ix then*/
    if (_ix_50848 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** 		emitted_temps = remove( emitted_temps, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_37emitted_temps_50750);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_50848)) ? _ix_50848 : (long)(DBL_PTR(_ix_50848)->dbl);
        int stop = (IS_ATOM_INT(_ix_50848)) ? _ix_50848 : (long)(DBL_PTR(_ix_50848)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_37emitted_temps_50750), start, &_37emitted_temps_50750 );
            }
            else Tail(SEQ_PTR(_37emitted_temps_50750), stop+1, &_37emitted_temps_50750);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_37emitted_temps_50750), start, &_37emitted_temps_50750);
        }
        else {
            assign_slice_seq = &assign_space;
            _37emitted_temps_50750 = Remove_elements(start, stop, (SEQ_PTR(_37emitted_temps_50750)->ref == 1));
        }
    }

    /** 		emitted_temp_referenced = remove( emitted_temp_referenced, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_37emitted_temp_referenced_50751);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_50848)) ? _ix_50848 : (long)(DBL_PTR(_ix_50848)->dbl);
        int stop = (IS_ATOM_INT(_ix_50848)) ? _ix_50848 : (long)(DBL_PTR(_ix_50848)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_37emitted_temp_referenced_50751), start, &_37emitted_temp_referenced_50751 );
            }
            else Tail(SEQ_PTR(_37emitted_temp_referenced_50751), stop+1, &_37emitted_temp_referenced_50751);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_37emitted_temp_referenced_50751), start, &_37emitted_temp_referenced_50751);
        }
        else {
            assign_slice_seq = &assign_space;
            _37emitted_temp_referenced_50751 = Remove_elements(start, stop, (SEQ_PTR(_37emitted_temp_referenced_50751)->ref == 1));
        }
    }
L1: 

    /** end procedure*/
    return;
    ;
}


int _37pop_temps()
{
    int _new_emitted_50855 = NOVALUE;
    int _new_referenced_50856 = NOVALUE;
    int _26571 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence new_emitted  = emitted_temps*/
    RefDS(_37emitted_temps_50750);
    DeRef(_new_emitted_50855);
    _new_emitted_50855 = _37emitted_temps_50750;

    /** 	sequence new_referenced = emitted_temp_referenced*/
    RefDS(_37emitted_temp_referenced_50751);
    DeRef(_new_referenced_50856);
    _new_referenced_50856 = _37emitted_temp_referenced_50751;

    /** 	emitted_temps  = {}*/
    RefDS(_22037);
    DeRefDS(_37emitted_temps_50750);
    _37emitted_temps_50750 = _22037;

    /** 	emitted_temp_referenced = {}*/
    RefDS(_22037);
    DeRefDS(_37emitted_temp_referenced_50751);
    _37emitted_temp_referenced_50751 = _22037;

    /** 	return { new_emitted, new_referenced }*/
    RefDS(_new_referenced_50856);
    RefDS(_new_emitted_50855);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _new_emitted_50855;
    ((int *)_2)[2] = _new_referenced_50856;
    _26571 = MAKE_SEQ(_1);
    DeRefDS(_new_emitted_50855);
    DeRefDS(_new_referenced_50856);
    return _26571;
    ;
}


int _37get_temps(int _add_to_50860)
{
    int _26576 = NOVALUE;
    int _26575 = NOVALUE;
    int _26574 = NOVALUE;
    int _26573 = NOVALUE;
    int _0, _1, _2;
    

    /** 	add_to[1] &= emitted_temps*/
    _2 = (int)SEQ_PTR(_add_to_50860);
    _26573 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_26573) && IS_ATOM(_37emitted_temps_50750)) {
    }
    else if (IS_ATOM(_26573) && IS_SEQUENCE(_37emitted_temps_50750)) {
        Ref(_26573);
        Prepend(&_26574, _37emitted_temps_50750, _26573);
    }
    else {
        Concat((object_ptr)&_26574, _26573, _37emitted_temps_50750);
        _26573 = NOVALUE;
    }
    _26573 = NOVALUE;
    _2 = (int)SEQ_PTR(_add_to_50860);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _add_to_50860 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _26574;
    if( _1 != _26574 ){
        DeRef(_1);
    }
    _26574 = NOVALUE;

    /** 	add_to[2] &= emitted_temp_referenced*/
    _2 = (int)SEQ_PTR(_add_to_50860);
    _26575 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_26575) && IS_ATOM(_37emitted_temp_referenced_50751)) {
    }
    else if (IS_ATOM(_26575) && IS_SEQUENCE(_37emitted_temp_referenced_50751)) {
        Ref(_26575);
        Prepend(&_26576, _37emitted_temp_referenced_50751, _26575);
    }
    else {
        Concat((object_ptr)&_26576, _26575, _37emitted_temp_referenced_50751);
        _26575 = NOVALUE;
    }
    _26575 = NOVALUE;
    _2 = (int)SEQ_PTR(_add_to_50860);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _add_to_50860 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _26576;
    if( _1 != _26576 ){
        DeRef(_1);
    }
    _26576 = NOVALUE;

    /** 	return add_to*/
    return _add_to_50860;
    ;
}


void _37push_temps(int _temps_50868)
{
    int _26579 = NOVALUE;
    int _26577 = NOVALUE;
    int _0, _1, _2;
    

    /** 	emitted_temps &= temps[1]*/
    _2 = (int)SEQ_PTR(_temps_50868);
    _26577 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_37emitted_temps_50750) && IS_ATOM(_26577)) {
        Ref(_26577);
        Append(&_37emitted_temps_50750, _37emitted_temps_50750, _26577);
    }
    else if (IS_ATOM(_37emitted_temps_50750) && IS_SEQUENCE(_26577)) {
    }
    else {
        Concat((object_ptr)&_37emitted_temps_50750, _37emitted_temps_50750, _26577);
    }
    _26577 = NOVALUE;

    /** 	emitted_temp_referenced &= temps[2]*/
    _2 = (int)SEQ_PTR(_temps_50868);
    _26579 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_37emitted_temp_referenced_50751) && IS_ATOM(_26579)) {
        Ref(_26579);
        Append(&_37emitted_temp_referenced_50751, _37emitted_temp_referenced_50751, _26579);
    }
    else if (IS_ATOM(_37emitted_temp_referenced_50751) && IS_SEQUENCE(_26579)) {
    }
    else {
        Concat((object_ptr)&_37emitted_temp_referenced_50751, _37emitted_temp_referenced_50751, _26579);
    }
    _26579 = NOVALUE;

    /** 	flush_temps()*/
    RefDS(_22037);
    _37flush_temps(_22037);

    /** end procedure*/
    DeRefDS(_temps_50868);
    return;
    ;
}


void _37backpatch(int _index_50875, int _val_50876)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_index_50875)) {
        _1 = (long)(DBL_PTR(_index_50875)->dbl);
        DeRefDS(_index_50875);
        _index_50875 = _1;
    }
    if (!IS_ATOM_INT(_val_50876)) {
        _1 = (long)(DBL_PTR(_val_50876)->dbl);
        DeRefDS(_val_50876);
        _val_50876 = _1;
    }

    /** 		Code[index] = val*/
    _2 = (int)SEQ_PTR(_26Code_12071);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _26Code_12071 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index_50875);
    _1 = *(int *)_2;
    *(int *)_2 = _val_50876;
    DeRef(_1);

    /** end procedure*/
    return;
    ;
}


void _37cont11ii(int _op_51057, int _ii_51059)
{
    int _t_51060 = NOVALUE;
    int _source_51061 = NOVALUE;
    int _c_51062 = NOVALUE;
    int _26588 = NOVALUE;
    int _26587 = NOVALUE;
    int _26585 = NOVALUE;
    int _0, _1, _2;
    

    /** 	emit_opcode(op)*/
    _37emit_opcode(_op_51057);

    /** 	source = Pop()*/
    _source_51061 = _37Pop();
    if (!IS_ATOM_INT(_source_51061)) {
        _1 = (long)(DBL_PTR(_source_51061)->dbl);
        DeRefDS(_source_51061);
        _source_51061 = _1;
    }

    /** 	emit_addr(source)*/
    _37emit_addr(_source_51061);

    /** 	assignable = TRUE*/
    _37assignable_50280 = _9TRUE_430;

    /** 	t = op_result[op]*/
    _2 = (int)SEQ_PTR(_37op_result_50878);
    _t_51060 = (int)*(((s1_ptr)_2)->base + _op_51057);

    /** 	if t = T_INTEGER or (ii and IsInteger(source)) then*/
    _26585 = (_t_51060 == 1);
    if (_26585 != 0) {
        goto L1; // [43] 64
    }
    if (_ii_51059 == 0) {
        _26587 = 0;
        goto L2; // [47] 59
    }
    _26588 = _37IsInteger(_source_51061);
    if (IS_ATOM_INT(_26588))
    _26587 = (_26588 != 0);
    else
    _26587 = DBL_PTR(_26588)->dbl != 0.0;
L2: 
    if (_26587 == 0)
    {
        _26587 = NOVALUE;
        goto L3; // [60] 80
    }
    else{
        _26587 = NOVALUE;
    }
L1: 

    /** 		c = NewTempSym()*/
    _c_51062 = _52NewTempSym(0);
    if (!IS_ATOM_INT(_c_51062)) {
        _1 = (long)(DBL_PTR(_c_51062)->dbl);
        DeRefDS(_c_51062);
        _c_51062 = _1;
    }

    /** 		TempInteger(c)*/
    _37TempInteger(_c_51062);
    goto L4; // [77] 95
L3: 

    /** 		c = NewTempSym() -- allocate *after* checking opnd type*/
    _c_51062 = _52NewTempSym(0);
    if (!IS_ATOM_INT(_c_51062)) {
        _1 = (long)(DBL_PTR(_c_51062)->dbl);
        DeRefDS(_c_51062);
        _c_51062 = _1;
    }

    /** 		emit_temp( c, NEW_REFERENCE )*/
    _37emit_temp(_c_51062, 1);
L4: 

    /** 	Push(c)*/
    _37Push(_c_51062);

    /** 	emit_addr(c)*/
    _37emit_addr(_c_51062);

    /** end procedure*/
    DeRef(_26585);
    _26585 = NOVALUE;
    DeRef(_26588);
    _26588 = NOVALUE;
    return;
    ;
}


void _37cont21d(int _op_51079, int _a_51080, int _b_51081, int _ii_51083)
{
    int _c_51084 = NOVALUE;
    int _t_51085 = NOVALUE;
    int _26598 = NOVALUE;
    int _26597 = NOVALUE;
    int _26596 = NOVALUE;
    int _26595 = NOVALUE;
    int _26593 = NOVALUE;
    int _0, _1, _2;
    

    /** 	assignable = TRUE*/
    _37assignable_50280 = _9TRUE_430;

    /** 	t = op_result[op]*/
    _2 = (int)SEQ_PTR(_37op_result_50878);
    _t_51085 = (int)*(((s1_ptr)_2)->base + _op_51079);

    /** 	if op = C_FUNC then*/
    if (_op_51079 != 133)
    goto L1; // [26] 38

    /** 		emit_addr(CurrentSub)*/
    _37emit_addr(_26CurrentSub_11990);
L1: 

    /** 	if t = T_INTEGER or (ii and IsInteger(a) and IsInteger(b)) then*/
    _26593 = (_t_51085 == 1);
    if (_26593 != 0) {
        goto L2; // [46] 79
    }
    if (_ii_51083 == 0) {
        _26595 = 0;
        goto L3; // [50] 62
    }
    _26596 = _37IsInteger(_a_51080);
    if (IS_ATOM_INT(_26596))
    _26595 = (_26596 != 0);
    else
    _26595 = DBL_PTR(_26596)->dbl != 0.0;
L3: 
    if (_26595 == 0) {
        DeRef(_26597);
        _26597 = 0;
        goto L4; // [62] 74
    }
    _26598 = _37IsInteger(_b_51081);
    if (IS_ATOM_INT(_26598))
    _26597 = (_26598 != 0);
    else
    _26597 = DBL_PTR(_26598)->dbl != 0.0;
L4: 
    if (_26597 == 0)
    {
        _26597 = NOVALUE;
        goto L5; // [75] 95
    }
    else{
        _26597 = NOVALUE;
    }
L2: 

    /** 		c = NewTempSym()*/
    _c_51084 = _52NewTempSym(0);
    if (!IS_ATOM_INT(_c_51084)) {
        _1 = (long)(DBL_PTR(_c_51084)->dbl);
        DeRefDS(_c_51084);
        _c_51084 = _1;
    }

    /** 		TempInteger(c)*/
    _37TempInteger(_c_51084);
    goto L6; // [92] 110
L5: 

    /** 		c = NewTempSym() -- allocate *after* checking opnd types*/
    _c_51084 = _52NewTempSym(0);
    if (!IS_ATOM_INT(_c_51084)) {
        _1 = (long)(DBL_PTR(_c_51084)->dbl);
        DeRefDS(_c_51084);
        _c_51084 = _1;
    }

    /** 		emit_temp( c, NEW_REFERENCE )*/
    _37emit_temp(_c_51084, 1);
L6: 

    /** 	Push(c)*/
    _37Push(_c_51084);

    /** 	emit_addr(c)*/
    _37emit_addr(_c_51084);

    /** end procedure*/
    DeRef(_26593);
    _26593 = NOVALUE;
    DeRef(_26596);
    _26596 = NOVALUE;
    DeRef(_26598);
    _26598 = NOVALUE;
    return;
    ;
}


void _37cont21ii(int _op_51107, int _ii_51109)
{
    int _a_51110 = NOVALUE;
    int _b_51111 = NOVALUE;
    int _0, _1, _2;
    

    /** 	b = Pop()*/
    _b_51111 = _37Pop();
    if (!IS_ATOM_INT(_b_51111)) {
        _1 = (long)(DBL_PTR(_b_51111)->dbl);
        DeRefDS(_b_51111);
        _b_51111 = _1;
    }

    /** 	emit_opcode(op)*/
    _37emit_opcode(_op_51107);

    /** 	a = Pop()*/
    _a_51110 = _37Pop();
    if (!IS_ATOM_INT(_a_51110)) {
        _1 = (long)(DBL_PTR(_a_51110)->dbl);
        DeRefDS(_a_51110);
        _a_51110 = _1;
    }

    /** 	emit_addr(a)*/
    _37emit_addr(_a_51110);

    /** 	emit_addr(b)*/
    _37emit_addr(_b_51111);

    /** 	cont21d(op, a, b, ii)*/
    _37cont21d(_op_51107, _a_51110, _b_51111, _ii_51109);

    /** end procedure*/
    return;
    ;
}


int _37good_string(int _elements_51116)
{
    int _obj_51117 = NOVALUE;
    int _ep_51119 = NOVALUE;
    int _e_51121 = NOVALUE;
    int _element_vals_51122 = NOVALUE;
    int _26621 = NOVALUE;
    int _26620 = NOVALUE;
    int _26619 = NOVALUE;
    int _26618 = NOVALUE;
    int _26617 = NOVALUE;
    int _26616 = NOVALUE;
    int _26615 = NOVALUE;
    int _26614 = NOVALUE;
    int _26613 = NOVALUE;
    int _26612 = NOVALUE;
    int _26611 = NOVALUE;
    int _26609 = NOVALUE;
    int _26606 = NOVALUE;
    int _26605 = NOVALUE;
    int _26604 = NOVALUE;
    int _26603 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence element_vals*/

    /** 	if TRANSLATE and length(elements) > 10000 then*/
    if (_26TRANSLATE_11619 == 0) {
        goto L1; // [9] 31
    }
    if (IS_SEQUENCE(_elements_51116)){
            _26604 = SEQ_PTR(_elements_51116)->length;
    }
    else {
        _26604 = 1;
    }
    _26605 = (_26604 > 10000);
    _26604 = NOVALUE;
    if (_26605 == 0)
    {
        DeRef(_26605);
        _26605 = NOVALUE;
        goto L1; // [21] 31
    }
    else{
        DeRef(_26605);
        _26605 = NOVALUE;
    }

    /** 		return -1 -- A huge string might upset the C compiler.*/
    DeRefDS(_elements_51116);
    DeRef(_obj_51117);
    DeRef(_element_vals_51122);
    return -1;
L1: 

    /** 	element_vals = {}*/
    RefDS(_22037);
    DeRef(_element_vals_51122);
    _element_vals_51122 = _22037;

    /** 	for i = 1 to length(elements) do*/
    if (IS_SEQUENCE(_elements_51116)){
            _26606 = SEQ_PTR(_elements_51116)->length;
    }
    else {
        _26606 = 1;
    }
    {
        int _i_51129;
        _i_51129 = 1;
L2: 
        if (_i_51129 > _26606){
            goto L3; // [43] 183
        }

        /** 		ep = elements[i]*/
        _2 = (int)SEQ_PTR(_elements_51116);
        _ep_51119 = (int)*(((s1_ptr)_2)->base + _i_51129);
        if (!IS_ATOM_INT(_ep_51119)){
            _ep_51119 = (long)DBL_PTR(_ep_51119)->dbl;
        }

        /** 		if ep < 1 then*/
        if (_ep_51119 >= 1)
        goto L4; // [60] 71

        /** 			return -1*/
        DeRefDS(_elements_51116);
        DeRef(_obj_51117);
        DeRef(_element_vals_51122);
        return -1;
L4: 

        /** 		e = ep*/
        _e_51121 = _ep_51119;

        /** 		obj = SymTab[e][S_OBJ]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26609 = (int)*(((s1_ptr)_2)->base + _e_51121);
        DeRef(_obj_51117);
        _2 = (int)SEQ_PTR(_26609);
        _obj_51117 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_obj_51117);
        _26609 = NOVALUE;

        /** 		if SymTab[e][S_MODE] = M_CONSTANT and*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26611 = (int)*(((s1_ptr)_2)->base + _e_51121);
        _2 = (int)SEQ_PTR(_26611);
        _26612 = (int)*(((s1_ptr)_2)->base + 3);
        _26611 = NOVALUE;
        if (IS_ATOM_INT(_26612)) {
            _26613 = (_26612 == 2);
        }
        else {
            _26613 = binary_op(EQUALS, _26612, 2);
        }
        _26612 = NOVALUE;
        if (IS_ATOM_INT(_26613)) {
            if (_26613 == 0) {
                DeRef(_26614);
                _26614 = 0;
                goto L5; // [112] 123
            }
        }
        else {
            if (DBL_PTR(_26613)->dbl == 0.0) {
                DeRef(_26614);
                _26614 = 0;
                goto L5; // [112] 123
            }
        }
        if (IS_ATOM_INT(_obj_51117))
        _26615 = 1;
        else if (IS_ATOM_DBL(_obj_51117))
        _26615 = IS_ATOM_INT(DoubleToInt(_obj_51117));
        else
        _26615 = 0;
        DeRef(_26614);
        _26614 = (_26615 != 0);
L5: 
        if (_26614 == 0) {
            goto L6; // [123] 169
        }
        _26617 = (_26TRANSLATE_11619 == 0);
        if (_26617 != 0) {
            DeRef(_26618);
            _26618 = 1;
            goto L7; // [132] 156
        }
        if (IS_ATOM_INT(_obj_51117)) {
            _26619 = (_obj_51117 >= 1);
        }
        else {
            _26619 = binary_op(GREATEREQ, _obj_51117, 1);
        }
        if (IS_ATOM_INT(_26619)) {
            if (_26619 == 0) {
                DeRef(_26620);
                _26620 = 0;
                goto L8; // [140] 152
            }
        }
        else {
            if (DBL_PTR(_26619)->dbl == 0.0) {
                DeRef(_26620);
                _26620 = 0;
                goto L8; // [140] 152
            }
        }
        if (IS_ATOM_INT(_obj_51117)) {
            _26621 = (_obj_51117 <= 255);
        }
        else {
            _26621 = binary_op(LESSEQ, _obj_51117, 255);
        }
        DeRef(_26620);
        if (IS_ATOM_INT(_26621))
        _26620 = (_26621 != 0);
        else
        _26620 = DBL_PTR(_26621)->dbl != 0.0;
L8: 
        DeRef(_26618);
        _26618 = (_26620 != 0);
L7: 
        if (_26618 == 0)
        {
            _26618 = NOVALUE;
            goto L6; // [157] 169
        }
        else{
            _26618 = NOVALUE;
        }

        /** 			element_vals = prepend(element_vals, obj)*/
        Ref(_obj_51117);
        Prepend(&_element_vals_51122, _element_vals_51122, _obj_51117);
        goto L9; // [166] 176
L6: 

        /** 			return -1*/
        DeRefDS(_elements_51116);
        DeRef(_obj_51117);
        DeRef(_element_vals_51122);
        DeRef(_26617);
        _26617 = NOVALUE;
        DeRef(_26613);
        _26613 = NOVALUE;
        DeRef(_26619);
        _26619 = NOVALUE;
        DeRef(_26621);
        _26621 = NOVALUE;
        return -1;
L9: 

        /** 	end for*/
        _i_51129 = _i_51129 + 1;
        goto L2; // [178] 50
L3: 
        ;
    }

    /** 	return element_vals*/
    DeRefDS(_elements_51116);
    DeRef(_obj_51117);
    DeRef(_26617);
    _26617 = NOVALUE;
    DeRef(_26613);
    _26613 = NOVALUE;
    DeRef(_26619);
    _26619 = NOVALUE;
    DeRef(_26621);
    _26621 = NOVALUE;
    return _element_vals_51122;
    ;
}


int _37Last_op()
{
    int _0, _1, _2;
    

    /** 	return last_op*/
    return _37last_op_51156;
    ;
}


int _37Last_pc()
{
    int _0, _1, _2;
    

    /** 	return last_pc*/
    return _37last_pc_51157;
    ;
}


void _37move_last_pc(int _amount_51164)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_amount_51164)) {
        _1 = (long)(DBL_PTR(_amount_51164)->dbl);
        DeRefDS(_amount_51164);
        _amount_51164 = _1;
    }

    /** 	if last_pc > 0 then*/
    if (_37last_pc_51157 <= 0)
    goto L1; // [7] 20

    /** 		last_pc += amount*/
    _37last_pc_51157 = _37last_pc_51157 + _amount_51164;
L1: 

    /** end procedure*/
    return;
    ;
}


void _37clear_last()
{
    int _0, _1, _2;
    

    /** 	last_op = 0*/
    _37last_op_51156 = 0;

    /** 	last_pc = 0*/
    _37last_pc_51157 = 0;

    /** end procedure*/
    return;
    ;
}


void _37clear_op()
{
    int _0, _1, _2;
    

    /** 	previous_op = -1*/
    _26previous_op_12081 = -1;

    /** 	assignable = FALSE*/
    _37assignable_50280 = _9FALSE_428;

    /** end procedure*/
    return;
    ;
}


void _37inlined_function()
{
    int _0, _1, _2;
    

    /** 	previous_op = PROC*/
    _26previous_op_12081 = 27;

    /** 	assignable = TRUE*/
    _37assignable_50280 = _9TRUE_430;

    /** 	inlined = TRUE*/
    _37inlined_51175 = _9TRUE_430;

    /** end procedure*/
    return;
    ;
}


void _37add_inline_target(int _pc_51186)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_51186)) {
        _1 = (long)(DBL_PTR(_pc_51186)->dbl);
        DeRefDS(_pc_51186);
        _pc_51186 = _1;
    }

    /** 	inlined_targets &= pc*/
    Append(&_37inlined_targets_51183, _37inlined_targets_51183, _pc_51186);

    /** end procedure*/
    return;
    ;
}


void _37clear_inline_targets()
{
    int _0, _1, _2;
    

    /** 	inlined_targets = {}*/
    RefDS(_22037);
    DeRefi(_37inlined_targets_51183);
    _37inlined_targets_51183 = _22037;

    /** end procedure*/
    return;
    ;
}


void _37emit_inline(int _code_51192)
{
    int _0, _1, _2;
    

    /** 	last_pc = 0*/
    _37last_pc_51157 = 0;

    /** 	last_op = 0*/
    _37last_op_51156 = 0;

    /** 	Code &= code*/
    Concat((object_ptr)&_26Code_12071, _26Code_12071, _code_51192);

    /** end procedure*/
    DeRefDS(_code_51192);
    return;
    ;
}


void _37emit_op(int _op_51197)
{
    int _a_51199 = NOVALUE;
    int _b_51200 = NOVALUE;
    int _c_51201 = NOVALUE;
    int _d_51202 = NOVALUE;
    int _source_51203 = NOVALUE;
    int _target_51204 = NOVALUE;
    int _subsym_51205 = NOVALUE;
    int _lhs_var_51207 = NOVALUE;
    int _ib_51208 = NOVALUE;
    int _ic_51209 = NOVALUE;
    int _n_51210 = NOVALUE;
    int _obj_51211 = NOVALUE;
    int _elements_51212 = NOVALUE;
    int _element_vals_51213 = NOVALUE;
    int _last_pc_backup_51214 = NOVALUE;
    int _last_op_backup_51215 = NOVALUE;
    int _temp_51224 = NOVALUE;
    int _real_op_51512 = NOVALUE;
    int _ref_51519 = NOVALUE;
    int _paths_51549 = NOVALUE;
    int _if_code_51629 = NOVALUE;
    int _if_code_51668 = NOVALUE;
    int _Top_inlined_Top_at_5195_52235 = NOVALUE;
    int _element_52306 = NOVALUE;
    int _Top_inlined_Top_at_6750_52453 = NOVALUE;
    int _31663 = NOVALUE;
    int _31662 = NOVALUE;
    int _27202 = NOVALUE;
    int _27198 = NOVALUE;
    int _27195 = NOVALUE;
    int _27193 = NOVALUE;
    int _27187 = NOVALUE;
    int _27186 = NOVALUE;
    int _27185 = NOVALUE;
    int _27183 = NOVALUE;
    int _27181 = NOVALUE;
    int _27180 = NOVALUE;
    int _27179 = NOVALUE;
    int _27178 = NOVALUE;
    int _27177 = NOVALUE;
    int _27176 = NOVALUE;
    int _27175 = NOVALUE;
    int _27174 = NOVALUE;
    int _27173 = NOVALUE;
    int _27172 = NOVALUE;
    int _27171 = NOVALUE;
    int _27169 = NOVALUE;
    int _27168 = NOVALUE;
    int _27167 = NOVALUE;
    int _27165 = NOVALUE;
    int _27164 = NOVALUE;
    int _27163 = NOVALUE;
    int _27162 = NOVALUE;
    int _27161 = NOVALUE;
    int _27160 = NOVALUE;
    int _27159 = NOVALUE;
    int _27158 = NOVALUE;
    int _27157 = NOVALUE;
    int _27154 = NOVALUE;
    int _27151 = NOVALUE;
    int _27150 = NOVALUE;
    int _27149 = NOVALUE;
    int _27148 = NOVALUE;
    int _27146 = NOVALUE;
    int _27144 = NOVALUE;
    int _27132 = NOVALUE;
    int _27124 = NOVALUE;
    int _27121 = NOVALUE;
    int _27120 = NOVALUE;
    int _27119 = NOVALUE;
    int _27118 = NOVALUE;
    int _27115 = NOVALUE;
    int _27114 = NOVALUE;
    int _27113 = NOVALUE;
    int _27112 = NOVALUE;
    int _27111 = NOVALUE;
    int _27110 = NOVALUE;
    int _27109 = NOVALUE;
    int _27108 = NOVALUE;
    int _27107 = NOVALUE;
    int _27106 = NOVALUE;
    int _27105 = NOVALUE;
    int _27103 = NOVALUE;
    int _27099 = NOVALUE;
    int _27098 = NOVALUE;
    int _27097 = NOVALUE;
    int _27096 = NOVALUE;
    int _27095 = NOVALUE;
    int _27094 = NOVALUE;
    int _27093 = NOVALUE;
    int _27092 = NOVALUE;
    int _27091 = NOVALUE;
    int _27090 = NOVALUE;
    int _27089 = NOVALUE;
    int _27087 = NOVALUE;
    int _27082 = NOVALUE;
    int _27081 = NOVALUE;
    int _27079 = NOVALUE;
    int _27078 = NOVALUE;
    int _27077 = NOVALUE;
    int _27075 = NOVALUE;
    int _27072 = NOVALUE;
    int _27068 = NOVALUE;
    int _27065 = NOVALUE;
    int _27064 = NOVALUE;
    int _27063 = NOVALUE;
    int _27062 = NOVALUE;
    int _27061 = NOVALUE;
    int _27060 = NOVALUE;
    int _27058 = NOVALUE;
    int _27057 = NOVALUE;
    int _27055 = NOVALUE;
    int _27054 = NOVALUE;
    int _27053 = NOVALUE;
    int _27052 = NOVALUE;
    int _27051 = NOVALUE;
    int _27050 = NOVALUE;
    int _27049 = NOVALUE;
    int _27048 = NOVALUE;
    int _27047 = NOVALUE;
    int _27046 = NOVALUE;
    int _27044 = NOVALUE;
    int _27043 = NOVALUE;
    int _27042 = NOVALUE;
    int _27041 = NOVALUE;
    int _27040 = NOVALUE;
    int _27039 = NOVALUE;
    int _27038 = NOVALUE;
    int _27037 = NOVALUE;
    int _27036 = NOVALUE;
    int _27035 = NOVALUE;
    int _27034 = NOVALUE;
    int _27033 = NOVALUE;
    int _27032 = NOVALUE;
    int _27031 = NOVALUE;
    int _27030 = NOVALUE;
    int _27028 = NOVALUE;
    int _27025 = NOVALUE;
    int _27024 = NOVALUE;
    int _27023 = NOVALUE;
    int _27022 = NOVALUE;
    int _27021 = NOVALUE;
    int _27020 = NOVALUE;
    int _27019 = NOVALUE;
    int _27018 = NOVALUE;
    int _27017 = NOVALUE;
    int _27016 = NOVALUE;
    int _27015 = NOVALUE;
    int _27014 = NOVALUE;
    int _27013 = NOVALUE;
    int _27012 = NOVALUE;
    int _27011 = NOVALUE;
    int _27009 = NOVALUE;
    int _27005 = NOVALUE;
    int _27002 = NOVALUE;
    int _27000 = NOVALUE;
    int _26999 = NOVALUE;
    int _26997 = NOVALUE;
    int _26996 = NOVALUE;
    int _26995 = NOVALUE;
    int _26994 = NOVALUE;
    int _26993 = NOVALUE;
    int _26992 = NOVALUE;
    int _26991 = NOVALUE;
    int _26990 = NOVALUE;
    int _26989 = NOVALUE;
    int _26988 = NOVALUE;
    int _26987 = NOVALUE;
    int _26986 = NOVALUE;
    int _26985 = NOVALUE;
    int _26984 = NOVALUE;
    int _26983 = NOVALUE;
    int _26982 = NOVALUE;
    int _26981 = NOVALUE;
    int _26980 = NOVALUE;
    int _26979 = NOVALUE;
    int _26977 = NOVALUE;
    int _26975 = NOVALUE;
    int _26974 = NOVALUE;
    int _26972 = NOVALUE;
    int _26962 = NOVALUE;
    int _26961 = NOVALUE;
    int _26960 = NOVALUE;
    int _26959 = NOVALUE;
    int _26958 = NOVALUE;
    int _26957 = NOVALUE;
    int _26956 = NOVALUE;
    int _26955 = NOVALUE;
    int _26954 = NOVALUE;
    int _26953 = NOVALUE;
    int _26952 = NOVALUE;
    int _26951 = NOVALUE;
    int _26950 = NOVALUE;
    int _26949 = NOVALUE;
    int _26948 = NOVALUE;
    int _26947 = NOVALUE;
    int _26946 = NOVALUE;
    int _26945 = NOVALUE;
    int _26944 = NOVALUE;
    int _26943 = NOVALUE;
    int _26942 = NOVALUE;
    int _26941 = NOVALUE;
    int _26940 = NOVALUE;
    int _26939 = NOVALUE;
    int _26933 = NOVALUE;
    int _26932 = NOVALUE;
    int _26929 = NOVALUE;
    int _26926 = NOVALUE;
    int _26925 = NOVALUE;
    int _26924 = NOVALUE;
    int _26923 = NOVALUE;
    int _26922 = NOVALUE;
    int _26921 = NOVALUE;
    int _26920 = NOVALUE;
    int _26919 = NOVALUE;
    int _26918 = NOVALUE;
    int _26917 = NOVALUE;
    int _26915 = NOVALUE;
    int _26914 = NOVALUE;
    int _26913 = NOVALUE;
    int _26911 = NOVALUE;
    int _26909 = NOVALUE;
    int _26908 = NOVALUE;
    int _26907 = NOVALUE;
    int _26906 = NOVALUE;
    int _26905 = NOVALUE;
    int _26904 = NOVALUE;
    int _26903 = NOVALUE;
    int _26902 = NOVALUE;
    int _26901 = NOVALUE;
    int _26900 = NOVALUE;
    int _26898 = NOVALUE;
    int _26897 = NOVALUE;
    int _26895 = NOVALUE;
    int _26894 = NOVALUE;
    int _26893 = NOVALUE;
    int _26892 = NOVALUE;
    int _26891 = NOVALUE;
    int _26889 = NOVALUE;
    int _26888 = NOVALUE;
    int _26887 = NOVALUE;
    int _26886 = NOVALUE;
    int _26885 = NOVALUE;
    int _26884 = NOVALUE;
    int _26883 = NOVALUE;
    int _26882 = NOVALUE;
    int _26880 = NOVALUE;
    int _26879 = NOVALUE;
    int _26878 = NOVALUE;
    int _26877 = NOVALUE;
    int _26876 = NOVALUE;
    int _26874 = NOVALUE;
    int _26873 = NOVALUE;
    int _26871 = NOVALUE;
    int _26870 = NOVALUE;
    int _26869 = NOVALUE;
    int _26868 = NOVALUE;
    int _26867 = NOVALUE;
    int _26865 = NOVALUE;
    int _26863 = NOVALUE;
    int _26861 = NOVALUE;
    int _26860 = NOVALUE;
    int _26858 = NOVALUE;
    int _26857 = NOVALUE;
    int _26856 = NOVALUE;
    int _26855 = NOVALUE;
    int _26854 = NOVALUE;
    int _26853 = NOVALUE;
    int _26852 = NOVALUE;
    int _26851 = NOVALUE;
    int _26850 = NOVALUE;
    int _26849 = NOVALUE;
    int _26848 = NOVALUE;
    int _26847 = NOVALUE;
    int _26846 = NOVALUE;
    int _26845 = NOVALUE;
    int _26844 = NOVALUE;
    int _26843 = NOVALUE;
    int _26842 = NOVALUE;
    int _26839 = NOVALUE;
    int _26838 = NOVALUE;
    int _26836 = NOVALUE;
    int _26835 = NOVALUE;
    int _26834 = NOVALUE;
    int _26833 = NOVALUE;
    int _26832 = NOVALUE;
    int _26830 = NOVALUE;
    int _26828 = NOVALUE;
    int _26827 = NOVALUE;
    int _26826 = NOVALUE;
    int _26825 = NOVALUE;
    int _26824 = NOVALUE;
    int _26823 = NOVALUE;
    int _26822 = NOVALUE;
    int _26821 = NOVALUE;
    int _26820 = NOVALUE;
    int _26817 = NOVALUE;
    int _26816 = NOVALUE;
    int _26814 = NOVALUE;
    int _26813 = NOVALUE;
    int _26812 = NOVALUE;
    int _26811 = NOVALUE;
    int _26810 = NOVALUE;
    int _26807 = NOVALUE;
    int _26806 = NOVALUE;
    int _26805 = NOVALUE;
    int _26804 = NOVALUE;
    int _26803 = NOVALUE;
    int _26802 = NOVALUE;
    int _26801 = NOVALUE;
    int _26796 = NOVALUE;
    int _26795 = NOVALUE;
    int _26794 = NOVALUE;
    int _26792 = NOVALUE;
    int _26791 = NOVALUE;
    int _26789 = NOVALUE;
    int _26788 = NOVALUE;
    int _26783 = NOVALUE;
    int _26782 = NOVALUE;
    int _26781 = NOVALUE;
    int _26780 = NOVALUE;
    int _26779 = NOVALUE;
    int _26773 = NOVALUE;
    int _26772 = NOVALUE;
    int _26770 = NOVALUE;
    int _26769 = NOVALUE;
    int _26768 = NOVALUE;
    int _26767 = NOVALUE;
    int _26766 = NOVALUE;
    int _26765 = NOVALUE;
    int _26763 = NOVALUE;
    int _26762 = NOVALUE;
    int _26761 = NOVALUE;
    int _26760 = NOVALUE;
    int _26759 = NOVALUE;
    int _26758 = NOVALUE;
    int _26757 = NOVALUE;
    int _26756 = NOVALUE;
    int _26755 = NOVALUE;
    int _26754 = NOVALUE;
    int _26753 = NOVALUE;
    int _26752 = NOVALUE;
    int _26751 = NOVALUE;
    int _26750 = NOVALUE;
    int _26748 = NOVALUE;
    int _26747 = NOVALUE;
    int _26746 = NOVALUE;
    int _26745 = NOVALUE;
    int _26742 = NOVALUE;
    int _26741 = NOVALUE;
    int _26740 = NOVALUE;
    int _26739 = NOVALUE;
    int _26737 = NOVALUE;
    int _26736 = NOVALUE;
    int _26735 = NOVALUE;
    int _26734 = NOVALUE;
    int _26732 = NOVALUE;
    int _26731 = NOVALUE;
    int _26730 = NOVALUE;
    int _26729 = NOVALUE;
    int _26728 = NOVALUE;
    int _26727 = NOVALUE;
    int _26726 = NOVALUE;
    int _26725 = NOVALUE;
    int _26724 = NOVALUE;
    int _26723 = NOVALUE;
    int _26722 = NOVALUE;
    int _26721 = NOVALUE;
    int _26720 = NOVALUE;
    int _26719 = NOVALUE;
    int _26717 = NOVALUE;
    int _26716 = NOVALUE;
    int _26715 = NOVALUE;
    int _26714 = NOVALUE;
    int _26713 = NOVALUE;
    int _26711 = NOVALUE;
    int _26710 = NOVALUE;
    int _26709 = NOVALUE;
    int _26708 = NOVALUE;
    int _26707 = NOVALUE;
    int _26703 = NOVALUE;
    int _26702 = NOVALUE;
    int _26701 = NOVALUE;
    int _26700 = NOVALUE;
    int _26699 = NOVALUE;
    int _26697 = NOVALUE;
    int _26696 = NOVALUE;
    int _26695 = NOVALUE;
    int _26694 = NOVALUE;
    int _26693 = NOVALUE;
    int _26692 = NOVALUE;
    int _26691 = NOVALUE;
    int _26690 = NOVALUE;
    int _26689 = NOVALUE;
    int _26688 = NOVALUE;
    int _26687 = NOVALUE;
    int _26686 = NOVALUE;
    int _26685 = NOVALUE;
    int _26684 = NOVALUE;
    int _26683 = NOVALUE;
    int _26682 = NOVALUE;
    int _26681 = NOVALUE;
    int _26680 = NOVALUE;
    int _26678 = NOVALUE;
    int _26677 = NOVALUE;
    int _26676 = NOVALUE;
    int _26675 = NOVALUE;
    int _26674 = NOVALUE;
    int _26673 = NOVALUE;
    int _26672 = NOVALUE;
    int _26671 = NOVALUE;
    int _26670 = NOVALUE;
    int _26668 = NOVALUE;
    int _26667 = NOVALUE;
    int _26666 = NOVALUE;
    int _26664 = NOVALUE;
    int _26663 = NOVALUE;
    int _26661 = NOVALUE;
    int _26659 = NOVALUE;
    int _26658 = NOVALUE;
    int _26657 = NOVALUE;
    int _26656 = NOVALUE;
    int _26655 = NOVALUE;
    int _26654 = NOVALUE;
    int _26650 = NOVALUE;
    int _26649 = NOVALUE;
    int _26648 = NOVALUE;
    int _26646 = NOVALUE;
    int _26645 = NOVALUE;
    int _26644 = NOVALUE;
    int _26643 = NOVALUE;
    int _26642 = NOVALUE;
    int _26641 = NOVALUE;
    int _26640 = NOVALUE;
    int _26639 = NOVALUE;
    int _26638 = NOVALUE;
    int _26637 = NOVALUE;
    int _26636 = NOVALUE;
    int _26635 = NOVALUE;
    int _26634 = NOVALUE;
    int _26633 = NOVALUE;
    int _26632 = NOVALUE;
    int _26627 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_op_51197)) {
        _1 = (long)(DBL_PTR(_op_51197)->dbl);
        DeRefDS(_op_51197);
        _op_51197 = _1;
    }

    /** 	integer ib, ic, n*/

    /** 	object obj*/

    /** 	sequence elements*/

    /** 	object element_vals*/

    /** 	check_for_temps()*/
    _37check_for_temps();

    /** 	integer last_pc_backup = last_pc*/
    _last_pc_backup_51214 = _37last_pc_51157;

    /** 	integer last_op_backup = last_op*/
    _last_op_backup_51215 = _37last_op_51156;

    /** 	last_op = op*/
    _37last_op_51156 = _op_51197;

    /** 	last_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_26Code_12071)){
            _26627 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _26627 = 1;
    }
    _37last_pc_51157 = _26627 + 1;
    _26627 = NOVALUE;

    /** 	switch op label "EMIT" do*/
    _0 = _op_51197;
    switch ( _0 ){ 

        /** 	case ASSIGN then*/
        case 18:

        /** 		sequence temp = {}*/
        RefDS(_22037);
        DeRef(_temp_51224);
        _temp_51224 = _22037;

        /** 		if not TRANSLATE and*/
        _26632 = (_26TRANSLATE_11619 == 0);
        if (_26632 == 0) {
            goto L1; // [70] 202
        }
        _26634 = (_26previous_op_12081 == 92);
        if (_26634 != 0) {
            DeRef(_26635);
            _26635 = 1;
            goto L2; // [82] 98
        }
        _26636 = (_26previous_op_12081 == 25);
        _26635 = (_26636 != 0);
L2: 
        if (_26635 == 0)
        {
            _26635 = NOVALUE;
            goto L1; // [99] 202
        }
        else{
            _26635 = NOVALUE;
        }

        /** 			while Code[$-1] = DEREF_TEMP and find( Code[$], derefs ) do*/
L3: 
        if (IS_SEQUENCE(_26Code_12071)){
                _26637 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26637 = 1;
        }
        _26638 = _26637 - 1;
        _26637 = NOVALUE;
        _2 = (int)SEQ_PTR(_26Code_12071);
        _26639 = (int)*(((s1_ptr)_2)->base + _26638);
        if (IS_ATOM_INT(_26639)) {
            _26640 = (_26639 == 208);
        }
        else {
            _26640 = binary_op(EQUALS, _26639, 208);
        }
        _26639 = NOVALUE;
        if (IS_ATOM_INT(_26640)) {
            if (_26640 == 0) {
                goto L4; // [126] 201
            }
        }
        else {
            if (DBL_PTR(_26640)->dbl == 0.0) {
                goto L4; // [126] 201
            }
        }
        if (IS_SEQUENCE(_26Code_12071)){
                _26642 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26642 = 1;
        }
        _2 = (int)SEQ_PTR(_26Code_12071);
        _26643 = (int)*(((s1_ptr)_2)->base + _26642);
        _26644 = find_from(_26643, _37derefs_50781, 1);
        _26643 = NOVALUE;
        if (_26644 == 0)
        {
            _26644 = NOVALUE;
            goto L4; // [147] 201
        }
        else{
            _26644 = NOVALUE;
        }

        /** 				temp &= Code[$]*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26645 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26645 = 1;
        }
        _2 = (int)SEQ_PTR(_26Code_12071);
        _26646 = (int)*(((s1_ptr)_2)->base + _26645);
        if (IS_SEQUENCE(_temp_51224) && IS_ATOM(_26646)) {
            Ref(_26646);
            Append(&_temp_51224, _temp_51224, _26646);
        }
        else if (IS_ATOM(_temp_51224) && IS_SEQUENCE(_26646)) {
        }
        else {
            Concat((object_ptr)&_temp_51224, _temp_51224, _26646);
        }
        _26646 = NOVALUE;

        /** 				Code = remove( Code, length(Code)-1, length(Code) )*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26648 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26648 = 1;
        }
        _26649 = _26648 - 1;
        _26648 = NOVALUE;
        if (IS_SEQUENCE(_26Code_12071)){
                _26650 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26650 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_26Code_12071);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26649)) ? _26649 : (long)(DBL_PTR(_26649)->dbl);
            int stop = (IS_ATOM_INT(_26650)) ? _26650 : (long)(DBL_PTR(_26650)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_26Code_12071), start, &_26Code_12071 );
                }
                else Tail(SEQ_PTR(_26Code_12071), stop+1, &_26Code_12071);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_26Code_12071), start, &_26Code_12071);
            }
            else {
                assign_slice_seq = &assign_space;
                _26Code_12071 = Remove_elements(start, stop, (SEQ_PTR(_26Code_12071)->ref == 1));
            }
        }
        _26649 = NOVALUE;
        _26650 = NOVALUE;

        /** 				emit_temp( temp, NEW_REFERENCE )*/
        RefDS(_temp_51224);
        _37emit_temp(_temp_51224, 1);

        /** 			end while*/
        goto L3; // [198] 107
L4: 
L1: 

        /** 		source = Pop()*/
        _source_51203 = _37Pop();
        if (!IS_ATOM_INT(_source_51203)) {
            _1 = (long)(DBL_PTR(_source_51203)->dbl);
            DeRefDS(_source_51203);
            _source_51203 = _1;
        }

        /** 		target = Pop()*/
        _target_51204 = _37Pop();
        if (!IS_ATOM_INT(_target_51204)) {
            _1 = (long)(DBL_PTR(_target_51204)->dbl);
            DeRefDS(_target_51204);
            _target_51204 = _1;
        }

        /** 		if assignable then*/
        if (_37assignable_50280 == 0)
        {
            goto L5; // [220] 601
        }
        else{
        }

        /** 			if inlined then*/
        if (_37inlined_51175 == 0)
        {
            goto L6; // [227] 326
        }
        else{
        }

        /** 				inlined = 0*/
        _37inlined_51175 = 0;

        /** 				if length( inlined_targets ) then*/
        if (IS_SEQUENCE(_37inlined_targets_51183)){
                _26654 = SEQ_PTR(_37inlined_targets_51183)->length;
        }
        else {
            _26654 = 1;
        }
        if (_26654 == 0)
        {
            _26654 = NOVALUE;
            goto L7; // [242] 295
        }
        else{
            _26654 = NOVALUE;
        }

        /** 					for i = 1 to length( inlined_targets ) do*/
        if (IS_SEQUENCE(_37inlined_targets_51183)){
                _26655 = SEQ_PTR(_37inlined_targets_51183)->length;
        }
        else {
            _26655 = 1;
        }
        {
            int _i_51267;
            _i_51267 = 1;
L8: 
            if (_i_51267 > _26655){
                goto L9; // [252] 280
            }

            /** 						Code[inlined_targets[i]] = target*/
            _2 = (int)SEQ_PTR(_37inlined_targets_51183);
            _26656 = (int)*(((s1_ptr)_2)->base + _i_51267);
            _2 = (int)SEQ_PTR(_26Code_12071);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _26Code_12071 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _26656);
            _1 = *(int *)_2;
            *(int *)_2 = _target_51204;
            DeRef(_1);

            /** 					end for*/
            _i_51267 = _i_51267 + 1;
            goto L8; // [275] 259
L9: 
            ;
        }

        /** 					clear_inline_targets()*/

        /** 	inlined_targets = {}*/
        RefDS(_22037);
        DeRefi(_37inlined_targets_51183);
        _37inlined_targets_51183 = _22037;

        /** end procedure*/
        goto LA; // [291] 294
LA: 
L7: 

        /** 				assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;

        /** 				clear_last()*/

        /** 	last_op = 0*/
        _37last_op_51156 = 0;

        /** 	last_pc = 0*/
        _37last_pc_51157 = 0;

        /** end procedure*/
        goto LB; // [316] 319
LB: 

        /** 				break "EMIT"*/
        DeRef(_temp_51224);
        _temp_51224 = NOVALUE;
        goto LC; // [323] 7412
L6: 

        /** 			clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26657 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26657 = 1;
        }
        _2 = (int)SEQ_PTR(_26Code_12071);
        _26658 = (int)*(((s1_ptr)_2)->base + _26657);
        Ref(_26658);
        _37clear_temp(_26658);
        _26658 = NOVALUE;

        /** 			Code = remove( Code, length( Code ) ) -- drop previous target*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26659 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26659 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_26Code_12071);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26659)) ? _26659 : (long)(DBL_PTR(_26659)->dbl);
            int stop = (IS_ATOM_INT(_26659)) ? _26659 : (long)(DBL_PTR(_26659)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_26Code_12071), start, &_26Code_12071 );
                }
                else Tail(SEQ_PTR(_26Code_12071), stop+1, &_26Code_12071);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_26Code_12071), start, &_26Code_12071);
            }
            else {
                assign_slice_seq = &assign_space;
                _26Code_12071 = Remove_elements(start, stop, (SEQ_PTR(_26Code_12071)->ref == 1));
            }
        }
        _26659 = NOVALUE;
        _26659 = NOVALUE;

        /** 			op = previous_op -- keep same previous op*/
        _op_51197 = _26previous_op_12081;

        /** 			if IsInteger(target) then*/
        _26661 = _37IsInteger(_target_51204);
        if (_26661 == 0) {
            DeRef(_26661);
            _26661 = NOVALUE;
            goto LD; // [372] 588
        }
        else {
            if (!IS_ATOM_INT(_26661) && DBL_PTR(_26661)->dbl == 0.0){
                DeRef(_26661);
                _26661 = NOVALUE;
                goto LD; // [372] 588
            }
            DeRef(_26661);
            _26661 = NOVALUE;
        }
        DeRef(_26661);
        _26661 = NOVALUE;

        /** 				if previous_op = RHS_SUBS then*/
        if (_26previous_op_12081 != 25)
        goto LE; // [381] 412

        /** 					op = RHS_SUBS_I*/
        _op_51197 = 114;

        /** 					backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26663 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26663 = 1;
        }
        _26664 = _26663 - 2;
        _26663 = NOVALUE;
        _37backpatch(_26664, 114);
        _26664 = NOVALUE;
        goto LF; // [409] 587
LE: 

        /** 				elsif previous_op = PLUS1 then*/
        if (_26previous_op_12081 != 93)
        goto L10; // [418] 449

        /** 					op = PLUS1_I*/
        _op_51197 = 117;

        /** 					backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26666 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26666 = 1;
        }
        _26667 = _26666 - 2;
        _26666 = NOVALUE;
        _37backpatch(_26667, 117);
        _26667 = NOVALUE;
        goto LF; // [446] 587
L10: 

        /** 				elsif previous_op = PLUS or previous_op = MINUS then*/
        _26668 = (_26previous_op_12081 == 11);
        if (_26668 != 0) {
            goto L11; // [459] 476
        }
        _26670 = (_26previous_op_12081 == 10);
        if (_26670 == 0)
        {
            DeRef(_26670);
            _26670 = NOVALUE;
            goto L12; // [472] 567
        }
        else{
            DeRef(_26670);
            _26670 = NOVALUE;
        }
L11: 

        /** 					if IsInteger(Code[$]) and*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26671 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26671 = 1;
        }
        _2 = (int)SEQ_PTR(_26Code_12071);
        _26672 = (int)*(((s1_ptr)_2)->base + _26671);
        Ref(_26672);
        _26673 = _37IsInteger(_26672);
        _26672 = NOVALUE;
        if (IS_ATOM_INT(_26673)) {
            if (_26673 == 0) {
                goto LF; // [491] 587
            }
        }
        else {
            if (DBL_PTR(_26673)->dbl == 0.0) {
                goto LF; // [491] 587
            }
        }
        if (IS_SEQUENCE(_26Code_12071)){
                _26675 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26675 = 1;
        }
        _26676 = _26675 - 1;
        _26675 = NOVALUE;
        _2 = (int)SEQ_PTR(_26Code_12071);
        _26677 = (int)*(((s1_ptr)_2)->base + _26676);
        Ref(_26677);
        _26678 = _37IsInteger(_26677);
        _26677 = NOVALUE;
        if (_26678 == 0) {
            DeRef(_26678);
            _26678 = NOVALUE;
            goto LF; // [513] 587
        }
        else {
            if (!IS_ATOM_INT(_26678) && DBL_PTR(_26678)->dbl == 0.0){
                DeRef(_26678);
                _26678 = NOVALUE;
                goto LF; // [513] 587
            }
            DeRef(_26678);
            _26678 = NOVALUE;
        }
        DeRef(_26678);
        _26678 = NOVALUE;

        /** 						if previous_op = PLUS then*/
        if (_26previous_op_12081 != 11)
        goto L13; // [522] 538

        /** 							op = PLUS_I*/
        _op_51197 = 115;
        goto L14; // [535] 548
L13: 

        /** 							op = MINUS_I*/
        _op_51197 = 116;
L14: 

        /** 						backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26680 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26680 = 1;
        }
        _26681 = _26680 - 2;
        _26680 = NOVALUE;
        _37backpatch(_26681, _op_51197);
        _26681 = NOVALUE;
        goto LF; // [564] 587
L12: 

        /** 					if IsInteger(source) then*/
        _26682 = _37IsInteger(_source_51203);
        if (_26682 == 0) {
            DeRef(_26682);
            _26682 = NOVALUE;
            goto L15; // [573] 586
        }
        else {
            if (!IS_ATOM_INT(_26682) && DBL_PTR(_26682)->dbl == 0.0){
                DeRef(_26682);
                _26682 = NOVALUE;
                goto L15; // [573] 586
            }
            DeRef(_26682);
            _26682 = NOVALUE;
        }
        DeRef(_26682);
        _26682 = NOVALUE;

        /** 						op = ASSIGN_I -- fake to avoid subsequent check*/
        _op_51197 = 113;
L15: 
LF: 
LD: 

        /** 			last_op = last_op_backup*/
        _37last_op_51156 = _last_op_backup_51215;

        /** 			last_pc = last_pc_backup*/
        _37last_pc_51157 = _last_pc_backup_51214;
        goto L16; // [598] 743
L5: 

        /** 			if IsInteger(source) and IsInteger(target) then*/
        _26683 = _37IsInteger(_source_51203);
        if (IS_ATOM_INT(_26683)) {
            if (_26683 == 0) {
                goto L17; // [607] 629
            }
        }
        else {
            if (DBL_PTR(_26683)->dbl == 0.0) {
                goto L17; // [607] 629
            }
        }
        _26685 = _37IsInteger(_target_51204);
        if (_26685 == 0) {
            DeRef(_26685);
            _26685 = NOVALUE;
            goto L17; // [616] 629
        }
        else {
            if (!IS_ATOM_INT(_26685) && DBL_PTR(_26685)->dbl == 0.0){
                DeRef(_26685);
                _26685 = NOVALUE;
                goto L17; // [616] 629
            }
            DeRef(_26685);
            _26685 = NOVALUE;
        }
        DeRef(_26685);
        _26685 = NOVALUE;

        /** 				op = ASSIGN_I*/
        _op_51197 = 113;
L17: 

        /** 			if source > 0 and target > 0 and*/
        _26686 = (_source_51203 > 0);
        if (_26686 == 0) {
            _26687 = 0;
            goto L18; // [635] 647
        }
        _26688 = (_target_51204 > 0);
        _26687 = (_26688 != 0);
L18: 
        if (_26687 == 0) {
            _26689 = 0;
            goto L19; // [647] 673
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26690 = (int)*(((s1_ptr)_2)->base + _source_51203);
        _2 = (int)SEQ_PTR(_26690);
        _26691 = (int)*(((s1_ptr)_2)->base + 3);
        _26690 = NOVALUE;
        if (IS_ATOM_INT(_26691)) {
            _26692 = (_26691 == 2);
        }
        else {
            _26692 = binary_op(EQUALS, _26691, 2);
        }
        _26691 = NOVALUE;
        if (IS_ATOM_INT(_26692))
        _26689 = (_26692 != 0);
        else
        _26689 = DBL_PTR(_26692)->dbl != 0.0;
L19: 
        if (_26689 == 0) {
            goto L1A; // [673] 727
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26694 = (int)*(((s1_ptr)_2)->base + _target_51204);
        _2 = (int)SEQ_PTR(_26694);
        _26695 = (int)*(((s1_ptr)_2)->base + 3);
        _26694 = NOVALUE;
        if (IS_ATOM_INT(_26695)) {
            _26696 = (_26695 == 2);
        }
        else {
            _26696 = binary_op(EQUALS, _26695, 2);
        }
        _26695 = NOVALUE;
        if (_26696 == 0) {
            DeRef(_26696);
            _26696 = NOVALUE;
            goto L1A; // [696] 727
        }
        else {
            if (!IS_ATOM_INT(_26696) && DBL_PTR(_26696)->dbl == 0.0){
                DeRef(_26696);
                _26696 = NOVALUE;
                goto L1A; // [696] 727
            }
            DeRef(_26696);
            _26696 = NOVALUE;
        }
        DeRef(_26696);
        _26696 = NOVALUE;

        /** 				SymTab[target][S_OBJ] = SymTab[source][S_OBJ]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_target_51204 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26699 = (int)*(((s1_ptr)_2)->base + _source_51203);
        _2 = (int)SEQ_PTR(_26699);
        _26700 = (int)*(((s1_ptr)_2)->base + 1);
        _26699 = NOVALUE;
        Ref(_26700);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _26700;
        if( _1 != _26700 ){
            DeRef(_1);
        }
        _26700 = NOVALUE;
        _26697 = NOVALUE;
L1A: 

        /** 			emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 			emit_addr(source)*/
        _37emit_addr(_source_51203);

        /** 			last_op = op*/
        _37last_op_51156 = _op_51197;
L16: 

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;

        /** 		emit_addr(target)*/
        _37emit_addr(_target_51204);

        /** 		if length(temp) then*/
        if (IS_SEQUENCE(_temp_51224)){
                _26701 = SEQ_PTR(_temp_51224)->length;
        }
        else {
            _26701 = 1;
        }
        if (_26701 == 0)
        {
            _26701 = NOVALUE;
            goto L1B; // [760] 792
        }
        else{
            _26701 = NOVALUE;
        }

        /** 			for i = 1 to length( temp ) do*/
        if (IS_SEQUENCE(_temp_51224)){
                _26702 = SEQ_PTR(_temp_51224)->length;
        }
        else {
            _26702 = 1;
        }
        {
            int _i_51370;
            _i_51370 = 1;
L1C: 
            if (_i_51370 > _26702){
                goto L1D; // [768] 791
            }

            /** 				flush_temp( temp[i] )*/
            _2 = (int)SEQ_PTR(_temp_51224);
            _26703 = (int)*(((s1_ptr)_2)->base + _i_51370);
            Ref(_26703);
            _37flush_temp(_26703);
            _26703 = NOVALUE;

            /** 			end for*/
            _i_51370 = _i_51370 + 1;
            goto L1C; // [786] 775
L1D: 
            ;
        }
L1B: 
        DeRef(_temp_51224);
        _temp_51224 = NOVALUE;
        goto LC; // [794] 7412

        /** 	case RHS_SUBS then*/
        case 25:

        /** 		b = Pop() -- subscript*/
        _b_51200 = _37Pop();
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 		c = Pop() -- sequence*/
        _c_51201 = _37Pop();
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		target = NewTempSym() -- target*/
        _target_51204 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_target_51204)) {
            _1 = (long)(DBL_PTR(_target_51204)->dbl);
            DeRefDS(_target_51204);
            _target_51204 = _1;
        }

        /** 		if c < 0 or length(SymTab[c]) < S_VTYPE or SymTab[c][S_VTYPE] < 0 then -- forward reference*/
        _26707 = (_c_51201 < 0);
        if (_26707 != 0) {
            _26708 = 1;
            goto L1E; // [828] 851
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26709 = (int)*(((s1_ptr)_2)->base + _c_51201);
        if (IS_SEQUENCE(_26709)){
                _26710 = SEQ_PTR(_26709)->length;
        }
        else {
            _26710 = 1;
        }
        _26709 = NOVALUE;
        _26711 = (_26710 < 15);
        _26710 = NOVALUE;
        _26708 = (_26711 != 0);
L1E: 
        if (_26708 != 0) {
            goto L1F; // [851] 876
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26713 = (int)*(((s1_ptr)_2)->base + _c_51201);
        _2 = (int)SEQ_PTR(_26713);
        _26714 = (int)*(((s1_ptr)_2)->base + 15);
        _26713 = NOVALUE;
        if (IS_ATOM_INT(_26714)) {
            _26715 = (_26714 < 0);
        }
        else {
            _26715 = binary_op(LESS, _26714, 0);
        }
        _26714 = NOVALUE;
        if (_26715 == 0) {
            DeRef(_26715);
            _26715 = NOVALUE;
            goto L20; // [872] 888
        }
        else {
            if (!IS_ATOM_INT(_26715) && DBL_PTR(_26715)->dbl == 0.0){
                DeRef(_26715);
                _26715 = NOVALUE;
                goto L20; // [872] 888
            }
            DeRef(_26715);
            _26715 = NOVALUE;
        }
        DeRef(_26715);
        _26715 = NOVALUE;
L1F: 

        /** 			op = RHS_SUBS_CHECK*/
        _op_51197 = 92;
        goto L21; // [885] 1049
L20: 

        /** 		elsif SymTab[c][S_MODE] = M_NORMAL then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26716 = (int)*(((s1_ptr)_2)->base + _c_51201);
        _2 = (int)SEQ_PTR(_26716);
        _26717 = (int)*(((s1_ptr)_2)->base + 3);
        _26716 = NOVALUE;
        if (binary_op_a(NOTEQ, _26717, 1)){
            _26717 = NOVALUE;
            goto L22; // [904] 991
        }
        _26717 = NOVALUE;

        /** 			if SymTab[c][S_VTYPE] != sequence_type and*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26719 = (int)*(((s1_ptr)_2)->base + _c_51201);
        _2 = (int)SEQ_PTR(_26719);
        _26720 = (int)*(((s1_ptr)_2)->base + 15);
        _26719 = NOVALUE;
        if (IS_ATOM_INT(_26720)) {
            _26721 = (_26720 != _52sequence_type_46134);
        }
        else {
            _26721 = binary_op(NOTEQ, _26720, _52sequence_type_46134);
        }
        _26720 = NOVALUE;
        if (IS_ATOM_INT(_26721)) {
            if (_26721 == 0) {
                goto L21; // [928] 1049
            }
        }
        else {
            if (DBL_PTR(_26721)->dbl == 0.0) {
                goto L21; // [928] 1049
            }
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26723 = (int)*(((s1_ptr)_2)->base + _c_51201);
        _2 = (int)SEQ_PTR(_26723);
        _26724 = (int)*(((s1_ptr)_2)->base + 15);
        _26723 = NOVALUE;
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!IS_ATOM_INT(_26724)){
            _26725 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26724)->dbl));
        }
        else{
            _26725 = (int)*(((s1_ptr)_2)->base + _26724);
        }
        _2 = (int)SEQ_PTR(_26725);
        _26726 = (int)*(((s1_ptr)_2)->base + 2);
        _26725 = NOVALUE;
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!IS_ATOM_INT(_26726)){
            _26727 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26726)->dbl));
        }
        else{
            _26727 = (int)*(((s1_ptr)_2)->base + _26726);
        }
        _2 = (int)SEQ_PTR(_26727);
        _26728 = (int)*(((s1_ptr)_2)->base + 15);
        _26727 = NOVALUE;
        if (IS_ATOM_INT(_26728)) {
            _26729 = (_26728 != _52sequence_type_46134);
        }
        else {
            _26729 = binary_op(NOTEQ, _26728, _52sequence_type_46134);
        }
        _26728 = NOVALUE;
        if (_26729 == 0) {
            DeRef(_26729);
            _26729 = NOVALUE;
            goto L21; // [975] 1049
        }
        else {
            if (!IS_ATOM_INT(_26729) && DBL_PTR(_26729)->dbl == 0.0){
                DeRef(_26729);
                _26729 = NOVALUE;
                goto L21; // [975] 1049
            }
            DeRef(_26729);
            _26729 = NOVALUE;
        }
        DeRef(_26729);
        _26729 = NOVALUE;

        /** 				op = RHS_SUBS_CHECK*/
        _op_51197 = 92;
        goto L21; // [988] 1049
L22: 

        /** 		elsif SymTab[c][S_MODE] != M_CONSTANT or*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26730 = (int)*(((s1_ptr)_2)->base + _c_51201);
        _2 = (int)SEQ_PTR(_26730);
        _26731 = (int)*(((s1_ptr)_2)->base + 3);
        _26730 = NOVALUE;
        if (IS_ATOM_INT(_26731)) {
            _26732 = (_26731 != 2);
        }
        else {
            _26732 = binary_op(NOTEQ, _26731, 2);
        }
        _26731 = NOVALUE;
        if (IS_ATOM_INT(_26732)) {
            if (_26732 != 0) {
                goto L23; // [1011] 1038
            }
        }
        else {
            if (DBL_PTR(_26732)->dbl != 0.0) {
                goto L23; // [1011] 1038
            }
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26734 = (int)*(((s1_ptr)_2)->base + _c_51201);
        _2 = (int)SEQ_PTR(_26734);
        _26735 = (int)*(((s1_ptr)_2)->base + 1);
        _26734 = NOVALUE;
        _26736 = IS_SEQUENCE(_26735);
        _26735 = NOVALUE;
        _26737 = (_26736 == 0);
        _26736 = NOVALUE;
        if (_26737 == 0)
        {
            DeRef(_26737);
            _26737 = NOVALUE;
            goto L24; // [1034] 1048
        }
        else{
            DeRef(_26737);
            _26737 = NOVALUE;
        }
L23: 

        /** 			op = RHS_SUBS_CHECK*/
        _op_51197 = 92;
L24: 
L21: 

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_51201);

        /** 		emit_addr(b)*/
        _37emit_addr(_b_51200);

        /** 		assignable = TRUE*/
        _37assignable_50280 = _9TRUE_430;

        /** 		Push(target)*/
        _37Push(_target_51204);

        /** 		emit_addr(target)*/
        _37emit_addr(_target_51204);

        /** 		emit_temp(target, NEW_REFERENCE)*/
        _37emit_temp(_target_51204, 1);

        /** 		current_sequence = append(current_sequence, target)*/
        Append(&_37current_sequence_50270, _37current_sequence_50270, _target_51204);

        /** 		flush_temp( Code[$-2] )*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26739 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26739 = 1;
        }
        _26740 = _26739 - 2;
        _26739 = NOVALUE;
        _2 = (int)SEQ_PTR(_26Code_12071);
        _26741 = (int)*(((s1_ptr)_2)->base + _26740);
        Ref(_26741);
        _37flush_temp(_26741);
        _26741 = NOVALUE;
        goto LC; // [1113] 7412

        /** 	case PROC then -- procedure, function and type calls*/
        case 27:

        /** 		assignable = FALSE -- assume for now*/
        _37assignable_50280 = _9FALSE_428;

        /** 		subsym = op_info1*/
        _subsym_51205 = _37op_info1_50262;

        /** 		n = SymTab[subsym][S_NUM_ARGS]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26742 = (int)*(((s1_ptr)_2)->base + _subsym_51205);
        _2 = (int)SEQ_PTR(_26742);
        if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
            _n_51210 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
        }
        else{
            _n_51210 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
        }
        if (!IS_ATOM_INT(_n_51210)){
            _n_51210 = (long)DBL_PTR(_n_51210)->dbl;
        }
        _26742 = NOVALUE;

        /** 		if subsym = CurrentSub then*/
        if (_subsym_51205 != _26CurrentSub_11990)
        goto L25; // [1155] 1340

        /** 			for i = cgi-n+1 to cgi do*/
        _26745 = _37cgi_50278 - _n_51210;
        if ((long)((unsigned long)_26745 +(unsigned long) HIGH_BITS) >= 0){
            _26745 = NewDouble((double)_26745);
        }
        if (IS_ATOM_INT(_26745)) {
            _26746 = _26745 + 1;
            if (_26746 > MAXINT){
                _26746 = NewDouble((double)_26746);
            }
        }
        else
        _26746 = binary_op(PLUS, 1, _26745);
        DeRef(_26745);
        _26745 = NOVALUE;
        _26747 = _37cgi_50278;
        {
            int _i_51456;
            Ref(_26746);
            _i_51456 = _26746;
L26: 
            if (binary_op_a(GREATER, _i_51456, _26747)){
                goto L27; // [1176] 1339
            }

            /** 				if cg_stack[i] > 0 then -- if it's a forward reference, it's not a private*/
            _2 = (int)SEQ_PTR(_37cg_stack_50277);
            if (!IS_ATOM_INT(_i_51456)){
                _26748 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51456)->dbl));
            }
            else{
                _26748 = (int)*(((s1_ptr)_2)->base + _i_51456);
            }
            if (binary_op_a(LESSEQ, _26748, 0)){
                _26748 = NOVALUE;
                goto L28; // [1191] 1332
            }
            _26748 = NOVALUE;

            /** 					if SymTab[cg_stack[i]][S_SCOPE] = SC_PRIVATE and*/
            _2 = (int)SEQ_PTR(_37cg_stack_50277);
            if (!IS_ATOM_INT(_i_51456)){
                _26750 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51456)->dbl));
            }
            else{
                _26750 = (int)*(((s1_ptr)_2)->base + _i_51456);
            }
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            if (!IS_ATOM_INT(_26750)){
                _26751 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26750)->dbl));
            }
            else{
                _26751 = (int)*(((s1_ptr)_2)->base + _26750);
            }
            _2 = (int)SEQ_PTR(_26751);
            _26752 = (int)*(((s1_ptr)_2)->base + 4);
            _26751 = NOVALUE;
            if (IS_ATOM_INT(_26752)) {
                _26753 = (_26752 == 3);
            }
            else {
                _26753 = binary_op(EQUALS, _26752, 3);
            }
            _26752 = NOVALUE;
            if (IS_ATOM_INT(_26753)) {
                if (_26753 == 0) {
                    goto L29; // [1221] 1299
                }
            }
            else {
                if (DBL_PTR(_26753)->dbl == 0.0) {
                    goto L29; // [1221] 1299
                }
            }
            _2 = (int)SEQ_PTR(_37cg_stack_50277);
            if (!IS_ATOM_INT(_i_51456)){
                _26755 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51456)->dbl));
            }
            else{
                _26755 = (int)*(((s1_ptr)_2)->base + _i_51456);
            }
            _2 = (int)SEQ_PTR(_27SymTab_10921);
            if (!IS_ATOM_INT(_26755)){
                _26756 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26755)->dbl));
            }
            else{
                _26756 = (int)*(((s1_ptr)_2)->base + _26755);
            }
            _2 = (int)SEQ_PTR(_26756);
            _26757 = (int)*(((s1_ptr)_2)->base + 16);
            _26756 = NOVALUE;
            if (IS_ATOM_INT(_26757) && IS_ATOM_INT(_i_51456)) {
                _26758 = (_26757 < _i_51456);
            }
            else {
                _26758 = binary_op(LESS, _26757, _i_51456);
            }
            _26757 = NOVALUE;
            if (_26758 == 0) {
                DeRef(_26758);
                _26758 = NOVALUE;
                goto L29; // [1248] 1299
            }
            else {
                if (!IS_ATOM_INT(_26758) && DBL_PTR(_26758)->dbl == 0.0){
                    DeRef(_26758);
                    _26758 = NOVALUE;
                    goto L29; // [1248] 1299
                }
                DeRef(_26758);
                _26758 = NOVALUE;
            }
            DeRef(_26758);
            _26758 = NOVALUE;

            /** 						emit_opcode(ASSIGN)*/
            _37emit_opcode(18);

            /** 						emit_addr(cg_stack[i])*/
            _2 = (int)SEQ_PTR(_37cg_stack_50277);
            if (!IS_ATOM_INT(_i_51456)){
                _26759 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51456)->dbl));
            }
            else{
                _26759 = (int)*(((s1_ptr)_2)->base + _i_51456);
            }
            Ref(_26759);
            _37emit_addr(_26759);
            _26759 = NOVALUE;

            /** 						cg_stack[i] = NewTempSym()*/
            _26760 = _52NewTempSym(0);
            _2 = (int)SEQ_PTR(_37cg_stack_50277);
            if (!IS_ATOM_INT(_i_51456))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51456)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _i_51456);
            _1 = *(int *)_2;
            *(int *)_2 = _26760;
            if( _1 != _26760 ){
                DeRef(_1);
            }
            _26760 = NOVALUE;

            /** 						emit_addr(cg_stack[i])*/
            _2 = (int)SEQ_PTR(_37cg_stack_50277);
            if (!IS_ATOM_INT(_i_51456)){
                _26761 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51456)->dbl));
            }
            else{
                _26761 = (int)*(((s1_ptr)_2)->base + _i_51456);
            }
            Ref(_26761);
            _37emit_addr(_26761);
            _26761 = NOVALUE;

            /** 						check_for_temps()*/
            _37check_for_temps();
            goto L2A; // [1296] 1331
L29: 

            /** 					elsif sym_mode( cg_stack[i] ) = M_TEMP then*/
            _2 = (int)SEQ_PTR(_37cg_stack_50277);
            if (!IS_ATOM_INT(_i_51456)){
                _26762 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51456)->dbl));
            }
            else{
                _26762 = (int)*(((s1_ptr)_2)->base + _i_51456);
            }
            Ref(_26762);
            _26763 = _52sym_mode(_26762);
            _26762 = NOVALUE;
            if (binary_op_a(NOTEQ, _26763, 3)){
                DeRef(_26763);
                _26763 = NOVALUE;
                goto L2B; // [1313] 1330
            }
            DeRef(_26763);
            _26763 = NOVALUE;

            /** 						emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (int)SEQ_PTR(_37cg_stack_50277);
            if (!IS_ATOM_INT(_i_51456)){
                _26765 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51456)->dbl));
            }
            else{
                _26765 = (int)*(((s1_ptr)_2)->base + _i_51456);
            }
            Ref(_26765);
            _37emit_temp(_26765, 1);
            _26765 = NOVALUE;
L2B: 
L2A: 
L28: 

            /** 			end for*/
            _0 = _i_51456;
            if (IS_ATOM_INT(_i_51456)) {
                _i_51456 = _i_51456 + 1;
                if ((long)((unsigned long)_i_51456 +(unsigned long) HIGH_BITS) >= 0){
                    _i_51456 = NewDouble((double)_i_51456);
                }
            }
            else {
                _i_51456 = binary_op_a(PLUS, _i_51456, 1);
            }
            DeRef(_0);
            goto L26; // [1334] 1183
L27: 
            ;
            DeRef(_i_51456);
        }
L25: 

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		emit_addr(subsym)*/
        _37emit_addr(_subsym_51205);

        /** 		for i = cgi-n+1 to cgi do*/
        _26766 = _37cgi_50278 - _n_51210;
        if ((long)((unsigned long)_26766 +(unsigned long) HIGH_BITS) >= 0){
            _26766 = NewDouble((double)_26766);
        }
        if (IS_ATOM_INT(_26766)) {
            _26767 = _26766 + 1;
            if (_26767 > MAXINT){
                _26767 = NewDouble((double)_26767);
            }
        }
        else
        _26767 = binary_op(PLUS, 1, _26766);
        DeRef(_26766);
        _26766 = NOVALUE;
        _26768 = _37cgi_50278;
        {
            int _i_51491;
            Ref(_26767);
            _i_51491 = _26767;
L2C: 
            if (binary_op_a(GREATER, _i_51491, _26768)){
                goto L2D; // [1367] 1404
            }

            /** 			emit_addr(cg_stack[i])*/
            _2 = (int)SEQ_PTR(_37cg_stack_50277);
            if (!IS_ATOM_INT(_i_51491)){
                _26769 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51491)->dbl));
            }
            else{
                _26769 = (int)*(((s1_ptr)_2)->base + _i_51491);
            }
            Ref(_26769);
            _37emit_addr(_26769);
            _26769 = NOVALUE;

            /** 			emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (int)SEQ_PTR(_37cg_stack_50277);
            if (!IS_ATOM_INT(_i_51491)){
                _26770 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51491)->dbl));
            }
            else{
                _26770 = (int)*(((s1_ptr)_2)->base + _i_51491);
            }
            Ref(_26770);
            _37emit_temp(_26770, 1);
            _26770 = NOVALUE;

            /** 		end for*/
            _0 = _i_51491;
            if (IS_ATOM_INT(_i_51491)) {
                _i_51491 = _i_51491 + 1;
                if ((long)((unsigned long)_i_51491 +(unsigned long) HIGH_BITS) >= 0){
                    _i_51491 = NewDouble((double)_i_51491);
                }
            }
            else {
                _i_51491 = binary_op_a(PLUS, _i_51491, 1);
            }
            DeRef(_0);
            goto L2C; // [1399] 1374
L2D: 
            ;
            DeRef(_i_51491);
        }

        /** 		cgi -= n*/
        _37cgi_50278 = _37cgi_50278 - _n_51210;

        /** 		if SymTab[subsym][S_TOKEN] != PROC then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26772 = (int)*(((s1_ptr)_2)->base + _subsym_51205);
        _2 = (int)SEQ_PTR(_26772);
        if (!IS_ATOM_INT(_26S_TOKEN_11659)){
            _26773 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_TOKEN_11659)->dbl));
        }
        else{
            _26773 = (int)*(((s1_ptr)_2)->base + _26S_TOKEN_11659);
        }
        _26772 = NOVALUE;
        if (binary_op_a(EQUALS, _26773, 27)){
            _26773 = NOVALUE;
            goto LC; // [1428] 7412
        }
        _26773 = NOVALUE;

        /** 			assignable = TRUE*/
        _37assignable_50280 = _9TRUE_430;

        /** 			c = NewTempSym() -- put final result in temp*/
        _c_51201 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _37emit_temp(_c_51201, 1);

        /** 			Push(c)*/
        _37Push(_c_51201);

        /** 			emit_addr(c)*/
        _37emit_addr(_c_51201);
        goto LC; // [1464] 7412

        /** 	case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** 		assignable = FALSE -- assume for now*/
        _37assignable_50280 = _9FALSE_428;

        /** 		integer real_op*/

        /** 		if op = PROC_FORWARD then*/
        if (_op_51197 != 195)
        goto L2E; // [1485] 1501

        /** 			real_op = PROC*/
        _real_op_51512 = 27;
        goto L2F; // [1498] 1511
L2E: 

        /** 			real_op = FUNC*/
        _real_op_51512 = 501;
L2F: 

        /** 		integer ref*/

        /** 		ref = new_forward_reference( real_op, op_info1, real_op )*/
        _ref_51519 = _29new_forward_reference(_real_op_51512, _37op_info1_50262, _real_op_51512);
        if (!IS_ATOM_INT(_ref_51519)) {
            _1 = (long)(DBL_PTR(_ref_51519)->dbl);
            DeRefDS(_ref_51519);
            _ref_51519 = _1;
        }

        /** 		n = Pop() -- number of known args*/
        _n_51210 = _37Pop();
        if (!IS_ATOM_INT(_n_51210)) {
            _1 = (long)(DBL_PTR(_n_51210)->dbl);
            DeRefDS(_n_51210);
            _n_51210 = _1;
        }

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		emit_addr(ref)*/
        _37emit_addr(_ref_51519);

        /** 		emit_addr( n ) -- this changes to be the "next" instruction*/
        _37emit_addr(_n_51210);

        /** 		for i = cgi-n+1 to cgi do*/
        _26779 = _37cgi_50278 - _n_51210;
        if ((long)((unsigned long)_26779 +(unsigned long) HIGH_BITS) >= 0){
            _26779 = NewDouble((double)_26779);
        }
        if (IS_ATOM_INT(_26779)) {
            _26780 = _26779 + 1;
            if (_26780 > MAXINT){
                _26780 = NewDouble((double)_26780);
            }
        }
        else
        _26780 = binary_op(PLUS, 1, _26779);
        DeRef(_26779);
        _26779 = NOVALUE;
        _26781 = _37cgi_50278;
        {
            int _i_51524;
            Ref(_26780);
            _i_51524 = _26780;
L30: 
            if (binary_op_a(GREATER, _i_51524, _26781)){
                goto L31; // [1566] 1603
            }

            /** 			emit_addr(cg_stack[i])*/
            _2 = (int)SEQ_PTR(_37cg_stack_50277);
            if (!IS_ATOM_INT(_i_51524)){
                _26782 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51524)->dbl));
            }
            else{
                _26782 = (int)*(((s1_ptr)_2)->base + _i_51524);
            }
            Ref(_26782);
            _37emit_addr(_26782);
            _26782 = NOVALUE;

            /** 			emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (int)SEQ_PTR(_37cg_stack_50277);
            if (!IS_ATOM_INT(_i_51524)){
                _26783 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51524)->dbl));
            }
            else{
                _26783 = (int)*(((s1_ptr)_2)->base + _i_51524);
            }
            Ref(_26783);
            _37emit_temp(_26783, 1);
            _26783 = NOVALUE;

            /** 		end for*/
            _0 = _i_51524;
            if (IS_ATOM_INT(_i_51524)) {
                _i_51524 = _i_51524 + 1;
                if ((long)((unsigned long)_i_51524 +(unsigned long) HIGH_BITS) >= 0){
                    _i_51524 = NewDouble((double)_i_51524);
                }
            }
            else {
                _i_51524 = binary_op_a(PLUS, _i_51524, 1);
            }
            DeRef(_0);
            goto L30; // [1598] 1573
L31: 
            ;
            DeRef(_i_51524);
        }

        /** 		cgi -= n*/
        _37cgi_50278 = _37cgi_50278 - _n_51210;

        /** 		if op != PROC_FORWARD then*/
        if (_op_51197 == 195)
        goto L32; // [1615] 1651

        /** 			assignable = TRUE*/
        _37assignable_50280 = _9TRUE_430;

        /** 			c = NewTempSym() -- put final result in temp*/
        _c_51201 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 			Push(c)*/
        _37Push(_c_51201);

        /** 			emit_addr(c)*/
        _37emit_addr(_c_51201);

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _37emit_temp(_c_51201, 1);
L32: 
        goto LC; // [1653] 7412

        /** 	case WARNING then*/
        case 506:

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;

        /** 	    a = Pop()*/
        _a_51199 = _37Pop();
        if (!IS_ATOM_INT(_a_51199)) {
            _1 = (long)(DBL_PTR(_a_51199)->dbl);
            DeRefDS(_a_51199);
            _a_51199 = _1;
        }

        /** 		Warning(SymTab[a][S_OBJ], custom_warning_flag,"")*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26788 = (int)*(((s1_ptr)_2)->base + _a_51199);
        _2 = (int)SEQ_PTR(_26788);
        _26789 = (int)*(((s1_ptr)_2)->base + 1);
        _26788 = NOVALUE;
        Ref(_26789);
        RefDS(_22037);
        _43Warning(_26789, 64, _22037);
        _26789 = NOVALUE;
        goto LC; // [1694] 7412

        /** 	case INCLUDE_PATHS then*/
        case 507:

        /** 		sequence paths*/

        /** 		assignable = TRUE*/
        _37assignable_50280 = _9TRUE_430;

        /** 	    a = Pop()*/
        _a_51199 = _37Pop();
        if (!IS_ATOM_INT(_a_51199)) {
            _1 = (long)(DBL_PTR(_a_51199)->dbl);
            DeRefDS(_a_51199);
            _a_51199 = _1;
        }

        /** 	    emit_opcode(RIGHT_BRACE_N)*/
        _37emit_opcode(31);

        /** 	    paths = Include_paths(SymTab[a][S_OBJ])*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26791 = (int)*(((s1_ptr)_2)->base + _a_51199);
        _2 = (int)SEQ_PTR(_26791);
        _26792 = (int)*(((s1_ptr)_2)->base + 1);
        _26791 = NOVALUE;
        Ref(_26792);
        _0 = _paths_51549;
        _paths_51549 = _38Include_paths(_26792);
        DeRef(_0);
        _26792 = NOVALUE;

        /** 	    emit(length(paths))*/
        if (IS_SEQUENCE(_paths_51549)){
                _26794 = SEQ_PTR(_paths_51549)->length;
        }
        else {
            _26794 = 1;
        }
        _37emit(_26794);
        _26794 = NOVALUE;

        /** 	    for i=length(paths) to 1 by -1 do*/
        if (IS_SEQUENCE(_paths_51549)){
                _26795 = SEQ_PTR(_paths_51549)->length;
        }
        else {
            _26795 = 1;
        }
        {
            int _i_51561;
            _i_51561 = _26795;
L33: 
            if (_i_51561 < 1){
                goto L34; // [1756] 1787
            }

            /** 	        c = NewStringSym(paths[i])*/
            _2 = (int)SEQ_PTR(_paths_51549);
            _26796 = (int)*(((s1_ptr)_2)->base + _i_51561);
            Ref(_26796);
            _c_51201 = _52NewStringSym(_26796);
            _26796 = NOVALUE;
            if (!IS_ATOM_INT(_c_51201)) {
                _1 = (long)(DBL_PTR(_c_51201)->dbl);
                DeRefDS(_c_51201);
                _c_51201 = _1;
            }

            /** 	        emit_addr(c)*/
            _37emit_addr(_c_51201);

            /** 	    end for*/
            _i_51561 = _i_51561 + -1;
            goto L33; // [1782] 1763
L34: 
            ;
        }

        /** 	    b = NewTempSym()*/
        _b_51200 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 		emit_temp(b, NEW_REFERENCE)*/
        _37emit_temp(_b_51200, 1);

        /** 	    Push(b)*/
        _37Push(_b_51200);

        /** 	    emit_addr(b)*/
        _37emit_addr(_b_51200);

        /** 		last_op = RIGHT_BRACE_N*/
        _37last_op_51156 = 31;

        /** 		op = last_op*/
        _op_51197 = 31;
        DeRef(_paths_51549);
        _paths_51549 = NOVALUE;
        goto LC; // [1829] 7412

        /** 	case NOP1, NOP2, NOPWHILE, PRIVATE_INIT_CHECK, GLOBAL_INIT_CHECK,*/
        case 159:
        case 110:
        case 158:
        case 30:
        case 109:
        case 58:
        case 59:
        case 61:
        case 184:
        case 22:
        case 23:
        case 188:
        case 189:
        case 88:
        case 43:
        case 90:
        case 89:
        case 87:
        case 135:
        case 156:
        case 169:
        case 175:
        case 174:
        case 187:
        case 210:
        case 211:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;

        /** 		if op = UPDATE_GLOBALS then*/
        if (_op_51197 != 89)
        goto LC; // [1901] 7412

        /** 			last_op = last_op_backup*/
        _37last_op_51156 = _last_op_backup_51215;

        /** 			last_pc = last_pc_backup*/
        _37last_pc_51157 = _last_pc_backup_51214;
        goto LC; // [1916] 7412

        /** 	case IF, WHILE then*/
        case 20:
        case 47:

        /** 		a = Pop()*/
        _a_51199 = _37Pop();
        if (!IS_ATOM_INT(_a_51199)) {
            _1 = (long)(DBL_PTR(_a_51199)->dbl);
            DeRefDS(_a_51199);
            _a_51199 = _1;
        }

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;

        /** 		if previous_op >= LESS and previous_op <= NOT then*/
        _26801 = (_26previous_op_12081 >= 1);
        if (_26801 == 0) {
            goto L35; // [1948] 2240
        }
        _26803 = (_26previous_op_12081 <= 7);
        if (_26803 == 0)
        {
            DeRef(_26803);
            _26803 = NOVALUE;
            goto L35; // [1961] 2240
        }
        else{
            DeRef(_26803);
            _26803 = NOVALUE;
        }

        /** 			clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26804 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26804 = 1;
        }
        _2 = (int)SEQ_PTR(_26Code_12071);
        _26805 = (int)*(((s1_ptr)_2)->base + _26804);
        Ref(_26805);
        _37clear_temp(_26805);
        _26805 = NOVALUE;

        /** 			Code = Code[1..$-1]*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26806 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26806 = 1;
        }
        _26807 = _26806 - 1;
        _26806 = NOVALUE;
        rhs_slice_target = (object_ptr)&_26Code_12071;
        RHS_Slice(_26Code_12071, 1, _26807);

        /** 			if previous_op = NOT then*/
        if (_26previous_op_12081 != 7)
        goto L36; // [2002] 2082

        /** 				op = NOT_IFW*/
        _op_51197 = 108;

        /** 				backpatch(length(Code) - 1, op)*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26810 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26810 = 1;
        }
        _26811 = _26810 - 1;
        _26810 = NOVALUE;
        _37backpatch(_26811, 108);
        _26811 = NOVALUE;

        /** 				sequence if_code = Code[$-1..$]*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26812 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26812 = 1;
        }
        _26813 = _26812 - 1;
        _26812 = NOVALUE;
        if (IS_SEQUENCE(_26Code_12071)){
                _26814 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26814 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_51629;
        RHS_Slice(_26Code_12071, _26813, _26814);

        /** 				Code = Code[1..$-2]*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26816 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26816 = 1;
        }
        _26817 = _26816 - 2;
        _26816 = NOVALUE;
        rhs_slice_target = (object_ptr)&_26Code_12071;
        RHS_Slice(_26Code_12071, 1, _26817);

        /** 				Code &= if_code*/
        Concat((object_ptr)&_26Code_12071, _26Code_12071, _if_code_51629);
        DeRefDS(_if_code_51629);
        _if_code_51629 = NOVALUE;
        goto L37; // [2079] 2227
L36: 

        /** 				if IsInteger(Code[$-1]) and IsInteger(Code[$]) then*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26820 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26820 = 1;
        }
        _26821 = _26820 - 1;
        _26820 = NOVALUE;
        _2 = (int)SEQ_PTR(_26Code_12071);
        _26822 = (int)*(((s1_ptr)_2)->base + _26821);
        Ref(_26822);
        _26823 = _37IsInteger(_26822);
        _26822 = NOVALUE;
        if (IS_ATOM_INT(_26823)) {
            if (_26823 == 0) {
                goto L38; // [2101] 2143
            }
        }
        else {
            if (DBL_PTR(_26823)->dbl == 0.0) {
                goto L38; // [2101] 2143
            }
        }
        if (IS_SEQUENCE(_26Code_12071)){
                _26825 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26825 = 1;
        }
        _2 = (int)SEQ_PTR(_26Code_12071);
        _26826 = (int)*(((s1_ptr)_2)->base + _26825);
        Ref(_26826);
        _26827 = _37IsInteger(_26826);
        _26826 = NOVALUE;
        if (_26827 == 0) {
            DeRef(_26827);
            _26827 = NOVALUE;
            goto L38; // [2119] 2143
        }
        else {
            if (!IS_ATOM_INT(_26827) && DBL_PTR(_26827)->dbl == 0.0){
                DeRef(_26827);
                _26827 = NOVALUE;
                goto L38; // [2119] 2143
            }
            DeRef(_26827);
            _26827 = NOVALUE;
        }
        DeRef(_26827);
        _26827 = NOVALUE;

        /** 					op = previous_op + LESS_IFW_I - LESS*/
        _26828 = _26previous_op_12081 + 119;
        if ((long)((unsigned long)_26828 + (unsigned long)HIGH_BITS) >= 0) 
        _26828 = NewDouble((double)_26828);
        if (IS_ATOM_INT(_26828)) {
            _op_51197 = _26828 - 1;
        }
        else {
            _op_51197 = NewDouble(DBL_PTR(_26828)->dbl - (double)1);
        }
        DeRef(_26828);
        _26828 = NOVALUE;
        if (!IS_ATOM_INT(_op_51197)) {
            _1 = (long)(DBL_PTR(_op_51197)->dbl);
            DeRefDS(_op_51197);
            _op_51197 = _1;
        }
        goto L39; // [2140] 2162
L38: 

        /** 					op = previous_op + LESS_IFW - LESS*/
        _26830 = _26previous_op_12081 + 102;
        if ((long)((unsigned long)_26830 + (unsigned long)HIGH_BITS) >= 0) 
        _26830 = NewDouble((double)_26830);
        if (IS_ATOM_INT(_26830)) {
            _op_51197 = _26830 - 1;
        }
        else {
            _op_51197 = NewDouble(DBL_PTR(_26830)->dbl - (double)1);
        }
        DeRef(_26830);
        _26830 = NOVALUE;
        if (!IS_ATOM_INT(_op_51197)) {
            _1 = (long)(DBL_PTR(_op_51197)->dbl);
            DeRefDS(_op_51197);
            _op_51197 = _1;
        }
L39: 

        /** 				backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26832 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26832 = 1;
        }
        _26833 = _26832 - 2;
        _26832 = NOVALUE;
        _37backpatch(_26833, _op_51197);
        _26833 = NOVALUE;

        /** 				sequence if_code = Code[$-2..$]*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26834 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26834 = 1;
        }
        _26835 = _26834 - 2;
        _26834 = NOVALUE;
        if (IS_SEQUENCE(_26Code_12071)){
                _26836 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26836 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_51668;
        RHS_Slice(_26Code_12071, _26835, _26836);

        /** 				Code = Code[1..$-3]*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26838 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26838 = 1;
        }
        _26839 = _26838 - 3;
        _26838 = NOVALUE;
        rhs_slice_target = (object_ptr)&_26Code_12071;
        RHS_Slice(_26Code_12071, 1, _26839);

        /** 				Code &= if_code*/
        Concat((object_ptr)&_26Code_12071, _26Code_12071, _if_code_51668);
        DeRefDS(_if_code_51668);
        _if_code_51668 = NOVALUE;
L37: 

        /** 			last_pc = last_pc_backup*/
        _37last_pc_51157 = _last_pc_backup_51214;

        /** 			last_op = op*/
        _37last_op_51156 = _op_51197;
        goto LC; // [2237] 7412
L35: 

        /** 		elsif op = WHILE and*/
        _26842 = (_op_51197 == 47);
        if (_26842 == 0) {
            _26843 = 0;
            goto L3A; // [2248] 2260
        }
        _26844 = (_a_51199 > 0);
        _26843 = (_26844 != 0);
L3A: 
        if (_26843 == 0) {
            _26845 = 0;
            goto L3B; // [2260] 2286
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26846 = (int)*(((s1_ptr)_2)->base + _a_51199);
        _2 = (int)SEQ_PTR(_26846);
        _26847 = (int)*(((s1_ptr)_2)->base + 3);
        _26846 = NOVALUE;
        if (IS_ATOM_INT(_26847)) {
            _26848 = (_26847 == 2);
        }
        else {
            _26848 = binary_op(EQUALS, _26847, 2);
        }
        _26847 = NOVALUE;
        if (IS_ATOM_INT(_26848))
        _26845 = (_26848 != 0);
        else
        _26845 = DBL_PTR(_26848)->dbl != 0.0;
L3B: 
        if (_26845 == 0) {
            _26849 = 0;
            goto L3C; // [2286] 2309
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26850 = (int)*(((s1_ptr)_2)->base + _a_51199);
        _2 = (int)SEQ_PTR(_26850);
        _26851 = (int)*(((s1_ptr)_2)->base + 1);
        _26850 = NOVALUE;
        if (IS_ATOM_INT(_26851))
        _26852 = 1;
        else if (IS_ATOM_DBL(_26851))
        _26852 = IS_ATOM_INT(DoubleToInt(_26851));
        else
        _26852 = 0;
        _26851 = NOVALUE;
        _26849 = (_26852 != 0);
L3C: 
        if (_26849 == 0) {
            goto L3D; // [2309] 2358
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26854 = (int)*(((s1_ptr)_2)->base + _a_51199);
        _2 = (int)SEQ_PTR(_26854);
        _26855 = (int)*(((s1_ptr)_2)->base + 1);
        _26854 = NOVALUE;
        if (_26855 == 0)
        _26856 = 1;
        else if (IS_ATOM_INT(_26855) && IS_ATOM_INT(0))
        _26856 = 0;
        else
        _26856 = (compare(_26855, 0) == 0);
        _26855 = NOVALUE;
        _26857 = (_26856 == 0);
        _26856 = NOVALUE;
        if (_26857 == 0)
        {
            DeRef(_26857);
            _26857 = NOVALUE;
            goto L3D; // [2333] 2358
        }
        else{
            DeRef(_26857);
            _26857 = NOVALUE;
        }

        /** 			optimized_while = TRUE   -- while TRUE ... emit nothing*/
        _37optimized_while_50264 = _9TRUE_430;

        /** 			last_pc = last_pc_backup*/
        _37last_pc_51157 = _last_pc_backup_51214;

        /** 			last_op = last_op_backup*/
        _37last_op_51156 = _last_op_backup_51215;
        goto LC; // [2355] 7412
L3D: 

        /** 			flush_temps( {a} )*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _a_51199;
        _26858 = MAKE_SEQ(_1);
        _37flush_temps(_26858);
        _26858 = NOVALUE;

        /** 			emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 			emit_addr(a)*/
        _37emit_addr(_a_51199);
        goto LC; // [2378] 7412

        /** 	case INTEGER_CHECK then*/
        case 96:

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;

        /** 		if previous_op = ASSIGN then*/
        if (_26previous_op_12081 != 18)
        goto L3E; // [2397] 2456

        /** 			c = Code[$-1]*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26860 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26860 = 1;
        }
        _26861 = _26860 - 1;
        _26860 = NOVALUE;
        _2 = (int)SEQ_PTR(_26Code_12071);
        _c_51201 = (int)*(((s1_ptr)_2)->base + _26861);
        if (!IS_ATOM_INT(_c_51201)){
            _c_51201 = (long)DBL_PTR(_c_51201)->dbl;
        }

        /** 			if not IsInteger(c) then*/
        _26863 = _37IsInteger(_c_51201);
        if (IS_ATOM_INT(_26863)) {
            if (_26863 != 0){
                DeRef(_26863);
                _26863 = NOVALUE;
                goto L3F; // [2424] 2442
            }
        }
        else {
            if (DBL_PTR(_26863)->dbl != 0.0){
                DeRef(_26863);
                _26863 = NOVALUE;
                goto L3F; // [2424] 2442
            }
        }
        DeRef(_26863);
        _26863 = NOVALUE;

        /** 				emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 				emit_addr(op_info1)*/
        _37emit_addr(_37op_info1_50262);
        goto L40; // [2439] 2513
L3F: 

        /** 				last_op = last_op_backup*/
        _37last_op_51156 = _last_op_backup_51215;

        /** 				last_pc = last_pc_backup*/
        _37last_pc_51157 = _last_pc_backup_51214;
        goto L40; // [2453] 2513
L3E: 

        /** 		elsif previous_op = -1 or*/
        _26865 = (_26previous_op_12081 == -1);
        if (_26865 != 0) {
            goto L41; // [2464] 2487
        }
        _2 = (int)SEQ_PTR(_37op_result_50878);
        _26867 = (int)*(((s1_ptr)_2)->base + _26previous_op_12081);
        _26868 = (_26867 != 1);
        _26867 = NOVALUE;
        if (_26868 == 0)
        {
            DeRef(_26868);
            _26868 = NOVALUE;
            goto L42; // [2483] 2502
        }
        else{
            DeRef(_26868);
            _26868 = NOVALUE;
        }
L41: 

        /** 			emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 			emit_addr(op_info1)*/
        _37emit_addr(_37op_info1_50262);
        goto L40; // [2499] 2513
L42: 

        /** 			last_op = last_op_backup*/
        _37last_op_51156 = _last_op_backup_51215;

        /** 			last_pc = last_pc_backup*/
        _37last_pc_51157 = _last_pc_backup_51214;
L40: 

        /** 		clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26869 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26869 = 1;
        }
        _26870 = _26869 - 1;
        _26869 = NOVALUE;
        _2 = (int)SEQ_PTR(_26Code_12071);
        _26871 = (int)*(((s1_ptr)_2)->base + _26870);
        Ref(_26871);
        _37clear_temp(_26871);
        _26871 = NOVALUE;
        goto LC; // [2531] 7412

        /** 	case SEQUENCE_CHECK then*/
        case 97:

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;

        /** 		if previous_op = ASSIGN then*/
        if (_26previous_op_12081 != 18)
        goto L43; // [2550] 2677

        /** 			c = Code[$-1]*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26873 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26873 = 1;
        }
        _26874 = _26873 - 1;
        _26873 = NOVALUE;
        _2 = (int)SEQ_PTR(_26Code_12071);
        _c_51201 = (int)*(((s1_ptr)_2)->base + _26874);
        if (!IS_ATOM_INT(_c_51201)){
            _c_51201 = (long)DBL_PTR(_c_51201)->dbl;
        }

        /** 			if c < 1 or*/
        _26876 = (_c_51201 < 1);
        if (_26876 != 0) {
            _26877 = 1;
            goto L44; // [2577] 2603
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26878 = (int)*(((s1_ptr)_2)->base + _c_51201);
        _2 = (int)SEQ_PTR(_26878);
        _26879 = (int)*(((s1_ptr)_2)->base + 3);
        _26878 = NOVALUE;
        if (IS_ATOM_INT(_26879)) {
            _26880 = (_26879 != 2);
        }
        else {
            _26880 = binary_op(NOTEQ, _26879, 2);
        }
        _26879 = NOVALUE;
        if (IS_ATOM_INT(_26880))
        _26877 = (_26880 != 0);
        else
        _26877 = DBL_PTR(_26880)->dbl != 0.0;
L44: 
        if (_26877 != 0) {
            goto L45; // [2603] 2630
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26882 = (int)*(((s1_ptr)_2)->base + _c_51201);
        _2 = (int)SEQ_PTR(_26882);
        _26883 = (int)*(((s1_ptr)_2)->base + 1);
        _26882 = NOVALUE;
        _26884 = IS_SEQUENCE(_26883);
        _26883 = NOVALUE;
        _26885 = (_26884 == 0);
        _26884 = NOVALUE;
        if (_26885 == 0)
        {
            DeRef(_26885);
            _26885 = NOVALUE;
            goto L46; // [2626] 2663
        }
        else{
            DeRef(_26885);
            _26885 = NOVALUE;
        }
L45: 

        /** 				emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 				emit_addr(op_info1)*/
        _37emit_addr(_37op_info1_50262);

        /** 				clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26886 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26886 = 1;
        }
        _26887 = _26886 - 1;
        _26886 = NOVALUE;
        _2 = (int)SEQ_PTR(_26Code_12071);
        _26888 = (int)*(((s1_ptr)_2)->base + _26887);
        Ref(_26888);
        _37clear_temp(_26888);
        _26888 = NOVALUE;
        goto LC; // [2660] 7412
L46: 

        /** 				last_op = last_op_backup*/
        _37last_op_51156 = _last_op_backup_51215;

        /** 				last_pc = last_pc_backup*/
        _37last_pc_51157 = _last_pc_backup_51214;
        goto LC; // [2674] 7412
L43: 

        /** 		elsif previous_op = -1 or op_result[previous_op] != T_SEQUENCE then*/
        _26889 = (_26previous_op_12081 == -1);
        if (_26889 != 0) {
            goto L47; // [2685] 2708
        }
        _2 = (int)SEQ_PTR(_37op_result_50878);
        _26891 = (int)*(((s1_ptr)_2)->base + _26previous_op_12081);
        _26892 = (_26891 != 2);
        _26891 = NOVALUE;
        if (_26892 == 0)
        {
            DeRef(_26892);
            _26892 = NOVALUE;
            goto L48; // [2704] 2741
        }
        else{
            DeRef(_26892);
            _26892 = NOVALUE;
        }
L47: 

        /** 			emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 			emit_addr(op_info1)*/
        _37emit_addr(_37op_info1_50262);

        /** 			clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26893 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26893 = 1;
        }
        _26894 = _26893 - 1;
        _26893 = NOVALUE;
        _2 = (int)SEQ_PTR(_26Code_12071);
        _26895 = (int)*(((s1_ptr)_2)->base + _26894);
        Ref(_26895);
        _37clear_temp(_26895);
        _26895 = NOVALUE;
        goto LC; // [2738] 7412
L48: 

        /** 			last_op = last_op_backup*/
        _37last_op_51156 = _last_op_backup_51215;

        /** 			last_pc = last_pc_backup*/
        _37last_pc_51157 = _last_pc_backup_51214;
        goto LC; // [2752] 7412

        /** 	case ATOM_CHECK then*/
        case 101:

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;

        /** 		if previous_op = ASSIGN then*/
        if (_26previous_op_12081 != 18)
        goto L49; // [2771] 2970

        /** 			c = Code[$-1]*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26897 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26897 = 1;
        }
        _26898 = _26897 - 1;
        _26897 = NOVALUE;
        _2 = (int)SEQ_PTR(_26Code_12071);
        _c_51201 = (int)*(((s1_ptr)_2)->base + _26898);
        if (!IS_ATOM_INT(_c_51201)){
            _c_51201 = (long)DBL_PTR(_c_51201)->dbl;
        }

        /** 			if c > 1*/
        _26900 = (_c_51201 > 1);
        if (_26900 == 0) {
            goto L4A; // [2798] 2919
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26902 = (int)*(((s1_ptr)_2)->base + _c_51201);
        _2 = (int)SEQ_PTR(_26902);
        _26903 = (int)*(((s1_ptr)_2)->base + 3);
        _26902 = NOVALUE;
        if (IS_ATOM_INT(_26903)) {
            _26904 = (_26903 == 2);
        }
        else {
            _26904 = binary_op(EQUALS, _26903, 2);
        }
        _26903 = NOVALUE;
        if (_26904 == 0) {
            DeRef(_26904);
            _26904 = NOVALUE;
            goto L4A; // [2821] 2919
        }
        else {
            if (!IS_ATOM_INT(_26904) && DBL_PTR(_26904)->dbl == 0.0){
                DeRef(_26904);
                _26904 = NOVALUE;
                goto L4A; // [2821] 2919
            }
            DeRef(_26904);
            _26904 = NOVALUE;
        }
        DeRef(_26904);
        _26904 = NOVALUE;

        /** 				if sequence( SymTab[c][S_OBJ] ) then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26905 = (int)*(((s1_ptr)_2)->base + _c_51201);
        _2 = (int)SEQ_PTR(_26905);
        _26906 = (int)*(((s1_ptr)_2)->base + 1);
        _26905 = NOVALUE;
        _26907 = IS_SEQUENCE(_26906);
        _26906 = NOVALUE;
        if (_26907 == 0)
        {
            _26907 = NOVALUE;
            goto L4B; // [2841] 2870
        }
        else{
            _26907 = NOVALUE;
        }

        /** 					ThisLine = ExprLine*/
        RefDS(_30ExprLine_56205);
        DeRef(_43ThisLine_48557);
        _43ThisLine_48557 = _30ExprLine_56205;

        /** 					bp = expr_bp*/
        _43bp_48561 = _30expr_bp_56206;

        /** 					CompileErr( 346 )*/
        RefDS(_22037);
        _43CompileErr(346, _22037, 0);
        goto L4C; // [2867] 3049
L4B: 

        /** 				elsif SymTab[c][S_OBJ] = NOVALUE then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26908 = (int)*(((s1_ptr)_2)->base + _c_51201);
        _2 = (int)SEQ_PTR(_26908);
        _26909 = (int)*(((s1_ptr)_2)->base + 1);
        _26908 = NOVALUE;
        if (binary_op_a(NOTEQ, _26909, _26NOVALUE_11836)){
            _26909 = NOVALUE;
            goto L4D; // [2886] 2905
        }
        _26909 = NOVALUE;

        /** 					emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 					emit_addr(op_info1)*/
        _37emit_addr(_37op_info1_50262);
        goto L4C; // [2902] 3049
L4D: 

        /** 					last_op = last_op_backup*/
        _37last_op_51156 = _last_op_backup_51215;

        /** 					last_pc = last_pc_backup*/
        _37last_pc_51157 = _last_pc_backup_51214;
        goto L4C; // [2916] 3049
L4A: 

        /** 			elsif c < 1 */
        _26911 = (_c_51201 < 1);
        if (_26911 != 0) {
            goto L4E; // [2925] 2941
        }
        _26913 = _37IsInteger(_c_51201);
        if (IS_ATOM_INT(_26913)) {
            _26914 = (_26913 == 0);
        }
        else {
            _26914 = unary_op(NOT, _26913);
        }
        DeRef(_26913);
        _26913 = NOVALUE;
        if (_26914 == 0) {
            DeRef(_26914);
            _26914 = NOVALUE;
            goto L4F; // [2937] 2956
        }
        else {
            if (!IS_ATOM_INT(_26914) && DBL_PTR(_26914)->dbl == 0.0){
                DeRef(_26914);
                _26914 = NOVALUE;
                goto L4F; // [2937] 2956
            }
            DeRef(_26914);
            _26914 = NOVALUE;
        }
        DeRef(_26914);
        _26914 = NOVALUE;
L4E: 

        /** 				emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 				emit_addr(op_info1)*/
        _37emit_addr(_37op_info1_50262);
        goto L4C; // [2953] 3049
L4F: 

        /** 				last_op = last_op_backup*/
        _37last_op_51156 = _last_op_backup_51215;

        /** 				last_pc = last_pc_backup*/
        _37last_pc_51157 = _last_pc_backup_51214;
        goto L4C; // [2967] 3049
L49: 

        /** 		elsif previous_op = -1 or*/
        _26915 = (_26previous_op_12081 == -1);
        if (_26915 != 0) {
            goto L50; // [2978] 3023
        }
        _2 = (int)SEQ_PTR(_37op_result_50878);
        _26917 = (int)*(((s1_ptr)_2)->base + _26previous_op_12081);
        _26918 = (_26917 != 1);
        _26917 = NOVALUE;
        if (_26918 == 0) {
            DeRef(_26919);
            _26919 = 0;
            goto L51; // [2996] 3018
        }
        _2 = (int)SEQ_PTR(_37op_result_50878);
        _26920 = (int)*(((s1_ptr)_2)->base + _26previous_op_12081);
        _26921 = (_26920 != 3);
        _26920 = NOVALUE;
        _26919 = (_26921 != 0);
L51: 
        if (_26919 == 0)
        {
            _26919 = NOVALUE;
            goto L52; // [3019] 3038
        }
        else{
            _26919 = NOVALUE;
        }
L50: 

        /** 			emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 			emit_addr(op_info1)*/
        _37emit_addr(_37op_info1_50262);
        goto L4C; // [3035] 3049
L52: 

        /** 			last_op = last_op_backup*/
        _37last_op_51156 = _last_op_backup_51215;

        /** 			last_pc = last_pc_backup*/
        _37last_pc_51157 = _last_pc_backup_51214;
L4C: 

        /** 		clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_26Code_12071)){
                _26922 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _26922 = 1;
        }
        _26923 = _26922 - 1;
        _26922 = NOVALUE;
        _2 = (int)SEQ_PTR(_26Code_12071);
        _26924 = (int)*(((s1_ptr)_2)->base + _26923);
        Ref(_26924);
        _37clear_temp(_26924);
        _26924 = NOVALUE;
        goto LC; // [3067] 7412

        /** 	case RIGHT_BRACE_N then*/
        case 31:

        /** 		n = op_info1*/
        _n_51210 = _37op_info1_50262;

        /** 		elements = {}*/
        RefDS(_22037);
        DeRef(_elements_51212);
        _elements_51212 = _22037;

        /** 		for i = 1 to n do*/
        _26925 = _n_51210;
        {
            int _i_51848;
            _i_51848 = 1;
L53: 
            if (_i_51848 > _26925){
                goto L54; // [3092] 3115
            }

            /** 			elements = append(elements, Pop())*/
            _26926 = _37Pop();
            Ref(_26926);
            Append(&_elements_51212, _elements_51212, _26926);
            DeRef(_26926);
            _26926 = NOVALUE;

            /** 		end for*/
            _i_51848 = _i_51848 + 1;
            goto L53; // [3110] 3099
L54: 
            ;
        }

        /** 		element_vals = good_string(elements)*/
        RefDS(_elements_51212);
        _0 = _element_vals_51213;
        _element_vals_51213 = _37good_string(_elements_51212);
        DeRef(_0);

        /** 		if sequence(element_vals) then*/
        _26929 = IS_SEQUENCE(_element_vals_51213);
        if (_26929 == 0)
        {
            _26929 = NOVALUE;
            goto L55; // [3126] 3157
        }
        else{
            _26929 = NOVALUE;
        }

        /** 			c = NewStringSym(element_vals)  -- make a string literal*/
        Ref(_element_vals_51213);
        _c_51201 = _52NewStringSym(_element_vals_51213);
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 			assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;

        /** 			last_op = last_op_backup*/
        _37last_op_51156 = _last_op_backup_51215;

        /** 			last_pc = last_pc_backup*/
        _37last_pc_51157 = _last_pc_backup_51214;
        goto L56; // [3154] 3248
L55: 

        /** 			if n = 2 then*/
        if (_n_51210 != 2)
        goto L57; // [3159] 3182

        /** 				emit_opcode(RIGHT_BRACE_2) -- faster op for two items*/
        _37emit_opcode(85);

        /** 				last_op = RIGHT_BRACE_2*/
        _37last_op_51156 = 85;
        goto L58; // [3179] 3193
L57: 

        /** 				emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 				emit(n)*/
        _37emit(_n_51210);
L58: 

        /** 			for i = 1 to n do*/
        _26932 = _n_51210;
        {
            int _i_51865;
            _i_51865 = 1;
L59: 
            if (_i_51865 > _26932){
                goto L5A; // [3198] 3221
            }

            /** 				emit_addr(elements[i])*/
            _2 = (int)SEQ_PTR(_elements_51212);
            _26933 = (int)*(((s1_ptr)_2)->base + _i_51865);
            Ref(_26933);
            _37emit_addr(_26933);
            _26933 = NOVALUE;

            /** 			end for*/
            _i_51865 = _i_51865 + 1;
            goto L59; // [3216] 3205
L5A: 
            ;
        }

        /** 			c = NewTempSym()*/
        _c_51201 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 			emit_addr(c)*/
        _37emit_addr(_c_51201);

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _37emit_temp(_c_51201, 1);

        /** 			assignable = TRUE*/
        _37assignable_50280 = _9TRUE_430;
L56: 

        /** 		Push(c)*/
        _37Push(_c_51201);
        goto LC; // [3253] 7412

        /** 	case ASSIGN_SUBS2,      -- can't change the op*/
        case 148:
        case 16:
        case 162:

        /** 		b = Pop() -- rhs value*/
        _b_51200 = _37Pop();
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 		a = Pop() -- subscript*/
        _a_51199 = _37Pop();
        if (!IS_ATOM_INT(_a_51199)) {
            _1 = (long)(DBL_PTR(_a_51199)->dbl);
            DeRefDS(_a_51199);
            _a_51199 = _1;
        }

        /** 		c = Pop() -- sequence*/
        _c_51201 = _37Pop();
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		if op = ASSIGN_SUBS then*/
        if (_op_51197 != 16)
        goto L5B; // [3288] 3480

        /** 			if (previous_op != LHS_SUBS) and*/
        _26939 = (_26previous_op_12081 != 95);
        if (_26939 == 0) {
            _26940 = 0;
            goto L5C; // [3302] 3314
        }
        _26941 = (_c_51201 > 0);
        _26940 = (_26941 != 0);
L5C: 
        if (_26940 == 0) {
            goto L5D; // [3314] 3452
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26943 = (int)*(((s1_ptr)_2)->base + _c_51201);
        _2 = (int)SEQ_PTR(_26943);
        _26944 = (int)*(((s1_ptr)_2)->base + 3);
        _26943 = NOVALUE;
        if (IS_ATOM_INT(_26944)) {
            _26945 = (_26944 != 1);
        }
        else {
            _26945 = binary_op(NOTEQ, _26944, 1);
        }
        _26944 = NOVALUE;
        if (IS_ATOM_INT(_26945)) {
            if (_26945 != 0) {
                DeRef(_26946);
                _26946 = 1;
                goto L5E; // [3336] 3436
            }
        }
        else {
            if (DBL_PTR(_26945)->dbl != 0.0) {
                DeRef(_26946);
                _26946 = 1;
                goto L5E; // [3336] 3436
            }
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26947 = (int)*(((s1_ptr)_2)->base + _c_51201);
        _2 = (int)SEQ_PTR(_26947);
        _26948 = (int)*(((s1_ptr)_2)->base + 15);
        _26947 = NOVALUE;
        if (IS_ATOM_INT(_26948)) {
            _26949 = (_26948 != _52sequence_type_46134);
        }
        else {
            _26949 = binary_op(NOTEQ, _26948, _52sequence_type_46134);
        }
        _26948 = NOVALUE;
        if (IS_ATOM_INT(_26949)) {
            if (_26949 == 0) {
                DeRef(_26950);
                _26950 = 0;
                goto L5F; // [3358] 3432
            }
        }
        else {
            if (DBL_PTR(_26949)->dbl == 0.0) {
                DeRef(_26950);
                _26950 = 0;
                goto L5F; // [3358] 3432
            }
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26951 = (int)*(((s1_ptr)_2)->base + _c_51201);
        _2 = (int)SEQ_PTR(_26951);
        _26952 = (int)*(((s1_ptr)_2)->base + 15);
        _26951 = NOVALUE;
        if (IS_ATOM_INT(_26952)) {
            _26953 = (_26952 > 0);
        }
        else {
            _26953 = binary_op(GREATER, _26952, 0);
        }
        _26952 = NOVALUE;
        if (IS_ATOM_INT(_26953)) {
            if (_26953 == 0) {
                DeRef(_26954);
                _26954 = 0;
                goto L60; // [3378] 3428
            }
        }
        else {
            if (DBL_PTR(_26953)->dbl == 0.0) {
                DeRef(_26954);
                _26954 = 0;
                goto L60; // [3378] 3428
            }
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26955 = (int)*(((s1_ptr)_2)->base + _c_51201);
        _2 = (int)SEQ_PTR(_26955);
        _26956 = (int)*(((s1_ptr)_2)->base + 15);
        _26955 = NOVALUE;
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!IS_ATOM_INT(_26956)){
            _26957 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26956)->dbl));
        }
        else{
            _26957 = (int)*(((s1_ptr)_2)->base + _26956);
        }
        _2 = (int)SEQ_PTR(_26957);
        _26958 = (int)*(((s1_ptr)_2)->base + 2);
        _26957 = NOVALUE;
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!IS_ATOM_INT(_26958)){
            _26959 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26958)->dbl));
        }
        else{
            _26959 = (int)*(((s1_ptr)_2)->base + _26958);
        }
        _2 = (int)SEQ_PTR(_26959);
        _26960 = (int)*(((s1_ptr)_2)->base + 15);
        _26959 = NOVALUE;
        if (IS_ATOM_INT(_26960)) {
            _26961 = (_26960 != _52sequence_type_46134);
        }
        else {
            _26961 = binary_op(NOTEQ, _26960, _52sequence_type_46134);
        }
        _26960 = NOVALUE;
        DeRef(_26954);
        if (IS_ATOM_INT(_26961))
        _26954 = (_26961 != 0);
        else
        _26954 = DBL_PTR(_26961)->dbl != 0.0;
L60: 
        DeRef(_26950);
        _26950 = (_26954 != 0);
L5F: 
        DeRef(_26946);
        _26946 = (_26950 != 0);
L5E: 
        if (_26946 == 0)
        {
            _26946 = NOVALUE;
            goto L5D; // [3437] 3452
        }
        else{
            _26946 = NOVALUE;
        }

        /** 				op = ASSIGN_SUBS_CHECK*/
        _op_51197 = 84;
        goto L61; // [3449] 3472
L5D: 

        /** 				if IsInteger(b) then*/
        _26962 = _37IsInteger(_b_51200);
        if (_26962 == 0) {
            DeRef(_26962);
            _26962 = NOVALUE;
            goto L62; // [3458] 3471
        }
        else {
            if (!IS_ATOM_INT(_26962) && DBL_PTR(_26962)->dbl == 0.0){
                DeRef(_26962);
                _26962 = NOVALUE;
                goto L62; // [3458] 3471
            }
            DeRef(_26962);
            _26962 = NOVALUE;
        }
        DeRef(_26962);
        _26962 = NOVALUE;

        /** 					op = ASSIGN_SUBS_I*/
        _op_51197 = 118;
L62: 
L61: 

        /** 			emit_opcode(op)*/
        _37emit_opcode(_op_51197);
        goto L63; // [3477] 3506
L5B: 

        /** 		elsif op = PASSIGN_SUBS then*/
        if (_op_51197 != 162)
        goto L64; // [3484] 3498

        /** 			emit_opcode(PASSIGN_SUBS) -- always*/
        _37emit_opcode(162);
        goto L63; // [3495] 3506
L64: 

        /** 			emit_opcode(ASSIGN_SUBS) -- always*/
        _37emit_opcode(16);
L63: 

        /** 		emit_addr(c) -- sequence*/
        _37emit_addr(_c_51201);

        /** 		emit_addr(a) -- subscript*/
        _37emit_addr(_a_51199);

        /** 		emit_addr(b) -- rhs value*/
        _37emit_addr(_b_51200);

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [3528] 7412

        /** 	case LHS_SUBS, LHS_SUBS1, LHS_SUBS1_COPY then*/
        case 95:
        case 161:
        case 166:

        /** 		a = Pop() -- subs*/
        _a_51199 = _37Pop();
        if (!IS_ATOM_INT(_a_51199)) {
            _1 = (long)(DBL_PTR(_a_51199)->dbl);
            DeRefDS(_a_51199);
            _a_51199 = _1;
        }

        /** 		lhs_var = Pop() -- sequence*/
        _lhs_var_51207 = _37Pop();
        if (!IS_ATOM_INT(_lhs_var_51207)) {
            _1 = (long)(DBL_PTR(_lhs_var_51207)->dbl);
            DeRefDS(_lhs_var_51207);
            _lhs_var_51207 = _1;
        }

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		emit_addr(lhs_var)*/
        _37emit_addr(_lhs_var_51207);

        /** 		emit_addr(a)*/
        _37emit_addr(_a_51199);

        /** 		if op = LHS_SUBS then*/
        if (_op_51197 != 95)
        goto L65; // [3571] 3602

        /** 			TempKeep(lhs_var) -- should be lhs_target_temp*/
        _37TempKeep(_lhs_var_51207);

        /** 			emit_addr(lhs_target_temp)*/
        _37emit_addr(_37lhs_target_temp_50276);

        /** 			Push(lhs_target_temp)*/
        _37Push(_37lhs_target_temp_50276);

        /** 			emit_addr(0) -- place holder*/
        _37emit_addr(0);
        goto L66; // [3599] 3656
L65: 

        /** 			lhs_target_temp = NewTempSym() -- use same temp for all subscripts*/
        _0 = _52NewTempSym(0);
        _37lhs_target_temp_50276 = _0;
        if (!IS_ATOM_INT(_37lhs_target_temp_50276)) {
            _1 = (long)(DBL_PTR(_37lhs_target_temp_50276)->dbl);
            DeRefDS(_37lhs_target_temp_50276);
            _37lhs_target_temp_50276 = _1;
        }

        /** 			emit_addr(lhs_target_temp) -- target temp holds pointer to sequence*/
        _37emit_addr(_37lhs_target_temp_50276);

        /** 			emit_temp(lhs_target_temp, NEW_REFERENCE )*/
        _37emit_temp(_37lhs_target_temp_50276, 1);

        /** 			Push(lhs_target_temp)*/
        _37Push(_37lhs_target_temp_50276);

        /** 			lhs_subs1_copy_temp = NewTempSym() -- place to copy (may be ignored)*/
        _0 = _52NewTempSym(0);
        _37lhs_subs1_copy_temp_50275 = _0;
        if (!IS_ATOM_INT(_37lhs_subs1_copy_temp_50275)) {
            _1 = (long)(DBL_PTR(_37lhs_subs1_copy_temp_50275)->dbl);
            DeRefDS(_37lhs_subs1_copy_temp_50275);
            _37lhs_subs1_copy_temp_50275 = _1;
        }

        /** 			emit_addr(lhs_subs1_copy_temp)*/
        _37emit_addr(_37lhs_subs1_copy_temp_50275);

        /** 			emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
        _37emit_temp(_37lhs_subs1_copy_temp_50275, 1);
L66: 

        /** 		current_sequence = append(current_sequence, lhs_target_temp)*/
        Append(&_37current_sequence_50270, _37current_sequence_50270, _37lhs_target_temp_50276);

        /** 		assignable = FALSE  -- need to update current_sequence like in RHS_SUBS*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [3673] 7412

        /** 	case RAND, PEEK, PEEK4S, PEEK4U, NOT_BITS, NOT,*/
        case 62:
        case 127:
        case 139:
        case 140:
        case 51:
        case 7:
        case 173:
        case 180:
        case 179:
        case 181:
        case 182:

        /** 		cont11ii(op, TRUE)*/
        _37cont11ii(_op_51197, _9TRUE_430);
        goto LC; // [3707] 7412

        /** 	case UMINUS then*/
        case 12:

        /** 		a = Pop()*/
        _a_51199 = _37Pop();
        if (!IS_ATOM_INT(_a_51199)) {
            _1 = (long)(DBL_PTR(_a_51199)->dbl);
            DeRefDS(_a_51199);
            _a_51199 = _1;
        }

        /** 		if a > 0 then*/
        if (_a_51199 <= 0)
        goto L67; // [3722] 3968

        /** 			obj = SymTab[a][S_OBJ]*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26972 = (int)*(((s1_ptr)_2)->base + _a_51199);
        DeRef(_obj_51211);
        _2 = (int)SEQ_PTR(_26972);
        _obj_51211 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_obj_51211);
        _26972 = NOVALUE;

        /** 			if SymTab[a][S_MODE] = M_CONSTANT then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26974 = (int)*(((s1_ptr)_2)->base + _a_51199);
        _2 = (int)SEQ_PTR(_26974);
        _26975 = (int)*(((s1_ptr)_2)->base + 3);
        _26974 = NOVALUE;
        if (binary_op_a(NOTEQ, _26975, 2)){
            _26975 = NOVALUE;
            goto L68; // [3756] 3880
        }
        _26975 = NOVALUE;

        /** 				if integer(obj) then*/
        if (IS_ATOM_INT(_obj_51211))
        _26977 = 1;
        else if (IS_ATOM_DBL(_obj_51211))
        _26977 = IS_ATOM_INT(DoubleToInt(_obj_51211));
        else
        _26977 = 0;
        if (_26977 == 0)
        {
            _26977 = NOVALUE;
            goto L69; // [3765] 3819
        }
        else{
            _26977 = NOVALUE;
        }

        /** 					if obj = MININT then*/
        if (binary_op_a(NOTEQ, _obj_51211, -1073741824)){
            goto L6A; // [3772] 3793
        }

        /** 						Push(NewDoubleSym(-MININT))*/
        if ((unsigned long)-1073741824 == 0xC0000000)
        _26979 = (int)NewDouble((double)-0xC0000000);
        else
        _26979 = - -1073741824;
        _26980 = _52NewDoubleSym(_26979);
        _26979 = NOVALUE;
        _37Push(_26980);
        _26980 = NOVALUE;
        goto L6B; // [3790] 3806
L6A: 

        /** 						Push(NewIntSym(-obj))*/
        if (IS_ATOM_INT(_obj_51211)) {
            if ((unsigned long)_obj_51211 == 0xC0000000)
            _26981 = (int)NewDouble((double)-0xC0000000);
            else
            _26981 = - _obj_51211;
        }
        else {
            _26981 = unary_op(UMINUS, _obj_51211);
        }
        _26982 = _52NewIntSym(_26981);
        _26981 = NOVALUE;
        _37Push(_26982);
        _26982 = NOVALUE;
L6B: 

        /** 					last_pc = last_pc_backup*/
        _37last_pc_51157 = _last_pc_backup_51214;

        /** 					last_op = last_op_backup*/
        _37last_op_51156 = _last_op_backup_51215;
        goto LC; // [3816] 7412
L69: 

        /** 				elsif atom(obj) and obj != NOVALUE then*/
        _26983 = IS_ATOM(_obj_51211);
        if (_26983 == 0) {
            goto L6C; // [3824] 3863
        }
        if (IS_ATOM_INT(_obj_51211) && IS_ATOM_INT(_26NOVALUE_11836)) {
            _26985 = (_obj_51211 != _26NOVALUE_11836);
        }
        else {
            _26985 = binary_op(NOTEQ, _obj_51211, _26NOVALUE_11836);
        }
        if (_26985 == 0) {
            DeRef(_26985);
            _26985 = NOVALUE;
            goto L6C; // [3835] 3863
        }
        else {
            if (!IS_ATOM_INT(_26985) && DBL_PTR(_26985)->dbl == 0.0){
                DeRef(_26985);
                _26985 = NOVALUE;
                goto L6C; // [3835] 3863
            }
            DeRef(_26985);
            _26985 = NOVALUE;
        }
        DeRef(_26985);
        _26985 = NOVALUE;

        /** 					Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_51211)) {
            if ((unsigned long)_obj_51211 == 0xC0000000)
            _26986 = (int)NewDouble((double)-0xC0000000);
            else
            _26986 = - _obj_51211;
        }
        else {
            _26986 = unary_op(UMINUS, _obj_51211);
        }
        _26987 = _52NewDoubleSym(_26986);
        _26986 = NOVALUE;
        _37Push(_26987);
        _26987 = NOVALUE;

        /** 					last_pc = last_pc_backup*/
        _37last_pc_51157 = _last_pc_backup_51214;

        /** 					last_op = last_op_backup*/
        _37last_op_51156 = _last_op_backup_51215;
        goto LC; // [3860] 7412
L6C: 

        /** 					Push(a)*/
        _37Push(_a_51199);

        /** 					cont11ii(op, FALSE)*/
        _37cont11ii(_op_51197, _9FALSE_428);
        goto LC; // [3877] 7412
L68: 

        /** 			elsif TRANSLATE and SymTab[a][S_MODE] = M_TEMP and*/
        if (_26TRANSLATE_11619 == 0) {
            _26988 = 0;
            goto L6D; // [3884] 3910
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26989 = (int)*(((s1_ptr)_2)->base + _a_51199);
        _2 = (int)SEQ_PTR(_26989);
        _26990 = (int)*(((s1_ptr)_2)->base + 3);
        _26989 = NOVALUE;
        if (IS_ATOM_INT(_26990)) {
            _26991 = (_26990 == 3);
        }
        else {
            _26991 = binary_op(EQUALS, _26990, 3);
        }
        _26990 = NOVALUE;
        if (IS_ATOM_INT(_26991))
        _26988 = (_26991 != 0);
        else
        _26988 = DBL_PTR(_26991)->dbl != 0.0;
L6D: 
        if (_26988 == 0) {
            goto L6E; // [3910] 3951
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _26993 = (int)*(((s1_ptr)_2)->base + _a_51199);
        _2 = (int)SEQ_PTR(_26993);
        _26994 = (int)*(((s1_ptr)_2)->base + 36);
        _26993 = NOVALUE;
        if (IS_ATOM_INT(_26994)) {
            _26995 = (_26994 == 2);
        }
        else {
            _26995 = binary_op(EQUALS, _26994, 2);
        }
        _26994 = NOVALUE;
        if (_26995 == 0) {
            DeRef(_26995);
            _26995 = NOVALUE;
            goto L6E; // [3933] 3951
        }
        else {
            if (!IS_ATOM_INT(_26995) && DBL_PTR(_26995)->dbl == 0.0){
                DeRef(_26995);
                _26995 = NOVALUE;
                goto L6E; // [3933] 3951
            }
            DeRef(_26995);
            _26995 = NOVALUE;
        }
        DeRef(_26995);
        _26995 = NOVALUE;

        /** 				Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_51211)) {
            if ((unsigned long)_obj_51211 == 0xC0000000)
            _26996 = (int)NewDouble((double)-0xC0000000);
            else
            _26996 = - _obj_51211;
        }
        else {
            _26996 = unary_op(UMINUS, _obj_51211);
        }
        _26997 = _52NewDoubleSym(_26996);
        _26996 = NOVALUE;
        _37Push(_26997);
        _26997 = NOVALUE;
        goto LC; // [3948] 7412
L6E: 

        /** 				Push(a)*/
        _37Push(_a_51199);

        /** 				cont11ii(op, FALSE)*/
        _37cont11ii(_op_51197, _9FALSE_428);
        goto LC; // [3965] 7412
L67: 

        /** 			Push(a)*/
        _37Push(_a_51199);

        /** 			cont11ii(op, FALSE)*/
        _37cont11ii(_op_51197, _9FALSE_428);
        goto LC; // [3982] 7412

        /** 	case LENGTH, GETC, SQRT, SIN, COS, TAN, ARCTAN, LOG, GETS, GETENV then*/
        case 42:
        case 33:
        case 41:
        case 80:
        case 81:
        case 82:
        case 73:
        case 74:
        case 17:
        case 91:

        /** 		cont11ii(op, FALSE)*/
        _37cont11ii(_op_51197, _9FALSE_428);
        goto LC; // [4014] 7412

        /** 	case IS_AN_INTEGER, IS_AN_ATOM, IS_A_SEQUENCE, IS_AN_OBJECT then*/
        case 94:
        case 67:
        case 68:
        case 40:

        /** 		cont11ii(op, FALSE)*/
        _37cont11ii(_op_51197, _9FALSE_428);
        goto LC; // [4034] 7412

        /** 	case ROUTINE_ID then*/
        case 134:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		source = Pop()*/
        _source_51203 = _37Pop();
        if (!IS_ATOM_INT(_source_51203)) {
            _1 = (long)(DBL_PTR(_source_51203)->dbl);
            DeRefDS(_source_51203);
            _source_51203 = _1;
        }

        /** 		if TRANSLATE then*/
        if (_26TRANSLATE_11619 == 0)
        {
            goto L6F; // [4056] 4100
        }
        else{
        }

        /** 			emit_addr(num_routines-1)*/
        _26999 = _26num_routines_11991 - 1;
        if ((long)((unsigned long)_26999 +(unsigned long) HIGH_BITS) >= 0){
            _26999 = NewDouble((double)_26999);
        }
        _37emit_addr(_26999);
        _26999 = NOVALUE;

        /** 			last_routine_id = num_routines*/
        _37last_routine_id_50267 = _26num_routines_11991;

        /** 			last_max_params = max_params*/
        _37last_max_params_50269 = _37max_params_50268;

        /** 			MarkTargets(source, S_RI_TARGET)*/
        _31663 = _52MarkTargets(_source_51203, 53);
        DeRef(_31663);
        _31663 = NOVALUE;
        goto L70; // [4097] 4137
L6F: 

        /** 			emit_addr(CurrentSub)*/
        _37emit_addr(_26CurrentSub_11990);

        /** 			emit_addr(length(SymTab))*/
        if (IS_SEQUENCE(_27SymTab_10921)){
                _27000 = SEQ_PTR(_27SymTab_10921)->length;
        }
        else {
            _27000 = 1;
        }
        _37emit_addr(_27000);
        _27000 = NOVALUE;

        /** 			if BIND then*/
        if (_26BIND_11622 == 0)
        {
            goto L71; // [4121] 4136
        }
        else{
        }

        /** 				MarkTargets(source, S_NREFS)*/
        _31662 = _52MarkTargets(_source_51203, 12);
        DeRef(_31662);
        _31662 = NOVALUE;
L71: 
L70: 

        /** 		emit_addr(source)*/
        _37emit_addr(_source_51203);

        /** 		emit_addr(current_file_no)  -- necessary at top level*/
        _37emit_addr(_26current_file_no_11982);

        /** 		assignable = TRUE*/
        _37assignable_50280 = _9TRUE_430;

        /** 		c = NewTempSym()*/
        _c_51201 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		TempInteger(c) -- result will always be an integer*/
        _37TempInteger(_c_51201);

        /** 		Push(c)*/
        _37Push(_c_51201);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_51201);
        goto LC; // [4179] 7412

        /** 	case SC1_OR, SC1_AND then*/
        case 143:
        case 141:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		emit_addr(Pop())*/
        _27002 = _37Pop();
        _37emit_addr(_27002);
        _27002 = NOVALUE;

        /** 		c = NewTempSym()*/
        _c_51201 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		Push(c)*/
        _37Push(_c_51201);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_51201);

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [4225] 7412

        /** 	case SYSTEM, PUTS, PRINT, QPRINT, POSITION, MACHINE_PROC,*/
        case 99:
        case 44:
        case 19:
        case 36:
        case 60:
        case 112:
        case 132:
        case 128:
        case 138:
        case 168:
        case 178:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		b = Pop()*/
        _b_51200 = _37Pop();
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 		emit_addr(Pop())*/
        _27005 = _37Pop();
        _37emit_addr(_27005);
        _27005 = NOVALUE;

        /** 		emit_addr(b)*/
        _37emit_addr(_b_51200);

        /** 		if op = C_PROC then*/
        if (_op_51197 != 132)
        goto L72; // [4280] 4292

        /** 			emit_addr(CurrentSub)*/
        _37emit_addr(_26CurrentSub_11990);
L72: 

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [4299] 7412

        /** 	case EQUALS, LESS, GREATER, NOTEQ, LESSEQ, GREATEREQ,*/
        case 3:
        case 1:
        case 6:
        case 4:
        case 5:
        case 2:
        case 8:
        case 9:
        case 152:
        case 71:
        case 56:
        case 24:
        case 26:

        /** 		cont21ii(op, TRUE)  -- both integer args => integer result*/
        _37cont21ii(_op_51197, _9TRUE_430);
        goto LC; // [4337] 7412

        /** 	case PLUS then -- elsif op = PLUS then*/
        case 11:

        /** 		b = Pop()*/
        _b_51200 = _37Pop();
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 		a = Pop()*/
        _a_51199 = _37Pop();
        if (!IS_ATOM_INT(_a_51199)) {
            _1 = (long)(DBL_PTR(_a_51199)->dbl);
            DeRefDS(_a_51199);
            _a_51199 = _1;
        }

        /** 		if b < 1 or a < 1 then*/
        _27009 = (_b_51200 < 1);
        if (_27009 != 0) {
            goto L73; // [4363] 4376
        }
        _27011 = (_a_51199 < 1);
        if (_27011 == 0)
        {
            DeRef(_27011);
            _27011 = NOVALUE;
            goto L74; // [4372] 4397
        }
        else{
            DeRef(_27011);
            _27011 = NOVALUE;
        }
L73: 

        /** 			Push(a)*/
        _37Push(_a_51199);

        /** 			Push(b)*/
        _37Push(_b_51200);

        /** 			cont21ii(op, FALSE)*/
        _37cont21ii(_op_51197, _9FALSE_428);
        goto LC; // [4394] 7412
L74: 

        /** 		elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 1) then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27012 = (int)*(((s1_ptr)_2)->base + _b_51200);
        _2 = (int)SEQ_PTR(_27012);
        _27013 = (int)*(((s1_ptr)_2)->base + 3);
        _27012 = NOVALUE;
        if (IS_ATOM_INT(_27013)) {
            _27014 = (_27013 == 2);
        }
        else {
            _27014 = binary_op(EQUALS, _27013, 2);
        }
        _27013 = NOVALUE;
        if (IS_ATOM_INT(_27014)) {
            if (_27014 == 0) {
                goto L75; // [4417] 4478
            }
        }
        else {
            if (DBL_PTR(_27014)->dbl == 0.0) {
                goto L75; // [4417] 4478
            }
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27016 = (int)*(((s1_ptr)_2)->base + _b_51200);
        _2 = (int)SEQ_PTR(_27016);
        _27017 = (int)*(((s1_ptr)_2)->base + 1);
        _27016 = NOVALUE;
        if (_27017 == 1)
        _27018 = 1;
        else if (IS_ATOM_INT(_27017) && IS_ATOM_INT(1))
        _27018 = 0;
        else
        _27018 = (compare(_27017, 1) == 0);
        _27017 = NOVALUE;
        if (_27018 == 0)
        {
            _27018 = NOVALUE;
            goto L75; // [4438] 4478
        }
        else{
            _27018 = NOVALUE;
        }

        /** 			op = PLUS1*/
        _op_51197 = 93;

        /** 			emit_opcode(op)*/
        _37emit_opcode(93);

        /** 			emit_addr(a)*/
        _37emit_addr(_a_51199);

        /** 			emit_addr(0)*/
        _37emit_addr(0);

        /** 			cont21d(op, a, b, FALSE)*/
        _37cont21d(93, _a_51199, _b_51200, _9FALSE_428);
        goto LC; // [4475] 7412
L75: 

        /** 		elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 1) then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27019 = (int)*(((s1_ptr)_2)->base + _a_51199);
        _2 = (int)SEQ_PTR(_27019);
        _27020 = (int)*(((s1_ptr)_2)->base + 3);
        _27019 = NOVALUE;
        if (IS_ATOM_INT(_27020)) {
            _27021 = (_27020 == 2);
        }
        else {
            _27021 = binary_op(EQUALS, _27020, 2);
        }
        _27020 = NOVALUE;
        if (IS_ATOM_INT(_27021)) {
            if (_27021 == 0) {
                goto L76; // [4498] 4559
            }
        }
        else {
            if (DBL_PTR(_27021)->dbl == 0.0) {
                goto L76; // [4498] 4559
            }
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27023 = (int)*(((s1_ptr)_2)->base + _a_51199);
        _2 = (int)SEQ_PTR(_27023);
        _27024 = (int)*(((s1_ptr)_2)->base + 1);
        _27023 = NOVALUE;
        if (_27024 == 1)
        _27025 = 1;
        else if (IS_ATOM_INT(_27024) && IS_ATOM_INT(1))
        _27025 = 0;
        else
        _27025 = (compare(_27024, 1) == 0);
        _27024 = NOVALUE;
        if (_27025 == 0)
        {
            _27025 = NOVALUE;
            goto L76; // [4519] 4559
        }
        else{
            _27025 = NOVALUE;
        }

        /** 			op = PLUS1*/
        _op_51197 = 93;

        /** 			emit_opcode(op)*/
        _37emit_opcode(93);

        /** 			emit_addr(b)*/
        _37emit_addr(_b_51200);

        /** 			emit_addr(0)*/
        _37emit_addr(0);

        /** 			cont21d(op, a, b, FALSE)*/
        _37cont21d(93, _a_51199, _b_51200, _9FALSE_428);
        goto LC; // [4556] 7412
L76: 

        /** 			Push(a)*/
        _37Push(_a_51199);

        /** 			Push(b)*/
        _37Push(_b_51200);

        /** 			cont21ii(op, FALSE)*/
        _37cont21ii(_op_51197, _9FALSE_428);
        goto LC; // [4578] 7412

        /** 	case rw:MULTIPLY then*/
        case 13:

        /** 		b = Pop()*/
        _b_51200 = _37Pop();
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 		a = Pop()*/
        _a_51199 = _37Pop();
        if (!IS_ATOM_INT(_a_51199)) {
            _1 = (long)(DBL_PTR(_a_51199)->dbl);
            DeRefDS(_a_51199);
            _a_51199 = _1;
        }

        /** 		if a < 1 or b < 1 then*/
        _27028 = (_a_51199 < 1);
        if (_27028 != 0) {
            goto L77; // [4604] 4617
        }
        _27030 = (_b_51200 < 1);
        if (_27030 == 0)
        {
            DeRef(_27030);
            _27030 = NOVALUE;
            goto L78; // [4613] 4638
        }
        else{
            DeRef(_27030);
            _27030 = NOVALUE;
        }
L77: 

        /** 			Push(a)*/
        _37Push(_a_51199);

        /** 			Push(b)*/
        _37Push(_b_51200);

        /** 			cont21ii(op, FALSE)*/
        _37cont21ii(_op_51197, _9FALSE_428);
        goto LC; // [4635] 7412
L78: 

        /** 		elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27031 = (int)*(((s1_ptr)_2)->base + _b_51200);
        _2 = (int)SEQ_PTR(_27031);
        _27032 = (int)*(((s1_ptr)_2)->base + 3);
        _27031 = NOVALUE;
        if (IS_ATOM_INT(_27032)) {
            _27033 = (_27032 == 2);
        }
        else {
            _27033 = binary_op(EQUALS, _27032, 2);
        }
        _27032 = NOVALUE;
        if (IS_ATOM_INT(_27033)) {
            if (_27033 == 0) {
                goto L79; // [4658] 4719
            }
        }
        else {
            if (DBL_PTR(_27033)->dbl == 0.0) {
                goto L79; // [4658] 4719
            }
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27035 = (int)*(((s1_ptr)_2)->base + _b_51200);
        _2 = (int)SEQ_PTR(_27035);
        _27036 = (int)*(((s1_ptr)_2)->base + 1);
        _27035 = NOVALUE;
        if (_27036 == 2)
        _27037 = 1;
        else if (IS_ATOM_INT(_27036) && IS_ATOM_INT(2))
        _27037 = 0;
        else
        _27037 = (compare(_27036, 2) == 0);
        _27036 = NOVALUE;
        if (_27037 == 0)
        {
            _27037 = NOVALUE;
            goto L79; // [4679] 4719
        }
        else{
            _27037 = NOVALUE;
        }

        /** 			op = PLUS*/
        _op_51197 = 11;

        /** 			emit_opcode(op)*/
        _37emit_opcode(11);

        /** 			emit_addr(a)*/
        _37emit_addr(_a_51199);

        /** 			emit_addr(a)*/
        _37emit_addr(_a_51199);

        /** 			cont21d(op, a, b, FALSE)*/
        _37cont21d(11, _a_51199, _b_51200, _9FALSE_428);
        goto LC; // [4716] 7412
L79: 

        /** 		elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 2) then*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27038 = (int)*(((s1_ptr)_2)->base + _a_51199);
        _2 = (int)SEQ_PTR(_27038);
        _27039 = (int)*(((s1_ptr)_2)->base + 3);
        _27038 = NOVALUE;
        if (IS_ATOM_INT(_27039)) {
            _27040 = (_27039 == 2);
        }
        else {
            _27040 = binary_op(EQUALS, _27039, 2);
        }
        _27039 = NOVALUE;
        if (IS_ATOM_INT(_27040)) {
            if (_27040 == 0) {
                goto L7A; // [4739] 4800
            }
        }
        else {
            if (DBL_PTR(_27040)->dbl == 0.0) {
                goto L7A; // [4739] 4800
            }
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27042 = (int)*(((s1_ptr)_2)->base + _a_51199);
        _2 = (int)SEQ_PTR(_27042);
        _27043 = (int)*(((s1_ptr)_2)->base + 1);
        _27042 = NOVALUE;
        if (_27043 == 2)
        _27044 = 1;
        else if (IS_ATOM_INT(_27043) && IS_ATOM_INT(2))
        _27044 = 0;
        else
        _27044 = (compare(_27043, 2) == 0);
        _27043 = NOVALUE;
        if (_27044 == 0)
        {
            _27044 = NOVALUE;
            goto L7A; // [4760] 4800
        }
        else{
            _27044 = NOVALUE;
        }

        /** 			op = PLUS*/
        _op_51197 = 11;

        /** 			emit_opcode(op)*/
        _37emit_opcode(11);

        /** 			emit_addr(b)*/
        _37emit_addr(_b_51200);

        /** 			emit_addr(b)*/
        _37emit_addr(_b_51200);

        /** 			cont21d(op, a, b, FALSE)*/
        _37cont21d(11, _a_51199, _b_51200, _9FALSE_428);
        goto LC; // [4797] 7412
L7A: 

        /** 			Push(a)*/
        _37Push(_a_51199);

        /** 			Push(b)*/
        _37Push(_b_51200);

        /** 			cont21ii(op, FALSE)*/
        _37cont21ii(_op_51197, _9FALSE_428);
        goto LC; // [4819] 7412

        /** 	case rw:DIVIDE then*/
        case 14:

        /** 		b = Pop()*/
        _b_51200 = _37Pop();
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 		if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _27046 = (_b_51200 > 0);
        if (_27046 == 0) {
            _27047 = 0;
            goto L7B; // [4838] 4864
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27048 = (int)*(((s1_ptr)_2)->base + _b_51200);
        _2 = (int)SEQ_PTR(_27048);
        _27049 = (int)*(((s1_ptr)_2)->base + 3);
        _27048 = NOVALUE;
        if (IS_ATOM_INT(_27049)) {
            _27050 = (_27049 == 2);
        }
        else {
            _27050 = binary_op(EQUALS, _27049, 2);
        }
        _27049 = NOVALUE;
        if (IS_ATOM_INT(_27050))
        _27047 = (_27050 != 0);
        else
        _27047 = DBL_PTR(_27050)->dbl != 0.0;
L7B: 
        if (_27047 == 0) {
            goto L7C; // [4864] 4935
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27052 = (int)*(((s1_ptr)_2)->base + _b_51200);
        _2 = (int)SEQ_PTR(_27052);
        _27053 = (int)*(((s1_ptr)_2)->base + 1);
        _27052 = NOVALUE;
        if (_27053 == 2)
        _27054 = 1;
        else if (IS_ATOM_INT(_27053) && IS_ATOM_INT(2))
        _27054 = 0;
        else
        _27054 = (compare(_27053, 2) == 0);
        _27053 = NOVALUE;
        if (_27054 == 0)
        {
            _27054 = NOVALUE;
            goto L7C; // [4885] 4935
        }
        else{
            _27054 = NOVALUE;
        }

        /** 			op = DIV2*/
        _op_51197 = 98;

        /** 			emit_opcode(op)*/
        _37emit_opcode(98);

        /** 			emit_addr(Pop()) -- n.b. "a" hasn't been set*/
        _27055 = _37Pop();
        _37emit_addr(_27055);
        _27055 = NOVALUE;

        /** 			a = 0*/
        _a_51199 = 0;

        /** 			emit_addr(0)*/
        _37emit_addr(0);

        /** 			cont21d(op, a, b, FALSE)  -- could have fractional result*/
        _37cont21d(98, 0, _b_51200, _9FALSE_428);
        goto LC; // [4932] 7412
L7C: 

        /** 			Push(b)*/
        _37Push(_b_51200);

        /** 			cont21ii(op, FALSE)*/
        _37cont21ii(_op_51197, _9FALSE_428);
        goto LC; // [4949] 7412

        /** 	case FLOOR then*/
        case 83:

        /** 		if previous_op = rw:DIVIDE then*/
        if (_26previous_op_12081 != 14)
        goto L7D; // [4959] 5007

        /** 			op = FLOOR_DIV*/
        _op_51197 = 63;

        /** 			backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_26Code_12071)){
                _27057 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _27057 = 1;
        }
        _27058 = _27057 - 3;
        _27057 = NOVALUE;
        _37backpatch(_27058, 63);
        _27058 = NOVALUE;

        /** 			assignable = TRUE*/
        _37assignable_50280 = _9TRUE_430;

        /** 			last_op = op*/
        _37last_op_51156 = 63;

        /** 			last_pc = last_pc_backup*/
        _37last_pc_51157 = _last_pc_backup_51214;
        goto LC; // [5004] 7412
L7D: 

        /** 		elsif previous_op = DIV2 then*/
        if (_26previous_op_12081 != 98)
        goto L7E; // [5013] 5100

        /** 			op = FLOOR_DIV2*/
        _op_51197 = 66;

        /** 			backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_26Code_12071)){
                _27060 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _27060 = 1;
        }
        _27061 = _27060 - 3;
        _27060 = NOVALUE;
        _37backpatch(_27061, 66);
        _27061 = NOVALUE;

        /** 			assignable = TRUE*/
        _37assignable_50280 = _9TRUE_430;

        /** 			if IsInteger(Code[$-2]) then*/
        if (IS_SEQUENCE(_26Code_12071)){
                _27062 = SEQ_PTR(_26Code_12071)->length;
        }
        else {
            _27062 = 1;
        }
        _27063 = _27062 - 2;
        _27062 = NOVALUE;
        _2 = (int)SEQ_PTR(_26Code_12071);
        _27064 = (int)*(((s1_ptr)_2)->base + _27063);
        Ref(_27064);
        _27065 = _37IsInteger(_27064);
        _27064 = NOVALUE;
        if (_27065 == 0) {
            DeRef(_27065);
            _27065 = NOVALUE;
            goto L7F; // [5067] 5087
        }
        else {
            if (!IS_ATOM_INT(_27065) && DBL_PTR(_27065)->dbl == 0.0){
                DeRef(_27065);
                _27065 = NOVALUE;
                goto L7F; // [5067] 5087
            }
            DeRef(_27065);
            _27065 = NOVALUE;
        }
        DeRef(_27065);
        _27065 = NOVALUE;

        /** 				TempInteger(Top()) --mark temp as integer type*/

        /** 	return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_5195_52235);
        _2 = (int)SEQ_PTR(_37cg_stack_50277);
        _Top_inlined_Top_at_5195_52235 = (int)*(((s1_ptr)_2)->base + _37cgi_50278);
        Ref(_Top_inlined_Top_at_5195_52235);
        Ref(_Top_inlined_Top_at_5195_52235);
        _37TempInteger(_Top_inlined_Top_at_5195_52235);
L7F: 

        /** 			last_op = op*/
        _37last_op_51156 = _op_51197;

        /** 			last_pc = last_pc_backup*/
        _37last_pc_51157 = _last_pc_backup_51214;
        goto LC; // [5097] 7412
L7E: 

        /** 			cont11ii(op, TRUE)*/
        _37cont11ii(_op_51197, _9TRUE_430);
        goto LC; // [5109] 7412

        /** 	case MINUS, rw:APPEND, PREPEND, COMPARE, EQUAL,*/
        case 10:
        case 35:
        case 57:
        case 76:
        case 153:
        case 154:
        case 15:
        case 32:
        case 111:
        case 133:
        case 53:
        case 167:
        case 194:
        case 198:
        case 199:
        case 204:

        /** 		cont21ii(op, FALSE)*/
        _37cont21ii(_op_51197, _9FALSE_428);
        goto LC; // [5153] 7412

        /** 	case SC2_NULL then  -- correct the stack - we aren't emitting anything*/
        case 145:

        /** 		c = Pop()*/
        _c_51201 = _37Pop();
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		TempKeep(c)*/
        _37TempKeep(_c_51201);

        /** 		b = Pop()  -- remove SC1's temp*/
        _b_51200 = _37Pop();
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 		Push(c)*/
        _37Push(_c_51201);

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;

        /** 		last_op = last_op_backup*/
        _37last_op_51156 = _last_op_backup_51215;

        /** 		last_pc = last_pc_backup*/
        _37last_pc_51157 = _last_pc_backup_51214;
        goto LC; // [5200] 7412

        /** 	case SC2_AND, SC2_OR then*/
        case 142:
        case 144:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		emit_addr(Pop())*/
        _27068 = _37Pop();
        _37emit_addr(_27068);
        _27068 = NOVALUE;

        /** 		c = Pop()*/
        _c_51201 = _37Pop();
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		TempKeep(c)*/
        _37TempKeep(_c_51201);

        /** 		emit_addr(c) -- target*/
        _37emit_addr(_c_51201);

        /** 		TempInteger(c)*/
        _37TempInteger(_c_51201);

        /** 		Push(c)*/
        _37Push(_c_51201);

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [5255] 7412

        /** 	case MEM_COPY, MEM_SET, PRINTF then*/
        case 130:
        case 131:
        case 38:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		c = Pop()*/
        _c_51201 = _37Pop();
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		b = Pop()*/
        _b_51200 = _37Pop();
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 		emit_addr(Pop())*/
        _27072 = _37Pop();
        _37emit_addr(_27072);
        _27072 = NOVALUE;

        /** 		emit_addr(b)*/
        _37emit_addr(_b_51200);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_51201);

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [5309] 7412

        /** 	case RHS_SLICE, FIND, MATCH, FIND_FROM, MATCH_FROM, SPLICE, INSERT, REMOVE, OPEN then*/
        case 46:
        case 77:
        case 78:
        case 176:
        case 177:
        case 190:
        case 191:
        case 200:
        case 37:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		c = Pop()*/
        _c_51201 = _37Pop();
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		b = Pop()*/
        _b_51200 = _37Pop();
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 		emit_addr(Pop())*/
        _27075 = _37Pop();
        _37emit_addr(_27075);
        _27075 = NOVALUE;

        /** 		emit_addr(b)*/
        _37emit_addr(_b_51200);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_51201);

        /** 		c = NewTempSym()*/
        _c_51201 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		if op = FIND or op = FIND_FROM or op = OPEN then*/
        _27077 = (_op_51197 == 77);
        if (_27077 != 0) {
            _27078 = 1;
            goto L80; // [5384] 5398
        }
        _27079 = (_op_51197 == 176);
        _27078 = (_27079 != 0);
L80: 
        if (_27078 != 0) {
            goto L81; // [5398] 5413
        }
        _27081 = (_op_51197 == 37);
        if (_27081 == 0)
        {
            DeRef(_27081);
            _27081 = NOVALUE;
            goto L82; // [5409] 5421
        }
        else{
            DeRef(_27081);
            _27081 = NOVALUE;
        }
L81: 

        /** 			TempInteger( c )*/
        _37TempInteger(_c_51201);
        goto L83; // [5418] 5428
L82: 

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _37emit_temp(_c_51201, 1);
L83: 

        /** 		assignable = TRUE*/
        _37assignable_50280 = _9TRUE_430;

        /** 		Push(c)*/
        _37Push(_c_51201);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_51201);
        goto LC; // [5445] 7412

        /** 	case CONCAT_N then     -- concatenate 3 or more items*/
        case 157:

        /** 		n = op_info1  -- number of items to concatenate*/
        _n_51210 = _37op_info1_50262;

        /** 		emit_opcode(CONCAT_N)*/
        _37emit_opcode(157);

        /** 		emit(n)*/
        _37emit(_n_51210);

        /** 		for i = 1 to n do*/
        _27082 = _n_51210;
        {
            int _i_52303;
            _i_52303 = 1;
L84: 
            if (_i_52303 > _27082){
                goto L85; // [5475] 5503
            }

            /** 			symtab_index element = Pop()*/
            _element_52306 = _37Pop();
            if (!IS_ATOM_INT(_element_52306)) {
                _1 = (long)(DBL_PTR(_element_52306)->dbl);
                DeRefDS(_element_52306);
                _element_52306 = _1;
            }

            /** 			emit_addr( element )  -- reverse order*/
            _37emit_addr(_element_52306);

            /** 		end for*/
            _i_52303 = _i_52303 + 1;
            goto L84; // [5498] 5482
L85: 
            ;
        }

        /** 		c = NewTempSym()*/
        _c_51201 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		emit_addr(c)*/
        _37emit_addr(_c_51201);

        /** 		emit_temp( c, NEW_REFERENCE )*/
        _37emit_temp(_c_51201, 1);

        /** 		assignable = TRUE*/
        _37assignable_50280 = _9TRUE_430;

        /** 		Push(c)*/
        _37Push(_c_51201);
        goto LC; // [5534] 7412

        /** 	case FOR then*/
        case 21:

        /** 		c = Pop() -- increment*/
        _c_51201 = _37Pop();
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		TempKeep(c)*/
        _37TempKeep(_c_51201);

        /** 		ic = IsInteger(c)*/
        _ic_51209 = _37IsInteger(_c_51201);
        if (!IS_ATOM_INT(_ic_51209)) {
            _1 = (long)(DBL_PTR(_ic_51209)->dbl);
            DeRefDS(_ic_51209);
            _ic_51209 = _1;
        }

        /** 		if c < 1 or*/
        _27087 = (_c_51201 < 1);
        if (_27087 != 0) {
            goto L86; // [5566] 5645
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27089 = (int)*(((s1_ptr)_2)->base + _c_51201);
        _2 = (int)SEQ_PTR(_27089);
        _27090 = (int)*(((s1_ptr)_2)->base + 3);
        _27089 = NOVALUE;
        if (IS_ATOM_INT(_27090)) {
            _27091 = (_27090 == 1);
        }
        else {
            _27091 = binary_op(EQUALS, _27090, 1);
        }
        _27090 = NOVALUE;
        if (IS_ATOM_INT(_27091)) {
            if (_27091 == 0) {
                DeRef(_27092);
                _27092 = 0;
                goto L87; // [5588] 5614
            }
        }
        else {
            if (DBL_PTR(_27091)->dbl == 0.0) {
                DeRef(_27092);
                _27092 = 0;
                goto L87; // [5588] 5614
            }
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27093 = (int)*(((s1_ptr)_2)->base + _c_51201);
        _2 = (int)SEQ_PTR(_27093);
        _27094 = (int)*(((s1_ptr)_2)->base + 4);
        _27093 = NOVALUE;
        if (IS_ATOM_INT(_27094)) {
            _27095 = (_27094 != 2);
        }
        else {
            _27095 = binary_op(NOTEQ, _27094, 2);
        }
        _27094 = NOVALUE;
        DeRef(_27092);
        if (IS_ATOM_INT(_27095))
        _27092 = (_27095 != 0);
        else
        _27092 = DBL_PTR(_27095)->dbl != 0.0;
L87: 
        if (_27092 == 0) {
            DeRef(_27096);
            _27096 = 0;
            goto L88; // [5614] 5640
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27097 = (int)*(((s1_ptr)_2)->base + _c_51201);
        _2 = (int)SEQ_PTR(_27097);
        _27098 = (int)*(((s1_ptr)_2)->base + 4);
        _27097 = NOVALUE;
        if (IS_ATOM_INT(_27098)) {
            _27099 = (_27098 != 4);
        }
        else {
            _27099 = binary_op(NOTEQ, _27098, 4);
        }
        _27098 = NOVALUE;
        if (IS_ATOM_INT(_27099))
        _27096 = (_27099 != 0);
        else
        _27096 = DBL_PTR(_27099)->dbl != 0.0;
L88: 
        if (_27096 == 0)
        {
            _27096 = NOVALUE;
            goto L89; // [5641] 5682
        }
        else{
            _27096 = NOVALUE;
        }
L86: 

        /** 			emit_opcode(ASSIGN)*/
        _37emit_opcode(18);

        /** 			emit_addr(c)*/
        _37emit_addr(_c_51201);

        /** 			c = NewTempSym()*/
        _c_51201 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 			if ic then*/
        if (_ic_51209 == 0)
        {
            goto L8A; // [5667] 5676
        }
        else{
        }

        /** 				TempInteger( c )*/
        _37TempInteger(_c_51201);
L8A: 

        /** 			emit_addr(c)*/
        _37emit_addr(_c_51201);
L89: 

        /** 		b = Pop() -- limit*/
        _b_51200 = _37Pop();
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 		TempKeep(b)*/
        _37TempKeep(_b_51200);

        /** 		ib = IsInteger(b)*/
        _ib_51208 = _37IsInteger(_b_51200);
        if (!IS_ATOM_INT(_ib_51208)) {
            _1 = (long)(DBL_PTR(_ib_51208)->dbl);
            DeRefDS(_ib_51208);
            _ib_51208 = _1;
        }

        /** 		if b < 1 or*/
        _27103 = (_b_51200 < 1);
        if (_27103 != 0) {
            goto L8B; // [5708] 5787
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27105 = (int)*(((s1_ptr)_2)->base + _b_51200);
        _2 = (int)SEQ_PTR(_27105);
        _27106 = (int)*(((s1_ptr)_2)->base + 3);
        _27105 = NOVALUE;
        if (IS_ATOM_INT(_27106)) {
            _27107 = (_27106 == 1);
        }
        else {
            _27107 = binary_op(EQUALS, _27106, 1);
        }
        _27106 = NOVALUE;
        if (IS_ATOM_INT(_27107)) {
            if (_27107 == 0) {
                DeRef(_27108);
                _27108 = 0;
                goto L8C; // [5730] 5756
            }
        }
        else {
            if (DBL_PTR(_27107)->dbl == 0.0) {
                DeRef(_27108);
                _27108 = 0;
                goto L8C; // [5730] 5756
            }
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27109 = (int)*(((s1_ptr)_2)->base + _b_51200);
        _2 = (int)SEQ_PTR(_27109);
        _27110 = (int)*(((s1_ptr)_2)->base + 4);
        _27109 = NOVALUE;
        if (IS_ATOM_INT(_27110)) {
            _27111 = (_27110 != 2);
        }
        else {
            _27111 = binary_op(NOTEQ, _27110, 2);
        }
        _27110 = NOVALUE;
        DeRef(_27108);
        if (IS_ATOM_INT(_27111))
        _27108 = (_27111 != 0);
        else
        _27108 = DBL_PTR(_27111)->dbl != 0.0;
L8C: 
        if (_27108 == 0) {
            DeRef(_27112);
            _27112 = 0;
            goto L8D; // [5756] 5782
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27113 = (int)*(((s1_ptr)_2)->base + _b_51200);
        _2 = (int)SEQ_PTR(_27113);
        _27114 = (int)*(((s1_ptr)_2)->base + 4);
        _27113 = NOVALUE;
        if (IS_ATOM_INT(_27114)) {
            _27115 = (_27114 != 4);
        }
        else {
            _27115 = binary_op(NOTEQ, _27114, 4);
        }
        _27114 = NOVALUE;
        if (IS_ATOM_INT(_27115))
        _27112 = (_27115 != 0);
        else
        _27112 = DBL_PTR(_27115)->dbl != 0.0;
L8D: 
        if (_27112 == 0)
        {
            _27112 = NOVALUE;
            goto L8E; // [5783] 5824
        }
        else{
            _27112 = NOVALUE;
        }
L8B: 

        /** 			emit_opcode(ASSIGN)*/
        _37emit_opcode(18);

        /** 			emit_addr(b)*/
        _37emit_addr(_b_51200);

        /** 			b = NewTempSym()*/
        _b_51200 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 			if ib then*/
        if (_ib_51208 == 0)
        {
            goto L8F; // [5809] 5818
        }
        else{
        }

        /** 				TempInteger( b )*/
        _37TempInteger(_b_51200);
L8F: 

        /** 			emit_addr(b)*/
        _37emit_addr(_b_51200);
L8E: 

        /** 		a = Pop() -- initial value*/
        _a_51199 = _37Pop();
        if (!IS_ATOM_INT(_a_51199)) {
            _1 = (long)(DBL_PTR(_a_51199)->dbl);
            DeRefDS(_a_51199);
            _a_51199 = _1;
        }

        /** 		if IsInteger(a) and ib and ic then*/
        _27118 = _37IsInteger(_a_51199);
        if (IS_ATOM_INT(_27118)) {
            if (_27118 == 0) {
                DeRef(_27119);
                _27119 = 0;
                goto L90; // [5837] 5845
            }
        }
        else {
            if (DBL_PTR(_27118)->dbl == 0.0) {
                DeRef(_27119);
                _27119 = 0;
                goto L90; // [5837] 5845
            }
        }
        DeRef(_27119);
        _27119 = (_ib_51208 != 0);
L90: 
        if (_27119 == 0) {
            goto L91; // [5845] 5884
        }
        if (_ic_51209 == 0)
        {
            goto L91; // [5850] 5884
        }
        else{
        }

        /** 			SymTab[op_info1][S_VTYPE] = integer_type*/
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _27SymTab_10921 = MAKE_SEQ(_2);
        }
        _3 = (int)(_37op_info1_50262 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 15);
        _1 = *(int *)_2;
        *(int *)_2 = _52integer_type_46136;
        DeRef(_1);
        _27121 = NOVALUE;

        /** 			op = FOR_I*/
        _op_51197 = 125;
        goto L92; // [5881] 5894
L91: 

        /** 			op = FOR*/
        _op_51197 = 21;
L92: 

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_51201);

        /** 		emit_addr(b)*/
        _37emit_addr(_b_51200);

        /** 		emit_addr(a)*/
        _37emit_addr(_a_51199);

        /** 		emit_addr(CurrentSub) -- in case recursion check is needed*/
        _37emit_addr(_26CurrentSub_11990);

        /** 		Push(b)*/
        _37Push(_b_51200);

        /** 		Push(c)*/
        _37Push(_c_51201);

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [5938] 7412

        /** 	case ENDFOR_GENERAL, ENDFOR_INT_UP1 then  -- all ENDFORs*/
        case 39:
        case 54:

        /** 		emit_opcode(op) -- will be patched at runtime*/
        _37emit_opcode(_op_51197);

        /** 		a = Pop()*/
        _a_51199 = _37Pop();
        if (!IS_ATOM_INT(_a_51199)) {
            _1 = (long)(DBL_PTR(_a_51199)->dbl);
            DeRefDS(_a_51199);
            _a_51199 = _1;
        }

        /** 		emit_addr(op_info2) -- address of top of loop*/
        _37emit_addr(_37op_info2_50263);

        /** 		emit_addr(Pop())    -- limit*/
        _27124 = _37Pop();
        _37emit_addr(_27124);
        _27124 = NOVALUE;

        /** 		emit_addr(op_info1) -- loop var*/
        _37emit_addr(_37op_info1_50262);

        /** 		emit_addr(a)        -- increment - not always used -*/
        _37emit_addr(_a_51199);

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [5992] 7412

        /** 	case ASSIGN_OP_SUBS, PASSIGN_OP_SUBS then*/
        case 149:
        case 164:

        /** 		b = Pop()      -- rhs value, keep on stack*/
        _b_51200 = _37Pop();
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 		TempKeep(b)*/
        _37TempKeep(_b_51200);

        /** 		a = Pop()      -- subscript, keep on stack*/
        _a_51199 = _37Pop();
        if (!IS_ATOM_INT(_a_51199)) {
            _1 = (long)(DBL_PTR(_a_51199)->dbl);
            DeRefDS(_a_51199);
            _a_51199 = _1;
        }

        /** 		TempKeep(a)*/
        _37TempKeep(_a_51199);

        /** 		c = Pop()      -- lhs sequence, keep on stack*/
        _c_51201 = _37Pop();
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		TempKeep(c)*/
        _37TempKeep(_c_51201);

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_51201);

        /** 		emit_addr(a)*/
        _37emit_addr(_a_51199);

        /** 		d = NewTempSym()*/
        _d_51202 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_d_51202)) {
            _1 = (long)(DBL_PTR(_d_51202)->dbl);
            DeRefDS(_d_51202);
            _d_51202 = _1;
        }

        /** 		emit_addr(d)   -- place to store result*/
        _37emit_addr(_d_51202);

        /** 		emit_temp( d, NEW_REFERENCE )*/
        _37emit_temp(_d_51202, 1);

        /** 		Push(c)*/
        _37Push(_c_51201);

        /** 		Push(a)*/
        _37Push(_a_51199);

        /** 		Push(d)*/
        _37Push(_d_51202);

        /** 		Push(b)*/
        _37Push(_b_51200);

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [6097] 7412

        /** 	case ASSIGN_SLICE, PASSIGN_SLICE then*/
        case 45:
        case 163:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		b = Pop() -- rhs value*/
        _b_51200 = _37Pop();
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 		a = Pop() -- 2nd subs*/
        _a_51199 = _37Pop();
        if (!IS_ATOM_INT(_a_51199)) {
            _1 = (long)(DBL_PTR(_a_51199)->dbl);
            DeRefDS(_a_51199);
            _a_51199 = _1;
        }

        /** 		c = Pop() -- 1st subs*/
        _c_51201 = _37Pop();
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		emit_addr(Pop()) -- sequence*/
        _27132 = _37Pop();
        _37emit_addr(_27132);
        _27132 = NOVALUE;

        /** 		emit_addr(c)*/
        _37emit_addr(_c_51201);

        /** 		emit_addr(a)*/
        _37emit_addr(_a_51199);

        /** 		emit_addr(b)*/
        _37emit_addr(_b_51200);

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [6161] 7412

        /** 	case REPLACE then*/
        case 201:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		b = Pop()  -- source*/
        _b_51200 = _37Pop();
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 		a = Pop()  -- replacement*/
        _a_51199 = _37Pop();
        if (!IS_ATOM_INT(_a_51199)) {
            _1 = (long)(DBL_PTR(_a_51199)->dbl);
            DeRefDS(_a_51199);
            _a_51199 = _1;
        }

        /** 		c = Pop()  -- start of replaced slice*/
        _c_51201 = _37Pop();
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		d = Pop()  -- end of replaced slice*/
        _d_51202 = _37Pop();
        if (!IS_ATOM_INT(_d_51202)) {
            _1 = (long)(DBL_PTR(_d_51202)->dbl);
            DeRefDS(_d_51202);
            _d_51202 = _1;
        }

        /** 		emit_addr(d)*/
        _37emit_addr(_d_51202);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_51201);

        /** 		emit_addr(a)*/
        _37emit_addr(_a_51199);

        /** 		emit_addr(b)*/
        _37emit_addr(_b_51200);

        /** 		c = NewTempSym()*/
        _c_51201 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		Push(c)*/
        _37Push(_c_51201);

        /** 		emit_addr(c)     -- place to store result*/
        _37emit_addr(_c_51201);

        /** 		emit_temp( c, NEW_REFERENCE )*/
        _37emit_temp(_c_51201, 1);

        /** 		assignable = TRUE*/
        _37assignable_50280 = _9TRUE_430;
        goto LC; // [6251] 7412

        /** 	case ASSIGN_OP_SLICE, PASSIGN_OP_SLICE then*/
        case 150:
        case 165:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		b = Pop()        -- rhs value not used*/
        _b_51200 = _37Pop();
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 		TempKeep(b)*/
        _37TempKeep(_b_51200);

        /** 		a = Pop()        -- 2nd subs*/
        _a_51199 = _37Pop();
        if (!IS_ATOM_INT(_a_51199)) {
            _1 = (long)(DBL_PTR(_a_51199)->dbl);
            DeRefDS(_a_51199);
            _a_51199 = _1;
        }

        /** 		TempKeep(a)*/
        _37TempKeep(_a_51199);

        /** 		c = Pop()        -- 1st subs*/
        _c_51201 = _37Pop();
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		TempKeep(c)*/
        _37TempKeep(_c_51201);

        /** 		d = Pop()*/
        _d_51202 = _37Pop();
        if (!IS_ATOM_INT(_d_51202)) {
            _1 = (long)(DBL_PTR(_d_51202)->dbl);
            DeRefDS(_d_51202);
            _d_51202 = _1;
        }

        /** 		TempKeep(d)      -- sequence*/
        _37TempKeep(_d_51202);

        /** 		emit_addr(d)*/
        _37emit_addr(_d_51202);

        /** 		Push(d)*/
        _37Push(_d_51202);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_51201);

        /** 		Push(c)*/
        _37Push(_c_51201);

        /** 		emit_addr(a)*/
        _37emit_addr(_a_51199);

        /** 		Push(a)*/
        _37Push(_a_51199);

        /** 		c = NewTempSym()*/
        _c_51201 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		Push(c)*/
        _37Push(_c_51201);

        /** 		emit_addr(c)     -- place to store result*/
        _37emit_addr(_c_51201);

        /** 		emit_temp( c, NEW_REFERENCE )*/
        _37emit_temp(_c_51201, 1);

        /** 		Push(b)*/
        _37Push(_b_51200);

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [6378] 7412

        /** 	case CALL_PROC then*/
        case 136:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		b = Pop()*/
        _b_51200 = _37Pop();
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 		emit_addr(Pop())*/
        _27144 = _37Pop();
        _37emit_addr(_27144);
        _27144 = NOVALUE;

        /** 		emit_addr(b)*/
        _37emit_addr(_b_51200);

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [6416] 7412

        /** 	case CALL_FUNC then*/
        case 137:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		b = Pop()*/
        _b_51200 = _37Pop();
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 		emit_addr(Pop())*/
        _27146 = _37Pop();
        _37emit_addr(_27146);
        _27146 = NOVALUE;

        /** 		emit_addr(b)*/
        _37emit_addr(_b_51200);

        /** 		assignable = TRUE*/
        _37assignable_50280 = _9TRUE_430;

        /** 		c = NewTempSym()*/
        _c_51201 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		Push(c)*/
        _37Push(_c_51201);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_51201);

        /** 		emit_temp( c, NEW_REFERENCE )*/
        _37emit_temp(_c_51201, 1);
        goto LC; // [6478] 7412

        /** 	case EXIT_BLOCK then*/
        case 206:

        /** 		emit_opcode( op )*/
        _37emit_opcode(_op_51197);

        /** 		emit_addr( Pop() )*/
        _27148 = _37Pop();
        _37emit_addr(_27148);
        _27148 = NOVALUE;

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [6504] 7412

        /** 	case RETURNP then*/
        case 29:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		emit_addr(CurrentSub)*/
        _37emit_addr(_26CurrentSub_11990);

        /** 		emit_addr(top_block())*/
        _27149 = _65top_block(0);
        _37emit_addr(_27149);
        _27149 = NOVALUE;

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [6538] 7412

        /** 	case RETURNF then*/
        case 28:

        /** 		clear_temp( Top() )*/

        /** 	return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_6750_52453);
        _2 = (int)SEQ_PTR(_37cg_stack_50277);
        _Top_inlined_Top_at_6750_52453 = (int)*(((s1_ptr)_2)->base + _37cgi_50278);
        Ref(_Top_inlined_Top_at_6750_52453);
        Ref(_Top_inlined_Top_at_6750_52453);
        _37clear_temp(_Top_inlined_Top_at_6750_52453);

        /** 		flush_temps()*/
        RefDS(_22037);
        _37flush_temps(_22037);

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		emit_addr(CurrentSub)*/
        _37emit_addr(_26CurrentSub_11990);

        /** 		emit_addr(Least_block())*/
        _27150 = _65Least_block();
        _37emit_addr(_27150);
        _27150 = NOVALUE;

        /** 		emit_addr(Pop())*/
        _27151 = _37Pop();
        _37emit_addr(_27151);
        _27151 = NOVALUE;

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [6600] 7412

        /** 	case RETURNT then*/
        case 34:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [6618] 7412

        /** 	case DATE, TIME, SPACE_USED, GET_KEY, TASK_LIST,*/
        case 69:
        case 70:
        case 75:
        case 79:
        case 172:
        case 100:
        case 183:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		c = NewTempSym()*/
        _c_51201 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		assignable = TRUE*/
        _37assignable_50280 = _9TRUE_430;

        /** 		if op = GET_KEY then  -- it's in op_result as integer*/
        if (_op_51197 != 79)
        goto L93; // [6660] 6672

        /** 			TempInteger(c)*/
        _37TempInteger(_c_51201);
        goto L94; // [6669] 6679
L93: 

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _37emit_temp(_c_51201, 1);
L94: 

        /** 		Push(c)*/
        _37Push(_c_51201);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_51201);
        goto LC; // [6689] 7412

        /** 	case CLOSE, ABORT, CALL, DELETE_OBJECT then*/
        case 86:
        case 126:
        case 129:
        case 205:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		emit_addr(Pop())*/
        _27154 = _37Pop();
        _37emit_addr(_27154);
        _27154 = NOVALUE;

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [6721] 7412

        /** 	case POWER then*/
        case 72:

        /** 		b = Pop()*/
        _b_51200 = _37Pop();
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 		a = Pop()*/
        _a_51199 = _37Pop();
        if (!IS_ATOM_INT(_a_51199)) {
            _1 = (long)(DBL_PTR(_a_51199)->dbl);
            DeRefDS(_a_51199);
            _a_51199 = _1;
        }

        /** 		if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _27157 = (_b_51200 > 0);
        if (_27157 == 0) {
            _27158 = 0;
            goto L95; // [6747] 6773
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27159 = (int)*(((s1_ptr)_2)->base + _b_51200);
        _2 = (int)SEQ_PTR(_27159);
        _27160 = (int)*(((s1_ptr)_2)->base + 3);
        _27159 = NOVALUE;
        if (IS_ATOM_INT(_27160)) {
            _27161 = (_27160 == 2);
        }
        else {
            _27161 = binary_op(EQUALS, _27160, 2);
        }
        _27160 = NOVALUE;
        if (IS_ATOM_INT(_27161))
        _27158 = (_27161 != 0);
        else
        _27158 = DBL_PTR(_27161)->dbl != 0.0;
L95: 
        if (_27158 == 0) {
            goto L96; // [6773] 6830
        }
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        _27163 = (int)*(((s1_ptr)_2)->base + _b_51200);
        _2 = (int)SEQ_PTR(_27163);
        _27164 = (int)*(((s1_ptr)_2)->base + 1);
        _27163 = NOVALUE;
        if (_27164 == 2)
        _27165 = 1;
        else if (IS_ATOM_INT(_27164) && IS_ATOM_INT(2))
        _27165 = 0;
        else
        _27165 = (compare(_27164, 2) == 0);
        _27164 = NOVALUE;
        if (_27165 == 0)
        {
            _27165 = NOVALUE;
            goto L96; // [6794] 6830
        }
        else{
            _27165 = NOVALUE;
        }

        /** 			op = rw:MULTIPLY*/
        _op_51197 = 13;

        /** 			emit_opcode(op)*/
        _37emit_opcode(13);

        /** 			emit_addr(a)*/
        _37emit_addr(_a_51199);

        /** 			emit_addr(a)*/
        _37emit_addr(_a_51199);

        /** 			cont21d(op, a, b, FALSE)*/
        _37cont21d(13, _a_51199, _b_51200, _9FALSE_428);
        goto LC; // [6827] 7412
L96: 

        /** 			Push(a)*/
        _37Push(_a_51199);

        /** 			Push(b)*/
        _37Push(_b_51200);

        /** 			cont21ii(op, FALSE)*/
        _37cont21ii(_op_51197, _9FALSE_428);
        goto LC; // [6849] 7412

        /** 	case TYPE_CHECK then*/
        case 65:

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		c = Pop()*/
        _c_51201 = _37Pop();
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [6874] 7412

        /** 	case DOLLAR then*/
        case -22:

        /** 		if current_sequence[$] < 0 or SymTab[current_sequence[$]][S_SCOPE] = SC_UNDEFINED then*/
        if (IS_SEQUENCE(_37current_sequence_50270)){
                _27167 = SEQ_PTR(_37current_sequence_50270)->length;
        }
        else {
            _27167 = 1;
        }
        _2 = (int)SEQ_PTR(_37current_sequence_50270);
        _27168 = (int)*(((s1_ptr)_2)->base + _27167);
        if (IS_ATOM_INT(_27168)) {
            _27169 = (_27168 < 0);
        }
        else {
            _27169 = binary_op(LESS, _27168, 0);
        }
        _27168 = NOVALUE;
        if (IS_ATOM_INT(_27169)) {
            if (_27169 != 0) {
                goto L97; // [6895] 6931
            }
        }
        else {
            if (DBL_PTR(_27169)->dbl != 0.0) {
                goto L97; // [6895] 6931
            }
        }
        if (IS_SEQUENCE(_37current_sequence_50270)){
                _27171 = SEQ_PTR(_37current_sequence_50270)->length;
        }
        else {
            _27171 = 1;
        }
        _2 = (int)SEQ_PTR(_37current_sequence_50270);
        _27172 = (int)*(((s1_ptr)_2)->base + _27171);
        _2 = (int)SEQ_PTR(_27SymTab_10921);
        if (!IS_ATOM_INT(_27172)){
            _27173 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27172)->dbl));
        }
        else{
            _27173 = (int)*(((s1_ptr)_2)->base + _27172);
        }
        _2 = (int)SEQ_PTR(_27173);
        _27174 = (int)*(((s1_ptr)_2)->base + 4);
        _27173 = NOVALUE;
        if (IS_ATOM_INT(_27174)) {
            _27175 = (_27174 == 9);
        }
        else {
            _27175 = binary_op(EQUALS, _27174, 9);
        }
        _27174 = NOVALUE;
        if (_27175 == 0) {
            DeRef(_27175);
            _27175 = NOVALUE;
            goto L98; // [6927] 7001
        }
        else {
            if (!IS_ATOM_INT(_27175) && DBL_PTR(_27175)->dbl == 0.0){
                DeRef(_27175);
                _27175 = NOVALUE;
                goto L98; // [6927] 7001
            }
            DeRef(_27175);
            _27175 = NOVALUE;
        }
        DeRef(_27175);
        _27175 = NOVALUE;
L97: 

        /** 			if lhs_ptr and length(current_sequence) = 1 then*/
        if (_37lhs_ptr_50272 == 0) {
            goto L99; // [6935] 6964
        }
        if (IS_SEQUENCE(_37current_sequence_50270)){
                _27177 = SEQ_PTR(_37current_sequence_50270)->length;
        }
        else {
            _27177 = 1;
        }
        _27178 = (_27177 == 1);
        _27177 = NOVALUE;
        if (_27178 == 0)
        {
            DeRef(_27178);
            _27178 = NOVALUE;
            goto L99; // [6949] 6964
        }
        else{
            DeRef(_27178);
            _27178 = NOVALUE;
        }

        /** 				c = PLENGTH*/
        _c_51201 = 160;
        goto L9A; // [6961] 6974
L99: 

        /** 				c = LENGTH*/
        _c_51201 = 42;
L9A: 

        /** 			c = - new_forward_reference( VARIABLE, current_sequence[$], c )*/
        if (IS_SEQUENCE(_37current_sequence_50270)){
                _27179 = SEQ_PTR(_37current_sequence_50270)->length;
        }
        else {
            _27179 = 1;
        }
        _2 = (int)SEQ_PTR(_37current_sequence_50270);
        _27180 = (int)*(((s1_ptr)_2)->base + _27179);
        Ref(_27180);
        _27181 = _29new_forward_reference(-100, _27180, _c_51201);
        _27180 = NOVALUE;
        if (IS_ATOM_INT(_27181)) {
            if ((unsigned long)_27181 == 0xC0000000)
            _c_51201 = (int)NewDouble((double)-0xC0000000);
            else
            _c_51201 = - _27181;
        }
        else {
            _c_51201 = unary_op(UMINUS, _27181);
        }
        DeRef(_27181);
        _27181 = NOVALUE;
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }
        goto L9B; // [6998] 7015
L98: 

        /** 			c = current_sequence[$]*/
        if (IS_SEQUENCE(_37current_sequence_50270)){
                _27183 = SEQ_PTR(_37current_sequence_50270)->length;
        }
        else {
            _27183 = 1;
        }
        _2 = (int)SEQ_PTR(_37current_sequence_50270);
        _c_51201 = (int)*(((s1_ptr)_2)->base + _27183);
        if (!IS_ATOM_INT(_c_51201)){
            _c_51201 = (long)DBL_PTR(_c_51201)->dbl;
        }
L9B: 

        /** 		if lhs_ptr and length(current_sequence) = 1 then*/
        if (_37lhs_ptr_50272 == 0) {
            goto L9C; // [7019] 7046
        }
        if (IS_SEQUENCE(_37current_sequence_50270)){
                _27186 = SEQ_PTR(_37current_sequence_50270)->length;
        }
        else {
            _27186 = 1;
        }
        _27187 = (_27186 == 1);
        _27186 = NOVALUE;
        if (_27187 == 0)
        {
            DeRef(_27187);
            _27187 = NOVALUE;
            goto L9C; // [7033] 7046
        }
        else{
            DeRef(_27187);
            _27187 = NOVALUE;
        }

        /** 			emit_opcode(PLENGTH)*/
        _37emit_opcode(160);
        goto L9D; // [7043] 7054
L9C: 

        /** 			emit_opcode(LENGTH)*/
        _37emit_opcode(42);
L9D: 

        /** 		emit_addr( c )*/
        _37emit_addr(_c_51201);

        /** 		c = NewTempSym()*/
        _c_51201 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		TempInteger(c)*/
        _37TempInteger(_c_51201);

        /** 		Push(c)*/
        _37Push(_c_51201);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_51201);

        /** 		assignable = FALSE -- it wouldn't be assigned anyway*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [7089] 7412

        /** 	case TASK_SELF then*/
        case 170:

        /** 		c = NewTempSym()*/
        _c_51201 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		Push(c)*/
        _37Push(_c_51201);

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		emit_addr(c)*/
        _37emit_addr(_c_51201);

        /** 		assignable = TRUE*/
        _37assignable_50280 = _9TRUE_430;
        goto LC; // [7125] 7412

        /** 	case SWITCH then*/
        case 185:

        /** 		emit_opcode( op )*/
        _37emit_opcode(_op_51197);

        /** 		c = Pop()*/
        _c_51201 = _37Pop();
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 		b = Pop()*/
        _b_51200 = _37Pop();
        if (!IS_ATOM_INT(_b_51200)) {
            _1 = (long)(DBL_PTR(_b_51200)->dbl);
            DeRefDS(_b_51200);
            _b_51200 = _1;
        }

        /** 		a = Pop()*/
        _a_51199 = _37Pop();
        if (!IS_ATOM_INT(_a_51199)) {
            _1 = (long)(DBL_PTR(_a_51199)->dbl);
            DeRefDS(_a_51199);
            _a_51199 = _1;
        }

        /** 		emit_addr( a ) -- Switch Expr*/
        _37emit_addr(_a_51199);

        /** 		emit_addr( b ) -- Case values*/
        _37emit_addr(_b_51200);

        /** 		emit_addr( c ) -- Jump table*/
        _37emit_addr(_c_51201);

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [7179] 7412

        /** 	case CASE then*/
        case 186:

        /** 		emit_opcode( op )*/
        _37emit_opcode(_op_51197);

        /** 		emit( cg_stack[cgi] )  -- the case index*/
        _2 = (int)SEQ_PTR(_37cg_stack_50277);
        _27193 = (int)*(((s1_ptr)_2)->base + _37cgi_50278);
        Ref(_27193);
        _37emit(_27193);
        _27193 = NOVALUE;

        /** 		cgi -= 1*/
        _37cgi_50278 = _37cgi_50278 - 1;
        goto LC; // [7211] 7412

        /** 	case PLATFORM then*/
        case 155:

        /** 		if BIND and shroud_only then*/
        if (_26BIND_11622 == 0) {
            goto L9E; // [7221] 7269
        }
        if (_26shroud_only_11980 == 0)
        {
            goto L9E; // [7228] 7269
        }
        else{
        }

        /** 			c = NewTempSym()*/
        _c_51201 = _52NewTempSym(0);
        if (!IS_ATOM_INT(_c_51201)) {
            _1 = (long)(DBL_PTR(_c_51201)->dbl);
            DeRefDS(_c_51201);
            _c_51201 = _1;
        }

        /** 			TempInteger(c)*/
        _37TempInteger(_c_51201);

        /** 			Push(c)*/
        _37Push(_c_51201);

        /** 			emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 			emit_addr(c)*/
        _37emit_addr(_c_51201);

        /** 			assignable = TRUE*/
        _37assignable_50280 = _9TRUE_430;
        goto LC; // [7266] 7412
L9E: 

        /** 			n = host_platform()*/
        _n_51210 = _36host_platform();
        if (!IS_ATOM_INT(_n_51210)) {
            _1 = (long)(DBL_PTR(_n_51210)->dbl);
            DeRefDS(_n_51210);
            _n_51210 = _1;
        }

        /** 			Push(NewIntSym(n))*/
        _27198 = _52NewIntSym(_n_51210);
        _37Push(_27198);
        _27198 = NOVALUE;

        /** 			assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [7293] 7412

        /** 	case PROFILE, TASK_SUSPEND then*/
        case 151:
        case 171:

        /** 		a = Pop()*/
        _a_51199 = _37Pop();
        if (!IS_ATOM_INT(_a_51199)) {
            _1 = (long)(DBL_PTR(_a_51199)->dbl);
            DeRefDS(_a_51199);
            _a_51199 = _1;
        }

        /** 		emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 		emit_addr(a)*/
        _37emit_addr(_a_51199);

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [7325] 7412

        /** 	case TRACE then*/
        case 64:

        /** 		a = Pop()*/
        _a_51199 = _37Pop();
        if (!IS_ATOM_INT(_a_51199)) {
            _1 = (long)(DBL_PTR(_a_51199)->dbl);
            DeRefDS(_a_51199);
            _a_51199 = _1;
        }

        /** 		if OpTrace then*/
        if (_26OpTrace_12052 == 0)
        {
            goto L9F; // [7342] 7388
        }
        else{
        }

        /** 			emit_opcode(op)*/
        _37emit_opcode(_op_51197);

        /** 			emit_addr(a)*/
        _37emit_addr(_a_51199);

        /** 			if TRANSLATE then*/
        if (_26TRANSLATE_11619 == 0)
        {
            goto LA0; // [7359] 7387
        }
        else{
        }

        /** 				if not trace_called then*/
        if (_37trace_called_50265 != 0)
        goto LA1; // [7366] 7377

        /** 					Warning(217,0)*/
        RefDS(_22037);
        _43Warning(217, 0, _22037);
LA1: 

        /** 				trace_called = TRUE*/
        _37trace_called_50265 = _9TRUE_430;
LA0: 
L9F: 

        /** 		assignable = FALSE*/
        _37assignable_50280 = _9FALSE_428;
        goto LC; // [7395] 7412

        /** 	case else*/
        default:

        /** 		InternalErr(259, {op})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _op_51197;
        _27202 = MAKE_SEQ(_1);
        _43InternalErr(259, _27202);
        _27202 = NOVALUE;
    ;}LC: 

    /** 	previous_op = op*/
    _26previous_op_12081 = _op_51197;

    /** 	inlined = 0*/
    _37inlined_51175 = 0;

    /** end procedure*/
    DeRef(_obj_51211);
    DeRef(_elements_51212);
    DeRef(_element_vals_51213);
    DeRef(_26707);
    _26707 = NOVALUE;
    DeRef(_26870);
    _26870 = NOVALUE;
    DeRef(_26823);
    _26823 = NOVALUE;
    DeRef(_27077);
    _27077 = NOVALUE;
    DeRef(_27107);
    _27107 = NOVALUE;
    DeRef(_27118);
    _27118 = NOVALUE;
    DeRef(_26634);
    _26634 = NOVALUE;
    DeRef(_26991);
    _26991 = NOVALUE;
    DeRef(_27099);
    _27099 = NOVALUE;
    _27172 = NOVALUE;
    DeRef(_26889);
    _26889 = NOVALUE;
    DeRef(_26939);
    _26939 = NOVALUE;
    _26726 = NOVALUE;
    DeRef(_26842);
    _26842 = NOVALUE;
    DeRef(_26918);
    _26918 = NOVALUE;
    DeRef(_27040);
    _27040 = NOVALUE;
    DeRef(_26673);
    _26673 = NOVALUE;
    DeRef(_26688);
    _26688 = NOVALUE;
    DeRef(_26767);
    _26767 = NOVALUE;
    DeRef(_26915);
    _26915 = NOVALUE;
    DeRef(_26638);
    _26638 = NOVALUE;
    DeRef(_26692);
    _26692 = NOVALUE;
    DeRef(_26711);
    _26711 = NOVALUE;
    _26956 = NOVALUE;
    DeRef(_27095);
    _27095 = NOVALUE;
    DeRef(_27157);
    _27157 = NOVALUE;
    _26709 = NOVALUE;
    DeRef(_26817);
    _26817 = NOVALUE;
    DeRef(_26865);
    _26865 = NOVALUE;
    DeRef(_26941);
    _26941 = NOVALUE;
    _26750 = NOVALUE;
    DeRef(_26813);
    _26813 = NOVALUE;
    DeRef(_27063);
    _27063 = NOVALUE;
    DeRef(_26740);
    _26740 = NOVALUE;
    DeRef(_26835);
    _26835 = NOVALUE;
    DeRef(_26839);
    _26839 = NOVALUE;
    DeRef(_26900);
    _26900 = NOVALUE;
    DeRef(_26953);
    _26953 = NOVALUE;
    _26755 = NOVALUE;
    DeRef(_27009);
    _27009 = NOVALUE;
    DeRef(_26676);
    _26676 = NOVALUE;
    DeRef(_26780);
    _26780 = NOVALUE;
    DeRef(_26874);
    _26874 = NOVALUE;
    DeRef(_26921);
    _26921 = NOVALUE;
    DeRef(_27115);
    _27115 = NOVALUE;
    _26656 = NOVALUE;
    DeRef(_27033);
    _27033 = NOVALUE;
    DeRef(_26732);
    _26732 = NOVALUE;
    DeRef(_26807);
    _26807 = NOVALUE;
    DeRef(_26721);
    _26721 = NOVALUE;
    DeRef(_26887);
    _26887 = NOVALUE;
    DeRef(_27087);
    _27087 = NOVALUE;
    DeRef(_26801);
    _26801 = NOVALUE;
    DeRef(_27169);
    _27169 = NOVALUE;
    DeRef(_26746);
    _26746 = NOVALUE;
    DeRef(_26821);
    _26821 = NOVALUE;
    DeRef(_27028);
    _27028 = NOVALUE;
    DeRef(_26876);
    _26876 = NOVALUE;
    DeRef(_27103);
    _27103 = NOVALUE;
    DeRef(_26668);
    _26668 = NOVALUE;
    DeRef(_26898);
    _26898 = NOVALUE;
    DeRef(_26945);
    _26945 = NOVALUE;
    DeRef(_26949);
    _26949 = NOVALUE;
    DeRef(_26961);
    _26961 = NOVALUE;
    _26724 = NOVALUE;
    DeRef(_26848);
    _26848 = NOVALUE;
    DeRef(_26861);
    _26861 = NOVALUE;
    DeRef(_26880);
    _26880 = NOVALUE;
    DeRef(_27014);
    _27014 = NOVALUE;
    DeRef(_27161);
    _27161 = NOVALUE;
    DeRef(_26911);
    _26911 = NOVALUE;
    DeRef(_26753);
    _26753 = NOVALUE;
    DeRef(_26844);
    _26844 = NOVALUE;
    DeRef(_26632);
    _26632 = NOVALUE;
    DeRef(_26923);
    _26923 = NOVALUE;
    _26958 = NOVALUE;
    DeRef(_27046);
    _27046 = NOVALUE;
    DeRef(_27091);
    _27091 = NOVALUE;
    DeRef(_27111);
    _27111 = NOVALUE;
    DeRef(_26636);
    _26636 = NOVALUE;
    DeRef(_26683);
    _26683 = NOVALUE;
    DeRef(_27050);
    _27050 = NOVALUE;
    DeRef(_27079);
    _27079 = NOVALUE;
    DeRef(_26640);
    _26640 = NOVALUE;
    DeRef(_26686);
    _26686 = NOVALUE;
    DeRef(_26894);
    _26894 = NOVALUE;
    DeRef(_27021);
    _27021 = NOVALUE;
    return;
    ;
}


void _37emit_assign_op(int _op_52604)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_op_52604)) {
        _1 = (long)(DBL_PTR(_op_52604)->dbl);
        DeRefDS(_op_52604);
        _op_52604 = _1;
    }

    /** 	if op = PLUS_EQUALS then*/
    if (_op_52604 != 515)
    goto L1; // [7] 21

    /** 		emit_op(PLUS)*/
    _37emit_op(11);
    goto L2; // [18] 86
L1: 

    /** 	elsif op = MINUS_EQUALS then*/
    if (_op_52604 != 516)
    goto L3; // [25] 39

    /** 		emit_op(MINUS)*/
    _37emit_op(10);
    goto L2; // [36] 86
L3: 

    /** 	elsif op = MULTIPLY_EQUALS then*/
    if (_op_52604 != 517)
    goto L4; // [43] 55

    /** 		emit_op(rw:MULTIPLY)*/
    _37emit_op(13);
    goto L2; // [52] 86
L4: 

    /** 	elsif op = DIVIDE_EQUALS then*/
    if (_op_52604 != 518)
    goto L5; // [59] 71

    /** 		emit_op(rw:DIVIDE)*/
    _37emit_op(14);
    goto L2; // [68] 86
L5: 

    /** 	elsif op = CONCAT_EQUALS then*/
    if (_op_52604 != 519)
    goto L6; // [75] 85

    /** 		emit_op(rw:CONCAT)*/
    _37emit_op(15);
L6: 
L2: 

    /** end procedure*/
    return;
    ;
}


void _37StartSourceLine(int _sl_52624, int _dup_ok_52625, int _emit_coverage_52626)
{
    int _line_span_52629 = NOVALUE;
    int _27224 = NOVALUE;
    int _27222 = NOVALUE;
    int _27221 = NOVALUE;
    int _27220 = NOVALUE;
    int _27219 = NOVALUE;
    int _27218 = NOVALUE;
    int _27216 = NOVALUE;
    int _27213 = NOVALUE;
    int _27211 = NOVALUE;
    int _27210 = NOVALUE;
    int _27209 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sl_52624)) {
        _1 = (long)(DBL_PTR(_sl_52624)->dbl);
        DeRefDS(_sl_52624);
        _sl_52624 = _1;
    }
    if (!IS_ATOM_INT(_dup_ok_52625)) {
        _1 = (long)(DBL_PTR(_dup_ok_52625)->dbl);
        DeRefDS(_dup_ok_52625);
        _dup_ok_52625 = _1;
    }
    if (!IS_ATOM_INT(_emit_coverage_52626)) {
        _1 = (long)(DBL_PTR(_emit_coverage_52626)->dbl);
        DeRefDS(_emit_coverage_52626);
        _emit_coverage_52626 = _1;
    }

    /** 	if gline_number = LastLineNumber then*/
    if (_26gline_number_11987 != _60LastLineNumber_23941)
    goto L1; // [13] 66

    /** 		if length(LineTable) then*/
    if (IS_SEQUENCE(_26LineTable_12072)){
            _27209 = SEQ_PTR(_26LineTable_12072)->length;
    }
    else {
        _27209 = 1;
    }
    if (_27209 == 0)
    {
        _27209 = NOVALUE;
        goto L2; // [24] 55
    }
    else{
        _27209 = NOVALUE;
    }

    /** 			if dup_ok then*/
    if (_dup_ok_52625 == 0)
    {
        goto L3; // [29] 47
    }
    else{
    }

    /** 				emit_op( STARTLINE )*/
    _37emit_op(58);

    /** 				emit_addr( gline_number )*/
    _37emit_addr(_26gline_number_11987);
L3: 

    /** 			return -- ignore duplicates*/
    return;
    goto L4; // [52] 65
L2: 

    /** 			sl = FALSE -- top-level new statement to execute on same line*/
    _sl_52624 = _9FALSE_428;
L4: 
L1: 

    /** 	LastLineNumber = gline_number*/
    _60LastLineNumber_23941 = _26gline_number_11987;

    /** 	line_span = gline_number - SymTab[CurrentSub][S_FIRSTLINE]*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27210 = (int)*(((s1_ptr)_2)->base + _26CurrentSub_11990);
    _2 = (int)SEQ_PTR(_27210);
    if (!IS_ATOM_INT(_26S_FIRSTLINE_11694)){
        _27211 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_FIRSTLINE_11694)->dbl));
    }
    else{
        _27211 = (int)*(((s1_ptr)_2)->base + _26S_FIRSTLINE_11694);
    }
    _27210 = NOVALUE;
    if (IS_ATOM_INT(_27211)) {
        _line_span_52629 = _26gline_number_11987 - _27211;
    }
    else {
        _line_span_52629 = binary_op(MINUS, _26gline_number_11987, _27211);
    }
    _27211 = NOVALUE;
    if (!IS_ATOM_INT(_line_span_52629)) {
        _1 = (long)(DBL_PTR(_line_span_52629)->dbl);
        DeRefDS(_line_span_52629);
        _line_span_52629 = _1;
    }

    /** 	while length(LineTable) < line_span do*/
L5: 
    if (IS_SEQUENCE(_26LineTable_12072)){
            _27213 = SEQ_PTR(_26LineTable_12072)->length;
    }
    else {
        _27213 = 1;
    }
    if (_27213 >= _line_span_52629)
    goto L6; // [109] 128

    /** 		LineTable = append(LineTable, -1) -- filler*/
    Append(&_26LineTable_12072, _26LineTable_12072, -1);

    /** 	end while*/
    goto L5; // [125] 104
L6: 

    /** 	LineTable = append(LineTable, length(Code))*/
    if (IS_SEQUENCE(_26Code_12071)){
            _27216 = SEQ_PTR(_26Code_12071)->length;
    }
    else {
        _27216 = 1;
    }
    Append(&_26LineTable_12072, _26LineTable_12072, _27216);
    _27216 = NOVALUE;

    /** 	if sl and (TRANSLATE or (OpTrace or OpProfileStatement)) then*/
    if (_sl_52624 == 0) {
        goto L7; // [145] 190
    }
    if (_26TRANSLATE_11619 != 0) {
        DeRef(_27219);
        _27219 = 1;
        goto L8; // [151] 171
    }
    if (_26OpTrace_12052 != 0) {
        _27220 = 1;
        goto L9; // [157] 167
    }
    _27220 = (_26OpProfileStatement_12054 != 0);
L9: 
    DeRef(_27219);
    _27219 = (_27220 != 0);
L8: 
    if (_27219 == 0)
    {
        _27219 = NOVALUE;
        goto L7; // [172] 190
    }
    else{
        _27219 = NOVALUE;
    }

    /** 		emit_op(STARTLINE)*/
    _37emit_op(58);

    /** 		emit_addr(gline_number)*/
    _37emit_addr(_26gline_number_11987);
L7: 

    /** 	if (sl and emit_coverage = COVERAGE_INCLUDE) or emit_coverage = COVERAGE_OVERRIDE then*/
    if (_sl_52624 == 0) {
        _27221 = 0;
        goto LA; // [192] 206
    }
    _27222 = (_emit_coverage_52626 == 2);
    _27221 = (_27222 != 0);
LA: 
    if (_27221 != 0) {
        goto LB; // [206] 221
    }
    _27224 = (_emit_coverage_52626 == 3);
    if (_27224 == 0)
    {
        DeRef(_27224);
        _27224 = NOVALUE;
        goto LC; // [217] 229
    }
    else{
        DeRef(_27224);
        _27224 = NOVALUE;
    }
LB: 

    /** 		include_line( gline_number )*/
    _49include_line(_26gline_number_11987);
LC: 

    /** end procedure*/
    DeRef(_27222);
    _27222 = NOVALUE;
    return;
    ;
}


int _37has_forward_params(int _sym_52683)
{
    int _27230 = NOVALUE;
    int _27229 = NOVALUE;
    int _27228 = NOVALUE;
    int _27227 = NOVALUE;
    int _27226 = NOVALUE;
    int _27225 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_52683)) {
        _1 = (long)(DBL_PTR(_sym_52683)->dbl);
        DeRefDS(_sym_52683);
        _sym_52683 = _1;
    }

    /** 	for i = cgi - (SymTab[sym][S_NUM_ARGS]-1) to cgi do*/
    _2 = (int)SEQ_PTR(_27SymTab_10921);
    _27225 = (int)*(((s1_ptr)_2)->base + _sym_52683);
    _2 = (int)SEQ_PTR(_27225);
    if (!IS_ATOM_INT(_26S_NUM_ARGS_11705)){
        _27226 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26S_NUM_ARGS_11705)->dbl));
    }
    else{
        _27226 = (int)*(((s1_ptr)_2)->base + _26S_NUM_ARGS_11705);
    }
    _27225 = NOVALUE;
    if (IS_ATOM_INT(_27226)) {
        _27227 = _27226 - 1;
        if ((long)((unsigned long)_27227 +(unsigned long) HIGH_BITS) >= 0){
            _27227 = NewDouble((double)_27227);
        }
    }
    else {
        _27227 = binary_op(MINUS, _27226, 1);
    }
    _27226 = NOVALUE;
    if (IS_ATOM_INT(_27227)) {
        _27228 = _37cgi_50278 - _27227;
        if ((long)((unsigned long)_27228 +(unsigned long) HIGH_BITS) >= 0){
            _27228 = NewDouble((double)_27228);
        }
    }
    else {
        _27228 = binary_op(MINUS, _37cgi_50278, _27227);
    }
    DeRef(_27227);
    _27227 = NOVALUE;
    _27229 = _37cgi_50278;
    {
        int _i_52685;
        Ref(_27228);
        _i_52685 = _27228;
L1: 
        if (binary_op_a(GREATER, _i_52685, _27229)){
            goto L2; // [32] 65
        }

        /** 		if cg_stack[i] < 0 then*/
        _2 = (int)SEQ_PTR(_37cg_stack_50277);
        if (!IS_ATOM_INT(_i_52685)){
            _27230 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_52685)->dbl));
        }
        else{
            _27230 = (int)*(((s1_ptr)_2)->base + _i_52685);
        }
        if (binary_op_a(GREATEREQ, _27230, 0)){
            _27230 = NOVALUE;
            goto L3; // [47] 58
        }
        _27230 = NOVALUE;

        /** 			return 1*/
        DeRef(_i_52685);
        DeRef(_27228);
        _27228 = NOVALUE;
        return 1;
L3: 

        /** 	end for*/
        _0 = _i_52685;
        if (IS_ATOM_INT(_i_52685)) {
            _i_52685 = _i_52685 + 1;
            if ((long)((unsigned long)_i_52685 +(unsigned long) HIGH_BITS) >= 0){
                _i_52685 = NewDouble((double)_i_52685);
            }
        }
        else {
            _i_52685 = binary_op_a(PLUS, _i_52685, 1);
        }
        DeRef(_0);
        goto L1; // [60] 39
L2: 
        ;
        DeRef(_i_52685);
    }

    /** 	return 0*/
    DeRef(_27228);
    _27228 = NOVALUE;
    return 0;
    ;
}



// 0x6888B6E5
