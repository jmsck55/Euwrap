// Euphoria To C version 4.0.5  (362497032f33, 2012-10-11)
#include "include/euphoria.h"
#include "main-.h"

int _33malloc(int _mem_struct_p_12254, int _cleanup_p_12255)
{
    int _temp__12256 = NOVALUE;
    int _6667 = NOVALUE;
    int _6665 = NOVALUE;
    int _6664 = NOVALUE;
    int _6663 = NOVALUE;
    int _6659 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_cleanup_p_12255)) {
        _1 = (long)(DBL_PTR(_cleanup_p_12255)->dbl);
        DeRefDS(_cleanup_p_12255);
        _cleanup_p_12255 = _1;
    }

    /** 	if atom(mem_struct_p) then*/
    _6659 = IS_ATOM(_mem_struct_p_12254);
    if (_6659 == 0)
    {
        _6659 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _6659 = NOVALUE;
    }

    /** 		mem_struct_p = repeat(0, mem_struct_p)*/
    _0 = _mem_struct_p_12254;
    _mem_struct_p_12254 = Repeat(0, _mem_struct_p_12254);
    DeRef(_0);
L1: 

    /** 	if ram_free_list = 0 then*/
    if (_33ram_free_list_12250 != 0)
    goto L2; // [22] 72

    /** 		ram_space = append(ram_space, mem_struct_p)*/
    Ref(_mem_struct_p_12254);
    Append(&_33ram_space_12249, _33ram_space_12249, _mem_struct_p_12254);

    /** 		if cleanup_p then*/
    if (_cleanup_p_12255 == 0)
    {
        goto L3; // [36] 59
    }
    else{
    }

    /** 			return delete_routine( length(ram_space), free_rid )*/
    if (IS_SEQUENCE(_33ram_space_12249)){
            _6663 = SEQ_PTR(_33ram_space_12249)->length;
    }
    else {
        _6663 = 1;
    }
    _6664 = NewDouble( (double) _6663 );
    _1 = (int) _00[_33free_rid_12251].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_33free_rid_12251].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _33free_rid_12251;
    ((cleanup_ptr)_1)->next = 0;
    if(DBL_PTR(_6664)->cleanup != 0 ){
        _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_6664)->cleanup );
    }
    else if( !UNIQUE(DBL_PTR(_6664)) ){
        DeRefDS(_6664);
        _6664 = NewDouble( DBL_PTR(_6664)->dbl );
    }
    DBL_PTR(_6664)->cleanup = (cleanup_ptr)_1;
    _6663 = NOVALUE;
    DeRef(_mem_struct_p_12254);
    return _6664;
    goto L4; // [56] 71
L3: 

    /** 			return length(ram_space)*/
    if (IS_SEQUENCE(_33ram_space_12249)){
            _6665 = SEQ_PTR(_33ram_space_12249)->length;
    }
    else {
        _6665 = 1;
    }
    DeRef(_mem_struct_p_12254);
    DeRef(_6664);
    _6664 = NOVALUE;
    return _6665;
L4: 
L2: 

    /** 	temp_ = ram_free_list*/
    _temp__12256 = _33ram_free_list_12250;

    /** 	ram_free_list = ram_space[temp_]*/
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    _33ram_free_list_12250 = (int)*(((s1_ptr)_2)->base + _temp__12256);
    if (!IS_ATOM_INT(_33ram_free_list_12250))
    _33ram_free_list_12250 = (long)DBL_PTR(_33ram_free_list_12250)->dbl;

    /** 	ram_space[temp_] = mem_struct_p*/
    Ref(_mem_struct_p_12254);
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_12249 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _temp__12256);
    _1 = *(int *)_2;
    *(int *)_2 = _mem_struct_p_12254;
    DeRef(_1);

    /** 	if cleanup_p then*/
    if (_cleanup_p_12255 == 0)
    {
        goto L5; // [97] 115
    }
    else{
    }

    /** 		return delete_routine( temp_, free_rid )*/
    _6667 = NewDouble( (double) _temp__12256 );
    _1 = (int) _00[_33free_rid_12251].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_33free_rid_12251].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _33free_rid_12251;
    ((cleanup_ptr)_1)->next = 0;
    if(DBL_PTR(_6667)->cleanup != 0 ){
        _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_6667)->cleanup );
    }
    else if( !UNIQUE(DBL_PTR(_6667)) ){
        DeRefDS(_6667);
        _6667 = NewDouble( DBL_PTR(_6667)->dbl );
    }
    DBL_PTR(_6667)->cleanup = (cleanup_ptr)_1;
    DeRef(_mem_struct_p_12254);
    DeRef(_6664);
    _6664 = NOVALUE;
    return _6667;
    goto L6; // [112] 122
L5: 

    /** 		return temp_*/
    DeRef(_mem_struct_p_12254);
    DeRef(_6664);
    _6664 = NOVALUE;
    DeRef(_6667);
    _6667 = NOVALUE;
    return _temp__12256;
L6: 
    ;
}


void _33free(int _mem_p_12274)
{
    int _6669 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if mem_p < 1 then return end if*/
    if (binary_op_a(GREATEREQ, _mem_p_12274, 1)){
        goto L1; // [3] 11
    }
    DeRef(_mem_p_12274);
    return;
L1: 

    /** 	if mem_p > length(ram_space) then return end if*/
    if (IS_SEQUENCE(_33ram_space_12249)){
            _6669 = SEQ_PTR(_33ram_space_12249)->length;
    }
    else {
        _6669 = 1;
    }
    if (binary_op_a(LESSEQ, _mem_p_12274, _6669)){
        _6669 = NOVALUE;
        goto L2; // [18] 26
    }
    _6669 = NOVALUE;
    DeRef(_mem_p_12274);
    return;
L2: 

    /** 	ram_space[mem_p] = ram_free_list*/
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_12249 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_mem_p_12274))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_mem_p_12274)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _mem_p_12274);
    _1 = *(int *)_2;
    *(int *)_2 = _33ram_free_list_12250;
    DeRef(_1);

    /** 	ram_free_list = floor(mem_p)*/
    if (IS_ATOM_INT(_mem_p_12274))
    _33ram_free_list_12250 = e_floor(_mem_p_12274);
    else
    _33ram_free_list_12250 = unary_op(FLOOR, _mem_p_12274);
    if (!IS_ATOM_INT(_33ram_free_list_12250)) {
        _1 = (long)(DBL_PTR(_33ram_free_list_12250)->dbl);
        DeRefDS(_33ram_free_list_12250);
        _33ram_free_list_12250 = _1;
    }

    /** end procedure*/
    DeRef(_mem_p_12274);
    return;
    ;
}


int _33valid(int _mem_p_12284, int _mem_struct_p_12285)
{
    int _6683 = NOVALUE;
    int _6682 = NOVALUE;
    int _6680 = NOVALUE;
    int _6679 = NOVALUE;
    int _6678 = NOVALUE;
    int _6676 = NOVALUE;
    int _6673 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not integer(mem_p) then return 0 end if*/
    if (IS_ATOM_INT(_mem_p_12284))
    _6673 = 1;
    else if (IS_ATOM_DBL(_mem_p_12284))
    _6673 = IS_ATOM_INT(DoubleToInt(_mem_p_12284));
    else
    _6673 = 0;
    if (_6673 != 0)
    goto L1; // [6] 14
    _6673 = NOVALUE;
    DeRef(_mem_p_12284);
    DeRef(_mem_struct_p_12285);
    return 0;
L1: 

    /** 	if mem_p < 1 then return 0 end if*/
    if (binary_op_a(GREATEREQ, _mem_p_12284, 1)){
        goto L2; // [16] 25
    }
    DeRef(_mem_p_12284);
    DeRef(_mem_struct_p_12285);
    return 0;
L2: 

    /** 	if mem_p > length(ram_space) then return 0 end if*/
    if (IS_SEQUENCE(_33ram_space_12249)){
            _6676 = SEQ_PTR(_33ram_space_12249)->length;
    }
    else {
        _6676 = 1;
    }
    if (binary_op_a(LESSEQ, _mem_p_12284, _6676)){
        _6676 = NOVALUE;
        goto L3; // [32] 41
    }
    _6676 = NOVALUE;
    DeRef(_mem_p_12284);
    DeRef(_mem_struct_p_12285);
    return 0;
L3: 

    /** 	if sequence(mem_struct_p) then return 1 end if*/
    _6678 = IS_SEQUENCE(_mem_struct_p_12285);
    if (_6678 == 0)
    {
        _6678 = NOVALUE;
        goto L4; // [46] 54
    }
    else{
        _6678 = NOVALUE;
    }
    DeRef(_mem_p_12284);
    DeRef(_mem_struct_p_12285);
    return 1;
L4: 

    /** 	if atom(ram_space[mem_p]) then */
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!IS_ATOM_INT(_mem_p_12284)){
        _6679 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_mem_p_12284)->dbl));
    }
    else{
        _6679 = (int)*(((s1_ptr)_2)->base + _mem_p_12284);
    }
    _6680 = IS_ATOM(_6679);
    _6679 = NOVALUE;
    if (_6680 == 0)
    {
        _6680 = NOVALUE;
        goto L5; // [65] 88
    }
    else{
        _6680 = NOVALUE;
    }

    /** 		if mem_struct_p >= 0 then*/
    if (binary_op_a(LESS, _mem_struct_p_12285, 0)){
        goto L6; // [70] 81
    }

    /** 			return 0*/
    DeRef(_mem_p_12284);
    DeRef(_mem_struct_p_12285);
    return 0;
L6: 

    /** 		return 1*/
    DeRef(_mem_p_12284);
    DeRef(_mem_struct_p_12285);
    return 1;
L5: 

    /** 	if length(ram_space[mem_p]) != mem_struct_p then*/
    _2 = (int)SEQ_PTR(_33ram_space_12249);
    if (!IS_ATOM_INT(_mem_p_12284)){
        _6682 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_mem_p_12284)->dbl));
    }
    else{
        _6682 = (int)*(((s1_ptr)_2)->base + _mem_p_12284);
    }
    if (IS_SEQUENCE(_6682)){
            _6683 = SEQ_PTR(_6682)->length;
    }
    else {
        _6683 = 1;
    }
    _6682 = NOVALUE;
    if (binary_op_a(EQUALS, _6683, _mem_struct_p_12285)){
        _6683 = NOVALUE;
        goto L7; // [99] 110
    }
    _6683 = NOVALUE;

    /** 		return 0*/
    DeRef(_mem_p_12284);
    DeRef(_mem_struct_p_12285);
    _6682 = NOVALUE;
    return 0;
L7: 

    /** 	return 1*/
    DeRef(_mem_p_12284);
    DeRef(_mem_struct_p_12285);
    _6682 = NOVALUE;
    return 1;
    ;
}



// 0x63D70821
